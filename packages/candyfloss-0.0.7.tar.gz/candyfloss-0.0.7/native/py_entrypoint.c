#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>

#include <pthread.h>

#include <Python.h>

#include <gst/gst.h>
#include <gst/video/video.h>
#include <gst/video/gstvideofilter.h>
#include <gst/app/gstappsink.h>

//#define DEBUG_PRINTF 1

#define BEGIN_PYTHON_THREAD PyGILState_STATE _gil_state = PyGILState_Ensure();
#define END_PYTHON_THREAD PyGILState_Release(_gil_state);

static inline void py_maybe_decref(PyObject *v) {
    if (v != NULL && v != Py_None) Py_DECREF(v);
}

static PyObject *pipeline_exception_class = NULL;
static PyObject *nil_tuple = NULL;

static inline GstElement *element_ref_unsink(GstElement *v) {

    return (GstElement *) g_object_ref_sink((GObject *) v);

}

static void *gevent_thread_worker(void *udata) {

    GMainContext *ctx = g_main_context_default();
    if (g_main_context_acquire(ctx)) {
        GMainLoop *loop = g_main_loop_new(ctx, 1);
        g_main_loop_run(loop);
    }
    return NULL;

}

static void start_gevent_thread() {
    pthread_t gevent_thread;
    pthread_create(&gevent_thread, NULL, gevent_thread_worker, NULL);
}

static int py_object_to_g_value(GValue *res, PyObject *inp) {

    if (PyLong_Check(inp)) {
        g_value_init(res, G_TYPE_INT);
        g_value_set_int(res, PyLong_AsLong(inp));
        return 1;
    } else if (PyBytes_Check(inp)) {
        g_value_init(res, G_TYPE_STRING);
        g_value_set_string(res, PyBytes_AsString(inp));
        return 1;
    } else if (PyFloat_Check(inp)) {
        g_value_init(res, G_TYPE_DOUBLE);
        g_value_set_double(res, PyFloat_AsDouble(inp));
        return 1;
    } else {
        PyErr_SetNone(PyExc_TypeError);
        return 0;
    }


}

static PyObject *py_object_from_g_value(const GValue *inp, GType typ) {

    switch(typ) {

        case G_TYPE_INT:
            int v = g_value_get_int(inp);
            return PyLong_FromLong(v);
        case G_TYPE_LONG:
            glong vl = g_value_get_long(inp);
            return PyLong_FromLong(vl);
        case G_TYPE_STRING:
            const gchar *vs = g_value_get_string(inp);
            return PyBytes_FromString(vs);
        case G_TYPE_DOUBLE:
            const double vd = g_value_get_double(inp);
            return PyFloat_FromDouble(vd);
        default:
            PyErr_SetNone(PyExc_TypeError);
            return NULL;

    }

}

static GstCaps *py_unwrap_caps(PyObject *inp) {
    GstCaps *res = PyCapsule_GetPointer(inp, "caps");    
    return res;
}

static void py_caps_unref(PyObject *v) {
    BEGIN_PYTHON_THREAD
    GstCaps *caps = py_unwrap_caps(v);
    END_PYTHON_THREAD
    gst_caps_unref(caps);
}

static PyObject *py_wrap_caps(GstCaps *obj) {

    gst_caps_ref(obj);
    return PyCapsule_New(obj, "caps", py_caps_unref);
    
}

static GstElement *python_gst_object_unwrap(PyObject *inp) {
    return PyCapsule_GetPointer(inp, "gst");
}

static void py_gst_wrapper_unref(PyObject *wrapper) {
    BEGIN_PYTHON_THREAD
    GstElement *ptr = python_gst_object_unwrap(wrapper);
    END_PYTHON_THREAD
    if (ptr != NULL) {
        gst_object_unref(ptr);
    }
}

static PyObject *python_gst_object_wrapper(GstElement *el) {
    return PyCapsule_New(el, "gst", py_gst_wrapper_unref);

}

typedef struct PyPipeline {
    GstPipeline *pipeline;
    PyObject *done_callback;
    PyObject *exc;
    guint cutlist_timer_handle;
    PyObject *cutlist;
    size_t cutlist_idx;
} PyPipeline;

static PyPipeline *py_pipeline_unwrap(PyObject *wrapper) {
    return PyCapsule_GetPointer(wrapper, "pipeline");
}

static gboolean pipeline_should_have_stopped(gpointer pp) {
    GST_ELEMENT_FLOW_ERROR((GstElement *) pp, GST_FLOW_ERROR);
    return FALSE;
}

static void stop_pipeline(GstPipeline *pipeline) {
    GstIterator *source_els = gst_bin_iterate_sinks((GstBin *) pipeline);
    GValue el_wrapper = G_VALUE_INIT;
    while(gst_iterator_next(source_els, &el_wrapper) == GST_ITERATOR_OK) {
        GstElement *el = (GstElement *) g_value_get_object(&el_wrapper);
        gst_element_send_event(el, gst_event_new_eos());
    }
    gst_iterator_free(source_els);

    g_timeout_add(500, pipeline_should_have_stopped, pipeline);
    gst_element_set_state((GstElement *) pipeline, GST_STATE_NULL);

}

static void py_pipeline_wrapper_unref(PyObject *wrapper) {

    PyPipeline *p = py_pipeline_unwrap(wrapper);
    if (p->pipeline) {
        stop_pipeline(p->pipeline);
        gst_object_unref(p->pipeline);
    }
    if (p->done_callback) Py_DECREF(p->done_callback);
    if (p->exc && p->exc != Py_None) Py_DECREF(p->exc);
    free(p);

}

static PyObject *py_pipeline_wrap(PyPipeline *p) {
    return PyCapsule_New(p, "pipeline", py_pipeline_wrapper_unref);
}

static PyPipeline *py_pipeline_construct(GstPipeline *gp, PyObject *cb) {

    PyPipeline *res = malloc(sizeof(PyPipeline));
    res->pipeline = gp;
    res->done_callback = cb;
    res->exc = Py_None;
    res->cutlist_timer_handle = 0;
    res->cutlist = NULL;
    res->cutlist_idx = 0;
    Py_INCREF(cb);
    return res;

}

static PyObject *make_pipeline(PyObject *self, PyObject *args) {

    const char *pipeline_name;
    PyObject *callback = NULL;
    if (!PyArg_ParseTuple(args, "sO", &pipeline_name, &callback)) return NULL;

    GstPipeline *pipeline = (GstPipeline *) gst_pipeline_new(pipeline_name);
    PyPipeline *pp = py_pipeline_construct(pipeline, callback);


    return py_pipeline_wrap(pp);

}

static PyObject *remove_element(PyObject *self, PyObject *args) {

    PyPipeline *pipeline;
    GstElement *el;

    PyObject *pipeline_wrapper = NULL;
    PyObject *el_wrapper = NULL;

    if (!PyArg_ParseTuple(args, "OO", &pipeline_wrapper, &el_wrapper)) return NULL;

    pipeline = py_pipeline_unwrap(pipeline_wrapper);
    if (pipeline == NULL) return NULL;

    el = python_gst_object_unwrap(el_wrapper);
    if (el == NULL) return NULL;

    if (!gst_bin_remove((GstBin *) (pipeline->pipeline), el)) {

        PyErr_SetString(PyExc_RuntimeError, "failed to remove element");
        return NULL;

    }


    Py_RETURN_NONE;

}

static PyObject *construct_element(PyObject *self, PyObject *args) {

    GstElementFactory *factory;
    GstElement *res;
    PyPipeline *pipeline;
    
    const char *element_name;
    PyObject *pipeline_wrapper = NULL;
    PyObject *items = NULL;
    PyObject *ret = NULL;

    if (!PyArg_ParseTuple(args, "OsO", &pipeline_wrapper, &element_name, &items)) goto end;

    pipeline = py_pipeline_unwrap(pipeline_wrapper);
    if (pipeline == NULL) {
        PyErr_SetString(PyExc_TypeError, "pipeline_unwrap");
        goto end;
    }

    factory = gst_element_factory_find(element_name);
    if (factory == NULL) {
        PyErr_SetString(PyExc_KeyError, element_name);
        goto end;
    }

    res = gst_element_factory_create(factory, NULL);

    Py_ssize_t n_items = PyList_Size(items);
    for (Py_ssize_t i=0; i < n_items; i++) {
        PyObject *item = PyList_GetItem(items, i);
        const char *k;
        PyObject *v;
        if (!PyArg_ParseTuple(item, "sO", &k, &v)) {
            goto end;
        }

        GValue gv = G_VALUE_INIT;
        if (!py_object_to_g_value(&gv, v)) goto end;
        g_object_set_property((GObject *) res, k, &gv);
    }

    if (!gst_bin_add((GstBin *) (pipeline->pipeline), res)) {
        PyErr_SetString(PyExc_RuntimeError, "could not add element to pipeline");
        goto end;
    }

    PyObject *py_el = python_gst_object_wrapper(element_ref_unsink(res));
    gchar *name = gst_element_get_name(res);
    PyObject *py_name = Py_None;
    if (name) {
        py_name = PyBytes_FromString(name);
        g_free(name);
    }
    
    ret = Py_BuildValue("(OO)", py_el, py_name);

end:
    return ret;

}

static PyObject *get_element_name(PyObject *self, PyObject *args) {

    PyObject *element_wrapper = PyTuple_GetItem(args, 0);
    if (!element_wrapper) return NULL;

    GstElement *element = python_gst_object_unwrap(element_wrapper);
    const gchar *name = gst_element_get_name(element);
    PyObject *res = PyBytes_FromString(name);
    return res;

}

static PyObject *make_capsfilter(PyObject *self, PyObject *args) {

    const char *type;
    PyObject *params = NULL;
    PyObject *pipeline_wrapper = NULL;
    PyObject *ret = NULL;
    PyPipeline *pipeline;

    if (!PyArg_ParseTuple(args, "OsO", &pipeline_wrapper, &type, &params)) goto end;

    pipeline = py_pipeline_unwrap(pipeline_wrapper);
    if (!pipeline) goto end;

    GstElementFactory *factory = gst_element_factory_find("capsfilter");
    if (factory == NULL) {
        PyErr_SetString(PyExc_RuntimeError, "could not construct capsfilter element");
        goto end;
    }

    GstElement *capsfilter = gst_element_factory_create(factory, NULL);

    GstCaps *caps = gst_caps_new_empty_simple(type);
    Py_ssize_t n_params = PyList_Size(params);
    for (Py_ssize_t i=0; i < n_params; i++) {
        PyObject *param = PyList_GetItem(params, i);
        const char *k;
        PyObject *v;
        if (!PyArg_ParseTuple(param, "sO", &k, &v)) {
            goto end;
        }

        GValue gv = G_VALUE_INIT;
        if (!py_object_to_g_value(&gv, v)) goto end;
        gst_caps_set_value(caps, k, &gv);
    }

    g_object_set((GObject *) capsfilter, "caps", caps, NULL);

    gst_bin_add((GstBin *) (pipeline->pipeline), capsfilter);

    ret = python_gst_object_wrapper(element_ref_unsink(capsfilter));

end:
    return ret;

}

static void link_deferred(GstElement *upstream, GstPad *upstream_pad, GstElement *downstream) {

    GstIterator *downstream_sink_pads = gst_element_iterate_sink_pads(downstream);
    GValue downstream_pad_container = G_VALUE_INIT;
    GstPad *downstream_pad;

    while(gst_iterator_next(downstream_sink_pads, &downstream_pad_container) == GST_ITERATOR_OK) {

        downstream_pad = g_value_get_object(&downstream_pad_container);
        if (gst_pad_can_link(upstream_pad, downstream_pad) && (gst_pad_link(upstream_pad, downstream_pad) == GST_PAD_LINK_OK)) {
            break;
        }
    }

    gst_iterator_free(downstream_sink_pads);

}

typedef struct NamedDeferedPadArgs {
    GstElement *downstream;
    char *upstream_pad_name;
    char *downstream_pad_name;
    gboolean is_linked;
    gulong handler_id;
    pthread_mutex_t lock;
} NamedDeferredPadArgs;

static void link_named(GstElement *upstream, GstPad *upstream_pad, NamedDeferredPadArgs *args) {

    pthread_mutex_lock(&(args->lock));

    if (args->is_linked) goto end;


    if (gst_element_link_pads(
        upstream, args->upstream_pad_name,
        args->downstream, args->downstream_pad_name)) {

        args->is_linked = TRUE;
        if (args->upstream_pad_name) {
            free(args->upstream_pad_name);
            args->upstream_pad_name = NULL;
        }
        if (args->downstream_pad_name) {
            free(args->downstream_pad_name);
            args->downstream_pad_name = NULL;
        }
        g_signal_handler_disconnect((GObject *) upstream, args->handler_id);
        //free(args);

    }

end:
    pthread_mutex_unlock(&(args->lock));

}

static PyObject *link_elements(PyObject *self, PyObject *args) {

    PyObject *py_upstream = NULL;
    PyObject *py_downstream = NULL;
    PyObject *upstream_name = NULL;
    PyObject *downstream_name = NULL;

    if (!PyArg_ParseTuple(args, "OOOO", 
        &py_upstream, &py_downstream, &upstream_name, &downstream_name)) return NULL;

    
    GstElement *upstream = python_gst_object_unwrap(py_upstream);
    if (!upstream) {
        PyErr_SetString(PyExc_TypeError, "upstream is invalid");
        return NULL;
    }
    GstElement *downstream = python_gst_object_unwrap(py_downstream);
    if (!downstream) {
        PyErr_SetString(PyExc_TypeError, "upstream is invalid");
        return NULL;
    }
    const char *upstream_name_string = 
        upstream_name == Py_None ? NULL : PyBytes_AsString(upstream_name);
    const char *downstream_name_string = 
        downstream_name == Py_None ? NULL : PyBytes_AsString(downstream_name);

    
    if (!upstream_name_string && !downstream_name_string) {
        if (!gst_element_link(upstream, downstream)) {

            g_signal_connect(upstream, "pad-added", G_CALLBACK(link_deferred), downstream);        
        }
    } else {

        if (!gst_element_link_pads(
            upstream, upstream_name_string,
            downstream, downstream_name_string)) {

            NamedDeferredPadArgs *pad_args = malloc(sizeof(NamedDeferredPadArgs));
            pthread_mutex_init(&(pad_args->lock), NULL);
            pad_args->downstream = downstream;
            if (upstream_name_string) {
                size_t name_size = PyBytes_Size(upstream_name) + 1;
                pad_args->upstream_pad_name = malloc(name_size);
                memcpy(pad_args->upstream_pad_name, PyBytes_AsString(upstream_name), name_size);
            } else {
                pad_args->upstream_pad_name = NULL;
            }
            if (downstream_name_string) {
                size_t name_size = PyBytes_Size(downstream_name) + 1;
                pad_args->downstream_pad_name = malloc(name_size);
                memcpy(pad_args->downstream_pad_name, PyBytes_AsString(downstream_name), name_size);
            } else {
                pad_args->downstream_pad_name = NULL;
            }
            pad_args->is_linked = FALSE;
            pad_args->handler_id = g_signal_connect(upstream,
                "pad-added", G_CALLBACK(link_named), pad_args);

        }

    }

    Py_RETURN_NONE;

}

static gboolean ensure_pipeline_closed_callback(gpointer p) {
    PyObject *py_wrapper = (PyObject *) p;
    BEGIN_PYTHON_THREAD;
    PyPipeline *pipeline =  py_pipeline_unwrap(py_wrapper);
    GstBus *bus = gst_pipeline_get_bus(pipeline->pipeline);
    gst_bus_remove_watch(bus);
    gst_object_unref((GstObject *) bus);
    Py_DECREF(py_wrapper);
    END_PYTHON_THREAD;
    return FALSE;
}

static void pipeline_done(GstBus *bus, GstMessage *message, gpointer pipeline_p) {

    BEGIN_PYTHON_THREAD
    const GstStructure *data = gst_message_get_structure(message);
    GstObject *src_object = message->src;
    PyObject *name = Py_None;
    if (src_object) {
        name = PyList_New(0);

        GstObject *cur_object = src_object;

        while (cur_object) {
            gchar *gname = gst_object_get_name(cur_object);
            if (gname) {
                PyList_Append(name, PyBytes_FromString(gname));
                g_free(gname);
            } else {
                break;
            }
            cur_object = gst_object_get_parent(cur_object);
        }

    }

    PyObject *pipeline_wrapper = (PyObject *) pipeline_p;
    PyPipeline *pipeline = py_pipeline_unwrap(pipeline_wrapper);

    if (message->type == GST_MESSAGE_ERROR && pipeline_exception_class) {
        GError *error;
        gst_message_parse_error(message, &error, NULL);
        pipeline->exc = PyObject_CallFunction(pipeline_exception_class,
            "ss", error->message, gst_structure_get_string(data, "debug"));
        g_error_free(error);
    }

    if (pipeline->cutlist) {

        PyObject *cutlist = pipeline->cutlist;
        pipeline->cutlist = NULL;
        Py_DECREF(cutlist);


    }

    if (pipeline->done_callback) {
        PyObject_CallFunction(pipeline->done_callback, "OO", pipeline->exc, name);
    }
    Py_DECREF(pipeline_wrapper);

    if (name != Py_None) Py_DECREF(name);

    END_PYTHON_THREAD
  
    gst_element_set_state((GstElement *) (pipeline->pipeline), GST_STATE_NULL);
    g_timeout_add(100, ensure_pipeline_closed_callback, pipeline_wrapper);

}

static gboolean bus_watch(GstBus *bus, GstMessage *message, gpointer pipeline_p) {

   
#ifdef DEBUG_PRINTF
    printf("%s\n", gst_message_type_get_name(GST_MESSAGE_TYPE(message)));
#endif

    switch(message->type) {

        case GST_MESSAGE_STATE_CHANGED:
            GstState new_state;
            GstState old_state;
            gst_message_parse_state_changed(message, &old_state, &new_state, NULL);
            if (old_state == GST_STATE_PLAYING) {
                pipeline_done(bus, message, pipeline_p);
                return FALSE;
            } else {
                return TRUE;
            }


        case GST_MESSAGE_EOS:
        case GST_MESSAGE_ERROR:
            pipeline_done(bus, message, pipeline_p);
            return FALSE;

        default:
            return TRUE;
    }

}

static gboolean state_check_timeout(gpointer vp) {
    BEGIN_PYTHON_THREAD;
    PyObject *pipeline_wrapper = (PyObject *) vp;
    PyPipeline *pipeline = py_pipeline_unwrap(pipeline_wrapper);
    if (pipeline) {
        GstState cur_state;
        gst_element_get_state(
            (GstElement *) (pipeline->pipeline),
            &cur_state, NULL, 0);
        if (cur_state != GST_STATE_PLAYING && pipeline->done_callback) {
            BEGIN_PYTHON_THREAD

            PyObject *exc = PyObject_CallFunction(PyExc_RuntimeError, "s", "playing timed out");

            PyObject_CallOneArg(pipeline->done_callback, exc);           

            PyObject_CallFunction(pipeline->done_callback, "OO", exc, nil_tuple);

            END_PYTHON_THREAD
        }
    }

    Py_DECREF(pipeline_wrapper);
    END_PYTHON_THREAD;
    return FALSE;

}

static PyObject *run_pipeline(PyObject *self, PyObject *args) {


    PyObject *pipeline_wrapper = PyTuple_GetItem(args, 0);
    if (pipeline_wrapper == NULL) return NULL;
    PyPipeline *pipeline = py_pipeline_unwrap(pipeline_wrapper);
    if (pipeline == NULL) return NULL;
    
    GstBus *bus = gst_pipeline_get_bus(pipeline->pipeline);
    Py_INCREF(pipeline_wrapper);
    gst_bus_add_watch(bus, bus_watch, pipeline_wrapper);
    gst_pipeline_set_auto_flush_bus(pipeline->pipeline, TRUE);
    gst_object_unref((GstObject *) bus);


    if (gst_element_set_state((GstElement *) (pipeline->pipeline), GST_STATE_PLAYING) == \
        GST_STATE_CHANGE_FAILURE) {
        PyErr_SetString(PyExc_RuntimeError, "failed to play pipeline");
        return NULL;
    }

    Py_INCREF(pipeline_wrapper);
    //g_timeout_add_seconds(10, state_check_timeout, pipeline_wrapper);

    Py_RETURN_NONE;

}

static GstBuffer *py_bytes_to_gst_buffer(PyObject *inp) {
    PyObject *bytes = PyBytes_FromObject(inp);
    if (!bytes) return NULL;
    char *data = PyBytes_AsString(bytes);
    size_t size = PyBytes_Size(bytes);

    GstBuffer *res = gst_buffer_new_memdup(data, size);

    Py_DECREF(bytes);

    return res;
}

static GstFlowReturn appsrc_iterator_callback(GstElement *appsrc, guint length, PyObject *iterator) {

    BEGIN_PYTHON_THREAD
    GstFlowReturn ret = GST_FLOW_OK;
    PyObject *next_value = NULL;

    if (!PyIter_Check(iterator)) {
        ret = GST_FLOW_ERROR;
        goto end;
    }

    next_value = PyIter_Next(iterator);
    
    if (next_value == NULL) {

        if (PyErr_Occurred()) {
            PyErr_Print();
            ret = GST_FLOW_ERROR;
        } else {
            ret = GST_FLOW_EOS;
        }
        g_signal_emit_by_name(appsrc, "end-of-stream", &ret);
        Py_DECREF(iterator);
        goto end;
    }

    PyObject *py_data = NULL;
    uint64_t timestamp;
    uint64_t duration;
    uint64_t counter;
    if (!PyArg_ParseTuple(next_value, "OKKK", &py_data, &timestamp, &duration, &counter)) {
        ret = GST_FLOW_ERROR;
        goto end;
    }

    if (!PyBytes_Check(py_data)) {
        PyErr_SetNone(PyExc_TypeError);
        ret = GST_FLOW_ERROR;
        goto end;
    }

    GstBuffer *buf = py_bytes_to_gst_buffer(py_data);
    buf->dts = timestamp;
    buf->pts = timestamp;
    buf->duration = duration;
    buf->offset = counter;

    g_signal_emit_by_name(appsrc, "push-buffer", buf, &ret);
    gst_buffer_unref(buf);

end:
    py_maybe_decref(next_value);

    if (PyErr_Occurred()) {
        PyErr_Print();
    }
    END_PYTHON_THREAD
    
    return ret;

}


static PyObject *make_iterator_source(PyObject *self, PyObject *args) {
    PyObject *pipeline_wrapper;
    PyObject *inp;
    PyObject *caps_wrapper;

    if (!PyArg_ParseTuple(args, "OOO", &pipeline_wrapper, &inp, &caps_wrapper)) return NULL;

    inp = PyObject_GetIter(inp);
    if (!inp) return NULL;

    PyPipeline *pipeline = py_pipeline_unwrap(pipeline_wrapper);
    if (!pipeline) return NULL;

    GstCaps *caps = py_unwrap_caps(caps_wrapper);
    if (!caps) return NULL;

    GstElementFactory *factory = gst_element_factory_find("appsrc");
    if (factory == NULL) {
        PyErr_SetString(PyExc_ImportError, "appsrc element cannot be found. something is wrong with your gstreamer installation");
        return NULL;
    }

    GstElement *appsrc = gst_element_factory_create(factory, NULL);
    if (appsrc == NULL) {
        PyErr_SetString(PyExc_RuntimeError, "failed to construct appsrc");
        return NULL;
    }

    if (!gst_bin_add((GstBin *) (pipeline->pipeline), appsrc)) {
        PyErr_SetString(PyExc_RuntimeError, "failed to add appsrc to pipeline");
        gst_object_unref(appsrc);
        return NULL;
    }

    gst_caps_ref(caps);
    g_object_set((GObject *) appsrc, 
        "emit-signals", TRUE, 
        "caps", caps,
        "is-live", FALSE,
        "stream-type", 0,
        NULL);
    gst_caps_unref(caps);

    g_signal_connect(appsrc, "need-data", G_CALLBACK(appsrc_iterator_callback), inp);

    return python_gst_object_wrapper(element_ref_unsink(appsrc));


}

static PyObject *gst_buffer_to_python(GstBuffer *buf) {

    size_t size = gst_buffer_get_size(buf);
    if (size < 1) return Py_None;
    PyObject *py_buf = PyBytes_FromStringAndSize(NULL, size);
    if (!py_buf) return NULL;

    gst_buffer_extract(buf, 0, PyBytes_AsString(py_buf), size);

    return py_buf;
}

static void appsink_eos(GstElement *appsink, gpointer pipeline_p) {

    gst_element_send_event((GstElement *) pipeline_p, gst_event_new_eos());

}

static GstElement *make_appsink(PyPipeline *pipeline) {

    GstElementFactory *factory = gst_element_factory_find("appsink");
    if (factory == NULL) {
        PyErr_SetString(PyExc_ImportError, "appsink element cannot be found. something is wrong with your gstreamer installation");
        return NULL;
    }

    GstElement *appsink = gst_element_factory_create(factory, NULL);
    if (appsink == NULL) {
        PyErr_SetString(PyExc_RuntimeError, "failed to construct appsink");
        return NULL;
    }

    gst_object_ref(appsink);
    if (!gst_bin_add((GstBin *) (pipeline->pipeline), appsink)) {
        PyErr_SetString(PyExc_RuntimeError, "failed to add appsink to pipeline");
        return NULL;
    }

    return appsink;

}

static PyObject *make_callback_sink(PyObject *self, PyObject *args) {

    PyObject *pipeline_wrapper;
    PyObject *caps_wrapper;
    int max_buffers;

    if (!PyArg_ParseTuple(args, "OOi", &pipeline_wrapper, &caps_wrapper, &max_buffers)) return NULL;

    PyPipeline *pipeline = py_pipeline_unwrap(pipeline_wrapper);

    GstCaps *caps;
    if (caps_wrapper == Py_None) {
        caps = NULL;
    } else {
        caps = py_unwrap_caps(caps_wrapper);
    }

    GstElement *appsink = make_appsink(pipeline);

    //g_signal_connect((GObject *) appsink, "eos", G_CALLBACK(appsink_eos), pipeline->pipeline);

    g_object_set((GObject *) appsink, 
        "max-buffers", max_buffers,
        "sync", FALSE,
        NULL);
    if (caps) {

        g_object_set((GObject *) appsink, 
            "caps", caps,
            NULL);

    }

    return python_gst_object_wrapper(element_ref_unsink(appsink));

}

static PyObject *appsink_pull_buffer(PyObject *self, PyObject *args) {

    PyObject *element_wrapper;
    guint64 timeout_interval;
    if (!PyArg_ParseTuple(args, "OK", &element_wrapper, &timeout_interval)) return NULL;

    GstElement *element = python_gst_object_unwrap(element_wrapper);

    GstSample *sample = NULL;
    Py_BEGIN_ALLOW_THREADS
    g_signal_emit_by_name(element, "try-pull-sample", timeout_interval, &sample);
    Py_END_ALLOW_THREADS

    if (sample == NULL) {
        gboolean is_eos;
        g_object_get((GObject *) element, "eos", &is_eos, NULL);
        if (is_eos) {
            Py_RETURN_NONE;
        } else {
            Py_RETURN_FALSE;
        }
    }

    GstBuffer *buf = gst_sample_get_buffer(sample);
    if (buf == NULL) {
        gst_sample_unref(sample);
        Py_RETURN_FALSE;
    }
    PyObject *py_buf = gst_buffer_to_python(buf);
    gst_sample_unref(sample);

    GstPad *sink_pad = gst_element_get_static_pad(element, "sink");
    if (sink_pad == NULL) Py_RETURN_FALSE;
    GstCaps *sink_caps = gst_pad_get_current_caps(sink_pad);
    if (sink_caps == NULL) Py_RETURN_FALSE;
    PyObject *py_caps = py_wrap_caps(sink_caps);
    gst_caps_unref(sink_caps);
    gst_object_unref(sink_pad);
   
    PyObject *res = Py_BuildValue("(OOkkk)", 
        py_buf, py_caps,
        buf->pts, buf->duration, buf->offset);

    Py_DECREF(py_buf);

    return res;
    
}

// transform filter

G_BEGIN_DECLS

typedef struct _GstPythonFilter GstPythonFilter;
typedef struct _GstPythonFilterClass GstPythonFilterClass;

struct _GstPythonFilter {

    GstBaseTransform base_transform;

    PyObject *callback;
    GstCaps *sink_caps;
    GstCaps *src_caps;
    gboolean pass_meta_to_callback;

};

struct _GstPythonFilterClass {

    GstBaseTransformClass parent_class;

};

GST_ELEMENT_REGISTER_DECLARE(pythonfilter);

G_END_DECLS

G_DEFINE_TYPE(GstPythonFilter, gst_python_filter, GST_TYPE_BASE_TRANSFORM);

static gboolean py_filter_accept_caps(GstBaseTransform *selfp, GstPadDirection direction, GstCaps *caps) {


    GstPythonFilter *self = (GstPythonFilter *) selfp;

    if (direction == GST_PAD_SRC) {

        return gst_caps_can_intersect(caps, self->sink_caps);

    } else if (direction == GST_PAD_SINK) {
        
        return gst_caps_can_intersect(caps, self->src_caps);

    } else {

        return FALSE;

    }

}

static GstFlowReturn py_filter_transform(GstBaseTransform *base, GstBuffer *buf_in, GstBuffer *buf_out) {


    GstPythonFilter *self = (GstPythonFilter *) base;

    GstPad *src_pad = GST_BASE_TRANSFORM_SRC_PAD(base);
    GstPad *sink_pad = GST_BASE_TRANSFORM_SINK_PAD(base);

    GstCaps *src_caps = gst_pad_get_current_caps(src_pad);
    GstCaps *sink_caps = gst_pad_get_current_caps(sink_pad);
    
    GstFlowReturn ret = GST_FLOW_ERROR;

    BEGIN_PYTHON_THREAD


    PyObject *src_caps_wrapper = py_wrap_caps(src_caps);
    PyObject *sink_caps_wrapper = py_wrap_caps(sink_caps);

    PyObject *py_in = gst_buffer_to_python(buf_in);
    Py_INCREF(py_in);

    PyObject *cb_res;
    if (self->pass_meta_to_callback) {
        cb_res = PyObject_CallFunction(self->callback, "OOO(kkk)",
            sink_caps_wrapper, src_caps_wrapper, py_in,
            buf_in->pts, buf_in->duration, buf_in->offset
            );
    } else {
        cb_res = PyObject_CallFunction(self->callback, "OOO",
            sink_caps_wrapper, src_caps_wrapper, py_in);
    }

    if (cb_res == Py_False) {
        ret = GST_FLOW_EOS;
        cb_res = NULL;
        goto end;
    }

    if (!cb_res || !PyBytes_Check(cb_res)) {
        ret = GST_FLOW_ERROR;
        goto end;
    }

    const char *res_data = PyBytes_AsString(cb_res);
    size_t res_size = PyBytes_Size(cb_res);
    
    gst_buffer_fill(buf_out, 0, res_data, res_size);
    ret = GST_FLOW_OK;

    Py_DECREF(cb_res);



end:

    END_PYTHON_THREAD
    if (py_in) Py_DECREF(py_in);
    gst_caps_unref(src_caps);
    gst_caps_unref(sink_caps);
    return ret;
}

static void py_filter_finalize(GObject *gobject) {

    GstPythonFilter *f = (GstPythonFilter *) gobject;
    Py_DECREF(f->callback);
    gst_caps_unref(f->src_caps);
    gst_caps_unref(f->sink_caps);
    G_OBJECT_CLASS(gst_python_filter_parent_class)->finalize(gobject);

}

static void gst_python_filter_init(GstPythonFilter *self) {
    return;
    self->callback = NULL;
    self->sink_caps = NULL;
    self->src_caps = NULL;
    self->pass_meta_to_callback = FALSE;

}

static GstStaticPadTemplate python_src_template = 
    GST_STATIC_PAD_TEMPLATE(
        "src",
        GST_PAD_SRC,
        GST_PAD_ALWAYS,
        GST_STATIC_CAPS_ANY);
static GstStaticPadTemplate python_sink_template = 
    GST_STATIC_PAD_TEMPLATE(
        "sink",
        GST_PAD_SINK,
        GST_PAD_ALWAYS,
        GST_STATIC_CAPS_ANY);

static void gst_python_filter_class_init(GstPythonFilterClass *cls) {

    GObjectClass *gobject_class = (GObjectClass *) cls;
    GstElementClass *gst_element_class = (GstElementClass *) cls;
    GstBaseTransformClass *gst_transform_class = (GstBaseTransformClass *) cls;

    gobject_class->finalize = py_filter_finalize;

    gst_element_class_set_static_metadata(gst_element_class, "Python Filter",
        "Filter", 
        "Runs user-defined python code to transform things",
        "Bob Poekert <candyfloss@hella.cheap>");

    gst_transform_class->accept_caps = py_filter_accept_caps;
    gst_transform_class->transform = py_filter_transform;


    gst_element_class_add_static_pad_template(gst_element_class, &python_sink_template);
    gst_element_class_add_static_pad_template(gst_element_class, &python_src_template);

}

PyObject *make_callback_transform(PyObject *self, PyObject *args) {

    PyObject *pipeline_wrapper = NULL;
    PyObject *inp_caps_wrapper = NULL;
    PyObject *outp_caps_wrapper = NULL;
    PyObject *callback = NULL;
    const char *desired_name;
    PyObject *pass_meta_to_callback = NULL;

    if (!PyArg_ParseTuple(args, "OOOOsO", 
        &pipeline_wrapper,
        &inp_caps_wrapper,
        &outp_caps_wrapper,
        &callback,
        &desired_name,
        &pass_meta_to_callback)) return NULL;

    PyPipeline *pipeline = py_pipeline_unwrap(pipeline_wrapper);
    if (!pipeline) return NULL;

    GstCaps *inp_caps = py_unwrap_caps(inp_caps_wrapper);
    if (!inp_caps) return NULL;
    GstCaps *outp_caps = py_unwrap_caps(outp_caps_wrapper);
    if (!outp_caps) return NULL;
    
    GstPythonFilter *el = (GstPythonFilter *) g_object_new(gst_python_filter_get_type(), NULL);
    el->callback = callback;
    el->pass_meta_to_callback = pass_meta_to_callback == Py_True;
    gst_caps_ref(inp_caps);
    el->sink_caps = inp_caps;
    gst_caps_ref(outp_caps);
    el->src_caps = outp_caps;

    if (!gst_bin_add((GstBin *) (pipeline->pipeline), (GstElement *) el)) {
        PyErr_SetString(PyExc_RuntimeError, "failed to add filter to pipeline");
        return NULL;
    }
    
    Py_INCREF(callback);
    gst_object_ref(el);
    return python_gst_object_wrapper((GstElement *) el);

}

// multi-map

G_BEGIN_DECLS

typedef struct _GstPythonMultiMap GstPythonMultiMap;
typedef struct _GstPythonMultiMapClass GstPythonMultiMapClass;

struct _GstPythonMultiMap {

    GstAggregator aggregator;
    PyObject *callback;
    GstClockTime *last_timestamps;

};

struct _GstPythonMultiMapClass {

    GstAggregatorClass parent_class;

};

GST_ELEMENT_REGISTER_DECLARE(pythonmultimap);

G_END_DECLS

G_DEFINE_TYPE(GstPythonMultiMap, gst_python_multi_map, GST_TYPE_AGGREGATOR);

static gboolean buffers_overlap(GstBuffer *a, GstBuffer *b) {

    GstClockTime a_start = a->pts;
    GstClockTime a_end = a->pts + a->duration;

    GstClockTime b_start = b->pts;
    GstClockTime b_end = b->pts + b->duration;

    return a_end >= b_start && b_end >= a_start; 
    

}

static GstBuffer *gst_python_multi_map_peek_buffer(GstPythonMultiMap *self, GstAggregatorPad *pad, size_t pad_i) {

    
        GstBuffer *buf = gst_aggregator_pad_peek_buffer(pad);
        while(buf && buf->pts < self->last_timestamps[pad_i]) {
            // buffer is out of order, drop
            gst_aggregator_pad_drop_buffer(pad);
            buf = gst_aggregator_pad_peek_buffer(pad);
        }
        if (buf) self->last_timestamps[pad_i] = buf->pts;
        return buf;

}

static GstFlowReturn gst_python_multi_map_aggregate(GstAggregator *selfp, gboolean timeout) {


    GstFlowReturn ret = GST_AGGREGATOR_FLOW_NEED_DATA;

    GstPythonMultiMap *self = (GstPythonMultiMap *) selfp;
    GstElement *el = (GstElement *) selfp;

    size_t n_queues = el->numsinkpads;

    size_t ag_buffers_size = (sizeof(GstBuffer *) + sizeof(GstCaps *) + sizeof(GstAggregatorPad *)) * n_queues;
    GstBuffer **ag_buffers = malloc(ag_buffers_size);
    GstCaps **ag_caps = (GstCaps **) &(ag_buffers[n_queues]);
    GstAggregatorPad **ag_pads = (GstAggregatorPad **) &(ag_caps[n_queues]);

    memset(ag_buffers, 0, ag_buffers_size);

    GList *sink_pads_hd = el->sinkpads;
    size_t pad_i = 0;
    while(sink_pads_hd) {

        GstAggregatorPad *pad = (GstAggregatorPad *) sink_pads_hd->data;
        if (gst_aggregator_pad_is_eos(pad)) {
            ret = GST_FLOW_EOS;
            goto bail_out;
        }
        GstBuffer *buf = gst_python_multi_map_peek_buffer(self, pad, pad_i);
        if (!buf) {
            // some queues are empty
            // this is actually guaranteed never to happen by the API contract for GstAggregator
            // but we're checkint it anyway
            ret = GST_FLOW_ERROR;
            goto bail_out;
        }
        ag_buffers[pad_i] = buf;
        ag_caps[pad_i] = gst_pad_get_current_caps((GstPad *) pad);
        ag_pads[pad_i] = pad;
        pad_i++;

        sink_pads_hd = sink_pads_hd->next;

    }

    gboolean found_result = FALSE;

    while(1) {

        // until either
            // one of the queues is empty
            // the buffers at the heads of all of the queues overlap
        // drop the oldest buffer


        // if one of the queues is empty (result of _peek_buffer() is NULL), exit
        for (size_t i=0; i < n_queues; i++) {
            if (ag_buffers[i] == NULL) goto bail_out;
        }

        // if all of the queues overlap, we are done
        gboolean all_overlap = TRUE;
        for (size_t i=1; i < n_queues; i++) {
            if (!buffers_overlap(ag_buffers[0], ag_buffers[i])) {
                all_overlap = FALSE;
                break;
            }
        }

        if (all_overlap) {
            found_result = TRUE;
            break;
        }

        // drop the oldest buffer

        size_t oldest_idx = 0;
        GstClockTime oldest_timestamp = ag_buffers[0]->pts;
        for (size_t i=1; i < n_queues; i++) {

            if (ag_buffers[i]->pts < oldest_timestamp) {
                oldest_idx = i;
                oldest_timestamp = ag_buffers[i]->pts;
            }

        }

        gst_aggregator_pad_drop_buffer(ag_pads[oldest_idx]);
        if (ag_buffers[oldest_idx]) gst_buffer_unref(ag_buffers[oldest_idx]);
        ag_buffers[oldest_idx] = gst_python_multi_map_peek_buffer(self, ag_pads[oldest_idx], oldest_idx);

    }

    GstClockTime max_pts = 0;
    GstClockTime max_dts = 0;
    GstClockTime min_end = -1;

    for (size_t i=0; i < n_queues; i++) {

        GstBuffer *buf = ag_buffers[i];
        GstClockTime end = buf->pts + buf->duration;
        if (buf->pts > max_pts) max_pts = buf->pts;
        if (buf->dts > max_dts) max_dts = buf->dts;
        if (end < min_end) min_end = end;

    }

    //gst_aggregator_selected_samples(selfp, max_pts, max_dts, min_end - max_pts, NULL);

    if (found_result) {
        BEGIN_PYTHON_THREAD

        PyObject *buffer_tuple = PyTuple_New(n_queues);
        for (size_t i=0; i < el->numsinkpads; i++) {
            PyObject *pybuf = gst_buffer_to_python(ag_buffers[i]);
            if (!pybuf) {
                ret = GST_FLOW_ERROR;
                Py_DECREF(buffer_tuple);
                break;
            }
            PyObject *pair = PyTuple_New(2);
            PyObject *pycaps = py_wrap_caps(ag_caps[i]);
            PyTuple_SetItem(pair, 0, pybuf);
            PyTuple_SetItem(pair, 1, pycaps);

            PyTuple_SetItem(buffer_tuple, i, pair);

            gst_buffer_unref(ag_buffers[i]);
            ag_buffers[i] = NULL;
            gst_aggregator_pad_drop_buffer(ag_pads[i]);
            gst_caps_unref(ag_caps[i]);
            ag_caps[i] = NULL;
        }

        GstCaps *src_caps = gst_pad_get_current_caps(selfp->srcpad);
        PyObject *src_caps_wrapper = py_wrap_caps(src_caps);
        PyObject *res = PyObject_CallFunction(self->callback, "OO", 
            buffer_tuple, src_caps_wrapper);
        gst_caps_unref(src_caps);
        Py_DECREF(buffer_tuple);
        Py_DECREF(src_caps_wrapper);
       
        if (!res || res == Py_None) {
            ret = GST_FLOW_ERROR;
            END_PYTHON_THREAD
        } else if (res == Py_False) {
            ret = GST_FLOW_EOS;
            END_PYTHON_THREAD
        } else {

            GstBuffer *outp = py_bytes_to_gst_buffer(res);
            Py_DECREF(res);
            END_PYTHON_THREAD
            if (outp) {
               
                outp->pts = max_pts;
                outp->dts = max_dts;
                outp->duration = (min_end - max_pts);
                ret = gst_aggregator_finish_buffer(selfp, outp);

            } else {
                ret = GST_FLOW_ERROR;
            }

        }
        
    }


bail_out:
    for (size_t i=0; i < n_queues; i++) {
        
        if (ag_buffers[i]) gst_buffer_unref(ag_buffers[i]);
        if (ag_caps[i]) gst_caps_unref(ag_caps[i]);

    }
    free(ag_buffers);
    return ret;


}

static void gst_python_multi_map_finalize(GObject *gobject) {

    GstPythonMultiMap *self = (GstPythonMultiMap *) gobject;    

    BEGIN_PYTHON_THREAD;
    Py_DECREF(self->callback);
    END_PYTHON_THREAD;

    G_OBJECT_CLASS(gst_python_multi_map_parent_class)->finalize(gobject);

}

static void gst_python_multi_map_init(GstPythonMultiMap *self) {

    self->callback = NULL;
    self->last_timestamps = NULL;
   
}


static void gst_python_multi_map_class_init(GstPythonMultiMapClass *cls) {


    GObjectClass *gobject_class = (GObjectClass *) cls;
    GstElementClass *gst_element_class = (GstElementClass *) cls;
    GstAggregatorClass *gst_aggregator_class = (GstAggregatorClass *) cls;

    gobject_class->finalize = gst_python_multi_map_finalize;
    gst_element_class_set_static_metadata(gst_element_class, "Python Multi-Map",
        "FIlter",
        "An aggregator which takes inputs from all of its input pads and maps them through a python function",
        "Bob Poekert <candyfloss@hella.cheap>");

    
    gst_aggregator_class->aggregate = gst_python_multi_map_aggregate;

    gst_element_class_add_static_pad_template(gst_element_class, &python_sink_template);
    gst_element_class_add_static_pad_template(gst_element_class, &python_src_template);


}


static PyObject *make_multi_map(PyObject *self, PyObject *args) {

    PyObject *pipeline_wrapper = PyTuple_GetItem(args, 0);
    PyObject *callback = PyTuple_GetItem(args, 1);
    PyObject *inp_caps_tuple = PyTuple_GetItem(args, 2);
    PyObject *outp_caps_wrapper = PyTuple_GetItem(args, 3);

    PyPipeline *pipeline = py_pipeline_unwrap(pipeline_wrapper);
    if (!pipeline) return NULL;

    GstPythonMultiMap *mm = (GstPythonMultiMap *) 
        g_object_new(gst_python_multi_map_get_type(), NULL);
    GstAggregator *agg = (GstAggregator *) mm;
    GstElement *el = (GstElement *) mm;

    Py_INCREF(callback);
    size_t n_sink_pads = PyTuple_Size(inp_caps_tuple);
    mm->callback = callback;
    mm->last_timestamps = malloc(sizeof(GstClockTime) * n_sink_pads);
    memset(mm->last_timestamps, 0, sizeof(GstClockTime) * n_sink_pads);

    gst_aggregator_set_ignore_inactive_pads(agg, FALSE);
    gst_aggregator_set_force_live(agg, TRUE);

    GstCaps *src_caps = py_unwrap_caps(outp_caps_wrapper);
    if (!src_caps) return NULL;
    gst_aggregator_set_src_caps(agg, src_caps);

    for (size_t i=0; i < n_sink_pads; i++) {

        GstCaps *pad_caps = py_unwrap_caps(PyTuple_GetItem(inp_caps_tuple, i));
        GstPadTemplate *pad_template = gst_pad_template_new_with_gtype("sink", 
            GST_PAD_SINK, GST_PAD_ALWAYS, pad_caps,
            gst_aggregator_pad_get_type());
        if (!pad_template) {
            PyErr_SetString(PyExc_RuntimeError, "failed to create pad template");
            gst_object_unref((GstObject *) mm);
            return NULL;

        }

        GstAggregatorPad *pad = (GstAggregatorPad *) gst_pad_new_from_template(pad_template, NULL);
        if (!pad) {
            PyErr_SetString(PyExc_RuntimeError, "failed to create pad");
            gst_object_unref((GstObject *) mm);
            return NULL;
        }

        gst_element_add_pad(el, (GstPad *) pad);

    }

    if (!gst_bin_add((GstBin *) (pipeline->pipeline), el)) {

        gst_object_unref((GstObject *) mm);
        PyErr_SetString(PyExc_RuntimeError, "failed to add filter to pipeline");
        return NULL;

    }

    return python_gst_object_wrapper(el);

}
static PyObject *dot_viz(PyObject *self, PyObject *args) {

    PyObject *inp = PyTuple_GetItem(args, 0);
    if (inp == NULL) return NULL;

    PyPipeline *pipeline = py_pipeline_unwrap(inp);
    gchar *data = gst_debug_bin_to_dot_data((GstBin *) (pipeline->pipeline), 
        GST_DEBUG_GRAPH_SHOW_ALL);

    PyObject *res = PyBytes_FromString(data);
    g_free(data);
    return res;

}

static PyObject *set_pipeline_exception_class(PyObject *self, PyObject *args) {

    PyObject *cls = PyTuple_GetItem(args, 0);
    if (!cls) return NULL;

    pipeline_exception_class = cls;
    
    Py_RETURN_NONE;

}

static PyObject *py_stop_pipeline(PyObject *self, PyObject *args) {

    PyObject *pipeline_wrapper = PyTuple_GetItem(args, 0);
    if (!pipeline_wrapper) return NULL;
    PyPipeline *pipeline = py_pipeline_unwrap(pipeline_wrapper);
    if (!pipeline) return NULL;

    stop_pipeline(pipeline->pipeline);

    Py_RETURN_NONE;

}


static PyObject *py_make_caps(PyObject *self, PyObject *args) {

    const char *caps_name;
    PyObject *props_list;

    if (!PyArg_ParseTuple(args, "sO", &caps_name, &props_list)) return NULL;

    GstCaps *res = gst_caps_new_empty_simple(caps_name);
    size_t n_props = PyList_Size(props_list);
    for (size_t i=0; i < n_props; i++) {
        PyObject *pair = PyList_GetItem(props_list, i);

        const char *key;
        PyObject *value;

        if (!PyArg_ParseTuple(pair, "sO", &key, &value)) return NULL;

        GValue gv = G_VALUE_INIT;
        py_object_to_g_value(&gv, value);

        gst_caps_set_value(res, key, &gv);

    }

    return py_wrap_caps(res);

}

PyObject *py_caps_get_prop(PyObject *self, PyObject *args) {

    PyObject *caps_wrapper;
    const char *key;
    PyObject *res = NULL;

    if (!PyArg_ParseTuple(args, "Os", &caps_wrapper, &key)) return NULL;

    GstCaps *caps = py_unwrap_caps(caps_wrapper);
    if (!caps) return NULL;

    size_t n_structures = gst_caps_get_size(caps);
    for (size_t si=0; si < n_structures; si++) {

        GstStructure *st = gst_caps_get_structure(caps, si);
        if (gst_structure_has_field(st, key)) {

            const GValue *value = gst_structure_get_value(st, key);
            res = py_object_from_g_value(value, gst_structure_get_field_type(st, key));
            break;

        }

    }

    if (res == NULL) {
        Py_RETURN_NONE;
    } else {
        return res;
    }



}

static PyObject *py_caps_is_compatible(PyObject *self, PyObject *args) {

    PyObject *py_a;
    PyObject *py_b;

    if (!PyArg_ParseTuple(args, "OO", &py_a, &py_b)) return NULL;

    GstCaps *caps_a = py_unwrap_caps(py_a);
    if (!caps_a) return NULL;

    GstCaps *caps_b = py_unwrap_caps(py_b);
    if (!caps_b) return NULL;

    if (gst_caps_can_intersect(caps_a, caps_b)) {
        Py_RETURN_TRUE;
    } else {
        Py_RETURN_FALSE;
    }

}


static PyObject *py_caps_to_list(PyObject *self, PyObject *args) {

    PyObject *caps_wrapper = PyTuple_GetItem(args, 0);
    if (!caps_wrapper) return NULL;

    GstCaps *caps = py_unwrap_caps(caps_wrapper);
    if (!caps) return NULL;

    PyObject *res = PyList_New(1);
    
    char *media_type = NULL;

    size_t n_structures = gst_caps_get_size(caps);
    for (size_t si=0; si < n_structures; si++) {

        const GstStructure *s = gst_caps_get_structure(caps, si);

        media_type = (char *) gst_structure_get_name(s);
    
        size_t n_fields = gst_structure_n_fields(s);

        for (size_t ki=0; ki < n_fields; ki++) {

            const gchar *k = gst_structure_nth_field_name(s, ki);
            const GValue *v = gst_structure_get_value(s, k);
            GType typ = gst_structure_get_field_type(s, k);

            PyObject *pair = PyTuple_New(2);
            PyTuple_SetItem(pair, 0, PyBytes_FromString(k));
            PyTuple_SetItem(pair, 1, py_object_from_g_value(v, typ));

            PyList_Append(res, pair);

        }

    }

    if (media_type) {
        PyList_SetItem(res, 0, PyBytes_FromString(media_type));
    } else {
        PyList_SetItem(res, 0, Py_None);
    }

    return res;

}

static PyObject *py_caps_union(PyObject *self, PyObject *args) {

    PyObject *wrapper_a = NULL;
    PyObject *wrapper_b = NULL;

    if (!PyArg_ParseTuple(args, "OO", &wrapper_a, &wrapper_b)) return NULL;

    GstCaps *caps_a = py_unwrap_caps(wrapper_a);
    if (!caps_a) return NULL;

    GstCaps *caps_b = py_unwrap_caps(wrapper_b);
    if (!caps_b) return NULL;

    GstCaps *caps_res = gst_caps_new_empty();
    gst_caps_append(caps_res, caps_a);
    gst_caps_append(caps_res, caps_b);

    return py_wrap_caps(caps_res);

}

PyObject *py_get_static_pad_caps(PyObject *self, PyObject *args) {

    PyObject *el_wrapper;
    const char *pad_name;
    PyObject *ret = NULL;
    if (!PyArg_ParseTuple(args, "Os", &el_wrapper, &pad_name)) return NULL;

    GstElement *el = NULL;
    GstPad *pad = NULL;
    GstCaps *caps = NULL;

    el = python_gst_object_unwrap(el_wrapper);
    if (!el) goto end;

    pad = gst_element_get_static_pad(el, pad_name);
    if (!pad) goto end;

    caps = gst_pad_get_current_caps(pad);
    if (!caps) goto end;

    ret = py_wrap_caps(caps);

end:
    if (pad) gst_object_unref((GstObject *) pad);
    if (caps) gst_caps_unref(caps);
    if (ret) {
        return ret;
    } else {
        Py_RETURN_NONE;
    }

}

static gboolean cutlist_timer_callback(gpointer udata) {

    gboolean ret = TRUE;

    BEGIN_PYTHON_THREAD

    PyObject *pipeline_wrapper = (PyObject *) udata;
    PyPipeline *pipeline = py_pipeline_unwrap(pipeline_wrapper);

    if (pipeline->cutlist == NULL) {
        ret = FALSE;
        goto end;
    }
    
    gint64 current = -1;

    if (!gst_element_query_position(
        (GstElement *) (pipeline->pipeline), GST_FORMAT_TIME, &current)) {
        goto end;
    }


    size_t cutlist_size = PyList_Size(pipeline->cutlist);

    if (pipeline->cutlist_idx >= cutlist_size) {
        // end of stream
        stop_pipeline(pipeline->pipeline);
        ret = FALSE;
        goto end;
    }

    PyObject *current_range = PyList_GetItem(pipeline->cutlist, pipeline->cutlist_idx);
    int64_t range_start;
    int64_t range_end;
    

    if (!PyArg_ParseTuple(current_range, "kk", &range_start, &range_end)) {
        pipeline->cutlist_idx++;
        goto end;
    }

    if (current < range_start) {
        gst_element_seek((GstElement *) (pipeline->pipeline), 
            1.0, GST_FORMAT_TIME, GST_SEEK_FLAG_FLUSH,
            GST_SEEK_TYPE_SET, range_start, 
            GST_SEEK_TYPE_NONE, GST_CLOCK_TIME_NONE);
        goto end;
    }
    
    if (current > range_end) {

        // next cut

        pipeline->cutlist_idx++;
        if (pipeline->cutlist_idx >= cutlist_size) {
            stop_pipeline(pipeline->pipeline);
            ret = FALSE;
            goto end;
        }

        current_range = PyList_GetItem(pipeline->cutlist, pipeline->cutlist_idx);
        
        if (!PyArg_ParseTuple(current_range, "kk", &range_start, &range_end)) {
            pipeline->cutlist_idx++;
            goto end;
        }


        gst_element_seek((GstElement *) (pipeline->pipeline), 
            1.0, GST_FORMAT_TIME, GST_SEEK_FLAG_FLUSH,
            GST_SEEK_TYPE_SET, range_start, 
            GST_SEEK_TYPE_NONE, GST_CLOCK_TIME_NONE);


    }

end:
    END_PYTHON_THREAD
    return ret;

}

static PyObject *set_cutlist(PyObject *self, PyObject *args) {

    PyObject *pipeline_wrapper;
    PyObject *cutlist;

    if (!PyArg_ParseTuple(args, "OO", &pipeline_wrapper, &cutlist)) return NULL;

    PyPipeline *pipeline = py_pipeline_unwrap(pipeline_wrapper);
    if (!pipeline) return NULL;

    if (pipeline->cutlist) {
        PyErr_SetString(PyExc_RuntimeError, "cutlist already set");
        return NULL;
    }

    Py_INCREF(cutlist);
    Py_INCREF(pipeline_wrapper);

    pipeline->cutlist = cutlist;
    pipeline->cutlist_idx = 0;
    pipeline->cutlist_timer_handle = g_timeout_add(10, cutlist_timer_callback, pipeline_wrapper);

    Py_RETURN_NONE;

}

static void filter_probe_destroy(gpointer data) {
    BEGIN_PYTHON_THREAD;
    Py_DECREF((PyObject *) data);
    END_PYTHON_THREAD;
}

static GstPadProbeReturn filter_probe_callback(GstPad *pad, GstPadProbeInfo *info, gpointer up) {

    BEGIN_PYTHON_THREAD;
    GstPadProbeReturn ret = GST_PAD_PROBE_OK;

    PyObject *callback = (PyObject *) up;

    GstBuffer *buf = gst_pad_probe_info_get_buffer(info);
    if (!buf) goto end;

    PyObject *cb_res = PyObject_CallFunction(callback, "kkk", buf->pts, buf->duration, buf->offset);
    if (cb_res == Py_False) {
        ret = GST_PAD_PROBE_DROP;
    }

end:
    END_PYTHON_THREAD;
    return ret;

}

static PyObject *add_meta_filter(PyObject *self, PyObject *args) {

    PyObject *upstream_wrapper;
    PyObject *callback;

    if (!PyArg_ParseTuple(args, "OO", &upstream_wrapper, &callback)) return NULL;

    GstElement *upstream = python_gst_object_unwrap(upstream_wrapper);
    if (!upstream) return NULL;

    GstPad *target_pad = gst_element_get_static_pad(upstream, "src");

    Py_INCREF(callback);
    gst_pad_add_probe(target_pad, 
        GST_PAD_PROBE_TYPE_BUFFER,
        filter_probe_callback, callback,
        filter_probe_destroy);

    Py_RETURN_NONE;
}

static void py_decref_notify(gpointer data, GClosure *closure) {

    Py_DECREF((PyObject *) data);

}

static GstFlowReturn callback_iter_handler(GstElement *appsink, gpointer arg) {
    GstSample *sample = gst_app_sink_pull_sample((GstAppSink *) appsink);
    GstBuffer *buf = gst_sample_get_buffer(sample);
    GstCaps *caps = gst_sample_get_caps(sample); 

    BEGIN_PYTHON_THREAD;
    GstFlowReturn ret = GST_FLOW_OK;
    
    PyObject *callback = (PyObject *) arg;
    PyObject *pybuf = gst_buffer_to_python(buf);
    PyObject *pycaps = py_wrap_caps(caps);

    if (!PyObject_CallFunction(callback, "OOkk", 
        pybuf,
        pycaps,
        buf->pts, buf->duration)) {

        ret = GST_FLOW_ERROR;

    }

    Py_DECREF(pybuf);
    Py_DECREF(pycaps);

    END_PYTHON_THREAD;
    gst_sample_unref(sample);
    return ret;

}

static void callback_eos_handler(GstElement *self, gpointer p) {
    BEGIN_PYTHON_THREAD;
    Py_DECREF((PyObject *) p);
    END_PYTHON_THREAD;
}

static PyObject *make_callback_iter_el(PyObject *self, PyObject *args) {

    PyObject *pipeline_wrapper;
    PyObject *callback;

    if (!PyArg_ParseTuple(args, "OO", &pipeline_wrapper, &callback)) return NULL;

    PyPipeline *pipeline = py_pipeline_unwrap(pipeline_wrapper);
    if(!pipeline) return NULL;

    GstElement *appsink = make_appsink(pipeline);
    if (!appsink) return NULL;

    g_object_set((GObject *) appsink, 
        "emit-signals", TRUE, 
        "sync", FALSE,
        "max-buffers", 2,
        NULL);

    Py_INCREF(callback);
    g_signal_connect((GObject *) appsink, 
        "new-sample", G_CALLBACK(callback_iter_handler), callback);
    g_signal_connect((GObject *) appsink, 
        "eos", G_CALLBACK(callback_eos_handler), callback);

    return python_gst_object_wrapper(appsink);

}

static PyMethodDef py_entrypoint_methods[] = {

    {"make_pipeline", make_pipeline, METH_VARARGS,
        "Construct an empty gstreamer pipeline"},
    {"construct_element", construct_element, METH_VARARGS,
        "Construct an element with a given name and a given set of properties"},
    {"remove_element", remove_element, METH_VARARGS,
        "Remove the given element from the given pipeline"},
    {"link_elements", link_elements, METH_VARARGS,
        "Link two elements together"},
    {"run_pipeline", run_pipeline, METH_VARARGS,
        "Run the given pipeline. Will block until the pipeline finishes (EOS or and error)"},
    {"make_capsfilter", make_capsfilter, METH_VARARGS,
        "Constructs a capsfilter element with the given type and parameters"},
    {"dot_viz", dot_viz, METH_VARARGS,
        "Return a graphviz dot representation of the given pipeline"},
    {"set_exception_class", set_pipeline_exception_class, METH_VARARGS,
        "Sets the class that pipeline exceptions are constructed from"},
    {"stop_pipeline", py_stop_pipeline, METH_VARARGS,
        "Stop the given pipeline"},

    {"make_caps", py_make_caps, METH_VARARGS, "make caps"},
    {"caps_get_prop", py_caps_get_prop, METH_VARARGS, "get prop from caps"},
    {"caps_is_compatible", py_caps_is_compatible, METH_VARARGS, "are two capses compatible"},
    {"caps_to_list", py_caps_to_list, METH_VARARGS, "list of props of caps"},
    {"caps_union", py_caps_union, METH_VARARGS, "returns the union of caps a and b"},

    {"add_meta_filter", add_meta_filter, METH_VARARGS,
        "adds a probe to the pad between the two given elements that drops buffers when the python function returns false"},

    {"get_static_pad_caps", py_get_static_pad_caps, METH_VARARGS, 
        "returns caps of the named pad of the given elem"},
    {"get_element_name", get_element_name, METH_VARARGS, "get element name"},

    {"set_cutlist", set_cutlist, METH_VARARGS,
        "set cutlist"},
    
    {"make_iterator_source", make_iterator_source, METH_VARARGS,
        "Construct a source element that consumes frames from a given iterator"},
    {"make_callback_sink", make_callback_sink, METH_VARARGS,
        "Construct a sink element that calls a given callback with new buffers"},
    {"make_callback_transform", make_callback_transform, METH_VARARGS,
        "Construct a transform element that maps the given callback over the pipeline"},
    {"appsink_pull_buffer", appsink_pull_buffer, METH_VARARGS,
        "Pull a buffer from the internal queue of the given appsink element (blocks)"},
    {"make_callback_iter_el", make_callback_iter_el, METH_VARARGS, "make callback appsink"},
    {"make_multi_map", make_multi_map, METH_VARARGS, "make multimap"},

    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef py_entrypoint = {
    .m_methods = py_entrypoint_methods,
};

PyMODINIT_FUNC PyInit_c_candyfloss(void) {
    nil_tuple = PyTuple_New(0);
    Py_INCREF(nil_tuple);
    start_gevent_thread();
    gst_init(NULL, NULL);
    return PyModuleDef_Init(&py_entrypoint);
}
