import os
from .engine import UDTP_Engine
from udtp_utils.logger import get_udtp_logger

log = get_udtp_logger()

class UDTP_FileCompiler:
    def compile_file(self, src, out):
        log.info(f"Компиляция {src} в формат UDTP...")
        if not os.path.exists(src): return
        
        with open(src, 'rb') as f_in, open(out, 'wb') as f_out:
            chunk_id = 0
            while chunk := f_in.read(2048):
                packet = UDTP_Engine.pack(chunk, seq=chunk_id)
                f_out.write(packet)
                chunk_id += 1
        log.info(f"✅ Готово! Создано {chunk_id} пакетов.")