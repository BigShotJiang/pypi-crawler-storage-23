import struct
import binascii
import zlib
from udtp_security.crypto import UDTP_Crypto

class UDTP_Engine:
    # [Sign:4b][Flags:1b][Seq:4I][Ack:4I][CRC:4I] = 17 байт заголовка
    HEADER_FORMAT = "!4sBIII" 
    SIGN = b"UDTP"

    @staticmethod
    def pack(data, seq=0, flags=1, ack=0):
        # 1. Сжатие
        compressed = zlib.compress(data)
        # 2. Шифрование (XOR)
        encrypted = UDTP_Crypto.obfuscate(compressed)
        
        # 3. Сборка заголовка (CRC пока 0)
        header = struct.pack(UDTP_Engine.HEADER_FORMAT, UDTP_Engine.SIGN, flags, seq, ack, 0)
        # 4. Расчет CRC32
        crc = binascii.crc32(header + encrypted) & 0xFFFFFFFF
        
        # 5. Финальный пакет
        final_header = struct.pack(UDTP_Engine.HEADER_FORMAT, UDTP_Engine.SIGN, flags, seq, ack, crc)
        return final_header + encrypted

    @staticmethod
    def unpack(raw_packet):
        """Метод расшифровки и распаковки пакета"""
        h_size = struct.calcsize(UDTP_Engine.HEADER_FORMAT)
        if len(raw_packet) < h_size:
            raise ValueError("Пакет слишком мал!")

        # 1. Читаем заголовок
        h = struct.unpack(UDTP_Engine.HEADER_FORMAT, raw_packet[:h_size])
        sign, flags, seq, ack, received_crc = h
        
        if sign != UDTP_Engine.SIGN:
            raise ValueError("Неверная сигнатура UDTP!")

        # 2. Извлекаем данные
        encrypted_data = raw_packet[h_size:]

        # 3. Проверка целостности (CRC)
        header_for_check = struct.pack(UDTP_Engine.HEADER_FORMAT, sign, flags, seq, ack, 0)
        actual_crc = binascii.crc32(header_for_check + encrypted_data) & 0xFFFFFFFF
        
        if received_crc != actual_crc:
            raise ValueError(f"Ошибка CRC! Данные повреждены. (Ожидалось {received_crc}, получено {actual_crc})")

        # 4. Дешифровка (XOR обратно)
        compressed_data = UDTP_Crypto.obfuscate(encrypted_data)
        
        # 5. Распаковка (Decompress)
        try:
            original_data = zlib.decompress(compressed_data)
        except Exception as e:
            raise ValueError(f"Ошибка декомпрессии: {e}")

        return {
            "flags": flags,
            "seq": seq,
            "ack": ack,
            "data": original_data
        }
