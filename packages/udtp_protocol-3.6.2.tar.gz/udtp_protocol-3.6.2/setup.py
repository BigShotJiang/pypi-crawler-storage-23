from setuptools import setup, find_packages

setup(
    name='udtp_protocol',
    version='3.6.2',
    description='Universal Data Transfer Protocol Stack, created on TAFTP. With new functions based on TCP, TAFTP.',
    author='HioDev',
    packages=find_packages(),
    install_requires=[],
    entry_points={
        'console_scripts': [
            'udtp-compile=udtp_core.compiler:main_cli',
        ],
    },
    classifiers=[
        'Programming Language :: Python :: 3',
        'Topic :: System :: Networking',
    ],
)