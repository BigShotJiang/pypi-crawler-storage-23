

total_episode = 1155
total_episoe_di_page = 30

# berarti 1155 % 30
hasil = 1155 / 30

print(hasil)


https://animeinweb.com/anime/6218


Accept:
*/*
Accept-Encoding:
identity;q=1, *;q=0
Accept-Language:
en-US,en;q=0.8
Connection:
keep-alive
Host: storages.animein.net
If-Range:
"ac8257b56a4ae7eceb2160cd7eab94ee"
Range:
bytes=48436-80543743
Referer:https://animeinweb.com/
sec-ch-ua:"Not(A:Brand";v="8", "Chromium";v="144", "Brave";v="144"
