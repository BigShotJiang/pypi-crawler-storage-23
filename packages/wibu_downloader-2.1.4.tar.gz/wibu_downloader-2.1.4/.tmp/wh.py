#!/usr/bin/env python3

from yt_dlp.utils import str_or_none
# g = 'Horror,School,Supernatural'
#
# g2 = ''.join(g)
#
# print(g2echo)

# ep = "https: //xyz-api.animein.net//assets_xyz/images/movie/poster/cb4a9f2820923010a335b641fd07aef8.jpg"
# print(type(ep))
ep = None
print(str_or_none("".join(ep)))
