from __future__ import annotations

from typing import Any, Dict


def _convert(node: Dict[str, Any]) -> Dict[str, Any]:
    out = {
        "node_id": node.get("node_id"),
        "title": node.get("title", ""),
        "summary": node.get("summary", ""),
        "start_index": node.get("start_index"),
        "end_index": node.get("end_index"),
        "text": node.get("full_text", ""),
    }
    children = node.get("children", [])
    if children:
        out["nodes"] = [_convert(c) for c in children]
    return out


def navexa_to_legacy_compat(document: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "doc_id": document.get("doc_id"),
        "doc_name": document.get("doc_name"),
        "structure": [_convert(n) for n in document.get("structure", [])],
    }
