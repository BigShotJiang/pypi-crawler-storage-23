from __future__ import annotations

from typing import Dict, Tuple


def extract_transcript_text_content(pdf_path: str) -> Tuple[Dict[int, str], int]:
    try:
        from PyPDF2 import PdfReader  # type: ignore
    except Exception as exc:
        raise RuntimeError(
            "PyPDF2 is required for transcript simple parsing. Install it in your environment."
        ) from exc

    reader = PdfReader(pdf_path)
    page_text_by_page: Dict[int, str] = {}
    for idx, page in enumerate(reader.pages, start=1):
        text = page.extract_text() or ""
        page_text_by_page[idx] = text.strip()

    total_pages = len(reader.pages)
    if total_pages <= 0:
        raise RuntimeError("Transcript parser could not read pages from PDF.")
    if not any((txt or "").strip() for txt in page_text_by_page.values()):
        raise RuntimeError("Transcript parser extracted no readable text from PDF.")

    return page_text_by_page, total_pages
