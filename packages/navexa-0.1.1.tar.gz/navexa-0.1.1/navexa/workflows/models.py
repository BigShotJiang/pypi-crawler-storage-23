from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class IndexResult:
    tree_navexa: Dict[str, Any]
    validation_report: Dict[str, Any]
    tree_legacy_compat: Dict[str, Any]
    meta: Dict[str, Any]


@dataclass
class SaveResult:
    out_dir: str
    paths: Dict[str, str]


@dataclass
class TreeReasoningResult:
    thinking: str
    node_list: List[str]
    raw_response: str
    used_prompt: Optional[str] = None
    parsed_json: Dict[str, Any] = field(default_factory=dict)


@dataclass
class ContextBundle:
    node_list: List[str]
    dropped_node_list: List[str]
    missing_node_list: List[str]
    text: str
    text_mode: str
    node_records: List[Dict[str, Any]]


@dataclass
class AnswerResult:
    answer: str
    raw_response: str
    used_prompt: Optional[str] = None


@dataclass
class RAGResult:
    tree: Dict[str, Any]
    tree_view: Dict[str, Any]
    node_index: Dict[str, Dict[str, Any]]
    reasoning: TreeReasoningResult
    context: ContextBundle
    answer: AnswerResult
    cost_before: Dict[str, Any]
    cost_after: Dict[str, Any]
    cost_delta: Dict[str, Any]
