from __future__ import annotations

import os
import sys
from pathlib import Path

os.environ["MKL_THREADING_LAYER"] = "GNU"
os.environ["OMP_NUM_THREADS"] = "1"
os.environ["MKL_SERVICE_FORCE_INTEL"] = "1"
os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

if __package__ is None or __package__ == "":
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from navexa.pipeline.index_pdf import run_cli
else:
    from ..pipeline.index_pdf import run_cli


if __name__ == "__main__":
    run_cli()
