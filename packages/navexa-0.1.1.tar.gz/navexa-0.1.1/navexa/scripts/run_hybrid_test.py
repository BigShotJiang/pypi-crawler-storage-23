from __future__ import annotations

# Hybrid entrypoint is intentionally the same single pipeline logic.

from .run_navexa_test import run_cli


def main() -> None:
    run_cli()


if __name__ == "__main__":
    main()
