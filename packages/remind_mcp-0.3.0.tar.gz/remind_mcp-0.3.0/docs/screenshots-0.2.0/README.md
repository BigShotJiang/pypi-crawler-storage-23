# Screenshots - Version 0.2.0

This directory contains screenshots showcasing the UI added in Remind version 0.2.0.

## Screenshots

![Screenshot 01](01.png)
*Concepts view*

![Screenshot 02](02.png)
*Concepts view dark mode*

![Screenshot 03](03.png)
*Entities view*

![Screenshot 04](04.png)
*Concept map*

![Screenshot 05](05.png)
*Entity graph*

![Screenshot 06](06.png)
*Episodes view*
