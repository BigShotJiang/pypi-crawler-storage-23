var $u=Object.defineProperty;var Mo=e=>{throw TypeError(e)};var bu=(e,t,n)=>t in e?$u(e,t,{enumerable:!0,configurable:!0,writable:!0,value:n}):e[t]=n;var Ln=(e,t,n)=>bu(e,typeof t!="symbol"?t+"":t,n),ca=(e,t,n)=>t.has(e)||Mo("Cannot "+n);var S=(e,t,n)=>(ca(e,t,"read from private field"),n?n.call(e):t.get(e)),et=(e,t,n)=>t.has(e)?Mo("Cannot add the same private member more than once"):t instanceof WeakSet?t.add(e):t.set(e,n),Ne=(e,t,n,r)=>(ca(e,t,"write to private field"),r?r.call(e,n):t.set(e,n),n),At=(e,t,n)=>(ca(e,t,"access private method"),n);(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const i of document.querySelectorAll('link[rel="modulepreload"]'))r(i);new MutationObserver(i=>{for(const s of i)if(s.type==="childList")for(const a of s.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&r(a)}).observe(document,{childList:!0,subtree:!0});function n(i){const s={};return i.integrity&&(s.integrity=i.integrity),i.referrerPolicy&&(s.referrerPolicy=i.referrerPolicy),i.crossOrigin==="use-credentials"?s.credentials="include":i.crossOrigin==="anonymous"?s.credentials="omit":s.credentials="same-origin",s}function r(i){if(i.ep)return;i.ep=!0;const s=n(i);fetch(i.href,s)}})();const ku="5";var kl;typeof window<"u"&&((kl=window.__svelte??(window.__svelte={})).v??(kl.v=new Set)).add(ku);let xi=!1,Eu=!1;function zu(){xi=!0}zu();const Nu=1,Mu=2,El=4,Au=8,Su=16,Tu=1,Cu=2,zl=4,Pu=8,Du=16,Lu=1,Ru=2,Bt=Symbol(),Iu="http://www.w3.org/1999/xhtml",Ou="http://www.w3.org/2000/svg",Fu="@attach",Ma=!1;var eo=Array.isArray,qu=Array.prototype.indexOf,Ys=Array.from,Nl=Object.defineProperty,yr=Object.getOwnPropertyDescriptor,Ml=Object.getOwnPropertyDescriptors,Bu=Object.prototype,Vu=Array.prototype,to=Object.getPrototypeOf,Ao=Object.isExtensible;function Ni(e){return typeof e=="function"}const xr=()=>{};function Hu(e){return e()}function Ss(e){for(var t=0;t<e.length;t++)e[t]()}function Al(){var e,t,n=new Promise((r,i)=>{e=r,t=i});return{promise:n,resolve:e,reject:t}}function Vi(e,t){if(Array.isArray(e))return e;if(!(Symbol.iterator in e))return Array.from(e);const n=[];for(const r of e)if(n.push(r),n.length===t)break;return n}const Xt=2,no=4,Xs=8,Sl=1<<24,ir=16,sr=32,Xr=64,js=128,Sn=512,Vt=1024,vn=2048,Tn=4096,_n=8192,nr=16384,ro=32768,br=65536,So=1<<17,Tl=1<<18,wi=1<<19,Cl=1<<20,Jn=1<<25,Vr=32768,Aa=1<<21,io=1<<22,wr=1<<23,Vn=Symbol("$state"),Pl=Symbol("legacy props"),Uu=Symbol(""),ri=new class extends Error{constructor(){super(...arguments);Ln(this,"name","StaleReactionError");Ln(this,"message","The reaction that called `getAbortSignal()` was re-run or destroyed")}};function Yu(e){throw new Error("https://svelte.dev/e/lifecycle_outside_component")}function Xu(){throw new Error("https://svelte.dev/e/async_derived_orphan")}function ju(e){throw new Error("https://svelte.dev/e/effect_in_teardown")}function Gu(){throw new Error("https://svelte.dev/e/effect_in_unowned_derived")}function Wu(e){throw new Error("https://svelte.dev/e/effect_orphan")}function Ku(){throw new Error("https://svelte.dev/e/effect_update_depth_exceeded")}function Zu(e){throw new Error("https://svelte.dev/e/props_invalid_value")}function Qu(){throw new Error("https://svelte.dev/e/state_descriptors_fixed")}function Ju(){throw new Error("https://svelte.dev/e/state_prototype_fixed")}function ef(){throw new Error("https://svelte.dev/e/state_unsafe_mutation")}function tf(){throw new Error("https://svelte.dev/e/svelte_boundary_reset_onerror")}function nf(){console.warn("https://svelte.dev/e/select_multiple_invalid_value")}function rf(){console.warn("https://svelte.dev/e/svelte_boundary_reset_noop")}function Dl(e){return e===this.v}function Ll(e,t){return e!=e?t==t:e!==t||e!==null&&typeof e=="object"||typeof e=="function"}function Rl(e){return!Ll(e,this.v)}let wt=null;function vi(e){wt=e}function Xn(e,t=!1,n){wt={p:wt,i:!1,c:null,e:null,s:e,x:null,l:xi&&!t?{s:null,u:null,$:[]}:null}}function jn(e){var t=wt,n=t.e;if(n!==null){t.e=null;for(var r of n)tc(r)}return t.i=!0,wt=t.p,{}}function rs(){return!xi||wt!==null&&wt.l===null}let Ar=[];function Il(){var e=Ar;Ar=[],Ss(e)}function jr(e){if(Ar.length===0&&!Fi){var t=Ar;queueMicrotask(()=>{t===Ar&&Il()})}Ar.push(e)}function sf(){for(;Ar.length>0;)Il()}function Ol(e){var t=tt;if(t===null)return je.f|=wr,e;if(t.f&ro)di(e,t);else{if(!(t.f&js))throw e;t.b.error(e)}}function di(e,t){for(;t!==null;){if(t.f&js)try{t.b.error(e);return}catch(n){e=n}t=t.parent}throw e}const vs=new Set;let Ae=null,Oi=null,Ct=null,bn=[],Gs=null,Sa=!1,Fi=!1;var li,ci,Tr,Cr,es,ui,fi,Ht,Ta,Ci,Ca,Fl,ql;const Vs=class Vs{constructor(){et(this,Ht);Ln(this,"committed",!1);Ln(this,"current",new Map);Ln(this,"previous",new Map);et(this,li,new Set);et(this,ci,new Set);et(this,Tr,0);et(this,Cr,0);et(this,es,null);et(this,ui,new Set);et(this,fi,new Set);Ln(this,"skipped_effects",new Set);Ln(this,"is_fork",!1)}is_deferred(){return this.is_fork||S(this,Cr)>0}process(t){var r;bn=[],Oi=null,this.apply();var n={parent:null,effect:null,effects:[],render_effects:[]};for(const i of t)At(this,Ht,Ta).call(this,i,n);this.is_fork||At(this,Ht,Fl).call(this),this.is_deferred()?(At(this,Ht,Ci).call(this,n.effects),At(this,Ht,Ci).call(this,n.render_effects)):(Oi=this,Ae=null,To(n.render_effects),To(n.effects),Oi=null,(r=S(this,es))==null||r.resolve()),Ct=null}capture(t,n){this.previous.has(t)||this.previous.set(t,n),t.f&wr||(this.current.set(t,t.v),Ct==null||Ct.set(t,t.v))}activate(){Ae=this,this.apply()}deactivate(){Ae===this&&(Ae=null,Ct=null)}flush(){if(this.activate(),bn.length>0){if(Bl(),Ae!==null&&Ae!==this)return}else S(this,Tr)===0&&this.process([]);this.deactivate()}discard(){for(const t of S(this,ci))t(this);S(this,ci).clear()}increment(t){Ne(this,Tr,S(this,Tr)+1),t&&Ne(this,Cr,S(this,Cr)+1)}decrement(t){Ne(this,Tr,S(this,Tr)-1),t&&Ne(this,Cr,S(this,Cr)-1),this.revive()}revive(){for(const t of S(this,ui))S(this,fi).delete(t),Yt(t,vn),Hr(t);for(const t of S(this,fi))Yt(t,Tn),Hr(t);this.flush()}oncommit(t){S(this,li).add(t)}ondiscard(t){S(this,ci).add(t)}settled(){return(S(this,es)??Ne(this,es,Al())).promise}static ensure(){if(Ae===null){const t=Ae=new Vs;vs.add(Ae),Fi||Vs.enqueue(()=>{Ae===t&&t.flush()})}return Ae}static enqueue(t){jr(t)}apply(){}};li=new WeakMap,ci=new WeakMap,Tr=new WeakMap,Cr=new WeakMap,es=new WeakMap,ui=new WeakMap,fi=new WeakMap,Ht=new WeakSet,Ta=function(t,n){var f;t.f^=Vt;for(var r=t.first;r!==null;){var i=r.f,s=(i&(sr|Xr))!==0,a=s&&(i&Vt)!==0,l=a||(i&_n)!==0||this.skipped_effects.has(r);if(r.f&js&&((f=r.b)!=null&&f.is_pending())&&(n={parent:n,effect:r,effects:[],render_effects:[]}),!l&&r.fn!==null){s?r.f^=Vt:i&no?n.effects.push(r):$i(r)&&(r.f&ir&&S(this,ui).add(r),_i(r));var u=r.first;if(u!==null){r=u;continue}}var c=r.parent;for(r=r.next;r===null&&c!==null;)c===n.effect&&(At(this,Ht,Ci).call(this,n.effects),At(this,Ht,Ci).call(this,n.render_effects),n=n.parent),r=c.next,c=c.parent}},Ci=function(t){for(const n of t)n.f&vn?S(this,ui).add(n):n.f&Tn&&S(this,fi).add(n),At(this,Ht,Ca).call(this,n.deps),Yt(n,Vt)},Ca=function(t){if(t!==null)for(const n of t)!(n.f&Xt)||!(n.f&Vr)||(n.f^=Vr,At(this,Ht,Ca).call(this,n.deps))},Fl=function(){if(S(this,Cr)===0){for(const t of S(this,li))t();S(this,li).clear()}S(this,Tr)===0&&At(this,Ht,ql).call(this)},ql=function(){var s;if(vs.size>1){this.previous.clear();var t=Ct,n=!0,r={parent:null,effect:null,effects:[],render_effects:[]};for(const a of vs){if(a===this){n=!1;continue}const l=[];for(const[c,f]of this.current){if(a.current.has(c))if(n&&f!==a.current.get(c))a.current.set(c,f);else continue;l.push(c)}if(l.length===0)continue;const u=[...a.current.keys()].filter(c=>!this.current.has(c));if(u.length>0){var i=bn;bn=[];const c=new Set,f=new Map;for(const g of l)Vl(g,u,c,f);if(bn.length>0){Ae=a,a.apply();for(const g of bn)At(s=a,Ht,Ta).call(s,g,r);a.deactivate()}bn=i}}Ae=null,Ct=t}this.committed=!0,vs.delete(this)};let er=Vs;function af(e){var t=Fi;Fi=!0;try{for(var n;;){if(sf(),bn.length===0&&(Ae==null||Ae.flush(),bn.length===0))return Gs=null,n;Bl()}}finally{Fi=t}}function Bl(){var e=Or;Sa=!0;var t=null;try{var n=0;for(Ps(!0);bn.length>0;){var r=er.ensure();if(n++>1e3){var i,s;of()}r.process(bn),$r.clear()}}finally{Sa=!1,Ps(e),Gs=null}}function of(){try{Ku()}catch(e){di(e,Gs)}}let zn=null;function To(e){var t=e.length;if(t!==0){for(var n=0;n<t;){var r=e[n++];if(!(r.f&(nr|_n))&&$i(r)&&(zn=new Set,_i(r),r.deps===null&&r.first===null&&r.nodes===null&&(r.teardown===null&&r.ac===null?sc(r):r.fn=null),(zn==null?void 0:zn.size)>0)){$r.clear();for(const i of zn){if(i.f&(nr|_n))continue;const s=[i];let a=i.parent;for(;a!==null;)zn.has(a)&&(zn.delete(a),s.push(a)),a=a.parent;for(let l=s.length-1;l>=0;l--){const u=s[l];u.f&(nr|_n)||_i(u)}}zn.clear()}}zn=null}}function Vl(e,t,n,r){if(!n.has(e)&&(n.add(e),e.reactions!==null))for(const i of e.reactions){const s=i.f;s&Xt?Vl(i,t,n,r):s&(io|ir)&&!(s&vn)&&Hl(i,t,r)&&(Yt(i,vn),Hr(i))}}function Hl(e,t,n){const r=n.get(e);if(r!==void 0)return r;if(e.deps!==null)for(const i of e.deps){if(t.includes(i))return!0;if(i.f&Xt&&Hl(i,t,n))return n.set(i,!0),!0}return n.set(e,!1),!1}function Hr(e){for(var t=Gs=e;t.parent!==null;){t=t.parent;var n=t.f;if(Sa&&t===tt&&n&ir&&!(n&Tl))return;if(n&(Xr|sr)){if(!(n&Vt))return;t.f^=Vt}}bn.push(t)}function lf(e){let t=0,n=kr(0),r;return()=>{Ui()&&(o(n),os(()=>(t===0&&(r=x(()=>e(()=>qi(n)))),t+=1,()=>{jr(()=>{t-=1,t===0&&(r==null||r(),r=void 0,qi(n))})})))}}var cf=br|wi|js;function uf(e,t,n){new ff(e,t,n)}var xn,wn,Ja,Rn,Pr,In,$n,ln,On,Qn,pr,Dr,_r,Lr,gr,Hs,Rt,vf,df,Pa,ys,xs,Da;class ff{constructor(t,n,r){et(this,Rt);Ln(this,"parent");et(this,xn,!1);et(this,wn);et(this,Ja,null);et(this,Rn);et(this,Pr);et(this,In);et(this,$n,null);et(this,ln,null);et(this,On,null);et(this,Qn,null);et(this,pr,null);et(this,Dr,0);et(this,_r,0);et(this,Lr,!1);et(this,gr,null);et(this,Hs,lf(()=>(Ne(this,gr,kr(S(this,Dr))),()=>{Ne(this,gr,null)})));Ne(this,wn,t),Ne(this,Rn,n),Ne(this,Pr,r),this.parent=tt.b,Ne(this,xn,!!S(this,Rn).pending),Ne(this,In,ls(()=>{tt.b=this;{var i=At(this,Rt,Pa).call(this);try{Ne(this,$n,cn(()=>r(i)))}catch(s){this.error(s)}S(this,_r)>0?At(this,Rt,xs).call(this):Ne(this,xn,!1)}return()=>{var s;(s=S(this,pr))==null||s.remove()}},cf))}is_pending(){return S(this,xn)||!!this.parent&&this.parent.is_pending()}has_pending_snippet(){return!!S(this,Rn).pending}update_pending_count(t){At(this,Rt,Da).call(this,t),Ne(this,Dr,S(this,Dr)+t),S(this,gr)&&Ur(S(this,gr),S(this,Dr))}get_effect_pending(){return S(this,Hs).call(this),o(S(this,gr))}error(t){var n=S(this,Rn).onerror;let r=S(this,Rn).failed;if(S(this,Lr)||!n&&!r)throw t;S(this,$n)&&(Ut(S(this,$n)),Ne(this,$n,null)),S(this,ln)&&(Ut(S(this,ln)),Ne(this,ln,null)),S(this,On)&&(Ut(S(this,On)),Ne(this,On,null));var i=!1,s=!1;const a=()=>{if(i){rf();return}i=!0,s&&tf(),er.ensure(),Ne(this,Dr,0),S(this,On)!==null&&Ir(S(this,On),()=>{Ne(this,On,null)}),Ne(this,xn,this.has_pending_snippet()),Ne(this,$n,At(this,Rt,ys).call(this,()=>(Ne(this,Lr,!1),cn(()=>S(this,Pr).call(this,S(this,wn)))))),S(this,_r)>0?At(this,Rt,xs).call(this):Ne(this,xn,!1)};var l=je;try{un(null),s=!0,n==null||n(t,a),s=!1}catch(u){di(u,S(this,In)&&S(this,In).parent)}finally{un(l)}r&&jr(()=>{Ne(this,On,At(this,Rt,ys).call(this,()=>{er.ensure(),Ne(this,Lr,!0);try{return cn(()=>{r(S(this,wn),()=>t,()=>a)})}catch(u){return di(u,S(this,In).parent),null}finally{Ne(this,Lr,!1)}}))})}}xn=new WeakMap,wn=new WeakMap,Ja=new WeakMap,Rn=new WeakMap,Pr=new WeakMap,In=new WeakMap,$n=new WeakMap,ln=new WeakMap,On=new WeakMap,Qn=new WeakMap,pr=new WeakMap,Dr=new WeakMap,_r=new WeakMap,Lr=new WeakMap,gr=new WeakMap,Hs=new WeakMap,Rt=new WeakSet,vf=function(){try{Ne(this,$n,cn(()=>S(this,Pr).call(this,S(this,wn))))}catch(t){this.error(t)}Ne(this,xn,!1)},df=function(){const t=S(this,Rn).pending;t&&(Ne(this,ln,cn(()=>t(S(this,wn)))),er.enqueue(()=>{var n=At(this,Rt,Pa).call(this);Ne(this,$n,At(this,Rt,ys).call(this,()=>(er.ensure(),cn(()=>S(this,Pr).call(this,n))))),S(this,_r)>0?At(this,Rt,xs).call(this):(Ir(S(this,ln),()=>{Ne(this,ln,null)}),Ne(this,xn,!1))}))},Pa=function(){var t=S(this,wn);return S(this,xn)&&(Ne(this,pr,Hn()),S(this,wn).before(S(this,pr)),t=S(this,pr)),t},ys=function(t){var n=tt,r=je,i=wt;kn(S(this,In)),un(S(this,In)),vi(S(this,In).ctx);try{return t()}catch(s){return Ol(s),null}finally{kn(n),un(r),vi(i)}},xs=function(){const t=S(this,Rn).pending;S(this,$n)!==null&&(Ne(this,Qn,document.createDocumentFragment()),S(this,Qn).append(S(this,pr)),lc(S(this,$n),S(this,Qn))),S(this,ln)===null&&Ne(this,ln,cn(()=>t(S(this,wn))))},Da=function(t){var n;if(!this.has_pending_snippet()){this.parent&&At(n=this.parent,Rt,Da).call(n,t);return}Ne(this,_r,S(this,_r)+t),S(this,_r)===0&&(Ne(this,xn,!1),S(this,ln)&&Ir(S(this,ln),()=>{Ne(this,ln,null)}),S(this,Qn)&&(S(this,wn).before(S(this,Qn)),Ne(this,Qn,null)))};function Ul(e,t,n,r){const i=rs()?is:ss;if(n.length===0&&e.length===0){r(t.map(i));return}var s=Ae,a=tt,l=hf();function u(){Promise.all(n.map(c=>pf(c))).then(c=>{l();try{r([...t.map(i),...c])}catch(f){a.f&nr||di(f,a)}s==null||s.deactivate(),Ts()}).catch(c=>{di(c,a)})}e.length>0?Promise.all(e).then(()=>{l();try{return u()}finally{s==null||s.deactivate(),Ts()}}):u()}function hf(){var e=tt,t=je,n=wt,r=Ae;return function(s=!0){kn(e),un(t),vi(n),s&&(r==null||r.activate())}}function Ts(){kn(null),un(null),vi(null)}function is(e){var t=Xt|vn,n=je!==null&&je.f&Xt?je:null;return tt!==null&&(tt.f|=wi),{ctx:wt,deps:null,effects:null,equals:Dl,f:t,fn:e,reactions:null,rv:0,v:Bt,wv:0,parent:n??tt,ac:null}}function pf(e,t){let n=tt;n===null&&Xu();var r=n.b,i=void 0,s=kr(Bt),a=!je,l=new Map;return Nf(()=>{var v;var u=Al();i=u.promise;try{Promise.resolve(e()).then(u.resolve,u.reject).then(()=>{c===Ae&&c.committed&&c.deactivate(),Ts()})}catch(h){u.reject(h),Ts()}var c=Ae;if(a){var f=!r.is_pending();r.update_pending_count(1),c.increment(f),(v=l.get(c))==null||v.reject(ri),l.delete(c),l.set(c,u)}const g=(h,$=void 0)=>{if(c.activate(),$)$!==ri&&(s.f|=wr,Ur(s,$));else{s.f&wr&&(s.f^=wr),Ur(s,h);for(const[y,p]of l){if(l.delete(y),y===c)break;p.reject(ri)}}a&&(r.update_pending_count(-1),c.decrement(f))};u.promise.then(g,h=>g(null,h||"unknown"))}),Ks(()=>{for(const u of l.values())u.reject(ri)}),new Promise(u=>{function c(f){function g(){f===i?u(s):c(i)}f.then(g,g)}c(i)})}function Hi(e){const t=is(e);return cc(t),t}function ss(e){const t=is(e);return t.equals=Rl,t}function Yl(e){var t=e.effects;if(t!==null){e.effects=null;for(var n=0;n<t.length;n+=1)Ut(t[n])}}function _f(e){for(var t=e.parent;t!==null;){if(!(t.f&Xt))return t.f&nr?null:t;t=t.parent}return null}function so(e){var t,n=tt;kn(_f(e));try{e.f&=~Vr,Yl(e),t=dc(e)}finally{kn(n)}return t}function Xl(e){var t=so(e);if(e.equals(t)||(Ae!=null&&Ae.is_fork||(e.v=t),e.wv=fc()),!Wr)if(Ct!==null)(Ui()||Ae!=null&&Ae.is_fork)&&Ct.set(e,t);else{var n=e.f&Sn?Vt:Tn;Yt(e,n)}}let La=new Set;const $r=new Map;let jl=!1;function kr(e,t){var n={f:0,v:e,reactions:null,equals:Dl,rv:0,wv:0};return n}function fr(e,t){const n=kr(e);return cc(n),n}function ze(e,t=!1,n=!0){var i;const r=kr(e);return t||(r.equals=Rl),xi&&n&&wt!==null&&wt.l!==null&&((i=wt.l).s??(i.s=[])).push(r),r}function gf(e,t){return R(e,x(()=>o(e))),t}function R(e,t,n=!1){je!==null&&(!qn||je.f&So)&&rs()&&je.f&(Xt|ir|io|So)&&!(tn!=null&&tn.includes(e))&&ef();let r=n?ii(t):t;return Ur(e,r)}function Ur(e,t){if(!e.equals(t)){var n=e.v;Wr?$r.set(e,t):$r.set(e,n),e.v=t;var r=er.ensure();r.capture(e,n),e.f&Xt&&(e.f&vn&&so(e),Yt(e,e.f&Sn?Vt:Tn)),e.wv=fc(),Gl(e,vn),rs()&&tt!==null&&tt.f&Vt&&!(tt.f&(sr|Xr))&&(yn===null?Tf([e]):yn.push(e)),!r.is_fork&&La.size>0&&!jl&&mf()}return t}function mf(){jl=!1;var e=Or;Ps(!0);const t=Array.from(La);try{for(const n of t)n.f&Vt&&Yt(n,Tn),$i(n)&&_i(n)}finally{Ps(e)}La.clear()}function hi(e,t=1){var n=o(e),r=t===1?n++:n--;return R(e,n),r}function qi(e){R(e,e.v+1)}function Gl(e,t){var n=e.reactions;if(n!==null)for(var r=rs(),i=n.length,s=0;s<i;s++){var a=n[s],l=a.f;if(!(!r&&a===tt)){var u=(l&vn)===0;if(u&&Yt(a,t),l&Xt){var c=a;Ct==null||Ct.delete(c),l&Vr||(l&Sn&&(a.f|=Vr),Gl(c,Tn))}else u&&(l&ir&&zn!==null&&zn.add(a),Hr(a))}}}function ii(e){if(typeof e!="object"||e===null||Vn in e)return e;const t=to(e);if(t!==Bu&&t!==Vu)return e;var n=new Map,r=eo(e),i=fr(0),s=Fr,a=l=>{if(Fr===s)return l();var u=je,c=Fr;un(null),Ro(s);var f=l();return un(u),Ro(c),f};return r&&n.set("length",fr(e.length)),new Proxy(e,{defineProperty(l,u,c){(!("value"in c)||c.configurable===!1||c.enumerable===!1||c.writable===!1)&&Qu();var f=n.get(u);return f===void 0?f=a(()=>{var g=fr(c.value);return n.set(u,g),g}):R(f,c.value,!0),!0},deleteProperty(l,u){var c=n.get(u);if(c===void 0){if(u in l){const f=a(()=>fr(Bt));n.set(u,f),qi(i)}}else R(c,Bt),qi(i);return!0},get(l,u,c){var h;if(u===Vn)return e;var f=n.get(u),g=u in l;if(f===void 0&&(!g||(h=yr(l,u))!=null&&h.writable)&&(f=a(()=>{var $=ii(g?l[u]:Bt),y=fr($);return y}),n.set(u,f)),f!==void 0){var v=o(f);return v===Bt?void 0:v}return Reflect.get(l,u,c)},getOwnPropertyDescriptor(l,u){var c=Reflect.getOwnPropertyDescriptor(l,u);if(c&&"value"in c){var f=n.get(u);f&&(c.value=o(f))}else if(c===void 0){var g=n.get(u),v=g==null?void 0:g.v;if(g!==void 0&&v!==Bt)return{enumerable:!0,configurable:!0,value:v,writable:!0}}return c},has(l,u){var v;if(u===Vn)return!0;var c=n.get(u),f=c!==void 0&&c.v!==Bt||Reflect.has(l,u);if(c!==void 0||tt!==null&&(!f||(v=yr(l,u))!=null&&v.writable)){c===void 0&&(c=a(()=>{var h=f?ii(l[u]):Bt,$=fr(h);return $}),n.set(u,c));var g=o(c);if(g===Bt)return!1}return f},set(l,u,c,f){var P;var g=n.get(u),v=u in l;if(r&&u==="length")for(var h=c;h<g.v;h+=1){var $=n.get(h+"");$!==void 0?R($,Bt):h in l&&($=a(()=>fr(Bt)),n.set(h+"",$))}if(g===void 0)(!v||(P=yr(l,u))!=null&&P.writable)&&(g=a(()=>fr(void 0)),R(g,ii(c)),n.set(u,g));else{v=g.v!==Bt;var y=a(()=>ii(c));R(g,y)}var p=Reflect.getOwnPropertyDescriptor(l,u);if(p!=null&&p.set&&p.set.call(f,c),!v){if(r&&typeof u=="string"){var _=n.get("length"),N=Number(u);Number.isInteger(N)&&N>=_.v&&R(_,N+1)}qi(i)}return!0},ownKeys(l){o(i);var u=Reflect.ownKeys(l).filter(g=>{var v=n.get(g);return v===void 0||v.v!==Bt});for(var[c,f]of n)f.v!==Bt&&!(c in l)&&u.push(c);return u},setPrototypeOf(){Ju()}})}function Co(e){try{if(e!==null&&typeof e=="object"&&Vn in e)return e[Vn]}catch{}return e}function yf(e,t){return Object.is(Co(e),Co(t))}var Po,Wl,Kl,Zl;function xf(){if(Po===void 0){Po=window,Wl=/Firefox/.test(navigator.userAgent);var e=Element.prototype,t=Node.prototype,n=Text.prototype;Kl=yr(t,"firstChild").get,Zl=yr(t,"nextSibling").get,Ao(e)&&(e.__click=void 0,e.__className=void 0,e.__attributes=null,e.__style=void 0,e.__e=void 0),Ao(n)&&(n.__t=void 0)}}function Hn(e=""){return document.createTextNode(e)}function pi(e){return Kl.call(e)}function as(e){return Zl.call(e)}function d(e,t){return pi(e)}function Z(e,t=!1){{var n=pi(e);return n instanceof Comment&&n.data===""?as(n):n}}function m(e,t=1,n=!1){let r=e;for(;t--;)r=as(r);return r}function wf(e){e.textContent=""}function Ql(){return!1}function $f(e,t){if(t){const n=document.body;e.autofocus=!0,jr(()=>{document.activeElement===n&&e.focus()})}}let Do=!1;function bf(){Do||(Do=!0,document.addEventListener("reset",e=>{Promise.resolve().then(()=>{var t;if(!e.defaultPrevented)for(const n of e.target.elements)(t=n.__on_r)==null||t.call(n)})},{capture:!0}))}function Ws(e){var t=je,n=tt;un(null),kn(null);try{return e()}finally{un(t),kn(n)}}function Jl(e,t,n,r=n){e.addEventListener(t,()=>Ws(n));const i=e.__on_r;i?e.__on_r=()=>{i(),r(!0)}:e.__on_r=()=>r(!0),bf()}function ec(e){tt===null&&(je===null&&Wu(),Gu()),Wr&&ju()}function kf(e,t){var n=t.last;n===null?t.last=t.first=e:(n.next=e,e.prev=n,t.last=e)}function Cn(e,t,n){var r=tt;r!==null&&r.f&_n&&(e|=_n);var i={ctx:wt,deps:null,nodes:null,f:e|vn|Sn,first:null,fn:t,last:null,next:null,parent:r,b:r&&r.b,prev:null,teardown:null,wv:0,ac:null};if(n)try{_i(i),i.f|=ro}catch(l){throw Ut(i),l}else t!==null&&Hr(i);var s=i;if(n&&s.deps===null&&s.teardown===null&&s.nodes===null&&s.first===s.last&&!(s.f&wi)&&(s=s.first,e&ir&&e&br&&s!==null&&(s.f|=br)),s!==null&&(s.parent=r,r!==null&&kf(s,r),je!==null&&je.f&Xt&&!(e&Xr))){var a=je;(a.effects??(a.effects=[])).push(s)}return i}function Ui(){return je!==null&&!qn}function Ks(e){const t=Cn(Xs,null,!1);return Yt(t,Vt),t.teardown=e,t}function Ra(e){ec();var t=tt.f,n=!je&&(t&sr)!==0&&(t&ro)===0;if(n){var r=wt;(r.e??(r.e=[])).push(e)}else return tc(e)}function tc(e){return Cn(no|Cl,e,!1)}function Ef(e){return ec(),Cn(Xs|Cl,e,!0)}function zf(e){er.ensure();const t=Cn(Xr|wi,e,!0);return(n={})=>new Promise(r=>{n.outro?Ir(t,()=>{Ut(t),r(void 0)}):(Ut(t),r(void 0))})}function Zs(e){return Cn(no,e,!1)}function Un(e,t){var n=wt,r={effect:null,ran:!1,deps:e};n.l.$.push(r),r.effect=os(()=>{e(),!r.ran&&(r.ran=!0,x(t))})}function Gr(){var e=wt;os(()=>{for(var t of e.l.$){t.deps();var n=t.effect;n.f&Vt&&Yt(n,Tn),$i(n)&&_i(n),t.ran=!1}})}function Nf(e){return Cn(io|wi,e,!0)}function os(e,t=0){return Cn(Xs|t,e,!0)}function L(e,t=[],n=[],r=[]){Ul(r,t,n,i=>{Cn(Xs,()=>e(...i.map(o)),!0)})}function ls(e,t=0){var n=Cn(ir|t,e,!0);return n}function nc(e,t=0){var n=Cn(Sl|t,e,!0);return n}function cn(e){return Cn(sr|wi,e,!0)}function rc(e){var t=e.teardown;if(t!==null){const n=Wr,r=je;Lo(!0),un(null);try{t.call(null)}finally{Lo(n),un(r)}}}function ic(e,t=!1){var n=e.first;for(e.first=e.last=null;n!==null;){const i=n.ac;i!==null&&Ws(()=>{i.abort(ri)});var r=n.next;n.f&Xr?n.parent=null:Ut(n,t),n=r}}function Mf(e){for(var t=e.first;t!==null;){var n=t.next;t.f&sr||Ut(t),t=n}}function Ut(e,t=!0){var n=!1;(t||e.f&Tl)&&e.nodes!==null&&e.nodes.end!==null&&(Af(e.nodes.start,e.nodes.end),n=!0),ic(e,t&&!n),Ds(e,0),Yt(e,nr);var r=e.nodes&&e.nodes.t;if(r!==null)for(const s of r)s.stop();rc(e);var i=e.parent;i!==null&&i.first!==null&&sc(e),e.next=e.prev=e.teardown=e.ctx=e.deps=e.fn=e.nodes=e.ac=null}function Af(e,t){for(;e!==null;){var n=e===t?null:as(e);e.remove(),e=n}}function sc(e){var t=e.parent,n=e.prev,r=e.next;n!==null&&(n.next=r),r!==null&&(r.prev=n),t!==null&&(t.first===e&&(t.first=r),t.last===e&&(t.last=n))}function Ir(e,t,n=!0){var r=[];ac(e,r,!0);var i=()=>{n&&Ut(e),t&&t()},s=r.length;if(s>0){var a=()=>--s||i();for(var l of r)l.out(a)}else i()}function ac(e,t,n){if(!(e.f&_n)){e.f^=_n;var r=e.nodes&&e.nodes.t;if(r!==null)for(const l of r)(l.is_global||n)&&t.push(l);for(var i=e.first;i!==null;){var s=i.next,a=(i.f&br)!==0||(i.f&sr)!==0&&(e.f&ir)!==0;ac(i,t,a?n:!1),i=s}}}function ao(e){oc(e,!0)}function oc(e,t){if(e.f&_n){e.f^=_n,e.f&Vt||(Yt(e,vn),Hr(e));for(var n=e.first;n!==null;){var r=n.next,i=(n.f&br)!==0||(n.f&sr)!==0;oc(n,i?t:!1),n=r}var s=e.nodes&&e.nodes.t;if(s!==null)for(const a of s)(a.is_global||t)&&a.in()}}function lc(e,t){if(e.nodes)for(var n=e.nodes.start,r=e.nodes.end;n!==null;){var i=n===r?null:as(n);t.append(n),n=i}}let hr=null;function Sf(e){var t=hr;try{if(hr=new Set,x(e),t!==null)for(var n of hr)t.add(n);return hr}finally{hr=t}}function Cs(e){for(var t of Sf(e))Ur(t,t.v)}let Or=!1;function Ps(e){Or=e}let Wr=!1;function Lo(e){Wr=e}let je=null,qn=!1;function un(e){je=e}let tt=null;function kn(e){tt=e}let tn=null;function cc(e){je!==null&&(tn===null?tn=[e]:tn.push(e))}let Jt=null,dn=0,yn=null;function Tf(e){yn=e}let uc=1,Yi=0,Fr=Yi;function Ro(e){Fr=e}function fc(){return++uc}function $i(e){var t=e.f;if(t&vn)return!0;if(t&Xt&&(e.f&=~Vr),t&Tn){var n=e.deps;if(n!==null)for(var r=n.length,i=0;i<r;i++){var s=n[i];if($i(s)&&Xl(s),s.wv>e.wv)return!0}t&Sn&&Ct===null&&Yt(e,Vt)}return!1}function vc(e,t,n=!0){var r=e.reactions;if(r!==null&&!(tn!=null&&tn.includes(e)))for(var i=0;i<r.length;i++){var s=r[i];s.f&Xt?vc(s,t,!1):t===s&&(n?Yt(s,vn):s.f&Vt&&Yt(s,Tn),Hr(s))}}function dc(e){var $;var t=Jt,n=dn,r=yn,i=je,s=tn,a=wt,l=qn,u=Fr,c=e.f;Jt=null,dn=0,yn=null,je=c&(sr|Xr)?null:e,tn=null,vi(e.ctx),qn=!1,Fr=++Yi,e.ac!==null&&(Ws(()=>{e.ac.abort(ri)}),e.ac=null);try{e.f|=Aa;var f=e.fn,g=f(),v=e.deps;if(Jt!==null){var h;if(Ds(e,dn),v!==null&&dn>0)for(v.length=dn+Jt.length,h=0;h<Jt.length;h++)v[dn+h]=Jt[h];else e.deps=v=Jt;if(Ui()&&e.f&Sn)for(h=dn;h<v.length;h++)(($=v[h]).reactions??($.reactions=[])).push(e)}else v!==null&&dn<v.length&&(Ds(e,dn),v.length=dn);if(rs()&&yn!==null&&!qn&&v!==null&&!(e.f&(Xt|Tn|vn)))for(h=0;h<yn.length;h++)vc(yn[h],e);return i!==null&&i!==e&&(Yi++,yn!==null&&(r===null?r=yn:r.push(...yn))),e.f&wr&&(e.f^=wr),g}catch(y){return Ol(y)}finally{e.f^=Aa,Jt=t,dn=n,yn=r,je=i,tn=s,vi(a),qn=l,Fr=u}}function Cf(e,t){let n=t.reactions;if(n!==null){var r=qu.call(n,e);if(r!==-1){var i=n.length-1;i===0?n=t.reactions=null:(n[r]=n[i],n.pop())}}n===null&&t.f&Xt&&(Jt===null||!Jt.includes(t))&&(Yt(t,Tn),t.f&Sn&&(t.f^=Sn,t.f&=~Vr),Yl(t),Ds(t,0))}function Ds(e,t){var n=e.deps;if(n!==null)for(var r=t;r<n.length;r++)Cf(e,n[r])}function _i(e){var t=e.f;if(!(t&nr)){Yt(e,Vt);var n=tt,r=Or;tt=e,Or=!0;try{t&(ir|Sl)?Mf(e):ic(e),rc(e);var i=dc(e);e.teardown=typeof i=="function"?i:null,e.wv=uc;var s;Ma&&Eu&&e.f&vn&&e.deps}finally{Or=r,tt=n}}}async function Pf(){await Promise.resolve(),af()}function o(e){var t=e.f,n=(t&Xt)!==0;if(hr==null||hr.add(e),je!==null&&!qn){var r=tt!==null&&(tt.f&nr)!==0;if(!r&&!(tn!=null&&tn.includes(e))){var i=je.deps;if(je.f&Aa)e.rv<Yi&&(e.rv=Yi,Jt===null&&i!==null&&i[dn]===e?dn++:Jt===null?Jt=[e]:Jt.includes(e)||Jt.push(e));else{(je.deps??(je.deps=[])).push(e);var s=e.reactions;s===null?e.reactions=[je]:s.includes(je)||s.push(je)}}}if(Wr){if($r.has(e))return $r.get(e);if(n){var a=e,l=a.v;return(!(a.f&Vt)&&a.reactions!==null||pc(a))&&(l=so(a)),$r.set(a,l),l}}else n&&(!(Ct!=null&&Ct.has(e))||Ae!=null&&Ae.is_fork&&!Ui())&&(a=e,$i(a)&&Xl(a),Or&&Ui()&&!(a.f&Sn)&&hc(a));if(Ct!=null&&Ct.has(e))return Ct.get(e);if(e.f&wr)throw e.v;return e.v}function hc(e){if(e.deps!==null){e.f^=Sn;for(const t of e.deps)(t.reactions??(t.reactions=[])).push(e),t.f&Xt&&!(t.f&Sn)&&hc(t)}}function pc(e){if(e.v===Bt)return!0;if(e.deps===null)return!1;for(const t of e.deps)if($r.has(t)||t.f&Xt&&pc(t))return!0;return!1}function x(e){var t=qn;try{return qn=!0,e()}finally{qn=t}}const Df=-7169;function Yt(e,t){e.f=e.f&Df|t}function St(e){if(!(typeof e!="object"||!e||e instanceof EventTarget)){if(Vn in e)Ia(e);else if(!Array.isArray(e))for(let t in e){const n=e[t];typeof n=="object"&&n&&Vn in n&&Ia(n)}}}function Ia(e,t=new Set){if(typeof e=="object"&&e!==null&&!(e instanceof EventTarget)&&!t.has(e)){t.add(e),e instanceof Date&&e.getTime();for(let r in e)try{Ia(e[r],t)}catch{}const n=to(e);if(n!==Object.prototype&&n!==Array.prototype&&n!==Map.prototype&&n!==Set.prototype&&n!==Date.prototype){const r=Ml(n);for(let i in r){const s=r[i].get;if(s)try{s.call(e)}catch{}}}}}const _c=new Set,Oa=new Set;function Lf(e,t,n,r={}){function i(s){if(r.capture||Pi.call(t,s),!s.cancelBubble)return Ws(()=>n==null?void 0:n.call(this,s))}return e.startsWith("pointer")||e.startsWith("touch")||e==="wheel"?jr(()=>{t.addEventListener(e,i,r)}):t.addEventListener(e,i,r),i}function Er(e){for(var t=0;t<e.length;t++)_c.add(e[t]);for(var n of Oa)n(e)}let Io=null;function Pi(e){var p;var t=this,n=t.ownerDocument,r=e.type,i=((p=e.composedPath)==null?void 0:p.call(e))||[],s=i[0]||e.target;Io=e;var a=0,l=Io===e&&e.__root;if(l){var u=i.indexOf(l);if(u!==-1&&(t===document||t===window)){e.__root=t;return}var c=i.indexOf(t);if(c===-1)return;u<=c&&(a=u)}if(s=i[a]||e.target,s!==t){Nl(e,"currentTarget",{configurable:!0,get(){return s||n}});var f=je,g=tt;un(null),kn(null);try{for(var v,h=[];s!==null;){var $=s.assignedSlot||s.parentNode||s.host||null;try{var y=s["__"+r];y!=null&&(!s.disabled||e.target===s)&&y.call(s,e)}catch(_){v?h.push(_):v=_}if(e.cancelBubble||$===t||$===null)break;s=$}if(v){for(let _ of h)queueMicrotask(()=>{throw _});throw v}}finally{e.__root=t,delete e.currentTarget,un(f),kn(g)}}}function gc(e){var t=document.createElement("template");return t.innerHTML=e.replaceAll("<!>","<!---->"),t.content}function gi(e,t){var n=tt;n.nodes===null&&(n.nodes={start:e,end:t,a:null,t:null})}function z(e,t){var n=(t&Lu)!==0,r=(t&Ru)!==0,i,s=!e.startsWith("<!>");return()=>{i===void 0&&(i=gc(s?e:"<!>"+e),n||(i=pi(i)));var a=r||Wl?document.importNode(i,!0):i.cloneNode(!0);if(n){var l=pi(a),u=a.lastChild;gi(l,u)}else gi(a,a);return a}}function Rf(e,t,n="svg"){var r=!e.startsWith("<!>"),i=`<${n}>${r?e:"<!>"+e}</${n}>`,s;return()=>{if(!s){var a=gc(i),l=pi(a);s=pi(l)}var u=s.cloneNode(!0);return gi(u,u),u}}function If(e,t){return Rf(e,t,"svg")}function Oo(e=""){{var t=Hn(e+"");return gi(t,t),t}}function ae(){var e=document.createDocumentFragment(),t=document.createComment(""),n=Hn();return e.append(t,n),gi(t,n),e}function b(e,t){e!==null&&e.before(t)}function Of(e){return e.endsWith("capture")&&e!=="gotpointercapture"&&e!=="lostpointercapture"}const Ff=["beforeinput","click","change","dblclick","contextmenu","focusin","focusout","input","keydown","keyup","mousedown","mousemove","mouseout","mouseover","mouseup","pointerdown","pointermove","pointerout","pointerover","pointerup","touchend","touchmove","touchstart"];function qf(e){return Ff.includes(e)}const Bf={formnovalidate:"formNoValidate",ismap:"isMap",nomodule:"noModule",playsinline:"playsInline",readonly:"readOnly",defaultvalue:"defaultValue",defaultchecked:"defaultChecked",srcobject:"srcObject",novalidate:"noValidate",allowfullscreen:"allowFullscreen",disablepictureinpicture:"disablePictureInPicture",disableremoteplayback:"disableRemotePlayback"};function Vf(e){return e=e.toLowerCase(),Bf[e]??e}const Hf=["touchstart","touchmove"];function Uf(e){return Hf.includes(e)}function M(e,t){var n=t==null?"":typeof t=="object"?t+"":t;n!==(e.__t??(e.__t=e.nodeValue))&&(e.__t=n,e.nodeValue=n+"")}function Yf(e,t){return Xf(e,t)}const ti=new Map;function Xf(e,{target:t,anchor:n,props:r={},events:i,context:s,intro:a=!0}){xf();var l=new Set,u=g=>{for(var v=0;v<g.length;v++){var h=g[v];if(!l.has(h)){l.add(h);var $=Uf(h);t.addEventListener(h,Pi,{passive:$});var y=ti.get(h);y===void 0?(document.addEventListener(h,Pi,{passive:$}),ti.set(h,1)):ti.set(h,y+1)}}};u(Ys(_c)),Oa.add(u);var c=void 0,f=zf(()=>{var g=n??t.appendChild(Hn());return uf(g,{pending:()=>{}},v=>{if(s){Xn({});var h=wt;h.c=s}i&&(r.$$events=i),c=e(v,r)||{},s&&jn()}),()=>{var $;for(var v of l){t.removeEventListener(v,Pi);var h=ti.get(v);--h===0?(document.removeEventListener(v,Pi),ti.delete(v)):ti.set(v,h)}Oa.delete(u),g!==n&&(($=g.parentNode)==null||$.removeChild(g))}});return jf.set(c,f),c}let jf=new WeakMap;var Nn,Fn,hn,Rr,ts,ns,Us;class oo{constructor(t,n=!0){Ln(this,"anchor");et(this,Nn,new Map);et(this,Fn,new Map);et(this,hn,new Map);et(this,Rr,new Set);et(this,ts,!0);et(this,ns,()=>{var t=Ae;if(S(this,Nn).has(t)){var n=S(this,Nn).get(t),r=S(this,Fn).get(n);if(r)ao(r),S(this,Rr).delete(n);else{var i=S(this,hn).get(n);i&&(S(this,Fn).set(n,i.effect),S(this,hn).delete(n),i.fragment.lastChild.remove(),this.anchor.before(i.fragment),r=i.effect)}for(const[s,a]of S(this,Nn)){if(S(this,Nn).delete(s),s===t)break;const l=S(this,hn).get(a);l&&(Ut(l.effect),S(this,hn).delete(a))}for(const[s,a]of S(this,Fn)){if(s===n||S(this,Rr).has(s))continue;const l=()=>{if(Array.from(S(this,Nn).values()).includes(s)){var c=document.createDocumentFragment();lc(a,c),c.append(Hn()),S(this,hn).set(s,{effect:a,fragment:c})}else Ut(a);S(this,Rr).delete(s),S(this,Fn).delete(s)};S(this,ts)||!r?(S(this,Rr).add(s),Ir(a,l,!1)):l()}}});et(this,Us,t=>{S(this,Nn).delete(t);const n=Array.from(S(this,Nn).values());for(const[r,i]of S(this,hn))n.includes(r)||(Ut(i.effect),S(this,hn).delete(r))});this.anchor=t,Ne(this,ts,n)}ensure(t,n){var r=Ae,i=Ql();if(n&&!S(this,Fn).has(t)&&!S(this,hn).has(t))if(i){var s=document.createDocumentFragment(),a=Hn();s.append(a),S(this,hn).set(t,{effect:cn(()=>n(a)),fragment:s})}else S(this,Fn).set(t,cn(()=>n(this.anchor)));if(S(this,Nn).set(r,t),i){for(const[l,u]of S(this,Fn))l===t?r.skipped_effects.delete(u):r.skipped_effects.add(u);for(const[l,u]of S(this,hn))l===t?r.skipped_effects.delete(u.effect):r.skipped_effects.add(u.effect);r.oncommit(S(this,ns)),r.ondiscard(S(this,Us))}else S(this,ns).call(this)}}Nn=new WeakMap,Fn=new WeakMap,hn=new WeakMap,Rr=new WeakMap,ts=new WeakMap,ns=new WeakMap,Us=new WeakMap;function Kr(e){wt===null&&Yu(),xi&&wt.l!==null?Gf(wt).m.push(e):Ra(()=>{const t=x(e);if(typeof t=="function")return t})}function Gf(e){var t=e.l;return t.u??(t.u={a:[],b:[],m:[]})}function D(e,t,n=!1){var r=new oo(e),i=n?br:0;function s(a,l){r.ensure(a,l)}ls(()=>{var a=!1;t((l,u=!0)=>{a=!0,s(u,l)}),a||s(!1,null)},i)}function Ge(e,t){return t}function Wf(e,t,n){for(var r=[],i=t.length,s,a=t.length,l=0;l<i;l++){let g=t[l];Ir(g,()=>{if(s){if(s.pending.delete(g),s.done.add(g),s.pending.size===0){var v=e.outrogroups;Fa(Ys(s.done)),v.delete(s),v.size===0&&(e.outrogroups=null)}}else a-=1},!1)}if(a===0){var u=r.length===0&&n!==null;if(u){var c=n,f=c.parentNode;wf(f),f.append(c),e.items.clear()}Fa(t,!u)}else s={pending:new Set(t),done:new Set},(e.outrogroups??(e.outrogroups=new Set)).add(s)}function Fa(e,t=!0){for(var n=0;n<e.length;n++)Ut(e[n],t)}var Fo;function We(e,t,n,r,i,s=null){var a=e,l=new Map,u=(t&El)!==0;if(u){var c=e;a=c.appendChild(Hn())}var f=null,g=ss(()=>{var _=n();return eo(_)?_:_==null?[]:Ys(_)}),v,h=!0;function $(){p.fallback=f,Kf(p,v,a,t,r),f!==null&&(v.length===0?f.f&Jn?(f.f^=Jn,Di(f,null,a)):ao(f):Ir(f,()=>{f=null}))}var y=ls(()=>{v=o(g);for(var _=v.length,N=new Set,P=Ae,w=Ql(),E=0;E<_;E+=1){var C=v[E],F=r(C,E),O=h?null:l.get(F);O?(O.v&&Ur(O.v,C),O.i&&Ur(O.i,E),w&&P.skipped_effects.delete(O.e)):(O=Zf(l,h?a:Fo??(Fo=Hn()),C,F,E,i,t,n),h||(O.e.f|=Jn),l.set(F,O)),N.add(F)}if(_===0&&s&&!f&&(h?f=cn(()=>s(a)):(f=cn(()=>s(Fo??(Fo=Hn()))),f.f|=Jn)),!h)if(w){for(const[ue,G]of l)N.has(ue)||P.skipped_effects.add(G.e);P.oncommit($),P.ondiscard(()=>{})}else $();o(g)}),p={effect:y,items:l,outrogroups:null,fallback:f};h=!1}function Kf(e,t,n,r,i){var G,ge,Ve,Re,k,I,A,H,Q;var s=(r&Au)!==0,a=t.length,l=e.items,u=e.effect.first,c,f=null,g,v=[],h=[],$,y,p,_;if(s)for(_=0;_<a;_+=1)$=t[_],y=i($,_),p=l.get(y).e,p.f&Jn||((ge=(G=p.nodes)==null?void 0:G.a)==null||ge.measure(),(g??(g=new Set)).add(p));for(_=0;_<a;_+=1){if($=t[_],y=i($,_),p=l.get(y).e,e.outrogroups!==null)for(const j of e.outrogroups)j.pending.delete(p),j.done.delete(p);if(p.f&Jn)if(p.f^=Jn,p===u)Di(p,null,n);else{var N=f?f.next:u;p===e.effect.last&&(e.effect.last=p.prev),p.prev&&(p.prev.next=p.next),p.next&&(p.next.prev=p.prev),vr(e,f,p),vr(e,p,N),Di(p,N,n),f=p,v=[],h=[],u=f.next;continue}if(p.f&_n&&(ao(p),s&&((Re=(Ve=p.nodes)==null?void 0:Ve.a)==null||Re.unfix(),(g??(g=new Set)).delete(p))),p!==u){if(c!==void 0&&c.has(p)){if(v.length<h.length){var P=h[0],w;f=P.prev;var E=v[0],C=v[v.length-1];for(w=0;w<v.length;w+=1)Di(v[w],P,n);for(w=0;w<h.length;w+=1)c.delete(h[w]);vr(e,E.prev,C.next),vr(e,f,E),vr(e,C,P),u=P,f=C,_-=1,v=[],h=[]}else c.delete(p),Di(p,u,n),vr(e,p.prev,p.next),vr(e,p,f===null?e.effect.first:f.next),vr(e,f,p),f=p;continue}for(v=[],h=[];u!==null&&u!==p;)(c??(c=new Set)).add(u),h.push(u),u=u.next;if(u===null)continue}p.f&Jn||v.push(p),f=p,u=p.next}if(e.outrogroups!==null){for(const j of e.outrogroups)j.pending.size===0&&(Fa(Ys(j.done)),(k=e.outrogroups)==null||k.delete(j));e.outrogroups.size===0&&(e.outrogroups=null)}if(u!==null||c!==void 0){var F=[];if(c!==void 0)for(p of c)p.f&_n||F.push(p);for(;u!==null;)!(u.f&_n)&&u!==e.fallback&&F.push(u),u=u.next;var O=F.length;if(O>0){var ue=r&El&&a===0?n:null;if(s){for(_=0;_<O;_+=1)(A=(I=F[_].nodes)==null?void 0:I.a)==null||A.measure();for(_=0;_<O;_+=1)(Q=(H=F[_].nodes)==null?void 0:H.a)==null||Q.fix()}Wf(e,F,ue)}}s&&jr(()=>{var j,W;if(g!==void 0)for(p of g)(W=(j=p.nodes)==null?void 0:j.a)==null||W.apply()})}function Zf(e,t,n,r,i,s,a,l){var u=a&Nu?a&Su?kr(n):ze(n,!1,!1):null,c=a&Mu?kr(i):null;return{v:u,i:c,e:cn(()=>(s(t,u??n,c??i,l),()=>{e.delete(r)}))}}function Di(e,t,n){if(e.nodes)for(var r=e.nodes.start,i=e.nodes.end,s=t&&!(t.f&Jn)?t.nodes.start:n;r!==null;){var a=as(r);if(s.before(r),r===i)return;r=a}}function vr(e,t,n){t===null?e.effect.first=n:t.next=n,n===null?e.effect.last=t:n.prev=t}function Qe(e,t,n,r,i){var l;var s=(l=t.$$slots)==null?void 0:l[n],a=!1;s===!0&&(s=t.children,a=!0),s===void 0||s(e,a?()=>r:r)}function Bn(e,t,n){var r=new oo(e);ls(()=>{var i=t()??null;r.ensure(i,i&&(s=>n(s,i)))},br)}function Qf(e,t,n,r,i,s){var a=null,l=e,u=new oo(l,!1);ls(()=>{const c=t()||null;var f=Ou;if(c===null){u.ensure(null,null);return}return u.ensure(c,g=>{if(c){if(a=document.createElementNS(f,c),gi(a,a),r){var v=a.appendChild(Hn());r(a,v)}tt.nodes.end=a,g.before(a)}}),()=>{}},br),Ks(()=>{})}function Jf(e,t){var n=void 0,r;nc(()=>{n!==(n=t())&&(r&&(Ut(r),r=null),n&&(r=cn(()=>{Zs(()=>n(e))})))})}function mc(e){var t,n,r="";if(typeof e=="string"||typeof e=="number")r+=e;else if(typeof e=="object")if(Array.isArray(e)){var i=e.length;for(t=0;t<i;t++)e[t]&&(n=mc(e[t]))&&(r&&(r+=" "),r+=n)}else for(n in e)e[n]&&(r&&(r+=" "),r+=n);return r}function ev(){for(var e,t,n=0,r="",i=arguments.length;n<i;n++)(e=arguments[n])&&(t=mc(e))&&(r&&(r+=" "),r+=t);return r}function tv(e){return typeof e=="object"?ev(e):e??""}const qo=[...` 	
\r\f \v\uFEFF`];function nv(e,t,n){var r=e==null?"":""+e;if(t&&(r=r?r+" "+t:t),n){for(var i in n)if(n[i])r=r?r+" "+i:i;else if(r.length)for(var s=i.length,a=0;(a=r.indexOf(i,a))>=0;){var l=a+s;(a===0||qo.includes(r[a-1]))&&(l===r.length||qo.includes(r[l]))?r=(a===0?"":r.substring(0,a))+r.substring(l+1):a=l}}return r===""?null:r}function Bo(e,t=!1){var n=t?" !important;":";",r="";for(var i in e){var s=e[i];s!=null&&s!==""&&(r+=" "+i+": "+s+n)}return r}function ua(e){return e[0]!=="-"||e[1]!=="-"?e.toLowerCase():e}function rv(e,t){if(t){var n="",r,i;if(Array.isArray(t)?(r=t[0],i=t[1]):r=t,e){e=String(e).replaceAll(/\s*\/\*.*?\*\/\s*/g,"").trim();var s=!1,a=0,l=!1,u=[];r&&u.push(...Object.keys(r).map(ua)),i&&u.push(...Object.keys(i).map(ua));var c=0,f=-1;const y=e.length;for(var g=0;g<y;g++){var v=e[g];if(l?v==="/"&&e[g-1]==="*"&&(l=!1):s?s===v&&(s=!1):v==="/"&&e[g+1]==="*"?l=!0:v==='"'||v==="'"?s=v:v==="("?a++:v===")"&&a--,!l&&s===!1&&a===0){if(v===":"&&f===-1)f=g;else if(v===";"||g===y-1){if(f!==-1){var h=ua(e.substring(c,f).trim());if(!u.includes(h)){v!==";"&&g++;var $=e.substring(c,g).trim();n+=" "+$+";"}}c=g+1,f=-1}}}}return r&&(n+=Bo(r)),i&&(n+=Bo(i,!0)),n=n.trim(),n===""?null:n}return e==null?null:String(e)}function xt(e,t,n,r,i,s){var a=e.__className;if(a!==n||a===void 0){var l=nv(n,r,s);l==null?e.removeAttribute("class"):t?e.className=l:e.setAttribute("class",l),e.__className=n}else if(s&&i!==s)for(var u in s){var c=!!s[u];(i==null||c!==!!i[u])&&e.classList.toggle(u,c)}return s}function fa(e,t={},n,r){for(var i in n){var s=n[i];t[i]!==s&&(n[i]==null?e.style.removeProperty(i):e.style.setProperty(i,s,r))}}function Mn(e,t,n,r){var i=e.__style;if(i!==t){var s=rv(t,r);s==null?e.removeAttribute("style"):e.style.cssText=s,e.__style=t}else r&&(Array.isArray(r)?(fa(e,n==null?void 0:n[0],r[0]),fa(e,n==null?void 0:n[1],r[1],"important")):fa(e,n,r));return r}function Xi(e,t,n=!1){if(e.multiple){if(t==null)return;if(!eo(t))return nf();for(var r of e.options)r.selected=t.includes(Bi(r));return}for(r of e.options){var i=Bi(r);if(yf(i,t)){r.selected=!0;return}}(!n||t!==void 0)&&(e.selectedIndex=-1)}function lo(e){var t=new MutationObserver(()=>{Xi(e,e.__value)});t.observe(e,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["value"]}),Ks(()=>{t.disconnect()})}function Ls(e,t,n=t){var r=new WeakSet,i=!0;Jl(e,"change",s=>{var a=s?"[selected]":":checked",l;if(e.multiple)l=[].map.call(e.querySelectorAll(a),Bi);else{var u=e.querySelector(a)??e.querySelector("option:not([disabled])");l=u&&Bi(u)}n(l),Ae!==null&&r.add(Ae)}),Zs(()=>{var s=t();if(e===document.activeElement){var a=Oi??Ae;if(r.has(a))return}if(Xi(e,s,i),i&&s===void 0){var l=e.querySelector(":checked");l!==null&&(s=Bi(l),n(s))}e.__value=s,i=!1}),lo(e)}function Bi(e){return"__value"in e?e.__value:e.value}const Mi=Symbol("class"),Ai=Symbol("style"),yc=Symbol("is custom element"),xc=Symbol("is html");function iv(e,t){t?e.hasAttribute("selected")||e.setAttribute("selected",""):e.removeAttribute("selected")}function qa(e,t,n,r){var i=wc(e);i[t]!==(i[t]=n)&&(t==="loading"&&(e[Uu]=n),n==null?e.removeAttribute(t):typeof n!="string"&&$c(e).includes(t)?e[t]=n:e.setAttribute(t,n))}function sv(e,t,n,r,i=!1,s=!1){var a=wc(e),l=a[yc],u=!a[xc],c=t||{},f=e.tagName==="OPTION";for(var g in t)g in n||(n[g]=null);n.class?n.class=tv(n.class):n[Mi]&&(n.class=null),n[Ai]&&(n.style??(n.style=null));var v=$c(e);for(const w in n){let E=n[w];if(f&&w==="value"&&E==null){e.value=e.__value="",c[w]=E;continue}if(w==="class"){var h=e.namespaceURI==="http://www.w3.org/1999/xhtml";xt(e,h,E,r,t==null?void 0:t[Mi],n[Mi]),c[w]=E,c[Mi]=n[Mi];continue}if(w==="style"){Mn(e,E,t==null?void 0:t[Ai],n[Ai]),c[w]=E,c[Ai]=n[Ai];continue}var $=c[w];if(!(E===$&&!(E===void 0&&e.hasAttribute(w)))){c[w]=E;var y=w[0]+w[1];if(y!=="$$")if(y==="on"){const C={},F="$$"+w;let O=w.slice(2);var p=qf(O);if(Of(O)&&(O=O.slice(0,-7),C.capture=!0),!p&&$){if(E!=null)continue;e.removeEventListener(O,c[F],C),c[F]=null}if(E!=null)if(p)e[`__${O}`]=E,Er([O]);else{let ue=function(G){c[w].call(this,G)};var P=ue;c[F]=Lf(O,e,ue,C)}else p&&(e[`__${O}`]=void 0)}else if(w==="style")qa(e,w,E);else if(w==="autofocus")$f(e,!!E);else if(!l&&(w==="__value"||w==="value"&&E!=null))e.value=e.__value=E;else if(w==="selected"&&f)iv(e,E);else{var _=w;u||(_=Vf(_));var N=_==="defaultValue"||_==="defaultChecked";if(E==null&&!l&&!N)if(a[w]=null,_==="value"||_==="checked"){let C=e;const F=t===void 0;if(_==="value"){let O=C.defaultValue;C.removeAttribute(_),C.defaultValue=O,C.value=C.__value=F?O:null}else{let O=C.defaultChecked;C.removeAttribute(_),C.defaultChecked=O,C.checked=F?O:!1}}else e.removeAttribute(w);else N||v.includes(_)&&(l||typeof E!="string")?(e[_]=E,_ in a&&(a[_]=Bt)):typeof E!="function"&&qa(e,_,E)}}}return c}function Vo(e,t,n=[],r=[],i=[],s,a=!1,l=!1){Ul(i,n,r,u=>{var c=void 0,f={},g=e.nodeName==="SELECT",v=!1;if(nc(()=>{var $=t(...u.map(o)),y=sv(e,c,$,s,a,l);v&&g&&"value"in $&&Xi(e,$.value);for(let _ of Object.getOwnPropertySymbols(f))$[_]||Ut(f[_]);for(let _ of Object.getOwnPropertySymbols($)){var p=$[_];_.description===Fu&&(!c||p!==c[_])&&(f[_]&&Ut(f[_]),f[_]=cn(()=>Jf(e,()=>p))),y[_]=p}c=y}),g){var h=e;Zs(()=>{Xi(h,c.value,!0),lo(h)})}v=!0})}function wc(e){return e.__attributes??(e.__attributes={[yc]:e.nodeName.includes("-"),[xc]:e.namespaceURI===Iu})}var Ho=new Map;function $c(e){var t=e.getAttribute("is")||e.nodeName,n=Ho.get(t);if(n)return n;Ho.set(t,n=[]);for(var r,i=e,s=Element.prototype;s!==i;){r=Ml(i);for(var a in r)r[a].set&&n.push(a);i=to(i)}return n}function co(e,t,n=t){var r=new WeakSet;Jl(e,"input",async i=>{var s=i?e.defaultValue:e.value;if(s=va(e)?da(s):s,n(s),Ae!==null&&r.add(Ae),await Pf(),s!==(s=t())){var a=e.selectionStart,l=e.selectionEnd,u=e.value.length;if(e.value=s??"",l!==null){var c=e.value.length;a===l&&l===u&&c>u?(e.selectionStart=c,e.selectionEnd=c):(e.selectionStart=a,e.selectionEnd=Math.min(l,c))}}}),x(t)==null&&e.value&&(n(va(e)?da(e.value):e.value),Ae!==null&&r.add(Ae)),os(()=>{var i=t();if(e===document.activeElement){var s=Oi??Ae;if(r.has(s))return}va(e)&&i===da(e.value)||e.type==="date"&&!i&&!e.value||i!==e.value&&(e.value=i??"")})}function va(e){var t=e.type;return t==="number"||t==="range"}function da(e){return e===""?null:+e}function Uo(e,t){return e===t||(e==null?void 0:e[Vn])===t}function uo(e={},t,n,r){return Zs(()=>{var i,s;return os(()=>{i=s,s=[],x(()=>{e!==n(...s)&&(t(e,...s),i&&Uo(n(...i),e)&&t(null,...i))})}),()=>{jr(()=>{s&&Uo(n(...s),e)&&t(null,...s)})}}),e}function ar(e=!1){const t=wt,n=t.l.u;if(!n)return;let r=()=>St(t.s);if(e){let i=0,s={};const a=is(()=>{let l=!1;const u=t.s;for(const c in u)u[c]!==s[c]&&(s[c]=u[c],l=!0);return l&&i++,i});r=()=>o(a)}n.b.length&&Ef(()=>{Yo(t,r),Ss(n.b)}),Ra(()=>{const i=x(()=>n.m.map(Hu));return()=>{for(const s of i)typeof s=="function"&&s()}}),n.a.length&&Ra(()=>{Yo(t,r),Ss(n.a)})}function Yo(e,t){if(e.l.s)for(const n of e.l.s)o(n);t()}function fo(e,t,n){if(e==null)return t(void 0),n&&n(void 0),xr;const r=x(()=>e.subscribe(t,n));return r.unsubscribe?()=>r.unsubscribe():r}const ni=[];function av(e,t){return{subscribe:ht(e,t).subscribe}}function ht(e,t=xr){let n=null;const r=new Set;function i(l){if(Ll(e,l)&&(e=l,n)){const u=!ni.length;for(const c of r)c[1](),ni.push(c,e);if(u){for(let c=0;c<ni.length;c+=2)ni[c][0](ni[c+1]);ni.length=0}}}function s(l){i(l(e))}function a(l,u=xr){const c=[l,u];return r.add(c),r.size===1&&(n=t(i,s)||xr),l(e),()=>{r.delete(c),r.size===0&&n&&(n(),n=null)}}return{set:i,update:s,subscribe:a}}function bc(e,t,n){const r=!Array.isArray(e),i=r?[e]:e;if(!i.every(Boolean))throw new Error("derived() expects stores as input, got a falsy value");const s=t.length<2;return av(n,(a,l)=>{let u=!1;const c=[];let f=0,g=xr;const v=()=>{if(f)return;g();const $=t(r?c[0]:c,a,l);s?a($):g=typeof $=="function"?$:xr},h=i.map(($,y)=>fo($,p=>{c[y]=p,f&=~(1<<y),u&&v()},()=>{f|=1<<y}));return u=!0,v(),function(){Ss(h),g(),u=!1}})}function ov(e){let t;return fo(e,n=>t=n)(),t}let ds=!1,Ba=Symbol();function at(e,t,n){const r=n[t]??(n[t]={store:null,source:ze(void 0),unsubscribe:xr});if(r.store!==e&&!(Ba in n))if(r.unsubscribe(),r.store=e??null,e==null)r.source.v=void 0,r.unsubscribe=xr;else{var i=!0;r.unsubscribe=fo(e,s=>{i?r.source.v=s:R(r.source,s)}),i=!1}return e&&Ba in n?ov(e):o(r.source)}function zr(){const e={};function t(){Ks(()=>{for(var n in e)e[n].unsubscribe();Nl(e,Ba,{enumerable:!1,value:!0})})}return[e,t]}function lv(e){var t=ds;try{return ds=!1,[e(),ds]}finally{ds=t}}const cv={get(e,t){if(!e.exclude.includes(t))return o(e.version),t in e.special?e.special[t]():e.props[t]},set(e,t,n){if(!(t in e.special)){var r=tt;try{kn(e.parent_effect),e.special[t]=Nr({get[t](){return e.props[t]}},t,zl)}finally{kn(r)}}return e.special[t](n),hi(e.version),!0},getOwnPropertyDescriptor(e,t){if(!e.exclude.includes(t)&&t in e.props)return{enumerable:!0,configurable:!0,value:e.props[t]}},deleteProperty(e,t){return e.exclude.includes(t)||(e.exclude.push(t),hi(e.version)),!0},has(e,t){return e.exclude.includes(t)?!1:t in e.props},ownKeys(e){return Reflect.ownKeys(e.props).filter(t=>!e.exclude.includes(t))}};function Ke(e,t){return new Proxy({props:e,exclude:t,special:{},version:kr(0),parent_effect:tt},cv)}const uv={get(e,t){let n=e.props.length;for(;n--;){let r=e.props[n];if(Ni(r)&&(r=r()),typeof r=="object"&&r!==null&&t in r)return r[t]}},set(e,t,n){let r=e.props.length;for(;r--;){let i=e.props[r];Ni(i)&&(i=i());const s=yr(i,t);if(s&&s.set)return s.set(n),!0}return!1},getOwnPropertyDescriptor(e,t){let n=e.props.length;for(;n--;){let r=e.props[n];if(Ni(r)&&(r=r()),typeof r=="object"&&r!==null&&t in r){const i=yr(r,t);return i&&!i.configurable&&(i.configurable=!0),i}}},has(e,t){if(t===Vn||t===Pl)return!1;for(let n of e.props)if(Ni(n)&&(n=n()),n!=null&&t in n)return!0;return!1},ownKeys(e){const t=[];for(let n of e.props)if(Ni(n)&&(n=n()),!!n){for(const r in n)t.includes(r)||t.push(r);for(const r of Object.getOwnPropertySymbols(n))t.includes(r)||t.push(r)}return t}};function nt(...e){return new Proxy({props:e},uv)}function Nr(e,t,n,r){var P;var i=!xi||(n&Cu)!==0,s=(n&Pu)!==0,a=(n&Du)!==0,l=r,u=!0,c=()=>(u&&(u=!1,l=a?x(r):r),l),f;if(s){var g=Vn in e||Pl in e;f=((P=yr(e,t))==null?void 0:P.set)??(g&&t in e?w=>e[t]=w:void 0)}var v,h=!1;s?[v,h]=lv(()=>e[t]):v=e[t],v===void 0&&r!==void 0&&(v=c(),f&&(i&&Zu(),f(v)));var $;if(i?$=()=>{var w=e[t];return w===void 0?c():(u=!0,w)}:$=()=>{var w=e[t];return w!==void 0&&(l=void 0),w===void 0?l:w},i&&!(n&zl))return $;if(f){var y=e.$$legacy;return function(w,E){return arguments.length>0?((!i||!E||y||h)&&f(E?$():w),w):$()}}var p=!1,_=(n&Tu?is:ss)(()=>(p=!1,$()));s&&o(_);var N=tt;return function(w,E){if(arguments.length>0){const C=E?o(_):i&&s?ii(w):w;return R(_,C),p=!0,l!==void 0&&(l=C),w}return Wr&&p||N.f&nr?_.v:o(_)}}const or=ht(""),kc=ht([]),Xo=ht(null),ws=ht(!1),ha=ht(null),jo=ht([]),Go=ht(0),$s=ht(!1),pa=ht(null),Wn=ht([]),Wo=ht([]),Ko=ht(0),bs=ht(!1),_a=ht(null),Zo=ht([]),fv=ht(0),ks=ht(!1),ga=ht(null),Qo=ht("dashboard"),Jo=ht(null),ma=ht(!1),ya=ht(null),el=ht(null),xa=ht(!1),wa=ht(null),vv=typeof localStorage<"u"?localStorage.getItem("theme"):null,Li=ht(vv||"system");typeof localStorage<"u"&&Li.subscribe(e=>{localStorage.setItem("theme",e)});const dv=bc(or,e=>e.length>0);bc([ws,$s,bs,ks],([e,t,n,r])=>e||t||n||r);const Ec="/api/v1";function zc(){return new URLSearchParams(window.location.search).get("db")||""}function Pn(e,t={}){const n=zc(),r=new URLSearchParams({db:n,...t});return`${Ec}${e}?${r.toString()}`}async function En(e,t){const n=await fetch(e,{...t,headers:{"Content-Type":"application/json",...t==null?void 0:t.headers}});if(!n.ok){const r=await n.json().catch(()=>({error:n.statusText}));throw new Error(r.error||`HTTP ${n.status}`)}return n.json()}async function hv(){return En(Pn("/stats"))}async function pv(e={}){const t={};return e.offset!==void 0&&(t.offset=String(e.offset)),e.limit!==void 0&&(t.limit=String(e.limit)),e.search&&(t.search=e.search),En(Pn("/concepts",t))}async function Va(e){return En(Pn(`/concepts/${e}`))}async function _v(e={}){const t={};return e.offset!==void 0&&(t.offset=String(e.offset)),e.limit!==void 0&&(t.limit=String(e.limit)),e.type&&(t.type=e.type),e.consolidated!==void 0&&(t.consolidated=String(e.consolidated)),e.start_date&&(t.start_date=e.start_date),e.end_date&&(t.end_date=e.end_date),e.search&&(t.search=e.search),En(Pn("/episodes",t))}async function Qs(e){return En(Pn(`/episodes/${e}`))}async function gv(e={}){const t={};return e.type&&(t.type=e.type),En(Pn("/entities",t))}async function Nc(e){return En(Pn(`/entities/${encodeURIComponent(e)}`))}async function Mc(e,t=50){return En(Pn(`/entities/${encodeURIComponent(e)}/episodes`,{limit:String(t)}))}async function Ac(e,t=50){return En(Pn(`/entities/${encodeURIComponent(e)}/concepts`,{limit:String(t)}))}async function mv(){return En(Pn("/graph"))}async function yv(){return En(Pn("/entity-graph"))}async function xv(){return(await En(`${Ec}/databases`)).databases}/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 * 
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 * 
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * ---
 * 
 * The MIT License (MIT) (for portions derived from Feather)
 * 
 * Copyright (c) 2013-2023 Cole Bemis
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 * 
 */const wv={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor","stroke-width":2,"stroke-linecap":"round","stroke-linejoin":"round"};var $v=If("<svg><!><!></svg>");function rt(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]),r=Ke(n,["name","color","size","strokeWidth","absoluteStrokeWidth","iconNode"]);Xn(t,!1);let i=Nr(t,"name",8,void 0),s=Nr(t,"color",8,"currentColor"),a=Nr(t,"size",8,24),l=Nr(t,"strokeWidth",8,2),u=Nr(t,"absoluteStrokeWidth",8,!1),c=Nr(t,"iconNode",24,()=>[]);const f=(...$)=>$.filter((y,p,_)=>!!y&&_.indexOf(y)===p).join(" ");ar();var g=$v();Vo(g,($,y)=>({...wv,...r,width:a(),height:a(),stroke:s(),"stroke-width":$,class:y}),[()=>(St(u()),St(l()),St(a()),x(()=>u()?Number(l())*24/Number(a()):l())),()=>(St(i()),St(n),x(()=>f("lucide-icon","lucide",i()?`lucide-${i()}`:"",n.class)))]);var v=d(g);We(v,1,c,Ge,($,y)=>{var p=Hi(()=>Vi(o(y),2));let _=()=>o(p)[0],N=()=>o(p)[1];var P=ae(),w=Z(P);Qf(w,_,!0,(E,C)=>{Vo(E,()=>({...N()}))}),b($,P)});var h=m(v);Qe(h,t,"default",{}),b(e,g),jn()}function si(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M5 12h14"}],["path",{d:"m12 5 7 7-7 7"}]];rt(e,nt({name:"arrow-right"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Sc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M12 7v14"}],["path",{d:"M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"}]];rt(e,nt({name:"book-open"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Tc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M21 8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16Z"}],["path",{d:"m3.3 7 8.7 5 8.7-5"}],["path",{d:"M12 22V12"}]];rt(e,nt({name:"box"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Js(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M12 18V5"}],["path",{d:"M15 13a4.17 4.17 0 0 1-3-4 4.17 4.17 0 0 1-3 4"}],["path",{d:"M17.598 6.5A3 3 0 1 0 12 5a3 3 0 1 0-5.598 1.5"}],["path",{d:"M17.997 5.125a4 4 0 0 1 2.526 5.77"}],["path",{d:"M18 18a4 4 0 0 0 2-7.464"}],["path",{d:"M19.967 17.483A4 4 0 1 1 12 18a4 4 0 1 1-7.967-.517"}],["path",{d:"M6 18a4 4 0 0 1-2-7.464"}],["path",{d:"M6.003 5.125a4 4 0 0 0-2.526 5.77"}]];rt(e,nt({name:"brain"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Cc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"}],["rect",{width:"20",height:"14",x:"2",y:"6",rx:"2"}]];rt(e,nt({name:"briefcase"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function vo(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"m6 9 6 6 6-6"}]];rt(e,nt({name:"chevron-down"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function ho(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"m9 18 6-6-6-6"}]];rt(e,nt({name:"chevron-right"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function tl(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["circle",{cx:"12",cy:"12",r:"10"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16"}]];rt(e,nt({name:"circle-alert"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function bv(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M21.801 10A10 10 0 1 1 17 3.335"}],["path",{d:"m9 11 3 3L22 4"}]];rt(e,nt({name:"circle-check-big"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function ji(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["circle",{cx:"12",cy:"12",r:"10"}],["path",{d:"M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"}],["path",{d:"M12 17h.01"}]];rt(e,nt({name:"circle-question-mark"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function kv(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["circle",{cx:"12",cy:"12",r:"10"}]];rt(e,nt({name:"circle"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Pc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"m16 18 6-6-6-6"}],["path",{d:"m8 6-6 6 6 6"}]];rt(e,nt({name:"code"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function ea(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0"}],["circle",{cx:"12",cy:"12",r:"3"}]];rt(e,nt({name:"eye"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Dc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5"}]];rt(e,nt({name:"file"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Lc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z"}]];rt(e,nt({name:"folder"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Ev(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z"}]];rt(e,nt({name:"funnel"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function ta(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M2 9.5a5.5 5.5 0 0 1 9.591-3.676.56.56 0 0 0 .818 0A5.49 5.49 0 0 1 22 9.5c0 2.29-1.5 4-3 5.5l-5.492 5.313a2 2 0 0 1-3 .019L5 15c-1.5-1.5-3-3.2-3-5.5"}]];rt(e,nt({name:"heart"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Rc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"}],["path",{d:"M3 3v5h5"}],["path",{d:"M12 7v5l4 2"}]];rt(e,nt({name:"history"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function zv(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"}],["path",{d:"M3 10a2 2 0 0 1 .709-1.528l7-6a2 2 0 0 1 2.582 0l7 6A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"}]];rt(e,nt({name:"house"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function na(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"}],["path",{d:"M9 18h6"}],["path",{d:"M10 22h4"}]];rt(e,nt({name:"lightbulb"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Nv(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["rect",{width:"20",height:"14",x:"2",y:"3",rx:"2"}],["line",{x1:"8",x2:"16",y1:"21",y2:"21"}],["line",{x1:"12",x2:"12",y1:"17",y2:"21"}]];rt(e,nt({name:"monitor"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Mv(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"}]];rt(e,nt({name:"moon"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Ic(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["rect",{x:"16",y:"16",width:"6",height:"6",rx:"1"}],["rect",{x:"2",y:"16",width:"6",height:"6",rx:"1"}],["rect",{x:"9",y:"2",width:"6",height:"6",rx:"1"}],["path",{d:"M5 16v-3a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v3"}],["path",{d:"M12 12V8"}]];rt(e,nt({name:"network"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Oc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"}],["path",{d:"M3 3v5h5"}]];rt(e,nt({name:"rotate-ccw"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function po(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"m21 21-4.34-4.34"}],["circle",{cx:"11",cy:"11",r:"8"}]];rt(e,nt({name:"search"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Av(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["circle",{cx:"12",cy:"12",r:"4"}],["path",{d:"M12 2v2"}],["path",{d:"M12 20v2"}],["path",{d:"m4.93 4.93 1.41 1.41"}],["path",{d:"m17.66 17.66 1.41 1.41"}],["path",{d:"M2 12h2"}],["path",{d:"M20 12h2"}],["path",{d:"m6.34 17.66-1.41 1.41"}],["path",{d:"m19.07 4.93-1.41 1.41"}]];rt(e,nt({name:"sun"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function _o(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"}],["circle",{cx:"7.5",cy:"7.5",r:".5",fill:"currentColor"}]];rt(e,nt({name:"tag"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Fc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"}],["circle",{cx:"12",cy:"7",r:"4"}]];rt(e,nt({name:"user"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function qc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z"}]];rt(e,nt({name:"wrench"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Bc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M18 6 6 18"}],["path",{d:"m6 6 12 12"}]];rt(e,nt({name:"x"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function ra(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["path",{d:"M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z"}]];rt(e,nt({name:"zap"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Vc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["circle",{cx:"11",cy:"11",r:"8"}],["line",{x1:"21",x2:"16.65",y1:"21",y2:"16.65"}],["line",{x1:"11",x2:"11",y1:"8",y2:"14"}],["line",{x1:"8",x2:"14",y1:"11",y2:"11"}]];rt(e,nt({name:"zoom-in"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}function Hc(e,t){const n=Ke(t,["children","$$slots","$$events","$$legacy"]);/**
 * @license lucide-svelte v0.562.0 - ISC
 *
 * ISC License
 *
 * Copyright (c) for portions of Lucide are held by Cole Bemis 2013-2023 as part of Feather (MIT). All other copyright (c) for Lucide are held by Lucide Contributors 2025.
 *
 * Permission to use, copy, modify, and/or distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 *
 * ---
 *
 * The MIT License (MIT) (for portions derived from Feather)
 *
 * Copyright (c) 2013-2023 Cole Bemis
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *
 */const r=[["circle",{cx:"11",cy:"11",r:"8"}],["line",{x1:"21",x2:"16.65",y1:"21",y2:"16.65"}],["line",{x1:"8",x2:"14",y1:"11",y2:"11"}]];rt(e,nt({name:"zoom-out"},()=>n,{get iconNode(){return r},children:(i,s)=>{var a=ae(),l=Z(a);Qe(l,t,"default",{}),b(i,a)},$$slots:{default:!0}}))}var Sv=z('<div class="loading svelte-1y1a8hs">Loading stats...</div>'),Tv=z('<div class="error svelte-1y1a8hs"> </div>'),Cv=z('<div class="status-item pending svelte-1y1a8hs"><!> <div><span class="status-count svelte-1y1a8hs"> </span> <span class="status-label">episodes pending consolidation</span></div></div>'),Pv=z('<div class="status-item ok svelte-1y1a8hs"><!> <span>All episodes consolidated</span></div>'),Dv=z('<div class="status-item pending svelte-1y1a8hs"><!> <div><span class="status-count svelte-1y1a8hs"> </span> <span class="status-label">episodes pending entity extraction</span></div></div>'),Lv=z('<div class="distribution-item svelte-1y1a8hs"><span class="distribution-label svelte-1y1a8hs"> </span> <span class="distribution-value svelte-1y1a8hs"> </span></div>'),Rv=z('<div class="distribution-item svelte-1y1a8hs"><span> </span> <span class="distribution-value svelte-1y1a8hs"> </span></div>'),Iv=z('<div class="stats-grid svelte-1y1a8hs"><div class="stat-card svelte-1y1a8hs"><div class="stat-icon icon-concepts svelte-1y1a8hs"><!></div> <div class="stat-content svelte-1y1a8hs"><span class="stat-value svelte-1y1a8hs"> </span> <span class="stat-label svelte-1y1a8hs">Concepts</span></div></div> <div class="stat-card svelte-1y1a8hs"><div class="stat-icon icon-episodes svelte-1y1a8hs"><!></div> <div class="stat-content svelte-1y1a8hs"><span class="stat-value svelte-1y1a8hs"> </span> <span class="stat-label svelte-1y1a8hs">Episodes</span></div></div> <div class="stat-card svelte-1y1a8hs"><div class="stat-icon icon-entities svelte-1y1a8hs"><!></div> <div class="stat-content svelte-1y1a8hs"><span class="stat-value svelte-1y1a8hs"> </span> <span class="stat-label svelte-1y1a8hs">Entities</span></div></div> <div class="stat-card svelte-1y1a8hs"><div class="stat-icon icon-relations svelte-1y1a8hs"><!></div> <div class="stat-content svelte-1y1a8hs"><span class="stat-value svelte-1y1a8hs"> </span> <span class="stat-label svelte-1y1a8hs">Relations</span></div></div></div> <div class="section svelte-1y1a8hs"><h3 class="svelte-1y1a8hs">Consolidation Status</h3> <div class="consolidation-status svelte-1y1a8hs"><!> <!></div></div> <div class="distributions svelte-1y1a8hs"><div class="section svelte-1y1a8hs"><h3 class="svelte-1y1a8hs">Episode Types</h3> <div class="distribution-list svelte-1y1a8hs"></div></div> <div class="section svelte-1y1a8hs"><h3 class="svelte-1y1a8hs">Relation Types</h3> <div class="distribution-list svelte-1y1a8hs"></div></div></div>',1),Ov=z('<div class="empty svelte-1y1a8hs">No stats available</div>'),Fv=z('<div class="dashboard svelte-1y1a8hs"><h2 class="svelte-1y1a8hs">Dashboard</h2> <!></div>');function qv(e,t){Xn(t,!1);const n=()=>at(or,"$currentDb",a),r=()=>at(ws,"$statsLoading",a),i=()=>at(ha,"$statsError",a),s=()=>at(Xo,"$stats",a),[a,l]=zr();let u=ze(!1);Kr(()=>{R(u,!0),c()});async function c(){if(n()){ws.set(!0),ha.set(null);try{const p=await hv();Xo.set(p)}catch(p){ha.set(p instanceof Error?p.message:"Failed to load stats")}finally{ws.set(!1)}}}const f={observation:"Observations",decision:"Decisions",question:"Questions",meta:"Meta",preference:"Preferences"},g={implies:"Implies",contradicts:"Contradicts",specializes:"Specializes",generalizes:"Generalizes",causes:"Causes",correlates:"Correlates",part_of:"Part of",context_of:"Context of"};Un(()=>(o(u),n()),()=>{o(u)&&n()&&c()}),Gr(),ar();var v=Fv(),h=m(d(v),2);{var $=p=>{var _=Sv();b(p,_)},y=p=>{var _=ae(),N=Z(_);{var P=E=>{var C=Tv(),F=d(C);L(()=>M(F,i())),b(E,C)},w=E=>{var C=ae(),F=Z(C);{var O=G=>{var ge=Iv(),Ve=Z(ge),Re=d(Ve),k=d(Re),I=d(k);na(I,{size:24});var A=m(k,2),H=d(A),Q=d(H),j=m(Re,2),W=d(j),me=d(W);Rc(me,{size:24});var Ce=m(W,2),it=d(Ce),Ie=d(it),Pe=m(j,2),lt=d(Pe),ut=d(lt);_o(ut,{size:24});var gt=m(lt,2),yt=d(gt),we=d(yt),$t=m(Pe,2),Dt=d($t),It=d(Dt);Ic(It,{size:24});var K=m(Dt,2),ve=d(K),vt=d(ve),bt=m(Ve,2),re=m(d(bt),2),ct=d(re);{var pt=q=>{var he=Cv(),ye=d(he);tl(ye,{size:20});var ke=m(ye,2),ee=d(ke),Me=d(ee);L(()=>M(Me,(s(),x(()=>s().unconsolidated_episodes)))),b(q,he)},Tt=q=>{var he=Pv(),ye=d(he);bv(ye,{size:20}),b(q,he)};D(ct,q=>{s(),x(()=>s().unconsolidated_episodes>0)?q(pt):q(Tt,!1)})}var Gt=m(ct,2);{var jt=q=>{var he=Dv(),ye=d(he);tl(ye,{size:20});var ke=m(ye,2),ee=d(ke),Me=d(ee);L(()=>M(Me,(s(),x(()=>s().unextracted_count)))),b(q,he)};D(Gt,q=>{s(),x(()=>s().unextracted_count>0)&&q(jt)})}var V=m(bt,2),Y=d(V),T=m(d(Y),2);We(T,5,()=>(s(),x(()=>Object.entries(s().episode_types))),Ge,(q,he)=>{var ye=Hi(()=>Vi(o(he),2));let ke=()=>o(ye)[0],ee=()=>o(ye)[1];var Me=Lv(),ne=d(Me),Oe=d(ne),Ze=m(ne,2),B=d(Ze);L(()=>{M(Oe,(ke(),x(()=>f[ke()]||ke()))),M(B,ee())}),b(q,Me)});var X=m(Y,2),$e=m(d(X),2);We($e,5,()=>(s(),x(()=>Object.entries(s().relation_types))),Ge,(q,he)=>{var ye=Hi(()=>Vi(o(he),2));let ke=()=>o(ye)[0],ee=()=>o(ye)[1];var Me=ae(),ne=Z(Me);{var Oe=Ze=>{var B=Rv(),U=d(B),pe=d(U),Fe=m(U,2),de=d(Fe);L(()=>{xt(U,1,`distribution-label relation-${ke()??""}`,"svelte-1y1a8hs"),M(pe,(ke(),x(()=>g[ke()]||ke()))),M(de,ee())}),b(Ze,B)};D(ne,Ze=>{ee()>0&&Ze(Oe)})}b(q,Me)}),L(()=>{M(Q,(s(),x(()=>s().concepts))),M(Ie,(s(),x(()=>s().episodes))),M(we,(s(),x(()=>s().entities))),M(vt,(s(),x(()=>s().relations)))}),b(G,ge)},ue=G=>{var ge=Ov();b(G,ge)};D(F,G=>{s()?G(O):G(ue,!1)},!0)}b(E,C)};D(N,E=>{i()?E(P):E(w,!1)},!0)}b(p,_)};D(h,p=>{r()?p($):p(y,!1)})}b(e,v),jn(),l()}var Bv=z('<div class="loading svelte-p1hd11">Loading entities...</div>'),Vv=z('<div class="error svelte-p1hd11"> </div>'),Hv=z('<div class="empty svelte-p1hd11">No entities found</div>'),Uv=z('<button><span><!></span> <div class="entity-info svelte-p1hd11"><div class="entity-name svelte-p1hd11"> </div> <div class="entity-type svelte-p1hd11"> </div></div></button>'),Yv=z('<div class="entity-items svelte-p1hd11"></div>'),Xv=z('<div class="no-selection svelte-p1hd11">Select an entity to view details</div>'),jv=z('<div class="loading svelte-p1hd11">Loading details...</div>'),Gv=z('<button class="related-item entity-relation-item clickable svelte-p1hd11"><div class="relation-header svelte-p1hd11"><span class="relation-direction svelte-p1hd11"><!></span> <span class="relation-type svelte-p1hd11"> </span> <span class="relation-strength svelte-p1hd11"> </span></div> <div class="related-entity-info svelte-p1hd11"><span><!></span> <span class="entity-name svelte-p1hd11"> </span></div></button>'),Wv=z('<div class="detail-section svelte-p1hd11"><h4 class="svelte-p1hd11"> </h4> <div class="related-list svelte-p1hd11"></div></div>'),Kv=z('<div class="related-title svelte-p1hd11"> </div>'),Zv=z('<button class="related-item concept-item clickable svelte-p1hd11"><!> <div class="related-summary svelte-p1hd11"> </div> <div class="concept-footer svelte-p1hd11"><span> </span> <span class="open-indicator svelte-p1hd11">View <!></span></div></button>'),Qv=z('<div class="detail-section svelte-p1hd11"><h4 class="svelte-p1hd11"> </h4> <div class="related-list svelte-p1hd11"></div></div>'),Jv=z('<span class="episode-status consolidated svelte-p1hd11">Consolidated</span>'),ed=z('<span class="episode-status pending svelte-p1hd11">Pending</span>'),td=z('<span class="entity-tag svelte-p1hd11"> </span>'),nd=z('<div class="episode-entities svelte-p1hd11"></div>'),rd=z('<div class="episode-full-content svelte-p1hd11"> </div> <!> <div class="episode-footer svelte-p1hd11"><span class="episode-id svelte-p1hd11"> </span></div>',1),id=z('<div class="episode-preview svelte-p1hd11"> </div>'),sd=z('<button><div class="episode-header svelte-p1hd11"><span class="expand-indicator svelte-p1hd11"><!></span> <span class="episode-type-icon svelte-p1hd11"><!></span> <span class="episode-date svelte-p1hd11"> </span> <!></div> <!></button>'),ad=z('<div class="more-items svelte-p1hd11"> </div>'),od=z('<div class="detail-section svelte-p1hd11"><h4 class="svelte-p1hd11"> </h4> <div class="related-list svelte-p1hd11"><!> <!></div></div>'),ld=z('<div class="empty svelte-p1hd11">No related concepts or episodes found</div>'),cd=z("<!> <!> <!> <!>",1),ud=z('<div class="detail-content svelte-p1hd11"><div class="panel-header svelte-p1hd11"><h3 class="svelte-p1hd11"><span><!></span> </h3> <button class="close-btn svelte-p1hd11"><!></button></div> <div class="detail-meta svelte-p1hd11"><div class="meta-item svelte-p1hd11"><span class="meta-label svelte-p1hd11">Type</span> <span class="meta-value svelte-p1hd11"> </span></div> <div class="meta-item svelte-p1hd11"><span class="meta-label svelte-p1hd11">ID</span> <span class="meta-value mono svelte-p1hd11"> </span></div> <div class="meta-item svelte-p1hd11"><span class="meta-label svelte-p1hd11">Mentions</span> <span class="meta-value svelte-p1hd11"> </span></div></div> <!></div>'),fd=z('<div class="loading svelte-p1hd11">Loading concept...</div>'),vd=z('<div class="concept-section svelte-p1hd11"><h4 class="svelte-p1hd11">Conditions</h4> <p class="svelte-p1hd11"> </p></div>'),dd=z("<li> </li>"),hd=z('<div class="concept-section svelte-p1hd11"><h4 class="svelte-p1hd11">Exceptions</h4> <ul class="svelte-p1hd11"></ul></div>'),pd=z('<span class="tag svelte-p1hd11"> </span>'),_d=z('<div class="concept-section svelte-p1hd11"><h4 class="svelte-p1hd11">Tags</h4> <div class="tags svelte-p1hd11"></div></div>'),gd=z('<div><span class="relation-type svelte-p1hd11"> </span> <span class="relation-target svelte-p1hd11"> </span></div>'),md=z('<div class="concept-section svelte-p1hd11"><h4 class="svelte-p1hd11"> </h4> <div class="relations-list svelte-p1hd11"></div></div>'),yd=z('<div class="side-panel-content svelte-p1hd11"><div class="concept-summary svelte-p1hd11"> </div> <div class="concept-meta svelte-p1hd11"><div class="meta-item svelte-p1hd11"><span class="meta-label svelte-p1hd11">Confidence</span> <span> </span></div> <div class="meta-item svelte-p1hd11"><span class="meta-label svelte-p1hd11">Instance Count</span> <span class="meta-value svelte-p1hd11"> </span></div> <div class="meta-item svelte-p1hd11"><span class="meta-label svelte-p1hd11">Created</span> <span class="meta-value svelte-p1hd11"> </span></div></div> <!> <!> <!> <!></div>'),xd=z('<div class="concept-side-panel svelte-p1hd11"><div class="side-panel-header svelte-p1hd11"><button class="back-btn svelte-p1hd11"><!> Close</button> <h3 class="svelte-p1hd11"> </h3></div> <!></div>'),wd=z('<div class="entity-list svelte-p1hd11"><div class="header svelte-p1hd11"><h2 class="svelte-p1hd11">Entities</h2> <div class="filters svelte-p1hd11"><div class="search-bar svelte-p1hd11"><!> <input type="text" placeholder="Search entities..." class="search-input svelte-p1hd11"/></div> <select class="svelte-p1hd11"><option>All types</option><option>Files</option><option>Functions</option><option>Classes</option><option>Modules</option><option>Concepts</option><option>Subjects</option><option>People</option><option>Projects</option><option>Tools</option><option>Other</option></select></div></div> <div class="content svelte-p1hd11"><div class="list-panel svelte-p1hd11"><!></div> <div class="detail-panel svelte-p1hd11"><!></div> <!></div></div>');function $d(e,t){Xn(t,!1);const n=()=>at(or,"$currentDb",a),r=()=>at(Zo,"$entities",a),i=()=>at(ks,"$entitiesLoading",a),s=()=>at(ga,"$entitiesError",a),[a,l]=zr(),u=ze();let c=ze(""),f=ze(""),g=ze(!1),v=ze(null),h=ze([]),$=ze([]),y=ze(!1),p=ze({}),_=ze(null),N=ze(!1);Kr(()=>{R(g,!0),P()});async function P(){if(n()){ks.set(!0),ga.set(null);try{const T=await gv();Zo.set(T.entities),fv.set(T.total)}catch(T){ga.set(T instanceof Error?T.message:"Failed to load entities")}finally{ks.set(!1)}}}async function w(T){R(y,!0),R(h,[]),R($,[]);try{const[X,$e,q]=await Promise.all([Nc(T.id),Mc(T.id),Ac(T.id)]);R(v,X),R(h,$e.episodes),R($,q.concepts)}catch(X){console.error("Failed to load entity details:",X),R(v,T)}finally{R(y,!1)}}async function E(T){await w(T)}function C(){R(v,null),R(h,[]),R($,[]),R(p,{}),R(_,null)}async function F(T){if(o(p)[T])R(p,{...o(p),[T]:null});else try{const X=await Qs(T);R(p,{...o(p),[T]:X})}catch(X){console.error("Failed to fetch episode:",X)}}async function O(T){R(N,!0);try{R(_,await Va(T))}catch(X){console.error("Failed to fetch concept:",X)}finally{R(N,!1)}}function ue(){R(_,null)}const G={file:"File",function:"Function",class:"Class",module:"Module",concept:"Concept",subject:"Subject",person:"Person",project:"Project",tool:"Tool",other:"Other"},ge={file:Dc,function:Pc,class:Tc,module:Lc,concept:na,subject:Sc,person:Fc,project:Cc,tool:qc,other:_o},Ve={observation:ea,decision:ra,question:ji,meta:Js,preference:ta};function Re(T){return new Date(T).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}function k(T){return`${Math.round(T*100)}%`}function I(T){return T>=.7?"high":T>=.4?"medium":"low"}function A(T){if(T.display_name)return T.display_name;const X=T.id.indexOf(":");return X>=0?T.id.slice(X+1):T.id}Un(()=>(o(g),n()),()=>{o(g)&&n()&&(P(),R(v,null),R(h,[]),R($,[]))}),Un(()=>(r(),o(c),o(f)),()=>{R(u,r().filter(T=>{if(o(c)&&T.type!==o(c))return!1;if(o(f).length>=2){const X=o(f).toLowerCase();return T.id.toLowerCase().includes(X)||T.display_name&&T.display_name.toLowerCase().includes(X)}return!0}).sort((T,X)=>(T.display_name||T.id).localeCompare(X.display_name||X.id)))}),Gr(),ar();var H=wd(),Q=d(H),j=m(d(Q),2),W=d(j),me=d(W);po(me,{size:14,class:"search-icon"});var Ce=m(me,2),it=m(W,2);L(()=>{o(c),Cs(()=>{})});var Ie=d(it);Ie.value=Ie.__value="";var Pe=m(Ie);Pe.value=Pe.__value="file";var lt=m(Pe);lt.value=lt.__value="function";var ut=m(lt);ut.value=ut.__value="class";var gt=m(ut);gt.value=gt.__value="module";var yt=m(gt);yt.value=yt.__value="concept";var we=m(yt);we.value=we.__value="subject";var $t=m(we);$t.value=$t.__value="person";var Dt=m($t);Dt.value=Dt.__value="project";var It=m(Dt);It.value=It.__value="tool";var K=m(It);K.value=K.__value="other";var ve=m(Q,2),vt=d(ve),bt=d(vt);{var re=T=>{var X=Bv();b(T,X)},ct=T=>{var X=ae(),$e=Z(X);{var q=ye=>{var ke=Vv(),ee=d(ke);L(()=>M(ee,s())),b(ye,ke)},he=ye=>{var ke=ae(),ee=Z(ke);{var Me=Oe=>{var Ze=Hv();b(Oe,Ze)},ne=Oe=>{var Ze=Yv();We(Ze,5,()=>o(u),Ge,(B,U)=>{var pe=Uv();let Fe;pe.__click=()=>w(o(U));var de=d(pe),He=d(de);Bn(He,()=>ge[o(U).type],(Ye,ie)=>{ie(Ye,{size:16})});var J=m(de,2),be=d(J),Ee=d(be),De=m(be,2),Ue=d(De);L(Ye=>{var ie;Fe=xt(pe,1,"entity-item svelte-p1hd11",null,Fe,{selected:((ie=o(v))==null?void 0:ie.id)===o(U).id}),xt(de,1,`entity-icon icon-${o(U),x(()=>o(U).type)??""}`,"svelte-p1hd11"),M(Ee,Ye),M(Ue,(o(U),x(()=>G[o(U).type])))},[()=>(o(U),x(()=>A(o(U))))]),b(B,pe)}),b(Oe,Ze)};D(ee,Oe=>{o(u),x(()=>o(u).length===0)?Oe(Me):Oe(ne,!1)},!0)}b(ye,ke)};D($e,ye=>{s()?ye(q):ye(he,!1)},!0)}b(T,X)};D(bt,T=>{i()?T(re):T(ct,!1)})}var pt=m(vt,2),Tt=d(pt);{var Gt=T=>{var X=Xv();b(T,X)},jt=T=>{var X=ud(),$e=d(X),q=d($e),he=d(q),ye=d(he);Bn(ye,()=>ge[o(v).type],(Ue,Ye)=>{Ye(Ue,{size:24})});var ke=m(he),ee=m(q,2);ee.__click=C;var Me=d(ee);Bc(Me,{size:20});var ne=m($e,2),Oe=d(ne),Ze=m(d(Oe),2),B=d(Ze),U=m(Oe,2),pe=m(d(U),2),Fe=d(pe),de=m(U,2),He=m(d(de),2),J=d(He),be=m(ne,2);{var Ee=Ue=>{var Ye=jv();b(Ue,Ye)},De=Ue=>{var Ye=cd(),ie=Z(Ye);{var oe=fe=>{var le=Wv(),te=d(le),_t=d(te),zt=m(te,2);We(zt,5,()=>(o(v),x(()=>o(v).relations)),Ge,(kt,xe)=>{var Lt=ae(),ft=Z(Lt);{var ce=Je=>{var Nt=Gv();Nt.__click=()=>E(o(xe).related_entity);var Wt=d(Nt),Ot=d(Wt),rn=d(Ot);{var qe=mt=>{si(mt,{size:14})},Kt=mt=>{si(mt,{size:14,style:"transform: rotate(180deg)"})};D(rn,mt=>{o(xe),x(()=>o(xe).direction==="outgoing")?mt(qe):mt(Kt,!1)})}var Be=m(Ot,2),Te=d(Be),Et=m(Be,2),sn=d(Et),an=m(Wt,2),Zt=d(an),Qt=d(Zt);Bn(Qt,()=>ge[o(xe).related_entity.type],(mt,Xe)=>{Xe(mt,{size:14})});var on=m(Zt,2),Ft=d(on);L(mt=>{M(Te,(o(xe),x(()=>o(xe).relation_type))),M(sn,`${mt??""}%`),xt(Zt,1,`entity-icon icon-${o(xe),x(()=>o(xe).related_entity.type)??""}`,"svelte-p1hd11"),M(Ft,(o(xe),x(()=>o(xe).related_entity.display_name||o(xe).related_entity.id)))},[()=>(o(xe),x(()=>Math.round(o(xe).strength*100)))]),b(Je,Nt)};D(ft,Je=>{o(xe),x(()=>o(xe).related_entity)&&Je(ce)})}b(kt,Lt)}),L(()=>M(_t,`Related Entities (${o(v),x(()=>o(v).relations.length)??""})`)),b(fe,le)};D(ie,fe=>{o(v),x(()=>{var le;return((le=o(v))==null?void 0:le.relations)&&o(v).relations.length>0})&&fe(oe)})}var _e=m(ie,2);{var ot=fe=>{var le=Qv(),te=d(le),_t=d(te),zt=m(te,2);We(zt,5,()=>o($),Ge,(kt,xe)=>{var Lt=Zv();Lt.__click=()=>O(o(xe).id);var ft=d(Lt);{var ce=Be=>{var Te=Kv(),Et=d(Te);L(()=>M(Et,(o(xe),x(()=>o(xe).title)))),b(Be,Te)};D(ft,Be=>{o(xe),x(()=>o(xe).title)&&Be(ce)})}var Je=m(ft,2),Nt=d(Je),Wt=m(Je,2),Ot=d(Wt),rn=d(Ot),qe=m(Ot,2),Kt=m(d(qe));si(Kt,{size:12,style:"display: inline-block; vertical-align: middle;"}),L((Be,Te)=>{M(Nt,(o(xe),x(()=>o(xe).summary))),xt(Ot,1,`related-meta confidence ${Be??""}`,"svelte-p1hd11"),M(rn,`${Te??""} confidence`)},[()=>(o(xe),x(()=>I(o(xe).confidence))),()=>(o(xe),x(()=>k(o(xe).confidence)))]),b(kt,Lt)}),L(()=>M(_t,`Related Concepts (${o($),x(()=>o($).length)??""})`)),b(fe,le)};D(_e,fe=>{o($),x(()=>o($).length>0)&&fe(ot)})}var se=m(_e,2);{var Se=fe=>{var le=od(),te=d(le),_t=d(te),zt=m(te,2),kt=d(zt);We(kt,1,()=>(o(h),x(()=>o(h).slice(0,20))),Ge,(ft,ce)=>{var Je=sd();let Nt;Je.__click=()=>F(o(ce).id);var Wt=d(Je),Ot=d(Wt),rn=d(Ot);{var qe=Xe=>{vo(Xe,{size:14})},Kt=Xe=>{ho(Xe,{size:14})};D(rn,Xe=>{o(p),o(ce),x(()=>o(p)[o(ce).id])?Xe(qe):Xe(Kt,!1)})}var Be=m(Ot,2),Te=d(Be);Bn(Te,()=>Ve[o(ce).episode_type],(Xe,Mt)=>{Mt(Xe,{size:14})});var Et=m(Be,2),sn=d(Et),an=m(Et,2);{var Zt=Xe=>{var Mt=Jv();b(Xe,Mt)},Qt=Xe=>{var Mt=ed();b(Xe,Mt)};D(an,Xe=>{o(ce),x(()=>o(ce).consolidated)?Xe(Zt):Xe(Qt,!1)})}var on=m(Wt,2);{var Ft=Xe=>{var Mt=rd(),lr=Z(Mt),cr=d(lr),Zr=m(lr,2);{var bi=st=>{var Le=nd();We(Le,5,()=>(o(p),o(ce),x(()=>o(p)[o(ce).id].entity_ids)),Ge,(qt,mn)=>{var ur=td(),Jr=d(ur);L(()=>M(Jr,o(mn))),b(qt,ur)}),b(st,Le)};D(Zr,st=>{o(p),o(ce),x(()=>o(p)[o(ce).id].entity_ids&&o(p)[o(ce).id].entity_ids.length>0)&&st(bi)})}var Qr=m(Zr,2),ki=d(Qr),Ei=d(ki);L(st=>{M(cr,(o(p),o(ce),x(()=>o(p)[o(ce).id].content))),M(Ei,`ID: ${st??""}`)},[()=>(o(ce),x(()=>o(ce).id.slice(0,8)))]),b(Xe,Mt)},mt=Xe=>{var Mt=id(),lr=d(Mt);L(cr=>M(lr,`${cr??""}${o(ce),x(()=>o(ce).content.length>200?"...":"")??""}`),[()=>(o(ce),x(()=>o(ce).content.slice(0,200)))]),b(Xe,Mt)};D(on,Xe=>{o(p),o(ce),x(()=>o(p)[o(ce).id])?Xe(Ft):Xe(mt,!1)})}L(Xe=>{Nt=xt(Je,1,"related-item episode-item expandable svelte-p1hd11",null,Nt,{expanded:o(p)[o(ce).id]}),M(sn,Xe)},[()=>(o(ce),x(()=>Re(o(ce).timestamp)))]),b(ft,Je)});var xe=m(kt,2);{var Lt=ft=>{var ce=ad(),Je=d(ce);L(()=>M(Je,`+${o(h),x(()=>o(h).length-20)??""} more episodes`)),b(ft,ce)};D(xe,ft=>{o(h),x(()=>o(h).length>20)&&ft(Lt)})}L(()=>M(_t,`Mentioning Episodes (${o(h),x(()=>o(h).length)??""})`)),b(fe,le)};D(se,fe=>{o(h),x(()=>o(h).length>0)&&fe(Se)})}var dt=m(se,2);{var Pt=fe=>{var le=ld();b(fe,le)};D(dt,fe=>{o($),o(h),x(()=>o($).length===0&&o(h).length===0)&&fe(Pt)})}b(Ue,Ye)};D(be,Ue=>{o(y)?Ue(Ee):Ue(De,!1)})}L(()=>{xt(he,1,`entity-type-icon icon-${o(v),x(()=>o(v).type)??""}`,"svelte-p1hd11"),M(ke,` ${o(v),x(()=>o(v).display_name||o(v).id)??""}`),M(B,(o(v),x(()=>G[o(v).type]))),M(Fe,(o(v),x(()=>o(v).id))),M(J,(o(v),x(()=>o(v).mention_count||0)))}),b(T,X)};D(Tt,T=>{o(v)?T(jt,!1):T(Gt)})}var V=m(pt,2);{var Y=T=>{var X=xd(),$e=d(X),q=d($e);q.__click=ue;var he=d(q);si(he,{size:16,style:"transform: rotate(180deg)"});var ye=m(q,2),ke=d(ye),ee=m($e,2);{var Me=Oe=>{var Ze=fd();b(Oe,Ze)},ne=Oe=>{var Ze=yd(),B=d(Ze),U=d(B),pe=m(B,2),Fe=d(pe),de=m(d(Fe),2),He=d(de),J=m(Fe,2),be=m(d(J),2),Ee=d(be),De=m(J,2),Ue=m(d(De),2),Ye=d(Ue),ie=m(pe,2);{var oe=fe=>{var le=vd(),te=m(d(le),2),_t=d(te);L(()=>M(_t,(o(_),x(()=>o(_).conditions)))),b(fe,le)};D(ie,fe=>{o(_),x(()=>o(_).conditions)&&fe(oe)})}var _e=m(ie,2);{var ot=fe=>{var le=hd(),te=m(d(le),2);We(te,5,()=>(o(_),x(()=>o(_).exceptions)),Ge,(_t,zt)=>{var kt=dd(),xe=d(kt);L(()=>M(xe,o(zt))),b(_t,kt)}),b(fe,le)};D(_e,fe=>{o(_),x(()=>o(_).exceptions&&o(_).exceptions.length>0)&&fe(ot)})}var se=m(_e,2);{var Se=fe=>{var le=_d(),te=m(d(le),2);We(te,5,()=>(o(_),x(()=>o(_).tags)),Ge,(_t,zt)=>{var kt=pd(),xe=d(kt);L(()=>M(xe,o(zt))),b(_t,kt)}),b(fe,le)};D(se,fe=>{o(_),x(()=>o(_).tags&&o(_).tags.length>0)&&fe(Se)})}var dt=m(se,2);{var Pt=fe=>{var le=md(),te=d(le),_t=d(te),zt=m(te,2);We(zt,5,()=>(o(_),x(()=>o(_).relations)),Ge,(kt,xe)=>{var Lt=gd(),ft=d(Lt),ce=d(ft),Je=m(ft,2),Nt=d(Je);L(()=>{xt(Lt,1,`relation-item relation-${o(xe),x(()=>o(xe).type)??""}`,"svelte-p1hd11"),M(ce,(o(xe),x(()=>o(xe).type))),M(Nt,(o(xe),x(()=>o(xe).target_id)))}),b(kt,Lt)}),L(()=>M(_t,`Relations (${o(_),x(()=>o(_).relations.length)??""})`)),b(fe,le)};D(dt,fe=>{o(_),x(()=>o(_).relations&&o(_).relations.length>0)&&fe(Pt)})}L((fe,le,te)=>{M(U,(o(_),x(()=>o(_).summary))),xt(de,1,`meta-value confidence ${fe??""}`,"svelte-p1hd11"),M(He,le),M(Ee,(o(_),x(()=>o(_).instance_count))),M(Ye,te)},[()=>(o(_),x(()=>I(o(_).confidence))),()=>(o(_),x(()=>k(o(_).confidence))),()=>(o(_),x(()=>Re(o(_).created_at)))]),b(Oe,Ze)};D(ee,Oe=>{o(N)?Oe(Me):Oe(ne,!1)})}L(()=>M(ke,(o(_),x(()=>o(_).title||"Concept Detail")))),b(T,X)};D(V,T=>{o(_)&&T(Y)})}co(Ce,()=>o(f),T=>R(f,T)),Ls(it,()=>o(c),T=>R(c,T)),b(e,H),jn(),l()}Er(["click"]);var bd=z('<div class="error-toast svelte-kxner8"> </div>'),kd=z('<div class="loading svelte-kxner8">Loading concepts...</div>'),Ed=z('<div class="error svelte-kxner8"> </div>'),zd=z('<div class="empty svelte-kxner8">No concepts found</div>'),Nd=z('<div class="concept-title svelte-kxner8"> </div>'),Md=z('<span class="tag svelte-kxner8"> </span>'),Ad=z('<div class="concept-tags svelte-kxner8"></div>'),Sd=z('<button><div class="concept-header svelte-kxner8"><span> </span></div> <!> <div class="concept-summary svelte-kxner8"> </div> <!></button>'),Td=z('<div class="concept-items svelte-kxner8"></div> <div class="pagination svelte-kxner8"><button class="svelte-kxner8">Previous</button> <span> </span> <button class="svelte-kxner8">Next</button></div>',1),Cd=z('<div class="no-selection svelte-kxner8">Select a concept to view details</div>'),Pd=z('<button class="back-btn svelte-kxner8"><!></button>'),Dd=z('<div class="detail-section svelte-kxner8"><h4 class="svelte-kxner8">Conditions</h4> <p class="conditions svelte-kxner8"> </p></div>'),Ld=z('<li class="svelte-kxner8"> </li>'),Rd=z('<div class="detail-section svelte-kxner8"><h4 class="svelte-kxner8">Exceptions</h4> <ul class="exceptions svelte-kxner8"></ul></div>'),Id=z('<span class="relation-summary svelte-kxner8"> </span>'),Od=z('<span class="relation-context svelte-kxner8"> </span>'),Fd=z('<button><span class="relation-type svelte-kxner8"> </span> <span class="relation-target svelte-kxner8"> </span> <!> <!> <span class="relation-arrow svelte-kxner8"><!></span></button>'),qd=z('<div class="detail-section svelte-kxner8"><h4 class="svelte-kxner8">Relations</h4> <div class="relations-list svelte-kxner8"></div></div>'),Bd=z('<span class="pending-badge svelte-kxner8">Pending</span>'),Vd=z('<div class="episode-title svelte-kxner8"> </div>'),Hd=z('<span class="entity-tag svelte-kxner8"> </span>'),Ud=z('<div class="episode-entities svelte-kxner8"></div>'),Yd=z('<span class="episode-confidence"> </span>'),Xd=z('<div class="episode-expanded svelte-kxner8"><div class="episode-header svelte-kxner8"><span> </span> <span class="episode-date svelte-kxner8"> </span> <!></div> <!> <div class="episode-full-content svelte-kxner8"> </div> <!> <div class="episode-footer svelte-kxner8"><span class="episode-id-label svelte-kxner8"> </span> <!></div></div>'),jd=z('<button><div class="episode-collapsed svelte-kxner8"><span class="episode-icon svelte-kxner8"><!></span> <span> </span> <span class="episode-chevron svelte-kxner8"><!></span></div> <!></button>'),Gd=z('<div class="more-episodes svelte-kxner8"> </div>'),Wd=z('<div class="detail-section svelte-kxner8"><h4 class="svelte-kxner8"> </h4> <div class="source-episodes svelte-kxner8"><!> <!></div></div>'),Kd=z('<span class="episode-id svelte-kxner8"> </span>'),Zd=z('<div class="detail-section svelte-kxner8"><h4 class="svelte-kxner8"> </h4> <div class="source-episodes-ids svelte-kxner8"></div></div>'),Qd=z('<span class="tag svelte-kxner8"> </span>'),Jd=z('<div class="detail-section svelte-kxner8"><h4 class="svelte-kxner8">Tags</h4> <div class="tags svelte-kxner8"></div></div>'),eh=z('<div><div class="detail-content svelte-kxner8"><div class="panel-header svelte-kxner8"><h3 class="svelte-kxner8"><!> </h3> <button class="close-btn svelte-kxner8"><!></button></div> <div class="detail-section svelte-kxner8"><h4 class="svelte-kxner8">Summary</h4> <p> </p></div> <div class="detail-meta svelte-kxner8"><div class="meta-item svelte-kxner8"><span class="meta-label svelte-kxner8">Confidence</span> <span> </span></div> <div class="meta-item svelte-kxner8"><span class="meta-label svelte-kxner8">Instances</span> <span class="meta-value svelte-kxner8"> </span></div></div> <!> <!> <!> <!> <!></div></div>'),th=z('<div class="concept-list svelte-kxner8"><!> <div class="header svelte-kxner8"><h2 class="svelte-kxner8">Concepts</h2> <div class="search-bar svelte-kxner8"><!> <input type="text" placeholder="Search concepts..." class="svelte-kxner8"/></div></div> <div class="content svelte-kxner8"><div class="list-panel svelte-kxner8"><!></div> <div class="details-container svelte-kxner8"><!></div></div></div>');function nh(e,t){Xn(t,!1);const n=()=>at(or,"$currentDb",u),r=()=>at($s,"$conceptsLoading",u),i=()=>at(pa,"$conceptsError",u),s=()=>at(jo,"$concepts",u),a=()=>at(Wn,"$conceptPath",u),l=()=>at(Go,"$conceptsTotal",u),[u,c]=zr();let f=ze(""),g=ze(0);const v=20;let h=ze(!1),$=ze(),y=ze({}),p=ze(null);Kr(()=>{R(h,!0),N()});function _(){o(p)&&clearTimeout(o(p)),R(p,setTimeout(()=>{R(g,0),N()},300))}async function N(){if(n()){$s.set(!0),pa.set(null);try{const K=await pv({offset:o(g)*v,limit:v,search:o(f)||void 0});jo.set(K.concepts),Go.set(K.total)}catch(K){pa.set(K instanceof Error?K.message:"Failed to load concepts")}finally{$s.set(!1)}}}async function P(K){try{const ve=await Va(K.id);Wn.set([ve])}catch(ve){console.error("Failed to fetch concept:",ve),Wn.set([K])}}let w=ze(null);async function E(K,ve){R(w,null);try{const vt=await Va(K);Wn.update(bt=>[...bt.slice(0,ve+1),vt]),setTimeout(()=>{o($)&&gf($,o($).scrollLeft=o($).scrollWidth)},50)}catch{R(w,`Concept "${K}" not found`),setTimeout(()=>R(w,null),3e3)}}function C(K){Wn.update(ve=>ve.slice(0,K+1))}function F(K){K===0?Wn.set([]):Wn.update(ve=>ve.slice(0,K))}function O(){o(p)&&clearTimeout(o(p)),R(g,0),N()}function ue(){hi(g),N()}function G(){o(g)>0&&(hi(g,-1),N())}function ge(K){return`${Math.round(K*100)}%`}function Ve(K){return K>=.7?"high":K>=.4?"medium":"low"}const Re={implies:"Implies",contradicts:"Contradicts",specializes:"Specializes",generalizes:"Generalizes",causes:"Causes",correlates:"Correlates",part_of:"Part of",context_of:"Context of"},k={observation:ea,decision:ra,question:ji,meta:Js,preference:ta},I={observation:"Observation",decision:"Decision",question:"Question",meta:"Meta",preference:"Preference"};function A(K){return new Date(K).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric",hour:"2-digit",minute:"2-digit"})}async function H(K){if(o(y)[K])R(y,{...o(y),[K]:null});else try{const ve=await Qs(K);R(y,{...o(y),[K]:ve})}catch(ve){console.error("Failed to fetch episode:",ve)}}Un(()=>(o(h),n(),Wn),()=>{o(h)&&n()&&(N(),Wn.set([]))}),Un(()=>(o(h),n(),o(f)),()=>{o(h)&&n()&&o(f).length>=2&&_()}),Un(()=>(o(h),n(),o(f),o(p)),()=>{o(h)&&n()&&o(f)===""&&(o(p)&&clearTimeout(o(p)),R(g,0),N())}),Gr(),ar();var Q=th(),j=d(Q);{var W=K=>{var ve=bd(),vt=d(ve);L(()=>M(vt,o(w))),b(K,ve)};D(j,K=>{o(w)&&K(W)})}var me=m(j,2),Ce=m(d(me),2),it=d(Ce);po(it,{size:14,class:"search-icon"});var Ie=m(it,2);Ie.__keydown=K=>K.key==="Enter"&&O();var Pe=m(me,2),lt=d(Pe),ut=d(lt);{var gt=K=>{var ve=kd();b(K,ve)},yt=K=>{var ve=ae(),vt=Z(ve);{var bt=ct=>{var pt=Ed(),Tt=d(pt);L(()=>M(Tt,i())),b(ct,pt)},re=ct=>{var pt=ae(),Tt=Z(pt);{var Gt=V=>{var Y=zd();b(V,Y)},jt=V=>{var Y=Td(),T=Z(Y);We(T,5,s,Ge,(ke,ee)=>{var Me=Sd();let ne;Me.__click=()=>P(o(ee));var Oe=d(Me),Ze=d(Oe),B=d(Ze),U=m(Oe,2);{var pe=be=>{var Ee=Nd(),De=d(Ee);L(()=>M(De,(o(ee),x(()=>o(ee).title)))),b(be,Ee)};D(U,be=>{o(ee),x(()=>o(ee).title)&&be(pe)})}var Fe=m(U,2),de=d(Fe),He=m(Fe,2);{var J=be=>{var Ee=Ad();We(Ee,5,()=>(o(ee),x(()=>o(ee).tags.slice(0,3))),Ge,(De,Ue)=>{var Ye=Md(),ie=d(Ye);L(()=>M(ie,o(Ue))),b(De,Ye)}),b(be,Ee)};D(He,be=>{o(ee),x(()=>o(ee).tags.length>0)&&be(J)})}L((be,Ee)=>{ne=xt(Me,1,"concept-item svelte-kxner8",null,ne,{selected:a().length>0&&a()[0].id===o(ee).id}),xt(Ze,1,`concept-confidence confidence-${be??""}`,"svelte-kxner8"),M(B,Ee),M(de,(o(ee),x(()=>o(ee).summary)))},[()=>(o(ee),x(()=>Ve(o(ee).confidence))),()=>(o(ee),x(()=>ge(o(ee).confidence)))]),b(ke,Me)});var X=m(T,2),$e=d(X);$e.__click=G;var q=m($e,2),he=d(q),ye=m(q,2);ye.__click=ue,L(ke=>{$e.disabled=o(g)===0,M(he,`Page ${o(g)+1} of ${ke??""}`),ye.disabled=(o(g)+1)*v>=l()},[()=>(l(),x(()=>Math.ceil(l()/v)))]),b(V,Y)};D(Tt,V=>{s(),x(()=>s().length===0)?V(Gt):V(jt,!1)},!0)}b(ct,pt)};D(vt,ct=>{i()?ct(bt):ct(re,!1)},!0)}b(K,ve)};D(ut,K=>{r()?K(gt):K(yt,!1)})}var we=m(lt,2),$t=d(we);{var Dt=K=>{var ve=Cd();b(K,ve)},It=K=>{var ve=ae(),vt=Z(ve);We(vt,1,a,Ge,(bt,re,ct)=>{var pt=eh();xt(pt,1,"detail-panel svelte-kxner8",null,{},{first:ct===0});var Tt=d(pt),Gt=d(Tt),jt=d(Gt),V=d(jt);{var Y=ie=>{var oe=Pd();oe.__click=()=>C(ct-1);var _e=d(oe);si(_e,{size:16,style:"transform: rotate(180deg)"}),b(ie,oe)};D(V,ie=>{ct>0&&ie(Y)})}var T=m(V),X=m(jt,2);X.__click=()=>F(ct);var $e=d(X);Bc($e,{size:20});var q=m(Gt,2),he=m(d(q),2),ye=d(he),ke=m(q,2),ee=d(ke),Me=m(d(ee),2),ne=d(Me),Oe=m(ee,2),Ze=m(d(Oe),2),B=d(Ze),U=m(ke,2);{var pe=ie=>{var oe=Dd(),_e=m(d(oe),2),ot=d(_e);L(()=>M(ot,(o(re),x(()=>o(re).conditions)))),b(ie,oe)};D(U,ie=>{o(re),x(()=>o(re).conditions)&&ie(pe)})}var Fe=m(U,2);{var de=ie=>{var oe=Rd(),_e=m(d(oe),2);We(_e,5,()=>(o(re),x(()=>o(re).exceptions)),Ge,(ot,se)=>{var Se=Ld(),dt=d(Se);L(()=>M(dt,o(se))),b(ot,Se)}),b(ie,oe)};D(Fe,ie=>{o(re),x(()=>o(re).exceptions.length>0)&&ie(de)})}var He=m(Fe,2);{var J=ie=>{var oe=qd(),_e=m(d(oe),2);We(_e,5,()=>(o(re),x(()=>o(re).relations)),Ge,(ot,se)=>{var Se=Fd();Se.__click=()=>E(o(se).target_id,ct);var dt=d(Se),Pt=d(dt),fe=m(dt,2),le=d(fe),te=m(fe,2);{var _t=ft=>{var ce=Id(),Je=d(ce);L(()=>M(Je,(o(se),x(()=>o(se).target_summary)))),b(ft,ce)};D(te,ft=>{o(se),x(()=>o(se).target_summary)&&ft(_t)})}var zt=m(te,2);{var kt=ft=>{var ce=Od(),Je=d(ce);L(()=>M(Je,`(${o(se),x(()=>o(se).context)??""})`)),b(ft,ce)};D(zt,ft=>{o(se),x(()=>o(se).context)&&ft(kt)})}var xe=m(zt,2),Lt=d(xe);si(Lt,{size:14}),L(ft=>{xt(Se,1,`relation-item relation-${o(se),x(()=>o(se).type)??""}`,"svelte-kxner8"),M(Pt,(o(se),x(()=>Re[o(se).type]))),M(le,ft)},[()=>(o(se),x(()=>o(se).target_id.substring(0,8)))]),b(ot,Se)}),b(ie,oe)};D(He,ie=>{o(re),x(()=>o(re).relations.length>0)&&ie(J)})}var be=m(He,2);{var Ee=ie=>{var oe=Wd(),_e=d(oe),ot=d(_e),se=m(_e,2),Se=d(se);We(Se,1,()=>(o(re),x(()=>o(re).source_episodes_data)),Ge,(fe,le)=>{const te=ss(()=>(o(y),o(le),x(()=>o(y)[o(le).id])));var _t=jd();let zt;_t.__click=()=>H(o(le).id);var kt=d(_t),xe=d(kt),Lt=d(xe);Bn(Lt,()=>k[o(le).type],(Be,Te)=>{Te(Be,{size:16})});var ft=m(xe,2);let ce;var Je=d(ft),Nt=m(ft,2),Wt=d(Nt);{var Ot=Be=>{vo(Be,{size:14})},rn=Be=>{ho(Be,{size:14})};D(Wt,Be=>{o(te)?Be(Ot):Be(rn,!1)})}var qe=m(kt,2);{var Kt=Be=>{var Te=Xd(),Et=d(Te),sn=d(Et),an=d(sn),Zt=m(sn,2),Qt=d(Zt),on=m(Zt,2);{var Ft=Le=>{var qt=Bd();b(Le,qt)};D(on,Le=>{St(o(te)),x(()=>!o(te).consolidated)&&Le(Ft)})}var mt=m(Et,2);{var Xe=Le=>{var qt=Vd(),mn=d(qt);L(()=>M(mn,(St(o(te)),x(()=>o(te).title)))),b(Le,qt)};D(mt,Le=>{St(o(te)),x(()=>o(te).title)&&Le(Xe)})}var Mt=m(mt,2),lr=d(Mt),cr=m(Mt,2);{var Zr=Le=>{var qt=Ud();We(qt,5,()=>(St(o(te)),x(()=>o(te).entity_ids)),Ge,(mn,ur)=>{var Jr=Hd(),la=d(Jr);L(()=>M(la,o(ur))),b(mn,Jr)}),b(Le,qt)};D(cr,Le=>{St(o(te)),x(()=>o(te).entity_ids.length>0)&&Le(Zr)})}var bi=m(cr,2),Qr=d(bi),ki=d(Qr),Ei=m(Qr,2);{var st=Le=>{var qt=Yd(),mn=d(qt);L(ur=>M(mn,`Confidence: ${ur??""}%`),[()=>(St(o(te)),x(()=>Math.round(o(te).confidence*100)))]),b(Le,qt)};D(Ei,Le=>{St(o(te)),x(()=>o(te).confidence<1)&&Le(st)})}L(Le=>{xt(sn,1,`episode-type type-${St(o(te)),x(()=>o(te).episode_type)??""}`,"svelte-kxner8"),M(an,(St(o(te)),x(()=>I[o(te).episode_type]))),M(Qt,Le),M(lr,(St(o(te)),x(()=>o(te).content))),M(ki,`ID: ${St(o(te)),x(()=>o(te).id)??""}`)},[()=>(St(o(te)),x(()=>A(o(te).timestamp)))]),b(Be,Te)};D(qe,Be=>{o(te)&&Be(Kt)})}L(()=>{zt=xt(_t,1,"episode-item svelte-kxner8",null,zt,{expanded:!!o(te)}),ce=xt(ft,1,"episode-content svelte-kxner8",null,ce,{expanded:!!o(te)}),M(Je,(o(le),x(()=>o(le).title||o(le).content)))}),b(fe,_t)});var dt=m(Se,2);{var Pt=fe=>{var le=Gd(),te=d(le);L(()=>M(te,`+${o(re),x(()=>o(re).source_episodes.length-10)??""} more episodes`)),b(fe,le)};D(dt,fe=>{o(re),x(()=>o(re).source_episodes.length>10)&&fe(Pt)})}L(()=>M(ot,`Source Episodes (${o(re),x(()=>o(re).source_episodes.length)??""})`)),b(ie,oe)},De=ie=>{var oe=ae(),_e=Z(oe);{var ot=se=>{var Se=Zd(),dt=d(Se),Pt=d(dt),fe=m(dt,2);We(fe,5,()=>(o(re),x(()=>o(re).source_episodes)),Ge,(le,te)=>{var _t=Kd(),zt=d(_t);L(()=>M(zt,o(te))),b(le,_t)}),L(()=>M(Pt,`Source Episodes (${o(re),x(()=>o(re).source_episodes.length)??""})`)),b(se,Se)};D(_e,se=>{o(re),x(()=>o(re).source_episodes.length>0)&&se(ot)},!0)}b(ie,oe)};D(be,ie=>{o(re),x(()=>o(re).source_episodes_data&&o(re).source_episodes_data.length>0)?ie(Ee):ie(De,!1)})}var Ue=m(be,2);{var Ye=ie=>{var oe=Jd(),_e=m(d(oe),2);We(_e,5,()=>(o(re),x(()=>o(re).tags)),Ge,(ot,se)=>{var Se=Qd(),dt=d(Se);L(()=>M(dt,o(se))),b(ot,Se)}),b(ie,oe)};D(Ue,ie=>{o(re),x(()=>o(re).tags.length>0)&&ie(Ye)})}L((ie,oe)=>{M(T,` ${o(re),x(()=>o(re).title||"Concept Details")??""}`),M(ye,(o(re),x(()=>o(re).summary))),xt(Me,1,`meta-value confidence-${ie??""}`,"svelte-kxner8"),M(ne,oe),M(B,(o(re),x(()=>o(re).instance_count)))},[()=>(o(re),x(()=>Ve(o(re).confidence))),()=>(o(re),x(()=>ge(o(re).confidence)))]),b(bt,pt)}),b(K,ve)};D($t,K=>{a(),x(()=>a().length===0)?K(Dt):K(It,!1)})}uo(we,K=>R($,K),()=>o($)),co(Ie,()=>o(f),K=>R(f,K)),b(e,Q),jn(),c()}Er(["keydown","click"]);var rh=z('<div class="loading svelte-kaumpu">Loading episodes...</div>'),ih=z('<div class="error svelte-kaumpu"> </div>'),sh=z('<div class="empty svelte-kaumpu">No episodes found</div>'),ah=z('<span class="pending-badge svelte-kaumpu">Pending</span>'),oh=z('<div class="episode-title svelte-kaumpu"> </div>'),lh=z('<span class="entity-tag svelte-kaumpu"> </span>'),ch=z('<div class="episode-entities svelte-kaumpu"></div>'),uh=z('<span class="episode-confidence"> </span>'),fh=z('<div><div class="timeline-marker svelte-kaumpu"><span class="episode-icon"><!></span></div> <div class="timeline-content svelte-kaumpu"><div class="episode-header svelte-kaumpu"><span> </span> <span class="episode-date svelte-kaumpu"> </span> <!></div> <!> <div class="episode-content svelte-kaumpu"> </div> <!> <div class="episode-footer svelte-kaumpu"><span class="episode-id svelte-kaumpu"> </span> <!></div></div></div>'),vh=z('<div class="timeline svelte-kaumpu"></div> <div class="pagination svelte-kaumpu"><button class="svelte-kaumpu">Previous</button> <span> </span> <button class="svelte-kaumpu">Next</button></div>',1),dh=z('<div class="episode-timeline svelte-kaumpu"><div class="header svelte-kaumpu"><h2 class="svelte-kaumpu">Episodes</h2> <div class="filters svelte-kaumpu"><div class="search-bar svelte-kaumpu"><div class="search-icon svelte-kaumpu"><!></div> <input type="text" placeholder="Search episodes..." class="svelte-kaumpu"/></div> <div class="select-wrapper svelte-kaumpu"><!> <select class="svelte-kaumpu"><option>All types</option><option>Observations</option><option>Decisions</option><option>Questions</option><option>Meta</option><option>Preferences</option></select></div> <div class="select-wrapper svelte-kaumpu"><select class="svelte-kaumpu"><option>All status</option><option>Consolidated</option><option>Pending</option></select></div></div></div> <!></div>');function hh(e,t){Xn(t,!1);const n=()=>at(or,"$currentDb",l),r=()=>at(bs,"$episodesLoading",l),i=()=>at(_a,"$episodesError",l),s=()=>at(Wo,"$episodes",l),a=()=>at(Ko,"$episodesTotal",l),[l,u]=zr();let c=ze(""),f=ze(null),g=ze(""),v=ze(0);const h=20;let $=ze(!1);Kr(()=>{R($,!0),y()});async function y(){if(n()){bs.set(!0),_a.set(null);try{const we=await _v({offset:o(v)*h,limit:h,type:o(c)||void 0,consolidated:o(f)??void 0,search:o(g)||void 0});Wo.set(we.episodes),Ko.set(we.total)}catch(we){_a.set(we instanceof Error?we.message:"Failed to load episodes")}finally{bs.set(!1)}}}function p(){R(v,0),y()}function _(){hi(v),y()}function N(){o(v)>0&&(hi(v,-1),y())}function P(we){return new Date(we).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric",hour:"2-digit",minute:"2-digit"})}const w={observation:"Observation",decision:"Decision",question:"Question",meta:"Meta",preference:"Preference"},E={observation:ea,decision:ra,question:ji,meta:Js,preference:ta};Un(()=>(o($),n()),()=>{o($)&&n()&&y()}),Gr(),ar();var C=dh(),F=d(C),O=m(d(F),2),ue=d(O),G=d(ue),ge=d(G);po(ge,{size:16});var Ve=m(G,2);Ve.__keydown=we=>we.key==="Enter"&&p();var Re=m(ue,2),k=d(Re);Ev(k,{size:14,class:"select-icon"});var I=m(k,2);L(()=>{o(c),Cs(()=>{})}),I.__change=p;var A=d(I);A.value=A.__value="";var H=m(A);H.value=H.__value="observation";var Q=m(H);Q.value=Q.__value="decision";var j=m(Q);j.value=j.__value="question";var W=m(j);W.value=W.__value="meta";var me=m(W);me.value=me.__value="preference";var Ce=m(Re,2),it=d(Ce);L(()=>{o(f),Cs(()=>{})}),it.__change=p;var Ie=d(it);Ie.value=(Ie.__value=null)??"";var Pe=m(Ie);Pe.value=Pe.__value=!0;var lt=m(Pe);lt.value=lt.__value=!1;var ut=m(F,2);{var gt=we=>{var $t=rh();b(we,$t)},yt=we=>{var $t=ae(),Dt=Z($t);{var It=ve=>{var vt=ih(),bt=d(vt);L(()=>M(bt,i())),b(ve,vt)},K=ve=>{var vt=ae(),bt=Z(vt);{var re=pt=>{var Tt=sh();b(pt,Tt)},ct=pt=>{var Tt=vh(),Gt=Z(Tt);We(Gt,5,s,Ge,($e,q)=>{var he=fh();let ye;var ke=d(he),ee=d(ke),Me=d(ee);Bn(Me,()=>E[o(q).episode_type],(se,Se)=>{Se(se,{size:16})});var ne=m(ke,2),Oe=d(ne),Ze=d(Oe),B=d(Ze),U=m(Ze,2),pe=d(U),Fe=m(U,2);{var de=se=>{var Se=ah();b(se,Se)};D(Fe,se=>{o(q),x(()=>!o(q).consolidated)&&se(de)})}var He=m(Oe,2);{var J=se=>{var Se=oh(),dt=d(Se);L(()=>M(dt,(o(q),x(()=>o(q).title)))),b(se,Se)};D(He,se=>{o(q),x(()=>o(q).title)&&se(J)})}var be=m(He,2),Ee=d(be),De=m(be,2);{var Ue=se=>{var Se=ch();We(Se,5,()=>(o(q),x(()=>o(q).entity_ids)),Ge,(dt,Pt)=>{var fe=lh(),le=d(fe);L(()=>M(le,o(Pt))),b(dt,fe)}),b(se,Se)};D(De,se=>{o(q),x(()=>o(q).entity_ids.length>0)&&se(Ue)})}var Ye=m(De,2),ie=d(Ye),oe=d(ie),_e=m(ie,2);{var ot=se=>{var Se=uh(),dt=d(Se);L(Pt=>M(dt,`Confidence: ${Pt??""}%`),[()=>(o(q),x(()=>Math.round(o(q).confidence*100)))]),b(se,Se)};D(_e,se=>{o(q),x(()=>o(q).confidence<1)&&se(ot)})}L(se=>{ye=xt(he,1,"timeline-item svelte-kaumpu",null,ye,{consolidated:o(q).consolidated}),xt(Ze,1,`episode-type type-${o(q),x(()=>o(q).episode_type)??""}`,"svelte-kaumpu"),M(B,(o(q),x(()=>w[o(q).episode_type]))),M(pe,se),M(Ee,(o(q),x(()=>o(q).content))),M(oe,`ID: ${o(q),x(()=>o(q).id)??""}`)},[()=>(o(q),x(()=>P(o(q).timestamp)))]),b($e,he)});var jt=m(Gt,2),V=d(jt);V.__click=N;var Y=m(V,2),T=d(Y),X=m(Y,2);X.__click=_,L($e=>{V.disabled=o(v)===0,M(T,`Page ${o(v)+1} of ${$e??""}`),X.disabled=(o(v)+1)*h>=a()},[()=>(a(),x(()=>Math.ceil(a()/h)))]),b(pt,Tt)};D(bt,pt=>{s(),x(()=>s().length===0)?pt(re):pt(ct,!1)},!0)}b(ve,vt)};D(Dt,ve=>{i()?ve(It):ve(K,!1)},!0)}b(we,$t)};D(ut,we=>{r()?we(gt):we(yt,!1)})}co(Ve,()=>o(g),we=>R(g,we)),Ls(I,()=>o(c),we=>R(c,we)),Ls(it,()=>o(f),we=>R(f,we)),b(e,C),jn(),u()}Er(["keydown","change","click"]);function ph(e,t){return e==null||t==null?NaN:e<t?-1:e>t?1:e>=t?0:NaN}var _h={value:()=>{}};function cs(){for(var e=0,t=arguments.length,n={},r;e<t;++e){if(!(r=arguments[e]+"")||r in n||/[\s.]/.test(r))throw new Error("illegal type: "+r);n[r]=[]}return new Es(n)}function Es(e){this._=e}function gh(e,t){return e.trim().split(/^|\s+/).map(function(n){var r="",i=n.indexOf(".");if(i>=0&&(r=n.slice(i+1),n=n.slice(0,i)),n&&!t.hasOwnProperty(n))throw new Error("unknown type: "+n);return{type:n,name:r}})}Es.prototype=cs.prototype={constructor:Es,on:function(e,t){var n=this._,r=gh(e+"",n),i,s=-1,a=r.length;if(arguments.length<2){for(;++s<a;)if((i=(e=r[s]).type)&&(i=mh(n[i],e.name)))return i;return}if(t!=null&&typeof t!="function")throw new Error("invalid callback: "+t);for(;++s<a;)if(i=(e=r[s]).type)n[i]=nl(n[i],e.name,t);else if(t==null)for(i in n)n[i]=nl(n[i],e.name,null);return this},copy:function(){var e={},t=this._;for(var n in t)e[n]=t[n].slice();return new Es(e)},call:function(e,t){if((i=arguments.length-2)>0)for(var n=new Array(i),r=0,i,s;r<i;++r)n[r]=arguments[r+2];if(!this._.hasOwnProperty(e))throw new Error("unknown type: "+e);for(s=this._[e],r=0,i=s.length;r<i;++r)s[r].value.apply(t,n)},apply:function(e,t,n){if(!this._.hasOwnProperty(e))throw new Error("unknown type: "+e);for(var r=this._[e],i=0,s=r.length;i<s;++i)r[i].value.apply(t,n)}};function mh(e,t){for(var n=0,r=e.length,i;n<r;++n)if((i=e[n]).name===t)return i.value}function nl(e,t,n){for(var r=0,i=e.length;r<i;++r)if(e[r].name===t){e[r]=_h,e=e.slice(0,r).concat(e.slice(r+1));break}return n!=null&&e.push({name:t,value:n}),e}var Ha="http://www.w3.org/1999/xhtml";const rl={svg:"http://www.w3.org/2000/svg",xhtml:Ha,xlink:"http://www.w3.org/1999/xlink",xml:"http://www.w3.org/XML/1998/namespace",xmlns:"http://www.w3.org/2000/xmlns/"};function ia(e){var t=e+="",n=t.indexOf(":");return n>=0&&(t=e.slice(0,n))!=="xmlns"&&(e=e.slice(n+1)),rl.hasOwnProperty(t)?{space:rl[t],local:e}:e}function yh(e){return function(){var t=this.ownerDocument,n=this.namespaceURI;return n===Ha&&t.documentElement.namespaceURI===Ha?t.createElement(e):t.createElementNS(n,e)}}function xh(e){return function(){return this.ownerDocument.createElementNS(e.space,e.local)}}function Uc(e){var t=ia(e);return(t.local?xh:yh)(t)}function wh(){}function go(e){return e==null?wh:function(){return this.querySelector(e)}}function $h(e){typeof e!="function"&&(e=go(e));for(var t=this._groups,n=t.length,r=new Array(n),i=0;i<n;++i)for(var s=t[i],a=s.length,l=r[i]=new Array(a),u,c,f=0;f<a;++f)(u=s[f])&&(c=e.call(u,u.__data__,f,s))&&("__data__"in u&&(c.__data__=u.__data__),l[f]=c);return new gn(r,this._parents)}function bh(e){return e==null?[]:Array.isArray(e)?e:Array.from(e)}function kh(){return[]}function Yc(e){return e==null?kh:function(){return this.querySelectorAll(e)}}function Eh(e){return function(){return bh(e.apply(this,arguments))}}function zh(e){typeof e=="function"?e=Eh(e):e=Yc(e);for(var t=this._groups,n=t.length,r=[],i=[],s=0;s<n;++s)for(var a=t[s],l=a.length,u,c=0;c<l;++c)(u=a[c])&&(r.push(e.call(u,u.__data__,c,a)),i.push(u));return new gn(r,i)}function Xc(e){return function(){return this.matches(e)}}function jc(e){return function(t){return t.matches(e)}}var Nh=Array.prototype.find;function Mh(e){return function(){return Nh.call(this.children,e)}}function Ah(){return this.firstElementChild}function Sh(e){return this.select(e==null?Ah:Mh(typeof e=="function"?e:jc(e)))}var Th=Array.prototype.filter;function Ch(){return Array.from(this.children)}function Ph(e){return function(){return Th.call(this.children,e)}}function Dh(e){return this.selectAll(e==null?Ch:Ph(typeof e=="function"?e:jc(e)))}function Lh(e){typeof e!="function"&&(e=Xc(e));for(var t=this._groups,n=t.length,r=new Array(n),i=0;i<n;++i)for(var s=t[i],a=s.length,l=r[i]=[],u,c=0;c<a;++c)(u=s[c])&&e.call(u,u.__data__,c,s)&&l.push(u);return new gn(r,this._parents)}function Gc(e){return new Array(e.length)}function Rh(){return new gn(this._enter||this._groups.map(Gc),this._parents)}function Rs(e,t){this.ownerDocument=e.ownerDocument,this.namespaceURI=e.namespaceURI,this._next=null,this._parent=e,this.__data__=t}Rs.prototype={constructor:Rs,appendChild:function(e){return this._parent.insertBefore(e,this._next)},insertBefore:function(e,t){return this._parent.insertBefore(e,t)},querySelector:function(e){return this._parent.querySelector(e)},querySelectorAll:function(e){return this._parent.querySelectorAll(e)}};function Ih(e){return function(){return e}}function Oh(e,t,n,r,i,s){for(var a=0,l,u=t.length,c=s.length;a<c;++a)(l=t[a])?(l.__data__=s[a],r[a]=l):n[a]=new Rs(e,s[a]);for(;a<u;++a)(l=t[a])&&(i[a]=l)}function Fh(e,t,n,r,i,s,a){var l,u,c=new Map,f=t.length,g=s.length,v=new Array(f),h;for(l=0;l<f;++l)(u=t[l])&&(v[l]=h=a.call(u,u.__data__,l,t)+"",c.has(h)?i[l]=u:c.set(h,u));for(l=0;l<g;++l)h=a.call(e,s[l],l,s)+"",(u=c.get(h))?(r[l]=u,u.__data__=s[l],c.delete(h)):n[l]=new Rs(e,s[l]);for(l=0;l<f;++l)(u=t[l])&&c.get(v[l])===u&&(i[l]=u)}function qh(e){return e.__data__}function Bh(e,t){if(!arguments.length)return Array.from(this,qh);var n=t?Fh:Oh,r=this._parents,i=this._groups;typeof e!="function"&&(e=Ih(e));for(var s=i.length,a=new Array(s),l=new Array(s),u=new Array(s),c=0;c<s;++c){var f=r[c],g=i[c],v=g.length,h=Vh(e.call(f,f&&f.__data__,c,r)),$=h.length,y=l[c]=new Array($),p=a[c]=new Array($),_=u[c]=new Array(v);n(f,g,y,p,_,h,t);for(var N=0,P=0,w,E;N<$;++N)if(w=y[N]){for(N>=P&&(P=N+1);!(E=p[P])&&++P<$;);w._next=E||null}}return a=new gn(a,r),a._enter=l,a._exit=u,a}function Vh(e){return typeof e=="object"&&"length"in e?e:Array.from(e)}function Hh(){return new gn(this._exit||this._groups.map(Gc),this._parents)}function Uh(e,t,n){var r=this.enter(),i=this,s=this.exit();return typeof e=="function"?(r=e(r),r&&(r=r.selection())):r=r.append(e+""),t!=null&&(i=t(i),i&&(i=i.selection())),n==null?s.remove():n(s),r&&i?r.merge(i).order():i}function Yh(e){for(var t=e.selection?e.selection():e,n=this._groups,r=t._groups,i=n.length,s=r.length,a=Math.min(i,s),l=new Array(i),u=0;u<a;++u)for(var c=n[u],f=r[u],g=c.length,v=l[u]=new Array(g),h,$=0;$<g;++$)(h=c[$]||f[$])&&(v[$]=h);for(;u<i;++u)l[u]=n[u];return new gn(l,this._parents)}function Xh(){for(var e=this._groups,t=-1,n=e.length;++t<n;)for(var r=e[t],i=r.length-1,s=r[i],a;--i>=0;)(a=r[i])&&(s&&a.compareDocumentPosition(s)^4&&s.parentNode.insertBefore(a,s),s=a);return this}function jh(e){e||(e=Gh);function t(g,v){return g&&v?e(g.__data__,v.__data__):!g-!v}for(var n=this._groups,r=n.length,i=new Array(r),s=0;s<r;++s){for(var a=n[s],l=a.length,u=i[s]=new Array(l),c,f=0;f<l;++f)(c=a[f])&&(u[f]=c);u.sort(t)}return new gn(i,this._parents).order()}function Gh(e,t){return e<t?-1:e>t?1:e>=t?0:NaN}function Wh(){var e=arguments[0];return arguments[0]=this,e.apply(null,arguments),this}function Kh(){return Array.from(this)}function Zh(){for(var e=this._groups,t=0,n=e.length;t<n;++t)for(var r=e[t],i=0,s=r.length;i<s;++i){var a=r[i];if(a)return a}return null}function Qh(){let e=0;for(const t of this)++e;return e}function Jh(){return!this.node()}function ep(e){for(var t=this._groups,n=0,r=t.length;n<r;++n)for(var i=t[n],s=0,a=i.length,l;s<a;++s)(l=i[s])&&e.call(l,l.__data__,s,i);return this}function tp(e){return function(){this.removeAttribute(e)}}function np(e){return function(){this.removeAttributeNS(e.space,e.local)}}function rp(e,t){return function(){this.setAttribute(e,t)}}function ip(e,t){return function(){this.setAttributeNS(e.space,e.local,t)}}function sp(e,t){return function(){var n=t.apply(this,arguments);n==null?this.removeAttribute(e):this.setAttribute(e,n)}}function ap(e,t){return function(){var n=t.apply(this,arguments);n==null?this.removeAttributeNS(e.space,e.local):this.setAttributeNS(e.space,e.local,n)}}function op(e,t){var n=ia(e);if(arguments.length<2){var r=this.node();return n.local?r.getAttributeNS(n.space,n.local):r.getAttribute(n)}return this.each((t==null?n.local?np:tp:typeof t=="function"?n.local?ap:sp:n.local?ip:rp)(n,t))}function Wc(e){return e.ownerDocument&&e.ownerDocument.defaultView||e.document&&e||e.defaultView}function lp(e){return function(){this.style.removeProperty(e)}}function cp(e,t,n){return function(){this.style.setProperty(e,t,n)}}function up(e,t,n){return function(){var r=t.apply(this,arguments);r==null?this.style.removeProperty(e):this.style.setProperty(e,r,n)}}function fp(e,t,n){return arguments.length>1?this.each((t==null?lp:typeof t=="function"?up:cp)(e,t,n??"")):mi(this.node(),e)}function mi(e,t){return e.style.getPropertyValue(t)||Wc(e).getComputedStyle(e,null).getPropertyValue(t)}function vp(e){return function(){delete this[e]}}function dp(e,t){return function(){this[e]=t}}function hp(e,t){return function(){var n=t.apply(this,arguments);n==null?delete this[e]:this[e]=n}}function pp(e,t){return arguments.length>1?this.each((t==null?vp:typeof t=="function"?hp:dp)(e,t)):this.node()[e]}function Kc(e){return e.trim().split(/^|\s+/)}function mo(e){return e.classList||new Zc(e)}function Zc(e){this._node=e,this._names=Kc(e.getAttribute("class")||"")}Zc.prototype={add:function(e){var t=this._names.indexOf(e);t<0&&(this._names.push(e),this._node.setAttribute("class",this._names.join(" ")))},remove:function(e){var t=this._names.indexOf(e);t>=0&&(this._names.splice(t,1),this._node.setAttribute("class",this._names.join(" ")))},contains:function(e){return this._names.indexOf(e)>=0}};function Qc(e,t){for(var n=mo(e),r=-1,i=t.length;++r<i;)n.add(t[r])}function Jc(e,t){for(var n=mo(e),r=-1,i=t.length;++r<i;)n.remove(t[r])}function _p(e){return function(){Qc(this,e)}}function gp(e){return function(){Jc(this,e)}}function mp(e,t){return function(){(t.apply(this,arguments)?Qc:Jc)(this,e)}}function yp(e,t){var n=Kc(e+"");if(arguments.length<2){for(var r=mo(this.node()),i=-1,s=n.length;++i<s;)if(!r.contains(n[i]))return!1;return!0}return this.each((typeof t=="function"?mp:t?_p:gp)(n,t))}function xp(){this.textContent=""}function wp(e){return function(){this.textContent=e}}function $p(e){return function(){var t=e.apply(this,arguments);this.textContent=t??""}}function bp(e){return arguments.length?this.each(e==null?xp:(typeof e=="function"?$p:wp)(e)):this.node().textContent}function kp(){this.innerHTML=""}function Ep(e){return function(){this.innerHTML=e}}function zp(e){return function(){var t=e.apply(this,arguments);this.innerHTML=t??""}}function Np(e){return arguments.length?this.each(e==null?kp:(typeof e=="function"?zp:Ep)(e)):this.node().innerHTML}function Mp(){this.nextSibling&&this.parentNode.appendChild(this)}function Ap(){return this.each(Mp)}function Sp(){this.previousSibling&&this.parentNode.insertBefore(this,this.parentNode.firstChild)}function Tp(){return this.each(Sp)}function Cp(e){var t=typeof e=="function"?e:Uc(e);return this.select(function(){return this.appendChild(t.apply(this,arguments))})}function Pp(){return null}function Dp(e,t){var n=typeof e=="function"?e:Uc(e),r=t==null?Pp:typeof t=="function"?t:go(t);return this.select(function(){return this.insertBefore(n.apply(this,arguments),r.apply(this,arguments)||null)})}function Lp(){var e=this.parentNode;e&&e.removeChild(this)}function Rp(){return this.each(Lp)}function Ip(){var e=this.cloneNode(!1),t=this.parentNode;return t?t.insertBefore(e,this.nextSibling):e}function Op(){var e=this.cloneNode(!0),t=this.parentNode;return t?t.insertBefore(e,this.nextSibling):e}function Fp(e){return this.select(e?Op:Ip)}function qp(e){return arguments.length?this.property("__data__",e):this.node().__data__}function Bp(e){return function(t){e.call(this,t,this.__data__)}}function Vp(e){return e.trim().split(/^|\s+/).map(function(t){var n="",r=t.indexOf(".");return r>=0&&(n=t.slice(r+1),t=t.slice(0,r)),{type:t,name:n}})}function Hp(e){return function(){var t=this.__on;if(t){for(var n=0,r=-1,i=t.length,s;n<i;++n)s=t[n],(!e.type||s.type===e.type)&&s.name===e.name?this.removeEventListener(s.type,s.listener,s.options):t[++r]=s;++r?t.length=r:delete this.__on}}}function Up(e,t,n){return function(){var r=this.__on,i,s=Bp(t);if(r){for(var a=0,l=r.length;a<l;++a)if((i=r[a]).type===e.type&&i.name===e.name){this.removeEventListener(i.type,i.listener,i.options),this.addEventListener(i.type,i.listener=s,i.options=n),i.value=t;return}}this.addEventListener(e.type,s,n),i={type:e.type,name:e.name,value:t,listener:s,options:n},r?r.push(i):this.__on=[i]}}function Yp(e,t,n){var r=Vp(e+""),i,s=r.length,a;if(arguments.length<2){var l=this.node().__on;if(l){for(var u=0,c=l.length,f;u<c;++u)for(i=0,f=l[u];i<s;++i)if((a=r[i]).type===f.type&&a.name===f.name)return f.value}return}for(l=t?Up:Hp,i=0;i<s;++i)this.each(l(r[i],t,n));return this}function eu(e,t,n){var r=Wc(e),i=r.CustomEvent;typeof i=="function"?i=new i(t,n):(i=r.document.createEvent("Event"),n?(i.initEvent(t,n.bubbles,n.cancelable),i.detail=n.detail):i.initEvent(t,!1,!1)),e.dispatchEvent(i)}function Xp(e,t){return function(){return eu(this,e,t)}}function jp(e,t){return function(){return eu(this,e,t.apply(this,arguments))}}function Gp(e,t){return this.each((typeof t=="function"?jp:Xp)(e,t))}function*Wp(){for(var e=this._groups,t=0,n=e.length;t<n;++t)for(var r=e[t],i=0,s=r.length,a;i<s;++i)(a=r[i])&&(yield a)}var tu=[null];function gn(e,t){this._groups=e,this._parents=t}function us(){return new gn([[document.documentElement]],tu)}function Kp(){return this}gn.prototype=us.prototype={constructor:gn,select:$h,selectAll:zh,selectChild:Sh,selectChildren:Dh,filter:Lh,data:Bh,enter:Rh,exit:Hh,join:Uh,merge:Yh,selection:Kp,order:Xh,sort:jh,call:Wh,nodes:Kh,node:Zh,size:Qh,empty:Jh,each:ep,attr:op,style:fp,property:pp,classed:yp,text:bp,html:Np,raise:Ap,lower:Tp,append:Cp,insert:Dp,remove:Rp,clone:Fp,datum:qp,on:Yp,dispatch:Gp,[Symbol.iterator]:Wp};function pn(e){return typeof e=="string"?new gn([[document.querySelector(e)]],[document.documentElement]):new gn([[e]],tu)}function Zp(e){let t;for(;t=e.sourceEvent;)e=t;return e}function Zn(e,t){if(e=Zp(e),t===void 0&&(t=e.currentTarget),t){var n=t.ownerSVGElement||t;if(n.createSVGPoint){var r=n.createSVGPoint();return r.x=e.clientX,r.y=e.clientY,r=r.matrixTransform(t.getScreenCTM().inverse()),[r.x,r.y]}if(t.getBoundingClientRect){var i=t.getBoundingClientRect();return[e.clientX-i.left-t.clientLeft,e.clientY-i.top-t.clientTop]}}return[e.pageX,e.pageY]}const Qp={passive:!1},Gi={capture:!0,passive:!1};function $a(e){e.stopImmediatePropagation()}function ai(e){e.preventDefault(),e.stopImmediatePropagation()}function nu(e){var t=e.document.documentElement,n=pn(e).on("dragstart.drag",ai,Gi);"onselectstart"in t?n.on("selectstart.drag",ai,Gi):(t.__noselect=t.style.MozUserSelect,t.style.MozUserSelect="none")}function ru(e,t){var n=e.document.documentElement,r=pn(e).on("dragstart.drag",null);t&&(r.on("click.drag",ai,Gi),setTimeout(function(){r.on("click.drag",null)},0)),"onselectstart"in n?r.on("selectstart.drag",null):(n.style.MozUserSelect=n.__noselect,delete n.__noselect)}const hs=e=>()=>e;function Ua(e,{sourceEvent:t,subject:n,target:r,identifier:i,active:s,x:a,y:l,dx:u,dy:c,dispatch:f}){Object.defineProperties(this,{type:{value:e,enumerable:!0,configurable:!0},sourceEvent:{value:t,enumerable:!0,configurable:!0},subject:{value:n,enumerable:!0,configurable:!0},target:{value:r,enumerable:!0,configurable:!0},identifier:{value:i,enumerable:!0,configurable:!0},active:{value:s,enumerable:!0,configurable:!0},x:{value:a,enumerable:!0,configurable:!0},y:{value:l,enumerable:!0,configurable:!0},dx:{value:u,enumerable:!0,configurable:!0},dy:{value:c,enumerable:!0,configurable:!0},_:{value:f}})}Ua.prototype.on=function(){var e=this._.on.apply(this._,arguments);return e===this._?this:e};function Jp(e){return!e.ctrlKey&&!e.button}function e_(){return this.parentNode}function t_(e,t){return t??{x:e.x,y:e.y}}function n_(){return navigator.maxTouchPoints||"ontouchstart"in this}function r_(){var e=Jp,t=e_,n=t_,r=n_,i={},s=cs("start","drag","end"),a=0,l,u,c,f,g=0;function v(w){w.on("mousedown.drag",h).filter(r).on("touchstart.drag",p).on("touchmove.drag",_,Qp).on("touchend.drag touchcancel.drag",N).style("touch-action","none").style("-webkit-tap-highlight-color","rgba(0,0,0,0)")}function h(w,E){if(!(f||!e.call(this,w,E))){var C=P(this,t.call(this,w,E),w,E,"mouse");C&&(pn(w.view).on("mousemove.drag",$,Gi).on("mouseup.drag",y,Gi),nu(w.view),$a(w),c=!1,l=w.clientX,u=w.clientY,C("start",w))}}function $(w){if(ai(w),!c){var E=w.clientX-l,C=w.clientY-u;c=E*E+C*C>g}i.mouse("drag",w)}function y(w){pn(w.view).on("mousemove.drag mouseup.drag",null),ru(w.view,c),ai(w),i.mouse("end",w)}function p(w,E){if(e.call(this,w,E)){var C=w.changedTouches,F=t.call(this,w,E),O=C.length,ue,G;for(ue=0;ue<O;++ue)(G=P(this,F,w,E,C[ue].identifier,C[ue]))&&($a(w),G("start",w,C[ue]))}}function _(w){var E=w.changedTouches,C=E.length,F,O;for(F=0;F<C;++F)(O=i[E[F].identifier])&&(ai(w),O("drag",w,E[F]))}function N(w){var E=w.changedTouches,C=E.length,F,O;for(f&&clearTimeout(f),f=setTimeout(function(){f=null},500),F=0;F<C;++F)(O=i[E[F].identifier])&&($a(w),O("end",w,E[F]))}function P(w,E,C,F,O,ue){var G=s.copy(),ge=Zn(ue||C,E),Ve,Re,k;if((k=n.call(w,new Ua("beforestart",{sourceEvent:C,target:v,identifier:O,active:a,x:ge[0],y:ge[1],dx:0,dy:0,dispatch:G}),F))!=null)return Ve=k.x-ge[0]||0,Re=k.y-ge[1]||0,function I(A,H,Q){var j=ge,W;switch(A){case"start":i[O]=I,W=a++;break;case"end":delete i[O],--a;case"drag":ge=Zn(Q||H,E),W=a;break}G.call(A,w,new Ua(A,{sourceEvent:H,subject:k,target:v,identifier:O,active:W,x:ge[0]+Ve,y:ge[1]+Re,dx:ge[0]-j[0],dy:ge[1]-j[1],dispatch:G}),F)}}return v.filter=function(w){return arguments.length?(e=typeof w=="function"?w:hs(!!w),v):e},v.container=function(w){return arguments.length?(t=typeof w=="function"?w:hs(w),v):t},v.subject=function(w){return arguments.length?(n=typeof w=="function"?w:hs(w),v):n},v.touchable=function(w){return arguments.length?(r=typeof w=="function"?w:hs(!!w),v):r},v.on=function(){var w=s.on.apply(s,arguments);return w===s?v:w},v.clickDistance=function(w){return arguments.length?(g=(w=+w)*w,v):Math.sqrt(g)},v}function yo(e,t,n){e.prototype=t.prototype=n,n.constructor=e}function iu(e,t){var n=Object.create(e.prototype);for(var r in t)n[r]=t[r];return n}function fs(){}var Wi=.7,Is=1/Wi,oi="\\s*([+-]?\\d+)\\s*",Ki="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*",Yn="\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*",i_=/^#([0-9a-f]{3,8})$/,s_=new RegExp(`^rgb\\(${oi},${oi},${oi}\\)$`),a_=new RegExp(`^rgb\\(${Yn},${Yn},${Yn}\\)$`),o_=new RegExp(`^rgba\\(${oi},${oi},${oi},${Ki}\\)$`),l_=new RegExp(`^rgba\\(${Yn},${Yn},${Yn},${Ki}\\)$`),c_=new RegExp(`^hsl\\(${Ki},${Yn},${Yn}\\)$`),u_=new RegExp(`^hsla\\(${Ki},${Yn},${Yn},${Ki}\\)$`),il={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074};yo(fs,Zi,{copy(e){return Object.assign(new this.constructor,this,e)},displayable(){return this.rgb().displayable()},hex:sl,formatHex:sl,formatHex8:f_,formatHsl:v_,formatRgb:al,toString:al});function sl(){return this.rgb().formatHex()}function f_(){return this.rgb().formatHex8()}function v_(){return su(this).formatHsl()}function al(){return this.rgb().formatRgb()}function Zi(e){var t,n;return e=(e+"").trim().toLowerCase(),(t=i_.exec(e))?(n=t[1].length,t=parseInt(t[1],16),n===6?ol(t):n===3?new fn(t>>8&15|t>>4&240,t>>4&15|t&240,(t&15)<<4|t&15,1):n===8?ps(t>>24&255,t>>16&255,t>>8&255,(t&255)/255):n===4?ps(t>>12&15|t>>8&240,t>>8&15|t>>4&240,t>>4&15|t&240,((t&15)<<4|t&15)/255):null):(t=s_.exec(e))?new fn(t[1],t[2],t[3],1):(t=a_.exec(e))?new fn(t[1]*255/100,t[2]*255/100,t[3]*255/100,1):(t=o_.exec(e))?ps(t[1],t[2],t[3],t[4]):(t=l_.exec(e))?ps(t[1]*255/100,t[2]*255/100,t[3]*255/100,t[4]):(t=c_.exec(e))?ul(t[1],t[2]/100,t[3]/100,1):(t=u_.exec(e))?ul(t[1],t[2]/100,t[3]/100,t[4]):il.hasOwnProperty(e)?ol(il[e]):e==="transparent"?new fn(NaN,NaN,NaN,0):null}function ol(e){return new fn(e>>16&255,e>>8&255,e&255,1)}function ps(e,t,n,r){return r<=0&&(e=t=n=NaN),new fn(e,t,n,r)}function d_(e){return e instanceof fs||(e=Zi(e)),e?(e=e.rgb(),new fn(e.r,e.g,e.b,e.opacity)):new fn}function Ya(e,t,n,r){return arguments.length===1?d_(e):new fn(e,t,n,r??1)}function fn(e,t,n,r){this.r=+e,this.g=+t,this.b=+n,this.opacity=+r}yo(fn,Ya,iu(fs,{brighter(e){return e=e==null?Is:Math.pow(Is,e),new fn(this.r*e,this.g*e,this.b*e,this.opacity)},darker(e){return e=e==null?Wi:Math.pow(Wi,e),new fn(this.r*e,this.g*e,this.b*e,this.opacity)},rgb(){return this},clamp(){return new fn(qr(this.r),qr(this.g),qr(this.b),Os(this.opacity))},displayable(){return-.5<=this.r&&this.r<255.5&&-.5<=this.g&&this.g<255.5&&-.5<=this.b&&this.b<255.5&&0<=this.opacity&&this.opacity<=1},hex:ll,formatHex:ll,formatHex8:h_,formatRgb:cl,toString:cl}));function ll(){return`#${Sr(this.r)}${Sr(this.g)}${Sr(this.b)}`}function h_(){return`#${Sr(this.r)}${Sr(this.g)}${Sr(this.b)}${Sr((isNaN(this.opacity)?1:this.opacity)*255)}`}function cl(){const e=Os(this.opacity);return`${e===1?"rgb(":"rgba("}${qr(this.r)}, ${qr(this.g)}, ${qr(this.b)}${e===1?")":`, ${e})`}`}function Os(e){return isNaN(e)?1:Math.max(0,Math.min(1,e))}function qr(e){return Math.max(0,Math.min(255,Math.round(e)||0))}function Sr(e){return e=qr(e),(e<16?"0":"")+e.toString(16)}function ul(e,t,n,r){return r<=0?e=t=n=NaN:n<=0||n>=1?e=t=NaN:t<=0&&(e=NaN),new An(e,t,n,r)}function su(e){if(e instanceof An)return new An(e.h,e.s,e.l,e.opacity);if(e instanceof fs||(e=Zi(e)),!e)return new An;if(e instanceof An)return e;e=e.rgb();var t=e.r/255,n=e.g/255,r=e.b/255,i=Math.min(t,n,r),s=Math.max(t,n,r),a=NaN,l=s-i,u=(s+i)/2;return l?(t===s?a=(n-r)/l+(n<r)*6:n===s?a=(r-t)/l+2:a=(t-n)/l+4,l/=u<.5?s+i:2-s-i,a*=60):l=u>0&&u<1?0:a,new An(a,l,u,e.opacity)}function p_(e,t,n,r){return arguments.length===1?su(e):new An(e,t,n,r??1)}function An(e,t,n,r){this.h=+e,this.s=+t,this.l=+n,this.opacity=+r}yo(An,p_,iu(fs,{brighter(e){return e=e==null?Is:Math.pow(Is,e),new An(this.h,this.s,this.l*e,this.opacity)},darker(e){return e=e==null?Wi:Math.pow(Wi,e),new An(this.h,this.s,this.l*e,this.opacity)},rgb(){var e=this.h%360+(this.h<0)*360,t=isNaN(e)||isNaN(this.s)?0:this.s,n=this.l,r=n+(n<.5?n:1-n)*t,i=2*n-r;return new fn(ba(e>=240?e-240:e+120,i,r),ba(e,i,r),ba(e<120?e+240:e-120,i,r),this.opacity)},clamp(){return new An(fl(this.h),_s(this.s),_s(this.l),Os(this.opacity))},displayable(){return(0<=this.s&&this.s<=1||isNaN(this.s))&&0<=this.l&&this.l<=1&&0<=this.opacity&&this.opacity<=1},formatHsl(){const e=Os(this.opacity);return`${e===1?"hsl(":"hsla("}${fl(this.h)}, ${_s(this.s)*100}%, ${_s(this.l)*100}%${e===1?")":`, ${e})`}`}}));function fl(e){return e=(e||0)%360,e<0?e+360:e}function _s(e){return Math.max(0,Math.min(1,e||0))}function ba(e,t,n){return(e<60?t+(n-t)*e/60:e<180?n:e<240?t+(n-t)*(240-e)/60:t)*255}const au=e=>()=>e;function __(e,t){return function(n){return e+n*t}}function g_(e,t,n){return e=Math.pow(e,n),t=Math.pow(t,n)-e,n=1/n,function(r){return Math.pow(e+r*t,n)}}function m_(e){return(e=+e)==1?ou:function(t,n){return n-t?g_(t,n,e):au(isNaN(t)?n:t)}}function ou(e,t){var n=t-e;return n?__(e,n):au(isNaN(e)?t:e)}const vl=function e(t){var n=m_(t);function r(i,s){var a=n((i=Ya(i)).r,(s=Ya(s)).r),l=n(i.g,s.g),u=n(i.b,s.b),c=ou(i.opacity,s.opacity);return function(f){return i.r=a(f),i.g=l(f),i.b=u(f),i.opacity=c(f),i+""}}return r.gamma=e,r}(1);function dr(e,t){return e=+e,t=+t,function(n){return e*(1-n)+t*n}}var Xa=/[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,ka=new RegExp(Xa.source,"g");function y_(e){return function(){return e}}function x_(e){return function(t){return e(t)+""}}function w_(e,t){var n=Xa.lastIndex=ka.lastIndex=0,r,i,s,a=-1,l=[],u=[];for(e=e+"",t=t+"";(r=Xa.exec(e))&&(i=ka.exec(t));)(s=i.index)>n&&(s=t.slice(n,s),l[a]?l[a]+=s:l[++a]=s),(r=r[0])===(i=i[0])?l[a]?l[a]+=i:l[++a]=i:(l[++a]=null,u.push({i:a,x:dr(r,i)})),n=ka.lastIndex;return n<t.length&&(s=t.slice(n),l[a]?l[a]+=s:l[++a]=s),l.length<2?u[0]?x_(u[0].x):y_(t):(t=u.length,function(c){for(var f=0,g;f<t;++f)l[(g=u[f]).i]=g.x(c);return l.join("")})}var dl=180/Math.PI,ja={translateX:0,translateY:0,rotate:0,skewX:0,scaleX:1,scaleY:1};function lu(e,t,n,r,i,s){var a,l,u;return(a=Math.sqrt(e*e+t*t))&&(e/=a,t/=a),(u=e*n+t*r)&&(n-=e*u,r-=t*u),(l=Math.sqrt(n*n+r*r))&&(n/=l,r/=l,u/=l),e*r<t*n&&(e=-e,t=-t,u=-u,a=-a),{translateX:i,translateY:s,rotate:Math.atan2(t,e)*dl,skewX:Math.atan(u)*dl,scaleX:a,scaleY:l}}var gs;function $_(e){const t=new(typeof DOMMatrix=="function"?DOMMatrix:WebKitCSSMatrix)(e+"");return t.isIdentity?ja:lu(t.a,t.b,t.c,t.d,t.e,t.f)}function b_(e){return e==null||(gs||(gs=document.createElementNS("http://www.w3.org/2000/svg","g")),gs.setAttribute("transform",e),!(e=gs.transform.baseVal.consolidate()))?ja:(e=e.matrix,lu(e.a,e.b,e.c,e.d,e.e,e.f))}function cu(e,t,n,r){function i(c){return c.length?c.pop()+" ":""}function s(c,f,g,v,h,$){if(c!==g||f!==v){var y=h.push("translate(",null,t,null,n);$.push({i:y-4,x:dr(c,g)},{i:y-2,x:dr(f,v)})}else(g||v)&&h.push("translate("+g+t+v+n)}function a(c,f,g,v){c!==f?(c-f>180?f+=360:f-c>180&&(c+=360),v.push({i:g.push(i(g)+"rotate(",null,r)-2,x:dr(c,f)})):f&&g.push(i(g)+"rotate("+f+r)}function l(c,f,g,v){c!==f?v.push({i:g.push(i(g)+"skewX(",null,r)-2,x:dr(c,f)}):f&&g.push(i(g)+"skewX("+f+r)}function u(c,f,g,v,h,$){if(c!==g||f!==v){var y=h.push(i(h)+"scale(",null,",",null,")");$.push({i:y-4,x:dr(c,g)},{i:y-2,x:dr(f,v)})}else(g!==1||v!==1)&&h.push(i(h)+"scale("+g+","+v+")")}return function(c,f){var g=[],v=[];return c=e(c),f=e(f),s(c.translateX,c.translateY,f.translateX,f.translateY,g,v),a(c.rotate,f.rotate,g,v),l(c.skewX,f.skewX,g,v),u(c.scaleX,c.scaleY,f.scaleX,f.scaleY,g,v),c=f=null,function(h){for(var $=-1,y=v.length,p;++$<y;)g[(p=v[$]).i]=p.x(h);return g.join("")}}}var k_=cu($_,"px, ","px)","deg)"),E_=cu(b_,", ",")",")"),z_=1e-12;function hl(e){return((e=Math.exp(e))+1/e)/2}function N_(e){return((e=Math.exp(e))-1/e)/2}function M_(e){return((e=Math.exp(2*e))-1)/(e+1)}const A_=function e(t,n,r){function i(s,a){var l=s[0],u=s[1],c=s[2],f=a[0],g=a[1],v=a[2],h=f-l,$=g-u,y=h*h+$*$,p,_;if(y<z_)_=Math.log(v/c)/t,p=function(F){return[l+F*h,u+F*$,c*Math.exp(t*F*_)]};else{var N=Math.sqrt(y),P=(v*v-c*c+r*y)/(2*c*n*N),w=(v*v-c*c-r*y)/(2*v*n*N),E=Math.log(Math.sqrt(P*P+1)-P),C=Math.log(Math.sqrt(w*w+1)-w);_=(C-E)/t,p=function(F){var O=F*_,ue=hl(E),G=c/(n*N)*(ue*M_(t*O+E)-N_(E));return[l+G*h,u+G*$,c*ue/hl(t*O+E)]}}return p.duration=_*1e3*t/Math.SQRT2,p}return i.rho=function(s){var a=Math.max(.001,+s),l=a*a,u=l*l;return e(a,l,u)},i}(Math.SQRT2,2,4);var yi=0,Ri=0,Si=0,uu=1e3,Fs,Ii,qs=0,Yr=0,sa=0,Qi=typeof performance=="object"&&performance.now?performance:Date,fu=typeof window=="object"&&window.requestAnimationFrame?window.requestAnimationFrame.bind(window):function(e){setTimeout(e,17)};function xo(){return Yr||(fu(S_),Yr=Qi.now()+sa)}function S_(){Yr=0}function Bs(){this._call=this._time=this._next=null}Bs.prototype=wo.prototype={constructor:Bs,restart:function(e,t,n){if(typeof e!="function")throw new TypeError("callback is not a function");n=(n==null?xo():+n)+(t==null?0:+t),!this._next&&Ii!==this&&(Ii?Ii._next=this:Fs=this,Ii=this),this._call=e,this._time=n,Ga()},stop:function(){this._call&&(this._call=null,this._time=1/0,Ga())}};function wo(e,t,n){var r=new Bs;return r.restart(e,t,n),r}function T_(){xo(),++yi;for(var e=Fs,t;e;)(t=Yr-e._time)>=0&&e._call.call(void 0,t),e=e._next;--yi}function pl(){Yr=(qs=Qi.now())+sa,yi=Ri=0;try{T_()}finally{yi=0,P_(),Yr=0}}function C_(){var e=Qi.now(),t=e-qs;t>uu&&(sa-=t,qs=e)}function P_(){for(var e,t=Fs,n,r=1/0;t;)t._call?(r>t._time&&(r=t._time),e=t,t=t._next):(n=t._next,t._next=null,t=e?e._next=n:Fs=n);Ii=e,Ga(r)}function Ga(e){if(!yi){Ri&&(Ri=clearTimeout(Ri));var t=e-Yr;t>24?(e<1/0&&(Ri=setTimeout(pl,e-Qi.now()-sa)),Si&&(Si=clearInterval(Si))):(Si||(qs=Qi.now(),Si=setInterval(C_,uu)),yi=1,fu(pl))}}function _l(e,t,n){var r=new Bs;return t=t==null?0:+t,r.restart(i=>{r.stop(),e(i+t)},t,n),r}var D_=cs("start","end","cancel","interrupt"),L_=[],vu=0,gl=1,Wa=2,zs=3,ml=4,Ka=5,Ns=6;function aa(e,t,n,r,i,s){var a=e.__transition;if(!a)e.__transition={};else if(n in a)return;R_(e,n,{name:t,index:r,group:i,on:D_,tween:L_,time:s.time,delay:s.delay,duration:s.duration,ease:s.ease,timer:null,state:vu})}function $o(e,t){var n=Dn(e,t);if(n.state>vu)throw new Error("too late; already scheduled");return n}function Gn(e,t){var n=Dn(e,t);if(n.state>zs)throw new Error("too late; already running");return n}function Dn(e,t){var n=e.__transition;if(!n||!(n=n[t]))throw new Error("transition not found");return n}function R_(e,t,n){var r=e.__transition,i;r[t]=n,n.timer=wo(s,0,n.time);function s(c){n.state=gl,n.timer.restart(a,n.delay,n.time),n.delay<=c&&a(c-n.delay)}function a(c){var f,g,v,h;if(n.state!==gl)return u();for(f in r)if(h=r[f],h.name===n.name){if(h.state===zs)return _l(a);h.state===ml?(h.state=Ns,h.timer.stop(),h.on.call("interrupt",e,e.__data__,h.index,h.group),delete r[f]):+f<t&&(h.state=Ns,h.timer.stop(),h.on.call("cancel",e,e.__data__,h.index,h.group),delete r[f])}if(_l(function(){n.state===zs&&(n.state=ml,n.timer.restart(l,n.delay,n.time),l(c))}),n.state=Wa,n.on.call("start",e,e.__data__,n.index,n.group),n.state===Wa){for(n.state=zs,i=new Array(v=n.tween.length),f=0,g=-1;f<v;++f)(h=n.tween[f].value.call(e,e.__data__,n.index,n.group))&&(i[++g]=h);i.length=g+1}}function l(c){for(var f=c<n.duration?n.ease.call(null,c/n.duration):(n.timer.restart(u),n.state=Ka,1),g=-1,v=i.length;++g<v;)i[g].call(e,f);n.state===Ka&&(n.on.call("end",e,e.__data__,n.index,n.group),u())}function u(){n.state=Ns,n.timer.stop(),delete r[t];for(var c in r)return;delete e.__transition}}function Ms(e,t){var n=e.__transition,r,i,s=!0,a;if(n){t=t==null?null:t+"";for(a in n){if((r=n[a]).name!==t){s=!1;continue}i=r.state>Wa&&r.state<Ka,r.state=Ns,r.timer.stop(),r.on.call(i?"interrupt":"cancel",e,e.__data__,r.index,r.group),delete n[a]}s&&delete e.__transition}}function I_(e){return this.each(function(){Ms(this,e)})}function O_(e,t){var n,r;return function(){var i=Gn(this,e),s=i.tween;if(s!==n){r=n=s;for(var a=0,l=r.length;a<l;++a)if(r[a].name===t){r=r.slice(),r.splice(a,1);break}}i.tween=r}}function F_(e,t,n){var r,i;if(typeof n!="function")throw new Error;return function(){var s=Gn(this,e),a=s.tween;if(a!==r){i=(r=a).slice();for(var l={name:t,value:n},u=0,c=i.length;u<c;++u)if(i[u].name===t){i[u]=l;break}u===c&&i.push(l)}s.tween=i}}function q_(e,t){var n=this._id;if(e+="",arguments.length<2){for(var r=Dn(this.node(),n).tween,i=0,s=r.length,a;i<s;++i)if((a=r[i]).name===e)return a.value;return null}return this.each((t==null?O_:F_)(n,e,t))}function bo(e,t,n){var r=e._id;return e.each(function(){var i=Gn(this,r);(i.value||(i.value={}))[t]=n.apply(this,arguments)}),function(i){return Dn(i,r).value[t]}}function du(e,t){var n;return(typeof t=="number"?dr:t instanceof Zi?vl:(n=Zi(t))?(t=n,vl):w_)(e,t)}function B_(e){return function(){this.removeAttribute(e)}}function V_(e){return function(){this.removeAttributeNS(e.space,e.local)}}function H_(e,t,n){var r,i=n+"",s;return function(){var a=this.getAttribute(e);return a===i?null:a===r?s:s=t(r=a,n)}}function U_(e,t,n){var r,i=n+"",s;return function(){var a=this.getAttributeNS(e.space,e.local);return a===i?null:a===r?s:s=t(r=a,n)}}function Y_(e,t,n){var r,i,s;return function(){var a,l=n(this),u;return l==null?void this.removeAttribute(e):(a=this.getAttribute(e),u=l+"",a===u?null:a===r&&u===i?s:(i=u,s=t(r=a,l)))}}function X_(e,t,n){var r,i,s;return function(){var a,l=n(this),u;return l==null?void this.removeAttributeNS(e.space,e.local):(a=this.getAttributeNS(e.space,e.local),u=l+"",a===u?null:a===r&&u===i?s:(i=u,s=t(r=a,l)))}}function j_(e,t){var n=ia(e),r=n==="transform"?E_:du;return this.attrTween(e,typeof t=="function"?(n.local?X_:Y_)(n,r,bo(this,"attr."+e,t)):t==null?(n.local?V_:B_)(n):(n.local?U_:H_)(n,r,t))}function G_(e,t){return function(n){this.setAttribute(e,t.call(this,n))}}function W_(e,t){return function(n){this.setAttributeNS(e.space,e.local,t.call(this,n))}}function K_(e,t){var n,r;function i(){var s=t.apply(this,arguments);return s!==r&&(n=(r=s)&&W_(e,s)),n}return i._value=t,i}function Z_(e,t){var n,r;function i(){var s=t.apply(this,arguments);return s!==r&&(n=(r=s)&&G_(e,s)),n}return i._value=t,i}function Q_(e,t){var n="attr."+e;if(arguments.length<2)return(n=this.tween(n))&&n._value;if(t==null)return this.tween(n,null);if(typeof t!="function")throw new Error;var r=ia(e);return this.tween(n,(r.local?K_:Z_)(r,t))}function J_(e,t){return function(){$o(this,e).delay=+t.apply(this,arguments)}}function e1(e,t){return t=+t,function(){$o(this,e).delay=t}}function t1(e){var t=this._id;return arguments.length?this.each((typeof e=="function"?J_:e1)(t,e)):Dn(this.node(),t).delay}function n1(e,t){return function(){Gn(this,e).duration=+t.apply(this,arguments)}}function r1(e,t){return t=+t,function(){Gn(this,e).duration=t}}function i1(e){var t=this._id;return arguments.length?this.each((typeof e=="function"?n1:r1)(t,e)):Dn(this.node(),t).duration}function s1(e,t){if(typeof t!="function")throw new Error;return function(){Gn(this,e).ease=t}}function a1(e){var t=this._id;return arguments.length?this.each(s1(t,e)):Dn(this.node(),t).ease}function o1(e,t){return function(){var n=t.apply(this,arguments);if(typeof n!="function")throw new Error;Gn(this,e).ease=n}}function l1(e){if(typeof e!="function")throw new Error;return this.each(o1(this._id,e))}function c1(e){typeof e!="function"&&(e=Xc(e));for(var t=this._groups,n=t.length,r=new Array(n),i=0;i<n;++i)for(var s=t[i],a=s.length,l=r[i]=[],u,c=0;c<a;++c)(u=s[c])&&e.call(u,u.__data__,c,s)&&l.push(u);return new rr(r,this._parents,this._name,this._id)}function u1(e){if(e._id!==this._id)throw new Error;for(var t=this._groups,n=e._groups,r=t.length,i=n.length,s=Math.min(r,i),a=new Array(r),l=0;l<s;++l)for(var u=t[l],c=n[l],f=u.length,g=a[l]=new Array(f),v,h=0;h<f;++h)(v=u[h]||c[h])&&(g[h]=v);for(;l<r;++l)a[l]=t[l];return new rr(a,this._parents,this._name,this._id)}function f1(e){return(e+"").trim().split(/^|\s+/).every(function(t){var n=t.indexOf(".");return n>=0&&(t=t.slice(0,n)),!t||t==="start"})}function v1(e,t,n){var r,i,s=f1(t)?$o:Gn;return function(){var a=s(this,e),l=a.on;l!==r&&(i=(r=l).copy()).on(t,n),a.on=i}}function d1(e,t){var n=this._id;return arguments.length<2?Dn(this.node(),n).on.on(e):this.each(v1(n,e,t))}function h1(e){return function(){var t=this.parentNode;for(var n in this.__transition)if(+n!==e)return;t&&t.removeChild(this)}}function p1(){return this.on("end.remove",h1(this._id))}function _1(e){var t=this._name,n=this._id;typeof e!="function"&&(e=go(e));for(var r=this._groups,i=r.length,s=new Array(i),a=0;a<i;++a)for(var l=r[a],u=l.length,c=s[a]=new Array(u),f,g,v=0;v<u;++v)(f=l[v])&&(g=e.call(f,f.__data__,v,l))&&("__data__"in f&&(g.__data__=f.__data__),c[v]=g,aa(c[v],t,n,v,c,Dn(f,n)));return new rr(s,this._parents,t,n)}function g1(e){var t=this._name,n=this._id;typeof e!="function"&&(e=Yc(e));for(var r=this._groups,i=r.length,s=[],a=[],l=0;l<i;++l)for(var u=r[l],c=u.length,f,g=0;g<c;++g)if(f=u[g]){for(var v=e.call(f,f.__data__,g,u),h,$=Dn(f,n),y=0,p=v.length;y<p;++y)(h=v[y])&&aa(h,t,n,y,v,$);s.push(v),a.push(f)}return new rr(s,a,t,n)}var m1=us.prototype.constructor;function y1(){return new m1(this._groups,this._parents)}function x1(e,t){var n,r,i;return function(){var s=mi(this,e),a=(this.style.removeProperty(e),mi(this,e));return s===a?null:s===n&&a===r?i:i=t(n=s,r=a)}}function hu(e){return function(){this.style.removeProperty(e)}}function w1(e,t,n){var r,i=n+"",s;return function(){var a=mi(this,e);return a===i?null:a===r?s:s=t(r=a,n)}}function $1(e,t,n){var r,i,s;return function(){var a=mi(this,e),l=n(this),u=l+"";return l==null&&(u=l=(this.style.removeProperty(e),mi(this,e))),a===u?null:a===r&&u===i?s:(i=u,s=t(r=a,l))}}function b1(e,t){var n,r,i,s="style."+t,a="end."+s,l;return function(){var u=Gn(this,e),c=u.on,f=u.value[s]==null?l||(l=hu(t)):void 0;(c!==n||i!==f)&&(r=(n=c).copy()).on(a,i=f),u.on=r}}function k1(e,t,n){var r=(e+="")=="transform"?k_:du;return t==null?this.styleTween(e,x1(e,r)).on("end.style."+e,hu(e)):typeof t=="function"?this.styleTween(e,$1(e,r,bo(this,"style."+e,t))).each(b1(this._id,e)):this.styleTween(e,w1(e,r,t),n).on("end.style."+e,null)}function E1(e,t,n){return function(r){this.style.setProperty(e,t.call(this,r),n)}}function z1(e,t,n){var r,i;function s(){var a=t.apply(this,arguments);return a!==i&&(r=(i=a)&&E1(e,a,n)),r}return s._value=t,s}function N1(e,t,n){var r="style."+(e+="");if(arguments.length<2)return(r=this.tween(r))&&r._value;if(t==null)return this.tween(r,null);if(typeof t!="function")throw new Error;return this.tween(r,z1(e,t,n??""))}function M1(e){return function(){this.textContent=e}}function A1(e){return function(){var t=e(this);this.textContent=t??""}}function S1(e){return this.tween("text",typeof e=="function"?A1(bo(this,"text",e)):M1(e==null?"":e+""))}function T1(e){return function(t){this.textContent=e.call(this,t)}}function C1(e){var t,n;function r(){var i=e.apply(this,arguments);return i!==n&&(t=(n=i)&&T1(i)),t}return r._value=e,r}function P1(e){var t="text";if(arguments.length<1)return(t=this.tween(t))&&t._value;if(e==null)return this.tween(t,null);if(typeof e!="function")throw new Error;return this.tween(t,C1(e))}function D1(){for(var e=this._name,t=this._id,n=pu(),r=this._groups,i=r.length,s=0;s<i;++s)for(var a=r[s],l=a.length,u,c=0;c<l;++c)if(u=a[c]){var f=Dn(u,t);aa(u,e,n,c,a,{time:f.time+f.delay+f.duration,delay:0,duration:f.duration,ease:f.ease})}return new rr(r,this._parents,e,n)}function L1(){var e,t,n=this,r=n._id,i=n.size();return new Promise(function(s,a){var l={value:a},u={value:function(){--i===0&&s()}};n.each(function(){var c=Gn(this,r),f=c.on;f!==e&&(t=(e=f).copy(),t._.cancel.push(l),t._.interrupt.push(l),t._.end.push(u)),c.on=t}),i===0&&s()})}var R1=0;function rr(e,t,n,r){this._groups=e,this._parents=t,this._name=n,this._id=r}function pu(){return++R1}var Kn=us.prototype;rr.prototype={constructor:rr,select:_1,selectAll:g1,selectChild:Kn.selectChild,selectChildren:Kn.selectChildren,filter:c1,merge:u1,selection:y1,transition:D1,call:Kn.call,nodes:Kn.nodes,node:Kn.node,size:Kn.size,empty:Kn.empty,each:Kn.each,on:d1,attr:j_,attrTween:Q_,style:k1,styleTween:N1,text:S1,textTween:P1,remove:p1,tween:q_,delay:t1,duration:i1,ease:a1,easeVarying:l1,end:L1,[Symbol.iterator]:Kn[Symbol.iterator]};function I1(e){return((e*=2)<=1?e*e*e:(e-=2)*e*e+2)/2}var O1={time:null,delay:0,duration:250,ease:I1};function F1(e,t){for(var n;!(n=e.__transition)||!(n=n[t]);)if(!(e=e.parentNode))throw new Error(`transition ${t} not found`);return n}function q1(e){var t,n;e instanceof rr?(t=e._id,e=e._name):(t=pu(),(n=O1).time=xo(),e=e==null?null:e+"");for(var r=this._groups,i=r.length,s=0;s<i;++s)for(var a=r[s],l=a.length,u,c=0;c<l;++c)(u=a[c])&&aa(u,e,t,c,a,n||F1(u,t));return new rr(r,this._parents,e,t)}us.prototype.interrupt=I_;us.prototype.transition=q1;const Za=Math.PI,Qa=2*Za,Mr=1e-6,B1=Qa-Mr;function _u(e){this._+=e[0];for(let t=1,n=e.length;t<n;++t)this._+=arguments[t]+e[t]}function V1(e){let t=Math.floor(e);if(!(t>=0))throw new Error(`invalid digits: ${e}`);if(t>15)return _u;const n=10**t;return function(r){this._+=r[0];for(let i=1,s=r.length;i<s;++i)this._+=Math.round(arguments[i]*n)/n+r[i]}}class H1{constructor(t){this._x0=this._y0=this._x1=this._y1=null,this._="",this._append=t==null?_u:V1(t)}moveTo(t,n){this._append`M${this._x0=this._x1=+t},${this._y0=this._y1=+n}`}closePath(){this._x1!==null&&(this._x1=this._x0,this._y1=this._y0,this._append`Z`)}lineTo(t,n){this._append`L${this._x1=+t},${this._y1=+n}`}quadraticCurveTo(t,n,r,i){this._append`Q${+t},${+n},${this._x1=+r},${this._y1=+i}`}bezierCurveTo(t,n,r,i,s,a){this._append`C${+t},${+n},${+r},${+i},${this._x1=+s},${this._y1=+a}`}arcTo(t,n,r,i,s){if(t=+t,n=+n,r=+r,i=+i,s=+s,s<0)throw new Error(`negative radius: ${s}`);let a=this._x1,l=this._y1,u=r-t,c=i-n,f=a-t,g=l-n,v=f*f+g*g;if(this._x1===null)this._append`M${this._x1=t},${this._y1=n}`;else if(v>Mr)if(!(Math.abs(g*u-c*f)>Mr)||!s)this._append`L${this._x1=t},${this._y1=n}`;else{let h=r-a,$=i-l,y=u*u+c*c,p=h*h+$*$,_=Math.sqrt(y),N=Math.sqrt(v),P=s*Math.tan((Za-Math.acos((y+v-p)/(2*_*N)))/2),w=P/N,E=P/_;Math.abs(w-1)>Mr&&this._append`L${t+w*f},${n+w*g}`,this._append`A${s},${s},0,0,${+(g*h>f*$)},${this._x1=t+E*u},${this._y1=n+E*c}`}}arc(t,n,r,i,s,a){if(t=+t,n=+n,r=+r,a=!!a,r<0)throw new Error(`negative radius: ${r}`);let l=r*Math.cos(i),u=r*Math.sin(i),c=t+l,f=n+u,g=1^a,v=a?i-s:s-i;this._x1===null?this._append`M${c},${f}`:(Math.abs(this._x1-c)>Mr||Math.abs(this._y1-f)>Mr)&&this._append`L${c},${f}`,r&&(v<0&&(v=v%Qa+Qa),v>B1?this._append`A${r},${r},0,1,${g},${t-l},${n-u}A${r},${r},0,1,${g},${this._x1=c},${this._y1=f}`:v>Mr&&this._append`A${r},${r},0,${+(v>=Za)},${g},${this._x1=t+r*Math.cos(s)},${this._y1=n+r*Math.sin(s)}`)}rect(t,n,r,i){this._append`M${this._x0=this._x1=+t},${this._y0=this._y1=+n}h${r=+r}v${+i}h${-r}Z`}toString(){return this._}}function U1(e,t){var n,r=1;e==null&&(e=0),t==null&&(t=0);function i(){var s,a=n.length,l,u=0,c=0;for(s=0;s<a;++s)l=n[s],u+=l.x,c+=l.y;for(u=(u/a-e)*r,c=(c/a-t)*r,s=0;s<a;++s)l=n[s],l.x-=u,l.y-=c}return i.initialize=function(s){n=s},i.x=function(s){return arguments.length?(e=+s,i):e},i.y=function(s){return arguments.length?(t=+s,i):t},i.strength=function(s){return arguments.length?(r=+s,i):r},i}function Y1(e){const t=+this._x.call(null,e),n=+this._y.call(null,e);return gu(this.cover(t,n),t,n,e)}function gu(e,t,n,r){if(isNaN(t)||isNaN(n))return e;var i,s=e._root,a={data:r},l=e._x0,u=e._y0,c=e._x1,f=e._y1,g,v,h,$,y,p,_,N;if(!s)return e._root=a,e;for(;s.length;)if((y=t>=(g=(l+c)/2))?l=g:c=g,(p=n>=(v=(u+f)/2))?u=v:f=v,i=s,!(s=s[_=p<<1|y]))return i[_]=a,e;if(h=+e._x.call(null,s.data),$=+e._y.call(null,s.data),t===h&&n===$)return a.next=s,i?i[_]=a:e._root=a,e;do i=i?i[_]=new Array(4):e._root=new Array(4),(y=t>=(g=(l+c)/2))?l=g:c=g,(p=n>=(v=(u+f)/2))?u=v:f=v;while((_=p<<1|y)===(N=($>=v)<<1|h>=g));return i[N]=s,i[_]=a,e}function X1(e){var t,n,r=e.length,i,s,a=new Array(r),l=new Array(r),u=1/0,c=1/0,f=-1/0,g=-1/0;for(n=0;n<r;++n)isNaN(i=+this._x.call(null,t=e[n]))||isNaN(s=+this._y.call(null,t))||(a[n]=i,l[n]=s,i<u&&(u=i),i>f&&(f=i),s<c&&(c=s),s>g&&(g=s));if(u>f||c>g)return this;for(this.cover(u,c).cover(f,g),n=0;n<r;++n)gu(this,a[n],l[n],e[n]);return this}function j1(e,t){if(isNaN(e=+e)||isNaN(t=+t))return this;var n=this._x0,r=this._y0,i=this._x1,s=this._y1;if(isNaN(n))i=(n=Math.floor(e))+1,s=(r=Math.floor(t))+1;else{for(var a=i-n||1,l=this._root,u,c;n>e||e>=i||r>t||t>=s;)switch(c=(t<r)<<1|e<n,u=new Array(4),u[c]=l,l=u,a*=2,c){case 0:i=n+a,s=r+a;break;case 1:n=i-a,s=r+a;break;case 2:i=n+a,r=s-a;break;case 3:n=i-a,r=s-a;break}this._root&&this._root.length&&(this._root=l)}return this._x0=n,this._y0=r,this._x1=i,this._y1=s,this}function G1(){var e=[];return this.visit(function(t){if(!t.length)do e.push(t.data);while(t=t.next)}),e}function W1(e){return arguments.length?this.cover(+e[0][0],+e[0][1]).cover(+e[1][0],+e[1][1]):isNaN(this._x0)?void 0:[[this._x0,this._y0],[this._x1,this._y1]]}function en(e,t,n,r,i){this.node=e,this.x0=t,this.y0=n,this.x1=r,this.y1=i}function K1(e,t,n){var r,i=this._x0,s=this._y0,a,l,u,c,f=this._x1,g=this._y1,v=[],h=this._root,$,y;for(h&&v.push(new en(h,i,s,f,g)),n==null?n=1/0:(i=e-n,s=t-n,f=e+n,g=t+n,n*=n);$=v.pop();)if(!(!(h=$.node)||(a=$.x0)>f||(l=$.y0)>g||(u=$.x1)<i||(c=$.y1)<s))if(h.length){var p=(a+u)/2,_=(l+c)/2;v.push(new en(h[3],p,_,u,c),new en(h[2],a,_,p,c),new en(h[1],p,l,u,_),new en(h[0],a,l,p,_)),(y=(t>=_)<<1|e>=p)&&($=v[v.length-1],v[v.length-1]=v[v.length-1-y],v[v.length-1-y]=$)}else{var N=e-+this._x.call(null,h.data),P=t-+this._y.call(null,h.data),w=N*N+P*P;if(w<n){var E=Math.sqrt(n=w);i=e-E,s=t-E,f=e+E,g=t+E,r=h.data}}return r}function Z1(e){if(isNaN(f=+this._x.call(null,e))||isNaN(g=+this._y.call(null,e)))return this;var t,n=this._root,r,i,s,a=this._x0,l=this._y0,u=this._x1,c=this._y1,f,g,v,h,$,y,p,_;if(!n)return this;if(n.length)for(;;){if(($=f>=(v=(a+u)/2))?a=v:u=v,(y=g>=(h=(l+c)/2))?l=h:c=h,t=n,!(n=n[p=y<<1|$]))return this;if(!n.length)break;(t[p+1&3]||t[p+2&3]||t[p+3&3])&&(r=t,_=p)}for(;n.data!==e;)if(i=n,!(n=n.next))return this;return(s=n.next)&&delete n.next,i?(s?i.next=s:delete i.next,this):t?(s?t[p]=s:delete t[p],(n=t[0]||t[1]||t[2]||t[3])&&n===(t[3]||t[2]||t[1]||t[0])&&!n.length&&(r?r[_]=n:this._root=n),this):(this._root=s,this)}function Q1(e){for(var t=0,n=e.length;t<n;++t)this.remove(e[t]);return this}function J1(){return this._root}function e0(){var e=0;return this.visit(function(t){if(!t.length)do++e;while(t=t.next)}),e}function t0(e){var t=[],n,r=this._root,i,s,a,l,u;for(r&&t.push(new en(r,this._x0,this._y0,this._x1,this._y1));n=t.pop();)if(!e(r=n.node,s=n.x0,a=n.y0,l=n.x1,u=n.y1)&&r.length){var c=(s+l)/2,f=(a+u)/2;(i=r[3])&&t.push(new en(i,c,f,l,u)),(i=r[2])&&t.push(new en(i,s,f,c,u)),(i=r[1])&&t.push(new en(i,c,a,l,f)),(i=r[0])&&t.push(new en(i,s,a,c,f))}return this}function n0(e){var t=[],n=[],r;for(this._root&&t.push(new en(this._root,this._x0,this._y0,this._x1,this._y1));r=t.pop();){var i=r.node;if(i.length){var s,a=r.x0,l=r.y0,u=r.x1,c=r.y1,f=(a+u)/2,g=(l+c)/2;(s=i[0])&&t.push(new en(s,a,l,f,g)),(s=i[1])&&t.push(new en(s,f,l,u,g)),(s=i[2])&&t.push(new en(s,a,g,f,c)),(s=i[3])&&t.push(new en(s,f,g,u,c))}n.push(r)}for(;r=n.pop();)e(r.node,r.x0,r.y0,r.x1,r.y1);return this}function r0(e){return e[0]}function i0(e){return arguments.length?(this._x=e,this):this._x}function s0(e){return e[1]}function a0(e){return arguments.length?(this._y=e,this):this._y}function ko(e,t,n){var r=new Eo(t??r0,n??s0,NaN,NaN,NaN,NaN);return e==null?r:r.addAll(e)}function Eo(e,t,n,r,i,s){this._x=e,this._y=t,this._x0=n,this._y0=r,this._x1=i,this._y1=s,this._root=void 0}function yl(e){for(var t={data:e.data},n=t;e=e.next;)n=n.next={data:e.data};return t}var nn=ko.prototype=Eo.prototype;nn.copy=function(){var e=new Eo(this._x,this._y,this._x0,this._y0,this._x1,this._y1),t=this._root,n,r;if(!t)return e;if(!t.length)return e._root=yl(t),e;for(n=[{source:t,target:e._root=new Array(4)}];t=n.pop();)for(var i=0;i<4;++i)(r=t.source[i])&&(r.length?n.push({source:r,target:t.target[i]=new Array(4)}):t.target[i]=yl(r));return e};nn.add=Y1;nn.addAll=X1;nn.cover=j1;nn.data=G1;nn.extent=W1;nn.find=K1;nn.remove=Z1;nn.removeAll=Q1;nn.root=J1;nn.size=e0;nn.visit=t0;nn.visitAfter=n0;nn.x=i0;nn.y=a0;function Br(e){return function(){return e}}function mr(e){return(e()-.5)*1e-6}function o0(e){return e.x+e.vx}function l0(e){return e.y+e.vy}function c0(e){var t,n,r,i=1,s=1;typeof e!="function"&&(e=Br(e==null?1:+e));function a(){for(var c,f=t.length,g,v,h,$,y,p,_=0;_<s;++_)for(g=ko(t,o0,l0).visitAfter(l),c=0;c<f;++c)v=t[c],y=n[v.index],p=y*y,h=v.x+v.vx,$=v.y+v.vy,g.visit(N);function N(P,w,E,C,F){var O=P.data,ue=P.r,G=y+ue;if(O){if(O.index>v.index){var ge=h-O.x-O.vx,Ve=$-O.y-O.vy,Re=ge*ge+Ve*Ve;Re<G*G&&(ge===0&&(ge=mr(r),Re+=ge*ge),Ve===0&&(Ve=mr(r),Re+=Ve*Ve),Re=(G-(Re=Math.sqrt(Re)))/Re*i,v.vx+=(ge*=Re)*(G=(ue*=ue)/(p+ue)),v.vy+=(Ve*=Re)*G,O.vx-=ge*(G=1-G),O.vy-=Ve*G)}return}return w>h+G||C<h-G||E>$+G||F<$-G}}function l(c){if(c.data)return c.r=n[c.data.index];for(var f=c.r=0;f<4;++f)c[f]&&c[f].r>c.r&&(c.r=c[f].r)}function u(){if(t){var c,f=t.length,g;for(n=new Array(f),c=0;c<f;++c)g=t[c],n[g.index]=+e(g,c,t)}}return a.initialize=function(c,f){t=c,r=f,u()},a.iterations=function(c){return arguments.length?(s=+c,a):s},a.strength=function(c){return arguments.length?(i=+c,a):i},a.radius=function(c){return arguments.length?(e=typeof c=="function"?c:Br(+c),u(),a):e},a}function u0(e){return e.index}function xl(e,t){var n=e.get(t);if(!n)throw new Error("node not found: "+t);return n}function f0(e){var t=u0,n=g,r,i=Br(30),s,a,l,u,c,f=1;e==null&&(e=[]);function g(p){return 1/Math.min(l[p.source.index],l[p.target.index])}function v(p){for(var _=0,N=e.length;_<f;++_)for(var P=0,w,E,C,F,O,ue,G;P<N;++P)w=e[P],E=w.source,C=w.target,F=C.x+C.vx-E.x-E.vx||mr(c),O=C.y+C.vy-E.y-E.vy||mr(c),ue=Math.sqrt(F*F+O*O),ue=(ue-s[P])/ue*p*r[P],F*=ue,O*=ue,C.vx-=F*(G=u[P]),C.vy-=O*G,E.vx+=F*(G=1-G),E.vy+=O*G}function h(){if(a){var p,_=a.length,N=e.length,P=new Map(a.map((E,C)=>[t(E,C,a),E])),w;for(p=0,l=new Array(_);p<N;++p)w=e[p],w.index=p,typeof w.source!="object"&&(w.source=xl(P,w.source)),typeof w.target!="object"&&(w.target=xl(P,w.target)),l[w.source.index]=(l[w.source.index]||0)+1,l[w.target.index]=(l[w.target.index]||0)+1;for(p=0,u=new Array(N);p<N;++p)w=e[p],u[p]=l[w.source.index]/(l[w.source.index]+l[w.target.index]);r=new Array(N),$(),s=new Array(N),y()}}function $(){if(a)for(var p=0,_=e.length;p<_;++p)r[p]=+n(e[p],p,e)}function y(){if(a)for(var p=0,_=e.length;p<_;++p)s[p]=+i(e[p],p,e)}return v.initialize=function(p,_){a=p,c=_,h()},v.links=function(p){return arguments.length?(e=p,h(),v):e},v.id=function(p){return arguments.length?(t=p,v):t},v.iterations=function(p){return arguments.length?(f=+p,v):f},v.strength=function(p){return arguments.length?(n=typeof p=="function"?p:Br(+p),$(),v):n},v.distance=function(p){return arguments.length?(i=typeof p=="function"?p:Br(+p),y(),v):i},v}const v0=1664525,d0=1013904223,wl=4294967296;function h0(){let e=1;return()=>(e=(v0*e+d0)%wl)/wl}function p0(e){return e.x}function _0(e){return e.y}var g0=10,m0=Math.PI*(3-Math.sqrt(5));function y0(e){var t,n=1,r=.001,i=1-Math.pow(r,1/300),s=0,a=.6,l=new Map,u=wo(g),c=cs("tick","end"),f=h0();e==null&&(e=[]);function g(){v(),c.call("tick",t),n<r&&(u.stop(),c.call("end",t))}function v(y){var p,_=e.length,N;y===void 0&&(y=1);for(var P=0;P<y;++P)for(n+=(s-n)*i,l.forEach(function(w){w(n)}),p=0;p<_;++p)N=e[p],N.fx==null?N.x+=N.vx*=a:(N.x=N.fx,N.vx=0),N.fy==null?N.y+=N.vy*=a:(N.y=N.fy,N.vy=0);return t}function h(){for(var y=0,p=e.length,_;y<p;++y){if(_=e[y],_.index=y,_.fx!=null&&(_.x=_.fx),_.fy!=null&&(_.y=_.fy),isNaN(_.x)||isNaN(_.y)){var N=g0*Math.sqrt(.5+y),P=y*m0;_.x=N*Math.cos(P),_.y=N*Math.sin(P)}(isNaN(_.vx)||isNaN(_.vy))&&(_.vx=_.vy=0)}}function $(y){return y.initialize&&y.initialize(e,f),y}return h(),t={tick:v,restart:function(){return u.restart(g),t},stop:function(){return u.stop(),t},nodes:function(y){return arguments.length?(e=y,h(),l.forEach($),t):e},alpha:function(y){return arguments.length?(n=+y,t):n},alphaMin:function(y){return arguments.length?(r=+y,t):r},alphaDecay:function(y){return arguments.length?(i=+y,t):+i},alphaTarget:function(y){return arguments.length?(s=+y,t):s},velocityDecay:function(y){return arguments.length?(a=1-y,t):1-a},randomSource:function(y){return arguments.length?(f=y,l.forEach($),t):f},force:function(y,p){return arguments.length>1?(p==null?l.delete(y):l.set(y,$(p)),t):l.get(y)},find:function(y,p,_){var N=0,P=e.length,w,E,C,F,O;for(_==null?_=1/0:_*=_,N=0;N<P;++N)F=e[N],w=y-F.x,E=p-F.y,C=w*w+E*E,C<_&&(O=F,_=C);return O},on:function(y,p){return arguments.length>1?(c.on(y,p),t):c.on(y)}}}function x0(){var e,t,n,r,i=Br(-30),s,a=1,l=1/0,u=.81;function c(h){var $,y=e.length,p=ko(e,p0,_0).visitAfter(g);for(r=h,$=0;$<y;++$)t=e[$],p.visit(v)}function f(){if(e){var h,$=e.length,y;for(s=new Array($),h=0;h<$;++h)y=e[h],s[y.index]=+i(y,h,e)}}function g(h){var $=0,y,p,_=0,N,P,w;if(h.length){for(N=P=w=0;w<4;++w)(y=h[w])&&(p=Math.abs(y.value))&&($+=y.value,_+=p,N+=p*y.x,P+=p*y.y);h.x=N/_,h.y=P/_}else{y=h,y.x=y.data.x,y.y=y.data.y;do $+=s[y.data.index];while(y=y.next)}h.value=$}function v(h,$,y,p){if(!h.value)return!0;var _=h.x-t.x,N=h.y-t.y,P=p-$,w=_*_+N*N;if(P*P/u<w)return w<l&&(_===0&&(_=mr(n),w+=_*_),N===0&&(N=mr(n),w+=N*N),w<a&&(w=Math.sqrt(a*w)),t.vx+=_*h.value*r/w,t.vy+=N*h.value*r/w),!0;if(h.length||w>=l)return;(h.data!==t||h.next)&&(_===0&&(_=mr(n),w+=_*_),N===0&&(N=mr(n),w+=N*N),w<a&&(w=Math.sqrt(a*w)));do h.data!==t&&(P=s[h.data.index]*r/w,t.vx+=_*P,t.vy+=N*P);while(h=h.next)}return c.initialize=function(h,$){e=h,n=$,f()},c.strength=function(h){return arguments.length?(i=typeof h=="function"?h:Br(+h),f(),c):i},c.distanceMin=function(h){return arguments.length?(a=h*h,c):Math.sqrt(a)},c.distanceMax=function(h){return arguments.length?(l=h*h,c):Math.sqrt(l)},c.theta=function(h){return arguments.length?(u=h*h,c):Math.sqrt(u)},c}function w0(e){var t=0,n=e.children,r=n&&n.length;if(!r)t=1;else for(;--r>=0;)t+=n[r].value;e.value=t}function $0(){return this.eachAfter(w0)}function b0(e,t){let n=-1;for(const r of this)e.call(t,r,++n,this);return this}function k0(e,t){for(var n=this,r=[n],i,s,a=-1;n=r.pop();)if(e.call(t,n,++a,this),i=n.children)for(s=i.length-1;s>=0;--s)r.push(i[s]);return this}function E0(e,t){for(var n=this,r=[n],i=[],s,a,l,u=-1;n=r.pop();)if(i.push(n),s=n.children)for(a=0,l=s.length;a<l;++a)r.push(s[a]);for(;n=i.pop();)e.call(t,n,++u,this);return this}function z0(e,t){let n=-1;for(const r of this)if(e.call(t,r,++n,this))return r}function N0(e){return this.eachAfter(function(t){for(var n=+e(t.data)||0,r=t.children,i=r&&r.length;--i>=0;)n+=r[i].value;t.value=n})}function M0(e){return this.eachBefore(function(t){t.children&&t.children.sort(e)})}function A0(e){for(var t=this,n=S0(t,e),r=[t];t!==n;)t=t.parent,r.push(t);for(var i=r.length;e!==n;)r.splice(i,0,e),e=e.parent;return r}function S0(e,t){if(e===t)return e;var n=e.ancestors(),r=t.ancestors(),i=null;for(e=n.pop(),t=r.pop();e===t;)i=e,e=n.pop(),t=r.pop();return i}function T0(){for(var e=this,t=[e];e=e.parent;)t.push(e);return t}function C0(){return Array.from(this)}function P0(){var e=[];return this.eachBefore(function(t){t.children||e.push(t)}),e}function D0(){var e=this,t=[];return e.each(function(n){n!==e&&t.push({source:n.parent,target:n})}),t}function*L0(){var e=this,t,n=[e],r,i,s;do for(t=n.reverse(),n=[];e=t.pop();)if(yield e,r=e.children)for(i=0,s=r.length;i<s;++i)n.push(r[i]);while(n.length)}function zo(e,t){e instanceof Map?(e=[void 0,e],t===void 0&&(t=O0)):t===void 0&&(t=I0);for(var n=new Ji(e),r,i=[n],s,a,l,u;r=i.pop();)if((a=t(r.data))&&(u=(a=Array.from(a)).length))for(r.children=a,l=u-1;l>=0;--l)i.push(s=a[l]=new Ji(a[l])),s.parent=r,s.depth=r.depth+1;return n.eachBefore(q0)}function R0(){return zo(this).eachBefore(F0)}function I0(e){return e.children}function O0(e){return Array.isArray(e)?e[1]:null}function F0(e){e.data.value!==void 0&&(e.value=e.data.value),e.data=e.data.data}function q0(e){var t=0;do e.height=t;while((e=e.parent)&&e.height<++t)}function Ji(e){this.data=e,this.depth=this.height=0,this.parent=null}Ji.prototype=zo.prototype={constructor:Ji,count:$0,each:b0,eachAfter:E0,eachBefore:k0,find:z0,sum:N0,sort:M0,path:A0,ancestors:T0,descendants:C0,leaves:P0,links:D0,copy:R0,[Symbol.iterator]:L0};function B0(e,t){return e.parent===t.parent?1:2}function Ea(e){var t=e.children;return t?t[0]:e.t}function za(e){var t=e.children;return t?t[t.length-1]:e.t}function V0(e,t,n){var r=n/(t.i-e.i);t.c-=r,t.s+=n,e.c+=r,t.z+=n,t.m+=n}function H0(e){for(var t=0,n=0,r=e.children,i=r.length,s;--i>=0;)s=r[i],s.z+=t,s.m+=t,t+=s.s+(n+=s.c)}function U0(e,t,n){return e.a.parent===t.parent?e.a:n}function As(e,t){this._=e,this.parent=null,this.children=null,this.A=null,this.a=this,this.z=0,this.m=0,this.c=0,this.s=0,this.t=null,this.i=t}As.prototype=Object.create(Ji.prototype);function Y0(e){for(var t=new As(e,0),n,r=[t],i,s,a,l;n=r.pop();)if(s=n._.children)for(n.children=new Array(l=s.length),a=l-1;a>=0;--a)r.push(i=n.children[a]=new As(s[a],a)),i.parent=n;return(t.parent=new As(null,0)).children=[t],t}function X0(){var e=B0,t=1,n=1,r=null;function i(c){var f=Y0(c);if(f.eachAfter(s),f.parent.m=-f.z,f.eachBefore(a),r)c.eachBefore(u);else{var g=c,v=c,h=c;c.eachBefore(function(N){N.x<g.x&&(g=N),N.x>v.x&&(v=N),N.depth>h.depth&&(h=N)});var $=g===v?1:e(g,v)/2,y=$-g.x,p=t/(v.x+$+y),_=n/(h.depth||1);c.eachBefore(function(N){N.x=(N.x+y)*p,N.y=N.depth*_})}return c}function s(c){var f=c.children,g=c.parent.children,v=c.i?g[c.i-1]:null;if(f){H0(c);var h=(f[0].z+f[f.length-1].z)/2;v?(c.z=v.z+e(c._,v._),c.m=c.z-h):c.z=h}else v&&(c.z=v.z+e(c._,v._));c.parent.A=l(c,v,c.parent.A||g[0])}function a(c){c._.x=c.z+c.parent.m,c.m+=c.parent.m}function l(c,f,g){if(f){for(var v=c,h=c,$=f,y=v.parent.children[0],p=v.m,_=h.m,N=$.m,P=y.m,w;$=za($),v=Ea(v),$&&v;)y=Ea(y),h=za(h),h.a=c,w=$.z+N-v.z-p+e($._,v._),w>0&&(V0(U0($,c,g),c,w),p+=w,_+=w),N+=$.m,p+=v.m,P+=y.m,_+=h.m;$&&!za(h)&&(h.t=$,h.m+=N-_),v&&!Ea(y)&&(y.t=v,y.m+=p-P,g=c)}return g}function u(c){c.x*=t,c.y=c.depth*n}return i.separation=function(c){return arguments.length?(e=c,i):e},i.size=function(c){return arguments.length?(r=!1,t=+c[0],n=+c[1],i):r?null:[t,n]},i.nodeSize=function(c){return arguments.length?(r=!0,t=+c[0],n=+c[1],i):r?[t,n]:null},i}function $l(e){return function(){return e}}function j0(e){let t=3;return e.digits=function(n){if(!arguments.length)return t;if(n==null)t=null;else{const r=Math.floor(n);if(!(r>=0))throw new RangeError(`invalid digits: ${n}`);t=r}return e},()=>new H1(t)}var G0=Array.prototype.slice;function W0(e){return e[0]}function K0(e){return e[1]}class Z0{constructor(t,n){this._context=t,this._x=n}areaStart(){this._line=0}areaEnd(){this._line=NaN}lineStart(){this._point=0}lineEnd(){(this._line||this._line!==0&&this._point===1)&&this._context.closePath(),this._line=1-this._line}point(t,n){switch(t=+t,n=+n,this._point){case 0:{this._point=1,this._line?this._context.lineTo(t,n):this._context.moveTo(t,n);break}case 1:this._point=2;default:{this._x?this._context.bezierCurveTo(this._x0=(this._x0+t)/2,this._y0,this._x0,n,t,n):this._context.bezierCurveTo(this._x0,this._y0=(this._y0+n)/2,t,this._y0,t,n);break}}this._x0=t,this._y0=n}}function Q0(e){return new Z0(e,!0)}function J0(e){return e.source}function eg(e){return e.target}function tg(e){let t=J0,n=eg,r=W0,i=K0,s=null,a=null,l=j0(u);function u(){let c;const f=G0.call(arguments),g=t.apply(this,f),v=n.apply(this,f);if(s==null&&(a=e(c=l())),a.lineStart(),f[0]=g,a.point(+r.apply(this,f),+i.apply(this,f)),f[0]=v,a.point(+r.apply(this,f),+i.apply(this,f)),a.lineEnd(),c)return a=null,c+""||null}return u.source=function(c){return arguments.length?(t=c,u):t},u.target=function(c){return arguments.length?(n=c,u):n},u.x=function(c){return arguments.length?(r=typeof c=="function"?c:$l(+c),u):r},u.y=function(c){return arguments.length?(i=typeof c=="function"?c:$l(+c),u):i},u.context=function(c){return arguments.length?(c==null?s=a=null:a=e(s=c),u):s},u}function ng(){return tg(Q0)}const ms=e=>()=>e;function rg(e,{sourceEvent:t,target:n,transform:r,dispatch:i}){Object.defineProperties(this,{type:{value:e,enumerable:!0,configurable:!0},sourceEvent:{value:t,enumerable:!0,configurable:!0},target:{value:n,enumerable:!0,configurable:!0},transform:{value:r,enumerable:!0,configurable:!0},_:{value:i}})}function tr(e,t,n){this.k=e,this.x=t,this.y=n}tr.prototype={constructor:tr,scale:function(e){return e===1?this:new tr(this.k*e,this.x,this.y)},translate:function(e,t){return e===0&t===0?this:new tr(this.k,this.x+this.k*e,this.y+this.k*t)},apply:function(e){return[e[0]*this.k+this.x,e[1]*this.k+this.y]},applyX:function(e){return e*this.k+this.x},applyY:function(e){return e*this.k+this.y},invert:function(e){return[(e[0]-this.x)/this.k,(e[1]-this.y)/this.k]},invertX:function(e){return(e-this.x)/this.k},invertY:function(e){return(e-this.y)/this.k},rescaleX:function(e){return e.copy().domain(e.range().map(this.invertX,this).map(e.invert,e))},rescaleY:function(e){return e.copy().domain(e.range().map(this.invertY,this).map(e.invert,e))},toString:function(){return"translate("+this.x+","+this.y+") scale("+this.k+")"}};var oa=new tr(1,0,0);tr.prototype;function Na(e){e.stopImmediatePropagation()}function Ti(e){e.preventDefault(),e.stopImmediatePropagation()}function ig(e){return(!e.ctrlKey||e.type==="wheel")&&!e.button}function sg(){var e=this;return e instanceof SVGElement?(e=e.ownerSVGElement||e,e.hasAttribute("viewBox")?(e=e.viewBox.baseVal,[[e.x,e.y],[e.x+e.width,e.y+e.height]]):[[0,0],[e.width.baseVal.value,e.height.baseVal.value]]):[[0,0],[e.clientWidth,e.clientHeight]]}function bl(){return this.__zoom||oa}function ag(e){return-e.deltaY*(e.deltaMode===1?.05:e.deltaMode?1:.002)*(e.ctrlKey?10:1)}function og(){return navigator.maxTouchPoints||"ontouchstart"in this}function lg(e,t,n){var r=e.invertX(t[0][0])-n[0][0],i=e.invertX(t[1][0])-n[1][0],s=e.invertY(t[0][1])-n[0][1],a=e.invertY(t[1][1])-n[1][1];return e.translate(i>r?(r+i)/2:Math.min(0,r)||Math.max(0,i),a>s?(s+a)/2:Math.min(0,s)||Math.max(0,a))}function mu(){var e=ig,t=sg,n=lg,r=ag,i=og,s=[0,1/0],a=[[-1/0,-1/0],[1/0,1/0]],l=250,u=A_,c=cs("start","zoom","end"),f,g,v,h=500,$=150,y=0,p=10;function _(k){k.property("__zoom",bl).on("wheel.zoom",O,{passive:!1}).on("mousedown.zoom",ue).on("dblclick.zoom",G).filter(i).on("touchstart.zoom",ge).on("touchmove.zoom",Ve).on("touchend.zoom touchcancel.zoom",Re).style("-webkit-tap-highlight-color","rgba(0,0,0,0)")}_.transform=function(k,I,A,H){var Q=k.selection?k.selection():k;Q.property("__zoom",bl),k!==Q?E(k,I,A,H):Q.interrupt().each(function(){C(this,arguments).event(H).start().zoom(null,typeof I=="function"?I.apply(this,arguments):I).end()})},_.scaleBy=function(k,I,A,H){_.scaleTo(k,function(){var Q=this.__zoom.k,j=typeof I=="function"?I.apply(this,arguments):I;return Q*j},A,H)},_.scaleTo=function(k,I,A,H){_.transform(k,function(){var Q=t.apply(this,arguments),j=this.__zoom,W=A==null?w(Q):typeof A=="function"?A.apply(this,arguments):A,me=j.invert(W),Ce=typeof I=="function"?I.apply(this,arguments):I;return n(P(N(j,Ce),W,me),Q,a)},A,H)},_.translateBy=function(k,I,A,H){_.transform(k,function(){return n(this.__zoom.translate(typeof I=="function"?I.apply(this,arguments):I,typeof A=="function"?A.apply(this,arguments):A),t.apply(this,arguments),a)},null,H)},_.translateTo=function(k,I,A,H,Q){_.transform(k,function(){var j=t.apply(this,arguments),W=this.__zoom,me=H==null?w(j):typeof H=="function"?H.apply(this,arguments):H;return n(oa.translate(me[0],me[1]).scale(W.k).translate(typeof I=="function"?-I.apply(this,arguments):-I,typeof A=="function"?-A.apply(this,arguments):-A),j,a)},H,Q)};function N(k,I){return I=Math.max(s[0],Math.min(s[1],I)),I===k.k?k:new tr(I,k.x,k.y)}function P(k,I,A){var H=I[0]-A[0]*k.k,Q=I[1]-A[1]*k.k;return H===k.x&&Q===k.y?k:new tr(k.k,H,Q)}function w(k){return[(+k[0][0]+ +k[1][0])/2,(+k[0][1]+ +k[1][1])/2]}function E(k,I,A,H){k.on("start.zoom",function(){C(this,arguments).event(H).start()}).on("interrupt.zoom end.zoom",function(){C(this,arguments).event(H).end()}).tween("zoom",function(){var Q=this,j=arguments,W=C(Q,j).event(H),me=t.apply(Q,j),Ce=A==null?w(me):typeof A=="function"?A.apply(Q,j):A,it=Math.max(me[1][0]-me[0][0],me[1][1]-me[0][1]),Ie=Q.__zoom,Pe=typeof I=="function"?I.apply(Q,j):I,lt=u(Ie.invert(Ce).concat(it/Ie.k),Pe.invert(Ce).concat(it/Pe.k));return function(ut){if(ut===1)ut=Pe;else{var gt=lt(ut),yt=it/gt[2];ut=new tr(yt,Ce[0]-gt[0]*yt,Ce[1]-gt[1]*yt)}W.zoom(null,ut)}})}function C(k,I,A){return!A&&k.__zooming||new F(k,I)}function F(k,I){this.that=k,this.args=I,this.active=0,this.sourceEvent=null,this.extent=t.apply(k,I),this.taps=0}F.prototype={event:function(k){return k&&(this.sourceEvent=k),this},start:function(){return++this.active===1&&(this.that.__zooming=this,this.emit("start")),this},zoom:function(k,I){return this.mouse&&k!=="mouse"&&(this.mouse[1]=I.invert(this.mouse[0])),this.touch0&&k!=="touch"&&(this.touch0[1]=I.invert(this.touch0[0])),this.touch1&&k!=="touch"&&(this.touch1[1]=I.invert(this.touch1[0])),this.that.__zoom=I,this.emit("zoom"),this},end:function(){return--this.active===0&&(delete this.that.__zooming,this.emit("end")),this},emit:function(k){var I=pn(this.that).datum();c.call(k,this.that,new rg(k,{sourceEvent:this.sourceEvent,target:_,transform:this.that.__zoom,dispatch:c}),I)}};function O(k,...I){if(!e.apply(this,arguments))return;var A=C(this,I).event(k),H=this.__zoom,Q=Math.max(s[0],Math.min(s[1],H.k*Math.pow(2,r.apply(this,arguments)))),j=Zn(k);if(A.wheel)(A.mouse[0][0]!==j[0]||A.mouse[0][1]!==j[1])&&(A.mouse[1]=H.invert(A.mouse[0]=j)),clearTimeout(A.wheel);else{if(H.k===Q)return;A.mouse=[j,H.invert(j)],Ms(this),A.start()}Ti(k),A.wheel=setTimeout(W,$),A.zoom("mouse",n(P(N(H,Q),A.mouse[0],A.mouse[1]),A.extent,a));function W(){A.wheel=null,A.end()}}function ue(k,...I){if(v||!e.apply(this,arguments))return;var A=k.currentTarget,H=C(this,I,!0).event(k),Q=pn(k.view).on("mousemove.zoom",Ce,!0).on("mouseup.zoom",it,!0),j=Zn(k,A),W=k.clientX,me=k.clientY;nu(k.view),Na(k),H.mouse=[j,this.__zoom.invert(j)],Ms(this),H.start();function Ce(Ie){if(Ti(Ie),!H.moved){var Pe=Ie.clientX-W,lt=Ie.clientY-me;H.moved=Pe*Pe+lt*lt>y}H.event(Ie).zoom("mouse",n(P(H.that.__zoom,H.mouse[0]=Zn(Ie,A),H.mouse[1]),H.extent,a))}function it(Ie){Q.on("mousemove.zoom mouseup.zoom",null),ru(Ie.view,H.moved),Ti(Ie),H.event(Ie).end()}}function G(k,...I){if(e.apply(this,arguments)){var A=this.__zoom,H=Zn(k.changedTouches?k.changedTouches[0]:k,this),Q=A.invert(H),j=A.k*(k.shiftKey?.5:2),W=n(P(N(A,j),H,Q),t.apply(this,I),a);Ti(k),l>0?pn(this).transition().duration(l).call(E,W,H,k):pn(this).call(_.transform,W,H,k)}}function ge(k,...I){if(e.apply(this,arguments)){var A=k.touches,H=A.length,Q=C(this,I,k.changedTouches.length===H).event(k),j,W,me,Ce;for(Na(k),W=0;W<H;++W)me=A[W],Ce=Zn(me,this),Ce=[Ce,this.__zoom.invert(Ce),me.identifier],Q.touch0?!Q.touch1&&Q.touch0[2]!==Ce[2]&&(Q.touch1=Ce,Q.taps=0):(Q.touch0=Ce,j=!0,Q.taps=1+!!f);f&&(f=clearTimeout(f)),j&&(Q.taps<2&&(g=Ce[0],f=setTimeout(function(){f=null},h)),Ms(this),Q.start())}}function Ve(k,...I){if(this.__zooming){var A=C(this,I).event(k),H=k.changedTouches,Q=H.length,j,W,me,Ce;for(Ti(k),j=0;j<Q;++j)W=H[j],me=Zn(W,this),A.touch0&&A.touch0[2]===W.identifier?A.touch0[0]=me:A.touch1&&A.touch1[2]===W.identifier&&(A.touch1[0]=me);if(W=A.that.__zoom,A.touch1){var it=A.touch0[0],Ie=A.touch0[1],Pe=A.touch1[0],lt=A.touch1[1],ut=(ut=Pe[0]-it[0])*ut+(ut=Pe[1]-it[1])*ut,gt=(gt=lt[0]-Ie[0])*gt+(gt=lt[1]-Ie[1])*gt;W=N(W,Math.sqrt(ut/gt)),me=[(it[0]+Pe[0])/2,(it[1]+Pe[1])/2],Ce=[(Ie[0]+lt[0])/2,(Ie[1]+lt[1])/2]}else if(A.touch0)me=A.touch0[0],Ce=A.touch0[1];else return;A.zoom("touch",n(P(W,me,Ce),A.extent,a))}}function Re(k,...I){if(this.__zooming){var A=C(this,I).event(k),H=k.changedTouches,Q=H.length,j,W;for(Na(k),v&&clearTimeout(v),v=setTimeout(function(){v=null},h),j=0;j<Q;++j)W=H[j],A.touch0&&A.touch0[2]===W.identifier?delete A.touch0:A.touch1&&A.touch1[2]===W.identifier&&delete A.touch1;if(A.touch1&&!A.touch0&&(A.touch0=A.touch1,delete A.touch1),A.touch0)A.touch0[1]=this.__zoom.invert(A.touch0[0]);else if(A.end(),A.taps===2&&(W=Zn(W,this),Math.hypot(g[0]-W[0],g[1]-W[1])<p)){var me=pn(this).on("dblclick.zoom");me&&me.apply(this,arguments)}}}return _.wheelDelta=function(k){return arguments.length?(r=typeof k=="function"?k:ms(+k),_):r},_.filter=function(k){return arguments.length?(e=typeof k=="function"?k:ms(!!k),_):e},_.touchable=function(k){return arguments.length?(i=typeof k=="function"?k:ms(!!k),_):i},_.extent=function(k){return arguments.length?(t=typeof k=="function"?k:ms([[+k[0][0],+k[0][1]],[+k[1][0],+k[1][1]]]),_):t},_.scaleExtent=function(k){return arguments.length?(s[0]=+k[0],s[1]=+k[1],_):[s[0],s[1]]},_.translateExtent=function(k){return arguments.length?(a[0][0]=+k[0][0],a[1][0]=+k[1][0],a[0][1]=+k[0][1],a[1][1]=+k[1][1],_):[[a[0][0],a[0][1]],[a[1][0],a[1][1]]]},_.constrain=function(k){return arguments.length?(n=k,_):n},_.duration=function(k){return arguments.length?(l=+k,_):l},_.interpolate=function(k){return arguments.length?(u=k,_):u},_.on=function(){var k=c.on.apply(c,arguments);return k===c?_:k},_.clickDistance=function(k){return arguments.length?(y=(k=+k)*k,_):Math.sqrt(y)},_.tapDistance=function(k){return arguments.length?(p=+k,_):p},_}var cg=z('<div class="loading svelte-1lwz2ra">Loading visualization...</div>'),ug=z('<div class="error svelte-1lwz2ra"> </div>'),fg=z('<div class="empty svelte-1lwz2ra">No concepts to display. Remember some episodes first.</div>'),vg=z("<li> </li>"),dg=z('<div class="section svelte-1lwz2ra"><h4 class="svelte-1lwz2ra">Conditions</h4> <ul class="svelte-1lwz2ra"></ul></div>'),hg=z("<li> </li>"),pg=z('<div class="section svelte-1lwz2ra"><h4 class="svelte-1lwz2ra">Exceptions</h4> <ul class="svelte-1lwz2ra"></ul></div>'),_g=z('<span class="tag svelte-1lwz2ra"> </span>'),gg=z('<div class="tags svelte-1lwz2ra"></div>'),mg=z('<div class="episode svelte-1lwz2ra"><span class="episode-type svelte-1lwz2ra"> </span> <span class="episode-content svelte-1lwz2ra"> </span></div>'),yg=z('<div class="section svelte-1lwz2ra"><h4 class="svelte-1lwz2ra"> </h4> <div class="episodes svelte-1lwz2ra"></div></div>'),xg=z('<div class="detail-panel svelte-1lwz2ra"><div class="detail-header svelte-1lwz2ra"><h3 class="svelte-1lwz2ra"> </h3> <button class="close-btn svelte-1lwz2ra">&times;</button></div> <div class="detail-content svelte-1lwz2ra"><p class="summary svelte-1lwz2ra"> </p> <div class="meta svelte-1lwz2ra"><span class="confidence"> </span> <span class="count"> </span></div> <!> <!> <!> <!></div></div>'),wg=z('<div class="detail-content svelte-1lwz2ra"><div class="loading-inline svelte-1lwz2ra">Loading episode...</div></div>'),$g=z('<span class="episode-status consolidated svelte-1lwz2ra">Consolidated</span>'),bg=z('<span class="episode-status pending svelte-1lwz2ra">Pending</span>'),kg=z('<span class="entity-tag svelte-1lwz2ra"> </span>'),Eg=z('<div class="section svelte-1lwz2ra"><h4 class="svelte-1lwz2ra"> </h4> <div class="entity-tags svelte-1lwz2ra"></div></div>'),zg=z('<div class="detail-content svelte-1lwz2ra"><div class="episode-meta svelte-1lwz2ra"><span class="episode-type-badge svelte-1lwz2ra"> </span> <span class="episode-date svelte-1lwz2ra"> </span> <!></div> <div class="episode-full-content svelte-1lwz2ra"> </div> <!></div>'),Ng=z('<div class="detail-panel svelte-1lwz2ra"><div class="detail-header svelte-1lwz2ra"><h3 class="svelte-1lwz2ra"> </h3> <button class="close-btn svelte-1lwz2ra">&times;</button></div> <!></div>'),Mg=z('<div class="detail-panel-placeholder svelte-1lwz2ra"></div>'),Ag=z('<div class="legend-item svelte-1lwz2ra"><span class="legend-color small svelte-1lwz2ra"></span> <span> </span></div>'),Sg=z('<div class="tooltip svelte-1lwz2ra"><div class="tooltip-title svelte-1lwz2ra"> </div> <div class="tooltip-content svelte-1lwz2ra"> </div></div>'),Tg=z('<div class="concept-map svelte-1lwz2ra"><div class="header svelte-1lwz2ra"><h2 class="svelte-1lwz2ra">Concept Map</h2> <div class="controls svelte-1lwz2ra"><button class="control-btn svelte-1lwz2ra" title="Zoom In"><!></button> <button class="control-btn svelte-1lwz2ra" title="Zoom Out"><!></button> <button class="control-btn svelte-1lwz2ra" title="Reset View"><!></button></div></div> <div class="content svelte-1lwz2ra"><div class="visualization svelte-1lwz2ra"><!></div> <!> <!></div> <div class="legend svelte-1lwz2ra"><div class="legend-section svelte-1lwz2ra"><span class="legend-title svelte-1lwz2ra">Confidence:</span> <div class="legend-item svelte-1lwz2ra"><span class="legend-color svelte-1lwz2ra" style="background: #22c55e"></span> <span>High (70%+)</span></div> <div class="legend-item svelte-1lwz2ra"><span class="legend-color svelte-1lwz2ra" style="background: #f59e0b"></span> <span>Medium</span></div> <div class="legend-item svelte-1lwz2ra"><span class="legend-color svelte-1lwz2ra" style="background: #ef4444"></span> <span>Low</span></div></div> <div class="legend-section svelte-1lwz2ra"><span class="legend-title svelte-1lwz2ra">Episode:</span> <!></div></div> <!></div>');function Cg(e,t){Xn(t,!1);const n=()=>at(Jo,"$conceptMapData",a),r=()=>at(or,"$currentDb",a),i=()=>at(ma,"$conceptMapLoading",a),s=()=>at(ya,"$conceptMapError",a),[a,l]=zr();let u=ze(),c=800,f=600,g=ze(!1),v=null,h=null,$=ze({visible:!1,x:0,y:0,title:"",content:""}),y=ze(null),p=ze(null),_=ze(!1);const N={observation:"#3b82f6",decision:"#f97316",question:"#a855f7",meta:"#22c55e",preference:"#ec4899"};Kr(()=>{R(g,!0),P();const V=new ResizeObserver(Y=>{const T=Y[0];T&&(c=T.contentRect.width,f=T.contentRect.height,n()&&E())});return V.observe(o(u)),()=>V.disconnect()});async function P(){if(r()){ma.set(!0),ya.set(null);try{const V=await mv();Jo.set(V),E()}catch(V){ya.set(V instanceof Error?V.message:"Failed to load data")}finally{ma.set(!1)}}}function w(V){return{name:"Memory",nodeType:"root",children:V.nodes.map(Y=>({id:Y.id,name:Y.title||Y.summary.substring(0,40),title:Y.title,summary:Y.summary,confidence:Y.confidence,instance_count:Y.instance_count,nodeType:"concept",children:(Y.source_episodes||[]).map(T=>({id:T.id,name:T.title||T.content.substring(0,30),title:T.title,type:T.type,content:T.content,nodeType:"episode"}))}))}}function E(){if(!n()||!o(u)||c===0||f===0)return;pn(o(u)).selectAll("svg").remove();const V=w(n());if(!V.children||V.children.length===0)return;const Y=zo(V);Y.sort((ne,Oe)=>ph(ne.data.name,Oe.data.name)),Y.descendants().length;const T=20,X=180;X0().nodeSize([T,X])(Y);let q=1/0,he=-1/0;Y.each(ne=>{ne.x>he&&(he=ne.x),ne.x<q&&(q=ne.x)});const ye=he-q+T*2,ke=(Y.height+1)*X;v=pn(o(u)).append("svg").attr("width",c).attr("height",f).attr("viewBox",[-X/2,q-T,ke+X,ye].join(" ")).style("font","10px sans-serif");const ee=v.append("g");h=mu().scaleExtent([.2,4]).on("zoom",ne=>{ee.attr("transform",ne.transform)}),v.call(h),ee.append("g").attr("fill","none").attr("stroke","var(--color-border)").attr("stroke-opacity",.5).attr("stroke-width",1.5).selectAll("path").data(Y.links()).join("path").attr("d",ng().x(ne=>ne.y).y(ne=>ne.x));const Me=ee.append("g").selectAll("g").data(Y.descendants()).join("g").attr("transform",ne=>`translate(${ne.y},${ne.x})`);Me.append("circle").attr("r",ne=>C(ne.data)).attr("fill",ne=>F(ne.data)).attr("stroke",ne=>ne.data.nodeType==="concept"?ue(ne.data):"none").attr("stroke-width",2).style("cursor",ne=>ne.data.nodeType!=="root"?"pointer":"default").on("mouseover",ge).on("mouseout",Ve).on("click",Re),Me.append("text").attr("dy","0.31em").attr("x",ne=>ne.children?-C(ne.data)-6:C(ne.data)+6).attr("text-anchor",ne=>ne.children?"end":"start").attr("fill","var(--color-text)").style("font-size",ne=>ne.data.nodeType==="concept"?"11px":"9px").text(ne=>G(ne.data.name,ne.data.nodeType==="episode"?25:35)).style("pointer-events","none")}function C(V){switch(V.nodeType){case"root":return 8;case"concept":return 6;case"episode":return 4;default:return 4}}function F(V){switch(V.nodeType){case"root":return"var(--color-primary)";case"concept":return O(V);case"episode":return V.type?N[V.type]:"#71717a";default:return"#71717a"}}function O(V){const Y=V.confidence||.5;return Y>=.7?"#22c55e":Y>=.4?"#f59e0b":"#ef4444"}function ue(V){const Y=V.confidence||.5;return Y>=.7?"#16a34a":Y>=.4?"#d97706":"#dc2626"}function G(V,Y){return V.length>Y?V.substring(0,Y)+"...":V}function ge(V,Y){var q,he;if(Y.data.nodeType==="root")return;const T=Y.data;let X,$e;T.nodeType==="concept"?(X=T.title||"Concept",$e=`${((q=T.summary)==null?void 0:q.substring(0,150))||""}...
Confidence: ${Math.round((T.confidence||0)*100)}%
Instances: ${T.instance_count||0}`):(X="Episode",$e=`${((he=T.content)==null?void 0:he.substring(0,150))||""}...
Type: ${T.type||"unknown"}`),R($,{visible:!0,x:V.pageX+10,y:V.pageY+10,title:X,content:$e})}function Ve(){R($,{...o($),visible:!1})}async function Re(V,Y){var T;if(Y.data.nodeType==="concept"){R(p,null);const X=(T=n())==null?void 0:T.nodes.find($e=>$e.id===Y.data.id);X&&R(y,X)}else if(Y.data.nodeType==="episode"&&Y.data.id){R(y,null),R(_,!0);try{R(p,await Qs(Y.data.id))}catch(X){console.error("Failed to fetch episode:",X),R(p,null)}finally{R(_,!1)}}}function k(){v&&h&&v.transition().duration(300).call(h.scaleBy,1.3)}function I(){v&&h&&v.transition().duration(300).call(h.scaleBy,.7)}function A(){v&&h&&v.transition().duration(300).call(h.transform,oa)}function H(){R(y,null)}function Q(){R(p,null)}function j(V){return new Date(V).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}Un(()=>(o(g),r()),()=>{o(g)&&r()&&P()}),Gr(),ar();var W=Tg(),me=d(W),Ce=m(d(me),2),it=d(Ce);it.__click=k;var Ie=d(it);Vc(Ie,{size:18});var Pe=m(it,2);Pe.__click=I;var lt=d(Pe);Hc(lt,{size:18});var ut=m(Pe,2);ut.__click=A;var gt=d(ut);Oc(gt,{size:18});var yt=m(me,2),we=d(yt),$t=d(we);{var Dt=V=>{var Y=cg();b(V,Y)},It=V=>{var Y=ae(),T=Z(Y);{var X=q=>{var he=ug(),ye=d(he);L(()=>M(ye,s())),b(q,he)},$e=q=>{var he=ae(),ye=Z(he);{var ke=ee=>{var Me=fg();b(ee,Me)};D(ye,ee=>{n(),x(()=>!n()||n().nodes.length===0)&&ee(ke)},!0)}b(q,he)};D(T,q=>{s()?q(X):q($e,!1)},!0)}b(V,Y)};D($t,V=>{i()?V(Dt):V(It,!1)})}uo(we,V=>R(u,V),()=>o(u));var K=m(we,2);{var ve=V=>{var Y=xg(),T=d(Y),X=d(T),$e=d(X),q=m(X,2);q.__click=H;var he=m(T,2),ye=d(he),ke=d(ye),ee=m(ye,2),Me=d(ee),ne=d(Me),Oe=m(Me,2),Ze=d(Oe),B=m(ee,2);{var U=Ee=>{var De=dg(),Ue=m(d(De),2);We(Ue,5,()=>(o(y),x(()=>o(y).conditions)),Ge,(Ye,ie)=>{var oe=vg(),_e=d(oe);L(()=>M(_e,o(ie))),b(Ye,oe)}),b(Ee,De)};D(B,Ee=>{o(y),x(()=>o(y).conditions&&o(y).conditions.length>0)&&Ee(U)})}var pe=m(B,2);{var Fe=Ee=>{var De=pg(),Ue=m(d(De),2);We(Ue,5,()=>(o(y),x(()=>o(y).exceptions)),Ge,(Ye,ie)=>{var oe=hg(),_e=d(oe);L(()=>M(_e,o(ie))),b(Ye,oe)}),b(Ee,De)};D(pe,Ee=>{o(y),x(()=>o(y).exceptions&&o(y).exceptions.length>0)&&Ee(Fe)})}var de=m(pe,2);{var He=Ee=>{var De=gg();We(De,5,()=>(o(y),x(()=>o(y).tags)),Ge,(Ue,Ye)=>{var ie=_g(),oe=d(ie);L(()=>M(oe,o(Ye))),b(Ue,ie)}),b(Ee,De)};D(de,Ee=>{o(y),x(()=>o(y).tags&&o(y).tags.length>0)&&Ee(He)})}var J=m(de,2);{var be=Ee=>{var De=yg(),Ue=d(De),Ye=d(Ue),ie=m(Ue,2);We(ie,5,()=>(o(y),x(()=>o(y).source_episodes)),Ge,(oe,_e)=>{var ot=mg(),se=d(ot),Se=d(se),dt=m(se,2),Pt=d(dt);L(()=>{Mn(se,`background: ${o(_e),x(()=>N[o(_e).type]||"#71717a")??""}`),M(Se,(o(_e),x(()=>o(_e).type))),M(Pt,(o(_e),x(()=>o(_e).title||o(_e).content)))}),b(oe,ot)}),L(()=>M(Ye,`Source Episodes (${o(y),x(()=>o(y).source_episodes.length)??""})`)),b(Ee,De)};D(J,Ee=>{o(y),x(()=>o(y).source_episodes&&o(y).source_episodes.length>0)&&Ee(be)})}L((Ee,De)=>{M($e,(o(y),x(()=>o(y).title||"Concept"))),M(ke,(o(y),x(()=>o(y).summary))),Mn(Me,`color: ${Ee??""}`),M(ne,`${De??""}% confidence`),M(Ze,`${o(y),x(()=>o(y).instance_count)??""} instances`)},[()=>(o(y),x(()=>O({confidence:o(y).confidence,nodeType:"concept",name:""}))),()=>(o(y),x(()=>Math.round(o(y).confidence*100)))]),b(V,Y)};D(K,V=>{o(y)&&V(ve)})}var vt=m(K,2);{var bt=V=>{var Y=Ng(),T=d(Y),X=d(T),$e=d(X),q=m(X,2);q.__click=Q;var he=m(T,2);{var ye=ee=>{var Me=wg();b(ee,Me)},ke=ee=>{var Me=ae(),ne=Z(Me);{var Oe=Ze=>{var B=zg(),U=d(B),pe=d(U),Fe=d(pe),de=m(pe,2),He=d(de),J=m(de,2);{var be=oe=>{var _e=$g();b(oe,_e)},Ee=oe=>{var _e=bg();b(oe,_e)};D(J,oe=>{o(p),x(()=>o(p).consolidated)?oe(be):oe(Ee,!1)})}var De=m(U,2),Ue=d(De),Ye=m(De,2);{var ie=oe=>{var _e=Eg(),ot=d(_e),se=d(ot),Se=m(ot,2);We(Se,5,()=>(o(p),x(()=>o(p).entity_ids)),Ge,(dt,Pt)=>{var fe=kg(),le=d(fe);L(()=>M(le,o(Pt))),b(dt,fe)}),L(()=>M(se,`Entities (${o(p),x(()=>o(p).entity_ids.length)??""})`)),b(oe,_e)};D(Ye,oe=>{o(p),x(()=>o(p).entity_ids&&o(p).entity_ids.length>0)&&oe(ie)})}L(oe=>{Mn(pe,`background: ${o(p),x(()=>N[o(p).episode_type]||"#71717a")??""}`),M(Fe,(o(p),x(()=>o(p).episode_type))),M(He,oe),M(Ue,(o(p),x(()=>o(p).content)))},[()=>(o(p),x(()=>j(o(p).timestamp)))]),b(Ze,B)};D(ne,Ze=>{o(p)&&Ze(Oe)},!0)}b(ee,Me)};D(he,ee=>{o(_)?ee(ye):ee(ke,!1)})}L(()=>M($e,(o(p),x(()=>{var ee;return((ee=o(p))==null?void 0:ee.title)||"Episode"})))),b(V,Y)},re=V=>{var Y=ae(),T=Z(Y);{var X=$e=>{var q=Mg();b($e,q)};D(T,$e=>{o(y)||$e(X)},!0)}b(V,Y)};D(vt,V=>{o(p)||o(_)?V(bt):V(re,!1)})}var ct=m(yt,2),pt=m(d(ct),2),Tt=m(d(pt),2);We(Tt,1,()=>x(()=>Object.entries(N)),Ge,(V,Y)=>{var T=Hi(()=>Vi(o(Y),2));let X=()=>o(T)[0],$e=()=>o(T)[1];var q=Ag(),he=d(q),ye=m(he,2),ke=d(ye);L(()=>{Mn(he,`background: ${$e()??""}`),M(ke,X())}),b(V,q)});var Gt=m(ct,2);{var jt=V=>{var Y=Sg(),T=d(Y),X=d(T),$e=m(T,2),q=d($e);L(()=>{Mn(Y,`left: ${o($),x(()=>o($).x)??""}px; top: ${o($),x(()=>o($).y)??""}px;`),M(X,(o($),x(()=>o($).title))),M(q,(o($),x(()=>o($).content)))}),b(V,Y)};D(Gt,V=>{o($),x(()=>o($).visible)&&V(jt)})}b(e,W),jn(),l()}Er(["click"]);var Pg=z('<div class="loading svelte-1smvsal">Loading graph...</div>'),Dg=z('<div class="error svelte-1smvsal"> </div>'),Lg=z('<div class="empty svelte-1smvsal"><!></div>'),Rg=z('<div class="loading svelte-1smvsal">Loading details...</div>'),Ig=z('<span class="relation-target svelte-1smvsal"><span class="target-icon svelte-1smvsal"></span> </span>'),Og=z('<span class="relation-strength svelte-1smvsal"> </span>'),Fg=z('<div class="relation svelte-1smvsal"><span class="relation-direction svelte-1smvsal"> </span> <span class="relation-type svelte-1smvsal"> </span> <!> <!></div>'),qg=z('<div class="section svelte-1smvsal"><h4 class="svelte-1smvsal"> </h4> <div class="relations svelte-1smvsal"></div></div>'),Bg=z('<div class="concept-title svelte-1smvsal"> </div>'),Vg=z('<div class="concept-item svelte-1smvsal"><!> <div class="concept-summary svelte-1smvsal"> </div> <span> </span></div>'),Hg=z('<div class="section svelte-1smvsal"><h4 class="svelte-1smvsal"> </h4> <div class="concepts-list svelte-1smvsal"></div></div>'),Ug=z('<span class="episode-status consolidated svelte-1smvsal">Consolidated</span>'),Yg=z('<span class="episode-status pending svelte-1smvsal">Pending</span>'),Xg=z('<span class="entity-tag svelte-1smvsal"> </span>'),jg=z('<div class="episode-entities svelte-1smvsal"></div>'),Gg=z('<div class="episode-full-content svelte-1smvsal"> </div> <!>',1),Wg=z('<div class="episode-preview svelte-1smvsal"> </div>'),Kg=z('<button><div class="episode-header svelte-1smvsal"><span class="expand-indicator svelte-1smvsal"><!></span> <span class="episode-type-icon svelte-1smvsal"><!></span> <span class="episode-date svelte-1smvsal"> </span> <!></div> <!></button>'),Zg=z('<div class="more-items svelte-1smvsal"> </div>'),Qg=z('<div class="section svelte-1smvsal"><h4 class="svelte-1smvsal"> </h4> <div class="episodes-list svelte-1smvsal"><!> <!></div></div>'),Jg=z("<!> <!> <!>",1),em=z('<div class="detail-panel svelte-1smvsal"><div class="detail-header svelte-1smvsal"><div class="entity-title svelte-1smvsal"><span class="entity-icon svelte-1smvsal"><!></span> <h3 class="svelte-1smvsal"> </h3></div> <button class="close-btn svelte-1smvsal">&times;</button></div> <div class="detail-content svelte-1smvsal"><div class="meta svelte-1smvsal"><span class="type-badge svelte-1smvsal"> </span> <span> </span></div> <div class="entity-id svelte-1smvsal"><span class="label svelte-1smvsal">ID:</span> <code class="svelte-1smvsal"> </code></div> <!></div></div>'),tm=z('<div class="detail-panel-placeholder svelte-1smvsal"></div>'),nm=z('<div class="legend-item svelte-1smvsal"><span class="legend-color svelte-1smvsal"></span> <span class="legend-label svelte-1smvsal"> </span></div>'),rm=z('<div class="tooltip svelte-1smvsal"><div class="tooltip-title svelte-1smvsal"> </div> <div class="tooltip-content svelte-1smvsal"> </div></div>'),im=z('<div class="entity-graph svelte-1smvsal"><div class="header svelte-1smvsal"><h2 class="svelte-1smvsal">Entity Network</h2> <div class="controls svelte-1smvsal"><select class="svelte-1smvsal"><option>All types</option><option>Files</option><option>Functions</option><option>Classes</option><option>Modules</option><option>Concepts</option><option>Subjects</option><option>People</option><option>Projects</option><option>Tools</option><option>Other</option></select> <button class="control-btn svelte-1smvsal" title="Zoom In"><!></button> <button class="control-btn svelte-1smvsal" title="Zoom Out"><!></button> <button class="control-btn svelte-1smvsal" title="Reset View"><!></button></div></div> <div class="content svelte-1smvsal"><div class="visualization svelte-1smvsal"><!></div> <!></div> <div class="legend svelte-1smvsal"></div> <!></div>');function sm(e,t){Xn(t,!1);const n=()=>at(el,"$entityGraphData",a),r=()=>at(or,"$currentDb",a),i=()=>at(xa,"$entityGraphLoading",a),s=()=>at(wa,"$entityGraphError",a),[a,l]=zr();let u=ze(),c=800,f=600,g=ze(!1),v=null,h=null,$=null,y=ze(""),p=ze({visible:!1,x:0,y:0,title:"",content:""}),_=ze(null),N=ze(null),P=ze([]),w=ze([]),E=ze({}),C=ze(!1);const F={file:"#3b82f6",function:"#8b5cf6",class:"#f59e0b",module:"#6366f1",concept:"#f97316",subject:"#14b8a6",person:"#22c55e",project:"#2563eb",tool:"#f43f5e",other:"#71717a"},O={file:Dc,function:Pc,class:Tc,module:Lc,concept:na,subject:Sc,person:Fc,project:Cc,tool:qc,other:ji};Kr(()=>{R(g,!0),ue();const B=new ResizeObserver(U=>{const pe=U[0];pe&&(c=pe.contentRect.width,f=pe.contentRect.height,n()&&G())});return B.observe(o(u)),()=>{B.disconnect(),v&&v.stop()}});async function ue(){if(r()){xa.set(!0),wa.set(null),R(_,null),R(N,null);try{const B=await yv();el.set(B),G()}catch(B){wa.set(B instanceof Error?B.message:"Failed to load data")}finally{xa.set(!1)}}}function G(){if(!n()||!o(u)||c===0||f===0)return;pn(o(u)).selectAll("svg").remove(),v&&v.stop();let B=[...n().nodes],U=[...n().links];if(o(y)){B=B.filter(be=>be.type===o(y));const J=new Set(B.map(be=>be.id));U=U.filter(be=>J.has(typeof be.source=="string"?be.source:be.source.id)&&J.has(typeof be.target=="string"?be.target:be.target.id))}if(B.length===0)return;h=pn(o(u)).append("svg").attr("width",c).attr("height",f),h.append("defs").append("marker").attr("id","arrowhead").attr("viewBox","-0 -5 10 10").attr("refX",20).attr("refY",0).attr("orient","auto").attr("markerWidth",6).attr("markerHeight",6).append("path").attr("d","M 0,-5 L 10,0 L 0,5").attr("fill","var(--color-text-muted)");const pe=h.append("g");$=mu().scaleExtent([.1,4]).on("zoom",J=>{pe.attr("transform",J.transform)}),h.call($),v=y0(B).force("link",f0(U).id(J=>J.id).distance(120)).force("charge",x0().strength(-400)).force("center",U1(c/2,f/2)).force("collision",c0().radius(40));const Fe=pe.append("g").attr("class","links").selectAll("line").data(U).join("line").attr("stroke","var(--color-border)").attr("stroke-width",J=>Math.max(1,J.strength*3)).attr("stroke-opacity",.6).attr("marker-end","url(#arrowhead)"),de=pe.append("g").attr("class","link-labels").selectAll("text").data(U).join("text").attr("font-size","9px").attr("fill","var(--color-text-muted)").attr("text-anchor","middle").attr("dy",-5).text(J=>J.type),He=pe.append("g").attr("class","nodes").selectAll("g").data(B).join("g").call(ge(v));He.append("circle").attr("r",J=>Math.min(25,12+Math.sqrt(J.mention_count)*2)).attr("fill",J=>F[J.type]).attr("fill-opacity",.85).attr("stroke","var(--color-surface)").attr("stroke-width",2).style("cursor","pointer").on("mouseover",Re).on("mouseout",k).on("click",I),He.append("text").attr("dy",J=>Math.min(25,12+Math.sqrt(J.mention_count)*2)+14).attr("text-anchor","middle").attr("font-size","10px").attr("fill","var(--color-text-secondary)").text(J=>Ve(J.display_name||J.id.split(":")[1]||J.id,12)),v.on("tick",()=>{Fe.attr("x1",J=>J.source.x).attr("y1",J=>J.source.y).attr("x2",J=>J.target.x).attr("y2",J=>J.target.y),de.attr("x",J=>(J.source.x+J.target.x)/2).attr("y",J=>(J.source.y+J.target.y)/2),He.attr("transform",J=>`translate(${J.x},${J.y})`)})}function ge(B){function U(de){de.active||B.alphaTarget(.3).restart(),de.subject.fx=de.subject.x,de.subject.fy=de.subject.y}function pe(de){de.subject.fx=de.x,de.subject.fy=de.y}function Fe(de){de.active||B.alphaTarget(0),de.subject.fx=null,de.subject.fy=null}return r_().on("start",U).on("drag",pe).on("end",Fe)}function Ve(B,U){return B.length>U?B.substring(0,U)+"...":B}function Re(B,U){R(p,{visible:!0,x:B.pageX+10,y:B.pageY+10,title:U.display_name||U.id,content:`Type: ${U.type}
Mentions: ${U.mention_count}`})}function k(){R(p,{...o(p),visible:!1})}async function I(B,U){R(_,U),R(C,!0),R(P,[]),R(w,[]),R(E,{});try{const[pe,Fe,de]=await Promise.all([Nc(U.id),Mc(U.id),Ac(U.id)]);R(N,pe),R(P,Fe.episodes),R(w,de.concepts)}catch(pe){console.error("Failed to fetch entity detail:",pe),R(N,null)}finally{R(C,!1)}}function A(){G()}function H(){h&&$&&h.transition().duration(300).call($.scaleBy,1.3)}function Q(){h&&$&&h.transition().duration(300).call($.scaleBy,.7)}function j(){h&&$&&h.transition().duration(300).call($.transform,oa)}function W(){R(_,null),R(N,null),R(P,[]),R(w,[]),R(E,{})}const me={observation:ea,decision:ra,question:ji,meta:Js,preference:ta};async function Ce(B){if(o(E)[B])R(E,{...o(E),[B]:null});else try{const U=await Qs(B);R(E,{...o(E),[B]:U})}catch(U){console.error("Failed to fetch episode:",U)}}function it(B){return new Date(B).toLocaleDateString("en-US",{month:"short",day:"numeric",year:"numeric"})}function Ie(B){return B>=.7?"high":B>=.4?"medium":"low"}function Pe(B){return`${Math.round(B*100)}%`}Un(()=>(o(g),r()),()=>{o(g)&&r()&&ue()}),Gr(),ar();var lt=im(),ut=d(lt),gt=m(d(ut),2),yt=d(gt);L(()=>{o(y),Cs(()=>{})}),yt.__change=A;var we=d(yt);we.value=we.__value="";var $t=m(we);$t.value=$t.__value="file";var Dt=m($t);Dt.value=Dt.__value="function";var It=m(Dt);It.value=It.__value="class";var K=m(It);K.value=K.__value="module";var ve=m(K);ve.value=ve.__value="concept";var vt=m(ve);vt.value=vt.__value="subject";var bt=m(vt);bt.value=bt.__value="person";var re=m(bt);re.value=re.__value="project";var ct=m(re);ct.value=ct.__value="tool";var pt=m(ct);pt.value=pt.__value="other";var Tt=m(yt,2);Tt.__click=H;var Gt=d(Tt);Vc(Gt,{size:18});var jt=m(Tt,2);jt.__click=Q;var V=d(jt);Hc(V,{size:18});var Y=m(jt,2);Y.__click=j;var T=d(Y);Oc(T,{size:18});var X=m(ut,2),$e=d(X),q=d($e);{var he=B=>{var U=Pg();b(B,U)},ye=B=>{var U=ae(),pe=Z(U);{var Fe=He=>{var J=Dg(),be=d(J);L(()=>M(be,s())),b(He,J)},de=He=>{var J=ae(),be=Z(J);{var Ee=De=>{var Ue=Lg(),Ye=d(Ue);{var ie=_e=>{var ot=Oo();L(()=>M(ot,`No ${o(y)??""} entities with relationships found.`)),b(_e,ot)},oe=_e=>{var ot=Oo("No entity relationships to display. Extract entities with relationships first.");b(_e,ot)};D(Ye,_e=>{o(y)?_e(ie):_e(oe,!1)})}b(De,Ue)};D(be,De=>{n(),x(()=>!n()||n().nodes.length===0)&&De(Ee)},!0)}b(He,J)};D(pe,He=>{s()?He(Fe):He(de,!1)},!0)}b(B,U)};D(q,B=>{i()?B(he):B(ye,!1)})}uo($e,B=>R(u,B),()=>o(u));var ke=m($e,2);{var ee=B=>{var U=em(),pe=d(U),Fe=d(pe),de=d(Fe),He=d(de);Bn(He,()=>O[o(_).type],(le,te)=>{te(le,{size:16})});var J=m(de,2),be=d(J),Ee=m(Fe,2);Ee.__click=W;var De=m(pe,2),Ue=d(De),Ye=d(Ue),ie=d(Ye),oe=m(Ye,2),_e=d(oe),ot=m(Ue,2),se=m(d(ot),2),Se=d(se),dt=m(ot,2);{var Pt=le=>{var te=Rg();b(le,te)},fe=le=>{var te=Jg(),_t=Z(te);{var zt=ce=>{var Je=qg(),Nt=d(Je),Wt=d(Nt),Ot=m(Nt,2);We(Ot,5,()=>(o(N),x(()=>o(N).relations)),Ge,(rn,qe)=>{var Kt=Fg(),Be=d(Kt),Te=d(Be),Et=m(Be,2),sn=d(Et),an=m(Et,2);{var Zt=Ft=>{var mt=Ig(),Xe=d(mt),Mt=m(Xe);L(()=>{Mn(Xe,`background: ${o(qe),x(()=>F[o(qe).related_entity.type])??""}`),M(Mt,` ${o(qe),x(()=>o(qe).related_entity.display_name||o(qe).related_entity.id)??""}`)}),b(Ft,mt)};D(an,Ft=>{o(qe),x(()=>o(qe).related_entity)&&Ft(Zt)})}var Qt=m(an,2);{var on=Ft=>{var mt=Og(),Xe=d(mt);L(Mt=>M(Xe,`${Mt??""}%`),[()=>(o(qe),x(()=>Math.round(o(qe).strength*100)))]),b(Ft,mt)};D(Qt,Ft=>{o(qe),x(()=>o(qe).strength)&&Ft(on)})}L(()=>{M(Te,(o(qe),x(()=>o(qe).direction==="outgoing"?"→":"←"))),M(sn,(o(qe),x(()=>o(qe).relation_type)))}),b(rn,Kt)}),L(()=>M(Wt,`Related Entities (${o(N),x(()=>o(N).relations.length)??""})`)),b(ce,Je)};D(_t,ce=>{o(N),x(()=>{var Je;return((Je=o(N))==null?void 0:Je.relations)&&o(N).relations.length>0})&&ce(zt)})}var kt=m(_t,2);{var xe=ce=>{var Je=Hg(),Nt=d(Je),Wt=d(Nt),Ot=m(Nt,2);We(Ot,5,()=>o(w),Ge,(rn,qe)=>{var Kt=Vg(),Be=d(Kt);{var Te=Qt=>{var on=Bg(),Ft=d(on);L(()=>M(Ft,(o(qe),x(()=>o(qe).title)))),b(Qt,on)};D(Be,Qt=>{o(qe),x(()=>o(qe).title)&&Qt(Te)})}var Et=m(Be,2),sn=d(Et),an=m(Et,2),Zt=d(an);L((Qt,on)=>{M(sn,(o(qe),x(()=>o(qe).summary))),xt(an,1,`confidence ${Qt??""}`,"svelte-1smvsal"),M(Zt,`${on??""} confidence`)},[()=>(o(qe),x(()=>Ie(o(qe).confidence))),()=>(o(qe),x(()=>Pe(o(qe).confidence)))]),b(rn,Kt)}),L(()=>M(Wt,`Related Concepts (${o(w),x(()=>o(w).length)??""})`)),b(ce,Je)};D(kt,ce=>{o(w),x(()=>o(w).length>0)&&ce(xe)})}var Lt=m(kt,2);{var ft=ce=>{var Je=Qg(),Nt=d(Je),Wt=d(Nt),Ot=m(Nt,2),rn=d(Ot);We(rn,1,()=>(o(P),x(()=>o(P).slice(0,20))),Ge,(Be,Te)=>{var Et=Kg();let sn;Et.__click=()=>Ce(o(Te).id);var an=d(Et),Zt=d(an),Qt=d(Zt);{var on=st=>{vo(st,{size:14})},Ft=st=>{ho(st,{size:14})};D(Qt,st=>{o(E),o(Te),x(()=>o(E)[o(Te).id])?st(on):st(Ft,!1)})}var mt=m(Zt,2),Xe=d(mt);Bn(Xe,()=>me[o(Te).episode_type],(st,Le)=>{Le(st,{size:14})});var Mt=m(mt,2),lr=d(Mt),cr=m(Mt,2);{var Zr=st=>{var Le=Ug();b(st,Le)},bi=st=>{var Le=Yg();b(st,Le)};D(cr,st=>{o(Te),x(()=>o(Te).consolidated)?st(Zr):st(bi,!1)})}var Qr=m(an,2);{var ki=st=>{const Le=ss(()=>(o(E),o(Te),x(()=>o(E)[o(Te).id])));var qt=Gg(),mn=Z(qt),ur=d(mn),Jr=m(mn,2);{var la=ei=>{var zi=jg();We(zi,5,()=>(St(o(Le)),x(()=>o(Le).entity_ids)),Ge,(yu,xu)=>{var No=Xg(),wu=d(No);L(()=>M(wu,o(xu))),b(yu,No)}),b(ei,zi)};D(Jr,ei=>{St(o(Le)),x(()=>{var zi;return((zi=o(Le))==null?void 0:zi.entity_ids)&&o(Le).entity_ids.length>0})&&ei(la)})}L(()=>M(ur,(St(o(Le)),x(()=>{var ei;return(ei=o(Le))==null?void 0:ei.content})))),b(st,qt)},Ei=st=>{var Le=Wg(),qt=d(Le);L(mn=>M(qt,`${mn??""}${o(Te),x(()=>o(Te).content.length>150?"...":"")??""}`),[()=>(o(Te),x(()=>o(Te).content.slice(0,150)))]),b(st,Le)};D(Qr,st=>{o(E),o(Te),x(()=>o(E)[o(Te).id])?st(ki):st(Ei,!1)})}L(st=>{sn=xt(Et,1,"episode-item expandable svelte-1smvsal",null,sn,{expanded:o(E)[o(Te).id]}),M(lr,st)},[()=>(o(Te),x(()=>it(o(Te).timestamp)))]),b(Be,Et)});var qe=m(rn,2);{var Kt=Be=>{var Te=Zg(),Et=d(Te);L(()=>M(Et,`+${o(P),x(()=>o(P).length-20)??""} more episodes`)),b(Be,Te)};D(qe,Be=>{o(P),x(()=>o(P).length>20)&&Be(Kt)})}L(()=>M(Wt,`Mentioning Episodes (${o(P),x(()=>o(P).length)??""})`)),b(ce,Je)};D(Lt,ce=>{o(P),x(()=>o(P).length>0)&&ce(ft)})}b(le,te)};D(dt,le=>{o(C)?le(Pt):le(fe,!1)})}L(()=>{Mn(de,`background: ${o(_),x(()=>F[o(_).type])??""}`),M(be,(o(_),x(()=>o(_).display_name||o(_).id))),Mn(Ye,`background: ${o(_),x(()=>F[o(_).type])??""}`),M(ie,(o(_),x(()=>o(_).type))),M(_e,`${o(_),x(()=>o(_).mention_count)??""} mentions`),M(Se,(o(_),x(()=>o(_).id)))}),b(B,U)},Me=B=>{var U=tm();b(B,U)};D(ke,B=>{o(_)?B(ee):B(Me,!1)})}var ne=m(X,2);We(ne,5,()=>x(()=>Object.entries(F)),Ge,(B,U)=>{var pe=Hi(()=>Vi(o(U),2));let Fe=()=>o(pe)[0],de=()=>o(pe)[1];var He=nm(),J=d(He),be=m(J,2),Ee=d(be);L(()=>{Mn(J,`background: ${de()??""}`),M(Ee,Fe())}),b(B,He)});var Oe=m(ne,2);{var Ze=B=>{var U=rm(),pe=d(U),Fe=d(pe),de=m(pe,2),He=d(de);L(()=>{Mn(U,`left: ${o(p),x(()=>o(p).x)??""}px; top: ${o(p),x(()=>o(p).y)??""}px;`),M(Fe,(o(p),x(()=>o(p).title))),M(He,(o(p),x(()=>o(p).content)))}),b(B,U)};D(Oe,B=>{o(p),x(()=>o(p).visible)&&B(Ze)})}Ls(yt,()=>o(y),B=>R(y,B)),b(e,lt),jn(),l()}Er(["change","click"]);var am=z("<option> </option>"),om=z('<select class="db-select svelte-73ak3c"><option>Select database...</option><!></select>');function lm(e,t){Xn(t,!1);const n=()=>at(or,"$currentDb",i),r=()=>at(kc,"$databases",i),[i,s]=zr();function a(g){const h=g.target.value;if(h!==n()){const $=new URL(window.location.href);$.searchParams.set("db",h),window.location.href=$.toString()}}ar();var l=om();l.__change=a;var u=d(l);u.value=u.__value="";var c=m(u);We(c,1,r,Ge,(g,v)=>{var h=am(),$=d(h),y={};L(()=>{M($,o(v).name),y!==(y=o(v).name)&&(h.value=(h.__value=o(v).name)??"")}),b(g,h)});var f;lo(l),L(()=>{f!==(f=n())&&(l.value=(l.__value=n())??"",Xi(l,n()))}),b(e,l),jn(),s()}Er(["change"]);var cm=z('<button><span class="nav-icon svelte-1n46o8q"><!></span> <span class="nav-label svelte-1n46o8q"> </span></button>'),um=z('<nav class="nav svelte-1n46o8q"></nav> <div class="sidebar-footer svelte-1n46o8q"><button class="nav-item theme-toggle svelte-1n46o8q"><span class="nav-icon svelte-1n46o8q"><!></span> <span class="nav-label svelte-1n46o8q"> </span></button></div>',1),fm=z('<div class="loading svelte-1n46o8q">Loading...</div>'),vm=z('<div class="no-db svelte-1n46o8q"><h2 class="svelte-1n46o8q">Select a Database</h2> <p>Choose a database from the dropdown above to explore your memories.</p></div>'),dm=z('<div class="app svelte-1n46o8q"><aside class="sidebar svelte-1n46o8q"><div class="sidebar-header glass svelte-1n46o8q"><h1 class="logo svelte-1n46o8q">Remind</h1> <!></div> <!></aside> <main class="main svelte-1n46o8q"><!></main></div>');function hm(e,t){Xn(t,!1);const n=()=>at(Li,"$theme",s),r=()=>at(dv,"$hasDatabase",s),i=()=>at(Qo,"$currentView",s),[s,a]=zr();let l=ze(!1);Kr(async()=>{const E=zc();or.set(E);try{const O=await xv();kc.set(O)}catch(O){console.error("Failed to fetch databases:",O)}R(l,!0);const C=window.matchMedia("(prefers-color-scheme: dark)"),F=O=>{n()==="system"&&document.documentElement.setAttribute("data-theme",O.matches?"dark":"light")};return C.addEventListener("change",F),()=>C.removeEventListener("change",F)});const u=[{view:"dashboard",label:"Dashboard",icon:zv},{view:"episodes",label:"Episodes",icon:Rc},{view:"entities",label:"Entities",icon:_o},{view:"concepts",label:"Concepts",icon:na},{view:"concept-map",label:"Concept Map",icon:kv},{view:"entity-graph",label:"Entity Graph",icon:Ic}];function c(){n()==="light"?Li.set("dark"):n()==="dark"?Li.set("system"):Li.set("light")}function f(E){return E==="light"?Av:E==="dark"?Mv:Nv}Un(()=>n(),()=>{if(typeof document<"u"){const E=n(),C=document.documentElement;if(E==="system"){const F=window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light";C.setAttribute("data-theme",F)}else C.setAttribute("data-theme",E)}}),Gr(),ar();var g=dm(),v=d(g),h=d(v),$=m(d(h),2);lm($,{});var y=m(h,2);{var p=E=>{var C=um(),F=Z(C);We(F,5,()=>u,Ge,(k,I)=>{var A=cm();let H;A.__click=()=>Qo.set(o(I).view);var Q=d(A),j=d(Q);Bn(j,()=>o(I).icon,(Ce,it)=>{it(Ce,{size:18})});var W=m(Q,2),me=d(W);L(()=>{H=xt(A,1,"nav-item svelte-1n46o8q",null,H,{active:i()===o(I).view}),M(me,(o(I),x(()=>o(I).label)))}),b(k,A)});var O=m(F,2),ue=d(O);ue.__click=c;var G=d(ue),ge=d(G);Bn(ge,()=>f(n()),(k,I)=>{I(k,{size:18})});var Ve=m(G,2),Re=d(Ve);L(()=>{qa(ue,"title",`Toggle theme (${n()??""})`),M(Re,`Theme: ${n()??""}`)}),b(E,C)};D(y,E=>{r()&&E(p)})}var _=m(v,2),N=d(_);{var P=E=>{var C=fm();b(E,C)},w=E=>{var C=ae(),F=Z(C);{var O=G=>{var ge=vm();b(G,ge)},ue=G=>{var ge=ae(),Ve=Z(ge);{var Re=I=>{qv(I,{})},k=I=>{var A=ae(),H=Z(A);{var Q=W=>{$d(W,{})},j=W=>{var me=ae(),Ce=Z(me);{var it=Pe=>{hh(Pe,{})},Ie=Pe=>{var lt=ae(),ut=Z(lt);{var gt=we=>{nh(we,{})},yt=we=>{var $t=ae(),Dt=Z($t);{var It=ve=>{Cg(ve,{})},K=ve=>{var vt=ae(),bt=Z(vt);{var re=ct=>{sm(ct,{})};D(bt,ct=>{i()==="entity-graph"&&ct(re)},!0)}b(ve,vt)};D(Dt,ve=>{i()==="concept-map"?ve(It):ve(K,!1)},!0)}b(we,$t)};D(ut,we=>{i()==="concepts"?we(gt):we(yt,!1)},!0)}b(Pe,lt)};D(Ce,Pe=>{i()==="episodes"?Pe(it):Pe(Ie,!1)},!0)}b(W,me)};D(H,W=>{i()==="entities"?W(Q):W(j,!1)},!0)}b(I,A)};D(Ve,I=>{i()==="dashboard"?I(Re):I(k,!1)})}b(G,ge)};D(F,G=>{r()?G(ue,!1):G(O)},!0)}b(E,C)};D(N,E=>{o(l)?E(w,!1):E(P)})}b(e,g),jn(),a()}Er(["click"]);Yf(hm,{target:document.getElementById("app")});
