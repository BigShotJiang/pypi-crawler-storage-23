"""REST API for Remind web UI."""

from remind.api.routes import api_routes

__all__ = ["api_routes"]
