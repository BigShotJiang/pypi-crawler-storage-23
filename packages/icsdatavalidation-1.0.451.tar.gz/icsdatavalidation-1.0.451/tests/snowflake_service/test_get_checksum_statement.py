from unittest.mock import MagicMock

import pytest

from icsDataValidation.core.database_objects import DatabaseObject, DatabaseObjectType
from icsDataValidation.services.database_services.snowflake_service import SnowflakeService


@pytest.fixture
def snowflake_service():
    """Create a SnowflakeService instance with mocked connection."""
    mock_params = MagicMock()
    service = SnowflakeService(mock_params)
    service.snowflake_connection = MagicMock()
    return service


@pytest.fixture
def mock_database_object():
    """Create a mock DatabaseObject."""
    return DatabaseObject(
        object_identifier="TestDB.dbo.TestTable",
        object_type=DatabaseObjectType.TABLE
    )


class TestGetChecksumStatementParametrized:
    """Parametrized tests for _get_checksum_statement method."""

    @pytest.mark.parametrize(
        "columns,datatype,exclude_columns,where_clause,numeric_scale," \
        "enclose_quotes,bool_cast_before_sum,expected_contains,expected_not_in",
        [
            ( # numeric with scale, no quotes, no cast before sum
                ["Amount"],
                [{"COLUMN_NAME": "Amount", "DATA_TYPE": "number"}],
                [],
                "",
                2,
                False,
                False,
                ["CAST(ROUND(SUM(Amount), 2) AS DECIMAL(38, 2))", 'AS "SUM_Amount"', "FROM TestDB.dbo.TestTable"],
                []
            ),
            ( # numeric with scale, with quotes
                ["Amount"],
                [{"COLUMN_NAME": "Amount", "DATA_TYPE": "number"}],
                [],
                "",
                2,
                True,
                False,
                ['CAST(ROUND(SUM("Amount"), 2) AS DECIMAL(38, 2))', 'AS "SUM_Amount"', "FROM TestDB.dbo.TestTable"],
                []
            ),
            ( # numeric without scale, no quotes
                ["AMOUNT"],
                [{"COLUMN_NAME": "AMOUNT", "DATA_TYPE": "number"}],
                [],
                "",
                None,
                False,
                False,
                ["CAST(SUM(AMOUNT) AS DECIMAL(38))", 'AS "SUM_AMOUNT"'],
                ["DECIMAL(38,"]
            ),
            ( # string column, no quotes
                ["NAME"],
                [{"COLUMN_NAME": "NAME", "DATA_TYPE": "text"}],
                [],
                "",
                None,
                False,
                False,
                ["COUNT(DISTINCT LOWER(NAME))", 'AS "COUNTDISTINCT_NAME"'],
                []
            ),
            ( # string column with special char, with quotes
                ["NAME/"],
                [{"COLUMN_NAME": "NAME/", "DATA_TYPE": "text"}],
                [],
                "",
                None,
                True,
                False,
                ['COUNT(DISTINCT LOWER("NAME/"))', 'AS "COUNTDISTINCT_NAME/"'],
                []
            ),
            ( # boolean column, no quotes
                ["IsActive"],
                [{"COLUMN_NAME": "IsActive", "DATA_TYPE": "boolean"}],
                [],
                "",
                None,
                False,
                False,
                ["COUNT(CASE WHEN IsActive = 1", "COUNT(CASE WHEN IsActive = 0", 'AS "AGGREGATEBOOLEAN_IsActive"'],
                []
            ),
            ( # boolean column, with quotes
                ["IsActive"],
                [{"COLUMN_NAME": "IsActive", "DATA_TYPE": "boolean"}],
                [],
                "",
                None,
                True,
                False,
                ['COUNT(CASE WHEN "IsActive" = 1', 'COUNT(CASE WHEN "IsActive" = 0', 'AS "AGGREGATEBOOLEAN_IsActive"'],
                []
            ),
            ( # binary column
                ["BINARYDATA"],
                [{"COLUMN_NAME": "BINARYDATA", "DATA_TYPE": "binary"}],
                [],
                "",
                None,
                False,
                False,
                ['TRY_CONVERT(VARCHAR,BINARYDATA)', "COUNT(DISTINCT LOWER("],
                []
            ),
            ( # with where clause
                ["Amount"],
                [{"COLUMN_NAME": "Amount", "DATA_TYPE": "number"}],
                [],
                "WHERE Amount > 100",
                None,
                False,
                False,
                ["SUM(Amount)", "WHERE Amount > 100"],
                []
            ),
            ( # excluded columns
                ["Amount"],
                [{"COLUMN_NAME": "Amount", "DATA_TYPE": "number"}],
                ["Price"],
                "",
                None,
                False,
                False,
                ["Amount"],
                ["Price"]
            ),
            ( # excluded columns with quotes
                ["Amount"],
                [{"COLUMN_NAME": "Amount", "DATA_TYPE": "number"}],
                ["Price"],
                "",
                None,
                True,
                False,
                ['"Amount"'],
                ['"Price"']
            ),
            ( # cast before sum, no quotes
                ["AMOUNT"],
                [{"COLUMN_NAME": "AMOUNT", "DATA_TYPE": "number"}],
                [],
                "",
                2,
                False,
                True,
                ["ROUND(SUM(CAST(AMOUNT AS DECIMAL(38, 2))), 2)", 'AS "SUM_AMOUNT"'],
                []
            ),
            ( # cast before sum, with quotes
                ["AMOUNT"],
                [{"COLUMN_NAME": "AMOUNT", "DATA_TYPE": "number"}],
                [],
                "",
                2,
                True,
                True,
                ['ROUND(SUM(CAST("AMOUNT" AS DECIMAL(38, 2))), 2)', 'AS "SUM_AMOUNT"'],
                []
            ),
            ( # multiple columns mixed types
                ["Amount", "Name/", "ISACTIVE"],
                [
                    {"COLUMN_NAME": "Amount", "DATA_TYPE": "number"},
                    {"COLUMN_NAME": "Name/", "DATA_TYPE": "text"},
                    {"COLUMN_NAME": "ISACTIVE", "DATA_TYPE": "boolean"}
                ],
                [],
                "",
                2,
                True,
                False,
                ['SUM("Amount")', 'COUNT(DISTINCT LOWER("Name/"))', '"AGGREGATEBOOLEAN_ISACTIVE"'],
                []
            ),
            ( # date column
                ["CreatedDate"],
                [{"COLUMN_NAME": "CreatedDate", "DATA_TYPE": "timestamp_ntz"}],
                [],
                "",
                None,
                False,
                False,
                ["COUNT(DISTINCT LOWER(CreatedDate))", 'AS "COUNTDISTINCT_CreatedDate"'],
                []
            ),
            ( # special characters with quotes
                ["/ISDFPS/OBJNR", "MANDT"],
                [
                    {"COLUMN_NAME": "/ISDFPS/OBJNR", "DATA_TYPE": "text"},
                    {"COLUMN_NAME": "MANDT", "DATA_TYPE": "number"}
                ],
                [],
                "",
                None,
                True,
                False,
                ['"/ISDFPS/OBJNR"', '"MANDT"', 'AS "COUNTDISTINCT_/ISDFPS/OBJNR"', 'AS "SUM_MANDT"'],
                []
            ),
        ],
    )
    def test_get_checksum_statement(
        self, snowflake_service, mock_database_object,
        columns, datatype, exclude_columns, where_clause,
        numeric_scale, enclose_quotes, bool_cast_before_sum,
        expected_contains, expected_not_in
    ):
        """Test checksum statement with various configurations."""
        snowflake_service.get_data_types_from_object = MagicMock(return_value=datatype)

        result = snowflake_service._get_checksum_statement(
            object=mock_database_object,
            column_intersections=columns,
            exclude_columns=exclude_columns,
            where_clause=where_clause,
            numeric_scale=numeric_scale,
            enclose_column_by_double_quotes=enclose_quotes,
            bool_cast_before_sum=bool_cast_before_sum
        )

        for expected in expected_contains:
            assert expected in result
        for expected in expected_not_in:
            assert expected not in result
        if where_clause:
            assert where_clause in result
