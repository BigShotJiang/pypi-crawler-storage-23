from unittest.mock import MagicMock

import pytest

from icsDataValidation.services.database_services.snowflake_service import SnowflakeService


@pytest.fixture
def snowflake_service():
    """Fixture for SnowflakeService with mocked connection."""
    mock_params = MagicMock()
    service = SnowflakeService(mock_params)
    return service

class TestGetColumnClauseParametrized:
    """Parametrized tests for _get_column_clause method."""

    @pytest.mark.parametrize(
        "column_list,columns_datatype,numeric_scale,key_columns," \
        "enclose_quotes,expected_clause,expected_numeric,expected_used",
        [
            # Numeric with scale
            (
                ['price'],
                [{"COLUMN_NAME": "price", "DATA_TYPE": "float"}],
                2,
                [],
                False,
                "CAST(ROUND(price, 2) as decimal(38,2)) as price",
                ['price'],
                ['price']
            ),
            # Numeric without scale
            (
                ['price'],
                [{"COLUMN_NAME": "price", "DATA_TYPE": "float"}],
                None,
                [],
                False,
                "price as price",
                ['price'],
                ['price']
            ),
            # String column
            (
                ['name'],
                [{"COLUMN_NAME": "name", "DATA_TYPE": "text"}],
                None,
                [],
                False,
                "name AS name",
                [],
                ['name']
            ),
            # Binary column
            (
                ['binary_data'],
                [{"COLUMN_NAME": "binary_data", "DATA_TYPE": "binary"}],
                None,
                [],
                False,
                "binary_data",
                [],
                ['binary_data']
            ),
            # Boolean column
            (
                ['is_active'],
                [{"COLUMN_NAME": "is_active", "DATA_TYPE": "boolean"}],
                None,
                [],
                False,
                "is_active",
                [],
                ['is_active']
            ),
            # String with double quotes
            (
                ['name'],
                [{"COLUMN_NAME": "name", "DATA_TYPE": "text"}],
                None,
                [],
                True,
                '"name" AS "name"',
                [],
                ['name']
            ),
            # Numeric with double quotes and scale
            (
                ['amount'],
                [{"COLUMN_NAME": "amount", "DATA_TYPE": "number"}],
                2,
                [],
                True,
                'CAST(ROUND("amount", 2) as decimal(38,2)) as "amount"',
                ['amount'],
                ['amount']
            ),
            # Column with spaces (special characters)
            (
                ['Column With Spaces'],
                [{"COLUMN_NAME": "Column With Spaces", "DATA_TYPE": "text"}],
                None,
                [],
                True,
                '"Column With Spaces" AS "Column With Spaces"',
                [],
                ['Column With Spaces']
            ),
            # High precision numeric
            (
                ['precise_value'],
                [{"COLUMN_NAME": "precise_value", "DATA_TYPE": "number"}],
                10,
                [],
                False,
                "CAST(ROUND(precise_value, 10) as decimal(38,10)) as precise_value",
                ['precise_value'],
                ['precise_value']
            ),
            # With zero scale
            (
                ['count'],
                [{"COLUMN_NAME": "count", "DATA_TYPE": "number"}],
                0,
                [],
                False,
                "count as count",
                ['count'],
                ['count']
            ),
            # empty column list
            (
                [],
                [],
                0,
                [],
                False,
                "",
                [],
                []
            ),
        ],
    )
    def test_single_column_variations(
        self, snowflake_service, column_list, columns_datatype, numeric_scale,
        key_columns, enclose_quotes, expected_clause, expected_numeric, expected_used
    ):
        """Test various single column scenarios."""
        column_clause, numeric_columns, used_columns = snowflake_service._get_column_clause(
            column_list, columns_datatype, numeric_scale, key_columns, enclose_quotes
        )

        assert expected_clause in column_clause
        assert numeric_columns == expected_numeric
        assert used_columns == expected_used

    @pytest.mark.parametrize(
        "column_list,columns_datatype,key_columns,expected_in_clause,expected_not_in_clause,expected_used_count",
        [
            # Date excluded by default
            (
                ['created_date'],
                [{"COLUMN_NAME": "created_date", "DATA_TYPE": "date"}],
                [],
                [],
                ['created_date'],
                0
            ),
            # Timestamp excluded by default
            (
                ['updated_at'],
                [{"COLUMN_NAME": "updated_at", "DATA_TYPE": "timestamp_ntz"}],
                [],
                [],
                ['updated_at'],
                0
            ),
            # Time excluded by default
            (
                ['event_time'],
                [{"COLUMN_NAME": "event_time", "DATA_TYPE": "time"}],
                [],
                [],
                ['event_time'],
                0
            ),
            # Date included as key column
            (
                ['created_date'],
                [{"COLUMN_NAME": "created_date", "DATA_TYPE": "date"}],
                ['created_date'],
                ['created_date'],
                [],
                1
            ),
            # All Snowflake datetime types excluded
            (
                ['col_date', 'col_time', 'col_ts_ntz', 'col_ts_tz', 'col_ts_ltz'],
                [
                    {"COLUMN_NAME": "col_date", "DATA_TYPE": "date"},
                    {"COLUMN_NAME": "col_time", "DATA_TYPE": "time"},
                    {"COLUMN_NAME": "col_ts_ntz", "DATA_TYPE": "timestamp_ntz"},
                    {"COLUMN_NAME": "col_ts_tz", "DATA_TYPE": "timestamp_tz"},
                    {"COLUMN_NAME": "col_ts_ltz", "DATA_TYPE": "timestamp_ltz"}
                ],
                [],
                [],
                ['col_date', 'col_time', 'col_ts_ntz', 'col_ts_tz', 'col_ts_ltz'],
                0
            ),
            # All datetime types included as key columns
            (
                ['col_date', 'col_time', 'col_ts_ntz', 'col_ts_tz', 'col_ts_ltz'],
                [
                    {"COLUMN_NAME": "col_date", "DATA_TYPE": "date"},
                    {"COLUMN_NAME": "col_time", "DATA_TYPE": "time"},
                    {"COLUMN_NAME": "col_ts_ntz", "DATA_TYPE": "timestamp_ntz"},
                    {"COLUMN_NAME": "col_ts_tz", "DATA_TYPE": "timestamp_tz"},
                    {"COLUMN_NAME": "col_ts_ltz", "DATA_TYPE": "timestamp_ltz"}
                ],
                ['col_date', 'col_time', 'col_ts_ntz', 'col_ts_tz', 'col_ts_ltz'],
                ['col_date', 'col_time', 'col_ts_ntz', 'col_ts_tz', 'col_ts_ltz'],
                [],
                5
            ),
        ],
    )
    def test_date_time_column_handling(
        self, snowflake_service, column_list, columns_datatype, key_columns,
        expected_in_clause, expected_not_in_clause, expected_used_count
    ):
        """Test date/time column inclusion/exclusion logic."""
        column_clause, numeric_columns, used_columns = snowflake_service._get_column_clause(
            column_list, columns_datatype, None, key_columns
        )

        for col in expected_in_clause:
            assert col in column_clause
        for col in expected_not_in_clause:
            assert col not in column_clause
        assert len(used_columns) == expected_used_count

    @pytest.mark.parametrize(
        "column_list,columns_datatype,numeric_scale,expected_contains",
        [
            # Multiple mixed types
            (
                ['id', 'name', 'amount'],
                [
                    {"COLUMN_NAME": "id", "DATA_TYPE": "number"},
                    {"COLUMN_NAME": "name", "DATA_TYPE": "text"},
                    {"COLUMN_NAME": "amount", "DATA_TYPE": "float"}
                ],
                2,
                ["CAST(ROUND(id, 2) as decimal(38,2)) as id", "name AS name", "CAST(ROUND(amount, 2) as decimal(38,2)) as amount"]
            ),
            # Multiple dates with one key column
            (
                ['created_date', 'updated_date', 'deleted_date'],
                [
                    {"COLUMN_NAME": "created_date", "DATA_TYPE": "date"},
                    {"COLUMN_NAME": "updated_date", "DATA_TYPE": "timestamp_ltz"},
                    {"COLUMN_NAME": "deleted_date", "DATA_TYPE": "timestamp_tz"}
                ],
                None,
                ["created_date"]
            ),
        ],
    )
    def test_multiple_columns_complex(
        self, snowflake_service, column_list, columns_datatype, numeric_scale, expected_contains
    ):
        """Test complex scenarios with multiple columns."""
        # For the dates test, only created_date is a key column
        key_columns = ['created_date'] if 'created_date' in column_list else []

        column_clause, numeric_columns, used_columns = snowflake_service._get_column_clause(
            column_list, columns_datatype, numeric_scale, key_columns
        )

        for expected in expected_contains:
            assert expected in column_clause

    def test_mixed_columns_with_date_excluded_and_key_included(self, snowflake_service):
        """Test mixed scenario with some date columns excluded and others included as key."""
        column_list = ['id', 'created_date', 'amount', 'updated_date']
        columns_datatype = [
            {"COLUMN_NAME": "id", "DATA_TYPE": "number"},
            {"COLUMN_NAME": "created_date", "DATA_TYPE": "date"},
            {"COLUMN_NAME": "amount", "DATA_TYPE": "float"},
            {"COLUMN_NAME": "updated_date", "DATA_TYPE": "timestamp_ntz"}
        ]
        key_columns = ['id', 'created_date']

        column_clause, numeric_columns, used_columns = snowflake_service._get_column_clause(
            column_list, columns_datatype, 2, key_columns
        )

        assert "CAST(ROUND(id, 2) as decimal(38,2)) as id" in column_clause
        assert "created_date" in column_clause
        assert "CAST(ROUND(amount, 2) as decimal(38,2)) as amount" in column_clause
        assert "updated_date" not in column_clause
        assert numeric_columns == ['id', 'amount']
        assert used_columns == ['id', 'created_date', 'amount']
