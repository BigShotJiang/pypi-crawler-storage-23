from unittest.mock import MagicMock

import pytest

from icsDataValidation.core.database_objects import DatabaseObject, DatabaseObjectType
from icsDataValidation.services.database_services.snowflake_service import SnowflakeService


@pytest.fixture
def snowflake_service():
    """Create a SnowflakeService instance with mocked connection."""
    mock_params = MagicMock()
    service = SnowflakeService(mock_params)
    service.snowflake_connection = MagicMock()
    return service


@pytest.fixture
def mock_database_object():
    """Create a mock DatabaseObject."""
    return DatabaseObject(
        object_identifier="TestDB.dbo.TestTable",
        object_type=DatabaseObjectType.TABLE
    )

class TestGetCountnullsStatementParametrized:
    """Parametrized tests for _get_countnulls_statement method."""

    @pytest.mark.parametrize(
        "columns,exclude_columns,where_clause," \
        "enclose_quotes,expected_contains,expected_not_in",
        [
         ( # no double quotes, with where clause, exclude one column
                ["Amount", "Name", "IsActive"],
                ["IsActive"],
                'Amount > 0',
                False,
                [
                    "SUM(CASE WHEN Amount IS NULL THEN 1 ELSE 0 END)",
                    'AS "COUNTNULLS_Amount"',
                    "SUM(CASE WHEN Name IS NULL THEN 1 ELSE 0 END)",
                    'AS "COUNTNULLS_Name"',

                ],
                ["SUM(CASE WHEN IsActive IS NULL THEN 1 ELSE 0 END)",
                 'AS "COUNTNULLS_IsActive"']
        ),
        ( # countnulls statement generation for a single column, non case-sensitive
                ["Amount"],
                [],
                "",
                False,
                [
                    "SUM(CASE WHEN Amount IS NULL THEN 1 ELSE 0 END)",
                    'AS "COUNTNULLS_Amount"',
                ],
                ['"Amount']
        ),
        ( # countnulls statement generation for a single column, non case-sensitive
                ["Amount"],
                [],
                "",
                True,
                [
                    "SUM(CASE WHEN \"Amount\" IS NULL THEN 1 ELSE 0 END)",
                    'AS "COUNTNULLS_Amount"',
                ],
                ['"AMOUNT']
        ),
        ( # countnulls single column, non case-sensitive, where clause
                ["Amount"],
                [],
                "WHERE Amount > 100",
                False,
                [
                    "SUM(CASE WHEN Amount IS NULL THEN 1 ELSE 0 END)",
                    'AS "COUNTNULLS_Amount"',
                    'WHERE Amount > 100'
                ],
                ['"Amount']
        ),
        (#  excluded columns
                ["AMOUNT", "PRICE", "QUANTITY"],
                ["PRICE"],
                "",
                False,
                [
                    "AMOUNT",
                    "QUANTITY"
                ],
                ['PRICE']
        ),
        (#  special characters and column enclosing
                ["/ISDFPS/OBJNR", "MANDT"],
                ["PRICE"],
                "",
                True,
                [
                    '"/ISDFPS/OBJNR"',
                    'AS "COUNTNULLS_/ISDFPS/OBJNR"',
                    '"MANDT"',
                    'AS "COUNTNULLS_MANDT"'
                ],
                ['PRICE']
        )
        ]
    )
    def test_get_countnulls_statement(
        self, snowflake_service, mock_database_object,
        columns, exclude_columns, where_clause,
        enclose_quotes,
        expected_contains, expected_not_in
    ):
        """Test countnulls statement with special characters and double quotes."""
        result = snowflake_service._get_countnulls_statement(
            object=mock_database_object,
            column_intersections=columns,
            enclose_column_by_double_quotes=enclose_quotes,
            exclude_columns=exclude_columns,
            where_clause=where_clause
        )

        for expected in expected_contains:
            assert expected in result
        for expected in expected_not_in:
            assert expected not in result
        if where_clause is not None:
            assert where_clause in result
