from unittest.mock import MagicMock, patch

import pytest

from icsDataValidation.core.database_objects import DatabaseObject, DatabaseObjectType
from icsDataValidation.services.database_services.snowflake_service import SnowflakeService


@pytest.fixture
def snowflake_service():
    """Create a SnowflakeService instance with mocked connection."""
    mock_params = MagicMock()
    service = SnowflakeService(mock_params)
    service.snowflake_connection = MagicMock()
    return service


@pytest.fixture
def mock_database_object():
    """Create a mock DatabaseObject."""
    return DatabaseObject(
        object_identifier="TEST_DB.TEST_SCHEMA.TEST_TABLE",
        object_type=DatabaseObjectType.TABLE
    )


class TestCreateChecksumsParametrized:
    """Parametrized tests for SnowflakeService.create_checksums."""

    @pytest.mark.parametrize(
        "column_intersections,where_clause,numeric_scale,execute_behavior," \
        "expected_columns,expected_errors,expect_retry",
        [
            (  # success path
                ['amount', 'name'],
                'WHERE amount > 0',
                2,
                {
                    "return_value": [
                        [{'SUM_AMOUNT': 10, 'COUNTDISTINCT_NAME': 3}],
                        [{'COUNTNULLS_AMOUNT': 1, 'COUNTNULLS_NAME': 0}]
                    ]
                },
                {
                    'AMOUNT': ['SUM', 10, 1],
                    'NAME': ['COUNTDISTINCT', 3, 0]
                },
                [],
                False
            ),
            (  # arithmetic overflow triggers retry
                ['amount'],
                '',
                None,
                {
                    "side_effect": [
                        Exception('checksum_sql|||Arithmetic overflow error converting numeric to data type numeric'),
                        [[{'SUM_AMOUNT': 5}], [{'COUNTNULLS_AMOUNT': 0}]]
                    ]
                },
                {
                    'AMOUNT': ['SUM', 5, 0]
                },
                [],
                True
            ),
            (  # non-overflow error surfaces in TESTATM_ERRORS
                ['amount'],
                '',
                None,
                {
                    "side_effect": Exception('checksum_sql|||Some other error')
                },
                {},
                [['ERROR', 'checksum_sql', 'Some other error']],
                False
            ),
        ],
    )
    def test_create_checksums(
        self,
        snowflake_service,
        mock_database_object,
        column_intersections,
        where_clause,
        numeric_scale,
        execute_behavior,
        expected_columns,
        expected_errors,
        expect_retry
    ):
        """Test create_checksums behavior across success, retry, and error scenarios."""
        with patch.object(snowflake_service, '_get_checksum_statement', return_value='checksum_sql') as mock_checksum_stmt, \
             patch.object(snowflake_service, '_get_countnulls_statement', return_value='countnulls_sql') as mock_countnulls_stmt, \
             patch.object(snowflake_service, 'execute_queries') as mock_execute:

            side_effect = execute_behavior.get('side_effect')
            if side_effect is not None:
                mock_execute.side_effect = side_effect
                expected_call_count = len(side_effect) if isinstance(side_effect, list) else 1
            else:
                mock_execute.return_value = execute_behavior['return_value']
                expected_call_count = 1

            result = snowflake_service.create_checksums(
                object=mock_database_object,
                column_intersections=column_intersections,
                where_clause=where_clause,
                exclude_columns=[],
                numeric_scale=numeric_scale,
                enclose_column_by_double_quotes=False
            )

            checksum_calls = mock_checksum_stmt.call_args_list
            base_kwargs = {
                'object': mock_database_object,
                'column_intersections': column_intersections,
                'where_clause': where_clause,
                'exclude_columns': [],
                'numeric_scale': numeric_scale,
                'enclose_column_by_double_quotes': False
            }
            assert checksum_calls[0].kwargs == base_kwargs
            if expect_retry:
                assert len(checksum_calls) == 2
                retry_kwargs = {**base_kwargs, 'bool_cast_before_sum': True}
                assert checksum_calls[1].kwargs == retry_kwargs
            else:
                assert len(checksum_calls) == 1
            mock_countnulls_stmt.assert_called_once_with(
                object=mock_database_object,
                column_intersections=column_intersections,
                where_clause=where_clause,
                exclude_columns=[],
                enclose_column_by_double_quotes=False
            )
            assert mock_execute.call_count == expected_call_count

            for column, expected in expected_columns.items():
                assert result[column] == expected

            expected_keys = set(expected_columns.keys()) | {'TESTATM_ERRORS'}
            assert set(result.keys()) == expected_keys
            assert result['TESTATM_ERRORS'] == expected_errors
