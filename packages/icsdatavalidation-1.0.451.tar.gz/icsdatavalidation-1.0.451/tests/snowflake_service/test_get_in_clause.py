import pytest

from icsDataValidation.services.database_services.snowflake_service import SnowflakeService


class TestInClauseVariations:
    """Test various IN clause generation scenarios using parametrization."""

    @pytest.mark.parametrize(
        "key_filters,numeric_columns,numeric_scale,enclose_column_by_double_quotes," \
        "expected_contains",
        [
            ( # numeric column with rounding
                {"price": [10.5, 20.3], "quantity": [5, 10]},
                ["price"],
                2,
                False,
                ["ROUND(price, 2)", "quantity", "('10.5','5'),('20.3','10')"],
            ),
            ( # single row with non numeric columns
                {"col1": ["value1"], "col2": ["value2"]},
                [],
                None,
                False,
                [" AND ((col1,col2) in (('value1','value2')))", ]
            ),
            ( # multiple rows with tuples and numeric column rounding
                {"id": [1, 2, 3], "name": ["a", "b", "c"]},
                ["id"],
                2,
                False,
                [" AND ((ROUND(id, 2),name) in (('1','a'),('2','b'),('3','c')))", ],
            ),
            ( # columns with double quotes
                {"Col1": ["val1"], "Col2": ["val2"]},
                [],
                None,
                True,
                [' AND (("Col1","Col2")', "('val1','val2')"],
            ),
            ( # empty key_filters
                {},
                [],
                None,
                False,
                [''],
            ),
            ( # special characters in column names with double quotes and numeric rounding
                {"/ISDFPS/OBJNR": ['000000000012345678', '000000000012345679'], "MANDT": [100, 200]},
                ["MANDT"],
                3,
                True,
                ['ROUND("MANDT", 3)', '"/ISDFPS/OBJNR"', "('000000000012345678','100'),('000000000012345679','200')"],
            )
        ],
    )
    def test_in_clause_contains(
        self, key_filters, numeric_columns, numeric_scale, enclose_column_by_double_quotes, expected_contains
    ):
        """Test that result contains expected substrings."""
        result = SnowflakeService._get_in_clause(
            key_filters, numeric_columns, numeric_scale, enclose_column_by_double_quotes
        )

        for expected in expected_contains:
            assert expected in result
