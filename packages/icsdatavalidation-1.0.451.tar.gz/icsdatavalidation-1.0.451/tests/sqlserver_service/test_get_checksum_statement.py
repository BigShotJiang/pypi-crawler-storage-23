from unittest.mock import MagicMock, Mock

import pytest

from icsDataValidation.core.database_objects import DatabaseObject
from icsDataValidation.services.database_services.sqlserver_service import SQLServerService


@pytest.fixture
def sqlserver_service():
    """Create a SQLServerService instance with mocked connection."""
    connection_params = {
        'Driver': 'ODBC Driver 18 for SQL Server',
        'Server': 'localhost',
        'Port': '1433',
        'Database': 'testdb',
        'User': 'sa',
        'Password': 'password',
        'Encrypt': True,
        'TrustServerCertificate': True
    }
    service = SQLServerService(connection_params=connection_params)
    service.sqlserver_connection = MagicMock()
    return service


@pytest.fixture
def mock_database_object():
    """Create a mock DatabaseObject."""
    obj = Mock(spec=DatabaseObject)
    obj.database = "TestDB"
    obj.schema = "dbo"
    obj.name = "TestTable"
    obj.type = "table"
    return obj


class TestGetChecksumStatementParametrized:
    """Parametrized tests for _get_checksum_statement method."""

    @pytest.mark.parametrize(
        "columns,mock_datatypes,exclude_columns,where_clause,numeric_scale," \
        "expected_contains,expected_not_in",
        [
            ( # numeric column with scale
                ["Amount"],
                [{"COLUMN_NAME": "AMOUNT", "DATA_TYPE": "decimal"}],
                [],
                "",
                2,
                ["SUM([AMOUNT])", "DECIMAL(38, 2)", "AS [SUM_AMOUNT]", "FROM dbo.TestTable"],
                []
            ),
            ( # numeric column without scale
                ["Amount"],
                [{"COLUMN_NAME": "AMOUNT", "DATA_TYPE": "int"}],
                [],
                "",
                None,
                ["SUM([AMOUNT])", "AS [SUM_AMOUNT]"],
                ["DECIMAL(38,"]
            ),
            ( # string column
                ["Name"],
                [{"COLUMN_NAME": "NAME", "DATA_TYPE": "varchar"}],
                [],
                "",
                None,
                ["COUNT(DISTINCT LOWER([NAME]))", "AS [COUNTDISTINCT_NAME]"],
                []
            ),
            ( # boolean column
                ["IsActive"],
                [{"COLUMN_NAME": "ISACTIVE", "DATA_TYPE": "bit"}],
                [],
                "",
                None,
                ["COUNT(CASE WHEN [ISACTIVE] = 1", "COUNT(CASE WHEN [ISACTIVE] = 0", "AS [AGGREGATEBOOLEAN_ISACTIVE]"],
                []
            ),
            ( # with where clause
                ["Amount"],
                [{"COLUMN_NAME": "AMOUNT", "DATA_TYPE": "int"}],
                [],
                "WHERE Amount > 100",
                None,
                ["WHERE Amount > 100"],
                []
            ),
            ( # exclude columns
                ["Amount", "Price"],
                [{"COLUMN_NAME": "AMOUNT", "DATA_TYPE": "int"}],
                ["Price"],
                "",
                None,
                ["AMOUNT"],
                ["PRICE"]
            ),
            ( # multiple columns mixed types
                ["Amount", "Name", "IsActive"],
                [
                    {"COLUMN_NAME": "AMOUNT", "DATA_TYPE": "decimal"},
                    {"COLUMN_NAME": "NAME", "DATA_TYPE": "varchar"},
                    {"COLUMN_NAME": "ISACTIVE", "DATA_TYPE": "bit"}
                ],
                [],
                "",
                2,
                ["SUM([AMOUNT])", "COUNT(DISTINCT LOWER([NAME]))", "AGGREGATEBOOLEAN_ISACTIVE"],
                []
            ),
            ( # binary column
                ["BinaryData"],
                [{"COLUMN_NAME": "BINARYDATA", "DATA_TYPE": "varbinary"}],
                [],
                "",
                None,
                ["TRY_CONVERT(VARCHAR,[BINARYDATA])", "COUNT(DISTINCT LOWER("],
                []
            ),
            ( # date column
                ["CreatedDate"],
                [{"COLUMN_NAME": "CREATEDDATE", "DATA_TYPE": "datetime"}],
                [],
                "",
                None,
                ["COUNT(DISTINCT LOWER([CREATEDDATE]))", "AS [COUNTDISTINCT_CREATEDDATE]"],
                []
            ),
            ( # special characters in column names
                ["/ISDFPS/OBJNR"],
                [{"COLUMN_NAME": "/ISDFPS/OBJNR", "DATA_TYPE": "varchar"}],
                [],
                "",
                None,
                ["[/ISDFPS/OBJNR]", "AS [COUNTDISTINCT_/ISDFPS/OBJNR]"],
                []
            ),
        ],
    )
    def test_get_checksum_statement(
        self, sqlserver_service, mock_database_object,
        columns, mock_datatypes, exclude_columns, where_clause, numeric_scale,
        expected_contains, expected_not_in
    ):
        """Test checksum statement with various configurations."""
        sqlserver_service.get_data_types_from_object = MagicMock(return_value=mock_datatypes)

        result = sqlserver_service._get_checksum_statement(
            object=mock_database_object,
            column_intersections=columns,
            exclude_columns=exclude_columns,
            where_clause=where_clause,
            numeric_scale=numeric_scale
        )

        for expected in expected_contains:
            assert expected in result
        for expected in expected_not_in:
            assert expected not in result
