from unittest.mock import MagicMock, Mock

import pytest

from icsDataValidation.core.database_objects import DatabaseObject
from icsDataValidation.services.database_services.sqlserver_service import SQLServerService


@pytest.fixture
def sqlserver_service():
    """Create a SQLServerService instance with mocked connection."""
    connection_params = {
        'Driver': 'ODBC Driver 18 for SQL Server',
        'Server': 'localhost',
        'Port': '1433',
        'Database': 'testdb',
        'User': 'sa',
        'Password': 'password',
        'Encrypt': True,
        'TrustServerCertificate': True
    }
    service = SQLServerService(connection_params=connection_params)
    service.sqlserver_connection = MagicMock()
    return service


@pytest.fixture
def mock_database_object():
    """Create a mock DatabaseObject."""
    obj = Mock(spec=DatabaseObject)
    obj.database = "TestDB"
    obj.schema = "dbo"
    obj.name = "TestTable"
    obj.type = "table"
    return obj


class TestGetCountnullsStatementParametrized:
    """Parametrized tests for _get_countnulls_statement method."""

    @pytest.mark.parametrize(
        "columns,exclude_columns,where_clause,expected_contains,expected_not_in",
        [
            ( # single column
                ["Amount"],
                [],
                "",
                ["SUM(CASE WHEN [AMOUNT] IS NULL THEN 1 ELSE 0 END)", "AS [COUNTNULLS_AMOUNT]", "FROM dbo.TestTable"],
                []
            ),
            ( # multiple columns
                ["Amount", "Name", "IsActive"],
                [],
                "",
                [
                    "SUM(CASE WHEN [AMOUNT] IS NULL THEN 1 ELSE 0 END)", "AS [COUNTNULLS_AMOUNT]",
                    "SUM(CASE WHEN [NAME] IS NULL THEN 1 ELSE 0 END)", "AS [COUNTNULLS_NAME]",
                    "SUM(CASE WHEN [ISACTIVE] IS NULL THEN 1 ELSE 0 END)", "AS [COUNTNULLS_ISACTIVE]"
                ],
                []
            ),
            ( # with where clause
                ["Amount"],
                [],
                "WHERE Amount > 100",
                ["SUM(CASE WHEN [AMOUNT] IS NULL THEN 1 ELSE 0 END)", "WHERE Amount > 100"],
                []
            ),
            ( # with exclude columns
                ["Amount", "Price", "Quantity"],
                ["Price"],
                "",
                ["AMOUNT", "QUANTITY"],
                ["PRICE"]
            ),
            ( # special characters in column names
                ["/ISDFPS/OBJNR", "MANDT"],
                [],
                "",
                ["[/ISDFPS/OBJNR]", "AS [COUNTNULLS_/ISDFPS/OBJNR]", "[MANDT]", "AS [COUNTNULLS_MANDT]"],
                []
            ),
            ( # empty columns
                [],
                [],
                "",
                ["SELECT", "FROM dbo.TestTable"],
                ["COUNTNULLS"]
            ),
            ( # all columns excluded
                ["Amount", "Price"],
                ["Amount", "Price"],
                "",
                ["SELECT", "FROM dbo.TestTable"],
                ["COUNTNULLS"]
            ),
            ( # case insensitive columns
                ["amount", "Name", "QUANTITY"],
                [],
                "",
                ["[AMOUNT]", "[NAME]", "[QUANTITY]"],
                []
            ),
        ],
    )
    def test_get_countnulls_statement(
        self, sqlserver_service, mock_database_object,
        columns, exclude_columns, where_clause, expected_contains, expected_not_in
    ):
        """Test countnulls statement with various configurations."""
        result = sqlserver_service._get_countnulls_statement(
            object=mock_database_object,
            column_intersections=columns,
            exclude_columns=exclude_columns,
            where_clause=where_clause
        )

        for expected in expected_contains:
            assert expected in result
        for expected in expected_not_in:
            assert expected not in result
