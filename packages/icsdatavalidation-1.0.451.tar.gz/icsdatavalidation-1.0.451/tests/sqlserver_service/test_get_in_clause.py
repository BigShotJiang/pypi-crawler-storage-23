import pytest

from icsDataValidation.services.database_services.sqlserver_service import SQLServerService


class TestInClauseVariations:
    """Test various IN clause generation scenarios using parametrization."""

    @pytest.mark.parametrize(
        "key_filters,numeric_columns,numeric_scale,expected_contains",
        [
            ( # basic single row
                {"col1": ["value1"], "col2": ["value2"]},
                [],
                2,
                [" AND (CONCAT(", "CONCAT([col1], '|' ,[col2], '|')", "('value1|value2|')"],
            ),
            ( # basic single row with one column
                {"col1": ["value1"]},
                [],
                2,
                [" AND (CONCAT(", "CONCAT([col1], '|')", "('value1|')"],
            ),
            ( # multiple rows
                {"id": [1, 2, 3], "name": ["a", "b", "c"]},
                [],
                2,
                ["(CONCAT([id], '|' ,[name], '|')", "('1|a|','2|b|','3|c|')"],
            ),
            ( # numeric columns with rounding
                {"price": [10.5, 20.3], "quantity": [5, 10]},
                ["price"],
                2,
                ["ROUND([price], 2)", "numeric(38, 2)", "quantity", "('10.5|5|','20.3|10|')"],
            ),
            ( # quotes in column names (should be removed)
                {"'col1'": ["value1"], "'col2'": ["value2"]},
                [],
                2,
                ["col1", "col2"],
            ),
            ( # empty filters
                {},
                [],
                2,
                [""],
            ),
            ( # numeric with specific scale
                {"Price": [100.123, 200.456], "Count": [1, 2]},
                ["Price"],
                3,
                ["ROUND([Price], 3)", "numeric(38, 3)", "Count"],
            ),
            ( # all numeric columns
                {"col1": [1.1, 2.2], "col2": [3.3, 4.4]},
                ["col1", "col2"],
                2,
                ["ROUND([col1], 2)", "ROUND([col2], 2)", "numeric(38, 2)"],
            ),
            ( # mixed data types
                {"amount": [100, 200], "category": ["A", "B"], "quantity": [10, 20]},
                ["amount", "quantity"],
                0,
                ["ROUND([amount], 0)", "ROUND([quantity], 0)", "category"],
            ),
            ( # values order check
                {"id": [1, 2], "name": ["alice", "bob"]},
                [],
                2,
                ["('1|alice|','2|bob|')"],
            ),
            ( # special character column names
                {"/ABC": ["value1", "value2"], "Normal": ["val1", "val2"]},
                [],
                2,
                ["[/ABC]", "[Normal]", "CONCAT([/ABC], '|' ,[Normal], '|')"],
            ),
        ],
    )
    def test_in_clause_contains(
        self, key_filters, numeric_columns, numeric_scale, expected_contains
    ):
        """Test that result contains expected substrings."""
        result = SQLServerService._get_in_clause(key_filters, numeric_columns, numeric_scale)

        for expected in expected_contains:
            assert expected in result
