from unittest.mock import MagicMock

import pytest

from icsDataValidation.services.database_services.sqlserver_service import SQLServerService


@pytest.fixture
def sqlserver_service():
    """Create a SQLServerService instance with mocked connection."""
    connection_params = {
        'Driver': 'ODBC Driver 18 for SQL Server',
        'Server': 'localhost',
        'Port': '1433',
        'Database': 'testdb',
        'User': 'sa',
        'Password': 'password',
        'Encrypt': True,
        'TrustServerCertificate': True
    }
    service = SQLServerService(connection_params=connection_params)
    service.sqlserver_connection = MagicMock()
    return service


class TestGetColumnClauseParametrized:
    """Parametrized tests for _get_column_clause method."""

    @pytest.mark.parametrize(
        "column_list,columns_datatype,numeric_scale,key_columns," \
        "expected_in_clause,expected_numeric,expected_used",
        [
            ( # numeric with scale
                ["Amount"],
                [{"COLUMN_NAME": "Amount", "DATA_TYPE": "decimal"}],
                2,
                [],
                ["CAST(ROUND([Amount], 2) as decimal(38,2)) as [Amount]"],
                ["Amount"],
                ["Amount"]
            ),
            ( # numeric without scale
                ["Price"],
                [{"COLUMN_NAME": "Price", "DATA_TYPE": "int"}],
                None,
                [],
                ["[Price] as [Price]"],
                ["Price"],
                ["Price"]
            ),
            ( # string column
                ["Name"],
                [{"COLUMN_NAME": "Name", "DATA_TYPE": "varchar"}],
                2,
                [],
                ["[Name] AS [Name]"],
                [],
                ["Name"]
            ),
            ( # date excluded by default
                ["CreatedDate"],
                [{"COLUMN_NAME": "CreatedDate", "DATA_TYPE": "datetime"}],
                2,
                [],
                [],
                [],
                []
            ),
            ( # date as key column
                ["CreatedDate"],
                [{"COLUMN_NAME": "CreatedDate", "DATA_TYPE": "datetime"}],
                2,
                ["CreatedDate"],
                ["CreatedDate"],
                [],
                ["CreatedDate"]
            ),
            ( # multiple mixed types
                ["Amount", "Name", "IsActive"],
                [
                    {"COLUMN_NAME": "Amount", "DATA_TYPE": "decimal"},
                    {"COLUMN_NAME": "Name", "DATA_TYPE": "varchar"},
                    {"COLUMN_NAME": "IsActive", "DATA_TYPE": "bit"}
                ],
                2,
                [],
                ["CAST(ROUND([Amount], 2)", "[Name] AS [Name]", "IsActive"],
                ["Amount"],
                ["Amount", "Name", "IsActive"]
            ),
            ( # special characters in column names
                ["/ISDFPS/OBJNR", "MANDT"],
                [
                    {"COLUMN_NAME": "/ISDFPS/OBJNR", "DATA_TYPE": "varchar"},
                    {"COLUMN_NAME": "MANDT", "DATA_TYPE": "varchar"}
                ],
                2,
                [],
                ["[/ISDFPS/OBJNR]", "[MANDT]"],
                [],
                ["/ISDFPS/OBJNR", "MANDT"]
            ),
            ( # binary column
                ["BinaryData"],
                [{"COLUMN_NAME": "BinaryData", "DATA_TYPE": "varbinary"}],
                2,
                [],
                ["BinaryData"],
                [],
                ["BinaryData"]
            ),
            ( # empty column list
                [],
                [],
                2,
                [],
                [],
                [],
                []
            ),
            ( # all numeric columns with scale
                ["Amount", "Price", "Quantity"],
                [
                    {"COLUMN_NAME": "Amount", "DATA_TYPE": "decimal"},
                    {"COLUMN_NAME": "Price", "DATA_TYPE": "money"},
                    {"COLUMN_NAME": "Quantity", "DATA_TYPE": "int"}
                ],
                3,
                [],
                ["decimal(38,3)"],
                ["Amount", "Price", "Quantity"],
                ["Amount", "Price", "Quantity"]
            ),
            ( # numeric with zero scale
                ["Count"],
                [{"COLUMN_NAME": "Count", "DATA_TYPE": "int"}],
                0,
                [],
                ["[Count] as [Count]"],
                ["Count"],
                ["Count"]
            ),
            ( # text and ntext columns
                ["Description", "Notes"],
                [
                    {"COLUMN_NAME": "Description", "DATA_TYPE": "text"},
                    {"COLUMN_NAME": "Notes", "DATA_TYPE": "ntext"}
                ],
                2,
                [],
                ["[Description] AS [Description]", "[Notes] AS [Notes]"],
                [],
                ["Description", "Notes"]
            ),
            ( # multiple date columns with one as key
                ["CreatedDate", "ModifiedDate", "Id"],
                [
                    {"COLUMN_NAME": "CreatedDate", "DATA_TYPE": "datetime"},
                    {"COLUMN_NAME": "ModifiedDate", "DATA_TYPE": "datetime2"},
                    {"COLUMN_NAME": "Id", "DATA_TYPE": "int"}
                ],
                2,
                ["CreatedDate"],
                ["CreatedDate", "Id"],
                ["Id"],
                ["CreatedDate", "Id"]
            ),
        ],
    )
    def test_get_column_clause(
        self, sqlserver_service, column_list, columns_datatype, numeric_scale,
        key_columns, expected_in_clause, expected_numeric, expected_used
    ):
        """Test column clause with various configurations."""
        column_clause, numeric_columns, used_columns = sqlserver_service._get_column_clause(
            column_list, columns_datatype, numeric_scale, key_columns
        )

        for expected in expected_in_clause:
            assert expected in column_clause
        assert set(numeric_columns) == set(expected_numeric)
        assert set(used_columns) == set(expected_used)
