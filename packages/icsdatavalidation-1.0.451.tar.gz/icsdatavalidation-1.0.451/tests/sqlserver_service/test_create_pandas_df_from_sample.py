from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

from icsDataValidation.core.database_objects import DatabaseObject, DatabaseObjectType
from icsDataValidation.services.database_services.sqlserver_service import SQLServerService


@pytest.fixture
def sqlserver_service():
    """Create a SQLServerService instance with mocked connection."""
    connection_params = {
        'Driver': 'ODBC Driver 18 for SQL Server',
        'Server': 'localhost',
        'Port': '1433',
        'Database': 'testdb',
        'User': 'sa',
        'Password': 'password',
        'Encrypt': True,
        'TrustServerCertificate': True
    }
    service = SQLServerService(connection_params=connection_params)
    service.sqlserver_connection = MagicMock()
    return service


@pytest.fixture
def mock_database_object():
    """Create a mock DatabaseObject."""
    obj = DatabaseObject(
        object_identifier="TEST_DB.TEST_SCHEMA.TEST_TABLE",
        object_type=DatabaseObjectType.TABLE
    )
    return obj


class TestCreatePandasDfFromSampleParametrized:
    """Parametrized tests for create_pandas_df_from_sample method."""

    @pytest.mark.parametrize(
        "column_intersections,key_columns,exclude_columns,dedicated_columns,"
        "where_clause,key_filters,sample_count,numeric_scale,enclose_quotes,"
        "mock_datatypes,mock_column_clause,mock_in_clause,expected_contains,expected_not_in",
        [
            (  # simple case with key columns
                ['id', 'name', 'amount'],
                ['id'],
                [],
                [],
                "",
                {},
                10,
                None,
                False,
                [
                    {"COLUMN_NAME": "id", "DATA_TYPE": "int"},
                    {"COLUMN_NAME": "name", "DATA_TYPE": "varchar"},
                    {"COLUMN_NAME": "amount", "DATA_TYPE": "int"}
                ],
                ("[id] as [id], [name] AS [name], [amount] as [amount]", ['id', 'amount'], ['id', 'name', 'amount']),
                None,
                [
                    "SELECT TOP (10) [id] as [id], [name] AS [name], [amount] as [amount]",
                    "FROM TEST_SCHEMA.TEST_TABLE",
                    "WHERE 1=1",
                    "ORDER BY [id];"
                ],
                []
            ),
            (  # multiple key columns
                ['id', 'region', 'amount'],
                ['id', 'region'],
                [],
                [],
                "",
                {},
                10,
                None,
                False,
                [
                    {"COLUMN_NAME": "id", "DATA_TYPE": "int"},
                    {"COLUMN_NAME": "region", "DATA_TYPE": "varchar"},
                    {"COLUMN_NAME": "amount", "DATA_TYPE": "int"}
                ],
                ("[id] as [id], [region] AS [region], [amount] as [amount]", ['id', 'amount'], ['id', 'region', 'amount']),
                None,
                ["ORDER BY [id], [region];"],
                []
            ),
            (  # with where clause
                ['id', 'status'],
                ['id'],
                [],
                [],
                "WHERE status = 'active'",
                {},
                10,
                None,
                False,
                [
                    {"COLUMN_NAME": "id", "DATA_TYPE": "int"},
                    {"COLUMN_NAME": "status", "DATA_TYPE": "varchar"}
                ],
                ("[id] as [id], [status] AS [status]", ['id'], ['id', 'status']),
                None,
                ["WHERE status = 'active'", "ORDER BY [id];"],
                []
            ),
            (  # excluded columns
                ['id', 'name', 'secret'],
                ['id'],
                ['secret'],
                [],
                "",
                {},
                10,
                None,
                False,
                [
                    {"COLUMN_NAME": "id", "DATA_TYPE": "int"},
                    {"COLUMN_NAME": "name", "DATA_TYPE": "varchar"}
                ],
                ("[id] as [id], [name] AS [name]", ['id'], ['id', 'name']),
                None,
                ["[id]", "[name]", "ORDER BY [id];"],
                ["[secret]"]
            ),
            (  # with key filters
                ['id', 'region', 'amount'],
                ['id', 'region'],
                [],
                [],
                "",
                {'id': [1, 2], 'region': ['US', 'EU']},
                10,
                None,
                False,
                [
                    {"COLUMN_NAME": "id", "DATA_TYPE": "int"},
                    {"COLUMN_NAME": "region", "DATA_TYPE": "varchar"},
                    {"COLUMN_NAME": "amount", "DATA_TYPE": "int"}
                ],
                ("[id] as [id], [region] AS [region], [amount] as [amount]", ['id', 'amount'], ['id', 'region', 'amount']),
                " AND (CONCAT(cast(ROUND([id], 0) as numeric(38, 0)), '|' ,[region], '|') in ('1|US|','2|EU|'))",
                [
                    "AND (CONCAT(cast(ROUND([id], 0) as numeric(38, 0)), '|' ,[region], '|') in ('1|US|','2|EU|'))",
                    "ORDER BY [id], [region];"
                ],
                []
            ),
            (  # dedicated columns
                ['id', 'name', 'amount', 'description'],
                ['id'],
                [],
                ['id', 'name'],
                "",
                {},
                10,
                None,
                False,
                [
                    {"COLUMN_NAME": "id", "DATA_TYPE": "int"},
                    {"COLUMN_NAME": "name", "DATA_TYPE": "varchar"}
                ],
                ("[id] as [id], [name] AS [name]", ['id'], ['id', 'name']),
                None,
                ["[id]", "[name]", "ORDER BY [id];"],
                ["[amount]", "[description]"]
            ),
            (  # custom sample count
                ['id', 'name'],
                ['id'],
                [],
                [],
                "",
                {},
                50,
                None,
                False,
                [
                    {"COLUMN_NAME": "id", "DATA_TYPE": "int"},
                    {"COLUMN_NAME": "name", "DATA_TYPE": "varchar"}
                ],
                ("[id] as [id], [name] AS [name]", ['id'], ['id', 'name']),
                None,
                ["SELECT TOP (50)"] ,
                []
            ),
            (  # no key columns (uses ORDER BY NEWID())
                ['id', 'name', 'amount'],
                [],
                [],
                [],
                "",
                {},
                10,
                None,
                False,
                [
                    {"COLUMN_NAME": "id", "DATA_TYPE": "int"},
                    {"COLUMN_NAME": "name", "DATA_TYPE": "varchar"},
                    {"COLUMN_NAME": "amount", "DATA_TYPE": "int"}
                ],
                ("[id] as [id], [name] AS [name], [amount] as [amount]", ['id', 'amount'], ['id', 'name', 'amount']),
                None,
                ["SELECT TOP (10) [id] as [id], [name] AS [name], [amount] as [amount]", "WHERE 1=1", "ORDER BY NEWID();"],
                ["ORDER BY ["]
            ),
            (  # with numeric scale, no double quotes
                ['id', 'price'],
                ['id'],
                [],
                [],
                "",
                {},
                10,
                2,
                False,
                [
                    {"COLUMN_NAME": "id", "DATA_TYPE": "int"},
                    {"COLUMN_NAME": "price", "DATA_TYPE": "decimal"}
                ],
                ("[id] as [id], CAST(ROUND([price], 2) as decimal(38,2)) as [price]", ['id', 'price'], ['id', 'price']),
                None,
                ["CAST(ROUND([price], 2) as decimal(38,2)) as [price]"],
                []
            ),
            (  # special characters
                ['User ID', 'Full Name', 'Email-Address'],
                ['User ID'],
                [],
                [],
                "",
                {},
                10,
                None,
                False,
                [
                    {"COLUMN_NAME": "User ID", "DATA_TYPE": "int"},
                    {"COLUMN_NAME": "Full Name", "DATA_TYPE": "varchar"},
                    {"COLUMN_NAME": "Email-Address", "DATA_TYPE": "varchar"}
                ],
                ("[User ID] as [User ID], [Full Name] AS [Full Name], [Email-Address] AS [Email-Address]", ['User ID'], ['User ID', 'Full Name', 'Email-Address']),
                None,
                ["[User ID]", "[Full Name]", "[Email-Address]", "ORDER BY [User ID];"],
                []
            ),
        ],
    )
    def test_create_pandas_df_from_sample(
        self, sqlserver_service, mock_database_object,
        column_intersections, key_columns, exclude_columns, dedicated_columns,
        where_clause, key_filters, sample_count, numeric_scale, enclose_quotes,
        mock_datatypes, mock_column_clause, mock_in_clause,
        expected_contains, expected_not_in
    ):
        """Test create_pandas_df_from_sample with various configurations."""
        with patch.object(sqlserver_service, 'get_data_types_from_object') as mock_get_datatypes, \
             patch.object(sqlserver_service, '_get_column_clause') as mock_get_column, \
             patch.object(sqlserver_service, '_get_in_clause') as mock_get_in, \
             patch.object(sqlserver_service, 'execute_queries') as mock_execute:

            mock_get_datatypes.return_value = mock_datatypes
            mock_get_column.return_value = mock_column_clause
            if mock_in_clause:
                mock_get_in.return_value = mock_in_clause
            mock_execute.return_value = pd.DataFrame({'id': [1], 'name': ['A'], 'region': ['US'], 'User ID': [123]})

            result_list, key_dict, used_columns, sample_query = sqlserver_service.create_pandas_df_from_sample(
                object=mock_database_object,
                column_intersections=column_intersections,
                key_columns=key_columns,
                exclude_columns=exclude_columns,
                dedicated_columns=dedicated_columns,
                where_clause=where_clause,
                key_filters=key_filters,
                sample_count=sample_count,
                numeric_scale=numeric_scale,
                enclose_column_by_double_quotes=enclose_quotes
            )

            for expected in expected_contains:
                assert expected in sample_query
            for expected in expected_not_in:
                assert expected not in sample_query
