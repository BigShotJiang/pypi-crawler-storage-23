"""Signal detection package."""

from .detector import Model, SignalDetector

__all__ = ["Model", "SignalDetector"]
