# mypackage_alt - clean Python (export_mode = py)
