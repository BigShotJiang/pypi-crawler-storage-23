Features
********


This section describes all features that are shipped with this package.


Scenario Features
=================

.. autoclass:: balderhub.ble.lib.scenario_features.AdvertisementObserverFeature
    :members:

.. autoclass:: balderhub.ble.lib.scenario_features.BleDeviceConfig
    :members:

.. autoclass:: balderhub.ble.lib.scenario_features.DeviceInformationConfig
    :members:

GATT Features
-------------

.. autoclass:: balderhub.ble.lib.scenario_features.gatt.BaseGattProfileFeature
    :members:

.. autoclass:: balderhub.ble.lib.scenario_features.gatt.BaseGattServiceFeature
    :members:

.. autoclass:: balderhub.ble.lib.scenario_features.gatt.GattBatteryServiceFeature
    :members:

.. autoclass:: balderhub.ble.lib.scenario_features.gatt.GattControllerFeature
    :members:

.. autoclass:: balderhub.ble.lib.scenario_features.gatt.GattDeviceInformationServiceFeature
    :members:

.. autoclass:: balderhub.ble.lib.scenario_features.gatt.GattHeartRateProfileFeature
    :members:

.. autoclass:: balderhub.ble.lib.scenario_features.gatt.GattHeartRateServiceFeature
    :members:


Setup Features
==============

.. autoclass:: balderhub.ble.lib.setup_features.BleakGattControllerFeature
    :members:

.. autoclass:: balderhub.ble.lib.setup_features.BleakAdvertisementObserverFeature
    :members:
