"""
langvision.agents

This package contains agent classes and logic for orchestrating LLMs and other components.
"""

class Agent:
    pass
