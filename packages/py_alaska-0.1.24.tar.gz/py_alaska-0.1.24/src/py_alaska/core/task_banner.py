# Copyright (c) 2026 동일비전(Dongil Vision Korea). All Rights Reserved.
import unicodedata
from typing import List, Optional, Union


def banner(msg: Union[str, List[str]], description: Optional[List[str]] = None) -> None:
    """Draw a box around the message with margin (supports wide characters like Korean, Chinese)

    Args:
        msg: 제목 문자열 또는 여러 줄 리스트
        description: 추가 설명 리스트 (선택)

    Examples:
        banner("Hello World")
        banner("Title", ["Line 1", "Line 2"])
    """
    def display_width(text: str) -> int:
        width = 0
        for char in text:
            if unicodedata.east_asian_width(char) in ('F', 'W'):
                width += 2
            else:
                width += 1
        return width

    margin = 4
    min_width = 80  # 최소 박스 폭

    # msg 처리: 문자열이면 줄 분리, 리스트면 그대로
    if isinstance(msg, str):
        title_lines = msg.split('\n')
    else:
        title_lines = list(msg)

    # description 처리
    desc_lines = list(description) if description else []

    # 전체 라인 구성
    all_lines = title_lines
    if desc_lines:
        all_lines = title_lines + [''] + desc_lines  # 빈 줄로 구분

    max_width = max(display_width(line) for line in all_lines) if all_lines else 0
    box_width = max(max_width + margin * 2, min_width)

    top_left = '┌'
    top_right = '┐'
    bottom_left = '└'
    bottom_right = '┘'
    horizontal = '─'
    vertical = '│'

    result = []
    result.append(top_left + horizontal * box_width + top_right)

    for line in all_lines:
        line_width = display_width(line)
        padding_left = ' ' * margin
        padding_right = ' ' * (box_width - margin - line_width)
        result.append(f'{vertical}{padding_left}{line}{padding_right}{vertical}')

    result.append(bottom_left + horizontal * box_width + bottom_right)

    output = '\n'.join(result)
    print(output.encode('utf-8').decode('utf-8'))