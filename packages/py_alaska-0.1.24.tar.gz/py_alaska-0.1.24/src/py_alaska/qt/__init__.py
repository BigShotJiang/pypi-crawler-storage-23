# Copyright (c) 2026 동일비전(Dongil Vision Korea). All Rights Reserved.
"""
py_alaska Qt Integration Module

PySide6/PyQt 애플리케이션과의 통합을 위한 유틸리티
- AlaskaApp: Qt 앱 원라인 시작
- ui_thread: UI 스레드 자동 전환 데코레이터
"""

from .app import AlaskaApp
from .decorators import ui_thread

__all__ = ["AlaskaApp", "ui_thread"]
