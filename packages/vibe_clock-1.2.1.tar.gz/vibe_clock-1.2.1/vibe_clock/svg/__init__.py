"""SVG chart generators."""
