#ifndef CF_DATAHIVE_CPP_CF_DATAHIVE_CPP_H
#define CF_DATAHIVE_CPP_CF_DATAHIVE_CPP_H

#include <string>

namespace cf_datahive_cpp {

struct SinkConfig {
  std::string workspace_root;
  std::string pipeline_id;
  std::string pipeline_label;
  int cycle_count = 20;
};

struct SinkResult {
  bool ok = false;
  std::string run_id;
  std::string session_id;
  int session_run_index = 0;
  std::string status;
  std::string error;
};

SinkResult write_demo_measurements_run(const SinkConfig& config, const std::string& payload);

}  // namespace cf_datahive_cpp

#endif  // CF_DATAHIVE_CPP_CF_DATAHIVE_CPP_H
