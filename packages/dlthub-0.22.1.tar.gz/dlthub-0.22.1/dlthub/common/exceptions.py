from dlt.common.exceptions import DltException


class DltPlusException(DltException):
    pass
