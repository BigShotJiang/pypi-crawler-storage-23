from typing_extensions import ParamSpec

TTransformationFunParams = ParamSpec("TTransformationFunParams")
