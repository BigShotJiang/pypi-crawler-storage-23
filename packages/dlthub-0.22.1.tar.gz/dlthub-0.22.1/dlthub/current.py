from dlthub.project import current as project


__all__ = ["project"]
