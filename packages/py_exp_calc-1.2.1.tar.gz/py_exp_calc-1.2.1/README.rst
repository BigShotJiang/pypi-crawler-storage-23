.. These are examples of badges you might want to add to your README:
   please update the URLs accordingly

    .. image:: https://api.cirrus-ci.com/github/<USER>/py_exp_calc.svg?branch=main
        :alt: Built Status
        :target: https://cirrus-ci.com/github/<USER>/py_exp_calc
    .. image:: https://readthedocs.org/projects/py_exp_calc/badge/?version=latest
        :alt: ReadTheDocs
        :target: https://py_exp_calc.readthedocs.io/en/stable/
    .. image:: https://img.shields.io/coveralls/github/<USER>/py_exp_calc/main.svg
        :alt: Coveralls
        :target: https://coveralls.io/r/<USER>/py_exp_calc
    .. image:: https://img.shields.io/pypi/v/py_exp_calc.svg
        :alt: PyPI-Server
        :target: https://pypi.org/project/py_exp_calc/
    .. image:: https://img.shields.io/conda/vn/conda-forge/py_exp_calc.svg
        :alt: Conda-Forge
        :target: https://anaconda.org/conda-forge/py_exp_calc
    .. image:: https://pepy.tech/badge/py_exp_calc/month
        :alt: Monthly Downloads
        :target: https://pepy.tech/project/py_exp_calc
    .. image:: https://img.shields.io/twitter/url/http/shields.io.svg?style=social&label=Twitter
        :alt: Twitter
        :target: https://twitter.com/py_exp_calc

.. image:: https://img.shields.io/badge/-PyScaffold-005CA0?logo=pyscaffold
    :alt: Project generated with PyScaffold
    :target: https://pyscaffold.org/

|

===========
py_exp_calc
===========


    Python package for amplifying operations on main Python data structures.


First, this package can enhance operations on various data structures such as lists, numpy arrays, and dictionaries. It allows not only an increase in the available operations within these data structures but also conversion between them. Some of the main operations are:

* Lists: Flattening, ensuring unique elements (uniq), adding tags to list elements and performing set operations such as intersection, union, and difference between lists.
* Dictionaries: Enhanced operations for nested dictionaries, such as the dig method from Ruby, addition and removal of key-value pairs and expanding dictionaries by adding values in list format.
* Numpy arrays: Matrix normalization and filtering.

Secondly, advanced data analysis operations have been added to the toolkit, including statistical analysis and clustering. To facilitate these operations, two command-line interfaces (CLIs) have been designed:

* clusterize: Applies hierarchical clustering to a given matrix.
* inference_analyzer: Executes inference analysis on a set of n observations divided into m categories.
