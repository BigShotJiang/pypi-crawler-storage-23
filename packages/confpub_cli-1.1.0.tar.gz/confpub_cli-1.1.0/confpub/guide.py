"""guide command — full machine-readable CLI schema.

An agent calls `confpub guide` once, caches the result, and can drive
the entire CLI zero-shot. Supports --section for filtering.
"""

from __future__ import annotations

from typing import Any

from confpub import __version__
from confpub.errors import (
    ERR_AUTH_EXPIRED,
    ERR_AUTH_FORBIDDEN,
    ERR_AUTH_REQUIRED,
    ERR_CONFLICT_FILE_EXISTS,
    ERR_CONFLICT_FINGERPRINT,
    ERR_CONFLICT_LOCK,
    ERR_CONFLICT_PAGE_EXISTS,
    ERR_INTERNAL_CONVERTER,
    ERR_INTERNAL_REVERSE_CONVERTER,
    ERR_INTERNAL_SDK,
    ERR_IO_CONNECTION,
    ERR_IO_FILE_NOT_FOUND,
    ERR_IO_TIMEOUT,
    ERR_VALIDATION_ASSET_MISSING,
    ERR_VALIDATION_MANIFEST,
    ERR_VALIDATION_MARKDOWN,
    ERR_VALIDATION_NOT_FOUND,
    ERR_VALIDATION_REQUIRED,
    ERR_VALIDATION_SPACE_MISMATCH,
    exit_code_for,
    retryable_for,
    suggested_action_for,
)


def _error_code_entry(code: str, **extra: Any) -> dict[str, Any]:
    entry: dict[str, Any] = {
        "exit_code": exit_code_for(code),
        "retryable": retryable_for(code),
        "suggested_action": suggested_action_for(code),
    }
    entry.update(extra)
    return entry


def build_guide() -> dict[str, Any]:
    """Build the complete guide JSON schema."""
    return {
        "schema_version": "1.0",
        "tool_version": __version__,
        "compatibility": {
            "additive_changes": "minor",
            "breaking_changes": "major",
        },
        "commands": {
            "guide": {
                "group": "meta",
                "mutates": False,
                "description": "Machine-readable CLI schema for agent consumption",
                "flags": ["--section"],
            },
            "search": {
                "group": "read",
                "mutates": False,
                "description": "Search Confluence content using CQL",
                "flags": ["--cql", "--space", "--title", "--type", "--limit", "--start", "--include-archived", "--excerpt-length"],
                "agent_hint": (
                    "Most agent workflows should include --type page to exclude attachments and space entities from results. "
                    "Use --start and --limit for pagination: first call with --start 0 --limit 25, "
                    "then if has_more is true, call again with --start 25 --limit 25, and so on."
                ),
                "result_schema": {
                    "cql_query": "string — effective CQL sent to the API",
                    "results": "list of {id, type, title, excerpt, url, space_key, entity_type, status, last_modified, container_title}",
                    "total": "int — total matching results",
                    "start": "int — current offset",
                    "limit": "int — page size",
                    "has_more": "bool — true if more results available",
                },
                "examples": [
                    'confpub search --cql \'label = "api-docs"\'',
                    "confpub search --space DEV --type page --limit 10",
                    'confpub search --space DEV --cql \'title ~ "deploy"\'',
                    'confpub search --title "deploy guide" --space DEV',
                    "confpub search --space DEV --type page --start 0 --limit 50",
                ],
            },
            "page.list": {
                "group": "read",
                "mutates": False,
                "description": "List pages in a Confluence space",
                "flags": ["--space", "--limit", "--start"],
            },
            "page.inspect": {
                "group": "read",
                "mutates": False,
                "description": "Inspect a Confluence page",
                "flags": ["--space", "--title", "--page-id", "--format", "--raw"],
                "agent_hint": (
                    "Use --format markdown to get the page body as Markdown instead of Confluence storage format. "
                    "Use --raw for the full unprocessed API response (useful for debugging)."
                ),
                "result_schema": {
                    "page_id": "string",
                    "title": "string",
                    "space_key": "string",
                    "version": "int",
                    "url": "string",
                    "body_storage": "string (when --format storage, the default)",
                    "body_markdown": "string (when --format markdown)",
                },
                "examples": [
                    'confpub page inspect --space DEV --title "My Page"',
                    "confpub page inspect --page-id 12345 --format markdown",
                    "confpub page inspect --page-id 12345 --raw",
                ],
            },
            "page.publish": {
                "group": "write",
                "mutates": True,
                "description": "Publish a single Markdown file to Confluence",
                "flags": ["--space", "--parent", "--title", "--page-id", "--dry-run", "--backup"],
                "agent_hint": (
                    "When --title is omitted, the title is inferred from the filename: "
                    "the stem is extracted, hyphens and underscores are replaced with spaces, "
                    "and the result is title-cased. E.g. 'my-cool-page.md' → 'My Cool Page'."
                ),
            },
            "page.pull": {
                "group": "read",
                "mutates": False,
                "description": "Pull Confluence pages to local Markdown files",
                "flags": [
                    "--space", "--title", "--page-id",
                    "--output", "--recursive", "--force",
                    "--layout", "--no-attachments", "--manifest",
                ],
                "safety_flags": {
                    "--force": "Overwrites existing local files without confirmation",
                },
                "agent_hint": (
                    "During recursive pulls, NDJSON progress events are emitted on stderr "
                    "with step (running discovery count) and total (0 until known). "
                    "Use --quiet to suppress."
                ),
            },
            "page.delete": {
                "group": "write",
                "mutates": True,
                "description": "Delete a Confluence page",
                "flags": ["--space", "--title", "--page-id", "--cascade"],
                "safety_flags": {
                    "--cascade": "Also deletes child pages",
                },
                "result_schema": {
                    "deleted_ids": "list of string — sorted page IDs that were deleted",
                    "deleted_count": "int — number of pages deleted (including children when --cascade)",
                },
            },
            "space.list": {
                "group": "read",
                "mutates": False,
                "description": "List accessible Confluence spaces",
                "flags": [],
            },
            "attachment.list": {
                "group": "read",
                "mutates": False,
                "description": "List attachments on a Confluence page",
                "flags": ["--page-id"],
            },
            "attachment.upload": {
                "group": "write",
                "mutates": True,
                "description": "Upload an attachment to a Confluence page",
                "flags": ["--page-id"],
            },
            "plan.create": {
                "group": "transactional",
                "mutates": False,
                "description": "Generate a plan artifact from a manifest or file",
                "flags": ["--manifest", "--output", "--space", "--parent"],
            },
            "plan.validate": {
                "group": "transactional",
                "mutates": False,
                "description": "Validate a plan artifact against current state",
                "flags": ["--plan"],
            },
            "plan.apply": {
                "group": "transactional",
                "mutates": True,
                "description": "Apply a plan to Confluence",
                "flags": [
                    "--plan", "--dry-run", "--backup",
                    "--skip-fingerprint-check", "--cascade",
                ],
                "safety_flags": {
                    "--skip-fingerprint-check": (
                        "Bypasses stale-state detection — use only if you know "
                        "the page changed intentionally"
                    ),
                    "--cascade": "Allows deletes that affect child pages",
                },
                "result_schema": {
                    "dry_run": "bool",
                    "changes": "list of change records",
                    "summary": "{create: int, update: int, attachments_upload: int}",
                    "lockfile_updated": "bool — true if lockfile was written",
                    "lockfile_path": "string | null — absolute path to lockfile (null on dry-run)",
                },
            },
            "plan.verify": {
                "group": "transactional",
                "mutates": False,
                "description": "Verify post-conditions after apply",
                "flags": ["--assertions", "--plan"],
            },
            "auth.inspect": {
                "group": "auth",
                "mutates": False,
                "description": "Show current credential status",
                "flags": [],
            },
            "config.set": {
                "group": "config",
                "mutates": True,
                "description": "Set a configuration value",
                "flags": [],
                "args": ["KEY", "VALUE"],
                "agent_hint": (
                    "Valid keys: base_url, user, token. "
                    "Values are persisted to the config file (~/.confpub/config.json)."
                ),
                "examples": [
                    "confpub config set base_url https://mysite.atlassian.net/wiki",
                    "confpub config set user alice@example.com",
                    "confpub config set token ATATT...",
                ],
            },
            "config.inspect": {
                "group": "config",
                "mutates": False,
                "description": "Show current configuration",
                "flags": [],
            },
        },
        "error_codes": {
            ERR_VALIDATION_REQUIRED: _error_code_entry(ERR_VALIDATION_REQUIRED),
            ERR_VALIDATION_MANIFEST: _error_code_entry(ERR_VALIDATION_MANIFEST),
            ERR_VALIDATION_MARKDOWN: _error_code_entry(ERR_VALIDATION_MARKDOWN),
            ERR_VALIDATION_ASSET_MISSING: _error_code_entry(ERR_VALIDATION_ASSET_MISSING),
            ERR_VALIDATION_NOT_FOUND: _error_code_entry(ERR_VALIDATION_NOT_FOUND),
            ERR_VALIDATION_SPACE_MISMATCH: _error_code_entry(ERR_VALIDATION_SPACE_MISMATCH),
            ERR_AUTH_REQUIRED: _error_code_entry(ERR_AUTH_REQUIRED),
            ERR_AUTH_EXPIRED: _error_code_entry(ERR_AUTH_EXPIRED),
            ERR_AUTH_FORBIDDEN: _error_code_entry(ERR_AUTH_FORBIDDEN),
            ERR_CONFLICT_FINGERPRINT: _error_code_entry(ERR_CONFLICT_FINGERPRINT),
            ERR_CONFLICT_LOCK: _error_code_entry(ERR_CONFLICT_LOCK),
            ERR_CONFLICT_PAGE_EXISTS: _error_code_entry(ERR_CONFLICT_PAGE_EXISTS),
            ERR_CONFLICT_FILE_EXISTS: _error_code_entry(ERR_CONFLICT_FILE_EXISTS),
            ERR_IO_FILE_NOT_FOUND: _error_code_entry(ERR_IO_FILE_NOT_FOUND),
            ERR_IO_CONNECTION: _error_code_entry(
                ERR_IO_CONNECTION, retry_after_ms=2000,
            ),
            ERR_IO_TIMEOUT: _error_code_entry(ERR_IO_TIMEOUT, retry_after_ms=2000),
            ERR_INTERNAL_CONVERTER: _error_code_entry(ERR_INTERNAL_CONVERTER),
            ERR_INTERNAL_REVERSE_CONVERTER: _error_code_entry(ERR_INTERNAL_REVERSE_CONVERTER),
            ERR_INTERNAL_SDK: _error_code_entry(ERR_INTERNAL_SDK),
        },
        "global_flags": {
            "description": "Flags that can be placed at the top level or between group name and subcommand.",
            "flags": {
                "--quiet": "Suppress progress output on stderr",
                "--verbose": "Include diagnostics in result",
                "--version": "Show version and exit (top-level only)",
            },
            "placement": [
                "confpub --quiet page publish ...  (before the group)",
                "confpub page --quiet publish ...  (between group and command)",
                "Both positions are equivalent; the flag is parsed by the group callback",
            ],
        },
        "concurrency": {
            "rule": (
                "Never run multiple write commands against the same "
                "space and page in parallel"
            ),
            "safe_patterns": [
                "Read commands (search, page.list, page.inspect) can parallelize freely",
                "Writes to DIFFERENT spaces can parallelize",
                (
                    "Use plan.apply with a single manifest for multi-page "
                    "publishes — do not run parallel applies"
                ),
            ],
            "lock_behavior": (
                "plan.apply acquires a local lockfile; concurrent applies "
                "to the same workspace return ERR_CONFLICT_LOCK"
            ),
        },
        "lockfile": {
            "description": "Local state file tracking page IDs and versions from publish/pull operations.",
            "file": "confpub.lock",
            "schema": {
                "schema_version": "Lockfile format version (currently '1.0')",
                "last_updated": "ISO 8601 timestamp of last write",
                "pages": "Map of page title to { page_id, version }",
            },
            "behavior": [
                "Created/updated automatically by page.publish, page.pull, and plan.apply",
                "Entries removed automatically by page.delete (including --cascade)",
                "Written atomically (temp file + rename) for crash safety",
                "Used by plan.create to detect existing pages and versions",
                "Does not prevent concurrent operations — purely local state tracking",
                (
                    "Path resolution: page.publish and page.delete use CWD/confpub.lock; "
                    "page.pull uses <output-dir>/confpub.lock; "
                    "plan.apply uses <plan-dir>/confpub.lock (same directory as the plan artifact)"
                ),
            ],
        },
        "assertions": {
            "description": "Post-condition assertions verified by plan.verify.",
            "file_format": "JSON array of assertion objects, or embedded in confpub.yaml under the 'assertions' key.",
            "auto_generation": "When --plan is passed without --assertions, plan.verify auto-generates page.exists assertions for every create/update page in the plan.",
            "types": {
                "page.exists": {
                    "description": "Verify that a page exists in the given space.",
                    "required_fields": ["type", "space", "title"],
                    "example": {"type": "page.exists", "space": "DEV", "title": "My Page"},
                },
                "page.parent": {
                    "description": "Verify that a page has the expected parent.",
                    "required_fields": ["type", "space", "title", "expected_parent"],
                    "example": {"type": "page.parent", "space": "DEV", "title": "My Page", "expected_parent": "Parent Page"},
                },
                "attachment.exists": {
                    "description": "Verify that an attachment exists on a page.",
                    "required_fields": ["type", "space", "page", "filename"],
                    "example": {"type": "attachment.exists", "space": "DEV", "page": "My Page", "filename": "diagram.png"},
                },
            },
        },
        "auth": {
            "precedence": [
                "--token + --user",
                "CONFPUB_TOKEN + CONFPUB_USER",
                "config_file",
                "os_keychain",
            ],
            "non_interactive": (
                "Never prompts when LLM=true or stdin is non-interactive"
            ),
            "inspect_command": "confpub auth inspect",
        },
    }
