"""
This is a namespace reservation. Please install 'trustscope' instead:
    pip install trustscope

https://trustscope.ai
"""

__version__ = "0.0.1"

import warnings
warnings.warn(
    "You have installed 'trustscope-ai'. The correct package is 'trustscope'. "
    "Please run: pip install trustscope",
    DeprecationWarning,
    stacklevel=2,
)
