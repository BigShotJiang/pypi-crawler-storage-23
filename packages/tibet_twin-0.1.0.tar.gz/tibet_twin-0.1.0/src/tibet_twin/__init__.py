"""
tibet-twin — Digital Twin Synchronicity Guard
==============================================

Deterministic sync verification between physical and virtual systems.
No action without proven synchronization. Every deviation is an alert.

TIBET proves the physical state matches the virtual state at the exact
moment of action. tibet-pol blocks when they diverge.

Usage::

    from tibet_twin import SyncGuard, PhysicalState, TwinState

    guard = SyncGuard(max_drift_ms=500)
    guard.register_physical("crane-01", state=PhysicalState(...))
    guard.register_twin("crane-01", state=TwinState(...))

    decision = guard.check("crane-01", intent="move_left")
    if decision.blocked:
        print(f"BLOCKED: {decision.reason}")  # drift_ms=503, state mismatch

Authors: J. van de Meent & R. AI (Root AI)
License: MIT — Humotica AI Lab 2025-2026
"""

from .guard import SyncGuard, SyncDecision
from .state import PhysicalState, TwinState, StateDelta
from .provenance import TwinProvenance
from .profiles import get_profile, list_profiles

__version__ = "0.1.0"

__all__ = [
    "SyncGuard",
    "SyncDecision",
    "PhysicalState",
    "TwinState",
    "StateDelta",
    "TwinProvenance",
    "get_profile",
    "list_profiles",
]
