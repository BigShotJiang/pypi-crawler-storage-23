"""
Sync Guard — the core safety engine.

No action without proven synchronization.
Every deviation is an alert. Every decision is a TIBET token.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

from .state import PhysicalState, TwinState, StateDelta, compute_delta
from .provenance import TwinProvenance


@dataclass
class SyncDecision:
    """
    Decision on whether an action is safe to execute.

    If blocked=True, the action MUST NOT proceed.
    The reason explains why, and the delta shows the evidence.
    """
    device_id: str
    intent: str
    allowed: bool
    blocked: bool
    reason: str
    delta: Optional[StateDelta] = None
    provenance_token: Optional[dict] = None
    timestamp: str = ""

    def to_dict(self) -> dict:
        return {
            "device_id": self.device_id,
            "intent": self.intent,
            "allowed": self.allowed,
            "blocked": self.blocked,
            "reason": self.reason,
            "delta": self.delta.to_dict() if self.delta else None,
            "timestamp": self.timestamp,
        }


class SyncGuard:
    """
    Digital Twin Synchronicity Guard.

    Ensures physical and virtual states are synchronized before
    allowing any action. If they diverge beyond tolerance,
    the action is BLOCKED.

    This prevents the deadly scenario where a digital twin
    authorizes an action based on stale data.

    Usage::

        guard = SyncGuard(max_drift_ms=500)
        guard.update_physical("crane-01", PhysicalState(...))
        guard.update_twin("crane-01", TwinState(...))

        decision = guard.check("crane-01", intent="move_left")
        if decision.blocked:
            print(f"BLOCKED: {decision.reason}")
    """

    def __init__(
        self,
        max_drift_ms: float = 1000.0,
        value_tolerances: dict[str, dict[str, float]] | None = None,
        actor: str = "tibet-twin",
    ):
        self.max_drift_ms = max_drift_ms
        self.value_tolerances = value_tolerances or {}
        self.provenance = TwinProvenance(actor=actor)

        self._physical: dict[str, PhysicalState] = {}
        self._twin: dict[str, TwinState] = {}
        self._stats = {
            "checks": 0,
            "allowed": 0,
            "blocked": 0,
        }

    def update_physical(self, device_id: str, state: PhysicalState) -> None:
        """Update the physical state for a device."""
        self._physical[device_id] = state

    def update_twin(self, device_id: str, state: TwinState) -> None:
        """Update the digital twin state for a device."""
        self._twin[device_id] = state

    def check(self, device_id: str, intent: str) -> SyncDecision:
        """
        Check if an action is safe based on physical-twin synchronization.

        Args:
            device_id: The device to check
            intent: What action is being attempted (e.g., "move_left", "start_motor")

        Returns:
            SyncDecision with allowed/blocked status and evidence
        """
        now = datetime.now(timezone.utc).isoformat()
        self._stats["checks"] += 1

        # Check if we have both states
        if device_id not in self._physical:
            decision = SyncDecision(
                device_id=device_id,
                intent=intent,
                allowed=False,
                blocked=True,
                reason="No physical state available — cannot verify sync",
                timestamp=now,
            )
            self._stats["blocked"] += 1
            self._create_decision_token(decision)
            return decision

        if device_id not in self._twin:
            decision = SyncDecision(
                device_id=device_id,
                intent=intent,
                allowed=False,
                blocked=True,
                reason="No twin state available — cannot verify sync",
                timestamp=now,
            )
            self._stats["blocked"] += 1
            self._create_decision_token(decision)
            return decision

        # Compute delta
        physical = self._physical[device_id]
        twin = self._twin[device_id]
        tolerances = self.value_tolerances.get(device_id, {})

        delta = compute_delta(
            physical, twin,
            max_drift_ms=self.max_drift_ms,
            max_value_tolerance=tolerances,
        )

        # Make decision
        if delta.synced and delta.safe:
            decision = SyncDecision(
                device_id=device_id,
                intent=intent,
                allowed=True,
                blocked=False,
                reason=f"Sync OK: drift={delta.drift_ms}ms, status match",
                delta=delta,
                timestamp=now,
            )
            self._stats["allowed"] += 1
        else:
            reasons = []
            if delta.drift_ms > self.max_drift_ms:
                reasons.append(f"time drift {delta.drift_ms}ms > {self.max_drift_ms}ms")
            if delta.status_mismatch:
                reasons.append(
                    f"status mismatch: physical={delta.physical_status}, "
                    f"twin={delta.twin_status}"
                )
            if not delta.synced and not reasons:
                reasons.append(
                    f"value deviation: {delta.max_delta_sensor}="
                    f"{delta.max_value_delta}"
                )

            decision = SyncDecision(
                device_id=device_id,
                intent=intent,
                allowed=False,
                blocked=True,
                reason=f"BLOCKED: {'; '.join(reasons)}",
                delta=delta,
                timestamp=now,
            )
            self._stats["blocked"] += 1

        self._create_decision_token(decision)
        return decision

    def _create_decision_token(self, decision: SyncDecision) -> None:
        """Create a TIBET token for the sync decision."""
        token = self.provenance.create_token(
            action="sync_check",
            device_id=decision.device_id,
            intent=decision.intent,
            allowed=decision.allowed,
            details={
                "reason": decision.reason,
                "drift_ms": decision.delta.drift_ms if decision.delta else None,
                "synced": decision.delta.synced if decision.delta else False,
            },
        )
        decision.provenance_token = token.to_dict()

    def status(self) -> dict:
        """Guard status."""
        return {
            "monitored_devices": len(
                set(self._physical.keys()) | set(self._twin.keys())
            ),
            "physical_states": len(self._physical),
            "twin_states": len(self._twin),
            "checks": self._stats["checks"],
            "allowed": self._stats["allowed"],
            "blocked": self._stats["blocked"],
            "block_rate": (
                round(self._stats["blocked"] / self._stats["checks"] * 100, 1)
                if self._stats["checks"] > 0 else 0.0
            ),
            "max_drift_ms": self.max_drift_ms,
            "tibet_tokens": len(self.provenance.chain()),
        }

    def export_audit(self) -> list[dict]:
        return self.provenance.chain()
