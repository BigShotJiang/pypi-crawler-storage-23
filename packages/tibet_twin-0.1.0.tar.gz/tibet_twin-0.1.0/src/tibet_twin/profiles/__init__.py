"""
Industry profiles for digital twin synchronicity.

Each profile defines typical sync requirements, sensor types,
and safety thresholds for a specific industry sector.
"""

from dataclasses import dataclass, field


@dataclass
class TwinProfile:
    name: str
    description: str
    sector: str
    max_drift_ms: float
    typical_sensors: list[str] = field(default_factory=list)
    safety_critical: bool = True
    compliance: list[str] = field(default_factory=list)
    typical_assets: list[str] = field(default_factory=list)
    notes: str = ""


_PROFILES: dict[str, TwinProfile] = {}


def _register(p: TwinProfile) -> None:
    _PROFILES[p.name] = p


def get_profile(name: str) -> TwinProfile:
    if name not in _PROFILES:
        raise ValueError(f"Unknown profile: {name}. Available: {list(_PROFILES.keys())}")
    return _PROFILES[name]


def list_profiles() -> list[str]:
    return list(_PROFILES.keys())


def all_profiles() -> list[TwinProfile]:
    return list(_PROFILES.values())


_register(TwinProfile(
    name="port",
    description="Port & harbor crane operations",
    sector="Maritime Logistics",
    max_drift_ms=200,
    typical_sensors=["position_x", "position_y", "height", "load_kg", "wind_speed"],
    safety_critical=True,
    compliance=["ISO 9001", "ISM Code", "NIS2", "ISPS"],
    typical_assets=["Container cranes (STS)", "RTG cranes", "AGVs", "reach stackers"],
    notes="Rotterdam, Antwerp, Hamburg — real-time crane control requires <200ms sync.",
))

_register(TwinProfile(
    name="manufacturing",
    description="Factory floor — CNC, robotics, assembly lines",
    sector="Manufacturing",
    max_drift_ms=100,
    typical_sensors=["spindle_rpm", "temperature", "vibration", "position", "torque"],
    safety_critical=True,
    compliance=["IEC 62443", "ISO 13849", "Machinery Directive 2006/42/EC"],
    typical_assets=["CNC machines", "Robot arms (KUKA/ABB/Fanuc)", "Conveyor systems", "AGVs"],
    notes="Robot arm collisions are fatal. <100ms sync is mandatory.",
))

_register(TwinProfile(
    name="energy",
    description="Power grid, wind turbines, solar farms",
    sector="Energy",
    max_drift_ms=500,
    typical_sensors=["power_mw", "frequency_hz", "voltage", "temperature", "wind_speed"],
    safety_critical=True,
    compliance=["IEC 61850", "NIS2", "NERC CIP", "TSO requirements"],
    typical_assets=["Wind turbines (Vestas/Siemens Gamesa)", "Solar inverters", "Substations", "BESS"],
    notes="Grid frequency sync is critical. 500ms is standard for SCADA polling.",
))

_register(TwinProfile(
    name="steel",
    description="Steel production — blast furnace, hot rolling",
    sector="Heavy Industry",
    max_drift_ms=300,
    typical_sensors=["temperature_c", "pressure_bar", "flow_rate", "thickness_mm", "speed_mps"],
    safety_critical=True,
    compliance=["IEC 62443", "NIS2", "Seveso III Directive"],
    typical_assets=["Blast furnaces", "Hot strip mills", "Continuous casters", "Ladle furnaces"],
    notes="Tata Steel IJmuiden: 1500°C processes. Twin desync = explosion risk.",
))

_register(TwinProfile(
    name="semiconductor",
    description="Chip fabrication — lithography, etching, deposition",
    sector="Semiconductor",
    max_drift_ms=50,
    typical_sensors=["wafer_position_nm", "temperature_c", "pressure_pa", "gas_flow", "dose_mj"],
    safety_critical=True,
    compliance=["SEMI S2", "ISO 14644", "ITAR (for defense chips)"],
    typical_assets=["ASML EUV lithography", "AMAT etch tools", "Lam Research CVD", "KLA inspection"],
    notes="ASML EUV requires nanometer precision. <50ms sync, sub-nm value tolerance.",
))

_register(TwinProfile(
    name="building",
    description="Smart building — HVAC, fire, access control",
    sector="Real Estate",
    max_drift_ms=5000,
    typical_sensors=["temperature", "humidity", "co2_ppm", "occupancy", "power_kw"],
    safety_critical=False,
    compliance=["EN 15232", "BREEAM", "LEED"],
    typical_assets=["HVAC systems", "Fire detection", "Access control", "Smart lighting"],
    notes="Non-safety-critical but energy efficiency requires reasonable sync.",
))
