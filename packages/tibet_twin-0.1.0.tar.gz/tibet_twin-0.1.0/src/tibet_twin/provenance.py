"""
TIBET provenance for digital twin sync decisions.

Every sync check, every block decision, every allowed action
is recorded as a TIBET token. The chain is the safety audit trail.
"""

import hashlib
import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class TwinToken:
    token_id: str
    timestamp: str
    action: str
    device_id: str
    intent: str
    allowed: bool
    erin: dict = field(default_factory=dict)
    eraan: dict = field(default_factory=dict)
    eromheen: dict = field(default_factory=dict)
    erachter: dict = field(default_factory=dict)
    parent_id: Optional[str] = None
    content_hash: str = ""

    def to_dict(self) -> dict:
        return {
            "token_id": self.token_id,
            "timestamp": self.timestamp,
            "type": "twin_sync",
            "action": self.action,
            "device_id": self.device_id,
            "intent": self.intent,
            "allowed": self.allowed,
            "erin": self.erin,
            "eraan": self.eraan,
            "eromheen": self.eromheen,
            "erachter": self.erachter,
            "parent_id": self.parent_id,
            "content_hash": self.content_hash,
        }


class TwinProvenance:
    def __init__(self, actor: str = "tibet-twin"):
        self.actor = actor
        self.tokens: list[TwinToken] = []
        self._last_id: str | None = None

    def create_token(
        self,
        action: str,
        device_id: str,
        intent: str,
        allowed: bool,
        details: dict | None = None,
    ) -> TwinToken:
        now = datetime.now(timezone.utc).isoformat()

        erin = {
            "action": action,
            "device_id": device_id,
            "intent": intent,
            "allowed": allowed,
            "details": details or {},
        }
        eraan = {"parent_token": self._last_id, "device_jis": f"jis:{device_id}"}
        eromheen = {
            "guard_node": os.uname().nodename,
            "timestamp": now,
            "actor": self.actor,
        }
        erachter = {
            "intent": f"Sync check: {intent} on {device_id}",
            "safety_critical": True,
            "decision": "ALLOW" if allowed else "BLOCK",
        }

        content = json.dumps({"erin": erin}, sort_keys=True)
        token_id = hashlib.sha256(f"{device_id}:{intent}:{now}".encode()).hexdigest()[:16]
        content_hash = hashlib.sha256(content.encode()).hexdigest()[:32]

        token = TwinToken(
            token_id=token_id,
            timestamp=now,
            action=action,
            device_id=device_id,
            intent=intent,
            allowed=allowed,
            erin=erin,
            eraan=eraan,
            eromheen=eromheen,
            erachter=erachter,
            parent_id=self._last_id,
            content_hash=content_hash,
        )
        self.tokens.append(token)
        self._last_id = token.token_id
        return token

    def chain(self) -> list[dict]:
        return [t.to_dict() for t in self.tokens]
