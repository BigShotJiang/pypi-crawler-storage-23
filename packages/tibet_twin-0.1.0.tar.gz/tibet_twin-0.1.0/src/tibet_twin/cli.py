"""
tibet-twin CLI — Digital Twin Synchronicity Guard.

Usage::

    tibet-twin info        Show concept and the deadly scenario
    tibet-twin demo        Interactive demo with crane scenario
    tibet-twin profiles    List industry profiles
"""

import argparse
import json
import sys
from datetime import datetime, timezone, timedelta

from .guard import SyncGuard
from .state import PhysicalState, TwinState
from .profiles import all_profiles


def cmd_info(args: argparse.Namespace) -> int:
    print()
    print("=" * 60)
    print("🏗️  TIBET-TWIN — Digital Twin Synchronicity Guard")
    print("=" * 60)
    print()
    print("The Problem: Physical ≠ Virtual")
    print("  Digital twins are virtual copies of physical machines.")
    print("  But there's ALWAYS latency between sensor and twin.")
    print("  If the twin authorizes an action based on stale data...")
    print()
    print("  The Deadly Scenario:")
    print("  ┌─────────────────┐     ┌──────────────┐")
    print("  │ Physical Crane   │     │ Digital Twin  │")
    print("  │ FAULT t=14:32:01 │     │ OK t=14:32:00 │")
    print("  │                  │     │ → GO command  │")
    print("  └─────────────────┘     └──────────────┘")
    print("         ↑                       ↑")
    print("    Reality (danger)      Model (stale = deadly)")
    print()
    print("How tibet-twin works:")
    print("  1. Physical state is reported by sensors")
    print("  2. Twin state is tracked by the model")
    print("  3. BEFORE any action: compute delta")
    print("  4. If drift > threshold OR status mismatch → BLOCK")
    print("  5. Every decision = TIBET token (audit trail)")
    print()
    print("  Other systems check: 'Is the data there?'")
    print("  tibet-twin checks:   'Is it the RIGHT data,")
    print("    from the RIGHT device, at the RIGHT time,")
    print("    and does the INTENT match the STATE?'")
    print()
    print("=" * 60)
    return 0


def cmd_demo(args: argparse.Namespace) -> int:
    print("\n🏗️  tibet-twin Demo: Port Crane Safety\n")

    guard = SyncGuard(
        max_drift_ms=200,
        value_tolerances={
            "crane-01": {"position_x": 0.5, "load_kg": 100.0},
        },
    )

    now = datetime.now(timezone.utc)

    # Scenario 1: In sync — action allowed
    print("  Scenario 1: Crane in sync\n")

    physical_1 = PhysicalState(
        device_id="crane-01",
        timestamp=(now - timedelta(milliseconds=50)).isoformat(),
        values={"position_x": 12.5, "position_y": 8.3, "load_kg": 2500.0},
        status="operational",
    )
    twin_1 = TwinState(
        device_id="crane-01",
        timestamp=now.isoformat(),
        values={"position_x": 12.5, "position_y": 8.3, "load_kg": 2500.0},
        status="operational",
    )

    guard.update_physical("crane-01", physical_1)
    guard.update_twin("crane-01", twin_1)

    decision_1 = guard.check("crane-01", intent="move_left")
    print(f"    Intent: move_left")
    print(f"    Drift:  {decision_1.delta.drift_ms}ms (max: 200ms)")
    print(f"    Result: {'✅ ALLOWED' if decision_1.allowed else '🚫 BLOCKED'}")
    print(f"    Reason: {decision_1.reason}")

    # Scenario 2: Out of sync — action BLOCKED
    print("\n  Scenario 2: Crane FAULT (twin doesn't know yet)\n")

    physical_2 = PhysicalState(
        device_id="crane-01",
        timestamp=(now + timedelta(seconds=1, milliseconds=3)).isoformat(),
        values={"position_x": 12.5, "position_y": 8.3, "load_kg": 2500.0},
        status="fault",  # FAULT!
    )
    twin_2 = TwinState(
        device_id="crane-01",
        timestamp=(now + timedelta(milliseconds=500)).isoformat(),
        values={"position_x": 12.5, "position_y": 8.3, "load_kg": 2500.0},
        status="operational",  # Still thinks OK!
    )

    guard.update_physical("crane-01", physical_2)
    guard.update_twin("crane-01", twin_2)

    decision_2 = guard.check("crane-01", intent="move_left")
    print(f"    Intent:   move_left")
    print(f"    Physical: status=FAULT at {physical_2.timestamp[-12:]}")
    print(f"    Twin:     status=OK    at {twin_2.timestamp[-12:]}")
    print(f"    Drift:    {decision_2.delta.drift_ms}ms")
    print(f"    Result:   {'✅ ALLOWED' if decision_2.allowed else '🚫 BLOCKED'}")
    print(f"    Reason:   {decision_2.reason}")

    # Scenario 3: Value deviation
    print("\n  Scenario 3: Sensor drift (load changed)\n")

    physical_3 = PhysicalState(
        device_id="crane-01",
        timestamp=(now + timedelta(seconds=2)).isoformat(),
        values={"position_x": 12.5, "position_y": 8.3, "load_kg": 3200.0},  # Load changed!
        status="operational",
    )
    twin_3 = TwinState(
        device_id="crane-01",
        timestamp=(now + timedelta(seconds=2, milliseconds=50)).isoformat(),
        values={"position_x": 12.5, "position_y": 8.3, "load_kg": 2500.0},  # Stale value
        status="operational",
    )

    guard.update_physical("crane-01", physical_3)
    guard.update_twin("crane-01", twin_3)

    decision_3 = guard.check("crane-01", intent="lift_container")
    print(f"    Intent:    lift_container")
    print(f"    Physical:  load_kg=3200 (changed!)")
    print(f"    Twin:      load_kg=2500 (stale)")
    print(f"    Delta:     {decision_3.delta.max_value_delta}kg on {decision_3.delta.max_delta_sensor}")
    print(f"    Result:    {'✅ ALLOWED' if decision_3.allowed else '🚫 BLOCKED'}")
    print(f"    Reason:    {decision_3.reason}")

    # Summary
    status = guard.status()
    print(f"\n  Guard Status:")
    print(f"    Checks: {status['checks']}")
    print(f"    Allowed: {status['allowed']}, Blocked: {status['blocked']}")
    print(f"    Block rate: {status['block_rate']}%")
    print(f"    TIBET tokens: {status['tibet_tokens']}")
    print()
    return 0


def cmd_profiles(args: argparse.Namespace) -> int:
    profiles = all_profiles()

    if args.json:
        data = [
            {
                "name": p.name,
                "sector": p.sector,
                "max_drift_ms": p.max_drift_ms,
                "safety_critical": p.safety_critical,
                "compliance": p.compliance,
            }
            for p in profiles
        ]
        print(json.dumps(data, indent=2))
    else:
        print()
        print(f"{'Profile':<16} {'Sector':<22} {'Max Drift':<12} {'Safety':<8} {'Compliance'}")
        print("-" * 90)
        for p in profiles:
            safety = "YES" if p.safety_critical else "no"
            compliance = ", ".join(p.compliance[:3])
            print(
                f"{p.name:<16} {p.sector:<22} {p.max_drift_ms:>6.0f}ms     "
                f"{safety:<8} {compliance}"
            )
        print()

    return 0


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="tibet-twin",
        description="Digital Twin Synchronicity Guard",
    )
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("info", help="Concept overview")
    sub.add_parser("demo", help="Interactive crane safety demo")
    p_prof = sub.add_parser("profiles", help="List industry profiles")
    p_prof.add_argument("-j", "--json", action="store_true")

    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)

    commands = {"info": cmd_info, "demo": cmd_demo, "profiles": cmd_profiles}
    sys.exit(commands[args.command](args))
