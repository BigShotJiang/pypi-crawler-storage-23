"""
State representation for physical and digital twin systems.

Physical state = what the real machine reports.
Twin state = what the digital model believes.
Delta = the difference that could kill.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional


@dataclass
class PhysicalState:
    """
    The state of a physical device/machine at a specific moment.

    This comes from real sensors, real hardware, real physics.
    """
    device_id: str
    timestamp: str  # ISO 8601 with timezone
    values: dict[str, float]  # sensor_name → value
    status: str = "operational"  # operational, fault, maintenance, emergency
    confidence: float = 1.0  # Sensor reliability (0.0-1.0)
    source: str = "sensor"  # sensor, manual, estimated

    @property
    def timestamp_dt(self) -> datetime:
        return datetime.fromisoformat(self.timestamp)

    def to_dict(self) -> dict:
        return {
            "device_id": self.device_id,
            "timestamp": self.timestamp,
            "values": self.values,
            "status": self.status,
            "confidence": self.confidence,
            "source": self.source,
        }


@dataclass
class TwinState:
    """
    The state of a digital twin at a specific moment.

    This is what the virtual model believes the physical system looks like.
    """
    device_id: str
    timestamp: str
    values: dict[str, float]
    status: str = "operational"
    model_version: str = "1.0"
    last_sync: str = ""  # When was this last synced with physical?
    predicted: bool = False  # Is this a prediction or a sync'd state?

    @property
    def timestamp_dt(self) -> datetime:
        return datetime.fromisoformat(self.timestamp)

    def to_dict(self) -> dict:
        return {
            "device_id": self.device_id,
            "timestamp": self.timestamp,
            "values": self.values,
            "status": self.status,
            "model_version": self.model_version,
            "last_sync": self.last_sync,
            "predicted": self.predicted,
        }


@dataclass
class StateDelta:
    """
    The difference between physical and twin state.

    This is where danger lives. A large delta means the twin
    doesn't know what the physical system is actually doing.
    """
    device_id: str
    drift_ms: float  # Time difference in milliseconds
    value_deltas: dict[str, float]  # sensor_name → absolute difference
    status_mismatch: bool  # Physical and twin disagree on status
    physical_status: str
    twin_status: str
    max_value_delta: float  # Largest value difference
    max_delta_sensor: str  # Which sensor has the largest delta
    synced: bool  # Are they in sync?
    timestamp: str = ""

    @property
    def safe(self) -> bool:
        """Is this delta within safe operating parameters?"""
        return self.synced and not self.status_mismatch

    def to_dict(self) -> dict:
        return {
            "device_id": self.device_id,
            "drift_ms": self.drift_ms,
            "value_deltas": self.value_deltas,
            "status_mismatch": self.status_mismatch,
            "physical_status": self.physical_status,
            "twin_status": self.twin_status,
            "max_value_delta": self.max_value_delta,
            "max_delta_sensor": self.max_delta_sensor,
            "synced": self.synced,
            "safe": self.safe,
        }


def compute_delta(
    physical: PhysicalState,
    twin: TwinState,
    max_drift_ms: float = 1000.0,
    max_value_tolerance: dict[str, float] | None = None,
) -> StateDelta:
    """
    Compute the delta between a physical state and its twin.

    Args:
        physical: The real physical state
        twin: The digital twin state
        max_drift_ms: Maximum allowed time drift in milliseconds
        max_value_tolerance: Per-sensor maximum allowed value difference

    Returns:
        StateDelta describing the gap between reality and model
    """
    tolerances = max_value_tolerance or {}

    # Calculate time drift
    p_dt = physical.timestamp_dt
    t_dt = twin.timestamp_dt
    drift = abs((p_dt - t_dt).total_seconds() * 1000)

    # Calculate value deltas
    all_sensors = set(physical.values.keys()) | set(twin.values.keys())
    value_deltas = {}
    max_delta = 0.0
    max_sensor = ""

    for sensor in all_sensors:
        p_val = physical.values.get(sensor, 0.0)
        t_val = twin.values.get(sensor, 0.0)
        delta = abs(p_val - t_val)
        value_deltas[sensor] = delta

        if delta > max_delta:
            max_delta = delta
            max_sensor = sensor

    # Check if within tolerance
    values_synced = True
    for sensor, delta in value_deltas.items():
        tolerance = tolerances.get(sensor, float("inf"))
        if delta > tolerance:
            values_synced = False
            break

    time_synced = drift <= max_drift_ms
    status_match = physical.status == twin.status

    return StateDelta(
        device_id=physical.device_id,
        drift_ms=round(drift, 3),
        value_deltas=value_deltas,
        status_mismatch=not status_match,
        physical_status=physical.status,
        twin_status=twin.status,
        max_value_delta=round(max_delta, 6),
        max_delta_sensor=max_sensor,
        synced=time_synced and values_synced and status_match,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )
