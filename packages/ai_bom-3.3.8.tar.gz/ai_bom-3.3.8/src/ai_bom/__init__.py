"""AI-BOM: AI Bill of Materials Discovery Scanner by Trusera."""

__version__ = "3.3.8"


def get_version() -> str:
    """Return the current ai-bom version string."""
    return __version__
