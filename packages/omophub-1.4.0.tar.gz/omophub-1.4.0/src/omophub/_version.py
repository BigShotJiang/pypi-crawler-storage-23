"""Version information for the OMOPHub SDK."""

__version__ = "0.1.0"


def get_version() -> str:
    """Return the current SDK version."""
    return __version__
