#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Shared pytest fixtures for bitbake_project tests.
"""

import json
import os
import subprocess
from datetime import datetime
from typing import Dict
from unittest.mock import MagicMock, patch

import pytest


@pytest.fixture
def temp_git_repo(tmp_path):
    """
    Create a temporary git repository with initial commit.

    Returns the path to the repository.
    """
    repo_path = tmp_path / "test_repo"
    repo_path.mkdir()

    # Initialize git repo
    subprocess.run(["git", "init"], cwd=repo_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.email", "test@test.com"],
        cwd=repo_path, check=True, capture_output=True
    )
    subprocess.run(
        ["git", "config", "user.name", "Test User"],
        cwd=repo_path, check=True, capture_output=True
    )

    # Create initial commit
    readme = repo_path / "README.md"
    readme.write_text("# Test Repo\n")
    subprocess.run(["git", "add", "README.md"], cwd=repo_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "Initial commit"],
        cwd=repo_path, check=True, capture_output=True
    )

    return repo_path


@pytest.fixture
def temp_git_repo_with_remote(temp_git_repo, tmp_path):
    """
    Create a git repository with a simulated remote (origin).

    Returns tuple of (repo_path, remote_path).
    """
    remote_path = tmp_path / "remote_repo"

    # Create a bare repo as "remote"
    subprocess.run(["git", "clone", "--bare", str(temp_git_repo), str(remote_path)],
                   check=True, capture_output=True)

    # Add as origin
    subprocess.run(
        ["git", "remote", "add", "origin", str(remote_path)],
        cwd=temp_git_repo, check=True, capture_output=True
    )

    # Fetch to set up tracking
    subprocess.run(
        ["git", "fetch", "origin"],
        cwd=temp_git_repo, check=True, capture_output=True
    )

    # Set upstream
    subprocess.run(
        ["git", "branch", "--set-upstream-to=origin/master", "master"],
        cwd=temp_git_repo, capture_output=True  # May fail if branch is main
    )
    subprocess.run(
        ["git", "branch", "--set-upstream-to=origin/main", "main"],
        cwd=temp_git_repo, capture_output=True  # May fail if branch is master
    )

    return temp_git_repo, remote_path


@pytest.fixture
def temp_git_repo_with_contrib_remote(temp_git_repo_with_remote, tmp_path):
    """
    Create a git repo with an additional 'contrib' remote and a branch tracking it.
    Returns tuple of (repo_path, origin_path, contrib_path).
    """
    repo_path, origin_path = temp_git_repo_with_remote

    # Create a second bare repo as "contrib" remote
    contrib_path = tmp_path / "contrib_repo"
    subprocess.run(["git", "clone", "--bare", str(repo_path), str(contrib_path)],
                   check=True, capture_output=True)
    subprocess.run(["git", "remote", "add", "contrib", str(contrib_path)],
                   cwd=repo_path, check=True, capture_output=True)
    subprocess.run(["git", "fetch", "contrib"],
                   cwd=repo_path, check=True, capture_output=True)

    # Determine current branch name
    result = subprocess.run(
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
        cwd=repo_path, check=True, capture_output=True, text=True,
    )
    current = result.stdout.strip()

    # Create a branch tracking the contrib remote
    subprocess.run(
        ["git", "checkout", "-b", "feature-branch", "--track", f"contrib/{current}"],
        cwd=repo_path, check=True, capture_output=True,
    )

    return repo_path, origin_path, contrib_path


@pytest.fixture
def temp_bblayers(tmp_path):
    """
    Create temporary bblayers.conf with test layers.

    Returns tuple of (bblayers_path, layers_dict) where layers_dict
    contains the created layer directories.
    """
    # Create build/conf structure
    conf_dir = tmp_path / "build" / "conf"
    conf_dir.mkdir(parents=True)

    # Create some layer directories
    layers_dir = tmp_path / "layers"
    layers_dir.mkdir()

    layers = {}
    for layer_name in ["meta", "meta-poky", "meta-custom"]:
        layer_path = layers_dir / layer_name
        layer_path.mkdir()
        layer_conf = layer_path / "conf"
        layer_conf.mkdir()
        (layer_conf / "layer.conf").write_text(f'BBFILE_COLLECTIONS += "{layer_name}"\n')
        layers[layer_name] = layer_path

    # Write bblayers.conf
    bblayers_path = conf_dir / "bblayers.conf"
    bblayers_content = f'''# Build configuration
LCONF_VERSION = "7"

BBPATH = "${{TOPDIR}}"
BBFILES ?= ""

BBLAYERS ?= " \\
    {layers_dir}/meta \\
    {layers_dir}/meta-poky \\
    {layers_dir}/meta-custom \\
"
'''
    bblayers_path.write_text(bblayers_content)

    return bblayers_path, layers


@pytest.fixture
def temp_bblayers_simple(tmp_path):
    """
    Create a minimal bblayers.conf for simple parsing tests.

    Returns the path to bblayers.conf.
    """
    conf_dir = tmp_path / "conf"
    conf_dir.mkdir()

    bblayers_path = conf_dir / "bblayers.conf"
    bblayers_path.write_text('''BBLAYERS = "/path/to/layer1 /path/to/layer2"
''')

    return bblayers_path


@pytest.fixture
def temp_defaults(tmp_path):
    """
    Create a temporary .bit.defaults file.

    Returns tuple of (defaults_path, initial_data).
    """
    defaults_path = tmp_path / ".bit.defaults"
    initial_data = {
        "repo1": "rebase",
        "repo2": "skip",
        "fzf_theme": "dark",
        "menu_sort": "category",
    }
    defaults_path.write_text(json.dumps(initial_data, indent=2))

    return defaults_path, initial_data


@pytest.fixture
def temp_prep_state(tmp_path):
    """
    Create a temporary prep state file.

    Returns tuple of (state_path, initial_data).
    """
    state_path = tmp_path / ".bit.prep-state.json"
    initial_data = {
        "timestamp": datetime.now().isoformat(),
        "repos": {
            "/path/to/repo1": {
                "branch": "master",
                "commits": ["abc123", "def456"],
            }
        }
    }
    state_path.write_text(json.dumps(initial_data, indent=2))

    return state_path, initial_data


@pytest.fixture
def temp_export_state(tmp_path):
    """
    Create a temporary export state file.

    Returns tuple of (state_path, initial_data).
    """
    state_path = tmp_path / ".bit.export-state.json"
    initial_data = {
        "/path/to/repo1": {
            "head": "abc123",
            "action": "include",
        },
        "/path/to/repo2": {
            "head": "def456",
            "action": "skip",
        }
    }
    state_path.write_text(json.dumps(initial_data, indent=2))

    return state_path, initial_data


@pytest.fixture
def mock_fzf(mocker):
    """
    Mock fzf availability and subprocess calls.

    Returns a dict with mock objects that can be configured:
    - available: Control whether fzf is "installed"
    - selection: What fzf returns when run
    """
    mock_state = {
        "available": True,
        "selection": None,
        "return_code": 0,
    }

    def mock_which(cmd):
        if cmd == "fzf":
            return "/usr/bin/fzf" if mock_state["available"] else None
        return None

    def mock_run(args, **kwargs):
        result = MagicMock()
        if args and args[0] == "fzf":
            result.returncode = mock_state["return_code"]
            result.stdout = mock_state["selection"] or ""
        else:
            result.returncode = 0
            result.stdout = ""
        return result

    mocker.patch("shutil.which", side_effect=mock_which)
    mocker.patch("subprocess.run", side_effect=mock_run)

    return mock_state


@pytest.fixture
def mock_subprocess(mocker):
    """
    Mock subprocess for GitRepo tests.

    Returns a configurable mock that can return different outputs
    for different git commands.
    """
    mock_state = {
        "outputs": {},  # command -> output mapping
        "return_codes": {},  # command -> return code mapping
    }

    def mock_check_output(args, **kwargs):
        cmd = " ".join(args)
        for pattern, output in mock_state["outputs"].items():
            if pattern in cmd:
                return output
        return ""

    def mock_run(args, **kwargs):
        cmd = " ".join(args)
        result = MagicMock()
        result.returncode = 0
        result.stdout = ""

        for pattern, output in mock_state["outputs"].items():
            if pattern in cmd:
                result.stdout = output
                break

        for pattern, rc in mock_state["return_codes"].items():
            if pattern in cmd:
                result.returncode = rc
                if kwargs.get("check") and rc != 0:
                    raise subprocess.CalledProcessError(rc, args)
                break

        return result

    mocker.patch("subprocess.check_output", side_effect=mock_check_output)
    mocker.patch("subprocess.run", side_effect=mock_run)

    return mock_state


@pytest.fixture
def clean_environment(tmp_path, monkeypatch):
    """
    Set up a clean environment for CLI tests.

    Changes to tmp_path and sets up minimal environment.
    """
    original_cwd = os.getcwd()
    monkeypatch.chdir(tmp_path)

    yield tmp_path

    os.chdir(original_cwd)
