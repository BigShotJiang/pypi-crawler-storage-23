#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for state management functions."""

import json
import os
from datetime import datetime

import pytest

from bitbake_project.core import (
    load_defaults,
    save_defaults,
    load_prep_state,
    save_prep_state,
    load_export_state,
    save_export_state,
)


class TestLoadDefaults:
    """Tests for load_defaults function."""

    def test_load_nonexistent_file(self, tmp_path):
        """Loading nonexistent file returns empty dict."""
        result = load_defaults(str(tmp_path / "nonexistent.json"))
        assert result == {}

    def test_load_valid_file(self, tmp_path):
        """Loading valid JSON file returns data."""
        defaults_file = tmp_path / ".bit.defaults"
        data = {"repo1": "rebase", "repo2": "skip"}
        defaults_file.write_text(json.dumps(data))

        result = load_defaults(str(defaults_file))
        assert result == {"repo1": "rebase", "repo2": "skip"}

    def test_load_corrupted_file(self, tmp_path):
        """Loading corrupted JSON returns empty dict."""
        defaults_file = tmp_path / ".bit.defaults"
        defaults_file.write_text("not valid json {{{")

        result = load_defaults(str(defaults_file))
        assert result == {}

    def test_converts_values_to_strings(self, tmp_path):
        """Values are converted to strings."""
        defaults_file = tmp_path / ".bit.defaults"
        data = {"repo1": 123, "repo2": True}
        defaults_file.write_text(json.dumps(data))

        result = load_defaults(str(defaults_file))
        assert result["repo1"] == "123"
        assert result["repo2"] == "True"

    def test_preserves_extra_repos_list(self, tmp_path):
        """Special __extra_repos__ key is preserved as list."""
        defaults_file = tmp_path / ".bit.defaults"
        data = {
            "repo1": "rebase",
            "__extra_repos__": ["/path/to/extra1", "/path/to/extra2"],
        }
        defaults_file.write_text(json.dumps(data))

        result = load_defaults(str(defaults_file))
        assert result["__extra_repos__"] == ["/path/to/extra1", "/path/to/extra2"]

    def test_preserves_hidden_repos_list(self, tmp_path):
        """Special __hidden_repos__ key is preserved as list."""
        defaults_file = tmp_path / ".bit.defaults"
        data = {
            "repo1": "rebase",
            "__hidden_repos__": ["/path/to/hidden"],
        }
        defaults_file.write_text(json.dumps(data))

        result = load_defaults(str(defaults_file))
        assert result["__hidden_repos__"] == ["/path/to/hidden"]

    def test_preserves_push_targets_dict(self, tmp_path):
        """Special __push_targets__ key is preserved as dict."""
        defaults_file = tmp_path / ".bit.defaults"
        data = {
            "repo1": "rebase",
            "__push_targets__": {"repo1": "upstream"},
        }
        defaults_file.write_text(json.dumps(data))

        result = load_defaults(str(defaults_file))
        assert result["__push_targets__"] == {"repo1": "upstream"}


class TestSaveDefaults:
    """Tests for save_defaults function."""

    def test_save_creates_file(self, tmp_path):
        """Saving creates a new file."""
        defaults_file = tmp_path / ".bit.defaults"
        data = {"repo1": "rebase"}

        save_defaults(str(defaults_file), data)

        assert defaults_file.exists()
        loaded = json.loads(defaults_file.read_text())
        assert loaded["repo1"] == "rebase"

    def test_save_overwrites_existing(self, tmp_path):
        """Saving overwrites existing file."""
        defaults_file = tmp_path / ".bit.defaults"
        defaults_file.write_text(json.dumps({"old": "data"}))

        save_defaults(str(defaults_file), {"new": "data"})

        loaded = json.loads(defaults_file.read_text())
        assert "old" not in loaded
        assert loaded["new"] == "data"

    def test_save_is_formatted(self, tmp_path):
        """Saved JSON is indented."""
        defaults_file = tmp_path / ".bit.defaults"
        save_defaults(str(defaults_file), {"a": "1", "b": "2"})

        content = defaults_file.read_text()
        assert "\n" in content  # Has newlines
        assert "  " in content  # Has indentation

    def test_save_sorts_keys(self, tmp_path):
        """Saved JSON has sorted keys."""
        defaults_file = tmp_path / ".bit.defaults"
        save_defaults(str(defaults_file), {"z": "1", "a": "2", "m": "3"})

        content = defaults_file.read_text()
        # a should come before m which should come before z
        assert content.index('"a"') < content.index('"m"') < content.index('"z"')


class TestLoadPrepState:
    """Tests for load_prep_state function."""

    def test_load_nonexistent_file(self, tmp_path):
        """Loading nonexistent file returns None."""
        result = load_prep_state(str(tmp_path / "nonexistent.json"))
        assert result is None

    def test_load_valid_state(self, tmp_path):
        """Loading valid prep state returns data."""
        state_file = tmp_path / ".bit.prep-state.json"
        data = {
            "timestamp": "2025-01-01T12:00:00",
            "repos": {
                "/path/to/repo": {
                    "branch": "master",
                    "commits": ["abc123"],
                }
            }
        }
        state_file.write_text(json.dumps(data))

        result = load_prep_state(str(state_file))
        assert result is not None
        assert "repos" in result
        assert "/path/to/repo" in result["repos"]

    def test_load_missing_repos_key(self, tmp_path):
        """State without repos key returns None."""
        state_file = tmp_path / ".bit.prep-state.json"
        state_file.write_text(json.dumps({"timestamp": "2025-01-01"}))

        result = load_prep_state(str(state_file))
        assert result is None

    def test_load_corrupted_file(self, tmp_path):
        """Corrupted file returns None."""
        state_file = tmp_path / ".bit.prep-state.json"
        state_file.write_text("invalid json")

        result = load_prep_state(str(state_file))
        assert result is None


class TestSavePrepState:
    """Tests for save_prep_state function."""

    def test_save_creates_file(self, tmp_path):
        """Saving creates a new file."""
        state_file = tmp_path / ".bit.prep-state.json"
        repos_data = {
            "/path/to/repo": {
                "branch": "master",
                "commits": ["abc123"],
            }
        }

        save_prep_state(str(state_file), repos_data)

        assert state_file.exists()

    def test_save_adds_timestamp(self, tmp_path):
        """Saved state includes timestamp."""
        state_file = tmp_path / ".bit.prep-state.json"
        save_prep_state(str(state_file), {})

        loaded = json.loads(state_file.read_text())
        assert "timestamp" in loaded
        # Verify it's a valid ISO format
        datetime.fromisoformat(loaded["timestamp"])

    def test_save_includes_repos(self, tmp_path):
        """Saved state includes repos data."""
        state_file = tmp_path / ".bit.prep-state.json"
        repos_data = {"/path/to/repo": {"branch": "master"}}

        save_prep_state(str(state_file), repos_data)

        loaded = json.loads(state_file.read_text())
        assert loaded["repos"] == repos_data


class TestLoadExportState:
    """Tests for load_export_state function."""

    def test_load_nonexistent_file(self, tmp_path):
        """Loading nonexistent file returns empty dict."""
        result = load_export_state(str(tmp_path / "nonexistent.json"))
        assert result == {}

    def test_load_valid_state(self, tmp_path):
        """Loading valid export state returns data."""
        state_file = tmp_path / ".bit.export-state.json"
        data = {
            "/path/to/repo1": {"head": "abc123", "action": "include"},
            "/path/to/repo2": {"head": "def456", "action": "skip"},
        }
        state_file.write_text(json.dumps(data))

        result = load_export_state(str(state_file))
        assert result == data

    def test_load_corrupted_file(self, tmp_path):
        """Corrupted file returns empty dict."""
        state_file = tmp_path / ".bit.export-state.json"
        state_file.write_text("invalid json")

        result = load_export_state(str(state_file))
        assert result == {}


class TestSaveExportState:
    """Tests for save_export_state function."""

    def test_save_creates_file(self, tmp_path):
        """Saving creates a new file."""
        state_file = tmp_path / ".bit.export-state.json"
        state = {"/path/to/repo": {"head": "abc123", "action": "include"}}

        save_export_state(str(state_file), state)

        assert state_file.exists()

    def test_save_is_formatted(self, tmp_path):
        """Saved JSON is indented."""
        state_file = tmp_path / ".bit.export-state.json"
        save_export_state(str(state_file), {"a": {"x": "1"}})

        content = state_file.read_text()
        assert "\n" in content

    def test_save_sorts_keys(self, tmp_path):
        """Saved JSON has sorted keys."""
        state_file = tmp_path / ".bit.export-state.json"
        save_export_state(str(state_file), {
            "/z/path": {},
            "/a/path": {},
        })

        content = state_file.read_text()
        assert content.index("/a/path") < content.index("/z/path")

    def test_roundtrip(self, tmp_path):
        """Data survives save/load roundtrip."""
        state_file = tmp_path / ".bit.export-state.json"
        original = {
            "/path/to/repo1": {"head": "abc123", "action": "include"},
            "/path/to/repo2": {"head": "def456", "action": "skip"},
        }

        save_export_state(str(state_file), original)
        loaded = load_export_state(str(state_file))

        assert loaded == original
