#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for pure helper functions."""

import json
import os

import pytest

from bitbake_project.commands.common import clean_title, dedupe_preserve_order
from bitbake_project.cli import (
    get_menu_sort_mode,
    set_menu_sort_mode,
    sort_commands_by_mode,
    COMMAND_TREE,
    COMMAND_CATEGORIES,
    CATEGORY_ORDER,
    INTERACTION_CATEGORIES,
    INTERACTION_ORDER,
)


class TestCleanTitle:
    """Tests for clean_title function."""

    def test_plain_title(self):
        """Title without brackets passes through."""
        assert clean_title("Fix memory leak in parser") == "Fix memory leak in parser"

    def test_strip_single_patch_bracket(self):
        """Single [PATCH] bracket is removed."""
        assert clean_title("[PATCH] Fix memory leak") == "Fix memory leak"

    def test_strip_patch_series_bracket(self):
        """[PATCH 1/5] style bracket is removed."""
        assert clean_title("[PATCH 1/5] Add new feature") == "Add new feature"

    def test_strip_repo_bracket(self):
        """[repo-name] bracket is removed."""
        assert clean_title("[OE-core] Update recipe") == "Update recipe"

    def test_strip_multiple_brackets(self):
        """Multiple brackets are removed."""
        assert clean_title("[PATCH 2/3][OE-core] Fix build") == "Fix build"

    def test_strip_nested_style_brackets(self):
        """Various bracket formats are handled."""
        assert clean_title("[v2][PATCH 1/2] Update docs") == "Update docs"

    def test_preserve_brackets_in_title(self):
        """Brackets in the actual title are preserved."""
        result = clean_title("[PATCH] Handle [array] notation")
        assert result == "Handle [array] notation"

    def test_empty_string(self):
        """Empty string returns empty."""
        assert clean_title("") == ""

    def test_whitespace_handling(self):
        """Leading/trailing whitespace is stripped."""
        assert clean_title("  [PATCH] Title  ") == "Title"


class TestDedupePreserveOrder:
    """Tests for dedupe_preserve_order function."""

    def test_no_duplicates(self):
        """List without duplicates passes through."""
        result = dedupe_preserve_order(["a", "b", "c"])
        assert result == ["a", "b", "c"]

    def test_with_duplicates(self):
        """Duplicates are removed, first occurrence kept."""
        result = dedupe_preserve_order(["a", "b", "a", "c", "b"])
        assert result == ["a", "b", "c"]

    def test_empty_list(self):
        """Empty list returns empty list."""
        result = dedupe_preserve_order([])
        assert result == []

    def test_all_same(self):
        """All same elements returns single element."""
        result = dedupe_preserve_order(["x", "x", "x"])
        assert result == ["x"]

    def test_preserves_order(self):
        """First occurrence position is preserved."""
        result = dedupe_preserve_order(["z", "a", "m", "z", "a"])
        assert result == ["z", "a", "m"]

    def test_generator_input(self):
        """Works with generator input."""
        def gen():
            yield "a"
            yield "b"
            yield "a"
        result = dedupe_preserve_order(gen())
        assert result == ["a", "b"]

    def test_tuple_input(self):
        """Works with tuple input."""
        result = dedupe_preserve_order(("a", "b", "a"))
        assert result == ["a", "b"]


class TestSortCommandsByMode:
    """Tests for sort_commands_by_mode function."""

    @pytest.fixture
    def sample_commands(self):
        """Sample command list for testing."""
        return [
            ("explore", "Explore commits", []),
            ("config", "Configure settings", [("config edit", "Edit config")]),
            ("branch", "Manage branches", []),
            ("help", "Show help", []),
            ("status", "Show status", []),
        ]

    def test_alpha_mode_sorts_alphabetically(self, sample_commands):
        """Alpha mode sorts commands by name."""
        sorted_cmds, categories = sort_commands_by_mode(sample_commands, "alpha")

        assert categories is None
        names = [cmd[0] for cmd in sorted_cmds]
        assert names == ["branch", "config", "explore", "help", "status"]

    def test_category_mode_groups_by_category(self, sample_commands):
        """Category mode groups commands with headers."""
        sorted_cmds, categories = sort_commands_by_mode(sample_commands, "category")

        # Should have category markers for first command in each group
        assert categories is not None
        # Check that at least one category is assigned
        assert len(categories) > 0

    def test_interactive_mode_uses_interaction_categories(self, sample_commands):
        """Interactive mode uses interaction-based grouping."""
        sorted_cmds, categories = sort_commands_by_mode(sample_commands, "interactive")

        assert categories is not None

    def test_preserves_subcommands(self, sample_commands):
        """Subcommands are preserved in sorted output."""
        sorted_cmds, _ = sort_commands_by_mode(sample_commands, "alpha")

        config_cmd = next((c for c in sorted_cmds if c[0] == "config"), None)
        assert config_cmd is not None
        assert len(config_cmd[2]) == 1
        assert config_cmd[2][0][0] == "config edit"


class TestMenuSortModeSettings:
    """Tests for get/set_menu_sort_mode."""

    def test_get_default_mode(self, tmp_path):
        """Default mode is 'category' when no file exists."""
        nonexistent = str(tmp_path / "nonexistent.json")
        result = get_menu_sort_mode(nonexistent)
        assert result == "category"

    def test_get_saved_mode(self, tmp_path):
        """Reads saved mode from file."""
        defaults_file = tmp_path / ".bit.defaults"
        defaults_file.write_text(json.dumps({"menu_sort": "alpha"}))

        result = get_menu_sort_mode(str(defaults_file))
        assert result == "alpha"

    def test_set_mode_creates_file(self, tmp_path):
        """Setting mode creates file if not exists."""
        defaults_file = tmp_path / ".bit.defaults"

        result = set_menu_sort_mode("interactive", str(defaults_file))
        assert result is True
        assert defaults_file.exists()

        data = json.loads(defaults_file.read_text())
        assert data["menu_sort"] == "interactive"

    def test_set_mode_preserves_other_data(self, tmp_path):
        """Setting mode preserves other data in file."""
        defaults_file = tmp_path / ".bit.defaults"
        defaults_file.write_text(json.dumps({"other_key": "value"}))

        set_menu_sort_mode("alpha", str(defaults_file))

        data = json.loads(defaults_file.read_text())
        assert data["menu_sort"] == "alpha"
        assert data["other_key"] == "value"

    def test_set_invalid_mode_returns_false(self, tmp_path):
        """Setting invalid mode returns False."""
        defaults_file = tmp_path / ".bit.defaults"

        result = set_menu_sort_mode("invalid_mode", str(defaults_file))
        assert result is False

    def test_valid_modes(self, tmp_path):
        """All valid modes can be set."""
        defaults_file = tmp_path / ".bit.defaults"

        for mode in ["category", "alpha", "interactive"]:
            result = set_menu_sort_mode(mode, str(defaults_file))
            assert result is True

            saved = get_menu_sort_mode(str(defaults_file))
            assert saved == mode

    def test_corrupted_file_returns_default(self, tmp_path):
        """Corrupted JSON returns default mode."""
        defaults_file = tmp_path / ".bit.defaults"
        defaults_file.write_text("not valid json")

        result = get_menu_sort_mode(str(defaults_file))
        assert result == "category"
