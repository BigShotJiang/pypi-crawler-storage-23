#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for update command - upstream tracking support."""

import subprocess

import pytest

from bitbake_project.core import current_branch
from bitbake_project.commands.update import get_pull_args, fetch_repo


class TestGetPullArgs:
    """Tests for get_pull_args() upstream tracking."""

    def test_origin_tracking_uses_explicit_args(self, temp_git_repo_with_remote):
        """When tracking origin, uses explicit origin/{branch}."""
        repo_path, _ = temp_git_repo_with_remote
        branch = current_branch(str(repo_path))
        cmd, desc = get_pull_args(str(repo_path), branch, rebase=True)
        assert "origin" in cmd
        assert branch in cmd
        assert f"origin/{branch}" in desc

    def test_nonorigin_tracking_uses_bare_pull(self, temp_git_repo_with_contrib_remote):
        """When tracking non-origin remote, uses bare pull."""
        repo_path, _, _ = temp_git_repo_with_contrib_remote
        cmd, desc = get_pull_args(str(repo_path), "feature-branch", rebase=True)
        # Should NOT have origin in command args
        assert "origin" not in cmd
        # Should mention tracking info in description
        assert "contrib" in desc

    def test_rebase_flag(self, temp_git_repo_with_remote):
        """Rebase flag is included in command."""
        repo_path, _ = temp_git_repo_with_remote
        branch = current_branch(str(repo_path))
        cmd, desc = get_pull_args(str(repo_path), branch, rebase=True)
        assert "--rebase" in cmd
        assert "rebase" in desc

    def test_merge_no_rebase(self, temp_git_repo_with_remote):
        """Merge mode omits --rebase."""
        repo_path, _ = temp_git_repo_with_remote
        branch = current_branch(str(repo_path))
        cmd, desc = get_pull_args(str(repo_path), branch, rebase=False)
        assert "--rebase" not in cmd

    def test_nonorigin_merge_uses_bare_pull(self, temp_git_repo_with_contrib_remote):
        """Non-origin merge also uses bare pull."""
        repo_path, _, _ = temp_git_repo_with_contrib_remote
        cmd, desc = get_pull_args(str(repo_path), "feature-branch", rebase=False)
        assert "origin" not in cmd
        assert "--rebase" not in cmd
        assert "contrib" in desc


class TestFetchRepo:
    """Tests for fetch_repo() remote detection."""

    def test_fetch_origin(self, temp_git_repo_with_remote):
        """Fetches from origin for standard tracking."""
        repo_path, _ = temp_git_repo_with_remote
        result = fetch_repo(str(repo_path))
        assert result is True

    def test_fetch_contrib_remote(self, temp_git_repo_with_contrib_remote):
        """Fetches from contrib when branch tracks contrib."""
        repo_path, _, _ = temp_git_repo_with_contrib_remote
        result = fetch_repo(str(repo_path))
        assert result is True
