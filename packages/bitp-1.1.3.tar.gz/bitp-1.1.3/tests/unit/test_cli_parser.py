#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for CLI argument parsing."""

import pytest

from bitbake_project.cli import build_parser, COMMAND_TREE, COMMANDS


class TestBuildParser:
    """Tests for build_parser function."""

    @pytest.fixture
    def parser(self):
        """Create a fresh parser for each test."""
        parser, _ = build_parser()
        return parser

    def test_parser_created(self, parser):
        """Parser is successfully created."""
        assert parser is not None

    def test_completion_flag(self, parser):
        """--completion flag is recognized."""
        args = parser.parse_args(["--completion"])
        assert args.completion is True

    def test_bblayers_option(self, parser):
        """--bblayers option is recognized."""
        args = parser.parse_args(["--bblayers", "/path/to/bblayers.conf", "status"])
        assert args.bblayers == "/path/to/bblayers.conf"

    def test_defaults_file_option(self, parser):
        """--defaults-file option is recognized."""
        args = parser.parse_args(["--defaults-file", "/path/to/.defaults", "status"])
        assert args.defaults_file == "/path/to/.defaults"

    def test_all_flag(self, parser):
        """--all / -a flag is recognized."""
        args = parser.parse_args(["--all", "status"])
        assert args.all is True

        args = parser.parse_args(["-a", "status"])
        assert args.all is True


class TestUpdateCommand:
    """Tests for 'update' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_update_basic(self, parser):
        """Basic update command."""
        args = parser.parse_args(["update"])
        assert args.command == "update"

    def test_update_alias(self, parser):
        """'u' alias for update."""
        args = parser.parse_args(["u"])
        assert args.command == "u"

    def test_update_with_repo(self, parser):
        """Update with specific repo."""
        args = parser.parse_args(["update", "meta-oe"])
        assert args.repo == "meta-oe"

    def test_update_dry_run(self, parser):
        """Update with --dry-run."""
        args = parser.parse_args(["update", "--dry-run"])
        assert args.dry_run is True

    def test_update_resume(self, parser):
        """Update with --resume."""
        args = parser.parse_args(["update", "--resume"])
        assert args.resume is True

    def test_update_resume_file(self, parser):
        """Update with custom resume file."""
        args = parser.parse_args(["update", "--resume-file", "custom.resume"])
        assert args.resume_file == "custom.resume"


class TestExploreCommand:
    """Tests for 'explore' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_explore_basic(self, parser):
        """Basic explore command."""
        args = parser.parse_args(["explore"])
        assert args.command == "explore"

    def test_explore_alias(self, parser):
        """'x' alias for explore."""
        args = parser.parse_args(["x"])
        assert args.command == "x"

    def test_explore_with_repo(self, parser):
        """Explore specific repo."""
        args = parser.parse_args(["explore", "OE-core"])
        assert args.repo == "OE-core"

    def test_explore_status_flag(self, parser):
        """Explore with --status flag."""
        args = parser.parse_args(["explore", "--status"])
        assert args.status is True

    def test_explore_verbose(self, parser):
        """Explore with -v flag."""
        args = parser.parse_args(["explore", "-v"])
        assert args.verbose == 1

        args = parser.parse_args(["explore", "-vv"])
        assert args.verbose == 2

    def test_explore_refresh(self, parser):
        """Explore with --refresh."""
        args = parser.parse_args(["explore", "--refresh"])
        assert args.refresh is True


class TestConfigCommand:
    """Tests for 'config' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_config_basic(self, parser):
        """Basic config command."""
        args = parser.parse_args(["config"])
        assert args.command == "config"

    def test_config_alias(self, parser):
        """'c' alias for config."""
        args = parser.parse_args(["c"])
        assert args.command == "c"

    def test_config_with_repo(self, parser):
        """Config for specific repo."""
        args = parser.parse_args(["config", "1"])
        assert args.repo == "1"

    def test_config_display_name(self, parser):
        """Config with --display-name."""
        args = parser.parse_args(["config", "1", "--display-name", "MyRepo"])
        assert args.display_name == "MyRepo"

    def test_config_update_default(self, parser):
        """Config with --update-default."""
        args = parser.parse_args(["config", "1", "--update-default", "rebase"])
        assert args.update_default == "rebase"


class TestBranchCommand:
    """Tests for 'branch' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_branch_basic(self, parser):
        """Basic branch command."""
        args = parser.parse_args(["branch"])
        assert args.command == "branch"

    def test_branch_alias(self, parser):
        """'b' alias for branch."""
        args = parser.parse_args(["b"])
        assert args.command == "b"

    def test_branch_with_repo_and_target(self, parser):
        """Branch with repo and target branch."""
        args = parser.parse_args(["branch", "1", "kirkstone"])
        assert args.repo == "1"
        assert args.target_branch == "kirkstone"

    def test_branch_all_repos(self, parser):
        """Branch with --all flag."""
        args = parser.parse_args(["branch", "--all", "kirkstone"])
        assert args.all_repos is True
        assert args.repo == "kirkstone"


class TestDepsCommand:
    """Tests for 'deps' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_deps_basic(self, parser):
        """Basic deps command."""
        args = parser.parse_args(["deps"])
        assert args.command == "deps"

    def test_deps_alias(self, parser):
        """'d' alias for deps."""
        args = parser.parse_args(["d"])
        assert args.command == "d"

    def test_deps_layers(self, parser):
        """Deps layers subcommand."""
        args = parser.parse_args(["deps", "layers"])
        assert args.deps_command == "layers"

    def test_deps_layers_with_layer(self, parser):
        """Deps layers with specific layer."""
        args = parser.parse_args(["deps", "layers", "meta-oe"])
        assert args.layer == "meta-oe"

    def test_deps_layers_reverse(self, parser):
        """Deps layers with --reverse."""
        args = parser.parse_args(["deps", "layers", "--reverse", "meta-oe"])
        assert args.reverse is True


class TestExportCommand:
    """Tests for 'export' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_export_basic(self, parser):
        """Basic export command."""
        args = parser.parse_args(["export", "--target-dir", "/tmp/patches"])
        assert args.command == "export"
        assert args.target_dir == "/tmp/patches"

    def test_export_layout(self, parser):
        """Export with --layout."""
        args = parser.parse_args(["export", "--target-dir", "/tmp", "--layout", "per-repo"])
        assert args.layout == "per-repo"

    def test_export_pick(self, parser):
        """Export with --pick."""
        args = parser.parse_args(["export", "--target-dir", "/tmp", "--pick"])
        assert args.pick is True

    def test_export_prep_subcommand(self, parser):
        """Export prep subcommand."""
        args = parser.parse_args(["export", "prep"])
        assert args.export_command == "prep"


class TestProjectsCommand:
    """Tests for 'projects' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_projects_basic(self, parser):
        """Basic projects command."""
        args = parser.parse_args(["projects"])
        assert args.command == "projects"

    def test_projects_alias(self, parser):
        """'p' alias for projects."""
        args = parser.parse_args(["p"])
        assert args.command == "p"

    def test_projects_add(self, parser):
        """Projects add subcommand."""
        args = parser.parse_args(["projects", "add", "/path/to/project"])
        assert args.projects_command == "add"
        assert args.path == "/path/to/project"

    def test_projects_add_with_name(self, parser):
        """Projects add with --name."""
        args = parser.parse_args(["projects", "add", "-n", "MyProject"])
        assert args.name == "MyProject"

    def test_projects_remove(self, parser):
        """Projects remove subcommand."""
        args = parser.parse_args(["projects", "remove", "/path/to/project"])
        assert args.projects_command == "remove"
        assert args.path == "/path/to/project"

    def test_projects_list(self, parser):
        """Projects list subcommand."""
        args = parser.parse_args(["projects", "list"])
        assert args.projects_command == "list"


class TestRecipesCommand:
    """Tests for 'recipes' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_recipes_basic(self, parser):
        """Basic recipes command."""
        args = parser.parse_args(["recipes"])
        assert args.command == "recipes"

    def test_recipes_alias(self, parser):
        """'r' alias for recipes."""
        args = parser.parse_args(["r"])
        assert args.command == "r"

    def test_recipes_with_query(self, parser):
        """Recipes with search query."""
        args = parser.parse_args(["recipes", "linux"])
        assert args.query == "linux"

    def test_recipes_browse(self, parser):
        """Recipes with --browse."""
        args = parser.parse_args(["recipes", "--browse"])
        assert args.browse is True


class TestFragmentsCommand:
    """Tests for 'fragments' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_fragments_basic(self, parser):
        """Basic fragments command."""
        args = parser.parse_args(["fragments"])
        assert args.command == "fragments"

    def test_fragments_aliases(self, parser):
        """'f' and 'frags' aliases for fragments."""
        args = parser.parse_args(["f"])
        assert args.command == "f"

        args = parser.parse_args(["frags"])
        assert args.command == "frags"

    def test_fragments_list(self, parser):
        """Fragments list subcommand."""
        args = parser.parse_args(["fragments", "list"])
        assert args.fragment_command == "list"

    def test_fragments_enable(self, parser):
        """Fragments enable subcommand."""
        args = parser.parse_args(["fragments", "enable", "meta/yocto/feature"])
        assert args.fragment_command == "enable"
        assert "meta/yocto/feature" in args.fragmentname


class TestInfoCommand:
    """Tests for 'info' command parsing."""

    @pytest.fixture
    def parser(self):
        parser, _ = build_parser()
        return parser

    def test_info_basic(self, parser):
        """Basic info command."""
        args = parser.parse_args(["info"])
        assert args.command == "info"

    def test_info_alias(self, parser):
        """'i' alias for info."""
        args = parser.parse_args(["i"])
        assert args.command == "i"

    def test_info_layers(self, parser):
        """Info layers subcommand."""
        args = parser.parse_args(["info", "layers"])
        assert args.info_command == "layers"

    def test_info_vars(self, parser):
        """Info vars subcommand."""
        args = parser.parse_args(["info", "vars"])
        assert args.info_command == "vars"


class TestCommandTree:
    """Tests for COMMAND_TREE structure."""

    def test_command_tree_not_empty(self):
        """COMMAND_TREE has commands."""
        assert len(COMMAND_TREE) > 0

    def test_commands_list_includes_subcommands(self):
        """COMMANDS list includes subcommands."""
        # Find a command with subcommands
        cmd_with_subs = None
        for cmd, desc, subs in COMMAND_TREE:
            if subs:
                cmd_with_subs = (cmd, subs)
                break

        assert cmd_with_subs is not None
        parent_cmd, subcommands = cmd_with_subs

        # Check that subcommands are in COMMANDS
        for subcmd, subdesc in subcommands:
            matching = [c for c, d in COMMANDS if c == subcmd]
            assert len(matching) > 0, f"Subcommand {subcmd} not in COMMANDS"

    def test_all_commands_have_descriptions(self):
        """All commands have descriptions."""
        for cmd, desc, _ in COMMAND_TREE:
            assert desc, f"Command {cmd} has no description"

    def test_expected_commands_present(self):
        """Expected core commands are present."""
        cmd_names = [cmd for cmd, _, _ in COMMAND_TREE]

        expected = ["update", "explore", "config", "branch", "status", "export", "info", "setup", "create", "layer-index"]
        for expected_cmd in expected:
            assert expected_cmd in cmd_names, f"Expected command {expected_cmd} missing"
