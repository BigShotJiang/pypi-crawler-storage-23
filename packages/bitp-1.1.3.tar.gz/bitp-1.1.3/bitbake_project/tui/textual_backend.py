#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Textual backend for TUI abstraction layer.

Provides rich TUI features including:
- Modal dialogs
- Floating panels
- Better prompt handling
- Full keyboard navigation

Requires: pip install textual
"""

from typing import List, Optional

# Check if textual is available
try:
    import textual
    from textual.app import App, ComposeResult
    from textual.widgets import Static, Input, Button, ListView, ListItem
    from textual.containers import Container, Vertical, Horizontal
    from textual.screen import ModalScreen
    TEXTUAL_AVAILABLE = True
except ImportError:
    TEXTUAL_AVAILABLE = False

from .base import (
    Action,
    MenuBackend,
    MenuConfig,
    MenuItem,
    MenuResult,
    PromptResult,
)


class TextualBackend(MenuBackend):
    """Textual-based TUI backend.

    Provides rich TUI with modal dialogs and better interactivity.
    Requires textual to be installed.
    """

    def available(self) -> bool:
        return TEXTUAL_AVAILABLE

    def name(self) -> str:
        return "textual"

    def select_one(
        self,
        items: List[MenuItem],
        config: Optional[MenuConfig] = None,
    ) -> MenuResult:
        if not TEXTUAL_AVAILABLE:
            raise RuntimeError("textual is not installed. Run: pip install textual")

        # TODO: Implement textual menu
        # For now, fall back to a simple implementation
        raise NotImplementedError("Textual backend not yet implemented")

    def select_many(
        self,
        items: List[MenuItem],
        config: Optional[MenuConfig] = None,
    ) -> MenuResult:
        if not TEXTUAL_AVAILABLE:
            raise RuntimeError("textual is not installed. Run: pip install textual")

        raise NotImplementedError("Textual backend not yet implemented")

    def prompt(
        self,
        message: str,
        default: str = "",
        placeholder: str = "",
    ) -> PromptResult:
        if not TEXTUAL_AVAILABLE:
            raise RuntimeError("textual is not installed. Run: pip install textual")

        raise NotImplementedError("Textual backend not yet implemented")

    def confirm(
        self,
        message: str,
        default: bool = False,
    ) -> bool:
        if not TEXTUAL_AVAILABLE:
            raise RuntimeError("textual is not installed. Run: pip install textual")

        raise NotImplementedError("Textual backend not yet implemented")

    def notify(
        self,
        message: str,
        title: Optional[str] = None,
        wait: bool = False,
    ) -> None:
        # Simple fallback
        if title:
            print(f"{title}: {message}")
        else:
            print(message)
        if wait:
            input("Press Enter to continue...")


# --- Textual Dialog Renderer (placeholder) ---

class TextualDialogRenderer:
    """Render dialogs as Textual modal overlays.

    Unlike fzf which adds items to the menu, Textual would show
    dialogs as floating modal panels over the menu.

    This is a placeholder - implementation would use Textual's
    ModalScreen to show dialogs.
    """

    def show_dialog(self, dialog, on_result):
        """Show dialog as modal overlay.

        Args:
            dialog: Dialog to show
            on_result: Callback with DialogResult when done
        """
        if not TEXTUAL_AVAILABLE:
            raise RuntimeError("textual not installed")
        raise NotImplementedError("Textual dialog renderer not yet implemented")


# --- Future implementation sketch ---
#
# When implementing, the textual backend would look something like:
#
# class SelectMenuScreen(ModalScreen):
#     """Modal screen for single selection."""
#
#     def __init__(self, items: List[MenuItem], config: MenuConfig):
#         super().__init__()
#         self.items = items
#         self.config = config
#         self.result = None
#
#     def compose(self) -> ComposeResult:
#         yield Container(
#             Static(self.config.header or "Select an option"),
#             Input(placeholder="Type to filter..."),
#             ListView(*[ListItem(Static(item.display)) for item in self.items]),
#             Horizontal(
#                 Button("Select", variant="primary"),
#                 Button("Cancel"),
#             ),
#         )
#
#     def on_button_pressed(self, event):
#         if event.button.label == "Cancel":
#             self.dismiss(MenuResult(action=Action.CANCEL))
#         else:
#             # Get selected item
#             self.dismiss(MenuResult(action=Action.SELECT, selected=...))
#
#
# class PromptScreen(ModalScreen):
#     """Modal screen for text input."""
#
#     def __init__(self, message: str, default: str = ""):
#         super().__init__()
#         self.message = message
#         self.default = default
#
#     def compose(self) -> ComposeResult:
#         yield Container(
#             Static(self.message),
#             Input(value=self.default, id="prompt-input"),
#             Horizontal(
#                 Button("OK", variant="primary"),
#                 Button("Cancel"),
#             ),
#         )
#
#     def on_button_pressed(self, event):
#         if event.button.label == "Cancel":
#             self.dismiss(PromptResult(value=None, confirmed=False))
#         else:
#             value = self.query_one("#prompt-input", Input).value
#             self.dismiss(PromptResult(value=value, confirmed=True))
