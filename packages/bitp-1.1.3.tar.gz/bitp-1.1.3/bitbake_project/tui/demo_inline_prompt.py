#!/usr/bin/env python3
#
# Demo: In-line prompts within fzf menus
#
# Run: python -m bitbake_project.tui.demo_inline_prompt
#
# Shows how to get user input without exiting fzf by:
# 1. Adding prompt items to the menu
# 2. Using the query field for input
# 3. Changing the prompt dynamically
#

import os
import shlex
import subprocess
import sys
import tempfile

# ANSI colors
CYAN = "\033[36m"
GREEN = "\033[32m"
YELLOW = "\033[33m"
DIM = "\033[2m"
RESET = "\033[0m"


def run_demo():
    """Demo: fzf menu with inline prompts."""

    # Sample repository data
    repos = [
        ("poky", "OE-core", "master", "clean", "5 local"),
        ("meta-oe", "meta-openembedded", "master", "clean", "0 local"),
        ("meta-virt", "meta-virtualization", "kirkstone", "dirty", "3 local"),
    ]

    prompt_mode = False
    prompt_type = None  # "branch" or "search"
    last_message = ""

    while True:
        # Build menu items
        menu_lines = []

        if prompt_mode:
            # Add prompt section at top
            if prompt_type == "branch":
                msg = "Enter branch name for all repos"
            else:
                msg = "Enter search term"

            menu_lines.extend([
                f"__PROMPT_MSG__\t{CYAN}┌─ {msg} ─{RESET}",
                f"__PROMPT_HELP__\t{DIM}│  Type value below, Enter=confirm, Esc=cancel{RESET}",
                f"__PROMPT_CONFIRM__\t{GREEN}│  [ ✓ Press Enter to confirm ]{RESET}",
                f"__PROMPT_CANCEL__\t{YELLOW}│  [ ✗ Press Esc to cancel ]{RESET}",
                f"__PROMPT_SEP__\t{CYAN}└{'─' * 45}{RESET}",
            ])

        # Add repo items
        for path, name, branch, status, commits in repos:
            status_color = GREEN if status == "clean" else YELLOW
            line = f"  {name:<22} {branch:<12} {commits:<10} [{status_color}{status}{RESET}]"
            menu_lines.append(f"{path}\t{line}")

        menu_input = "\n".join(menu_lines)

        # Build fzf command
        if prompt_mode:
            header = f"{DIM}Type your input in the prompt below{RESET}"
            if prompt_type == "branch":
                prompt_text = "Branch name: "
            else:
                prompt_text = "Search: "
            expect_keys = []
        else:
            header = "b=branch all | s=search | Enter=select | q=quit"
            prompt_text = "Select repo: "
            expect_keys = ["b", "s", "q"]

        fzf_args = [
            "fzf",
            "--ansi",
            "--height", "~60%",
            "--layout=reverse",
            "--header", header,
            "--prompt", prompt_text,
            "--with-nth", "2..",
            "--delimiter", "\t",
            "--print-query",  # Always capture query for prompt mode
            "--no-sort",  # Keep order stable
        ]

        if expect_keys:
            fzf_args.extend(["--expect", ",".join(expect_keys)])

        # Write menu to temp file, run fzf reading from it
        # This lets fzf use TTY for interaction while getting menu from file
        with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
            f.write(menu_input)
            temp_file = f.name

        try:
            shell_cmd = f"cat {shlex.quote(temp_file)} | {' '.join(shlex.quote(a) for a in fzf_args)}"
            result = subprocess.run(
                shell_cmd,
                shell=True,
                stdout=subprocess.PIPE,
                # Don't capture stderr - fzf writes its UI there
                text=True,
            )
        finally:
            os.unlink(temp_file)

        # Parse output
        lines = result.stdout.split("\n")

        # Debug: uncomment to see what's happening
        # print(f"DEBUG: returncode={result.returncode}, stdout={repr(result.stdout)}, stderr={repr(result.stderr)}")

        if result.returncode != 0:
            if prompt_mode:
                # Cancelled in prompt mode - return to normal
                prompt_mode = False
                last_message = f"{YELLOW}Cancelled{RESET}"
                continue
            else:
                # Quit
                break

        if prompt_mode:
            # Prompt mode: query is the user's input
            query = lines[0].strip() if lines else ""
            selected = lines[1].split("\t")[0].strip() if len(lines) > 1 else ""

            if selected == "__PROMPT_CONFIRM__" or (selected and not selected.startswith("__PROMPT_")):
                # User confirmed (either via confirm button or selecting a repo)
                if query:
                    if prompt_type == "branch":
                        last_message = f"{GREEN}Would switch all repos to branch: {query}{RESET}"
                    else:
                        last_message = f"{GREEN}Would search for: {query}{RESET}"
                else:
                    last_message = f"{YELLOW}No input provided{RESET}"
                prompt_mode = False
            elif selected == "__PROMPT_CANCEL__":
                last_message = f"{YELLOW}Cancelled{RESET}"
                prompt_mode = False
            # else: selected a non-actionable prompt item, stay in prompt mode

        else:
            # Normal mode
            query = lines[0].strip() if lines else ""
            key = lines[1].strip() if len(lines) > 1 else ""
            selected = lines[2].split("\t")[0].strip() if len(lines) > 2 else ""

            if key == "b":
                prompt_mode = True
                prompt_type = "branch"
                last_message = ""
                continue

            if key == "s":
                prompt_mode = True
                prompt_type = "search"
                last_message = ""
                continue

            if key == "q":
                break

            if selected and not selected.startswith("__"):
                last_message = f"{GREEN}Selected: {selected}{RESET}"

        # Show message if any
        if last_message:
            print(last_message)
            last_message = ""

    print("Done.")


if __name__ == "__main__":
    run_demo()
