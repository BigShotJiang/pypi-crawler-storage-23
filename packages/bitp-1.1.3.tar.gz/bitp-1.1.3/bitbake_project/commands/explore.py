#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Explore command - interactively explore commits in layer repos."""

from datetime import datetime
import argparse
import json
import os
import re
import shlex
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import threading
import time
import urllib.request
import uuid
from typing import Dict, List, Optional, Set, Tuple

from ..core import (
    Colors,
    current_branch,
    current_head,
    fzf_available,
    get_fzf_color_args,
    get_fzf_preview_resize_bindings,
    git_toplevel,
    load_defaults,
    repo_is_clean,
    save_defaults,
    terminal_color,
)
from ..fzf_bindings import (
    get_exit_bindings,
    get_accept_binding,
    get_fzf_version,
    get_preview_header_suffix,
    get_preview_toggle_binding,
    get_preview_scroll_bindings,
    get_toggle_binding,
    get_action_binding,
    get_position_binding,
)
from .common import (
    resolve_bblayers_path,
    resolve_base_and_layers,
    collect_repos,
    dedupe_preserve_order,
    repo_display_name,
    layer_display_name,
    discover_layers,
    add_layer_to_bblayers,
    remove_layer_from_bblayers,
    build_layer_collection_map,
    prompt_action,
    run_cmd,
    add_extra_repo,
    add_hidden_repo,
    remove_hidden_repo,
    get_hidden_repos,
    get_upstream_count_ls_remote,
    find_repo_by_identifier,
    get_upstream_layer_counts,
)
from .update import fetch_repo, get_upstream_commits, run_single_repo_update
from .branch import (
    fzf_branch_repos,
    get_branches,
    checkout_branch,
    collect_union_branches,
    switch_repos_to_branch,
    get_local_commits,
    get_local_commits_for_layer,
    get_upstream_context_commits,
    get_upstream_ref,
    get_upstream_to_pull,
    get_upstream_to_pull_for_layer,
    fzf_multiselect_commits,
    fzf_select_insertion_point,
    prompt_branch_name,
)
from .config import (
    fzf_repo_config,
    fzf_build_config,
)
from .info import fzf_info_browser
from .common import copy_to_clipboard, export_commits_from_explore, get_project_header_prefix
from .projects import get_preferred_git_viewer, get_preview_window_arg, get_explore_load_size
from ..tui import (
    DialogType,
    ExploreMenuState,
    create_branch_dialog,
    confirm_update_dialog,
    confirm_action_dialog,
    text_input_dialog,
    custom_command_dialog,
    select_action_dialog,
    update_repo_dialog,
    InlineSelector,
    InlineSelectorItem,
)

def run_status(args) -> int:
    defaults = load_defaults(args.defaults_file)
    discover_all = getattr(args, 'all', False)
    pairs, repo_sets = resolve_base_and_layers(args.bblayers, defaults, discover_all=discover_all)

    repo_layers: Dict[str, List[str]] = {}
    for layer, repo in pairs:
        repo_layers.setdefault(repo, []).append(layer)

    # Optionally fetch first
    if args.fetch:
        print("Fetching from origin...")
        for repo in repo_layers.keys():
            if defaults.get(repo, "rebase") != "skip":
                fetch_repo(repo)

    repo_cache: Dict[str, Tuple[str, bool, str, List[str]]] = {}

    for repo, layers in repo_layers.items():
        default_action = defaults.get(repo, "rebase")
        layer_list = ", ".join(layers)
        is_discovered = repo in repo_sets.discovered
        discovered_marker = " (?)" if is_discovered else ""

        # Format layers for multi-line display
        def format_layers(layer_paths: List[str]) -> str:
            if len(layer_paths) == 1:
                return f"  layer: {layer_display_name(layer_paths[0])}"
            lines = ["  layers:"]
            for lp in layer_paths:
                lines.append(f"    {layer_display_name(lp)}")
            return "\n".join(lines)

        if default_action == "skip":
            if args.verbose == 0:
                layer_names = ", ".join(layer_display_name(lp) for lp in layers)
                print(f"→ {layer_names}{discovered_marker}: default=skip")
            else:
                print(f"→ {repo}: default=skip (skipping status)")
                print(format_layers(layers))
            continue

        if repo not in repo_cache:
            branch = current_branch(repo)
            if not branch:
                repo_cache[repo] = ("(detached)", False, "detached head", [], [])
            else:
                remote_ref = f"origin/{branch}"
                remote_exists = (
                    subprocess.run(
                        ["git", "-C", repo, "rev-parse", "--verify", remote_ref],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                    ).returncode
                    == 0
                )
                show_all = args.verbose >= 2
                desc, lines = get_repo_log(repo, branch, remote_exists, args.max_commits, show_all)
                upstream = get_upstream_commits(repo, branch) if remote_exists else []
                repo_cache[repo] = (branch, remote_exists, desc, lines, upstream)

        branch, remote_exists, desc, lines, upstream = repo_cache[repo]
        is_clean = repo_is_clean(repo)

        # Format worktree status with color
        if is_clean:
            worktree_status = terminal_color("clean", "[clean]")
            worktree_status_plain = "[clean]"
        else:
            worktree_status = terminal_color("dirty", "[DIRTY]")
            worktree_status_plain = "[DIRTY]"

        if branch == "(detached)":
            if args.verbose == 0:
                layer_names = ", ".join(layer_display_name(lp) for lp in layers)
                print(f"→ {layer_names}{discovered_marker}: detached HEAD {worktree_status}")
            else:
                print(f"→ {repo}: detached HEAD or no branch {worktree_status}; skipping")
                print(format_layers(layers))
            continue

        local_count = len(lines)
        upstream_count = len(upstream)

        if args.verbose == 0:
            # Summary mode (default)
            layer_names = ", ".join(layer_display_name(lp) for lp in layers)
            status_parts = []
            if local_count:
                status_parts.append(f"{local_count} local commit(s)")
            # Use ls-remote for upstream if not fetched (like repos status does)
            if args.fetch:
                if upstream_count:
                    status_parts.append(terminal_color("upstream", f"{upstream_count} to pull"))
            else:
                ls_result = get_upstream_count_ls_remote(repo, branch)
                if ls_result == -1:
                    status_parts.append(terminal_color("upstream", "upstream has changes"))
                elif ls_result and ls_result > 0:
                    status_parts.append(terminal_color("upstream", f"{ls_result} to pull"))
            if not status_parts:
                status_parts.append("up-to-date")
            print(f"→ {layer_names}{discovered_marker}: {', '.join(status_parts)} on {Colors.bold(branch)} {worktree_status}")
            continue

        # Build status line with colors
        status_parts = []
        if local_count:
            status_parts.append(f"{local_count} local commit(s)")
        if upstream_count:
            status_parts.append(terminal_color("upstream", f"{upstream_count} upstream commit(s) to pull"))
        if not status_parts:
            status_parts.append("up-to-date")

        # Color repo path green if clean
        repo_display = Colors.green(repo) if is_clean else repo
        branch_display = Colors.bold(branch)
        print(f"→ {repo_display}: {', '.join(status_parts)} on {branch_display} {worktree_status}")
        print(format_layers(layers))

        # Show local commits
        show_all = args.verbose >= 2
        if lines:
            print("  local:")
            limit = len(lines) if show_all else args.max_commits
            for line in lines[:limit]:
                print(f"    {line}")
            if remote_exists and not show_all and len(lines) > args.max_commits:
                print(f"    ... ({len(lines) - args.max_commits} more)")

        # Show upstream commits (yellow to indicate pending pulls)
        if upstream:
            print(f"  {terminal_color('upstream', 'upstream:')}")
            limit = len(upstream) if show_all else args.max_commits
            for line in upstream[:limit]:
                print(f"    {Colors.yellow(line)}")
            if not show_all and len(upstream) > args.max_commits:
                print(f"    {terminal_color('upstream', f'... ({len(upstream) - args.max_commits} more)')}")

    return 0



def _build_layers_view_menu(
    repos: List[str],
    repo_info: Dict[str, Dict],
    repo_layers: Dict[str, List[str]],
    discovered_repos: Set[str],
    external_repos: Set[str],
    configured_layers: Set[str],
) -> str:
    """Build fzf menu showing individual layers grouped by repo."""
    menu_lines = []

    # Build list of all layers with their info
    layer_entries = []
    for repo in repos:
        layers = repo_layers.get(repo, [])
        is_discovered_repo = repo in discovered_repos
        is_external = repo in external_repos

        if not layers:
            # External repo with no layers - show repo itself
            if is_external:
                layer_entries.append({
                    "path": repo,
                    "name": repo_display_name(repo),
                    "repo": repo,
                    "repo_name": repo_display_name(repo),
                    "is_configured": False,
                    "is_external": True,
                    "branch": repo_info.get(repo, {}).get("branch", ""),
                    "is_dirty": repo_info.get(repo, {}).get("is_dirty", False),
                })
            continue

        for layer in layers:
            layer_name = os.path.basename(layer)
            is_configured = layer in configured_layers
            layer_entries.append({
                "path": layer,
                "name": layer_name,
                "repo": repo,
                "repo_name": repo_display_name(repo),
                "is_configured": is_configured,
                "is_external": False,
                "branch": repo_info.get(repo, {}).get("branch", ""),
                "is_dirty": repo_info.get(repo, {}).get("is_dirty", False),
            })

    if not layer_entries:
        return ""

    # Calculate column widths
    max_layer_len = max(len(e["name"]) for e in layer_entries)
    max_layer_len = min(max_layer_len + 6, 40)  # +6 for markers, cap at 40
    max_repo_len = max(len(e["repo_name"]) for e in layer_entries)
    max_repo_len = min(max_repo_len, 25)
    max_branch_len = max(len(e["branch"]) for e in layer_entries) if layer_entries else 15
    max_branch_len = max(max_branch_len, 15)  # minimum 15 chars

    # Build menu lines
    for entry in layer_entries:
        layer_path = entry["path"]
        layer_name = entry["name"]
        repo_name = entry["repo_name"]
        is_configured = entry["is_configured"]
        is_external = entry["is_external"]
        branch = entry["branch"]
        is_dirty = entry["is_dirty"]

        # Markers
        if is_external:
            marker = " (ext)"
        elif not is_configured:
            marker = " (?)"
        else:
            marker = ""

        display_name = f"{layer_name}{marker}"

        # Status
        if is_dirty:
            status = terminal_color("dirty", "[DIRTY]")
        else:
            status = terminal_color("clean", "[clean]")

        # Color based on status
        if is_dirty:
            colored_name = Colors.red(f"{display_name:<{max_layer_len}}")
            colored_repo = Colors.red(f"{repo_name:<{max_repo_len}}")
        elif is_external:
            colored_name = terminal_color("repo_external", f"{display_name:<{max_layer_len}}")
            colored_repo = terminal_color("repo_external", f"{repo_name:<{max_repo_len}}")
        elif not is_configured:
            colored_name = terminal_color("repo_discovered", f"{display_name:<{max_layer_len}}")
            colored_repo = terminal_color("repo_discovered", f"{repo_name:<{max_repo_len}}")
        else:
            colored_name = terminal_color("repo", f"{display_name:<{max_layer_len}}")
            colored_repo = terminal_color("repo", f"{repo_name:<{max_repo_len}}")

        line = f"LAYER:{layer_path}\t{colored_name}  {colored_repo}  {branch:<{max_branch_len}} {status}"
        menu_lines.append(line)

    # Reverse so first layer appears at top
    menu_lines = list(reversed(menu_lines))

    # Column header and separator
    header_line = f"HEADER\t{'Layer':<{max_layer_len}}  {'Repository':<{max_repo_len}}  {'Branch':<{max_branch_len}} Status"
    sep_len = max_layer_len + 2 + max_repo_len + 2 + max_branch_len + 1 + 8
    separator = f"SEPARATOR_HEADER\t{'─' * sep_len}"
    menu_lines.append(separator)
    menu_lines.append(header_line)

    return "\n".join(menu_lines)



def _build_explore_menu_lines(
    repos: List[str],
    repo_info: Dict[str, Dict],
    repo_layers: Dict[str, List[str]],
    verbose_mode: bool,
    discovered_repos: Optional[Set[str]] = None,
    external_repos: Optional[Set[str]] = None,
    expanded_repos: Optional[Set[str]] = None,
    layers_mode: bool = False,
    configured_layers: Optional[Set[str]] = None,
    bblayers_conf: Optional[str] = None,
) -> str:
    """Build fzf menu input for explore repo/layers list. Returns newline-joined string."""
    menu_lines = []
    discovered_repos = discovered_repos or set()
    external_repos = external_repos or set()
    expanded_repos = expanded_repos or set()
    configured_layers = configured_layers or set()

    # Layers mode: show individual layers instead of repos
    if layers_mode:
        return _build_layers_view_menu(
            repos, repo_info, repo_layers, discovered_repos,
            external_repos, configured_layers
        )

    def get_marker_len(repo: str) -> int:
        """Get marker length: 4 for '(?)', 6 for '(ext)', 0 otherwise."""
        if repo in external_repos:
            return 6  # " (ext)"
        if repo in discovered_repos:
            return 4  # " (?)"
        return 0

    # Account for markers on discovered/external repos
    max_name_len = max(
        len(repo_info[r]["display_name"]) + get_marker_len(r)
        for r in repos
    ) if repos else 20

    max_name_len = max(max_name_len, 20)

    # Calculate max length of info column for alignment
    count_width = 3
    max_info_len = 0
    for repo in repos:
        info = repo_info[repo]
        local_count = info["local_count"]
        branch = info["branch"]
        upstream_count = info.get("upstream_count", 0)

        # Fixed-width count + branch + tracking hint + upstream (at end)
        upstream_ref = get_upstream_ref(repo, branch)
        if upstream_ref and not upstream_ref.startswith("origin/"):
            tracking_hint = f" \u2192 {upstream_ref.split('/')[0]}"
        else:
            tracking_hint = ""
        if upstream_count == -1:
            upstream_str = " \u2193 upstream"
        elif upstream_count > 0:
            upstream_str = f" \u2193 {upstream_count}"
        else:
            upstream_str = ""
        info_str = f"{local_count:>{count_width}} local, {branch}{tracking_hint}{upstream_str}"
        if len(info_str) > max_info_len:
            max_info_len = len(info_str)

    max_info_len = max(max_info_len, 25)

    for repo in repos:
        info = repo_info[repo]
        local_count = info["local_count"]
        branch = info["branch"]
        is_dirty = info["is_dirty"]
        upstream_count = info.get("upstream_count", 0)

        verbose_commit = ""
        if verbose_mode:
            head_commit = info.get("head_commit")
            if head_commit:
                top_hash, top_subject = head_commit
                commit_text = f"{top_hash[:8]} {top_subject}"
                if len(commit_text) > 50:
                    commit_text = commit_text[:47] + "..."
                verbose_commit = f"{commit_text:<50}"
        name = info["display_name"]

        # Add marker for discovered/external repos
        is_discovered = repo in discovered_repos
        is_external = repo in external_repos
        if is_external:
            name = f"{name} (ext)"
        elif is_discovered:
            name = f"{name} (?)"

        # Add + prefix for repos with multiple layers (expandable)
        num_layers = len(repo_layers.get(repo, []))
        expand_marker = "+ " if num_layers > 1 else "  "

        if is_dirty:
            status = terminal_color("dirty", "[DIRTY]")
            colored_name = Colors.red(f"{name:<{max_name_len}}")
        elif is_external:
            status = terminal_color("clean", "[clean]")
            colored_name = terminal_color("repo_external", f"{name:<{max_name_len}}")
        elif is_discovered:
            status = terminal_color("clean", "[clean]")
            colored_name = terminal_color("repo_discovered", f"{name:<{max_name_len}}")
        else:
            status = terminal_color("clean", "[clean]")
            colored_name = terminal_color("repo", f"{name:<{max_name_len}}")
        if verbose_commit:
            colored_name += "  " + terminal_color("commit", verbose_commit)

        count_str = f"{local_count:>3} local"

        # Resolve upstream for display
        upstream_ref = get_upstream_ref(repo, branch)
        if upstream_ref and not upstream_ref.startswith("origin/"):
            tracking_hint = f" \u2192 {upstream_ref.split('/')[0]}"
        else:
            tracking_hint = ""

        if upstream_count == -1:
            upstream_str_plain = " \u2193 upstream"
            upstream_str = " " + terminal_color("upstream", "\u2193 upstream")
        elif upstream_count > 0:
            upstream_str_plain = f" \u2193 {upstream_count}"
            upstream_str = " " + terminal_color("upstream", f"\u2193 {upstream_count}")
        else:
            upstream_str_plain = ""
            upstream_str = ""

        info_str_plain = f"{count_str}, {branch}{tracking_hint}{upstream_str_plain}"
        padding = max_info_len - len(info_str_plain)
        info_str = f"{count_str}, {branch}{tracking_hint}{upstream_str}{' ' * padding}"

        line = f"{repo}\t{expand_marker}{colored_name}  {info_str} {status}"
        menu_lines.append(line)

        # Add layer lines if repo is expanded
        if repo in expanded_repos:
            layers = repo_layers.get(repo, [])
            # Filter out layer that matches the repo display name (redundant)
            display = repo_display_name(repo)
            layers = [l for l in layers if os.path.basename(l) != display]
            layer_counts = info.get("layer_upstream_counts", {})
            # Align layer commits with repo commits: layer prefix is 3 chars
            # wider than expand marker ("  ├─ "=5 vs "+ "=2), so subtract 3.
            # Include " (?)" (4 chars) for discovered layers in width calc.
            max_layer_len = max(
                max_name_len - 3,
                max((len(os.path.basename(l)) + (4 if l not in configured_layers else 0)
                     for l in layers), default=0))
            for i, layer in enumerate(layers):
                layer_name = os.path.basename(layer)
                is_last = (i == len(layers) - 1)
                prefix = "  └─ " if is_last else "  ├─ "
                # Color based on whether layer is in bblayers.conf
                if layer in configured_layers:
                    padded = f"{layer_name:<{max_layer_len}}"
                    layer_display = f"{prefix}{terminal_color('repo', padded)}"
                else:
                    label = f"{layer_name} {Colors.dim('(?)')}"
                    # Pad based on visible width (layer_name + 4 for " (?)")
                    visible_len = len(layer_name) + 4
                    pad = max_layer_len - visible_len
                    layer_display = f"{prefix}{terminal_color('repo_discovered', layer_name)} {Colors.dim('(?)')}{' ' * max(pad, 0)}"
                # Append per-layer top commit in verbose mode
                if verbose_mode:
                    try:
                        relpath = os.path.relpath(layer, repo)
                        out = subprocess.check_output(
                            ["git", "-C", repo, "log", "-1", "--format=%H %s", "--", f"{relpath}/"],
                            text=True, stderr=subprocess.DEVNULL,
                        ).strip()
                        if out:
                            sha, subj = out.split(" ", 1)
                            lcommit = f"{sha[:8]} {subj}"
                            if len(lcommit) > 50:
                                lcommit = lcommit[:47] + "..."
                            lcommit = f"{lcommit:<50}"
                            layer_display += "  " + terminal_color("commit", lcommit)
                    except Exception:
                        pass
                # Append per-layer upstream count if available
                lcount = layer_counts.get(layer, 0)
                if lcount > 0:
                    layer_display += f" {terminal_color('upstream', f'↓ {lcount}')}"
                # Use LAYER: prefix to identify layer entries
                layer_line = f"LAYER:{layer}\t{layer_display}"
                menu_lines.append(layer_line)

    # Add project entry if bblayers.conf is known (with separator)
    if bblayers_conf:
        conf_dir = os.path.dirname(bblayers_conf)
        # Add separator before project (unique ID to distinguish from header separator)
        menu_lines.append(f"SEPARATOR_PROJECT\t")  # Empty separator line
        # Pad plain text, then apply color
        project_name = f"{'project':<{max_name_len}}"
        project_line = f"PROJECT\t  {terminal_color('project_active', project_name)}  {'config':<{max_info_len}} {conf_dir}"
        menu_lines.append(project_line)
        # Add info entry
        info_name = f"{'info':<{max_name_len}}"
        info_line = f"INFO\t  {Colors.yellow(info_name)}  {'build':<{max_info_len}} layers + variables"
        menu_lines.append(info_line)

    # Reverse so first repo appears at top
    menu_lines = list(reversed(menu_lines))

    # Column header and separator (unique ID to distinguish from project separator)
    header_info = f"{'Commits,':<11}Branch"
    header_line = f"HEADER\t  {'Name':<{max_name_len}}  {header_info:<{max_info_len}} Status"
    sep_len = 2 + max_name_len + 2 + max_info_len + 1 + 8
    separator = f"SEPARATOR_HEADER\t{'─' * sep_len}"
    menu_lines.append(separator)
    menu_lines.append(header_line)

    return "\n".join(menu_lines)



def _find_free_port() -> int:
    """Find a free port for fzf --listen."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1', 0))
        return s.getsockname()[1]



def _background_upstream_check(
    repos: List[str],
    repo_info: Dict[str, Dict],
    repo_layers: Dict[str, List[str]],
    verbose_mode: bool,
    defaults: Dict[str, str],
    temp_file: str,
    fzf_port: int,
    stop_event: threading.Event,
    discovered_repos: Optional[Set[str]] = None,
    external_repos: Optional[Set[str]] = None,
    expanded_repos: Optional[Set[str]] = None,
    bblayers_conf: Optional[str] = None,
) -> None:
    """Background thread: check upstream status via ls-remote and reload fzf."""
    any_updates = False
    for repo in repos:
        if stop_event.is_set():
            return
        info = repo_info[repo]
        branch = info["branch"]
        if branch == "(detached)" or defaults.get(repo, "rebase") == "skip":
            continue
        if info.get("upstream_count", 0) != 0:
            # Already have upstream info
            continue
        try:
            ls_result = get_upstream_count_ls_remote(repo, branch)
            if ls_result == -1:
                repo_info[repo]["upstream_count"] = -1
                any_updates = True
            elif ls_result and ls_result > 0:
                repo_info[repo]["upstream_count"] = ls_result
                any_updates = True
                layers = repo_layers.get(repo, [])
                if len(layers) > 1:
                    layer_counts = get_upstream_layer_counts(repo, branch, layers)
                    repo_info[repo]["layer_upstream_counts"] = layer_counts
        except Exception:
            pass

    if stop_event.is_set():
        return

    if any_updates:
        # Rebuild menu and write to temp file
        menu_input = _build_explore_menu_lines(repos, repo_info, repo_layers, verbose_mode, discovered_repos, external_repos, expanded_repos, bblayers_conf=bblayers_conf)
        try:
            with open(temp_file, 'w') as f:
                f.write(menu_input)
            # Tell fzf to reload
            req = urllib.request.Request(
                f"http://127.0.0.1:{fzf_port}",
                data=f"reload(cat {temp_file})".encode(),
                method='POST',
            )
            urllib.request.urlopen(req, timeout=2)
        except Exception:
            pass  # fzf may have exited



def fzf_explore_repo_list(
    repos: List[str],
    repo_info: Dict[str, Dict],
    repo_layers: Dict[str, List[str]] = None,
    verbose_mode: bool = False,
    defaults: Dict[str, str] = None,
    enable_background_refresh: bool = False,
    discovered_repos: Optional[Set[str]] = None,
    external_repos: Optional[Set[str]] = None,
    expanded_repos: Optional[Set[str]] = None,
    layers_mode: bool = False,
    configured_layers: Optional[Set[str]] = None,
    initial_selection: Optional[str] = None,
    bblayers_conf: Optional[str] = None,
    dialog_state: Optional[ExploreMenuState] = None,
    branch_selector: Optional[InlineSelector] = None,
) -> Tuple[str, Optional[str], str]:
    """
    Show repo/layer list with local commit counts for selection.
    Returns: (action, repo_path, query)
      action: "explore", "rebase", "merge", "refresh", "refresh_all", "verbose", "quit", "layers_toggle", "interrupt", "cancelled", "branch_select", or "dialog_*"
      repo_path: selected repo/layer path (None for quit/cancelled/refresh_all/verbose/layers_toggle/interrupt)
      query: the fzf query string (used for dialog text input)
    """
    if not repos:
        return "cancelled", None, ""

    repo_layers = repo_layers or {}
    defaults = defaults or {}
    discovered_repos = discovered_repos or set()
    external_repos = external_repos or set()
    expanded_repos = expanded_repos or set()
    configured_layers = configured_layers or set()

    # Check if dialog is active
    has_dialog = dialog_state is not None and dialog_state.has_dialog()

    # Don't reorder - we'll jump to the selected repo's position instead
    display_repos = repos

    # Build menu input using helper
    menu_input = _build_explore_menu_lines(
        display_repos, repo_info, repo_layers, verbose_mode,
        discovered_repos, external_repos, expanded_repos,
        layers_mode, configured_layers, bblayers_conf
    )

    # Append branch selector lines if active
    if branch_selector:
        selector_lines = branch_selector.build_menu_lines()
        menu_input = menu_input + "\n" + "\n".join(selector_lines)

    # Prepend dialog items if dialog is active
    if has_dialog:
        dialog_lines = dialog_state.get_dialog_menu_lines()
        dialog_input = "\n".join(f"{value}\t{display}" for value, display in dialog_lines)
        menu_input = dialog_input + "\n" + menu_input

    # Build header - show dialog info if active
    if branch_selector:
        header = branch_selector.header
        prompt = "Branch: "
    elif has_dialog:
        header = f"Complete dialog above | Esc=cancel"
        prompt = dialog_state.get_prompt_text() or "Input: "
    elif layers_mode:
        prefix = get_project_header_prefix()
        header = f"{prefix}{Colors.cyan('LAYERS VIEW')} | Enter=explore | a=add | d=remove | L=repos view | A=discover | q=quit\n+=track | -=hide | H=show hidden"
        prompt = "Select layer: "
    else:
        prefix = get_project_header_prefix()
        header = f"{prefix}{Colors.cyan('REPOS VIEW')} | Enter=explore | q=quit | L=layers view\n{Colors.cyan('Update:')} u=single | U=all | m=merge | r=refresh | R=refresh all | b=branch | B=branch all\n{Colors.cyan('View:')} v=verbose | Enter/←/→/\\=fold | t=history | S=shell\n{Colors.cyan('Manage:')} a/d=add/remove | +/-=track/hide | c=config | A=discover"
        prompt = "Select repo: "

    # Setup for background refresh if enabled
    temp_file = None
    bg_thread = None
    stop_event = None
    fzf_port = None

    if enable_background_refresh:
        # Write initial menu to temp file (for reload command)
        fd, temp_file = tempfile.mkstemp(prefix="bitbake-explore-", suffix=".txt")
        try:
            with os.fdopen(fd, 'w') as f:
                f.write(menu_input)
        except Exception:
            os.close(fd)
            temp_file = None

        if temp_file:
            fzf_port = _find_free_port()
            stop_event = threading.Event()
            bg_thread = threading.Thread(
                target=_background_upstream_check,
                args=(repos, repo_info, repo_layers, verbose_mode, defaults, temp_file, fzf_port, stop_event, discovered_repos, external_repos, expanded_repos, bblayers_conf),
                daemon=True,
            )
            bg_thread.start()

    try:
        fzf_cmd = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--no-info",
            "--ansi",
            "--height=~100%",
            "--header", header,
            "--prompt", prompt,
            "--with-nth", "2..",  # Display from field 2 onwards (hide repo path/HEADER)
            "--delimiter", "\t",
        ] + get_fzf_color_args()

        # Only use --print-query in dialog mode (to capture typed input)
        # In normal mode, become() commands don't work well with --print-query
        if branch_selector:
            # Branch picker mode - use InlineSelector args
            fzf_cmd.extend(branch_selector.get_fzf_args())
        elif has_dialog:
            fzf_cmd.append("--print-query")
            # Text prompts: disable filtering so typing captures query
            # without hiding the Confirm/Cancel options
            if dialog_state.active_dialog.dialog_type == DialogType.TEXT_PROMPT:
                fzf_cmd.append("--disabled")
            # Esc to cancel dialog
            fzf_cmd.extend(["--bind", "esc:abort"])
            # Position cursor on the default/selected option
            default_line = dialog_state.get_default_cursor_line()
            if default_line:
                fzf_cmd.extend(get_position_binding(default_line))
        else:
            # Normal mode bindings
            fzf_cmd.extend(get_action_binding("right", "RIGHT {1}"))
            fzf_cmd.extend(get_action_binding("left", "LEFT {1}"))
            fzf_cmd.extend(get_action_binding("q", "QUIT"))
            fzf_cmd.extend(get_action_binding("u", "REBASE {1}"))
            fzf_cmd.extend(get_action_binding("m", "MERGE {1}"))
            fzf_cmd.extend(get_action_binding("r", "REFRESH {1}"))
            fzf_cmd.extend(get_action_binding("R", "REFRESH_ALL"))
            fzf_cmd.extend(get_action_binding("v", "VERBOSE"))
            fzf_cmd.extend(get_action_binding("t", "TIG {1}"))
            fzf_cmd.extend(get_action_binding("+", "ADD_TRACKED {1}"))
            fzf_cmd.extend(get_action_binding("-", "HIDE {1}"))
            fzf_cmd.extend(get_action_binding("H", "TOGGLE_HIDDEN"))
            fzf_cmd.extend(get_action_binding("a", "ADD_LAYER {1}"))
            fzf_cmd.extend(get_action_binding("d", "REMOVE_LAYER {1}"))
            fzf_cmd.extend(get_action_binding("\\", "EXPAND {1}"))
            fzf_cmd.extend(get_action_binding("L", "LAYERS_TOGGLE"))
            fzf_cmd.extend(get_action_binding("c", "CONFIG {1}"))
            fzf_cmd.extend(get_action_binding("A", "DISCOVER_TOGGLE"))
            fzf_cmd.extend(get_action_binding("U", "UPDATE_ALL"))
            fzf_cmd.extend(get_action_binding("b", "BRANCH {1}"))
            fzf_cmd.extend(get_action_binding("B", "BRANCH_ALL"))
            fzf_cmd.extend(get_action_binding("S", "SHELL"))

        # Add --listen for background refresh support
        if fzf_port:
            fzf_cmd.extend(["--listen", str(fzf_port)])

        # Jump to selected repo's position (calculate line number from menu)
        if initial_selection:
            # Find line number of selected repo in menu (it's in field 1, tab-separated)
            lines = menu_input.split('\n')
            target_line = None
            search_for = initial_selection
            # If selection was a LAYER: entry that may no longer exist (collapsed),
            # fall back to finding the parent repo
            parent_repo = None
            if initial_selection.startswith("LAYER:"):
                layer_path = initial_selection[6:]
                # Find parent repo by checking which repo contains this layer
                for repo in repo_layers:
                    if layer_path in repo_layers.get(repo, []):
                        parent_repo = repo
                        break
            for i, line in enumerate(lines):
                if line.startswith(search_for + '\t'):
                    target_line = i + 1  # 1-indexed for fzf pos()
                    break
            # If LAYER: entry not found, try parent repo
            if target_line is None and parent_repo:
                for i, line in enumerate(lines):
                    if line.startswith(parent_repo + '\t'):
                        target_line = i + 1  # 1-indexed
                        break
            if target_line:
                fzf_cmd.extend(get_position_binding(target_line))

        result = subprocess.run(
            fzf_cmd,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        print("fzf not found. Please install fzf for the explore command.")
        return "cancelled", None
    finally:
        # Cleanup background refresh resources
        if stop_event:
            stop_event.set()
        if temp_file:
            try:
                os.unlink(temp_file)
            except Exception:
                pass

    if result.returncode == 130:
        # Ctrl+C pressed - return special action for double-tap detection
        return "interrupt", None, ""
    if result.returncode != 0 or not result.stdout.strip():
        if branch_selector:
            return "cancelled", None, ""
        return "cancelled", None, ""

    # Branch selector mode - parse via InlineSelector
    if branch_selector:
        selected_key = branch_selector.parse_selection(result.stdout, result.returncode)
        if selected_key:
            return "branch_select", selected_key, ""
        return "cancelled", None, ""

    # Parse output differently based on whether --print-query was used
    if has_dialog:
        # With --print-query: first line is query, second is selection
        lines = result.stdout.split("\n")
        query = lines[0] if lines else ""
        output = lines[1].strip() if len(lines) > 1 else ""

        # Handle dialog selections
        if dialog_state.is_dialog_selection(output.split("\t")[0] if output else ""):
            selected_value = output.split("\t")[0]
            return "dialog_selection", selected_value, query
    else:
        # Without --print-query: output is just the selection/command
        output = result.stdout.strip()
        query = ""

    if output == "QUIT":
        return "quit", None, query
    elif output == "REFRESH_ALL":
        return "refresh_all", None, query
    elif output.startswith("REFRESH "):
        repo_path = output[8:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "cancelled", None, query
        # Handle LAYER: prefix for expanded layer entries
        if repo_path.startswith("LAYER:"):
            layer_path = repo_path[6:]
            # Find the git repo for this layer
            try:
                repo_path = subprocess.check_output(
                    ["git", "-C", layer_path, "rev-parse", "--show-toplevel"],
                    text=True, stderr=subprocess.DEVNULL
                ).strip()
            except subprocess.CalledProcessError:
                repo_path = layer_path  # Fallback to layer path
        return "refresh", repo_path, query
    elif output == "VERBOSE":
        return "verbose", None, query
    elif output.startswith("REBASE "):
        repo_path = output[7:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "cancelled", None, query
        # Handle LAYER: prefix for expanded layer entries
        if repo_path.startswith("LAYER:"):
            layer_path = repo_path[6:]
            # Find the git repo for this layer
            try:
                repo_path = subprocess.check_output(
                    ["git", "-C", layer_path, "rev-parse", "--show-toplevel"],
                    text=True, stderr=subprocess.DEVNULL
                ).strip()
            except subprocess.CalledProcessError:
                repo_path = layer_path  # Fallback to layer path
        return "rebase", repo_path, query
    elif output.startswith("MERGE "):
        repo_path = output[6:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "cancelled", None, query
        # Handle LAYER: prefix for expanded layer entries
        if repo_path.startswith("LAYER:"):
            layer_path = repo_path[6:]
            # Find the git repo for this layer
            try:
                repo_path = subprocess.check_output(
                    ["git", "-C", layer_path, "rev-parse", "--show-toplevel"],
                    text=True, stderr=subprocess.DEVNULL
                ).strip()
            except subprocess.CalledProcessError:
                repo_path = layer_path  # Fallback to layer path
        return "merge", repo_path, query
    elif output.startswith("TIG "):
        repo_path = output[4:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "cancelled", None, query
        # Handle LAYER: prefix for expanded layer entries
        if repo_path.startswith("LAYER:"):
            layer_path = repo_path[6:]
            # Find the git repo for this layer
            try:
                repo_path = subprocess.check_output(
                    ["git", "-C", layer_path, "rev-parse", "--show-toplevel"],
                    text=True, stderr=subprocess.DEVNULL
                ).strip()
            except subprocess.CalledProcessError:
                repo_path = layer_path  # Fallback to layer path
        return "tig", repo_path, query
    elif output.startswith("ADD_TRACKED "):
        repo_path = output[12:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "cancelled", None, query
        # Handle LAYER: prefix for layers view
        if repo_path.startswith("LAYER:"):
            layer_path = repo_path[6:]
            # Find the git repo for this layer
            try:
                repo_path = subprocess.check_output(
                    ["git", "-C", layer_path, "rev-parse", "--show-toplevel"],
                    text=True, stderr=subprocess.DEVNULL
                ).strip()
            except subprocess.CalledProcessError:
                repo_path = layer_path  # Fallback to layer path
        return "add_tracked", repo_path, query
    elif output.startswith("HIDE "):
        repo_path = output[5:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "cancelled", None, query
        return "hide", repo_path, query
    elif output == "TOGGLE_HIDDEN":
        return "toggle_hidden", None, query
    elif output.startswith("ADD_LAYER "):
        repo_path = output[10:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "cancelled", None, query
        # Handle LAYER: prefix for expanded layer entries
        if repo_path.startswith("LAYER:"):
            return "add_layer", repo_path[6:], query  # Strip LAYER: prefix
        return "add_layer", repo_path, query
    elif output.startswith("REMOVE_LAYER "):
        repo_path = output[13:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "cancelled", None, query
        # Handle LAYER: prefix for expanded layer entries
        if repo_path.startswith("LAYER:"):
            return "remove_layer", repo_path[6:], query  # Strip LAYER: prefix
        return "remove_layer", repo_path, query
    elif output.startswith("EXPAND "):
        repo_path = output[7:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "expand_all", repo_path, query  # Expand/collapse all, preserve selection
        # Handle LAYER: prefix - expand parent repo instead
        if repo_path.startswith("LAYER:"):
            return "expand_all", repo_path, query  # On a layer, expand/collapse all, preserve selection
        return "expand", repo_path, query
    elif output == "LAYERS_TOGGLE":
        return "layers_toggle", None, query
    elif output == "DISCOVER_TOGGLE":
        return "discover_toggle", None, query
    elif output == "UPDATE_ALL":
        return "update_all", None, query
    elif output.startswith("BRANCH "):
        repo_path = output[7:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "cancelled", None, query
        if repo_path.startswith("LAYER:"):
            layer_path = repo_path[6:]
            try:
                repo_path = subprocess.check_output(
                    ["git", "-C", layer_path, "rev-parse", "--show-toplevel"],
                    text=True, stderr=subprocess.DEVNULL
                ).strip()
            except subprocess.CalledProcessError:
                repo_path = layer_path
        return "branch", repo_path, query
    elif output == "BRANCH_ALL":
        return "branch_all", None, query
    elif output == "SHELL":
        return "shell", None, query
    elif output.startswith("CONFIG "):
        repo_path = output[7:].strip()  # After "CONFIG "
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "cancelled", None, query
        # Handle LAYER: prefix for expanded layer entries
        if repo_path.startswith("LAYER:"):
            layer_path = repo_path[6:]
            # Find the git repo for this layer
            try:
                repo_path = subprocess.check_output(
                    ["git", "-C", layer_path, "rev-parse", "--show-toplevel"],
                    text=True, stderr=subprocess.DEVNULL
                ).strip()
            except subprocess.CalledProcessError:
                repo_path = layer_path  # Fallback to layer path
        return "config", repo_path, query

    # RIGHT arrow: expand if expandable, explore otherwise
    if output.startswith("RIGHT "):
        repo_path = output[6:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "cancelled", None, query
        if repo_path == "PROJECT":
            return "config", "PROJECT", query
        if repo_path == "INFO":
            return "info", None, query
        # LAYER: entries are already expanded - drill into them
        if repo_path.startswith("LAYER:"):
            repo_path = repo_path[6:]
            return "explore", repo_path, query
        # For repos, try expand first - caller will check if expandable
        return "right", repo_path, query

    # LEFT arrow: collapse if expanded, quit otherwise
    if output.startswith("LEFT "):
        repo_path = output[5:].strip()
        if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
            return "quit", None, query
        # LAYER: entries - collapse parent repo
        if repo_path.startswith("LAYER:"):
            return "left_layer", repo_path[6:], query
        # For repos, caller will check if expanded
        return "left", repo_path, query

    # Default: explore (Enter)
    # Extract repo path (first field before tab), ignore header/separator lines
    parts = output.split("\t", 1)
    repo_path = parts[0] if parts else None
    if repo_path == "HEADER" or repo_path.startswith("SEPARATOR"):
        return "cancelled", None, query
    # PROJECT entry: go to config instead of explore
    if repo_path == "PROJECT":
        return "config", "PROJECT", query
    # Handle LAYER: prefix from layers view - strip it to get layer path
    if repo_path and repo_path.startswith("LAYER:"):
        repo_path = repo_path[6:]
    return "explore", repo_path, query


def _format_refs(refs: List[Tuple[str, str]]) -> str:
    """Format ref decorations tig-style: [local] {remote} <tag>."""
    parts = []
    for name, rtype in refs:
        if rtype == "local":
            parts.append(f"[{name}]")
        elif rtype == "remote":
            parts.append(f"{{{name}}}")
        elif rtype == "tag":
            parts.append(f"<{name}>")
    return " ".join(parts)


def fzf_explore_commits(
    repo: str,
    branch: str,
    local_commits: List[Tuple[str, str]],
    upstream_context: List[Tuple[str, str]],
    upstream_to_pull: List[Tuple[str, str]],
    base_ref: str,
    is_dirty: bool = False,
    layer_filter: Optional[str] = None,
    layers: Optional[List[str]] = None,
    layer_counts: Optional[Dict[str, int]] = None,
    total_upstream: int = 0,
    context_limit: int = 0,
    scroll_to_context: int = 0,
) -> Tuple[str, List[str]]:
    """
    Browse commits with preview pane and optional range selection for export.
    Returns: (action, commit_hashes)
      action: "back", "quit", "copy", "export", "layer_view", etc.
      commit_hashes: list of commit hashes (for export may be multiple)
    """
    display_name = repo_display_name(repo)
    local_count = len(local_commits)

    # Build commit→refs map for decorations (one git call per ref namespace)
    commit_refs: Dict[str, List[Tuple[str, str]]] = {}
    for ref_glob, ref_type in [("refs/heads/", "local"), ("refs/remotes/", "remote"), ("refs/tags/", "tag")]:
        try:
            out = subprocess.check_output(
                ["git", "-C", repo, "for-each-ref",
                 "--format=%(objectname) %(refname:short)", ref_glob],
                text=True, stderr=subprocess.DEVNULL,
            ).strip()
            for line in out.splitlines():
                if not line:
                    continue
                sha, ref = line.split(" ", 1)
                commit_refs.setdefault(sha, []).append((ref, ref_type))
        except Exception:
            pass

    # Get actual upstream count (not limited by display cap)
    # When a layer filter is active, use the layer-specific count
    if layer_filter and layer_counts:
        upstream_count = layer_counts.get(layer_filter, len(upstream_to_pull))
    else:
        try:
            out = subprocess.check_output(
                ["git", "-C", repo, "rev-list", "--count", f"HEAD..{base_ref}"],
                text=True,
                stderr=subprocess.DEVNULL,
            )
            upstream_count = int(out.strip())
        except (subprocess.CalledProcessError, ValueError):
            upstream_count = len(upstream_to_pull)  # Fallback to displayed count

    # Build hash list for range filling and export (local + upstream)
    all_hashes = [h for h, _ in local_commits]
    all_upstream_hashes = [h for h, _ in upstream_to_pull] + [h for h, _ in upstream_context]

    # Build display: local commits + separator + upstream to pull + context
    # (reversed order because fzf shows last input at top)
    menu_lines = []

    # Upstream context commits (will appear at very bottom)
    if upstream_context:
        # "Load more" at the very bottom (added first, ends up last after reverse)
        if context_limit > 0 and len(upstream_context) >= context_limit:
            more_label = Colors.magenta("(load more history...)")
            menu_lines.append(f"LOAD_MORE\t   {more_label}")
        pull_hashes = {h for h, _ in upstream_to_pull}
        for hash_val, subject in reversed(upstream_context):
            if hash_val in pull_hashes:
                continue
            refs = commit_refs.get(hash_val, [])
            deco = _format_refs(refs)
            deco_str = f" {terminal_color('commit', deco)}" if deco else ""
            menu_lines.append(f"{hash_val[:12]}\t   {Colors.yellow(hash_val[:12])}{deco_str} {subject[:70]}")

    # Separator with base_ref (merge base between local and upstream)
    separator = f"──────────── {base_ref} ────────────"
    menu_lines.append(f"---\t{separator}")

    # Upstream commits to pull section
    if upstream_to_pull:
        # Show "load more" entry if there are more upstream commits than displayed
        showing_count = len(upstream_to_pull)
        has_more_upstream = upstream_count > showing_count
        if has_more_upstream:
            remaining = upstream_count - showing_count
            more_label = Colors.magenta(f"(load more... {remaining} remaining)")
            menu_lines.append(f"LOAD_MORE\t   {more_label}")
        for hash_val, subject in reversed(upstream_to_pull):
            refs = commit_refs.get(hash_val, [])
            deco = _format_refs(refs)
            deco_str = f" {terminal_color('commit', deco)}" if deco else ""
            menu_lines.append(f"{hash_val[:12]}\t   {Colors.cyan(hash_val[:12])}{deco_str} {subject[:70]}")
        menu_lines.append(f"---\t{'─' * 50}")
        if layer_filter:
            layer_name = os.path.basename(layer_filter)
            upstream_header = f"UPSTREAM ({upstream_count} to pull from {base_ref}, showing {showing_count} for {layer_name})"
        elif has_more_upstream:
            upstream_header = f"UPSTREAM ({upstream_count} to pull from {base_ref}, showing {showing_count})"
        else:
            upstream_header = f"UPSTREAM ({upstream_count} to pull from {base_ref})"
        menu_lines.append(f"---\t{Colors.cyan(upstream_header)}")
        menu_lines.append(f"---\t{'─' * 50}")

    # Local commits header
    local_header = f"LOCAL ({local_count} ahead of {base_ref})"
    menu_lines.append(f"---\t{Colors.bold(local_header)}")
    menu_lines.append(f"---\t{'─' * 50}")

    # Local commits (oldest first in input, so newest appears at top after fzf reversal)
    for hash_val, subject in local_commits:
        refs = commit_refs.get(hash_val, [])
        deco = _format_refs(refs)
        deco_str = f" {terminal_color('commit', deco)}" if deco else ""
        menu_lines.append(f"{hash_val[:12]}\t   {hash_val[:12]}{deco_str} {subject[:70]}")

    # Virtual "uncommitted changes" entry (before reverse, so it ends up at top)
    if is_dirty:
        dirty_label = Colors.red("*** uncommitted changes ***")
        menu_lines.append(f"DIRTY\t   {dirty_label}")

    # Reverse so newest-local is first in input; with --layout=reverse-list
    # first input item displays at top, preserving the same visual order.
    menu_lines.reverse()

    # Find initial cursor position (1-based)
    if scroll_to_context > 0:
        # Position at the first NEW context commit after loading more.
        # Context commits are at the bottom (after reverse), identified by
        # lines that are not separators, not LOAD_MORE, not DIRTY, and appear
        # after the base_ref separator.
        past_separator = False
        context_idx = 0
        first_commit_pos = None
        for i, line in enumerate(menu_lines):
            field = line.split("\t", 1)[0]
            if not past_separator:
                # Look for the base_ref separator
                if field == "---" and base_ref in line:
                    past_separator = True
                continue
            if field in ("---", "LOAD_MORE", "DIRTY"):
                continue
            context_idx += 1
            if context_idx == scroll_to_context + 1:
                first_commit_pos = i + 1
                break
        # Fallback: if we couldn't find the exact position, go to first commit
        if first_commit_pos is None:
            first_commit_pos = next(
                (i + 1 for i, line in enumerate(menu_lines) if not line.startswith("---\t")),
                None,
            )
    else:
        first_commit_pos = next(
            (i + 1 for i, line in enumerate(menu_lines) if not line.startswith("---\t")),
            None,
        )

    menu_input = "\n".join(menu_lines)

    # Temp files for state
    diff_file = f"/tmp/fzf_explore_diff_{os.getpid()}"
    range_file = f"/tmp/fzf_explore_range_{os.getpid()}"

    # Preview command - check for diff mode toggle
    preview_cmd = (
        f'hash={{1}}; '
        f'if [ "$hash" = "---" ]; then echo "Header line"; exit 0; fi; '
        f'if [ "$hash" = "LOAD_MORE" ]; then echo "Press Enter to load more commits"; exit 0; fi; '
        f'if [ "$hash" = "DIRTY" ]; then '
        f'if [ -f {diff_file} ]; then '
        f'git -C {repo} diff --color=always HEAD 2>/dev/null; '
        f'else '
        f'git -C {repo} diff --stat --color=always HEAD 2>/dev/null; '
        f'fi; exit 0; fi; '
        f'if [ -f {diff_file} ]; then '
        f'git -C {repo} show --color=always $hash 2>/dev/null || echo "No commit selected"; '
        f'else '
        f'git -C {repo} show --stat --color=always $hash 2>/dev/null || echo "No commit selected"; '
        f'fi'
    )

    # Dynamic prompt showing selection count
    prompt_script = (
        f'sel=0; rng=0; '
        f'[ -f {range_file} ] && rng=$(wc -l < {range_file}); '
        f'if [ $rng -gt 0 ]; then echo "Browse [range:$rng]: "; else echo "Browse: "; fi'
    )

    header = f"{get_project_header_prefix()}{Colors.bold(display_name)} ({local_count} local"
    if layer_filter:
        layer_name = os.path.basename(layer_filter)
        pull_count = len(upstream_to_pull)
        header += f", {Colors.cyan(f'{pull_count} to pull for {layer_name}')}"
    elif upstream_count > 0:
        header += f", {Colors.cyan(f'{upstream_count} to pull')}"
    header += f") on {Colors.bold(branch)}\n"
    keys = "Tab=mark | Space=range | ?=preview | d=diff | c=copy | e=export | D=drop | i=rebase | t=history | f=files"
    if layers and len(layers) > 1:
        keys += " | l=layers"
    keys += " | p=lore src | \u2190/b=back | q=quit"
    header += keys + "\n"
    header += get_preview_header_suffix()
    current_prompt = "Browse: "

    # Pad to fill terminal height so list top-aligns with preview top
    try:
        term_lines = os.get_terminal_size().lines
    except OSError:
        term_lines = 40
    header_line_count = header.count('\n') + 1
    chrome_lines = header_line_count + 2  # header + prompt + info line
    preview_arg = get_preview_window_arg("50%")
    if preview_arg.startswith("right"):
        available = term_lines - chrome_lines
    else:
        available = (term_lines // 2) - chrome_lines

    menu_line_count = menu_input.count('\n') + 1
    if menu_line_count < available:
        menu_input += "\n" + "\n".join("---\t" for _ in range(available - menu_line_count))

    try:
        fzf_cmd = [
            "fzf",
            "--no-sort",
            "--ansi",
            "--height", "100%",
            "--layout=reverse-list",
            "--header", header,
            "--prompt", current_prompt,
            "--with-nth", "2..",  # Display from field 2 onwards (hide hash field)
            "--delimiter", "\t",
            "--preview", preview_cmd,
            "--preview-window", get_preview_window_arg("50%"),
        ]

        fzf_cmd.append("--multi")
        # Standard bindings from fzf_bindings module
        fzf_cmd.extend(get_preview_toggle_binding())
        fzf_cmd.extend(get_preview_scroll_bindings())
        fzf_cmd.extend(get_toggle_binding())
        fzf_cmd.extend(get_exit_bindings(mode="back"))
        fzf_cmd.extend(get_action_binding("q", "QUIT"))
        # Custom bindings
        fzf_cmd.extend(["--bind", f"d:execute-silent(if [ -f {diff_file} ]; then rm {diff_file}; else touch {diff_file}; fi)+refresh-preview"])
        fzf_cmd.extend(["--bind", f"space:toggle+execute-silent(echo {{1}} >> {range_file})+transform-prompt({prompt_script})"])
        fzf_cmd.extend(get_action_binding("b", "BACK"))
        fzf_cmd.extend(get_action_binding("c", "COPY {1}"))
        fzf_cmd.extend(["--bind", "e:become(echo EXPORT {+1})"])  # {+1} = selected or current if none
        fzf_cmd.extend(["--bind", "D:become(echo DROP_COMMITS {+1})"])
        fzf_cmd.extend(get_action_binding("i", "REBASE_INTERACTIVE"))
        fzf_cmd.extend(get_action_binding("t", "TIG {1}"))
        if layers and len(layers) > 1:
            fzf_cmd.extend(get_action_binding("l", "LAYER_VIEW"))
        fzf_cmd.extend(["--bind", "f:become(echo TREE_MODE {1})"])
        fzf_cmd.extend(get_action_binding("p", "PATCH_LOOKUP {1}"))
        # Position binding
        if first_commit_pos:
            fzf_cmd.extend(get_position_binding(first_commit_pos))
        fzf_cmd.extend(get_fzf_preview_resize_bindings())
        fzf_cmd.extend(get_fzf_color_args())

        result = subprocess.run(
            fzf_cmd,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return "back", []

    # Read range markers before cleanup
    range_markers = []
    if os.path.exists(range_file):
        with open(range_file) as f:
            range_markers = [line.strip() for line in f if line.strip() and line.strip() != "---"]

    # Clean up temp files
    for f in [diff_file, range_file]:
        if os.path.exists(f):
            os.remove(f)

    if result.returncode != 0 or not result.stdout.strip():
        return "back", []

    output = result.stdout.strip()

    return _parse_commit_browser_output(output, all_hashes, all_upstream_hashes, range_markers)


def _parse_commit_browser_output(
    output: str,
    all_hashes: List[str],
    all_upstream_hashes: List[str],
    range_markers: List[str],
) -> Tuple[str, List[str]]:
    """Parse raw fzf output from the commit browser into (action, hashes)."""
    if output == "BACK":
        return "back", []
    elif output == "QUIT":
        return "quit", []
    elif output.startswith("COPY "):
        commit = output[5:].strip()
        return "copy", [commit] if commit and commit not in ("---", "DIRTY") else []
    elif output.startswith("EXPORT "):
        # May have multiple hashes separated by space
        hashes_str = output[7:].strip()
        hashes = [h for h in hashes_str.split() if h and h not in ("---", "DIRTY")]

        # If we have range markers, fill in the range
        if len(range_markers) >= 2:
            first_marker = range_markers[0]
            last_marker = range_markers[-1]
            try:
                idx1 = next(i for i, h in enumerate(all_hashes) if h.startswith(first_marker))
                idx2 = next(i for i, h in enumerate(all_hashes) if h.startswith(last_marker))
                start_idx, end_idx = min(idx1, idx2), max(idx1, idx2)
                range_hashes = all_hashes[start_idx:end_idx + 1]
                # Merge with individually selected
                all_selected = set(hashes) | set(range_hashes)
                # Return in original order (oldest first)
                hashes = [h for h in all_hashes if h in all_selected or any(h.startswith(sel) for sel in all_selected)]
            except StopIteration:
                pass

        # Filter to full hashes (check local and upstream)
        full_hashes = []
        combined_hashes = all_hashes + all_upstream_hashes
        for h in hashes:
            found = False
            for full_h in combined_hashes:
                if full_h.startswith(h):
                    if full_h not in full_hashes:
                        full_hashes.append(full_h)
                    found = True
                    break
            # If not found in our lists, it might be a full hash already
            if not found and len(h) >= 7:
                full_hashes.append(h)

        return "export", full_hashes
    elif output.startswith("DROP_COMMITS "):
        hashes_str = output[13:].strip()
        hashes = [h for h in hashes_str.split() if h and h not in ("---", "DIRTY")]

        # If we have range markers, fill in the range (local only)
        if len(range_markers) >= 2:
            first_marker = range_markers[0]
            last_marker = range_markers[-1]
            try:
                idx1 = next(i for i, h in enumerate(all_hashes) if h.startswith(first_marker))
                idx2 = next(i for i, h in enumerate(all_hashes) if h.startswith(last_marker))
                start_idx, end_idx = min(idx1, idx2), max(idx1, idx2)
                range_hashes = all_hashes[start_idx:end_idx + 1]
                all_selected = set(hashes) | set(range_hashes)
                hashes = [h for h in all_hashes if h in all_selected or any(h.startswith(sel) for sel in all_selected)]
            except StopIteration:
                pass

        # Filter to local hashes only
        full_hashes = []
        for h in hashes:
            for full_h in all_hashes:
                if full_h.startswith(h):
                    if full_h not in full_hashes:
                        full_hashes.append(full_h)
                    break

        return "drop_commits", full_hashes
    elif output.startswith("TIG "):
        commit = output[4:].strip()
        if commit and commit != "---":
            return "tig", [commit]
        return "tig", []
    elif output == "REBASE_INTERACTIVE":
        return "rebase_interactive", []
    elif output == "LAYER_VIEW":
        return "layer_view", []
    elif output.startswith("PATCH_LOOKUP"):
        parts = output.split(" ", 1)
        commit = parts[1].strip() if len(parts) > 1 else ""
        if commit in ("---", "DIRTY", "LOAD_MORE", ""):
            commit = ""
        return "patch_lookup", [commit] if commit else []
    elif output.startswith("TREE_MODE"):
        parts = output.split(" ", 1)
        commit = parts[1].strip() if len(parts) > 1 else ""
        # Skip non-commit identifiers
        if commit in ("---", "DIRTY", "LOAD_MORE", ""):
            commit = ""
        return "tree_mode", [commit] if commit else []
    elif output.startswith("LOAD_MORE"):
        return "load_more", []

    return "back", []


def _build_file_tree(file_list: List[str]) -> Dict[str, List[Tuple[str, bool]]]:
    """Build a tree structure from flat file paths.

    Returns dict mapping parent_path -> [(child_name, is_dir), ...] sorted
    dirs-first then alphabetical.  Root children are keyed by "".
    """
    dirs: Set[str] = set()
    children: Dict[str, Set[str]] = {}  # parent -> set of immediate child names

    for filepath in file_list:
        parts = filepath.split("/")
        # Register every directory level
        for i in range(len(parts) - 1):
            parent = "/".join(parts[:i]) if i > 0 else ""
            child_dir = parts[i]
            dir_path = "/".join(parts[: i + 1])
            dirs.add(dir_path)
            children.setdefault(parent, set()).add(child_dir)
        # Register the file itself under its parent
        parent = "/".join(parts[:-1]) if len(parts) > 1 else ""
        children.setdefault(parent, set()).add(parts[-1])

    # Convert to sorted list of (name, is_dir) tuples — dirs first, then alpha
    tree: Dict[str, List[Tuple[str, bool]]] = {}
    for parent, names in children.items():
        entries: List[Tuple[str, bool]] = []
        for name in names:
            full = f"{parent}/{name}" if parent else name
            entries.append((name, full in dirs))
        entries.sort(key=lambda e: (not e[1], e[0].lower()))
        tree[parent] = entries
    return tree


def _build_tree_menu_lines(
    tree: Dict[str, List[Tuple[str, bool]]],
    expanded_dirs: Set[str],
    expanded_files: Optional[Set[str]] = None,
    file_commits: Optional[Dict[str, List[Tuple[str, str]]]] = None,
    file_has_more: Optional[Dict[str, bool]] = None,
    highlight_files: Optional[Set[str]] = None,
) -> str:
    """Render tree structure as tab-separated menu lines for fzf.

    Each line: ``identifier\\tdisplay_text``
    Identifiers: ``DIR:path``, ``FILE:path``, ``COMMIT:hash:path``,
    or ``MORE:path``
    """
    if expanded_files is None:
        expanded_files = set()
    if file_commits is None:
        file_commits = {}
    if file_has_more is None:
        file_has_more = {}
    lines: List[str] = []

    def _render(parent: str, continuation: List[bool]) -> None:
        entries = tree.get(parent, [])
        for idx, (name, is_dir) in enumerate(entries):
            is_last = idx == len(entries) - 1
            # Build prefix from continuation stack
            prefix = ""
            for cont in continuation:
                prefix += "\u2502  " if cont else "   "
            connector = "\u2514\u2500 " if is_last else "\u251c\u2500 "

            full_path = f"{parent}/{name}" if parent else name

            if is_dir:
                expanded = full_path in expanded_dirs
                marker = "\u25be " if expanded else "\u25b6 "
                display = f"{prefix}{connector}{marker}{name}/"
                lines.append(f"DIR:{full_path}\t{display}")
                if expanded:
                    _render(full_path, continuation + [not is_last])
            else:
                file_expanded = full_path in expanded_files
                commits = file_commits.get(full_path, [])
                # Color the filename for highlighted (commit-modified) files
                if highlight_files and full_path in highlight_files:
                    colored_name = f"\033[33m{name}\033[0m"
                else:
                    colored_name = name
                if file_expanded:
                    marker = "\u25be " if commits else "\u25b6 "
                    display = f"{prefix}{connector}{marker}{colored_name}"
                else:
                    display = f"{prefix}{connector}  {colored_name}"
                lines.append(f"FILE:{full_path}\t{display}")
                if file_expanded:
                    # Render commit children
                    child_prefix = prefix + ("\u2502  " if not is_last else "   ")
                    has_more = file_has_more.get(full_path, False)
                    if commits:
                        for cidx, (chash, subject) in enumerate(commits):
                            c_is_last = cidx == len(commits) - 1 and not has_more
                            c_connector = "\u2514\u2500 " if c_is_last else "\u251c\u2500 "
                            short_hash = chash[:10]
                            trunc_subject = subject[:60]
                            c_display = f"{child_prefix}{c_connector}\033[33m{short_hash}\033[0m {trunc_subject}"
                            lines.append(f"COMMIT:{chash}:{full_path}\t{c_display}")
                        if has_more:
                            m_display = f"{child_prefix}\u2514\u2500 \033[35m(load more...)\033[0m"
                            lines.append(f"MORE:{full_path}\t{m_display}")
                    else:
                        c_display = f"{child_prefix}\u2514\u2500 (no commits)"
                        lines.append(f"COMMIT:none:{full_path}\t{c_display}")

    _render("", [])
    return "\n".join(lines)


def _build_layer_view_menu_lines(
    layers: List[str],
    expanded_layers: Set[str],
    layer_local_commits: Dict[str, List[Tuple[str, str]]],
    layer_upstream_commits: Dict[str, List[Tuple[str, str]]],
    layer_has_more: Optional[Dict[str, bool]] = None,
    layer_local_counts: Optional[Dict[str, int]] = None,
    layer_upstream_counts: Optional[Dict[str, int]] = None,
) -> str:
    """Render layer-grouped commit view as tab-separated menu lines for fzf.

    Each line: ``identifier\\tdisplay_text``
    Identifiers: ``LAYER:path``, ``LCOMMIT:hash:path``, ``UCOMMIT:hash:path``,
    ``LMORE:path``
    """
    if layer_has_more is None:
        layer_has_more = {}
    if layer_local_counts is None:
        layer_local_counts = {}
    if layer_upstream_counts is None:
        layer_upstream_counts = {}
    lines: List[str] = []

    for layer in layers:
        name = os.path.basename(layer)
        local_count = layer_local_counts.get(layer, len(layer_local_commits.get(layer, [])))
        upstream_count = layer_upstream_counts.get(layer, 0)
        expanded = layer in expanded_layers

        # Layer header line
        marker = "\u25be" if expanded else "\u25b8"
        count_parts = []
        if local_count > 0:
            count_parts.append(f"{local_count} local")
        if upstream_count > 0:
            count_parts.append(f"{upstream_count} to pull")
        count_str = f"({', '.join(count_parts)})" if count_parts else "(0 to pull)"
        display = f"{marker} {name:<30} {count_str}"
        lines.append(f"LAYER:{layer}\t{display}")

        if expanded:
            local_commits = layer_local_commits.get(layer, [])
            upstream_commits = layer_upstream_commits.get(layer, [])
            has_more = layer_has_more.get(layer, False)
            has_upstream = bool(upstream_commits)

            if not local_commits and not upstream_commits:
                # Empty layer — show placeholder
                lines.append(f"---\t  \u2514\u2500 \033[2m(no commits)\033[0m")
            else:
                # Local commits
                for cidx, (chash, subject) in enumerate(local_commits):
                    is_last = cidx == len(local_commits) - 1 and not has_upstream and not has_more
                    connector = "\u2514\u2500" if is_last else "\u251c\u2500"
                    short_hash = chash[:10]
                    trunc_subject = subject[:60]
                    c_display = f"  {connector} \033[33m{short_hash}\033[0m {trunc_subject}"
                    lines.append(f"LCOMMIT:{chash}:{layer}\t{c_display}")

                # Separator between local and upstream
                if local_commits and upstream_commits:
                    sep_display = f"  \u2502  \033[2m\u2500\u2500 to pull \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\033[0m"
                    lines.append(f"---\t{sep_display}")

                # Upstream commits
                for cidx, (chash, subject) in enumerate(upstream_commits):
                    is_last = cidx == len(upstream_commits) - 1 and not has_more
                    connector = "\u2514\u2500" if is_last else "\u251c\u2500"
                    short_hash = chash[:10]
                    trunc_subject = subject[:60]
                    c_display = f"  {connector} \033[36m{short_hash}\033[0m {trunc_subject}"
                    lines.append(f"UCOMMIT:{chash}:{layer}\t{c_display}")

                # Load more
                if has_more:
                    remaining = upstream_count - len(upstream_commits)
                    if remaining > 0:
                        m_display = f"  \u2514\u2500 \033[35m(load more... {remaining} remaining)\033[0m"
                    else:
                        m_display = f"  \u2514\u2500 \033[35m(load more...)\033[0m"
                    lines.append(f"LMORE:{layer}\t{m_display}")

    return "\n".join(lines)


def fzf_explore_tree(
    repo: str,
    branch: str,
    focus_commit: str = "",
) -> Tuple[str, List[str]]:
    """
    Browse repository files as a collapsible directory tree with preview.
    Returns: (action, file_paths)
      action: "back", "quit"
      file_paths: [file_path] if user pressed Enter on a file, [] otherwise
    """
    display_name = repo_display_name(repo)

    # Detect bat/batcat for syntax-highlighted file preview
    bat_cmd = shutil.which("bat") or shutil.which("batcat") or ""

    # Get file listing from git ls-tree (once)
    # Use focus_commit as ref when available so files it added are in the tree
    tree_ref = focus_commit or "HEAD"
    try:
        tree_output = subprocess.check_output(
            ["git", "-C", repo, "ls-tree", "-r", "--name-only", tree_ref],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return "back", []

    if not tree_output:
        return "back", []

    file_list = tree_output.splitlines()
    file_count = len(file_list)
    file_tree = _build_file_tree(file_list)

    # Temp files for preview mode toggles
    pid = os.getpid()
    diff_file = f"/tmp/fzf_explore_tree_diff_{pid}"
    blame_file = f"/tmp/fzf_explore_tree_blame_{pid}"
    file_mode_file = f"/tmp/fzf_explore_tree_filemode_{pid}"

    expanded_dirs: Set[str] = set()
    expanded_files: Set[str] = set()
    file_commits: Dict[str, List[Tuple[str, str]]] = {}
    file_commit_limits: Dict[str, int] = {}  # per-file commit limit
    file_has_more: Dict[str, bool] = {}  # whether more commits may exist
    next_selection: Optional[str] = None

    # Helper: load file commits with limit, track has_more
    def _load_file_commits(fpath: str) -> None:
        limit = file_commit_limits.get(fpath, 30)
        log_cmd = ["git", "-C", repo, "log", "--oneline", f"-{limit}"]
        if focus_commit:
            log_cmd.append(focus_commit)
        log_cmd.extend(["--", fpath])
        try:
            out = subprocess.check_output(
                log_cmd,
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip()
        except (subprocess.CalledProcessError, FileNotFoundError):
            out = ""
        commits: List[Tuple[str, str]] = []
        for cline in out.splitlines():
            if " " in cline:
                h, s = cline.split(" ", 1)
                commits.append((h, s))
            elif cline:
                commits.append((cline, ""))
        file_commits[fpath] = commits
        file_has_more[fpath] = len(commits) >= limit

    # Helper: expand file commits (lazy load + cache)
    def _expand_file(fpath: str) -> None:
        if fpath not in file_commits:
            _load_file_commits(fpath)
        expanded_files.add(fpath)

    # If a focus commit was given, get its modified files and pre-expand their dirs
    focus_files: Set[str] = set()
    if focus_commit:
        try:
            diff_out = subprocess.check_output(
                ["git", "-C", repo, "diff-tree", "--no-commit-id", "-r", "--name-only", focus_commit],
                text=True,
                stderr=subprocess.DEVNULL,
            ).strip()
            focus_files = set(diff_out.splitlines()) if diff_out else set()
        except (subprocess.CalledProcessError, FileNotFoundError):
            pass

        # Only keep files that exist in the tree
        focus_files &= set(file_list)

        # Expand all parent directories of modified files
        for fpath in focus_files:
            parts = fpath.split("/")
            for i in range(len(parts) - 1):
                expanded_dirs.add("/".join(parts[:i + 1]))

        # Expand modified files and pre-load their commit history
        for fpath in sorted(focus_files):
            _expand_file(fpath)

        # Position cursor at first modified file
        if focus_files:
            first_focus = sorted(focus_files)[0]
            next_selection = f"FILE:{first_focus}"

    # Preview command: dispatches on DIR:/FILE:/COMMIT: prefix
    # For COMMIT entries, id is COMMIT:hash:path — extract hash and path separately
    preview_cmd = (
        f'id={{1}}; '
        f'type=${{id%%:*}}; rest=${{id#*:}}; '
        f'if [ "$type" = "COMMIT" ]; then '
        f'hash=${{rest%%:*}}; path=${{rest#*:}}; '
        f'if [ -f {diff_file} ]; then '
        f'git -C {repo} show --color=always "$hash" 2>/dev/null || echo "No details"; '
        f'else '
        f'git -C {repo} show --stat --color=always "$hash" 2>/dev/null || echo "No details"; '
        f'fi; '
        f'elif [ "$type" = "MORE" ]; then '
        f'path="$rest"; '
        f'count=$(git -C {repo} log --oneline -- "$path" 2>/dev/null | wc -l); '
        f'shown=$(git -C {repo} log --oneline -1 -- "$path" 2>/dev/null | wc -l); '
        f'echo "Press Enter to load more commits for $path"; '
        f'echo "Total commits: $count"; '
        f'elif [ "$type" = "DIR" ]; then '
        f'path="$rest"; '
        f'git -C {repo} log --oneline --color=always -30 -- "$path/" 2>/dev/null || echo "No history"; '
        f'else '
        f'path="$rest"; '
        f'if [ -f {file_mode_file} ]; then '
        f'git -C {repo} show {tree_ref}:"$path" 2>/dev/null '
        f'{f"| {bat_cmd} --style=plain --color=always --file-name \"$path\" " if bat_cmd else ""}'
        f'|| echo "No file content available"; '
        f'elif [ -f {blame_file} ]; then '
        f'git -C {repo} blame --color-lines -- "$path" 2>/dev/null || echo "No blame available"; '
        f'elif [ -f {diff_file} ]; then '
        f'git -C {repo} log --color=always --stat -30 -- "$path" 2>/dev/null || echo "No history"; '
        f'else '
        f'git -C {repo} log --oneline --color=always -30 -- "$path" 2>/dev/null || echo "No history"; '
        f'fi; '
        f'fi'
    )

    try:
        while True:
            menu_input = _build_tree_menu_lines(file_tree, expanded_dirs, expanded_files, file_commits, file_has_more, highlight_files=focus_files)
            if not menu_input:
                return "back", []

            # Header — build per-mode variants for change-header
            header_line1 = f"{Colors.bold(display_name)} ({file_count} files) on {Colors.bold(branch)} [tree mode]"
            header_line3 = get_preview_header_suffix()
            keys_base = "Enter/\u2192=open | \u2190=collapse | \\=toggle"
            keys_tail = "p=lore | ?=preview | b=back | q=quit"
            header_log = f"{header_line1}\n{keys_base} | d=diff/stat | a=blame | f=file | {keys_tail} [log]\n{header_line3}"
            header_diff = f"{header_line1}\n{keys_base} | d=LOG | a=blame | f=file | {keys_tail} [diff/stat]\n{header_line3}"
            header_blame = f"{header_line1}\n{keys_base} | d=diff/stat | a=LOG | f=file | {keys_tail} [blame]\n{header_line3}"
            header_file = f"{header_line1}\n{keys_base} | d=diff/stat | a=blame | f=LOG | {keys_tail} [file]\n{header_line3}"

            # Preview window — add delay:1 debounce if fzf >= 0.53.0
            preview_win = get_preview_window_arg("50%")
            if get_fzf_version() >= (0, 53, 0):
                preview_win += ",delay:1"

            fzf_cmd = [
                "fzf",
                "--no-sort",
                "--ansi",
                "--height", "100%",
                "--layout=reverse-list",
                "--prompt", "Tree: ",
                "--header", header_log,
                "--preview", preview_cmd,
                "--preview-window", preview_win,
                "--with-nth", "2..",
                "--delimiter", "\t",
            ]
            # Keybindings: Enter returns {1}, arrows return tagged values
            fzf_cmd.extend(["--bind", "enter:become(echo ENTER {1})"])
            fzf_cmd.extend(get_action_binding("right", "RIGHT {1}"))
            fzf_cmd.extend(get_action_binding("left", "LEFT {1}"))
            fzf_cmd.extend(get_action_binding("\\", "TOGGLE {1}"))
            fzf_cmd.extend(get_action_binding("b", "BACK"))
            fzf_cmd.extend(get_action_binding("q", "QUIT"))
            fzf_cmd.extend(get_action_binding("p", "PATCH_LOOKUP {1}"))
            # d/a/f: toggle preview modes with dynamic header updates
            fzf_cmd.extend(["--bind", f"d:execute-silent(if [ -f {diff_file} ]; then rm {diff_file}; else touch {diff_file}; rm -f {blame_file} {file_mode_file}; fi)+refresh-preview+transform-header(if [ -f {diff_file} ]; then echo {shlex.quote(header_diff)}; else echo {shlex.quote(header_log)}; fi)"])
            fzf_cmd.extend(["--bind", f"a:execute-silent(if [ -f {blame_file} ]; then rm {blame_file}; else touch {blame_file}; rm -f {diff_file} {file_mode_file}; fi)+refresh-preview+transform-header(if [ -f {blame_file} ]; then echo {shlex.quote(header_blame)}; else echo {shlex.quote(header_log)}; fi)"])
            fzf_cmd.extend(["--bind", f"f:execute-silent(if [ -f {file_mode_file} ]; then rm {file_mode_file}; else touch {file_mode_file}; rm -f {diff_file} {blame_file}; fi)+refresh-preview+transform-header(if [ -f {file_mode_file} ]; then echo {shlex.quote(header_file)}; else echo {shlex.quote(header_log)}; fi)"])
            fzf_cmd.extend(get_preview_toggle_binding())
            fzf_cmd.extend(get_preview_scroll_bindings())
            fzf_cmd.extend(["--bind", "esc:become(echo BACK)"])
            fzf_cmd.extend(get_fzf_preview_resize_bindings())
            fzf_cmd.extend(get_fzf_color_args())

            # Position cursor if we have a selection to restore
            if next_selection:
                menu_lines = menu_input.split("\n")
                target_line = None
                for i, line in enumerate(menu_lines):
                    if line.startswith(next_selection + "\t"):
                        target_line = i + 1
                        break
                # Fallback: if entry collapsed away, find parent
                if target_line is None and ":" in next_selection:
                    sel_type = next_selection.split(":")[0]
                    if sel_type == "COMMIT":
                        # COMMIT:hash:path — find parent FILE:path
                        sel_rest = next_selection.split(":", 1)[1]
                        sel_file = sel_rest.split(":", 1)[1] if ":" in sel_rest else ""
                        if sel_file:
                            parent_key = f"FILE:{sel_file}"
                            for i, line in enumerate(menu_lines):
                                if line.startswith(parent_key + "\t"):
                                    target_line = i + 1
                                    break
                    elif sel_type == "MORE":
                        # MORE:path — find parent FILE:path
                        sel_file = next_selection.split(":", 1)[1]
                        if sel_file:
                            parent_key = f"FILE:{sel_file}"
                            for i, line in enumerate(menu_lines):
                                if line.startswith(parent_key + "\t"):
                                    target_line = i + 1
                                    break
                    if target_line is None:
                        # Fall back to parent DIR
                        sel_path = next_selection.split(":", 1)[1]
                        # For COMMIT entries, use the file path portion
                        if sel_type == "COMMIT" and ":" in sel_path:
                            sel_path = sel_path.split(":", 1)[1]
                        parent_path = "/".join(sel_path.split("/")[:-1]) if "/" in sel_path else ""
                        if parent_path:
                            parent_key = f"DIR:{parent_path}"
                            for i, line in enumerate(menu_lines):
                                if line.startswith(parent_key + "\t"):
                                    target_line = i + 1
                                    break
                if target_line:
                    fzf_cmd.extend(get_position_binding(target_line))
                next_selection = None

            try:
                result = subprocess.run(
                    fzf_cmd,
                    input=menu_input,
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                return "back", []

            if result.returncode != 0 or not result.stdout.strip():
                return "back", []

            output = result.stdout.strip()

            if output == "BACK":
                return "back", []
            elif output == "QUIT":
                return "quit", []

            # Parse action and identifier
            parts = output.split(" ", 1)
            action = parts[0]
            entry_id = parts[1] if len(parts) > 1 else ""
            entry_type = entry_id.split(":")[0] if ":" in entry_id else ""
            entry_path = entry_id.split(":", 1)[1] if ":" in entry_id else ""
            # For COMMIT:hash:path, extract hash and file path separately
            commit_hash = ""
            commit_file_path = ""
            if entry_type == "COMMIT":
                commit_parts = entry_path.split(":", 1)
                commit_hash = commit_parts[0]
                commit_file_path = commit_parts[1] if len(commit_parts) > 1 else ""

            if action == "ENTER":
                if entry_type == "DIR":
                    # Toggle expand/collapse
                    if entry_path in expanded_dirs:
                        expanded_dirs.discard(entry_path)
                    else:
                        expanded_dirs.add(entry_path)
                    next_selection = entry_id
                    continue
                elif entry_type == "FILE":
                    # Toggle file commit expansion
                    if entry_path in expanded_files:
                        expanded_files.discard(entry_path)
                    else:
                        _expand_file(entry_path)
                    next_selection = entry_id
                    continue
                elif entry_type == "COMMIT":
                    # No-op — just preview
                    next_selection = entry_id
                    continue
                elif entry_type == "MORE":
                    # Double limit and reload
                    cur = file_commit_limits.get(entry_path, 30)
                    file_commit_limits[entry_path] = cur * 2
                    _load_file_commits(entry_path)
                    next_selection = entry_id
                    continue

            elif action == "RIGHT":
                if entry_type == "DIR":
                    if entry_path not in expanded_dirs:
                        expanded_dirs.add(entry_path)
                    else:
                        # Already expanded — toggle
                        expanded_dirs.discard(entry_path)
                    next_selection = entry_id
                    continue
                elif entry_type == "FILE":
                    # Expand file commits
                    if entry_path not in expanded_files:
                        _expand_file(entry_path)
                    next_selection = entry_id
                    continue
                elif entry_type == "COMMIT":
                    # No-op
                    next_selection = entry_id
                    continue
                elif entry_type == "MORE":
                    # Double limit and reload
                    cur = file_commit_limits.get(entry_path, 30)
                    file_commit_limits[entry_path] = cur * 2
                    _load_file_commits(entry_path)
                    next_selection = entry_id
                    continue

            elif action == "LEFT":
                if entry_type == "DIR":
                    if entry_path in expanded_dirs:
                        # Collapse this dir
                        expanded_dirs.discard(entry_path)
                        next_selection = entry_id
                        continue
                    else:
                        # Move to parent dir
                        if "/" in entry_path:
                            parent = "/".join(entry_path.split("/")[:-1])
                            next_selection = f"DIR:{parent}"
                            continue
                        else:
                            # Root-level dir, go back
                            return "back", []
                elif entry_type == "FILE":
                    if entry_path in expanded_files:
                        # Collapse file commits
                        expanded_files.discard(entry_path)
                        next_selection = entry_id
                        continue
                    else:
                        # Collapse parent dir; if root-level file, go back
                        if "/" in entry_path:
                            parent = "/".join(entry_path.split("/")[:-1])
                            expanded_dirs.discard(parent)
                            next_selection = f"DIR:{parent}"
                            continue
                        else:
                            return "back", []
                elif entry_type == "COMMIT":
                    # Collapse parent file's commit list
                    expanded_files.discard(commit_file_path)
                    next_selection = f"FILE:{commit_file_path}"
                    continue
                elif entry_type == "MORE":
                    # Collapse parent file's commit list
                    expanded_files.discard(entry_path)
                    next_selection = f"FILE:{entry_path}"
                    continue

            elif action == "TOGGLE":
                if entry_type == "DIR":
                    if entry_path in expanded_dirs:
                        expanded_dirs.discard(entry_path)
                    else:
                        expanded_dirs.add(entry_path)
                    next_selection = entry_id
                    continue
                elif entry_type == "FILE":
                    # Toggle file commit expansion
                    if entry_path in expanded_files:
                        expanded_files.discard(entry_path)
                    else:
                        _expand_file(entry_path)
                    next_selection = entry_id
                    continue
                elif entry_type == "MORE":
                    # Double limit and reload
                    cur = file_commit_limits.get(entry_path, 30)
                    file_commit_limits[entry_path] = cur * 2
                    _load_file_commits(entry_path)
                    next_selection = entry_id
                    continue
                elif entry_type == "COMMIT":
                    # No-op
                    next_selection = entry_id
                    continue

            elif action == "PATCH_LOOKUP":
                if entry_type == "FILE":
                    from .b4 import b4_file_lookup
                    b4_file_lookup(repo, entry_path)
                elif entry_type == "COMMIT":
                    from .b4 import b4_patch_lookup
                    b4_patch_lookup(repo, commit_hash)
                next_selection = entry_id
                continue

            # Fallback
            return "back", []
    finally:
        # Cleanup temp files
        for f in [diff_file, blame_file, file_mode_file]:
            if os.path.exists(f):
                os.remove(f)


def fzf_explore_layer_view(
    repo: str,
    branch: str,
    layers: List[str],
    layer_counts: Dict[str, int],
) -> Tuple[str, List[str]]:
    """Browse commits grouped by layer with collapsible expand/collapse.

    Returns: (action, [])
      action: "back" or "quit"
    """
    display_name = repo_display_name(repo)

    # Temp file for diff/stat toggle
    pid = os.getpid()
    diff_file = f"/tmp/fzf_explore_layer_view_diff_{pid}"

    # Internal state
    expanded_layers: Set[str] = set()
    layer_local_commits: Dict[str, List[Tuple[str, str]]] = {}
    layer_upstream_commits: Dict[str, List[Tuple[str, str]]] = {}
    layer_commit_limits: Dict[str, int] = {}
    layer_has_more: Dict[str, bool] = {}
    layer_local_counts: Dict[str, int] = {}
    next_selection: Optional[str] = None

    # Pre-compute local commit counts for all layers (fast — small number of layers)
    for layer in layers:
        commits, _ = get_local_commits_for_layer(repo, branch, layer)
        layer_local_commits[layer] = commits if commits else []
        layer_local_counts[layer] = len(layer_local_commits[layer])

    # Helper: load upstream commits for a layer with limit
    def _load_upstream(layer: str) -> None:
        limit = layer_commit_limits.get(layer, 20)
        upstream = get_upstream_to_pull_for_layer(repo, branch, layer, count=limit)
        layer_upstream_commits[layer] = upstream
        total = layer_counts.get(layer, 0)
        layer_has_more[layer] = len(upstream) >= limit and len(upstream) < total

    # Helper: expand a layer (lazy load upstream on first expand)
    def _expand_layer(layer: str) -> None:
        if layer not in layer_upstream_commits:
            _load_upstream(layer)
        expanded_layers.add(layer)

    # Preview command: dispatches on prefix
    preview_cmd = (
        f'id={{1}}; '
        f'type=${{id%%:*}}; rest=${{id#*:}}; '
        f'if [ "$type" = "LCOMMIT" ] || [ "$type" = "UCOMMIT" ]; then '
        f'hash=${{rest%%:*}}; '
        f'if [ -f {diff_file} ]; then '
        f'git -C {repo} show --color=always "$hash" 2>/dev/null || echo "No details"; '
        f'else '
        f'git -C {repo} show --stat --color=always "$hash" 2>/dev/null || echo "No details"; '
        f'fi; '
        f'elif [ "$type" = "LAYER" ]; then '
        f'path="$rest"; '
        f'relpath=$(python3 -c "import os; print(os.path.relpath(\\"$path\\", \\"{repo}\\"))"); '
        f'git -C {repo} log --oneline --color=always -20 -- "$relpath/" 2>/dev/null || echo "No history"; '
        f'elif [ "$type" = "LMORE" ]; then '
        f'echo "Press Enter to load more upstream commits"; '
        f'else '
        f'echo ""; '
        f'fi'
    )

    try:
        while True:
            menu_input = _build_layer_view_menu_lines(
                layers, expanded_layers,
                layer_local_commits, layer_upstream_commits,
                layer_has_more, layer_local_counts, layer_counts,
            )
            if not menu_input:
                return "back", []

            # Header
            total_local = sum(layer_local_counts.get(l, 0) for l in layers)
            total_upstream = sum(layer_counts.get(l, 0) for l in layers)
            header_line1 = f"{Colors.bold(display_name)} ({total_local} local, {Colors.cyan(f'{total_upstream} to pull')}) on {Colors.bold(branch)} [layers]"
            keys = "Enter/\u2192=open | \u2190=collapse | \\=toggle | d=diff/stat | ?=preview | l/b=back | q=quit"
            header_line3 = get_preview_header_suffix()
            header = f"{header_line1}\n{keys}\n{header_line3}"

            # Preview window
            preview_win = get_preview_window_arg("50%")
            if get_fzf_version() >= (0, 53, 0):
                preview_win += ",delay:1"

            fzf_cmd = [
                "fzf",
                "--no-sort",
                "--ansi",
                "--height", "100%",
                "--layout=reverse-list",
                "--prompt", "Layers: ",
                "--header", header,
                "--preview", preview_cmd,
                "--preview-window", preview_win,
                "--with-nth", "2..",
                "--delimiter", "\t",
            ]
            # Keybindings
            fzf_cmd.extend(["--bind", "enter:become(echo ENTER {1})"])
            fzf_cmd.extend(get_action_binding("right", "RIGHT {1}"))
            fzf_cmd.extend(get_action_binding("left", "LEFT {1}"))
            fzf_cmd.extend(get_action_binding("\\", "TOGGLE {1}"))
            fzf_cmd.extend(get_action_binding("b", "BACK"))
            fzf_cmd.extend(get_action_binding("l", "BACK"))
            fzf_cmd.extend(get_action_binding("q", "QUIT"))
            fzf_cmd.extend(["--bind", f"d:execute-silent(if [ -f {diff_file} ]; then rm {diff_file}; else touch {diff_file}; fi)+refresh-preview"])
            fzf_cmd.extend(get_preview_toggle_binding())
            fzf_cmd.extend(get_preview_scroll_bindings())
            fzf_cmd.extend(["--bind", "esc:become(echo BACK)"])
            fzf_cmd.extend(get_fzf_preview_resize_bindings())
            fzf_cmd.extend(get_fzf_color_args())

            # Position cursor
            if next_selection:
                menu_lines = menu_input.split("\n")
                target_line = None
                for i, line in enumerate(menu_lines):
                    if line.startswith(next_selection + "\t"):
                        target_line = i + 1
                        break
                # Fallback: if entry collapsed away, find parent LAYER
                if target_line is None and ":" in next_selection:
                    sel_type = next_selection.split(":")[0]
                    if sel_type in ("LCOMMIT", "UCOMMIT"):
                        # LCOMMIT:hash:path or UCOMMIT:hash:path — find parent LAYER:path
                        sel_rest = next_selection.split(":", 1)[1]
                        sel_layer = sel_rest.split(":", 1)[1] if ":" in sel_rest else ""
                        if sel_layer:
                            parent_key = f"LAYER:{sel_layer}"
                            for i, line in enumerate(menu_lines):
                                if line.startswith(parent_key + "\t"):
                                    target_line = i + 1
                                    break
                    elif sel_type == "LMORE":
                        # LMORE:path — find parent LAYER:path
                        sel_layer = next_selection.split(":", 1)[1]
                        if sel_layer:
                            parent_key = f"LAYER:{sel_layer}"
                            for i, line in enumerate(menu_lines):
                                if line.startswith(parent_key + "\t"):
                                    target_line = i + 1
                                    break
                if target_line:
                    fzf_cmd.extend(get_position_binding(target_line))
                next_selection = None

            try:
                result = subprocess.run(
                    fzf_cmd,
                    input=menu_input,
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                return "back", []

            if result.returncode != 0 or not result.stdout.strip():
                return "back", []

            output = result.stdout.strip()

            if output == "BACK":
                return "back", []
            elif output == "QUIT":
                return "quit", []

            # Parse action and identifier
            parts = output.split(" ", 1)
            action = parts[0]
            entry_id = parts[1] if len(parts) > 1 else ""
            entry_type = entry_id.split(":")[0] if ":" in entry_id else ""
            entry_rest = entry_id.split(":", 1)[1] if ":" in entry_id else ""

            # For LCOMMIT/UCOMMIT entries: hash:layer_path
            commit_hash = ""
            commit_layer = ""
            if entry_type in ("LCOMMIT", "UCOMMIT"):
                cparts = entry_rest.split(":", 1)
                commit_hash = cparts[0]
                commit_layer = cparts[1] if len(cparts) > 1 else ""

            if action in ("ENTER", "RIGHT"):
                if entry_type == "LAYER":
                    # Toggle expand/collapse
                    if entry_rest in expanded_layers:
                        expanded_layers.discard(entry_rest)
                    else:
                        _expand_layer(entry_rest)
                    next_selection = entry_id
                    continue
                elif entry_type in ("LCOMMIT", "UCOMMIT"):
                    # No-op — just preview
                    next_selection = entry_id
                    continue
                elif entry_type == "LMORE":
                    # Double limit and reload upstream
                    layer = entry_rest
                    cur = layer_commit_limits.get(layer, 20)
                    layer_commit_limits[layer] = cur * 2
                    _load_upstream(layer)
                    next_selection = entry_id
                    continue

            elif action == "LEFT":
                if entry_type == "LAYER":
                    if entry_rest in expanded_layers:
                        expanded_layers.discard(entry_rest)
                        next_selection = entry_id
                        continue
                    else:
                        # Already collapsed — back
                        return "back", []
                elif entry_type in ("LCOMMIT", "UCOMMIT"):
                    # Collapse parent layer
                    if commit_layer:
                        expanded_layers.discard(commit_layer)
                        next_selection = f"LAYER:{commit_layer}"
                        continue
                elif entry_type == "LMORE":
                    # Collapse parent layer
                    expanded_layers.discard(entry_rest)
                    next_selection = f"LAYER:{entry_rest}"
                    continue

            elif action == "TOGGLE":
                if entry_type == "LAYER":
                    if entry_rest in expanded_layers:
                        expanded_layers.discard(entry_rest)
                    else:
                        _expand_layer(entry_rest)
                    next_selection = entry_id
                    continue
                elif entry_type in ("LCOMMIT", "UCOMMIT"):
                    next_selection = entry_id
                    continue
                elif entry_type == "LMORE":
                    cur = layer_commit_limits.get(entry_rest, 20)
                    layer_commit_limits[entry_rest] = cur * 2
                    _load_upstream(entry_rest)
                    next_selection = entry_id
                    continue

            # Fallback
            return "back", []
    finally:
        if os.path.exists(diff_file):
            os.remove(diff_file)


def text_select_insertion_point(
    repo: str,
    branch: str,
    base_ref: str,
    remaining_commits: List[Tuple[str, str]],
) -> Optional[str]:
    """Text-based insertion point selection."""
    display_name = repo_display_name(repo)

    # Get upstream commits for context
    upstream_commits = get_upstream_context_commits(repo, base_ref)

    print(f"\nSelect insertion point for {Colors.bold(display_name)}:")
    print("(upstream commits will be placed AFTER the selected point)")
    print()

    # Local commits newest first (reversed), with index numbers
    if remaining_commits:
        for idx, (hash_val, subject) in enumerate(reversed(remaining_commits), 1):
            print(f"  {idx}. {hash_val[:12]} {subject[:60]}")

    # Separator and default
    print("  ────────────────────────────────────────")
    print(f"  0. {base_ref} (default - insert here)")

    # Upstream context
    if upstream_commits:
        for hash_val, subject in upstream_commits:
            print(f"     {hash_val[:12]} {subject[:60]}")

    print()

    try:
        choice = input("Selection [0]: ").strip()
    except EOFError:
        return None

    if not choice or choice == "0":
        return base_ref

    try:
        idx = int(choice)
        if 1 <= idx <= len(remaining_commits):
            # Convert from display order (newest first) to storage order (oldest first)
            real_idx = len(remaining_commits) - idx
            return remaining_commits[real_idx][0]
    except ValueError:
        pass

    return base_ref  # Default on invalid input



def text_multiselect_commits(
    repo: str,
    branch: str,
    commits: List[Tuple[str, str]]
) -> Optional[Tuple[List[str], str]]:
    """Text-based commit selection fallback."""
    if not commits:
        return ([], "skip")

    display_name = repo_display_name(repo)
    print(f"\n{Colors.bold(display_name)} on {Colors.bold(branch)}")
    print(f"Local commits ({len(commits)}):")

    # Display newest-first with indices (user sees 1=newest)
    for idx, (hash_val, subject) in enumerate(reversed(commits), 1):
        print(f"  {idx:3}. {hash_val[:12]} {subject[:60]}")

    print()
    print("Enter commit numbers for UPSTREAM (comma-separated, e.g., 1,3,5)")
    print("  'a' = all, 's' = skip repo, 'S' = skip remaining repos, 'q' = quit")

    try:
        choice = input("Selection: ").strip()
    except EOFError:
        return None

    if not choice or choice.lower() == 's':
        return ([], "skip")
    if choice == 'S':
        return ([], "skip_rest")
    if choice.lower() == 'q':
        return None
    if choice.lower() == 'a':
        return ([h for h, _ in commits], "selected")

    # Parse indices
    try:
        indices = [int(x.strip()) for x in choice.split(',') if x.strip()]
        # Convert to 0-based, accounting for reversed display
        n = len(commits)
        selected_hashes = []
        for idx in indices:
            if 1 <= idx <= n:
                # idx 1 = newest = commits[n-1], idx n = oldest = commits[0]
                real_idx = n - idx
                selected_hashes.append(commits[real_idx][0])
        # Return in original order (oldest first)
        selected_ordered = [h for h, _ in commits if h in selected_hashes]
        return (selected_ordered, "selected")
    except ValueError:
        print("Invalid input, skipping repo.")
        return ([], "skip")


def fzf_select_rebase_range(
    repo: str,
    branch: str,
    commits: List[Tuple[str, str]],
    base_ref: str,
) -> Optional[str]:
    """
    Show commit browser for selecting rebase range.

    User marks commits with Space (range) or Tab (individual). The rebase will
    include all commits from the oldest selected to HEAD.

    Returns the rebase base (parent of oldest selected commit), or None if cancelled.
    """
    if not commits:
        return None

    display_name = repo_display_name(repo)

    # Get upstream context commits
    upstream_commits = get_upstream_context_commits(repo, base_ref, count=3)

    # Build menu: upstream context -> separator -> local commits (reversed for fzf)
    menu_lines = []

    # Upstream commits for context (will appear at bottom)
    if upstream_commits:
        for hash_val, subject in reversed(upstream_commits):
            dimmed = Colors.dim(f"   {hash_val[:12]} {subject[:70]}")
            menu_lines.append(f"---\t{dimmed}")

    # Separator with base_ref
    separator = f"──────────── {base_ref} ────────────"
    menu_lines.append(f"---\t{separator}")

    # Local commits (oldest first, so newest at top after reversal)
    for hash_val, subject in commits:
        menu_lines.append(f"{hash_val[:12]}\t   {hash_val[:12]} {subject[:70]}")

    menu_lines.reverse()
    menu_input = "\n".join(menu_lines)

    header = f"{Colors.bold(display_name)} on {Colors.bold(branch)}\n"
    header += f"Select commits to include in interactive rebase ({len(commits)} local)\n"
    header += "Space=range | Tab=single | Enter=confirm | Esc/b=cancel\n"
    header += "Rebase will include selected commits through HEAD"

    # Temp file for range tracking
    range_file = f"/tmp/fzf_rebase_range_{os.getpid()}"
    if os.path.exists(range_file):
        os.remove(range_file)

    # Dynamic prompt showing range bounds in yellow
    # ANSI: \033[33m = yellow, \033[0m = reset
    prompt_script = (
        f'if [ -f {range_file} ]; then '
        f'first=$(head -1 {range_file}); last=$(tail -1 {range_file}); '
        f'if [ -n "$first" ]; then '
        f'printf "Rebase \\033[33m[%s..%s]\\033[0m: " "$first" "$last"; '
        f'else echo "Rebase: "; fi; '
        f'else echo "Rebase: "; fi'
    )

    # Preview command
    preview_cmd = (
        f'hash={{1}}; '
        f'if [ "$hash" = "---" ]; then echo "Context commit"; exit 0; fi; '
        f'git -C {repo} show --stat --color=always $hash 2>/dev/null || echo "Select a commit"'
    )

    try:
        fzf_cmd = [
            "fzf",
            "--multi",
            "--no-sort",
            "--ansi",
            "--height", "100%",
            "--layout=reverse-list",
            "--header", header,
            "--prompt", "Rebase: ",
            "--with-nth", "2..",
            "--delimiter", "\t",
            "--preview", preview_cmd,
            "--preview-window", get_preview_window_arg("50%"),
        ]
        # Standard bindings from fzf_bindings module
        fzf_cmd.extend(get_preview_toggle_binding())
        fzf_cmd.extend(get_preview_scroll_bindings())
        fzf_cmd.extend(get_toggle_binding())
        fzf_cmd.extend(get_exit_bindings(mode="back", back_value="CANCEL"))
        # Custom bindings
        fzf_cmd.extend(["--bind", f"space:toggle+execute-silent(echo {{1}} >> {range_file})+transform-prompt({prompt_script})"])
        fzf_cmd.extend(get_action_binding("b", "CANCEL"))
        fzf_cmd.extend(get_fzf_preview_resize_bindings())
        fzf_cmd.extend(get_fzf_color_args())

        result = subprocess.run(
            fzf_cmd,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        print("fzf not found")
        return None

    # Read range markers
    range_markers = []
    if os.path.exists(range_file):
        with open(range_file) as f:
            range_markers = [line.strip() for line in f if line.strip() and line.strip() != "---"]
        os.remove(range_file)

    if result.returncode != 0 or not result.stdout.strip():
        return None

    output = result.stdout.strip()
    if output == "CANCEL":
        return None

    # Collect selected commits from output and range markers
    selected_short = set()

    # From direct selection (tab)
    for line in output.strip().split('\n'):
        if line and not line.startswith("---"):
            parts = line.split('\t')
            if parts:
                selected_short.add(parts[0].strip())

    # From range markers (space)
    selected_short.update(range_markers)

    if not selected_short:
        return None

    # Find the oldest selected commit to determine rebase base
    all_hashes = [h for h, _ in commits]
    oldest_idx = len(all_hashes)  # Start past end

    for short_hash in selected_short:
        for i, full_hash in enumerate(all_hashes):
            if full_hash.startswith(short_hash):
                if i < oldest_idx:
                    oldest_idx = i
                break

    if oldest_idx >= len(all_hashes):
        return None

    # Rebase base is the parent of the oldest selected commit
    oldest_commit = all_hashes[oldest_idx]
    if oldest_idx == 0:
        # Oldest selected is the first local commit, use base_ref
        rebase_base = base_ref
    else:
        # Use the commit before the oldest selected
        rebase_base = f"{oldest_commit}^"

    return rebase_base


def interactive_rebase_with_backup(
    repo: str,
    rebase_base: str,
    branch: str,
) -> Tuple[bool, str]:
    """
    Run git rebase -i with automatic backup and confirmation.

    Creates a backup branch before rebasing. After rebase completes (or fails),
    shows before/after comparison and asks user to confirm. If user declines,
    restores from backup.

    Args:
        repo: Path to the repository
        rebase_base: The commit to rebase onto (parent of first commit to edit)
        branch: Current branch name (for backup naming)

    Returns (success, message).
    """
    display_name = repo_display_name(repo)

    # Create backup branch
    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_branch = f"{branch}-backup-{timestamp}"

    try:
        subprocess.run(
            ["git", "-C", repo, "branch", backup_branch],
            check=True, capture_output=True
        )
    except subprocess.CalledProcessError as e:
        return False, f"Failed to create backup branch: {e}"

    # Get old commit list for comparison
    try:
        old_commits = subprocess.check_output(
            ["git", "-C", repo, "log", "--oneline", f"{rebase_base}..HEAD"],
            text=True
        ).strip()
    except subprocess.CalledProcessError:
        old_commits = ""

    # Run interactive rebase (inherits terminal for editor)
    print(f"\nStarting interactive rebase for {display_name}...")
    print(f"Backup branch: {backup_branch}")
    print()
    result = subprocess.run(["git", "-C", repo, "rebase", "-i", rebase_base])

    if result.returncode != 0:
        # Rebase failed or was aborted - check if we're mid-rebase
        rebase_dir = os.path.join(repo, ".git", "rebase-merge")
        rebase_apply_dir = os.path.join(repo, ".git", "rebase-apply")
        if os.path.isdir(rebase_dir) or os.path.isdir(rebase_apply_dir):
            print("\nRebase in progress. Aborting...")
            subprocess.run(["git", "-C", repo, "rebase", "--abort"], capture_output=True)

        # Restore from backup
        subprocess.run(["git", "-C", repo, "reset", "--hard", backup_branch], check=True, capture_output=True)
        subprocess.run(["git", "-C", repo, "branch", "-D", backup_branch], capture_output=True)
        return False, "Rebase aborted, restored from backup"

    # Get new commit list
    try:
        new_commits = subprocess.check_output(
            ["git", "-C", repo, "log", "--oneline", f"{rebase_base}..HEAD"],
            text=True
        ).strip()
    except subprocess.CalledProcessError:
        new_commits = ""

    # Show side-by-side comparison
    old_lines = old_commits.splitlines() if old_commits else []
    new_lines = new_commits.splitlines() if new_commits else []
    max_lines = max(len(old_lines), len(new_lines))

    # Get terminal width for column sizing
    try:
        term_width = os.get_terminal_size().columns
    except OSError:
        term_width = 80
    col_width = (term_width - 7) // 2  # 7 = " │ " separator + margins

    # Print header
    print()
    before_header = Colors.bold("Before")
    after_header = Colors.bold("After")
    print(f"  {before_header:<{col_width}}   {after_header}")
    print(f"  {'─' * col_width} │ {'─' * col_width}")

    # Print side by side
    for i in range(max_lines):
        old_line = old_lines[i][:col_width] if i < len(old_lines) else ""
        new_line = new_lines[i][:col_width] if i < len(new_lines) else ""
        # Pad old_line to align columns (account for no ANSI codes in padding calc)
        print(f"  {old_line:<{col_width}} │ {new_line}")

    if max_lines == 0:
        print(f"  {'(no commits)':<{col_width}} │ (no commits)")

    # Confirm
    print()
    choice = input(f"Keep changes? [Y]es / [n]o (restore from {backup_branch}): ").strip().lower()

    if choice == 'n':
        subprocess.run(["git", "-C", repo, "reset", "--hard", backup_branch], check=True, capture_output=True)
        subprocess.run(["git", "-C", repo, "branch", "-D", backup_branch], capture_output=True)
        return True, "Restored from backup"
    else:
        subprocess.run(["git", "-C", repo, "branch", "-D", backup_branch], capture_output=True)
        return True, "Rebase complete, backup deleted"


def drop_commits_with_backup(
    repo: str,
    commits_to_drop: List[Tuple[str, str]],
    branch: str,
    base_ref: str,
) -> Tuple[bool, str]:
    """
    Drop local commits from HEAD with automatic backup.

    Drops all commits from the oldest in commits_to_drop through HEAD
    by resetting to the parent of the oldest commit.

    Args:
        repo: Path to the repository
        commits_to_drop: List of (hash, subject) tuples to drop (oldest first)
        branch: Current branch name (for backup naming)
        base_ref: Upstream reference (used if oldest commit is first local)

    Returns (success, message).
    """
    display_name = repo_display_name(repo)
    count = len(commits_to_drop)

    # Show commits that will be dropped
    print(f"\n{Colors.bold(f'Drop {count} commit(s) from {display_name}:')}")
    for h, subject in commits_to_drop:
        print(f"  {Colors.yellow(h[:12])} {subject}")

    # Determine reset target
    oldest_hash = commits_to_drop[0][0]
    try:
        # Check if oldest has a parent within local range
        parent = subprocess.check_output(
            ["git", "-C", repo, "rev-parse", f"{oldest_hash}~1"],
            text=True, stderr=subprocess.DEVNULL,
        ).strip()
    except subprocess.CalledProcessError:
        parent = None

    # If parent resolves and is not beyond base_ref, use it; otherwise use base_ref
    if parent:
        try:
            merge_base = subprocess.check_output(
                ["git", "-C", repo, "merge-base", parent, base_ref],
                text=True, stderr=subprocess.DEVNULL,
            ).strip()
            # If parent IS the base_ref (or ancestor), use base_ref directly
            if merge_base == parent:
                reset_target = base_ref
            else:
                reset_target = f"{oldest_hash}~1"
        except subprocess.CalledProcessError:
            reset_target = base_ref
    else:
        reset_target = base_ref

    timestamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    backup_branch = f"{branch}-backup-{timestamp}"
    print(f"\n  Backup branch: {Colors.cyan(backup_branch)}")

    # Confirm (default No — destructive action)
    choice = input(f"\nDrop {count} commit(s)? [y/N]: ").strip().lower()
    if choice != 'y':
        return False, "Cancelled"

    # Create backup branch
    try:
        subprocess.run(
            ["git", "-C", repo, "branch", backup_branch],
            check=True, capture_output=True,
        )
    except subprocess.CalledProcessError as e:
        return False, f"Failed to create backup branch: {e}"

    # Reset to target
    try:
        subprocess.run(
            ["git", "-C", repo, "reset", "--hard", reset_target],
            check=True, capture_output=True,
        )
    except subprocess.CalledProcessError as e:
        return False, f"Reset failed: {e}. Backup branch: {backup_branch}"

    return True, f"Dropped {count} commit(s). Backup: {backup_branch}"


def reorder_commits_via_cherrypick(
    repo: str,
    branch: str,
    base_ref: str,
    selected_commits: List[str],
    remaining_commits: List[str],
    commits_info: List[Tuple[str, str]],  # (hash, subject) for display
    insertion_point: str = None,  # Where to insert selected commits (default: base_ref)
    backup_branch: Optional[str] = None,
    dry_run: bool = False
) -> Tuple[bool, str, Optional[str]]:
    """
    Reorder commits using cherry-pick approach.
    If insertion_point is base_ref: base_ref -> selected -> remaining
    If insertion_point is a commit: commits up to insertion_point -> selected -> rest
    Returns (success, message, cut_point_hash).
    cut_point_hash is the commit hash at the end of selected commits (for PR branch creation).
    """
    display_name = repo_display_name(repo)

    if insertion_point is None:
        insertion_point = base_ref

    # Build lookup for commit subjects
    subject_map = {h: s for h, s in commits_info}

    # Determine final commit order
    if insertion_point == base_ref:
        all_commits = selected_commits + remaining_commits
        insert_desc = base_ref
        cut_point_idx = len(selected_commits)
    else:
        # Find where to split remaining_commits
        insertion_idx = None
        for i, h in enumerate(remaining_commits):
            if h == insertion_point:
                insertion_idx = i
                break
        if insertion_idx is not None:
            before = remaining_commits[:insertion_idx + 1]
            after = remaining_commits[insertion_idx + 1:]
            all_commits = before + selected_commits + after
            insert_desc = f"after {insertion_point[:12]}"
            cut_point_idx = len(before) + len(selected_commits)
        else:
            all_commits = selected_commits + remaining_commits
            insert_desc = base_ref
            cut_point_idx = len(selected_commits)

    # Get current commit order from base_ref to HEAD
    try:
        current_commits = subprocess.check_output(
            ["git", "-C", repo, "rev-list", "--reverse", f"{base_ref}..HEAD"],
            text=True,
        ).strip().splitlines()
    except subprocess.CalledProcessError:
        current_commits = []

    # Check if commits are already in the correct order
    if current_commits == all_commits:
        # Already in correct order - compute cut point and return
        if cut_point_idx > 0 and cut_point_idx <= len(current_commits):
            cut_point = current_commits[cut_point_idx - 1]
        else:
            cut_point = None
        msg = f"Already in order: {len(selected_commits)} upstream + {len(remaining_commits)} local"
        return True, msg, cut_point

    # Dry run mode - show what would happen
    if dry_run:
        # Get upstream commits for context
        upstream_context = get_upstream_context_commits(repo, base_ref, count=3)

        print(f"\n  Selected for upstream ({len(selected_commits)}):")
        # Show selected commits newest-first
        for h in reversed(selected_commits):
            print(f"    {h[:12]} {subject_map.get(h, '')[:60]}")

        print(f"  ────────────────────────────────────────")
        print(f"  {base_ref}")

        # Show upstream context
        if upstream_context:
            for h, subj in upstream_context:
                print(f"    {h[:12]} {subj[:60]}")

        msg = f"Would reorder {len(selected_commits)} upstream + {len(remaining_commits)} local"
        return True, msg, None  # No cut point in dry run

    # Record original HEAD for recovery
    try:
        original_head = subprocess.check_output(
            ["git", "-C", repo, "rev-parse", "HEAD"],
            text=True,
        ).strip()
    except subprocess.CalledProcessError:
        return False, "Failed to get current HEAD", None

    # Create backup branch if requested
    if backup_branch:
        result = subprocess.run(
            ["git", "-C", repo, "branch", backup_branch, "HEAD"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if result.returncode != 0:
            return False, f"Failed to create backup branch '{backup_branch}'", None
        print(f"  Created backup: {backup_branch}")

    # Create temp branch at base_ref
    temp_branch = f"_prepare-export-temp-{uuid.uuid4().hex[:8]}"

    try:
        # Create and checkout temp branch at base_ref
        subprocess.run(
            ["git", "-C", repo, "checkout", "-b", temp_branch, base_ref],
            check=True,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
    except subprocess.CalledProcessError:
        return False, f"Failed to create temp branch at {base_ref}", None

    # Cherry-pick all commits in the computed order
    # (cut_point_idx already computed above)
    cherry_pick_failed = False
    failed_commit = None
    cut_point = None

    for i, commit in enumerate(all_commits):
        result = subprocess.run(
            ["git", "-C", repo, "cherry-pick", commit],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        if result.returncode != 0:
            cherry_pick_failed = True
            failed_commit = commit[:12]
            break

        # Capture cut point (HEAD after last selected commit)
        if i + 1 == cut_point_idx:
            cut_point = subprocess.check_output(
                ["git", "-C", repo, "rev-parse", "HEAD"],
                text=True,
            ).strip()

    if cherry_pick_failed:
        # Abort cherry-pick and restore
        subprocess.run(
            ["git", "-C", repo, "cherry-pick", "--abort"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        subprocess.run(
            ["git", "-C", repo, "checkout", branch],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        subprocess.run(
            ["git", "-C", repo, "branch", "-D", temp_branch],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return False, f"Cherry-pick failed on {failed_commit}, original branch restored", None

    # Get new HEAD
    new_head = subprocess.check_output(
        ["git", "-C", repo, "rev-parse", "HEAD"],
        text=True,
    ).strip()

    # Switch back to original branch and reset to new HEAD
    subprocess.run(
        ["git", "-C", repo, "checkout", branch],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    subprocess.run(
        ["git", "-C", repo, "reset", "--hard", new_head],
        check=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    # Cleanup temp branch
    subprocess.run(
        ["git", "-C", repo, "branch", "-D", temp_branch],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )

    return True, f"Reordered: {len(selected_commits)} upstream + {len(remaining_commits)} local", cut_point



def run_explore(args) -> int:
    """Main entry point for explore subcommand."""
    bblayers_path = resolve_bblayers_path(args.bblayers)
    defaults = load_defaults(args.defaults_file)
    discover_all = getattr(args, 'all', False)
    pairs, repo_sets = resolve_base_and_layers(
        bblayers_path, defaults, include_external=discover_all, discover_all=discover_all
    )
    # Filter out hidden repos
    repos = dedupe_preserve_order(
        repo for _, repo in pairs if repo not in repo_sets.hidden
    )

    # Add external repos to the list (they're not in pairs since they're not layers)
    for ext_repo in repo_sets.external:
        if ext_repo not in repos and ext_repo not in repo_sets.hidden:
            repos.append(ext_repo)

    # For backward compat with UI functions that expect simple sets
    discovered_repos = repo_sets.discovered
    external_repos = repo_sets.external
    configured_layers = repo_sets.configured_layers

    if not repos and not external_repos:
        print("No repos found.")
        return 1

    # Build layer mapping for repos (needed for status output)
    repo_layers: Dict[str, List[str]] = {}
    for layer, repo in pairs:
        repo_layers.setdefault(repo, []).append(layer)

    # Optionally fetch first
    if getattr(args, 'refresh', False) or getattr(args, 'fetch', False):
        print("Fetching from origin...")
        for repo in repos:
            if defaults.get(repo, "rebase") != "skip":
                fetch_repo(repo)
        print()

    # Pre-collect repo info for display
    verbose = getattr(args, 'verbose', 0)
    max_commits = getattr(args, 'max_commits', 10)
    did_fetch = getattr(args, 'refresh', False) or getattr(args, 'fetch', False)
    status_mode = getattr(args, 'status', False)

    repo_info: Dict[str, Dict] = {}
    for repo in repos:
        default_action = defaults.get(repo, "rebase")
        branch = current_branch(repo)
        if not branch:
            branch = "(detached)"

        # Get local commits
        commits = []
        base_ref = None
        upstream_count = 0
        layer_upstream_counts = {}
        if branch != "(detached)" and default_action != "skip":
            try:
                commits_list, base_ref = get_local_commits(repo, branch)
                commits = commits_list if commits_list else []
                # Get upstream count:
                # - If we fetched: use local refs (accurate count)
                # - If --status mode: do ls-remote (user expects to wait for accurate info)
                # - Otherwise: skip for fast startup (user can press r/R to refresh)
                if did_fetch:
                    upstream = get_upstream_commits(repo, branch)
                    upstream_count = len(upstream)
                    if upstream_count > 0 and len(repo_layers.get(repo, [])) > 1:
                        layer_upstream_counts = get_upstream_layer_counts(repo, branch, repo_layers[repo])
                elif status_mode:
                    ls_result = get_upstream_count_ls_remote(repo, branch)
                    if ls_result == -1:
                        upstream_count = -1  # indicates "has changes" but unknown count
                    elif ls_result and ls_result > 0:
                        upstream_count = ls_result
                        if len(repo_layers.get(repo, [])) > 1:
                            layer_upstream_counts = get_upstream_layer_counts(repo, branch, repo_layers[repo])
                # else: leave upstream_count = 0 (unknown) for fast interactive startup
            except Exception:
                pass

        # Get HEAD commit (hash + subject) for verbose mode
        head_commit = None
        try:
            out = subprocess.check_output(
                ["git", "-C", repo, "log", "-1", "--format=%H %s"],
                text=True, stderr=subprocess.DEVNULL,
            ).strip()
            if out:
                sha, subject = out.split(" ", 1)
                head_commit = (sha, subject)
        except Exception:
            pass

        repo_info[repo] = {
            "display_name": repo_display_name(repo),
            "local_count": len(commits),
            "commits": commits,
            "head_commit": head_commit,
            "branch": branch,
            "base_ref": base_ref,
            "upstream_count": upstream_count,
            "layer_upstream_counts": layer_upstream_counts,
            "is_dirty": not repo_is_clean(repo),
            "default_action": default_action,
        }

    # Handle --status mode: print text output instead of fzf
    if getattr(args, 'status', False):
        def format_layers(layer_paths: List[str]) -> str:
            if len(layer_paths) == 1:
                return f"  layer: {layer_display_name(layer_paths[0])}"
            lines = ["  layers:"]
            for lp in layer_paths:
                lines.append(f"    {layer_display_name(lp)}")
            return "\n".join(lines)

        for repo in repos:
            info = repo_info[repo]
            layers = repo_layers.get(repo, [])
            display_name = info["display_name"]
            branch = info["branch"]
            local_count = info["local_count"]
            upstream_count = info["upstream_count"]
            is_dirty = info["is_dirty"]
            default_action = info["default_action"]
            commits = info["commits"]

            # Format worktree status with color
            if is_dirty:
                worktree_status = terminal_color("dirty", "[DIRTY]")
            else:
                worktree_status = terminal_color("clean", "[clean]")

            if default_action == "skip":
                if verbose == 0:
                    layer_names = ", ".join(layer_display_name(lp) for lp in layers)
                    print(f"→ {layer_names}: default=skip")
                else:
                    print(f"→ {repo}: default=skip (skipping status)")
                    print(format_layers(layers))
                continue

            if branch == "(detached)":
                if verbose == 0:
                    layer_names = ", ".join(layer_display_name(lp) for lp in layers)
                    print(f"→ {layer_names}: detached HEAD {worktree_status}")
                else:
                    print(f"→ {repo}: detached HEAD or no branch {worktree_status}; skipping")
                    print(format_layers(layers))
                continue

            if verbose == 0:
                # Summary mode (default)
                layer_names = ", ".join(layer_display_name(lp) for lp in layers)
                status_parts = []
                if local_count:
                    status_parts.append(f"{local_count} local commit(s)")
                if upstream_count == -1:
                    status_parts.append(terminal_color("upstream", "upstream has changes"))
                elif upstream_count > 0:
                    status_parts.append(terminal_color("upstream", f"{upstream_count} to pull"))
                if not status_parts:
                    status_parts.append("up-to-date")
                print(f"→ {layer_names}: {', '.join(status_parts)} on {Colors.bold(branch)} {worktree_status}")
            else:
                # Detailed mode (verbose >= 1)
                status_parts = []
                if local_count:
                    status_parts.append(f"{local_count} local commit(s)")
                if upstream_count == -1:
                    status_parts.append(terminal_color("upstream", "upstream has changes"))
                elif upstream_count > 0:
                    status_parts.append(terminal_color("upstream", f"{upstream_count} upstream commit(s) to pull"))
                if not status_parts:
                    status_parts.append("up-to-date")

                repo_display = Colors.green(repo) if not is_dirty else repo
                branch_display = Colors.bold(branch)
                print(f"→ {repo_display}: {', '.join(status_parts)} on {branch_display} {worktree_status}")
                print(format_layers(layers))

                # Show local commits
                show_all = verbose >= 2
                if commits:
                    print("  local:")
                    limit = len(commits) if show_all else max_commits
                    for hash_val, subject in commits[:limit]:
                        print(f"    {hash_val[:12]} {subject}")
                    if not show_all and len(commits) > max_commits:
                        print(f"    ... ({len(commits) - max_commits} more)")

                # Show upstream count hint
                if upstream_count > 0 and did_fetch:
                    print(f"  {terminal_color('upstream', f'upstream: {upstream_count} commit(s) to pull')}")

        return 0

    # fzf mode requires fzf
    if not fzf_available():
        print("fzf is required for the explore command. Please install fzf.")
        return 1

    # If specific repo given, jump directly to it
    if args.repo:
        repo = find_repo_by_identifier(repos, args.repo, defaults)
        if not repo:
            print(f"Repo not found: {args.repo}")
            return 1

        # Browse single repo until back/quit
        load_size = get_explore_load_size()
        upstream_pull_limit = 500
        context_limit = args.upstream_count
        scroll_to_context = 0
        layer_filter = None
        layers = repo_layers.get(repo, [])

        # Get layer upstream counts if multi-layer repo
        layer_counts = {}
        total_upstream = 0
        if len(layers) > 1:
            branch = current_branch(repo) or "(detached)"
            if branch != "(detached)":
                layer_counts = get_upstream_layer_counts(repo, branch, layers)
                try:
                    total_upstream = int(subprocess.check_output(
                        ["git", "-C", repo, "rev-list", "--count",
                         f"HEAD..{get_upstream_ref(repo, branch) or 'HEAD'}"],
                        text=True,
                    ).strip())
                except Exception:
                    total_upstream = sum(layer_counts.values())

        while True:
            branch = current_branch(repo) or "(detached)"
            if layer_filter and branch != "(detached)":
                commits, base_ref = get_local_commits_for_layer(repo, branch, layer_filter)
            else:
                commits, base_ref = get_local_commits(repo, branch)
            if not commits:
                commits = []
            upstream_context = get_upstream_context_commits(repo, base_ref, context_limit) if base_ref else []

            if layer_filter and base_ref and branch != "(detached)":
                upstream_to_pull = get_upstream_to_pull_for_layer(repo, branch, layer_filter, count=upstream_pull_limit)
            else:
                upstream_to_pull = get_upstream_to_pull(repo, branch, count=upstream_pull_limit) if branch != "(detached)" else []

            action, selected_hashes = fzf_explore_commits(
                repo, branch, commits, upstream_context, upstream_to_pull, base_ref or "HEAD",
                is_dirty=not repo_is_clean(repo),
                layer_filter=layer_filter,
                layers=layers,
                layer_counts=layer_counts,
                total_upstream=total_upstream,
                context_limit=context_limit,
                scroll_to_context=scroll_to_context,
            )

            scroll_to_context = 0  # reset after use
            if action == "quit" or action == "back":
                break
            elif action == "load_more":
                scroll_to_context = len(upstream_context)
                upstream_pull_limit += load_size
                context_limit += load_size
                continue
            elif action == "layer_view":
                if len(layers) > 1:
                    lv_action, _ = fzf_explore_layer_view(repo, branch, layers, layer_counts)
                    if lv_action == "quit":
                        break
                continue
            elif action == "copy" and selected_hashes:
                commit = selected_hashes[0]
                if copy_to_clipboard(commit):
                    print(f"Copied: {commit}")
                else:
                    print(f"Clipboard not available. Hash: {commit}")
            elif action == "export" and selected_hashes:
                export_commits_from_explore(repo, selected_hashes)
            elif action == "rebase_interactive":
                if branch == "(detached)":
                    print(f"\n{Colors.yellow('Cannot rebase: detached HEAD')}")
                    input("Press Enter to continue...")
                elif not repo_is_clean(repo):
                    print(f"\n{Colors.yellow('Cannot rebase: uncommitted changes')}")
                    input("Press Enter to continue...")
                elif not commits:
                    print(f"\n{Colors.yellow('Cannot rebase: no local commits')}")
                    input("Press Enter to continue...")
                elif not base_ref:
                    print(f"\n{Colors.yellow('Cannot rebase: no upstream reference')}")
                    input("Press Enter to continue...")
                else:
                    # Show commit selection for rebase range
                    rebase_base = fzf_select_rebase_range(repo, branch, commits, base_ref)
                    if rebase_base:
                        success, msg = interactive_rebase_with_backup(repo, rebase_base, branch)
                        print(f"\n{msg}")
                        input("Press Enter to continue...")
            elif action == "drop_commits":
                if branch == "(detached)":
                    print(f"\n{Colors.yellow('Cannot drop: detached HEAD')}")
                    input("Press Enter to continue...")
                elif not repo_is_clean(repo):
                    print(f"\n{Colors.yellow('Cannot drop: uncommitted changes')}")
                    input("Press Enter to continue...")
                elif not commits:
                    print(f"\n{Colors.yellow('Cannot drop: no local commits')}")
                    input("Press Enter to continue...")
                elif not base_ref:
                    print(f"\n{Colors.yellow('Cannot drop: no upstream reference')}")
                    input("Press Enter to continue...")
                elif not selected_hashes:
                    print(f"\n{Colors.yellow('No commits selected')}")
                    input("Press Enter to continue...")
                else:
                    # Find oldest selected → drop everything from HEAD to it
                    all_local = [h for h, _ in commits]
                    oldest_idx = len(all_local)
                    for sel_h in selected_hashes:
                        for i, loc_h in enumerate(all_local):
                            if loc_h == sel_h or loc_h.startswith(sel_h):
                                oldest_idx = min(oldest_idx, i)
                                break
                    if oldest_idx >= len(all_local):
                        print(f"\n{Colors.yellow('Selected commits not in local range')}")
                        input("Press Enter to continue...")
                    else:
                        # commits is oldest-first, so drop from oldest_idx to end = HEAD
                        to_drop = commits[oldest_idx:]
                        success, msg = drop_commits_with_backup(
                            repo, to_drop, branch, base_ref
                        )
                        print(f"\n{msg}")
                        input("Press Enter to continue...")
            elif action == "tig":
                viewer = get_preferred_git_viewer()
                if not viewer:
                    print(f"\n{Colors.yellow('No git history viewer found.')}")
                    print("Install one of: tig, lazygit, or gitk")
                    print("  apt install tig  (or brew install tig)")
                    input("Press Enter to continue...")
                else:
                    # Launch the preferred viewer
                    if selected_hashes and viewer == "tig":
                        subprocess.run(["tig", "show", selected_hashes[0]], cwd=repo)
                    elif selected_hashes and viewer == "lazygit":
                        subprocess.run(["lazygit"], cwd=repo)
                    elif selected_hashes and viewer == "gitk":
                        subprocess.run(["gitk", selected_hashes[0]], cwd=repo)
                    else:
                        subprocess.run([viewer], cwd=repo)
            elif action == "patch_lookup" and selected_hashes:
                from .b4 import b4_patch_lookup
                b4_patch_lookup(repo, selected_hashes[0])
            elif action == "tree_mode":
                commit_for_tree = selected_hashes[0] if selected_hashes else ""
                tree_action, _ = fzf_explore_tree(repo, branch, focus_commit=commit_for_tree)
                if tree_action == "quit":
                    break

        return 0

    # Two-level navigation loop
    explore_verbose_mode = False
    explore_layers_mode = False
    expanded_repos: Set[str] = set()
    first_iteration = True
    next_selection: Optional[str] = None  # Track repo to select after expand/collapse
    last_interrupt_time: float = 0  # Track Ctrl+C for double-tap exit
    dialog_state = ExploreMenuState()  # Dialog state for inline prompts
    upstream_checked = False  # True once background or manual refresh has populated upstream counts
    show_branch_picker = False
    while True:
        # Build branch selector if active
        branch_selector = None
        if show_branch_picker:
            union = collect_union_branches(repos)
            total = len(repos)
            # Detect common branch across repos
            branches_set = set(repo_info.get(r, {}).get("branch", "") for r in repos)
            common = branches_set.pop() if len(branches_set) == 1 else ""
            items = []
            for name, count in union:
                if count == total:
                    label = f"{name:<30} ({count}/{total} repos)"
                else:
                    label = Colors.dim(f"{name:<30} ({count}/{total} repos)")
                items.append(InlineSelectorItem(
                    name, label,
                    marker="\u2022" if name == common else "",
                ))
            branch_selector = InlineSelector("Switch all repos to branch", items)

        # Level 1: Repo/Layers list
        # Enable background upstream check on first iteration only
        list_action, selected_repo, query = fzf_explore_repo_list(
            repos, repo_info, repo_layers, explore_verbose_mode,
            defaults=defaults,
            enable_background_refresh=first_iteration,
            discovered_repos=discovered_repos,
            external_repos=external_repos,
            expanded_repos=expanded_repos,
            layers_mode=explore_layers_mode,
            configured_layers=configured_layers,
            initial_selection=next_selection,
            bblayers_conf=bblayers_path,
            dialog_state=dialog_state,
            branch_selector=branch_selector,
        )
        if first_iteration:
            upstream_checked = True  # Background refresh ran during first fzf session
        first_iteration = False
        next_selection = None  # Clear after use

        # Handle branch picker results
        if show_branch_picker:
            if list_action == "branch_select" and selected_repo:
                target_branch = selected_repo
                print(f"\nSwitching repos to branch: {target_branch}")
                switch_repos_to_branch(repos, target_branch)
                # Update repo_info with new branch info
                for repo in repos:
                    info = repo_info.get(repo, {})
                    info["branch"] = current_branch(repo) or "(detached)"
                    repo_info[repo] = info
                input("\nPress Enter to continue...")
            show_branch_picker = False
            continue

        # Handle dialog selections
        if list_action == "dialog_selection" and dialog_state.has_dialog():
            result = dialog_state.handle_dialog_selection(selected_repo, query)
            old_dialog = dialog_state.active_dialog
            if result.confirmed:
                # Execute dialog callback with the result
                if old_dialog.on_confirm:
                    old_dialog.on_confirm(result.value)
                # Only clear if callback didn't chain a new dialog
                if dialog_state.active_dialog is old_dialog:
                    dialog_state.set_status(f"✓ {old_dialog.title}: {result.value}")
                    dialog_state.clear_dialog()
            else:
                dialog_state.clear_dialog()
            continue

        if list_action == "quit":
            break
        elif list_action == "interrupt":
            # If dialog is active, Esc/Ctrl+C just cancels the dialog
            if dialog_state.has_dialog():
                dialog_state.clear_dialog()
                continue
            # Double Ctrl+C to exit (only when no dialog)
            now = time.time()
            if now - last_interrupt_time < 1.0:
                break  # Exit on double Ctrl+C
            last_interrupt_time = now
            print("\nPress Ctrl+C again to exit")
            continue
        elif list_action == "cancelled":
            # Clear any active dialog on cancel/escape
            if dialog_state.has_dialog():
                dialog_state.clear_dialog()
            continue
        elif list_action in ("rebase", "merge") and selected_repo:
            branch = current_branch(selected_repo)
            display_name = repo_display_name(selected_repo)
            action_type = list_action  # Capture for closure
            target_repo = selected_repo  # Capture for closure

            upstream = get_upstream_ref(selected_repo, branch) or f"origin/{branch}"
            if action_type == "rebase":
                cmd_desc = f"git pull --rebase {upstream}"
            else:
                cmd_desc = f"git pull {upstream}"

            def on_update_confirm(confirmed):
                if confirmed:
                    run_single_repo_update(target_repo, branch, action_type)
                    print()
                    # Refresh repo info after update
                    try:
                        commits, _ = get_local_commits(target_repo, branch)
                        repo_info[target_repo]["local_count"] = len(commits) if commits else 0
                    except Exception:
                        pass
                    try:
                        upstream = get_upstream_commits(target_repo, branch)
                        repo_info[target_repo]["upstream_count"] = len(upstream)
                        layers = repo_layers.get(target_repo, [])
                        if len(layers) > 1 and len(upstream) > 0:
                            repo_info[target_repo]["layer_upstream_counts"] = get_upstream_layer_counts(target_repo, branch, layers)
                        else:
                            repo_info[target_repo]["layer_upstream_counts"] = {}
                    except Exception:
                        pass
                    input("Press Enter to continue...")

            dialog_state.show_dialog(
                confirm_action_dialog(
                    title=f"{action_type.title()} {display_name}?",
                    message=cmd_desc,
                    on_confirm=on_update_confirm,
                )
            )
            continue
        elif list_action == "refresh" and selected_repo:
            # Skip special entries
            if selected_repo in ("HEADER", "PROJECT", "SETTINGS", "INFO") or selected_repo.startswith("SEPARATOR"):
                continue
            # Fetch from single repo and refresh its info
            display_name = repo_display_name(selected_repo)
            print(f"\nRefreshing {display_name}...", end=" ", flush=True)
            try:
                subprocess.run(
                    ["git", "-C", selected_repo, "fetch", "--quiet"],
                    check=True,
                    stderr=subprocess.DEVNULL,
                    timeout=30,
                )
                print("done")
            except subprocess.TimeoutExpired:
                print("timeout")
            except subprocess.CalledProcessError:
                print("failed")
            # Refresh this repo's info
            branch = current_branch(selected_repo) or "(detached)"
            try:
                commits, _ = get_local_commits(selected_repo, branch)
                repo_info[selected_repo]["local_count"] = len(commits) if commits else 0
                upstream = get_upstream_commits(selected_repo, branch)
                repo_info[selected_repo]["upstream_count"] = len(upstream)
                layers = repo_layers.get(selected_repo, [])
                if len(layers) > 1 and len(upstream) > 0:
                    layer_counts = get_upstream_layer_counts(selected_repo, branch, layers)
                    repo_info[selected_repo]["layer_upstream_counts"] = layer_counts
            except Exception:
                pass
            try:
                out = subprocess.check_output(
                    ["git", "-C", selected_repo, "log", "-1", "--format=%H %s"],
                    text=True, stderr=subprocess.DEVNULL,
                ).strip()
                if out:
                    sha, subject = out.split(" ", 1)
                    repo_info[selected_repo]["head_commit"] = (sha, subject)
            except Exception:
                pass
            repo_info[selected_repo]["is_dirty"] = not repo_is_clean(selected_repo)
            next_selection = selected_repo
            continue
        elif list_action == "refresh_all":
            # Fetch from all repos and refresh info
            print("\nRefreshing from origin...")
            for repo in repos:
                display_name = repo_display_name(repo)
                try:
                    subprocess.run(
                        ["git", "-C", repo, "fetch", "--quiet"],
                        check=True,
                        stderr=subprocess.DEVNULL,
                    )
                    print(f"  {display_name}: fetched")
                except subprocess.CalledProcessError:
                    print(f"  {display_name}: fetch failed")
            # Rebuild repo info
            for repo in repos:
                branch = current_branch(repo) or "(detached)"
                try:
                    commits, _ = get_local_commits(repo, branch)
                    repo_info[repo]["local_count"] = len(commits) if commits else 0
                    upstream = get_upstream_commits(repo, branch)
                    repo_info[repo]["upstream_count"] = len(upstream)
                    layers = repo_layers.get(repo, [])
                    if len(layers) > 1 and len(upstream) > 0:
                        layer_counts = get_upstream_layer_counts(repo, branch, layers)
                        repo_info[repo]["layer_upstream_counts"] = layer_counts
                except Exception:
                    pass
                try:
                    out = subprocess.check_output(
                        ["git", "-C", repo, "log", "-1", "--format=%H %s"],
                        text=True, stderr=subprocess.DEVNULL,
                    ).strip()
                    if out:
                        sha, subject = out.split(" ", 1)
                        repo_info[repo]["head_commit"] = (sha, subject)
                except Exception:
                    pass
                repo_info[repo]["is_dirty"] = not repo_is_clean(repo)
            upstream_checked = True
            print()
            continue
        elif list_action == "verbose":
            # Toggle verbose mode (show top commit instead of display names)
            explore_verbose_mode = not explore_verbose_mode
            continue
        elif list_action == "update_all":
            # Show inline update dialogs for each repo (chained)
            update_repos = list(repos)
            update_idx = [0]  # mutable for closures

            def _refresh_repo_info(repo):
                """Refresh repo_info entry after an update."""
                branch = current_branch(repo) or "(detached)"
                info = repo_info.get(repo, {})
                try:
                    commits, base = get_local_commits(repo, branch)
                    info["local_count"] = len(commits) if commits else 0
                    info["commits"] = commits or []
                    info["base_ref"] = base
                except Exception:
                    pass
                try:
                    out = subprocess.check_output(
                        ["git", "-C", repo, "log", "-1", "--format=%H %s"],
                        text=True, stderr=subprocess.DEVNULL,
                    ).strip()
                    if out:
                        sha, subject = out.split(" ", 1)
                        info["head_commit"] = (sha, subject)
                except Exception:
                    pass
                info["is_dirty"] = not repo_is_clean(repo)
                try:
                    upstream = get_upstream_commits(repo, branch)
                    info["upstream_count"] = len(upstream)
                    layers = repo_layers.get(repo, [])
                    if len(layers) > 1 and len(upstream) > 0:
                        info["layer_upstream_counts"] = get_upstream_layer_counts(repo, branch, layers)
                    else:
                        info["layer_upstream_counts"] = {}
                except Exception:
                    info["upstream_count"] = 0
                    info["layer_upstream_counts"] = {}
                repo_info[repo] = info

            def _show_next_update_dialog():
                """Show dialog for the next repo that needs updating."""
                while update_idx[0] < len(update_repos):
                    repo = update_repos[update_idx[0]]
                    branch = current_branch(repo)
                    if not branch:
                        # Skip detached HEAD repos
                        update_idx[0] += 1
                        continue
                    upstream_count = repo_info.get(repo, {}).get("upstream_count", 0)
                    if upstream_checked and upstream_count == 0:
                        # Upstream data is reliable and nothing to pull — skip
                        update_idx[0] += 1
                        continue
                    default_action = defaults.get(repo, "rebase")
                    display_name = repo_display_name(repo)

                    dialog_state.show_dialog(
                        update_repo_dialog(
                            repo_name=display_name,
                            branch=branch,
                            default_action=default_action,
                            index=update_idx[0] + 1,
                            total=len(update_repos),
                            upstream_count=upstream_count,
                            on_confirm=_handle_update_selection,
                        )
                    )
                    return
                # All repos processed — no more dialogs

            def _handle_update_selection(selected):
                """Handle user's choice for one repo, then chain the next."""
                repo = update_repos[update_idx[0]]
                branch = current_branch(repo)
                default_action = defaults.get(repo, "rebase")
                display_name = repo_display_name(repo)

                if selected == "stop":
                    # User chose to stop — don't chain further
                    return

                action = selected
                if action == "use_default":
                    action = default_action

                if action == "skip":
                    update_idx[0] += 1
                    _show_next_update_dialog()
                    return

                if action in ("rebase", "merge"):
                    print(f"\n  Updating {display_name}...")
                    run_single_repo_update(repo, branch, action)
                    _refresh_repo_info(repo)
                    print()

                update_idx[0] += 1
                _show_next_update_dialog()

            _show_next_update_dialog()
            continue
        elif list_action == "branch" and selected_repo:
            if selected_repo in ("HEADER", "SETTINGS") or selected_repo.startswith("SEPARATOR"):
                continue
            fzf_branch_repos([selected_repo])
            # Refresh branch info after returning
            info = repo_info.get(selected_repo, {})
            info["branch"] = current_branch(selected_repo) or "(detached)"
            repo_info[selected_repo] = info
            next_selection = selected_repo
            continue
        elif list_action == "branch_all":
            show_branch_picker = True
            continue
        elif list_action == "shell":
            from .setup import run_init_shell
            ns = argparse.Namespace(layers_dir="layers")
            run_init_shell(ns)
            continue
        elif list_action == "layers_toggle":
            # Toggle between repos view and layers view
            explore_layers_mode = not explore_layers_mode
            continue
        elif list_action == "discover_toggle":
            # Toggle discovery mode and reload layers
            discover_all = not discover_all
            pairs, repo_sets = resolve_base_and_layers(
                bblayers_path, defaults, include_external=discover_all, discover_all=discover_all
            )
            repos = dedupe_preserve_order(repo for _, repo in pairs)
            discovered_repos = repo_sets.discovered
            external_repos = repo_sets.external
            configured_layers = repo_sets.configured_layers
            # Rebuild repo_layers
            repo_layers = {}
            for layer, repo in pairs:
                repo_layers.setdefault(repo, []).append(layer)
            # Rebuild repo_info for new repos
            for repo in repos:
                if repo not in repo_info:
                    branch = current_branch(repo) or "(detached)"
                    commits, _ = get_local_commits(repo, branch)
                    repo_info[repo] = {
                        "display_name": repo_display_name(repo),
                        "branch": branch,
                        "local_count": len(commits) if commits else 0,
                        "is_dirty": not repo_is_clean(repo),
                        "upstream_count": 0,
                    }
            continue
        elif list_action == "config" and selected_repo:
            # Skip special entries (but PROJECT is handled specially below)
            if selected_repo in ("HEADER", "SETTINGS") or selected_repo.startswith("SEPARATOR"):
                continue
            # Show config menu for selected repo (or project config if PROJECT)
            if selected_repo == "PROJECT":
                fzf_build_config(args.bblayers)
                # Reload layer configuration after returning (bblayers.conf may have been edited)
                pairs, repo_sets = resolve_base_and_layers(
                    bblayers_path, defaults, include_external=discover_all, discover_all=discover_all
                )
                repos = dedupe_preserve_order(repo for _, repo in pairs)
                discovered_repos = repo_sets.discovered
                external_repos = repo_sets.external
                configured_layers = repo_sets.configured_layers
                # Rebuild repo_layers
                repo_layers = {}
                for layer, repo in pairs:
                    repo_layers.setdefault(repo, []).append(layer)
                # Rebuild repo_info
                for repo in repos:
                    if repo not in repo_info:
                        branch = current_branch(repo) or "(detached)"
                        commits, _ = get_local_commits(repo, branch)
                        repo_info[repo] = {
                            "display_name": repo_display_name(repo),
                            "branch": branch,
                            "local_count": len(commits) if commits else 0,
                            "is_dirty": not repo_is_clean(repo),
                            "upstream_count": 0,
                        }
            else:
                fzf_repo_config(selected_repo, defaults, args.defaults_file)
            continue
        elif list_action == "right" and selected_repo:
            # Right arrow: expand if expandable and not expanded, explore otherwise
            if selected_repo in ("HEADER", "PROJECT", "SETTINGS", "INFO") or selected_repo.startswith("SEPARATOR"):
                # For special entries, treat as explore
                list_action = "explore"
            else:
                layers = repo_layers.get(selected_repo, [])
                if len(layers) > 1 and selected_repo not in expanded_repos:
                    # Expandable and not yet expanded - expand it
                    expanded_repos.add(selected_repo)
                    next_selection = selected_repo
                    continue
                else:
                    # Already expanded or single-layer - explore
                    list_action = "explore"
            # Fall through to explore handling below
        elif list_action == "left" and selected_repo:
            # Left arrow: collapse if expanded, quit otherwise
            if selected_repo in expanded_repos:
                expanded_repos.discard(selected_repo)
                next_selection = selected_repo
            else:
                break  # Not expanded - quit
            continue
        elif list_action == "left_layer" and selected_repo:
            # Left arrow on a LAYER: entry - collapse parent repo
            parent_repo = git_toplevel(selected_repo)
            if parent_repo and parent_repo in expanded_repos:
                expanded_repos.discard(parent_repo)
                next_selection = parent_repo
            else:
                break  # Can't find parent - quit
            continue
        elif list_action == "expand" and selected_repo:
            # Skip special entries
            if selected_repo in ("HEADER", "PROJECT", "SETTINGS", "INFO") or selected_repo.startswith("SEPARATOR"):
                continue
            # Toggle expansion of repo to show layers
            if selected_repo in expanded_repos:
                expanded_repos.discard(selected_repo)
            else:
                # Only expand if repo has multiple layers
                layers = repo_layers.get(selected_repo, [])
                if len(layers) > 1:
                    expanded_repos.add(selected_repo)
            # Preserve position at the expanded/collapsed repo
            next_selection = selected_repo
            continue
        elif list_action == "expand_all":
            # Toggle expand/collapse all repos with multiple layers
            # If any are expanded, collapse all; otherwise expand all
            expandable_repos = [r for r in repos if len(repo_layers.get(r, [])) > 1]
            if expanded_repos:
                # Some expanded - collapse all
                expanded_repos.clear()
            else:
                # None expanded - expand all
                expanded_repos.update(expandable_repos)
            # Preserve exact selection position (including HEADER/SEPARATOR)
            if selected_repo:
                next_selection = selected_repo
            continue
        elif list_action == "tig" and selected_repo:
            # Skip special entries
            if selected_repo in ("HEADER", "PROJECT", "SETTINGS", "INFO") or selected_repo.startswith("SEPARATOR"):
                continue
            # Launch git history viewer for this repo
            viewer = get_preferred_git_viewer()
            if not viewer:
                print(f"\n{Colors.yellow('No git history viewer found.')}")
                print("Install one of: tig, lazygit, or gitk")
                print("  apt install tig  (or brew install tig)")
                input("Press Enter to continue...")
                continue
            display_name = repo_display_name(selected_repo)
            print(f"\nLaunching {viewer} for {display_name}...")
            try:
                subprocess.run([viewer], cwd=selected_repo)
            except Exception as e:
                print(f"Error launching {viewer}: {e}")
                input("Press Enter to continue...")
            continue
        elif list_action == "add_tracked" and selected_repo:
            # Skip special entries
            if selected_repo in ("HEADER", "PROJECT", "SETTINGS", "INFO") or selected_repo.startswith("SEPARATOR"):
                continue
            # Add repo to tracked list AND add layer to bblayers.conf
            # Works for external, discovered, or hidden repos
            hidden_repos = set(get_hidden_repos(defaults))
            is_hidden = selected_repo in hidden_repos
            is_external = selected_repo in external_repos
            is_discovered = selected_repo in discovered_repos

            if is_external or is_discovered or is_hidden:
                # Add to extra repos (makes it permanently tracked)
                add_extra_repo(args.defaults_file, defaults, selected_repo)
                # Remove from external/discovered sets (now it's tracked)
                external_repos.discard(selected_repo)
                discovered_repos.discard(selected_repo)
                # If it was hidden, unhide it
                if is_hidden:
                    remove_hidden_repo(args.defaults_file, defaults, selected_repo)

            # Also add layer to bblayers.conf if it's a layer
            # Check if selected_repo is a layer or contains layers
            layers_to_check = []
            if os.path.isfile(os.path.join(selected_repo, "conf", "layer.conf")):
                layers_to_check = [selected_repo]
            else:
                layers_to_check = repo_layers.get(selected_repo, [])

            # Filter to unconfigured layers only
            unconfigured = [l for l in layers_to_check if os.path.realpath(l) not in configured_layers]

            if unconfigured:
                bblayers_conf = resolve_bblayers_path(args.bblayers)
                if bblayers_conf:
                    # Build collection map
                    all_layer_paths = []
                    for layer_list in repo_layers.values():
                        all_layer_paths.extend(layer_list)
                    collection_map = build_layer_collection_map(all_layer_paths)

                    # Add layers (if single layer, add directly; if multiple, use fzf)
                    if len(unconfigured) == 1:
                        layer_to_add = unconfigured[0]
                        layer_name = os.path.basename(layer_to_add)
                        print(f"\nAdding {layer_name} to bblayers.conf...")
                        success, message, added = add_layer_to_bblayers(
                            layer_to_add, bblayers_conf, collection_map
                        )
                        print(f"{message}")
                        if success and added:
                            for added_layer in added:
                                configured_layers.add(os.path.realpath(added_layer))
                    else:
                        # Multiple layers - prompt which to add
                        print(f"\nMultiple unconfigured layers in {repo_display_name(selected_repo)}:")
                        for i, layer in enumerate(unconfigured, 1):
                            print(f"  {i}. {os.path.basename(layer)}")
                        print("  a. Add all")
                        print("  s. Skip (just track repo)")
                        try:
                            choice = input("\nSelect (number/a/s): ").strip().lower()
                            if choice == "a":
                                for layer in unconfigured:
                                    layer_name = os.path.basename(layer)
                                    print(f"Adding {layer_name}...")
                                    success, message, added = add_layer_to_bblayers(
                                        layer, bblayers_conf, collection_map
                                    )
                                    if success and added:
                                        for added_layer in added:
                                            configured_layers.add(os.path.realpath(added_layer))
                                    else:
                                        print(f"  {message}")
                            elif choice and choice != "s":
                                idx = int(choice) - 1
                                if 0 <= idx < len(unconfigured):
                                    layer_to_add = unconfigured[idx]
                                    layer_name = os.path.basename(layer_to_add)
                                    print(f"Adding {layer_name}...")
                                    success, message, added = add_layer_to_bblayers(
                                        layer_to_add, bblayers_conf, collection_map
                                    )
                                    print(f"{message}")
                                    if success and added:
                                        for added_layer in added:
                                            configured_layers.add(os.path.realpath(added_layer))
                        except (ValueError, EOFError, KeyboardInterrupt):
                            pass
            continue
        elif list_action == "hide" and selected_repo:
            # Skip special entries
            if selected_repo in ("HEADER", "PROJECT", "SETTINGS", "INFO") or selected_repo.startswith("SEPARATOR"):
                continue
            # Hide repo (silently - repo disappears from list)
            if selected_repo in repos:
                add_hidden_repo(args.defaults_file, defaults, selected_repo)
                repos.remove(selected_repo)
                repo_info.pop(selected_repo, None)
            continue
        elif list_action == "toggle_hidden":
            # Toggle showing hidden repos (silently - fzf will show the updated list)
            hidden_repos = set(get_hidden_repos(defaults))
            if hidden_repos:
                # Check if we're currently showing hidden repos
                showing_hidden = any(r in repos for r in hidden_repos)
                if showing_hidden:
                    # Hide them again
                    for repo in list(hidden_repos):
                        if repo in repos:
                            repos.remove(repo)
                            repo_info.pop(repo, None)
                else:
                    # Show them
                    for repo in hidden_repos:
                        if repo not in repos and os.path.isdir(repo):
                            repos.append(repo)
                            # Add repo_info for newly shown repo
                            branch = current_branch(repo) or "(detached)"
                            is_dirty = not repo_is_clean(repo)
                            commits, _ = get_local_commits(repo, branch) if branch != "(detached)" else ([], None)
                            repo_info[repo] = {
                                "display_name": repo_display_name(repo),
                                "branch": branch,
                                "local_count": len(commits) if commits else 0,
                                "is_dirty": is_dirty,
                                "upstream_count": 0,
                            }
            continue
        elif list_action == "add_layer" and selected_repo:
            # Skip special entries
            if selected_repo in ("HEADER", "PROJECT", "SETTINGS", "INFO") or selected_repo.startswith("SEPARATOR"):
                continue
            # Add a layer to bblayers.conf using bitbake-layers
            # Check if selected_repo is actually a layer path (from expanded view)
            is_direct_layer = os.path.isfile(os.path.join(selected_repo, "conf", "layer.conf"))

            if is_direct_layer:
                # Direct layer selection from expanded view
                layers_in_repo = [selected_repo]
            else:
                # Repo selection - get layers from it
                layers_in_repo = repo_layers.get(selected_repo, [])

            if not layers_in_repo:
                print(f"\nNo layers found in {repo_display_name(selected_repo)}")
                input("Press Enter to continue...")
                continue

            # Find bblayers.conf path
            bblayers_conf = resolve_bblayers_path(args.bblayers)
            if not bblayers_conf:
                print("\nCould not find bblayers.conf")
                input("Press Enter to continue...")
                continue

            # Build collection map from all known layers
            all_layer_paths = []
            for layer_list in repo_layers.values():
                all_layer_paths.extend(layer_list)
            # Also add layers from other discovered repos
            for repo in discovered_repos | external_repos:
                if repo not in repo_layers:
                    # Check if repo itself is a layer
                    if os.path.isfile(os.path.join(repo, "conf", "layer.conf")):
                        all_layer_paths.append(repo)
            # Discover all layers for collection map
            peer_dirs = {os.path.dirname(r) for r in repos if r}
            all_discovered = discover_layers(peer_dirs=peer_dirs)
            for layer_path, _ in all_discovered:
                if layer_path not in all_layer_paths:
                    all_layer_paths.append(layer_path)

            collection_map = build_layer_collection_map(all_layer_paths)

            # Determine layer to add
            layer_to_add = None
            if len(layers_in_repo) == 1:
                layer_to_add = layers_in_repo[0]
            else:
                # Use fzf to select layer
                display_name = repo_display_name(selected_repo)
                menu_lines = []
                for layer in layers_in_repo:
                    layer_name = os.path.basename(layer)
                    menu_lines.append(f"{layer}\t{layer_name}")
                menu_input = "\n".join(menu_lines)

                try:
                    result = subprocess.run(
                        [
                            "fzf",
                            "--no-multi",
                            "--no-sort",
                            "--no-info",
                            "--ansi",
                            "--height", "~50%",
                            "--header", f"Select layer from {display_name} (Enter=select, Esc=cancel)",
                            "--prompt", "Layer: ",
                            "--with-nth", "2..",
                            "--delimiter", "\t",
                        ] + get_fzf_color_args(),
                        input=menu_input,
                        stdout=subprocess.PIPE,
                        text=True,
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        parts = result.stdout.strip().split("\t", 1)
                        if parts:
                            layer_to_add = parts[0]
                except FileNotFoundError:
                    # Fallback to numbered menu if fzf not available
                    print(f"\nLayers in {display_name}:")
                    for i, layer in enumerate(layers_in_repo, 1):
                        print(f"  {i}. {os.path.basename(layer)}")
                    try:
                        choice = input("\nSelect layer number (or Enter to cancel): ").strip()
                        if choice:
                            idx = int(choice) - 1
                            if 0 <= idx < len(layers_in_repo):
                                layer_to_add = layers_in_repo[idx]
                    except (ValueError, IndexError):
                        pass

            if not layer_to_add:
                # User cancelled layer selection - go back to list
                continue

            layer_name = os.path.basename(layer_to_add)
            print(f"\nAdding {layer_name} to bblayers.conf...")
            success, message, added = add_layer_to_bblayers(
                layer_to_add, bblayers_conf, collection_map
            )
            print(f"{message}\n")
            if success and added:
                # Update configured_layers with newly added layers
                for added_layer in added:
                    configured_layers.add(os.path.realpath(added_layer))
                # Also track the repo (add to __extra_repos__ if not already tracked)
                # Find the repo for this layer
                try:
                    layer_repo = subprocess.check_output(
                        ["git", "-C", layer_to_add, "rev-parse", "--show-toplevel"],
                        text=True, stderr=subprocess.DEVNULL
                    ).strip()
                    if layer_repo in discovered_repos or layer_repo in external_repos:
                        add_extra_repo(args.defaults_file, defaults, layer_repo)
                        discovered_repos.discard(layer_repo)
                        external_repos.discard(layer_repo)
                except subprocess.CalledProcessError:
                    pass
            continue
        elif list_action == "remove_layer" and selected_repo:
            # Skip special entries
            if selected_repo in ("HEADER", "PROJECT", "SETTINGS", "INFO") or selected_repo.startswith("SEPARATOR"):
                continue
            # Remove a layer from bblayers.conf
            # Determine which layer to remove
            layer_to_remove = None

            # Check if selected_repo is actually a layer path
            if os.path.isfile(os.path.join(selected_repo, "conf", "layer.conf")):
                layer_to_remove = selected_repo
            else:
                # It's a repo - get configured layers in this repo
                repo_layer_list = repo_layers.get(selected_repo, [])
                configured_in_repo = [l for l in repo_layer_list if os.path.realpath(l) in configured_layers]

                if not configured_in_repo:
                    print(f"\nNo configured layers in this repo to remove")
                    input("Press Enter to continue...")
                    continue
                elif len(configured_in_repo) == 1:
                    layer_to_remove = configured_in_repo[0]
                else:
                    # Multiple layers - let user choose with fzf
                    layer_names = [os.path.basename(l) for l in configured_in_repo]
                    fzf_input = "\n".join(layer_names)
                    try:
                        result = subprocess.run(
                            ["fzf", "--height", "~30%", "--prompt", "Remove layer: ", "--header", "Select layer to remove (Esc to cancel)"] + get_fzf_color_args(),
                            input=fzf_input,
                            capture_output=True,
                            text=True,
                        )
                        if result.returncode == 0 and result.stdout.strip():
                            selected_name = result.stdout.strip()
                            for l in configured_in_repo:
                                if os.path.basename(l) == selected_name:
                                    layer_to_remove = l
                                    break
                    except FileNotFoundError:
                        pass

            if not layer_to_remove:
                continue

            # Check layer is actually configured
            layer_realpath = os.path.realpath(layer_to_remove)
            if layer_realpath not in configured_layers:
                print(f"\n{os.path.basename(layer_to_remove)} is not in bblayers.conf")
                input("Press Enter to continue...")
                continue

            # Find bblayers.conf
            bblayers_conf = resolve_bblayers_path(args.bblayers)
            if not bblayers_conf:
                print("\nCould not find bblayers.conf")
                input("Press Enter to continue...")
                continue

            layer_name = os.path.basename(layer_to_remove)
            print(f"\nRemoving {layer_name} from bblayers.conf...")
            success, message = remove_layer_from_bblayers(layer_to_remove, bblayers_conf)
            print(f"{message}\n")

            if success:
                # Update configured_layers
                configured_layers.discard(layer_realpath)
                # If no layers remain configured in repo, mark as discovered
                repo_layer_list = repo_layers.get(selected_repo, [])
                if repo_layer_list and not any(os.path.realpath(l) in configured_layers for l in repo_layer_list):
                    # Find the repo for this layer
                    layer_repo = git_toplevel(layer_to_remove)
                    if layer_repo:
                        discovered_repos.add(layer_repo)
            continue
        elif list_action != "explore" or not selected_repo:
            continue

        # Handle special entries
        if selected_repo == "INFO":
            fzf_info_browser(args.bblayers)
            continue
        if selected_repo == "PROJECT":
            fzf_build_config(args.bblayers)
            continue

        # If selected_repo is a layer path (from layers view), resolve to its git repo
        explore_repo = selected_repo
        layer_filter = None
        if not os.path.isdir(os.path.join(selected_repo, ".git")):
            # Not a repo root - might be a layer, find parent repo
            repo_path = git_toplevel(selected_repo)
            if repo_path:
                layer_filter = selected_repo  # selected_repo is the layer path
                explore_repo = repo_path

        # Level 2: Commit browser (loop until back/quit)
        load_size = get_explore_load_size()
        upstream_pull_limit = 500
        context_limit = args.upstream_count
        scroll_to_context = 0
        while True:
            branch = current_branch(explore_repo) or "(detached)"
            if layer_filter and branch != "(detached)":
                commits, base_ref = get_local_commits_for_layer(explore_repo, branch, layer_filter)
            else:
                commits, base_ref = get_local_commits(explore_repo, branch)
            if not commits:
                commits = []
            upstream_context = get_upstream_context_commits(explore_repo, base_ref, context_limit) if base_ref else []

            if layer_filter and base_ref and branch != "(detached)":
                upstream_to_pull = get_upstream_to_pull_for_layer(explore_repo, branch, layer_filter, count=upstream_pull_limit)
            else:
                upstream_to_pull = get_upstream_to_pull(explore_repo, branch, count=upstream_pull_limit) if branch != "(detached)" else []

            layers = repo_layers.get(explore_repo, [])
            info = repo_info.get(explore_repo, {})
            lyr_counts = info.get("layer_upstream_counts", {})
            lyr_total = info.get("upstream_count", 0)
            action, selected_hashes = fzf_explore_commits(
                explore_repo, branch, commits, upstream_context, upstream_to_pull, base_ref or "HEAD",
                is_dirty=not repo_is_clean(explore_repo),
                layer_filter=layer_filter,
                layers=layers,
                layer_counts=lyr_counts,
                total_upstream=lyr_total,
                context_limit=context_limit,
                scroll_to_context=scroll_to_context,
            )

            scroll_to_context = 0  # reset after use
            if action == "back":
                break  # Return to repo list
            elif action == "load_more":
                scroll_to_context = len(upstream_context)
                upstream_pull_limit += load_size
                context_limit += load_size
                continue
            elif action == "quit":
                return 0  # Exit entirely
            elif action == "layer_view":
                if len(layers) > 1:
                    lv_action, _ = fzf_explore_layer_view(explore_repo, branch, layers, lyr_counts)
                    if lv_action == "quit":
                        return 0
                continue
            elif action == "copy" and selected_hashes:
                commit = selected_hashes[0]
                if copy_to_clipboard(commit):
                    print(f"Copied: {commit}")
                else:
                    print(f"Clipboard not available. Hash: {commit}")
            elif action == "export" and selected_hashes:
                export_commits_from_explore(explore_repo, selected_hashes)
            elif action == "rebase_interactive":
                if branch == "(detached)":
                    print(f"\n{Colors.yellow('Cannot rebase: detached HEAD')}")
                    input("Press Enter to continue...")
                elif not repo_is_clean(explore_repo):
                    print(f"\n{Colors.yellow('Cannot rebase: uncommitted changes')}")
                    input("Press Enter to continue...")
                elif not commits:
                    print(f"\n{Colors.yellow('Cannot rebase: no local commits')}")
                    input("Press Enter to continue...")
                elif not base_ref:
                    print(f"\n{Colors.yellow('Cannot rebase: no upstream reference')}")
                    input("Press Enter to continue...")
                else:
                    # Show commit selection for rebase range
                    rebase_base = fzf_select_rebase_range(explore_repo, branch, commits, base_ref)
                    if rebase_base:
                        success, msg = interactive_rebase_with_backup(explore_repo, rebase_base, branch)
                        print(f"\n{msg}")
                        input("Press Enter to continue...")
            elif action == "drop_commits":
                if branch == "(detached)":
                    print(f"\n{Colors.yellow('Cannot drop: detached HEAD')}")
                    input("Press Enter to continue...")
                elif not repo_is_clean(explore_repo):
                    print(f"\n{Colors.yellow('Cannot drop: uncommitted changes')}")
                    input("Press Enter to continue...")
                elif not commits:
                    print(f"\n{Colors.yellow('Cannot drop: no local commits')}")
                    input("Press Enter to continue...")
                elif not base_ref:
                    print(f"\n{Colors.yellow('Cannot drop: no upstream reference')}")
                    input("Press Enter to continue...")
                elif not selected_hashes:
                    print(f"\n{Colors.yellow('No commits selected')}")
                    input("Press Enter to continue...")
                else:
                    all_local = [h for h, _ in commits]
                    oldest_idx = len(all_local)
                    for sel_h in selected_hashes:
                        for i, loc_h in enumerate(all_local):
                            if loc_h == sel_h or loc_h.startswith(sel_h):
                                oldest_idx = min(oldest_idx, i)
                                break
                    if oldest_idx >= len(all_local):
                        print(f"\n{Colors.yellow('Selected commits not in local range')}")
                        input("Press Enter to continue...")
                    else:
                        to_drop = commits[oldest_idx:]
                        success, msg = drop_commits_with_backup(
                            explore_repo, to_drop, branch, base_ref
                        )
                        print(f"\n{msg}")
                        input("Press Enter to continue...")
            elif action == "tig":
                viewer = get_preferred_git_viewer()
                if not viewer:
                    print(f"\n{Colors.yellow('No git history viewer found.')}")
                    print("Install one of: tig, lazygit, or gitk")
                    print("  apt install tig  (or brew install tig)")
                    input("Press Enter to continue...")
                else:
                    # Launch the preferred viewer
                    if selected_hashes and viewer == "tig":
                        subprocess.run(["tig", "show", selected_hashes[0]], cwd=explore_repo)
                    elif selected_hashes and viewer == "lazygit":
                        subprocess.run(["lazygit"], cwd=explore_repo)
                    elif selected_hashes and viewer == "gitk":
                        subprocess.run(["gitk", selected_hashes[0]], cwd=explore_repo)
                    else:
                        subprocess.run([viewer], cwd=explore_repo)
            elif action == "patch_lookup" and selected_hashes:
                from .b4 import b4_patch_lookup
                b4_patch_lookup(explore_repo, selected_hashes[0])
            elif action == "tree_mode":
                commit_for_tree = selected_hashes[0] if selected_hashes else ""
                tree_action, _ = fzf_explore_tree(explore_repo, branch, focus_commit=commit_for_tree)
                if tree_action == "quit":
                    return 0
                continue

    return 0


