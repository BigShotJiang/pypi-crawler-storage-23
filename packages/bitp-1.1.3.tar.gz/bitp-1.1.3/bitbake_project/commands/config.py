#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Config command - view and configure repo/layer settings."""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from typing import Dict, List, Optional, Set, Tuple

from ..core import (
    Colors,
    current_branch,
    current_head,
    export_settings,
    fzf_available,
    get_fzf_preview_resize_bindings,
    git_toplevel,
    import_settings,
    load_defaults,
    repo_is_clean,
    save_defaults,
    FZF_THEMES,
    FZF_TEXT_COLORS,
    get_current_theme_name,
    get_current_text_color_name,
    get_fzf_color_args,
    get_custom_colors,
    fzf_theme_picker,
    fzf_text_color_picker,
    fzf_custom_color_menu,
    TERMINAL_COLOR_ELEMENTS,
    ANSI_COLORS,
    get_terminal_color,
    set_terminal_color,
    terminal_color,
    COLOR_MODES,
    get_color_mode,
    set_color_mode,
    _get_global_colors_file,
)
from .projects import (
    get_directory_browser,
    _pick_directory_browser,
    get_git_viewer,
    _pick_git_viewer,
    get_preview_layout,
    _pick_preview_layout,
    get_recipe_use_bitbake_layers,
    _pick_recipe_use_bitbake_layers,
)
from .common import (
    resolve_bblayers_path,
    resolve_base_and_layers,
    extract_layer_paths,
    collect_repos,
    repo_display_name,
    layer_display_name,
    get_push_target,
    set_push_target,
    remove_push_target,
    add_extra_repo,
    add_hidden_repo,
    remove_hidden_repo,
    get_hidden_repos,
    discover_layers,
    discover_git_repos,
    add_layer_to_bblayers,
    remove_layer_from_bblayers,
    build_layer_collection_map,
    get_upstream_count_ls_remote,
)
from ..tui import (
    ExploreMenuState,
    text_input_dialog,
    confirm_action_dialog,
)
from ..fzf_bindings import (
    get_exit_bindings,
    get_preview_header_suffix,
    get_preview_scroll_bindings,
    get_accept_binding,
)

def run_config_edit(args) -> int:
    """Edit a layer's layer.conf file in $EDITOR."""
    pairs, _repo_sets = resolve_base_and_layers(args.bblayers)
    layers = [layer for layer, repo in pairs]

    # Find the target layer by index, name, or path
    target_layer = None
    try:
        idx = int(args.layer)
        if 1 <= idx <= len(layers):
            target_layer = layers[idx - 1]
        else:
            print(f"Invalid index {idx}. Valid range: 1-{len(layers)}")
            return 1
    except ValueError:
        # Try matching by layer name (directory name)
        for layer in layers:
            if layer_display_name(layer).lower() == args.layer.lower():
                target_layer = layer
                break
        # Then try as path
        if not target_layer and os.path.isdir(args.layer):
            target_layer = os.path.abspath(args.layer)
        # Finally try partial path match
        if not target_layer:
            for layer in layers:
                if args.layer in layer or layer.endswith(args.layer):
                    target_layer = layer
                    break

    if not target_layer:
        print(f"Layer not found: {args.layer}")
        print("\nAvailable layers:")
        for idx, layer in enumerate(layers, start=1):
            print(f"  {idx}. {layer_display_name(layer)}: {layer}")
        return 1

    # Find layer.conf
    layer_conf = os.path.join(target_layer, "conf", "layer.conf")
    if not os.path.isfile(layer_conf):
        print(f"layer.conf not found: {layer_conf}")
        return 1

    # Get editor
    editor = os.environ.get("EDITOR", os.environ.get("VISUAL", "vi"))

    print(f"Editing: {layer_conf}")
    try:
        subprocess.run([editor, layer_conf], check=True)
        return 0
    except subprocess.CalledProcessError as e:
        print(f"Editor exited with code {e.returncode}")
        return e.returncode
    except FileNotFoundError:
        print(f"Editor not found: {editor}")
        print("Set $EDITOR environment variable to your preferred editor")
        return 1



def run_config(args) -> int:
    # Handle 'edit' command: config edit <layer>
    if args.repo == "edit":
        if not args.extra_arg:
            print("Usage: bit config edit <layer>")
            print("  layer: index, name, or path")
            return 1
        # Create a mock args object with layer attribute
        class EditArgs:
            pass
        edit_args = EditArgs()
        edit_args.bblayers = args.bblayers
        edit_args.layer = args.extra_arg
        return run_config_edit(edit_args)

    if args.repo == "export-settings":
        export_file = args.extra_arg or "bit-settings.json"
        count = export_settings(args.defaults_file, export_file)
        print(f"Exported {count} setting(s) to {export_file}")
        return 0

    if args.repo == "import-settings":
        if not args.extra_arg:
            import_file = "bit-settings.json"
        else:
            import_file = args.extra_arg
        if not os.path.exists(import_file):
            print(f"File not found: {import_file}")
            return 1
        count = import_settings(import_file, args.defaults_file)
        print(f"Imported {count} setting(s) from {import_file}")
        return 0

    defaults = load_defaults(args.defaults_file)
    repos, _repo_sets = collect_repos(args.bblayers, defaults)

    # If no repo specified, use fzf interactive interface
    if args.repo is None:
        return fzf_config_repos(repos, defaults, args.bblayers, args.defaults_file)

    # Find the target repo by index, display name, or path
    target_repo = None
    try:
        idx = int(args.repo)
        if 1 <= idx <= len(repos):
            target_repo = repos[idx - 1]
        else:
            print(f"Invalid index {idx}. Valid range: 1-{len(repos)}")
            return 1
    except ValueError:
        # Try matching by display name first
        for repo in repos:
            if repo_display_name(repo).lower() == args.repo.lower():
                target_repo = repo
                break
        # Then try as path
        if not target_repo and os.path.isdir(args.repo):
            target_repo = os.path.abspath(args.repo)
        # Finally try partial path match
        if not target_repo:
            for repo in repos:
                if args.repo in repo or repo.endswith(args.repo):
                    target_repo = repo
                    break

    if not target_repo:
        print(f"Repo not found: {args.repo}")
        return 1

    # If -e/--edit specified, open interactive submenu for this repo
    if getattr(args, 'edit', False):
        fzf_repo_config(target_repo, defaults, args.defaults_file)
        return 0

    # If no options specified, show current config for this repo
    if args.display_name is None and args.update_default is None:
        display = repo_display_name(target_repo)
        update_default = defaults.get(target_repo, "rebase")
        push_target = get_push_target(defaults, target_repo)
        print(f"Repo: {target_repo}")
        print(f"Display name: {display}")
        try:
            custom = subprocess.check_output(
                ["git", "-C", target_repo, "config", "--get", "bit.display-name"],
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
            if custom:
                print("  (custom override)")
            else:
                print("  (auto-detected)")
        except subprocess.CalledProcessError:
            print("  (auto-detected)")
        print(f"Update default: {update_default}")
        if push_target:
            print(f"Push target: {push_target.get('push_url', '')}")
            if push_target.get('branch_prefix'):
                print(f"  Branch prefix: {push_target['branch_prefix']}")
        return 0

    # Handle display name changes
    if args.display_name is not None:
        if args.display_name == "":
            # Clear custom name
            try:
                subprocess.run(
                    ["git", "-C", target_repo, "config", "--unset", "bit.display-name"],
                    check=True,
                )
                print(f"Cleared custom display name for {target_repo}")
                print(f"Now using: {repo_display_name(target_repo)}")
            except subprocess.CalledProcessError:
                print(f"No custom display name was set for {target_repo}")
        else:
            subprocess.run(
                ["git", "-C", target_repo, "config", "bit.display-name", args.display_name],
                check=True,
            )
            print(f"Set display name for {target_repo}")
            print(f"  {args.display_name}")

    # Handle update default changes
    if args.update_default is not None:
        old_default = defaults.get(target_repo, "rebase")
        defaults[target_repo] = args.update_default
        save_defaults(args.defaults_file, defaults)
        print(f"Set update default for {target_repo}")
        print(f"  {old_default} -> {args.update_default}")

    return 0



def show_repo_status_detail(repo: str, branch: str) -> None:
    """Show detailed status for a repo (local and upstream commits)."""
    if not branch:
        print("  (detached HEAD)")
        return

    # Local commits
    try:
        local_log = subprocess.check_output(
            ["git", "-C", repo, "log", "--oneline", f"origin/{branch}..HEAD"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        if local_log:
            lines = local_log.splitlines()
            print(f"  {len(lines)} local commit(s):")
            for line in lines[:10]:
                print(f"    {line}")
            if len(lines) > 10:
                print(f"    ... and {len(lines) - 10} more")
        else:
            print("  No local commits")
    except subprocess.CalledProcessError:
        print("  (could not get local commits)")

    # Upstream commits
    try:
        upstream_log = subprocess.check_output(
            ["git", "-C", repo, "log", "--oneline", f"HEAD..origin/{branch}"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        if upstream_log:
            lines = upstream_log.splitlines()
            print(f"  {len(lines)} upstream commit(s) to pull:")
            for line in lines[:5]:
                print(f"    {Colors.YELLOW}{line}{Colors.RESET}")
            if len(lines) > 5:
                print(f"    ... and {len(lines) - 5} more")
        else:
            print("  Up-to-date with upstream")
    except subprocess.CalledProcessError:
        print("  (could not get upstream commits)")

    # Working tree status
    is_clean = repo_is_clean(repo)
    if is_clean:
        print(f"  Working tree: {Colors.green('clean')}")
    else:
        print(f"  Working tree: {Colors.red('DIRTY')}")



def parse_config_variables(conf_path: str) -> List[Tuple[str, int, str]]:
    """
    Parse BitBake config file for variable assignments.
    Handles multi-line continuations (lines ending with backslash).
    Returns: [(var_name, line_number, raw_value), ...]
    """
    if not os.path.isfile(conf_path):
        return []

    results = []
    seen_vars = set()  # Track seen variable names to deduplicate
    # Match variable assignments: VAR = "...", VAR += "...", VAR:append = "...", etc.
    var_pattern = re.compile(r'^([A-Z_][A-Z0-9_]*(?::[a-z_]+)?)\s*[\?\+\.]*=')

    try:
        with open(conf_path, "r") as f:
            lines = f.readlines()

        i = 0
        while i < len(lines):
            line = lines[i]
            stripped = line.strip()
            if not stripped or stripped.startswith("#"):
                i += 1
                continue

            match = var_pattern.match(stripped)
            if match:
                var_name = match.group(1)
                start_line = i + 1  # 1-indexed

                # Extract value (everything after the = sign)
                eq_pos = stripped.find("=")
                value_parts = [stripped[eq_pos + 1:].strip()]

                # Handle line continuations (ending with \)
                while value_parts[-1].endswith("\\") and i + 1 < len(lines):
                    i += 1
                    cont_line = lines[i].strip()
                    # Remove trailing \ from previous part
                    value_parts[-1] = value_parts[-1][:-1].strip()
                    value_parts.append(cont_line)

                # Combine all parts
                full_value = " ".join(value_parts)
                # Clean up quotes and whitespace
                full_value = full_value.strip().strip('"').strip("'").strip()

                # Only add if we haven't seen this variable (deduplicate)
                if var_name not in seen_vars:
                    seen_vars.add(var_name)
                    # Truncate for display
                    display_value = full_value
                    if len(display_value) > 50:
                        display_value = display_value[:47] + "..."
                    results.append((var_name, start_line, display_value))

            i += 1
    except (IOError, OSError):
        pass

    return results



def fzf_build_config(bblayers_path: Optional[str] = None) -> None:
    """Show config menu for project conf files (local.conf, bblayers.conf)."""
    # Find conf directory
    bblayers_conf = resolve_bblayers_path(bblayers_path)
    if not bblayers_conf:
        print("\nCould not find bblayers.conf")
        input("Press Enter to continue...")
        return

    conf_dir = os.path.dirname(bblayers_conf)
    local_conf = os.path.join(conf_dir, "local.conf")

    # Track which files are expanded
    expanded_files: Set[str] = set()
    # Cache parsed variables
    var_cache: Dict[str, List[Tuple[str, int, str]]] = {}
    # Cache for bitbake-getvar results
    getvar_cache: Dict[str, str] = {}

    def get_variables(conf_path: str) -> List[Tuple[str, int, str]]:
        """Get cached variables for a config file."""
        if conf_path not in var_cache:
            var_cache[conf_path] = parse_config_variables(conf_path)
        return var_cache[conf_path]

    # Calculate max variable name length for alignment
    def get_max_var_len() -> int:
        max_len = 0
        for conf_path in [bblayers_conf, local_conf]:
            if conf_path in expanded_files:
                for var_name, _, _ in get_variables(conf_path):
                    max_len = max(max_len, len(var_name))
        return max_len

    # Create temp files for preview script and getvar cache
    getvar_cache_file = os.path.join(tempfile.gettempdir(), f"bit-getvar-{os.getpid()}.txt")
    preview_script_file = os.path.join(tempfile.gettempdir(), f"bit-preview-{os.getpid()}.sh")

    # Write preview script once (content doesn't change)
    with open(preview_script_file, "w") as f:
        f.write(f'''#!/bin/bash
item="$1"
cache_file="{getvar_cache_file}"
if [[ "$item" == VAR:* ]]; then
    var_name=$(echo "$item" | cut -d: -f2)
    file_path=$(echo "$item" | cut -d: -f3-)
    line_num="${{file_path##*:}}"
    file_path="${{file_path%:*}}"
    # Check if we have cached getvar output for this variable
    if [ -f "$cache_file" ]; then
        cached_var=$(head -1 "$cache_file" 2>/dev/null)
        if [ "$cached_var" = "$var_name" ]; then
            echo -e "\\033[1;36mbitbake-getvar $var_name\\033[0m"
            echo
            tail -n +2 "$cache_file"
            exit 0
        fi
    fi
    # Show value from file (15 lines to capture multi-line values)
    echo -e "\\033[1m$var_name\\033[0m (line $line_num)"
    echo
    [ -f "$file_path" ] && sed -n "${{line_num}},$((line_num + 14))p" "$file_path"
else
    file_path="${{item#FILE:}}"
    [ -f "$file_path" ] && head -40 "$file_path"
fi
''')
    os.chmod(preview_script_file, 0o755)
    preview_cmd = f"{preview_script_file} {{1}}"

    next_selection = None  # Track item to select after operations
    try:
        while True:
            menu_lines = []
            max_var_len = get_max_var_len()

            # bblayers.conf entry
            bblayers_vars = get_variables(bblayers_conf)
            expand_marker = "+ " if bblayers_vars and bblayers_conf not in expanded_files else "  "
            if bblayers_conf in expanded_files:
                expand_marker = "- "
            menu_lines.append(f"FILE:{bblayers_conf}\t{expand_marker}Edit bblayers.conf  conf/bblayers.conf")

            # Expanded variables for bblayers.conf
            if bblayers_conf in expanded_files:
                for i, (var_name, line_num, raw_value) in enumerate(bblayers_vars):
                    is_last = (i == len(bblayers_vars) - 1)
                    prefix = "  └─ " if is_last else "  ├─ "
                    # Show VAR = value aligned with colors
                    padded_name = f"{var_name:<{max_var_len}}"
                    display_value = raw_value if raw_value else '""'
                    if len(display_value) > 40:
                        display_value = display_value[:37] + "..."
                    colored_name = Colors.cyan(padded_name)
                    colored_value = Colors.green(display_value)
                    menu_lines.append(f"VAR:{var_name}:{bblayers_conf}:{line_num}\t{prefix}{colored_name} = {colored_value}")

            # local.conf entry
            if os.path.isfile(local_conf):
                local_vars = get_variables(local_conf)
                expand_marker = "+ " if local_vars and local_conf not in expanded_files else "  "
                if local_conf in expanded_files:
                    expand_marker = "- "
                menu_lines.append(f"FILE:{local_conf}\t{expand_marker}Edit local.conf     conf/local.conf")

                # Expanded variables for local.conf
                if local_conf in expanded_files:
                    for i, (var_name, line_num, raw_value) in enumerate(local_vars):
                        is_last = (i == len(local_vars) - 1)
                        prefix = "  └─ " if is_last else "  ├─ "
                        padded_name = f"{var_name:<{max_var_len}}"
                        display_value = raw_value if raw_value else '""'
                        if len(display_value) > 40:
                            display_value = display_value[:37] + "..."
                        colored_name = Colors.cyan(padded_name)
                        colored_value = Colors.green(display_value)
                        menu_lines.append(f"VAR:{var_name}:{local_conf}:{line_num}\t{prefix}{colored_name} = {colored_value}")
            else:
                menu_lines.append(f"FILE:{local_conf}\t  Edit local.conf     (not found)")

            header = f"Project config | Enter/←/→/\\=fold | r=bitbake-getvar | S=shell | q/←=back\n{get_preview_header_suffix()}"

            try:
                fzf_cmd = [
                    "fzf",
                    "--ansi",
                    "--no-multi",
                    "--no-sort",
                    "--layout=reverse-list",
                    "--height", "50%",
                    "--header", header,
                    "--prompt", "Select: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                    "--preview", preview_cmd,
                    "--preview-window", "right:60%:wrap",
                    "--bind", "b:become(echo FILE:" + bblayers_conf + ")",
                    "--bind", "l:become(echo FILE:" + local_conf + ")",
                    "--bind", "\\:become(echo EXPAND {1})",
                    "--bind", "r:become(echo GETVAR {1})",
                    "--bind", "S:become(echo SHELL)",
                    "--bind", "right:become(echo RIGHT {1})",
                ] + get_exit_bindings(mode="back") + [
                    "--bind", "left:become(echo LEFT {1})",  # Override left from exit bindings
                ] + get_preview_scroll_bindings(include_half_page=False) + get_fzf_preview_resize_bindings() + get_fzf_color_args()

                # Jump to selected item's position if we have one
                if next_selection:
                    for i, line in enumerate(menu_lines):
                        if line.startswith(next_selection + "\t"):
                            fzf_cmd.extend(["--sync", "--bind", f"load:pos({i + 1})"])
                            break
                    next_selection = None

                result = subprocess.run(
                    fzf_cmd,
                    input="\n".join(menu_lines),
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                print("fzf not found")
                return

            if result.returncode != 0 or not result.stdout.strip():
                break

            output = result.stdout.strip()

            if output == "BACK":
                break
            elif output == "SHELL":
                from .setup import run_init_shell
                ns = argparse.Namespace(layers_dir="layers")
                run_init_shell(ns)
                continue
            elif output.startswith("EXPAND "):
                # Toggle expansion of a file
                item = output[7:].strip()
                if item.startswith("FILE:"):
                    file_path = item[5:]
                    if file_path in expanded_files:
                        expanded_files.discard(file_path)
                    else:
                        expanded_files.add(file_path)
                elif item.startswith("VAR:"):
                    # Expanding on a variable - expand its parent file
                    parts = item.split(":")
                    if len(parts) >= 3:
                        file_path = ":".join(parts[2:-1])  # Handle paths with colons
                        if file_path in expanded_files:
                            expanded_files.discard(file_path)
                        else:
                            expanded_files.add(file_path)
                continue
            elif output.startswith("GETVAR "):
                # Run bitbake-getvar for a variable and cache result for preview
                item = output[7:].strip()
                if item.startswith("VAR:"):
                    parts = item.split(":")
                    if len(parts) >= 2:
                        var_name = parts[1]
                        # Check if bitbake-getvar is available
                        if not shutil.which("bitbake-getvar"):
                            print(f"\nbitbake-getvar not found in PATH.")
                            print("Source oe-init-build-env first to enable this feature.")
                            input("Press Enter to continue...")
                            continue
                        print(f"\nRunning: bitbake-getvar {var_name}...")
                        # Write result to cache file for preview
                        with open(getvar_cache_file, "w") as f:
                            f.write(var_name + "\n")
                        try:
                            getvar_result = subprocess.run(
                                ["bitbake-getvar", var_name],
                                stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT,
                                text=True,
                            )
                            with open(getvar_cache_file, "a") as f:
                                f.write(getvar_result.stdout)
                            # Jump back to this item so preview shows the result
                            next_selection = item
                            if getvar_result.returncode != 0:
                                print(f"Error: {getvar_result.stdout}")
                                input("Press Enter to continue...")
                        except FileNotFoundError:
                            print(f"\nbitbake-getvar not found.")
                            input("Press Enter to continue...")
                continue
            elif output.startswith("LEFT "):
                # Left arrow: collapse if expanded, back otherwise
                item = output[5:].strip()
                if item.startswith("FILE:"):
                    file_path = item[5:]
                    if file_path in expanded_files:
                        expanded_files.discard(file_path)
                        continue
                elif item.startswith("VAR:"):
                    # On a variable - collapse its parent file
                    parts = item.split(":")
                    if len(parts) >= 3:
                        file_path = ":".join(parts[2:-1])
                        if file_path in expanded_files:
                            expanded_files.discard(file_path)
                            continue
                # Not expanded or not a file - back
                break
            elif output.startswith("RIGHT "):
                # Right arrow: expand if expandable FILE:, otherwise accept
                item = output[6:].strip()
                if item.startswith("FILE:"):
                    file_path = item[5:]
                    if file_path not in expanded_files:
                        # Not expanded yet - expand it
                        expanded_files.add(file_path)
                        continue
                    # Already expanded - fall through to edit
                    output = item  # Rewrite as FILE: for handling below
                elif item.startswith("VAR:"):
                    output = item  # Rewrite as VAR: for handling below
                else:
                    continue
                via_right = True
            else:
                via_right = False
            if output.startswith("FILE:"):
                file_path = output.split("\t")[0][5:]
                if not via_right:
                    # Enter on FILE: toggles expansion
                    if file_path in expanded_files:
                        expanded_files.discard(file_path)
                    else:
                        expanded_files.add(file_path)
                    continue
                # RIGHT on already-expanded FILE: - edit
                if os.path.isfile(file_path):
                    editor = os.environ.get("EDITOR", os.environ.get("VISUAL", "vi"))
                    subprocess.run([editor, file_path])
                    # Clear cache after editing
                    var_cache.pop(file_path, None)
                else:
                    print(f"\nFile not found: {file_path}")
                    input("Press Enter to continue...")
            elif output.startswith("VAR:"):
                # Open editor at specific line - extract first field before tab
                first_field = output.split("\t")[0]
                parts = first_field.split(":")
                if len(parts) >= 4:
                    var_name = parts[1]
                    line_num = parts[-1]
                    file_path = ":".join(parts[2:-1])
                    if os.path.isfile(file_path):
                        editor = os.environ.get("EDITOR", os.environ.get("VISUAL", "vi"))
                        # Most editors support +line syntax
                        subprocess.run([editor, f"+{line_num}", file_path])
                        # Clear cache after editing
                        var_cache.pop(file_path, None)
    finally:
        # Cleanup temp files
        for tmp_file in [getvar_cache_file, preview_script_file]:
            if os.path.exists(tmp_file):
                try:
                    os.unlink(tmp_file)
                except OSError:
                    pass



def fzf_repo_config(
    repo: str,
    defaults: Dict[str, str],
    defaults_file: str,
) -> None:
    """Show config submenu for a single repo (standalone version for explore)."""
    dialog_state = ExploreMenuState()

    # Track state for two-step push target dialog
    pending_push_url: Optional[str] = None

    def get_display_name() -> Tuple[str, bool]:
        """Get display name and whether it's custom."""
        display = repo_display_name(repo)
        is_custom = False
        try:
            with open(defaults_file, "r") as f:
                for line in f:
                    if line.startswith(f"display:{repo}="):
                        is_custom = True
                        break
        except FileNotFoundError:
            pass
        return display, is_custom

    def pick_update_default() -> None:
        """Show submenu to pick update default."""
        display, _ = get_display_name()
        current = defaults.get(repo, "rebase")

        options = [
            ("rebase", "Rebase local commits on top of upstream"),
            ("merge", "Merge upstream into local branch"),
            ("skip", "Skip this repo during updates"),
        ]

        menu_lines = []
        for opt, desc in options:
            marker = "●" if opt == current else "○"
            menu_lines.append(f"{opt}\t{marker} {opt:<8} {desc}")

        header = f"Update default for {display}"

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--height", "~8",
                    "--header", header,
                    "--prompt", "Select: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        # Extract option from first field
        selected = output.split("\t")[0]
        if selected in ("rebase", "merge", "skip"):
            save_default(defaults_file, repo, selected)
            defaults[repo] = selected

    def edit_layer_conf() -> None:
        """Edit layer.conf for this repo."""
        # Find layer.conf files in this repo
        layer_confs = []
        for root, dirs, files in os.walk(repo):
            # Don't descend into .git
            if ".git" in dirs:
                dirs.remove(".git")
            if "layer.conf" in files:
                conf_path = os.path.join(root, "conf", "layer.conf")
                if os.path.isfile(conf_path):
                    layer_confs.append(conf_path)
                else:
                    # Check if it's directly in conf/
                    parent = os.path.dirname(root)
                    if os.path.basename(root) == "conf":
                        layer_confs.append(os.path.join(root, "layer.conf"))

        if not layer_confs:
            # Try standard location
            for item in os.listdir(repo):
                conf_path = os.path.join(repo, item, "conf", "layer.conf")
                if os.path.isfile(conf_path):
                    layer_confs.append(conf_path)

        if not layer_confs:
            print(f"\nNo layer.conf found in {repo}")
            input("Press Enter to continue...")
            return

        if len(layer_confs) == 1:
            editor = os.environ.get("EDITOR", os.environ.get("VISUAL", "vi"))
            subprocess.run([editor, layer_confs[0]])
        else:
            # Multiple - let user pick
            menu = "\n".join(layer_confs)
            try:
                result = subprocess.run(
                    ["fzf", "--height", "~10", "--header", "Select layer.conf to edit"] + get_fzf_color_args(),
                    input=menu,
                    stdout=subprocess.PIPE,
                    text=True,
                )
                if result.returncode == 0 and result.stdout.strip():
                    editor = os.environ.get("EDITOR", os.environ.get("VISUAL", "vi"))
                    subprocess.run([editor, result.stdout.strip()])
            except FileNotFoundError:
                pass

    while True:
        display, is_custom = get_display_name()
        update_default = defaults.get(repo, "rebase")
        has_dialog = dialog_state.has_dialog()

        display_suffix = " (custom)" if is_custom else " (auto)"
        push_target_data = get_push_target(defaults, repo)
        push_status = push_target_data.get("push_url", "")[:40] if push_target_data else "(not configured)"
        menu_lines = [
            f"DISPLAY\tDisplay name     {display}{display_suffix}",
            f"DEFAULT\tUpdate default   {update_default}",
            f"PUSH\tPush target      {push_status}",
            f"EDIT\tEdit layer.conf  →",
        ]

        # Build menu input
        menu_input = "\n".join(menu_lines)

        # Prepend dialog items if active
        if has_dialog:
            dialog_lines = dialog_state.get_dialog_menu_lines()
            dialog_input = "\n".join(f"{value}\t{display}" for value, display in dialog_lines)
            menu_input = dialog_input + "\n" + menu_input
            current_header = "Complete dialog above | Esc=cancel"
            current_prompt = dialog_state.get_prompt_text() or "Input: "
        else:
            current_header = f"Configure {display} ({repo})"
            current_prompt = "Select: "

        fzf_cmd = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--height", "~12",
            "--header", current_header,
            "--prompt", current_prompt,
            "--with-nth", "2..",
            "--delimiter", "\t",
        ] + get_fzf_color_args()

        if has_dialog:
            fzf_cmd.extend(["--print-query", "--bind", "esc:abort"])
        else:
            fzf_cmd.extend(get_exit_bindings(mode="back") + get_accept_binding())

        try:
            result = subprocess.run(
                fzf_cmd,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            if has_dialog:
                dialog_state.clear_dialog()
                continue
            return

        # Parse output based on dialog mode
        if has_dialog:
            lines = result.stdout.split("\n")
            query = lines[0] if lines else ""
            output = lines[1].strip() if len(lines) > 1 else ""

            # Handle dialog selection
            if dialog_state.is_dialog_selection(output.split("\t")[0] if output else ""):
                dlg_result = dialog_state.handle_dialog_selection(output.split("\t")[0], query)
                if dlg_result.confirmed and dialog_state.active_dialog.on_confirm:
                    dialog_state.active_dialog.on_confirm(dlg_result.value)
                dialog_state.clear_dialog()
                continue
        else:
            output = result.stdout.strip()

        if output == "BACK":
            return
        elif output.startswith("DISPLAY\t"):
            # Show inline dialog for display name
            current_display, _ = get_display_name()

            def on_display_confirm(new_name):
                key = f"display:{repo}"
                if new_name:
                    save_default(defaults_file, key, new_name)
                else:
                    remove_default(defaults_file, key)

            dialog_state.show_dialog(
                text_input_dialog(
                    title="Set display name",
                    message=f"Current: {current_display} | Empty to reset to auto",
                    default=current_display,
                    placeholder="Display name",
                    on_confirm=on_display_confirm,
                )
            )
        elif output.startswith("DEFAULT\t"):
            pick_update_default()
        elif output.startswith("PUSH\t"):
            # Show inline dialog for push URL (first step)
            push_target_data = get_push_target(defaults, repo)
            current_url = push_target_data.get("push_url", "") if push_target_data else ""
            current_prefix = push_target_data.get("branch_prefix", "") if push_target_data else ""

            def on_push_url_confirm(new_url):
                nonlocal pending_push_url
                if not new_url:
                    # Clear push target
                    remove_push_target(defaults_file, defaults, repo)
                else:
                    # Store URL and show prefix dialog
                    pending_push_url = new_url

                    def on_prefix_confirm(new_prefix):
                        nonlocal pending_push_url
                        if pending_push_url:
                            set_push_target(defaults_file, defaults, repo, pending_push_url, new_prefix or "")
                            pending_push_url = None

                    dialog_state.show_dialog(
                        text_input_dialog(
                            title="Branch prefix",
                            message="e.g. 'yourname/' or empty for none",
                            default=current_prefix,
                            placeholder="Prefix",
                            on_confirm=on_prefix_confirm,
                        )
                    )

            dialog_state.show_dialog(
                text_input_dialog(
                    title="Push URL",
                    message=f"Current: {current_url or '(not configured)'} | Empty to clear",
                    default=current_url,
                    placeholder="git@...",
                    on_confirm=on_push_url_confirm,
                )
            )
        elif output.startswith("EDIT\t"):
            edit_layer_conf()



def fzf_global_settings(defaults_file: str = ".bit.defaults") -> None:
    """Global settings menu for bit tool configuration.

    Accessible from the dashboard and from the config command.
    Covers colors/themes, directory browser, git viewer, preview layout,
    recipe scan, and b4 patch management.
    """
    from ..fzf_bindings import get_exit_bindings, get_accept_binding

    defaults = load_defaults(defaults_file)

    def _resolve_color_file():
        """Resolve the color file based on current mode."""
        mode = get_color_mode(defaults_file)
        if mode == "global":
            return _get_global_colors_file()
        elif mode == "custom":
            return defaults_file
        return None

    def _colors_submenu() -> None:
        """Show colors/theme submenu."""
        while True:
            color_mode = get_color_mode(defaults_file)
            mode_desc = COLOR_MODES.get(color_mode, color_mode)

            if color_mode == "global":
                color_file = _get_global_colors_file()
                header_source = "global (~/.config/bit/colors.json)"
            elif color_mode == "custom":
                color_file = defaults_file
                header_source = "per-project (.bit.defaults)"
            else:
                color_file = None
                header_source = "built-in defaults"

            current_theme = get_current_theme_name(defaults_file)
            theme_desc = FZF_THEMES.get(current_theme, ("", ""))[1]
            custom_colors = get_custom_colors(defaults_file)
            custom_count = len(custom_colors)
            custom_desc = f"{custom_count} override{'s' if custom_count != 1 else ''}" if custom_count else "none"

            terminal_overrides = sum(
                1 for elem in TERMINAL_COLOR_ELEMENTS
                if get_terminal_color(elem, defaults_file) != TERMINAL_COLOR_ELEMENTS[elem][0]
            )
            terminal_desc = f"{terminal_overrides} override{'s' if terminal_overrides != 1 else ''}" if terminal_overrides else "defaults"

            menu_lines = [
                f"MODE\tColor Mode       {color_mode} - {mode_desc}",
                f"THEME\tTheme            {current_theme} - {theme_desc}",
                f"CUSTOM\tIndividual       {custom_desc}",
                f"TERMINAL\tDisplay Colors   {terminal_desc}",
            ]

            header = f"Colors - {header_source} (←/q=back)"

            try:
                result = subprocess.run(
                    [
                        "fzf",
                        "--no-multi",
                        "--no-sort",
                        "--height", "~10",
                        "--header", header,
                        "--prompt", "Option: ",
                        "--with-nth", "2..",
                        "--delimiter", "\t",
                    ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                    input="\n".join(menu_lines),
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                return

            if result.returncode != 0 or not result.stdout.strip():
                return

            output = result.stdout.strip()

            if output == "BACK":
                return
            elif output.startswith("MODE\t"):
                _color_mode_picker()
            elif output.startswith("THEME\t"):
                if color_file is None:
                    _color_mode_picker()
                else:
                    fzf_theme_picker(color_file)
            elif output.startswith("CUSTOM\t"):
                if color_file is None:
                    _color_mode_picker()
                else:
                    fzf_custom_color_menu(color_file)
            elif output.startswith("TERMINAL\t"):
                if color_file is None:
                    _color_mode_picker()
                else:
                    _terminal_colors_submenu(color_file)

    def _color_mode_picker() -> None:
        """Show picker for color mode (default/global/custom)."""
        current_mode = get_color_mode(defaults_file)

        menu_lines = []
        for mode, desc in COLOR_MODES.items():
            marker = "● " if mode == current_mode else "  "
            menu_lines.append(f"{mode}\t{marker}{mode:<10} {desc}")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--height", "~8",
                    "--header", "Select color mode (←/q=back)",
                    "--prompt", "Mode: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        selected = output.split("\t")[0]
        if selected in COLOR_MODES:
            set_color_mode(selected, defaults_file)

    def _terminal_colors_submenu(color_file: str) -> None:
        """Show terminal output colors submenu."""
        while True:
            menu_lines = []
            for elem, (default_color, desc) in TERMINAL_COLOR_ELEMENTS.items():
                current = get_terminal_color(elem, defaults_file)
                is_default = (current == default_color)
                marker = "  " if is_default else "● "
                ansi_code = ANSI_COLORS.get(current, "\033[33m")
                sample = f"{ansi_code}■■■\033[0m"
                status = f"{current}" if not is_default else f"{current} (default)"
                menu_lines.append(f"{elem}\t{marker}{sample} {desc:<35} {status}")

            try:
                result = subprocess.run(
                    [
                        "fzf",
                        "--no-multi",
                        "--no-sort",
                        "--ansi",
                        "--height", "~15",
                        "--header", "Display Colors (←/q=back)\nColors used in dashboard, repos view, and status output",
                        "--prompt", "Element: ",
                        "--with-nth", "2..",
                        "--delimiter", "\t",
                    ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                    input="\n".join(menu_lines),
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                return

            if result.returncode != 0 or not result.stdout.strip():
                return

            output = result.stdout.strip()

            if output == "BACK":
                return

            elem = output.split("\t")[0] if "\t" in output else output
            if elem in TERMINAL_COLOR_ELEMENTS:
                _terminal_color_picker(elem, color_file)

    def _terminal_color_picker(element: str, color_file: str) -> None:
        """Pick a color for a terminal output element."""
        default_color = TERMINAL_COLOR_ELEMENTS[element][0]
        current = get_terminal_color(element, defaults_file)
        desc = TERMINAL_COLOR_ELEMENTS[element][1]

        menu_lines = []
        default_marker = "● " if current == default_color else "  "
        default_ansi = ANSI_COLORS.get(default_color, "\033[33m")
        menu_lines.append(f"(default)\t{default_marker}{default_ansi}■■■\033[0m (default: {default_color})")

        for name, ansi in sorted(ANSI_COLORS.items()):
            if name == default_color:
                continue
            marker = "● " if name == current else "  "
            menu_lines.append(f"{name}\t{marker}{ansi}■■■\033[0m {name}")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--ansi",
                    "--height", "~20",
                    "--header", f"Pick color for: {desc} (←/q=back)",
                    "--prompt", "Color: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        selected = output.split("\t")[0] if "\t" in output else output
        if selected == "(default)":
            set_terminal_color(element, "(default)", color_file)
        elif selected in ANSI_COLORS:
            set_terminal_color(element, selected, color_file)

    while True:
        color_mode = get_color_mode(defaults_file)
        current_theme = get_current_theme_name(defaults_file)
        custom_colors = get_custom_colors(defaults_file)
        custom_count = len(custom_colors)
        theme_summary = f"{color_mode}: {current_theme}"
        if custom_count:
            theme_summary += f" +{custom_count} custom"

        browser = get_directory_browser()
        browser_desc = {
            "auto": "auto-detect",
            "broot": "broot",
            "ranger": "ranger",
            "nnn": "nnn",
            "fzf": "fzf built-in"
        }.get(browser, browser)

        git_viewer = get_git_viewer()
        git_viewer_desc = {
            "auto": "auto-detect",
            "tig": "tig",
            "lazygit": "lazygit",
            "gitk": "gitk",
        }.get(git_viewer, git_viewer)

        preview_layout = get_preview_layout()
        preview_layout_desc = {
            "down": "bottom",
            "right": "side-by-side",
            "up": "top",
        }.get(preview_layout, preview_layout)

        use_bitbake_layers = get_recipe_use_bitbake_layers()
        recipe_scan_desc = "bitbake-layers" if use_bitbake_layers else "file scan"

        b4_installed = shutil.which("b4") is not None
        b4_desc = "available" if b4_installed else "not found"
        b4_list = defaults.get("b4_default_list", "")
        if b4_list:
            b4_desc += f", list: {b4_list}"

        # Display colors summary
        terminal_overrides = sum(
            1 for elem in TERMINAL_COLOR_ELEMENTS
            if get_terminal_color(elem, defaults_file) != TERMINAL_COLOR_ELEMENTS[elem][0]
        )
        display_desc = f"{terminal_overrides} override{'s' if terminal_overrides != 1 else ''}" if terminal_overrides else "defaults"

        menu_lines = [
            f"HEADER\t{Colors.bold(Colors.cyan('─── bit Settings ───'))}",
            f"COLORS\tColors/Themes    {theme_summary}",
            f"DISPLAY\tDisplay Colors   {display_desc}",
            f"BROWSER\tDir Browser      {browser_desc}",
            f"GITVIEWER\tGit Viewer       {git_viewer_desc}",
            f"PREVIEW\tPreview Layout   {preview_layout_desc}",
            f"RECIPE\tRecipe Scan      {recipe_scan_desc}",
            f"B4\tB4 Patch Mgmt    {b4_desc}",
        ]

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--ansi",
                    "--layout=reverse-list",
                    "--height", "~14",
                    "--header", "Customize colors, tools, and preferences (←/q=back)",
                    "--prompt", "Setting: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()

        if output == "BACK":
            return
        elif output.startswith("HEADER\t"):
            continue
        elif output.startswith("DISPLAY\t"):
            cf = _resolve_color_file()
            if cf:
                _terminal_colors_submenu(cf)
            else:
                _color_mode_picker()
        elif output.startswith("COLORS\t"):
            _colors_submenu()
        elif output.startswith("BROWSER\t"):
            _pick_directory_browser()
        elif output.startswith("GITVIEWER\t"):
            _pick_git_viewer()
        elif output.startswith("PREVIEW\t"):
            _pick_preview_layout()
        elif output.startswith("RECIPE\t"):
            _pick_recipe_use_bitbake_layers()
        elif output.startswith("B4\t"):
            _pick_b4_settings(defaults_file, defaults)


def _pick_b4_settings(defaults_file: str, defaults: dict) -> None:
    """Show b4 settings submenu for configuring mail-based patch management."""
    from ..fzf_bindings import get_exit_bindings, get_accept_binding
    from .b4 import (
        fzf_pick_mailing_list, get_b4_setting, get_b4_repo_config,
        set_b4_repo_config, remove_b4_repo_config,
        load_global_b4_config, save_global_b4_config,
    )

    while True:
        # Project-level settings
        current_list = get_b4_setting(defaults, "b4_default_list") or "(not set)"
        current_midmask = get_b4_setting(defaults, "b4_midmask") or "https://lore.kernel.org/%s"
        auto_trailers = get_b4_setting(defaults, "b4_auto_trailers") or "false"
        auto_desc = "on" if auto_trailers == "true" else "off"

        # Thread viewer setting
        thread_viewer = get_b4_setting(defaults, "b4_thread_viewer") or "terminal"
        viewer_desc = "terminal" if thread_viewer == "terminal" else "browser"

        # Source indicators (project vs global)
        list_source = "project" if defaults.get("b4_default_list") else "global"
        midmask_source = "project" if defaults.get("b4_midmask") else "global"
        trailers_source = "project" if defaults.get("b4_auto_trailers") else "global"
        viewer_source = "project" if defaults.get("b4_thread_viewer") else "global"

        # Repo associations
        b4_repos = defaults.get("__b4_repos__", {})
        repo_count = len(b4_repos)
        repo_desc = f"{repo_count} configured" if repo_count else "none"

        menu_lines = [
            f"LIST\tDefault Mailing List   {current_list}  ({list_source})",
            f"MIDMASK\tMessage-Id URL Mask   {current_midmask}  ({midmask_source})",
            f"TRAILERS\tAuto-check Trailers   {auto_desc}  ({trailers_source})",
            f"VIEWER\tThread Viewer          {viewer_desc}  ({viewer_source})",
            f"REPOS\tRepo Associations      {repo_desc}",
            f"---\t{Colors.dim('  ───────────────────')}",
            f"GLOBAL\tEdit Global Defaults   (~/.config/bit/b4.json)",
        ]

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-sort",
                    "--no-multi",
                    "--height", "~10",
                    "--header", "B4 Settings (\u2190/q=back)",
                    "--prompt", "Setting: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                    "--ansi",
                ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        key = output.split("\t")[0]

        if key == "LIST":
            picked = fzf_pick_mailing_list()
            if picked:
                defaults["b4_default_list"] = picked[0]
                save_defaults(defaults_file, defaults)
        elif key == "MIDMASK":
            try:
                val = input(f"Message-Id URL mask [{current_midmask}]: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                continue
            if val:
                defaults["b4_midmask"] = val
                save_defaults(defaults_file, defaults)
        elif key == "TRAILERS":
            new_val = "false" if auto_trailers == "true" else "true"
            defaults["b4_auto_trailers"] = new_val
            save_defaults(defaults_file, defaults)
        elif key == "VIEWER":
            new_val = "browser" if thread_viewer == "terminal" else "terminal"
            defaults["b4_thread_viewer"] = new_val
            save_defaults(defaults_file, defaults)
        elif key == "REPOS":
            _pick_b4_repo_associations(defaults_file, defaults)
        elif key == "GLOBAL":
            _pick_b4_global_settings()


def _pick_b4_repo_associations(defaults_file: str, defaults: dict) -> None:
    """Manage per-repo mailing list associations."""
    from ..fzf_bindings import get_exit_bindings, get_accept_binding
    from .b4 import (
        fzf_pick_mailing_list, get_b4_repo_config,
        set_b4_repo_config, remove_b4_repo_config,
    )
    from .common import repo_display_name

    while True:
        b4_repos = defaults.get("__b4_repos__", {})

        menu_lines = []
        if b4_repos:
            for repo_path, cfg in sorted(b4_repos.items()):
                display = repo_display_name(repo_path)
                ml = cfg.get("mailing_list", "")
                lore = cfg.get("lore_name", "")
                desc = lore if lore else ml
                menu_lines.append(f"{repo_path}\t{display:30s}  \u21a6 {desc}")
        else:
            menu_lines.append(f"---\t  No repos configured yet")

        menu_lines.append(f"---\t{Colors.dim('  \u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500')}")
        menu_lines.append(f"ADD\t  Add repo association...")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-sort",
                    "--no-multi",
                    "--height", "~10",
                    "--header", "Repo \u21a6 Mailing List Associations (\u2190/q=back)\nSelect to edit/remove",
                    "--prompt", "Repo: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                    "--ansi",
                ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        key = output.split("\t")[0]

        if key in ("---", ""):
            continue
        elif key == "ADD":
            # Pick a repo, then a mailing list
            try:
                repo_path = input("Repository path: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                continue
            if not repo_path:
                continue
            repo_path = os.path.expanduser(repo_path)
            picked = fzf_pick_mailing_list(repo=repo_path)
            if picked:
                set_b4_repo_config(defaults_file, defaults, repo_path, picked[0], picked[1])
                print(f"Configured {repo_display_name(repo_path)} \u21a6 {picked[0]}")
                input("Press Enter to continue...")
        elif key in b4_repos:
            # Edit/remove existing
            display = repo_display_name(key)
            cfg = b4_repos[key]
            ml = cfg.get("mailing_list", "")
            print(f"\n{display} \u21a6 {ml}")
            try:
                choice = input("[C]hange list / [R]emove / Enter=keep: ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                print()
                continue
            if choice in ("c", "change"):
                picked = fzf_pick_mailing_list(repo=key)
                if picked:
                    set_b4_repo_config(defaults_file, defaults, key, picked[0], picked[1])
                    print(f"Updated {display} \u21a6 {picked[0]}")
                    input("Press Enter to continue...")
            elif choice in ("r", "remove"):
                remove_b4_repo_config(defaults_file, defaults, key)
                print(f"Removed {display}")
                input("Press Enter to continue...")


def _pick_b4_global_settings() -> None:
    """Edit global b4 defaults (~/.config/bit/b4.json)."""
    from ..fzf_bindings import get_exit_bindings, get_accept_binding
    from .b4 import load_global_b4_config, save_global_b4_config, fzf_pick_mailing_list

    while True:
        config = load_global_b4_config()
        current_list = config.get("default_list", "(not set)")
        current_midmask = config.get("midmask", "https://lore.kernel.org/%s")
        auto_trailers = config.get("auto_trailers", False)
        auto_desc = "on" if auto_trailers else "off"

        menu_lines = [
            f"LIST\tDefault Mailing List   {current_list}",
            f"MIDMASK\tMessage-Id URL Mask   {current_midmask}",
            f"TRAILERS\tAuto-check Trailers   {auto_desc}",
        ]

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-sort",
                    "--no-multi",
                    "--height", "~8",
                    "--header", "Global B4 Defaults (~/.config/bit/b4.json)  (\u2190/q=back)",
                    "--prompt", "Setting: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        key = output.split("\t")[0]

        if key == "LIST":
            picked = fzf_pick_mailing_list()
            if picked:
                config["default_list"] = picked[0]
                save_global_b4_config(config)
        elif key == "MIDMASK":
            try:
                val = input(f"Message-Id URL mask [{current_midmask}]: ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                continue
            if val:
                config["midmask"] = val
                save_global_b4_config(config)
        elif key == "TRAILERS":
            config["auto_trailers"] = not auto_trailers
            save_global_b4_config(config)


def fzf_config_repos(
    repos: List[str],
    defaults: Dict[str, str],
    bblayers_path: str,
    defaults_file: str,
) -> int:
    """
    Interactive fzf-based config interface.
    Returns exit code.
    """
    if not repos:
        print("No repos found.")
        return 1

    def get_repo_info(repo: str) -> Tuple[str, bool]:
        """Get display name and whether it's custom."""
        display = repo_display_name(repo)
        is_custom = False
        try:
            custom = subprocess.check_output(
                ["git", "-C", repo, "config", "--get", "bit.display-name"],
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
            if custom:
                is_custom = True
        except subprocess.CalledProcessError:
            pass
        return display, is_custom

    def build_menu_lines() -> str:
        """Build fzf menu input with header as last line (appears at top in fzf)."""
        menu_lines = []
        max_name_len = 20

        # First pass to get max name length
        for repo in repos:
            display, _ = get_repo_info(repo)
            if len(display) + 1 > max_name_len:  # +1 for potential *
                max_name_len = len(display) + 1

        # Data lines in reverse order (so they display 1,2,3... from top in fzf)
        data_lines = []
        for idx, repo in enumerate(repos, start=1):
            display, is_custom = get_repo_info(repo)
            if is_custom:
                display = f"{display}*"
            update_default = defaults.get(repo, "rebase")
            line = f"{repo}\t{idx:<4} {display:<{max_name_len}} {update_default:<10} {repo}"
            data_lines.append(line)

        # Add special "project" entry for project config (with separator)
        bblayers_conf = resolve_bblayers_path(bblayers_path)
        if bblayers_conf:
            conf_dir = os.path.dirname(bblayers_conf)
            # Add separator before project
            data_lines.append(f"SEPARATOR\t")  # Empty separator line
            # Pad plain text first, then apply color (ANSI codes don't take visual space)
            project_name = f"{'project':<{max_name_len}}"
            build_line = f"PROJECT\t{'P':<4} {terminal_color('project_active', project_name)} {'—':<10} {conf_dir}"
            data_lines.append(build_line)

        # Add "bit" entry for tool settings
        settings_name = f"{'bit':<{max_name_len}}"
        settings_line = f"SETTINGS\t{'S':<4} {Colors.magenta(settings_name)} {'—':<10} configure options"
        data_lines.append(settings_line)

        # Reverse so item N is first in input (appears at bottom), item 1 is near end
        menu_lines = list(reversed(data_lines))

        # Column header as LAST line (appears at TOP in default fzf layout)
        col_header = f"HEADER\t{'#':<4} {'Name':<{max_name_len}} {'Default':<10} Path"
        # Separator line under header (second-to-last, appears just below header)
        sep_len = 4 + 1 + max_name_len + 1 + 10 + 1 + 20  # rough width matching columns
        separator = f"SEPARATOR\t{'─' * sep_len}"
        menu_lines.append(separator)
        menu_lines.append(col_header)

        return "\n".join(menu_lines)

    def set_display_name(repo: str) -> None:
        """Prompt and set display name for a repo."""
        current, is_custom = get_repo_info(repo)
        try:
            if is_custom:
                new_name = input(f"\nDisplay name [{current}] (empty to clear): ").strip()
            else:
                new_name = input(f"\nDisplay name [{current}]: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n  Cancelled.")
            return

        if new_name == "" and is_custom:
            # Clear custom name
            try:
                subprocess.run(
                    ["git", "-C", repo, "config", "--unset", "bit.display-name"],
                    check=True,
                )
                print(f"  Cleared. Now using: {repo_display_name(repo)}")
            except subprocess.CalledProcessError:
                pass
        elif new_name:
            subprocess.run(
                ["git", "-C", repo, "config", "bit.display-name", new_name],
                check=True,
            )
            print(f"  Set to: {new_name}")
        else:
            print("  Unchanged.")

    def set_update_default(repo: str, new_default: str) -> None:
        """Set update default for a repo."""
        old_default = defaults.get(repo, "rebase")
        if old_default == new_default:
            display, _ = get_repo_info(repo)
            print(f"\n  {display}: already set to {new_default}")
            return
        defaults[repo] = new_default
        save_defaults(defaults_file, defaults)
        display, _ = get_repo_info(repo)
        print(f"\n  {display}: {old_default} → {new_default}")

    def edit_layer_conf(repo: str) -> None:
        """Edit layer.conf for a repo."""
        # Find layers in this repo
        pairs, _repo_sets = resolve_base_and_layers(bblayers_path)
        repo_layers = [layer for layer, r in pairs if r == repo]

        if not repo_layers:
            print(f"\n  No layers found in {repo}")
            return

        if len(repo_layers) == 1:
            layer = repo_layers[0]
        else:
            # Multiple layers - use fzf to pick
            display_name, _ = get_repo_info(repo)
            menu_lines = []
            bindings = []
            for i, lyr in enumerate(repo_layers, start=1):
                # Format: "layer_path\t#  layer_name"
                menu_lines.append(f"{lyr}\t{i}  {layer_display_name(lyr)}")
                # Add number key binding (1-9)
                if i <= 9:
                    bindings.extend(["--bind", f"{i}:become(echo {lyr})"])

            try:
                result = subprocess.run(
                    [
                        "fzf",
                        "--no-multi",
                        "--no-sort",
                        "--height", "~10",
                        "--header", f"Select layer in {display_name} (←=back, 1-{min(len(repo_layers), 9)} or Enter)",
                        "--prompt", "Layer: ",
                        "--with-nth", "2..",
                        "--delimiter", "\t",
                    ] + get_exit_bindings(mode="back") + bindings + get_fzf_color_args(),
                    input="\n".join(menu_lines),
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                print("  fzf not found")
                return

            if result.returncode != 0 or not result.stdout.strip():
                return

            output = result.stdout.strip()
            if output == "BACK":
                return
            # Extract layer path (either raw path from number key, or first field from selection)
            if "\t" in output:
                layer = output.split("\t")[0]
            else:
                layer = output

        layer_conf = os.path.join(layer, "conf", "layer.conf")
        if not os.path.isfile(layer_conf):
            print(f"\n  layer.conf not found: {layer_conf}")
            return

        editor = os.environ.get("EDITOR", os.environ.get("VISUAL", "vi"))
        print(f"\n  Editing: {layer_conf}")
        try:
            subprocess.run([editor, layer_conf], check=True)
        except (subprocess.CalledProcessError, FileNotFoundError) as e:
            print(f"  Error: {e}")

    def show_repo_submenu(repo: str) -> None:
        """Show config submenu for a single repo."""
        submenu_dialog_state = ExploreMenuState()
        pending_push_url: Optional[str] = None

        while True:
            display, is_custom = get_repo_info(repo)
            update_default = defaults.get(repo, "rebase")
            has_dialog = submenu_dialog_state.has_dialog()

            # Build menu showing current values
            display_suffix = " (custom)" if is_custom else " (auto)"
            push_target = get_push_target(defaults, repo)
            push_status = push_target.get("push_url", "")[:40] if push_target else "(not configured)"
            menu_lines = [
                f"DISPLAY\tDisplay name     {display}{display_suffix}",
                f"DEFAULT\tUpdate default   {update_default}",
                f"PUSH\tPush target      {push_status}",
                f"EDIT\tEdit layer.conf  →",
            ]

            menu_input = "\n".join(menu_lines)

            # Prepend dialog items if active
            if has_dialog:
                dialog_lines = submenu_dialog_state.get_dialog_menu_lines()
                dialog_input = "\n".join(f"{value}\t{disp}" for value, disp in dialog_lines)
                menu_input = dialog_input + "\n" + menu_input
                current_header = "Complete dialog above | Esc=cancel"
                current_prompt = submenu_dialog_state.get_prompt_text() or "Input: "
            else:
                current_header = f"Configure {display} ({repo})"
                current_prompt = "Select: "

            fzf_cmd = [
                "fzf",
                "--no-multi",
                "--no-sort",
                "--ansi",
                "--height", "~12",
                "--header", current_header,
                "--prompt", current_prompt,
                "--with-nth", "2..",
                "--delimiter", "\t",
            ] + get_fzf_color_args()

            if has_dialog:
                fzf_cmd.extend(["--print-query", "--bind", "esc:abort"])
            else:
                fzf_cmd.extend(get_exit_bindings(mode="back") + get_accept_binding())

            try:
                result = subprocess.run(
                    fzf_cmd,
                    input=menu_input,
                    stdout=subprocess.PIPE,
                    text=True,
                )
            except FileNotFoundError:
                return

            if result.returncode != 0 or not result.stdout.strip():
                if has_dialog:
                    submenu_dialog_state.clear_dialog()
                    continue
                return

            # Parse output based on dialog mode
            if has_dialog:
                lines = result.stdout.split("\n")
                query = lines[0] if lines else ""
                output = lines[1].strip() if len(lines) > 1 else ""

                if submenu_dialog_state.is_dialog_selection(output.split("\t")[0] if output else ""):
                    dlg_result = submenu_dialog_state.handle_dialog_selection(output.split("\t")[0], query)
                    if dlg_result.confirmed and submenu_dialog_state.active_dialog.on_confirm:
                        submenu_dialog_state.active_dialog.on_confirm(dlg_result.value)
                    submenu_dialog_state.clear_dialog()
                    continue
            else:
                output = result.stdout.strip()

            if output == "BACK":
                return
            elif output.startswith("DISPLAY\t"):
                # Show inline dialog for display name
                def on_display_confirm(new_name):
                    if new_name == "" and is_custom:
                        try:
                            subprocess.run(
                                ["git", "-C", repo, "config", "--unset", "bit.display-name"],
                                check=True,
                            )
                        except subprocess.CalledProcessError:
                            pass
                    elif new_name:
                        subprocess.run(
                            ["git", "-C", repo, "config", "bit.display-name", new_name],
                            check=True,
                        )

                submenu_dialog_state.show_dialog(
                    text_input_dialog(
                        title="Set display name",
                        message=f"Current: {display} | Empty to {'clear' if is_custom else 'keep'}",
                        default=display if is_custom else "",
                        placeholder="Display name",
                        on_confirm=on_display_confirm,
                    )
                )
            elif output.startswith("DEFAULT\t"):
                pick_update_default(repo)
            elif output.startswith("EDIT\t"):
                edit_layer_conf(repo)
            elif output.startswith("PUSH\t"):
                # Show inline dialog for push URL
                current_url = push_target.get("push_url", "") if push_target else ""
                current_prefix = push_target.get("branch_prefix", "") if push_target else ""

                def on_push_url_confirm(new_url):
                    nonlocal pending_push_url
                    if not new_url:
                        remove_push_target(defaults_file, defaults, repo)
                    else:
                        pending_push_url = new_url

                        def on_prefix_confirm(new_prefix):
                            nonlocal pending_push_url
                            if pending_push_url:
                                set_push_target(defaults_file, defaults, repo, pending_push_url, new_prefix or "")
                                pending_push_url = None

                        submenu_dialog_state.show_dialog(
                            text_input_dialog(
                                title="Branch prefix",
                                message="e.g. 'yourname/' or empty for none",
                                default=current_prefix,
                                placeholder="Prefix",
                                on_confirm=on_prefix_confirm,
                            )
                        )

                submenu_dialog_state.show_dialog(
                    text_input_dialog(
                        title="Push URL",
                        message=f"Current: {current_url or '(not configured)'} | Empty to clear",
                        default=current_url,
                        placeholder="git@...",
                        on_confirm=on_push_url_confirm,
                    )
                )

    def configure_push_target(repo: str) -> None:
        """Configure push target for a repo."""
        display, _ = get_repo_info(repo)
        push_target = get_push_target(defaults, repo)
        current_url = push_target.get("push_url", "") if push_target else ""
        current_prefix = push_target.get("branch_prefix", "") if push_target else ""

        print(f"\nPush target for {display}")
        print(f"Current push URL: {current_url or '(not configured)'}")
        print(f"Current branch prefix: {current_prefix or '(none)'}")
        print()

        new_url = input("Push URL (empty to clear, - to keep): ").strip()
        if new_url == "-":
            new_url = current_url
        elif not new_url:
            # Clear the push target
            remove_push_target(defaults_file, defaults, repo)
            print("Push target cleared.")
            input("Press Enter to continue...")
            return

        new_prefix = input("Branch prefix (e.g. 'yourname/', empty for none, - to keep): ").strip()
        if new_prefix == "-":
            new_prefix = current_prefix

        set_push_target(defaults_file, defaults, repo, new_url, new_prefix)
        print(f"Push target set: {new_url}")
        if new_prefix:
            print(f"Branch prefix: {new_prefix}")
        input("Press Enter to continue...")

    def show_build_config() -> None:
        """Show config submenu for project conf files."""
        fzf_build_config(bblayers_path)

    def show_settings_submenu() -> None:
        """Show settings submenu for bit tool configuration."""
        fzf_global_settings(defaults_file)

    def pick_update_default(repo: str) -> None:
        """Show submenu to pick update default."""
        display, _ = get_repo_info(repo)
        current = defaults.get(repo, "rebase")

        menu_lines = []
        for opt in ["rebase", "merge", "skip"]:
            marker = "●" if opt == current else "○"
            menu_lines.append(f"{opt}\t{marker} {opt}")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--height", "~6",
                    "--header", f"Update default for {display}",
                    "--prompt", "Default: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                    "--bind", "r:become(echo rebase)",
                    "--bind", "m:become(echo merge)",
                    "--bind", "s:become(echo skip)",
                ] + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        # Handle both direct key (rebase) and selection (rebase\t● rebase)
        new_default = output.split("\t")[0]
        if new_default in ("rebase", "merge", "skip"):
            set_update_default(repo, new_default)

    header = "Enter/→=configure | d=display | r=rebase | m=merge | s=skip | e=edit | q=quit"

    while True:
        menu_input = build_menu_lines()

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--no-info",
                    "--ansi",
                    "--height", "~50%",
                    "--header", header,
                    "--prompt", "Config: ",
                    "--with-nth", "2..",  # Hide repo path / HEADER marker (field 1)
                    "--delimiter", "\t",
                    "--bind", "q:become(echo QUIT)",
                    "--bind", "d:become(echo DISPLAY {1})",
                    "--bind", "r:become(echo REBASE {1})",
                    "--bind", "m:become(echo MERGE {1})",
                    "--bind", "s:become(echo SKIP {1})",
                    "--bind", "e:become(echo EDIT {1})",
                ] + get_accept_binding() + get_fzf_color_args(),
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            print("fzf not found. Use CLI: bit config <repo> --display-name/--update-default")
            return 1

        if result.returncode != 0 or not result.stdout.strip():
            break

        output = result.stdout.strip()

        if output == "QUIT":
            break
        elif output.startswith("DISPLAY "):
            repo_path = output[8:].strip()
            if repo_path not in ("HEADER", "SEPARATOR"):
                set_display_name(repo_path)
        elif output.startswith("REBASE "):
            repo_path = output[7:].strip()
            if repo_path not in ("HEADER", "SEPARATOR"):
                set_update_default(repo_path, "rebase")
        elif output.startswith("MERGE "):
            repo_path = output[6:].strip()
            if repo_path not in ("HEADER", "SEPARATOR"):
                set_update_default(repo_path, "merge")
        elif output.startswith("SKIP "):
            repo_path = output[5:].strip()
            if repo_path not in ("HEADER", "SEPARATOR"):
                set_update_default(repo_path, "skip")
        elif output.startswith("EDIT "):
            repo_path = output[5:].strip()
            if repo_path not in ("HEADER", "SEPARATOR"):
                edit_layer_conf(repo_path)
        elif "\t" in output:
            # Enter was pressed - drill into submenu (ignore header/separator lines)
            repo_path = output.split("\t")[0]
            if repo_path == "PROJECT":
                show_build_config()
            elif repo_path == "SETTINGS":
                show_settings_submenu()
            elif repo_path not in ("HEADER", "SEPARATOR"):
                show_repo_submenu(repo_path)

    return 0


