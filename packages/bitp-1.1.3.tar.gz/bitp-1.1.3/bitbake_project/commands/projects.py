#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Projects command - manage multiple bit working directories."""

import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from typing import Dict, List, Optional, Tuple

from ..core import (
    Colors, get_fzf_color_args, get_fzf_preview_resize_bindings, fzf_available,
    terminal_color, TERMINAL_COLOR_ELEMENTS, ANSI_COLORS,
    get_terminal_color, set_terminal_color, _get_global_colors_file,
    get_color_mode,
)
from ..fzf_bindings import get_exit_bindings, get_preview_scroll_bindings, get_action_binding, get_position_binding


def _get_projects_file() -> str:
    """Get path to global projects config file."""
    config_dir = os.path.expanduser("~/.config/bit")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, "projects.json")


def load_projects() -> Dict[str, dict]:
    """
    Load projects from config file.

    Returns dict mapping path -> {name, description, last_used}.
    Excludes internal keys like __current_project__, __directory_browser__, etc.
    """
    projects_file = _get_projects_file()
    if not os.path.isfile(projects_file):
        return {}
    try:
        with open(projects_file, "r") as f:
            data = json.load(f)
            # Filter out internal keys (start with __)
            return {k: v for k, v in data.items() if not k.startswith("__")}
    except (json.JSONDecodeError, OSError):
        return {}


def get_current_project() -> Optional[str]:
    """Get the currently active project path, or None if not set."""
    config_file = _get_projects_file()
    if not os.path.isfile(config_file):
        return None
    try:
        with open(config_file, "r") as f:
            data = json.load(f)
            path = data.get("__current_project__")
            # Verify it still exists
            if path and os.path.isdir(path):
                return path
            return None
    except (json.JSONDecodeError, OSError):
        return None


def find_project_for_directory(directory: Optional[str] = None) -> Optional[str]:
    """Return the registered project path that contains `directory`.

    If `directory` is inside (or equal to) a registered project, return that
    project's path.  When multiple projects match (nested), the deepest
    (longest path) wins.  Returns None if no project matches.
    """
    cwd = os.path.abspath(directory or os.getcwd())
    projects = load_projects()
    best_match: Optional[str] = None
    best_len = 0
    for proj_path in projects:
        proj = os.path.abspath(proj_path)
        # cwd must be the project dir itself or a subdirectory
        if cwd == proj or cwd.startswith(proj + os.sep):
            if len(proj) > best_len:
                best_match = proj
                best_len = len(proj)
    return best_match


def resolve_project_by_name(name: str) -> Optional[str]:
    """Resolve a project short name to its path.

    Matches case-insensitively against registered project names.
    Also accepts a direct path if it matches a registered project.
    Returns the project path or None.
    """
    projects = load_projects()

    # Direct path match
    if name in projects:
        return name

    # Name match (case-insensitive)
    for proj_path, info in projects.items():
        if info.get("name", "").lower() == name.lower():
            return proj_path

    return None


def set_current_project(path: Optional[str]) -> None:
    """Set the currently active project path (or None to clear)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass

    if path:
        data["__current_project__"] = os.path.abspath(path)
    elif "__current_project__" in data:
        del data["__current_project__"]

    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def save_projects(projects: Dict[str, dict]) -> None:
    """Save projects to config file."""
    projects_file = _get_projects_file()
    try:
        with open(projects_file, "w") as f:
            json.dump(projects, f, indent=2)
    except OSError as e:
        print(f"Warning: Could not save projects: {e}", file=sys.stderr)


def add_project(path: str, name: Optional[str] = None, description: str = "") -> bool:
    """
    Add a project to the list.

    Args:
        path: Absolute path to the project directory
        name: Display name (defaults to directory basename)
        description: Optional description

    Returns:
        True if added, False if already exists or invalid
    """
    path = os.path.abspath(path)
    if not os.path.isdir(path):
        print(f"Error: Not a directory: {path}", file=sys.stderr)
        return False

    projects = load_projects()
    if path in projects:
        print(f"Project already registered: {path}")
        return False

    if not name:
        name = os.path.basename(path)

    projects[path] = {
        "name": name,
        "description": description,
        "last_used": None,
    }
    save_projects(projects)
    print(f"Added project: {name} ({path})")

    # Write .ignore so ripgrep/fd/etc skip build directories
    from .common import write_ignore_file
    if write_ignore_file(path):
        print(f"Wrote {os.path.join(path, '.ignore')} (excludes build*/ from searches)")

    return True


def remove_project(path: str) -> bool:
    """Remove a project from the list."""
    path = os.path.abspath(path)
    projects = load_projects()
    if path not in projects:
        print(f"Project not found: {path}", file=sys.stderr)
        return False

    name = projects[path].get("name", path)
    del projects[path]
    save_projects(projects)
    print(f"Removed project: {name}")
    return True


def _detect_project_info(path: str) -> dict:
    """Detect info about a potential project directory."""
    info = {
        "has_bblayers": False,
        "has_defaults": False,
        "layer_count": 0,
        "branch": None,
    }

    # Check for bblayers.conf in build/conf or any conf directory
    for root, dirs, files in os.walk(path):
        depth = root[len(path):].count(os.sep)
        if depth > 3:
            dirs[:] = []
            continue
        if "bblayers.conf" in files:
            info["has_bblayers"] = True
            break

    # Check for defaults file
    if os.path.isfile(os.path.join(path, ".bit.defaults")):
        info["has_defaults"] = True

    # Count layers
    for root, dirs, files in os.walk(path):
        depth = root[len(path):].count(os.sep)
        if depth > 4:
            dirs[:] = []
            continue
        if "layer.conf" in files and "conf" in root:
            info["layer_count"] += 1

    # Get git branch if in a git repo
    try:
        result = subprocess.run(
            ["git", "-C", path, "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
        )
        if result.returncode == 0:
            info["branch"] = result.stdout.strip()
    except Exception:
        pass

    return info


_project_info_cache: Dict[str, Tuple[float, dict]] = {}
_CACHE_TTL = 30.0


def _detect_project_info_fast(path: str) -> dict:
    """Detect project info with caching and fast checks.

    Uses a 30s TTL cache. Checks only standard bblayers.conf locations
    (conf/ and build/conf/) instead of walking the tree. Falls back to
    full _detect_project_info() for layer count on first load.
    """
    now = time.monotonic()
    if path in _project_info_cache:
        ts, cached = _project_info_cache[path]
        if now - ts < _CACHE_TTL:
            return cached

    info = {
        "has_bblayers": False,
        "has_defaults": False,
        "layer_count": 0,
        "branch": None,
        "is_dirty": False,
        "ahead": 0,
        "behind": 0,
    }

    if not os.path.isdir(path):
        _project_info_cache[path] = (now, info)
        return info

    # Fast check: bblayers.conf in standard locations only
    for subdir in ("conf", "build/conf"):
        if os.path.isfile(os.path.join(path, subdir, "bblayers.conf")):
            info["has_bblayers"] = True
            break

    # Check for defaults file
    if os.path.isfile(os.path.join(path, ".bit.defaults")):
        info["has_defaults"] = True

    # Find primary git repo — project root first, then common Yocto subdirs
    git_dir = None
    if os.path.isdir(os.path.join(path, ".git")):
        git_dir = path
    else:
        for subdir in ("poky", "oe-core", "openembedded-core"):
            candidate = os.path.join(path, subdir)
            if os.path.isdir(os.path.join(candidate, ".git")):
                git_dir = candidate
                break
        # Fallback: first git repo in immediate subdirectories
        if not git_dir:
            try:
                for entry in os.scandir(path):
                    if entry.is_dir(follow_symlinks=False) and not entry.name.startswith("."):
                        if os.path.isdir(os.path.join(entry.path, ".git")):
                            git_dir = entry.path
                            break
            except OSError:
                pass

    # Git checks on primary repo
    if git_dir:
        try:
            result = subprocess.run(
                ["git", "-C", git_dir, "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, timeout=3,
            )
            if result.returncode == 0:
                info["branch"] = result.stdout.strip()
        except Exception:
            pass

        if info["branch"]:
            try:
                r = subprocess.run(
                    ["git", "-C", git_dir, "status", "--porcelain", "-uno", "--no-renames"],
                    capture_output=True, text=True, timeout=3,
                )
                if r.returncode == 0 and r.stdout.strip():
                    info["is_dirty"] = True
            except Exception:
                pass
            try:
                r = subprocess.run(
                    ["git", "-C", git_dir, "rev-list", "--left-right", "--count", "HEAD...@{u}"],
                    capture_output=True, text=True, timeout=3,
                )
                if r.returncode == 0:
                    parts = r.stdout.strip().split()
                    if len(parts) == 2:
                        info["ahead"] = int(parts[0])
                        info["behind"] = int(parts[1])
            except Exception:
                pass

    # Layer count: reuse from previous cache if available, else full walk
    if path in _project_info_cache:
        _, old = _project_info_cache[path]
        if old.get("layer_count", 0) > 0:
            info["layer_count"] = old["layer_count"]
        else:
            full = _detect_project_info(path)
            info["layer_count"] = full.get("layer_count", 0)
    else:
        full = _detect_project_info(path)
        info["layer_count"] = full.get("layer_count", 0)

    _project_info_cache[path] = (now, info)
    return info


_dashboard_summary_cache: Dict[str, Tuple[float, dict]] = {}


def _get_dashboard_summary(path: str) -> dict:
    """Get repo-level summary for a project directory.

    Scans for git repos up to 2 levels deep and gathers aggregate stats:
    repo_count, dirty_count, ahead (local commits), behind (upstream), branch.
    Uses 30s TTL cache.
    """
    now = time.monotonic()
    if path in _dashboard_summary_cache:
        ts, cached = _dashboard_summary_cache[path]
        if now - ts < _CACHE_TTL:
            return cached

    summary: dict = {
        "repo_count": 0,
        "dirty_count": 0,
        "ahead": 0,
        "behind": 0,
        "branch": "",
    }

    if not os.path.isdir(path):
        _dashboard_summary_cache[path] = (now, summary)
        return summary

    # Find all git repos up to 2 levels deep
    git_repos: list = []
    if os.path.isdir(os.path.join(path, ".git")):
        git_repos.append(path)
    try:
        for entry in os.scandir(path):
            if entry.is_dir(follow_symlinks=False) and not entry.name.startswith("."):
                if os.path.isdir(os.path.join(entry.path, ".git")):
                    git_repos.append(entry.path)
                else:
                    # Level 2
                    try:
                        for sub in os.scandir(entry.path):
                            if sub.is_dir(follow_symlinks=False) and not sub.name.startswith("."):
                                if os.path.isdir(os.path.join(sub.path, ".git")):
                                    git_repos.append(sub.path)
                    except OSError:
                        pass
    except OSError:
        pass

    summary["repo_count"] = len(git_repos)

    # Gather per-repo stats
    branches: dict = {}  # branch_name -> count

    for repo in git_repos:
        # Branch
        try:
            r = subprocess.run(
                ["git", "-C", repo, "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True, timeout=3,
            )
            if r.returncode == 0:
                b = r.stdout.strip()
                if b:
                    branches[b] = branches.get(b, 0) + 1
        except Exception:
            pass

        # Dirty check
        try:
            r = subprocess.run(
                ["git", "-C", repo, "status", "--porcelain", "-uno", "--no-renames"],
                capture_output=True, text=True, timeout=3,
            )
            if r.returncode == 0 and r.stdout.strip():
                summary["dirty_count"] += 1
        except Exception:
            pass

        # Ahead/behind upstream
        try:
            r = subprocess.run(
                ["git", "-C", repo, "rev-list", "--left-right", "--count", "HEAD...@{u}"],
                capture_output=True, text=True, timeout=3,
            )
            if r.returncode == 0:
                parts = r.stdout.strip().split()
                if len(parts) == 2:
                    summary["ahead"] += int(parts[0])
                    summary["behind"] += int(parts[1])
        except Exception:
            pass

    # Most common branch across repos
    if branches:
        summary["branch"] = max(branches, key=branches.get)

    _dashboard_summary_cache[path] = (now, summary)
    return summary


def _remove_project_interactive() -> bool:
    """Show picker to select a project to stop tracking."""
    if not fzf_available():
        return False

    projects = load_projects()
    if not projects:
        print("No projects to remove.")
        return False

    menu_lines = []
    for path, info in sorted(projects.items(), key=lambda x: x[1].get("name", x[0]).lower()):
        name = info.get("name", os.path.basename(path))
        exists = "  " if os.path.isdir(path) else Colors.red("! ")
        menu_lines.append(f"{path}\t{exists}{name:<20} {Colors.dim(path)}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~40%",
        "--layout", "reverse",
        "--header", "Select project to stop tracking (Enter=remove, ←/q=cancel)",
        "--prompt", "Remove: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return False

    if result.returncode != 0 or not result.stdout.strip():
        return False

    selected = result.stdout.strip().split("\t")[0]
    if selected in projects:
        return remove_project(selected)

    return False


def fzf_project_picker(include_browse: bool = True, show_exit_hint: bool = False) -> Optional[str]:
    """
    Show fzf menu to select a project.

    Args:
        include_browse: Include option to browse for new project
        show_exit_hint: Show hint about Enter exiting to command menu

    Returns:
        Selected project path, or special commands like:
        - "SELECT:<path>" - Space was pressed, set as active but stay in picker
        - "EXIT:<path>" - Enter was pressed, exit and optionally chain to command menu
        - Other special values for menu options
        - None if cancelled
    """
    if not fzf_available():
        return None

    projects = load_projects()
    current_project = get_current_project()

    if not projects and not include_browse:
        print("No projects registered. Use 'bit projects add' to add one.")
        return None

    # Build menu
    menu_lines = []

    # Compute max path length for column alignment
    max_path_len = max((len(p) for p in projects), default=20)
    path_col = max_path_len + 3  # 3 spaces after longest path

    # Column header and separator (first lines = top of screen with reverse-list)
    header_line = f"HEADER\t  {'Name':<20} {'Path':<{path_col}} Info"
    sep_len = 2 + 20 + 1 + path_col + 4
    separator = f"SEPARATOR_HEADER\t{'─' * sep_len}"
    menu_lines.append(header_line)
    menu_lines.append(separator)

    for path, info in sorted(projects.items(), key=lambda x: x[1].get("name", x[0]).lower()):
        name = info.get("name", os.path.basename(path))
        desc = info.get("description", "")

        # Check if path still exists and if it's current
        is_current = (path == current_project)
        if os.path.isdir(path):
            if is_current:
                status = terminal_color("project_active", "●")
            else:
                status = terminal_color("project_name", "○")
        else:
            status = terminal_color("project_missing", "!")

        # Detect current state
        proj_info = _detect_project_info(path) if os.path.isdir(path) else {}
        layers = proj_info.get("layer_count", 0)
        branch = proj_info.get("branch", "")

        extra = []
        if is_current:
            extra.append("ACTIVE")
        if layers:
            extra.append(f"{layers} layers")
        if branch:
            extra.append(branch)
        extra_str = f"({', '.join(extra)})" if extra else ""

        # Pad path to align info column (Colors.dim adds ANSI codes, so pad the raw path first)
        padded_path = f"{path:<{path_col}}"
        display = f"{status} {name:<20} {Colors.dim(padded_path)}{terminal_color('project_active', extra_str)}"
        if desc:
            display += f" - {desc}"

        menu_lines.append(f"{path}\t{display}")

    # Add browse/add/remove options
    if include_browse:
        menu_lines.append("---\t" + "─" * 50)
        menu_lines.append("ADD_CWD\t+ Add current directory")
        menu_lines.append("ADD_PATH\t+ Enter path manually...")
        menu_lines.append("BROWSE\t+ Browse for directory...")
        if projects:
            menu_lines.append("REMOVE\t- Remove project tracking...")
        if current_project:
            menu_lines.append("CLEAR\t✖ Clear active project")
        # Settings
        browser = get_directory_browser()
        browser_desc = {"auto": "auto (broot>ranger>nnn>fzf)", "nnn": "nnn", "fzf": "fzf", "broot": "broot", "ranger": "ranger"}.get(browser, browser)
        menu_lines.append(f"SETTINGS\t⚙ Settings: browser={browser_desc}")

    menu_input = "\n".join(menu_lines)

    # Build header based on context
    if show_exit_hint:
        header = (f"{terminal_color('project_active', 'Projects')} | Space=activate | Enter=done (→menu) | q=quit"
                  f"\n+=browse | -=remove | c=clear | s=settings | S=shell | i=setup")
    else:
        header = (f"{terminal_color('project_active', 'Projects')} | Space=activate | Enter=done | q=quit"
                  f"\n+=browse | -=remove | c=clear | s=settings | S=shell | i=setup")

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--layout=reverse-list",
        "--height", "~50%",
        "--header", header,
        "--prompt", "Project: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
        "--expect", "space,+,-,c,s,i,S",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return None

    if result.returncode != 0 or not result.stdout.strip():
        return None

    # Parse output - with --expect, first line is key (or empty if Enter), second is selection
    # Don't strip() first as it removes the leading newline when Enter is pressed
    lines = result.stdout.split("\n")
    key = lines[0].strip() if lines else ""
    selected = lines[1].split("\t")[0].strip() if len(lines) > 1 else ""

    # Items that are not projects (actions, separators, header)
    action_items = ("---", "ADD_CWD", "ADD_PATH", "BROWSE", "REMOVE", "CLEAR", "SETTINGS",
                    "HEADER", "SEPARATOR_HEADER")

    # Handle key shortcuts
    if key == "+":
        return "BROWSE"
    elif key == "space" and selected and selected not in action_items:
        # Space = select/activate the project but stay in picker
        return f"SELECT:{selected}"
    elif key == "-" and selected and selected not in action_items:
        # Remove the highlighted project directly
        return f"REMOVE:{selected}"
    elif key == "c":
        return "CLEAR"
    elif key == "s":
        return "SETTINGS"
    elif key == "S" and selected and selected not in action_items:
        return f"SHELL:{selected}"
    elif key == "i" and selected and selected not in action_items:
        return f"INIT:{selected}"

    # No special key (Enter) - return the selected item
    if not selected or selected in ("---", "HEADER", "SEPARATOR_HEADER"):
        return fzf_project_picker(include_browse, show_exit_hint)

    # Enter on a project - signal to exit
    if selected not in action_items:
        return f"EXIT:{selected}"

    return selected


def _dashboard_run_command(project_path: str, argv: list) -> int:
    """Run a bit command in the context of a project directory.

    Changes to the project directory, sets it as active, runs the command
    via cli.main(), then restores the original directory.
    """
    saved_cwd = os.getcwd()
    try:
        os.chdir(project_path)
        set_current_project(project_path)
        from ..cli import main as cli_main
        return cli_main(argv)
    except SystemExit as e:
        return e.code if isinstance(e.code, int) else 1
    finally:
        try:
            os.chdir(saved_cwd)
        except OSError:
            pass


# Action submenus for expanded projects
_DASHBOARD_ACTIONS = [
    ("explore", "Browse commits and repos"),
    ("update", "Update git repos"),
    ("recipes", "Search and browse recipes"),
    ("info", "Build configuration"),
    ("deps", "Layer dependencies"),
    ("fragments", "Configuration fragments"),
    ("config", "Repo and layer settings"),
    ("shell", "Build environment shell"),
]


def fzf_dashboard() -> int:
    """Project dashboard with status summaries and quick actions.

    Shows all configured projects with status columns (branch, layer count,
    sync/dirty status), expandable action submenus per project, and an inline
    manage dialog. Direct action keybindings also available.
    Returns to dashboard after each action completes.
    """
    if not fzf_available():
        return 1

    expanded_projects: set = set()
    last_selection: Optional[str] = None
    show_manage: bool = False
    show_configure: bool = False

    while True:
        projects = load_projects()
        current_project = get_current_project()

        # Build menu lines
        menu_lines = []

        if not projects:
            # No projects yet - just show manage entry
            menu_lines.append("MANAGE\t  ⚙  Manage projects...")
        else:
            # Gather repo summaries for all projects
            summaries = {}
            for path in projects:
                summaries[path] = _get_dashboard_summary(path) if os.path.isdir(path) else {}

            # Compute column widths from raw (pre-ANSI) data
            names_raw = []
            branches_raw = []
            status_raw = []
            for path, info in projects.items():
                names_raw.append(info.get("name", os.path.basename(path)))
                s = summaries.get(path, {})
                branches_raw.append(s.get("branch") or "")
                # Build raw status text for width computation
                rc = s.get("repo_count", 0)
                if rc == 0:
                    status_raw.append("")
                else:
                    sp = [f"{rc} repos"]
                    if s.get("dirty_count", 0):
                        sp.append(f"\u270e{s['dirty_count']}")
                    if s.get("ahead", 0):
                        sp.append(f"\u2191{s['ahead']}")
                    if s.get("behind", 0):
                        sp.append(f"\u2193{s['behind']}")
                    if not s.get("dirty_count") and not s.get("ahead") and not s.get("behind"):
                        sp.append("\u2713")
                    status_raw.append(" ".join(sp))

            max_name = max((len(n) for n in names_raw), default=10)
            name_col = min(max(max_name + 2, 10), 25)

            max_branch = max((len(b) for b in branches_raw), default=8)
            branch_col = min(max(max_branch + 2, 8), 20)

            max_status = max((len(s) for s in status_raw), default=8)
            status_col = min(max(max_status + 2, 8), 30)

            total_width = name_col + branch_col + status_col + 12

            # Banner header (non-selectable, at bottom of input = top of screen with reverse-list)
            banner_text = Colors.bold(Colors.cyan("── bit dashboard ──"))
            menu_lines.append(f"HEADER\t  {banner_text}{'─' * max(total_width - 15, 10)}")

            # Column headers — prefix is 4 visual chars: expand(1) + space(1) + dot(1) + space(1)
            col_header = (
                f"    {'Name':<{name_col}} "
                f"{'Branch':<{branch_col}} "
                f"{'Status':<{status_col}} "
                f"Path"
            )
            menu_lines.append(f"SEP_COL\t{Colors.dim(col_header)}")
            menu_lines.append(f"SEP_LINE\t  {'─' * total_width}")

            # Project entries
            sorted_projects = sorted(projects.items(), key=lambda x: x[1].get("name", x[0]).lower())

            for path, info in sorted_projects:
                name = info.get("name", os.path.basename(path))
                is_current = (path == current_project)
                is_expanded = (path in expanded_projects)
                exists = os.path.isdir(path)

                s = summaries.get(path, {})
                branch = s.get("branch") or ""
                rc = s.get("repo_count", 0)
                dirty = s.get("dirty_count", 0)
                ahead = s.get("ahead", 0)
                behind = s.get("behind", 0)

                # Dot indicator (current/ready/missing)
                if exists:
                    dot = terminal_color("project_active", "●") if is_current else terminal_color("project_name", "○")
                else:
                    dot = terminal_color("project_missing", "!")

                # Expand marker
                expand = "-" if is_expanded else "+"

                # Build status text (raw for padding, colored for display)
                if rc == 0:
                    raw_st = ""
                    colored_st = ""
                else:
                    raw_parts = [f"{rc} repos"]
                    col_parts = [f"{rc} repos"]
                    if dirty:
                        raw_parts.append(f"\u270e{dirty}")
                        col_parts.append(terminal_color("dirty", f"\u270e{dirty}"))
                    if ahead:
                        raw_parts.append(f"\u2191{ahead}")
                        col_parts.append(terminal_color("project_ahead", f"\u2191{ahead}"))
                    if behind:
                        raw_parts.append(f"\u2193{behind}")
                        col_parts.append(terminal_color("project_behind", f"\u2193{behind}"))
                    if not dirty and not ahead and not behind:
                        raw_parts.append("\u2713")
                        col_parts.append(terminal_color("clean", "\u2713"))
                    raw_st = " ".join(raw_parts)
                    colored_st = " ".join(col_parts)

                # Pad raw text BEFORE applying ANSI colors
                padded_name = f"{name:<{name_col}}"
                padded_branch = f"{branch:<{branch_col}}"
                # Status: pad with spaces after colored text
                st_padding = max(status_col - len(raw_st), 0)
                padded_status = colored_st + " " * st_padding

                # Apply colors after padding
                if is_current:
                    colored_name = Colors.bold(terminal_color("project_active", padded_name))
                elif not exists:
                    colored_name = terminal_color("project_missing", padded_name)
                else:
                    colored_name = Colors.bold(terminal_color("project_name", padded_name))

                colored_branch = terminal_color("project_branch", padded_branch) if branch else padded_branch
                colored_path = Colors.dim(path)

                display = f"{expand} {dot} {colored_name} {colored_branch} {padded_status} {colored_path}"
                menu_lines.append(f"{path}\t{display}")

                # Action sub-items if expanded
                if is_expanded:
                    for idx, (cmd, desc) in enumerate(_DASHBOARD_ACTIONS):
                        is_last = (idx == len(_DASHBOARD_ACTIONS) - 1)
                        tree_char = "└─" if is_last else "├─"
                        action_line = f"  {tree_char} {Colors.cyan(f'{cmd:<14}')}{Colors.dim(desc)}"
                        menu_lines.append(f"ACTION:{path}:{cmd}\t{action_line}")

            # Separator and manage entry
            menu_lines.append(f"SEP_BOTTOM\t  {'─' * total_width}")
            menu_lines.append(f"MANAGE\t  {Colors.dim('⚙')}  Manage projects...")
            menu_lines.append(f"CONFIGURE\t  {Colors.dim('⚙')}  Configure...")

        # Inline manage dialog: append items (reverse-list puts end of list near prompt)
        if show_manage:
            manage_items = [
                f"MANAGE_SEP\t  {Colors.dim('─── Manage Projects ───')}",
                f"MANAGE_ADD_CWD\t  {Colors.green('+')} Add current directory",
                f"MANAGE_ADD_PATH\t  {Colors.green('+')} Enter path manually...",
                f"MANAGE_BROWSE\t  {Colors.green('+')} Browse for directory...",
                f"MANAGE_REMOVE\t  {Colors.yellow('-')} Remove project tracking...",
            ]
            if current_project:
                manage_items.append(f"MANAGE_CLEAR\t  {Colors.red('✖')}  Clear active project")
            menu_lines = menu_lines + manage_items

        # Inline configure dialog
        if show_configure:
            from .config import fzf_global_settings
            browser = get_directory_browser()
            browser_desc = {"auto": "auto-detect", "broot": "broot", "ranger": "ranger",
                            "nnn": "nnn", "fzf": "fzf built-in"}.get(browser, browser)
            git_viewer = get_git_viewer()
            viewer_desc = {"auto": "auto-detect", "tig": "tig", "lazygit": "lazygit",
                           "gitk": "gitk"}.get(git_viewer, git_viewer)
            preview_layout = get_preview_layout()
            layout_desc = {"down": "bottom", "right": "side-by-side", "up": "top"}.get(preview_layout, preview_layout)
            recipe_scan = "bitbake-layers" if get_recipe_use_bitbake_layers() else "file scan"

            conf_items = [
                f"CONF_SEP\t  {Colors.dim('─── Configure ───')}",
                f"CONF_COLORS\t  Colors and themes...",
                f"CONF_BROWSER\t  Dir browser          {Colors.dim(browser_desc)}",
                f"CONF_VIEWER\t  Git viewer            {Colors.dim(viewer_desc)}",
                f"CONF_PREVIEW\t  Preview layout        {Colors.dim(layout_desc)}",
                f"CONF_RECIPE\t  Recipe scan           {Colors.dim(recipe_scan)}",
            ]
            menu_lines = menu_lines + conf_items

        menu_input = "\n".join(menu_lines)

        # Header
        header_line1 = "Space=activate | Enter/→=open | \\=fold | ?=commands | +=manage | q=quit"
        header_line2 = "x=explore | u=update | r=recipes | i=info | d=deps | f=fragments | c=config | S=shell"
        header = f"{header_line1}\n{header_line2}"

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--layout=reverse-list",
            "--height", "~80%",
            "--header", header,
            "--with-nth", "2..",
            "--delimiter", "\t",
        ]

        if show_manage:
            fzf_args.extend(["--disabled", "--prompt", "Manage: "])
        elif show_configure:
            fzf_args.extend(["--disabled", "--prompt", "Configure: "])
        else:
            fzf_args.extend(["--prompt", "Dashboard: "])

        # Bindings using get_action_binding pattern (no --expect needed)
        fzf_args.extend(["--bind", "enter:become(echo ENTER {1})"])
        fzf_args.extend(get_action_binding("right", "RIGHT {1}"))
        fzf_args.extend(get_action_binding("left", "LEFT {1}"))
        fzf_args.extend(get_action_binding("\\", "EXPAND {1}"))
        fzf_args.extend(get_action_binding("space", "ACTIVATE {1}"))
        fzf_args.extend(get_action_binding("?", "MENU {1}"))
        fzf_args.extend(get_action_binding("m", "MENU {1}"))
        fzf_args.extend(get_action_binding("+", "MANAGE"))
        fzf_args.extend(get_action_binding("q", "QUIT"))
        # Direct action keybindings on highlighted project
        fzf_args.extend(get_action_binding("x", "EXPLORE {1}"))
        fzf_args.extend(get_action_binding("u", "UPDATE {1}"))
        fzf_args.extend(get_action_binding("r", "RECIPES {1}"))
        fzf_args.extend(get_action_binding("i", "INFO {1}"))
        fzf_args.extend(get_action_binding("d", "DEPS {1}"))
        fzf_args.extend(get_action_binding("f", "FRAGMENTS {1}"))
        fzf_args.extend(get_action_binding("c", "CONFIG {1}"))
        fzf_args.extend(get_action_binding("S", "SHELL {1}"))
        fzf_args.extend(["--bind", "esc:abort"])

        # Cursor restore (not in dialog mode — let fzf default to bottom)
        if last_selection and projects and not show_manage and not show_configure:
            key_list = [line.split("\t")[0] for line in menu_lines]
            if last_selection in key_list:
                pos = key_list.index(last_selection) + 1  # 1-indexed
                fzf_args.extend(get_position_binding(pos))

        fzf_args.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return 1

        if result.returncode != 0 or not result.stdout.strip():
            # Esc/abort: dismiss dialog if open, else quit
            if show_manage:
                show_manage = False
                continue
            if show_configure:
                show_configure = False
                continue
            return 0

        output = result.stdout.strip()

        # --- Parse output ---

        # Non-selectable keys
        non_selectable = {"HEADER", "MANAGE_SEP", "CONF_SEP"}

        if output == "QUIT":
            return 0

        # Manage dialog activation (+ key or Enter on manage entry)
        if output in ("MANAGE", "ENTER MANAGE", "RIGHT MANAGE"):
            show_manage = True
            show_configure = False
            continue

        # Configure dialog activation (Enter/Right on configure entry)
        if output in ("CONFIGURE", "ENTER CONFIGURE", "RIGHT CONFIGURE"):
            show_configure = True
            show_manage = False
            continue

        # Manage dialog item selections
        if output.startswith("ENTER MANAGE_") or output.startswith("RIGHT MANAGE_"):
            selected = output.split(" ", 1)[1] if " " in output else ""
            if selected and selected != "MANAGE_SEP":
                _dashboard_handle_manage(selected, projects)
            show_manage = False
            continue

        # Configure dialog item selections
        if output.startswith("ENTER CONF_") or output.startswith("RIGHT CONF_"):
            selected = output.split(" ", 1)[1] if " " in output else ""
            if selected and selected != "CONF_SEP":
                _dashboard_handle_configure(selected)
            continue

        # LEFT while in dialog mode → dismiss
        if show_manage and output.startswith("LEFT "):
            show_manage = False
            continue
        if show_configure and output.startswith("LEFT "):
            show_configure = False
            continue

        # Activate project
        if output.startswith("ACTIVATE "):
            selected = output[9:].strip()
            if selected.startswith("ACTION:") or selected in non_selectable or selected.startswith("SEP_") or selected == "MANAGE":
                continue
            if selected and os.path.isdir(selected):
                set_current_project(selected)
                name = projects.get(selected, {}).get("name", os.path.basename(selected))
                print(f"{Colors.green('✓')} Activated: {Colors.bold(name)}")
            last_selection = selected
            continue

        # Command menu (? or m)
        if output.startswith("MENU "):
            selected = output[5:].strip()
            target = None
            if selected.startswith("ACTION:"):
                parts = selected.split(":", 2)
                if len(parts) >= 2:
                    target = parts[1]
            elif selected and not selected.startswith("SEP_") and selected not in non_selectable and selected != "MANAGE":
                target = selected
            if not target:
                target = current_project
            if target and os.path.isdir(target):
                last_selection = target
                saved_cwd = os.getcwd()
                try:
                    os.chdir(target)
                    set_current_project(target)
                    from ..cli import fzf_command_menu, main as cli_main
                    cmd = fzf_command_menu()
                    if cmd:
                        cli_main(cmd.split())
                finally:
                    try:
                        os.chdir(saved_cwd)
                    except OSError:
                        pass
            continue

        # Expand/collapse toggle
        if output.startswith("EXPAND "):
            selected = output[7:].strip()
            if selected.startswith("ACTION:") or selected in non_selectable or selected.startswith("SEP_") or selected == "MANAGE":
                continue
            if selected:
                if selected in expanded_projects:
                    expanded_projects.discard(selected)
                else:
                    expanded_projects.add(selected)
                last_selection = selected
            continue

        # Direct action keybindings (x, u, r, i, d, f)
        direct_actions = {
            "EXPLORE ": "explore",
            "UPDATE ": "update",
            "RECIPES ": "recipes",
            "INFO ": "info",
            "DEPS ": "deps",
            "FRAGMENTS ": "fragments",
            "CONFIG ": "config",
        }
        handled = False
        for prefix, cmd in direct_actions.items():
            if output.startswith(prefix):
                selected = output[len(prefix):].strip()
                # Resolve ACTION: entries to their parent project
                if selected.startswith("ACTION:"):
                    parts = selected.split(":", 2)
                    if len(parts) >= 2:
                        selected = parts[1]
                if selected and not selected.startswith("SEP_") and selected not in non_selectable and selected != "MANAGE":
                    if os.path.isdir(selected):
                        _dashboard_run_command(selected, [cmd])
                        last_selection = selected
                handled = True
                break
        if handled:
            continue

        # Shell action (S key — special handling)
        if output.startswith("SHELL "):
            selected = output[6:].strip()
            if selected.startswith("ACTION:"):
                parts = selected.split(":", 2)
                if len(parts) >= 2:
                    selected = parts[1]
            if selected and os.path.isdir(selected):
                last_selection = selected
                os.chdir(selected)
                ns = argparse.Namespace(layers_dir="layers")
                from .setup import run_init_shell
                run_init_shell(ns)
            continue

        # RIGHT arrow: expand project or run action
        if output.startswith("RIGHT "):
            selected = output[6:].strip()
            if selected.startswith("ACTION:"):
                parts = selected.split(":", 2)
                if len(parts) == 3:
                    proj_path, cmd = parts[1], parts[2]
                    last_selection = proj_path
                    if cmd == "shell":
                        if os.path.isdir(proj_path):
                            os.chdir(proj_path)
                            ns = argparse.Namespace(layers_dir="layers")
                            from .setup import run_init_shell
                            run_init_shell(ns)
                    elif os.path.isdir(proj_path):
                        _dashboard_run_command(proj_path, [cmd])
            elif selected and not selected.startswith("SEP_") and selected not in non_selectable and selected != "MANAGE":
                expanded_projects.add(selected)
                last_selection = selected
            continue

        # LEFT arrow: collapse or quit
        if output.startswith("LEFT "):
            selected = output[5:].strip()
            if selected.startswith("ACTION:"):
                parts = selected.split(":", 2)
                if len(parts) >= 2:
                    parent = parts[1]
                    expanded_projects.discard(parent)
                    last_selection = parent
            elif selected in expanded_projects:
                expanded_projects.discard(selected)
                last_selection = selected
            else:
                return 0
            continue

        # ENTER: toggle expand on project, run action on sub-item
        if output.startswith("ENTER "):
            selected = output[6:].strip()
            if selected.startswith("ACTION:"):
                parts = selected.split(":", 2)
                if len(parts) == 3:
                    proj_path, cmd = parts[1], parts[2]
                    last_selection = proj_path
                    if cmd == "shell":
                        if os.path.isdir(proj_path):
                            os.chdir(proj_path)
                            ns = argparse.Namespace(layers_dir="layers")
                            from .setup import run_init_shell
                            run_init_shell(ns)
                    elif os.path.isdir(proj_path):
                        _dashboard_run_command(proj_path, [cmd])
            elif selected == "MANAGE":
                show_manage = True
            elif selected and not selected.startswith("SEP_") and selected not in non_selectable:
                if selected not in expanded_projects:
                    expanded_projects.add(selected)
                else:
                    expanded_projects.discard(selected)
                last_selection = selected
            continue

    return 0


def _dashboard_handle_manage(action: str, projects: dict) -> None:
    """Handle a manage submenu action."""
    # Strip MANAGE_ prefix if present
    if action.startswith("MANAGE_"):
        action = action[7:]

    if action == "ADD_CWD":
        cwd = os.getcwd()
        add_project(cwd)

    elif action == "ADD_PATH":
        try:
            path = input("Enter project path: ").strip()
            if path:
                path = os.path.expanduser(path)
                path = os.path.abspath(path)
                if os.path.isdir(path):
                    add_project(path)
                else:
                    print(f"Not a directory: {path}")
        except (EOFError, KeyboardInterrupt):
            print()

    elif action == "BROWSE":
        path = browse_for_directory()
        if path:
            add_project(path)

    elif action == "REMOVE":
        _remove_project_interactive()

    elif action == "CLEAR":
        set_current_project(None)
        print(f"{Colors.yellow('Cleared')} active project.")

    elif action == "SETTINGS":
        from .config import fzf_global_settings
        fzf_global_settings()


def _dashboard_handle_configure(action: str) -> None:
    """Handle a configure dialog action."""
    if action.startswith("CONF_"):
        action = action[5:]

    if action == "DASH_COLORS":
        _pick_dashboard_colors()
    elif action == "COLORS":
        from .config import fzf_global_settings
        fzf_global_settings()
    elif action == "BROWSER":
        _pick_directory_browser()
    elif action == "VIEWER":
        _pick_git_viewer()
    elif action == "PREVIEW":
        _pick_preview_layout()
    elif action == "RECIPE":
        _pick_recipe_use_bitbake_layers()


def _pick_dashboard_colors() -> None:
    """Pick colors for all terminal display elements."""
    from ..fzf_bindings import get_exit_bindings, get_accept_binding

    # Resolve which color file to write to
    color_mode = get_color_mode()
    if color_mode == "global":
        color_file = _get_global_colors_file()
    elif color_mode == "custom":
        color_file = ".bit.defaults"
    else:
        color_file = None

    while True:
        menu_lines = []
        for elem, (default_color, desc) in TERMINAL_COLOR_ELEMENTS.items():
            current = get_terminal_color(elem)
            is_default = (current == default_color)
            ansi_code = ANSI_COLORS.get(current, "\033[33m")
            sample = f"{ansi_code}\u25a0\u25a0\u25a0\033[0m"
            status = f"{current}" if not is_default else f"{current} (default)"
            menu_lines.append(f"{elem}\t{sample}  {desc:<45} {status}")

        try:
            result = subprocess.run(
                [
                    "fzf",
                    "--no-multi",
                    "--no-sort",
                    "--ansi",
                    "--height", "~15",
                    "--header", "Display Colors (\u2190/q=back)",
                    "--prompt", "Element: ",
                    "--with-nth", "2..",
                    "--delimiter", "\t",
                ] + get_exit_bindings(mode="back") + get_accept_binding() + get_fzf_color_args(),
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        output = result.stdout.strip()
        if output == "BACK":
            return

        elem = output.split("\t")[0] if "\t" in output else output
        if elem in TERMINAL_COLOR_ELEMENTS and color_file:
            _pick_single_color(elem, color_file)
        elif not color_file:
            print("Set color mode to 'global' or 'custom' first (Colors and themes → Color Mode)")


def _pick_single_color(element: str, color_file: str) -> None:
    """Pick a color for a single terminal element."""
    from ..fzf_bindings import get_exit_bindings

    default_color = TERMINAL_COLOR_ELEMENTS[element][0]
    current = get_terminal_color(element)
    desc = TERMINAL_COLOR_ELEMENTS[element][1]

    menu_lines = []
    default_marker = "\u25cf " if current == default_color else "  "
    default_ansi = ANSI_COLORS.get(default_color, "\033[33m")
    menu_lines.append(f"(default)\t{default_marker}{default_ansi}\u25a0\u25a0\u25a0\033[0m (default: {default_color})")

    for name, ansi in sorted(ANSI_COLORS.items()):
        if name == default_color:
            continue
        marker = "\u25cf " if name == current else "  "
        menu_lines.append(f"{name}\t{marker}{ansi}\u25a0\u25a0\u25a0\033[0m {name}")

    try:
        result = subprocess.run(
            [
                "fzf",
                "--no-multi",
                "--no-sort",
                "--ansi",
                "--height", "~20",
                "--header", f"Pick color for: {desc} (\u2190/q=back)",
                "--prompt", "Color: ",
                "--with-nth", "2..",
                "--delimiter", "\t",
            ] + get_exit_bindings(mode="back") + get_fzf_color_args(),
            input="\n".join(menu_lines),
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    output = result.stdout.strip()
    if output == "BACK":
        return

    selected = output.split("\t")[0] if "\t" in output else output
    if selected == "(default)":
        set_terminal_color(element, "(default)", color_file)
    elif selected in ANSI_COLORS:
        set_terminal_color(element, selected, color_file)


def run_dashboard(args) -> int:
    """Entry point for 'bit dashboard' command."""
    return fzf_dashboard()


def get_directory_browser() -> str:
    """Get configured directory browser preference."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__directory_browser__", "auto")
        except (json.JSONDecodeError, OSError):
            pass
    return "auto"


def set_directory_browser(browser: str) -> None:
    """Set directory browser preference (auto, nnn, fzf)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__directory_browser__"] = browser
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_git_viewer() -> str:
    """Get configured git history viewer preference."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__git_viewer__", "auto")
        except (json.JSONDecodeError, OSError):
            pass
    return "auto"


def set_git_viewer(viewer: str) -> None:
    """Set git history viewer preference."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__git_viewer__"] = viewer
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_graph_renderer() -> str:
    """Get configured graph renderer preference for dependency visualization."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__graph_renderer__", "auto")
        except (json.JSONDecodeError, OSError):
            pass
    return "auto"


def set_graph_renderer(renderer: str) -> None:
    """Set graph renderer preference (auto, graph-easy, ascii)."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__graph_renderer__"] = renderer
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_preferred_graph_renderer() -> str:
    """
    Get the preferred graph renderer that's actually available.

    Returns: 'graph-easy', 'ascii', or the configured preference.
    """
    preference = get_graph_renderer()

    if preference == "auto":
        # Prefer graph-easy if available
        if shutil.which("graph-easy"):
            return "graph-easy"
        return "ascii"
    elif preference == "graph-easy":
        if shutil.which("graph-easy"):
            return "graph-easy"
        return "ascii"  # Fall back if not available
    else:
        return preference


def get_preferred_git_viewer() -> Optional[str]:
    """
    Get the preferred git viewer that's actually available.

    Returns the command name (tig, lazygit, gitk) or None if none available.
    """
    preference = get_git_viewer()

    # Define viewer priority
    viewers = ["tig", "lazygit", "gitk"]

    if preference == "auto":
        # Return first available
        for viewer in viewers:
            if shutil.which(viewer):
                return viewer
        return None
    elif preference in viewers and shutil.which(preference):
        return preference
    else:
        # Configured viewer not available, fall back to auto
        for viewer in viewers:
            if shutil.which(viewer):
                return viewer
        return None


def _pick_git_viewer() -> None:
    """Pick git history viewer."""
    if not fzf_available():
        return

    current = get_git_viewer()

    options = [
        ("auto", "Auto-detect (tig > lazygit > gitk)"),
        ("tig", "tig - ncurses git interface"),
        ("lazygit", "lazygit - terminal UI for git"),
        ("gitk", "gitk - graphical git browser"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        available = ""
        if value in ("tig", "lazygit", "gitk") and not shutil.which(value):
            available = Colors.dim(" (not installed)")
        menu_lines.append(f"{value}\t{marker}{desc}{available}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Select git history viewer (Enter=select, ←/q=back)",
        "--prompt", "Viewer: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected in ("auto", "tig", "lazygit", "gitk"):
        set_git_viewer(selected)


def get_preview_layout() -> str:
    """Get configured preview pane layout preference."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__preview_layout__", "down")
        except (json.JSONDecodeError, OSError):
            pass
    return "down"


def set_preview_layout(layout: str) -> None:
    """Set preview pane layout preference."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__preview_layout__"] = layout
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_explore_load_size() -> int:
    """Get configured number of commits to load per page in explore."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return int(data.get("__explore_load_size__", 200))
        except (json.JSONDecodeError, OSError, ValueError):
            pass
    return 200


def set_explore_load_size(size: int) -> None:
    """Set number of commits to load per page in explore."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__explore_load_size__"] = size
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def get_preview_window_arg(size: str = "50%") -> str:
    """Get the fzf --preview-window argument based on configured layout."""
    layout = get_preview_layout()
    if layout == "right":
        return f"right:{size}:wrap"
    elif layout == "up":
        return f"up,{size},wrap"
    else:  # down (default)
        return f"down,{size},wrap"


def get_fzf_preview_args(
    preview_cmd: str,
    size: str = "50%",
    toggle_key: str = "?",
) -> list:
    """
    Get standard fzf arguments for preview pane.

    This provides a consistent preview experience across all commands, including:
    - Preview window with configured layout
    - Resize bindings (F3/F4 cross-platform, alt-left/right on Linux)
    - Color scheme
    - Toggle preview visibility
    - Preview scrolling (multiple key options for compatibility)

    Main list navigation:
    - pgup/pgdn: Page through the list (fzf default, not overridden)
    - up/down: Move one item at a time

    Preview scrolling:
    - alt-up/alt-down: Scroll preview by full pages
    - ctrl-u/ctrl-d: Scroll preview by half-pages (vim style)
    - shift-up/shift-down: Scroll preview by lines
    - alt-k/alt-j: Scroll preview by lines (vim-style alternative)

    Preview resize:
    - F3: Grow preview (cross-platform, Mac-friendly)
    - F4: Shrink preview (cross-platform, Mac-friendly)
    - alt-left: Grow preview (Linux)
    - alt-right: Shrink preview (Linux)

    Args:
        preview_cmd: The preview command to run
        size: Preview window size (default "50%")
        toggle_key: Key to toggle preview visibility (default "?")

    Returns:
        List of fzf arguments to extend your fzf_args with
    """
    preview_window = get_preview_window_arg(size)

    args = [
        "--preview", preview_cmd,
        "--preview-window", preview_window,
        "--bind", f"{toggle_key}:toggle-preview",
        # Preview scrolling - don't override pgup/pgdn so main list paging works
        "--bind", "shift-up:preview-up",
        "--bind", "shift-down:preview-down",
        "--bind", "alt-k:preview-up",
        "--bind", "alt-j:preview-down",
        "--bind", "ctrl-u:preview-half-page-up",
        "--bind", "ctrl-d:preview-half-page-down",
        "--bind", "alt-up:preview-page-up",
        "--bind", "alt-down:preview-page-down",
    ]

    # Add resize bindings and color scheme
    args.extend(get_fzf_preview_resize_bindings())
    args.extend(get_fzf_color_args())

    return args


def _pick_preview_layout() -> None:
    """Pick preview pane layout."""
    if not fzf_available():
        return

    current = get_preview_layout()

    options = [
        ("down", "Bottom - preview below commit list"),
        ("right", "Right - preview beside commit list (side-by-side)"),
        ("up", "Top - preview above commit list"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        menu_lines.append(f"{value}\t{marker}{desc}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Select preview pane layout (Enter=select, ←/q=back)",
        "--prompt", "Layout: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected in ("down", "right", "up"):
        set_preview_layout(selected)


def get_recipe_use_bitbake_layers() -> bool:
    """Get whether to use bitbake-layers for recipe scanning (default: True)."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                value = data.get("__recipe_use_bitbake_layers__", True)
                # Handle string values from config
                if isinstance(value, str):
                    return value.lower() not in ("false", "no", "0")
                return bool(value)
        except (json.JSONDecodeError, OSError):
            pass
    return True


def set_recipe_use_bitbake_layers(value: bool) -> None:
    """Set whether to use bitbake-layers for recipe scanning."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__recipe_use_bitbake_layers__"] = value
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def _pick_recipe_use_bitbake_layers() -> None:
    """Pick whether to use bitbake-layers for recipe scanning."""
    if not fzf_available():
        return

    current = get_recipe_use_bitbake_layers()

    options = [
        (True, "bitbake-layers - Use bitbake-layers show-recipes (more accurate, slower)"),
        (False, "File scan - Scan .bb files directly (faster, no bitbake env needed)"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        key = "true" if value else "false"
        menu_lines.append(f"{key}\t{marker}{desc}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Recipe scan method (Enter=select, ←/q=back)",
        "--prompt", "Method: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected == "true":
        set_recipe_use_bitbake_layers(True)
    elif selected == "false":
        set_recipe_use_bitbake_layers(False)


def _pick_directory_browser() -> None:
    """Show settings menu for directory browser preferences."""
    if not fzf_available():
        return

    while True:
        current_browser = get_directory_browser()
        current_colors = get_nnn_colors()

        # Color descriptions
        color_names = {
            "0": "black", "1": "red", "2": "green", "3": "yellow",
            "4": "blue", "5": "magenta", "6": "cyan", "7": "white"
        }
        color_desc = f"dirs={color_names.get(current_colors[0:1], '?')}" if current_colors else "default"

        menu_lines = [
            f"BROWSER\tBrowser: {current_browser}",
            f"NNN_COLORS\tnnn colors: {color_desc} ({current_colors})",
        ]

        menu_input = "\n".join(menu_lines)

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--height", "~20%",
            "--layout", "reverse",
            "--header", "Projects settings (Enter=edit, ←/q=back)",
            "--prompt", "Setting: ",
            "--with-nth", "2..",
            "--delimiter", "\t",
        ]

        fzf_args.extend(get_exit_bindings(mode="abort"))
        fzf_args.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return

        if result.returncode != 0 or not result.stdout.strip():
            return

        selected = result.stdout.strip().split("\t")[0]

        if selected == "BROWSER":
            _pick_browser_option()
        elif selected == "NNN_COLORS":
            _pick_nnn_colors()


def _pick_browser_option() -> None:
    """Pick directory browser."""
    current = get_directory_browser()

    options = [
        ("auto", "Auto-detect (broot > ranger > nnn > fzf)"),
        ("broot", "broot - fuzzy search, type paths directly"),
        ("ranger", "ranger - vim-like file manager"),
        ("nnn", "nnn - fast, minimal file manager"),
        ("fzf", "fzf built-in browser"),
    ]

    menu_lines = []
    for value, desc in options:
        marker = "● " if value == current else "  "
        available = ""
        if value in ("broot", "ranger", "nnn") and not shutil.which(value):
            available = Colors.dim(" (not installed)")
        menu_lines.append(f"{value}\t{marker}{desc}{available}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~20%",
        "--layout", "reverse",
        "--header", "Select directory browser (Enter=select, ←/q=back)",
        "--prompt", "Browser: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected in ("auto", "fzf", "nnn", "broot", "ranger"):
        set_directory_browser(selected)


def _pick_nnn_colors() -> None:
    """Pick nnn color scheme."""
    # NNN_COLORS format: up to 8 chars, each is a color 0-7
    # We'll focus on the directory color (3rd char) which is usually the issue
    current = get_nnn_colors()

    presets = [
        ("6234", "cyan dirs (default)"),
        ("2234", "green dirs"),
        ("3234", "yellow dirs"),
        ("7234", "white dirs"),
        ("5234", "magenta dirs"),
        ("1234", "red dirs"),
        ("4234", "blue dirs (nnn default)"),
    ]

    menu_lines = []
    for value, desc in presets:
        marker = "● " if value == current else "  "
        # Show color sample
        color_code = {"1": "31", "2": "32", "3": "33", "4": "34", "5": "35", "6": "36", "7": "37"}.get(value[0], "0")
        sample = f"\033[{color_code}m■■■\033[0m"
        menu_lines.append(f"{value}\t{marker}{sample} {desc}")

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--no-sort",
        "--ansi",
        "--height", "~25%",
        "--layout", "reverse",
        "--header", "Select nnn directory color (Enter=select, ←/q=back)",
        "--prompt", "Color: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]

    fzf_args.extend(get_exit_bindings(mode="abort"))
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return

    if result.returncode != 0 or not result.stdout.strip():
        return

    selected = result.stdout.strip().split("\t")[0]
    if selected:
        set_nnn_colors(selected)


def browse_for_directory() -> Optional[str]:
    """
    Browse filesystem to select a directory.

    Uses configured browser preference, or auto-detects.
    Priority: broot > ranger > nnn > fzf
    """
    browser = get_directory_browser()

    if browser == "auto":
        # Auto-detect best available
        if shutil.which("broot"):
            return _browse_with_broot()
        elif shutil.which("ranger"):
            return _browse_with_ranger()
        elif shutil.which("nnn"):
            return _browse_with_nnn()
    elif browser == "broot" and shutil.which("broot"):
        return _browse_with_broot()
    elif browser == "ranger" and shutil.which("ranger"):
        return _browse_with_ranger()
    elif browser == "nnn" and shutil.which("nnn"):
        return _browse_with_nnn()

    # Fall back to fzf
    if fzf_available():
        return _browse_with_fzf_walker()

    return None


def _browse_with_broot() -> Optional[str]:
    """Browse for directory using broot."""
    import tempfile

    start_dir = os.path.expanduser("~")

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.broot') as f:
        out_file = f.name

    try:
        print()
        print(f"{Colors.bold('broot directory browser')}")
        print(f"  Type to fuzzy search     /path : jump to absolute path")
        print(f"  Enter    : enter dir     Alt+Enter : {Colors.cyan('SELECT and quit')}")
        print(f"  Esc/q    : cancel        ?     : help")
        print()
        input("Press Enter to open broot...")

        # --only-folders: show only directories
        # --cmd: initial command (none)
        # We use :print_path verb bound to alt-enter
        result = subprocess.run(
            ["broot", "--only-folders", "--print-path", "-o", out_file, start_dir],
        )

        if os.path.isfile(out_file):
            with open(out_file, "r") as f:
                selected = f.read().strip()
            if selected:
                # broot might output a file, get its directory
                if os.path.isfile(selected):
                    return os.path.dirname(selected)
                elif os.path.isdir(selected):
                    return selected

        return None
    finally:
        try:
            os.unlink(out_file)
        except OSError:
            pass


def _browse_with_ranger() -> Optional[str]:
    """Browse for directory using ranger with fzf integration."""
    import tempfile

    start_dir = os.path.expanduser("~")

    # Create temp directory for our ranger config
    temp_dir = tempfile.mkdtemp(prefix='ranger_bbp_')
    choosedir_file = os.path.join(temp_dir, 'choosedir')
    commands_file = os.path.join(temp_dir, 'commands.py')
    rc_file = os.path.join(temp_dir, 'rc.conf')

    try:
        # Write custom commands.py with fzf_select
        commands_content = '''
import subprocess
import os.path
from ranger.api.commands import Command

class fzf_select(Command):
    """Find a file or directory using fzf and jump to it."""
    def execute(self):
        # Use fd if available, otherwise find
        if subprocess.run(["which", "fd"], capture_output=True).returncode == 0:
            command = "fd --type d --hidden --exclude .git 2>/dev/null | fzf +m"
        else:
            command = "find . -type d -not -path '*/.*' 2>/dev/null | fzf +m"
        fzf = self.fm.execute_command(command, stdout=subprocess.PIPE)
        stdout, stderr = fzf.communicate()
        if fzf.returncode == 0:
            fzf_file = os.path.abspath(stdout.decode('utf-8').strip())
            if os.path.isdir(fzf_file):
                self.fm.cd(fzf_file)
            else:
                self.fm.select_file(fzf_file)

class fzf_cd(Command):
    """fzf to any directory from root."""
    def execute(self):
        start = self.arg(1) or os.path.expanduser("~")
        if subprocess.run(["which", "fd"], capture_output=True).returncode == 0:
            command = f"fd --type d --hidden --exclude .git . {start} 2>/dev/null | fzf +m"
        else:
            command = f"find {start} -type d -not -path '*/.*' 2>/dev/null | fzf +m"
        fzf = self.fm.execute_command(command, stdout=subprocess.PIPE)
        stdout, stderr = fzf.communicate()
        if fzf.returncode == 0:
            fzf_file = os.path.abspath(stdout.decode('utf-8').strip())
            if os.path.isdir(fzf_file):
                self.fm.cd(fzf_file)
'''
        with open(commands_file, 'w') as f:
            f.write(commands_content)

        # Write rc.conf with our mappings
        # Source user's rc.conf first if it exists
        user_rc = os.path.expanduser("~/.config/ranger/rc.conf")
        rc_content = f'''
# Source user config if exists
{"source " + user_rc if os.path.isfile(user_rc) else "# no user rc.conf"}

# bit mappings
map <C-f> fzf_select
map <C-g> fzf_cd ~
map g console cd%space
'''
        with open(rc_file, 'w') as f:
            f.write(rc_content)

        print()
        print(f"{Colors.bold('ranger directory browser')} (with fzf)")
        print(f"  {Colors.bold('Ctrl+f')}    : fzf search from current dir")
        print(f"  {Colors.bold('Ctrl+g')}    : fzf search from home")
        print(f"  {Colors.bold('g')}         : type path directly (tab completes)")
        print(f"  :cd /path : jump to path")
        print(f"  q         : {Colors.cyan('SELECT current dir and quit')}")
        print()
        input("Press Enter to open ranger...")

        env = os.environ.copy()
        env['RANGER_LOAD_DEFAULT_RC'] = 'FALSE'

        result = subprocess.run(
            ["ranger",
             f"--choosedir={choosedir_file}",
             f"--cmd=source {rc_file}",
             f"--cmd=source {commands_file}",
             start_dir],
            env=env,
        )

        if os.path.isfile(choosedir_file):
            with open(choosedir_file, "r") as f:
                selected = f.read().strip()
            if selected and os.path.isdir(selected):
                return selected

        return None
    finally:
        # Cleanup temp files
        try:
            os.unlink(choosedir_file)
        except OSError:
            pass
        try:
            os.unlink(commands_file)
        except OSError:
            pass
        try:
            os.unlink(rc_file)
        except OSError:
            pass
        try:
            os.rmdir(temp_dir)
        except OSError:
            pass


def get_nnn_colors() -> str:
    """Get configured nnn color scheme."""
    config_file = _get_projects_file()
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
                return data.get("__nnn_colors__", "6234")
        except (json.JSONDecodeError, OSError):
            pass
    # Default: cyan dirs (6), green sel (2), yellow ctx (3), blue files (4)
    return "6234"


def set_nnn_colors(colors: str) -> None:
    """Set nnn color scheme."""
    config_file = _get_projects_file()
    data = {}
    if os.path.isfile(config_file):
        try:
            with open(config_file, "r") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    data["__nnn_colors__"] = colors
    try:
        with open(config_file, "w") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def _browse_with_nnn() -> Optional[str]:
    """Browse for directory using nnn file manager."""
    import tempfile

    start_dir = os.path.expanduser("~")

    with tempfile.NamedTemporaryFile(mode='w', delete=False, suffix='.nnn') as f:
        picker_file = f.name

    try:
        env = os.environ.copy()
        # Set colors - default avoids hard-to-read blue for directories
        # Format: 4 chars for contexts (cursor line, selection, dir, file)
        # 1=red, 2=green, 3=yellow, 4=blue, 5=magenta, 6=cyan, 7=white
        env["NNN_COLORS"] = get_nnn_colors()

        print()
        print(f"{Colors.bold('nnn directory browser')} (type-to-nav enabled)")
        print(f"  hjkl/arrows : navigate        {Colors.bold('/')} : filter current dir")
        print(f"  Enter/l     : enter dir       {Colors.bold('~')} : jump to home")
        print(f"  Backspace/h : go up           Just type: jump to path (e.g. /opt)")
        print(f"  {Colors.bold('p')}           : {Colors.cyan('SELECT and quit')}")
        print(f"  q           : cancel          {Colors.bold('?')} : full help")
        print()
        input("Press Enter to open nnn...")

        result = subprocess.run(
            ["nnn", "-n", "-p", picker_file, start_dir],
            env=env,
        )

        # Read selected path (written when user presses 'p')
        if os.path.isfile(picker_file):
            with open(picker_file, "r") as f:
                selected = f.read().strip()
            if selected and os.path.isdir(selected):
                return selected
            elif selected and os.path.isfile(selected):
                # If a file was selected, use its directory
                return os.path.dirname(selected)

        return None
    finally:
        try:
            os.unlink(picker_file)
        except OSError:
            pass


def _browse_with_fzf_walker() -> Optional[str]:
    """Browse for directory using fzf with manual directory navigation."""
    start_dir = os.path.expanduser("~")
    current_dir = start_dir

    while True:
        # List directories in current location
        try:
            entries = sorted(os.listdir(current_dir))
        except OSError:
            entries = []

        dirs = [d for d in entries if os.path.isdir(os.path.join(current_dir, d)) and not d.startswith(".")]

        menu_lines = []
        menu_lines.append(f".\t{Colors.green('● Select this directory')}: {current_dir}")
        if current_dir != "/":
            menu_lines.append(f"..\t{Colors.cyan('↑ Go up to')}: {os.path.dirname(current_dir)}")

        for d in dirs:
            full_path = os.path.join(current_dir, d)
            # Check for indicators this might be a Yocto project
            has_layers = os.path.isdir(os.path.join(full_path, "layers"))
            has_build = os.path.isdir(os.path.join(full_path, "build"))
            has_poky = os.path.isdir(os.path.join(full_path, "poky"))
            has_bblayers = any(
                os.path.isfile(os.path.join(full_path, sub, "conf", "bblayers.conf"))
                for sub in ["", "build"]
            )

            indicator = ""
            if has_layers or has_build or has_poky or has_bblayers:
                indicator = Colors.green(" [yocto?]")

            menu_lines.append(f"{d}\t  {d}/{indicator}")

        menu_input = "\n".join(menu_lines)

        fzf_args = [
            "fzf",
            "--no-multi",
            "--no-sort",
            "--ansi",
            "--height", "~60%",
            "--layout", "reverse",
            "--header", f"Browse: {current_dir}\nEnter=enter dir, Tab=select, ←/q=cancel",
            "--prompt", "Dir: ",
            "--with-nth", "2..",
            "--delimiter", "\t",
            "--expect", "tab",
        ]

        fzf_args.extend(get_exit_bindings(mode="abort"))
        fzf_args.extend(get_fzf_color_args())

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            return None

        if result.returncode != 0 or not result.stdout.strip():
            return None

        # Split BEFORE stripping to preserve empty key line
        lines = result.stdout.split("\n")
        key = lines[0] if lines else ""
        selected = lines[1].split("\t")[0] if len(lines) > 1 else ""

        # Tab means select current highlighted item as the project
        if key == "tab" and selected and selected not in (".", ".."):
            return os.path.join(current_dir, selected)

        if selected == ".":
            return current_dir
        elif selected == "..":
            current_dir = os.path.dirname(current_dir)
        elif selected:
            new_dir = os.path.join(current_dir, selected)
            if os.path.isdir(new_dir):
                current_dir = new_dir


def run_projects(args, from_auto_prompt: bool = False) -> int:
    """
    Main entry point for projects command.

    Args:
        args: Parsed command line arguments
        from_auto_prompt: True if invoked automatically because no project context was found.
                          In this case, after selecting a project with Enter, show command menu.

    Returns:
        0 for success, 1 for error, 2 to signal "chain to command menu"
    """
    subcommand = getattr(args, "projects_command", None)

    if subcommand == "add":
        path = getattr(args, "path", None) or os.getcwd()
        name = getattr(args, "name", None)
        desc = getattr(args, "description", "") or ""
        if add_project(path, name, desc):
            return 0
        return 1

    elif subcommand == "remove":
        path = getattr(args, "path", None)
        if not path:
            # Interactive selection
            selected = fzf_project_picker(include_browse=False)
            if not selected:
                return 1
            path = selected
        if remove_project(path):
            return 0
        return 1

    elif subcommand == "shell":
        # Alias for 'init shell' - change to current project first
        current_project = get_current_project()
        if current_project and os.path.isdir(current_project):
            os.chdir(current_project)
        from .setup import run_init_shell
        return run_init_shell(args)

    elif subcommand == "list":
        projects = load_projects()
        current = get_current_project()

        if not projects:
            print("No projects registered.")
            print("Use 'bit projects add' to add one.")
            return 0

        print(f"\n{Colors.bold('Registered projects:')}\n")
        for path, info in sorted(projects.items(), key=lambda x: x[1].get("name", x[0]).lower()):
            name = info.get("name", os.path.basename(path))
            desc = info.get("description", "")
            exists = os.path.isdir(path)
            is_current = (path == current)

            if is_current:
                status = terminal_color("project_active", "●")
                label = f" {terminal_color('project_active', '(ACTIVE)')}"
            elif exists:
                status = terminal_color("project_name", "○")
                label = ""
            else:
                status = terminal_color("project_missing", "!")
                label = ""

            print(f"  {status} {terminal_color('project_active' if is_current else 'project_name', name)}{label}")
            print(f"    {path}")
            if desc:
                print(f"    {Colors.dim(desc)}")
            if not exists:
                print(f"    {Colors.red('(directory not found)')}")
            print()
        return 0

    else:
        # Default: launch dashboard
        return fzf_dashboard()
