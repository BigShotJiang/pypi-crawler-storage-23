#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Commands package for bit.

This package contains all command implementations:
- update: git pull/rebase layer repos
- explore: interactively explore commits
- export: export patches
- config: view and configure settings
- branch: view and switch branches
- layer-index: search and browse layer index
- setup: setup build environment
- create: create new project from scratch
- repos: list repositories
- projects: manage multiple project directories
"""

# Import all run_* functions for CLI dispatch
from .update import run_update, run_single_repo_update
from .explore import run_explore, run_status
from .export import run_export, run_prepare_export
from .config import run_config, run_config_edit
from .branch import run_branch
from .search import run_search
from .setup import run_init, run_init_shell, run_bootstrap, run_create
from .repos import run_repos
from .projects import run_projects, run_dashboard, get_current_project, set_current_project, find_project_for_directory, resolve_project_by_name
from .recipe import run_recipe
from .fragment import run_fragment
from .deps import run_deps
from .patches import run_patches
from .b4 import run_b4
from .info import run_info, fzf_info_browser

# Also export fzf_available for CLI
from ..core import fzf_available

__all__ = [
    "run_update",
    "run_single_repo_update",
    "run_explore",
    "run_status",
    "run_export",
    "run_prepare_export",
    "run_config",
    "run_config_edit",
    "run_branch",
    "run_search",
    "run_init",
    "run_init_shell",
    "run_bootstrap",
    "run_create",
    "run_repos",
    "run_projects",
    "run_dashboard",
    "get_current_project",
    "set_current_project",
    "resolve_project_by_name",
    "run_recipe",
    "run_fragment",
    "run_deps",
    "run_patches",
    "run_b4",
    "run_info",
    "fzf_info_browser",
    "fzf_available",
]
