#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Setup and create commands - OE/Yocto build environment and project creation."""

import json
import os
import shutil
import subprocess
import sys
import time
from typing import List, Optional

from ..core import Colors, get_fzf_color_args, load_defaults, save_defaults, terminal_color
from .common import add_extra_repo, write_ignore_file

def run_init(args) -> int:
    """Show OE/Yocto build environment setup command."""
    layers_dir = args.layers_dir

    # Find oe-init-build-env script
    init_scripts = []
    if os.path.isdir(layers_dir):
        for root, dirs, files in os.walk(layers_dir):
            # Don't descend too deep
            depth = root[len(layers_dir):].count(os.sep)
            if depth >= 3:
                dirs[:] = []
                continue
            if "oe-init-build-env" in files:
                init_scripts.append(os.path.join(root, "oe-init-build-env"))

    if not init_scripts:
        # Try current directory
        if os.path.isfile("oe-init-build-env"):
            init_scripts.append("./oe-init-build-env")

    if not init_scripts:
        print(f"Could not find oe-init-build-env in {layers_dir}/")
        print("Try running from your OE/Yocto project root, or use --layers-dir")
        return 1

    init_script = init_scripts[0]  # Use first found

    # Find template directories (conf/templates/default pattern)
    templates = []
    if os.path.isdir(layers_dir):
        for root, dirs, files in os.walk(layers_dir):
            depth = root[len(layers_dir):].count(os.sep)
            if depth >= 6:
                dirs[:] = []
                continue
            # Check if this directory contains conf/templates/default
            template_path = os.path.join(root, "conf", "templates", "default")
            if os.path.isdir(template_path):
                templates.append(template_path)

    # Let user pick template if multiple
    selected_template = None
    if templates:
        # Prefer meta-poky template if available
        poky_templates = [t for t in templates if "meta-poky" in t]
        if len(templates) == 1:
            selected_template = templates[0]
        elif poky_templates:
            selected_template = poky_templates[0]
            if len(templates) > 1:
                print(f"Found {len(templates)} templates, using: {selected_template}")
                print(f"Others: {', '.join(t for t in templates if t != selected_template)}")
        else:
            # Use fzf if available and we have a tty
            if shutil.which("fzf") and sys.stdin.isatty():
                try:
                    result = subprocess.run(
                        ["fzf", "--height", "~10", "--header", "Select template (or Esc for none):"] + get_fzf_color_args(),
                        input="\n".join(templates),
                        stdout=subprocess.PIPE,
                        text=True,
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        selected_template = result.stdout.strip()
                except Exception:
                    pass

            if not selected_template:
                # Fall back to numbered selection or first one
                if sys.stdin.isatty():
                    print("Multiple templates found:")
                    for i, t in enumerate(templates, 1):
                        print(f"  {i}. {t}")
                    print("  0. (none)")
                    try:
                        choice = input("Select template number: ").strip()
                        if choice and choice != "0":
                            idx = int(choice) - 1
                            if 0 <= idx < len(templates):
                                selected_template = templates[idx]
                    except (ValueError, EOFError):
                        selected_template = templates[0]
                else:
                    selected_template = templates[0]

    # Build the command
    print()
    print(Colors.bold("Run this command to set up the build environment:"))
    print()

    if selected_template:
        # Make paths relative to current dir
        template_rel = os.path.relpath(selected_template)
        init_rel = os.path.relpath(init_script)
        cmd = f"TEMPLATECONF=$PWD/{template_rel} source ./{init_rel}"
    else:
        init_rel = os.path.relpath(init_script)
        cmd = f"source ./{init_rel}"

    print(f"  {Colors.cyan(cmd)}")
    print()

    # Copy to clipboard if possible
    try:
        if shutil.which("xclip"):
            subprocess.run(["xclip", "-selection", "clipboard"], input=cmd.encode(), check=True)
            print(Colors.dim("(copied to clipboard)"))
        elif shutil.which("xsel"):
            subprocess.run(["xsel", "--clipboard", "--input"], input=cmd.encode(), check=True)
            print(Colors.dim("(copied to clipboard)"))
    except Exception:
        pass

    return 0


def run_init_shell(args) -> int:
    """Start a new shell with OE/Yocto build environment sourced."""
    import tempfile

    layers_dir = args.layers_dir

    # Find oe-init-build-env script (same logic as run_init)
    init_scripts = []
    if os.path.isdir(layers_dir):
        for root, dirs, files in os.walk(layers_dir):
            depth = root[len(layers_dir):].count(os.sep)
            if depth >= 3:
                dirs[:] = []
                continue
            if "oe-init-build-env" in files:
                init_scripts.append(os.path.join(root, "oe-init-build-env"))

    if not init_scripts:
        if os.path.isfile("oe-init-build-env"):
            init_scripts.append("./oe-init-build-env")

    if not init_scripts:
        # No OE infrastructure found — fall back to a plain shell in the
        # project directory so the user still gets a usable environment.
        shell = os.environ.get("SHELL", "/bin/bash")
        cwd = os.getcwd()
        print(f"No oe-init-build-env found in {layers_dir}/")
        print(Colors.bold(f"Starting shell in {cwd}"))
        print()
        result = subprocess.run([shell], cwd=cwd)
        return result.returncode

    init_script = os.path.abspath(init_scripts[0])

    # Find template directories
    templates = []
    if os.path.isdir(layers_dir):
        for root, dirs, files in os.walk(layers_dir):
            depth = root[len(layers_dir):].count(os.sep)
            if depth >= 6:
                dirs[:] = []
                continue
            template_path = os.path.join(root, "conf", "templates", "default")
            if os.path.isdir(template_path):
                templates.append(template_path)

    # Select template (prefer meta-poky)
    selected_template = None
    if templates:
        poky_templates = [t for t in templates if "meta-poky" in t]
        if len(templates) == 1:
            selected_template = templates[0]
        elif poky_templates:
            selected_template = poky_templates[0]
        elif shutil.which("fzf") and sys.stdin.isatty():
            try:
                result = subprocess.run(
                    ["fzf", "--height", "~10", "--header", "Select template (or Esc for none):"] + get_fzf_color_args(),
                    input="\n".join(templates),
                    stdout=subprocess.PIPE,
                    text=True,
                )
                if result.returncode == 0 and result.stdout.strip():
                    selected_template = result.stdout.strip()
            except Exception:
                pass
        if not selected_template and templates:
            selected_template = templates[0]

    if selected_template:
        selected_template = os.path.abspath(selected_template)

    # Determine which shell to use
    shell = os.environ.get("SHELL", "/bin/bash")
    shell_name = os.path.basename(shell)

    # Build the source command
    cwd = os.getcwd()
    if selected_template:
        source_cmd = f'export TEMPLATECONF="{selected_template}" && source "{init_script}"'
    else:
        source_cmd = f'source "{init_script}"'

    print(Colors.bold("Starting shell with OE/Yocto build environment..."))
    print(f"  Init script: {Colors.cyan(init_script)}")
    if selected_template:
        print(f"  Template: {Colors.cyan(selected_template)}")
    print()

    # Create a temporary rcfile that sources the init script
    # This ensures the environment is set up when the shell starts
    if shell_name in ("bash", "sh"):
        # For bash, create an rcfile that sources user's bashrc then the init script
        with tempfile.NamedTemporaryFile(mode="w", suffix=".bashrc", delete=False) as f:
            f.write("# Temporary rcfile for bit init shell\n")
            # Source user's bashrc first for their customizations
            bashrc = os.path.expanduser("~/.bashrc")
            if os.path.isfile(bashrc):
                f.write(f'[ -f "{bashrc}" ] && source "{bashrc}"\n')
            # Change to original directory (sourcing init script changes cwd)
            f.write(f'cd "{cwd}"\n')
            # Source the OE init script
            f.write(f'{source_cmd}\n')
            # Set a custom prompt to indicate we're in a bit shell
            f.write('export PS1="(oe) $PS1"\n')
            rcfile = f.name

        try:
            # Start bash with our custom rcfile
            result = subprocess.run([shell, "--rcfile", rcfile])
            return result.returncode
        finally:
            # Clean up temp file
            try:
                os.unlink(rcfile)
            except Exception:
                pass

    elif shell_name == "zsh":
        # For zsh, use ZDOTDIR to point to a temp directory with our .zshrc
        with tempfile.TemporaryDirectory() as tmpdir:
            zshrc = os.path.join(tmpdir, ".zshrc")
            with open(zshrc, "w") as f:
                f.write("# Temporary zshrc for bit init shell\n")
                # Source user's zshrc first
                user_zshrc = os.path.expanduser("~/.zshrc")
                if os.path.isfile(user_zshrc):
                    f.write(f'[ -f "{user_zshrc}" ] && source "{user_zshrc}"\n')
                f.write(f'cd "{cwd}"\n')
                f.write(f'{source_cmd}\n')
                f.write('export PS1="(oe) $PS1"\n')

            env = os.environ.copy()
            env["ZDOTDIR"] = tmpdir
            result = subprocess.run([shell], env=env)
            return result.returncode

    else:
        # Fallback: use bash -c to source and exec
        print(f"Note: Using bash instead of {shell_name}")
        bash_cmd = f'{source_cmd} && exec bash'
        result = subprocess.run(["bash", "-c", bash_cmd])
        return result.returncode


def run_bootstrap(args) -> int:
    """Clone core Yocto/OE repositories for a new project."""
    branch = args.branch
    layers_dir = args.layers_dir
    do_clone = args.clone

    # Core repos for Yocto/OE setup
    # See: https://docs.yoctoproject.org/dev-manual/poky-manual-setup.html
    repos = [
        {
            "name": "bitbake",
            "url": "https://git.openembedded.org/bitbake",
            "desc": "Build engine",
        },
        {
            "name": "openembedded-core",
            "url": "https://git.openembedded.org/openembedded-core",
            "desc": "Core metadata and recipes",
        },
        {
            "name": "meta-yocto",
            "url": "https://git.yoctoproject.org/meta-yocto",
            "desc": "Yocto Project reference distribution (poky)",
        },
    ]

    # Check if layers_dir already exists and has content
    if os.path.isdir(layers_dir) and os.listdir(layers_dir):
        existing = os.listdir(layers_dir)
        print(f"Warning: {layers_dir}/ already exists with: {', '.join(existing[:5])}")
        if len(existing) > 5:
            print(f"  ... and {len(existing) - 5} more")
        if do_clone:
            try:
                resp = input("Continue anyway? [y/N] ").strip().lower()
                if resp != "y":
                    return 1
            except (EOFError, KeyboardInterrupt):
                return 1

    print()
    print(Colors.bold(f"Core Yocto/OE repositories (branch: {branch}):"))
    print()

    clone_cmds = []
    for repo in repos:
        target = os.path.join(layers_dir, repo["name"])
        cmd = f"git clone -b {branch} {repo['url']} {target}"
        clone_cmds.append(cmd)
        print(f"  {Colors.cyan(repo['name'])}: {repo['desc']}")
        print(f"    {Colors.dim(cmd)}")
        print()

    if do_clone:
        # Create layers dir if needed
        os.makedirs(layers_dir, exist_ok=True)

        print(Colors.bold("Cloning repositories..."))
        print()

        for i, (repo, cmd) in enumerate(zip(repos, clone_cmds)):
            target = os.path.join(layers_dir, repo["name"])
            if os.path.isdir(target):
                print(f"  {Colors.yellow('skip')} {repo['name']} (already exists)")
                continue

            print(f"  {Colors.cyan('clone')} {repo['name']}...")
            result = subprocess.run(
                ["git", "clone", "-b", branch, repo["url"], target],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                print(f"    {Colors.red('failed')}: {result.stderr.strip()}")
                return 1
            print(f"    {Colors.green('done')}")

        # Write .ignore so ripgrep/fd/etc skip build directories
        if write_ignore_file(os.getcwd()):
            print(f"  {Colors.green('wrote')} .ignore (excludes build*/ from searches)")

        # Add bitbake to tracked repos (it's not a layer, so won't be auto-discovered)
        bitbake_path = os.path.abspath(os.path.join(layers_dir, "bitbake"))
        if os.path.isdir(bitbake_path):
            defaults_file = args.defaults_file
            defaults = load_defaults(defaults_file)
            add_extra_repo(defaults_file, defaults, bitbake_path)

        print()
        print(Colors.green("Bootstrap complete!"))
        print()
        print("Next steps:")
        print(f"  1. Run: {Colors.cyan(f'bit setup --layers-dir {layers_dir}')}")
        print("  2. Source the environment setup command shown")
        print("  3. Run: bitbake core-image-minimal")
    else:
        print(Colors.dim("Add --execute (or --clone) to execute, or copy/paste the commands manually."))

    return 0


def run_create(args) -> int:
    """Create a new Yocto/OE project: clone core repos and register."""
    project_dir = getattr(args, "project_dir", None)
    if project_dir:
        project_dir = os.path.abspath(project_dir)
        if not os.path.isdir(project_dir):
            os.makedirs(project_dir, exist_ok=True)
            print(f"Created project directory: {terminal_color('project_active', project_dir)}")
        os.chdir(project_dir)

    result = run_bootstrap(args)
    if result != 0:
        return result

    # Auto-register as tracked project if cloning was executed
    if getattr(args, "clone", False):
        register_dir = project_dir or os.getcwd()
        register_dir = os.path.abspath(register_dir)
        from .projects import add_project
        name = getattr(args, "name", None) or os.path.basename(register_dir)
        add_project(register_dir, name)

    return 0


def _get_layer_index_cache_path() -> str:
    """Get path to layer index cache file."""
    cache_dir = os.path.expanduser("~/.cache/bit")
    os.makedirs(cache_dir, exist_ok=True)
    return os.path.join(cache_dir, "layer-index.json")


def _fetch_layer_index(force: bool = False) -> Optional[list]:
    """Fetch layer index from API or cache. Returns None on error."""
    import urllib.request
    import urllib.error

    cache_path = _get_layer_index_cache_path()
    cache_max_age = 2 * 60 * 60  # 2 hours in seconds

    # Check cache
    if not force and os.path.isfile(cache_path):
        try:
            cache_age = time.time() - os.path.getmtime(cache_path)
            if cache_age < cache_max_age:
                with open(cache_path, "r") as f:
                    cache_data = json.load(f)
                    if cache_data.get("data"):
                        return cache_data["data"]
        except (json.JSONDecodeError, OSError, KeyError):
            pass  # Cache invalid, fetch fresh

    # Fetch from API
    api_url = "https://layers.openembedded.org/layerindex/api/layers/?format=json"
    try:
        print(Colors.dim("Fetching layer index..."), end=" ", flush=True)
        with urllib.request.urlopen(api_url, timeout=30) as resp:
            data = json.loads(resp.read().decode())
        print(Colors.dim("done"))

        # Save to cache
        try:
            with open(cache_path, "w") as f:
                json.dump({"timestamp": time.time(), "data": data}, f)
        except OSError:
            pass  # Cache write failed, continue anyway

        return data
    except urllib.error.URLError as e:
        print(Colors.dim("failed"))
        # Try to use stale cache
        if os.path.isfile(cache_path):
            try:
                with open(cache_path, "r") as f:
                    cache_data = json.load(f)
                    if cache_data.get("data"):
                        print(Colors.yellow(f"Using cached data (network error: {e})"))
                        return cache_data["data"]
            except (json.JSONDecodeError, OSError, KeyError):
                pass
        print(f"Error fetching layer index: {e}")
        return None
    except json.JSONDecodeError as e:
        print(Colors.dim("failed"))
        print(f"Error parsing response: {e}")
        return None


def _fetch_layer_dependencies(layer_name: str, branch: str) -> List[dict]:
    """Fetch dependencies for a layer from the API. Returns list of {name, required} dicts."""
    import urllib.request
    import urllib.error

    # First get the layerbranch ID for this layer+branch
    try:
        # Get all layerbranches for this layer
        url = f"https://layers.openembedded.org/layerindex/api/layerBranches/?filter=layer__name:{layer_name}"
        with urllib.request.urlopen(url, timeout=10) as resp:
            layerbranches = json.loads(resp.read().decode())
        if not layerbranches:
            return []

        # Get branch ID mapping
        branch_url = "https://layers.openembedded.org/layerindex/api/branches/"
        with urllib.request.urlopen(branch_url, timeout=10) as resp:
            branches = json.loads(resp.read().decode())
        branch_id = next((b["id"] for b in branches if b["name"] == branch), None)
        if not branch_id:
            return []

        # Find layerbranch for the target branch
        layerbranch_id = next((lb["id"] for lb in layerbranches if lb.get("branch") == branch_id), None)
        if not layerbranch_id:
            return []
    except (urllib.error.URLError, json.JSONDecodeError, KeyError, IndexError, StopIteration):
        return []

    # Get dependencies for this layerbranch
    try:
        url = f"https://layers.openembedded.org/layerindex/api/layerDependencies/?filter=layerbranch:{layerbranch_id}"
        with urllib.request.urlopen(url, timeout=10) as resp:
            deps = json.loads(resp.read().decode())
    except (urllib.error.URLError, json.JSONDecodeError):
        return []

    if not deps:
        return []

    # Get layer info for each dependency ID
    dep_ids = [d.get("dependency") for d in deps if d.get("dependency")]
    if not dep_ids:
        return []

    # Build lookup from cached layer data
    layer_data = _fetch_layer_index(force=False)
    if not layer_data:
        return []

    # Map layer IDs to names (layer ID is in layer.id)
    id_to_name = {}
    for entry in layer_data:
        layer_info = entry.get("layer", {})
        lid = layer_info.get("id")
        name = layer_info.get("name")
        if lid and name:
            id_to_name[lid] = name

    # Resolve dependency names
    result = []
    for d in deps:
        dep_id = d.get("dependency")
        required = d.get("required", True)
        name = id_to_name.get(dep_id)
        if name:
            # Skip openembedded-core (always present)
            if name == "openembedded-core":
                continue
            result.append({"name": name, "required": required})

    # Dedupe and sort (required first)
    seen = set()
    unique = []
    for d in result:
        if d["name"] not in seen:
            seen.add(d["name"])
            unique.append(d)
    return sorted(unique, key=lambda x: (not x["required"], x["name"]))


def _fetch_layer_deps_bulk(branch: str, layer_data: list) -> dict:
    """Fetch all layer dependencies for a branch. Returns {layer_name: [{name, required}]}.

    Uses 1 API call (cached) + already-fetched layer_data for ID mapping.
    """
    import urllib.request
    import urllib.error

    cache_dir = os.path.expanduser("~/.cache/bit")
    os.makedirs(cache_dir, exist_ok=True)
    cache_path = os.path.join(cache_dir, "layer-deps.json")
    cache_max_age = 2 * 60 * 60  # 2 hours

    # Try loading cached raw API response
    raw_deps = None
    if os.path.isfile(cache_path):
        try:
            cache_age = time.time() - os.path.getmtime(cache_path)
            if cache_age < cache_max_age:
                with open(cache_path, "r") as f:
                    raw_deps = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass

    # Fetch from API if not cached
    if raw_deps is None:
        try:
            url = "https://layers.openembedded.org/layerindex/api/layerDependencies/?format=json"
            with urllib.request.urlopen(url, timeout=30) as resp:
                raw_deps = json.loads(resp.read().decode())
            # Cache the raw response
            try:
                with open(cache_path, "w") as f:
                    json.dump(raw_deps, f)
            except OSError:
                pass
        except (urllib.error.URLError, json.JSONDecodeError):
            return {}

    if not raw_deps:
        return {}

    # Build ID maps from layer_data (already fetched, filtered to target branch)
    # Find the branch ID for the target branch name
    branch_id = None
    layerbranch_to_layer_name = {}  # layerbranch_id -> layer_name
    layer_id_to_name = {}  # layer_id -> layer_name

    for entry in layer_data:
        entry_branch = entry.get("branch", {})
        layer_info = entry.get("layer", {})
        lid = layer_info.get("id")
        name = layer_info.get("name")
        if lid and name:
            layer_id_to_name[lid] = name
        if entry_branch.get("name") == branch:
            if branch_id is None:
                branch_id = entry_branch.get("id")
            lb_id = entry.get("id")  # layerbranch ID
            if lb_id and name:
                layerbranch_to_layer_name[lb_id] = name

    if not branch_id or not layerbranch_to_layer_name:
        return {}

    # Build deps map: for each dependency record whose layerbranch is in our branch
    deps_map = {}  # layer_name -> list of {name, required}
    for dep in raw_deps:
        lb_id = dep.get("layerbranch")
        dep_layer_id = dep.get("dependency")
        required = dep.get("required", True)

        src_name = layerbranch_to_layer_name.get(lb_id)
        if not src_name:
            continue

        dep_name = layer_id_to_name.get(dep_layer_id)
        if not dep_name or dep_name == "openembedded-core":
            continue

        deps_map.setdefault(src_name, []).append({"name": dep_name, "required": required})

    # Dedupe and sort each layer's deps (required first, then alphabetical)
    for layer_name, deps_list in deps_map.items():
        seen = set()
        unique = []
        for d in deps_list:
            if d["name"] not in seen:
                seen.add(d["name"])
                unique.append(d)
        deps_map[layer_name] = sorted(unique, key=lambda x: (not x["required"], x["name"]))

    return deps_map


