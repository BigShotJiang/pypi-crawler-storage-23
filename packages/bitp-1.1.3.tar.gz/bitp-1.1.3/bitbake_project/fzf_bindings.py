#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Centralized fzf keybinding definitions for consistent UI across all menus.

This module provides standardized keybinding functions to ensure consistency
across all fzf-based menus in the application. Each function returns a list
of fzf --bind arguments.

Usage:
    from bitbake_project.fzf_bindings import (
        get_exit_bindings,
        get_preview_scroll_bindings,
        get_preview_toggle_binding,
    )

    fzf_cmd = [
        "fzf",
        ...
    ] + get_exit_bindings() + get_preview_scroll_bindings()

Keybinding Philosophy:
    - Exit: q, Esc, Left arrow all exit/go back
    - Preview scroll: PgUp/PgDn for full page, Ctrl-U/Ctrl-D for half page
    - Preview toggle: ? to show/hide preview
    - Accept: Enter or Right arrow to select/drill down
    - Multi-select: Tab to toggle, Space for range selection
"""

import subprocess
from typing import List, Optional, Tuple


# =============================================================================
# KEYBINDING CONSTANTS
# =============================================================================
# These define the standard keys used across all menus. Change here to
# update everywhere.

# Exit/Navigation keys
KEY_QUIT = "q"
KEY_ESCAPE = "esc"
KEY_BACK = "left"
KEY_ACCEPT = "right"

# Preview navigation
KEY_PREVIEW_TOGGLE = "?"
KEY_PREVIEW_PAGE_UP = "pgup"
KEY_PREVIEW_PAGE_DOWN = "pgdn"
KEY_PREVIEW_HALF_UP = "ctrl-u"
KEY_PREVIEW_HALF_DOWN = "ctrl-d"
KEY_PREVIEW_LINE_UP = "shift-up"
KEY_PREVIEW_LINE_DOWN = "shift-down"
KEY_PREVIEW_LINE_UP_ALT = "alt-k"
KEY_PREVIEW_LINE_DOWN_ALT = "alt-j"
KEY_PREVIEW_PAGE_UP_ALT = "alt-up"
KEY_PREVIEW_PAGE_DOWN_ALT = "alt-down"

# Preview resize (F-keys work cross-platform)
KEY_PREVIEW_GROW = "f3"
KEY_PREVIEW_SHRINK = "f4"
KEY_PREVIEW_GROW_ALT = "alt-left"
KEY_PREVIEW_SHRINK_ALT = "alt-right"

# Selection
KEY_TOGGLE = "tab"
KEY_TOGGLE_ALL = "ctrl-a"

# Common actions
KEY_REFRESH = "r"
KEY_HELP = "?"


# =============================================================================
# EXIT / NAVIGATION BINDINGS
# =============================================================================

def get_exit_bindings(
    mode: str = "back",
    back_value: str = "BACK",
    quit_value: str = "QUIT",
) -> List[str]:
    """
    Get standard exit/back keybindings.

    Args:
        mode: Exit behavior mode
            - "abort": Immediate exit with non-zero return code
            - "back": Return custom value (for menu loops)
            - "quit": Return quit signal (for nested menus)
        back_value: Value to return for BACK action (mode="back")
        quit_value: Value to return for QUIT action (mode="quit")

    Returns:
        List of fzf --bind arguments

    Standard keys: q, Esc, Left arrow
    """
    if mode == "abort":
        return [
            "--bind", f"{KEY_ESCAPE}:abort",
            "--bind", f"{KEY_QUIT}:abort",
            "--bind", f"{KEY_BACK}:abort",
        ]
    elif mode == "back":
        return [
            "--bind", f"{KEY_ESCAPE}:become(echo {back_value})",
            "--bind", f"{KEY_QUIT}:become(echo {back_value})",
            "--bind", f"{KEY_BACK}:become(echo {back_value})",
        ]
    elif mode == "quit":
        return [
            "--bind", f"{KEY_ESCAPE}:become(echo {quit_value})",
            "--bind", f"{KEY_QUIT}:become(echo {quit_value})",
            "--bind", f"{KEY_BACK}:become(echo {back_value})",
        ]
    else:
        raise ValueError(f"Unknown exit mode: {mode}")


def get_accept_binding(action: str = "accept") -> List[str]:
    """
    Get accept/enter keybinding.

    Args:
        action: fzf action to perform
            - "accept": Standard accept (return selection)
            - Custom become() action string

    Returns:
        List of fzf --bind arguments

    Standard key: Right arrow (Enter is implicit in fzf)
    """
    if action == "accept":
        return ["--bind", f"{KEY_ACCEPT}:accept"]
    else:
        return ["--bind", f"{KEY_ACCEPT}:{action}"]


# =============================================================================
# PREVIEW BINDINGS
# =============================================================================

def get_preview_toggle_binding() -> List[str]:
    """
    Get preview pane toggle keybinding.

    Returns:
        List of fzf --bind arguments

    Standard key: ? (question mark)
    """
    return ["--bind", f"{KEY_PREVIEW_TOGGLE}:toggle-preview"]


def get_preview_scroll_bindings(include_half_page: bool = True) -> List[str]:
    """
    Get preview pane scroll keybindings.

    Args:
        include_half_page: Also include Ctrl-U/Ctrl-D for half-page scroll

    Returns:
        List of fzf --bind arguments

    Standard keys:
        - PgUp/PgDn: Full page scroll
        - Alt-Up/Alt-Down: Full page scroll (alternative, works when PgUp/PgDn page the list)
        - Ctrl-U/Ctrl-D: Half page scroll (optional)
    """
    # pgup/pgdn left unbound so they scroll the main list (fzf default)
    bindings = [
        "--bind", f"{KEY_PREVIEW_PAGE_UP_ALT}:preview-page-up",
        "--bind", f"{KEY_PREVIEW_PAGE_DOWN_ALT}:preview-page-down",
    ]
    if include_half_page:
        bindings.extend([
            "--bind", f"{KEY_PREVIEW_HALF_UP}:preview-half-page-up",
            "--bind", f"{KEY_PREVIEW_HALF_DOWN}:preview-half-page-down",
        ])
    return bindings


def get_preview_line_scroll_bindings() -> List[str]:
    """
    Get single-line preview scroll keybindings.

    Returns:
        List of fzf --bind arguments

    Standard keys: Shift-Up/Shift-Down, Alt-K/Alt-J (vim-style alternative)
    """
    return [
        "--bind", f"{KEY_PREVIEW_LINE_UP}:preview-up",
        "--bind", f"{KEY_PREVIEW_LINE_DOWN}:preview-down",
        "--bind", f"{KEY_PREVIEW_LINE_UP_ALT}:preview-up",
        "--bind", f"{KEY_PREVIEW_LINE_DOWN_ALT}:preview-down",
    ]


def get_preview_all_bindings(include_toggle: bool = True) -> List[str]:
    """
    Get all standard preview keybindings combined.

    Args:
        include_toggle: Include ? to toggle preview visibility

    Returns:
        List of fzf --bind arguments

    Includes: toggle, page scroll, half-page scroll
    """
    bindings = []
    if include_toggle:
        bindings.extend(get_preview_toggle_binding())
    bindings.extend(get_preview_scroll_bindings(include_half_page=True))
    return bindings


# =============================================================================
# SELECTION BINDINGS
# =============================================================================

def get_toggle_binding() -> List[str]:
    """
    Get single item toggle keybinding for multi-select mode.

    Returns:
        List of fzf --bind arguments

    Standard key: Tab
    """
    return ["--bind", f"{KEY_TOGGLE}:toggle"]


def get_toggle_all_binding() -> List[str]:
    """
    Get toggle-all keybinding for multi-select mode.

    Returns:
        List of fzf --bind arguments

    Standard key: Ctrl-A
    """
    return ["--bind", f"{KEY_TOGGLE_ALL}:toggle-all"]


def get_multi_select_bindings() -> List[str]:
    """
    Get all multi-select keybindings.

    Returns:
        List of fzf --bind arguments

    Standard keys: Tab (toggle), Ctrl-A (toggle all)
    """
    return get_toggle_binding() + get_toggle_all_binding()


# =============================================================================
# ACTION BINDINGS
# =============================================================================

def get_refresh_binding(action_value: str = "REFRESH") -> List[str]:
    """
    Get refresh/reload keybinding.

    Args:
        action_value: Value to return when refresh is triggered

    Returns:
        List of fzf --bind arguments

    Standard key: r
    """
    return ["--bind", f"{KEY_REFRESH}:become(echo {action_value})"]


def get_action_binding(key: str, action_value: str) -> List[str]:
    """
    Get a custom action keybinding that returns a value.

    Args:
        key: The key to bind (e.g., "d", "ctrl-e")
        action_value: Value to return when key is pressed

    Returns:
        List of fzf --bind arguments

    Example:
        get_action_binding("d", "DELETE") -> ["--bind", "d:become(echo DELETE)"]
    """
    return ["--bind", f"{key}:become(echo {action_value})"]


def get_action_bindings(bindings: dict) -> List[str]:
    """
    Get multiple custom action keybindings.

    Args:
        bindings: Dict mapping keys to action values
            e.g., {"d": "DELETE", "e": "EDIT", "c": "COPY"}

    Returns:
        List of fzf --bind arguments
    """
    result = []
    for key, value in bindings.items():
        result.extend(get_action_binding(key, value))
    return result


# =============================================================================
# CURSOR POSITIONING
# =============================================================================

def get_position_binding(position: int) -> List[str]:
    """
    Get binding to position cursor at startup.

    Args:
        position: 1-indexed position to place cursor

    Returns:
        List of fzf --bind arguments

    Note: Uses load:pos() which runs after menu is populated
    """
    return ["--bind", f"load:pos({position})"]


def get_sync_position_binding(position: int) -> List[str]:
    """
    Get binding to position cursor with sync (waits for input).

    Args:
        position: 1-indexed position to place cursor

    Returns:
        List of fzf --bind arguments including --sync

    Note: Uses --sync to ensure input is fully loaded before positioning
    """
    return ["--sync", "--bind", f"load:pos({position})"]


# =============================================================================
# COMPOSITE BINDING SETS
# =============================================================================

def get_standard_menu_bindings(
    exit_mode: str = "back",
    include_preview: bool = True,
    include_accept: bool = True,
) -> List[str]:
    """
    Get standard keybindings for a typical menu.

    Args:
        exit_mode: Exit behavior ("abort", "back", "quit")
        include_preview: Include preview scroll bindings
        include_accept: Include right-arrow accept binding

    Returns:
        List of fzf --bind arguments

    Includes:
        - Exit bindings (q, Esc, Left)
        - Accept binding (Right) if include_accept
        - Preview scroll (PgUp/PgDn, Ctrl-U/Ctrl-D) if include_preview
    """
    bindings = get_exit_bindings(mode=exit_mode)
    if include_accept:
        bindings.extend(get_accept_binding())
    if include_preview:
        bindings.extend(get_preview_scroll_bindings())
    return bindings


def get_browser_bindings(
    exit_mode: str = "back",
    include_refresh: bool = True,
    include_preview_toggle: bool = True,
) -> List[str]:
    """
    Get standard keybindings for a browser/explorer menu.

    Args:
        exit_mode: Exit behavior ("abort", "back", "quit")
        include_refresh: Include 'r' for refresh
        include_preview_toggle: Include '?' for preview toggle

    Returns:
        List of fzf --bind arguments

    Includes:
        - Exit bindings (q, Esc, Left)
        - Accept binding (Right)
        - Preview scroll (PgUp/PgDn, Ctrl-U/Ctrl-D)
        - Preview toggle (?) if include_preview_toggle
        - Refresh (r) if include_refresh
    """
    bindings = get_standard_menu_bindings(exit_mode=exit_mode)
    if include_preview_toggle:
        bindings.extend(get_preview_toggle_binding())
    if include_refresh:
        bindings.extend(get_refresh_binding())
    return bindings


def get_picker_bindings(exit_mode: str = "abort") -> List[str]:
    """
    Get minimal keybindings for a simple picker/selector.

    Args:
        exit_mode: Exit behavior (typically "abort" for pickers)

    Returns:
        List of fzf --bind arguments

    Includes:
        - Exit bindings (q, Esc, Left)
        - Accept binding (Right)

    Note: No preview bindings - use for simple selection menus
    """
    return get_exit_bindings(mode=exit_mode) + get_accept_binding()


# =============================================================================
# HEADER TEXT HELPERS
# =============================================================================

def format_keybinding_help(*items: Tuple[str, str]) -> str:
    """
    Format keybinding help text for fzf header.

    Args:
        items: Tuples of (key, description)
            e.g., ("Enter", "select"), ("q", "quit")

    Returns:
        Formatted string like "Enter=select | q=quit | Esc=back"

    Example:
        format_keybinding_help(
            ("Enter", "select"),
            ("d", "diff"),
            ("q", "quit"),
        )
        -> "Enter=select | d=diff | q=quit"
    """
    return " | ".join(f"{key}={desc}" for key, desc in items)


def get_standard_header_suffix() -> str:
    """
    Get standard header suffix with common navigation keybindings.

    Returns:
        String describing exit and preview scroll bindings
    """
    return "q/Esc=back | alt-up/dn=page | ctrl-u/d=half-page | alt-j/k=line"


def get_preview_header_suffix() -> str:
    """
    Get header suffix for preview-related keys (scroll + resize + toggle).

    Use this on a second header line for commands with preview panes.

    Returns:
        String describing all preview keybindings
    """
    return "?=preview | alt-up/dn=page | ctrl-u/d=half-page | alt-j/k=line | F3/F4,alt-arrows=resize"


# Cached fzf version tuple
_fzf_version_cache: Optional[Tuple[int, ...]] = None


def get_fzf_version() -> Tuple[int, ...]:
    """Return the installed fzf version as a tuple, e.g. (0, 44, 1).

    Result is cached after the first call. Returns (0, 0, 0) if fzf
    is not found or the version string cannot be parsed.
    """
    global _fzf_version_cache
    if _fzf_version_cache is not None:
        return _fzf_version_cache
    try:
        out = subprocess.check_output(
            ["fzf", "--version"], text=True, stderr=subprocess.DEVNULL
        ).strip()
        # Output looks like "0.44.1 (debian)" — take first token
        ver_str = out.split()[0] if out else ""
        _fzf_version_cache = tuple(int(p) for p in ver_str.split("."))
    except (subprocess.CalledProcessError, FileNotFoundError, ValueError):
        _fzf_version_cache = (0, 0, 0)
    return _fzf_version_cache
