from pathlib import Path
from random import choice

from kaptive.database import load_database
from kaptive.assembly import parse_result
from kaptive_plot import KaptivePlotter


def main():
    db = load_database('kpsc_k')

    json = Path('test.json')
    assert json.exists()

    with open('test.json') as f:
        result = parse_result(choice(f.readlines()), db)

    plotter = KaptivePlotter(db)
    png = Path('../docs/assets/test.png')
    html = Path('../docs/assets/test.html')

    with plotter.plot(result) as (fig, ax):
        fig.savefig(png)
    assert png.exists()

    plotter.plotly(result).write_html(html)
    assert html.exists()

if __name__ == '__main__':
    main()