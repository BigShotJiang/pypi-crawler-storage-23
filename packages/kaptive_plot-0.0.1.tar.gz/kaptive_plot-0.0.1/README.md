<img src="docs/assets/logo.png" alt="Kaptive" width="600"></p>

[![Release](https://img.shields.io/github/v/release/tomdstanton/kaptive-plot)](https://img.shields.io/github/v/release/tomdstanton/kaptive-plot)
[![Build status](https://img.shields.io/github/actions/workflow/status/tomdstanton/kaptive-plot/main.yml?branch=main)](https://github.com/tomdstanton/kaptive-plot/actions/workflows/main.yml?query=branch%3Amain)
[![codecov](https://codecov.io/gh/tomdstanton/kaptive-plot/branch/main/graph/badge.svg)](https://codecov.io/gh/tomdstanton/kaptive-plot)
[![Commit activity](https://img.shields.io/github/commit-activity/m/tomdstanton/kaptive-plot)](https://img.shields.io/github/commit-activity/m/tomdstanton/kaptive-plot)
[![License](https://img.shields.io/github/license/tomdstanton/kaptive-plot)](https://img.shields.io/github/license/tomdstanton/kaptive-plot)

# Kaptive Plot

- **Github repository**: <https://github.com/tomdstanton/kaptive-plot/>
- **Documentation** <https://tomdstanton.github.io/kaptive-plot/>

## Installation

From PyPI:

<!-- termynal -->
```bash
$ pip install kaptive-plot
---> 100%
Installed!
```

From source:

<!-- termynal -->
```bash
$ pip install git+https://github.com/tomdstanton/kaptive-plot.git
---> 100%
Installed!
```

## Usage

<!-- termynal -->
```bash
$ kaptive-plot -h

usage: kaptive-plot <db> <json>

Plotting library for Kaptive, the tool for in silico serotyping

Inputs:

  db              Database path or keyword used to generate results
  json            Kaptive results JSON file or "-" for stdin

Outputs:

  -o, --out       Output path (default: .)
  -f , --format   Output format: png, svg or html (default: png)
  -p, --plotly    Use plotly instead of matplotlib (default: False)

Other options:

  -v, --version   show program's version number and exit
  -h, --help      Show this help message and exit

For more help, visit: https://tomdstanton.github.io/kaptive-plot
```

## Examples

### Static plot

<!-- termynal -->
```bash
kaptive-plot kpsc_k tests/test.json
```

<img src="docs/assets/test.png" alt="test_plot" width="600"></p>

### Interactive plot

<!-- termynal -->
```bash
kaptive-plot kpsc_k tests/test.json --plotly --format html
```

``` plotly
{"file_path": "docs/assets/test.json"}
```
