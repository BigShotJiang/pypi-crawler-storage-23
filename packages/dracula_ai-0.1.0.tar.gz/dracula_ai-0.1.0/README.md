# Dracula 🧛

A simple Python library for Google Gemini with conversation memory.

## Installation

pip install dracula-ai

## Usage

from dracula import Dracula

ai = Dracula(api_key="your-api-key")

response = ai.chat("Hello, who are you?")
print(response)