import google.generativeai as genai
from .memory import Memory
from .exceptions import InvalidAPIKeyException, ChatException


class Dracula:
    def __init__(
        self, api_key: str, model: str = "gemini-2.0-flash", max_messages: int = 10
    ):
        if not api_key:
            raise InvalidAPIKeyException("API Key cannot be empty.")

        try:
            genai.configure(api_key=api_key)
            self.model = genai.GenerativeModel(model)

        except Exception:
            raise InvalidAPIKeyException("Invalid API key or model name.")

        self.memory = Memory(max_messages=max_messages)

    def chat(self, message: str) -> str:
        if not message:
            raise ChatException("Message cannot be empty.")

        try:
            self.memory.add_message("user", message)

            history = [
                {"role": msg["role"], "parts": [msg["content"]]}
                for msg in self.memory.get_history()
            ]

            response = self.model.generate_content(history)
            reply = response.text

            self.memory.add_message("model", reply)
            return reply

        except Exception as e:
            raise ChatException(f"Something went wrong: {str(e)}")

    def clear_memory(self):
        self.memory.clear()

    def get_history(self):
        return self.memory.get_history()
