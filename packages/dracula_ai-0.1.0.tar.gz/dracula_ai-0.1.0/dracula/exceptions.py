class DraculaException(Exception):
    """Base exception for Dracula library."""

    pass


class InvalidAPIKeyException(DraculaException):
    """Raised when the API key is missing or invalid."""

    pass


class ChatException(DraculaException):
    """Raised when something goes wrong during a chat request."""

    pass
