---
name: deps
description: "Detect package manager and manage project dependencies (install, add, list)."
---

Manage project dependencies. Auto-detects the package manager from project files.
Supports pip, npm, poetry, and cargo. Use `detect` to identify the package manager,
`install` to install all dependencies, `add` to add a specific package, `list` to
show installed packages.
