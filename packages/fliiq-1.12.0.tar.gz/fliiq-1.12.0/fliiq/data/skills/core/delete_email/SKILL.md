---
name: delete_email
description: "Delete an email by IMAP UID (moves to Trash in Gmail). Uses OAuth or app password fallback."
---

Delete an email by moving it to Gmail's Trash folder. Uses IMAP UID from `receive_emails`.

Pass the `id` field from a receive_emails result as the `message_id` parameter.
