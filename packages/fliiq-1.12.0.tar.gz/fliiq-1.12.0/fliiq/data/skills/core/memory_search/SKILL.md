---
name: memory_search
description: "Search across all memory files by keyword, or list available skill memories."
---

Use this tool to find information across the agent's memory files. Supports:
- Keyword/regex search across MEMORY.md, daily logs, and skill memories
- Listing available skill memory files (set `list_skills: true`)

Results include file name, line number, matching line, and surrounding context.
