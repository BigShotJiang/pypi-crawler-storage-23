from fliiq.runtime.config import resolve_fliiq_dir
from fliiq.runtime.memory.manager import MemoryManager


async def handler(params: dict) -> dict:
    """Read a memory file by name."""
    name = params["name"]
    manager = MemoryManager(resolve_fliiq_dir() / "memory")
    content = manager.load_memory(name)
    if content is None:
        return {"content": "", "exists": False}
    return {"content": content, "exists": True}
