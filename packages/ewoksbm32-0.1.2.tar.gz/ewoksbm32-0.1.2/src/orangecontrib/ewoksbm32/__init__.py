import sysconfig

NAME = "ewoksbm32"

DESCRIPTION = "Data processing workflows for BM32"

LONG_DESCRIPTION = "Data processing workflows for BM32"

ICON = "icons/category.svg"

BACKGROUND = "light-blue"

WIDGET_HELP_PATH = (
    # Development documentation (make htmlhelp in ./doc)
    ("{DEVELOP_ROOT}/doc/_build/htmlhelp/index.html", None),
    # Documentation included in wheel
    (
        "{}/help/ewoksbm32/index.html".format(sysconfig.get_path("data")),
        None,
    ),
    # Online documentation url
    ("https://ewoksbm32.readthedocs.io", ""),
)
