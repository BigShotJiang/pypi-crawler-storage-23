import sysconfig

WIDGET_HELP_PATH = (
    # Development documentation (make htmlhelp in ./doc)
    ("{DEVELOP_ROOT}/doc/_build/htmlhelp/index.html", None),
    # Documentation included in wheel
    (
        "{}/help/ewoksbm32/index.html".format(sysconfig.get_path("data")),
        None,
    ),
    # Online documentation url
    ("https://ewoksbm32.readthedocs.io", ""),
)


# Entry point for main Orange categories/widgets discovery
def widget_discovery(discovery):
    from ewoksorange.pkg_meta import get_distribution

    dist = get_distribution("ewoksbm32")
    pkgs = [
        "orangecontrib.ewoksbm32.categories.examples1",
        "orangecontrib.ewoksbm32.categories.examples2",
    ]
    for pkg in pkgs:
        discovery.process_category_package(pkg, distribution=dist)
