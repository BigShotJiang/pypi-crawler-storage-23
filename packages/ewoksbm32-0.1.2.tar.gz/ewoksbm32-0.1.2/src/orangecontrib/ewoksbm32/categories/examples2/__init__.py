NAME = "Ewoks Examples (2)"

DESCRIPTION = "Ewoks Examples"

LONG_DESCRIPTION = "Ewoks Examples"

ICON = "icons/category.svg"

BACKGROUND = "light-blue"
