# API Reference

```{eval-rst}
.. automodule:: lamindb_setup
```
