# Running hub-local tests locally

To run these tests locally, you need to have the local backend set up: https://github.com/laminlabs/laminhub?tab=readme-ov-file#local-backend.
Moreover, ensure that `laminhub_rest` is installed in editable mode.
Otherwise you might run into `laminhub_rest` not found errors.
It might be required to use a specific supabase version.
Currently 2.31.8 works and the latest version 2.48.3 does not - talk to the hub team.
