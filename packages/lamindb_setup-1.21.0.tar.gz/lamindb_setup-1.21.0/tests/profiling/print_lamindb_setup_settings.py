from lamindb_setup import settings

print(settings)
