from lamindb_setup._connect_instance import _connect_cli

_connect_cli("laminlabs/lamindata")
