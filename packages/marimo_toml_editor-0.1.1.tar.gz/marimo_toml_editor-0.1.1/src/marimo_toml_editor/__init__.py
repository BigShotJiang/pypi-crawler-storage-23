"""marimo-toml-editor public API."""

from marimo_toml_editor._widget import TomlConfigEditor

__all__ = ["TomlConfigEditor"]
__version__ = "0.1.0"
