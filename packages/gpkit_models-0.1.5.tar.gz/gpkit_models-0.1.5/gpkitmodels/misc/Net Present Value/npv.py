"get the python code from the markdown file"

from gpkit.tools import mdparse

exec(mdparse("npv.md"))
