#!/usr/bin/env bash
# One-off publish to PyPI using your API token.
# Usage:
#   export TWINE_USERNAME=__token__
#   export TWINE_PASSWORD=pypi-YourTokenHere
#   ./scripts/publish-once.sh
# Or run the commands below manually.

set -e
cd "$(dirname "$0")/.."
pip install build twine -q
rm -rf dist
python -m build
twine upload dist/*
