"""Protocol definitions for PyCatalyst pluggable interfaces.

Protocols define the contracts for generators, sinks, and schema
inferrers. Implementations can be swapped in via dependency injection
without coupling to concrete classes.
"""

from __future__ import annotations

from random import Random
from typing import Any, Protocol, runtime_checkable

from pycatalyst._types import FieldSpec, SchemaSpec, SinkResult

# ---------------------------------------------------------------------------
# Generator protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class Generator(Protocol):
    """Generates values for a single field type.

    Implementations produce random or constrained values based on a
    FieldSpec. Each generator handles one or more FieldType values.
    """

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate a single value for the given field spec.

        Args:
            spec: The field specification describing what to generate.
            rng: Random number generator for reproducible output.

        Returns:
            A generated value matching the field spec's type and constraints.
        """
        ...


# ---------------------------------------------------------------------------
# Sink protocols
# ---------------------------------------------------------------------------


@runtime_checkable
class Sink(Protocol):
    """Receives generated data batches (synchronous).

    Sinks are the output targets for generated data. Implementations
    handle writing to files, HTTP endpoints, databases, queues, etc.
    """

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Send a batch of records to the target.

        Args:
            records: List of generated records to send.
            metadata: Generation metadata (schema name, timestamp, etc.).

        Returns:
            Result indicating success/failure and records sent.
        """
        ...

    def close(self) -> None:
        """Release any resources held by the sink."""
        ...


@runtime_checkable
class AsyncSink(Protocol):
    """Receives generated data batches (asynchronous).

    Async variant for I/O-bound sinks (HTTP, databases, queues).
    """

    async def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Send a batch of records to the target asynchronously.

        Args:
            records: List of generated records to send.
            metadata: Generation metadata (schema name, timestamp, etc.).

        Returns:
            Result indicating success/failure and records sent.
        """
        ...

    async def close(self) -> None:
        """Release any resources held by the sink."""
        ...


# ---------------------------------------------------------------------------
# Schema inferrer protocol
# ---------------------------------------------------------------------------


@runtime_checkable
class SchemaInferrer(Protocol):
    """Infers a SchemaSpec from a data source.

    Implementations analyze sample data (CSV, JSON, Parquet, etc.)
    to produce a SchemaSpec suitable for generation.
    """

    def infer(self, source: Any) -> SchemaSpec:
        """Infer a schema from the given data source.

        Args:
            source: The data source to analyze. Type depends on
                implementation (file path, DataFrame, dict, etc.).

        Returns:
            An inferred SchemaSpec ready for data generation.
        """
        ...
