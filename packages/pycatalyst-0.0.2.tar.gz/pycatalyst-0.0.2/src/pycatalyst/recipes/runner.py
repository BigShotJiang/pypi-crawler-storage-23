"""Recipe runner for end-to-end data generation and delivery.

Loads a recipe, builds a SchemaSpec, generates data, and sends
it to the configured sink.
"""

from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

from pycatalyst._types import FieldSpec, GenerationResult, SchemaSpec, SinkResult
from pycatalyst.errors import RecipeError
from pycatalyst.generators.engine import GenerationEngine
from pycatalyst.recipes.loader import load_recipe, load_recipe_from_dict
from pycatalyst.recipes.models import RecipeConfig, SchemaFieldConfig

logger = logging.getLogger(__name__)


class RecipeRunner:
    """Executes a recipe end-to-end.

    Handles the full pipeline: load recipe → build schema →
    generate data → send to sink.
    """

    def __init__(self, engine: GenerationEngine | None = None) -> None:
        self._engine = engine or GenerationEngine()

    def run_file(self, path: str | Path) -> tuple[GenerationResult, SinkResult]:
        """Run a recipe from a YAML file.

        Args:
            path: Path to the recipe YAML file.

        Returns:
            Tuple of (GenerationResult, SinkResult).
        """
        config = load_recipe(path)
        return self._execute(config)

    def run_dict(self, data: dict[str, Any]) -> tuple[GenerationResult, SinkResult]:
        """Run a recipe from a dictionary.

        Args:
            data: Recipe configuration as a dict.

        Returns:
            Tuple of (GenerationResult, SinkResult).
        """
        config = load_recipe_from_dict(data)
        return self._execute(config)

    def _execute(self, config: RecipeConfig) -> tuple[GenerationResult, SinkResult]:
        """Execute a validated recipe config."""
        logger.info("running recipe '%s'", config.name)

        schema = _build_schema(config)
        gen_result = self._engine.generate(
            schema,
            count=config.generation.count,
            seed=config.generation.seed,
        )

        sink = _create_sink(config)
        metadata = {
            "recipe_name": config.name,
            "schema_name": schema.name,
            "count": gen_result.count,
        }
        sink_result = sink.send(list(gen_result.records), metadata)
        sink.close()

        logger.info(
            "recipe '%s' complete: %d records generated, %d sent",
            config.name,
            gen_result.count,
            sink_result.records_sent,
        )

        return gen_result, sink_result


def _build_schema(config: RecipeConfig) -> SchemaSpec:
    """Build a SchemaSpec from recipe config."""
    fields = tuple(_build_field(f) for f in config.schema_.fields)
    return SchemaSpec(
        name=config.name,
        fields=fields,
        description=config.description,
    )


def _build_field(field_config: SchemaFieldConfig) -> FieldSpec:
    """Convert a recipe field config to a FieldSpec."""
    config_dict: dict[str, Any] = {
        "name": field_config.name,
        "type": field_config.type,
        "nullable": field_config.nullable,
        "nullable_rate": field_config.nullable_rate,
        "description": field_config.description,
    }
    if field_config.constraints:
        config_dict["constraints"] = field_config.constraints
    if field_config.children:
        config_dict["children"] = [
            {
                "name": c.name,
                "type": c.type,
                "nullable": c.nullable,
                "constraints": c.constraints if c.constraints else None,
            }
            for c in field_config.children
        ]
    return FieldSpec.from_config(config_dict)


def _create_sink(config: RecipeConfig) -> Any:
    """Create a sink instance from recipe config."""
    sink_type = config.sink.type.lower()
    sink_config = config.sink.config

    if sink_type == "memory":
        from pycatalyst.sinks.memory import InMemorySink

        return InMemorySink()

    if sink_type == "file":
        from pycatalyst.sinks.file import FileSink

        path = sink_config.get("path")
        if not path:
            raise RecipeError(
                "File sink requires 'path' in config",
                recipe_name=config.name,
            )
        return FileSink(
            path,
            format=sink_config.get("format"),
            append=sink_config.get("append", False),
        )

    if sink_type == "http":
        from pycatalyst.sinks.http import HttpSink

        url = sink_config.get("url")
        if not url:
            raise RecipeError(
                "HTTP sink requires 'url' in config",
                recipe_name=config.name,
            )
        return HttpSink(
            url,
            method=sink_config.get("method", "POST"),
            headers=sink_config.get("headers"),
            batch_size=sink_config.get("batch_size", 0),
            timeout=sink_config.get("timeout", 30.0),
            auth_token=sink_config.get("auth_token"),
        )

    if sink_type == "database":
        from pycatalyst.sinks.database import DatabaseSink

        connection_url = sink_config.get("connection_url")
        table_name = sink_config.get("table_name")
        if not connection_url:
            raise RecipeError(
                "Database sink requires 'connection_url' in config",
                recipe_name=config.name,
            )
        if not table_name:
            raise RecipeError(
                "Database sink requires 'table_name' in config",
                recipe_name=config.name,
            )
        return DatabaseSink(
            connection_url,
            table_name,
            batch_size=sink_config.get("batch_size", 0),
            if_exists=sink_config.get("if_exists", "append"),
            schema=sink_config.get("schema"),
        )

    if sink_type == "kafka":
        from pycatalyst.sinks.kafka import KafkaSink

        bootstrap_servers = sink_config.get("bootstrap_servers")
        topic = sink_config.get("topic")
        if not bootstrap_servers:
            raise RecipeError(
                "Kafka sink requires 'bootstrap_servers' in config",
                recipe_name=config.name,
            )
        if not topic:
            raise RecipeError(
                "Kafka sink requires 'topic' in config",
                recipe_name=config.name,
            )
        return KafkaSink(
            bootstrap_servers,
            topic,
            key_field=sink_config.get("key_field"),
            producer_config=sink_config.get("producer_config"),
            flush_timeout=sink_config.get("flush_timeout", 10.0),
        )

    if sink_type == "rabbitmq":
        from pycatalyst.sinks.rabbitmq import RabbitMQSink

        url = sink_config.get("url")
        if not url:
            raise RecipeError(
                "RabbitMQ sink requires 'url' in config",
                recipe_name=config.name,
            )
        return RabbitMQSink(
            url,
            exchange=sink_config.get("exchange", ""),
            routing_key=sink_config.get("routing_key", ""),
            queue=sink_config.get("queue"),
            declare_queue=sink_config.get("declare_queue", True),
        )

    raise RecipeError(
        f"Unknown sink type: '{sink_type}'",
        recipe_name=config.name,
    )
