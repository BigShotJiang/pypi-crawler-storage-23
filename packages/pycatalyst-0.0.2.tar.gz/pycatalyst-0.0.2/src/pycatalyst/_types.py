"""Internal data types for PyCatalyst.

All frozen dataclasses that define the structure of data generation:
FieldSpec, SchemaSpec, GenerationResult, SinkResult, and supporting types.

These are the core value objects -- immutable definitions loaded from config.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class FieldType(str, Enum):
    """Supported field types for data generation."""

    STRING = "string"
    """Variable-length text."""

    INT = "int"
    """Integer values."""

    FLOAT = "float"
    """Floating-point values."""

    BOOL = "bool"
    """Boolean true/false."""

    DATE = "date"
    """Calendar date (no time component)."""

    DATETIME = "datetime"
    """Date with time and optional timezone."""

    UUID = "uuid"
    """UUID v4 identifier."""

    ENUM = "enum"
    """Value from a fixed set of choices."""

    OBJECT = "object"
    """Nested object with child fields."""

    ARRAY = "array"
    """Array of items (homogeneous type via children)."""

    @classmethod
    def from_string(cls, value: str) -> FieldType:
        """Parse a field type from a string, case-insensitive.

        Args:
            value: String representation of the field type.

        Returns:
            The matching FieldType enum member.

        Raises:
            ValueError: If the string doesn't match any field type.
        """
        normalized = value.strip().lower()
        try:
            return cls(normalized)
        except ValueError:
            valid = ", ".join(member.value for member in cls)
            raise ValueError(f"Unknown field type '{value}'. Valid types: {valid}")


class Distribution(str, Enum):
    """Statistical distribution for numeric field generation."""

    UNIFORM = "uniform"
    """Uniformly distributed between min and max."""

    NORMAL = "normal"
    """Normal (Gaussian) distribution."""

    LOG_NORMAL = "log_normal"
    """Log-normal distribution."""

    EXPONENTIAL = "exponential"
    """Exponential distribution."""


# ---------------------------------------------------------------------------
# Constraints
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class FieldConstraints:
    """Constraints for field value generation.

    Not all constraints apply to all field types. The generator
    interprets only the constraints relevant to its field type.

    Attributes:
        min: Minimum value (int/float) or minimum length (string).
        max: Maximum value (int/float) or maximum length (string).
        precision: Decimal precision for float fields.
        pattern: Regex pattern for string fields.
        choices: Fixed set of allowed values for enum fields.
        distribution: Statistical distribution for numeric fields.
        mean: Mean for normal/log-normal distribution.
        std: Standard deviation for normal/log-normal distribution.
        unique: If True, generated values must be unique within the batch.
        min_items: Minimum number of items for array fields.
        max_items: Maximum number of items for array fields.
        format: Named format hint (e.g., "email", "url", "phone").
    """

    min: int | float | None = None
    max: int | float | None = None
    precision: int | None = None
    pattern: str | None = None
    choices: tuple[Any, ...] = ()
    distribution: Distribution | None = None
    mean: float | None = None
    std: float | None = None
    unique: bool = False
    min_items: int | None = None
    max_items: int | None = None
    format: str | None = None

    def __post_init__(self) -> None:
        if self.min is not None and self.max is not None and self.min > self.max:
            raise ValueError(
                f"min ({self.min}) cannot be greater than max ({self.max})"
            )
        if self.precision is not None and self.precision < 0:
            raise ValueError(f"precision must be non-negative, got {self.precision}")
        if self.min_items is not None and self.min_items < 0:
            raise ValueError(f"min_items must be non-negative, got {self.min_items}")
        if self.max_items is not None and self.max_items < 0:
            raise ValueError(f"max_items must be non-negative, got {self.max_items}")
        if (
            self.min_items is not None
            and self.max_items is not None
            and self.min_items > self.max_items
        ):
            raise ValueError(
                f"min_items ({self.min_items}) cannot be greater "
                f"than max_items ({self.max_items})"
            )

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> FieldConstraints:
        """Create from a config dict (YAML/JSON recipe).

        Args:
            config: Dictionary with constraint fields.

        Returns:
            A new FieldConstraints instance.
        """
        choices = config.get("choices", ())
        if isinstance(choices, list):
            choices = tuple(choices)

        distribution = config.get("distribution")
        if distribution and isinstance(distribution, str):
            distribution = Distribution(distribution)

        return cls(
            min=config.get("min"),
            max=config.get("max"),
            precision=config.get("precision"),
            pattern=config.get("pattern"),
            choices=choices,
            distribution=distribution,
            mean=config.get("mean"),
            std=config.get("std"),
            unique=config.get("unique", False),
            min_items=config.get("min_items"),
            max_items=config.get("max_items"),
            format=config.get("format"),
        )


# ---------------------------------------------------------------------------
# FieldSpec
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class FieldSpec:
    """Specification for generating a single field.

    Describes the name, type, nullability, constraints, and nested
    structure (for objects/arrays) of a field to generate.

    Attributes:
        name: Field name in the generated record.
        type: The data type to generate.
        nullable: If True, some generated values will be None.
        nullable_rate: Probability of generating None (0.0-1.0).
        constraints: Optional generation constraints.
        children: Child field specs for OBJECT and ARRAY types.
        description: Human-readable description.
    """

    name: str
    type: FieldType
    nullable: bool = False
    nullable_rate: float = 0.1
    constraints: FieldConstraints | None = None
    children: tuple[FieldSpec, ...] = ()
    description: str = ""

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("Field name cannot be empty")
        if not (0.0 <= self.nullable_rate <= 1.0):
            raise ValueError(
                f"nullable_rate must be between 0.0 and 1.0, got {self.nullable_rate}"
            )
        if self.type == FieldType.OBJECT and not self.children:
            raise ValueError(f"Object field '{self.name}' must have at least one child")
        if self.type == FieldType.ARRAY and not self.children:
            raise ValueError(
                f"Array field '{self.name}' must have at least one child "
                f"defining the item type"
            )
        if self.type == FieldType.ENUM:
            if not self.constraints or not self.constraints.choices:
                raise ValueError(
                    f"Enum field '{self.name}' must have constraints "
                    f"with choices defined"
                )

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> FieldSpec:
        """Create from a config dict (YAML/JSON recipe).

        Args:
            config: Dictionary with field specification.

        Returns:
            A new FieldSpec instance.

        Raises:
            ValueError: If required fields are missing or invalid.
        """
        if "name" not in config or "type" not in config:
            raise ValueError(f"FieldSpec requires 'name' and 'type': {config}")

        field_type = FieldType.from_string(config["type"])

        constraints = None
        if "constraints" in config:
            constraints = FieldConstraints.from_config(config["constraints"])

        children = ()
        if "children" in config:
            children = tuple(cls.from_config(child) for child in config["children"])

        return cls(
            name=config["name"],
            type=field_type,
            nullable=config.get("nullable", False),
            nullable_rate=config.get("nullable_rate", 0.1),
            constraints=constraints,
            children=children,
            description=config.get("description", ""),
        )


# ---------------------------------------------------------------------------
# SchemaSpec
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class SchemaSpec:
    """Complete specification for generating records.

    Describes a full record schema with all fields, used by the
    GenerationEngine to produce data batches.

    Attributes:
        name: Schema name (used for identification and logging).
        fields: Field specifications for the record.
        description: Human-readable description.
        metadata: Additional user-defined metadata.
    """

    name: str
    fields: tuple[FieldSpec, ...]
    description: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("Schema name cannot be empty")
        if not self.fields:
            raise ValueError(f"Schema '{self.name}' must have at least one field")
        # Check for duplicate field names
        names = [f.name for f in self.fields]
        if len(names) != len(set(names)):
            dupes = [n for n in names if names.count(n) > 1]
            raise ValueError(
                f"Schema '{self.name}' has duplicate field names: {sorted(set(dupes))}"
            )

    @property
    def field_names(self) -> tuple[str, ...]:
        """All top-level field names."""
        return tuple(f.name for f in self.fields)

    def get_field(self, name: str) -> FieldSpec | None:
        """Look up a field by name.

        Args:
            name: The field name to find.

        Returns:
            The matching FieldSpec, or None if not found.
        """
        for f in self.fields:
            if f.name == name:
                return f
        return None

    @classmethod
    def from_config(cls, config: dict[str, Any]) -> SchemaSpec:
        """Create from a config dict (YAML/JSON recipe).

        Args:
            config: Dictionary with schema specification.

        Returns:
            A new SchemaSpec instance.

        Raises:
            ValueError: If required fields are missing.
        """
        if "name" not in config:
            raise ValueError("SchemaSpec requires 'name'")

        fields_config = config.get("fields", [])
        if not fields_config:
            raise ValueError(
                f"SchemaSpec '{config['name']}' requires at least one field"
            )

        fields = tuple(FieldSpec.from_config(f) for f in fields_config)

        return cls(
            name=config["name"],
            fields=fields,
            description=config.get("description", ""),
            metadata=config.get("metadata", {}),
        )


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class GenerationResult:
    """Result of a data generation run.

    Attributes:
        records: The generated records.
        schema: The schema used for generation.
        count: Number of records generated.
        duration_ms: Generation time in milliseconds.
        seed: Random seed used (for reproducibility).
    """

    records: tuple[dict[str, Any], ...]
    schema: SchemaSpec
    count: int
    duration_ms: float
    seed: int | None = None


@dataclass(frozen=True, slots=True)
class SinkResult:
    """Result of sending data to a sink.

    Attributes:
        success: Whether all records were sent successfully.
        records_sent: Number of records successfully sent.
        sink_type: The type of sink that received the data.
        errors: Error messages for any failures.
        metadata: Additional sink-specific metadata.
    """

    success: bool
    records_sent: int
    sink_type: str = ""
    errors: tuple[str, ...] = ()
    metadata: dict[str, Any] = field(default_factory=dict)
