"""Database sink for inserting generated data via SQLAlchemy.

Inserts generated records into a database table. Requires the [db]
optional extra (sqlalchemy).
"""

from __future__ import annotations

import logging
from typing import Any

from pycatalyst._types import SinkResult
from pycatalyst.errors import SinkError

logger = logging.getLogger(__name__)


class DatabaseSink:
    """Inserts generated records into a database table via SQLAlchemy.

    Supports any database backend that SQLAlchemy supports
    (PostgreSQL, SQLite, MySQL, etc.).

    Attributes:
        table_name: Target database table.
        connection_url: SQLAlchemy connection URL.
        batch_size: Records per INSERT statement (0 = all at once).
    """

    def __init__(
        self,
        connection_url: str,
        table_name: str,
        *,
        batch_size: int = 0,
        if_exists: str = "append",
        schema: str | None = None,
    ) -> None:
        """Initialize the database sink.

        Args:
            connection_url: SQLAlchemy connection URL.
            table_name: Target table name.
            batch_size: Records per INSERT (0 = send all at once).
            if_exists: Behavior when table exists: "append" or "replace".
            schema: Optional database schema (e.g. "public").

        Raises:
            SinkError: If sqlalchemy is not installed or if_exists is invalid.
        """
        try:
            import sqlalchemy  # noqa: F401
        except ImportError:
            raise SinkError(
                "sqlalchemy is required for DatabaseSink. "
                "Install with: pip install pycatalyst[db]",
                sink_type="database",
            )

        if if_exists not in ("append", "replace"):
            raise SinkError(
                f"Invalid if_exists value: '{if_exists}'. Use 'append' or 'replace'.",
                sink_type="database",
            )

        self._connection_url = connection_url
        self._table_name = table_name
        self._batch_size = batch_size
        self._if_exists = if_exists
        self._schema = schema
        self._engine: Any = None

    def _get_engine(self) -> Any:
        """Lazily create the SQLAlchemy engine."""
        if self._engine is None:
            from sqlalchemy import create_engine

            self._engine = create_engine(self._connection_url)
        return self._engine

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Insert records into the database table.

        Args:
            records: List of generated records.
            metadata: Generation metadata.

        Returns:
            SinkResult indicating success or failure.
        """
        if not records:
            return SinkResult(
                success=True,
                records_sent=0,
                sink_type="database",
            )

        from sqlalchemy import MetaData, Table, insert, text

        engine = self._get_engine()
        total_sent = 0
        errors: list[str] = []

        try:
            with engine.begin() as conn:
                if self._if_exists == "replace":
                    # Drop and recreate is too aggressive; just truncate
                    conn.execute(
                        text(f"DELETE FROM {self._table_name}")  # noqa: S608
                    )
                    logger.debug("truncated table %s", self._table_name)

                meta = MetaData(schema=self._schema)
                meta.reflect(bind=engine, only=[self._table_name])

                table = Table(
                    self._table_name,
                    meta,
                    schema=self._schema,
                    autoload_with=engine,
                )

                batches = self._split_batches(records)
                for batch in batches:
                    conn.execute(insert(table), batch)
                    total_sent += len(batch)
                    logger.debug(
                        "inserted %d records into %s",
                        len(batch),
                        self._table_name,
                    )

        except Exception as exc:
            msg = f"Database insert failed: {exc}"
            errors.append(msg)
            logger.warning("database sink error: %s", msg)

        success = len(errors) == 0

        if success:
            logger.info(
                "inserted %d records into %s",
                total_sent,
                self._table_name,
            )

        return SinkResult(
            success=success,
            records_sent=total_sent,
            sink_type="database",
            errors=tuple(errors),
            metadata={
                "table": self._table_name,
                "connection_url": _mask_url(self._connection_url),
            },
        )

    def close(self) -> None:
        """Dispose of the database engine."""
        if self._engine is not None:
            self._engine.dispose()
            self._engine = None

    def _split_batches(
        self, records: list[dict[str, Any]]
    ) -> list[list[dict[str, Any]]]:
        """Split records into batches."""
        if self._batch_size <= 0:
            return [records]
        return [
            records[i : i + self._batch_size]
            for i in range(0, len(records), self._batch_size)
        ]


def _mask_url(url: str) -> str:
    """Mask password in a connection URL for safe logging."""
    if "@" in url and ":" in url.split("@")[0]:
        # Has credentials — mask password
        prefix, rest = url.split("@", 1)
        scheme_user = prefix.rsplit(":", 1)[0]
        return f"{scheme_user}:***@{rest}"
    return url
