"""File sink for writing generated data to disk.

Supports JSON, CSV, and YAML output formats. Parquet support
requires the [parquet] optional extra.
"""

from __future__ import annotations

import csv
import json
import logging
from pathlib import Path
from typing import Any

import yaml

from pycatalyst._types import SinkResult
from pycatalyst.errors import SinkError

logger = logging.getLogger(__name__)


class FileSink:
    """Writes generated records to a file.

    Supports JSON, CSV, and YAML formats. Format is auto-detected
    from the file extension, or can be explicitly specified.

    Attributes:
        path: Output file path.
        format: Output format (json, csv, yaml).
        append: If True, append to existing file instead of overwriting.
    """

    _SUPPORTED_FORMATS = {"json", "csv", "yaml", "yml"}

    def __init__(
        self,
        path: str | Path,
        *,
        format: str | None = None,
        append: bool = False,
    ) -> None:
        self._path = Path(path)
        self._append = append

        if format:
            self._format = format.lower()
        else:
            self._format = self._path.suffix.lstrip(".").lower()

        if self._format == "yml":
            self._format = "yaml"

        if self._format not in self._SUPPORTED_FORMATS:
            raise SinkError(
                f"Unsupported file format: '{self._format}'. "
                f"Supported: {', '.join(sorted(self._SUPPORTED_FORMATS))}",
                sink_type="file",
            )

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Write records to the file.

        Args:
            records: List of generated records.
            metadata: Generation metadata (unused for file output).

        Returns:
            SinkResult indicating success or failure.
        """
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)

            if self._format == "json":
                self._write_json(records)
            elif self._format == "csv":
                self._write_csv(records)
            elif self._format == "yaml":
                self._write_yaml(records)

            logger.info(
                "wrote %d records to %s (%s)",
                len(records),
                self._path,
                self._format,
            )

            return SinkResult(
                success=True,
                records_sent=len(records),
                sink_type="file",
                metadata={"path": str(self._path), "format": self._format},
            )
        except Exception as exc:
            raise SinkError(
                f"Failed to write to {self._path}: {exc}",
                sink_type="file",
            ) from exc

    def close(self) -> None:
        """No-op for file sink."""

    def _write_json(self, records: list[dict[str, Any]]) -> None:
        """Write records as JSON array."""
        if self._append and self._path.exists():
            existing = json.loads(self._path.read_text(encoding="utf-8"))
            if isinstance(existing, list):
                records = existing + records

        self._path.write_text(
            json.dumps(records, indent=2, default=str),
            encoding="utf-8",
        )

    def _write_csv(self, records: list[dict[str, Any]]) -> None:
        """Write records as CSV."""
        if not records:
            return

        # Collect all field names across records
        fieldnames: list[str] = []
        seen: set[str] = set()
        for record in records:
            for key in record:
                if key not in seen:
                    fieldnames.append(key)
                    seen.add(key)

        mode = "a" if self._append and self._path.exists() else "w"
        write_header = mode == "w" or not self._path.exists()

        with self._path.open(mode, encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            if write_header:
                writer.writeheader()
            writer.writerows(records)

    def _write_yaml(self, records: list[dict[str, Any]]) -> None:
        """Write records as YAML list."""
        if self._append and self._path.exists():
            existing = yaml.safe_load(self._path.read_text(encoding="utf-8"))
            if isinstance(existing, list):
                records = existing + records

        self._path.write_text(
            yaml.dump(records, default_flow_style=False, sort_keys=False),
            encoding="utf-8",
        )
