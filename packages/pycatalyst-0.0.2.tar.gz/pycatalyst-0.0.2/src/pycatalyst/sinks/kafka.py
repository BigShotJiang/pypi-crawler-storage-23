"""Kafka sink for publishing generated data to Kafka topics.

Publishes generated records as JSON messages to a Kafka topic.
Requires the [kafka] optional extra (confluent-kafka).
"""

from __future__ import annotations

import json
import logging
from typing import Any

from pycatalyst._types import SinkResult
from pycatalyst.errors import SinkError

logger = logging.getLogger(__name__)


class KafkaSink:
    """Publishes generated records to a Kafka topic.

    Each record is serialized as JSON and sent as a message.

    Attributes:
        topic: Target Kafka topic.
        bootstrap_servers: Kafka broker addresses.
    """

    def __init__(
        self,
        bootstrap_servers: str,
        topic: str,
        *,
        key_field: str | None = None,
        producer_config: dict[str, Any] | None = None,
        flush_timeout: float = 10.0,
    ) -> None:
        """Initialize the Kafka sink.

        Args:
            bootstrap_servers: Comma-separated broker addresses.
            topic: Target topic name.
            key_field: Optional record field to use as message key.
            producer_config: Additional confluent-kafka producer config.
            flush_timeout: Timeout in seconds for flushing pending messages.

        Raises:
            SinkError: If confluent-kafka is not installed.
        """
        try:
            import confluent_kafka  # noqa: F401
        except ImportError:
            raise SinkError(
                "confluent-kafka is required for KafkaSink. "
                "Install with: pip install pycatalyst[kafka]",
                sink_type="kafka",
            )

        self._bootstrap_servers = bootstrap_servers
        self._topic = topic
        self._key_field = key_field
        self._flush_timeout = flush_timeout

        config: dict[str, Any] = {
            "bootstrap.servers": bootstrap_servers,
            **(producer_config or {}),
        }
        self._producer_config = config
        self._producer: Any = None
        self._delivery_errors: list[str] = []

    def _get_producer(self) -> Any:
        """Lazily create the Kafka producer."""
        if self._producer is None:
            from confluent_kafka import Producer

            self._producer = Producer(self._producer_config)
        return self._producer

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Publish records to the Kafka topic.

        Args:
            records: List of generated records.
            metadata: Generation metadata.

        Returns:
            SinkResult indicating success or failure.
        """
        if not records:
            return SinkResult(
                success=True,
                records_sent=0,
                sink_type="kafka",
            )

        producer = self._get_producer()
        self._delivery_errors.clear()
        total_sent = 0
        errors: list[str] = []

        try:
            for record in records:
                key = None
                if self._key_field and self._key_field in record:
                    key = str(record[self._key_field])

                value = json.dumps(record).encode("utf-8")
                key_bytes = key.encode("utf-8") if key else None

                producer.produce(
                    topic=self._topic,
                    value=value,
                    key=key_bytes,
                    callback=self._delivery_callback,
                )
                total_sent += 1

            # Wait for all messages to be delivered
            remaining = producer.flush(timeout=self._flush_timeout)
            if remaining > 0:
                errors.append(
                    f"{remaining} messages not delivered "
                    f"within {self._flush_timeout}s timeout"
                )

            errors.extend(self._delivery_errors)

        except Exception as exc:
            msg = f"Kafka produce failed: {exc}"
            errors.append(msg)
            logger.warning("kafka sink error: %s", msg)

        success = len(errors) == 0

        if success:
            logger.info(
                "published %d records to topic %s",
                total_sent,
                self._topic,
            )

        return SinkResult(
            success=success,
            records_sent=total_sent,
            sink_type="kafka",
            errors=tuple(errors),
            metadata={
                "topic": self._topic,
                "bootstrap_servers": self._bootstrap_servers,
            },
        )

    def close(self) -> None:
        """Flush and clean up the producer."""
        if self._producer is not None:
            self._producer.flush(timeout=self._flush_timeout)
            self._producer = None

    def _delivery_callback(self, err: Any, msg: Any) -> None:
        """Handle delivery reports from the producer."""
        if err is not None:
            error_msg = f"Message delivery failed: {err}"
            self._delivery_errors.append(error_msg)
            logger.warning("kafka delivery error: %s", error_msg)
