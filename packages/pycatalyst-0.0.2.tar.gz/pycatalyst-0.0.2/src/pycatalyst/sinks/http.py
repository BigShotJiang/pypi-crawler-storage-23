"""HTTP sink for sending generated data to REST APIs.

Posts generated records to an HTTP endpoint. Requires the [http]
optional extra (httpx).
"""

from __future__ import annotations

import logging
from typing import Any

from pycatalyst._types import SinkResult
from pycatalyst.errors import SinkError

logger = logging.getLogger(__name__)


class HttpSink:
    """Sends generated records to an HTTP endpoint.

    Supports POST/PUT with configurable headers, authentication,
    batch size, and timeout.

    Attributes:
        url: Target endpoint URL.
        method: HTTP method (POST or PUT).
        headers: Request headers.
        batch_size: Records per request (0 = send all at once).
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        url: str,
        *,
        method: str = "POST",
        headers: dict[str, str] | None = None,
        batch_size: int = 0,
        timeout: float = 30.0,
        auth_token: str | None = None,
    ) -> None:
        try:
            import httpx  # noqa: F401
        except ImportError:
            raise SinkError(
                "httpx is required for HttpSink. "
                "Install with: pip install pycatalyst[http]",
                sink_type="http",
            )

        self._url = url
        self._method = method.upper()
        self._headers = dict(headers or {})
        self._batch_size = batch_size
        self._timeout = timeout

        if auth_token:
            self._headers["Authorization"] = f"Bearer {auth_token}"

        if "Content-Type" not in self._headers:
            self._headers["Content-Type"] = "application/json"

        if self._method not in ("POST", "PUT", "PATCH"):
            raise SinkError(
                f"Unsupported HTTP method: '{self._method}'. Use POST, PUT, or PATCH.",
                sink_type="http",
            )

    def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Send records to the HTTP endpoint.

        Args:
            records: List of generated records.
            metadata: Generation metadata.

        Returns:
            SinkResult indicating success or failure.
        """
        import httpx

        if not records:
            return SinkResult(success=True, records_sent=0, sink_type="http")

        batches = self._split_batches(records)
        total_sent = 0
        errors: list[str] = []

        with httpx.Client(timeout=self._timeout) as client:
            for batch in batches:
                try:
                    response = client.request(
                        self._method,
                        self._url,
                        json=batch,
                        headers=self._headers,
                    )
                    response.raise_for_status()
                    total_sent += len(batch)
                    logger.debug(
                        "sent %d records to %s (%d)",
                        len(batch),
                        self._url,
                        response.status_code,
                    )
                except httpx.HTTPStatusError as exc:
                    msg = (
                        f"HTTP {exc.response.status_code} from "
                        f"{self._url}: {exc.response.text[:200]}"
                    )
                    errors.append(msg)
                    logger.warning("http sink error: %s", msg)
                except httpx.RequestError as exc:
                    msg = f"Request failed for {self._url}: {exc}"
                    errors.append(msg)
                    logger.warning("http sink error: %s", msg)

        success = len(errors) == 0

        if success:
            logger.info("sent %d records to %s", total_sent, self._url)

        return SinkResult(
            success=success,
            records_sent=total_sent,
            sink_type="http",
            errors=tuple(errors),
            metadata={"url": self._url, "method": self._method},
        )

    def close(self) -> None:
        """No-op for HTTP sink (uses per-request clients)."""

    def _split_batches(
        self, records: list[dict[str, Any]]
    ) -> list[list[dict[str, Any]]]:
        """Split records into batches."""
        if self._batch_size <= 0:
            return [records]
        return [
            records[i : i + self._batch_size]
            for i in range(0, len(records), self._batch_size)
        ]


class AsyncHttpSink:
    """Async variant of HttpSink for use in async contexts.

    Attributes:
        url: Target endpoint URL.
        method: HTTP method (POST or PUT).
    """

    def __init__(
        self,
        url: str,
        *,
        method: str = "POST",
        headers: dict[str, str] | None = None,
        batch_size: int = 0,
        timeout: float = 30.0,
        auth_token: str | None = None,
    ) -> None:
        try:
            import httpx  # noqa: F401
        except ImportError:
            raise SinkError(
                "httpx is required for AsyncHttpSink. "
                "Install with: pip install pycatalyst[http]",
                sink_type="http",
            )

        self._url = url
        self._method = method.upper()
        self._headers = dict(headers or {})
        self._batch_size = batch_size
        self._timeout = timeout

        if auth_token:
            self._headers["Authorization"] = f"Bearer {auth_token}"

        if "Content-Type" not in self._headers:
            self._headers["Content-Type"] = "application/json"

    async def send(
        self,
        records: list[dict[str, Any]],
        metadata: dict[str, Any],
    ) -> SinkResult:
        """Send records asynchronously.

        Args:
            records: List of generated records.
            metadata: Generation metadata.

        Returns:
            SinkResult indicating success or failure.
        """
        import httpx

        if not records:
            return SinkResult(success=True, records_sent=0, sink_type="http")

        batches = (
            [records]
            if self._batch_size <= 0
            else [
                records[i : i + self._batch_size]
                for i in range(0, len(records), self._batch_size)
            ]
        )

        total_sent = 0
        errors: list[str] = []

        async with httpx.AsyncClient(timeout=self._timeout) as client:
            for batch in batches:
                try:
                    response = await client.request(
                        self._method,
                        self._url,
                        json=batch,
                        headers=self._headers,
                    )
                    response.raise_for_status()
                    total_sent += len(batch)
                except httpx.HTTPStatusError as exc:
                    errors.append(
                        f"HTTP {exc.response.status_code}: {exc.response.text[:200]}"
                    )
                except httpx.RequestError as exc:
                    errors.append(f"Request failed: {exc}")

        return SinkResult(
            success=len(errors) == 0,
            records_sent=total_sent,
            sink_type="http",
            errors=tuple(errors),
            metadata={"url": self._url, "method": self._method},
        )

    async def close(self) -> None:
        """No-op for async HTTP sink."""
