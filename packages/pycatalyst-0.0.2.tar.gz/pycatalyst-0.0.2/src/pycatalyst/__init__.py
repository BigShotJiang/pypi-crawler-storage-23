"""pycatalyst — a schema-aware data generation and testing platform."""

from __future__ import annotations

try:
    from importlib.metadata import version

    __version__ = version("pycatalyst")
except Exception:
    __version__ = "0.1.0"

# -- Core types --
# -- Protocols --
from pycatalyst._protocols import (
    AsyncSink,
    Generator,
    SchemaInferrer,
    Sink,
)
from pycatalyst._types import (
    Distribution,
    FieldConstraints,
    FieldSpec,
    FieldType,
    GenerationResult,
    SchemaSpec,
    SinkResult,
)

# -- Errors --
from pycatalyst.errors import (
    CatalystError,
    ConfigError,
    ConstraintViolationError,
    ErrorCode,
    GenerationError,
    GeneratorNotFoundError,
    InferenceError,
    RecipeError,
    SchemaError,
    SinkError,
)

# -- Generators & Sinks --
from pycatalyst.generators.engine import GenerationEngine
from pycatalyst.generators.registry import GeneratorRegistry
from pycatalyst.schema.inferrer import infer_from_file, infer_from_records
from pycatalyst.schema.json_schema import from_json_schema
from pycatalyst.schema.pydantic import from_pydantic_model
from pycatalyst.schema.spec import SchemaBuilder
from pycatalyst.sinks.database import DatabaseSink
from pycatalyst.sinks.file import FileSink
from pycatalyst.sinks.http import AsyncHttpSink, HttpSink
from pycatalyst.sinks.kafka import KafkaSink
from pycatalyst.sinks.memory import InMemorySink
from pycatalyst.sinks.rabbitmq import RabbitMQSink

__all__ = [
    "__version__",
    # Types
    "Distribution",
    "FieldConstraints",
    "FieldSpec",
    "FieldType",
    "GenerationResult",
    "SchemaSpec",
    "SinkResult",
    # Protocols
    "AsyncSink",
    "Generator",
    "SchemaInferrer",
    "Sink",
    # Errors
    "CatalystError",
    "ConfigError",
    "ConstraintViolationError",
    "ErrorCode",
    "GenerationError",
    "GeneratorNotFoundError",
    "InferenceError",
    "RecipeError",
    "SchemaError",
    "SinkError",
    # Generators & Sinks
    "GenerationEngine",
    "GeneratorRegistry",
    "InMemorySink",
    "FileSink",
    "HttpSink",
    "AsyncHttpSink",
    "DatabaseSink",
    "KafkaSink",
    "RabbitMQSink",
    # Schema
    "SchemaBuilder",
    "from_json_schema",
    "from_pydantic_model",
    "infer_from_file",
    "infer_from_records",
]
