"""PyCatalyst API — FastAPI application.

REST API for data generation, schema inference, and recipe management.

Usage:
    uvicorn pycatalyst.api.main:create_application --factory --reload
"""

from __future__ import annotations

import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from pycatalyst import __version__ as catalyst_version
from pycatalyst.api.routes.v1 import generate, infer, recipes

API_VERSION = "v1"
API_PREFIX = f"/api/{API_VERSION}"


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Lifespan context manager for FastAPI application."""
    yield


def create_application() -> FastAPI:
    """Create and configure FastAPI application."""
    app = FastAPI(
        title="PyCatalyst API",
        description="REST API for data generation and testing",
        version=catalyst_version,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_url="/openapi.json",
        lifespan=lifespan,
    )

    # CORS
    cors_origins_env = os.getenv("CORS_ORIGINS", "").strip()
    cors_origins = (
        [o.strip() for o in cors_origins_env.split(",") if o.strip()]
        if cors_origins_env
        else []
    )
    is_production = os.getenv("ENVIRONMENT") == "production"
    if not cors_origins and not is_production:
        cors_origins = [
            "http://localhost:3000",
            "http://localhost:3001",
            "http://localhost:3006",
            "http://127.0.0.1:3000",
            "http://127.0.0.1:3001",
            "http://127.0.0.1:3006",
        ]
    use_credentials = bool(cors_origins and "*" not in cors_origins)
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins if cors_origins else ["*"],
        allow_credentials=use_credentials,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Exception handlers
    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(
        request: Request, exc: RequestValidationError
    ) -> JSONResponse:
        return JSONResponse(
            status_code=422,
            content={
                "detail": exc.errors(),
                "body": exc.body,
            },
        )

    @app.exception_handler(Exception)
    async def global_error_handler(request: Request, exc: Exception) -> JSONResponse:
        if isinstance(exc, RequestValidationError):
            return JSONResponse(
                status_code=422,
                content={
                    "detail": exc.errors(),
                    "body": exc.body,
                },
            )
        if isinstance(exc, HTTPException):
            return JSONResponse(
                status_code=exc.status_code,
                content={"detail": exc.detail},
            )
        is_dev = os.getenv("ENVIRONMENT") != "production"
        return JSONResponse(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            content={
                "detail": str(exc) if is_dev else "Internal server error",
            },
        )

    # Routes
    app.include_router(generate.router, prefix=API_PREFIX, tags=["generate"])
    app.include_router(infer.router, prefix=API_PREFIX, tags=["infer"])
    app.include_router(recipes.router, prefix=API_PREFIX, tags=["recipes"])

    # Health check
    @app.get("/health")
    async def health() -> dict[str, str]:
        return {"status": "ok", "version": catalyst_version}

    return app
