"""Recipes endpoint — POST /api/v1/recipes/run."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from pycatalyst.errors import CatalystError
from pycatalyst.recipes.runner import RecipeRunner

router = APIRouter()

_runner = RecipeRunner()


class RecipeRunRequest(BaseModel):
    """Request body for running a recipe."""

    name: str
    description: str = ""
    schema_: dict[str, Any] = Field(..., alias="schema")
    generation: dict[str, Any] = Field(default_factory=lambda: {"count": 10})
    sink: dict[str, Any] = Field(default_factory=lambda: {"type": "memory"})

    model_config = {"populate_by_name": True}


class RecipeRunResponse(BaseModel):
    """Response from running a recipe."""

    records: list[dict[str, Any]]
    count: int
    records_sent: int
    sink_type: str
    duration_ms: float


@router.post("/recipes/run", response_model=RecipeRunResponse)
async def run_recipe(request: RecipeRunRequest) -> RecipeRunResponse:
    """Run a recipe and return generated data.

    Args:
        request: Recipe configuration.

    Returns:
        Generated records and sink result.
    """
    try:
        recipe_dict: dict[str, Any] = {
            "name": request.name,
            "description": request.description,
            "schema": request.schema_,
            "generation": request.generation,
            "sink": {"type": "memory"},  # Always use memory for API
        }

        gen_result, sink_result = _runner.run_dict(recipe_dict)

        return RecipeRunResponse(
            records=list(gen_result.records),
            count=gen_result.count,
            records_sent=sink_result.records_sent,
            sink_type=sink_result.sink_type,
            duration_ms=round(gen_result.duration_ms, 2),
        )
    except CatalystError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=exc.to_dict(),
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": str(exc)},
        )
