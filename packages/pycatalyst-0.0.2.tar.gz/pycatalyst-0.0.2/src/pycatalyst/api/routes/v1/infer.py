"""Infer endpoint — POST /api/v1/infer."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from pycatalyst.errors import CatalystError
from pycatalyst.schema.inferrer import infer_from_records

router = APIRouter()


class InferRequest(BaseModel):
    """Request body for schema inference."""

    records: list[dict[str, Any]] = Field(
        ..., min_length=1, description="Sample records to infer schema from"
    )
    name: str = Field(default="inferred", description="Schema name")


class InferFieldResponse(BaseModel):
    """Inferred field in the response."""

    name: str
    type: str
    nullable: bool = False
    constraints: dict[str, Any] | None = None


class InferResponse(BaseModel):
    """Response from the infer endpoint."""

    name: str
    fields: list[InferFieldResponse]
    field_count: int


@router.post("/infer", response_model=InferResponse)
async def infer_schema(request: InferRequest) -> InferResponse:
    """Infer a schema from sample records.

    Args:
        request: Sample records and optional schema name.

    Returns:
        Inferred schema with field types and constraints.
    """
    try:
        schema = infer_from_records(request.records, name=request.name)

        fields = []
        for f in schema.fields:
            constraints = None
            if f.constraints:
                c = f.constraints
                constraints = {}
                if c.min is not None:
                    constraints["min"] = c.min
                if c.max is not None:
                    constraints["max"] = c.max
                if c.choices:
                    constraints["choices"] = list(c.choices)
                if not constraints:
                    constraints = None

            fields.append(
                InferFieldResponse(
                    name=f.name,
                    type=f.type.value,
                    nullable=f.nullable,
                    constraints=constraints,
                )
            )

        return InferResponse(
            name=schema.name,
            fields=fields,
            field_count=len(fields),
        )
    except CatalystError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=exc.to_dict(),
        )
