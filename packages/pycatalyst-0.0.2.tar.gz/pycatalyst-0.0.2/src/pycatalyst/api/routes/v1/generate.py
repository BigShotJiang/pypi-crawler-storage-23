"""Generate endpoint — POST /api/v1/generate."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from pycatalyst._types import SchemaSpec
from pycatalyst.errors import CatalystError
from pycatalyst.generators.engine import GenerationEngine

router = APIRouter()

_engine = GenerationEngine()


class GenerateFieldRequest(BaseModel):
    """Field definition in a generation request."""

    name: str
    type: str
    nullable: bool = False
    constraints: dict[str, Any] = Field(default_factory=dict)
    children: list[GenerateFieldRequest] = Field(default_factory=list)


class GenerateRequest(BaseModel):
    """Request body for the generate endpoint."""

    schema_name: str = Field(default="api_request", alias="name")
    fields: list[GenerateFieldRequest]
    count: int = Field(default=10, ge=1, le=100000)
    seed: int | None = None

    model_config = {"populate_by_name": True}


class GenerateResponse(BaseModel):
    """Response from the generate endpoint."""

    records: list[dict[str, Any]]
    count: int
    schema_name: str
    duration_ms: float
    seed: int | None = None


@router.post("/generate", response_model=GenerateResponse)
async def generate_data(request: GenerateRequest) -> GenerateResponse:
    """Generate data from an inline schema definition.

    Args:
        request: Generation parameters with schema fields.

    Returns:
        Generated records with metadata.
    """
    try:
        schema = SchemaSpec.from_config(
            {
                "name": request.schema_name,
                "fields": [_field_to_config(f) for f in request.fields],
            }
        )

        result = _engine.generate(schema, count=request.count, seed=request.seed)

        return GenerateResponse(
            records=list(result.records),
            count=result.count,
            schema_name=result.schema.name,
            duration_ms=round(result.duration_ms, 2),
            seed=result.seed,
        )
    except CatalystError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=exc.to_dict(),
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"message": str(exc)},
        )


def _field_to_config(field: GenerateFieldRequest) -> dict[str, Any]:
    """Convert API field request to config dict."""
    config: dict[str, Any] = {
        "name": field.name,
        "type": field.type,
        "nullable": field.nullable,
    }
    if field.constraints:
        config["constraints"] = field.constraints
    if field.children:
        config["children"] = [_field_to_config(c) for c in field.children]
    return config
