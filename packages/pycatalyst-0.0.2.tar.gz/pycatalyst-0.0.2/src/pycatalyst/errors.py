"""Exception hierarchy for PyCatalyst.

All PyCatalyst exceptions inherit from CatalystError, making it easy
to catch any data-generation-related error with a single except clause.
"""

from __future__ import annotations

from enum import Enum
from typing import Any


class ErrorCode(str, Enum):
    """Machine-readable error codes for programmatic error handling."""

    SCHEMA_INVALID = "schema_invalid"
    GENERATION_FAILED = "generation_failed"
    SINK_ERROR = "sink_error"
    RECIPE_INVALID = "recipe_invalid"
    INFERENCE_FAILED = "inference_failed"
    CONFIG = "config"
    GENERATOR_NOT_FOUND = "generator_not_found"
    CONSTRAINT_VIOLATION = "constraint_violation"


class CatalystError(Exception):
    """Base exception for all PyCatalyst errors.

    Attributes:
        message: Human-readable error description.
        context: Additional context about the error.
        code: Machine-readable error code for programmatic handling.
    """

    def __init__(
        self,
        message: str,
        context: dict[str, Any] | None = None,
        *,
        code: ErrorCode | None = None,
    ) -> None:
        self.message = message
        self.context = context or {}
        self.code = code
        super().__init__(message)

    def __str__(self) -> str:
        if self.context:
            ctx_str = ", ".join(f"{k}={v!r}" for k, v in self.context.items())
            return f"{self.message} ({ctx_str})"
        return self.message

    def to_dict(self) -> dict[str, Any]:
        """Serialize error to dictionary."""
        return {
            "type": self.__class__.__name__,
            "message": self.message,
            "code": self.code.value if self.code else None,
            "context": self.context,
        }


class SchemaError(CatalystError):
    """Error in schema definition or validation.

    Attributes:
        field_name: The field that caused the error, if applicable.
    """

    def __init__(
        self,
        message: str,
        field_name: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if field_name:
            ctx["field_name"] = field_name
        super().__init__(message, ctx)
        self.field_name = field_name
        self.code = ErrorCode.SCHEMA_INVALID


class GenerationError(CatalystError):
    """Error during data generation.

    Attributes:
        field_name: The field that failed to generate.
        schema_name: The schema being generated.
    """

    def __init__(
        self,
        message: str,
        field_name: str | None = None,
        schema_name: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if field_name:
            ctx["field_name"] = field_name
        if schema_name:
            ctx["schema_name"] = schema_name
        super().__init__(message, ctx)
        self.field_name = field_name
        self.schema_name = schema_name
        self.code = ErrorCode.GENERATION_FAILED


class GeneratorNotFoundError(CatalystError):
    """Generator not registered for a field type.

    Attributes:
        field_type: The field type with no registered generator.
    """

    def __init__(
        self,
        message: str,
        field_type: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx["field_type"] = field_type
        super().__init__(message, ctx)
        self.field_type = field_type
        self.code = ErrorCode.GENERATOR_NOT_FOUND


class SinkError(CatalystError):
    """Error sending data to a sink target.

    Attributes:
        sink_type: The type of sink that failed.
        records_sent: Number of records successfully sent before failure.
    """

    def __init__(
        self,
        message: str,
        sink_type: str | None = None,
        records_sent: int = 0,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if sink_type:
            ctx["sink_type"] = sink_type
        ctx["records_sent"] = records_sent
        super().__init__(message, ctx)
        self.sink_type = sink_type
        self.records_sent = records_sent
        self.code = ErrorCode.SINK_ERROR


class RecipeError(CatalystError):
    """Error in recipe definition or execution.

    Attributes:
        recipe_name: The recipe that caused the error.
        path: File path of the recipe, if applicable.
    """

    def __init__(
        self,
        message: str,
        recipe_name: str | None = None,
        path: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if recipe_name:
            ctx["recipe_name"] = recipe_name
        if path:
            ctx["path"] = path
        super().__init__(message, ctx)
        self.recipe_name = recipe_name
        self.path = path
        self.code = ErrorCode.RECIPE_INVALID


class InferenceError(CatalystError):
    """Error during schema inference from data.

    Attributes:
        source_type: Type of data source (csv, json, parquet, etc.).
    """

    def __init__(
        self,
        message: str,
        source_type: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if source_type:
            ctx["source_type"] = source_type
        super().__init__(message, ctx)
        self.source_type = source_type
        self.code = ErrorCode.INFERENCE_FAILED


class ConfigError(CatalystError):
    """Error in PyCatalyst configuration.

    Attributes:
        path: Config file path, if applicable.
    """

    def __init__(
        self,
        message: str,
        path: str | None = None,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        if path:
            ctx["path"] = path
        super().__init__(message, ctx)
        self.path = path
        self.code = ErrorCode.CONFIG


class ConstraintViolationError(CatalystError):
    """Generated value violated a field constraint.

    Attributes:
        field_name: The field with the violated constraint.
        constraint: Description of the violated constraint.
    """

    def __init__(
        self,
        message: str,
        field_name: str,
        constraint: str,
        context: dict[str, Any] | None = None,
    ) -> None:
        ctx = context or {}
        ctx.update({"field_name": field_name, "constraint": constraint})
        super().__init__(message, ctx)
        self.field_name = field_name
        self.constraint = constraint
        self.code = ErrorCode.CONSTRAINT_VIOLATION
