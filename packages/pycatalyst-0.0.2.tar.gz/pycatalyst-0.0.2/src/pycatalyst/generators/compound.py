"""Compound generators for nested object and array field types.

These generators delegate to the GeneratorRegistry for child field
generation, supporting arbitrary nesting depth.
"""

from __future__ import annotations

from random import Random
from typing import TYPE_CHECKING, Any

from pycatalyst._types import FieldSpec

if TYPE_CHECKING:
    from pycatalyst.generators.registry import GeneratorRegistry


class ObjectGenerator:
    """Generates nested object values by delegating to child generators.

    Attributes:
        registry: The generator registry for resolving child types.
    """

    def __init__(self, registry: GeneratorRegistry) -> None:
        self._registry = registry

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate a nested object from child field specs.

        Args:
            spec: Field specification with children describing the object.
            rng: Random number generator.

        Returns:
            A dict with generated values for each child field.
        """
        result: dict[str, Any] = {}
        for child in spec.children:
            # Handle nullable children
            if child.nullable and rng.random() < child.nullable_rate:
                result[child.name] = None
                continue

            gen = self._registry.get(child.type)
            result[child.name] = gen.generate(child, rng)
        return result


class ArrayGenerator:
    """Generates array values with items of a specified type.

    The first child spec defines the item type. Array length is
    controlled by constraints.min_items / constraints.max_items.

    Attributes:
        registry: The generator registry for resolving item types.
    """

    _DEFAULT_MIN_ITEMS = 1
    _DEFAULT_MAX_ITEMS = 5

    def __init__(self, registry: GeneratorRegistry) -> None:
        self._registry = registry

    def generate(self, spec: FieldSpec, rng: Random) -> Any:
        """Generate an array of values.

        Args:
            spec: Field specification with children[0] as item type.
            rng: Random number generator.

        Returns:
            A list of generated values.
        """
        item_spec = spec.children[0]
        gen = self._registry.get(item_spec.type)

        c = spec.constraints
        min_items = (
            c.min_items if c and c.min_items is not None else self._DEFAULT_MIN_ITEMS
        )
        max_items = (
            c.max_items if c and c.max_items is not None else self._DEFAULT_MAX_ITEMS
        )

        count = rng.randint(min_items, max_items)
        return [gen.generate(item_spec, rng) for _ in range(count)]
