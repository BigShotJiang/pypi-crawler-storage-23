"""Generator registry for mapping field types to generators.

Provides a central registry for looking up the appropriate generator
for each FieldType. Users can register custom generators to extend
or override built-in behavior.
"""

from __future__ import annotations

import logging

from pycatalyst._protocols import Generator
from pycatalyst._types import FieldType
from pycatalyst.errors import GeneratorNotFoundError

logger = logging.getLogger(__name__)


class GeneratorRegistry:
    """Registry mapping FieldType to Generator implementations.

    Provides lookup, registration, and override of generators
    by field type. Built-in generators are registered at construction
    via the ``default()`` class method.
    """

    def __init__(self) -> None:
        self._generators: dict[FieldType, Generator] = {}

    def register(self, field_type: FieldType, generator: Generator) -> None:
        """Register a generator for a field type.

        Args:
            field_type: The field type this generator handles.
            generator: The generator implementation.
        """
        if field_type in self._generators:
            logger.info("overriding generator for %s", field_type.value)
        self._generators[field_type] = generator

    def get(self, field_type: FieldType) -> Generator:
        """Get the generator for a field type.

        Args:
            field_type: The field type to look up.

        Returns:
            The registered generator.

        Raises:
            GeneratorNotFoundError: If no generator is registered.
        """
        gen = self._generators.get(field_type)
        if gen is None:
            raise GeneratorNotFoundError(
                f"No generator registered for field type '{field_type.value}'",
                field_type=field_type.value,
            )
        return gen

    def has(self, field_type: FieldType) -> bool:
        """Check if a generator is registered for the given type."""
        return field_type in self._generators

    def unregister(self, field_type: FieldType) -> None:
        """Remove a generator registration.

        Args:
            field_type: The field type to unregister.
        """
        self._generators.pop(field_type, None)

    @property
    def registered_types(self) -> list[FieldType]:
        """List of field types with registered generators."""
        return list(self._generators.keys())

    @classmethod
    def default(cls) -> GeneratorRegistry:
        """Create a registry with all built-in generators.

        Returns:
            A new registry with scalar and compound generators registered.
        """
        # Lazy import to avoid circular dependencies
        from pycatalyst.generators.compound import (
            ArrayGenerator,
            ObjectGenerator,
        )
        from pycatalyst.generators.scalar import (
            BoolGenerator,
            DateGenerator,
            DateTimeGenerator,
            EnumGenerator,
            FloatGenerator,
            IntGenerator,
            StringGenerator,
            UUIDGenerator,
        )

        registry = cls()

        registry.register(FieldType.STRING, StringGenerator())
        registry.register(FieldType.INT, IntGenerator())
        registry.register(FieldType.FLOAT, FloatGenerator())
        registry.register(FieldType.BOOL, BoolGenerator())
        registry.register(FieldType.DATE, DateGenerator())
        registry.register(FieldType.DATETIME, DateTimeGenerator())
        registry.register(FieldType.UUID, UUIDGenerator())
        registry.register(FieldType.ENUM, EnumGenerator())
        registry.register(FieldType.OBJECT, ObjectGenerator(registry))
        registry.register(FieldType.ARRAY, ArrayGenerator(registry))

        return registry
