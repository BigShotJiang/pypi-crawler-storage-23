"""Shared test fixtures for pycatalyst."""

from __future__ import annotations

import pytest

from pycatalyst._types import (
    FieldConstraints,
    FieldSpec,
    FieldType,
    SchemaSpec,
)


@pytest.fixture()
def simple_string_field() -> FieldSpec:
    """A basic string field spec."""
    return FieldSpec(name="name", type=FieldType.STRING)


@pytest.fixture()
def simple_int_field() -> FieldSpec:
    """A basic integer field spec with constraints."""
    return FieldSpec(
        name="age",
        type=FieldType.INT,
        constraints=FieldConstraints(min=0, max=150),
    )


@pytest.fixture()
def enum_field() -> FieldSpec:
    """An enum field spec with choices."""
    return FieldSpec(
        name="status",
        type=FieldType.ENUM,
        constraints=FieldConstraints(choices=("active", "inactive", "pending")),
    )


@pytest.fixture()
def simple_schema(
    simple_string_field: FieldSpec, simple_int_field: FieldSpec
) -> SchemaSpec:
    """A simple schema with string and int fields."""
    return SchemaSpec(
        name="test_schema",
        fields=(simple_string_field, simple_int_field),
        description="A simple test schema",
    )


@pytest.fixture()
def order_schema() -> SchemaSpec:
    """A realistic order schema for testing."""
    return SchemaSpec(
        name="orders",
        fields=(
            FieldSpec(name="order_id", type=FieldType.UUID),
            FieldSpec(
                name="symbol",
                type=FieldType.ENUM,
                constraints=FieldConstraints(choices=("AAPL", "GOOGL", "MSFT", "AMZN")),
            ),
            FieldSpec(
                name="quantity",
                type=FieldType.INT,
                constraints=FieldConstraints(min=1, max=10000),
            ),
            FieldSpec(
                name="price",
                type=FieldType.FLOAT,
                constraints=FieldConstraints(min=1.0, max=5000.0, precision=2),
            ),
            FieldSpec(
                name="side",
                type=FieldType.ENUM,
                constraints=FieldConstraints(choices=("buy", "sell")),
            ),
            FieldSpec(name="timestamp", type=FieldType.DATETIME),
        ),
        description="Order records for testing",
    )
