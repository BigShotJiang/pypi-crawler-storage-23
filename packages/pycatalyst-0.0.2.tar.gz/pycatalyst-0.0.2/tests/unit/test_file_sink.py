"""Tests for pycatalyst.sinks.file module."""

from __future__ import annotations

import csv
import json
from pathlib import Path

import pytest
import yaml

from pycatalyst._protocols import Sink
from pycatalyst.errors import SinkError
from pycatalyst.sinks.file import FileSink


class TestFileSink:
    """Tests for FileSink."""

    def test_satisfies_sink_protocol(self, tmp_path: Path) -> None:
        sink = FileSink(tmp_path / "out.json")
        assert isinstance(sink, Sink)

    def test_json_output(self, tmp_path: Path) -> None:
        path = tmp_path / "out.json"
        sink = FileSink(path)
        records = [{"id": 1, "name": "a"}, {"id": 2, "name": "b"}]
        result = sink.send(records, {})

        assert result.success is True
        assert result.records_sent == 2

        data = json.loads(path.read_text())
        assert len(data) == 2
        assert data[0]["id"] == 1

    def test_csv_output(self, tmp_path: Path) -> None:
        path = tmp_path / "out.csv"
        sink = FileSink(path)
        records = [{"id": 1, "name": "a"}, {"id": 2, "name": "b"}]
        result = sink.send(records, {})

        assert result.success is True

        with path.open(encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        assert len(rows) == 2
        assert rows[0]["id"] == "1"  # CSV reads as strings

    def test_yaml_output(self, tmp_path: Path) -> None:
        path = tmp_path / "out.yaml"
        sink = FileSink(path)
        records = [{"id": 1, "name": "a"}]
        result = sink.send(records, {})

        assert result.success is True

        data = yaml.safe_load(path.read_text())
        assert len(data) == 1
        assert data[0]["id"] == 1

    def test_yml_extension(self, tmp_path: Path) -> None:
        path = tmp_path / "out.yml"
        sink = FileSink(path)
        sink.send([{"x": 1}], {})
        data = yaml.safe_load(path.read_text())
        assert data[0]["x"] == 1

    def test_explicit_format(self, tmp_path: Path) -> None:
        path = tmp_path / "data.txt"
        sink = FileSink(path, format="json")
        sink.send([{"x": 1}], {})
        data = json.loads(path.read_text())
        assert data[0]["x"] == 1

    def test_unsupported_format(self, tmp_path: Path) -> None:
        with pytest.raises(SinkError, match="Unsupported"):
            FileSink(tmp_path / "out.parquet")

    def test_creates_parent_dirs(self, tmp_path: Path) -> None:
        path = tmp_path / "sub" / "dir" / "out.json"
        sink = FileSink(path)
        sink.send([{"x": 1}], {})
        assert path.exists()

    def test_json_append(self, tmp_path: Path) -> None:
        path = tmp_path / "out.json"
        sink = FileSink(path, append=True)
        sink.send([{"x": 1}], {})
        sink.send([{"x": 2}], {})
        data = json.loads(path.read_text())
        assert len(data) == 2

    def test_csv_append(self, tmp_path: Path) -> None:
        path = tmp_path / "out.csv"
        sink = FileSink(path, append=True)
        sink.send([{"x": 1}], {})
        sink.send([{"x": 2}], {})
        with path.open(encoding="utf-8") as f:
            reader = csv.DictReader(f)
            rows = list(reader)
        assert len(rows) == 2

    def test_metadata_in_result(self, tmp_path: Path) -> None:
        path = tmp_path / "out.json"
        sink = FileSink(path)
        result = sink.send([{"x": 1}], {})
        assert result.metadata["path"] == str(path)
        assert result.metadata["format"] == "json"

    def test_close_is_noop(self, tmp_path: Path) -> None:
        sink = FileSink(tmp_path / "out.json")
        sink.close()  # Should not raise
