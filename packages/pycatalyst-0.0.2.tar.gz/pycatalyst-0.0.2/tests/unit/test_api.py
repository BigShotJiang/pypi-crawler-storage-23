"""Tests for pycatalyst.api module."""

from __future__ import annotations

from typing import Any

import pytest
from fastapi.testclient import TestClient

from pycatalyst.api.main import create_application


@pytest.fixture()
def client() -> TestClient:
    """Create a test client for the API."""
    app = create_application()
    return TestClient(app, raise_server_exceptions=False)


class TestHealthEndpoint:
    """Tests for GET /health."""

    def test_health_returns_ok(self, client: TestClient) -> None:
        response = client.get("/health")
        assert response.status_code == 200
        data = response.json()
        assert data["status"] == "ok"
        assert "version" in data


class TestGenerateEndpoint:
    """Tests for POST /api/v1/generate."""

    def test_generate_basic(self, client: TestClient) -> None:
        payload = {
            "name": "test",
            "fields": [
                {"name": "id", "type": "uuid"},
                {"name": "value", "type": "int"},
            ],
            "count": 5,
        }
        response = client.post("/api/v1/generate", json=payload)
        assert response.status_code == 200
        data = response.json()
        assert data["count"] == 5
        assert len(data["records"]) == 5
        assert data["schema_name"] == "test"
        assert "duration_ms" in data

    def test_generate_with_seed_reproducible(self, client: TestClient) -> None:
        payload = {
            "name": "seeded",
            "fields": [{"name": "x", "type": "int"}],
            "count": 3,
            "seed": 42,
        }
        r1 = client.post("/api/v1/generate", json=payload)
        r2 = client.post("/api/v1/generate", json=payload)
        assert r1.json()["records"] == r2.json()["records"]
        assert r1.json()["seed"] == 42

    def test_generate_with_constraints(self, client: TestClient) -> None:
        payload = {
            "fields": [
                {
                    "name": "score",
                    "type": "float",
                    "constraints": {"min": 0.0, "max": 1.0},
                },
            ],
            "count": 10,
        }
        response = client.post("/api/v1/generate", json=payload)
        assert response.status_code == 200
        records = response.json()["records"]
        for record in records:
            assert 0.0 <= record["score"] <= 1.0

    def test_generate_with_enum(self, client: TestClient) -> None:
        payload = {
            "fields": [
                {
                    "name": "color",
                    "type": "enum",
                    "constraints": {"choices": ["red", "green", "blue"]},
                },
            ],
            "count": 20,
        }
        response = client.post("/api/v1/generate", json=payload)
        assert response.status_code == 200
        records = response.json()["records"]
        for record in records:
            assert record["color"] in ("red", "green", "blue")

    def test_generate_missing_fields_returns_422(self, client: TestClient) -> None:
        response = client.post("/api/v1/generate", json={"name": "test"})
        assert response.status_code == 422

    def test_generate_invalid_field_type_returns_400(self, client: TestClient) -> None:
        payload = {
            "fields": [{"name": "x", "type": "nonexistent_type"}],
        }
        response = client.post("/api/v1/generate", json=payload)
        assert response.status_code == 400

    def test_generate_count_zero_returns_422(self, client: TestClient) -> None:
        payload = {
            "fields": [{"name": "x", "type": "int"}],
            "count": 0,
        }
        response = client.post("/api/v1/generate", json=payload)
        assert response.status_code == 422

    def test_generate_default_name(self, client: TestClient) -> None:
        payload = {
            "fields": [{"name": "x", "type": "int"}],
            "count": 1,
        }
        response = client.post("/api/v1/generate", json=payload)
        assert response.status_code == 200
        assert response.json()["schema_name"] == "api_request"


class TestInferEndpoint:
    """Tests for POST /api/v1/infer."""

    def test_infer_basic(self, client: TestClient) -> None:
        payload = {
            "records": [
                {"name": "Alice", "age": 30},
                {"name": "Bob", "age": 25},
                {"name": "Carol", "age": 35},
            ],
        }
        response = client.post("/api/v1/infer", json=payload)
        assert response.status_code == 200
        data = response.json()
        assert data["name"] == "inferred"
        assert data["field_count"] == 2
        field_names = {f["name"] for f in data["fields"]}
        assert "name" in field_names
        assert "age" in field_names

    def test_infer_with_custom_name(self, client: TestClient) -> None:
        payload = {
            "records": [{"x": 1}, {"x": 2}],
            "name": "my_schema",
        }
        response = client.post("/api/v1/infer", json=payload)
        assert response.status_code == 200
        assert response.json()["name"] == "my_schema"

    def test_infer_detects_types(self, client: TestClient) -> None:
        payload = {
            "records": [
                {"count": 10, "ratio": 0.5, "active": True},
                {"count": 20, "ratio": 0.7, "active": False},
                {"count": 30, "ratio": 0.9, "active": True},
            ],
        }
        response = client.post("/api/v1/infer", json=payload)
        assert response.status_code == 200
        fields = {f["name"]: f for f in response.json()["fields"]}
        assert fields["count"]["type"] == "int"
        assert fields["ratio"]["type"] == "float"
        assert fields["active"]["type"] == "bool"

    def test_infer_empty_records_returns_422(self, client: TestClient) -> None:
        response = client.post("/api/v1/infer", json={"records": []})
        assert response.status_code == 422

    def test_infer_missing_records_returns_422(self, client: TestClient) -> None:
        response = client.post("/api/v1/infer", json={})
        assert response.status_code == 422


class TestRecipeEndpoint:
    """Tests for POST /api/v1/recipes/run."""

    def _minimal_recipe_payload(self) -> dict[str, Any]:
        """Return a minimal recipe payload."""
        return {
            "name": "api_test",
            "schema": {
                "fields": [
                    {"name": "id", "type": "uuid"},
                    {"name": "value", "type": "int"},
                ],
            },
            "generation": {"count": 5},
        }

    def test_run_recipe(self, client: TestClient) -> None:
        payload = self._minimal_recipe_payload()
        response = client.post("/api/v1/recipes/run", json=payload)
        assert response.status_code == 200
        data = response.json()
        assert data["count"] == 5
        assert len(data["records"]) == 5
        assert data["sink_type"] == "memory"
        assert data["records_sent"] == 5
        assert "duration_ms" in data

    def test_run_recipe_always_uses_memory_sink(self, client: TestClient) -> None:
        payload = self._minimal_recipe_payload()
        payload["sink"] = {"type": "file", "config": {"path": "/tmp/x.json"}}
        response = client.post("/api/v1/recipes/run", json=payload)
        assert response.status_code == 200
        assert response.json()["sink_type"] == "memory"

    def test_run_recipe_missing_schema_returns_422(self, client: TestClient) -> None:
        payload = {"name": "test"}
        response = client.post("/api/v1/recipes/run", json=payload)
        assert response.status_code == 422

    def test_run_recipe_invalid_field_type_returns_400(
        self, client: TestClient
    ) -> None:
        payload = {
            "name": "bad",
            "schema": {
                "fields": [{"name": "x", "type": "unknown_type"}],
            },
        }
        response = client.post("/api/v1/recipes/run", json=payload)
        assert response.status_code == 400

    def test_run_recipe_with_enum_field(self, client: TestClient) -> None:
        payload = {
            "name": "enum_test",
            "schema": {
                "fields": [
                    {
                        "name": "status",
                        "type": "enum",
                        "constraints": {"choices": ["active", "inactive"]},
                    },
                ],
            },
            "generation": {"count": 10},
        }
        response = client.post("/api/v1/recipes/run", json=payload)
        assert response.status_code == 200
        for record in response.json()["records"]:
            assert record["status"] in ("active", "inactive")


class TestRecipeRunnerHttpSink:
    """Tests for HTTP sink integration in recipe runner."""

    def test_http_sink_missing_url_raises(self) -> None:
        from pycatalyst.errors import RecipeError
        from pycatalyst.recipes.runner import RecipeRunner

        data = {
            "name": "test",
            "schema": {
                "fields": [{"name": "x", "type": "int"}],
            },
            "sink": {"type": "http", "config": {}},
        }
        runner = RecipeRunner()
        with pytest.raises(RecipeError, match="requires 'url'"):
            runner.run_dict(data)
