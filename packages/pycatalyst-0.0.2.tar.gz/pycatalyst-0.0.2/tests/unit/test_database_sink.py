"""Tests for pycatalyst.sinks.database module."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any

import pytest

from pycatalyst.errors import SinkError
from pycatalyst.sinks.database import DatabaseSink, _mask_url


def _sample_records(count: int = 3) -> list[dict[str, Any]]:
    """Return sample records for testing."""
    return [{"id": i, "name": f"item_{i}", "value": i * 10} for i in range(count)]


def _create_test_db(tmp_path: Path) -> str:
    """Create a SQLite database with a test table."""
    db_path = tmp_path / "test.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute("CREATE TABLE test_table (  id INTEGER,   name TEXT,   value INTEGER)")
    conn.commit()
    conn.close()
    return f"sqlite:///{db_path}"


class TestDatabaseSink:
    """Tests for DatabaseSink."""

    def test_invalid_if_exists_raises(self) -> None:
        with pytest.raises(SinkError, match="Invalid if_exists"):
            DatabaseSink(
                "sqlite:///test.db",
                "table",
                if_exists="drop",
            )

    def test_send_empty_records(self, tmp_path: Path) -> None:
        url = _create_test_db(tmp_path)
        sink = DatabaseSink(url, "test_table")
        result = sink.send([], {})
        assert result.success is True
        assert result.records_sent == 0
        assert result.sink_type == "database"
        sink.close()

    def test_send_records_to_sqlite(self, tmp_path: Path) -> None:
        url = _create_test_db(tmp_path)
        sink = DatabaseSink(url, "test_table")
        records = _sample_records()

        result = sink.send(records, {"schema": "test"})

        assert result.success is True
        assert result.records_sent == 3
        assert result.sink_type == "database"
        assert result.metadata["table"] == "test_table"

        # Verify data in database
        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        rows = conn.execute("SELECT * FROM test_table").fetchall()
        conn.close()
        assert len(rows) == 3
        assert rows[0] == (0, "item_0", 0)
        assert rows[1] == (1, "item_1", 10)

        sink.close()

    def test_send_with_batching(self, tmp_path: Path) -> None:
        url = _create_test_db(tmp_path)
        sink = DatabaseSink(url, "test_table", batch_size=2)
        records = _sample_records(5)

        result = sink.send(records, {})
        assert result.success is True
        assert result.records_sent == 5

        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        count = conn.execute("SELECT COUNT(*) FROM test_table").fetchone()[0]
        conn.close()
        assert count == 5

        sink.close()

    def test_send_replace_truncates(self, tmp_path: Path) -> None:
        url = _create_test_db(tmp_path)

        # Insert initial data
        sink = DatabaseSink(url, "test_table")
        sink.send(_sample_records(3), {})
        sink.close()

        # Replace with new data
        sink = DatabaseSink(url, "test_table", if_exists="replace")
        sink.send(_sample_records(2), {})

        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        count = conn.execute("SELECT COUNT(*) FROM test_table").fetchone()[0]
        conn.close()
        assert count == 2

        sink.close()

    def test_send_append_adds_rows(self, tmp_path: Path) -> None:
        url = _create_test_db(tmp_path)

        sink = DatabaseSink(url, "test_table")
        sink.send(_sample_records(3), {})
        sink.send(_sample_records(2), {})

        db_path = tmp_path / "test.db"
        conn = sqlite3.connect(str(db_path))
        count = conn.execute("SELECT COUNT(*) FROM test_table").fetchone()[0]
        conn.close()
        assert count == 5

        sink.close()

    def test_send_nonexistent_table_fails(self, tmp_path: Path) -> None:
        url = _create_test_db(tmp_path)
        sink = DatabaseSink(url, "nonexistent_table")

        result = sink.send(_sample_records(), {})
        assert result.success is False
        assert len(result.errors) == 1
        sink.close()

    def test_close_disposes_engine(self, tmp_path: Path) -> None:
        url = _create_test_db(tmp_path)
        sink = DatabaseSink(url, "test_table")
        sink.send(_sample_records(1), {})
        assert sink._engine is not None
        sink.close()
        assert sink._engine is None

    def test_close_noop_when_no_engine(self) -> None:
        sink = DatabaseSink("sqlite:///test.db", "table")
        sink.close()  # Should not raise

    def test_split_batches(self, tmp_path: Path) -> None:
        url = _create_test_db(tmp_path)
        sink = DatabaseSink(url, "test_table", batch_size=3)
        records = _sample_records(7)
        batches = sink._split_batches(records)
        assert len(batches) == 3
        assert len(batches[0]) == 3
        assert len(batches[1]) == 3
        assert len(batches[2]) == 1
        sink.close()


class TestMaskUrl:
    """Tests for _mask_url helper."""

    def test_masks_password(self) -> None:
        assert (
            _mask_url("postgresql://user:secret@host/db")
            == "postgresql://user:***@host/db"
        )

    def test_no_password_unchanged(self) -> None:
        assert _mask_url("sqlite:///test.db") == "sqlite:///test.db"

    def test_no_at_sign_unchanged(self) -> None:
        assert _mask_url("sqlite:///test.db") == "sqlite:///test.db"


class TestRecipeRunnerDatabaseSink:
    """Tests for database sink integration in recipe runner."""

    def test_database_sink_missing_connection_url(self) -> None:
        from pycatalyst.errors import RecipeError
        from pycatalyst.recipes.runner import RecipeRunner

        data = {
            "name": "test",
            "schema": {"fields": [{"name": "x", "type": "int"}]},
            "sink": {"type": "database", "config": {"table_name": "t"}},
        }
        runner = RecipeRunner()
        with pytest.raises(RecipeError, match="connection_url"):
            runner.run_dict(data)

    def test_database_sink_missing_table_name(self) -> None:
        from pycatalyst.errors import RecipeError
        from pycatalyst.recipes.runner import RecipeRunner

        data = {
            "name": "test",
            "schema": {"fields": [{"name": "x", "type": "int"}]},
            "sink": {
                "type": "database",
                "config": {"connection_url": "sqlite:///x.db"},
            },
        }
        runner = RecipeRunner()
        with pytest.raises(RecipeError, match="table_name"):
            runner.run_dict(data)

    def test_database_sink_end_to_end(self, tmp_path: Path) -> None:
        from pycatalyst.recipes.runner import RecipeRunner

        db_path = tmp_path / "recipe_test.db"
        conn = sqlite3.connect(str(db_path))
        conn.execute("CREATE TABLE gen_data (x INTEGER)")
        conn.commit()
        conn.close()

        data = {
            "name": "db_test",
            "schema": {"fields": [{"name": "x", "type": "int"}]},
            "generation": {"count": 5, "seed": 42},
            "sink": {
                "type": "database",
                "config": {
                    "connection_url": f"sqlite:///{db_path}",
                    "table_name": "gen_data",
                },
            },
        }
        runner = RecipeRunner()
        gen_result, sink_result = runner.run_dict(data)
        assert gen_result.count == 5
        assert sink_result.success is True
        assert sink_result.records_sent == 5

        conn = sqlite3.connect(str(db_path))
        count = conn.execute("SELECT COUNT(*) FROM gen_data").fetchone()[0]
        conn.close()
        assert count == 5
