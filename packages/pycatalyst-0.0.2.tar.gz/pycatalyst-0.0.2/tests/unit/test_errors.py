"""Tests for pycatalyst.errors module."""

from __future__ import annotations

import pytest

from pycatalyst.errors import (
    CatalystError,
    ConfigError,
    ConstraintViolationError,
    ErrorCode,
    GenerationError,
    GeneratorNotFoundError,
    InferenceError,
    RecipeError,
    SchemaError,
    SinkError,
)


class TestErrorCode:
    """Tests for ErrorCode enum."""

    def test_all_codes_are_strings(self) -> None:
        for code in ErrorCode:
            assert isinstance(code.value, str)

    def test_expected_codes_exist(self) -> None:
        assert ErrorCode.SCHEMA_INVALID == "schema_invalid"
        assert ErrorCode.GENERATION_FAILED == "generation_failed"
        assert ErrorCode.SINK_ERROR == "sink_error"
        assert ErrorCode.RECIPE_INVALID == "recipe_invalid"
        assert ErrorCode.INFERENCE_FAILED == "inference_failed"
        assert ErrorCode.CONFIG == "config"
        assert ErrorCode.GENERATOR_NOT_FOUND == "generator_not_found"
        assert ErrorCode.CONSTRAINT_VIOLATION == "constraint_violation"


class TestCatalystError:
    """Tests for the base CatalystError exception."""

    def test_basic_creation(self) -> None:
        err = CatalystError("something failed")
        assert err.message == "something failed"
        assert err.context == {}
        assert err.code is None
        assert str(err) == "something failed"

    def test_with_context(self) -> None:
        err = CatalystError("failed", {"key": "value"})
        assert err.context == {"key": "value"}
        assert "key='value'" in str(err)

    def test_with_code(self) -> None:
        err = CatalystError("failed", code=ErrorCode.CONFIG)
        assert err.code == ErrorCode.CONFIG

    def test_to_dict(self) -> None:
        err = CatalystError("test error", {"detail": 42}, code=ErrorCode.CONFIG)
        d = err.to_dict()
        assert d["type"] == "CatalystError"
        assert d["message"] == "test error"
        assert d["code"] == "config"
        assert d["context"] == {"detail": 42}

    def test_to_dict_no_code(self) -> None:
        err = CatalystError("no code")
        assert err.to_dict()["code"] is None

    def test_is_exception(self) -> None:
        err = CatalystError("test")
        assert isinstance(err, Exception)

    def test_all_subclasses_inherit(self) -> None:
        subclasses = [
            SchemaError,
            GenerationError,
            GeneratorNotFoundError,
            SinkError,
            RecipeError,
            InferenceError,
            ConfigError,
            ConstraintViolationError,
        ]
        for cls in subclasses:
            assert issubclass(cls, CatalystError)


class TestSchemaError:
    """Tests for SchemaError."""

    def test_with_field_name(self) -> None:
        err = SchemaError("invalid type", field_name="age")
        assert err.field_name == "age"
        assert err.context["field_name"] == "age"
        assert err.code == ErrorCode.SCHEMA_INVALID

    def test_without_field_name(self) -> None:
        err = SchemaError("missing fields")
        assert err.field_name is None
        assert "field_name" not in err.context


class TestGenerationError:
    """Tests for GenerationError."""

    def test_with_details(self) -> None:
        err = GenerationError("overflow", field_name="price", schema_name="orders")
        assert err.field_name == "price"
        assert err.schema_name == "orders"
        assert err.context["field_name"] == "price"
        assert err.context["schema_name"] == "orders"
        assert err.code == ErrorCode.GENERATION_FAILED

    def test_minimal(self) -> None:
        err = GenerationError("failed")
        assert err.field_name is None
        assert err.schema_name is None


class TestGeneratorNotFoundError:
    """Tests for GeneratorNotFoundError."""

    def test_creation(self) -> None:
        err = GeneratorNotFoundError(
            "no generator for custom_type", field_type="custom_type"
        )
        assert err.field_type == "custom_type"
        assert err.context["field_type"] == "custom_type"
        assert err.code == ErrorCode.GENERATOR_NOT_FOUND


class TestSinkError:
    """Tests for SinkError."""

    def test_with_details(self) -> None:
        err = SinkError(
            "connection refused",
            sink_type="http",
            records_sent=42,
        )
        assert err.sink_type == "http"
        assert err.records_sent == 42
        assert err.context["sink_type"] == "http"
        assert err.context["records_sent"] == 42
        assert err.code == ErrorCode.SINK_ERROR

    def test_defaults(self) -> None:
        err = SinkError("failed")
        assert err.sink_type is None
        assert err.records_sent == 0


class TestRecipeError:
    """Tests for RecipeError."""

    def test_with_details(self) -> None:
        err = RecipeError(
            "invalid schema section",
            recipe_name="test_orders",
            path="/recipes/orders.yaml",
        )
        assert err.recipe_name == "test_orders"
        assert err.path == "/recipes/orders.yaml"
        assert err.code == ErrorCode.RECIPE_INVALID


class TestInferenceError:
    """Tests for InferenceError."""

    def test_with_source_type(self) -> None:
        err = InferenceError("cannot parse", source_type="csv")
        assert err.source_type == "csv"
        assert err.context["source_type"] == "csv"
        assert err.code == ErrorCode.INFERENCE_FAILED


class TestConfigError:
    """Tests for ConfigError."""

    def test_with_path(self) -> None:
        err = ConfigError("missing key", path="/etc/pycatalyst.yaml")
        assert err.path == "/etc/pycatalyst.yaml"
        assert err.context["path"] == "/etc/pycatalyst.yaml"
        assert err.code == ErrorCode.CONFIG


class TestConstraintViolationError:
    """Tests for ConstraintViolationError."""

    def test_creation(self) -> None:
        err = ConstraintViolationError(
            "value out of range",
            field_name="age",
            constraint="min=0, max=150",
        )
        assert err.field_name == "age"
        assert err.constraint == "min=0, max=150"
        assert err.context["field_name"] == "age"
        assert err.context["constraint"] == "min=0, max=150"
        assert err.code == ErrorCode.CONSTRAINT_VIOLATION


class TestExceptionCatchAll:
    """Test that CatalystError can catch all domain errors."""

    def test_catch_all(self) -> None:
        errors = [
            SchemaError("a"),
            GenerationError("b"),
            SinkError("c"),
            RecipeError("d"),
            InferenceError("e"),
            ConfigError("f"),
            GeneratorNotFoundError("g", field_type="x"),
            ConstraintViolationError("h", field_name="y", constraint="z"),
        ]
        for err in errors:
            with pytest.raises(CatalystError):
                raise err
