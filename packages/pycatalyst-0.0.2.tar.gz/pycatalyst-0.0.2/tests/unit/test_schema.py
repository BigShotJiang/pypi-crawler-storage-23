"""Tests for pycatalyst.schema module."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
from pydantic import BaseModel, Field

from pycatalyst._types import FieldType
from pycatalyst.errors import InferenceError, SchemaError
from pycatalyst.schema.inferrer import infer_from_file, infer_from_records
from pycatalyst.schema.json_schema import from_json_schema
from pycatalyst.schema.pydantic import from_pydantic_model
from pycatalyst.schema.spec import SchemaBuilder


class TestSchemaBuilder:
    """Tests for SchemaBuilder fluent API."""

    def test_basic_build(self) -> None:
        schema = (
            SchemaBuilder("test")
            .add_uuid("id")
            .add_string("name")
            .add_int("age")
            .build()
        )
        assert schema.name == "test"
        assert len(schema.fields) == 3
        assert schema.field_names == ("id", "name", "age")

    def test_all_field_types(self) -> None:
        schema = (
            SchemaBuilder("full", description="All types")
            .add_string("s", min_len=1, max_len=100)
            .add_int("i", min_val=0, max_val=999)
            .add_float("f", min_val=0.0, max_val=1.0, precision=4)
            .add_bool("b")
            .add_date("d")
            .add_datetime("dt")
            .add_uuid("u")
            .add_enum("e", choices=["a", "b"])
            .build()
        )
        assert len(schema.fields) == 8
        types = [f.type for f in schema.fields]
        assert FieldType.STRING in types
        assert FieldType.INT in types
        assert FieldType.FLOAT in types
        assert FieldType.BOOL in types
        assert FieldType.DATE in types
        assert FieldType.DATETIME in types
        assert FieldType.UUID in types
        assert FieldType.ENUM in types

    def test_nullable(self) -> None:
        schema = SchemaBuilder("test").add_string("name", nullable=True).build()
        assert schema.fields[0].nullable is True

    def test_constraints_on_string(self) -> None:
        schema = (
            SchemaBuilder("test")
            .add_string("code", min_len=3, max_len=10, pattern=r"[A-Z]+")
            .build()
        )
        f = schema.fields[0]
        assert f.constraints is not None
        assert f.constraints.min == 3
        assert f.constraints.max == 10
        assert f.constraints.pattern == r"[A-Z]+"

    def test_metadata(self) -> None:
        schema = (
            SchemaBuilder("test").add_int("x").with_metadata("version", "1.0").build()
        )
        assert schema.metadata["version"] == "1.0"

    def test_add_field(self) -> None:
        from pycatalyst._types import FieldSpec, FieldType

        spec = FieldSpec(name="custom", type=FieldType.UUID)
        schema = SchemaBuilder("test").add_field(spec).build()
        assert schema.fields[0].name == "custom"


class TestFromJsonSchema:
    """Tests for JSON Schema to SchemaSpec conversion."""

    def test_basic_conversion(self) -> None:
        json_schema = {
            "type": "object",
            "title": "Order",
            "properties": {
                "id": {"type": "integer"},
                "name": {"type": "string"},
                "active": {"type": "boolean"},
            },
            "required": ["id", "name"],
        }
        schema = from_json_schema(json_schema)
        assert schema.name == "Order"
        assert len(schema.fields) == 3

        id_field = schema.get_field("id")
        assert id_field is not None
        assert id_field.type == FieldType.INT
        assert id_field.nullable is False

        active_field = schema.get_field("active")
        assert active_field is not None
        assert active_field.nullable is True  # not in required

    def test_string_formats(self) -> None:
        json_schema = {
            "type": "object",
            "properties": {
                "created": {"type": "string", "format": "date-time"},
                "birthday": {"type": "string", "format": "date"},
                "ref": {"type": "string", "format": "uuid"},
            },
        }
        schema = from_json_schema(json_schema, name="formats")
        assert schema.get_field("created").type == FieldType.DATETIME
        assert schema.get_field("birthday").type == FieldType.DATE
        assert schema.get_field("ref").type == FieldType.UUID

    def test_numeric_constraints(self) -> None:
        json_schema = {
            "type": "object",
            "properties": {
                "age": {"type": "integer", "minimum": 0, "maximum": 150},
                "price": {"type": "number", "minimum": 0.01},
            },
        }
        schema = from_json_schema(json_schema, name="constrained")
        age = schema.get_field("age")
        assert age.constraints is not None
        assert age.constraints.min == 0
        assert age.constraints.max == 150

    def test_enum_property(self) -> None:
        json_schema = {
            "type": "object",
            "properties": {
                "status": {"enum": ["active", "inactive"]},
            },
        }
        schema = from_json_schema(json_schema, name="enums")
        status = schema.get_field("status")
        assert status.type == FieldType.ENUM
        assert status.constraints.choices == ("active", "inactive")

    def test_nested_object(self) -> None:
        json_schema = {
            "type": "object",
            "properties": {
                "address": {
                    "type": "object",
                    "properties": {
                        "street": {"type": "string"},
                        "zip": {"type": "string"},
                    },
                },
            },
        }
        schema = from_json_schema(json_schema, name="nested")
        addr = schema.get_field("address")
        assert addr.type == FieldType.OBJECT
        assert len(addr.children) == 2

    def test_array_property(self) -> None:
        json_schema = {
            "type": "object",
            "properties": {
                "tags": {
                    "type": "array",
                    "items": {"type": "string"},
                    "minItems": 1,
                    "maxItems": 5,
                },
            },
        }
        schema = from_json_schema(json_schema, name="arrays")
        tags = schema.get_field("tags")
        assert tags.type == FieldType.ARRAY
        assert len(tags.children) == 1
        assert tags.constraints.min_items == 1
        assert tags.constraints.max_items == 5

    def test_non_object_root_raises(self) -> None:
        with pytest.raises(SchemaError, match="must be type 'object'"):
            from_json_schema({"type": "array"})

    def test_no_properties_raises(self) -> None:
        with pytest.raises(SchemaError, match="no properties"):
            from_json_schema({"type": "object"})

    def test_name_override(self) -> None:
        schema = from_json_schema(
            {
                "type": "object",
                "title": "Original",
                "properties": {"x": {"type": "string"}},
            },
            name="custom",
        )
        assert schema.name == "custom"


class TestFromPydanticModel:
    """Tests for Pydantic model to SchemaSpec conversion."""

    def test_basic_model(self) -> None:
        class Order(BaseModel):
            order_id: int
            name: str
            active: bool = True

        schema = from_pydantic_model(Order)
        assert schema.name == "Order"
        assert len(schema.fields) >= 3
        assert schema.get_field("order_id") is not None
        assert schema.get_field("name") is not None

    def test_model_with_constraints(self) -> None:
        class Product(BaseModel):
            name: str = Field(..., min_length=1, max_length=100)
            price: float = Field(..., ge=0, le=99999)

        schema = from_pydantic_model(Product)
        assert schema.name == "Product"

    def test_name_override(self) -> None:
        class Foo(BaseModel):
            x: int

        schema = from_pydantic_model(Foo, name="custom")
        assert schema.name == "custom"

    def test_non_basemodel_raises(self) -> None:
        with pytest.raises(SchemaError, match="Pydantic BaseModel"):
            from_pydantic_model(dict)  # type: ignore[arg-type]


class TestInferFromRecords:
    """Tests for schema inference from records."""

    def test_basic_inference(self) -> None:
        records = [
            {"name": "Alice", "age": 30, "score": 95.5},
            {"name": "Bob", "age": 25, "score": 88.0},
        ]
        schema = infer_from_records(records)
        assert schema.name == "inferred"
        assert len(schema.fields) == 3

        name_f = schema.get_field("name")
        assert name_f.type == FieldType.STRING

        age_f = schema.get_field("age")
        assert age_f.type == FieldType.INT

        score_f = schema.get_field("score")
        assert score_f.type == FieldType.FLOAT

    def test_nullable_detection(self) -> None:
        records = [
            {"x": 1, "y": "a"},
            {"x": None, "y": "b"},
            {"x": 3, "y": None},
        ]
        schema = infer_from_records(records)
        x_f = schema.get_field("x")
        assert x_f.nullable is True

    def test_uuid_detection(self) -> None:
        records = [
            {"id": "550e8400-e29b-41d4-a716-446655440000"},
            {"id": "6ba7b810-9dad-11d1-80b4-00c04fd430c8"},
        ]
        schema = infer_from_records(records)
        assert schema.get_field("id").type == FieldType.UUID

    def test_date_detection(self) -> None:
        records = [
            {"dt": "2024-01-15"},
            {"dt": "2024-06-20"},
        ]
        schema = infer_from_records(records)
        assert schema.get_field("dt").type == FieldType.DATE

    def test_datetime_detection(self) -> None:
        records = [
            {"ts": "2024-01-15T10:30:00Z"},
            {"ts": "2024-06-20T14:00:00Z"},
        ]
        schema = infer_from_records(records)
        assert schema.get_field("ts").type == FieldType.DATETIME

    def test_enum_detection(self) -> None:
        records = [{"status": "active"}] * 20 + [{"status": "inactive"}] * 10
        schema = infer_from_records(records)
        assert schema.get_field("status").type == FieldType.ENUM

    def test_bool_detection(self) -> None:
        records = [{"flag": True}, {"flag": False}, {"flag": True}]
        schema = infer_from_records(records)
        assert schema.get_field("flag").type == FieldType.BOOL

    def test_int_constraints(self) -> None:
        records = [{"val": i} for i in range(10, 51)]
        schema = infer_from_records(records)
        f = schema.get_field("val")
        assert f.constraints is not None
        assert f.constraints.min == 10
        assert f.constraints.max == 50

    def test_empty_records_raises(self) -> None:
        with pytest.raises(InferenceError, match="empty"):
            infer_from_records([])

    def test_non_dict_record_raises(self) -> None:
        with pytest.raises(InferenceError, match="must be dicts"):
            infer_from_records(["not a dict"])  # type: ignore[list-item]


class TestInferFromFile:
    """Tests for schema inference from files."""

    def test_json_file(self, tmp_path: Path) -> None:
        data = [{"x": 1, "y": "a"}, {"x": 2, "y": "b"}]
        f = tmp_path / "data.json"
        f.write_text(json.dumps(data))

        schema = infer_from_file(f)
        assert schema.name == "data"
        assert len(schema.fields) == 2

    def test_yaml_file(self, tmp_path: Path) -> None:
        import yaml

        data = [{"x": 1, "y": "a"}, {"x": 2, "y": "b"}]
        f = tmp_path / "data.yaml"
        f.write_text(yaml.dump(data))

        schema = infer_from_file(f)
        assert schema.name == "data"

    def test_name_override(self, tmp_path: Path) -> None:
        f = tmp_path / "data.json"
        f.write_text(json.dumps([{"x": 1}]))
        schema = infer_from_file(f, name="custom")
        assert schema.name == "custom"

    def test_file_not_found(self) -> None:
        with pytest.raises(InferenceError, match="File not found"):
            infer_from_file("/nonexistent/file.json")

    def test_unsupported_format(self, tmp_path: Path) -> None:
        f = tmp_path / "data.txt"
        f.write_text("hello")
        with pytest.raises(InferenceError, match="Unsupported file type"):
            infer_from_file(f)

    def test_invalid_json(self, tmp_path: Path) -> None:
        f = tmp_path / "bad.json"
        f.write_text("{not valid json")
        with pytest.raises(InferenceError, match="Invalid JSON"):
            infer_from_file(f)

    def test_non_list_json(self, tmp_path: Path) -> None:
        f = tmp_path / "obj.json"
        f.write_text(json.dumps({"not": "a list"}))
        with pytest.raises(InferenceError, match="must contain"):
            infer_from_file(f)
