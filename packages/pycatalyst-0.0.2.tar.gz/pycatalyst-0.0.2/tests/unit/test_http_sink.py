"""Tests for pycatalyst.sinks.http module."""

from __future__ import annotations

from typing import Any
from unittest.mock import MagicMock, patch

import httpx
import pytest

from pycatalyst.errors import SinkError
from pycatalyst.sinks.http import AsyncHttpSink, HttpSink


def _sample_records(count: int = 3) -> list[dict[str, Any]]:
    """Return sample records for testing."""
    return [{"id": i, "name": f"item_{i}"} for i in range(count)]


class TestHttpSink:
    """Tests for HttpSink."""

    def test_unsupported_method_raises(self) -> None:
        with pytest.raises(SinkError, match="Unsupported HTTP method"):
            HttpSink("http://example.com/api", method="DELETE")

    def test_default_headers_set(self) -> None:
        sink = HttpSink("http://example.com/api")
        assert sink._headers["Content-Type"] == "application/json"

    def test_auth_token_sets_bearer_header(self) -> None:
        sink = HttpSink("http://example.com/api", auth_token="my-secret-token")
        assert sink._headers["Authorization"] == "Bearer my-secret-token"

    def test_custom_headers_preserved(self) -> None:
        sink = HttpSink(
            "http://example.com/api",
            headers={"X-Custom": "value", "Content-Type": "text/plain"},
        )
        assert sink._headers["X-Custom"] == "value"
        assert sink._headers["Content-Type"] == "text/plain"

    def test_send_empty_records(self) -> None:
        sink = HttpSink("http://example.com/api")
        result = sink.send([], {})
        assert result.success is True
        assert result.records_sent == 0
        assert result.sink_type == "http"

    @patch("httpx.Client")
    def test_send_records_success(self, mock_client_cls: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.request.return_value = mock_response
        mock_client_cls.return_value = mock_client

        sink = HttpSink("http://example.com/api")
        records = _sample_records()
        result = sink.send(records, {"schema": "test"})

        assert result.success is True
        assert result.records_sent == 3
        assert result.metadata["url"] == "http://example.com/api"
        assert result.metadata["method"] == "POST"

        mock_client.request.assert_called_once_with(
            "POST",
            "http://example.com/api",
            json=records,
            headers=sink._headers,
        )

    @patch("httpx.Client")
    def test_send_with_batching(self, mock_client_cls: MagicMock) -> None:
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.request.return_value = mock_response
        mock_client_cls.return_value = mock_client

        sink = HttpSink("http://example.com/api", batch_size=2)
        records = _sample_records(5)
        result = sink.send(records, {})

        assert result.success is True
        assert result.records_sent == 5
        # 5 records / batch_size 2 = 3 batches
        assert mock_client.request.call_count == 3

    @patch("httpx.Client")
    def test_send_http_error_partial_failure(self, mock_client_cls: MagicMock) -> None:
        success_response = MagicMock()
        success_response.raise_for_status = MagicMock()

        error_response = MagicMock()
        error_response.status_code = 500
        error_response.text = "Internal Server Error"

        def raise_status() -> None:
            raise httpx.HTTPStatusError(
                "Server Error",
                request=MagicMock(),
                response=error_response,
            )

        error_response.raise_for_status = raise_status

        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.request.side_effect = [
            success_response,
            error_response,
        ]
        mock_client_cls.return_value = mock_client

        sink = HttpSink("http://example.com/api", batch_size=2)
        records = _sample_records(4)
        result = sink.send(records, {})

        assert result.success is False
        assert result.records_sent == 2
        assert len(result.errors) == 1
        assert "500" in result.errors[0]

    @patch("httpx.Client")
    def test_send_request_error(self, mock_client_cls: MagicMock) -> None:
        mock_client = MagicMock()
        mock_client.__enter__ = MagicMock(return_value=mock_client)
        mock_client.__exit__ = MagicMock(return_value=False)
        mock_client.request.side_effect = httpx.ConnectError("Connection refused")
        mock_client_cls.return_value = mock_client

        sink = HttpSink("http://example.com/api")
        result = sink.send(_sample_records(), {})

        assert result.success is False
        assert result.records_sent == 0
        assert len(result.errors) == 1

    def test_close_is_noop(self) -> None:
        sink = HttpSink("http://example.com/api")
        sink.close()  # Should not raise

    def test_split_batches_no_batching(self) -> None:
        sink = HttpSink("http://example.com/api", batch_size=0)
        records = _sample_records(5)
        batches = sink._split_batches(records)
        assert len(batches) == 1
        assert batches[0] == records

    def test_split_batches_with_batching(self) -> None:
        sink = HttpSink("http://example.com/api", batch_size=3)
        records = _sample_records(7)
        batches = sink._split_batches(records)
        assert len(batches) == 3
        assert len(batches[0]) == 3
        assert len(batches[1]) == 3
        assert len(batches[2]) == 1

    def test_put_method_accepted(self) -> None:
        sink = HttpSink("http://example.com/api", method="PUT")
        assert sink._method == "PUT"

    def test_patch_method_accepted(self) -> None:
        sink = HttpSink("http://example.com/api", method="PATCH")
        assert sink._method == "PATCH"


class TestAsyncHttpSink:
    """Tests for AsyncHttpSink."""

    def test_default_headers_set(self) -> None:
        sink = AsyncHttpSink("http://example.com/api")
        assert sink._headers["Content-Type"] == "application/json"

    def test_auth_token_sets_bearer_header(self) -> None:
        sink = AsyncHttpSink("http://example.com/api", auth_token="token123")
        assert sink._headers["Authorization"] == "Bearer token123"

    @pytest.mark.asyncio()
    async def test_send_empty_records(self) -> None:
        sink = AsyncHttpSink("http://example.com/api")
        result = await sink.send([], {})
        assert result.success is True
        assert result.records_sent == 0

    @pytest.mark.asyncio()
    async def test_close_is_noop(self) -> None:
        sink = AsyncHttpSink("http://example.com/api")
        await sink.close()  # Should not raise
