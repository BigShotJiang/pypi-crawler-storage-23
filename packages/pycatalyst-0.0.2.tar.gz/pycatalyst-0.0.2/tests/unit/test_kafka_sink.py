"""Tests for pycatalyst.sinks.kafka module."""

from __future__ import annotations

import json
import sys
from typing import Any
from unittest.mock import MagicMock, patch

import pytest


def _sample_records(count: int = 3) -> list[dict[str, Any]]:
    """Return sample records for testing."""
    return [{"id": i, "name": f"item_{i}"} for i in range(count)]


@pytest.fixture(autouse=True)
def _mock_confluent_kafka() -> Any:
    """Mock confluent_kafka module for all tests in this file."""
    mock_module = MagicMock()
    with patch.dict(sys.modules, {"confluent_kafka": mock_module}):
        yield mock_module


class TestKafkaSink:
    """Tests for KafkaSink."""

    def test_send_empty_records(self) -> None:
        from pycatalyst.sinks.kafka import KafkaSink

        sink = KafkaSink("localhost:9092", "test-topic")
        result = sink.send([], {})
        assert result.success is True
        assert result.records_sent == 0
        assert result.sink_type == "kafka"

    def test_send_records_success(self, _mock_confluent_kafka: MagicMock) -> None:
        from pycatalyst.sinks.kafka import KafkaSink

        mock_producer = MagicMock()
        mock_producer.flush.return_value = 0
        _mock_confluent_kafka.Producer.return_value = mock_producer

        sink = KafkaSink("localhost:9092", "test-topic")
        records = _sample_records()
        result = sink.send(records, {"schema": "test"})

        assert result.success is True
        assert result.records_sent == 3
        assert result.metadata["topic"] == "test-topic"
        assert result.metadata["bootstrap_servers"] == "localhost:9092"

        assert mock_producer.produce.call_count == 3
        mock_producer.flush.assert_called_once()

    def test_send_with_key_field(self, _mock_confluent_kafka: MagicMock) -> None:
        from pycatalyst.sinks.kafka import KafkaSink

        mock_producer = MagicMock()
        mock_producer.flush.return_value = 0
        _mock_confluent_kafka.Producer.return_value = mock_producer

        sink = KafkaSink("localhost:9092", "test-topic", key_field="id")
        records = [{"id": "abc", "value": 1}]
        sink.send(records, {})

        call_kwargs = mock_producer.produce.call_args.kwargs
        assert call_kwargs["key"] == b"abc"
        assert call_kwargs["topic"] == "test-topic"

    def test_send_without_key_field(self, _mock_confluent_kafka: MagicMock) -> None:
        from pycatalyst.sinks.kafka import KafkaSink

        mock_producer = MagicMock()
        mock_producer.flush.return_value = 0
        _mock_confluent_kafka.Producer.return_value = mock_producer

        sink = KafkaSink("localhost:9092", "test-topic")
        records = [{"value": 1}]
        sink.send(records, {})

        call_kwargs = mock_producer.produce.call_args.kwargs
        assert call_kwargs["key"] is None

    def test_send_serializes_as_json(self, _mock_confluent_kafka: MagicMock) -> None:
        from pycatalyst.sinks.kafka import KafkaSink

        mock_producer = MagicMock()
        mock_producer.flush.return_value = 0
        _mock_confluent_kafka.Producer.return_value = mock_producer

        sink = KafkaSink("localhost:9092", "test-topic")
        records = [{"x": 42}]
        sink.send(records, {})

        call_kwargs = mock_producer.produce.call_args.kwargs
        value = call_kwargs["value"]
        assert json.loads(value) == {"x": 42}

    def test_flush_timeout_reports_remaining(
        self, _mock_confluent_kafka: MagicMock
    ) -> None:
        from pycatalyst.sinks.kafka import KafkaSink

        mock_producer = MagicMock()
        mock_producer.flush.return_value = 2
        _mock_confluent_kafka.Producer.return_value = mock_producer

        sink = KafkaSink("localhost:9092", "test-topic", flush_timeout=5.0)
        result = sink.send(_sample_records(), {})

        assert result.success is False
        assert "2 messages not delivered" in result.errors[0]

    def test_produce_exception_captured(self, _mock_confluent_kafka: MagicMock) -> None:
        from pycatalyst.sinks.kafka import KafkaSink

        mock_producer = MagicMock()
        mock_producer.produce.side_effect = Exception("Broker unreachable")
        _mock_confluent_kafka.Producer.return_value = mock_producer

        sink = KafkaSink("localhost:9092", "test-topic")
        result = sink.send(_sample_records(), {})

        assert result.success is False
        assert "Broker unreachable" in result.errors[0]

    def test_delivery_callback_error(self) -> None:
        from pycatalyst.sinks.kafka import KafkaSink

        sink = KafkaSink("localhost:9092", "test-topic")
        sink._delivery_callback(err="Message too large", msg=MagicMock())
        assert len(sink._delivery_errors) == 1

    def test_close_flushes_producer(self, _mock_confluent_kafka: MagicMock) -> None:
        from pycatalyst.sinks.kafka import KafkaSink

        mock_producer = MagicMock()
        mock_producer.flush.return_value = 0
        _mock_confluent_kafka.Producer.return_value = mock_producer

        sink = KafkaSink("localhost:9092", "test-topic")
        sink.send(_sample_records(1), {})
        sink.close()

        # flush called once in send, once in close
        assert mock_producer.flush.call_count == 2
        assert sink._producer is None

    def test_close_noop_when_no_producer(self) -> None:
        from pycatalyst.sinks.kafka import KafkaSink

        sink = KafkaSink("localhost:9092", "test-topic")
        sink.close()  # Should not raise


class TestRecipeRunnerKafkaSink:
    """Tests for Kafka sink integration in recipe runner."""

    def test_kafka_sink_missing_bootstrap_servers(self) -> None:
        from pycatalyst.errors import RecipeError
        from pycatalyst.recipes.runner import RecipeRunner

        data = {
            "name": "test",
            "schema": {"fields": [{"name": "x", "type": "int"}]},
            "sink": {
                "type": "kafka",
                "config": {"topic": "test-topic"},
            },
        }
        runner = RecipeRunner()
        with pytest.raises(RecipeError, match="bootstrap_servers"):
            runner.run_dict(data)

    def test_kafka_sink_missing_topic(self) -> None:
        from pycatalyst.errors import RecipeError
        from pycatalyst.recipes.runner import RecipeRunner

        data = {
            "name": "test",
            "schema": {"fields": [{"name": "x", "type": "int"}]},
            "sink": {
                "type": "kafka",
                "config": {"bootstrap_servers": "localhost:9092"},
            },
        }
        runner = RecipeRunner()
        with pytest.raises(RecipeError, match="topic"):
            runner.run_dict(data)
