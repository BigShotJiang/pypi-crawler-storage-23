"""Tests for pycatalyst.sinks.rabbitmq module."""

from __future__ import annotations

import json
import sys
from typing import Any
from unittest.mock import MagicMock, patch

import pytest

from pycatalyst.sinks.rabbitmq import _mask_amqp_url


def _sample_records(count: int = 3) -> list[dict[str, Any]]:
    """Return sample records for testing."""
    return [{"id": i, "name": f"item_{i}"} for i in range(count)]


@pytest.fixture(autouse=True)
def _mock_pika() -> Any:
    """Mock pika module for all tests in this file."""
    mock_module = MagicMock()
    with patch.dict(sys.modules, {"pika": mock_module}):
        yield mock_module


class TestRabbitMQSink:
    """Tests for RabbitMQSink."""

    def test_send_empty_records(self) -> None:
        from pycatalyst.sinks.rabbitmq import RabbitMQSink

        sink = RabbitMQSink("amqp://localhost/")
        result = sink.send([], {})
        assert result.success is True
        assert result.records_sent == 0
        assert result.sink_type == "rabbitmq"

    def test_send_records_success(self, _mock_pika: MagicMock) -> None:
        from pycatalyst.sinks.rabbitmq import RabbitMQSink

        mock_channel = MagicMock()
        mock_conn = MagicMock()
        mock_conn.is_closed = False
        mock_conn.channel.return_value = mock_channel
        _mock_pika.BlockingConnection.return_value = mock_conn

        sink = RabbitMQSink(
            "amqp://localhost/",
            exchange="test-exchange",
            routing_key="test-key",
        )
        records = _sample_records()
        result = sink.send(records, {})

        assert result.success is True
        assert result.records_sent == 3
        assert result.metadata["exchange"] == "test-exchange"
        assert result.metadata["routing_key"] == "test-key"

        assert mock_channel.basic_publish.call_count == 3
        sink.close()

    def test_send_serializes_as_json(self, _mock_pika: MagicMock) -> None:
        from pycatalyst.sinks.rabbitmq import RabbitMQSink

        mock_channel = MagicMock()
        mock_conn = MagicMock()
        mock_conn.is_closed = False
        mock_conn.channel.return_value = mock_channel
        _mock_pika.BlockingConnection.return_value = mock_conn

        sink = RabbitMQSink("amqp://localhost/", routing_key="test")
        records = [{"x": 42}]
        sink.send(records, {})

        published_body = mock_channel.basic_publish.call_args.kwargs["body"]
        assert json.loads(published_body) == {"x": 42}
        sink.close()

    def test_queue_declared_when_provided(self, _mock_pika: MagicMock) -> None:
        from pycatalyst.sinks.rabbitmq import RabbitMQSink

        mock_channel = MagicMock()
        mock_conn = MagicMock()
        mock_conn.is_closed = False
        mock_conn.channel.return_value = mock_channel
        _mock_pika.BlockingConnection.return_value = mock_conn

        sink = RabbitMQSink(
            "amqp://localhost/",
            queue="my-queue",
            declare_queue=True,
        )
        sink.send(_sample_records(1), {})

        mock_channel.queue_declare.assert_called_once_with(
            queue="my-queue", durable=True
        )
        sink.close()

    def test_queue_not_declared_when_disabled(self, _mock_pika: MagicMock) -> None:
        from pycatalyst.sinks.rabbitmq import RabbitMQSink

        mock_channel = MagicMock()
        mock_conn = MagicMock()
        mock_conn.is_closed = False
        mock_conn.channel.return_value = mock_channel
        _mock_pika.BlockingConnection.return_value = mock_conn

        sink = RabbitMQSink(
            "amqp://localhost/",
            queue="my-queue",
            declare_queue=False,
        )
        sink.send(_sample_records(1), {})

        mock_channel.queue_declare.assert_not_called()
        sink.close()

    def test_routing_key_defaults_to_queue(self, _mock_pika: MagicMock) -> None:
        from pycatalyst.sinks.rabbitmq import RabbitMQSink

        mock_channel = MagicMock()
        mock_conn = MagicMock()
        mock_conn.is_closed = False
        mock_conn.channel.return_value = mock_channel
        _mock_pika.BlockingConnection.return_value = mock_conn

        sink = RabbitMQSink("amqp://localhost/", queue="my-queue")
        sink.send(_sample_records(1), {})

        publish_kwargs = mock_channel.basic_publish.call_args.kwargs
        assert publish_kwargs["routing_key"] == "my-queue"
        sink.close()

    def test_publish_exception_captured(self, _mock_pika: MagicMock) -> None:
        from pycatalyst.sinks.rabbitmq import RabbitMQSink

        mock_channel = MagicMock()
        mock_channel.basic_publish.side_effect = Exception("Connection lost")
        mock_conn = MagicMock()
        mock_conn.is_closed = False
        mock_conn.channel.return_value = mock_channel
        _mock_pika.BlockingConnection.return_value = mock_conn

        sink = RabbitMQSink("amqp://localhost/", routing_key="test")
        result = sink.send(_sample_records(), {})

        assert result.success is False
        assert "Connection lost" in result.errors[0]
        sink.close()

    def test_close_closes_connection(self, _mock_pika: MagicMock) -> None:
        from pycatalyst.sinks.rabbitmq import RabbitMQSink

        mock_conn = MagicMock()
        mock_conn.is_closed = False
        mock_conn.channel.return_value = MagicMock()
        _mock_pika.BlockingConnection.return_value = mock_conn

        sink = RabbitMQSink("amqp://localhost/", routing_key="test")
        sink.send(_sample_records(1), {})
        sink.close()

        mock_conn.close.assert_called_once()
        assert sink._connection is None
        assert sink._channel is None

    def test_close_noop_when_no_connection(self) -> None:
        from pycatalyst.sinks.rabbitmq import RabbitMQSink

        sink = RabbitMQSink("amqp://localhost/")
        sink.close()  # Should not raise


class TestMaskAmqpUrl:
    """Tests for _mask_amqp_url helper."""

    def test_masks_password(self) -> None:
        assert (
            _mask_amqp_url("amqp://guest:secret@localhost/")
            == "amqp://guest:***@localhost/"
        )

    def test_no_password_unchanged(self) -> None:
        assert _mask_amqp_url("amqp://localhost/") == "amqp://localhost/"


class TestRecipeRunnerRabbitMQSink:
    """Tests for RabbitMQ sink integration in recipe runner."""

    def test_rabbitmq_sink_missing_url(self) -> None:
        from pycatalyst.errors import RecipeError
        from pycatalyst.recipes.runner import RecipeRunner

        data = {
            "name": "test",
            "schema": {"fields": [{"name": "x", "type": "int"}]},
            "sink": {
                "type": "rabbitmq",
                "config": {"queue": "test-queue"},
            },
        }
        runner = RecipeRunner()
        with pytest.raises(RecipeError, match="url"):
            runner.run_dict(data)
