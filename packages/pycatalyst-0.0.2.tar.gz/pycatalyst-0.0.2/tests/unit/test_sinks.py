"""Tests for pycatalyst.sinks module."""

from __future__ import annotations

from pycatalyst._protocols import Sink
from pycatalyst.sinks.memory import InMemorySink


class TestInMemorySink:
    """Tests for InMemorySink."""

    def test_satisfies_sink_protocol(self) -> None:
        sink = InMemorySink()
        assert isinstance(sink, Sink)

    def test_send_stores_records(self) -> None:
        sink = InMemorySink()
        records = [{"id": 1, "name": "a"}, {"id": 2, "name": "b"}]
        result = sink.send(records, {"schema": "test"})
        assert result.success is True
        assert result.records_sent == 2
        assert result.sink_type == "memory"
        assert sink.record_count == 2
        assert sink.records == records

    def test_multiple_sends(self) -> None:
        sink = InMemorySink()
        sink.send([{"x": 1}], {})
        sink.send([{"x": 2}, {"x": 3}], {})
        assert sink.record_count == 3
        assert sink.batch_count == 2

    def test_clear(self) -> None:
        sink = InMemorySink()
        sink.send([{"x": 1}], {})
        sink.clear()
        assert sink.record_count == 0
        assert sink.batch_count == 0

    def test_close_is_noop(self) -> None:
        sink = InMemorySink()
        sink.send([{"x": 1}], {})
        sink.close()
        assert sink.record_count == 1
