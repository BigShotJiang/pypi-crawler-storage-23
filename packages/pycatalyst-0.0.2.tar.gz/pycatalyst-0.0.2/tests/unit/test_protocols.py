"""Tests for pycatalyst._protocols module."""

from __future__ import annotations

from random import Random
from typing import Any

from pycatalyst._protocols import AsyncSink, Generator, SchemaInferrer, Sink
from pycatalyst._types import FieldSpec, FieldType, SchemaSpec, SinkResult


class TestGeneratorProtocol:
    """Tests for the Generator protocol."""

    def test_concrete_class_satisfies_protocol(self) -> None:
        class IntGenerator:
            def generate(self, spec: FieldSpec, rng: Random) -> Any:
                return rng.randint(0, 100)

        gen = IntGenerator()
        assert isinstance(gen, Generator)

    def test_non_conforming_class(self) -> None:
        class NotAGenerator:
            def produce(self) -> int:
                return 0

        assert not isinstance(NotAGenerator(), Generator)


class TestSinkProtocol:
    """Tests for the Sink protocol."""

    def test_concrete_class_satisfies_protocol(self) -> None:
        class MemorySink:
            def __init__(self) -> None:
                self.data: list[dict[str, Any]] = []

            def send(
                self,
                records: list[dict[str, Any]],
                metadata: dict[str, Any],
            ) -> SinkResult:
                self.data.extend(records)
                return SinkResult(success=True, records_sent=len(records))

            def close(self) -> None:
                self.data.clear()

        sink = MemorySink()
        assert isinstance(sink, Sink)

        result = sink.send([{"x": 1}], {})
        assert result.success is True
        assert result.records_sent == 1

    def test_non_conforming_class(self) -> None:
        class NotASink:
            def write(self, data: list[dict[str, Any]]) -> None:
                pass

        assert not isinstance(NotASink(), Sink)


class TestAsyncSinkProtocol:
    """Tests for the AsyncSink protocol."""

    def test_concrete_class_satisfies_protocol(self) -> None:
        class AsyncMemorySink:
            async def send(
                self,
                records: list[dict[str, Any]],
                metadata: dict[str, Any],
            ) -> SinkResult:
                return SinkResult(success=True, records_sent=len(records))

            async def close(self) -> None:
                pass

        assert isinstance(AsyncMemorySink(), AsyncSink)


class TestSchemaInferrerProtocol:
    """Tests for the SchemaInferrer protocol."""

    def test_concrete_class_satisfies_protocol(self) -> None:
        class DictInferrer:
            def infer(self, source: Any) -> SchemaSpec:
                return SchemaSpec(
                    name="inferred",
                    fields=(FieldSpec(name="col", type=FieldType.STRING),),
                )

        inferrer = DictInferrer()
        assert isinstance(inferrer, SchemaInferrer)

        schema = inferrer.infer({"col": "test"})
        assert schema.name == "inferred"
