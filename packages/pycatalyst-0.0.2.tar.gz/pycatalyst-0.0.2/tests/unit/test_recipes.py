"""Tests for pycatalyst.recipes module."""

from __future__ import annotations

import json
from pathlib import Path

import pytest
import yaml

from pycatalyst.errors import RecipeError
from pycatalyst.recipes.loader import load_recipe, load_recipe_from_dict
from pycatalyst.recipes.runner import RecipeRunner


def _minimal_recipe() -> dict:
    """Return a minimal valid recipe dict."""
    return {
        "name": "test_recipe",
        "schema": {
            "fields": [
                {"name": "id", "type": "uuid"},
                {"name": "value", "type": "int"},
            ],
        },
        "generation": {"count": 5, "seed": 42},
        "sink": {"type": "memory"},
    }


class TestRecipeLoader:
    """Tests for recipe loading and validation."""

    def test_load_from_dict(self) -> None:
        config = load_recipe_from_dict(_minimal_recipe())
        assert config.name == "test_recipe"
        assert len(config.schema_.fields) == 2
        assert config.generation.count == 5
        assert config.sink.type == "memory"

    def test_load_from_file(self, tmp_path: Path) -> None:
        recipe_path = tmp_path / "recipe.yaml"
        recipe_path.write_text(yaml.dump(_minimal_recipe()), encoding="utf-8")
        config = load_recipe(recipe_path)
        assert config.name == "test_recipe"

    def test_file_not_found(self) -> None:
        with pytest.raises(RecipeError, match="not found"):
            load_recipe("/nonexistent/recipe.yaml")

    def test_invalid_yaml(self, tmp_path: Path) -> None:
        bad = tmp_path / "bad.yaml"
        bad.write_text("{{invalid yaml", encoding="utf-8")
        with pytest.raises(RecipeError, match="Invalid YAML"):
            load_recipe(bad)

    def test_missing_name(self) -> None:
        data = _minimal_recipe()
        del data["name"]
        with pytest.raises(RecipeError, match="Invalid recipe"):
            load_recipe_from_dict(data)

    def test_missing_schema(self) -> None:
        data = {"name": "test"}
        with pytest.raises(RecipeError, match="Invalid recipe"):
            load_recipe_from_dict(data)

    def test_env_var_substitution(self, tmp_path: Path) -> None:
        recipe_data = _minimal_recipe()
        recipe_data["sink"] = {
            "type": "file",
            "config": {"path": "${TEST_OUTPUT_PATH:-/tmp/default.json}"},
        }
        recipe_path = tmp_path / "recipe.yaml"
        recipe_path.write_text(yaml.dump(recipe_data), encoding="utf-8")
        config = load_recipe(recipe_path)
        assert config.sink.config["path"] == "/tmp/default.json"

    def test_env_var_with_value(
        self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch
    ) -> None:
        monkeypatch.setenv("CATALYST_OUT", "/my/output.json")
        recipe_data = _minimal_recipe()
        recipe_data["sink"] = {
            "type": "file",
            "config": {"path": "${CATALYST_OUT}"},
        }
        recipe_path = tmp_path / "recipe.yaml"
        recipe_path.write_text(yaml.dump(recipe_data), encoding="utf-8")
        config = load_recipe(recipe_path)
        assert config.sink.config["path"] == "/my/output.json"

    def test_env_var_required_missing(self, tmp_path: Path) -> None:
        recipe_path = tmp_path / "recipe.yaml"
        recipe_path.write_text(
            "name: test\nurl: ${REQUIRED_VAR:?Must set REQUIRED_VAR}\n"
            "schema:\n  fields:\n    - name: x\n      type: int\n"
            "sink:\n  type: memory\n",
            encoding="utf-8",
        )
        with pytest.raises(RecipeError, match="Must set REQUIRED_VAR"):
            load_recipe(recipe_path)

    def test_defaults(self) -> None:
        data = {
            "name": "minimal",
            "schema": {"fields": [{"name": "x", "type": "int"}]},
        }
        config = load_recipe_from_dict(data)
        assert config.generation.count == 10
        assert config.generation.seed is None
        assert config.sink.type == "memory"

    def test_with_enum_constraints(self) -> None:
        data = {
            "name": "enum_test",
            "schema": {
                "fields": [
                    {
                        "name": "status",
                        "type": "enum",
                        "constraints": {"choices": ["a", "b"]},
                    },
                ],
            },
        }
        config = load_recipe_from_dict(data)
        assert config.schema_.fields[0].constraints["choices"] == ["a", "b"]


class TestRecipeRunner:
    """Tests for RecipeRunner."""

    def test_run_dict(self) -> None:
        runner = RecipeRunner()
        gen_result, sink_result = runner.run_dict(_minimal_recipe())
        assert gen_result.count == 5
        assert len(gen_result.records) == 5
        assert sink_result.success is True

    def test_run_file(self, tmp_path: Path) -> None:
        recipe_path = tmp_path / "recipe.yaml"
        recipe_path.write_text(yaml.dump(_minimal_recipe()), encoding="utf-8")
        runner = RecipeRunner()
        gen_result, sink_result = runner.run_file(recipe_path)
        assert gen_result.count == 5

    def test_run_with_file_sink(self, tmp_path: Path) -> None:
        output_path = tmp_path / "output.json"
        data = _minimal_recipe()
        data["sink"] = {
            "type": "file",
            "config": {"path": str(output_path)},
        }
        runner = RecipeRunner()
        gen_result, sink_result = runner.run_dict(data)
        assert sink_result.success is True
        assert output_path.exists()

        records = json.loads(output_path.read_text())
        assert len(records) == 5

    def test_reproducible_with_seed(self) -> None:
        runner = RecipeRunner()
        r1, _ = runner.run_dict(_minimal_recipe())
        r2, _ = runner.run_dict(_minimal_recipe())
        assert r1.records == r2.records

    def test_unknown_sink_type(self) -> None:
        data = _minimal_recipe()
        data["sink"] = {"type": "unknown_sink"}
        runner = RecipeRunner()
        with pytest.raises(RecipeError, match="Unknown sink type"):
            runner.run_dict(data)

    def test_file_sink_missing_path(self) -> None:
        data = _minimal_recipe()
        data["sink"] = {"type": "file", "config": {}}
        runner = RecipeRunner()
        with pytest.raises(RecipeError, match="requires 'path'"):
            runner.run_dict(data)

    def test_built_in_recipe_templates(self) -> None:
        templates_dir = (
            Path(__file__).parent.parent.parent
            / "src"
            / "pycatalyst"
            / "data"
            / "templates"
            / "recipes"
        )
        runner = RecipeRunner()
        for recipe_path in templates_dir.glob("*.yaml"):
            config = load_recipe(recipe_path)
            gen_result, sink_result = runner.run_dict(
                yaml.safe_load(recipe_path.read_text())
            )
            assert gen_result.count > 0
            assert sink_result.success is True
