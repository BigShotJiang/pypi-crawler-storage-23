# Contributing

## Setup

```bash
git clone https://github.com/your-org/pycatalyst
cd pycatalyst
python -m venv .venv
source .venv/bin/activate   # or .venv\Scripts\activate on Windows
pip install -e ".[dev]"
```

## Checks before commit

- `ruff check . && ruff format .`
- `mypy src/`
- `pytest`

## Releasing

1. Update `version` in `pyproject.toml` and add an entry in `CHANGELOG.md`.
2. Commit and push.
3. Create and push a tag: `git tag v0.1.0 && git push origin v0.1.0`.
4. On PyPI, configure [Trusted Publishing](https://docs.pypi.org/trusted-publishers/) for this repository so the GitHub Action can publish without storing tokens.
