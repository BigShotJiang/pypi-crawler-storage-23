import datetime
from dateutil import parser
from typing import List, Dict, Any, Optional, Set
from esi.clients import EsiClientProvider
from django.core.cache import cache
import pytz

from .utils.eveonline import EveCharacterUtils
from .brmodels import Victim,Killmail
from eveuniverse.models import EveEntity
from .models import BattleReport, FilterEntity, KillCompensation
from .exceptions import PartialReportError
import requests
import json
from allianceauth.services.hooks import get_extension_logger
from allianceauth import __version__, __title_useragent__, __url__
from esi.errors import TokenExpiredError, TokenInvalidError
from esi.models import Token

logger = get_extension_logger(__name__)

esi = EsiClientProvider()

class EveMailService:
    """Сервис для работы с почтой персонажа EVE Online через ESI API"""
    
    REQUIRED_SCOPES = ['esi-mail.read_mail.v1']
    CACHE_TIMEOUT = 30  # 30 секунд для кэширования списка писем
    
    @classmethod
    def get_character_mail_list(cls, character_id: int, token: Token, last_mail_id:int = None) -> List[Dict[str, Any]]:
        """
        Получить список писем персонажа (только метаданные, без содержимого).
        
        Args:
            character_id: ID персонажа
            token: Токен авторизации
            
        Returns:
            Список писем с метаданными
        """
        try:
            # Проверяем кэш
            cache_key = f'mail_list_{character_id}'
            cached_mails = cache.get(cache_key)
            
            if cached_mails is not None:
                logger.debug(f'Использован кэш для списка писем персонажа {character_id}')
                return cached_mails
            
            # Получаем ESI клиент с автоматическим обновлением токена
            client = token.get_esi_client(spec_file=None)
            
            # Запрашиваем список писем
            mail_list = client.Mail.get_characters_character_id_mail(
                character_id=character_id,
            ).result()
            
            # Сохраняем в кэш
            cache.set(cache_key, mail_list, cls.CACHE_TIMEOUT)
            
            logger.info(f'Получено {len(mail_list)} писем для персонажа {character_id}')
            
            if not last_mail_id == None:
                mail_list = [ mail for mail in mail_list if mail['mail_id'] > last_mail_id ]
            
            return mail_list
            
        except TokenExpiredError as e:
            logger.warning(
                f'Токен пользователя {character_id} просрочен или недействителен. '
                f'Пользователю необходимо авторизоваться снова через EVE SSO с скоупом esi-mail.read_mail.v1. '
                f'Ошибка: {e}'
            )
            return []
        except TokenInvalidError as e:
            logger.warning(
                f'Некорректный токен пользователя {character_id}. '
                f'Токен был отозван или имеет недействительный refresh token. '
                f'Пользователю необходимо авторизоваться снова через EVE SSO. '
                f'Ошибка: {e}'
            )
            return []
        except Exception as e:
            logger.error(f'Ошибка при получении списка писем для персонажа {character_id}: {e}')
            raise
    
    @classmethod
    def get_mail_content(cls, character_id: int, mail_id: int, token: Token) -> Optional[Dict[str, Any]]:
        """
        Получить содержимое конкретного письма.
        
        Args:
            character_id: ID персонажа
            mail_id: ID письма
            token: Токен авторизации
            
        Returns:
            Словарь с содержимым письма включая body
        """
        try:
            # Проверяем кэш
            cache_key = f'mail_content_{character_id}_{mail_id}'
            cached_mail = cache.get(cache_key)
            
            if cached_mail is not None:
                logger.debug(f'Использован кэш для письма {mail_id} персонажа {character_id}')
                return cached_mail
            
            # Получаем ESI клиент с автоматическим обновлением токена
            client = token.get_esi_client(spec_file=None)
            
            # Запрашиваем содержимое письма
            mail_content = client.Mail.get_characters_character_id_mail_mail_id(
                character_id=character_id,
                mail_id=mail_id
            ).result()
            
            # Сохраняем в кэш
            cache.set(cache_key, mail_content, cls.CACHE_TIMEOUT * 2)
            
            logger.debug(f'Получено содержимое письма {mail_id} для персонажа {character_id}')
            return mail_content
            
        except TokenExpiredError as e:
            logger.warning(
                f'Токен пользователя {character_id} просрочен или недействителен. '
                f'Пользователю необходимо авторизоваться снова через EVE SSO с скоупом esi-mail.read_mail.v1. '
                f'Ошибка: {e}'
            )
            return None
        except TokenInvalidError as e:
            logger.warning(
                f'Некорректный токен пользователя {character_id}. '
                f'Токен был отозван или имеет недействительный refresh token. '
                f'Пользователю необходимо авторизоваться снова через EVE SSO. '
                f'Ошибка: {e}'
            )
            return None
        except Exception as e:
            logger.error(f'Ошибка при получении письма {mail_id} для персонажа {character_id}: {e}')
            raise
    
    @classmethod
    def get_all_mails_with_content(
        cls,
        character_id: int,
        token: Token,
        limit: int = 50,
        last_mail_id: int = None,
        unread_only: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Получить все письма с содержимым.
        
        Args:
            character_id: ID персонажа
            token: Токен авторизации
            limit: Максимальное количество писем для загрузки
            unread_only: Загружать только непрочитанные письма
            
        Returns:
            Список писем с полным содержимым
        """
        try:
            # Получаем список писем
            mail_list = cls.get_character_mail_list(character_id, token, last_mail_id)
            
            if not mail_list:
                return []
            
            # Фильтруем по is_read если нужно
            if unread_only:
                mail_list = [mail for mail in mail_list if not mail.get('is_read', False)]
            
            # Ограничиваем количество
            mail_list = mail_list[:limit]
            
            # Получаем содержимое для каждого письма
            mails_with_content = []
            for mail in mail_list:
                mail_id = mail.get('mail_id')
                if mail_id:
                    mail_content = cls.get_mail_content(character_id, mail_id, token)
                    if mail_content:
                        # Объединяем метаданные и содержимое
                        mail_with_content = {**mail, **mail_content}
                        mails_with_content.append(mail_with_content)
            
            logger.info(f'Получено {len(mails_with_content)} писем с содержимым для персонажа {character_id}')
            return mails_with_content
            
        except Exception as e:
            logger.error(f'Ошибка при получении писем с содержимым для персонажа {character_id}: {e}')
            raise
    
    @classmethod
    def get_character_mails(
        cls,
        character_id: int,
        limit: int = 50,
        last_mail_id: int = None,
        unread_only: bool = False
    ) -> List[Dict[str, Any]]:
        """
        Получить письма персонажа (автоматически находит токен).
        
        Args:
            character_id: ID персонажа
            limit: Максимальное количество писем для загрузки
            unread_only: Загружать только непрочитанные письма
            
        Returns:
            Список писем с полным содержимым или пустой список при ошибке
        """
        try:
            # Получаем токен
            token = EveCharacterUtils.get_token_for_character(character_id,cls.REQUIRED_SCOPES)
            
            if not token:
                logger.warning(f'Не найден токен для персонажа {character_id} или токен не имеет нужных скоупов')
                return []
            
            # Получаем письма с содержимым
            return cls.get_all_mails_with_content(
                character_id=character_id,
                token=token,
                limit=limit,
                unread_only=unread_only,
                last_mail_id=last_mail_id
            )
            
        except Exception as e:
            logger.error(f'Ошибка при получении писем для персонажа {character_id}: {e}')
            return []

class EveUniverseSearchService:
    """Сервис для поиска сущностей в EVE Universe через ESI"""
    
    CACHE_TIMEOUT = 300  # 5 минут
    
    @classmethod
    def search_by_name(cls, name: str) -> Dict[str, Any]:
        """Поиск сущности по имени (использует локальную базу данных)"""
        cache_key = f"local_search_{name}"
        cached_result = cache.get(cache_key)
        if cached_result is not None:
            return cached_result
        
        try:
            # Поиск в локальной базе данных
            entities = EveEntity.objects.filter(name__icontains=name)[:50]
            
            formatted_result = [
                    {'id': e.id, 'name': e.name, 'type': e.category} 
                    for e in entities
                ]
            
            cache.set(cache_key, formatted_result, cls.CACHE_TIMEOUT)
            return formatted_result
        except Exception as e:
            logger.error(f"Ошибка при поиске: {e}")
            return []
 
class BattleReportsService:
    
    #Single kill url https://br.evetools.org/api/v1/killmails/133268017/
    #Related url https://br.evetools.org/api/v1/composition/get/
    BR_API_BASE_URL = 'https://br.evetools.org/api/v1/'
    CACHE_TIMEOUT = 3600  # 1 час для кэша названий
    
    @classmethod
    def process_all(cls):
        """Выполняет загрузку всех новых отчетов"""
        reports = BattleReport.objects.exclude(status = BattleReport.PROCESS_COMPLETE).all()
        for report in reports:
            try:
                cls.process(report)
            except Exception as e:
                logger.error(f'Ошибка бработки отчета {report.report_id}')
                report.status = BattleReport.PROCESS_FAILED
                report.save()
        
    @classmethod
    def process(cls, report:BattleReport):
        """
        Выполняет загрузку данных из отчета и сохраняет киллы в базе
        Args:
            report: Отчет о сражении
        Returns:
            List[Killmail]: Список загруженных киллмэйлов
        """
        result = List[Killmail]
        try:
            report.status = BattleReport.PROCESS_PROCESSING
            report.save()
           
            logger.info(f'Начинается обработка отчета: {report.link}')
           
            api_url = cls.get_br_api_url(report.link)
           
            logger.info(f'Ссылка на api отчета: {api_url}')
            logger.info(f'Запрашиваем данные о бое.')
           
            json_data = cls.get_api_response(api_url)
            if json_data is None:
                raise Exception(f'br.evetools.org вернул пустой ответ по адресу {api_url}')
            
            if 'updatedAt' in json_data:
                report.updatedAt =  parser.parse(json_data['updatedAt'])
            else:
                report.updatedAt = datetime.datetime.now()
            
            logger.info('Данные получены')
            
            result = cls.parse_killmails_from_api(json_data)
            
            logger.info(f'В отчете найдено {len(result)} киллмэйлов, отвечающих критериям фильтрации.')
            logger.info('Запрашиваем данные объектов киллмэйла из ESI.')
            # Заполняем killmails названиями сущностей
            
            result = cls.enrich_killmails_with_names(result)
            
            logger.info('Данные получены.')
            logger.info('Сохраняем киллмэйлы в базе данных.')
            
            cls.save_killmails(result)
            
            logger.info('Киллмэйлы успешно сохранены.')
            logger.info('Помечаем отчет как обработанный.')
            
            report.status = BattleReport.PROCESS_COMPLETE
            report.save()
            
            logger.info('Обработка успешно выполнена.')
            return result
        except PartialReportError as e:
            '''Не критичная ошибка. Просто бр не до конца загрузился и возвращает неполные данные'''
            '''Помечаем бр для повторной обработки''' 
            report.status = BattleReport.PROCESS_REINITIALIZE
            report.save()
            logger.error(e)
            return None
        except Exception as e:
            logger.error(e)
            return None
        
    
    @classmethod
    def get_br_api_url(cls, url):
        url_parts = url.split('/')
        id = url_parts[-1]
        if id == '' and len(url_parts) > 1:
            id = url_parts[-2]
        if 'zkillboard.com' in url:
            br_endpoint =  'killmails/'
        elif 'br.evetools.org/related' in url:
            br_endpoint = 'related/'
            id = f'{url_parts[-2]}/{url_parts[-1]}'
        elif 'br.evetools.org':
            br_endpoint = 'composition/get/'
        return f'{cls.BR_API_BASE_URL}{br_endpoint}{id}'
    
    @classmethod
    def get_api_response(cls, url):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
        
        try:
            print(f"\n🔄 Запрашиваю данные...")
            response = requests.get(url, headers=headers, timeout=15)
            response.raise_for_status()
            return response.json()
        except requests.exceptions.Timeout:
            print(f"❌ Таймаут запроса для {url}")
            return None
        except requests.exceptions.HTTPError as e:
            print(f"❌ HTTP ошибка для {url}: {e}")
            return None
        except requests.exceptions.RequestException as e:
            print(f"❌ Ошибка запроса для {url}: {e}")
            return None
        except json.JSONDecodeError as e:
            print(f"❌ Ошибка парсинга JSON для {url}: {e}")
            return None
        except Exception as e:
            print(f"❌ Неожиданная ошибка для {url}: {e}")
            return None
        
    @classmethod
    def _prepare_filter_sets(cls, filter_entities) -> Optional[Dict[str, Set[int]]]:
        """
        Подготавливает множества ID для быстрого поиска по фильтрам
        
        Args:
            filter_entities: QuerySet или список объектов FilterEntity
        
        Returns:
            Dict с множествами ID или None если фильтры не заданы
        """
        if not filter_entities:
            return None
        
        # Преобразуем QuerySet в список если нужно
        if hasattr(filter_entities, 'all'):
            filter_entities = list(filter_entities.all())
        elif hasattr(filter_entities, '__iter__'):
            filter_entities = list(filter_entities)
        else:
            return None
        
        # Создаем множества для быстрого поиска
        character_ids = set()
        corporation_ids = set()
        alliance_ids = set()
        
        for entity in filter_entities:
            if entity.entity_type == FilterEntity.CHARACTER:
                character_ids.add(entity.entity_id)
            elif entity.entity_type == FilterEntity.CORPORATION:
                corporation_ids.add(entity.entity_id)
            elif entity.entity_type == FilterEntity.ALLIANCE:
                alliance_ids.add(entity.entity_id)
        
        if not any([character_ids, corporation_ids, alliance_ids]):
            logger.warning("Нет активных фильтров для фильтрации")
            return None
        
        logger.info(
            f"Подготовлены фильтры: "
            f"{len(character_ids)} персонажей, "
            f"{len(corporation_ids)} корпораций, "
            f"{len(alliance_ids)} альянсов"
        )
        
        return {
            'character_ids': character_ids,
            'corporation_ids': corporation_ids,
            'alliance_ids': alliance_ids
        }
    @classmethod
    def _matches_filter(cls, victim: Victim, filter_sets: Dict[str, Set[int]]) -> bool:
        """
        Проверяет, соответствует ли жертва фильтрам
        
        Args:
            victim: Объект Victim
            filter_sets: Словарь с множествами ID для фильтрации
        
        Returns:
            bool: True если жертва соответствует хотя бы одному фильтру
        """
        return (
            victim.char in filter_sets.get('character_ids', set()) or
            victim.corp in filter_sets.get('corporation_ids', set()) or
            victim.ally in filter_sets.get('alliance_ids', set())
        )
        
    @classmethod
    def parse_killmails_from_api(cls, response_json) -> List[Killmail]:
        """
        Парсит JSON-ответ API и возвращает список объектов Killmail
        """
        killmails = []
        filter_sets = cls._prepare_filter_sets(FilterEntity.objects.all())
               
        if isinstance(response_json, dict):
            data = response_json
        else:
            data = json.loads(response_json)

        '''
            Загружен один киллмэйл
        '''
        if 'vict' in data:
            victim_data = data['vict']
            required_victim_fields = ['char', 'corp', 'ally']
            if not all(field in victim_data for field in required_victim_fields):
                raise PartialReportError("Репорт не полностью сформирован. Необходимо подождать некоторое время.")
            
            victim = Victim(
                char=victim_data['char'],
                char_name='',  # Будет заполнено позже
                corp=victim_data['corp'],
                corp_name='',  # Будет заполнено позже
                ally=victim_data['ally'],
                ally_name='',  # Будет заполнено позже
                lossValue=data['sumV'],
                ship=victim_data['ship'],
                ship_name='',
            )
            
            # Применяем фильтрацию если заданы фильтры
            if filter_sets is not None:
                if not cls._matches_filter(victim, filter_sets):
                    return killmails
            '''Хордкодим фильтрацию капсул. Нужно будет создать доп фильтр'''
            if victim.ship == 670:
                return killmails
            
            required_km_fields = ['_id', 'sys', 'time']
            if not all(field in data for field in required_km_fields):
                return killmails
            
            killmail = Killmail(
                _id=data.get('_id'),
                id=data['_id'],
                system=data['sys']['id'],
                system_name=data['sys']['name'],  # Будет заполнено позже
                time=data['time'],
                victim=victim
            )
            killmails.append(killmail)
            return killmails
        
        '''
            Загружаем релейт
        '''
        if 'kms' in data:
            for km in data['kms']:
                if 'victim' not in km:
                    if 'vict' in km:
                        victim_data = km['vict']
                    else:
                        continue
                else:
                    victim_data = km['victim']
                
                required_victim_fields = ['char', 'corp', 'ally']
                if not all(field in victim_data for field in required_victim_fields):
                    raise PartialReportError("Репорт не полностью сформирован. Необходимо подождать некоторое время.")
                
                victim = Victim(
                    char=victim_data['char'],
                    char_name='',  # Будет заполнено позже
                    corp=victim_data['corp'],
                    corp_name='',  # Будет заполнено позже
                    ally=victim_data['ally'],
                    ally_name='',  # Будет заполнено позже
                    lossValue=victim_data['lossValue'] if 'lossValue' in victim_data else 0,
                    ship=victim_data['ship'],
                    ship_name='',
                )
                
                # Применяем фильтрацию если заданы фильтры
                if filter_sets is not None:
                    if not cls._matches_filter(victim, filter_sets):
                        continue
                '''Хордкодим фильтрацию капсул. Нужно будет создать доп фильтр'''
                if victim.ship == 670:
                    continue
                
                required_km_fields = ['id', 'system', 'time']
                if not all(field in km for field in required_km_fields):
                    continue
                
                killmail = Killmail(
                    _id=km.get('_id'),
                    id=km['id'],
                    system=km['system'],
                    system_name='',  # Будет заполнено позже
                    time=km['time'],
                    victim=victim
                )
                killmails.append(killmail)
            return killmails
        '''
            Загружен БР
        '''
        if 'relateds' not in data:
            print("⚠️ Внимание: В ответе нет поля 'relateds'")
            return killmails
        
        for related in data['relateds']:
            if 'kms' not in related:
                continue
                
            for km in related['kms']:
                try:
                    if 'victim' not in km:
                        if 'vict' in km:
                            victim_data = km['vict']
                        else:
                            continue
                    else:
                        victim_data = km['victim']
                    
                    required_victim_fields = ['char', 'corp', 'ally']
                    if not all(field in victim_data for field in required_victim_fields):
                        raise PartialReportError("Репорт не полностью сформирован. Необходимо подождать некоторое время.")
                    
                    victim = Victim(
                        char=victim_data['char'],
                        char_name='',  # Будет заполнено позже
                        corp=victim_data['corp'],
                        corp_name='',  # Будет заполнено позже
                        ally=victim_data['ally'],
                        ally_name='',  # Будет заполнено позже
                        lossValue=victim_data['lossValue'] if 'lossValue' in victim_data else 0,
                        ship=victim_data['ship'],
                        ship_name='',
                    )
                    
                    # Применяем фильтрацию если заданы фильтры
                    if filter_sets is not None:
                        if not cls._matches_filter(victim, filter_sets):
                            continue
                    '''Хордкодим фильтрацию капсул. Нужно будет создать доп фильтр'''
                    if victim.ship == 670:
                        continue
                  
                    
                    killmail = Killmail(
                        _id=km.get('id'),
                        id=km.get('id'),
                        system=km.get('sys') if 'sys' in km else km.get('system'),
                        system_name='',  # Будет заполнено позже
                        time=km.get('time'),
                        victim=victim
                    )
                    killmails.append(killmail)
                    
                except Exception as e:
                    print(f"⚠️ Ошибка при парсинге killmail: {e}")
                    continue
        return killmails
    
    @classmethod
    def enrich_killmails_with_names(cls, killmails: List[Killmail]) -> List[Killmail]:
        """
        Обогащает killmails названиями сущностей через ESI
        
        Собирает все уникальные ID из killmails (char, corp, ally, system),
        делает один запрос к ESI /universe/names и заполняет поля *_name
        """
        if not killmails:
            return killmails
        
        # Собираем все уникальные ID
        entity_ids = set()
        for km in killmails:
            entity_ids.add(km.system)
            entity_ids.add(km.victim.char)
            entity_ids.add(km.victim.corp)
            entity_ids.add(km.victim.ally)
            entity_ids.add(km.victim.ship)
        
        # Удаляем None или 0 если есть
        entity_ids.discard(0)
        entity_ids.discard(None)
        
        if not entity_ids:
            return killmails
        
        # Проверяем кэш
        cache_key = f"esi_universe_names_{'_'.join(map(str, sorted(entity_ids)))}"
        cached_names = cache.get(cache_key)
        
        if cached_names is not None:
            names_dict = cached_names
            logger.info(f"Использован кэш для {len(names_dict)} сущностей")
        else:
            try:
                # Делаем запрос к ESI /universe/names
                logger.info(f"Запрашиваем названия для {len(entity_ids)} сущностей из ESI")
                response = esi.client.Universe.post_universe_names(ids=list(entity_ids)).result()
                names_dict = {item['id']: item['name'] for item in response}
                cache.set(cache_key, names_dict, cls.CACHE_TIMEOUT)
                logger.info(f"Получены названия для {len(names_dict)} сущностей")
            except Exception as e:
                logger.error(f"Ошибка при получении названий из ESI: {e}")
                return killmails
        
        # Заполняем названия в объектах
        for km in killmails:
            km.system_name = names_dict.get(km.system, '')
            km.victim.char_name = names_dict.get(km.victim.char, '')
            km.victim.corp_name = names_dict.get(km.victim.corp, '')
            km.victim.ally_name = names_dict.get(km.victim.ally, '')
            km.victim.ship_name = names_dict.get(km.victim.ship, '')
        
        return killmails
    @classmethod
    def save_killmails(cls, killmails: List[Killmail]):
        for killmail in killmails:
            if KillCompensation.objects.filter(killmail_id = killmail.id).exists():
                logger.info('Киллмэйл уже есть в базе данных.')
                logger.debug(KillCompensation.objects.filter(killmail_id = killmail.id).first())
                continue
            timestamp = datetime.datetime.fromtimestamp(killmail.time, tz = pytz.UTC)
            entity = KillCompensation(killmail_id=killmail.id,
                                      character_id=killmail.victim.char,
                                      character_name=killmail.victim.char_name,
                                      alliance_id=killmail.victim.ally,
                                      alliance_name=killmail.victim.ally_name,
                                      corporation_id=killmail.victim.corp,
                                      corporation_name=killmail.victim.corp_name,
                                      loss_value=killmail.victim.lossValue,
                                      timestamp=timestamp,
                                      system=killmail.system,
                                      system_name=killmail.system_name,
                                      ship_type=killmail.victim.ship,
                                      ship_name=killmail.victim.ship_name)
            entity.save()
            logger.info(f'Сохранен килл {killmail.id}')
