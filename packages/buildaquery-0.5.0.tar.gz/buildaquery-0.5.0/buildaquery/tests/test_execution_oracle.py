import pytest
from unittest.mock import MagicMock, patch

from buildaquery.execution.oracle import OracleExecutor
from buildaquery.compiler.compiled_query import CompiledQuery

@pytest.fixture
def mock_oracledb():
    with patch("buildaquery.execution.oracle.OracleExecutor._get_oracledb") as mock:
        mock_module = MagicMock()
        mock.return_value = mock_module
        yield mock_module

def test_oracle_executor_fetch_all(mock_oracledb):
    executor = OracleExecutor(connection_info="oracle://user:pass@localhost:1521/XEPDB1")
    query = CompiledQuery(sql="SELECT :1 FROM dual", params=[1])

    mock_conn = mock_oracledb.connect.return_value
    mock_cursor = mock_conn.cursor.return_value
    mock_cursor.fetchall.return_value = [(1,)]

    results = executor.fetch_all(query)

    assert results == [(1,)]
    mock_oracledb.connect.assert_called_once()
    mock_cursor.execute.assert_called_once_with("SELECT :1 FROM dual", [1])
    mock_cursor.fetchall.assert_called_once()
    mock_cursor.close.assert_called_once()
    mock_conn.close.assert_called_once()

def test_oracle_executor_execute(mock_oracledb):
    executor = OracleExecutor(connection_info="oracle://user:pass@localhost:1521/XEPDB1")
    query = CompiledQuery(sql="INSERT INTO t VALUES (:1)", params=[10])

    mock_conn = mock_oracledb.connect.return_value
    mock_cursor = mock_conn.cursor.return_value

    executor.execute(query)

    mock_cursor.execute.assert_called_once_with("INSERT INTO t VALUES (:1)", [10])
    mock_conn.commit.assert_called_once()
    mock_cursor.close.assert_called_once()
    mock_conn.close.assert_called_once()

def test_oracle_executor_import_error():
    executor = OracleExecutor(connection_info="oracle://user:pass@localhost:1521/XEPDB1")

    with patch("buildaquery.execution.oracle.importlib.import_module", side_effect=ImportError("oracledb not found")):
        with pytest.raises(ImportError) as excinfo:
            executor._get_oracledb()
        assert "oracledb" in str(excinfo.value)
