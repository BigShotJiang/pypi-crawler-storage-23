// JS: index.js


document.addEventListener('DOMContentLoaded', () => {
    // ...
});


// EOF - index.js
