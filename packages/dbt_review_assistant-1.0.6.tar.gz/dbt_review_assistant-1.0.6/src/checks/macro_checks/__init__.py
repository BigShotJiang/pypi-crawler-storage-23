"""Macro checks."""
