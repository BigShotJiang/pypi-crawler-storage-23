# filesystem-integration

Biblioteka służy do obsługi plików z mikroserwisu do twojego projektu.

## Instalacja

Postaw kontenery z mikroserwisem
https://github.com/gufi2115/Microservice-to-save-files

``pip install filesystempack``

## Jak używać


```from filesystempack.filesystem import Filesystem```

Storzenie instancji na przykład w helpers.py

```file_system = Filesystem(url="http://host:6767/api/file/", api_key=twój_api_key_z_mikroserwisu)```

POST

``uuid = file_system.save_file(file=plik, content_type=mime_type_opcjonalnie)``

GET

``file, content_type = file_system.get_file(uuid)``

DELETE

``delete = file_system.delete_file(uuid)``

status 

``status = file_system.status``