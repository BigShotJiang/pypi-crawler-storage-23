from rest_framework.viewsets import ModelViewSet
from .models import FileInfoM
from .serializers import FileSerializer
from .helpers import file_system
from django.http.response import FileResponse
from rest_framework.response import Response

class FileViewSet(ModelViewSet):
    queryset = FileInfoM.objects.all()
    serializer_class = FileSerializer

    def retrieve(self, request, *args, **kwargs):
        instance = self.get_object()

        file, content_type = file_system.get_file(uuid=instance.file_uuid)
        status = file_system.status
        if status == 200:
            return FileResponse(file=file, content_type=content_type)
        elif (status := int(status[:4])) >= 400:
            return Response(status=status)
        else:
            raise Exception(status)

    def destroy(self, request, *args, **kwargs):
        instance = self.get_object()
        delete_file = file_system.delete_file(uuid=instance.file_uuid)
        status = file_system.status
        if status == 204:
            return Response(status=status)
        elif (status := int(status[:4])) >= 400:
            return Response(status=status)
        else:
            raise Exception(status)

