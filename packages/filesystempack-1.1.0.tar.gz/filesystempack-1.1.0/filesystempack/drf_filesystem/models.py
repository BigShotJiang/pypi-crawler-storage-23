from django.db import models

class FileInfoM(models.Model):
    file_uuid = models.UUIDField(unique=True)
    file_type = models.CharField(max_length=100)

    class Meta:
        abstract = True