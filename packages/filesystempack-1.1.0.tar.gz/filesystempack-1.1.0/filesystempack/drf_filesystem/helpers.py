from ..filesystem import FileSystem
from django.conf import settings

if hasattr(settings, 'FILES_MICROSERVICE_URL') and hasattr(settings, 'FILES_MICROSERVICE_API_KEY'):
    file_system = FileSystem(url=settings.FILES_MICROSERVICE_URL, api_key=settings.FILES_MICROSERVICE_API_KEY)
else:
    raise Exception('Incorrect variables in settings')
