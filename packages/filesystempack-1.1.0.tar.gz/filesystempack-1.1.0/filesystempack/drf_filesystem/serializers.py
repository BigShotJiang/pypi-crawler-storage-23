from rest_framework import serializers
from .models import FileInfoM
from .helpers import file_system


class FileSerializer(serializers.ModelSerializer):
    file = serializers.FileField(write_only=True, required=True)

    class Meta:
        model = FileInfoM
        fields = ('file_uuid', 'file_type')
        extra_kwargs = {'file_uuid': {'read_only': True}, 'file_type': {'read_only': True}}

    def create(self, validated_data):
        file = validated_data['file']
        file_type = file.content_type
        try:
            file_uuid = file_system.save_file(file=file, content_type=file_type)
            validated_data['file_uuid'] = file_uuid
            validated_data['file_type'] = file_type
            return super().create(validated_data)
        except Exception as e:
            raise e
