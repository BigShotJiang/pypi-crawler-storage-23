import niquests
import magic
from urllib3.exceptions import MaxRetryError, NewConnectionError


class FileSystem:
    def __init__(self, url, api_key):
        self.url = url
        self.api_key = api_key
        self._status = None
        self._content_type = None

    def _api_key_headers(self):
        return {'Authorization': f'api-key {self.api_key}'}

    @property
    def status(self):
        return self._status

    def get_file(self, uuid):
        file, status = self.__requests_handling(method='get',uuid=uuid, stream=True)
        self._status = status
        return file, self._content_type

    def save_file(self, file, content_type=None):
        if not content_type:
            if hasattr(file, 'content_type'):
                content_type = file.content_type
            else:
                file.seek(0)
                content_type = magic.Magic(mime=True).from_buffer(file.read(2048))
                file.seek(0)
        data = {
            'file': (file.name, file, content_type),
        }
        uuid, status = self.__requests_handling(method='post', data=data)
        self._status = status
        return uuid

    def delete_file(self, uuid):
        status = self.__requests_handling(method='delete', uuid=uuid)
        self._status = status

    def __requests_handling(self, method, uuid=None, data=None, stream=None):
        headers = self._api_key_headers()
        url = self.url
        if uuid:
            url = self.url + f"{uuid}" + '/'
        if hasattr(niquests, method):
            try:
                r = getattr(niquests, method)(url=url, headers=headers, files=data, stream=stream)
                status = r.status_code
                if data and status == 201:
                    return str(r.json()['id']), status
                elif uuid and status == 200:
                    self._content_type = r.headers.get('content-type')
                    file = r.raw
                    return file, status
                elif uuid and status == 204:
                    return status
                r.raise_for_status()
            except niquests.HTTPError as e:
                if method == 'delete':
                    return f"{e.response.status_code} {e.response.reason}"
                return None, f"{e.response.status_code} {e.response.reason}"
            except niquests.ConnectionError as e:
                if method == 'delete':
                    return f"Connection Error: {e}"
                return None, f"Connection Error: {e}"
            except MaxRetryError as e:
                if method == 'delete':
                    return  f"Max Retry Error: {e}"
                return None, f"Max Retry Error: {e}"
            except NewConnectionError as e:
                if method == 'delete':
                    return  f"New Connection Error: {e}"
                return None, f"New Connection Error: {e}"
            except niquests.RequestException as e:
                if method == 'delete':
                    return f"Request Exception: {e}"
                return None, f"Request Exception: {e}"
            except Exception as e:
                if method == 'delete':
                    return f"Exception: {e}"
                return None, f"Exception: {e}"
        else:
            return None, f"niquests have not {method} method"
