from filesystempack.filesystem import FileSystem
from pathlib import Path

class TestFileSystem:
    def test_api_key_headers(self):
        file_system = FileSystem(url='http://100.64.0.1:6767/api/file/', api_key='32533b40-50e0-4267-8069-6e2af0944a88')
        api_key = file_system._api_key_headers()
        assert 'api-key 32533b40-50e0-4267-8069-6e2af0944a88' == api_key['Authorization']

    def test_save_file(self):
        base_dir = Path(__file__).resolve().parent.parent
        file = open(Path(base_dir / 'tests/test_files/test_file.png'), 'rb')
        file_system= FileSystem(url='http://100.64.0.1:6767/api/file/', api_key="32533b40-50e0-4267-8069-6e2af0944a88")
        save_file_uuid = file_system.save_file(file=file)
        print(save_file_uuid, file_system.status)
        assert save_file_uuid is not None
        assert file_system.status == 201

    def test_get_file(self):
        file_system = FileSystem(url='http://100.64.0.1:6767/api/file/', api_key='32533b40-50e0-4267-8069-6e2af0944a88')
        file, content_type= file_system.get_file(uuid='0b0718d3-b3ee-445d-a0a4-fa1fca56fb58')
        assert file is not None
        assert content_type == 'image/png'
        assert file_system.status == 200

    def test_delete_file(self):
        file_system = FileSystem(url='http://100.64.0.1:6767/api/file/', api_key='32533b40-50e0-4267-8069-6e2af0944a88')
        file_system.delete_file(uuid='0b0718d3-b3ee-445d-a0a4-fa1fca56fb58')
        assert file_system.status == 204
