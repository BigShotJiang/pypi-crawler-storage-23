from docutils.nodes import Element, General, Inline, Node


class svgbob(General, Inline, Element):
    pass
