#![allow(dead_code, unused_imports)]

use pyo3::prelude::*;

include!(concat!(env!("OUT_DIR"), "/built.rs"));
