import json
from pathlib import Path

from PIL import Image

from ..metadata.drac_report_builder import DracReportBuilder


def test_escape_characters():
    report = DracReportBuilder(dataset_type="demo")
    escaped = report.escape_characters("AÅ\nB° <&>")
    assert "&Aring;" in escaped
    assert "&deg;" in escaped
    assert "<br>" in escaped
    assert "&lt;&amp;&gt;" in escaped


def test_render_json_and_html(tmp_path):
    report = DracReportBuilder(dataset_type="demo", dataset_title="Demo Report")
    report.add_info("Info line")
    report.add_warning("Warn line")
    report.add_table(
        title="Sample Table",
        columns=["Name", "Value"],
        data=[["Alpha", 1], ["Beta", 2]],
    )
    log_path = tmp_path / "log.txt"
    log_path.write_text("Log <unsafe>", encoding="utf-8")
    report.add_log_file("Log", "View log", str(log_path))

    json_path = Path(report.render_json(str(tmp_path)))
    assert json_path.exists()
    data = json.loads(json_path.read_text(encoding="utf-8"))
    assert data["title"] == "Demo Report"
    assert [item["type"] for item in data["items"]] == [
        "info",
        "warning",
        "table",
        "logFile",
    ]

    html_path = Path(report.render_html(str(tmp_path)))
    assert html_path.exists()
    html_text = html_path.read_text(encoding="utf-8")
    assert "Demo Report" in html_text
    assert "Info line" in html_text
    assert "Warn line" in html_text
    assert "View log" in html_text
    assert "<table" in html_text

    log_htmls = sorted(tmp_path.glob("Log*.html"))
    assert log_htmls
    log_html_text = log_htmls[0].read_text(encoding="utf-8")
    assert "&lt;unsafe&gt;" in log_html_text


def test_render_image_in_html(tmp_path):
    image_path = tmp_path / "sample.png"
    Image.new("RGB", (8, 6), color=(255, 0, 0)).save(image_path)

    report = DracReportBuilder(dataset_type="demo", dataset_title="Demo Report")
    report.add_image(str(image_path), image_title="Sample Image")

    json_path = Path(report.render_json(str(tmp_path)))
    data = json.loads(json_path.read_text(encoding="utf-8"))
    assert data["items"][-1]["type"] == "image"
    assert data["items"][-1]["value"]

    html_path = Path(report.render_html(str(tmp_path)))
    assert html_path.exists()
    html_text = html_path.read_text(encoding="utf-8")
    assert "<img" in html_text
    assert "Sample_Image.png" in html_text

    rendered_image = tmp_path / "Sample_Image.png"
    assert rendered_image.exists()
    assert rendered_image.stat().st_size > 0


def test_render_image_with_thumbnail(tmp_path):
    image_path = tmp_path / "sample.png"
    thumbnail_path = tmp_path / "thumbnail.png"
    Image.new("RGB", (8, 6), color=(255, 0, 0)).save(image_path)
    Image.new("RGB", (4, 3), color=(0, 255, 0)).save(thumbnail_path)

    report = DracReportBuilder(dataset_type="demo", dataset_title="Demo Report")
    report.add_image(
        str(image_path),
        image_title="Sample Image",
        path_to_thumbnail_image=str(thumbnail_path),
    )

    json_path = Path(report.render_json(str(tmp_path)))
    data = json.loads(json_path.read_text(encoding="utf-8"))
    assert data["items"][-1]["type"] == "image"
    assert data["items"][-1]["thumbnailValue"]

    html_path = Path(report.render_html(str(tmp_path)))
    assert html_path.exists()
    html_text = html_path.read_text(encoding="utf-8")
    assert "<img" in html_text
    assert "Sample_Image_thumbnail.png" in html_text

    rendered_thumbnail = tmp_path / "Sample_Image_thumbnail.png"
    assert rendered_thumbnail.exists()
    assert rendered_thumbnail.stat().st_size > 0
