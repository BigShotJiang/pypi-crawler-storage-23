"""Factories for generating functions which can produce KCells or VKCells."""

from typing import TYPE_CHECKING, Any, Protocol

from ..instance import ProtoTInstance
from ..instance_group import ProtoTInstanceGroup
from ..kcell import ProtoTKCell
from ..typings import dbu, um
from . import bezier, circular, euler, straight, taper, virtual

if TYPE_CHECKING:
    from ..kcell import ProtoTKCell


class StraightFactoryDBU(Protocol):
    """Factory Protocol for routing.

    A straight factory must return a KCell with only a width and length given.
    """

    def __call__(self, width: int, length: int) -> ProtoTKCell[Any]:
        """Produces the KCell.

        E.g. in a function this would amount to
        `straight_factory(length=10_000, width=1000)`
        """
        ...


class StraightFactoryUM(Protocol):
    """Factory Protocol for routing.

    A straight factory must return a KCell with only a width and length given.
    """

    def __call__(self, width: float, length: float) -> ProtoTKCell[Any]:
        """Produces the KCell.

        E.g. in a function this would amount to
        `straight_factory(length=10_000, width=1000)`
        """
        ...


class SBendFactoryDBU(Protocol):
    def __call__(
        self, *, c: ProtoTKCell[Any], offset: dbu, length: dbu, width: dbu
    ) -> ProtoTInstance[Any] | ProtoTInstanceGroup[Any, Any]: ...


class SBendFactoryUM(Protocol):
    def __call__(
        self, *, c: ProtoTKCell[Any], offset: um, length: um, width: um
    ) -> ProtoTInstance[Any] | ProtoTInstanceGroup[Any, Any]: ...


__all__ = [
    "StraightFactoryDBU",
    "StraightFactoryUM",
    "bezier",
    "circular",
    "euler",
    "straight",
    "taper",
    "virtual",
]
