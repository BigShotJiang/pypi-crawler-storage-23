"""Entry point for `python -m pinger`."""
from pinger import main

main()
