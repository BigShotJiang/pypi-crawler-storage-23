"""Base client infrastructure for Function Apps.

This module provides the BaseFunctionClient class, which contains all shared
infrastructure for making HTTP calls to devservers and deployed Cognite Functions.
Both the dynamic FunctionClient and generated typed clients inherit from this base class.

The base class handles:
- Initialization for both devserver and deployed function modes
- HTTP calls via httpx (devserver) or the cognite SDK session (deployed)
- Session nonce creation via CogniteClient (deployed mode)
- System endpoint path mapping (deployed mode)
- Response unwrapping and error handling
- Deserialization of responses into Pydantic models
"""

import inspect
import re
import sys
from typing import Any, cast, overload
from urllib.parse import quote

from cognite.client import CogniteClient
from cognite.client.exceptions import CogniteException
from pydantic import BaseModel

from .models import CogniteFunctionError, CogniteFunctionResponse, HTTPMethod

# Optional OpenTelemetry support for trace propagation
try:
    from opentelemetry.propagate import inject as _otel_inject
except ImportError:

    def _otel_inject(*args: Any, **kwargs: Any) -> None:
        """No-op inject when OpenTelemetry not installed."""
        pass


# System endpoint path mapping: internal framework paths -> real API paths
_SYSTEM_PATH_MAP: dict[str, str] = {
    "/__client_methods__": "/-/client-methods",
    "/__schema__": "/-/openapi.json",
    "/__routes__": "/-/routes",
    "/__health__": "/-/health",
    "/__ping__": "/-/ping",
}


class BaseFunctionClient:
    """Base class for Cognite Function App clients.

    Provides shared infrastructure for both dynamic and generated clients:
    - HTTP calling via httpx (devserver) or the cognite SDK session (deployed)
    - Session nonce creation via CogniteClient (deployed mode)
    - Response unwrapping and error handling
    - Model deserialization

    Supports two modes:
    1. Local devserver: Pass base_url only (e.g., 'http://localhost:8000')
    2. Deployed function: Pass cognite_client + function_external_id
    """

    base_url: str
    _project: str | None
    _function_external_id: str | None
    _cognite_client: CogniteClient | None
    _timeout: float

    @overload
    def __init__(self, *, base_url: str, timeout: float = ...) -> None: ...

    @overload
    def __init__(
        self,
        *,
        cognite_client: CogniteClient,
        function_external_id: str,
        timeout: float = ...,
    ) -> None: ...

    def __init__(
        self,
        *,
        base_url: str | None = None,
        function_external_id: str | None = None,
        cognite_client: CogniteClient | None = None,
        timeout: float = 600.0,
    ) -> None:
        """Initialize the client.

        Args:
            base_url: Devserver URL, e.g. 'http://localhost:8000'.
            function_external_id: External ID of the deployed function (required with cognite_client).
            cognite_client: A CogniteClient instance. When provided, base_url, project,
                and credentials are extracted automatically from the client's configuration.
            timeout: HTTP request timeout in seconds. Applied to all requests including
                session nonce creation. Defaults to 600.0 (10 minutes) to accommodate
                long-running functions.

        Raises:
            ValueError: If invalid parameter combination is provided.

        Example:
            # Local devserver
            client = BaseFunctionClient(base_url="http://localhost:8000")

            # Deployed function via CogniteClient
            from cognite.client import CogniteClient
            client = BaseFunctionClient(
                cognite_client=CogniteClient(...),
                function_external_id="my-function",
                timeout=120.0,
            )
        """
        if cognite_client is not None:
            if function_external_id is None:
                raise ValueError("function_external_id is required when cognite_client is provided")
            self.base_url = cognite_client.config.base_url.rstrip("/")
            self._project = cognite_client.config.project
            self._function_external_id = function_external_id
            self._cognite_client = cognite_client
        elif base_url is not None:
            self.base_url = base_url.rstrip("/")
            self._project = None
            self._function_external_id = None
            self._cognite_client = None
        else:
            raise ValueError(
                "Either base_url (devserver) or cognite_client + function_external_id (deployed) must be provided"
            )

        self._timeout = timeout

    def _get_token(self) -> str:
        """Get the current access token from the CogniteClient credentials.

        Returns:
            Access token string.

        Raises:
            RuntimeError: If no CogniteClient is configured.
            ValueError: If the authorization header format is unexpected.
        """
        if self._cognite_client is None:
            raise RuntimeError("No cognite_client configured")
        _, auth_value = self._cognite_client.config.credentials.authorization_header()
        if not auth_value.startswith("Bearer "):
            raise ValueError(f"Unexpected authorization header format. Expected 'Bearer <token>', got '{auth_value}'")
        return auth_value.removeprefix("Bearer ")

    def _create_session_nonce(self) -> str:
        """Create a session and return the nonce.

        Nonces are single-use -- a fresh one must be created before each API call.
        Delegates to the CogniteClient's session API so that token exchange, refresh,
        and interactive login are handled entirely by the SDK.

        Returns:
            Session nonce string.

        Raises:
            RuntimeError: If session creation fails.
        """
        if self._cognite_client is None:
            raise RuntimeError("No cognite_client configured")
        try:
            return self._cognite_client.iam.sessions.create().nonce
        except CogniteException as e:
            raise RuntimeError(f"Session creation failed: {e}") from e

    def _map_system_path(self, path: str) -> str:
        """Map internal framework paths to real API paths for deployed mode.

        Args:
            path: Internal path (e.g., '/__schema__').

        Returns:
            Mapped API path (e.g., '/-/openapi.json'), or the original path
            if no mapping exists.
        """
        return _SYSTEM_PATH_MAP.get(path, path)

    def _call_api(
        self,
        path: str,
        method: HTTPMethod,
        body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Call the real Function Apps API (deployed mode).

        Creates a fresh session nonce for each call, then routes the request through
        the CogniteClient's public HTTP methods. This ensures correct proxy, SSL,
        auth, and retry behaviour in all environments including Fusion notebooks.

        Args:
            path: Endpoint path (e.g., '/items/123' or '/__schema__').
            method: HTTP method.
            body: Request body for POST/PUT.
            params: Query parameters.

        Returns:
            Response JSON (already unwrapped by the API gateway).

        Raises:
            CogniteAPIError: If the HTTP request fails.
            RuntimeError: If session creation fails.
            NotImplementedError: If the HTTP method has no public SDK equivalent.
        """
        if self._cognite_client is None:
            raise RuntimeError("CogniteClient is not configured.")
        nonce = self._create_session_nonce()

        # Map system paths to real API paths
        api_path = self._map_system_path(path)

        project = quote(str(self._project), safe="")
        ext_id = quote(str(self._function_external_id), safe="")
        # Build the path only — the SDK prepends base_url automatically
        url_path = f"/api/v1/projects/{project}/function-apps/{ext_id}{api_path}"

        # Extra headers beyond what the SDK already injects (auth is handled by the SDK)
        headers: dict[str, str] = {
            "X-Session-Nonce": nonce,
            "x-cdf-traffic-source": "external",
        }
        _otel_inject(headers)

        json_body = body if method in {HTTPMethod.POST, HTTPMethod.PUT} else None

        # Use CogniteClient's public HTTP methods — they use the SDK's configured
        # session (correct proxy, SSL, auth, retries) for all environments.
        resp: Any
        match method:
            case HTTPMethod.GET:
                resp = self._cognite_client.get(url_path, params=params, headers=headers)
            case HTTPMethod.POST:
                resp = self._cognite_client.post(url_path, json=json_body or {}, headers=headers)
            case HTTPMethod.PUT:
                resp = self._cognite_client.put(url_path, json=json_body or {}, headers=headers)
            case HTTPMethod.DELETE:
                resp = self._cognite_client.delete(url_path, params=params, headers=headers)
            case _:
                # CogniteClient's public API only exposes GET/POST/PUT/DELETE.
                # PATCH (and any future methods) cannot be routed through it.
                raise NotImplementedError(
                    f"HTTP method {method.value} is not supported in deployed mode — "
                    "CogniteClient does not expose a public patch() method."
                )

        if resp.status_code == 204:  # No Content — body is empty
            return None
        try:
            return resp.json()
        except ValueError as e:
            raise RuntimeError(f"Failed to decode JSON response: {e}") from e

    def _call_devserver(
        self,
        path: str,
        method: HTTPMethod,
        body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Call local devserver using httpx.

        Args:
            path: Path to call (e.g., "/items/123")
            method: HTTP method (GET, POST, PUT, DELETE, PATCH)
            body: Request body for POST/PUT
            params: Query parameters for GET

        Returns:
            Raw response from HTTP call

        Raises:
            httpx.HTTPStatusError: If HTTP request fails
        """
        import httpx  # noqa: PLC0415 — lazy import: only needed in devserver mode

        url = f"{self.base_url}{path}"
        headers: dict[str, str] = {}
        _otel_inject(headers)  # Injects traceparent header if active span exists, no-op if no tracing is active.

        response = httpx.request(
            method=method.value,
            url=url,
            params=params if method == HTTPMethod.GET else None,
            json=body if method in {HTTPMethod.POST, HTTPMethod.PUT, HTTPMethod.PATCH} else None,
            headers=headers,
            timeout=self._timeout,
        )
        response.raise_for_status()
        if response.status_code == 204:  # No Content — body is empty
            return None
        try:
            return response.json()
        except ValueError as e:
            raise RuntimeError(f"Failed to decode JSON response: {e}") from e

    def _call_method(
        self,
        path: str,
        method: HTTPMethod,
        body: dict[str, Any] | None = None,
        params: dict[str, Any] | None = None,
    ) -> Any:
        """Dispatch method call to appropriate backend and unwrap response.

        Args:
            path: Path to call (e.g., "/items/123")
            method: HTTP method (GET, POST, PUT, DELETE, PATCH)
            body: Request body for POST/PUT
            params: Query parameters for GET

        Returns:
            Unwrapped response data

        Raises:
            RuntimeError: If response indicates an error
        """
        if self._cognite_client is not None:
            return self._call_api(path, method, body, params)

        # Devserver mode: get wrapped response and unwrap
        result = self._call_devserver(path, method, body, params)

        # Unwrap Cognite Functions response format
        # Use status_code < 400 to determine success (new wire format)
        status_code: int | None = None
        if isinstance(result, dict):
            result = cast(dict[str, Any], result)
            raw_status = result.get("status_code")
            if isinstance(raw_status, int):
                status_code = raw_status
        if status_code is None or status_code >= 400:
            error = CogniteFunctionError.model_validate(result)
            raise RuntimeError(f"{error.error_type}: {error.message}")

        typed_response = CogniteFunctionResponse.model_validate(result)
        return typed_response.data  # type: ignore[reportReturnType]

    def _deserialize_response(self, data: Any, return_type: str) -> Any:
        """Deserialize response data into Pydantic models if applicable.

        This method looks up model classes in the subclass's module namespace and
        validates responses against them if the return type matches a Pydantic model.

        Args:
            data: Raw response data
            return_type: String representation of the return type

        Returns:
            Deserialized data if a Pydantic model, otherwise raw data
        """
        # Get the module namespace where the actual client class is defined
        # This allows us to find models defined in generated clients
        module_namespace = sys.modules[type(self).__module__].__dict__

        if return_type.startswith("list["):
            # Handle list responses - extract model name
            if match := re.search(r"list\[([A-Z][a-zA-Z0-9_]*)\]", return_type):
                model_name = match.group(1)
                if model_name in module_namespace:
                    model_class = module_namespace[model_name]
                    # Verify it's actually a Pydantic model class
                    if inspect.isclass(model_class) and issubclass(model_class, BaseModel):
                        if isinstance(data, list):
                            return [model_class.model_validate(item) for item in cast(list[Any], data)]
        elif return_type and return_type[0].isupper():
            # Single model response - check if it's a known model
            # Extract base type name (e.g., "Item" from "Item")
            if match := re.search(r"^([A-Z][a-zA-Z0-9_]*)", return_type):
                model_name = match.group(1)
                if model_name in module_namespace:
                    model_class = module_namespace[model_name]
                    # Verify it's actually a Pydantic model class
                    if inspect.isclass(model_class) and issubclass(model_class, BaseModel):
                        return model_class.model_validate(data)

        return data
