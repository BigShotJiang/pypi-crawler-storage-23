"""Jinja2 templates for client code generation."""
