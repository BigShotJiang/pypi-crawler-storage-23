# Changelog

## [0.8.0](https://github.com/cognitedata/cognite-function-apps/compare/cognite-function-apps-v0.7.0...cognite-function-apps-v0.8.0) (2026-02-27)


### ⚠ BREAKING CHANGES

* The token, cdf_cluster, and project parameters have been removed from BaseFunctionClient and FunctionClient. Deployed-mode callers must now pass cognite_client + function_external_id. This enables correct HTTP routing in Fusion notebooks and removes the need to manage credentials manually.

### Features

* require CogniteClient for deployed mode, drop token/cdf_cluster/project params ([6aba844](https://github.com/cognitedata/cognite-function-apps/commit/6aba8444b4b5a6375695406fcc6df32fea96e9ed))


### Bug Fixes

* remove stale _is_deployed reference from RuntimeError message ([0b898f6](https://github.com/cognitedata/cognite-function-apps/commit/0b898f6daaf062ba6d9c2219d17da2906c2b135b))
* replace assert with explicit RuntimeError guard in _call_api ([f687e4d](https://github.com/cognitedata/cognite-function-apps/commit/f687e4dcd690ac85e476b0c58c75bf54efd75aa7))


### Code Refactoring

* lazy-import httpx so deployed mode has no httpx dependency ([adf540c](https://github.com/cognitedata/cognite-function-apps/commit/adf540ca19d095cfbb19860fa173cdd3e21a6db7))
* make CogniteClient the only option for deployed mode ([b3f6514](https://github.com/cognitedata/cognite-function-apps/commit/b3f65140966e59bb73e0ae3a9f5fa41da9d2e5fa))
* make CogniteClient the only option for deployed mode ([406f249](https://github.com/cognitedata/cognite-function-apps/commit/406f24923e44b86b071ff3765a7edde0ecb34497))
* remove redundant _is_deployed flag, improve PATCH error message, fix stale docstring ([11e325f](https://github.com/cognitedata/cognite-function-apps/commit/11e325f6d35fb67cd9da13bbb786594fb3787bbf))

## [0.7.0](https://github.com/cognitedata/cognite-function-apps/compare/cognite-function-apps-v0.6.1...cognite-function-apps-v0.7.0) (2026-02-27)


### Features

* add CogniteClient constructor overload for auth setup ([c5d11fd](https://github.com/cognitedata/cognite-function-apps/commit/c5d11fd27cbfe479c75eaec54ce6f495c64d947b))
* client SDK - direct HTTP transport with CogniteClient auth ([374d6b2](https://github.com/cognitedata/cognite-function-apps/commit/374d6b286c941a11b596dc71ef5a0c08502b76ef))
* FastAPI parity for single list[Model] body parameter ([8ad8fe3](https://github.com/cognitedata/cognite-function-apps/commit/8ad8fe36c97c226eec1cdcd87eb71bdead07e1c4))
* support eu.honeycomb and fail gracefully on missing tracing key FUN-759  ([#20](https://github.com/cognitedata/cognite-function-apps/issues/20)) ([29fd6b6](https://github.com/cognitedata/cognite-function-apps/commit/29fd6b65c0b65f329988ce5241b78d44bb29e4df))
* use CogniteClient SDK for session creation ([ec84340](https://github.com/cognitedata/cognite-function-apps/commit/ec843404501ca7985b5045802ae37c87b827ca6b))


### Bug Fixes

* add Literal/typing imports and normalize Json in method signatures ([b8ed98d](https://github.com/cognitedata/cognite-function-apps/commit/b8ed98d26c0cb6dafe2d1c912c5a38c7e136eca9))
* add missing httpx import in client.py ([6249909](https://github.com/cognitedata/cognite-function-apps/commit/624990932e2419adad39a8c6a32bd5259814a9d5))
* add missing pydantic imports and support recursive models in generated clients ([86d31bf](https://github.com/cognitedata/cognite-function-apps/commit/86d31bf8e5996a47a03ad56713009a110b53d042))
* add type-narrowing assertions to pass pyright checks ([4019057](https://github.com/cognitedata/cognite-function-apps/commit/4019057a71d619f7e06c3e9cbca4304a63034823))
* align body param handling between schema and dispatcher ([67ba785](https://github.com/cognitedata/cognite-function-apps/commit/67ba7853cc2a7558ea772915a81f48b5073d5aef))
* align body param handling between schema and dispatcher ([a881363](https://github.com/cognitedata/cognite-function-apps/commit/a8813637fa6eeb88386924f8064ca753b349eef4))
* correct single Pydantic body param detection logic ([2cfe9dd](https://github.com/cognitedata/cognite-function-apps/commit/2cfe9dd7db19e4eaeb8dc3700fe1e56b5b596168))
* handle 204 No Content responses in _call_api and _call_devserver ([0f01972](https://github.com/cognitedata/cognite-function-apps/commit/0f019726fccf7c1e1742818064ad31e22c16dfd5))
* handle unwrapped body when param name coincides with model field name ([bb9487a](https://github.com/cognitedata/cognite-function-apps/commit/bb9487a169946e787ef5fedfe1bd205235389efc))
* ignore request body for GET and DELETE methods ([8f1f6f7](https://github.com/cognitedata/cognite-function-apps/commit/8f1f6f7ecb759a19b58917cda66ee6d91e4ce79e))
* make HTTP timeout configurable, default to 600s ([3a9b6bd](https://github.com/cognitedata/cognite-function-apps/commit/3a9b6bd5c685762a18272f033b001e6d3be6167b))
* preserve **kwargs params when filtering function arguments ([2a8c792](https://github.com/cognitedata/cognite-function-apps/commit/2a8c792bf70b0e535a55848a4b29f81c88dd2795))
* resolve syntax error in _token_from_cognite_client ([e1c7a57](https://github.com/cognitedata/cognite-function-apps/commit/e1c7a57397330b943a2aded2dd7d7a176cd9b0be))
* scan method signatures for pydantic types when augmenting imports ([b212996](https://github.com/cognitedata/cognite-function-apps/commit/b2129961484b2567cb725cdeefa25de130cbf07a))
* split long URL line to satisfy E501 line length limit ([4939734](https://github.com/cognitedata/cognite-function-apps/commit/4939734a0ff0b46a21cc53c3f343e2c5c8be56a7))
* url-encode project and external_id in API paths, fix double token fetch, drop type:ignore from template ([b67c6b9](https://github.com/cognitedata/cognite-function-apps/commit/b67c6b96f0be6a527ea066244277be9e2126b990))
* use match statement for base_url resolution and lowercase regex variable ([5bbe976](https://github.com/cognitedata/cognite-function-apps/commit/5bbe976abe4c05192b22e0a690d0e8aefbdd0118))
* wrap response.json() in try/except for invalid JSON bodies ([6423080](https://github.com/cognitedata/cognite-function-apps/commit/64230805c792920f81b9c7fba56d048431fc7963))


### Code Refactoring

* consolidate sequence-of-pydantic check on RequestData ([c0e40d9](https://github.com/cognitedata/cognite-function-apps/commit/c0e40d9a66e231f3892451f441af1e7c7aba54ab))
* derive pydantic/typing detectable names from modules dynamically ([b8e33e3](https://github.com/cognitedata/cognite-function-apps/commit/b8e33e3c75c56e2a5424a3e7781dbba6116017eb))
* use raise_for_status() in _create_session_nonce ([62d2ca6](https://github.com/cognitedata/cognite-function-apps/commit/62d2ca66d1b8833ba572013d38ddac102f1cadea))

## [0.6.1](https://github.com/cognitedata/cognite-function-apps/compare/cognite-function-apps-v0.6.0...cognite-function-apps-v0.6.1) (2026-01-20)


### Bug Fixes

* exclude dependency parameters from MCP schema with PEP 563/649 annotations ([b9c1772](https://github.com/cognitedata/cognite-function-apps/commit/b9c17729753652ac1c49f391455ad9e34e697579))
* exclude dependency parameters with PEP 563/649 annotations ([fb862cb](https://github.com/cognitedata/cognite-function-apps/commit/fb862cb554ea0fea74229235a2b3836d659572eb))
* handle PEP 563/649 string annotations in dependency injection ([a22a190](https://github.com/cognitedata/cognite-function-apps/commit/a22a190f7e33b0e8da54e7cee085e9464213cdde))

## [0.6.0](https://github.com/cognitedata/cognite-function-apps/compare/cognite-function-apps-v0.5.3...cognite-function-apps-v0.6.0) (2025-12-19)

### ⚠ BREAKING CHANGES

* Package renamed from cognite-typed-functions to cognite-function-apps. CLI command renamed from ctf to fun.
* Response customization with status_code and headers ([#141](https://github.com/cognitedata/cognite-function-apps/issues/141))
* Streamlines tracing setup to one line before v1.0. Taking this opportunity to fix the API while adoption is still early.

### Features

* add automatic trace propagation via traceparent header ([f410e2f](https://github.com/cognitedata/cognite-function-apps/commit/f410e2fb75587cfba30c048f083f0dd6a806a87b))
* Add exporter_provider to TracingApp for secret-based authentication ([dabbe4f](https://github.com/cognitedata/cognite-function-apps/commit/dabbe4f22ef595f9e397c0b8a403526e03812f3e))
* make the docs actionable as a tutorial, and smaller. ([6377121](https://github.com/cognitedata/cognite-function-apps/commit/6377121866b6d4dfb92f9748be0fb33477c87e0d))
* More renames ([6586373](https://github.com/cognitedata/cognite-function-apps/commit/6586373b28b4ab567abacd280cd34ebb0ab14bda))
* reduce docs for tracer ([aa27a59](https://github.com/cognitedata/cognite-function-apps/commit/aa27a5962d7fee0bf48f8a96423a24ad999354c6))
* rename SDK to Function Apps ([4c138d3](https://github.com/cognitedata/cognite-function-apps/commit/4c138d3386023e568dce2c0ae1f038e1dacbd832))
* Response customization with status_code and headers ([#141](https://github.com/cognitedata/cognite-function-apps/issues/141)) ([9423f2b](https://github.com/cognitedata/cognite-function-apps/commit/9423f2bc7572b6216bdae6a50108390f425663cf))
* simplify tracing API with backend presets ([7535b3a](https://github.com/cognitedata/cognite-function-apps/commit/7535b3aa9aa0c676770ffc46e0d33e41994ee1fc))
* standardize secret key with actionable error messages ([63a0641](https://github.com/cognitedata/cognite-function-apps/commit/63a0641e015986bfcce0976124598b0097267501))

### Bug Fixes

* configure release-please to use manifest mode ([810fff3](https://github.com/cognitedata/cognite-function-apps/commit/810fff30854e472bffed64603f697bf534366a47))
* remove line_spans from highlight config causing garbled code blocks ([#139](https://github.com/cognitedata/cognite-function-apps/issues/139)) ([4ede4cc](https://github.com/cognitedata/cognite-function-apps/commit/4ede4cc7b84d0f1a05d929739d40e4f712846099))
* update publish workflow to trigger on merge commits ([857f19f](https://github.com/cognitedata/cognite-function-apps/commit/857f19fc2091c2bef1faa13ef45265408bed7f33))
* update release-please workflow to use PAT token ([77cadd2](https://github.com/cognitedata/cognite-function-apps/commit/77cadd2aa97694bd7ed8d04a63af9ac584943e21))
* update version to 0.5.0 and configure release-please annotations ([eeb323b](https://github.com/cognitedata/cognite-function-apps/commit/eeb323bad6354c086b39973283e0d4337f4c0dbb))
* use route content_type in OpenAPI schema responses ([#143](https://github.com/cognitedata/cognite-function-apps/issues/143)) ([dc87c6b](https://github.com/cognitedata/cognite-function-apps/commit/dc87c6b2a391f2fddf29844a8192af7d48269bfa))
* use version-file instead of extra-files for Python version ([72548b9](https://github.com/cognitedata/cognite-function-apps/commit/72548b96ea087b841e621e0d5c5e83daf1190d5a))

### Documentation

* add ADR for response customization ([#138](https://github.com/cognitedata/cognite-function-apps/issues/138)) ([b69180b](https://github.com/cognitedata/cognite-function-apps/commit/b69180ba058cf2a3fa68927967d82c07f58e072b))
* add revert commit type to guidelines ([0389f12](https://github.com/cognitedata/cognite-function-apps/commit/0389f12571aa0288675f0632961a265183ca50ba))
* Auto-generate docs from Python files to get linting and type-checking ([#137](https://github.com/cognitedata/cognite-function-apps/issues/137)) ([6a69fe2](https://github.com/cognitedata/cognite-function-apps/commit/6a69fe2dbed6084ac726b146a9aef7592aecf62d))
* Missing renames ([122c151](https://github.com/cognitedata/cognite-function-apps/commit/122c15123a81cb7a822a397f01bdcf4babcc2070))
* update documentation for response customization (PR 141) ([#144](https://github.com/cognitedata/cognite-function-apps/issues/144)) ([d05763c](https://github.com/cognitedata/cognite-function-apps/commit/d05763cfab94f10928e90e63dec6cdd5e5af7d6b))

### Code Refactoring

* address PR review comments ([30a94e9](https://github.com/cognitedata/cognite-function-apps/commit/30a94e903fa269e16c38849b30d6c77ad9df8d8b))
* consolidate tracing to single exporter path ([8ee34dc](https://github.com/cognitedata/cognite-function-apps/commit/8ee34dcbb73cea2ab692f4f633fcae3e8dcba550))
* use version-file instead of extra-files ([2f49ca5](https://github.com/cognitedata/cognite-function-apps/commit/2f49ca5934758088141102aeebcaa2bd4f781512))

## [0.5.3](https://github.com/cognitedata/cognite-typed-functions/compare/cognite-typed-functions-v0.5.2...cognite-typed-functions-v0.5.3) (2025-11-26)

### Documentation

* add revert commit type to guidelines ([0389f12](https://github.com/cognitedata/cognite-typed-functions/commit/0389f12571aa0288675f0632961a265183ca50ba))

## [0.5.2](https://github.com/cognitedata/cognite-typed-functions/compare/cognite-typed-functions-v0.5.1...cognite-typed-functions-v0.5.2) (2025-11-20)

### Bug Fixes

* update publish workflow to trigger on merge commits ([84c30c7](https://github.com/cognitedata/cognite-typed-functions/commit/84c30c7393e70e9b035732a573317bb0ed1d80f0))

## [0.5.1](https://github.com/cognitedata/cognite-typed-functions/compare/cognite-typed-functions-v0.5.0...cognite-typed-functions-v0.5.1) (2025-11-20)

### Bug Fixes

* update version to 0.5.0 and configure release-please annotations ([3a01001](https://github.com/cognitedata/cognite-typed-functions/commit/3a0100101738d008957075fa73523fb2db5558c6))

## [0.5.0](https://github.com/cognitedata/cognite-typed-functions/compare/cognite-typed-functions-v0.4.0...cognite-typed-functions-v0.5.0) (2025-11-19)

### Features

* add automatic trace propagation via traceparent header ([f410e2f](https://github.com/cognitedata/cognite-typed-functions/commit/f410e2fb75587cfba30c048f083f0dd6a806a87b))

## [0.4.0](https://github.com/cognitedata/cognite-typed-functions/compare/cognite-typed-functions-v0.3.2...cognite-typed-functions-v0.4.0) (2025-11-19)

### ⚠ BREAKING CHANGES

* Streamlines tracing setup to one line before v1.0. Taking this opportunity to fix the API while adoption is still early.

### Features

* Add exporter_provider to TracingApp for secret-based authentication ([dabbe4f](https://github.com/cognitedata/cognite-typed-functions/commit/dabbe4f22ef595f9e397c0b8a403526e03812f3e))
* make the docs actionable as a tutorial, and smaller. ([6377121](https://github.com/cognitedata/cognite-typed-functions/commit/6377121866b6d4dfb92f9748be0fb33477c87e0d))
* reduce docs for tracer ([aa27a59](https://github.com/cognitedata/cognite-typed-functions/commit/aa27a5962d7fee0bf48f8a96423a24ad999354c6))
* simplify tracing API with backend presets ([0ecb671](https://github.com/cognitedata/cognite-typed-functions/commit/0ecb671327e87992ef6baa77b10f8f90fa694a6e))
* standardize secret key with actionable error messages ([63a0641](https://github.com/cognitedata/cognite-typed-functions/commit/63a0641e015986bfcce0976124598b0097267501))

### Bug Fixes

* configure release-please to use manifest mode ([45623b2](https://github.com/cognitedata/cognite-typed-functions/commit/45623b2d39c075c703d8a09d8741120ec21607b5))
* update release-please workflow to use PAT token ([ea6cc26](https://github.com/cognitedata/cognite-typed-functions/commit/ea6cc26bf9c827917a9b974dc44721b4f8995455))
* use version-file instead of extra-files for Python version ([5122824](https://github.com/cognitedata/cognite-typed-functions/commit/51228249b214b74a5cfda5f9e445a000be86f234))

### Code Refactoring

* address PR review comments ([30a94e9](https://github.com/cognitedata/cognite-typed-functions/commit/30a94e903fa269e16c38849b30d6c77ad9df8d8b))
* consolidate tracing to single exporter path ([8ee34dc](https://github.com/cognitedata/cognite-typed-functions/commit/8ee34dcbb73cea2ab692f4f633fcae3e8dcba550))
* use version-file instead of extra-files ([2f49ca5](https://github.com/cognitedata/cognite-typed-functions/commit/2f49ca5934758088141102aeebcaa2bd4f781512))
