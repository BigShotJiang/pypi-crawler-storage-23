"""MCPFind: Context-efficient MCP tool proxy with semantic search."""

__version__ = "0.1.1"
