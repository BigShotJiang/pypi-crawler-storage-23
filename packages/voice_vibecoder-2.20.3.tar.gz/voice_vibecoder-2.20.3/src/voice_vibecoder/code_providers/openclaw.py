"""OpenClaw Agent code provider.

Routes coding tasks to OpenClaw Gateway via WebSocket for streaming output.
Falls back to CLI if WebSocket connection fails.
"""

from __future__ import annotations

import asyncio
import base64
import json
import logging
import os
import time
import uuid
from typing import Any, Awaitable, Callable

from voice_vibecoder.code_providers import AgentOutput, AgentResult

logger = logging.getLogger(__name__)

try:
    from cryptography.hazmat.primitives import serialization
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
    HAS_CRYPTO = True
except ImportError:
    HAS_CRYPTO = False
    logger.warning("cryptography not installed, WebSocket auth will not work")


def _load_device_keys(state_dir: str) -> tuple[str, Ed25519PrivateKey | None, str | None]:
    """Load device identity from OpenClaw state directory."""
    device_path = os.path.join(state_dir, "identity", "device.json")
    auth_path = os.path.join(state_dir, "identity", "device-auth.json")
    
    device_id = None
    private_key = None
    token = None
    
    try:
        with open(device_path) as f:
            device = json.load(f)
            device_id = device["deviceId"]
            if HAS_CRYPTO:
                pem = device["privateKeyPem"].encode()
                private_key = serialization.load_pem_private_key(pem, password=None)
    except Exception as e:
        logger.debug("Could not load device.json: %s", e)
    
    try:
        with open(auth_path) as f:
            auth = json.load(f)
            if "tokens" in auth and "operator" in auth["tokens"]:
                token = auth["tokens"]["operator"]["token"]
    except Exception as e:
        logger.debug("Could not load device-auth.json: %s", e)
    
    return device_id, private_key, token


def _build_auth_payload(
    device_id: str,
    client_id: str,
    client_mode: str,
    role: str,
    scopes: list[str],
    signed_at_ms: int,
    token: str | None,
    nonce: str | None,
) -> str:
    """Build the payload to sign for device auth."""
    scopes_str = ",".join(scopes)
    token_str = token or ""
    
    parts = [
        "v2",
        device_id,
        client_id,
        client_mode,
        role,
        scopes_str,
        str(signed_at_ms),
        token_str,
        nonce or "",
    ]
    return "|".join(parts)


def _sign_payload(private_key: Ed25519PrivateKey, payload: str) -> str:
    """Sign the payload and return base64url-encoded signature."""
    signature = private_key.sign(payload.encode())
    return base64.urlsafe_b64encode(signature).decode().rstrip("=")


class OpenClawRunner:
    """AgentRunner implementation using OpenClaw Gateway WebSocket."""

    def __init__(
        self,
        session_id: str | None = None,
        agent_id: str | None = None,
        env: dict[str, str] | None = None,
        gateway_url: str | None = None,
        state_dir: str | None = None,
        **_kwargs,
    ) -> None:
        self._session_id = session_id or f"voice-{uuid.uuid4().hex[:8]}"
        self._agent_id = agent_id
        self._env = env or {}
        self._gateway_url = gateway_url or os.environ.get("OPENCLAW_GATEWAY_URL", "ws://127.0.0.1:18789")
        self._state_dir = state_dir or os.environ.get("OPENCLAW_STATE_DIR", "/data/olaf")
        self._task: asyncio.Task | None = None
        self._ws = None
        
        self._device_id, self._private_key, self._device_token = _load_device_keys(self._state_dir)

    async def _connect_websocket(self) -> Any:
        """Connect to OpenClaw Gateway via WebSocket."""
        try:
            import websockets
        except ImportError:
            logger.warning("websockets not installed")
            return None
        
        if not self._device_id or not self._private_key:
            logger.warning("No device identity found, cannot connect via WebSocket")
            return None
        
        try:
            ws = await asyncio.wait_for(
                websockets.connect(self._gateway_url),
                timeout=5.0
            )
            
            challenge_msg = await asyncio.wait_for(ws.recv(), timeout=5.0)
            challenge = json.loads(challenge_msg)
            
            if challenge.get("event") != "connect.challenge":
                logger.warning("Unexpected challenge: %s", challenge)
                await ws.close()
                return None
            
            nonce = challenge["payload"]["nonce"]
            signed_at_ms = int(time.time() * 1000)
            
            client_id = "cli"
            client_mode = "cli"
            role = "operator"
            scopes = ["operator.read", "operator.write", "operator.admin"]
            
            payload = _build_auth_payload(
                device_id=self._device_id,
                client_id=client_id,
                client_mode=client_mode,
                role=role,
                scopes=scopes,
                signed_at_ms=signed_at_ms,
                token=self._device_token,
                nonce=nonce,
            )
            signature = _sign_payload(self._private_key, payload)
            
            public_key_bytes = self._private_key.public_key().public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw
            )
            pub_b64 = base64.urlsafe_b64encode(public_key_bytes).decode().rstrip("=")
            
            connect_req = {
                "type": "req",
                "id": str(uuid.uuid4()),
                "method": "connect",
                "params": {
                    "minProtocol": 3,
                    "maxProtocol": 3,
                    "client": {
                        "id": client_id,
                        "version": "1.0.0",
                        "platform": "linux",
                        "mode": client_mode
                    },
                    "role": role,
                    "scopes": scopes,
                    "caps": [],
                    "commands": [],
                    "permissions": {},
                    "auth": {"token": self._device_token} if self._device_token else {},
                    "locale": "en-US",
                    "userAgent": "voice-server/1.0.0",
                    "device": {
                        "id": self._device_id,
                        "publicKey": pub_b64,
                        "signature": signature,
                        "signedAt": signed_at_ms,
                        "nonce": nonce
                    }
                }
            }
            
            await ws.send(json.dumps(connect_req))
            
            response_msg = await asyncio.wait_for(ws.recv(), timeout=5.0)
            response = json.loads(response_msg)
            
            if not response.get("ok"):
                error = response.get("error", {}).get("message", "Unknown error")
                logger.warning("Gateway connect failed: %s", error)
                await ws.close()
                return None
            
            logger.info("Connected to OpenClaw Gateway via WebSocket")
            return ws
            
        except Exception as e:
            logger.warning("WebSocket connection failed: %s", e)
            return None

    async def _run_via_websocket(
        self,
        ws,
        message: str,
        cwd: str,
        session_id: str,
        on_output: Callable[[AgentOutput], None] | None = None,
    ) -> AgentResult | None:
        """Run agent via WebSocket for streaming output."""
        try:
            req_id = str(uuid.uuid4())
            idempotency_key = f"voice-{uuid.uuid4().hex[:16]}"
            
            # Prepend working directory to message so agent knows where to work
            full_message = f"[Working directory: {cwd}]\n\n{message}"
            
            chat_req = {
                "type": "req",
                "id": req_id,
                "method": "chat.send",
                "params": {
                    "sessionKey": session_id,
                    "message": full_message,
                    "idempotencyKey": idempotency_key,
                }
            }
            
            await ws.send(json.dumps(chat_req))

            result_text = ""
            prev_text_len = 0  # Track streamed text length for delta extraction
            line_buffer = ""   # Buffer tokens until we have a complete line

            def _flush_lines(buf: str, final: bool = False) -> str:
                """Emit complete lines from buffer, return the remaining partial line.

                When *final* is True, also emit whatever remains in the buffer.
                """
                while "\n" in buf:
                    line, buf = buf.split("\n", 1)
                    line = line.strip()
                    if line and on_output:
                        on_output(AgentOutput(category="text", content=line))
                if final:
                    remainder = buf.strip()
                    if remainder and on_output:
                        on_output(AgentOutput(category="text", content=remainder))
                    return ""
                return buf

            while True:
                msg = await asyncio.wait_for(ws.recv(), timeout=300.0)
                data = json.loads(msg)

                event = data.get("event")
                payload = data.get("payload", {})

                if event == "agent":
                    stream = payload.get("stream")
                    agent_data = payload.get("data", {})

                    if stream == "lifecycle":
                        phase = agent_data.get("phase")
                        if phase == "start" and on_output:
                            on_output(AgentOutput(category="text", content="🤔 Tenker..."))

                    elif stream == "assistant" and "text" in agent_data:
                        text = agent_data["text"]
                        if text:
                            result_text = text
                            # Extract only the new delta (API sends full text each time)
                            delta = text[prev_text_len:]
                            prev_text_len = len(text)
                            if delta:
                                line_buffer += delta
                                line_buffer = _flush_lines(line_buffer)

                    elif stream == "tool":
                        # Flush any buffered text before showing tool output
                        line_buffer = _flush_lines(line_buffer, final=True)
                        # Reset stream position so next assistant text starts fresh
                        prev_text_len = len(result_text)
                        name = agent_data.get("name", "")
                        status = agent_data.get("status", "")
                        if name and on_output:
                            if status == "started":
                                on_output(AgentOutput(category="tool_call", content=f"🔧 [{name}]"))
                            elif status == "completed":
                                result = agent_data.get("result", "")
                                if result:
                                    preview = str(result)[:200]
                                    on_output(AgentOutput(category="tool_result", content=f"✓ {preview}"))

                    elif stream == "thinking":
                        # Thinking deltas — suppress (the "🤔 Thinking..."
                        # lifecycle message already indicates the agent is working)
                        pass
                
                elif event == "chat":
                    state = payload.get("state")
                    if state == "final":
                        # Flush remaining buffered text
                        line_buffer = _flush_lines(line_buffer, final=True)
                        # Get final message
                        msg_content = payload.get("message", {})
                        if isinstance(msg_content, dict) and "content" in msg_content:
                            content = msg_content["content"]
                            if isinstance(content, list):
                                texts = [c.get("text", "") for c in content if isinstance(c, dict) and c.get("type") == "text"]
                                result_text = "\n".join(texts)
                            elif isinstance(content, str):
                                result_text = content
                        break
                    elif state == "error":
                        error = payload.get("error", "Unknown error")
                        raise RuntimeError(f"Chat error: {error}")
                
                elif data.get("type") == "res" and data.get("id") == req_id:
                    if not data.get("ok"):
                        error = data.get("error", {}).get("message", "Unknown error")
                        raise RuntimeError(f"Chat send error: {error}")
            
            return AgentResult(text=result_text.strip(), session_id=session_id)
            
        except Exception as e:
            logger.warning("WebSocket chat failed: %s", e)
            return None

    async def _run_via_cli(
        self,
        message: str,
        cwd: str,
        session_id: str,
        on_output: Callable[[AgentOutput], None] | None = None,
    ) -> AgentResult:
        """Fallback: run agent via CLI."""
        if on_output:
            on_output(AgentOutput(category="text", content="🦞 Running via CLI..."))
        
        full_message = f"[Working directory: {cwd}]\n\n{message}"
        
        cmd = [
            "openclaw", "agent",
            "--session-id", session_id,
            "--message", full_message,
            "--local",
        ]
        
        env = os.environ.copy()
        env["PATH"] = f"/home/olaf/.npm-global/bin:/home/olaf/.local/bin:{env.get('PATH', '')}"
        env["OPENCLAW_STATE_DIR"] = self._state_dir
        if self._env:
            env.update(self._env)
        
        process = await asyncio.create_subprocess_exec(
            *cmd,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            env=env,
            cwd=cwd,
        )
        
        stdout, stderr = await process.communicate()
        result_text = stdout.decode("utf-8", errors="replace").strip()
        
        if process.returncode != 0 and not result_text:
            raise RuntimeError(f"CLI failed: {stderr.decode()}")
        
        return AgentResult(text=result_text, session_id=session_id)

    async def run(
        self,
        message: str,
        cwd: str,
        session_id: str | None = None,
        on_output: Callable[[AgentOutput], None] | None = None,
        can_use_tool: Callable[[str, dict, Any], Awaitable[Any]] | None = None,
    ) -> AgentResult:
        """Run a coding task via OpenClaw."""
        self._task = asyncio.current_task()
        effective_session = session_id or self._session_id

        ws = await self._connect_websocket()
        if ws:
            try:
                result = await self._run_via_websocket(ws, message, cwd, effective_session, on_output)
                if result:
                    return result
            finally:
                await ws.close()

        if on_output:
            on_output(AgentOutput(category="text", content="WebSocket unavailable, using CLI...\n"))

        return await self._run_via_cli(message, cwd, effective_session, on_output)

    def cancel(self) -> bool:
        """Cancel the running task."""
        task = self._task
        if task and not task.done():
            task.cancel()
            return True
        return False
