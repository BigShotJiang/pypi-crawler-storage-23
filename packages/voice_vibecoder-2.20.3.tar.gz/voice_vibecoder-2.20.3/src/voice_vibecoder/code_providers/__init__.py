"""Agent runner protocol and result types.

Defines a provider-agnostic interface for code agents that execute tasks.
Implementations wrap specific agent SDKs (Claude, Cursor, Aider, etc.)
while the tool layer works with these abstract types.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Protocol

OUTPUT_LIMIT = 10000
TRUNCATION_KEEP = 2000


def truncate_output(text: str) -> str:
    """Truncate long output text, keeping start and end."""
    if len(text) <= OUTPUT_LIMIT:
        return text
    omitted = len(text) - (TRUNCATION_KEEP * 2)
    return (
        text[:TRUNCATION_KEEP]
        + f"\n\n[... {omitted} chars omitted ...]\n\n"
        + text[-TRUNCATION_KEEP:]
    )


@dataclass
class AgentResult:
    """Result from an agent task execution."""
    text: str
    session_id: str | None = None


@dataclass
class AgentOutput:
    """Streaming output line from the agent."""
    category: str  # "text", "tool_call", "file_edit", "bash", "tool_result", "diff_del", "diff_add"
    content: str


class AgentRunner(Protocol):
    """Interface for a code agent that executes tasks."""

    async def run(
        self,
        message: str,
        cwd: str,
        session_id: str | None = None,
        on_output: Callable[[AgentOutput], None] | None = None,
        can_use_tool: Callable[[str, dict, Any], Awaitable[Any]] | None = None,
    ) -> AgentResult:
        """Execute a task. Streams output via on_output. Returns final result."""
        ...

    def cancel(self) -> bool:
        """Cancel a running task. Returns True if something was cancelled."""
        ...
