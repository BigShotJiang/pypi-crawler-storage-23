"""WebSocket server for browser-based voice coding.

Bridges browser WebSocket connections to the existing RealtimeSession.
Each connection gets its own session, provider, and instance registry.
The browser sends/receives JSON frames — never talks to OpenAI directly.

Protocol (client -> server):
  {"type": "auth", "token": "<JWT>"}           — must be the first message when auth is enabled
  {"type": "sync_state", "mode": "voice"}        — voice mode: connects voice provider
  {"type": "sync_state", "mode": "text"}         — text-only mode: skip voice provider entirely
  {"type": "audio", "data": "<base64 PCM16 24kHz>"}
  {"type": "audio.commit"}
  {"type": "text", "text": "..."}               — send text (routes via voice or directly to agent)
  {"type": "update_settings", "settings": {...}}  — partial settings update, reconnects provider

Protocol (server -> client):
  {"type": "auth_ok"}
  {"type": "audio", "data": "<base64>"}
  {"type": "transcript", "role": "user"|"assistant", "text": "..."}
  {"type": "status", "status": "ready"|"listening"|"processing"|"responding"|"reconnecting"}
  {"type": "settings_updated", "settings": {...}}
  {"type": "agent_output", "instanceId": "...", "line": "..."}
  {"type": "instance_status", "instanceId": "...", "status": "...", "branch": "..."}
  {"type": "tool_call", "name": "...", "arguments": {...}}
  {"type": "ui_command", "instanceId": "...", "action": "show_diff"|"show_output"|"fullscreen"|"remove", "data": {...}}
  {"type": "interrupt"}
  {"type": "error", "message": "..."}
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from dataclasses import asdict, fields
from pathlib import Path
from typing import Any

import websockets
from websockets.asyncio.server import ServerConnection
from websockets.http11 import Request, Response

from voice_vibecoder.app_config import VoiceConfig
from voice_vibecoder.config import RealtimeSettings
from voice_vibecoder.instances import InstanceStatus
from voice_vibecoder.session import RealtimeSession
from voice_vibecoder.voice_providers import create_provider

logger = logging.getLogger(__name__)

# ── Auth timeout ─────────────────────────────────────────────────────────────

AUTH_TIMEOUT_SECONDS = 10


def _sanitize_settings(d: dict[str, Any]) -> dict[str, Any]:
    """Strip API keys from a settings dict before sending to the frontend."""
    d = {k: v for k, v in d.items() if k != "api_key"}
    for provider in ("openai", "azure", "gemini"):
        if provider in d and isinstance(d[provider], dict):
            d[provider] = {k: v for k, v in d[provider].items() if k != "api_key"}
    return d


def _merge_settings(settings: RealtimeSettings, incoming: dict[str, Any]) -> None:
    """Merge a partial settings dict into an existing RealtimeSettings.

    Top-level scalar keys (provider, language, etc.) are replaced directly.
    Nested provider dicts (openai, azure, gemini) are merged at the field level
    so the frontend can send e.g. ``{"gemini": {"model": "..."}}`` without
    needing to include every field.
    """
    from voice_vibecoder.config import OpenAIConfig, AzureConfig, GeminiConfig

    _PROVIDER_ATTRS = {
        "openai": OpenAIConfig,
        "azure": AzureConfig,
        "gemini": GeminiConfig,
    }

    for key, value in incoming.items():
        if key in _PROVIDER_ATTRS and isinstance(value, dict):
            # Merge sub-keys into the existing dataclass
            cfg = getattr(settings, key)
            valid_fields = {f.name for f in fields(cfg)}
            for sub_key, sub_value in value.items():
                if sub_key in valid_fields:
                    setattr(cfg, sub_key, sub_value)
        elif hasattr(settings, key):
            setattr(settings, key, value)


class WebSocketBridge:
    """One bridge per browser connection. Thin adapter between WS frames and RealtimeSession."""

    def __init__(
        self,
        ws: ServerConnection,
        settings: RealtimeSettings,
        repo_root: Path,
        voice_config: VoiceConfig | None = None,
        user_email: str | None = None,
        user_jwt: str | None = None,
    ) -> None:
        self._ws = ws
        self._settings = settings
        self._repo_root = repo_root
        self._session: RealtimeSession | None = None
        self._voice_config = voice_config
        self._user_email = user_email
        self._user_jwt = user_jwt
        self._messages_task: asyncio.Task | None = None
        self._ui_commands_enabled = False

    async def run(self) -> None:
        provider = create_provider(self._settings)

        self._session = RealtimeSession(
            provider=provider,
            settings=self._settings,
            repo_root=self._repo_root,
            voice_config=self._voice_config,
            user_email=self._user_email,
            user_jwt=self._user_jwt,
            on_audio=self._on_audio,
            on_transcript=self._on_transcript,
            on_status=self._on_status,
            on_tool_call=self._on_tool_call,
            on_agent_output=self._on_agent_output,
            on_instance_status=self._on_instance_status,
            on_interrupt=self._on_interrupt,
            on_ui_command=self._on_ui_command,
        )

        # Set event loop so _send works even before voice provider connects
        self._session._loop = asyncio.get_event_loop()

        # Load saved instances — panels appear dynamically as sessions/instances are created
        restored = self._session.registry.load_state()

        # Don't connect voice provider yet — wait for sync_state.
        # Text-only clients (no sync_state) skip the voice provider entirely.
        self._send({"type": "status", "status": "ready"})

        try:
            await self._receive_loop()
        finally:
            if self._messages_task:
                self._messages_task.cancel()
                try:
                    await self._messages_task
                except (asyncio.CancelledError, Exception):
                    pass
            if self._session.connected:
                await self._session.disconnect()

    async def _connect_voice_provider(self) -> None:
        """Lazily connect the voice provider when audio is needed."""
        if self._session.connected:
            return
        await self._session.connect()
        await self._session.configure_session()
        self._messages_task = asyncio.create_task(self._session.handle_messages())

    async def _receive_loop(self) -> None:
        try:
            async for raw in self._ws:
                try:
                    msg = json.loads(raw)
                except (json.JSONDecodeError, TypeError):
                    continue

                msg_type = msg.get("type")
                if msg_type == "audio":
                    data = msg.get("data", "")
                    if data and self._session and self._session.connected:
                        await self._session.send_audio(data)
                elif msg_type == "audio.commit":
                    if self._session and self._session.connected:
                        await self._session.commit_audio()
                elif msg_type == "text":
                    text = msg.get("text", "") or msg.get("message", "")
                    if text and self._session:
                        if self._session.connected:
                            # Voice mode: route through voice provider
                            await self._session.inject_user_message(text)
                        else:
                            # Text-only mode: route directly to agent
                            await self._handle_text_only(text)
                elif msg_type == "update_settings":
                    await self._handle_settings_update(msg.get("settings", {}))
                elif msg_type == "sync_state":
                    if msg.get("ui_commands"):
                        self._ui_commands_enabled = True
                    mode = msg.get("mode", "voice")
                    if mode == "voice":
                        await self._connect_voice_provider()
                    else:
                        self._session.text_only = True
                    self._send({"type": "status", "status": "syncing"})
                    await self._sync_state_to_frontend()
                    self._send({"type": "status", "status": "ready"})
        except websockets.ConnectionClosed:
            pass

    async def _handle_text_only(self, text: str) -> None:
        """Route text directly to an agent session, bypassing the voice provider.

        Used for text-only clients that don't need audio. The agent streams
        output via on_agent_output and sends the final result as a transcript.
        """
        from voice_vibecoder.tools.agent_task import _handle_send_to_session

        self._session.text_only = True
        self._session.registry.add_transcript("user", text)
        self._send({"type": "transcript", "role": "user", "text": text})
        _handle_send_to_session(text)

    async def _sync_state_to_frontend(self) -> None:
        """Send full backend state to frontend - all instances with their conversation history."""
        if not self._session:
            return

        # Send transcript history (skip for text-only — they start fresh)
        if not self._session.text_only:
            transcripts = self._session.registry.get_transcripts()
            logger.info(f"[SYNC_STATE] Sending {len(transcripts)} transcripts to frontend")
            for entry in transcripts:
                self._send({
                    "type": "transcript",
                    "role": entry["role"],
                    "text": entry["text"],
                })

        # Send instance status and history (skip for text-only)
        if self._session.text_only:
            return
        for inst in self._session.registry.get_all():
            self._send({
                "type": "instance_status",
                "instanceId": inst.instance_id,
                "status": inst.status.value,
                "branch": inst.branch,
                "agentType": inst.agent_type,
                "displayName": inst.display_key,
            })
            # Send buffered output from previous session
            if inst.output_buffer:
                self._send({
                    "type": "agent_output",
                    "instanceId": inst.instance_id,
                    "line": f"text:{inst.output_buffer}",
                })

        # Send current settings so the frontend can render voice controls
        if not self._session.text_only:
            self._send({
                "type": "settings_updated",
                "settings": _sanitize_settings(self._settings._to_dict()),
            })

    async def _handle_settings_update(self, incoming: dict[str, Any]) -> None:
        """Apply a partial settings update, save to disk, and reconnect the provider."""
        if not incoming:
            self._send({"type": "error", "message": "Empty settings update"})
            return

        _merge_settings(self._settings, incoming)
        self._settings.save()
        logger.info("Settings updated: %s", list(incoming.keys()))

        if self._session:
            self._send({"type": "status", "status": "reconnecting"})
            try:
                # Stop the current message listener before swapping providers
                if self._messages_task:
                    self._messages_task.cancel()
                    try:
                        await self._messages_task
                    except (asyncio.CancelledError, Exception):
                        pass

                await self._session.update_provider(self._settings)

                # Restart the message listener with the new provider
                self._messages_task = asyncio.create_task(
                    self._session.handle_messages()
                )
                self._send({"type": "status", "status": "ready"})
                self._send({
                    "type": "settings_updated",
                    "settings": _sanitize_settings(self._settings._to_dict()),
                })
            except Exception as e:
                logger.error("Failed to reconnect after settings update: %s", e, exc_info=True)
                self._send({"type": "error", "message": f"Reconnect failed: {e}"})

    # -- Callbacks (called from RealtimeSession, possibly from background threads) --

    def _send(self, msg: dict[str, Any]) -> None:
        try:
            data = json.dumps(msg)
            loop = self._session._loop if self._session else None
            if not loop or not loop.is_running():
                return
            # If called from the event loop thread, create a task directly
            # so the send is processed immediately on the next await.
            # From other threads (agent background tasks), use the
            # thread-safe scheduler which wakes the loop.
            try:
                running_loop = asyncio.get_running_loop()
            except RuntimeError:
                running_loop = None
            if running_loop is loop:
                asyncio.ensure_future(self._ws.send(data), loop=loop)
            else:
                future = asyncio.run_coroutine_threadsafe(self._ws.send(data), loop)
                future.add_done_callback(_log_send_error)
        except Exception:
            logger.warning("Failed to send WS frame", exc_info=True)

    def _on_audio(self, base64_chunk: str) -> None:
        if self._session and self._session.text_only:
            return
        self._send({"type": "audio", "data": base64_chunk})

    def _on_transcript(self, role: str, text: str) -> None:
        self._send({"type": "transcript", "role": role, "text": text})

    def _on_status(self, status: str) -> None:
        self._send({"type": "status", "status": status})

    def _on_agent_output(self, instance_id: str, line: str) -> None:
        self._send({"type": "agent_output", "instanceId": instance_id, "line": line})

    def _on_instance_status(self, instance_id: str, status: InstanceStatus) -> None:
        inst = self._session.registry.get_by_id(instance_id) if self._session else None
        branch = inst.branch if inst else ""
        agent_type = inst.agent_type if inst else "claude"
        display_name = inst.display_key if inst else branch
        self._send({
            "type": "instance_status",
            "instanceId": instance_id,
            "status": status.value,
            "branch": branch,
            "agentType": agent_type,
            "displayName": display_name,
        })

    def _on_tool_call(self, name: str, arguments: dict) -> None:
        self._send({"type": "tool_call", "name": name, "arguments": arguments})

    def _on_ui_command(self, instance_id: str, action: str, data: Any) -> None:
        if not self._ui_commands_enabled:
            return
        self._send({"type": "ui_command", "instanceId": instance_id, "action": action, "data": data})

    def _on_interrupt(self) -> None:
        self._send({"type": "interrupt"})


def _log_send_error(future: asyncio.Future) -> None:
    """Callback for run_coroutine_threadsafe — log exceptions instead of losing them."""
    exc = future.exception()
    if exc:
        logger.warning("WS send failed: %s", exc)


async def _authenticate_ws(
    ws: ServerConnection,
    authenticate: Any,
) -> tuple[str, str] | None:
    """Wait for an auth message as the first frame.

    *authenticate* is the ``VoiceConfig.authenticate`` async callback.
    Returns ``(user_email, raw_token)`` on success, ``None`` on failure.
    """
    try:
        raw = await asyncio.wait_for(ws.recv(), timeout=AUTH_TIMEOUT_SECONDS)
        msg = json.loads(raw)
    except asyncio.TimeoutError:
        await ws.send(json.dumps({"type": "error", "message": "Auth timeout"}))
        return None
    except (json.JSONDecodeError, TypeError, websockets.ConnectionClosed):
        return None

    if msg.get("type") != "auth" or not isinstance(msg.get("token"), str):
        await ws.send(json.dumps({"type": "error", "message": "Expected auth message"}))
        return None

    token = msg["token"]
    if token.startswith("Bearer "):
        token = token[7:]

    try:
        result = await authenticate(token)
    except ValueError as exc:
        logger.warning("Authentication failed: %s", exc)
        await ws.send(json.dumps({"type": "error", "message": "Authentication failed"}))
        return None
    except Exception as exc:
        logger.error("Unexpected error during authentication: %s", exc, exc_info=True)
        await ws.send(json.dumps({"type": "error", "message": "Authentication failed"}))
        return None

    await ws.send(json.dumps({"type": "auth_ok"}))
    return result


async def _handle_connection(
    ws: ServerConnection,
    settings: RealtimeSettings,
    repo_root: Path,
    voice_config: VoiceConfig | None,
) -> None:
    remote = ws.remote_address
    logger.info("Client connected from %s", remote)

    user_email = None
    user_jwt = None
    authenticate = voice_config.authenticate if voice_config else None
    if authenticate:
        auth_result = await _authenticate_ws(ws, authenticate)
        if not auth_result:
            logger.warning("Auth failed for %s — closing", remote)
            await ws.close(4001, "Unauthorized")
            return
        user_email, user_jwt = auth_result
        logger.info("Authenticated user: %s", user_email)

    bridge = WebSocketBridge(ws, settings, repo_root, voice_config, user_email=user_email, user_jwt=user_jwt)
    try:
        await bridge.run()
    except Exception:
        logger.error("Bridge error", exc_info=True)
    finally:
        logger.info("Client disconnected: %s", remote)


async def serve(
    host: str = "127.0.0.1",
    port: int = 8765,
    repo_root: Path | None = None,
    voice_config: VoiceConfig | None = None,
    settings: RealtimeSettings | None = None,
    allowed_origins: list[str] | None = None,
) -> None:
    """Start the WebSocket server. Blocks until stopped."""
    if repo_root is None:
        repo_root = Path.cwd()

    # Browser cookie headers can exceed the default 8 KiB line limit.
    import websockets.http11
    websockets.http11.MAX_LINE_LENGTH = 32768

    if settings is None:
        settings = RealtimeSettings.load()
    if not settings.is_configured:
        logger.error("Not configured. Run 'vibecoder' TUI first to set API keys.")
        return

    auth_enabled = voice_config is not None and voice_config.authenticate is not None
    if auth_enabled:
        logger.info("WebSocket auth enabled (authenticate callback provided)")
    else:
        logger.info("WebSocket auth disabled (no authenticate callback)")

    # Origin checking — build allowed set from env var + explicit param
    origin_env = os.environ.get("VOICE_ALLOWED_ORIGINS", "")
    _allowed_origins: set[str] = set()
    if allowed_origins:
        _allowed_origins.update(allowed_origins)
    if origin_env:
        _allowed_origins.update(o.strip() for o in origin_env.split(",") if o.strip())

    def process_request(connection: ServerConnection, request: Request) -> Response | None:
        """Check Origin header before completing the WebSocket handshake."""
        if _allowed_origins:
            origin = request.headers.get("Origin", "")
            if origin not in _allowed_origins:
                logger.warning("Rejected connection from origin: %s", origin)
                return Response(403, "Forbidden", websockets.Headers())
        return None

    logger.info(
        "Starting voice server on ws://%s:%d  repo=%s  provider=%s",
        host, port, repo_root, settings.provider_label,
    )

    async def handler(ws: ServerConnection) -> None:
        await _handle_connection(ws, settings, repo_root, voice_config)

    async with websockets.serve(handler, host, port, process_request=process_request):
        await asyncio.Future()  # Block forever
