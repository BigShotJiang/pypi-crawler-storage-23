"""Terminal audio I/O using sounddevice for mic capture and speaker playback."""

import base64
import queue
import threading
from typing import Callable

import numpy as np
import sounddevice as sd

from voice_vibecoder.config import (
    AUDIO_SAMPLE_RATE,
    AUDIO_CHANNELS,
    AUDIO_DTYPE,
    CHUNK_SIZE,
)


class AudioManager:
    """Manages mic input and speaker output for the Realtime API.

    Audio format: PCM16, 24 kHz, mono — matches OpenAI Realtime requirements.
    Auto-suppresses mic input while playing back audio to prevent
    speaker-to-mic feedback from triggering the server VAD.
    """

    def __init__(self, on_audio_chunk: Callable[[str], None]) -> None:
        self._on_audio_chunk = on_audio_chunk
        self._input_stream: sd.InputStream | None = None
        self._output_stream: sd.OutputStream | None = None
        self._playback_queue: queue.Queue[bytes] = queue.Queue()
        self._muted = False
        self._playing = False
        self._running = False
        self._playback_thread: threading.Thread | None = None

    @property
    def muted(self) -> bool:
        return self._muted

    def start(self) -> None:
        self._running = True
        self._input_stream = sd.InputStream(
            samplerate=AUDIO_SAMPLE_RATE,
            channels=AUDIO_CHANNELS,
            dtype=AUDIO_DTYPE,
            blocksize=CHUNK_SIZE,
            callback=self._mic_callback,
        )
        self._output_stream = sd.OutputStream(
            samplerate=AUDIO_SAMPLE_RATE,
            channels=AUDIO_CHANNELS,
            dtype=AUDIO_DTYPE,
            blocksize=CHUNK_SIZE,
        )
        self._input_stream.start()
        self._output_stream.start()
        self._playback_thread = threading.Thread(
            target=self._playback_loop, daemon=True
        )
        self._playback_thread.start()

    def stop(self) -> None:
        self._running = False
        if self._input_stream:
            self._input_stream.stop()
            self._input_stream.close()
            self._input_stream = None
        if self._output_stream:
            self._output_stream.stop()
            self._output_stream.close()
            self._output_stream = None
        self._playback_queue.put(b"")

    def set_muted(self, muted: bool) -> None:
        self._muted = muted

    def play_audio(self, base64_pcm: str) -> None:
        pcm_data = base64.b64decode(base64_pcm)
        self._playback_queue.put(pcm_data)

    def clear_playback(self) -> None:
        self._playing = False
        while not self._playback_queue.empty():
            try:
                self._playback_queue.get_nowait()
            except queue.Empty:
                break

    def _mic_callback(self, indata: np.ndarray, frames: int, time_info, status) -> None:
        if self._muted or self._playing or not self._running:
            return
        pcm_bytes = indata.tobytes()
        encoded = base64.b64encode(pcm_bytes).decode("ascii")
        self._on_audio_chunk(encoded)

    def _playback_loop(self) -> None:
        while self._running:
            try:
                pcm_data = self._playback_queue.get(timeout=0.5)
            except queue.Empty:
                if self._playing:
                    self._playing = False
                continue
            if not pcm_data or not self._running:
                break
            self._playing = True
            audio_array = np.frombuffer(pcm_data, dtype=np.int16).reshape(-1, 1)
            try:
                if self._output_stream and self._running:
                    self._output_stream.write(audio_array)
            except Exception:
                pass
        self._playing = False
