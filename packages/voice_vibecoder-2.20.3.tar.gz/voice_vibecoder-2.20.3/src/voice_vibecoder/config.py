"""Configuration for OpenAI Realtime API voice coding sessions."""

from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Literal

AUDIO_SAMPLE_RATE = 24000
AUDIO_CHANNELS = 1
AUDIO_DTYPE = "int16"
CHUNK_DURATION_MS = 100
CHUNK_SIZE = AUDIO_SAMPLE_RATE * CHUNK_DURATION_MS // 1000

Language = Literal["no", "en", "sv"]
PermissionMode = Literal["bypass", "acceptEdits", "default"]
InputMode = Literal["vad", "ptt"]
AgentType = Literal["claude", "cursor", "openclaw"]


def _agent_names(enabled: list[str] | None = None) -> str:
    """Return human-readable agent names for system instructions."""
    from voice_vibecoder.code_providers.registry import get_agent

    if not enabled:
        enabled = ["claude"]
    return " / ".join(get_agent(a).label for a in enabled)


_SYSTEM_INSTRUCTIONS: dict[Language, str] = {
    "no": """\
Du er Olaf, en hjelpsom stemmeassistent for utviklere. Snakk alltid norsk. \
Brukeren skal oppleve en helt vanlig samtale — du bare hjelper.

Svar direkte på:
- Hilsener, småprat, korte spørsmål
- Enkel status: bruk list_branches / get_agent_status og fortell
- Bekreftelser og ting som ikke krever oppslag eller kode

Alt annet delegerer du USYNLIG — brukeren trenger aldri vite om det:
- Kodeoppgaver (funksjoner, bugs, refaktorering, tester, konfig) → send_to_agent. \
Auto-generer branchnavn fra oppgaven ("legg til dark mode" → "dark-mode"). \
Aldri spør om branchnavn med mindre brukeren eksplisitt nevner en. \
Branch-navn fuzzy-matches — "branding" matcher "feat/branding-refresh".
- Alt annet (research, spørsmål, data, planlegging, analyse, Jira, CI) → send_to_session \
med beskrivende navn.
- Si aldri "jeg sender dette til en agent" — si heller "Ser på det!" / "Et øyeblikk."
- Videresend brukerens ord NØYAKTIG til agenten. Ikke omskriv.

Hold samtalen i gang mens du venter — ikke la det bli stille. \
Småprat, kommentarer, humor — hva som helst som føles naturlig. \
Hvis en forespørsel tar tid, forklar kort hva du tenker eller gjør (uten å nevne agenter).

Når agenten er ferdig, lever resultatet som om DU fant svaret. \
Oppsummer kort i én-to setninger.

Gjenbruk — ikke start nye agenter med mindre det åpenbart gir mening:
- SJEKK ALLTID aktive instanser nedenfor før du oppretter en ny.
- Gjenbruk eksisterende sesjon/branch for samme eller relatert tema (bruk det eksakte navnet). \
Ny instans betyr tapt kontekst — unngå det.
- Oppfølgingsspørsmål → send til samme sesjon/branch automatisk.
- Bare opprett ny instans når oppgaven er tydelig uavhengig av alt som allerede kjører.
{active_instances}

Agenter: {agent_names}.

Brukeren bestemmer:
- Når brukeren spesifikt sier hvilken sesjon eller branch, BARE videresend. \
Aldri nekt eller korriger.
- Brukeren har ALLTID rett til å sende hva som helst til hvilken som helst sesjon/agent.

Avbryt/reset:
- "avbryt", "stopp" → cancel_agent (med branch eller session_name)
- "start på nytt", "reset" → reset_agent
- remove_branch_instance / remove_session for å fjerne instanser.

Visning:
- "vis diff" → show_diff
- "vis output", "gå tilbake" → show_output
- "fullskjerm" → toggle_fullscreen

Spørsmål fra agenten:
- Still spørsmålet til brukeren. Videresend svaret ordrett via answer_agent_question.""",
    "en": """\
You are Olaf, a helpful voice assistant for developers. Always speak English. \
The user should experience a normal conversation — you just help.

Answer directly:
- Greetings, small talk, short questions
- Simple status: use list_branches / get_agent_status and tell them
- Confirmations and things that don't require lookups or code

Everything else you delegate INVISIBLY — the user never needs to know:
- Code tasks (features, bugs, refactoring, tests, config) → send_to_agent. \
Auto-generate branch name from the task ("add dark mode" → "dark-mode"). \
Never ask for a branch name unless the user explicitly mentions one. \
Branch names are fuzzy-matched — "branding" matches "feat/branding-refresh".
- Everything else (research, questions, data, planning, analysis, Jira, CI) → send_to_session \
with a descriptive name.
- Never say "I'm sending this to an agent" — say "Looking into it!" / "One moment."
- Forward the user's words EXACTLY to the agent. Don't rewrite.

Keep the conversation going while you wait — never let it go silent. \
Small talk, comments, humor — whatever feels natural. \
If a request takes time, briefly explain what you're thinking or doing (without mentioning agents).

When the agent finishes, deliver the result as if YOU found the answer. \
Summarize briefly in one or two sentences.

Reuse — don't start new agents unless it obviously makes sense:
- ALWAYS check active instances below before creating a new one.
- Reuse existing session/branch for the same or related topic (use the exact name). \
A new instance means lost context — avoid it.
- Follow-up questions → send to the same session/branch automatically.
- Only create a new instance when the task is clearly independent of everything already running.
{active_instances}

Agents: {agent_names}.

User is in control:
- When the user specifically says which session or branch, JUST forward. \
Never refuse or correct.
- The user ALWAYS has the right to send anything to any session/agent.

Cancel/reset:
- "cancel", "stop" → cancel_agent (with branch or session_name)
- "start fresh", "reset" → reset_agent
- remove_branch_instance / remove_session to remove instances.

Views:
- "show diff" → show_diff
- "show output", "go back" → show_output
- "fullscreen" → toggle_fullscreen

Questions from the agent:
- Ask the user the question. Forward their answer verbatim via answer_agent_question.""",
    "sv": """\
Du är Olaf, en hjälpsam röstassistent för utvecklare. Tala alltid svenska. \
Användaren ska uppleva ett helt vanligt samtal — du bara hjälper.

Svara direkt på:
- Hälsningar, småprat, korta frågor
- Enkel status: använd list_branches / get_agent_status och berätta
- Bekräftelser och saker som inte kräver uppslag eller kod

Allt annat delegerar du OSYNLIGT — användaren behöver aldrig veta:
- Koduppgifter (funktioner, buggar, refaktorering, tester, konfig) → send_to_agent. \
Auto-generera branchnamn från uppgiften ("lägg till dark mode" → "dark-mode"). \
Fråga aldrig om branchnamn om inte användaren uttryckligen nämner ett. \
Branch-namn fuzzy-matchas — "branding" matchar "feat/branding-refresh".
- Allt annat (research, frågor, data, planering, analys, Jira, CI) → send_to_session \
med beskrivande namn.
- Säg aldrig "jag skickar detta till en agent" — säg hellre "Kollar på det!" / "Ett ögonblick."
- Vidarebefordra användarens ord EXAKT till agenten. Skriv inte om.

Håll samtalet igång medan du väntar — låt det aldrig bli tyst. \
Småprat, kommentarer, humor — vad som helst som känns naturligt. \
Om en förfrågan tar tid, förklara kort vad du tänker eller gör (utan att nämna agenter).

När agenten är klar, leverera resultatet som om DU hittade svaret. \
Sammanfatta kort i en till två meningar.

Återanvändning — starta inte nya agenter om det inte uppenbart behövs:
- KONTROLLERA ALLTID aktiva instanser nedan innan du skapar en ny.
- Återanvänd befintlig session/branch för samma eller relaterat ämne (använd det exakta namnet). \
En ny instans innebär förlorad kontext — undvik det.
- Uppföljningsfrågor → skicka till samma session/branch automatiskt.
- Skapa bara en ny instans när uppgiften är tydligt oberoende av allt som redan körs.
{active_instances}

Agenter: {agent_names}.

Användaren bestämmer:
- När användaren specifikt säger vilken session eller branch, BARA vidarebefordra. \
Aldrig vägra eller korrigera.
- Användaren har ALLTID rätt att skicka vad som helst till vilken session/agent som helst.

Avbryt/reset:
- "avbryt", "stopp" → cancel_agent (med branch eller session_name)
- "börja om", "reset" → reset_agent
- remove_branch_instance / remove_session för att ta bort instanser.

Visning:
- "visa diff" → show_diff
- "visa output", "gå tillbaka" → show_output
- "helskärm" → toggle_fullscreen

Frågor från agenten:
- Ställ frågan till användaren. Vidarebefordra svaret ordagrant via answer_agent_question.""",
}


def get_system_instructions(
    language: Language = "en",
    context: str = "",
    overrides: dict[str, str] | None = None,
    enabled_agents: list[str] | None = None,
    active_instances: str = "",
) -> str:
    if overrides and language in overrides:
        base = overrides[language]
    else:
        base = _SYSTEM_INSTRUCTIONS.get(language, _SYSTEM_INSTRUCTIONS["en"])
    instances_text = active_instances or "(No active sessions or agents.)"
    has_instances_placeholder = "{active_instances}" in base
    try:
        base = base.format(
            agent_names=_agent_names(enabled_agents),
            active_instances=instances_text,
        )
    except KeyError:
        # Override instructions may not have all placeholders
        base = base.format(agent_names=_agent_names(enabled_agents))
    # If the template didn't have {active_instances}, append inline
    if not has_instances_placeholder and active_instances:
        base += f"\n\n{instances_text}"
    if context:
        return f"{base}\n\n{context}"
    return base


Provider = Literal["openai", "azure", "gemini"]

VOICES = ["ash", "ballad", "coral", "sage", "shimmer", "alloy", "echo", "verse"]

OPENAI_WS_URL = "wss://api.openai.com/v1/realtime"
OPENAI_DEFAULT_MODEL = "gpt-4o-realtime-preview"

AZURE_DEFAULT_ENDPOINT = ""
AZURE_DEFAULT_DEPLOYMENT = ""
AZURE_API_VERSION = "2024-10-01-preview"

GEMINI_WS_URL = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent"
GEMINI_DEFAULT_MODEL = "models/gemini-2.5-flash-native-audio-latest"
GEMINI_VOICES = ["Kore", "Aoede", "Charon", "Fenrir", "Puck", "Leda", "Orus", "Zephyr"]

# Module-level configurable path — set via configure_paths()
from voice_vibecoder.app_config import _default_config_dir

SETTINGS_PATH = _default_config_dir() / "realtime.json"

LANGUAGES = [("English", "en"), ("Norsk", "no"), ("Svenska", "sv")]
PERMISSION_MODES = [
    ("Bypass (no prompts)", "bypass"),
    ("Accept edits only", "acceptEdits"),
    ("Default (prompt all)", "default"),
]
INPUT_MODES = [("Voice Activity Detection", "vad"), ("Push-to-Talk", "ptt")]


def configure_paths(config_dir: Path) -> None:
    """Set the settings file path based on the configured config directory."""
    global SETTINGS_PATH
    SETTINGS_PATH = config_dir / "realtime.json"


@dataclass
class OpenAIConfig:
    """Per-provider settings for OpenAI."""
    api_key: str = ""
    model: str = OPENAI_DEFAULT_MODEL
    voice: str = "ash"
    vad_threshold: float = 0.8
    silence_duration_ms: int = 700
    prefix_padding_ms: int = 300


@dataclass
class AzureConfig:
    """Per-provider settings for Azure OpenAI."""
    api_key: str = ""
    endpoint: str = AZURE_DEFAULT_ENDPOINT
    deployment: str = AZURE_DEFAULT_DEPLOYMENT
    voice: str = "ash"
    vad_threshold: float = 0.8
    silence_duration_ms: int = 700
    prefix_padding_ms: int = 300


@dataclass
class GeminiConfig:
    """Per-provider settings for Gemini."""
    api_key: str = ""
    model: str = GEMINI_DEFAULT_MODEL
    voice: str = "Puck"
    start_sensitivity: str = "HIGH"   # "HIGH" or "LOW"
    end_sensitivity: str = "LOW"      # "HIGH" or "LOW"
    silence_duration_ms: int = 700
    prefix_padding_ms: int = 100


class RealtimeSettings:
    """Persisted settings for the Realtime voice coding feature."""

    def __init__(
        self,
        provider: Provider = "openai",
        api_key: str = "",
        # Per-provider configs
        openai: OpenAIConfig | None = None,
        azure: AzureConfig | None = None,
        gemini: GeminiConfig | None = None,
        # Agent
        agent_timeout: int = 300,
        # Language
        language: Language = "en",
        # Permission mode
        permission_mode: PermissionMode = "bypass",
        # Input mode
        input_mode: InputMode = "vad",
        # Enabled coding agents
        enabled_agents: list[str] | None = None,
    ) -> None:
        self.provider = provider
        self.api_key = api_key
        self.openai = openai or OpenAIConfig()
        self.azure = azure or AzureConfig()
        self.gemini = gemini or GeminiConfig()
        self.agent_timeout = agent_timeout
        self.language = language
        self.permission_mode = permission_mode
        self.input_mode = input_mode
        self.enabled_agents: list[str] = enabled_agents or ["claude"]

    @property
    def active_api_key(self) -> str:
        """Return the API key for the active provider.

        Checks the per-provider key first, falls back to the legacy
        top-level ``api_key`` for backward compatibility.
        """
        provider_key = self.active_provider_config.api_key
        return provider_key or self.api_key

    @property
    def active_voice(self) -> str:
        """Return the voice setting for the active provider."""
        if self.provider == "azure":
            return self.azure.voice
        if self.provider == "gemini":
            return self.gemini.voice
        return self.openai.voice

    @property
    def active_provider_config(self) -> OpenAIConfig | AzureConfig | GeminiConfig:
        """Return the config object for the active provider."""
        if self.provider == "azure":
            return self.azure
        if self.provider == "gemini":
            return self.gemini
        return self.openai

    @property
    def ws_url(self) -> str:
        if self.provider == "azure":
            return (
                f"wss://{self.azure.endpoint}/openai/realtime"
                f"?api-version={AZURE_API_VERSION}"
                f"&deployment={self.azure.deployment}"
            )
        if self.provider == "gemini":
            return f"{GEMINI_WS_URL}?key={self.active_api_key}"
        return f"{OPENAI_WS_URL}?model={self.openai.model}"

    @property
    def ws_headers(self) -> dict[str, str]:
        if self.provider == "azure":
            return {"api-key": self.active_api_key}
        if self.provider == "gemini":
            return {}
        return {
            "Authorization": f"Bearer {self.active_api_key}",
            "OpenAI-Beta": "realtime=v1",
        }

    @property
    def is_configured(self) -> bool:
        return bool(self.active_api_key)

    @property
    def provider_label(self) -> str:
        if self.provider == "azure":
            return f"Azure ({self.azure.deployment})"
        if self.provider == "gemini":
            return f"Gemini ({self.gemini.model})"
        return f"OpenAI ({self.openai.model})"

    def save(self) -> None:
        SETTINGS_PATH.parent.mkdir(parents=True, exist_ok=True)
        SETTINGS_PATH.write_text(json.dumps(self._to_dict(), indent=2))

    def _to_dict(self) -> dict:
        return {
            "provider": self.provider,
            "api_key": self.api_key,
            "openai": asdict(self.openai),
            "azure": asdict(self.azure),
            "gemini": asdict(self.gemini),
            "agent_timeout": self.agent_timeout,
            "language": self.language,
            "permission_mode": self.permission_mode,
            "input_mode": self.input_mode,
            "enabled_agents": self.enabled_agents,
        }

    @classmethod
    def load(cls) -> RealtimeSettings:
        if not SETTINGS_PATH.exists():
            return cls()
        try:
            data = json.loads(SETTINGS_PATH.read_text())
            # Migrate flat format → nested format
            if "openai_model" in data or "vad_threshold" in data:
                data = cls._migrate_flat(data)
            return cls(
                provider=data.get("provider", "openai"),
                api_key=data.get("api_key", ""),
                openai=cls._load_openai(data.get("openai", {})),
                azure=cls._load_azure(data.get("azure", {})),
                gemini=cls._load_gemini(data.get("gemini", {})),
                agent_timeout=data.get("agent_timeout", 300),
                language=data.get("language", "en"),
                permission_mode=data.get("permission_mode", "bypass"),
                input_mode=data.get("input_mode", "vad"),
                enabled_agents=data.get("enabled_agents"),
            )
        except (json.JSONDecodeError, OSError):
            return cls()

    @staticmethod
    def _load_openai(d: dict) -> OpenAIConfig:
        return OpenAIConfig(
            api_key=d.get("api_key", ""),
            model=d.get("model", OPENAI_DEFAULT_MODEL),
            voice=d.get("voice", "ash"),
            vad_threshold=d.get("vad_threshold", 0.8),
            silence_duration_ms=d.get("silence_duration_ms", 700),
            prefix_padding_ms=d.get("prefix_padding_ms", 300),
        )

    @staticmethod
    def _load_azure(d: dict) -> AzureConfig:
        return AzureConfig(
            api_key=d.get("api_key", ""),
            endpoint=d.get("endpoint", AZURE_DEFAULT_ENDPOINT),
            deployment=d.get("deployment", AZURE_DEFAULT_DEPLOYMENT),
            voice=d.get("voice", "ash"),
            vad_threshold=d.get("vad_threshold", 0.8),
            silence_duration_ms=d.get("silence_duration_ms", 700),
            prefix_padding_ms=d.get("prefix_padding_ms", 300),
        )

    @staticmethod
    def _load_gemini(d: dict) -> GeminiConfig:
        return GeminiConfig(
            api_key=d.get("api_key", ""),
            model=d.get("model", GEMINI_DEFAULT_MODEL),
            voice=d.get("voice", "Puck"),
            start_sensitivity=d.get("start_sensitivity", "HIGH"),
            end_sensitivity=d.get("end_sensitivity", "LOW"),
            silence_duration_ms=d.get("silence_duration_ms", 700),
            prefix_padding_ms=d.get("prefix_padding_ms", 100),
        )

    @staticmethod
    def _migrate_flat(data: dict) -> dict:
        """Migrate old flat-key format into nested provider dicts."""
        voice = data.get("voice", "ash")
        vad_t = data.get("vad_threshold", 0.8)
        silence = data.get("silence_duration_ms", 700)
        prefix = data.get("prefix_padding_ms", 300)

        data["openai"] = {
            "model": data.pop("openai_model", OPENAI_DEFAULT_MODEL),
            "voice": voice,
            "vad_threshold": vad_t,
            "silence_duration_ms": silence,
            "prefix_padding_ms": prefix,
        }
        data["azure"] = {
            "endpoint": data.pop("azure_endpoint", AZURE_DEFAULT_ENDPOINT),
            "deployment": data.pop("azure_deployment", AZURE_DEFAULT_DEPLOYMENT),
            "voice": voice,
            "vad_threshold": vad_t,
            "silence_duration_ms": silence,
            "prefix_padding_ms": prefix,
        }
        data["gemini"] = {
            "model": data.pop("gemini_model", GEMINI_DEFAULT_MODEL),
            "voice": voice if voice in GEMINI_VOICES else "Puck",
            "start_sensitivity": "HIGH",
            "end_sensitivity": "HIGH",
        }
        # Remove migrated flat keys
        for k in ("voice", "vad_threshold", "silence_duration_ms", "prefix_padding_ms"):
            data.pop(k, None)
        return data

    @staticmethod
    def clear() -> None:
        try:
            SETTINGS_PATH.unlink(missing_ok=True)
        except OSError:
            pass
