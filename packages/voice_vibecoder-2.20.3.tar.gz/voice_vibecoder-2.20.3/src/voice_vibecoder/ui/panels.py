"""PanelMixin — instance panel management for VoiceCodingScreen.

Handles creating, updating, toggling fullscreen, and removing agent
instance panels in the grid layout.
"""

import logging
import math

logger = logging.getLogger(__name__)

from textual.containers import Grid, Horizontal, Vertical
from textual.widgets import Static, RichLog, Tree

from voice_vibecoder.code_providers.registry import get_badge
from voice_vibecoder.instances import AgentInstance, InstanceStatus, InstanceType
from voice_vibecoder.ui.styles import _STATUS_ICONS


_FILE_STATUS_ICONS = {
    "modified": "[yellow]M[/yellow]",
    "new": "[green]A[/green]",
    "deleted": "[red]D[/red]",
    "unchanged": "[dim]·[/dim]",
}

_FILE_STATUS_COLORS = {
    "modified": "yellow",
    "new": "green",
    "deleted": "red",
    "unchanged": "dim",
}


class FileTreeWidget(Tree):
    """Interactive file tree sidebar with clickable expand/collapse folders."""

    show_root = False

    DEFAULT_CSS = """
    FileTreeWidget {
        scrollbar-size: 1 1;
    }
    """

    def __init__(self, tree_data: dict, **kwargs):
        super().__init__(tree_data.get("name", "files"), **kwargs)
        self._user_toggled: dict[str, bool] = {}
        self._rebuilding = False
        self._build_from_data(tree_data)

    def _build_from_data(self, tree_data: dict) -> None:
        self._rebuilding = True
        self.clear()
        self.root.expand()
        for child in tree_data.get("children", []):
            self._insert_node(self.root, child)
        self._rebuilding = False

    def _insert_node(self, parent, node_data: dict) -> None:
        path = node_data.get("path", "")
        name = node_data.get("name", "")

        if node_data["type"] == "folder":
            if path in self._user_toggled:
                should_expand = self._user_toggled[path]
            else:
                should_expand = node_data.get("expanded", False)

            label = f"[bold dim]{name}/[/bold dim]"
            folder_node = parent.add(label, data={"path": path, "type": "folder"}, expand=should_expand)

            for child in node_data.get("children", []):
                self._insert_node(folder_node, child)
        else:
            status = node_data.get("status", "unchanged")
            icon = _FILE_STATUS_ICONS.get(status, "[dim]·[/dim]")
            color = _FILE_STATUS_COLORS.get(status, "dim")
            label = f"{icon} [{color}]{name}[/{color}]"
            parent.add_leaf(label, data={"path": path, "type": "file", "status": status})

    def rebuild(self, tree_data: dict) -> None:
        """Rebuild tree from new data, preserving user expand/collapse state."""
        self._build_from_data(tree_data)

    def on_tree_node_expanded(self, event) -> None:
        if self._rebuilding:
            return
        if event.node.data and event.node.data.get("type") == "folder":
            self._user_toggled[event.node.data["path"]] = True

    def on_tree_node_collapsed(self, event) -> None:
        if self._rebuilding:
            return
        if event.node.data and event.node.data.get("type") == "folder":
            self._user_toggled[event.node.data["path"]] = False


def _format_header(inst: AgentInstance, status: InstanceStatus | None = None) -> str:
    """Format panel header: icon + display_key + agent badge."""
    s = status or inst.status
    icon = _STATUS_ICONS.get(s, "[dim]?[/dim]")
    badge = get_badge(inst.agent_type)
    return f"{icon} {inst.display_key}  {badge}"


def _calculate_grid_size(item_count: int, max_columns: int = 4) -> tuple[int, int]:
    """Calculate optimal (columns, rows) for a grid layout."""
    if item_count <= 0:
        return (1, 1)
    if item_count == 1:
        return (1, 1)
    if item_count == 2:
        return (2, 1)
    cols = min(math.ceil(math.sqrt(item_count)), max_columns)
    rows = math.ceil(item_count / cols)
    return (cols, rows)


def _apply_grid_size(grid_widget, item_count: int, max_columns: int = 4) -> None:
    """Apply optimal grid dimensions to a Textual Grid widget."""
    cols, rows = _calculate_grid_size(item_count, max_columns)
    grid_widget.styles.grid_size_columns = cols
    grid_widget.styles.grid_size_rows = rows


class PanelMixin:
    """Mixin providing panel management methods for VoiceCodingScreen."""

    def _dismiss_welcome(self) -> None:
        """Remove the welcome panel if present."""
        try:
            self.query_one("#welcome-panel").remove()
        except Exception:
            pass

    def _show_welcome(self) -> None:
        """Re-show the welcome panel if the grid is empty."""
        try:
            self.query_one("#welcome-panel")
            return  # already showing
        except Exception:
            pass
        try:
            grid = self.query_one("#agent-grid", Grid)
            if len(grid.children) == 0:
                grid.mount(Static(self._WELCOME_TEXT, id="welcome-panel"))
        except Exception:
            pass

    def _create_panels_batch(self, instances: list) -> None:
        """Create all panels in one mount call for faster startup."""
        if instances:
            self._dismiss_welcome()
        panels = []
        for inst in instances:
            header_text = _format_header(inst)
            header = Static(
                header_text,
                classes="agent-header agent-header-idle",
                id=f"header-{inst.instance_id}",
            )
            output = RichLog(
                highlight=True,
                markup=True,
                classes="agent-output",
                id=f"output-{inst.instance_id}",
            )
            inst.header_widget = header
            inst.output_widget = output

            if inst.instance_type == InstanceType.CODE:
                _empty_tree = {"name": "", "path": "", "type": "folder", "children": [], "expanded": True}
                tree_widget = FileTreeWidget(
                    _empty_tree,
                    classes="file-tree-sidebar",
                    id=f"file-tree-{inst.instance_id}",
                )
                body = Horizontal(
                    tree_widget,
                    output,
                    classes="file-tree-container",
                    id=f"file-tree-wrap-{inst.instance_id}",
                )
            else:
                body = output

            panel = Vertical(
                header,
                body,
                classes="agent-panel",
                id=f"panel-{inst.instance_id}",
            )
            panels.append(panel)

        try:
            grid = self.query_one("#agent-grid", Grid)
            grid.styles.display = "block"
            grid.mount_all(panels)
            _apply_grid_size(grid, len(panels), max_columns=3)
        except Exception:
            pass

    def _create_instance_panel(self, instance_id: str, display_key: str) -> None:
        """Create a new panel in the grid for an agent instance."""
        self._dismiss_welcome()
        inst = self._session.registry.get_by_id(instance_id) if self._session else None
        header_text = _format_header(inst) if inst else f"{_STATUS_ICONS[InstanceStatus.IDLE]} {display_key}"
        header = Static(
            header_text,
            classes="agent-header agent-header-idle",
            id=f"header-{instance_id}",
        )
        output = RichLog(
            highlight=True,
            markup=True,
            classes="agent-output",
            id=f"output-{instance_id}",
        )

        if inst:
            inst.header_widget = header
            inst.output_widget = output

        is_code = inst and inst.instance_type == InstanceType.CODE
        if is_code:
            _empty_tree = {"name": "", "path": "", "type": "folder", "children": [], "expanded": True}
            tree_widget = FileTreeWidget(
                _empty_tree,
                classes="file-tree-sidebar",
                id=f"file-tree-{instance_id}",
            )
            body = Horizontal(
                tree_widget,
                output,
                classes="file-tree-container",
                id=f"file-tree-wrap-{instance_id}",
            )
        else:
            body = output

        panel = Vertical(
            header,
            body,
            classes="agent-panel",
            id=f"panel-{instance_id}",
        )

        try:
            grid = self.query_one("#agent-grid", Grid)
            grid.styles.display = "block"
            grid.mount(panel)
            panel_count = len(grid.children)
            _apply_grid_size(grid, panel_count, max_columns=3)
        except Exception:
            pass

    def _update_instance_header(self, instance_id: str, status: InstanceStatus) -> None:
        if not self._session:
            return
        inst = self._session.registry.get_by_id(instance_id)
        if not inst or not inst.header_widget:
            return

        inst.header_widget.update(_format_header(inst, status))

        header = inst.header_widget
        header.remove_class("agent-header-idle", "agent-header-running", "agent-header-waiting_input", "agent-header-error")
        header.add_class(f"agent-header-{status.value}")

    def _show_diff_view(self, instance_id: str, data: dict) -> None:
        """Replace agent output with a diff view in the panel."""
        from voice_vibecoder.ui.diff_view import create_diff_view, format_file_list

        if not self._session:
            return
        inst = self._session.registry.get_by_id(instance_id)
        if not inst:
            return

        if inst.output_widget:
            inst.output_widget.styles.display = "none"

        files = data.get("files", [])
        diff_lines = data.get("diff_lines", [])

        # Reuse existing diff view if present — avoids mount timing issues
        try:
            file_list_widget = self.query_one(f"#diff-files-{instance_id}", Static)
            diff_log = self.query_one(f"#diff-log-{instance_id}", RichLog)
            file_list_widget.update(format_file_list(files))
            diff_log.clear()
            for line in diff_lines:
                diff_log.write(line)
            return
        except Exception:
            pass

        # First time — create and mount
        diff_view, diff_log = create_diff_view(instance_id, files, diff_lines)

        try:
            panel = self.query_one(f"#panel-{instance_id}")
            panel.mount(diff_view)
            for line in diff_lines:
                diff_log.write(line)
        except Exception:
            pass

    def _hide_diff_view(self, instance_id: str) -> None:
        """Remove diff view and restore agent output."""
        if not self._session:
            return
        inst = self._session.registry.get_by_id(instance_id)
        if not inst:
            return

        try:
            diff_view = self.query_one(f"#diff-view-{instance_id}")
            diff_view.remove()
        except Exception:
            pass

        if inst.output_widget:
            inst.output_widget.styles.display = "block"

    def _toggle_fullscreen(self, instance_id: str) -> None:
        """Toggle fullscreen for a panel."""
        try:
            grid = self.query_one("#agent-grid", Grid)
            transcript = self.query_one("#voice-transcript", RichLog)
        except Exception:
            return

        if self._fullscreen_id == instance_id:
            self._fullscreen_id = None
            self._state._fullscreen_branch = None
            if self._session:
                self._session.registry.fullscreen_id = None
            transcript.styles.display = "block"
            for panel in grid.query(".agent-panel"):
                panel.styles.display = "block"
            panel_count = len(grid.children)
            _apply_grid_size(grid, panel_count, max_columns=3)
        else:
            self._fullscreen_id = instance_id
            if self._session:
                self._session.registry.fullscreen_id = instance_id
                inst = self._session.registry.get_by_id(instance_id)
                if inst:
                    self._state._fullscreen_branch = inst.display_key
            transcript.styles.display = "none"
            for panel in grid.query(".agent-panel"):
                pid = getattr(panel, "id", "") or ""
                if pid == f"panel-{instance_id}":
                    panel.styles.display = "block"
                else:
                    panel.styles.display = "none"
            grid.styles.grid_size_columns = 1
            grid.styles.grid_size_rows = 1

    def _update_file_tree(self, instance_id: str, data: dict) -> None:
        """Update the file tree sidebar for a code instance panel."""
        tree_data = data.get("tree")
        if not tree_data or not tree_data.get("children"):
            return

        try:
            tree_widget = self.query_one(f"#file-tree-{instance_id}", FileTreeWidget)
            tree_widget.rebuild(tree_data)
        except Exception:
            pass

    def _remove_instance_panel(self, instance_id: str) -> None:
        """Remove a panel from the grid."""
        if self._session:
            inst = self._session.registry.get_by_id(instance_id)
            if inst:
                self._state.remove_instance(inst.display_key)

        if self._fullscreen_id == instance_id:
            self._fullscreen_id = None
            try:
                transcript = self.query_one("#voice-transcript", RichLog)
                transcript.styles.display = "block"
            except Exception:
                pass

        try:
            panel = self.query_one(f"#panel-{instance_id}")
            panel.remove()
            grid = self.query_one("#agent-grid", Grid)
            panel_count = len(grid.children)
            if panel_count > 0:
                _apply_grid_size(grid, panel_count, max_columns=3)
            else:
                self._show_welcome()
        except Exception:
            pass
