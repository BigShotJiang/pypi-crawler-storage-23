"""First-run setup wizard — 5 steps: Language, Agents, Provider, API Key, Voice."""

from __future__ import annotations

import asyncio
import shutil
import subprocess

from textual.binding import Binding
from textual.containers import Vertical, Center, Horizontal
from textual.screen import Screen
from textual.widgets import Header, Footer, Static, Input, Select, Button, Switch

from voice_vibecoder.code_providers.registry import get_agent, get_choices as get_agent_choices
from voice_vibecoder.config import (
    RealtimeSettings, OpenAIConfig, AzureConfig, GeminiConfig,
    VOICES, GEMINI_VOICES, GEMINI_DEFAULT_MODEL, LANGUAGES,
)

WIZARD_CSS = """
SetupWizardScreen {
    background: $surface;
}

#wizard-scroll {
    align: center middle;
    width: 100%;
    height: 100%;
}

#wizard-card {
    width: 64;
    height: auto;
    max-height: 85%;
    padding: 2 3;
    border: solid $accent;
    background: $surface;
}

#wizard-title {
    text-align: center;
    padding: 0 0 1 0;
}

.wizard-step {
    height: auto;
    padding: 1 0;
}

.wizard-text {
    padding: 0 0 1 0;
}

.wizard-label {
    padding: 1 0 0 0;
}

.wizard-buttons {
    height: auto;
    padding: 1 0 0 0;
    align: right middle;
}

.wizard-buttons Button {
    margin: 0 0 0 1;
}

#wizard-error {
    color: $error;
    padding: 0 0 1 0;
}

#wizard-test-status, #wizard-voice-status, #wizard-agent-test-status {
    padding: 1 0 0 0;
}

.hidden {
    display: none;
}

.agent-row {
    height: auto;
    padding: 0 0 0 1;
}

.agent-row Static {
    width: 1fr;
    padding: 0 1 0 0;
}

.agent-row Switch {
    width: auto;
}

.agent-detected {
    color: $success;
}

.agent-missing {
    color: $error;
}
"""


PROVIDERS = [
    ("OpenAI", "openai"),
    ("Azure OpenAI", "azure"),
    ("Gemini", "gemini"),
]


class SetupWizardScreen(Screen):
    """5-step first-run wizard: Language → Agents → Provider → API Key → Voice."""

    BINDINGS = [
        Binding("escape", "cancel", "Cancel", priority=True),
    ]

    CSS = WIZARD_CSS

    def __init__(self) -> None:
        super().__init__()
        self._step = 0

    @staticmethod
    def _detect_cli(cmd: str) -> bool:
        return shutil.which(cmd) is not None

    def compose(self):
        yield Header(show_clock=True)
        with Center(id="wizard-scroll"):
            with Vertical(id="wizard-card"):
                yield Static(
                    "[bold cyan]Olaf The Vibecoder[/bold cyan]\n"
                    "[dim]by Snokam[/dim]",
                    id="wizard-title",
                )

                # Step 0: Welcome + Language
                with Vertical(id="step-0", classes="wizard-step"):
                    yield Static(
                        "Welcome! Let's get Olaf set up for you.",
                        classes="wizard-text",
                    )
                    yield Static("Language", classes="wizard-label")
                    yield Select(
                        LANGUAGES,
                        value="en",
                        id="wizard-language",
                    )
                    with Horizontal(classes="wizard-buttons"):
                        yield Button("Next", variant="primary", id="btn-next-0")

                # Step 1: Agent Selection
                with Vertical(id="step-1", classes="wizard-step hidden"):
                    yield Static(
                        "Which coding agents do you want to use?",
                        classes="wizard-text",
                    )
                    for label, agent_id in get_agent_choices():
                        cli_cmd = get_agent(agent_id).cli_command
                        detected = self._detect_cli(cli_cmd)
                        status_cls = "agent-detected" if detected else "agent-missing"
                        status_txt = "detected" if detected else "not found"
                        with Horizontal(classes="agent-row"):
                            yield Switch(
                                value=detected,
                                id=f"wizard-agent-{agent_id}",
                            )
                            yield Static(
                                f"{label}  [{status_cls}]{cli_cmd}: {status_txt}[/{status_cls}]",
                            )
                    yield Static("", id="wizard-agent-error", classes="hidden")
                    yield Static("", id="wizard-agent-test-status", classes="hidden")
                    with Horizontal(classes="wizard-buttons"):
                        yield Button("Back", id="btn-back-1")
                        yield Button("Test Agents", variant="warning", id="btn-test-agents")
                        yield Button("Next", variant="primary", id="btn-next-1")

                # Step 2: Provider
                with Vertical(id="step-2", classes="wizard-step hidden"):
                    yield Static(
                        "Which OpenAI provider do you want to use?",
                        classes="wizard-text",
                    )
                    yield Select(
                        PROVIDERS,
                        value="openai",
                        id="wizard-provider",
                    )
                    with Horizontal(classes="wizard-buttons"):
                        yield Button("Back", id="btn-back-2")
                        yield Button("Next", variant="primary", id="btn-next-2")

                # Step 3: API Key (dynamic based on provider)
                with Vertical(id="step-3", classes="wizard-step hidden"):
                    yield Static(
                        "Enter your OpenAI API key.\n"
                        "[dim]Get one at platform.openai.com/api-keys[/dim]",
                        classes="wizard-text",
                        id="wizard-api-help",
                    )
                    yield Input(
                        placeholder="sk-...",
                        password=True,
                        id="wizard-api-key",
                    )
                    # Azure-specific fields (hidden by default)
                    yield Static("Endpoint", classes="wizard-label hidden", id="lbl-azure-endpoint")
                    yield Input(
                        placeholder="your-resource.openai.azure.com",
                        id="wizard-azure-endpoint",
                        classes="hidden",
                    )
                    yield Static("Deployment", classes="wizard-label hidden", id="lbl-azure-deployment")
                    yield Input(
                        placeholder="gpt-4o-realtime",
                        id="wizard-azure-deployment",
                        classes="hidden",
                    )
                    yield Static("", id="wizard-error", classes="hidden")
                    yield Static("", id="wizard-test-status", classes="hidden")
                    with Horizontal(classes="wizard-buttons"):
                        yield Button("Back", id="btn-back-3")
                        yield Button("Test", variant="warning", id="btn-test")
                        yield Button("Next", variant="primary", id="btn-next-3")

                # Step 4: Voice
                with Vertical(id="step-4", classes="wizard-step hidden"):
                    yield Static("Pick a voice.", classes="wizard-text")
                    yield Select(
                        [(v, v) for v in VOICES],
                        value="ash",
                        id="wizard-voice",
                    )
                    yield Static("", id="wizard-voice-status", classes="hidden")
                    with Horizontal(classes="wizard-buttons"):
                        yield Button("Back", id="btn-back-4")
                        yield Button("Test Voice", variant="warning", id="btn-test-voice")
                        yield Button(
                            "Start Coding",
                            variant="primary",
                            id="btn-finish",
                        )

        yield Footer()

    def on_mount(self) -> None:
        self.query_one("#wizard-language", Select).focus()

    # -- Navigation --

    @property
    def _provider(self) -> str:
        sel = self.query_one("#wizard-provider", Select)
        return sel.value if sel.value != Select.BLANK else "openai"

    def _selected_agents(self) -> list[str]:
        """Return list of agent IDs that are currently switched on."""
        agents = []
        for _label, agent_id in get_agent_choices():
            switch = self.query_one(f"#wizard-agent-{agent_id}", Switch)
            if switch.value:
                agents.append(agent_id)
        return agents

    def _go_to(self, step: int) -> None:
        self.query_one(f"#step-{self._step}").add_class("hidden")
        self._step = step
        self.query_one(f"#step-{self._step}").remove_class("hidden")
        focus_map = {
            0: ("#wizard-language", Select),
            1: (f"#wizard-agent-{get_agent_choices()[0][1]}", Switch),
            2: ("#wizard-provider", Select),
            3: ("#wizard-api-key", Input),
            4: ("#wizard-voice", Select),
        }
        if step in focus_map:
            wid, cls = focus_map[step]
            self.query_one(wid, cls).focus()
        if step == 3:
            self._update_api_step()
        if step == 4:
            self._update_voice_options()

    def _update_api_step(self) -> None:
        """Show/hide fields based on selected provider."""
        provider = self._provider
        help_widget = self.query_one("#wizard-api-help", Static)
        azure_ids = [
            "#lbl-azure-endpoint", "#wizard-azure-endpoint",
            "#lbl-azure-deployment", "#wizard-azure-deployment",
        ]
        if provider == "azure":
            help_widget.update(
                "Enter your Azure OpenAI API key.\n"
                "[dim]Found in Azure Portal → your resource → Keys and Endpoint[/dim]"
            )
            for wid in azure_ids:
                self.query_one(wid).remove_class("hidden")
        elif provider == "gemini":
            help_widget.update(
                "Enter your Google AI API key.\n"
                "[dim]Get one at aistudio.google.com/apikey[/dim]"
            )
            for wid in azure_ids:
                self.query_one(wid).add_class("hidden")
        else:
            help_widget.update(
                "Enter your OpenAI API key.\n"
                "[dim]Get one at platform.openai.com/api-keys[/dim]"
            )
            for wid in azure_ids:
                self.query_one(wid).add_class("hidden")

    def _update_voice_options(self) -> None:
        """Swap voice dropdown options based on selected provider."""
        voices = GEMINI_VOICES if self._provider == "gemini" else VOICES
        default = voices[0]
        voice_sel = self.query_one("#wizard-voice", Select)
        voice_sel.set_options([(v, v) for v in voices])
        voice_sel.value = default

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn = event.button.id
        if btn == "btn-next-0":
            self._go_to(1)
        elif btn == "btn-back-1":
            self._go_to(0)
        elif btn == "btn-test-agents":
            self._test_agents()
        elif btn == "btn-next-1":
            self._validate_agents_and_advance()
        elif btn == "btn-back-2":
            self._go_to(1)
        elif btn == "btn-next-2":
            self._go_to(3)
        elif btn == "btn-back-3":
            self._go_to(2)
        elif btn == "btn-test":
            self._test_connection()
        elif btn == "btn-next-3":
            self._validate_and_advance()
        elif btn == "btn-back-4":
            self._go_to(3)
        elif btn == "btn-test-voice":
            self._test_voice()
        elif btn == "btn-finish":
            self._finish()

    def on_input_submitted(self, event: Input.Submitted) -> None:
        if event.input.id == "wizard-api-key":
            self._test_connection()

    def _validate_agents_and_advance(self) -> None:
        agents = self._selected_agents()
        error_widget = self.query_one("#wizard-agent-error", Static)
        if not agents:
            error_widget.update("[red]Select at least one coding agent.[/red]")
            error_widget.remove_class("hidden")
            return
        error_widget.add_class("hidden")
        self._go_to(2)

    def _test_agents(self) -> None:
        agents = self._selected_agents()
        error_widget = self.query_one("#wizard-agent-error", Static)
        status_widget = self.query_one("#wizard-agent-test-status", Static)
        if not agents:
            error_widget.update("[red]Select at least one coding agent.[/red]")
            error_widget.remove_class("hidden")
            status_widget.add_class("hidden")
            return
        error_widget.add_class("hidden")
        status_widget.update("[yellow]Testing...[/yellow]")
        status_widget.remove_class("hidden")

        btn = self.query_one("#btn-test-agents", Button)
        btn.disabled = True
        self.run_worker(self._do_test_agents(agents), exclusive=True, group="test-agents")

    async def _do_test_agents(self, agents: list[str]) -> None:
        status_widget = self.query_one("#wizard-agent-test-status", Static)
        btn = self.query_one("#btn-test-agents", Button)
        prompt_args = {
            "claude": ["-p", "--output-format", "text", "Respond with exactly: OK"],
            "cursor": ["-p", "--output-format", "text", "--force", "Respond with exactly: OK"],
        }

        results: list[str] = []
        loop = asyncio.get_event_loop()

        for agent_id in agents:
            info = get_agent(agent_id)
            cmd = info.cli_command
            label = info.label

            # Phase 1: version check
            status_widget.update("\n".join(results + [f"[yellow]{label}: checking version...[/yellow]"]))
            try:
                proc = await loop.run_in_executor(
                    None,
                    lambda c=cmd: subprocess.run(
                        [c, "--version"],
                        capture_output=True, text=True, timeout=10,
                    ),
                )
                if proc.returncode != 0:
                    stderr = (proc.stderr.strip() or "unknown error")[:80]
                    results.append(f"[red]{label}: exit {proc.returncode} — {stderr}[/red]")
                    continue
                version = (proc.stdout.strip() or "?").splitlines()[0][:60]
            except FileNotFoundError:
                results.append(f"[red]{label}: '{cmd}' not found in PATH[/red]")
                continue
            except subprocess.TimeoutExpired:
                results.append(f"[red]{label}: version check timed out[/red]")
                continue
            except Exception as exc:
                results.append(f"[red]{label}: {exc}[/red]")
                continue

            # Phase 2: prompt test
            status_widget.update("\n".join(results + [f"[yellow]{label}: {version} — sending test prompt...[/yellow]"]))
            args = prompt_args.get(agent_id, ["-p", "Respond with exactly: OK"])
            try:
                proc = await loop.run_in_executor(
                    None,
                    lambda c=cmd, a=args: subprocess.run(
                        [c, *a],
                        capture_output=True, text=True, timeout=30,
                    ),
                )
                if proc.returncode == 0:
                    results.append(f"[green]{label}: {version} — prompt OK[/green]")
                else:
                    stderr = (proc.stderr.strip() or proc.stdout.strip() or "unknown error")[:80]
                    results.append(f"[red]{label}: {version} — prompt failed: {stderr}[/red]")
            except subprocess.TimeoutExpired:
                results.append(f"[red]{label}: {version} — prompt timed out (30s)[/red]")
            except Exception as exc:
                results.append(f"[red]{label}: {version} — {exc}[/red]")

        status_widget.update("\n".join(results))
        btn.disabled = False

    def _validate_and_advance(self) -> None:
        api_key = self.query_one("#wizard-api-key", Input).value.strip()
        error_widget = self.query_one("#wizard-error", Static)
        if not api_key:
            error_widget.update("API key is required.")
            error_widget.remove_class("hidden")
            return
        error_widget.add_class("hidden")
        self._go_to(4)

    def _build_test_settings(self) -> RealtimeSettings | None:
        """Build a RealtimeSettings from current form state, or None if invalid."""
        api_key = self.query_one("#wizard-api-key", Input).value.strip()
        if not api_key:
            return None
        provider = self._provider
        kwargs: dict = dict(provider=provider, api_key=api_key)
        if provider == "azure":
            endpoint = self.query_one("#wizard-azure-endpoint", Input).value.strip()
            deployment = self.query_one("#wizard-azure-deployment", Input).value.strip()
            if not endpoint or not deployment:
                return None
            kwargs["azure"] = AzureConfig(endpoint=endpoint, deployment=deployment)
        elif provider == "gemini":
            kwargs["gemini"] = GeminiConfig(model=GEMINI_DEFAULT_MODEL)
        return RealtimeSettings(**kwargs)

    def _make_provider(self, settings: RealtimeSettings):
        from voice_vibecoder.voice_providers import create_provider
        return create_provider(settings)

    def _test_connection(self) -> None:
        error_widget = self.query_one("#wizard-error", Static)
        status_widget = self.query_one("#wizard-test-status", Static)

        settings = self._build_test_settings()
        if settings is None:
            missing = []
            if not self.query_one("#wizard-api-key", Input).value.strip():
                missing.append("API key")
            if self._provider == "azure":
                if not self.query_one("#wizard-azure-endpoint", Input).value.strip():
                    missing.append("endpoint")
                if not self.query_one("#wizard-azure-deployment", Input).value.strip():
                    missing.append("deployment")
            error_widget.update(f"{', '.join(missing)} required.")
            error_widget.remove_class("hidden")
            status_widget.add_class("hidden")
            return

        error_widget.add_class("hidden")
        status_widget.update("[yellow]Connecting...[/yellow]")
        status_widget.remove_class("hidden")

        btn = self.query_one("#btn-test", Button)
        btn.disabled = True
        self.run_worker(self._do_test(settings), exclusive=True, group="test")

    async def _do_test(self, settings: RealtimeSettings) -> None:
        status_widget = self.query_one("#wizard-test-status", Static)
        btn = self.query_one("#btn-test", Button)
        try:
            provider = self._make_provider(settings)
            pcm = await provider.test_connection()
            await self._play_audio(pcm)
            status_widget.update("[green]Connected! You're good to go.[/green]")
        except Exception as exc:
            msg = str(exc)
            if len(msg) > 120:
                msg = msg[:120] + "..."
            status_widget.update(f"[red]{msg}[/red]")
        finally:
            btn.disabled = False

    def _test_voice(self) -> None:
        settings = self._build_test_settings()
        if settings is None:
            self.notify("Go back and fill in your credentials first.", severity="warning")
            return

        voice_sel = self.query_one("#wizard-voice", Select)
        voice = voice_sel.value if voice_sel.value != Select.BLANK else "ash"

        status = self.query_one("#wizard-voice-status", Static)
        status.update("[yellow]Connecting...[/yellow]")
        status.remove_class("hidden")

        btn = self.query_one("#btn-test-voice", Button)
        btn.disabled = True
        self.run_worker(self._do_test_voice(settings, voice), exclusive=True, group="test-voice")

    async def _do_test_voice(self, settings: RealtimeSettings, voice: str) -> None:
        status = self.query_one("#wizard-voice-status", Static)
        btn = self.query_one("#btn-test-voice", Button)
        try:
            provider = self._make_provider(settings)
            status.update(f"[yellow]Playing {voice}...[/yellow]")
            pcm = await provider.test_voice(voice)
            await self._play_audio(pcm)
            status.update(f"[green]{voice} — done.[/green]")
        except Exception as exc:
            msg = str(exc)
            if len(msg) > 120:
                msg = msg[:120] + "..."
            status.update(f"[red]{msg}[/red]")
        finally:
            btn.disabled = False

    @staticmethod
    async def _play_audio(pcm: bytes) -> None:
        import numpy as np
        import sounddevice as sd
        from voice_vibecoder.config import AUDIO_SAMPLE_RATE, AUDIO_CHANNELS, AUDIO_DTYPE, CHUNK_SIZE

        audio_array = np.frombuffer(pcm, dtype=np.int16).reshape(-1, 1)

        def _play():
            stream = sd.OutputStream(
                samplerate=AUDIO_SAMPLE_RATE,
                channels=AUDIO_CHANNELS,
                dtype=AUDIO_DTYPE,
                blocksize=CHUNK_SIZE,
            )
            stream.start()
            stream.write(audio_array)
            # Flush with silence so the last block plays fully
            stream.write(np.zeros((CHUNK_SIZE, 1), dtype=np.int16))
            stream.stop()
            stream.close()

        await asyncio.get_event_loop().run_in_executor(None, _play)

    def _finish(self) -> None:
        language_sel = self.query_one("#wizard-language", Select)
        language = language_sel.value if language_sel.value != Select.BLANK else "en"

        provider = self._provider
        api_key = self.query_one("#wizard-api-key", Input).value.strip()

        voice_sel = self.query_one("#wizard-voice", Select)
        voice = voice_sel.value if voice_sel.value != Select.BLANK else "ash"

        enabled_agents = self._selected_agents() or ["claude"]

        kwargs: dict = dict(
            provider=provider, api_key=api_key,
            language=language, enabled_agents=enabled_agents,
        )
        if provider == "azure":
            endpoint = self.query_one("#wizard-azure-endpoint", Input).value.strip()
            deployment = self.query_one("#wizard-azure-deployment", Input).value.strip()
            kwargs["azure"] = AzureConfig(
                endpoint=endpoint or "",
                deployment=deployment or "",
                voice=voice,
            )
        elif provider == "gemini":
            kwargs["gemini"] = GeminiConfig(
                model=GEMINI_DEFAULT_MODEL,
                voice=voice,
            )
        else:
            kwargs["openai"] = OpenAIConfig(voice=voice)

        settings = RealtimeSettings(**kwargs)
        settings.save()
        self.dismiss(settings)

    def action_cancel(self) -> None:
        self.dismiss(None)
