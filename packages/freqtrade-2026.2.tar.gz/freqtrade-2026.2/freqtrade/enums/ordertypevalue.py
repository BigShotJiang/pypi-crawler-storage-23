from enum import StrEnum


class OrderTypeValues(StrEnum):
    limit = "limit"
    market = "market"
