# Disclaimer

* Most of the test-code is AI-generated
* There hasn't been much efforts put into code reviews of the test code

Probably more effort should go into:

1) Verifying that all corner cases are covered
2) Verifying the coverage
3) Check that there is not too much duplicated tests
4) Verify tha the right things are tested

