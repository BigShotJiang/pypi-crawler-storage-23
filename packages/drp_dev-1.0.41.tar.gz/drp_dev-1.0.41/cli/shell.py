"""
DrpShell — cmd2-based REPL for drp.

Dynamically registers every command in ``cli.commands`` as a ``do_*``
method so the registry is the single source of truth.
"""

from __future__ import annotations

import os

import cmd2

from cli import __version__
from cli.commands import Command, all_commands


def _build_help(spec: Command) -> str:
    lines = [spec.description, ""]
    if spec.args:
        lines.append("Arguments:")
        for arg in spec.args:
            tag = f"  {arg.name}"
            if arg.required:
                tag += "  (required)"
            lines.append(tag)
            lines.append(f"      {arg.description}")
            if arg.choices:
                lines.append(f"      choices: {', '.join(arg.choices)}")
            if arg.repeatable:
                lines.append("      (repeatable)")
        lines.append("")
    return "\n".join(lines)


def _in_drive(unified_cwd: str, username: str) -> bool:
    return bool(username) and f"@{username}" in unified_cwd.split("/")


def _drive_subpath(unified_cwd: str, username: str) -> str:
    """Return the drive-relative path after @username."""
    parts = unified_cwd.split("/")
    try:
        idx = parts.index(f"@{username}")
        return "/".join(parts[idx + 1:])
    except ValueError:
        return ""


def _resolve_tab_path(shell, text: str) -> tuple[str, str, str]:
    """Resolve a partial tab path relative to shell.unified_cwd.

    Returns (subpath_for_api, filename_prefix, leading_text).
    """
    dir_part, prefix = (text.rsplit("/", 1) if "/" in text else ("", text))

    parts = shell.unified_cwd.rstrip("/").split("/")
    for segment in dir_part.split("/"):
        if segment == "..":
            if parts:
                parts.pop()
        elif segment and segment != ".":
            parts.append(segment)

    resolved = "/".join(parts)
    if _in_drive(resolved, shell.username):
        subpath = _drive_subpath(resolved, shell.username)
        return subpath, prefix, (dir_part + "/") if dir_part else ""
    return resolved, prefix, (dir_part + "/") if dir_part else ""


def _drive_completions(shell, text: str) -> list[str]:
    try:
        from cli.session import api_get
        subpath, prefix, lead = _resolve_tab_path(shell, text)
        resp = api_get("/api/v1/folders/", params={"path": subpath} if subpath else {})
        if resp.status_code != 200:
            return []
        data = resp.json()
        candidates = (
            [f.get("filename", "") for f in data.get("files", [])]
            + [d.rstrip("/") + "/" for d in data.get("folders", [])]
        )
        return [lead + c for c in candidates if c.startswith(prefix)]
    except Exception:
        return []


def _local_completions(text: str) -> list[str]:
    try:
        expanded = os.path.expanduser(text)
        dir_part = os.path.dirname(expanded) or "."
        prefix = os.path.basename(expanded)
        base = text[: len(text) - len(prefix)]
        return [
            base + e + ("/" if os.path.isdir(os.path.join(dir_part, e)) else "")
            for e in os.listdir(dir_part)
            if e.startswith(prefix)
        ]
    except Exception:
        return []


class DrpShell(cmd2.Cmd):
    """Interactive drp shell."""

    intro = f"drp {__version__} — type 'help' for commands, 'exit' or Ctrl-D to quit.\n"

    def __init__(self, *, username: str = "", **kwargs):
        super().__init__(**kwargs)
        self.username = username
        self.local_cwd = os.getcwd()
        self.unified_cwd = self.local_cwd
        self._update_prompt()
        self.hidden_commands.extend(["alias", "macro", "run_pyscript",
                                     "run_script", "edit", "shell", "set",
                                     "shortcuts"])
        DrpShell._register_commands()

    @property
    def cwd(self) -> str:
        """Drive-relative subpath for commands that need it."""
        if _in_drive(self.unified_cwd, self.username):
            sub = _drive_subpath(self.unified_cwd, self.username)
            return "/" + sub if sub else "/"
        return "/"

    def _update_prompt(self):
        home = os.path.expanduser("~")
        display = self.unified_cwd.replace(home, "~", 1)
        self.prompt = f"\033[36mdrp\033[0m:\033[33m{display}/\033[0m> "

    def do_exit(self, _statement):
        """Exit the drp shell."""
        return True

    @classmethod
    def _register_commands(cls):
        for name, spec in all_commands().items():
            _install_command(cls, spec)

    def default(self, statement: cmd2.Statement):
        self.poutput(f"unknown command: {statement.command}")


def _install_command(cls, spec: Command):
    help_text = _build_help(spec)
    func_name = f"do_{spec.name}"

    def do_func(self, statement: cmd2.Statement):
        from cli.commands import _run_command
        _run_command(self, spec, statement)

    do_func.__doc__ = spec.description
    do_func.__name__ = func_name

    def help_func(self):
        self.poutput(help_text)

    help_func.__name__ = f"help_{spec.name}"

    flag_names = [
        n.strip()
        for arg in spec.args
        for n in arg.name.split("/")
        if n.strip().startswith("-")
    ]
    has_drive_ref = any(
        not any(n.strip().startswith("-") for n in arg.name.split("/"))
        for arg in spec.args
    )

    def complete_func(self, text, line, begidx, endidx):
        if text.startswith("-"):
            return [f for f in flag_names if f.startswith(text)]

        tokens = line[:begidx].split()
        prev = tokens[-1] if tokens else ""
        prev_spec = next(
            (a for a in spec.args if prev in [n.strip() for n in a.name.split("/")]),
            None,
        )
        if prev_spec and prev_spec.type == "path":
            return _local_completions(text)

        if has_drive_ref:
            if text.startswith("@"):
                return [f"@{self.username}/"] if self.username.startswith(text[1:]) else []
            if _in_drive(self.unified_cwd, self.username):
                return _drive_completions(self, text)
            return _local_completions(text)

        return []

    complete_func.__name__ = f"complete_{spec.name}"

    setattr(cls, func_name, do_func)
    setattr(cls, f"help_{spec.name}", help_func)
    setattr(cls, f"complete_{spec.name}", complete_func)