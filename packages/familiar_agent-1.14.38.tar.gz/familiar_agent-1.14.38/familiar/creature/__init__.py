# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Familiar Creature — Tamagotchi Avatar System

A pixel creature that lives in the CLI, evolving through 3 stages
as the relationship deepens.

Public API:
    load_creature()      — Load saved creature or return None
    save_creature()      — Persist creature state to disk
    run_creature_intro() — First-run creature birth sequence
    CreatureDisplay      — Render creature in retro box frame
"""

from .display import CreatureDisplay
from .intro import CreatureIntroResult, run_creature_intro
from .state import (
    ActivityState,
    CreatureState,
    EvolutionStage,
    load_creature,
    save_creature,
)

__all__ = [
    "CreatureDisplay",
    "CreatureIntroResult",
    "CreatureState",
    "ActivityState",
    "EvolutionStage",
    "load_creature",
    "save_creature",
    "run_creature_intro",
]
