# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
HTML Sprite Renderer

Renders sprite frames as HTML for the web dashboard.
Each pixel becomes a colored span with a block character.
"""

BLOCK = "\u2588"  # █


def render_frame_html(frame: list[str], colors: dict[str, tuple[int, int, int]]) -> str:
    """Render a sprite frame to an HTML string.

    Args:
        frame: List of row strings where each char is a role code.
        colors: Mapping of role codes to (R, G, B) tuples.

    Returns:
        HTML string with colored spans, rows separated by <br>.
    """
    rows = []
    for row in frame:
        parts = []
        for ch in row:
            if ch == ".":
                parts.append(f'<span style="color:transparent">{BLOCK}</span>')
            elif ch in colors:
                r, g, b = colors[ch]
                parts.append(f'<span style="color:rgb({r},{g},{b})">{BLOCK}</span>')
            else:
                parts.append(f'<span style="color:rgb(30,30,30)">{BLOCK}</span>')
        rows.append("".join(parts))
    return "<br>".join(rows)
