# Familiar - Self-Hosted AI Companion Platform
# Copyright (c) 2026 George Scott Foley
# ORCID: 0009-0006-4957-0540
# Email: Georgescottfoley@proton.me
# Licensed under the MIT License - see LICENSE file for details

"""
Sprite Frame Data

Per-species, per-stage, per-animation-state pixel art frames.

Each frame is a list of strings (rows). Each character is a role code:
  . = transparent (space)
  # = outline (dark gray)
  B = body color
  E = eyes color
  A = accent color
  H = highlight (auto-computed lighter body)
  S = shadow (auto-computed darker body)

Structure: SPRITES[species][stage][activity][frame_index] -> list[str]

Phase 1: Fox fully drawn at all 3 stages.
         Other 5 species have baby stage drawn; juvenile/adult fall back to fox.
"""

# ── Fox ──────────────────────────────────────────────────────────────

_FOX_BABY = {
    "idle": [
        [
            "..A..A...",
            ".ABBBBA..",
            "ABEBEBBA.",
            ".ABBHBBA.",
            "..BSBSB..",
            "..BB.BB..",
        ],
        [
            "..A..A...",
            ".ABBBBA..",
            "ABBBBBBA.",
            ".ABBHBBA.",
            "..BSBSB..",
            "..BB.BB..",
        ],
    ],
    "thinking": [
        [
            "..A..A...",
            ".ABBBBA..",
            "ABE.EBBA.",
            ".ABBHBBA.",
            "..BSBSB..",
            "..BB.BB..",
        ],
        [
            "..A..A.H.",
            ".ABBBBA..",
            "ABE.EBBA.",
            ".ABBHBBA.",
            "..BSBSB..",
            "..BB.BB..",
        ],
    ],
    "working": [
        [
            "..A..A...",
            ".ABBBBA..",
            "ABEBEBBA.",
            ".ABBHBBAA",
            "..BSBSB..",
            ".BB..BB..",
        ],
        [
            "..A..A...",
            ".ABBBBA..",
            "ABEBEBBA.",
            "AABBHBBA.",
            "..BSBSB..",
            "..BB..BB.",
        ],
    ],
    "sleeping": [
        [
            ".........",
            "..A..A...",
            ".ABBBBA..",
            ".AB##BBA.",
            ".ABBHBBA.",
            "..BBBBB..",
        ],
    ],
}

_FOX_JUVENILE = {
    "idle": [
        [
            "..A...A...",
            ".ABBBBBA..",
            "ABBEBEBBA.",
            ".ABBBHBBA.",
            "..BBBBBBA.",
            "..BSBBSB..",
            "..BB..BB..",
        ],
        [
            "..A...A...",
            ".ABBBBBA..",
            "ABBBBBBBBA",
            ".ABBBHBBA.",
            "..BBBBBBA.",
            "..BSBBSB..",
            "..BB..BB..",
        ],
    ],
    "thinking": [
        [
            "..A...A...",
            ".ABBBBBA..",
            "ABBE.EBBA.",
            ".ABBBHBBA.",
            "..BBBBBBA.",
            "..BSBBSB..",
            "..BB..BB..",
        ],
        [
            "..A...A.H.",
            ".ABBBBBA..",
            "ABBE.EBBA.",
            ".ABBBHBBA.",
            "..BBBBBBA.",
            "..BSBBSB..",
            "..BB..BB..",
        ],
    ],
    "working": [
        [
            "..A...A...",
            ".ABBBBBA..",
            "ABBEBEBBA.",
            ".ABBBHBBA.",
            "..BBBBBBAA",
            "..BSBBSB..",
            ".BB...BB..",
        ],
        [
            "..A...A...",
            ".ABBBBBA..",
            "ABBEBEBBA.",
            ".ABBBHBBA.",
            "AABBBBBB..",
            "..BSBBSB..",
            "..BB...BB.",
        ],
    ],
    "sleeping": [
        [
            "..........",
            "..A...A...",
            ".ABBBBBA..",
            ".ABB##BBA.",
            ".ABBBHBBA.",
            "..BBBBBBA.",
            "...BBBBB..",
        ],
    ],
}

_FOX_ADULT = {
    "idle": [
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBEBEBBA.",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB...BB..",
        ],
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBBBBBBBA",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB...BB..",
        ],
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBEBEBBA.",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB...BB..",
        ],
    ],
    "thinking": [
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBE..BBA.",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB...BB..",
        ],
        [
            "..A....A.H.",
            ".ABBBBBBA..",
            "ABBBE..BBA.",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB...BB..",
        ],
    ],
    "working": [
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBEBEBBA.",
            ".ABBBBHBBAA",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            ".BB....BB..",
        ],
        [
            "..A....A...",
            ".ABBBBBBA..",
            "ABBBEBEBBA.",
            "AABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBBA.",
            "..BSBBBSB..",
            "..BB....BB.",
        ],
    ],
    "sleeping": [
        [
            "...........",
            "..A....A...",
            ".ABBBBBBA..",
            ".ABBB##BBA.",
            ".ABBBBHBBA.",
            "..BBBBBBBA.",
            "..BBBBBBB..",
            "...........",
        ],
    ],
}

# ── Owl ──────────────────────────────────────────────────────────────

_OWL_BABY = {
    "idle": [
        [
            ".BBBBB.",
            "BEBEBEB",
            "BBBHBBB",
            ".BBABB.",
            ".BSSBB.",
            "..B.B..",
        ],
        [
            ".BBBBB.",
            "BBBBBBB",
            "BBBHBBB",
            ".BBABB.",
            ".BSSBB.",
            "..B.B..",
        ],
    ],
    "thinking": [
        [
            ".BBBBB.",
            "BE.B.EB",
            "BBBHBBB",
            ".BBABB.",
            ".BSSBB.",
            "..B.B..",
        ],
        [
            ".BBBBB.H",
            "BE.B.EB.",
            "BBBHBBB.",
            ".BBABB..",
            ".BSSBB..",
            "..B.B...",
        ],
    ],
    "working": [
        [
            ".BBBBB.",
            "BEBEBEB",
            "BBBHBBB",
            ".BBAABB",
            ".BSSBB.",
            ".BB.B..",
        ],
        [
            ".BBBBB.",
            "BEBEBEB",
            "BBBHBBB",
            "BBABBBA",
            ".BSSBB.",
            "..B.BB.",
        ],
    ],
    "sleeping": [
        [
            ".BBBBB.",
            "B##B##B",
            "BBBHBBB",
            ".BBABB.",
            ".BBBBB.",
            "..B.B..",
        ],
    ],
}

# ── Cat ──────────────────────────────────────────────────────────────

_CAT_BABY = {
    "idle": [
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "BBBHBBB",
            ".BSBSB.",
            ".BB.BB.",
        ],
        [
            ".A...A.",
            "ABBBBBA",
            "BBBBBBB",
            "BBBHBBB",
            ".BSBSB.",
            ".BB.BB.",
        ],
    ],
    "thinking": [
        [
            ".A...A.",
            "ABBBBBA",
            "BE.B.BB",
            "BBBHBBB",
            ".BSBSB.",
            ".BB.BB.",
        ],
        [
            ".A...A.H",
            "ABBBBBA.",
            "BE.B.BB.",
            "BBBHBBB.",
            ".BSBSB..",
            ".BB.BB..",
        ],
    ],
    "working": [
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "BBBHBBBA",
            ".BSBSB.",
            "BB..BB.",
        ],
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "ABBBHBBB",
            ".BSBSB.",
            ".BB..BB",
        ],
    ],
    "sleeping": [
        [
            "........",
            ".A...A..",
            "ABBBBBA.",
            "B##B##B.",
            "BBBHBBB.",
            ".BBBBB..",
        ],
    ],
}

# ── Dragon ───────────────────────────────────────────────────────────

_DRAGON_BABY = {
    "idle": [
        [
            "A.......",
            ".ABBBBA.",
            ".BEBEBBA",
            ".BBBHBB.",
            "..BSSB..",
            "..BB.BB.",
        ],
        [
            "A.......",
            ".ABBBBA.",
            ".BBBBBBA",
            ".BBBHBB.",
            "..BSSB..",
            "..BB.BB.",
        ],
    ],
    "thinking": [
        [
            "A.......",
            ".ABBBBA.",
            ".BE.EBBA",
            ".BBBHBB.",
            "..BSSB..",
            "..BB.BB.",
        ],
        [
            "A.....H.",
            ".ABBBBA.",
            ".BE.EBBA",
            ".BBBHBB.",
            "..BSSB..",
            "..BB.BB.",
        ],
    ],
    "working": [
        [
            "A.......",
            ".ABBBBA.",
            ".BEBEBBA",
            ".BBBHBBA",
            "..BSSB..",
            ".BB..BB.",
        ],
        [
            "A.......",
            ".ABBBBA.",
            ".BEBEBBA",
            "ABBBHBB.",
            "..BSSB..",
            "..BB..BB",
        ],
    ],
    "sleeping": [
        [
            "........",
            "A.......",
            ".ABBBBA.",
            ".B##BBBA",
            ".BBBHBB.",
            "..BBBB..",
        ],
    ],
}

# ── Wolf ─────────────────────────────────────────────────────────────

_WOLF_BABY = {
    "idle": [
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "BBBHBBB",
            ".BSSBB.",
            ".BB.BB.",
        ],
        [
            ".A...A.",
            "ABBBBBA",
            "BBBBBBB",
            "BBBHBBB",
            ".BSSBB.",
            ".BB.BB.",
        ],
    ],
    "thinking": [
        [
            ".A...A.",
            "ABBBBBA",
            "BE..BBB",
            "BBBHBBB",
            ".BSSBB.",
            ".BB.BB.",
        ],
        [
            ".A...A.H",
            "ABBBBBA.",
            "BE..BBB.",
            "BBBHBBB.",
            ".BSSBB..",
            ".BB.BB..",
        ],
    ],
    "working": [
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "BBBHBBBA",
            ".BSSBB.",
            "BB..BB.",
        ],
        [
            ".A...A.",
            "ABBBBBA",
            "BEBEBBB",
            "ABBBHBBB",
            ".BSSBB.",
            ".BB..BB",
        ],
    ],
    "sleeping": [
        [
            "........",
            ".A...A..",
            "ABBBBBA.",
            "B##B##B.",
            "BBBHBBB.",
            ".BBBBB..",
        ],
    ],
}

# ── Frog ─────────────────────────────────────────────────────────────

_FROG_BABY = {
    "idle": [
        [
            ".E...E.",
            "EBBBBEB",
            "BBBBBBB",
            "BAHHHAB",
            ".BSSB..",
            "..B.B..",
        ],
        [
            ".E...E.",
            "EBBBBEB",
            "BBBBBBB",
            "BAHHHAB",
            "..BSSB.",
            "..B.B..",
        ],
    ],
    "thinking": [
        [
            ".E...E.",
            "E.BBB.B",
            "BBBBBBB",
            "BAHHHAB",
            ".BSSB..",
            "..B.B..",
        ],
        [
            ".E...E.H",
            "E.BBB.B.",
            "BBBBBBB.",
            "BAHHHAB.",
            ".BSSB...",
            "..B.B...",
        ],
    ],
    "working": [
        [
            ".E...E.",
            "EBBBBEB",
            "BBBBBBB",
            "BAHHHAB",
            ".BSSB..",
            ".BB.B..",
        ],
        [
            ".E...E.",
            "EBBBBEB",
            "BBBBBBB",
            "BAHHHAB",
            "..BSSB.",
            "..B.BB.",
        ],
    ],
    "sleeping": [
        [
            "........",
            ".#...#..",
            "#BBBB#B.",
            "BBBBBBB.",
            "BAHHHAB.",
            ".BBBBB..",
        ],
    ],
}

# ── Egg (for intro sequence) ────────────────────────────────────────

EGG_FRAMES = [
    [
        "..###..",
        ".#BBB#.",
        "#BBBBB#",
        "#BBHBB#",
        "#BBBBB#",
        ".#BBB#.",
        "..###..",
    ],
    [
        "..###..",
        ".#BBB#.",
        "#BBHBB#",
        "#BBBBB#",
        "#BBHBB#",
        ".#BBB#.",
        "..###..",
    ],
]

# ── Master sprite dictionary ────────────────────────────────────────

SPRITES: dict[str, dict[str, dict[str, list[list[str]]]]] = {
    "fox": {
        "baby": _FOX_BABY,
        "juvenile": _FOX_JUVENILE,
        "adult": _FOX_ADULT,
    },
    "owl": {
        "baby": _OWL_BABY,
        "juvenile": _FOX_JUVENILE,  # placeholder
        "adult": _FOX_ADULT,  # placeholder
    },
    "cat": {
        "baby": _CAT_BABY,
        "juvenile": _FOX_JUVENILE,  # placeholder
        "adult": _FOX_ADULT,  # placeholder
    },
    "dragon": {
        "baby": _DRAGON_BABY,
        "juvenile": _FOX_JUVENILE,  # placeholder
        "adult": _FOX_ADULT,  # placeholder
    },
    "wolf": {
        "baby": _WOLF_BABY,
        "juvenile": _FOX_JUVENILE,  # placeholder
        "adult": _FOX_ADULT,  # placeholder
    },
    "frog": {
        "baby": _FROG_BABY,
        "juvenile": _FOX_JUVENILE,  # placeholder
        "adult": _FOX_ADULT,  # placeholder
    },
}


def get_sprite_frames(species: str, stage: str, activity: str) -> list[list[str]]:
    """Get sprite frames for a species/stage/activity combination.

    Falls back gracefully: unknown species -> fox, unknown stage -> baby,
    unknown activity -> idle.
    """
    sp = SPRITES.get(species, SPRITES["fox"])
    st = sp.get(stage, sp.get("baby", {}))
    frames = st.get(activity, st.get("idle", []))
    return frames if frames else SPRITES["fox"]["baby"]["idle"]
