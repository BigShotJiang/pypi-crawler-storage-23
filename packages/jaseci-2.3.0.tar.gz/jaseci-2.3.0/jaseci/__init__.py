# Jaseci v2.0 Meta-package
# This package installs the complete Jaseci ecosystem
__version__ = "2.0.0"
