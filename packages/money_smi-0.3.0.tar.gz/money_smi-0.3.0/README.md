# 💰 money-smi

**v0.1.0 "Protocol: MIDAS"**

**"Every second your GPU is idle, you are losing money."**

`money-smi` (formerly GPUWatch) is a cyberpunk-themed universal dashboard that tracks the **Opportunity Cost** of your idle Local GPUs and Cloud Instances.

![Demo](https://via.placeholder.com/800x400?text=money-smi+Dashboard)

## 📦 Installation

```bash
pip install money-smi
```

## 🚀 Usage

Run the tool with default settings ($2.00 daily profit potential):

```bash
money-smi --auto
```

### Options

Customize your potential earnings:

```bash
# earning $3.50 per day
money-smi --daily-profit 3.50

# using Yen (¥)
gpuwatch --currency "¥" --daily-profit 500

# reset lifetime statistics
gpuwatch --reset
```

## 🧠 Philosophy

Humans are loss-averse. We don't care about saving 5 cents of electricity.
But we **hate** missing out on $5.00 of free money.
This tool weaponizes that psychology to make you efficiently use your hardware.

## 🌍 Universal Monitor (v0.3.0) - NEW!

**"One Dashboard to Rule Them All."**

GPUWatch now automatically detects and monitors your **Local GPUs** (NVIDIA) and **Cloud Instances** (AWS EC2) simultaneously.

### ✨ Key Features
1.  **Auto-Detect (`--auto`):** Zero-config. It finds your GPU. It finds your AWS credentials. It just works.
2.  **Market Intelligence:** Real-time opportunity cost estimation based on live **Vast.ai / NiceHash rental rates** (e.g., ~$0.45/h for RTX 4090).
3.  **Guardian Mode:** 
    *   **Slack Alerts:** Get notified when money is burning.
    *   **Auto-Kill:** Automatically terminate cloud instances after set idle time (e.g., 30 mins).
4.  **True Metrics:** Distinguishes between **Cash Burn** (Cloud) and **Missed Opportunity** (Local).

## 🚀 Usage

### 1. The "Magic" Command (Recommended)
Automatically scans everything.
```bash
gpuwatch --auto
```

### 2. Guardian Mode (Set & Forget)
Monitor for waste, alert on Slack, and kill instances if idle for 30 minutes.
```bash
gpuwatch --auto --guardian --slack-webhook "https://hooks.slack.com/..." --allow-kill --idle-timeout 1800
```
*(Requires `requests` library)*

### 3. Manual Mode
Legacy manual controls are still available.
```bash
# Local only (custom daily profit target)
gpuwatch --daily-profit 5.0

# Cloud only (AWS Tokyo)
gpuwatch --cloud aws --region ap-northeast-1
```

## ☁️ Cloud Setup
Just have your standard AWS credentials ready (`~/.aws/credentials` or `AWS_ACCESS_KEY_ID`).
*   **Accuracy:** If CloudWatch Agent is installed, we use accurate **GPU Utilization**. Otherwise, we fall back to **CPU Utilization** as a proxy.


## License
MIT
