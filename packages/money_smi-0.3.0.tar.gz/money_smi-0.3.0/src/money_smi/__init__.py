__app_name__ = "money-smi"
__version__ = "0.3.0"
