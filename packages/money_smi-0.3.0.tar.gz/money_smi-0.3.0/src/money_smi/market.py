import random
import time

class MarketOracle:
    """
    Simulated Market Feed (Vast.ai / NiceHash proxy).
    Returns real-time fluctuating rates for GPU models.
    """
    
    # Base rates ($/h) based on 2026 market data (approx)
    BASE_RATES = {
        "RTX 4090": 0.45,
        "RTX 3090": 0.35,
        "RTX 3080": 0.22,
        "A100": 1.50,
        "H100": 3.80,
        "L40S": 1.20,
        "T4": 0.15,
        "V100": 0.80,
        "P100": 0.30,
        "M60": 0.10,
        # Default for unknown
        "DEFAULT": 0.20
    }

    def __init__(self):
        self._last_update = 0
        self._cache = {}

    def get_market_rate(self, gpu_name):
        """Returns live market rate ($/h) for the given GPU model."""
        now = time.time()
        
        # Simple cache to avoid jittering too fast
        if now - self._last_update < 5.0 and gpu_name in self._cache:
            return self._cache[gpu_name]

        # Find base rate
        base = self.BASE_RATES["DEFAULT"]
        for key, rate in self.BASE_RATES.items():
            if key in gpu_name:
                base = rate
                break
        
        # Market Fluctuation logic (Removed for Accuracy on user request)
        # Random +/- 0% jitter representing real-time demand
        fluctuation = 1.0 # Fixed for now
        current_rate = base * fluctuation
        
        self._cache[gpu_name] = current_rate
        self._last_update = now
        
        return current_rate
