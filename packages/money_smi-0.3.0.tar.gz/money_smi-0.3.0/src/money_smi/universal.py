import logging
import os
import boto3

# Local Imports
try:
    from .local_monitor import LocalMonitor
except ImportError:
    LocalMonitor = None
try:
    from .cloud_aws import AWSMonitor
except ImportError:
    AWSMonitor = None

class UniversalMonitor:
    def __init__(self, args):
        self.monitors = []
        self.args = args
        self.data_cache = []

        if self.args.auto or self.args.cloud == 'both':
            self.auto_detect()
        else:
            # Manual Selection
            if self.args.cloud == 'local':
                self._add_local()
            elif self.args.cloud == 'aws':
                self._add_aws()
            elif self.args.cloud == 'both':
                self._add_local()
                self._add_aws()

    def _add_local(self):
        if LocalMonitor:
            m = LocalMonitor(daily_profit=self.args.daily_profit)
            if m.available:
                self.monitors.append(m)
                logging.info("UniversalMonitor: Added LocalMonitor")

    def _add_aws(self):
        if AWSMonitor:
            # Check creds OR assume user wants to configure?
            # For Universal Mode, be permissive? Or strict?
            # Let's verify creds first.
            try:
                boto3.setup_default_session(region_name=self.args.region)
                sts = boto3.client('sts')
                if sts.get_caller_identity():
                    m = AWSMonitor(region_name=self.args.region)
                    self.monitors.append(m)
                    logging.info("UniversalMonitor: Added AWSMonitor")
            except Exception as e:
                logging.warning(f"AWSMonitor skipped (No creds/Error): {e}")

    def auto_detect(self):
        """Intelligently enable monitors based on environment."""
        logging.info("Starting Auto-Detect...")
        
        # 1. Local GPU Check
        # Try init LocalMonitor. If works, keep it.
        self._add_local()

        # 2. AWS Check
        # Check env vars or ~/.aws/credentials via boto3
        # If successfully can list instances or check identity, add it.
        if os.environ.get("AWS_ACCESS_KEY_ID") or os.path.exists(os.path.expanduser("~/.aws/credentials")):
            self._add_aws()
        
        # 3. GCP Check (Placeholder for v0.3.1)
        # if os.environ.get("GOOGLE_APPLICATION_CREDENTIALS"): ...

    def get_status_data(self):
        """
        Aggregates data from all active monitors.
        Returns unified list of dicts.
        Structure:
        {
            "id": "unique-id",
            "name": "Display Name",
            "utilization": float (0-100),
            "metric_1": str (Temp/Price),
            "metric_2": str (Power/Status),
            "cost_rate": float ($/h),
            "type": "LOC" | "AWS" | "GCP"
        }
        """
        aggregated_data = []
        
        for m in self.monitors:
            try:
                # AWSMonitor has .get_cloud_data() -> need adapt?
                if hasattr(m, 'get_cloud_data'):
                    raw = m.get_cloud_data()
                    for r in raw:
                        aggregated_data.append({
                            "id": r["id"],
                            "name": f"{r['id']} ({r['type']})",
                            "utilization": r["utilization"],
                            "metric_1": f"${r['price']}/h",
                            "metric_2": "Running",
                            "cost_rate": r["price"],
                            "type": "AWS"
                        })
                elif hasattr(m, 'get_data'):
                    # LocalMonitor already returns mostly correct format
                    raw = m.get_data()
                    aggregated_data.extend(raw) # Assuming LocalMonitor conforms
            except Exception as e:
                logging.error(f"Monitor Error: {e}")

        # Fallback Mock if absolutely nothing found in Auto Mode
        if not aggregated_data and (self.args.auto or not self.monitors):
            import random
            aggregated_data.append({
                "id": "mock-gpu",
                "name": "[MOCK] GPU (Demo Mode)",
                "utilization": random.randint(0, 50),
                "metric_1": "60°C",
                "metric_2": "100W",
                "cost_rate": 0.0,
                "type": "LOC"
            })
            
        return aggregated_data
