import json
import os
import sys
import time
import logging
from datetime import datetime
from pathlib import Path
from types import SimpleNamespace
from typing import Optional

import typer
from rich.live import Live
from rich.layout import Layout
from rich.panel import Panel
from rich.text import Text
from rich.table import Table
from rich.console import Console
from rich import box

# Local imports
try:
    from . import __app_name__, __version__
except ImportError:
    __app_name__ = "money-smi"
    __version__ = "0.3.0"

try:
    from .universal import UniversalMonitor
except ImportError:
    UniversalMonitor = None
try:
    from .market import MarketOracle
except ImportError:
    MarketOracle = None
try:
    from .guardian import Guardian
except ImportError:
    Guardian = None


# Constants
DEFAULT_DAILY_PROFIT = 2.0  # USD
DEFAULT_CURRENCY = "$"
IDLE_THRESHOLD = 20  # Usage %
GPU_POLL_INTERVAL = 1.0
UI_REFRESH_RATE = 10
DATA_FILE = Path.home() / ".money_smi_data.json"

# Logging setup
logging.basicConfig(filename='money_smi_debug.log', level=logging.ERROR, 
                    format='%(asctime)s - %(levelname)s - %(message)s')

class DataManager:
    """Handles persistence of wasted/missed revenue."""
    def __init__(self, filepath=DATA_FILE):
        self.filepath = filepath
        self.data = self._load()

    def _load(self):
        if not self.filepath.exists():
            return {"total_missed_revenue": 0.0, "total_idle_time": 0.0}
        try:
            with open(self.filepath, "r") as f:
                return json.load(f)
        except Exception:
            return {"total_missed_revenue": 0.0, "total_idle_time": 0.0}

    def save(self):
        try:
            with open(self.filepath, "w") as f:
                json.dump(self.data, f)
        except Exception as e:
            logging.error(f"Failed to save data: {e}")

    def add_revenue(self, amount, time_delta):
        self.data["total_missed_revenue"] += amount
        self.data["total_idle_time"] += time_delta

class GPUWatchApp:
    def __init__(self, monitor, args):
        self.console = Console()
        self.layout = Layout()
        self.monitor = monitor
        self.args = args
        self.data_manager = DataManager()
        
        # New Engines
        self.market = MarketOracle() if MarketOracle else None
        self.guardian = None
        if Guardian and (args.guardian or args.slack_webhook):
            self.guardian = Guardian(
                slack_webhook=args.slack_webhook,
                allow_kill=args.allow_kill,
                idle_timeout=args.idle_timeout
            )
        
        self.last_update_time = time.time()
        self.last_poll = 0.0
        self.cached_data = []
        self.session_revenue = 0.0
        self.current_idle_duration = 0.0
        
        self._setup_layout()

    def _setup_layout(self):
        self.layout.split_column(
            Layout(name="header", size=3),
            Layout(name="main", ratio=1),
            Layout(name="footer", size=8)
        )

    def generate_header(self) -> Panel:
        grid = Table.grid(expand=True)
        grid.add_column(justify="left", ratio=1)
        grid.add_column(justify="right")
        
        mode = "UNIVERSAL" if self.args.auto else f"MODE: {self.args.cloud.upper()}"
        if self.guardian:
            mode += " [GUARDIAN ACTIVE]"
            
        title = Text(f"🔥 {__app_name__} v{__version__} [MIDAS] [{mode}]", style="bold gold1")
        
        t_str = datetime.now().strftime("%H:%M:%S.%f")[:-3]
        meta = Text(f"TIME: {t_str}", style="bold white on blue")
        grid.add_row(title, meta)
        return Panel(grid, style="cyan", box=box.HEAVY_EDGE)

    def generate_main_area(self, data) -> Panel:
        table = Table(box=box.SIMPLE, expand=True, show_header=True, header_style="bold magenta")
        table.add_column("Resource", style="white")
        table.add_column("Utilization", width=20)
        table.add_column("Details", justify="right", style="bold yellow")
        table.add_column("Status", justify="right", style="bold green")

        for d in data:
            util = d["utilization"]
            color = "red" if util < self.args.threshold else "green"
            bar_len = int(15 * util / 100)
            bar = "█" * bar_len + "░" * (15 - bar_len)
            
            # Unified metrics
            metric_1 = d.get("metric_1", "-")
            metric_2 = d.get("metric_2", "-")
            
            # If we have specific source info (Cloud Mode)
            if "metric_source" in d:
                # e.g. "ESTIMATED (CPU)" or "ACCURATE (GPU)"
                source = d["metric_source"]
                style = "bold yellow" if "ESTIMATED" in source else "bold green"
                metric_2 = Text(source, style=style)

            # Enhancing 'Status' with Market Rate if available and relevant
            if self.market and d.get("type") == "LOC":
                rate = self.market.get_market_rate(d["name"])
                metric_2 = f"Market: ${rate:.2f}/h"
                # Update cost_rate in data for correct calculation
                d["cost_rate"] = rate

            table.add_row(
                d["name"],
                Text(f"{bar} {util:.1f}%", style=color),
                metric_1,
                metric_2
            )
        return Panel(table, title="[bold green]System Status[/]", border_style="green", box=box.ROUNDED)

    def generate_footer(self, data) -> Panel:
        now = time.time()
        dt = now - self.last_update_time
        self.last_update_time = now
        if dt > 2.0: dt = 0.0 

        is_idle = False
        current_burn_rate = 0.0 # $/h

        # Unified Logic: Sum up cost_rate ($/h) involved in idle resources
        cloud_burn = 0.0
        opportunity_missed = 0.0

        for d in data:
            if d["utilization"] < self.args.threshold:
                is_idle = True
                rate = d.get('cost_rate', 0.0)
                current_burn_rate += rate
                
                if d.get("type") == "LOC":
                    opportunity_missed += rate
                else:
                    cloud_burn += rate
                
                # Guardian Check
                if self.guardian:
                    self.current_idle_duration += dt
                    self.guardian.check_and_act(d, self.current_idle_duration, self.data_manager.data["total_missed_revenue"])

        if not is_idle:
            self.current_idle_duration = 0.0

        # Calculate Missed Revenue / Wasted Spend
        missed = 0.0
        if is_idle:
            # hourly rate / 3600 * seconds
            missed = (current_burn_rate / 3600.0) * dt
            self.session_revenue += missed
            self.data_manager.add_revenue(missed, dt)

        # Total
        total = self.data_manager.data["total_missed_revenue"]
        c = self.args.currency
        money_str = f"{c}{total:,.6f}"
        
        grid = Table.grid(expand=True)
        grid.add_column(justify="center")
        
        label = "💀 UNIVERSAL WASTED COST"
        grid.add_row(Text(label, style="bold white underline"))
        grid.add_row(Text(""))
        
        # Red Flash logic (Pro Feature)
        style = "bold red reverse"
        if total > 10.0 and int(now * 2) % 2 == 0: # Flash logic
             style = "bold white on red"
             
        grid.add_row(Text(money_str, style=style, justify="center"))
        grid.add_row(Text(""))
        
        # Detailed Breakdown
        if is_idle:
            if cloud_burn > 0:
                grid.add_row(Text(f"💸 CASH BURN: {c}{cloud_burn:.2f}/h", style="bold red"))
            if opportunity_missed > 0:
                grid.add_row(Text(f"📉 MISSED OPP: {c}{opportunity_missed:.2f}/h", style="bold yellow"))
            grid.add_row(Text(""))

        status = f"⚠ BURNING {c}{current_burn_rate:.2f}/h" if is_idle else "✔ OPTIMIZED"
        status_style = "bold red blink" if is_idle else "bold green"
        if not is_idle:
             grid.add_row(Text(status, style=status_style))
        
        session_str = f"Session Waste: {c}{self.session_revenue:.4f}"
        grid.add_row(Text(session_str, style="dim white"))

        return Panel(grid, title="[bold red]Financial Impact[/]", border_style="red", box=box.DOUBLE_EDGE)

    def run(self):
        with Live(self.layout, refresh_per_second=UI_REFRESH_RATE, screen=True) as live:
            last_save = time.time()
            while True:
                now = time.time()
                
                # Poll Data
                if now - self.last_poll >= GPU_POLL_INTERVAL:
                    if self.monitor:
                        self.cached_data = self.monitor.get_status_data()
                    else:
                        self.cached_data = [] 
                    self.last_poll = now
                
                # UI Update
                self.layout["header"].update(self.generate_header())
                self.layout["main"].update(self.generate_main_area(self.cached_data))
                self.layout["footer"].update(self.generate_footer(self.cached_data))
                
                # Auto-save
                if now - last_save > 5.0:
                    self.data_manager.save()
                    last_save = now
                
                time.sleep(1.0 / UI_REFRESH_RATE)

# Typer Application
app = typer.Typer()

def version_callback(value: bool):
    if value:
        typer.echo(f"{__app_name__} v{__version__}")
        raise typer.Exit()

@app.command()
def main(
    daily_profit: float = typer.Option(2.0, help="Estimated daily profit (Local mode)"),
    currency: str = typer.Option("$", help="Currency symbol"),
    threshold: int = typer.Option(10, help="Idle threshold %"),
    cloud: str = typer.Option("local", help="Monitor mode: local, aws, or both"),
    auto: bool = typer.Option(False, "--auto", help="Auto-detect all available resources"),
    region: str = typer.Option("us-east-1", help="AWS Region"),
    reset: bool = typer.Option(False, "--reset", help="Reset lifetime data"),
    guardian: bool = typer.Option(False, "--guardian", help="Enable Guardian Mode (Alerts)"),
    slack_webhook: Optional[str] = typer.Option(None, help="Slack Webhook URL for alerts"),
    allow_kill: bool = typer.Option(False, "--allow-kill", help="Allow Guardian to KILL instances (Dangerous)"),
    idle_timeout: int = typer.Option(1800, help="Seconds before Guardian acts"),
    version: Optional[bool] = typer.Option(
        None, "--version", "-v", help="Show the application version and exit.", callback=version_callback, is_eager=True
    ),
):
    """
    Universal GPU Opportunity Cost Tracker [Protocol: MIDAS]
    """
    
    # Compatibility with existing classes
    # We construct an object similar to argparse Namespace
    args = SimpleNamespace(
        daily_profit=daily_profit,
        currency=currency,
        threshold=threshold,
        cloud=cloud,
        auto=auto,
        region=region,
        reset=reset,
        guardian=guardian,
        slack_webhook=slack_webhook,
        allow_kill=allow_kill,
        idle_timeout=idle_timeout
    )

    if args.reset:
        if os.path.exists(DATA_FILE):
            os.remove(DATA_FILE)
            print("Reset complete.")
        return

    # Initialize Universal Monitor
    if UniversalMonitor is None:
        print("Error: Could not import UniversalMonitor.")
        return

    try:
        monitor = UniversalMonitor(args)
        app_instance = GPUWatchApp(monitor, args)
        app_instance.run()
    except KeyboardInterrupt:
        pass
    except Exception as e:
        logging.critical(f"Crash: {e}")
        # Only print generic error to avoid breaking rich layout if it crashed mid-stream, 
        # but here we are outside Live context usually (or weirdly inside).
        print(f"Error: {e}")
    finally:
        if 'app_instance' in locals():
            app_instance.data_manager.save()

# Entry point for setuptools
def start():
    app()

if __name__ == "__main__":
    start()
