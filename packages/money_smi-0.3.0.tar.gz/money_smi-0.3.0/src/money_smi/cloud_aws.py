import logging
from datetime import datetime, timedelta
# Third-party imports
try:
    import boto3
    BOTO3_AVAILABLE = True
except ImportError:
    BOTO3_AVAILABLE = False

# Simplified Pricing Dict (Region: us-east-1 / ap-northeast-1 avg)
# Focusing on GPU instances + common ones
PRICING = {
    # GPU Instances (Expensive!)
    "p4d.24xlarge": 32.77,
    "p3.16xlarge": 24.48,
    "p3.8xlarge": 12.24,
    "p3.2xlarge": 3.06,
    "p2.16xlarge": 14.4,
    "p2.8xlarge": 7.2,
    "p2.xlarge": 0.9,
    "g5.48xlarge": 16.288,
    "g5.24xlarge": 8.144,
    "g5.12xlarge": 4.072,
    "g5.xlarge": 1.006,
    "g4dn.12xlarge": 3.912,
    "g4dn.xlarge": 0.526,
    # CPU Instances (Commonly wasted)
    "m5.24xlarge": 4.608,
    "m5.large": 0.096,
    "c5.24xlarge": 4.08,
    "c5.large": 0.085,
    "t3.micro": 0.0104, # For testing
}

class AWSMonitor:
    def __init__(self, region_name=None):
        self.available = BOTO3_AVAILABLE
        self.region = region_name
        self.ec2 = None
        self.cloudwatch = None
        self.setup_failed = False
        
        if self.available:
            try:
                self.session = boto3.Session(region_name=region_name)
                self.ec2 = self.session.resource('ec2')
                self.cloudwatch = self.session.client('cloudwatch')
                # Verify credentials
                self.session.client('sts').get_caller_identity()
            except Exception as e:
                logging.error(f"AWS Init Failed: {e}")
                self.setup_failed = True
                self.available = False

    def get_cloud_data(self):
        """
        Scans all running EC2 instances.
        Returns list of dicts with instance info and idle status.
        """
        if not self.available or self.setup_failed:
            # Return Mock Data if setup failed or no creds
            return self._get_mock_data()

        instances_data = []
        try:
            # Filter only running instances
            instances = self.ec2.instances.filter(
                Filters=[{'Name': 'instance-state-name', 'Values': ['running']}]
            )
            
            for instance in instances:
                # Get CPU Utilization (Avg over last 10 mins)
                # Try to get real GPU metrics (requires CloudWatch Agent)
                metric_source = "ESTIMATED (CPU)"
                util = 0.0
                
                try:
                    # 1. Try CWAgent GPUUtilization
                    # Note: Dimensions often include ImageId, InstanceId, InstanceType. 
                    # Simpler to just filter by InstanceId if possible, but CWAgent is picky.
                    # We try a broad search or specific known dimension combo if user installed standard agent.
                    # Standard CWAgent for GPU usually has dim: {InstanceId: ...}
                    stats = self.cloudwatch.get_metric_statistics(
                        Namespace='CWAgent',
                        MetricName='nvidia_smi_utilization_gpu', # Standard metric name for Linux
                        Dimensions=[{'Name': 'InstanceId', 'Value': instance.id}],
                        Period=600,
                        Statistics=['Average'],
                        StartTime=datetime.utcnow() - timedelta(minutes=10),
                        EndTime=datetime.utcnow()
                    )
                    if stats['Datapoints']:
                        util = stats['Datapoints'][0]['Average']
                        metric_source = "ACCURATE (GPU)"
                    else:
                        raise ValueError("No GPU data")
                        
                except Exception:
                    # 2. Fallback to CPU
                    try:
                        stats = self.cloudwatch.get_metric_statistics(
                            Namespace='AWS/EC2',
                            MetricName='CPUUtilization',
                            Dimensions=[{'Name': 'InstanceId', 'Value': instance.id}],
                            Period=600,
                            Statistics=['Average'],
                            StartTime=datetime.utcnow() - timedelta(minutes=10),
                            EndTime=datetime.utcnow()
                        )
                        util = stats['Datapoints'][0]['Average'] if stats['Datapoints'] else 0.0
                        metric_source = "ESTIMATED (CPU)"
                    except Exception:
                        util = 0.0

                price = PRICING.get(instance.instance_type, 0.0)
                
                # Heuristic: If unknown type, assume min $0.1
                if price == 0.0 and instance.instance_type.startswith(('p', 'g')):
                    price = 1.0 # Unknown GPU instance
                
                instances_data.append({
                    "id": instance.id,
                    "type": instance.instance_type,
                    "utilization": util,
                    "price": price,
                    "status": "running",
                    "metric_source": metric_source
                })

        except Exception as e:
            logging.error(f"AWS Scan Failed: {e}")
            return self._get_mock_data()

        return instances_data

    def _get_mock_data(self):
        import random
        return [
            {
                "id": "i-0a1b2c3d4e5f6g7h8",
                "type": "[MOCK] p3.2xlarge",
                "utilization": random.uniform(0.1, 15.0), # Often idle
                "price": 3.06,
                "status": "running"
            },
            {
                "id": "i-9z8y7x6w5v4u3t2s1",
                "type": "[MOCK] g4dn.xlarge",
                "utilization": random.uniform(40.0, 90.0), # Busy
                "price": 0.526,
                "status": "running"
            }
        ]
