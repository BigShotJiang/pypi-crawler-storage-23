import logging
# Try importing pynvml
try:
    import pynvml
    PYNVML_IMPORTED = True
except ImportError:
    PYNVML_IMPORTED = False

class LocalMonitor:
    def __init__(self, daily_profit=2.0):
        self.available = False
        self.device_count = 0
        self.daily_profit = daily_profit
        # Initialize immediately if possible, or lazy load?
        # Let's try init here
        if PYNVML_IMPORTED:
            try:
                pynvml.nvmlInit()
                self.device_count = pynvml.nvmlDeviceGetCount()
                self.available = True
            except Exception as e:
                logging.error(f"NVML Init Failed: {e}")
                self.available = False

    def __del__(self):
        if self.available and PYNVML_IMPORTED:
            try:
                pynvml.nvmlShutdown()
            except Exception:
                pass

    def get_data(self):
        data = []
        if self.available:
            try:
                for i in range(self.device_count):
                    try:
                        handle = pynvml.nvmlDeviceGetHandleByIndex(i)
                        name = pynvml.nvmlDeviceGetName(handle)
                        if isinstance(name, bytes): name = name.decode("utf-8")
                        
                        try: util = pynvml.nvmlDeviceGetUtilizationRates(handle).gpu
                        except: util = 0
                        
                        try: temp = pynvml.nvmlDeviceGetTemperature(handle, pynvml.NVML_TEMPERATURE_GPU)
                        except: temp = 0

                        try: power = pynvml.nvmlDeviceGetPowerUsage(handle) / 1000.0
                        except: power = 0.0

                        # Calculate cost rate (daily_profit / 24)
                        # Local doesn't have "hourly rate" in the same way, but we can normalize it.
                        # For consistency with Universal Dashboard, cost_rate should be $/h.
                        cost_rate = self.daily_profit / 24.0

                        data.append({
                            "id": f"gpu-{i}",
                            "name": name, 
                            "utilization": util, 
                            "metric_1": f"{temp}°C", 
                            "metric_2": f"{power:.1f} W",
                            "cost_rate": cost_rate,
                            "type": "LOC"
                        })
                    except: continue
            except: pass
        
        # Mock data if unavailable but expected?
        # The Universal Monitor should handle mock if NO monitors are available.
        # But for now, let's return empty if not available.
        return data
