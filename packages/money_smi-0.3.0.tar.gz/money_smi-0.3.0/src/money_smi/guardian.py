import logging
import json
import time
import requests

class Guardian:
    """
    Guardian Mode: Active Intervention System.
    - Alerts on Slack/Discord when idle duration > limit.
    - Auto-Kills instances if --allow-kill is set.
    """
    def __init__(self, slack_webhook=None, allow_kill=False, idle_timeout=1800):
        self.slack_webhook = slack_webhook
        self.allow_kill = allow_kill
        self.idle_timeout = idle_timeout # seconds (default 30m)
        self.active_alerts = {} # {id: timestamp}

    def check_and_act(self, data, current_idle_duration, total_missed):
        """
        Checks if intervention is needed.
        """
        if current_idle_duration > self.idle_timeout:
            self._trigger_alert(data, current_idle_duration, total_missed)
            
            if self.allow_kill:
                self._kill_instance(data)

    def _trigger_alert(self, data, duration, total_missed):
        """Sends alert via Webhook."""
        msg = {
            "text": f"🚨 **GUARDIAN ALERT** 🚨\n"
                    f"Idle Duration: {duration/60:.1f} min\n"
                    f"Wasted Cost: ${total_missed:.2f}\n"
                    f"Instance: {data['name']} (Utilization: {data['utilization']}%)"
        }
        
        # Debounce alerts (don't spam every second)
        last_alert = self.active_alerts.get(data['id'], 0)
        if time.time() - last_alert < 300: # 5 min debounce
            return

        print(f"\n[GUARDIAN] ALERT SENT: {msg['text']}")
        self.active_alerts[data['id']] = time.time()

        if self.slack_webhook:
            try:
                requests.post(self.slack_webhook, json=msg)
            except Exception as e:
                logging.error(f"Guardian Alert Failed: {e}")

    def _kill_instance(self, data):
        """Auto-Kill logic (Stub for safety, requires AWS SDK integration)"""
        print(f"\n[GUARDIAN] 💀 KILLING INSTANCE {data['id']} (Simulated)")
        # In v0.3.1, integrate boto3.stop_instances here.
