"""Tests for the MCP server tools."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest
from pydantic import BaseModel

from football_api_mcp.server import (
    _serialize,
    get_competition_matches,
    get_matches,
    get_person,
    get_scorers,
    get_standings,
    get_team,
    get_team_matches,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class _FakeModel(BaseModel):
    name: str
    value: int


def _make_mock_client(**method_returns: object) -> MagicMock:
    """Create a mock FootballClient with given return values."""
    client = MagicMock()
    client.__enter__ = MagicMock(return_value=client)
    client.__exit__ = MagicMock(return_value=False)
    for method_name, return_value in method_returns.items():
        getattr(client, method_name).return_value = return_value
    return client


# ---------------------------------------------------------------------------
# _serialize
# ---------------------------------------------------------------------------


class TestSerialize:
    def test_pydantic_model(self):
        model = _FakeModel(name="test", value=42)
        result = _serialize(model)
        assert result == {"name": "test", "value": 42}

    def test_plain_dict(self):
        d = {"key": "val"}
        assert _serialize(d) is d

    def test_plain_string(self):
        assert _serialize("hello") == "hello"


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


class TestGetStandings:
    @patch("football_api_mcp.server._get_client")
    def test_basic_call(self, mock_get_client):
        fake = _FakeModel(name="standings", value=1)
        client = _make_mock_client(get_standings=fake)
        mock_get_client.return_value = client

        result = get_standings("PL")

        client.get_standings.assert_called_once_with("PL", season=None, matchday=None)
        assert result == {"name": "standings", "value": 1}

    @patch("football_api_mcp.server._get_client")
    def test_with_season_and_matchday(self, mock_get_client):
        fake = _FakeModel(name="standings", value=2)
        client = _make_mock_client(get_standings=fake)
        mock_get_client.return_value = client

        result = get_standings("BL1", season=2024, matchday=10)

        client.get_standings.assert_called_once_with("BL1", season=2024, matchday=10)
        assert result == {"name": "standings", "value": 2}


class TestGetMatches:
    @patch("football_api_mcp.server._get_client")
    def test_no_params(self, mock_get_client):
        fake = _FakeModel(name="matches", value=5)
        client = _make_mock_client(get_matches=fake)
        mock_get_client.return_value = client

        result = get_matches()

        client.get_matches.assert_called_once_with(
            date_from=None, date_to=None, status=None, competitions=None
        )
        assert result == {"name": "matches", "value": 5}

    @patch("football_api_mcp.server._get_client")
    def test_with_filters(self, mock_get_client):
        fake = _FakeModel(name="matches", value=3)
        client = _make_mock_client(get_matches=fake)
        mock_get_client.return_value = client

        get_matches(
            date_from="2024-01-01", date_to="2024-01-31", status="FINISHED", competitions="PL,SA"
        )

        client.get_matches.assert_called_once_with(
            date_from="2024-01-01",
            date_to="2024-01-31",
            status="FINISHED",
            competitions="PL,SA",
        )


class TestGetCompetitionMatches:
    @patch("football_api_mcp.server._get_client")
    def test_basic_call(self, mock_get_client):
        fake = _FakeModel(name="comp_matches", value=10)
        client = _make_mock_client(get_competition_matches=fake)
        mock_get_client.return_value = client

        result = get_competition_matches("PL", matchday=5)

        client.get_competition_matches.assert_called_once_with(
            "PL", matchday=5, season=None, status=None, date_from=None, date_to=None
        )
        assert result == {"name": "comp_matches", "value": 10}


class TestGetTeam:
    @patch("football_api_mcp.server._get_client")
    def test_basic_call(self, mock_get_client):
        fake = _FakeModel(name="Arsenal", value=57)
        client = _make_mock_client(get_team=fake)
        mock_get_client.return_value = client

        result = get_team(57)

        client.get_team.assert_called_once_with(57)
        assert result == {"name": "Arsenal", "value": 57}


class TestGetTeamMatches:
    @patch("football_api_mcp.server._get_client")
    def test_basic_call(self, mock_get_client):
        fake = _FakeModel(name="team_matches", value=20)
        client = _make_mock_client(get_team_matches=fake)
        mock_get_client.return_value = client

        get_team_matches(57)

        client.get_team_matches.assert_called_once_with(
            57, season=None, status=None, venue=None,
            date_from=None, date_to=None, limit=None,
        )

    @patch("football_api_mcp.server._get_client")
    def test_with_all_params(self, mock_get_client):
        fake = _FakeModel(name="team_matches", value=3)
        client = _make_mock_client(get_team_matches=fake)
        mock_get_client.return_value = client

        get_team_matches(
            57, season=2024, status="FINISHED", venue="HOME",
            date_from="2024-01-01", date_to="2024-06-30", limit=5,
        )

        client.get_team_matches.assert_called_once_with(
            57, season=2024, status="FINISHED", venue="HOME",
            date_from="2024-01-01", date_to="2024-06-30", limit=5,
        )


class TestGetScorers:
    @patch("football_api_mcp.server._get_client")
    def test_basic_call(self, mock_get_client):
        fake = _FakeModel(name="scorers", value=15)
        client = _make_mock_client(get_scorers=fake)
        mock_get_client.return_value = client

        result = get_scorers("PL")

        client.get_scorers.assert_called_once_with(
            "PL", season=None, matchday=None, limit=None
        )
        assert result == {"name": "scorers", "value": 15}


class TestGetPerson:
    @patch("football_api_mcp.server._get_client")
    def test_basic_call(self, mock_get_client):
        fake = _FakeModel(name="Messi", value=1)
        client = _make_mock_client(get_person=fake)
        mock_get_client.return_value = client

        result = get_person(44)

        client.get_person.assert_called_once_with(44)
        assert result == {"name": "Messi", "value": 1}


# ---------------------------------------------------------------------------
# API key validation
# ---------------------------------------------------------------------------


class TestGetClient:
    def test_missing_api_key(self, monkeypatch):
        monkeypatch.delenv("FOOTBALL_DATA_API_KEY", raising=False)
        with pytest.raises(ValueError, match="FOOTBALL_DATA_API_KEY"):
            from football_api_mcp.server import _get_client

            _get_client()

    @patch("football_api_mcp.server.FootballClient")
    def test_returns_client_when_key_set(self, mock_cls, monkeypatch):
        monkeypatch.setenv("FOOTBALL_DATA_API_KEY", "test-key-123")
        from football_api_mcp.server import _get_client

        client = _get_client()

        mock_cls.assert_called_once_with(api_key="test-key-123")
        assert client is mock_cls.return_value
