# football-api-mcp

MCP server for [football-data.org](https://www.football-data.org/) API. Built on [football-api](https://pypi.org/project/football-api/).

## Setup

```bash
pip install football-api-mcp
```

Get a free API key at [football-data.org](https://www.football-data.org/client/register).

## Claude Desktop

Add to `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "football-data": {
      "command": "python",
      "args": ["-m", "football_api_mcp"],
      "env": {
        "FOOTBALL_DATA_API_KEY": "your-api-key"
      }
    }
  }
}
```

## Tools

| Tool | Description |
|------|-------------|
| `get_standings` | League table |
| `get_matches` | Matches by date/status |
| `get_competition_matches` | Matches in a competition |
| `get_team` | Team info |
| `get_team_matches` | Team's matches |
| `get_scorers` | Top scorers |
| `get_person` | Player/coach info |

Competition codes: `PL` `BL1` `SA` `FL1` `PD` `CL` `EC` `WC` `ELC` `PPL` `DED` `BSA`

## License

MIT
