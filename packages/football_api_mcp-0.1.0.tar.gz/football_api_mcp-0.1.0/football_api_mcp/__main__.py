"""Entry point: python -m football_api_mcp"""

from football_api_mcp.server import mcp

mcp.run(transport="stdio")
