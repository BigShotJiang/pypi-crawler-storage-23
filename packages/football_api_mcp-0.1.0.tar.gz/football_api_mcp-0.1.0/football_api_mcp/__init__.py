"""MCP server exposing football-data.org API via the football-api client."""

from football_api_mcp.server import mcp

__all__ = ["mcp"]
