"""Football Data MCP server — exposes football-data.org API as MCP tools."""

from __future__ import annotations

import os

from football_api import FootballClient
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("football-data")

COMPETITION_CODES_HELP = (
    "Competition code (e.g. PL=Premier League, BL1=Bundesliga, SA=Serie A, "
    "FL1=Ligue 1, PD=La Liga, CL=Champions League, EC=European Championship, "
    "WC=World Cup, ELC=Championship, PPL=Primeira Liga, DED=Eredivisie, BSA=Brasileirão)."
)


def _get_client() -> FootballClient:
    """Create a FootballClient using the FOOTBALL_DATA_API_KEY env var."""
    api_key = os.environ.get("FOOTBALL_DATA_API_KEY")
    if not api_key:
        raise ValueError(
            "FOOTBALL_DATA_API_KEY environment variable is not set. "
            "Get a free API key at https://www.football-data.org/client/register"
        )
    return FootballClient(api_key=api_key)


def _serialize(obj: object) -> object:
    """Convert pydantic models (and nested structures) to JSON-safe dicts."""
    if hasattr(obj, "model_dump"):
        return obj.model_dump(mode="json", by_alias=True)
    return obj


# ---------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------


@mcp.tool()
def get_standings(
    competition: str, season: int | None = None, matchday: int | None = None
) -> dict:
    """Get league table / standings for a competition.

    Args:
        competition: Competition code (PL, BL1, SA, FL1, PD, CL, EC, WC, ELC, PPL, DED, BSA)
                     or numeric competition id.
        season: Filter by season year (e.g. 2024). Defaults to the current season.
        matchday: Filter by matchday number.

    Returns standings with groups/tables including position, team, points,
    wins, draws, losses, goals for/against.
    """
    with _get_client() as client:
        result = client.get_standings(competition, season=season, matchday=matchday)
    return _serialize(result)


@mcp.tool()
def get_matches(
    date_from: str | None = None,
    date_to: str | None = None,
    status: str | None = None,
    competitions: str | None = None,
) -> dict:
    """Get football matches, optionally filtered by date range and status.

    Args:
        date_from: Start date in YYYY-MM-DD format.
        date_to: End date in YYYY-MM-DD format.
        status: Match status filter — SCHEDULED, TIMED, IN_PLAY, PAUSED,
                FINISHED, POSTPONED, SUSPENDED, CANCELLED.
                Multiple values comma-separated.
        competitions: Comma-separated competition codes (PL,BL1,SA) or ids
                      to filter matches.

    Returns a list of matches with scores, teams, and metadata.
    When no dates given, defaults to today's matches.
    """
    with _get_client() as client:
        result = client.get_matches(
            date_from=date_from,
            date_to=date_to,
            status=status,
            competitions=competitions,
        )
    return _serialize(result)


@mcp.tool()
def get_competition_matches(
    competition: str,
    matchday: int | None = None,
    season: int | None = None,
    status: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
) -> dict:
    """Get matches for a specific competition.

    Args:
        competition: Competition code (PL, BL1, SA, FL1, PD, CL, EC, WC, ELC, PPL, DED, BSA)
                     or numeric competition id.
        matchday: Filter by matchday number.
        season: Filter by season year (e.g. 2024).
        status: Match status filter — SCHEDULED, TIMED, IN_PLAY, PAUSED,
                FINISHED, POSTPONED, SUSPENDED, CANCELLED.
        date_from: Start date in YYYY-MM-DD format.
        date_to: End date in YYYY-MM-DD format.

    Returns matches for the given competition with full score and team details.
    """
    with _get_client() as client:
        result = client.get_competition_matches(
            competition,
            matchday=matchday,
            season=season,
            status=status,
            date_from=date_from,
            date_to=date_to,
        )
    return _serialize(result)


@mcp.tool()
def get_team(team_id: int) -> dict:
    """Get detailed information about a football team.

    Args:
        team_id: Numeric team id from football-data.org
                 (e.g. 57=Arsenal, 65=Manchester City, 86=Real Madrid,
                  5=Bayern Munich, 108=Barcelona).

    Returns team details including name, venue, coach, squad list,
    running competitions, and club colors.
    """
    with _get_client() as client:
        result = client.get_team(team_id)
    return _serialize(result)


@mcp.tool()
def get_team_matches(
    team_id: int,
    season: int | None = None,
    status: str | None = None,
    venue: str | None = None,
    date_from: str | None = None,
    date_to: str | None = None,
    limit: int | None = None,
) -> dict:
    """Get matches for a specific team.

    Args:
        team_id: Numeric team id from football-data.org.
        season: Filter by season year (e.g. 2024).
        status: Match status filter — SCHEDULED, TIMED, IN_PLAY, PAUSED,
                FINISHED, POSTPONED, SUSPENDED, CANCELLED.
        venue: HOME or AWAY.
        date_from: Start date in YYYY-MM-DD format.
        date_to: End date in YYYY-MM-DD format.
        limit: Maximum number of matches to return.

    Returns a list of matches for the given team with scores and opponents.
    """
    with _get_client() as client:
        result = client.get_team_matches(
            team_id,
            season=season,
            status=status,
            venue=venue,
            date_from=date_from,
            date_to=date_to,
            limit=limit,
        )
    return _serialize(result)


@mcp.tool()
def get_scorers(
    competition: str,
    season: int | None = None,
    matchday: int | None = None,
    limit: int | None = None,
) -> dict:
    """Get top scorers for a competition.

    Args:
        competition: Competition code (PL, BL1, SA, FL1, PD, CL, EC, WC, ELC, PPL, DED, BSA)
                     or numeric competition id.
        season: Filter by season year (e.g. 2024).
        matchday: Filter by matchday number.
        limit: Maximum number of scorers to return.

    Returns a ranked list of top scorers with goals, assists, penalties,
    and the team they play for.
    """
    with _get_client() as client:
        result = client.get_scorers(
            competition, season=season, matchday=matchday, limit=limit
        )
    return _serialize(result)


@mcp.tool()
def get_person(person_id: int) -> dict:
    """Get information about a person (player, coach, or referee).

    Args:
        person_id: Numeric person id from football-data.org.

    Returns person details including name, date of birth, nationality,
    position, shirt number, and current team.
    """
    with _get_client() as client:
        result = client.get_person(person_id)
    return _serialize(result)
