from typing import Any, Protocol


class EventPayloadTransformer(Protocol):
    """Contract for platform-specific envelope transformers."""

    def transform(self, envelope: dict[str, Any]) -> dict[str, Any]:
        """Transform an envelope before it is sent to a platform."""
        ...


__all__ = ["EventPayloadTransformer"]
