# OpenAPI Snapshots

Generated artifacts are written here:

- `openapi.json` from `scripts/sync_openapi.py`
- `metadata.json` from `scripts/sync_openapi.py`

These files are intended to be committed when syncing against upstream API changes.
