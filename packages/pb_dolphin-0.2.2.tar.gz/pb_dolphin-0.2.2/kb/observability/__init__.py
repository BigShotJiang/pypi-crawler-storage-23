"""Structured logging for KB backend."""

from .structured_logger import LogLevel, StructuredLogger

__all__ = ["StructuredLogger", "LogLevel"]
