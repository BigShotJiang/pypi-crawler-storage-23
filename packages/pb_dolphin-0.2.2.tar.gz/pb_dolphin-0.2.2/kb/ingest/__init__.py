"""Ingestion package."""

# Avoid importing CLI and pipeline at package import time to prevent cycles.
__all__: list[str] = []
