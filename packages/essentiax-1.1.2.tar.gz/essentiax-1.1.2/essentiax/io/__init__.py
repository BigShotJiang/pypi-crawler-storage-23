from .smart_read import smart_read


def hello():
    return "Hello from Essentia library!"

__all__ = ["smart_read", "hello"]
