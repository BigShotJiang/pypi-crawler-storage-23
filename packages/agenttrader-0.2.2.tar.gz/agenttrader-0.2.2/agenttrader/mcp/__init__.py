from agenttrader.mcp.server import server

__all__ = ["server"]
