from agenttrader.dashboard.server import app

__all__ = ["app"]
