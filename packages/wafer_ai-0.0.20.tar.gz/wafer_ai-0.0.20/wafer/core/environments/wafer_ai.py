"""Wafer AI environment with minimal toolset for code editing tasks.
Tools: read, write, edit, glob, grep, bash, sandbox, skill, ask_docs, eval_task
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING

import trio

if TYPE_CHECKING:
    from wafer.core.sandbox.session import SandboxSession

from wafer.core.rollouts.dtypes import (
    AgentState,
    Message,
    RunConfig,
    Tool,
    ToolCall,
    ToolResult,
)
from wafer.core.rollouts.dtypes import ToolResultDelta
from wafer.core.tools import (
    ASK_DOCS_TOOL,
    BASH_TOOL,
    EDIT_TOOL,
    EVAL_TOOL,
    GLOB_TOOL,
    GREP_TOOL,
    READ_TOOL,
    SANDBOX_TOOL,
    SKILL_TOOL,
    WRITE_TOOL,
    ApprovalCallback,
    exec_ask_docs,
    exec_bash,
    exec_edit,
    exec_eval,
    exec_glob,
    exec_grep,
    exec_read,
    exec_sandbox,
    exec_skill,
    exec_write,
)


def _shorten_path(path: str) -> str:
    """Convert absolute path to tilde notation if in home directory."""
    home = os.path.expanduser("~")
    if path.startswith(home):
        return "~" + path[len(home) :]
    return path


ALL_TOOLS = {
    "read": READ_TOOL,
    "write": WRITE_TOOL,
    "edit": EDIT_TOOL,
    "glob": GLOB_TOOL,
    "grep": GREP_TOOL,
    "bash": BASH_TOOL,
    "sandbox": SANDBOX_TOOL,
    "skill": SKILL_TOOL,
    "ask_docs": ASK_DOCS_TOOL,
    "eval_task": EVAL_TOOL,
}


@dataclass
class WaferAiEnvironment:
    """Local filesystem environment with read, write, edit, glob, grep, bash tools.
    Args:
        working_dir: Working directory for file operations and commands.
        enabled_tools: List of tool names to enable. If None, all tools enabled.
            Valid tools: read, write, edit, glob, grep, bash, sandbox.
        bash_allowlist: List of allowed bash command prefixes. Commands matching
            these prefixes execute without prompting.
        bash_denylist: List of denied bash command prefixes. Commands matching
            these prefixes are always blocked.
        bash_approval_callback: Optional callback for "ask" tier approval.
            If None, commands not in allowlist are denied (headless mode).
        allow_network: Whether to allow network access for bash commands.
        ssh_target: SSH target (user@host:port) for sandbox. Required if sandbox enabled.
        ssh_key: Path to SSH key for sandbox.
        target_name: Target name for sandbox (for display).
    """
    working_dir: Path = field(default_factory=Path.cwd)
    enabled_tools: list[str] | None = None
    bash_allowlist: list[str] | None = None
    bash_denylist: list[str] | None = None
    bash_approval_callback: ApprovalCallback | None = None
    allow_network: bool = False
    ssh_target: str | None = None
    ssh_key: str | None = None
    target_name: str | None = None
    _sandbox_session: "SandboxSession | None" = field(default=None, repr=False)

    def __post_init__(self) -> None:
        """Validate enabled_tools and sandbox requirements."""
        if self.enabled_tools is not None:
            valid_tools = set(ALL_TOOLS.keys())
            unknown = set(self.enabled_tools) - valid_tools
            if unknown:
                raise ValueError(
                    f"Unknown tools: {sorted(unknown)}. Available: {sorted(valid_tools)}"
                )
            if "sandbox" in self.enabled_tools and self.ssh_target is None:
                raise ValueError(
                    "sandbox tool requires ssh_target. "
                    "Use a target with SSH (wafer target init ssh) and set default."
                )

    def get_name(self) -> str:
        """Return environment name identifier."""
        return "wafer-ai"

    async def serialize(self) -> dict:
        return {
            "working_dir": str(self.working_dir),
            "enabled_tools": self.enabled_tools,
            "bash_allowlist": self.bash_allowlist,
            "bash_denylist": self.bash_denylist,
            "allow_network": self.allow_network,
            "ssh_target": self.ssh_target,
            "ssh_key": self.ssh_key,
            "target_name": self.target_name,
        }

    @staticmethod
    async def deserialize(data: dict) -> WaferAiEnvironment:
        return WaferAiEnvironment(
            working_dir=Path(data["working_dir"]),
            enabled_tools=data.get("enabled_tools"),
            bash_allowlist=data.get("bash_allowlist"),
            bash_denylist=data.get("bash_denylist"),
            allow_network=data.get("allow_network", False),
            ssh_target=data.get("ssh_target"),
            ssh_key=data.get("ssh_key"),
            target_name=data.get("target_name"),
        )

    async def close(self) -> None:
        """Close sandbox session if active."""
        if self._sandbox_session is not None:
            await self._sandbox_session.close()
            self._sandbox_session = None

    async def _exec_sandbox(self, tool_call: ToolCall) -> ToolResult:
        """Execute sandbox tool. Lazy-creates SandboxSession on first call."""
        if self.ssh_target is None or self.ssh_key is None:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error="sandbox requires ssh_target and ssh_key",
            )
        if self._sandbox_session is None:
            from wafer.core.sandbox import (
                SandboxSession,
                create_sandbox,
            )

            sandbox = create_sandbox(
                target_name=self.target_name or "default",
                ssh_target=self.ssh_target,
                ssh_key=self.ssh_key,
            )
            self._sandbox_session = SandboxSession(sandbox)
            await self._sandbox_session.start()
        return await exec_sandbox(tool_call, self._sandbox_session)

    def requires_confirmation(self, tool_call: ToolCall) -> bool:
        """Only bash commands require confirmation by default."""
        return tool_call.name == "bash"

    def get_tools(self) -> list[Tool]:
        """Return enabled tools."""
        if self.enabled_tools is None:
            return list(ALL_TOOLS.values())
        return [ALL_TOOLS[name] for name in self.enabled_tools if name in ALL_TOOLS]

    async def on_assistant_message(self, message: Message, state: AgentState) -> AgentState:
        """No feedback needed for wafer-ai environment."""
        return state

    async def exec_tool(
        self,
        tool_call: ToolCall,
        current_state: AgentState,
        run_config: RunConfig,
        cancel_scope: trio.CancelScope | None = None,
    ) -> ToolResult:
        """Execute tool call."""
        if self.enabled_tools is not None and tool_call.name not in self.enabled_tools:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Tool '{tool_call.name}' is not enabled. Enabled tools: {', '.join(self.enabled_tools)}",
            )
        async def _bash_on_output(chunk: str) -> None:
            await run_config.on_chunk(ToolResultDelta(
                tool_call_id=tool_call.id,
                delta=chunk,
            ))

        handlers = {
            "read": lambda tc: exec_read(tc, self.working_dir),
            "write": lambda tc: exec_write(tc, self.working_dir),
            "edit": lambda tc: exec_edit(tc, self.working_dir),
            "glob": lambda tc: exec_glob(tc, self.working_dir),
            "grep": lambda tc: exec_grep(tc, self.working_dir),
            "bash": lambda tc: exec_bash(
                tc,
                self.working_dir,
                cancel_scope,
                self.bash_allowlist,
                self.bash_denylist,
                self.bash_approval_callback,
                on_output=_bash_on_output,
            ),
            "skill": lambda tc: exec_skill(tc),
            "ask_docs": lambda tc: exec_ask_docs(tc),
            "eval_task": lambda tc: exec_eval(tc, self.working_dir),
            "sandbox": lambda tc: self._exec_sandbox(tc),
        }
        handler = handlers.get(tool_call.name)
        if handler is None:
            return ToolResult(
                tool_call_id=tool_call.id,
                is_error=True,
                content="",
                error=f"Unknown tool: {tool_call.name}",
            )
        try:
            return await handler(tool_call)
        except Exception as e:
            return ToolResult(tool_call_id=tool_call.id, is_error=True, content="", error=str(e))
