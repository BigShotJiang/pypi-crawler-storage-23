"""Sandbox CLI: create, manage, and run commands in tmux sandboxes on remote GPU machines."""
from __future__ import annotations

import os
import shlex
from pathlib import Path

import trio
import trio_asyncio
import typer

from wafer.cli.target_resolve import resolve_target
from wafer.cli.targets import load_target
from wafer.cli.targets_ops import get_target_ssh_info, sync_to_target
from wafer.core.sandbox import (
    SandboxSession,
    create_sandbox,
    destroy_all_sandboxes,
    destroy_sandbox,
    list_sandboxes,
)
from wafer.core.sandbox.manager import DEFAULT_TIMEOUT_HOURS
from wafer.core.sandbox.types import Sandbox
from wafer.core.ssh_utils import parse_ssh_target

sandbox_app = typer.Typer(
    name="sandbox",
    help="Create, manage, and run commands in sandboxes on remote GPU machines.",
    no_args_is_help=True,
)


def _get_ssh_creds(target_name: str) -> tuple[str, str]:
    """Load target and return (ssh_target, ssh_key)."""
    target = load_target(target_name)
    if not hasattr(target, "ssh_target") or not target.ssh_target:
        typer.echo(f"Error: target '{target_name}' has no SSH credentials", err=True)
        raise typer.Exit(1)
    return target.ssh_target, target.ssh_key


def _run_async(async_fn):
    """Run an async function (not a coroutine) via trio with trio_asyncio bridge."""

    async def _wrapper():
        async with trio_asyncio.open_loop():
            return await async_fn()

    return trio.run(_wrapper)


@sandbox_app.command("create")
def sandbox_create(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name"),
    timeout: int = typer.Option(4, "--timeout-hours", help="Self-destruct timeout in hours"),
) -> None:
    """Create a new sandbox on the target."""
    try:
        target_name, _ = resolve_target(name=target)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    ssh_target, ssh_key = _get_ssh_creds(target_name)

    sandbox = create_sandbox(target_name, ssh_target, ssh_key, timeout)

    async def _create():
        session = SandboxSession(sandbox)
        await session.start()

    _run_async(_create)
    typer.echo(
        f"Sandbox {sandbox.id} created on {target_name}. "
        f"Attach: wafer sandbox attach {sandbox.id} --target {target_name}"
    )


@sandbox_app.command("list")
def sandbox_list(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name"),
    json_output: bool = typer.Option(False, "--json", "-j", help="Output as JSON"),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Show extra details (tmp dir path)"),
) -> None:
    """List sandboxes. With --target, list on that target only."""
    import json as json_mod

    rows: list[tuple[str, str]] = []

    if target:
        try:
            target_name, _ = resolve_target(name=target)
        except RuntimeError as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1) from None
        ssh_target, ssh_key = _get_ssh_creds(target_name)

        async def _list():
            return await list_sandboxes(ssh_target, ssh_key)

        sessions = _run_async(_list)
        rows.extend((s, target_name) for s in sessions)
    else:
        from wafer.cli.targets import list_targets

        for tname in list_targets():
            try:
                ssh_target, ssh_key = _get_ssh_creds(tname)

                async def _list_target(st=ssh_target, sk=ssh_key):
                    return await list_sandboxes(st, sk)

                sessions = _run_async(_list_target)
                rows.extend((s, tname) for s in sessions)
            except Exception:
                pass

    if json_output:
        items = [
            {"id": sid, "target": tname, "status": "active", "tmp_dir": f"/tmp/.wafer_sandbox/{sid}"}
            if verbose
            else {"id": sid, "target": tname, "status": "active"}
            for sid, tname in rows
        ]
        typer.echo(json_mod.dumps({"sandboxes": items}))
        return

    if not rows:
        typer.echo("No sandboxes found.")
        return

    if verbose:
        typer.echo(f"{'ID':<40} {'TARGET':<22} {'STATUS':<8} TMP_DIR")
        typer.echo(f"{'-'*40} {'-'*22} {'-'*8} {'-'*40}")
        for sid, tname in rows:
            typer.echo(f"{sid:<40} {tname:<22} {'active':<8} /tmp/.wafer_sandbox/{sid}")
    else:
        typer.echo(f"{'ID':<40} {'TARGET':<22} STATUS")
        typer.echo(f"{'-'*40} {'-'*22} {'-'*8}")
        for sid, tname in rows:
            typer.echo(f"{sid:<40} {tname:<22} active")


@sandbox_app.command("status")
def sandbox_status(
    target: str | None = typer.Option(None, "--target", "-t", help="Target name"),
) -> None:
    """Show sandbox status (alias for 'list --verbose')."""
    sandbox_list(target=target, json_output=False, verbose=True)


@sandbox_app.command("attach")
def sandbox_attach(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID (e.g. sandbox-abc12345)"),
    target: str | None = typer.Option(None, "--target", "-t", help="Target name"),
) -> None:
    """Attach to a sandbox tmux session (interactive)."""
    try:
        target_name, _ = resolve_target(name=target)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        typer.echo("Set default: wafer target default <name>", err=True)
        raise typer.Exit(1) from None
    ssh_target, ssh_key = _get_ssh_creds(target_name)
    parsed = parse_ssh_target(ssh_target)
    key_path = str(Path(ssh_key).expanduser().resolve())
    tmux_session = sandbox_id if sandbox_id.startswith("wafer-") else f"wafer-{sandbox_id}"
    os.execvp(
        "ssh",
        [
            "ssh",
            "-t",
            "-p",
            str(parsed.port),
            "-i",
            key_path,
            "-o",
            "StrictHostKeyChecking=no",
            "-o",
            "UserKnownHostsFile=/dev/null",
            f"{parsed.user}@{parsed.host}",
            f"tmux attach -t {tmux_session}",
        ],
    )


@sandbox_app.command("destroy")
def sandbox_destroy(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID or 'all'"),
    target: str | None = typer.Option(None, "--target", "-t", help="Target name"),
) -> None:
    """Destroy a sandbox (or all with sandbox_id=all)."""
    try:
        target_name, _ = resolve_target(name=target)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        typer.echo("Set default: wafer target default <name>", err=True)
        raise typer.Exit(1) from None
    ssh_target, ssh_key = _get_ssh_creds(target_name)
    if sandbox_id.lower() == "all":

        async def _destroy_all():
            return await destroy_all_sandboxes(ssh_target, ssh_key)

        count = _run_async(_destroy_all)
        typer.echo(f"Destroyed {count} sandbox(es)")
    else:
        tmux_session = sandbox_id if sandbox_id.startswith("wafer-") else f"wafer-{sandbox_id}"

        async def _check_and_destroy():
            sessions = await list_sandboxes(ssh_target, ssh_key)
            if tmux_session not in sessions:
                return False
            await destroy_sandbox(ssh_target, ssh_key, tmux_session)
            return True

        existed = _run_async(_check_and_destroy)
        if existed:
            typer.echo(f"Destroyed {sandbox_id}")
        else:
            typer.echo(f"Sandbox {sandbox_id} not found (may already be destroyed)")


@sandbox_app.command("run")
def sandbox_run(
    command: list[str] = typer.Argument(..., help="Command to run"),
    target: str | None = typer.Option(None, "--target", "-t", help="Target name"),
    sandbox_id: str | None = typer.Option(None, "--sandbox", "-s", help="Sandbox ID to run in (default: first available)"),
    sync_path: Path | None = typer.Option(None, "--sync", help="Path to sync before run"),
    timeout: int = typer.Option(300, "--timeout-sec", help="Command timeout in seconds (default: 300)"),
) -> None:
    """Run a command in a sandbox. Creates one if none exists."""
    try:
        target_name, _ = resolve_target(name=target)
    except RuntimeError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    ssh_target, ssh_key = _get_ssh_creds(target_name)

    if sync_path and sync_path.exists():
        t = load_target(target_name)

        async def _get_info():
            return await get_target_ssh_info(t)

        ssh_info = _run_async(_get_info)
        sync_to_target(ssh_info, sync_path.resolve())

    cmd_str = shlex.join(command) if len(command) > 1 else (command[0] if command else "")

    async def _run_in_sandbox():
        sessions = await list_sandboxes(ssh_target, ssh_key)
        if sandbox_id:
            tmux_session = sandbox_id if sandbox_id.startswith("wafer-") else f"wafer-{sandbox_id}"
            if tmux_session not in sessions:
                typer.echo(f"Error: Sandbox {sandbox_id} not found on {target_name}", err=True)
                typer.echo("  List sandboxes: wafer sandbox list --target " + target_name, err=True)
                raise typer.Exit(1)
        elif sessions:
            tmux_session = sessions[0]
        else:
            tmux_session = None

        if tmux_session:
            suffix = tmux_session.replace("wafer-sandbox-", "")
            sandbox = Sandbox(
                id=f"sandbox-{suffix}",
                target_name=target_name,
                tmux_session=tmux_session,
                ssh_target=ssh_target,
                ssh_key=ssh_key,
                created_at="",
                timeout_hours=DEFAULT_TIMEOUT_HOURS,
            )
            sb = SandboxSession(sandbox)
            await sb.connect()
        else:
            sandbox = create_sandbox(target_name, ssh_target, ssh_key)
            sb = SandboxSession(sandbox)
            await sb.start()

        try:
            output, exit_code = await sb.run_command(cmd_str, timeout)
        finally:
            if sb._client is not None:
                await sb._client.close()

        typer.echo(output)
        return exit_code

    exit_code = _run_async(_run_in_sandbox)
    raise typer.Exit(exit_code if exit_code >= 0 else 1)
