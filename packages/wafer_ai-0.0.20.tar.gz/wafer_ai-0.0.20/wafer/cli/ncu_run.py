"""NCU remote profiling — run NCU on wafer B200 machines.
Packages a local directory, uploads to B200 as tar.gz, runs NCU,
streams output in real-time, and downloads the .ncu-rep report.
This is the core module behind `wafer tool ncu run <command>`.
"""
import fnmatch
import io
import shlex
import subprocess
import tarfile
import time
from pathlib import Path

import httpx
import typer

# Default patterns to exclude from directory upload.
# These match directory names and file glob patterns.
DEFAULT_EXCLUDES = frozenset({
    ".git",
    "__pycache__",
    "node_modules",
    ".venv",
    "venv",
    ".env",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "*.pyc",
    "*.pyo",
    "*.egg-info",
    ".DS_Store",
    "Thumbs.db",
    "*.ncu-rep",  # Don't upload existing NCU reports
})


# --- Directory Packaging ---
def _get_git_tracked_files(directory: Path) -> list[Path] | None:
    """Get git-tracked + untracked-but-not-ignored files.
    Uses `git ls-files` which respects .gitignore natively.
    Returns None if not a git repo or git is unavailable.
    """
    try:
        result = subprocess.run(
            ["git", "ls-files", "--cached", "--others", "--exclude-standard"],
            cwd=directory,
            capture_output=True,
            text=True,
            timeout=10,
            check=False,
        )
        if result.returncode != 0:
            return None
        files = []
        for line in result.stdout.strip().split("\n"):
            if not line:
                continue
            file_path = directory / line
            if file_path.is_file():
                files.append(file_path)
        return files
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None


def _should_exclude(path: Path, base_dir: Path, excludes: frozenset[str]) -> bool:
    """Check if a path matches any exclusion pattern."""
    relative = path.relative_to(base_dir)

    for part in relative.parts:
        if part in excludes:
            return True

        for pattern in excludes:
            if "*" in pattern and fnmatch.fnmatch(part, pattern):
                return True
    return False


def _collect_files_for_upload(
    directory: Path,
    extra_excludes: set[str] | None = None,
) -> list[Path]:
    """Collect files from directory for upload.
    Strategy:
    1. If in a git repo, use `git ls-files` (respects .gitignore)
    2. Otherwise, walk directory with default exclusion patterns
    In both cases, user-provided --exclude patterns and DEFAULT_EXCLUDES
    are applied so that e.g. --exclude "*.bin" works regardless of
    whether the project is a git repo.
    """
    assert directory.is_dir(), f"Not a directory: {directory}"
    all_excludes = DEFAULT_EXCLUDES | frozenset(extra_excludes or set())
    # Try git ls-files first — most robust .gitignore handling
    git_files = _get_git_tracked_files(directory)
    if git_files is not None:
        # Still apply DEFAULT_EXCLUDES + user --exclude patterns on top
        # of git's .gitignore filtering. This ensures --exclude flags
        # and built-in exclusions (*.ncu-rep, __pycache__) always work.
        return [f for f in git_files if not _should_exclude(f, directory, all_excludes)]
    # Fallback: walk directory with exclusion patterns
    files = []
    for file_path in sorted(directory.rglob("*")):
        if file_path.is_file() and not _should_exclude(file_path, directory, all_excludes):
            files.append(file_path)
    return files


def package_directory(
    directory: Path,
    extra_excludes: set[str] | None = None,
) -> tuple[bytes, int]:
    """Package directory as tar.gz for upload.
    Returns (tarball_bytes, file_count).
    Raises AssertionError if no files found.
    """
    assert directory.is_dir(), f"Not a directory: {directory}"
    files = _collect_files_for_upload(directory, extra_excludes)
    assert len(files) > 0, f"No files found in {directory}"
    buf = io.BytesIO()
    with tarfile.open(fileobj=buf, mode="w:gz") as tar:
        for file_path in files:
            relative = file_path.relative_to(directory)
            tar.add(str(file_path), arcname=str(relative))
    return buf.getvalue(), len(files)


# --- SSE Stream Processing ---
def _handle_sse_line(content: str, state: dict) -> None:
    """Handle a single SSE data line. Mutates state dict for job_id/exit_code.
    Why mutate state? Because we need to pass data back from the SSE stream
    processing loop (job_id for report download, exit_code for return value)
    without complex return-value plumbing through the streaming loop.
    """
    if content == "[DONE]":
        state["done"] = True
    elif content.startswith("[ERROR]"):
        typer.echo(content[8:], err=True)
        state["exit_code"] = 1
        state["done"] = True
    elif content.startswith("[EXIT:"):

        try:
            state["exit_code"] = int(content[6:-1])
        except ValueError:
            state["exit_code"] = 1
    elif content.startswith("[REPORT_READY:"):

        state["job_id"] = content[14:-1]
    elif content.startswith("[QUEUE_POSITION:"):
        # Queue position update: [QUEUE_POSITION:position:estimated_seconds]
        # Sent when all GPUs are busy and the job is waiting in queue
        try:
            parts = content[16:-1].split(":")
            if len(parts) == 2:
                position = parts[0]
                est_seconds = int(parts[1])
                est_str = f"{est_seconds}s" if est_seconds < 60 else f"{est_seconds // 60}m {est_seconds % 60}s"
                typer.echo(f"\r[wafer] Queue position: {position} (est. wait: {est_str})", nl=False)
            else:
                typer.echo("[wafer] Waiting in queue...")
        except (ValueError, IndexError):
            typer.echo("[wafer] Waiting in queue...")
    elif content.startswith("[STATUS:"):
        status = content[8:-1]
        # Map internal status codes to user-friendly messages
        status_messages = {
            "ALLOCATING_GPU": "Allocating GPU...",
            "QUEUED": "All GPUs busy — waiting in queue...",
            "UPLOADING": "Uploading code to B200...",
            "RUNNING": "Running NCU profiling...",
        }
        # Handle GPU_ALLOCATED:N format
        if status.startswith("GPU_ALLOCATED:"):
            gpu_id = status.split(":")[1]
            typer.echo(f"\n[wafer] GPU {gpu_id} allocated")
        else:
            message = status_messages.get(status, status)
            typer.echo(f"[wafer] {message}")
    elif content.startswith("[BILLING:"):
        billing_info = content[9:-1]
        typer.echo(f"[wafer] {billing_info}", err=True)
    else:
        # NCU output or user program output — print directly
        typer.echo(content)


def _stream_sse_response(response: httpx.Response) -> dict:
    """Process SSE stream from API response. Returns state dict with results."""
    state: dict = {"exit_code": 0, "job_id": None, "done": False}
    for line in response.iter_lines():
        if not line:
            continue
        if line.startswith("data: "):
            content = line[6:]
            _handle_sse_line(content, state)
            if state["done"]:
                break
    return state


# --- Report Download ---
def _download_report(
    api_url: str,
    headers: dict[str, str],
    job_id: str,
    output: Path | None,
    directory: Path,
) -> None:
    """Download .ncu-rep report from B200 after profiling."""
    if output is None:
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        output = Path(f"{directory.name}_{timestamp}.ncu-rep")
    typer.echo("\nDownloading report...")
    try:
        with httpx.Client(timeout=120.0, headers=headers) as client:
            with client.stream("GET", f"{api_url}/v1/ncu/run/{job_id}/report") as resp:
                resp.raise_for_status()
                total = 0
                with open(output, "wb") as f:
                    for chunk in resp.iter_bytes(chunk_size=1024 * 1024):
                        f.write(chunk)
                        total += len(chunk)
        size_mb = total / 1024 / 1024
        typer.echo(f"Report saved to {output} ({size_mb:.1f} MB)")
        typer.echo(f"\nTip: Run `wafer tool ncu analyze {output}` for detailed analysis.")
    except httpx.HTTPStatusError as e:
        if e.response.status_code == 404:
            typer.echo(
                "Warning: No .ncu-rep report found (NCU may not have produced one).", err=True
            )
        else:
            typer.echo(f"Warning: Failed to download report: {e.response.status_code}", err=True)
    except Exception as e:
        typer.echo(f"Warning: Failed to download report: {e}", err=True)


# --- Main Entry Point ---
def ncu_run(  # noqa: PLR0913 — many params required for CLI passthrough
    command: list[str],
    directory: Path = Path("."),
    ncu_args: str = "",
    requirements: Path | None = None,
    output: Path | None = None,
    no_download: bool = False,
    exclude: list[str] | None = None,
    timeout: int = 600,
    queue_timeout: int = 300,
) -> int:
    """Run NCU profiling on wafer B200.
    Packages directory, uploads tarball to B200, runs NCU on bare metal,
    streams profiling output, and downloads the .ncu-rep report.

    GPU scheduling: If all B200 GPUs are busy (used by other NCU runs
    or workspaces), the job enters a FIFO queue with position updates.

    Returns exit code (0 = success).
    """
    from .api_client import _get_auth_headers
    from .global_config import get_api_url
    directory = directory.resolve()
    assert directory.is_dir(), f"Not a directory: {directory}"

    # e.g. ["python", "-c", "print('a b')"] → "python -c 'print('\"'\"'a b'\"'\"')'"
    # The API's _build_ncu_command will re-parse with shlex.split and re-quote.
    cmd_str = shlex.join(command)
    assert len(cmd_str) > 0, "No command provided"
    # --- Package directory ---
    typer.echo(f"Packaging {directory.name}/...")
    extra_excludes = set(exclude) if exclude else None
    tarball, file_count = package_directory(directory, extra_excludes)
    size_mb = len(tarball) / 1024 / 1024
    typer.echo(f"  {file_count} files ({size_mb:.1f} MB compressed)")
    # --- Detect requirements ---
    requirements_content = None
    if requirements and requirements.exists():
        requirements_content = requirements.read_text()
    elif (directory / "requirements.txt").exists():
        requirements_content = (directory / "requirements.txt").read_text()
    # --- Upload + stream ---
    api_url = get_api_url()
    headers = _get_auth_headers()
    typer.echo("Uploading to wafer B200...")
    typer.echo(f"Command: ncu {ncu_args + ' ' if ncu_args else ''}{cmd_str}")
    typer.echo("-" * 60)
    state = _upload_and_stream(
        api_url,
        headers,
        tarball,
        cmd_str,
        ncu_args,
        requirements_content,
        timeout,
        queue_timeout,
    )
    # --- Download report ---
    if state["job_id"] and not no_download and state["exit_code"] == 0:
        _download_report(api_url, headers, state["job_id"], output, directory)
    return state["exit_code"]


def _upload_and_stream(  # noqa: PLR0913
    api_url: str,
    headers: dict[str, str],
    tarball: bytes,
    cmd_str: str,
    ncu_args: str,
    requirements_content: str | None,
    timeout: int,
    queue_timeout: int = 300,
) -> dict:
    """Upload tarball and stream NCU execution output. Returns state dict."""
    files_dict = {
        "tarball": ("workspace.tar.gz", tarball, "application/gzip"),
    }
    data_dict: dict[str, str] = {
        "command": cmd_str,
        "ncu_args": ncu_args,
        "timeout_seconds": str(timeout),
        "queue_timeout_seconds": str(queue_timeout),
    }
    if requirements_content:
        data_dict["requirements"] = requirements_content
    try:
        with httpx.Client(timeout=120, headers=headers) as client:
            with client.stream(
                "POST",
                f"{api_url}/v1/ncu/run",
                files=files_dict,
                data=data_dict,
            ) as response:
                if response.status_code == 402:
                    typer.echo(
                        "Error: Insufficient credits. Add credits at https://wafer.sh/billing",
                        err=True,
                    )
                    return {"exit_code": 1, "job_id": None, "done": True}
                response.raise_for_status()
                return _stream_sse_response(response)
    except httpx.HTTPStatusError as e:
        _handle_http_error(e)
        return {"exit_code": 1, "job_id": None, "done": True}
    except KeyboardInterrupt:
        typer.echo("\nInterrupted by user", err=True)
        return {"exit_code": 130, "job_id": None, "done": True}
    except httpx.ConnectError:
        typer.echo("Error: Could not connect to wafer API. Is your internet working?", err=True)
        return {"exit_code": 1, "job_id": None, "done": True}
    except Exception as e:
        typer.echo(f"Error: {e}", err=True)
        return {"exit_code": 1, "job_id": None, "done": True}


def _handle_http_error(e: httpx.HTTPStatusError) -> None:
    """Print user-friendly message for HTTP errors."""
    if e.response.status_code == 401:
        typer.echo("Error: Not authenticated. Run `wafer settings login` first.", err=True)
    elif e.response.status_code == 402:
        typer.echo("Error: Insufficient credits.", err=True)
    elif e.response.status_code == 503:
        typer.echo("Error: No GPU available. Try again shortly.", err=True)
    else:
        detail = e.response.text[:200] if e.response.text else "Unknown error"
        typer.echo(f"Error: {e.response.status_code} - {detail}", err=True)
