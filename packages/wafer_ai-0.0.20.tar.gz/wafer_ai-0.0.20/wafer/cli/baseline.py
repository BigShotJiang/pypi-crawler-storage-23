"""Baseline CLI commands.
Discover what kernel PyTorch dispatches to for a given operation.
Helps understand the baseline performance you need to beat.
"""
from __future__ import annotations

import asyncio
import types
from collections.abc import Callable
from typing import TYPE_CHECKING

import typer

if TYPE_CHECKING:
    from wafer.cli.targets_ops import TargetSSHInfo
    from wafer.core.async_ssh import SyncSSHClient as SSHClientType
    from wafer.core.tools.dispatch_baseline.executor import TraceExecutionResult

from wafer.core.tools.dispatch_baseline.client import (
    lookup_baseline,
    store_baseline,
)
from wafer.core.tools.dispatch_baseline.codegen import (
    parse_op_string,
    update_dtypes,
    update_shapes,
)
from wafer.core.tools.dispatch_baseline.dtypes import KernelTraceConfig, KernelTraceResult, OpSpec
from wafer.core.tools.dispatch_baseline.executor import trace_kernel_local
from wafer.core.tools.dispatch_baseline.roofline import HARDWARE_SPECS, get_hardware_spec
from wafer.core.utils.kernel_utils.targets.config import TargetConfig

baseline_app = typer.Typer(
    help="Discover what kernel PyTorch dispatches for a given operation."
)


def _parse_shape(shape_str: str) -> tuple[str, tuple[int, ...]]:
    """Parse shape string like 'A=4096,4096' into (name, shape)."""
    if "=" not in shape_str:
        raise typer.BadParameter(f"Invalid shape format: {shape_str}. Expected: name=dim1,dim2,...")
    name, dims_str = shape_str.split("=", 1)
    try:
        dims = tuple(int(d.strip()) for d in dims_str.split(","))
    except ValueError as err:
        raise typer.BadParameter(f"Invalid dimensions in shape: {dims_str}") from err
    return name.strip(), dims


def _complete_target_name(incomplete: str) -> list[str]:
    """Autocomplete target names from API."""
    try:
        from .targets import list_targets
        return [n for n in list_targets() if n.startswith(incomplete)]
    except Exception:
        return []


def _parse_op_and_shapes(op: str, shape: list[str], dtype: str) -> OpSpec:
    assert op, "op string must not be empty"
    assert isinstance(shape, list), "shape must be a list"
    assert dtype, "dtype must not be empty"
    try:
        op_spec = parse_op_string(op)
    except ValueError as e:
        typer.echo(f"Error parsing operation: {e}", err=True)
        raise typer.Exit(1) from None
    shapes: dict[str, tuple[int, ...]] = {}
    for shape_str in shape:
        try:
            name, dims = _parse_shape(shape_str)
            shapes[name] = dims
        except typer.BadParameter as e:
            typer.echo(f"Error: {e}", err=True)
            raise typer.Exit(1) from None
    if shapes:
        op_spec = update_shapes(op_spec, shapes)
    op_spec = update_dtypes(op_spec, dtype)
    return op_spec


def _warn_no_hardware_specs(label: str, json_output: bool) -> None:
    assert label, "label must not be empty"
    assert isinstance(json_output, bool), "json_output must be a bool"
    if not json_output:
        typer.echo(f"Warning: No roofline specs for {label}", err=True)
        typer.echo(f"Supported hardware: {', '.join(HARDWARE_SPECS.keys())}", err=True)
        typer.echo("Roofline analysis will be skipped.", err=True)
        typer.echo("")


def _try_use_cache(op_spec: OpSpec, hardware: str, pytorch_version: str, runtime_version: str, gpu_arch: str, json_output: bool) -> tuple[KernelTraceResult | None, bool]:
    assert op_spec is not None, "op_spec must not be None"
    assert pytorch_version, "pytorch_version must not be empty"
    assert gpu_arch, "gpu_arch must not be empty"
    cached = lookup_baseline(op_spec, hardware, pytorch_version, runtime_version, gpu_arch)
    if cached is not None:
        config = KernelTraceConfig(op_spec=op_spec, hardware=hardware, num_warmup=0, num_runs=0)
        from wafer.core.tools.dispatch_baseline.executor import _add_roofline_analysis
        result = _add_roofline_analysis(cached, config)
        if not json_output:
            typer.echo(f"Using cached result (key: {pytorch_version}/{runtime_version}/{gpu_arch})")
            typer.echo("")
        return result, True
    return None, False


def _detect_hardware_from_workspace(workspace_name: str, json_output: bool) -> str | None:
    assert workspace_name, "workspace_name must not be empty"
    assert isinstance(json_output, bool), "json_output must be a bool"
    ws_lower = workspace_name.lower()
    if "b200" in ws_lower:
        hardware = "B200"
    elif "mi300" in ws_lower:
        hardware = "MI300X"
    else:
        hardware = None
    if hardware:
        if not json_output:
            typer.echo(f"Auto-detected hardware from workspace name: {hardware}")
    else:
        _warn_no_hardware_specs(f"workspace name '{workspace_name}'", json_output)
    return hardware


def _execute_on_workspace(workspace_name: str, script: str, timeout: int) -> str:
    assert workspace_name, "workspace_name must not be empty"
    assert script, "script must not be empty"
    assert timeout >= 0, "timeout must be non-negative"
    import subprocess
    import tempfile
    from pathlib import Path

    with tempfile.TemporaryDirectory() as tmpdir:
        script_path = Path(tmpdir) / "baseline_trace.py"
        script_path.write_text(script)
        sync_result = subprocess.run(
            ["wafer", "target", "sync", workspace_name, str(tmpdir)],
            capture_output=True,
            text=True,
        )
        if sync_result.returncode != 0:
            typer.echo(f"Error syncing to workspace: {sync_result.stderr}", err=True)
            raise typer.Exit(1) from None
        exec_result = subprocess.run(
            ["wafer", "target", "run", "--name", workspace_name, "--timeout", str(timeout), "--",
             "python", "/workspace/baseline_trace.py"],
            capture_output=True,
            text=True,
        )
        return exec_result.stdout + exec_result.stderr


@baseline_app.command("run")
def baseline_run_cmd(
    op: str = typer.Argument(
        ...,
        help='PyTorch operation to trace, e.g., "torch.matmul(A, B)"',
    ),
    shape: list[str] = typer.Option(
        [],
        "--shape",
        "-s",
        help="Tensor shape as name=dim1,dim2,... (can specify multiple)",
    ),
    dtype: str = typer.Option(
        "float16",
        "--dtype",
        "-d",
        help="Data type for tensors (float16, float32, bfloat16, etc.)",
    ),
    hardware: str = typer.Option(
        None,
        "--hardware",
        help="Hardware name for roofline analysis (auto-detected from target if not specified)",
    ),
    target: str = typer.Option(
        None,
        "--target",
        "-t",
        help="GPU target name (see 'wafer target list')",
        autocompletion=_complete_target_name,
    ),
    workspace: str = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace name (see 'wafer target list')",
    ),
    num_warmup: int = typer.Option(
        10,
        "--warmup",
        help="Number of warmup iterations",
    ),
    num_runs: int = typer.Option(
        100,
        "--runs",
        help="Number of profiling runs",
    ),
    no_cache: bool = typer.Option(
        False,
        "--no-cache",
        help="Skip cache and always run fresh trace",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON for programmatic use",
    ),
    verbose: bool = typer.Option(
        False,
        "--verbose",
        "-v",
        help="Show verbose output including raw profiler data",
    ),
    timeout: int = typer.Option(
        120,
        "--timeout",
        help="Timeout in seconds for profiling (default: 120)",
    ),
) -> None:
    """Discover what kernel PyTorch dispatches to for a given operation.

    Examples:
        wafer baseline run "torch.matmul(A, B)" -s A=4096,4096 -s B=4096,4096 --target b200-dev
        wafer baseline run "torch.matmul(A, B)" -s A=4096,4096 -s B=4096,4096
    """
    # Validate mutually exclusive options
    if target and workspace:
        typer.echo("Error: Cannot specify both --target and --workspace", err=True)
        raise typer.Exit(1)
    # Dispatch to appropriate execution mode
    if target:
        asyncio.run(_run_on_target(
            op, shape, dtype, hardware, target, num_warmup, num_runs, no_cache, json_output, verbose, timeout
        ))
    elif workspace:
        asyncio.run(_run_on_workspace(
            op, shape, dtype, hardware, workspace, num_warmup, num_runs, no_cache, json_output, verbose, timeout
        ))
    else:
        _run_locally(op, shape, dtype, hardware, num_warmup, num_runs, no_cache, json_output, verbose, timeout)


def _run_locally(
    op: str,
    shape: list[str],
    dtype: str,
    hardware: str | None,
    num_warmup: int,
    num_runs: int,
    no_cache: bool,
    json_output: bool,
    verbose: bool,
    timeout: int,
) -> None:
    """Run baseline trace on local GPU."""
    import torch
    if not torch.cuda.is_available():
        typer.echo("Error: CUDA not available on this machine", err=True)
        typer.echo("Use --target or --workspace to run on a remote GPU.", err=True)
        raise typer.Exit(1)
    if hardware is None:
        hardware = _detect_local_hardware()
        if hardware:
            if not json_output:
                typer.echo(f"Auto-detected hardware: {hardware}")
        else:
            gpu_name = torch.cuda.get_device_name(0) if torch.cuda.is_available() else "unknown"
            _warn_no_hardware_specs(f"'{gpu_name}'", json_output)
    op_spec = _parse_op_and_shapes(op, shape, dtype)
    hw_spec = get_hardware_spec(hardware)
    if hw_spec is None:
        typer.echo(f"Warning: Unknown hardware '{hardware}', roofline analysis will be skipped", err=True)
        typer.echo(f"Supported hardware: {', '.join(HARDWARE_SPECS.keys())}", err=True)
    pytorch_version, runtime_version, gpu_arch = _get_local_gpu_info(torch)
    from_cache = False
    if not no_cache:
        result, from_cache = _try_use_cache(
            op_spec, hardware, pytorch_version, runtime_version, gpu_arch, json_output
        )
    if not from_cache:
        result = _trace_locally(op_spec, hardware, num_warmup, num_runs, timeout, json_output)
    _output_result(result, json_output, verbose, from_cache)


def _get_local_gpu_info(torch: types.ModuleType) -> tuple[str, str, str]:
    assert torch is not None, "torch module must not be None"
    assert isinstance(torch, types.ModuleType), "torch must be a module"
    pytorch_version = torch.__version__
    props = torch.cuda.get_device_properties(0)
    if hasattr(torch.version, 'hip') and torch.version.hip:
        runtime_version = torch.version.hip
        gpu_arch = getattr(props, 'gcnArchName', f"gfx{props.major}{props.minor}")
    else:
        runtime_version = torch.version.cuda or "unknown"
        gpu_arch = f"sm_{props.major}{props.minor}"
    return pytorch_version, runtime_version, gpu_arch


def _trace_locally(op_spec: OpSpec, hardware: str, num_warmup: int, num_runs: int, timeout: int, json_output: bool) -> KernelTraceResult:
    assert op_spec is not None, "op_spec must not be None"
    assert num_warmup >= 0, "num_warmup must be non-negative"
    assert num_runs >= 0, "num_runs must be non-negative"
    config = KernelTraceConfig(
        op_spec=op_spec,
        hardware=hardware,
        num_warmup=num_warmup,
        num_runs=num_runs,
        timeout_seconds=timeout,
    )
    if not json_output:
        typer.echo(f"Profiling: {op_spec}")
        typer.echo(f"Hardware: {hardware}")
        typer.echo("")
    exec_result = trace_kernel_local(config)
    result = exec_result.result
    if not result.error:
        store_baseline(
            result,
            exec_result.pytorch_version,
            exec_result.runtime_version,
            exec_result.gpu_arch,
        )
    return result


def _detect_local_hardware() -> str | None:
    """Detect accelerator hardware name from local device.
    Tries CUDA, then ROCm, then Neuron, then TPU env.
    Returns hardware name only if we have roofline specs (B200, MI300X, Trainium2, TPUv4).
    """
    from wafer.core.gpu_detect import detect_local_accelerator
    info = detect_local_accelerator()
    if info is None:
        return None
    name_upper = info.gpu_name.upper()
    if "B200" in name_upper or "B100" in name_upper:
        return "B200"
    if "MI300" in name_upper:
        return "MI300X"
    if info.vendor == "trainium":
        return "TRAINIUM2"
    if info.vendor == "tpu":
        return "TPUV4"
    return None


def _detect_hardware_from_target(target_config: TargetConfig) -> str | None:
    """Detect hardware from target configuration.
    Returns hardware name only if we have roofline specs.
    """
    gpu_type = getattr(target_config, "gpu_type", None)
    if gpu_type:
        gpu_upper = gpu_type.upper().replace("-", "").replace(" ", "")
        if gpu_upper in HARDWARE_SPECS:
            return gpu_upper
        if "TRAINIUM" in gpu_upper or "TRN" in gpu_upper:
            return "TRAINIUM2"
        if "TPU" in gpu_upper:
            return "TPUV4"
    return None


async def _run_on_target(
    op: str,
    shape: list[str],
    dtype: str,
    hardware: str | None,
    target_name: str,
    num_warmup: int,
    num_runs: int,
    no_cache: bool,
    json_output: bool,
    verbose: bool,
    timeout: int,
) -> None:
    """Run baseline trace on a configured target via SSH."""
    from wafer.core.async_ssh import SyncSSHClient as SSHClient
    from wafer.core.tools.dispatch_baseline.executor import trace_kernel_remote

    from .targets import load_target
    from .targets_ops import TargetExecError, get_target_ssh_info
    try:
        target_config = load_target(target_name)
    except FileNotFoundError:
        typer.echo(f"Error: Target '{target_name}' not found", err=True)
        typer.echo("Run 'wafer target list' to see available targets", err=True)
        raise typer.Exit(1) from None
    if hardware is None:
        hardware = _detect_hardware_from_target(target_config)
        if hardware:
            if not json_output:
                typer.echo(f"Auto-detected hardware from target: {hardware}")
        else:
            _warn_no_hardware_specs("target's GPU", json_output)
    try:
        ssh_info = await get_target_ssh_info(target_config)
    except TargetExecError as e:
        typer.echo(f"Error: {e}", err=True)
        raise typer.Exit(1) from None
    op_spec = _parse_op_and_shapes(op, shape, dtype)
    config = KernelTraceConfig(
        op_spec=op_spec,
        hardware=hardware,
        num_warmup=num_warmup,
        num_runs=num_runs,
    )
    if not json_output:
        typer.echo(f"Profiling: {op_spec}")
        typer.echo(f"Target: {target_name}")
        typer.echo(f"Hardware: {hardware}")
        typer.echo("")
    result = _trace_on_ssh_target(
        SSHClient, trace_kernel_remote, config, ssh_info, no_cache
    )
    _output_result(result, json_output, verbose, from_cache=False)


def _trace_on_ssh_target(SSHClient: type[SSHClientType], trace_kernel_remote: Callable[..., TraceExecutionResult], config: KernelTraceConfig, ssh_info: TargetSSHInfo, no_cache: bool) -> KernelTraceResult:
    assert SSHClient is not None, "SSHClient class must not be None"
    assert config is not None, "config must not be None"
    assert ssh_info is not None, "ssh_info must not be None"
    ssh_target = f"{ssh_info.user}@{ssh_info.host}:{ssh_info.port}"
    ssh_client = SSHClient(
        ssh_target,
        str(ssh_info.key_path),
    )
    try:
        exec_result = trace_kernel_remote(config, ssh_client)
        result = exec_result.result
        if not result.error and not no_cache:
            store_baseline(
                result,
                exec_result.pytorch_version,
                exec_result.runtime_version,
                exec_result.gpu_arch,
            )
    finally:
        ssh_client.close()
    return result


async def _run_on_workspace(
    op: str,
    shape: list[str],
    dtype: str,
    hardware: str | None,
    workspace_name: str,
    num_warmup: int,
    num_runs: int,
    no_cache: bool,
    json_output: bool,
    verbose: bool,
    timeout: int,
) -> None:
    """Run baseline trace on a workspace."""
    from wafer.core.tools.dispatch_baseline.analyzer import parse_trace_output
    from wafer.core.tools.dispatch_baseline.codegen import generate_trace_script
    from wafer.core.tools.dispatch_baseline.executor import _add_roofline_analysis

    op_spec = _parse_op_and_shapes(op, shape, dtype)
    if hardware is None:
        hardware = _detect_hardware_from_workspace(workspace_name, json_output)
    config = KernelTraceConfig(
        op_spec=op_spec,
        hardware=hardware,
        num_warmup=num_warmup,
        num_runs=num_runs,
    )
    if not json_output:
        typer.echo(f"Profiling: {op_spec}")
        typer.echo(f"Workspace: {workspace_name}")
        typer.echo(f"Hardware: {hardware}")
        typer.echo("")
    script = generate_trace_script(config)
    output = _execute_on_workspace(workspace_name, script, timeout)
    parsed = parse_trace_output(output, op_spec, hardware)
    result = _add_roofline_analysis(parsed.result, config)
    if not result.error and not no_cache:
        store_baseline(
            result,
            parsed.pytorch_version,
            parsed.runtime_version,
            parsed.gpu_arch,
        )
    _output_result(result, json_output, verbose, from_cache=False)


def _output_result(result: KernelTraceResult, json_output: bool, verbose: bool, from_cache: bool = False) -> None:
    """Output trace result in the requested format."""
    if json_output:
        output = {
            "op": str(result.op_spec),
            "hardware": result.hardware,
            "total_duration_us": result.total_duration_us,
            "from_cache": from_cache,
            "kernels": [
                {
                    "name": k.name,
                    "duration_us": k.duration_us,
                }
                for k in result.kernels
            ],
            "primary_kernel": {
                "name": result.primary_kernel.name,
                "duration_us": result.primary_kernel.duration_us,
            }
            if result.primary_kernel
            else None,
            "roofline": {
                "achieved_tflops": result.roofline.achieved_tflops,
                "achieved_memory_bw_tbps": result.roofline.achieved_memory_bw_tbps,
                "compute_pct_of_peak": result.roofline.compute_pct_of_peak,
                "memory_bw_pct_of_peak": result.roofline.memory_bw_pct_of_peak,
                "bottleneck": result.roofline.bottleneck,
            }
            if result.roofline
            else None,
            "error": result.error,
        }
        from .output import json_response
        eval_status = "ok" if not result.error else "error"
        typer.echo(json_response(data=output, status=eval_status))
    else:
        if result.error:
            typer.echo(f"Error: {result.error}", err=True)
            if verbose and result.raw_output:
                typer.echo("\nRaw output:")
                typer.echo(result.raw_output)
            raise typer.Exit(1)
        if from_cache:
            typer.echo("(from cache)")
            typer.echo("")
        typer.echo(result.summary())
        if verbose and result.raw_output:
            typer.echo("\n--- Raw Profiler Output ---")
            typer.echo(result.raw_output)


@baseline_app.command("hardware")
def hardware_cmd(
    json_output: bool = typer.Option(
        False,
        "--json",
        "-j",
        help="Output as JSON",
    ),
) -> None:
    """List supported hardware specs for roofline analysis."""
    if json_output:
        from .output import json_response
        output = {
            name: {
                "peak_fp16_tflops": spec.peak_fp16_tflops,
                "peak_fp32_tflops": spec.peak_fp32_tflops,
                "peak_memory_bw_tbps": spec.peak_memory_bw_tbps,
                "peak_fp8_tflops": spec.peak_fp8_tflops,
                "peak_int8_tops": spec.peak_int8_tops,
            }
            for name, spec in HARDWARE_SPECS.items()
        }
        typer.echo(json_response(data={"hardware": output}))
    else:
        typer.echo("Supported Hardware for Roofline Analysis")
        typer.echo("=" * 60)
        typer.echo("")
        typer.echo(f"{'Name':<12} {'FP16 TFLOPS':<14} {'FP32 TFLOPS':<14} {'Mem BW (TB/s)':<14}")
        typer.echo("-" * 60)
        for name, spec in sorted(HARDWARE_SPECS.items()):
            typer.echo(
                f"{name:<12} {spec.peak_fp16_tflops:<14.1f} {spec.peak_fp32_tflops:<14.1f} {spec.peak_memory_bw_tbps:<14.2f}"
            )
        typer.echo("")
        typer.echo("Note: FP16 TFLOPS shown without sparsity for most GPUs.")
        typer.echo("Use --json for complete specifications.")
