# Wrought

**Engineering and operations control system by [FluxForge AI](https://github.com/fluxforgeai).**

Wrought is a full-lifecycle control system for AI-assisted engineering and production operations — standardizing feature delivery, incident response, RCA, and governance into repeatable workflows with durable artifacts.

*If it ain't Wrought, it's fraught.*

Full package coming soon.
