"""Wrought by FluxForge AI — Engineering and operations control system."""

__version__ = "0.0.1"
