from datetime import datetime
from typing import Dict, List

import pandas as pd
from pydantic import BaseModel

from journey.database.models import ShipmentJorneySimiInquilino, ShipmentJorneySimiPropietario
from journey.database.querys import select_record_shipment_inquilino, select_record_shipment_propietario, upsert_record_shipment_inquilino, upsert_record_shipment_propietario
from journey.shipments_by_template_for_gmail import (
    send_email_month_1,
    send_email_month_2,
    send_email_month_3,
    send_email_month_4,
    send_template_inq_email_month_1,
    send_template_inq_email_month_3,
    send_template_inq_email_month_5,
    send_template_inq_email_month_6,
    send_template_inq_email_month_7,
    send_template_inq_email_month_9,
    send_template_inq_email_month_12,
)
from journey.shipments_by_template_for_meta import sends_template_inq_wpp_month_2, sends_template_inq_wpp_month_4, sends_template_inq_wpp_month_8, sends_template_inq_wpp_month_10, sends_template_wpp_1, sends_template_wpp_2
from journey.templates_x_month import TemplatesInquilino, TemplatesPropietario


class DataSendAudiencia(BaseModel):
    email: str
    phone: str


def enviar_audiencia_propietario(template: str, data: DataSendAudiencia) -> Dict:
    print(f"Enviando audiencia para: {data.email=}")

    match template:
        case "template_email_1":
            send_email_month_1(email=data.email)
            ...

        case "template_email_2":
            send_email_month_2(email=data.email)
            ...

        case "template_email_3":
            send_email_month_3(email=data.email)
            ...

        case "template_email_4":
            send_email_month_4(email=data.email)
            ...

        case "sends_template_wpp_1":
            sends_template_wpp_1(phone=data.phone)
            ...

        case "sends_template_wpp_2":
            sends_template_wpp_2(phone=data.phone)
            ...

    return {"msj": "", "status": True}


def registrar_audiencia_propietario_en_db(records_audiencias: List[Dict], month: int):
    print(f"Registrando audiencias del {month=}")
    print(f"Cantidad de audiencias para registrar {len(records_audiencias)}")

    for record in records_audiencias:
        # Normalizar NaN / tipos pandas
        contrato = record.get("NoContrato")
        email = record.get("EmailPro")
        phone = record.get("CelPro1")
        fecha_inicio = record.get("InicioContrato")

        contrato = None if pd.isna(contrato) else int(contrato)
        email = None if pd.isna(email) else str(email).strip()
        phone = None if pd.isna(phone) else str(phone).strip()
        fecha_inicio = None if pd.isna(fecha_inicio) else fecha_inicio

        if fecha_inicio is not None and hasattr(fecha_inicio, "to_pydatetime"):
            fecha_inicio = fecha_inicio.to_pydatetime()

        result_record = select_record_shipment_propietario(contrato=record.get("NoContrato"))


        if result_record is None:
            month_ = 1
            template_ = TemplatesPropietario.get(month=month_)
            history_templates = template_



            record_ = {
                "contrato": contrato,
                "email": email,
                "phone": phone,
                "last_template_sent": template_,
                "month": month_,
                "list_of_templates_sent": history_templates,  # lista Python (JSON)
                "fecha_inicio": fecha_inicio,
            }


        else:
            month_ = result_record.month + 1
            month_ = month_ if month_ in range(1, 13) else 1
            template_ = TemplatesPropietario.get(month=month_)
            history_templates = result_record.list_of_templates_sent.copy()

            if history_templates:
                history_templates.extend(template_)
                history_templates = list(set(history_templates))
            else:
                history_templates = template_.copy()

            record_ = {
                "contrato": contrato,
                "email": email,
                "phone": phone,
                "last_template_sent": template_ if template_ else None,
                "month": month_,
                "list_of_templates_sent": history_templates,  # lista Python (JSON)
                "fecha_inicio": fecha_inicio,
            }

        if template_:
            if email and phone:
                print(f"{template_[0]=}")
                data = DataSendAudiencia(email=email, phone=phone)
                result_send = enviar_audiencia_propietario(template=template_[0], data=data)  # hace el envio email o wpp
                #result_send= {"status": True}
                if result_send.get("status"):
                    data_ = ShipmentJorneySimiPropietario(**record_)
                    upsert_record_shipment_propietario(data_)
        else:
            record_.update({"last_template_sent": None})
            data_ = ShipmentJorneySimiPropietario(**record_)
            upsert_record_shipment_propietario(data_)




def ejecutar_audiencia_propietario(data: pd.DataFrame):
    data["InicioContrato"] = pd.to_datetime(data["InicioContrato"], errors="coerce")
    data["month_InicioContrato"] = data["InicioContrato"].dt.month

    groups = list(data.groupby(by="month_InicioContrato"))
    current_month = datetime.now().month - 1

    if current_month >= 1:
        print("Enviar audiecnias de enero")
        records_audiencias = groups[0][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=1)

    if current_month >= 2:
        print("Enviar audiecnias de febrero")
        records_audiencias = groups[1][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=2)

    if current_month >= 3:
        print("Enviar audiecnias de marzo")
        records_audiencias = groups[2][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=3)

    if current_month >= 4:
        print("Enviar audiecnias de abril")
        records_audiencias = groups[3][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=4)

    if current_month >= 5:
        print("Enviar audiecnias de mayo")
        records_audiencias = groups[4][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=5)

    if current_month >= 6:
        print("Enviar audiecnias de junio")
        records_audiencias = groups[5][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=6)

    if current_month >= 7:
        print("Enviar audiecnias de julio")
        records_audiencias = groups[6][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=7)

    if current_month >= 8:
        print("Enviar audiecnias de agosto")
        records_audiencias = groups[7][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=8)

    if current_month >= 9:
        print("Enviar audiecnias de septiembre")
        records_audiencias = groups[8][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=9)

    if current_month >= 10:
        print("Enviar audiecnias de octubre")
        records_audiencias = groups[9][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=10)

    if current_month >= 11:
        print("Enviar audiecnias de noviembre")
        records_audiencias = groups[10][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=11)

    if current_month >= 12:
        print("Enviar audiecnias de diciembre")
        records_audiencias = groups[11][1].to_dict(orient="records")
        registrar_audiencia_propietario_en_db(records_audiencias=records_audiencias, month=12)


# ===============================================
def enviar_audiencia_inquilino(template: str, data: DataSendAudiencia) -> Dict:
    print(f"Enviando audiencia para: {data.email=}")

    match template:
        case "template_inq_email_month_1":
            send_template_inq_email_month_1(email=data.email)
            ...

        case "template_inq_wpp_month_2":
            sends_template_inq_wpp_month_2(phone=data.phone)
            ...

        case "template_inq_email_month_3":
            send_template_inq_email_month_3(email=data.email)
            ...

        case "template_inq_wpp_month_4":
            sends_template_inq_wpp_month_4(phone=data.phone)
            ...

        case "template_inq_email_month_5":
            send_template_inq_email_month_5(email=data.email)
            ...

        case "template_inq_email_month_6":
            send_template_inq_email_month_6(email=data.email)
            ...

        case "template_inq_email_month_7":
            send_template_inq_email_month_7(email=data.email)
            ...

        case "template_inq_wpp_month_8":
            sends_template_inq_wpp_month_8(phone=data.phone)
            ...

        case "template_inq_email_month_9":
            send_template_inq_email_month_9(email=data.email)
            ...

        case "template_inq_wpp_month_10":
            sends_template_inq_wpp_month_10(phone=data.phone)
            ...

        case "template_inq_email_month_12":
            send_template_inq_email_month_12(email=data.email)
            ...

    return {"msj": "", "status": True}


def registrar_audiencia_inquilino_en_db(records_audiencias: List[Dict], month: int):
    print(f"Registrando audiencias del {month=}")
    print(f"Cantidad de audiencias para registrar {len(records_audiencias)}")

    for record in records_audiencias:
        # Normalizar NaN / tipos pandas
        contrato = record.get("NoContrato")
        email = record.get("EmailArre")
        phone = record.get("CelArre1")
        fecha_inicio = record.get("InicioContrato")

        contrato = None if pd.isna(contrato) else int(contrato)
        email = None if pd.isna(email) else str(email).strip()
        phone = None if pd.isna(phone) else str(phone).strip()
        fecha_inicio = None if pd.isna(fecha_inicio) else fecha_inicio

        if fecha_inicio is not None and hasattr(fecha_inicio, "to_pydatetime"):
            fecha_inicio = fecha_inicio.to_pydatetime()

        result_record = select_record_shipment_inquilino(contrato=record.get("NoContrato"))

        if result_record is None:
            month_ = 1
            template_ = TemplatesInquilino.get(month=month_)
            history_templates = template_

            record_ = {
                "contrato": contrato,
                "email": email,
                "phone": phone,
                "last_template_sent": template_,
                "month": month_,
                "list_of_templates_sent": history_templates,  # lista Python (JSON)
                "fecha_inicio": fecha_inicio,
            }

        else:
            month_ = result_record.month + 1
            month_ = month_ if month_ in range(1, 13) else 1
            template_ = TemplatesInquilino.get(month=month_)
            history_templates = result_record.list_of_templates_sent.copy()

            if history_templates:
                history_templates.extend(template_)
                history_templates = list(set(history_templates))
            else:
                history_templates = template_.copy()

            record_ = {
                "contrato": contrato,
                "email": email,
                "phone": phone,
                "last_template_sent": template_ if template_ else None,
                "month": month_,
                "list_of_templates_sent": history_templates,  # lista Python (JSON)
                "fecha_inicio": fecha_inicio,
            }

        if template_ :
            if email and phone:
                data = DataSendAudiencia(email=email, phone=phone)
                result_send = enviar_audiencia_inquilino(template=template_[0], data=data)  # hace el envio email o wpp
                #result_send= {"status": True}
                if result_send.get("status"):
                    data_ = ShipmentJorneySimiInquilino(**record_)
                    upsert_record_shipment_inquilino(data_)

        else:
            record_.update({"last_template_sent": None})
            data_ = ShipmentJorneySimiPropietario(**record_)
            upsert_record_shipment_propietario(data_)



def ejecutar_audiencia_inquilino(data: pd.DataFrame):
    data["InicioContrato"] = pd.to_datetime(data["InicioContrato"], errors="coerce")
    data["month_InicioContrato"] = data["InicioContrato"].dt.month

    groups = list(data.groupby(by="month_InicioContrato"))
    current_month = datetime.now().month - 1

    if current_month >= 1:
        print("Enviar audiecnias de enero")
        records_audiencias = groups[0][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=1)

    if current_month >= 2:
        print("Enviar audiecnias de febrero")
        records_audiencias = groups[1][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=2)

    if current_month >= 3:
        print("Enviar audiecnias de marzo")
        records_audiencias = groups[2][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=3)

    if current_month >= 4:
        print("Enviar audiecnias de abril")
        records_audiencias = groups[3][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=4)

    if current_month >= 5:
        print("Enviar audiecnias de mayo")
        records_audiencias = groups[4][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=5)

    if current_month >= 6:
        print("Enviar audiecnias de junio")
        records_audiencias = groups[5][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=6)

    if current_month >= 7:
        print("Enviar audiecnias de julio")
        records_audiencias = groups[6][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=7)

    if current_month >= 8:
        print("Enviar audiecnias de agosto")
        records_audiencias = groups[7][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=8)

    if current_month >= 9:
        print("Enviar audiecnias de septiembre")
        records_audiencias = groups[8][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=9)

    if current_month >= 10:
        print("Enviar audiecnias de octubre")
        records_audiencias = groups[9][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=10)

    if current_month >= 11:
        print("Enviar audiecnias de noviembre")
        records_audiencias = groups[10][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=11)

    if current_month >= 12:
        print("Enviar audiecnias de diciembre")
        records_audiencias = groups[11][1].to_dict(orient="records")
        registrar_audiencia_inquilino_en_db(records_audiencias=records_audiencias, month=12)
