import os
from typing import List

from pydantic import BaseModel, Field


class Auth(BaseModel):
    username: str = os.getenv("LIVIN_USERNAME")
    password: str = os.getenv("LIVIN_PASSWORD")


class DataCompany(BaseModel):
    CompaniaID: str = Field(..., example="Livin Inmobiliaria")
    NombreCompania: str = Field(..., example="D9897081-01CF-4F05-8FA5-3EAEC9F30715")


class ResponseGetToken(BaseModel):
    token: str = Field(..., examples=["3743909|Kets0enTYSMfeaSdedArBAFFAVIsEyg3AZUhqKYz495fcd13"])
    expiration: str = Field(..., examples=["2026-02-19T20:39:54.306889Z"])
    companies: List[DataCompany] = Field(...)


class ResquestFetchPropietario(BaseModel):
    id_cedula: str = Field(..., example="900225208")
    month: int = Field(..., example=1)
    year: int = Field(..., example=2025)


class ResquestFetchInquilino(BaseModel):
    id_cedula: str = Field(..., example="811012353")
    month: int = Field(..., example=1)
    year: int = Field(..., example=2025)
