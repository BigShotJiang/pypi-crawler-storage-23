from datetime import datetime

import httpx
from loguru import logger

from journey.api.models import Auth, ResponseGetToken, ResquestFetchInquilino, ResquestFetchPropietario


def convert_date_iso_to_utc(date_str):
    """Convierte la fecha ISO 8601 en un formato UTC."""
    date_obj = datetime.fromisoformat(date_str.replace("Z", ""))
    return date_obj


class Simi:
    def __init__(self, auth: Auth):
        self.auth = auth
        self.headers = {
            "Content-Type": "application/json",
        }
        timeout = httpx.Timeout(60.0, connect=20.0)
        self._client = httpx.Client(timeout=timeout, headers=self.headers)
        self.expiration_token = None
        self.token = None

    def get_token(self) -> ResponseGetToken:
        """Obtiene un nuevo token de la API."""
        url_get_token = "https://pid1.siminmobiliarias.com/api/integraciones/token"

        # No usar el contexto `with` aquí para que el cliente no se cierre
        payload = self.auth.model_dump(mode="json")
        response = self._client.post(url=url_get_token, json=payload)
        response.raise_for_status()

        logger.info(f"{response.status_code=}")

        result = ResponseGetToken(**response.json())

        # Almacenar la fecha de expiración y el token
        self.expiration_token = result.expiration
        self.token = result.token

        # Actualizar el encabezado con el nuevo token
        self.headers.update({"Authorization": f"Bearer {self.token}", "idEmpresa": result.companies[0].CompaniaID})

        # Actualizar los headers del cliente
        self._client.headers.update(self.headers)

        return result

    def valid_token(self):
        """Verifica si el token ha expirado y lo actualiza si es necesario."""
        if not self.expiration_token or not self.token:
            # Si no hay token o la fecha de expiración, obtenemos un nuevo token
            self.get_token()
            return

        # Convertir la fecha de expiración a un objeto datetime
        date_expire = convert_date_iso_to_utc(self.expiration_token)
        now = datetime.now()

        # Comparar si el token ha expirado
        if date_expire <= now:
            logger.info("El token ha expirado. Obteniendo un nuevo token.")
            self.get_token()

    def fetch_contratos(self):
        """Obtiene la información de los propietarios."""
        self.valid_token()

        url_fetch_contratos = "https://pid1.siminmobiliarias.com/api/integraciones/353"

        # Nuevamente, no usar el contexto `with` para mantener el cliente abierto
        response = self._client.post(url=url_fetch_contratos)
        response.raise_for_status()

        logger.info(f"{response.status_code=}")

        return response.json()

    def fetch_propietario(self, data: ResquestFetchPropietario):
        """Obtiene la información de los propietarios con los parámetros proporcionados."""
        self.valid_token()

        url_fetch_propietarios = "https://pid1.siminmobiliarias.com/api/integraciones/358"

        body = {
            "CRITERIA": {},  # Aquí podrías incluir filtros adicionales si lo necesitas
            "OPERATION": "READ",
            "PAYLOAD": {"IdCedula": data.id_cedula, "Month": data.month, "Year": data.year},
        }

        # Realizar la solicitud POST con los headers y el cuerpo adecuado
        response = self._client.post(url=url_fetch_propietarios, json=body)

        # Verificar que la respuesta fue exitosa
        response.raise_for_status()

        # Log de la respuesta
        logger.info(f"Status Code: {response.status_code}")

        # Retornar la respuesta en formato JSON
        return response.json()

    def fetch_inquilino(self, data: ResquestFetchInquilino):
        """Obtiene la información de los inquilinos con los parámetros proporcionados."""
        self.valid_token()

        url_fetch_propietarios = "https://pid1.siminmobiliarias.com/api/integraciones/357"

        body = {
            "CRITERIA": {},
            "OPERATION": "READ",
            "PAYLOAD": {"IdCedula": data.id_cedula, "Month": data.month, "Year": data.year},
        }

        # Realizar la solicitud POST con los headers y el cuerpo adecuado
        response = self._client.post(url=url_fetch_propietarios, json=body)

        # Verificar que la respuesta fue exitosa
        response.raise_for_status()

        # Log de la respuesta
        logger.info(f"Status Code: {response.status_code}")

        # Retornar la respuesta en formato JSON
        return response.json()
