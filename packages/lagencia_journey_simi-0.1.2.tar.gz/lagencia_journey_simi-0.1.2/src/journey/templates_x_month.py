from typing import List


class TemplatesPropietario:
    month_1: List[str] = ["template_email_1"]
    month_2: List[str] = []
    month_3: List[str] = ["template_email_2"]
    month_4: List[str] = []
    month_5: List[str] = ["template_email_3"]
    month_6: List[str] = []
    month_7: List[str] = ["template_email_4"]
    month_8: List[str] = []
    month_9: List[str] = ["sends_template_wpp_1"]
    month_10: List[str] = []
    month_11: List[str] = ["sends_template_wpp_2"]
    month_12: List[str] = []

    @classmethod
    def get(cls, month: int) -> List[str]:
        return getattr(cls, f"month_{month}")


class TemplatesInquilino:
    month_1: List[str] = ["template_inq_email_month_1"]
    month_2: List[str] = ["template_inq_wpp_month_2"]
    month_3: List[str] = ["template_inq_email_month_3"]
    month_4: List[str] = ["template_inq_wpp_month_4"]
    month_5: List[str] = ["template_inq_email_month_5"]
    month_6: List[str] = ["template_inq_email_month_6"]
    month_7: List[str] = ["template_inq_email_month_7"]
    month_8: List[str] = ["template_inq_wpp_month_8"]
    month_9: List[str] = ["template_inq_email_month_9"]
    month_10: List[str] = ["template_inq_wpp_month_10"]
    month_11: List[str] = []
    month_12: List[str] = ["template_inq_email_month_12"]

    @classmethod
    def get(cls, month: int) -> List[str]:
        return getattr(cls, f"month_{month}")
