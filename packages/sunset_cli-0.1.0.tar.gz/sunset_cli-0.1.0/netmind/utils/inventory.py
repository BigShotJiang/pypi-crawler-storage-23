"""Device inventory loader.

Reads a YAML inventory file and returns device definitions with
full interface, OSPF, and topology data for production use.

Inventory format (inventory.yml):

    devices:
      - id: R1
        host: 192.168.1.160
        username: admin
        password: cisco
        device_type: cisco_ios
        port: 22
        enable_secret: null
        role: router
        site: DC1
        interfaces:
          - name: GigabitEthernet0/0
            ip: 10.10.10.1
            mask: 255.255.255.0
            description: Link to R2
            connected_to: R2:GigabitEthernet0/0
          - name: Loopback0
            ip: 1.1.1.1
            mask: 255.255.255.255
        ospf:
          process_id: 1
          router_id: 1.1.1.1
          areas:
            - id: 0
              networks:
                - network: 10.10.10.0
                  wildcard: 0.0.0.255
          passive_interfaces:
            - Loopback0

    links:
      - endpoints: [R1:GigabitEthernet0/0, R2:GigabitEthernet0/0]
        subnet: 10.10.10.0/24
        description: R1-R2 backbone

Environment variable substitution is supported:
    password: ${DEVICE_PASSWORD}
"""

import os
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

from netmind.core.topology import (
    InterfaceInfo,
    NetworkTopology,
    OSPFArea,
    OSPFConfig,
    TopologyLink,
    TopologyNode,
)
from netmind.models import DeviceType
from netmind.utils.logger import get_logger

logger = get_logger("utils.inventory")

# Default inventory file paths (checked in order)
DEFAULT_INVENTORY_PATHS = [
    "inventory.yml",
    "inventory.yaml",
    "devices.yml",
    "devices.yaml",
]

# Map of string names to DeviceType enum values
DEVICE_TYPE_MAP = {
    "cisco_ios": DeviceType.CISCO_IOS,
    "cisco_xe": DeviceType.CISCO_XE,
    "cisco_nxos": DeviceType.CISCO_NXOS,
    "juniper_junos": DeviceType.JUNIPER_JUNOS,
    "arista_eos": DeviceType.ARISTA_EOS,
}


class InventoryError(Exception):
    """Raised when inventory loading or validation fails."""


# ── Public API ───────────────────────────────────────────────────────


def load_inventory(
    path: Optional[str] = None,
) -> List[Dict[str, Any]]:
    """Load device definitions from a YAML inventory file.

    Args:
        path: Explicit path to inventory file. If None, searches
              default locations (inventory.yml, devices.yml, etc.).

    Returns:
        List of device dicts with keys:
            device_id, host, username, password, device_type, port,
            enable_secret

    Raises:
        InventoryError: If the file is missing, malformed, or has invalid entries.
    """
    inventory_path = _resolve_path(path)
    if inventory_path is None:
        if path is not None:
            raise InventoryError(f"Inventory file not found: {path}")
        return []

    logger.info("Loading inventory from %s", inventory_path)

    raw = _load_yaml(inventory_path)
    if raw is None:
        return []

    if not isinstance(raw, dict) or "devices" not in raw:
        raise InventoryError(
            f"Inventory file must have a top-level 'devices' key. "
            f"Got: {list(raw.keys()) if isinstance(raw, dict) else type(raw).__name__}"
        )

    devices_raw = raw["devices"]
    if not isinstance(devices_raw, list):
        raise InventoryError("'devices' must be a list of device definitions")

    devices = []
    for i, entry in enumerate(devices_raw):
        try:
            device = _validate_device_entry(entry, i)
            devices.append(device)
        except InventoryError as e:
            raise InventoryError(f"Device #{i + 1}: {e}") from e

    logger.info("Loaded %d device(s) from inventory", len(devices))
    return devices


def load_full_inventory(
    path: Optional[str] = None,
) -> Tuple[List[Dict[str, Any]], NetworkTopology]:
    """Load devices AND build a full topology from inventory.

    This is the production entry point — it returns both the device
    connection dicts (for DeviceManager) and a populated NetworkTopology
    with interfaces, OSPF config, and links.

    Args:
        path: Explicit path to inventory file.

    Returns:
        (device_dicts, topology) tuple.

    Raises:
        InventoryError: On invalid inventory.
    """
    inventory_path = _resolve_path(path)
    if inventory_path is None:
        if path is not None:
            raise InventoryError(f"Inventory file not found: {path}")
        return [], NetworkTopology()

    raw = _load_yaml(inventory_path)
    if raw is None:
        return [], NetworkTopology()

    if not isinstance(raw, dict) or "devices" not in raw:
        raise InventoryError(
            f"Inventory file must have a top-level 'devices' key. "
            f"Got: {list(raw.keys()) if isinstance(raw, dict) else type(raw).__name__}"
        )

    devices_raw = raw["devices"]
    if not isinstance(devices_raw, list):
        raise InventoryError("'devices' must be a list of device definitions")

    # Parse devices for connection + topology
    device_dicts: List[Dict[str, Any]] = []
    topology_nodes: List[TopologyNode] = []

    for i, entry in enumerate(devices_raw):
        try:
            dev_dict = _validate_device_entry(entry, i)
            device_dicts.append(dev_dict)

            node = _parse_topology_node(entry, i)
            topology_nodes.append(node)
        except InventoryError as e:
            raise InventoryError(f"Device #{i + 1}: {e}") from e

    # Parse explicit links
    explicit_links = _parse_links(raw.get("links", []))

    # Build topology
    topology = NetworkTopology()
    topology.build_from_inventory(topology_nodes, explicit_links)

    logger.info(
        "Full inventory loaded: %d devices, %d nodes, %d links",
        len(device_dicts),
        topology.node_count,
        topology.link_count,
    )

    return device_dicts, topology


def find_inventory_file() -> Optional[Path]:
    """Find the first existing inventory file from default paths."""
    return _resolve_path(None)


def save_device_to_inventory(
    device_data: Dict[str, Any],
    path: Optional[str] = None,
) -> Path:
    """Append a device entry to the inventory YAML file.

    If the file does not exist, creates it with the standard structure.
    If it exists, loads the current content, appends the new device,
    and writes it back.

    Args:
        device_data: Dict with keys: id, host, username, password,
                     device_type, port, enable_secret, legacy_ssh.
        path: Explicit inventory file path. If None, uses the first
              default path or creates inventory.yml.

    Returns:
        The Path of the file written to.

    Raises:
        InventoryError: If the existing file is malformed.
    """
    if path is not None:
        inventory_path = Path(path)
    else:
        found = _resolve_path(None)
        inventory_path = found if found is not None else Path(DEFAULT_INVENTORY_PATHS[0])

    # Load existing content or start fresh
    if inventory_path.exists():
        raw = _load_yaml(inventory_path)
        if raw is None:
            raw = {"devices": []}
        elif not isinstance(raw, dict) or "devices" not in raw:
            raise InventoryError(
                "Inventory file must have a top-level 'devices' key."
            )
        if not isinstance(raw["devices"], list):
            raw["devices"] = []
    else:
        raw = {"devices": []}

    # Build entry in canonical key order
    entry: Dict[str, Any] = {
        "id": device_data["id"],
        "host": device_data["host"],
        "username": device_data["username"],
        "password": device_data["password"],
        "device_type": device_data.get("device_type", "cisco_ios"),
    }
    if device_data.get("enable_secret"):
        entry["enable_secret"] = device_data["enable_secret"]
    entry["port"] = device_data.get("port", 22)
    if device_data.get("legacy_ssh"):
        entry["legacy_ssh"] = True

    raw["devices"].append(entry)

    with open(inventory_path, "w") as f:
        f.write("# Sunset Device Inventory\n")
        yaml.safe_dump(raw, f, default_flow_style=False, sort_keys=False)

    logger.info("Saved device '%s' to inventory: %s", device_data["id"], inventory_path)
    return inventory_path


# ── YAML helpers ─────────────────────────────────────────────────────


def _load_yaml(path: Path) -> Optional[Any]:
    """Load and return parsed YAML content."""
    try:
        with open(path) as f:
            return yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise InventoryError(f"Invalid YAML in {path}: {e}") from e


def _resolve_path(path: Optional[str]) -> Optional[Path]:
    """Resolve the inventory file path."""
    if path is not None:
        p = Path(path)
        return p if p.exists() else None

    for default in DEFAULT_INVENTORY_PATHS:
        p = Path(default)
        if p.exists():
            return p

    return None


# ── Device validation (connection-level) ─────────────────────────────


def _validate_device_entry(entry: dict, index: int) -> Dict[str, Any]:
    """Validate and normalize a single device entry for connection."""
    if not isinstance(entry, dict):
        raise InventoryError(f"Expected a dict, got {type(entry).__name__}")

    device_id = entry.get("id")
    if not device_id:
        raise InventoryError("Missing required field: 'id'")

    host = _expand_env(entry.get("host", ""))
    if not host:
        raise InventoryError("Missing required field: 'host'")

    username = _expand_env(entry.get("username", ""))
    if not username:
        raise InventoryError("Missing required field: 'username'")

    password = _expand_env(entry.get("password", ""))
    if not password:
        raise InventoryError("Missing required field: 'password'")

    port = entry.get("port", 22)
    if not isinstance(port, int) or port < 1 or port > 65535:
        raise InventoryError(f"Invalid port: {port}")

    device_type_str = entry.get("device_type", "cisco_ios")
    device_type = DEVICE_TYPE_MAP.get(device_type_str)
    if device_type is None:
        valid = ", ".join(DEVICE_TYPE_MAP.keys())
        raise InventoryError(
            f"Unknown device_type: '{device_type_str}'. Valid: {valid}"
        )

    enable_secret = _expand_env(entry.get("enable_secret") or "")

    # SSH options — for legacy devices that need non-default algorithms
    ssh_options = _parse_ssh_options(entry)

    return {
        "device_id": str(device_id),
        "host": host,
        "username": username,
        "password": password,
        "device_type": device_type,
        "port": port,
        "enable_secret": enable_secret or None,
        "ssh_options": ssh_options,
    }


# ── SSH options parsing ───────────────────────────────────────────────

# Legacy algorithms commonly needed for older IOS devices
_LEGACY_SSH_ALGORITHMS = {
    "kex": ["diffie-hellman-group14-sha1", "diffie-hellman-group1-sha1"],
    "pubkeys": ["ssh-rsa", "ssh-dss"],
    "keys": ["ssh-rsa", "ssh-dss"],
}


def _parse_ssh_options(entry: dict) -> Dict[str, Any]:
    """Parse SSH options from inventory entry.

    Supports two styles:

    1. Shorthand — `legacy_ssh: true` enables all legacy algorithms:
        - id: R1
          legacy_ssh: true

    2. Explicit — `ssh_options:` dict with Netmiko/Paramiko kwargs:
        - id: R1
          ssh_options:
            disabled_algorithms:
              pubkeys: []
            conn_timeout: 30

    The `legacy_ssh: true` shorthand translates to Paramiko's
    `disabled_algorithms` override that re-enables old key exchange
    and host key algorithms (diffie-hellman-group14-sha1, ssh-rsa).
    """
    ssh_options: Dict[str, Any] = {}

    # Shorthand: legacy_ssh: true
    if entry.get("legacy_ssh", False):
        # Paramiko >=2.9 disables these by default; we re-enable them
        # by passing an empty disabled_algorithms dict
        ssh_options["disabled_algorithms"] = {"kex": [], "pubkeys": [], "keys": []}
        logger.debug(
            "%s: legacy_ssh enabled — re-allowing legacy algorithms",
            entry.get("id", "?"),
        )

    # Explicit ssh_options dict (overrides/merges with legacy_ssh)
    explicit = entry.get("ssh_options")
    if isinstance(explicit, dict):
        ssh_options.update(explicit)

    return ssh_options


# ── Topology node parsing ────────────────────────────────────────────


def _parse_topology_node(entry: dict, index: int) -> TopologyNode:
    """Parse a device entry into a full TopologyNode with interfaces and OSPF."""
    device_id = str(entry.get("id", f"device-{index}"))
    host = _expand_env(entry.get("host", ""))
    device_type_str = entry.get("device_type", "cisco_ios")

    # Parse interfaces
    interfaces = _parse_interfaces(entry.get("interfaces", []), device_id)

    # Parse OSPF config
    ospf = _parse_ospf(entry.get("ospf"), device_id)

    # Find loopback IP
    loopback_ip = None
    for iface in interfaces:
        if "loopback" in iface.name.lower() and iface.ip:
            loopback_ip = iface.ip
            break

    return TopologyNode(
        device_id=device_id,
        host=host,
        device_type=device_type_str,
        interfaces=interfaces,
        ospf=ospf,
        loopback_ip=loopback_ip,
        role=entry.get("role"),
        site=entry.get("site"),
    )


def _parse_interfaces(
    raw_interfaces: Any, device_id: str
) -> List[InterfaceInfo]:
    """Parse a list of interface definitions."""
    if not raw_interfaces or not isinstance(raw_interfaces, list):
        return []

    interfaces = []
    for i, raw_iface in enumerate(raw_interfaces):
        if not isinstance(raw_iface, dict):
            logger.warning(
                "%s: interface #%d is not a dict, skipping", device_id, i
            )
            continue

        name = raw_iface.get("name", "")
        if not name:
            logger.warning("%s: interface #%d has no name, skipping", device_id, i)
            continue

        ip = raw_iface.get("ip")
        mask = raw_iface.get("mask")
        cidr = raw_iface.get("cidr")

        # Convert mask to CIDR if needed
        if mask and cidr is None:
            cidr = NetworkTopology.mask_to_cidr(mask)

        iface = InterfaceInfo(
            name=name,
            ip=ip,
            mask=mask,
            cidr=cidr,
            description=raw_iface.get("description"),
            enabled=raw_iface.get("enabled", True),
            connected_to=raw_iface.get("connected_to"),
            vlan=raw_iface.get("vlan"),
            speed=raw_iface.get("speed"),
            duplex=raw_iface.get("duplex"),
            shutdown=raw_iface.get("shutdown", False),
        )
        interfaces.append(iface)

    return interfaces


def _parse_ospf(raw_ospf: Any, device_id: str) -> Optional[OSPFConfig]:
    """Parse OSPF configuration for a device."""
    if not raw_ospf or not isinstance(raw_ospf, dict):
        return None

    process_id = raw_ospf.get("process_id", 1)
    router_id = raw_ospf.get("router_id")

    # Parse areas
    areas = []
    for raw_area in raw_ospf.get("areas", []):
        if not isinstance(raw_area, dict):
            continue

        area_id = raw_area.get("id", raw_area.get("area_id", 0))
        networks = []
        for net in raw_area.get("networks", []):
            if isinstance(net, dict):
                networks.append({
                    "network": net.get("network", ""),
                    "wildcard": net.get("wildcard", "0.0.0.255"),
                })

        areas.append(OSPFArea(
            area_id=int(area_id),
            networks=networks,
        ))

    return OSPFConfig(
        process_id=int(process_id),
        router_id=router_id,
        areas=areas,
        passive_interfaces=raw_ospf.get("passive_interfaces", []),
        default_information_originate=raw_ospf.get(
            "default_information_originate", False
        ),
        redistribute=raw_ospf.get("redistribute", []),
    )


# ── Explicit link parsing ────────────────────────────────────────────


def _parse_links(raw_links: Any) -> List[TopologyLink]:
    """Parse the top-level 'links' section of the inventory."""
    if not raw_links or not isinstance(raw_links, list):
        return []

    links = []
    for i, raw_link in enumerate(raw_links):
        if not isinstance(raw_link, dict):
            logger.warning("Link #%d is not a dict, skipping", i)
            continue

        endpoints = raw_link.get("endpoints", [])
        if len(endpoints) != 2:
            logger.warning(
                "Link #%d: 'endpoints' must have exactly 2 entries, got %d",
                i,
                len(endpoints),
            )
            continue

        src = _parse_endpoint(endpoints[0])
        dst = _parse_endpoint(endpoints[1])
        if src is None or dst is None:
            logger.warning("Link #%d: could not parse endpoints", i)
            continue

        link = TopologyLink(
            source_device=src[0],
            source_interface=src[1],
            target_device=dst[0],
            target_interface=dst[1],
            subnet=raw_link.get("subnet"),
            description=raw_link.get("description"),
            link_type=raw_link.get("link_type", "ethernet"),
            ospf_area=raw_link.get("ospf_area"),
        )
        links.append(link)

    return links


def _parse_endpoint(value: str) -> Optional[Tuple[str, str]]:
    """Parse 'DEVICE:INTERFACE' string."""
    if not isinstance(value, str):
        return None
    if ":" in value:
        parts = value.split(":", 1)
        return (parts[0].strip(), parts[1].strip())
    return (value.strip(), "unknown")


# ── Environment variable expansion ───────────────────────────────────


def _expand_env(value: str) -> str:
    """Expand ${VAR_NAME} environment variable references in a string."""
    if not isinstance(value, str):
        return str(value) if value is not None else ""

    def replacer(match: re.Match) -> str:
        var_name = match.group(1)
        env_val = os.environ.get(var_name)
        if env_val is None:
            logger.warning(
                "Environment variable '%s' not set (used in inventory)",
                var_name,
            )
            return match.group(0)
        return env_val

    return re.sub(r"\$\{(\w+)\}", replacer, value)
