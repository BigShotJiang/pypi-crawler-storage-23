"""Network auto-discovery module.

SSHes into connected devices and discovers:
  - Interfaces (name, IP, mask, status)
  - OSPF configuration (process ID, router-id, areas, networks)
  - CDP/LLDP neighbors (to build topology links automatically)

The discovery results are merged into the topology model so Claude
can reason about the network without the user hand-writing interface data.
"""

import re
from typing import Any, Dict, List, Optional, Tuple

from netmind.core.device_connection import DeviceConnection
from netmind.core.topology import (
    InterfaceInfo,
    NetworkTopology,
    OSPFArea,
    OSPFConfig,
    TopologyLink,
    TopologyNode,
)
from netmind.utils.logger import get_logger
from netmind.utils.parsers import parse_show_ip_interface_brief

logger = get_logger("core.discovery")


# ── Public API ───────────────────────────────────────────────────────


class DiscoveryResult:
    """Results from discovering a single device."""

    def __init__(self, device_id: str) -> None:
        self.device_id = device_id
        self.interfaces: List[InterfaceInfo] = []
        self.ospf: Optional[OSPFConfig] = None
        self.cdp_neighbors: List[Dict[str, str]] = []
        self.lldp_neighbors: List[Dict[str, str]] = []
        self.errors: List[str] = []
        self.success = False

    @property
    def summary(self) -> str:
        parts = [f"{self.device_id}:"]
        parts.append(f"{len(self.interfaces)} interfaces")
        if self.ospf:
            parts.append(f"OSPF pid:{self.ospf.process_id}")
        cdp_count = len(self.cdp_neighbors) + len(self.lldp_neighbors)
        if cdp_count:
            parts.append(f"{cdp_count} neighbors")
        if self.errors:
            parts.append(f"{len(self.errors)} errors")
        return " | ".join(parts)


def discover_device(conn: DeviceConnection) -> DiscoveryResult:
    """Run full discovery on a single connected device.

    Discovers interfaces, OSPF config, and CDP/LLDP neighbors.
    Each phase is independent — a failure in one doesn't block others.

    Args:
        conn: An active DeviceConnection.

    Returns:
        DiscoveryResult with all discovered data.
    """
    device_id = conn.device.device_id
    result = DiscoveryResult(device_id)
    logger.info("Starting discovery on %s", device_id)

    # Phase 1: Interfaces
    try:
        result.interfaces = _discover_interfaces(conn)
        logger.info(
            "%s: discovered %d interfaces", device_id, len(result.interfaces)
        )
    except Exception as e:
        msg = f"Interface discovery failed: {e}"
        result.errors.append(msg)
        logger.warning("%s: %s", device_id, msg)

    # Phase 2: OSPF
    try:
        result.ospf = _discover_ospf(conn)
        if result.ospf:
            logger.info(
                "%s: OSPF pid:%d, rid:%s, %d areas",
                device_id,
                result.ospf.process_id,
                result.ospf.router_id or "auto",
                len(result.ospf.areas),
            )
    except Exception as e:
        msg = f"OSPF discovery failed: {e}"
        result.errors.append(msg)
        logger.warning("%s: %s", device_id, msg)

    # Phase 3: CDP neighbors
    try:
        result.cdp_neighbors = _discover_cdp_neighbors(conn)
        logger.info(
            "%s: discovered %d CDP neighbors",
            device_id, len(result.cdp_neighbors),
        )
    except Exception as e:
        msg = f"CDP discovery failed: {e}"
        result.errors.append(msg)
        logger.debug("%s: %s", device_id, msg)

    # Phase 4: LLDP neighbors (fallback if CDP is empty)
    if not result.cdp_neighbors:
        try:
            result.lldp_neighbors = _discover_lldp_neighbors(conn)
            logger.info(
                "%s: discovered %d LLDP neighbors",
                device_id, len(result.lldp_neighbors),
            )
        except Exception as e:
            msg = f"LLDP discovery failed: {e}"
            result.errors.append(msg)
            logger.debug("%s: %s", device_id, msg)

    result.success = len(result.interfaces) > 0
    logger.info("Discovery complete: %s", result.summary)
    return result


def discover_all(
    connections: List[DeviceConnection],
) -> Tuple[List[DiscoveryResult], NetworkTopology]:
    """Run discovery on all connected devices and build a topology.

    Args:
        connections: List of active DeviceConnection objects.

    Returns:
        (results, topology) — individual results per device and
        a fully built NetworkTopology.
    """
    results: List[DiscoveryResult] = []
    nodes: List[TopologyNode] = []

    for conn in connections:
        if not conn.is_connected:
            logger.warning(
                "Skipping %s — not connected", conn.device.device_id
            )
            continue

        result = discover_device(conn)
        results.append(result)

        # Build topology node from discovery
        node = TopologyNode(
            device_id=conn.device.device_id,
            host=conn.device.host,
            device_type=conn.device.device_type.value,
            interfaces=result.interfaces,
            ospf=result.ospf,
        )

        # Set loopback IP
        for iface in result.interfaces:
            if "loopback" in iface.name.lower() and iface.ip:
                node.loopback_ip = iface.ip
                break

        nodes.append(node)

    # Build topology
    topology = NetworkTopology()
    for node in nodes:
        topology.add_node(node)

    # Build links from CDP/LLDP neighbors
    _build_links_from_neighbors(topology, results)

    logger.info(
        "Discovery complete: %d devices, %d nodes, %d links",
        len(results), topology.node_count, topology.link_count,
    )

    return results, topology


# ── Interface discovery ──────────────────────────────────────────────


def _discover_interfaces(conn: DeviceConnection) -> List[InterfaceInfo]:
    """Discover all interfaces with IPs using show commands."""
    device_id = conn.device.device_id
    interfaces: List[InterfaceInfo] = []

    # Get basic interface list
    brief = conn.execute_command("show ip interface brief")
    if not brief.success:
        logger.warning("%s: show ip interface brief failed", device_id)
        return interfaces

    parsed = parse_show_ip_interface_brief(brief.output)

    for entry in parsed:
        name = entry.get("interface", "")
        ip = entry.get("ip_address", "")
        status = entry.get("status", "")
        protocol = entry.get("protocol", "")

        # Skip unassigned interfaces
        if not ip or ip == "unassigned":
            ip = None

        is_shutdown = "administratively" in status.lower()
        is_up = (
            status.lower() == "up" and protocol.lower() == "up"
        )

        iface = InterfaceInfo(
            name=name,
            ip=ip,
            enabled=is_up,
            shutdown=is_shutdown,
        )
        interfaces.append(iface)

    # Enrich with subnet masks from "show interfaces"
    _enrich_with_masks(conn, interfaces)

    # Enrich with descriptions from "show interfaces description"
    _enrich_with_descriptions(conn, interfaces)

    return interfaces


def _enrich_with_masks(
    conn: DeviceConnection, interfaces: List[InterfaceInfo]
) -> None:
    """Add subnet masks to interfaces that have IPs."""
    ifaces_with_ip = [i for i in interfaces if i.ip]
    if not ifaces_with_ip:
        return

    # Use "show running-config | include interface|ip address" for bulk
    # This is more efficient than per-interface queries
    result = conn.execute_command(
        "show running-config | include ^interface |^ ip address"
    )
    if not result.success:
        # Fallback: try individual queries
        for iface in ifaces_with_ip:
            _get_single_mask(conn, iface)
        return

    # Parse: lines alternate between "interface X" and " ip address X M"
    current_iface = None
    ip_map: Dict[str, Tuple[str, str]] = {}  # iface_name -> (ip, mask)

    for line in result.output.splitlines():
        line = line.strip()
        if line.startswith("interface "):
            current_iface = line.split("interface ", 1)[1].strip()
        elif line.startswith("ip address ") and current_iface:
            parts = line.split()
            if len(parts) >= 4:
                ip_map[current_iface] = (parts[2], parts[3])
            current_iface = None

    # Match discovered interfaces to config data
    for iface in ifaces_with_ip:
        for cfg_name, (ip, mask) in ip_map.items():
            if _iface_name_match(iface.name, cfg_name):
                iface.mask = mask
                iface.cidr = NetworkTopology.mask_to_cidr(mask)
                break


def _get_single_mask(conn: DeviceConnection, iface: InterfaceInfo) -> None:
    """Get mask for a single interface via show interface."""
    result = conn.execute_command(f"show interface {iface.name}")
    if not result.success:
        return

    match = re.search(
        r"Internet address is (\d+\.\d+\.\d+\.\d+)/(\d+)",
        result.output,
    )
    if match:
        iface.cidr = int(match.group(2))
        # Convert CIDR back to mask
        cidr = iface.cidr
        mask_int = (0xFFFFFFFF << (32 - cidr)) & 0xFFFFFFFF
        iface.mask = ".".join(
            str((mask_int >> (24 - 8 * i)) & 0xFF) for i in range(4)
        )


def _enrich_with_descriptions(
    conn: DeviceConnection, interfaces: List[InterfaceInfo]
) -> None:
    """Add descriptions to interfaces."""
    result = conn.execute_command("show interfaces description")
    if not result.success:
        return

    # Parse output: "Interface  Status  Protocol  Description"
    for line in result.output.splitlines():
        if not line.strip() or line.startswith("Interface"):
            continue

        parts = line.split(None, 3)
        if len(parts) >= 4:
            iface_name = parts[0]
            description = parts[3].strip()
            for iface in interfaces:
                if _iface_name_match(iface.name, iface_name):
                    iface.description = description
                    break


# ── OSPF discovery ───────────────────────────────────────────────────


def _discover_ospf(conn: DeviceConnection) -> Optional[OSPFConfig]:
    """Discover OSPF configuration from the running config."""
    device_id = conn.device.device_id

    # First check if OSPF is even running
    ospf_check = conn.execute_command("show ip ospf")
    if not ospf_check.success or not ospf_check.output.strip():
        return None
    if "OSPF not enabled" in ospf_check.output:
        return None

    # Parse process ID and router-id from "show ip ospf"
    process_id = 1
    router_id = None

    # Parse process ID — "Routing Process "ospf 1" with ID 1.1.1.1"
    pid_match = re.search(
        r'Routing Process\s+"ospf\s+(\d+)".*?(?:with\s+)?ID\s+(\S+)',
        ospf_check.output,
    )
    if pid_match:
        process_id = int(pid_match.group(1))
        router_id = pid_match.group(2)
    else:
        # Fallback: simpler patterns across multiple lines
        pid_match2 = re.search(r"ospf\s+(\d+)", ospf_check.output, re.IGNORECASE)
        if pid_match2:
            process_id = int(pid_match2.group(1))
        rid_match = re.search(r"Router ID\s+(\S+)", ospf_check.output)
        if rid_match:
            router_id = rid_match.group(1)

    # Discover areas and networks from "show ip ospf interface brief"
    areas = _discover_ospf_areas(conn)

    # Discover passive interfaces
    passive_interfaces = _discover_passive_interfaces(conn)

    return OSPFConfig(
        process_id=process_id,
        router_id=router_id,
        areas=areas,
        passive_interfaces=passive_interfaces,
    )


def _discover_ospf_areas(conn: DeviceConnection) -> List[OSPFArea]:
    """Discover OSPF areas and their networks from interface data."""
    result = conn.execute_command("show ip ospf interface brief")
    if not result.success:
        return []

    # Parse: Interface  PID  Area  IP Address/Mask  Cost  State  ...
    areas_map: Dict[int, List[Dict[str, str]]] = {}

    for line in result.output.splitlines():
        if not line.strip() or line.startswith("Interface"):
            continue

        parts = line.split()
        if len(parts) >= 4:
            try:
                iface_name = parts[0]
                # PID is parts[1], Area is parts[2]
                area_id = int(parts[2])
                ip_mask = parts[3]  # e.g. "10.10.10.1/24"

                if "/" in ip_mask:
                    ip, cidr = ip_mask.split("/")
                    cidr_int = int(cidr)
                    # Calculate network and wildcard
                    net = _ip_to_network(ip, cidr_int)
                    wildcard = _cidr_to_wildcard(cidr_int)
                else:
                    net = ip_mask
                    wildcard = "0.0.0.255"

                if area_id not in areas_map:
                    areas_map[area_id] = []
                areas_map[area_id].append({
                    "network": net,
                    "wildcard": wildcard,
                })
            except (ValueError, IndexError):
                continue

    return [
        OSPFArea(area_id=aid, networks=nets)
        for aid, nets in sorted(areas_map.items())
    ]


def _discover_passive_interfaces(conn: DeviceConnection) -> List[str]:
    """Discover OSPF passive interfaces from running config."""
    result = conn.execute_command(
        "show running-config | section router ospf"
    )
    if not result.success:
        return []

    passive = []
    for line in result.output.splitlines():
        match = re.match(r"\s+passive-interface\s+(\S+)", line)
        if match:
            iface = match.group(1)
            if iface.lower() != "default":
                passive.append(iface)

    return passive


# ── CDP/LLDP neighbor discovery ──────────────────────────────────────


def _discover_cdp_neighbors(conn: DeviceConnection) -> List[Dict[str, str]]:
    """Discover CDP neighbors."""
    result = conn.execute_command("show cdp neighbors detail")
    if not result.success:
        return []

    neighbors = []
    blocks = re.split(r"-{10,}", result.output)

    for block in blocks:
        if not block.strip():
            continue

        neighbor: Dict[str, str] = {}

        # Device ID
        did_match = re.search(r"Device ID:\s*(\S+)", block)
        if did_match:
            # Clean up FQDN — take just the hostname
            hostname = did_match.group(1).split(".")[0]
            neighbor["device_id"] = hostname

        # Local interface
        local_match = re.search(
            r"Interface:\s*(\S+)", block
        )
        if local_match:
            neighbor["local_interface"] = local_match.group(1).rstrip(",")

        # Remote interface (port)
        remote_match = re.search(
            r"Port ID \(outgoing port\):\s*(\S+)", block
        )
        if remote_match:
            neighbor["remote_interface"] = remote_match.group(1)

        # IP address
        ip_match = re.search(
            r"IP(?:v4)?\s+[Aa]ddress:\s*(\d+\.\d+\.\d+\.\d+)", block
        )
        if ip_match:
            neighbor["ip"] = ip_match.group(1)

        # Platform
        platform_match = re.search(r"Platform:\s*(.+?)(?:,|$)", block)
        if platform_match:
            neighbor["platform"] = platform_match.group(1).strip()

        if "device_id" in neighbor and "local_interface" in neighbor:
            neighbors.append(neighbor)

    return neighbors


def _discover_lldp_neighbors(conn: DeviceConnection) -> List[Dict[str, str]]:
    """Discover LLDP neighbors."""
    result = conn.execute_command("show lldp neighbors detail")
    if not result.success:
        return []

    neighbors = []
    blocks = re.split(r"-{10,}", result.output)

    for block in blocks:
        if not block.strip():
            continue

        neighbor: Dict[str, str] = {}

        # System name
        name_match = re.search(r"System Name:\s*(\S+)", block)
        if name_match:
            neighbor["device_id"] = name_match.group(1).split(".")[0]

        # Local interface
        local_match = re.search(r"Local Intf:\s*(\S+)", block)
        if local_match:
            neighbor["local_interface"] = local_match.group(1)

        # Remote port
        port_match = re.search(r"Port id:\s*(\S+)", block)
        if port_match:
            neighbor["remote_interface"] = port_match.group(1)

        # Management address
        ip_match = re.search(
            r"Management Addresses.*?IP:\s*(\d+\.\d+\.\d+\.\d+)",
            block, re.DOTALL,
        )
        if ip_match:
            neighbor["ip"] = ip_match.group(1)

        if "device_id" in neighbor and "local_interface" in neighbor:
            neighbors.append(neighbor)

    return neighbors


# ── Link building from neighbor data ─────────────────────────────────


def _build_links_from_neighbors(
    topology: NetworkTopology, results: List[DiscoveryResult]
) -> None:
    """Create topology links from CDP/LLDP neighbor data.

    Cross-references neighbor data from multiple devices to create
    verified bidirectional links.
    """
    known_devices = {n.device_id for n in topology.get_all_nodes()}
    seen_links: set = set()

    for result in results:
        device_id = result.device_id
        all_neighbors = result.cdp_neighbors + result.lldp_neighbors

        for nbr in all_neighbors:
            nbr_id = nbr.get("device_id", "")
            local_iface = nbr.get("local_interface", "unknown")
            remote_iface = nbr.get("remote_interface", "unknown")

            # Try to match the CDP/LLDP device_id to a known topology node
            # CDP may report "R2" or "R2.domain.com" — we try prefix match
            matched_id = _match_device_id(nbr_id, known_devices)
            if matched_id is None:
                logger.debug(
                    "%s: CDP/LLDP neighbor '%s' not in topology, skipping",
                    device_id, nbr_id,
                )
                continue

            # Deduplicate
            link_key = tuple(sorted([
                (device_id, local_iface),
                (matched_id, remote_iface),
            ]))
            if link_key in seen_links:
                continue
            seen_links.add(link_key)

            # Find subnet from interface data
            subnet = None
            node = topology.get_node(device_id)
            if node:
                iface = node.get_interface(local_iface)
                if iface and iface.ip and iface.cidr is not None:
                    subnet = f"{_ip_to_network(iface.ip, iface.cidr)}/{iface.cidr}"

            link = TopologyLink(
                source_device=device_id,
                source_interface=local_iface,
                target_device=matched_id,
                target_interface=remote_iface,
            )
            if subnet:
                link.subnet = subnet

            topology.add_link(link)
            logger.info(
                "Discovered link: %s:%s <-> %s:%s",
                device_id, local_iface, matched_id, remote_iface,
            )


def _match_device_id(
    cdp_name: str, known_ids: set
) -> Optional[str]:
    """Match a CDP/LLDP device name to a known topology node ID.

    Handles cases like CDP reporting "R2.lab.local" when the node is "R2".
    """
    # Exact match first
    if cdp_name in known_ids:
        return cdp_name

    # Try hostname prefix (before first dot)
    short = cdp_name.split(".")[0]
    if short in known_ids:
        return short

    # Case-insensitive match
    for kid in known_ids:
        if kid.lower() == cdp_name.lower() or kid.lower() == short.lower():
            return kid

    return None


# ── Helpers ──────────────────────────────────────────────────────────


def _iface_name_match(name_a: str, name_b: str) -> bool:
    """Check if two interface names refer to the same interface.

    Handles abbreviated vs full names (e.g., Gi0/0 vs GigabitEthernet0/0).
    """
    return name_a.lower() == name_b.lower() or _normalize_iface(
        name_a
    ) == _normalize_iface(name_b)


def _normalize_iface(name: str) -> str:
    """Normalize interface name to a canonical short form."""
    name = name.strip()
    replacements = [
        ("GigabitEthernet", "Gi"),
        ("FastEthernet", "Fa"),
        ("TenGigabitEthernet", "Te"),
        ("Ethernet", "Et"),
        ("Serial", "Se"),
        ("Loopback", "Lo"),
        ("Tunnel", "Tu"),
        ("Vlan", "Vl"),
        ("Port-channel", "Po"),
    ]
    for full, short in replacements:
        if name.lower().startswith(full.lower()):
            return short + name[len(full):]
    return name


def _ip_to_network(ip: str, cidr: int) -> str:
    """Calculate network address from IP and CIDR."""
    parts = [int(x) for x in ip.split(".")]
    mask_int = (0xFFFFFFFF << (32 - cidr)) & 0xFFFFFFFF
    ip_int = (parts[0] << 24) | (parts[1] << 16) | (parts[2] << 8) | parts[3]
    net_int = ip_int & mask_int
    return ".".join(
        str((net_int >> (24 - 8 * i)) & 0xFF) for i in range(4)
    )


def _cidr_to_wildcard(cidr: int) -> str:
    """Convert CIDR prefix length to wildcard mask."""
    mask_int = (0xFFFFFFFF << (32 - cidr)) & 0xFFFFFFFF
    wildcard = mask_int ^ 0xFFFFFFFF
    return ".".join(
        str((wildcard >> (24 - 8 * i)) & 0xFF) for i in range(4)
    )
