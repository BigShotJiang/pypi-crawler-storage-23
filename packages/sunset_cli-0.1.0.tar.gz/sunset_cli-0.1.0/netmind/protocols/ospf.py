"""OSPF verification helpers.

Provides structured OSPF state analysis that supplements Claude's
ability to interpret raw command output. These helpers parse common
OSPF show commands into structured data for programmatic verification.
"""

from typing import Any, Optional

from netmind.core.device_connection import DeviceConnection
from netmind.protocols.base import ProtocolVerifier
from netmind.utils import get_logger
from netmind.utils.parsers import (
    extract_ospf_config,
    parse_show_ip_ospf_neighbor,
    parse_show_ip_route_ospf,
)

logger = get_logger("protocols.ospf")


class OSPFVerifier(ProtocolVerifier):
    """OSPF-specific verification and analysis."""

    @property
    def protocol_name(self) -> str:
        return "OSPF"

    def get_relevant_commands(self) -> list[str]:
        return [
            "show ip ospf",
            "show ip ospf neighbor",
            "show ip ospf interface brief",
            "show ip ospf database",
            "show ip route ospf",
        ]

    def verify_status(self, conn: DeviceConnection) -> dict[str, Any]:
        """Verify OSPF health on a device.

        Checks:
        - OSPF process is running
        - Neighbor adjacencies are FULL
        - OSPF routes are present

        Returns:
            Dict with health status and detailed findings.
        """
        device_id = conn.device.device_id
        result: dict[str, Any] = {
            "healthy": False,
            "summary": "",
            "details": {},
            "device_id": device_id,
        }

        # Check OSPF process
        ospf_output = conn.execute_command("show ip ospf")
        if not ospf_output.success:
            result["summary"] = f"Failed to check OSPF on {device_id}: {ospf_output.error}"
            return result

        if "OSPF not enabled" in ospf_output.output or not ospf_output.output.strip():
            result["summary"] = f"OSPF is not configured on {device_id}"
            result["details"]["ospf_enabled"] = False
            return result

        result["details"]["ospf_enabled"] = True
        result["details"]["ospf_process"] = ospf_output.output

        # Check neighbors
        neighbor_output = conn.execute_command("show ip ospf neighbor")
        if neighbor_output.success:
            neighbors = parse_show_ip_ospf_neighbor(neighbor_output.output)
            result["details"]["neighbors"] = neighbors
            result["details"]["neighbor_count"] = len(neighbors)

            full_neighbors = [n for n in neighbors if "FULL" in n.get("state", "")]
            result["details"]["full_adjacencies"] = len(full_neighbors)
        else:
            result["details"]["neighbors"] = []
            result["details"]["neighbor_count"] = 0

        # Check OSPF routes
        route_output = conn.execute_command("show ip route ospf")
        if route_output.success:
            routes = parse_show_ip_route_ospf(route_output.output)
            result["details"]["ospf_routes"] = routes
            result["details"]["route_count"] = len(routes)
        else:
            result["details"]["ospf_routes"] = []
            result["details"]["route_count"] = 0

        # Determine health
        neighbor_count = result["details"].get("neighbor_count", 0)
        full_count = result["details"].get("full_adjacencies", 0)

        if neighbor_count > 0 and full_count == neighbor_count:
            result["healthy"] = True
            result["summary"] = (
                f"OSPF healthy on {device_id}: "
                f"{full_count} FULL adjacencies, "
                f"{result['details']['route_count']} OSPF routes"
            )
        elif neighbor_count > 0:
            result["summary"] = (
                f"OSPF partially up on {device_id}: "
                f"{full_count}/{neighbor_count} FULL adjacencies"
            )
        else:
            result["summary"] = f"OSPF running on {device_id} but no neighbors detected"

        logger.info(result["summary"])
        return result


def verify_ospf_adjacency(
    conn: DeviceConnection,
    expected_neighbors: Optional[list[str]] = None,
) -> tuple[bool, str]:
    """Quick check: are OSPF adjacencies up?

    Args:
        conn: Device connection.
        expected_neighbors: Optional list of expected neighbor router IDs.

    Returns:
        (success, message) tuple.
    """
    output = conn.execute_command("show ip ospf neighbor")
    if not output.success:
        return False, f"Failed to check OSPF neighbors: {output.error}"

    neighbors = parse_show_ip_ospf_neighbor(output.output)
    full_neighbors = [n for n in neighbors if "FULL" in n.get("state", "")]

    if not neighbors:
        return False, "No OSPF neighbors found"

    if expected_neighbors:
        found_ids = {n["neighbor_id"] for n in full_neighbors}
        missing = set(expected_neighbors) - found_ids
        if missing:
            return False, f"Missing expected OSPF neighbors: {', '.join(missing)}"

    if len(full_neighbors) < len(neighbors):
        not_full = [n for n in neighbors if "FULL" not in n.get("state", "")]
        states = ", ".join(
            f"{n['neighbor_id']}={n['state']}" for n in not_full
        )
        return False, f"Some neighbors not FULL: {states}"

    return True, f"All {len(full_neighbors)} OSPF adjacencies are FULL"


def get_ospf_config(conn: DeviceConnection) -> Optional[str]:
    """Extract OSPF configuration block from running config.

    Returns:
        OSPF config section as string, or None if not configured.
    """
    try:
        running = conn.get_running_config()
        return extract_ospf_config(running)
    except Exception as e:
        logger.warning("Could not extract OSPF config: %s", e)
        return None
