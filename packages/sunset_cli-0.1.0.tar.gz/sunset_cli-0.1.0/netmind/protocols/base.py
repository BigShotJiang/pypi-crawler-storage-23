"""Base protocol verification interface.

All protocol modules should follow this pattern so Claude
can use them consistently.
"""

from abc import ABC, abstractmethod
from typing import Any

from netmind.core.device_connection import DeviceConnection


class ProtocolVerifier(ABC):
    """Abstract base for protocol-specific verification helpers."""

    @property
    @abstractmethod
    def protocol_name(self) -> str:
        """Human-readable protocol name (e.g., 'OSPF', 'BGP')."""

    @abstractmethod
    def verify_status(self, conn: DeviceConnection) -> dict[str, Any]:
        """Verify protocol status on a device.

        Returns:
            Dict with at least:
              - 'healthy': bool
              - 'summary': str
              - 'details': dict (protocol-specific details)
        """

    @abstractmethod
    def get_relevant_commands(self) -> list[str]:
        """Return list of show commands relevant to this protocol."""
