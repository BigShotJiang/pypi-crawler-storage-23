"""BGP verification helpers.

Provides structured BGP state analysis: neighbor sessions,
prefix counts, and configuration extraction.
"""

from typing import Any, Optional

from netmind.core.device_connection import DeviceConnection
from netmind.protocols.base import ProtocolVerifier
from netmind.utils import get_logger
from netmind.utils.parsers import extract_bgp_config, parse_show_bgp_summary

logger = get_logger("protocols.bgp")


class BGPVerifier(ProtocolVerifier):
    """BGP-specific verification and analysis."""

    @property
    def protocol_name(self) -> str:
        return "BGP"

    def get_relevant_commands(self) -> list[str]:
        return [
            "show ip bgp summary",
            "show ip bgp neighbors",
            "show ip bgp",
            "show ip route bgp",
            "show running-config | section router bgp",
        ]

    def verify_status(self, conn: DeviceConnection) -> dict[str, Any]:
        """Verify BGP health on a device.

        Checks:
        - BGP process is running
        - Neighbor sessions are Established
        - Prefixes are being received

        Returns:
            Dict with health status and detailed findings.
        """
        device_id = conn.device.device_id
        result: dict[str, Any] = {
            "healthy": False,
            "summary": "",
            "details": {},
            "device_id": device_id,
        }

        summary_output = conn.execute_command("show ip bgp summary")
        if not summary_output.success:
            result["summary"] = f"Failed to check BGP on {device_id}: {summary_output.error}"
            return result

        if "not a recognized" in summary_output.output.lower() or not summary_output.output.strip():
            result["summary"] = f"BGP is not configured on {device_id}"
            result["details"]["bgp_enabled"] = False
            return result

        # Extract local AS from summary header
        import re
        as_match = re.search(r"local AS number (\d+)", summary_output.output)
        if as_match:
            result["details"]["local_as"] = as_match.group(1)

        result["details"]["bgp_enabled"] = True
        neighbors = parse_show_bgp_summary(summary_output.output)
        result["details"]["neighbors"] = neighbors
        result["details"]["neighbor_count"] = len(neighbors)

        established = []
        not_established = []
        total_prefixes = 0

        for n in neighbors:
            state = n.get("state_pfxrcd", "")
            if state.isdigit():
                established.append(n)
                total_prefixes += int(state)
            else:
                not_established.append(n)

        result["details"]["established_count"] = len(established)
        result["details"]["total_prefixes_received"] = total_prefixes

        # Check routes
        route_output = conn.execute_command("show ip route bgp")
        if route_output.success:
            route_lines = [
                l for l in route_output.output.splitlines()
                if l.strip().startswith("B")
            ]
            result["details"]["bgp_route_count"] = len(route_lines)
        else:
            result["details"]["bgp_route_count"] = 0

        # Determine health
        if len(neighbors) == 0:
            result["summary"] = f"BGP running on {device_id} but no neighbors configured"
        elif len(established) == len(neighbors):
            result["healthy"] = True
            result["summary"] = (
                f"BGP healthy on {device_id}: "
                f"{len(established)} sessions Established, "
                f"{total_prefixes} prefixes received"
            )
        elif len(established) > 0:
            result["summary"] = (
                f"BGP partially up on {device_id}: "
                f"{len(established)}/{len(neighbors)} sessions Established"
            )
        else:
            result["summary"] = (
                f"BGP on {device_id}: no sessions Established "
                f"({len(neighbors)} configured)"
            )

        logger.info(result["summary"])
        return result


def verify_bgp_session(
    conn: DeviceConnection,
    expected_neighbors: Optional[list[str]] = None,
) -> tuple[bool, str]:
    """Quick check: are BGP sessions established?"""
    output = conn.execute_command("show ip bgp summary")
    if not output.success:
        return False, f"Failed to check BGP: {output.error}"

    neighbors = parse_show_bgp_summary(output.output)
    established = [n for n in neighbors if n.get("state_pfxrcd", "").isdigit()]

    if not neighbors:
        return False, "No BGP neighbors configured"

    if expected_neighbors:
        found = {n["neighbor"] for n in established}
        missing = set(expected_neighbors) - found
        if missing:
            return False, f"Missing BGP sessions: {', '.join(missing)}"

    if len(established) < len(neighbors):
        down = [n for n in neighbors if not n.get("state_pfxrcd", "").isdigit()]
        states = ", ".join(
            f"{n['neighbor']}={n['state_pfxrcd']}" for n in down
        )
        return False, f"Some BGP sessions not Established: {states}"

    return True, f"All {len(established)} BGP sessions Established"


def get_bgp_config(conn: DeviceConnection) -> Optional[str]:
    """Extract BGP configuration block from running config."""
    try:
        running = conn.get_running_config()
        return extract_bgp_config(running)
    except Exception as e:
        logger.warning("Could not extract BGP config: %s", e)
        return None
