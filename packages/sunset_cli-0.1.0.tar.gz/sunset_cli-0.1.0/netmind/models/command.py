"""Command execution result models."""

from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class CommandType(str, Enum):
    """Type of command executed."""

    SHOW = "show"
    CONFIG = "config"
    PRIVILEGED = "privileged"


class CommandResult(BaseModel):
    """Result of a command execution on a device."""

    success: bool
    device_id: str
    command: str = Field(description="The command or commands that were executed")
    command_type: CommandType = CommandType.SHOW
    output: str = ""
    error: Optional[str] = None
    execution_time_ms: float = 0.0
    timestamp: datetime = Field(default_factory=datetime.now)

    @property
    def summary(self) -> str:
        """Short summary for logging."""
        status = "OK" if self.success else "FAIL"
        return f"[{status}] {self.device_id}: {self.command} ({self.execution_time_ms:.0f}ms)"

    def to_tool_result(self) -> dict:
        """Format for returning to Claude as a tool result."""
        if self.success:
            return {
                "status": "success",
                "device_id": self.device_id,
                "command": self.command,
                "output": self.output,
            }
        return {
            "status": "error",
            "device_id": self.device_id,
            "command": self.command,
            "error": self.error or "Unknown error",
        }


class MultiDeviceResult(BaseModel):
    """Results from executing a command across multiple devices."""

    command: str
    results: dict[str, CommandResult] = Field(default_factory=dict)

    @property
    def all_success(self) -> bool:
        return all(r.success for r in self.results.values())

    @property
    def failed_devices(self) -> list[str]:
        return [did for did, r in self.results.items() if not r.success]
