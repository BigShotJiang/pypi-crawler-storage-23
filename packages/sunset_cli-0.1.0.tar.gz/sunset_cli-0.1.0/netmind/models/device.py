"""Device data models."""

from datetime import datetime
from enum import Enum
from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, Field


class DeviceType(str, Enum):
    """Supported device types for Netmiko."""

    CISCO_IOS = "cisco_ios"
    CISCO_XE = "cisco_xe"
    CISCO_NXOS = "cisco_nxos"
    JUNIPER_JUNOS = "juniper_junos"
    ARISTA_EOS = "arista_eos"


class DeviceStatus(str, Enum):
    """Device connection status."""

    DISCONNECTED = "disconnected"
    CONNECTING = "connecting"
    CONNECTED = "connected"
    ERROR = "error"


class DeviceCredentials(BaseModel):
    """Credentials for connecting to a device. Never serialized to logs."""

    username: str
    password: str = Field(repr=False, exclude=True)
    enable_secret: Optional[str] = Field(default=None, repr=False, exclude=True)

    model_config = ConfigDict(
        json_schema_extra={"examples": [{"username": "admin", "password": "***"}]}
    )


class DeviceInfo(BaseModel):
    """Discovered device information from 'show version' etc."""

    hostname: str = ""
    os_version: str = ""
    model: str = ""
    serial: str = ""
    uptime: str = ""


class Device(BaseModel):
    """Full device representation."""

    device_id: str = Field(description="User-assigned ID (e.g., 'R1', 'core-sw-01')")
    host: str = Field(description="IP address or hostname")
    port: int = Field(default=22, description="SSH port")
    device_type: DeviceType = Field(default=DeviceType.CISCO_IOS)
    credentials: DeviceCredentials
    info: DeviceInfo = Field(default_factory=DeviceInfo)
    status: DeviceStatus = Field(default=DeviceStatus.DISCONNECTED)
    last_seen: Optional[datetime] = None
    connection_error: Optional[str] = None
    ssh_options: Dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Extra SSH options passed to Netmiko/Paramiko. "
            "Common keys: disabled_algorithms, transport_options, "
            "or any kwarg accepted by ConnectHandler."
        ),
    )

    @property
    def display_name(self) -> str:
        """Human-readable device name for UI."""
        name = self.info.hostname or self.device_id
        return f"{name} ({self.host})"

    @property
    def is_connected(self) -> bool:
        return self.status == DeviceStatus.CONNECTED
