"""sunset doctor - Diagnostic health checks."""

import shutil
import sys

from rich.console import Console


def run_doctor() -> None:
    """Run all health checks and print results."""
    console = Console()
    console.print("\n[bold cyan]Sunset Doctor[/bold cyan]\n")

    all_ok = True

    # 1. Python version
    v = sys.version_info
    if v >= (3, 9):
        console.print(f"  [green]\u2713[/green]  Python {v.major}.{v.minor}.{v.micro}")
    else:
        console.print(f"  [red]\u2717[/red]  Python {v.major}.{v.minor} (need >= 3.9)")
        all_ok = False

    # 2. Config file
    from netmind.utils.config import SUNSET_CONFIG_ENV

    if SUNSET_CONFIG_ENV.is_file():
        console.print(f"  [green]\u2713[/green]  Config file: {SUNSET_CONFIG_ENV}")
    else:
        console.print(f"  [red]\u2717[/red]  Config file not found: {SUNSET_CONFIG_ENV}")
        console.print("         Run [bold]sunset setup[/bold] to create it")
        all_ok = False

    # 3. API key set
    from netmind.utils.config import get_config, reset_config

    reset_config()
    config = get_config()
    if config.has_api_key:
        redacted = config.anthropic_api_key[:10] + "..."
        console.print(f"  [green]\u2713[/green]  API key set ({redacted})")
    else:
        console.print("  [red]\u2717[/red]  ANTHROPIC_API_KEY not set")
        all_ok = False

    # 4. License key
    if config.has_license:
        from netmind.utils.license import check_license

        result = check_license()
        if result.valid:
            email_str = f" ({result.email})" if result.email else ""
            cached_str = " (cached)" if result.cached else ""
            console.print(f"  [green]\u2713[/green]  License active{email_str}{cached_str}")
        else:
            console.print(f"  [red]\u2717[/red]  License invalid: {result.error}")
            all_ok = False
    else:
        console.print("  [red]\u2717[/red]  No license key set")
        console.print("         Run [bold]sunset auth <key>[/bold] to activate")
        all_ok = False

    # 5. API key validation (quick test call)
    if config.has_api_key:
        try:
            import anthropic

            client = anthropic.Anthropic(api_key=config.anthropic_api_key)
            client.messages.create(
                model=config.claude_model,
                max_tokens=1,
                messages=[{"role": "user", "content": "hi"}],
            )
            console.print(
                f"  [green]\u2713[/green]  API key valid (model: {config.claude_model})"
            )
        except Exception as exc:
            console.print(f"  [red]\u2717[/red]  API key validation failed: {exc}")
            all_ok = False

    # 5. Required packages
    for pkg in ("netmiko", "paramiko", "textual", "rich", "anthropic"):
        try:
            __import__(pkg)
            console.print(f"  [green]\u2713[/green]  {pkg}")
        except ImportError:
            console.print(f"  [red]\u2717[/red]  {pkg} not installed")
            all_ok = False

    # 6. SSH
    ssh_path = shutil.which("ssh")
    if ssh_path:
        console.print(f"  [green]\u2713[/green]  SSH: {ssh_path}")
    else:
        console.print("  [red]\u2717[/red]  SSH not found on PATH")
        all_ok = False

    # Summary
    console.print()
    if all_ok:
        console.print("[bold green]All checks passed.[/bold green]\n")
    else:
        console.print(
            "[bold red]Some checks failed.[/bold red] See above for details.\n"
        )
