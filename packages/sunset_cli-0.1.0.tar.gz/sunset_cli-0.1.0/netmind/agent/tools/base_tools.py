"""Base tool handlers: device listing and info retrieval.

These are generic, read-only tools that work across all device types.
"""

from typing import Any

from netmind.agent.tool_registry import ToolRegistry
from netmind.core.device_manager import DeviceManager
from netmind.utils import get_logger

logger = get_logger("agent.tools.base")


async def handle_list_devices(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle the list_devices tool call."""
    dm: DeviceManager = context["device_manager"]
    devices = dm.get_devices_summary()

    if not devices:
        return {
            "status": "success",
            "devices": [],
            "message": "No devices connected. Use the device manager to add devices.",
        }

    return {
        "status": "success",
        "device_count": len(devices),
        "devices": devices,
    }


async def handle_get_device_info(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle the get_device_info tool call."""
    dm: DeviceManager = context["device_manager"]
    device_id = tool_input["device_id"]

    conn = dm.get_device(device_id)
    if conn is None:
        return {
            "status": "error",
            "error": f"Device '{device_id}' not found. Available: {', '.join(dm.get_device_ids())}",
        }

    d = conn.device
    return {
        "status": "success",
        "device_id": device_id,
        "hostname": d.info.hostname,
        "host": d.host,
        "os_version": d.info.os_version,
        "model": d.info.model,
        "serial": d.info.serial,
        "uptime": d.info.uptime,
        "device_type": d.device_type.value,
        "connected": conn.is_connected,
    }


def register_base_tools(registry: ToolRegistry) -> None:
    """Register base tool handlers."""
    registry.register("list_devices", handle_list_devices)
    registry.register("get_device_info", handle_get_device_info)
