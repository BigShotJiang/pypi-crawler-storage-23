"""Topology-aware tool handlers for Claude.

These tools give Claude direct access to the network topology model,
letting it reason about connectivity, paths, subnets, and OSPF design
without needing to discover everything via SSH.
"""

from typing import Any

from netmind.agent.tool_registry import ToolRegistry
from netmind.core.topology import NetworkTopology
from netmind.utils import get_logger

logger = get_logger("agent.tools.topology")


async def handle_get_topology(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Return the full network topology summary.

    Includes all nodes, links, subnets, OSPF areas, and an ASCII diagram.
    """
    topology: NetworkTopology = context.get("topology")
    if topology is None or topology.node_count == 0:
        return {
            "status": "success",
            "message": (
                "No topology data loaded. The inventory file may not include "
                "interface or link definitions. Use SSH commands to discover "
                "the topology from the devices directly."
            ),
            "node_count": 0,
            "link_count": 0,
        }

    summary = topology.get_topology_summary()
    return {
        "status": "success",
        **summary,
    }


async def handle_get_device_interfaces(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Return all interfaces for a specific device, with connection info."""
    topology: NetworkTopology = context.get("topology")
    device_id = tool_input["device_id"]

    if topology is None:
        return {
            "status": "error",
            "error": "No topology data loaded.",
        }

    interfaces = topology.get_device_interfaces(device_id)
    if interfaces is None:
        all_ids = [n.device_id for n in topology.get_all_nodes()]
        return {
            "status": "error",
            "error": (
                f"Device '{device_id}' not found in topology. "
                f"Available: {', '.join(all_ids)}"
            ),
        }

    node = topology.get_node(device_id)
    result: dict[str, Any] = {
        "status": "success",
        "device_id": device_id,
        "interface_count": len(interfaces),
        "interfaces": interfaces,
    }

    if node and node.ospf:
        result["ospf"] = {
            "process_id": node.ospf.process_id,
            "router_id": node.ospf.router_id,
            "areas": [
                {"area_id": a.area_id, "networks": a.networks}
                for a in node.ospf.areas
            ],
            "passive_interfaces": node.ospf.passive_interfaces,
        }

    return result


async def handle_get_neighbors(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Return all neighbors of a device with connecting interface details."""
    topology: NetworkTopology = context.get("topology")
    device_id = tool_input["device_id"]

    if topology is None:
        return {
            "status": "error",
            "error": "No topology data loaded.",
        }

    node = topology.get_node(device_id)
    if node is None:
        all_ids = [n.device_id for n in topology.get_all_nodes()]
        return {
            "status": "error",
            "error": (
                f"Device '{device_id}' not found in topology. "
                f"Available: {', '.join(all_ids)}"
            ),
        }

    neighbors = topology.get_neighbors(device_id)
    return {
        "status": "success",
        "device_id": device_id,
        "neighbor_count": len(neighbors),
        "neighbors": neighbors,
    }


async def handle_find_path(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Find the shortest path between two devices in the topology."""
    topology: NetworkTopology = context.get("topology")
    source = tool_input["source_device"]
    target = tool_input["target_device"]

    if topology is None:
        return {
            "status": "error",
            "error": "No topology data loaded.",
        }

    path = topology.find_path(source, target)
    if path is None:
        return {
            "status": "error",
            "error": f"No path found between '{source}' and '{target}'.",
        }

    # Build detailed path with hop-by-hop interface info
    hops = []
    for i in range(len(path) - 1):
        src = path[i]
        dst = path[i + 1]
        # Find the link between them
        link_info = None
        for link in topology.get_all_links():
            if (link.source_device == src and link.target_device == dst) or \
               (link.source_device == dst and link.target_device == src):
                if link.source_device == src:
                    link_info = {
                        "from_device": src,
                        "from_interface": link.source_interface,
                        "to_device": dst,
                        "to_interface": link.target_interface,
                        "subnet": link.subnet,
                    }
                else:
                    link_info = {
                        "from_device": src,
                        "from_interface": link.target_interface,
                        "to_device": dst,
                        "to_interface": link.source_interface,
                        "subnet": link.subnet,
                    }
                break
        hops.append(link_info or {"from_device": src, "to_device": dst})

    return {
        "status": "success",
        "source": source,
        "target": target,
        "hop_count": len(path) - 1,
        "path": path,
        "hops": hops,
    }


async def handle_get_ospf_topology(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Get the OSPF topology: areas, member devices, networks, and router-IDs."""
    topology: NetworkTopology = context.get("topology")

    if topology is None:
        return {
            "status": "error",
            "error": "No topology data loaded.",
        }

    ospf_summary = topology.get_ospf_summary()
    if not ospf_summary["devices"]:
        return {
            "status": "success",
            "message": (
                "No OSPF configuration found in topology data. "
                "Use SSH to discover OSPF configuration from devices."
            ),
            "ospf_areas": {},
            "devices": {},
        }

    return {
        "status": "success",
        **ospf_summary,
    }


async def handle_get_subnets(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Get all subnets and which device:interface belongs to each."""
    topology: NetworkTopology = context.get("topology")

    if topology is None:
        return {
            "status": "error",
            "error": "No topology data loaded.",
        }

    subnets = topology.get_subnets()
    return {
        "status": "success",
        "subnet_count": len(subnets),
        "subnets": subnets,
    }


def register_topology_tools(registry: ToolRegistry) -> None:
    """Register topology tool handlers."""
    registry.register("get_topology", handle_get_topology)
    registry.register("get_device_interfaces", handle_get_device_interfaces)
    registry.register("get_neighbors", handle_get_neighbors)
    registry.register("find_path", handle_find_path)
    registry.register("get_ospf_topology", handle_get_ospf_topology)
    registry.register("get_subnets", handle_get_subnets)
