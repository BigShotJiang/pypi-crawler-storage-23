"""Device management tool handlers.

Allows the Claude agent to dynamically add new devices to the
managed topology at runtime (no inventory file edit required).
"""

from typing import Any

from netmind.agent.tool_registry import ToolRegistry
from netmind.core.device_connection import DeviceConnectionError
from netmind.core.device_manager import DeviceManager
from netmind.core.safety import SafetyGuard
from netmind.core.topology import TopologyNode
from netmind.models import DeviceType
from netmind.utils import get_logger, get_session_logger

logger = get_logger("agent.tools.device")


async def handle_add_device(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle the add_device tool call.

    Connects to a device via SSH, adds it to the DeviceManager,
    and creates a TopologyNode so topology tools can see it.
    """
    dm: DeviceManager = context["device_manager"]
    guard: SafetyGuard = context["safety_guard"]
    slog = get_session_logger()

    # Safety: adding devices is a mutating action
    if guard.read_only:
        return {
            "status": "error",
            "error": (
                "Cannot add devices in READ-ONLY mode. "
                "The user must switch to INTERACTIVE mode first (Ctrl+R)."
            ),
        }

    device_id = tool_input["device_id"]
    host = tool_input["host"]
    username = tool_input["username"]
    password = tool_input["password"]
    device_type_str = tool_input.get("device_type", "cisco_ios")
    port = tool_input.get("port", 22)
    enable_secret = tool_input.get("enable_secret")
    legacy_ssh = tool_input.get("legacy_ssh", False)

    # Build SSH options
    ssh_options: dict[str, Any] = {}
    if legacy_ssh:
        ssh_options["disabled_algorithms"] = {"kex": [], "pubkeys": [], "keys": []}

    try:
        device_type = DeviceType(device_type_str)
    except ValueError:
        return {
            "status": "error",
            "error": (
                f"Unknown device_type '{device_type_str}'. "
                f"Valid types: {', '.join(dt.value for dt in DeviceType)}"
            ),
        }

    try:
        conn = dm.add_device(
            device_id=device_id,
            host=host,
            username=username,
            password=password,
            device_type=device_type,
            port=int(port),
            enable_secret=enable_secret,
            ssh_options=ssh_options or None,
        )
    except ValueError as e:
        return {"status": "error", "error": str(e)}
    except DeviceConnectionError as e:
        return {
            "status": "error",
            "error": f"SSH connection to {host} failed: {e}",
        }
    except Exception as e:
        logger.error("add_device failed for %s (%s): %s", device_id, host, e)
        return {
            "status": "error",
            "error": f"Failed to add device: {e}",
        }

    # Add a topology node so topology tools (get_topology, etc.) see it
    topo_node = TopologyNode(
        device_id=device_id,
        host=host,
        device_type=device_type_str,
        role="router",
    )
    dm.topology.add_node(topo_node)

    info = conn.device.info
    priv = conn.privilege_level

    slog.log_device_connect(
        device_id=device_id,
        host=host,
        success=True,
        elapsed_ms=0,
    )

    result: dict[str, Any] = {
        "status": "success",
        "device_id": device_id,
        "host": host,
        "hostname": info.hostname,
        "os_version": info.os_version,
        "model": info.model,
        "privilege_level": priv,
        "message": (
            f"Device {device_id} ({info.hostname}) added and connected via SSH. "
            f"It is now available for all tools."
        ),
    }

    if 0 <= priv < 15:
        result["warning"] = (
            f"Connected at privilege level {priv} (need 15 for config). "
            f"Provide enable_secret if configuration changes are needed."
        )

    return result


def register_device_tools(registry: ToolRegistry) -> None:
    """Register device management tool handlers."""
    registry.register("add_device", handle_add_device)
