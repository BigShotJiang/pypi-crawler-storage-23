"""Protocol verification tool handlers.

These tools give Claude structured protocol health checks
instead of requiring it to parse raw command output.
"""

from typing import Any

from netmind.agent.tool_registry import ToolRegistry
from netmind.core.device_manager import DeviceManager
from netmind.protocols.ospf import OSPFVerifier
from netmind.protocols.bgp import BGPVerifier
from netmind.protocols.eigrp import EIGRPVerifier
from netmind.protocols.isis import ISISVerifier
from netmind.protocols.mpls import MPLSVerifier
from netmind.utils import get_logger

logger = get_logger("agent.tools.verification")


async def _run_verifier(
    verifier_cls: type,
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Common logic for all protocol verification tools."""
    dm: DeviceManager = context["device_manager"]
    device_id = tool_input["device_id"]

    conn = dm.get_device(device_id)
    if conn is None:
        return {
            "status": "error",
            "error": f"Device '{device_id}' not found",
        }

    verifier = verifier_cls()
    result = verifier.verify_status(conn)

    return {
        "status": "success",
        "device_id": device_id,
        "protocol": verifier.protocol_name,
        "healthy": result["healthy"],
        "summary": result["summary"],
        "details": result["details"],
    }


async def handle_verify_ospf(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle the verify_ospf tool."""
    return await _run_verifier(OSPFVerifier, tool_input, context)


async def handle_verify_bgp(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle the verify_bgp tool."""
    return await _run_verifier(BGPVerifier, tool_input, context)


async def handle_verify_eigrp(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle the verify_eigrp tool."""
    return await _run_verifier(EIGRPVerifier, tool_input, context)


async def handle_verify_isis(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle the verify_isis tool."""
    return await _run_verifier(ISISVerifier, tool_input, context)


async def handle_verify_mpls(
    tool_input: dict[str, Any],
    context: dict[str, Any],
) -> dict[str, Any]:
    """Handle the verify_mpls tool."""
    return await _run_verifier(MPLSVerifier, tool_input, context)


def register_verification_tools(registry: ToolRegistry) -> None:
    """Register verification tool handlers."""
    registry.register("verify_ospf", handle_verify_ospf)
    registry.register("verify_bgp", handle_verify_bgp)
    registry.register("verify_eigrp", handle_verify_eigrp)
    registry.register("verify_isis", handle_verify_isis)
    registry.register("verify_mpls", handle_verify_mpls)
