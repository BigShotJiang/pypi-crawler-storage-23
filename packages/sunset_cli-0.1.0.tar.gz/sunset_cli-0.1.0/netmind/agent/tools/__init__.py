"""Tool handler implementations."""

from netmind.agent.tools.base_tools import register_base_tools
from netmind.agent.tools.device_tools import register_device_tools
from netmind.agent.tools.ios_tools import register_ios_tools
from netmind.agent.tools.topology_tools import register_topology_tools
from netmind.agent.tools.verification_tools import register_verification_tools
from netmind.agent.tool_registry import ToolRegistry


def register_all_tools(registry: ToolRegistry) -> None:
    """Register all available tool handlers."""
    register_base_tools(registry)
    register_device_tools(registry)
    register_ios_tools(registry)
    register_verification_tools(registry)
    register_topology_tools(registry)


__all__ = ["register_all_tools"]
