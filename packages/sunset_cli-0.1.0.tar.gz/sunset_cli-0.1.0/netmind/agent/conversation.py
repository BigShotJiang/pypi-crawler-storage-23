"""Conversation history manager for Claude API interactions.

Maintains the message history in Anthropic's expected format,
handles token-aware truncation, and provides serialization
for session persistence.
"""

import json
from typing import Any, Optional

from netmind.utils import get_logger

logger = get_logger("agent.conversation")


class ConversationManager:
    """Manages the conversation message history with Claude.

    Messages are stored in Anthropic's format:
    [
        {"role": "user", "content": "..."},
        {"role": "assistant", "content": [...]},
        {"role": "user", "content": [{"type": "tool_result", ...}]},
        ...
    ]
    """

    def __init__(self, max_messages: int = 50) -> None:
        self._messages: list[dict[str, Any]] = []
        self._max_messages = max_messages

    @property
    def messages(self) -> list[dict[str, Any]]:
        """Get the current message history."""
        return list(self._messages)

    @property
    def message_count(self) -> int:
        return len(self._messages)

    def add_user_message(self, content: str) -> None:
        """Add a user text message."""
        self._messages.append({
            "role": "user",
            "content": content,
        })
        self._trim()
        logger.debug("Added user message (%d chars)", len(content))

    def add_assistant_message(self, content: list[dict[str, Any]]) -> None:
        """Add Claude's response (may include text and tool_use blocks).

        Args:
            content: List of content blocks from Claude's response.
                     Each block is either {"type": "text", "text": "..."}
                     or {"type": "tool_use", "id": "...", "name": "...", "input": {...}}
        """
        self._messages.append({
            "role": "assistant",
            "content": content,
        })
        self._trim()
        logger.debug("Added assistant message (%d blocks)", len(content))

    def add_tool_result(
        self,
        tool_use_id: str,
        result: Any,
        is_error: bool = False,
    ) -> None:
        """Add a tool execution result.

        If the last message is already a user message with tool_results,
        append to it (for parallel tool calls). Otherwise create new.
        """
        tool_result_block = {
            "type": "tool_result",
            "tool_use_id": tool_use_id,
            "content": json.dumps(result) if isinstance(result, dict) else str(result),
        }
        if is_error:
            tool_result_block["is_error"] = True

        # Check if last message is user role with tool_results
        if (
            self._messages
            and self._messages[-1]["role"] == "user"
            and isinstance(self._messages[-1]["content"], list)
            and all(
                isinstance(block, dict) and block.get("type") == "tool_result"
                for block in self._messages[-1]["content"]
            )
        ):
            # Append to existing tool results
            self._messages[-1]["content"].append(tool_result_block)
        else:
            # New user message with tool result
            self._messages.append({
                "role": "user",
                "content": [tool_result_block],
            })

        logger.debug("Added tool result for %s", tool_use_id)

    def get_messages(self) -> list[dict[str, Any]]:
        """Get conversation history in Anthropic API format."""
        return list(self._messages)

    def clear(self) -> None:
        """Clear all conversation history."""
        self._messages.clear()
        logger.info("Conversation history cleared")

    def get_last_assistant_text(self) -> Optional[str]:
        """Get the text content from the last assistant message."""
        for msg in reversed(self._messages):
            if msg["role"] == "assistant":
                content = msg["content"]
                if isinstance(content, str):
                    return content
                if isinstance(content, list):
                    texts = [
                        block["text"]
                        for block in content
                        if isinstance(block, dict) and block.get("type") == "text"
                    ]
                    return "\n".join(texts) if texts else None
        return None

    def _trim(self) -> None:
        """Trim old messages if we exceed the limit.

        Keeps the most recent messages. Ensures we don't break
        conversation flow (never trim mid-tool-call).
        """
        if len(self._messages) <= self._max_messages:
            return

        # Find a safe trim point - don't split tool call / result pairs
        trim_target = len(self._messages) - self._max_messages
        trim_point = 0

        for i in range(trim_target):
            msg = self._messages[i]
            # Don't trim if next message is a tool result (would orphan it)
            if i + 1 < len(self._messages):
                next_msg = self._messages[i + 1]
                if (
                    next_msg["role"] == "user"
                    and isinstance(next_msg["content"], list)
                    and any(
                        isinstance(b, dict) and b.get("type") == "tool_result"
                        for b in next_msg["content"]
                    )
                ):
                    continue
            trim_point = i + 1

        if trim_point > 0:
            self._messages = self._messages[trim_point:]
            logger.debug("Trimmed %d old messages", trim_point)

    def to_json(self) -> str:
        """Serialize conversation to JSON for persistence."""
        return json.dumps(self._messages, indent=2)

    @classmethod
    def from_json(cls, data: str, max_messages: int = 50) -> "ConversationManager":
        """Restore conversation from JSON."""
        mgr = cls(max_messages=max_messages)
        mgr._messages = json.loads(data)
        return mgr
