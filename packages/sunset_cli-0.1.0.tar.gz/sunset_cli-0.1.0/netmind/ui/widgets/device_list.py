"""Device list widget — clickable sidebar.

Each connected device is clickable to open an SSH session.
The "+ ADD NODE" button at the bottom opens the add-node modal.
Shows an image logo from assets/logo.png if present, else a text logo.
"""

from pathlib import Path
from typing import Optional

from textual.app import ComposeResult
from textual.containers import VerticalScroll
from textual.message import Message
from textual.reactive import reactive
from textual.widget import Widget
from textual.widgets import Static

# Import before app runs (required by textual-image for terminal capability detection)
try:
    from textual_image.widget import Image as ImageWidget
except Exception:
    ImageWidget = None

# Text logo when no image is available
DEFAULT_LOGO = "═══ SUNSET ═══\n network automation"


def _logo_path() -> Optional[Path]:
    """Resolve path to logo image. Prefer assets/logo.png from cwd or project root."""
    for base in (Path.cwd(), Path(__file__).resolve().parents[3]):
        for name in ("logo.png", "logo.jpg", "logo.jpeg", "logo.webp"):
            p = base / "assets" / name
            if p.exists():
                return p
    return None


class DeviceListItem(Static):
    """A single device entry. Click a connected device to open SSH."""

    class Clicked(Message):
        """Posted when a connected device item is clicked."""

        def __init__(self, device_id: str) -> None:
            super().__init__()
            self.device_id = device_id

    DEFAULT_CSS = """
    DeviceListItem {
        height: 1;
        padding: 0 1;
        color: #5a5a7c;
    }
    DeviceListItem.connected {
        color: #00ff41;
    }
    DeviceListItem.connected:hover {
        background: #1a1a2e;
        color: #00ffff;
    }
    DeviceListItem.disconnected {
        color: #3a3a5c;
    }
    DeviceListItem.error {
        color: #ff1744;
    }
    DeviceListItem.detail {
        color: #5a5a7c;
        height: 1;
    }
    """

    def __init__(self, text: str, device_id: str = "", **kwargs) -> None:
        super().__init__(text, **kwargs)
        self.device_id = device_id

    def on_click(self) -> None:
        if self.device_id and "connected" in self.classes:
            self.post_message(self.Clicked(self.device_id))


class AddNodeButton(Static):
    """Clickable '+ ADD NODE' button at the bottom of the device list."""

    class Clicked(Message):
        """Posted when the add-node button is clicked."""

    DEFAULT_CSS = """
    AddNodeButton {
        height: 1;
        padding: 0 1;
        color: #3a3a5c;
        margin-top: 1;
    }
    AddNodeButton:hover {
        background: #1a1a2e;
        color: #00ffff;
    }
    """

    def __init__(self, **kwargs) -> None:
        super().__init__(" + ADD NODE", **kwargs)

    def on_click(self) -> None:
        self.post_message(self.Clicked())


class DeviceList(Widget):
    """Widget displaying all connected network devices with topology info."""

    DEFAULT_CSS = """
    DeviceList {
        height: 1fr;
        background: #0c0c18;
        padding: 0;
    }

    DeviceList #device-scroll {
        height: 1fr;
    }

    DeviceList .device-list-header {
        text-style: bold;
        padding: 0 1;
        color: #00ffff;
        height: 1;
    }

    DeviceList #app-logo {
        height: auto;
        max-height: 10;
        padding: 1 0;
    }

    DeviceList .app-logo-text {
        padding: 0 1;
        color: #00ffff;
        text-style: bold;
    }

    DeviceList .no-devices {
        padding: 0 1;
        color: #2a2a4c;
    }
    """

    devices: reactive[list] = reactive(list, always_update=True)

    def compose(self) -> ComposeResult:
        logo_path = _logo_path()
        if logo_path is not None and ImageWidget is not None:
            try:
                yield ImageWidget(str(logo_path), id="app-logo")
            except Exception:
                yield Static(DEFAULT_LOGO, id="app-logo", classes="app-logo-text")
        else:
            yield Static(DEFAULT_LOGO, id="app-logo", classes="app-logo-text")
        yield Static(
            " NODES \u2500\u2500 click to SSH",
            classes="device-list-header",
        )
        yield VerticalScroll(id="device-scroll")

    def watch_devices(self, devices: list) -> None:
        self._refresh_list()

    def _refresh_list(self) -> None:
        try:
            container = self.query_one("#device-scroll", VerticalScroll)
            container.remove_children()

            if not self.devices:
                container.mount(
                    Static(
                        "  No nodes registered.",
                        classes="no-devices",
                    )
                )
            else:
                for dev in self.devices:
                    status = dev.get("status", "disconnected")
                    hostname = dev.get("hostname") or dev.get("device_id", "?")
                    host = dev.get("host", "?")
                    os_ver = dev.get("os_version", "")
                    did = dev.get("device_id", "?")
                    role = dev.get("role")
                    iface_count = dev.get("interface_count", 0)
                    neighbor_ids = dev.get("neighbor_ids", [])
                    priv = dev.get("privilege_level", -1)

                    if status == "connected":
                        icon = "\u25cf"
                    elif status == "error":
                        icon = "\u25c9"
                    else:
                        icon = "\u25cb"

                    line = f" {icon} {did:<5} {host}"
                    item = DeviceListItem(
                        line, device_id=did, classes=status,
                    )
                    container.mount(item)

                    detail_parts = []
                    if hostname and hostname != did:
                        detail_parts.append(hostname)
                    if os_ver:
                        detail_parts.append(os_ver)
                    if detail_parts:
                        sep = " \u00b7 "
                        container.mount(
                            DeviceListItem(
                                f"   {sep.join(detail_parts)}",
                                classes="detail",
                            )
                        )

                    topo_parts = []
                    if iface_count > 0:
                        topo_parts.append(f"{iface_count}if")
                    if neighbor_ids:
                        nbr_str = ",".join(neighbor_ids)
                        topo_parts.append(f"\u2192{nbr_str}")
                    if role:
                        topo_parts.append(role)
                    if 0 <= priv < 15:
                        topo_parts.append(f"priv:{priv}")
                    if topo_parts:
                        sep = " \u00b7 "
                        container.mount(
                            DeviceListItem(
                                f"   {sep.join(topo_parts)}",
                                classes="detail",
                            )
                        )

            # Always show the add button at the bottom
            container.mount(AddNodeButton())

        except Exception:
            pass
