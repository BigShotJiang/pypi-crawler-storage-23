"""Device management screen — cyberpunk neon style.

UPPERCASE labels, neon form styling, box-drawing borders.
Terse status messages, terminal voice.
"""

from textual import on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical, VerticalScroll
from textual.screen import Screen
from textual.widgets import Button, Footer, Input, Label, Select, Static

from netmind.core.device_connection import DeviceConnectionError
from netmind.core.device_manager import DeviceManager
from netmind.models import DeviceType


class DeviceManagerScreen(Screen):
    """Screen for managing device connections."""

    BINDINGS = [
        Binding("escape", "pop_screen", "Back", show=True),
    ]

    DEFAULT_CSS = """
    DeviceManagerScreen {
        layout: vertical;
        background: #0a0a14;
    }

    #dm-title {
        text-style: bold;
        text-align: center;
        padding: 1;
        background: #0e0e1a;
        color: #00ffff;
        dock: top;
        height: 3;
    }

    #dm-content {
        layout: horizontal;
        height: 1fr;
    }

    #add-device-panel {
        width: 1fr;
        background: #0e0e1a;
        border: solid #1a1a2e;
        padding: 1 2;
    }

    #device-panel {
        width: 1fr;
        background: #0e0e1a;
        border: solid #1a1a2e;
        padding: 1 2;
    }

    .form-label {
        margin-top: 1;
        color: #5a5a7c;
        text-style: bold;
    }

    .form-section-title {
        color: #00ffff;
        text-style: bold;
    }

    .form-input {
        margin-bottom: 0;
        background: #0a0a14;
        color: #00ffff;
    }

    #dm-buttons {
        margin-top: 1;
        height: 3;
    }

    #dm-buttons Button {
        margin-right: 1;
    }

    #dm-status {
        margin-top: 1;
        height: 2;
        color: #5a5a7c;
    }

    .device-entry {
        height: 2;
        padding: 0 1;
        background: #0a0a14;
        margin-bottom: 1;
    }

    .device-entry.connected {
        color: #00ff41;
    }

    .device-entry.error {
        color: #ff1744;
    }

    .device-entry.disconnected {
        color: #3a3a5c;
    }

    .panel-title {
        color: #00ffff;
        text-style: bold;
        padding: 0 0 1 0;
    }

    .no-devices-msg {
        color: #2a2a4c;
        padding: 1;
    }
    """

    def __init__(self, device_manager: DeviceManager) -> None:
        super().__init__()
        self.device_manager = device_manager

    def compose(self) -> ComposeResult:
        yield Static("┌─── DEVICE MANAGER ─── SSH CONNECTION CONTROL ───┐", id="dm-title")

        with Container(id="dm-content"):
            # Left panel: Add device form
            with Vertical(id="add-device-panel"):
                yield Label("╔═ ADD NEW NODE ═══════════════════╗", classes="form-section-title")
                yield Label("DEVICE ID:", classes="form-label")
                yield Input(placeholder="R1", id="input-device-id", classes="form-input")
                yield Label("HOST:", classes="form-label")
                yield Input(placeholder="192.168.1.1", id="input-host", classes="form-input")
                yield Label("USERNAME:", classes="form-label")
                yield Input(placeholder="admin", id="input-username", classes="form-input")
                yield Label("PASSWORD:", classes="form-label")
                yield Input(placeholder="********", password=True, id="input-password", classes="form-input")
                yield Label("SSH PORT:", classes="form-label")
                yield Input(placeholder="22", value="22", id="input-port", classes="form-input")
                yield Label("DEVICE TYPE:", classes="form-label")
                yield Select(
                    [(dt.value, dt.value) for dt in DeviceType],
                    value=DeviceType.CISCO_IOS.value,
                    id="device-type-select",
                )
                with Horizontal(id="dm-buttons"):
                    yield Button("CONNECT", variant="primary", id="btn-connect")
                    yield Button("TEST", variant="default", id="btn-test")
                yield Static("", id="dm-status")

            # Right panel: Connected devices
            with Vertical(id="device-panel"):
                yield Static("╔═ CONNECTED NODES ════════════════╗", classes="panel-title")
                yield VerticalScroll(id="device-list-scroll")

        yield Footer()

    def on_mount(self) -> None:
        self._refresh_device_list()
        self.query_one("#input-device-id", Input).focus()

    @on(Button.Pressed, "#btn-connect")
    async def on_connect_pressed(self) -> None:
        """Handle connect button press."""
        device_id, host, username, password, port, device_type = self._get_form_values()

        if not all([device_id, host, username, password]):
            self._set_status("REQUIRED FIELDS MISSING", error=True)
            return

        self._set_status(f"ESTABLISHING SSH TO {host}...")

        try:
            self.device_manager.add_device(
                device_id=device_id,
                host=host,
                username=username,
                password=password,
                device_type=DeviceType(device_type),
                port=int(port),
            )
            self._set_status(f"CONNECTED: {device_id} ({host})")
            self._clear_form()
            self._refresh_device_list()

        except DeviceConnectionError as e:
            self._set_status(f"CONNECTION FAILED: {e}", error=True)
        except ValueError as e:
            self._set_status(f"INVALID INPUT: {e}", error=True)
        except Exception as e:
            self._set_status(f"ERROR: {e}", error=True)

    @on(Button.Pressed, "#btn-test")
    async def on_test_pressed(self) -> None:
        """Handle test connection button press."""
        device_id, host, username, password, port, device_type = self._get_form_values()

        if not all([host, username, password]):
            self._set_status("PROVIDE HOST, USERNAME, PASSWORD", error=True)
            return

        self._set_status(f"PROBING {host}...")

        try:
            from netmiko import ConnectHandler

            conn = ConnectHandler(
                device_type=device_type,
                host=host,
                port=int(port),
                username=username,
                password=password,
                timeout=10,
            )
            output = conn.send_command("show version")
            conn.disconnect()
            self._set_status(f"HANDSHAKE OK ── {host} reachable")
        except Exception as e:
            self._set_status(f"PROBE FAILED: {e}", error=True)

    def _get_form_values(self) -> tuple[str, str, str, str, str, str]:
        """Read all form input values."""
        device_id = self.query_one("#input-device-id", Input).value.strip()
        host = self.query_one("#input-host", Input).value.strip()
        username = self.query_one("#input-username", Input).value.strip()
        password = self.query_one("#input-password", Input).value
        port = self.query_one("#input-port", Input).value.strip() or "22"
        device_type = self.query_one("#device-type-select", Select).value or DeviceType.CISCO_IOS.value
        return device_id, host, username, password, port, device_type

    def _clear_form(self) -> None:
        """Clear all form inputs."""
        self.query_one("#input-device-id", Input).value = ""
        self.query_one("#input-host", Input).value = ""
        self.query_one("#input-username", Input).value = ""
        self.query_one("#input-password", Input).value = ""
        self.query_one("#input-port", Input).value = "22"

    def _set_status(self, message: str, error: bool = False) -> None:
        """Update the status message."""
        status_widget = self.query_one("#dm-status", Static)
        if error:
            status_widget.update(f" !! {message}")
            status_widget.styles.color = "#ff1744"
        else:
            status_widget.update(f" >> {message}")
            status_widget.styles.color = "#00ff41"

    def _refresh_device_list(self) -> None:
        """Refresh the connected devices panel."""
        try:
            scroll = self.query_one("#device-list-scroll", VerticalScroll)
            scroll.remove_children()

            devices = self.device_manager.get_devices_summary()
            if not devices:
                scroll.mount(Static(" No nodes registered.", classes="no-devices-msg"))
                return

            for dev in devices:
                status = dev.get("status", "disconnected")
                did = dev.get("device_id", "?")
                hostname = dev.get("hostname") or "?"
                host = dev.get("host", "?")
                os_ver = dev.get("os_version", "?")

                if status == "connected":
                    icon = "●"
                elif status == "error":
                    icon = "◉"
                else:
                    icon = "○"

                text = f" {icon} {did:<6} │ {hostname:<14} │ {host:<15} │ IOS {os_ver}"
                entry = Static(text, classes=f"device-entry {status}")
                scroll.mount(entry)
        except Exception:
            pass

    def action_pop_screen(self) -> None:
        """Go back to main screen."""
        self.app.pop_screen()
