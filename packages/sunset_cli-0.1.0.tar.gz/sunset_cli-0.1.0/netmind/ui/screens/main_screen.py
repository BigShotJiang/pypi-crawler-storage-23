"""Main interaction screen — compact layout.

Device list on the left, chat on the right,
single-line header, input bar near the bottom.
"""

from textual import on, work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal, Vertical
from textual.screen import Screen
from textual.widgets import Footer, Input

from netmind.agent import (
    ClaudeAgent,
    DoneEvent,
    ErrorEvent,
    TextEvent,
    ToolCallEvent,
    ToolResultEvent,
)
from netmind.ui.widgets import ChatPanel, DeviceList, StatusBar
from netmind.ui.widgets.device_list import AddNodeButton, DeviceListItem


class MainScreen(Screen):
    """Primary chat interface with the Claude agent."""

    BINDINGS = [
        Binding("ctrl+d", "push_device_manager", "Devices", show=True),
        Binding("ctrl+a", "run_discovery", "Discover", show=True),
        Binding("ctrl+r", "toggle_mode", "Toggle Mode", show=True),
        Binding("ctrl+l", "clear_chat", "Clear", show=True),
        Binding("ctrl+q", "app.quit", "Quit", show=True),
    ]

    DEFAULT_CSS = """
    MainScreen {
        layout: vertical;
        background: #0a0a14;
    }

    MainScreen #body {
        height: 1fr;
    }

    MainScreen #sidebar {
        width: 38;
        height: 1fr;
        background: #0c0c18;
        border-right: solid #1a1a2e;
    }

    MainScreen #main-area {
        height: 1fr;
        width: 1fr;
    }

    MainScreen #input-bar {
        height: 3;
        background: #0e0e1a;
        padding: 0;
        margin: 0 0 1 0;
    }

    MainScreen #chat-input {
        background: #12122a;
        color: #e0e0ff;
        border: tall #1a1a2e;
        padding: 0 1;
        width: 1fr;
        height: 3;
    }
    MainScreen #chat-input:focus {
        border: tall #00ffff;
        color: #ffffff;
    }
    MainScreen #chat-input > .input--cursor {
        background: #00ffff;
        color: #0a0a14;
    }
    MainScreen #chat-input > .input--placeholder {
        color: #3a3a5c;
    }
    """

    def __init__(self, agent: ClaudeAgent) -> None:
        super().__init__()
        self.agent = agent
        self._processing = False

    def compose(self) -> ComposeResult:
        yield StatusBar()
        with Horizontal(id="body"):
            with Vertical(id="sidebar"):
                yield DeviceList(id="device-list")
            with Vertical(id="main-area"):
                yield ChatPanel(id="chat-panel")
                yield Container(
                    Input(placeholder="> enter command...", id="chat-input"),
                    id="input-bar",
                )
        yield Footer()

    def on_mount(self) -> None:
        """Initialize screen state."""
        self._update_status()
        self._update_device_list()

        chat = self.query_one("#chat-panel", ChatPanel)
        chat.add_system_message("BOOT SEQUENCE COMPLETE")
        chat.add_system_message(
            "Network automation agent initialized. "
            "Add nodes with Ctrl+D, then issue commands."
        )
        if self.agent.read_only:
            chat.add_system_message(
                "MODE: LOCKED (read-only). Press Ctrl+R to arm configuration changes."
            )

        # Show inventory and topology load results
        app = self.app
        inv_success = getattr(app, "_inventory_success", 0)
        inv_errors = getattr(app, "_inventory_errors", [])
        topo_nodes = getattr(app, "_topology_nodes", 0)
        topo_links = getattr(app, "_topology_links", 0)

        if inv_success > 0:
            chat.add_system_message(
                f"INVENTORY: {inv_success} node(s) connected via SSH."
            )
        if topo_nodes > 0:
            chat.add_system_message(
                f"TOPOLOGY: {topo_nodes} nodes, {topo_links} links loaded. "
                f"Agent has full network map."
            )
        if inv_errors:
            for err in inv_errors:
                chat.add_system_message(f"INVENTORY ERROR: {err}")

        # Warn about low-privilege connections
        dm = getattr(app, "device_manager", None)
        if dm is not None:
            for dev_id, conn in dm._devices.items():
                pl = conn.privilege_level
                if 0 <= pl < 15:
                    chat.add_system_message(
                        f"WARNING: {dev_id} connected at privilege level {pl} "
                        f"(need 15 for config). Set enable_secret in inventory "
                        f"and ensure the router has an enable secret configured."
                    )

        # Suggest auto-discovery if inventory has no interface data
        needs_discovery = getattr(app, "_needs_discovery", False)
        if needs_discovery:
            chat.add_system_message(
                "NOTICE: Inventory has devices but no interface/topology data. "
                "Press Ctrl+A to run auto-discovery (SSH scan of all devices)."
            )

        # Focus the input
        self.query_one("#chat-input", Input).focus()

    @on(Input.Submitted, "#chat-input")
    async def on_input_submitted(self, event: Input.Submitted) -> None:
        """Handle user message submission."""
        message = event.value.strip()
        if not message or self._processing:
            return

        input_widget = self.query_one("#chat-input", Input)
        input_widget.value = ""

        chat = self.query_one("#chat-panel", ChatPanel)
        chat.add_user_message(message)

        self._send_to_agent(message)

    @work(exclusive=True, thread=False)
    async def _send_to_agent(self, message: str) -> None:
        """Send message to Claude agent and stream responses."""
        self._processing = True
        self._update_status()

        chat = self.query_one("#chat-panel", ChatPanel)
        status = self.query_one(StatusBar)
        status.is_processing = True

        try:
            full_text_parts: list[str] = []

            async for event in self.agent.process_message(message):
                if isinstance(event, TextEvent):
                    full_text_parts.append(event.text)

                elif isinstance(event, ToolCallEvent):
                    chat.add_tool_call(event.tool_name, event.tool_input)

                elif isinstance(event, ToolResultEvent):
                    chat.add_tool_result(event.tool_name, event.result)

                elif isinstance(event, ErrorEvent):
                    chat.add_error(event.error)

                elif isinstance(event, DoneEvent):
                    full_text = "".join(full_text_parts)
                    if full_text.strip():
                        chat.add_assistant_text(full_text)
                    break

        except Exception as e:
            chat.add_error(f"AGENT FAULT: {e}")

        finally:
            self._processing = False
            status.is_processing = False
            self._update_device_list()

    def on_screen_resume(self) -> None:
        """Called when this screen becomes active again (e.g. after popping DeviceManager)."""
        self._update_device_list()
        self._update_status()

    @on(DeviceListItem.Clicked)
    def on_device_clicked(self, event: DeviceListItem.Clicked) -> None:
        """Open an SSH terminal to the clicked device."""
        dm = self.agent.device_manager
        conn = dm.get_device(event.device_id)
        if conn is None:
            chat = self.query_one("#chat-panel", ChatPanel)
            chat.add_system_message(
                f"Cannot open SSH to {event.device_id} — not connected."
            )
            return

        from netmind.ui.screens.ssh_screen import SSHScreen

        self.app.push_screen(SSHScreen(event.device_id, conn, self.agent))

    @on(AddNodeButton.Clicked)
    @work
    async def on_add_node_clicked(self) -> None:
        """Open the Add Node modal, save to inventory, and connect."""
        from netmind.core.topology import TopologyNode
        from netmind.models import DeviceType
        from netmind.ui.screens.add_node_screen import AddNodeScreen
        from netmind.utils.inventory import save_device_to_inventory

        result = await self.app.push_screen_wait(AddNodeScreen())
        if result is None:
            return

        chat = self.query_one("#chat-panel", ChatPanel)
        device_id = result["id"]

        # 1. Save to inventory file
        try:
            inv_path = save_device_to_inventory(result)
            chat.add_system_message(
                f"INVENTORY: Saved {device_id} to {inv_path}"
            )
        except Exception as e:
            chat.add_system_message(
                f"INVENTORY ERROR: Could not save {device_id} — {e}"
            )

        # 2. Connect via SSH
        dm = self.agent.device_manager
        ssh_options = None
        if result.get("legacy_ssh"):
            ssh_options = {"disabled_algorithms": {"kex": [], "pubkeys": [], "keys": []}}

        try:
            device_type = DeviceType(result.get("device_type", "cisco_ios"))
            conn = dm.add_device(
                device_id=device_id,
                host=result["host"],
                username=result["username"],
                password=result["password"],
                device_type=device_type,
                port=result.get("port", 22),
                enable_secret=result.get("enable_secret"),
                ssh_options=ssh_options,
            )

            # Add topology node
            topo_node = TopologyNode(
                device_id=device_id,
                host=result["host"],
                device_type=result.get("device_type", "cisco_ios"),
                role="router",
            )
            dm.topology.add_node(topo_node)

            info = conn.device.info
            priv = conn.privilege_level
            chat.add_system_message(
                f"CONNECTED: {device_id} ({info.hostname}) — "
                f"priv {priv}, {info.os_version or 'unknown OS'}"
            )
            if 0 <= priv < 15:
                chat.add_system_message(
                    f"WARNING: {device_id} at privilege {priv} "
                    f"(need 15 for config). Set enable_secret."
                )
        except Exception as e:
            chat.add_system_message(
                f"SSH ERROR: Could not connect to {device_id} — {e}"
            )

        # 3. Refresh UI
        self._update_device_list()
        self._update_status()

    def action_push_device_manager(self) -> None:
        """Open the device manager screen."""
        from netmind.ui.screens.device_manager import DeviceManagerScreen

        self.app.push_screen(DeviceManagerScreen(self.agent.device_manager))

    def action_run_discovery(self) -> None:
        """Run auto-discovery on all connected devices."""
        chat = self.query_one("#chat-panel", ChatPanel)
        dm = self.agent.device_manager

        if dm.connected_count == 0:
            chat.add_system_message(
                "DISCOVERY: No connected devices. Add devices first (Ctrl+D)."
            )
            return

        chat.add_system_message(
            f"DISCOVERY: Scanning {dm.connected_count} device(s)... "
            "Interfaces, OSPF, CDP/LLDP neighbors."
        )

        # Run discovery in a background worker to avoid blocking the UI
        self._run_discovery_worker()

    @work(exclusive=False, thread=True)
    def _run_discovery_worker(self) -> None:
        """Background worker for auto-discovery (runs in thread)."""
        dm = self.agent.device_manager

        try:
            results, node_count, link_count = dm.run_discovery()

            # Update the agent's topology reference
            self.agent.topology = dm.topology

            # Schedule UI updates on the main thread
            self.app.call_from_thread(
                self._on_discovery_complete, results, node_count, link_count
            )
        except Exception as e:
            self.app.call_from_thread(
                self._on_discovery_error, str(e)
            )

    def _on_discovery_complete(
        self, results: list, node_count: int, link_count: int
    ) -> None:
        """Handle discovery completion — update UI."""
        chat = self.query_one("#chat-panel", ChatPanel)

        # Show per-device results
        total_ifaces = 0
        total_errors = 0
        for r in results:
            total_ifaces += len(r.interfaces)
            total_errors += len(r.errors)
            chat.add_system_message(f"DISCOVERED: {r.summary}")

        # Summary
        chat.add_system_message(
            f"DISCOVERY COMPLETE: {node_count} nodes, {link_count} links, "
            f"{total_ifaces} interfaces found."
        )

        if total_errors > 0:
            chat.add_system_message(
                f"DISCOVERY: {total_errors} non-critical error(s). "
                "Some data may be partial."
            )

        chat.add_system_message(
            "Agent now has full topology context. "
            "Try: 'show me the topology' or 'configure OSPF'."
        )

        # Refresh the device list
        self._update_device_list()
        self._update_status()

    def _on_discovery_error(self, error: str) -> None:
        """Handle discovery failure."""
        chat = self.query_one("#chat-panel", ChatPanel)
        chat.add_error(f"DISCOVERY FAILED: {error}")

    def action_toggle_mode(self) -> None:
        """Toggle between read-only and interactive mode."""
        self.agent.read_only = not self.agent.read_only
        self._update_status()

        chat = self.query_one("#chat-panel", ChatPanel)
        if self.agent.read_only:
            chat.add_system_message("MODE: LOCKED ── Read-only active")
        else:
            chat.add_system_message("MODE: ARMED ── Configuration changes enabled")

    def action_clear_chat(self) -> None:
        """Clear the chat panel and conversation history."""
        chat = self.query_one("#chat-panel", ChatPanel)
        chat.clear()
        self.agent.clear_conversation()
        chat.add_system_message("MEMORY PURGED ── Conversation cleared")

    def _update_status(self) -> None:
        """Update the status bar."""
        try:
            status = self.query_one(StatusBar)
            status.read_only = self.agent.read_only
            status.device_count = self.agent.device_manager.device_count
            status.connected_count = self.agent.device_manager.connected_count
        except Exception:
            pass

    def _update_device_list(self) -> None:
        """Update the device list widget."""
        try:
            device_list = self.query_one("#device-list", DeviceList)
            device_list.devices = self.agent.device_manager.get_devices_summary()
        except Exception:
            pass
