"""Interactive SSH terminal screen with optional LLM side-panel.

Custom Terminal widget captures keystrokes and sends them directly to
the SSH channel.  A background reader thread streams device output back
continuously.  The result is a real terminal: device prompts, echo,
empty enters, backspace, tab-completion, and ``?`` help all work.

Ctrl+K toggles an LLM chat panel on the right, scoped to this device.
"""

import time
import threading
from typing import Optional

from textual import on, work
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.events import Key
from textual.message import Message
from textual.screen import Screen
from textual.widgets import Footer, Input, Markdown, Static

from rich.text import Text

from netmind.agent import (
    ClaudeAgent,
    DoneEvent,
    ErrorEvent,
    TextEvent,
    ToolCallEvent,
    ToolResultEvent,
)
from netmind.core.device_connection import DeviceConnection
from netmind.ui.widgets.chat_panel import copy_to_clipboard


# ───────────────────────────────────────────────────────────────────────────
# Terminal widget
# ───────────────────────────────────────────────────────────────────────────

MAX_SCROLLBACK = 2000


class Terminal(VerticalScroll, can_focus=True):
    """Terminal emulator widget.

    Single Static inside a VerticalScroll — content grows from the top,
    the prompt sits right after the last output line (like a real terminal).
    Scrollback is capped at MAX_SCROLLBACK lines for bounded render cost.
    Only the visible tail is re-rendered on each update.
    """

    _PASSTHROUGH = frozenset({"escape", "ctrl+k", "ctrl+l", "ctrl+q"})

    _KEY_MAP: dict[str, str] = {
        "enter": "\n",
        "tab": "\t",
        "backspace": "\x7f",
        "delete": "\x1b[3~",
        "up": "\x1b[A",
        "down": "\x1b[B",
        "right": "\x1b[C",
        "left": "\x1b[D",
        "home": "\x01",
        "end": "\x05",
        "space": " ",
    }

    DEFAULT_CSS = """
    Terminal {
        height: 1fr;
        width: 1fr;
        background: #000000;
        scrollbar-size: 1 1;
        scrollbar-color: #222222;
        scrollbar-color-hover: #444444;
        scrollbar-color-active: #666666;
    }
    Terminal > #term-content {
        width: 1fr;
        height: auto;
        background: #000000;
        color: #d0d0d0;
        padding: 0;
    }
    """

    class TermData(Message):
        def __init__(self, data: str) -> None:
            super().__init__()
            self.data = data

    def __init__(self, **kwargs) -> None:
        super().__init__(**kwargs)
        self._lines: list[str] = []
        self._cur: str = ""
        self._dirty = True

    def compose(self) -> ComposeResult:
        yield Static("", id="term-content")

    def feed(self, data: str) -> None:
        """Ingest raw data from the SSH channel."""
        data = data.replace("\r\n", "\n")
        i, n = 0, len(data)
        while i < n:
            c = data[i]

            if c == "\x1b" and i + 1 < n and data[i + 1] == "[":
                j = i + 2
                while j < n and (data[j].isdigit() or data[j] in ";?"):
                    j += 1
                if j < n and data[j].isalpha():
                    seq = data[i : j + 1]
                    if seq[-1] == "m":
                        self._cur += seq
                    i = j + 1
                    continue
                i += 1
                continue

            if c == "\n":
                self._lines.append(self._cur)
                self._cur = ""
            elif c == "\r":
                self._cur = ""
            elif c == "\x08":
                if self._cur:
                    self._cur = self._cur[:-1]
            elif ord(c) >= 32 or c == "\t":
                self._cur += c
            i += 1

        if len(self._lines) > MAX_SCROLLBACK:
            self._lines = self._lines[-MAX_SCROLLBACK:]

        self._refresh()

    def info(self, text: str) -> None:
        for ln in text.split("\n"):
            self._lines.append(f"\x1b[38;2;98;114;164m{ln}\x1b[0m")
        self._refresh()

    def error(self, text: str) -> None:
        for ln in text.split("\n"):
            self._lines.append(f"\x1b[38;2;255;85;85m{ln}\x1b[0m")
        self._refresh()

    def clear(self) -> None:
        self._lines.clear()
        self._cur = ""
        self._refresh()

    def _refresh(self) -> None:
        buf = "\n".join(self._lines + [self._cur + "\x1b[0m\u2588"])
        try:
            self.query_one("#term-content", Static).update(
                Text.from_ansi(buf)
            )
            self.scroll_end(animate=False)
        except Exception:
            pass

    def on_key(self, event: Key) -> None:
        if event.key in self._PASSTHROUGH:
            return
        event.prevent_default()
        event.stop()
        payload = self._xlat(event)
        if payload is not None:
            self.post_message(self.TermData(payload))

    def _xlat(self, event: Key) -> Optional[str]:
        k = event.key
        if k in self._KEY_MAP:
            return self._KEY_MAP[k]
        if k.startswith("ctrl+"):
            c = k[5:]
            if len(c) == 1 and "a" <= c <= "z":
                return chr(ord(c) - ord("a") + 1)
            return None
        if event.character and len(event.character) == 1 and ord(event.character) >= 32:
            return event.character
        return None


# ───────────────────────────────────────────────────────────────────────────
# LLM panel widgets
# ───────────────────────────────────────────────────────────────────────────

class LLMMessage(Static):
    """LLM panel message with optional click-to-copy."""

    def __init__(self, renderable="", *, copyable_text: str = "", **kwargs):
        super().__init__(renderable, **kwargs)
        self._copyable_text = copyable_text

    def on_click(self) -> None:
        if self._copyable_text:
            if copy_to_clipboard(self._copyable_text):
                self.app.notify("Copied to clipboard", timeout=2)

    DEFAULT_CSS = """
    LLMMessage { height: auto; padding: 0 1; }
    LLMMessage.user { background: #151525; color: #e0e0f0; padding: 0 1; margin: 1 0 0 0; }
    LLMMessage.system { color: #555577; padding: 0 1; }
    LLMMessage.error { color: #ff4466; padding: 0 1; }
    LLMMessage.tool { color: #5a5a7c; padding: 0 1; }
    LLMMessage.copyable:hover { background: #12122a; }
    """


class LLMMarkdown(Markdown):
    """LLM panel markdown with clickable code blocks."""

    def on_click(self, event) -> None:
        """Copy code block to clipboard when a code fence is clicked."""
        try:
            widget, _ = self.screen.get_widget_at(event.screen_x, event.screen_y)
            target = widget
            while target is not None and target is not self:
                if type(target).__name__ == "MarkdownFence":
                    code = getattr(target, "code", "")
                    if code:
                        if copy_to_clipboard(code):
                            self.app.notify("Code copied!", timeout=2)
                    return
                target = target.parent
        except Exception:
            pass

    DEFAULT_CSS = """
    LLMMarkdown { background: transparent; padding: 0 1; margin: 0 0 1 0; }
    LLMMarkdown MarkdownH1 { color: #00e0e0; text-style: bold; margin: 1 0 0 0; padding: 0; background: transparent; border-bottom: none; }
    LLMMarkdown MarkdownH2 { color: #00cccc; text-style: bold; margin: 1 0 0 0; padding: 0; background: transparent; border-bottom: none; }
    LLMMarkdown MarkdownParagraph { color: #c0c0d8; margin: 0 0; }
    LLMMarkdown MarkdownFence { background: #0e0e1c; color: #a0d0a0; margin: 0 0; padding: 1 2; border: round #1e1e3a; }
    LLMMarkdown MarkdownFence:hover { border: round #00ffff 50%; }
    LLMMarkdown MarkdownBulletList { color: #c0c0d8; margin: 0; padding: 0; }
    LLMMarkdown MarkdownBulletListItem { color: #c0c0d8; }
    """


# ───────────────────────────────────────────────────────────────────────────
# SSH Screen
# ───────────────────────────────────────────────────────────────────────────

class SSHScreen(Screen):
    """Full-screen SSH terminal with optional LLM chat panel."""

    BINDINGS = [
        Binding("escape", "pop_screen", "Back", show=True),
        Binding("ctrl+k", "toggle_llm", "AI Chat", show=True),
        Binding("ctrl+l", "clear_term", "Clear", show=True),
        Binding("ctrl+q", "pop_screen", "Back", show=False),
    ]

    DEFAULT_CSS = """
    SSHScreen {
        layout: vertical;
        background: #000000;
    }

    SSHScreen #ssh-body {
        height: 1fr;
    }

    SSHScreen #term-pane {
        height: 1fr;
        width: 1fr;
        background: #000000;
    }

    /* ── LLM panel (right, hidden by default) ── */
    SSHScreen #llm-pane {
        display: none;
        width: 55;
        height: 1fr;
        background: #0a0a14;
        border-left: solid #1a1a2e;
    }
    SSHScreen #llm-pane.visible {
        display: block;
    }

    SSHScreen #llm-header {
        height: 1;
        background: #0e0e1a;
        color: #ff00ff;
        text-style: bold;
        padding: 0 1;
    }

    SSHScreen #llm-scroll {
        height: 1fr;
        background: #0a0a14;
    }

    SSHScreen #llm-input {
        background: #12122a;
        color: #e0e0ff;
        border: tall #1a1a2e;
        padding: 0 1;
        width: 1fr;
        height: 3;
    }
    SSHScreen #llm-input:focus {
        border: tall #ff00ff;
        color: #ffffff;
    }
    SSHScreen #llm-input > .input--cursor {
        background: #ff00ff;
        color: #0a0a14;
    }
    SSHScreen #llm-input > .input--placeholder {
        color: #3a3a5c;
    }
    """

    def __init__(
        self, device_id: str, connection: DeviceConnection, agent: ClaudeAgent,
    ) -> None:
        super().__init__()
        self.device_id = device_id
        self.connection = connection
        self.agent = agent
        self._llm_visible = False
        self._reader_active = True
        self._reader_paused = False

    # ── compose / mount ─────────────────────────────────────────

    def compose(self) -> ComposeResult:
        with Horizontal(id="ssh-body"):
            with Vertical(id="term-pane"):
                yield Terminal(id="terminal")

            with Vertical(id="llm-pane"):
                yield Static(
                    " AI ASSISTANT \u2500\u2500 Ctrl+K to close", id="llm-header",
                )
                yield VerticalScroll(id="llm-scroll")
                yield Input(
                    placeholder="ask the AI about this device...",
                    id="llm-input",
                )

        yield Footer()

    def on_mount(self) -> None:
        term = self.query_one("#terminal", Terminal)

        host = self.connection.device.host
        term.info(f"Connected to {host} ({self.device_id})")
        term.info("Type commands below. Ctrl+K for AI. Esc to exit.")
        term.info("")

        priv = self.connection.privilege_level
        if 0 <= priv < 15:
            term.error(
                f"*** Warning: privilege level {priv} "
                "\u2014 config commands may fail ***"
            )
            term.info("")

        term.focus()
        self._channel_reader()

    # ── SSH channel I/O ─────────────────────────────────────────

    @work(thread=True)
    def _channel_reader(self) -> None:
        """Background thread: read from the SSH channel with batching.

        Reads are accumulated over a short window (15 ms) so multiple
        small fragments are coalesced into a single UI update, cutting
        context switches by ~10x for large outputs.
        """
        conn = self.connection._connection
        if conn is not None:
            try:
                conn.write_channel("\n")
            except Exception:
                pass
            time.sleep(0.2)

        while self._reader_active:
            if self._reader_paused:
                time.sleep(0.05)
                continue
            conn = self.connection._connection
            if conn is None:
                break
            try:
                data = conn.read_channel()
                if data:
                    # Accumulate more data within a short window
                    time.sleep(0.015)
                    more = conn.read_channel()
                    if more:
                        data += more
                    self.app.call_from_thread(self._on_channel_data, data)
                else:
                    time.sleep(0.02)
            except Exception:
                break

    def _on_channel_data(self, data: str) -> None:
        try:
            self.query_one("#terminal", Terminal).feed(data)
        except Exception:
            pass

    @on(Terminal.TermData)
    def on_term_data(self, event: Terminal.TermData) -> None:
        """Forward keystrokes from the Terminal widget to the SSH channel."""
        conn = self.connection._connection
        if conn is None:
            try:
                self.query_one("#terminal", Terminal).error(
                    "*** Connection lost ***"
                )
            except Exception:
                pass
            return
        try:
            conn.write_channel(event.data)
        except Exception as e:
            try:
                self.query_one("#terminal", Terminal).error(f"*** Error: {e} ***")
            except Exception:
                pass

    # ── LLM panel toggle ────────────────────────────────────────

    def action_toggle_llm(self) -> None:
        pane = self.query_one("#llm-pane")
        self._llm_visible = not self._llm_visible
        if self._llm_visible:
            pane.add_class("visible")
            scroll = self.query_one("#llm-scroll", VerticalScroll)
            if not scroll.children:
                self._llm_system_msg(
                    f"AI assistant for {self.device_id}. "
                    "Ask questions or request commands."
                )
            self.query_one("#llm-input", Input).focus()
        else:
            pane.remove_class("visible")
            self.query_one("#terminal", Terminal).focus()

    # ── LLM input ────────────────────────────────────────────────

    @on(Input.Submitted, "#llm-input")
    def on_llm_submitted(self, event: Input.Submitted) -> None:
        msg = event.value.strip()
        if not msg:
            return

        inp = self.query_one("#llm-input", Input)
        inp.value = ""

        self._llm_user_msg(msg)

        scoped = (
            f"[Context: You are operating ONLY on device {self.device_id} "
            f"({self.connection.device.host}). "
            f"Any commands you call should target device_id=\"{self.device_id}\". "
            f"The user is in a direct SSH terminal to this device.]\n\n{msg}"
        )
        self._send_to_llm(scoped)

    @work(exclusive=True, thread=False)
    async def _send_to_llm(self, message: str) -> None:
        # Pause channel reader so Netmiko send_command() has exclusive access.
        self._reader_paused = True
        try:
            full_text_parts: list[str] = []
            async for event in self.agent.process_message(message):
                if isinstance(event, TextEvent):
                    full_text_parts.append(event.text)

                elif isinstance(event, ToolCallEvent):
                    cmd = event.tool_input.get("command", "")
                    tool_label = cmd if cmd else event.tool_name
                    self._llm_tool_msg(f"  > {tool_label}", copyable=cmd)

                elif isinstance(event, ToolResultEvent):
                    output = event.result.get("output", "")
                    if output:
                        self._llm_tool_msg(output[:300], copyable=output)

                elif isinstance(event, ErrorEvent):
                    self._llm_error_msg(event.error)

                elif isinstance(event, DoneEvent):
                    full_text = "".join(full_text_parts)
                    if full_text.strip():
                        self._llm_assistant_msg(full_text)
                    break
        except Exception as e:
            self._llm_error_msg(f"Agent error: {e}")
        finally:
            self._reader_paused = False

    # ── LLM panel helpers ────────────────────────────────────────

    def _llm_user_msg(self, text: str) -> None:
        content = Text()
        content.append("> ", style="bold #555577")
        content.append(text, style="#e0e0f0")
        self._llm_append(LLMMessage(content, classes="user"))

    def _llm_assistant_msg(self, text: str) -> None:
        self._llm_append_widget(LLMMarkdown(text))

    def _llm_tool_msg(self, text: str, copyable: str = "") -> None:
        self._llm_append(
            LLMMessage(text, classes="tool copyable", copyable_text=copyable or text)
        )

    def _llm_system_msg(self, text: str) -> None:
        self._llm_append(LLMMessage(text, classes="system"))

    def _llm_error_msg(self, text: str) -> None:
        self._llm_append(LLMMessage(text, classes="error"))

    def _llm_append(self, widget: Static) -> None:
        try:
            scroll = self.query_one("#llm-scroll", VerticalScroll)
            scroll.mount(widget)
            scroll.scroll_end(animate=False)
        except Exception:
            pass

    def _llm_append_widget(self, widget) -> None:
        try:
            scroll = self.query_one("#llm-scroll", VerticalScroll)
            scroll.mount(widget)
            scroll.scroll_end(animate=False)
        except Exception:
            pass

    # ── actions ──────────────────────────────────────────────────

    def action_clear_term(self) -> None:
        self.query_one("#terminal", Terminal).clear()

    def action_pop_screen(self) -> None:
        self._reader_active = False
        self.app.pop_screen()
