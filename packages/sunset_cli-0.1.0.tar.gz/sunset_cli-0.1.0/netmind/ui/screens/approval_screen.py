"""Configuration approval screen — cyberpunk neon style.

Dramatic warning aesthetic, double-line box borders,
terse confirmation language.
"""

import asyncio
from typing import Optional

from textual import on
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Center, Horizontal, Vertical
from textual.screen import ModalScreen
from textual.widgets import Button, Label, Static

from netmind.models import ApprovalRequest


class ApprovalScreen(ModalScreen[bool]):
    """Modal screen for reviewing and approving config changes.

    Returns True if approved, False if rejected.
    """

    BINDINGS = [
        Binding("a", "approve", "Approve", show=True),
        Binding("r", "reject", "Reject", show=True),
        Binding("escape", "reject", "Reject", show=False),
    ]

    DEFAULT_CSS = """
    ApprovalScreen {
        align: center middle;
        background: #0a0a14 80%;
    }

    #approval-container {
        width: 76;
        max-height: 32;
        background: #0e0e1a;
        border: double #ffb000;
        padding: 1 2;
    }

    #approval-header {
        text-style: bold;
        text-align: center;
        color: #ffb000;
        height: 3;
        content-align: center middle;
    }

    #approval-sep {
        color: #ffb000 50%;
        height: 1;
    }

    #approval-device {
        margin-top: 1;
        color: #00ffff;
        text-style: bold;
    }

    #approval-description {
        margin-bottom: 1;
        color: #5a5a7c;
    }

    #approval-commands {
        background: #0a0a14;
        border: solid #1a1a2e;
        padding: 1;
        margin-bottom: 1;
        max-height: 14;
        overflow-y: auto;
    }

    .command-line {
        color: #00ff41;
    }

    .commands-label {
        color: #5a5a7c;
        text-style: bold;
        margin-bottom: 1;
    }

    #approval-checkpoint {
        color: #0066ff;
        margin-bottom: 1;
    }

    #approval-warnings {
        color: #ffb000;
        margin-bottom: 1;
    }

    #approval-buttons {
        height: 3;
        align: center middle;
        margin-top: 1;
    }

    #approval-buttons Button {
        margin: 0 2;
        min-width: 20;
    }

    #approval-hint {
        text-align: center;
        color: #2a2a4c;
        margin-top: 1;
    }
    """

    def __init__(
        self,
        request: ApprovalRequest,
        warnings: Optional[list[str]] = None,
    ) -> None:
        super().__init__()
        self.request = request
        self.warnings = warnings or []

    def compose(self) -> ComposeResult:
        with Vertical(id="approval-container"):
            yield Static(
                "╔══════════════════════════════════════════════╗\n"
                "║       ◉ CONFIGURATION CHANGE DETECTED       ║\n"
                "╚══════════════════════════════════════════════╝",
                id="approval-header",
            )
            yield Static("═" * 70, id="approval-sep")

            yield Static(
                f"  TARGET: {self.request.device_id}",
                id="approval-device",
            )
            yield Static(
                f"  DESC:   {self.request.description}",
                id="approval-description",
            )

            # Commands display
            with Vertical(id="approval-commands"):
                yield Static("  PROPOSED COMMANDS:", classes="commands-label")
                for cmd in self.request.commands:
                    yield Static(f"    {cmd}", classes="command-line")

            # Checkpoint info
            if self.request.checkpoint_name:
                yield Static(
                    f"  CHECKPOINT: {self.request.checkpoint_name} ── rollback available",
                    id="approval-checkpoint",
                )

            # Warnings
            if self.warnings:
                warning_text = "\n".join(f"  !! {w}" for w in self.warnings)
                yield Static(warning_text, id="approval-warnings")

            # Buttons
            with Horizontal(id="approval-buttons"):
                yield Button("AUTHORIZE [a]", variant="success", id="btn-approve")
                yield Button("DENY [r]", variant="error", id="btn-reject")

            yield Static("press [a] to authorize  │  press [r] to deny", id="approval-hint")

    @on(Button.Pressed, "#btn-approve")
    def on_approve(self) -> None:
        self.request.approve()
        self.dismiss(True)

    @on(Button.Pressed, "#btn-reject")
    def on_reject(self) -> None:
        self.request.reject()
        self.dismiss(False)

    def action_approve(self) -> None:
        self.request.approve()
        self.dismiss(True)

    def action_reject(self) -> None:
        self.request.reject()
        self.dismiss(False)
