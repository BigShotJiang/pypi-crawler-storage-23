"""Main Textual application for NetMind.

Cyberpunk neon theme: cyan primary, magenta accents, deep dark backgrounds.
"""

import asyncio
from pathlib import Path
from typing import Optional

from textual.app import App
from textual.binding import Binding
from textual.design import ColorSystem

from netmind.agent.claude_agent import ClaudeAgent
from netmind.core.device_manager import DeviceManager
from netmind.core.safety import ApprovalManager, CheckpointManager, SafetyGuard
from netmind.models import ApprovalRequest
from netmind.ui.screens.approval_screen import ApprovalScreen
from netmind.ui.screens.license_screen import LicenseScreen
from netmind.ui.screens.main_screen import MainScreen
from netmind.ui.screens.setup_screen import SetupScreen
from netmind.utils import get_config, get_logger, setup_logging
from netmind.utils.license import check_license

logger = get_logger("ui.app")

# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
# Cyberpunk Neon color palette
# ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CYBER_DARK = ColorSystem(
    primary="#00ffff",
    secondary="#ff00ff",
    warning="#ffb000",
    error="#ff1744",
    success="#00ff41",
    accent="#0066ff",
    background="#0a0a14",
    surface="#12121f",
    panel="#0e0e1a",
    dark=True,
)


class NetMindApp(App):
    """NetMind - LLM-powered network automation TUI."""

    TITLE = "SUNSET"
    SUB_TITLE = "NETWORK AUTOMATION AGENT"

    BINDINGS = [
        Binding("ctrl+q", "quit", "Quit", show=False, priority=True),
        Binding("ctrl+c", "quit", "Quit", show=False, priority=True),
    ]

    CSS = """
    /* ═══════════════════════════════════════════════════════════
       SUNSET GLOBAL THEME — Cyberpunk Neon
       ═══════════════════════════════════════════════════════════ */

    Screen {
        background: #0a0a14;
    }

    /* ── Scrollbar styling ── */
    Scrollbar {
        background: #0e0e1a;
        color: #00ffff 40%;
    }
    ScrollBar > .scrollbar--bar {
        color: #00ffff 50%;
    }

    /* ── Input fields (forms only — chat input styled per-screen) ── */
    Input {
        background: #0e0e1a;
        color: #00ffff;
        border: tall #1a1a2e;
    }
    Input:focus {
        border: tall #00ffff;
    }
    Input > .input--placeholder {
        color: #3a3a5c;
    }
    #chat-input > .input--cursor {
        background: #00ffff;
        color: #0a0a14;
    }

    /* ── Buttons ── */
    Button {
        background: #1a1a2e;
        color: #00ffff;
        border: tall #1a1a2e;
        text-style: bold;
    }
    Button:hover {
        background: #00ffff 15%;
        border: tall #00ffff;
    }
    Button.-primary {
        background: #00ffff 15%;
        color: #00ffff;
        border: tall #00ffff 50%;
    }
    Button.-primary:hover {
        background: #00ffff 25%;
    }
    Button.-success {
        background: #00ff41 10%;
        color: #00ff41;
        border: tall #00ff41 50%;
    }
    Button.-success:hover {
        background: #00ff41 20%;
    }
    Button.-error {
        background: #ff1744 10%;
        color: #ff1744;
        border: tall #ff1744 50%;
    }
    Button.-error:hover {
        background: #ff1744 20%;
    }

    /* ── Select / dropdowns ── */
    Select {
        background: #0e0e1a;
        color: #00ffff;
        border: tall #1a1a2e;
    }
    Select:focus {
        border: tall #00ffff;
    }
    SelectOverlay {
        background: #12121f;
        color: #00ffff;
        border: tall #00ffff 50%;
    }
    SelectCurrent {
        background: #0e0e1a;
        color: #00ffff;
    }

    /* ── Footer ── */
    Footer {
        background: #0e0e1a;
        color: #3a3a5c;
    }
    Footer > .footer--key {
        background: #1a1a2e;
        color: #00ffff;
    }
    Footer > .footer--description {
        color: #3a3a5c;
    }

    /* ── Labels ── */
    Label {
        color: #7a7a9c;
    }

    /* ── OptionList ── */
    OptionList {
        background: #12121f;
        color: #00ffff;
        border: tall #1a1a2e;
    }
    OptionList:focus {
        border: tall #00ffff;
    }
    OptionList > .option-list--option-highlighted {
        background: #00ffff 15%;
    }
    """

    def get_css_variables(self) -> dict[str, str]:
        """Override CSS variables for the cyberpunk theme."""
        variables = super().get_css_variables()
        variables.update({
            "primary": "#00ffff",
            "secondary": "#ff00ff",
            "warning": "#ffb000",
            "error": "#ff1744",
            "success": "#00ff41",
            "accent": "#0066ff",
            "background": "#0a0a14",
            "surface": "#12121f",
            "panel": "#0e0e1a",
            "primary-background": "#1a1a2e",
            "text": "#c0c0e0",
            "text-muted": "#5a5a7c",
            "text-disabled": "#2a2a4c",
            "boost": "#15152a",
        })
        return variables

    def __init__(
        self,
        debug: bool = False,
        inventory_path: Optional[str] = None,
    ) -> None:
        super().__init__()
        self._debug = debug
        self._inventory_path = inventory_path
        self._config = get_config()

        # Setup logging
        log_level = "DEBUG" if debug else self._config.log_level
        setup_logging(
            level=log_level,
            log_file=str(Path.home() / ".sunset" / "logs" / "sunset.log") if debug else None,
            console=False,
        )

        # Core components are deferred until API key is available.
        self.device_manager: Optional[DeviceManager] = None
        self.agent: Optional[ClaudeAgent] = None

        if self._config.has_api_key:
            self._init_core()

        logger.info(
            "NetMindApp initialized (debug=%s, has_key=%s)",
            debug,
            self._config.has_api_key,
        )

    def _init_core(self) -> None:
        """Initialize core components (requires API key)."""
        self.device_manager = DeviceManager()
        self.safety_guard = SafetyGuard(read_only=self._config.read_only_default)
        self.approval_manager = ApprovalManager()
        self.checkpoint_manager = CheckpointManager(
            max_checkpoints=self._config.max_checkpoints,
        )
        self.agent = ClaudeAgent(
            device_manager=self.device_manager,
            safety_guard=self.safety_guard,
            approval_manager=self.approval_manager,
            checkpoint_manager=self.checkpoint_manager,
        )
        self.agent.set_approval_callback(self._handle_approval)

    async def _handle_approval(self, request: ApprovalRequest) -> None:
        """Handle an approval request by showing the approval screen."""
        _, warnings = self.safety_guard.validate_commands(request.commands)

        result = await self.push_screen_wait(
            ApprovalScreen(request, warnings=warnings)
        )

        if result:
            logger.info("Config approved for %s", request.device_id)
        else:
            logger.info("Config rejected for %s", request.device_id)

    def on_mount(self) -> None:
        """Called when the app is mounted."""
        if not self._config.has_api_key:
            logger.warning("No ANTHROPIC_API_KEY — showing setup screen")
            self.push_screen(SetupScreen(), callback=self._on_setup_complete)
            return

        self._check_license_and_start()

    def _check_license_and_start(self) -> None:
        """Validate license key before starting the main screen."""
        result = check_license()
        if not result.valid:
            error_map = {
                "no_key": "No license key configured.",
                "key_not_found": "Invalid license key.",
                "key_revoked": "This license has been revoked.",
                "key_expired": "This license has expired.",
            }
            error = error_map.get(result.error, result.error)
            logger.warning("License check failed: %s", result.error)
            self.push_screen(
                LicenseScreen(error=error),
                callback=self._on_license_dismiss,
            )
            return
        self._start_main()

    def _on_license_dismiss(self, result: None) -> None:
        """License screen was dismissed — exit the app."""
        self.exit()

    def _start_main(self) -> None:
        """Load inventory and push the main screen."""
        self._inventory_errors: list[str] = []
        self._inventory_success = 0
        self._load_inventory()
        self.push_screen(MainScreen(self.agent))

    async def _on_setup_complete(self, result: Optional[dict]) -> None:
        """Handle the setup screen result."""
        if result is None:
            self.exit()
            return

        from netmind.utils.config import save_env_file, reset_and_reload

        save_env_file({"ANTHROPIC_API_KEY": result["api_key"]})
        self._config = reset_and_reload()
        self._init_core()

        if result.get("node"):
            try:
                from netmind.utils.inventory import save_device_to_inventory
                save_device_to_inventory(result["node"])
            except Exception as exc:
                logger.warning("Failed to save initial node: %s", exc)

        self._check_license_and_start()

    def _load_inventory(self) -> None:
        """Load devices from inventory file (if present).

        Also passes the loaded topology to the Claude agent so it can
        use topology tools without SSH.
        """
        from netmind.utils.inventory import find_inventory_file

        # Determine the inventory path
        inv_path = self._inventory_path
        if inv_path is None:
            found = find_inventory_file()
            if found is None:
                return  # No inventory file — that's normal
            inv_path = str(found)

        logger.info("Loading inventory from %s", inv_path)
        success, errors = self.device_manager.load_from_inventory(inv_path)
        self._inventory_success = success
        self._inventory_errors = errors

        # Pass the topology to the agent
        topo = self.device_manager.topology
        self.agent.topology = topo
        self._topology_nodes = topo.node_count
        self._topology_links = topo.link_count

        if errors:
            for err in errors:
                logger.warning("Inventory load error: %s", err)

        # Detect if we have connected devices but no interface data
        self._needs_discovery = (
            success > 0
            and not self.device_manager.has_topology_data
        )

        logger.info(
            "Topology: %d nodes, %d links loaded (needs_discovery=%s)",
            topo.node_count,
            topo.link_count,
            self._needs_discovery,
        )

    async def action_quit(self) -> None:
        """Clean up and quit."""
        logger.info("Shutting down...")
        if self.device_manager is not None:
            self.device_manager.disconnect_all()
        self.exit()
