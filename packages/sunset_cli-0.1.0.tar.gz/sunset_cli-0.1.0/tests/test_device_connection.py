"""Tests for DeviceConnection and DeviceManager.

Uses mock Netmiko ConnectHandler to test connection lifecycle,
retry logic, and command execution without real SSH.
"""

import tempfile
from unittest.mock import MagicMock, patch, PropertyMock

import pytest

from netmind.core.device_connection import DeviceConnection, DeviceConnectionError
from netmind.core.device_manager import DeviceManager
from netmind.models import (
    CommandType,
    Device,
    DeviceCredentials,
    DeviceInfo,
    DeviceStatus,
    DeviceType,
)
from netmind.utils.session_logger import reset_session_logger, SessionLogger


# ── Fixtures ────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def _isolate_session_logger(tmp_path):
    """Ensure each test gets a fresh session logger."""
    reset_session_logger()
    with patch("netmind.utils.session_logger._instance", SessionLogger(log_dir=str(tmp_path))):
        yield
    reset_session_logger()


@pytest.fixture
def mock_config():
    config = MagicMock()
    config.ssh_timeout = 10
    config.command_timeout = 30
    return config


def _make_device(device_id="R1", host="192.168.1.1") -> Device:
    return Device(
        device_id=device_id,
        host=host,
        device_type=DeviceType.CISCO_IOS,
        credentials=DeviceCredentials(username="admin", password="secret"),
    )


# ── DeviceConnection Tests ──────────────────────────────────────


class TestDeviceConnectionInit:
    def test_initial_state(self, mock_config):
        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            device = _make_device()
            conn = DeviceConnection(device)
            assert conn.is_connected is False
            assert conn.device.status == DeviceStatus.DISCONNECTED

    def test_repr(self, mock_config):
        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            device = _make_device()
            conn = DeviceConnection(device)
            r = repr(conn)
            assert "R1" in r
            assert "192.168.1.1" in r


class TestDeviceConnectionConnect:
    def test_successful_connect(self, mock_config):
        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            device = _make_device()
            conn = DeviceConnection(device)

            mock_handler = MagicMock()
            mock_handler.send_command.return_value = (
                "Cisco IOS Software, IOSv Software, Version 15.9(3)M6\n"
                "router upance 5 days\n"
                "Cisco IOSv\n"
            )

            with patch("netmind.core.device_connection.ConnectHandler", return_value=mock_handler):
                result = conn.connect()

            assert result is True
            assert device.status == DeviceStatus.CONNECTED

    def test_auth_failure(self, mock_config):
        from netmiko.exceptions import NetmikoAuthenticationException

        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            device = _make_device()
            conn = DeviceConnection(device)

            with patch(
                "netmind.core.device_connection.ConnectHandler",
                side_effect=NetmikoAuthenticationException("Bad password"),
            ):
                with pytest.raises(DeviceConnectionError, match="Authentication failed"):
                    conn.connect()

            assert device.status == DeviceStatus.ERROR

    def test_timeout_failure(self, mock_config):
        from netmiko.exceptions import NetmikoTimeoutException

        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            device = _make_device()
            conn = DeviceConnection(device)

            with patch(
                "netmind.core.device_connection.ConnectHandler",
                side_effect=NetmikoTimeoutException("Timed out"),
            ):
                with pytest.raises(DeviceConnectionError, match="timed out"):
                    conn.connect()

            assert device.status == DeviceStatus.ERROR

    def test_generic_failure(self, mock_config):
        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            device = _make_device()
            conn = DeviceConnection(device)

            with patch(
                "netmind.core.device_connection.ConnectHandler",
                side_effect=OSError("Network unreachable"),
            ):
                with pytest.raises(DeviceConnectionError):
                    conn.connect()

            assert device.status == DeviceStatus.ERROR
            assert "Network unreachable" in device.connection_error


class TestDeviceConnectionExecute:
    @pytest.fixture
    def connected_conn(self, mock_config):
        """Create a DeviceConnection with a mocked active connection."""
        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            device = _make_device()
            conn = DeviceConnection(device)
            conn._connection = MagicMock()
            conn._connection.is_alive.return_value = True
            device.status = DeviceStatus.CONNECTED
            return conn

    def test_execute_show_command(self, connected_conn):
        connected_conn._connection.send_command.return_value = (
            "Interface  IP-Address  OK? Method Status Protocol\n"
            "Gi0/0      10.0.0.1    YES manual up     up\n"
        )

        result = connected_conn.execute_command("show ip interface brief")

        assert result.success is True
        assert result.command == "show ip interface brief"
        assert result.command_type == CommandType.SHOW
        assert "10.0.0.1" in result.output
        assert result.execution_time_ms > 0

    def test_execute_command_retry(self, connected_conn):
        """Command fails twice then succeeds on third attempt."""
        connected_conn._connection.send_command.side_effect = [
            Exception("Timeout 1"),
            Exception("Timeout 2"),
            "Success output",
        ]

        with patch("netmind.core.device_connection.time.sleep"):  # Skip retry delay
            result = connected_conn.execute_command("show version")

        assert result.success is True
        assert result.output == "Success output"
        assert connected_conn._connection.send_command.call_count == 3

    def test_execute_command_all_retries_fail(self, connected_conn):
        """Command fails all 3 retry attempts."""
        connected_conn._connection.send_command.side_effect = Exception("Permanent failure")

        with patch("netmind.core.device_connection.time.sleep"):
            result = connected_conn.execute_command("show version")

        assert result.success is False
        assert "Permanent failure" in result.error
        assert connected_conn._connection.send_command.call_count == 3

    def test_execute_config_commands(self, connected_conn):
        connected_conn._connection.send_config_set.return_value = (
            "R1(config)#router ospf 1\nR1(config-router)#end"
        )

        result = connected_conn.execute_config_commands(["router ospf 1"])

        assert result.success is True
        assert result.command_type == CommandType.CONFIG
        assert result.execution_time_ms > 0

    def test_execute_config_commands_failure(self, connected_conn):
        connected_conn._connection.send_config_set.side_effect = Exception("Config error")

        result = connected_conn.execute_config_commands(["bad command"])

        assert result.success is False
        assert "Config error" in result.error

    def test_get_running_config(self, connected_conn):
        connected_conn._connection.send_command.return_value = "hostname R1\n!\n"

        config = connected_conn.get_running_config()
        assert "hostname R1" in config

    def test_get_running_config_failure(self, connected_conn):
        connected_conn._connection.send_command.side_effect = Exception("Failed")

        # After all retries fail, get_running_config raises DeviceConnectionError
        with pytest.raises(DeviceConnectionError):
            with patch("netmind.core.device_connection.time.sleep"):
                connected_conn.get_running_config()

    def test_save_config(self, connected_conn):
        connected_conn._connection.save_config.return_value = "[OK]"

        result = connected_conn.save_config()
        assert result.success is True

    def test_save_config_failure(self, connected_conn):
        connected_conn._connection.save_config.side_effect = Exception("Write error")

        result = connected_conn.save_config()
        assert result.success is False

    def test_disconnect(self, connected_conn):
        connected_conn.disconnect()
        assert connected_conn.device.status == DeviceStatus.DISCONNECTED
        assert connected_conn._connection is None


class TestDeviceConnectionReconnect:
    def test_reconnects_when_connection_lost(self, mock_config):
        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            device = _make_device()
            conn = DeviceConnection(device)
            conn._connection = MagicMock()
            conn._connection.is_alive.return_value = False  # Connection dead

            # Mock reconnection
            new_handler = MagicMock()
            new_handler.send_command.return_value = "Version info"
            with patch("netmind.core.device_connection.ConnectHandler", return_value=new_handler):
                conn._ensure_connected()

            assert device.status == DeviceStatus.CONNECTED


# ── DeviceManager Tests ─────────────────────────────────────────


class TestDeviceManager:
    def test_initial_state(self):
        dm = DeviceManager()
        assert dm.device_count == 0
        assert dm.connected_count == 0
        assert dm.get_device_ids() == []

    def test_add_device(self, mock_config):
        dm = DeviceManager()

        mock_handler = MagicMock()
        mock_handler.send_command.return_value = "Cisco IOS Version 15.9"
        mock_handler.is_alive.return_value = True

        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            with patch("netmind.core.device_connection.ConnectHandler", return_value=mock_handler):
                conn = dm.add_device("R1", "192.168.1.1", "admin", "secret")

        assert dm.device_count == 1
        assert dm.get_device("R1") is not None

    def test_add_duplicate_device(self, mock_config):
        dm = DeviceManager()

        mock_handler = MagicMock()
        mock_handler.send_command.return_value = "Cisco IOS"
        mock_handler.is_alive.return_value = True

        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            with patch("netmind.core.device_connection.ConnectHandler", return_value=mock_handler):
                dm.add_device("R1", "192.168.1.1", "admin", "secret")
                with pytest.raises(ValueError, match="already exists"):
                    dm.add_device("R1", "192.168.1.2", "admin", "secret")

    def test_remove_device(self, mock_config):
        dm = DeviceManager()

        mock_handler = MagicMock()
        mock_handler.send_command.return_value = "Cisco IOS"

        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            with patch("netmind.core.device_connection.ConnectHandler", return_value=mock_handler):
                dm.add_device("R1", "192.168.1.1", "admin", "secret")

        assert dm.remove_device("R1") is True
        assert dm.device_count == 0
        assert dm.remove_device("R1") is False  # Already removed

    def test_execute_on_device_not_found(self):
        dm = DeviceManager()
        result = dm.execute_on_device("R99", "show version")
        assert result.success is False
        assert "not found" in result.error

    def test_execute_config_on_device_not_found(self):
        dm = DeviceManager()
        result = dm.execute_config_on_device("R99", ["router ospf 1"])
        assert result.success is False
        assert "not found" in result.error

    def test_get_devices_summary(self, mock_config):
        dm = DeviceManager()

        mock_handler = MagicMock()
        mock_handler.send_command.return_value = "Cisco IOS Software, Version 15.9"
        mock_handler.is_alive.return_value = True

        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            with patch("netmind.core.device_connection.ConnectHandler", return_value=mock_handler):
                dm.add_device("R1", "192.168.1.1", "admin", "secret")

        summary = dm.get_devices_summary()
        assert len(summary) == 1
        assert summary[0]["device_id"] == "R1"
        assert summary[0]["host"] == "192.168.1.1"

    def test_disconnect_all(self, mock_config):
        dm = DeviceManager()

        mock_handler = MagicMock()
        mock_handler.send_command.return_value = "Cisco IOS"

        with patch("netmind.core.device_connection.get_config", return_value=mock_config):
            with patch("netmind.core.device_connection.ConnectHandler", return_value=mock_handler):
                dm.add_device("R1", "192.168.1.1", "admin", "secret")
                dm.add_device("R2", "192.168.1.2", "admin", "secret")

        dm.disconnect_all()
        # Should not raise even if disconnect has errors
