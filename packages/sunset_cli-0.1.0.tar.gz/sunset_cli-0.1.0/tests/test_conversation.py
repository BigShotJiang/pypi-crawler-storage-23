"""Tests for conversation manager."""

import json

from netmind.agent.conversation import ConversationManager


class TestConversationManager:
    def test_add_user_message(self):
        mgr = ConversationManager()
        mgr.add_user_message("Hello")
        msgs = mgr.get_messages()
        assert len(msgs) == 1
        assert msgs[0]["role"] == "user"
        assert msgs[0]["content"] == "Hello"

    def test_add_assistant_message(self):
        mgr = ConversationManager()
        mgr.add_user_message("Hello")
        mgr.add_assistant_message([{"type": "text", "text": "Hi there!"}])
        msgs = mgr.get_messages()
        assert len(msgs) == 2
        assert msgs[1]["role"] == "assistant"

    def test_add_tool_result(self):
        mgr = ConversationManager()
        mgr.add_user_message("Show devices")
        mgr.add_assistant_message([
            {"type": "text", "text": "Let me check..."},
            {"type": "tool_use", "id": "tool_1", "name": "list_devices", "input": {}},
        ])
        mgr.add_tool_result("tool_1", {"status": "success", "devices": []})

        msgs = mgr.get_messages()
        assert len(msgs) == 3
        assert msgs[2]["role"] == "user"
        assert msgs[2]["content"][0]["type"] == "tool_result"

    def test_multiple_tool_results_merged(self):
        mgr = ConversationManager()
        mgr.add_user_message("Check all")
        mgr.add_assistant_message([
            {"type": "tool_use", "id": "t1", "name": "execute_command", "input": {}},
            {"type": "tool_use", "id": "t2", "name": "execute_command", "input": {}},
        ])
        mgr.add_tool_result("t1", {"status": "success"})
        mgr.add_tool_result("t2", {"status": "success"})

        msgs = mgr.get_messages()
        # Tool results should be in the same user message
        assert len(msgs) == 3
        assert len(msgs[2]["content"]) == 2

    def test_trimming(self):
        mgr = ConversationManager(max_messages=4)
        for i in range(10):
            mgr.add_user_message(f"Message {i}")
            mgr.add_assistant_message([{"type": "text", "text": f"Reply {i}"}])
        assert mgr.message_count <= 4

    def test_clear(self):
        mgr = ConversationManager()
        mgr.add_user_message("Hello")
        mgr.clear()
        assert mgr.message_count == 0

    def test_serialization(self):
        mgr = ConversationManager()
        mgr.add_user_message("Hello")
        mgr.add_assistant_message([{"type": "text", "text": "Hi!"}])

        json_str = mgr.to_json()
        restored = ConversationManager.from_json(json_str)
        assert restored.message_count == 2

    def test_get_last_assistant_text(self):
        mgr = ConversationManager()
        mgr.add_user_message("Hello")
        mgr.add_assistant_message([{"type": "text", "text": "I'm NetMind!"}])
        assert mgr.get_last_assistant_text() == "I'm NetMind!"
