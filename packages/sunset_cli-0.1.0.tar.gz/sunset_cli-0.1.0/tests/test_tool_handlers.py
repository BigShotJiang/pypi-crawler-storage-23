"""Tests for tool handlers (base, IOS, verification).

Uses mock DeviceManager and DeviceConnection to test tool logic
without requiring real SSH connections.
"""

import tempfile
from unittest.mock import MagicMock, patch

import pytest

from netmind.agent.tools.base_tools import handle_list_devices, handle_get_device_info
from netmind.agent.tools.ios_tools import (
    handle_execute_command,
    handle_execute_config_commands,
    handle_get_running_config,
)
from netmind.agent.tools.verification_tools import handle_verify_ospf
from netmind.core.safety import ApprovalManager, CheckpointManager, SafetyGuard
from netmind.models import (
    CommandResult,
    CommandType,
    Device,
    DeviceCredentials,
    DeviceInfo,
    DeviceStatus,
    DeviceType,
)
from netmind.utils.session_logger import reset_session_logger, SessionLogger


# ── Fixtures ────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def _isolate_session_logger(tmp_path):
    """Ensure each test gets a fresh session logger writing to a temp dir."""
    reset_session_logger()
    with patch("netmind.utils.session_logger._instance", SessionLogger(log_dir=str(tmp_path))):
        yield
    reset_session_logger()


def _make_device(device_id="R1", host="192.168.1.1") -> Device:
    return Device(
        device_id=device_id,
        host=host,
        device_type=DeviceType.CISCO_IOS,
        credentials=DeviceCredentials(username="admin", password="secret"),
        info=DeviceInfo(
            hostname="router-1",
            os_version="15.9(3)M6",
            model="vIOS",
        ),
        status=DeviceStatus.CONNECTED,
    )


def _make_mock_connection(device_id="R1", host="192.168.1.1"):
    """Create a mock DeviceConnection."""
    conn = MagicMock()
    conn.device = _make_device(device_id, host)
    conn.is_connected = True
    return conn


def _make_context(
    devices=None,
    read_only=True,
    approval_callback=None,
):
    """Build a tool execution context with mocked components."""
    dm = MagicMock()

    if devices:
        dm.get_device.side_effect = lambda did: devices.get(did)
        dm.get_device_ids.return_value = list(devices.keys())
        dm.get_devices_summary.return_value = [
            {
                "device_id": did,
                "host": conn.device.host,
                "hostname": conn.device.info.hostname,
                "os_version": conn.device.info.os_version,
                "model": conn.device.info.model,
                "status": conn.device.status.value,
                "device_type": conn.device.device_type.value,
            }
            for did, conn in devices.items()
        ]
    else:
        dm.get_device.return_value = None
        dm.get_device_ids.return_value = []
        dm.get_devices_summary.return_value = []

    return {
        "device_manager": dm,
        "safety_guard": SafetyGuard(read_only=read_only),
        "approval_manager": ApprovalManager(),
        "checkpoint_manager": CheckpointManager(),
        "approval_callback": approval_callback,
    }


# ── Base Tools Tests ────────────────────────────────────────────


class TestListDevices:
    @pytest.mark.asyncio
    async def test_no_devices(self):
        ctx = _make_context()
        result = await handle_list_devices({}, ctx)
        assert result["status"] == "success"
        assert result["devices"] == []

    @pytest.mark.asyncio
    async def test_with_devices(self):
        conn = _make_mock_connection()
        ctx = _make_context(devices={"R1": conn})
        result = await handle_list_devices({}, ctx)
        assert result["status"] == "success"
        assert result["device_count"] == 1
        assert result["devices"][0]["device_id"] == "R1"


class TestGetDeviceInfo:
    @pytest.mark.asyncio
    async def test_device_found(self):
        conn = _make_mock_connection()
        ctx = _make_context(devices={"R1": conn})
        result = await handle_get_device_info({"device_id": "R1"}, ctx)
        assert result["status"] == "success"
        assert result["hostname"] == "router-1"
        assert result["os_version"] == "15.9(3)M6"

    @pytest.mark.asyncio
    async def test_device_not_found(self):
        ctx = _make_context()
        result = await handle_get_device_info({"device_id": "R99"}, ctx)
        assert result["status"] == "error"
        assert "not found" in result["error"]


# ── IOS Tools Tests ─────────────────────────────────────────────


class TestExecuteCommand:
    @pytest.mark.asyncio
    async def test_successful_show_command(self):
        conn = _make_mock_connection()
        dm = MagicMock()
        dm.execute_on_device.return_value = CommandResult(
            success=True,
            device_id="R1",
            command="show ip interface brief",
            output="Interface  IP-Address...",
        )
        ctx = _make_context(devices={"R1": conn})
        ctx["device_manager"] = dm

        result = await handle_execute_command(
            {"device_id": "R1", "command": "show ip interface brief"}, ctx
        )
        assert result["status"] == "success"
        assert "Interface" in result["output"]

    @pytest.mark.asyncio
    async def test_blocked_config_command(self):
        """Trying to run 'configure terminal' via execute_command should be blocked."""
        conn = _make_mock_connection()
        ctx = _make_context(devices={"R1": conn})

        result = await handle_execute_command(
            {"device_id": "R1", "command": "configure terminal"}, ctx
        )
        assert result["status"] == "error"
        assert "not allowed" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_command_failure(self):
        dm = MagicMock()
        dm.execute_on_device.return_value = CommandResult(
            success=False,
            device_id="R1",
            command="show foo",
            error="Invalid command",
        )
        conn = _make_mock_connection()
        ctx = _make_context(devices={"R1": conn})
        ctx["device_manager"] = dm

        result = await handle_execute_command(
            {"device_id": "R1", "command": "show foo"}, ctx
        )
        assert result["status"] == "error"
        assert "Invalid command" in result["error"]


class TestExecuteConfigCommands:
    @pytest.mark.asyncio
    async def test_read_only_blocks_config(self):
        conn = _make_mock_connection()
        ctx = _make_context(devices={"R1": conn}, read_only=True)

        result = await handle_execute_config_commands(
            {
                "device_id": "R1",
                "commands": ["router ospf 1"],
                "description": "Enable OSPF",
            },
            ctx,
        )
        assert result["status"] == "error"
        assert "Read-only" in result["error"]

    @pytest.mark.asyncio
    async def test_blocked_dangerous_command(self):
        conn = _make_mock_connection()
        ctx = _make_context(devices={"R1": conn}, read_only=False)

        result = await handle_execute_config_commands(
            {
                "device_id": "R1",
                "commands": ["reload"],
                "description": "Reload device",
            },
            ctx,
        )
        assert result["status"] == "error"
        assert "blocked" in result["error"].lower()

    @pytest.mark.asyncio
    async def test_device_not_found(self):
        ctx = _make_context(read_only=False)

        result = await handle_execute_config_commands(
            {
                "device_id": "R99",
                "commands": ["router ospf 1"],
                "description": "Enable OSPF",
            },
            ctx,
        )
        assert result["status"] == "error"
        assert "not found" in result["error"]

    @pytest.mark.asyncio
    async def test_approved_config_succeeds(self):
        conn = _make_mock_connection()
        conn.get_running_config.return_value = "! running config"

        dm = MagicMock()
        dm.get_device.return_value = conn
        dm.get_device_ids.return_value = ["R1"]
        dm.execute_config_on_device.return_value = CommandResult(
            success=True,
            device_id="R1",
            command="router ospf 1",
            command_type=CommandType.CONFIG,
            output="Config applied",
        )

        async def auto_approve(request):
            request.approve()

        ctx = _make_context(devices={"R1": conn}, read_only=False, approval_callback=auto_approve)
        ctx["device_manager"] = dm

        result = await handle_execute_config_commands(
            {
                "device_id": "R1",
                "commands": ["router ospf 1", "network 10.0.0.0 0.0.0.255 area 0"],
                "description": "Configure OSPF process 1",
            },
            ctx,
        )
        assert result["status"] == "success"
        assert "Configuration applied" in result["message"]

    @pytest.mark.asyncio
    async def test_rejected_config(self):
        conn = _make_mock_connection()
        conn.get_running_config.return_value = "! running config"

        async def auto_reject(request):
            request.reject()

        ctx = _make_context(devices={"R1": conn}, read_only=False, approval_callback=auto_reject)

        result = await handle_execute_config_commands(
            {
                "device_id": "R1",
                "commands": ["router ospf 1"],
                "description": "Configure OSPF",
            },
            ctx,
        )
        assert result["status"] == "rejected"
        assert "rejected" in result["message"].lower()


class TestGetRunningConfig:
    @pytest.mark.asyncio
    async def test_success(self):
        conn = _make_mock_connection()
        conn.get_running_config.return_value = "hostname R1\n!\ninterface GigabitEthernet0/0\n"

        ctx = _make_context(devices={"R1": conn})

        result = await handle_get_running_config({"device_id": "R1"}, ctx)
        assert result["status"] == "success"
        assert "hostname R1" in result["config"]

    @pytest.mark.asyncio
    async def test_device_not_found(self):
        ctx = _make_context()
        result = await handle_get_running_config({"device_id": "R99"}, ctx)
        assert result["status"] == "error"
        assert "not found" in result["error"]

    @pytest.mark.asyncio
    async def test_connection_error(self):
        conn = _make_mock_connection()
        conn.get_running_config.side_effect = Exception("SSH connection lost")

        ctx = _make_context(devices={"R1": conn})

        result = await handle_get_running_config({"device_id": "R1"}, ctx)
        assert result["status"] == "error"
        assert "SSH connection lost" in result["error"]


# ── Verification Tools Tests ────────────────────────────────────


class TestVerifyOSPF:
    @pytest.mark.asyncio
    async def test_device_not_found(self):
        ctx = _make_context()
        result = await handle_verify_ospf({"device_id": "R99"}, ctx)
        assert result["status"] == "error"
        assert "not found" in result["error"]

    @pytest.mark.asyncio
    async def test_ospf_verification(self):
        conn = _make_mock_connection()

        # Mock the OSPFVerifier
        with patch("netmind.agent.tools.verification_tools.OSPFVerifier") as MockVerifier:
            mock_verifier = MockVerifier.return_value
            mock_verifier.verify_status.return_value = {
                "healthy": True,
                "summary": "OSPF is healthy with 2 neighbors",
                "details": {
                    "neighbor_count": 2,
                    "full_adjacencies": 2,
                    "route_count": 5,
                },
            }

            ctx = _make_context(devices={"R1": conn})
            result = await handle_verify_ospf({"device_id": "R1"}, ctx)

            assert result["status"] == "success"
            assert result["ospf_healthy"] is True
            assert result["neighbor_count"] == 2
