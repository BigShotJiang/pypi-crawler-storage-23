"""Tests for command output parsers."""

import os
from pathlib import Path

from netmind.utils.parsers import (
    extract_ospf_config,
    parse_show_ip_interface_brief,
    parse_show_ip_ospf_neighbor,
    parse_show_ip_route_ospf,
    parse_show_version,
)

FIXTURES_DIR = Path(__file__).parent / "fixtures" / "sample_outputs"


def _load_fixture(name: str) -> str:
    return (FIXTURES_DIR / name).read_text()


class TestParseShowVersion:
    def test_parse_hostname(self):
        output = _load_fixture("show_version.txt")
        result = parse_show_version(output)
        assert result["hostname"] == "R1"

    def test_parse_version(self):
        output = _load_fixture("show_version.txt")
        result = parse_show_version(output)
        assert "15.2" in result.get("version", "")

    def test_parse_model(self):
        output = _load_fixture("show_version.txt")
        result = parse_show_version(output)
        assert "7206VXR" in result.get("model", "")

    def test_parse_serial(self):
        output = _load_fixture("show_version.txt")
        result = parse_show_version(output)
        assert result.get("serial") == "4279256517"

    def test_parse_uptime(self):
        output = _load_fixture("show_version.txt")
        result = parse_show_version(output)
        assert "2 hours" in result.get("uptime", "")


class TestParseShowIpInterfaceBrief:
    def test_parse_interfaces(self):
        output = _load_fixture("show_ip_interface_brief.txt")
        result = parse_show_ip_interface_brief(output)
        assert len(result) == 5

    def test_parse_interface_details(self):
        output = _load_fixture("show_ip_interface_brief.txt")
        result = parse_show_ip_interface_brief(output)
        gi0 = next(i for i in result if i["interface"] == "GigabitEthernet0/0")
        assert gi0["ip_address"] == "192.168.1.1"
        assert gi0["status"] == "up"
        assert gi0["protocol"] == "up"

    def test_down_interface(self):
        output = _load_fixture("show_ip_interface_brief.txt")
        result = parse_show_ip_interface_brief(output)
        fa0 = next(i for i in result if i["interface"] == "FastEthernet0/0")
        assert fa0["ip_address"] == "unassigned"
        assert "down" in fa0["status"]


class TestParseShowIpOspfNeighbor:
    def test_parse_neighbors(self):
        output = _load_fixture("show_ip_ospf_neighbor.txt")
        result = parse_show_ip_ospf_neighbor(output)
        assert len(result) == 2

    def test_neighbor_details(self):
        output = _load_fixture("show_ip_ospf_neighbor.txt")
        result = parse_show_ip_ospf_neighbor(output)
        n1 = result[0]
        assert n1["neighbor_id"] == "2.2.2.2"
        assert "FULL" in n1["state"]

    def test_neighbor_interface(self):
        output = _load_fixture("show_ip_ospf_neighbor.txt")
        result = parse_show_ip_ospf_neighbor(output)
        n2 = result[1]
        assert n2["neighbor_id"] == "3.3.3.3"
        assert n2["interface"] == "GigabitEthernet0/2"


class TestParseShowIpRouteOspf:
    def test_parse_routes(self):
        output = _load_fixture("show_ip_route_ospf.txt")
        result = parse_show_ip_route_ospf(output)
        assert len(result) >= 2

    def test_route_details(self):
        output = _load_fixture("show_ip_route_ospf.txt")
        result = parse_show_ip_route_ospf(output)
        # Find the route to 2.2.2.2
        r = next((r for r in result if "2.2.2.2" in r["network"]), None)
        assert r is not None
        assert r["via"] == "10.0.12.2"
        assert r["admin_distance"] == 110
        assert r["metric"] == 2


class TestExtractOspfConfig:
    def test_extract_ospf_block(self):
        running = """!
interface GigabitEthernet0/0
 ip address 192.168.1.1 255.255.255.0
!
router ospf 1
 router-id 1.1.1.1
 network 10.0.0.0 0.0.0.255 area 0
 network 192.168.1.0 0.0.0.255 area 0
!
line con 0
"""
        result = extract_ospf_config(running)
        assert result is not None
        assert "router ospf 1" in result
        assert "router-id 1.1.1.1" in result
        assert "network 10.0.0.0" in result

    def test_no_ospf_config(self):
        running = """!
interface GigabitEthernet0/0
 ip address 192.168.1.1 255.255.255.0
!
line con 0
"""
        result = extract_ospf_config(running)
        assert result is None
