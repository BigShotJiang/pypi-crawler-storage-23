"""Tests for safety mechanisms."""

from netmind.core.safety import ApprovalManager, SafetyGuard


class TestSafetyGuard:
    def test_read_only_blocks_config(self):
        guard = SafetyGuard(read_only=True)
        allowed, reason = guard.can_execute_config(["router ospf 1"])
        assert allowed is False
        assert "Read-only" in reason

    def test_interactive_allows_config(self):
        guard = SafetyGuard(read_only=False)
        allowed, reason = guard.can_execute_config(["router ospf 1"])
        assert allowed is True

    def test_blocked_commands(self):
        guard = SafetyGuard(read_only=False)

        # Reload should be blocked
        allowed, reason = guard.can_execute_config(["reload"])
        assert allowed is False
        assert "blocked" in reason.lower()

        # Erase should be blocked
        allowed, reason = guard.can_execute_config(["erase startup-config"])
        assert allowed is False

    def test_dangerous_command_warnings(self):
        guard = SafetyGuard(read_only=False)

        # Shutdown should warn
        valid, warnings = guard.validate_commands(["interface gi0/0", "shutdown"])
        assert valid is True
        assert len(warnings) > 0
        assert any("shutdown" in w.lower() for w in warnings)

    def test_show_commands_allowed(self):
        guard = SafetyGuard(read_only=True)
        allowed, reason = guard.can_execute_show("show ip interface brief")
        assert allowed is True

    def test_config_disguised_as_show_blocked(self):
        guard = SafetyGuard(read_only=True)
        allowed, reason = guard.can_execute_show("configure terminal")
        assert allowed is False


class TestApprovalManager:
    def test_create_approval(self):
        mgr = ApprovalManager()
        req = mgr.request_approval(
            device_id="R1",
            commands=["router ospf 1"],
            description="Test",
        )
        assert req.is_pending
        assert mgr.has_pending()

    def test_approve(self):
        mgr = ApprovalManager()
        req = mgr.request_approval(
            device_id="R1",
            commands=["router ospf 1"],
            description="Test",
        )
        result = mgr.approve(req.request_id)
        assert result is not None
        assert result.is_approved
        assert not mgr.has_pending()

    def test_reject(self):
        mgr = ApprovalManager()
        req = mgr.request_approval(
            device_id="R1",
            commands=["router ospf 1"],
            description="Test",
        )
        result = mgr.reject(req.request_id)
        assert result is not None
        assert not result.is_approved
        assert not mgr.has_pending()

    def test_history(self):
        mgr = ApprovalManager()
        req1 = mgr.request_approval("R1", ["cmd1"], "desc1")
        req2 = mgr.request_approval("R2", ["cmd2"], "desc2")
        mgr.approve(req1.request_id)
        mgr.reject(req2.request_id)
        assert len(mgr.history) == 2
