"""Tests for the session logging system."""

import json
import tempfile
from pathlib import Path

from netmind.utils.session_logger import SessionLogger, _safe_serialize, _truncate


class TestSessionLogger:
    """Tests for the SessionLogger class."""

    def _make_logger(self, tmp_dir: str) -> SessionLogger:
        return SessionLogger(log_dir=tmp_dir)

    def test_creates_log_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            assert slog.log_path.exists()
            assert slog.log_path.suffix == ".jsonl"

    def test_session_start_written(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            entries = _read_entries(slog.log_path)
            assert len(entries) >= 1
            assert entries[0]["type"] == "session_start"
            assert "session_id" in entries[0]["data"]

    def test_log_user_message(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_user_message("show me the config")
            entries = _read_entries(slog.log_path)
            msg_entries = [e for e in entries if e["type"] == "user_message"]
            assert len(msg_entries) == 1
            assert msg_entries[0]["data"]["message"] == "show me the config"

    def test_log_agent_text(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_agent_text("I'll check the OSPF status.")
            entries = _read_entries(slog.log_path)
            text_entries = [e for e in entries if e["type"] == "agent_text"]
            assert len(text_entries) == 1
            assert "OSPF" in text_entries[0]["data"]["text"]

    def test_log_tool_call_and_result(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_tool_call("execute_command", {"device_id": "R1", "command": "show version"})
            slog.log_tool_result(
                "execute_command",
                {"status": "success", "output": "Cisco IOS..."},
                elapsed_ms=142.5,
            )
            entries = _read_entries(slog.log_path)
            calls = [e for e in entries if e["type"] == "tool_call"]
            results = [e for e in entries if e["type"] == "tool_result"]
            assert len(calls) == 1
            assert calls[0]["data"]["tool"] == "execute_command"
            assert len(results) == 1
            assert results[0]["data"]["status"] == "success"
            assert results[0]["data"]["elapsed_ms"] == 142.5

    def test_log_device_connect(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_device_connect("R1", "192.168.1.1", True, elapsed_ms=3200.0)
            entries = _read_entries(slog.log_path)
            conn = [e for e in entries if e["type"] == "device_connect"]
            assert len(conn) == 1
            assert conn[0]["data"]["success"] is True
            assert conn[0]["data"]["host"] == "192.168.1.1"

    def test_log_device_command(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_device_command("R1", "show ip route", True, elapsed_ms=80.0, output_preview="Codes: L...")
            entries = _read_entries(slog.log_path)
            cmds = [e for e in entries if e["type"] == "device_command"]
            assert len(cmds) == 1
            assert cmds[0]["data"]["command"] == "show ip route"
            assert cmds[0]["data"]["success"] is True

    def test_log_device_config(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_device_config("R1", ["router ospf 1", "network 10.0.0.0 0.0.0.255 area 0"], True, elapsed_ms=200.0)
            entries = _read_entries(slog.log_path)
            cfgs = [e for e in entries if e["type"] == "device_config"]
            assert len(cfgs) == 1
            assert cfgs[0]["data"]["commands"] == ["router ospf 1", "network 10.0.0.0 0.0.0.255 area 0"]

    def test_log_safety_check(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_safety_check("show_command", True, command="show version")
            slog.log_safety_check("config_commands", False, "Read-only mode active", commands=["reload"])
            entries = _read_entries(slog.log_path)
            safety = [e for e in entries if e["type"] == "safety_check"]
            assert len(safety) == 2
            assert safety[0]["data"]["allowed"] is True
            assert safety[1]["data"]["allowed"] is False

    def test_log_approval(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_approval("req-123", "R1", "requested", ["router ospf 1"], "Configure OSPF")
            entries = _read_entries(slog.log_path)
            approvals = [e for e in entries if e["type"] == "approval"]
            assert len(approvals) == 1
            assert approvals[0]["data"]["action"] == "requested"

    def test_log_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_error("api_connection", "Cannot reach API", {"endpoint": "api.anthropic.com"})
            entries = _read_entries(slog.log_path)
            errors = [e for e in entries if e["type"] == "error"]
            assert len(errors) == 1
            assert errors[0]["data"]["category"] == "api_connection"

    def test_log_api_call(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_api_call("claude-sonnet-4-20250514", 5, elapsed_ms=1200.0, input_tokens=500, output_tokens=200)
            entries = _read_entries(slog.log_path)
            api_calls = [e for e in entries if e["type"] == "api_call"]
            assert len(api_calls) == 1
            assert api_calls[0]["data"]["model"] == "claude-sonnet-4-20250514"
            assert api_calls[0]["data"]["input_tokens"] == 500

    def test_log_checkpoint(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_checkpoint("R1", "checkpoint-R1-1", "create", True)
            entries = _read_entries(slog.log_path)
            ckpts = [e for e in entries if e["type"] == "checkpoint"]
            assert len(ckpts) == 1
            assert ckpts[0]["data"]["action"] == "create"

    def test_log_session_end(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_session_end()
            entries = _read_entries(slog.log_path)
            ends = [e for e in entries if e["type"] == "session_end"]
            assert len(ends) == 1
            assert "duration_seconds" in ends[0]["data"]

    def test_timestamps_present(self):
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)
            slog.log_user_message("test")
            entries = _read_entries(slog.log_path)
            for entry in entries:
                assert "ts" in entry
                # ISO-8601 format check
                assert "T" in entry["ts"]

    def test_full_session_flow(self):
        """Simulate a realistic session flow and verify log integrity."""
        with tempfile.TemporaryDirectory() as tmp:
            slog = self._make_logger(tmp)

            # Simulate: user asks question -> agent calls tools -> done
            slog.log_user_message("show me the OSPF neighbors")
            slog.log_api_call("claude-sonnet-4-20250514", 3, elapsed_ms=800.0, input_tokens=300, output_tokens=150)
            slog.log_agent_text("Let me check the OSPF neighbors.")
            slog.log_tool_call("execute_command", {"device_id": "R1", "command": "show ip ospf neighbor"})
            slog.log_safety_check("show_command", True, command="show ip ospf neighbor")
            slog.log_device_command("R1", "show ip ospf neighbor", True, elapsed_ms=95.0)
            slog.log_tool_result("execute_command", {"status": "success", "output": "Neighbor ID..."}, elapsed_ms=100.0)
            slog.log_api_call("claude-sonnet-4-20250514", 5, elapsed_ms=1100.0, input_tokens=600, output_tokens=300)
            slog.log_agent_text("The OSPF neighbors are healthy.")
            slog.log_agent_done("Let me check the OSPF neighbors.\nThe OSPF neighbors are healthy.")
            slog.log_session_end()

            entries = _read_entries(slog.log_path)

            # Verify all event types present
            types = {e["type"] for e in entries}
            assert "session_start" in types
            assert "user_message" in types
            assert "api_call" in types
            assert "agent_text" in types
            assert "tool_call" in types
            assert "safety_check" in types
            assert "device_command" in types
            assert "tool_result" in types
            assert "agent_done" in types
            assert "session_end" in types

            # Verify chronological order by checking session_start is first and session_end is last
            assert entries[0]["type"] == "session_start"
            assert entries[-1]["type"] == "session_end"


class TestSafeSerialize:
    """Tests for the _safe_serialize helper."""

    def test_masks_password(self):
        result = _safe_serialize({"username": "admin", "password": "secret123"})
        assert result["username"] == "admin"
        assert result["password"] == "***"

    def test_masks_nested(self):
        result = _safe_serialize({"device": {"credentials": {"password": "s3cr3t", "enable_secret": "en4ble"}}})
        assert result["device"]["credentials"]["password"] == "***"
        assert result["device"]["credentials"]["enable_secret"] == "***"

    def test_masks_api_key(self):
        result = _safe_serialize({"api_key": "sk-ant-abc123"})
        assert result["api_key"] == "***"

    def test_preserves_normal_values(self):
        result = _safe_serialize({"host": "192.168.1.1", "port": 22, "commands": ["show version"]})
        assert result == {"host": "192.168.1.1", "port": 22, "commands": ["show version"]}

    def test_handles_lists(self):
        result = _safe_serialize([{"password": "x"}, {"name": "ok"}])
        assert result[0]["password"] == "***"
        assert result[1]["name"] == "ok"


class TestTruncate:
    """Tests for the _truncate helper."""

    def test_short_text_unchanged(self):
        assert _truncate("hello", 100) == "hello"

    def test_long_text_truncated(self):
        text = "a" * 200
        result = _truncate(text, 50)
        assert len(result) < 200
        assert "200 chars total" in result
        assert result.startswith("a" * 50)

    def test_exact_length_unchanged(self):
        text = "a" * 50
        assert _truncate(text, 50) == text


# ── Helpers ────────────────────────────────────────────────────

def _read_entries(path: Path) -> list[dict]:
    """Read all JSON-lines entries from a log file."""
    entries = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if line:
                entries.append(json.loads(line))
    return entries
