"""Tests for the network auto-discovery module."""

from unittest.mock import MagicMock, patch

import pytest

from netmind.core.discovery import (
    DiscoveryResult,
    _discover_cdp_neighbors,
    _discover_interfaces,
    _discover_ospf,
    _enrich_with_descriptions,
    _enrich_with_masks,
    _iface_name_match,
    _match_device_id,
    _normalize_iface,
    discover_device,
    discover_all,
)
from netmind.core.topology import InterfaceInfo, NetworkTopology
from netmind.models import CommandResult, CommandType, Device, DeviceCredentials, DeviceStatus, DeviceType


# ── Fixtures ─────────────────────────────────────────────────────────


def _make_mock_conn(device_id="R1", host="192.168.1.1"):
    """Create a mock DeviceConnection."""
    conn = MagicMock()
    conn.device = Device(
        device_id=device_id,
        host=host,
        device_type=DeviceType.CISCO_IOS,
        credentials=DeviceCredentials(username="admin", password="cisco"),
        status=DeviceStatus.CONNECTED,
    )
    conn.is_connected = True
    return conn


def _cmd_result(output, success=True, command=""):
    """Create a CommandResult."""
    return CommandResult(
        success=success,
        device_id="R1",
        command=command,
        command_type=CommandType.SHOW,
        output=output,
    )


# ── Interface discovery tests ────────────────────────────────────────


SHOW_IP_INTERFACE_BRIEF = """\
Interface                  IP-Address      OK? Method Status                Protocol
GigabitEthernet0/0         10.10.10.1      YES NVRAM  up                    up
GigabitEthernet0/1         10.10.20.1      YES NVRAM  up                    up
Loopback0                  1.1.1.1         YES NVRAM  up                    up
GigabitEthernet0/2         unassigned      YES NVRAM  administratively down down
"""


SHOW_RUN_IP_ADDRESS = """\
interface GigabitEthernet0/0
 ip address 10.10.10.1 255.255.255.0
interface GigabitEthernet0/1
 ip address 10.10.20.1 255.255.255.0
interface Loopback0
 ip address 1.1.1.1 255.255.255.255
"""


SHOW_INTERFACES_DESC = """\
Interface                      Status         Protocol Description
Gi0/0                          up             up       Link to R2
Gi0/1                          up             up       Link to R3
Lo0                            up             up       Router-ID
Gi0/2                          admin down     down
"""


class TestInterfaceDiscovery:
    def test_discover_interfaces(self):
        conn = _make_mock_conn()

        def execute_side_effect(cmd):
            if cmd == "show ip interface brief":
                return _cmd_result(SHOW_IP_INTERFACE_BRIEF)
            elif "show running-config" in cmd:
                return _cmd_result(SHOW_RUN_IP_ADDRESS)
            elif "show interfaces description" in cmd:
                return _cmd_result(SHOW_INTERFACES_DESC)
            return _cmd_result("", success=False)

        conn.execute_command = MagicMock(side_effect=execute_side_effect)

        interfaces = _discover_interfaces(conn)

        assert len(interfaces) == 4
        gi0 = next(i for i in interfaces if "0/0" in i.name)
        assert gi0.ip == "10.10.10.1"
        assert gi0.mask == "255.255.255.0"
        assert gi0.cidr == 24
        assert gi0.enabled is True

        lo0 = next(i for i in interfaces if "Loopback" in i.name)
        assert lo0.ip == "1.1.1.1"
        assert lo0.cidr == 32

        gi2 = next(i for i in interfaces if "0/2" in i.name)
        assert gi2.shutdown is True
        assert gi2.ip is None

    def test_discover_interfaces_no_brief(self):
        conn = _make_mock_conn()
        conn.execute_command = MagicMock(
            return_value=_cmd_result("", success=False)
        )
        interfaces = _discover_interfaces(conn)
        assert interfaces == []


# ── OSPF discovery tests ─────────────────────────────────────────────


SHOW_IP_OSPF = """\
 Routing Process "ospf 1" with ID 1.1.1.1
 Start time: 00:00:01.234, Time elapsed: 1d2h3m
 Supports only single TOS(TOS0) routes
 Supports opaque LSA
 SPF schedule delay 5 secs, Hold time between two SPFs 10 secs
"""

SHOW_OSPF_IFACE_BRIEF = """\
Interface    PID   Area            IP Address/Mask    Cost  State Nbrs F/C
Gi0/0        1     0               10.10.10.1/24      1     DR    1/1
Gi0/1        1     0               10.10.20.1/24      1     BDR   1/1
Lo0          1     0               1.1.1.1/32         1     LOOP  0/0
"""

SHOW_RUN_OSPF_SECTION = """\
router ospf 1
 router-id 1.1.1.1
 passive-interface Loopback0
 network 10.10.10.0 0.0.0.255 area 0
 network 10.10.20.0 0.0.0.255 area 0
"""


class TestOSPFDiscovery:
    def test_discover_ospf(self):
        conn = _make_mock_conn()

        def execute_side_effect(cmd):
            if cmd == "show ip ospf":
                return _cmd_result(SHOW_IP_OSPF)
            elif cmd == "show ip ospf interface brief":
                return _cmd_result(SHOW_OSPF_IFACE_BRIEF)
            elif "show running-config | section router ospf" in cmd:
                return _cmd_result(SHOW_RUN_OSPF_SECTION)
            return _cmd_result("", success=False)

        conn.execute_command = MagicMock(side_effect=execute_side_effect)

        ospf = _discover_ospf(conn)

        assert ospf is not None
        assert ospf.process_id == 1
        assert ospf.router_id == "1.1.1.1"
        assert len(ospf.areas) == 1
        assert ospf.areas[0].area_id == 0
        assert len(ospf.areas[0].networks) == 3  # Gi0/0, Gi0/1, Lo0
        assert "Loopback0" in ospf.passive_interfaces

    def test_discover_ospf_not_enabled(self):
        conn = _make_mock_conn()
        conn.execute_command = MagicMock(
            return_value=_cmd_result("OSPF not enabled")
        )
        ospf = _discover_ospf(conn)
        assert ospf is None


# ── CDP neighbor discovery tests ─────────────────────────────────────


CDP_NEIGHBORS_DETAIL = """\
-------------------------
Device ID: R2.lab.local
Entry address(es):
  IP address: 10.10.10.2
Platform: Cisco 7206VXR,  Capabilities: Router Switch IGMP
Interface: GigabitEthernet0/0,  Port ID (outgoing port): GigabitEthernet0/0

-------------------------
Device ID: R3.lab.local
Entry address(es):
  IP address: 10.10.20.2
Platform: Cisco 7206VXR,  Capabilities: Router
Interface: GigabitEthernet0/1,  Port ID (outgoing port): GigabitEthernet0/0
"""


class TestCDPDiscovery:
    def test_discover_cdp_neighbors(self):
        conn = _make_mock_conn()
        conn.execute_command = MagicMock(
            return_value=_cmd_result(CDP_NEIGHBORS_DETAIL)
        )

        neighbors = _discover_cdp_neighbors(conn)

        assert len(neighbors) == 2
        r2 = neighbors[0]
        assert r2["device_id"] == "R2"
        assert r2["local_interface"] == "GigabitEthernet0/0"
        assert r2["remote_interface"] == "GigabitEthernet0/0"
        assert r2["ip"] == "10.10.10.2"

        r3 = neighbors[1]
        assert r3["device_id"] == "R3"

    def test_discover_cdp_no_neighbors(self):
        conn = _make_mock_conn()
        conn.execute_command = MagicMock(
            return_value=_cmd_result("", success=False)
        )
        neighbors = _discover_cdp_neighbors(conn)
        assert neighbors == []


# ── Full discovery tests ─────────────────────────────────────────────


class TestFullDiscovery:
    def test_discover_device(self):
        conn = _make_mock_conn()

        def execute_side_effect(cmd):
            if cmd == "show ip interface brief":
                return _cmd_result(SHOW_IP_INTERFACE_BRIEF)
            elif "show running-config | include" in cmd:
                return _cmd_result(SHOW_RUN_IP_ADDRESS)
            elif "show interfaces description" in cmd:
                return _cmd_result(SHOW_INTERFACES_DESC)
            elif cmd == "show ip ospf":
                return _cmd_result(SHOW_IP_OSPF)
            elif cmd == "show ip ospf interface brief":
                return _cmd_result(SHOW_OSPF_IFACE_BRIEF)
            elif "section router ospf" in cmd:
                return _cmd_result(SHOW_RUN_OSPF_SECTION)
            elif "cdp" in cmd:
                return _cmd_result(CDP_NEIGHBORS_DETAIL)
            return _cmd_result("", success=False)

        conn.execute_command = MagicMock(side_effect=execute_side_effect)

        result = discover_device(conn)

        assert result.success is True
        assert result.device_id == "R1"
        assert len(result.interfaces) == 4
        assert result.ospf is not None
        assert len(result.cdp_neighbors) == 2

    def test_discover_all_builds_topology(self):
        conn1 = _make_mock_conn("R1", "192.168.1.1")
        conn2 = _make_mock_conn("R2", "192.168.1.2")

        # R1 discovers R2 as CDP neighbor
        def r1_execute(cmd):
            if cmd == "show ip interface brief":
                return _cmd_result(
                    "Interface  IP-Address  OK? Method Status Protocol\n"
                    "GigabitEthernet0/0  10.10.10.1  YES NVRAM  up  up\n"
                )
            elif "show running-config | include" in cmd:
                return _cmd_result(
                    "interface GigabitEthernet0/0\n"
                    " ip address 10.10.10.1 255.255.255.0\n"
                )
            elif "cdp" in cmd:
                return _cmd_result(
                    "-------------------------\n"
                    "Device ID: R2\n"
                    "  IP address: 10.10.10.2\n"
                    "Interface: GigabitEthernet0/0,  "
                    "Port ID (outgoing port): GigabitEthernet0/0\n"
                )
            return _cmd_result("", success=False)

        # R2 discovers R1 as CDP neighbor
        def r2_execute(cmd):
            if cmd == "show ip interface brief":
                return _cmd_result(
                    "Interface  IP-Address  OK? Method Status Protocol\n"
                    "GigabitEthernet0/0  10.10.10.2  YES NVRAM  up  up\n"
                )
            elif "show running-config | include" in cmd:
                return _cmd_result(
                    "interface GigabitEthernet0/0\n"
                    " ip address 10.10.10.2 255.255.255.0\n"
                )
            elif "cdp" in cmd:
                return _cmd_result(
                    "-------------------------\n"
                    "Device ID: R1\n"
                    "  IP address: 10.10.10.1\n"
                    "Interface: GigabitEthernet0/0,  "
                    "Port ID (outgoing port): GigabitEthernet0/0\n"
                )
            return _cmd_result("", success=False)

        conn1.execute_command = MagicMock(side_effect=r1_execute)
        conn2.execute_command = MagicMock(side_effect=r2_execute)

        results, topology = discover_all([conn1, conn2])

        assert len(results) == 2
        assert topology.node_count == 2
        # CDP from both sides deduplicates to 1 link
        assert topology.link_count == 1

        neighbors = topology.get_neighbors("R1")
        assert len(neighbors) == 1
        assert neighbors[0]["neighbor_id"] == "R2"


# ── Helper tests ─────────────────────────────────────────────────────


class TestHelpers:
    def test_iface_name_match_exact(self):
        assert _iface_name_match("GigabitEthernet0/0", "GigabitEthernet0/0")

    def test_iface_name_match_case(self):
        assert _iface_name_match("gigabitethernet0/0", "GigabitEthernet0/0")

    def test_iface_name_match_normalized(self):
        assert _iface_name_match("GigabitEthernet0/0", "Gi0/0")

    def test_iface_name_no_match(self):
        assert not _iface_name_match("GigabitEthernet0/0", "GigabitEthernet0/1")

    def test_normalize_iface(self):
        assert _normalize_iface("GigabitEthernet0/0") == "Gi0/0"
        assert _normalize_iface("FastEthernet0/1") == "Fa0/1"
        assert _normalize_iface("Loopback0") == "Lo0"
        assert _normalize_iface("Serial0/0/0") == "Se0/0/0"

    def test_match_device_id_exact(self):
        known = {"R1", "R2", "R3"}
        assert _match_device_id("R2", known) == "R2"

    def test_match_device_id_fqdn(self):
        known = {"R1", "R2", "R3"}
        assert _match_device_id("R2.lab.local", known) == "R2"

    def test_match_device_id_case(self):
        known = {"R1", "R2"}
        assert _match_device_id("r1", known) == "R1"

    def test_match_device_id_unknown(self):
        known = {"R1", "R2"}
        assert _match_device_id("SW1", known) is None

    def test_discovery_result_summary(self):
        r = DiscoveryResult("R1")
        r.interfaces = [InterfaceInfo(name="Gi0/0")]
        assert "R1" in r.summary
        assert "1 interfaces" in r.summary
