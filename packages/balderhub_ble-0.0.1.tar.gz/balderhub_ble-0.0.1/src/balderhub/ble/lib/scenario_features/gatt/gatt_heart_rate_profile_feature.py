from .base_gatt_profile_feature import BaseGattProfileFeature

class GattHeartRateProfileFeature(BaseGattProfileFeature):
    """Base GATT heart rate profile feature"""
    # TODO where do we use this feature?
