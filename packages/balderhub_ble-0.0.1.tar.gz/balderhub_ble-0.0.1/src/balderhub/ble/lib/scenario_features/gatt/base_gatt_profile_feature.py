import balder


class BaseGattProfileFeature(balder.Feature):
    """Base GATT profile feature that is used as base class for all GATT profiles within this project"""
