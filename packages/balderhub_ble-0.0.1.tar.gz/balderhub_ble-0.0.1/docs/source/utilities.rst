Utilities
*********

This section shows general objects and helper functions that are used with this package.

Messages
========

Advertisement-Messages
----------------------

.. autoclass:: balderhub.ble.lib.utils.AdvertisementMessage
    :members:

Gatt Messages
-------------

.. autoclass:: balderhub.ble.lib.utils.BaseGattMessage
    :members:

.. autoclass:: balderhub.ble.lib.utils.RawGattMessage
    :members:

Characteristics
===============

.. autoclass:: balderhub.ble.lib.utils.Characteristic
    :members:

Characteristic Utilities
------------------------

.. autoclass:: balderhub.ble.lib.utils.CharacteristicProperty
    :members:

.. autoclass:: balderhub.ble.lib.utils.CharacteristicSecurity
    :members:

Data Objects
============

.. autoclass:: balderhub.ble.lib.utils.BLEDeviceInformation
    :members:

.. autoclass:: balderhub.ble.lib.utils.PnpIdData


Further Utilities
=================

.. autoclass:: balderhub.ble.lib.utils.AsyncManagerThread
    :members: