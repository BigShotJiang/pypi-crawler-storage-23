Scenarios
*********

Scenarios describe **what you need**. They define the tests and the necessary devices for them. Here you can find all
scenarios that are implemented in this BalderHub package.


Battery Service
===============

.. autoclass:: balderhub.ble.scenarios.ScenarioBatteryService
    :members:

Device Information Service
==========================

.. autoclass:: balderhub.ble.scenarios.ScenarioDeviceInformationService
    :members:

Heart-Rate Profile / Service
============================

.. autoclass:: balderhub.ble.scenarios.ScenarioHrProfileAdvertisements
    :members:

.. autoclass:: balderhub.ble.scenarios.ScenarioHeartRateService
    :members:
