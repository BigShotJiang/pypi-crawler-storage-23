#!/usr/bin/env python

"""The setup script."""

# shim for compatibility with setuptools build workflow
# adapted from https://stackoverflow.com/a/58754298

from setuptools import setup

setup()
