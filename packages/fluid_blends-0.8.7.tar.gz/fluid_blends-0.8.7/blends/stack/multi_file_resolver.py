from __future__ import annotations

from dataclasses import dataclass
from typing import TYPE_CHECKING

from blends.stack.partial_path_db import PartialPathDb

if TYPE_CHECKING:
    from blends.stack.forward_stitcher import ForwardStitcherConfig
    from blends.stack.partial_path import (
        FileHandle,
        PartialPathDatabase,
    )
    from blends.stack.selection import PartialPathEdge
    from blends.stack.view import StackGraphView


@dataclass(frozen=True, slots=True)
class MultiFileResolutionStats:
    phases_executed: int
    candidates_considered: int
    concatenations_succeeded: int
    complete_paths_found: int
    cancelled: bool
    cycle_guard_hits: int
    queue_pruned_count: int
    files_considered: int


@dataclass(frozen=True, slots=True)
class MultiFileResolutionRequest:
    file_handle: FileHandle
    ref_node_index: int
    config: ForwardStitcherConfig | None = None
    include_stats: bool = False


@dataclass(frozen=True, slots=True)
class _MultiFileDefinitionCandidate:
    definition_node_index: int
    file_handle: FileHandle
    edges: tuple[PartialPathEdge, ...]


def _build_multi_file_db(
    database: PartialPathDatabase,
    view: StackGraphView,
) -> PartialPathDb:
    db = PartialPathDb(symbols=view.symbols)
    for file_handle in database.list_files():
        record = database.get_file(file_handle)
        if record is None:
            continue
        db.add_file(record)
    return db


def _find_definition_file_handle(
    db: PartialPathDb,
    end_node_index: int,
    ref_file_handle: FileHandle,
    all_file_handles: tuple[FileHandle, ...],
) -> FileHandle:
    for fh in all_file_handles:
        if (fh, end_node_index) in db.start_node_index:
            return fh
    return ref_file_handle
