class ReferenceLike:
    """Base class for reference-like objects."""

    ...
