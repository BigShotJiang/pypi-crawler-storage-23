#![cfg(test)]

pub const DEFAULT_EPS: f64 = 1e-9;
