# error code

# Watcher
EC_Watcher = 100

# recovery failed
EC_Recovery = 101

# timeout in sent
EC_SendError = 102

# timeout in holding
EC_Holding = 103

# timeout in transferring
EC_Transferring = 104

# timeout for other status
EC_Timeout = 105
