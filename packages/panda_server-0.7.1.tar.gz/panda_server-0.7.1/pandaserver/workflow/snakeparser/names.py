__author__ = "retmas"

WORKFLOW_NAMES = ["prun", "phpo", "junction", "reana"]
