# error code

# Setupper
EC_Setupper = 100

# Setupper
EC_GUID = 101

# Adder
EC_Adder = 200

# Subscription failures
EC_Subscription = 201

# location registration failures
EC_Location = 203

# missing nEvents
EC_MissingNumEvents = 204

# inconsistent GUID
EC_InconsistentGUID = 205

# wrong RSE configuration
EC_RSE = 206
