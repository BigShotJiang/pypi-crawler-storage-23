from embedding import Embedding

# Read the README file
with open("README.md", "r", encoding="utf-8") as f:
    doc = f.read()

# Create Embedding instance
emb = Embedding()

# Add the document
#print("Adding README to embeddings...")
#emb.add(doc, update=True)

# Query the document
query_text = "What is PromptBlender?"
print(f"Querying: {query_text}")
documents = emb.query(query_text, doc)

print("Results:")
for i, doc in enumerate(documents):
    print(f"{i+1}: {doc}")