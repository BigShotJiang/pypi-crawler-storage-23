from turbocore.log import runReflectorDaemon

runReflectorDaemon()
