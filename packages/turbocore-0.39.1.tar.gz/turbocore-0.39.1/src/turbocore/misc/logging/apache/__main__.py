from turbocore.misc.logging.apache import main


if __name__ == "__main__":
    main()
