from . import application_memory_mb


if __name__ == "__main__":
    print(application_memory_mb())
