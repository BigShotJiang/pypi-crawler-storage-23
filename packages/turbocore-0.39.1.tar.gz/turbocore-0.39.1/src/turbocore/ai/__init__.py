import time
import sys
import json
import turbocore
from rich.pretty import pprint as PP
import sqlite3
from datetime import datetime, timezone

NOW_UTC = datetime.now(timezone.utc)


import os
import requests

OPENAI_URL_RESPONSES = "https://api.openai.com/v1/responses"


AI_HOME = os.path.expanduser(os.path.join("~", ".ai"))
AI_DB = os.path.join(AI_HOME, "ai.db")


def initialize():
    os.makedirs(AI_HOME, exist_ok=True)
    if not os.path.isfile(AI_DB):
        with sqlite3.connect(AI_DB) as conn:
            cursor = conn.cursor()
            cursor.execute("""
            CREATE TABLE token_usage (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                total_tokens INTEGER,
                created_at TEXT
            );
            """)
            cursor.execute("""
            CREATE TABLE prompt_archive (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                total_tokens INTEGER,
                created_at TEXT,
                q_sys TEXT,
                q_user TEXT,
                q_seconds INTEGER,
                ai_response TEXT,
                ai_model TEXT
            );
            """)


def one_word_payload(content=None, system="Antworte ausschließlich mit genau einem Wort. Keine Satzzeichen, keine Erklärungen."):
    payload = {
        "model": "gpt-5.2",
        "input": [
            {
                "role": "system",
                "content": system
            },
            {
                "role": "user",
                "content": content
            }
        ]
    }
    return payload


def main():
    from prompt_toolkit.styles import Style
    bw_style = Style.from_dict({
        "dialog":         "bg:black fg:white",
        "dialog frame":   "bg:black fg:white",
        "dialog.body":    "bg:black fg:white",
        "dialog.title":   "fg:cyan bold",
        "button":         "bg:black fg:white",
        "button.focused": "bg:white fg:black"
    })
    from prompt_toolkit import prompt
    from prompt_toolkit.history import InMemoryHistory
    from prompt_toolkit.completion import WordCompleter
    his = InMemoryHistory()
    woco = WordCompleter(words=["Robert", "Robert1", "Robert2"], ignore_case=True)
    his.append_string("A")
    his.append_string("B")
    his.append_string("C")
    x = prompt("> ", default="aha", history=his, completer=woco, is_password=True)
    import hashlib
    pw_hash = hashlib.sha256(x.encode()).hexdigest()

    from prompt_toolkit.shortcuts.dialogs import message_dialog

    message_dialog(
        title="Hinweis",
        text="Das ist eine einfache Meldung.", style=bw_style
    ).run()

    from prompt_toolkit.shortcuts.dialogs import yes_no_dialog

    result = yes_no_dialog(
        title="Bestätigung",
        text="Willst du wirklich fortfahren?"
        , style=bw_style
    ).run()

    print("Antwort:", result)

    from prompt_toolkit.shortcuts.dialogs import input_dialog

    password = input_dialog(
        title="Login",
        text="Passwort eingeben:",
        password=True, style=bw_style
    ).run()

    if password is None:
        print("Abgebrochen")
    else:
        print("Länge:", len(password))

    name = input_dialog(
        title="Login Name",
        text="Passwort eingeben:", default="bob", style=bw_style

    ).run()

    message_dialog(
        title="NAME lautet",
        text="'%s'" % name, style=bw_style
    ).run()



def main2():
    initialize()

    secr = os.environ.get("OPENAI_API_KEY", "_")
    SESS = requests.Session()
    SESS.headers.update({
        "Authorization": f"Bearer {secr}",
        "Content-Type": "application/json",
    })



    payload = one_word_payload(content="wieviel MB groß ein input an deine api maximal haben")

    http_t1 = time.time()
    response = SESS.post(
        OPENAI_URL_RESPONSES,
        json=payload,
        timeout=(3,10),
    )

    response.raise_for_status()

    data = response.json()
    http_t2 = time.time()
    http_t = int(http_t2-http_t1)


    text = None
    for output in data["output"]:
        for item in output["content"]:
            if item["type"] == "output_text":
                if text is not None:
                    raise Exception("Multiple Text outputs from OpenAI, first was [%s] not there's [%s]" % (text, item["text"]))
                text = item["text"]

    print(data["usage"]["total_tokens"])

    with sqlite3.connect(AI_DB) as conn:
        cursor = conn.cursor()

        cursor.execute("""
        INSERT INTO token_usage (created_at, total_tokens) VALUES (?, ?);
        """,
                       (NOW_UTC.isoformat(timespec="seconds"), data["usage"]["total_tokens"],)
        )

        cursor.execute("""
        INSERT INTO prompt_archive (
        total_tokens, created_at, q_sys, q_user, q_seconds, ai_response, ai_model
        ) VALUES (?, ?, ?, ?, ?, ?, ?);
        """,
                       (
                           data["usage"]["total_tokens"],
                        NOW_UTC.isoformat(timespec="seconds"),
                        payload["input"][0]["content"],
                        payload["input"][1]["content"],
                        http_t,
                        str(text),
                        payload["model"],
                        )
        )



    # ofilename = sys.argv[2]
    # filename = sys.argv[1]
    # with open(ofilename, 'w') as of:
    #     data = None
    #     try:
    #         data = json.loads(open(filename, 'r').read())
    #
    #         hosts_actual = []
    #
    #
    #         results = []
    #
    #         for k in data["stats"].keys():
    #             hosts_actual.append(k)
    #             results.append([k])
    #
    #         of.write("* Results\n")
    #
    #         cols = data["stats"][hosts_actual[0]].keys()
    #         results.insert(0, ["", *cols])
    #
    #         fresults = []
    #         import copy
    #         for row in results:
    #             if row[0] == "":
    #                 fresults.append(row)
    #                 continue
    #             frow = copy.deepcopy(row)
    #             h = frow[0]
    #             for col in cols:
    #                 marker1 = ""
    #                 marker2 = ""
    #                 if col == "ok":
    #                     marker1 = " ( "
    #                     marker2 = " ) "
    #                 frow.append(marker1 + str(data["stats"][h][col]) + marker2)
    #             fresults.append(frow)
    #
    #         for row in fresults:
    #             of.write("| ")
    #             of.write(" | ".join(row))
    #             of.write(" |\n")
    #
    #
    #
    #     except:
    #         pass
    #     print("lets look at ansible json output...")
    #
    #
    #     of.write("* Tasklog\n\n")
    #
    #     for h in hosts_actual:
    #         of.write("** Tasks run on host =%s=\n\n" % h)
    #
    #         for p in data["plays"]:
    #             play_file = p["play"]["path"].split("/")[-1]
    #             for t in p["tasks"]:
    #                 task_file = t["task"]["path"].split("/")[-1]
    #                 if h in t["hosts"].keys():
    #                     task_action = t["hosts"][h]["action"]
    #                     is_failed = False
    #                     if "failed" in t["hosts"][h].keys():
    #                         if t["hosts"][h]["failed"] == True:
    #                             is_failed = True
    #
    #                     fail_s = ""
    #                     if is_failed:
    #                         fail_s = "TODO "
    #                     of.write("*** %s=%s= / =%s= / =%s=\n\n" % (fail_s, play_file, task_file, task_action))
    #
    #                     if is_failed:
    #                         of.write("#+begin_src \n")
    #                         if "msg" in t["hosts"][h].keys():
    #                             of.write("%s\n" % (t["hosts"][h]["msg"]).strip())
    #                         of.write("#+end_src\n")
    #
    #
    #     #PP(data)
