from turbocore.utils.tailgrepper import main


if __name__ == "__main__":
    main()
