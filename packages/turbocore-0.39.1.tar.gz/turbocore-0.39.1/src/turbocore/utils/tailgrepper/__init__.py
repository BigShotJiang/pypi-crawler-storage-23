import turbocore


def tg_help():
    pass

def main():
    turbocore.cli_this(__name__, "tg_")
