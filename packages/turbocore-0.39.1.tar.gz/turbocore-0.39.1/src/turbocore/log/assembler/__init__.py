import turbocore

def la_multi(LOCATIONS, PREFIX, STRATEGY):
    pass

def main():
    turbocore.cli_this(__name__, "la_")
