import os
import subprocess
import rich


class SectionalComponent:

    def __init__(self, parent_section=None, title=None, state=None, day=None):
        self._parent_section = parent_section
        self._title = title
        self._data = []
        self._raw_lines = []
        self._state = state
        self._day = day


    def append_section(self, title):
        res = SectionalComponent(parent_section=self, title=title)
        self._data.append(res)
        return res


    def writeln(self, line=""):
        self._raw_lines.append(line)

    def writelnall(self, lines=[]):
        for line in lines:
            self.writeln(line)

    def src(self, lines=[]):
        self.writeln("#+begin_src ")
        for line in lines:
            self.writeln(line)
        self.writeln("#+end_src")

    def src_table(self, data=[[]]):
        self.writeln("")
        for row in data:
            line = "| "
            for col in row:
                line += " =%s= |" % str(col)
            self.writeln(line)
        self.writeln("")

    def table(self, data=[[]]):
        self.writeln("")
        for row in data:
            line = "| "
            for col in row:
                line += " %s |" % str(col)
            self.writeln(line)
        self.writeln("")


    def table011(self, rowheaders=[], headers=[], net_data=[[]], src_cell=False, src_headers=False):
        src_headers_str = ""
        if src_headers:
            src_headers_str = "="

        src_cell_str = ""
        if src_cell:
            src_cell_str = "="

        data = [ [""] + [ src_headers_str+x+src_headers_str for x in headers] ]

        row_i = 0
        for row in net_data:
            new_row = [ src_headers_str + str(rowheaders[row_i]) + src_headers_str] + [src_cell_str + str(x) + src_cell_str for x in row]
            data.append((new_row))
            row_i += 1

        self.writeln("")
        for row in data:
            line = "| "
            for col in row:
                line += " %s |" % str(col)
            self.writeln(line)
        self.writeln("")

    def src1(self, line):
        self.src(lines=[line])


    def build(self, f, depth=0):
        if self._title is not None:
            state_str = ""
            if self._state is not None:
                state_str = " " + self._state
            day_str = ""
            if self._day is not None:
                day_str = self._day
            f.write("*"*depth + "%s %s %s\n\n" % (state_str, day_str, self._title))

        for raw_line in self._raw_lines:
            f.write(raw_line)
            f.write("\n")


        for item in self._data:
            item.build(f, depth=depth+1)


class OrgOut:

    def __init__(self, title="Untitled"):
        self._title = title
        self._root = SectionalComponent()


    def compile(self, parent_outdir="/tmp/turbocore-orgout", run_emacs=True):
        the_dir = os.path.join(parent_outdir, self._title)
        the_index = os.path.join(the_dir, "index.org")
        os.makedirs(the_dir, exist_ok=True)
        with open(the_index, 'w') as f:
            self._root.build(f)

        if run_emacs:
            subprocess.check_output("""/bin/bash -c 'cd "%s" && eeee'""" % the_dir, shell=True, universal_newlines=True)


def rich_diagram_type1(data=None):
    import rich.console
    #console = rich.console.Console(width=200, color_system=None, force_terminal=True, file=ascii_out)
    console = rich.console.Console(width=80, record=True, force_terminal=True)


    from rich.console import Console
    from rich.table import Table
    table = Table(
        show_header=False,
        box=None,
        pad_edge=False
    )

    table.add_column("L", justify="right")
    table.add_column("R", justify="left")

    data_min = float(data[0][1])
    data_max = float(data[0][1])
    data_avg = 0.0

    for row in data:
        if row[1] < data_min:
            data_min = row[1]
        if row[1] > data_max:
            data_max = row[1]

    table.add_row("MIN", "%f" % data_min)
    table.add_row("MAX", "%f" % data_max)

    w = 40

    for row in data:
        if row[1] < data_min:
            data_min = row[1]
        bdata = "█"
        table.add_row(row[0], "%s %.2f" % (bdata, row[1]))

    with console.capture() as capture:
        console.print(table)

    res = capture.get().replace("\n", "\n\n").strip()
    return res



if __name__ == "__main__":
    oo = OrgOut(title="Diagramme Test")

    s1 = oo._root.append_section("le first")
    s2 = oo._root.append_section("le second")
    s2._day = "[2022-02-02]"

    mopp = s1.append_section("mopp")
    s1.writeln(line="test inhalt")

    mopp._state = "TODO"
    mopp.src1("jojo")

    s2.table011(["R1", "R2"], ["L", "R"], [[0, 1], [2, 3]])
    s2.writeln()
    mopp._day = "[2022-02-02]"


    # import io
    # ascii_out = io.TextIOWrapper(io.BytesIO(), encoding="ascii", errors="replace")

    bar_data = [
        ['a', 17.8],
        ['b', 100 ],
        ['c', -20 ],
        ['d', -40 ],
        ['e', 150 ]
    ]

    plaintext = rich_diagram_type1(bar_data)
    mopp.src(plaintext.split("\n"))

    oo.compile()
