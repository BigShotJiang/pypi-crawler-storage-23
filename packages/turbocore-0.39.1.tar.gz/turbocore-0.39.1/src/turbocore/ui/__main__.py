import wx
import wx.adv
import wx.dataview as DV



def make_icon(text="R+", size_f=0.75*0.5, fg=None):
    size = 32
    bmp = wx.Bitmap(size, size)
    bmp.UseAlpha()
    dc = wx.MemoryDC(bmp)

    font = wx.Font(
        int(size * size_f),          # Schriftgröße relativ zur Icongröße
        wx.FONTFAMILY_SWISS,
        wx.FONTSTYLE_NORMAL,
        wx.FONTWEIGHT_BOLD
    )
    dc.SetFont(font)

    dc.SetBackground(wx.Brush(wx.Colour(0,0,0, 0)))  # transparent
    dc.Clear()

    dc.SetTextForeground(wx.Colour(0, 0, 0))

    if fg is None:
        fg = wx.SystemSettings.GetColour(wx.SYS_COLOUR_MENUTEXT)  # oder WINDOWTEXT
        dc.SetTextForeground(fg)

    tw, th = dc.GetTextExtent("R")
    x = (size - tw) // 2
    y = (size - th) // 2
    dc.DrawText(text, x, y)

    dc.SelectObject(wx.NullBitmap)

    icon = wx.Icon(bmp)
    return icon



class Tray(wx.adv.TaskBarIcon):
    def __init__(self, text, size_f):
        super().__init__()
        self._text = text
        self._size_f = size_f
        self.RefreshIcon()

    def RefreshIcon(self):
        self.SetIcon(make_icon(text=self._text, size_f=self._size_f))

    def CreatePopupMenu(self):
        menu = wx.Menu()
        item_exit = menu.Append(wx.ID_EXIT, "Quit")
        
        return menu


class MyFrame(wx.Frame):

    def __init__(self, parent=None, title="", tray=None):
        wx.Frame.__init__(self, parent, wx.ID_ANY, title=title, size=(800,600))


        panel = wx.Panel(self)
        sizer = wx.BoxSizer(wx.VERTICAL)




        self.dvlc = DV.DataViewListCtrl(
            panel,
            style=wx.BORDER_THEME | DV.DV_ROW_LINES | DV.DV_VERT_RULES | DV.DV_HORIZ_RULES
        )

        self.dvlc.Bind(DV.EVT_DATAVIEW_ITEM_CONTEXT_MENU, self.on_context_menu)

        self.dvlc.AppendTextColumn("ID", width=80)
        self.dvlc.AppendTextColumn("Name", width=200)
        self.dvlc.AppendTextColumn("Beschreibung", width=600)

        # data
        self.dvlc.AppendItem(["a", "0", "True"])
        self.dvlc.AppendItem(["b", "1", "True"])

        sizer.Add(self.dvlc, 1, wx.EXPAND | wx.ALL, 8)
        panel.SetSizer(sizer)

        self._tray = tray

        filemenu = wx.Menu()
        menu_about = filemenu.Append(wx.ID_ABOUT, "&About...", " About this program")
        filemenu.AppendSeparator()
        menu_exit = filemenu.Append(wx.ID_EXIT, "E&xit", " Terminate the program")

        testmenu = wx.Menu()
        menu_abc = testmenu.Append(wx.ID_ANY, "ABC", "ABC")


        menubar = wx.MenuBar()
        menubar.Append(filemenu, "&File")
        menubar.Append(testmenu, "ABCD")

        self.SetMenuBar(menubar)

        self.Bind(wx.EVT_MENU, self.OnABC, menu_abc)
        self.Bind(wx.EVT_MENU, self.OnExit, menu_exit)
        self.Bind(wx.EVT_MENU, self.OnAbout, menu_about)

        self.Bind(wx.EVT_SYS_COLOUR_CHANGED, self.OnSysColourChanged)


        self.Show(True)
        # self.Maximize(True)


    def OnABC(self, event):
        dlg = wx.MessageDialog(self, "a", "b", wx.OK)
        dlg.ShowModal()
        dlg.Destroy()

    def OnAbout(self, event):
        dlg = wx.MessageDialog(self, "Version X", "About", wx.OK)
        dlg.ShowModal()
        dlg.Destroy()

    def OnSysColourChanged(self, event):
        if self._tray is not None:
            self._tray.RefreshIcon()

    def OnExit(self, event):
        import sys
        self.Close(True)
        sys.exit(0)

    def on_edit(self, item):
        self.Title = "edit %s" % str(item)

    def on_context_menu(self, event):
        self.Title = "okok"
        item = event.GetItem()
        if not item.IsOk():
            return
        self.dvlc.Select(item)

        menu = wx.Menu()
        edit = menu.Append(wx.ID_ANY, "&Edit")
        delete = menu.Append(wx.ID_ANY, "&Delete")

        self.Bind(wx.EVT_MENU, lambda e: self.on_edit(item), edit)


        self.PopupMenu(menu)
        menu.Destroy()


class MyApp(wx.App):

    def __init__(self):
        # self._frame1 = MyFrame(None, "Test", tray=self._tray)
        # self._tray = Tray(text="A+", size_f=0.75*0.75)
        wx.App.__init__(self)
        self.SetAppName("b1")
        self.SetAppDisplayName("b2")


    def OnInit(self):
        self._tray = Tray(text="A+", size_f=0.75*0.75)
        self._frame1 = MyFrame(None, "Test", tray=self._tray)
        self.SetTopWindow(self._frame1)
        return True




app = MyApp()

app.MainLoop()
