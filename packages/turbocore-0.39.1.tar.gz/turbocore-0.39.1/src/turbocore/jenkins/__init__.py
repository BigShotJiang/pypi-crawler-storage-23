import requests
import logging
import os

SESSION = None
BASE_URL = None
USRNAME = None

def initialize():
    global SESSION
    global BASE_URL
    global USERNAME

    SESSION = requests.Session()

    ssl_host = os.environ.get("TC_JENKINS_HOST")
    ssl_port = int(os.environ.get("TC_JENKINS_PORT", "443"))
    username = os.environ.get("TC_JENKINS_USERNAME")
    password = os.environ.get("TC_JENKINS_PASSWORD")


    USERNAME = username
    SESSION.auth = (username, password)
    BASE_URL = "https://%s:%d" % (ssl_host, ssl_port)

    logging.info("Jenkins api client initialized to talk to %s as user %s" % (BASE_URL, USERNAME))


def apicall_overview():
    pass

def main():

    import logging
    import time
    FORMAT = '%(asctime)s+00:00 %(levelname)10s: %(message)-80s'
    logging.basicConfig(level=logging.INFO, format=FORMAT)
    logging.Formatter.converter = time.gmtime

    initialize()
