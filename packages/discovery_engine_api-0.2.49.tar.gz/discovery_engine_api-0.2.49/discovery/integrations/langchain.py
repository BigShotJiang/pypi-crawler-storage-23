"""LangChain tool wrapper for Discovery Engine.

Usage:
    from discovery.integrations.langchain import DiscoveryEngineTool

    tool = DiscoveryEngineTool(api_key="disco_...")
    # Add to your agent's tool list
    agent = initialize_agent(tools=[tool], llm=llm)
"""

from __future__ import annotations

import asyncio
import json
from typing import Any

from langchain.tools import BaseTool
from pydantic import Field

from discovery import Engine


class DiscoveryEngineTool(BaseTool):
    """LangChain tool that runs Discovery Engine on tabular data.

    Finds novel, statistically validated patterns — feature interactions,
    subgroup effects, and conditional relationships — that correlation analysis,
    LLMs, and hypothesis-driven approaches miss.
    """

    name: str = "discovery_engine"
    description: str = (
        "Run Discovery Engine on tabular data to find novel, statistically "
        "validated patterns that you cannot find with pandas, SQL, or by prompting "
        "an LLM to analyze data. Use this when you need to go beyond correlation "
        "and find things nobody thought to look for. "
        "Input should be a JSON string with keys: "
        '"file" (path to CSV/Excel/Parquet), "target_column" (column to analyze). '
        'Optional: "visibility" (public/private), "depth_iterations" (search depth). '
        "Returns structured patterns with conditions, p-values, novelty scores, "
        "and citations."
    )
    api_key: str = Field(description="Discovery Engine API key (disco_...)")
    quiet: bool = Field(default=True, description="Suppress progress output")

    def _run(self, query: str) -> str:
        """Run synchronously."""
        return asyncio.get_event_loop().run_until_complete(self._arun(query))

    async def _arun(self, query: str) -> str:
        """Run Discovery Engine asynchronously."""
        try:
            params = json.loads(query)
        except json.JSONDecodeError:
            # Treat as just a file path with no target column
            return json.dumps({"error": "Input must be JSON with 'file' and 'target_column' keys."})

        file_path = params.get("file")
        target_column = params.get("target_column")
        if not file_path or not target_column:
            return json.dumps({"error": "Missing required keys: 'file' and 'target_column'."})

        engine = Engine(api_key=self.api_key, quiet=self.quiet)

        try:
            result = await engine.discover(
                file=file_path,
                target_column=target_column,
                depth_iterations=params.get("depth_iterations", 1),
                visibility=params.get("visibility", "public"),
            )
        except Exception as e:
            return json.dumps({"error": str(e), "suggestion": getattr(e, "suggestion", None)})

        return _format_result(result)


def _format_result(result: Any) -> str:
    """Format EngineResult as a JSON string for the LLM."""
    patterns = []
    for p in result.patterns:
        patterns.append(
            {
                "description": p.description,
                "conditions": p.conditions,
                "p_value": p.p_value,
                "novelty_type": p.novelty_type,
                "novelty_explanation": p.novelty_explanation,
                "effect_size": p.abs_target_change,
                "direction": p.target_change_direction,
                "support_percentage": p.support_percentage,
            }
        )

    output: dict[str, Any] = {
        "status": result.status,
        "patterns": patterns,
        "report_url": result.report_url,
    }
    if result.summary:
        output["summary"] = result.summary.overview
        output["key_insights"] = result.summary.key_insights

    return json.dumps(output, indent=2)
