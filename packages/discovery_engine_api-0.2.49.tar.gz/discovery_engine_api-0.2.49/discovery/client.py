"""Discovery Engine Python SDK."""

import asyncio
import os
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple, Union

import httpx

try:
    import pandas as pd
except ImportError:
    pd = None

from discovery.errors import (
    AuthenticationError,
    InsufficientCreditsError,
    PaymentRequiredError,
    RateLimitError,
    RunFailedError,
    RunNotFoundError,
)
from discovery.types import (
    Column,
    CorrelationEntry,
    EngineResult,
    FeatureImportance,
    FeatureImportanceScore,
    FileInfo,
    Pattern,
    PatternGroup,
    RunStatus,
    Summary,
)


class Engine:
    """Client for the Discovery Engine API.

    The primary method is ``discover()`` — submit a dataset, wait for analysis,
    and get back structured patterns with p-values, novelty scores, and citations.

    Args:
        api_key: Your Discovery Engine API key (``disco_...``).
        quiet: If True, suppress all status output. Useful for agent workflows.
    """

    # Production API URL (can be overridden via DISCOVERY_API_URL env var for testing)
    _DEFAULT_BASE_URL = "https://leap-labs-production--discovery-api.modal.run"

    # Dashboard URL for web UI and /api/* endpoints
    _DEFAULT_DASHBOARD_URL = "https://disco.leap-labs.com"

    _TIMEOUT = httpx.Timeout(connect=30.0, read=300.0, write=1800.0, pool=30.0)

    def __init__(self, api_key: str, *, quiet: bool = False):
        self.api_key = api_key
        self.quiet = quiet
        self.base_url = os.getenv("DISCOVERY_API_URL", self._DEFAULT_BASE_URL).rstrip("/")
        self.dashboard_url = os.getenv(
            "DISCOVERY_DASHBOARD_URL", self._DEFAULT_DASHBOARD_URL
        ).rstrip("/")
        self._organization_id: Optional[str] = None
        self._client: Optional[httpx.AsyncClient] = None
        self._dashboard_client: Optional[httpx.AsyncClient] = None
        self._org_fetched = False
        self._log("Initializing Discovery Engine...")

    def _log(self, message: str) -> None:
        """Print a message unless quiet mode is enabled."""
        if not self.quiet:
            print(message)

    # ------------------------------------------------------------------
    # HTTP clients
    # ------------------------------------------------------------------

    async def _get_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client."""
        if self._client is None:
            self._client = httpx.AsyncClient(
                base_url=self.base_url,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=self._TIMEOUT,
            )
        return self._client

    async def _get_client_with_org(self) -> httpx.AsyncClient:
        """Get HTTP client with organization header set."""
        client = await self._get_client()
        org_id = await self._ensure_organization_id()
        client.headers["X-Organization-ID"] = org_id
        return client

    async def _get_dashboard_client(self) -> httpx.AsyncClient:
        """Get or create the HTTP client for dashboard API calls."""
        if self._dashboard_client is None:
            self._dashboard_client = httpx.AsyncClient(
                base_url=self.dashboard_url,
                headers={"Authorization": f"Bearer {self.api_key}"},
                timeout=self._TIMEOUT,
            )
        return self._dashboard_client

    @classmethod
    def _make_anon_client(cls) -> httpx.AsyncClient:
        """Create an unauthenticated client for public endpoints."""
        base_url = os.getenv("DISCOVERY_API_URL", cls._DEFAULT_BASE_URL).rstrip("/")
        return httpx.AsyncClient(base_url=base_url, timeout=cls._TIMEOUT)

    async def close(self) -> None:
        """Close the HTTP clients."""
        if self._client:
            await self._client.aclose()
            self._client = None
        if self._dashboard_client:
            await self._dashboard_client.aclose()
            self._dashboard_client = None

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    # ------------------------------------------------------------------
    # Error handling helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _raise_for_status(response: httpx.Response) -> None:
        """Raise structured errors for common HTTP status codes."""
        if response.status_code < 400:
            return
        try:
            body = response.json()
            detail = body.get("detail") or body.get("error") or response.text
        except Exception:
            detail = response.text

        if response.status_code == 401:
            raise AuthenticationError(str(detail))
        if response.status_code == 402:
            raise PaymentRequiredError(str(detail))
        if response.status_code == 404:
            raise RunNotFoundError(message=str(detail))
        if response.status_code == 429:
            retry_after = response.headers.get("Retry-After")
            raise RateLimitError(
                retry_after=float(retry_after) if retry_after else None,
                message=str(detail),
            )
        # Fall through to httpx default
        response.raise_for_status()

    # ------------------------------------------------------------------
    # Organization resolution
    # ------------------------------------------------------------------

    async def _ensure_organization_id(self) -> str:
        """Fetch and cache organization ID for multi-tenancy."""
        if self._organization_id:
            return self._organization_id

        if not self._org_fetched:
            try:
                orgs = await self.get_organizations()
                if orgs:
                    self._organization_id = orgs[0]["id"]
            except (ValueError, AuthenticationError) as e:
                raise AuthenticationError(
                    f"Failed to fetch organization: {e}. "
                    "Please ensure your API key is valid and you belong to an organization."
                ) from e
            self._org_fetched = True

        if not self._organization_id:
            raise AuthenticationError(
                "No organization found for your account. "
                "Please contact support if this issue persists."
            )

        return self._organization_id

    async def get_organizations(self) -> List[Dict[str, Any]]:
        """Get the organizations you belong to."""
        client = await self._get_client()
        response = await client.get("/v1/me/organizations")
        self._raise_for_status(response)
        return response.json()

    # ------------------------------------------------------------------
    # No-auth class methods
    # ------------------------------------------------------------------

    @classmethod
    async def list_plans(cls) -> List[Dict[str, Any]]:
        """List available plans and pricing. No authentication required.

        Returns:
            Dict with ``plans`` list, ``credit_price_usd``, ``credit_pack_size``,
            and ``credit_pack_price_usd``.
        """
        async with cls._make_anon_client() as client:
            response = await client.get("/v1/plans")
            response.raise_for_status()
            return response.json()

    @classmethod
    async def signup(
        cls,
        email: str,
        *,
        name: Optional[str] = None,
        quiet: bool = False,
    ) -> "Engine":
        """Create an account and return a configured Engine instance.

        Zero-touch signup: one call with an email address, returns a fully
        provisioned Engine with a ``disco_`` API key. Free tier is active
        immediately.

        Args:
            email: Email address for the new account.
            name: Display name (optional — defaults to email local part).
            quiet: If True, suppress status output.

        Returns:
            A configured Engine instance with the new API key.

        Raises:
            ValueError: If the email is already registered (409).
        """
        body: Dict[str, Any] = {"email": email}
        if name:
            body["name"] = name
        async with cls._make_anon_client() as client:
            response = await client.post("/v1/signup", json=body)
            cls._raise_for_status(response)
            data = response.json()

        engine = cls(api_key=data["key"], quiet=quiet)
        if not quiet:
            print(
                f"Account created. Tier: {data.get('tier', 'free_tier')}, "
                f"Credits: {data.get('credits', 0)}"
            )
        return engine

    # ------------------------------------------------------------------
    # discover() — the primary method for agents
    # ------------------------------------------------------------------

    async def discover(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        target_column: str,
        depth_iterations: int = 1,
        visibility: str = "public",
        title: Optional[str] = None,
        description: Optional[str] = None,
        column_descriptions: Optional[Dict[str, str]] = None,
        excluded_columns: Optional[List[str]] = None,
        timeout: float = 1800,
        **kwargs,
    ) -> EngineResult:
        """Run Discovery Engine on a dataset and return results.

        This is the primary method. It uploads data, submits the analysis,
        polls for completion, and returns structured results — all in one call.
        Runs typically take 3-15 minutes.

        Args:
            file: File path, Path object, or pandas DataFrame.
            target_column: Column to analyze (what drives it up or down?).
            depth_iterations: 1=fast, higher=deeper pattern search (max: num_columns - 2).
            visibility: "public" (free, published) or "private" (costs credits).
            title: Optional dataset title.
            description: Optional dataset description.
            column_descriptions: Dict mapping column names to descriptions.
                Significantly improves pattern explanations for non-obvious column names.
            excluded_columns: Columns to exclude from analysis.
            timeout: Max seconds to wait for completion (default: 1800).
            **kwargs: Additional arguments passed to run_async().

        Returns:
            EngineResult with patterns, summary, feature importance, and report_url.

        Raises:
            InsufficientCreditsError: Not enough credits for a private run.
            RunFailedError: Analysis failed server-side.
            TimeoutError: Analysis didn't complete within timeout.
            FileNotFoundError: Input file doesn't exist.
        """
        return await self.run_async(
            file=file,
            target_column=target_column,
            depth_iterations=depth_iterations,
            visibility=visibility,
            title=title,
            description=description,
            column_descriptions=column_descriptions,
            excluded_columns=excluded_columns,
            wait=True,
            wait_timeout=timeout,
            **kwargs,
        )

    def discover_sync(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        target_column: str,
        depth_iterations: int = 1,
        visibility: str = "public",
        title: Optional[str] = None,
        description: Optional[str] = None,
        column_descriptions: Optional[Dict[str, str]] = None,
        excluded_columns: Optional[List[str]] = None,
        timeout: float = 1800,
        **kwargs,
    ) -> EngineResult:
        """Synchronous version of discover(). See discover() for full docs."""
        return self._run_sync(
            self.discover(
                file=file,
                target_column=target_column,
                depth_iterations=depth_iterations,
                visibility=visibility,
                title=title,
                description=description,
                column_descriptions=column_descriptions,
                excluded_columns=excluded_columns,
                timeout=timeout,
                **kwargs,
            )
        )

    # ------------------------------------------------------------------
    # Account & billing
    # ------------------------------------------------------------------

    async def get_account(self) -> Dict[str, Any]:
        """Get account info: plan, credits, payment method status.

        Returns:
            Dict with ``plan``, ``credits``, ``payment_method``, and more.
        """
        client = await self._get_client_with_org()
        response = await client.get("/v1/account")
        self._raise_for_status(response)
        return response.json()

    async def add_payment_method(self, payment_method_id: str) -> Dict[str, Any]:
        """Attach a Stripe payment method to your account.

        The payment method must be tokenized via Stripe's API first (card details
        never touch Discovery Engine).

        Args:
            payment_method_id: Stripe payment method token (``pm_...``).

        Returns:
            Dict with ``payment_method_attached``, ``card_last4``, ``card_brand``.
        """
        client = await self._get_client_with_org()
        response = await client.post(
            "/v1/account/payment-method",
            json={"payment_method_id": payment_method_id},
        )
        self._raise_for_status(response)
        return response.json()

    async def subscribe(self, plan: str) -> Dict[str, Any]:
        """Subscribe to or change your plan.

        Args:
            plan: Plan tier — "free_tier", "tier_1", or "tier_2".

        Returns:
            Dict with ``plan``, ``name``, ``monthly_credits``, ``price_usd``.
        """
        client = await self._get_client_with_org()
        response = await client.post(
            "/v1/account/subscribe",
            json={"plan": plan},
        )
        self._raise_for_status(response)
        return response.json()

    async def purchase_credits(self, packs: int = 1) -> Dict[str, Any]:
        """Purchase credit packs. Each pack is 20 credits for $20.

        Requires a payment method on file.

        Args:
            packs: Number of 20-credit packs to purchase (default: 1).

        Returns:
            Dict with ``purchased_credits``, ``total_credits``, ``charge_amount_usd``.

        Raises:
            PaymentRequiredError: No payment method on file.
        """
        client = await self._get_client_with_org()
        response = await client.post(
            "/v1/account/credits/purchase",
            json={"packs": packs},
        )
        self._raise_for_status(response)
        return response.json()

    # ------------------------------------------------------------------
    # Estimation (works with or without auth)
    # ------------------------------------------------------------------

    async def estimate(
        self,
        file_size_mb: float,
        num_columns: int,
        num_rows: Optional[int] = None,
        depth_iterations: int = 1,
        visibility: str = "public",
    ) -> Dict[str, Any]:
        """Estimate cost and time for an analysis run.

        Works with or without authentication. If authenticated, the response
        includes your current credit balance and whether you have enough.

        Args:
            file_size_mb: Size of the data file in megabytes.
            num_columns: Number of columns in the dataset.
            num_rows: Number of rows (improves time estimate accuracy).
            depth_iterations: Depth iterations (1=fast, higher=deeper).
            visibility: "public" (free, depth=1) or "private" (costs credits).

        Returns:
            Dict with ``cost``, ``time_estimate``, ``limits``, and ``account`` info.
        """
        # Use authenticated client if we have an API key and org,
        # fall back to unauthenticated for no-auth usage
        try:
            client = await self._get_client_with_org()
        except (AuthenticationError, ValueError):
            client = await self._get_client()

        response = await client.post(
            "/v1/estimate",
            json={
                "file_size_mb": file_size_mb,
                "num_columns": num_columns,
                "num_rows": num_rows,
                "depth_iterations": depth_iterations,
                "visibility": visibility,
            },
        )
        self._raise_for_status(response)
        return response.json()

    # ------------------------------------------------------------------
    # Dataset & run management (lower-level API)
    # ------------------------------------------------------------------

    async def create_dataset(
        self,
        title: Optional[str] = None,
        description: Optional[str] = None,
        total_rows: int = 0,
        dataset_size_mb: Optional[float] = None,
        author: Optional[str] = None,
        source_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a dataset record."""
        client = await self._get_client_with_org()
        response = await client.post(
            "/v1/run-datasets",
            json={
                "title": title,
                "description": description,
                "total_rows": total_rows,
                "dataset_size_mb": dataset_size_mb,
                "author": author,
                "source_url": source_url,
            },
        )
        response.raise_for_status()
        return response.json()

    async def create_file_record(self, dataset_id: str, file_info: FileInfo) -> Dict[str, Any]:
        """Create a file record for a dataset."""
        client = await self._get_client_with_org()
        response = await client.post(
            f"/v1/run-datasets/{dataset_id}/files",
            json={
                "mime_type": file_info.mime_type,
                "file_path": file_info.file_path,
                "file_hash": file_info.file_hash,
                "file_size": file_info.file_size,
            },
        )
        response.raise_for_status()
        return response.json()

    async def create_columns(
        self, dataset_id: str, columns: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Create column records for a dataset."""
        client = await self._get_client_with_org()
        response = await client.post(
            f"/v1/run-datasets/{dataset_id}/columns",
            json=columns,
        )
        response.raise_for_status()
        return response.json()

    async def create_run(
        self,
        dataset_id: str,
        target_column_id: str,
        task: str = "regression",
        depth_iterations: int = 1,
        visibility: str = "public",
        timeseries_groups: Optional[List[Dict[str, Any]]] = None,
        target_column_override: Optional[str] = None,
        auto_report_use_llm_evals: bool = True,
        author: Optional[str] = None,
        source_url: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Create a run and enqueue it for processing."""
        client = await self._get_client_with_org()

        payload = {
            "run_target_column_id": target_column_id,
            "task": task,
            "depth_iterations": depth_iterations,
            "visibility": visibility,
            "auto_report_use_llm_evals": auto_report_use_llm_evals,
        }

        if timeseries_groups:
            payload["timeseries_groups"] = timeseries_groups
        if target_column_override:
            payload["target_column_override"] = target_column_override
        if author:
            payload["author"] = author
        if source_url:
            payload["source_url"] = source_url

        response = await client.post(
            f"/v1/run-datasets/{dataset_id}/runs",
            json=payload,
        )
        response.raise_for_status()
        return response.json()

    async def get_results(self, run_id: str) -> EngineResult:
        """Get complete analysis results for a run."""
        dashboard_client = await self._get_dashboard_client()
        response = await dashboard_client.get(f"/api/runs/{run_id}/results")
        if response.status_code == 404:
            try:
                body = response.json()
                detail = body.get("error", "Unknown")
                code = body.get("code", "UNKNOWN")
            except Exception:
                detail = response.text
                code = "UNKNOWN"
            raise RunNotFoundError(
                run_id=run_id,
                message=f"Run {run_id} not found: {detail} (code={code})",
            )
        self._raise_for_status(response)
        data = response.json()
        return self._parse_analysis_result(data)

    async def get_run_status(self, run_id: str) -> RunStatus:
        """Get the status of a run."""
        dashboard_client = await self._get_dashboard_client()
        response = await dashboard_client.get(f"/api/runs/{run_id}/results")
        self._raise_for_status(response)
        data = response.json()
        return RunStatus(
            run_id=data["run_id"],
            status=data["status"],
            job_id=data.get("job_id"),
            job_status=data.get("job_status"),
            error_message=data.get("error_message"),
        )

    async def wait_for_completion(
        self,
        run_id: str,
        poll_interval: float = 5.0,
        timeout: Optional[float] = None,
    ) -> EngineResult:
        """Wait for a run to complete and return the results.

        Raises:
            TimeoutError: If the run doesn't complete within the timeout.
            RunFailedError: If the run fails server-side.
            RunNotFoundError: If the run disappears during polling.
        """
        start_time = time.time()
        last_status = None
        poll_count = 0
        consecutive_errors = 0
        max_consecutive_errors = 3

        self._log(f"Waiting for run {run_id} to complete...")

        while True:
            try:
                result = await self.get_results(run_id)
                consecutive_errors = 0
            except RunNotFoundError:
                consecutive_errors += 1
                elapsed = time.time() - start_time
                if consecutive_errors >= max_consecutive_errors:
                    raise RunNotFoundError(
                        run_id=run_id,
                        message=(
                            f"Run {run_id} not found after {elapsed:.0f}s of polling "
                            f"(last status: {last_status}). "
                            "The run may have been deleted or cleaned up server-side."
                        ),
                    )
                self._log(
                    f"  Run returned 404 (attempt {consecutive_errors}/{max_consecutive_errors}), retrying..."
                )
                await asyncio.sleep(poll_interval)
                continue
            except httpx.HTTPStatusError:
                consecutive_errors += 1
                if consecutive_errors >= max_consecutive_errors:
                    raise
                await asyncio.sleep(poll_interval)
                continue

            elapsed = time.time() - start_time
            poll_count += 1

            if result.status != last_status or poll_count % 3 == 0:
                status_msg = f"Status: {result.status}"
                if result.job_status:
                    status_msg += f" (job: {result.job_status})"
                if elapsed > 0:
                    status_msg += f" | Elapsed: {elapsed:.1f}s"
                self._log(f"  {status_msg}")

            last_status = result.status

            if result.status == "completed":
                self._log(f"Run completed in {elapsed:.1f}s")
                return result
            elif result.status == "failed":
                error_msg = result.error_message or "Unknown error"
                self._log(f"Run failed: {error_msg}")
                raise RunFailedError(run_id, error_msg)

            if timeout and elapsed > timeout:
                raise TimeoutError(f"Run {run_id} did not complete within {timeout} seconds")

            await asyncio.sleep(poll_interval)

    # ------------------------------------------------------------------
    # File upload
    # ------------------------------------------------------------------

    async def _presign_and_upload(
        self,
        file_content: bytes,
        filename: str,
        mime_type: str,
    ) -> Tuple[Dict[str, Any], Dict[str, Any]]:
        """Upload a file using presigned URL (3-step: presign, upload, finalize)."""
        dashboard_client = await self._get_dashboard_client()
        file_size = len(file_content)

        presign_response = await dashboard_client.post(
            "/api/data/upload/presign",
            json={
                "fileName": filename,
                "contentType": mime_type,
                "fileSize": file_size,
            },
        )

        if presign_response.status_code >= 400:
            try:
                error_data = presign_response.json()
                error_message = error_data.get("error", presign_response.text)
            except Exception:
                error_message = presign_response.text
            raise ValueError(f"Presign error ({presign_response.status_code}): {error_message}")

        presign_data = presign_response.json()
        upload_url = presign_data["uploadUrl"]
        key = presign_data["key"]
        upload_token = presign_data["uploadToken"]

        async with httpx.AsyncClient(timeout=self._TIMEOUT) as upload_client:
            upload_response = await upload_client.put(
                upload_url,
                content=file_content,
                headers={"Content-Type": mime_type},
            )
            if upload_response.status_code >= 400:
                raise ValueError(
                    f"Direct upload failed ({upload_response.status_code}): {upload_response.text}"
                )

        finalize_response = await dashboard_client.post(
            "/api/data/upload/finalize",
            json={"key": key, "uploadToken": upload_token},
        )

        if finalize_response.status_code >= 400:
            try:
                error_data = finalize_response.json()
                error_message = error_data.get("error", finalize_response.text)
                if "issues" in error_data:
                    errors = error_data["issues"].get("errors", [])
                    if errors:
                        error_message = errors[0].get("message", error_message)
            except Exception:
                error_message = finalize_response.text
            raise ValueError(f"Finalize error ({finalize_response.status_code}): {error_message}")

        return presign_data, finalize_response.json()

    async def _upload_file_direct(
        self,
        file_content: bytes,
        filename: str,
        mime_type: str,
    ) -> Dict[str, Any]:
        """Upload a file using presigned URL. Returns finalize result."""
        _, finalize_data = await self._presign_and_upload(
            file_content=file_content,
            filename=filename,
            mime_type=mime_type,
        )
        return finalize_data

    def _prepare_upload(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        filename: Optional[str] = None,
        title: Optional[str] = None,
        log: bool = False,
    ) -> Tuple[bytes, str, str, float]:
        if pd is not None and isinstance(file, pd.DataFrame):
            import io

            if log:
                self._log(f"Preparing DataFrame ({len(file)} rows, {len(file.columns)} columns)...")
            buffer = io.BytesIO()
            file.to_csv(buffer, index=False)
            buffer.seek(0)
            file_content = buffer.getvalue()
            resolved_filename = filename or ((title + ".csv") if title else "dataset.csv")
            mime_type = "text/csv"
        else:
            file_path = Path(file)
            if not file_path.exists():
                raise FileNotFoundError(f"File not found: {file_path}")
            if log:
                self._log(f"Reading file: {file_path.name}...")
            file_content = file_path.read_bytes()
            resolved_filename = filename or file_path.name
            _MIME_TYPES = {
                ".csv": "text/csv",
                ".tsv": "text/tab-separated-values",
                ".json": "application/json",
                ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                ".xls": "application/vnd.ms-excel",
                ".parquet": "application/vnd.apache.parquet",
                ".arff": "text/plain",
                ".feather": "application/octet-stream",
            }
            mime_type = _MIME_TYPES.get(file_path.suffix.lower(), "text/csv")

        file_size_mb = len(file_content) / (1024 * 1024)
        if log:
            self._log(f"  File size: {file_size_mb:.2f} MB")
        return file_content, resolved_filename, mime_type, file_size_mb

    # ------------------------------------------------------------------
    # File upload
    # ------------------------------------------------------------------

    async def upload_file(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        title: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Upload a file and return the server's parsed metadata.

        Use this when you need to inspect the server's column list before
        creating a run (e.g. to choose a target column).  Pass the result
        to ``run_async(upload_result=...)`` to avoid re-uploading.

        Returns:
            Dict with ``file`` (key, name, size, fileHash) and ``columns``
            (list of dicts with ``name``, ``type``, ``enabled``).
        """
        file_content, filename, mime_type, _ = self._prepare_upload(
            file=file,
            title=title,
            log=True,
        )
        self._log("  Uploading to storage...")
        result = await self._upload_file_direct(file_content, filename, mime_type)

        if not result.get("ok"):
            errors = result.get("issues", {}).get("errors", [])
            error_msg = errors[0].get("message") if errors else "Upload failed"
            raise ValueError(f"Upload failed: {error_msg}")

        return {
            "file": result["file"],
            "columns": result.get("columns", []),
            "rowCount": result.get("rowCount"),
        }

    # ------------------------------------------------------------------
    # run_async / run — full-control analysis submission
    # ------------------------------------------------------------------

    async def run_async(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        target_column: str,
        depth_iterations: int = 1,
        title: Optional[str] = None,
        description: Optional[str] = None,
        column_descriptions: Optional[Dict[str, str]] = None,
        excluded_columns: Optional[List[str]] = None,
        task: Optional[str] = None,
        visibility: str = "public",
        timeseries_groups: Optional[List[Dict[str, Any]]] = None,
        target_column_override: Optional[str] = None,
        auto_report_use_llm_evals: bool = True,
        author: Optional[str] = None,
        source_url: Optional[str] = None,
        wait: bool = False,
        wait_timeout: Optional[float] = None,
        upload_result: Optional[Dict[str, Any]] = None,
        **kwargs,
    ) -> EngineResult:
        """Run analysis on a dataset (async).

        For most use cases, prefer ``discover()`` which wraps this with
        ``wait=True`` and a cleaner parameter set.

        Args:
            file: File path, Path object, or pandas DataFrame.
            target_column: Name of the target column.
            depth_iterations: Analysis depth (default 1). Public runs are always depth 1.
            title: Optional dataset title.
            description: Optional dataset description.
            column_descriptions: Dict mapping column names to descriptions.
            excluded_columns: Column names to exclude from analysis.
            task: Task type (auto-detected if None).
            visibility: "public" (free) or "private" (costs credits).
            wait: If True, wait for completion and return full results.
            wait_timeout: Max seconds to wait (only if wait=True).
            upload_result: Pre-uploaded file data from ``upload_file()``.
                If provided, skips the upload step.

        Returns:
            EngineResult with run_id and (if wait=True) complete results.
        """
        # Warn if depth > 1 with public visibility (server will cap to 1)
        if depth_iterations > 1 and visibility == "public":
            self._log(
                "Public runs are limited to depth 1. "
                "Set visibility='private' for deeper analysis (requires credits)."
            )
            depth_iterations = 1

        if upload_result:
            uploaded_file = upload_result["file"]
            columns = upload_result.get("columns", [])
            self._log(
                f"Creating run from pre-uploaded file (depth: {depth_iterations}, target: {target_column})..."
            )
        else:
            file_content, filename, mime_type, _ = self._prepare_upload(
                file=file,
                title=title,
                log=True,
            )
            self._log(
                f"Uploading file and creating run (depth: {depth_iterations}, target: {target_column})..."
            )

            # Step 1: Upload file
            self._log("  Uploading to storage...")
            raw_result = await self._upload_file_direct(file_content, filename, mime_type)

            if not raw_result.get("ok"):
                errors = raw_result.get("issues", {}).get("errors", [])
                error_msg = errors[0].get("message") if errors else "Upload failed"
                raise ValueError(f"Upload failed: {error_msg}")

            uploaded_file = raw_result["file"]
            columns = raw_result.get("columns", [])

        # Step 2: Create the run
        self._log("  Creating analysis run...")
        dashboard_client = await self._get_dashboard_client()

        report_payload: Dict[str, Any] = {
            "file": {
                "key": uploaded_file["key"],
                "name": uploaded_file["name"],
                "size": uploaded_file["size"],
                "fileHash": uploaded_file["fileHash"],
            },
            "columns": columns,
            "targetColumn": target_column,
            "depthIterations": depth_iterations,
            "isPublic": visibility == "public",
        }

        if title:
            report_payload["title"] = title
        if description:
            report_payload["description"] = description
        if author:
            report_payload["author"] = author
        if source_url:
            report_payload["sourceUrl"] = source_url
        if column_descriptions:
            for col in report_payload["columns"]:
                if col["name"] in column_descriptions:
                    col["description"] = column_descriptions[col["name"]]
        if excluded_columns:
            for col in report_payload["columns"]:
                if col["name"] in excluded_columns and col["name"] != target_column:
                    col["enabled"] = False
        if timeseries_groups:
            report_payload["columnGroups"] = timeseries_groups
        response = await dashboard_client.post(
            "/api/reports/create-from-upload",
            json=report_payload,
        )

        if response.status_code >= 400:
            try:
                error_data = response.json()
                error_message = error_data.get("error", response.text)
            except Exception:
                error_message = response.text

            if "insufficient credits" in error_message.lower():
                raise InsufficientCreditsError(message=f"API error: {error_message}")

            raise ValueError(f"API error ({response.status_code}): {error_message}")

        result_data = response.json()

        # Handle duplicates
        if result_data.get("duplicate"):
            report_id = result_data.get("report_id")
            run_id = result_data.get("run_id")
            if not report_id or not run_id:
                raise ValueError("Duplicate report found but missing report_id or run_id")

            self._log(f"Duplicate report found (run_id: {run_id})")
            progress_url = f"{self.dashboard_url}/reports/new/{run_id}/processing"
            self._log(f"View progress: {progress_url}")

            if wait:
                return await self.get_results(run_id)
            return EngineResult(run_id=run_id, status="completed", report_id=report_id)

        run_id = result_data["run_id"]
        self._log(f"Run created: {run_id}")

        progress_url = f"{self.dashboard_url}/reports/new/{run_id}/processing"
        self._log(f"View progress: {progress_url}")

        if wait:
            return await self.wait_for_completion(run_id, timeout=wait_timeout)

        return EngineResult(run_id=run_id, status="pending")

    def run(
        self,
        file: Union[str, Path, "pd.DataFrame"],
        target_column: str,
        depth_iterations: int = 1,
        title: Optional[str] = None,
        description: Optional[str] = None,
        column_descriptions: Optional[Dict[str, str]] = None,
        excluded_columns: Optional[List[str]] = None,
        task: Optional[str] = None,
        visibility: str = "public",
        timeseries_groups: Optional[List[Dict[str, Any]]] = None,
        target_column_override: Optional[str] = None,
        auto_report_use_llm_evals: bool = True,
        author: Optional[str] = None,
        source_url: Optional[str] = None,
        wait: bool = False,
        wait_timeout: Optional[float] = None,
        **kwargs,
    ) -> EngineResult:
        """Run analysis on a dataset (synchronous wrapper around run_async)."""
        return self._run_sync(
            self.run_async(
                file,
                target_column,
                depth_iterations,
                title=title,
                description=description,
                column_descriptions=column_descriptions,
                excluded_columns=excluded_columns,
                task=task,
                visibility=visibility,
                timeseries_groups=timeseries_groups,
                target_column_override=target_column_override,
                auto_report_use_llm_evals=auto_report_use_llm_evals,
                author=author,
                source_url=source_url,
                wait=wait,
                wait_timeout=wait_timeout,
                **kwargs,
            )
        )

    # ------------------------------------------------------------------
    # Sync helper
    # ------------------------------------------------------------------

    @staticmethod
    def _run_sync(coro):
        """Run a coroutine synchronously, handling Jupyter event loops."""
        try:
            return asyncio.run(coro)
        except RuntimeError as e:
            if "cannot be called from a running event loop" in str(e).lower():
                try:
                    import nest_asyncio

                    nest_asyncio.apply()
                    return asyncio.run(coro)
                except ImportError:
                    raise RuntimeError(
                        "Cannot run synchronously in a Jupyter notebook. "
                        "Use 'await engine.discover(...)' instead, or install "
                        "nest_asyncio (pip install nest-asyncio)."
                    ) from e
            raise

    # ------------------------------------------------------------------
    # Result parsing
    # ------------------------------------------------------------------

    def _parse_analysis_result(self, data: Dict[str, Any]) -> EngineResult:
        """Parse API response into EngineResult dataclass."""
        summary = None
        if data.get("summary"):
            summary = self._parse_summary(data["summary"])

        patterns = []
        for p in data.get("patterns", []):
            patterns.append(
                Pattern(
                    id=p["id"],
                    task=p.get("task", "regression"),
                    target_column=p.get("target_column", ""),
                    target_change_direction=p.get("target_change_direction", "max"),
                    p_value=p.get("p_value", 0),
                    conditions=p.get("conditions", []),
                    abs_target_change=p.get("abs_target_change", 0),
                    support_count=p.get("support_count", 0),
                    support_percentage=p.get("support_percentage", 0),
                    novelty_type=p.get("novelty_type", "confirmatory"),
                    target_score=p.get("target_score", 0),
                    target_class=p.get("target_class"),
                    target_mean=p.get("target_mean"),
                    target_std=p.get("target_std"),
                    description=p.get("description", ""),
                    novelty_explanation=p.get("novelty_explanation", ""),
                    citations=p.get("citations", []),
                    p_value_raw=p.get("p_value_raw"),
                )
            )

        columns = []
        for c in data.get("columns", []):
            columns.append(
                Column(
                    id=c["id"],
                    name=c["name"],
                    display_name=c.get("display_name", c["name"]),
                    type=c.get("type", "continuous"),
                    data_type=c.get("data_type", "float"),
                    enabled=c.get("enabled", True),
                    description=c.get("description"),
                    mean=c.get("mean"),
                    median=c.get("median"),
                    std=c.get("std"),
                    min=c.get("min"),
                    max=c.get("max"),
                    iqr_min=c.get("iqr_min"),
                    iqr_max=c.get("iqr_max"),
                    mode=c.get("mode"),
                    approx_unique=c.get("approx_unique"),
                    null_percentage=c.get("null_percentage"),
                    feature_importance_score=c.get("feature_importance_score"),
                )
            )

        correlation_matrix = []
        for entry in data.get("correlation_matrix", []):
            correlation_matrix.append(
                CorrelationEntry(
                    feature_x=entry["feature_x"],
                    feature_y=entry["feature_y"],
                    value=entry["value"],
                )
            )

        feature_importance = None
        if data.get("feature_importance"):
            fi = data["feature_importance"]
            scores = [
                FeatureImportanceScore(feature=s["feature"], score=s["score"])
                for s in fi.get("scores", [])
            ]
            feature_importance = FeatureImportance(
                kind=fi.get("kind", "global"),
                baseline=fi.get("baseline", 0),
                scores=scores,
            )

        # Build report URL if we have a report_id
        report_url = data.get("report_url")
        if not report_url and data.get("report_id"):
            report_url = f"{self.dashboard_url}/reports/{data['report_id']}"

        return EngineResult(
            run_id=data["run_id"],
            report_id=data.get("report_id"),
            status=data.get("status", "unknown"),
            dataset_title=data.get("dataset_title"),
            dataset_description=data.get("dataset_description"),
            total_rows=data.get("total_rows"),
            target_column=data.get("target_column"),
            task=data.get("task"),
            summary=summary,
            patterns=patterns,
            columns=columns,
            correlation_matrix=correlation_matrix,
            feature_importance=feature_importance,
            job_id=data.get("job_id"),
            job_status=data.get("job_status"),
            error_message=data.get("error_message"),
            report_url=report_url,
        )

    def _parse_summary(self, data: Dict[str, Any]) -> Summary:
        """Parse summary data into Summary dataclass."""
        return Summary(
            overview=data.get("overview", ""),
            key_insights=data.get("key_insights", []),
            novel_patterns=PatternGroup(
                pattern_ids=data.get("novel_patterns", {}).get("pattern_ids", []),
                explanation=data.get("novel_patterns", {}).get("explanation", ""),
            ),
            selected_pattern_id=data.get("selected_pattern_id"),
        )
