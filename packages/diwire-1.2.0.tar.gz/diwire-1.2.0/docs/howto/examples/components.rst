:orphan:

Components (deprecated)
=======================

This page has been replaced by :doc:`named-components` and :doc:`open-generics`.
