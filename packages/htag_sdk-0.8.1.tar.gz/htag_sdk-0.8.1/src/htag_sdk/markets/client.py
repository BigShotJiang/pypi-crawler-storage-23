"""Synchronous client for the Markets API domain."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional, TypeVar, Union

from pydantic import BaseModel

from htag_sdk.markets.models import (
    AdvancedSearchBody,
    BaseResponse,
    DemandProfileOut,
    EssentialsOut,
    FSDMonthlyOut,
    FSDQuarterlyOut,
    FSDYearlyOut,
    GRCOut,
    MarketSnapshot,
    PriceHistoryOut,
    RentHistoryOut,
    YieldHistoryOut,
)

if TYPE_CHECKING:
    from htag_sdk._base import SyncRequestMixin


class _TrendsClient:
    """Synchronous sub-client for ``/markets/trends/*`` endpoints.

    Accessed via ``client.markets.trends``.
    """

    _client: "SyncRequestMixin"

    def __init__(self, client: "SyncRequestMixin") -> None:
        self._client = client

    # -- helpers -------------------------------------------------------------

    def _trend_params(
        self,
        level: str,
        area_id: List[str],
        *,
        property_type: Optional[List[str]] = None,
        period_end_min: Optional[str] = None,
        period_end_max: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "level": level,
            "area_id": area_id,
            "limit": limit,
            "offset": offset,
        }
        if property_type is not None:
            params["property_type"] = property_type
        if period_end_min is not None:
            params["period_end_min"] = period_end_min
        if period_end_max is not None:
            params["period_end_max"] = period_end_max
        return params

    def _trend_params_with_bedrooms(
        self,
        level: str,
        area_id: List[str],
        *,
        property_type: Optional[List[str]] = None,
        period_end_min: Optional[str] = None,
        period_end_max: Optional[str] = None,
        bedrooms: Optional[Union[str, List[str]]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Dict[str, Any]:
        params = self._trend_params(
            level, area_id,
            property_type=property_type,
            period_end_min=period_end_min,
            period_end_max=period_end_max,
            limit=limit,
            offset=offset,
        )
        if bedrooms is not None:
            params["bedrooms"] = bedrooms if isinstance(bedrooms, list) else [bedrooms]
        return params

    # -- endpoints -----------------------------------------------------------

    def price(
        self,
        level: str,
        area_id: List[str],
        *,
        property_type: Optional[List[str]] = None,
        period_end_min: Optional[str] = None,
        period_end_max: Optional[str] = None,
        bedrooms: Optional[Union[str, List[str]]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> BaseResponse[PriceHistoryOut]:
        """Retrieve price history trends.

        Args:
            level: Geographic level (``"suburb"`` or ``"lga"``).
            area_id: List of area identifiers.
            property_type: Filter by property types.
            period_end_min: Earliest period end date (ISO 8601).
            period_end_max: Latest period end date (ISO 8601).
            bedrooms: Bedroom filter (single value or list).
            limit: Maximum results per page (default 100).
            offset: Pagination offset.

        Returns:
            Paginated :class:`BaseResponse` of :class:`PriceHistoryOut` records.
        """
        params = self._trend_params_with_bedrooms(
            level, area_id,
            property_type=property_type,
            period_end_min=period_end_min,
            period_end_max=period_end_max,
            bedrooms=bedrooms,
            limit=limit,
            offset=offset,
        )
        data = self._client._request(
            "GET", "/markets/trends/price",
            params=params, base_url=self._client._internal_base_url,
        )
        return _parse_base_response(data, PriceHistoryOut)

    def rent(
        self,
        level: str,
        area_id: List[str],
        *,
        property_type: Optional[List[str]] = None,
        period_end_min: Optional[str] = None,
        period_end_max: Optional[str] = None,
        bedrooms: Optional[Union[str, List[str]]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> BaseResponse[RentHistoryOut]:
        """Retrieve rent history trends.

        Args:
            level: Geographic level (``"suburb"`` or ``"lga"``).
            area_id: List of area identifiers.
            property_type: Filter by property types.
            period_end_min: Earliest period end date (ISO 8601).
            period_end_max: Latest period end date (ISO 8601).
            bedrooms: Bedroom filter (single value or list).
            limit: Maximum results per page (default 100).
            offset: Pagination offset.

        Returns:
            Paginated :class:`BaseResponse` of :class:`RentHistoryOut` records.
        """
        params = self._trend_params_with_bedrooms(
            level, area_id,
            property_type=property_type,
            period_end_min=period_end_min,
            period_end_max=period_end_max,
            bedrooms=bedrooms,
            limit=limit,
            offset=offset,
        )
        data = self._client._request(
            "GET", "/markets/trends/rent",
            params=params,
        )
        return _parse_base_response(data, RentHistoryOut)

    def yield_history(
        self,
        level: str,
        area_id: List[str],
        *,
        property_type: Optional[List[str]] = None,
        period_end_min: Optional[str] = None,
        period_end_max: Optional[str] = None,
        bedrooms: Optional[Union[str, List[str]]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> BaseResponse[YieldHistoryOut]:
        """Retrieve yield history trends.

        Args:
            level: Geographic level (``"suburb"`` or ``"lga"``).
            area_id: List of area identifiers.
            property_type: Filter by property types.
            period_end_min: Earliest period end date (ISO 8601).
            period_end_max: Latest period end date (ISO 8601).
            bedrooms: Bedroom filter (single value or list).
            limit: Maximum results per page (default 100).
            offset: Pagination offset.

        Returns:
            Paginated :class:`BaseResponse` of :class:`YieldHistoryOut` records.
        """
        params = self._trend_params_with_bedrooms(
            level, area_id,
            property_type=property_type,
            period_end_min=period_end_min,
            period_end_max=period_end_max,
            bedrooms=bedrooms,
            limit=limit,
            offset=offset,
        )
        data = self._client._request(
            "GET", "/markets/trends/yield",
            params=params,
        )
        return _parse_base_response(data, YieldHistoryOut)

    def supply_demand(
        self,
        level: str,
        area_id: List[str],
        *,
        property_type: Optional[List[str]] = None,
        period_end_min: Optional[str] = None,
        period_end_max: Optional[str] = None,
        bedrooms: Optional[Union[str, List[str]]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> BaseResponse[FSDMonthlyOut]:
        """Retrieve supply and demand trends (monthly frequency).

        Args:
            level: Geographic level (``"suburb"`` or ``"lga"``).
            area_id: List of area identifiers.
            property_type: Filter by property types.
            period_end_min: Earliest period end date (ISO 8601).
            period_end_max: Latest period end date (ISO 8601).
            bedrooms: Bedroom filter (single value or list).
            limit: Maximum results per page (default 100).
            offset: Pagination offset.

        Returns:
            Paginated :class:`BaseResponse` of :class:`FSDMonthlyOut` records.
        """
        params = self._trend_params_with_bedrooms(
            level, area_id,
            property_type=property_type,
            period_end_min=period_end_min,
            period_end_max=period_end_max,
            bedrooms=bedrooms,
            limit=limit,
            offset=offset,
        )
        data = self._client._request(
            "GET", "/markets/trends/supply_demand",
            params=params, base_url=self._client._internal_base_url,
        )
        return _parse_base_response(data, FSDMonthlyOut)

    def search_index(
        self,
        level: str,
        area_id: List[str],
        *,
        property_type: Optional[List[str]] = None,
        period_end_min: Optional[str] = None,
        period_end_max: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> BaseResponse[FSDQuarterlyOut]:
        """Retrieve search index trends (quarterly frequency).

        Args:
            level: Geographic level (``"suburb"`` or ``"lga"``).
            area_id: List of area identifiers.
            property_type: Filter by property types.
            period_end_min: Earliest period end date (ISO 8601).
            period_end_max: Latest period end date (ISO 8601).
            limit: Maximum results per page (default 100).
            offset: Pagination offset.

        Returns:
            Paginated :class:`BaseResponse` of :class:`FSDQuarterlyOut` records.
        """
        params = self._trend_params(
            level, area_id,
            property_type=property_type,
            period_end_min=period_end_min,
            period_end_max=period_end_max,
            limit=limit,
            offset=offset,
        )
        data = self._client._request(
            "GET", "/markets/trends/search_index",
            params=params, base_url=self._client._internal_base_url,
        )
        return _parse_base_response(data, FSDQuarterlyOut)

    def hold_period(
        self,
        level: str,
        area_id: List[str],
        *,
        property_type: Optional[List[str]] = None,
        period_end_min: Optional[str] = None,
        period_end_max: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> BaseResponse[FSDYearlyOut]:
        """Retrieve hold period trends (yearly frequency).

        Args:
            level: Geographic level (``"suburb"`` or ``"lga"``).
            area_id: List of area identifiers.
            property_type: Filter by property types.
            period_end_min: Earliest period end date (ISO 8601).
            period_end_max: Latest period end date (ISO 8601).
            limit: Maximum results per page (default 100).
            offset: Pagination offset.

        Returns:
            Paginated :class:`BaseResponse` of :class:`FSDYearlyOut` records.
        """
        params = self._trend_params(
            level, area_id,
            property_type=property_type,
            period_end_min=period_end_min,
            period_end_max=period_end_max,
            limit=limit,
            offset=offset,
        )
        data = self._client._request(
            "GET", "/markets/trends/hold_period",
            params=params, base_url=self._client._internal_base_url,
        )
        return _parse_base_response(data, FSDYearlyOut)

    def performance(
        self,
        level: str,
        area_id: List[str],
        *,
        property_type: Optional[List[str]] = None,
        period_end_min: Optional[str] = None,
        period_end_max: Optional[str] = None,
        bedrooms: Optional[Union[str, List[str]]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> BaseResponse[EssentialsOut]:
        """Retrieve performance essentials trends.

        Args:
            level: Geographic level (``"suburb"`` or ``"lga"``).
            area_id: List of area identifiers.
            property_type: Filter by property types.
            period_end_min: Earliest period end date (ISO 8601).
            period_end_max: Latest period end date (ISO 8601).
            bedrooms: Bedroom filter (single value or list).
            limit: Maximum results per page (default 100).
            offset: Pagination offset.

        Returns:
            Paginated :class:`BaseResponse` of :class:`EssentialsOut` records.
        """
        params = self._trend_params_with_bedrooms(
            level, area_id,
            property_type=property_type,
            period_end_min=period_end_min,
            period_end_max=period_end_max,
            bedrooms=bedrooms,
            limit=limit,
            offset=offset,
        )
        data = self._client._request(
            "GET", "/markets/trends/performance",
            params=params, base_url=self._client._internal_base_url,
        )
        return _parse_base_response(data, EssentialsOut)

    def growth_rates(
        self,
        level: str,
        area_id: List[str],
        *,
        property_type: Optional[List[str]] = None,
        period_end_min: Optional[str] = None,
        period_end_max: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> BaseResponse[GRCOut]:
        """Retrieve growth rate cycle trends.

        Args:
            level: Geographic level (``"suburb"`` or ``"lga"``).
            area_id: List of area identifiers.
            property_type: Filter by property types.
            period_end_min: Earliest period end date (ISO 8601).
            period_end_max: Latest period end date (ISO 8601).
            limit: Maximum results per page (default 100).
            offset: Pagination offset.

        Returns:
            Paginated :class:`BaseResponse` of :class:`GRCOut` records.
        """
        params = self._trend_params(
            level, area_id,
            property_type=property_type,
            period_end_min=period_end_min,
            period_end_max=period_end_max,
            limit=limit,
            offset=offset,
        )
        data = self._client._request(
            "GET", "/markets/trends/growth-rates",
            params=params,
        )
        return _parse_base_response(data, GRCOut)

    def demand_profile(
        self,
        level: str,
        area_id: List[str],
        *,
        property_type: Optional[List[str]] = None,
        period_end_min: Optional[str] = None,
        period_end_max: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> BaseResponse[DemandProfileOut]:
        """Retrieve demand profile trends.

        Args:
            level: Geographic level (``"suburb"`` or ``"lga"``).
            area_id: List of area identifiers.
            property_type: Filter by property types.
            period_end_min: Earliest period end date (ISO 8601).
            period_end_max: Latest period end date (ISO 8601).
            limit: Maximum results per page (default 100).
            offset: Pagination offset.

        Returns:
            Paginated :class:`BaseResponse` of :class:`DemandProfileOut` records.
        """
        params = self._trend_params(
            level, area_id,
            property_type=property_type,
            period_end_min=period_end_min,
            period_end_max=period_end_max,
            limit=limit,
            offset=offset,
        )
        data = self._client._request(
            "GET", "/markets/trends/demand-profile",
            params=params,
        )
        return _parse_base_response(data, DemandProfileOut)


class MarketsClient:
    """Synchronous client for market snapshots, queries, and trend data.

    This class is not instantiated directly. Access it via ``client.markets``.
    """

    _client: "SyncRequestMixin"
    trends: _TrendsClient

    def __init__(self, client: "SyncRequestMixin") -> None:
        self._client = client
        self.trends = _TrendsClient(client)

    def snapshots(
        self,
        level: str,
        property_type: List[str],
        *,
        area_id: Optional[List[str]] = None,
        typical_price_min: Optional[int] = None,
        typical_price_max: Optional[int] = None,
        confidence: Optional[str] = None,
        bedrooms: Optional[Union[str, List[str]]] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> BaseResponse[MarketSnapshot]:
        """Retrieve market snapshots for geographic areas.

        Args:
            level: Geographic level (``"suburb"`` or ``"lga"``).
            property_type: List of property types to include.
            area_id: Filter to specific area identifiers.
            typical_price_min: Minimum typical price filter.
            typical_price_max: Maximum typical price filter.
            confidence: Confidence level filter.
            bedrooms: Bedroom filter (single value or list).
            limit: Maximum results per page (default 100).
            offset: Pagination offset.

        Returns:
            Paginated :class:`BaseResponse` of :class:`MarketSnapshot` records.
        """
        params: Dict[str, Any] = {
            "level": level,
            "property_type": property_type,
            "limit": limit,
            "offset": offset,
        }
        if area_id is not None:
            params["area_id"] = area_id
        if typical_price_min is not None:
            params["typical_price_min"] = typical_price_min
        if typical_price_max is not None:
            params["typical_price_max"] = typical_price_max
        if confidence is not None:
            params["confidence"] = confidence
        if bedrooms is not None:
            params["bedrooms"] = bedrooms if isinstance(bedrooms, list) else [bedrooms]

        data = self._client._request(
            "GET", "/markets/snapshots",
            params=params, base_url=self._client._internal_base_url,
        )
        return _parse_base_response(data, MarketSnapshot)

    def query(
        self,
        body: Union[AdvancedSearchBody, Dict[str, Any]],
    ) -> BaseResponse[MarketSnapshot]:
        """Run an advanced market query.

        Args:
            body: The search query as an :class:`AdvancedSearchBody` instance
                or a plain dictionary matching the same schema.

        Returns:
            Paginated :class:`BaseResponse` of :class:`MarketSnapshot` records.
        """
        if isinstance(body, AdvancedSearchBody):
            json_body = body.model_dump(exclude_none=True)
        else:
            json_body = body

        data = self._client._request(
            "POST", "/markets/query",
            json=json_body, base_url=self._client._internal_base_url,
        )
        return _parse_base_response(data, MarketSnapshot)


# ---------------------------------------------------------------------------
# Helper to parse BaseResponse with typed results
# ---------------------------------------------------------------------------

_T = TypeVar("_T", bound=BaseModel)


def _parse_base_response(data: Dict[str, Any], model_cls: type) -> BaseResponse:  # type: ignore[type-arg]
    """Parse a raw API dict into a typed BaseResponse.

    The ``results`` list entries are validated against ``model_cls``.
    """
    results = [model_cls.model_validate(item) for item in data.get("results", [])]
    return BaseResponse(
        total=data.get("total", 0),
        limit=data.get("limit", 0),
        offset=data.get("offset", 0),
        results=results,
    )
