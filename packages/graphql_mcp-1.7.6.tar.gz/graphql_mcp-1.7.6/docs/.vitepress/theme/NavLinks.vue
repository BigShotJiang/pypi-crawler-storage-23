<template>
  <div class="nav-links">
    <a href="https://github.com/parob/graphql-mcp" class="nav-link-btn" target="_blank">GitHub</a>
    <a href="https://pypi.org/project/graphql-mcp/" class="nav-link-btn nav-link-btn-primary" target="_blank">PyPI</a>
  </div>
</template>
