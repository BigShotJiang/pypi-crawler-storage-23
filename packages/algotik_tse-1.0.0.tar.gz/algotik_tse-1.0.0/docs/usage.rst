=====
Usage
=====

To use algotik-tse in a project::

    import algotik_tse
