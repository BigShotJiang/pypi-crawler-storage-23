import uuid
from .constants import  NAMESPACE

import  json

from dioritorm.core.Fields.string import String
from dioritorm.core.Fields.text import Text
from dioritorm.core.Database.databasemanager import DatabaseManger
import hashlib
from dioritorm.core.Fields.boolean import Boolean
from dioritorm.core.Fields.number import Number
from dioritorm.core.Fields.datetime import DateTime


#from abc import ABC,abstractmethod

class Base:

    def __init__(self):
        self._objectName = String()
        self._objectName.len = 50
        self._objectName.value = self.__class__.__name__
        if not self._objectName:
            raise ValueError("setObjectName must set a valid object name!")
        self._objectUUID = String()
        self._objectUUID.len = 36
        self._objectUUID.value = str(uuid.uuid5(NAMESPACE, self._objectName.value))
        self.isIndexed = True
        self.isUnique = False

        #logging.info(f"Object created: {self._objectName}, UUID: {self._objectUUID}")

    def __del__(self):
       pass

    def buildSchema(self):
        pass

    def beforeCreate(self):
        pass

    def onCreate(self):
        pass

    def afterCreate(self):
        pass

    def create(self):
        from dioritorm.core.event import Event
        self.buildSchema()
        self.beforeCreate()
        self.onCreate()
        self.afterCreate()
        event = Event()
        event.create()
        pass

    def beforeSave(self):
        pass

    def onSave(self,connection = None):

        if connection is None:
            connection = DatabaseManger()
            connection.save(self.toDict())
        else:
            connection.save(self.toDict(),connection)#Це треба звести в одну функцыю


    def afterSave(self):
        pass

    def beforeDelete(self):
        pass

    def onDelete(self, connection=None, filter=None):
        if filter is None:
            raise ValueError("Delete requires a Filter.")

        if connection is None:
            connection = DatabaseManger()
            connection.delete(self, filter)
        else:
            connection.delete(self, filter)

    def afterDelete(self):
        pass

    def _build_unique_filter(self):
        from dioritorm.core.data_field import DataField
        from dioritorm.core.entity import Entity
        from dioritorm.core.Database.Filter import Filter, FilterOperator

        unique_fields = set()
        try:
            schema = self.getSchema()
            for field_name, definition in schema.get("Fields", {}).items():
                if isinstance(definition, dict) and definition.get("isUnique"):
                    unique_fields.add(field_name)
        except Exception:
            pass

        for attr, value in self.__dict__.items():
            if attr in ["_objectName", "_objectUUID", "UUID"]:
                continue
            if getattr(value, "isUnique", False):
                unique_fields.add(attr)

        if not unique_fields:
            return None

        filter = Filter()
        first = True
        for field_name in sorted(unique_fields):
            if not hasattr(self, field_name):
                continue
            value = getattr(self, field_name)
            if isinstance(value, DataField):
                resolved = value.value
            elif isinstance(value, Entity):
                resolved = value.uuid.value
            elif hasattr(value, "uuid"):
                resolved = getattr(value.uuid, "value", value.uuid)
            elif hasattr(value, "value"):
                resolved = value.value
            else:
                resolved = value

            if resolved is None:
                continue

            if not first:
                filter.and_logic()
            filter.add(field_name, FilterOperator.EQUALS, resolved)
            first = False

        if not filter.conditions:
            return None
        return filter


    @property
    def objectUUID(self):
        return self._objectUUID

    @property
    def objectName(self):
        return self._objectName

    def toDict(self):
        from dioritorm.core.table_section import TableSection
        from dioritorm.core.data_field import DataField
        from dioritorm.core.entity import Entity

        result = {}
        table_sections = {}

        for attr, value in self.__dict__.items():
            if callable(value):  # 🛑 Пропустити методи
                continue
            if isinstance(value, DataField):
                if isinstance(value, DateTime) and value.value:
                    from datetime import datetime
                    if isinstance(value.value, datetime):
                        # Конвертуємо datetime в рядок у потрібному форматі
                        result[attr] = value.value.strftime("%Y-%m-%d %H:%M:%S")
                    else:
                        result[attr] = value.value
                else:
                    result[attr] = value.value


            elif isinstance(value, Entity):
                result[attr] = value.uuid.value
            elif isinstance(value, TableSection):
                rows_list = []
                for row in value.rows:
                    row_data = {}
                    for col_name, col_value in row.data.items():
                        if isinstance(col_value, DataField):
                            row_data[col_name] = col_value.value
                        elif isinstance(col_value, Entity):
                            row_data[col_name] = col_value.uuid.value
                        else:
                            row_data[col_name] = col_value
                    rows_list.append(row_data)
                #table_name = value._objectName.value.lower()
                table_name = value.name
                table_sections[table_name] = rows_list
            elif isinstance(value, list):
                continue
            else:
                result[attr] = value

        if table_sections:
            result["TableSections"] = table_sections

        return result

    """    def toDict(self):
        result = {}
        for attr, value in self.__dict__.items():
            from app.core.table_section import TableSection
            if isinstance(value, DataField):
                print("DataField",value.value)
                result[attr] = value.value
            elif isinstance(value, Base):
                print("Base", attr ,value._uuid.value)
                result[attr] = value._uuid.value

            else:
                result[attr] = value
        return result"""

    def toJson(self):
        return json.dumps(self.toDict())

    @staticmethod
    def _map_type(value):
        from dioritorm.core.entity import Entity
        if isinstance(value, Text):  # Якщо це Field
            return {
                "type": "LONGTEXT",
                "isIndexed": getattr(value, "isIndexed", False),
                "isUnique": getattr(value, "isUnique", False)
            }
        if isinstance(value, String):  # Якщо це Field
            return {
                "type": "VARCHAR",
                "len": value.len,
                "isIndexed": getattr(value, "isIndexed", False),
                "isUnique": getattr(value, "isUnique", False)
            }
        elif isinstance(value, Boolean):  # Якщо це Field
            return {
                "type": "tinyint(1)",
                "isIndexed": getattr(value, "isIndexed", False),
                "isUnique": getattr(value, "isUnique", False)
            }
        elif isinstance(value, Number):  # Якщо це Field
            return {
                "type": "DOUBLE", 
                "isIndexed": getattr(value, "isIndexed", False),
                "isUnique": getattr(value, "isUnique", False)
            }
        elif isinstance(value, DateTime):  # Якщо це Field
            return {
                "type": "DATETIME", 
                "isIndexed": getattr(value, "isIndexed", False),
                "isUnique": getattr(value, "isUnique", False)
            }
        elif isinstance(value, Entity):  # Якщо це Entity (Foreign Key)
            return {
                "type": "VARCHAR",
                "len": 36,
                "isIndexed": getattr(value, "isIndexed", False),
                "isUnique": getattr(value, "isUnique", False)
            }
        else:
            return "BLOB"  # Заглушка для складних типів

    @classmethod
    def getSignature(cls):
        schema_str = json.dumps(cls.getSchema(), sort_keys=True)
        return hashlib.sha256(schema_str.encode()).hexdigest()

    @classmethod
    def getList(cls, filter=None, order_by=None, limit=None, offset=None):
        # Створюємо екземпляр для передачі в handler
        instance = cls()
        connection = DatabaseManger()
        return connection.getList(instance, filter, order_by, limit, offset)
