﻿from dioritorm.core.Sync.apimessage import ApiMessage
from dioritorm.core.constants import NULLLINK
from dioritorm.core.entity import Entity

from dioritorm.core.Database.databasemanager import DatabaseManger
from dioritorm.core.Fields.string import String
from dioritorm.core.Fields.text import Text
from dioritorm.core.Fields.number import Number
from dioritorm.core.Fields.boolean import Boolean
from dioritorm.core.Fields.datetime import DateTime
from dioritorm.core.table_section import TableSection
from dioritorm.core.Database.Filter import Filter, FilterOperator
from dioritorm.core.Database.Query import Query, SelectField
from time import perf_counter
from dioritorm.core.registry import (
    get_sync_entity,
    get_sync_events,
    get_sync_node,
)


"""РќРµ РІРёРґР°Р»СЏС‚Рё. РїРѕС‚СЂС–Р±РЅРѕ РґР»СЏ РІРёР·РЅР°С‡РµРЅРЅСЏ РґРѕС‡С–СЂРЅСЊРѕРіРѕ РєР»Р°СЃСѓ"""
from dioritorm.core.event import Event

class SyncHandler:
    def __init__(self):
        #Р¦Рµ РґР»СЏ С‚РѕРіРѕ Р°Р±Рё РЅРµ РІРёРґР°Р»СЏР»РёСЃСЏ С–РјРїРѕСЂС‚Рё РїСЂРё СЂРµС„Р°РєС‚РѕСЂС–
        Event()
        for event_cls in get_sync_events():
            event_cls()

        self.apiMessage = ApiMessage()

    def _debug(self, *args):
        print("[SyncHandler]", *args)

    def save(self, data, connection=None):
        """Пакетное сохранение с bulk и таймингом."""
        t_total_start = perf_counter()

        obj = data.get("object")
        nodeUUID = data.get("node") or NULLLINK

        self._debug("save start", {"object": obj, "node": nodeUUID, "items": len(data.get("items", []))})

        node_cls = get_sync_node()
        if node_cls is None:
            try:
                from app.Replication.node import Node as _Node
                node_cls = get_sync_node()
            except Exception:
                node_cls = None
        if node_cls is None:
            self._debug("save failed", "Sync node class is not registered")
            self.apiMessage.result = False
            self.apiMessage.messages.append("Sync node class is not registered.")
            return self.apiMessage

        node = node_cls()
        node.getByUUID(nodeUUID)

        if not obj:
            print("Warning: missing 'object'")
            return self.apiMessage

        className = obj.lower()
        cls = Entity.registry.get(className)
        if not cls:
            from dioritorm.core.Record import Record
            cls = Record.registry.get(className)

        if not cls:
            self._debug("save failed", f"Entity '{className}' is not registered")

        items = data.get("items", [])
        dbm = DatabaseManger()
        handler = dbm._getHandler()

        batches = {}
        objects_by_class = {}

        for item in items:
            obj_instance = self.buildObject(className, item)
            if obj_instance is None:
                self._debug("save skipped", "buildObject returned None")
                continue
            batches.setdefault(className, []).append(obj_instance.toDict())
            objects_by_class.setdefault(className, []).append(obj_instance)

        t_build_end = perf_counter()

        conn = handler.connect()
        if conn is not None:
            try:
                conn.autocommit = False
            except Exception:
                pass
            try:
                conn.start_transaction()
            except Exception:
                pass

        from app.Events.sync_event import SyncEvent
        from app.Replication.node import Node
        from app.Models.InfoRecords.Replication.RouteReplication import RouteReplication

        try:
            SyncEvent.start_batch(nodes=Node.getList(), routes=RouteReplication.getList())
            handler.save_bulk(batches, handler)

            t_save_end = perf_counter()

            # Триггерим события для репликации
            for objs in objects_by_class.values():
                for obj_instance in objs:
                    event = Event()
                    event.context = obj_instance
                    event.save(node, handler)
                    obj_instance.afterSave()

            SyncEvent.flush_batch(handler)

            if conn is not None:
                conn.commit()
        except Exception as exc:
            if conn is not None:
                try:
                    conn.rollback()
                except Exception:
                    pass
            SyncEvent.cancel_batch()
            self._debug("save failed", str(exc))
            self.apiMessage.result = False
            self.apiMessage.messages.append(str(exc))
            return self.apiMessage

        total_time = perf_counter() - t_total_start
        print(f"[save] build:{t_build_end - t_total_start:.4f}s, bulk:{t_save_end - t_build_end:.4f}s, total:{total_time:.4f}s, items:{len(items)}")

        return self.apiMessage

        node = node_cls()
        node.getByUUID(nodeUUID)
        #print("node first -",nodeUUID)

        if obj is None:
            print("Warning: РєР»СЋС‡ 'object' РІС–РґСЃСѓС‚РЅС–Р№")
        else:
            pass
            #print(obj + "55")

        className = obj.lower()  # РјРѕР¶РЅР° РІРёРєРѕСЂРёСЃС‚РѕРІСѓРІР°С‚Рё РґР»СЏ РґРёРЅР°РјС–С‡РЅРѕРіРѕ СЃС‚РІРѕСЂРµРЅРЅСЏ РєР»Р°СЃСѓ
        #print("className",className)
        cls = Entity.registry.get(className)#TODO РџРµСЂРµРІС–СЂРёС‚Рё С‡Рё РЅРµ Р»РёС€РЅС”
        if not cls:
            from dioritorm.core.Record import Record
            cls = Record.registry.get(className)

        items = data.get("items", [])
        dbm = DatabaseManger()
        handler = dbm._getHandler()

        batches = {}
        objects_by_class = {}

        for item in items:
            obj_instance = self.buildObject(className, item)
            if obj_instance is None:
                continue
            batches.setdefault(className, []).append(obj_instance.toDict())
            objects_by_class.setdefault(className, []).append(obj_instance)

        handler.save_bulk(batches)
        t_save_end = perf_counter()
        for objs in objects_by_class.values():
            for obj_instance in objs:
                event = Event()
                event.context = obj_instance
                event.save(node, handler)
                obj_instance.afterSave()

        # total_time = perf_counter() - t_total_start
        # print(f"[save] build:{t_build_end - t_total_start:.4f}s, bulk:{t_save_end - t_build_end:.4f}s, total:{total_time:.4f}s, items:{len(items)}")\n\n        return self.apiMessage

    def buildObject(self, className, data):
        cls = Entity.registry.get(className)#Потрібно переробити записи регістрів на ентіті або якось тут зробити щоб визначало записи регістрів
        if not cls:
            from dioritorm.core.Record import Record
            cls = Record.registry.get(className)

        if not cls:
            self.apiMessage.result = False
            self.apiMessage.messages.append(f"�?�>���? '{className}' �?�� ���?�����?��?�?.")
            return None

        obj = cls()
        obj.create()
        print("buildObject")
        for key, value in data.items():
            attr_name = key
            field = getattr(obj, attr_name, None)

            if field is not None and isinstance(field, (String, Text)):
                field.value = value
            elif field is not None and isinstance(field, Number):
                field.value = value
            elif field is not None and isinstance(field, Boolean):
                field.value = value
            elif field is not None and isinstance(field, DateTime):
                field.value = value
            elif field is not None and isinstance(field, Entity):
                field.uuid.value = value
            elif field is not None and isinstance(field, TableSection):
                self.fillInTableSection(field, value)
            else:
                setattr(obj, attr_name, value)

        uuid_field = getattr(obj, "uuid", None)
        if uuid_field is not None and getattr(uuid_field, "value", None) == NULLLINK:
            import uuid
            uuid_field.value = str(uuid.uuid4())

        obj.beforeSave()
        # if hasattr(obj, "_ensure_uuid"):
        #     obj._ensure_uuid()
        return obj

    def clearByOwner(self,data,connection):
        pass


    def fillInTableSection(self,tableSection,data):

        dataItems = data.get("items")

        for dataItem in dataItems:
            row = tableSection.rows.add()
            for key, value in dataItem.items():


                field = getattr(row, key, None)

                if field is not None and isinstance(field, (String, Text)):
                    field.value = value
                elif field is not None and isinstance(field, Number):
                    field.value = value
                elif field is not None and isinstance(field, Boolean):
                    field.value = value
                elif field is not None and isinstance(field, DateTime):
                    #field.value = value
                    field.value = value


                elif field is not None and isinstance(field, Entity):
                    field.uuid.value = value

    def saveObject(self,className,data,connection,node = None):

        cls = Entity.registry.get(className)
        if not cls:
            from dioritorm.core.Record import Record
            cls = Record.registry.get(className)

        if not cls:
            self.apiMessage.result = False
            self.apiMessage.messages.append(f"РљР»Р°СЃ '{className}' РЅРµ Р·РЅР°Р№РґРµРЅРѕ.")
            return
            #raise ValueError(f"РљР»Р°СЃ '{className}' РЅРµ Р·РЅР°Р№РґРµРЅРѕ.")
        obj = cls()
        obj.create()
        for key, value in data.items():
            # Р¤РѕСЂРјСѓС”РјРѕ С–Рј'СЏ Р°С‚СЂРёР±СѓС‚Р°, РЅР°РїСЂРёРєР»Р°Рґ, "code" -> "_code"
            attr_name = "" + key #TODO РјРѕР¶Р»РёРІРѕ РїСЂРёР±СЂР°С‚Рё РїС–РґРєСЂРµСЃР»СЋРІР°РЅРЅСЏ
            # РћС‚СЂРёРјР°С”РјРѕ РїРѕР»Рµ, СЏРєС‰Рѕ РІРѕРЅРѕ С–СЃРЅСѓС”

            #print("attr_name",attr_name)

            field = getattr(obj, attr_name, None)

            #print("field_type", type(field))
            # РЇРєС‰Рѕ РїРѕР»Рµ С–СЃРЅСѓС” С– С” РµРєР·РµРјРїР»СЏСЂРѕРј РєР»Р°СЃСѓ String, РІСЃС‚Р°РЅРѕРІР»СЋС”РјРѕ Р№РѕРіРѕ Р·РЅР°С‡РµРЅРЅСЏ

            if (key=="childReference"):
                child = data.get("childReference")
                for childKey, childVal in child.items():
                    attr_name = childKey
                    self.save(childVal.get("data"),connection)

            if (key=="infoRecord"):
                child = data.get("infoRecord")
                for childKey, childVal in child.items():
                    attr_name = childKey
                    self.save(childVal.get("data"),connection)
                pass

            if field is not None and isinstance(field, (String, Text)):
                field.value = value
            elif field is not None and isinstance(field, Number):
                field.value = value
            elif field is not None and isinstance(field, Boolean):
                field.value = value
            elif field is not None and isinstance(field, DateTime):
                # if isinstance(value, str):
                #     from datetime import datetime
                #     value = datetime.strptime(value, "%Y-%m-%d %H:%M:%S")
                # if hasattr(value, 'replace'):
                #     value = value.replace(microsecond=0)
                field.value = value

            elif field is not None and isinstance(field, Entity):
                field.uuid.value = value
            elif field is not None and isinstance(field, TableSection):
                #print("TableSection",field.name)

                self.fillInTableSection(field,value)
                    #print("child.product._uuid",child.product._uuid)

            else:
                #print(f"РџРѕРїРµСЂРµРґР¶РµРЅРЅСЏ: Р’Р»Р°СЃС‚РёРІС–СЃС‚СЊ {attr_name} РІС–РґСЃСѓС‚РЅСЏ Р°Р±Рѕ РЅРµ С” С‚РёРїСѓ String")
                pass



        obj.save(connection, node)

    def get(self, data):#Р’РёРєРѕСЂРёСЃС‚РѕРІСѓС”С‚СЊСЃСЏ РґР»СЏ РѕС‚СЂРёРјР°РЅРЅСЏ РґР°РЅРёС… СЃРёРЅС…СЂРѕРЅС–Р·Р°С†С–С—.
        cls = get_sync_entity()
        if cls is None:
            self.apiMessage.result = False
            self.apiMessage.messages.append("Sync entity class is not registered.")
            #total_time = perf_counter() - t_total_start\n        print(f"[save] build:{t_build_end - t_total_start:.4f}s, bulk:{t_save_end - t_build_end:.4f}s, total:{total_time:.4f}s, items:{len(items)}")\n\n
            return self.apiMessage

        filter = Filter()
        filter.add("node", FilterOperator.EQUALS, data.get("node"))
        filter.and_logic()
        filter.add("state", FilterOperator.EQUALS, 0)

        # РћР±СЂРѕР±Р»СЏС”РјРѕ С„С–Р»СЊС‚СЂ РїРѕ entity
        entities_filter = data.get("filter")
        if entities_filter:
            # РћС‚СЂРёРјР°С”РјРѕ СЃРїРёСЃРѕРє С–РјРµРЅ С‚Р°Р±Р»РёС†СЊ Р· С„С–Р»СЊС‚СЂСѓ
            entity_names = [f.get("entity") for f in entities_filter if f.get("entity")]

            # Р”РѕРґР°С”РјРѕ СѓРјРѕРІСѓ РґРѕ С„С–Р»СЊС‚СЂСѓ, СЏРєС‰Рѕ С” entity
            if entity_names:
                #print("entity_names", entity_names)

                filter.and_logic()
                filter.add("tableName", FilterOperator.IN, entity_names)


        sync_entities = cls.getList(filter,None,data.get("limit"))

        result = []

        for item in sync_entities:
            className = item.tableName.value

            #print(item.node.uuid.value)
            cls = Entity.registry.get(className.lower())  # Р’РёРєРѕСЂРёСЃС‚РѕРІСѓС”РјРѕ РЅРёР¶РЅС–Р№ СЂРµРіС–СЃС‚СЂ
            if not cls:
                self.apiMessage.result = False
                self.apiMessage.messages.append(f"РљР»Р°СЃ '{className}' РЅРµ Р·РЅР°Р№РґРµРЅРѕ.")
                # total_time = perf_counter() - t_total_start
                # print(f"[save] build:{t_build_end - t_total_start:.4f}s, bulk:{t_save_end - t_build_end:.4f}s, total:{total_time:.4f}s, items:{len(items)}")\n\n
                return self.apiMessage
                #raise ValueError(
                #    f"РљР»Р°СЃ '{className}' РЅРµ Р·РЅР°Р№РґРµРЅРѕ.")  # TODO Р— СѓРёРј РїРѕС‚СЂС–Р±РЅРѕ Р±СѓРґРµ РїРѕРґСѓРјР°С‚Рё. РЇРєР° РїРѕРІРµРґС–РЅРєР° РїСЂРё РІС–РґСЃСѓС‚РЅРѕСЃС‚С– РєР»Р°СЃСѓ
            obj = cls()
            obj.create()

            #print(item.entityUUID.uuid.value)

            obj.getByUUID(item.entityUUID.uuid.value)
            #obj.uuid.value = "111"
            # Р”РѕРґР°С”РјРѕ РѕС‚СЂРёРјР°РЅРёР№ РѕР±'С”РєС‚ РґРѕ СЃРїРёСЃРєСѓ СЂРµР·СѓР»СЊС‚Р°С‚С–РІ
            result.append(obj.toDict())


        return result

    def getPendingByNode(self, data):
        apiMessage = ApiMessage()
        t_start = perf_counter()

        sync_cls = get_sync_entity()
        if sync_cls is None:
            apiMessage.result = False
            apiMessage.messages.append("Sync entity class is not registered.")
            return apiMessage

        node_uuid = data.get("node")
        if not node_uuid:
            apiMessage.result = False
            apiMessage.messages.append("Node uuid is required.")
            return apiMessage

        from app.Replication.node import Node
        from app.Events.sync_event import SyncEvent
        filter_node = None
        try:
            node_filter = Filter()
            node_filter.add("uuid", FilterOperator.EQUALS, node_uuid)
            nodes = Node.getList(node_filter, None, 1)
            if nodes:
                filter_node = nodes[0]
        except Exception:
            filter_node = None
        sync_event = SyncEvent()

        sync_filter = Filter()
        sync_filter.add("node", FilterOperator.EQUALS, node_uuid)
        sync_filter.and_logic()
        sync_filter.add("state", FilterOperator.EQUALS, 0)

        entities_filter = data.get("filter")
        if entities_filter:
            entity_names = [f.get("entity") for f in entities_filter if f.get("entity")]
            if entity_names:
                sync_filter.and_logic()
                sync_filter.add("tableName", FilterOperator.IN, entity_names)

        pending_items = sync_cls.getList(sync_filter, None, data.get("limit"))
        #print(f"[getPendingByNode] pending fetch: {len(pending_items)} rows in {perf_counter() - t_start:.4f}s")

        table_to_ids = {}
        for item in pending_items:
            tname = getattr(item.tableName, "value", None)
            euuid = getattr(getattr(item, "entityUUID", None), "uuid", None)
            euuid = getattr(euuid, "value", None)
            if not tname or not euuid:
                continue
            table_to_ids.setdefault(tname, []).append(euuid)

        if not table_to_ids:
            return []

        handler = DatabaseManger()._getHandler()
        connection = handler.connect()

        def _get_columns(table_name: str):
            cols = set()
            cur = connection.cursor()
            try:
                cur.execute(f"SHOW COLUMNS FROM {table_name}")
                for row in cur.fetchall():
                    cols.add(row[0])
            finally:
                cur.close()
            return cols

        result = []

        def build_entity_for_filter(cls, row_data):
            obj = cls()
            obj.create()
            for attr, val in obj.__dict__.items():
                if attr.startswith("_"):
                    continue
                if attr not in row_data:
                    continue
                if isinstance(val, (String, Text, Number, Boolean, DateTime)):
                    setattr(val, "value", row_data.get(attr))
                elif isinstance(val, Entity):
                    val.uuid.value = row_data.get(attr)
            if hasattr(obj, "uuid") and getattr(obj.uuid, "value", None) is None:
                obj.uuid.value = row_data.get("uuid")
            return obj

        for class_name, uuids in table_to_ids.items():
            t_type_start = perf_counter()
            cls = Entity.registry.get(class_name.lower())
            if not cls:
                from dioritorm.core.Record import Record
                cls = Record.registry.get(class_name.lower())
            if not cls:
                apiMessage.result = False
                apiMessage.messages.append(f"Entity '{class_name}' is not registered.")
                return apiMessage

            template = cls()
            template.create()
            table_name = f"{template._type}_{template._objectName.value.lower()}"

            main_fields = []
            for attr, val in template.__dict__.items():
                if attr.startswith("_"):
                    continue
                if isinstance(val, (String, Text, Number, Boolean, DateTime)):
                    main_fields.append(attr)
                elif isinstance(val, Entity):
                    main_fields.append(attr)
            table_columns = _get_columns(table_name)
            main_fields = [f for f in main_fields if f in table_columns]
            if "uuid" in table_columns and "uuid" not in main_fields:
                main_fields.append("uuid")

            select_fields = [SelectField(f"{table_name}.{fld}") for fld in main_fields]
            obj_filter = Filter()
            obj_filter.add(f"{table_name}.uuid", FilterOperator.IN, uuids)
            obj_query = Query(from_table=table_name, select=select_fields, filter=obj_filter)
            obj_sql = obj_query.to_sql()

            cursor = connection.cursor(dictionary=True)
            try:
                cursor.execute(obj_sql.sql, obj_sql.args)
                main_rows = cursor.fetchall()
            finally:
                cursor.close()

            #print(f"[getPendingByNode] {class_name}: main fetch {len(main_rows)} rows in {perf_counter() - t_type_start:.4f}s")
            if not main_rows:
                continue

            table_sections = {name: ts for name, ts in template.__dict__.items() if isinstance(ts, TableSection)}

            section_rows = {name: {} for name in table_sections}

            for section_name, ts in table_sections.items():
                ts_filter = Filter()
                ts_filter.add("owner", FilterOperator.IN, uuids)
                ts_query = Query(from_table=ts._objectName.value, filter=ts_filter)
                ts_sql = ts_query.to_sql()
                cursor = connection.cursor(dictionary=True)
                t_sections = perf_counter()
                try:
                    cursor.execute(ts_sql.sql, ts_sql.args)
                    rows = cursor.fetchall()
                finally:
                    cursor.close()
                #print(f"[getPendingByNode] {class_name}: section {section_name} fetch {len(rows)} rows in {perf_counter() - t_sections:.4f}s")

                for row in rows:
                    owner = row.get("owner")
                    if not owner:
                        continue
                    section_rows[section_name].setdefault(owner, []).append(row)

            t_build = perf_counter()
            section_names = list(table_sections.keys())
            for row in main_rows:
                payload = {}
                # службові поля зі схеми
                payload["_objectName"] = getattr(template._objectName, "value", None)
                payload["_objectUUID"] = getattr(template._objectUUID, "value", None)
                payload["isIndexed"] = getattr(template, "isIndexed", None)
                payload["isUnique"] = getattr(template, "isUnique", None)
                payload["_type"] = getattr(template, "_type", None)

                for fld in main_fields:
                    if fld == "uuid":
                        payload["uuid"] = row.get("uuid")
                    else:
                        payload[fld] = row.get(fld)

                table_sections_payload = {}
                for sec in section_names:
                    rows = section_rows.get(sec, {}).get(row.get("uuid"), [])
                    if not rows:
                        continue
                    cleaned = []
                    for r in rows:
                        cleaned.append({k: v for k, v in r.items() if k not in ("uuid", "owner", "__section")})
                    table_sections_payload[sec] = cleaned

                if table_sections_payload:
                    payload["TableSections"] = table_sections_payload

                if filter_node is None or sync_event._should_replicate(build_entity_for_filter(cls, payload), filter_node):
                    result.append(payload)

            #print(f"[getPendingByNode] {class_name}: build payload {len(main_rows)} rows in {perf_counter() - t_build:.4f}s")

        total_time = perf_counter() - t_start
        #print(f"[getPendingByNode] total time: {total_time:.4f}s, objects: {len(result)}")
        return result

    def getBuUUID(self, data):
        apiMessage = ApiMessage()

        entity_name = data.get("entity")
        entity_uuid = data.get("uuid")

        if not entity_name or not entity_uuid:
            apiMessage.result = False
            apiMessage.messages.append("Entity name and uuid are required.")
            return apiMessage

        cls = Entity.registry.get(entity_name.lower())
        if not cls:
            from dioritorm.core.Record import Record
            cls = Record.registry.get(entity_name.lower())

        if not cls:
            apiMessage.result = False
            apiMessage.messages.append(f"Entity '{entity_name}' is not registered.")
            return apiMessage

        obj = cls()
        obj.create()
        obj.getByUUID(entity_uuid)

        return self._with_entity_refs(obj)

    def getList(self, data):
        apiMessage = ApiMessage()

        entity_name = data.get("entity")
        if not entity_name:
            apiMessage.result = False
            apiMessage.messages.append("Entity name is required.")
            return apiMessage

        cls = Entity.registry.get(entity_name.lower())
        if not cls:
            from dioritorm.core.Record import Record
            cls = Record.registry.get(entity_name.lower())

        if not cls:
            apiMessage.result = False
            apiMessage.messages.append(f"Entity '{entity_name}' is not registered.")
            return apiMessage

        filters_data = data.get("filter") or data.get("filters")
        logic = (data.get("logic") or "AND").upper()

        filter_obj = None
        if filters_data:
            filter_obj = Filter()
            if logic == "OR":
                filter_obj.or_logic()
            else:
                filter_obj.and_logic()

            operator_map = {
                "==": FilterOperator.EQUALS,
                "=": FilterOperator.EQUALS,
                "eq": FilterOperator.EQUALS,
                "equals": FilterOperator.EQUALS,
                "in": FilterOperator.IN,
                "!=": FilterOperator.NOT_EQUALS,
                "<>": FilterOperator.NOT_EQUALS,
                "ne": FilterOperator.NOT_EQUALS,
                ">": FilterOperator.GREATER,
                "gt": FilterOperator.GREATER,
                "<": FilterOperator.LESS,
                "lt": FilterOperator.LESS,
                ">=": FilterOperator.GREATER_EQUALS,
                "gte": FilterOperator.GREATER_EQUALS,
                "<=": FilterOperator.LESS_EQUALS,
                "lte": FilterOperator.LESS_EQUALS,
                "contains": FilterOperator.CONTAINS,
                "like": FilterOperator.CONTAINS,
                "startswith": FilterOperator.STARTS_WITH,
                "endswith": FilterOperator.ENDS_WITH,
            }

            for condition in filters_data:
                field = condition.get("field") or condition.get("name")
                operator = condition.get("operator")
                value = condition.get("value")

                if not field:
                    continue

                if isinstance(operator, FilterOperator):
                    op_enum = operator
                else:
                    op_enum = operator_map.get(str(operator).lower()) if operator is not None else None

                if op_enum is None:
                    continue

                filter_obj.add(field, op_enum, value)

        result = []
        for item in cls.getList(filter_obj, None, data.get("limit"), data.get("offset")):
            result.append(self._with_entity_refs(item))

        return result

    def _with_entity_refs(self, obj):
        data = obj.toDict()

        for attr, value in obj.__dict__.items():
            if isinstance(value, Entity):
                ref = {"uuid": value.uuid.value}
                if hasattr(value, "code") and hasattr(value.code, "value"):
                    ref["code"] = value.code.value
                if hasattr(value, "name") and hasattr(value.name, "value"):
                    ref["name"] = value.name.value
                data[attr] = ref

        return data











