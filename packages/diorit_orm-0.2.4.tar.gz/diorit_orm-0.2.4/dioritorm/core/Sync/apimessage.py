class ApiMessage:
    def __init__(self):
        self.result = True
        self.messages = []
