import pprint

from dioritorm.core.Fields.string import String
from .base import Base
from dioritorm.core.Database.Filter import Filter, FilterOperator
from dioritorm.core.constants import NULLLINK

class Record(Base):
    registry = {}
    def __init__(self):
        super().__init__()
        self.uuid = String()
        self.uuid.len = 36

    def __init_subclass__(cls, **kwargs):
        super().__init_subclass__(**kwargs)

        # Додаємо клас у реєстр за його ім'ям
        Record.registry[cls.__name__.lower()] = cls

    def beforeSave(self):
        print("Save record")
        self._ensure_uuid()

    def save(self,connection = None, node = None):
        from dioritorm.core.event import Event
        #print("node",node.uuid.value)


        for attr in sorted(self.__dict__.keys()):
            print(attr)
            value = self.__dict__.get(attr)
            pprint.pprint(value)

        if connection is None:
            print("connection is None")

        self.beforeSave()
        self.onSave(connection)
        if node!=None:
            event = Event()
            event.context = self  # Передаємо контекст події
            event.save(node,connection)
        self.afterSave()

    def delete(self, connection=None, node=None):
        if self.uuid.value == NULLLINK:
            filter = self._build_unique_filter()
            if filter is None:
                raise ValueError("Cannot delete record without UUID or unique fields.")
        else:
            filter = Filter().add("uuid", FilterOperator.EQUALS, self.uuid.value)
        self.beforeDelete()
        self.onDelete(connection, filter)
        self.afterDelete()



    @classmethod
    def getSchema(cls):
        from dioritorm.core.entity import Entity
        fields_schema = {}

        from .data_field import DataField

        try:
            temp_instance = cls()
            if hasattr(temp_instance, "create"):
                temp_instance.create()
        except Exception as e:
            print("Не вдалося створити екземпляр класу:", e)
            return {"Entity": cls.__name__, "Fields": fields_schema}

        for attr, value in temp_instance.__dict__.items():
            if attr in ["_objectName", "_objectUUID"]:
                continue

            if isinstance(value, (DataField, Entity, cls)):
                fields_schema[attr] = cls._map_type(value)

        return {
            "Entity": temp_instance._type + "_" + cls.__name__,
            "Fields": fields_schema
        }

    def _ensure_uuid(self):
        from dioritorm.core.data_field import DataField
        from dioritorm.core.entity import Entity
        from dioritorm.core.Helpers.UUIDHelper import make_key

        def extract_unique_value(item):
            if isinstance(item, DataField):
                return item.value
            if isinstance(item, Entity):
                return item.uuid.value
            if hasattr(item, "uuid"):
                return getattr(item.uuid, "value", item.uuid)
            if hasattr(item, "value"):
                return item.value
            return item

        unique_fields = set()
        try:
            schema = self.getSchema()
            for field_name, definition in schema.get("Fields", {}).items():
                if isinstance(definition, dict) and definition.get("isUnique"):
                    unique_fields.add(field_name)
        except Exception:
            unique_fields = set()

        unique_parts = [self._objectName.value]
        for attr in sorted(self.__dict__.keys()):
            if attr in ["_objectName", "_objectUUID", "UUID"]:
                continue
            value = self.__dict__.get(attr)
            if getattr(value, "isUnique", False) or attr in unique_fields:
                unique_parts.extend([attr, extract_unique_value(value)])

        if len(unique_parts) > 1:
            self.uuid.value = str(make_key(*unique_parts))


    def restruct(self):
        from dioritorm.core.Database.databasemanager import DatabaseManger
        schema = self.getSchema()
        dm = DatabaseManger()

        # Основна таблиця
        dm.restruct({
            "Entity": schema["Entity"],
            "Fields": schema["Fields"]
        })

