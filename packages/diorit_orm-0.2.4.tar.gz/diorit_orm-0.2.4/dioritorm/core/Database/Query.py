import re
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Dict, List, Optional

from .Filter import Filter
from .OrderBy import OrderBy


_entity_table_cache: Dict[str, str] = {}

_dsl_keyword_aliases: Dict[str, str] = {
    "SEL": "SELECT",
    "FRM": "FROM",
    "WHE": "WHERE",
    "ORD": "ORDER",
    "BY": "BY",
}

_dsl_keywords = {
    "FROM",
    "SELECT",
    "WHERE",
    "ORDER",
    "LIMIT",
    "OFFSET",
    "JOIN",
    "LEFT",
    "INNER",
}


def _normalize_entity_name(name: str) -> str:
    return name.replace("\"", "").replace("`", "").strip()


def _resolve_entity_table(name: str) -> str:
    from dioritorm.core.entity import Entity  # local import to avoid circulars
    from dioritorm.core.Record import Record

    normalized = _normalize_entity_name(name)
    key = normalized.lower()

    if key in _entity_table_cache:
        return _entity_table_cache[key]

    factory = Entity.registry.get(key) or Record.registry.get(key)
    if factory:
        try:
            instance = factory()
            # Prefer the convention used by handlers: <type>_<name>
            table_prefix = getattr(instance, "_type", "")
            object_name = getattr(instance, "_objectName", None)
            name_part = (
                object_name.value.lower()
                if object_name is not None and hasattr(object_name, "value")
                else instance.__class__.__name__.lower()
            )
            table_name = f"{table_prefix}_{name_part}" if table_prefix else name_part
            _entity_table_cache[key] = table_name
            return table_name
        except Exception:
            # Fallback to raw name if factory fails
            pass

    _entity_table_cache[key] = normalized
    return normalized


class JoinType(Enum):
    INNER = "INNER"
    LEFT = "LEFT"


class SelectField:
    def __init__(self, expression: str, alias: Optional[str] = None):
        self.expression = expression
        self.alias = alias

    def to_sql(self) -> str:
        if self.alias:
            return f"{self.expression} AS {self.alias}"
        return self.expression


class JoinSpec:
    def __init__(
        self,
        *,
        type: JoinType,
        table: str,
        on: str,
        alias: Optional[str] = None,
        params: Optional[List[object]] = None,
    ):
        self.type = type
        self.table = table
        self.alias = alias
        self.on = on
        self.params = params or []

    def to_sql(self, args: List[object], named_params: Dict[str, object]) -> str:
        buffer = []
        buffer.append("LEFT JOIN" if self.type == JoinType.LEFT else "INNER JOIN")
        buffer.append(self.table)
        if self.alias:
            buffer.append(self.alias)
        buffer.append("ON")
        buffer.append(_replace_params(self.on, args, named_params))
        return " ".join(buffer)


@dataclass
class QuerySql:
    sql: str
    args: List[object]


class Query:
    def __init__(
        self,
        *,
        from_table: str,
        from_alias: Optional[str] = None,
        select: Optional[List[SelectField]] = None,
        joins: Optional[List[JoinSpec]] = None,
        filter: Optional[Filter] = None,
        raw_where: Optional[str] = None,
        order_by: Optional[OrderBy] = None,
        raw_order: Optional[str] = None,
        limit: Optional[int] = None,
        offset: Optional[int] = None,
        params: Optional[Dict[str, object]] = None,
    ):
        self.from_table = from_table
        self.from_alias = from_alias
        self.select = select or []
        self.joins = joins or []
        self.filter = filter
        self.raw_where = raw_where
        self.order_by = order_by
        self.raw_order = raw_order
        self.limit = limit
        self.offset = offset
        self.params = params or {}

    @staticmethod
    def resolve_entity_table(name: str) -> str:
        return _resolve_entity_table(name)

    def to_sql(self) -> QuerySql:
        args: List[object] = []
        select_sql = "*" if not self.select else ", ".join(s.to_sql() for s in self.select)

        parts = ["SELECT", select_sql, "FROM", self.from_table]
        table_alias = self.from_alias.strip() if self.from_alias else None
        if table_alias:
            parts.append(table_alias)

        for join in self.joins:
            parts.append(join.to_sql(args, self.params))

        where_parts: List[str] = []

        if self.raw_where and self.raw_where.strip():
            where_parts.append(_replace_params(self.raw_where, args, self.params))

        if self.filter:
            filter_sql, filter_args = self.filter.to_sql()
            if filter_sql:
                where_parts.append(filter_sql)
            if filter_args:
                args.extend(filter_args)

        if where_parts:
            parts.extend(["WHERE", " AND ".join(where_parts)])

        if self.raw_order and self.raw_order.strip():
            parts.extend(["ORDER BY", self.raw_order.strip()])
        elif self.order_by:
            order_sql = self.order_by.to_sql()
            if order_sql:
                parts.extend(["ORDER BY", order_sql])

        if self.limit is not None:
            parts.extend(["LIMIT", str(self.limit)])

        if self.offset is not None:
            parts.extend(["OFFSET", str(self.offset)])

        return QuerySql(" ".join(parts), args)

    @classmethod
    def from_dsl(
        cls,
        dsl: str,
        *,
        params: Optional[Dict[str, object]] = None,
        resolve_table: Optional[Callable[[str], str]] = None,
    ) -> "Query":
        table_resolver = resolve_table or _resolve_entity_table
        params = params or {}

        from_table: Optional[str] = None
        from_alias: Optional[str] = None
        select: List[SelectField] = []
        joins: List[JoinSpec] = []
        raw_where: Optional[str] = None
        raw_order: Optional[str] = None
        limit: Optional[int] = None
        offset: Optional[int] = None

        raw = dsl.replace("\n", " ").replace("\r", " ")
        tokens = [t for t in re.split(r"\s+", raw) if t]

        current_key: Optional[str] = None
        buffer: Dict[str, List[str]] = {}

        def push_token(token: str) -> None:
            buffer.setdefault(current_key or "", []).append(token)

        for token in tokens:
            upper = token.upper()
            canonical = _dsl_keyword_aliases.get(upper, upper)
            if canonical in _dsl_keywords:
                current_key = canonical
                buffer.setdefault(current_key, []).append(canonical)
            else:
                push_token(token)

        if "FROM" in buffer:
            line = " ".join(buffer["FROM"]).strip()
            parts = re.split(r"\s+", line)
            parts = parts[1:] if parts and parts[0].upper() == "FROM" else parts
            if parts:
                raw_table = parts[0]
                from_table = table_resolver(raw_table)
                if len(parts) > 1:
                    from_alias = parts[1]

        if from_table is None:
            match = re.search(r"\bfrom\s+([A-Za-z0-9_\.]+)(?:\s+([A-Za-z0-9_]+))?", raw, flags=re.IGNORECASE)
            if match:
                raw_table = match.group(1)
                from_table = table_resolver(raw_table)
                from_alias = match.group(2)

        if "SELECT" in buffer:
            line = " ".join(buffer["SELECT"]).strip()
            body = re.sub(r"^SELECT\s+", "", line, flags=re.IGNORECASE)
            for raw_field in body.split(","):
                part = raw_field.strip()
                if not part:
                    continue
                match = re.search(r"\s+AS\s+", part, flags=re.IGNORECASE)
                if match:
                    idx = match.start()
                    expr = part[:idx].strip()
                    alias = part[match.end():].strip()
                    select.append(SelectField(expr, alias=alias))
                else:
                    select.append(SelectField(part))

        join_buffers = [v for k, v in buffer.items() if "JOIN" in k]
        if join_buffers:
            join_line = " ".join(" ".join(v) for v in join_buffers)
            join_tokens = re.split(r"(?=JOIN )|(?=LEFT JOIN )|(?=INNER JOIN )", join_line, flags=re.IGNORECASE)
            for j in join_tokens:
                line = j.strip()
                if not line:
                    continue
                upper = line.upper()
                is_left = upper.startswith("LEFT JOIN ")
                normalized = re.sub(r"^(LEFT JOIN|INNER JOIN|JOIN)\s+", "", line, flags=re.IGNORECASE)
                on_index = normalized.upper().find(" ON ")
                if on_index == -1:
                    continue
                left_part = normalized[:on_index].strip()
                on_part = normalized[on_index + 4 :].strip()
                left_pieces = re.split(r"\s+", left_part)
                raw_table = left_pieces[0] if left_pieces else ""
                table = table_resolver(raw_table)
                alias = left_pieces[1] if len(left_pieces) > 1 else None
                joins.append(
                    JoinSpec(
                        type=JoinType.LEFT if is_left else JoinType.INNER,
                        table=table,
                        alias=alias,
                        on=on_part,
                    )
                )

        if "WHERE" in buffer:
            line = " ".join(buffer["WHERE"]).strip()
            raw_where = re.sub(r"^WHERE\s+", "", line, flags=re.IGNORECASE)

        if "ORDER" in buffer:
            line = " ".join(buffer["ORDER"]).strip()
            raw_order = (
                re.sub(r"^ORDER\s+BY\s+", "", line, flags=re.IGNORECASE)
                .replace("ORDER", "")
                .strip()
            )

        if "LIMIT" in buffer:
            parts = " ".join(buffer["LIMIT"]).strip().split()
            if parts:
                try:
                    limit = int(parts[-1])
                except ValueError:
                    limit = None

        if "OFFSET" in buffer:
            parts = " ".join(buffer["OFFSET"]).strip().split()
            if parts:
                try:
                    offset = int(parts[-1])
                except ValueError:
                    offset = None

        normalized = raw.strip()

        if select == []:
            select_match = re.search(r"\bselect\s+(.*?)\s+from", normalized, flags=re.IGNORECASE)
            if select_match:
                body = select_match.group(1) or ""
                for raw_field in body.split(","):
                    part = raw_field.strip()
                    if not part:
                        continue
                    match = re.search(r"\s+AS\s+", part, flags=re.IGNORECASE)
                    if match:
                        idx = match.start()
                        expr = part[:idx].strip()
                        alias = part[match.end():].strip()
                        select.append(SelectField(expr, alias=alias))
                    else:
                        select.append(SelectField(part))

        if from_table is None:
            from_match = re.search(
                r"\bfrom\s+([A-Za-z0-9_\.]+)(?:\s+([A-Za-z0-9_]+))?",
                normalized,
                flags=re.IGNORECASE,
            )
            if from_match:
                raw_table = from_match.group(1)
                from_table = table_resolver(raw_table)
                from_alias = from_match.group(2)

        if raw_where is None:
            where_match = re.search(
                r"\bwhere\s+(.*?)(?:\border\s+by\b|\blimit\b|\boffset\b|$)",
                normalized,
                flags=re.IGNORECASE,
            )
            if where_match:
                raw_where = where_match.group(1).strip()

        if raw_order is None:
            order_match = re.search(
                r"\border\s+by\s+(.*?)(?:\blimit\b|\boffset\b|$)",
                normalized,
                flags=re.IGNORECASE,
            )
            if order_match:
                raw_order = order_match.group(1).strip()

        if from_table is None:
            raise ValueError("FROM clause is required in DSL query")

        return cls(
            from_table=from_table,
            from_alias=from_alias,
            select=select,
            joins=joins,
            raw_where=raw_where,
            raw_order=raw_order,
            limit=limit,
            offset=offset,
            params=params,
        )


def _replace_params(source: str, args: List[object], named_params: Dict[str, object]) -> str:
    def repl(match: re.Match[str]) -> str:
        key = match.group(1)
        if key not in named_params:
            raise ValueError(f'Parameter "{key}" not provided for query')
        args.append(named_params[key])
        return "%s"

    return re.sub(r":([A-Za-z0-9_]+)", repl, source)
