from dioritorm.core.data_field import DataField


class Text(DataField):

    def __init__(self, owner=None):
        super().__init__(owner)
        self._value = ""

    @DataField.value.setter
    def value(self, val):
        if val is None:
            val = ""
        if not isinstance(val, str):
            raise ValueError("The 'value' property must be a string value.")
        DataField.value.fset(self, val)
