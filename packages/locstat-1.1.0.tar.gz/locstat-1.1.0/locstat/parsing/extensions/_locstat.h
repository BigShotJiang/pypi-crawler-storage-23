#ifndef LOCSTAT_GLOBAL_INCDEFS
#define LOCSTAT_GLOBAL_INCDEFS
#define PY_SSIZE_T_CLEAN
#include <Python.h>
#endif