"""Faker community provider for Pokemon data."""

__version__ = "0.1.0"

from faker_pokemon.provider import PokemonProvider

__all__ = ["PokemonProvider"]
