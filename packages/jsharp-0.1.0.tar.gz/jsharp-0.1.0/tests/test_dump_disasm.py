from __future__ import annotations

from pathlib import Path

from jsharp.cli import cmd_dump


def test_dump_contains_main_and_const(capsys, tmp_path: Path):
    src = tmp_path / "sample.jsh"
    src.write_text("fn main() { return 3; }", encoding="utf-8")

    code = cmd_dump(str(src))
    out = capsys.readouterr().out

    assert code == 0
    assert "Function main" in out
    assert "CONST" in out
