from __future__ import annotations

from tests.helpers import run_main


def test_while_sum_1_to_5():
    source = """
fn main() {
  let i = 1;
  let sum = 0;
  while (i <= 5) {
    sum = sum + i;
    i = i + 1;
  }
  return sum;
}
"""
    assert run_main(source) == 15


def test_short_circuit_logic_values():
    source = """
fn main() {
  if ((false || 123) == 123 && (true && 9) == 9) {
    return 1;
  }
  return 0;
}
"""
    assert run_main(source) == 1
