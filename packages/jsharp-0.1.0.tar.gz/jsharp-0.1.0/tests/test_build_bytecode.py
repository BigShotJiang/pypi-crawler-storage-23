from __future__ import annotations

from pathlib import Path

from jsharp.cli import cmd_build


def test_build_emits_jbc_file(tmp_path: Path):
    src = tmp_path / "sample.jsh"
    out = tmp_path / "sample.jbc"
    src.write_text("fn main() { return 3; }", encoding="utf-8")

    code = cmd_build(str(src), str(out))

    assert code == 0
    data = out.read_bytes()
    assert data.startswith(b"JBC1")
