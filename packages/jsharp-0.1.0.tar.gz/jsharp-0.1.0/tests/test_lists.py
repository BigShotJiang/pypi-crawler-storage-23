from __future__ import annotations

import pytest

from jsharp.errors import RuntimeJError
from tests.helpers import run_main


def test_list_literal_and_index_get():
    source = """
fn main() {
  let a = [10, 20, 30];
  return a[1];
}
"""
    assert run_main(source) == 20


def test_list_index_set():
    source = """
fn main() {
  let a = [1, 2, 3];
  a[1] = 99;
  return a[1];
}
"""
    assert run_main(source) == 99


def test_len_builtin_for_list():
    source = """
fn main() {
  let a = [1, 2, 3, 4];
  return len(a);
}
"""
    assert run_main(source) == 4


def test_list_push_pop_methods():
    source = """
fn main() {
  let a = [1];
  a.push(5);
  a.push(8);
  let x = a.pop();
  return x + len(a);
}
"""
    assert run_main(source) == 10


def test_list_index_out_of_bounds_error():
    source = """
fn main() {
  let a = [1];
  return a[2];
}
"""
    with pytest.raises(RuntimeJError) as err:
        run_main(source)
    assert "Index out of bounds" in str(err.value)
