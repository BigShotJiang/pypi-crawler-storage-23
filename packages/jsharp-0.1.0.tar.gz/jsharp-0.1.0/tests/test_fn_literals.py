from __future__ import annotations

import pytest

from jsharp.compiler import Compiler
from jsharp.errors import CompileError
from jsharp.lexer import Lexer
from jsharp.parser import Parser
from tests.helpers import run_main


def test_fn_literal_call():
    source = """
fn main() {
  let f = fn(x) { return x + 1; };
  return f(10);
}
"""
    assert run_main(source) == 11


def test_closure_capture_restriction():
    source = """
fn main() {
  let x = 10;
  let f = fn() { return x + 1; };
  return f();
}
"""
    toks = Lexer(source, filename="<test>").tokenize()
    program = Parser(toks, filename="<test>").parse_program()
    with pytest.raises(CompileError) as err:
        Compiler(filename="<test>").compile_program(program)

    assert "closures" in str(err.value).lower()
