from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path

import pytest


REPO_ROOT = Path(__file__).resolve().parents[1]
RUNTIME_DIR = REPO_ROOT / "runtime" / "jsharp_vm"


def _native_candidates() -> list[Path]:
    env = os.environ.get("JSHARP_NATIVE_BIN")
    if env:
        return [Path(env)]
    release_dir = RUNTIME_DIR / "target" / "release"
    return [release_dir / "jsh-native", release_dir / "jsh-native.exe"]


def _ensure_native_bin() -> Path | None:
    for p in _native_candidates():
        if p.exists():
            return p

    cargo = shutil.which("cargo")
    if cargo is None or not RUNTIME_DIR.exists():
        return None

    proc = subprocess.run([cargo, "build", "--release"], cwd=RUNTIME_DIR, check=False)
    if proc.returncode != 0:
        return None

    for p in _native_candidates():
        if p.exists():
            return p
    return None


def test_native_and_python_vm_stdout_match(tmp_path: Path):
    native_bin = _ensure_native_bin()
    if native_bin is None:
        pytest.skip("native VM binary not built in this environment")

    src = tmp_path / "compat.jsh"
    src.write_text(
        """
fn main() {
  let x = [1,2,3];
  print(x[0] + x[1] + x[2]);
}
""".strip()
        + "\n",
        encoding="utf-8",
    )

    py_proc = subprocess.run(
        [sys.executable, "jsh.py", "run", str(src)],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
    )

    native_proc = subprocess.run(
        [sys.executable, "jsh.py", "run", "--native", str(src)],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
        env={**os.environ, "JSHARP_NATIVE_BIN": str(native_bin)},
    )

    assert py_proc.returncode == native_proc.returncode
    assert py_proc.stdout == native_proc.stdout


def test_native_flag_falls_back_to_python_when_binary_missing(tmp_path: Path):
    src = tmp_path / "fallback_native.jsh"
    src.write_text(
        """
fn main() {
  print("fallback-ok");
}
""".strip()
        + "\n",
        encoding="utf-8",
    )

    proc = subprocess.run(
        [sys.executable, "jsh.py", "run", "--native", str(src)],
        cwd=REPO_ROOT,
        capture_output=True,
        text=True,
        check=False,
        env={**os.environ, "JSHARP_NATIVE_BIN": str(tmp_path / "missing-native-bin")},
    )

    assert proc.returncode == 0
    assert "fallback-ok" in proc.stdout
    assert "Falling back to Python VM execution" in proc.stderr
