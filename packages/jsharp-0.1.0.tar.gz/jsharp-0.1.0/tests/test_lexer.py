from __future__ import annotations

from jsharp.lexer import Lexer
from jsharp.tokens import TokenType


def types_of(src: str):
    return [t.type for t in Lexer(src, filename="<test>").tokenize()]


def test_keywords_and_identifiers():
    toks = Lexer("fn main() { let x = true; break; continue; return x; }", filename="<test>").tokenize()
    assert toks[0].type == TokenType.FN
    assert toks[1].type == TokenType.IDENT
    assert toks[5].type == TokenType.LET
    assert any(t.type == TokenType.BREAK for t in toks)
    assert any(t.type == TokenType.CONTINUE for t in toks)


def test_numbers_and_strings_and_escapes():
    toks = Lexer('let a = 123; let b = 3.14; let s = "a\\nb\\\"c\\\\";', filename="<test>").tokenize()
    nums = [t for t in toks if t.type == TokenType.NUMBER]
    strs = [t for t in toks if t.type == TokenType.STRING]
    assert nums[0].literal == 123
    assert nums[1].literal == 3.14
    assert strs[0].literal == 'a\nb"c\\'


def test_comments_ignored():
    toks = Lexer("let x = 1; // comment\nlet y = 2;", filename="<test>").tokenize()
    lexemes = [t.lexeme for t in toks if t.type != TokenType.EOF]
    assert "comment" not in " ".join(lexemes)
    assert lexemes.count("let") == 2


def test_operator_tokens():
    toks = types_of("a==b != c <= d >= e && f || g")
    assert TokenType.EQ_EQ in toks
    assert TokenType.BANG_EQ in toks
    assert TokenType.LT_EQ in toks
    assert TokenType.GT_EQ in toks
    assert TokenType.AND_AND in toks
    assert TokenType.OR_OR in toks


def test_bracket_tokens():
    toks = types_of("let a = [1, 2]; a[0] = 9;")
    assert TokenType.LBRACKET in toks
    assert TokenType.RBRACKET in toks


def test_line_and_col_tracking():
    toks = Lexer("let x = 1;\nlet y = 2;", filename="<test>").tokenize()
    let2 = [t for t in toks if t.type == TokenType.LET][1]
    assert let2.line == 2
    assert let2.col == 1
