from __future__ import annotations

from tests.helpers import run_main


def test_named_function_call():
    source = """
fn add(a, b) {
  return a + b;
}

fn main() {
  return add(2, 3);
}
"""
    assert run_main(source) == 5
