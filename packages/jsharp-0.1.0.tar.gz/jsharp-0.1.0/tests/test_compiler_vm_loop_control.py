from __future__ import annotations

import pytest

from jsharp.compiler import Compiler
from jsharp.errors import CompileError
from jsharp.lexer import Lexer
from jsharp.parser import Parser
from tests.helpers import run_main


def test_break_exits_loop_early():
    source = """
fn main() {
  let i = 0;
  let sum = 0;
  while (true) {
    if (i == 5) {
      break;
    }
    sum = sum + i;
    i = i + 1;
  }
  return sum;
}
"""
    assert run_main(source) == 10


def test_continue_skips_body_tail():
    source = """
fn main() {
  let i = 0;
  let sum = 0;
  while (i < 6) {
    i = i + 1;
    if (i % 2 == 1) {
      continue;
    }
    sum = sum + i;
  }
  return sum;
}
"""
    assert run_main(source) == 12


def test_nested_loops_break_inner_only():
    source = """
fn main() {
  let outer = 0;
  let total = 0;
  while (outer < 3) {
    let inner = 0;
    while (true) {
      if (inner == 2) {
        break;
      }
      total = total + 1;
      inner = inner + 1;
    }
    outer = outer + 1;
  }
  return total;
}
"""
    assert run_main(source) == 6


def test_break_outside_loop_is_compile_error():
    source = """
fn main() {
  break;
}
"""
    toks = Lexer(source, filename="<test>").tokenize()
    program = Parser(toks, filename="<test>").parse_program()
    with pytest.raises(CompileError):
        Compiler(filename="<test>").compile_program(program)
