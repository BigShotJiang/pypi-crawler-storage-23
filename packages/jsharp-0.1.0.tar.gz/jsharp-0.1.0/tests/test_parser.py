from __future__ import annotations

from jsharp import ast_nodes as ast
from jsharp.lexer import Lexer
from jsharp.parser import Parser


def parse(src: str):
    toks = Lexer(src, filename="<test>").tokenize()
    return Parser(toks, filename="<test>").parse_program()


def test_parse_main_function():
    program = parse("fn main() { let x = 3; return x; }")
    assert len(program.functions) == 1
    assert program.functions[0].name == "main"


def test_precedence():
    program = parse("fn main() { return 1 + 2 * 3; }")
    ret = program.functions[0].body[0]
    assert isinstance(ret, ast.ReturnStmt)
    expr = ret.value
    assert isinstance(expr, ast.BinaryExpr)
    assert expr.op == "+"
    assert isinstance(expr.right, ast.BinaryExpr)
    assert expr.right.op == "*"


def test_parse_call_and_getattr_chain():
    program = parse("fn main() { http.serve(8080, handler); }")
    stmt = program.functions[0].body[0]
    assert isinstance(stmt, ast.ExprStmt)
    call = stmt.expr
    assert isinstance(call, ast.CallExpr)
    assert isinstance(call.callee, ast.GetAttrExpr)
    assert call.callee.name == "serve"


def test_parse_fn_literal():
    program = parse("fn main() { let f = fn(x) { return x + 1; }; }")
    stmt = program.functions[0].body[0]
    assert isinstance(stmt, ast.LetStmt)
    assert isinstance(stmt.expr, ast.FnLitExpr)


def test_parse_list_and_index_set():
    program = parse("fn main() { let a = [1, 2, 3]; a[1] = 9; return a[1]; }")
    stmts = program.functions[0].body
    assert isinstance(stmts[0], ast.LetStmt)
    assert isinstance(stmts[0].expr, ast.ListLitExpr)
    assert isinstance(stmts[1], ast.IndexSetStmt)
    assert isinstance(stmts[2], ast.ReturnStmt)
