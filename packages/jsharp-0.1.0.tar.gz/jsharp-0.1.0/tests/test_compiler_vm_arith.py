from __future__ import annotations

from tests.helpers import run_main


def test_arithmetic_result():
    source = """
fn main() {
  return 1 + 2 * 3;
}
"""
    assert run_main(source) == 7


def test_string_concat_with_plus():
    source = """
fn main() {
  return "Path: " + 42;
}
"""
    assert run_main(source) == "Path: 42"
