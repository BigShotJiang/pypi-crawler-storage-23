from __future__ import annotations

import queue
import socket
import threading
import time
import urllib.request

from tests.helpers import run_main


def _free_port() -> int:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def test_web_bridge_smoke():
    port = _free_port()
    source = f"""
fn main() {{
  http.serve({port}, fn(req) {{
    return "<h1>Hello</h1><p>Path: " + req.path + "</p>";
  }});
}}
"""

    errors: queue.Queue[Exception] = queue.Queue()

    def target():
        try:
            run_main(source, filename="<web-smoke>")
        except Exception as exc:  # pragma: no cover - only checked on failure
            errors.put(exc)

    thread = threading.Thread(target=target, daemon=True)
    thread.start()

    deadline = time.time() + 5
    response_text = ""
    while time.time() < deadline:
        try:
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=0.5) as resp:
                response_text = resp.read().decode("utf-8")
                break
        except Exception:
            time.sleep(0.05)

    assert "<h1>Hello" in response_text

    # Stop the server cleanly for test determinism.
    with urllib.request.urlopen(f"http://127.0.0.1:{port}/__shutdown", timeout=2) as _:
        pass

    thread.join(timeout=5)
    assert not thread.is_alive()
    assert errors.empty(), f"server thread failed: {errors.get() if not errors.empty() else None}"
