"""Builtin/native symbols registered in VM.globals."""

from __future__ import annotations

from jsharp.stdlib import fs, http, io, jsonlib
from jsharp.stdlib.io import IOState
from jsharp.values import NativeFn


def _native_print(vm, *args):
    print(*args)
    return None


def _native_len(vm, value):
    try:
        return len(value)
    except TypeError as exc:
        raise RuntimeError(f"len() not supported for type {type(value).__name__}") from exc


def _native_div(vm, a, b):
    if isinstance(a, bool) or isinstance(b, bool) or not isinstance(a, int) or not isinstance(b, int):
        raise RuntimeError("div(a,b) expects integer arguments")
    if b == 0:
        raise RuntimeError("division by zero")
    # Truncate toward zero for C-like competitive-programming semantics.
    return int(a / b)


def make_builtins(vm):
    if not hasattr(vm, "_io_state"):
        vm._io_state = IOState()

    return {
        "print": NativeFn("print", _native_print),
        "len": NativeFn("len", _native_len),
        "div": NativeFn("div", _native_div),
        "http": {
            "serve": NativeFn("http.serve", http.serve),
        },
        "fs": {
            "read_text": NativeFn("fs.read_text", fs.read_text),
            "write_text": NativeFn("fs.write_text", fs.write_text),
        },
        "json": {
            "parse": NativeFn("json.parse", jsonlib.parse),
            "stringify": NativeFn("json.stringify", jsonlib.stringify),
        },
        "io": {
            "read_all": NativeFn("io.read_all", io.read_all),
            "read_line": NativeFn("io.read_line", io.read_line),
            "read_int": NativeFn("io.read_int", io.read_int),
            "read_str": NativeFn("io.read_str", io.read_str),
            "write": NativeFn("io.write", io.write),
            "writeln": NativeFn("io.writeln", io.writeln),
            "flush": NativeFn("io.flush", io.flush),
        },
    }
