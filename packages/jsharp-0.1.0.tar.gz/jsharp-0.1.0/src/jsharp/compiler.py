"""AST -> bytecode compiler for J#."""

from __future__ import annotations

from dataclasses import dataclass, field

from jsharp import ast_nodes as ast
from jsharp.bytecode import Chunk
from jsharp.errors import CompileError
from jsharp.values import FunctionObj


@dataclass
class _FnCtx:
    name: str
    chunk: Chunk
    locals: set[str]
    forbidden_captures: set[str]


@dataclass
class _LoopCtx:
    continue_target: int
    break_jumps: list[int] = field(default_factory=list)


class Compiler:
    def __init__(self, filename: str = "<input>") -> None:
        self.filename = filename
        self._anon_counter = 0
        self._global_function_names: set[str] = set()
        self._compiled_functions: dict[str, FunctionObj] = {}
        self._loop_stack: list[_LoopCtx] = []

    def compile_program(self, program: ast.Program) -> dict[str, FunctionObj]:
        seen: set[str] = set()
        for fn in program.functions:
            if fn.name in seen:
                raise CompileError(
                    f"Duplicate function name: {fn.name}",
                    line=fn.line,
                    col=fn.col,
                    filename=self.filename,
                )
            seen.add(fn.name)

        self._global_function_names = set(seen)
        self._compiled_functions = {}

        if "main" not in self._global_function_names:
            raise CompileError(
                "Program must define fn main()",
                filename=self.filename,
                hint="Add `fn main() { ... }` as an entrypoint.",
            )

        out: dict[str, FunctionObj] = {}
        for fn in program.functions:
            out[fn.name] = self._compile_function(fn.name, fn.params, fn.body, forbidden_captures=set())
        return out

    @property
    def compiled_functions(self) -> dict[str, FunctionObj]:
        """All compiled functions, including anonymous literals."""
        return dict(self._compiled_functions)

    def _compile_function(
        self,
        name: str,
        params: list[str],
        body: list[ast.Stmt],
        forbidden_captures: set[str],
    ) -> FunctionObj:
        chunk = Chunk()
        ctx = _FnCtx(name=name, chunk=chunk, locals=set(params), forbidden_captures=set(forbidden_captures))

        for stmt in body:
            self._compile_stmt(ctx, stmt)

        if not chunk.code or chunk.code[-1].op != "RET":
            self._emit_const(ctx, None, line=0)
            chunk.emit("RET", line=0)

        fn_obj = FunctionObj(name=name, params=params, chunk=chunk)
        self._compiled_functions[name] = fn_obj
        return fn_obj

    def _compile_stmt(self, ctx: _FnCtx, stmt: ast.Stmt) -> None:
        if isinstance(stmt, ast.LetStmt):
            self._compile_expr(ctx, stmt.expr)
            ctx.chunk.emit("STORE", stmt.name, line=stmt.line)
            ctx.locals.add(stmt.name)
            return

        if isinstance(stmt, ast.AssignStmt):
            self._compile_expr(ctx, stmt.expr)
            ctx.chunk.emit("STORE", stmt.name, line=stmt.line)
            ctx.locals.add(stmt.name)
            return

        if isinstance(stmt, ast.IndexSetStmt):
            self._compile_expr(ctx, stmt.obj)
            self._compile_expr(ctx, stmt.index)
            self._compile_expr(ctx, stmt.value)
            ctx.chunk.emit("LIST_SET", line=stmt.line)
            return

        if isinstance(stmt, ast.ExprStmt):
            self._compile_expr(ctx, stmt.expr)
            ctx.chunk.emit("POP", line=stmt.line)
            return

        if isinstance(stmt, ast.IfStmt):
            self._compile_expr(ctx, stmt.cond)
            jmpf_idx = ctx.chunk.emit("JMPF", None, line=stmt.line)
            for child in stmt.then_body:
                self._compile_stmt(ctx, child)

            if stmt.else_body is not None:
                jmp_end_idx = ctx.chunk.emit("JMP", None, line=stmt.line)
                else_start = len(ctx.chunk.code)
                ctx.chunk.patch(jmpf_idx, else_start)
                for child in stmt.else_body:
                    self._compile_stmt(ctx, child)
                end = len(ctx.chunk.code)
                ctx.chunk.patch(jmp_end_idx, end)
            else:
                end = len(ctx.chunk.code)
                ctx.chunk.patch(jmpf_idx, end)
            return

        if isinstance(stmt, ast.WhileStmt):
            loop_start = len(ctx.chunk.code)
            self._compile_expr(ctx, stmt.cond)
            jmpf_idx = ctx.chunk.emit("JMPF", None, line=stmt.line)

            loop_ctx = _LoopCtx(continue_target=loop_start)
            self._loop_stack.append(loop_ctx)
            try:
                for child in stmt.body:
                    self._compile_stmt(ctx, child)
            finally:
                self._loop_stack.pop()

            ctx.chunk.emit("JMP", loop_start, line=stmt.line)
            loop_end = len(ctx.chunk.code)
            ctx.chunk.patch(jmpf_idx, loop_end)
            for break_jmp in loop_ctx.break_jumps:
                ctx.chunk.patch(break_jmp, loop_end)
            return

        if isinstance(stmt, ast.BreakStmt):
            if not self._loop_stack:
                raise CompileError(
                    "'break' used outside of a loop",
                    line=stmt.line,
                    col=stmt.col,
                    filename=self.filename,
                )
            patch_idx = ctx.chunk.emit("JMP", None, line=stmt.line)
            self._loop_stack[-1].break_jumps.append(patch_idx)
            return

        if isinstance(stmt, ast.ContinueStmt):
            if not self._loop_stack:
                raise CompileError(
                    "'continue' used outside of a loop",
                    line=stmt.line,
                    col=stmt.col,
                    filename=self.filename,
                )
            ctx.chunk.emit("JMP", self._loop_stack[-1].continue_target, line=stmt.line)
            return

        if isinstance(stmt, ast.ReturnStmt):
            if stmt.value is None:
                self._emit_const(ctx, None, line=stmt.line)
            else:
                self._compile_expr(ctx, stmt.value)
            ctx.chunk.emit("RET", line=stmt.line)
            return

        raise CompileError(
            f"Unsupported statement node: {type(stmt).__name__}",
            filename=self.filename,
        )

    def _compile_expr(self, ctx: _FnCtx, expr: ast.Expr) -> None:
        if isinstance(expr, ast.LiteralExpr):
            self._emit_const(ctx, expr.value, expr.line)
            return

        if isinstance(expr, ast.ListLitExpr):
            for item in expr.items:
                self._compile_expr(ctx, item)
            ctx.chunk.emit("MAKE_LIST", len(expr.items), line=expr.line)
            return

        if isinstance(expr, ast.VarExpr):
            if expr.name in ctx.forbidden_captures and expr.name not in ctx.locals:
                raise CompileError(
                    "J# MVP does not support closures yet; function literals cannot capture outer variables.",
                    line=expr.line,
                    col=expr.col,
                    filename=self.filename,
                    hint=f"Move `{expr.name}` to global scope or pass it as a parameter.",
                )
            ctx.chunk.emit("LOAD", expr.name, line=expr.line)
            return

        if isinstance(expr, ast.GroupExpr):
            self._compile_expr(ctx, expr.expr)
            return

        if isinstance(expr, ast.UnaryExpr):
            self._compile_expr(ctx, expr.right)
            op = {"!": "NOT", "-": "NEG"}.get(expr.op)
            if op is None:
                raise CompileError(
                    f"Unsupported unary operator: {expr.op}",
                    line=expr.line,
                    col=expr.col,
                    filename=self.filename,
                )
            ctx.chunk.emit(op, line=expr.line)
            return

        if isinstance(expr, ast.BinaryExpr):
            if expr.op == "&&":
                self._compile_expr(ctx, expr.left)
                ctx.chunk.emit("DUP", line=expr.line)
                jmpf_end = ctx.chunk.emit("JMPF", None, line=expr.line)
                ctx.chunk.emit("POP", line=expr.line)
                self._compile_expr(ctx, expr.right)
                end = len(ctx.chunk.code)
                ctx.chunk.patch(jmpf_end, end)
                return

            if expr.op == "||":
                self._compile_expr(ctx, expr.left)
                ctx.chunk.emit("DUP", line=expr.line)
                jmpf_eval_b = ctx.chunk.emit("JMPF", None, line=expr.line)
                jmp_end = ctx.chunk.emit("JMP", None, line=expr.line)
                eval_b = len(ctx.chunk.code)
                ctx.chunk.patch(jmpf_eval_b, eval_b)
                ctx.chunk.emit("POP", line=expr.line)
                self._compile_expr(ctx, expr.right)
                end = len(ctx.chunk.code)
                ctx.chunk.patch(jmp_end, end)
                return

            self._compile_expr(ctx, expr.left)
            self._compile_expr(ctx, expr.right)

            op = {
                "+": "ADD",
                "-": "SUB",
                "*": "MUL",
                "/": "DIV",
                "%": "MOD",
                "==": "EQ",
                "!=": "NE",
                "<": "LT",
                "<=": "LE",
                ">": "GT",
                ">=": "GE",
            }.get(expr.op)
            if op is None:
                raise CompileError(
                    f"Unsupported binary operator: {expr.op}",
                    line=expr.line,
                    col=expr.col,
                    filename=self.filename,
                )
            ctx.chunk.emit(op, line=expr.line)
            return

        if isinstance(expr, ast.CallExpr):
            self._compile_expr(ctx, expr.callee)
            for arg in expr.args:
                self._compile_expr(ctx, arg)
            ctx.chunk.emit("CALL", len(expr.args), line=expr.line)
            return

        if isinstance(expr, ast.GetAttrExpr):
            self._compile_expr(ctx, expr.obj)
            ctx.chunk.emit("GETATTR", expr.name, line=expr.line)
            return

        if isinstance(expr, ast.IndexGetExpr):
            self._compile_expr(ctx, expr.obj)
            self._compile_expr(ctx, expr.index)
            ctx.chunk.emit("LIST_GET", line=expr.line)
            return

        if isinstance(expr, ast.FnLitExpr):
            fn_name = self._fresh_anon_name()
            forbidden = set(ctx.forbidden_captures) | set(ctx.locals)
            fn_obj = self._compile_function(fn_name, expr.params, expr.body, forbidden_captures=forbidden)
            const_idx = ctx.chunk.add_const(fn_obj)
            ctx.chunk.emit("CONST", const_idx, line=expr.line)
            return

        raise CompileError(
            f"Unsupported expression node: {type(expr).__name__}",
            filename=self.filename,
        )

    def _emit_const(self, ctx: _FnCtx, value: object, line: int) -> None:
        idx = ctx.chunk.add_const(value)
        ctx.chunk.emit("CONST", idx, line=line)

    def _fresh_anon_name(self) -> str:
        self._anon_counter += 1
        return f"<anon_{self._anon_counter}>"
