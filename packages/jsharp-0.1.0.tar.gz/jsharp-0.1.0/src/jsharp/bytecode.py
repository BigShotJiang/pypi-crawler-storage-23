"""Bytecode container and disassembler for J# VM."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class Instruction:
    op: str
    arg: Any = None
    line: int = 0


class Chunk:
    def __init__(self) -> None:
        self.code: list[Instruction] = []
        self.consts: list[Any] = []

    def add_const(self, value: Any) -> int:
        self.consts.append(value)
        return len(self.consts) - 1

    def emit(self, op: str, arg: Any = None, line: int = 0) -> int:
        self.code.append(Instruction(op=op, arg=arg, line=line))
        return len(self.code) - 1

    def patch(self, index: int, arg: Any) -> None:
        self.code[index].arg = arg

    def disassemble(self, fn_name: str = "<fn>") -> str:
        def fmt_const(value: Any) -> str:
            # Keep disassembly stable even for function object constants.
            if hasattr(value, "name") and hasattr(value, "chunk"):
                return f"<fn {getattr(value, 'name', '?')}>"
            return repr(value)

        lines = [f"== Function {fn_name} ==", "Constants:"]
        if not self.consts:
            lines.append("  <none>")
        else:
            for i, c in enumerate(self.consts):
                lines.append(f"  [{i}] {fmt_const(c)}")

        lines.append("Code:")
        for i, ins in enumerate(self.code):
            if ins.arg is None:
                lines.append(f"  {i:04d} {ins.op}")
            elif ins.op == "CONST" and isinstance(ins.arg, int) and 0 <= ins.arg < len(self.consts):
                lines.append(f"  {i:04d} {ins.op} {ins.arg}    ; {fmt_const(self.consts[ins.arg])}")
            else:
                lines.append(f"  {i:04d} {ins.op} {ins.arg}")

        return "\n".join(lines)
