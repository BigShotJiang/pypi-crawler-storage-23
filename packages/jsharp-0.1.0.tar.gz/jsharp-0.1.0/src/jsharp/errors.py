"""Error types and pretty formatting for J# diagnostics."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class JSharpError(Exception):
    """Base error that carries location + hint metadata."""

    message: str
    line: int = 1
    col: int = 1
    hint: Optional[str] = None
    filename: str = "<input>"

    def __str__(self) -> str:  # pragma: no cover - trivial
        return self.message


class LexError(JSharpError):
    pass


class ParseError(JSharpError):
    pass


class CompileError(JSharpError):
    pass


class RuntimeJError(JSharpError):
    pass


def _safe_line(source: str, line: int) -> str:
    lines = source.splitlines()
    if 1 <= line <= len(lines):
        return lines[line - 1]
    return ""


def format_error(error: JSharpError, source: str = "", filename: Optional[str] = None) -> str:
    """Return a beginner-friendly caret diagnostic.

    Output shape:
      Error: Type: message
        --> file:line:col
      line | source line
           |   ^
      Hint: ...
    """

    file_display = filename or getattr(error, "filename", "<input>")
    line = max(1, int(getattr(error, "line", 1) or 1))
    col = max(1, int(getattr(error, "col", 1) or 1))

    src_line = _safe_line(source, line)
    caret_pad = " " * (max(col - 1, 0))

    parts = [
        f"Error: {error.__class__.__name__}: {error.message}",
        f"  --> {file_display}:{line}:{col}",
    ]

    if src_line:
        parts.append(f"{line:>4} | {src_line}")
        parts.append(f"     | {caret_pad}^")

    hint = getattr(error, "hint", None)
    if hint:
        parts.append(f"Hint: {hint}")

    return "\n".join(parts)
