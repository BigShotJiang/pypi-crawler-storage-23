"""Recursive-descent parser for J#.

EBNF:
program        = { fn_decl } EOF ;

fn_decl        = "fn" IDENT "(" [ params ] ")" block ;
params         = IDENT { "," IDENT } ;

block          = "{" { stmt } "}" ;

stmt           = let_stmt
               | if_stmt
               | while_stmt
               | return_stmt
               | break_stmt
               | continue_stmt
               | assign_stmt
               | index_set_stmt
               | expr_stmt ;

let_stmt       = "let" IDENT "=" expr ";" ;
assign_stmt    = IDENT "=" expr ";" ;
index_set_stmt = call "[" expr "]" "=" expr ";" ;
expr_stmt      = expr ";" ;

if_stmt        = "if" "(" expr ")" block [ "else" block ] ;
while_stmt     = "while" "(" expr ")" block ;
return_stmt    = "return" [ expr ] ";" ;
break_stmt     = "break" ";" ;
continue_stmt  = "continue" ";" ;

expr           = logic_or ;
logic_or       = logic_and { "||" logic_and } ;
logic_and      = equality { "&&" equality } ;
equality       = comparison { ("==" | "!=") comparison } ;
comparison     = term { ("<" | "<=" | ">" | ">=") term } ;
term           = factor { ("+" | "-") factor } ;
factor         = unary { ("*" | "/" | "%") unary } ;
unary          = ( "!" | "-" ) unary | call ;
call           = primary { "(" [ args ] ")" | "." IDENT | "[" expr "]" } ;
args           = expr { "," expr } ;

primary        = NUMBER
               | STRING
               | "true" | "false" | "none"
               | IDENT
               | "(" expr ")"
               | "[" [ args ] "]"
               | fn_lit ;

fn_lit         = "fn" "(" [ params ] ")" block ;
"""

from __future__ import annotations

from jsharp import ast_nodes as ast
from jsharp.errors import ParseError
from jsharp.tokens import Token, TokenType


class Parser:
    def __init__(self, tokens: list[Token], filename: str = "<input>") -> None:
        self.tokens = tokens
        self.filename = filename
        self.pos = 0

    def parse_program(self) -> ast.Program:
        functions: list[ast.FnDecl] = []
        while not self._at_end():
            if self._check(TokenType.EOF):
                break
            functions.append(self._parse_fn_decl())

        self._expect(TokenType.EOF, "Expected end of file")

        if not functions:
            raise ParseError(
                "Program must contain at least one function declaration",
                filename=self.filename,
                hint="Define `fn main() { ... }`.",
            )

        return ast.Program(functions)

    def _parse_fn_decl(self) -> ast.FnDecl:
        fn_tok = self._expect(TokenType.FN, "Expected 'fn' to start a function declaration")
        name_tok = self._expect(TokenType.IDENT, "Expected function name after 'fn'")
        self._expect(TokenType.LPAREN, "Expected '(' after function name")
        params = self._parse_params()
        self._expect(TokenType.RPAREN, "Expected ')' after parameter list")
        body = self._parse_block()
        return ast.FnDecl(name=name_tok.lexeme, params=params, body=body, line=fn_tok.line, col=fn_tok.col)

    def _parse_params(self) -> list[str]:
        params: list[str] = []
        if self._check(TokenType.RPAREN):
            return params

        while True:
            tok = self._expect(TokenType.IDENT, "Expected parameter name")
            params.append(tok.lexeme)
            if not self._match(TokenType.COMMA):
                break
        return params

    def _parse_block(self) -> list[ast.Stmt]:
        self._expect(TokenType.LBRACE, "Expected '{' to start block")
        stmts: list[ast.Stmt] = []
        while not self._check(TokenType.RBRACE) and not self._at_end():
            stmts.append(self._parse_stmt())
        self._expect(TokenType.RBRACE, "Expected '}' to close block")
        return stmts

    def _parse_stmt(self) -> ast.Stmt:
        tok = self._peek()

        if self._match(TokenType.LET):
            name = self._expect(TokenType.IDENT, "Expected identifier after 'let'")
            self._expect(TokenType.EQUAL, "Expected '=' in let statement")
            expr = self._parse_expr()
            self._expect(TokenType.SEMI, "Expected ';' after let statement")
            return ast.LetStmt(name.lexeme, expr, tok.line, tok.col)

        if self._match(TokenType.IF):
            self._expect(TokenType.LPAREN, "Expected '(' after 'if'")
            cond = self._parse_expr()
            self._expect(TokenType.RPAREN, "Expected ')' after if condition")
            then_body = self._parse_block()
            else_body = None
            if self._match(TokenType.ELSE):
                else_body = self._parse_block()
            return ast.IfStmt(cond, then_body, else_body, tok.line, tok.col)

        if self._match(TokenType.WHILE):
            self._expect(TokenType.LPAREN, "Expected '(' after 'while'")
            cond = self._parse_expr()
            self._expect(TokenType.RPAREN, "Expected ')' after while condition")
            body = self._parse_block()
            return ast.WhileStmt(cond, body, tok.line, tok.col)

        if self._match(TokenType.RETURN):
            value = None
            if not self._check(TokenType.SEMI):
                value = self._parse_expr()
            self._expect(TokenType.SEMI, "Expected ';' after return")
            return ast.ReturnStmt(value, tok.line, tok.col)

        if self._match(TokenType.BREAK):
            self._expect(TokenType.SEMI, "Expected ';' after break")
            return ast.BreakStmt(tok.line, tok.col)

        if self._match(TokenType.CONTINUE):
            self._expect(TokenType.SEMI, "Expected ';' after continue")
            return ast.ContinueStmt(tok.line, tok.col)

        # General assignment parsing: parse expression target first, then optional '='.
        expr = self._parse_expr()

        if self._match(TokenType.EQUAL):
            value = self._parse_expr()
            semi = self._expect(TokenType.SEMI, "Expected ';' after assignment")

            if isinstance(expr, ast.VarExpr):
                return ast.AssignStmt(expr.name, value, expr.line, expr.col)

            if isinstance(expr, ast.IndexGetExpr):
                return ast.IndexSetStmt(expr.obj, expr.index, value, expr.line, expr.col)

            raise ParseError(
                "Invalid assignment target",
                line=semi.line,
                col=semi.col,
                filename=self.filename,
                hint="Only variables and index targets like a[i] can be assigned.",
            )

        semi = self._expect(TokenType.SEMI, "Expected ';' after expression")
        return ast.ExprStmt(expr, semi.line, semi.col)

    def _parse_expr(self) -> ast.Expr:
        return self._parse_logic_or()

    def _parse_logic_or(self) -> ast.Expr:
        expr = self._parse_logic_and()
        while self._match(TokenType.OR_OR):
            op = self._previous()
            right = self._parse_logic_and()
            expr = ast.BinaryExpr(expr, op.lexeme, right, op.line, op.col)
        return expr

    def _parse_logic_and(self) -> ast.Expr:
        expr = self._parse_equality()
        while self._match(TokenType.AND_AND):
            op = self._previous()
            right = self._parse_equality()
            expr = ast.BinaryExpr(expr, op.lexeme, right, op.line, op.col)
        return expr

    def _parse_equality(self) -> ast.Expr:
        expr = self._parse_comparison()
        while self._match(TokenType.EQ_EQ, TokenType.BANG_EQ):
            op = self._previous()
            right = self._parse_comparison()
            expr = ast.BinaryExpr(expr, op.lexeme, right, op.line, op.col)
        return expr

    def _parse_comparison(self) -> ast.Expr:
        expr = self._parse_term()
        while self._match(TokenType.LT, TokenType.LT_EQ, TokenType.GT, TokenType.GT_EQ):
            op = self._previous()
            right = self._parse_term()
            expr = ast.BinaryExpr(expr, op.lexeme, right, op.line, op.col)
        return expr

    def _parse_term(self) -> ast.Expr:
        expr = self._parse_factor()
        while self._match(TokenType.PLUS, TokenType.MINUS):
            op = self._previous()
            right = self._parse_factor()
            expr = ast.BinaryExpr(expr, op.lexeme, right, op.line, op.col)
        return expr

    def _parse_factor(self) -> ast.Expr:
        expr = self._parse_unary()
        while self._match(TokenType.STAR, TokenType.SLASH, TokenType.PERCENT):
            op = self._previous()
            right = self._parse_unary()
            expr = ast.BinaryExpr(expr, op.lexeme, right, op.line, op.col)
        return expr

    def _parse_unary(self) -> ast.Expr:
        if self._match(TokenType.BANG, TokenType.MINUS):
            op = self._previous()
            right = self._parse_unary()
            return ast.UnaryExpr(op.lexeme, right, op.line, op.col)
        return self._parse_call()

    def _parse_call(self) -> ast.Expr:
        expr = self._parse_primary()

        while True:
            if self._match(TokenType.LPAREN):
                args: list[ast.Expr] = []
                if not self._check(TokenType.RPAREN):
                    while True:
                        args.append(self._parse_expr())
                        if not self._match(TokenType.COMMA):
                            break
                rp = self._expect(TokenType.RPAREN, "Expected ')' after call arguments")
                expr = ast.CallExpr(expr, args, rp.line, rp.col)
                continue

            if self._match(TokenType.DOT):
                name = self._expect(TokenType.IDENT, "Expected attribute name after '.'")
                expr = ast.GetAttrExpr(expr, name.lexeme, name.line, name.col)
                continue

            if self._match(TokenType.LBRACKET):
                idx = self._parse_expr()
                rb = self._expect(TokenType.RBRACKET, "Expected ']' after index expression")
                expr = ast.IndexGetExpr(expr, idx, rb.line, rb.col)
                continue

            break

        return expr

    def _parse_primary(self) -> ast.Expr:
        tok = self._peek()

        if self._match(TokenType.NUMBER):
            return ast.LiteralExpr(self._previous().literal, tok.line, tok.col)
        if self._match(TokenType.STRING):
            return ast.LiteralExpr(self._previous().literal, tok.line, tok.col)
        if self._match(TokenType.TRUE):
            return ast.LiteralExpr(True, tok.line, tok.col)
        if self._match(TokenType.FALSE):
            return ast.LiteralExpr(False, tok.line, tok.col)
        if self._match(TokenType.NONE):
            return ast.LiteralExpr(None, tok.line, tok.col)

        if self._match(TokenType.IDENT):
            return ast.VarExpr(self._previous().lexeme, tok.line, tok.col)

        if self._match(TokenType.LPAREN):
            expr = self._parse_expr()
            self._expect(TokenType.RPAREN, "Expected ')' after expression")
            return ast.GroupExpr(expr, tok.line, tok.col)

        if self._match(TokenType.LBRACKET):
            items: list[ast.Expr] = []
            if not self._check(TokenType.RBRACKET):
                while True:
                    items.append(self._parse_expr())
                    if not self._match(TokenType.COMMA):
                        break
            self._expect(TokenType.RBRACKET, "Expected ']' after list literal")
            return ast.ListLitExpr(items, tok.line, tok.col)

        if self._match(TokenType.FN):
            self._expect(TokenType.LPAREN, "Expected '(' after anonymous 'fn'")
            params = self._parse_params()
            self._expect(TokenType.RPAREN, "Expected ')' after function literal parameters")
            body = self._parse_block()
            return ast.FnLitExpr(params, body, tok.line, tok.col)

        raise ParseError(
            f"Unexpected token: {tok.type.name} ({tok.lexeme!r})",
            line=tok.line,
            col=tok.col,
            filename=self.filename,
            hint="Check expression syntax and missing punctuation.",
        )

    # ---------- helpers ----------

    def _match(self, *types: TokenType) -> bool:
        for ttype in types:
            if self._check(ttype):
                self._advance()
                return True
        return False

    def _expect(self, ttype: TokenType, message: str) -> Token:
        if self._check(ttype):
            return self._advance()
        tok = self._peek()
        hint = "Did you forget a semicolon?" if ttype == TokenType.SEMI else None
        raise ParseError(
            message,
            line=tok.line,
            col=tok.col,
            filename=self.filename,
            hint=hint,
        )

    def _check(self, ttype: TokenType) -> bool:
        if self._at_end():
            return ttype == TokenType.EOF
        return self._peek().type == ttype

    def _advance(self) -> Token:
        if not self._at_end():
            self.pos += 1
        return self._previous()

    def _peek(self) -> Token:
        return self.tokens[self.pos]

    def _previous(self) -> Token:
        return self.tokens[self.pos - 1]

    def _at_end(self) -> bool:
        return self._peek().type == TokenType.EOF
