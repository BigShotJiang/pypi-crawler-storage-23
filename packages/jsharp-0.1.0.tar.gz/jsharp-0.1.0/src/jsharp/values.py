"""Runtime callable values for J#."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from jsharp.bytecode import Chunk


@dataclass
class FunctionObj:
    name: str
    params: list[str]
    chunk: Chunk


@dataclass
class NativeFn:
    name: str
    fn: Callable[..., Any]

    def __repr__(self) -> str:  # pragma: no cover - debug helper
        return f"<native {self.name}>"
