"""Fast buffered stdin/stdout helpers for J# competitive-programming workflows."""

from __future__ import annotations

import sys
from dataclasses import dataclass, field


def _is_ws(byte: int) -> bool:
    return byte in (9, 10, 11, 12, 13, 32)


@dataclass
class FastInput:
    data: bytes | None = None
    idx: int = 0

    def _ensure(self) -> None:
        if self.data is None:
            self.data = sys.stdin.buffer.read()
            self.idx = 0

    def read_all(self) -> str:
        self._ensure()
        assert self.data is not None
        if self.idx >= len(self.data):
            return ""
        out = self.data[self.idx :]
        self.idx = len(self.data)
        return out.decode("utf-8")

    def read_line(self) -> str | None:
        self._ensure()
        assert self.data is not None
        if self.idx >= len(self.data):
            return None

        start = self.idx
        while self.idx < len(self.data) and self.data[self.idx] != 10:
            self.idx += 1

        line = self.data[start : self.idx]
        if self.idx < len(self.data) and self.data[self.idx] == 10:
            self.idx += 1

        if line.endswith(b"\r"):
            line = line[:-1]
        return line.decode("utf-8")

    def _read_token(self) -> str | None:
        self._ensure()
        assert self.data is not None

        n = len(self.data)
        while self.idx < n and _is_ws(self.data[self.idx]):
            self.idx += 1

        if self.idx >= n:
            return None

        start = self.idx
        while self.idx < n and not _is_ws(self.data[self.idx]):
            self.idx += 1

        return self.data[start : self.idx].decode("utf-8")

    def read_int(self) -> int:
        tok = self._read_token()
        if tok is None:
            raise ValueError("io.read_int() reached EOF")
        return int(tok)

    def read_str(self) -> str | None:
        return self._read_token()


@dataclass
class FastOutput:
    parts: list[str] = field(default_factory=list)

    def write(self, value) -> None:
        self.parts.append(str(value))

    def writeln(self, value) -> None:
        self.parts.append(f"{value}\n")

    def flush(self) -> None:
        if not self.parts:
            return
        sys.stdout.write("".join(self.parts))
        sys.stdout.flush()
        self.parts.clear()


@dataclass
class IOState:
    inp: FastInput = field(default_factory=FastInput)
    out: FastOutput = field(default_factory=FastOutput)


# Native wrapper fns take `vm` first (VM instance).
def read_all(vm):
    return vm._io_state.inp.read_all()


def read_line(vm):
    return vm._io_state.inp.read_line()


def read_int(vm):
    try:
        return vm._io_state.inp.read_int()
    except ValueError as exc:
        raise RuntimeError(str(exc)) from exc


def read_str(vm):
    return vm._io_state.inp.read_str()


def write(vm, value):
    vm._io_state.out.write(value)
    return None


def writeln(vm, value):
    vm._io_state.out.writeln(value)
    return None


def flush(vm):
    vm._io_state.out.flush()
    return None
