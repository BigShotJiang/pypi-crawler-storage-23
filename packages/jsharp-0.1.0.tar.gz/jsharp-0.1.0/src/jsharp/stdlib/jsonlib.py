"""JSON helpers exposed to J# as native functions."""

from __future__ import annotations

import json


def parse(vm, text):
    return json.loads(str(text))


def stringify(vm, obj):
    return json.dumps(obj)
