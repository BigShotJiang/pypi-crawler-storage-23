"""Filesystem helpers exposed to J# as native functions."""

from __future__ import annotations


def read_text(vm, path):
    with open(str(path), "r", encoding="utf-8") as f:
        return f.read()


def write_text(vm, path, content):
    with open(str(path), "w", encoding="utf-8") as f:
        f.write(str(content))
    return None
