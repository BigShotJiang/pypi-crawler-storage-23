"""HTTP stdlib bridge for J#.

This module keeps the server implementation in Python but runs request handlers
through vm.call_value(handler, [req]) so user logic is still executed by J# VM.
"""

from __future__ import annotations

import threading
from http.server import BaseHTTPRequestHandler, HTTPServer


def serve(vm, port, handler):
    port_i = int(port)

    server_holder: dict[str, HTTPServer] = {}

    class JSharpHandler(BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):  # pragma: no cover - cosmetic
            return

        def do_GET(self):  # noqa: N802 - stdlib naming
            server = server_holder["server"]

            if self.path == "/__shutdown":
                body = "Shutting down J# test server"
                self.send_response(200)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(body.encode("utf-8"))))
                self.end_headers()
                self.wfile.write(body.encode("utf-8"))

                # Shutdown must happen outside the current request handler call stack.
                threading.Thread(target=server.shutdown, daemon=True).start()
                return

            req = {"path": self.path, "method": "GET"}
            status = 200
            try:
                result = vm.call_value(handler, [req])
                body = "" if result is None else str(result)
            except Exception as exc:
                status = 500
                body = f"<h1>500 Internal Server Error</h1><pre>{exc}</pre>"
                print(f"[jsharp/http] handler error: {exc}")

            data = body.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

    server = HTTPServer(("127.0.0.1", port_i), JSharpHandler)
    server_holder["server"] = server

    print(f"J# server running on http://localhost:{port_i}")
    try:
        server.serve_forever()
    finally:
        server.server_close()

    return None
