"""J# lexer: source text -> tokens."""

from __future__ import annotations

from jsharp.errors import LexError
from jsharp.tokens import KEYWORDS, Token, TokenType


class Lexer:
    def __init__(self, source: str, filename: str = "<input>") -> None:
        self.source = source
        self.filename = filename
        self.i = 0
        self.line = 1
        self.col = 1
        self.tokens: list[Token] = []

    def tokenize(self) -> list[Token]:
        while not self._at_end():
            start_i = self.i
            ch = self._peek()

            if ch in " \t\r":
                self._advance()
                continue
            if ch == "\n":
                self._advance()
                continue

            if ch == "/" and self._peek_next() == "/":
                self._skip_comment()
                continue

            start_line = self.line
            start_col = self.col

            if ch.isdigit():
                self._number(start_line, start_col)
            elif ch.isalpha() or ch == "_":
                self._identifier_or_keyword(start_line, start_col)
            elif ch == '"':
                self._string(start_line, start_col)
            else:
                self._symbol(start_line, start_col)

            if self.i <= start_i:
                raise LexError(
                    "Lexer made no progress",
                    line=self.line,
                    col=self.col,
                    filename=self.filename,
                    hint="Check tokenize() branches and make sure each branch consumes characters.",
                )

        self.tokens.append(Token(TokenType.EOF, "", None, self.line, self.col))
        return self.tokens

    def _symbol(self, line: int, col: int) -> None:
        ch = self._advance()

        single = {
            "(": TokenType.LPAREN,
            ")": TokenType.RPAREN,
            "{": TokenType.LBRACE,
            "}": TokenType.RBRACE,
            "[": TokenType.LBRACKET,
            "]": TokenType.RBRACKET,
            ",": TokenType.COMMA,
            ".": TokenType.DOT,
            ";": TokenType.SEMI,
            "+": TokenType.PLUS,
            "-": TokenType.MINUS,
            "*": TokenType.STAR,
            "%": TokenType.PERCENT,
            "/": TokenType.SLASH,
        }

        if ch in single:
            self.tokens.append(Token(single[ch], ch, None, line, col))
            return

        if ch == "!":
            if self._match("="):
                self.tokens.append(Token(TokenType.BANG_EQ, "!=", None, line, col))
            else:
                self.tokens.append(Token(TokenType.BANG, "!", None, line, col))
            return

        if ch == "=":
            if self._match("="):
                self.tokens.append(Token(TokenType.EQ_EQ, "==", None, line, col))
            else:
                self.tokens.append(Token(TokenType.EQUAL, "=", None, line, col))
            return

        if ch == "<":
            if self._match("="):
                self.tokens.append(Token(TokenType.LT_EQ, "<=", None, line, col))
            else:
                self.tokens.append(Token(TokenType.LT, "<", None, line, col))
            return

        if ch == ">":
            if self._match("="):
                self.tokens.append(Token(TokenType.GT_EQ, ">=", None, line, col))
            else:
                self.tokens.append(Token(TokenType.GT, ">", None, line, col))
            return

        if ch == "&":
            if self._match("&"):
                self.tokens.append(Token(TokenType.AND_AND, "&&", None, line, col))
                return
            raise LexError(
                "Single '&' is not supported",
                line=line,
                col=col,
                filename=self.filename,
                hint="Use '&&' for logical AND.",
            )

        if ch == "|":
            if self._match("|"):
                self.tokens.append(Token(TokenType.OR_OR, "||", None, line, col))
                return
            raise LexError(
                "Single '|' is not supported",
                line=line,
                col=col,
                filename=self.filename,
                hint="Use '||' for logical OR.",
            )

        raise LexError(
            f"Unexpected character: {ch!r}",
            line=line,
            col=col,
            filename=self.filename,
        )

    def _number(self, line: int, col: int) -> None:
        start = self.i
        while self._peek().isdigit():
            self._advance()

        is_float = False
        if self._peek() == "." and self._peek_next().isdigit():
            is_float = True
            self._advance()  # dot
            while self._peek().isdigit():
                self._advance()

        lexeme = self.source[start:self.i]
        literal = float(lexeme) if is_float else int(lexeme)
        self.tokens.append(Token(TokenType.NUMBER, lexeme, literal, line, col))

    def _identifier_or_keyword(self, line: int, col: int) -> None:
        start = self.i
        while self._peek().isalnum() or self._peek() == "_":
            self._advance()

        lexeme = self.source[start:self.i]
        ttype = KEYWORDS.get(lexeme, TokenType.IDENT)
        self.tokens.append(Token(ttype, lexeme, None, line, col))

    def _string(self, line: int, col: int) -> None:
        start = self.i
        self._advance()  # opening quote
        chars: list[str] = []

        while not self._at_end() and self._peek() != '"':
            ch = self._advance()
            if ch == "\\":
                if self._at_end():
                    break
                esc = self._advance()
                if esc == "n":
                    chars.append("\n")
                elif esc == "t":
                    chars.append("\t")
                elif esc == '"':
                    chars.append('"')
                elif esc == "\\":
                    chars.append("\\")
                else:
                    raise LexError(
                        f"Unknown escape sequence: \\{esc}",
                        line=self.line,
                        col=self.col - 1,
                        filename=self.filename,
                        hint='Supported escapes are \\n, \\t, \\" and \\\\.',
                    )
            else:
                chars.append(ch)

        if self._at_end():
            raise LexError(
                "Unterminated string literal",
                line=line,
                col=col,
                filename=self.filename,
                hint="Add a closing double quote.",
            )

        self._advance()  # closing quote
        lexeme = self.source[start:self.i]
        self.tokens.append(Token(TokenType.STRING, lexeme, "".join(chars), line, col))

    def _skip_comment(self) -> None:
        self._advance()
        self._advance()
        while not self._at_end() and self._peek() != "\n":
            self._advance()

    def _at_end(self) -> bool:
        return self.i >= len(self.source)

    def _peek(self) -> str:
        if self._at_end():
            return "\0"
        return self.source[self.i]

    def _peek_next(self) -> str:
        if self.i + 1 >= len(self.source):
            return "\0"
        return self.source[self.i + 1]

    def _advance(self) -> str:
        ch = self.source[self.i]
        self.i += 1
        if ch == "\n":
            self.line += 1
            self.col = 1
        else:
            self.col += 1
        return ch

    def _match(self, expected: str) -> bool:
        if self._at_end():
            return False
        if self.source[self.i] != expected:
            return False
        self._advance()
        return True
