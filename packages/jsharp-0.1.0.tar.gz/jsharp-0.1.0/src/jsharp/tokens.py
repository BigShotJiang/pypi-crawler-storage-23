"""Token model for the J# lexer and parser."""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto
from typing import Any


class TokenType(Enum):
    # Single-character tokens.
    LPAREN = auto()
    RPAREN = auto()
    LBRACE = auto()
    RBRACE = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    COMMA = auto()
    DOT = auto()
    SEMI = auto()
    PLUS = auto()
    MINUS = auto()
    STAR = auto()
    SLASH = auto()
    PERCENT = auto()

    # One/two-character operators.
    BANG = auto()
    EQUAL = auto()
    LT = auto()
    GT = auto()
    AND_AND = auto()
    OR_OR = auto()
    EQ_EQ = auto()
    BANG_EQ = auto()
    LT_EQ = auto()
    GT_EQ = auto()

    # Literals.
    IDENT = auto()
    NUMBER = auto()
    STRING = auto()

    # Keywords.
    FN = auto()
    LET = auto()
    IF = auto()
    ELSE = auto()
    WHILE = auto()
    RETURN = auto()
    BREAK = auto()
    CONTINUE = auto()
    TRUE = auto()
    FALSE = auto()
    NONE = auto()

    EOF = auto()


KEYWORDS = {
    "fn": TokenType.FN,
    "let": TokenType.LET,
    "if": TokenType.IF,
    "else": TokenType.ELSE,
    "while": TokenType.WHILE,
    "return": TokenType.RETURN,
    "break": TokenType.BREAK,
    "continue": TokenType.CONTINUE,
    "true": TokenType.TRUE,
    "false": TokenType.FALSE,
    "none": TokenType.NONE,
}


@dataclass(frozen=True)
class Token:
    type: TokenType
    lexeme: str
    literal: Any
    line: int
    col: int

    def pretty(self) -> str:
        lex = self.lexeme.replace("\n", "\\n")
        return f'[{self.type.name} "{lex}" @ {self.line}:{self.col}]'
