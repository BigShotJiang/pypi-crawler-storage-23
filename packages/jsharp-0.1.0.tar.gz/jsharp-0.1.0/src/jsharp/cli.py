"""Command-line interface for J# (jsh)."""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

from jsharp.builtins import make_builtins
from jsharp.bytecode_io import write_program
from jsharp.compiler import Compiler
from jsharp.errors import CompileError, LexError, ParseError, RuntimeJError, format_error
from jsharp.lexer import Lexer
from jsharp.parser import Parser
from jsharp.vm import VM


def _read_file(path: str) -> str:
    return Path(path).read_text(encoding="utf-8")


def _pipeline(source: str, filename: str):
    tokens = Lexer(source, filename=filename).tokenize()
    program = Parser(tokens, filename=filename).parse_program()
    compiler = Compiler(filename=filename)
    functions = compiler.compile_program(program)
    return tokens, program, functions, compiler


def _default_native_bin() -> Path:
    repo_root = Path(__file__).resolve().parents[2]
    name = "jsh-native.exe" if os.name == "nt" else "jsh-native"
    return repo_root / "runtime" / "jsharp_vm" / "target" / "release" / name


def _runtime_dir() -> Path:
    return Path(__file__).resolve().parents[2] / "runtime" / "jsharp_vm"


def _try_build_native(native_bin: Path, debug: bool = False) -> bool:
    cargo = shutil.which("cargo")
    runtime_dir = _runtime_dir()
    if cargo is None or not runtime_dir.exists():
        return False

    if debug:
        print(f"[debug] building native VM with cargo in {runtime_dir}")

    proc = subprocess.run([cargo, "build", "--release"], cwd=runtime_dir, check=False)
    return proc.returncode == 0 and native_bin.exists()


def cmd_build(path: str, out_path: str | None = None) -> int:
    try:
        source = _read_file(path)
    except OSError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    try:
        _tokens, _program, functions, _compiler = _pipeline(source, path)
        target = Path(out_path) if out_path else Path(path).with_suffix(".jbc")
        write_program(target, functions, entrypoint="main")
        print(target)
        return 0
    except (LexError, ParseError, CompileError) as exc:
        print(format_error(exc, source, filename=path), file=sys.stderr)
        return 1


def cmd_run(path: str, debug: bool = False, native: bool = False) -> int:
    try:
        source = _read_file(path)
    except OSError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    try:
        t0 = time.perf_counter()
        _tokens, _program, functions, _compiler = _pipeline(source, path)
        compile_ms = (time.perf_counter() - t0) * 1000

        def run_python_vm() -> int:
            vm = VM(debug=debug)
            vm.globals.update(make_builtins(vm))
            vm.globals.update(functions)

            if debug:
                print(f"[debug] compile time: {compile_ms:.2f} ms")
                print("[debug] Running main()")

            vm.call_value(vm.globals["main"], [])
            return 0

        if native:
            native_bin = Path(os.environ.get("JSHARP_NATIVE_BIN", str(_default_native_bin())))
            if not native_bin.exists():
                built = _try_build_native(native_bin, debug=debug)
                if not built:
                    print(
                        "Native VM binary not found and could not be built automatically.\n"
                        "Falling back to Python VM execution.\n"
                        "To enable native mode, install Rust and run:\n"
                        "  cd runtime/jsharp_vm && cargo build --release\n"
                        f"Expected binary: {native_bin}",
                        file=sys.stderr,
                    )
                    return run_python_vm()

            with tempfile.NamedTemporaryFile(suffix=".jbc", delete=False) as temp_file:
                jbc_path = Path(temp_file.name)

            try:
                write_program(jbc_path, functions, entrypoint="main")
                if debug:
                    print(f"[debug] compile time: {compile_ms:.2f} ms")
                    print(f"[debug] native bytecode: {jbc_path}")
                proc = subprocess.run([str(native_bin), "run", str(jbc_path)], check=False)
                return int(proc.returncode)
            finally:
                try:
                    jbc_path.unlink(missing_ok=True)
                except OSError:
                    pass

        return run_python_vm()

    except (LexError, ParseError, CompileError) as exc:
        print(format_error(exc, source, filename=path), file=sys.stderr)
        return 1
    except RuntimeJError as exc:
        print(format_error(exc, source, filename=path), file=sys.stderr)
        return 2


def cmd_dump(path: str) -> int:
    try:
        source = _read_file(path)
    except OSError as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 1

    try:
        tokens, program, functions, _compiler = _pipeline(source, path)
    except (LexError, ParseError, CompileError) as exc:
        print(format_error(exc, source, filename=path), file=sys.stderr)
        return 1

    print("== Tokens ==")
    for tok in tokens:
        print(tok.pretty())

    print("\n== AST ==")
    print(program)

    print("\n== Bytecode ==")
    for name in sorted(functions):
        print(functions[name].chunk.disassemble(name))
        print()

    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="jsh", description="J# language toolchain")
    sub = parser.add_subparsers(dest="command", required=True)

    p_run = sub.add_parser("run", help="Compile and run a .jsh program")
    p_run.add_argument("path", help="Path to .jsh source file")
    p_run.add_argument("--debug", action="store_true", help="Print VM trace while running")
    p_run.add_argument(
        "--native",
        action="store_true",
        help="Run using native VM (compile source to temporary .jbc and invoke jsh-native)",
    )

    p_dump = sub.add_parser("dump", help="Show tokens, AST, and bytecode")
    p_dump.add_argument("path", help="Path to .jsh source file")

    p_build = sub.add_parser("build", help="Compile .jsh source into .jbc bytecode")
    p_build.add_argument("path", help="Path to .jsh source file")
    p_build.add_argument("-o", "--out", help="Output .jbc path (default: input name with .jbc)")

    return parser


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "run":
        return cmd_run(args.path, debug=args.debug, native=args.native)
    if args.command == "dump":
        return cmd_dump(args.path)
    if args.command == "build":
        return cmd_build(args.path, args.out)

    parser.print_help()
    return 1


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
