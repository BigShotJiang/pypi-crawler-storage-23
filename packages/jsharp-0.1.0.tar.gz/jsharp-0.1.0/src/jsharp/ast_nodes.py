"""AST dataclasses for J#. Keep this file simple and beginner-readable."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


@dataclass
class Program:
    functions: list["FnDecl"]


@dataclass
class FnDecl:
    name: str
    params: list[str]
    body: list["Stmt"]
    line: int
    col: int


class Stmt:
    pass


@dataclass
class LetStmt(Stmt):
    name: str
    expr: "Expr"
    line: int
    col: int


@dataclass
class AssignStmt(Stmt):
    name: str
    expr: "Expr"
    line: int
    col: int


@dataclass
class IndexSetStmt(Stmt):
    obj: "Expr"
    index: "Expr"
    value: "Expr"
    line: int
    col: int


@dataclass
class ExprStmt(Stmt):
    expr: "Expr"
    line: int
    col: int


@dataclass
class IfStmt(Stmt):
    cond: "Expr"
    then_body: list[Stmt]
    else_body: Optional[list[Stmt]]
    line: int
    col: int


@dataclass
class WhileStmt(Stmt):
    cond: "Expr"
    body: list[Stmt]
    line: int
    col: int


@dataclass
class BreakStmt(Stmt):
    line: int
    col: int


@dataclass
class ContinueStmt(Stmt):
    line: int
    col: int


@dataclass
class ReturnStmt(Stmt):
    value: Optional["Expr"]
    line: int
    col: int


class Expr:
    pass


@dataclass
class LiteralExpr(Expr):
    value: object
    line: int
    col: int


@dataclass
class ListLitExpr(Expr):
    items: list["Expr"]
    line: int
    col: int


@dataclass
class VarExpr(Expr):
    name: str
    line: int
    col: int


@dataclass
class UnaryExpr(Expr):
    op: str
    right: Expr
    line: int
    col: int


@dataclass
class BinaryExpr(Expr):
    left: Expr
    op: str
    right: Expr
    line: int
    col: int


@dataclass
class CallExpr(Expr):
    callee: Expr
    args: list[Expr]
    line: int
    col: int


@dataclass
class GetAttrExpr(Expr):
    obj: Expr
    name: str
    line: int
    col: int


@dataclass
class IndexGetExpr(Expr):
    obj: Expr
    index: Expr
    line: int
    col: int


@dataclass
class GroupExpr(Expr):
    expr: Expr
    line: int
    col: int


@dataclass
class FnLitExpr(Expr):
    params: list[str]
    body: list[Stmt]
    line: int
    col: int
