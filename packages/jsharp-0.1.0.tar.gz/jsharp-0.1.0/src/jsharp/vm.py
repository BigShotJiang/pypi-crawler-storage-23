"""Stack-based VM for J# bytecode."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from jsharp.errors import RuntimeJError
from jsharp.values import FunctionObj, NativeFn

I64_MIN = -(2**63)
I64_MAX = 2**63 - 1


@dataclass
class Frame:
    fn: FunctionObj
    ip: int = 0
    locals: dict[str, Any] = field(default_factory=dict)


class VM:
    """Executes J# bytecode.

    STORE convention in this VM consumes the assigned value.
    """

    def __init__(self, globals_dict: dict[str, Any] | None = None, debug: bool = False) -> None:
        self.stack: list[Any] = []
        self.frames: list[Frame] = []
        self.globals: dict[str, Any] = globals_dict or {}
        self.debug = debug

    def call_value(self, callee: Any, args: list[Any]) -> Any:
        if isinstance(callee, NativeFn):
            return callee.fn(self, *args)

        if isinstance(callee, FunctionObj):
            return self._call_function(callee, args)

        raise RuntimeJError(f"Not callable: {callee!r}")

    def _call_function(self, fn: FunctionObj, args: list[Any]) -> Any:
        if len(args) != len(fn.params):
            raise RuntimeJError(
                f"Function {fn.name} expects {len(fn.params)} args, got {len(args)}"
            )

        locals_dict = {name: value for name, value in zip(fn.params, args)}
        stop_depth = len(self.frames)
        self.frames.append(Frame(fn=fn, ip=0, locals=locals_dict))
        return self._run_until_depth(stop_depth)

    def _run_until_depth(self, stop_depth: int) -> Any:
        while len(self.frames) > stop_depth:
            frame = self.frames[-1]
            if frame.ip < 0 or frame.ip >= len(frame.fn.chunk.code):
                raise RuntimeJError(f"Instruction pointer out of range in function {frame.fn.name}")

            ins = frame.fn.chunk.code[frame.ip]
            frame.ip += 1

            if self.debug:
                arg_text = "" if ins.arg is None else f" {ins.arg}"
                print(
                    f"[VM] fn={frame.fn.name} ip={frame.ip - 1:04d} op={ins.op}{arg_text} stack={self.stack}"
                )

            try:
                op = ins.op

                if op == "CONST":
                    self.stack.append(frame.fn.chunk.consts[ins.arg])

                elif op == "LOAD":
                    self.stack.append(self._load_name(ins.arg))

                elif op == "STORE":
                    value = self._pop("STORE needs a value")
                    frame.locals[ins.arg] = value

                elif op == "POP":
                    self._pop("POP on empty stack")

                elif op == "DUP":
                    value = self._peek("DUP on empty stack")
                    self.stack.append(value)

                elif op == "MAKE_LIST":
                    n = int(ins.arg)
                    if n < 0:
                        raise RuntimeJError("MAKE_LIST received negative size", line=ins.line)
                    values = [self._pop("MAKE_LIST missing value") for _ in range(n)]
                    values.reverse()
                    self.stack.append(values)

                elif op == "LIST_GET":
                    index = self._pop("LIST_GET missing index")
                    obj = self._pop("LIST_GET missing object")
                    self.stack.append(self._index_get(obj, index, ins.line))

                elif op == "LIST_SET":
                    value = self._pop("LIST_SET missing value")
                    index = self._pop("LIST_SET missing index")
                    obj = self._pop("LIST_SET missing object")
                    self._index_set(obj, index, value, ins.line)

                elif op in {"ADD", "SUB", "MUL", "DIV", "MOD"}:
                    b = self._pop("Binary op missing rhs")
                    a = self._pop("Binary op missing lhs")
                    self.stack.append(self._binary_math(op, a, b, ins.line))

                elif op in {"EQ", "NE", "LT", "LE", "GT", "GE"}:
                    b = self._pop("Comparison missing rhs")
                    a = self._pop("Comparison missing lhs")
                    self.stack.append(self._compare(op, a, b, ins.line))

                elif op == "NOT":
                    value = self._pop("NOT on empty stack")
                    self.stack.append(not self._truthy(value))

                elif op == "NEG":
                    value = self._pop("NEG on empty stack")
                    if not self._is_number(value):
                        raise RuntimeJError(
                            f"Cannot negate non-number: {type(value).__name__}",
                            line=ins.line,
                            hint="Unary '-' only works on numbers.",
                        )
                    if isinstance(value, int):
                        self._check_int64(-value, ins.line)
                    self.stack.append(-value)

                elif op == "JMP":
                    frame.ip = int(ins.arg)

                elif op == "JMPF":
                    cond = self._pop("JMPF needs condition")
                    if not self._truthy(cond):
                        frame.ip = int(ins.arg)

                elif op == "GETATTR":
                    obj = self._pop("GETATTR needs object")
                    name = str(ins.arg)
                    self.stack.append(self._get_attr(obj, name, ins.line))

                elif op == "CALL":
                    argc = int(ins.arg)
                    args = [self._pop("CALL missing argument") for _ in range(argc)]
                    args.reverse()
                    callee = self._pop("CALL missing callee")
                    result = self.call_value(callee, args)
                    self.stack.append(result)

                elif op == "RET":
                    result = self.stack.pop() if self.stack else None
                    self.frames.pop()

                    if len(self.frames) > stop_depth:
                        self.stack.append(result)
                    else:
                        return result

                else:
                    raise RuntimeJError(f"Unknown opcode: {op}", line=ins.line)

            except RuntimeJError:
                raise
            except Exception as exc:
                raise RuntimeJError(
                    f"Runtime failure in {frame.fn.name} at op {ins.op}: {exc}",
                    line=ins.line,
                ) from exc

        return None

    def _load_name(self, name: str) -> Any:
        if self.frames and name in self.frames[-1].locals:
            return self.frames[-1].locals[name]
        if name in self.globals:
            return self.globals[name]
        raise RuntimeJError(f"Undefined name: {name}")

    def _get_attr(self, obj: Any, name: str, line: int) -> Any:
        if isinstance(obj, dict) and name in obj:
            return obj[name]

        if isinstance(obj, list):
            if name == "push":
                return NativeFn("list.push", lambda _vm, value, _obj=obj: _obj.append(value) or None)
            if name == "pop":
                def _pop_list(_vm, _obj=obj):
                    if not _obj:
                        raise RuntimeJError("Cannot pop from empty list", line=line)
                    return _obj.pop()

                return NativeFn("list.pop", _pop_list)

        if hasattr(obj, name):
            return getattr(obj, name)

        raise RuntimeJError(
            f"No attribute '{name}' on value {obj!r}",
            line=line,
        )

    def _index_get(self, obj: Any, index: Any, line: int) -> Any:
        idx = self._require_int_index(index, line)
        if isinstance(obj, (list, str)):
            if idx < 0 or idx >= len(obj):
                raise RuntimeJError(
                    f"Index out of bounds: {idx} for length {len(obj)}",
                    line=line,
                )
            return obj[idx]
        raise RuntimeJError(
            f"Indexing is only supported on lists and strings, got {type(obj).__name__}",
            line=line,
        )

    def _index_set(self, obj: Any, index: Any, value: Any, line: int) -> None:
        idx = self._require_int_index(index, line)
        if not isinstance(obj, list):
            raise RuntimeJError(
                f"Indexed assignment is only supported on lists, got {type(obj).__name__}",
                line=line,
            )
        if idx < 0 or idx >= len(obj):
            raise RuntimeJError(
                f"Index out of bounds: {idx} for length {len(obj)}",
                line=line,
            )
        obj[idx] = value

    @staticmethod
    def _require_int_index(index: Any, line: int) -> int:
        if not isinstance(index, int) or isinstance(index, bool):
            raise RuntimeJError(
                f"Index must be an integer, got {type(index).__name__}",
                line=line,
            )
        return index

    def _binary_math(self, op: str, a: Any, b: Any, line: int) -> Any:
        if op == "ADD" and (isinstance(a, str) or isinstance(b, str)):
            return str(a) + str(b)

        if not self._is_number(a) or not self._is_number(b):
            raise RuntimeJError(
                f"Arithmetic expects numbers, got {type(a).__name__} and {type(b).__name__}",
                line=line,
                hint="Only '+' supports string concatenation.",
            )

        if op == "ADD":
            result = a + b
        elif op == "SUB":
            result = a - b
        elif op == "MUL":
            result = a * b
        elif op == "DIV":
            if b == 0:
                raise RuntimeJError("Division by zero", line=line)
            result = a / b
        elif op == "MOD":
            if b == 0:
                raise RuntimeJError("Modulo by zero", line=line)
            result = a % b
        else:
            raise RuntimeJError(f"Unsupported math op: {op}", line=line)

        if isinstance(result, int) and not isinstance(result, bool):
            self._check_int64(result, line)
        return result

    def _compare(self, op: str, a: Any, b: Any, line: int) -> bool:
        if op == "EQ":
            return a == b
        if op == "NE":
            return a != b

        if not self._is_number(a) or not self._is_number(b):
            raise RuntimeJError(
                f"Cannot compare non-numeric values with {op}: {type(a).__name__}, {type(b).__name__}",
                line=line,
            )

        if op == "LT":
            return a < b
        if op == "LE":
            return a <= b
        if op == "GT":
            return a > b
        if op == "GE":
            return a >= b

        raise RuntimeJError(f"Unsupported comparison op: {op}", line=line)

    @staticmethod
    def _truthy(value: Any) -> bool:
        return not (value is None or value is False or value == 0 or value == 0.0 or value == "")

    @staticmethod
    def _is_number(value: Any) -> bool:
        return isinstance(value, (int, float)) and not isinstance(value, bool)

    @staticmethod
    def _check_int64(value: int, line: int) -> None:
        if value < I64_MIN or value > I64_MAX:
            raise RuntimeJError(
                f"int64 overflow: {value}",
                line=line,
                hint="Keep integer arithmetic within [-2^63, 2^63-1].",
            )

    def _pop(self, message: str) -> Any:
        if not self.stack:
            raise RuntimeJError(message)
        return self.stack.pop()

    def _peek(self, message: str) -> Any:
        if not self.stack:
            raise RuntimeJError(message)
        return self.stack[-1]
