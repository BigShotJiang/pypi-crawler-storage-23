"""Bytecode serialization for J# compiled programs (.jbc files)."""

from __future__ import annotations

import struct
from collections import OrderedDict
from pathlib import Path

from jsharp.values import FunctionObj

MAGIC = b"JBC1"
VERSION = 1

OPCODE_IDS = {
    "CONST": 1,
    "LOAD": 2,
    "STORE": 3,
    "POP": 4,
    "DUP": 5,
    "MAKE_LIST": 6,
    "LIST_GET": 7,
    "LIST_SET": 8,
    "ADD": 20,
    "SUB": 21,
    "MUL": 22,
    "DIV": 23,
    "MOD": 24,
    "EQ": 30,
    "NE": 31,
    "LT": 32,
    "LE": 33,
    "GT": 34,
    "GE": 35,
    "NOT": 40,
    "NEG": 41,
    "JMP": 50,
    "JMPF": 51,
    "CALL": 60,
    "RET": 61,
    "GETATTR": 70,
}


def _u16(n: int) -> bytes:
    return struct.pack("<H", n)


def _u32(n: int) -> bytes:
    return struct.pack("<I", n)


def _i32(n: int) -> bytes:
    return struct.pack("<i", n)


def _i64(n: int) -> bytes:
    return struct.pack("<q", n)


def _f64(x: float) -> bytes:
    return struct.pack("<d", x)


def _str(s: str) -> bytes:
    data = s.encode("utf-8")
    return _u32(len(data)) + data


def _gather_functions(functions: dict[str, FunctionObj]) -> list[FunctionObj]:
    ordered: "OrderedDict[str, FunctionObj]" = OrderedDict()

    def visit(fn: FunctionObj) -> None:
        if fn.name in ordered:
            return
        ordered[fn.name] = fn
        for c in fn.chunk.consts:
            if isinstance(c, FunctionObj):
                visit(c)

    for name in sorted(functions):
        visit(functions[name])

    return list(ordered.values())


def serialize_program(functions: dict[str, FunctionObj], entrypoint: str = "main") -> bytes:
    if entrypoint not in functions:
        raise ValueError(f"Entry function not found: {entrypoint}")

    all_functions = _gather_functions(functions)
    fn_index = {fn.name: i for i, fn in enumerate(all_functions)}

    out = bytearray()
    out += MAGIC
    out += _u16(VERSION)
    out += _u32(len(all_functions))
    out += _u32(fn_index[entrypoint])

    for fn in all_functions:
        out += _str(fn.name)

        out += _u32(len(fn.params))
        for p in fn.params:
            out += _str(p)

        out += _u32(len(fn.chunk.consts))
        for c in fn.chunk.consts:
            if c is None:
                out += b"\x00"
            elif c is False:
                out += b"\x01"
            elif c is True:
                out += b"\x02"
            elif isinstance(c, int):
                out += b"\x03" + _i64(c)
            elif isinstance(c, float):
                out += b"\x04" + _f64(c)
            elif isinstance(c, str):
                out += b"\x05" + _str(c)
            elif isinstance(c, FunctionObj):
                if c.name not in fn_index:
                    raise ValueError(f"Unknown function constant: {c.name}")
                out += b"\x06" + _u32(fn_index[c.name])
            else:
                raise ValueError(f"Unsupported constant type in serializer: {type(c).__name__}")

        out += _u32(len(fn.chunk.code))
        for ins in fn.chunk.code:
            op_id = OPCODE_IDS.get(ins.op)
            if op_id is None:
                raise ValueError(f"Unknown opcode for serializer: {ins.op}")
            out += struct.pack("<B", op_id)

            if ins.arg is None:
                out += b"\x00"
            elif isinstance(ins.arg, int):
                out += b"\x01" + _i32(ins.arg)
            elif isinstance(ins.arg, str):
                out += b"\x02" + _str(ins.arg)
            else:
                raise ValueError(f"Unsupported instruction arg type: {type(ins.arg).__name__}")

            out += _u32(max(0, int(ins.line or 0)))

    return bytes(out)


def write_program(path: str | Path, functions: dict[str, FunctionObj], entrypoint: str = "main") -> Path:
    p = Path(path)
    p.write_bytes(serialize_program(functions, entrypoint=entrypoint))
    return p
