# Support

## Where to Ask Questions

- Usage questions: GitHub Discussions
- Bug reports: GitHub Issues
- Security issues: see `SECURITY.md`

## What to Include

- OS and Python version
- Install method (`pip`/source)
- Minimal reproduction steps
- Error logs/traceback
