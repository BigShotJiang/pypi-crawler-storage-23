# Code of Conduct

We are committed to a welcoming and harassment-free community.

## Our Standards

- Be respectful and constructive.
- Assume good intent and discuss technical details in good faith.
- No harassment, abuse, discrimination, or doxxing.

## Enforcement

Report incidents to project maintainers via private channels listed in `SECURITY.md`.
Maintainers may remove content or contributors violating this code.
