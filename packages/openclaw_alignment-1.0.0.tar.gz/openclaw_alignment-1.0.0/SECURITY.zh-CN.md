# 安全策略

## 支持版本

- `1.0.x`：官方支持
- `<1.0.0`：尽力支持

## 漏洞上报

请使用私密方式上报：

- GitHub 私有安全通告：https://github.com/412984588/openclaw-alignment/security/advisories/new
- 安全邮箱：security@openclaw-alignment.example

发布前请将上述占位邮箱替换为真实安全联系方式。

**不要**在公开 issue 中披露未修复漏洞。

## 响应目标

- 首次响应：72 小时内
- 分级结论：7 天内
- 修复时限：按严重级别与影响范围确定
