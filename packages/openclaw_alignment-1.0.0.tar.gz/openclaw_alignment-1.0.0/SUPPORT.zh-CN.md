# 支持与反馈

## 提问渠道

- 使用问题：GitHub Discussions
- 缺陷反馈：GitHub Issues
- 安全问题：见 `SECURITY.zh-CN.md`

## 反馈建议包含

- 操作系统与 Python 版本
- 安装方式（`pip` / 源码）
- 最小复现步骤
- 错误日志与 traceback
