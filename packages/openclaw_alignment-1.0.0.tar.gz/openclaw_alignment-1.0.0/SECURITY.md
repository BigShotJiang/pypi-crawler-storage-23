# Security Policy

## Supported Versions

- `1.0.x`: supported
- `<1.0.0`: best effort only

## Reporting a Vulnerability

Please report vulnerabilities privately:

- GitHub private advisory: https://github.com/412984588/openclaw-alignment/security/advisories/new
- Security email: security@openclaw-alignment.example

Before public release, maintainers must replace the placeholder email with the real security contact.

Do **not** open public issues for unpatched vulnerabilities.

## Response Targets

- Initial response: within 72 hours
- Triage decision: within 7 days
- Patch target: based on severity and impact
