# Open Source Release Scope (v1.0.0)

Included:

- Core RL engine and optional phase3 modules
- Packaging and cross-platform installation
- CI/CD release workflows
- Security/community governance docs
- Bilingual project documentation

Excluded:

- Large architecture rewrites
- Non-release-critical feature expansions
