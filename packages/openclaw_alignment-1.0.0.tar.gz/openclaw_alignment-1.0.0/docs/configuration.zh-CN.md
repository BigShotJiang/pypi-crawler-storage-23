# 配置说明

默认配置路径：

- Linux/macOS：`$XDG_CONFIG_HOME/openclaw-alignment/config.json`（回退 `~/.config/...`）
- Windows：`%APPDATA%/openclaw-alignment/config.json`
- 同时兼容 legacy 路径用于向后兼容。

示例配置见 `config/config.example.json`。
