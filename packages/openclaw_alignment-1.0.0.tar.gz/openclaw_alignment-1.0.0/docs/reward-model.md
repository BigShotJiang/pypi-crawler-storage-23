# Reward Model

The reward engine combines four dimensions:

1. Objective metrics (coverage, quality, bug count, task time)
2. User behavior signals (acceptance, adoption, rewrite)
3. Explicit feedback (rating, feedback count)
4. Behavior patterns (agent/workflow preference)

Weights are normalized and can be adapted by phase and negative feedback events.
