# Configuration

Default path strategy:

- Linux/macOS config: `$XDG_CONFIG_HOME/openclaw-alignment/config.json` (fallback `~/.config/...`)
- Windows config: `%APPDATA%/openclaw-alignment/config.json`
- Legacy path is still supported for backward compatibility.

Example config is provided at `config/config.example.json`.
