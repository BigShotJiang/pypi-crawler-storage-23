import time
import random
import shutil
import sys
import re
from colorama import Fore, Style

def strip_ansi(text):
    return re.sub(r'\033\[[0-9;]*m', '', text)

POP_COLORS = [
    f"{Style.BRIGHT}{Fore.LIGHTCYAN_EX}", f"{Style.BRIGHT}{Fore.LIGHTMAGENTA_EX}", 
    f"{Style.BRIGHT}{Fore.LIGHTYELLOW_EX}", f"{Style.BRIGHT}{Fore.WHITE}"
]
RAINBOW = [
    Fore.RED, Fore.YELLOW, Fore.GREEN, Fore.CYAN, Fore.BLUE, Fore.MAGENTA,
    Fore.LIGHTRED_EX, Fore.LIGHTGREEN_EX, Fore.LIGHTYELLOW_EX, Fore.LIGHTCYAN_EX
]

def assemble_resume(target_text_block, duration=4.5):
    cols, rows = shutil.get_terminal_size()
    target_lines = target_text_block.split('\n')
    clean_targets = [strip_ansi(line) for line in target_lines]
    start_time = time.time()
    print("\033[?25l", end="")
    chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@#$%&*<>/\\!?"
    
    try:
        while True:
            elapsed = time.time() - start_time
            progress = min(elapsed / duration, 1.0)
            sys.stdout.write("\033[H")
            output = []
            for r_idx, target_line in enumerate(clean_targets):
                if r_idx >= rows - 2: break
                display_line = ""
                for c_idx in range(cols):
                    if c_idx < len(target_line) and target_line[c_idx] != " ":
                        if random.random() < progress:
                            display_line += f"{Style.BRIGHT}{target_line[c_idx]}{Style.RESET_ALL}"
                        else:
                            color = random.choice(POP_COLORS) if random.random() > 0.90 else random.choice(RAINBOW)
                            display_line += f"{color}{random.choice(chars)}{Style.RESET_ALL}"
                    else:
                        if progress < 0.8 and random.random() > (0.98 + (progress * 0.015)):
                            color = random.choice(POP_COLORS) if random.random() > 0.8 else random.choice(RAINBOW)
                            display_line += f"{color}{random.choice(chars)}{Style.RESET_ALL}"
                        else:
                            display_line += " "
                output.append(display_line)
            sys.stdout.write("\n".join(output))
            sys.stdout.flush()
            if progress >= 1.0:
                sys.stdout.write("\033[H\033[J")
                sys.stdout.write(target_text_block)
                sys.stdout.flush()
                break
            time.sleep(0.04)
    finally:
        print("\033[?25h")
