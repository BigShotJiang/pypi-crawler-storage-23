import os
import shutil
import time
import textwrap
from .renderer import enable_windows_ansi, clear_screen
from .matrix import assemble_resume
from .resume_data import RESUME_DATA
from colorama import Fore, Style

def build_wrapped_resume():
    cols, _ = shutil.get_terminal_size()
    width = min(cols - 4, 80)
    d = RESUME_DATA
    c, y, g, w = Fore.CYAN, Fore.YELLOW, Fore.GREEN, Fore.WHITE
    rs, b = Style.RESET_ALL, Style.BRIGHT
    lines = [f"{c}{b}{'═' * width}{rs}"]
    lines.append(f"{c}{b}{d['HEADER']['name'].center(width)}{rs}")
    lines.append(f"{w}{d['HEADER']['title'].center(width)}{rs}")
    lines.append(f"{w}{d['HEADER']['contact'].center(width)}{rs}")
    lines.append(f"{w}{d['HEADER']['links'].center(width)}{rs}")
    lines.append(f"{c}{'─' * width}{rs}")
    lines.append(f"\n{y}{b}[ PROFESSIONAL SUMMARY ]{rs}")
    wrapper = textwrap.TextWrapper(width=width, initial_indent="  ", subsequent_indent="  ")
    lines.extend([f"{w}{l}{rs}" for l in wrapper.wrap(d['PROFESSIONAL SUMMARY'])])
    lines.append(f"\n{y}{b}[ TECHNICAL SKILLS ]{rs}")
    for k, v in d['TECHNICAL SKILLS'].items():
        skill_wrapper = textwrap.TextWrapper(width=width, initial_indent=f"  {g}• {k}{rs}: ", subsequent_indent="    ")
        lines.extend([f"{w}{l}{rs}" for l in skill_wrapper.wrap(v)])
    lines.append(f"\n{y}{b}[ KEY PROJECTS ]{rs}")
    for p in d['PROJECTS']:
        lines.append(f"  {c}{b}{p['name']}{rs} {g}({p['tech']}){rs}")
        p_wrapper = textwrap.TextWrapper(width=width, initial_indent="    ", subsequent_indent="    ")
        lines.extend([f"{w}{l}{rs}" for l in p_wrapper.wrap(p['impact'])])
    lines.append(f"\n{y}{b}[ EDUCATION ]{rs}")
    for edu in d['EDUCATION']:
        lines.append(f"  {g}• {edu['school']}{rs} | {w}{edu['degree']}{rs}")
    lines.append(f"\n{c}{b}{'═' * width}{rs}")
    return "\n".join(lines)

def main():
    enable_windows_ansi()
    clear_screen()
    resume_string = build_wrapped_resume()
    assemble_resume(resume_string, duration=4.0)
    print(f"\n{Fore.MAGENTA}[SYSTEM] Digital reconstruction successful.{Style.RESET_ALL}")
    choice = input(f"\nDownload original PDF resume? (y/n): ").lower()
    if choice == 'y':
        pdf_name = "vishwapanchal.pdf"
        source = os.path.join(os.path.dirname(__file__), pdf_name)
        if os.path.exists(source):
            dest = os.path.join(os.getcwd(), "Vishwa_Panchal_Resume.pdf")
            shutil.copy(source, dest)
            print(f"{Fore.GREEN}[SUCCESS] Saved to: {dest}{Style.RESET_ALL}")
            if os.name == 'nt': os.startfile(dest)
        else:
            print(f"{Fore.RED}[ERROR] PDF source not found inside package.{Style.RESET_ALL}")

if __name__ == "__main__":
    main()
