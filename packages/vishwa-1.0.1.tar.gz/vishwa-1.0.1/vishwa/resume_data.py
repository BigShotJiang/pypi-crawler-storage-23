RESUME_DATA = {
    "HEADER": {
        "name": "VISHWA PANCHAL",
        "title": "DevOps Engineer & Backend Developer",
        "contact": "+91 8277665467 | thevishwapanchal@gmail.com",
        "links": "LinkedIn: vishwapanchal | GitHub: vishwapanchal"
    },
    "PROFESSIONAL SUMMARY": "AWS Certified Solutions Architect - Associate specializing in cloud infrastructure (EC2, S3, Lambda, RDS, IAM), CI/CD automation, and microservices architecture. Expert in Docker, Kubernetes, Infrastructure as Code (Terraform, Ansible), and Linux system administration. Strong foundation in Python, FastAPI, and database management (PostgreSQL, MongoDB).",
    "EDUCATION": [
        {"school": "R. V. College of Engineering", "degree": "B.E. Information Science (2024 - 2028)"},
        {"school": "Government Polytechnic", "degree": "Diploma CSE (CGPA: 9.73/10 | 2021 - 2024)"}
    ],
    "TECHNICAL SKILLS": {
        "Cloud & DevOps": "AWS (EC2, S3, Lambda, RDS, IAM, CloudWatch), Docker, Kubernetes, Jenkins, GitHub Actions, Terraform, Ansible, GitOps, Helm, Azure DevOps",
        "Programming": "Python (Advanced), Bash/Shell Scripting, SQL, Java, JavaScript, PowerShell",
        "Backend": "FastAPI, REST APIs, GraphQL, Microservices, WebSockets, API Gateway, Serverless",
        "Databases": "PostgreSQL, MongoDB, MySQL, Redis, FAISS Vector DB, Query Optimization",
        "Monitoring": "Prometheus, Grafana, CloudWatch, ELK Stack"
    },
    "PROJECTS": [
        {
            "name": "Cloud-Hosted EL Management Platform",
            "tech": "AWS, FastAPI, PostgreSQL, Docker",
            "impact": "Deployed backend achieving 99.9% uptime. Integrated FAISS Vector DB for automated plagiarism detection, reducing manual review time by 80%."
        },
        {
            "name": "Gram Sahayak: Digital Governance",
            "tech": "FastAPI, MongoDB, WebSockets",
            "impact": "Architected microservices for 5,000+ concurrent users. Built real-time tracking and AI chatbot, reducing response time by 90%."
        }
    ]
}
