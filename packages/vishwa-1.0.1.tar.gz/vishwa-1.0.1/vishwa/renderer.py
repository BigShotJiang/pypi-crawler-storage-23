import os
import sys
from colorama import init, Fore, Style

def enable_windows_ansi():
    """Initializes colorama to handle ANSI codes on all platforms."""
    # strip=False ensures codes aren't removed on Windows Terminal/Linux
    init(autoreset=True, strip=False)

def clear_screen():
    """Clears the terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')
