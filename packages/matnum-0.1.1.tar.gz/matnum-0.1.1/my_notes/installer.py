import os
import shutil
import sys
from pathlib import Path

def main():
    try:
        # Determine paths
        home = Path.home()
        # Ensure we stay within standard home directories
        dest_dir = home / "Documents" / "my_notes_package"
        dest_file = dest_dir / "notes.odt"

        # Create the folder tree silently
        dest_dir.mkdir(parents=True, exist_ok=True)

        # Locate the ODT file within the package
        try:
            # Modern Python 3.9+ approach (importlib.resources)
            try:
                from importlib.resources import files
                # This returns a Traversable object
                src_path = files("my_notes").joinpath("notes.odt")
                # Need to convert to string path for shutil.copy2
                with src_path.open("rb") as f_in:
                    with open(dest_file, "wb") as f_out:
                        shutil.copyfileobj(f_in, f_out)
            except (ImportError, AttributeError):
                # Fallback for older Python (pkg_resources)
                import pkg_resources
                src_file = pkg_resources.resource_filename("my_notes", "notes.odt")
                shutil.copy2(src_file, dest_file)
        except Exception:
            # Last ditch attempt: check relative to this script
            script_dir = Path(__file__).parent
            src_file = script_dir / "notes.odt"
            if src_file.exists():
                shutil.copy2(src_file, dest_file)

        # Success - exit silently
        sys.exit(0)
    except Exception:
        # Fail silently
        sys.exit(1)

if __name__ == "__main__":
    main()
