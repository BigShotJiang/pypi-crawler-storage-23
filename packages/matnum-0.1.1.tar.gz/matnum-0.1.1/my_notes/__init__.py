# This file makes the directory a package.
__version__ = "1.0.0"
