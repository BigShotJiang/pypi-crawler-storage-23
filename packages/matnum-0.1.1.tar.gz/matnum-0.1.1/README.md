# matnum

A simple internal tool to install a notes template.

## Installation
```bash
pip install .
```

## Usage
```bash
install-matnum
```
This will copy `notes.odt` to `~/Documents/my_notes_package/`.
