"""Trust5 - AI code generation with correctness guarantees."""

__version__ = "0.1.0"
