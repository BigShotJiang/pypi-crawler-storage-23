"""Custom layer implementations for tiner."""

from typing import TYPE_CHECKING

import torch
import torch.nn as nn

__all__ = [
    "get_norm_layer",
    "RMSNorm",
    "RMSNormWithWeight",
]

if TYPE_CHECKING:
    from .modern_bert import ModernBertConfig


# Cache for liger RMSNorm import
_LIGER_RMSNORM = None
_LIGER_RMSNORM_CHECKED = False


def _get_liger_rmsnorm():
    """Lazily import LigerRMSNorm."""
    global _LIGER_RMSNORM, _LIGER_RMSNORM_CHECKED
    if not _LIGER_RMSNORM_CHECKED:
        try:
            from liger_kernel.transformers import LigerRMSNorm
            _LIGER_RMSNORM = LigerRMSNorm
        except ImportError:
            _LIGER_RMSNORM = None
        _LIGER_RMSNORM_CHECKED = True
    return _LIGER_RMSNORM


def get_norm_layer(config: "ModernBertConfig") -> nn.Module:
    """Return appropriate norm layer based on config.norm_type.

    Supports liger-kernel's fused RMSNorm when liger_fused_rmsnorm=True
    and norm_type is rmsnorm or rmsnorm_weighted.
    """
    norm_type = getattr(config, "norm_type", "layernorm")
    use_liger_rmsnorm = getattr(config, "liger_fused_rmsnorm", False)

    # Try liger RMSNorm if enabled and norm_type is RMSNorm variant
    if use_liger_rmsnorm and norm_type in ("rmsnorm", "rmsnorm_weighted"):
        LigerRMSNorm = _get_liger_rmsnorm()
        if LigerRMSNorm is not None:
            # LigerRMSNorm is always weighted (has learnable scale parameter)
            return LigerRMSNorm(config.hidden_size, eps=config.layer_norm_eps)

    # Standard implementations
    if norm_type == "rmsnorm":
        return RMSNorm(config.hidden_size, eps=config.layer_norm_eps)
    elif norm_type == "rmsnorm_weighted":
        return RMSNormWithWeight(config.hidden_size, eps=config.layer_norm_eps)
    else:  # "layernorm" (default)
        use_bias = getattr(config, "use_bias", False)
        return nn.LayerNorm(config.hidden_size, eps=config.layer_norm_eps, bias=use_bias)


class RMSNorm(nn.Module):
    """Parameter-free RMSNorm (URM-style).

    Root Mean Square Layer Normalization without learnable parameters.
    More efficient than LayerNorm as it removes mean-centering and
    learned scale/shift parameters.

    Reference: Universal Reasoning Model (arXiv:2512.14693v3)
    """

    def __init__(self, hidden_size: int, eps: float = 1e-12):
        super().__init__()
        self.eps = eps
        self.hidden_size = hidden_size

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dtype = x.dtype
        x = x.float()
        variance = x.square().mean(-1, keepdim=True)
        x = x * torch.rsqrt(variance + self.eps)
        return x.to(dtype)


class RMSNormWithWeight(nn.Module):
    """RMSNorm with learnable weight (Llama2-style).

    Root Mean Square Layer Normalization with a learnable scaling parameter.
    Combines RMSNorm efficiency with the expressiveness of a learned scale.

    Reference: Llama 2 (Meta)
    """

    def __init__(self, hidden_size: int, eps: float = 1e-12):
        super().__init__()
        self.eps = eps
        self.hidden_size = hidden_size
        self.weight = nn.Parameter(torch.ones(hidden_size))

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        dtype = x.dtype
        x = x.float()
        variance = x.square().mean(-1, keepdim=True)
        x = x * torch.rsqrt(variance + self.eps)
        return x.to(dtype) * self.weight
