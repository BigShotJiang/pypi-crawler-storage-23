"""Utilities for padding and unpadding batches for efficient attention.

This module provides functions to remove padding from batched sequences before
attention computation and restore it afterward. This optimization eliminates
wasted computation on padding tokens.

Adapted from MosaicBERT/ModernBERT implementation.
Original source: https://github.com/HazyResearch/flash-attention/blob/main/flash_attn/bert_padding.py
"""

from typing import Tuple, cast

import torch

__all__ = [
    "IndexFirstAxis",
    "IndexPutFirstAxis",
    "index_first_axis",
    "index_put_first_axis",
    "unpad_input",
    "unpad_input_only",
    "pad_input",
]
import torch.nn.functional as F
from einops import rearrange, repeat


class IndexFirstAxis(torch.autograd.Function):
    """Custom autograd function for efficient indexing along the first axis.

    Uses torch.gather which is faster than direct indexing for this use case.
    """

    @staticmethod
    def forward(ctx, input: torch.Tensor, indices: torch.Tensor) -> torch.Tensor:
        """Get values of `input` at `indices` along the first axis.

        Arguments:
            ctx: Autograd context object.
            input: (b, ...) 2+ dimensional tensor.
            indices: (num_idx,) 1D tensor of indices.

        Returns:
            Tensor of shape (num_idx, ...) with selected values.
        """
        ctx.save_for_backward(indices)
        assert input.ndim >= 2
        ctx.first_axis_dim, other_shape = input.shape[0], input.shape[1:]
        second_dim = other_shape.numel()
        # torch.gather is faster than direct indexing
        return torch.gather(
            rearrange(input, "b ... -> b (...)"),
            0,
            repeat(indices, "z -> z d", d=second_dim),
        ).reshape(-1, *other_shape)

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> Tuple[torch.Tensor, None]:
        (indices,) = ctx.saved_tensors
        assert grad_output.ndim >= 2
        other_shape = grad_output.shape[1:]
        grad_output = rearrange(grad_output, "b ... -> b (...)")
        grad_input = torch.zeros(
            [ctx.first_axis_dim, grad_output.shape[1]],
            device=grad_output.device,
            dtype=grad_output.dtype,
        )
        # torch.scatter is faster than direct indexing
        grad_input.scatter_(
            0, repeat(indices, "z -> z d", d=grad_output.shape[1]), grad_output
        )
        return grad_input.reshape(ctx.first_axis_dim, *other_shape), None


index_first_axis = IndexFirstAxis.apply


class IndexPutFirstAxis(torch.autograd.Function):
    """Custom autograd function for efficient scatter along the first axis."""

    @staticmethod
    def forward(
        ctx, values: torch.Tensor, indices: torch.Tensor, first_axis_dim: int
    ) -> torch.Tensor:
        """Put values at indices in a zero tensor.

        Arguments:
            ctx: Autograd context object.
            values: (num_idx, ...) tensor of values to scatter.
            indices: (num_idx,) 1D tensor of indices.
            first_axis_dim: Size of the first dimension in output.

        Returns:
            Tensor of shape (first_axis_dim, ...) with values at indices.
        """
        ctx.save_for_backward(indices)
        assert indices.ndim == 1
        assert values.ndim >= 2
        output = torch.zeros(
            first_axis_dim, *values.shape[1:], device=values.device, dtype=values.dtype
        )
        output[indices] = values
        return output

    @staticmethod
    def backward(ctx, grad_output: torch.Tensor) -> Tuple[torch.Tensor, None, None]:
        (indices,) = ctx.saved_tensors
        grad_values = grad_output[indices]
        return grad_values, None, None


index_put_first_axis = IndexPutFirstAxis.apply


def unpad_input(
    hidden_states: torch.Tensor,
    attention_mask: torch.Tensor,
) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, int]:
    """Remove padding from input sequences.

    This function extracts only the valid (non-padding) tokens from batched
    sequences, returning the information needed to later restore padding.

    Arguments:
        hidden_states: (batch, seqlen, ...) tensor of hidden states.
        attention_mask: (batch, seqlen) tensor where 1 = valid, 0 = padding.

    Returns:
        hidden_states: (total_nnz, ...) unpadded tensor.
        indices: (total_nnz,) indices for restoring padding.
        cu_seqlens: (batch + 1,) cumulative sequence lengths for flash attention.
        max_seqlen_in_batch: Maximum sequence length in the batch.

    Example:
        >>> hidden = torch.randn(2, 4, 64)  # batch=2, seq=4, dim=64
        >>> mask = torch.tensor([[1, 1, 0, 0], [1, 1, 1, 0]])  # lengths 2 and 3
        >>> unpadded, indices, cu_seqlens, max_len = unpad_input(hidden, mask)
        >>> unpadded.shape  # (5, 64) - 2 + 3 valid tokens
        >>> cu_seqlens  # tensor([0, 2, 5])
        >>> max_len  # 3
    """
    seqlens_in_batch = attention_mask.sum(dim=-1, dtype=torch.int32)
    indices = torch.nonzero(attention_mask.flatten(), as_tuple=False).flatten()
    max_seqlen_in_batch = int(seqlens_in_batch.max().item())
    cu_seqlens = F.pad(torch.cumsum(seqlens_in_batch, dim=0, dtype=torch.int32), (1, 0))
    # Use custom indexing which is faster than bool mask indexing
    hidden_states = cast(
        torch.Tensor,
        index_first_axis(rearrange(hidden_states, "b s ... -> (b s) ..."), indices),
    )
    return hidden_states, indices, cu_seqlens, max_seqlen_in_batch


def unpad_input_only(
    hidden_states: torch.Tensor,
    attention_mask: torch.Tensor,
) -> torch.Tensor:
    """Like unpad_input, but only return the unpadded tensor.

    Slightly less overhead when you don't need indices/cu_seqlens.

    Arguments:
        hidden_states: (batch, seqlen, ...) tensor of hidden states.
        attention_mask: (batch, seqlen) tensor where 1 = valid, 0 = padding.

    Returns:
        hidden_states: (total_nnz, ...) unpadded tensor.
    """
    indices = torch.nonzero(attention_mask.flatten(), as_tuple=False).flatten()
    rearranged = rearrange(hidden_states, "b s ... -> (b s) ...")
    return index_first_axis(rearranged, indices)


def pad_input(
    hidden_states: torch.Tensor,
    indices: torch.Tensor,
    batch: int,
    seqlen: int,
) -> torch.Tensor:
    """Add padding back to sequences.

    Restores the original batched shape by placing unpadded tokens at their
    original positions and filling the rest with zeros.

    Arguments:
        hidden_states: (total_nnz, ...) unpadded tensor.
        indices: (total_nnz,) indices from unpad_input.
        batch: Original batch size.
        seqlen: Original sequence length.

    Returns:
        hidden_states: (batch, seqlen, ...) padded tensor.

    Example:
        >>> # After processing unpadded tensor
        >>> padded = pad_input(processed, indices, batch=2, seqlen=4)
        >>> padded.shape  # (2, 4, 64)
    """
    output = index_put_first_axis(hidden_states, indices, batch * seqlen)
    return rearrange(output, "(b s) ... -> b s ...", b=batch)
