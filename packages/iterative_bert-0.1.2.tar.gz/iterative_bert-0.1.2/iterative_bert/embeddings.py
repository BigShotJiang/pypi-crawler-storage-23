"""Embeddings layers for TiNER models.

This module provides embeddings layers compatible with BERT but without
position embeddings (for use with RoPE).
"""

from typing import Optional

import torch
import torch.nn as nn

__all__ = ["BertEmbeddingsWithoutPosition"]
from torch import Tensor
from transformers import BertConfig

from .layers import get_norm_layer


class BertEmbeddingsWithoutPosition(nn.Module):
    """BERT-style embeddings without position embeddings.

    This is designed for use with Rotary Position Embeddings (RoPE),
    where position information is injected in the attention mechanism
    rather than the embedding layer.

    Compatible with the BertEmbeddings interface but ignores position_ids.

    Args:
        config: BERT configuration with vocab_size, hidden_size, etc.
    """

    def __init__(self, config: BertConfig):
        super().__init__()
        self.config = config

        # Word embeddings
        self.word_embeddings = nn.Embedding(
            config.vocab_size,
            config.hidden_size,
            padding_idx=getattr(config, "pad_token_id", 0),
        )

        # Token type embeddings (segment embeddings)
        self.token_type_embeddings = nn.Embedding(
            config.type_vocab_size,
            config.hidden_size,
        )

        # Norm and dropout
        self.LayerNorm = get_norm_layer(config)
        self.dropout = nn.Dropout(config.hidden_dropout_prob)

        # Register buffer for default token type ids (zeros)
        # This is used when token_type_ids is not provided
        self.register_buffer(
            "token_type_ids",
            torch.zeros((1, 512), dtype=torch.long),
            persistent=False,
        )

    def forward(
        self,
        input_ids: Tensor,
        token_type_ids: Optional[Tensor] = None,
        position_ids: Optional[Tensor] = None,
        inputs_embeds: Optional[Tensor] = None,
        past_key_values_length: int = 0,
    ) -> Tensor:
        """Forward pass.

        Args:
            input_ids: Token IDs (batch, seq_len)
            token_type_ids: Segment IDs (batch, seq_len), defaults to zeros
            position_ids: Ignored (RoPE handles positions in attention)
            inputs_embeds: Optional pre-computed embeddings
            past_key_values_length: For compatibility, ignored

        Returns:
            Embeddings tensor (batch, seq_len, hidden_size)
        """
        if input_ids is not None:
            input_shape = input_ids.size()
            device = input_ids.device
        else:
            assert inputs_embeds is not None
            input_shape = inputs_embeds.size()[:-1]
            device = inputs_embeds.device

        seq_length = input_shape[1]

        # Default token type ids to zeros
        if token_type_ids is None:
            # Always create zeros directly for the actual sequence length
            # This avoids issues with cached buffer size limits
            token_type_ids = torch.zeros(input_shape, dtype=torch.long, device=device)

        # Get word embeddings
        if inputs_embeds is None:
            inputs_embeds = self.word_embeddings(input_ids)

        # Get token type embeddings
        token_type_embeddings = self.token_type_embeddings(token_type_ids)

        # Combine (no position embeddings - RoPE handles this)
        embeddings = inputs_embeds + token_type_embeddings

        # Layer norm and dropout
        embeddings = self.LayerNorm(embeddings)
        embeddings = self.dropout(embeddings)

        return embeddings

    def resize_token_embeddings(self, new_num_tokens: int) -> nn.Embedding:
        """Resize the word embeddings.

        Args:
            new_num_tokens: New vocabulary size

        Returns:
            The resized embedding layer
        """
        old_embeddings = self.word_embeddings
        old_num_tokens, embedding_dim = old_embeddings.weight.shape

        if new_num_tokens == old_num_tokens:
            return old_embeddings

        # Create new embeddings
        new_embeddings = nn.Embedding(
            new_num_tokens,
            embedding_dim,
            padding_idx=old_embeddings.padding_idx,
        )

        # Copy existing weights
        num_to_copy = min(old_num_tokens, new_num_tokens)
        new_embeddings.weight.data[:num_to_copy] = old_embeddings.weight.data[:num_to_copy]

        # Initialize new tokens with mean of existing (if expanding)
        if new_num_tokens > old_num_tokens:
            new_embeddings.weight.data[old_num_tokens:] = old_embeddings.weight.data.mean(
                dim=0, keepdim=True
            )

        self.word_embeddings = new_embeddings
        return new_embeddings
