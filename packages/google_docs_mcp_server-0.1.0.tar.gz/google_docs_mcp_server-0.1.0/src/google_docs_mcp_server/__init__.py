"""Google Docs MCP server with full tab support."""
