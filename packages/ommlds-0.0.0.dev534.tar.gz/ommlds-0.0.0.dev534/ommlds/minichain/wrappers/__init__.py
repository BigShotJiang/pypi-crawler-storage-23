"""
TODO:
 - ratelimit
 - option - output injection / removal
 - 'switch'
 - ** reflection passthrough **
"""
