# simple-finance

## Install
```bash
pip install simple-finance
