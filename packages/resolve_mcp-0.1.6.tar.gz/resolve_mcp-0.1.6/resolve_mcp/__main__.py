"""Entry point: python -m resolve_mcp"""

from . import mcp

mcp.run()
