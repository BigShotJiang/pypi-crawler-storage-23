"""Provider adapter helpers that route tool and LLM calls through SDK context."""

from __future__ import annotations

from collections.abc import Awaitable, Callable, Mapping, Sequence
from typing import Any, Protocol, TypeVar, cast

from trajectly.sdk.context import get_context

T = TypeVar("T")


class SDKContextLike(Protocol):
    """Minimal protocol required by adapter helpers."""

    def invoke_tool(
        self,
        name: str,
        fn: Callable[..., T],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> T:
        """Invoke a synchronous tool call through SDK context hooks."""
        ...

    def invoke_llm(
        self,
        provider: str,
        model: str,
        fn: Callable[..., T],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> T:
        """Invoke a synchronous model call through SDK context hooks."""
        ...

    async def invoke_tool_async(
        self,
        name: str,
        fn: Callable[..., T] | Callable[..., Awaitable[T]],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> T:
        """Invoke an asynchronous tool call through SDK context hooks."""
        ...

    async def invoke_llm_async(
        self,
        provider: str,
        model: str,
        fn: Callable[..., T] | Callable[..., Awaitable[T]],
        args: tuple[Any, ...],
        kwargs: dict[str, Any],
    ) -> T:
        """Invoke an asynchronous model call through SDK context hooks."""
        ...


def _resolve_context(context: SDKContextLike | None) -> SDKContextLike:
    """Return caller-provided context or the process-global SDK context."""
    if context is not None:
        return context
    return get_context()


def _as_mapping(value: Any) -> Mapping[str, Any] | None:
    """Convert mapping-like objects to ``Mapping[str, Any]`` when possible."""
    if isinstance(value, Mapping):
        return cast(Mapping[str, Any], value)
    if hasattr(value, "__dict__"):
        raw = cast(dict[str, Any], vars(value))
        return raw
    return None


def _as_usage_dict(value: Any) -> dict[str, Any]:
    """Normalize arbitrary usage payloads to a plain dictionary."""
    mapping = _as_mapping(value)
    if mapping is None:
        return {}
    return {str(key): mapping[key] for key in mapping}


def _lookup(value: Any, key: str, default: Any = None) -> Any:
    """Read key from mapping/object with a shared default path."""
    mapping = _as_mapping(value)
    if mapping is not None:
        return mapping.get(key, default)
    return getattr(value, key, default)


def _resolve_nested_attribute(root: Any, segments: tuple[str, ...], label: str) -> Any:
    """Resolve nested object attributes and raise a clear adapter error."""
    current = root
    for segment in segments:
        if not hasattr(current, segment):
            joined = ".".join(segments)
            raise ValueError(f"{label} client must expose `{joined}`")
        current = getattr(current, segment)
    return current


def _extract_openai_response(result: Any) -> tuple[Any, dict[str, Any]]:
    """Extract normalized response text and usage from OpenAI SDK payloads."""
    usage = _as_usage_dict(_lookup(result, "usage", {}))
    choices = _lookup(result, "choices", [])

    if isinstance(choices, Sequence) and not isinstance(choices, (str, bytes)) and choices:
        first = choices[0]
        message = _lookup(first, "message")
        if message is not None:
            content = _lookup(message, "content")
            if content is not None:
                return content, usage
        text = _lookup(first, "text")
        if text is not None:
            return text, usage

    response = _lookup(result, "response", result)
    return response, usage


def _extract_anthropic_response(result: Any) -> tuple[Any, dict[str, Any]]:
    """Extract normalized response text and usage from Anthropic payloads."""
    usage = _as_usage_dict(_lookup(result, "usage", {}))
    content_blocks = _lookup(result, "content", [])
    if isinstance(content_blocks, Sequence) and not isinstance(content_blocks, (str, bytes)):
        texts = []
        for block in content_blocks:
            text = _lookup(block, "text")
            if text is None:
                continue
            texts.append(str(text))
        if texts:
            return "\n".join(texts), usage

    response = _lookup(result, "response", result)
    return response, usage


def _extract_gemini_response(result: Any) -> tuple[Any, dict[str, Any]]:
    """Extract normalized response text and usage from Gemini payloads."""
    usage_source = _lookup(result, "usage_metadata", _lookup(result, "usage", {}))
    usage = _as_usage_dict(usage_source)

    text = _lookup(result, "text")
    if text is not None:
        return text, usage

    candidates = _lookup(result, "candidates", [])
    if isinstance(candidates, Sequence) and not isinstance(candidates, (str, bytes)):
        candidate_texts: list[str] = []
        for candidate in candidates:
            output_text = _lookup(candidate, "output_text")
            if output_text is not None:
                candidate_texts.append(str(output_text))
                continue

            content = _lookup(candidate, "content")
            parts = _lookup(content, "parts", [])
            if not isinstance(parts, Sequence) or isinstance(parts, (str, bytes)):
                continue
            part_texts = []
            for part in parts:
                part_text = _lookup(part, "text")
                if part_text is None:
                    continue
                part_texts.append(str(part_text))
            if part_texts:
                candidate_texts.append("".join(part_texts))
        if candidate_texts:
            return "\n".join(candidate_texts), usage

    response = _lookup(result, "response", result)
    return response, usage


def _extract_llamaindex_response(result: Any) -> tuple[Any, dict[str, Any]]:
    """Extract normalized response text and usage from LlamaIndex payloads."""
    metadata = _lookup(result, "metadata", {})
    usage_source = _lookup(result, "usage", metadata)
    usage = _as_usage_dict(usage_source)
    response = _lookup(result, "response", result)
    return response, usage


def _extract_crewai_result(result: Any) -> tuple[Any, dict[str, Any]]:
    """Extract normalized response text and usage from CrewAI payloads."""
    usage_source = _lookup(result, "usage", _lookup(result, "token_usage", {}))
    usage = _as_usage_dict(usage_source)

    mapping = _as_mapping(result)
    if mapping is not None:
        if "output" in mapping:
            return mapping["output"], usage
        if "response" in mapping:
            return mapping["response"], usage
        if "text" in mapping:
            return mapping["text"], usage

    response = _lookup(result, "output", _lookup(result, "response", result))
    return response, usage


def _extract_autogen_result(result: Any) -> tuple[Any, dict[str, Any]]:
    """Extract normalized response text and usage from AutoGen payloads."""
    usage_source = _lookup(result, "usage", _lookup(result, "token_usage", {}))
    usage = _as_usage_dict(usage_source)

    mapping = _as_mapping(result)
    if mapping is not None:
        if "response" in mapping:
            return mapping["response"], usage
        if "content" in mapping:
            return mapping["content"], usage
        if "text" in mapping:
            return mapping["text"], usage
        if "messages" in mapping:
            messages = mapping["messages"]
            if isinstance(messages, Sequence) and not isinstance(messages, (str, bytes)) and messages:
                last = messages[-1]
                content = _lookup(last, "content")
                if content is not None:
                    return content, usage

    response = _lookup(result, "response", _lookup(result, "content", result))
    return response, usage


def _extract_dspy_result(result: Any) -> tuple[Any, dict[str, Any]]:
    """Extract normalized response text and usage from DSPy payloads."""
    usage_source = _lookup(result, "usage", _lookup(result, "token_usage", {}))
    usage = _as_usage_dict(usage_source)

    mapping = _as_mapping(result)
    if mapping is not None:
        if "answer" in mapping:
            return mapping["answer"], usage
        if "response" in mapping:
            return mapping["response"], usage
        if "text" in mapping:
            return mapping["text"], usage

    response = _lookup(result, "answer", _lookup(result, "response", result))
    return response, usage


def invoke_tool_call(
    name: str,
    fn: Callable[..., T],
    *args: Any,
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> T:
    """Invoke a tool through the active SDK context and emit trace events."""
    ctx = _resolve_context(context)
    return ctx.invoke_tool(name, fn, args, kwargs)


async def invoke_tool_call_async(
    name: str,
    fn: Callable[..., T] | Callable[..., Awaitable[T]],
    *args: Any,
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> T:
    """Async variant of :func:`invoke_tool_call`."""
    ctx = _resolve_context(context)
    return await ctx.invoke_tool_async(name, fn, args, kwargs)


def invoke_llm_call(
    provider: str,
    model: str,
    fn: Callable[..., T],
    *args: Any,
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> T:
    """Invoke an LLM call through the active SDK context."""
    ctx = _resolve_context(context)
    return ctx.invoke_llm(provider=provider, model=model, fn=fn, args=args, kwargs=kwargs)


async def invoke_llm_call_async(
    provider: str,
    model: str,
    fn: Callable[..., T] | Callable[..., Awaitable[T]],
    *args: Any,
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> T:
    """Async variant of :func:`invoke_llm_call`."""
    ctx = _resolve_context(context)
    return await ctx.invoke_llm_async(provider=provider, model=model, fn=fn, args=args, kwargs=kwargs)


def openai_chat_completion(
    client: Any,
    *,
    model: str,
    messages: list[dict[str, Any]],
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Run OpenAI chat completions with normalized response and usage output."""
    create_fn = _resolve_nested_attribute(client, ("chat", "completions", "create"), label="openai")
    request = {"model": model, "messages": messages, **kwargs}
    ctx = _resolve_context(context)
    raw_result = ctx.invoke_llm(provider="openai", model=model, fn=create_fn, args=(), kwargs=request)
    response, usage = _extract_openai_response(raw_result)
    return {"response": response, "usage": usage, "result": raw_result}


def anthropic_messages_create(
    client: Any,
    *,
    model: str,
    messages: list[dict[str, Any]],
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Run Anthropic messages API with normalized response and usage output."""
    create_fn = _resolve_nested_attribute(client, ("messages", "create"), label="anthropic")
    request = {"model": model, "messages": messages, **kwargs}
    ctx = _resolve_context(context)
    raw_result = ctx.invoke_llm(provider="anthropic", model=model, fn=create_fn, args=(), kwargs=request)
    response, usage = _extract_anthropic_response(raw_result)
    return {"response": response, "usage": usage, "result": raw_result}


def gemini_generate_content(
    client: Any,
    *,
    model: str,
    contents: Any,
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Run Gemini generate_content with normalized response and usage output."""
    create_fn = _resolve_nested_attribute(client, ("models", "generate_content"), label="gemini")
    request = {"model": model, "contents": contents, **kwargs}
    ctx = _resolve_context(context)
    raw_result = ctx.invoke_llm(provider="gemini", model=model, fn=create_fn, args=(), kwargs=request)
    response, usage = _extract_gemini_response(raw_result)
    return {"response": response, "usage": usage, "result": raw_result}


def langchain_invoke(
    runnable: Any,
    input_value: Any,
    *,
    model: str = "langchain-runnable",
    provider: str = "langchain",
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Invoke a LangChain runnable while preserving Trajectly trace semantics."""
    if not hasattr(runnable, "invoke"):
        raise ValueError("langchain runnable must expose `invoke`")
    invoke_fn = runnable.invoke
    raw_result = invoke_llm_call(provider, model, invoke_fn, input_value, context=context, **kwargs)

    usage = {}
    response: Any = raw_result
    mapping = _as_mapping(raw_result)
    if mapping is not None:
        usage = _as_usage_dict(mapping.get("usage", {}))
        if "response" in mapping:
            response = mapping["response"]
        elif "text" in mapping:
            response = mapping["text"]

    return {"response": response, "usage": usage, "result": raw_result}


def llamaindex_query(
    query_engine: Any,
    query: str,
    *,
    model: str = "llamaindex-query-engine",
    provider: str = "llamaindex",
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Query a LlamaIndex query engine with normalized response and usage output."""
    if not hasattr(query_engine, "query"):
        raise ValueError("llamaindex query engine must expose `query`")
    query_fn = query_engine.query
    raw_result = invoke_llm_call(provider, model, query_fn, query, context=context, **kwargs)
    response, usage = _extract_llamaindex_response(raw_result)
    return {"response": response, "usage": usage, "result": raw_result}


def crewai_run_task(
    task: Any,
    inputs: Mapping[str, Any] | None = None,
    *,
    model: str = "crewai-task",
    provider: str = "crewai",
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Run a CrewAI task and normalize response/usage payloads."""
    run_fn: Callable[..., Any]
    if hasattr(task, "execute"):
        run_fn = task.execute
    elif hasattr(task, "run"):
        run_fn = task.run
    else:
        raise ValueError("crewai task must expose `execute` or `run`")

    request = dict(inputs or {})
    request.update(kwargs)
    raw_result = invoke_llm_call(provider, model, run_fn, context=context, **request)
    response, usage = _extract_crewai_result(raw_result)
    return {"response": response, "usage": usage, "result": raw_result}


def autogen_chat_run(
    chat_runner: Any,
    messages: list[dict[str, Any]],
    *,
    model: str = "autogen-chat",
    provider: str = "autogen",
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Run an AutoGen chat executor and normalize response/usage payloads."""
    if not hasattr(chat_runner, "run"):
        raise ValueError("autogen chat runner must expose `run`")
    run_fn = chat_runner.run
    raw_result = invoke_llm_call(provider, model, run_fn, messages, context=context, **kwargs)
    response, usage = _extract_autogen_result(raw_result)
    return {"response": response, "usage": usage, "result": raw_result}


def dspy_call(
    program: Any,
    input_value: Any,
    *,
    model: str = "dspy-program",
    provider: str = "dspy",
    context: SDKContextLike | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Run a DSPy callable/program and normalize response/usage payloads."""
    call_fn: Callable[..., Any]
    if callable(program):
        call_fn = program
    elif hasattr(program, "forward"):
        call_fn = program.forward
    else:
        raise ValueError("dspy program must be callable or expose `forward`")

    raw_result = invoke_llm_call(provider, model, call_fn, input_value, context=context, **kwargs)
    response, usage = _extract_dspy_result(raw_result)
    return {"response": response, "usage": usage, "result": raw_result}


__all__ = [
    "SDKContextLike",
    "anthropic_messages_create",
    "autogen_chat_run",
    "crewai_run_task",
    "dspy_call",
    "gemini_generate_content",
    "invoke_llm_call",
    "invoke_llm_call_async",
    "invoke_tool_call",
    "invoke_tool_call_async",
    "langchain_invoke",
    "llamaindex_query",
    "openai_chat_completion",
]
