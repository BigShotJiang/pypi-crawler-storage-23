"""CLI module: trajectly/cli/report/renderers.py."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from trajectly.constants import SCHEMA_VERSION
from trajectly.diff.models import DiffResult
from trajectly.schema import validate_diff_report_dict


def render_markdown(spec_name: str, result: DiffResult) -> str:
    """Execute `render_markdown`."""
    lines: list[str] = []
    lines.append(f"## Trajectly Report: {spec_name}")
    lines.append("")
    summary = result.summary
    status = "Regression detected" if summary.get("regression") else "No regression"
    lines.append(f"- Status: **{status}**")
    lines.append(f"- Findings: **{summary.get('finding_count', 0)}**")
    first_divergence = summary.get("first_divergence")
    if isinstance(first_divergence, dict):
        lines.append(
            "- First divergence: "
            f"**{first_divergence.get('kind', 'unknown')}** at index "
            f"**{first_divergence.get('index', '?')}**"
        )

    baseline = summary.get("baseline", {})
    current = summary.get("current", {})
    lines.append("")
    lines.append("### Resource Usage")
    lines.append("")
    lines.append("| Metric | Baseline | Current |")
    lines.append("|---|---:|---:|")
    lines.append(
        f"| Duration (ms) | {baseline.get('duration_ms', 0)} | {current.get('duration_ms', 0)} |"
    )
    lines.append(f"| Tool Calls | {baseline.get('tool_calls', 0)} | {current.get('tool_calls', 0)} |")
    lines.append(f"| Tokens | {baseline.get('tokens', 0)} | {current.get('tokens', 0)} |")

    lines.append("")
    lines.append("### Findings")
    lines.append("")
    if not result.findings:
        lines.append("No findings.")
    else:
        for finding in result.findings:
            location = f" at `{finding.path}`" if finding.path else ""
            lines.append(f"- `{finding.classification}`{location}: {finding.message}")

    lines.append("")
    return "\n".join(lines)


def write_reports(spec_name: str, result: DiffResult, json_path: Path, md_path: Path) -> None:
    """Execute `write_reports`."""
    json_path.parent.mkdir(parents=True, exist_ok=True)
    md_path.parent.mkdir(parents=True, exist_ok=True)
    report_payload = {"schema_version": SCHEMA_VERSION, **result.to_dict()}
    validated_payload = validate_diff_report_dict(report_payload)
    json_path.write_text(json.dumps(validated_payload, indent=2, sort_keys=True), encoding="utf-8")
    md_path.write_text(render_markdown(spec_name=spec_name, result=result), encoding="utf-8")


def render_pr_comment(latest_report: dict[str, Any]) -> str:
    """Execute `render_pr_comment`."""
    processed_specs = int(latest_report.get("processed_specs", 0))
    regressions = int(latest_report.get("regressions", 0))
    errors = latest_report.get("errors", [])
    reports = latest_report.get("reports", [])

    lines: list[str] = []
    lines.append("### Trajectly Regression Report")
    lines.append("")
    lines.append(f"- Specs processed: **{processed_specs}**")
    lines.append(f"- Regressions: **{regressions}**")
    lines.append(f"- Errors: **{len(errors) if isinstance(errors, list) else 0}**")
    lines.append("")
    lines.append("| Spec | Status | Repro |")
    lines.append("|---|---|---|")

    if isinstance(reports, list) and reports:
        for row in reports:
            if not isinstance(row, dict):
                continue
            spec_name = str(row.get("spec", "unknown"))
            status = "regression" if row.get("regression") else "clean"
            repro = str(row.get("repro_command", "n/a"))
            lines.append(f"| `{spec_name}` | `{status}` | `{repro}` |")
    else:
        lines.append("| n/a | n/a | n/a |")

    return "\n".join(lines) + "\n"
