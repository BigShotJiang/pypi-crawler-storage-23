"""
SDK integration tests — real HTTP calls against a running API.

Run:  PERSON_SDK_INTEGRATION=1 PYTHONPATH=. python3 -m pytest tests/test_integration.py -v
  or: PERSON_SDK_INTEGRATION=1 PYTHONPATH=. python3 -m unittest tests/test_integration.py -v

Requires a running API server (pnpm --filter @person/api dev).
Uses dev auth bypass (any "dev_*" key accepted when DEV_AUTH_BYPASS=true).
"""
from __future__ import annotations

import os
import sys
import unittest
import uuid

SKIP = not os.environ.get("PERSON_SDK_INTEGRATION")

BASE_URL = os.environ.get("PERSON_SDK_TEST_BASE_URL", "http://localhost:3002")
API_KEY = os.environ.get("PERSON_SDK_TEST_API_KEY", "dev_integration_test")
TENANT_ID = os.environ.get("PERSON_SDK_TEST_TENANT_ID", "0c74268c-09e8-40ea-b413-8dd5f0852f9a")


@unittest.skipIf(SKIP, "Set PERSON_SDK_INTEGRATION=1 to run integration tests")
class TestPythonSDKIntegration(unittest.TestCase):
    """End-to-end tests using the real Python SDK against the live API."""

    client = None  # type: ignore
    created_persona_id: str | None = None

    @classmethod
    def setUpClass(cls) -> None:
        from person_sdk import PersonClient

        cls.client = PersonClient(
            api_key=API_KEY,
            base_url=BASE_URL,
            default_tenant_id=TENANT_ID,
            timeout_seconds=30,
            max_retries=1,
        )

    @classmethod
    def tearDownClass(cls) -> None:
        if cls.created_persona_id and cls.client:
            try:
                cls.client.delete_persona(cls.created_persona_id)
            except Exception:
                pass

    def test_01_health(self) -> None:
        result = self.client.health()
        self.assertEqual(result["status"], "ok")
        self.assertIn("timestamp", result)
        print(f"  ✓ Health: {result['status']}")

    def test_02_create_persona(self) -> None:
        result = self.client.create_persona(
            seed={
                "firstName": "IntegrationTest",
                "lastName": "Python",
                "age": 35,
                "location": "Austin, TX",
                "baseOccupation": "Data scientist",
            },
        )
        self.assertIn("persona", result)
        persona_id = result["persona"]["id"]
        self.assertTrue(persona_id)
        TestPythonSDKIntegration.created_persona_id = persona_id
        print(f"  ✓ Created persona: {persona_id}")

    def test_03_get_persona(self) -> None:
        self.assertIsNotNone(self.created_persona_id)
        result = self.client.get_persona(self.created_persona_id)
        self.assertEqual(result["persona"]["id"], self.created_persona_id)
        print(f"  ✓ Retrieved persona: {self.created_persona_id}")

    def test_04_list_personas(self) -> None:
        self.assertIsNotNone(self.created_persona_id)
        result = self.client.list_personas()
        self.assertIn("personas", result)
        personas = result["personas"]
        self.assertIsInstance(personas, list)
        found = any(p["id"] == self.created_persona_id for p in personas)
        self.assertTrue(found, "Created persona should appear in list")
        print(f"  ✓ Listed personas, found ours among {len(personas)}")

    def test_05_prompt(self) -> None:
        self.assertIsNotNone(self.created_persona_id)
        result = self.client.prompt(
            persona_id=self.created_persona_id,
            user_prompt="What is your job? Reply in one sentence.",
        )
        self.assertIn("response", result)
        response = result["response"]
        self.assertTrue(len(response) > 0, "Response should not be empty")
        print(f"  ✓ Prompt response: {response[:80]}...")

    def test_06_prompt_stream(self) -> None:
        self.assertIsNotNone(self.created_persona_id)
        events = list(
            self.client.prompt_stream(
                persona_id=self.created_persona_id,
                user_prompt="Say hello in one word.",
            )
        )
        self.assertTrue(len(events) > 0, "Should receive at least one SSE event")
        done_events = [e for e in events if e["event"] == "done"]
        self.assertTrue(len(done_events) > 0, "Should receive a 'done' event")
        print(f"  ✓ Streamed {len(events)} SSE events")

    def test_07_delete_persona(self) -> None:
        self.assertIsNotNone(self.created_persona_id)
        result = self.client.delete_persona(self.created_persona_id)
        self.assertTrue(result)
        TestPythonSDKIntegration.created_persona_id = None
        print("  ✓ Deleted persona")

    def test_08_nonexistent_persona(self) -> None:
        from person_sdk import PersonSDKError

        fake_id = str(uuid.uuid4())
        with self.assertRaises(PersonSDKError) as ctx:
            self.client.get_persona(fake_id)
        self.assertIn(ctx.exception.status_code, (404, 401))
        print("  ✓ Correctly rejected nonexistent persona")


if __name__ == "__main__":
    unittest.main()
