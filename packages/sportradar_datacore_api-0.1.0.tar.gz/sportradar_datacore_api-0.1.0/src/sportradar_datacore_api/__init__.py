"""Initialization file for the sportradar_datacore_api package.

Author: Michael Adams, 2025
"""
