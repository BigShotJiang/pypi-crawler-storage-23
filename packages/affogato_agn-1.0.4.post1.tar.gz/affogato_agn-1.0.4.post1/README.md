# AFFOGATO
gAlactic Faint Feature extractiOn with GALFITM-bAsed Tools in pythOn
