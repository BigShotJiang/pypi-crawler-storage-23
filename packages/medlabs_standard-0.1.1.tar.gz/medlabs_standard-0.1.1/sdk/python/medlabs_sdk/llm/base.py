from medlabs_sdk.contracts import LLMClient

__all__ = ["LLMClient"]
