from medlabs_sdk.core.map.to_standard import to_standard_panel

__all__ = ["to_standard_panel"]
