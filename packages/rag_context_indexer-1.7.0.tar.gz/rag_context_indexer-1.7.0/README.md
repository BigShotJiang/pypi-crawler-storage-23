<!--
@RAG_CONTEXT
{
  "archivo": "README.md",
  "lineas": 75,
  "tokens_estimados": 520,
  "hash_contenido": "2a1924a921eaea602b23db0539d0ff8407901f4536f6512a0eea574f7631b865",
  "creacion": "2026-03-04",
  "modificacion": "2026-03-05",
  "tags": [],
  "descripcion_corta": "",
  "descripcion_larga": ""
}
-->
# RAG Context Indexer

Indexador de contexto enriquecido para optimización de RAG en LLMs. Motor agnóstico que inyecta metadatos semánticos en el código fuente y genera un `arbol_de_archivos_comentado.json` para que los LLMs entiendan arquitecturas complejas ahorrando millones de tokens.

## Instalación

```bash
pip install rag-context-indexer
```

## Uso

```bash
# En la raíz de tu proyecto:

# 1. Instalar el pre-commit hook (una sola vez)
rag-indexer init

# 2. Ejecutar indexación manual
rag-indexer run
```

## Configuración

Crea un archivo `.env` en la raíz de tu proyecto:

```env
# LLM activo: openai | anthropic | gemini | deepseek
ACTIVE_LLM=openai

# API Keys (solo la del LLM activo es necesaria)
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GEMINI_API_KEY=AIza...
DEEPSEEK_API_KEY=sk-...

# Opcional: usar modelos de razonamiento pesados
USE_CODE_MODEL=false
```

## Modelos soportados

| LLM       | Tier Default         | Tier Code                   |
|-----------|----------------------|-----------------------------|
| OpenAI    | gpt-4o-mini          | gpt-4o                      |
| Anthropic | claude-3-haiku       | claude-3-5-sonnet-latest    |
| Gemini    | gemini-2.5-flash     | gemini-2.5-pro              |
| DeepSeek  | deepseek-chat        | deepseek-coder              |

## Plantilla JSON inyectada por archivo

```json
{
  "archivo": "ruta/relativa/al/archivo.ext",
  "lineas": 0,
  "tokens_estimados": 0,
  "hash_contenido": "sha256_del_codigo_limpio",
  "creacion": "YYYY-MM-DD",
  "modificacion": "YYYY-MM-DD",
  "tags": ["dependencia1", "exportacion_principal"],
  "descripcion_corta": "Máx 50 chars.",
  "descripcion_larga": "100-500 chars, técnico."
}
```

## Principios de diseño

- **Idempotencia**: el hash SHA256 del código limpio evita llamadas innecesarias a la API
- **Anti vendor lock-in**: sin SDKs de terceros, solo `requests` vía REST
- **Control de costos**: variable `USE_CODE_MODEL` alterna entre tiers de modelos
- **Contexto de ejecución**: siempre escanea `os.getcwd()`, no la ubicación del script

## Licencia

MIT
