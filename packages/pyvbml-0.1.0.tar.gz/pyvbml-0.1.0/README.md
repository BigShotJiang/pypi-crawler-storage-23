# pyvbml

[![PyPI - Version](https://img.shields.io/pypi/v/pyvbml?style=for-the-badge)](https://pypi.org/project/pyvbml/)
[![Buy Me A Coffee/Beer](https://img.shields.io/badge/Buy_Me_A_☕/🍺-F16061?style=for-the-badge&logo=ko-fi&logoColor=white&labelColor=grey)](https://ko-fi.com/natekspencer)
[![Sponsor on GitHub](https://img.shields.io/badge/Sponsor_💜-6f42c1?style=for-the-badge&logo=github&logoColor=white&labelColor=grey)](https://github.com/sponsors/natekspencer)

[![GitHub License](https://img.shields.io/github/license/natekspencer/pyvbml?style=flat-square)](LICENSE)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyvbml?style=flat-square)](https://pypi.org/project/pyvbml/)
![Pepy Total Downloads](https://img.shields.io/pepy/dt/pyvbml?style=flat-square)
![PyPI - Downloads](https://img.shields.io/pypi/dm/pyvbml?style=flat-square)

A Python package for parsing [Vestaboard markup language (VBML)](https://docs.vestaboard.com/docs/vbml/) to Vestaboard character arrays locally. Based on the [Vestaboard/vbml](https://github.com/Vestaboard/vbml) codebase. Used in the [Vestaboard for Home Assistant integration](https://github.com/natekspencer/ha-vestaboard).

## ❤️ Support Me

I maintain this python project in my spare time. If you find it useful, consider supporting development:

- 💜 [Sponsor me on GitHub](https://github.com/sponsors/natekspencer)
- ☕ [Buy me a coffee / beer](https://ko-fi.com/natekspencer)
- 💸 [PayPal (direct support)](https://www.paypal.com/paypalme/natekspencer)
- ⭐ [Star this project](https://github.com/natekspencer/pyvbml)
- 📦 If you’d like to support in other ways, such as donating hardware for testing, feel free to [reach out to me](https://github.com/natekspencer)

## 📈 Star History

[![Star History Chart](https://api.star-history.com/svg?repos=natekspencer/pyvbml)](https://www.star-history.com/#natekspencer/pyvbml)
