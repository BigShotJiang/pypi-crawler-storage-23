"""Python VBML module."""

from __future__ import annotations

from .index import VBML
from .types import Align, Justify

__all__ = ["VBML", "Align", "Justify"]
__version__ = "0.1.0"
