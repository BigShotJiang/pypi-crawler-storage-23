"""
Main KerdosAgent class that orchestrates the training and deployment process.
"""

from typing import Optional, Union, Dict, Any
from pathlib import Path
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from .trainer import Trainer
from .deployer import Deployer
from .data_processor import DataProcessor

class KerdosAgent:
    """
    Main agent class for training and deploying LLMs with custom data.
    """
    
    def __init__(
        self,
        base_model: str,
        training_data: Union[str, Path],
        device: Optional[str] = None,
        **kwargs
    ):
        """
        Initialize the KerdosAgent.
        
        Args:
            base_model: Name or path of the base LLM model
            training_data: Path to the training data
            device: Device to run the model on (cuda/cpu)
            **kwargs: Additional configuration parameters
        """
        self.base_model = base_model
        self.training_data = Path(training_data)
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.config = kwargs
        
        # Initialize components
        self.model = AutoModelForCausalLM.from_pretrained(
            base_model,
            torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
            device_map="auto"
        )
        self.tokenizer = AutoTokenizer.from_pretrained(base_model)
        
        self.data_processor = DataProcessor(self.training_data)
        self.trainer = Trainer(self.model, self.tokenizer, self.device)
        self.deployer = Deployer(self.model, self.tokenizer)
    
    def train(
        self,
        epochs: int = 3,
        batch_size: int = 4,
        learning_rate: float = 2e-5,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Train the model on the provided data.
        
        Args:
            epochs: Number of training epochs
            batch_size: Training batch size
            learning_rate: Learning rate for training
            **kwargs: Additional training parameters
            
        Returns:
            Dictionary containing training metrics
        """
        # Process training data
        train_dataset = self.data_processor.prepare_dataset()
        
        # Train the model
        training_args = {
            "epochs": epochs,
            "batch_size": batch_size,
            "learning_rate": learning_rate,
            **kwargs
        }
        
        metrics = self.trainer.train(train_dataset, **training_args)
        return metrics
    
    def deploy(
        self,
        deployment_type: str = "rest",
        host: str = "0.0.0.0",
        port: int = 8000,
        **kwargs
    ) -> None:
        """
        Deploy the trained model.
        
        Args:
            deployment_type: Type of deployment (rest/docker/kubernetes)
            host: Host address for REST API
            port: Port number for REST API
            **kwargs: Additional deployment parameters
        """
        deployment_args = {
            "deployment_type": deployment_type,
            "host": host,
            "port": port,
            **kwargs
        }
        
        self.deployer.deploy(**deployment_args)
    
    def save(self, output_dir: Union[str, Path]) -> None:
        """
        Save the trained model and tokenizer.
        
        Args:
            output_dir: Directory to save the model
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        self.model.save_pretrained(output_dir)
        self.tokenizer.save_pretrained(output_dir)
    
    @classmethod
    def load(cls, model_dir: Union[str, Path], **kwargs) -> "KerdosAgent":
        """
        Load a trained model from disk.
        
        Args:
            model_dir: Directory containing the saved model
            **kwargs: Additional initialization parameters
            
        Returns:
            Loaded KerdosAgent instance
        """
        model_dir = Path(model_dir)
        agent = cls(
            base_model=str(model_dir),
            training_data="",  # Not needed for loading
            **kwargs
        )
        return agent 