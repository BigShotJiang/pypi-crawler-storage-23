"""
kerdosai.rag
Retrieval-Augmented Generation toolkit for KerdosAI.

Quick start::

    from kerdosai.rag import KnowledgeBase, RAGAgent

    kb = KnowledgeBase()
    kb.index_documents(["report.pdf", "policy.docx"])

    agent = RAGAgent(hf_token="hf_...", knowledge_base=kb)
    print(agent.chat("What is the refund policy?"))

Low-level access::

    from kerdosai.rag import load_documents, build_index, retrieve, answer_stream
"""

from kerdosai.rag.document_loader import load_documents
from kerdosai.rag.embedder import (
    VectorIndex, build_index, add_to_index,
    EMBEDDING_MODEL, CHUNK_SIZE, CHUNK_OVERLAP,
)
from kerdosai.rag.retriever import retrieve
from kerdosai.rag.chain import answer_stream, answer, build_context
from kerdosai.rag.knowledge_base import KnowledgeBase
from kerdosai.rag.rag_agent import RAGAgent

__all__ = [
    # Low-level
    "load_documents",
    "VectorIndex", "build_index", "add_to_index",
    "retrieve",
    "answer_stream", "answer", "build_context",
    # High-level
    "KnowledgeBase", "RAGAgent",
    # Constants
    "EMBEDDING_MODEL", "CHUNK_SIZE", "CHUNK_OVERLAP",
]
