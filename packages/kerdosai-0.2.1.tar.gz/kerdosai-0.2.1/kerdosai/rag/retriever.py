"""
kerdosai.rag.retriever
Performs cosine-similarity search against a VectorIndex.
"""

from __future__ import annotations
import numpy as np
from typing import List

from kerdosai.rag.embedder import VectorIndex

DEFAULT_TOP_K = 5
# Chunks with cosine similarity below this are dropped before reaching the LLM.
MIN_SCORE = 0.30


def retrieve(query: str, vector_index: VectorIndex,
             top_k: int = DEFAULT_TOP_K,
             min_score: float = MIN_SCORE) -> List[dict]:
    """
    Embed *query* and return the top-K most similar chunks above *min_score*.

    Args:
        query:        The user's natural-language question.
        vector_index: A :class:`~kerdosai.rag.embedder.VectorIndex`.
        top_k:        Maximum number of chunks to return.
        min_score:    Minimum cosine similarity threshold (0–1).

    Returns:
        List of ``{"source": str, "text": str, "score": float}`` dicts,
        ordered by descending relevance.
    """
    import faiss

    if vector_index is None or vector_index.index is None:
        return []

    query_embedding = vector_index.embedder.encode([query], show_progress_bar=False)
    query_embedding = np.array(query_embedding, dtype="float32")
    faiss.normalize_L2(query_embedding)

    n_results = min(top_k, vector_index.index.ntotal)
    scores, indices = vector_index.index.search(query_embedding, n_results)

    results: List[dict] = []
    for score, idx in zip(scores[0], indices[0]):
        if idx == -1:
            continue
        if float(score) < min_score:
            continue
        chunk = vector_index.chunks[idx]
        results.append({
            "source": chunk["source"],
            "text":   chunk["text"],
            "score":  float(score),
        })
    return results
