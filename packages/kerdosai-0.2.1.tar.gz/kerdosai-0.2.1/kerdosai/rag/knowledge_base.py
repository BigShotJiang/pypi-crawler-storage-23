"""
kerdosai.rag.knowledge_base
High-level KnowledgeBase API — index documents and query them in one object.
"""

from __future__ import annotations
from pathlib import Path
from typing import List, Optional, Union

from kerdosai.rag.document_loader import load_documents
from kerdosai.rag.embedder import (
    VectorIndex, build_index, add_to_index,
    EMBEDDING_MODEL, CHUNK_SIZE, CHUNK_OVERLAP,
)
from kerdosai.rag.retriever import retrieve, DEFAULT_TOP_K, MIN_SCORE


class KnowledgeBase:
    """
    High-level interface for building and querying a RAG knowledge base.

    Example::

        from kerdosai.rag import KnowledgeBase

        kb = KnowledgeBase()
        kb.index_documents(["report.pdf", "policy.docx"])

        results = kb.search("What is the refund policy?", top_k=5)
        for r in results:
            print(r["source"], r["score"], r["text"][:120])

    Args:
        embedding_model: SentenceTransformer model ID (default: BAAI/bge-small-en-v1.5).
        chunk_size:      Max characters per text chunk.
        chunk_overlap:   Overlap characters between consecutive chunks.
        min_score:       Minimum cosine-similarity threshold for retrieval.
    """

    def __init__(
        self,
        embedding_model: str = EMBEDDING_MODEL,
        chunk_size:      int = CHUNK_SIZE,
        chunk_overlap:   int = CHUNK_OVERLAP,
        min_score:       float = MIN_SCORE,
    ) -> None:
        self.embedding_model = embedding_model
        self.chunk_size      = chunk_size
        self.chunk_overlap   = chunk_overlap
        self.min_score       = min_score

        self._index:           Optional[VectorIndex] = None
        self._indexed_sources: set[str]              = set()

    # ── Indexing ───────────────────────────────────────────────────────────

    def index_documents(self, file_paths: List[Union[str, Path]]) -> "KnowledgeBase":
        """
        Load and index one or more documents.

        Already-indexed filenames are silently skipped (duplicate guard).

        Args:
            file_paths: List of paths to PDF / DOCX / TXT / MD / CSV files.

        Returns:
            *self* for method chaining.
        """
        paths = [str(p) for p in file_paths]
        new_paths = [p for p in paths if Path(p).name not in self._indexed_sources]

        if not new_paths:
            print("[KnowledgeBase] All provided files are already indexed.")
            return self

        docs = load_documents(new_paths)
        if not docs:
            print("[KnowledgeBase] No text could be extracted from the provided files.")
            return self

        if self._index is None:
            self._index = build_index(
                docs,
                embedding_model=self.embedding_model,
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap,
            )
        else:
            self._index = add_to_index(
                self._index, docs,
                chunk_size=self.chunk_size,
                chunk_overlap=self.chunk_overlap,
            )

        self._indexed_sources |= {d["source"] for d in docs}
        print(f"[KnowledgeBase] Total chunks: {self._index.index.ntotal} | "
              f"Sources: {sorted(self._indexed_sources)}")
        return self

    def clear(self) -> "KnowledgeBase":
        """Clear the knowledge base (index + source tracking)."""
        self._index           = None
        self._indexed_sources = set()
        return self

    # ── Retrieval ──────────────────────────────────────────────────────────

    def search(self, query: str,
               top_k: int = DEFAULT_TOP_K) -> List[dict]:
        """
        Retrieve the most relevant chunks for *query*.

        Args:
            query: Natural-language question.
            top_k: Maximum number of chunks to return.

        Returns:
            List of ``{"source", "text", "score"}`` dicts ordered by relevance.
        """
        if self._index is None:
            raise RuntimeError("No documents indexed yet. Call index_documents() first.")
        return retrieve(query, self._index, top_k=top_k, min_score=self.min_score)

    # ── Properties ─────────────────────────────────────────────────────────

    @property
    def indexed_sources(self) -> set[str]:
        """Set of filenames currently in the knowledge base."""
        return set(self._indexed_sources)

    @property
    def chunk_count(self) -> int:
        """Total number of chunks stored in the index."""
        return self._index.index.ntotal if self._index else 0

    @property
    def is_ready(self) -> bool:
        """True if at least one document has been indexed."""
        return self._index is not None
