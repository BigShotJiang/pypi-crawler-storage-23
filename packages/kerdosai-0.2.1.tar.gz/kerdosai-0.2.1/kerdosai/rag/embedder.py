"""
kerdosai.rag.embedder
Chunks raw text and builds / extends an in-memory FAISS vector index.
"""

from __future__ import annotations
import re as _re
import numpy as np
from dataclasses import dataclass, field
from typing import List, Optional

# ── Defaults (override via env or KnowledgeBase kwargs) ───────────────────────
CHUNK_SIZE = 512        # max chars per chunk
CHUNK_OVERLAP = 64      # approx overlap between consecutive chunks
EMBEDDING_MODEL = "BAAI/bge-small-en-v1.5"  # state-of-the-art small retrieval model

# Regex: split on sentence-ending punctuation followed by whitespace + capital,
# or on paragraph / line breaks.
_SENTENCE_SPLIT = _re.compile(r'(?<=[.!?])\s+(?=[A-Z])|(?<=\n)\s*\n+')

# ── Model singleton ───────────────────────────────────────────────────────────
_MODEL: Optional[object] = None


def _get_model(model_name: str = EMBEDDING_MODEL):
    """Return the cached SentenceTransformer, loading it on first call."""
    global _MODEL
    if _MODEL is None:
        from sentence_transformers import SentenceTransformer
        _MODEL = SentenceTransformer(model_name)
    return _MODEL
# ─────────────────────────────────────────────────────────────────────────────


@dataclass
class VectorIndex:
    """Holds chunks, their embeddings, and the FAISS index."""
    chunks: List[dict] = field(default_factory=list)   # {"source", "text"}
    index: object = None                                # faiss.IndexFlatIP
    embedder: object = None                             # SentenceTransformer
    embedding_model: str = EMBEDDING_MODEL


def _chunk_text(source: str, text: str,
                chunk_size: int = CHUNK_SIZE,
                chunk_overlap: int = CHUNK_OVERLAP) -> List[dict]:
    """
    Split *text* into overlapping chunks that respect sentence boundaries.

    1. Split document into sentences / paragraphs.
    2. Greedily accumulate sentences until *chunk_size* chars is reached.
    3. Back-up by ~*chunk_overlap* chars for the next chunk so consecutive
       chunks share boundary context.
    """
    text = _re.sub(r'[ \t]+', ' ', text).strip()
    sentences = [s.strip() for s in _SENTENCE_SPLIT.split(text) if s.strip()]

    chunks: List[dict] = []
    i = 0

    while i < len(sentences):
        parts: List[str] = []
        total = 0
        j = i
        while j < len(sentences):
            slen = len(sentences[j])
            if total + slen > chunk_size and parts:
                break
            parts.append(sentences[j])
            total += slen + 1
            j += 1

        chunk_text = " ".join(parts)
        if chunk_text.strip():
            chunks.append({"source": source, "text": chunk_text})

        if j == i:
            sent = sentences[i]
            for k in range(0, len(sent), chunk_size - chunk_overlap):
                part = sent[k: k + chunk_size]
                if part.strip():
                    chunks.append({"source": source, "text": part})
            i += 1
            continue

        overlap_chars = 0
        next_i = j
        for k in range(j - 1, i, -1):
            overlap_chars += len(sentences[k]) + 1
            if overlap_chars >= chunk_overlap:
                next_i = k
                break

        i = max(i + 1, next_i)

    return chunks


def build_index(docs: List[dict],
                embedding_model: str = EMBEDDING_MODEL,
                chunk_size: int = CHUNK_SIZE,
                chunk_overlap: int = CHUNK_OVERLAP) -> VectorIndex:
    """
    Build a new FAISS index from a list of ``{"source", "text"}`` dicts.

    Args:
        docs:            List of document dicts (from :func:`load_documents`).
        embedding_model: SentenceTransformer model ID.
        chunk_size:      Max characters per chunk.
        chunk_overlap:   Overlap between consecutive chunks (characters).

    Returns:
        :class:`VectorIndex` ready for retrieval.
    """
    import faiss

    model = _get_model(embedding_model)

    all_chunks: List[dict] = []
    for doc in docs:
        all_chunks.extend(_chunk_text(doc["source"], doc["text"], chunk_size, chunk_overlap))

    if not all_chunks:
        raise ValueError("No text chunks could be extracted from the provided documents.")

    print(f"[kerdosai.rag] Embedding {len(all_chunks)} chunks …")
    texts = [c["text"] for c in all_chunks]
    embeddings = model.encode(texts, show_progress_bar=False, batch_size=32)
    embeddings = np.array(embeddings, dtype="float32")

    dim = embeddings.shape[1]
    faiss.normalize_L2(embeddings)
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)

    print(f"[kerdosai.rag] Index ready: {index.ntotal} vectors, dim={dim}")
    return VectorIndex(chunks=all_chunks, index=index, embedder=model,
                       embedding_model=embedding_model)


def add_to_index(vector_index: VectorIndex, docs: List[dict],
                 chunk_size: int = CHUNK_SIZE,
                 chunk_overlap: int = CHUNK_OVERLAP) -> VectorIndex:
    """Incrementally add new documents to an existing :class:`VectorIndex`."""
    import faiss

    new_chunks: List[dict] = []
    for doc in docs:
        new_chunks.extend(_chunk_text(doc["source"], doc["text"], chunk_size, chunk_overlap))

    if not new_chunks:
        return vector_index

    texts = [c["text"] for c in new_chunks]
    embeddings = vector_index.embedder.encode(texts, show_progress_bar=False, batch_size=32)
    embeddings = np.array(embeddings, dtype="float32")
    faiss.normalize_L2(embeddings)

    vector_index.index.add(embeddings)
    vector_index.chunks.extend(new_chunks)
    return vector_index
