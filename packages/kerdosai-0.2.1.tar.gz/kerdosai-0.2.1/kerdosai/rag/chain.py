"""
kerdosai.rag.chain
Calls an LLM via the HuggingFace Inference API with a strict RAG prompt.
Answers ONLY from the retrieved context; never from general knowledge.

Features:
  - answer_stream() yields token-by-token for real-time Gradio streaming
  - answer() blocks until the full reply is ready (non-streaming)
  - tenacity retry (3 attempts, exponential back-off) on transient API errors
  - Hard input-length guard (query ≤ 2 000 chars, history capped at 6 messages)
"""

from __future__ import annotations
import os
from typing import Generator, List, Optional

from huggingface_hub import InferenceClient
from tenacity import (
    retry, stop_after_attempt, wait_exponential, retry_if_exception_type
)

SYSTEM_PROMPT = """\
You are an enterprise document assistant. Your ONLY job is to answer questions \
using the provided document context below.

STRICT RULES:
1. Answer ONLY using information explicitly found in the provided context.
2. Do NOT use any outside knowledge or assumptions.
3. If the answer is not found in the context, respond EXACTLY with: \
"I don't have that information in the uploaded documents."
4. Always cite the source document name(s) in your answer using [Source: <filename>].
5. Be concise and professional.

Context from uploaded documents:
---
{context}
---
"""

LLM_MODEL       = os.environ.get("LLM_MODEL", "meta-llama/Llama-3.1-8B-Instruct")
MAX_NEW_TOKENS  = 1024
TEMPERATURE     = 0.1   # low for grounded, factual responses
MAX_QUERY_CHARS = 2_000
MAX_HISTORY_TURNS = 6   # last N messages (1 turn = 1 user + 1 assistant)


# ── Helpers ───────────────────────────────────────────────────────────────────

def build_context(chunks: List[dict]) -> str:
    """Format retrieved chunks into a numbered context block."""
    parts = [f"[{i}] (Source: {c['source']})\n{c['text']}"
             for i, c in enumerate(chunks, 1)]
    return "\n\n".join(parts)


def _build_messages(query: str,
                    context_chunks: List[dict],
                    chat_history: Optional[List[dict]]) -> List[dict]:
    context  = build_context(context_chunks)
    messages = [{"role": "system", "content": SYSTEM_PROMPT.format(context=context)}]

    if chat_history:
        for msg in chat_history[-MAX_HISTORY_TURNS:]:
            if msg.get("role") in ("user", "assistant") and msg.get("content"):
                messages.append({"role": msg["role"], "content": msg["content"]})

    messages.append({"role": "user", "content": query[:MAX_QUERY_CHARS]})
    return messages


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=2, max=10),
    retry=retry_if_exception_type(Exception),
    reraise=True,
)
def _open_stream(client: InferenceClient, messages: List[dict], model: str):
    """Open a streaming LLM connection; retried up to 3× on transient errors."""
    return client.chat_completion(
        model=model,
        messages=messages,
        max_tokens=MAX_NEW_TOKENS,
        temperature=TEMPERATURE,
        stream=True,
    )


# ── Public API ────────────────────────────────────────────────────────────────

def answer_stream(
    query: str,
    context_chunks: List[dict],
    hf_token: str,
    chat_history: Optional[List[dict]] = None,
    model: str = LLM_MODEL,
) -> Generator[str, None, None]:
    """
    Stream the LLM answer token-by-token.

    Yields progressively-growing reply strings so a Gradio chatbot can update
    in real time.

    Args:
        query:          The user's question.
        context_chunks: Retrieved chunks from :func:`~kerdosai.rag.retriever.retrieve`.
        hf_token:       HuggingFace API token.
        chat_history:   Previous messages (OpenAI-style list of dicts).
        model:          HF model ID to use for generation.

    Yields:
        Partial answer strings (each yield = full text accumulated so far).
    """
    if not context_chunks:
        yield "I don't have that information in the uploaded documents."
        return

    messages = _build_messages(query, context_chunks, chat_history)
    client   = InferenceClient(token=hf_token)

    try:
        stream = _open_stream(client, messages, model)
    except Exception as e:
        yield f"❌ Could not reach the LLM after 3 attempts: {e}"
        return

    accumulated = ""
    try:
        for chunk in stream:
            delta = chunk.choices[0].delta.content
            if delta:
                accumulated += delta
                yield accumulated
    except Exception as e:
        error_notice = f"\n\n⚠️ *Streaming interrupted: {e}*"
        yield (accumulated + error_notice) if accumulated else f"❌ Streaming error: {e}"


def answer(
    query: str,
    context_chunks: List[dict],
    hf_token: str,
    chat_history: Optional[List[dict]] = None,
    model: str = LLM_MODEL,
) -> str:
    """
    Non-streaming version of :func:`answer_stream`.

    Returns the complete LLM reply as a single string.
    Useful for programmatic / API usage where streaming is not needed.
    """
    result = ""
    for partial in answer_stream(query, context_chunks, hf_token, chat_history, model):
        result = partial
    return result
