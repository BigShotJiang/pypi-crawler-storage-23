"""
kerdosai.rag.rag_agent
RAGAgent — combines a KnowledgeBase with an LLM Inference client
for one-shot answers or streaming chat with full conversation history.
"""

from __future__ import annotations
import os
from typing import Generator, List, Optional, Union
from pathlib import Path

from kerdosai.rag.knowledge_base import KnowledgeBase
from kerdosai.rag.chain import answer, answer_stream, LLM_MODEL


class RAGAgent:
    """
    High-level Retrieval-Augmented Generation agent.

    Wraps a :class:`~kerdosai.rag.KnowledgeBase` and calls the HuggingFace
    Inference API to answer questions grounded in your documents.

    Example::

        from kerdosai.rag import RAGAgent

        agent = RAGAgent(hf_token="hf_...")
        agent.index(["company_handbook.pdf", "faq.docx"])

        # One-shot answer
        print(agent.chat("What is the leave policy?"))

        # Streaming (yields partial strings)
        for partial in agent.chat_stream("Summarise the refund section."):
            print(partial, end="\\r")

    Args:
        hf_token:        HuggingFace API token. Falls back to ``HF_TOKEN`` env var.
        model:           LLM model ID to use for generation.
        knowledge_base:  Existing :class:`KnowledgeBase` to reuse (optional).
        top_k:           Number of chunks retrieved per query.
        **kb_kwargs:     Extra kwargs forwarded to :class:`KnowledgeBase` constructor.
    """

    def __init__(
        self,
        hf_token:       Optional[str] = None,
        model:          str = LLM_MODEL,
        knowledge_base: Optional[KnowledgeBase] = None,
        top_k:          int = 5,
        **kb_kwargs,
    ) -> None:
        self.hf_token = hf_token or os.environ.get("HF_TOKEN", "")
        self.model    = model
        self.top_k    = top_k
        self.kb       = knowledge_base or KnowledgeBase(**kb_kwargs)
        self._history: List[dict] = []

    # ── Document management ────────────────────────────────────────────────

    def index(self, file_paths: List[Union[str, Path]]) -> "RAGAgent":
        """Index documents into the knowledge base and return *self*."""
        self.kb.index_documents(file_paths)
        return self

    # ── Chat ───────────────────────────────────────────────────────────────

    def chat(self, query: str) -> str:
        """
        Ask a question and get a complete answer (blocking).

        Conversation history is maintained automatically.
        """
        self._validate()
        chunks = self.kb.search(query, top_k=self.top_k)
        reply  = answer(query, chunks, self.hf_token,
                        chat_history=self._history, model=self.model)
        self._record(query, reply)
        return reply

    def chat_stream(self, query: str) -> Generator[str, None, None]:
        """
        Ask a question and stream the answer token-by-token.

        Each yielded value is the *full accumulated* reply so far.
        Conversation history is updated after the stream completes.
        """
        self._validate()
        chunks = self.kb.search(query, top_k=self.top_k)
        final  = ""
        for partial in answer_stream(query, chunks, self.hf_token,
                                     chat_history=self._history, model=self.model):
            final = partial
            yield partial
        self._record(query, final)

    def reset_history(self) -> "RAGAgent":
        """Clear conversation history (keeps the knowledge base intact)."""
        self._history = []
        return self

    # ── Internals ──────────────────────────────────────────────────────────

    def _validate(self) -> None:
        if not self.hf_token:
            raise ValueError(
                "No HuggingFace token provided. Pass hf_token= or set HF_TOKEN env var."
            )
        if not self.kb.is_ready:
            raise RuntimeError("No documents indexed. Call agent.index([...]) first.")

    def _record(self, query: str, reply: str) -> None:
        self._history.append({"role": "user",      "content": query})
        self._history.append({"role": "assistant",  "content": reply})
