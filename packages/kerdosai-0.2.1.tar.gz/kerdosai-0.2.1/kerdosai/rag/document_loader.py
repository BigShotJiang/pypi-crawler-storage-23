"""
kerdosai.rag.document_loader
Parses uploaded files (PDF, DOCX, TXT, MD, CSV) into plain-text dicts.
"""

from __future__ import annotations
from pathlib import Path
from typing import List


def load_documents(file_paths: List[str]) -> List[dict]:
    """
    Parse a list of file paths into ``{"source": filename, "text": content}`` dicts.

    Supported formats: .pdf, .docx, .txt, .md, .csv

    Args:
        file_paths: Absolute or relative paths to the files to load.

    Returns:
        List of dicts with keys ``source`` (filename) and ``text`` (extracted text).
    """
    docs = []
    for path in file_paths:
        if path is None:
            continue
        ext = Path(path).suffix.lower()
        name = Path(path).name
        try:
            if ext == ".pdf":
                text = _load_pdf(path)
            elif ext == ".docx":
                text = _load_docx(path)
            elif ext in (".txt", ".md", ".csv"):
                text = _load_text(path)
            else:
                print(f"[kerdosai.rag] Unsupported file type: {ext} — skipping {name}")
                continue

            if text.strip():
                docs.append({"source": name, "text": text})
            else:
                print(f"[kerdosai.rag] Empty content from {name} — skipping")
        except Exception as e:
            print(f"[kerdosai.rag] Failed to load {name}: {e}")

    return docs


# ── Private helpers ────────────────────────────────────────────────────────────

def _load_pdf(path: str) -> str:
    import fitz  # PyMuPDF
    doc = fitz.open(path)
    pages = [page.get_text("text") for page in doc]
    doc.close()
    return "\n".join(pages)


def _load_docx(path: str) -> str:
    from docx import Document
    doc = Document(path)
    parts: list[str] = []

    # Body paragraphs
    for p in doc.paragraphs:
        if p.text.strip():
            parts.append(p.text.strip())

    # Tables
    for table in doc.tables:
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells if cell.text.strip()]
            if cells:
                parts.append("\t".join(cells))

    return "\n".join(parts)


def _load_text(path: str) -> str:
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        return f.read()
