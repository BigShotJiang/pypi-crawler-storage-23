"""
Deployment module for KerdosAI.
"""

from typing import Dict, Any, Optional
import torch
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import uvicorn
import docker
import yaml
import logging
from pathlib import Path

logger = logging.getLogger(__name__)

class TextRequest(BaseModel):
    """Request model for text generation."""
    text: str
    max_length: Optional[int] = 100
    temperature: Optional[float] = 0.7
    top_p: Optional[float] = 0.9

class Deployer:
    """
    Handles model deployment in various environments.
    """
    
    def __init__(
        self,
        model: Any,
        tokenizer: Any,
        device: Optional[str] = None
    ):
        """
        Initialize the deployer.
        
        Args:
            model: The trained model
            tokenizer: The model's tokenizer
            device: Device to run inference on
        """
        self.model = model
        self.tokenizer = tokenizer
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)
        self.model.eval()
    
    def deploy(
        self,
        deployment_type: str = "rest",
        host: str = "0.0.0.0",
        port: int = 8000,
        **kwargs
    ) -> None:
        """
        Deploy the model.
        
        Args:
            deployment_type: Type of deployment (rest/docker/kubernetes)
            host: Host address for REST API
            port: Port number for REST API
            **kwargs: Additional deployment parameters
        """
        if deployment_type == "rest":
            self._deploy_rest(host, port)
        elif deployment_type == "gradio-rag":
            self._deploy_gradio_rag(host=host, port=port, **kwargs)
        elif deployment_type == "docker":
            self._deploy_docker(**kwargs)
        elif deployment_type == "kubernetes":
            self._deploy_kubernetes(**kwargs)
        else:
            raise ValueError(f"Unsupported deployment type: {deployment_type}")
    
    def _deploy_rest(self, host: str, port: int) -> None:
        """
        Deploy the model as a REST API.

        Args:
            host: Host address
            port: Port number
        """
        app = FastAPI(title="KerdosAI API")

        @app.post("/generate")
        async def generate_text(request: TextRequest):
            try:
                inputs = self.tokenizer(
                    request.text,
                    return_tensors="pt",
                    padding=True,
                    truncation=True
                ).to(self.device)

                with torch.no_grad():
                    outputs = self.model.generate(
                        **inputs,
                        max_length=request.max_length,
                        temperature=request.temperature,
                        top_p=request.top_p,
                        pad_token_id=self.tokenizer.eos_token_id
                    )

                generated_text = self.tokenizer.decode(
                    outputs[0],
                    skip_special_tokens=True
                )

                return {"generated_text": generated_text}

            except Exception as e:
                raise HTTPException(status_code=500, detail=str(e))

        uvicorn.run(app, host=host, port=port)

    def _deploy_gradio_rag(
        self,
        host: str = "0.0.0.0",
        port: int = 7860,
        hf_token: str = "",
        knowledge_base=None,
        **kwargs,
    ) -> None:
        """
        Launch the Kerdos enterprise RAG Chat UI (Gradio).

        Replicates the HuggingFace Space locally so it can be run
        on-premise with full data privacy.

        Args:
            host:           Server host (default 0.0.0.0).
            port:           Server port (default 7860).
            hf_token:       HuggingFace API token for LLM inference.
            knowledge_base: Pre-built :class:`~kerdosai.rag.KnowledgeBase`
                            (optional — users can upload docs via UI).
        """
        import os
        import gradio as gr
        from kerdosai.rag import KnowledgeBase as KB
        from kerdosai.rag.document_loader import load_documents
        from kerdosai.rag.embedder import build_index, add_to_index
        from kerdosai.rag.retriever import retrieve
        from kerdosai.rag.chain import answer_stream
        from pathlib import Path

        hf_token = hf_token or os.environ.get("HF_TOKEN", "")

        # ── state helpers ────────────────────────────────────────────────
        def _get_token(user_token):
            t = (user_token or "").strip()
            return t or hf_token

        def process_files(files, cur_idx, sources):
            if not files:
                return cur_idx, sources, "⚠️ No files uploaded."
            paths = [f.name for f in files] if hasattr(files[0], "name") else files
            new_paths = [p for p in paths if Path(p).name not in sources]
            if not new_paths:
                return cur_idx, sources, "⚠️ Already indexed. No new documents added."
            docs = load_documents(new_paths)
            if not docs:
                return cur_idx, sources, "❌ Could not extract text. Upload PDF/DOCX/TXT."
            try:
                idx = build_index(docs) if cur_idx is None else add_to_index(cur_idx, docs)
            except Exception as e:
                return cur_idx, sources, f"❌ Failed to build index: {e}"
            new_sources = {d["source"] for d in docs}
            msg = (f"✅ Indexed {len(new_sources)} file(s): {', '.join(new_sources)}\n"
                   f"📦 Total chunks: {idx.index.ntotal}")
            return idx, sources | new_sources, msg

        def chat(user_msg, history, vec_idx, token_in, top_k):
            if not user_msg.strip():
                yield history, ""; return
            tok = _get_token(token_in)
            if not tok:
                yield history + [{"role":"user","content":user_msg},
                                  {"role":"assistant","content":"⚠️ Provide a HF token."}], ""
                return
            if vec_idx is None:
                yield history + [{"role":"user","content":user_msg},
                                  {"role":"assistant","content":"⚠️ Upload documents first."}], ""
                return
            chunks  = retrieve(user_msg, vec_idx, top_k=int(top_k))
            history = history + [{"role":"user","content":user_msg},{"role":"assistant","content":""}]
            for partial in answer_stream(user_msg, chunks, tok, chat_history=history[:-2]):
                history[-1]["content"] = partial
                yield history, ""

        def reset_all():
            return None, set(), [], "🗑️ Cleared.", ""

        # ── UI ───────────────────────────────────────────────────────────
        CSS = """
        :root{--k-primary:#0055FF;--k-accent:#00C2FF;--k-dark:#0A0F2C;}
        body{font-family:'Segoe UI',Arial,sans-serif;}
        #kerdos-header{background:linear-gradient(135deg,#0A0F2C,#0B2C6E,#0044CC);
            border-radius:16px;padding:24px 32px 20px;margin-bottom:12px;
            border:1px solid rgba(0,194,255,.25);box-shadow:0 4px 24px rgba(0,85,255,.18);}
        #kerdos-footer{text-align:center;margin-top:18px;padding:12px;
            border-top:1px solid rgba(0,194,255,.15);font-size:.82em;color:#888;}
        .upload-box{border:2px dashed #0055FF!important;border-radius:12px!important;}
        footer{display:none!important;}
        """

        with gr.Blocks(title="Kerdos AI — Custom LLM Chat", css=CSS,
                       theme=gr.themes.Soft()) as ui:

            gr.HTML("""
            <div id='kerdos-header'>
              <div style='text-align:center;font-size:1.6em;font-weight:800;color:#fff;'>
                Kerdos <span style='color:#00C2FF;'>AI</span>
                <span style='font-size:.55em;background:rgba(0,194,255,.15);
                  border:1px solid rgba(0,194,255,.4);border-radius:20px;
                  padding:3px 14px;color:#00C2FF;letter-spacing:.08em;
                  text-transform:uppercase;font-weight:600;'>Enterprise</span>
              </div>
              <div style='text-align:center;color:#A0B8FF;font-size:.88em;margin-top:4px;'>
                Custom LLM Chat &amp; Document Q&amp;A
              </div>
            </div>""")

            vec_state  = gr.State(None)
            src_state  = gr.State(set())

            with gr.Row():
                with gr.Column(scale=1, min_width=300):
                    gr.Markdown("### 📂 Upload Documents")
                    file_upload = gr.File(file_count="multiple",
                        file_types=[".pdf",".docx",".txt",".md",".csv"],
                        label="Drag & drop or click", elem_classes=["upload-box"])
                    index_btn  = gr.Button("📥 Index Documents", variant="primary")
                    status_box = gr.Textbox(label="Status", interactive=False, lines=3)
                    gr.Markdown("### ⚙️ Settings")
                    hf_input   = gr.Textbox(label="HF Token (optional)",
                        placeholder="hf_...", type="password")
                    top_k_sl   = gr.Slider(1, 10, value=5, step=1,
                        label="Chunks to retrieve (top-K)")
                    reset_btn  = gr.Button("🗑️ Clear All", variant="stop")

                with gr.Column(scale=2):
                    gr.Markdown("### 💬 Ask Questions")
                    chatbot   = gr.Chatbot(height=460, show_label=False, type="messages")
                    with gr.Row():
                        user_in  = gr.Textbox(placeholder="Ask about your documents…",
                            show_label=False, scale=5, container=False)
                        send_btn = gr.Button("Send ▶", variant="primary", scale=1)

            index_btn.click(process_files,
                [file_upload, vec_state, src_state],
                [vec_state, src_state, status_box])
            send_btn.click(chat,
                [user_in, chatbot, vec_state, hf_input, top_k_sl],
                [chatbot, user_in])
            user_in.submit(chat,
                [user_in, chatbot, vec_state, hf_input, top_k_sl],
                [chatbot, user_in])
            reset_btn.click(reset_all, [],
                [vec_state, src_state, chatbot, status_box, user_in])

            gr.HTML("<div id='kerdos-footer'>"
                    "&copy; 2024–2026 <strong>Kerdos Infrasoft Private Limited</strong>"
                    "</div>")

        logger.info(f"Launching Kerdos RAG UI at http://{host}:{port}")
        ui.queue()
        ui.launch(server_name=host, server_port=port)
    
    def _deploy_docker(self, **kwargs) -> None:
        """
        Deploy the model using Docker.
        
        Args:
            **kwargs: Additional Docker deployment parameters
        """
        # Create Dockerfile
        dockerfile_content = """
FROM python:3.8-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install -r requirements.txt

COPY . .

CMD ["python", "-m", "kerdosai.deployer", "--deploy", "rest"]
"""
        
        # Save Dockerfile
        with open("Dockerfile", "w") as f:
            f.write(dockerfile_content)
        
        # Build and run Docker container
        client = docker.from_env()
        
        try:
            # Build image
            image, _ = client.images.build(
                path=".",
                tag="kerdosai:latest",
                dockerfile="Dockerfile"
            )
            
            # Run container
            container = client.containers.run(
                image.id,
                ports={'8000/tcp': 8000},
                detach=True
            )
            
            logger.info(f"Docker container started: {container.id}")
            
        except Exception as e:
            logger.error(f"Error deploying with Docker: {str(e)}")
            raise
    
    def _deploy_kubernetes(self, **kwargs) -> None:
        """
        Deploy the model using Kubernetes.
        
        Args:
            **kwargs: Additional Kubernetes deployment parameters
        """
        # Create Kubernetes deployment manifest
        deployment_manifest = {
            "apiVersion": "apps/v1",
            "kind": "Deployment",
            "metadata": {
                "name": "kerdosai"
            },
            "spec": {
                "replicas": 1,
                "selector": {
                    "matchLabels": {
                        "app": "kerdosai"
                    }
                },
                "template": {
                    "metadata": {
                        "labels": {
                            "app": "kerdosai"
                        }
                    },
                    "spec": {
                        "containers": [{
                            "name": "kerdosai",
                            "image": "kerdosai:latest",
                            "ports": [{
                                "containerPort": 8000
                            }]
                        }]
                    }
                }
            }
        }
        
        # Create Kubernetes service manifest
        service_manifest = {
            "apiVersion": "v1",
            "kind": "Service",
            "metadata": {
                "name": "kerdosai"
            },
            "spec": {
                "selector": {
                    "app": "kerdosai"
                },
                "ports": [{
                    "port": 80,
                    "targetPort": 8000
                }],
                "type": "LoadBalancer"
            }
        }
        
        # Save manifests
        with open("deployment.yaml", "w") as f:
            yaml.dump(deployment_manifest, f)
        
        with open("service.yaml", "w") as f:
            yaml.dump(service_manifest, f)
        
        logger.info("Kubernetes manifests created. Apply them using:")
        logger.info("kubectl apply -f deployment.yaml")
        logger.info("kubectl apply -f service.yaml") 