"""
KerdosAI - Universal LLM Training & RAG Agent
"""

from .agent import KerdosAgent
from .trainer import Trainer
from .deployer import Deployer
from .data_processor import DataProcessor
from . import rag
from .rag import KnowledgeBase, RAGAgent

__version__ = "0.2.1"
__all__ = [
    "KerdosAgent", "Trainer", "Deployer", "DataProcessor",
    "KnowledgeBase", "RAGAgent",
    "rag",
]
