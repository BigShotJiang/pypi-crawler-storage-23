"""
Command-line interface for KerdosAI.
"""

import argparse
import logging
import os
from pathlib import Path
from .agent import KerdosAgent

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def main():
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(description="KerdosAI - Universal LLM Training Agent")
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    # Train command
    train_parser = subparsers.add_parser("train", help="Train the model")
    train_parser.add_argument("--model", required=True, help="Base model name or path")
    train_parser.add_argument("--data", required=True, help="Path to training data")
    train_parser.add_argument("--output", default="output", help="Output directory")
    train_parser.add_argument("--epochs", type=int, default=3, help="Number of epochs")
    train_parser.add_argument("--batch-size", type=int, default=4, help="Batch size")
    train_parser.add_argument("--learning-rate", type=float, default=2e-5, help="Learning rate")
    
    # Deploy command
    deploy_parser = subparsers.add_parser("deploy", help="Deploy the model")
    deploy_parser.add_argument("--model-dir", required=True, help="Path to trained model")
    deploy_parser.add_argument("--type",
        choices=["rest", "docker", "kubernetes", "gradio-rag"],
        default="rest", help="Deployment type")
    deploy_parser.add_argument("--host", default="0.0.0.0", help="Host address")
    deploy_parser.add_argument("--port", type=int, default=8000, help="Port number")
    deploy_parser.add_argument("--hf-token", default="",
        help="HuggingFace token (for gradio-rag; falls back to HF_TOKEN env var)")

    # RAG Chat command — no local model required
    rag_parser = subparsers.add_parser("rag-chat",
        help="Launch a RAG chat UI without a locally trained model")
    rag_parser.add_argument("--data", nargs="+", required=False, default=[],
        metavar="FILE",
        help="Pre-index these files before launching (PDF/DOCX/TXT/MD/CSV)")
    rag_parser.add_argument("--hf-token", default="",
        help="HuggingFace API token (falls back to HF_TOKEN env var)")
    rag_parser.add_argument("--model",
        default="meta-llama/Llama-3.1-8B-Instruct",
        help="LLM model ID to use for generation")
    rag_parser.add_argument("--host", default="0.0.0.0", help="Server host")
    rag_parser.add_argument("--port", type=int, default=7860, help="Server port")
    rag_parser.add_argument("--embedding-model",
        default="BAAI/bge-small-en-v1.5",
        help="SentenceTransformer model for document embeddings")
    
    args = parser.parse_args()
    
    if args.command == "train":
        try:
            # Initialize agent
            agent = KerdosAgent(
                base_model=args.model,
                training_data=args.data
            )
            
            # Train model
            metrics = agent.train(
                epochs=args.epochs,
                batch_size=args.batch_size,
                learning_rate=args.learning_rate
            )
            
            # Save model
            agent.save(args.output)
            
            logger.info("Training completed successfully!")
            logger.info(f"Metrics: {metrics}")
            
        except Exception as e:
            logger.error(f"Error during training: {str(e)}")
            raise
    
    elif args.command == "deploy":
        try:
            agent = KerdosAgent.load(args.model_dir)
            agent.deploy(
                deployment_type=args.type,
                host=args.host,
                port=args.port,
                hf_token=getattr(args, "hf_token", ""),
            )
            logger.info(f"Model deployed successfully using {args.type}!")
        except Exception as e:
            logger.error(f"Error during deployment: {str(e)}")
            raise

    elif args.command == "rag-chat":
        try:
            from .rag import KnowledgeBase, RAGAgent
            from .deployer import Deployer

            hf_token = getattr(args, "hf_token", "") or os.environ.get("HF_TOKEN", "")
            os.environ["LLM_MODEL"] = args.model

            kb = KnowledgeBase(embedding_model=args.embedding_model)
            if args.data:
                kb.index_documents(args.data)
                logger.info(f"Pre-indexed {len(args.data)} file(s).")

            # Use Deployer to launch the Gradio RAG UI (no local model needed)
            deployer = Deployer(model=None, tokenizer=None)
            deployer.deploy(
                deployment_type="gradio-rag",
                host=args.host,
                port=args.port,
                hf_token=hf_token,
                knowledge_base=kb,
            )
        except Exception as e:
            logger.error(f"Error launching RAG chat: {str(e)}")
            raise

    else:
        parser.print_help()

if __name__ == "__main__":
    main() 