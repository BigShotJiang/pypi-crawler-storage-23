import pytest
from pathlib import Path
from kerdosai import KerdosAgent, TrainingConfig

def test_agent_initialization():
    """Test basic agent initialization."""
    agent = KerdosAgent(
        base_model="gpt2",  # Using a small model for testing
        training_data="tests/data/sample.json"
    )
    assert agent.base_model == "gpt2"
    assert isinstance(agent.training_data, Path)

def test_agent_with_config():
    """Test agent initialization with configuration."""
    config = TrainingConfig(
        curriculum_learning=True,
        hyperparameter_optimization=True
    )
    agent = KerdosAgent(
        base_model="gpt2",
        training_data="tests/data/sample.json",
        config=config
    )
    assert agent.config.curriculum_learning is True
    assert agent.config.hyperparameter_optimization is True

def test_invalid_model():
    """Test agent initialization with invalid model."""
    with pytest.raises(ValueError):
        KerdosAgent(
            base_model="invalid_model",
            training_data="tests/data/sample.json"
        )

def test_invalid_data_path():
    """Test agent initialization with invalid data path."""
    with pytest.raises(FileNotFoundError):
        KerdosAgent(
            base_model="gpt2",
            training_data="nonexistent/path/data.json"
        ) 