import requests

BASE_URL = "https://raw.githubusercontent.com/KulalMithun/labpgmml/main/"

FILES = [
    "A1","A2","A3","A4","A5","A6","A7",
    "B1","B2","B3","B4","B5","B6","B7",
    "C1","C2","C3","C4","C5","C6","CNP"
]


def list_programs():
    print("\nAvailable Lab Programs:\n")
    for f in FILES:
        print(f)
    print()


def get(name):

    name = name.upper()

    if name not in FILES:
        print("Program not found.")
        return

    if name == "CNP":
        filename = name + ".txt"
    else:
        filename = name + ".ipynb"

    url = BASE_URL + filename

    try:
        r = requests.get(url)

        if r.status_code != 200:
            print("Failed to download file.")
            return

        with open(filename, "wb") as f:
            f.write(r.content)

        print(f"{filename} downloaded successfully.")

    except Exception as e:
        print("Error:", e)


def get_all():

    print("Downloading all lab programs...\n")

    for f in FILES:
        get(f)

    print("\nAll programs downloaded.")