"""Integration tests for repo_generation_tool pipeline."""
