"""Matplotlib utilities with Chinese font support."""

from yclibs.matplotlib.bar import bar_plot, horizontal_bar_plot
from yclibs.matplotlib.utils import (
    CHINESE_FONT_NAMES,
    DEFAULT_CHINESE_FONT_SEARCH_PATHS,
    apply_chinese_font,
    close_figure,
    export_plot,
    find_chinese_font,
    register_chinese_font,
    save_plot,
    setup_chinese_font,
)

__all__ = [
    "CHINESE_FONT_NAMES",
    "DEFAULT_CHINESE_FONT_SEARCH_PATHS",
    "apply_chinese_font",
    "bar_plot",
    "close_figure",
    "export_plot",
    "find_chinese_font",
    "horizontal_bar_plot",
    "register_chinese_font",
    "save_plot",
    "setup_chinese_font",
]
