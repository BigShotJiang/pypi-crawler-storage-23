"""
Padam.id PLN Outage API SDK
Official Python SDK for the Padam.id API

Author: Akbar Naufal Awalin
License: MIT
"""

from .client import PadamClient, PadamAPIError
from .types import (
    OutageCheckResponse,
    MeterSummaryResponse,
    Pole,
    TokenEstimate,
    BillingEntry,
)

__version__ = "1.0.0"
__author__ = "Akbar Naufal Awalin"
__all__ = [
    "PadamClient",
    "PadamAPIError",
    "OutageCheckResponse",
    "MeterSummaryResponse",
    "Pole",
    "TokenEstimate",
    "BillingEntry",
]
