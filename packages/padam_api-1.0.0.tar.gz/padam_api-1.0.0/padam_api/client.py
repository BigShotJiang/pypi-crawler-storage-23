"""
Padam API Client
"""

import requests
from typing import Optional

from .types import OutageCheckResponse, MeterSummaryResponse


class PadamAPIError(Exception):
    """Exception raised for API errors"""

    def __init__(self, code: str, message: str, status_code: int = 0):
        self.code = code
        self.message = message
        self.status_code = status_code
        super().__init__(f"{code}: {message}")


class PadamClient:
    """
    Client for the Padam.id PLN Outage API

    Args:
        api_key: Your API key
        base_url: API base URL (default: https://padam.id/api)
        timeout: Request timeout in seconds (default: 10)

    Example:
        >>> client = PadamClient(api_key="your_api_key")
        >>> result = client.check_outage(-6.2088, 106.8456)
        >>> print(result.summary.has_outage)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = "https://padam.id/api",
        timeout: int = 10,
    ):
        if not api_key:
            raise ValueError("API key is required")

        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({
            "Content-Type": "application/json",
            "X-API-Key": self.api_key,
        })

    def _request(self, endpoint: str, data: dict) -> dict:
        """Make a POST request to the API"""
        try:
            response = self._session.post(
                f"{self.base_url}{endpoint}",
                json=data,
                timeout=self.timeout,
            )
            result = response.json()

            if not response.ok or not result.get("success"):
                error = result.get("error", {})
                raise PadamAPIError(
                    code=error.get("code", "UNKNOWN_ERROR"),
                    message=error.get("message", "An unknown error occurred"),
                    status_code=response.status_code,
                )

            return result

        except requests.Timeout:
            raise PadamAPIError("TIMEOUT", "Request timed out", 408)
        except requests.RequestException as e:
            raise PadamAPIError("NETWORK_ERROR", f"Failed to connect to API: {e}", 0)

    def check_outage(
        self,
        latitude: float,
        longitude: float,
    ) -> OutageCheckResponse:
        """
        Check power outage at a specific location

        Args:
            latitude: Latitude coordinate (-90 to 90)
            longitude: Longitude coordinate (-180 to 180)

        Returns:
            OutageCheckResponse with poles data and summary

        Raises:
            PadamAPIError: If the API request fails
            ValueError: If coordinates are invalid

        Example:
            >>> result = client.check_outage(-6.2088, 106.8456)
            >>> print(f"Total poles: {result.summary.total_poles}")
            >>> print(f"Has outage: {result.summary.has_outage}")
        """
        if not -90 <= latitude <= 90:
            raise ValueError("Invalid latitude (must be -90 to 90)")
        if not -180 <= longitude <= 180:
            raise ValueError("Invalid longitude (must be -180 to 180)")

        data = self._request("/outage/check", {
            "latitude": latitude,
            "longitude": longitude,
        })

        return OutageCheckResponse.from_dict(data)

    def get_meter_summary(
        self,
        meter_id: Optional[str] = None,
        account_id: Optional[str] = None,
    ) -> MeterSummaryResponse:
        """
        Get meter summary including billing history and token estimate

        Args:
            meter_id: 12-digit PLN meter number (recommended)
            account_id: Internal PLN account ID

        Returns:
            MeterSummaryResponse with billing and token data

        Raises:
            PadamAPIError: If the API request fails
            ValueError: If neither meter_id nor account_id is provided

        Example:
            >>> result = client.get_meter_summary(meter_id="566601485354")
            >>> print(f"Consumer: {result.consumer_name}")
            >>> if result.token_estimate:
            ...     print(f"Remaining days: {result.token_estimate.remaining_days}")
        """
        if not meter_id and not account_id:
            raise ValueError("Either meter_id or account_id is required")

        request_data = {}
        if meter_id:
            request_data["meter_id"] = meter_id
        if account_id:
            request_data["account_id"] = account_id

        data = self._request("/meter/summary", request_data)

        return MeterSummaryResponse.from_dict(data)

    def close(self):
        """Close the underlying session"""
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
