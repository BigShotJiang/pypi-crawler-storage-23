"""
Type definitions for Padam API responses
"""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class Pole:
    """Represents a power pole"""
    id: str
    name: Optional[str]
    address: Optional[str]
    status: str
    distance: Optional[float]
    latitude: float
    longitude: float


@dataclass
class OutageSummary:
    """Summary of outage check results"""
    total_poles: int
    poles_on: int
    poles_off: int
    has_outage: bool


@dataclass
class OutageCheckResponse:
    """Response from outage check endpoint"""
    success: bool
    latitude: Optional[float] = None
    longitude: Optional[float] = None
    radius: Optional[int] = None
    summary: Optional[OutageSummary] = None
    poles: Optional[List[Pole]] = None
    credits_remaining: Optional[int] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "OutageCheckResponse":
        if not data.get("success"):
            error = data.get("error", {})
            return cls(
                success=False,
                error_code=error.get("code"),
                error_message=error.get("message"),
            )

        response_data = data.get("data", {})
        location = response_data.get("location", {})
        summary_data = response_data.get("summary", {})
        poles_data = response_data.get("poles", [])

        poles = [
            Pole(
                id=p.get("id", ""),
                name=p.get("name"),
                address=p.get("address"),
                status=p.get("status", ""),
                distance=p.get("distance"),
                latitude=p.get("location", {}).get("latitude", 0),
                longitude=p.get("location", {}).get("longitude", 0),
            )
            for p in poles_data
        ]

        summary = OutageSummary(
            total_poles=summary_data.get("total_poles", 0),
            poles_on=summary_data.get("poles_on", 0),
            poles_off=summary_data.get("poles_off", 0),
            has_outage=summary_data.get("has_outage", False),
        )

        return cls(
            success=True,
            latitude=location.get("latitude"),
            longitude=location.get("longitude"),
            radius=response_data.get("radius"),
            summary=summary,
            poles=poles,
            credits_remaining=response_data.get("credits_remaining"),
        )


@dataclass
class TokenEstimate:
    """Token estimate for prepaid meters"""
    remaining_days: int
    remaining_kwh: float
    daily_usage_kwh: float
    description: Optional[str]


@dataclass
class BillingEntry:
    """Billing history entry"""
    date: str
    amount: int
    kwh: float
    token: Optional[str]


@dataclass
class MeterSummaryResponse:
    """Response from meter summary endpoint"""
    success: bool
    account_id: Optional[str] = None
    meter_id: Optional[str] = None
    consumer_name: Optional[str] = None
    energy_type: Optional[str] = None
    energy: Optional[int] = None
    is_prepaid: Optional[bool] = None
    token_estimate: Optional[TokenEstimate] = None
    billing_history: Optional[List[BillingEntry]] = None
    credits_remaining: Optional[int] = None
    error_code: Optional[str] = None
    error_message: Optional[str] = None

    @classmethod
    def from_dict(cls, data: dict) -> "MeterSummaryResponse":
        if not data.get("success"):
            error = data.get("error", {})
            return cls(
                success=False,
                error_code=error.get("code"),
                error_message=error.get("message"),
            )

        response_data = data.get("data", {})
        token_data = response_data.get("token_estimate")
        billing_data = response_data.get("billing_history", [])

        token_estimate = None
        if token_data:
            token_estimate = TokenEstimate(
                remaining_days=token_data.get("remaining_days", 0),
                remaining_kwh=token_data.get("remaining_kwh", 0),
                daily_usage_kwh=token_data.get("daily_usage_kwh", 0),
                description=token_data.get("description"),
            )

        billing_history = [
            BillingEntry(
                date=b.get("date", ""),
                amount=b.get("amount", 0),
                kwh=b.get("kwh", 0),
                token=b.get("token"),
            )
            for b in billing_data
        ]

        return cls(
            success=True,
            account_id=response_data.get("account_id"),
            meter_id=response_data.get("meter_id"),
            consumer_name=response_data.get("consumer_name"),
            energy_type=response_data.get("energy_type"),
            energy=response_data.get("energy"),
            is_prepaid=response_data.get("is_prepaid"),
            token_estimate=token_estimate,
            billing_history=billing_history,
            credits_remaining=response_data.get("credits_remaining"),
        )
