"""Tests for the VWS CLI."""
