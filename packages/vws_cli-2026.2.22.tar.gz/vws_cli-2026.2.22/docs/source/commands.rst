Commands
========

.. click:: vws_cli:vws_group
  :prog: vws
  :show-nested:

.. click:: vws_cli.query:vuforia_cloud_reco
  :prog: vuforia-cloud-reco
  :show-nested:

.. click:: vws_cli.vumark:generate_vumark
  :prog: vumark
