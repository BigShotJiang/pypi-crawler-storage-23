"""Options for the VWS CLI commands."""
