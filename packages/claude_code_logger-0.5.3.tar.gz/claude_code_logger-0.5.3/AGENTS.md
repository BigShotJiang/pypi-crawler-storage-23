# Agent Instructions

- Always commit and push changes when work is complete
- Always deploy to PyPI after pushing — bump version, build, publish
- Keep code minimal and readable
