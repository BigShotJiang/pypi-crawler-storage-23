# cc-logger

Export and analyse [Claude Code](https://docs.anthropic.com/en/docs/claude-code) sessions.

Reads the JSONL trajectories Claude Code stores in `~/.claude/` and converts them to [Harbor ATIF](https://github.com/codegenresearch/harbor) format for viewing and analysis. Includes cost estimation using Anthropic's model pricing.

## Install

```
pip install claude-code-logger
```

## Usage

```bash
# List sessions
cc-logger list

# Export all sessions (Harbor format by default)
cc-logger export /tmp/cc-export

# View exported sessions in the browser
cc-logger view /tmp/cc-export

# Show analytics (tokens, costs, models, working hours)
cc-logger stats /tmp/cc-export
cc-logger stats /tmp/cc-export --json
cc-logger stats /tmp/cc-export --project myproject

# Refresh model pricing from Anthropic
cc-logger update-pricing
```

## Pricing

Cost estimation uses model pricing bundled in `src/cc_logger/data/pricing.json`, scraped from [platform.claude.com/docs/en/about-claude/pricing](https://platform.claude.com/docs/en/about-claude/pricing).

Run `cc-logger update-pricing` to scrape the latest prices into the repo, then release a new version so users get updated pricing.
