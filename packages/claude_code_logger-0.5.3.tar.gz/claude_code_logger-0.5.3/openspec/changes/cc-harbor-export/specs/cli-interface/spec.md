## ADDED Requirements

### Requirement: Export command writes ATIF files to output directory
The system SHALL provide an `export` command that reads CC sessions and writes ATIF v1.6 JSON files to a specified output directory.

#### Scenario: Export all sessions
- **WHEN** the user runs `cc-logger export ./trajectories`
- **THEN** the system SHALL export all discovered sessions as ATIF JSON files into `./trajectories/`, creating the directory if it doesn't exist

#### Scenario: Export with project filter
- **WHEN** the user runs `cc-logger export ./trajectories --project my-app`
- **THEN** the system SHALL only export sessions from projects matching the filter

#### Scenario: Export with session filter
- **WHEN** the user runs `cc-logger export ./trajectories --session <uuid>`
- **THEN** the system SHALL export only the specified session

#### Scenario: Export with date filter
- **WHEN** the user runs `cc-logger export ./trajectories --since 2026-01-15`
- **THEN** the system SHALL only export sessions modified on or after that date

#### Scenario: Export with combined filters
- **WHEN** the user runs `cc-logger export ./trajectories --project my-app --since 2026-02-01`
- **THEN** the system SHALL apply all filters (AND logic) to select sessions

### Requirement: Output file structure
The system SHALL organize exported files in a predictable directory structure.

#### Scenario: Single session export
- **WHEN** exporting session `abc-123`
- **THEN** the main trajectory SHALL be written to `<output-dir>/abc-123.json`

#### Scenario: Session with subagents
- **WHEN** exporting session `abc-123` that has subagents `agent-x1` and `agent-x2`
- **THEN** the main trajectory SHALL be at `<output-dir>/abc-123.json` and subagent trajectories at `<output-dir>/abc-123/subagents/agent-x1.json` and `<output-dir>/abc-123/subagents/agent-x2.json`

#### Scenario: Batch export with project grouping
- **WHEN** exporting multiple sessions without a project filter
- **THEN** sessions SHALL be organized by project: `<output-dir>/<project-slug>/<session-id>.json`

### Requirement: List command displays available sessions
The system SHALL provide a `list` command that shows available CC sessions in a table format.

#### Scenario: List all sessions
- **WHEN** the user runs `cc-logger list`
- **THEN** the system SHALL display a table with columns: session ID (truncated), project, date, first prompt (truncated), and message count

#### Scenario: List with project filter
- **WHEN** the user runs `cc-logger list --project my-app`
- **THEN** the system SHALL only list sessions from matching projects

#### Scenario: List with date filter
- **WHEN** the user runs `cc-logger list --since 2026-01-15`
- **THEN** the system SHALL only list sessions modified on or after the specified date

#### Scenario: No sessions found
- **WHEN** no sessions match the applied filters
- **THEN** the system SHALL print "No sessions found" and exit with code 0

### Requirement: Progress reporting during export
The system SHALL report progress during batch export operations.

#### Scenario: Multi-session export progress
- **WHEN** exporting multiple sessions
- **THEN** the system SHALL print progress as each session completes (e.g., `[3/47] Exported abc-123 (142 steps)`)

#### Scenario: Single session export feedback
- **WHEN** exporting a single session
- **THEN** the system SHALL print a summary on completion: file path, step count, and token totals

### Requirement: Custom Claude Code data directory
The system SHALL support specifying a custom Claude Code data directory instead of the default `~/.claude`.

#### Scenario: Custom data directory
- **WHEN** the user runs `cc-logger export ./out --claude-dir /path/to/.claude`
- **THEN** the system SHALL read session data from the specified directory instead of `~/.claude`

### Requirement: Error handling and exit codes
The system SHALL use conventional exit codes and clear error messages.

#### Scenario: Output directory not writable
- **WHEN** the output directory cannot be created or written to
- **THEN** the system SHALL exit with code 1 and print an error message

#### Scenario: No sessions match filters
- **WHEN** export is run with filters that match no sessions
- **THEN** the system SHALL print "No sessions found matching filters" and exit with code 0

#### Scenario: Partial export failure
- **WHEN** some sessions fail to export (e.g., corrupted JSONL) but others succeed
- **THEN** the system SHALL continue exporting remaining sessions, log warnings for failures, and exit with code 0 if any succeeded
