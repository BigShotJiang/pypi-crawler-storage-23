## Why

Claude Code stores rich conversation trajectories (tool calls, reasoning, approvals, plans, subagent work, context compaction) in per-session JSONL files, but there's no way to browse or visualize them. The Harbor project provides a trajectory viewer and a standard interchange format (ATIF), but no exporter exists for Claude Code's data. A CLI tool that reads CC sessions and exports them as Harbor ATIF files would make every CC session instantly viewable via `harbor view`.

## What Changes

- New CLI tool `cc-logger` with an `export` command that reads Claude Code JSONL session files and writes Harbor ATIF JSON files
- Parses CC's message types: user messages, assistant responses (text + tool_use blocks), tool results, system events, progress updates, file-history snapshots, and subagent trajectories
- Maps CC concepts to ATIF steps: user messages → user steps, assistant turns → agent steps (with tool_calls + reasoning_content), tool results → observations, system/progress → system steps
- Extracts token usage and cost metrics from assistant message `usage` fields into ATIF `metrics` and `final_metrics`
- Follows the conversation tree via `parentUuid`/`uuid` links to reconstruct correct step ordering (handling sidechains)
- Exports subagent trajectories as separate ATIF files with `subagent_trajectory_ref` links
- Supports exporting a single session, all sessions for a project, or all sessions globally
- Reads `sessions-index.json` for session discovery and listing

## Capabilities

### New Capabilities
- `session-discovery`: Finding and listing CC sessions from `~/.claude/projects/` structure, reading `sessions-index.json`, filtering by project/date/session-id
- `jsonl-parsing`: Reading CC JSONL files, reconstructing conversation trees from `parentUuid`/`uuid` links, handling all message types (user, assistant, system, progress, file-history-snapshot, queue-operation), resolving sidechains
- `atif-mapping`: Converting CC messages to Harbor ATIF v1.6 format — mapping content blocks to steps, tool_use to tool_calls, tool_result to observations, extracting reasoning_content from thinking blocks, computing metrics from usage data
- `cli-interface`: The `cc-logger export <output-dir>` command with flags for filtering (--session, --project, --since), listing sessions (cc-logger list), and output options

### Modified Capabilities
_(none — greenfield project)_

## Impact

- **New dependency**: Node.js CLI package (TypeScript)
- **Reads from**: `~/.claude/projects/` (JSONL session files, sessions-index.json, subagent logs) — read-only, never modifies CC data
- **Writes to**: User-specified output directory with ATIF JSON files
- **External compatibility**: Must conform to Harbor ATIF v1.6 schema so files work with `harbor view`
