"""Message classification utilities.

The main classification logic lives in reassemble.py (reassemble_assistant_groups),
which handles both grouping and classification in a single pass. This module provides
helpers for inspecting individual tool result messages.
"""

from __future__ import annotations

from typing import Any


def extract_tool_results(content: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Extract tool_result entries from a user message's content array."""
    return [item for item in content if isinstance(item, dict) and item.get("type") == "tool_result"]


def get_tool_result_text(tool_result: dict[str, Any]) -> str:
    """Get the text content from a tool_result, handling string and structured content."""
    content = tool_result.get("content", "")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        # Content can be an array of content blocks
        parts = []
        for part in content:
            if isinstance(part, dict) and part.get("type") == "text":
                parts.append(part.get("text", ""))
        return "\n".join(parts)
    return str(content)
