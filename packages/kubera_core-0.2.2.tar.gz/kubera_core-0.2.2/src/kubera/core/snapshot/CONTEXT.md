# snapshot

> Parent: [core/CONTEXT.md](../CONTEXT.md)

Banksalad Excel export-based financial snapshot system.

## Models

All inherit `(TimestampMixin, Base)`. `Snapshot` is parent; 4 child entry tables cascade on delete.

| Model | Table | Key columns |
|-------|-------|-------------|
| Snapshot | snapshots | snapshot_date, source, credit_score, total_assets/liabilities/net_worth(20,4) |
| AssetEntry | snapshot_asset_entries | FK→Snapshot, category, product_name, amount(20,4) |
| InvestmentEntry | snapshot_investment_entries | FK→Snapshot, broker, invested_amount, current_value, return_rate(10,4) |
| LoanEntry | snapshot_loan_entries | FK→Snapshot, lender, principal, balance, interest_rate(10,4), start/end_date |
| InsuranceEntry | snapshot_insurance_entries | FK→Snapshot, insurer, status, total_paid, start/end_date |
| LedgerEntry | snapshot_ledger_entries | FK→Snapshot, entry_date/time, entry_type(수입/지출), major/minor_category, amount(20,4), currency, payment_method |

UniqueConstraint on `(user_id, snapshot_date, source)`.

## Parser

`BanksaladParser.parse(file_path, password?)` → `ParsedSnapshot` dataclass (DB-independent).
- Sheet 1: section detection via markers ("1.고객정보", "3.재무현황", etc.)
- Sheet 2: ledger entries (가계부 내역) — fixed header row 1, filters 이체 out (수입/지출 only)
- Date extraction: filename pattern `YYYY-MM-DD~YYYY-MM-DD.xlsx` (end date)
- Supports `.zip` files via stdlib `zipfile`

## Service

`SnapshotService(db: Session)` — import, list, get, delete, trend, compare, ledger.
- `import_from_file` / `import_from_bytes`: parse → duplicate check → persist
- Incremental ledger import: only entries after previous snapshot's date are saved
- `get_ledger_entries`: paginated ledger query for a snapshot
- `get_trend`: chronological list of totals
- `compare_snapshots`: diff between two dates
