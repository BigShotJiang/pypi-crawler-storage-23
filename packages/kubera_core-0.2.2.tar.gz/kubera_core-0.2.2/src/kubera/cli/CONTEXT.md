# cli

> Parent: [kubera/CONTEXT.md](../CONTEXT.md)

Entry point: `kubera.cli:main` (registered as `kubera-core` in pyproject.toml).

## Commands

| Command | Action |
|---------|--------|
| `kubera-core start [--host] [--port]` | Ensure token → run migrations → uvicorn |
| `kubera-core token [--refresh]` | Show or regenerate auth token |
| `kubera-core snapshot import <file> [--password]` | Parse Banksalad xlsx/zip → save snapshot |
| `kubera-core snapshot list` | Table: date, source, net_worth, credit_score |

## DB access

CLI accesses DB directly (not through API): `Settings() → get_engine() → get_session()`.
Each command creates its own session and closes it in `finally`.
