"""Tests for snapshot CLI commands."""

from datetime import date
from decimal import Decimal
from pathlib import Path
from unittest.mock import patch

from openpyxl import Workbook

from kubera.core.snapshot.models import Snapshot


def _create_test_xlsx(path: Path):
    """Create a minimal test Banksalad xlsx matching real structure."""
    wb = Workbook()
    ws = wb.active

    row = 2
    ws.cell(row=row, column=2, value="1.고객정보")
    row += 2
    ws.cell(row=row, column=2, value="이름")
    ws.cell(row=row, column=5, value="신용점수\n(KCB)")
    row += 1
    ws.cell(row=row, column=2, value="홍길동")
    ws.cell(row=row, column=5, value=800)
    row += 2

    ws.cell(row=row, column=2, value="3.재무현황")
    row += 2
    ws.cell(row=row, column=2, value="항목")
    ws.cell(row=row, column=3, value="상품명")
    ws.cell(row=row, column=5, value="금액")
    ws.cell(row=row, column=6, value="항목")
    ws.cell(row=row, column=9, value="금액")
    row += 1
    ws.cell(row=row, column=2, value="예금")
    ws.cell(row=row, column=3, value="정기예금")
    ws.cell(row=row, column=5, value=10000000)
    ws.cell(row=row, column=6, value="신용대출")
    ws.cell(row=row, column=9, value=2000000)
    row += 1
    ws.cell(row=row, column=2, value="총자산")
    ws.cell(row=row, column=5, value=10000000)
    ws.cell(row=row, column=6, value="총부채")
    ws.cell(row=row, column=9, value=2000000)

    # Sheet 2: Ledger
    ws2 = wb.create_sheet("가계부 내역")
    ws2.cell(row=1, column=1, value="날짜")
    ws2.cell(row=1, column=2, value="시간")
    ws2.cell(row=1, column=3, value="타입")
    ws2.cell(row=1, column=4, value="대분류")
    ws2.cell(row=1, column=5, value="소분류")
    ws2.cell(row=1, column=6, value="내용")
    ws2.cell(row=1, column=7, value="금액")
    ws2.cell(row=1, column=8, value="화폐")
    ws2.cell(row=1, column=9, value="결제수단")
    ws2.cell(row=1, column=10, value="메모")
    ws2.cell(row=2, column=1, value="2025-04-20")
    ws2.cell(row=2, column=3, value="지출")
    ws2.cell(row=2, column=4, value="식비")
    ws2.cell(row=2, column=7, value=-10000)
    ws2.cell(row=2, column=8, value="KRW")
    ws2.cell(row=3, column=1, value="2025-04-15")
    ws2.cell(row=3, column=3, value="수입")
    ws2.cell(row=3, column=4, value="급여")
    ws2.cell(row=3, column=7, value=3000000)
    ws2.cell(row=3, column=8, value="KRW")

    wb.save(path)
    wb.close()


class TestSnapshotImport:
    def test_import_command(self, tmp_path, db, engine):
        xlsx_path = tmp_path / "2025-04-01~2025-04-30.xlsx"
        _create_test_xlsx(xlsx_path)

        from kubera.core.snapshot.service import SnapshotService
        svc = SnapshotService(db)
        snapshot = svc.import_from_file(xlsx_path)

        assert snapshot.snapshot_date == date(2025, 4, 30)
        assert snapshot.credit_score == 800
        assert snapshot.total_assets == Decimal("10000000")
        assert snapshot.net_worth == Decimal("8000000")
        assert len(snapshot.ledger_entries) == 2
        types = {e.entry_type for e in snapshot.ledger_entries}
        assert types == {"수입", "지출"}


class TestSnapshotList:
    def test_list_command(self, db):
        s = Snapshot(
            user_id="default",
            snapshot_date=date(2025, 5, 1),
            source="banksalad",
            credit_score=750,
            total_assets=Decimal("20000000"),
            total_liabilities=Decimal("5000000"),
            net_worth=Decimal("15000000"),
        )
        db.add(s)
        db.commit()

        from kubera.core.snapshot.service import SnapshotService
        svc = SnapshotService(db)
        items, total = svc.list_snapshots()

        assert total == 1
        assert items[0].snapshot_date == date(2025, 5, 1)
