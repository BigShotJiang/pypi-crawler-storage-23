"""Tests for core credential utilities."""

from __future__ import annotations

import json


class TestLoadCredentials:
    def test_empty_when_no_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from kubera.core.credentials import load_credentials

        assert load_credentials() == []

    def test_loads_valid_json(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        creds = [{"provider": "mail", "email": "a@b.com"}]
        (tmp_path / ".kubera_credentials.json").write_text(json.dumps(creds))

        from kubera.core.credentials import load_credentials

        assert load_credentials() == creds

    def test_returns_empty_on_invalid_json(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        (tmp_path / ".kubera_credentials.json").write_text("not json")

        from kubera.core.credentials import load_credentials

        assert load_credentials() == []


class TestSaveCredential:
    def test_creates_file(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from kubera.core.credentials import save_credential, load_credentials

        save_credential({"provider": "upbit", "access_key": "ak"})
        creds = load_credentials()
        assert len(creds) == 1
        assert creds[0]["provider"] == "upbit"

    def test_replaces_existing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from kubera.core.credentials import save_credential, load_credentials

        save_credential({"provider": "upbit", "access_key": "old"})
        save_credential({"provider": "upbit", "access_key": "new"})
        creds = load_credentials()
        assert len(creds) == 1
        assert creds[0]["access_key"] == "new"


class TestGetCredential:
    def test_returns_none_when_missing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from kubera.core.credentials import get_credential

        assert get_credential("upbit") is None

    def test_returns_matching_provider(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from kubera.core.credentials import save_credential, get_credential

        save_credential({"provider": "upbit", "access_key": "ak"})
        cred = get_credential("upbit")
        assert cred is not None
        assert cred["access_key"] == "ak"


class TestRemoveCredential:
    def test_removes_existing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from kubera.core.credentials import save_credential, remove_credential, load_credentials

        save_credential({"provider": "upbit", "access_key": "ak"})
        assert remove_credential("upbit") is True
        assert load_credentials() == []

    def test_returns_false_when_missing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        from kubera.core.credentials import remove_credential

        assert remove_credential("upbit") is False
