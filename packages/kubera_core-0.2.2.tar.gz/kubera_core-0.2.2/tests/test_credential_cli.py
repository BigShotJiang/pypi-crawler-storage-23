"""Tests for credential CLI commands (mail provider)."""

from __future__ import annotations

import argparse
import json


class TestMailCredentialAdd:
    def test_add_mail_credential(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        inputs = iter(["imap.gmail.com", "993", "user@gmail.com", "apppassword", "banksalad"])
        monkeypatch.setattr("builtins.input", lambda _: next(inputs))
        monkeypatch.setattr("getpass.getpass", lambda _: "apppassword")

        from kubera.cli.commands import _cmd_credential_add

        args = argparse.Namespace(provider="mail")
        _cmd_credential_add(args)

        cred_file = tmp_path / ".kubera_credentials.json"
        assert cred_file.exists()
        data = json.loads(cred_file.read_text())
        assert len(data) == 1
        cred = data[0]
        assert cred["provider"] == "mail"
        assert cred["imap_host"] == "imap.gmail.com"
        assert cred["email"] == "user@gmail.com"
        assert cred["password"] == "apppassword"

    def test_add_mail_uses_defaults(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # Return empty string for optional fields to trigger defaults
        inputs = iter(["imap.gmail.com", "", "user@gmail.com", "", ""])
        monkeypatch.setattr("builtins.input", lambda _: next(inputs))
        monkeypatch.setattr("getpass.getpass", lambda _: "mypassword")

        from kubera.cli.commands import _cmd_credential_add

        args = argparse.Namespace(provider="mail")
        _cmd_credential_add(args)

        data = json.loads((tmp_path / ".kubera_credentials.json").read_text())
        cred = data[0]
        assert cred["imap_port"] == "993"
        assert cred["sender_filter"] == "banksalad"

    def test_add_unsupported_provider(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        import pytest
        from kubera.cli.commands import _cmd_credential_add

        args = argparse.Namespace(provider="unknown_provider")
        with pytest.raises(SystemExit):
            _cmd_credential_add(args)

    def test_add_replaces_existing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        # First add
        inputs = iter(["imap.gmail.com", "993", "old@gmail.com", "pass1", "banksalad"])
        monkeypatch.setattr("builtins.input", lambda _: next(inputs))
        monkeypatch.setattr("getpass.getpass", lambda _: "pass1")

        from kubera.cli.commands import _cmd_credential_add

        _cmd_credential_add(argparse.Namespace(provider="mail"))

        # Second add (replace)
        inputs2 = iter(["imap.gmail.com", "993", "new@gmail.com", "pass2", "banksalad"])
        monkeypatch.setattr("builtins.input", lambda _: next(inputs2))
        monkeypatch.setattr("getpass.getpass", lambda _: "pass2")
        _cmd_credential_add(argparse.Namespace(provider="mail"))

        data = json.loads((tmp_path / ".kubera_credentials.json").read_text())
        assert len(data) == 1
        assert data[0]["email"] == "new@gmail.com"


class TestUpbitCredentialAdd:
    def test_add_upbit_credential(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        keys = iter(["test-access-key", "test-secret-key"])
        monkeypatch.setattr("getpass.getpass", lambda _: next(keys))

        from kubera.cli.commands import _cmd_credential_add

        args = argparse.Namespace(provider="upbit")
        _cmd_credential_add(args)

        data = json.loads((tmp_path / ".kubera_credentials.json").read_text())
        assert len(data) == 1
        cred = data[0]
        assert cred["provider"] == "upbit"
        assert cred["access_key"] == "test-access-key"
        assert cred["secret_key"] == "test-secret-key"

    def test_list_masks_upbit_keys(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        cred_file = tmp_path / ".kubera_credentials.json"
        cred_file.write_text(json.dumps([{
            "provider": "upbit",
            "access_key": "my-access-key",
            "secret_key": "my-secret-key",
        }]))

        from kubera.cli.commands import _cmd_credential_list

        _cmd_credential_list()
        out = capsys.readouterr().out
        assert "upbit" in out
        assert "my-access-key" not in out
        assert "my-secret-key" not in out
        assert "***" in out


class TestMailCredentialList:
    def test_list_empty(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        from kubera.cli.commands import _cmd_credential_list

        _cmd_credential_list()
        out = capsys.readouterr().out
        assert "No credentials" in out

    def test_list_shows_mail(self, tmp_path, monkeypatch, capsys):
        monkeypatch.chdir(tmp_path)
        cred_file = tmp_path / ".kubera_credentials.json"
        cred_file.write_text(json.dumps([{
            "provider": "mail",
            "imap_host": "imap.gmail.com",
            "imap_port": "993",
            "email": "user@gmail.com",
            "password": "secret",
            "sender_filter": "banksalad",
        }]))

        from kubera.cli.commands import _cmd_credential_list

        _cmd_credential_list()
        out = capsys.readouterr().out
        assert "mail" in out
        assert "user@gmail.com" in out
        # Password must be masked
        assert "secret" not in out
        assert "***" in out


class TestMailCredentialRemove:
    def test_remove_existing(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        cred_file = tmp_path / ".kubera_credentials.json"
        cred_file.write_text(json.dumps([{
            "provider": "mail",
            "imap_host": "imap.gmail.com",
            "email": "user@gmail.com",
            "password": "secret",
        }]))

        from kubera.cli.commands import _cmd_credential_remove

        _cmd_credential_remove(argparse.Namespace(provider="mail"))
        data = json.loads(cred_file.read_text())
        assert data == []

    def test_remove_nonexistent(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        import pytest
        from kubera.cli.commands import _cmd_credential_remove

        with pytest.raises(SystemExit):
            _cmd_credential_remove(argparse.Namespace(provider="mail"))
