"""Tests for Banksalad Excel parser."""

from datetime import date
from decimal import Decimal
from pathlib import Path
import tempfile
import zipfile

import pytest
from openpyxl import Workbook

from kubera.core.snapshot.parser import BanksaladParser, ParseError, _extract_date


def _create_test_xlsx(path: Path, include_sections: bool = True):
    """Create a test Banksalad xlsx matching real export structure.

    Real structure: section markers in col B, headers use Korean labels,
    data columns vary by section.  See parser.py for keyword mapping.
    """
    wb = Workbook()
    ws = wb.active

    if not include_sections:
        wb.save(path)
        wb.close()
        return

    row = 2
    # --- 1. Customer info ---
    ws.cell(row=row, column=2, value="1.고객정보")
    row += 1
    ws.cell(row=row, column=2, value="사용자의 기본 정보에 해당하는 항목입니다.")
    row += 1
    # Header
    ws.cell(row=row, column=2, value="이름")
    ws.cell(row=row, column=5, value="신용점수\n(KCB)")
    row += 1
    # Data
    ws.cell(row=row, column=2, value="홍길동")
    ws.cell(row=row, column=5, value=850)
    row += 2

    # --- 3. Finance ---
    ws.cell(row=row, column=2, value="3.재무현황")
    row += 1
    ws.cell(row=row, column=2, value="description text")
    row += 1
    # Super-header
    ws.cell(row=row, column=2, value="자산")
    ws.cell(row=row, column=6, value="부채")
    row += 1
    # Column headers
    ws.cell(row=row, column=2, value="항목")
    ws.cell(row=row, column=3, value="상품명")
    ws.cell(row=row, column=5, value="금액")
    ws.cell(row=row, column=6, value="항목")
    ws.cell(row=row, column=7, value="상품명")
    ws.cell(row=row, column=9, value="금액")
    header_row = row
    row += 1
    # Data rows
    ws.cell(row=row, column=2, value="예금")
    ws.cell(row=row, column=3, value="신한 정기예금")
    ws.cell(row=row, column=5, value=50000000)
    ws.cell(row=row, column=6, value="장기대출")
    ws.cell(row=row, column=7, value="주택담보대출")
    ws.cell(row=row, column=9, value=20000000)
    row += 1
    ws.cell(row=row, column=3, value="우리 적금")
    ws.cell(row=row, column=5, value=30000000)
    row += 1
    # Totals row
    ws.cell(row=row, column=2, value="총자산")
    ws.cell(row=row, column=5, value=100000000)
    ws.cell(row=row, column=6, value="총부채")
    ws.cell(row=row, column=9, value=20000000)
    row += 1
    ws.cell(row=row, column=2, value="순자산")
    row += 2

    # --- 4. Insurance ---
    ws.cell(row=row, column=2, value="4.보험현황")
    row += 1
    ws.cell(row=row, column=2, value="description text")
    row += 1
    ws.cell(row=row, column=2, value="금융사")
    ws.cell(row=row, column=3, value="보험명")
    ws.cell(row=row, column=5, value="계약상태")
    ws.cell(row=row, column=6, value="총납입금")
    ws.cell(row=row, column=7, value="계약일자")
    ws.cell(row=row, column=8, value="만기일자")
    row += 1
    ws.cell(row=row, column=2, value="삼성생명")
    ws.cell(row=row, column=3, value="종신보험")
    ws.cell(row=row, column=5, value="유지")
    ws.cell(row=row, column=6, value=5000000)
    ws.cell(row=row, column=7, value="2020-01-01")
    ws.cell(row=row, column=8, value="2040-01-01")
    row += 1
    ws.cell(row=row, column=2, value="합계")
    row += 2

    # --- 5. Investment ---
    ws.cell(row=row, column=2, value="5.투자현황")
    row += 1
    ws.cell(row=row, column=2, value="description text")
    row += 1
    ws.cell(row=row, column=2, value="투자상품종류")
    ws.cell(row=row, column=3, value="금융사")
    ws.cell(row=row, column=4, value="상품명")
    ws.cell(row=row, column=6, value="투자원금")
    ws.cell(row=row, column=7, value="평가금액")
    ws.cell(row=row, column=8, value="수익률")
    row += 1
    ws.cell(row=row, column=2, value="주식")
    ws.cell(row=row, column=3, value="삼성증권")
    ws.cell(row=row, column=4, value="KODEX 200")
    ws.cell(row=row, column=6, value=10000000)
    ws.cell(row=row, column=7, value=11000000)
    ws.cell(row=row, column=8, value=10.0)
    row += 1
    ws.cell(row=row, column=2, value="합계")
    row += 2

    # --- 6. Loan ---
    ws.cell(row=row, column=2, value="6.대출현황")
    row += 1
    ws.cell(row=row, column=2, value="description text")
    row += 1
    ws.cell(row=row, column=2, value="대출종류")
    ws.cell(row=row, column=3, value="금융사")
    ws.cell(row=row, column=4, value="상품명")
    ws.cell(row=row, column=6, value="대출원금")
    ws.cell(row=row, column=7, value="대출잔액")
    ws.cell(row=row, column=8, value="대출금리")
    ws.cell(row=row, column=9, value="대출신규일")
    ws.cell(row=row, column=10, value="대출만기일")
    row += 1
    ws.cell(row=row, column=2, value="신용")
    ws.cell(row=row, column=3, value="우리은행")
    ws.cell(row=row, column=4, value="주택담보대출")
    ws.cell(row=row, column=6, value=200000000)
    ws.cell(row=row, column=7, value=180000000)
    ws.cell(row=row, column=8, value=3.5)
    ws.cell(row=row, column=9, value="2023-01-01")
    ws.cell(row=row, column=10, value="2053-01-01")
    row += 1
    ws.cell(row=row, column=2, value="합계")

    # --- Sheet 2: Ledger (가계부 내역) ---
    ws2 = wb.create_sheet("가계부 내역")
    # Header row
    ws2.cell(row=1, column=1, value="날짜")
    ws2.cell(row=1, column=2, value="시간")
    ws2.cell(row=1, column=3, value="타입")
    ws2.cell(row=1, column=4, value="대분류")
    ws2.cell(row=1, column=5, value="소분류")
    ws2.cell(row=1, column=6, value="내용")
    ws2.cell(row=1, column=7, value="금액")
    ws2.cell(row=1, column=8, value="화폐")
    ws2.cell(row=1, column=9, value="결제수단")
    ws2.cell(row=1, column=10, value="메모")
    # Data rows
    ws2.cell(row=2, column=1, value="2025-01-14")
    ws2.cell(row=2, column=2, value="12:30:00")
    ws2.cell(row=2, column=3, value="지출")
    ws2.cell(row=2, column=4, value="식비")
    ws2.cell(row=2, column=5, value="외식")
    ws2.cell(row=2, column=6, value="점심식사")
    ws2.cell(row=2, column=7, value=-15000)
    ws2.cell(row=2, column=8, value="KRW")
    ws2.cell(row=2, column=9, value="신한카드")
    ws2.cell(row=2, column=10, value=None)
    # 수입 row
    ws2.cell(row=3, column=1, value="2025-01-10")
    ws2.cell(row=3, column=3, value="수입")
    ws2.cell(row=3, column=4, value="급여")
    ws2.cell(row=3, column=7, value=3000000)
    ws2.cell(row=3, column=8, value="KRW")
    # 이체 row (should be filtered out)
    ws2.cell(row=4, column=1, value="2025-01-12")
    ws2.cell(row=4, column=3, value="이체")
    ws2.cell(row=4, column=4, value="이체")
    ws2.cell(row=4, column=7, value=-500000)
    ws2.cell(row=4, column=8, value="KRW")

    wb.save(path)
    wb.close()


class TestExtractDate:
    def test_extract_end_date(self):
        d = _extract_date("2025-01-01~2025-01-15")
        assert d == date(2025, 1, 15)

    def test_extract_from_full_filename(self):
        d = _extract_date("2025-03-01~2025-03-31.xlsx")
        assert d == date(2025, 3, 31)

    def test_invalid_filename_raises(self):
        with pytest.raises(ValueError):
            _extract_date("invalid_file.xlsx")


class TestBanksaladParser:
    def test_full_parse(self, tmp_path):
        xlsx_path = tmp_path / "2025-01-01~2025-01-15.xlsx"
        _create_test_xlsx(xlsx_path)

        parser = BanksaladParser()
        result = parser.parse(xlsx_path)

        assert result.snapshot_date == date(2025, 1, 15)
        assert result.source == "banksalad"
        assert result.credit_score == 850
        assert result.total_assets == Decimal("100000000")
        assert result.total_liabilities == Decimal("20000000")
        assert result.net_worth == Decimal("80000000")

        assert len(result.asset_entries) == 2
        assert result.asset_entries[0]["category"] == "예금"
        assert result.asset_entries[0]["product_name"] == "신한 정기예금"
        assert result.asset_entries[0]["amount"] == Decimal("50000000")

        assert len(result.investment_entries) == 1
        assert result.investment_entries[0]["broker"] == "삼성증권"
        assert result.investment_entries[0]["current_value"] == Decimal("11000000")

        assert len(result.loan_entries) == 1
        assert result.loan_entries[0]["lender"] == "우리은행"
        assert result.loan_entries[0]["balance"] == Decimal("180000000")

        assert len(result.insurance_entries) == 1
        assert result.insurance_entries[0]["insurer"] == "삼성생명"
        assert result.insurance_entries[0]["status"] == "유지"

        # Ledger entries (이체 filtered out)
        assert len(result.ledger_entries) == 2
        expense = next(e for e in result.ledger_entries if e["entry_type"] == "지출")
        assert expense["entry_date"] == date(2025, 1, 14)
        assert expense["major_category"] == "식비"
        assert expense["minor_category"] == "외식"
        assert expense["amount"] == Decimal("-15000")
        assert expense["currency"] == "KRW"
        assert expense["payment_method"] == "신한카드"

        income = next(e for e in result.ledger_entries if e["entry_type"] == "수입")
        assert income["entry_date"] == date(2025, 1, 10)
        assert income["major_category"] == "급여"
        assert income["amount"] == Decimal("3000000")

    def test_ledger_filters_transfer(self, tmp_path):
        """이체 type entries must be excluded."""
        xlsx_path = tmp_path / "2025-01-01~2025-01-15.xlsx"
        _create_test_xlsx(xlsx_path)

        parser = BanksaladParser()
        result = parser.parse(xlsx_path)

        types = {e["entry_type"] for e in result.ledger_entries}
        assert "이체" not in types
        assert types <= {"수입", "지출"}

    def test_no_sheet2_returns_empty_ledger(self, tmp_path):
        """When xlsx has only 1 sheet, ledger_entries should be empty."""
        xlsx_path = tmp_path / "2025-01-01~2025-01-15.xlsx"
        wb = Workbook()
        ws = wb.active
        # Minimal sheet 1 with required sections
        ws.cell(row=2, column=2, value="1.고객정보")
        ws.cell(row=4, column=2, value="이름")
        ws.cell(row=4, column=5, value="신용점수\n(KCB)")
        ws.cell(row=5, column=5, value=800)
        ws.cell(row=7, column=2, value="3.재무현황")
        ws.cell(row=9, column=2, value="항목")
        ws.cell(row=9, column=3, value="상품명")
        ws.cell(row=9, column=5, value="금액")
        ws.cell(row=10, column=2, value="총자산")
        ws.cell(row=10, column=5, value=0)
        wb.save(xlsx_path)
        wb.close()

        parser = BanksaladParser()
        result = parser.parse(xlsx_path)
        assert result.ledger_entries == []

    def test_missing_required_sections_raises(self, tmp_path):
        xlsx_path = tmp_path / "2025-02-01~2025-02-28.xlsx"
        _create_test_xlsx(xlsx_path, include_sections=False)

        parser = BanksaladParser()
        with pytest.raises(ParseError, match="Required section"):
            parser.parse(xlsx_path)

    def test_zip_file(self, tmp_path):
        xlsx_path = tmp_path / "2025-01-01~2025-01-15.xlsx"
        _create_test_xlsx(xlsx_path)

        zip_path = tmp_path / "2025-01-01~2025-01-15.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.write(xlsx_path, "2025-01-01~2025-01-15.xlsx")

        parser = BanksaladParser()
        result = parser.parse(zip_path)

        assert result.snapshot_date == date(2025, 1, 15)
        assert result.source == "banksalad"
        assert result.credit_score == 850
        assert len(result.asset_entries) == 2

    def test_zip_with_password(self, tmp_path):
        # stdlib zipfile can only extract (not create) password-protected zips.
        # We test the code path by creating an unprotected zip and passing None.
        xlsx_path = tmp_path / "2025-06-01~2025-06-30.xlsx"
        _create_test_xlsx(xlsx_path)

        zip_path = tmp_path / "2025-06-01~2025-06-30.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.write(xlsx_path, "2025-06-01~2025-06-30.xlsx")

        parser = BanksaladParser()
        result = parser.parse(zip_path, password=None)
        assert result.snapshot_date == date(2025, 6, 30)

    def test_no_xlsx_in_zip_raises(self, tmp_path):
        zip_path = tmp_path / "2025-01-01~2025-01-15.zip"
        with zipfile.ZipFile(zip_path, "w") as zf:
            zf.writestr("readme.txt", "nothing here")

        parser = BanksaladParser()
        with pytest.raises(ValueError, match="No .xlsx file found"):
            parser.parse(zip_path)
