"""Tests for settings and configuration."""

import os
from pathlib import Path

from kubera.core.config import Settings


class TestSettings:
    def test_defaults(self):
        settings = Settings(
            _env_file=None,  # ignore any .env in the repo
        )
        assert settings.database_url == "sqlite:///kubera.db"
        assert settings.host == "0.0.0.0"
        assert settings.port == 8000
        assert settings.debug is False
        assert settings.cors_origins == ["*"]

    def test_env_override(self, monkeypatch):
        monkeypatch.setenv("KUBERA_PORT", "9999")
        monkeypatch.setenv("KUBERA_DEBUG", "true")
        settings = Settings(_env_file=None)
        assert settings.port == 9999
        assert settings.debug is True

    def test_token_auto_generation(self, tmp_path, monkeypatch):
        monkeypatch.chdir(tmp_path)
        settings = Settings(_env_file=None)
        assert settings.secret_token is None

        token = settings.ensure_token()
        assert len(token) > 20
        assert settings.secret_token == token

        # Verify .env was written
        env_content = (tmp_path / ".env").read_text()
        assert f"KUBERA_SECRET_TOKEN={token}" in env_content

    def test_token_not_regenerated_if_set(self):
        settings = Settings(_env_file=None, secret_token="my-fixed-token")
        token = settings.ensure_token()
        assert token == "my-fixed-token"

    def test_mail_watch_interval_default(self):
        settings = Settings(_env_file=None)
        assert settings.mail_watch_interval == 300

    def test_snapshot_zip_password_default(self):
        settings = Settings(_env_file=None)
        assert settings.snapshot_zip_password is None

    def test_mail_watch_interval_env_override(self, monkeypatch):
        monkeypatch.setenv("KUBERA_MAIL_WATCH_INTERVAL", "60")
        settings = Settings(_env_file=None)
        assert settings.mail_watch_interval == 60

    def test_snapshot_zip_password_env_override(self, monkeypatch):
        monkeypatch.setenv("KUBERA_SNAPSHOT_ZIP_PASSWORD", "s3cr3t")
        settings = Settings(_env_file=None)
        assert settings.snapshot_zip_password == "s3cr3t"
