"""Tests for Upbit exchange integration."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from kubera.core.exchange.upbit import UpbitClient

SAMPLE_ACCOUNTS = [
    {
        "currency": "BTC",
        "balance": "0.005",
        "locked": "0.0",
        "avg_buy_price": "50000000",
        "avg_buy_price_modified": False,
        "unit_currency": "KRW",
    },
    {
        "currency": "KRW",
        "balance": "1000000",
        "locked": "0",
        "avg_buy_price": "0",
        "avg_buy_price_modified": False,
        "unit_currency": "KRW",
    },
]


class TestUpbitClient:
    def test_create_token_structure(self):
        import jwt

        client = UpbitClient(access_key="test-ak", secret_key="test-sk")
        token = client._create_token()
        decoded = jwt.decode(token, "test-sk", algorithms=["HS256"])
        assert decoded["access_key"] == "test-ak"
        assert "nonce" in decoded

    @patch("kubera.core.exchange.upbit.httpx.get")
    def test_get_accounts_success(self, mock_get):
        mock_resp = MagicMock()
        mock_resp.status_code = 200
        mock_resp.json.return_value = SAMPLE_ACCOUNTS
        mock_get.return_value = mock_resp

        client = UpbitClient(access_key="ak", secret_key="sk")
        result = client.get_accounts()

        assert len(result) == 2
        assert result[0]["currency"] == "BTC"
        mock_get.assert_called_once()

    @patch("kubera.core.exchange.upbit.httpx.get")
    def test_get_accounts_api_error(self, mock_get):
        from kubera.api.errors import KuberaError

        mock_resp = MagicMock()
        mock_resp.status_code = 401
        mock_get.return_value = mock_resp

        client = UpbitClient(access_key="ak", secret_key="sk")
        with pytest.raises(KuberaError) as exc_info:
            client.get_accounts()
        assert exc_info.value.code == "UPBIT_API_ERROR"


class TestUpbitBalancesEndpoint:
    @patch("kubera.api.routers.exchange.UpbitClient")
    @patch("kubera.api.routers.exchange.get_credential")
    def test_returns_balances(self, mock_get_cred, mock_client_cls, client, auth_headers):
        mock_get_cred.return_value = {"provider": "upbit", "access_key": "ak", "secret_key": "sk"}
        mock_client_cls.return_value.get_accounts.return_value = SAMPLE_ACCOUNTS

        resp = client.get("/api/v1/exchange/upbit/balances", headers=auth_headers)
        assert resp.status_code == 200
        data = resp.json()
        assert len(data) == 2
        assert data[0]["currency"] == "BTC"
        assert data[0]["balance"] == "0.005"

    @patch("kubera.api.routers.exchange.get_credential")
    def test_missing_credential(self, mock_get_cred, client, auth_headers):
        mock_get_cred.return_value = None

        resp = client.get("/api/v1/exchange/upbit/balances", headers=auth_headers)
        assert resp.status_code == 400
        assert resp.json()["code"] == "CREDENTIAL_NOT_FOUND"

    def test_requires_auth(self, client):
        resp = client.get("/api/v1/exchange/upbit/balances")
        assert resp.status_code == 401
