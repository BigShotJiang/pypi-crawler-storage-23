# Nex Sovereign SDK — Python

The official Python SDK for [Nex Sovereign](https://nexsovereign.com) — a cognitive AI operating system with an 18-emotion HEART Engine, persistent memory graph, PDAR reasoning, and boardroom governance.

## Install

```bash
pip install nex-sovereign-sdk
```

## Quick Start

```python
from nex_sdk import NexClient

nex = NexClient(api_key="nex_sk_...")

# Classify emotional content via HEART Engine
result = nex.heart.classify("user_123", "I'm excited about this project!")
print(result.classified.label)   # "happiness"
print(result.emotion_vector)     # full 18-dim vector
```

## Features

- **HEART Engine** — 18-dimensional emotion classification, injection, history, and pattern analysis
- **Memory Graph** — Persistent semantic memory with emotionally-biased retrieval
- **PDAR Reasoning** — Transparent Perceive-Decide-Act-Reflect reasoning traces
- **Boardroom** — Governance mandates for high-stakes AI actions

## Documentation

Full API reference and guides: [nexsovereign.com/developers](https://nexsovereign.com/developers)

## License

MIT
