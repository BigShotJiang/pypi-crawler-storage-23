"""Nex SDK Exceptions."""


class NexError(Exception):
    """Base exception for all Nex SDK errors."""

    def __init__(self, message: str, status_code: int = 0, request_id: str | None = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.request_id = request_id

    def __repr__(self) -> str:
        return f"{type(self).__name__}(status={self.status_code}, message={self.message!r})"


class NexAuthError(NexError):
    """Raised on 401/403 — invalid or expired API key."""


class NexRateLimitError(NexError):
    """Raised on 429 — rate limit exceeded."""

    def __init__(self, message: str, retry_after: int = 60, **kwargs):
        super().__init__(message, status_code=429, **kwargs)
        self.retry_after = retry_after


class NexNotFoundError(NexError):
    """Raised on 404 — resource not found."""


class NexValidationError(NexError):
    """Raised on 422 — request validation failed."""
