"""
Nex Sovereign SDK — Main Client

Wraps the Nex HTTP API with typed methods, automatic retries,
and rate-limit awareness.

Usage:
    nex = NexClient(api_key="nex_sk_...")
    state = nex.heart.get_state("user_123")
"""

from __future__ import annotations

import time
from typing import Any, Optional

import httpx

from .exceptions import (
    NexAuthError,
    NexError,
    NexNotFoundError,
    NexRateLimitError,
    NexValidationError,
)
from .models import (
    AgentRecommendation,
    ClassifiedEmotion,
    ClassifyResult,
    EmotionalContext,
    EmotionalState,
    HeartState,
    MandateResult,
    MandateStatus,
    MemoryNode,
    MemoryQueryResult,
    ReasoningTrace,
)

DEFAULT_BASE_URL = "https://nex-ai-os.onrender.com"
DEFAULT_TIMEOUT = 30.0


class _BaseNamespace:
    def __init__(self, client: "NexClient"):
        self._client = client

    def _get(self, path: str, **params) -> dict:
        return self._client._request("GET", path, params=params)

    def _post(self, path: str, body: dict) -> dict:
        return self._client._request("POST", path, json=body)


# ---------------------------------------------------------------------------
# Heart namespace
# ---------------------------------------------------------------------------

class HeartNamespace(_BaseNamespace):
    """Emotional intelligence (HEART Engine v4) methods."""

    def get_state(self, user_id: str) -> HeartState:
        """
        Get the full 18-dimensional emotional state for a user.

        Args:
            user_id: The user whose emotional state to query.

        Returns:
            HeartState with emotion_vector, dominant emotion, and proxies.
        """
        data = self._get("/sdk/v1/heart/state", user_id=user_id)
        es = data["emotional_state"]
        ctx = data["context"]
        return HeartState(
            user_id=data["user_id"],
            emotional_state=EmotionalState(
                dominant_emotion=es["dominant_emotion"],
                intensity=es["intensity"],
                confidence=es["confidence"],
                valence=es["valence"],
                energy_level=es["energy_level"],
                stress_level=es["stress_level"],
                dopamine=es["dopamine"],
                cortisol=es["cortisol"],
            ),
            emotion_vector=data.get("emotion_vector", {}),
            context=EmotionalContext(
                recent_wins=ctx["recent_wins"],
                stressors=ctx["stressors"],
                mood_trend=ctx["mood_trend"],
            ),
            timestamp=data["timestamp"],
        )

    def classify(
        self,
        user_id: str,
        text: str,
        personality_bias: float = 1.0,
        save_state: bool = True,
    ) -> ClassifyResult:
        """
        Classify the emotional content of text using HEART Engine v4.

        Args:
            user_id: The user context for classification.
            text: The text to classify (max 4000 chars).
            personality_bias: Personality weighting (0.0–2.0, default 1.0).
            save_state: Whether to persist the classified state to history.

        Returns:
            ClassifyResult with dominant emotion, 18-dim vector, and trajectory.
        """
        data = self._post("/v1/heart/classify", {
            "user_id": user_id,
            "text": text,
            "personality_bias": personality_bias,
            "save_state": save_state,
        })
        c = data["classified"]
        return ClassifyResult(
            user_id=data["user_id"],
            classified=ClassifiedEmotion(
                label=c["label"],
                intensity=c["intensity"],
                confidence=c["confidence"],
                valence=c["valence"],
            ),
            emotion_vector=data.get("emotion_vector", {}),
            trajectory=data.get("trajectory", {}),
            timestamp=data["timestamp"],
        )

    def inject(self, user_id: str, emotion: str, intensity: float, context: Optional[dict] = None) -> dict:
        """
        Inject an emotional state directly (bypasses LLM classification).

        Args:
            user_id: Target user ID.
            emotion: One of the 18 canonical HEART emotions.
            intensity: Emotion intensity (0.0–1.0).
            context: Optional metadata dict.

        Returns:
            Confirmation dict with ok, user_id, injected state, timestamp.
        """
        return self._post("/v1/heart/inject", {
            "user_id": user_id,
            "emotion": emotion,
            "intensity": intensity,
            "context": context,
        })

    def get_history(self, user_id: str, limit: int = 50, since: Optional[float] = None) -> list[dict]:
        """Get recent emotional state history for a user."""
        params: dict[str, Any] = {"user_id": user_id, "limit": limit}
        if since is not None:
            params["since"] = since
        data = self._get("/v1/heart/history", **params)
        return data.get("history", [])

    def get_patterns(self, user_id: str, window_hours: int = 168) -> dict:
        """Get computed emotional patterns (frequency, trend, streak) for a user."""
        data = self._get("/v1/heart/patterns", user_id=user_id, window_hours=window_hours)
        return data.get("patterns", {})


# ---------------------------------------------------------------------------
# Memory namespace
# ---------------------------------------------------------------------------

class MemoryNamespace(_BaseNamespace):
    """Persistent Memory Graph methods."""

    def query(
        self,
        user_id: str,
        query: str,
        context: str = "",
        limit: int = 10,
    ) -> MemoryQueryResult:
        """
        Query the persistent memory graph for a user.

        Args:
            user_id: The user whose memory to query.
            query: Search query string.
            context: Additional context for retrieval.
            limit: Maximum nodes to return (1–100).

        Returns:
            MemoryQueryResult with matching memory nodes and confidence.
        """
        data = self._post("/sdk/v1/memory/query", {
            "user_id": user_id,
            "query": query,
            "context": context,
            "limit": limit,
        })
        nodes = [
            MemoryNode(
                id=n["id"],
                type=n["type"],
                content=n["content"],
                timestamp=n["timestamp"],
            )
            for n in data.get("nodes", [])
        ]
        return MemoryQueryResult(
            nodes=nodes,
            confidence=data["confidence"],
            timestamp=data["timestamp"],
        )


# ---------------------------------------------------------------------------
# Reasoning namespace
# ---------------------------------------------------------------------------

class ReasoningNamespace(_BaseNamespace):
    """PDAR Reasoning Trace transparency methods."""

    def get_trace(self, session_id: str) -> ReasoningTrace:
        """
        Get the current PDAR reasoning trace for a session.

        Shows Perceive → Decide → Act → Reflect steps with messages.

        Args:
            session_id: The session or user ID to get the trace for.

        Returns:
            ReasoningTrace with stage messages and confidence.
        """
        data = self._get("/sdk/v1/reasoning/trace", session_id=session_id)
        return ReasoningTrace(
            session_id=data["session_id"],
            trace=data["trace"],
            timestamp=data["timestamp"],
            confidence=data["confidence"],
        )


# ---------------------------------------------------------------------------
# Boardroom namespace
# ---------------------------------------------------------------------------

class BoardroomNamespace(_BaseNamespace):
    """Governance / Boardroom mandate methods."""

    def create_mandate(
        self,
        user_id: str,
        action_type: str,
        amount: Optional[float] = None,
        recipient: Optional[str] = None,
        reason: Optional[str] = None,
    ) -> MandateResult:
        """
        Create a governance mandate for a high-stakes action.

        CEO and CTO agents review the action and provide recommendations.
        Amounts over $10,000 require manual review.

        Args:
            user_id: The requesting user.
            action_type: Type of action (e.g., "budget_allocation", "partnership").
            amount: Optional financial amount.
            recipient: Optional recipient identifier.
            reason: Optional reason/description.

        Returns:
            MandateResult with mandate_id, status, and agent recommendations.
        """
        data = self._post("/sdk/v1/boardroom/mandate", {
            "user_id": user_id,
            "action": {
                "type": action_type,
                "amount": amount,
                "recipient": recipient,
                "reason": reason,
            },
        })
        return MandateResult(
            mandate_id=data["mandate_id"],
            status=data["status"],
            ceo_recommendation=AgentRecommendation(**data["ceo_recommendation"]),
            cto_recommendation=AgentRecommendation(**data["cto_recommendation"]),
            approval_url=data["approval_url"],
        )

    def get_mandate_status(self, mandate_id: str) -> MandateStatus:
        """
        Poll the status of an existing mandate.

        Args:
            mandate_id: The mandate ID returned from create_mandate().

        Returns:
            MandateStatus with current status and user decision (if any).
        """
        data = self._get(f"/sdk/v1/boardroom/mandate/{mandate_id}")
        return MandateStatus(
            mandate_id=data["mandate_id"],
            status=data["status"],
            user_decision=data.get("user_decision"),
            timestamp=data["timestamp"],
        )


# ---------------------------------------------------------------------------
# Main client
# ---------------------------------------------------------------------------

class NexClient:
    """
    Nex Sovereign API Client.

    Args:
        api_key: Your SDK API key (starts with "nex_sk_").
        base_url: API base URL. Defaults to production.
        timeout: Request timeout in seconds.

    Example:
        nex = NexClient(api_key="nex_sk_...")
        state = nex.heart.get_state("user_123")
        result = nex.memory.query("user_123", "recent goals")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        if not api_key.startswith("nex_sk_"):
            raise ValueError("API key must start with 'nex_sk_'. Get one at nexsovereign.com/developers")

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._http = httpx.Client(
            base_url=self._base_url,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": f"nex-sdk-python/0.1.0",
            },
            timeout=timeout,
        )

        # Namespaces
        self.heart = HeartNamespace(self)
        self.memory = MemoryNamespace(self)
        self.reasoning = ReasoningNamespace(self)
        self.boardroom = BoardroomNamespace(self)

    def _request(self, method: str, path: str, **kwargs) -> dict:
        """Execute an HTTP request and raise typed exceptions on error."""
        try:
            response = self._http.request(method, path, **kwargs)
        except httpx.TimeoutException as e:
            raise NexError(f"Request timed out: {e}") from e
        except httpx.RequestError as e:
            raise NexError(f"Network error: {e}") from e

        request_id = response.headers.get("x-request-id")

        if response.status_code == 200:
            return response.json()

        # Parse error body
        try:
            body = response.json()
            message = body.get("error") or body.get("detail") or response.text
        except Exception:
            message = response.text

        if response.status_code == 401:
            raise NexAuthError(message, status_code=401, request_id=request_id)
        if response.status_code == 403:
            raise NexAuthError(message, status_code=403, request_id=request_id)
        if response.status_code == 404:
            raise NexNotFoundError(message, status_code=404, request_id=request_id)
        if response.status_code == 422:
            raise NexValidationError(message, status_code=422, request_id=request_id)
        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", 60))
            raise NexRateLimitError(message, retry_after=retry_after, request_id=request_id)

        raise NexError(message, status_code=response.status_code, request_id=request_id)

    def close(self):
        """Close the underlying HTTP client."""
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
