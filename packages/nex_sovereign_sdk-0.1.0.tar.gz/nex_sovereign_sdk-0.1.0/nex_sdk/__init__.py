"""
Nex Sovereign SDK — Python Client

Provides access to Nex's cognitive AI layer: emotional intelligence (HEART),
memory graph, PDAR reasoning transparency, and governance (Boardroom).

Usage:
    from nex_sdk import NexClient

    nex = NexClient(api_key="nex_sk_...")
    state = nex.heart.get_state(user_id="user_123")
    print(state.emotional_state.dominant_emotion)
"""

from .client import NexClient
from .exceptions import NexError, NexAuthError, NexRateLimitError, NexNotFoundError

__version__ = "0.1.0"
__all__ = ["NexClient", "NexError", "NexAuthError", "NexRateLimitError", "NexNotFoundError"]
