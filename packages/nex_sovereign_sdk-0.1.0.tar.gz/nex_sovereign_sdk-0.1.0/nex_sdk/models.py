"""
Nex SDK — Response Models

Typed dataclasses for all API responses, matching the server's JSON output.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional


# ---------------------------------------------------------------------------
# HEART / Emotional State
# ---------------------------------------------------------------------------

@dataclass
class EmotionalState:
    dominant_emotion: str
    intensity: float
    confidence: float
    valence: str          # "positive" | "negative" | "neutral"
    energy_level: str     # "high" | "medium" | "low"
    stress_level: str     # "high" | "medium" | "low"
    dopamine: int         # 0-100 proxy
    cortisol: int         # 0-100 proxy


@dataclass
class EmotionalContext:
    recent_wins: list[str]
    stressors: list[str]
    mood_trend: str       # "improving" | "stable" | "declining"


@dataclass
class HeartState:
    user_id: str
    emotional_state: EmotionalState
    emotion_vector: dict[str, float]  # 18-dim canonical emotion vector
    context: EmotionalContext
    timestamp: str


@dataclass
class ClassifiedEmotion:
    label: str
    intensity: float
    confidence: float
    valence: str


@dataclass
class ClassifyResult:
    user_id: str
    classified: ClassifiedEmotion
    emotion_vector: dict[str, float]
    trajectory: dict[str, Any]
    timestamp: float


# ---------------------------------------------------------------------------
# Memory Graph
# ---------------------------------------------------------------------------

@dataclass
class MemoryNode:
    id: str
    type: str
    content: dict[str, Any]
    timestamp: float


@dataclass
class MemoryQueryResult:
    nodes: list[MemoryNode]
    confidence: float
    timestamp: str


# ---------------------------------------------------------------------------
# PDAR Reasoning Trace
# ---------------------------------------------------------------------------

@dataclass
class ReasoningTrace:
    session_id: str
    trace: dict[str, str]  # keys: perceive, decide, act, reflect
    timestamp: str
    confidence: float


# ---------------------------------------------------------------------------
# Boardroom / Governance
# ---------------------------------------------------------------------------

@dataclass
class AgentRecommendation:
    decision: str    # "approve" | "deny" | "review_carefully"
    reasoning: str


@dataclass
class MandateResult:
    mandate_id: str
    status: str
    ceo_recommendation: AgentRecommendation
    cto_recommendation: AgentRecommendation
    approval_url: str


@dataclass
class MandateStatus:
    mandate_id: str
    status: str
    user_decision: Optional[str]
    timestamp: str
