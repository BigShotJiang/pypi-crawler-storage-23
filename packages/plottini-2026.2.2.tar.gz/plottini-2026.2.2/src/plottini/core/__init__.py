"""Core functionality for data parsing, plotting, and exporting."""
