"""Tests for Plottini package."""
