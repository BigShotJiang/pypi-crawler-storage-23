"""Synthetic provider status plugin."""

