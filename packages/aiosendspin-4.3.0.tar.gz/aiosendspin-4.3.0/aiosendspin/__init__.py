"""Sendspin: Python implementation of the Sendspin Protocol."""
