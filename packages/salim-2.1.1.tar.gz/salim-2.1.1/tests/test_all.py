"""
Salim v12 — Comprehensive Test Suite
Tests every handler module for correctness, edge cases, and integration.
Run: python3 -m pytest tests/test_all.py -v
or:  python3 tests/test_all.py
"""
import asyncio
import csv
import io
import json
import os
import re
import sys
import tempfile
import time
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

PASS = "✅"
FAIL = "❌"
SKIP = "⚠️"
results = []


def record(name, passed, detail=""):
    icon = PASS if passed else FAIL
    results.append((icon, name, detail))
    print(f"  {icon} {name}" + (f" — {detail}" if detail else ""))


def section(title):
    print(f"\n{'═'*60}")
    print(f"  {title}")
    print(f"{'═'*60}")


# ══════════════════════════════════════════════════════════════════
# 1. SYNTAX & IMPORT CHECKS
# ══════════════════════════════════════════════════════════════════

section("1. SYNTAX & IMPORT CHECKS")

import ast

handler_dir = Path(__file__).parent.parent / "salim" / "handlers"
all_py = list(Path(__file__).parent.parent.rglob("*.py"))

syntax_errors = []
for f in all_py:
    if "__pycache__" in str(f):
        continue
    try:
        ast.parse(f.read_text())
    except SyntaxError as e:
        syntax_errors.append(f"{f.name}: {e}")

record("All Python files parse cleanly", len(syntax_errors) == 0,
       f"{len(syntax_errors)} errors" if syntax_errors else f"{len(all_py)} files OK")
for e in syntax_errors:
    print(f"    {FAIL} {e}")

# Check all handlers exist
REQUIRED_HANDLERS = [
    "agent", "agent_advanced", "ai_handler", "alerts", "backup_handler",
    "browser", "calendar_handler", "camera", "clipboard_image",
    "code_runner", "crypto_finance", "digest_handler", "document_writer",
    "files", "git_handler", "guard", "heartbeat", "history", "memory",
    "notes_handler", "power", "qr_handler", "reminder_handler",
    "scheduler_handler", "screen", "shell", "skills", "smart_upload",
    "speedtest_handler", "ssh_handler", "stream", "sysmon_handler",
    "system", "tts", "transcript_handler", "translate_handler",
    "vision", "voice", "watcher_handler", "weather", "web_handler",
]
missing = [h for h in REQUIRED_HANDLERS if not (handler_dir / f"{h}.py").exists()]
record("All required handlers present", len(missing) == 0,
       f"Missing: {missing}" if missing else f"{len(REQUIRED_HANDLERS)} handlers found")

# ══════════════════════════════════════════════════════════════════
# 2. DOCUMENT ENGINES
# ══════════════════════════════════════════════════════════════════

section("2. DOCUMENT CREATION ENGINES")

from salim.handlers.agent import (
    create_docx, create_xlsx, create_csv, create_pdf, create_pptx,
    edit_docx, edit_xlsx, edit_csv, read_docx, read_xlsx, read_csv,
)

with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)

    # ── DOCX ──────────────────────────────────────────────────────
    content = """# Invoice

## Client Details
ABC Corporation, Dubai

## Items
| Item | Qty | Price | Total |
|------|-----|-------|-------|
| Web Design | 1 | 5000 | 5000 |
| SEO Package | 3 | 500 | 1500 |

## Summary
- Total: $6,500
- Payment due within 30 days
1. Bank transfer preferred
2. Reference: INV-2025-001
"""
    try:
        p = tmp / "invoice.docx"
        create_docx(content, p, "Invoice #001")
        size = p.stat().st_size
        record("DOCX creation", size > 5000, f"{size} bytes")
    except Exception as e:
        record("DOCX creation", False, str(e))

    # DOCX read-back
    try:
        text = read_docx(tmp / "invoice.docx")
        has_content = "ABC" in text or "Invoice" in text or "5000" in text
        record("DOCX read-back", has_content, f"{len(text)} chars read")
    except Exception as e:
        record("DOCX read-back", False, str(e))

    # DOCX edit - find/replace
    try:
        edit_docx(tmp / "invoice.docx", "replace ABC Corporation with XYZ Ltd", "")
        text_after = read_docx(tmp / "invoice.docx")
        record("DOCX edit (find/replace)", True, "no crash")
    except Exception as e:
        record("DOCX edit (find/replace)", False, str(e))

    # DOCX edge cases
    try:
        p2 = tmp / "empty.docx"
        create_docx("", p2, "Empty Doc")
        record("DOCX empty content", p2.stat().st_size > 0, "empty doc created")
    except Exception as e:
        record("DOCX empty content", False, str(e))

    try:
        long_content = "\n".join([f"Line {i}: " + "x" * 100 for i in range(200)])
        p3 = tmp / "long.docx"
        create_docx(long_content, p3, "Long Document")
        record("DOCX long content (200 lines)", p3.stat().st_size > 10000)
    except Exception as e:
        record("DOCX long content", False, str(e))

    # ── XLSX ──────────────────────────────────────────────────────
    xl_content = """# Monthly Sales Report

| Employee | Department | Sales | Target | Achievement |
|----------|-----------|-------|--------|-------------|
| Ahmed Ali | Sales | 45000 | 40000 | 112% |
| Sara Khan | Sales | 38000 | 40000 | 95% |
| John Smith | Marketing | 52000 | 50000 | 104% |
| Fatima Al | Tech | 29000 | 30000 | 97% |
"""
    try:
        xp = tmp / "sales.xlsx"
        create_xlsx(xl_content, xp, "Sales Report Q1")
        size = xp.stat().st_size
        record("XLSX creation", size > 3000, f"{size} bytes")
    except Exception as e:
        record("XLSX creation", False, str(e))

    # XLSX read-back
    try:
        text = read_xlsx(tmp / "sales.xlsx")
        has_data = "Ahmed" in text or "Sales" in text
        record("XLSX read-back", has_data, f"{len(text)} chars")
    except Exception as e:
        record("XLSX read-back", False, str(e))

    # XLSX edit
    try:
        edit_xlsx(tmp / "sales.xlsx", "add row", "| New Employee | HR | 35000 | 35000 | 100% |")
        record("XLSX edit (add row)", True, "no crash")
    except Exception as e:
        record("XLSX edit", False, str(e))

    # XLSX numeric parsing
    try:
        import openpyxl
        wb = openpyxl.load_workbook(str(tmp / "sales.xlsx"), data_only=True)
        ws = wb.active
        has_numbers = any(
            isinstance(ws.cell(row=r, column=c).value, (int, float))
            for r in range(1, ws.max_row + 1)
            for c in range(1, ws.max_column + 1)
        )
        record("XLSX numeric cells", has_numbers, "numbers stored correctly")
    except Exception as e:
        record("XLSX numeric cells", False, str(e))

    # ── CSV ───────────────────────────────────────────────────────
    csv_content = """| Name | Email | Role | Salary |
|------|-------|------|--------|
| Ahmed | ahmed@co.com | Engineer | 8000 |
| Sara | sara@co.com | Designer | 7000 |
| John | john@co.com | Manager | 12000 |
"""
    try:
        cp = tmp / "staff.csv"
        create_csv(csv_content, cp)
        rows = list(csv.reader(cp.open()))
        record("CSV creation", len(rows) >= 4, f"{len(rows)} rows")
    except Exception as e:
        record("CSV creation", False, str(e))

    # CSV read-back
    try:
        text = read_csv(tmp / "staff.csv")
        record("CSV read-back", "Ahmed" in text or "Name" in text, f"{len(text)} chars")
    except Exception as e:
        record("CSV read-back", False, str(e))

    # CSV edit - add row
    try:
        from salim.handlers.agent import edit_csv
        edit_csv(tmp / "staff.csv", "add row", "| Bob | bob@co.com | Analyst | 9000 |")
        rows_after = list(csv.reader((tmp / "staff.csv").open()))
        record("CSV edit (add row)", len(rows_after) > 4, f"now {len(rows_after)} rows")
    except Exception as e:
        record("CSV edit", False, str(e))

    # ── PDF ───────────────────────────────────────────────────────
    pdf_content = """# Quarterly Report

## Executive Summary
Strong performance across all departments in Q1 2025.

## Financial Highlights
- Revenue: $2.4M (↑ 18%)
- Net Profit: $480K (↑ 22%)
- Operating Margin: 20%

## Department Results
| Department | Revenue | Growth |
|-----------|---------|--------|
| Sales | $1.2M | +25% |
| Services | $800K | +15% |
| Products | $400K | +10% |

## Outlook
Positive trajectory continuing into Q2.
"""
    try:
        pp = tmp / "report.pdf"
        create_pdf(pdf_content, pp, "Q1 2025 Report")
        size = pp.stat().st_size
        record("PDF creation", size > 5000, f"{size} bytes")
        # Verify it's a real PDF
        header = pp.read_bytes()[:4]
        record("PDF valid header", header == b"%PDF", f"header: {header}")
    except Exception as e:
        record("PDF creation", False, str(e))

    # ── PPTX ──────────────────────────────────────────────────────
    pptx_content = """# AI in Business 2025

## Overview
Transforming how companies operate

---
# Market Size

## $450 Billion by 2030
- 38% annual growth
- 94% of enterprises use AI in some form

---
# Key Benefits

## Why AI Matters
- Automation of repetitive tasks
- Data-driven decision making
- 24/7 availability at scale

---
# Implementation Roadmap

## Getting Started
1. Identify use cases
2. Build pilot programs
3. Scale successful pilots
4. Continuous improvement

---
# Thank You

## Questions?
contact@company.com
"""
    try:
        ptp = tmp / "presentation.pptx"
        create_pptx(pptx_content, ptp, "AI in Business")
        size = ptp.stat().st_size
        record("PPTX creation", size > 5000, f"{size} bytes")
        # Check slide count
        from pptx import Presentation
        prs = Presentation(str(ptp))
        record("PPTX slide count", len(prs.slides) >= 4, f"{len(prs.slides)} slides")
    except Exception as e:
        record("PPTX creation", False, str(e))

    # ── Document conversion ───────────────────────────────────────
    try:
        # Test the TXT -> DOCX conversion path
        txt_path = tmp / "notes.txt"
        txt_path.write_text("Meeting notes\n\nDiscussed Q2 targets\nAgreed on 15% growth")
        out = txt_path.with_suffix(".docx")
        create_docx(txt_path.read_text(), out, "Notes")
        record("TXT→DOCX conversion", out.stat().st_size > 0)
    except Exception as e:
        record("TXT→DOCX conversion", False, str(e))

# ══════════════════════════════════════════════════════════════════
# 3. WEATHER HANDLER
# ══════════════════════════════════════════════════════════════════

section("3. WEATHER HANDLER")

from salim.handlers.weather import (
    _geocode, _fetch_weather, _load_location, _save_location, WMO_CODES,
)

# WMO codes coverage
record("WMO codes defined", len(WMO_CODES) >= 20, f"{len(WMO_CODES)} conditions")
record("WMO code 0 (clear)", WMO_CODES.get(0, "") != "", WMO_CODES.get(0, "MISSING"))
record("WMO code 95 (thunderstorm)", WMO_CODES.get(95, "") != "", WMO_CODES.get(95, "MISSING"))

# Location save/load
with tempfile.TemporaryDirectory() as tmpdir:
    with patch("salim.handlers.weather.WEATHER_CFG", Path(tmpdir) / "weather.json"):
        _save_location("London", 51.5074, -0.1278, "London, United Kingdom")
        saved = _load_location()
        record("Weather location save/load", saved.get("city") == "London" and
               saved.get("lat") == 51.5074, str(saved))

# Geocode function - test offline (will fail without network, but should not crash)
try:
    result = asyncio.run(_geocode("TestCity_That_Does_Not_Exist_XYZ"))
    record("Geocode handles unknown city", result is None, "returned None for unknown city")
except Exception as e:
    if "name resolution" in str(e).lower() or "connect" in str(e).lower():
        record("Geocode offline graceful", True, f"network unavailable: {str(e)[:50]}")
    else:
        record("Geocode error handling", False, str(e)[:80])

# ══════════════════════════════════════════════════════════════════
# 4. CALENDAR HANDLER
# ══════════════════════════════════════════════════════════════════

section("4. CALENDAR HANDLER")

from salim.handlers.calendar_handler import (
    _parse_datetime, _parse_duration, _format_event,
    _load_local_events, _save_local_events,
)

# Date parsing
tests = [
    ("meeting tomorrow at 3pm",   True),
    ("standup today at 9am",      True),
    ("lunch in 2 hours",          False),  # no explicit time keyword
    ("dentist april 15 10am",     True),
    ("call tomorrow",             True),
]
for text, has_time in tests:
    try:
        dt = _parse_datetime(text)
        record(f"Date parse: '{text[:30]}'", dt is not None, str(dt)[:16] if dt else "None")
    except Exception as e:
        record(f"Date parse: '{text[:30]}'", False, str(e))

# Duration parsing
dur_tests = [("1h", 60), ("30m", 30), ("1h30m", 90), ("2h", 120), ("45m", 45)]
for text, expected in dur_tests:
    result = _parse_duration(text)
    record(f"Duration parse '{text}'", result == expected, f"{result} min (expected {expected})")

# Event formatting
test_event = {
    "id": "test123",
    "summary": "Board Meeting",
    "start": {"dateTime": "2025-04-15T14:00:00"},
    "location": "Conference Room A",
}
try:
    formatted = _format_event(test_event)
    record("Event format", "Board Meeting" in formatted, formatted[:60])
    formatted_with_id = _format_event(test_event, show_id=True)
    record("Event format with ID", "test123" in formatted_with_id)
except Exception as e:
    record("Event formatting", False, str(e))

# Local calendar CRUD
with tempfile.TemporaryDirectory() as tmpdir:
    test_file = Path(tmpdir) / "events.json"
    with patch("salim.handlers.calendar_handler.LOCAL_FILE", test_file):
        _save_local_events([])
        events = _load_local_events()
        record("Calendar local storage init", events == [], "empty list")

        new_event = {
            "id": "local_001",
            "summary": "Test Meeting",
            "start": {"dateTime": datetime.now().isoformat()},
            "end":   {"dateTime": (datetime.now() + timedelta(hours=1)).isoformat()},
        }
        _save_local_events([new_event])
        loaded = _load_local_events()
        record("Calendar event save/load", len(loaded) == 1 and loaded[0]["summary"] == "Test Meeting")

        # Add multiple
        more = [
            {**new_event, "id": f"local_{i:03d}", "summary": f"Event {i}"}
            for i in range(10)
        ]
        _save_local_events(more)
        record("Calendar multiple events", len(_load_local_events()) == 10, "10 events stored")

# ══════════════════════════════════════════════════════════════════
# 5. WEB HANDLER
# ══════════════════════════════════════════════════════════════════

section("5. WEB HANDLER")

from salim.handlers.web_handler import _strip_html, _extract_readable

# HTML stripping
html_samples = [
    ("<p>Hello <b>World</b></p>",             "Hello World"),
    ("<script>alert('x')</script>Real content", "Real content"),
    ("<style>body{}</style>Text",             "Text"),
    ("&amp; &lt; &gt; &quot;",               "& < > \""),
    ("<nav>Skip</nav><article>Main</article>", "Main"),
]
for raw, expected_fragment in html_samples:
    result = _strip_html(raw)
    record(f"HTML strip: '{raw[:30]}'", expected_fragment.lower() in result.lower(),
           f"→ '{result[:40]}'")

# Readable extraction with BeautifulSoup
article_html = """
<html>
<head><style>body{color:red}</style><script>ga()</script></head>
<body>
  <nav>Menu items</nav>
  <article>
    <h1>Real Article Title</h1>
    <p>This is the main content of the article that matters.</p>
    <p>Second important paragraph with real information.</p>
  </article>
  <footer>Copyright 2025</footer>
</body>
</html>
"""
try:
    readable = _extract_readable(article_html)
    record("HTML readable extraction", "Real Article Title" in readable or
           "main content" in readable, readable[:80])
    record("HTML strips scripts/styles", "ga()" not in readable and "color:red" not in readable)
except Exception as e:
    record("HTML readable extraction", False, str(e))

# DuckDuckGo search (offline graceful)
try:
    from salim.handlers.web_handler import _ddg_search
    results_list = asyncio.run(_ddg_search("python programming"))
    record("DDG search offline graceful", isinstance(results_list, list),
           f"{len(results_list)} results (0 if offline)")
except Exception as e:
    if "connect" in str(e).lower() or "name resolution" in str(e).lower():
        record("DDG search offline graceful", True, "network unavailable")
    else:
        record("DDG search", False, str(e)[:80])

# ══════════════════════════════════════════════════════════════════
# 6. GIT HANDLER
# ══════════════════════════════════════════════════════════════════

section("6. GIT HANDLER")

from salim.handlers.git_handler import _run_git, _get_local_ip, _find_git_repos

# Git command execution
ok, out = _run_git(["--version"])
record("Git available", ok and "git version" in out.lower(), out[:40])

ok, out = _run_git(["status"], cwd=str(Path(__file__).parent.parent))
record("Git status in project", ok or "not a git" in out.lower() or "fatal" in out.lower(),
       out[:60])

# Invalid git command
ok, out = _run_git(["invalid-subcommand-xyz"])
record("Git invalid command handled", not ok, out[:60])

# Timeout
ok, out = _run_git(["--version"], timeout=0)
record("Git timeout handled", not ok, out[:40])

# CWD load/save
with tempfile.TemporaryDirectory() as tmpdir:
    with patch("salim.handlers.git_handler.GIT_CWD_FILE", Path(tmpdir) / "cwd.txt"):
        from salim.handlers.git_handler import _save_cwd, _git_cwd
        _save_cwd(tmpdir)
        loaded = _git_cwd()
        record("Git CWD save/load", loaded == tmpdir, loaded)

# Find repos
repos = _find_git_repos(max_results=5)
record("Git repo finder", isinstance(repos, list), f"found {len(repos)} repos")

# ══════════════════════════════════════════════════════════════════
# 7. TRANSLATION HANDLER
# ══════════════════════════════════════════════════════════════════

section("7. TRANSLATION HANDLER")

from salim.handlers.translate_handler import (
    _lang_code, LANG_NAMES, LANG_CODE_MAP, _load_cfg, _save_cfg,
)

# Language code mapping
lang_tests = [
    ("arabic",     "ar"),
    ("arabic",     "ar"),
    ("Arabic",     "ar"),
    ("French",     "fr"),
    ("zh",         "zh"),
    ("en",         "en"),
    ("japanese",   "ja"),
    ("unknown123", "un"),
]
for name, expected in lang_tests:
    code = _lang_code(name)
    record(f"Lang code '{name}'", code == expected, f"→ {code}")

# Config save/load
with tempfile.TemporaryDirectory() as tmpdir:
    with patch("salim.handlers.translate_handler.TRANS_CFG", Path(tmpdir) / "trans.json"):
        _save_cfg({"instance": "http://localhost:5000"})
        cfg = _load_cfg()
        record("Translate config save/load", cfg.get("instance") == "http://localhost:5000")

# LibreTranslate offline graceful
from salim.handlers.translate_handler import _libretranslate
try:
    result = asyncio.run(_libretranslate("Hello", "ar"))
    record("LibreTranslate offline graceful", result is None or isinstance(result, str),
           f"result={result}")
except Exception as e:
    if "connect" in str(e).lower() or "name resolution" in str(e).lower():
        record("LibreTranslate offline graceful", True, "no network")
    else:
        record("LibreTranslate error handling", False, str(e)[:80])

# ══════════════════════════════════════════════════════════════════
# 8. SYSMON HANDLER
# ══════════════════════════════════════════════════════════════════

section("8. NETWORK / SYSMON HANDLER")

from salim.handlers.sysmon_handler import (
    _get_local_ip, _check_port, _run_cmd, _dns_lookup,
)

# Local IP detection
ip = _get_local_ip()
record("Local IP detection", bool(re.match(r"\d+\.\d+\.\d+\.\d+", ip)), f"IP: {ip}")

# Port check — localhost:80 is probably closed, but function must not crash
result = _check_port("127.0.0.1", 80, timeout=0.5)
record("Port check no crash", isinstance(result, bool), f"port 80: {'open' if result else 'closed'}")

# Port 22 on localhost
result = _check_port("127.0.0.1", 22, timeout=0.5)
record("Port check SSH", isinstance(result, bool), f"port 22: {'open' if result else 'closed'}")

# DNS lookup
dns_result = _dns_lookup("localhost")
record("DNS lookup localhost", "127.0.0.1" in dns_result, dns_result[:60])

# DNS for unknown
dns_bad = _dns_lookup("this-domain-does-not-exist-xyz-abc-123.invalid")
record("DNS unknown domain handled", "failed" in dns_bad.lower() or "error" in dns_bad.lower(),
       dns_bad[:60])

# Shell commands
ok, out = _run_cmd(["echo", "test"])
record("Shell command: echo", ok and "test" in out, out)

ok, out = _run_cmd(["ls", "/"])
record("Shell command: ls /", ok and len(out) > 0, out[:40])

ok, out = _run_cmd(["nonexistent_command_xyz"])
record("Shell nonexistent command handled", not ok, out[:60])

ok, out = _run_cmd(["sleep", "10"], timeout=1)
record("Shell timeout handled", not ok, out[:40])

# ══════════════════════════════════════════════════════════════════
# 9. REMINDER HANDLER
# ══════════════════════════════════════════════════════════════════

section("9. REMINDER HANDLER")

from salim.handlers.reminder_handler import (
    _parse_reminder_time, _load as load_reminders, _save as save_reminders,
)

# Time parsing tests
now = datetime.now()
time_tests = [
    ("call John in 2 hours",          True,  False),
    ("take medicine every day at 8am", True,  True),
    ("meeting tomorrow at 3pm",        True,  False),
    ("standup in 30 minutes",          True,  False),
    ("backup every week",              True,  True),
    ("dentist april 15 10am",          True,  False),
    ("wake up at 7am",                 True,  False),
]
for text, expect_when, expect_recurring in time_tests:
    try:
        when, is_recurring, label = _parse_reminder_time(text)
        record(f"Remind parse: '{text[:35]}'",
               (when is not None) == expect_when and is_recurring == expect_recurring,
               f"when={str(when)[:16] if when else None} recur={is_recurring} label='{label[:20]}'")
    except Exception as e:
        record(f"Remind parse: '{text[:35]}'", False, str(e))

# Label cleaning — should strip "me to", "to", time words
label_tests = [
    ("remind me to call John in 2 hours", "call John"),
    ("take medicine every day at 8am",    "take medicine"),
    ("meeting tomorrow at 3pm",           "meeting"),
]
for text, expected_fragment in label_tests:
    _, _, label = _parse_reminder_time(text)
    record(f"Reminder label clean: '{text[:35]}'",
           expected_fragment.lower() in label.lower(),
           f"label='{label}'")

# CRUD
with tempfile.TemporaryDirectory() as tmpdir:
    test_file = Path(tmpdir) / "reminders.json"
    with patch("salim.handlers.reminder_handler.REMINDERS_FILE", test_file):
        save_reminders([])
        record("Reminders init", load_reminders() == [])

        rem = {
            "id": "rem_001", "label": "Test reminder",
            "when": (now + timedelta(hours=1)).isoformat(),
            "user_id": 12345, "recurring": False,
        }
        save_reminders([rem])
        loaded = load_reminders()
        record("Reminder save/load", len(loaded) == 1 and loaded[0]["label"] == "Test reminder")

        # Add multiple
        many = [
            {**rem, "id": f"rem_{i:03d}", "label": f"Reminder {i}"}
            for i in range(20)
        ]
        save_reminders(many)
        record("Multiple reminders", len(load_reminders()) == 20, "20 saved")

        # Recurring reminder
        rec_rem = {**rem, "id": "rem_rec", "recurring": True, "label": "Daily standup"}
        save_reminders([rec_rem])
        loaded = load_reminders()
        record("Recurring reminder saved", loaded[0].get("recurring") is True)

# ══════════════════════════════════════════════════════════════════
# 10. FINANCE HANDLER
# ══════════════════════════════════════════════════════════════════

section("10. FINANCE / CRYPTO HANDLER")

from salim.handlers.crypto_finance import (
    _fmt_price, _change_emoji, CRYPTO_IDS, INDICES,
)

# Price formatting
format_tests = [
    (45123.67, "USD", "$45,123.67"),
    (0.00045, "USD", "$0.000450"),
    (2.50, "USD", "$2.5000"),
    (1000, "EUR", "€1,000.00"),
]
for price, currency, expected_frag in format_tests:
    result = _fmt_price(price, currency)
    record(f"Price format {price} {currency}", expected_frag in result, result)

# Change emojis
emoji_tests = [
    (5.0,  "🚀"),
    (1.0,  "📈"),
    (-1.0, "🔻"),
    (-5.0, "📉"),
    (0.0,  "➡️"),
]
for change, expected_emoji in emoji_tests:
    result = _change_emoji(change)
    record(f"Change emoji {change:+.0f}%", result == expected_emoji, result)

# Crypto IDs coverage
record("Crypto IDs defined", len(CRYPTO_IDS) >= 10, f"{len(CRYPTO_IDS)} coins")
record("BTC in crypto IDs", "BTC" in CRYPTO_IDS, CRYPTO_IDS.get("BTC"))
record("ETH in crypto IDs", "ETH" in CRYPTO_IDS, CRYPTO_IDS.get("ETH"))

# Market indices
record("Market indices defined", len(INDICES) >= 8, f"{len(INDICES)} indices")
record("S&P 500 index", "^GSPC" in INDICES)

# Exchange rate offline graceful
from salim.handlers.crypto_finance import _exchange_rate
try:
    rate = asyncio.run(_exchange_rate("USD", "EUR"))
    record("Exchange rate offline graceful", rate is None or isinstance(rate, float),
           f"rate={rate}")
except Exception as e:
    if "connect" in str(e).lower() or "name resolution" in str(e).lower():
        record("Exchange rate offline graceful", True, "no network")
    else:
        record("Exchange rate error", False, str(e)[:80])

# ══════════════════════════════════════════════════════════════════
# 11. BACKUP HANDLER
# ══════════════════════════════════════════════════════════════════

section("11. BACKUP HANDLER")

from salim.handlers.backup_handler import (
    _create_tar_archive, _human_size, _load_cfg as load_backup_cfg,
    _save_cfg as save_backup_cfg, DEFAULT_DST,
)

# Human readable sizes
size_tests = [
    (500,          "B"),
    (1500,         "KB"),
    (1_500_000,    "MB"),
    (1_500_000_000,"GB"),
]
# Test via a directory
with tempfile.TemporaryDirectory() as tmpdir:
    p = Path(tmpdir)
    (p / "test.txt").write_text("x" * 1024)
    size_str = _human_size(p)
    record("Human size formatting", any(unit in size_str for unit in ["B", "KB", "MB"]), size_str)

# Config CRUD
with tempfile.TemporaryDirectory() as tmpdir:
    cfg_file = Path(tmpdir) / "backup.json"
    with patch("salim.handlers.backup_handler.BACKUP_CFG", cfg_file):
        save_backup_cfg({"schedules": [], "last_results": []})
        cfg = load_backup_cfg()
        record("Backup config save/load", "schedules" in cfg and "last_results" in cfg)

        # Add a schedule
        cfg["schedules"].append({
            "id": "bak_001", "src": str(Path.home()),
            "dst": tmpdir, "freq": "daily", "time": "2:00",
        })
        save_backup_cfg(cfg)
        loaded = load_backup_cfg()
        record("Backup schedule persistence", len(loaded["schedules"]) == 1)

# Tar archive creation
with tempfile.TemporaryDirectory() as src_dir:
    with tempfile.TemporaryDirectory() as dst_dir:
        # Create source files
        src = Path(src_dir)
        (src / "file1.txt").write_text("content one")
        (src / "file2.txt").write_text("content two")
        (src / "subdir").mkdir()
        (src / "subdir" / "nested.txt").write_text("nested content")

        ok, msg = _create_tar_archive(src_dir, Path(dst_dir))
        archive_files = list(Path(dst_dir).glob("*.tar.gz"))
        record("Tar archive creation", ok and len(archive_files) == 1,
               f"{msg[:60]}")

        if archive_files:
            import tarfile
            with tarfile.open(str(archive_files[0])) as tf:
                names = tf.getnames()
            record("Tar archive contains files", len(names) >= 3, f"{len(names)} files")

# ══════════════════════════════════════════════════════════════════
# 12. TRANSCRIPT HANDLER
# ══════════════════════════════════════════════════════════════════

section("12. TRANSCRIPT HANDLER")

from salim.handlers.transcript_handler import (
    append_turn, _load_turns, _session_file,
)

with tempfile.TemporaryDirectory() as tmpdir:
    with patch("salim.handlers.transcript_handler.TRANSCRIPT_DIR", Path(tmpdir)):
        uid = 99999
        # Append turns
        append_turn(uid, "user", "Hello Salim")
        append_turn(uid, "assistant", "Hello! How can I help?", tokens_in=10, tokens_out=8)
        append_turn(uid, "user", "Create a report", tokens_in=5)
        append_turn(uid, "assistant", "Creating report now...", tool="create_document", model="claude")

        turns = _load_turns(uid, days=1)
        record("Transcript append + load", len(turns) == 4, f"{len(turns)} turns")
        record("Transcript user role", turns[0]["role"] == "user")
        record("Transcript assistant role", turns[1]["role"] == "assistant")
        record("Transcript tokens stored", turns[1].get("tokens_in") == 10)
        record("Transcript tool stored", turns[3].get("tool") == "create_document")
        record("Transcript model stored", turns[3].get("model") == "claude")

        # JSONL format validity — each line must be valid JSON
        sf = _session_file(uid)
        lines = sf.read_text().strip().split("\n")
        all_valid_json = all(json.loads(l) for l in lines if l.strip())
        record("Transcript valid JSONL", all_valid_json, f"{len(lines)} lines")

        # Test multi-day load with no prior days
        turns_7day = _load_turns(uid, days=7)
        record("Transcript multi-day load", len(turns_7day) == 4, "same day only")

# ══════════════════════════════════════════════════════════════════
# 13. ADVANCED AGENT — BELIEF SYSTEM
# ══════════════════════════════════════════════════════════════════

section("13. ADVANCED AGENT — BELIEF SYSTEM")

from salim.handlers.agent_advanced import (
    add_belief, load_beliefs, save_beliefs, contradict_belief,
    add_hypothesis, load_hypotheses, save_hypotheses, record_experiment,
    load_goals, save_goals, add_goal,
    load_rapport, save_rapport, update_rapport_after_message, detect_emotion,
    load_performance, save_performance, record_task_outcome, get_best_strategy,
    build_personality_context, EMPATHY_RESPONSES, EMOTION_SIGNALS,
    ADVANCED_DIR,
)

with tempfile.TemporaryDirectory() as tmpdir:
    adv_dir = Path(tmpdir) / "advanced"
    adv_dir.mkdir()
    rapport_dir = adv_dir / "rapport"
    rapport_dir.mkdir()

    with patch("salim.handlers.agent_advanced.BELIEFS_FILE",  adv_dir / "beliefs.json"), \
         patch("salim.handlers.agent_advanced.GOALS_FILE",    adv_dir / "goals.json"), \
         patch("salim.handlers.agent_advanced.HYPOTHESES_FILE", adv_dir / "hyps.json"), \
         patch("salim.handlers.agent_advanced.PERF_FILE",     adv_dir / "perf.json"), \
         patch("salim.handlers.agent_advanced.RAPPORT_DIR",   rapport_dir), \
         patch("salim.handlers.agent_advanced.ADVANCED_DIR",  adv_dir):

        # ── Beliefs ─────────────────────────────────────────────
        save_beliefs([])
        b1 = add_belief("Python is faster than R for ETL pipelines", 0.7, "experience", "tech")
        record("Belief add", b1["id"].startswith("bel_") and b1["confidence"] == 0.7)

        b2 = add_belief("Python is faster than R for ETL pipelines", 0.8, "experiment", "tech")
        beliefs = load_beliefs()
        record("Belief dedup + confidence merge", len(beliefs) == 1 and
               beliefs[0]["confidence"] > 0.7, f"conf={beliefs[0]['confidence']:.2f}")
        record("Belief confirmations tracked", beliefs[0].get("confirmations", 0) >= 2)

        # Add diverse beliefs
        topics = ["AI will transform software", "TDD reduces bugs by 40%",
                  "Microservices add complexity", "TypeScript catches 15% of bugs"]
        for t in topics:
            add_belief(t, 0.6 + 0.1 * topics.index(t) % 3, "test")
        record("Multiple beliefs stored", len(load_beliefs()) == 5, "5 beliefs")

        # Contradict
        bid = load_beliefs()[0]["id"]
        orig_conf = load_beliefs()[0]["confidence"]
        contradict_belief(bid, strength=0.3)
        new_conf = load_beliefs()[0]["confidence"]
        record("Belief contradiction reduces confidence", new_conf < orig_conf,
               f"{orig_conf:.2f} → {new_conf:.2f}")
        record("Belief confidence floor (≥0)", new_conf >= 0)

        # ── Hypotheses ──────────────────────────────────────────
        save_hypotheses([])
        h1 = add_hypothesis("If I add database indexing, queries will be 10x faster")
        record("Hypothesis add", h1["id"].startswith("hyp_") and h1["status"] == "untested")
        record("Hypothesis initial confidence 0.5", h1["confidence"] == 0.5)

        # Record supporting experiment
        record_experiment(h1["id"], "benchmark_test",
                          "Query time dropped from 2s to 0.18s", True, 0.2)
        hyps = load_hypotheses()
        record("Experiment recorded", len(hyps[0]["experiments"]) == 1)
        record("Confidence increases on support", hyps[0]["confidence"] > 0.5,
               f"conf={hyps[0]['confidence']:.2f}")

        # Refute with experiments
        record_experiment(h1["id"], "counter_test", "Queries still slow on writes", False, 0.1)
        hyps = load_hypotheses()
        record("Counter-experiment reduces confidence",
               hyps[0]["confidence"] < 0.8, f"conf={hyps[0]['confidence']:.2f}")

        # Status progression
        h2 = add_hypothesis("Coffee improves code quality")
        for _ in range(6):
            record_experiment(h2["id"], "daily_observation", "Better code after coffee", True, 0.12)
        hyps_after = [h for h in load_hypotheses() if h["id"] == h2["id"]]
        record("Hypothesis confirmed at high confidence",
               hyps_after[0]["status"] == "confirmed" or hyps_after[0]["confidence"] >= 0.85,
               f"status={hyps_after[0]['status']} conf={hyps_after[0]['confidence']:.2f}")

        # ── Goals ───────────────────────────────────────────────
        save_goals(12345, [])
        g = add_goal(12345, "Learn Rust programming", "Complete Rustlings course",
                     "high", "this month")
        record("Goal add", g["id"].startswith("goal_") and g["status"] == "active")
        record("Goal priority stored", g["priority"] == "high")
        record("Goal horizon stored", g["horizon"] == "this month")
        record("Goal progress starts at 0", g["progress"] == 0)

        goals = load_goals(12345)
        record("Goal load", len(goals) == 1 and goals[0]["title"] == "Learn Rust programming")

        # Update goal progress
        goals[0]["progress"] = 45
        goals[0]["next_action"] = "Complete chapter 4"
        save_goals(12345, goals)
        loaded = load_goals(12345)
        record("Goal progress update", loaded[0]["progress"] == 45)
        record("Goal next_action update", loaded[0]["next_action"] == "Complete chapter 4")

        # Multiple goals with different priorities
        for i, (title, priority) in enumerate([
            ("Ship v2 feature", "high"),
            ("Write blog post", "low"),
            ("Learn Go", "medium"),
        ]):
            add_goal(12345, title, priority=priority)
        all_goals = load_goals(12345)
        record("Multiple goals stored", len(all_goals) == 4, f"{len(all_goals)} goals")

        # Cancel goal
        gid = all_goals[-1]["id"]
        all_goals[-1]["status"] = "cancelled"
        save_goals(12345, all_goals)
        active = [g for g in load_goals(12345) if g["status"] == "active"]
        record("Goal cancellation", len(active) == 3, f"{len(active)} active")

        # ── Emotion Detection ───────────────────────────────────
        emotion_tests = [
            ("this stupid thing doesn't work again ugh",   "frustrated"),
            ("I'm so stressed, deadline is tomorrow!",     "stressed"),
            ("wow this is amazing! exactly what I needed", "happy"),
            ("finally got it working! this is incredible", "excited"),
            ("I'm curious about how this algorithm works", "curious"),
            ("I'm exhausted, been working all day",        "tired"),
        ]
        for text, expected in emotion_tests:
            detected = detect_emotion(text)
            record(f"Emotion detect '{text[:30]}'", detected == expected,
                   f"detected={detected} (expected={expected})")

        # Neutral detection
        neutral = detect_emotion("please create a report")
        record("Neutral emotion", neutral in ("neutral", "focused"), f"detected={neutral}")

        # ── Rapport ─────────────────────────────────────────────
        uid = 77777
        rapport = load_rapport(uid)
        record("Rapport initial trust 0.5", rapport["trust_level"] == 0.5)
        record("Rapport initial familiarity 0", rapport["familiarity"] == 0)

        # Update through messages
        update_rapport_after_message(uid, "hi can you help me")
        r2 = load_rapport(uid)
        record("Rapport familiarity increments", r2["familiarity"] == 1)
        record("Rapport last_seen set", r2.get("last_seen") is not None)

        # Emotion in rapport
        update_rapport_after_message(uid, "I'm frustrated this isn't working")
        r3 = load_rapport(uid)
        record("Rapport emotion updated", r3["emotional_state"] in ("frustrated", "neutral"))

        # Trust grows with helpful interactions
        for _ in range(20):
            update_rapport_after_message(uid, "thanks, that worked perfectly!", was_helpful=True)
        r4 = load_rapport(uid)
        record("Trust grows with positive interactions", r4["trust_level"] > 0.5,
               f"trust={r4['trust_level']:.3f}")

        # Style detection
        update_rapport_after_message(uid, "please debug this function and fix the API endpoint")
        r5 = load_rapport(uid)
        record("Style detection: technical", r5["communication_style"] in ("technical", "balanced"))

        update_rapport_after_message(uid, "yo can u help")
        r6 = load_rapport(uid)
        record("Style detection: casual", r6["communication_style"] in ("casual", "balanced"))

        # Milestones
        for i in range(15):
            update_rapport_after_message(uid, f"message {i}")
        r7 = load_rapport(uid)
        milestones = r7.get("milestones", [])
        record("Rapport milestone at 10", any(m.get("interactions") == 10 for m in milestones),
               f"milestones: {[m.get('interactions') for m in milestones]}")

        # ── Performance Tracking ─────────────────────────────────
        save_performance({"tasks": [], "strategies": {}, "failures": {}})

        record_task_outcome("create_document", True,  "default", 3, "create invoice")
        record_task_outcome("create_document", True,  "default", 2, "create report")
        record_task_outcome("create_document", False, "default", 5, "create complex doc")
        record_task_outcome("deep_think",       True,  "chain_of_thought", 1, "analyze problem")
        record_task_outcome("web_search",        False, "ddg",    2, "search news")

        perf = load_performance()
        record("Performance tasks recorded", len(perf["tasks"]) == 5, f"{len(perf['tasks'])} tasks")
        record("Strategy win/loss tracked", "default" in perf["strategies"],
               str(perf["strategies"]))
        record("Failure patterns tracked", len(perf["failures"]) >= 1, str(perf["failures"]))

        # Best strategy selection
        # Add winning strategy
        for _ in range(5):
            record_task_outcome("create_document", True, "structured_template", 2)
        best = get_best_strategy("create_document")
        record("Best strategy selection", isinstance(best, str), f"best={best}")

        # ── Personality Context ──────────────────────────────────
        # Save rapport for personality context test
        rapport_data = load_rapport(uid)
        rapport_data["communication_style"] = "technical"
        rapport_data["preferred_length"] = "brief"
        rapport_data["expertise_level"] = "expert"
        rapport_data["trust_level"] = 0.85
        rapport_data["emotional_state"] = "focused"
        save_rapport(uid, rapport_data)

        with patch("salim.handlers.memory.load_memory", return_value={"name": "Ahmed"}):
            ctx = build_personality_context(uid)
            record("Personality context generated", len(ctx) > 50, f"{len(ctx)} chars")
            record("Style in context", "technical" in ctx.lower())
            record("Expertise in context", "expert" in ctx.lower())
            record("Trust in context", "trust" in ctx.lower())

        # Empathy responses complete
        record("Empathy responses all emotions",
               all(e in EMPATHY_RESPONSES for e in EMOTION_SIGNALS),
               f"coverage: {len(EMPATHY_RESPONSES)} emotions")

# ══════════════════════════════════════════════════════════════════
# 14. MEMORY SYSTEM
# ══════════════════════════════════════════════════════════════════

section("14. MEMORY SYSTEM")

from salim.handlers.memory import (
    load_memory, save_memory, set_memory, get_memory,
    delete_memory_key, clear_memory, learn_from_text,
    build_memory_context, update_last_seen,
)

with tempfile.TemporaryDirectory() as tmpdir:
    with patch("salim.handlers.memory.MEMORY_DIR", Path(tmpdir)):
        uid = 55555

        # Initial load
        record("Memory empty on first load", load_memory(uid) == {})

        # Set and get
        set_memory(uid, "name", "Ahmed")
        set_memory(uid, "timezone", "UTC+5")
        set_memory(uid, "role", "software engineer")
        record("Memory set single key", get_memory(uid, "name") == "Ahmed")
        record("Memory set multiple keys", get_memory(uid, "timezone") == "UTC+5")
        record("Memory default value", get_memory(uid, "missing_key", "default") == "default")

        # Delete key
        delete_memory_key(uid, "timezone")
        record("Memory delete key", get_memory(uid, "timezone") is None)

        # learn_from_text — name extraction
        learn_from_text(44444, "My name is Sarah")
        record("Memory learn name", get_memory(44444, "name") == "Sarah",
               get_memory(44444, "name"))

        learn_from_text(44444, "I'm in Asia/Karachi timezone")
        record("Memory learn timezone", "Asia/Karachi" in str(get_memory(44444, "timezone", "")))

        learn_from_text(44444, "respond in Arabic please")
        record("Memory learn language", get_memory(44444, "language") == "arabic")

        learn_from_text(44444, "I am a software developer")
        record("Memory learn role", "developer" in str(get_memory(44444, "role", "")))

        # Command frequency tracking
        learn_from_text(uid, "/screenshot")
        learn_from_text(uid, "/screenshot")
        learn_from_text(uid, "/agent create report")
        counts = get_memory(uid, "command_counts", {})
        record("Memory command counts", counts.get("screenshot", 0) >= 2, str(counts))

        # Build context
        context = build_memory_context(uid)
        record("Memory context built", "name" in context.lower() or "Ahmed" in context,
               context[:80])
        record("Memory context has guidance", "personalize" in context.lower() or
               "memory" in context.lower())

        # update_last_seen
        update_last_seen(uid)
        record("Memory last_seen updated", get_memory(uid, "last_seen") is not None)

        # Clear
        clear_memory(uid)
        record("Memory clear", load_memory(uid) == {})

# ══════════════════════════════════════════════════════════════════
# 15. BOT.PY INTEGRATION
# ══════════════════════════════════════════════════════════════════

section("15. BOT.PY INTEGRATION CHECKS")

bot_source = Path(__file__).parent.parent / "salim" / "bot.py"
src = bot_source.read_text()

# All v12 handlers imported
v12_imports = [
    "WeatherHandlers", "CalendarHandlers", "WebHandlers", "GitHandlers",
    "DigestHandlers", "TranslateHandlers", "SysMonHandlers", "ReminderHandlers",
    "FinanceHandlers", "BackupHandlers", "TranscriptHandlers",
    "AdvancedAgentHandlers",
]
for cls in v12_imports:
    record(f"Import: {cls}", cls in src)

# All v12 commands registered
v12_commands = [
    "weather", "cal", "web", "webread", "websearch", "webnews", "yt",
    "git", "digest", "translate", "tl", "ports", "portscan", "netdevices",
    "myip", "ping", "dns", "traceroute", "whois",
    "remind", "reminders", "remdel", "remclear",
    "price", "crypto", "stocks", "market", "fx",
    "backup", "transcript",
    "think", "goal", "hypo", "beliefs", "rapport", "selfcheck", "agentmode", "probe",
]
all_cmds_found = all(f'CommandHandler("{cmd}"' in src for cmd in v12_commands)
missing_cmds = [cmd for cmd in v12_commands if f'CommandHandler("{cmd}"' not in src]
record("All v12 commands registered", all_cmds_found,
       f"Missing: {missing_cmds}" if missing_cmds else f"{len(v12_commands)} commands OK")

# restore_reminders in post_init
record("restore_reminders called at startup", "restore_reminders" in src)

# AdvancedAgentHandlers in SalimBot class
record("AdvancedAgentHandlers in SalimBot", "AdvancedAgentHandlers," in src)

# All handlers in SalimBot class
class_match = re.search(r"class SalimBot\((.+?)\):", src, re.DOTALL)
if class_match:
    class_body = class_match.group(1)
    for cls in v12_imports:
        record(f"Mixin in SalimBot: {cls}", cls in class_body)

# BotCommands count
bot_cmd_count = src.count("BotCommand(")
record("BotCommands registered count", bot_cmd_count >= 100, f"{bot_cmd_count} commands")

# Personality injected in ai.py
ai_src = (Path(__file__).parent.parent / "salim" / "ai.py").read_text()
record("Personality context in ai.py", "build_personality_context" in ai_src)
record("Rapport update in ai_handler", "update_rapport_after_message" in
       (Path(__file__).parent.parent / "salim" / "handlers" / "ai_handler.py").read_text())

# ══════════════════════════════════════════════════════════════════
# 16. AGENT LOOP LOGIC
# ══════════════════════════════════════════════════════════════════

section("16. AGENT LOOP LOGIC")

from salim.handlers.agent import (
    load_agent_log, save_agent_log, _safe_path, _ensure_dirs,
    run_agent, AGENT_SYSTEM_PROMPT, MAX_STEPS, STEP_TIMEOUT,
)

# Constants
record("MAX_STEPS defined", isinstance(MAX_STEPS, int) and MAX_STEPS >= 10, str(MAX_STEPS))
record("STEP_TIMEOUT defined", isinstance(STEP_TIMEOUT, int) and STEP_TIMEOUT >= 30, str(STEP_TIMEOUT))

# Agent system prompt
record("AGENT_SYSTEM_PROMPT length", len(AGENT_SYSTEM_PROMPT) > 500, f"{len(AGENT_SYSTEM_PROMPT)} chars")
record("AGENT_SYSTEM_PROMPT has tools", "create_document" in AGENT_SYSTEM_PROMPT)
record("AGENT_SYSTEM_PROMPT has rules", "NEVER" in AGENT_SYSTEM_PROMPT or "RULES" in AGENT_SYSTEM_PROMPT)
record("AGENT_SYSTEM_PROMPT no placeholders rule", "placeholder" in AGENT_SYSTEM_PROMPT.lower())

# Safe path resolution
with tempfile.TemporaryDirectory() as tmpdir:
    with patch("salim.handlers.agent.DOCS_DIR", Path(tmpdir)):
        # Existing file
        (Path(tmpdir) / "test.docx").write_text("x")
        p = _safe_path("test.docx")
        record("Safe path resolves existing file", p.exists(), str(p))

        # Non-existing → goes to DOCS_DIR
        p2 = _safe_path("new_file.docx")
        record("Safe path defaults to DOCS_DIR", str(tmpdir) in str(p2))

        # Absolute path
        p3 = _safe_path(str(Path.home()))
        record("Safe path absolute", p3.is_absolute())

# Log CRUD
with tempfile.TemporaryDirectory() as tmpdir:
    with patch("salim.handlers.agent.AGENT_DIR", Path(tmpdir)):
        uid = 11111
        log = {
            "goal": "Create invoice",
            "started": datetime.now().isoformat(),
            "user_id": uid,
            "steps": [
                {"step": 1, "action": "create_document", "success": True, "output": "Created invoice.docx"},
                {"step": 2, "action": "email_send", "success": True, "output": "Email sent"},
            ],
            "completed": datetime.now().isoformat(),
            "summary": "Invoice created and emailed",
        }
        save_agent_log(uid, log)
        loaded = load_agent_log(uid)
        record("Agent log save/load", loaded["goal"] == "Create invoice")
        record("Agent log steps preserved", len(loaded["steps"]) == 2)
        record("Agent log summary", loaded["summary"] == "Invoice created and emailed")

# Agent run with mocked AI - tests the loop logic
async def test_agent_run():
    call_count = [0]

    class MockAI:
        def is_configured(self): return True
        async def _call_with_fallback(self, messages, system, max_tokens, temperature):
            call_count[0] += 1
            if call_count[0] == 1:
                return json.dumps({
                    "thought": "I will create the document first",
                    "action": "create_document",
                    "parameters": {
                        "type": "docx", "filename": "test_report.docx",
                        "title": "Test Report", "content": "# Test\n\nThis is a test report."
                    }
                }), "mock"
            elif call_count[0] == 2:
                return json.dumps({
                    "thought": "Document created successfully",
                    "action": "done",
                    "summary": "Created test_report.docx successfully"
                }), "mock"
            else:
                return json.dumps({"action": "stop", "reason": "extra call"}), "mock"

    progress_calls = []
    async def mock_progress(step, thought, action, output):
        progress_calls.append({"step": step, "action": action})

    file_callbacks = []
    async def mock_file(path):
        file_callbacks.append(path)

    with tempfile.TemporaryDirectory() as tmpdir:
        with patch("salim.handlers.agent.AGENT_DIR", Path(tmpdir)), \
             patch("salim.handlers.agent.DOCS_DIR", Path(tmpdir)), \
             patch("salim.handlers.agent.build_personality_context", return_value=""):
            stop_event = asyncio.Event()
            result = await run_agent(
                goal="Create a test report document",
                user_id=11111,
                ai_instance=MockAI(),
                progress_callback=mock_progress,
                stop_event=stop_event,
                send_file_callback=mock_file,
            )
    return result, progress_calls, call_count[0]

try:
    result, prog, ai_calls = asyncio.run(test_agent_run())
    record("Agent loop runs", isinstance(result, str), result[:60])
    record("Agent calls AI multiple times", ai_calls >= 2, f"{ai_calls} AI calls")
    record("Agent reports progress", len(prog) >= 1, f"{len(prog)} progress updates")
    record("Agent returns summary on done", "successfully" in result.lower() or "created" in result.lower(), result[:60])
except Exception as e:
    record("Agent loop", False, str(e)[:100])

# Agent stop event
async def test_agent_stop():
    class MockAI:
        async def _call_with_fallback(self, m, system, max_tokens, temperature):
            await asyncio.sleep(0.1)
            return json.dumps({"action": "done", "summary": "done"}), "mock"
    stop = asyncio.Event()
    stop.set()  # Stop immediately
    with tempfile.TemporaryDirectory() as tmpdir:
        with patch("salim.handlers.agent.AGENT_DIR", Path(tmpdir)), \
             patch("salim.handlers.agent.DOCS_DIR", Path(tmpdir)), \
             patch("salim.handlers.agent.build_personality_context", return_value=""):
            result = await run_agent("test", 0, MockAI(), lambda *a: None, stop)
    return result

try:
    stop_result = asyncio.run(test_agent_stop())
    record("Agent stops on stop_event", "stop" in stop_result.lower(), stop_result[:60])
except Exception as e:
    record("Agent stop event", False, str(e)[:80])

# Agent handles AI failures with retry
async def test_agent_failures():
    fail_count = [0]

    class FailingAI:
        async def _call_with_fallback(self, m, system, max_tokens, temperature):
            fail_count[0] += 1
            raise Exception("AI timeout")

    with tempfile.TemporaryDirectory() as tmpdir:
        with patch("salim.handlers.agent.AGENT_DIR", Path(tmpdir)), \
             patch("salim.handlers.agent.DOCS_DIR", Path(tmpdir)), \
             patch("salim.handlers.agent.build_personality_context", return_value=""):
            result = await run_agent("test", 0, FailingAI(),
                                     lambda *a: asyncio.sleep(0), asyncio.Event())
    return result, fail_count[0]

try:
    fail_result, fail_count = asyncio.run(test_agent_failures())
    record("Agent fails gracefully after 3 AI errors",
           "failed" in fail_result.lower() or "error" in fail_result.lower(),
           fail_result[:80])
    record("Agent retries AI 3 times before stopping",
           fail_count >= 3, f"{fail_count} AI attempts")
except Exception as e:
    record("Agent failure handling", False, str(e)[:80])

# ══════════════════════════════════════════════════════════════════
# 17. EMAIL CONFIG
# ══════════════════════════════════════════════════════════════════

section("17. EMAIL CONFIG")

from salim.handlers.agent import load_email_config, save_email_config

with tempfile.TemporaryDirectory() as tmpdir:
    with patch("salim.handlers.agent.EMAIL_CFG", Path(tmpdir) / "email.json"):
        # Empty config
        record("Email config empty on first load", load_email_config() == {})

        # Save and load
        test_cfg = {
            "smtp_host": "smtp.gmail.com", "smtp_port": 587,
            "imap_host": "imap.gmail.com",
            "username": "test@gmail.com", "password": "app_password",
            "sender": "Test User <test@gmail.com>",
        }
        save_email_config(test_cfg)
        loaded = load_email_config()
        record("Email config save/load", loaded["smtp_host"] == "smtp.gmail.com")
        record("Email config IMAP stored", loaded["imap_host"] == "imap.gmail.com")
        record("Email config port stored", loaded["smtp_port"] == 587)

        # Verify file permissions
        cfg_file = Path(tmpdir) / "email.json"
        permissions = oct(cfg_file.stat().st_mode)[-3:]
        record("Email config chmod 600", permissions == "600", f"permissions: {permissions}")

# ══════════════════════════════════════════════════════════════════
# 18. EDGE CASES & ROBUSTNESS
# ══════════════════════════════════════════════════════════════════

section("18. EDGE CASES & ROBUSTNESS")

# Unicode in all document types
with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)
    unicode_content = """# تقرير الأعمال

## ملخص تنفيذي
أداء قوي في جميع الأقسام.

## Chinese: 你好世界
## Japanese: こんにちは
## Arabic: مرحباً بالعالم

| الاسم | القسم | الراتب |
|-------|-------|--------|
| أحمد علي | المبيعات | 8000 |
| سارة خان | التصميم | 7000 |
"""
    try:
        create_docx(unicode_content, tmp / "unicode.docx", "Unicode Report")
        record("DOCX handles Unicode (Arabic/Chinese/Japanese)",
               (tmp / "unicode.docx").stat().st_size > 0)
    except Exception as e:
        record("DOCX Unicode", False, str(e))

    try:
        create_xlsx(unicode_content, tmp / "unicode.xlsx", "Unicode Sheet")
        record("XLSX handles Unicode", (tmp / "unicode.xlsx").stat().st_size > 0)
    except Exception as e:
        record("XLSX Unicode", False, str(e))

    try:
        create_pdf(unicode_content, tmp / "unicode.pdf", "Unicode Report")
        record("PDF handles Unicode", (tmp / "unicode.pdf").stat().st_size > 0)
    except Exception as e:
        record("PDF Unicode", False, str(e)[:60])

# Special chars in filenames
with tempfile.TemporaryDirectory() as tmpdir:
    try:
        p = Path(tmpdir) / "report_Q1-2025_(draft).docx"
        create_docx("# Test\n\nContent here", p, "Test")
        record("DOCX special chars in filename", p.exists())
    except Exception as e:
        record("DOCX special filename", False, str(e))

# Empty/malformed inputs
with tempfile.TemporaryDirectory() as tmpdir:
    tmp = Path(tmpdir)

    # Very long title
    try:
        p = tmp / "long_title.docx"
        long_title = "A" * 500
        create_docx("Content", p, long_title)
        record("DOCX very long title", p.exists())
    except Exception as e:
        record("DOCX very long title", False, str(e))

    # Malformed table
    try:
        bad_table = """| Col1 | Col2
No separator here
| data | data |"""
        p = tmp / "bad_table.docx"
        create_docx(bad_table, p, "Bad Table")
        record("DOCX malformed table no crash", p.exists())
    except Exception as e:
        record("DOCX malformed table", False, str(e))

    # Mixed content
    try:
        mixed = "# Title\n\nParagraph\n\n- bullet\n1. numbered\n\n| a | b |\n|---|---|\n| 1 | 2 |\n\nMore text"
        p = tmp / "mixed.docx"
        create_docx(mixed, p, "Mixed")
        record("DOCX mixed content types", p.exists())
    except Exception as e:
        record("DOCX mixed content", False, str(e))

# Emotion detection edge cases
edge_emotions = [
    ("", "neutral"),
    ("ok",  "neutral"),
    ("THIS IS AMAZING", "happy"),
    ("ugh I'm so frustrated and stressed", None),  # either works
    ("123 456 789", "neutral"),
]
for text, expected in edge_emotions:
    try:
        emotion = detect_emotion(text)
        if expected is None:
            record(f"Emotion edge case: '{text[:20]}'", emotion in ("frustrated", "stressed", "neutral"),
                   f"detected={emotion}")
        else:
            record(f"Emotion edge case: '{text[:20]}'", emotion == expected or emotion == "neutral",
                   f"detected={emotion} (expected {expected})")
    except Exception as e:
        record(f"Emotion edge case: '{text[:20]}'", False, str(e))

# Reminder time parse edge cases
edge_reminders = [
    ("",                  False),   # empty string
    ("no time specified", False),   # no time info
    ("tomorrow",          True),    # just tomorrow defaults to 9am
    ("at midnight",       True),
]
for text, expect_when in edge_reminders:
    try:
        when, _, label = _parse_reminder_time(text)
        record(f"Reminder edge: '{text[:20]}'",
               (when is not None) == expect_when,
               f"when={str(when)[:16] if when else None}")
    except Exception as e:
        record(f"Reminder edge: '{text[:20]}'", False, str(e))

# ══════════════════════════════════════════════════════════════════
# FINAL SUMMARY
# ══════════════════════════════════════════════════════════════════

print(f"\n{'═'*60}")
print("  FINAL TEST RESULTS")
print(f"{'═'*60}")

passed  = sum(1 for r in results if r[0] == PASS)
failed  = sum(1 for r in results if r[0] == FAIL)
skipped = sum(1 for r in results if r[0] == SKIP)
total   = len(results)
pct     = (passed / total * 100) if total else 0

print(f"\n  {PASS} Passed:  {passed}")
print(f"  {FAIL} Failed:  {failed}")
print(f"  {SKIP} Skipped: {skipped}")
print(f"\n  Total: {total} tests  ({pct:.1f}% pass rate)")

if failed > 0:
    print(f"\n{'─'*60}")
    print("  FAILURES:")
    for icon, name, detail in results:
        if icon == FAIL:
            print(f"  {icon} {name}")
            if detail:
                print(f"       → {detail}")

print(f"\n{'═'*60}\n")
sys.exit(0 if failed == 0 else 1)
