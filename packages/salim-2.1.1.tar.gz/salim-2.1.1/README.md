# 🤖 Salim v13 — Your AI-Powered Laptop Assistant on Telegram

Control your entire laptop, create professional documents, send beautiful emails, and automate your digital life — all through Telegram.  
**No cloud. No subscriptions. 100% yours.**

---

## ✨ What's New in v13

| Feature | Description |
|---|---|
| 📚 **SKILL.md Engine** | Documents created using professional `.md` skill files (docx-js, pptxgenjs, openpyxl) |
| 📧 **HTML Emails** | All emails sent as beautiful HTML with gradient headers, styled paragraphs |
| 🧭 **Plain English** | Type anything — no `/` needed. "create an invoice" works without `/agent` |
| 📸 **Smart Photos** | Send photo + caption "save this" or "email to x@y.com" — auto-acted |
| ⏱️ **25s Confirmation** | Dangerous actions show countdown — auto-approves if no response |
| 🎯 **Step-by-Step UI** | Agent shows rich progress: step number, thought, action, result per step |
| ⚙️ **Onboarding** | `/setup` wizard for image save folder, document folder |
| 📄 **Real Docs** | Word via docx-js (Arial fonts, DXA tables), Excel with real `=SUM()` formulas |

---

## ✨ Full Capabilities

| Category | Capability |
|---|---|
| 🖥️ System | Screenshots, process control, power (shutdown/sleep/lock), disk info |
| 🐚 Shell | Run any terminal command, live output streaming |
| 📁 Files | Browse, upload, download, search, watch for changes |
| 🧠 AI | Natural language, chat memory, vision (describe images), plain-English routing |
| 📄 Documents | DOCX (docx-js), XLSX (openpyxl+formulas), PDF, PPTX (pptxgenjs), CSV |
| 📧 Email | Beautiful HTML emails, SMTP/IMAP, attachments, reply, search |
| 🤖 Agent | Autonomous multi-step: "create invoice and email it to client" |
| 📸 Images | Photo → auto-save to folder, email attachment, AI vision analysis |
| 🌍 Weather | Real-time forecasts, 7-day (Open-Meteo, free) |
| 📅 Calendar | Local calendar, add/view/search events |
| 🌐 Web | Fetch pages, DuckDuckGo search, news, YouTube summaries |
| 🔀 Git | Full git control — status, commit, push, pull, clone, branch |
| 🌅 Digest | Morning briefing: weather + calendar + email + news + system health |
| 🌐 Translate | 30+ languages via LibreTranslate |
| 🔌 Network | Port scanner, network devices, ping, DNS, traceroute, WHOIS |
| ⏰ Reminders | Natural language: "remind me to call John in 2 hours" |
| 💰 Finance | Stocks, crypto, forex in real-time (Yahoo Finance + CoinGecko) |
| 💾 Backup | rsync/tar encrypted file backups |
| 📋 Transcript | JSONL session logs, searchable audit trail |
| 🔔 Alerts | CPU/RAM/disk/temp thresholds |
| 🎙️ Voice | Voice message → transcribes + executes |
| 📷 Camera | Webcam snapshots, motion detection |
| 🔐 SSH | Remote control other machines |
| 🌐 Browser | Playwright automation, screenshots, form filling |
| 🗂️ Notes | Quick note-taking, searchable |
| 💾 Memory | Persistent user memory across sessions |
| 🔌 Skills | Dynamic .md skill files (docx, xlsx, pptx, pdf) + Python plugins |

---

## 🚀 Quick Start

```bash
pip install salim
salim setup    # enter bot token + allowed user ID
salim          # start the bot
```

Then in Telegram:
- Send `/start` for dashboard
- Send `/setup` for onboarding (set image/document save folders)
- Just **type anything in plain English** — no `/` needed!

---

## 💬 Plain English Examples (No Commands Needed!)

Just type these naturally in Telegram:

```
"create an invoice for ABC Company for $5,000"
→ Salim creates a professional DOCX invoice and sends it to you

"send email to boss about the project update"
→ Salim composes and sends a beautiful HTML email

"what's the weather in Dubai?"
→ Shows real-time weather

"remind me to call Ahmed at 3pm"
→ Sets a reminder

"take a screenshot"
→ Takes and sends a screenshot

"translate 'hello world' to Arabic"
→ Translates immediately

"what's the Bitcoin price?"
→ Shows current BTC price

"check disk space"
→ Shows disk usage
```

---

## 📄 Document Creation (Skill-Powered)

Salim uses professional skill `.md` files to create documents:

### Word Documents (DOCX)
Uses **docx-js** (Node.js) following `SKILL.md` rules:
- Arial font throughout
- Navy blue H1, steel blue H2 headings
- Proper `List Bullet` style (no unicode bullets)
- Tables with dual DXA widths, CLEAR shading
- US Letter page (12240×15840 DXA)
- Professional footer with date

```
"create a word document with a sales report for Q1 2025"
"/agent create word invoice for Client XYZ $10,000"
"/agent write resignation letter for Ahmed, last day April 30"
```

### Excel Spreadsheets (XLSX)
Uses **openpyxl** with real Excel formulas:
- Blue headers (white text), alternating row fills
- Real `=SUM()` formulas (never Python-calculated values)
- Color coding: blue=inputs, black=formulas
- Frozen top row, auto-column widths

```
"create an excel salary sheet for 10 employees"
"/agent create excel budget for Q2 with projections"
```

### PowerPoint (PPTX)  
Uses **pptxgenjs** (Node.js) following design rules:
- 16:9 layout
- Dark title slide, light content slides
- Bold slide numbers, proper bullet formatting

```
"/agent create pptx sales pitch 6 slides"
```

### Email (HTML)
All emails sent with beautiful HTML:
- Gradient header (navy → steel blue)
- Styled body paragraphs
- Professional footer
- Plain-text fallback included

```
"/agent email send to client@company.com subject Invoice attached body Please find..."
```

---

## 📸 Photo Commands

Send any photo with a caption:

| Caption | Action |
|---|---|
| `save this` | Saves to your configured image folder |
| `email to user@example.com` | Sends as email attachment |
| `what is this?` | AI vision analysis |
| `read this text` | OCR / text extraction |
| `describe` | Full image description |

Set your image save folder: `/setup`

---

## 🔌 Skills System (SKILL.md)

Salim downloads and uses professional `.md` skill files:

- `~/.salim/skill_docs/docx.md` — Word document rules
- `~/.salim/skill_docs/xlsx.md` — Excel rules  
- `~/.salim/skill_docs/pptx.md` — PowerPoint rules
- `~/.salim/skill_docs/pdf.md` — PDF rules

View skills: `/skilldocs`  
Install Python skill plugin: `/skilladd <url>`  
List plugins: `/skills`

---

## 📋 All Commands

### Agent & AI
| Command | Description |
|---|---|
| `/agent <goal>` | Autonomous multi-step task |
| `/think <problem>` | Deep reasoning |
| `/goal` | Manage persistent goals |
| `/hypo <hypothesis>` | Test hypotheses |
| `/beliefs` | Agent knowledge base |
| `/rapport` | Communication style |
| `/selfcheck` | Self-assessment |
| `/agentmode <mode>` | brief/detailed/empathy |
| `/probe <topic>` | Investigate + hypothesize |

### System
| Command | Description |
|---|---|
| `/info` | Full system overview |
| `/cpu /mem /disk /battery /network` | Individual metrics |
| `/top` | Live resource monitor |
| `/ps [name]` | Running processes |
| `/kill <pid>` | Kill process |

### Shell & Files
| Command | Description |
|---|---|
| `/run <cmd>` | Execute shell command |
| `/ls [path]` | List directory |
| `/cat <file>` | Read file |
| `/find <pattern>` | Search files |
| `/download <path>` | Download file |
| `/write <file> <content>` | Create/overwrite file |
| `/zip /unzip` | Archive operations |

### Web & Info
| Command | Description |
|---|---|
| `/web <url>` | Fetch and summarize |
| `/websearch <query>` | DuckDuckGo search |
| `/webnews <topic>` | Latest news |
| `/weather [city]` | Weather forecast |
| `/translate <text>` | Translate to any language |

### Finance
| Command | Description |
|---|---|
| `/price <BTC\|AAPL>` | Stock/crypto price |
| `/market` | Major market indices |
| `/fx <USD EUR 100>` | Currency exchange |

### Calendar & Reminders
| Command | Description |
|---|---|
| `/cal [add\|list\|search]` | Calendar management |
| `/remind <natural language>` | Set reminder |
| `/reminders` | List reminders |
| `/at <time> <cmd>` | Schedule command |
| `/every <interval> <cmd>` | Repeat command |

### Communication
| Command | Description |
|---|---|
| `/vision on\|off` | Auto-describe photos |
| `/askvision <question>` | Ask about last photo |
| `/tts <text>` | Text-to-speech |
| `/say <text>` | Speak text |

### Setup & Config
| Command | Description |
|---|---|
| `/setup` | Onboarding wizard |
| `/config` | Bot settings |
| `/skilldocs` | List SKILL.md files |
| `/skills` | List skill plugins |
| `/skilladd <url>` | Install skill plugin |
| `/status` | Bot health check |
| `/digest` | Morning briefing |

---

## ⚙️ Configuration

```bash
salim setup
```

Configures:
- Telegram Bot Token
- Allowed User IDs
- AI API Keys (NVIDIA NIM / Groq / Z.AI)
- Email (SMTP/IMAP)

Then in Telegram: `/setup` for:
- Image save directory
- Documents save directory

---

## 🏗️ Architecture

```
salim/
├── bot.py              # Main bot class (all handlers)  
├── ai.py               # AI engine (NVIDIA NIM → Groq → Z.AI)
├── handlers/
│   ├── agent.py        # Office agent (doc creation via skills)
│   ├── skill_engine.py # SKILL.md loader, docx-js, pptxgenjs, xlsx
│   ├── onboarding.py   # First-run setup wizard
│   ├── ai_handler.py   # NLP routing + plain-English understanding
│   ├── vision.py       # Image AI + auto-save photos
│   ├── agent_advanced.py # EQ, goals, beliefs, rapport
│   └── ...             # 30+ other handlers
└── skill_docs/         # ~/.salim/skill_docs/*.md
    ├── docx.md
    ├── xlsx.md
    ├── pptx.md
    └── pdf.md
```

---

## 📦 Requirements

- Python 3.11+
- Node.js 18+ (for docx-js and pptxgenjs)
- `npm install -g docx pptxgenjs` (auto-detected)
- See `pyproject.toml` for Python dependencies

---

## 📄 License

MIT — Use freely, modify, distribute.

---

*Salim v13 — Made with ❤️ for productivity*
