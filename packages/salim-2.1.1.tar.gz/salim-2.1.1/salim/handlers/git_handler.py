"""
Salim Git Handler — Real Git & GitHub operations from Telegram.

Commands:
  /git status              — git status of current repo
  /git log [n]             — last N commits (default 10)
  /git diff                — show uncommitted changes
  /git pull                — git pull
  /git push                — git push
  /git branch              — list branches
  /git checkout <branch>   — switch branch
  /git commit <msg>        — stage all + commit
  /git clone <url>         — clone a repo to Desktop
  /git repos               — list git repos on this machine
  /git cd <path>           — set working repo directory
"""
from __future__ import annotations
import html
import logging
import os
import subprocess
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.git")
GIT_CWD_FILE = Path.home() / ".salim" / "git_cwd.txt"


def _git_cwd() -> str:
    """Get saved git working directory."""
    if GIT_CWD_FILE.exists():
        p = GIT_CWD_FILE.read_text().strip()
        if Path(p).exists():
            return p
    return str(Path.home())


def _save_cwd(path: str):
    GIT_CWD_FILE.parent.mkdir(parents=True, exist_ok=True)
    GIT_CWD_FILE.write_text(path)


def _run_git(args: list[str], cwd: str = None, timeout: int = 60) -> tuple[bool, str]:
    """Run a git command. Returns (success, output)."""
    cwd = cwd or _git_cwd()
    try:
        result = subprocess.run(
            ["git"] + args,
            capture_output=True, text=True, timeout=timeout, cwd=cwd
        )
        out = (result.stdout or "").strip()
        err = (result.stderr or "").strip()
        if result.returncode == 0:
            return True, out or "(no output)"
        else:
            return False, err or out or f"Exit code {result.returncode}"
    except FileNotFoundError:
        return False, "git not installed. Install from https://git-scm.com"
    except subprocess.TimeoutExpired:
        return False, f"Git command timed out after {timeout}s"
    except Exception as e:
        return False, str(e)


def _find_git_repos(max_results: int = 15) -> list[str]:
    """Find git repos on this machine."""
    repos = []
    search_dirs = [Path.home() / d for d in ["Desktop", "Documents", "Projects", "dev", "code", "repos"]]
    search_dirs.append(Path.home())
    seen = set()
    for base in search_dirs:
        if not base.exists():
            continue
        try:
            for p in base.rglob(".git"):
                repo_path = str(p.parent)
                if repo_path not in seen:
                    seen.add(repo_path)
                    repos.append(repo_path)
                if len(repos) >= max_results:
                    return repos
        except PermissionError:
            pass
    return repos


class GitHandlers:

    @require_auth
    async def cmd_git(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /git <subcommand> — full git control from Telegram.
        /git help for all commands.
        """
        msg  = update.effective_message
        args = ctx.args or []
        sub  = args[0].lower() if args else "status"
        cwd  = _git_cwd()

        # ── Set working dir ────────────────────────────────────────────────────
        if sub == "cd":
            if len(args) < 2:
                await msg.reply_text(
                    f"Current repo: <code>{html.escape(cwd)}</code>\n"
                    f"Change: <code>/git cd /path/to/repo</code>",
                    parse_mode="HTML"
                )
                return
            new_path = " ".join(args[1:])
            p = Path(new_path).expanduser()
            if not p.exists():
                await msg.reply_text(f"❌ Path not found: <code>{html.escape(str(p))}</code>", parse_mode="HTML")
                return
            _save_cwd(str(p))
            await msg.reply_text(f"✅ Git working directory set to:\n<code>{html.escape(str(p))}</code>", parse_mode="HTML")
            return

        # ── List repos ─────────────────────────────────────────────────────────
        if sub == "repos":
            await msg.reply_text("🔍 Searching for git repos…")
            repos = _find_git_repos()
            if not repos:
                await msg.reply_text("No git repos found. Use /git cd <path> to set one manually.")
                return
            lines = ["📁 <b>Git repos found:</b>\n"]
            for i, r in enumerate(repos, 1):
                is_current = " ← current" if r == cwd else ""
                lines.append(f"{i}. <code>{html.escape(r)}</code>{is_current}")
            lines.append(f"\n<i>Use /git cd &lt;path&gt; to select one</i>")
            await msg.reply_text("\n".join(lines), parse_mode="HTML")
            return

        # ── Clone ──────────────────────────────────────────────────────────────
        if sub == "clone":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/git clone https://github.com/user/repo</code>", parse_mode="HTML")
                return
            repo_url = args[1]
            dest = str(Path.home() / "Desktop")
            await msg.reply_text(f"⏳ Cloning <code>{html.escape(repo_url)}</code>…", parse_mode="HTML")
            ok, out = _run_git(["clone", repo_url], cwd=dest, timeout=120)
            if ok:
                # Auto-switch to cloned repo
                repo_name = repo_url.rstrip("/").split("/")[-1].replace(".git", "")
                new_cwd = str(Path(dest) / repo_name)
                if Path(new_cwd).exists():
                    _save_cwd(new_cwd)
                await msg.reply_text(
                    f"✅ Cloned to <code>{html.escape(dest)}/{html.escape(repo_name)}</code>\n"
                    f"Working directory set to this repo.",
                    parse_mode="HTML"
                )
            else:
                await msg.reply_text(f"❌ Clone failed:\n<code>{html.escape(out[:500])}</code>", parse_mode="HTML")
            return

        # ── Standard git commands ──────────────────────────────────────────────
        GIT_COMMANDS = {
            "status":   (["status", "--short", "--branch"], "📊 Git Status"),
            "log":      (["log", "--oneline", f"-{args[1] if len(args) > 1 else '10'}"], "📋 Recent Commits"),
            "diff":     (["diff", "--stat"], "📝 Uncommitted Changes"),
            "branch":   (["branch", "-a"], "🌿 Branches"),
            "pull":     (["pull"], "⬇️ Git Pull"),
            "push":     (["push"], "⬆️ Git Push"),
            "fetch":    (["fetch", "--all"], "🔄 Git Fetch"),
            "stash":    (["stash"], "📦 Stashed Changes"),
            "stash-pop":(["stash", "pop"], "📦 Stash Pop"),
        }

        if sub == "commit":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/git commit your commit message</code>", parse_mode="HTML")
                return
            commit_msg = " ".join(args[1:])
            ok1, out1 = _run_git(["add", "-A"], cwd=cwd)
            ok2, out2 = _run_git(["commit", "-m", commit_msg], cwd=cwd)
            if ok2:
                await msg.reply_text(
                    f"✅ <b>Committed</b>\n<code>{html.escape(out2[:300])}</code>",
                    parse_mode="HTML"
                )
            else:
                await msg.reply_text(f"❌ Commit failed:\n<code>{html.escape(out2[:300])}</code>", parse_mode="HTML")
            return

        if sub == "checkout":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/git checkout branch-name</code>", parse_mode="HTML")
                return
            branch = args[1]
            ok, out = _run_git(["checkout", branch], cwd=cwd)
            icon = "✅" if ok else "❌"
            await msg.reply_text(f"{icon} <code>{html.escape(out[:300])}</code>", parse_mode="HTML")
            return

        if sub == "diff" and len(args) > 1:
            # Full diff
            ok, out = _run_git(["diff"], cwd=cwd)
            if ok and out:
                from io import BytesIO
                bio = BytesIO(out.encode())
                bio.name = "git_diff.txt"
                await msg.reply_document(document=bio, filename="git_diff.txt",
                                         caption="📝 Full git diff")
            else:
                await msg.reply_text("📝 No uncommitted changes." if not out else f"❌ {html.escape(out[:300])}")
            return

        if sub in GIT_COMMANDS:
            git_args, label = GIT_COMMANDS[sub]
            await msg.reply_text(f"⏳ Running git {sub}…")
            ok, out = _run_git(git_args, cwd=cwd)
            icon = "✅" if ok else "❌"
            await msg.reply_text(
                f"{icon} <b>{label}</b>\n<i>{html.escape(cwd)}</i>\n\n"
                f"<code>{html.escape(out[:2000])}</code>",
                parse_mode="HTML"
            )
            return

        # ── Help ───────────────────────────────────────────────────────────────
        await msg.reply_text(
            f"🔧 <b>Git Commands</b>\n<i>Current repo: {html.escape(cwd)}</i>\n\n"
            "<code>/git status</code>            — working tree status\n"
            "<code>/git log [n]</code>           — last N commits\n"
            "<code>/git diff</code>              — uncommitted changes\n"
            "<code>/git pull</code>              — pull from remote\n"
            "<code>/git push</code>              — push to remote\n"
            "<code>/git fetch</code>             — fetch all remotes\n"
            "<code>/git branch</code>            — list branches\n"
            "<code>/git checkout &lt;branch&gt;</code> — switch branch\n"
            "<code>/git commit &lt;message&gt;</code>  — stage all + commit\n"
            "<code>/git clone &lt;url&gt;</code>       — clone repo\n"
            "<code>/git stash</code>             — stash changes\n"
            "<code>/git stash-pop</code>         — pop stash\n"
            "<code>/git repos</code>             — find repos on machine\n"
            "<code>/git cd &lt;path&gt;</code>         — set working repo",
            parse_mode="HTML"
        )
