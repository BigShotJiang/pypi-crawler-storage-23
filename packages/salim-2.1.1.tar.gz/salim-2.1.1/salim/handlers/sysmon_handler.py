"""
Salim SysMon Handler — Advanced system monitoring, network scanner, port checker.

Commands:
  /ports                   — list open ports on this machine
  /portscan 192.168.1.0/24 — scan local network for devices
  /netdevices              — show all devices on local network
  /syswatch                — start live system monitor (updates every 10s for 1 min)
  /whois <domain>          — WHOIS lookup
  /ping <host>             — ping a host
  /traceroute <host>       — traceroute to host
  /dns <domain>            — DNS lookup
  /myip                    — get public IP address
"""
from __future__ import annotations
import html
import logging
import re
import socket
import subprocess
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.sysmon")


def _run_cmd(cmd: list[str], timeout: int = 15) -> tuple[bool, str]:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode == 0, (r.stdout + r.stderr).strip()
    except FileNotFoundError:
        return False, f"Command '{cmd[0]}' not found"
    except subprocess.TimeoutExpired:
        return False, f"Timed out after {timeout}s"
    except Exception as e:
        return False, str(e)


def _get_local_ip() -> str:
    """Get local IP address."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def _check_port(host: str, port: int, timeout: float = 0.5) -> bool:
    """Check if a TCP port is open."""
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except Exception:
        return False


def _get_open_ports(host: str = "localhost", common_only: bool = True) -> list[tuple[int, str]]:
    """Scan common ports. Returns [(port, service_name)]."""
    COMMON_PORTS = {
        21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
        80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS", 445: "SMB",
        993: "IMAPS", 995: "POP3S", 1433: "MSSQL", 3306: "MySQL",
        3389: "RDP", 5432: "PostgreSQL", 5900: "VNC", 6379: "Redis",
        8080: "HTTP-Alt", 8443: "HTTPS-Alt", 27017: "MongoDB",
    }
    ports_to_check = list(COMMON_PORTS.keys()) if common_only else range(1, 1025)
    open_ports = []
    with ThreadPoolExecutor(max_workers=50) as executor:
        futures = {executor.submit(_check_port, host, p): p for p in ports_to_check}
        for future in as_completed(futures):
            port = futures[future]
            if future.result():
                svc = COMMON_PORTS.get(port, "unknown")
                open_ports.append((port, svc))
    return sorted(open_ports)


def _ping_host(host: str, count: int = 4) -> str:
    """Ping a host and return result string."""
    import platform
    plat = platform.system().lower()
    if plat == "windows":
        cmd = ["ping", "-n", str(count), host]
    else:
        cmd = ["ping", "-c", str(count), "-W", "2", host]
    ok, out = _run_cmd(cmd, timeout=20)
    return out


def _dns_lookup(domain: str) -> str:
    """Perform DNS lookup."""
    try:
        results = socket.getaddrinfo(domain, None)
        ips = list({r[4][0] for r in results})
        return f"Domain: {domain}\nIPs: {', '.join(ips)}"
    except Exception as e:
        return f"DNS lookup failed: {e}"


async def _get_public_ip() -> str:
    """Get public IP from multiple free services."""
    import httpx
    for url in ["https://api.ipify.org", "https://icanhazip.com", "https://ifconfig.me/ip"]:
        try:
            async with httpx.AsyncClient(timeout=5) as client:
                r = await client.get(url)
                return r.text.strip()
        except Exception:
            continue
    return "Could not determine public IP"


class SysMonHandlers:

    @require_auth
    async def cmd_ports(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/ports — list open ports on this machine."""
        msg = update.effective_message
        await msg.reply_text("🔍 Scanning common ports on localhost…")
        open_ports = _get_open_ports("localhost")
        if not open_ports:
            await msg.reply_text("✅ No common ports open.")
            return
        lines = [f"🔓 <b>Open Ports on Localhost</b>\n"]
        for port, svc in open_ports:
            lines.append(f"  <b>{port}</b>/tcp  {svc}")
        await msg.reply_text("\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_portscan(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/portscan <host> — scan ports on a specific host."""
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            await msg.reply_text("Usage: <code>/portscan 192.168.1.1</code>", parse_mode="HTML")
            return
        host = args[0]
        await msg.reply_text(f"🔍 Scanning ports on <code>{html.escape(host)}</code>…", parse_mode="HTML")
        open_ports = _get_open_ports(host)
        if not open_ports:
            await msg.reply_text(f"✅ No common ports open on {html.escape(host)}.")
            return
        lines = [f"🔓 <b>Open Ports on {html.escape(host)}</b>\n"]
        for port, svc in open_ports:
            lines.append(f"  <b>{port}</b>/tcp  {svc}")
        await msg.reply_text("\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_netdevices(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/netdevices — find devices on local network using ARP scan."""
        msg = update.effective_message
        local_ip = _get_local_ip()
        subnet = ".".join(local_ip.split(".")[:3]) + ".0/24"
        await msg.reply_text(f"🌐 Scanning network {html.escape(subnet)}…\n<i>This may take 30 seconds.</i>", parse_mode="HTML")

        # Try nmap first
        ok, out = _run_cmd(["nmap", "-sn", "-T4", subnet], timeout=60)
        if ok and "Nmap" in out:
            # Parse nmap output
            devices = re.findall(r"Nmap scan report for (.+)", out)
            macs    = re.findall(r"MAC Address: ([\w:]+)\s*\(([^)]*)\)", out)
            lines   = [f"🌐 <b>Network Devices on {html.escape(subnet)}</b>\n"]
            for i, dev in enumerate(devices):
                mac_info = macs[i-1] if i > 0 and i-1 < len(macs) else ("", "")
                mac_str  = f"  MAC: {mac_info[0]} ({mac_info[1]})" if mac_info[0] else ""
                lines.append(f"• <code>{html.escape(dev)}</code>{mac_str}")
            lines.append(f"\n<i>{len(devices)} device(s) found</i>")
            await msg.reply_text("\n".join(lines), parse_mode="HTML")
        else:
            # Fallback: ARP table
            ok2, out2 = _run_cmd(["arp", "-a"], timeout=10)
            if ok2:
                await msg.reply_text(
                    f"🌐 <b>ARP Table (known devices)</b>\n\n"
                    f"<code>{html.escape(out2[:2000])}</code>\n\n"
                    f"<i>Install nmap for full scan: apt install nmap / brew install nmap</i>",
                    parse_mode="HTML"
                )
            else:
                await msg.reply_text("❌ Could not scan network. Install nmap: <code>sudo apt install nmap</code>", parse_mode="HTML")

    @require_auth
    async def cmd_myip(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/myip — show local and public IP addresses."""
        msg = update.effective_message
        local_ip = _get_local_ip()
        public_ip = await _get_public_ip()
        await msg.reply_text(
            f"🌐 <b>IP Addresses</b>\n\n"
            f"🏠 Local (LAN):  <code>{local_ip}</code>\n"
            f"🌍 Public (WAN): <code>{public_ip}</code>",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_ping(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/ping <host> — ping a host."""
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            await msg.reply_text("Usage: <code>/ping google.com</code>", parse_mode="HTML")
            return
        host = args[0]
        await msg.reply_text(f"🏓 Pinging <code>{html.escape(host)}</code>…", parse_mode="HTML")
        result = _ping_host(host)
        # Extract stats
        stats = ""
        m = re.search(r"(?:rtt|round-trip|Minimum)[^\n]*", result, re.IGNORECASE)
        if m:
            stats = f"\n\n<b>Stats:</b> {html.escape(m.group(0))}"
        await msg.reply_text(
            f"🏓 <b>Ping {html.escape(host)}</b>\n\n"
            f"<code>{html.escape(result[:800])}</code>{stats}",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_dns(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/dns <domain> — DNS lookup."""
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            await msg.reply_text("Usage: <code>/dns google.com</code>", parse_mode="HTML")
            return
        domain = args[0]
        result = _dns_lookup(domain)
        await msg.reply_text(
            f"🔍 <b>DNS Lookup</b>\n\n<code>{html.escape(result)}</code>",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_traceroute(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/traceroute <host> — trace network path."""
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            await msg.reply_text("Usage: <code>/traceroute google.com</code>", parse_mode="HTML")
            return
        host = args[0]
        await msg.reply_text(f"🛤 Tracing route to <code>{html.escape(host)}</code>…", parse_mode="HTML")
        import platform
        cmd = ["traceroute", host] if platform.system() != "Windows" else ["tracert", host]
        ok, out = _run_cmd(cmd, timeout=30)
        await msg.reply_text(
            f"🛤 <b>Traceroute to {html.escape(host)}</b>\n\n"
            f"<code>{html.escape(out[:2000])}</code>",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_whois(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/whois <domain> — WHOIS lookup."""
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            await msg.reply_text("Usage: <code>/whois google.com</code>", parse_mode="HTML")
            return
        domain = args[0]
        await msg.reply_text(f"🔍 WHOIS lookup for <code>{html.escape(domain)}</code>…", parse_mode="HTML")
        ok, out = _run_cmd(["whois", domain], timeout=15)
        if ok:
            # Filter relevant lines
            relevant = [l for l in out.split("\n")
                        if any(k in l.lower() for k in
                               ["registrar", "expir", "creat", "updat", "name server",
                                "status", "registrant", "admin", "tech", "country"])]
            clean = "\n".join(relevant[:20]) or out[:500]
            await msg.reply_text(
                f"🔍 <b>WHOIS: {html.escape(domain)}</b>\n\n<code>{html.escape(clean[:1500])}</code>",
                parse_mode="HTML"
            )
        else:
            await msg.reply_text(
                f"❌ WHOIS failed.\n<code>{html.escape(out[:300])}</code>\n\n"
                f"Install whois: <code>sudo apt install whois</code>",
                parse_mode="HTML"
            )
