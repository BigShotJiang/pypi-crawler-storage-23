"""
Salim Transcript Handler — JSONL session transcripts, inspired by OpenClaw's
replayable audit log architecture. Every AI turn is appended to a JSONL file.

Commands:
  /transcript               — show recent conversation turns
  /transcript export        — send full session log as .jsonl file
  /transcript search <text> — search through all logged turns
  /transcript stats         — token usage, cost estimates, session stats
  /transcript clear         — clear current session log
"""
from __future__ import annotations
import json
import logging
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.transcript")

TRANSCRIPT_DIR = Path.home() / ".salim" / "transcripts"


def _session_file(user_id: int) -> Path:
    TRANSCRIPT_DIR.mkdir(parents=True, exist_ok=True)
    today = datetime.now().strftime("%Y-%m-%d")
    return TRANSCRIPT_DIR / f"session_{user_id}_{today}.jsonl"


def append_turn(user_id: int, role: str, content: str,
                tokens_in: int = 0, tokens_out: int = 0,
                tool: str = "", model: str = ""):
    """Append a turn to the JSONL transcript. Called by AI handler."""
    entry = {
        "ts":         datetime.now().isoformat(),
        "user_id":    user_id,
        "role":       role,
        "content":    content[:2000],
        "model":      model,
        "tokens_in":  tokens_in,
        "tokens_out": tokens_out,
    }
    if tool:
        entry["tool"] = tool
    try:
        with _session_file(user_id).open("a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception as e:
        logger.debug(f"Transcript write: {e}")


def _load_turns(user_id: int, days: int = 1) -> list[dict]:
    turns = []
    for i in range(days):
        from datetime import timedelta
        day = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
        f   = TRANSCRIPT_DIR / f"session_{user_id}_{day}.jsonl"
        if f.exists():
            for line in f.read_text(encoding="utf-8").splitlines():
                try:
                    turns.append(json.loads(line))
                except Exception:
                    pass
    return turns


class TranscriptHandlers:

    @require_auth
    async def cmd_transcript(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /transcript           — recent turns
        /transcript export    — download JSONL log
        /transcript search X  — search turns
        /transcript stats     — usage stats
        /transcript clear     — wipe today's log
        """
        msg     = update.effective_message
        uid     = update.effective_user.id
        args    = ctx.args or []
        sub     = args[0].lower() if args else "show"

        if sub == "export":
            sf = _session_file(uid)
            if not sf.exists() or sf.stat().st_size == 0:
                await msg.reply_text("📭 No transcript data for today.")
                return
            await msg.reply_document(
                document=sf.open("rb"),
                filename=sf.name,
                caption=f"📄 Session transcript — {datetime.now().strftime('%Y-%m-%d')}"
            )
            return

        if sub == "search" and len(args) > 1:
            query  = " ".join(args[1:]).lower()
            turns  = _load_turns(uid, days=7)
            hits   = [t for t in turns if query in t.get("content", "").lower()]
            if not hits:
                await msg.reply_text(f"🔍 No transcript entries matching '<b>{query}</b>'.", parse_mode="HTML")
                return
            lines = [f"🔍 <b>Transcript search: '{query}' ({len(hits)} hits)</b>\n"]
            for t in hits[-8:]:
                ts   = t["ts"][:16].replace("T", " ")
                role = "You" if t["role"] == "user" else "Salim"
                snip = t["content"][:120].replace("\n", " ")
                lines.append(f"<b>{role}</b> [{ts}]: {snip}")
            await msg.reply_text("\n\n".join(lines), parse_mode="HTML")
            return

        if sub == "stats":
            turns = _load_turns(uid, days=30)
            if not turns:
                await msg.reply_text("📊 No transcript data yet.")
                return
            total_in  = sum(t.get("tokens_in",  0) for t in turns)
            total_out = sum(t.get("tokens_out", 0) for t in turns)
            user_turns   = [t for t in turns if t.get("role") == "user"]
            agent_turns  = [t for t in turns if t.get("role") == "assistant"]
            # Cost estimate: $3/M in, $15/M out (Sonnet approximate)
            cost = (total_in * 3 + total_out * 15) / 1_000_000
            models = {}
            for t in turns:
                m = t.get("model", "unknown")
                if m: models[m] = models.get(m, 0) + 1
            model_str = ", ".join(f"{m}×{c}" for m, c in sorted(models.items(), key=lambda x: -x[1])[:3])
            await msg.reply_text(
                f"📊 <b>Transcript Stats (30 days)</b>\n\n"
                f"💬 Your messages:   {len(user_turns)}\n"
                f"🤖 Salim replies:   {len(agent_turns)}\n"
                f"📥 Tokens in:       {total_in:,}\n"
                f"📤 Tokens out:      {total_out:,}\n"
                f"💰 Est. cost:       ~${cost:.4f}\n"
                f"🧠 Models used:     {model_str or 'n/a'}",
                parse_mode="HTML"
            )
            return

        if sub == "clear":
            sf = _session_file(uid)
            if sf.exists():
                sf.write_text("")
            await msg.reply_text("🗑️ Today's transcript cleared.")
            return

        # Default: show recent turns
        turns = _load_turns(uid, days=1)
        if not turns:
            await msg.reply_text(
                "📄 No transcript yet today.\n\n"
                "Every AI conversation is automatically logged.\n"
                "<code>/transcript stats</code> — 30-day usage\n"
                "<code>/transcript export</code> — download JSONL",
                parse_mode="HTML"
            )
            return

        lines = [f"📄 <b>Today's Transcript ({len(turns)} turns)</b>\n"]
        for t in turns[-10:]:
            ts   = t["ts"][11:16]
            role = "👤" if t["role"] == "user" else "🤖"
            snip = t["content"][:80].replace("\n", " ")
            lines.append(f"{role} [{ts}] {snip}")
        lines.append("\n<i>/transcript export to download full JSONL</i>")
        await msg.reply_text("\n".join(lines), parse_mode="HTML")
