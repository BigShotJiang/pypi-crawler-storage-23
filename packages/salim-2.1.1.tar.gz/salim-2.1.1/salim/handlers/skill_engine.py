"""
Salim Skill Engine — Reads .md skill files and applies their rules to tasks.

Skills are stored as SKILL.md files (like /mnt/skills/public/docx/SKILL.md).
This engine:
  1. Discovers skill .md files in ~/.salim/skill_docs/
  2. Downloads/copies skills from the built-in skills directory
  3. Selects the right skill for each task type
  4. Returns the skill's guidance text to inject into AI system prompts
  5. Runs skill-mandated tools (node docx-js, openpyxl, etc.)

Skills are REAL .md files — not Python files. The .md contains the full
professional guidance the AI uses to produce high-quality output.
"""
from __future__ import annotations

import json
import logging
import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Optional

logger = logging.getLogger("salim.skill_engine")

# Where we store downloaded skill .md files
SKILL_DOCS_DIR = Path.home() / ".salim" / "skill_docs"

# Built-in skill paths (installed with package / available in container)
BUILTIN_SKILL_PATHS = [
    Path("/mnt/skills/public/docx"),
    Path("/mnt/skills/public/xlsx"),
    Path("/mnt/skills/public/pptx"),
    Path("/mnt/skills/public/pdf"),
    Path("/mnt/skills/public/frontend-design"),
]

# Task type → skill name mapping
TASK_SKILL_MAP = {
    # Document types
    "docx":  "docx",
    "word":  "docx",
    "doc":   "docx",
    "xlsx":  "xlsx",
    "excel": "xlsx",
    "xls":   "xlsx",
    "csv":   "xlsx",
    "pptx":  "pptx",
    "ppt":   "pptx",
    "presentation": "pptx",
    "slides": "pptx",
    "pdf":   "pdf",
    # Action types
    "email": "email",
    "report": "docx",
    "invoice": "docx",
    "letter": "docx",
    "contract": "docx",
    "spreadsheet": "xlsx",
    "budget": "xlsx",
    "chart": "xlsx",
    "dashboard": "xlsx",
}

# Scripts bundled with docx skill
DOCX_SCRIPTS_DIR = Path("/mnt/skills/public/docx/scripts")
XLSX_SCRIPTS_DIR = Path("/mnt/skills/public/xlsx/scripts")
PPTX_SCRIPTS_DIR = Path("/mnt/skills/public/pptx/scripts")


def _ensure_dirs():
    SKILL_DOCS_DIR.mkdir(parents=True, mode=0o755, exist_ok=True)


def bootstrap_skills() -> list[str]:
    """
    Copy built-in skill .md files to ~/.salim/skill_docs/.
    Returns list of skill names bootstrapped.
    """
    _ensure_dirs()
    bootstrapped = []
    for skill_path in BUILTIN_SKILL_PATHS:
        md_file = skill_path / "SKILL.md"
        if md_file.exists():
            skill_name = skill_path.name
            dest = SKILL_DOCS_DIR / f"{skill_name}.md"
            if not dest.exists():
                shutil.copy2(str(md_file), str(dest))
                bootstrapped.append(skill_name)
                logger.info(f"Bootstrapped skill: {skill_name} → {dest}")
    return bootstrapped


def list_skills() -> list[dict]:
    """Return all available skill .md files."""
    _ensure_dirs()
    skills = []
    for md_file in sorted(SKILL_DOCS_DIR.glob("*.md")):
        content = md_file.read_text(encoding="utf-8")
        # Extract name/description from frontmatter
        name = md_file.stem
        description = ""
        m = re.search(r'^description:\s*"?([^"\n]+)"?', content, re.MULTILINE)
        if m:
            description = m.group(1).strip()[:120]
        skills.append({
            "name": name,
            "file": str(md_file),
            "description": description,
            "size": len(content),
        })
    return skills


def get_skill_for_task(task_description: str, doc_type: str = "") -> Optional[dict]:
    """
    Select the best skill for a task based on document type and description.
    Returns dict with {name, content, guidance} or None.
    """
    _ensure_dirs()
    
    # Determine skill name
    skill_name = None
    
    # Check explicit doc_type first
    if doc_type:
        skill_name = TASK_SKILL_MAP.get(doc_type.lower())
    
    # Fall back to scanning task description
    if not skill_name:
        task_lower = task_description.lower()
        for keyword, sname in TASK_SKILL_MAP.items():
            if keyword in task_lower:
                skill_name = sname
                break
    
    if not skill_name:
        return None
    
    # Load the skill .md
    md_file = SKILL_DOCS_DIR / f"{skill_name}.md"
    if not md_file.exists():
        # Try to bootstrap it
        bootstrap_skills()
        if not md_file.exists():
            return None
    
    content = md_file.read_text(encoding="utf-8")
    
    # Extract key guidance sections (not the entire file — too long for prompt)
    guidance = _extract_key_guidance(content, skill_name)
    
    return {
        "name": skill_name,
        "file": str(md_file),
        "content": content,
        "guidance": guidance,
    }


def _extract_key_guidance(content: str, skill_name: str) -> str:
    """Extract the most relevant guidance from a skill .md for use in prompts."""
    lines = content.split("\n")
    
    # Skip frontmatter
    start = 0
    if lines and lines[0].startswith("---"):
        for i, line in enumerate(lines[1:], 1):
            if line.strip() == "---":
                start = i + 1
                break
    
    # For docx: grab Critical Rules + Tables + Lists sections
    if skill_name == "docx":
        sections = []
        capture = False
        for line in lines[start:]:
            if any(h in line for h in ["## Creating New Documents", "### Critical Rules", 
                                        "### Tables", "### Lists", "### Styles"]):
                capture = True
            elif line.startswith("## ") and "Creating" not in line and "Critical" not in line:
                if capture and sections:
                    break
            if capture:
                sections.append(line)
        return "\n".join(sections[:120])  # cap at ~120 lines
    
    # For xlsx: grab key openpyxl patterns + formula rules
    if skill_name == "xlsx":
        sections = []
        capture = False
        for line in lines[start:]:
            if any(h in line for h in ["### Creating new Excel", "## CRITICAL:", 
                                        "Color Coding", "Number Formatting"]):
                capture = True
            elif line.startswith("## Best Practices"):
                break
            if capture:
                sections.append(line)
        return "\n".join(sections[:100])
    
    # For pptx: grab design + pptxgenjs basics
    if skill_name == "pptx":
        sections = []
        capture = False
        for line in lines[start:]:
            if any(h in line for h in ["## Design Ideas", "## Quick Reference",
                                        "### Color Palettes", "### Typography"]):
                capture = True
            elif line.startswith("## ") and capture and len(sections) > 20:
                break
            if capture:
                sections.append(line)
        return "\n".join(sections[:80])
    
    # For pdf: grab quick start + Python libraries
    if skill_name == "pdf":
        sections = []
        capture = False
        for line in lines[start:]:
            if any(h in line for h in ["## Quick Start", "### pypdf", "### reportlab"]):
                capture = True
            elif line.startswith("## ") and capture and len(sections) > 30:
                break
            if capture:
                sections.append(line)
        return "\n".join(sections[:80])
    
    # Default: first 80 lines after frontmatter
    return "\n".join(lines[start:start + 80])


def create_docx_via_nodejs(content_spec: dict, output_path: Path) -> tuple[bool, str]:
    """
    Create a professional DOCX using docx-js (Node.js) following the skill's rules.
    content_spec: {title, sections: [{heading, level, text, bullets, table}]}
    """
    js_script = _build_docx_js(content_spec, str(output_path))
    
    with tempfile.NamedTemporaryFile(mode="w", suffix=".mjs", delete=False, encoding="utf-8") as f:
        f.write(js_script)
        script_path = f.name
    
    try:
        result = subprocess.run(
            ["node", script_path],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0 and output_path.exists():
            return True, f"Created {output_path.name}"
        else:
            err = (result.stderr or result.stdout or "unknown error")[:500]
            return False, f"Node error: {err}"
    except subprocess.TimeoutExpired:
        return False, "DOCX generation timed out"
    except Exception as e:
        return False, f"DOCX generation error: {e}"
    finally:
        try:
            os.unlink(script_path)
        except Exception:
            pass


def _build_docx_js(spec: dict, output_path: str) -> str:
    """Build a Node.js script to create a DOCX using docx-js following skill rules."""
    title = spec.get("title", "Document")
    sections = spec.get("sections", [])
    
    # Build sections JS code
    children_code = []
    
    # Add title
    children_code.append(f"""
    new Paragraph({{
        heading: HeadingLevel.TITLE,
        children: [new TextRun({{ text: {json.dumps(title)}, bold: true, size: 52, font: "Arial" }})],
        spacing: {{ before: 0, after: 300 }},
        alignment: AlignmentType.CENTER,
    }}),""")
    
    for section in sections:
        heading = section.get("heading", "")
        level = section.get("level", 1)
        text = section.get("text", "")
        bullets = section.get("bullets", [])
        table_data = section.get("table", None)
        
        heading_level_map = {1: "HEADING_1", 2: "HEADING_2", 3: "HEADING_3"}
        hl = heading_level_map.get(level, "HEADING_2")
        
        if heading:
            children_code.append(f"""
    new Paragraph({{
        heading: HeadingLevel.{hl},
        children: [new TextRun({{ text: {json.dumps(heading)}, bold: true, font: "Arial", 
            size: {48 - (level-1)*8} }})],
        spacing: {{ before: 240, after: 120 }},
    }}),""")
        
        if text:
            # Handle bold **text** and italic *text*
            runs = _parse_markdown_runs(text)
            children_code.append(f"""
    new Paragraph({{
        children: [{runs}],
        spacing: {{ before: 80, after: 80 }},
    }}),""")
        
        for bullet in bullets:
            bullet_escaped = json.dumps(str(bullet))
            children_code.append(f"""
    new Paragraph({{
        numbering: {{ reference: "bullets", level: 0 }},
        children: [new TextRun({{ text: {bullet_escaped}, font: "Arial", size: 24 }})],
        spacing: {{ before: 40, after: 40 }},
    }}),""")
        
        if table_data and len(table_data) > 0:
            table_js = _build_table_js(table_data)
            children_code.append(table_js)
    
    children_str = "\n".join(children_code)
    
    return f"""
import {{ createRequire }} from 'module';
const require = createRequire(import.meta.url);
const {{ Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
         HeadingLevel, AlignmentType, BorderStyle, WidthType, ShadingType,
         VerticalAlign, LevelFormat }} = require('docx');
const {{ writeFileSync }} = require('fs');

// Following SKILL.md rules: dual widths, DXA units, CLEAR shading, proper bullets
const doc = new Document({{
  numbering: {{
    config: [
      {{
        reference: "bullets",
        levels: [{{
          level: 0,
          format: LevelFormat.BULLET,
          text: "•",
          alignment: AlignmentType.LEFT,
          style: {{ paragraph: {{ indent: {{ left: 720, hanging: 360 }} }} }}
        }}, {{
          level: 1,
          format: LevelFormat.BULLET,
          text: "◦",
          alignment: AlignmentType.LEFT,
          style: {{ paragraph: {{ indent: {{ left: 1080, hanging: 360 }} }} }}
        }}]
      }},
      {{
        reference: "numbers",
        levels: [{{
          level: 0,
          format: LevelFormat.DECIMAL,
          text: "%1.",
          alignment: AlignmentType.LEFT,
          style: {{ paragraph: {{ indent: {{ left: 720, hanging: 360 }} }} }}
        }}]
      }}
    ]
  }},
  styles: {{
    default: {{
      document: {{ run: {{ font: "Arial", size: 24 }} }}
    }},
    paragraphStyles: [
      {{
        id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: {{ size: 48, bold: true, font: "Arial", color: "1F3864" }},
        paragraph: {{ spacing: {{ before: 360, after: 180 }}, outlineLevel: 0 }}
      }},
      {{
        id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: {{ size: 36, bold: true, font: "Arial", color: "2E75B6" }},
        paragraph: {{ spacing: {{ before: 240, after: 120 }}, outlineLevel: 1 }}
      }},
      {{
        id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: {{ size: 28, bold: true, font: "Arial", color: "404040" }},
        paragraph: {{ spacing: {{ before: 180, after: 80 }}, outlineLevel: 2 }}
      }},
    ]
  }},
  sections: [{{
    properties: {{
      page: {{
        size: {{ width: 12240, height: 15840 }},  // US Letter
        margin: {{ top: 1440, right: 1440, bottom: 1440, left: 1440 }}
      }}
    }},
    children: [
{children_str}
    ]
  }}]
}});

Packer.toBuffer(doc).then(buffer => {{
  writeFileSync({json.dumps(output_path)}, buffer);
  console.log("OK:" + {json.dumps(output_path)});
}}).catch(err => {{
  console.error("ERR:" + err.message);
  process.exit(1);
}});
"""


def _parse_markdown_runs(text: str) -> str:
    """Convert **bold** and *italic* markdown to docx TextRun JS code."""
    # Split on bold/italic markers
    parts = re.split(r'(\*\*[^*]+\*\*|\*[^*]+\*)', text)
    runs = []
    for part in parts:
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            inner = part[2:-2]
            runs.append(f'new TextRun({{ text: {json.dumps(inner)}, bold: true, font: "Arial", size: 24 }})')
        elif part.startswith("*") and part.endswith("*"):
            inner = part[1:-1]
            runs.append(f'new TextRun({{ text: {json.dumps(inner)}, italics: true, font: "Arial", size: 24 }})')
        else:
            runs.append(f'new TextRun({{ text: {json.dumps(part)}, font: "Arial", size: 24 }})')
    return ", ".join(runs) if runs else f'new TextRun({{ text: {json.dumps(text)}, font: "Arial", size: 24 }})'


def _build_table_js(table_data: list[list]) -> str:
    """Build a docx-js Table from a 2D array. First row = header."""
    if not table_data:
        return ""
    
    num_cols = max(len(row) for row in table_data)
    col_width = 9360 // max(num_cols, 1)  # US Letter content width in DXA
    col_widths_arr = ", ".join([str(col_width)] * num_cols)
    
    rows_code = []
    for row_idx, row in enumerate(table_data):
        is_header = (row_idx == 0)
        bg = "2E75B6" if is_header else ("F2F2F2" if row_idx % 2 == 1 else "FFFFFF")
        text_color = "FFFFFF" if is_header else "000000"
        
        cells_code = []
        for col_idx in range(num_cols):
            cell_text = str(row[col_idx]) if col_idx < len(row) else ""
            cells_code.append(f"""
          new TableCell({{
            borders: {{
              top: {{ style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" }},
              bottom: {{ style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" }},
              left: {{ style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" }},
              right: {{ style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" }},
            }},
            width: {{ size: {col_width}, type: WidthType.DXA }},
            shading: {{ fill: "{bg}", type: ShadingType.CLEAR }},
            margins: {{ top: 80, bottom: 80, left: 120, right: 120 }},
            children: [new Paragraph({{
              children: [new TextRun({{ 
                text: {json.dumps(cell_text)}, 
                bold: {'true' if is_header else 'false'},
                font: "Arial", size: 22,
                color: "{text_color}"
              }})],
              alignment: AlignmentType.{"CENTER" if is_header else "LEFT"},
            }})],
          }})""")
        
        rows_code.append(f"""
        new TableRow({{
          tableHeader: {'true' if is_header else 'false'},
          children: [{",".join(cells_code)}]
        }})""")
    
    rows_str = ",\n".join(rows_code)
    
    return f"""
    new Table({{
      width: {{ size: 9360, type: WidthType.DXA }},
      columnWidths: [{col_widths_arr}],
      rows: [{rows_str}]
    }}),
    new Paragraph({{ children: [], spacing: {{ before: 120, after: 120 }} }}),"""


def create_xlsx_professional(spec: dict, output_path: Path) -> tuple[bool, str]:
    """
    Create professional XLSX using openpyxl following the skill's rules.
    Uses real Excel formulas, proper formatting, color-coded cells.
    """
    py_script = _build_xlsx_python(spec, str(output_path))
    
    with tempfile.NamedTemporaryFile(mode="w", suffix=".py", delete=False, encoding="utf-8") as f:
        f.write(py_script)
        script_path = f.name
    
    try:
        result = subprocess.run(
            ["python3", script_path],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0 and output_path.exists():
            return True, f"Created {output_path.name}"
        else:
            err = (result.stderr or result.stdout or "unknown error")[:500]
            return False, f"Python error: {err}"
    except subprocess.TimeoutExpired:
        return False, "XLSX generation timed out"
    except Exception as e:
        return False, f"XLSX generation error: {e}"
    finally:
        try:
            os.unlink(script_path)
        except Exception:
            pass


def _build_xlsx_python(spec: dict, output_path: str) -> str:
    """Build Python script for professional XLSX creation per skill rules."""
    title = spec.get("title", "Spreadsheet")
    sheets = spec.get("sheets", [])
    
    if not sheets:
        sheets = [{"name": "Sheet1", "headers": [], "data": [], "formulas": []}]
    
    script_lines = ["""
from openpyxl import Workbook
from openpyxl.styles import (Font, PatternFill, Alignment, Border, Side,
                               GradientFill, numbers)
from openpyxl.utils import get_column_letter
from openpyxl.styles.numbers import FORMAT_NUMBER_COMMA_SEPARATED1
import json

wb = Workbook()
wb.remove(wb.active)  # Remove default sheet
"""]
    
    for sheet_idx, sheet in enumerate(sheets):
        sheet_name = sheet.get("name", f"Sheet{sheet_idx+1}")
        headers = sheet.get("headers", [])
        data = sheet.get("data", [])
        formulas = sheet.get("formulas", [])
        col_formats = sheet.get("column_formats", {})
        
        script_lines.append(f"""
ws = wb.create_sheet({json.dumps(sheet_name)})

# ── Header styling (blue background, white bold text) ──
header_font = Font(name='Arial', bold=True, color='FFFFFF', size=11)
header_fill = PatternFill('solid', start_color='2E75B6')
header_align = Alignment(horizontal='center', vertical='center', wrap_text=True)
thin = Side(style='thin', color='CCCCCC')
border = Border(left=thin, right=thin, top=thin, bottom=thin)

headers = {json.dumps(headers)}
for col_idx, header in enumerate(headers, 1):
    cell = ws.cell(row=1, column=col_idx, value=header)
    cell.font = header_font
    cell.fill = header_fill
    cell.alignment = header_align
    cell.border = border

# ── Data rows ──
data = {json.dumps(data)}
for row_idx, row in enumerate(data, 2):
    is_even = row_idx % 2 == 0
    row_fill = PatternFill('solid', start_color='EEF3FA') if is_even else PatternFill('solid', start_color='FFFFFF')
    for col_idx, value in enumerate(row, 1):
        cell = ws.cell(row=row_idx, column=col_idx, value=value)
        cell.fill = row_fill
        cell.border = border
        cell.font = Font(name='Arial', size=10)
        cell.alignment = Alignment(horizontal='left', vertical='center')

# ── Excel formulas (NOT hardcoded Python calculations) ──
formulas = {json.dumps(formulas)}
for formula_spec in formulas:
    cell_ref = formula_spec.get('cell', '')
    formula = formula_spec.get('formula', '')
    label = formula_spec.get('label', '')
    if cell_ref and formula:
        cell = ws[cell_ref]
        cell.value = formula  # Real Excel formula string
        cell.font = Font(name='Arial', bold=True, size=10, color='000000')  # Black = formula per skill
        if label:
            # Put label in adjacent cell
            import re
            m = re.match(r'([A-Z]+)(\\d+)', cell_ref)
            if m:
                col_letter = m.group(1)
                row_num = int(m.group(2))
                # Label goes one column to the left
                from openpyxl.utils import column_index_from_string
                col_num = column_index_from_string(col_letter)
                if col_num > 1:
                    label_cell = ws.cell(row=row_num, column=col_num-1)
                    label_cell.value = label
                    label_cell.font = Font(name='Arial', bold=True, size=10)

# ── Auto-fit column widths ──
for col in ws.columns:
    max_len = 0
    col_letter = get_column_letter(col[0].column)
    for cell in col:
        try:
            val = str(cell.value) if cell.value else ''
            if len(val) > max_len:
                max_len = len(val)
        except Exception:
            pass
    ws.column_dimensions[col_letter].width = min(max(max_len + 3, 10), 40)

# ── Freeze top row ──
ws.freeze_panes = 'A2'

# ── Row height for header ──
ws.row_dimensions[1].height = 30
""")
    
    script_lines.append(f"""
wb.save({json.dumps(output_path)})
print("OK:" + {json.dumps(output_path)})
""")
    
    return "\n".join(script_lines)


def create_pptx_via_nodejs(spec: dict, output_path: Path) -> tuple[bool, str]:
    """
    Create professional PPTX using pptxgenjs following the skill's design rules.
    """
    js_script = _build_pptx_js(spec, str(output_path))
    
    with tempfile.NamedTemporaryFile(mode="w", suffix=".mjs", delete=False, encoding="utf-8") as f:
        f.write(js_script)
        script_path = f.name
    
    try:
        result = subprocess.run(
            ["node", script_path],
            capture_output=True, text=True, timeout=45
        )
        if result.returncode == 0 and output_path.exists():
            return True, f"Created {output_path.name}"
        else:
            err = (result.stderr or result.stdout or "unknown error")[:500]
            return False, f"Node error: {err}"
    except subprocess.TimeoutExpired:
        return False, "PPTX generation timed out"
    except Exception as e:
        return False, f"PPTX generation error: {e}"
    finally:
        try:
            os.unlink(script_path)
        except Exception:
            pass


def _build_pptx_js(spec: dict, output_path: str) -> str:
    """Build pptxgenjs script for professional presentation."""
    title = spec.get("title", "Presentation")
    slides = spec.get("slides", [])
    theme = spec.get("theme", {
        "primary": "1F3864",
        "secondary": "2E75B6", 
        "accent": "FFFFFF",
        "dark": "1F3864",
        "light": "EEF3FA",
    })
    
    slides_code = []
    
    for i, slide in enumerate(slides):
        slide_title = slide.get("title", "")
        slide_body = slide.get("body", "")
        bullets = slide.get("bullets", [])
        layout = slide.get("layout", "title_content" if i > 0 else "title")
        
        is_title_slide = (i == 0 or layout == "title")
        bg_color = theme["dark"] if is_title_slide else "FFFFFF"
        text_color = "FFFFFF" if is_title_slide else theme["dark"]
        
        slide_lines = [f"\n// ── Slide {i+1}: {slide_title[:40]} ──"]
        slide_lines.append("{ const slide = pres.addSlide();")
        
        # Background
        slide_lines.append(f'  slide.background = {{ color: "{bg_color}" }};')
        
        # Accent bar
        if not is_title_slide:
            slide_lines.append(f'  slide.addShape(pres.ShapeType.rect, {{ x: 0, y: 0, w: 10, h: 0.08, fill: {{ color: "{theme["secondary"]}" }} }});')
        
        # Title
        if slide_title:
            title_y = "2.2" if is_title_slide else "0.2"
            title_size = 44 if is_title_slide else 28
            slide_lines.append(f"""  slide.addText({json.dumps(slide_title)}, {{
    x: 0.5, y: {title_y}, w: 9, h: 1.2,
    fontSize: {title_size}, bold: true, fontFace: "Arial",
    color: "{text_color}", align: "{"center" if is_title_slide else "left"}",
    valign: "middle"
  }});""")
        
        # Body text
        if slide_body:
            body_y = "3.6" if is_title_slide else "1.6"
            body_color = "CADCFC" if is_title_slide else "404040"
            slide_lines.append(f"""  slide.addText({json.dumps(slide_body)}, {{
    x: 0.5, y: {body_y}, w: 9, h: 0.8,
    fontSize: 18, fontFace: "Arial",
    color: "{body_color}", align: "{"center" if is_title_slide else "left"}"
  }});""")
        
        # Bullets
        if bullets:
            bullet_items = []
            for b in bullets:
                bullet_items.append(
                    f'{{ text: {json.dumps(str(b))}, options: {{ bullet: true, breakLine: true }} }}'
                )
            bullets_str = ",\n    ".join(bullet_items)
            slide_lines.append(f"""  slide.addText([
    {bullets_str}
  ], {{
    x: 0.5, y: 1.7, w: 9, h: 3.5,
    fontSize: 16, fontFace: "Arial",
    color: "363636",
    valign: "top"
  }});""")
        
        # Slide number (not on title slide)
        if not is_title_slide:
            slide_lines.append(f"""  slide.addText("{i+1}", {{
    x: 9.5, y: 5.3, w: 0.5, h: 0.3,
    fontSize: 10, color: "999999", align: "right"
  }});""")
        
        slide_lines.append("}")
        slides_code.append("\n".join(slide_lines))
    
    slides_str = "\n".join(slides_code)
    
    return f"""
import {{ createRequire }} from 'module';
const require = createRequire(import.meta.url);
const pptxgen = require('pptxgenjs');

const pres = new pptxgen();
pres.layout = 'LAYOUT_16x9';
pres.title = {json.dumps(title)};
pres.author = 'Salim AI';

{slides_str}

pres.writeFile({{ fileName: {json.dumps(output_path)} }}).then(() => {{
  console.log("OK:" + {json.dumps(output_path)});
}}).catch(err => {{
  console.error("ERR:" + err.message);
  process.exit(1);
}});
"""


def build_html_email(to: str, subject: str, body_text: str,
                     sender_name: str = "Salim AI") -> str:
    """
    Build a beautiful HTML email following email design best practices.
    Returns the complete HTML string.
    """
    # Convert **bold** and *italic* markdown in body
    body_html = body_text
    body_html = re.sub(r'\*\*([^*]+)\*\*', r'<strong>\1</strong>', body_html)
    body_html = re.sub(r'\*([^*]+)\*', r'<em>\1</em>', body_html)
    
    # Convert newlines to <br> or paragraph breaks
    paragraphs = body_html.split("\n\n")
    body_paras = "".join(
        f"<p style='margin: 0 0 16px 0; color: #374151; line-height: 1.7;'>{p.replace(chr(10), '<br>')}</p>"
        for p in paragraphs if p.strip()
    )
    
    # Extract greeting line if present
    lines = body_text.strip().split("\n")
    greeting = ""
    if lines and (lines[0].startswith("Dear") or lines[0].startswith("Hi") or lines[0].startswith("Hello")):
        greeting = lines[0]
    
    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{subject}</title>
</head>
<body style="margin:0;padding:0;background-color:#F3F4F6;font-family:Arial,Helvetica,sans-serif;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#F3F4F6;padding:32px 0;">
    <tr><td align="center">
      <table width="600" cellpadding="0" cellspacing="0" style="background:#FFFFFF;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,0.08);">
        
        <!-- Header -->
        <tr>
          <td style="background:linear-gradient(135deg,#1F3864 0%,#2E75B6 100%);padding:32px 40px;">
            <h1 style="margin:0;color:#FFFFFF;font-size:24px;font-weight:700;letter-spacing:-0.5px;">{subject}</h1>
            <p style="margin:8px 0 0;color:#93C5FD;font-size:13px;">From {sender_name}</p>
          </td>
        </tr>
        
        <!-- Body -->
        <tr>
          <td style="padding:40px;">
            {body_paras}
          </td>
        </tr>
        
        <!-- Divider -->
        <tr>
          <td style="padding:0 40px;">
            <hr style="border:none;border-top:1px solid #E5E7EB;margin:0;">
          </td>
        </tr>
        
        <!-- Footer -->
        <tr>
          <td style="padding:24px 40px;background:#F9FAFB;border-top:1px solid #E5E7EB;">
            <p style="margin:0;color:#9CA3AF;font-size:12px;text-align:center;">
              Sent via <strong style="color:#2E75B6;">Salim AI</strong> · Your intelligent assistant
            </p>
          </td>
        </tr>
        
      </table>
    </td></tr>
  </table>
</body>
</html>"""
    
    return html


def get_skill_summary() -> str:
    """Return a formatted list of available skills for display."""
    _ensure_dirs()
    bootstrap_skills()
    skills = list_skills()
    if not skills:
        return "No skills loaded yet."
    
    lines = ["📚 <b>Available Skills (SKILL.md)</b>\n"]
    for s in skills:
        lines.append(f"• <b>{s['name']}</b> — {s['description'][:80]}")
    return "\n".join(lines)
