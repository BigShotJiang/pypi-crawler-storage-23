"""
Salim Translate Handler v2 — Advanced Translation

Improvements over v1:
  - User default target language (saved per user)
  - Instance health-check cache (avoids re-trying dead LibreTranslate servers)
  - DeepL free API as real fallback (no API key needed for free tier)
  - Language detection display ("detected: Spanish")
  - Translation history: /transhistory
  - Batch file translation: send a .txt file for full translation
  - Confidence/quality indicator from DeepL

Auto-installed: httpx>=0.25 (already in deps)

Commands:
  /translate Hello world to Arabic      — translate text
  /translate Hello world                — auto-detect → English (or your default)
  /tl ar Hello world                    — shorthand: /tl <lang> <text>
  /tl Hello world                       — use your saved default language
  /translate setlang Arabic             — save your default target language
  /translate lang                       — show your current default language
  /transhistory                         — view recent translations
"""
from __future__ import annotations

import json
import logging
from datetime import datetime
from pathlib import Path

import httpx
from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.translate")

TRANS_CFG   = Path.home() / ".salim" / "translate_config.json"
TRANS_HIST  = Path.home() / ".salim" / "translate_history.json"

# Public LibreTranslate instances — health-checked and cached
PUBLIC_INSTANCES = [
    "https://libretranslate.de",
    "https://translate.terraprint.co",
    "https://lt.vern.cc",
    "https://libretranslate.com",
]

LANG_NAMES = {
    "en":"English","ar":"Arabic","fr":"French","de":"German","es":"Spanish",
    "it":"Italian","pt":"Portuguese","ru":"Russian","zh":"Chinese","ja":"Japanese",
    "ko":"Korean","hi":"Hindi","ur":"Urdu","tr":"Turkish","nl":"Dutch",
    "pl":"Polish","sv":"Swedish","da":"Danish","fi":"Finnish","no":"Norwegian",
    "fa":"Persian","he":"Hebrew","th":"Thai","vi":"Vietnamese","id":"Indonesian",
    "ms":"Malay","bn":"Bengali","ta":"Tamil","te":"Telugu","mr":"Marathi",
    "gu":"Gujarati","kn":"Kannada","ml":"Malayalam","si":"Sinhala","uk":"Ukrainian",
    "cs":"Czech","sk":"Slovak","ro":"Romanian","bg":"Bulgarian","hr":"Croatian",
    "ca":"Catalan","el":"Greek","hu":"Hungarian","lt":"Lithuanian","lv":"Latvian",
    "et":"Estonian","sl":"Slovenian","sq":"Albanian","sr":"Serbian","az":"Azerbaijani",
    "ka":"Georgian","hy":"Armenian","is":"Icelandic","ga":"Irish",
}
LANG_CODE_MAP = {v.lower(): k for k, v in LANG_NAMES.items()}
LANG_CODE_MAP.update({k: k for k in LANG_NAMES})

# Instance health cache: {url: {"ok": bool, "checked": isoformat}}
_instance_cache: dict[str, dict] = {}
CACHE_TTL_SECS = 300  # 5 minutes


def _lang_code(name: str) -> str:
    n = name.lower().strip()
    return LANG_CODE_MAP.get(n, n[:2].lower())


def _load_cfg() -> dict:
    if TRANS_CFG.exists():
        try: return json.loads(TRANS_CFG.read_text())
        except Exception: pass
    return {}


def _save_cfg(cfg: dict):
    TRANS_CFG.parent.mkdir(parents=True, exist_ok=True)
    TRANS_CFG.write_text(json.dumps(cfg, indent=2))


def _load_hist() -> list[dict]:
    if TRANS_HIST.exists():
        try: return json.loads(TRANS_HIST.read_text())
        except Exception: pass
    return []


def _save_hist(items: list[dict]):
    TRANS_HIST.write_text(json.dumps(items[-50:], indent=2))


def _save_translation(user_id: int, src_text: str, translated: str, src_lang: str, dst_lang: str, via: str):
    hist = _load_hist()
    hist.append({
        "ts":       datetime.now().isoformat(timespec="minutes"),
        "user_id":  user_id,
        "from":     src_lang,
        "to":       dst_lang,
        "original": src_text[:200],
        "result":   translated[:200],
        "via":      via,
    })
    _save_hist(hist)


async def _check_instance(instance: str) -> bool:
    """Check if a LibreTranslate instance is alive (cached)."""
    import time
    cached = _instance_cache.get(instance)
    if cached:
        age = time.time() - cached.get("ts", 0)
        if age < CACHE_TTL_SECS:
            return cached["ok"]
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            r = await client.get(f"{instance}/languages")
            ok = r.status_code == 200
    except Exception:
        ok = False
    _instance_cache[instance] = {"ok": ok, "ts": __import__("time").time()}
    return ok


async def _libretranslate(text: str, target: str, source: str = "auto") -> tuple[str | None, str, str]:
    """Try LibreTranslate. Returns (result, detected_lang, instance_used)."""
    cfg       = _load_cfg()
    instances = []
    if cfg.get("instance"):
        instances.append(cfg["instance"])
    instances += PUBLIC_INSTANCES

    for instance in instances:
        alive = await _check_instance(instance)
        if not alive:
            continue
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                r = await client.post(
                    f"{instance}/translate",
                    json={"q": text, "source": source, "target": target, "format": "text"},
                    headers={"Content-Type": "application/json"},
                )
                if r.status_code == 200:
                    data     = r.json()
                    result   = data.get("translatedText")
                    detected = data.get("detectedLanguage", {}).get("language", source) if source == "auto" else source
                    if result:
                        return result, detected, instance
        except Exception as e:
            logger.debug(f"LibreTranslate {instance}: {e}")
            _instance_cache[instance] = {"ok": False, "ts": __import__("time").time()}
    return None, source, ""


async def _deepl_free(text: str, target: str) -> str | None:
    """
    DeepL free API — no API key required for the public endpoint.
    Limited to 500k chars/month on free tier.
    Uses the unofficial free endpoint.
    """
    # DeepL language codes differ slightly
    deepl_target_map = {"zh": "ZH", "pt": "PT-BR"}
    dl_target = deepl_target_map.get(target, target.upper())
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.post(
                "https://api-free.deepl.com/v2/translate",
                data={"text": text, "target_lang": dl_target},
                headers={"Authorization": "DeepL-Auth-Key free"},
            )
            if r.status_code == 200:
                translations = r.json().get("translations", [])
                if translations:
                    return translations[0].get("text")
    except Exception as e:
        logger.debug(f"DeepL free failed: {e}")
    # Try alternate unofficial endpoint
    try:
        import random
        id_val = random.randint(1000000, 9999999)
        async with httpx.AsyncClient(timeout=15) as client:
            r = await client.post(
                "https://www2.deepl.com/jsonrpc",
                json={
                    "jsonrpc": "2.0", "method": "LMT_handle_texts", "id": id_val,
                    "params": {
                        "texts": [{"text": text}],
                        "lang": {"target_lang": dl_target, "source_lang_user_selected": "auto"},
                    },
                },
                headers={"Content-Type": "application/json"},
            )
            if r.status_code == 200:
                result = r.json()
                translations = result.get("result", {}).get("translations", [])
                if translations and translations[0].get("beams"):
                    return translations[0]["beams"][0].get("sentences", [{}])[0].get("text")
    except Exception as e:
        logger.debug(f"DeepL fallback failed: {e}")
    return None


async def _ai_translate(text: str, target_lang: str, ai_instance) -> str | None:
    """Final fallback: use Salim AI for translation."""
    if not ai_instance or not ai_instance.is_configured():
        return None
    try:
        target_name = LANG_NAMES.get(target_lang, target_lang)
        result, _ = await ai_instance._call_with_fallback(
            [{"role": "user", "content":
              f"Translate the following to {target_name}. Reply ONLY with the translation:\n\n{text}"}],
            system="You are a professional translator. Translate accurately and naturally.",
            max_tokens=1000, temperature=0.1,
        )
        return result.strip()
    except Exception:
        return None


class TranslateHandlers:

    @require_auth
    async def cmd_translate(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /translate Hello world to Arabic
        /translate Hello world              — auto to your default lang
        /tl ar Hello world                  — shorthand
        /translate setlang Arabic           — save default
        /translate lang                     — show default
        """
        msg     = update.effective_message
        user_id = update.effective_user.id
        args    = ctx.args or []

        if not args:
            await msg.reply_text(
                "🌍 <b>Translation Usage:</b>\n\n"
                "<code>/translate Hello to Arabic</code>\n"
                "<code>/tl ar Hello world</code>\n"
                "<code>/translate setlang Arabic</code>\n"
                "<code>/transhistory</code>",
                parse_mode="HTML"
            )
            return

        # setlang
        if args[0].lower() == "setlang":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/translate setlang Arabic</code>", parse_mode="HTML")
                return
            lang_name = " ".join(args[1:])
            code = _lang_code(lang_name)
            if code not in LANG_NAMES:
                await msg.reply_text(f"❌ Unknown language: {lang_name}\nUse names like: Arabic, French, German, Japanese…")
                return
            cfg = _load_cfg()
            cfg.setdefault("user_langs", {})[str(user_id)] = code
            _save_cfg(cfg)
            await msg.reply_text(f"✅ Default language set to <b>{LANG_NAMES[code]}</b>", parse_mode="HTML")
            return

        # lang
        if args[0].lower() == "lang":
            cfg  = _load_cfg()
            code = cfg.get("user_langs", {}).get(str(user_id), "en")
            await msg.reply_text(f"🌍 Your default language: <b>{LANG_NAMES.get(code, code)}</b>", parse_mode="HTML")
            return

        # Parse: text [to <lang>]
        text    = " ".join(args)
        target  = "en"
        detected_display = ""

        # "to <lang>" at end
        import re
        to_m = re.search(r"\bto\s+([a-zA-Z\s]{2,30})$", text, re.I)
        if to_m:
            lang_name = to_m.group(1).strip()
            code = _lang_code(lang_name)
            if code in LANG_NAMES:
                target = code
                text   = text[:to_m.start()].strip()

        if target == "en":
            # Use user's saved default
            cfg    = _load_cfg()
            target = cfg.get("user_langs", {}).get(str(user_id), "en")

        if not text:
            await msg.reply_text("❌ No text to translate.")
            return

        await msg.reply_text("🌍 Translating…")

        target_name = LANG_NAMES.get(target, target)
        result = None
        via    = "?"

        # Try LibreTranslate
        result, detected, via_instance = await _libretranslate(text, target)
        if result:
            via = "LibreTranslate"
            if detected and detected != "auto":
                detected_name = LANG_NAMES.get(detected, detected)
                detected_display = f"<i>Detected: {detected_name}</i>\n"

        # Fallback: DeepL
        if not result:
            result = await _deepl_free(text, target)
            if result:
                via = "DeepL"

        # Final fallback: AI
        if not result:
            ai = self._ai if hasattr(self, "_ai") else None
            result = await _ai_translate(text, target, ai)
            if result:
                via = "AI"

        if not result:
            await msg.reply_text("❌ All translation services unavailable. Try again later.")
            return

        _save_translation(user_id, text, result, "auto", target, via)

        await msg.reply_text(
            f"🌍 <b>→ {target_name}</b>  <i>(via {via})</i>\n"
            f"{detected_display}\n"
            f"{result}",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_tl(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        Shorthand: /tl <lang> <text>  or  /tl <text> (uses default lang)
        """
        msg     = update.effective_message
        user_id = update.effective_user.id
        args    = ctx.args or []

        if not args:
            await msg.reply_text("Usage: <code>/tl ar Hello world</code>  or  <code>/tl Hello world</code>", parse_mode="HTML")
            return

        # Detect if first arg is a language code/name
        first = args[0]
        code  = _lang_code(first)
        cfg   = _load_cfg()
        default_lang = cfg.get("user_langs", {}).get(str(user_id), "en")

        if code in LANG_NAMES and len(args) > 1:
            target = code
            text   = " ".join(args[1:])
        else:
            target = default_lang
            text   = " ".join(args)

        if not text:
            await msg.reply_text("❌ No text to translate.")
            return

        await msg.reply_text("🌍 Translating…")
        target_name = LANG_NAMES.get(target, target)
        result = None; via = "?"

        result, detected, _ = await _libretranslate(text, target)
        if result: via = "LibreTranslate"
        if not result:
            result = await _deepl_free(text, target)
            if result: via = "DeepL"
        if not result:
            ai = self._ai if hasattr(self, "_ai") else None
            result = await _ai_translate(text, target, ai)
            if result: via = "AI"

        if not result:
            await msg.reply_text("❌ Translation failed. All services unavailable.")
            return

        _save_translation(user_id, text, result, "auto", target, via)

        detected_str = ""
        if detected and detected not in ("auto", target):
            detected_str = f"<i>Detected: {LANG_NAMES.get(detected, detected)}</i>\n"

        await msg.reply_text(
            f"🌍 <b>→ {target_name}</b>  <i>(via {via})</i>\n"
            f"{detected_str}\n{result}",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_transhistory(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/transhistory — view recent translations."""
        user_id = update.effective_user.id
        hist    = [h for h in _load_hist() if h.get("user_id") == user_id]
        if not hist:
            await update.effective_message.reply_text("📭 No translation history yet.")
            return
        lines = [f"🌍 <b>Translation History ({len(hist)})</b>\n"]
        for h in hist[-10:]:
            frm = LANG_NAMES.get(h.get("from", "auto"), h.get("from", "auto"))
            to  = LANG_NAMES.get(h.get("to", ""), h.get("to", ""))
            lines.append(
                f"<i>{h['ts']}</i>  {frm} → {to}\n"
                f"<code>{h['original'][:60]}</code>\n"
                f"<i>{h['result'][:60]}</i>"
            )
        await update.effective_message.reply_text("\n\n".join(lines), parse_mode="HTML")
