"""
Salim Persistent Memory v2 — Advanced User Profile & Habit Learning

Improvements over v1:
  - Confidence-scored facts (wrong guesses can't overwrite confident ones)
  - Auto AI-learn after EVERY exchange (not just manual /memory learn)
  - Memory decay: stale low-confidence facts fade automatically
  - Memory search: /memory search <keyword>
  - Short-term vs long-term separation via confidence
  - Usage analytics: /memory stats
  - Timezone-aware timestamps

Auto-installed deps: none (stdlib + existing pytz)

Commands:
  /memory                   — show profile
  /memory set <k> <v>       — set a preference (confidence=100%)
  /memory forget <key>      — delete a specific fact
  /memory clear             — wipe entire profile
  /memory learn             — AI extract from recent history
  /memory search <word>     — find facts by keyword
  /memory stats             — usage analytics
"""
from __future__ import annotations

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.memory")

MEMORY_DIR = Path.home() / ".salim" / "memory"

DECAY_DAYS       = 30
MIN_CONFIDENCE   = 0.4
MANUAL_CONF      = 1.0
AI_CONF          = 0.75
REGEX_CONF       = 0.55
DEFAULT_CONF     = 0.5

AUTO_KEYS = {
    "name": "User preferred name", "timezone": "Timezone",
    "language": "Preferred language", "wake_time": "Wake time",
    "sleep_time": "Sleep time", "work_start": "Work start",
    "work_end": "Work end", "working_days": "Working days",
    "role": "Job role", "projects": "Active projects",
    "tools": "Frequently used tools", "download_dir": "Download directory",
    "desktop_dir": "Desktop path", "briefing_time": "Daily briefing time",
    "briefing_enabled": "Briefing enabled", "style": "Response style",
    "interests": "Interests", "last_seen": "Last seen",
}


def _memory_file(user_id: int) -> Path:
    MEMORY_DIR.mkdir(parents=True, mode=0o700, exist_ok=True)
    return MEMORY_DIR / f"{user_id}.json"


def load_memory(user_id: int) -> dict:
    path = _memory_file(user_id)
    if not path.exists():
        return {"facts": {}, "meta": {}}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if "facts" not in data:
            # Migrate v1 flat format
            facts = {}
            for k, v in data.items():
                if k not in ("last_updated", "command_counts", "inferred_habits"):
                    facts[k] = {"value": v, "confidence": DEFAULT_CONF,
                                "source": "migrated", "updated_at": datetime.now().isoformat()}
            return {"facts": facts, "meta": {"migrated": True}}
        return data
    except Exception:
        return {"facts": {}, "meta": {}}


def save_memory(user_id: int, data: dict):
    path = _memory_file(user_id)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    path.chmod(0o600)


def set_fact(user_id: int, key: str, value: Any,
             confidence: float = MANUAL_CONF, source: str = "manual") -> bool:
    """Set a fact. Higher confidence wins; manual always overwrites."""
    data = load_memory(user_id)
    existing_conf = data["facts"].get(key, {}).get("confidence", 0.0)
    if confidence >= existing_conf or source == "manual":
        data["facts"][key] = {
            "value": value, "confidence": confidence,
            "source": source, "updated_at": datetime.now().isoformat(),
        }
        data.setdefault("meta", {})["last_updated"] = datetime.now().isoformat()
        save_memory(user_id, data)
        return True
    return False


def get_fact(user_id: int, key: str, default: Any = None) -> Any:
    data = load_memory(user_id)
    fact = data.get("facts", {}).get(key)
    return fact["value"] if fact else default


def delete_fact(user_id: int, key: str):
    data = load_memory(user_id)
    data["facts"].pop(key, None)
    save_memory(user_id, data)


def clear_memory(user_id: int):
    path = _memory_file(user_id)
    if path.exists():
        path.unlink()


def update_last_seen(user_id: int):
    set_fact(user_id, "last_seen", datetime.now().isoformat(),
             confidence=1.0, source="system")


# Keep backward compat aliases used elsewhere in bot
def load_memory_flat(user_id: int) -> dict:
    """Return flat {key: value} dict for backward compat."""
    data = load_memory(user_id)
    return {k: v["value"] for k, v in data.get("facts", {}).items()}

# Legacy aliases
def set_memory(user_id: int, key: str, value: Any):
    set_fact(user_id, key, value, confidence=MANUAL_CONF, source="manual")

def get_memory(user_id: int, key: str, default: Any = None) -> Any:
    return get_fact(user_id, key, default)

def delete_memory_key(user_id: int, key: str):
    delete_fact(user_id, key)


def decay_memory(user_id: int):
    """Remove stale low-confidence facts. Called lazily on /memory view."""
    data = load_memory(user_id)
    now = datetime.now()
    to_delete = []
    for key, fact in data.get("facts", {}).items():
        if key in ("last_seen", "name"):
            continue
        conf = fact.get("confidence", DEFAULT_CONF)
        if conf >= MIN_CONFIDENCE:
            continue
        try:
            updated = datetime.fromisoformat(fact.get("updated_at", now.isoformat()))
            if (now - updated).days > DECAY_DAYS:
                to_delete.append(key)
        except Exception:
            pass
    for key in to_delete:
        data["facts"].pop(key, None)
    if to_delete:
        save_memory(user_id, data)
        logger.debug(f"Decayed {len(to_delete)} facts for user {user_id}")


def build_memory_context(user_id: int) -> str:
    data = load_memory(user_id)
    facts = data.get("facts", {})
    if not facts:
        return ""
    MIN_CTX_CONF = 0.5
    lines = ["[USER MEMORY — what you know about this user:]"]
    priority = [
        "name", "timezone", "role", "language", "style",
        "work_start", "work_end", "working_days", "wake_time", "sleep_time",
        "briefing_time", "briefing_enabled", "projects", "tools", "interests",
        "download_dir", "desktop_dir",
    ]
    shown = set()
    for key in priority:
        fact = facts.get(key)
        if fact and fact.get("value") and fact.get("confidence", 0) >= MIN_CTX_CONF:
            lines.append(f"  {key}: {fact['value']}")
            shown.add(key)
    skip = {"last_seen", "command_counts", "inferred_habits"}
    for key, fact in facts.items():
        if key not in shown and key not in skip:
            if fact.get("confidence", 0) >= MIN_CTX_CONF:
                v = fact.get("value")
                if isinstance(v, (str, int, float, bool)):
                    lines.append(f"  {key}: {v}")
    lines.append("Use this information to personalize responses.")
    return "\n".join(lines)


def learn_from_text(user_id: int, text: str):
    """Regex-based passive learning. Called on every user message."""
    text_lower = text.lower().strip()

    # Name
    for pat in [r"(?:my name is|i'm|i am|call me)\s+([A-Z][a-z]{1,20})",
                r"^([A-Z][a-z]{1,20})\s+here"]:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            set_fact(user_id, "name", m.group(1).strip(), REGEX_CONF, "regex")
            break

    # Timezone
    for pat in [r"(?:i'm in|i live in|my timezone is)\s+(UTC[+-]\d{1,2}|\w+/\w+)",
                r"(UTC[+-]\d{1,2})",
                r"\b(Asia/\w+|America/\w+|Europe/\w+|Africa/\w+|Pacific/\w+)\b"]:
        m = re.search(pat, text, re.IGNORECASE)
        if m:
            set_fact(user_id, "timezone", m.group(1).strip(), REGEX_CONF, "regex")
            break

    # Role
    role_kws = ["developer", "engineer", "designer", "manager", "student", "doctor",
                "teacher", "analyst", "scientist", "freelancer", "cto", "ceo", "founder"]
    for pat in [r"i(?:'m| am) (?:a |an )?(.{3,30}?)(?:\.|,|$)",
                r"(?:my job|my role|i work as) (?:is |as )?(.{3,30}?)(?:\.|,|$)"]:
        m = re.search(pat, text_lower)
        if m:
            cand = m.group(1).strip()
            if any(kw in cand for kw in role_kws):
                set_fact(user_id, "role", cand, REGEX_CONF, "regex")
                break

    # Language
    lm = re.search(r"(?:respond|reply|answer|speak)\s+in\s+([a-zA-Z]{3,20})", text_lower)
    if lm:
        set_fact(user_id, "language", lm.group(1).strip(), REGEX_CONF + 0.1, "regex")

    # Work hours
    wm = re.search(r"(?:i work|working hours?).{0,20}?(\d{1,2}(?::\d{2})?(?:\s*[ap]m)?)", text_lower)
    if wm:
        set_fact(user_id, "work_start", wm.group(1).strip(), REGEX_CONF, "regex")

    # Command frequency in meta
    cm = re.match(r"^/(\w+)", text)
    if cm:
        data = load_memory(user_id)
        meta = data.setdefault("meta", {})
        counts = meta.get("command_counts", {})
        counts[cm.group(1)] = counts.get(cm.group(1), 0) + 1
        meta["command_counts"] = counts
        save_memory(user_id, data)


async def learn_from_ai(user_id: int, user_message: str, ai_response: str, ai_instance) -> None:
    """AI-powered extraction. Higher confidence than regex. Called after every exchange."""
    data = load_memory(user_id)
    existing = {k: v["value"] for k, v in data.get("facts", {}).items()
                if k != "last_seen"}
    prompt = f"""You are a memory extractor for a personal AI assistant.
Extract NEW facts about the user from this exchange. Return JSON with ONLY new/corrected keys.
Return {{}} if nothing new.

ALREADY KNOWN: {json.dumps(existing, ensure_ascii=False)}
USER SAID: {user_message[:600]}
ASSISTANT REPLIED: {ai_response[:400]}

Keys to extract: name, timezone, role, language, projects, tools, interests,
work_start, work_end, wake_time, sleep_time, style, download_dir, briefing_time, briefing_enabled.

Return ONLY valid JSON. No explanation."""

    try:
        raw, _ = await ai_instance._call_with_fallback(
            [{"role": "user", "content": prompt}],
            system="You are a JSON-only extractor. Output only valid JSON, nothing else.",
            max_tokens=256, temperature=0.1,
        )
        raw = re.sub(r"```(?:json)?|```", "", raw).strip()
        new_facts = json.loads(raw)
        if isinstance(new_facts, dict):
            for k, v in new_facts.items():
                if v and k != "last_seen":
                    set_fact(user_id, k, v, AI_CONF, "ai")
            if new_facts:
                logger.info(f"Memory AI-updated for {user_id}: {list(new_facts.keys())}")
    except Exception as e:
        logger.debug(f"Memory AI extraction skipped: {e}")


def search_memory(user_id: int, keyword: str) -> list[tuple[str, Any, float]]:
    """Search facts by keyword in key or value."""
    data = load_memory(user_id)
    kw = keyword.lower()
    results = []
    for key, fact in data.get("facts", {}).items():
        v = str(fact.get("value", "")).lower()
        if kw in key.lower() or kw in v:
            results.append((key, fact.get("value"), fact.get("confidence", 0)))
    return sorted(results, key=lambda x: -x[2])


class MemoryHandlers:
    """Mixin for SalimBot — /memory commands."""

    @require_auth
    async def cmd_memory(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        import html as _html
        def esc(v): return _html.escape(str(v), quote=False)

        msg     = update.effective_message
        user_id = update.effective_user.id
        args    = ctx.args or []
        sub     = args[0].lower() if args else "show"

        if sub == "clear":
            clear_memory(user_id)
            await msg.reply_text(
                "🧹 <b>Memory cleared.</b>\n<i>Salim will learn from scratch.</i>",
                parse_mode="HTML")
            return

        if sub == "forget" and len(args) >= 2:
            delete_fact(user_id, args[1].lower())
            await msg.reply_text(f"🗑️ Forgot: <code>{esc(args[1])}</code>", parse_mode="HTML")
            return

        if sub == "set" and len(args) >= 3:
            key = args[1].lower()
            val = " ".join(args[2:])
            set_fact(user_id, key, val, MANUAL_CONF, "manual")
            await msg.reply_text(
                f"✅ <code>{esc(key)}</code> = <code>{esc(val)}</code>\n<i>Confidence: 100%</i>",
                parse_mode="HTML")
            return

        if sub == "search" and len(args) >= 2:
            kw = " ".join(args[1:])
            results = search_memory(user_id, kw)
            if not results:
                await msg.reply_text(f"🔍 No match for: <code>{esc(kw)}</code>", parse_mode="HTML")
                return
            lines = [f"🔍 <b>Search: '{esc(kw)}'</b>\n"]
            for key, val, conf in results[:10]:
                ci = "🟢" if conf >= 0.75 else "🟡" if conf >= 0.5 else "🔴"
                lines.append(f"{ci} <b>{esc(key)}</b>: <code>{esc(str(val))}</code> <i>{int(conf*100)}%</i>")
            await msg.reply_text("\n".join(lines), parse_mode="HTML")
            return

        if sub == "stats":
            data   = load_memory(user_id)
            facts  = data.get("facts", {})
            meta   = data.get("meta", {})
            counts = meta.get("command_counts", {})
            high = sum(1 for f in facts.values() if f.get("confidence", 0) >= 0.75)
            med  = sum(1 for f in facts.values() if 0.5 <= f.get("confidence", 0) < 0.75)
            low  = sum(1 for f in facts.values() if f.get("confidence", 0) < 0.5)
            sources: dict = {}
            for f in facts.values():
                s = f.get("source", "?")
                sources[s] = sources.get(s, 0) + 1
            lines = [
                "📊 <b>Memory Analytics</b>\n",
                f"📌 Total facts: <b>{len(facts)}</b>",
                f"  🟢 High (≥75%): {high}  🟡 Med: {med}  🔴 Low: {low}",
                "\n<b>Sources:</b>",
            ]
            src_icons = {"manual": "✍️", "ai": "🤖", "regex": "🔤", "system": "⚙️", "migrated": "📦"}
            for s, n in sorted(sources.items(), key=lambda x: -x[1]):
                lines.append(f"  {src_icons.get(s,'📌')} {s}: {n}")
            if counts:
                top = sorted(counts.items(), key=lambda x: -x[1])[:8]
                lines.append("\n<b>Top commands:</b>")
                for cmd, n in top:
                    lines.append(f"  /{cmd}: {'▓'*min(n,15)} ({n}x)")
            await msg.reply_text("\n".join(lines), parse_mode="HTML")
            return

        if sub == "learn":
            thinking = await msg.reply_text(
                "🧠 <i>Re-learning from recent history…</i>", parse_mode="HTML")
            try:
                from salim.handlers.history import load_history
                history = load_history(user_id, 30)
                if not history:
                    await thinking.edit_text("📭 No history yet.", parse_mode="HTML")
                    return
                user_msgs = " ".join(h["content"] for h in history if h.get("role") == "user")[-5:]
                asst_msgs = " ".join(h["content"] for h in history if h.get("role") == "assistant")[-5:]
                ai = self._ai if hasattr(self, "_ai") else None
                if ai:
                    await learn_from_ai(user_id, user_msgs, asst_msgs, ai)
                count = len(load_memory(user_id).get("facts", {}))
                await thinking.edit_text(
                    f"🧠 <b>Done!</b> {count} facts in memory.", parse_mode="HTML")
            except Exception as e:
                await thinking.edit_text(f"⚠️ Failed: {esc(str(e))}", parse_mode="HTML")
            return

        # ── Show ───────────────────────────────────────────────────────────────
        decay_memory(user_id)
        data  = load_memory(user_id)
        facts = data.get("facts", {})

        if not facts:
            await msg.reply_text(
                "🧠 <b>No memory yet.</b>\n\n"
                "<i>Salim learns automatically as you chat.</i>\n\n"
                "<code>/memory set name Ahmed</code>\n"
                "<code>/memory set timezone UTC+5</code>\n"
                "<code>/memory search projects</code>\n"
                "<code>/memory stats</code>",
                parse_mode="HTML")
            return

        ICON_MAP = {
            "name":"👤","timezone":"🌍","role":"💼","language":"🗣️",
            "wake_time":"⏰","sleep_time":"😴","work_start":"🏢","work_end":"🏠",
            "projects":"📁","tools":"🔧","interests":"⭐","style":"✏️",
            "briefing_time":"📰","briefing_enabled":"🔔",
        }
        skip = {"last_seen", "command_counts", "inferred_habits"}
        lines = ["🧠 <b>Your Memory Profile</b>\n"]
        for key, fact in sorted(facts.items(), key=lambda x: -x[1].get("confidence", 0)):
            if key in skip:
                continue
            v    = fact.get("value")
            conf = fact.get("confidence", 0)
            if not isinstance(v, (str, int, float, bool)):
                continue
            icon = ICON_MAP.get(key, "📌")
            ci   = "🟢" if conf >= 0.75 else "🟡" if conf >= 0.5 else "🔴"
            lines.append(f"{icon} <b>{esc(key)}</b>: <code>{esc(str(v))}</code> {ci}<i>{int(conf*100)}%</i>")

        meta   = data.get("meta", {})
        counts = meta.get("command_counts", {})
        if counts:
            top = sorted(counts.items(), key=lambda x: -x[1])[:5]
            lines.append("\n📊 <b>Top:</b> " + ", ".join(f"/{c}({n})" for c, n in top))
        last = meta.get("last_updated", "")
        if last:
            lines.append(f"\n<i>Updated: {esc(last[:16])}</i>")
        lines.append("\n<i>/memory set · forget · search · stats · clear</i>")
        await msg.reply_text("\n".join(lines), parse_mode="HTML")
