"""
Salim File Watcher Handler v2 — Advanced File System Monitoring

Improvements over v1:
  - Event debouncing: batches rapid changes (editor autosave floods) into summaries
  - File type filters: /watch ~/code --include *.py --exclude *.pyc
  - Change log: /watchlog <id> — review what changed while you were away
  - Watcher persistence: saved to JSON, restored on restart
  - Trigger actions: /watch ~/code --on-change "git status" (run cmd on change)
  - Smart summary: groups rapid changes by directory

Auto-installed: watchdog>=4.0 (already in deps)

Commands:
  /watch <path>                          — watch a folder
  /watch <path> --include *.py           — filter to specific file types
  /watch <path> --exclude *.pyc,*.log    — exclude patterns
  /watch <path> --on-change <cmd>        — run command on change
  /watchlist                             — list active watchers
  /watchlog <id>                         — show recent change log
  /watchstop <id>                        — stop a watcher
  /watchstopall                          — stop all watchers
"""
from __future__ import annotations

import asyncio
import fnmatch
import json
import logging
import threading
import time
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Callable

from telegram import Update
from telegram.ext import ContextTypes

from salim.auto_install import ensure_one

logger = logging.getLogger(__name__)

WATCHERS_FILE   = Path.home() / ".salim" / "watchers.json"
WATCHER_LOGS    = Path.home() / ".salim" / "watcher_logs"
DEBOUNCE_SECS   = 3       # Wait this long after last event before firing alert
MAX_LOG_ENTRIES = 200     # Per watcher

_watchers: dict[str, dict] = {}
_watcher_counter = 0
_bot_ref         = None


def _ensure_watchdog():
    return ensure_one("watchdog", "watchdog>=4.0")


# ── Persistence ───────────────────────────────────────────────────────────────

def _save_watcher_state():
    WATCHERS_FILE.parent.mkdir(parents=True, exist_ok=True)
    state = {
        wid: {
            "path": w["path"],
            "chat_id": w["chat_id"],
            "include": w.get("include", []),
            "exclude": w.get("exclude", []),
            "on_change": w.get("on_change"),
            "created": w.get("created"),
        }
        for wid, w in _watchers.items()
    }
    WATCHERS_FILE.write_text(json.dumps(state, indent=2))


def _log_event(wid: str, entry: dict):
    WATCHER_LOGS.mkdir(parents=True, exist_ok=True)
    log_file = WATCHER_LOGS / f"{wid}.json"
    logs = []
    if log_file.exists():
        try: logs = json.loads(log_file.read_text())
        except Exception: pass
    logs.append(entry)
    log_file.write_text(json.dumps(logs[-MAX_LOG_ENTRIES:], indent=2))


def _get_log(wid: str) -> list[dict]:
    log_file = WATCHER_LOGS / f"{wid}.json"
    if log_file.exists():
        try: return json.loads(log_file.read_text())
        except Exception: pass
    return []


# ── File filtering ────────────────────────────────────────────────────────────

def _matches(path: str, include: list[str], exclude: list[str]) -> bool:
    name = Path(path).name
    if include and not any(fnmatch.fnmatch(name, pat) for pat in include):
        return False
    if exclude and any(fnmatch.fnmatch(name, pat) for pat in exclude):
        return False
    return True


# ── Watcher thread ────────────────────────────────────────────────────────────

def _watch_thread(
    wid: str, path: Path, stop: threading.Event,
    chat_id: int, main_loop: asyncio.AbstractEventLoop,
    include: list[str], exclude: list[str], on_change: str | None,
):
    from watchdog.observers import Observer
    from watchdog.events import FileSystemEventHandler

    # Debounce buffer: path → list of events
    pending: dict = defaultdict(list)
    pending_lock  = threading.Lock()

    def _flush():
        """Called after debounce delay to send batched alerts."""
        while not stop.is_set():
            time.sleep(DEBOUNCE_SECS)
            with pending_lock:
                if not pending:
                    continue
                # Build summary
                events = dict(pending)
                pending.clear()

            # Group by directory
            by_dir: dict[str, list] = defaultdict(list)
            for p, evs in events.items():
                parent = str(Path(p).parent)
                by_dir[parent].extend(evs)

            lines = [f"👁 <b>Watcher #{wid}</b> — {len(events)} change(s)\n"]
            for d, evs in list(by_dir.items())[:5]:
                lines.append(f"📂 <code>{d}</code>")
                for ev in evs[:5]:
                    lines.append(f"  {ev['icon']} {ev['name']}")
                if len(evs) > 5:
                    lines.append(f"  … +{len(evs)-5} more")

            text = "\n".join(lines)

            # Log it
            _log_event(wid, {
                "ts":     datetime.now().isoformat(timespec="seconds"),
                "events": {p: [e["type"] for e in evs] for p, evs in events.items()},
            })

            # Run on_change command
            if on_change:
                try:
                    import subprocess
                    r = subprocess.run(on_change, shell=True, capture_output=True, text=True, timeout=30)
                    out = (r.stdout or r.stderr or "").strip()[:500]
                    if out:
                        text += f"\n\n💻 <b>on-change output:</b>\n<pre>{out}</pre>"
                except Exception as e:
                    text += f"\n\n⚠️ on-change failed: {e}"

            async def _send(t=text):
                if _bot_ref:
                    try:
                        await _bot_ref.send_message(chat_id=chat_id, text=t, parse_mode="HTML")
                    except Exception as ex:
                        logger.warning(f"Watcher send failed: {ex}")
            asyncio.run_coroutine_threadsafe(_send(), main_loop)

    class Handler(FileSystemEventHandler):
        def _handle(self, event, icon, etype):
            if event.is_directory:
                return
            p = getattr(event, "src_path", "")
            if not _matches(p, include, exclude):
                return
            with pending_lock:
                pending[p].append({
                    "type": etype,
                    "icon": icon,
                    "name": Path(p).name,
                })

        def on_modified(self, e): self._handle(e, "📝", "modified")
        def on_created(self,  e): self._handle(e, "✨", "created")
        def on_deleted(self,  e): self._handle(e, "🗑", "deleted")
        def on_moved(self,    e): self._handle(e, "↪️", "moved")

    flush_thread = threading.Thread(target=_flush, daemon=True)
    flush_thread.start()

    observer = Observer()
    observer.schedule(Handler(), str(path), recursive=path.is_dir())
    observer.start()
    try:
        while not stop.is_set():
            time.sleep(0.5)
    finally:
        observer.stop()
        observer.join()


# ── Telegram handlers ─────────────────────────────────────────────────────────

class WatcherHandlers:

    async def init_watchers(self, bot):
        """Restore watchers from saved state on bot startup."""
        global _bot_ref
        _bot_ref = bot
        if not WATCHERS_FILE.exists():
            return
        try:
            state = json.loads(WATCHERS_FILE.read_text())
        except Exception:
            return
        if not state:
            return
        if not _ensure_watchdog():
            logger.warning("watchdog unavailable, skipping watcher restore")
            return
        for wid, w in state.items():
            path = Path(w["path"])
            if not path.exists():
                continue
            self._start_watcher(
                wid, path, w["chat_id"],
                w.get("include", []), w.get("exclude", []),
                w.get("on_change"),
                asyncio.get_event_loop(),
                created=w.get("created"),
            )
        logger.info(f"Restored {len(state)} file watchers.")

    def _start_watcher(self, wid, path, chat_id, include, exclude, on_change, loop, created=None):
        stop_event = threading.Event()
        _watchers[wid] = {
            "path": str(path), "chat_id": chat_id,
            "include": include, "exclude": exclude,
            "on_change": on_change, "stop": stop_event,
            "created": created or datetime.now().isoformat(timespec="seconds"),
        }
        t = threading.Thread(
            target=_watch_thread,
            args=(wid, path, stop_event, chat_id, loop, include, exclude, on_change),
            daemon=True,
        )
        t.start()
        _watchers[wid]["thread"] = t
        _save_watcher_state()

    async def cmd_watch(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Watch a file or folder. Usage: /watch <path> [--include *.py] [--exclude *.pyc] [--on-change cmd]"""
        global _watcher_counter, _bot_ref
        _bot_ref = ctx.bot

        args_raw = ctx.args or []
        if not args_raw:
            await update.effective_message.reply_text(
                "Usage:\n"
                "<code>/watch ~/Documents</code>\n"
                "<code>/watch ~/code --include *.py</code>\n"
                "<code>/watch ~/code --exclude *.pyc,*.log</code>\n"
                "<code>/watch ~/project --on-change \"git status\"</code>",
                parse_mode="HTML"
            )
            return

        # Parse flags
        include: list[str] = []
        exclude: list[str] = []
        on_change: str | None = None
        path_parts = []
        i = 0
        while i < len(args_raw):
            a = args_raw[i]
            if a == "--include" and i + 1 < len(args_raw):
                include = [p.strip() for p in args_raw[i+1].split(",")]
                i += 2
            elif a == "--exclude" and i + 1 < len(args_raw):
                exclude = [p.strip() for p in args_raw[i+1].split(",")]
                i += 2
            elif a == "--on-change" and i + 1 < len(args_raw):
                on_change = args_raw[i+1]
                i += 2
            else:
                path_parts.append(a)
                i += 1

        path_str = " ".join(path_parts)
        path     = Path(path_str).expanduser().resolve()

        if not path.exists():
            await update.effective_message.reply_text(f"❌ Path not found: <code>{path}</code>", parse_mode="HTML")
            return

        if not _ensure_watchdog():
            await update.effective_message.reply_text("❌ watchdog library could not be installed.")
            return

        _watcher_counter += 1
        wid  = str(_watcher_counter)
        loop = asyncio.get_event_loop()
        chat_id = update.effective_chat.id

        self._start_watcher(wid, path, chat_id, include, exclude, on_change, loop)

        inc_str = f"  include: {', '.join(include)}" if include else ""
        exc_str = f"  exclude: {', '.join(exclude)}" if exclude else ""
        chg_str = f"  on-change: <code>{on_change}</code>" if on_change else ""
        await update.effective_message.reply_text(
            f"👁 <b>Watcher #{wid} started</b>\n\n"
            f"📂 <code>{path}</code>\n"
            f"{inc_str}\n{exc_str}\n{chg_str}\n\n"
            f"<i>Changes batched every {DEBOUNCE_SECS}s · /watchlog {wid} for history</i>\n"
            f"Stop: <code>/watchstop {wid}</code>",
            parse_mode="HTML"
        )

    async def cmd_watchlist(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """List active file watchers."""
        if not _watchers:
            await update.effective_message.reply_text("No active watchers. Use <code>/watch &lt;path&gt;</code>", parse_mode="HTML")
            return
        lines = [f"<b>👁 Active Watchers ({len(_watchers)})</b>\n"]
        for wid, w in _watchers.items():
            inc = f" +{','.join(w.get('include',[]))}" if w.get("include") else ""
            exc = f" -{','.join(w.get('exclude',[]))}" if w.get("exclude") else ""
            log_count = len(_get_log(wid))
            lines.append(
                f"<b>#{wid}</b> 📂 <code>{w['path']}</code>{inc}{exc}\n"
                f"  {log_count} events logged · /watchlog {wid}"
            )
        lines.append("\n<i>/watchstop &lt;id&gt; · /watchstopall</i>")
        await update.effective_message.reply_text("\n\n".join(lines), parse_mode="HTML")

    async def cmd_watchlog(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show recent change log for a watcher. /watchlog <id>"""
        args = ctx.args or []
        if not args:
            await update.effective_message.reply_text("Usage: <code>/watchlog &lt;id&gt;</code>", parse_mode="HTML")
            return
        wid  = args[0]
        logs = _get_log(wid)
        if not logs:
            await update.effective_message.reply_text(f"📭 No logs yet for watcher #{wid}.")
            return
        lines = [f"📋 <b>Watcher #{wid} Log ({len(logs)} events)</b>\n"]
        for entry in logs[-15:]:
            ts     = entry.get("ts", "?")
            events = entry.get("events", {})
            total  = sum(len(v) for v in events.values())
            dirs   = list(set(str(Path(p).parent) for p in events))
            lines.append(
                f"🕐 {ts}  ({total} changes in {len(dirs)} dir(s))\n"
                + "\n".join(f"  📂 <code>{d}</code>" for d in dirs[:3])
            )
        await update.effective_message.reply_text("\n\n".join(lines), parse_mode="HTML")

    async def cmd_watchstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Stop a file watcher. /watchstop <id>"""
        wid = " ".join(ctx.args) if ctx.args else ""
        if not wid or wid not in _watchers:
            await update.effective_message.reply_text(
                f"Usage: /watchstop <id>  Active: {list(_watchers.keys()) or 'none'}"
            )
            return
        _watchers[wid]["stop"].set()
        w = _watchers.pop(wid)
        _save_watcher_state()
        await update.effective_message.reply_text(f"✅ Stopped watcher #{wid} ({w['path']})")

    async def cmd_watchstopall(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Stop all active watchers."""
        count = len(_watchers)
        for w in _watchers.values():
            w["stop"].set()
        _watchers.clear()
        _save_watcher_state()
        await update.effective_message.reply_text(f"✅ Stopped {count} watcher(s).")
