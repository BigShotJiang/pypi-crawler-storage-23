"""
Salim AI Handler — Telegram message handler for natural language control.

Uses HTML parse mode throughout to avoid Markdown entity errors caused by
underscores in filenames, backslashes in paths, backticks in content, etc.
"""

from __future__ import annotations

import asyncio
import html
import logging
import re
import time
from pathlib import Path

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from salim.ai import SalimAI
from salim.ai_search import SearchResult, search_laptop
from salim.auth import require_auth
from salim.handlers.history import save_message, get_ai_context

logger = logging.getLogger("salim.ai_handler")

MAX_BUTTON_RESULTS = 8
HTML = "HTML"


async def _async_learn_memory(user_id: int, user_text: str, ai_response: str, ai_instance):
    """Background task: extract new facts from conversation and update memory."""
    try:
        from salim.handlers.memory import learn_from_ai
        await learn_from_ai(user_id, user_text, ai_response, ai_instance)
    except Exception:
        pass


def esc(text: str) -> str:
    """HTML-escape so any string is safe inside Telegram HTML messages."""
    return html.escape(str(text), quote=False)


# Commands that map to handler method names
HANDLER_MAP = {
    "screenshot": "cmd_screenshot",
    "ss":         "cmd_screenshot",
    "info":       "cmd_info",
    "cpu":        "cmd_cpu",
    "mem":        "cmd_mem",
    "disk":       "cmd_disk",
    "battery":    "cmd_battery",
    "network":    "cmd_network",
    "uptime":     "cmd_uptime",
    "top":        "cmd_top",
    "ps":         "cmd_ps",
    "ls":         "cmd_ls",
    "pwd":        "cmd_pwd",
    "paste":      "cmd_paste",
    "volume":     "cmd_volume",
    "brightness": "cmd_brightness",
    "lock":       "cmd_lock",
    "sleep":      "cmd_sleep",
    "screensaver":"cmd_screensaver",
    "notify":     "cmd_notify",
    "open":       "cmd_open",
    "type":       "cmd_type",
    "key":        "cmd_key",
    "mousepos":   "cmd_mousepos",
    "click":      "cmd_click",
    "scroll":     "cmd_scroll",
    "move":       "cmd_move",
    "run":        "cmd_run",
    "sh":         "cmd_run",
    "env":        "cmd_env",
    "which":      "cmd_which",
    "find":       "cmd_find",
    "grep":       "cmd_grep",
    "cat":        "cmd_cat",
    "stat":       "cmd_stat",
    "download":   "cmd_download",
    "copy":       "cmd_copy",
    "mkdir":      "cmd_mkdir",
    "zip":        "cmd_zip",
    "unzip":      "cmd_unzip",
    "write":      "cmd_write",
    "mv":         "cmd_mv",
    "cp":         "cmd_cp",
}

DESTRUCTIVE_MAP = {
    "shutdown":  "cmd_shutdown",
    "restart":   "cmd_restart",
    "sleep":     "cmd_sleep",
    "lock":      "cmd_lock",
    "hibernate": "cmd_hibernate",
    "logout":    "cmd_logout",
    "rm":        "cb_rm_confirm",
    "kill":      "cmd_kill",
}

# ── Plain-English NLP patterns → auto-route to commands ──────────────────────
# Each entry: (pattern_keywords, handler_method, extract_args_fn_or_None)
# Salim understands these WITHOUT requiring the user to type /command
NLP_PATTERNS = [
    # Weather
    (["weather", "forecast", "temperature", "rain", "sunny", "climate"],
     "cmd_weather", lambda t: [re.sub(r".*(?:weather|forecast|temperature).*?(?:in|for|at)\s+", "", t, flags=re.I).strip()[:50]]),
    # Screenshot
    (["screenshot", "screen shot", "capture screen", "take screenshot"],
     "cmd_screenshot", None),
    # Translate
    (["translate", "translation", "in french", "in arabic", "in spanish", "in german"],
     "cmd_translate", lambda t: [t]),
    # Remind
    (["remind me", "reminder", "set alarm", "alert me"],
     "cmd_remind", lambda t: [re.sub(r".*(?:remind me|reminder)\s*(?:to\s*)?", "", t, flags=re.I).strip()]),
    # Calendar
    (["calendar", "schedule", "meeting", "appointment", "event"],
     "cmd_cal", lambda t: [t]),
    # Notes
    (["note", "jot down", "remember this", "write down"],
     "cmd_note", lambda t: [re.sub(r".*(?:note|jot down|remember this|write down)\s*:?\s*", "", t, flags=re.I).strip()]),
    # Web search
    (["search for", "look up", "google", "find online", "search online"],
     "cmd_websearch", lambda t: [re.sub(r".*(?:search for|look up|google|find online|search online)\s*", "", t, flags=re.I).strip()]),
    # Finance
    (["price of", "stock price", "bitcoin", "crypto price", "btc price", "eth price"],
     "cmd_price", lambda t: ([re.sub(r".*(?:price of|price)\s*", "", t, flags=re.I).strip().split()[0]]
                              if re.sub(r".*(?:price of|price)\s*", "", t, flags=re.I).strip().split()
                              else ["BTC"])),
    # System info
    (["system info", "system status", "computer info", "laptop info"],
     "cmd_info", None),
    # Processes
    (["running processes", "what's running", "process list", "active apps"],
     "cmd_ps", None),
    # Disk
    (["disk space", "disk usage", "storage", "free space", "hard drive"],
     "cmd_disk", None),
    # Battery
    (["battery", "battery level", "battery status", "charging"],
     "cmd_battery", None),
    # Network
    (["network", "wifi", "ip address", "internet connection"],
     "cmd_myip", None),
    # Git
    (["git status", "git commit", "git push", "git pull", "github"],
     "cmd_git", lambda t: [re.sub(r".*git\s*", "", t, flags=re.I).strip()]),
    # Agent tasks (document creation, email)
    (["create a", "make a", "write a", "generate a", "build a", "draft a",
      "create an", "make an", "write an", "send email", "compose email",
      "spreadsheet", "create excel", "make excel", "excel sheet",
      "word doc", "powerpoint", "presentation", "create report"],
     "cmd_agent", lambda t: [t]),
    # Skills
    (["list skills", "show skills", "what skills", "installed skills"],
     "cmd_skills", None),
    # Memory
    (["my memory", "what do you know", "remember about me", "my preferences"],
     "cmd_memory", None),
    # Backup
    (["backup", "back up", "archive files"],
     "cmd_backup", lambda t: [t]),
    # Digest
    (["morning briefing", "daily digest", "today's summary", "what's happening"],
     "cmd_digest", None),
]


def _nlp_route(text: str) -> tuple[str | None, list[str]]:
    """
    Check if plain-English text matches any known NLP pattern.
    Returns (handler_name, args) or (None, []).
    """
    text_lower = text.lower()
    for keywords, handler, args_fn in NLP_PATTERNS:
        if any(kw in text_lower for kw in keywords):
            args = args_fn(text) if args_fn else []
            return handler, args
    return None, []




async def _safe_edit(msg, text: str, **kwargs):
    """Edit a message safely — falls back to plain text on parse error."""
    try:
        await msg.edit_text(text, **kwargs)
    except Exception as e:
        logger.error(f"edit_text failed ({e}), retrying plain")
        try:
            await msg.edit_text(text[:4000], parse_mode=None)
        except Exception:
            pass


async def _safe_reply(msg, text: str, **kwargs):
    """Reply safely — falls back to plain text on parse error."""
    try:
        await msg.reply_text(text, **kwargs)
    except Exception as e:
        logger.error(f"reply_text failed ({e}), retrying plain")
        try:
            await msg.reply_text(text[:4000], parse_mode=None)
        except Exception:
            pass


class AIHandler:
    """
    Mixin for SalimBot — adds full natural language understanding.
    All plain-text Telegram messages go through handle_ai_message().
    """

    @property
    def _ai(self) -> SalimAI:
        if not hasattr(self, "_ai_instance"):
            self._ai_instance = SalimAI(self.config)
        return self._ai_instance

    @require_auth
    async def handle_ai_message(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        msg = update.effective_message
        text = (msg.text or "").strip()
        if not text:
            return

        if not self._ai.is_configured():
            await _safe_reply(
                msg,
                "🤖 <b>AI mode is not configured.</b>\n\n"
                "Run <code>salim setup</code> on your laptop to add API keys.\n"
                "You can still use /commands directly — send /help.",
                parse_mode=HTML,
            )
            return

        # ── Save user message to conversation history ────────────────────────
        user_id = update.effective_user.id if update.effective_user else 0
        if user_id:
            save_message(user_id, "user", text)
            from salim.handlers.memory import learn_from_text, update_last_seen
            learn_from_text(user_id, text)
            update_last_seen(user_id)
            try:
                from salim.handlers.agent_advanced import update_rapport_after_message
                update_rapport_after_message(user_id, text)
            except Exception:
                pass
            from salim.handlers.heartbeat import get_heartbeat
            get_heartbeat().register_user(user_id, update.effective_message.chat_id)

        # ── Interactive SSH session — intercept first ───────────────────────
        if hasattr(self, "handle_ssh_interactive"):
            consumed = await self.handle_ssh_interactive(update, ctx)
            if consumed:
                return

        # ── NLP Auto-routing: plain English → command (no / needed) ─────────
        nlp_handler, nlp_args = _nlp_route(text)
        if nlp_handler and hasattr(self, nlp_handler):
            if nlp_handler == "cmd_agent":
                ctx.args = nlp_args
                await getattr(self, nlp_handler)(update, ctx)
                return

            is_destructive = nlp_handler in {v for v in DESTRUCTIVE_MAP.values()}
            if is_destructive:
                confirm_msg = await msg.reply_text(
                    f"⚠️ <b>Confirm:</b> <code>{esc(nlp_handler.replace('cmd_', ''))}</code>\n"
                    f"<i>From: \"{esc(text[:60])}\"</i>\n\n"
                    f"<b>Auto-approving in 25 seconds</b> unless cancelled.",
                    parse_mode=HTML,
                    reply_markup=InlineKeyboardMarkup([[
                        InlineKeyboardButton("✅ Do it now", callback_data=f"nlp_confirm:{nlp_handler}"),
                        InlineKeyboardButton("❌ Cancel",    callback_data="ai_cancel"),
                    ]])
                )
                async def _auto_exec():
                    await asyncio.sleep(25)
                    try:
                        await confirm_msg.edit_text(
                            f"✅ <b>Auto-approved (25s elapsed)</b>\n"
                            f"Running: <code>{esc(nlp_handler.replace('cmd_', ''))}</code>",
                            parse_mode=HTML
                        )
                        ctx.args = nlp_args
                        await getattr(self, nlp_handler)(update, ctx)
                    except Exception:
                        pass
                asyncio.create_task(_auto_exec())
                return

            notice = await msg.reply_text(
                f"⚡ <b>Auto-detected:</b> <code>{nlp_handler.replace('cmd_', '')}</code>\n"
                f"<i>From: \"{esc(text[:60])}\"</i>",
                parse_mode=HTML
            )
            ctx.args = nlp_args
            try:
                await getattr(self, nlp_handler)(update, ctx)
                await notice.edit_text(
                    f"✅ <code>{nlp_handler.replace('cmd_', '')}</code> — done",
                    parse_mode=HTML
                )
            except Exception as e:
                await notice.edit_text(
                    f"⚠️ Error: {esc(str(e)[:100])}", parse_mode=HTML
                )
            return

        # ── Document writer intercept ────────────────────────────────────────
        if hasattr(self, "handle_natural_doc"):
            from salim.handlers.document_writer import detect_doc_type
            _cat, _dt = detect_doc_type(text)
            _creation_kws = ["write", "create", "make", "generate", "draft", "prepare", "build"]
            if _dt and any(kw in text.lower() for kw in _creation_kws):
                handled = await self.handle_natural_doc(update, ctx, text)
                if handled:
                    return

        thinking = await msg.reply_text("🤖 <i>Thinking...</i>", parse_mode=HTML)

        # ── Build messages with conversation history context ─────────────────
        history_ctx = get_ai_context(user_id) if user_id else []

        try:
            intent = await self._ai.parse_intent_with_history(text, history_ctx, user_id=user_id)
        except Exception as e:
            await _safe_edit(thinking, f"⚠️ AI error: {esc(str(e))}", parse_mode=HTML)
            return

        action   = intent.get("action", "clarify")
        ai_msg   = esc(intent.get("message", ""))
        provider = intent.get("_provider", "")
        ptag     = f" <i>[{esc(provider)}]</i>" if provider else ""

        if action == "search_files":
            await _safe_edit(thinking, (ai_msg or "🔍 Searching your laptop...") + ptag, parse_mode=HTML)
            await self._do_search(update, ctx, intent)

        elif action == "execute":
            await _safe_edit(thinking, (ai_msg or "⚙️ Running...") + ptag, parse_mode=HTML)
            await self._do_execute(update, ctx, intent)

        elif action == "generate_and_write":
            await _safe_edit(thinking, (ai_msg or "✍️ Generating content...") + ptag, parse_mode=HTML)
            await self._do_generate_write(update, ctx, intent)

        elif action == "confirm":
            body = ai_msg or "⚠️ Confirm this action?"
            cmd  = intent.get("command", "").lstrip("/")
            args = intent.get("args", "")
            await _safe_edit(
                thinking,
                f"{body}{ptag}\n\n<i>This action may be irreversible.</i>",
                parse_mode=HTML,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("✅ Yes, do it", callback_data=f"ai_confirm:{cmd}:{args}"),
                    InlineKeyboardButton("❌ Cancel", callback_data="ai_cancel"),
                ]]),
            )

        elif action == "clarify":
            reply = ai_msg or "🤔 Could you be more specific? Or use a /command directly."
            await _safe_edit(thinking, reply, parse_mode=HTML)
            if user_id:
                save_message(user_id, "assistant", reply)
                # v11: background AI memory extraction
                asyncio.create_task(_async_learn_memory(user_id, text, reply, self._ai))

        else:
            reply = ai_msg or "⚠️ Something went wrong. Try a /command directly."
            await _safe_edit(thinking, reply, parse_mode=HTML)
            if user_id:
                save_message(user_id, "assistant", reply)

    async def _do_search(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, intent: dict):
        msg = update.effective_message
        keywords: list[str] = intent.get("keywords", [])
        file_types: list[str] = intent.get("file_types", [])
        # Also carry the original action hint so file-action callbacks know what to do
        action_hint: str = intent.get("action_hint", "")  # e.g. "download", "delete", "play"

        if not keywords:
            await _safe_reply(
                msg,
                "❓ I couldn't extract search keywords.\n"
                "Try: <i>find my day 3 recording</i> or <i>delete the project zip</i>",
                parse_mode=HTML,
            )
            return

        kws_display = esc(", ".join(keywords))
        status = await msg.reply_text(
            f"🔍 <i>Searching for: <b>{kws_display}</b>…</i>", parse_mode=HTML
        )

        results = await search_laptop(
            keywords=keywords,
            file_types=file_types or None,
            max_results=10,
        )

        if not results:
            await status.edit_text(
                f"🔍 No files found for: <b>{kws_display}</b>\n\n"
                f"Try different keywords, or use <code>/find &lt;pattern&gt;</code> directly.",
                parse_mode=HTML,
            )
            return

        # ── Build ONE button per result (file name only, path encoded in callback) ──
        keyboard = []
        for i, r in enumerate(results):
            # Encode: result_idx|action_hint|full_path
            # Telegram callback_data limit = 64 bytes — store index into a session cache
            slot = _store_search_results(results, action_hint)
            # Only need to call _store once; do it outside the loop below
            break

        slot = _store_search_results(results, action_hint)

        for i, r in enumerate(results):
            name_label = f"{r.icon} {r.path.name[:40]}"
            cb = f"sr_pick:{slot}:{i}"
            keyboard.append([InlineKeyboardButton(name_label, callback_data=cb)])

        keyboard.append([InlineKeyboardButton("❌ Cancel", callback_data="ai_cancel")])

        count = len(results)
        await status.edit_text(
            f"🔍 <b>Found {count} result{'s' if count != 1 else ''}</b> for <i>{kws_display}</i>\n"
            f"<i>Tap a file to see actions:</i>",
            parse_mode=HTML,
            reply_markup=InlineKeyboardMarkup(keyboard),
        )

    async def _do_execute(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, intent: dict):
        command  = intent.get("command", "").lstrip("/")
        args_str = intent.get("args", "")
        ctx.args = args_str.split() if args_str.strip() else []

        handler_name = HANDLER_MAP.get(command)
        if handler_name and hasattr(self, handler_name):
            await getattr(self, handler_name)(update, ctx)
        else:
            display = esc(f"{command} {args_str}".strip())
            await _safe_reply(
                update.effective_message,
                f"⚙️ Running: <code>{display}</code>",
                parse_mode=HTML,
            )
            ctx.args = [f"{command} {args_str}".strip()]
            if hasattr(self, "cmd_run"):
                await self.cmd_run(update, ctx)

    async def _do_generate_write(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, intent: dict):
        msg          = update.effective_message
        topic        = intent.get("topic", "")
        fmt          = intent.get("format", "txt").lower()
        filename     = intent.get("filename", f"salim_output.{fmt}")
        save_path    = Path(intent.get("save_path", "~/Desktop")).expanduser()
        instructions = intent.get("content_instructions", f"Write about: {topic}")

        if not topic:
            await _safe_reply(
                msg,
                "❓ I couldn't determine what to write about.\n"
                "Example: <i>create a txt file about the history of chess</i>",
                parse_mode=HTML,
            )
            return

        gen_msg = await msg.reply_text(
            f"✍️ <b>Writing your {esc(fmt.upper())} file about {esc(topic)}...</b>",
            parse_mode=HTML,
        )

        try:
            content, provider = await self._ai.generate_content(
                topic=topic, format=fmt, instructions=instructions, max_tokens=2048,
            )
        except Exception as e:
            await _safe_edit(gen_msg, f"⚠️ Content generation failed: {esc(str(e))}", parse_mode=HTML)
            return

        try:
            save_path.mkdir(parents=True, exist_ok=True)
            full_path = save_path / filename
            full_path.write_text(content, encoding="utf-8")
        except Exception as e:
            await _safe_edit(gen_msg, f"⚠️ Could not save file: {esc(str(e))}", parse_mode=HTML)
            return

        try:
            display_path = "~/" + str(full_path.relative_to(Path.home()))
        except ValueError:
            display_path = str(full_path)

        preview = esc(content[:300]) + ("..." if len(content) > 300 else "")

        # Store the generated file as a single-item "search result" in session cache
        # so fa_ callbacks can resolve it by slot:0 (avoids 64-byte callback_data limit)
        from salim.ai_search import SearchResult
        import os
        _fake_result = SearchResult(
            path=full_path,
            score=100,
            size_bytes=len(content.encode()),
        )
        _gen_slot = _store_search_results([_fake_result], "")

        await _safe_edit(
            gen_msg,
            f"✅ <b>Created</b> <code>{esc(filename)}</code> <i>[{esc(provider)}]</i>\n"
            f"📁 <code>{esc(display_path)}</code>\n"
            f"📝 {len(content):,} characters\n\n"
            f"<b>Preview:</b>\n<pre>{preview}</pre>",
            parse_mode=HTML,
            reply_markup=InlineKeyboardMarkup([
                [
                    InlineKeyboardButton("⬇️ Send to Telegram", callback_data=f"fa_dl:{_gen_slot}:0"),
                    InlineKeyboardButton("👁️ Read file",         callback_data=f"fa_cat:{_gen_slot}:0"),
                ],
                [InlineKeyboardButton("✅ Done", callback_data="ai_cancel")],
            ]),
        )

    async def handle_ai_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        data = query.data or ""

        # ── Cancel ─────────────────────────────────────────────────────────────
        if data == "ai_cancel":
            try:
                await query.edit_message_text("❌ Cancelled.")
            except Exception:
                pass
            return

        # ── Search result picked — show file-action buttons ───────────────────
        if data.startswith("sr_pick:"):
            await self._cb_sr_pick(query, data)
            return

        # ── Back to search results list ───────────────────────────────────────
        if data.startswith("sr_back:"):
            slot = data[8:]
            session = _get_search_session(slot)
            if not session:
                await query.edit_message_text(
                    "⚠️ Session expired. Please search again.", parse_mode=HTML
                )
                return
            results = session["results"]
            keyboard = []
            for i, r in enumerate(results):
                name_label = f"{r.icon} {r.path.name[:40]}"
                cb = f"sr_pick:{slot}:{i}"
                keyboard.append([InlineKeyboardButton(name_label, callback_data=cb)])
            keyboard.append([InlineKeyboardButton("❌ Cancel", callback_data="ai_cancel")])
            count = len(results)
            await query.edit_message_text(
                f"🔍 <b>{count} result{'s' if count != 1 else ''}</b>\n"
                f"<i>Tap a file to see actions:</i>",
                parse_mode=HTML,
                reply_markup=InlineKeyboardMarkup(keyboard),
            )
            return

        # ── File action: send image as photo ──────────────────────────────────
        if data.startswith("fa_photo:"):
            path = _resolve_fa_path(data[9:])
            if path is None:
                await query.edit_message_text("⚠️ Session expired. Please search again.", parse_mode=HTML)
                return
            try:
                import io as _io
                p = Path(path)
                buf = _io.BytesIO(p.read_bytes())
                buf.name = p.name
                await query.message.reply_photo(photo=buf, caption=f"🖼️ {esc(p.name)}")
                await query.edit_message_text(f"✅ Sent photo: <code>{esc(p.name)}</code>", parse_mode=HTML)
            except Exception as e:
                await query.edit_message_text(f"❌ Failed: <code>{esc(str(e))}</code>", parse_mode=HTML)
            return

        # ── File action: send video/audio for streaming ────────────────────────
        if data.startswith("fa_stream:"):
            path = _resolve_fa_path(data[10:])
            if path is None:
                await query.edit_message_text("⚠️ Session expired. Please search again.", parse_mode=HTML)
                return
            try:
                import io as _io
                p = Path(path)
                if p.stat().st_size > 50 * 1024 * 1024:
                    await query.edit_message_text(
                        f"⚠️ File is too large to stream via Telegram (50 MB limit).\n"
                        f"Use ⬇️ Download instead or play locally with ▶️ Open.",
                        parse_mode=HTML
                    )
                    return
                buf = _io.BytesIO(p.read_bytes())
                buf.name = p.name
                ext = p.suffix.lower()
                if ext in {".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm"}:
                    await query.message.reply_video(
                        video=buf, caption=f"🎬 {esc(p.name)}", supports_streaming=True
                    )
                else:
                    await query.message.reply_audio(audio=buf, title=p.stem, caption=f"🎵 {esc(p.name)}")
                await query.edit_message_text(f"✅ Sent: <code>{esc(p.name)}</code>", parse_mode=HTML)
            except Exception as e:
                await query.edit_message_text(f"❌ Failed: <code>{esc(str(e))}</code>", parse_mode=HTML)
            return

        # ── File action: download ─────────────────────────────────────────────
        if data.startswith("fa_dl:"):
            path = _resolve_fa_path(data[6:])
            if path is None:
                await query.edit_message_text("⚠️ Session expired. Please search again.", parse_mode=HTML)
                return
            try:
                import io as _io
                p = Path(path)
                if p.stat().st_size > 50 * 1024 * 1024:
                    await query.edit_message_text(
                        f"⚠️ <b>File too large for Telegram</b> (50 MB limit)\n"
                        f"💾 Size: {esc(str(round(p.stat().st_size/1024/1024, 1)))} MB\n"
                        f"📋 Path: <code>{esc(path)}</code>\n\n"
                        f"<i>Copy the path and access it directly on your laptop.</i>",
                        parse_mode=HTML
                    )
                    return
                buf = _io.BytesIO(p.read_bytes())
                buf.name = p.name
                await query.message.reply_document(
                    document=buf,
                    filename=p.name,
                    caption=f"📁 <b>{esc(p.name)}</b>",
                    parse_mode=HTML,
                )
                await query.edit_message_text(
                    f"✅ Sent: <code>{esc(p.name)}</code>", parse_mode=HTML
                )
            except Exception as e:
                await query.edit_message_text(
                    f"❌ Download failed: <code>{esc(str(e))}</code>", parse_mode=HTML
                )
            return

        # ── File action: delete (confirm step) ────────────────────────────────
        if data.startswith("fa_rm:"):
            ref = data[6:]
            path = _resolve_fa_path(ref)
            if path is None:
                await query.edit_message_text("⚠️ Session expired. Please search again.", parse_mode=HTML)
                return
            name = esc(Path(path).name)
            await query.edit_message_text(
                f"⚠️ <b>Delete this file?</b>\n\n"
                f"🗂 <code>{esc(path)}</code>\n\n"
                f"<i>This cannot be undone.</i>",
                parse_mode=HTML,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🗑️ Yes, delete", callback_data=f"fa_rm_confirm:{ref}"),
                    InlineKeyboardButton("❌ Cancel",       callback_data="ai_cancel"),
                ]]),
            )
            return

        # ── File action: delete confirmed ─────────────────────────────────────
        if data.startswith("fa_rm_confirm:"):
            path = _resolve_fa_path(data[14:])
            if path is None:
                await query.edit_message_text("⚠️ Session expired. Please search again.", parse_mode=HTML)
                return
            try:
                Path(path).unlink()
                await query.edit_message_text(
                    f"🗑️ <b>Deleted:</b>\n<code>{esc(path)}</code>", parse_mode=HTML
                )
            except Exception as e:
                await query.edit_message_text(
                    f"❌ Delete failed: <code>{esc(str(e))}</code>", parse_mode=HTML
                )
            return

        # ── File action: read/cat ──────────────────────────────────────────────
        if data.startswith("fa_cat:"):
            path = _resolve_fa_path(data[7:])
            if path is None:
                await query.edit_message_text("⚠️ Session expired. Please search again.", parse_mode=HTML)
                return
            try:
                p = Path(path)
                content = p.read_text(errors="replace")
                if len(content) > 3500:
                    preview = content[:3500] + "\n…(truncated)"
                else:
                    preview = content
                await query.edit_message_text(
                    f"📄 <b>{esc(p.name)}</b>\n\n<pre>{esc(preview)}</pre>",
                    parse_mode=HTML,
                )
            except Exception as e:
                await query.edit_message_text(
                    f"❌ Read failed: <code>{esc(str(e))}</code>", parse_mode=HTML
                )
            return

        # ── File action: open with default app ────────────────────────────────
        if data.startswith("fa_open:"):
            path = _resolve_fa_path(data[8:])
            if path is None:
                await query.edit_message_text("⚠️ Session expired. Please search again.", parse_mode=HTML)
                return
            try:
                import subprocess, platform as _platform
                system = _platform.system()
                if system == "Darwin":
                    subprocess.Popen(["open", path])
                elif system == "Windows":
                    subprocess.Popen(["explorer", path])
                else:
                    subprocess.Popen(["xdg-open", path])
                await query.edit_message_text(
                    f"▶️ Opened locally: <code>{esc(path)}</code>", parse_mode=HTML
                )
            except Exception as e:
                await query.edit_message_text(
                    f"❌ Could not open: <code>{esc(str(e))}</code>", parse_mode=HTML
                )
            return

        # ── File action: copy path to clipboard ───────────────────────────────
        if data.startswith("fa_copy_path:"):
            path = _resolve_fa_path(data[13:])
            if path is None:
                await query.edit_message_text("⚠️ Session expired. Please search again.", parse_mode=HTML)
                return
            # Copy path text to clipboard via pyperclip
            try:
                import pyperclip
                pyperclip.copy(path)
                await query.edit_message_text(
                    f"📋 Path copied to clipboard:\n<code>{esc(path)}</code>", parse_mode=HTML
                )
            except Exception as e:
                await query.edit_message_text(
                    f"📋 Path:\n<code>{esc(path)}</code>\n\n<i>(clipboard unavailable: {esc(str(e))})</i>",
                    parse_mode=HTML
                )
            return

        # ── Legacy ai_confirm (destructive commands from AI intent) ───────────
        if data.startswith("ai_confirm:"):
            rest     = data[11:]
            parts    = rest.split(":", 1)
            command  = parts[0]
            args_str = parts[1] if len(parts) > 1 else ""
            ctx.args = args_str.split() if args_str.strip() else []
            handler_name = DESTRUCTIVE_MAP.get(command)
            if handler_name and hasattr(self, handler_name):
                await query.edit_message_text(
                    f"⚙️ Executing <code>/{esc(command)}</code>…", parse_mode=HTML
                )
                await getattr(self, handler_name)(update, ctx)
            else:
                await query.edit_message_text(
                    f"❓ Unknown command: <code>{esc(command)}</code>", parse_mode=HTML
                )
            return

        # ── Legacy direct-action callbacks (keep for backward compat) ─────────
        if data.startswith("ai_dl:"):
            path = data[6:]
            ctx.args = [path]
            if hasattr(self, "cmd_download"):
                await self.cmd_download(update, ctx)
            return

        if data.startswith("ai_rm:"):
            path = data[6:]
            # Store in session so fa_rm_confirm can resolve it (avoids 64-byte limit)
            from salim.ai_search import SearchResult as _SR
            _r = _SR(path=Path(path), score=100)
            _slot = _store_search_results([_r], "")
            await query.edit_message_text(
                f"⚠️ <b>Delete?</b>\n<code>{esc(path)}</code>",
                parse_mode=HTML,
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("🗑️ Yes", callback_data=f"fa_rm_confirm:{_slot}:0"),
                    InlineKeyboardButton("❌ No",  callback_data="ai_cancel"),
                ]]),
            )
            return

        if data.startswith("ai_cat:"):
            path = data[7:]
            ctx.args = [path]
            if hasattr(self, "cmd_cat"):
                await self.cmd_cat(update, ctx)
            return

    async def _cb_sr_pick(self, query, data: str):
        """
        User tapped a search result button.
        Show the file details + context-aware action buttons.
        """
        _, slot, idx_str = data.split(":", 2)
        idx = int(idx_str)

        session = _get_search_session(slot)
        if not session:
            await query.edit_message_text("⚠️ Session expired. Please search again.", parse_mode=HTML)
            return

        results = session["results"]
        action_hint: str = session.get("action_hint", "")

        if idx >= len(results):
            await query.edit_message_text("⚠️ Invalid selection.", parse_mode=HTML)
            return

        r = results[idx]
        path = str(r.path)
        # Use slot:idx as callback payload — avoids Telegram's 64-byte callback_data limit
        # (base64-encoded paths easily exceed this and cause button errors)
        ref  = f"{slot}:{idx}"
        ext  = r.path.suffix.lower()

        # ── File category ─────────────────────────────────────────────────────
        is_video    = ext in {".mp4", ".mkv", ".avi", ".mov", ".wmv", ".flv", ".webm"}
        is_audio    = ext in {".mp3", ".wav", ".flac", ".aac", ".ogg", ".m4a", ".wma"}
        is_image    = ext in {".jpg", ".jpeg", ".png", ".gif", ".bmp", ".webp", ".heic"}
        is_text     = ext in {".txt", ".md", ".csv", ".log", ".json", ".py", ".js",
                               ".ts", ".html", ".css", ".xml", ".yaml", ".yml",
                               ".sh", ".bat", ".env", ".ini", ".cfg", ".toml"}
        is_document = ext in {".pdf", ".docx", ".doc", ".pptx", ".xlsx", ".xls"}
        is_archive  = ext in {".zip", ".tar", ".gz", ".rar", ".7z"}

        type_label = ("🎬 Video"    if is_video    else
                      "🎵 Audio"    if is_audio    else
                      "🖼️ Image"   if is_image    else
                      "📄 Document" if is_document  else
                      "📝 Text"     if is_text      else
                      "🗜️ Archive"  if is_archive   else "📁 File")

        # ── If action_hint is "delete" → go straight to delete confirm ────────
        if action_hint == "delete":
            await query.edit_message_text(
                f"⚠️ <b>Delete this file?</b>\n\n"
                f"{r.icon} <code>{esc(r.path.name)}</code>\n"
                f"📁 <code>{esc(r.short_path)}</code>\n"
                f"💾 {esc(r.size_human)}\n\n"
                f"<i>This cannot be undone.</i>",
                parse_mode=HTML,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("🗑️ Yes, delete", callback_data=f"fa_rm_confirm:{ref}"),
                     InlineKeyboardButton("❌ Cancel",       callback_data="ai_cancel")],
                    [InlineKeyboardButton("◀️ Back to results", callback_data=f"sr_back:{slot}")],
                ]),
            )
            return

        # ── If action_hint is "download" → trigger download immediately ────────
        if action_hint == "download":
            await query.edit_message_text(
                f"⬇️ <i>Downloading <b>{esc(r.path.name)}</b>…</i>",
                parse_mode=HTML,
            )
            # Rebuild a fake update so cmd_download works
            # We set ctx.args to the path; cmd_download reads ctx.args[0]
            from telegram.ext import CallbackContext
            import types
            # Use the underlying context object
            ctx_obj = query._bot  # just to get bot; we need a real way
            # Best approach: send via bot directly
            try:
                import io as _io
                p = r.path
                if p.stat().st_size > 50 * 1024 * 1024:
                    await query.message.reply_text(
                        f"⚠️ File is {esc(r.size_human)} — too large to send via Telegram (50 MB limit).\n"
                        f"📋 Full path: <code>{esc(path)}</code>",
                        parse_mode=HTML
                    )
                else:
                    buf = _io.BytesIO(p.read_bytes())
                    buf.name = p.name
                    await query.message.reply_document(
                        document=buf,
                        filename=p.name,
                        caption=f"📁 {esc(p.name)}\n💾 {esc(r.size_human)}"
                    )
            except Exception as e:
                await query.message.reply_text(
                    f"❌ Download failed: <code>{esc(str(e))}</code>\n"
                    f"📋 Path: <code>{esc(path)}</code>",
                    parse_mode=HTML
                )
            return

        # ── Normal: show action buttons ───────────────────────────────────────
        buttons = []

        # Row 1 — download always + open for media/docs
        row1 = [InlineKeyboardButton("⬇️ Download", callback_data=f"fa_dl:{ref}")]
        if is_video or is_audio or is_image or is_document:
            row1.append(InlineKeyboardButton("▶️ Open locally", callback_data=f"fa_open:{ref}"))
        buttons.append(row1)

        # Row 2 — type-specific actions
        row2 = []
        if is_text or is_document:
            row2.append(InlineKeyboardButton("👁️ Read", callback_data=f"fa_cat:{ref}"))
        if is_image:
            row2.append(InlineKeyboardButton("🖼️ Send as photo", callback_data=f"fa_photo:{ref}"))
        if is_video or is_audio:
            row2.append(InlineKeyboardButton("▶️ Send & stream", callback_data=f"fa_stream:{ref}"))
        if row2:
            buttons.append(row2)

        # Row 3 — copy path
        buttons.append([InlineKeyboardButton("📋 Copy path", callback_data=f"fa_copy_path:{ref}")])

        # Row 4 — destructive + navigation
        buttons.append([
            InlineKeyboardButton("🗑️ Delete", callback_data=f"fa_rm:{ref}"),
            InlineKeyboardButton("◀️ Back",   callback_data=f"sr_back:{slot}"),
        ])

        caption = (
            f"{r.icon} <b>{esc(r.path.name)}</b>\n"
            f"📁 <code>{esc(r.short_path)}</code>\n"
            f"💾 {esc(r.size_human)} · 🕐 {esc(r.modified_human)}\n"
            f"🏷 {type_label}"
        )

        await query.edit_message_text(
            caption,
            parse_mode=HTML,
            reply_markup=InlineKeyboardMarkup(buttons),
        )


# ═══════════════════════════════════════════════════════════════════════════════
#  SESSION CACHE  — stores search results between the list and the action tap
# ═══════════════════════════════════════════════════════════════════════════════

import time as _time

_search_sessions: dict[str, dict] = {}   # slot → {results, action_hint, ts}
_SESSION_TTL = 600   # 10 minutes


def _store_search_results(results, action_hint: str) -> str:
    """Store results in session cache and return the slot key."""
    import hashlib, json
    slot = hashlib.md5(f"{_time.time()}".encode()).hexdigest()[:8]
    _search_sessions[slot] = {
        "results":     results,
        "action_hint": action_hint,
        "ts":          _time.time(),
    }
    # Evict old sessions
    cutoff = _time.time() - _SESSION_TTL
    for k in list(_search_sessions):
        if _search_sessions[k]["ts"] < cutoff:
            del _search_sessions[k]
    return slot


def _get_search_session(slot: str) -> dict | None:
    s = _search_sessions.get(slot)
    if s and _time.time() - s["ts"] < _SESSION_TTL:
        return s
    return None


def _encode_path(path: str) -> str:
    """Base64-encode a file path so it fits safely in callback_data."""
    import base64
    return base64.urlsafe_b64encode(path.encode()).decode()


def _decode_path(encoded: str) -> str:
    import base64
    try:
        return base64.urlsafe_b64decode(encoded.encode()).decode()
    except Exception:
        return encoded   # fallback: might be a raw path from legacy callbacks


def _resolve_fa_path(ref: str) -> str | None:
    """
    Resolve a file-action reference to an absolute path string.

    New format (v10 fix): "slot:idx"  — looks up path from session cache.
    Legacy format: base64-encoded path — decoded directly.

    Returns the path string, or None if the session expired.
    """
    parts = ref.split(":", 1)
    if len(parts) == 2 and len(parts[0]) == 8 and parts[1].isdigit():
        # New format: slot:idx
        slot = parts[0]
        idx  = int(parts[1])
        session = _get_search_session(slot)
        if not session:
            return None
        results = session["results"]
        if idx >= len(results):
            return None
        return str(results[idx].path)
    else:
        # Legacy: base64 encoded path
        return _decode_path(ref)


# ── Back to results list ──────────────────────────────────────────────────────

# sr_back is handled in the callback dispatcher by re-showing the session results.
# We wire it here so it can reach _cb_sr_back.


TEXT_EXTENSIONS = {
    ".txt", ".md", ".csv", ".log", ".json", ".py", ".js", ".ts",
    ".html", ".css", ".xml", ".yaml", ".yml", ".sh", ".bat", ".env",
    ".ini", ".cfg", ".toml",
}
