"""
Salim Onboarding — First-run setup flow with directory selection.
Stores user preferences in ~/.salim/user_prefs.json
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.onboarding")

PREFS_FILE = Path.home() / ".salim" / "user_prefs.json"
H = "HTML"


def load_prefs(user_id: int = 0) -> dict:
    if PREFS_FILE.exists():
        try:
            return json.loads(PREFS_FILE.read_text())
        except Exception:
            pass
    return {}


def save_prefs(prefs: dict):
    PREFS_FILE.parent.mkdir(parents=True, exist_ok=True)
    PREFS_FILE.write_text(json.dumps(prefs, indent=2, ensure_ascii=False))
    PREFS_FILE.chmod(0o600)


def get_image_save_dir() -> Path:
    prefs = load_prefs()
    p = prefs.get("image_save_dir", "")
    if p:
        d = Path(p).expanduser()
        d.mkdir(parents=True, exist_ok=True)
        return d
    # Default to ~/Pictures/Salim
    d = Path.home() / "Pictures" / "Salim"
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_docs_save_dir() -> Path:
    prefs = load_prefs()
    p = prefs.get("docs_save_dir", "")
    if p:
        d = Path(p).expanduser()
        d.mkdir(parents=True, exist_ok=True)
        return d
    d = Path.home() / "Desktop"
    d.mkdir(parents=True, exist_ok=True)
    return d


def is_onboarded() -> bool:
    return PREFS_FILE.exists() and bool(load_prefs().get("onboarded"))


class OnboardingHandlers:
    """Mixin — onboarding flow + /setup command."""

    @require_auth
    async def cmd_setup(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/setup — re-run onboarding wizard."""
        await self._onboarding_start(update.effective_message)

    async def _onboarding_start(self, msg):
        prefs = load_prefs()
        img_dir = prefs.get("image_save_dir", str(Path.home() / "Pictures" / "Salim"))
        doc_dir = prefs.get("docs_save_dir", str(Path.home() / "Desktop"))

        await msg.reply_text(
            "🎉 <b>Welcome to Salim v13!</b>\n\n"
            "Let me set up your preferences. You can change these anytime with /setup\n\n"
            "📁 <b>Current settings:</b>\n"
            f"• Images saved to: <code>{img_dir}</code>\n"
            f"• Documents saved to: <code>{doc_dir}</code>\n\n"
            "Tap to configure:",
            parse_mode=H,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📸 Set Image Save Folder", callback_data="ob_set_img")],
                [InlineKeyboardButton("📄 Set Documents Folder",  callback_data="ob_set_doc")],
                [InlineKeyboardButton("✅ Done — Use Defaults",   callback_data="ob_done")],
            ])
        )

    async def _handle_onboarding_callback(self, query, data: str):
        prefs = load_prefs()

        if data == "ob_set_img":
            # Offer common directories
            home = Path.home()
            options = [
                str(home / "Pictures" / "Salim"),
                str(home / "Pictures"),
                str(home / "Downloads" / "Salim"),
                str(home / "Desktop" / "Salim_Images"),
            ]
            btns = [[InlineKeyboardButton(o.replace(str(home), "~"), callback_data=f"ob_img:{o}")]
                    for o in options]
            btns.append([InlineKeyboardButton("◀️ Back", callback_data="ob_back")])
            await query.edit_message_text(
                "📸 <b>Where should Salim save images?</b>\n\n"
                "Choose a folder or type a custom path with:\n"
                "<code>/setup img /path/to/folder</code>",
                parse_mode=H,
                reply_markup=InlineKeyboardMarkup(btns)
            )

        elif data.startswith("ob_img:"):
            path = data[7:]
            prefs["image_save_dir"] = path
            Path(path).mkdir(parents=True, exist_ok=True)
            save_prefs(prefs)
            await query.edit_message_text(
                f"✅ <b>Images will be saved to:</b>\n<code>{path}</code>\n\n"
                "You can now send photos with captions like:\n"
                "<code>save this</code> or <code>send to email</code>",
                parse_mode=H,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("📄 Set Documents Folder", callback_data="ob_set_doc")],
                    [InlineKeyboardButton("✅ Finish Setup", callback_data="ob_done")],
                ])
            )

        elif data == "ob_set_doc":
            home = Path.home()
            options = [
                str(home / "Desktop"),
                str(home / "Documents"),
                str(home / "Documents" / "Salim"),
                str(home / "Downloads"),
            ]
            btns = [[InlineKeyboardButton(o.replace(str(home), "~"), callback_data=f"ob_doc:{o}")]
                    for o in options]
            btns.append([InlineKeyboardButton("◀️ Back", callback_data="ob_back")])
            await query.edit_message_text(
                "📄 <b>Where should Salim save documents?</b>",
                parse_mode=H,
                reply_markup=InlineKeyboardMarkup(btns)
            )

        elif data.startswith("ob_doc:"):
            path = data[7:]
            prefs["docs_save_dir"] = path
            Path(path).mkdir(parents=True, exist_ok=True)
            save_prefs(prefs)
            await query.edit_message_text(
                f"✅ <b>Documents will be saved to:</b>\n<code>{path}</code>",
                parse_mode=H,
                reply_markup=InlineKeyboardMarkup([
                    [InlineKeyboardButton("✅ Finish Setup", callback_data="ob_done")],
                ])
            )

        elif data == "ob_back":
            await self._onboarding_start(query.message)

        elif data == "ob_done":
            prefs["onboarded"] = True
            save_prefs(prefs)
            img_dir = prefs.get("image_save_dir", str(Path.home() / "Pictures" / "Salim"))
            doc_dir = prefs.get("docs_save_dir", str(Path.home() / "Desktop"))
            await query.edit_message_text(
                "✅ <b>Setup complete!</b>\n\n"
                f"📸 Images → <code>{img_dir}</code>\n"
                f"📄 Documents → <code>{doc_dir}</code>\n\n"
                "💬 <b>Just type anything in plain English to get started!</b>\n"
                "No need to use / commands — Salim understands you.\n\n"
                "<b>Examples:</b>\n"
                "• <i>create an invoice for Ahmed</i>\n"
                "• <i>send email to boss about the update</i>\n"
                "• <i>remind me to call John at 3pm</i>\n"
                "• <i>take a screenshot</i>\n"
                "• <i>what's the weather in Dubai?</i>",
                parse_mode=H
            )
