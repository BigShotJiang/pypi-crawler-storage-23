"""
Salim Office Agent v12 - AI document/email automation.
See module docstring above for full command reference.
"""
from __future__ import annotations

import asyncio
import csv
import email as email_lib
import imaplib
import io
import json
import logging
import os
import re
import smtplib
import subprocess
import time
from datetime import datetime
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.agent")

AGENT_DIR   = Path.home() / ".salim" / "agent"
DOCS_DIR    = Path.home() / "Desktop"
EMAIL_CFG   = Path.home() / ".salim" / "email_config.json"
MAX_STEPS   = 20
STEP_TIMEOUT = 60

_active_agents: dict[int, asyncio.Task] = {}


# ─────────────────────────── helpers ────────────────────────────

def _ensure_dirs():
    AGENT_DIR.mkdir(parents=True, mode=0o700, exist_ok=True)
    DOCS_DIR.mkdir(parents=True, exist_ok=True)

def _agent_log(uid: int) -> Path:
    _ensure_dirs()
    return AGENT_DIR / f"{uid}_last.json"

def save_agent_log(uid: int, log: dict):
    p = _agent_log(uid)
    p.write_text(json.dumps(log, indent=2, ensure_ascii=False))
    p.chmod(0o600)

def load_agent_log(uid: int) -> dict:
    p = _agent_log(uid)
    return json.loads(p.read_text()) if p.exists() else {}

def _safe_path(filename: str) -> Path:
    p = Path(filename).expanduser()
    if not p.is_absolute():
        for base in [DOCS_DIR, Path.home()]:
            c = base / filename
            if c.exists():
                return c
        return DOCS_DIR / filename
    return p

def _esc(v): 
    import html
    return html.escape(str(v), quote=False)


# ──────────────────────────── email config ────────────────────────────

def load_email_config() -> dict:
    return json.loads(EMAIL_CFG.read_text()) if EMAIL_CFG.exists() else {}

def save_email_config(cfg: dict):
    EMAIL_CFG.parent.mkdir(parents=True, exist_ok=True)
    EMAIL_CFG.write_text(json.dumps(cfg, indent=2))
    EMAIL_CFG.chmod(0o600)


# ────────────────────────── DOCX engine ──────────────────────────────

def create_docx(content: str, path: Path, title: str = "") -> Path:
    """
    Create a professional DOCX using docx-js (Node.js) via the SKILL.md rules.
    Falls back to python-docx if Node is unavailable.
    """
    # ── Try skill engine (docx-js) first ─────────────────────────────────────
    try:
        from salim.handlers.skill_engine import create_docx_via_nodejs, get_skill_for_task
        # Bootstrap skill .md
        get_skill_for_task("docx", "docx")
        spec = _parse_content_to_spec(content, title)
        ok, msg = create_docx_via_nodejs(spec, path)
        if ok and path.exists() and path.stat().st_size > 1000:
            logger.info(f"DOCX created via docx-js skill: {path}")
            return path
        else:
            logger.warning(f"docx-js failed ({msg}), falling back to python-docx")
    except Exception as e:
        logger.warning(f"Skill engine unavailable ({e}), using python-docx fallback")

    # ── Fallback: python-docx ─────────────────────────────────────────────────
    return _create_docx_fallback(content, path, title)


def _parse_content_to_spec(content: str, title: str) -> dict:
    """Parse markdown content into a spec dict for skill_engine."""
    spec = {"title": title or "Document", "sections": []}
    current_section = None
    table_rows = []
    bullets = []
    text_buffer = []

    def flush_section():
        nonlocal current_section, table_rows, bullets, text_buffer
        if current_section is not None:
            if bullets:
                current_section["bullets"] = bullets[:]
                bullets.clear()
            if table_rows:
                current_section["table"] = _parse_markdown_table(table_rows)
                table_rows.clear()
            if text_buffer:
                current_section["text"] = " ".join(text_buffer)
                text_buffer.clear()
            spec["sections"].append(current_section)
            current_section = None

    for line in (content or "").strip().split("\n"):
        line = line.rstrip()
        if not line:
            continue
        if line.startswith("### "):
            flush_section()
            current_section = {"heading": line[4:], "level": 3}
        elif line.startswith("## "):
            flush_section()
            current_section = {"heading": line[3:], "level": 2}
        elif line.startswith("# "):
            flush_section()
            current_section = {"heading": line[2:], "level": 1}
        elif line.startswith(("- ", "* ")):
            if current_section is None:
                current_section = {"heading": "", "level": 2}
            bullets.append(line[2:])
        elif line.startswith("|"):
            if current_section is None:
                current_section = {"heading": "", "level": 2}
            table_rows.append(line)
        elif re.match(r"^\d+\.\s", line):
            if current_section is None:
                current_section = {"heading": "", "level": 2}
            bullets.append(re.sub(r"^\d+\.\s", "", line))
        else:
            if current_section is None:
                current_section = {"heading": "", "level": 2}
            text_buffer.append(line)

    flush_section()
    return spec


def _parse_markdown_table(rows: list[str]) -> list[list]:
    """Parse markdown table rows into 2D list."""
    result = []
    for row in rows:
        cells = [c.strip() for c in row.strip("|").split("|")]
        if all(re.match(r"^[-:]+$", c) for c in cells if c):
            continue
        result.append(cells)
    return result


def _create_docx_fallback(content: str, path: Path, title: str = "") -> Path:
    """Python-docx fallback with proper formatting following SKILL.md principles."""
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches, Cm
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    doc = Document()
    # US Letter with 1-inch margins per SKILL.md
    for sec in doc.sections:
        sec.top_margin    = Inches(1)
        sec.bottom_margin = Inches(1)
        sec.left_margin   = Inches(1)
        sec.right_margin  = Inches(1)
        sec.page_width    = Inches(8.5)
        sec.page_height   = Inches(11)

    # Set default font to Arial per SKILL.md
    from docx.oxml.ns import qn as _qn
    from lxml import etree
    try:
        doc.styles["Normal"].font.name = "Arial"
        doc.styles["Normal"].font.size = Pt(11)
    except Exception:
        pass

    if title:
        h = doc.add_heading(title, level=0)
        h.alignment = WD_ALIGN_PARAGRAPH.CENTER
        if h.runs:
            h.runs[0].font.color.rgb = RGBColor(0x1F, 0x38, 0x64)
            h.runs[0].font.size = Pt(24)
            h.runs[0].font.name = "Arial"
        doc.add_paragraph()

    table_rows: list[str] = []

    def flush_table():
        if table_rows:
            _docx_table(doc, table_rows)
            table_rows.clear()

    for line in (content or "").strip().split("\n"):
        line = line.rstrip()
        if not line:
            flush_table()
            doc.add_paragraph()
            continue
        if line.startswith("### "):
            flush_table()
            h = doc.add_heading(line[4:], level=3)
            if h.runs:
                h.runs[0].font.color.rgb = RGBColor(0x40, 0x40, 0x40)
                h.runs[0].font.name = "Arial"
        elif line.startswith("## "):
            flush_table()
            h = doc.add_heading(line[3:], level=2)
            if h.runs:
                h.runs[0].font.color.rgb = RGBColor(0x2E, 0x75, 0xB6)
                h.runs[0].font.name = "Arial"
        elif line.startswith("# "):
            flush_table()
            h = doc.add_heading(line[2:], level=1)
            if h.runs:
                h.runs[0].font.color.rgb = RGBColor(0x1F, 0x38, 0x64)
                h.runs[0].font.name = "Arial"
        elif line.startswith(("- ", "* ")):
            flush_table()
            # Use proper List Bullet style (not unicode bullet)
            p = doc.add_paragraph(style="List Bullet")
            _apply_inline_formatting(p, line[2:])
        elif re.match(r"^\d+\.\s", line):
            flush_table()
            p = doc.add_paragraph(style="List Number")
            _apply_inline_formatting(p, re.sub(r"^\d+\.\s", "", line))
        elif line.startswith("|"):
            table_rows.append(line)
        else:
            flush_table()
            p = doc.add_paragraph()
            _apply_inline_formatting(p, line)
            p.paragraph_format.space_after = Pt(6)
            p.paragraph_format.space_before = Pt(2)

    flush_table()

    # Professional footer
    footer_para = doc.sections[0].footer.paragraphs[0]
    footer_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = footer_para.add_run(f"Generated by Salim  ·  {datetime.now().strftime('%B %d, %Y')}")
    run.font.size = Pt(9)
    run.font.color.rgb = RGBColor(0x80, 0x80, 0x80)
    run.font.name = "Arial"

    doc.save(str(path))
    return path


def _apply_inline_formatting(paragraph, text: str):
    """Apply **bold** and *italic* markdown formatting to a paragraph."""
    from docx.shared import Pt
    # Split text by bold/italic markers
    parts = re.split(r'(\*\*[^*]+\*\*|\*[^*]+\*)', text)
    for part in parts:
        if not part:
            continue
        if part.startswith("**") and part.endswith("**"):
            run = paragraph.add_run(part[2:-2])
            run.bold = True
            run.font.name = "Arial"
        elif part.startswith("*") and part.endswith("*"):
            run = paragraph.add_run(part[1:-1])
            run.italic = True
            run.font.name = "Arial"
        else:
            run = paragraph.add_run(part)
            run.font.name = "Arial"


def _docx_table(doc, rows: list[str]):
    from docx.shared import Pt, RGBColor
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement

    parsed = []
    for row in rows:
        cells = [c.strip() for c in row.strip("|").split("|")]
        if not all(re.match(r"^[-:]+$", c) for c in cells if c):
            parsed.append(cells)
    if not parsed:
        return

    max_cols = max(len(r) for r in parsed)
    table = doc.add_table(rows=len(parsed), cols=max_cols)
    table.style = "Table Grid"
    for r_idx, row in enumerate(parsed):
        for c_idx, txt in enumerate(row[:max_cols]):
            cell = table.rows[r_idx].cells[c_idx]
            run = cell.paragraphs[0].add_run(txt)
            run.font.size = Pt(10)
            if r_idx == 0:
                run.font.bold = True
                tc = cell._tc
                tcPr = tc.get_or_add_tcPr()
                shd = OxmlElement("w:shd")
                shd.set(qn("w:fill"), "2E74B5")
                shd.set(qn("w:val"), "clear")
                tcPr.append(shd)
                run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)


# ────────────────────────── XLSX engine ──────────────────────────────

def create_xlsx(content: str, path: Path, title: str = "") -> Path:
    """
    Create professional XLSX via skill_engine (openpyxl with formulas, color-coding).
    Follows SKILL.md: blue=hardcoded inputs, black=formulas, freeze panes, auto-widths.
    """
    try:
        from salim.handlers.skill_engine import create_xlsx_professional
        spec = _parse_content_to_xlsx_spec(content, title)
        ok, msg = create_xlsx_professional(spec, path)
        if ok and path.exists() and path.stat().st_size > 1000:
            logger.info(f"XLSX created via skill engine: {path}")
            return path
        logger.warning(f"Skill XLSX failed ({msg}), using fallback")
    except Exception as e:
        logger.warning(f"Skill XLSX error ({e}), using fallback")

    return _create_xlsx_fallback(content, path, title)


def _parse_content_to_xlsx_spec(content: str, title: str) -> dict:
    """Parse markdown content into xlsx spec with sheets, headers, data, formulas."""
    headers: list[str] = []
    data_rows: list[list] = []
    formulas: list[dict] = []
    extra_text: list[str] = []
    in_table = False

    for line in (content or "").strip().split("\n"):
        line = line.rstrip()
        if not line:
            in_table = False
            continue
        if line.startswith("|"):
            cells = [c.strip() for c in line.strip("|").split("|")]
            if all(re.match(r"^[-:]+$", c) for c in cells if c):
                in_table = True
                continue
            if not headers:
                headers = cells
            else:
                data_rows.append(cells)
            in_table = True
        elif line.startswith(("# ", "## ")):
            extra_text.append(re.sub(r"^#+\s*", "", line))
        elif "=" in line and not line.startswith("|"):
            # Looks like a formula assignment: A5=SUM(A2:A4)
            m = re.match(r"([A-Za-z]+\d+)\s*=\s*(.+)", line.strip())
            if m:
                formulas.append({
                    "cell": m.group(1).upper(),
                    "formula": "=" + m.group(2).strip(),
                })
        else:
            extra_text.append(line)

    # Auto-generate SUM formulas for numeric columns
    if data_rows and headers:
        # Try to add total row formula for columns that look numeric
        total_row_idx = len(data_rows) + 2  # +1 header, +1 for 1-indexed
        for col_idx, header in enumerate(headers, 1):
            col_letter = chr(ord('A') + col_idx - 1)
            data_start = 2  # row 2 after header
            data_end = total_row_idx - 1
            # Only add formula for non-first columns (first usually labels)
            if col_idx > 1:
                formulas.append({
                    "cell": f"{col_letter}{total_row_idx}",
                    "formula": f"=SUM({col_letter}{data_start}:{col_letter}{data_end})",
                    "label": "TOTAL" if col_idx == 2 else "",
                })

    return {
        "title": title,
        "sheets": [{
            "name": (title[:31] if title else "Data"),
            "headers": headers,
            "data": data_rows,
            "formulas": formulas,
        }]
    }


def _create_xlsx_fallback(content: str, path: Path, title: str = "") -> Path:
    """Fallback XLSX creator using openpyxl directly."""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = (title[:31] if title else "Sheet1")

    H_FILL = PatternFill("solid", fgColor="2E75B6")
    A_FILL = PatternFill("solid", fgColor="EEF3FA")
    T_FILL = PatternFill("solid", fgColor="BDD7EE")
    H_FONT = Font(bold=True, color="FFFFFF", size=11, name="Arial")
    B_FONT = Font(size=10, name="Arial")
    BD     = Side(style="thin", color="CCCCCC")
    BORDER = Border(left=BD, right=BD, top=BD, bottom=BD)
    CENTER = Alignment(horizontal="center", vertical="center")
    LEFT   = Alignment(horizontal="left", vertical="center", wrap_text=True)

    row = 1
    if title:
        ws.merge_cells(f"A{row}:J{row}")
        c = ws.cell(row=row, column=1, value=title)
        c.font = Font(bold=True, size=14, color="FFFFFF", name="Arial")
        c.fill = H_FILL; c.alignment = CENTER
        ws.row_dimensions[row].height = 30
        row += 2

    headers: list[str] = []
    data_rows: list[list] = []
    in_table = False

    for line in (content or "").strip().split("\n"):
        line = line.rstrip()
        if not line:
            in_table = False; continue
        if line.startswith("|"):
            cells = [c.strip() for c in line.strip("|").split("|")]
            if all(re.match(r"^[-:]+$", c) for c in cells if c):
                in_table = True; continue
            if not headers:
                headers = cells; in_table = True
            else:
                data_rows.append(cells)
        elif line.startswith(("# ", "## ")):
            heading = re.sub(r"^#+\s*", "", line)
            ws.merge_cells(f"A{row}:J{row}")
            c = ws.cell(row=row, column=1, value=heading)
            c.font = Font(bold=True, size=12, color="2E75B6", name="Arial")
            ws.row_dimensions[row].height = 22; row += 1
            in_table = False
        else:
            ws.cell(row=row, column=1, value=line).font = B_FONT
            row += 1

    if headers:
        for ci, h in enumerate(headers, 1):
            c = ws.cell(row=row, column=ci, value=h)
            c.font = H_FONT; c.fill = H_FILL; c.alignment = CENTER; c.border = BORDER
            ws.column_dimensions[get_column_letter(ci)].width = max(15, len(h) + 4)
        ws.row_dimensions[row].height = 25; row += 1

    data_start = row
    for ri, rd in enumerate(data_rows):
        fill = A_FILL if ri % 2 == 1 else None
        for ci, val in enumerate(rd, 1):
            c = ws.cell(row=row, column=ci)
            try:
                num_val = val.replace(",", "").replace("$", "").strip()
                c.value = float(num_val) if "." in num_val else (
                    int(num_val) if num_val.lstrip("-").isdigit() else val
                )
            except (ValueError, AttributeError):
                c.value = val
            c.font = B_FONT; c.alignment = LEFT; c.border = BORDER
            if fill: c.fill = fill
        row += 1

    if data_rows and headers:
        ws.cell(row=row, column=1, value="TOTAL").font = Font(bold=True, name="Arial")
        for ci in range(2, len(headers) + 1):
            col_l = get_column_letter(ci)
            # Use real Excel formula per SKILL.md — never hardcode Python calculations
            c = ws.cell(row=row, column=ci, value=f"=SUM({col_l}{data_start}:{col_l}{row-1})")
            c.font = Font(bold=True, color="000000", name="Arial")  # black = formula per skill
            c.fill = T_FILL; c.border = BORDER

    ws.freeze_panes = ws.cell(row=(3 if title else 2), column=1)
    wb.save(str(path))
    return path


# ────────────────────────── CSV engine ───────────────────────────────

def create_csv(content: str, path: Path) -> Path:
    rows = []
    for line in (content or "").strip().split("\n"):
        if line.startswith("|"):
            cells = [c.strip() for c in line.strip("|").split("|")]
            if not all(re.match(r"^[-:]+$", c) for c in cells if c):
                rows.append(cells)
        elif "," in line:
            rows.append(next(csv.reader([line])))
        elif line.strip():
            rows.append([line.strip()])
    with open(str(path), "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(rows)
    return path


# ────────────────────────── PDF engine ───────────────────────────────

def create_pdf(content: str, path: Path, title: str = "") -> Path:
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.lib import colors
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable

        doc_rl = SimpleDocTemplate(str(path), pagesize=letter,
                                   rightMargin=inch, leftMargin=inch,
                                   topMargin=inch, bottomMargin=inch)
        styles = getSampleStyleSheet()
        T_STYLE = ParagraphStyle("T", parent=styles["Title"], fontSize=18,
                                 textColor=colors.HexColor("#1F497D"), spaceAfter=12)
        H1 = ParagraphStyle("H1", parent=styles["Heading1"], fontSize=14,
                             textColor=colors.HexColor("#1F497D"), spaceBefore=12, spaceAfter=6)
        H2 = ParagraphStyle("H2", parent=styles["Heading2"], fontSize=12,
                             textColor=colors.HexColor("#2E74B5"), spaceBefore=8, spaceAfter=4)
        BODY = ParagraphStyle("B", parent=styles["Normal"], fontSize=11, leading=16)

        story = []
        if title:
            story += [Paragraph(title, T_STYLE),
                      HRFlowable(width="100%", thickness=1, color=colors.HexColor("#1F497D")),
                      Spacer(1, 12)]

        table_rows: list[str] = []
        for line in (content or "").strip().split("\n"):
            line = line.rstrip()
            if not line:
                if table_rows:
                    _pdf_table(story, table_rows); table_rows = []
                story.append(Spacer(1, 8)); continue
            if line.startswith("## "):
                if table_rows: _pdf_table(story, table_rows); table_rows = []
                story.append(Paragraph(line[3:], H2))
            elif line.startswith("# "):
                if table_rows: _pdf_table(story, table_rows); table_rows = []
                story.append(Paragraph(line[2:], H1))
            elif line.startswith("|"):
                table_rows.append(line)
            elif line.startswith(("- ", "* ")):
                story.append(Paragraph(f"• {line[2:]}", BODY))
            else:
                if table_rows: _pdf_table(story, table_rows); table_rows = []
                story.append(Paragraph(line, BODY))
        if table_rows:
            _pdf_table(story, table_rows)

        story += [Spacer(1, 20),
                  HRFlowable(width="100%", thickness=0.5, color=colors.grey),
                  Paragraph(f"Generated by Salim  ·  {datetime.now().strftime('%B %d, %Y')}",
                             ParagraphStyle("F", parent=styles["Normal"], fontSize=8,
                                            textColor=colors.grey, alignment=1))]
        doc_rl.build(story)
        return path
    except ImportError:
        raise ImportError("reportlab not installed. Run: pip install reportlab")


def _pdf_table(story, rows: list[str]):
    from reportlab.platypus import Table, TableStyle
    from reportlab.lib import colors

    parsed = []
    for row in rows:
        cells = [c.strip() for c in row.strip("|").split("|")]
        if not all(re.match(r"^[-:]+$", c) for c in cells if c):
            parsed.append(cells)
    if not parsed:
        return
    max_cols = max(len(r) for r in parsed)
    normalized = [r + [""] * (max_cols - len(r)) for r in parsed]
    t = Table(normalized)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F497D")),
        ("TEXTCOLOR",  (0, 0), (-1, 0), colors.white),
        ("FONTNAME",   (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE",   (0, 0), (-1, -1), 10),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#DCE6F1")]),
        ("GRID",       (0, 0), (-1, -1), 0.5, colors.HexColor("#B8CCE4")),
        ("ALIGN",      (0, 0), (-1, -1), "LEFT"),
        ("VALIGN",     (0, 0), (-1, -1), "MIDDLE"),
        ("TOPPADDING", (0, 0), (-1, -1), 6),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
    ]))
    story.append(t)


# ────────────────────────── PPTX engine ──────────────────────────────

def create_pptx(content: str, path: Path, title: str = "") -> Path:
    """
    Create professional PPTX via pptxgenjs (Node.js) following SKILL.md design rules.
    Falls back to python-pptx if Node is unavailable.
    """
    try:
        from salim.handlers.skill_engine import create_pptx_via_nodejs
        spec = _parse_content_to_pptx_spec(content, title)
        ok, msg = create_pptx_via_nodejs(spec, path)
        if ok and path.exists() and path.stat().st_size > 2000:
            logger.info(f"PPTX created via pptxgenjs skill: {path}")
            return path
        logger.warning(f"pptxgenjs failed ({msg}), using python-pptx fallback")
    except Exception as e:
        logger.warning(f"Skill PPTX error ({e}), using python-pptx fallback")
    return _create_pptx_fallback(content, path, title)


def _parse_content_to_pptx_spec(content: str, title: str) -> dict:
    """Parse markdown content into pptx spec."""
    slides = [{"title": title or "Presentation", "body": "", "bullets": [], "layout": "title"}]
    slides_raw = re.split(r"\n---+\n", (content or ""))
    for idx, slide_text in enumerate(slides_raw):
        lines = [l.rstrip() for l in slide_text.strip().split("\n") if l.strip()]
        if not lines:
            continue
        slide_title = ""
        slide_body = ""
        bullets = []
        for line in lines:
            if line.startswith(("# ", "## ")):
                slide_title = re.sub(r"^#+\s*", "", line)
            elif line.startswith(("- ", "* ")):
                bullets.append(line[2:])
            elif re.match(r"^\d+\.\s", line):
                bullets.append(re.sub(r"^\d+\.\s", "", line))
            else:
                if not slide_body:
                    slide_body = line
                else:
                    bullets.append(line)
        if slide_title or bullets:
            slides.append({"title": slide_title, "body": slide_body, "bullets": bullets, "layout": "title_content"})
    return {"title": title or "Presentation", "slides": slides}


def _create_pptx_fallback(content: str, path: Path, title: str = "") -> Path:
    """Python-pptx fallback for PPTX creation."""
    from pptx import Presentation
    from pptx.util import Inches, Pt
    prs = Presentation()
    prs.slide_width = Inches(13.33)
    prs.slide_height = Inches(7.5)
    slides_raw = re.split(r"\n---+\n", (content or ""))
    if not slides_raw:
        slides_raw = [content]
    for idx, slide_text in enumerate(slides_raw):
        lines = [l.rstrip() for l in slide_text.strip().split("\n") if l.strip()]
        if not lines:
            continue
        if idx == 0:
            sl = prs.slides.add_slide(prs.slide_layouts[0])
            sl.shapes.title.text = (title or lines[0].lstrip("# "))
            if len(lines) > 1 and sl.placeholders and len(sl.placeholders) > 1:
                sl.placeholders[1].text = "\n".join(lines[1:])
        else:
            sl = prs.slides.add_slide(prs.slide_layouts[1])
            sl.shapes.title.text = lines[0].lstrip("# ")
            if sl.placeholders and len(sl.placeholders) > 1:
                tf = sl.placeholders[1].text_frame
                tf.clear()
                for i, line in enumerate(lines[1:]):
                    p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
                    p.text = re.sub(r"^\s*[-*]\s*", "", line)
                    p.level = 1 if line.startswith("  ") else 0
                    p.font.size = Pt(18)
    prs.save(str(path))
    return path


# ────────────────────── Document read/edit ───────────────────────────

def read_docx(path: Path) -> str:
    from docx import Document
    doc = Document(str(path))
    parts = [p.text for p in doc.paragraphs if p.text.strip()]
    for table in doc.tables:
        for row in table.rows:
            parts.append(" | ".join(c.text.strip() for c in row.cells))
    return "\n".join(parts)

def read_xlsx(path: Path) -> str:
    import openpyxl
    wb = openpyxl.load_workbook(str(path), data_only=True)
    parts = []
    for name in wb.sheetnames:
        ws = wb[name]
        parts.append(f"=== {name} ===")
        for row in ws.iter_rows(values_only=True):
            if any(v is not None for v in row):
                parts.append(" | ".join(str(v) if v is not None else "" for v in row))
    return "\n".join(parts)

def read_csv(path: Path) -> str:
    with open(str(path), "r", encoding="utf-8") as f:
        return "\n".join(" | ".join(r) for r in list(csv.reader(f))[:50])

def edit_docx(path: Path, instruction: str, content: str) -> Path:
    from docx import Document
    doc = Document(str(path))
    instr = instruction.lower()

    if "find and replace" in instr or "replace" in instr:
        for line in (content or "").split("\n"):
            m = re.match(r'replace\s+["\'](.+?)["\']\s+with\s+["\'](.+?)["\']', line, re.I)
            if m:
                old, new = m.group(1), m.group(2)
                for para in doc.paragraphs:
                    for run in para.runs:
                        run.text = run.text.replace(old, new)
                for table in doc.tables:
                    for row in table.rows:
                        for cell in row.cells:
                            for para in cell.paragraphs:
                                for run in para.runs:
                                    run.text = run.text.replace(old, new)
    elif "add table" in instr or "insert table" in instr:
        table_lines = [l for l in (content or "").split("\n") if l.strip().startswith("|")]
        if table_lines:
            doc.add_paragraph()
            _docx_table(doc, table_lines)
    elif "add paragraph" in instr or "append" in instr:
        doc.add_paragraph()
        for line in (content or "").split("\n"):
            if line.strip():
                doc.add_paragraph(line.strip())
    elif "delete paragraph" in instr:
        kw_m = re.search(r'delete.*?["\'](.+?)["\']', instruction, re.I)
        if kw_m:
            kw = kw_m.group(1).lower()
            for para in doc.paragraphs:
                if kw in para.text.lower():
                    p = para._element
                    p.getparent().remove(p)
    else:
        doc.add_page_break()
        doc.add_heading("Additions", level=1)
        for line in (content or "").split("\n"):
            if line.strip():
                doc.add_paragraph(line.strip())

    doc.save(str(path))
    return path

def edit_xlsx(path: Path, instruction: str, content: str) -> Path:
    import openpyxl
    from openpyxl.styles import Font, PatternFill
    instr = instruction.lower()
    wb = openpyxl.load_workbook(str(path))
    ws = wb.active

    if "add column" in instr:
        col_name = re.search(r"add column (.+?)(?:\s+to|\s*$)", instruction, re.I)
        col_name = col_name.group(1).strip() if col_name else "NewColumn"
        mc = ws.max_column + 1
        c = ws.cell(row=1, column=mc, value=col_name)
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="1F497D")
    elif "add row" in instr:
        ws.append([c.strip() for c in (content or "").split(",")])
    elif "delete row" in instr:
        m = re.search(r"delete row (\d+)", instruction, re.I)
        if m: ws.delete_rows(int(m.group(1)))
    elif "delete column" in instr:
        m = re.search(r"delete column ([A-Za-z]+|\d+)", instruction, re.I)
        if m:
            col = m.group(1)
            if col.isdigit():
                ws.delete_cols(int(col))
            else:
                from openpyxl.utils import column_index_from_string
                ws.delete_cols(column_index_from_string(col.upper()))
    elif "merge" in instr and "sheet" in instr:
        names = wb.sheetnames
        if len(names) > 1:
            target = wb[names[0]]
            for sn in names[1:]:
                for row in wb[sn].iter_rows(values_only=True):
                    target.append(list(row))
    elif "set cell" in instr:
        m = re.search(r"set cell ([A-Za-z]+\d+) to (.+)", instruction, re.I)
        if m: ws[m.group(1).upper()] = m.group(2).strip()
    elif "formula" in instr:
        for line in (content or "").split("\n"):
            m = re.match(r"([A-Za-z]+\d+)\s*=\s*(.+)", line.strip(), re.I)
            if m: ws[m.group(1).upper()] = "=" + m.group(2).strip()
    else:
        for line in (content or "").split("\n"):
            if "|" in line and not all(c in "-|: " for c in line):
                ws.append([c.strip() for c in line.strip("|").split("|")])

    wb.save(str(path))
    return path

def edit_csv(path: Path, instruction: str, content: str) -> Path:
    with open(str(path), "r", encoding="utf-8") as f:
        rows = list(csv.reader(f))
    instr = instruction.lower()

    if "add row" in instr or "add_row" in instr:
        rows.append(next(csv.reader([content])))
    elif "delete row" in instr:
        m = re.search(r"delete row (\d+)", instruction, re.I)
        if m:
            idx = int(m.group(1)) - 1
            if 0 <= idx < len(rows): rows.pop(idx)
    elif "add column" in instr:
        col = re.search(r"add column (.+?)(?:\s+to|\s*$)", instruction, re.I)
        col = col.group(1).strip() if col else "NewCol"
        rows = [row + [col if i == 0 else ""] for i, row in enumerate(rows)]
    elif "replace" in instr:
        m = re.search(r'replace\s+["\'](.+?)["\']\s+with\s+["\'](.+?)["\']', instruction, re.I)
        if m:
            old, new = m.group(1), m.group(2)
            rows = [[c.replace(old, new) for c in row] for row in rows]

    with open(str(path), "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(rows)
    return path


# ───────────────────────── Email engine ──────────────────────────────

def send_email(to: str, subject: str, body: str,
               attachments: list | None = None,
               cc: str = "", bcc: str = "",
               sender_name: str = "Salim AI") -> tuple[bool, str]:
    """Send a beautiful HTML email with plain-text fallback."""
    cfg = load_email_config()
    if not cfg:
        return False, "Email not configured. Use /agent email setup first."
    smtp_host = cfg.get("smtp_host", "")
    smtp_port = int(cfg.get("smtp_port", 587))
    username  = cfg.get("username", "")
    password  = cfg.get("password", "")
    sender    = cfg.get("sender", username)
    display_name = cfg.get("display_name", sender_name)
    if not all([smtp_host, username, password]):
        return False, "Incomplete email config. Re-run /agent email setup."

    # Build HTML email using skill_engine
    try:
        from salim.handlers.skill_engine import build_html_email
        html_body = build_html_email(to, subject, body, display_name)
    except Exception:
        # Fallback inline HTML
        safe_body = body.replace("\n\n", "</p><p>").replace("\n", "<br>")
        html_body = f"""<!DOCTYPE html><html><body style="font-family:Arial;max-width:600px;margin:auto;padding:20px">
<div style="background:#1F3864;padding:20px;border-radius:8px 8px 0 0">
<h2 style="color:#fff;margin:0">{subject}</h2></div>
<div style="background:#fff;border:1px solid #e5e7eb;padding:24px;border-radius:0 0 8px 8px">
<p style="color:#374151;line-height:1.7">{safe_body}</p></div>
<p style="color:#9ca3af;font-size:12px;text-align:center;margin-top:16px">Sent via Salim AI</p>
</body></html>"""

    # Build multipart/alternative with both plain and HTML
    outer = MIMEMultipart("mixed")
    outer["From"]    = f"{display_name} <{sender}>"
    outer["To"]      = to
    outer["Subject"] = subject
    if cc:  outer["Cc"]  = cc
    if bcc: outer["Bcc"] = bcc

    alt = MIMEMultipart("alternative")
    alt.attach(MIMEText(body, "plain", "utf-8"))
    alt.attach(MIMEText(html_body, "html", "utf-8"))
    outer.attach(alt)

    for att in (attachments or []):
        p = _safe_path(att)
        if p.exists():
            with open(str(p), "rb") as f:
                part = MIMEApplication(f.read(), Name=p.name)
            part["Content-Disposition"] = f'attachment; filename="{p.name}"'
            outer.attach(part)

    recipients = [to] + ([cc] if cc else []) + ([bcc] if bcc else [])
    try:
        with smtplib.SMTP(smtp_host, smtp_port, timeout=20) as s:
            s.ehlo(); s.starttls(); s.login(username, password)
            s.sendmail(sender, recipients, outer.as_string())
        return True, f"✉️ HTML email sent to {to}"
    except Exception as e:
        try:
            with smtplib.SMTP_SSL(smtp_host, 465, timeout=20) as s:
                s.login(username, password)
                s.sendmail(sender, recipients, outer.as_string())
            return True, f"✉️ HTML email sent to {to} (SSL)"
        except Exception as e2:
            return False, f"Send failed: {e2}"

def read_emails(folder: str = "INBOX", limit: int = 10, search: str = "ALL") -> list[dict]:
    cfg = load_email_config()
    if not cfg: return []
    imap_host = cfg.get("imap_host", "")
    username  = cfg.get("username", "")
    password  = cfg.get("password", "")
    if not all([imap_host, username, password]): return []
    try:
        mail = imaplib.IMAP4_SSL(imap_host, timeout=20)
        mail.login(username, password)
        mail.select(folder)
        _, data = mail.search(None, search)
        ids = data[0].split()[-limit:]
        emails = []
        for eid in reversed(ids):
            _, md = mail.fetch(eid, "(RFC822)")
            raw = md[0][1]
            em = email_lib.message_from_bytes(raw)
            body = ""
            if em.is_multipart():
                for part in em.walk():
                    if part.get_content_type() == "text/plain":
                        body = part.get_payload(decode=True).decode("utf-8", errors="replace"); break
            else:
                body = em.get_payload(decode=True).decode("utf-8", errors="replace")
            emails.append({
                "id": eid.decode(), "from": em.get("From",""),
                "to": em.get("To",""), "subject": em.get("Subject","(no subject)"),
                "date": em.get("Date",""), "body": body[:500],
            })
        mail.logout()
        return emails
    except Exception as e:
        logger.error(f"IMAP error: {e}")
        return []

def search_emails(query: str, limit: int = 10) -> list[dict]:
    try:
        r = read_emails(search=f'SUBJECT "{query}"', limit=limit)
        return r if r else read_emails(search=f'BODY "{query}"', limit=limit)
    except Exception:
        return read_emails(limit=limit)

def reply_to_email(email_id: str, reply_body: str) -> tuple[bool, str]:
    emails = read_emails(limit=50)
    original = next((e for e in emails if e["id"] == email_id), None)
    if not original:
        return False, f"Email ID {email_id} not found in recent emails."
    to = original["from"]
    subject = ("Re: " + original["subject"]) if not original["subject"].startswith("Re:") else original["subject"]
    quoted = "\n".join(f"> {l}" for l in original["body"].split("\n"))
    body = f"{reply_body}\n\n---\nOn {original['date']}, {original['from']} wrote:\n{quoted}"
    return send_email(to, subject, body)


# ────────────────────────── Tool executor ────────────────────────────

async def _execute_tool(action: str, parameters: dict) -> tuple[bool, str]:
    """Execute any tool. All real — no mocks."""
    try:
        _ensure_dirs()

        if action == "create_document":
            doc_type = parameters.get("type", "docx").lower().strip()
            filename = parameters.get("filename", f"document_{int(time.time())}")
            title    = parameters.get("title", "")
            content  = parameters.get("content", "")
            path = _safe_path(filename)

            type_map = {
                "docx": ".docx", "word": ".docx", "doc": ".docx",
                "xlsx": ".xlsx", "excel": ".xlsx", "xls": ".xlsx",
                "csv": ".csv",
                "pdf": ".pdf",
                "pptx": ".pptx", "ppt": ".pptx", "powerpoint": ".pptx",
            }
            ext = type_map.get(doc_type, ".docx")
            if not str(path).endswith(ext):
                path = path.with_suffix(ext)

            if ext == ".docx":
                create_docx(content, path, title)
            elif ext == ".xlsx":
                create_xlsx(content, path, title)
            elif ext == ".csv":
                create_csv(content, path)
            elif ext == ".pdf":
                create_pdf(content, path, title)
            elif ext == ".pptx":
                create_pptx(content, path, title)

            size = path.stat().st_size // 1024
            return True, f"✅ Created: {path.name} ({size} KB) at {path.parent}"

        elif action == "read_document":
            path = _safe_path(parameters.get("path", ""))
            if not path.exists():
                return False, f"File not found: {path}"
            ext = path.suffix.lower()
            if ext == ".docx":
                text = read_docx(path)
            elif ext in (".xlsx", ".xls"):
                text = read_xlsx(path)
            elif ext == ".csv":
                text = read_csv(path)
            else:
                text = path.read_text(errors="replace")
            return True, (text[:3000] or "(empty file)")

        elif action == "edit_document":
            path = _safe_path(parameters.get("path", ""))
            if not path.exists():
                return False, f"File not found: {path}"
            instruction = parameters.get("instruction", "")
            content     = parameters.get("content", "")
            ext = path.suffix.lower()
            if ext == ".docx":
                edit_docx(path, instruction, content)
            elif ext in (".xlsx", ".xls"):
                edit_xlsx(path, instruction, content)
            elif ext == ".csv":
                edit_csv(path, instruction, content)
            elif ext in (".txt", ".md"):
                if "append" in instruction.lower():
                    with open(str(path), "a") as f:
                        f.write("\n" + content)
                else:
                    path.write_text(content)
            else:
                return False, f"Editing not supported for {ext} files"
            size = path.stat().st_size // 1024
            return True, f"✅ Edited: {path.name} ({size} KB)"

        elif action == "delete_document":
            path = _safe_path(parameters.get("path", ""))
            if not path.exists():
                return False, f"File not found: {path}"
            path.unlink()
            return True, f"✅ Deleted: {path.name}"

        elif action == "convert_document":
            from_path = _safe_path(parameters.get("from_path", ""))
            to_fmt    = parameters.get("to_format", "pdf").lower()
            if not from_path.exists():
                return False, f"File not found: {from_path}"
            out = from_path.with_suffix(f".{to_fmt}")

            if to_fmt == "pdf" and from_path.suffix.lower() == ".docx":
                create_pdf(read_docx(from_path), out, from_path.stem.replace("_"," ").title())
                return True, f"✅ Converted to PDF: {out.name}"
            elif to_fmt == "docx" and from_path.suffix.lower() == ".txt":
                create_docx(from_path.read_text(errors="replace"), out, from_path.stem.replace("_"," ").title())
                return True, f"✅ Converted to DOCX: {out.name}"
            elif to_fmt == "csv" and from_path.suffix.lower() in (".xlsx", ".xls"):
                import openpyxl
                wb = openpyxl.load_workbook(str(from_path), data_only=True)
                ws = wb.active
                with open(str(out), "w", newline="") as f:
                    csv.writer(f).writerows(
                        [v if v is not None else "" for v in row]
                        for row in ws.iter_rows(values_only=True)
                    )
                return True, f"✅ Converted to CSV: {out.name}"
            else:
                result = subprocess.run(
                    ["libreoffice", "--headless", "--convert-to", to_fmt,
                     "--outdir", str(out.parent), str(from_path)],
                    capture_output=True, text=True, timeout=60
                )
                if result.returncode == 0:
                    return True, f"✅ Converted: {out.name}"
                return False, f"Conversion failed: {result.stderr[:300]}"

        elif action == "shell":
            cmd = parameters.get("command", "")
            result = subprocess.run(
                cmd, shell=True, capture_output=True, text=True,
                timeout=STEP_TIMEOUT, cwd=str(Path.home())
            )
            out = (result.stdout or "").strip()
            err = (result.stderr or "").strip()
            if result.returncode != 0 and err:
                return False, f"Exit {result.returncode}: {err[:1000]}"
            return True, (out or "(done)")[:2000]

        elif action == "find_files":
            pattern   = parameters.get("pattern", "*")
            directory = Path(parameters.get("directory", str(Path.home()))).expanduser()
            results = []
            for p in directory.rglob(pattern):
                results.append(str(p))
                if len(results) >= 20: break
            return True, "\n".join(results) if results else "No files found"

        elif action == "email_send":
            to      = parameters.get("to", "")
            subject = parameters.get("subject", "")
            body    = parameters.get("body", "")
            if not to or not subject:
                return False, "Need 'to' and 'subject'."
            success, msg = send_email(
                to, subject, body,
                parameters.get("attachments", []),
                parameters.get("cc", ""),
                parameters.get("bcc", ""),
            )
            return success, msg

        elif action == "email_read":
            folder = parameters.get("folder", "INBOX")
            limit  = int(parameters.get("limit", 10))
            emails = read_emails(folder=folder, limit=limit)
            if not emails:
                return False, "No emails found or email not configured."
            lines = []
            for e in emails:
                lines.append(
                    f"[{e['id']}] From: {e['from']}\n"
                    f"Subject: {e['subject']}\n"
                    f"Date: {e['date']}\n"
                    f"Preview: {e['body'][:100].strip()}"
                )
            return True, "\n\n".join(lines)

        elif action == "email_search":
            query  = parameters.get("query", "")
            limit  = int(parameters.get("limit", 10))
            emails = search_emails(query, limit)
            if not emails:
                return True, f"No emails found matching '{query}'"
            return True, "\n".join(f"[{e['id']}] {e['subject']} — {e['from']}" for e in emails)

        elif action == "email_reply":
            email_id = str(parameters.get("email_id", ""))
            body     = parameters.get("body", "")
            success, msg = reply_to_email(email_id, body)
            return success, msg

        else:
            return False, f"Unknown action: {action}"

    except subprocess.TimeoutExpired:
        return False, f"Timed out after {STEP_TIMEOUT}s"
    except Exception as e:
        logger.exception(f"Tool error [{action}]: {e}")
        return False, f"Error in {action}: {e}"


# ────────────────────────── Agent loop ───────────────────────────────

AGENT_SYSTEM_PROMPT = f"""You are Salim's Office Agent v13 — an AI that autonomously creates professional documents and emails using built-in SKILL.md files.

SKILL SYSTEM: Documents are created using professional skill engines:
- DOCX → docx-js (Node.js) with Arial fonts, blue headers, proper tables with dual DXA widths
- XLSX → openpyxl with real Excel formulas (=SUM, =AVERAGE), color-coded headers, freeze panes
- PPTX → pptxgenjs with 16:9 design, dark title slides, gradient themes
- PDF  → reportlab with proper typography
- EMAIL → beautiful HTML with gradient header, styled paragraphs, plain-text fallback

AVAILABLE TOOLS (respond with JSON only):

create_document — create Word/Excel/CSV/PDF/PowerPoint using skill engines
  params: {{"type": "docx|xlsx|csv|pdf|pptx", "filename": "name.ext", "title": "Title", "content": "full markdown content"}}

read_document — read a file
  params: {{"path": "filename.ext"}}

edit_document — modify existing file
  params: {{"path": "filename.ext", "instruction": "what to change", "content": "new data"}}

delete_document — delete a file
  params: {{"path": "filename.ext"}}

convert_document — convert formats
  params: {{"from_path": "file.docx", "to_format": "pdf"}}

email_send — send beautiful HTML email with styled layout
  params: {{"to": "addr@co.com", "subject": "...", "body": "full email body text (supports **bold** *italic*)", "attachments": [], "cc": "", "bcc": ""}}

email_read — read inbox
  params: {{"folder": "INBOX", "limit": 10}}

email_search — search emails
  params: {{"query": "keyword", "limit": 10}}

email_reply — reply to email
  params: {{"email_id": "...", "body": "..."}}

shell — run terminal command
  params: {{"command": "..."}}

find_files — search for files
  params: {{"pattern": "*.docx", "directory": "~/Desktop"}}

done — task complete
  params: {{"summary": "what was accomplished and where files are saved"}}

stop — cannot proceed
  params: {{"reason": "..."}}

DOCUMENT CONTENT FORMAT (use rich markdown):
  # Main Title (H1 — navy blue in Word, large in PDF)
  ## Section Heading (H2 — steel blue in Word)
  ### Sub-section (H3 — dark gray in Word)

  Normal paragraph text with **bold** and *italic* supported

  - Bullet point (uses proper docx List Bullet style, not unicode)
  - Another bullet
  1. Numbered item
  2. Another numbered item

  | Column 1 | Column 2 | Column 3 |
  |----------|----------|----------|
  | Data     | Value    | Result   |
  | Row 2    | 1000     | 2000     |

  ---  (page break / new slide for PowerPoint)

CRITICAL RULES:
- NEVER use [placeholder], [YOUR NAME], [DATE] — fill in REAL content
- Write complete, professional, ready-to-use documents with actual data
- For invoices: include real line items, calculations, dates
- For emails: write full professional email body with greeting and sign-off
- For spreadsheets: use markdown tables — SUM formulas are auto-generated
- For presentations: each slide separated by ---
- Date today: {datetime.now().strftime('%B %d, %Y')}
- Maximum {MAX_STEPS} autonomous steps

Always respond ONLY with valid JSON:
{{"thought": "your reasoning here", "action": "tool_name", "parameters": {{...}}}}"""


def _execute_sync(action: str, params: dict) -> tuple[bool, str]:
    """Synchronous wrapper."""
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(_execute_tool(action, params))
    finally:
        loop.close()


async def run_agent(
    goal: str,
    user_id: int,
    ai_instance,
    progress_callback,
    stop_event: asyncio.Event,
    send_file_callback=None,
) -> str:
    steps_taken: list[dict] = []
    log = {"goal": goal, "started": datetime.now().isoformat(), "user_id": user_id, "steps": []}
    failures = 0
    created_files: list[Path] = []

    for step_num in range(1, MAX_STEPS + 1):
        if stop_event.is_set():
            log["stopped"] = "user_requested"; log["steps"] = steps_taken
            save_agent_log(user_id, log)
            return "⏹ Agent stopped by user."

        ctx = ""
        if steps_taken:
            ctx = "\n\nSTEPS DONE:\n"
            for i, s in enumerate(steps_taken, 1):
                ctx += f"\nStep {i}: {s['action']}({json.dumps(s['params'])[:200]})\n"
                ctx += f"Result: {'OK' if s['success'] else 'FAIL'} {s['output'][:400]}\n"

        prompt = f"GOAL: {goal}\nSTEP: {step_num}/{MAX_STEPS}\nDESKTOP: {DOCS_DIR}\n{ctx}\n\nNext action? JSON only."

        # Build personalized system prompt
        _agent_sys = AGENT_SYSTEM_PROMPT
        try:
            from salim.handlers.agent_advanced import build_personality_context
            _pctx = build_personality_context(user_id)
            if _pctx:
                _agent_sys = _agent_sys + "\n\n" + _pctx
        except Exception:
            pass

        try:
            raw, _ = await ai_instance._call_with_fallback(
                [{"role": "user", "content": prompt}],
                system=_agent_sys,
                max_tokens=1500,
                temperature=0.2,
            )
            raw = re.sub(r"```(?:json)?|```", "", raw).strip()
            plan = json.loads(raw)
        except Exception as e:
            logger.error(f"Agent AI error step {step_num}: {e}")
            failures += 1
            if failures >= 3:
                return f"⚠️ AI planning failed 3 times: {e}"
            continue

        action = plan.get("action", "stop")
        thought = plan.get("thought", "")
        params  = plan.get("parameters", {})

        if action == "done":
            summary = plan.get("summary", "Task completed.")
            log["completed"] = datetime.now().isoformat()
            log["summary"] = summary; log["steps"] = steps_taken
            save_agent_log(user_id, log)
            await progress_callback(step_num, thought, "✅ Done", summary)
            if send_file_callback:
                for fp in created_files:
                    if fp.exists():
                        try: await send_file_callback(fp)
                        except Exception as e: logger.warning(f"send file: {e}")
            return summary

        if action == "stop":
            reason = plan.get("reason", "Agent stopped.")
            log["stopped"] = reason; log["steps"] = steps_taken
            save_agent_log(user_id, log)
            await progress_callback(step_num, thought, "⏹ Stop", reason)
            return f"⏹ Stopped: {reason}"

        param_preview = ", ".join(f"{k}={str(v)[:30]}" for k,v in list(params.items())[:3])
        action_desc   = f"{action}({param_preview})"
        await progress_callback(step_num, thought, action_desc, None)

        loop = asyncio.get_event_loop()
        success, output = await loop.run_in_executor(None, _execute_sync, action, params)

        if success and action == "create_document":
            fn = params.get("filename", "")
            dt = params.get("type", "docx").lower()
            if fn:
                fp = _safe_path(fn)
                ext_map = {"docx":"docx","word":"docx","xlsx":"xlsx","excel":"xlsx",
                           "csv":"csv","pdf":"pdf","pptx":"pptx","ppt":"pptx"}
                ext = ext_map.get(dt, "docx")
                if not str(fp).endswith(f".{ext}"):
                    fp = fp.with_suffix(f".{ext}")
                if fp.exists():
                    created_files.append(fp)

        steps_taken.append({
            "step": step_num, "action": action, "params": params,
            "success": success, "output": output[:500], "thought": thought,
        })
        failures = 0 if success else failures + 1

        await progress_callback(step_num, thought, action_desc,
                                 output if success else f"❌ {output}")
        if failures >= 3:
            log["stopped"] = "too_many_failures"; log["steps"] = steps_taken
            save_agent_log(user_id, log)
            return f"⚠️ Stopped after 3 failures. Last: {output}"

        await asyncio.sleep(0.3)

    log["stopped"] = "max_steps"; log["steps"] = steps_taken
    save_agent_log(user_id, log)
    return f"⚠️ Reached {MAX_STEPS} steps. Task may be partially complete."


# ───────────────────────── Help text ─────────────────────────────────

HELP_TEXT = """🤖 <b>Salim Office Agent — Complete Guide</b>

━━━ 📄 CREATE DOCUMENTS ━━━
Type what you want to create in plain English:

<code>/agent create word invoice for ABC Company</code>
<code>/agent create excel salary sheet for 10 employees</code>
<code>/agent create csv product catalog with prices</code>
<code>/agent create pdf company profile 2025</code>
<code>/agent create powerpoint sales pitch 6 slides</code>
<code>/agent write resignation letter for Ahmed, last day April 30</code>
<code>/agent make attendance register for April 2025</code>
<code>/agent build purchase order for 10 laptops at $800 each</code>
<code>/agent create staff payroll sheet for March 2025</code>
<code>/agent write NOC letter for employee John Smith</code>
<code>/agent create employment certificate for Sarah Ahmed</code>
<code>/agent generate project budget for Phase 2 at $50,000</code>

━━━ ✏️ EDIT EXISTING FILES ━━━
<code>/agent edit report.docx add a conclusion section</code>
<code>/agent edit sales.xlsx add column for Q4 targets</code>
<code>/agent edit data.csv delete row 3</code>
<code>/agent add table to report.docx</code>
<code>/agent replace "Manager" with "Director" in letter.docx</code>
<code>/agent add row Ahmed, Sales, 5000 to staff.csv</code>

━━━ 📖 READ FILES ━━━
<code>/agent read contract.docx</code>
<code>/agent read budget.xlsx</code>
<code>/agent read employees.csv</code>

━━━ 🔄 CONVERT FILES ━━━
<code>/agent convert report.docx to pdf</code>
<code>/agent convert data.xlsx to csv</code>

━━━ 📧 EMAIL ━━━
<b>Setup (first time only):</b>
<code>/agent email setup</code>

<b>Read inbox:</b>
<code>/agent email read</code>
<code>/agent email read 20</code>  ← get 20 emails

<b>Send email:</b>
<code>/agent email send to boss@co.com subject Monthly Report body Please see attached</code>
<code>/agent email send to hr@co.com subject Leave Request body I need 3 days from April 5</code>

<b>Send with attachment:</b>
<code>/agent email send to ceo@co.com subject Q1 Results body See report attach report.xlsx</code>

<b>Search:</b>
<code>/agent email search invoice</code>
<code>/agent email search from Ahmed</code>

<b>Reply:</b>
<code>/agent email reply to 42 Thank you, I will review and respond by Friday</code>
(Get email ID numbers from /agent email read)

━━━ ⚙️ AGENT CONTROLS ━━━
<code>/agentstop</code>    — stop current task immediately
<code>/agentstatus</code>  — check if something is running
<code>/agentlog</code>     — see what happened in last task
<code>/agenthelp</code>    — show this guide

<i>📁 All files are saved to your Desktop and sent to you here automatically.</i>"""


# ───────────────────────── Telegram Handlers ─────────────────────────

class AgentHandlers:
    """Mixin for SalimBot — adds office agent commands."""

    @require_auth
    async def cmd_agenthelp(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show full agent guide."""
        await update.effective_message.reply_text(HELP_TEXT, parse_mode="HTML")

    @require_auth
    async def cmd_agent(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/agent <goal> — run any office task."""
        msg     = update.effective_message
        user_id = update.effective_user.id
        goal    = " ".join(ctx.args) if ctx.args else ""

        if goal.strip().lower() in ("email setup", "setup email"):
            await self._email_setup_guide(msg); return

        if not goal:
            await msg.reply_text(
                "🤖 <b>Salim Office Agent</b>\n\n"
                "I create, edit, read and send documents and emails for you.\n\n"
                "<b>Examples:</b>\n"
                "• <code>/agent create word Q1 sales report</code>\n"
                "• <code>/agent create excel invoice for ABC Corp</code>\n"
                "• <code>/agent write resignation letter for Ahmed</code>\n"
                "• <code>/agent email read</code>\n"
                "• <code>/agent email send to boss@co.com subject Update body Done</code>\n\n"
                "📖 Full guide: <code>/agenthelp</code>",
                parse_mode="HTML"
            ); return

        if not self._ai.is_configured():
            await msg.reply_text(
                "⚠️ AI not configured.\n"
                "Run <code>salim setup</code> to add an API key.",
                parse_mode="HTML"
            ); return

        # Email shortcut
        if goal.lower().startswith("email "):
            await self._handle_email_cmd(msg, goal[6:].strip(), user_id); return

        # Stop existing agent
        if user_id in _active_agents and not _active_agents[user_id].done():
            _active_agents[user_id].cancel()
            await asyncio.sleep(0.1)

        progress_msg = await msg.reply_text(
            f"🤖 <b>Agent starting…</b>\n\n"
            f"🎯 Goal: <i>{_esc(goal[:120])}</i>\n\n"
            f"<i>Planning first step…</i>",
            parse_mode="HTML"
        )

        step_log: list[dict] = []
        stop_event = asyncio.Event()
        self._agent_stop_events = getattr(self, "_agent_stop_events", {})
        self._agent_stop_events[user_id] = stop_event

        # ── Action icons for display ──────────────────────────────────────────
        ACTION_ICONS = {
            "create_document": "📄", "read_document": "📖", "edit_document": "✏️",
            "delete_document": "🗑️", "email_send": "📧", "email_read": "📬",
            "email_search": "🔍", "email_reply": "↩️", "shell": "💻",
            "find_files": "🔎", "convert_document": "🔄", "done": "✅", "stop": "⏹",
        }

        async def progress_callback(step_num: int, thought: str, action_desc: str, result):
            action_name = action_desc.split("(")[0].strip() if "(" in action_desc else action_desc
            icon = ACTION_ICONS.get(action_name, "⚙️")
            step_log.append({
                "step": step_num,
                "thought": (thought or "")[:120],
                "action": action_desc,
                "icon": icon,
                "result": str(result)[:250] if result is not None else None,
            })

            # ── Rich step-by-step Telegram UI ─────────────────────────────────
            lines = [
                "🤖 <b>Salim Agent — Working</b>",
                f"🎯 <b>Goal:</b> <i>{_esc(goal[:90])}</i>",
                f"📊 Step {step_num}/{MAX_STEPS}",
                "─" * 30,
                "",
            ]

            for entry in step_log[-8:]:
                s    = entry["step"]
                act  = _esc(entry.get("action", "")[:60])
                res  = entry.get("result")
                thgt = _esc((entry.get("thought") or "")[:80])
                ico  = entry.get("icon", "⚙️")
                
                if res is None:
                    status_icon = "⏳"
                elif str(res).startswith("❌") or "Error" in str(res) or "failed" in str(res).lower():
                    status_icon = "❌"
                else:
                    status_icon = "✅"

                lines.append(f"{status_icon} {ico} <b>Step {s}:</b> <code>{act}</code>")
                if thgt:
                    lines.append(f"   💭 <i>{thgt}</i>")
                if res and res != "None":
                    # Show result preview — truncate long outputs
                    res_preview = _esc(str(res)[:120])
                    if len(str(res)) > 120:
                        res_preview += "…"
                    lines.append(f"   📤 <code>{res_preview}</code>")
                lines.append("")

            if result is None:
                lines.append(f"⏳ <i>Executing step {step_num}…</i>")
            
            lines.append(f"\n<i>Type /agentstop to cancel</i>")
            try:
                await progress_msg.edit_text("\n".join(lines), parse_mode="HTML")
            except Exception:
                pass

        async def send_file_callback(fp: Path):
            try:
                with open(str(fp), "rb") as f:
                    await msg.reply_document(
                        document=f, filename=fp.name,
                        caption=f"📎 <b>{_esc(fp.name)}</b>",
                        parse_mode="HTML"
                    )
            except Exception as e:
                logger.warning(f"Send file {fp.name}: {e}")

        async def agent_task():
            try:
                summary = await run_agent(
                    goal=goal, user_id=user_id, ai_instance=self._ai,
                    progress_callback=progress_callback, stop_event=stop_event,
                    send_file_callback=send_file_callback,
                )
                total = len(step_log)
                final = [
                    "🤖 <b>Agent Complete</b>",
                    f"🎯 <i>{_esc(goal[:80])}</i>", "",
                    f"📊 {total} step{'s' if total != 1 else ''} executed", "",
                    "📝 <b>Summary:</b>", _esc(summary), "",
                    "<i>Use /agentlog for full details · /agenthelp for guide</i>",
                ]
                await progress_msg.edit_text("\n".join(final), parse_mode="HTML")
            except asyncio.CancelledError:
                await progress_msg.edit_text(
                    f"⏹ <b>Agent stopped</b>\n🎯 <i>{_esc(goal[:80])}</i>",
                    parse_mode="HTML"
                )
            except Exception as e:
                await progress_msg.edit_text(
                    f"⚠️ <b>Agent error:</b> {_esc(str(e)[:300])}",
                    parse_mode="HTML"
                )
            finally:
                _active_agents.pop(user_id, None)

        task = asyncio.create_task(agent_task())
        _active_agents[user_id] = task

    async def _handle_email_cmd(self, msg, sub: str, user_id: int):
        """Handle /agent email <sub> directly."""
        sl = sub.lower()

        if sl in ("setup", "configure", "config"):
            await self._email_setup_guide(msg); return

        if sl.startswith("read") or sl.startswith("inbox"):
            limit = 10
            for part in sl.split():
                if part.isdigit(): limit = int(part); break
            await msg.reply_text("📬 Reading inbox…")
            emails = read_emails(limit=limit)
            if not emails:
                cfg = load_email_config()
                if not cfg:
                    await msg.reply_text(
                        "⚠️ Email not configured yet.\n\n"
                        "Run: <code>/agent email setup</code>",
                        parse_mode="HTML"
                    )
                else:
                    await msg.reply_text("📭 No emails found in inbox.")
                return
            lines = [f"📬 <b>Inbox — {len(emails)} email(s)</b>\n"]
            for e in emails:
                lines.append(
                    f"📧 <b>[ID:{e['id']}]</b> {_esc(e['subject'])}\n"
                    f"   From: <i>{_esc(e['from'])}</i> · {_esc(e['date'])}\n"
                    f"   <code>{_esc(e['body'][:80].strip())}</code>"
                )
            await msg.reply_text("\n\n".join(lines), parse_mode="HTML"); return

        if sl.startswith("search "):
            query = sub[7:].strip()
            await msg.reply_text(f"🔍 Searching for: <i>{_esc(query)}</i>…", parse_mode="HTML")
            emails = search_emails(query)
            if not emails:
                await msg.reply_text(f"📭 No emails found for '{_esc(query)}'.", parse_mode="HTML")
                return
            lines = [f"🔍 <b>{len(emails)} result(s) for '{_esc(query)}'</b>\n"]
            for e in emails:
                lines.append(f"[{e['id']}] <b>{_esc(e['subject'])}</b> — {_esc(e['from'])}")
            await msg.reply_text("\n".join(lines), parse_mode="HTML"); return

        if sl.startswith("send"):
            to_m   = re.search(r"to\s+([\w._%+\-]+@[\w.\-]+\.[a-zA-Z]{2,})", sub, re.I)
            subj_m = re.search(r"subject\s+(.+?)(?:\s+body\s|\s+attach\s|$)", sub, re.I)
            body_m = re.search(r"body\s+(.+?)(?:\s+attach\s|$)", sub, re.I | re.DOTALL)
            att_m  = re.search(r"attach\s+(.+?)$", sub, re.I)
            to     = to_m.group(1) if to_m else ""
            subject = subj_m.group(1).strip() if subj_m else "(no subject)"
            body    = body_m.group(1).strip() if body_m else ""
            attachments = [att_m.group(1).strip()] if att_m else []
            if not to:
                await msg.reply_text(
                    "❌ Recipient missing.\n"
                    "Example: <code>/agent email send to boss@co.com subject Update body Done</code>",
                    parse_mode="HTML"
                ); return
            await msg.reply_text(f"📤 Sending to <code>{_esc(to)}</code>…", parse_mode="HTML")
            ok, result = send_email(to, subject, body, attachments)
            if ok:
                await msg.reply_text(
                    f"✅ <b>Email sent!</b>\nTo: <code>{_esc(to)}</code>\nSubject: <i>{_esc(subject)}</i>",
                    parse_mode="HTML"
                )
            else:
                await msg.reply_text(f"❌ Failed: {_esc(result)}", parse_mode="HTML")
            return

        if sl.startswith("reply"):
            m = re.search(r"reply\s+(?:to\s+)?(\d+)\s+(.+)", sub, re.I | re.DOTALL)
            if not m:
                await msg.reply_text(
                    "Usage: <code>/agent email reply to &lt;ID&gt; &lt;your message&gt;</code>\n"
                    "Get IDs from: <code>/agent email read</code>",
                    parse_mode="HTML"
                ); return
            email_id, reply_body = m.group(1), m.group(2).strip()
            await msg.reply_text(f"↩️ Replying to email {email_id}…")
            ok, result = reply_to_email(email_id, reply_body)
            if ok:
                await msg.reply_text(f"✅ Reply sent to email {email_id}.")
            else:
                await msg.reply_text(f"❌ Failed: {_esc(result)}", parse_mode="HTML")
            return

        await msg.reply_text(
            "📧 <b>Email Commands:</b>\n\n"
            "<code>/agent email setup</code> — connect your email account\n"
            "<code>/agent email read</code> — read inbox\n"
            "<code>/agent email search &lt;keyword&gt;</code> — search\n"
            "<code>/agent email send to addr subject ... body ...</code> — send\n"
            "<code>/agent email reply to &lt;id&gt; &lt;message&gt;</code> — reply",
            parse_mode="HTML"
        )

    async def _email_setup_guide(self, msg):
        """Show step-by-step email setup instructions."""
        cfg = load_email_config()
        current = ""
        if cfg:
            current = (
                f"\n\n<b>⚙️ Current config:</b>\n"
                f"SMTP: {_esc(cfg.get('smtp_host',''))}:{cfg.get('smtp_port','')}\n"
                f"IMAP: {_esc(cfg.get('imap_host',''))}\n"
                f"User: {_esc(cfg.get('username',''))}"
            )

        await msg.reply_text(
            "📧 <b>Email Setup — Step by Step</b>\n\n"
            "<b>Step 1:</b> Open a terminal on your laptop\n\n"
            "<b>Step 2:</b> Run this command (replace with your details):\n\n"
            "<code>python3 -c \"\nimport json, pathlib\n"
            "cfg = {\n"
            "  'smtp_host': 'smtp.gmail.com',\n"
            "  'smtp_port': 587,\n"
            "  'imap_host': 'imap.gmail.com',\n"
            "  'username': 'you@gmail.com',\n"
            "  'password': 'your-app-password',\n"
            "  'sender': 'Your Name &lt;you@gmail.com&gt;'\n"
            "}\n"
            "p = pathlib.Path.home()/'.salim'/'email_config.json'\n"
            "p.parent.mkdir(exist_ok=True)\n"
            "p.write_text(json.dumps(cfg, indent=2))\n"
            "p.chmod(0o600)\n"
            "print('Done!')\n\"</code>\n\n"
            "<b>For Gmail users:</b>\n"
            "1. Go to myaccount.google.com → Security\n"
            "2. Turn on 2-Step Verification\n"
            "3. Go to App passwords → create one for Mail\n"
            "4. Use that 16-character password in the command above\n\n"
            "<b>For Outlook / Office 365:</b>\n"
            "• smtp_host: <code>smtp.office365.com</code>\n"
            "• imap_host: <code>outlook.office365.com</code>\n\n"
            "<b>For Yahoo Mail:</b>\n"
            "• smtp_host: <code>smtp.mail.yahoo.com</code>\n"
            "• imap_host: <code>imap.mail.yahoo.com</code>" + current,
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_agentstop(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Stop a running agent."""
        uid = update.effective_user.id
        stop_events = getattr(self, "_agent_stop_events", {})
        if uid in stop_events:
            stop_events[uid].set()
        if uid in _active_agents and not _active_agents[uid].done():
            _active_agents[uid].cancel()
            await update.effective_message.reply_text("⏹ Agent stopped.")
        else:
            await update.effective_message.reply_text("ℹ️ No agent is running right now.")

    @require_auth
    async def cmd_agentstatus(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Check if agent is running."""
        uid = update.effective_user.id
        if uid in _active_agents and not _active_agents[uid].done():
            await update.effective_message.reply_text(
                "🤖 <b>Agent is running.</b>\n\n"
                "Use <code>/agentstop</code> to cancel it at any time.",
                parse_mode="HTML"
            )
        else:
            await update.effective_message.reply_text(
                "✅ No agent running.\n\n"
                "Start one with: <code>/agent your task here</code>",
                parse_mode="HTML"
            )

    @require_auth
    async def cmd_agentlog(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show last agent run log."""
        uid = update.effective_user.id
        log = load_agent_log(uid)
        if not log:
            await update.effective_message.reply_text(
                "📋 No agent runs recorded yet.\n\n"
                "Try: <code>/agent create word report on company status</code>",
                parse_mode="HTML"
            ); return

        lines = [
            "📋 <b>Last Agent Run</b>",
            f"🎯 Goal: <i>{_esc(log.get('goal','?'))}</i>",
            f"⏰ Started: {_esc(str(log.get('started','?'))[:16])}",
        ]
        if log.get("completed"):
            lines.append(f"✅ Completed: {_esc(str(log['completed'])[:16])}")
        if log.get("summary"):
            lines += ["", f"📝 <b>Summary:</b> {_esc(log['summary'])}"]
        if log.get("stopped"):
            lines += ["", f"⏹ Stopped: {_esc(str(log['stopped']))}"]

        steps = log.get("steps", [])
        if steps:
            lines += ["", f"<b>Steps ({len(steps)}):</b>"]
            for s in steps[-10:]:
                icon = "✅" if s.get("success") else "❌"
                lines.append(
                    f"{icon} <b>Step {s['step']}:</b> {_esc(str(s.get('action','?')))}"
                    f" → {_esc(str(s.get('output',''))[:80])}"
                )

        await update.effective_message.reply_text("\n".join(lines), parse_mode="HTML")
