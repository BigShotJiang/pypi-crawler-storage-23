"""
Salim Speed Test Handler v2 — Internet Speed with History & Alerts

Improvements over v1:
  - History tracking: /speedhistory — see last 20 tests
  - Threshold alerts: /speedalert 50 — alert if speed drops below 50 Mbps
  - Scheduled tests: /speedschedule every 1 hour
  - Average vs current comparison
  - ASCII trend chart
  - Uses speedtest-cli (free, open source)

Auto-installed: speedtest-cli>=2.1 (already in deps), APScheduler>=3.10

Commands:
  /speedtest               — run internet speed test
  /speedhistory            — show last 20 results + trend
  /speedalert <mbps>       — alert when speed drops below threshold
  /speedschedule <N> <unit>— schedule recurring test (e.g. every 1 hour)
  /speedunschedule         — stop scheduled tests
"""
from __future__ import annotations

import asyncio
import json
import logging
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.auto_install import ensure_one

logger = logging.getLogger(__name__)

SPEED_HISTORY = Path.home() / ".salim" / "speedtest_history.json"
SPEED_CFG     = Path.home() / ".salim" / "speedtest_config.json"
SCHED_JOB_ID  = "speedtest_auto"


def _ensure_speedtest():
    return ensure_one("speedtest", "speedtest-cli>=2.1")


def _load_history() -> list[dict]:
    if SPEED_HISTORY.exists():
        try: return json.loads(SPEED_HISTORY.read_text())
        except Exception: pass
    return []


def _save_history(items: list[dict]):
    SPEED_HISTORY.parent.mkdir(parents=True, exist_ok=True)
    SPEED_HISTORY.write_text(json.dumps(items[-50:], indent=2))  # Keep last 50


def _load_cfg() -> dict:
    if SPEED_CFG.exists():
        try: return json.loads(SPEED_CFG.read_text())
        except Exception: pass
    return {}


def _save_cfg(cfg: dict):
    SPEED_CFG.parent.mkdir(parents=True, exist_ok=True)
    SPEED_CFG.write_text(json.dumps(cfg, indent=2))


def _run_speedtest_sync() -> dict:
    import speedtest as st
    s = st.Speedtest(secure=True)
    s.get_best_server()
    s.download(threads=4)
    s.upload(threads=4)
    r = s.results.dict()
    return {
        "ts":       datetime.now().isoformat(timespec="minutes"),
        "download": round(r["download"] / 1_000_000, 2),
        "upload":   round(r["upload"] / 1_000_000, 2),
        "ping":     round(r["ping"], 1),
        "isp":      r.get("client", {}).get("isp", "?"),
        "server":   r.get("server", {}).get("name", "?"),
        "country":  r.get("server", {}).get("country", ""),
    }


def _format_result(r: dict, avg_down: float | None = None) -> str:
    d = r["download"]; u = r["upload"]; p = r["ping"]
    ed = "🚀" if d > 100 else "✅" if d > 25 else "🐢"
    eu = "🚀" if u > 50  else "✅" if u > 10  else "🐢"
    ep = "⚡" if p < 20  else "✅" if p < 80  else "🐌"
    avg_str = ""
    if avg_down is not None:
        diff = d - avg_down
        sign = "+" if diff >= 0 else ""
        avg_str = f"  <i>({sign}{diff:.1f} vs avg)</i>"
    return (
        f"<b>🌐 Speed Test Results</b>\n\n"
        f"{ed} <b>Download:</b> {d:.1f} Mbps{avg_str}\n"
        f"{eu} <b>Upload:</b>   {u:.1f} Mbps\n"
        f"{ep} <b>Ping:</b>     {p:.0f} ms\n\n"
        f"📡 <b>Server:</b> {r['server']} {r['country']}\n"
        f"🏢 <b>ISP:</b>    {r['isp']}\n"
        f"🕐 {r['ts']}"
    )


def _ascii_trend(history: list[dict], key: str = "download", width: int = 20) -> str:
    """Simple ASCII bar chart for speed history."""
    vals = [h[key] for h in history[-width:]]
    if not vals:
        return ""
    vmax = max(vals) or 1
    lines = [f"📈 {key.title()} trend (last {len(vals)} tests):"]
    for v in vals:
        bar_len = max(1, int(v / vmax * 15))
        bar = "█" * bar_len
        lines.append(f"  {bar} {v:.0f}")
    lines.append(f"  Min: {min(vals):.0f}  Max: {max(vals):.0f}  Avg: {sum(vals)/len(vals):.0f} Mbps")
    return "\n".join(lines)


async def _run_and_notify(bot, chat_id: int, alert_threshold: float | None = None):
    """Run speed test and send result. Called by scheduler."""
    try:
        loop   = asyncio.get_event_loop()
        result = await loop.run_in_executor(None, _run_speedtest_sync)
        history = _load_history()
        avgs    = [h["download"] for h in history[-10:]]
        avg_down = sum(avgs) / len(avgs) if avgs else None
        history.append(result)
        _save_history(history)

        text = _format_result(result, avg_down)

        if alert_threshold and result["download"] < alert_threshold:
            text = f"🚨 <b>Speed Alert!</b> Download {result['download']:.1f} Mbps < threshold {alert_threshold:.0f} Mbps\n\n" + text

        await bot.send_message(chat_id=chat_id, text=text, parse_mode="HTML")
    except Exception as e:
        await bot.send_message(chat_id=chat_id, text=f"❌ Speed test failed: {e}")


class SpeedTestHandlers:

    @require_auth
    async def cmd_speedtest(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Run an internet speed test."""
        msg = await update.effective_message.reply_text("🌐 Running speed test… (~15s)")

        if not _ensure_speedtest():
            await msg.edit_text("❌ speedtest-cli could not be installed. Run: pip install speedtest-cli")
            return

        try:
            loop   = asyncio.get_event_loop()
            result = await loop.run_in_executor(None, _run_speedtest_sync)

            history  = _load_history()
            avgs     = [h["download"] for h in history[-10:]]
            avg_down = sum(avgs) / len(avgs) if avgs else None
            history.append(result)
            _save_history(history)

            text = _format_result(result, avg_down)

            # Check alert threshold
            cfg       = _load_cfg()
            threshold = cfg.get("alert_threshold")
            if threshold and result["download"] < threshold:
                text = f"🚨 <b>Speed Alert!</b> {result['download']:.1f} Mbps below {threshold:.0f} Mbps threshold!\n\n" + text

            await msg.edit_text(text, parse_mode="HTML")
        except Exception as e:
            await msg.edit_text(f"❌ Speed test failed: {e}")

    @require_auth
    async def cmd_speedhistory(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show speed test history and trend chart. /speedhistory"""
        history = _load_history()
        if not history:
            await update.effective_message.reply_text(
                "📭 No speed test history yet.\n\nRun <code>/speedtest</code> first.",
                parse_mode="HTML"
            )
            return

        recent = history[-20:]
        downs  = [h["download"] for h in recent]
        ups    = [h["upload"]   for h in recent]
        pings  = [h["ping"]     for h in recent]

        lines = [
            f"📊 <b>Speed History ({len(history)} tests)</b>\n",
            f"📥 Download: avg {sum(downs)/len(downs):.1f}  min {min(downs):.1f}  max {max(downs):.1f} Mbps",
            f"📤 Upload:   avg {sum(ups)/len(ups):.1f}  min {min(ups):.1f}  max {max(ups):.1f} Mbps",
            f"📡 Ping:     avg {sum(pings)/len(pings):.0f}  min {min(pings):.0f}  max {max(pings):.0f} ms",
            "",
            _ascii_trend(recent, "download"),
            "",
            "<b>Last 5 tests:</b>",
        ]
        for r in recent[-5:]:
            lines.append(
                f"  {r['ts']}  ↓{r['download']:.0f}  ↑{r['upload']:.0f}  📡{r['ping']:.0f}ms"
            )

        await update.effective_message.reply_text("\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_speedalert(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Set speed alert threshold. /speedalert <mbps> or /speedalert off"""
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            cfg = _load_cfg()
            t   = cfg.get("alert_threshold")
            if t:
                await msg.reply_text(f"🔔 Alert threshold: <b>{t} Mbps</b>\nDisable: <code>/speedalert off</code>", parse_mode="HTML")
            else:
                await msg.reply_text("No alert set.\nUsage: <code>/speedalert 50</code>", parse_mode="HTML")
            return

        if args[0].lower() == "off":
            cfg = _load_cfg()
            cfg.pop("alert_threshold", None)
            _save_cfg(cfg)
            await msg.reply_text("🔕 Speed alert disabled.")
            return

        try:
            threshold = float(args[0])
        except ValueError:
            await msg.reply_text("❌ Invalid threshold. Use a number in Mbps.")
            return

        cfg = _load_cfg()
        cfg["alert_threshold"] = threshold
        _save_cfg(cfg)
        await msg.reply_text(
            f"🔔 <b>Alert set</b>\nI'll warn you when download speed drops below <b>{threshold} Mbps</b>.",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_speedschedule(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Schedule recurring speed tests. /speedschedule every 1 hour"""
        msg     = update.effective_message
        user_id = update.effective_user.id
        args    = ctx.args or []

        if not args:
            await msg.reply_text(
                "Usage: <code>/speedschedule &lt;N&gt; &lt;min|hour|day&gt;</code>\n"
                "Example: <code>/speedschedule 1 hour</code>",
                parse_mode="HTML"
            )
            return

        if args[0].lower() == "off":
            await self._stop_speed_schedule(msg)
            return

        try:
            n    = int(args[0])
            unit = args[1].lower() if len(args) > 1 else "hour"
        except Exception:
            await msg.reply_text("❌ Invalid syntax.")
            return

        unit_secs = {"min":60,"mins":60,"minute":60,"minutes":60,
                     "hour":3600,"hours":3600,"hr":3600,
                     "day":86400,"days":86400}
        if unit not in unit_secs:
            await msg.reply_text(f"❌ Unknown unit: {unit}")
            return

        interval = n * unit_secs[unit]
        cfg      = _load_cfg()
        threshold = cfg.get("alert_threshold")
        chat_id  = update.effective_chat.id

        from salim.handlers.scheduler_handler import _get_scheduler
        sched = _get_scheduler()
        if not sched:
            await msg.reply_text("❌ APScheduler unavailable. Run: pip install APScheduler>=3.10")
            return

        from apscheduler.triggers.interval import IntervalTrigger
        jid = f"speedtest_{user_id}"
        sched.add_job(
            _run_and_notify,
            IntervalTrigger(seconds=interval),
            id=jid,
            args=[None, chat_id, threshold],  # bot passed via global
            replace_existing=True,
        )
        # Store job id in config
        cfg["schedule_job_id"] = jid
        cfg["schedule_interval"] = interval
        _save_cfg(cfg)

        await msg.reply_text(
            f"⏱ <b>Speed tests scheduled</b>\n"
            f"Every {n} {unit}  ·  Stop: <code>/speedschedule off</code>",
            parse_mode="HTML"
        )

    async def _stop_speed_schedule(self, msg):
        cfg = _load_cfg()
        jid = cfg.get("schedule_job_id")
        if jid:
            from salim.handlers.scheduler_handler import _get_scheduler
            sched = _get_scheduler()
            if sched:
                try: sched.remove_job(jid)
                except Exception: pass
            cfg.pop("schedule_job_id", None)
            cfg.pop("schedule_interval", None)
            _save_cfg(cfg)
        await msg.reply_text("🔕 Scheduled speed tests stopped.")
