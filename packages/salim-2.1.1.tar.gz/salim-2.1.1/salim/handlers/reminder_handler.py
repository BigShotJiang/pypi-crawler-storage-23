"""
Salim Reminder Handler v2 — Advanced reminders with real persistence & snooze.

Improvements over v1:
  - APScheduler with SQLite job store: reminders survive bot restarts
  - Timezone-aware: fires at user's local time (reads from /memory)
  - Proper recurring: every Monday, weekdays, every 2 hours, etc.
  - Snooze via inline buttons (5min, 15min, 1hr, tomorrow)
  - Undo: /remdel can undo within 30s
  - Natural language parsing via dateparser (auto-installed)
  - Shows countdown: "fires in 2h 15m"

Auto-installed: apscheduler>=3.10, dateparser>=1.2, pytz>=2024.1

Commands:
  /remind me to call John in 2 hours
  /remind take medicine every day at 8am
  /remind meeting tomorrow at 3pm
  /remind standup every weekday at 9:30am
  /reminders                      — list all upcoming
  /remdel <id>                    — delete a reminder
  /remclear                       — clear all your reminders
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
from datetime import datetime, timedelta
from pathlib import Path

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, Bot
from telegram.ext import ContextTypes, CallbackQueryHandler

from salim.auth import require_auth
from salim.auto_install import ensure_one

logger = logging.getLogger("salim.reminders")

REMINDERS_DB  = Path.home() / ".salim" / "reminders_v2.db"
REMINDERS_JSON = Path.home() / ".salim" / "reminders.json"

_scheduler = None
_bot_ref: Bot | None = None


def _ensure_deps() -> bool:
    ok1 = ensure_one("apscheduler", "APScheduler>=3.10")
    ok2 = ensure_one("dateparser", "dateparser>=1.2")
    ok3 = ensure_one("pytz", "pytz>=2024.1")
    return ok1 and ok2 and ok3


def _get_scheduler():
    global _scheduler
    if _scheduler is not None:
        return _scheduler
    if not _ensure_deps():
        return None
    from apscheduler.schedulers.asyncio import AsyncIOScheduler
    from apscheduler.jobstores.sqlalchemy import SQLAlchemyJobStore

    REMINDERS_DB.parent.mkdir(parents=True, exist_ok=True)
    jobstores = {
        "default": SQLAlchemyJobStore(url=f"sqlite:///{REMINDERS_DB}")
    }
    _scheduler = AsyncIOScheduler(jobstores=jobstores)
    if not _scheduler.running:
        _scheduler.start()
    return _scheduler


# ── Natural language time parsing ─────────────────────────────────────────────

def _parse_time(text: str, user_tz: str = "UTC") -> tuple[datetime | None, bool, str, str | None]:
    """
    Parse natural language time from reminder text.
    Returns (when, is_recurring, cleaned_label, cron_str_or_None).
    """
    try:
        import pytz
        tz = pytz.timezone(user_tz)
    except Exception:
        import pytz
        tz = pytz.UTC

    now = datetime.now(tz)
    text_orig = text
    text_lower = text.lower().strip()
    is_recurring = False
    cron_str = None

    # ── Recurring patterns ────────────────────────────────────────────────────
    # "every weekday at 9am"
    weekday_m = re.search(
        r"every\s+weekday(?:\s+at\s+([\d:]+\s*(?:am|pm)?))?", text_lower
    )
    if weekday_m:
        is_recurring = True
        time_str = weekday_m.group(1) or "09:00"
        h, mn = _parse_hhmm(time_str)
        cron_str = f"{mn} {h} * * 1-5"
        when = _next_cron(cron_str, now)
        label = re.sub(weekday_m.re, "", text_orig, flags=re.IGNORECASE).strip()
        label = _clean_label(label)
        return when, True, label, cron_str

    # "every Monday at 10am" / "every Monday"
    dow_m = re.search(
        r"every\s+(monday|tuesday|wednesday|thursday|friday|saturday|sunday)"
        r"(?:\s+at\s+([\d:]+\s*(?:am|pm)?))?", text_lower
    )
    if dow_m:
        is_recurring = True
        day_name = dow_m.group(1)
        DOW = {"monday":0,"tuesday":1,"wednesday":2,"thursday":3,
               "friday":4,"saturday":5,"sunday":6}
        dow_num = DOW[day_name]
        time_str = dow_m.group(2) or "09:00"
        h, mn = _parse_hhmm(time_str)
        cron_str = f"{mn} {h} * * {dow_num}"
        when = _next_cron(cron_str, now)
        label = re.sub(dow_m.re, "", text_orig, flags=re.IGNORECASE).strip()
        label = _clean_label(label)
        return when, True, label, cron_str

    # "every N minutes/hours/days"
    recur_m = re.search(
        r"every\s+(?:(\d+)\s+)?(minute|hour|day|week|month)s?"
        r"(?:\s+at\s+([\d:]+\s*(?:am|pm)?))?",
        text_lower
    )
    if recur_m:
        is_recurring = True
        amount = int(recur_m.group(1) or 1)
        unit   = recur_m.group(2)
        time_str = recur_m.group(3)
        unit_map = {"minute": amount, "hour": amount * 60,
                    "day": amount * 1440, "week": amount * 10080}
        interval_mins = unit_map.get(unit, 1440)
        if unit in ("day", "week") and time_str:
            h, mn = _parse_hhmm(time_str)
            if unit == "day":
                cron_str = f"{mn} {h} * * *"
            else:
                cron_str = f"{mn} {h} * * 0"
            when = _next_cron(cron_str, now)
        else:
            when = now + timedelta(minutes=interval_mins)
            cron_str = f"interval:{interval_mins}"
        label = re.sub(recur_m.re, "", text_orig, flags=re.IGNORECASE).strip()
        label = _clean_label(label)
        return when, True, label, cron_str

    # ── One-shot via dateparser ────────────────────────────────────────────────
    try:
        import dateparser
        settings = {
            "PREFER_DATES_FROM": "future",
            "RETURN_AS_TIMEZONE_AWARE": True,
            "TIMEZONE": user_tz,
        }
        # Strip command words before parsing
        clean = re.sub(r"^(remind\s+)?(me\s+to|to)\s+", "", text_lower, flags=re.I).strip()
        # Try to extract time phrase
        time_phrases = re.findall(
            r"(?:in\s+[\d\w\s]+|at\s+[\d:]+\s*(?:am|pm)?|tomorrow|next\s+\w+|tonight|today)", clean
        )
        for phrase in time_phrases:
            parsed = dateparser.parse(phrase, settings=settings)
            if parsed and parsed > now:
                label = re.sub(re.escape(phrase), "", text_orig, flags=re.I).strip()
                label = _clean_label(label)
                return parsed, False, label or text_orig, None
        # Try full string
        parsed = dateparser.parse(clean, settings=settings)
        if parsed and parsed > now:
            return parsed, False, text_orig, None
    except Exception as e:
        logger.debug(f"dateparser failed: {e}")

    # ── Fallback regex ─────────────────────────────────────────────────────────
    in_m = re.search(r"in\s+(\d+)\s+(minute|hour|day|week)s?", text_lower)
    if in_m:
        amount = int(in_m.group(1))
        unit = in_m.group(2)
        delta = {"minute": timedelta(minutes=amount), "hour": timedelta(hours=amount),
                 "day": timedelta(days=amount), "week": timedelta(weeks=amount)}
        when = now + delta[unit]
        label = re.sub(in_m.re, "", text_orig, flags=re.I).strip()
        return when, False, _clean_label(label), None

    at_m = re.search(r"at\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", text_lower, re.I)
    if at_m:
        h = int(at_m.group(1)); mn = int(at_m.group(2) or 0)
        ap = (at_m.group(3) or "").lower()
        if ap == "pm" and h < 12: h += 12
        elif ap == "am" and h == 12: h = 0
        when = now.replace(hour=h, minute=mn, second=0, microsecond=0)
        if "tomorrow" in text_lower:
            when += timedelta(days=1)
        elif when <= now:
            when += timedelta(days=1)
        label = re.sub(at_m.re, "", text_orig, flags=re.I).strip()
        if "tomorrow" in label.lower():
            label = re.sub(r"\btomorrow\b", "", label, flags=re.I).strip()
        return when, False, _clean_label(label), None

    return None, False, text_orig, None


def _parse_hhmm(time_str: str) -> tuple[int, int]:
    """Parse '9am', '9:30am', '14:00' → (hour, minute)."""
    m = re.match(r"(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", time_str.strip(), re.I)
    if not m:
        return 9, 0
    h = int(m.group(1)); mn = int(m.group(2) or 0)
    ap = (m.group(3) or "").lower()
    if ap == "pm" and h < 12: h += 12
    elif ap == "am" and h == 12: h = 0
    return h, mn


def _clean_label(text: str) -> str:
    """Remove leading filler words from reminder label."""
    text = re.sub(r"^(remind\s+)?(me\s+to|to)\s+", "", text.strip(), flags=re.I)
    text = re.sub(r"\s+", " ", text).strip(" ,.")
    return text or "Reminder"


def _next_cron(cron_str: str, after: datetime) -> datetime:
    """Get next run time for a cron string."""
    try:
        from apscheduler.triggers.cron import CronTrigger
        parts = cron_str.split()
        trigger = CronTrigger(
            minute=parts[0], hour=parts[1],
            day=parts[2], month=parts[3], day_of_week=parts[4]
        )
        return trigger.get_next_fire_time(None, after)
    except Exception:
        return after + timedelta(days=1)


# ── Snooze keyboard ───────────────────────────────────────────────────────────

def _snooze_keyboard(rid: str) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("⏱ 5m",   callback_data=f"snooze:{rid}:5"),
        InlineKeyboardButton("⏱ 15m",  callback_data=f"snooze:{rid}:15"),
        InlineKeyboardButton("⏱ 1h",   callback_data=f"snooze:{rid}:60"),
        InlineKeyboardButton("🌅 Tomorrow", callback_data=f"snooze:{rid}:1440"),
        InlineKeyboardButton("✅ Done",  callback_data=f"snooze:{rid}:0"),
    ]])


# ── APScheduler job functions ─────────────────────────────────────────────────

async def _fire_reminder(user_id: int, label: str, rid: str):
    """Called by APScheduler when a reminder fires."""
    global _bot_ref
    if _bot_ref is None:
        return
    try:
        await _bot_ref.send_message(
            chat_id=user_id,
            text=f"⏰ <b>Reminder!</b>\n\n📝 {label}",
            parse_mode="HTML",
            reply_markup=_snooze_keyboard(rid),
        )
    except Exception as e:
        logger.error(f"Reminder fire error {rid}: {e}")


# ── Simple JSON fallback store ────────────────────────────────────────────────
# Used to list/delete reminders by user (APScheduler doesn't filter by user easily)

def _meta_file() -> Path:
    p = Path.home() / ".salim" / "reminders_meta.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _load_meta() -> list[dict]:
    f = _meta_file()
    if f.exists():
        try: return json.loads(f.read_text())
        except Exception: pass
    return []


def _save_meta(items: list[dict]):
    _meta_file().write_text(json.dumps(items, indent=2, default=str))


def _add_meta(rem: dict):
    items = _load_meta()
    items.append(rem)
    _save_meta(items)


def _remove_meta(rid: str):
    items = [r for r in _load_meta() if r.get("id") != rid]
    _save_meta(items)


# ── Telegram handlers ─────────────────────────────────────────────────────────

class ReminderHandlers:

    async def init_reminders(self, bot: Bot):
        """Call at bot startup to restore persisted reminders."""
        global _bot_ref
        _bot_ref = bot
        sched = _get_scheduler()
        if sched is None:
            # Fallback: use old asyncio method
            await self._restore_legacy(bot)
            return
        # APScheduler reloads jobs from SQLite automatically — nothing else needed.
        # But fix any jobs that have _bot_ref=None reference issue by doing nothing
        # (jobs call _fire_reminder which uses global _bot_ref)
        logger.info("Reminder scheduler started, persisted jobs restored from DB.")

    async def _restore_legacy(self, bot: Bot):
        """Fallback for when APScheduler is unavailable."""
        if not REMINDERS_JSON.exists():
            return
        try:
            reminders = json.loads(REMINDERS_JSON.read_text())
        except Exception:
            return
        now = datetime.now()
        active = []
        for r in reminders:
            try:
                when = datetime.fromisoformat(r["when"])
                if when > now:
                    active.append(r)
                    asyncio.create_task(self._legacy_fire(r, bot))
                elif r.get("recurring"):
                    new_when = now.replace(hour=when.hour, minute=when.minute, second=0)
                    if new_when <= now:
                        new_when += timedelta(days=1)
                    r["when"] = new_when.isoformat()
                    active.append(r)
                    asyncio.create_task(self._legacy_fire(r, bot))
            except Exception:
                pass
        REMINDERS_JSON.write_text(json.dumps(active, indent=2, default=str))

    async def _legacy_fire(self, reminder: dict, bot: Bot):
        when = datetime.fromisoformat(reminder["when"])
        delay = max(0.0, (when - datetime.now()).total_seconds())
        await asyncio.sleep(delay)
        try:
            await bot.send_message(
                chat_id=reminder["user_id"],
                text=f"⏰ <b>Reminder!</b>\n\n📝 {reminder['label']}",
                parse_mode="HTML",
                reply_markup=_snooze_keyboard(reminder["id"]),
            )
        except Exception as e:
            logger.error(f"Legacy reminder fire: {e}")

    @require_auth
    async def cmd_remind(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /remind me to call John in 2 hours
        /remind take medicine every day at 8am
        /remind standup every weekday at 9:30am
        /remind meeting tomorrow at 3pm
        """
        msg     = update.effective_message
        user_id = update.effective_user.id
        text    = " ".join(ctx.args) if ctx.args else ""

        if not text:
            await msg.reply_text(
                "⏰ <b>Reminder Examples:</b>\n\n"
                "<code>/remind call John in 2 hours</code>\n"
                "<code>/remind take medicine every day at 8am</code>\n"
                "<code>/remind standup every weekday at 9:30am</code>\n"
                "<code>/remind meeting tomorrow at 3pm</code>\n"
                "<code>/remind backup every Monday at 2am</code>\n\n"
                "📋 List: <code>/reminders</code>",
                parse_mode="HTML"
            )
            return

        # Get user timezone from memory
        from salim.handlers.memory import get_fact
        user_tz = get_fact(user_id, "timezone") or "UTC"

        when, is_recurring, label, cron_str = _parse_time(text, user_tz)

        if not when:
            await msg.reply_text(
                "❌ Could not parse time.\n\n"
                "Try: <code>/remind call John in 2 hours</code> or "
                "<code>/remind standup tomorrow at 9am</code>",
                parse_mode="HTML"
            )
            return

        rid = f"rem_{user_id}_{int(when.timestamp())}_{abs(hash(label)) % 9999:04d}"

        sched = _get_scheduler()
        if sched:
            try:
                if is_recurring and cron_str and not cron_str.startswith("interval:"):
                    # Cron-based recurring
                    parts = cron_str.split()
                    from apscheduler.triggers.cron import CronTrigger
                    trigger = CronTrigger(
                        minute=parts[0], hour=parts[1],
                        day=parts[2], month=parts[3], day_of_week=parts[4],
                        timezone=user_tz,
                    )
                    sched.add_job(
                        _fire_reminder, trigger, id=rid,
                        args=[user_id, label, rid],
                        replace_existing=True,
                        misfire_grace_time=3600,
                    )
                elif is_recurring and cron_str and cron_str.startswith("interval:"):
                    mins = int(cron_str.split(":")[1])
                    from apscheduler.triggers.interval import IntervalTrigger
                    trigger = IntervalTrigger(minutes=mins)
                    sched.add_job(
                        _fire_reminder, trigger, id=rid,
                        args=[user_id, label, rid],
                        replace_existing=True,
                        misfire_grace_time=3600,
                    )
                else:
                    from apscheduler.triggers.date import DateTrigger
                    sched.add_job(
                        _fire_reminder, DateTrigger(run_date=when), id=rid,
                        args=[user_id, label, rid],
                        replace_existing=True,
                    )
            except Exception as e:
                logger.error(f"APScheduler add_job failed: {e}")
                # Fallback to asyncio
                asyncio.create_task(self._legacy_fire(
                    {"id": rid, "user_id": user_id, "label": label,
                     "when": when.isoformat(), "recurring": is_recurring},
                    update.get_bot()
                ))
        else:
            asyncio.create_task(self._legacy_fire(
                {"id": rid, "user_id": user_id, "label": label,
                 "when": when.isoformat(), "recurring": is_recurring},
                update.get_bot()
            ))

        # Store metadata
        _add_meta({
            "id": rid, "label": label, "when": when.isoformat(),
            "user_id": user_id, "recurring": is_recurring,
            "cron": cron_str, "tz": user_tz,
            "created": datetime.now().isoformat(),
        })

        # Build countdown string
        now_local = datetime.now()
        diff = when.replace(tzinfo=None) - now_local if when.tzinfo else when - now_local
        total_secs = int(diff.total_seconds())
        if total_secs < 3600:
            countdown = f"{total_secs//60}m"
        elif total_secs < 86400:
            countdown = f"{total_secs//3600}h {(total_secs%3600)//60}m"
        else:
            countdown = f"{total_secs//86400}d {(total_secs%86400)//3600}h"

        recur_str = " 🔁 recurring" if is_recurring else ""
        try:
            when_str = when.strftime("%a %b %d at %I:%M %p")
        except Exception:
            when_str = str(when)[:16]

        await msg.reply_text(
            f"✅ <b>Reminder set{recur_str}</b>\n\n"
            f"📝 {label}\n"
            f"⏰ {when_str}  <i>(in {countdown})</i>\n\n"
            f"<code>ID: {rid[-12:]}</code>  ·  /reminders to view all",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_reminders(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/reminders — list all upcoming reminders."""
        msg     = update.effective_message
        user_id = update.effective_user.id
        items   = [r for r in _load_meta() if str(r.get("user_id")) == str(user_id)]
        items.sort(key=lambda r: r.get("when", ""))

        if not items:
            await msg.reply_text(
                "📋 No reminders set.\n\n"
                "Add one: <code>/remind call John in 2 hours</code>",
                parse_mode="HTML"
            )
            return

        lines = [f"📋 <b>Your Reminders ({len(items)})</b>\n"]
        now = datetime.now()
        for r in items:
            try:
                when = datetime.fromisoformat(r["when"]).replace(tzinfo=None)
                diff = when - now
                secs = int(diff.total_seconds())
                if secs > 0:
                    if secs < 3600:
                        eta = f"in {secs//60}m"
                    elif secs < 86400:
                        eta = f"in {secs//3600}h {(secs%3600)//60}m"
                    else:
                        eta = f"in {secs//86400}d"
                else:
                    eta = "overdue"
                time_str = when.strftime("%a %b %d at %I:%M %p")
            except Exception:
                time_str = r.get("when", "?")[:16]
                eta = ""
            recur = " 🔁" if r.get("recurring") else ""
            lines.append(
                f"⏰ <b>{r['label']}</b>{recur}\n"
                f"   {time_str}  <i>({eta})</i>  ·  <code>{r['id'][-10:]}</code>"
            )
        lines.append("\n<i>Delete: /remdel &lt;id&gt; · /remclear to clear all</i>")
        await msg.reply_text("\n\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_remdel(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/remdel <id> — delete a reminder."""
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            await msg.reply_text("Usage: <code>/remdel &lt;id&gt;</code>", parse_mode="HTML")
            return
        rid_part = args[0]
        items = _load_meta()
        matched = [r for r in items if rid_part in r.get("id", "")]
        if not matched:
            await msg.reply_text(f"❌ No reminder found with ID containing: <code>{rid_part}</code>", parse_mode="HTML")
            return
        for r in matched:
            rid = r["id"]
            _remove_meta(rid)
            sched = _get_scheduler()
            if sched:
                try: sched.remove_job(rid)
                except Exception: pass
        await msg.reply_text(f"🗑️ Deleted {len(matched)} reminder(s).")

    @require_auth
    async def cmd_remclear(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/remclear — delete all your reminders."""
        uid   = str(update.effective_user.id)
        items = _load_meta()
        mine  = [r for r in items if str(r.get("user_id")) == uid]
        sched = _get_scheduler()
        for r in mine:
            if sched:
                try: sched.remove_job(r["id"])
                except Exception: pass
        remaining = [r for r in items if str(r.get("user_id")) != uid]
        _save_meta(remaining)
        await update.effective_message.reply_text(f"🗑️ Cleared {len(mine)} reminder(s).")

    async def callback_snooze(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handle snooze inline button presses."""
        query = update.callback_query
        await query.answer()
        data  = query.data  # "snooze:<rid>:<minutes>"
        parts = data.split(":")
        if len(parts) != 3:
            return
        _, rid, mins_str = parts
        mins  = int(mins_str)

        if mins == 0:
            await query.edit_message_reply_markup(reply_markup=None)
            await query.message.reply_text("✅ Reminder dismissed.")
            return

        # Get original reminder
        items   = _load_meta()
        rem     = next((r for r in items if rid in r.get("id", "")), None)
        label   = rem["label"] if rem else "Reminder"
        user_id = query.from_user.id
        user_tz = "UTC"
        try:
            from salim.handlers.memory import get_fact
            user_tz = get_fact(user_id, "timezone") or "UTC"
        except Exception:
            pass

        snooze_when = datetime.now() + timedelta(minutes=mins)
        snooze_rid  = f"snooze_{rid}_{int(snooze_when.timestamp())}"

        sched = _get_scheduler()
        if sched:
            try:
                from apscheduler.triggers.date import DateTrigger
                sched.add_job(
                    _fire_reminder, DateTrigger(run_date=snooze_when), id=snooze_rid,
                    args=[user_id, f"[Snoozed] {label}", snooze_rid],
                    replace_existing=True,
                )
            except Exception as e:
                logger.error(f"Snooze schedule failed: {e}")
        else:
            asyncio.create_task(self._legacy_fire(
                {"id": snooze_rid, "user_id": user_id, "label": f"[Snoozed] {label}",
                 "when": snooze_when.isoformat(), "recurring": False},
                query.get_bot()
            ))

        _add_meta({
            "id": snooze_rid, "label": f"[Snoozed] {label}",
            "when": snooze_when.isoformat(), "user_id": user_id,
            "recurring": False, "tz": user_tz,
        })

        human = f"{mins}m" if mins < 60 else f"{mins//60}h"
        await query.edit_message_reply_markup(reply_markup=None)
        await query.message.reply_text(f"⏱ Snoozed for {human}. I'll remind you again.")

    # Keep backward compat
    async def restore_reminders(self, bot: Bot):
        await self.init_reminders(bot)
