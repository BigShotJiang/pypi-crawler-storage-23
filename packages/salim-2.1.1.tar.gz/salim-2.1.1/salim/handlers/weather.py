"""
Salim Weather Handler v2 — Advanced weather with multiple locations & alerts

Improvements over v1:
  - Multiple saved locations: /weather save home London
  - Hourly forecast: /weather London hourly
  - Weather alerts (auto-detect severe codes)
  - Imperial/metric toggle: /weather units imperial
  - UV index, humidity, precipitation probability
  - Auto morning briefing integration (triggered by digest_handler)
  - Better emoji forecast bar chart

Auto-installed: httpx>=0.25 (already required), pytz>=2024.1

Commands:
  /weather                         — current weather (default location)
  /weather <city>                  — weather in any city
  /weather <city> 5                — 5-day forecast
  /weather <city> hourly           — 24h hourly forecast
  /weather save <name> <city>      — save a named location (home, work…)
  /weather set <city>              — set default location
  /weather locations               — list saved locations
  /weather units imperial|metric   — toggle units
  /weather alerts                  — show any active weather alerts
"""
from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta
from pathlib import Path

import httpx
from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.weather")
WEATHER_CFG = Path.home() / ".salim" / "weather_config.json"

WMO_CODES = {
    0:"☀️ Clear",1:"🌤 Mainly clear",2:"⛅ Partly cloudy",3:"☁️ Overcast",
    45:"🌫 Foggy",48:"🌫 Icy fog",51:"🌦 Lt drizzle",53:"🌦 Drizzle",55:"🌧 Hvy drizzle",
    61:"🌧 Lt rain",63:"🌧 Rain",65:"🌧 Hvy rain",66:"🌨 Freezing rain",67:"🌨 Hvy freezing rain",
    71:"❄️ Lt snow",73:"❄️ Snow",75:"❄️ Hvy snow",77:"🌨 Snow grains",
    80:"🌦 Lt showers",81:"🌧 Showers",82:"⛈ Hvy showers",
    85:"🌨 Snow showers",86:"❄️ Hvy snow showers",
    95:"⛈ Thunderstorm",96:"⛈ T-storm+hail",99:"⛈ Hvy T-storm+hail",
}

SEVERE_CODES = {65, 66, 67, 75, 82, 95, 96, 99}

ALERT_MESSAGES = {
    65:"🚨 Heavy rain alert",66:"🚨 Freezing rain alert",67:"🚨 Heavy freezing rain",
    75:"🚨 Heavy snow alert",82:"🚨 Heavy rain shower alert",
    95:"⚡ Thunderstorm alert",96:"⚡ Thunderstorm + hail",99:"⚡ Severe thunderstorm + hail",
}


def _load_cfg() -> dict:
    if WEATHER_CFG.exists():
        try: return json.loads(WEATHER_CFG.read_text())
        except Exception: pass
    return {"locations": {}, "default": None, "units": "metric"}


def _save_cfg(cfg: dict):
    WEATHER_CFG.parent.mkdir(parents=True, exist_ok=True)
    WEATHER_CFG.write_text(json.dumps(cfg, indent=2))


async def _geocode(city: str) -> tuple[float, float, str] | None:
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(
                "https://geocoding-api.open-meteo.com/v1/search",
                params={"name": city, "count": 1, "language": "en", "format": "json"}
            )
            results = r.json().get("results", [])
            if not results:
                return None
            res  = results[0]
            name = f"{res.get('name','')}, {res.get('country','')}"
            return res["latitude"], res["longitude"], name
    except Exception as e:
        logger.error(f"Geocode error: {e}")
        return None


async def _fetch_weather(lat: float, lon: float, days: int = 1, hourly: bool = False) -> dict | None:
    try:
        params = {
            "latitude": lat, "longitude": lon,
            "current": "temperature_2m,relative_humidity_2m,wind_speed_10m,weathercode,"
                       "apparent_temperature,precipitation,uv_index,surface_pressure",
            "daily": "weathercode,temperature_2m_max,temperature_2m_min,precipitation_sum,"
                     "wind_speed_10m_max,sunrise,sunset,uv_index_max,precipitation_probability_max",
            "timezone": "auto",
            "forecast_days": min(max(days, 1), 7),
        }
        if hourly:
            params["hourly"] = "temperature_2m,precipitation_probability,weathercode,wind_speed_10m"
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get("https://api.open-meteo.com/v1/forecast", params=params)
            return r.json()
    except Exception as e:
        logger.error(f"Weather fetch error: {e}")
        return None


def _fmt_temp(val, units: str) -> str:
    if val is None or val == "?":
        return "?"
    if units == "imperial":
        f = val * 9/5 + 32
        return f"{f:.0f}°F"
    return f"{val:.0f}°C"


def _fmt_wind(val, units: str) -> str:
    if val is None:
        return "?"
    if units == "imperial":
        mph = val * 0.621371
        return f"{mph:.0f} mph"
    return f"{val:.0f} km/h"


def _temp_bar(hi, lo, units: str) -> str:
    """Visual temperature range bar."""
    try:
        h = float(hi); l = float(lo)
        if units == "imperial":
            h = h * 9/5 + 32; l = l * 9/5 + 32
        bar_len = max(1, min(10, int(abs(h - l) / 3)))
        return "█" * bar_len
    except Exception:
        return ""


class WeatherHandlers:

    @require_auth
    async def cmd_weather(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /weather                       — default location
        /weather London                — any city
        /weather London 5              — 5-day forecast
        /weather London hourly         — 24h hourly
        /weather save home London      — save named location
        /weather set London            — default location
        /weather locations             — list saved
        /weather units imperial        — toggle units
        /weather alerts                — weather alerts
        """
        msg  = update.effective_message
        args = ctx.args or []
        cfg  = _load_cfg()
        units = cfg.get("units", "metric")

        if not args:
            args_sub = "show"
        else:
            args_sub = args[0].lower()

        # ── set ────────────────────────────────────────────────────────────────
        if args_sub == "set":
            city = " ".join(args[1:])
            if not city:
                await msg.reply_text("Usage: <code>/weather set London</code>", parse_mode="HTML")
                return
            geo = await _geocode(city)
            if not geo:
                await msg.reply_text(f"❌ City not found: <b>{city}</b>", parse_mode="HTML")
                return
            lat, lon, name = geo
            cfg["default"] = {"city": city, "lat": lat, "lon": lon, "name": name}
            _save_cfg(cfg)
            await msg.reply_text(f"✅ Default set to <b>{name}</b>", parse_mode="HTML")
            return

        # ── save ───────────────────────────────────────────────────────────────
        if args_sub == "save" and len(args) >= 3:
            loc_name = args[1].lower()
            city     = " ".join(args[2:])
            geo = await _geocode(city)
            if not geo:
                await msg.reply_text(f"❌ City not found: <b>{city}</b>", parse_mode="HTML")
                return
            lat, lon, name = geo
            cfg.setdefault("locations", {})[loc_name] = {"city": city, "lat": lat, "lon": lon, "name": name}
            _save_cfg(cfg)
            await msg.reply_text(f"✅ Saved <b>{loc_name}</b> → {name}", parse_mode="HTML")
            return

        # ── locations ──────────────────────────────────────────────────────────
        if args_sub == "locations":
            locs = cfg.get("locations", {})
            default = cfg.get("default")
            if not locs and not default:
                await msg.reply_text("No saved locations.\n<code>/weather save home London</code>", parse_mode="HTML")
                return
            lines = ["📍 <b>Saved Locations</b>\n"]
            if default:
                lines.append(f"⭐ <b>default</b>: {default['name']}")
            for name, loc in locs.items():
                lines.append(f"📌 <b>{name}</b>: {loc['name']}")
            lines.append("\n<i>/weather &lt;name&gt; — use saved location</i>")
            await msg.reply_text("\n".join(lines), parse_mode="HTML")
            return

        # ── units ──────────────────────────────────────────────────────────────
        if args_sub == "units" and len(args) >= 2:
            u = args[1].lower()
            if u in ("imperial", "metric"):
                cfg["units"] = u
                _save_cfg(cfg)
                await msg.reply_text(f"✅ Units set to <b>{u}</b>", parse_mode="HTML")
            else:
                await msg.reply_text("❌ Use: <code>/weather units imperial</code> or <code>metric</code>", parse_mode="HTML")
            return

        # ── alerts ─────────────────────────────────────────────────────────────
        if args_sub == "alerts":
            await self._show_alerts(msg, cfg, units)
            return

        # ── Parse city + options ───────────────────────────────────────────────
        days   = 1
        hourly = False
        city_parts = []
        remaining  = args if args_sub != "show" else []

        for a in remaining:
            al = a.lower()
            if al.isdigit():
                days = min(int(al), 7)
            elif al in ("hourly", "hour", "24h"):
                hourly = True
            else:
                # Check if it's a saved location name
                if al in cfg.get("locations", {}):
                    loc = cfg["locations"][al]
                    lat, lon, display_name = loc["lat"], loc["lon"], loc["name"]
                    await self._display_weather(msg, lat, lon, display_name, days, hourly, units)
                    return
                else:
                    city_parts.append(a)

        city = " ".join(city_parts)

        if city:
            geo = await _geocode(city)
            if not geo:
                await msg.reply_text(f"❌ City not found: <b>{city}</b>", parse_mode="HTML")
                return
            lat, lon, display_name = geo
        else:
            default = cfg.get("default")
            if not default:
                await msg.reply_text(
                    "📍 No default location.\n\n"
                    "<code>/weather set London</code>\n"
                    "<code>/weather save home London</code>",
                    parse_mode="HTML"
                )
                return
            lat, lon, display_name = default["lat"], default["lon"], default["name"]

        await self._display_weather(msg, lat, lon, display_name, days, hourly, units)

    async def _display_weather(self, msg, lat, lon, display_name, days, hourly, units):
        await msg.reply_text("🌍 Fetching weather…")
        data = await _fetch_weather(lat, lon, days, hourly)
        if not data or "current" not in data:
            await msg.reply_text("❌ Could not fetch weather data.")
            return

        cur   = data["current"]
        code  = cur.get("weathercode", 0)
        cond  = WMO_CODES.get(code, "Unknown")
        temp  = _fmt_temp(cur.get("temperature_2m"), units)
        feels = _fmt_temp(cur.get("apparent_temperature"), units)
        humid = cur.get("relative_humidity_2m", "?")
        wind  = _fmt_wind(cur.get("wind_speed_10m"), units)
        precip = cur.get("precipitation", 0)
        uv    = cur.get("uv_index", None)
        press = cur.get("surface_pressure", None)

        # Alert check
        alert_str = ""
        if code in SEVERE_CODES:
            alert_str = f"\n🚨 <b>{ALERT_MESSAGES.get(code, 'Severe weather alert')}</b>"

        lines = [
            f"🌍 <b>{display_name}</b>",
            f"🕐 {datetime.now().strftime('%a %b %d, %H:%M')}",
            "",
            f"{cond}{alert_str}",
            f"🌡️ <b>{temp}</b>  (feels {feels})",
            f"💧 Humidity: {humid}%",
            f"💨 Wind: {wind}",
        ]
        if precip:
            lines.append(f"🌧 Precip: {precip} mm")
        if uv is not None:
            uv_label = "Low" if uv < 3 else "Moderate" if uv < 6 else "High" if uv < 8 else "Very High" if uv < 11 else "Extreme"
            lines.append(f"☀️ UV: {uv:.0f} ({uv_label})")
        if press:
            lines.append(f"🌬 Pressure: {press:.0f} hPa")

        # ── Hourly forecast ────────────────────────────────────────────────────
        if hourly and "hourly" in data:
            h_data = data["hourly"]
            times  = h_data.get("time", [])
            temps  = h_data.get("temperature_2m", [])
            probs  = h_data.get("precipitation_probability", [])
            codes  = h_data.get("weathercode", [])
            lines += ["", "<b>⏰ 24h Forecast</b>"]
            now_h  = datetime.now().replace(minute=0, second=0, microsecond=0)
            count  = 0
            for i, ts in enumerate(times[:48]):
                try:
                    t = datetime.fromisoformat(ts)
                    if t < now_h:
                        continue
                    if count >= 12:
                        break
                    count += 1
                    emoji = WMO_CODES.get(codes[i] if i < len(codes) else 0, "?").split()[0]
                    tp    = _fmt_temp(temps[i] if i < len(temps) else None, units)
                    prob  = probs[i] if i < len(probs) else 0
                    rain  = f" 🌧{prob}%" if prob > 20 else ""
                    lines.append(f"  <b>{t.strftime('%H:00')}</b>  {emoji} {tp}{rain}")
                except Exception:
                    pass

        # ── Multi-day daily forecast ───────────────────────────────────────────
        elif days > 1 and "daily" in data:
            daily = data["daily"]
            lines += ["", f"<b>📅 {days}-Day Forecast</b>"]
            dates = daily.get("time", [])
            for i in range(min(days, len(dates))):
                try:
                    d     = datetime.strptime(dates[i], "%Y-%m-%d")
                    dname = d.strftime("%a %d")
                    dc    = daily["weathercode"][i]
                    dcond = WMO_CODES.get(dc, "—").split()[0]
                    hi    = _fmt_temp(daily["temperature_2m_max"][i], units)
                    lo    = _fmt_temp(daily["temperature_2m_min"][i], units)
                    rain  = daily.get("precipitation_sum", [None]*8)[i]
                    prob  = daily.get("precipitation_probability_max", [0]*8)[i] or 0
                    uv_d  = daily.get("uv_index_max", [None]*8)[i]
                    bar   = _temp_bar(daily["temperature_2m_max"][i], daily["temperature_2m_min"][i], units)
                    rain_str = f" 🌧{prob}%" if prob > 20 else ""
                    uv_str   = f" UV:{uv_d:.0f}" if uv_d else ""
                    lines.append(
                        f"  <b>{dname}</b>  {dcond} {bar}  {hi}↑{lo}↓{rain_str}{uv_str}"
                    )
                except Exception:
                    pass

        lines.append(f"\n<i>Source: Open-Meteo (free, no API key)</i>")
        lines.append("<i>/weather locations · /weather units imperial · /weather alerts</i>")
        await msg.reply_text("\n".join(lines), parse_mode="HTML")

    async def _show_alerts(self, msg, cfg, units):
        default = cfg.get("default")
        if not default:
            await msg.reply_text("No default location. Set one: <code>/weather set London</code>", parse_mode="HTML")
            return
        data = await _fetch_weather(default["lat"], default["lon"], days=3)
        if not data or "daily" not in data:
            await msg.reply_text("❌ Could not fetch weather data.")
            return
        daily   = data["daily"]
        dates   = daily.get("time", [])
        codes   = daily.get("weathercode", [])
        alerts  = []
        for i, (date, code) in enumerate(zip(dates, codes)):
            if code in SEVERE_CODES:
                alerts.append(f"⚠️ <b>{date}</b>: {ALERT_MESSAGES.get(code, 'Severe weather')}")
        cur_code = data.get("current", {}).get("weathercode", 0)
        if cur_code in SEVERE_CODES:
            alerts.insert(0, f"🚨 <b>NOW</b>: {ALERT_MESSAGES.get(cur_code, 'Severe weather')}")

        if not alerts:
            await msg.reply_text(f"✅ No severe weather alerts for <b>{default['name']}</b> in the next 3 days.", parse_mode="HTML")
        else:
            await msg.reply_text(
                f"🚨 <b>Weather Alerts — {default['name']}</b>\n\n" + "\n".join(alerts),
                parse_mode="HTML"
            )

    async def get_weather_brief(self, lat: float, lon: float, units: str = "metric") -> str:
        """Called by digest/briefing handler for morning weather summary."""
        data = await _fetch_weather(lat, lon, days=1)
        if not data or "current" not in data:
            return "Weather unavailable."
        cur   = data["current"]
        code  = cur.get("weathercode", 0)
        temp  = _fmt_temp(cur.get("temperature_2m"), units)
        feels = _fmt_temp(cur.get("apparent_temperature"), units)
        cond  = WMO_CODES.get(code, "Unknown")
        alert = f" ⚠️ {ALERT_MESSAGES.get(code, '')}" if code in SEVERE_CODES else ""
        return f"{cond}{alert} · {temp} (feels {feels})"
