"""
Salim Notes Handler v2 — Advanced Notes / Scratchpad

Improvements over v1:
  - Full-text search: /notesearch <keyword>
  - Edit notes: /noteedit <id> <new text>
  - Tags: /note #work #urgent Call the client
  - View full note: /noteview <id>
  - Auth-protected (require_auth on all commands)
  - User-isolated: each user's notes stored separately
  - Export all notes as text file: /notesexport
  - Pin notes: /notepin <id>
  - Sequential IDs never reused (use monotonic counter)

Auto-installed deps: none (stdlib only)

Commands:
  /note <text>              — save a note (supports #tags)
  /notes                    — list latest 20 notes
  /notesearch <keyword>     — search notes
  /noteview <id>            — view full note
  /noteedit <id> <text>     — edit a note
  /notepin <id>             — pin/unpin a note
  /notedel <id>             — delete a note
  /noteclear                — clear all notes
  /notesexport              — export notes as text file
"""
from __future__ import annotations

import html
import io
import json
import logging
import re
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger(__name__)

NOTES_DIR = Path.home() / ".salim" / "notes"


def _notes_file(user_id: int) -> Path:
    NOTES_DIR.mkdir(parents=True, exist_ok=True)
    return NOTES_DIR / f"{user_id}.json"


def _load(user_id: int) -> list[dict]:
    f = _notes_file(user_id)
    try:
        if f.exists():
            return json.loads(f.read_text())
    except Exception:
        pass
    return []


def _save(user_id: int, notes: list[dict]):
    _notes_file(user_id).write_text(json.dumps(notes, indent=2))


def _next_id(notes: list[dict]) -> int:
    """Always incrementing ID, never reused."""
    if not notes:
        return 1
    return max(n["id"] for n in notes) + 1


def _extract_tags(text: str) -> list[str]:
    return list({m.lower() for m in re.findall(r"#(\w+)", text)})


class NotesHandlers:

    @require_auth
    async def cmd_note(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Save a quick note. Usage: /note <text> — supports #tags"""
        user_id = update.effective_user.id
        text = " ".join(ctx.args) if ctx.args else ""
        if not text:
            await update.effective_message.reply_text(
                "📝 <b>Notes Usage:</b>\n\n"
                "<code>/note Call the client</code>\n"
                "<code>/note #work #urgent Finish the report</code>\n"
                "<code>/notes</code> — view all\n"
                "<code>/notesearch urgent</code> — search\n"
                "<code>/noteedit 3 Updated text</code> — edit",
                parse_mode="HTML"
            )
            return

        notes = _load(user_id)
        tags  = _extract_tags(text)
        note  = {
            "id":      _next_id(notes),
            "text":    text,
            "tags":    tags,
            "pinned":  False,
            "created": datetime.now().isoformat(timespec="seconds"),
            "edited":  None,
        }
        notes.append(note)
        _save(user_id, notes)

        tag_str = "  " + " ".join(f"#{t}" for t in tags) if tags else ""
        await update.effective_message.reply_text(
            f"📝 <b>Note #{note['id']} saved</b>{html.escape(tag_str)}\n"
            f"<i>{html.escape(text[:200])}</i>",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_notes(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """List all notes (latest 20, pinned first)."""
        user_id = update.effective_user.id
        notes   = _load(user_id)
        if not notes:
            await update.effective_message.reply_text(
                "📭 No notes yet.\n\n<code>/note <text></code> to add one.",
                parse_mode="HTML"
            )
            return

        # Pinned first, then by date desc
        pinned   = [n for n in notes if n.get("pinned")]
        unpinned = [n for n in notes if not n.get("pinned")]
        combined = pinned + list(reversed(unpinned))
        shown    = combined[:20]

        lines = [f"<b>📝 Notes ({len(notes)})</b>  <i>/notesearch · /notesexport</i>\n"]
        for n in shown:
            ts      = n.get("created", "")[:16].replace("T", " ")
            preview = html.escape(n["text"][:100])
            if len(n["text"]) > 100:
                preview += "…"
            pin  = "📌 " if n.get("pinned") else ""
            tags = " ".join(f"#{t}" for t in n.get("tags", []))
            tag_str = f"  <i>{html.escape(tags)}</i>" if tags else ""
            lines.append(
                f"{pin}<b>#{n['id']}</b>  <i>{ts}</i>{tag_str}\n"
                f"{preview}"
            )
        if len(notes) > 20:
            lines.append(f"\n<i>…and {len(notes)-20} more. Use /notesearch to find older notes.</i>")
        lines.append("\n<i>/noteview &lt;id&gt; · /noteedit &lt;id&gt; · /notepin &lt;id&gt; · /notedel &lt;id&gt;</i>")
        await update.effective_message.reply_text("\n\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_notesearch(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Search notes by keyword or tag. Usage: /notesearch <keyword>"""
        user_id = update.effective_user.id
        if not ctx.args:
            await update.effective_message.reply_text("Usage: <code>/notesearch <keyword></code>", parse_mode="HTML")
            return
        kw    = " ".join(ctx.args).lower()
        is_tag = kw.startswith("#")
        if is_tag:
            kw = kw.lstrip("#")
        notes  = _load(user_id)
        if is_tag:
            results = [n for n in notes if kw in [t.lower() for t in n.get("tags", [])]]
        else:
            results = [n for n in notes if kw in n["text"].lower()]

        if not results:
            await update.effective_message.reply_text(
                f"🔍 No notes found for: <code>{html.escape(kw)}</code>", parse_mode="HTML"
            )
            return

        lines = [f"🔍 <b>Search '{html.escape(kw)}': {len(results)} result(s)</b>\n"]
        for n in results[-15:]:
            ts      = n.get("created", "")[:16].replace("T", " ")
            # Highlight keyword in preview
            text    = n["text"][:150]
            preview = html.escape(text)
            lines.append(f"<b>#{n['id']}</b>  <i>{ts}</i>\n{preview}")
        await update.effective_message.reply_text("\n\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_noteview(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """View full note. Usage: /noteview <id>"""
        user_id = update.effective_user.id
        if not ctx.args or not ctx.args[0].isdigit():
            await update.effective_message.reply_text("Usage: <code>/noteview &lt;id&gt;</code>", parse_mode="HTML")
            return
        nid   = int(ctx.args[0])
        notes = _load(user_id)
        note  = next((n for n in notes if n["id"] == nid), None)
        if not note:
            await update.effective_message.reply_text(f"❌ Note #{nid} not found.", parse_mode="HTML")
            return
        tags    = " ".join(f"#{t}" for t in note.get("tags", []))
        pin_str = "📌 Pinned  " if note.get("pinned") else ""
        edited  = f"\n<i>Edited: {note['edited'][:16]}</i>" if note.get("edited") else ""
        await update.effective_message.reply_text(
            f"{pin_str}<b>Note #{nid}</b>  <i>{note['created'][:16].replace('T',' ')}</i>\n"
            f"<i>{html.escape(tags)}</i>{edited}\n\n"
            f"{html.escape(note['text'])}",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_noteedit(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Edit a note. Usage: /noteedit <id> <new text>"""
        user_id = update.effective_user.id
        args    = ctx.args or []
        if len(args) < 2 or not args[0].isdigit():
            await update.effective_message.reply_text(
                "Usage: <code>/noteedit &lt;id&gt; &lt;new text&gt;</code>", parse_mode="HTML"
            )
            return
        nid  = int(args[0])
        text = " ".join(args[1:])
        notes = _load(user_id)
        for n in notes:
            if n["id"] == nid:
                n["text"]   = text
                n["tags"]   = _extract_tags(text)
                n["edited"] = datetime.now().isoformat(timespec="seconds")
                _save(user_id, notes)
                await update.effective_message.reply_text(
                    f"✅ <b>Note #{nid} updated</b>\n<i>{html.escape(text[:200])}</i>",
                    parse_mode="HTML"
                )
                return
        await update.effective_message.reply_text(f"❌ Note #{nid} not found.")

    @require_auth
    async def cmd_notepin(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Pin/unpin a note. Usage: /notepin <id>"""
        user_id = update.effective_user.id
        if not ctx.args or not ctx.args[0].isdigit():
            await update.effective_message.reply_text("Usage: <code>/notepin &lt;id&gt;</code>", parse_mode="HTML")
            return
        nid   = int(ctx.args[0])
        notes = _load(user_id)
        for n in notes:
            if n["id"] == nid:
                n["pinned"] = not n.get("pinned", False)
                _save(user_id, notes)
                state = "📌 Pinned" if n["pinned"] else "📄 Unpinned"
                await update.effective_message.reply_text(f"{state} Note #{nid}.")
                return
        await update.effective_message.reply_text(f"❌ Note #{nid} not found.")

    @require_auth
    async def cmd_notedel(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Delete a note by ID. Usage: /notedel <id>"""
        user_id = update.effective_user.id
        if not ctx.args or not ctx.args[0].isdigit():
            await update.effective_message.reply_text("Usage: <code>/notedel &lt;id&gt;</code>", parse_mode="HTML")
            return
        nid   = int(ctx.args[0])
        notes = _load(user_id)
        new   = [n for n in notes if n["id"] != nid]
        if len(new) == len(notes):
            await update.effective_message.reply_text(f"❌ Note #{nid} not found.")
            return
        _save(user_id, new)
        await update.effective_message.reply_text(f"🗑 Note #{nid} deleted.")

    @require_auth
    async def cmd_noteclear(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Clear all your notes."""
        user_id = update.effective_user.id
        count   = len(_load(user_id))
        _save(user_id, [])
        await update.effective_message.reply_text(f"🗑 {count} notes cleared.")

    @require_auth
    async def cmd_notesexport(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Export all notes as a text file. /notesexport"""
        user_id = update.effective_user.id
        notes   = _load(user_id)
        if not notes:
            await update.effective_message.reply_text("📭 No notes to export.")
            return

        lines = [f"# Salim Notes Export — {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"]
        pinned   = [n for n in notes if n.get("pinned")]
        unpinned = [n for n in notes if not n.get("pinned")]
        for n in pinned + unpinned:
            pin_str = "[PINNED] " if n.get("pinned") else ""
            tags    = " ".join(f"#{t}" for t in n.get("tags", []))
            lines.append(
                f"---\n"
                f"#{n['id']} {pin_str}{n['created'][:16]} {tags}\n"
                f"{n['text']}\n"
            )

        buf = io.BytesIO("\n".join(lines).encode("utf-8"))
        buf.name = f"notes_{datetime.now().strftime('%Y%m%d')}.txt"
        await update.effective_message.reply_document(
            document=buf,
            filename=buf.name,
            caption=f"📝 Exported {len(notes)} notes."
        )
