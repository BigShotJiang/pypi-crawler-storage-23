"""
Salim Finance Handler — Real-time stock & crypto prices, currency conversion (all free APIs).

Commands:
  /price AAPL              — stock price (Yahoo Finance, no API key)
  /price BTC               — crypto price
  /crypto BTC ETH SOL      — multiple crypto prices at once
  /stocks AAPL MSFT GOOGL  — multiple stock prices
  /fx USD to AED           — currency exchange rate
  /fx 500 USD to EUR       — convert amount
  /market                  — major market indices snapshot
"""
from __future__ import annotations
import html
import json
import logging
from datetime import datetime

import httpx
from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.finance")

CRYPTO_IDS = {
    "BTC":"bitcoin","ETH":"ethereum","SOL":"solana","BNB":"binancecoin",
    "XRP":"ripple","ADA":"cardano","DOT":"polkadot","DOGE":"dogecoin",
    "AVAX":"avalanche-2","MATIC":"matic-network","LINK":"chainlink",
    "LTC":"litecoin","UNI":"uniswap","ATOM":"cosmos","NEAR":"near",
}

INDICES = {
    "^GSPC": "S&P 500", "^DJI": "Dow Jones", "^IXIC": "NASDAQ",
    "^FTSE": "FTSE 100", "^N225": "Nikkei 225", "^HSI": "Hang Seng",
    "GC=F": "Gold", "SI=F": "Silver", "CL=F": "Crude Oil",
}


async def _yahoo_quote(symbol: str) -> dict | None:
    """Fetch stock/ETF/index quote from Yahoo Finance (free, no API key)."""
    try:
        url = f"https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
        async with httpx.AsyncClient(
            timeout=10,
            headers={"User-Agent": "Mozilla/5.0 (compatible; Salim/1.0)"}
        ) as client:
            r = await client.get(url)
            data = r.json()
            meta = data["chart"]["result"][0]["meta"]
            return {
                "symbol":   meta.get("symbol", symbol),
                "price":    meta.get("regularMarketPrice", 0),
                "prev":     meta.get("chartPreviousClose", 0),
                "currency": meta.get("currency", "USD"),
                "name":     meta.get("longName") or meta.get("shortName") or symbol,
                "exchange": meta.get("exchangeName", ""),
            }
    except Exception as e:
        logger.debug(f"Yahoo quote {symbol}: {e}")
        return None


async def _coingecko_price(coin_ids: list[str]) -> dict:
    """Fetch crypto prices from CoinGecko (free, no API key)."""
    try:
        ids = ",".join(coin_ids)
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(
                "https://api.coingecko.com/api/v3/simple/price",
                params={"ids": ids, "vs_currencies": "usd",
                        "include_24hr_change": "true", "include_market_cap": "true"}
            )
            return r.json()
    except Exception as e:
        logger.debug(f"CoinGecko: {e}")
        return {}


async def _exchange_rate(base: str, target: str) -> float | None:
    """Get exchange rate from exchangerate-api.com (free tier, no key for basic)."""
    try:
        async with httpx.AsyncClient(timeout=10) as client:
            r = await client.get(f"https://open.er-api.com/v6/latest/{base.upper()}")
            data = r.json()
            rates = data.get("rates", {})
            return rates.get(target.upper())
    except Exception as e:
        logger.debug(f"Exchange rate {base}/{target}: {e}")
        return None


def _change_emoji(change: float) -> str:
    if change > 2:    return "🚀"
    if change > 0:    return "📈"
    if change < -2:   return "📉"
    if change < 0:    return "🔻"
    return "➡️"


def _fmt_price(price: float, currency: str = "USD") -> str:
    symbols = {"USD": "$", "EUR": "€", "GBP": "£", "AED": "AED ", "SAR": "SAR "}
    sym = symbols.get(currency, f"{currency} ")
    if price >= 1000:
        return f"{sym}{price:,.2f}"
    elif price >= 1:
        return f"{sym}{price:.4f}"
    else:
        return f"{sym}{price:.6f}"


class FinanceHandlers:

    @require_auth
    async def cmd_price(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /price AAPL          — stock price
        /price BTC           — crypto price
        /price AAPL MSFT BTC — multiple at once
        """
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            await msg.reply_text(
                "💰 <b>Price Lookup</b>\n\n"
                "<code>/price AAPL</code>        — Apple stock\n"
                "<code>/price BTC ETH</code>     — crypto\n"
                "<code>/price AAPL MSFT GOOGL</code> — multiple stocks\n"
                "<code>/market</code>             — market overview\n"
                "<code>/fx USD to AED</code>      — currency rates",
                parse_mode="HTML"
            )
            return

        await msg.reply_text("📊 Fetching prices…")
        lines = []

        for symbol in args[:6]:
            sym_upper = symbol.upper()
            cg_id = CRYPTO_IDS.get(sym_upper)

            if cg_id:
                # Crypto via CoinGecko
                data = await _coingecko_price([cg_id])
                if cg_id in data:
                    info   = data[cg_id]
                    price  = info.get("usd", 0)
                    change = info.get("usd_24h_change", 0) or 0
                    mcap   = info.get("usd_market_cap", 0)
                    icon   = _change_emoji(change)
                    mcap_str = f"  MCap: ${mcap/1e9:.1f}B" if mcap else ""
                    lines.append(
                        f"{icon} <b>{sym_upper}</b>  {_fmt_price(price)}\n"
                        f"   24h: {change:+.2f}%{mcap_str}"
                    )
                else:
                    lines.append(f"❌ {sym_upper}: not found")
            else:
                # Stock/ETF via Yahoo Finance
                quote = await _yahoo_quote(sym_upper)
                if quote:
                    price  = quote["price"]
                    prev   = quote["prev"]
                    change = ((price - prev) / prev * 100) if prev else 0
                    icon   = _change_emoji(change)
                    lines.append(
                        f"{icon} <b>{sym_upper}</b> — {quote['name'][:30]}\n"
                        f"   {_fmt_price(price, quote['currency'])}  ({change:+.2f}%)  {quote['exchange']}"
                    )
                else:
                    lines.append(f"❌ {sym_upper}: not found")

        timestamp = datetime.now().strftime("%H:%M:%S")
        lines.append(f"\n<i>🕐 {timestamp}  ·  Data: Yahoo Finance / CoinGecko (free)</i>")
        await msg.reply_text("\n\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_crypto(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/crypto BTC ETH SOL — crypto prices with 24h change."""
        ctx.args = ctx.args or ["BTC", "ETH", "SOL", "BNB"]
        # Only pass crypto symbols
        await self.cmd_price(update, ctx)

    @require_auth
    async def cmd_stocks(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/stocks AAPL MSFT GOOGL — stock prices."""
        ctx.args = ctx.args or ["AAPL", "MSFT", "GOOGL"]
        await self.cmd_price(update, ctx)

    @require_auth
    async def cmd_market(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/market — snapshot of major indices."""
        msg = update.effective_message
        await msg.reply_text("📊 Fetching market data…")
        lines = ["📊 <b>Markets Snapshot</b>\n"]

        for sym, name in INDICES.items():
            quote = await _yahoo_quote(sym)
            if quote:
                price  = quote["price"]
                prev   = quote["prev"]
                change = ((price - prev) / prev * 100) if prev else 0
                icon   = _change_emoji(change)
                lines.append(f"{icon} <b>{name}</b>  {_fmt_price(price, quote['currency'])}  ({change:+.2f}%)")

        lines.append(f"\n<i>🕐 {datetime.now().strftime('%H:%M:%S')}  ·  Data: Yahoo Finance</i>")
        await msg.reply_text("\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_fx(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /fx USD to AED       — exchange rate
        /fx 500 USD to EUR   — convert amount
        """
        msg  = update.effective_message
        args = ctx.args or []
        if len(args) < 3:
            await msg.reply_text(
                "💱 <b>Currency Exchange</b>\n\n"
                "<code>/fx USD to AED</code>        — rate only\n"
                "<code>/fx 500 USD to EUR</code>    — convert amount\n"
                "<code>/fx 1000 SAR to USD</code>   — Saudi Riyal to USD",
                parse_mode="HTML"
            )
            return

        # Parse: [amount] BASE to TARGET
        import re
        full = " ".join(args).upper()
        m = re.match(r"^([\d.]+\s+)?([A-Z]{3})\s+TO\s+([A-Z]{3})$", full.strip())
        if not m:
            await msg.reply_text("❌ Format: <code>/fx 100 USD to EUR</code>", parse_mode="HTML")
            return

        amount_str = (m.group(1) or "1").strip()
        base       = m.group(2)
        target     = m.group(3)
        try:
            amount = float(amount_str)
        except ValueError:
            amount = 1.0

        rate = await _exchange_rate(base, target)
        if rate is None:
            await msg.reply_text(f"❌ Could not get rate for {base}/{target}.")
            return

        converted = amount * rate
        await msg.reply_text(
            f"💱 <b>Exchange Rate</b>\n\n"
            f"{amount:,.2f} {base} = <b>{converted:,.4f} {target}</b>\n\n"
            f"Rate: 1 {base} = {rate:.4f} {target}\n"
            f"<i>Source: open.er-api.com (free)</i>",
            parse_mode="HTML"
        )
