"""
Salim Calendar Handler — Google Calendar integration (free OAuth, no paid API).

Setup: /cal setup   — one-time Google OAuth in browser
Commands:
  /cal                    — today's events
  /cal tomorrow           — tomorrow's events
  /cal week               — this week's events
  /cal add Meeting with John tomorrow 3pm  — add event
  /cal add Dentist April 15 10am 1h        — add with duration
  /cal search project                      — search events
  /cal delete <event_id>                   — delete event
"""
from __future__ import annotations
import json
import logging
import os
import re
from datetime import datetime, timedelta, date
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.calendar")

CAL_DIR      = Path.home() / ".salim" / "calendar"
TOKEN_FILE   = CAL_DIR / "token.json"
CREDS_FILE   = CAL_DIR / "credentials.json"
LOCAL_FILE   = CAL_DIR / "local_events.json"  # fallback if no Google

SCOPES = ["https://www.googleapis.com/auth/calendar"]


def _load_local_events() -> list[dict]:
    if LOCAL_FILE.exists():
        try:
            return json.loads(LOCAL_FILE.read_text())
        except Exception:
            pass
    return []


def _save_local_events(events: list[dict]):
    LOCAL_FILE.parent.mkdir(parents=True, exist_ok=True)
    LOCAL_FILE.write_text(json.dumps(events, indent=2, default=str))


def _get_google_service():
    """Return authenticated Google Calendar service or None."""
    try:
        from google.oauth2.credentials import Credentials
        from google.auth.transport.requests import Request
        from googleapiclient.discovery import build
        from google_auth_oauthlib.flow import InstalledAppFlow

        creds = None
        if TOKEN_FILE.exists():
            creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)

        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            elif CREDS_FILE.exists():
                flow = InstalledAppFlow.from_client_secrets_file(str(CREDS_FILE), SCOPES)
                creds = flow.run_local_server(port=0)
            else:
                return None

            TOKEN_FILE.parent.mkdir(parents=True, exist_ok=True)
            TOKEN_FILE.write_text(creds.to_json())

        return build("calendar", "v3", credentials=creds)
    except ImportError:
        return None
    except Exception as e:
        logger.error(f"Google Calendar auth: {e}")
        return None


def _parse_datetime(text: str) -> datetime | None:
    """Parse natural language date/time strings."""
    now = datetime.now()
    text = text.lower().strip()

    if "today" in text:
        base = now.date()
    elif "tomorrow" in text:
        base = (now + timedelta(days=1)).date()
    elif "monday" in text or "tuesday" in text or "wednesday" in text or \
         "thursday" in text or "friday" in text or "saturday" in text or "sunday" in text:
        days = {"monday":0,"tuesday":1,"wednesday":2,"thursday":3,"friday":4,"saturday":5,"sunday":6}
        for day_name, offset in days.items():
            if day_name in text:
                days_ahead = offset - now.weekday()
                if days_ahead <= 0:
                    days_ahead += 7
                base = (now + timedelta(days=days_ahead)).date()
                break
        else:
            base = now.date()
    else:
        # Try parsing explicit date like "April 15" or "15/4" or "2025-04-15"
        date_patterns = [
            r"(\w+ \d{1,2})",           # April 15
            r"(\d{1,2}/\d{1,2})",        # 15/4
            r"(\d{4}-\d{2}-\d{2})",      # 2025-04-15
        ]
        base = now.date()
        for pattern in date_patterns:
            m = re.search(pattern, text, re.IGNORECASE)
            if m:
                try:
                    ds = m.group(1)
                    for fmt in ["%B %d", "%d/%m", "%Y-%m-%d", "%m/%d"]:
                        try:
                            parsed = datetime.strptime(ds, fmt)
                            base = parsed.replace(year=now.year).date()
                            break
                        except ValueError:
                            continue
                    break
                except Exception:
                    pass

    # Extract time
    time_match = re.search(r"(\d{1,2})(?::(\d{2}))?\s*(am|pm)?", text, re.IGNORECASE)
    if time_match:
        hour   = int(time_match.group(1))
        minute = int(time_match.group(2) or 0)
        ampm   = (time_match.group(3) or "").lower()
        if ampm == "pm" and hour < 12:
            hour += 12
        elif ampm == "am" and hour == 12:
            hour = 0
        return datetime.combine(base, datetime.min.time().replace(hour=hour, minute=minute))
    else:
        return datetime.combine(base, datetime.min.time().replace(hour=9, minute=0))


def _parse_duration(text: str) -> int:
    """Parse duration in minutes. '1h' → 60, '30m' → 30, '1h30m' → 90."""
    total = 0
    for h in re.findall(r"(\d+)\s*h", text, re.IGNORECASE):
        total += int(h) * 60
    for m in re.findall(r"(\d+)\s*m(?!o)", text, re.IGNORECASE):
        total += int(m)
    return total if total > 0 else 60  # default 1 hour


def _format_event(event: dict, show_id: bool = False) -> str:
    """Format a calendar event for Telegram display."""
    title = event.get("summary", "Untitled")
    start = event.get("start", {})
    dt_str = start.get("dateTime") or start.get("date", "")
    loc   = event.get("location", "")
    eid   = event.get("id", "")

    try:
        if "T" in dt_str:
            dt = datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
            time_str = dt.strftime("%a %b %d, %I:%M %p")
        else:
            dt = datetime.strptime(dt_str, "%Y-%m-%d")
            time_str = dt.strftime("%a %b %d (all day)")
    except Exception:
        time_str = dt_str

    line = f"📅 <b>{title}</b>\n   🕐 {time_str}"
    if loc:
        line += f"\n   📍 {loc}"
    if show_id:
        line += f"\n   ID: <code>{eid[:20]}</code>"
    return line


class CalendarHandlers:

    @require_auth
    async def cmd_cal(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /cal                    — today's events
        /cal tomorrow           — tomorrow
        /cal week               — this week
        /cal add Meeting 3pm    — add event
        /cal search keyword     — search
        /cal delete <id>        — delete
        /cal setup              — Google Calendar OAuth setup
        """
        msg  = update.effective_message
        args = ctx.args or []
        sub  = args[0].lower() if args else "today"

        # ── Setup ──────────────────────────────────────────────────────────────
        if sub == "setup":
            await msg.reply_text(
                "📅 <b>Google Calendar Setup</b>\n\n"
                "<b>Step 1:</b> Go to console.cloud.google.com\n"
                "<b>Step 2:</b> Create a project → Enable 'Google Calendar API'\n"
                "<b>Step 3:</b> Create OAuth 2.0 credentials → Desktop App\n"
                "<b>Step 4:</b> Download credentials.json\n"
                "<b>Step 5:</b> Place it at:\n"
                f"<code>{CAL_DIR}/credentials.json</code>\n\n"
                "<b>Step 6:</b> Run <code>/cal auth</code> to authorize\n\n"
                "<i>Alternatively, Salim uses its own local calendar (no Google needed).\n"
                "Local events work with /cal add, /cal, /cal week without any setup.</i>",
                parse_mode="HTML"
            )
            return

        if sub == "auth":
            svc = _get_google_service()
            if svc:
                await msg.reply_text("✅ Google Calendar connected successfully!")
            else:
                await msg.reply_text(
                    "❌ Auth failed. Make sure credentials.json is at:\n"
                    f"<code>{CAL_DIR}/credentials.json</code>",
                    parse_mode="HTML"
                )
            return

        # ── Add event ──────────────────────────────────────────────────────────
        if sub == "add":
            event_text = " ".join(args[1:])
            if not event_text:
                await msg.reply_text(
                    "Usage: <code>/cal add Meeting with John tomorrow 3pm</code>",
                    parse_mode="HTML"
                )
                return

            # Extract duration
            dur_match = re.search(r"\b(\d+h\s*\d*m?|\d+m(?!o)|\d+h)\b", event_text, re.IGNORECASE)
            duration_mins = _parse_duration(dur_match.group(1)) if dur_match else 60

            # Clean title: remove time/date words
            title_text = re.sub(
                r"\b(today|tomorrow|monday|tuesday|wednesday|thursday|friday|saturday|sunday|"
                r"\d{1,2}(?::\d{2})?\s*(?:am|pm)?|"
                r"january|february|march|april|may|june|july|august|september|october|november|december|"
                r"\d{1,2}h|\d+m(?!o))\b",
                "", event_text, flags=re.IGNORECASE
            ).strip()
            title = title_text or event_text

            start_dt = _parse_datetime(event_text)
            end_dt   = start_dt + timedelta(minutes=duration_mins)

            # Try Google first
            svc = _get_google_service()
            if svc:
                try:
                    event_body = {
                        "summary": title,
                        "start": {"dateTime": start_dt.isoformat(), "timeZone": "local"},
                        "end":   {"dateTime": end_dt.isoformat(),   "timeZone": "local"},
                    }
                    created = svc.events().insert(calendarId="primary", body=event_body).execute()
                    await msg.reply_text(
                        f"✅ <b>Added to Google Calendar</b>\n\n"
                        f"{_format_event(created)}",
                        parse_mode="HTML"
                    )
                    return
                except Exception as e:
                    logger.warning(f"Google Calendar add failed: {e}")

            # Fallback: local calendar
            events = _load_local_events()
            new_event = {
                "id": f"local_{int(datetime.now().timestamp())}",
                "summary": title,
                "start": {"dateTime": start_dt.isoformat()},
                "end":   {"dateTime": end_dt.isoformat()},
            }
            events.append(new_event)
            _save_local_events(events)
            await msg.reply_text(
                f"✅ <b>Event added (local calendar)</b>\n\n"
                f"{_format_event(new_event)}\n\n"
                f"<i>Connect Google Calendar with /cal setup for cloud sync.</i>",
                parse_mode="HTML"
            )
            return

        # ── Delete event ───────────────────────────────────────────────────────
        if sub == "delete" and len(args) >= 2:
            eid = args[1]
            svc = _get_google_service()
            if svc:
                try:
                    svc.events().delete(calendarId="primary", eventId=eid).execute()
                    await msg.reply_text(f"🗑️ Event deleted from Google Calendar.")
                    return
                except Exception as e:
                    pass

            # Local fallback
            events = _load_local_events()
            before = len(events)
            events = [e for e in events if e.get("id") != eid]
            if len(events) < before:
                _save_local_events(events)
                await msg.reply_text("🗑️ Event deleted from local calendar.")
            else:
                await msg.reply_text(f"❌ Event ID not found: <code>{eid}</code>", parse_mode="HTML")
            return

        # ── Search ─────────────────────────────────────────────────────────────
        if sub == "search" and len(args) >= 2:
            query = " ".join(args[1:]).lower()
            all_events = await self._get_events(7)
            results = [e for e in all_events if query in e.get("summary", "").lower()]
            if not results:
                await msg.reply_text(f"🔍 No events found matching '<b>{query}</b>'.", parse_mode="HTML")
                return
            lines = [f"🔍 <b>Events matching '{query}':</b>\n"]
            for e in results[:10]:
                lines.append(_format_event(e, show_id=True))
            await msg.reply_text("\n\n".join(lines), parse_mode="HTML")
            return

        # ── View events ────────────────────────────────────────────────────────
        if sub in ("today", ""):
            start = datetime.now().replace(hour=0, minute=0, second=0)
            end   = start + timedelta(days=1)
            label = "📅 <b>Today's Events</b>"
        elif sub == "tomorrow":
            start = (datetime.now() + timedelta(days=1)).replace(hour=0, minute=0, second=0)
            end   = start + timedelta(days=1)
            label = "📅 <b>Tomorrow's Events</b>"
        elif sub == "week":
            start = datetime.now().replace(hour=0, minute=0, second=0)
            end   = start + timedelta(days=7)
            label = "📅 <b>This Week's Events</b>"
        else:
            start = datetime.now().replace(hour=0, minute=0, second=0)
            end   = start + timedelta(days=1)
            label = "📅 <b>Today's Events</b>"

        events = await self._get_events_range(start, end)
        if not events:
            await msg.reply_text(
                f"{label}\n\n<i>No events scheduled.</i>\n\n"
                f"Add one: <code>/cal add Meeting tomorrow 2pm</code>",
                parse_mode="HTML"
            )
            return

        lines = [label, ""]
        for e in events:
            lines.append(_format_event(e))
        lines.append(f"\n<i>Total: {len(events)} event(s)</i>")
        await msg.reply_text("\n\n".join(lines), parse_mode="HTML")

    async def _get_events(self, days: int = 1) -> list[dict]:
        start = datetime.now().replace(hour=0, minute=0, second=0)
        end   = start + timedelta(days=days)
        return await self._get_events_range(start, end)

    async def _get_events_range(self, start: datetime, end: datetime) -> list[dict]:
        """Get events from Google Calendar or local fallback."""
        svc = _get_google_service()
        if svc:
            try:
                result = svc.events().list(
                    calendarId="primary",
                    timeMin=start.isoformat() + "Z",
                    timeMax=end.isoformat() + "Z",
                    singleEvents=True,
                    orderBy="startTime",
                    maxResults=50,
                ).execute()
                return result.get("items", [])
            except Exception as e:
                logger.warning(f"Google Calendar list: {e}")

        # Local fallback
        all_events = _load_local_events()
        result = []
        for e in all_events:
            try:
                dt_str = e.get("start", {}).get("dateTime", "")
                if dt_str:
                    dt = datetime.fromisoformat(dt_str)
                    if start <= dt <= end:
                        result.append(e)
            except Exception:
                pass
        return sorted(result, key=lambda x: x.get("start", {}).get("dateTime", ""))
