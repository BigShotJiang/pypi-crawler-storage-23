"""
Salim Advanced Agent — Autonomous Problem-Solving, Self-Improvement, Emotional Intelligence.

This module extends the base agent (agent.py) with higher-order cognition:

AUTONOMOUS PROBLEM-SOLVING
  • Self-goal setting — agent identifies problems worth solving without prompting
  • Hypothesis → Experiment → Learn loops — forms theories, tests them, updates beliefs
  • Knowledge gap detection — finds what it doesn't know and fills the gap
  • Persistent belief system — maintains a JSON knowledge base that updates over time
  • Failure memory — remembers what failed and avoids repeating mistakes
  • Priority queue — ranks tasks by importance × urgency × feasibility

EMOTIONAL INTELLIGENCE
  • Emotion detection from text — identifies mood, stress, frustration, excitement
  • Empathy-first responses — adjusts tone depth before giving practical help
  • Relationship memory — tracks rapport, trust level, conversation history patterns
  • Mood-aware task scheduling — defers demanding tasks when user is stressed
  • Consistent personality — same character across all sessions

ADAPTIVE COMMUNICATION
  • Style mirroring — matches formal/casual/technical tone from user signals
  • Brevity adaptation — respects when user wants short vs detailed answers
  • Language switching — follows the language the user writes in
  • Expertise gauging — adjusts explanation depth based on inferred knowledge level

EXPERIMENT ENGINE
  • Hypothesis storage — /hypo add "if X then Y"
  • Experiment design — agent designs minimal test to validate hypothesis
  • Results logging — outcome, confidence, learnings stored
  • Knowledge graph update — confirmed hypotheses become beliefs

SELF-IMPROVEMENT
  • Performance tracking — which tasks succeed/fail and why
  • Strategy evolution — rotates approaches on repeated failures
  • Skill gap analysis — identifies commands never used, suggests learning
  • Weekly self-review — summaries of what was learned and what to improve

Commands:
  /think <problem>          — deep autonomous reasoning (multi-step)
  /goal set <goal>          — give agent a persistent background goal to pursue
  /goal list                — list all active goals + progress
  /goal done <id>           — mark goal as complete
  /goal cancel <id>         — cancel a goal
  /hypo add <hypothesis>    — add a hypothesis to test
  /hypo list                — list all hypotheses + confidence
  /hypo test <id>           — design + run experiment to test hypothesis
  /beliefs                  — show agent's current belief system
  /rapport                  — show relationship profile + trust level
  /selfcheck                — agent does a self-assessment of its performance
  /agentmode <mode>         — set communication mode (brief/detailed/empathy/technical)
"""
from __future__ import annotations

import asyncio
import json
import logging
import re
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.handlers.memory import load_memory, save_memory, set_memory

logger = logging.getLogger("salim.agent_advanced")

ADVANCED_DIR   = Path.home() / ".salim" / "agent_advanced"
BELIEFS_FILE   = ADVANCED_DIR / "beliefs.json"
GOALS_FILE     = ADVANCED_DIR / "goals.json"
HYPOTHESES_FILE = ADVANCED_DIR / "hypotheses.json"
RAPPORT_DIR    = ADVANCED_DIR / "rapport"
EXPERIMENTS_FILE = ADVANCED_DIR / "experiments.json"
PERF_FILE      = ADVANCED_DIR / "performance.json"


def _ensure_dirs():
    ADVANCED_DIR.mkdir(parents=True, mode=0o700, exist_ok=True)
    RAPPORT_DIR.mkdir(parents=True, exist_ok=True)


def _esc(v: Any) -> str:
    import html
    return html.escape(str(v), quote=False)


# ══════════════════════════════════════════════════════════════════
# BELIEF SYSTEM
# ══════════════════════════════════════════════════════════════════

def load_beliefs() -> list[dict]:
    _ensure_dirs()
    if BELIEFS_FILE.exists():
        try:
            return json.loads(BELIEFS_FILE.read_text())
        except Exception:
            pass
    return []


def save_beliefs(beliefs: list[dict]):
    _ensure_dirs()
    BELIEFS_FILE.write_text(json.dumps(beliefs, indent=2, ensure_ascii=False))


def add_belief(statement: str, confidence: float = 0.7, source: str = "inferred",
               category: str = "general") -> dict:
    """Add or update a belief. Confidence 0-1."""
    beliefs = load_beliefs()
    # Check for existing similar belief
    for b in beliefs:
        if b["statement"].lower() == statement.lower():
            b["confidence"] = min(1.0, (b["confidence"] + confidence) / 2 + 0.1)
            b["updated"] = datetime.now().isoformat()
            b["confirmations"] = b.get("confirmations", 0) + 1
            save_beliefs(beliefs)
            return b
    new_belief = {
        "id": f"bel_{int(time.time() * 1000)}",
        "statement": statement,
        "confidence": confidence,
        "source": source,
        "category": category,
        "created": datetime.now().isoformat(),
        "updated": datetime.now().isoformat(),
        "confirmations": 1,
        "contradictions": 0,
    }
    beliefs.append(new_belief)
    save_beliefs(beliefs)
    return new_belief


def contradict_belief(belief_id: str, strength: float = 0.3):
    """Reduce confidence in a belief after contradicting evidence."""
    beliefs = load_beliefs()
    for b in beliefs:
        if b["id"] == belief_id:
            b["confidence"] = max(0.0, b["confidence"] - strength)
            b["contradictions"] = b.get("contradictions", 0) + 1
            b["updated"] = datetime.now().isoformat()
    save_beliefs(beliefs)


# ══════════════════════════════════════════════════════════════════
# GOAL SYSTEM
# ══════════════════════════════════════════════════════════════════

def load_goals(user_id: int) -> list[dict]:
    _ensure_dirs()
    gf = ADVANCED_DIR / f"goals_{user_id}.json"
    if gf.exists():
        try:
            return json.loads(gf.read_text())
        except Exception:
            pass
    return []


def save_goals(user_id: int, goals: list[dict]):
    _ensure_dirs()
    gf = ADVANCED_DIR / f"goals_{user_id}.json"
    gf.write_text(json.dumps(goals, indent=2, ensure_ascii=False))


def add_goal(user_id: int, title: str, description: str = "",
             priority: str = "medium", horizon: str = "this week") -> dict:
    goals = load_goals(user_id)
    g = {
        "id":          f"goal_{int(time.time() * 1000)}",
        "title":       title,
        "description": description,
        "priority":    priority,   # high / medium / low
        "horizon":     horizon,    # today / this week / this month / ongoing
        "status":      "active",   # active / paused / done / cancelled
        "created":     datetime.now().isoformat(),
        "updated":     datetime.now().isoformat(),
        "progress":    0,          # 0-100
        "steps_done":  [],
        "next_action": "",
        "notes":       [],
    }
    goals.append(g)
    save_goals(user_id, goals)
    return g


# ══════════════════════════════════════════════════════════════════
# HYPOTHESIS + EXPERIMENT ENGINE
# ══════════════════════════════════════════════════════════════════

def load_hypotheses() -> list[dict]:
    _ensure_dirs()
    if HYPOTHESES_FILE.exists():
        try:
            return json.loads(HYPOTHESES_FILE.read_text())
        except Exception:
            pass
    return []


def save_hypotheses(hyps: list[dict]):
    _ensure_dirs()
    HYPOTHESES_FILE.write_text(json.dumps(hyps, indent=2, ensure_ascii=False))


def add_hypothesis(statement: str, proposed_test: str = "") -> dict:
    hyps = load_hypotheses()
    h = {
        "id":           f"hyp_{int(time.time() * 1000)}",
        "statement":    statement,
        "proposed_test": proposed_test,
        "status":       "untested",   # untested / testing / confirmed / refuted
        "confidence":   0.5,
        "experiments":  [],
        "created":      datetime.now().isoformat(),
    }
    hyps.append(h)
    save_hypotheses(hyps)
    return h


def record_experiment(hyp_id: str, method: str, result: str,
                      supports: bool, confidence_change: float = 0.15):
    """Record a completed experiment and update hypothesis confidence."""
    hyps = load_hypotheses()
    for h in hyps:
        if h["id"] == hyp_id:
            exp = {
                "ts":       datetime.now().isoformat(),
                "method":   method,
                "result":   result,
                "supports": supports,
            }
            h["experiments"].append(exp)
            if supports:
                h["confidence"] = min(1.0, h["confidence"] + confidence_change)
            else:
                h["confidence"] = max(0.0, h["confidence"] - confidence_change)

            # Update status based on confidence
            if h["confidence"] >= 0.85:
                h["status"] = "confirmed"
                add_belief(h["statement"], h["confidence"], "experiment", "hypothesis")
            elif h["confidence"] <= 0.2:
                h["status"] = "refuted"
            else:
                h["status"] = "testing"
    save_hypotheses(hyps)


# ══════════════════════════════════════════════════════════════════
# RAPPORT & EMOTIONAL INTELLIGENCE
# ══════════════════════════════════════════════════════════════════

def load_rapport(user_id: int) -> dict:
    _ensure_dirs()
    rf = RAPPORT_DIR / f"{user_id}.json"
    if rf.exists():
        try:
            return json.loads(rf.read_text())
        except Exception:
            pass
    return {
        "trust_level":       0.5,    # 0-1: grows through positive interactions
        "familiarity":       0,      # interaction count
        "communication_style": "balanced",  # formal / casual / technical / balanced
        "expertise_level":   "general",   # beginner / general / expert
        "emotional_state":   "neutral",   # current detected emotion
        "mood_history":      [],     # last 10 mood readings
        "rapport_notes":     [],     # things agent noticed about the relationship
        "preferred_length":  "auto", # brief / detailed / auto
        "last_seen":         None,
        "streak_days":       0,      # consecutive days interacted
        "milestones":        [],     # relationship milestones
    }


def save_rapport(user_id: int, rapport: dict):
    _ensure_dirs()
    rf = RAPPORT_DIR / f"{user_id}.json"
    rf.write_text(json.dumps(rapport, indent=2, ensure_ascii=False))
    rf.chmod(0o600)


EMOTION_SIGNALS = {
    # Negative
    "frustrated": ["frustrated", "annoying", "doesn't work", "broken", "useless", "hate", "terrible", "waste", "ugh", "argh"],
    "stressed":   ["stressed", "overwhelmed", "too much", "deadline", "urgent", "emergency", "running out of time", "behind"],
    "sad":        ["sad", "depressed", "down", "upset", "disappointed", "unhappy", "worried", "anxious"],
    "angry":      ["angry", "furious", "outrageous", "ridiculous", "stupid", "idiot", "wtf", "are you serious"],
    # Positive
    "happy":      ["great", "awesome", "excellent", "fantastic", "love it", "perfect", "amazing", "brilliant", "thank you", "thanks"],
    "excited":    ["excited", "can't wait", "finally", "yes!", "wow", "incredible", "this is great", "let's go"],
    "curious":    ["wondering", "curious", "how does", "why does", "what if", "interesting", "tell me more"],
    # Neutral
    "focused":    ["need to", "let's", "i want to", "please", "can you", "help me", "i need"],
    "tired":      ["tired", "exhausted", "sleepy", "can't focus", "need coffee", "been working", "long day"],
}

EMPATHY_RESPONSES = {
    "frustrated": "I can see that's been frustrating. Let me help fix this properly.",
    "stressed":   "Sounds like you have a lot on your plate. I'll keep this efficient.",
    "sad":        "I hear you. Let me make this as easy as possible for you.",
    "angry":      "That sounds genuinely aggravating. Let's sort this out.",
    "happy":      "Great to hear things are going well!",
    "excited":    "Your enthusiasm is contagious — let's make it happen!",
    "tired":      "Understood. I'll give you clear, concise answers so you can focus.",
    "curious":    "Great question — I enjoy exploring this kind of thing.",
    "focused":    "",  # no preamble for focused users — just get to work
    "neutral":    "",
}


def detect_emotion(text: str) -> str:
    """Detect emotional state from message text. Returns emotion label."""
    text_lower = text.lower()
    scores: dict[str, int] = {}
    for emotion, signals in EMOTION_SIGNALS.items():
        score = sum(1 for s in signals if s in text_lower)
        if score > 0:
            scores[emotion] = score
    if not scores:
        return "neutral"
    return max(scores, key=lambda e: scores[e])


def update_rapport_after_message(user_id: int, text: str, was_helpful: bool = True):
    """Update rapport profile after each interaction."""
    rapport = load_rapport(user_id)
    rapport["familiarity"] = rapport.get("familiarity", 0) + 1

    # Emotion detection
    emotion = detect_emotion(text)
    rapport["emotional_state"] = emotion
    mood_history = rapport.get("mood_history", [])
    mood_history.append({"ts": datetime.now().isoformat(), "emotion": emotion})
    rapport["mood_history"] = mood_history[-20:]  # keep last 20

    # Trust grows with positive interactions
    if was_helpful:
        rapport["trust_level"] = min(1.0, rapport.get("trust_level", 0.5) + 0.01)

    # Style detection from text — technical checked BEFORE formal to avoid misclassification
    word_count = len(text.split())
    text_lower = text.lower()
    if word_count < 5 and "." not in text:
        rapport["communication_style"] = "casual"
    elif any(w in text_lower for w in ["api", "function", "code", "script", "bash", "python", "debug",
                                        "sql", "git", "docker", "terminal", "command", "regex"]):
        rapport["communication_style"] = "technical"
    elif any(w in text_lower for w in ["please", "could you", "would you kindly", "i request"]):
        rapport["communication_style"] = "formal"

    # Update last seen + streak
    last_seen_str = rapport.get("last_seen")
    now = datetime.now()
    rapport["last_seen"] = now.isoformat()
    if last_seen_str:
        try:
            last_seen = datetime.fromisoformat(last_seen_str)
            if (now - last_seen).days == 1:
                rapport["streak_days"] = rapport.get("streak_days", 0) + 1
            elif (now - last_seen).days > 1:
                rapport["streak_days"] = 1
        except Exception:
            pass

    # Milestones
    fam = rapport["familiarity"]
    for milestone in [10, 50, 100, 500, 1000]:
        if fam == milestone and str(milestone) not in str(rapport.get("milestones", [])):
            rapport.setdefault("milestones", []).append({
                "interactions": milestone,
                "achieved": now.isoformat()
            })
    save_rapport(user_id, rapport)
    return emotion


def build_personality_context(user_id: int) -> str:
    """Build personality + communication style context for AI system prompt."""
    rapport = load_rapport(user_id)
    mem = load_memory(user_id)
    style = rapport.get("communication_style", "balanced")
    emotion = rapport.get("emotional_state", "neutral")
    trust = rapport.get("trust_level", 0.5)
    fam = rapport.get("familiarity", 0)
    pref_length = rapport.get("preferred_length", "auto")
    expertise = rapport.get("expertise_level", "general")

    empathy_note = EMPATHY_RESPONSES.get(emotion, "")

    length_inst = {
        "brief":    "Keep responses very concise — 1-3 sentences unless more is needed.",
        "detailed": "Give thorough, detailed responses with context and examples.",
        "auto":     "Match response length to the complexity of the question.",
    }.get(pref_length, "")

    style_inst = {
        "formal":    "Use formal, professional language.",
        "casual":    "Be warm, friendly and conversational — like talking to a friend.",
        "technical": "Use technical precision. Skip basics, go straight to specifics.",
        "balanced":  "Balance clarity with friendliness.",
    }.get(style, "")

    trust_note = ""
    if trust > 0.8:
        trust_note = "You have a strong, established relationship. You can be direct and candid."
    elif trust > 0.6:
        trust_note = "You have a good working relationship. Be helpful and supportive."
    elif fam < 5:
        trust_note = "This is an early interaction. Be welcoming and establish trust."

    expertise_inst = {
        "beginner": "Explain things clearly without assuming technical knowledge. Use analogies.",
        "expert":   "Assume strong technical knowledge. Skip basics. Be precise and efficient.",
        "general":  "Assume general intelligence but don't assume domain expertise.",
    }.get(expertise, "")

    name = mem.get("name", "")
    name_note = f"Address the user as {name}." if name else ""

    parts = [
        "[PERSONALITY & COMMUNICATION CONTEXT]",
        f"Communication style: {style}. {style_inst}",
        f"Response length preference: {pref_length}. {length_inst}",
        f"User expertise level: {expertise}. {expertise_inst}",
        f"Trust level: {trust:.0%}. {trust_note}",
        f"Detected emotion: {emotion}.",
    ]
    if empathy_note:
        parts.append(f"Empathy note: {empathy_note}")
    if name_note:
        parts.append(name_note)

    return "\n".join(p for p in parts if p.strip())


# ══════════════════════════════════════════════════════════════════
# PERFORMANCE TRACKING
# ══════════════════════════════════════════════════════════════════

def load_performance() -> dict:
    _ensure_dirs()
    if PERF_FILE.exists():
        try:
            return json.loads(PERF_FILE.read_text())
        except Exception:
            pass
    return {"tasks": [], "strategies": {}, "failures": {}}


def save_performance(perf: dict):
    _ensure_dirs()
    PERF_FILE.write_text(json.dumps(perf, indent=2, ensure_ascii=False))


def record_task_outcome(task_type: str, success: bool, strategy: str,
                        steps: int, goal: str = ""):
    """Record whether a task succeeded — used for strategy evolution."""
    perf = load_performance()
    perf["tasks"].append({
        "ts":        datetime.now().isoformat(),
        "type":      task_type,
        "success":   success,
        "strategy":  strategy,
        "steps":     steps,
        "goal_preview": goal[:60],
    })
    perf["tasks"] = perf["tasks"][-200:]  # keep last 200

    # Update strategy win/loss counts
    s = perf["strategies"].setdefault(strategy, {"wins": 0, "losses": 0})
    if success:
        s["wins"] += 1
    else:
        s["losses"] += 1

    # Track failure patterns
    if not success:
        failure_key = f"{task_type}::{strategy}"
        perf["failures"][failure_key] = perf["failures"].get(failure_key, 0) + 1

    save_performance(perf)


def get_best_strategy(task_type: str) -> str:
    """Pick best strategy for a task type based on historical win rates."""
    perf = load_performance()
    best = "default"
    best_rate = 0.0
    for strategy, counts in perf["strategies"].items():
        total = counts["wins"] + counts["losses"]
        if total >= 3:  # minimum sample size
            rate = counts["wins"] / total
            if rate > best_rate:
                best_rate = rate
                best = strategy
    return best


# ══════════════════════════════════════════════════════════════════
# DEEP THINKING ENGINE
# ══════════════════════════════════════════════════════════════════

DEEP_THINK_SYSTEM = """You are Salim's deep reasoning engine. Unlike a normal assistant, you:
1. Think step by step, showing your actual reasoning process
2. Form hypotheses and test them mentally
3. Consider multiple angles and counterarguments
4. Identify what you know vs. what you're uncertain about
5. Propose concrete next actions after your reasoning
6. Learn from past failures stored in your belief system

Reasoning format:
OBSERVE: What do I know about this situation?
HYPOTHESIZE: What might explain this / what could work?
CHALLENGE: What could be wrong with my hypothesis?
SYNTHESIZE: What is my best current understanding?
ACT: What is the single most useful next step?
LEARN: What belief or knowledge update does this trigger?

Be intellectually honest. Say when you're uncertain. Don't oversimplify."""

KNOWLEDGE_GAP_SYSTEM = """You are Salim's knowledge gap detector. 
Given a user's goal or question, identify:
1. What information is MISSING that would help solve this better
2. What ASSUMPTIONS are being made that should be verified
3. What EXPERIMENTS or data collection could resolve the uncertainty
4. What RELATED KNOWLEDGE would strengthen the solution

Return as JSON:
{
  "gaps": [{"gap": "description", "severity": "high|medium|low", "how_to_fill": "..."}],
  "assumptions": [{"assumption": "...", "risk_if_wrong": "..."}],
  "experiments": [{"test": "...", "expected_outcome": "...", "time_to_run": "..."}],
  "related_knowledge": ["topic1", "topic2"]
}"""


async def deep_think(problem: str, user_id: int, ai_instance,
                     beliefs: list[dict] = None) -> str:
    """
    Run multi-step deep reasoning on a problem.
    Incorporates the agent's belief system and past experiences.
    """
    belief_context = ""
    if beliefs:
        relevant = [b for b in beliefs if any(
            w.lower() in problem.lower() for w in b["statement"].split()[:4]
        )][:5]
        if relevant:
            belief_context = "\n\nRELEVANT BELIEFS FROM KNOWLEDGE BASE:\n"
            for b in relevant:
                belief_context += f"- [{b['confidence']:.0%} confident] {b['statement']}\n"

    perf = load_performance()
    failure_note = ""
    for failure_key, count in perf.get("failures", {}).items():
        if count >= 2 and any(w.lower() in problem.lower() for w in failure_key.split("::")):
            failure_note += f"\nPAST FAILURE WARNING: '{failure_key}' has failed {count} times — try a different approach."

    prompt = f"""Problem to reason about deeply:

{problem}
{belief_context}
{failure_note}

Apply your step-by-step reasoning framework (OBSERVE → HYPOTHESIZE → CHALLENGE → SYNTHESIZE → ACT → LEARN).
End with concrete, actionable recommendations."""

    try:
        raw, _ = await ai_instance._call_with_fallback(
            [{"role": "user", "content": prompt}],
            system=DEEP_THINK_SYSTEM,
            max_tokens=1500,
            temperature=0.4,
        )
        return raw
    except Exception as e:
        return f"Deep thinking failed: {e}"


async def detect_knowledge_gaps(goal: str, ai_instance) -> dict:
    """Use AI to identify knowledge gaps and missing information for a goal."""
    try:
        raw, _ = await ai_instance._call_with_fallback(
            [{"role": "user", "content": f"Analyze knowledge gaps for this goal:\n\n{goal}"}],
            system=KNOWLEDGE_GAP_SYSTEM,
            max_tokens=800,
            temperature=0.3,
        )
        raw = re.sub(r"```(?:json)?|```", "", raw).strip()
        return json.loads(raw)
    except Exception as e:
        logger.debug(f"Gap detection failed: {e}")
        return {"gaps": [], "assumptions": [], "experiments": [], "related_knowledge": []}


async def design_experiment(hypothesis: str, ai_instance) -> str:
    """Ask AI to design a concrete experiment to test a hypothesis."""
    try:
        raw, _ = await ai_instance._call_with_fallback(
            [{"role": "user", "content": f"""Design a minimal, concrete experiment to test this hypothesis:

HYPOTHESIS: {hypothesis}

Output a specific, executable test plan:
1. What to do (concrete steps)
2. What to measure/observe
3. What result would CONFIRM the hypothesis
4. What result would REFUTE the hypothesis
5. Estimated time to complete
6. Tools/resources needed

Be specific and practical. Avoid vague suggestions."""}],
            system="You are a scientific experiment designer. Design minimal, executable tests.",
            max_tokens=600,
            temperature=0.3,
        )
        return raw
    except Exception as e:
        return f"Experiment design failed: {e}"


async def self_assess(user_id: int, ai_instance) -> str:
    """
    Agent self-assessment: analyzes its own performance, identifies weaknesses,
    proposes improvement strategies.
    """
    perf   = load_performance()
    beliefs = load_beliefs()
    hyps   = load_hypotheses()
    rapport = load_rapport(user_id)
    goals  = load_goals(user_id)

    total_tasks = len(perf["tasks"])
    recent      = perf["tasks"][-20:] if perf["tasks"] else []
    success_rate = sum(1 for t in recent if t.get("success")) / max(len(recent), 1)
    common_fails = sorted(perf.get("failures", {}).items(), key=lambda x: -x[1])[:3]
    active_goals = [g for g in goals if g.get("status") == "active"]
    confirmed_hyps = [h for h in hyps if h.get("status") == "confirmed"]

    context = f"""My performance data for self-assessment:
- Total tasks completed: {total_tasks}
- Recent success rate: {success_rate:.0%} (last {len(recent)} tasks)
- Most common failure patterns: {[f[0] for f in common_fails]}
- Active goals: {len(active_goals)} ({', '.join(g['title'][:30] for g in active_goals[:3])})
- Confirmed hypotheses: {len(confirmed_hyps)}
- Beliefs in knowledge base: {len(beliefs)}
- Relationship trust level: {rapport.get('trust_level', 0.5):.0%}
- Interaction count: {rapport.get('familiarity', 0)}

Strategies and win rates:
{json.dumps(perf.get('strategies', {}), indent=2)}"""

    try:
        raw, _ = await ai_instance._call_with_fallback(
            [{"role": "user", "content": context}],
            system="""You are performing an honest self-assessment of your performance as an AI assistant.
Analyze the data provided and:
1. Identify your 3 biggest strengths based on evidence
2. Identify your 3 biggest weaknesses or failure patterns
3. Propose specific improvement strategies for each weakness
4. Suggest what experiments to run to validate improvements
5. Set 3 concrete goals for the next week to become more helpful
Be intellectually honest. Don't oversell your capabilities.""",
            max_tokens=1000,
            temperature=0.4,
        )
        return raw
    except Exception as e:
        return f"Self-assessment failed: {e}"


# ══════════════════════════════════════════════════════════════════
# GOAL AUTOPILOT — background goal pursuit
# ══════════════════════════════════════════════════════════════════

async def advance_goal(goal: dict, user_id: int, ai_instance, bot) -> str | None:
    """
    Autonomously advance one goal. Called by heartbeat periodically.
    Returns a status update to send the user if significant progress was made.
    """
    if goal.get("status") != "active":
        return None

    title    = goal["title"]
    progress = goal.get("progress", 0)
    done     = goal.get("steps_done", [])
    next_act = goal.get("next_action", "")

    prompt = f"""I am autonomously working toward this goal:
GOAL: {title}
CURRENT PROGRESS: {progress}%
STEPS ALREADY DONE: {json.dumps(done[-5:])}
PLANNED NEXT ACTION: {next_act or 'none planned yet'}

What is the single most productive thing I can do RIGHT NOW to advance this goal?
Be concrete — give one specific, executable action, not general advice.
Also estimate the new progress % after this action.
Reply as JSON: {{"action": "...", "rationale": "...", "new_progress": 0-100, "next_after_this": "..."}}"""

    try:
        raw, _ = await ai_instance._call_with_fallback(
            [{"role": "user", "content": prompt}],
            system="You are a goal advancement engine. Output only valid JSON.",
            max_tokens=400,
            temperature=0.3,
        )
        raw = re.sub(r"```(?:json)?|```", "", raw).strip()
        result = json.loads(raw)

        # Update goal state
        goals = load_goals(user_id)
        for g in goals:
            if g["id"] == goal["id"]:
                g["steps_done"].append({
                    "action": result.get("action", ""),
                    "ts":     datetime.now().isoformat(),
                })
                g["progress"]    = result.get("new_progress", progress)
                g["next_action"] = result.get("next_after_this", "")
                g["updated"]     = datetime.now().isoformat()
                if g["progress"] >= 100:
                    g["status"] = "done"
        save_goals(user_id, goals)

        if result.get("new_progress", progress) > progress:
            return (
                f"🎯 <b>Goal Update: {_esc(title)}</b>\n\n"
                f"✅ Completed: {_esc(result.get('action', ''))}\n"
                f"📊 Progress: {progress}% → {result.get('new_progress', progress)}%\n"
                f"➡️ Next: {_esc(result.get('next_after_this', ''))}"
            )
    except Exception as e:
        logger.debug(f"Goal advance error: {e}")
    return None


# ══════════════════════════════════════════════════════════════════
# TELEGRAM COMMAND HANDLERS
# ══════════════════════════════════════════════════════════════════

class AdvancedAgentHandlers:
    """Mixin for SalimBot — adds advanced autonomous reasoning commands."""

    @require_auth
    async def cmd_think(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /think <problem> — deep autonomous multi-step reasoning.
        Agent thinks through the problem using OBSERVE→HYPOTHESIZE→CHALLENGE→SYNTHESIZE→ACT→LEARN.
        """
        msg     = update.effective_message
        user_id = update.effective_user.id
        problem = " ".join(ctx.args) if ctx.args else ""

        if not problem:
            await msg.reply_text(
                "🧠 <b>Deep Thinking Mode</b>\n\n"
                "I'll reason through complex problems step by step:\n\n"
                "<code>/think why is my Python script slow</code>\n"
                "<code>/think how can I grow my freelance business</code>\n"
                "<code>/think best architecture for a real-time chat app</code>\n"
                "<code>/think should I switch from React to Vue</code>\n\n"
                "<i>I use Observe → Hypothesize → Challenge → Synthesize → Act → Learn</i>",
                parse_mode="HTML"
            )
            return

        # Detect emotion and update rapport
        emotion = update_rapport_after_message(user_id, problem)
        empathy = EMPATHY_RESPONSES.get(emotion, "")

        thinking_msg = await msg.reply_text(
            f"{'💙 ' + empathy + ' ' if empathy else ''}🧠 <b>Thinking deeply…</b>\n\n"
            f"<i>Analyzing: {_esc(problem[:80])}</i>",
            parse_mode="HTML"
        )

        beliefs = load_beliefs()
        result  = await deep_think(problem, user_id, self._ai, beliefs)

        # Extract any new beliefs from the reasoning
        belief_extracts = re.findall(r"LEARN:\s*(.+?)(?:\n|$)", result, re.IGNORECASE)
        for extract in belief_extracts[:3]:
            clean = extract.strip()
            if len(clean) > 20:
                add_belief(clean, confidence=0.6, source="reasoning", category="inferred")

        record_task_outcome("deep_think", True, "chain_of_thought", 1, problem)

        # Chunk long responses
        if len(result) > 3000:
            chunks = [result[i:i+3000] for i in range(0, len(result), 3000)]
            await thinking_msg.edit_text(
                f"🧠 <b>Deep Analysis</b>\n\n{chunks[0]}",
                parse_mode="HTML"
            )
            for chunk in chunks[1:]:
                await msg.reply_text(chunk, parse_mode="HTML")
        else:
            await thinking_msg.edit_text(
                f"🧠 <b>Deep Analysis</b>\n\n{result}",
                parse_mode="HTML"
            )

    @require_auth
    async def cmd_goal(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /goal set <title>         — set a persistent background goal
        /goal list                — view all goals + progress
        /goal done <id>           — mark goal complete
        /goal cancel <id>         — cancel a goal
        /goal update <id> <note>  — add progress note
        /goal gaps <id>           — detect knowledge gaps for a goal
        """
        msg     = update.effective_message
        user_id = update.effective_user.id
        args    = ctx.args or []
        sub     = args[0].lower() if args else "list"

        if sub == "set":
            title = " ".join(args[1:])
            if not title:
                await msg.reply_text(
                    "Usage: <code>/goal set Learn Python async programming</code>\n\n"
                    "Goals are tracked autonomously. Salim will:\n"
                    "• Break them into steps\n"
                    "• Check in with progress updates\n"
                    "• Proactively suggest next actions\n"
                    "• Alert you when blocked",
                    parse_mode="HTML"
                )
                return

            await msg.reply_text(f"🎯 Setting up goal: <i>{_esc(title)}</i>…", parse_mode="HTML")

            # AI-enhanced goal decomposition
            try:
                raw, _ = await self._ai._call_with_fallback(
                    [{"role": "user", "content": f"""Break this goal into a clear plan:
GOAL: {title}

Return JSON:
{{
  "refined_title": "cleaner version of the goal",
  "description": "1-2 sentence goal description",
  "priority": "high|medium|low",
  "horizon": "today|this week|this month|ongoing",
  "first_action": "the single most important first step",
  "success_criteria": "how will I know when this is done"
}}"""}],
                    system="You are a goal-setting coach. Output only valid JSON.",
                    max_tokens=400,
                    temperature=0.3,
                )
                raw = re.sub(r"```(?:json)?|```", "", raw).strip()
                plan = json.loads(raw)
                g = add_goal(
                    user_id,
                    plan.get("refined_title", title),
                    plan.get("description", ""),
                    plan.get("priority", "medium"),
                    plan.get("horizon", "this week"),
                )
                g["next_action"]      = plan.get("first_action", "")
                g["success_criteria"] = plan.get("success_criteria", "")
                goals = load_goals(user_id)
                for existing in goals:
                    if existing["id"] == g["id"]:
                        existing.update(g)
                save_goals(user_id, goals)

                await msg.reply_text(
                    f"✅ <b>Goal Set</b>\n\n"
                    f"🎯 <b>{_esc(g['title'])}</b>\n"
                    f"📝 {_esc(plan.get('description', ''))}\n"
                    f"⚡ Priority: {g['priority']}  ·  Horizon: {g['horizon']}\n"
                    f"➡️ First action: <i>{_esc(g['next_action'])}</i>\n"
                    f"✓ Done when: <i>{_esc(g.get('success_criteria', ''))}</i>\n\n"
                    f"<i>ID: <code>{g['id']}</code>  ·  Track with /goal list</i>",
                    parse_mode="HTML"
                )
            except Exception as e:
                g = add_goal(user_id, title)
                await msg.reply_text(
                    f"✅ <b>Goal added:</b> {_esc(title)}\n\n"
                    f"<i>ID: <code>{g['id']}</code></i>",
                    parse_mode="HTML"
                )
            return

        if sub == "list":
            goals = load_goals(user_id)
            if not goals:
                await msg.reply_text(
                    "📋 No goals yet.\n\n"
                    "Set one: <code>/goal set Learn Python async programming</code>",
                    parse_mode="HTML"
                )
                return

            active   = [g for g in goals if g.get("status") == "active"]
            done     = [g for g in goals if g.get("status") == "done"]
            lines    = [f"🎯 <b>Goals ({len(active)} active, {len(done)} done)</b>\n"]

            PRIORITY_ICONS = {"high": "🔴", "medium": "🟡", "low": "🟢"}
            for g in sorted(active, key=lambda x: {"high": 0, "medium": 1, "low": 2}.get(x.get("priority", "medium"), 1)):
                icon    = PRIORITY_ICONS.get(g.get("priority", "medium"), "⚪")
                prog    = g.get("progress", 0)
                bar     = "█" * (prog // 10) + "░" * (10 - prog // 10)
                next_a  = g.get("next_action", "")
                lines.append(
                    f"{icon} <b>{_esc(g['title'])}</b>\n"
                    f"   [{bar}] {prog}%\n"
                    + (f"   ➡️ Next: <i>{_esc(next_a[:60])}</i>\n" if next_a else "")
                    + f"   ID: <code>{g['id']}</code>"
                )

            if done:
                lines.append(f"\n✅ <b>Completed ({len(done)}):</b>")
                for g in done[-3:]:
                    lines.append(f"  • {_esc(g['title'])}")

            lines.append(
                "\n<i>/goal done &lt;id&gt; · /goal cancel &lt;id&gt; · /goal gaps &lt;id&gt;</i>"
            )
            await msg.reply_text("\n\n".join(lines), parse_mode="HTML")
            return

        if sub in ("done", "cancel") and len(args) >= 2:
            gid    = args[1]
            goals  = load_goals(user_id)
            new_status = "done" if sub == "done" else "cancelled"
            matched = False
            for g in goals:
                if gid in g.get("id", ""):
                    g["status"]  = new_status
                    g["updated"] = datetime.now().isoformat()
                    matched = True
                    title = g["title"]
                    if new_status == "done":
                        g["progress"] = 100
            if matched:
                save_goals(user_id, goals)
                icon = "✅" if new_status == "done" else "🗑️"
                await msg.reply_text(f"{icon} Goal {new_status}: <b>{_esc(title)}</b>", parse_mode="HTML")
            else:
                await msg.reply_text(f"❌ Goal not found: <code>{_esc(gid)}</code>", parse_mode="HTML")
            return

        if sub == "gaps" and len(args) >= 2:
            gid   = args[1]
            goals = load_goals(user_id)
            goal  = next((g for g in goals if gid in g.get("id", "")), None)
            if not goal:
                await msg.reply_text(f"❌ Goal not found: <code>{_esc(gid)}</code>", parse_mode="HTML")
                return

            await msg.reply_text(f"🔍 Analyzing knowledge gaps for: <i>{_esc(goal['title'])}</i>…", parse_mode="HTML")
            gaps = await detect_knowledge_gaps(goal["title"] + " " + goal.get("description", ""), self._ai)

            lines = [f"🔍 <b>Knowledge Gaps: {_esc(goal['title'])}</b>\n"]

            if gaps.get("gaps"):
                lines.append("❓ <b>Information gaps:</b>")
                for gap in gaps["gaps"][:4]:
                    sev = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(gap.get("severity", "medium"), "⚪")
                    lines.append(f"  {sev} {_esc(gap['gap'])}\n     → {_esc(gap.get('how_to_fill', ''))}")

            if gaps.get("assumptions"):
                lines.append("\n⚠️ <b>Assumptions to verify:</b>")
                for a in gaps["assumptions"][:3]:
                    lines.append(f"  • {_esc(a['assumption'])}")

            if gaps.get("experiments"):
                lines.append("\n🧪 <b>Suggested experiments:</b>")
                for e in gaps["experiments"][:3]:
                    lines.append(f"  • {_esc(e['test'])}")

            await msg.reply_text("\n".join(lines), parse_mode="HTML")
            return

        if sub == "update" and len(args) >= 3:
            gid   = args[1]
            note  = " ".join(args[2:])
            goals = load_goals(user_id)
            for g in goals:
                if gid in g.get("id", ""):
                    g.setdefault("notes", []).append({
                        "note": note,
                        "ts":   datetime.now().isoformat()
                    })
                    g["updated"] = datetime.now().isoformat()
                    save_goals(user_id, goals)
                    await msg.reply_text(f"📝 Note added to goal.", parse_mode="HTML")
                    return
            await msg.reply_text("❌ Goal not found.")
            return

        await msg.reply_text(
            "🎯 <b>Goal Commands</b>\n\n"
            "<code>/goal set &lt;title&gt;</code>      — set a new goal\n"
            "<code>/goal list</code>           — view all goals\n"
            "<code>/goal done &lt;id&gt;</code>   — mark complete\n"
            "<code>/goal cancel &lt;id&gt;</code> — cancel a goal\n"
            "<code>/goal gaps &lt;id&gt;</code>   — detect knowledge gaps\n"
            "<code>/goal update &lt;id&gt; &lt;note&gt;</code> — add note",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_hypo(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /hypo add <hypothesis>    — add a hypothesis
        /hypo list                — list all with confidence levels
        /hypo test <id>           — design experiment to test it
        /hypo confirm <id>        — mark as confirmed by observation
        /hypo refute <id>         — mark as refuted
        """
        msg  = update.effective_message
        args = ctx.args or []
        sub  = args[0].lower() if args else "list"

        if sub == "add":
            statement = " ".join(args[1:])
            if not statement:
                await msg.reply_text(
                    "Usage: <code>/hypo add if I optimize my database queries, the app will be 3x faster</code>\n\n"
                    "Hypotheses are tested through designed experiments.\n"
                    "Confirmed hypotheses enter the agent's belief system.",
                    parse_mode="HTML"
                )
                return
            h = add_hypothesis(statement)
            await msg.reply_text(
                f"🧪 <b>Hypothesis Added</b>\n\n"
                f"📝 <i>{_esc(statement)}</i>\n"
                f"📊 Initial confidence: 50%\n"
                f"ID: <code>{h['id']}</code>\n\n"
                f"Run <code>/hypo test {h['id']}</code> to design an experiment.",
                parse_mode="HTML"
            )
            return

        if sub == "list":
            hyps = load_hypotheses()
            if not hyps:
                await msg.reply_text(
                    "🧪 No hypotheses yet.\n\n"
                    "Add one: <code>/hypo add if X then Y</code>",
                    parse_mode="HTML"
                )
                return
            lines = [f"🧪 <b>Hypotheses ({len(hyps)})</b>\n"]
            STATUS_ICONS = {"untested": "❓", "testing": "🔬", "confirmed": "✅", "refuted": "❌"}
            for h in hyps[-10:]:
                icon  = STATUS_ICONS.get(h.get("status", "untested"), "❓")
                conf  = h.get("confidence", 0.5)
                exps  = len(h.get("experiments", []))
                lines.append(
                    f"{icon} <b>{_esc(h['statement'][:80])}</b>\n"
                    f"   Confidence: {conf:.0%}  ·  Experiments: {exps}  ·  ID: <code>{h['id']}</code>"
                )
            await msg.reply_text("\n\n".join(lines), parse_mode="HTML")
            return

        if sub == "test" and len(args) >= 2:
            hid  = args[1]
            hyps = load_hypotheses()
            h    = next((x for x in hyps if hid in x.get("id", "")), None)
            if not h:
                await msg.reply_text(f"❌ Hypothesis not found: <code>{_esc(hid)}</code>", parse_mode="HTML")
                return
            await msg.reply_text(
                f"🔬 Designing experiment for:\n<i>{_esc(h['statement'])}</i>…",
                parse_mode="HTML"
            )
            experiment_plan = await design_experiment(h["statement"], self._ai)
            record_experiment(hid, "ai_designed", experiment_plan[:100], True, 0.05)
            await msg.reply_text(
                f"🔬 <b>Experiment Design</b>\n"
                f"Hypothesis: <i>{_esc(h['statement'][:80])}</i>\n\n"
                f"{experiment_plan[:2000]}",
                parse_mode="HTML"
            )
            return

        if sub in ("confirm", "refute") and len(args) >= 2:
            hid      = args[1]
            supports = sub == "confirm"
            evidence = " ".join(args[2:]) if len(args) > 2 else "manual observation"
            record_experiment(hid, "manual", evidence, supports, 0.3)
            hyps = load_hypotheses()
            h = next((x for x in hyps if hid in x.get("id", "")), None)
            if h:
                icon = "✅" if supports else "❌"
                await msg.reply_text(
                    f"{icon} Hypothesis {sub}d.\n"
                    f"New confidence: {h.get('confidence', 0.5):.0%}\n"
                    f"Status: {h.get('status', 'testing')}",
                    parse_mode="HTML"
                )
            else:
                await msg.reply_text("❌ Hypothesis not found.")
            return

        await msg.reply_text(
            "🧪 <b>Hypothesis Commands</b>\n\n"
            "<code>/hypo add if X then Y</code>   — add hypothesis\n"
            "<code>/hypo list</code>               — view all\n"
            "<code>/hypo test &lt;id&gt;</code>    — design experiment\n"
            "<code>/hypo confirm &lt;id&gt;</code> — mark confirmed\n"
            "<code>/hypo refute &lt;id&gt;</code>  — mark refuted",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_beliefs(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /beliefs              — show full knowledge base
        /beliefs search <q>   — search beliefs
        /beliefs add <text>   — manually add a belief
        /beliefs clear        — wipe belief system
        """
        msg  = update.effective_message
        args = ctx.args or []
        sub  = args[0].lower() if args else "show"

        if sub == "add":
            statement = " ".join(args[1:])
            if not statement:
                await msg.reply_text("Usage: <code>/beliefs add Python is faster than R for large data pipelines</code>", parse_mode="HTML")
                return
            b = add_belief(statement, confidence=0.9, source="user_asserted")
            await msg.reply_text(
                f"✅ Belief added to knowledge base.\n"
                f"<i>{_esc(statement)}</i>\n"
                f"Confidence: 90%",
                parse_mode="HTML"
            )
            return

        beliefs = load_beliefs()

        if sub == "search" and len(args) >= 2:
            query  = " ".join(args[1:]).lower()
            hits   = [b for b in beliefs if query in b["statement"].lower()]
            if not hits:
                await msg.reply_text(f"🔍 No beliefs matching '<b>{_esc(query)}</b>'.", parse_mode="HTML")
                return
            beliefs = hits

        if sub == "clear":
            save_beliefs([])
            await msg.reply_text("🗑️ Belief system cleared.")
            return

        if not beliefs:
            await msg.reply_text(
                "🧠 No beliefs yet.\n\n"
                "Beliefs build up as the agent:\n"
                "• Completes deep thinking (/think)\n"
                "• Confirms hypotheses (/hypo confirm)\n"
                "• You assert facts (/beliefs add)\n"
                "• Runs experiments (/hypo test)",
                parse_mode="HTML"
            )
            return

        # Group by category
        from collections import defaultdict
        by_cat: dict = defaultdict(list)
        for b in sorted(beliefs, key=lambda x: -x.get("confidence", 0)):
            by_cat[b.get("category", "general")].append(b)

        lines = [f"🧠 <b>Knowledge Base ({len(beliefs)} beliefs)</b>\n"]
        for cat, cat_beliefs in sorted(by_cat.items()):
            lines.append(f"📂 <b>{cat.title()}</b>")
            for b in cat_beliefs[:5]:
                conf = b.get("confidence", 0.5)
                bar  = "█" * int(conf * 5) + "░" * (5 - int(conf * 5))
                src  = b.get("source", "unknown")[:10]
                lines.append(
                    f"  [{bar}] {conf:.0%}  <i>{_esc(b['statement'][:80])}</i>\n"
                    f"           <code>{src}</code>"
                )

        lines.append("\n<i>/beliefs add &lt;text&gt; · /beliefs search &lt;q&gt; · /beliefs clear</i>")
        await msg.reply_text("\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_rapport(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /rapport              — show relationship profile and communication style
        /rapport set style formal|casual|technical|balanced
        /rapport set length brief|detailed|auto
        /rapport set expertise beginner|general|expert
        /rapport reset        — reset rapport profile
        """
        msg     = update.effective_message
        user_id = update.effective_user.id
        args    = ctx.args or []
        sub     = args[0].lower() if args else "show"

        rapport = load_rapport(user_id)

        if sub == "set" and len(args) >= 3:
            key = args[1].lower()
            val = args[2].lower()
            key_map = {
                "style":     "communication_style",
                "length":    "preferred_length",
                "expertise": "expertise_level",
            }
            if key in key_map:
                rapport[key_map[key]] = val
                save_rapport(user_id, rapport)
                await msg.reply_text(f"✅ {key.title()} set to: <b>{_esc(val)}</b>", parse_mode="HTML")
            else:
                await msg.reply_text(f"❌ Unknown setting: {key}. Options: style, length, expertise")
            return

        if sub == "reset":
            rf = RAPPORT_DIR / f"{user_id}.json"
            if rf.exists():
                rf.unlink()
            await msg.reply_text("🔄 Rapport profile reset.")
            return

        # Show rapport
        trust     = rapport.get("trust_level", 0.5)
        fam       = rapport.get("familiarity", 0)
        style     = rapport.get("communication_style", "balanced")
        emotion   = rapport.get("emotional_state", "neutral")
        streak    = rapport.get("streak_days", 0)
        milestones = rapport.get("milestones", [])
        pref_len  = rapport.get("preferred_length", "auto")
        expertise = rapport.get("expertise_level", "general")

        trust_bar  = "█" * int(trust * 10) + "░" * (10 - int(trust * 10))
        trust_label = "🤝 Trusted" if trust > 0.7 else "🌱 Building" if trust > 0.4 else "👋 Getting started"

        mood_history = rapport.get("mood_history", [])
        recent_moods = [m["emotion"] for m in mood_history[-5:]]
        mood_str = " → ".join(recent_moods) if recent_moods else "no data"

        lines = [
            "🤝 <b>Relationship Profile</b>\n",
            f"👤 Trust: [{trust_bar}] {trust:.0%}  {trust_label}",
            f"💬 Interactions: {fam}  ·  🔥 Streak: {streak} days",
            f"🎭 Style: {style}  ·  📏 Length: {pref_len}  ·  🎓 Expertise: {expertise}",
            f"😊 Current emotion: {emotion}",
            f"📈 Recent mood: {mood_str}",
        ]

        if milestones:
            last_m = milestones[-1]
            lines.append(f"\n🏆 Last milestone: {last_m['interactions']} interactions!")

        lines += [
            "",
            "<b>Customize:</b>",
            "<code>/rapport set style formal|casual|technical|balanced</code>",
            "<code>/rapport set length brief|detailed|auto</code>",
            "<code>/rapport set expertise beginner|general|expert</code>",
        ]
        await msg.reply_text("\n".join(lines), parse_mode="HTML")

    @require_auth
    async def cmd_selfcheck(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /selfcheck — agent performs a comprehensive self-assessment.
        Analyzes performance, identifies weaknesses, proposes improvements.
        """
        msg     = update.effective_message
        user_id = update.effective_user.id
        thinking = await msg.reply_text(
            "🔍 <b>Running self-assessment…</b>\n\n"
            "<i>Analyzing task history, failure patterns, relationship quality, knowledge base…</i>",
            parse_mode="HTML"
        )
        result = await self_assess(user_id, self._ai)
        record_task_outcome("self_assess", True, "introspection", 1)
        await thinking.edit_text(
            f"🔍 <b>Self-Assessment Report</b>\n"
            f"<i>{datetime.now().strftime('%B %d, %Y')}</i>\n\n"
            f"{result[:3000]}",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_agentmode(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /agentmode brief      — very concise responses
        /agentmode detailed   — thorough responses with context
        /agentmode empathy    — emotion-first, supportive style
        /agentmode technical  — precision over warmth, deep detail
        /agentmode balanced   — default adaptive mode
        """
        msg     = update.effective_message
        user_id = update.effective_user.id
        args    = ctx.args or []
        mode    = args[0].lower() if args else ""

        MODES = {
            "brief":     ("📏", "brief",    "auto",     "Concise responses — just the essentials."),
            "detailed":  ("📖", "balanced", "detailed", "Thorough responses with full context and examples."),
            "empathy":   ("💙", "casual",   "auto",     "Emotion-first. I prioritize your feelings before solving problems."),
            "technical": ("⚙️", "technical","detailed", "Technical precision. Skip basics, go deep."),
            "balanced":  ("⚖️", "balanced", "auto",     "Adaptive default — matches what each situation needs."),
        }

        if mode not in MODES:
            rapport = load_rapport(user_id)
            current_style = rapport.get("communication_style", "balanced")
            current_len   = rapport.get("preferred_length", "auto")
            await msg.reply_text(
                "⚙️ <b>Agent Communication Mode</b>\n\n"
                f"Current: style=<b>{current_style}</b>  length=<b>{current_len}</b>\n\n"
                "<code>/agentmode brief</code>    — just the essentials\n"
                "<code>/agentmode detailed</code>  — full context + examples\n"
                "<code>/agentmode empathy</code>   — emotion-first support\n"
                "<code>/agentmode technical</code> — precise + deep\n"
                "<code>/agentmode balanced</code>  — adaptive (default)",
                parse_mode="HTML"
            )
            return

        icon, style, length, description = MODES[mode]
        rapport = load_rapport(user_id)
        rapport["communication_style"] = style
        rapport["preferred_length"]    = length
        save_rapport(user_id, rapport)

        await msg.reply_text(
            f"{icon} <b>Mode: {mode.title()}</b>\n\n{description}\n\n"
            f"<i>Every response from now on will adapt to this mode.\n"
            f"Change anytime with /agentmode</i>",
            parse_mode="HTML"
        )

    @require_auth
    async def cmd_probe(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /probe <topic>  — agent proactively investigates a topic, forms hypotheses,
        runs thought experiments, and reports back with structured insights.
        This is self-directed inquiry without a specific task.
        """
        msg     = update.effective_message
        user_id = update.effective_user.id
        topic   = " ".join(ctx.args) if ctx.args else ""

        if not topic:
            await msg.reply_text(
                "🔭 <b>Autonomous Inquiry Mode</b>\n\n"
                "I'll investigate a topic independently — form hypotheses, test them mentally,\n"
                "identify knowledge gaps, and build a structured understanding.\n\n"
                "<code>/probe Python performance optimization</code>\n"
                "<code>/probe machine learning for time series</code>\n"
                "<code>/probe best way to structure a startup's tech stack</code>",
                parse_mode="HTML"
            )
            return

        await msg.reply_text(f"🔭 <b>Investigating:</b> <i>{_esc(topic)}</i>…", parse_mode="HTML")

        # Parallel: deep think + gap analysis + hypothesis generation
        think_task   = asyncio.create_task(deep_think(topic, user_id, self._ai, load_beliefs()))
        gaps_task    = asyncio.create_task(detect_knowledge_gaps(topic, self._ai))

        thinking_result, gaps = await asyncio.gather(think_task, gaps_task)

        # Auto-generate hypotheses from the reasoning
        hyp_prompt = f"""Based on this analysis of "{topic}", list 3 testable hypotheses in this format:
1. If [condition] then [expected outcome]
2. If [condition] then [expected outcome]
3. If [condition] then [expected outcome]

Keep each under 20 words. Make them specific and testable."""
        try:
            raw_hyps, _ = await self._ai._call_with_fallback(
                [{"role": "user", "content": thinking_result[:1000] + "\n\n" + hyp_prompt}],
                system="Output 3 concise, testable hypotheses only.",
                max_tokens=200, temperature=0.4,
            )
            # Parse and store hypotheses
            for line in raw_hyps.strip().split("\n"):
                line = re.sub(r"^\d+\.\s*", "", line).strip()
                if len(line) > 20 and "if" in line.lower():
                    add_hypothesis(line, f"Generated from probe on: {topic}")
        except Exception:
            pass

        lines = [
            f"🔭 <b>Autonomous Investigation: {_esc(topic)}</b>\n",
            thinking_result[:2000],
        ]

        if gaps.get("gaps"):
            lines += ["\n❓ <b>Knowledge gaps identified:</b>"]
            for g in gaps["gaps"][:3]:
                sev = {"high": "🔴", "medium": "🟡", "low": "🟢"}.get(g.get("severity", "medium"), "⚪")
                lines.append(f"  {sev} {_esc(g['gap'])}")

        lines.append("\n<i>Hypotheses generated and stored — view with /hypo list</i>")
        result_text = "\n".join(lines)

        if len(result_text) > 3800:
            await msg.reply_text(result_text[:3800], parse_mode="HTML")
            await msg.reply_text(result_text[3800:6000], parse_mode="HTML")
        else:
            await msg.reply_text(result_text, parse_mode="HTML")

        record_task_outcome("probe", True, "autonomous_inquiry", 3, topic)
