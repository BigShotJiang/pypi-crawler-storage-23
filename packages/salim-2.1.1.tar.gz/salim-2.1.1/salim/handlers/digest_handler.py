"""
Salim Daily Digest Handler — Morning briefing combining weather, calendar, emails, news.

Commands:
  /digest                 — get full morning briefing now
  /digest setup           — configure digest preferences
  /digest schedule 7:30   — auto-send digest every day at 7:30am
  /digest stop            — stop scheduled digest

The digest includes:
  • Good morning greeting + date
  • Today's weather
  • Calendar events for today
  • Unread email count + important senders
  • Top news headlines
  • System health snapshot
  • Motivational tip / task reminder
"""
from __future__ import annotations
import json
import logging
from datetime import datetime, timedelta
from pathlib import Path

from telegram import Update, Bot
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.digest")

DIGEST_CFG = Path.home() / ".salim" / "digest_config.json"

GREETINGS = {
    range(5, 12):  "🌅 Good morning",
    range(12, 17): "☀️ Good afternoon",
    range(17, 21): "🌆 Good evening",
    range(21, 24): "🌙 Good night",
    range(0, 5):   "🌙 Late night briefing",
}


def _greeting() -> str:
    h = datetime.now().hour
    for r, g in GREETINGS.items():
        if h in r:
            return g
    return "👋 Hello"


def _load_cfg() -> dict:
    if DIGEST_CFG.exists():
        try:
            return json.loads(DIGEST_CFG.read_text())
        except Exception:
            pass
    return {}


def _save_cfg(cfg: dict):
    DIGEST_CFG.parent.mkdir(parents=True, exist_ok=True)
    DIGEST_CFG.write_text(json.dumps(cfg, indent=2))


async def _build_digest(bot_instance) -> str:
    """Build the full morning digest string."""
    now    = datetime.now()
    lines  = []

    # ── Header ────────────────────────────────────────────────────────────────
    lines += [
        f"{_greeting()}! 🤖",
        f"📅 <b>{now.strftime('%A, %B %d, %Y')}</b>",
        f"🕐 {now.strftime('%I:%M %p')}",
        "",
    ]

    # ── System health ─────────────────────────────────────────────────────────
    try:
        import psutil
        cpu  = psutil.cpu_percent(interval=0.3)
        mem  = psutil.virtual_memory()
        disk = psutil.disk_usage("/")
        bat  = psutil.sensors_battery()
        bat_str = f" · 🔋 {bat.percent:.0f}%" if bat else ""
        lines += [
            "💻 <b>System</b>",
            f"   CPU {cpu:.0f}%  RAM {mem.percent:.0f}%  Disk {disk.percent:.0f}%{bat_str}",
            "",
        ]
    except Exception:
        pass

    # ── Weather ───────────────────────────────────────────────────────────────
    try:
        from salim.handlers.weather import _load_location, _fetch_weather, WMO_CODES
        saved = _load_location()
        if saved:
            data = await _fetch_weather(saved["lat"], saved["lon"], days=1)
            if data and "current" in data:
                cur  = data["current"]
                code = cur.get("weathercode", 0)
                cond = WMO_CODES.get(code, "")
                temp = cur.get("temperature_2m", "?")
                feel = cur.get("apparent_temperature", "?")
                lines += [
                    f"🌍 <b>Weather — {saved['name']}</b>",
                    f"   {cond}  🌡️ {temp}°C (feels {feel}°C)",
                    "",
                ]
    except Exception as e:
        logger.debug(f"Digest weather: {e}")

    # ── Calendar ──────────────────────────────────────────────────────────────
    try:
        from salim.handlers.calendar_handler import _load_local_events, _get_google_service
        svc = _get_google_service()
        cal_events = []
        if svc:
            start = now.replace(hour=0, minute=0, second=0)
            end   = start + timedelta(days=1)
            result = svc.events().list(
                calendarId="primary",
                timeMin=start.isoformat() + "Z",
                timeMax=end.isoformat() + "Z",
                singleEvents=True, orderBy="startTime", maxResults=10,
            ).execute()
            cal_events = result.get("items", [])
        else:
            local = _load_local_events()
            today = now.date()
            cal_events = [
                e for e in local
                if e.get("start", {}).get("dateTime", "")[:10] == str(today)
            ]

        if cal_events:
            lines += [f"📅 <b>Today's Calendar ({len(cal_events)} event(s))</b>"]
            for e in cal_events[:5]:
                title    = e.get("summary", "Untitled")
                dt_str   = e.get("start", {}).get("dateTime", "")
                time_str = ""
                if dt_str:
                    try:
                        dt = datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
                        time_str = f"  🕐 {dt.strftime('%I:%M %p')}"
                    except Exception:
                        pass
                lines.append(f"   • {title}{time_str}")
            lines.append("")
        else:
            lines += ["📅 <b>Calendar</b>  No events today.", ""]
    except Exception as e:
        logger.debug(f"Digest calendar: {e}")

    # ── Email ─────────────────────────────────────────────────────────────────
    try:
        from salim.handlers.agent import load_email_config, read_emails
        if load_email_config():
            emails = read_emails(limit=5, search="UNSEEN")
            if emails:
                lines += [f"📧 <b>Unread Emails ({len(emails)} recent unread)</b>"]
                for e in emails[:3]:
                    sender  = e.get("from", "")[:30]
                    subject = e.get("subject", "")[:50]
                    lines.append(f"   • {sender}: {subject}")
                lines.append("")
            else:
                lines += ["📧 <b>Email</b>  Inbox clear ✅", ""]
    except Exception as e:
        logger.debug(f"Digest email: {e}")

    # ── Top news ──────────────────────────────────────────────────────────────
    try:
        from salim.handlers.web_handler import _ddg_search
        results = await _ddg_search("top news today", max_results=4)
        if results:
            lines += ["📰 <b>Top News</b>"]
            for r in results[:4]:
                title = r.get("title", "")[:80]
                lines.append(f"   • {title}")
            lines.append("")
    except Exception as e:
        logger.debug(f"Digest news: {e}")

    # ── Footer ────────────────────────────────────────────────────────────────
    lines += [
        "─────────────────────",
        "<i>Have a productive day! 🚀</i>",
        "<i>Type any command or just speak naturally to Salim.</i>",
    ]

    return "\n".join(lines)


class DigestHandlers:

    @require_auth
    async def cmd_digest(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /digest             — get morning briefing now
        /digest schedule 7:30 — auto-send every morning
        /digest stop        — cancel scheduled digest
        /digest setup       — configure settings
        """
        msg  = update.effective_message
        user_id = update.effective_user.id
        args = ctx.args or []
        sub  = args[0].lower() if args else ""

        if sub == "setup":
            cfg = _load_cfg()
            await msg.reply_text(
                "⚙️ <b>Daily Digest Setup</b>\n\n"
                "The digest includes: weather, calendar, email summary, top news, system health.\n\n"
                "<b>Schedule it:</b> <code>/digest schedule 7:30</code>\n"
                "<b>Run now:</b> <code>/digest</code>\n"
                "<b>Stop schedule:</b> <code>/digest stop</code>\n\n"
                "<b>For weather:</b> <code>/weather set YourCity</code>\n"
                "<b>For calendar:</b> <code>/cal setup</code>\n"
                "<b>For email:</b> <code>/agent email setup</code>",
                parse_mode="HTML"
            )
            return

        if sub == "schedule":
            time_str = args[1] if len(args) > 1 else "7:00"
            try:
                hour, minute = map(int, time_str.split(":"))
            except Exception:
                hour, minute = 7, 0

            cfg = _load_cfg()
            cfg["scheduled"] = True
            cfg["hour"]      = hour
            cfg["minute"]    = minute
            cfg["user_id"]   = user_id
            _save_cfg(cfg)

            await msg.reply_text(
                f"✅ <b>Daily Digest Scheduled</b>\n\n"
                f"You'll receive your morning briefing every day at <b>{hour:02d}:{minute:02d}</b>.\n\n"
                f"<i>Make sure Salim is running in the background.</i>",
                parse_mode="HTML"
            )
            return

        if sub == "stop":
            cfg = _load_cfg()
            cfg["scheduled"] = False
            _save_cfg(cfg)
            await msg.reply_text("⏹ Daily digest schedule cancelled.")
            return

        # Send digest now
        await msg.reply_text("📋 Building your digest…")
        try:
            digest = await _build_digest(self)
            await msg.reply_text(digest, parse_mode="HTML")
        except Exception as e:
            await msg.reply_text(f"❌ Digest error: {e}")

    async def check_and_send_digest(self, bot: Bot):
        """Called by heartbeat to auto-send digest at scheduled time."""
        cfg = _load_cfg()
        if not cfg.get("scheduled"):
            return
        now = datetime.now()
        if now.hour == cfg.get("hour", 7) and now.minute == cfg.get("minute", 0):
            uid = cfg.get("user_id")
            if uid:
                try:
                    digest = await _build_digest(self)
                    await bot.send_message(chat_id=uid, text=digest, parse_mode="HTML")
                except Exception as e:
                    logger.error(f"Digest send error: {e}")
