"""
Salim Web Handler — Fetch, summarize, and search the web using free tools only.

Commands:
  /web <url>              — fetch and summarize a webpage
  /web summary <url>      — AI-powered page summary
  /websearch <query>      — search DuckDuckGo (no API key)
  /webread <url>          — extract full readable text from a page
  /webnews <topic>        — fetch latest news on a topic (DuckDuckGo News)
  /yt <url>               — summarize a YouTube video (title + description + transcript)
"""
from __future__ import annotations
import html as html_lib
import logging
import re
from urllib.parse import urljoin, urlparse, quote_plus

import httpx
from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.web")


def _strip_html(html: str) -> str:
    """Strip HTML tags and decode entities, return clean text."""
    text = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<script[^>]*>.*?</script>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<[^>]+>", " ", text)
    text = html_lib.unescape(text)
    text = re.sub(r"\s{3,}", "\n\n", text)
    return text.strip()


def _extract_readable(html: str, url: str = "") -> str:
    """Extract main readable content from a webpage HTML."""
    try:
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, "html.parser")
        # Remove noise
        for tag in soup.find_all(["script", "style", "nav", "header", "footer",
                                   "aside", "ads", "iframe", "form"]):
            tag.decompose()
        # Try article body first
        article = soup.find("article") or soup.find(id="content") or \
                  soup.find(class_=re.compile(r"article|content|post|body", re.I))
        target = article or soup.find("body") or soup
        text = target.get_text(separator="\n", strip=True)
        # Clean up excess whitespace
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()
    except ImportError:
        return _strip_html(html)


async def _fetch_url(url: str, timeout: int = 15) -> tuple[str, str]:
    """Fetch a URL. Returns (html_content, final_url)."""
    headers = {
        "User-Agent": "Mozilla/5.0 (compatible; Salim/1.0; +https://github.com/salim)",
        "Accept": "text/html,application/xhtml+xml,*/*",
    }
    async with httpx.AsyncClient(
        headers=headers, follow_redirects=True, timeout=timeout
    ) as client:
        r = await client.get(url)
        return r.text, str(r.url)


async def _ddg_search(query: str, max_results: int = 8) -> list[dict]:
    """Search DuckDuckGo HTML (no API key needed). Returns list of {title, url, snippet}."""
    results = []
    try:
        encoded = quote_plus(query)
        url = f"https://html.duckduckgo.com/html/?q={encoded}"
        html, _ = await _fetch_url(url)
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(html, "html.parser")
        for result in soup.find_all("div", class_="result__body"):
            a = result.find("a", class_="result__a")
            snip = result.find("a", class_="result__snippet")
            if a:
                results.append({
                    "title":   a.get_text(strip=True),
                    "url":     a.get("href", ""),
                    "snippet": snip.get_text(strip=True) if snip else "",
                })
            if len(results) >= max_results:
                break
    except Exception as e:
        logger.error(f"DDG search error: {e}")
    return results


async def _get_yt_info(url: str) -> dict:
    """Get YouTube video info using yt-dlp (free, no API key)."""
    try:
        import subprocess, json as _json
        result = subprocess.run(
            ["yt-dlp", "--dump-json", "--no-warnings", "--quiet", url],
            capture_output=True, text=True, timeout=30
        )
        if result.returncode == 0:
            return _json.loads(result.stdout)
    except Exception:
        pass
    # Fallback: parse from page
    try:
        html, _ = await _fetch_url(url)
        title_m = re.search(r'"title"\s*:\s*"([^"]+)"', html)
        desc_m  = re.search(r'"shortDescription"\s*:\s*"([^"]{0,500})', html)
        return {
            "title":       title_m.group(1) if title_m else "YouTube Video",
            "description": desc_m.group(1).replace("\\n", "\n") if desc_m else "",
            "webpage_url": url,
        }
    except Exception:
        return {}


class WebHandlers:

    @require_auth
    async def cmd_web(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /web <url>          — fetch + summarize a webpage
        /web summary <url>  — AI-powered summary
        """
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            await msg.reply_text(
                "Usage:\n"
                "<code>/web https://example.com</code> — summarize a page\n"
                "<code>/web summary https://...</code> — AI summary\n"
                "<code>/websearch your query</code> — web search\n"
                "<code>/webnews AI latest</code> — news on topic",
                parse_mode="HTML"
            )
            return

        ai_summary = args[0].lower() == "summary"
        url = args[1] if ai_summary else args[0]
        if not url.startswith("http"):
            url = "https://" + url

        await msg.reply_text(f"🌐 Fetching <code>{url[:60]}</code>…", parse_mode="HTML")
        try:
            html, final_url = await _fetch_url(url)
        except Exception as e:
            await msg.reply_text(f"❌ Could not fetch: {e}")
            return

        text = _extract_readable(html, final_url)
        truncated = text[:4000]

        if ai_summary and self._ai.is_configured():
            try:
                summary, _ = await self._ai._call_with_fallback(
                    [{"role": "user", "content": f"Summarize this webpage content in 5-8 bullet points:\n\n{truncated}"}],
                    system="You are a web content summarizer. Be concise and factual.",
                    max_tokens=600, temperature=0.3,
                )
                await msg.reply_text(
                    f"🌐 <b>AI Summary</b>\n<i>{final_url[:60]}</i>\n\n{summary}",
                    parse_mode="HTML"
                )
            except Exception as e:
                await msg.reply_text(f"❌ AI summary failed: {e}")
        else:
            # Show first 1500 chars of clean text
            preview = text[:1500].strip()
            await msg.reply_text(
                f"🌐 <b>Page Content</b>\n<i>{final_url[:60]}</i>\n\n"
                f"<code>{html_lib.escape(preview[:1400])}</code>\n\n"
                f"<i>({len(text)} chars total)</i>",
                parse_mode="HTML"
            )

    @require_auth
    async def cmd_webread(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/webread <url> — extract full readable text from a webpage."""
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            await msg.reply_text("Usage: <code>/webread https://example.com</code>", parse_mode="HTML")
            return

        url = args[0]
        if not url.startswith("http"):
            url = "https://" + url

        await msg.reply_text("🌐 Extracting content…")
        try:
            html, final_url = await _fetch_url(url)
            text = _extract_readable(html)
            if len(text) > 3000:
                # Send as file
                from io import BytesIO
                bio = BytesIO(text.encode())
                bio.name = "page_content.txt"
                await msg.reply_document(document=bio, filename="page_content.txt",
                                         caption=f"📄 Full content from {final_url[:60]}")
            else:
                await msg.reply_text(
                    f"📄 <b>Page Text</b>\n<i>{final_url[:60]}</i>\n\n{html_lib.escape(text[:3000])}",
                    parse_mode="HTML"
                )
        except Exception as e:
            await msg.reply_text(f"❌ Error: {e}")

    @require_auth
    async def cmd_websearch(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/websearch <query> — search the web via DuckDuckGo (no API key)."""
        msg   = update.effective_message
        args  = ctx.args or []
        query = " ".join(args)
        if not query:
            await msg.reply_text("Usage: <code>/websearch your search query</code>", parse_mode="HTML")
            return

        await msg.reply_text(f"🔍 Searching: <i>{html_lib.escape(query)}</i>…", parse_mode="HTML")
        results = await _ddg_search(query)

        if not results:
            await msg.reply_text("❌ No results found. Try a different query.")
            return

        lines = [f"🔍 <b>Results for: {html_lib.escape(query)}</b>\n"]
        for i, r in enumerate(results[:6], 1):
            lines.append(
                f"{i}. <b>{html_lib.escape(r['title'])}</b>\n"
                f"   <a href='{r['url']}'>{r['url'][:60]}</a>\n"
                f"   <i>{html_lib.escape(r['snippet'][:120])}</i>"
            )
        await msg.reply_text("\n\n".join(lines), parse_mode="HTML",
                             disable_web_page_preview=True)

    @require_auth
    async def cmd_webnews(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/webnews <topic> — get latest news on a topic via DuckDuckGo News."""
        msg   = update.effective_message
        args  = ctx.args or []
        topic = " ".join(args)
        if not topic:
            await msg.reply_text("Usage: <code>/webnews AI technology</code>", parse_mode="HTML")
            return

        await msg.reply_text(f"📰 Fetching news: <i>{html_lib.escape(topic)}</i>…", parse_mode="HTML")
        results = await _ddg_search(f"{topic} news", max_results=6)

        if not results:
            await msg.reply_text("❌ No news found.")
            return

        lines = [f"📰 <b>Latest News: {html_lib.escape(topic)}</b>\n"]
        for i, r in enumerate(results[:6], 1):
            lines.append(
                f"{i}. <b>{html_lib.escape(r['title'][:80])}</b>\n"
                f"   <a href='{r['url']}'>{urlparse(r['url']).netloc}</a>\n"
                f"   <i>{html_lib.escape(r['snippet'][:120])}</i>"
            )
        await msg.reply_text("\n\n".join(lines), parse_mode="HTML",
                             disable_web_page_preview=True)

    @require_auth
    async def cmd_yt(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/yt <youtube_url> — get video info and summary."""
        msg  = update.effective_message
        args = ctx.args or []
        if not args:
            await msg.reply_text("Usage: <code>/yt https://youtube.com/watch?v=...</code>", parse_mode="HTML")
            return

        url = args[0]
        await msg.reply_text("🎬 Fetching video info…")
        info = await _get_yt_info(url)

        if not info:
            await msg.reply_text("❌ Could not get video info. Make sure yt-dlp is installed:\n<code>pip install yt-dlp</code>", parse_mode="HTML")
            return

        title    = info.get("title", "Unknown Title")
        uploader = info.get("uploader", "")
        duration = info.get("duration", 0)
        views    = info.get("view_count", 0)
        desc     = (info.get("description") or "")[:600]
        dur_str  = f"{duration // 60}:{duration % 60:02d}" if duration else "?"

        lines = [
            f"🎬 <b>{html_lib.escape(title)}</b>",
            f"👤 {html_lib.escape(uploader)}  ·  ⏱ {dur_str}",
            f"👁 {views:,} views" if views else "",
        ]

        if desc:
            lines += ["", "📝 <b>Description:</b>", html_lib.escape(desc[:500])]

        if self._ai.is_configured() and desc:
            try:
                summary, _ = await self._ai._call_with_fallback(
                    [{"role": "user", "content": f"Summarize this YouTube video in 4-5 bullet points:\nTitle: {title}\nDescription: {desc}"}],
                    system="You are a YouTube video summarizer. Be concise.",
                    max_tokens=400, temperature=0.3,
                )
                lines += ["", "🤖 <b>AI Summary:</b>", summary]
            except Exception:
                pass

        await msg.reply_text("\n".join(l for l in lines if l), parse_mode="HTML")
