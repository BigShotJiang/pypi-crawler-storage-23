PyGranta System |version|
#########################

PyGranta System, a component of the PyGranta software suite, provides a
Python interface for Granta MI System Administration functions.

.. grid:: 1 2 2 2


   .. grid-item-card:: Getting started :material-regular:`directions_run`
      :padding: 2 2 2 2
      :link: getting_started/index
      :link-type: doc

      Learn how to install PyGranta System in user mode and quickly
      begin using it.

   .. grid-item-card:: User guide :material-regular:`menu_book`
      :padding: 2 2 2 2
      :link: user_guide/index
      :link-type: doc

      Understand key concepts for using PyGranta System.

   .. grid-item-card:: API reference :material-regular:`bookmark`
      :padding: 2 2 2 2
      :link: api/index
      :link-type: doc

      Understand how to use Python to interact programmatically with
      PyGranta System.

   .. grid-item-card:: Examples :material-regular:`play_arrow`
      :padding: 2 2 2 2
      :link: examples/index
      :link-type: doc

      Explore examples that show how to use PyGranta System to
      perform many different types of operations.

   .. grid-item-card:: Contribute :material-regular:`group`
      :padding: 2 2 2 2
      :link: contributing
      :link-type: doc

      Learn how to contribute to the PyGranta System codebase or documentation.


.. toctree::
   :hidden:
   :maxdepth: 3

   getting_started/index
   user_guide/index
   api/index
   examples/index
   contributing
   changelog
