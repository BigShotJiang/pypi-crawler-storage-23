# Copyright (C) 2025 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: Apache-2.0

from typing import Any, Iterator, List, Type

import pytest

from ansys.grantami.system._models import ActivityItem, _PagedResult


class TestPagedResult:
    @pytest.mark.parametrize(
        ("item_type", "expected_type_string"),
        [
            (int, "int"),
            (str, "str"),
            (bool, "bool"),
            (float, "float"),
            (ActivityItem, "ActivityItem"),
        ],
    )
    @pytest.mark.parametrize("page_index", [1, 10, 100, 1000])
    def test_repr(self, item_type: Type, expected_type_string: str, page_index: int):
        def next_func(page_index: int) -> List[Any]:
            raise NotImplementedError()

        paged_result = _PagedResult(next_func, item_type)
        paged_result._page_index = page_index
        assert paged_result.__repr__() == f"<_PagedResult[{expected_type_string}] page_index={page_index}>"

    def test_no_results_raises_stop_iteration(self):
        call_count = 0

        def next_func(page_index: int) -> List[int]:
            nonlocal call_count
            call_count += 1
            return []

        paged_result = _PagedResult(next_func, int)

        with pytest.raises(StopIteration):
            next(paged_result)
        assert call_count == 1

    def test_error_in_next_func_falls_through(self):
        def next_func(page_index: int) -> List[int]:
            raise NotImplementedError()

        paged_result = _PagedResult(next_func, int)

        with pytest.raises(NotImplementedError):
            next(paged_result)

    def test_iterator_exposes_correct_number_of_values_when_total_is_less_than_page_size(self):
        call_count = 0

        def next_func(page_index: int) -> List[int]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return [1, 2, 3]
            return []

        paged_result = _PagedResult(next_func, int)
        list_result = list(paged_result)

        assert (
            call_count == 2
        )  # Called once to retrieve the values and again to determine the end of the iterator has been reached
        assert list_result == [1, 2, 3]

    def test_iterator_exposes_correct_number_of_values_when_total_is_greater_than_page_size(self):
        call_count = 0

        def next_func(page_index: int) -> List[int]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return [1, 2, 3]
            elif call_count == 2:
                return [4, 5]
            return []

        paged_result = _PagedResult(next_func, int)
        list_result = list(paged_result)

        assert (
            call_count == 3
        )  # Called twice to retrieve the values and again to determine the end of the iterator has been reached
        assert list_result == [1, 2, 3, 4, 5]

    def test_iter_return_iterator(self):
        def next_func(page_index: int) -> List[int]:
            raise NotImplementedError()

        paged_result = _PagedResult(next_func, int)

        iterator = iter(paged_result)
        assert isinstance(iterator, Iterator)

    def test_paged_result_can_be_iterated_over(self):
        call_count = 0

        def next_func(page_index: int) -> List[int]:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                return [1, 2, 3]
            elif call_count == 2:
                return [4, 5]
            return []

        paged_result = _PagedResult(next_func, int)

        result = []
        for value in paged_result:
            result.append(value)

        assert (
            call_count == 3
        )  # Called twice to retrieve the values and again to determine the end of the iterator has been reached
        assert result == [1, 2, 3, 4, 5]
