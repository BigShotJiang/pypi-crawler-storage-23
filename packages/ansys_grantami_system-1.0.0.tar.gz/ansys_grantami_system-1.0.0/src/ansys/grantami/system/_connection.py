# Copyright (C) 2025 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: Apache-2.0

"""
Granta MI System connection module.

Defines the client for interacting with Granta MI.
"""

from abc import ABC
import functools
from typing import Iterator, Optional

from ansys.openapi.common import (
    ApiClient,
    ApiClientFactory,
    ApiException,
    SessionConfiguration,
    generate_user_agent,
)
import requests

from ansys.grantami.serverapi_openapi.v2026r1 import api, models

from ._logger import logger
from ._models import ActivityItem, ActivityReportFilter, GrantaMIVersion, _PagedResult

PROXY_PATH = "/proxy/v1.svc/mi"
AUTH_PATH = "/Health/v2.svc"
API_DEFINITION_PATH = "/swagger/v1/swagger.json"
GRANTA_APPLICATION_NAME_HEADER = "PyGranta System"

MINIMUM_GRANTA_MI_VERSION = (26, 1)
DEFAULT_PAGE_SIZE = 1000


class SystemApiClient(ApiClient, ABC):
    """
    Communicates with Granta MI.

    Methods are only implemented if the underlying functionality is supported by the Granta MI server version. If the
    functionality is not available, a :class:`NotImplementedError` is raised.

    This class should not be instantiated directly. New sessions are created with the :class:`.Connection` class.

    Other Parameters
    ----------------
    session : requests.Session
        A requests.Session object.
    service_layer_url : str
        The Granta MI Service Layer URL.
    configuration : ansys.openapi.common.SessionConfiguration
        The configuration to apply to the client.
    """

    def __init__(
        self,
        session: requests.Session,
        service_layer_url: str,
        configuration: SessionConfiguration,
    ):
        self._service_layer_url = service_layer_url
        api_url = service_layer_url + PROXY_PATH

        logger.debug(f"Base Service Layer URL: {self._service_layer_url}")
        logger.debug(f"Service URL: {api_url}")
        super().__init__(session, api_url, configuration)
        self._instantiate_apis()

    def _instantiate_apis(self) -> None:
        """
        Instantiate the APIs required by this class.

        The versions of the API classes are not fixed, and depend on the api module defined in the ``_api`` class
        variable. This method can be overridden if APIs do not exist for a certain Granta MI version.
        """
        self.schema_api = api.SchemaApi(self)
        self.activity_log_api = api.ActivityLogApi(self)

    def __repr__(self) -> str:
        """Printable representation of the object."""
        return f"<{self.__class__.__name__} url: {self._service_layer_url}>"

    def get_activity_report(self, page_size: Optional[int] = DEFAULT_PAGE_SIZE) -> Iterator[ActivityItem]:
        """
        Get all activity information from the Granta MI server.

        Parameters
        ----------
        page_size : int, optional
            The number of items to include in a single response. Defaults to 1000.

        Returns
        -------
        Iterator of ActivityItem
            An iterator containing the returned activity information.

        Warnings
        --------
        Activity information is updated on the Granta MI server at midnight server time. If a request is made
        while the activity report is being updated, duplicate results may be retrieved from the server.

        Avoid making requests while the server is updating the activity report.
        """
        gsa_filter = ActivityReportFilter()
        return self.get_activity_report_where(filter_=gsa_filter, page_size=page_size)

    def get_activity_report_where(
        self,
        filter_: ActivityReportFilter,
        page_size: Optional[int] = DEFAULT_PAGE_SIZE,
    ) -> Iterator[ActivityItem]:
        """
        Get activity information from the Granta MI server that matches a filter.

        Parameters
        ----------
        filter_ : ActivityReportFilter
            The filter to apply to the request.
        page_size : int | None, optional
            The number of items to include in a single response. Defaults to 1000.

        Returns
        -------
        Iterator of ActivityItem
            An iterator containing the returned activity information.

        Warnings
        --------
        Activity information is updated on the Granta MI server at midnight server time. If a request is made
        while the activity report is being updated, duplicate results may be retrieved from the server.

        Avoid making requests while the server is updating the activity report.
        """
        logger.info(f"Fetching activity log entries in batches of size {page_size}...")

        def get_next_page(
            client: "SystemApiClient",
            gsa_filter: models.GsaActivityLogEntriesFilter,
            page: int,
        ) -> list[ActivityItem]:
            """
            Request the next batch of activity log information from Granta MI.

            Parameters
            ----------
            client : SystemApiClient
                The client to use for the API request.
            gsa_filter : models.GsaActivityLogEntriesFilter
                The filter used to restrict the items in the response.
            page : int
                The page number to request.

            Returns
            -------
            List of ActivityItem
                A list containing a page of the activity log.
            """
            _response = client.activity_log_api.get_entries(body=gsa_filter, page_size=page_size, page=page)
            if _response is None:
                raise ValueError("ActivityLogApi.get_entries must not return None")
            return [ActivityItem._from_model(item) for item in _response.entries]

        partial_func = functools.partial(get_next_page, self, filter_._to_model())
        return _PagedResult(partial_func, ActivityItem)

    def get_granta_mi_version(self) -> GrantaMIVersion:
        """
        Get the version of Granta MI running on the server.

        Returns
        -------
        GrantaMIVersion
            Granta MI version information.
        """
        version = self.schema_api.get_version()
        return GrantaMIVersion._from_model(version)


class Connection(ApiClientFactory):
    """
    Connects to a Granta MI ServerAPI instance.

    This is a subclass of the :class:`ansys.openapi.common.ApiClientFactory` class. All methods in
    this class are documented as returning :class:`~ansys.openapi.common.ApiClientFactory` class
    instances of the :class:`ansys.grantami.system.Connection` class instead.

    Parameters
    ----------
    servicelayer_url : str
       Base URL of the Granta MI Service Layer application.
    session_configuration : :class:`~ansys.openapi.common.SessionConfiguration`, optional
       Additional configuration settings for the requests session. The default is ``None``, in which
       case the :class:`~ansys.openapi.common.SessionConfiguration` class with default parameters
       is used.

    Notes
    -----
    For advanced usage, including configuring session-specific properties and timeouts, see the
    :external+openapi-common:doc:`ansys-openapi-common API reference <api/index>`. Specifically, see
    the documentation for the :class:`~ansys.openapi.common.ApiClientFactory` base class and the
    :class:`~ansys.openapi.common.SessionConfiguration` class.

    1. Create the connection builder object and specify the server to connect to.
    2. Specify the authentication method to use for the connection and provide credentials if
       required.
    3. Connect to the server, which returns the client object.

    The examples show this process for different authentication methods.

    Examples
    --------
    >>> client = Connection("http://my_mi_server/mi_servicelayer").with_autologon().connect()
    >>> client
    <SystemApiClient: url=http://my_mi_server/mi_servicelayer>
    >>> client = (
    ...     Connection("http://my_mi_server/mi_servicelayer")
    ...     .with_credentials(username="my_username", password="my_password")
    ...     .connect()
    ... )
    >>> client
    <SystemApiClient: url: http://my_mi_server/mi_servicelayer>
    """

    def __init__(self, servicelayer_url: str, session_configuration: Optional[SessionConfiguration] = None):
        from . import __version__

        auth_url = servicelayer_url.strip("/") + AUTH_PATH
        super().__init__(auth_url, session_configuration)
        self._base_service_layer_url = servicelayer_url
        self._session_configuration.headers["X-Granta-ApplicationName"] = GRANTA_APPLICATION_NAME_HEADER
        self._session_configuration.headers["User-Agent"] = generate_user_agent("ansys-grantami-system", __version__)

    def connect(self) -> SystemApiClient:
        """
        Finalize the :class:`.SystemApiClient` client and return it for use.

        Authentication must be configured for this method to succeed.

        Returns
        -------
        :class:`.SystemApiClient`
            Client object that can be used to connect to Granta MI and interact with the Granta MI System API. The
            client object is a subtype of :class:`.SystemApiClient`. The subtype returned depends on the Granta MI
            server version.
        """
        self._validate_builder()
        client = SystemApiClient(
            session=self._session,
            service_layer_url=self._base_service_layer_url,
            configuration=self._session_configuration,
        )
        client.setup_client(models)
        self._test_connection(client)
        return client

    @staticmethod
    def _test_connection(client: SystemApiClient) -> None:
        """
        Check if the created client can be used to perform a request.

        This method tests both that the API definition can be accessed and that the Granta MI
        version is compatible with this package.

        The first checks ensures that the Server API exists and is functional. The second check
        ensures that the Granta MI server version is compatible with this version of the package.

        A failure at any point raises a ``ConnectionError``.

        Parameters
        ----------
        client : :class:`~.SystemApiClient`
            Client object to test.

        Raises
        ------
        ConnectionError
            Error raised if the connection test fails.
        """
        try:
            client.call_api(resource_path=API_DEFINITION_PATH, method="GET")
        except ApiException as e:
            if e.status_code == 404:
                raise ConnectionError(
                    "Cannot find the Server API definition in Granta MI Service Layer. Ensure "
                    "that a compatible version of Granta MI is available and try again."
                ) from e
            else:
                raise ConnectionError(
                    "An unexpected error occurred when trying to connect to the Server API in Granta "
                    " MI Service Layer. Check the Service Layer logs for more information and try "
                    "again."
                ) from e
        except requests.exceptions.RetryError as e:
            raise ConnectionError(
                "An unexpected error occurred when trying to connect to Granta MI Server API. Check "
                "that SSL certificates have been configured for communications between the Granta MI "
                "Server and client Granta MI applications."
            ) from e

        try:
            server_version = client.get_granta_mi_version()
        except ApiException as e:
            # Currently the server version check returns a 403 for a System Admin-only user
            # Suppress this spurious failure by returning early
            if e.status_code == 403:
                return
            raise ConnectionError(
                "Cannot check the Granta MI server version. Ensure that the Granta MI server version "
                f"is at least {'.'.join([str(e) for e in MINIMUM_GRANTA_MI_VERSION])}."
            ) from e

        # Once there are multiple versions of this package targeting different Granta MI server
        # versions, the error message should direct users towards the PyGranta metapackage for
        # earlier versions. This is not necessary now though, because there is no support for
        # versions earlier than 2026 R1.

        if server_version.version < MINIMUM_GRANTA_MI_VERSION:
            raise ConnectionError(
                f"This package requires a more recent Granta MI version. Detected Granta MI server "
                f"version is {server_version}, but this package requires at least "
                f"{'.'.join([str(e) for e in MINIMUM_GRANTA_MI_VERSION])}."
            )
