"""ancify -- Ancestral allele polarization pipeline using outgroup species."""

__version__ = "1.0.0"
