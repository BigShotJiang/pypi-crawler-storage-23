"""UAM bridge modules for cross-protocol interoperability."""
