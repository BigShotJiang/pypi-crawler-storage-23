"""Allow running ``python -m uam.cli``."""

from uam.cli.main import cli

if __name__ == "__main__":
    cli()
