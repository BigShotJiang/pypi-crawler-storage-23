"""UAM plugin modules for framework integrations."""
