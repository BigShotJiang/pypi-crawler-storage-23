# Authors

Contributors to pyconverters_pyexcel include:

+ [Olivier Terrier](mailto:olivier.terrier@kairntech.com)
