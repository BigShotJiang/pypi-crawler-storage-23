from enum import Enum

class Mode(Enum):
    normal = 0
    minimal = 1
