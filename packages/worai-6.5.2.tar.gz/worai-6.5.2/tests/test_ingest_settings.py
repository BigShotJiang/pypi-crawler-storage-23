from __future__ import annotations

import pytest

from worai.core.ingest import resolve_ingest_settings
from worai.errors import UsageError


def test_resolve_ingest_settings_legacy_loader_default_maps_to_web_scrape_api() -> None:
    settings = resolve_ingest_settings(
        context="test",
        legacy_loader="default",
    )
    assert settings.loader == "web_scrape_api"


def test_resolve_ingest_settings_prefers_new_loader_and_warns(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level("WARNING")
    settings = resolve_ingest_settings(
        context="test",
        new_loader="web_scrape_api",
        legacy_loader="proxy",
    )
    assert settings.loader == "web_scrape_api"
    assert settings.warnings
    assert "ingest_config_conflict" in caplog.text


def test_resolve_ingest_settings_rejects_invalid_loader() -> None:
    with pytest.raises(UsageError):
        resolve_ingest_settings(context="test", new_loader="invalid")

