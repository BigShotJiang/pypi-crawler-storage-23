"""
Transport abstraction for communication with the Bench Service.
"""

import abc
import collections
import socket
import struct
import time

from ec_driver.codec import PACKAGE_SIZE_LIMIT

from ._logger import logger


class Transport(abc.ABC):
    @property
    @abc.abstractmethod
    def is_connected(self) -> bool:
        """Indicates whether a connection to the Bench Service is established."""

    @abc.abstractmethod
    def reconnect(self) -> None:
        """
        Establish a connection to the Bench Service.

        If the transport is already connected, the existing connection should be closed.

        If this method returns successfully, the transport must be connected.
        """

    @abc.abstractmethod
    def send(self, pkg: bytes) -> None:
        """Send a package to the Bench Service."""

    @abc.abstractmethod
    def receive(self, timeout: float) -> bytes | None:
        """Receive a package from the Bench Service."""


DEFAULT_TCP_PORT = 5302


class TCPTransport(Transport):
    host: str
    port: int

    connection: socket.socket | None = None

    _rx_buffer: collections.deque[bytes]
    _rx_buffer_size: int

    def __init__(self, host: str, port: int = DEFAULT_TCP_PORT) -> None:
        self.host = host
        self.port = port
        self.connection = None
        self._rx_buffer = collections.deque()
        self._rx_buffer_size = 0

    def _recv_exact(self, length: int, timeout: float) -> bytes | None:
        if self.connection is None:
            raise RuntimeError("transport is not connected")
        start = time.monotonic()
        try:
            # We need to buffer data globally to not loose any data when a timeout occurs.
            while self._rx_buffer_size < length:
                elapsed = time.monotonic() - start
                if elapsed > timeout:
                    raise TimeoutError()
                self.connection.settimeout(timeout - elapsed)
                chunk = self.connection.recv(max(4096, length - self._rx_buffer_size))
                if not chunk:
                    raise RuntimeError("unexpected EOF while receiving data")
                self._rx_buffer.append(chunk)
                self._rx_buffer_size += len(chunk)
        except TimeoutError:
            return None
        assert self._rx_buffer_size >= length
        data = bytearray(length)
        offset = 0
        while offset < length:
            chunk = self._rx_buffer[0]
            chunk_length = len(chunk)
            if offset + chunk_length <= length:
                data[offset : offset + chunk_length] = chunk
                offset += chunk_length
                self._rx_buffer.popleft()
                self._rx_buffer_size -= chunk_length
            else:
                needed = length - offset
                data[offset : offset + needed] = chunk[:needed]
                offset += needed
                self._rx_buffer[0] = chunk[needed:]
                self._rx_buffer_size -= needed
        return bytes(data)

    @property
    def is_connected(self) -> bool:
        return self.connection is not None

    def reconnect(self) -> None:
        if self.connection is not None:
            try:
                self.connection.close()
            except Exception as error:
                logger.error(f"failed to close existing socket: {error}")
            self.connection = None
        logger.info(f"connecting to Bench Service at {self.host}:{self.port}")
        self.connection = socket.create_connection((self.host, self.port))

    def send(self, pkg: bytes) -> None:
        if self.connection is None:
            raise RuntimeError("transport is not connected")
        self.connection.sendall(_TCP_HEADER_STRUCT.pack(len(pkg)))
        self.connection.sendall(pkg)

    def receive(self, timeout: float) -> bytes | None:
        start = time.monotonic()
        header = self._recv_exact(_TCP_HEADER_STRUCT.size, timeout)
        if header is None:
            return None
        (length,) = _TCP_HEADER_STRUCT.unpack(header)
        if length > PACKAGE_SIZE_LIMIT:
            raise RuntimeError(f"package too large, {length} > 1 MiB")
        elapsed = time.monotonic() - start
        # No matter how long we waited for the header, we will wait at least 5 seconds
        # for the data before we give up and throw an exception.
        pkg = self._recv_exact(length, max(timeout - elapsed, 5))
        if pkg is None:
            raise RuntimeError("timeout while receiving package data")
        return pkg


_TCP_HEADER_STRUCT = struct.Struct("!I")
