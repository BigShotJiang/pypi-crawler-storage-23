import logging
import sys


logger = logging.getLogger(__package__)

if not logging.root.hasHandlers() and not logger.hasHandlers():
    handler = logging.StreamHandler(sys.stderr)
    handler.setFormatter(
        logging.Formatter("%(asctime)s %(name)s [%(levelname)s] %(message)s")
    )
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
