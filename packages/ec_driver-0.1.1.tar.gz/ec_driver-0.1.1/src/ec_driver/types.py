"""
Base data types for the driver and bench service.
"""

from __future__ import annotations

import typing as t

import base64
import enum

from pydantic import BaseModel, Field


class DriverInfo(BaseModel):
    """Driver information."""

    name: str
    version: str

    metadata: t.Any = None

    provides: list[StreamInfo] = Field(default_factory=lambda: [])
    consumes: list[StreamInfo] = Field(default_factory=lambda: [])


class BenchInfo(BaseModel):
    """Bench Service information."""

    version: str

    metadata: t.Any = None


class StreamInfo(BaseModel):
    """Stream information."""

    name: str
    typ: StreamType

    default: StreamValue

    metadata: t.Any = None


class StreamValueBytes(BaseModel):
    """Bytes stream value."""

    bytes: str


class StreamType(str, enum.Enum):
    """Stream type."""

    INT = "Int"
    FLOAT = "Float"
    BOOL = "Bool"
    STRING = "String"
    BYTES = "Bytes"

    @classmethod
    def from_value(cls, value: StreamValue) -> StreamType:
        match value:
            case bool():
                return cls.BOOL
            case int():
                return cls.INT
            case float():
                return cls.FLOAT
            case str():
                return cls.STRING
            case StreamValueBytes():
                return cls.BYTES
            case _:
                raise ValueError(f"unsupported type: {type(value)}")


StreamValue = int | float | bool | str | StreamValueBytes

PythonStreamValue = int | float | bool | str | bytes


def convert_from_python(value: PythonStreamValue) -> StreamValue:
    """Convert a Python value to a StreamValue."""
    match value:
        case bool():
            return value
        case int():
            return value
        case float():
            return value
        case str():
            return value
        case bytes():
            return StreamValueBytes(
                bytes=base64.urlsafe_b64encode(value).decode("utf-8")
            )
        case _:
            raise ValueError(f"unsupported type: {type(value)}")


def convert_to_python(value: StreamValue) -> PythonStreamValue:
    """Convert a StreamValue to a Python value."""
    match value:
        case bool():
            return value
        case int():
            return value
        case float():
            return value
        case str():
            return value
        case StreamValueBytes():
            return base64.urlsafe_b64decode(value.bytes)
        case _:
            raise ValueError(f"unsupported type: {type(value)}")
