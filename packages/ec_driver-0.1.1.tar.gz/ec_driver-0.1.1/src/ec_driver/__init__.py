"""
eChecker driver library for Python.
"""

from __future__ import annotations

import dataclasses as d
import typing as t

import enum
import threading
import time

from types import TracebackType

from ec_driver.codec import (
    DataPackage,
    DriverHelloPackage,
    Package,
    decode_data,
    encode_data,
    encode_package,
    decode_package,
    BenchHelloPackage,
)
from ec_driver.transport import Transport
from ec_driver.types import (
    DriverInfo,
    PythonStreamValue,
    StreamInfo,
    StreamType,
    BenchInfo,
    convert_from_python,
    convert_to_python,
)

from ._logger import logger


V = t.TypeVar("V", bound=PythonStreamValue)

T = t.TypeVar("T", bound=Transport)


__all__ = [
    "DriverState",
    "BenchState",
    "DriverBuilder",
    "Driver",
    "Stream",
    "VersionedValue",
    "Snapshot",
]


class DriverState(enum.IntEnum):
    """Driver state values."""

    ERROR = -1
    OFF = 0
    IDLE = 1
    READY = 2


class BenchState(enum.IntEnum):
    """Bench Service state values."""

    OFF = 0
    IDLE = 1
    STARTING = 2
    RUNNING = 3
    RESUMING = 4
    PAUSED = 5


class DriverBuilder:
    """Builder for a driver."""

    _data: _DriverData | None

    _bench_state: Stream[BenchState]
    _driver_state: Stream[DriverState]

    def __init__(self, name: str, version: str) -> None:
        self._data = _DriverData(DriverInfo(name=name, version=version))
        self._bench_state = self.create_consumed_stream("$bench::state", BenchState.OFF)
        self._driver_state = self.create_provided_stream(
            "$driver::state", DriverState.READY
        )

    @property
    def _data_checked(self) -> _DriverData:
        if self._data is None:
            raise ValueError(
                "do not use `DriverBuilder` after `build()` has been called"
            )
        return self._data

    def set_metadata(self, metadata: t.Any) -> None:
        """Set metadata for the driver."""
        self._data_checked.driver_info.metadata = metadata

    def create_provided_stream(
        self, name: str, default: V, *, metadata: t.Any = None
    ) -> Stream[V]:
        """Create a new stream provided by the driver."""
        state = self._data_checked
        value = convert_from_python(default)
        typ = StreamType.from_value(value)
        state.driver_info.provides.append(
            StreamInfo(name=name, typ=typ, default=value, metadata=metadata)
        )
        return state.provides_buffer.create_stream(default)

    def create_consumed_stream(
        self, name: str, default: V, *, metadata: t.Any = None
    ) -> Stream[V]:
        """Create a new stream consumed by the driver."""
        state = self._data_checked
        value = convert_from_python(default)
        typ = StreamType.from_value(value)
        state.driver_info.consumes.append(
            StreamInfo(name=name, typ=typ, default=value, metadata=metadata)
        )
        return state.consumes_buffer.create_stream(default)

    def build(self, transport: T) -> Driver[T]:
        """Build the driver with the given transport."""
        state = self._data_checked
        self._data = None
        return Driver(state, transport, self._bench_state, self._driver_state)


class Driver(t.Generic[T]):
    """Driver for sending and receiving values from the Bench Service."""

    _data: _DriverData

    _thread: threading.Thread | None
    _shutdown: threading.Event

    _send_lock: threading.Lock
    _last_version_sent: int

    transport: T

    bench_state: Stream[BenchState]
    driver_state: Stream[DriverState]

    def __init__(
        self,
        data: _DriverData,
        transport: T,
        bench_state: Stream[BenchState],
        driver_state: Stream[DriverState],
    ) -> None:
        self._data = data
        self._thread = None
        self._shutdown = threading.Event()
        self._send_lock = threading.Lock()
        self._last_version_sent = -1
        self.transport = transport
        self.bench_state = bench_state
        self.driver_state = driver_state

    def start(self) -> None:
        """
        Start the driver.

        The driver will run in its own background thread.
        """
        if self._thread is not None:
            raise RuntimeError("driver is already running")
        self._shutdown.clear()
        self._thread = threading.Thread(target=self._run)
        self._thread.start()

    def stop(self, wait_for_shutdown: bool = True) -> None:
        """Stop the driver and wait for it to shut down."""
        self._shutdown.set()
        thread = self._thread
        if wait_for_shutdown and thread is not None:
            thread.join()

    def wait_until_connected(self, timeout: float | None = None) -> None:
        """Wait until the driver is connected to the Bench Service."""
        start = time.monotonic()
        with self._data.bench_info_changed:
            while self._data.bench_info is None:
                elapsed = time.monotonic() - start
                if timeout is not None and timeout <= elapsed:
                    raise TimeoutError("timeout while waiting for connection")
                self._data.bench_info_changed.wait(
                    None if timeout is None else timeout - elapsed
                )

    def is_connected(self) -> bool:
        """
        Indicates whether the driver is connected to the Bench Service.

        This is not the same as the transport being connected.
        """
        return self.bench_info is not None

    def bench_info(self) -> BenchInfo | None:
        """Get information about the connected Bench Service, if available."""
        with self._data.bench_info_lock:
            return self._data.bench_info

    def send_data(self) -> bool:
        """
        Send any updated provided stream values to the Bench Service.

        Returns `True` if data was sent, `False` otherwise.
        """
        with self._send_lock:
            snapshot = self._data.provides_buffer.snapshot()
            if snapshot.version == self._last_version_sent:
                return False
            # Only send the data that has changed since the last update.
            updated_values = [
                v.value if v.version > self._last_version_sent else None
                for v in snapshot.values
            ]
            data = encode_data(updated_values)
            try:
                self._send_package(DataPackage(data))
            except Exception as error:
                logger.error(f"failed to send `DATA` package: {error}")
                return False
            self._last_version_sent = snapshot.version
            return True

    @property
    def consumes_snapshot(self) -> Snapshot:
        """Snapshot of the latest consumed stream values."""
        return self._data.consumes_buffer.snapshot()

    @property
    def provides_snapshot(self) -> Snapshot:
        """Snapshot of the latest provided stream values."""
        return self._data.provides_buffer.snapshot()

    def _send_package(self, pkg: Package) -> None:
        logger.debug("sending package %s", type(pkg).__name__)
        """Send a package to the bench service via the underlying transport."""
        self.transport.send(encode_package(pkg))

    def _receive_package(self) -> Package | None:
        """Receive a package from the bench service via the underlying transport."""
        pkg = self.transport.receive(5)
        if pkg is None:
            return None
        return decode_package(pkg)

    def _run(self) -> None:
        """Run the driver main loop."""
        # We collect the types here to avoid doing it on every received data package.
        consumed_types = [info.typ for info in self._data.driver_info.consumes]
        while not self._shutdown.is_set():
            logger.debug("starting connection to Bench Service")
            self._data.set_bench_info(None)
            with self._send_lock:
                self._last_version_sent = -1
            try:
                self.transport.reconnect()
            except Exception as error:
                logger.error(f"failed to connect to Bench Service: {error}")
                time.sleep(5)
                continue
            logger.debug("sending `DRIVER_HELLO` package to Bench Service")
            try:
                self._send_package(DriverHelloPackage(self._data.driver_info))
            except Exception as error:
                logger.error(f"failed to send `DRIVER_HELLO` package: {error}")
                time.sleep(5)
                continue
            while not self._shutdown.is_set() and self.transport.is_connected:
                try:
                    logger.debug("waiting for package from Bench Service")
                    pkg = self._receive_package()
                    if pkg is None:
                        # We hit a timeout while waiting for a package.
                        continue
                    logger.debug("received package %s", type(pkg).__name__)
                    match pkg:
                        case BenchHelloPackage(info):
                            self._data.set_bench_info(info)
                        case DataPackage():
                            decoded = decode_data(consumed_types, pkg.data)
                            with self._data.consumes_buffer:
                                for i, value in enumerate(decoded):
                                    if value is not None:
                                        self._data.consumes_buffer.set_value(
                                            i, convert_to_python(value)
                                        )
                        case _:
                            logger.warning(f"received unexpected package: {pkg}")
                except Exception as error:
                    logger.error(
                        "error while receiving and handling package: %s", error
                    )
                    time.sleep(1)
                    # Either the connection was lost, or we received malformed data. In
                    # both cases, our best shot is to abort and reconnect.
                    break
        self._shutdown.clear()
        self._thread = None


class Stream(t.Generic[V]):
    """Handle to a stream."""

    _buffer: _StreamValueBuffer
    _idx: int

    def __init__(self, buffer: _StreamValueBuffer, idx: int) -> None:
        self._buffer = buffer
        self._idx = idx

    @property
    def versioned_value(self) -> VersionedValue[V]:
        """Current value of the stream, including version information."""
        return t.cast(VersionedValue[V], self._buffer.buffer[self._idx])

    @property
    def value(self) -> V:
        """Current value of the stream."""
        return t.cast(V, self._buffer.buffer[self._idx].value)

    @value.setter
    def value(self, value: V) -> None:
        with self._buffer:
            self._buffer.set_value(self._idx, value)


@d.dataclass(frozen=True)
class Snapshot:
    """Snapshot of stream values at a specific version."""

    version: int
    values: list[VersionedValue[PythonStreamValue]]


@d.dataclass(frozen=True, repr=False)
class VersionedValue(t.Generic[V]):
    """Versioned stream value."""

    value: V
    version: int

    last_updated: float

    @property
    def age(self) -> float:
        """Age of the value in seconds."""
        return time.monotonic() - self.last_updated

    def __repr__(self) -> str:
        return f"VersionedValue(value={self.value!r}, version={self.version}, age={self.age:.3f}s)"


class _StreamValueBuffer:
    buffer: list[VersionedValue[PythonStreamValue]]

    current_version: int

    _current_snapshot: Snapshot | None

    _lock: threading.Lock
    _locked_by: int | None

    def __init__(self) -> None:
        self.buffer = []
        self.current_version = 0
        self._current_snapshot = None
        self._lock = threading.Lock()
        self._locked_by = None

    def create_stream(self, value: V) -> Stream[V]:
        """Create a new stream in the buffer."""
        idx = len(self.buffer)
        self.buffer.append(
            VersionedValue(value=value, version=0, last_updated=time.monotonic())
        )
        return Stream(self, idx)

    def acquire_lock(self, increment_version: bool = True) -> None:
        """Acquire the lock for stream values."""
        if self._locked_by == threading.get_ident():
            raise RuntimeError("stream value buffer is already locked by this thread")
        self._lock.acquire()
        self._locked_by = threading.get_ident()
        if increment_version:
            self.current_version += 1
            self._current_snapshot = None

    def release_lock(self):
        """Release the lock for stream values."""
        if self._locked_by != threading.get_ident():
            raise RuntimeError("current thread does not hold the lock")
        self._locked_by = None
        self._lock.release()

    def set_value(self, idx: int, value: PythonStreamValue) -> None:
        """
        Set the value of a stream in the buffer.

        This requires the current thread to hold the lock.
        """
        if self._locked_by != threading.get_ident():
            raise RuntimeError("current thread does not hold the lock")
        self.buffer[idx] = VersionedValue(
            value=value, version=self.current_version, last_updated=time.monotonic()
        )

    def snapshot(self) -> Snapshot:
        """Get a snapshot of the current stream values."""
        self.acquire_lock(False)
        try:
            if self._current_snapshot is None:
                self._current_snapshot = Snapshot(
                    self.current_version, self.buffer.copy()
                )
            return self._current_snapshot
        finally:
            self.release_lock()

    def __enter__(self) -> t.Self:
        self.acquire_lock()
        return self

    def __exit__(
        self,
        _exc_type: type[BaseException] | None,
        _exc_value: BaseException | None,
        _traceback: TracebackType | None,
    ) -> bool | None:
        self.release_lock()


class _DriverData:
    """Shared state of a driver."""

    driver_info: DriverInfo
    provides_buffer: _StreamValueBuffer
    consumes_buffer: _StreamValueBuffer
    bench_info: BenchInfo | None
    bench_info_lock: threading.Lock
    bench_info_changed: threading.Condition

    def __init__(self, info: DriverInfo) -> None:
        self.driver_info = info
        self.provides_buffer = _StreamValueBuffer()
        self.consumes_buffer = _StreamValueBuffer()
        self.bench_info = None
        self.bench_info_lock = threading.Lock()
        self.bench_info_changed = threading.Condition(self.bench_info_lock)

    def set_bench_info(self, info: BenchInfo | None) -> None:
        """Set the current bench info and notify any waiters if it changed."""
        with self.bench_info_lock:
            if self.bench_info != info:
                self.bench_info = info
                self.bench_info_changed.notify_all()
