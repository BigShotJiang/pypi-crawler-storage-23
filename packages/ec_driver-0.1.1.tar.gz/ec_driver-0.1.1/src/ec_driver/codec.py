"""
Functionality for encoding and decoding of driver packages.
"""

from __future__ import annotations

import dataclasses as d
import typing as t

import abc
import base64
import struct

from ec_driver.types import (
    DriverInfo,
    BenchInfo,
    PythonStreamValue,
    StreamType,
    StreamValue,
    StreamValueBytes,
)


def decode_package(pkg: bytes) -> Package:
    """Decode a package."""
    if len(pkg) == 0:
        raise ValueError("package must not be empty")
    tag = pkg[0]
    package_type = _PACKAGE_TYPES.get(tag)
    if package_type is None:
        raise ValueError(f"unknown package tag: {tag}")
    return package_type.decode_payload(pkg[1:])


def encode_package(pkg: Package) -> bytes:
    """Encode a package."""
    return bytes([pkg.TAG]) + pkg.encode_payload()


class Package(abc.ABC):
    """Base class for all packages."""

    TAG: t.ClassVar[int]

    @classmethod
    @abc.abstractmethod
    def decode_payload(cls, payload: bytes) -> t.Self:
        """Decode the package payload from the given bytes."""

    @abc.abstractmethod
    def encode_payload(self) -> bytes:
        """Encode the package payload into bytes for transmission."""


@d.dataclass(frozen=True)
class DriverHelloPackage(Package):
    """Package containing metadata about the driver."""

    TAG = 0x00

    info: DriverInfo

    @classmethod
    def decode_payload(cls, payload: bytes) -> t.Self:
        info = DriverInfo.model_validate_json(payload.decode("utf-8"))
        return cls(info)

    def encode_payload(self) -> bytes:
        return self.info.model_dump_json().encode("utf-8")


@d.dataclass(frozen=True)
class BenchHelloPackage(Package):
    """Package containing metadata about the Bench Service."""

    TAG = 0x01

    info: BenchInfo

    @classmethod
    def decode_payload(cls, payload: bytes) -> t.Self:
        info = BenchInfo.model_validate_json(payload.decode("utf-8"))
        return cls(info)

    def encode_payload(self) -> bytes:
        return self.info.model_dump_json().encode("utf-8")


@d.dataclass(frozen=True)
class DataPackage(Package):
    """Package containing stream data."""

    TAG = 0x10

    data: bytes

    @classmethod
    def decode_payload(cls, payload: bytes) -> t.Self:
        return cls(data=payload)

    def encode_payload(self) -> bytes:
        return self.data


def decode_data(types: t.Sequence[StreamType], data: bytes) -> list[StreamValue | None]:
    """Decode the provided stream data based on the given types."""
    bitmask_length = (len(types) + 7) // 8
    values: list[StreamValue | None] = []
    cursor = bitmask_length
    for i, typ in enumerate(types):
        if (data[i // 8] >> (i % 8)) & 1 == 0:
            values.append(None)
            continue
        match typ:
            case StreamType.BOOL:
                values.append(data[cursor] != 0)
                cursor += 1
            case StreamType.INT:
                values.append(_VALUE_INT.unpack_from(data, cursor)[0])
                cursor += _VALUE_INT.size
            case StreamType.FLOAT:
                values.append(_VALUE_FLOAT.unpack_from(data, cursor)[0])
                cursor += _VALUE_FLOAT.size
            case StreamType.STRING:
                (length,) = _LENGTH.unpack_from(data, cursor)
                cursor += _LENGTH.size
                str_bytes = data[cursor : cursor + length]
                values.append(str_bytes.decode("utf-8"))
                cursor += length
            case StreamType.BYTES:
                (length,) = _LENGTH.unpack_from(data, cursor)
                cursor += _LENGTH.size
                bytes_value = data[cursor : cursor + length]
                values.append(
                    StreamValueBytes(
                        bytes=base64.urlsafe_b64encode(bytes_value).decode("utf-8")
                    )
                )
                cursor += length
            case _:
                raise ValueError(f"unsupported stream type: {typ}")
    return values


def encode_data(values: t.Sequence[PythonStreamValue | None]) -> bytes:
    """Encode the data for a `DataPackage` based on the given values."""
    bitmask_length = (len(values) + 7) // 8
    data = bytearray(bitmask_length)
    for i, value in enumerate(values):
        if value is None:
            continue
        data[i // 8] |= 1 << (i % 8)
        match value:
            case bool():
                data.append(1 if value else 0)
            case int():
                data.extend(_VALUE_INT.pack(value))
            case float():
                data.extend(_VALUE_FLOAT.pack(value))
            case str():
                encoded = value.encode("utf-8")
                data.extend(_LENGTH.pack(len(encoded)))
                data.extend(encoded)
            case bytes():
                data.extend(_LENGTH.pack(len(value)))
                data.extend(value)
            case _:
                raise ValueError(f"unsupported value type: {type(value)}")
    return bytes(data)


_LENGTH = struct.Struct("!I")

_VALUE_INT = struct.Struct("!q")
_VALUE_FLOAT = struct.Struct("!d")

_PACKAGE_TYPES: t.Dict[int, t.Type[Package]] = {
    DriverHelloPackage.TAG: DriverHelloPackage,
    BenchHelloPackage.TAG: BenchHelloPackage,
    DataPackage.TAG: DataPackage,
}

PACKAGE_SIZE_LIMIT = 16 * 1024 * 1024  # 16 MiB
