# eChecker Driver Library for Python

This library allows you to write custom drivers for the eChecker software.
