def main():
    print("Hello from arraymorph!")


if __name__ == "__main__":
    main()
