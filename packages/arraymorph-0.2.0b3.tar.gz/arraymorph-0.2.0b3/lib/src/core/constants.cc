#include "arraymorph/core/constants.h"
#include<string>
SPlan SP = SPlan::S3;
QPlan SINGLE_PLAN = QPlan::NONE;
std::string BUCKET_NAME = "";
