"""Backward compatibility alias for graphsense.models.tx_value."""

from graphsense.models.tx_value import *  # noqa: F401, F403
