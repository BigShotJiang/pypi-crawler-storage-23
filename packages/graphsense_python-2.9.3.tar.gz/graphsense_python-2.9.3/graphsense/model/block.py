"""Backward compatibility alias for graphsense.models.block."""

from graphsense.models.block import *  # noqa: F401, F403
