"""Backward compatibility alias for graphsense.models.tag_summary."""

from graphsense.models.tag_summary import *  # noqa: F401, F403
