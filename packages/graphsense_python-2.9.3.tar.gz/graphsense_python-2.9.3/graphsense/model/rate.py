"""Backward compatibility alias for graphsense.models.rate."""

from graphsense.models.rate import *  # noqa: F401, F403
