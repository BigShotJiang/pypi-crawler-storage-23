"""Backward compatibility alias for graphsense.models.taxonomy."""

from graphsense.models.taxonomy import *  # noqa: F401, F403
