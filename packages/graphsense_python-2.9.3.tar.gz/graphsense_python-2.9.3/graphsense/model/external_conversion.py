"""Backward compatibility alias for graphsense.models.external_conversion."""

from graphsense.models.external_conversion import *  # noqa: F401, F403
