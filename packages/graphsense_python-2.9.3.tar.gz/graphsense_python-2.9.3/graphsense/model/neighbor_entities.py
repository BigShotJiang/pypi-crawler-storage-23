"""Backward compatibility alias for graphsense.models.neighbor_entities."""

from graphsense.models.neighbor_entities import *  # noqa: F401, F403
