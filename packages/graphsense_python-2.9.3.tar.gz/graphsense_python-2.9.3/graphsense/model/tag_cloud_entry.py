"""Backward compatibility alias for graphsense.models.tag_cloud_entry."""

from graphsense.models.tag_cloud_entry import *  # noqa: F401, F403
