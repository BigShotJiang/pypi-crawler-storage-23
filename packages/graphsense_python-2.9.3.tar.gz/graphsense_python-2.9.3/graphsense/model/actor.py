"""Backward compatibility alias for graphsense.models.actor."""

from graphsense.models.actor import *  # noqa: F401, F403
