"""Backward compatibility alias for graphsense.models.entity."""

from graphsense.models.entity import *  # noqa: F401, F403
