"""Backward compatibility alias for graphsense.models.neighbor_address."""

from graphsense.models.neighbor_address import *  # noqa: F401, F403
