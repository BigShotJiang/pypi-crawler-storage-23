"""Backward compatibility alias for graphsense.models.currency_stats."""

from graphsense.models.currency_stats import *  # noqa: F401, F403
