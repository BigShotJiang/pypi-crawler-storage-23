"""Backward compatibility alias for graphsense.models.actor_context."""

from graphsense.models.actor_context import *  # noqa: F401, F403
