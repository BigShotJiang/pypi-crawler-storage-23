"""Backward compatibility alias for graphsense.models.address_txs."""

from graphsense.models.address_txs import *  # noqa: F401, F403
