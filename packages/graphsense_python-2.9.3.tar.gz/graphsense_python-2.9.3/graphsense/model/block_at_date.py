"""Backward compatibility alias for graphsense.models.block_at_date."""

from graphsense.models.block_at_date import *  # noqa: F401, F403
