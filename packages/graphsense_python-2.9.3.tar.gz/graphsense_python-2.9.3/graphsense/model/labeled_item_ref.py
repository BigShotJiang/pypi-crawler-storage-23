"""Backward compatibility alias for graphsense.models.labeled_item_ref."""

from graphsense.models.labeled_item_ref import *  # noqa: F401, F403
