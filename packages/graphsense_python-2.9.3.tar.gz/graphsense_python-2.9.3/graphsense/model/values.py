"""Backward compatibility alias for graphsense.models.values."""

from graphsense.models.values import *  # noqa: F401, F403
