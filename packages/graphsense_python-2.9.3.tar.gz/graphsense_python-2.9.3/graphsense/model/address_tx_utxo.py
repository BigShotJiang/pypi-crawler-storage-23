"""Backward compatibility alias for graphsense.models.address_tx_utxo."""

from graphsense.models.address_tx_utxo import *  # noqa: F401, F403
