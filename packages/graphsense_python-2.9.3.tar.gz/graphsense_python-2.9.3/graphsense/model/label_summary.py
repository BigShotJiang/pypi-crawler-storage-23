"""Backward compatibility alias for graphsense.models.label_summary."""

from graphsense.models.label_summary import *  # noqa: F401, F403
