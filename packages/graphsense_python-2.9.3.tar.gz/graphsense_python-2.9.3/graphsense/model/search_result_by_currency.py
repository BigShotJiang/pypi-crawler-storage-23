"""Backward compatibility alias for graphsense.models.search_result_by_currency."""

from graphsense.models.search_result_by_currency import *  # noqa: F401, F403
