"""Backward compatibility alias for graphsense.models.neighbor_entity."""

from graphsense.models.neighbor_entity import *  # noqa: F401, F403
