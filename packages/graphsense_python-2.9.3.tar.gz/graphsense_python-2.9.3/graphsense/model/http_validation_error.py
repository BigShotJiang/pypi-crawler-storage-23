"""Backward compatibility alias for graphsense.models.http_validation_error."""

from graphsense.models.http_validation_error import *  # noqa: F401, F403
