"""Backward compatibility alias for graphsense.models.rates."""

from graphsense.models.rates import *  # noqa: F401, F403
