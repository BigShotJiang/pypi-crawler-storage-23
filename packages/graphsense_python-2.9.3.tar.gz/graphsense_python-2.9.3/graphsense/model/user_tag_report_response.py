"""Backward compatibility alias for graphsense.models.user_tag_report_response."""

from graphsense.models.user_tag_report_response import *  # noqa: F401, F403
