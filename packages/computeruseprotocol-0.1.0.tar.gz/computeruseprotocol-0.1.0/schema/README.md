# Schema Files

These schema files are bundled copies from the canonical source at [computeruseprotocol/computeruseprotocol](https://github.com/computeruseprotocol/computeruseprotocol/tree/main/schema).

They are included here for test validation (`test_schema.py`). For the authoritative specification, compact format spec, and full documentation, refer to the spec repo.
