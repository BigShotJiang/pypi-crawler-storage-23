"""CUP MCP Server — expose UI accessibility trees and actions to AI agents."""
