from __future__ import annotations

import argparse
import sys

from .extractor import scan_file
from .output import open_output


def build_parser() -> argparse.ArgumentParser:
    epilog = """Examples:

  # KV/plain
  spectre --logfile examples/sample_kv.log --spanid F76281848BD8288C --mode block --context 20

  # JSON-per-line
  spectre --logfile examples/sample_json.log --spanid a1b2c3d4e5f60718 --format json --mode context --context 10

  # traceparent (matches parent-id field)
  spectre --logfile examples/sample_traceparent.log --spanid 6f35a0c9d2d3b4a1 --format traceparent --mode block
"""
    p = argparse.ArgumentParser(
        prog="spectre",
        description="Extract context or logical log blocks for a given spanId (streaming, safe for large files).",
        epilog=epilog,
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )

    # Not required anymore: we can prompt interactively if missing.
    p.add_argument(
        "--spanid",
        required=False,
        help="Span id to search for (matched literally; case-insensitive by default).",
    )
    p.add_argument(
        "--logfile",
        required=False,
        help="Path to the log file to scan.",
    )
    p.add_argument(
        "--context",
        type=int,
        default=20,
        help="Number of lines before/after the match (default: 20).",
    )
    p.add_argument(
        "--mode",
        choices=["context", "block"],
        default="context",
        help="context: N lines before+after (grep -C). block: extract logical block including stack traces.",
    )
    p.add_argument(
        "--output",
        default=None,
        help="Write results to a file (default: stdout). Use '-' for stdout.",
    )
    p.add_argument(
        "--format",
        choices=["auto", "kv", "json", "traceparent"],
        default="auto",
        help="Force parsing mode (default: auto).",
    )

    ig = p.add_mutually_exclusive_group()
    ig.add_argument(
        "--ignore-case",
        dest="ignore_case",
        action="store_true",
        help="Case-insensitive matching (default).",
    )
    ig.add_argument(
        "--case-sensitive",
        dest="ignore_case",
        action="store_false",
        help="Case-sensitive matching.",
    )
    p.set_defaults(ignore_case=True)

    # Optional: force interactive mode even if args exist
    p.add_argument(
        "--interactive",
        action="store_true",
        help="Ask questions instead of relying on flags (can still use flags as defaults).",
    )

    return p


def _die_stdin_closed() -> None:
    # Friendly message instead of EOFError traceback.
    raise SystemExit(
        "Interactive mode needs stdin. If you're in Docker, run with -it:\n"
        "  docker run -it --rm ...\n"
        "Or provide --logfile and --spanid to avoid interactive prompts."
    )


def _prompt(text: str, default: str | None = None) -> str:
    if default is None or default == "":
        prompt = f"{text}: "
    else:
        prompt = f"{text} [{default}]: "

    try:
        val = input(prompt).strip()
    except EOFError:
        _die_stdin_closed()

    return val if val != "" else (default or "")


def _prompt_int(text: str, default: int, minimum: int | None = None) -> int:
    while True:
        raw = _prompt(text, str(default))
        try:
            v = int(raw)
        except ValueError:
            print("Please enter a valid integer.", file=sys.stderr)
            continue
        if minimum is not None and v < minimum:
            print(f"Please enter an integer >= {minimum}.", file=sys.stderr)
            continue
        return v


def _prompt_choice(text: str, choices: list[str], default: str) -> str:
    choices_str = "/".join(choices)
    while True:
        raw = _prompt(f"{text} ({choices_str})", default).strip()
        if raw in choices:
            return raw
        print(f"Please choose one of: {choices_str}", file=sys.stderr)


def _prompt_yes_no(text: str, default_yes: bool) -> bool:
    default = "y" if default_yes else "n"
    while True:
        raw = _prompt(f"{text} (y/n)", default).lower()
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        print("Please answer y or n.", file=sys.stderr)


def _needs_interactive(args: argparse.Namespace) -> bool:
    # If user forced interactive, do it.
    if getattr(args, "interactive", False):
        return True

    # If essential fields missing, prompt.
    if not getattr(args, "logfile", None) or not getattr(args, "spanid", None):
        return True

    return False


def _interactive_fill(args: argparse.Namespace) -> argparse.Namespace:
    print("\n=== spectre interactive mode ===\n")

    # logfile
    while True:
        logfile = _prompt("Path to log file", getattr(args, "logfile", None) or "")
        if logfile.strip() == "":
            print("Log file path is required.", file=sys.stderr)
            continue
        args.logfile = logfile
        break

    # spanid
    while True:
        spanid = _prompt("Span id to search for", getattr(args, "spanid", None) or "")
        if spanid.strip() == "":
            print("Span id is required.", file=sys.stderr)
            continue
        args.spanid = spanid
        break

    # mode / format / context / ignore_case / output
    args.mode = _prompt_choice("Mode", ["context", "block"], getattr(args, "mode", "context"))
    args.format = _prompt_choice("Format", ["auto", "kv", "json", "traceparent"], getattr(args, "format", "auto"))
    args.context = _prompt_int("Context lines before/after", getattr(args, "context", 20), minimum=0)
    args.ignore_case = _prompt_yes_no("Case-insensitive match?", getattr(args, "ignore_case", True))

    output_default = getattr(args, "output", None)
    out = _prompt("Output file (leave empty for stdout, use '-' for stdout)", output_default or "")
    args.output = out if out.strip() != "" else None

    print("\n=== Running ===")
    print(f"  logfile      : {args.logfile}")
    print(f"  spanid       : {args.spanid}")
    print(f"  mode         : {args.mode}")
    print(f"  format       : {args.format}")
    print(f"  context      : {args.context}")
    print(f"  ignore_case  : {args.ignore_case}")
    print(f"  output       : {args.output if args.output is not None else '(stdout)'}")
    print()

    return args


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    
    try:
        if _needs_interactive(args):
        # Prevent EOFError in non-interactive contexts (Docker without -it, CI, pipes, etc.)
            if not sys.stdin.isatty():
                parser.error(
                    "Interactive mode needs a TTY stdin.\n"
                    "Run Docker with -it (example):\n"
                    "  docker run -it --rm -v \"$PWD:/work\" <image>\n"
                    "Or pass --logfile and --spanid to skip interactive mode.\n"
                    "Or build a standalone binary with and then run:\n"
                    "spectre --interactive --logfile <path> --spanid <id>\n"
                    "Or use interactive mode with --interactive. its sets by default."
                )
            args = _interactive_fill(args)
    except KeyboardInterrupt:
        sys.stderr.write("Cancelled by user [Ctrl-C].\n")
        raise SystemExit(130)
    except EOFError:
        sys.stderr.write("Input close aborted by user [Ctrl-Z].\n")
        raise SystemExit(1)

    # Validate essential args (works for both interactive + flags)
    if not args.logfile:
        parser.error("Missing --logfile (or run with --interactive).")
    if not args.spanid:
        parser.error("Missing --spanid (or run with --interactive).")

    sink = None
    try:
        sink = open_output(args.output)
        try:
            with open(args.logfile, "r", encoding="utf-8", errors="replace") as fh:
                count = scan_file(
                    fh=fh,
                    sink=sink,
                    target_spanid=args.spanid,
                    context=args.context,
                    mode=args.mode,
                    fmt=args.format,
                    ignore_case=args.ignore_case,
                )
        except FileNotFoundError:
            parser.error(f"Log file not found: {args.logfile}")
            raise SystemExit(2)
        except PermissionError:
            parser.error(f"Permission denied reading log file: {args.logfile}")
            raise SystemExit(2)
        except OSError as e:
            parser.error(f"Failed to read log file: {args.logfile} ({e})")
            raise SystemExit(2)

        if count == 0:
            sink.writeln("NOT FOUND")
            raise SystemExit(1)
        raise SystemExit(0)
    finally:
        if sink is not None:
            sink.close()