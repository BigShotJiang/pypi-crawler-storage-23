from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable, Optional, TextIO
import sys

from .utils import Line


@dataclass
class OutputSink:
    fh: TextIO
    close_when_done: bool = False

    def write(self, s: str) -> None:
        self.fh.write(s)

    def writeln(self, s: str = "") -> None:
        self.fh.write(s + "\n")

    def flush(self) -> None:
        try:
            self.fh.flush()
        except Exception:
            pass

    def close(self) -> None:
        if self.close_when_done:
            try:
                self.fh.close()
            except Exception:
                pass


def open_output(path: Optional[str]) -> OutputSink:
    if not path or path == "-":
        return OutputSink(sys.stdout, close_when_done=False)
    fh = open(path, "w", encoding="utf-8", newline="\n")
    return OutputSink(fh, close_when_done=True)


def write_match(
    sink: OutputSink,
    index: int,
    match_line_no: int,
    matched_spanid: str,
    lines: Iterable[Line],
) -> None:
    sink.writeln(f"===== MATCH {index} START =====")
    sink.writeln(f"line: {match_line_no}")
    sink.writeln(f"spanId: {matched_spanid}")
    for ln in lines:
        # Keep original text; add a stable prefix with file line number.
        text = ln.text.rstrip("\n")
        sink.writeln(f"{ln.no:>8} | {text}")
    sink.writeln(f"===== MATCH {index} END =====")
    sink.writeln()
    sink.flush()