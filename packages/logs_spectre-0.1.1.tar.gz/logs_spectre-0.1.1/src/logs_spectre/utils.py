from __future__ import annotations

import re
from dataclasses import dataclass

# Timestamp patterns that mark a new top-level log entry.
# Supported (heuristic):
#   YYYY-MM-DD HH:MM:SS
#   YYYY-MM-DDTHH:MM:SS
TIMESTAMP_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}:\d{2}")

def is_timestamp_line(line: str) -> bool:
    return bool(TIMESTAMP_RE.match(line))

# Common stack-trace / continuation markers
CONTINUATION_PREFIXES = (
    "at ",
    "Caused by:",
    "Suppressed:",
    "...",
)

def is_continuation_line(line: str) -> bool:
    if not line:
        return False
    if line[0].isspace():
        return True
    for p in CONTINUATION_PREFIXES:
        if line.startswith(p):
            return True
    return False

@dataclass(frozen=True)
class Line:
    no: int
    text: str
