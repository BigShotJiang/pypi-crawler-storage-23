from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Callable, Deque, Iterable, Iterator, List, Optional, TextIO, Tuple

from .utils import Line, is_timestamp_line
from . import detectors
from .output import OutputSink, write_match

DetectorFn = Callable[[str], Optional[str]]

def _get_detector(fmt: str) -> DetectorFn:
    fmt = (fmt or "auto").lower()
    if fmt == "kv":
        return detectors.detect_spanid_kv
    if fmt == "json":
        return detectors.detect_spanid_json
    if fmt == "traceparent":
        return detectors.detect_spanid_traceparent
    return detectors.detect_spanid_auto

def _equals(a: str, b: str, ignore_case: bool) -> bool:
    return a.lower() == b.lower() if ignore_case else a == b

@dataclass
class _PendingContextMatch:
    index: int
    match_line_no: int
    matched_spanid: str
    lines: List[Line]            # prelude + match + after
    after_remaining: int

def scan_file(fh: TextIO, sink: OutputSink, target_spanid: str, context: int = 20, mode: str = "context",fmt: str = "auto", ignore_case: bool = True,) -> int:
    """Scan file stream and write all matches to sink.

    Returns number of matches written.
    """
    detector = _get_detector(fmt)
    mode = (mode or "context").lower()
    if mode not in ("context", "block"):
        raise ValueError(f"Unsupported mode: {mode}")

    before: Deque[Line] = deque(maxlen=max(0, int(context)))
    pending_context: List[_PendingContextMatch] = []

    match_count = 0
    match_index = 0

    capturing_block = False
    block_lines: List[Line] = []
    block_match_line_no = -1
    block_matched_spanid = ""
    block_prelude: List[Line] = []

    pending_reprocess: Optional[Tuple[int, str]] = None  # (line_no, line_text)

    def finalize_block() -> None:
        nonlocal capturing_block, block_lines, block_match_line_no, block_matched_spanid, block_prelude, match_count
        if not capturing_block:
            return
        all_lines = block_prelude + block_lines
        match_count += 1
        write_match(sink, match_count, block_match_line_no, block_matched_spanid, all_lines)
        capturing_block = False
        block_lines = []
        block_prelude = []
        block_match_line_no = -1
        block_matched_spanid = ""

    def finalize_context_if_ready(pm: _PendingContextMatch) -> bool:
        if pm.after_remaining <= 0:
            nonlocal match_count
            match_count += 1
            write_match(sink, match_count, pm.match_line_no, pm.matched_spanid, pm.lines)
            return True
        return False

    line_no = 0
    while True:
        if pending_reprocess is not None:
            line_no, raw = pending_reprocess
            pending_reprocess = None
        else:
            raw = fh.readline()
            if raw == "":
                break
            line_no += 1

        line = raw.rstrip("\n")

        # If we are capturing a block, decide whether this line starts a new event.
        if capturing_block:
            if is_timestamp_line(line):
                # New top-level entry: end current block BEFORE this line.
                finalize_block()
                # Reprocess this line as normal input.
                pending_reprocess = (line_no, raw)
                continue
            else:
                block_lines.append(Line(line_no, line))
                # Still update before-buffer to allow prelude context for later matches.
                before.append(Line(line_no, line))
                continue

        # Update any pending context matches with this line as "after" context.
        if pending_context:
            for pm in pending_context:
                if pm.after_remaining > 0:
                    pm.lines.append(Line(line_no, line))
                    pm.after_remaining -= 1
            # Finalize any that completed on this line
            pending_context = [pm for pm in pending_context if not finalize_context_if_ready(pm)]

        # Detect span id in current line
        found = detector(line)
        if found is not None and _equals(found, target_spanid, ignore_case):
            match_index += 1

            if mode == "context":
                # snapshot of before buffer + match line
                prelude = list(before)
                lines_out = prelude + [Line(line_no, line)]
                pm = _PendingContextMatch(
                    index=match_index,
                    match_line_no=line_no,
                    matched_spanid=found,
                    lines=lines_out,
                    after_remaining=max(0, int(context)),
                )
                # If context==0, finalize immediately
                if pm.after_remaining <= 0:
                    match_count += 1
                    write_match(sink, match_count, pm.match_line_no, pm.matched_spanid, pm.lines)
                else:
                    pending_context.append(pm)

            else:  # block
                capturing_block = True
                block_match_line_no = line_no
                block_matched_spanid = found
                block_prelude = list(before)  # include --context lines before match
                block_lines = [Line(line_no, line)]

            # Regardless of mode, keep before buffer updated
            before.append(Line(line_no, line))
            continue

        # Normal line: update before buffer
        before.append(Line(line_no, line))

    # End-of-file: finalize any active captures
    if capturing_block:
        finalize_block()

    # For context mode, finalize any pending matches even if we don't have enough "after" lines.
    if pending_context:
        for pm in pending_context:
            match_count += 1
            write_match(sink, match_count, pm.match_line_no, pm.matched_spanid, pm.lines)

    return match_count
