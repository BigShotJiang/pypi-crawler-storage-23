from __future__ import annotations

import json
import re
from typing import Any, Iterable, Optional

# KV/plain detection: spanId=..., span_id=..., span-id=..., spanid=...
# We accept = or : and optional quotes around the value.
_KV_RE = re.compile(
    r'''(?ix)
    \bspan(?:[_-]?id)\b\s*[:=]\s*
    (?:
        "(?P<qval>[^"]+)"
        |
        '(?P<sval>[^']+)'
        |
        (?P<val>[^\s,]+)
    )
    '''
)

# traceparent="00-<trace-id>-<parent-id>-<flags>"
_TRACEPARENT_RE = re.compile(
    r'''(?ix)
    \btraceparent\b\s*[:=]\s*
    "?                                   # optional quote
    (?P<version>[0-9a-f]{2})-
    (?P<trace_id>[0-9a-f]{32})-
    (?P<span_id>[0-9a-f]{16})-
    (?P<flags>[0-9a-f]{2})
    "?
    '''
)

# JSON keys we consider as span id keys (case-insensitive, normalized)
_SPAN_KEYS = {
    "spanid",
    "span_id",
    "span-id",
    "spanId",
    "SPANID",
}

def _normalize_key(k: str) -> str:
    # Normalize to a small set:
    # - lower
    # - turn '-' into '_'
    return k.strip().replace("-", "_").lower()

def detect_spanid_kv(line: str) -> Optional[str]:
    m = _KV_RE.search(line)
    if not m:
        return None
    return m.group("qval") or m.group("sval") or m.group("val")

def detect_spanid_traceparent(line: str) -> Optional[str]:
    m = _TRACEPARENT_RE.search(line)
    if not m:
        return None
    return m.group("span_id")

def detect_spanid_json(line: str) -> Optional[str]:
    # Parse safely: if invalid JSON, return None (caller may fall back to regex).
    obj: Any
    try:
        obj = json.loads(line)
    except Exception:
        return None

    if not isinstance(obj, dict):
        return None

    # Prefer explicit span id keys first
    for k, v in obj.items():
        nk = _normalize_key(str(k))
        if nk in ("spanid", "span_id"):
            if v is None:
                continue
            return str(v)

    # Also check if traceparent exists inside JSON; treat parent-id as span id
    for k, v in obj.items():
        if _normalize_key(str(k)) == "traceparent" and isinstance(v, str):
            tp = detect_spanid_traceparent(f'traceparent="{v}"')
            if tp:
                return tp

    return None

def detect_spanid_auto(line: str) -> Optional[str]:
    # Try JSON first (cheap if line starts with '{', but still safe if it doesn't)
    if line.lstrip().startswith("{"):
        s = detect_spanid_json(line)
        if s:
            return s

    # traceparent can appear in plain text or JSON string fragments
    s = detect_spanid_traceparent(line)
    if s:
        return s

    # KV/plain
    s = detect_spanid_kv(line)
    if s:
        return s

    # If JSON parsing failed earlier, do a last-resort KV regex anyway (already done)
    return None
