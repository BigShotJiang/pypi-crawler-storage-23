import io
from logs_spectre.extractor import scan_file
from logs_spectre.output import OutputSink

def test_context_mode_finds_all_matches():
    content = "\n".join([
        "2026-02-27 10:00:00 INFO start",
        "alpha spanId=AAA111",
        "beta",
        "gamma spanId=AAA111",
        "delta",
        "epsilon",
    ]) + "\n"
    fh = io.StringIO(content)
    out = io.StringIO()
    sink = OutputSink(out)

    count = scan_file(fh, sink, target_spanid="AAA111", context=1, mode="context", fmt="kv", ignore_case=True)
    assert count == 2
    txt = out.getvalue()
    assert "===== MATCH 1 START =====" in txt
    assert "===== MATCH 2 START =====" in txt
    # match line numbers should be present
    assert "line: 2" in txt
    assert "line: 4" in txt
