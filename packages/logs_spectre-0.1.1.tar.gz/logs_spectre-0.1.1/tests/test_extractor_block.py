import io
from logs_spectre.extractor import scan_file
from logs_spectre.output import OutputSink

def test_block_mode_includes_stacktrace_until_next_timestamp():
    content = "\n".join([
        "2026-02-27 10:00:00 INFO doing stuff spanId=DEADBEEF",
        "java.lang.RuntimeException: boom",
        "  at com.example.App.run(App.java:10)",
        "Caused by: java.io.IOException: no",
        "  at com.example.IO.read(IO.java:20)",
        "2026-02-27 10:00:01 INFO next event",
        "2026-02-27 10:00:02 INFO again spanId=DEADBEEF",
        "ok",
        "2026-02-27 10:00:03 INFO end",
    ]) + "\n"
    fh = io.StringIO(content)
    out = io.StringIO()
    sink = OutputSink(out)

    count = scan_file(fh, sink, target_spanid="DEADBEEF", context=1, mode="block", fmt="kv", ignore_case=True)
    assert count == 2
    txt = out.getvalue()
    # Block should include stacktrace lines and stop before next timestamp
    assert "java.lang.RuntimeException: boom" in txt
    assert "Caused by:" in txt
    # "next event" line should not be inside first block lines (but it appears elsewhere in output maybe as context prelude for second)
    # Ensure the first block end happens before 'next event' is printed with same match section.
    first_section = txt.split("===== MATCH 1 END =====")[0]
    assert "2026-02-27 10:00:01 INFO next event" not in first_section
