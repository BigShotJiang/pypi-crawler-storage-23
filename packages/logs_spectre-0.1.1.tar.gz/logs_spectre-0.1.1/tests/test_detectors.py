import pytest
from logs_spectre import detectors

def test_kv_variants():
    for line in [
        "spanId=F76281848BD8288C msg=ok",
        "span_id=F76281848BD8288C msg=ok",
        "span-id=F76281848BD8288C msg=ok",
        "spanid=F76281848BD8288C msg=ok",
        "SPANID: F76281848BD8288C",
        "foo spanId=\"F76281848BD8288C\" bar",
    ]:
        assert detectors.detect_spanid_kv(line).lower() == "f76281848bd8288c".lower()

def test_traceparent_parentid():
    line = 'traceparent="00-4bf92f3577b34da6a3ce929d0e0e4736-6f35a0c9d2d3b4a1-01"'
    assert detectors.detect_spanid_traceparent(line) == "6f35a0c9d2d3b4a1"

def test_json_spanid_and_traceparent():
    j1 = '{"level":"INFO","spanId":"A1B2C3D4E5F60718","msg":"ok"}'
    assert detectors.detect_spanid_json(j1) == "A1B2C3D4E5F60718"

    j2 = '{"traceparent":"00-4bf92f3577b34da6a3ce929d0e0e4736-6f35a0c9d2d3b4a1-01","msg":"x"}'
    assert detectors.detect_spanid_json(j2) == "6f35a0c9d2d3b4a1"

def test_auto_fallback():
    bad_json = '{"spanId": "X"  '  # invalid json
    # auto won't parse json, but KV regex won't find either -> None
    assert detectors.detect_spanid_auto(bad_json) is None
