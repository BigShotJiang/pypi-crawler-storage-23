#!/bin/bash
set -e

printf "===== Let's detect your OS =====\n\n"

RAW_OS="$(uname -s)"

case "$RAW_OS" in
  Linux*)    OS="Linux" ;;
  Darwin*)   OS="macOS" ;;
  CYGWIN*|MINGW*|MSYS*) OS="Windows" ;;
  *)         OS="UNKNOWN" ;;
esac

printf "Your OS is: %s\n" "$OS"
printf "lets build the project according to your %s\n\n" "$OS"

if [ "$OS" = "UNKNOWN" ]; then
  printf "Unsupported OS: %s\n" "$RAW_OS"
  exit 1
fi

# Create venv
python3 -m venv .venv

# Activate venv (different path on Windows Git Bash)
if [ "$OS" = "Windows" ]; then
  # Git Bash / MSYS
  source ".venv/Scripts/activate"
else
  # Linux / macOS
  source ".venv/bin/activate"
fi

python -m pip install -U pip
python -m pip install -e .
python -m pip install pyinstaller

printf "%s detected: building binary...\n" "$OS"
pyinstaller --onefile --console --name spectre -m spectre.cli

printf "Spectre installed successfully!\n"
printf "Run 'spectre --help' for more info\n\n"
printf "Enjoy!\n"