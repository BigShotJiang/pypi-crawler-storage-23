# az-table-catalog

A resilient, event-sourced indexing library for Azure Table Storage. 

`az-table-catalog` allows you to create high-performance, multi-indexed lookup tables. It uses a Write-Ahead Log (WAL) and a checkpoint-driven recovery model to ensure that your data remains consistent even if a process crashes mid-transaction.

## Features
* **Multi-Index Fan-out**: Search by any defined index key with O(1) performance.
* **Event Sourcing**: A permanent WAL serves as the "Source of Truth."
* **Deterministic RowKeys**: Prevents collisions using content-based fingerprints.
* **Auto-Recovery**: Automatically replays missing transactions on startup.
* **Schema Locking**: Prevents data corruption by locking configuration at runtime.

## Installation

```bash
pip install az-table-catalog
