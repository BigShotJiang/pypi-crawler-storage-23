"""Wumpus4 - all subcommand classes prefixed with `Wumpus` and suffixed with `Cmd`."""
