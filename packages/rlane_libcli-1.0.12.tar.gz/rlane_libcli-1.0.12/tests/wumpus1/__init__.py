"""Wumpus1 - all subcommand classes named `Command`."""
