"""Wumpus2 - all subcommand classes suffixed with `Cmd`."""
