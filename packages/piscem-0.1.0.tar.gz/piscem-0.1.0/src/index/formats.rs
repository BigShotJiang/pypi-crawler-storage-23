#[derive(Debug, Clone, Copy)]
pub enum ArtifactFormat {
    Cpp,
    Rust,
}
