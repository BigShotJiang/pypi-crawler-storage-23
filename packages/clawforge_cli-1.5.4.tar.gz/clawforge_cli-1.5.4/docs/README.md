# ClawForge Documentation

ClawForge is a multi-mode coding workflow CLI for orchestrating coding agents in tmux + git worktrees.

## Start Here
- [Getting Started](./getting-started.md)
- [Workflow Modes](./workflow-modes.md)
- [Command Reference](./command-reference.md)
- [Scenario Playbooks](./scenarios.md)
- [Dashboard (Go TUI)](./dashboard.md)
- [Architecture](./architecture.md)
- [Fleet Ops (memory, init, history)](./fleet-ops.md)
- [Evaluation Loop](./evaluation.md)
- [Configuration](./configuration.md)
- [Troubleshooting](./troubleshooting.md)
- [FAQ](./faq.md)

## Versions
- v0.5: observability (dashboard, cost, conflicts, templates)
- v0.6: fleet ops (multi-repo swarm, routing, memory, init, history)
- v0.6.2: eval loop (`clawforge eval`)
- v0.7: reliability (doctor, auto-clean, timeout, signal traps, file locking, pruning)
- v0.8: TUI view modes + nudge, swarm hardening
- v0.9: observability v2 (logs, on-complete, TUI preview)
- v1.0: milestone release
- v1.2: power features (config, multi-model review, summary, cost parsing)
- v1.3: developer experience (profiles, replay, export, completions, task deps, webhooks)
- v1.4: web dashboard (real-time browser UI, mobile-friendly)
- v1.5: dependency graph + first-class chaining (`deps`, `--after` for sprint/swarm)
