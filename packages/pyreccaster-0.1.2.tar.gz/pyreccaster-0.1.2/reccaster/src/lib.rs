// This file is part of Recsync-rs.
// Copyright (c) 2024 UK Research and Innovation, Science and Technology Facilities Council
//
// This project is licensed under both the MIT License and the BSD 3-Clause License.
// You must comply with both licenses to use, modify, or distribute this software.
// See the LICENSE file for details.

//! Client library for the RecSync protocol, used to register EPICS PV records
//! with a RecSync server over TCP.

/// Record type definitions.
pub mod record;
pub use self::record::Record;

use futures::SinkExt;
use std::{
    collections::HashMap,
    io,
    net::{IpAddr, Ipv4Addr, SocketAddr},
};
use tokio::{
    io::Interest,
    net::{TcpStream, UdpSocket},
};
use tokio_stream::StreamExt;
use tokio_util::codec::Framed;
use tracing::{debug, error, info};
use wire::{Announcement, Message, MessageCodec, MSG_MAGIC_ID};

/// An active RecSync caster that announces PV records to a RecSync server.
pub struct Reccaster {
    udpsock: UdpSocket,
    framed: Option<Framed<TcpStream, MessageCodec>>,
    buf: [u8; 1024],
    pvs: Vec<Record>,
    props: Option<HashMap<String, String>>,
    state: CasterState,
}

enum CasterState {
    Announcement,
    Handshake(Announcement),
    Upload,
    PingPong,
}

impl Reccaster {
    /// Create a new `Reccaster` that will register `records` with optional client
    /// properties `props` once a RecSync server is discovered.
    pub async fn new(records: Vec<Record>, props: Option<HashMap<String, String>>) -> Reccaster {
        let sock = UdpSocket::bind(format!("0.0.0.0:{}", wire::SERVER_ANNOUNCEMENT_UDP_PORT))
            .await
            .unwrap();
        debug!(
            "listening for announcement messages at {}",
            wire::SERVER_ANNOUNCEMENT_UDP_PORT
        );
        Self {
            udpsock: sock,
            framed: None,
            buf: [0; 1024],
            pvs: records,
            props,
            state: CasterState::Announcement,
        }
    }

    /// Run the caster indefinitely, cycling through discovery, handshake, upload,
    /// and keepalive phases as the connection state changes.
    pub async fn run(&mut self) {
        loop {
            match self.state {
                CasterState::Announcement => self.handle_announcement().await,
                CasterState::Handshake(_) => self.handle_handshake().await,
                CasterState::Upload => self.handle_upload().await,
                CasterState::PingPong => self.handle_pingpong().await,
            }
        }
    }

    async fn handle_announcement(&mut self) {
        let ready = match self.udpsock.ready(Interest::READABLE).await {
            Ok(ready) => ready,
            Err(_) => {
                self.state = CasterState::Announcement;
                return;
            }
        };
        if ready.is_readable() {
            match self.udpsock.try_recv_from(&mut self.buf) {
                Ok((len, addr)) => {
                    if len >= 16 {
                        match Self::parse_announcement_message(&self.buf[..len], addr) {
                            Ok(msg) => {
                                info!("Received announcement message: {:?}:{:?} with key:{:?} from: {:?}", msg.server_addr, msg.server_port, msg.server_key, addr);
                                self.state = CasterState::Handshake(msg);
                            }
                            Err(_) => {
                                debug!("Invalid announcement message");
                                self.state = CasterState::Announcement;
                            }
                        };
                    }
                }
                Err(ref err) if err.kind() == io::ErrorKind::WouldBlock => {}
                Err(err) => {
                    error!("{:?}", err)
                }
            };
        }
    }

    async fn handle_handshake(&mut self) {
        if let CasterState::Handshake(msg) = &mut self.state {
            let addr = msg.server_addr;
            let port = msg.server_port;
            let key = msg.server_key;
            let stream = match TcpStream::connect(format!("{}:{}", addr, port)).await {
                Ok(stream) => {
                    info!("Connected to {:?}:{}", addr, port);
                    stream
                }
                Err(_) => {
                    debug!("Connection failed {:?}:{}", addr, port);
                    self.state = CasterState::Announcement;
                    return;
                }
            };
            let codec = MessageCodec;
            let framed = Framed::new(stream, codec);
            self.framed = Some(framed);

            if let Some(framed) = &mut self.framed {
                let msg = match framed.next().await {
                    Some(Ok(msg)) => msg,
                    _ => {
                        self.state = CasterState::Announcement;
                        return;
                    }
                };
                match msg {
                    Message::ServerGreet(_) => {
                        let _ = framed
                            .send(Message::ClientGreet(wire::ClientGreet { serv_key: key }))
                            .await;
                        debug!("Greet Message with server key: {}", key);
                        self.state = CasterState::Upload;
                    }
                    _ => {
                        self.state = CasterState::Announcement;
                    }
                }
            }
        }
    }

    async fn handle_upload(&mut self) {
        if let CasterState::Upload = &mut self.state {
            if let Some(framed) = &mut self.framed {
                for (i, record) in self.pvs.iter().enumerate() {
                    let recid: u32 = i as u32 + 100;
                    // AddRecord Message
                    let record_name = &record.name;
                    let record_type = &record.r#type;
                    let msg = Message::AddRecord(wire::AddRecord {
                        recid,
                        atype: wire::AddRecordType::Record as u8,
                        rtlen: record_type.len() as u8,
                        rnlen: record_name.len() as u16,
                        rtype: record_type.to_string(),
                        rname: record_name.to_string(),
                    });
                    let _ = framed.send(msg.clone()).await;
                    debug!("Sending AddRecord Message: {:?}", msg);
                    // AddRecord alias Message if avaliable
                    if let Some(record_alias) = &record.alias {
                        let msg = Message::AddRecord(wire::AddRecord {
                            recid,
                            atype: wire::AddRecordType::Alias as u8,
                            rtlen: record_type.len() as u8,
                            rnlen: record_alias.len() as u16,
                            rtype: record_type.to_string(),
                            rname: record_alias.to_string(),
                        });
                        let _ = framed.send(msg.clone()).await;
                    };
                    // AddInfo Message
                    // Send Client Properties
                    if let Some(props) = &self.props {
                        for (key, value) in props {
                            let msg: Message = Message::AddInfo(wire::AddInfo {
                                recid: 0,
                                keylen: key.len() as u8,
                                valen: value.len() as u16,
                                key: key.to_string(),
                                value: value.to_string(),
                            });
                            let _ = framed.send(msg.clone()).await;
                            debug!("Sending AddInfo Message: {:?}", msg.clone());
                        }
                    }
                    // Send Record Properties
                    for (key, value) in &record.properties {
                        let msg = Message::AddInfo(wire::AddInfo {
                            recid,
                            keylen: key.len() as u8,
                            valen: value.len() as u16,
                            key: key.to_string(),
                            value: value.to_string(),
                        });
                        let _ = framed.send(msg.clone()).await;
                        debug!("Sending AddInfo Message: {:?}", msg.clone());
                    }
                }
                let _ = framed.send(Message::UploadDone(wire::UploadDone)).await;
                debug!("Sending UploadDone Message");
                self.state = CasterState::PingPong;
            }
        }
    }

    async fn handle_pingpong(&mut self) {
        if let CasterState::PingPong = &mut self.state {
            if let Some(framed) = &mut self.framed {
                while let Some(msg_result) = framed.next().await {
                    match msg_result {
                        Ok(msg) => match msg {
                            Message::Ping(ping_msg) => {
                                info!("received ping with nonce: {}", ping_msg.nonce);
                                if framed
                                    .send(Message::Pong(wire::Pong {
                                        nonce: ping_msg.nonce,
                                    }))
                                    .await
                                    .is_err()
                                {
                                    self.state = CasterState::Announcement;
                                    return;
                                }
                            }
                            _ => {
                                self.state = CasterState::Announcement;
                                return;
                            }
                        },
                        Err(_) => {
                            self.state = CasterState::Announcement;
                            return;
                        }
                    }
                }
                self.state = CasterState::Announcement;
            }
        }
    }

    fn parse_announcement_message(
        data: &[u8],
        src_addr: SocketAddr,
    ) -> Result<Announcement, &'static str> {
        let id = u16::from_be_bytes([data[0], data[1]]);
        // Checking if the ID is 'RC'
        if id != MSG_MAGIC_ID {
            return Err("Invalid ID");
        }

        let version = data[2];
        if version != 0 {
            return Err("Invalid version");
        }

        // Extracting the server address (IPv4, 4 bytes)
        let server_addr_bytes = &data[4..8];
        let mut server_addr = Ipv4Addr::new(
            server_addr_bytes[0],
            server_addr_bytes[1],
            server_addr_bytes[2],
            server_addr_bytes[3],
        );

        if server_addr.is_broadcast() {
            match src_addr.ip() {
                IpAddr::V4(addr) => {
                    server_addr = addr;
                }
                IpAddr::V6(_) => {
                    unimplemented!("IPv6 is not supported")
                }
            }
        }

        let server_port = u16::from_be_bytes([data[8], data[9]]);

        let server_key = u32::from_be_bytes([data[12], data[13], data[14], data[15]]);

        Ok(Announcement {
            id,
            server_addr,
            server_port,
            server_key,
        })
    }
}
