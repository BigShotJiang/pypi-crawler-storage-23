kimi-cli-main 项目架构总结

编辑时间: 2026年2月20日
创作者:andy
creator: andylee

一、整体技术选型（混合框架方案）                                                                    

  kimi-cli-main 采用了一个聪明的混合架构，而不是依赖单一框架：

  1. Rich (v14.2.0) - 负责终端渲染
    - Markdown 渲染和语法高亮
    - Live Display 实时更新
    - 自定义主题和样式
  2. Prompt-Toolkit (v3.0.52) - 负责用户交互
    - 自定义提示符
    - 文件路径和命令自动补全
    - 键盘快捷键绑定
  3. Textual/Toad - 可选的高级 TUI（Python 3.14+）

  ★ Insight ─────────────────────────────────────
  这种混合方案的智慧在于：分离关注点
  - Rich 专注于"如何展示"（渲染引擎）
  - Prompt-Toolkit 专注于"如何交互"（输入处理）
  - 两者通过 Wire 消息系统解耦，可独立升级

  这避免了单一框架的限制，是构建复杂 CLI 工具的最佳实践。
  ─────────────────────────────────────────────────

  二、输出机制的三大核心

  1. Wire 消息系统（SPMC 架构）

  Soul（AI引擎）──→ Wire ──→ UI（多订阅者）
                     ↓
                持久化到文件

  关键设计：
  - SPMC模式：Single Producer, Multiple Consumer
  - 消息合并：流式文本自动合并，减少UI刷新
  - 双队列：raw_queue（原始）+ merged_queue（优化后）

  代码位置：src/kimi_cli/wire/__init__.py

  2. Live Display 渲染循环

  with Live(
      self.compose(),
      console=console,
      refresh_per_second=10,  # 10 Hz 刷新
      transient=True,         # 临时显示
  ) as live:
      # 消费 Wire 消息并更新 UI

  内容块管理：
  - _ContentBlock - AI 输出的文本/思考
  - _ToolCallBlock - 工具调用展示
  - _ApprovalRequestPanel - 审批请求 UI
  - _StatusBlock - 状态信息

  代码位置：src/kimi_cli/ui/shell/visualize.py

  3. 自定义 Markdown 渲染器

  项目移除了 Rich 的默认样式，实现了完全自定义的 Markdown 渲染：
  - 基于 markdown-it 解析器
  - 自定义代码高亮（Pygments）
  - 移除背景色以适配终端
  - 支持表格、列表、链接

  代码位置：src/kimi_cli/utils/rich/markdown.py

  ★ Insight ─────────────────────────────────────
  流式输出的优化策略：
  1. 消息合并：连续的文本块合并为一次渲染
  2. 刷新节流：固定 10 Hz，避免过度渲染
  3. transient 模式：输出完成后清除临时内容

  这比简单的 print() 循环高效得多，是实现流畅 AI 对话的关键。
  ─────────────────────────────────────────────────

  三、事件驱动架构的四个层次

  层次 1：Wire 事件（Soul-UI 通信）

  type Event = (
      TurnBegin | TurnEnd       # 对话回合
      | StepBegin | StepInterrupted  # 执行步骤
      | StatusUpdate            # 状态更新
      | ContentPart             # 内容片段
      | ToolCall | ToolResult   # 工具调用
      | ApprovalRequest         # 审批请求
  )

  层次 2：键盘事件（用户交互）

  class KeyEvent(Enum):
      UP, DOWN, LEFT, RIGHT  # 方向键
      ENTER, ESCAPE, TAB     # 控制键
      CTRL_E                 # 组合键

  层次 3：Prompt-Toolkit 键盘绑定

  @_kb.add("c-x")
  def toggle_mode(event):
      """Ctrl+X 切换 Agent/Shell 模式"""

  @_kb.add("c-v")
  def paste(event):
      """Ctrl+V 粘贴（支持图像）"""

  层次 4：JSON-RPC 消息（进程间通信）

  用于 Web 模式的 WebSocket 通信和子进程管理。

  ★ Insight ─────────────────────────────────────
  多层事件系统的设计哲学：
  - 每层处理不同粒度的事件
  - 通过异步队列解耦层次
  - 使用 asyncio.Event 实现跨层协调（如取消操作）

  这种分层让你可以在不影响其他层的情况下修改某一层的实现。
  ─────────────────────────────────────────────────

  四、键盘监听的跨平台实现

  核心挑战：线程到异步的桥接

  # 独立线程监听键盘
  def keyboard_thread(emit_callback):
      while not cancel_event.is_set():
          key = read_key()  # 阻塞读取
          emit_callback(KeyEvent.UP)

  # 桥接到 asyncio
  def emit(event: KeyEvent):
      loop.call_soon_threadsafe(queue.put_nowait, event)

  Unix 实现（termios）

  import termios, tty

  # 设置原始模式
  old_attrs = termios.tcgetattr(sys.stdin)
  tty.setraw(sys.stdin.fileno())

  # 箭头键检测
  if ch == b"\x1b":
      next_ch = sys.stdin.read(2)
      if next_ch == b"[A":
          return KeyEvent.UP

  Windows 实现（msvcrt）

  import msvcrt

  # 扩展键检测
  if msvcrt.kbhit():
      ch = msvcrt.getch()
      if ch == b"\xe0":  # 扩展键前缀
          next_ch = msvcrt.getch()
          if next_ch == b"H":
              return KeyEvent.UP

  代码位置：src/kimi_cli/ui/shell/keyboard.py

  五、@ 筛选功能的完整实现

  CLI 版本核心机制

  1. 触发检测（智能守卫）

  # 提取 @ 后的片段
  def _extract_fragment(text: str) -> str | None:
      index = text.rfind("@")
      if index == -1:
          return None

      # 守卫：防止误触发（如 email@example.com）
      if index > 0:
          prev = text[index - 1]
          if prev.isalnum() or prev in (".", "-", "_", ...):
              return None  # ❌ 不触发

      return text[index + 1:]

  2. 模糊匹配 + 智能排序

  # 使用 FuzzyCompleter 进行初步匹配
  fuzzy_completer = FuzzyCompleter(word_completer)

  # 重新排序：basename 优先
  def _rank(completion):
      basename = path.split("/")[-1].lower()
      if basename.startswith(query):
          return 0  # 🥇 最高优先级
      elif query in basename:
          return 1  # 🥈 中等优先级
      else:
          return 2  # 🥉 跨路径匹配

  3. 两级缓存策略

  class LocalFileMentionCompleter:
      _FRESHNESS_SECONDS = 2.0  # 缓存刷新间隔

      def __init__(self):
          self._top_cache = None      # 顶层缓存（快速）
          self._deeper_cache = None   # 深度缓存（懒加载）

  代码位置：src/kimi_cli/ui/shell/prompt.py (第 135-383 行)

  Web 版本实现

  使用 React Hooks + TypeScript：
  - useFileMentions hook 管理状态
  - 懒加载工作空间文件（限制 500 文件）
  - 分组展示（附件 + 工作空间）
  - 键盘导航（↑↓ Enter Tab Esc）

  代码位置：web/src/features/chat/useFileMentions.ts

  ★ Insight ─────────────────────────────────────
  @ 筛选的核心设计要点：
  1. 触发守卫：避免在 URL、Email 中误触发
  2. basename 优先：用户通常记得文件名，而非完整路径
  3. 懒加载 + 缓存：平衡响应速度和内存占用
  4. 忽略规则：排除 node_modules、.git 等噪音

  这比简单的 ls + grep 体验好太多了！
  ─────────────────────────────────────────────────

  六、值得学习的工程实践

  1. 并发模型选择
  ┌──────────┬─────────────┬──────────────────────────┐
  │   场景   │    选择     │           原因           │
  ├──────────┼─────────────┼──────────────────────────┤
  │ 键盘监听 │ 线程 + 队列 │ 阻塞式 I/O，需要独立线程 │
  ├──────────┼─────────────┼──────────────────────────┤
  │ UI 渲染  │ asyncio     │ 需要协调多个异步任务     │
  ├──────────┼─────────────┼──────────────────────────┤
  │ 消息广播 │ SPMC 队列   │ 一对多通信，避免锁竞争   │
  └──────────┴─────────────┴──────────────────────────┘
  2. 生命周期管理

  # 启动流程
  listener.start()  → 启动线程
  wire.serve()      → 创建流
  view.visualize()  → 渲染循环

  # 优雅关闭
  cancel_event.set()       → 设置标志
  queue.shutdown()         → 关闭队列
  await asyncio.wait(...)  → 等待清理

  3. 信号处理（跨平台）

  # Unix: 优先使用 add_signal_handler
  loop.add_signal_handler(signal.SIGINT, handler)

  # Windows: 降级到 signal.signal
  signal.signal(signal.SIGINT, lambda s, f: handler())

  代码位置：src/kimi_cli/utils/signals.py

  4. 异步队列优化

  class Queue[T](asyncio.Queue):
      def shutdown(self, immediate=False):
          """优雅关闭：唤醒所有等待者"""
          if immediate:
              self._queue.clear()
          # 发送关闭信号
          self._enqueue_shutdown()

  代码位置：src/kimi_cli/utils/aioqueue.py

  七、项目结构总览

  src/kimi_cli/
  ├── ui/
  │   ├── shell/          # 主 TUI 实现
  │   │   ├── visualize.py   # 渲染循环 ⭐
  │   │   ├── prompt.py      # @ 筛选 ⭐
  │   │   ├── keyboard.py    # 键盘监听 ⭐
  │   │   └── console.py     # Rich 配置
  │   ├── print/          # 非交互模式
  │   └── acp/            # ACP 服务器
  ├── wire/               # 消息系统 ⭐
  │   ├── __init__.py       # Wire 核心
  │   ├── types.py          # 事件类型
  │   ├── jsonrpc.py        # JSON-RPC
  │   └── server.py         # Wire 服务器
  ├── utils/
  │   ├── aioqueue.py     # 异步队列 ⭐
  │   ├── broadcast.py    # 广播队列 ⭐
  │   ├── signals.py      # 信号处理
  │   └── rich/           # 自定义 Rich 组件
  └── web/                # Web UI

  八、可直接应用到你的 Agent SDK 的设计

  1. Wire 消息系统 - 用于 Agent 和 UI 之间的通信
  2. 异步队列 + shutdown - 优雅关闭机制
  3. 键盘监听器 - 支持交互式调试和控制
  4. @ 补全机制 - 用于文件/工具/Agent 选择
  5. Live Display - 实时展示 Agent 执行状态
  6. SPMC 广播 - 支持多个 UI 客户端同时观察

  ★ Insight ─────────────────────────────────────
  最重要的架构启示：
  kimi-cli 的成功在于不追求完美的抽象，而是务实的分层：
  - Rich 负责渲染（它擅长的）
  - Prompt-Toolkit 负责输入（它擅长的）
  - Wire 消息系统解耦二者

  在构建 Agent SDK 时，也应该：
  1. 分离"执行"和"展示"
  2. 使用消息队列解耦
  3. 支持多种 UI 前端（CLI/Web/API）
  ─────────────────────────────────────────────────