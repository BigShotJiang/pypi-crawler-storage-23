from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

EXAMPLES_DIR = Path(__file__).resolve().parents[1]
if str(EXAMPLES_DIR) not in sys.path:
    sys.path.insert(0, str(EXAMPLES_DIR))

import comate as comate_entry


class TestShutdownNoiseGuard(unittest.TestCase):
    def test_unraisable_keyboard_interrupt_is_suppressed_only_after_shutdown(self) -> None:
        guard = comate_entry._ShutdownNoiseGuard()
        forwarded: list[object] = []
        guard._orig_unraisablehook = lambda unraisable: forwarded.append(unraisable)  # type: ignore[assignment]

        kb = KeyboardInterrupt()
        unraisable = SimpleNamespace(exc_value=kb)

        guard._unraisablehook(unraisable)
        self.assertEqual(len(forwarded), 1)

        guard._shutdown_armed = True
        guard._unraisablehook(unraisable)
        self.assertEqual(len(forwarded), 1)

    def test_unraisable_non_keyboard_interrupt_is_forwarded(self) -> None:
        guard = comate_entry._ShutdownNoiseGuard()
        forwarded: list[object] = []
        guard._orig_unraisablehook = lambda unraisable: forwarded.append(unraisable)  # type: ignore[assignment]
        guard._shutdown_armed = True

        unraisable = SimpleNamespace(exc_value=RuntimeError("boom"))
        guard._unraisablehook(unraisable)
        self.assertEqual(len(forwarded), 1)

    def test_begin_shutdown_sets_sigint_ignore(self) -> None:
        guard = comate_entry._ShutdownNoiseGuard()
        current_thread = object()
        signal_mock = MagicMock()
        signal_mock.SIGINT = 2
        signal_mock.SIG_IGN = 1

        with (
            patch.object(comate_entry.threading, "current_thread", return_value=current_thread),
            patch.object(comate_entry.threading, "main_thread", return_value=current_thread),
            patch.object(comate_entry, "signal", signal_mock),
        ):
            guard.begin_shutdown()
            guard.begin_shutdown()

        signal_mock.signal.assert_called_once_with(signal_mock.SIGINT, signal_mock.SIG_IGN)


if __name__ == "__main__":
    unittest.main(verbosity=2)
