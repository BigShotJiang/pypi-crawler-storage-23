"""Terminal agent example package."""

