from __future__ import annotations

import asyncio
import logging
import os
import signal
import sys
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path

from rich.console import Console

from comate_agent_sdk import Agent
from comate_agent_sdk.agent import AgentConfig, ChatSession
from comate_agent_sdk.context import EnvOptions
from comate_agent_sdk.tools import tool

from terminal_agent.event_renderer import EventRenderer
from terminal_agent.logo import print_logo
from terminal_agent.rpc_stdio import StdioRPCBridge
from terminal_agent.status_bar import StatusBar
from terminal_agent.tui import TerminalAgentTUI

console = Console()
logger = logging.getLogger(__name__)


def _flush_langfuse_if_configured() -> None:
    """Flush Langfuse pending events synchronously to prevent atexit thread-join errors on Ctrl+C."""
    try:
        from langfuse import get_client
        get_client().flush()
    except Exception:
        pass


@contextmanager
def _sigint_guard() -> Iterator[None]:
    """Temporarily ignore SIGINT in critical shutdown windows."""
    if os.name == "nt":
        yield
        return
    if threading.current_thread() is not threading.main_thread():
        yield
        return

    try:
        previous_handler = signal.getsignal(signal.SIGINT)
        signal.signal(signal.SIGINT, signal.SIG_IGN)
        logger.debug("SIGINT guard enabled for shutdown")
    except Exception as exc:
        logger.debug(f"Failed to enable SIGINT guard, fallback to unguarded shutdown: {exc}")
        yield
        return

    try:
        yield
    finally:
        try:
            signal.signal(signal.SIGINT, previous_handler)
            logger.debug("SIGINT guard restored")
        except Exception as exc:
            logger.warning(f"Failed to restore SIGINT handler: {exc}", exc_info=True)


async def _shutdown_session(session: ChatSession, *, label: str) -> None:
    start = time.monotonic()
    try:
        shutdown = getattr(session, "shutdown", None)
        if callable(shutdown):
            await shutdown()
        else:
            await session.close()
    except Exception as exc:
        logger.warning(f"Session shutdown failed ({label}): {exc}", exc_info=True)
        return

    elapsed = time.monotonic() - start
    logger.info(f"Session shutdown completed ({label}) in {elapsed:.3f}s")


async def _graceful_shutdown(*sessions: ChatSession) -> None:
    unique_sessions: list[ChatSession] = []
    seen_ids: set[int] = set()
    for session in sessions:
        sid = id(session)
        if sid in seen_ids:
            continue
        seen_ids.add(sid)
        unique_sessions.append(session)

    start = time.monotonic()
    with _sigint_guard():
        for index, session in enumerate(unique_sessions, start=1):
            label = f"{index}/{len(unique_sessions)} session_id={session.session_id}"
            await _shutdown_session(session, label=label)
        _flush_langfuse_if_configured()

    elapsed = time.monotonic() - start
    logger.info(f"Graceful shutdown completed in {elapsed:.3f}s")


@tool("Add two numbers 涉及到加法运算 必须使用这个工具")
async def add(a: int, b: int) -> int:
    return a + b


def _build_agent() -> Agent:
    context7_api_key = os.getenv("CONTEXT7_API_KEY")
    exa_api_key = os.getenv("EXA_API_KEY")

    exa_tools = (
        "web_search_exa,"
        "web_search_advanced_exa,"
        "get_code_context_exa,"
        "crawling_exa"
    )
    exa_url = "https://mcp.exa.ai/mcp"
    if exa_api_key:
        exa_url = f"{exa_url}?exaApiKey={exa_api_key}&tools={exa_tools}"
    else:
        exa_url = f"{exa_url}?tools={exa_tools}"

    return Agent(
        config=AgentConfig(
            role="software_engineering",
            env_options=EnvOptions(system_env=True, git_env=True),
            use_streaming_task=True,  # 启用流式 Task（实时显示嵌套工具调用）
            mcp_servers={
                "context7": {
                    "type": "http",
                    "url": "https://mcp.context7.com/mcp",
                    "headers": {
                        "CONTEXT7_API_KEY": context7_api_key,
                    },
                },
                "wiretext": {
                    "command": "npx",
                    "args": ["-y", "@wiretext/mcp"]
                },
                "exa_search": {
                    "type": "http",
                    "url": exa_url,
                },
            },
        )
    )


def _resolve_session(agent: Agent, session_id: str | None) -> tuple[ChatSession, str]:
    if session_id:
        return ChatSession.resume(agent, session_id=session_id), "resume"
    return ChatSession(agent), "new"


def _format_exit_usage_line(usage: object) -> str:
    total_prompt_tokens = int(getattr(usage, "total_prompt_tokens", 0) or 0)
    total_prompt_cached_tokens = int(
        getattr(usage, "total_prompt_cached_tokens", 0) or 0
    )
    total_completion_tokens = int(getattr(usage, "total_completion_tokens", 0) or 0)
    total_reasoning_tokens = int(getattr(usage, "total_reasoning_tokens", 0) or 0)

    input_tokens = max(total_prompt_tokens - total_prompt_cached_tokens, 0)
    total_tokens = input_tokens + total_completion_tokens

    reasoning_part = f" (reasoning {total_reasoning_tokens:,})" if total_reasoning_tokens > 0 else ""
    return (
        f"Token usage: total={total_tokens:,} "
        f"input={input_tokens:,} (+ {total_prompt_cached_tokens:,} cached) "
        f"output={total_completion_tokens:,}{reasoning_part}"
    )


async def _preload_mcp_in_tui(session: ChatSession, renderer: EventRenderer) -> None:
    """在 TUI 内部异步加载 MCP，通过 renderer 输出状态消息."""
    if not session._agent.options.mcp_servers:
        return
    try:
        await session._agent.ensure_mcp_tools_loaded()
    except Exception as e:
        renderer.append_system_message(f"MCP init failed: {e}", severity="error")
        return

    mgr = session._agent._mcp_manager
    if mgr is None:
        return

    loaded = mgr.tool_infos
    if loaded:
        count = len(loaded)
        aliases = sorted({i.server_alias for i in loaded})
        renderer.append_system_message(f"MCP loaded: {', '.join(aliases)} ({count} tools)")


async def run(*, rpc_stdio: bool = False, session_id: str | None = None) -> None:
    agent = _build_agent()
    session, mode = _resolve_session(agent, session_id)

    if rpc_stdio:
        bridge = StdioRPCBridge(session)
        try:
            await bridge.run()
        finally:
            await _graceful_shutdown(session)
        return

    print_logo(console)
    # 不再阻塞等待 MCP，改为 TUI 内部异步加载
    status_bar = StatusBar(session)
    status_bar.set_mode(session.get_mode())
    if mode == "resume":
        await status_bar.refresh()

    renderer = EventRenderer(project_root=Path.cwd())

    # 配置 TUI logging handler（将 SDK 日志输出到 TUI）
    from terminal_agent.logging_adapter import setup_tui_logging
    setup_tui_logging(renderer)

    tui = TerminalAgentTUI(session, status_bar, renderer)
    tui.add_resume_history(mode)

    # 把 MCP loading 作为 TUI 内部初始化任务
    async def _mcp_loader() -> None:
        await _preload_mcp_in_tui(session, renderer)

    usage_line: str | None = None
    active_session = session
    try:
        await tui.run(mcp_init=_mcp_loader)
        active_session = tui.session
        try:
            usage = await active_session.get_usage()
            usage_line = _format_exit_usage_line(usage)
        except Exception as exc:
            logger.warning(
                f"Failed to collect usage for exit summary: {exc}",
                exc_info=True,
            )
    finally:
        if active_session is session:
            await _graceful_shutdown(active_session)
        else:
            await _graceful_shutdown(session, active_session)

    if usage_line:
        console.print(f"[dim]{usage_line}[/]")

    console.print(
        f"[dim]To continue this session, run [bold cyan]comate resume "
        f"{active_session.session_id}[/][/]"
    )


if __name__ == "__main__":
    argv_session_id = sys.argv[1] if len(sys.argv) > 1 else None
    asyncio.run(run(session_id=argv_session_id))
