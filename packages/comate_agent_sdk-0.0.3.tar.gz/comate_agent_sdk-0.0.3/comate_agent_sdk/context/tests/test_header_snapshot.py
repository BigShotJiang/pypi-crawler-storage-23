from __future__ import annotations

import pytest

from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import UserMessage


def test_header_snapshot_roundtrip_restores_only_header_items() -> None:
    """快照只持久化 static header 段；session_state（含 user_instruction）不纳入快照。"""
    source = ContextIR()
    source.set_system_prompt("SNAPSHOT_PROMPT", cache=False)
    source.set_tool_strategy("SNAPSHOT_TOOL_STRATEGY")
    source.set_system_env("<system_env>SNAPSHOT_ENV</system_env>")
    source.set_output_style("<output_style>SNAPSHOT_STYLE</output_style>")
    source.set_user_instruction("SNAPSHOT_USER_INSTRUCTION", cache=False)

    snapshot = source.export_header_snapshot()

    restored = ContextIR()
    restored.import_header_snapshot(snapshot)

    prompt_item = restored.header.find_one_by_type(ItemType.SYSTEM_PROMPT)
    tool_item = restored.header.find_one_by_type(ItemType.TOOL_STRATEGY)
    env_item = restored.session_state.find_one_by_type(ItemType.SYSTEM_ENV)
    style_item = restored.session_state.find_one_by_type(ItemType.OUTPUT_STYLE)
    assert prompt_item is not None
    assert tool_item is not None
    # session_state 在 resume 后被清空，由运行时重新注入
    assert env_item is None
    assert style_item is None
    assert prompt_item.content_text == "SNAPSHOT_PROMPT"
    assert tool_item.content_text == "SNAPSHOT_TOOL_STRATEGY"
    # user_instruction 不纳入快照，由运行时重新注入（生命周期对齐）
    assert restored.user_instruction_item is None


def test_header_snapshot_rejects_non_header_item() -> None:
    ctx = ContextIR()
    snapshot = {
        "schema_version": 1,
        "header_items": [
            {
                "item_type": "user_message",
                "message": None,
                "content_text": "bad",
                "token_count": 1,
                "priority": 50,
                "ephemeral": False,
                "destroyed": False,
                "tool_name": None,
                "created_at": 0.0,
                "metadata": {},
                "cache_hint": False,
                "offload_path": None,
                "offloaded": False,
                "is_tool_error": False,
                "created_turn": 0,
            }
        ],
        "user_instruction_item": None,
    }
    with pytest.raises(ValueError):
        ctx.import_header_snapshot(snapshot)


def test_header_snapshot_legacy_memory_item_silently_ignored() -> None:
    """旧版 schema（v2）中的 memory_item / user_instruction_item 字段被静默忽略，不报错。"""
    ctx = ContextIR()
    legacy_snapshot = {
        "schema_version": 1,
        "header_items": [],
        "memory_item": {
            "id": "legacy01",
            "item_type": "memory",
            "message": UserMessage(content="LEGACY_MEMORY", is_meta=True).model_dump(mode="json"),
            "content_text": "LEGACY_MEMORY",
            "token_count": 0,
            "priority": 100,
            "ephemeral": False,
            "destroyed": False,
            "tool_name": None,
            "created_at": 0.0,
            "metadata": {},
            "cache_hint": False,
            "offload_path": None,
            "offloaded": False,
            "is_tool_error": False,
            "created_turn": 0,
        },
    }

    # 不应抛出异常，旧字段静默忽略
    ctx.import_header_snapshot(legacy_snapshot)
    # user_instruction_item 不从快照恢复，由运行时刷新
    assert ctx.user_instruction_item is None
