from __future__ import annotations

from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import UserMessage


def _build_lines(total: int) -> str:
    return "\n".join([f"LINE_{idx:03d}" for idx in range(1, total + 1)])


def test_auto_memory_injected_as_meta_user_message() -> None:
    ctx = ContextIR()
    ctx.set_auto_memory("AUTO_MEMORY_BODY", source_path="/tmp/session/memory/MEMORY.md")

    assert ctx.memory is not None
    assert ctx.memory.item_type == ItemType.MEMORY
    assert isinstance(ctx.memory.message, UserMessage)
    assert bool(getattr(ctx.memory.message, "is_meta", False))
    assert ctx.memory.content_text == "AUTO_MEMORY_BODY"


def test_auto_memory_bootstrap_ensure_once() -> None:
    ctx = ContextIR()
    ctx.set_auto_memory(_build_lines(20), source_path="/tmp/session/memory/MEMORY.md")

    first = ctx.ensure_auto_memory_bootstrap()
    second = ctx.ensure_auto_memory_bootstrap()

    assert first is not None
    assert second is None
    assert first.item_type == ItemType.USER_MESSAGE
    assert first.metadata.get("origin") == "auto_memory_bootstrap"
    assert "LINE_001" in first.content_text


def test_auto_memory_periodic_reminder_every_10_turns_with_first_200_lines() -> None:
    ctx = ContextIR()
    ctx.set_auto_memory(_build_lines(260), source_path="/tmp/session/memory/MEMORY.md")
    ctx.set_turn_number(10)
    ctx.record_tool_event(tool_name="Task")

    reminder = ctx.inject_due_reminders()
    duplicate = ctx.inject_due_reminders()

    assert reminder is not None
    assert duplicate is None
    assert reminder.item_type == ItemType.SYSTEM_REMINDER
    assert "auto_memory_periodic" in list(reminder.metadata.get("reminder_rule_ids", []))
    assert "path: /tmp/session/memory/MEMORY.md" in reminder.content_text
    assert "LINE_200" in reminder.content_text
    assert "LINE_201" not in reminder.content_text


def test_auto_memory_periodic_reminder_requires_non_empty_memory() -> None:
    ctx = ContextIR()
    ctx.set_auto_memory("", source_path="/tmp/session/memory/MEMORY.md")
    ctx.set_turn_number(10)
    ctx.record_tool_event(tool_name="Task")

    reminder = ctx.inject_due_reminders()
    assert reminder is None
