import asyncio
import json
import unittest
from types import SimpleNamespace

from comate_agent_sdk.context.compaction import (
    CompactionStrategy,
    SelectiveCompactionPolicy,
    TypeCompactionRule,
)
from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ContextItem, ItemType
from comate_agent_sdk.llm.messages import (
    AssistantMessage,
    Function,
    ToolCall,
    ToolMessage,
    UserMessage,
)


class _EmptySummaryLLM:
    model = "fake-model"

    async def ainvoke(self, *, messages, tools=None, tool_choice=None):
        return SimpleNamespace(content="", usage=None)


class _ExceptionSummaryLLM:
    model = "fake-model"

    async def ainvoke(self, *, messages, tools=None, tool_choice=None):
        raise RuntimeError("summary invocation failed")


class _SummaryFalsePolicy(SelectiveCompactionPolicy):
    async def _fallback_full_summary_with_retry(self, context: ContextIR) -> tuple[bool, str]:  # noqa: D401
        return False, "compact_false"


class _FlakySummaryLLM:
    model = "fake-model"

    def __init__(self) -> None:
        self.calls = 0

    async def ainvoke(self, *, messages, tools=None, tool_choice=None):
        self.calls += 1
        if self.calls == 1:
            return SimpleNamespace(content="", usage=None, stop_reason="end_turn", thinking=None)
        return SimpleNamespace(content="<summary>ok summary</summary>", usage=None, stop_reason="end_turn", thinking=None)


class _CaptureSummaryLLM:
    model = "fake-model"

    def __init__(self) -> None:
        self.messages = None

    async def ainvoke(self, *, messages, tools=None, tool_choice=None):
        del tools, tool_choice
        self.messages = messages
        return SimpleNamespace(content="<summary>captured</summary>", usage=None, stop_reason="end_turn", thinking=None)


class _CancelledSummaryPolicy(SelectiveCompactionPolicy):
    async def _fallback_full_summary_with_retry(self, context: ContextIR) -> tuple[bool, str]:  # noqa: D401
        del context
        raise asyncio.CancelledError()


class TestCompactionRoundGuardAndRollback(unittest.TestCase):
    def _add_tool_block(
        self,
        ctx: ContextIR,
        *,
        call_id: str,
        tool_name: str = "Read",
    ) -> None:
        ctx.add_message(
            AssistantMessage(
                content=None,
                tool_calls=[
                    ToolCall(
                        id=call_id,
                        type="function",
                        function=Function(name=tool_name, arguments='{"path":"a.txt"}'),
                    )
                ],
            )
        )
        ctx.add_message(
            ToolMessage(
                tool_call_id=call_id,
                tool_name=tool_name,
                content=f"result-{call_id}",
            )
        )

    def _conversation_signature(self, ctx: ContextIR) -> str:
        rows = []
        for item in ctx.conversation.items:
            message_dump = item.message.model_dump(mode="python") if item.message is not None else None
            rows.append(
                {
                    "id": item.id,
                    "item_type": item.item_type.value,
                    "content_text": item.content_text,
                    "token_count": item.token_count,
                    "metadata": item.metadata,
                    "message": message_dump,
                }
            )
        return json.dumps(rows, ensure_ascii=False, sort_keys=True, default=str)

    def test_recent_12_rounds_are_protected_and_meta_not_counted(self) -> None:
        ctx = ContextIR()
        ctx.add_message(UserMessage(content="meta-header", is_meta=True))

        for i in range(1, 15):
            ctx.add_message(UserMessage(content=f"user-{i}", is_meta=False))
            ctx.add_message(UserMessage(content=f"meta-{i}", is_meta=True))
            ctx.add_message(AssistantMessage(content=f"assistant-{i}", tool_calls=None))

        rules = dict(SelectiveCompactionPolicy().rules)
        rules[ItemType.USER_MESSAGE.value] = TypeCompactionRule(
            strategy=CompactionStrategy.TRUNCATE,
            keep_recent=0,
        )
        rules[ItemType.ASSISTANT_MESSAGE.value] = TypeCompactionRule(
            strategy=CompactionStrategy.TRUNCATE,
            keep_recent=0,
        )

        policy = SelectiveCompactionPolicy(
            threshold=1,
            fallback_to_full_summary=False,
            rules=rules,
            dialogue_rounds_keep_min=12,
        )
        compacted = asyncio.run(policy.compact(ctx))
        self.assertTrue(compacted)

        real_users = [
            item.message.text
            for item in ctx.conversation.items
            if item.item_type == ItemType.USER_MESSAGE
            and isinstance(item.message, UserMessage)
            and not item.message.is_meta
        ]
        assistants = [
            item.message.text
            for item in ctx.conversation.items
            if item.item_type == ItemType.ASSISTANT_MESSAGE
            and isinstance(item.message, AssistantMessage)
        ]

        self.assertEqual(real_users, [f"user-{i}" for i in range(3, 15)])
        self.assertEqual(assistants, [f"assistant-{i}" for i in range(3, 15)])

    def test_rollback_on_summary_failed_result(self) -> None:
        ctx = ContextIR()
        for i in range(8):
            self._add_tool_block(ctx, call_id=f"call-{i}")
        before = self._conversation_signature(ctx)

        policy = _SummaryFalsePolicy(threshold=1, fallback_to_full_summary=True)
        compacted = asyncio.run(policy.compact(ctx))

        self.assertFalse(compacted)
        self.assertEqual(before, self._conversation_signature(ctx))
        self.assertEqual(policy.meta_records[-1].phase, "rollback")

    def test_rollback_on_empty_summary(self) -> None:
        ctx = ContextIR()
        for i in range(8):
            self._add_tool_block(ctx, call_id=f"call-{i}")
        before = self._conversation_signature(ctx)

        policy = SelectiveCompactionPolicy(
            threshold=1,
            llm=_EmptySummaryLLM(),
            fallback_to_full_summary=True,
        )
        compacted = asyncio.run(policy.compact(ctx))

        self.assertFalse(compacted)
        self.assertEqual(before, self._conversation_signature(ctx))
        self.assertEqual(policy.meta_records[-1].phase, "rollback")

    def test_rollback_on_summary_exception(self) -> None:
        ctx = ContextIR()
        for i in range(8):
            self._add_tool_block(ctx, call_id=f"call-{i}")
        before = self._conversation_signature(ctx)

        policy = SelectiveCompactionPolicy(
            threshold=1,
            llm=_ExceptionSummaryLLM(),
            fallback_to_full_summary=True,
        )
        compacted = asyncio.run(policy.compact(ctx))

        self.assertFalse(compacted)
        self.assertEqual(before, self._conversation_signature(ctx))
        self.assertEqual(policy.meta_records[-1].phase, "rollback")

    def test_summary_retry_recovers_from_first_empty_attempt(self) -> None:
        ctx = ContextIR()
        for i in range(8):
            self._add_tool_block(ctx, call_id=f"call-{i}")

        llm = _FlakySummaryLLM()
        policy = SelectiveCompactionPolicy(
            threshold=1,
            llm=llm,
            fallback_to_full_summary=True,
            summary_retry_attempts=2,
        )
        compacted = asyncio.run(policy.compact(ctx))

        self.assertTrue(compacted)
        self.assertGreaterEqual(llm.calls, 2)
        self.assertEqual(len(ctx.conversation.items), 1)
        self.assertEqual(ctx.conversation.items[0].item_type, ItemType.COMPACTION_SUMMARY)

    def test_default_rule_drops_compaction_summary(self) -> None:
        policy = SelectiveCompactionPolicy()
        rule = policy.rules[ItemType.COMPACTION_SUMMARY.value]
        self.assertEqual(rule.strategy, CompactionStrategy.DROP)

    def test_compaction_summary_not_in_summary_input(self) -> None:
        ctx = ContextIR()
        summary_text = "<summary>previous summary</summary>"
        summary_item = ContextItem(
            item_type=ItemType.COMPACTION_SUMMARY,
            message=UserMessage(content=summary_text),
            content_text=summary_text,
            token_count=ctx.token_counter.count(summary_text),
        )
        ctx.conversation.items.append(summary_item)
        ctx.add_message(UserMessage(content="new user request", is_meta=False))

        rules = dict(SelectiveCompactionPolicy().rules)
        rules[ItemType.COMPACTION_SUMMARY.value] = TypeCompactionRule(
            strategy=CompactionStrategy.NONE,
        )
        llm = _CaptureSummaryLLM()
        policy = SelectiveCompactionPolicy(
            threshold=1,
            llm=llm,
            fallback_to_full_summary=True,
            rules=rules,
        )
        compacted = asyncio.run(policy.compact(ctx))

        self.assertTrue(compacted)
        self.assertIsNotNone(llm.messages)
        assert llm.messages is not None
        payload = str(getattr(llm.messages[1], "text", ""))
        self.assertIn("new user request", payload)
        self.assertNotIn("previous summary", payload)

    def test_cancelled_error_also_rolls_back(self) -> None:
        ctx = ContextIR()
        for i in range(8):
            self._add_tool_block(ctx, call_id=f"call-{i}")
        before = self._conversation_signature(ctx)

        policy = _CancelledSummaryPolicy(
            threshold=1,
            fallback_to_full_summary=True,
        )

        with self.assertRaises(asyncio.CancelledError):
            asyncio.run(policy.compact(ctx))

        self.assertEqual(before, self._conversation_signature(ctx))
        self.assertEqual(policy.meta_records[-1].phase, "rollback")
        self.assertEqual(policy.meta_records[-1].reason, "cancelled")

    def test_system_reminder_is_excluded_from_summary_input(self) -> None:
        ctx = ContextIR()
        ctx.add_message(
            UserMessage(content="<system-reminder>\ninternal\n</system-reminder>", is_meta=True),
            item_type=ItemType.SYSTEM_REMINDER,
            metadata={
                "origin": "system_reminder",
                "reminder_rule_ids": ["rule-1"],
                "reminder_turn": 1,
            },
        )
        ctx.add_message(UserMessage(content="real user message", is_meta=False))

        llm = _CaptureSummaryLLM()
        policy = SelectiveCompactionPolicy(
            threshold=1,
            llm=llm,
            fallback_to_full_summary=True,
        )

        compacted = asyncio.run(policy.compact(ctx))

        self.assertTrue(compacted)
        self.assertIsNotNone(llm.messages)
        assert llm.messages is not None
        self.assertEqual(len(llm.messages), 2)
        payload = str(getattr(llm.messages[1], "text", ""))
        self.assertIn("real user message", payload)
        self.assertNotIn("<system-reminder>", payload)

    def test_skill_meta_user_message_kept_in_summary_input_by_type_filter(self) -> None:
        ctx = ContextIR()
        ctx.add_message(
            UserMessage(content="skill meta line", is_meta=True),
            item_type=ItemType.SKILL_METADATA,
            metadata={"skill_name": "demo-skill"},
        )
        ctx.add_message(
            UserMessage(content="skill prompt line", is_meta=True),
            item_type=ItemType.SKILL_PROMPT,
            metadata={"skill_name": "demo-skill"},
        )
        ctx.add_message(UserMessage(content="real user message", is_meta=False))

        rules = dict(SelectiveCompactionPolicy().rules)
        rules[ItemType.SKILL_METADATA.value] = TypeCompactionRule(
            strategy=CompactionStrategy.NONE,
        )
        rules[ItemType.SKILL_PROMPT.value] = TypeCompactionRule(
            strategy=CompactionStrategy.NONE,
        )

        llm = _CaptureSummaryLLM()
        policy = SelectiveCompactionPolicy(
            threshold=1,
            llm=llm,
            fallback_to_full_summary=True,
            rules=rules,
        )

        compacted = asyncio.run(policy.compact(ctx))

        self.assertTrue(compacted)
        self.assertIsNotNone(llm.messages)
        assert llm.messages is not None
        payload = str(getattr(llm.messages[1], "text", ""))
        self.assertIn("skill meta line", payload)
        self.assertIn("skill prompt line", payload)
        self.assertIn("real user message", payload)

    def test_policy_compact_pre_purges_system_reminder_without_runner(self) -> None:
        ctx = ContextIR()
        ctx.add_message(
            UserMessage(content="<system-reminder>\ninternal\n</system-reminder>", is_meta=True),
            item_type=ItemType.SYSTEM_REMINDER,
            metadata={
                "origin": "system_reminder",
                "reminder_rule_ids": ["rule-1"],
                "reminder_turn": 1,
            },
        )
        ctx.add_message(UserMessage(content="real user message", is_meta=False))

        policy = SelectiveCompactionPolicy(
            threshold=1,
            fallback_to_full_summary=False,
            rules={},
        )
        compacted = asyncio.run(policy.compact(ctx))

        self.assertTrue(compacted)
        self.assertEqual(len(ctx.conversation.items), 1)
        self.assertEqual(ctx.conversation.items[0].item_type, ItemType.USER_MESSAGE)


if __name__ == "__main__":
    unittest.main()
