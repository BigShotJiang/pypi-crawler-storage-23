"""选择性压缩模块。

按类型优先级逐步压缩（tool_result 先压缩，system_prompt 永不压缩），
并在选择性压缩后始终执行全量摘要。
"""

from __future__ import annotations

import asyncio
import copy
import json
import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING, Literal

from comate_agent_sdk.context.items import DEFAULT_PRIORITIES, ItemType
from comate_agent_sdk.context.observer import ContextEvent, EventType
from comate_agent_sdk.context.truncation import TruncationRecord

if TYPE_CHECKING:
    from comate_agent_sdk.agent.llm_levels import LLMLevel
    from comate_agent_sdk.context.fs import ContextFileSystem
    from comate_agent_sdk.context.ir import ContextIR
    from comate_agent_sdk.context.items import ContextItem
    from comate_agent_sdk.context.offload import OffloadPolicy
    from comate_agent_sdk.llm.base import BaseChatModel
    from comate_agent_sdk.llm.messages import BaseMessage
    from comate_agent_sdk.tokens import TokenCost

logger = logging.getLogger("comate_agent_sdk.context.compaction")

try:
    import tiktoken as _tiktoken

    _TIKTOKEN_AVAILABLE = True
except ImportError:
    _tiktoken = None  # type: ignore[assignment]
    _TIKTOKEN_AVAILABLE = False


def _cleanup_stale_error_items(context: "ContextIR", max_turns: int = 10) -> list[str]:
    """清理超过指定轮次的失败工具调用项。"""
    from comate_agent_sdk.llm.messages import AssistantMessage, ToolMessage

    current_turn = context.turn_number
    removed_ids: list[str] = []

    error_tool_results: list["ContextItem"] = []
    for item in context.conversation.items:
        if (
            item.item_type == ItemType.TOOL_RESULT
            and item.is_tool_error
            and (current_turn - item.created_turn) >= max_turns
        ):
            error_tool_results.append(item)

    if not error_tool_results:
        return removed_ids

    error_tool_call_ids = set()
    for item in error_tool_results:
        if isinstance(item.message, ToolMessage):
            error_tool_call_ids.add(item.message.tool_call_id)

    assistant_items_to_remove: list[str] = []
    for item in context.conversation.items:
        if item.item_type != ItemType.ASSISTANT_MESSAGE:
            continue
        if not isinstance(item.message, AssistantMessage):
            continue
        if not item.message.tool_calls:
            continue
        if all(tc.id in error_tool_call_ids for tc in item.message.tool_calls):
            assistant_items_to_remove.append(item.id)

    for item in error_tool_results:
        if context.conversation.remove_by_id(item.id):
            removed_ids.append(item.id)
            context.event_bus.emit(ContextEvent(
                event_type=EventType.ITEM_REMOVED,
                item_type=ItemType.TOOL_RESULT,
                item_id=item.id,
                detail=f"stale error tool_result removed (turn gap={current_turn - item.created_turn})",
            ))

    for item_id in assistant_items_to_remove:
        if context.conversation.remove_by_id(item_id):
            removed_ids.append(item_id)
            context.event_bus.emit(ContextEvent(
                event_type=EventType.ITEM_REMOVED,
                item_type=ItemType.ASSISTANT_MESSAGE,
                item_id=item_id,
                detail="associated assistant message removed (all tool_calls failed)",
            ))

    return removed_ids


@dataclass(frozen=True)
class _ToolCallInfo:
    tool_call_id: str
    tool_name: str


@dataclass(frozen=True)
class _ToolInteractionBlock:
    start_idx: int
    end_idx: int
    assistant_item_id: str
    tool_calls: list[_ToolCallInfo]
    tool_result_items: list["ContextItem"]


@dataclass
class _CompactionStats:
    tool_blocks_kept: int = 0
    tool_blocks_dropped: int = 0
    tool_calls_truncated: int = 0
    tool_results_truncated: int = 0


@dataclass(frozen=True)
class CompactionMetaRecord:
    phase: Literal["selective_start", "selective_done", "summary_start", "summary_done", "rollback"]
    tokens_before: int
    tokens_after: int
    tool_blocks_kept: int
    tool_blocks_dropped: int
    tool_calls_truncated: int
    tool_results_truncated: int
    reason: str


class CompactionStrategy(Enum):
    """压缩策略。"""

    NONE = "none"                # 不压缩
    DROP = "drop"                # 直接丢弃
    TRUNCATE = "truncate"        # 保留最近 N 个
    SUMMARIZE = "summarize"      # LLM 摘要（暂未实现，留接口）
    OFFLOAD_MIDDLE = "offload_middle"  # 首尾保留，中间卸载到磁盘


@dataclass
class TypeCompactionRule:
    """单个类型的压缩规则。"""

    strategy: CompactionStrategy = CompactionStrategy.NONE
    keep_recent: int = 5

    # OFFLOAD_MIDDLE 策略参数
    token_threshold: int = 500   # 超过此阈值才触发卸载
    head_tokens: int = 100       # 保留首部 tokens
    tail_tokens: int = 100       # 保留尾部 tokens


# 默认规则
DEFAULT_COMPACTION_RULES: dict[str, TypeCompactionRule] = {
    # 工具结果：超过阈值时首尾保留 + 中间卸载到磁盘
    ItemType.TOOL_RESULT.value: TypeCompactionRule(
        strategy=CompactionStrategy.OFFLOAD_MIDDLE,
        token_threshold=500,
        head_tokens=100,
        tail_tokens=100,
    ),
    ItemType.SKILL_PROMPT.value: TypeCompactionRule(
        strategy=CompactionStrategy.DROP
    ),
    ItemType.SKILL_METADATA.value: TypeCompactionRule(
        strategy=CompactionStrategy.DROP
    ),
    # 对话消息：永不压缩，保留完整对话骨架
    ItemType.ASSISTANT_MESSAGE.value: TypeCompactionRule(
        strategy=CompactionStrategy.NONE,
    ),
    ItemType.USER_MESSAGE.value: TypeCompactionRule(
        strategy=CompactionStrategy.NONE,
    ),
    # 以下类型永不压缩
    ItemType.SYSTEM_PROMPT.value: TypeCompactionRule(
        strategy=CompactionStrategy.NONE
    ),
    # 注意：Memory 存储在 ContextIR._memory 独立字段中，不在 conversation.items 中
    # 该规则永远不会被匹配，保留仅为向后兼容
    ItemType.MEMORY.value: TypeCompactionRule(
        strategy=CompactionStrategy.NONE
    ),
    ItemType.SUBAGENT_STRATEGY.value: TypeCompactionRule(
        strategy=CompactionStrategy.NONE
    ),
    ItemType.COMPACTION_SUMMARY.value: TypeCompactionRule(
        strategy=CompactionStrategy.DROP
    ),
    ItemType.OFFLOAD_PLACEHOLDER.value: TypeCompactionRule(
        strategy=CompactionStrategy.NONE
    ),
}


@dataclass
class SelectiveCompactionPolicy:
    """选择性压缩策略。"""

    threshold: int = 0
    rules: dict[str, TypeCompactionRule] = field(
        default_factory=lambda: dict(DEFAULT_COMPACTION_RULES)
    )
    llm: BaseChatModel | None = None
    fallback_to_full_summary: bool = True
    fs: ContextFileSystem | None = None
    offload_policy: OffloadPolicy | None = None
    token_cost: TokenCost | None = None
    level: LLMLevel | None = None
    source_prefix: str | None = None

    tool_blocks_keep_recent: int = 8
    tool_call_threshold: int = 500
    tool_result_threshold: int = 600
    preview_tokens: int = 200
    dialogue_rounds_keep_min: int = 15
    summary_retry_attempts: int = 2
    error_item_max_turns: int = 10  # 失败工具项最大保留轮次

    meta_records: list[CompactionMetaRecord] = field(default_factory=list, init=False)

    def should_compact(self, total_tokens: int) -> bool:
        """检查是否需要压缩。"""
        if self.threshold <= 0:
            return False
        return total_tokens >= self.threshold

    async def compact(self, context: "ContextIR") -> bool:
        """执行选择性压缩 + 全量摘要（事务化）。"""
        if self.threshold <= 0:
            return False

        # 在选择性压缩前先清理过期的失败工具调用
        if self.error_item_max_turns > 0:
            removed_error_ids = _cleanup_stale_error_items(
                context,
                max_turns=self.error_item_max_turns
            )
            if removed_error_ids:
                logger.info(
                    f"清理过期失败工具项: 移除 {len(removed_error_ids)} 条"
                )

        self.meta_records = []
        initial_tokens = context.total_tokens
        conversation_snapshot = copy.deepcopy(context.conversation.items)
        stats = _CompactionStats()

        logger.info(
            f"开始选择性压缩: current={initial_tokens}, threshold={self.threshold}"
        )
        self._append_meta(
            phase="selective_start",
            tokens_before=initial_tokens,
            tokens_after=initial_tokens,
            stats=stats,
            reason="started",
        )

        try:
            purged_reminders = self._purge_system_reminders(context)
            sorted_types = sorted(
                DEFAULT_PRIORITIES.items(),
                key=lambda x: x[1],
            )
            compacted_any = purged_reminders > 0
            protected_ids = self._collect_recent_round_protected_ids(context)

            for item_type, _ in sorted_types:
                rule = self.rules.get(item_type.value)
                if rule is None or rule.strategy == CompactionStrategy.NONE:
                    continue

                items = context.conversation.find_by_type(item_type)
                if not items:
                    continue

                tokens_before = context.total_tokens

                if rule.strategy == CompactionStrategy.DROP:
                    removed = context.conversation.remove_by_type(item_type)
                    if removed:
                        compacted_any = True
                        logger.info(
                            f"DROP {item_type.value}: 移除 {len(removed)} 条, "
                            f"释放 ~{tokens_before - context.total_tokens} tokens"
                        )

                elif rule.strategy == CompactionStrategy.TRUNCATE:
                    if item_type == ItemType.TOOL_RESULT:
                        removed_blocks = await self._truncate_tool_blocks(
                            context=context,
                            keep_recent=self.tool_blocks_keep_recent,
                            stats=stats,
                        )
                        if removed_blocks > 0:
                            compacted_any = True
                            logger.info(
                                f"TRUNCATE tool_blocks: 移除 {removed_blocks} 个块 "
                                f"(保留最近 {self.tool_blocks_keep_recent}), "
                                f"释放 ~{tokens_before - context.total_tokens} tokens"
                            )
                    else:
                        candidates = items
                        if item_type in (ItemType.USER_MESSAGE, ItemType.ASSISTANT_MESSAGE):
                            candidates = [it for it in items if it.id not in protected_ids]

                        if not candidates:
                            continue

                        if rule.keep_recent > 0 and len(candidates) <= rule.keep_recent:
                            continue

                        if rule.keep_recent <= 0:
                            items_to_remove = candidates
                        else:
                            items_to_remove = candidates[:-rule.keep_recent]

                        removed_count = 0
                        for item in items_to_remove:
                            if item.destroyed:
                                continue
                            if self._should_offload(item):
                                self.fs.offload(item)
                            if context.conversation.remove_by_id(item.id) is not None:
                                removed_count += 1

                        if removed_count > 0:
                            compacted_any = True
                            logger.info(
                                f"TRUNCATE {item_type.value}: 移除 {removed_count} 条 "
                                f"(保留最近 {rule.keep_recent}, 轮次保底={self.dialogue_rounds_keep_min}), "
                                f"释放 ~{tokens_before - context.total_tokens} tokens"
                            )

                elif rule.strategy == CompactionStrategy.OFFLOAD_MIDDLE:
                    offloaded_count = 0
                    for item in items:
                        if item.destroyed or item.offloaded:
                            continue
                        if item.token_count > rule.token_threshold:
                            success = await self._offload_middle_content(
                                context,
                                item,
                                head_tokens=rule.head_tokens,
                                tail_tokens=rule.tail_tokens,
                            )
                            if success:
                                offloaded_count += 1

                    if offloaded_count > 0:
                        compacted_any = True
                        logger.info(
                            f"OFFLOAD_MIDDLE {item_type.value}: 卸载 {offloaded_count} 条, "
                            f"释放 ~{tokens_before - context.total_tokens} tokens"
                        )

                current_tokens = context.total_tokens
                if current_tokens < self.threshold:
                    logger.info(
                        f"选择性压缩达到阈值: {initial_tokens} → {current_tokens} tokens "
                        f"(阈值={self.threshold})"
                    )
                    break

            selective_tokens = context.total_tokens
            self._append_meta(
                phase="selective_done",
                tokens_before=initial_tokens,
                tokens_after=selective_tokens,
                stats=stats,
                reason="done",
            )

            if self.fallback_to_full_summary:
                logger.info(
                    f"选择性压缩完成 ({initial_tokens} → {selective_tokens})，执行 LLM 全量摘要"
                )
                self._append_meta(
                    phase="summary_start",
                    tokens_before=selective_tokens,
                    tokens_after=selective_tokens,
                    stats=stats,
                    reason="always_run",
                )

                summary_success, summary_reason = await self._fallback_full_summary_with_retry(context)
                if not summary_success:
                    raise RuntimeError(f"summary_failed_or_empty:{summary_reason}")

                final_tokens = context.total_tokens
                self._append_meta(
                    phase="summary_done",
                    tokens_before=selective_tokens,
                    tokens_after=final_tokens,
                    stats=stats,
                    reason="success",
                )
                return True

            return compacted_any

        except asyncio.CancelledError:
            context.conversation.items = conversation_snapshot
            rollback_tokens = context.total_tokens
            self._append_meta(
                phase="rollback",
                tokens_before=initial_tokens,
                tokens_after=rollback_tokens,
                stats=stats,
                reason="cancelled",
            )
            logger.warning("压缩被取消，已回滚。", exc_info=True)
            raise

        except Exception as exc:
            context.conversation.items = conversation_snapshot
            rollback_tokens = context.total_tokens
            self._append_meta(
                phase="rollback",
                tokens_before=initial_tokens,
                tokens_after=rollback_tokens,
                stats=stats,
                reason=str(exc),
            )
            logger.warning(f"压缩失败，已回滚: {exc}", exc_info=True)
            return False

    def _purge_system_reminders(self, context: "ContextIR") -> int:
        """在压缩入口统一清理 system reminder。"""
        purge_func = getattr(context, "purge_system_reminders", None)
        if not callable(purge_func):
            return 0

        removed = int(purge_func(include_persistent=True))
        if removed > 0:
            logger.info(f"压缩前清理 system reminder: removed={removed}")
        return removed

    def _build_summary_input_messages(self, context: "ContextIR") -> list["BaseMessage"]:
        """构建全量摘要输入（按语义类型过滤）。"""
        messages: list["BaseMessage"] = []
        excluded_types = {ItemType.SYSTEM_REMINDER, ItemType.COMPACTION_SUMMARY}

        for item in context.conversation.items:
            if item.item_type in excluded_types:
                continue
            if str((item.metadata or {}).get("origin", "")).strip() == "auto_memory_bootstrap":
                continue
            if item.message is None:
                continue
            messages.append(item.message)
        return messages

    async def _truncate_tool_blocks(
        self,
        context: "ContextIR",
        *,
        keep_recent: int,
        stats: _CompactionStats | None = None,
    ) -> int:
        """按“最近 keep_recent 块保留，旧块整块删除”处理工具交互历史。"""
        blocks = self._extract_tool_blocks(context)
        if not blocks:
            if stats is not None:
                stats.tool_blocks_kept = 0
                stats.tool_blocks_dropped = 0
            return 0

        blocks_sorted = sorted(blocks, key=lambda b: b.start_idx)
        if keep_recent <= 0:
            kept_blocks: list[_ToolInteractionBlock] = []
            dropped_blocks = blocks_sorted
        else:
            kept_blocks = blocks_sorted[-keep_recent:]
            dropped_blocks = blocks_sorted[:-keep_recent]

        if stats is not None:
            stats.tool_blocks_kept = len(kept_blocks)
            stats.tool_blocks_dropped = len(dropped_blocks)

        for block in kept_blocks:
            calls_count, results_count = self._truncate_tool_block_fields(context, block)
            if stats is not None:
                stats.tool_calls_truncated += calls_count
                stats.tool_results_truncated += results_count

        removed = 0
        for block in sorted(dropped_blocks, key=lambda b: b.start_idx, reverse=True):
            del context.conversation.items[block.start_idx:block.end_idx + 1]
            removed += 1

        return removed

    def _truncate_tool_block_fields(
        self,
        context: "ContextIR",
        block: _ToolInteractionBlock,
    ) -> tuple[int, int]:
        """对保留工具块内字段做阈值截断。"""
        from comate_agent_sdk.llm.messages import AssistantMessage, ToolMessage

        tool_calls_truncated = 0
        tool_results_truncated = 0

        assistant_item = context.conversation.items[block.start_idx]
        if assistant_item.destroyed:
            return 0, 0
        assistant_msg = assistant_item.message
        if isinstance(assistant_msg, AssistantMessage) and assistant_msg.tool_calls:
            truncation_details: list[dict[str, object]] = []
            for tool_call in assistant_msg.tool_calls:
                arguments = tool_call.function.arguments or ""
                arguments_tokens = context.token_counter.count(arguments)
                if arguments_tokens <= self.tool_call_threshold:
                    continue
                tool_call.function.arguments = self._truncate_text(
                    text=arguments,
                    original_tokens=arguments_tokens,
                )
                truncation_details.append(
                    {
                        "field": "tool_call.arguments",
                        "tool_call_id": tool_call.id,
                        "original_tokens": arguments_tokens,
                        "kept_tokens": self.preview_tokens,
                        "threshold": self.tool_call_threshold,
                    }
                )
                tool_calls_truncated += 1

            if truncation_details:
                self._merge_truncation_metadata(assistant_item, truncation_details)
                self._refresh_assistant_item_tokens(context, assistant_item)

        for result_item in block.tool_result_items:
            if result_item.destroyed:
                continue

            result_msg = result_item.message
            if not isinstance(result_msg, ToolMessage):
                continue

            if (
                result_item.truncation_record is not None
                and result_item.truncation_record.is_formatter_truncated
            ):
                logger.debug(
                    "跳过已被 OutputFormatter 截断的 tool_result: "
                    f"tool_call_id={result_msg.tool_call_id}, "
                    f"reason={result_item.truncation_record.formatter_reason}"
                )
                continue

            result_text = result_msg.text
            result_tokens = context.token_counter.count(result_text)
            if result_tokens <= self.tool_result_threshold:
                continue

            result_msg.content = self._truncate_text(
                text=result_text,
                original_tokens=result_tokens,
            )
            result_item.content_text = result_msg.text
            result_item.token_count = context.token_counter.count(result_item.content_text)
            self._merge_truncation_metadata(
                result_item,
                [
                    {
                        "field": "tool_result.content",
                        "tool_call_id": result_msg.tool_call_id,
                        "original_tokens": result_tokens,
                        "kept_tokens": self.preview_tokens,
                        "threshold": self.tool_result_threshold,
                    }
                ],
            )
            tool_results_truncated += 1

        return tool_calls_truncated, tool_results_truncated

    def _truncate_text(self, *, text: str, original_tokens: int) -> str:
        preview = self._take_first_tokens(text=text, max_tokens=self.preview_tokens, total_tokens=original_tokens)
        return f"{preview}\n[TRUNCATED original~{original_tokens} tokens]"

    def _take_first_tokens(self, *, text: str, max_tokens: int, total_tokens: int) -> str:
        if not text:
            return text
        if max_tokens <= 0:
            return ""
        try:
            if not _TIKTOKEN_AVAILABLE:
                raise RuntimeError("tiktoken not available")
            encoder = _tiktoken.get_encoding("cl100k_base")
            token_ids = encoder.encode(text)
            return encoder.decode(token_ids[:max_tokens])
        except Exception:
            token_base = max(total_tokens, 1)
            ratio = min(max_tokens / token_base, 1.0)
            keep_chars = max(1, int(len(text) * ratio))
            return text[:keep_chars]

    def _extract_head_tail(
        self,
        text: str,
        *,
        head_tokens: int = 100,
        tail_tokens: int = 100,
    ) -> tuple[str, str, int]:
        """提取文本首尾部分。

        Returns:
            (head_text, tail_text, middle_tokens)
            当 middle_tokens == 0 时表示无需卸载（总长度不超过首尾之和）。
        """
        if not text:
            return text, "", 0
        try:
            if not _TIKTOKEN_AVAILABLE:
                raise RuntimeError("tiktoken not available")
            encoder = _tiktoken.get_encoding("cl100k_base")
            token_ids = encoder.encode(text)
            total = len(token_ids)

            if total <= head_tokens + tail_tokens:
                return text, "", 0

            head_text = encoder.decode(token_ids[:head_tokens])
            tail_text = encoder.decode(token_ids[-tail_tokens:])
            middle_tokens = total - head_tokens - tail_tokens
            return head_text, tail_text, middle_tokens
        except Exception:
            # 回退到字符估算
            total_chars = len(text)
            # 粗估每 token 约 4 字符
            chars_per_token = 4
            head_chars = head_tokens * chars_per_token
            tail_chars = tail_tokens * chars_per_token

            if total_chars <= head_chars + tail_chars:
                return text, "", 0

            middle_char_count = total_chars - head_chars - tail_chars
            middle_tokens_est = max(1, middle_char_count // chars_per_token)
            return text[:head_chars], text[-tail_chars:], middle_tokens_est

    async def _offload_middle_content(
        self,
        context: "ContextIR",
        item: "ContextItem",
        *,
        head_tokens: int = 100,
        tail_tokens: int = 100,
    ) -> bool:
        """首尾保留 + 中间卸载策略。

        与 destroy_ephemeral_messages() 兼容：
        - destroyed=True 或 offloaded=True 的 item 直接跳过。

        Returns:
            True if offloaded, False otherwise.
        """
        from comate_agent_sdk.llm.messages import ToolMessage

        if not self.fs:
            return False

        # 已被销毁或已卸载的 item 直接跳过
        if item.destroyed or item.offloaded:
            return False

        msg = item.message
        if not isinstance(msg, ToolMessage):
            return False

        # message 层面被标记销毁的也跳过
        if getattr(msg, "destroyed", False):
            return False

        text = msg.text
        head, tail, middle_tokens = self._extract_head_tail(
            text,
            head_tokens=head_tokens,
            tail_tokens=tail_tokens,
        )

        if middle_tokens <= 0:
            return False

        # 卸载完整原始内容到文件系统
        tool_call_id = msg.tool_call_id or item.id
        tool_name = item.metadata.get("tool_name") or item.tool_name or "unknown"
        write_result = self.fs.offload_tool_result(
            item,
            tool_call_id=tool_call_id,
            tool_name=tool_name,
            result_token_count=item.token_count,
        )

        # 构建新内容：首部 + 占位符 + 尾部
        abs_path = self.fs.root_path / write_result.relative_path
        new_content = (
            f"{head}\n\n"
            f"[... 已卸载 {middle_tokens} tokens ...]\n"
            f"[路径: {abs_path}]\n\n"
            f"{tail}"
        )

        # 更新 item 及其关联的 message
        msg.content = new_content
        item.content_text = new_content
        item.token_count = context.token_counter.count(new_content)
        item.offloaded = True
        item.offload_path = write_result.relative_path

        # 同步到 message 层（与 destroy_ephemeral_messages 保持一致）
        msg.offloaded = True
        msg.offload_path = str(abs_path)

        return True

    def _refresh_assistant_item_tokens(self, context: "ContextIR", item: "ContextItem") -> None:
        from comate_agent_sdk.llm.messages import AssistantMessage

        message = item.message
        if not isinstance(message, AssistantMessage):
            return

        content_text = message.text
        if message.tool_calls:
            tool_calls_json = json.dumps(
                [
                    {
                        "id": tc.id,
                        "type": tc.type,
                        "function": {"name": tc.function.name, "arguments": tc.function.arguments},
                    }
                    for tc in message.tool_calls
                ],
                ensure_ascii=False,
            )
            content_text = content_text + "\n" + tool_calls_json if content_text else tool_calls_json

        item.content_text = content_text
        item.token_count = context.token_counter.count(content_text)

    def _merge_truncation_metadata(
        self,
        item: "ContextItem",
        details: list[dict[str, object]],
    ) -> None:
        if item.truncation_record is None:
            item.truncation_record = TruncationRecord()
        item.truncation_record.compaction_details.extend(details)

        item.metadata["truncated"] = True
        item.metadata["truncation"] = {
            "details": item.truncation_record.compaction_details,
        }

    def _collect_recent_round_protected_ids(self, context: "ContextIR") -> set[str]:
        """收集受保护的 item IDs（最近轮次 + thinking blocks in tool loop）。

        保护两类 assistant messages：
        1. 最近 N 轮对话（dialogue_rounds_keep_min）
        2. 当前 tool loop 中含 thinking blocks 的 assistant messages（Anthropic 约束）
        """
        from comate_agent_sdk.llm.messages import UserMessage

        items = context.conversation.items
        round_ranges: list[tuple[int, int]] = []
        round_start: int | None = None

        for idx, item in enumerate(items):
            message = item.message
            if isinstance(message, UserMessage) and not bool(getattr(message, "is_meta", False)):
                if round_start is not None:
                    round_ranges.append((round_start, idx - 1))
                round_start = idx

        if round_start is not None:
            round_ranges.append((round_start, len(items) - 1))

        # 即使没有轮次保护，也要保护 tool loop 中的 thinking blocks
        if not round_ranges:
            return set(context._thinking_protected_assistant_ids)

        protected_ranges = round_ranges[-self.dialogue_rounds_keep_min:]
        protected_ids: set[str] = set()
        for start, end in protected_ranges:
            for item in items[start:end + 1]:
                if item.item_type in (ItemType.USER_MESSAGE, ItemType.ASSISTANT_MESSAGE):
                    protected_ids.add(item.id)

        # 合并 thinking 保护 IDs（tool loop 中含 thinking blocks 的 assistant messages）
        thinking_protected = context._thinking_protected_assistant_ids
        if thinking_protected:
            logger.debug(
                f"Thinking-protected assistant messages (in tool loop): {len(thinking_protected)} items"
            )
        protected_ids.update(thinking_protected)

        return protected_ids

    def _append_meta(
        self,
        *,
        phase: Literal["selective_start", "selective_done", "summary_start", "summary_done", "rollback"],
        tokens_before: int,
        tokens_after: int,
        stats: _CompactionStats,
        reason: str,
    ) -> None:
        self.meta_records.append(
            CompactionMetaRecord(
                phase=phase,
                tokens_before=tokens_before,
                tokens_after=tokens_after,
                tool_blocks_kept=stats.tool_blocks_kept,
                tool_blocks_dropped=stats.tool_blocks_dropped,
                tool_calls_truncated=stats.tool_calls_truncated,
                tool_results_truncated=stats.tool_results_truncated,
                reason=reason,
            )
        )

    def _extract_tool_blocks(self, context: "ContextIR") -> list[_ToolInteractionBlock]:
        """从 conversation 中提取工具交互块（assistant tool_calls + tool_results）。"""
        from comate_agent_sdk.llm.messages import AssistantMessage, ToolMessage, UserMessage

        items = context.conversation.items
        blocks: list[_ToolInteractionBlock] = []
        i = 0
        while i < len(items):
            item = items[i]
            msg = item.message
            if not isinstance(msg, AssistantMessage) or not msg.tool_calls:
                i += 1
                continue

            tool_calls: list[_ToolCallInfo] = []
            for tc in msg.tool_calls:
                tool_calls.append(
                    _ToolCallInfo(
                        tool_call_id=tc.id,
                        tool_name=tc.function.name,
                    )
                )

            call_ids = {tc.tool_call_id for tc in tool_calls}

            found: set[str] = set()
            tool_result_items: list["ContextItem"] = []
            end_idx = i

            for j in range(i + 1, len(items)):
                next_msg = items[j].message

                # 避免跨越到下一个 tool_calls 起点
                if isinstance(next_msg, AssistantMessage) and next_msg.tool_calls:
                    break

                # 避免跨越到下一轮真实用户输入
                if isinstance(next_msg, UserMessage) and not bool(getattr(next_msg, "is_meta", False)):
                    break

                if isinstance(next_msg, ToolMessage) and next_msg.tool_call_id in call_ids:
                    tool_result_items.append(items[j])
                    found.add(next_msg.tool_call_id)
                    end_idx = j
                    if len(found) >= len(call_ids):
                        break

            blocks.append(
                _ToolInteractionBlock(
                    start_idx=i,
                    end_idx=end_idx,
                    assistant_item_id=item.id,
                    tool_calls=tool_calls,
                    tool_result_items=tool_result_items,
                )
            )
            i = end_idx + 1

        return blocks

    def _should_offload(self, item: "ContextItem") -> bool:
        """判断是否需要卸载。"""
        if not self.fs or not self.offload_policy:
            return False
        if not self.offload_policy.enabled:
            return False
        if item.item_type == ItemType.COMPACTION_SUMMARY:
            return False
        type_enabled = self.offload_policy.type_enabled.get(
            item.item_type.value,
            False,
        )
        if not type_enabled:
            return False
        threshold_by_type = getattr(self.offload_policy, "token_threshold_by_type", {}) or {}
        threshold = int(
            threshold_by_type.get(item.item_type.value, self.offload_policy.token_threshold)
        )
        return item.token_count >= threshold

    async def _fallback_full_summary_with_retry(self, context: "ContextIR") -> tuple[bool, str]:
        """带重试的全量摘要。"""
        max_attempts = max(1, int(self.summary_retry_attempts) + 1)
        last_reason = "unknown"
        for attempt in range(1, max_attempts + 1):
            success, reason = await self._fallback_full_summary_once(context)
            if success:
                return True, "success"
            last_reason = reason
            logger.warning(
                f"全量摘要失败 (attempt {attempt}/{max_attempts}): reason={reason}"
            )
        return False, last_reason

    async def _fallback_full_summary_once(self, context: "ContextIR") -> tuple[bool, str]:
        """单次全量摘要执行。"""
        from comate_agent_sdk.agent.compaction import CompactionService
        from comate_agent_sdk.context.items import ContextItem
        from comate_agent_sdk.llm.messages import UserMessage

        if self.llm is None:
            logger.warning("无法执行全量摘要：未提供 LLM")
            return False, "llm_missing"

        conversation_messages = self._build_summary_input_messages(context)
        if not conversation_messages:
            return False, "no_messages"

        usage_source = "compaction"
        if self.source_prefix:
            usage_source = f"{self.source_prefix}:compaction"

        service = CompactionService(
            llm=self.llm,
            token_cost=self.token_cost,
            usage_source=usage_source,
        )
        try:
            result = await service.compact(
                conversation_messages,
                self.llm,
                level=self.level,
            )
        except Exception as exc:
            return False, f"summary_exception:{type(exc).__name__}"

        if not result.compacted or not result.summary:
            reason = result.failure_reason or "compact_false"
            if result.stop_reason:
                reason = f"{reason}|stop_reason={result.stop_reason}"
            if result.failure_detail:
                reason = f"{reason}|{result.failure_detail}"
            return False, reason

        summary_item = ContextItem(
            item_type=ItemType.COMPACTION_SUMMARY,
            message=UserMessage(content=result.summary),
            content_text=result.summary,
            token_count=context.token_counter.count(result.summary),
            priority=DEFAULT_PRIORITIES[ItemType.COMPACTION_SUMMARY],
        )
        context.replace_conversation([summary_item])
        logger.info(f"全量摘要完成: 新 token 数 ~{summary_item.token_count}")
        return True, "success"
