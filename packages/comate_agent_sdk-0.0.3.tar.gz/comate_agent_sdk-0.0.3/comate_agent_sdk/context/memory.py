"""User Instruction 配置和文件加载。

User Instruction 是静态用户约束文本，通常来自 AGENTS.md，
在运行时注入为独立 meta UserMessage。
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

logger = logging.getLogger("comate_agent_sdk.context.memory")


@dataclass
class UserInstructionConfig:
    """User Instruction 配置。

    Attributes:
        files: 文件路径列表（支持 str 或 Path）
        max_tokens: token 上限，超出时 warning（不截断）
        cache: 是否建议 prompt cache
    """

    files: list[str | Path]
    max_tokens: int = 2000
    cache: bool = True


def load_user_instruction_content(config: UserInstructionConfig) -> str | None:
    """加载 User Instruction 内容。

    读取所有文件，用 \\n\\n 拼接为单个字符串。
    文件不存在或为空时记录 warning，但不报错。

    Args:
        config: UserInstructionConfig 配置

    Returns:
        拼接后的 user instruction 内容，如果所有文件都不存在或为空则返回 None
    """
    parts: list[str] = []

    for file_path in config.files:
        path = Path(file_path).expanduser()

        if not path.exists():
            logger.warning(f"User instruction 文件不存在: {path}")
            continue

        if not path.is_file():
            logger.warning(f"User instruction 路径不是文件: {path}")
            continue

        try:
            content = path.read_text(encoding="utf-8")
            if not content.strip():
                logger.warning(f"User instruction 文件为空: {path}")
                continue
            parts.append(content.strip())
        except Exception as e:
            logger.warning(f"读取 user instruction 文件失败 {path}: {e}")
            continue

    if not parts:
        return None

    return "\n\n".join(parts)
