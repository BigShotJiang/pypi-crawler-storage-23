from comate_agent_sdk.llm.minimax.chat import ChatMiniMax

__all__ = ["ChatMiniMax"]
