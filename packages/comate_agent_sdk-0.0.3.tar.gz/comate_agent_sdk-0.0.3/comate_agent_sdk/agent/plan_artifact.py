from __future__ import annotations

import random
import secrets
from pathlib import Path

_PLAN_WORDS: tuple[tuple[str, ...], tuple[str, ...], tuple[str, ...]] = (
    (
        "amber", "azure", "bold", "calm", "cold", "crisp", "dark", "deep",
        "dim", "dry", "dusk", "faint", "far", "fast", "fierce", "firm",
        "flat", "fluid", "fresh", "frost", "grand", "grave", "gray", "grim",
        "hollow", "hushed", "iron", "jade", "keen", "kind", "lean", "lone",
        "low", "lucid", "mute", "narrow", "null", "odd", "pale", "plain",
        "proud", "pure", "quick", "quiet", "raw", "rigid", "rough", "round",
        "sharp", "silver", "slim", "slow", "small", "soft", "stark", "stern",
        "still", "stone", "strong", "swift", "thin", "true", "vast", "vivid",
        "warm", "wide", "wild", "wise",
    ),
    (
        "broken", "burning", "carved", "chilled", "circling", "climbing",
        "coiled", "curling", "drifting", "falling", "fading", "floating",
        "folded", "frozen", "glowing", "hidden", "hollow", "humming", "idle",
        "leaning", "lifted", "listed", "locked", "looming", "lost", "muted",
        "nested", "open", "painted", "resting", "rising", "roaming", "rolling",
        "sealed", "shadowed", "shifting", "silent", "sinking", "slanted",
        "sleeping", "sliding", "slow", "smoldering", "still", "sunken",
        "tangled", "tilted", "torn", "traced", "turning", "twisted", "veiled",
        "waning", "woven", "yawning",
    ),
    (
        "arc", "ash", "basin", "bay", "blade", "bloom", "bone", "branch",
        "breach", "brick", "bridge", "brook", "cave", "chord", "cliff",
        "cloud", "coal", "coast", "creek", "crest", "crown", "curve", "dawn",
        "delta", "depth", "door", "dune", "dust", "edge", "ember", "field",
        "flame", "flint", "flow", "fog", "forest", "forge", "frost", "gale",
        "gap", "gate", "glade", "grain", "grove", "gulf", "helm", "hill",
        "horizon", "hull", "isle", "keep", "knot", "lake", "lamp", "lane",
        "layer", "leaf", "ledge", "light", "line", "link", "mast", "mesa",
        "mesh", "mist", "moon", "mound", "node", "notch", "orbit", "path",
        "peak", "plain", "plume", "pool", "port", "pulse", "reef", "ridge",
        "rift", "ring", "rise", "root", "rune", "sand", "seam", "shelf",
        "shore", "shard", "slab", "slope", "smoke", "span", "spark", "spire",
        "spring", "stone", "storm", "strand", "stream", "summit", "tide",
        "trail", "trench", "vale", "veil", "vent", "void", "wake", "wall",
        "wave", "well", "wind", "wire", "wood", "yard",
    ),
)


def build_plan_artifact_path() -> Path:
    plan_root = (Path.home() / ".agent" / "plans").expanduser().resolve()
    plan_root.mkdir(parents=True, exist_ok=True)
    adjs, parts, nouns = _PLAN_WORDS
    name = "plan"
    for _ in range(20):
        name = f"{random.choice(adjs)}-{random.choice(parts)}-{random.choice(nouns)}"
        path = plan_root / f"{name}.md"
        if not path.exists():
            return path
    suffix = secrets.token_hex(2)
    return plan_root / f"{name}-{suffix}.md"
