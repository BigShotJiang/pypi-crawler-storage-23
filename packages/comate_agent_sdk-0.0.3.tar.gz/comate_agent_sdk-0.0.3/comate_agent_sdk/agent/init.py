from __future__ import annotations

import logging
import uuid
from dataclasses import fields, is_dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from comate_agent_sdk.agent.compaction import CompactionConfig, CompactionService
from comate_agent_sdk.agent.llm_levels import LLMLevel
from comate_agent_sdk.context import ContextIR
from comate_agent_sdk.context.fs import ContextFileSystem
from comate_agent_sdk.context.offload import OffloadPolicy
from comate_agent_sdk.context.usage_tracker import ContextUsageTracker
from comate_agent_sdk.tokens import TokenCost
from comate_agent_sdk.tools.decorator import Tool

logger = logging.getLogger("comate_agent_sdk.agent")

DEFAULT_OUTPUT_STYLE = """<output_style>
- Respond in clear, practical Markdown.
- Keep answers concise by default, and expand only when needed.
- State assumptions explicitly when information is uncertain.
</output_style>"""

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime, AgentTemplate
    from comate_agent_sdk.llm.base import BaseChatModel


def _setup_env_info(runtime: "AgentRuntime", skip_git_env: bool = False) -> None:
    opts = runtime.options.env_options
    if opts is None:
        return
    if not opts.system_env and not opts.git_env:
        return

    from comate_agent_sdk.context.env import EnvProvider

    working_dir = opts.working_dir or runtime.options.project_root or Path.cwd()
    provider = EnvProvider(
        git_status_limit=opts.git_status_limit,
        git_log_limit=opts.git_log_limit,
    )

    if opts.system_env:
        extra_lines = None
        if skip_git_env:  # Plan subagent
            agent_home = Path("~/.agent").expanduser().resolve()
            plans_dir = agent_home / "plans"
            extra_lines = [
                f"agent_plans_dir          : {plans_dir}\n",
                "      → Write your plan files here. This is the ONLY allowed write location.\n",
            ]
        runtime._context.set_system_env(provider.get_system_env(working_dir, extra_lines=extra_lines))
        logger.info(f"已注入 SYSTEM_ENV（working_dir={working_dir}）")

    if opts.git_env and not skip_git_env:
        git_env = provider.get_git_env(working_dir)
        if git_env:
            runtime._context.set_git_env(git_env)
            logger.info(f"已注入 GIT_ENV（working_dir={working_dir}）")
        else:
            logger.info(f"未注入 GIT_ENV：working_dir={working_dir} 不在 git 仓库中或无法读取")


def _setup_output_style(runtime: "AgentRuntime") -> None:
    """注入会话级输出风格（幂等覆盖）。"""
    runtime._context.set_output_style(DEFAULT_OUTPUT_STYLE)


def _setup_mcp_session_state(runtime: "AgentRuntime") -> None:
    """标记 MCP session_state 需在真实请求循环中构建。"""
    if not bool(runtime.options.mcp_enabled):
        runtime._context.remove_mcp_tools()
        return

    runtime.invalidate_mcp_tools(reason="runtime_init")


def build_template(template: "AgentTemplate") -> None:
    """模板阶段初始化：只做只读解析与发现。"""
    from comate_agent_sdk.agent.settings import (
        discover_agents_md,
        discover_user_agents_md,
        load_user_model_preference,
        resolve_settings,
    )
    from comate_agent_sdk.agent.llm_levels import resolve_llm_levels

    cfg = template.config

    # ===== Subagent 解析（内置 + 发现 + 用户级 merge） =====
    # 语义：
    # - agents is None：默认行为，加载内置 + 自动发现 + 用户显式配置
    # - agents == ()：显式禁用 subagent（包括内置）
    # - agents 非空 tuple：内置 + 自动发现 + merge（同名以显式配置优先）
    # - 用户/发现的 agent 名称不能与内置重名（抛 ValueError）
    from comate_agent_sdk.subagent.builtin import get_builtin_agents, get_builtin_agent_names

    builtin_agents = get_builtin_agents()
    builtin_names = get_builtin_agent_names()

    resolved_agents: tuple | None
    if cfg.agents == ():
        # 显式禁用 subagent（包括内置）
        resolved_agents = ()
    else:
        from comate_agent_sdk.subagent import discover_subagents

        discovered = discover_subagents(project_root=cfg.project_root)
        user_agents = list(cfg.agents or ())

        # 同名冲突检测：用户/发现的 agent 不能与内置重名
        for a in discovered + user_agents:
            if a.name in builtin_names:
                raise ValueError(
                    f"Subagent '{a.name}' 与系统内置 subagent 同名，不允许覆盖。"
                    f"请将你的 subagent 改名。"
                    f"系统内置 subagent: {sorted(builtin_names)}"
                )

        # merge: discovered + user（同名以 user 优先）
        agent_map: dict[str, AgentDefinition] = {}
        for a in discovered:
            agent_map[a.name] = a
        for a in user_agents:
            agent_map[a.name] = a

        # 内置 + 用户级合并
        all_agents = list(builtin_agents) + list(agent_map.values())
        resolved_agents = tuple(all_agents) if all_agents else None

        if builtin_agents:
            logger.info(f"Loaded {len(builtin_agents)} builtin subagent(s)")
        if discovered:
            logger.info(f"Auto-discovered {len(discovered)} subagent(s)")

    # ===== Skill 自动发现和 Merge（模板期一次性） =====
    from comate_agent_sdk.skill import discover_skills

    discovered_skills = discover_skills(project_root=cfg.project_root)
    user_skills = list(cfg.skills or ())
    if discovered_skills or user_skills:
        user_skill_names = {s.name for s in user_skills}
        merged_skills = [s for s in discovered_skills if s.name not in user_skill_names]
        merged_skills.extend(user_skills)
        resolved_skills: tuple | None = tuple(merged_skills)
        if discovered_skills:
            logger.info(f"Auto-discovered {len(discovered_skills)} skill(s)")
    else:
        resolved_skills = None

    # ===== Settings + AGENTS.md user_instruction 注入（模板期一次性） =====
    settings = resolve_settings(
        sources=cfg.setting_sources,
        project_root=cfg.project_root,
    )

    resolved_user_instruction = cfg.user_instruction
    if cfg.setting_sources and resolved_user_instruction is None:
        agents_md_files: list[Path] = []
        source_used: str | None = None

        if "project" in cfg.setting_sources:
            agents_md_files = discover_agents_md(cfg.project_root)
            if agents_md_files:
                source_used = "project"

        if not agents_md_files and "user" in cfg.setting_sources:
            agents_md_files = discover_user_agents_md()
            if agents_md_files:
                source_used = "user"

        if agents_md_files and source_used:
            from comate_agent_sdk.context.memory import UserInstructionConfig

            resolved_user_instruction = UserInstructionConfig(files=agents_md_files)
            logger.info(f"自动发现 {source_used} AGENTS.md，注入 user_instruction: {agents_md_files}")

    # ===== LLM levels + 主 LLM 解析（模板期一次性） =====
    resolved_llm_levels = resolve_llm_levels(explicit=dict(cfg.llm_levels) if cfg.llm_levels else None, settings=settings)

    resolved_level: LLMLevel | None = template.level
    resolved_llm = template.llm
    if resolved_llm is None:
        preferred_level: LLMLevel | None = None
        can_read_user_settings = bool(cfg.setting_sources and "user" in cfg.setting_sources)
        if resolved_level is None and can_read_user_settings:
            preferred_level = load_user_model_preference()
            if preferred_level is not None:
                logger.info(f"应用 user model 偏好: {preferred_level}")

        effective_level: LLMLevel = resolved_level or preferred_level or "MID"
        if effective_level not in resolved_llm_levels:
            raise ValueError(f"level='{effective_level}' 不在 llm_levels 中")
        resolved_llm = resolved_llm_levels[effective_level]
        resolved_level = effective_level
    elif template.level is not None:
        logger.warning(f"同时指定了 llm= 和 level='{template.level}'，llm= 优先")
        resolved_level = template.level

    object.__setattr__(template, "_resolved_agents", resolved_agents)
    object.__setattr__(template, "_resolved_skills", resolved_skills)
    object.__setattr__(template, "_resolved_user_instruction", resolved_user_instruction)
    object.__setattr__(template, "_resolved_settings", settings)
    object.__setattr__(template, "_resolved_llm_levels", resolved_llm_levels)
    object.__setattr__(template, "_resolved_level", resolved_level)
    object.__setattr__(template, "_resolved_llm", resolved_llm)


_LLM_INTERNAL_RUNTIME_FIELDS = {
    "_client",
    "_langfuse_instrumented",
    "_cached_content_name",
    "_cached_content_key",
}


def _clone_llm_with_model(llm: "BaseChatModel", model_name: str) -> "BaseChatModel":
    """Clone an LLM instance while overriding its model field.

    This intentionally avoids dataclasses.replace to prevent carrying
    internal runtime caches (e.g., _client) into the cloned instance.
    """
    if not is_dataclass(llm):
        raise TypeError(
            f"LLM {type(llm).__name__} 不是 dataclass，无法安全克隆 model"
        )

    kwargs: dict[str, object] = {}
    for f in fields(llm):
        if not f.init or f.name == "model":
            continue
        if f.name in _LLM_INTERNAL_RUNTIME_FIELDS:
            continue
        kwargs[f.name] = getattr(llm, f.name)

    return llm.__class__(model=model_name, **kwargs)


def _resolve_compaction_llm(
    runtime: "AgentRuntime",
    compaction_config: CompactionConfig,
) -> "BaseChatModel":
    """Resolve the LLM used for compaction.

    Priority:
    1) MID level model (default)
    2) Override model name via compaction.model
    3) Fallback to runtime.llm on clone failure
    """
    if runtime.llm is None:
        raise ValueError("runtime.llm 未初始化，无法解析压缩模型")

    compaction_llm = runtime.llm

    if runtime.options.llm_levels is not None and "MID" in runtime.options.llm_levels:
        compaction_llm = runtime.options.llm_levels["MID"]
        logger.info(f"压缩默认使用 MID 模型: {compaction_llm.model}")
    else:
        logger.warning("未找到 MID 档位模型，压缩回退到主 LLM")

    if compaction_config.model:
        try:
            compaction_llm = _clone_llm_with_model(compaction_llm, compaction_config.model)
            logger.info(f"压缩使用覆盖模型: {compaction_config.model}")
        except Exception as e:
            logger.warning(f"创建压缩覆盖模型失败，回退到主 LLM: {e}")
            compaction_llm = runtime.llm

    return compaction_llm


def init_runtime_from_template(runtime: "AgentRuntime") -> None:
    """运行态初始化：只初始化可变状态，不做模板发现。"""
    from comate_agent_sdk.agent.tool_visibility import hidden_tool_names, visible_tools
    from comate_agent_sdk.tools import ToolRegistry, get_default_registry

    # ====== 自动推断 tools 和 tool_registry ======
    builtin = get_default_registry()

    if runtime.options.tool_registry is None:
        local_registry = ToolRegistry()
        for t in builtin.all():
            if t.name not in local_registry:
                local_registry.register(t)
        runtime.options.tool_registry = local_registry
        logger.debug(f"Initialized runtime-local registry with {len(local_registry)} built-in tool(s)")

    if runtime.options.tools is None:
        runtime._tools_allowlist_mode = False
        runtime.options.tools = runtime.options.tool_registry.all()
        logger.debug(f"Using all {len(runtime.options.tools)} tool(s) from registry")
    else:
        runtime._tools_allowlist_mode = True

        resolved: list[Tool] = []
        pending_mcp: list[str] = []
        requested_names: list[str] = []

        for item in runtime.options.tools:
            if isinstance(item, Tool):
                if item.name not in runtime.options.tool_registry:  # type: ignore[operator]
                    try:
                        runtime.options.tool_registry.register(item)  # type: ignore[union-attr]
                    except Exception:
                        logger.debug(f"注册工具失败（忽略覆盖/重复）：{item.name}", exc_info=True)

        for item in runtime.options.tools:
            if isinstance(item, Tool):
                resolved.append(item)
                continue

            if isinstance(item, str):
                name = item
                requested_names.append(name)

                if name in runtime.options.tool_registry:  # type: ignore[operator]
                    resolved.append(runtime.options.tool_registry.get(name))  # type: ignore[union-attr]
                    continue

                if name.startswith("mcp__"):
                    pending_mcp.append(name)
                    continue

                raise ValueError(f"Unknown tool name: {name}")

            raise TypeError(f"tools 仅支持 Tool 或 str，收到：{type(item).__name__}")

        runtime._mcp_pending_tool_names = pending_mcp
        runtime._requested_tool_names = requested_names
        runtime.options.tools = resolved

    # ====== Tool 名冲突检查 ======
    if runtime.options.agents != []:
        user_task_tools = [
            t
            for t in runtime.options.tools
            if isinstance(t, Tool)
            and t.name == "Task"
            and getattr(t, "_comate_agent_sdk_internal", False) is not True
        ]
        if user_task_tools:
            raise ValueError(
                "检测到用户提供了同名工具 'Task'。"
                "'Task' 为 subagent 调度保留名（除非显式禁用 subagent：agents=[]/()）。"
                "解决方式：1) 将你的工具改名（不要叫 'Task'）；"
                "2) 显式禁用 subagent（例如 agents=[]/()）。"
            )

    if runtime._is_subagent and runtime.options.agents:
        raise ValueError("Subagent 不能再定义 agents（不支持嵌套）")

    if runtime._is_subagent:
        blocked_names = hidden_tool_names(runtime.options.tools, is_subagent=True)
        runtime.options.tools = visible_tools(runtime.options.tools, is_subagent=True)
        if blocked_names:
            logger.info(
                f"Subagent 隐藏受限工具: {blocked_names}"
            )

    for t in runtime.options.tools:
        assert isinstance(t, Tool), (
            f"Expected Tool instance, got {type(t).__name__}. Did you forget to use the @tool decorator?"
        )

    runtime._tool_map = {t.name: t for t in runtime.options.tools}

    runtime._session_id = runtime.options.session_id or str(uuid.uuid4())

    if runtime.llm is None:
        effective_level: LLMLevel = runtime.level or "MID"
        if runtime.options.llm_levels is None or effective_level not in runtime.options.llm_levels:
            raise ValueError(f"level='{effective_level}' 不在 llm_levels 中")
        runtime.llm = runtime.options.llm_levels[effective_level]

    runtime._subagent_source_prefix = None
    if runtime._is_subagent:
        prefix_parts: list[str] = ["subagent"]
        if runtime.name:
            prefix_parts.append(runtime.name)
        if runtime._subagent_run_id:
            prefix_parts.append(runtime._subagent_run_id)
        runtime._subagent_source_prefix = ":".join(prefix_parts)

    if runtime._parent_token_cost is not None:
        runtime._token_cost = runtime._parent_token_cost
    else:
        runtime._token_cost = TokenCost(include_cost=runtime.options.include_cost)

    if runtime.options.offload_enabled:
        if runtime.options.offload_root_path:
            root_path = Path(runtime.options.offload_root_path).expanduser()
        else:
            root_path = Path.home() / ".agent" / "sessions" / runtime._session_id / "offload"
        runtime._context_fs = ContextFileSystem(
            root_path=root_path,
            session_id=runtime._session_id,
        )
        logger.info(f"Context FileSystem enabled at {root_path}")

        if runtime.options.offload_policy is None:
            runtime.options.offload_policy = OffloadPolicy(
                enabled=True,
                token_threshold=runtime.options.offload_token_threshold,
            )

    runtime._context = ContextIR()
    if runtime.header_snapshot is not None:
        runtime._context.import_header_snapshot(runtime.header_snapshot)
        runtime._lock_header_from_snapshot = True

    compaction_config = (
        runtime.options.compaction if runtime.options.compaction is not None else CompactionConfig()
    )
    compaction_llm = _resolve_compaction_llm(runtime, compaction_config)
    compaction_usage_source = "compaction"
    if runtime._subagent_source_prefix:
        compaction_usage_source = f"{runtime._subagent_source_prefix}:compaction"
    runtime._compaction_service = CompactionService(
        config=compaction_config,
        llm=compaction_llm,
        token_cost=runtime._token_cost,
        usage_source=compaction_usage_source,
    )

    # ContextUsageTracker: context_window 用默认值初始化；
    # 第一次 invoke_llm 前会在 runner 中通过 get_model_context_limit 异步更新。
    runtime._context_usage_tracker = ContextUsageTracker(
        threshold_ratio=compaction_config.threshold_ratio,
    )

    # 同步模型上下文限制到 ContextIR budget（用于预算利用率计算）
    if runtime.llm is not None:
        try:
            import asyncio
            import concurrent.futures

            coro = runtime._compaction_service.get_model_context_limit(
                runtime.llm.model, llm=runtime.llm
            )
            try:
                asyncio.get_running_loop()
                # 已在事件循环内（如 subagent 在 TUI 中初始化），用独立线程+event loop 执行
                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    context_limit = pool.submit(asyncio.run, coro).result(timeout=10)
            except RuntimeError:
                # 无运行中的 loop，直接 asyncio.run
                context_limit = asyncio.run(coro)

            runtime._context.budget.total_limit = context_limit
            logger.debug(f"已设置 ContextIR budget total_limit: {context_limit}")
        except Exception as e:
            logger.warning(f"获取模型上下文限制失败，使用默认值: {e}")
            runtime._context.budget.total_limit = 128_000  # DEFAULT_CONTEXT_WINDOW

    if runtime.header_snapshot is None:
        runtime._setup_agent_loop()

    if runtime.options.agents:
        runtime._setup_subagents()

    runtime._setup_skills()
    if runtime.header_snapshot is None:
        runtime._setup_tool_strategy()

    if runtime.header_snapshot is None:
        resolved_prompt = runtime._resolve_system_prompt()
        if resolved_prompt:
            runtime._context.set_system_prompt(resolved_prompt, cache=True)

    is_plan_subagent = bool(runtime._is_subagent and runtime.name == "Plan")

    # user_instruction 始终运行时刷新（不依赖快照恢复），生命周期对齐 Compact/Resume
    if runtime.options.user_instruction and not is_plan_subagent:
        runtime._setup_user_instruction()

    if not runtime._is_subagent:
        runtime._setup_auto_memory()

    # 所有 agent 都注入 ENV，但 Plan subagent 跳过 git_env
    _setup_env_info(runtime, skip_git_env=is_plan_subagent)
    if not runtime._is_subagent:
        _setup_output_style(runtime)
    _prompts_dir = Path(__file__).parent / "prompts"

    _plan_prompt_md = _prompts_dir / "plan_prompt.md"
    if _plan_prompt_md.exists():
        _content = _plan_prompt_md.read_text(encoding="utf-8").strip()
        if _content:
            runtime.options.plan_mode_prompt_template = _content

    _plan_reminder_md = _prompts_dir / "plan_reminder.md"
    if _plan_reminder_md.exists():
        _content = _plan_reminder_md.read_text(encoding="utf-8").strip()
        runtime._context.set_plan_mode_reminder_template(_content)

    _plan_exit_md = _prompts_dir / "plan_exit_reminder.md"
    if _plan_exit_md.exists():
        _content = _plan_exit_md.read_text(encoding="utf-8").strip()
        if _content:
            runtime._context.set_plan_exit_reminder_template(_content)

    runtime.set_mode("act")
    _setup_mcp_session_state(runtime)

    from comate_agent_sdk.agent.hooks.engine import HookEngine
    from comate_agent_sdk.agent.hooks.loader import load_hook_config_from_sources

    hook_config = load_hook_config_from_sources(
        project_root=runtime.options.project_root,
        sources=runtime.options.setting_sources,
    )
    runtime._hook_engine = HookEngine(
        config=hook_config,
        project_root=runtime.options.project_root,
        session_id=runtime._session_id,
        permission_mode=runtime.options.permission_mode,
    )


# 兼容旧调用路径
agent_post_init = init_runtime_from_template
