from __future__ import annotations

import asyncio
import logging
import time
from typing import TYPE_CHECKING

from comate_agent_sdk.agent.compaction.models import ManualCompactionResult
from comate_agent_sdk.context import SelectiveCompactionPolicy
from comate_agent_sdk.context.observer import ContextEvent, EventType
from comate_agent_sdk.context.offload import OffloadPolicy
from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion

logger = logging.getLogger("comate_agent_sdk.agent")

if TYPE_CHECKING:
    from comate_agent_sdk.agent.core import AgentRuntime
    from comate_agent_sdk.agent.events import CompactionMetaEvent, PreCompactEvent


def _refresh_session_state_after_compact(agent: "AgentRuntime") -> None:
    """Compact 后刷新 session_state（含 user_instruction）和 memory。

    生命周期语义：Compact 是上下文重置点，session_state 和 memory 需要重新注入
    以确保 env/git 信息、user_instruction、MEMORY.md 内容都是最新的。
    """
    from comate_agent_sdk.agent.init import _setup_env_info, _setup_output_style
    from comate_agent_sdk.agent.setup import setup_auto_memory, setup_user_instruction

    is_subagent = bool(getattr(agent, "_is_subagent", False))
    is_plan_subagent = bool(is_subagent and getattr(agent, "name", None) == "Plan")
    options = getattr(agent, "options", None)
    if options is None:
        return

    try:
        # 刷新 env（system_env + git_env）
        env_options = getattr(options, "env_options", None)
        if env_options is not None:
            _setup_env_info(agent, skip_git_env=is_plan_subagent)

        # 刷新 output_style（仅主 agent）
        if not is_subagent:
            _setup_output_style(agent)

        # 刷新 user_instruction
        user_instruction = getattr(options, "user_instruction", None)
        if user_instruction and not is_plan_subagent:
            setup_user_instruction(agent)

        # 刷新 memory（仅主 agent，含文件 I/O）
        if not is_subagent:
            setup_auto_memory(agent)

    except Exception as exc:
        logger.warning(f"Compact 后刷新 session_state 失败，跳过: {exc}")

_SUMMARY_FAILURE_COOLDOWN_SECONDS = 8.0
_SUMMARY_FAILURE_STREAK_FOR_COOLDOWN = 2


def _build_compaction_policy(agent: "AgentRuntime", threshold: int) -> SelectiveCompactionPolicy:
    offload_policy = None
    if agent.options.offload_enabled and agent._context_fs:
        offload_policy = agent.options.offload_policy or OffloadPolicy(
            enabled=True,
            token_threshold=agent.options.offload_token_threshold,
        )

    compaction_llm = agent._compaction_service.llm or agent.llm
    is_subagent = bool(getattr(agent, "_is_subagent", False))
    agent_name = getattr(agent, "name", None)
    source_prefix = f"subagent:{agent_name}" if is_subagent and agent_name else None
    return SelectiveCompactionPolicy(
        threshold=threshold,
        llm=compaction_llm,
        fallback_to_full_summary=True,
        fs=agent._context_fs,
        offload_policy=offload_policy,
        token_cost=agent._token_cost,
        level=agent._effective_level,
        source_prefix=source_prefix,
    )


def _build_compaction_meta_events(
    agent: "AgentRuntime",
    policy: SelectiveCompactionPolicy,
) -> list["CompactionMetaEvent"]:
    if not bool(getattr(agent.options, "emit_compaction_meta_events", False)):
        return []
    if not policy.meta_records:
        return []

    from comate_agent_sdk.agent.events import CompactionMetaEvent

    return [
        CompactionMetaEvent(
            phase=record.phase,
            tokens_before=record.tokens_before,
            tokens_after=record.tokens_after,
            tool_blocks_kept=record.tool_blocks_kept,
            tool_blocks_dropped=record.tool_blocks_dropped,
            tool_calls_truncated=record.tool_calls_truncated,
            tool_results_truncated=record.tool_results_truncated,
            reason=record.reason,
        )
        for record in policy.meta_records
    ]


def log_compaction_meta_events(events: list["CompactionMetaEvent"]) -> None:
    for event in events:
        logger.debug(f"Compaction meta event: {event}")


def _extract_summary_failure_reason(policy: SelectiveCompactionPolicy) -> str | None:
    if not policy.meta_records:
        return None
    last = policy.meta_records[-1]
    if last.phase != "rollback":
        return None

    reason = (last.reason or "").strip()
    if not reason.startswith("summary_failed_or_empty"):
        return None
    if ":" in reason:
        return reason.split(":", 1)[1]
    return "summary_failed_or_empty"


def _record_compaction_outcome(agent: "AgentRuntime", policy: SelectiveCompactionPolicy) -> None:
    reason = _extract_summary_failure_reason(policy)
    if reason is None:
        setattr(agent, "_summary_compaction_failure_streak", 0)
        setattr(agent, "_summary_compaction_last_reason", "")
        return

    streak = int(getattr(agent, "_summary_compaction_failure_streak", 0)) + 1
    setattr(agent, "_summary_compaction_failure_streak", streak)
    setattr(agent, "_summary_compaction_last_reason", reason)

    if streak >= _SUMMARY_FAILURE_STREAK_FOR_COOLDOWN:
        until = time.monotonic() + _SUMMARY_FAILURE_COOLDOWN_SECONDS
        setattr(agent, "_summary_compaction_cooldown_until", until)
        logger.warning(
            "Compaction summary repeatedly failed; entering cooldown "
            f"for {_SUMMARY_FAILURE_COOLDOWN_SECONDS:.1f}s (reason={reason}, streak={streak})"
        )


def _is_summary_compaction_cooldown_active(agent: "AgentRuntime") -> bool:
    cooldown_until = float(getattr(agent, "_summary_compaction_cooldown_until", 0.0))
    return cooldown_until > 0 and time.monotonic() < cooldown_until


def _cooldown_remaining_seconds(agent: "AgentRuntime") -> float:
    cooldown_until = float(getattr(agent, "_summary_compaction_cooldown_until", 0.0))
    return max(0.0, cooldown_until - time.monotonic())


def _serialize_compaction_meta_records(policy: SelectiveCompactionPolicy) -> list[dict[str, object]]:
    records: list[dict[str, object]] = []
    for record in policy.meta_records:
        records.append(
            {
                "phase": record.phase,
                "tokens_before": record.tokens_before,
                "tokens_after": record.tokens_after,
                "tool_blocks_kept": record.tool_blocks_kept,
                "tool_blocks_dropped": record.tool_blocks_dropped,
                "tool_calls_truncated": record.tool_calls_truncated,
                "tool_results_truncated": record.tool_results_truncated,
                "reason": record.reason,
            }
        )
    return records


async def manual_compact_context(agent: "AgentRuntime") -> ManualCompactionResult:
    """Run compaction once regardless of threshold (manual trigger)."""
    service = agent._compaction_service
    if service is None or not service.config.enabled:
        return ManualCompactionResult(
            attempted=False,
            compacted=False,
            cancelled=False,
            tokens_before=agent._context.total_tokens,
            tokens_after=agent._context.total_tokens,
            reason="disabled",
        )

    if _is_summary_compaction_cooldown_active(agent):
        remaining = _cooldown_remaining_seconds(agent)
        reason = str(getattr(agent, "_summary_compaction_last_reason", "summary_failed_or_empty"))
        return ManualCompactionResult(
            attempted=False,
            compacted=False,
            cancelled=False,
            tokens_before=agent._context.total_tokens,
            tokens_after=agent._context.total_tokens,
            reason=f"cooldown:{reason}:remaining={remaining:.1f}s",
        )

    if not agent._context.conversation.items:
        return ManualCompactionResult(
            attempted=False,
            compacted=False,
            cancelled=False,
            tokens_before=agent._context.total_tokens,
            tokens_after=agent._context.total_tokens,
            reason="empty_conversation",
        )

    threshold = await _get_threshold(agent)
    policy = _build_compaction_policy(agent, threshold=max(1, threshold))
    before_tokens = agent._context.total_tokens

    try:
        compacted = await policy.compact(agent._context)
    except asyncio.CancelledError:
        _record_compaction_outcome(agent, policy)
        after_tokens = agent._context.total_tokens
        return ManualCompactionResult(
            attempted=True,
            compacted=False,
            cancelled=True,
            tokens_before=before_tokens,
            tokens_after=after_tokens,
            reason="cancelled",
            meta_records=_serialize_compaction_meta_records(policy),
        )

    _record_compaction_outcome(agent, policy)
    after_tokens = agent._context.total_tokens

    if compacted:
        tracker = getattr(agent, "_context_usage_tracker", None)
        if tracker is not None:
            tracker.reset_after_compaction()
        agent._context.event_bus.emit(
            ContextEvent(
                event_type=EventType.COMPACTION_PERFORMED,
                detail=f"manual_compact: {before_tokens} → {after_tokens} tokens",
            )
        )
        _refresh_session_state_after_compact(agent)
        reason_text = "success"
    else:
        reason_text = "failed"
        if policy.meta_records:
            reason_text = str(policy.meta_records[-1].reason or "failed")

    return ManualCompactionResult(
        attempted=True,
        compacted=compacted,
        cancelled=False,
        tokens_before=before_tokens,
        tokens_after=after_tokens,
        reason=reason_text,
        meta_records=_serialize_compaction_meta_records(policy),
    )


async def generate_max_iterations_summary(agent: "AgentRuntime") -> str:
    summary_prompt = """The task has reached the maximum number of steps allowed.
Please provide a concise summary of:
1. What was accomplished so far
2. What actions were taken
3. What remains incomplete (if anything)
4. Any partial results or findings

Keep the summary brief but informative."""

    temp_item = agent._context.add_message(UserMessage(content=summary_prompt, is_meta=True))

    try:
        response = await agent.llm.ainvoke(
            messages=agent._context.lower(),
            tools=None,
            tool_choice=None,
        )
        summary = response.content or "Unable to generate summary."
    except Exception as exc:
        logger.warning(f"Failed to generate max iterations summary: {exc}")
        summary = (
            f"Task stopped after {agent.options.max_iterations} iterations. "
            "Unable to generate summary due to error."
        )
    finally:
        agent._context.conversation.remove_by_id(temp_item.id)

    return f"[Max iterations reached]\n\n{summary}"


async def _get_threshold(agent: "AgentRuntime") -> int:
    try:
        return await agent._compaction_service.get_threshold_for_model(
            agent.llm.model,
            llm=agent.llm,
        )
    except TypeError:
        return await agent._compaction_service.get_threshold_for_model(agent.llm.model)


async def check_and_compact(
    agent: "AgentRuntime",
    response: ChatInvokeCompletion,
) -> tuple[bool, "PreCompactEvent | None", list["CompactionMetaEvent"]]:
    del response
    if agent._compaction_service is None:
        return False, None, []

    tracker = getattr(agent, "_context_usage_tracker", None)
    if tracker is None or not tracker.should_compact_post_response():
        return False, None, []

    from comate_agent_sdk.agent.events import PreCompactEvent

    threshold = await _get_threshold(agent)
    actual_tokens = tracker.context_usage
    event = PreCompactEvent(current_tokens=actual_tokens, threshold=threshold, trigger="check")

    if _is_summary_compaction_cooldown_active(agent):
        remaining = _cooldown_remaining_seconds(agent)
        reason = str(getattr(agent, "_summary_compaction_last_reason", "summary_failed_or_empty"))
        logger.warning(f"压缩冷却中，跳过本轮压缩: remaining={remaining:.1f}s, reason={reason}")
        return False, event, []

    policy = _build_compaction_policy(agent, threshold)
    compacted = await agent._context.auto_compact(policy=policy, current_total_tokens=actual_tokens)
    _record_compaction_outcome(agent, policy)
    if compacted:
        tracker.reset_after_compaction()
        _refresh_session_state_after_compact(agent)

    return compacted, event, _build_compaction_meta_events(agent, policy)


async def precheck_and_compact(
    agent: "AgentRuntime",
) -> tuple[bool, "PreCompactEvent | None", list["CompactionMetaEvent"]]:
    if agent._compaction_service is None or not agent._compaction_service.config.enabled:
        return False, None, []

    tracker = getattr(agent, "_context_usage_tracker", None)
    if tracker is None:
        return False, None, []

    ir_total = agent._context.total_tokens
    if not tracker.should_compact_precheck(ir_total):
        return False, None, []

    from comate_agent_sdk.agent.events import PreCompactEvent

    estimated_tokens = tracker.estimate_precheck(ir_total)
    threshold = await _get_threshold(agent)
    logger.info(f"预检查触发压缩: 估算 {estimated_tokens} tokens >= 阈值 {threshold}")
    event = PreCompactEvent(current_tokens=estimated_tokens, threshold=threshold, trigger="precheck")

    if _is_summary_compaction_cooldown_active(agent):
        remaining = _cooldown_remaining_seconds(agent)
        reason = str(getattr(agent, "_summary_compaction_last_reason", "summary_failed_or_empty"))
        logger.warning(f"压缩冷却中，跳过本轮压缩: remaining={remaining:.1f}s, reason={reason}")
        return False, event, []

    policy = _build_compaction_policy(agent, threshold)
    compacted = await agent._context.auto_compact(policy=policy, current_total_tokens=estimated_tokens)
    _record_compaction_outcome(agent, policy)
    if compacted:
        tracker.reset_after_compaction()
        _refresh_session_state_after_compact(agent)

    return compacted, event, _build_compaction_meta_events(agent, policy)
