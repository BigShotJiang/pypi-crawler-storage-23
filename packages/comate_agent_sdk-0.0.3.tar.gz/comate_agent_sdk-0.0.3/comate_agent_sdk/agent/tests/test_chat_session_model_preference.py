import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from comate_agent_sdk import Agent
from comate_agent_sdk.agent import AgentConfig
from comate_agent_sdk.agent.chat_session import ChatSession


class _FakeChatModel:
    def __init__(self) -> None:
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("This test should not call the LLM")


class TestChatSessionModelPreference(unittest.TestCase):
    @patch("comate_agent_sdk.agent.chat_session.persist_user_model_preference")
    def test_set_level_persists_user_model_preference_when_user_source_enabled(self, mock_persist) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    mcp_enabled=False,
                    setting_sources=("user",),
                ),
            )
            session = ChatSession(
                agent,
                session_id="s1",
                storage_root=root / "session",
            )

            event = session.set_level("LOW")

            self.assertEqual(event.new_level, "LOW")
            mock_persist.assert_called_once_with("LOW")

    @patch("comate_agent_sdk.agent.chat_session.persist_user_model_preference")
    def test_set_level_skips_persist_when_user_source_disabled(self, mock_persist) -> None:
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    mcp_enabled=False,
                    setting_sources=("project",),
                ),
            )
            session = ChatSession(
                agent,
                session_id="s1",
                storage_root=root / "session",
            )

            session.set_level("HIGH")

            mock_persist.assert_not_called()

    @patch("comate_agent_sdk.agent.chat_session.persist_user_model_preference")
    def test_set_level_persist_failure_does_not_break_switch(self, mock_persist) -> None:
        mock_persist.side_effect = OSError("disk is read-only")
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            agent = Agent(
                llm=_FakeChatModel(),  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(),
                    agents=(),
                    offload_enabled=False,
                    mcp_enabled=False,
                    setting_sources=("user",),
                ),
            )
            session = ChatSession(
                agent,
                session_id="s1",
                storage_root=root / "session",
            )

            event = session.set_level("MID")

            self.assertEqual(event.new_level, "MID")
            self.assertEqual(session._agent.level, "MID")
            mock_persist.assert_called_once_with("MID")


if __name__ == "__main__":
    unittest.main()
