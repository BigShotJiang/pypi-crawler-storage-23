from __future__ import annotations

import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.context.env import EnvOptions
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.context.memory import UserInstructionConfig


class _NoInvokeFakeChatModel:
    model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("ainvoke should not be called in this test")


class TestSubagentContextInjection(unittest.TestCase):
    def _create_template(self, user_instruction_file: Path) -> Agent:
        return Agent(
            llm=_NoInvokeFakeChatModel(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                skills=(),
                offload_enabled=False,
                setting_sources=(),
                env_options=EnvOptions(system_env=True, git_env=True, working_dir=Path.cwd()),
                user_instruction=UserInstructionConfig(files=[user_instruction_file]),
            ),
        )

    def test_subagent_does_not_inject_output_style(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            memory_file = Path(tmpdir) / "memory.md"
            memory_file.write_text("memory", encoding="utf-8")
            template = self._create_template(memory_file)

            runtime = template.create_runtime(is_subagent=True, name="Worker")

            self.assertIsNone(
                runtime._context.session_state.find_one_by_type(ItemType.OUTPUT_STYLE)
            )

    def test_main_agent_keeps_output_style(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            memory_file = Path(tmpdir) / "memory.md"
            memory_file.write_text("memory", encoding="utf-8")
            template = self._create_template(memory_file)

            runtime = template.create_runtime()

            self.assertIsNotNone(
                runtime._context.session_state.find_one_by_type(ItemType.OUTPUT_STYLE)
            )

    def test_plan_subagent_skips_user_instruction_but_keeps_env(self) -> None:
        """Plan subagent 应跳过 user_instruction 和 GIT_ENV，但保留 SYSTEM_ENV（含 agent_home + agent_plans_dir）。"""
        with tempfile.TemporaryDirectory() as tmpdir:
            memory_file = Path(tmpdir) / "memory.md"
            memory_file.write_text("memory", encoding="utf-8")
            template = self._create_template(memory_file)

            runtime = template.create_runtime(is_subagent=True, name="Plan")

            # Plan subagent 应该有 SYSTEM_ENV
            system_env_item = runtime._context.session_state.find_one_by_type(ItemType.SYSTEM_ENV)
            self.assertIsNotNone(system_env_item)
            # Plan subagent 的 system_env 至少包含工作目录信息
            self.assertIn("task_working_directory", system_env_item.content_text)
            # Plan subagent 的 system_env 包含 agent_plans_dir（Plan 专属）
            self.assertIn("agent_plans_dir", system_env_item.content_text)
            # Plan subagent 不应该有 GIT_ENV
            self.assertIsNone(
                runtime._context.session_state.find_one_by_type(ItemType.GIT_ENV)
            )
            # Plan subagent 不应该有 user_instruction
            self.assertIsNone(runtime._context.user_instruction_item)
            # Subagent 不注入 auto memory
            self.assertIsNone(runtime._context.memory)

    def test_non_plan_subagent_keeps_system_env_and_user_instruction(self) -> None:
        with tempfile.TemporaryDirectory() as tmpdir:
            memory_file = Path(tmpdir) / "memory.md"
            memory_file.write_text("memory", encoding="utf-8")
            template = self._create_template(memory_file)

            runtime = template.create_runtime(is_subagent=True, name="Explorer")

            system_env_item = runtime._context.session_state.find_one_by_type(ItemType.SYSTEM_ENV)
            self.assertIsNotNone(system_env_item)
            # 普通 subagent 的 system_env 至少包含工作目录信息
            self.assertIn("task_working_directory", system_env_item.content_text)
            # 普通 subagent 的 system_env 不应该包含 agent_plans_dir（Plan 专属）
            self.assertNotIn("agent_plans_dir", system_env_item.content_text)
            self.assertIsNotNone(runtime._context.user_instruction_item)
            self.assertIsNone(runtime._context.memory)
            self.assertIsNone(
                runtime._context.session_state.find_one_by_type(ItemType.OUTPUT_STYLE)
            )
