import unittest
from unittest.mock import patch

from comate_agent_sdk import Agent
from comate_agent_sdk.agent import AgentConfig
from comate_agent_sdk.llm.anthropic.chat import ChatAnthropic


class _FakeChatModel:
    def __init__(self, model: str) -> None:
        self.model = model

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("This test should not call the LLM")


def _build_fake_levels() -> dict[str, _FakeChatModel]:
    return {
        "LOW": _FakeChatModel(model="model-low"),
        "MID": _FakeChatModel(model="model-mid"),
        "HIGH": _FakeChatModel(model="model-high"),
    }


class TestModelPreferenceIntegration(unittest.TestCase):
    @patch("comate_agent_sdk.agent.settings.load_user_model_preference")
    def test_template_uses_user_model_preference_when_level_not_explicit(self, mock_pref) -> None:
        mock_pref.return_value = "LOW"
        llm_levels = _build_fake_levels()
        agent = Agent(
            config=AgentConfig(
                tools=(),
                agents=(),
                mcp_enabled=False,
                offload_enabled=False,
                setting_sources=("user",),
                llm_levels=llm_levels,  # type: ignore[arg-type]
            )
        )
        self.assertEqual(agent.resolved_level, "LOW")
        self.assertIs(agent.resolved_llm, llm_levels["LOW"])
        mock_pref.assert_called_once()

    @patch("comate_agent_sdk.agent.settings.load_user_model_preference")
    def test_template_explicit_level_overrides_user_model_preference(self, mock_pref) -> None:
        mock_pref.return_value = "LOW"
        llm_levels = _build_fake_levels()
        agent = Agent(
            level="HIGH",
            config=AgentConfig(
                tools=(),
                agents=(),
                mcp_enabled=False,
                offload_enabled=False,
                setting_sources=("user",),
                llm_levels=llm_levels,  # type: ignore[arg-type]
            ),
        )
        self.assertEqual(agent.resolved_level, "HIGH")
        self.assertIs(agent.resolved_llm, llm_levels["HIGH"])
        mock_pref.assert_not_called()

    @patch("comate_agent_sdk.agent.settings.load_user_model_preference")
    def test_template_ignores_model_preference_without_user_source(self, mock_pref) -> None:
        mock_pref.return_value = "LOW"
        llm_levels = _build_fake_levels()
        agent = Agent(
            config=AgentConfig(
                tools=(),
                agents=(),
                mcp_enabled=False,
                offload_enabled=False,
                setting_sources=("project",),
                llm_levels=llm_levels,  # type: ignore[arg-type]
            )
        )
        self.assertEqual(agent.resolved_level, "MID")
        self.assertIs(agent.resolved_llm, llm_levels["MID"])
        mock_pref.assert_not_called()

    @patch("comate_agent_sdk.agent.settings.load_user_model_preference")
    def test_template_with_explicit_llm_skips_model_preference(self, mock_pref) -> None:
        mock_pref.return_value = "LOW"
        explicit_llm = ChatAnthropic(model="custom-model")
        agent = Agent(
            llm=explicit_llm,
            config=AgentConfig(
                tools=(),
                agents=(),
                mcp_enabled=False,
                offload_enabled=False,
                setting_sources=("user",),
            ),
        )
        self.assertIs(agent.resolved_llm, explicit_llm)
        self.assertIsNone(agent.resolved_level)
        mock_pref.assert_not_called()


if __name__ == "__main__":
    unittest.main()
