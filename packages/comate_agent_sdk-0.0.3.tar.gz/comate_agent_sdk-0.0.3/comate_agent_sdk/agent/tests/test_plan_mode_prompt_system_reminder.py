import unittest
from pathlib import Path
from unittest.mock import patch

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import HiddenUserMessageEvent
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import UserMessage
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _CaptureChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]):
        self._completions = completions
        self._idx = 0
        self.model = "fake:model"
        self.last_messages = None

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del tools, tool_choice, kwargs
        self.last_messages = list(messages)
        if self._idx >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._idx + 1}")
        result = self._completions[self._idx]
        self._idx += 1
        return result


class TestPlanModePromptSystemReminder(unittest.IsolatedAsyncioTestCase):
    async def test_plan_prompt_injected_as_system_reminder_item(self) -> None:
        llm = _CaptureChatModel([ChatInvokeCompletion(content="done")])
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
            ),
        )
        runtime = template.create_runtime()
        runtime.options.plan_mode_prompt_template = "PLAN_PROMPT_TEST"
        runtime.set_mode("plan")

        events = []
        async for event in runtime.query_stream("hello"):
            events.append(event)

        self.assertIsNotNone(llm.last_messages)
        assert llm.last_messages is not None
        self.assertTrue(
            any(
                isinstance(msg, UserMessage)
                and bool(getattr(msg, "is_meta", False))
                and "PLAN_PROMPT_TEST" in msg.text
                for msg in llm.last_messages
            )
        )

        reminder_items = [
            item
            for item in runtime._context.conversation.items
            if item.item_type == ItemType.SYSTEM_REMINDER
        ]
        self.assertGreaterEqual(len(reminder_items), 1)
        plan_prompt_items = [
            item
            for item in reminder_items
            if item.metadata.get("reminder_rule_ids") == ["plan_mode_prompt"]
        ]
        self.assertEqual(len(plan_prompt_items), 1)
        self.assertIn("PLAN_PROMPT_TEST", plan_prompt_items[0].content_text)
        self.assertEqual(plan_prompt_items[0].metadata.get("origin"), "system_reminder")

        legacy_user_items = [
            item
            for item in runtime._context.conversation.items
            if item.item_type == ItemType.USER_MESSAGE
            and isinstance(item.message, UserMessage)
            and bool(getattr(item.message, "is_meta", False))
            and "PLAN_PROMPT_TEST" in item.content_text
        ]
        self.assertEqual(legacy_user_items, [])

        hidden_events = [event for event in events if isinstance(event, HiddenUserMessageEvent)]
        self.assertTrue(any("PLAN_PROMPT_TEST" in event.content for event in hidden_events))

    async def test_plan_prompt_renders_active_plan_file_path_placeholder(self) -> None:
        llm = _CaptureChatModel([ChatInvokeCompletion(content="done")])
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
            ),
        )
        runtime = template.create_runtime()
        runtime.options.plan_mode_prompt_template = "Plan file: {{PLAN_FILE_PATH}}"
        expected_path = Path("/tmp/test-plan.md")
        with patch(
            "comate_agent_sdk.agent.core.runtime.build_plan_artifact_path",
            return_value=expected_path,
        ):
            runtime.set_mode("plan")

        async for _event in runtime.query_stream("hello"):
            pass

        self.assertIsNotNone(llm.last_messages)
        assert llm.last_messages is not None
        self.assertTrue(
            any(
                isinstance(msg, UserMessage)
                and bool(getattr(msg, "is_meta", False))
                and f"Plan file: {expected_path}" in msg.text
                for msg in llm.last_messages
            )
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
