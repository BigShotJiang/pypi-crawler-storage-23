from __future__ import annotations

import asyncio
import time
import unittest
from types import SimpleNamespace

from comate_agent_sdk.agent.compaction import CompactionService
from comate_agent_sdk.agent.runner_engine.compaction import manual_compact_context
from comate_agent_sdk.context.ir import ContextIR
from comate_agent_sdk.context.items import ItemType
from comate_agent_sdk.llm.messages import UserMessage


class _FakeSummaryLLM:
    model = "fake-summary-model"

    async def ainvoke(self, *, messages, tools=None, tool_choice=None):
        del messages, tools, tool_choice
        return SimpleNamespace(
            content="<summary>manual compact summary</summary>",
            usage=None,
            stop_reason="end_turn",
            thinking=None,
        )


class _Tracker:
    def __init__(self) -> None:
        self.reset_calls = 0

    def reset_after_compaction(self) -> None:
        self.reset_calls += 1


class TestManualCompaction(unittest.TestCase):
    def _build_agent(self) -> SimpleNamespace:
        context = ContextIR()
        context.add_message(UserMessage(content="hello", is_meta=False))
        llm = _FakeSummaryLLM()
        tracker = _Tracker()
        service = CompactionService(llm=llm)
        return SimpleNamespace(
            _context=context,
            _compaction_service=service,
            llm=llm,
            _context_usage_tracker=tracker,
            options=SimpleNamespace(
                offload_enabled=False,
                offload_policy=None,
                offload_token_threshold=0,
                emit_compaction_meta_events=False,
            ),
            _context_fs=None,
            _token_cost=None,
            _effective_level="MID",
            _is_subagent=False,
            name=None,
        )

    def test_manual_compaction_success(self) -> None:
        agent = self._build_agent()

        result = asyncio.run(manual_compact_context(agent))

        self.assertTrue(result.attempted)
        self.assertTrue(result.compacted)
        self.assertFalse(result.cancelled)
        self.assertGreater(result.tokens_before, 0)
        self.assertGreater(result.tokens_after, 0)
        self.assertEqual(agent._context_usage_tracker.reset_calls, 1)
        self.assertEqual(len(agent._context.conversation.items), 1)
        self.assertEqual(agent._context.conversation.items[0].item_type, ItemType.COMPACTION_SUMMARY)

    def test_manual_compaction_respects_cooldown(self) -> None:
        agent = self._build_agent()
        agent._summary_compaction_cooldown_until = time.monotonic() + 5.0
        agent._summary_compaction_last_reason = "summary_failed_or_empty"

        result = asyncio.run(manual_compact_context(agent))

        self.assertFalse(result.attempted)
        self.assertFalse(result.compacted)
        self.assertIn("cooldown:", result.reason)
        self.assertEqual(agent._context_usage_tracker.reset_calls, 0)


if __name__ == "__main__":
    unittest.main()
