from __future__ import annotations

import unittest
from pathlib import Path
from unittest.mock import patch

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.llm.views import ChatInvokeCompletion


class _FakeChatModel:
    model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        return ChatInvokeCompletion(content="ok")


class TestRuntimePlanArtifactPath(unittest.TestCase):
    def test_set_mode_allocates_new_active_plan_path_per_act_to_plan_transition(self) -> None:
        llm = _FakeChatModel()
        template = Agent(
            llm=llm,  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
            ),
        )
        runtime = template.create_runtime()
        first_path = Path("/tmp/plan-first.md")
        second_path = Path("/tmp/plan-second.md")
        with patch(
            "comate_agent_sdk.agent.core.runtime.build_plan_artifact_path",
            side_effect=[first_path, second_path],
        ):
            runtime.set_mode("plan")
            self.assertEqual(runtime.get_active_plan_path(), str(first_path))

            runtime.set_mode("plan")
            self.assertEqual(runtime.get_active_plan_path(), str(first_path))

            runtime.set_mode("act")
            self.assertIsNone(runtime.get_active_plan_path())

            runtime.set_mode("plan")
            self.assertEqual(runtime.get_active_plan_path(), str(second_path))


if __name__ == "__main__":
    unittest.main(verbosity=2)
