import json
import tempfile
import unittest
from pathlib import Path

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.events import PlanApprovalRequiredEvent, StopEvent
from comate_agent_sdk.llm.messages import Function, ToolCall
from comate_agent_sdk.llm.views import ChatInvokeCompletion
from comate_agent_sdk.system_tools.tool_result import ok
from comate_agent_sdk.tools import tool


class _FakeChatModel:
    def __init__(self, completions: list[ChatInvokeCompletion]):
        self._completions = completions
        self._idx = 0
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        del messages, tools, tool_choice, kwargs
        if self._idx >= len(self._completions):
            raise AssertionError(f"Unexpected ainvoke call #{self._idx + 1}")
        completion = self._completions[self._idx]
        self._idx += 1
        return completion


class TestRunnerStreamExitPlanMode(unittest.IsolatedAsyncioTestCase):
    async def test_plan_approval_event_contains_plan_markdown(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            plan_path = Path(td) / "plan.md"
            plan_markdown = "# Plan\n\n- step 1\n- step 2\n"
            plan_path.write_text(plan_markdown, encoding="utf-8")

            @tool("Fake ExitPlanMode", name="ExitPlanMode")
            async def FakeExitPlanMode(summary: str, execution_prompt: str) -> dict:
                del summary, execution_prompt
                return ok(
                    data={
                        "status": "waiting_for_plan_approval",
                        "plan_path": str(plan_path),
                        "summary": "ready",
                        "execution_prompt": "execute now",
                    },
                    message="Plan is ready",
                    meta={"status": "waiting_for_plan_approval", "plan_path": str(plan_path)},
                )

            tool_call = ToolCall(
                id="tc_exit_plan_1",
                function=Function(
                    name="ExitPlanMode",
                    arguments=json.dumps(
                        {"summary": "ready", "execution_prompt": "execute now"},
                        ensure_ascii=False,
                    ),
                ),
            )

            llm = _FakeChatModel([ChatInvokeCompletion(tool_calls=[tool_call])])
            template = Agent(
                llm=llm,  # type: ignore[arg-type]
                config=AgentConfig(
                    tools=(FakeExitPlanMode,),
                    agents=(),
                    offload_enabled=False,
                ),
            )
            agent = template.create_runtime()

            events = []
            async for event in agent.query_stream("finalize plan"):
                events.append(event)

            approval_events = [e for e in events if isinstance(e, PlanApprovalRequiredEvent)]
            self.assertEqual(len(approval_events), 1)
            approval = approval_events[0]
            self.assertEqual(approval.plan_path, str(plan_path))
            self.assertEqual(approval.summary, "ready")
            self.assertEqual(approval.execution_prompt, "execute now")
            self.assertEqual(approval.plan_markdown, plan_markdown)

            stop_events = [e for e in events if isinstance(e, StopEvent)]
            self.assertEqual(len(stop_events), 1)
            self.assertEqual(stop_events[0].reason, "waiting_for_plan_approval")


if __name__ == "__main__":
    unittest.main(verbosity=2)
