from __future__ import annotations

import tempfile
import unittest
from pathlib import Path
from unittest.mock import AsyncMock

from comate_agent_sdk.agent import Agent, AgentConfig
from comate_agent_sdk.agent.chat_session import ChatSession


class _FakeChatModel:
    def __init__(self) -> None:
        self.model = "fake:model"

    @property
    def provider(self) -> str:
        return "fake"

    @property
    def name(self) -> str:
        return self.model

    async def ainvoke(self, messages, tools=None, tool_choice=None, **kwargs):  # type: ignore[no-untyped-def]
        raise AssertionError("This test should not call the LLM")


class _FakeMcpManager:
    def __init__(self) -> None:
        self.close_calls = 0

    async def aclose(self) -> None:
        self.close_calls += 1


class TestRuntimeShutdown(unittest.IsolatedAsyncioTestCase):
    def _build_runtime(self):
        template = Agent(
            llm=_FakeChatModel(),  # type: ignore[arg-type]
            config=AgentConfig(
                tools=(),
                agents=(),
                offload_enabled=False,
                setting_sources=None,
            ),
        )
        return template, template.create_runtime(session_id="runtime-shutdown-test")

    async def test_runtime_aclose_is_idempotent(self) -> None:
        _, runtime = self._build_runtime()
        manager = _FakeMcpManager()
        runtime._mcp_manager = manager
        runtime._mcp_loaded = True
        runtime._mcp_dirty = True
        runtime._mcp_pending_tool_names = ["mcp__demo__tool"]

        await runtime.aclose()
        await runtime.aclose()

        self.assertEqual(manager.close_calls, 1)
        self.assertIsNone(runtime._mcp_manager)
        self.assertFalse(runtime._mcp_loaded)
        self.assertFalse(runtime._mcp_dirty)
        self.assertEqual(runtime._mcp_pending_tool_names, [])

    async def test_chat_session_shutdown_closes_runtime_once(self) -> None:
        template, runtime = self._build_runtime()
        runtime.aclose = AsyncMock()  # type: ignore[method-assign]

        with tempfile.TemporaryDirectory() as tmp:
            session = ChatSession(
                template,
                runtime=runtime,
                session_id=runtime.options.session_id,
                storage_root=Path(tmp) / "s1",
            )
            await session.shutdown()
            await session.shutdown()

        self.assertTrue(session._closed)
        self.assertTrue(session._shutdown_completed)
        runtime.aclose.assert_awaited_once()


if __name__ == "__main__":
    unittest.main(verbosity=2)
