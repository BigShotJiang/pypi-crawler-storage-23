from __future__ import annotations

import pytest

from comate_agent_sdk.agent import AgentConfig
from comate_agent_sdk.context.ir import ContextIR


def test_agent_config_rejects_legacy_memory_field() -> None:
    with pytest.raises(TypeError):
        AgentConfig(memory="legacy")  # type: ignore[call-arg]


def test_context_ir_legacy_set_memory_api_removed() -> None:
    ctx = ContextIR()
    assert not hasattr(ctx, "set_memory")
