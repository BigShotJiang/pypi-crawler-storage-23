"""
Example scripts demonstrating comate_agent_sdk features.

Run examples from the project root:
    python -m comate_agent_sdk.examples.simple_calculator
    python -m comate_agent_sdk.examples.dependency_injection
    python -m comate_agent_sdk.examples.pydantic_models
    python -m comate_agent_sdk.examples.chat_conversation
"""
