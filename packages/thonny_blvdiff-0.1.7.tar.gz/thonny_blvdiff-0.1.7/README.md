<h1><u>blvdiff - Thonny</u></h1>

<h2>About:</h2>

- An on-going individual study project at the <i> University of Mary Washington </i>
- Parts of the Rust structure based from blvrun: https://arxiv.org/pdf/2401.16654
- Designed to <b>improve</b> debugging directly on the command line for blind and low-vision (blv) developers.
- The associated paper for this project can be found here: https://dl.acm.org/doi/10.1145/3663547.3759716

<h2>Features:</h2>

- Rust based shell script.
- Automatic script versioning.

- <b>Three Flags</b>

  - <code>--explain</code> flag: feeds error tracebacks into an LLM powered by <a href="https://www.llama.com/">Meta Llama</a>. Outputs an error explanation in a <i>screen-readable</i> format.
  - <code>--diff</code> flag: Utilizes previously saved script versions to generate a <i>screen-readable</i> display of changes made. Similiar functionality to that of vim-diff, but with automatic versioning.
  - <code>--revert</code> flag: Revert current script version back to most recently saved version. Similiar to that of git's revert feature.
 

<h2>Install:</h2>

Note: This version is for Thonny only.

For command-line support: <a href="https://github.com/rylansedlacek/blvflag"> blvdiff </a>

<h3>Steps:</h3>

1) Open Thonny.

2) In the Tool menu select, Manage Plugins.

3) Search for, "thonny-blvdiff" and install.

4) Reload Thonny, open the tools menu.

You are now ready to use the tools functions described above.

First run, <code>BLVDIFF: Setup</code>

Then, write a Python script and run it with.
  
- <code>BLVDIFF: Run Script</code>
- <code>BLVDIFF: --explain </code>
- <code>BLVDIFF: --diff </code>
- <code>BLVDIFF: --revert </code>


