# Explanation

Background theory and design decisions behind Litterman.

*Explanations will be added as features are implemented.*
