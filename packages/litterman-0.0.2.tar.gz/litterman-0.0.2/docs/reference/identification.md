# Identification Schemes

::: litterman.identification
