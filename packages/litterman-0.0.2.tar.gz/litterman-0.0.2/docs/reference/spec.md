# VAR Specification

::: litterman.spec
