# FittedVAR

::: litterman.fitted
