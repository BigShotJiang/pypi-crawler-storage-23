# Tutorials

These tutorials walk you through Litterman's core workflow: fitting a Bayesian VAR, producing probabilistic forecasts, and running structural analysis. They assume familiarity with regression and autoregressive models but explain VAR-specific concepts as they arise.

All three tutorials use the same simulated macroeconomic dataset — quarterly GDP growth, inflation, and an interest rate — so results are consistent across the series.

| Tutorial | What you'll learn |
|----------|-------------------|
| [Quickstart: Fitting Your First Bayesian VAR](quickstart.ipynb) | Data validation, lag selection, Minnesota prior, posterior inspection |
| [Probabilistic Forecasts](forecasting.ipynb) | Multi-step-ahead forecasts, credible intervals, fan charts |
| [Structural Shocks and Their Effects](structural-analysis.ipynb) | Cholesky identification, impulse responses, FEVD, historical decomposition |

Start with the **Quickstart** if you're new to Litterman. The Forecasting and Structural Analysis tutorials build on concepts introduced there.
