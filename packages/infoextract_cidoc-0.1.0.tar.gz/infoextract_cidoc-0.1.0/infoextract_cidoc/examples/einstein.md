# Albert Einstein

## Early Life, Family, and Education

Albert Einstein was born on March 14, 1879, in Ulm, Württemberg, Germany. He grew up in a secular Jewish family. His father, Hermann Einstein, was a salesman and engineer who, with his brother, founded Elektrotechnische Fabrik J. Einstein & Cie, a Munich-based company that mass-produced electrical equipment. Einstein's mother, the former Pauline Koch, ran the family household. Einstein had one sister, Maja, born two years after him.

Einstein attended elementary school at the Luitpold Gymnasium in Munich. However, he felt alienated there and struggled with the institution's rigid pedagogical style. He also had what were considered speech challenges. However, he developed a passion for classical music and playing the violin, which would stay with him into his later years. Most significantly, Einstein's youth was marked by deep inquisitiveness and inquiry.

Toward the end of the 1880s, Max Talmud, a Polish medical student who sometimes dined with the Einstein family, became an informal tutor to young Einstein. Talmud had introduced his pupil to a children's science text that inspired Einstein to dream about the nature of light. Thus, during his teens, Einstein penned what would be seen as his first major paper, "The Investigation of the State of Aether in Magnetic Fields."

Hermann relocated the family to Milan, Italy, in the mid-1890s after his business lost out on a major contract. Einstein was left at a relative's boarding house in Munich to complete his schooling at the Luitpold.

Faced with military duty when he turned of age, Einstein allegedly withdrew from classes, using a doctor's note to excuse himself and claim nervous exhaustion. With their son rejoining them in Italy, his parents understood Einstein's perspective but were concerned about his future prospects as a school dropout and draft dodger.

Einstein was eventually able to gain admission into the Swiss Federal Institute of Technology in Zurich, specifically due to his superb mathematics and physics scores on the entrance exam. He was still required to complete his pre-university education first and thus attended a high school in Aarau, Switzerland, helmed by Jost Winteler. Einstein lived with the schoolmaster's family and fell in love with Winteler's daughter Marie. Einstein later renounced his German citizenship and became a Swiss citizen at the dawn of the new century.

## Einstein's IQ

Einstein's intelligence quotient was estimated to be around 160, but there are no indications he was ever actually tested.

Psychologist David Wechsler didn't release the first edition of the WAIS cognitive test, which evolved into the WAIS-IV test commonly used today, until 1955—shortly before Einstein's death. The maximum score of the current version is 160, with an IQ of 135 or higher ranking in the 99th percentile.

Magazine columnist Marilyn vos Savant has the highest-ever recorded IQ at 228 and was featured in the Guinness Book of World Records in the late 1980s. However, Guinness discontinued the category because of debates about testing accuracy. According to Parade, individuals believed to have higher IQs than Einstein include Leonardo Da Vinci, Marie Curie, Nikola Tesla, and Nicolaus Copernicus.

## Patent Clerk

After graduating from university, Einstein faced major challenges in terms of finding academic positions, having alienated some professors over not attending class more regularly in lieu of studying independently.

Einstein eventually found steady work in 1902 after receiving a referral for a clerk position in a Swiss patent office. While working at the patent office, Einstein had the time to further explore ideas that had taken hold during his university studies and thus cemented his theorems on what would be known as the principle of relativity.

In 1905—seen by many as a "miracle year" for the theorist—Einstein had four papers published in the Annalen der Physik, one of the best-known physics journals of the era. Two focused on the photoelectric effect and Brownian motion. The two others, which outlined E=MC2 and the special theory of relativity, were defining for Einstein's career and the course of the study of physics.

## Inventions and Discoveries

As a physicist, Einstein had many discoveries, but he is perhaps best known for his theory of relativity and the equation E=MC2, which foreshadowed the development of atomic power and the atomic bomb.

### Theory of Relativity

Einstein first proposed a special theory of relativity in 1905 in his paper "On the Electrodynamics of Moving Bodies," which took physics in an electrifying new direction. The theory explains that space and time are actually connected, and Einstein called this joint structure space-time.

By November 1915, Einstein completed the general theory of relativity, which accounted for gravity's relationship to space-time. Einstein considered this theory the culmination of his life research. He was convinced of the merits of general relativity because it allowed for a more accurate prediction of planetary orbits around the sun, which fell short in Isaac Newton's theory. It also offered a more expansive, nuanced explanation of how gravitational forces worked.

Einstein's assertions were affirmed via observations and measurements by British astronomers Sir Frank Dyson and Sir Arthur Eddington during the 1919 solar eclipse, and thus a global science icon was born. Today, the theories of relativity underpin the accuracy of GPS technology, among other phenomena.

Even so, Einstein did make one mistake when developing his general theory, which naturally predicted the universe is either expanding or contracting. Einstein didn't believe this prediction initially, instead holding onto the belief that the universe was a fixed, static entity. To account for, this he factored in a "cosmological constant" to his equation. His later theories directly contracted this idea and asserted that the universe could be in a state of flux. Then, astronomer Edwin Hubble deduced that we indeed inhabit an expanding universe. Hubble and Einstein met at the Mount Wilson Observatory near Los Angeles in 1931.

Decades after Einstein's death, in 2018, a team of scientists confirmed one aspect of Einstein's general theory of relativity: that the light from a star passing close to a black hole would be stretched to longer wavelengths by the overwhelming gravitational field. Tracking star S2, their measurements indicated that the star's orbital velocity increased to over 25 million kph as it neared the supermassive black hole at the center of the galaxy, its appearance shifting from blue to red as its wavelengths stretched to escape the pull of gravity.

### Einstein's E=MC²

Einstein's 1905 paper on the matter-energy relationship proposed the equation E=MC²: the energy of a body (E) is equal to the mass (M) of that body times the speed of light squared (C²). This equation suggested that tiny particles of matter could be converted into huge amounts of energy, a discovery that heralded atomic power.

Famed quantum theorist Max Planck backed up the assertions of Einstein, who thus became a star of the lecture circuit and academia, taking on various positions before becoming director of the Kaiser Wilhelm Institute for Physics (today is known as the Max Planck Institute for Physics) from 1917 to 1933.

## Nobel Prize in Physics

In 1921, Einstein won the Nobel Prize in Physics for his explanation of the photoelectric effect, since his ideas on relativity were still considered questionable. He wasn't actually given the award until the following year due to a bureaucratic ruling, and during his acceptance speech, he still opted to speak about relativity.

## Wives and Children

Einstein married Mileva Maric on January 6, 1903. While attending school in Zurich, Einstein met Maric, a Serbian physics student. Einstein continued to grow closer to Maric, but his parents were strongly against the relationship due to her ethnic background.

Nonetheless, Einstein continued to see her, with the two developing a correspondence via letters in which he expressed many of his scientific ideas. Einstein's father passed away in 1902, and the couple married shortly thereafter.

Einstein and Mavic had three children. Their daughter, Lieserl, was born in 1902 before their wedding and might have been later raised by Maric's relatives or given up for adoption. Her ultimate fate and whereabouts remain a mystery. The couple also had two sons: Hans Albert Einstein, who became a well-known hydraulic engineer, and Eduard "Tete" Einstein, who was diagnosed with schizophrenia as a young man.

The Einsteins' marriage would not be a happy one, with the two divorcing in 1919 and Maric having an emotional breakdown in connection to the split. Einstein, as part of a settlement, agreed to give Maric any funds he might receive from possibly winning the Nobel Prize in the future.

During his marriage to Maric, Einstein had also begun an affair some time earlier with a cousin, Elsa Löwenthal. The couple wed in 1919, the same year of Einstein's divorce. He would continue to see other women throughout his second marriage, which ended with Löwenthal's death in 1936.

## Travel Diaries

In his 40s, Einstein traveled extensively and journaled about his experiences. Some of his unfiltered private thoughts are shared two volumes of The Travel Diaries of Albert Einstein.

The first volume, published in 2018, focuses on his five-and-a-half month trip to the Far East, Palestine, and Spain. The scientist started a sea journey to Japan in Marseille, France, in autumn of 1922, accompanied by his second wife, Elsa. They journeyed through the Suez Canal, then to Sri Lanka, Singapore, Hong Kong, Shanghai, and Japan. The couple returned to Germany via Palestine and Spain in March 1923.

The second volume, released in 2023, covers three months that he spent lecturing and traveling in Argentina, Uruguay, and Brazil in 1925.

The Travel Diaries contain unflattering analyses of the people he came across, including the Chinese, Sri Lankans, and Argentinians, a surprise coming from a man known for vehemently denouncing racism in his later years. In an entry for November 1922, Einstein refers to residents of Hong Kong as "industrious, filthy, lethargic people."

## Becoming a U.S. Citizen

In 1933, Einstein took on a position at the Institute for Advanced Study in Princeton, New Jersey, where he would spend the rest of his life.

At the time the Nazis, led by Adolf Hitler, were gaining prominence with violent propaganda and vitriol in an impoverished post-World War I Germany. The Nazi Party influenced other scientists to label Einstein's work "Jewish physics." Jewish citizens were barred from university work and other official jobs, and Einstein himself was targeted to be killed. Meanwhile, other European scientists also left regions threatened by Germany and immigrated to the United States, with concern over Nazi strategies to create an atomic weapon.

Not long after moving and beginning his career at IAS, Einstein expressed an appreciation for American meritocracy and the opportunities people had for free thought, a stark contrast to his own experiences coming of age. In 1935, Einstein was granted permanent residency in his adopted country and became an American citizen five years later.

In America, Einstein mostly devoted himself to working on a unified field theory, an all-embracing paradigm meant to unify the varied laws of physics. However, during World War II, he worked on Navy-based weapons systems and made big monetary donations to the military by auctioning off manuscripts worth millions.

## Einstein and the Atomic Bomb

In 1939, Einstein and fellow physicist Leo Szilard wrote to President Franklin D. Roosevelt to alert him of the possibility of a Nazi bomb and to galvanize the United States to create its own nuclear weapons.

The United States would eventually initiate the Manhattan Project, though Einstein wouldn't take a direct part in its implementation due to his pacifist and socialist affiliations. Einstein was also the recipient of much scrutiny and major distrust from FBI director J. Edgar Hoover. In July 1940, the U.S. Army Intelligence office denied Einstein a security clearance to participate in the project, meaning J. Robert Oppenheimer and the scientists working in Los Alamos were forbidden from consulting with him.

Einstein had no knowledge of the U.S. plan to use atomic bombs in Japan in 1945. When he heard of the first bombing at Hiroshima, he reportedly said, "Ach! The world is not ready for it."

Einstein became a major player in efforts to curtail usage of the A-bomb. The following year, he and Szilard founded the Emergency Committee of Atomic Scientists, and in 1947, via an essay for The Atlantic Monthly, Einstein espoused working with the United Nations to maintain nuclear weapons as a deterrent to conflict.

## Time Travel and Quantum Theory

After World War II, Einstein continued to work on his unified field theory and key aspects of his general theory of relativity, including time travel, wormholes, black holes, and the origins of the universe.

However, he felt isolated in his endeavors since the majority of his colleagues had begun focusing their attention on quantum theory. In the last decade of his life, Einstein, who had always seen himself as a loner, withdrew even further from any sort of spotlight, preferring to stay close to Princeton and immerse himself in processing ideas with colleagues.

## Personal Life

In the late 1940s, Einstein became a member of the National Association for the Advancement of Colored People (NAACP), seeing the parallels between the treatment of Jews in Germany and Black people in the United States. He corresponded with scholar and activist W.E.B. Du Bois as well as performer Paul Robeson and campaigned for civil rights, calling racism a "disease" in a 1946 Lincoln University speech.

Einstein was very particular about his sleep schedule, claiming he needed 10 hours of sleep per day to function well. His theory of relativity allegedly came to him in a dream about cows being electrocuted. He was also known to take regular naps. He is said to have held objects like a spoon or pencil in his hand while falling asleep. That way, he could wake up before hitting the second stage of sleep—a hypnagogic process believed to boost creativity and capture sleep-inspired ideas.

Although sleep was important to Einstein, socks were not. He was famous for refusing to wear them. According to a letter he wrote to future wife Elsa, he stopped wearing them because he was annoyed by his big toe pushing through the material and creating a hole.

One of the most recognizable photos of the 20th century shows Einstein sticking out his tongue while leaving his 72nd birthday party on March 14, 1951.

According to Discovery.com, Einstein was leaving his party at Princeton when a swarm of reporters and photographers approached and asked him to smile. Tired from doing so all night, he refused and rebelliously stuck his tongue out at the crowd for a moment before turning away. UPI photographer Arthur Sasse captured the shot.

Einstein was amused by the picture and ordered several prints to give to his friends. He also signed a copy of the photo that sold for $125,000 at a 2017 auction.

## Death and Final Words

Einstein died on April 18, 1955, at age 76 at the University Medical Center at Princeton. The previous day, while working on a speech to honor Israel's seventh anniversary, Einstein suffered an abdominal aortic aneurysm.

He was taken to the hospital for treatment but refused surgery, believing that he had lived his life and was content to accept his fate. "I want to go when I want," he stated at the time. "It is tasteless to prolong life artificially. I have done my share, it is time to go. I will do it elegantly."

According to the BBC, Einstein muttered a few words in German at the moment of his death. However, the nurse on duty didn't speak German so their translation was lost forever.

In a 2014 interview, Life magazine photographer Ralph Morse said the hospital was swarmed by journalists, photographers, and onlookers once word of Einstein's death spread. Morse decided to travel to Einstein's office at the Institute for Advanced Studies, offering the superintendent alcohol to gain access. He was able to photograph the office just as Einstein left it.

After an autopsy, Einstein's corpse was moved to a Princeton funeral home later that afternoon and then taken to Trenton, New Jersey, for a cremation ceremony. Morse said he was the only photographer present for the cremation, but Life managing editor Ed Thompson decided not to publish an exclusive story at the request of Einstein's son Hans.

## Einstein's Brain

During Einstein's autopsy, pathologist Thomas Stoltz Harvey had removed his brain, reportedly without his family's consent, for preservation and future study by doctors of neuroscience.

However, during his life, Einstein participated in brain studies, and at least one biography claimed he hoped researchers would study his brain after he died. Einstein's brain is now located at the Princeton University Medical Center. In keeping with his wishes, the rest of his body was cremated and the ashes scattered in a secret location.

In 1999, Canadian scientists who were studying Einstein's brain found that his inferior parietal lobe, the area that processes spatial relationships, 3D-visualization, and mathematical thought, was 15 percent wider than in people who possess normal intelligence. According to The New York Times, the researchers believe it might help explain why Einstein was so intelligent.

In 2011, the Mütter Museum in Philadelphia received thin slices of Einstein's brain from Dr. Lucy Rorke-Adams, a neuropathologist at the Children's Hospital of Philadelphia, and put them on display. Rorke-Adams said she received the brain slides from Harvey.

## Einstein in Books and Movies: "Oppenheimer" and More

Since Einstein's death, a veritable mountain of books have been written on the iconic thinker's life, including Einstein: His Life and Universe by Walter Isaacson and Einstein: A Biography by Jürgen Neffe, both from 2007. Einstein's own words are presented in the collection The World As I See It.

Einstein has also been portrayed on screen. Michael Emil played a character called "The Professor," clearly based on Einstein, in the 1985 film Insignificance—in which alternate versions of Einstein, Marilyn Monroe, Joe DiMaggio, and Joseph McCarthy cross paths in a New York City hotel.

Walter Matthau portrayed Einstein in the fictional 1994 comedy I.Q., in which he plays matchmaker for his niece played by Meg Ryan. Einstein was also a character in the obscure comedy films I Killed Einstein, Gentlemen (1970) and Young Einstein (1988).

A much more historically accurate depiction of Einstein came in 2017, when he was the subject of the first season of Genius, a 10-part scripted miniseries by National Geographic. Johnny Flynn played a younger version of the scientist, while Geoffrey Rush portrayed Einstein in his later years after he had fled Germany. Ron Howard was the director.

Tom Conti plays Einstein in the 2023 biopic Oppenheimer, directed by Christopher Nolan and starring Cillian Murphy as scientist J. Robert Oppenheimer during his involvement with the Manhattan Project.

## Quotes

- *The world is a dangerous place to live; not because of the people who are evil, but because of the people who don't do anything about it.*
- *A question that sometimes drives me hazy: Am I or are the others crazy?*
- *A person who never made a mistake never tried anything new.*
- *Logic will get you from A to B. Imagination will take you everywhere.*
- *I want to go when I want. It is tasteless to prolong life artificially. I have done my share, it is time to go. I will do it elegantly.*
- *If you can't explain it simply, you don't understand it well enough.*
- *Nature shows us only the tail of the lion. But there is no doubt in my mind that the lion belongs with it even if he cannot reveal himself to the eye all at once because of his huge dimension. We see him only the way a louse sitting upon him would.*
- *[T]he distinction between past, present, and future is only an illusion, however persistent.*
- *Living in this "great age," it is hard to understand that we belong to this mad, degenerate species, which imputes free will to itself. If only there were somewhere an island for the benevolent and the prudent! Then also I would want to be an ardent patriot.*
- *I, at any rate, am convinced that He [God] is not playing at dice.*
- *How strange is the lot of us mortals! Each of us is here for a brief sojourn; for what purpose he knows not, though he sometimes thinks he senses it.*
- *I regard class differences as contrary to justice and, in the last resort, based on force.*
- *I have never looked upon ease and happiness as ends in themselves—this critical basis I call the ideal of a pigsty. The ideals that have lighted my way, and time after time have given me new courage to face life cheerfully, have been Kindness, Beauty, and Truth.*
- *My political ideal is democracy. Let every man be respected as an individual and no man idolized. It is an irony of fate that I myself have been the recipient of excessive admiration and reverence from my fellow-beings, through no fault and no merit of my own.*
- *The most beautiful experience we can have is the mysterious. It is the fundamental emotion that stands at the cradle of true art and true science. Whoever does not know it and can no longer wonder, no longer marvel, is as good as dead, and his eyes are dimmed.*
- *An autocratic system of coercion, in my opinion, soon degenerates. For force always attracts men of low morality, and I believe it to be an invariable rule that tyrants of genius are succeeded by scoundrels.*
- *My passionate interest in social justice and social responsibility has always stood in curious contrast to a marked lack of desire for direct association with men and women. I am a horse for single harness, not cut out for tandem or team work. I have never belonged wholeheartedly to country or state, to my circle of friends, or even to my own family.*
- *Everybody is a genius.*