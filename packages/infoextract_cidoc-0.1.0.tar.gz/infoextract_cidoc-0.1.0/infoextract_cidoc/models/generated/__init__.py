"""Generated CRM models package for COLLIE."""

# This package contains auto-generated CIDOC CRM E-class models
# Generated from YAML specifications in codegen/specs/
