### E21 · Person · in Philadelphia · (720a3369...)

- **Label** (`label`): in Philadelphia
- **Type** (`type`): ['E21']
- **Notes**: Person mentioned in context: earchers believe it might help explain why Einstein was so intelligent.

In 2011, the Mütter Museum in Philadelphia received thin slices of Einstein's brain from Dr. Lucy Rorke-Adams, a neuropathologist at the Children's Hosp