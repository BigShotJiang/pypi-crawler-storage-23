### E21 · Person · New Jersey · (c8037576...)

- **Label** (`label`): New Jersey
- **Type** (`type`): ['E21']
- **Notes**: Person mentioned in the text: New Jersey