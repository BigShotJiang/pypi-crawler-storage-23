# smolpack
Multidimensional Quadrature Using Sparse Grids
