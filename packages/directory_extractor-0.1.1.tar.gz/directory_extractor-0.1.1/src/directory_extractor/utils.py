# In-built packages (Standard Library modules)
import re
import os
from glob import glob
from pathlib import Path
from typing import Iterable, Optional
from datetime import datetime, timezone

# External packages


# Our Own Imports
from directory_extractor.schemas import DuplicatePolicy, FileType

def iter_regular_files(root_dir : Path) -> Iterable[Path]:
    """
    Generator that yields ALL regular files in directory tree recursively.
    
    Walks the directory using `os.walk()` and yields each file path as a Path object.
    
    <b>*Args*</b>
        - root_dir: Root directory to start scanning from
        
    <b>*Yields*</b>
        - Path: Each regular file found (skips directories, symlinks, special files)
        
    <b>*Example*</b>
    ```python
    for file_path in iter_regular_files(Path("/home/user/docs")):
        print(file_path)  # Prints: /home/user/docs/file1.txt, /home/user/docs/subdir/file2.pdf
    ```
    
    <b>*Notes*</b>
    - Uses `topdown = True` (prunes directories as it goes)
    - `followlinks = False` (avoids infinite loops from symlinks)
    - Only yields `path.is_file()` == True (skips sockets, pipes, etc.)
    - Memory efficient (generator, doesn't load all files at once)
    """
    
    # Walk directory tree recursively using os.walk
    # topdown = True: Process directories before their contents
    # followlinks = False: Don't follow symbolic links (prevents loops)
    for dirpath, dirnames, filenames in os.walk(root_dir, topdown = True, followlinks = False):
        # For each filename in current directory
        for name in filenames:
            # Construct full path using Path for cross-platform compatibility
            path = Path(dirpath)/name
            
            # Safety check: Only yield actual regular files
            if path.is_file():
                yield path


def collect_all_files(directory : Path) -> list[Path]:
    """
    Collect ALL regular files from directory into a list.
    
    Convenience wrapper around `iter_regular_files()` that loads everything into memory.
    
    <b>*Args*</b>
        - directory: Root directory to scan
            
    <b>*Returns*</b>
        - list[Path]: Complete list of all regular files found
        
    <b>*Example*</b>
    ```python
    all_files = collect_all_files(Path("/home/user/project"))
    print(len(all_files))  # e.g., 127
    print(all_files)    # e.g., PosixPath('/home/user/project/README.md')
    ```
    
    <b>*⚠️ Warning*</b>
    - Loads ALL files into memory (fine for small/medium directories)
    - Use `iter_regular_files()` for large directories to save memory
    """
    return list(iter_regular_files(directory))


def get_allowed_extensions(file_types : Optional[set[FileType]]) -> set[str]:
    """
    Convert FileType enum set to lowercase file extensions with dots.
    
    Helper for `by_types` filtering mode. Transforms enum values like FileType.pdf → '.pdf'.
    
    <b>*Args*</b>
        - file_types: Set of FileType enums or None
            
    <b>*Returns*</b>
        - set[str]: Extensions like {'.pdf', '.docx'} or empty set if None
        
    <b>*Example*</b>
    ```python
    extensions = get_allowed_extensions({FileType.pdf, FileType.md})
    print(extensions)  # {'.pdf', '.md'}
    
    extensions = get_allowed_extensions(None)
    print(extensions)  # set()
    ```
    
    <b>*Notes*</b>
        - Always returns lowercase extensions (case-insensitive matching)
        - Empty set means "no type filtering" (allow all types)
        - Dot prefix ('.pdf') matches `path.suffix` exactly
    """
    # None/empty = no filtering (return empty set)
    if not file_types:
        return set()
    
    # Transform: FileType.pdf → '.pdf' (lowercase with dot prefix)
    return {"." + ft.value.lower() for ft in file_types}


def collect_files_by_extensions(directory : Path, extensions : set[str]) -> list[Path]:
    """
    Filter files by exact file extension match (case-insensitive).
    
    Used when `mode = by_types`. Only returns files whose suffix matches extensions set.
    
    <b>*Args*</b>
        - directory: Root directory to scan
        - extensions: Set of allowed extensions (e.g., {'.pdf', '.docx'})
        
    <b>*Returns*</b>
        - list[Path]: Files with matching extensions only
        
    <b>*Raises*</b>
        - ValueError: If extensions is empty (invalid for by_types mode)
        
    <b>*Example*</b>
    ```python
    pdf_docs = collect_files_by_extensions(directory = Path("/docs"), 
                                            extensions = {".pdf", ".docx"})
    # Returns: [/docs/report.pdf, /docs/guide.docx]
    ```
    
    <b>*Notes*</b>
        - Case-insensitive: '.Pdf' matches 'report.PDF'
        - Uses `p.suffix.lower()` (e.g., 'file.pdf' → '.pdf')
    """
    # SAFETY: by_types mode requires extensions to be specified
    if not extensions:
        raise ValueError("mode = by_types requires non-empty 'file_types'")
    
    # List comprehension: Filter files where suffix matches extensions
    # collect_all_files() → check p.suffix.lower() → collect matching paths
    return [p for p in collect_all_files(directory = directory) if p.suffix.lower() in extensions]


def is_path_within(base_dir : Path, target_path : Path) -> bool:
    """
    SAFETY CHECK: Verify target_path is inside base_dir (prevents directory traversal).
    
    Uses `resolve()` + `relative_to()` to check if one path is safely contained within another.
    Critical security function to prevent accessing files outside the target directory.
    
    <b>*Args*</b>
        - base_dir: Parent directory (e.g., /home/user/docs)
        - target_path: File to verify (e.g., /home/user/docs/subdir/file.txt)
        
    <b>*Returns*</b>
        - bool: True if target_path is safely inside base_dir
        
    <b>*Example*</b>
    ```python
    # ✅ SAFE
    is_path_within(Path("/docs"), Path("/docs/subdir/file.txt"))  # True
    
    # ❌ DANGEROUS (path traversal attempt)
    is_path_within(Path("/docs"), Path("/etc/passwd"))          # False
    is_path_within(Path("/docs"), Path("../secret.txt"))         # False
    ```
    
    <b>*How it works*</b>
    1. `resolve()`: Converts to absolute path (follows symlinks)
    2. `relative_to()`: Tries to get relative path from base_dir
    3. Success = path is contained within base_dir
    4. Any `ValueError`/`RuntimeError` = path is outside → UNSAFE
    """
    try:
        # Step 1: Resolve to absolute paths (handles symlinks, relative paths)
        resolved_base = base_dir.resolve()
        resolved_target = target_path.resolve()
        
        # Step 2: Try to compute relative path target → base
        # Succeeds ONLY if target is inside base directory tree
        resolved_target.relative_to(resolved_base)
        return True
    
    # Step 3: Any path resolution error = target is OUTSIDE base_dir
    except Exception:
        return False


def collect_files_by_names(base_dir : Path, 
                           requested_names : Optional[list[str]], 
                           case_insensitive : bool = False, 
                           duplicate_policy : DuplicatePolicy = DuplicatePolicy.all) -> tuple[list[Path], list[str]]:
    """
    Find files by exact name or relative path (by_names mode).
    
    <b>*Handles both*</b>
    1. **Relative paths** (e.g., "docs/guide.pdf")
    2. **Bare filenames** (e.g., "README.md" - searches everywhere)
    
    <b>*Args*</b>
        - base_dir: Root directory to search within
        - requested_names: List of filenames/paths to find
        - case_insensitive: Ignore case for bare filenames (default: False)
        - duplicate_policy: How to handle multiple files with same name
        
    <b>*Returns*</b>
        - Tuple[List[Path], List[str]]:
            - found_files: Sorted list of unique matching files
            - missing_names: Names that weren't found
            
    <b>*Raises*</b>
        - ValueError: If requested_names is empty/None
        
    <b>*Example*</b>
    ```python
    # Find specific files
    files, missing = collect_files_by_names(base_dir = Path("/project"), 
                    requested_names = ["README.md", "docs/guide.pdf", "data.csv"])
    
    # files: [/project/README.md, /project/docs/guide.pdf]
    # missing: ['data.csv']
    ```
    
    <b>*Complex Example (bare names + duplicates)*</b>
    ```python
    # Multiple README.md files exist
    files, missing = collect_files_by_names(base_dir = Path("/project"), 
                    requested_names = ["readme.md"],  # case_insensitive = True
                    case_insensitive = True,
                    duplicate_policy = DuplicatePolicy.first  # Only first match
                    )
    ```
    """
    # VALIDATION: by_names mode requires names to search for
    if not requested_names:
        raise ValueError("mode = by_names requires non-empty 'file_names'")
    
    # Resolve base directory to absolute path for security checks
    base = base_dir.resolve()
    found_files : list[Path] = []
    missing_names : list[str] = []
    
    # OPTIMIZATION: Check if we need to index all filenames
    # needs_bare_lookup = True if any name lacks path separators ("/" or "\\")
    needs_bare_lookup = any("\\" not in n and "/" not in n for n in requested_names if n)
    
    # BUILD FILENAME INDEX (only if searching bare filenames)
    filename_index : Optional[dict[str, list[Path]]] = None
    if needs_bare_lookup:
        filename_index = {}
        print(f"🔍 Indexing {len(list(iter_regular_files(base)))} files for name lookup...")
        
        # Create case-sensitive/case-insensitive index of ALL files
        for p in iter_regular_files(base):
            # Key: filename (lowercase if case_insensitive)
            key = p.name.lower() if case_insensitive else p.name
            
            # Group paths by filename (handles duplicates)
            filename_index.setdefault(key, []).append(p.resolve())
    
    # PROCESS EACH REQUESTED NAME
    for original in requested_names:
        # Skip None/empty names
        if original is None:
            continue
        name = original.strip()
        if not name:
            continue
        
        # PATH 1: Relative path with separators (e.g., "docs/guide.pdf")
        has_sep = ("/" in name) or ("\\" in name)
        if has_sep:
            # Normalize to forward slashes for cross-platform
            rel_path = Path(name.replace("\\", "/"))
            candidate = (base/rel_path).resolve()
            
            # Check: exists + is file + safely within base_dir
            if candidate.is_file() and is_path_within(base, candidate):
                found_files.append(candidate)
            else:
                missing_names.append(original)
        
        # PATH 2: Bare filename (e.g., "README.md") - search everywhere
        else:
            if not filename_index:
                missing_names.append(original)
                continue
            
            # Lookup in index (case-insensitive if enabled)
            key = name.lower() if case_insensitive else name
            matches = filename_index.get(key, [])
            
            if not matches:
                missing_names.append(original)
                continue
            
            # HANDLE DUPLICATES according to policy
            if len(matches) == 1 or duplicate_policy == DuplicatePolicy.all:
                # Single match OR return all matches
                found_files.extend(matches)
            elif duplicate_policy == DuplicatePolicy.first:
                # Return only first match
                found_files.append(matches[0])
            else:  # DuplicatePolicy.error
                # Mark as ambiguous (multiple matches found)
                missing_names.append(original + " (ambiguous; multiple matches)")
    
    # FINAL CLEANUP: Remove duplicates, sort by resolved path
    unique_sorted = sorted({p.resolve() for p in found_files})
    return unique_sorted, missing_names


def get_file_size_bytes(file_path : Path) -> int:
    """
    Get file size in bytes from filesystem stat.
    
    <b>*Args*</b>
        - file_path: Path to existing file
            
    <b>*Returns*</b>
        - int: File size in bytes (e.g., 1024 for 1KB)
        
    <b>*Raises*</b>
        - FileNotFoundError: If file doesn't exist
        - PermissionError: If no read access
        
    <b>*Example*</b>
    ```python
    size = get_file_size_bytes(Path("report.pdf"))
    print(f"{size / 1024 / 1024:.1f} MB")  # e.g., "2.3 MB"
    ```
    """
    
    # stat() returns filesystem metadata
    # st_size = exact byte size of the file
    return file_path.stat().st_size


def get_modified_time_utc(file_path : Path) -> datetime:
    """
    Get file's last modification time in UTC timezone.
    
    Converts filesystem timestamp to aware datetime (UTC).
    
    <b>*Args*</b>
        - file_path: Path to existing file
            
    <b>*Returns*</b>
        - datetime: Modification time in UTC (tz-aware)
        
    <b>*Raises*</b>
        - FileNotFoundError: If file doesn't exist
        
    <b>*Example*</b>
    ```python
    mod_time = get_modified_time_utc(Path("README.md"))
    print(mod_time)  # 2024-02-23 10:30:45+00:00
    ```
    
    <b>*Notes*</b>
        - Uses `st_mtime` (modification time, not access/create time)
        - Always returns UTC (timezone-aware) for consistent filtering
    """
    return datetime.fromtimestamp(file_path.stat().st_mtime, tz = timezone.utc)


def convert_to_utc(dt : Optional[datetime]) -> Optional[datetime]:
    """
    Safely convert datetime to UTC timezone.
    
    <b>*Handles all cases*</b>
    1. None → None
    2. Naive datetime → Assume local, convert to UTC
    3. Aware datetime → Convert to UTC
    
    <b>*Args*</b>
        - dt: Datetime to convert (naive or aware) or None
            
    <b>*Returns*</b>
        - Optional[datetime]: UTC timezone-aware datetime or None
        
    <b>*Example*</b>
    ```python
    # Naive datetime (no timezone)
    dt = datetime(2024, 1, 1, 12, 0)
    utc_dt = convert_to_utc(dt)  # 2024-01-01 12:00:00+00:00 (assumes local)
    
    # Aware datetime (IST → UTC)
    dt_ist = datetime(2024, 1, 1, 17, 30, tzinfo = timezone(timedelta(hours = 5, minutes = 30)))
    utc_dt = convert_to_utc(dt_ist)  # 2024-01-01 12:00:00+00:00
    ```
    
    <b>*Why this matters*</b>
        - `modified_after`/`modified_before` filters need consistent UTC comparison
        - Prevents timezone bugs across servers/users
        - Safe: Handles None, naive, and aware datetimes
    """
    # CASE 1: None input
    if dt is None:
        return None
    
    # CASE 2: Naive datetime (no tzinfo) → assume local time → make UTC
    if dt.tzinfo is None:
        return dt.replace(tzinfo = timezone.utc)
    
    # CASE 3: Already timezone-aware → convert to UTC
    return dt.astimezone(timezone.utc)


def apply_guardrails(base_dir : Path, 
                     files : list[Path], 
                     max_file_size_mb : Optional[float], 
                     modified_after : Optional[datetime], 
                     modified_before : Optional[datetime], 
                     limit : Optional[int] = None) -> tuple[list[Path], dict[str, int]]:
    """
    Apply ALL safety guardrails and return filtered + sorted results.
    
    Filters files by:
    1. File size limit
    2. Modification time window
    3. Result count limit
    4. File existence
    
    <b>*Args*</b>
        - base_dir: Root directory (for sorting)
        - files: Candidate files to filter
        - max_file_size_mb: Skip files larger than this (MB)
        - modified_after: Only newer files (UTC)
        - modified_before: Only older files (UTC)
        - limit: Max files to keep
        
    <b>*Returns*</b>
        - Tuple[List[Path], Dict[str, Any]]:
            - kept_files: Filtered + sorted files
            - skip_summary: Detailed stats on why files were rejected
            
    <b>*Raises*</b>
        - ValueError: Invalid time window (after ≥ before)
        
    <b>*Example*</b>
    ```python
    files, summary = apply_guardrails(base_dir = Path("/docs"), 
                    files = [Path("big.pdf"), Path("old.txt"), Path("small.pdf")],
                    max_file_size_mb = 5.0,
                    modified_after = datetime(2024, 1, 1, tzinfo = timezone.utc),
                    limit = 10)
    print(summary)
    # {'too_large' : 1, 'outside_time_window' : 1, 'disappeared' : 0}
    ```
    """
    # CONVERT: MB → bytes for comparison
    max_bytes = int(max_file_size_mb * 1024 * 1024) if max_file_size_mb else None
    
    # NORMALIZE: All datetimes to UTC for consistent comparison
    after_utc = convert_to_utc(modified_after)
    before_utc = convert_to_utc(modified_before)
    
    # VALIDATION: Time window must make sense
    if after_utc and before_utc and after_utc >= before_utc:
        raise ValueError("'modified_after' must be earlier than 'modified_before'")
    
    # RESULT TRACKING
    kept_files : list[Path] = []
    skip_summary = {"too_large" : 0, "outside_time_window" : 0, "disappeared" : 0, "files" : []}
    
    # APPLY FILTERS: Process each candidate file
    for path in files:
        try:
            # FILTER 1: SIZE LIMIT
            if max_bytes and get_file_size_bytes(path) > max_bytes:
                skip_summary["too_large"] = skip_summary["too_large"] + 1
                skip_summary["files"].append(path)
                continue
            
            # FILTER 2: MODIFICATION TIME WINDOW
            mtime = get_modified_time_utc(path)
            passes_time = True
            
            # STRICTLY after modified_afters
            if after_utc and not (mtime > after_utc):
                passes_time = False
            
            # STRICTLY before modified_before
            if before_utc and not(mtime < before_utc):
                passes_time = False
            
            if not passes_time:
                skip_summary["outside_time_window"] = skip_summary["outside_time_window"] + 1
                skip_summary["outside_time_window"].append(path)
                continue
            
            # PASSED ALL FILTERS
            kept_files.append(path)
        
        # HANDLE: File deleted/moved between scan and filter
        except FileNotFoundError:
            skip_summary["disappeared"] = skip_summary["disappeared"] + 1
            skip_summary["disappeared"].append(path)
    
    # SORTING: Relative paths within base_dir (directory tree order)
    try:
        base = base_dir.resolve()
        
        # Sort by relative path (e.g., "docs/sub/a.txt" <b "docs/sub/b.txt")
        kept_sorted = sorted(kept_files, key = lambda p : p.resolve().relative_to(base).as_posix())
    except Exception:
        # FALLBACK: Sort by absolute path if relative_to fails
        kept_sorted = sorted(kept_files, key = lambda p : str(p.resolve()))
    
    # FINAL LIMIT: Cap results if specified
    if limit is  not None:
        kept_sorted = kept_sorted[: int(limit)]
    
    return kept_sorted, skip_summary


def filter_excluded_files(base_dir : Path, 
                          files : list[Path], 
                          exclude_names : Optional[list[str]], 
                          case_insensitive : bool = False) -> tuple[list[Path], list[str]]:
    """
    Remove files matching exclude_names patterns.
    
    <b>*Supports two exclusion types*</b>
    1. **Relative paths** (e.g., "docs/README.md")
    2. **Bare filenames** (e.g., "temp.txt" - excludes all matches)
    
    <b>*Args*</b>
        - base_dir: Root directory (for relative path calculation)
        - files: Candidate files to filter
        - exclude_names: Patterns/names to exclude
        - case_insensitive: Ignore case for bare filenames
        
    <b>*Returns*</b>
        - Tuple[List[Path], List[str]]:
            - kept_files: Files that PASSED exclusion filter
            - matched_exclusions: Which exclusion patterns actually matched files
            
    <b>*Example*</b>
    ```python
    files, matched = filter_excluded_files(base_dir = Path("/project"), 
                    files = [Path("/project/README.md"), Path("/project/docs/temp.txt")],
                    exclude_names = ["README.md", "secret/*"])
    # kept_files : [/project/docs/temp.txt]
    # matched : ['README.md']
    ```
    """
    
    # NOTHING TO EXCLUDE → Fast return
    if not exclude_names:
        return files, []
    
    # SECURITY: Use resolved base for relative path calculations
    base = base_dir.resolve()
    
    # BUILD INDEXES FOR FAST LOOKUP
    rel_lookup : dict[str, Path] = {}  # "docs/file.txt" → Path
    name_lookup : dict[str, list[Path]] = {}  # "temp.txt" → [Path1, Path2, ...]
    
    for file_path in files:
        # INDEX 1: Relative path (POSIX format for consistency)
        rel_posix = file_path.resolve().relative_to(base).as_posix()
        rel_lookup[rel_posix] = file_path
        
        # INDEX 2: Bare filename (case-insensitive option)  
        filename_key = file_path.name.lower() if case_insensitive else file_path.name
        name_lookup.setdefault(filename_key, []).append(file_path)
    
    # COLLECT FILES TO EXCLUDE
    to_exclude : set[Path] = set()
    matched_exclusions : list[str] = []
    
    # PROCESS EACH EXCLUSION PATTERN
    for raw_entry in exclude_names:
        # Skip None/empty entries
        if raw_entry is None:
            continue
        
        entry = raw_entry.strip()
        if not entry:
            continue
        
        # PATH 1: Relative path exclusion (e.g., "docs/README.md")
        has_slash = ("/" in entry) or ("\\" in entry)
        if has_slash:
            # Normalize: Windows \ → Unix / + POSIX format
            rel_norm = Path(entry.replace("\\", "/")).as_posix()
            
            # Exact relative path match?
            match_path = rel_lookup.get(rel_norm)
            if match_path:
                to_exclude.add(match_path)
                matched_exclusions.append(raw_entry)
        
        # PATH 2: Bare filename exclusion (e.g., "temp.txt")
        else:
            key = entry.lower() if case_insensitive else entry
            matched_paths = name_lookup.get(key, [])
            
            if matched_paths:
                # Exclude ALL files with this name
                for p in matched_paths:
                    to_exclude.add(p)
                matched_exclusions.append(raw_entry)
    
    # FINAL FILTER: Remove excluded files
    kept_files = [p for p in files if p not in to_exclude]
    return kept_files, matched_exclusions


def collect_files_by_patterns(base_dir : Path, include_globs : list[str]) -> list[Path]:
    """
    Find files using glob patterns (by_patterns mode).
    
    <b>*Supports recursive glob patterns like*</b>
    - `**/*.md` = All markdown files recursively
    - `docs/*.pdf` = PDFs in docs folder only  
    - `data/**/*.csv` = CSVs in data and subfolders
    
    <b>*Args*</b>
        base_dir: Root directory for relative glob patterns
        include_globs: List of glob patterns
            
    <b>*Returns*</b>
        list[Path]: Sorted unique files matching ANY pattern
        
    <b>*Raises*</b>
        ValueError: Empty globs list or absolute paths detected
        
    <b>*Example*</b>
    ```python
    files = collect_files_by_patterns(base_dir = Path("/project"), 
            include_globs = ["**/*.md", "docs/*.pdf"])
    # Returns : [/project/README.md, /project/docs/guide.pdf]
    ```
    """
    # VALIDATION: by_patterns requires patterns
    if not include_globs:
        raise ValueError("mode = by_patterns requires non-empty 'include_globs'")
    
    # SECURITY: Resolve root for path validation
    root = base_dir.resolve()
    found : set[Path] = set()  # Use set to auto-deduplicate
    
    # PROCESS EACH GLOB PATTERN
    for pat in include_globs:
        # Skip empty patterns
        if not pat or not str(pat).strip():
            continue
        
        # Normalize: Windows \ → Unix /
        normalized = pat.replace("\\", "/").strip()
        
        # SECURITY: Reject absolute paths (prevents traversal)
        if normalized.startswith("/") or re.match(r"^[a-zA-Z]:[/\\\\]", normalized):
            raise ValueError(f"Absolute patterns are not allowed : '{pat}'")
        
        # GLOB MAGIC ✨
        # glob() with root_dir + recursive=True = powerful pattern matching
        for rel in glob(normalized, root_dir = str(root), recursive = True):
            # Construct absolute path
            candidate = (root / rel).resolve()
            
            # SAFETY + VALIDATION
            if candidate.is_file() and is_path_within(root, candidate):
                found.add(candidate)
    
    # RETURN: Sorted deterministic order
    return sorted(found)