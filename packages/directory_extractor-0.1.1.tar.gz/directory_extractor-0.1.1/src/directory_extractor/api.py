# In-built packages (Standard Library modules)
from pathlib import Path

# External packages
import uvicorn
from starlette import status
from fastapi import FastAPI, HTTPException
from fastapi.concurrency import run_in_threadpool

# Our Own Imports
from directory_extractor.schemas import IndexDirectoryRequest, IndexMode
from directory_extractor.utils import apply_guardrails, collect_all_files, collect_files_by_names, collect_files_by_extensions, collect_files_by_patterns, filter_excluded_files, get_allowed_extensions

app = FastAPI(title = "Directory Extraction API", description = "Robust file listing and filtering from directories", version = "0.1.0")

def run():
    uvicorn.run("directory_extractor.api:app", host = "0.0.0.0", port = 8000)

@app.post("/directory/", status_code = status.HTTP_200_OK, summary = "Index directory files with filters")
async def index_directory(payload : IndexDirectoryRequest):
    """
    Main API endpoint - orchestrates complete directory extraction pipeline.
    
    <b>*Pipeline Flow*</b>
    1. SELECT files (mode-specific)
    2. EXCLUDE unwanted files  
    3. APPLY guardrails (size/date/limit)
    4. RETURN stats + relative paths
    
    <b>*Args*</b>
    - payload: Complete configuration (see IndexDirectoryRequest)
        
    <b>*Returns*</b>
    - dict: Comprehensive results with stats and file paths
        
    <b>*Example Request*</b>
    ```json
    {
        "directory" : "/home/user/docs",
        "mode" : "by_types", 
        "file_types" : ["pdf", "md"],
        "max_file_size_mb" : 10.0,
        "limit" : 50
    }
    ```
    
    <b>*Example Response*</b>
    ```json
    {
        "total_candidates" : 127, 
        "excluded_names" : [], 
        "excluded_names_matched" : [], 
        "post_exclude_candidates" : 115, 
        "total_selected" : 42, 
        "selected_files" : ["README.md", "docs/guide.pdf"], 
        "skipped" : {"too_large" : 5, "outside_time_window" : 68, "disappeared" : 0, "files" : []}, 
        "selected_files_path" : ["/home/siddharth/Documents/README.md", "/home/siddharth/Documents/docs/guide.pdf"]
    }
    ```
    """
    try:
        # SECURITY: Resolve directory path
        base_dir = Path(payload.directory).resolve()
        
        result = {}
        files_found : list[Path] = []
        unresolved_names : list[str] = []
        
        # =============================================================================
        # STEP 1: MODE-SPECIFIC FILE COLLECTION
        # =============================================================================
        
        if payload.mode == IndexMode.all:
            # ALL files (no filtering)
            files_found = await run_in_threadpool(collect_all_files, directory = base_dir)
        elif payload.mode == IndexMode.by_types:
            # VALIDATION
            if not payload.file_types:
                raise HTTPException(status_code = status.HTTP_400_BAD_REQUEST, detail = "mode = by_types requires non-empty 'file_types'")
            allowed_exts = get_allowed_extensions(payload.file_types)
            
            files_found = await run_in_threadpool(collect_files_by_extensions, directory = base_dir, extensions = allowed_exts)
        elif payload.mode == IndexMode.by_names:
            # VALIDATION
            if not payload.file_names:
                raise HTTPException(status_code = status.HTTP_400_BAD_REQUEST, detail = "mode = by_names requires non-empty 'file_names'")
            
            # Collect + get missing names stats
            resolved_files, unresolved_names = await run_in_threadpool(collect_files_by_names, base_dir = base_dir, 
                                                                       requested_names = payload.file_names, 
                                                                       case_insensitive = payload.case_insensitive, 
                                                                       duplicate_policy = payload.duplicate_policy)
            
            files_found = resolved_files
            result["total_requested_names"] = len(payload.file_names)
            result["missing_names"] = unresolved_names
            
        elif payload.mode == IndexMode.by_patterns:
            # VALIDATION
            if not payload.include_globs:
                raise HTTPException(status_code = status.HTTP_400_BAD_REQUEST, detail = "mode = by_patterns requires non-empty 'include_globs'")
            files_found = await run_in_threadpool(collect_files_by_patterns, base_dir = base_dir, include_globs = payload.include_globs)
        else:
            raise HTTPException(status_code = status.HTTP_400_BAD_REQUEST, detail = "Unsupported mode for this route")
        
        # =============================================================================
        # STEP 2: APPLY EXCLUSIONS
        # =============================================================================
        files_after_exclude, matched_exclusions = await run_in_threadpool(filter_excluded_files, 
                                                                          base_dir = base_dir, 
                                                                          files = files_found, 
                                                                          exclude_names = payload.exclude_names, 
                                                                          case_insensitive = payload.case_insensitive)
        
        # =============================================================================
        # STEP 3: APPLY GUARDRAILS
        # =============================================================================
        files_kept, skip_summary = await run_in_threadpool(apply_guardrails, 
                                                           base_dir = base_dir, 
                                                           files = files_after_exclude, 
                                                           max_file_size_mb = payload.max_file_size_mb, 
                                                           modified_after = payload.modified_after, 
                                                           modified_before = payload.modified_before, 
                                                           limit = payload.limit)
        
        # =============================================================================
        # STEP 4: FORMAT RESPONSE
        # =============================================================================
        # Convert to user-friendly relative paths (sorted)
        rel_paths = sorted([p.resolve().relative_to(base_dir).as_posix() for p in files_kept])
        
        # COMPREHENSIVE STATS
        result.update({
            "total_candidates" : len(files_found), 
            "excluded_names" : payload.exclude_names or [], 
            "excluded_names_matched" : matched_exclusions, 
            "post_exclude_candidates" : len(files_after_exclude), 
            "total_selected" : len(rel_paths), 
            "selected_files" : rel_paths, 
            "skipped" : skip_summary, 
            "selected_files_path" : files_kept
        })
        
        return result
    
    # =============================================================================
    # ERROR HANDLING
    # =============================================================================
    except HTTPException:
        # Re-raise FastAPI exceptions unchanged
        raise
    except ValueError as ve:
        # Validation errors (400)
        raise HTTPException(status_code = status.HTTP_400_BAD_REQUEST, detail = str(ve))
    except Exception as ex:
        # Unexpected errors (500)
        raise HTTPException(status_code = status.HTTP_500_INTERNAL_SERVER_ERROR, detail = f"Internal error : {ex}")