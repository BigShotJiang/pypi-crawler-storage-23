# In-built packages (Standard Library modules)
from enum import Enum
from typing import Optional
from datetime import datetime

# External packages
from pydantic import BaseModel, Field, DirectoryPath, PositiveFloat

# Our Own Imports


class IndexMode(str, Enum):
    """
    Defines how files are selected from the directory.
    
    Attributes:
        all: Include ALL files in the directory (no filtering by name/type)
        by_types: Filter by specific file extensions (e.g., .pdf, .docx)
        by_names: Filter by exact filenames or relative paths
        by_patterns: Filter using glob patterns (e.g., **/*.md, docs/*.pdf)
    """
    all = "all"
    by_types = "by_types"
    by_names = "by_names"
    by_patterns = "by_patterns"


class FileType(str, Enum):
    """
    Supported file extensions for type-based filtering.
    
    Use with `IndexDirectoryRequest.file_types` when `mode=by_types`.
    """
    docx = "docx"
    xlsx = "xlsx"
    pptx = "pptx"
    txt = "txt"
    pdf = "pdf"
    md = "md"
    csv = "csv"
    json = "json"
    html = "html"
    png = "png"
    jpg = "jpg"
    jpeg = "jpeg"


class DuplicatePolicy(str, Enum):
    """
    Policy for handling duplicate filename matches in `by_names` mode.
    
    Attributes:
        error: Raise an error if duplicates found
        first: Return only the first match found
        all: Return all matching files
    """
    error = "error"
    first = "first"
    all = "all"


class IndexDirectoryRequest(BaseModel):
    """
    Main configuration model for directory file extraction.
    
    This model validates all parameters needed to scan a directory and filter files.
    Required: Only `directory` path is mandatory.
    All other fields have smart defaults for easy usage.
    
    Example Usage:
    ```python
    # Scan all files in a folder
    request = IndexDirectoryRequest(directory = "/path/to/docs")
    
    # Filter only PDFs modified after Jan 1, 2024
    request = IndexDirectoryRequest(directory = "/path/to/docs", 
                                    mode = IndexMode.by_types, 
                                    file_types = {FileType.pdf}, 
                                    modified_after = datetime(2024, 1, 1))
    ```
    
    Attributes:
        directory: Root folder to scan (REQUIRED)
        mode: Selection strategy (default: 'all')
        file_types: Specific extensions when mode='by_types' (default: None)
        file_names: Exact filenames/paths when mode='by_names' (default: None)
        exclude_names: Filenames/paths to skip (works with any mode)
        include_globs: Glob patterns when mode='by_patterns' (default: None)
        case_insensitive: Ignore case for filenames (by_names mode only)
        duplicate_policy: Handle duplicate name matches (by_names mode only)
        max_file_size_mb: Skip large files (default: None/unlimited)
        modified_after: Newer-than filter (default: None)
        modified_before: Older-than filter (default: None)
        limit: Max files to return (default: None/unlimited)
    """
    # =============================================================================
    # REQUIRED PARAMETERS
    # =============================================================================
    directory : DirectoryPath = Field(description = "Root directory to scan for files to index", 
                                      examples = ["/home/user/documents", "C:\\Projects\\docs"])
    
    # =============================================================================
    # SELECTION MODE
    # =============================================================================
    mode : IndexMode = Field(default = IndexMode.all, 
                             description = "How to select files : all, by_types, by_names, or by_patterns")
    
    # =============================================================================
    # MODE-SPECIFIC FILTERS
    # =============================================================================
    file_types : Optional[set[FileType]] = Field(default = None, 
                                                 description = "REQUIRED when mode = 'by_types'. Set of allowed file extensions.")
    
    file_names : Optional[list[str]] = Field(default = None, 
                                             description = "REQUIRED when mode = 'by_names'. Exact filenames or relative paths.", 
                                             examples = [["README.md", "docs/guide.docx", "data/report.xlsx"]])
    
    exclude_names : Optional[list[str]] = Field(default = None, 
                                                description = (
                                                "Files to EXCLUDE from results (works with ANY mode).\n"
                                                "• Entries with '/' or '\\' = relative paths (e.g., 'docs/README.md')\n"
                                                "• Entries without slashes = bare filenames (matches anywhere)\n"
                                                "• Supports case_insensitive matching for bare filenames"), 
                                                examples = [["README.md", "temp/*", "docs/guide.docx"]])
    
    include_globs : Optional[list[str]] = Field(default = None, 
                                                description = (
                                                    "REQUIRED when mode='by_patterns'. Glob patterns relative to 'directory'.\n"
                                                    "• '**/*.md' = all markdown files recursively\n"
                                                    "• 'docs/**/*.pdf' = all PDFs in docs folder and subfolders\n"
                                                    "• '*.txt' = txt files in root only"), 
                                                examples = [["**/*.md", "docs/**/*.pdf", "images/*.png"]])
    
    # =============================================================================
    # BY_NAMES MODE - SPECIAL BEHAVIOR
    # =============================================================================
    case_insensitive : bool = Field(default = None, 
                                    description = (
                                        "When mode='by_names':\n"
                                        "• True = Match filenames case-insensitively (e.g., 'readme.md' matches 'README.md')\n"
                                        "• False/None = Case-sensitive matching\n"
                                        "• Only affects bare filenames (no path separators)"))
    
    duplicate_policy : DuplicatePolicy = Field(default = DuplicatePolicy.all, 
                                              description = (
            "When mode='by_names' finds multiple files with same name:\n"
            "• 'error' = Raise ValueError\n"
            "• 'first' = Return first match only\n"
            "• 'all' = Return all matches"
        ))
    
    # =============================================================================
    # GUARDRAILS (SAFETY LIMITS)
    # =============================================================================
    max_file_size_mb : Optional[PositiveFloat] = Field(default = None, description = "Skip files LARGER than this size (MB). None = no limit.")
    modified_after : Optional[datetime] = Field(default = None, description = "Include ONLY files modified STRICTLY AFTER this datetime.")
    modified_before : Optional[datetime] = Field(default = None, description = "Include ONLY files modified STRICTLY BEFORE this datetime.")
    limit : Optional[int] = Field(default = None, ge = 1, description = "Maximum number of files to return. None = process all matching files.")