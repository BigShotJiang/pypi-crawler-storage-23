"""Shanks CLI - Modular command-line interface"""

from .main import main
from .sorm import sorm_main

__all__ = ["main", "sorm_main"]
