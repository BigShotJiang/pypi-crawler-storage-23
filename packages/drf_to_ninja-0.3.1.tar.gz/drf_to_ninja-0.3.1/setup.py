from setuptools import setup

# All configuration is defined in pyproject.toml.
# This file exists for backward compatibility with
# older pip versions that don't support PEP 517.
setup()
