# Copyright 2025 The LiteRT Torch Authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ==============================================================================
"""Exportable modules."""

import dataclasses
import torch


@dataclasses.dataclass
class ExportableModuleConfig:
  """Config for exportable modules."""
  task: str = "text_generation"

  work_dir: str | None = None
  output_dir: str | None = None

  use_jinja_template: bool = False
  litert_lm_model_type_override: str | None = None

  batch_size: int = 1
  cache_length: int = 1280
  prefill_lengths: list[int] = dataclasses.field(default_factory=lambda: [128])
  # For dynamic shape
  cache_length_dim: torch.export.Dim | None = None
  prefill_length_dim: torch.export.Dim | None = None

  # For quantization
  quantization_recipe: str | None = None
  vision_encoder_quantization_recipe: str | None = None

  # Export configs
  externalize_embedder: bool = False
  single_token_embedder: bool = False
  externalize_rope: bool = False

  export_vision_encoder: bool = False

  split_cache: bool = False
  cache_implementation: str = "LiteRTLMCache"
  k_ts_idx: int = 2
  v_ts_idx: int = 3

  # Experimental configs
  experimental_use_mixed_precision: bool = False
