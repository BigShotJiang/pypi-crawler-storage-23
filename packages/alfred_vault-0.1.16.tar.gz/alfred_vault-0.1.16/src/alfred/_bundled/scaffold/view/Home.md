---
type: view
name: Home
owner: # Link to your Person record, e.g. "[[person/Your Name]]"
updated:
tags:
  - view
  - personal
---

# Home

---

## Morning Briefing
<!-- ALFRED:DYNAMIC — Alfred rewrites this section each morning -->

*Alfred will populate this section with a daily briefing once configured. It will include: what happened overnight, what needs your attention today, conversations to watch, and a weekly pulse summary.*

<!-- END ALFRED:DYNAMIC -->

---

## My Tasks
![[view-home.base#My Tasks - Active]]

## Waiting On Others
![[view-waiting.base#Waiting On Others]]

## My Conversations
![[view-home.base#My Conversations]]

## Inbox — Unprocessed
![[view-inbox.base#Unprocessed Inbox]]

## My Sessions
![[view-home.base#Recent Sessions]]

## All Team Sessions
![[view-sessions.base#All Recent Sessions]]

## Active Projects
![[view-projects.base#Active Projects]]

---

## Alfred's Notes
<!-- ALFRED:DYNAMIC — Alfred updates this with observations, suggestions, patterns -->

*Alfred will populate this section with observations, suggestions, and patterns detected across your work. Things like: stale conversations, recurring blockers, opportunities for process improvement.*

<!-- END ALFRED:DYNAMIC -->

---

## Recently Completed
![[view-home.base#My Tasks - Completed]]
