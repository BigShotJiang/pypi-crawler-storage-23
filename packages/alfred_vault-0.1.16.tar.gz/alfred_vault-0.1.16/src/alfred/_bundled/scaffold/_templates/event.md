---
type: event
name:
description:
date:
participants: [] # Links to People
location: # Link to Location
project: # Link to Project
session: # Link to Session
related: []
relationships: []
created: "{{date}}"
tags: []
---

# {{title}}

## Related
![[related.base#All]]
