---
type: project
status: active # active | paused | completed | abandoned | proposed
name:
description:
client: # Link to Org
parent: # Link to parent Project (for phases/sub-projects)
owner: # Link to Person
location: # Link to Location
related: []
relationships: []
supports: [] # [[what this project enables]]
based_on: [] # [[assumptions/decisions this rests on]]
depends_on: [] # [[operational prerequisites — projects, processes]]
blocked_by: [] # [[active blockers]]
approved_by: [] # [[person links — authority chain]]
created: "{{date}}"
tags: []
---

# {{title}}

Brief description of the project's purpose and goal.

---

## Assumptions
![[project.base#Assumptions]]

## Decisions
![[project.base#Decisions]]

## Constraints
![[project.base#Constraints]]

## Contradictions
![[project.base#Contradictions]]

## Dependencies
![[project.base#Dependencies]]

## Tasks
![[project.base#Tasks]]

## Sub-projects
![[project.base#Sub-projects]]

## Sessions
![[project.base#Sessions]]

## Learnings
![[project.base#Learnings]]

## Conversations
![[project.base#Conversations]]

## Inputs
![[project.base#Inputs]]

## Notes
![[project.base#Notes]]
