---
type: contradiction
status: unresolved # unresolved | resolved | accepted
resolution: "" # how it was resolved (if resolved)
resolved_date:
claim_a: "" # [[link or description of first claim]]
claim_b: "" # [[link or description of conflicting claim]]
source_a: "" # where claim A came from
source_b: "" # where claim B came from
project: [] # [[project links]]
related: []
created: "{{date}}"
tags: []
---

# {{title}}

## Claim A

<!-- First version of events / data -->

## Claim B

<!-- Conflicting version -->

## Analysis

<!-- Why do these conflict? Is it timing, perspective, error? -->

## Resolution

<!-- How was this resolved? Which claim held? What changed? -->

![[learn-contradiction.base#Related]]
