Python API
##########

The HiGlass python API provides a functionality for starting a
lightweight server, creating viewconfs and displaying a HiGlass
component within Jupyter.

higlass.api
**************

.. automodule:: higlass.api
 :members:

