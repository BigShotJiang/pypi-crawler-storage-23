from upplib.index import *


# 使用 sqlparse 库格式化 SQL 代码
def format_json(data_code=None):
    if data_code is None:
        return None
    # 去除字符串首尾的多余空白字符
    data_code = data_code.strip()
    if len(data_code) == 0:
        return None
    # 去除 开头结尾非 json 的部分
    while not data_code.startswith('{') and not data_code.startswith('[') and len(data_code):
        data_code = data_code[1:]
        data_code = data_code.strip()
    while not data_code.endswith('}') and not data_code.endswith(']') and len(data_code):
        data_code = data_code[:-1]
        data_code = data_code.strip()
    try:
        # 尝试解析 json
        parsed_json = json.loads(data_code)
    except json.JSONDecodeError as e:
        try:
            # 尝试将 ' 替换成 "
            # 尝试将 True 替换成 true
            # 尝试将 False 替换成 false
            data_code = re.sub(r"'", r'"', data_code).replace('True', 'true').replace('False', 'false').strip()
            parsed_json = json.loads(data_code)
        except json.JSONDecodeError as e:
            try:
                # 尝试将 \" 替换成 "
                data_code = data_code.replace(r'\"', '"').strip()
                parsed_json = json.loads(data_code)
            except json.JSONDecodeError as e:
                try:
                    # 尝试将 \' 替换成 "
                    data_code = data_code.replace(r"\'", '"').strip()
                    parsed_json = json.loads(data_code)
                except json.JSONDecodeError as e:
                    return None
    if parsed_json is None:
        return None
    # 缩进格式化
    pretty_result = json.dumps(parsed_json, indent=4, ensure_ascii=False)
    # 判断格式化后的 JSON 是否等价于原始 JSON（忽略空格）
    if pretty_result.strip() == data_code.strip():
        # 原始就是格式化的，返回紧凑格式
        result = json.dumps(parsed_json, separators=(',', ':'), ensure_ascii=False)
    else:
        result = pretty_result
    return result


def format_sql(data_code=None):
    if not data_code: return None
    return sqlparse.format(data_code, reindent=True, keyword_case='upper')


def extract_all_sql(log_content):
    preparing_pattern = re.compile(r"Preparing:\s*(.*)")
    parameters_pattern = re.compile(r"Parameters:\s*(.*)")
    total_pattern = re.compile(r"Total:\s*(\d+)")
    columns_pattern = re.compile(r"Columns:\s*(.*)")
    row_pattern = re.compile(r"Row:\s*(.*)")

    lines = log_content.splitlines()
    all_results = []

    current_sql, current_params, current_total = None, None, None
    current_columns, current_rows_output = [], []

    def build_output():
        if not current_sql and not current_rows_output: return None
        res_parts = []
        insert_param_mappings = []

        # 1. 处理 SQL 还原
        if current_sql:
            final_sql = current_sql
            is_insert = current_sql.strip().upper().startswith("INSERT")

            # 如果是 INSERT，提取字段名用于展示
            col_names = []
            if is_insert:
                match = re.search(r"INSERT\s+INTO\s+\w+\s*\((.*?)\)", current_sql, re.IGNORECASE)
                if match: col_names = [c.strip() for c in match.group(1).split(",")]

            if current_params:
                # 强大的参数切分逻辑（处理 JSON 中的逗号）
                params_items = []
                temp_item, bracket_stack = "", 0
                for char in current_params:
                    if char in '([{':
                        bracket_stack += 1
                    elif char in ')]}':
                        bracket_stack -= 1
                    if char == ',' and bracket_stack == 0:
                        params_items.append(temp_item.strip());
                        temp_item = ""
                    else:
                        temp_item += char
                if temp_item: params_items.append(temp_item.strip())

                for idx, item in enumerate(params_items):
                    type_match = re.search(r'\(\w+\)$', item)
                    val = item[:type_match.start()].strip() if type_match else item.strip()

                    # 值格式化
                    if val.lower() == "null":
                        replacement = "NULL"
                    elif val.lower() in ["true", "false"]:
                        replacement = f"'{val.lower()}'"
                    elif re.match(r'^-?\d+(\.\d+)?$', val):
                        replacement = val
                    else:
                        replacement = f"'{val.replace("'", "''")}'"

                    final_sql = final_sql.replace("?", replacement, 1)

                    # 仅 INSERT 记录映射关系
                    if is_insert and idx < len(col_names):
                        insert_param_mappings.append(f"{col_names[idx]} = {replacement}")

            res_parts.append(format_sql(final_sql))

            # 只有 INSERT 输出这个详细列表
            if is_insert and insert_param_mappings:
                res_parts.append("============INSERT_DATA_start============")
                res_parts.extend(insert_param_mappings)
                res_parts.append("============INSERT_DATA___end============")

        # 2. 处理 SELECT 结果数据 (Result Data)
        if current_rows_output:
            res_parts.append("============SELECT_DATA_start============")
            for i, row in enumerate(current_rows_output):
                if len(current_rows_output) > 1:
                    res_parts.append(f"Row {i + 1}:")
                res_parts.extend([f"{kv}" for kv in row])
                if i < len(current_rows_output) - 1:
                    res_parts.append("----------------------------------------")
            res_parts.append("============SELECT_DATA___end============")

        if current_total is not None:
            res_parts.append(f"Total: {current_total}")

        return "\n".join(res_parts)

    for line in lines:
        if "Preparing:" in line:
            if current_sql or current_rows_output: all_results.append(build_output())
            m = preparing_pattern.search(line)
            current_sql = m.group(1).strip() if m else None
            current_params, current_total, current_columns, current_rows_output = None, None, [], []
        elif "Parameters:" in line:
            m = parameters_pattern.search(line)
            if m: current_params = m.group(1).strip()
        elif "Columns:" in line:
            m = columns_pattern.search(line)
            if m: current_columns = [c.strip() for c in m.group(1).split(",")]
        elif "Row:" in line and current_columns:
            m = row_pattern.search(line)
            if m:
                vals = [v.strip() for v in m.group(1).split(",")]
                row_kv = [f"{c} = {v}" for c, v in zip(current_columns, vals)]
                current_rows_output.append(row_kv)
        elif "Total:" in line:
            m = total_pattern.search(line)
            if m: current_total = m.group(1).strip()

    if current_sql or current_rows_output: all_results.append(build_output())
    all_results = "\n\n".join(filter(None, all_results))
    if not all_results:
        return None
    return all_results

# # 测试输出
# log = '''
# ==>  Preparing: INSERT INTO credit_apply_letter ( user_id, requester, credit_apply_no, seq_id, apply_time, status, app_line, deleted ) VALUES ( ?, ?, ?, ?, ?, ?, ?, ? )
# ==> Parameters: 1162123669614335312(Long), trade(String), 1162873570904262396(String), 1156947856065503112(String), 2026-01-20T19:00:37.046(LocalDateTime), NO_CREDIT(String), (String), false(Boolean)
# <==    Updates: 1
# ==>  Preparing: UPDATE delay_task SET strategy_name = ?, request_data = ?, status = ?, task_type = ?, rpc_context = ?, biz_type = ?, execute_cnt = ?, create_time = ?, modify_time = ?, biz_flow_number = ?, seq_id = ?, request_id = ?, decision_id = ? WHERE id = ?
# ==> Parameters: apply(String), {"strategyName":"apply","user_id":1162123669614335312,"gaid":"2cc1b43f-5862-416a-bf1b-75b4167cdcf6","credit_apply_no":"1162873570904262396","customer_id":1162123669614336225,"decisionStage":"apply"}(String), processing(String), SYSTEM(String), {"requester":"trade","seq_id":"1156947856065503112","biz_type":"APPLY","report_id":"90986cb0fae94e75b177181f022cfdd9","user_channel":"Null_GP","header":{"tpCode":"rcs-provider","requestId":"1156947856065503112","scene":"APPLY"},"input_data":{"engineCode":"jcl_20240927000001","organId":"11","fields":{"biz_flow_number":"1162873570904262396","user_channel":"Null_GP","user_id":1162123669614335312,"gaid":"2cc1b43f-5862-416a-bf1b-75b4167cdcf6","biz_type":"APPLY","seq_id":"1156947856065503112","credit_apply_no":"1162873570904262396","customer_id":1162123669614336225,"loan_apply_no":"-1"}}}(String), APPLY(String), 1(Integer), 2026-01-20T19:00:37(LocalDateTime), 2026-01-20T19:00:37.069(LocalDateTime), 1162873570904262396(String), 1156947856065503112(String), 1156947856065503112(String), 20260120190037058APPLY03566(String), 1117889(Long)
# ==>  Preparing: SELECT * FROM rcs_strategy_report WHERE seq_id = ?
# ==> Parameters: 1156947856065503112(String)
# <==    Columns: id, seq_id, requester, strategy_name, biz_type, status, header, input_data, mid_result, result, is_deleted, duration, created_time, updated_time, version, user_id
# <==        Row: 6495974, 1156947856065503112, trade, apply, APPLY, PROCESSING, <<BLOB>>, <<BLOB>>, <<BLOB>>, <<BLOB>>, N, null, 2026-01-20 19:00:37, 2026-01-20 19:00:37, 1, 1162123669614335312
# <==        Row: 6495974, 1156947856065503112, trade, apply, APPLY, PROCESSING, <<BLOB>>, <<BLOB>>, <<BLOB>>, <<BLOB>>, N, null, 2026-01-20 19:00:37, 2026-01-20 19:00:37, 1, 1162123669614335312
# <==      Total: 2
#
# '''
# log = '''
#
# {"strategyName":"apply","user_id":980365936454085953,"gaid":"b37e2bf1-2579-48ad-8058-4299f392e192","credit_apply_no":"1162873570904261771","customer_id":1162137121451927630,"decisionStage":"apply"}
#
#
# '''
# b = extract_all_sql('select * from review.audit_user order by id desc limit 10;')
# print(b)
