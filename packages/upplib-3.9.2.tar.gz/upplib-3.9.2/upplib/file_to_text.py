from upplib import *
from upplib.common_package import *


def _check_line_is_startswith_or_endswith_or_contain(
        line: str = '',
        check_flag_msg: list[str] | set[str] | str = None,
        check_type: int = 0
) -> bool:
    if not check_flag_msg:
        return False
    # 统一转为元组，因为 startswith/endswith 直接支持元组加速
    flags = (check_flag_msg,) if isinstance(check_flag_msg, str) else tuple(check_flag_msg)
    if check_type == 1:  # startswith
        return line.startswith(flags)
    elif check_type == 2:  # endswith
        return line.endswith(flags)
    elif check_type == 3:  # contain
        return any(f in line for f in flags)
    return False


def to_list_from_file(
        file_name: str = 'a.txt',
        line_ignore_startswith=None,
        line_ignore_endswith=None,
        line_ignore_contain=None,
        line_ignore_empty=None,
        line_must_startswith=None,
        line_must_endswith=None,
        line_must_contain=None,
        start_index=None,
        end_index=None,
        count=None,
        start_line=None,
        end_line=None,
        line_is_json=False
) -> list:
    """
    :param file_name                : 文件名称
    :param line_ignore_startswith   : 行忽略, 以什么开头. 忽略以这个为开头的行
    :param line_ignore_endswith     : 行忽略, 以什么结尾. 忽略以这个为结尾的行
    :param line_ignore_contain      : 行忽略, 包含什么. 忽略包含这个的行
    :param line_ignore_empty        : 行忽略, 是否忽略空行. 如果这一行为空，就忽略这行
    :param line_must_startswith     : 行必须以什么开头. 这一行必须以这个字符串为开始
    :param line_must_endswith       : 行必须以什么结尾. 这一行必须以这个字符串为结尾
    :param line_must_contain        : 行必须包含什么. 这一行必须包含这个字符串
    :param start_index              : 开始索引. 从这个地方开始读取,从1开始标号 , 包含这一行
    :param start_line               : 开始行. 从这个地方开始读取,从第一行开始找到这个字符串开始标记 , 包含这一行
    :param end_index                : 结束索引. 读取到这个地方结束,从1开始标号 , 不包含这一行
    :param end_line                 : 结束行. 读取到这个地方结束,从第一行开始找到这个字符串开始标记 , 不包含这一行
    :param count                    : 数量. 读取指定的行数
    :param line_is_json             : 是否是 json 格式. 如果是 json 格式, 就将这一行, 解析为 json 格式
    :return:
    """
    if not os.path.exists(file_name) or os.path.getsize(file_name) == 0:
        return []
    result_list = []
    in_range = (start_line is None)  # 如果没有指定开始行，默认就在范围内
    found_count = 0
    with open(file_name, 'r', encoding='utf-8') as f:
        for i, line in enumerate(f, 1):
            line = line.strip()

            # 1. 索引过滤 (Index based)
            if start_index and i < int(start_index): continue
            if end_index and i >= int(end_index): break

            # 2. 数量过滤 (Count based)
            if count and found_count >= int(count): break

            # 3. 标记位逻辑 (Line content based range)
            if not in_range:
                if start_line and start_line in line:
                    in_range = True
                else:
                    continue

            if end_line and end_line in line:
                in_range = False  # 结束读取
                break

            # 4. 文本过滤逻辑
            if line_ignore_empty and not line: continue
            if line_ignore_startswith and _check_line_is_startswith_or_endswith_or_contain(line, line_ignore_startswith, 1): continue
            if line_ignore_endswith and _check_line_is_startswith_or_endswith_or_contain(line, line_ignore_endswith, 2): continue
            if line_ignore_contain and _check_line_is_startswith_or_endswith_or_contain(line, line_ignore_contain, 3): continue

            if line_must_startswith and not _check_line_is_startswith_or_endswith_or_contain(line, line_must_startswith, 1): continue
            if line_must_endswith and not _check_line_is_startswith_or_endswith_or_contain(line, line_must_endswith, 2): continue
            if line_must_contain and not _check_line_is_startswith_or_endswith_or_contain(line, line_must_contain, 3): continue

            # 5. 普通行添加
            val = json.loads(line) if line_is_json and line else line
            result_list.append(val)
            found_count += 1

    return result_list


def to_list_json_from_file(
        file_name: str = 'a.txt',
        line_ignore_startswith=None,
        line_ignore_endswith=None,
        line_ignore_contain=None,
        line_ignore_empty=None,
        line_must_startswith=None,
        line_must_endswith=None,
        line_must_contain=None,
        start_index=None,
        end_index=None,
        count=None,
        start_line=None,
        end_line=None,
        line_is_json=True
) -> list:
    """
    将一个文件中的数据按照行来区分,
    会自动过滤掉空格行,
    组成一个 list[json] 数据
    可以将以下文本转 list[json]
    {"accessKey":"1","signature":"4","timestamp":"1747639787"}
    {"accessKey":"2","signature":"5","timestamp":"1747639787"}
    {"accessKey":"3","signature":"6","timestamp":"1747639787"}
    """
    return to_list_from_file(file_name=file_name,
                             line_ignore_startswith=line_ignore_startswith,
                             line_ignore_endswith=line_ignore_endswith,
                             line_ignore_contain=line_ignore_contain,
                             line_ignore_empty=line_ignore_empty,
                             line_must_startswith=line_must_startswith,
                             line_must_endswith=line_must_endswith,
                             line_must_contain=line_must_contain,
                             start_index=start_index,
                             end_index=end_index,
                             count=count,
                             start_line=start_line,
                             end_line=end_line,
                             line_is_json=line_is_json)


def to_str_from_file(
        file_name: str = 'a.txt',
        line_ignore_startswith=None,
        line_ignore_endswith=None,
        line_ignore_contain=None,
        line_ignore_empty=None,
        line_must_startswith=None,
        line_must_endswith=None,
        line_must_contain=None,
        start_index=None,
        end_index=None,
        count=None,
        start_line=None,
        end_line=None
) -> str:
    """
    读取文件中的数据,返回一个 str
    """
    return ''.join(to_list_from_file(file_name=file_name,
                                     line_ignore_startswith=line_ignore_startswith,
                                     line_ignore_endswith=line_ignore_endswith,
                                     line_ignore_contain=line_ignore_contain,
                                     line_ignore_empty=line_ignore_empty,
                                     line_must_startswith=line_must_startswith,
                                     line_must_endswith=line_must_endswith,
                                     line_must_contain=line_must_contain,
                                     start_index=start_index,
                                     end_index=end_index,
                                     count=count,
                                     start_line=start_line,
                                     end_line=end_line,
                                     line_is_json=False))


# 读取文件中的数据,返回一个 json
def to_json_from_file(
        file_name: str = 'a.txt',
        line_ignore_startswith=None,
        line_ignore_endswith=None,
        line_ignore_contain=None,
        line_ignore_empty=None,
        line_must_startswith=None,
        line_must_endswith=None,
        line_must_contain=None,
        start_index=None,
        end_index=None,
        count=None,
        start_line=None,
        end_line=None
) -> dict[str, Any]:
    if line_ignore_startswith is None:
        line_ignore_startswith = ['//', '/*', '#']
    return json.loads(to_str_from_file(file_name=file_name,
                                       line_ignore_startswith=line_ignore_startswith,
                                       line_ignore_endswith=line_ignore_endswith,
                                       line_ignore_contain=line_ignore_contain,
                                       line_ignore_empty=line_ignore_empty,
                                       line_must_startswith=line_must_startswith,
                                       line_must_endswith=line_must_endswith,
                                       line_must_contain=line_must_contain,
                                       start_index=start_index,
                                       end_index=end_index,
                                       count=count,
                                       start_line=start_line,
                                       end_line=end_line))


def to_list_from_file_with_ignore_line(
        file_name: str = 'a.txt',
        line_ignore_startswith=None,
        line_ignore_endswith=None,
        line_ignore_contain=None,
        line_ignore_empty=True,
        line_must_startswith=None,
        line_must_endswith=None,
        line_must_contain=None,
        start_index=None,
        end_index=None,
        count=None,
        start_line=None,
        end_line=None,
        line_is_json=False
) -> list:
    return to_list_from_file(
        file_name=file_name,
        line_ignore_startswith=line_ignore_startswith,
        line_ignore_endswith=line_ignore_endswith,
        line_ignore_contain=line_ignore_contain,
        line_ignore_empty=line_ignore_empty,
        line_must_startswith=line_must_startswith,
        line_must_endswith=line_must_endswith,
        line_must_contain=line_must_contain,
        start_index=start_index,
        end_index=end_index,
        count=count,
        start_line=start_line,
        end_line=end_line,
        line_is_json=line_is_json
    )
