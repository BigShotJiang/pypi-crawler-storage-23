"""
Valiqor Eval - Quality Evaluation Module

Evaluate LLM outputs with heuristic and LLM-based metrics.

Usage:
    from valiqor.eval import ValiqorEvalClient

    client = ValiqorEvalClient(api_key="vq_xxx", project_name="my-app")
    result = client.evaluate(
        dataset=[
            {"input": "What is 2+2?", "output": "4", "expected": "4"}
        ],
        metrics=["factual_accuracy", "coherence"]
    )

Or via unified client:
    from valiqor import ValiqorClient

    client = ValiqorClient(api_key="vq_xxx")
    client.eval.evaluate(...)
"""

from typing import TYPE_CHECKING

# =============================================================================
# MODELS (always available - plain Python dataclasses)
# =============================================================================
from valiqor.eval.models import (
    AuthInfo,
    CancelResponse,
    EvalItemDetail,
    EvalItemsPage,
    EvalRunComparison,
    EvalTrendPoint,
    EvaluationItem,
    EvaluationResult,
    JobStatus,
    MetricInfo,
    ProjectInfo,
    RunMetric,
)

# =============================================================================
# COMPILED CLIENT LOADER
# =============================================================================
# The client module is compiled for distribution:
# - client.py -> _client_impl.so/.pyd


def _load_eval_client():
    """Load the eval client (compiled or source)."""
    try:
        # Try compiled extension first (PyPI distribution)
        from valiqor.eval import _client_impl

        return _client_impl.ValiqorEvalClient, getattr(_client_impl, "JobHandle", None)
    except ImportError:
        try:
            # Fallback to source (development mode)
            from valiqor.eval.client import JobHandle, ValiqorEvalClient

            return ValiqorEvalClient, JobHandle
        except ImportError as e:
            raise ImportError(
                "Eval client not available. Install valiqor[eval] from PyPI or "
                "ensure you're in the development environment.\n"
                f"Original error: {e}"
            ) from None


# Load the client class
ValiqorEvalClient, JobHandle = _load_eval_client()

# =============================================================================
# PUBLIC API
# =============================================================================
__all__ = [
    "ValiqorEvalClient",
    "JobHandle",
    "EvaluationResult",
    "EvaluationItem",
    "JobStatus",
    "AuthInfo",
    "ProjectInfo",
    "MetricInfo",
    "RunMetric",
    "EvalItemDetail",
    "EvalItemsPage",
    "EvalTrendPoint",
    "EvalRunComparison",
    "CancelResponse",
]
