# autolog.py - Minimal Integration API for Valiqor Tracing (Competitor-Inspired)

import functools
import inspect
import json
import threading
import time
import uuid
from typing import Any, Callable, Dict, List, Optional

from .rag_extensions import DocumentHit, RetrievalInfo, create_document_hit
from .tracer import TracerV2, ValiqorSpanKind, ValiqorStage

# Global state for autolog configuration
_global_config = {
    "enabled": False,
    "tracer": None,
    "exporters": [],  # No console output by default
    "app_info": {"name": "valiqor-app", "version": "1.0.0"},
    "auto_trace": True,  # Automatically create traces
    "auto_export": True,  # Automatically export traces
    # RAG instrumentation configuration
    "rag_instrumentation": False,
    "custom_retriever_patterns": {
        "name_indicators": [],  # Additional tool name patterns
        "class_patterns": [],  # Additional class name patterns
        "module_patterns": [],  # Additional module name patterns
    },
    # Eval steps generation configuration
    "eval_steps_enabled": True,  # Generate eval_steps.json by default
    "eval_steps_output_dir": None,  # Custom output dir (defaults to trace_dir)
    "eval_steps_callback": None,  # Optional callback for custom post-processing
    "debug": False,  # Debug logging flag
}

# Thread-local storage for auto-managed traces
_thread_local = threading.local()

# Global cache for tool retrievals (bridges thread context issues)
_tool_retrievals_cache = {}

# 🔥 CRITICAL FIX: Global dict to store current workflow node span across threads
# This is needed because LangGraph may execute tools in different threads
# and thread-local storage doesn't work across those boundaries
# Using a regular dict instead of threading.local() so it works across threads
_current_workflow_span = {}


class _TraceContext:
    """Thread-local context for preventing re-entry and tracking active operations.
    
    This provides a guard against duplicate tracing when nested calls occur,
    e.g., when invoke() internally calls _run() for tools.
    """
    
    _local = threading.local()
    
    @classmethod
    def _get_active_operations(cls) -> set:
        """Get the set of currently active operations for this thread."""
        if not hasattr(cls._local, 'active_operations'):
            cls._local.active_operations = set()
        return cls._local.active_operations
    
    @classmethod
    def _get_traced_tools(cls) -> set:
        """Get the set of tool calls that have already been traced via _trace_tool_call."""
        if not hasattr(cls._local, 'traced_tools'):
            cls._local.traced_tools = set()
        return cls._local.traced_tools
    
    @classmethod
    def is_operation_active(cls, operation_key: str) -> bool:
        """Check if an operation is currently active (prevents re-entry)."""
        return operation_key in cls._get_active_operations()
    
    @classmethod
    def start_operation(cls, operation_key: str) -> bool:
        """Start an operation if not already active. Returns True if started."""
        ops = cls._get_active_operations()
        if operation_key in ops:
            return False  # Already active - prevent re-entry
        ops.add(operation_key)
        return True
    
    @classmethod
    def end_operation(cls, operation_key: str):
        """End an operation, allowing it to be started again."""
        ops = cls._get_active_operations()
        ops.discard(operation_key)
    
    @classmethod
    def mark_tool_traced(cls, tool_name: str, args_hash: int):
        """Mark a tool as already traced to prevent duplicate tracing from ToolNode."""
        tools = cls._get_traced_tools()
        tools.add(f"{tool_name}:{args_hash}")
    
    @classmethod
    def is_tool_traced(cls, tool_name: str, args_hash: int) -> bool:
        """Check if a tool was already traced."""
        return f"{tool_name}:{args_hash}" in cls._get_traced_tools()
    
    @classmethod
    def clear_traced_tools(cls):
        """Clear traced tools (call at end of workflow)."""
        if hasattr(cls._local, 'traced_tools'):
            cls._local.traced_tools.clear()
    
    @classmethod
    def clear_all(cls):
        """Clear all active operations for this thread."""
        if hasattr(cls._local, 'active_operations'):
            cls._local.active_operations.clear()
        if hasattr(cls._local, 'traced_tools'):
            cls._local.traced_tools.clear()


def _debug_print(message: str):
    """Print debug message only if debug mode is enabled."""
    if _global_config.get("debug", False):
        print(message)


class AutoInstrumentor:
    """Base class for auto-instrumentors following OpenTelemetry pattern"""

    def __init__(self):
        self.is_instrumented = False
        self.original_functions = {}

    def instrument(self, **kwargs):
        """Instrument the target library for automatic tracing"""
        if self.is_instrumented:
            return

        self._patch_target_functions()
        self.is_instrumented = True
        _debug_print(f"[AUTOLOG] Valiqor autolog enabled for {self.__class__.__name__}")

    def uninstrument(self):
        """Remove instrumentation"""
        if not self.is_instrumented:
            return

        self._restore_original_functions()
        self.is_instrumented = False

    def _patch_target_functions(self):
        """Override in subclass to patch specific functions"""
        raise NotImplementedError

    def _restore_original_functions(self):
        """Restore original functions"""
        for target, original_func in self.original_functions.items():
            setattr(target[0], target[1], original_func)
        self.original_functions.clear()


class OpenAIInstrumentor(AutoInstrumentor):
    """OpenAI auto-instrumentor following competitor patterns"""

    def _patch_target_functions(self):
        try:
            import openai
            from openai.resources.chat.completions import Completions

            # Patch OpenAI chat completions by patching the Completions class
            original_create = Completions.create

            def traced_create(self, *args, **kwargs):
                return instrumentor._trace_openai_call(original_create, self, *args, **kwargs)

            # Store reference to this instrumentor for the closure
            instrumentor = self

            # Store original and patch
            self.original_functions[(Completions, "create")] = original_create
            Completions.create = traced_create

            # Also patch async version if available
            if hasattr(openai, "AsyncOpenAI"):
                from openai.resources.chat.completions import AsyncCompletions

                original_async_create = AsyncCompletions.create

                async def traced_async_create(self, *args, **kwargs):
                    return await instrumentor._trace_openai_async_call(
                        original_async_create, self, *args, **kwargs
                    )

                self.original_functions[(AsyncCompletions, "create")] = original_async_create
                AsyncCompletions.create = traced_async_create

        except ImportError:
            _debug_print("⚠️  OpenAI package not found - install with: pip install openai")
        except Exception as e:
            _debug_print(f"⚠️  Could not instrument OpenAI: {e}")

    def _add_openai_user_message(self, tracer, messages, span=None):
        """
        Extract and add user message from OpenAI messages array to the trace.
        This ensures user input is recorded in the conversation flow.
        """
        try:
            if not messages:
                return

            # Find the last user message in the messages array
            user_content = None
            for msg in reversed(messages):
                if isinstance(msg, dict) and msg.get("role") == "user":
                    user_content = msg.get("content", "")
                    break

            if user_content:
                human_message = {
                    "type": "human",
                    "id": f"human-{str(uuid.uuid4())}",
                    "content": str(user_content),
                    "name": None,
                    "example": False,
                    "additional_kwargs": {},
                    "response_metadata": {
                        "timestamp": _get_current_timestamp(),
                        "source": "user_input",
                        "llm.vendor": "openai",
                        "request_id": f"req_{str(uuid.uuid4())[:8]}",
                        "endpoint_url": "https://api.openai.com/v1/chat/completions",
                    },
                    "tool_calls": [],
                    "invalid_tool_calls": [],
                }
                tracer.add_message(human_message, span_id=getattr(span, "span_id", None) if span else None)
                _debug_print(f"[Autolog] Added OpenAI user message: {str(user_content)[:100]}...")
        except Exception as e:
            _debug_print(f"[Autolog] Failed to extract OpenAI user message: {e}")

    def _trace_openai_call(self, original_func, client_instance, *args, **kwargs):
        """Trace synchronous OpenAI API call"""
        tracer = _ensure_tracer()

        # Extract call parameters
        call_kwargs = kwargs.copy()

        # OpenAI calls auto-create traces when no active trace exists
        # This allows standalone usage without @trace_workflow decorators
        trace_started = _ensure_auto_trace(
            "openai_chat", {"model": call_kwargs.get("model", "gpt-4o")}, is_workflow_entry=True
        )

        try:
            # Create span for this LLM call
            with _auto_span(
                "llm_call_openai",
                {
                    "llm.provider": "openai",
                    "llm.model": call_kwargs.get("model", "gpt-4o"),
                    "llm.messages": str(call_kwargs.get("messages", []))[:200] + "...",
                },
                stage=ValiqorStage.LLM_CALL,
                span_kind=ValiqorSpanKind.LLM_CALL,
            ) as span:

                # Add user message to trace BEFORE making the API call
                if tracer:
                    self._add_openai_user_message(tracer, call_kwargs.get("messages", []), span)

                # Make the actual API call
                result = original_func(client_instance, *args, **kwargs)

                # Extract response metadata directly from result (standard OpenAI response)
                prompt_tokens = 0
                completion_tokens = 0
                total_tokens = 0
                cost = 0.0

                if hasattr(result, "usage") and result.usage:
                    prompt_tokens = getattr(result.usage, "prompt_tokens", 0)
                    completion_tokens = getattr(result.usage, "completion_tokens", 0)
                    total_tokens = getattr(result.usage, "total_tokens", 0)

                    span.set_attribute("llm.input_tokens", prompt_tokens)
                    span.set_attribute("llm.output_tokens", completion_tokens)
                    span.set_attribute("llm.total_tokens", total_tokens)

                    # Calculate cost
                    if tracer:
                        cost = tracer.calculate_cost(
                            call_kwargs.get("model", "gpt-4o"), prompt_tokens, completion_tokens
                        )
                        span.set_attribute("llm.cost_usd", cost)

                if hasattr(result, "model") and result.model:
                    span.set_attribute("llm.response_model", result.model)

                # Safely extract finish_reason and response ID
                finish_reason = "unknown"
                response_id = "unknown"

                try:
                    if hasattr(result, "choices") and result.choices:
                        finish_reason = getattr(result.choices[0], "finish_reason", "unknown")
                    if hasattr(result, "id"):
                        response_id = result.id
                except (AttributeError, IndexError):
                    pass

                span.add_event(
                    "llm_response_received",
                    {"response_id": response_id, "finish_reason": finish_reason},
                )

                # Add the AI message to the trace for conversation tracking
                if tracer and hasattr(result, "choices") and result.choices:
                    try:
                        choice = result.choices[0]

                        # Create comprehensive AI message like manual tracing
                        ai_message = {
                            "type": "ai",
                            "id": str(uuid.uuid4()),
                            "content": (
                                getattr(choice.message, "content", "")
                                if hasattr(choice, "message")
                                else ""
                            ),
                            "additional_kwargs": {},
                            "response_metadata": {
                                "model_name": call_kwargs.get("model", "gpt-4o"),
                                "finish_reason": finish_reason,
                                "token_usage": {
                                    "prompt_tokens": prompt_tokens,
                                    "completion_tokens": completion_tokens,
                                    "total_tokens": total_tokens,
                                },
                                "system_fingerprint": getattr(result, "system_fingerprint", ""),
                                "id": getattr(result, "id", ""),
                                "llm.vendor": "openai",
                                "endpoint_url": "https://api.openai.com/v1/chat/completions",
                                "cost_usd": cost,
                            },
                            "cost_breakdown": {
                                "prompt_cost": (
                                    cost * (prompt_tokens / (prompt_tokens + completion_tokens))
                                    if total_tokens > 0
                                    else 0
                                ),
                                "completion_cost": (
                                    cost * (completion_tokens / (prompt_tokens + completion_tokens))
                                    if total_tokens > 0
                                    else 0
                                ),
                                "total_cost": cost,
                                "model": call_kwargs.get("model", "gpt-4o"),
                            },
                            "usage_metadata": {
                                "input_tokens": prompt_tokens,
                                "output_tokens": completion_tokens,
                                "total_tokens": total_tokens,
                                "input_token_details": {"audio": 0, "cache_read": 0},
                                "output_token_details": {"audio": 0, "reasoning": 0},
                            },
                            "tool_calls": [],
                            "invalid_tool_calls": [],
                            "span_id": getattr(span, "span_id", None),
                        }

                        # Extract tool calls if present
                        if (
                            hasattr(choice, "message")
                            and hasattr(choice.message, "tool_calls")
                            and choice.message.tool_calls
                        ):
                            for tool_call in choice.message.tool_calls:
                                # Get arguments - OpenAI returns JSON string, parse it
                                raw_args = (
                                    getattr(tool_call.function, "arguments", "{}")
                                    if hasattr(tool_call, "function")
                                    else "{}"
                                )
                                # Parse JSON string to dict
                                try:
                                    import json
                                    parsed_args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
                                except (json.JSONDecodeError, TypeError):
                                    parsed_args = {"raw": raw_args} if raw_args else {}
                                
                                tool_call_info = {
                                    "id": getattr(tool_call, "id", ""),
                                    "name": (
                                        getattr(tool_call.function, "name", "")
                                        if hasattr(tool_call, "function")
                                        else ""
                                    ),
                                    "args": parsed_args,
                                    "type": "tool_call",
                                }
                                ai_message["tool_calls"].append(tool_call_info)

                        # Add message with proper timestamp
                        import time

                        ai_message["timestamp"] = time.time()

                        tracer.add_message(ai_message, span_id=getattr(span, "span_id", None))
                    except Exception as e:
                        # If we can't extract the message, just log for debugging
                        span.add_event("message_extraction_error", {"error": str(e)})

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("llm_error", {"error": str(e)})
                span.set_attribute("error", True)
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    async def _trace_openai_async_call(self, original_func, client_instance, *args, **kwargs):
        """Trace asynchronous OpenAI API call"""
        # Similar implementation for async calls
        tracer = _ensure_tracer()
        call_kwargs = kwargs.copy()

        trace_started = _ensure_auto_trace(
            "openai_chat_async",
            {"model": call_kwargs.get("model", "gpt-4o")},
            is_workflow_entry=True,
        )

        try:
            with _auto_span(
                "llm_call_openai_async",
                {
                    "llm.provider": "openai",
                    "llm.model": call_kwargs.get("model", "gpt-4o"),
                    "llm.async": True,
                },
                stage=ValiqorStage.LLM_CALL,
                span_kind=ValiqorSpanKind.LLM_CALL,
            ) as span:

                # Add user message to trace BEFORE making the API call
                if tracer:
                    self._add_openai_user_message(tracer, call_kwargs.get("messages", []), span)

                result = await original_func(client_instance, *args, **kwargs)

                # Handle both raw response and parsed response for async calls
                parsed_result = result
                if hasattr(result, "parsed"):
                    parsed_result = result.parsed
                elif hasattr(result, "content"):  # For LegacyAPIResponse
                    parsed_result = result.content

                # Extract response metadata
                prompt_tokens = 0
                completion_tokens = 0
                total_tokens = 0
                cost = 0.0

                if hasattr(parsed_result, "usage") and parsed_result.usage:
                    prompt_tokens = getattr(parsed_result.usage, "prompt_tokens", 0)
                    completion_tokens = getattr(parsed_result.usage, "completion_tokens", 0)
                    total_tokens = getattr(parsed_result.usage, "total_tokens", 0)

                    span.set_attribute("llm.input_tokens", prompt_tokens)
                    span.set_attribute("llm.output_tokens", completion_tokens)
                    span.set_attribute("llm.total_tokens", total_tokens)

                    # Calculate cost
                    if tracer:
                        cost = tracer.calculate_cost(
                            call_kwargs.get("model", "gpt-4o"), prompt_tokens, completion_tokens
                        )
                        span.set_attribute("llm.cost_usd", cost)

                # Add AI message to trace
                if tracer and hasattr(parsed_result, "choices") and parsed_result.choices:
                    try:
                        choice = parsed_result.choices[0]
                        finish_reason = getattr(choice, "finish_reason", "unknown")

                        ai_message = {
                            "type": "ai",
                            "id": str(uuid.uuid4()),
                            "content": (
                                getattr(choice.message, "content", "")
                                if hasattr(choice, "message")
                                else ""
                            ),
                            "additional_kwargs": {},
                            "response_metadata": {
                                "model_name": call_kwargs.get("model", "gpt-4o"),
                                "finish_reason": finish_reason,
                                "token_usage": {
                                    "prompt_tokens": prompt_tokens,
                                    "completion_tokens": completion_tokens,
                                    "total_tokens": total_tokens,
                                },
                                "llm.vendor": "openai",
                                "endpoint_url": "https://api.openai.com/v1/chat/completions",
                                "cost_usd": cost,
                            },
                            "usage_metadata": {
                                "input_tokens": prompt_tokens,
                                "output_tokens": completion_tokens,
                                "total_tokens": total_tokens,
                            },
                            "tool_calls": [],
                            "invalid_tool_calls": [],
                            "span_id": getattr(span, "span_id", None),
                            "timestamp": _get_current_timestamp(),
                        }
                        
                        # Extract tool calls if present (async version)
                        if (
                            hasattr(choice, "message")
                            and hasattr(choice.message, "tool_calls")
                            and choice.message.tool_calls
                        ):
                            for tool_call in choice.message.tool_calls:
                                # Get arguments - OpenAI returns JSON string, parse it
                                raw_args = (
                                    getattr(tool_call.function, "arguments", "{}")
                                    if hasattr(tool_call, "function")
                                    else "{}"
                                )
                                # Parse JSON string to dict
                                try:
                                    import json
                                    parsed_args = json.loads(raw_args) if isinstance(raw_args, str) else raw_args
                                except (json.JSONDecodeError, TypeError):
                                    parsed_args = {"raw": raw_args} if raw_args else {}
                                
                                tool_call_info = {
                                    "id": getattr(tool_call, "id", ""),
                                    "name": (
                                        getattr(tool_call.function, "name", "")
                                        if hasattr(tool_call, "function")
                                        else ""
                                    ),
                                    "args": parsed_args,
                                    "type": "tool_call",
                                }
                                ai_message["tool_calls"].append(tool_call_info)
                        
                        tracer.add_message(ai_message, span_id=getattr(span, "span_id", None))
                    except Exception as e:
                        span.add_event("message_extraction_error", {"error": str(e)})

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("llm_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})


class AnthropicInstrumentor(AutoInstrumentor):
    """Anthropic auto-instrumentor"""

    def _patch_target_functions(self):
        try:
            import anthropic
            from anthropic.resources.messages import Messages

            # Patch Anthropic messages.create (sync)
            original_create = Messages.create

            def traced_create(self, *args, **kwargs):
                return instrumentor._trace_anthropic_call(original_create, self, *args, **kwargs)

            # Store reference to this instrumentor for the closure
            instrumentor = self

            self.original_functions[(Messages, "create")] = original_create
            Messages.create = traced_create

            # Patch Anthropic AsyncMessages.create (async)
            try:
                from anthropic.resources.messages import AsyncMessages
                
                original_async_create = AsyncMessages.create

                async def traced_async_create(self, *args, **kwargs):
                    return await instrumentor._trace_anthropic_async_call(original_async_create, self, *args, **kwargs)

                self.original_functions[(AsyncMessages, "create")] = original_async_create
                AsyncMessages.create = traced_async_create
                _debug_print("[DEBUG] Anthropic AsyncMessages.create patched for async tracing")
            except (ImportError, AttributeError) as e:
                _debug_print(f"[DEBUG] Anthropic async not available: {e}")

        except ImportError:
            _debug_print("⚠️  Anthropic package not found - install with: pip install anthropic")
        except Exception as e:
            _debug_print(f"⚠️  Could not instrument Anthropic: {e}")

    def _add_anthropic_user_message(self, tracer, messages, span=None):
        """
        Extract and add user message from Anthropic messages array to the trace.
        This ensures user input is recorded in the conversation flow.
        """
        try:
            if not messages:
                return

            # Find the last user message in the messages array
            user_content = None
            for msg in reversed(messages):
                if isinstance(msg, dict) and msg.get("role") == "user":
                    content = msg.get("content", "")
                    # Anthropic content can be a string or a list of content blocks
                    if isinstance(content, str):
                        user_content = content
                    elif isinstance(content, list):
                        # Extract text from content blocks
                        text_parts = []
                        for block in content:
                            if isinstance(block, dict) and block.get("type") == "text":
                                text_parts.append(block.get("text", ""))
                            elif isinstance(block, str):
                                text_parts.append(block)
                        user_content = " ".join(text_parts)
                    break

            if user_content:
                human_message = {
                    "type": "human",
                    "id": f"human-{str(uuid.uuid4())}",
                    "content": str(user_content),
                    "name": None,
                    "example": False,
                    "additional_kwargs": {},
                    "response_metadata": {
                        "timestamp": _get_current_timestamp(),
                        "source": "user_input",
                        "llm.vendor": "anthropic",
                        "request_id": f"req_{str(uuid.uuid4())[:8]}",
                        "endpoint_url": "https://api.anthropic.com/v1/messages",
                    },
                    "tool_calls": [],
                    "invalid_tool_calls": [],
                }
                tracer.add_message(human_message, span_id=getattr(span, "span_id", None) if span else None)
                _debug_print(f"[Autolog] Added Anthropic user message: {str(user_content)[:100]}...")
        except Exception as e:
            _debug_print(f"[Autolog] Failed to extract Anthropic user message: {e}")

    def _trace_anthropic_call(self, original_func, client_instance, *args, **kwargs):
        """Trace Anthropic API call"""
        tracer = _ensure_tracer()
        call_kwargs = kwargs.copy()

        trace_started = _ensure_auto_trace(
            "Anthropic API Call",
            {"model": call_kwargs.get("model", "claude-3-5-sonnet")},
            is_workflow_entry=True,
        )

        try:
            with _auto_span(
                "llm_call_anthropic",
                {
                    "llm.provider": "anthropic",
                    "llm.model": call_kwargs.get("model", "claude-3-5-sonnet"),
                    "llm.max_tokens": call_kwargs.get("max_tokens", 1024),
                },
                stage=ValiqorStage.LLM_CALL,
                span_kind=ValiqorSpanKind.LLM_CALL,
            ) as span:

                # Add user message to trace BEFORE making the API call
                if tracer:
                    self._add_anthropic_user_message(tracer, call_kwargs.get("messages", []), span)

                result = original_func(client_instance, *args, **kwargs)

                # Extract Anthropic response metadata
                prompt_tokens = 0
                completion_tokens = 0
                total_tokens = 0
                cost = 0.0

                if hasattr(result, "usage") and result.usage:
                    prompt_tokens = getattr(result.usage, "input_tokens", 0)
                    completion_tokens = getattr(result.usage, "output_tokens", 0)
                    total_tokens = prompt_tokens + completion_tokens

                    span.set_attribute("llm.input_tokens", prompt_tokens)
                    span.set_attribute("llm.output_tokens", completion_tokens)
                    span.set_attribute("llm.total_tokens", total_tokens)

                    # Calculate cost
                    if tracer:
                        cost = tracer.calculate_cost(
                            call_kwargs.get("model", "claude-3-5-sonnet"), prompt_tokens, completion_tokens
                        )
                        span.set_attribute("llm.cost_usd", cost)

                # Add AI message to trace
                if tracer and hasattr(result, "content") and result.content:
                    try:
                        # Extract content from Anthropic response
                        content_text = ""
                        if isinstance(result.content, list):
                            for block in result.content:
                                if hasattr(block, "text"):
                                    content_text += block.text
                                elif isinstance(block, dict) and block.get("type") == "text":
                                    content_text += block.get("text", "")
                        else:
                            content_text = str(result.content)

                        ai_message = {
                            "type": "ai",
                            "id": str(uuid.uuid4()),
                            "content": content_text,
                            "additional_kwargs": {},
                            "response_metadata": {
                                "model_name": call_kwargs.get("model", "claude-3-5-sonnet"),
                                "finish_reason": getattr(result, "stop_reason", "end_turn"),
                                "token_usage": {
                                    "prompt_tokens": prompt_tokens,
                                    "completion_tokens": completion_tokens,
                                    "total_tokens": total_tokens,
                                },
                                "llm.vendor": "anthropic",
                                "endpoint_url": "https://api.anthropic.com/v1/messages",
                                "cost_usd": cost,
                            },
                            "usage_metadata": {
                                "input_tokens": prompt_tokens,
                                "output_tokens": completion_tokens,
                                "total_tokens": total_tokens,
                            },
                            "tool_calls": [],
                            "invalid_tool_calls": [],
                            "span_id": getattr(span, "span_id", None),
                            "timestamp": _get_current_timestamp(),
                        }
                        tracer.add_message(ai_message, span_id=getattr(span, "span_id", None))
                    except Exception as e:
                        span.add_event("message_extraction_error", {"error": str(e)})

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("llm_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    async def _trace_anthropic_async_call(self, original_func, client_instance, *args, **kwargs):
        """Trace Anthropic async API call"""
        tracer = _ensure_tracer()
        call_kwargs = kwargs.copy()

        trace_started = _ensure_auto_trace(
            "Anthropic API Call (Async)",
            {"model": call_kwargs.get("model", "claude-3-5-sonnet")},
            is_workflow_entry=True,
        )

        try:
            with _auto_span(
                "llm_call_anthropic",
                {
                    "llm.provider": "anthropic",
                    "llm.model": call_kwargs.get("model", "claude-3-5-sonnet"),
                    "llm.max_tokens": call_kwargs.get("max_tokens", 1024),
                    "llm.async": True,
                },
                stage=ValiqorStage.LLM_CALL,
                span_kind=ValiqorSpanKind.LLM_CALL,
            ) as span:

                # Add user message to trace BEFORE making the API call
                if tracer:
                    self._add_anthropic_user_message(tracer, call_kwargs.get("messages", []), span)

                result = await original_func(client_instance, *args, **kwargs)

                # Extract Anthropic response metadata
                prompt_tokens = 0
                completion_tokens = 0
                total_tokens = 0
                cost = 0.0

                if hasattr(result, "usage") and result.usage:
                    prompt_tokens = getattr(result.usage, "input_tokens", 0)
                    completion_tokens = getattr(result.usage, "output_tokens", 0)
                    total_tokens = prompt_tokens + completion_tokens

                    span.set_attribute("llm.input_tokens", prompt_tokens)
                    span.set_attribute("llm.output_tokens", completion_tokens)
                    span.set_attribute("llm.total_tokens", total_tokens)

                    # Calculate cost
                    if tracer:
                        cost = tracer.calculate_cost(
                            call_kwargs.get("model", "claude-3-5-sonnet"), prompt_tokens, completion_tokens
                        )
                        span.set_attribute("llm.cost_usd", cost)

                # Add AI message to trace
                if tracer and hasattr(result, "content") and result.content:
                    try:
                        # Extract content from Anthropic response
                        content_text = ""
                        if isinstance(result.content, list):
                            for block in result.content:
                                if hasattr(block, "text"):
                                    content_text += block.text
                                elif isinstance(block, dict) and block.get("type") == "text":
                                    content_text += block.get("text", "")
                        else:
                            content_text = str(result.content)

                        ai_message = {
                            "type": "ai",
                            "id": str(uuid.uuid4()),
                            "content": content_text,
                            "additional_kwargs": {},
                            "response_metadata": {
                                "model_name": call_kwargs.get("model", "claude-3-5-sonnet"),
                                "finish_reason": getattr(result, "stop_reason", "end_turn"),
                                "token_usage": {
                                    "prompt_tokens": prompt_tokens,
                                    "completion_tokens": completion_tokens,
                                    "total_tokens": total_tokens,
                                },
                                "llm.vendor": "anthropic",
                                "endpoint_url": "https://api.anthropic.com/v1/messages",
                                "cost_usd": cost,
                            },
                            "usage_metadata": {
                                "input_tokens": prompt_tokens,
                                "output_tokens": completion_tokens,
                                "total_tokens": total_tokens,
                            },
                            "tool_calls": [],
                            "invalid_tool_calls": [],
                            "span_id": getattr(span, "span_id", None),
                            "timestamp": _get_current_timestamp(),
                        }
                        tracer.add_message(ai_message, span_id=getattr(span, "span_id", None))
                    except Exception as e:
                        span.add_event("message_extraction_error", {"error": str(e)})

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("llm_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})


class OllamaInstrumentor(AutoInstrumentor):
    """Ollama auto-instrumentor - patches requests library to detect Ollama API calls"""

    def _patch_target_functions(self):
        try:
            import requests

            # Store original requests.post function
            original_post = requests.post

            def traced_post(*args, **kwargs):
                """Intercept requests.post and check if it's an Ollama call"""
                return instrumentor._trace_request_post(original_post, *args, **kwargs)

            # Store reference for closure
            instrumentor = self

            # Patch requests.post
            self.original_functions[(requests, "post")] = original_post
            requests.post = traced_post

        except ImportError:
            _debug_print("⚠️  requests package not found - install with: pip install requests")
        except Exception as e:
            _debug_print(f"⚠️  Could not instrument Ollama: {e}")

    def _trace_request_post(self, original_post, *args, **kwargs):
        """Trace HTTP POST requests if they target Ollama"""

        # Extract URL from args or kwargs
        url = args[0] if args else kwargs.get("url", "")

        # Check if this is an Ollama API call
        is_ollama = self._is_ollama_request(url)

        if not is_ollama:
            # Not Ollama - pass through without tracing
            return original_post(*args, **kwargs)

        # This IS an Ollama call - trace it!
        return self._trace_ollama_call(original_post, url, *args, **kwargs)

    def _is_ollama_request(self, url: str) -> bool:
        """Detect if URL is an Ollama API endpoint"""
        if not isinstance(url, str):
            return False

        # Ollama patterns
        ollama_patterns = [
            "localhost:11434",
            "127.0.0.1:11434",
            ":11434/api/",
            "ollama.local",
        ]

        return any(pattern in url for pattern in ollama_patterns)

    def _add_ollama_user_message(self, tracer, prompt, messages, span=None):
        """
        Extract and add user message from Ollama request to the trace.
        Handles both generate (prompt) and chat (messages) endpoints.
        """
        try:
            user_content = None

            # For generate endpoint, use prompt directly
            if prompt:
                user_content = prompt
            # For chat endpoint, find the last user message
            elif messages:
                for msg in reversed(messages):
                    if isinstance(msg, dict) and msg.get("role") == "user":
                        user_content = msg.get("content", "")
                        break

            if user_content:
                human_message = {
                    "type": "human",
                    "id": f"human-{str(uuid.uuid4())}",
                    "content": str(user_content),
                    "name": None,
                    "example": False,
                    "additional_kwargs": {},
                    "response_metadata": {
                        "timestamp": _get_current_timestamp(),
                        "source": "user_input",
                        "llm.vendor": "ollama",
                        "request_id": f"req_{str(uuid.uuid4())[:8]}",
                        "endpoint_url": "http://localhost:11434/api/generate",
                    },
                    "tool_calls": [],
                    "invalid_tool_calls": [],
                }
                tracer.add_message(human_message, span_id=getattr(span, "span_id", None) if span else None)
                _debug_print(f"[Autolog] Added Ollama user message: {str(user_content)[:100]}...")
        except Exception as e:
            _debug_print(f"[Autolog] Failed to extract Ollama user message: {e}")

    def _trace_ollama_call(self, original_post, url, *args, **kwargs):
        """Trace an Ollama LLM API call"""
        import time
        import uuid

        tracer = _ensure_tracer()

        # Extract request data
        json_data = kwargs.get("json", {})
        model = json_data.get("model", "unknown")
        prompt = json_data.get("prompt", "")
        
        # For chat endpoint, extract messages
        messages = json_data.get("messages", [])

        # Determine endpoint type
        endpoint = "generate" if "/api/generate" in url else "chat"

        # Ollama calls auto-create traces when no active trace exists
        trace_started = _ensure_auto_trace(
            "Ollama LLM Call", {"model": model}, is_workflow_entry=True
        )

        try:
            # Create span for this LLM call
            with _auto_span(
                f"ollama_llm_call",
                {
                    "llm.provider": "ollama",
                    "llm.model": model,
                    "llm.endpoint": endpoint,
                    "llm.request.prompt_length": len(prompt) if prompt else 0,
                },
                stage=ValiqorStage.LLM_CALL,
                span_kind=ValiqorSpanKind.LLM_CALL,
            ) as span:

                # Add user message to trace BEFORE making the API call
                if tracer:
                    self._add_ollama_user_message(tracer, prompt, messages, span)

                # Make the actual API call
                start_time = time.time()
                response = original_post(*args, **kwargs)
                latency_ms = (time.time() - start_time) * 1000

                # Parse response
                try:
                    response_data = response.json()
                except:
                    response_data = {}

                # Extract response content
                output = response_data.get("response", "")

                # Extract token usage
                prompt_tokens = response_data.get("prompt_eval_count", 0)
                completion_tokens = response_data.get("eval_count", 0)
                total_tokens = prompt_tokens + completion_tokens

                # Set span attributes
                span.set_attribute("llm.response.latency_ms", latency_ms)
                span.set_attribute("llm.response.length", len(output))
                span.set_attribute("llm.usage.prompt_tokens", prompt_tokens)
                span.set_attribute("llm.usage.completion_tokens", completion_tokens)
                span.set_attribute("llm.usage.total_tokens", total_tokens)

                # Add events
                span.add_event(
                    "llm_request",
                    {
                        "prompt_preview": prompt[:500] if prompt else "",
                        "prompt_length": len(prompt) if prompt else 0,
                    },
                )

                span.add_event(
                    "llm_response",
                    {
                        "response_preview": output[:500],
                        "latency_ms": latency_ms,
                        "response_length": len(output),
                    },
                )

                # Add AI message to trace with proper model metadata
                if tracer and output:
                    ai_message = {
                        "type": "ai",
                        "id": f"ai-{str(uuid.uuid4())}",
                        "content": output,
                        "name": None,
                        "example": False,
                        "additional_kwargs": {},
                        "response_metadata": {
                            "timestamp": time.time(),
                            "llm.vendor": "ollama",
                            "llm.model": model,
                            "model_name": model,  # Add this for cost calculation
                            "finish_reason": "stop",
                            "token_usage": {
                                "prompt_tokens": prompt_tokens,
                                "completion_tokens": completion_tokens,
                                "total_tokens": total_tokens,
                            },
                        },
                        "tool_calls": [],
                        "invalid_tool_calls": [],
                        "usage_metadata": {
                            "input_tokens": prompt_tokens,
                            "output_tokens": completion_tokens,
                            "total_tokens": total_tokens,
                        },
                    }
                    tracer.add_message(ai_message, span_id=span.span_id)

                return response

        except Exception as e:
            # Handle errors gracefully
            _debug_print(f"⚠️ Ollama tracing error: {e}")
            return original_post(*args, **kwargs)
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})


class LangChainInstrumentor(AutoInstrumentor):
    """LangChain auto-instrumentor with RAG-aware retrieval capture"""

    def _patch_target_functions(self):
        _debug_print("[DEBUG] LangChainInstrumentor._patch_target_functions() called")
        try:
            # Try to patch various LangChain components
            self._patch_retrievers()  # NEW: Patch retrievers first for RAG capture
            self._patch_chat_models()
            self._patch_chains()
            self._patch_tools()
            _debug_print("[DEBUG] About to call _patch_langgraph()")
            self._patch_langgraph()
            _debug_print("[DEBUG] _patch_langgraph() call completed")

        except ImportError:
            _debug_print("⚠️  LangChain package not found - install with: pip install langchain")
        except Exception as e:
            _debug_print(f"⚠️  Could not instrument LangChain: {e}")

    def _add_langchain_user_message(self, tracer, messages, span=None):
        """
        Extract and add user message from LangChain messages to the trace.
        Handles both HumanMessage objects and dict-based messages.
        """
        try:
            if not messages:
                return

            user_content = None
            
            # Find the last human/user message
            for msg in reversed(messages if isinstance(messages, list) else [messages]):
                # Handle LangChain message objects
                msg_type = type(msg).__name__
                if msg_type == "HumanMessage":
                    user_content = getattr(msg, "content", str(msg))
                    break
                elif hasattr(msg, "type") and msg.type == "human":
                    user_content = getattr(msg, "content", str(msg))
                    break
                # Handle dict-based messages
                elif isinstance(msg, dict):
                    if msg.get("type") == "human" or msg.get("role") == "user":
                        user_content = msg.get("content", "")
                        break
                # Handle tuple format (role, content)
                elif isinstance(msg, tuple) and len(msg) >= 2:
                    if msg[0] in ("human", "user"):
                        user_content = msg[1]
                        break
                # Handle string input (direct prompt)
                elif isinstance(msg, str):
                    user_content = msg
                    break

            if user_content:
                human_message = {
                    "type": "human",
                    "id": f"human-{str(uuid.uuid4())}",
                    "content": str(user_content),
                    "name": None,
                    "example": False,
                    "additional_kwargs": {},
                    "response_metadata": {
                        "timestamp": _get_current_timestamp(),
                        "source": "user_input",
                        "llm.vendor": "langchain",
                        "request_id": f"req_{str(uuid.uuid4())[:8]}",
                    },
                    "tool_calls": [],
                    "invalid_tool_calls": [],
                }
                tracer.add_message(human_message, span_id=getattr(span, "span_id", None) if span else None)
                _debug_print(f"[Autolog] Added LangChain user message: {str(user_content)[:100]}...")
        except Exception as e:
            _debug_print(f"[Autolog] Failed to extract LangChain user message: {e}")

    def _patch_retrievers(self):
        """Patch LangChain retrievers for automatic RAG capture"""
        try:
            from langchain_core.retrievers import BaseRetriever

            # Patch the main get_relevant_documents method
            original_get_docs = BaseRetriever.get_relevant_documents
            instrumentor = self

            def traced_get_docs(self, query, *args, **kwargs):
                return instrumentor._trace_retrieval_call(
                    original_get_docs, self, query, *args, **kwargs
                )

            self.original_functions[(BaseRetriever, "get_relevant_documents")] = original_get_docs
            BaseRetriever.get_relevant_documents = traced_get_docs

            # Also patch the async version
            original_aget_docs = BaseRetriever.aget_relevant_documents

            async def traced_aget_docs(self, query, *args, **kwargs):
                return await instrumentor._trace_async_retrieval_call(
                    original_aget_docs, self, query, *args, **kwargs
                )

            self.original_functions[(BaseRetriever, "aget_relevant_documents")] = original_aget_docs
            BaseRetriever.aget_relevant_documents = traced_aget_docs

            _debug_print("[RAG] Valiqor: RAG retrieval instrumentation enabled")

        except ImportError:
            _debug_print("⚠️  LangChain core retrievers not available")
        except Exception as e:
            _debug_print(f"⚠️  Could not instrument LangChain retrievers: {e}")

    def _trace_retrieval_call(self, original_func, retriever_instance, query, *args, **kwargs):
        """Trace LangChain retrieval operation - capture actual retrieval data"""
        _debug_print("[RAG DEBUG 1] _trace_retrieval_call: Entry point for retrieval tracing")
        tracer = _ensure_tracer()

        try:
            # Start retrieval span with detailed attributes
            retriever_name = retriever_instance.__class__.__name__

            with _auto_span(
                "retrieval_operation",
                {
                    "rag.operation": "retrieval",
                    "rag.retriever_type": retriever_name,
                    "rag.query": query[:200] if query else "",
                    "rag.query_length": len(query) if query else 0,
                },
                stage=ValiqorStage.RETRIEVAL,
                span_kind=ValiqorSpanKind.RETRIEVER,
            ) as span:

                # Execute the actual retrieval
                import time

                start_time = time.time()
                documents = original_func(retriever_instance, query, *args, **kwargs)
                end_time = time.time()

                # Extract retrieval metadata
                k = kwargs.get("k", len(documents) if documents else 0)
                embedding_model = getattr(retriever_instance, "embedding_model", None)
                if hasattr(retriever_instance, "embeddings"):
                    embedding_model = getattr(
                        retriever_instance.embeddings,
                        "model",
                        str(retriever_instance.embeddings.__class__.__name__),
                    )

                # Create document hits from LangChain Documents
                hits = []
                for i, doc in enumerate(documents):
                    hit = {
                        "doc_id": doc.metadata.get("id")
                        or doc.metadata.get("source")
                        or f"doc_{i}",
                        "rank": i + 1,
                        "score": doc.metadata.get(
                            "score", doc.metadata.get("similarity_score", 1.0 - (i * 0.1))
                        ),  # Fallback scoring
                        "snippet_preview": (
                            doc.page_content[:300]
                            if hasattr(doc, "page_content")
                            else str(doc)[:300]
                        ),
                        "metadata": dict(doc.metadata) if hasattr(doc, "metadata") else {},
                    }
                    hits.append(hit)

                # Update span with retrieval results
                span.set_attribute("rag.documents_retrieved", len(documents))
                span.set_attribute("rag.retrieval_latency_ms", (end_time - start_time) * 1000)
                span.set_attribute("rag.top_score", hits[0]["score"] if hits else 0.0)

                span.add_event(
                    "retrieval_completed",
                    {
                        "hit_count": len(hits),
                        "top_score": hits[0]["score"] if hits else None,
                        "query_length": len(query) if query else 0,
                        "retriever_type": retriever_name,
                    },
                )

                # Log detailed retrieval information to tracer
                if tracer and len(hits) > 0:
                    from .rag_extensions import DocumentHit, RetrievalInfo

                    # Convert to proper DocumentHit objects
                    document_hits = [
                        DocumentHit(
                            doc_id=hit["doc_id"],
                            rank=hit["rank"],
                            score=hit["score"],
                            snippet_preview=hit["snippet_preview"],
                            metadata=hit["metadata"],
                        )
                        for hit in hits
                    ]

                    # Create RetrievalInfo with correct parameter names
                    retrieval_info = RetrievalInfo(
                        retriever=retriever_name,
                        embedding_model=embedding_model or "unknown",
                        top_k=k,
                        query=query,
                        hits=document_hits,
                        latency_ms=(end_time - start_time) * 1000,
                        filters=kwargs.get("filter", {}),
                        total_documents=len(document_hits),
                    )

                    # Store retrieval info in span if it's a RAGSpan
                    if hasattr(span, "set_retrieval_info"):
                        span.set_retrieval_info(retrieval_info)

                    # Also log as extra data for the trace
                    tracer.log_extra(
                        {
                            "retrieval": {
                                "query": query,
                                "retriever_type": retriever_name,
                                "embedding_model": embedding_model or "unknown",
                                "k": k,
                                "hits": hits,
                                "latency_ms": (end_time - start_time) * 1000,
                                "filters": kwargs.get("filter", {}),
                                "timestamp": time.time(),
                            }
                        }
                    )

                return documents
                return documents

        except Exception as e:
            if "span" in locals():
                span.add_event("retrieval_error", {"error": str(e)})
                span.set_attribute("error", True)
            raise

    async def _trace_async_retrieval_call(
        self, original_func, retriever_instance, query, *args, **kwargs
    ):
        """Trace async LangChain retrieval operation"""
        tracer = _ensure_tracer()

        try:
            retriever_name = retriever_instance.__class__.__name__

            with _auto_span(
                "async_retrieval_operation",
                {
                    "rag.operation": "retrieval",
                    "rag.retriever_type": retriever_name,
                    "rag.query": query[:200] if query else "",
                    "rag.async": True,
                },
                stage=ValiqorStage.RETRIEVAL,
                span_kind=ValiqorSpanKind.RETRIEVER,
            ) as span:

                import time

                start_time = time.time()
                documents = await original_func(retriever_instance, query, *args, **kwargs)
                end_time = time.time()

                # Same processing as sync version
                hits = []
                for i, doc in enumerate(documents):
                    hit = {
                        "doc_id": doc.metadata.get("id")
                        or doc.metadata.get("source")
                        or f"doc_{i}",
                        "rank": i + 1,
                        "score": doc.metadata.get("score", 1.0 - (i * 0.1)),
                        "snippet_preview": (
                            doc.page_content[:300]
                            if hasattr(doc, "page_content")
                            else str(doc)[:300]
                        ),
                        "metadata": dict(doc.metadata) if hasattr(doc, "metadata") else {},
                    }
                    hits.append(hit)

                span.set_attribute("rag.documents_retrieved", len(documents))
                span.set_attribute("rag.retrieval_latency_ms", (end_time - start_time) * 1000)

                # Log to tracer
                if tracer and len(hits) > 0:
                    tracer.log_extra(
                        {
                            "retrieval": {
                                "query": query,
                                "retriever_type": retriever_name,
                                "async": True,
                                "hits": hits,
                                "latency_ms": (end_time - start_time) * 1000,
                                "timestamp": time.time(),
                            }
                        }
                    )

                return documents

        except Exception as e:
            if "span" in locals():
                span.add_event("async_retrieval_error", {"error": str(e)})
            raise

    def _patch_chat_models(self):
        """Patch LangChain chat models"""
        try:
            from langchain_core.language_models.chat_models import BaseChatModel

            # Patch the main _generate method (sync)
            original_generate = BaseChatModel._generate
            instrumentor = self

            def traced_generate(self, messages, *args, **kwargs):
                return instrumentor._trace_langchain_call(
                    original_generate, self, messages, *args, **kwargs
                )

            self.original_functions[(BaseChatModel, "_generate")] = original_generate
            BaseChatModel._generate = traced_generate

            # Patch _agenerate method (async)
            if hasattr(BaseChatModel, "_agenerate"):
                original_agenerate = BaseChatModel._agenerate

                async def traced_agenerate(self, messages, *args, **kwargs):
                    return await instrumentor._trace_langchain_async_call(
                        original_agenerate, self, messages, *args, **kwargs
                    )

                self.original_functions[(BaseChatModel, "_agenerate")] = original_agenerate
                BaseChatModel._agenerate = traced_agenerate
                _debug_print("[DEBUG] BaseChatModel._agenerate patched for async tracing")

            # Also patch the invoke method which is commonly used
            original_invoke = BaseChatModel.invoke

            def traced_invoke(self, input_data, *args, **kwargs):
                return instrumentor._trace_langchain_invoke(
                    original_invoke, self, input_data, *args, **kwargs
                )

            self.original_functions[(BaseChatModel, "invoke")] = original_invoke
            BaseChatModel.invoke = traced_invoke

            # Patch ainvoke method (async)
            if hasattr(BaseChatModel, "ainvoke"):
                original_ainvoke = BaseChatModel.ainvoke

                async def traced_ainvoke(self, input_data, *args, **kwargs):
                    return await instrumentor._trace_langchain_ainvoke(
                        original_ainvoke, self, input_data, *args, **kwargs
                    )

                self.original_functions[(BaseChatModel, "ainvoke")] = original_ainvoke
                BaseChatModel.ainvoke = traced_ainvoke
                _debug_print("[DEBUG] BaseChatModel.ainvoke patched for async tracing")

        except ImportError:
            pass  # LangChain components might not be available

    def _patch_chains(self):
        """Patch LangChain chains"""
        try:
            from langchain_core.runnables.base import Runnable

            original_invoke = Runnable.invoke

            def traced_invoke(self, input_data, *args, **kwargs):
                return self._trace_chain_call(original_invoke, self, input_data, *args, **kwargs)

            self.original_functions[(Runnable, "invoke")] = original_invoke
            Runnable.invoke = traced_invoke

            # Patch ainvoke method (async)
            if hasattr(Runnable, "ainvoke"):
                original_ainvoke = Runnable.ainvoke
                instrumentor = self

                async def traced_ainvoke(self, input_data, *args, **kwargs):
                    return await instrumentor._trace_chain_async_call(
                        original_ainvoke, self, input_data, *args, **kwargs
                    )

                self.original_functions[(Runnable, "ainvoke")] = original_ainvoke
                Runnable.ainvoke = traced_ainvoke
                _debug_print("[DEBUG] Runnable.ainvoke patched for async tracing")
            Runnable.invoke = traced_invoke

        except ImportError:
            pass

    def _patch_tools(self):
        """Patch LangChain tools for automatic tracing.
        
        CRITICAL: Wrapper functions MUST have the same signature as the original _run methods,
        specifically including the `config: RunnableConfig` keyword-only argument.
        
        LangChain's BaseTool.run() uses `_get_runnable_config_param(self._run)` to detect
        if _run has a `config` parameter. If our wrapper doesn't have `config` in its signature,
        LangChain won't pass it, causing "missing 1 required keyword-only argument: 'config'" errors.
        """
        try:
            from langchain_core.tools import BaseTool
            from langchain_core.runnables.config import RunnableConfig
            from typing import Any

            # Store reference to this instrumentor for the closure
            instrumentor = self

            # Patch BaseTool._run (for any custom tools that use it directly)
            original_base_run = BaseTool._run

            # CRITICAL: Signature must match original to ensure LangChain passes config
            def traced_base_run(
                self, 
                *args: Any, 
                config: RunnableConfig = None, 
                run_manager = None, 
                **kwargs: Any
            ) -> Any:
                return instrumentor._trace_tool_call(
                    original_base_run, self, *args, 
                    config=config, run_manager=run_manager, **kwargs
                )

            self.original_functions[(BaseTool, "_run")] = original_base_run
            BaseTool._run = traced_base_run
            _debug_print("[DEBUG] BaseTool._run patched for tool tracing")

            # CRITICAL: Also patch StructuredTool._run - this is what @tool decorator creates!
            # StructuredTool OVERRIDES BaseTool._run, so patching BaseTool alone doesn't work.
            try:
                from langchain_core.tools import StructuredTool
                
                original_structured_run = StructuredTool._run

                # CRITICAL: Signature must match original to ensure LangChain passes config
                def traced_structured_run(
                    self, 
                    *args: Any, 
                    config: RunnableConfig = None, 
                    run_manager = None, 
                    **kwargs: Any
                ) -> Any:
                    return instrumentor._trace_tool_call(
                        original_structured_run, self, *args, 
                        config=config, run_manager=run_manager, **kwargs
                    )

                self.original_functions[(StructuredTool, "_run")] = original_structured_run
                StructuredTool._run = traced_structured_run
                _debug_print("[DEBUG] StructuredTool._run patched for tool tracing")

            except ImportError:
                _debug_print("[WARN] StructuredTool not available - only BaseTool patched")

            # Also patch create_retriever_tool's tool class (RetrieverTool) if it exists
            try:
                from langchain_core.tools.retriever import RetrieverTool
                
                original_retriever_run = RetrieverTool._run

                # CRITICAL: Signature must match original to ensure LangChain passes config
                def traced_retriever_run(
                    self, 
                    *args: Any, 
                    config: RunnableConfig = None, 
                    run_manager = None, 
                    **kwargs: Any
                ) -> Any:
                    return instrumentor._trace_tool_call(
                        original_retriever_run, self, *args, 
                        config=config, run_manager=run_manager, **kwargs
                    )

                self.original_functions[(RetrieverTool, "_run")] = original_retriever_run
                RetrieverTool._run = traced_retriever_run
                _debug_print("[DEBUG] RetrieverTool._run patched for tool tracing")
                
            except ImportError:
                _debug_print("[DEBUG] RetrieverTool not available (uses StructuredTool)")

            # NOTE: We intentionally do NOT patch BaseTool.invoke because:
            # 1. invoke() internally calls _run(), so patching _run is sufficient
            # 2. Patching both causes DUPLICATE tool spans and messages
            # 3. _run() has access to the actual tool arguments, while invoke() receives
            #    the full tool_call dict which requires extra parsing

            # Patch async _arun method for async tool execution parity
            if hasattr(BaseTool, "_arun"):
                original_arun = BaseTool._arun

                # CRITICAL: Signature must match original to ensure LangChain passes config
                async def traced_arun(
                    self, 
                    *args: Any, 
                    config: RunnableConfig = None, 
                    run_manager = None, 
                    **kwargs: Any
                ) -> Any:
                    return await instrumentor._trace_tool_call_async(
                        original_arun, self, *args, 
                        config=config, run_manager=run_manager, **kwargs
                    )

                self.original_functions[(BaseTool, "_arun")] = original_arun
                BaseTool._arun = traced_arun
                _debug_print("[DEBUG] BaseTool._arun patched for async tool tracing")

            # Also patch StructuredTool._arun for async parity
            try:
                from langchain_core.tools import StructuredTool
                if hasattr(StructuredTool, "_arun"):
                    original_structured_arun = StructuredTool._arun

                    # CRITICAL: Signature must match original to ensure LangChain passes config
                    async def traced_structured_arun(
                        self, 
                        *args: Any, 
                        config: RunnableConfig = None, 
                        run_manager = None, 
                        **kwargs: Any
                    ) -> Any:
                        return await instrumentor._trace_tool_call_async(
                            original_structured_arun, self, *args, 
                            config=config, run_manager=run_manager, **kwargs
                        )

                    self.original_functions[(StructuredTool, "_arun")] = original_structured_arun
                    StructuredTool._arun = traced_structured_arun
                    _debug_print("[DEBUG] StructuredTool._arun patched for async tool tracing")
            except ImportError:
                pass

            # Also patch ToolNode if available for LangGraph tool execution
            try:
                from langgraph.prebuilt import ToolNode

                # ToolNode is callable, so we patch __call__ but we DON'T wrap it as a traced_action
                # because it's already wrapped by the workflow node patching above
                # Just skip ToolNode patching since it's already handled by workflow node wrapping
                _debug_print(
                    "[DEBUG] ToolNode detected - will be traced through workflow node wrapping"
                )

            except ImportError:
                pass  # LangGraph might not be available

        except ImportError:
            pass  # Tools might not be available

    def _patch_langgraph(self):
        """Patch LangGraph components for automatic tracing"""
        _debug_print("[DEBUG] _patch_langgraph() called - Starting LangGraph instrumentation")
        try:
            # Patch StateGraph execution (Pregel is the compiled graph class in newer LangGraph)
            from langgraph.pregel import Pregel

            _debug_print("[DEBUG] Pregel (compiled graph) imported successfully")

            original_invoke = Pregel.invoke

            def traced_graph_invoke(self, input_data, *args, **kwargs):
                return instrumentor._trace_graph_call(
                    original_invoke, self, input_data, *args, **kwargs
                )

            instrumentor = self

            self.original_functions[(Pregel, "invoke")] = original_invoke
            Pregel.invoke = traced_graph_invoke

            # Patch ainvoke (async invoke)
            if hasattr(Pregel, "ainvoke"):
                original_ainvoke = Pregel.ainvoke

                async def traced_graph_ainvoke(self, input_data, *args, **kwargs):
                    return await instrumentor._trace_graph_async_call(
                        original_ainvoke, self, input_data, *args, **kwargs
                    )

                self.original_functions[(Pregel, "ainvoke")] = original_ainvoke
                Pregel.ainvoke = traced_graph_ainvoke
                _debug_print("[DEBUG] Pregel.ainvoke patched for async tracing")

            # Also patch streaming invoke if available
            if hasattr(Pregel, "stream"):
                original_stream = Pregel.stream

                def traced_graph_stream(self, input_data, *args, **kwargs):
                    return instrumentor._trace_graph_stream(
                        original_stream, self, input_data, *args, **kwargs
                    )

                self.original_functions[(Pregel, "stream")] = original_stream
                Pregel.stream = traced_graph_stream

            # Patch astream (async stream)
            if hasattr(Pregel, "astream"):
                original_astream = Pregel.astream

                async def traced_graph_astream(self, input_data, *args, **kwargs):
                    async for chunk in instrumentor._trace_graph_async_stream(
                        original_astream, self, input_data, *args, **kwargs
                    ):
                        yield chunk

                self.original_functions[(Pregel, "astream")] = original_astream
                Pregel.astream = traced_graph_astream
                _debug_print("[DEBUG] Pregel.astream patched for async tracing")

            # ✅ NEW: Auto-instrument individual workflow nodes
            _debug_print("[DEBUG] About to call _patch_langgraph_nodes()")
            self._patch_langgraph_nodes()
            _debug_print("[DEBUG] _patch_langgraph_nodes() completed")

        except ImportError as ie:
            _debug_print(
                f"[WARN] LangGraph not available: {ie}"
            )  # LangGraph might not be available
        except Exception as e:
            _debug_print(f"[WARN] Could not fully instrument LangGraph: {e}")
            import traceback

            traceback.print_exc()

    def _patch_langgraph_nodes(self):
        """
        Auto-instrument LangGraph workflow nodes to capture high-level calls.

        This patches StateGraph.add_node to automatically wrap node functions
        with tracing spans - no application code changes required!
        """
        try:
            from langgraph.graph import StateGraph

            _debug_print("[DEBUG] LangGraph StateGraph imported successfully")

            original_add_node = StateGraph.add_node
            instrumentor = self

            def traced_add_node(self, node_name, action, **kwargs):
                """
                Intercept node registration and wrap action with automatic tracing.
                """
                _debug_print(
                    f"[DEBUG] traced_add_node called for: '{node_name}', action type: {type(action).__name__}"
                )
                _debug_print(
                    f"[DEBUG] callable(action): {callable(action)}, isinstance(action, type): {isinstance(action, type)}"
                )

                # Check if action is a ToolNode instance (special handling needed)
                is_tool_node_instance = False
                try:
                    from langgraph.prebuilt import ToolNode

                    is_tool_node_instance = isinstance(action, ToolNode)
                    if is_tool_node_instance:
                        _debug_print(
                            f"[DEBUG] Node '{node_name}' is a ToolNode instance - will wrap with special handling"
                        )
                except ImportError:
                    pass

                # Only wrap if it's a callable (function/method or ToolNode instance)
                # ToolNode instances are callable but need special argument handling
                # For ToolNode instances, we skip the 'not isinstance(action, type)' check
                should_wrap = (
                    callable(action) and not isinstance(action, type)
                ) or is_tool_node_instance

                if should_wrap:
                    _debug_print(f"[OK] Wrapping node '{node_name}' with tracing")
                    original_action = action
                    _is_tool_node = is_tool_node_instance  # Capture in closure

                    def traced_action(state, *args, **inner_kwargs):
                        """Traced wrapper for workflow node function."""
                        _debug_print(f"[TRACE] Executing traced node: '{node_name}'")
                        tracer = _ensure_tracer()
                        span = None

                        # Create high-level span for this workflow node
                        if tracer:
                            try:
                                # Stage will be inferred by _enrich_span from node name
                                # We just pass the workflow node attributes
                                span = tracer.start_span(
                                    node_name,  # Use node name directly - works with ANY name!
                                    attributes={
                                        "node.type": "workflow_node",
                                        "node.name": node_name,
                                        "node.level": "high_level",
                                        "workflow.framework": "langgraph",
                                        "state.has_messages": (
                                            "messages" in state
                                            if isinstance(state, dict)
                                            else False
                                        ),
                                        "state.message_count": (
                                            len(state.get("messages", []))
                                            if isinstance(state, dict) and "messages" in state
                                            else 0
                                        ),
                                    },
                                    span_kind=ValiqorSpanKind.WORKFLOW_NODE,
                                )
                                _debug_print(
                                    f"[OK] Started span for node '{node_name}': {span.span_id}"
                                )

                                # Store span ID in global dict for tool execution to access
                                _current_workflow_span["span_id"] = span.span_id
                                _current_workflow_span["span_name"] = node_name
                                _debug_print(
                                    f"[DEBUG] Stored workflow span for tool access: {span.span_id}"
                                )

                            except Exception as e:
                                _debug_print(
                                    f"[WARN] Could not start span for node '{node_name}': {e}"
                                )

                            except Exception as e:
                                _debug_print(
                                    f"[WARN] Could not start span for node '{node_name}': {e}"
                                )

                        try:
                            # Execute original node function
                            # ToolNode instances have an invoke() method, not __call__
                            if _is_tool_node:
                                _debug_print(
                                    f"[DEBUG] Calling ToolNode.invoke() with state argument"
                                )
                                result = original_action.invoke(state)
                            else:
                                result = original_action(state, *args, **inner_kwargs)
                            _debug_print(f"[OK] Node '{node_name}' executed successfully")

                            # Update span with result info
                            if span and result:
                                if isinstance(result, dict):
                                    if "messages" in result:
                                        span.set_attribute(
                                            "result.added_messages", len(result["messages"])
                                        )
                                    for key in ["is_sufficient", "feedback", "iteration_count"]:
                                        if key in result:
                                            span.set_attribute(f"result.{key}", result[key])

                            # Mark span as successful
                            if span and tracer:
                                tracer.finish_span(span, "success")
                                _debug_print(f"[OK] Finished span for node '{node_name}'")

                                # Clear global dict
                                _current_workflow_span.pop("span_id", None)
                                _current_workflow_span.pop("span_name", None)

                            return result

                        except Exception as e:
                            _debug_print(f"[ERROR] Node '{node_name}' failed: {e}")
                            # Mark span as failed
                            if span and tracer:
                                span.set_attribute("error", str(e))
                                span.set_attribute("error.type", type(e).__name__)
                                tracer.finish_span(span, "error")

                                # Clear global dict
                                _current_workflow_span.pop("span_id", None)
                                _current_workflow_span.pop("span_name", None)
                            raise

                    # Replace action with traced version
                    action = traced_action
                else:
                    _debug_print(
                        f"[WARN] NOT wrapping node '{node_name}' - not a callable or is a type"
                    )

                # Call original add_node with potentially wrapped action
                return original_add_node(self, node_name, action, **kwargs)

            self.original_functions[(StateGraph, "add_node")] = original_add_node
            StateGraph.add_node = traced_add_node

            _debug_print("[OK] Valiqor: LangGraph workflow nodes will be auto-instrumented")

        except ImportError:
            pass  # StateGraph not available
        except Exception as e:
            _debug_print(f"[WARN] Could not instrument LangGraph nodes: {e}")

    def _trace_langchain_call(self, original_func, instance, messages, *args, **kwargs):
        """Trace LangChain chat model call"""
        tracer = _ensure_tracer()

        trace_started = _ensure_auto_trace(
            "LangChain Chat Model",
            {
                "model_type": instance.__class__.__name__,
                "messages_count": len(messages) if messages else 0,
            },
            is_workflow_entry=True,
        )

        try:
            # Determine model name - get it from the instance
            model_name = "unknown"
            vendor = "unknown"

            # Extract model information from LangChain instance
            if hasattr(instance, "model_name"):
                model_name = instance.model_name
            elif hasattr(instance, "model"):
                model_name = instance.model

            # Determine vendor from class name
            class_name = instance.__class__.__name__.lower()
            if "openai" in class_name:
                vendor = "openai"
            elif "anthropic" in class_name:
                vendor = "anthropic"

            # Create span with LangChain naming pattern similar to manual trace
            span_name = f"llm_call_{str(instance.__class__.__module__.split('.') + [instance.__class__.__name__])}"

            with _auto_span(
                span_name,
                {
                    "llm.model_name": model_name,
                    "llm.vendor": vendor,
                    "llm.request.type": "chat.completions",
                    "langchain.model_type": instance.__class__.__name__,
                    "langchain.messages_count": len(messages) if messages else 0,
                },
                stage=ValiqorStage.LLM_CALL,
                span_kind=ValiqorSpanKind.LLM_CALL,
            ) as span:

                # Add user message to trace BEFORE making the API call
                if tracer:
                    self._add_langchain_user_message(tracer, messages, span)

                result = original_func(instance, messages, *args, **kwargs)

                # Extract LangChain response metadata and token usage
                if hasattr(result, "llm_output") and result.llm_output:
                    llm_output = result.llm_output
                    if isinstance(llm_output, dict):
                        token_usage = llm_output.get("token_usage", {})
                        if token_usage:
                            prompt_tokens = token_usage.get("prompt_tokens", 0)
                            completion_tokens = token_usage.get("completion_tokens", 0)
                            total_tokens = token_usage.get("total_tokens", 0)

                            span.set_attribute("llm.input_tokens", prompt_tokens)
                            span.set_attribute("llm.output_tokens", completion_tokens)
                            span.set_attribute("llm.total_tokens", total_tokens)

                            # Calculate cost for LangChain calls too
                            if tracer and model_name != "unknown":
                                cost = tracer.calculate_cost(
                                    model_name, prompt_tokens, completion_tokens
                                )
                                span.set_attribute("llm.cost_usd", cost)

                # Add AI messages from LangChain result if available
                if tracer and hasattr(result, "generations") and result.generations:
                    try:
                        for generation in result.generations[0]:  # Usually one generation per call
                            if hasattr(generation, "message"):
                                message = generation.message

                                # Extract token usage from generation or message response_metadata
                                prompt_tokens = 0
                                completion_tokens = 0
                                total_tokens = 0
                                cost = 0.0

                                # LangChain stores response metadata in the message
                                if (
                                    hasattr(message, "response_metadata")
                                    and message.response_metadata
                                ):
                                    metadata = message.response_metadata
                                    if "token_usage" in metadata:
                                        token_usage = metadata["token_usage"]
                                        prompt_tokens = token_usage.get("prompt_tokens", 0)
                                        completion_tokens = token_usage.get("completion_tokens", 0)
                                        total_tokens = token_usage.get("total_tokens", 0)

                                        # Update span attributes with token info
                                        span.set_attribute("llm.input_tokens", prompt_tokens)
                                        span.set_attribute("llm.output_tokens", completion_tokens)
                                        span.set_attribute("llm.total_tokens", total_tokens)

                                        # Calculate cost
                                        cost = tracer.calculate_cost(
                                            model_name, prompt_tokens, completion_tokens
                                        )
                                        span.set_attribute("llm.cost_usd", cost)

                                ai_message = {
                                    "type": "ai",
                                    "id": str(uuid.uuid4()),
                                    "content": getattr(message, "content", ""),
                                    "additional_kwargs": getattr(message, "additional_kwargs", {}),
                                    "response_metadata": {
                                        "model_name": model_name,
                                        "llm.vendor": vendor,
                                        "request_id": f"req_{str(uuid.uuid4())[:8]}",
                                        "endpoint_url": (
                                            f"https://api.{vendor}.com/v1/completions"
                                            if vendor != "unknown"
                                            else "https://api.unknown.com/v1/completions"
                                        ),
                                        "token_usage": {
                                            "prompt_tokens": prompt_tokens,
                                            "completion_tokens": completion_tokens,
                                            "total_tokens": total_tokens,
                                        },
                                        "cost_usd": cost,
                                    },
                                    "cost_breakdown": {
                                        "prompt_cost": (
                                            cost
                                            * (prompt_tokens / (prompt_tokens + completion_tokens))
                                            if total_tokens > 0
                                            else 0
                                        ),
                                        "completion_cost": (
                                            cost
                                            * (
                                                completion_tokens
                                                / (prompt_tokens + completion_tokens)
                                            )
                                            if total_tokens > 0
                                            else 0
                                        ),
                                        "total_cost": cost,
                                        "model": model_name,
                                    },
                                    "usage_metadata": {
                                        "input_tokens": prompt_tokens,
                                        "output_tokens": completion_tokens,
                                        "total_tokens": total_tokens,
                                    },
                                    "tool_calls": [],
                                    "invalid_tool_calls": [],
                                    "span_id": getattr(span, "span_id", None),
                                }

                                # Copy actual response metadata if available
                                if (
                                    hasattr(message, "response_metadata")
                                    and message.response_metadata
                                ):
                                    ai_message["response_metadata"].update(
                                        message.response_metadata
                                    )

                                # Extract tool calls from LangChain message if present
                                # Handle both dict and object formats (LangChain version compatibility)
                                if hasattr(message, "tool_calls") and message.tool_calls:
                                    for tool_call in message.tool_calls:
                                        if isinstance(tool_call, dict):
                                            # Dict format (newer LangChain versions)
                                            tool_call_info = {
                                                "id": tool_call.get("id", ""),
                                                "name": tool_call.get("name", ""),
                                                "args": tool_call.get("args", {}),
                                                "type": "tool_call",
                                            }
                                        else:
                                            # Object format (older LangChain versions)
                                            tool_call_info = {
                                                "id": getattr(tool_call, "id", ""),
                                                "name": getattr(tool_call, "name", ""),
                                                "args": getattr(tool_call, "args", {}),
                                                "type": "tool_call",
                                            }
                                        ai_message["tool_calls"].append(tool_call_info)

                                # Add timestamp
                                import time

                                ai_message["timestamp"] = time.time()

                                tracer.add_message(
                                    ai_message, span_id=getattr(span, "span_id", None)
                                )
                    except Exception as e:
                        span.add_event("message_extraction_error", {"error": str(e)})

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("langchain_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    def _trace_langchain_invoke(self, original_func, instance, input_data, *args, **kwargs):
        """Trace LangChain chat model invoke method"""
        tracer = _ensure_tracer()

        trace_started = _ensure_auto_trace(
            "LangChain Invoke",
            {"model_type": instance.__class__.__name__, "input_type": type(input_data).__name__},
            is_workflow_entry=True,
        )

        try:
            # Determine model name and vendor
            model_name = getattr(instance, "model_name", getattr(instance, "model", "unknown"))
            vendor = "unknown"

            class_name = instance.__class__.__name__.lower()
            if "openai" in class_name:
                vendor = "openai"
            elif "anthropic" in class_name:
                vendor = "anthropic"

            # Create span with LangChain naming pattern
            span_name = f"llm_call_{str(instance.__class__.__module__.split('.') + [instance.__class__.__name__])}"

            with _auto_span(
                span_name,
                {
                    "llm.model_name": model_name,
                    "llm.vendor": vendor,
                    "llm.request.type": "chat.completions",
                    "langchain.model_type": instance.__class__.__name__,
                },
                stage=ValiqorStage.LLM_CALL,
                span_kind=ValiqorSpanKind.LLM_CALL,
            ) as span:

                # Add user message to trace BEFORE making the API call
                if tracer:
                    self._add_langchain_user_message(tracer, input_data, span)

                result = original_func(instance, input_data, *args, **kwargs)

                # Extract response metadata from LangChain AIMessage result
                if tracer and hasattr(result, "response_metadata") and result.response_metadata:
                    metadata = result.response_metadata

                    # Extract token usage
                    if "token_usage" in metadata:
                        token_usage = metadata["token_usage"]
                        prompt_tokens = token_usage.get("prompt_tokens", 0)
                        completion_tokens = token_usage.get("completion_tokens", 0)
                        total_tokens = token_usage.get("total_tokens", 0)

                        # Update span attributes
                        span.set_attribute("llm.input_tokens", prompt_tokens)
                        span.set_attribute("llm.output_tokens", completion_tokens)
                        span.set_attribute("llm.total_tokens", total_tokens)

                        # Calculate cost
                        cost = tracer.calculate_cost(model_name, prompt_tokens, completion_tokens)
                        span.set_attribute("llm.cost_usd", cost)

                        # Create comprehensive AI message like manual tracing
                        ai_message = {
                            "type": "ai",
                            "id": str(uuid.uuid4()),
                            "content": getattr(result, "content", ""),
                            "additional_kwargs": getattr(result, "additional_kwargs", {}),
                            "response_metadata": dict(metadata),  # Copy all metadata
                            "cost_breakdown": {
                                "prompt_cost": (
                                    cost * (prompt_tokens / (prompt_tokens + completion_tokens))
                                    if total_tokens > 0
                                    else 0
                                ),
                                "completion_cost": (
                                    cost * (completion_tokens / (prompt_tokens + completion_tokens))
                                    if total_tokens > 0
                                    else 0
                                ),
                                "total_cost": cost,
                                "model": model_name,
                            },
                            "usage_metadata": {
                                "input_tokens": prompt_tokens,
                                "output_tokens": completion_tokens,
                                "total_tokens": total_tokens,
                            },
                            "tool_calls": [],
                            "invalid_tool_calls": [],
                            "span_id": getattr(span, "span_id", None),
                        }

                        # Extract tool calls if present
                        # Handle both dict and object formats (LangChain version compatibility)
                        if hasattr(result, "tool_calls") and result.tool_calls:
                            for tool_call in result.tool_calls:
                                if isinstance(tool_call, dict):
                                    # Dict format (newer LangChain versions)
                                    tool_call_info = {
                                        "id": tool_call.get("id", ""),
                                        "name": tool_call.get("name", ""),
                                        "args": tool_call.get("args", {}),
                                        "type": "tool_call",
                                    }
                                else:
                                    # Object format (older LangChain versions)
                                    tool_call_info = {
                                        "id": getattr(tool_call, "id", ""),
                                        "name": getattr(tool_call, "name", ""),
                                        "args": getattr(tool_call, "args", {}),
                                        "type": "tool_call",
                                    }
                                ai_message["tool_calls"].append(tool_call_info)

                        # Add timestamp and message ID
                        import time

                        ai_message["timestamp"] = time.time()

                        tracer.add_message(ai_message, span_id=getattr(span, "span_id", None))

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("langchain_invoke_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    async def _trace_langchain_async_call(self, original_func, instance, messages, *args, **kwargs):
        """Trace LangChain chat model async call (_agenerate)"""
        tracer = _ensure_tracer()

        trace_started = _ensure_auto_trace(
            "LangChain Chat Model (Async)",
            {
                "model_type": instance.__class__.__name__,
                "messages_count": len(messages) if messages else 0,
            },
            is_workflow_entry=True,
        )

        try:
            model_name = getattr(instance, "model_name", getattr(instance, "model", "unknown"))
            vendor = "unknown"
            class_name = instance.__class__.__name__.lower()
            if "openai" in class_name:
                vendor = "openai"
            elif "anthropic" in class_name:
                vendor = "anthropic"

            span_name = f"llm_call_{str(instance.__class__.__module__.split('.') + [instance.__class__.__name__])}"

            with _auto_span(
                span_name,
                {
                    "llm.model_name": model_name,
                    "llm.vendor": vendor,
                    "llm.request.type": "chat.completions",
                    "llm.async": True,
                    "langchain.model_type": instance.__class__.__name__,
                    "langchain.messages_count": len(messages) if messages else 0,
                },
                stage=ValiqorStage.LLM_CALL,
                span_kind=ValiqorSpanKind.LLM_CALL,
            ) as span:

                if tracer:
                    self._add_langchain_user_message(tracer, messages, span)

                result = await original_func(instance, messages, *args, **kwargs)

                # Extract token usage and add AI message (same as sync version)
                if tracer and hasattr(result, "generations") and result.generations:
                    try:
                        for generation in result.generations[0]:
                            if hasattr(generation, "message"):
                                message = generation.message
                                prompt_tokens = 0
                                completion_tokens = 0
                                total_tokens = 0
                                cost = 0.0

                                if hasattr(message, "response_metadata") and message.response_metadata:
                                    metadata = message.response_metadata
                                    if "token_usage" in metadata:
                                        token_usage = metadata["token_usage"]
                                        prompt_tokens = token_usage.get("prompt_tokens", 0)
                                        completion_tokens = token_usage.get("completion_tokens", 0)
                                        total_tokens = token_usage.get("total_tokens", 0)
                                        cost = tracer.calculate_cost(model_name, prompt_tokens, completion_tokens)

                                ai_message = {
                                    "type": "ai",
                                    "id": str(uuid.uuid4()),
                                    "content": getattr(message, "content", ""),
                                    "response_metadata": {
                                        "model_name": model_name,
                                        "llm.vendor": vendor,
                                        "async": True,
                                    },
                                    "tool_calls": [],
                                    "invalid_tool_calls": [],
                                    "span_id": getattr(span, "span_id", None),
                                }
                                tracer.add_message(ai_message, span_id=getattr(span, "span_id", None))
                    except Exception as e:
                        span.add_event("message_extraction_error", {"error": str(e)})

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("langchain_async_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    async def _trace_langchain_ainvoke(self, original_func, instance, input_data, *args, **kwargs):
        """Trace LangChain chat model ainvoke method"""
        tracer = _ensure_tracer()

        trace_started = _ensure_auto_trace(
            "LangChain Ainvoke",
            {"model_type": instance.__class__.__name__, "input_type": type(input_data).__name__},
            is_workflow_entry=True,
        )

        try:
            model_name = getattr(instance, "model_name", getattr(instance, "model", "unknown"))
            vendor = "unknown"
            class_name = instance.__class__.__name__.lower()
            if "openai" in class_name:
                vendor = "openai"
            elif "anthropic" in class_name:
                vendor = "anthropic"

            span_name = f"llm_call_{str(instance.__class__.__module__.split('.') + [instance.__class__.__name__])}"

            with _auto_span(
                span_name,
                {
                    "llm.model_name": model_name,
                    "llm.vendor": vendor,
                    "llm.async": True,
                    "langchain.model_type": instance.__class__.__name__,
                },
                stage=ValiqorStage.LLM_CALL,
                span_kind=ValiqorSpanKind.LLM_CALL,
            ) as span:

                if tracer:
                    self._add_langchain_user_message(tracer, input_data, span)

                result = await original_func(instance, input_data, *args, **kwargs)

                # Add AI message to trace
                if tracer and hasattr(result, "content"):
                    ai_message = {
                        "type": "ai",
                        "id": str(uuid.uuid4()),
                        "content": getattr(result, "content", ""),
                        "response_metadata": {
                            "model_name": model_name,
                            "llm.vendor": vendor,
                            "async": True,
                        },
                        "tool_calls": [],
                        "invalid_tool_calls": [],
                        "span_id": getattr(span, "span_id", None),
                    }
                    tracer.add_message(ai_message, span_id=getattr(span, "span_id", None))

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("langchain_ainvoke_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    def _trace_chain_call(self, original_func, instance, input_data, *args, **kwargs):
        """Trace LangChain chain call"""
        tracer = _ensure_tracer()

        trace_started = _ensure_auto_trace(
            "LangChain Chain",
            {
                "chain_type": instance.__class__.__name__,
                "input_preview": str(input_data)[:100] + "...",
            },
            is_workflow_entry=True,
        )

        try:
            with _auto_span(
                "langchain_chain",
                {
                    "langchain.chain_type": instance.__class__.__name__,
                    "langchain.input_type": type(input_data).__name__,
                },
                stage=ValiqorStage.ORCHESTRATION,
                span_kind=ValiqorSpanKind.WORKFLOW_NODE,
            ) as span:

                # Add user message to trace BEFORE making the chain call
                if tracer:
                    self._add_langchain_user_message(tracer, input_data, span)

                result = original_func(instance, input_data, *args, **kwargs)

                span.add_event(
                    "chain_completed", {"output_type": type(result).__name__ if result else "None"}
                )

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("chain_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    async def _trace_chain_async_call(self, original_func, instance, input_data, *args, **kwargs):
        """Trace LangChain chain async call (ainvoke)"""
        tracer = _ensure_tracer()

        trace_started = _ensure_auto_trace(
            "LangChain Chain (Async)",
            {
                "chain_type": instance.__class__.__name__,
                "input_preview": str(input_data)[:100] + "...",
            },
            is_workflow_entry=True,
        )

        try:
            with _auto_span(
                "langchain_chain",
                {
                    "langchain.chain_type": instance.__class__.__name__,
                    "langchain.input_type": type(input_data).__name__,
                    "langchain.async": True,
                },
                stage=ValiqorStage.ORCHESTRATION,
                span_kind=ValiqorSpanKind.WORKFLOW_NODE,
            ) as span:

                if tracer:
                    self._add_langchain_user_message(tracer, input_data, span)

                result = await original_func(instance, input_data, *args, **kwargs)

                span.add_event(
                    "chain_completed", {"output_type": type(result).__name__ if result else "None"}
                )

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("chain_async_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    def _trace_tool_call(self, original_func, instance, *args, **kwargs):
        """Trace LangChain tool execution via _run method"""
        tracer = _ensure_tracer()

        tool_name = getattr(instance, "name", instance.__class__.__name__)
        
        # Generate operation key for re-entry guard
        args_hash = hash(str(args)[:100]) if args else 0
        operation_key = f"tool:{tool_name}:{args_hash}"
        
        # Check if this operation is already active (prevents duplicate tracing)
        if _TraceContext.is_operation_active(operation_key):
            _debug_print(f"🔧 [TOOL_RUN] Skipping duplicate trace for '{tool_name}' - already active")
            return original_func(instance, *args, **kwargs)
        
        # Start the operation
        if not _TraceContext.start_operation(operation_key):
            _debug_print(f"🔧 [TOOL_RUN] Could not start operation for '{tool_name}'")
            return original_func(instance, *args, **kwargs)
        
        _debug_print(f"🔧 [TOOL_RUN] _trace_tool_call called for: '{tool_name}'")

        try:
            # Check if this is a retriever tool - if so, use the RAG-aware tracing
            is_retriever_tool = self._detect_retriever_tool(
                instance, tool_name, args[0] if args else None
            )
            _debug_print(f"🔧 [TOOL_RUN] is_retriever_tool={is_retriever_tool}")

            if is_retriever_tool and tracer:
                # Use RAG-aware tracing for retriever tools
                return self._trace_retriever_tool_run(original_func, instance, *args, **kwargs)

            trace_started = _ensure_auto_trace(
                f"Tool: {tool_name}",
                {"tool_name": tool_name, "tool_args": str(args)[:200] + "..." if args else ""},
                is_workflow_entry=False,
            )

            try:
                with _auto_span(
                    "tool_execution",
                    {
                        "tool.name": tool_name,
                        "tool.type": instance.__class__.__name__,
                        "tool.args_count": len(args),
                    },
                    stage=ValiqorStage.TOOL_CALL,
                    span_kind=ValiqorSpanKind.TOOL,
                ) as span:

                    result = original_func(instance, *args, **kwargs)

                    span.add_event(
                        "tool_completed",
                        {
                            "result_type": type(result).__name__,
                            "result_preview": str(result)[:200] + "..." if result else "",
                        },
                    )

                    # Mark this tool as traced to prevent duplicate from ToolNode
                    _TraceContext.mark_tool_traced(tool_name, args_hash)

                    return result

            except Exception as e:
                if "span" in locals():
                    span.add_event("tool_error", {"error": str(e)})
                raise
            finally:
                if trace_started:
                    _end_auto_trace({"status": "success"})
        finally:
            # Always end the operation to allow future calls
            _TraceContext.end_operation(operation_key)

    async def _trace_tool_call_async(self, original_func, instance, *args, **kwargs):
        """Trace LangChain tool execution via _arun method (async version)"""
        tracer = _ensure_tracer()

        tool_name = getattr(instance, "name", instance.__class__.__name__)
        
        # Generate operation key for re-entry guard
        args_hash = hash(str(args)[:100]) if args else 0
        operation_key = f"tool_async:{tool_name}:{args_hash}"
        
        # Check if this operation is already active (prevents duplicate tracing)
        if _TraceContext.is_operation_active(operation_key):
            _debug_print(f"🔧 [TOOL_ARUN] Skipping duplicate trace for '{tool_name}' - already active")
            return await original_func(instance, *args, **kwargs)
        
        # Start the operation
        if not _TraceContext.start_operation(operation_key):
            _debug_print(f"🔧 [TOOL_ARUN] Could not start operation for '{tool_name}'")
            return await original_func(instance, *args, **kwargs)
        
        _debug_print(f"🔧 [TOOL_ARUN] _trace_tool_call_async called for: '{tool_name}'")

        try:
            # Check if this is a retriever tool - if so, use the RAG-aware tracing
            is_retriever_tool = self._detect_retriever_tool(
                instance, tool_name, args[0] if args else None
            )
            _debug_print(f"🔧 [TOOL_ARUN] is_retriever_tool={is_retriever_tool}")

            if is_retriever_tool and tracer:
                # Use RAG-aware tracing for retriever tools
                return await self._trace_retriever_tool_run_async(original_func, instance, *args, **kwargs)

            trace_started = _ensure_auto_trace(
                f"Tool: {tool_name}",
                {"tool_name": tool_name, "tool_args": str(args)[:200] + "..." if args else ""},
                is_workflow_entry=False,
            )

            try:
                with _auto_span(
                    "tool_execution",
                    {
                        "tool.name": tool_name,
                        "tool.type": instance.__class__.__name__,
                        "tool.args_count": len(args),
                    },
                    stage=ValiqorStage.TOOL_CALL,
                    span_kind=ValiqorSpanKind.TOOL,
                ) as span:

                    result = await original_func(instance, *args, **kwargs)

                    span.add_event(
                        "tool_completed",
                        {
                            "result_type": type(result).__name__,
                            "result_preview": str(result)[:200] + "..." if result else "",
                        },
                    )

                    return result

            except Exception as e:
                if "span" in locals():
                    span.add_event("tool_error", {"error": str(e)})
                raise
            finally:
                if trace_started:
                    _end_auto_trace({"status": "success"})
        finally:
            # Always end the operation to allow future calls
            _TraceContext.end_operation(operation_key)

    def _trace_retriever_tool_run(self, original_func, instance, *args, **kwargs):
        """Trace retriever tool execution via _run method with RAG-aware span creation.

        This handles the case where ToolNode calls tool._run() directly.
        """
        tracer = _ensure_tracer()
        tool_name = getattr(instance, "name", instance.__class__.__name__)

        # Extract query from args
        query = str(args[0]) if args else ""
        import time

        _debug_print(f"🔧 [RETRIEVER_RUN] Creating RAG span for '{tool_name}' via _run()")

        try:
            with _auto_span(
                tool_name,
                {
                    "rag.operation": "retrieval",
                    "rag.retriever_type": f"ToolWrapped_{tool_name}",
                    "rag.query": query[:500] if query else "",
                    "rag.documents_retrieved": 0,
                    "rag.via_cache": True,
                    "rag.embedding_model": "unknown",
                    "rag.top_k": 0,
                    "rag.hit_count": 0,
                    "message_id": f"tool-msg-{str(uuid.uuid4())[:8]}",
                },
                stage=ValiqorStage.RETRIEVAL,
                span_kind=ValiqorSpanKind.RETRIEVER,
                is_rag_span=True,
            ) as rag_span:

                _debug_print(
                    f"🔧 [RETRIEVER_RUN] RAG span created: {getattr(rag_span, 'span_id', 'unknown')}"
                )

                # Execute the tool
                start_time = time.time()
                result = original_func(instance, *args, **kwargs)
                end_time = time.time()
                latency_ms = (end_time - start_time) * 1000

                # Extract hits from result
                hits = self._extract_hits_from_result(result, tool_name)
                _debug_print(f"🔧 [RETRIEVER_RUN] Extracted {len(hits)} hits")

                # Update span attributes
                rag_span.set_attribute("rag.documents_retrieved", len(hits))
                rag_span.set_attribute("rag.top_k", len(hits))
                rag_span.set_attribute("rag.hit_count", len(hits))
                rag_span.set_attribute("rag.retrieval_latency_ms", latency_ms)

                # Convert hits to DocumentHit objects for RetrievalInfo
                document_hits = []
                for hit in hits:
                    doc_hit = create_document_hit(
                        doc_id=hit.get("doc_id", f"doc_{len(document_hits)+1}"),
                        snippet=hit.get("snippet_preview", ""),
                        score=hit.get("score", 1.0),
                        metadata=hit.get("metadata", {}),
                        rank=hit.get("rank", len(document_hits) + 1),
                    )
                    document_hits.append(doc_hit)

                # Create RetrievalInfo and set on span (this makes it a proper RAG span)
                retrieval_info = RetrievalInfo(
                    retriever=f"ToolWrapped_{tool_name}",
                    embedding_model="unknown",
                    query=query[:500] if query else "",
                    hits=document_hits,
                    top_k=len(hits),
                    latency_ms=latency_ms,
                    total_documents=len(hits),
                )

                # Set retrieval info using proper RAGSpan method if available
                if hasattr(rag_span, "set_retrieval_info"):
                    rag_span.set_retrieval_info(retrieval_info)
                elif hasattr(rag_span, "retrieval_info"):
                    rag_span.retrieval_info = retrieval_info

                # Also store as dict for serialization (backup for regular spans)
                rag_span.retrieval = (
                    retrieval_info.to_dict()
                    if hasattr(retrieval_info, "to_dict")
                    else {
                        "retriever": f"ToolWrapped_{tool_name}",
                        "embedding_model": "unknown",
                        "chunk_size": None,
                        "chunk_overlap": None,
                        "top_k": len(hits),
                        "similarity_threshold": None,
                        "filters": {},
                        "query": query[:500] if query else "",
                        "hits": hits,
                        "latency_ms": latency_ms,
                        "total_documents": len(hits),
                    }
                )

                # Set pipeline stage
                if hasattr(rag_span, "rag_pipeline_stage"):
                    rag_span.rag_pipeline_stage = "retrieval"

                # 🔥 CRITICAL FIX: Add retrieval to trace-level array for instrumented_retrievals tracking
                try:
                    retrieval_record = {
                        "query": query[:500] if query else "",
                        "retriever_type": f"ToolWrapped_{tool_name}",
                        "embedding_model": "unknown",
                        "k": len(hits),
                        "hits": hits,
                        "latency_ms": latency_ms,
                        "filters": {},
                        "timestamp": end_time,
                        "via_tool": True,
                        "start_timestamp": start_time,
                        "end_timestamp": end_time,
                    }
                    tracer.log_extra({"retrieval": retrieval_record})
                    _debug_print(
                        f"📊 [RETRIEVER_RUN] Added retrieval to trace array for '{tool_name}'"
                    )
                except Exception as retrieval_err:
                    _debug_print(
                        f"⚠️ [RETRIEVER_RUN] Could not add retrieval to trace array: {retrieval_err}"
                    )

                # Create tool message
                actual_result = result.content if hasattr(result, "content") else result
                formatted_content = ""
                if hits:
                    formatted_content = f"Retrieved {len(hits)} documents:\n\n"
                    for hit in hits:
                        formatted_content += f"📄 Document {hit['rank']} (ID: {hit['doc_id']}, Score: {hit['score']:.2f}, Source: {hit['metadata'].get('source', 'unknown')}):\n{hit['snippet_preview']}\n\n---\n\n"

                tool_message = {
                    "type": "tool",
                    "id": f"tool-msg-{str(uuid.uuid4())[:8]}",
                    "name": tool_name,
                    "tool_call_id": "",
                    "tool_name": tool_name,
                    "arguments": {"query": query[:500]} if query else {},
                    "content": (
                        formatted_content if formatted_content else str(actual_result)[:1000]
                    ),
                    "status": "success",
                    "latency_ms": latency_ms,
                    "timestamp": _get_current_timestamp(),
                    "response_metadata": {
                        "tool_execution": True,
                        "timestamp": _get_current_timestamp(),
                        "source": "tool_result",
                    },
                    "span_id": getattr(rag_span, "span_id", None),
                    "parent_span_id": _current_workflow_span.get("span_id"),
                    "parent_span_name": _current_workflow_span.get("span_name"),
                }

                tracer.add_message(tool_message, span_id=getattr(rag_span, "span_id", None))
                _debug_print(
                    f"✅ [RETRIEVER_RUN] Created RAG span for '{tool_name}': {rag_span.span_id}"
                )

                # Mark this tool as traced to prevent duplicate from ToolNode
                # Use query for hash to match how ToolNode calculates it (from tool_args dict)
                query_for_hash = query[:100] if query else ""
                args_hash = hash(query_for_hash)
                _TraceContext.mark_tool_traced(tool_name, args_hash)

                return result

        except Exception as e:
            _debug_print(f"⚠️ [RETRIEVER_RUN] Error creating RAG span: {e}")
            import traceback

            traceback.print_exc()
            # Fallback: execute without span
            return original_func(instance, *args, **kwargs)

    async def _trace_retriever_tool_run_async(self, original_func, instance, *args, **kwargs):
        """Trace retriever tool async execution via _arun method with RAG-aware span creation.

        This handles the case where ToolNode calls tool._arun() directly (async version).
        """
        tracer = _ensure_tracer()
        tool_name = getattr(instance, "name", instance.__class__.__name__)

        # Extract query from args
        query = str(args[0]) if args else ""
        import time

        _debug_print(f"🔧 [RETRIEVER_ARUN] Creating RAG span for '{tool_name}' via _arun()")

        try:
            with _auto_span(
                tool_name,
                {
                    "rag.operation": "retrieval",
                    "rag.retriever_type": f"ToolWrapped_{tool_name}",
                    "rag.query": query[:500] if query else "",
                    "rag.documents_retrieved": 0,
                    "rag.via_cache": True,
                    "rag.embedding_model": "unknown",
                    "rag.top_k": 0,
                    "rag.hit_count": 0,
                    "message_id": f"tool-msg-{str(uuid.uuid4())[:8]}",
                },
                stage=ValiqorStage.RETRIEVAL,
                span_kind=ValiqorSpanKind.RETRIEVER,
                is_rag_span=True,
            ) as rag_span:

                _debug_print(
                    f"🔧 [RETRIEVER_ARUN] RAG span created: {getattr(rag_span, 'span_id', 'unknown')}"
                )

                # Execute the tool asynchronously
                start_time = time.time()
                result = await original_func(instance, *args, **kwargs)
                end_time = time.time()
                latency_ms = (end_time - start_time) * 1000

                # Extract hits from result
                hits = self._extract_hits_from_result(result, tool_name)
                _debug_print(f"🔧 [RETRIEVER_ARUN] Extracted {len(hits)} hits")

                # Update span attributes
                rag_span.set_attribute("rag.documents_retrieved", len(hits))
                rag_span.set_attribute("rag.top_k", len(hits))
                rag_span.set_attribute("rag.hit_count", len(hits))
                rag_span.set_attribute("rag.retrieval_latency_ms", latency_ms)

                # Convert hits to DocumentHit objects for RetrievalInfo
                document_hits = []
                for hit in hits:
                    doc_hit = create_document_hit(
                        doc_id=hit.get("doc_id", f"doc_{len(document_hits)+1}"),
                        snippet=hit.get("snippet_preview", ""),
                        score=hit.get("score", 1.0),
                        metadata=hit.get("metadata", {}),
                        rank=hit.get("rank", len(document_hits) + 1),
                    )
                    document_hits.append(doc_hit)

                # Create RetrievalInfo and set on span
                retrieval_info = RetrievalInfo(
                    retriever=f"ToolWrapped_{tool_name}",
                    embedding_model="unknown",
                    query=query[:500] if query else "",
                    hits=document_hits,
                    top_k=len(hits),
                    latency_ms=latency_ms,
                    total_documents=len(hits),
                )

                # Set retrieval info using proper RAGSpan method if available
                if hasattr(rag_span, "set_retrieval_info"):
                    rag_span.set_retrieval_info(retrieval_info)
                elif hasattr(rag_span, "retrieval_info"):
                    rag_span.retrieval_info = retrieval_info

                # Also store as dict for serialization
                rag_span.retrieval = (
                    retrieval_info.to_dict()
                    if hasattr(retrieval_info, "to_dict")
                    else {
                        "retriever": f"ToolWrapped_{tool_name}",
                        "embedding_model": "unknown",
                        "chunk_size": None,
                        "chunk_overlap": None,
                        "top_k": len(hits),
                        "similarity_threshold": None,
                        "filters": {},
                        "query": query[:500] if query else "",
                        "hits": hits,
                        "latency_ms": latency_ms,
                        "total_documents": len(hits),
                    }
                )

                # Set pipeline stage
                if hasattr(rag_span, "rag_pipeline_stage"):
                    rag_span.rag_pipeline_stage = "retrieval"

                # Add retrieval to trace-level array
                try:
                    retrieval_record = {
                        "query": query[:500] if query else "",
                        "retriever_type": f"ToolWrapped_{tool_name}",
                        "embedding_model": "unknown",
                        "k": len(hits),
                        "hits": hits,
                        "latency_ms": latency_ms,
                        "filters": {},
                        "timestamp": end_time,
                        "via_tool": True,
                        "start_timestamp": start_time,
                        "end_timestamp": end_time,
                    }
                    tracer.log_extra({"retrieval": retrieval_record})
                    _debug_print(
                        f"📊 [RETRIEVER_ARUN] Added retrieval to trace array for '{tool_name}'"
                    )
                except Exception as retrieval_err:
                    _debug_print(
                        f"⚠️ [RETRIEVER_ARUN] Could not add retrieval to trace array: {retrieval_err}"
                    )

                # Create tool message
                actual_result = result.content if hasattr(result, "content") else result
                formatted_content = ""
                if hits:
                    formatted_content = f"Retrieved {len(hits)} documents:\n\n"
                    for hit in hits:
                        formatted_content += f"📄 Document {hit['rank']} (ID: {hit['doc_id']}, Score: {hit['score']:.2f}, Source: {hit['metadata'].get('source', 'unknown')}):\n{hit['snippet_preview']}\n\n---\n\n"

                tool_message = {
                    "type": "tool",
                    "id": f"tool-msg-{str(uuid.uuid4())[:8]}",
                    "name": tool_name,
                    "tool_call_id": "",
                    "tool_name": tool_name,
                    "arguments": {"query": query[:500]} if query else {},
                    "content": (
                        formatted_content if formatted_content else str(actual_result)[:1000]
                    ),
                    "status": "success",
                    "latency_ms": latency_ms,
                    "timestamp": _get_current_timestamp(),
                    "response_metadata": {
                        "tool_execution": True,
                        "timestamp": _get_current_timestamp(),
                        "source": "tool_result",
                    },
                    "span_id": getattr(rag_span, "span_id", None),
                    "parent_span_id": _current_workflow_span.get("span_id"),
                    "parent_span_name": _current_workflow_span.get("span_name"),
                }

                tracer.add_message(tool_message, span_id=getattr(rag_span, "span_id", None))
                _debug_print(
                    f"✅ [RETRIEVER_ARUN] Created RAG span for '{tool_name}': {rag_span.span_id}"
                )

                return result

        except Exception as e:
            _debug_print(f"⚠️ [RETRIEVER_ARUN] Error creating RAG span: {e}")
            import traceback

            traceback.print_exc()
            # Fallback: execute without span
            return await original_func(instance, *args, **kwargs)

    def _trace_tool_invoke(self, original_func, instance, input_data, *args, **kwargs):
        """Trace LangChain tool invoke method - CRITICAL for retriever tools.

        🔥 KEY FIX: Create span BEFORE executing tool to maintain proper parent-child hierarchy.
        The span must wrap the tool execution, not be created after it completes.
        """
        tracer = _ensure_tracer()

        tool_name = getattr(instance, "name", instance.__class__.__name__)
        _debug_print(
            f"🔧 [TOOL_INVOKE] Called for tool: '{tool_name}', input_type: {type(input_data).__name__}"
        )

        # Check if this is a retriever tool using multiple detection strategies
        is_retriever_tool = self._detect_retriever_tool(instance, tool_name, input_data)
        _debug_print(
            f"🔧 [TOOL_INVOKE] is_retriever_tool={is_retriever_tool}, tracer={tracer is not None}"
        )

        # For retriever tools, ALWAYS create a span and capture data
        # 🔥 CRITICAL: Create span FIRST, execute tool INSIDE the span context
        if is_retriever_tool and tracer:
            # Extract query from input
            query = str(input_data) if input_data else ""
            import time

            _debug_print(f"🔧 [TOOL_INVOKE] Creating RAG span for '{tool_name}'")

            # 🔥 Create the RAG span BEFORE executing the tool
            # This ensures proper parent-child hierarchy (tool span is child of workflow node span)
            try:
                with _auto_span(
                    tool_name,
                    {
                        "rag.operation": "retrieval",
                        "rag.retriever_type": f"ToolWrapped_{tool_name}",
                        "rag.query": query[:500] if query else "",
                        "rag.documents_retrieved": 0,  # Will update after execution
                        "rag.via_cache": True,
                        "rag.embedding_model": "unknown",
                        "rag.top_k": 0,
                        "rag.hit_count": 0,
                        "message_id": f"tool-msg-{str(uuid.uuid4())[:8]}",
                    },
                    stage=ValiqorStage.RETRIEVAL,
                    span_kind=ValiqorSpanKind.RETRIEVER,
                    is_rag_span=True,
                ) as rag_span:

                    _debug_print(
                        f"🔧 [TOOL_INVOKE] RAG span created: {getattr(rag_span, 'span_id', 'unknown')}"
                    )

                    # Execute the tool INSIDE the span context
                    start_time = time.time()
                    result = original_func(instance, input_data, *args, **kwargs)
                    end_time = time.time()
                    latency_ms = (end_time - start_time) * 1000

                    # Extract document information from result
                    hits = self._extract_hits_from_result(result, tool_name)
                    _debug_print(f"🔧 [TOOL_INVOKE] Extracted {len(hits)} hits from '{tool_name}'")

                    # Update span attributes with actual results
                    rag_span.set_attribute("rag.documents_retrieved", len(hits))
                    rag_span.set_attribute("rag.top_k", len(hits))
                    rag_span.set_attribute("rag.hit_count", len(hits))
                    rag_span.set_attribute("rag.retrieval_latency_ms", latency_ms)

                    # Convert hits to DocumentHit objects for RetrievalInfo
                    document_hits = []
                    for hit in hits:
                        doc_hit = create_document_hit(
                            doc_id=hit.get("doc_id", f"doc_{len(document_hits)+1}"),
                            snippet=hit.get("snippet_preview", ""),
                            score=hit.get("score", 1.0),
                            metadata=hit.get("metadata", {}),
                            rank=hit.get("rank", len(document_hits) + 1),
                        )
                        document_hits.append(doc_hit)

                    # Create RetrievalInfo and set on span (this makes it a proper RAG span)
                    retrieval_info = RetrievalInfo(
                        retriever=f"ToolWrapped_{tool_name}",
                        embedding_model="unknown",
                        query=query[:500] if query else "",
                        hits=document_hits,
                        top_k=len(hits),
                        latency_ms=latency_ms,
                        total_documents=len(hits),
                    )

                    # Set retrieval info using proper RAGSpan method if available
                    if hasattr(rag_span, "set_retrieval_info"):
                        rag_span.set_retrieval_info(retrieval_info)
                    elif hasattr(rag_span, "retrieval_info"):
                        rag_span.retrieval_info = retrieval_info

                    # Also store as dict for serialization (backup for regular spans)
                    rag_span.retrieval = (
                        retrieval_info.to_dict()
                        if hasattr(retrieval_info, "to_dict")
                        else {
                            "retriever": f"ToolWrapped_{tool_name}",
                            "embedding_model": "unknown",
                            "chunk_size": None,
                            "chunk_overlap": None,
                            "top_k": len(hits),
                            "similarity_threshold": None,
                            "filters": {},
                            "query": query[:500] if query else "",
                            "hits": hits,
                            "latency_ms": latency_ms,
                            "total_documents": len(hits),
                        }
                    )

                    # Set pipeline stage
                    if hasattr(rag_span, "rag_pipeline_stage"):
                        rag_span.rag_pipeline_stage = "retrieval"

                    # 🔥 CRITICAL FIX: Add retrieval to trace-level array for instrumented_retrievals tracking
                    # This populates trace["retrievals"] which feeds into rag_metrics
                    try:
                        retrieval_record = {
                            "query": query[:500] if query else "",
                            "retriever_type": f"ToolWrapped_{tool_name}",
                            "embedding_model": "unknown",
                            "k": len(hits),
                            "hits": hits,
                            "latency_ms": latency_ms,
                            "filters": {},
                            "timestamp": end_time,
                            "via_tool": True,
                            "start_timestamp": start_time,
                            "end_timestamp": end_time,
                        }
                        tracer.log_extra({"retrieval": retrieval_record})
                        _debug_print(
                            f"📊 [TOOL_INVOKE] Added retrieval to trace array for '{tool_name}'"
                        )
                    except Exception as retrieval_err:
                        _debug_print(
                            f"⚠️ [TOOL_INVOKE] Could not add retrieval to trace array: {retrieval_err}"
                        )

                    # Format content for tool message
                    actual_result = result.content if hasattr(result, "content") else result
                    formatted_content = ""
                    if hits:
                        formatted_content = f"Retrieved {len(hits)} documents:\n\n"
                        for hit in hits:
                            formatted_content += f"📄 Document {hit['rank']} (ID: {hit['doc_id']}, Score: {hit['score']:.2f}, Source: {hit['metadata'].get('source', 'unknown')}):\n{hit['snippet_preview']}\n\n---\n\n"

                    # Create and add the tool message
                    tool_message = {
                        "type": "tool",
                        "id": f"tool-msg-{str(uuid.uuid4())[:8]}",
                        "name": tool_name,
                        "tool_call_id": "",
                        "tool_name": tool_name,
                        "arguments": {"query": query[:500]} if query else {},
                        "content": (
                            formatted_content if formatted_content else str(actual_result)[:1000]
                        ),
                        "status": "success",
                        "latency_ms": latency_ms,
                        "timestamp": _get_current_timestamp(),
                        "response_metadata": {
                            "tool_execution": True,
                            "related_message_id": "",
                            "timestamp": _get_current_timestamp(),
                            "source": "tool_result",
                            "llm.vendor": "unknown",
                            "request_id": f"req_{str(uuid.uuid4())[:8]}-{str(uuid.uuid4())[:3]}",
                            "endpoint_url": "https://api.unknown.com/v1/completions",
                        },
                        "span_id": getattr(rag_span, "span_id", None),
                        "parent_span_id": _current_workflow_span.get("span_id"),
                        "parent_span_name": _current_workflow_span.get("span_name"),
                        "additional_kwargs": {},
                        "tool_calls": [],
                        "invalid_tool_calls": [],
                        "example": False,
                    }

                    tracer.add_message(tool_message, span_id=getattr(rag_span, "span_id", None))
                    _debug_print(
                        f"✅ Created RAG span for retriever tool '{tool_name}': {rag_span.span_id}"
                    )

                    return result

            except Exception as e:
                _debug_print(f"⚠️ Could not create RAG span for '{tool_name}': {e}")
                # Fallback: execute tool without span
                return original_func(instance, input_data, *args, **kwargs)

        # For non-retriever tools, try to create spans if possible
        try:
            # If there's an active trace, use spans for better tracing
            with _auto_span(
                "tool_invoke",
                {
                    "tool.name": tool_name,
                    "tool.type": instance.__class__.__name__,
                    "tool.input_type": type(input_data).__name__,
                    "tool.is_retriever": is_retriever_tool,
                },
                stage=ValiqorStage.TOOL_CALL,
                span_kind=ValiqorSpanKind.TOOL,
            ) as span:

                result = original_func(instance, input_data, *args, **kwargs)

                span.add_event(
                    "tool_invoke_completed",
                    {
                        "result_type": type(result).__name__,
                        "result_length": len(str(result)) if result else 0,
                        "is_retriever_tool": is_retriever_tool,
                    },
                )

                return result

        except Exception as e:
            # If span creation fails (no active trace), just execute the tool
            if "No active trace" in str(e):
                return original_func(instance, input_data, *args, **kwargs)
            else:
                if "span" in locals():
                    span.add_event("tool_invoke_error", {"error": str(e)})
                raise

    def _extract_hits_from_result(self, result, tool_name):
        """Extract document hits from tool result - handles various result formats.

        This is a generic helper that works with:
        - TavilySearchResults (list of dicts with url, content)
        - Vector store results (list of Documents)
        - String results (split by separators)
        - ToolMessage wrappers
        """
        hits = []

        # Extract actual content from ToolMessage if that's what we got
        actual_result = result
        if hasattr(result, "content"):
            actual_result = result.content

        if not actual_result:
            return hits

        if isinstance(actual_result, list):
            # Handle list of search results (like TavilySearchResults, web search, etc.)
            for i, item in enumerate(actual_result[:5]):  # Take first 5 results
                if isinstance(item, dict):
                    # Extract from dict format (typical web search results)
                    hits.append(
                        {
                            "doc_id": f"web_result_{i+1}",
                            "rank": i + 1,
                            "score": 1.0 - (i * 0.1),  # Simulate decreasing relevance
                            "snippet_preview": str(
                                item.get("content", item.get("snippet", str(item)))
                            )[:300],
                            "metadata": {
                                "source": tool_name,
                                "title": item.get("title", ""),
                                "url": item.get("url", ""),
                                "result_index": i + 1,
                            },
                        }
                    )
                elif hasattr(item, "page_content"):
                    # Handle LangChain Document objects
                    hits.append(
                        {
                            "doc_id": f"doc_{i+1}",
                            "rank": i + 1,
                            "score": getattr(item, "score", 1.0 - (i * 0.1)),
                            "snippet_preview": str(item.page_content)[:300],
                            "metadata": {"source": tool_name, **getattr(item, "metadata", {})},
                        }
                    )
                else:
                    hits.append(
                        {
                            "doc_id": f"result_{i+1}",
                            "rank": i + 1,
                            "score": 1.0 - (i * 0.1),
                            "snippet_preview": str(item)[:300],
                            "metadata": {"source": tool_name, "item_index": i + 1},
                        }
                    )
        elif isinstance(actual_result, str):
            # Parse string result for document-like information
            # Split by common document separators used by LangChain retrievers
            doc_separators = ["\n\n---\n\n", "\n\n", "\n"]
            chunks = [actual_result]

            # Try each separator to split documents
            for sep in doc_separators:
                if sep in actual_result:
                    chunks = actual_result.split(sep)
                    break

            # Extract up to 5 document chunks
            for i, chunk in enumerate(chunks[:5]):
                if chunk.strip():
                    hits.append(
                        {
                            "doc_id": f"doc_{i+1}",
                            "rank": i + 1,
                            "score": 1.0 - (i * 0.1),
                            "snippet_preview": chunk.strip()[:300],
                            "metadata": {"source": tool_name, "chunk_index": i + 1},
                        }
                    )

        return hits

    def _trace_tool_node_call(self, original_func, instance, state, *args, **kwargs):
        """Trace LangGraph ToolNode execution - capture tool results with individual spans"""
        tracer = _ensure_tracer()
        import time

        start_time = time.time()

        # Extract pending tool calls from state (AI message with tool_calls)
        pending_tool_calls = {}
        if isinstance(state, dict) and "messages" in state:
            for msg in reversed(state["messages"]):  # Check from most recent
                if hasattr(msg, "tool_calls") and msg.tool_calls:
                    for tc in msg.tool_calls:
                        tc_id = (
                            getattr(tc, "id", "") or tc.get("id", "")
                            if isinstance(tc, dict)
                            else ""
                        )
                        tc_name = (
                            getattr(tc, "name", "") or tc.get("name", "")
                            if isinstance(tc, dict)
                            else ""
                        )
                        tc_args = (
                            getattr(tc, "args", {}) or tc.get("args", {})
                            if isinstance(tc, dict)
                            else {}
                        )
                        pending_tool_calls[tc_id] = {
                            "name": tc_name,
                            "args": tc_args,
                            "start_time": time.time(),
                        }
                    break  # Found the AI message with tool calls

        try:
            result = original_func(instance, state, *args, **kwargs)
            end_time = time.time()

            # Extract tool results from the result and create individual spans
            if tracer and isinstance(result, dict) and "messages" in result:
                messages = result["messages"]

                # Process tool result messages
                for msg in messages:
                    if hasattr(msg, "type") and msg.type == "tool":
                        tool_name = getattr(msg, "name", "")
                        tool_call_id = getattr(msg, "tool_call_id", "")
                        tool_result = getattr(msg, "content", "")
                        tool_args = pending_tool_calls.get(tool_call_id, {}).get("args", {})
                        tool_start = pending_tool_calls.get(tool_call_id, {}).get(
                            "start_time", start_time
                        )

                        # Check if this tool was already traced via _trace_tool_call
                        # This prevents duplicate spans/messages when StructuredTool._run is patched
                        # Use query value for hash to match _trace_retriever_tool_run
                        query_value = ""
                        if tool_args and isinstance(tool_args, dict):
                            query_value = str(tool_args.get("query", ""))[:100]
                        args_hash = hash(query_value)
                        if _TraceContext.is_tool_traced(tool_name, args_hash):
                            _debug_print(f"🔧 [TOOL_NODE] Skipping '{tool_name}' - already traced via _run")
                            continue

                        # Check if this is a retrieval/RAG tool
                        is_rag_tool = self._is_rag_tool(tool_name, tool_result)

                        # Create individual span for this tool
                        tool_latency_ms = (end_time - tool_start) * 1000

                        if is_rag_tool:
                            # Create RAG span for retrieval tools
                            self._create_rag_span_for_tool(
                                tracer,
                                tool_name,
                                tool_call_id,
                                tool_args,
                                tool_result,
                                tool_latency_ms,
                            )
                        else:
                            # Create regular tool span
                            with _auto_span(
                                tool_name,
                                {
                                    "tool.name": tool_name,
                                    "tool.call_id": tool_call_id,
                                    "tool.type": "langgraph_tool",
                                },
                                stage=ValiqorStage.TOOL_CALL,
                                span_kind=ValiqorSpanKind.TOOL,
                            ) as tool_span:
                                # Add tool message
                                tool_message = {
                                    "type": "tool",
                                    "id": f"tool-msg-{str(uuid.uuid4())[:8]}",
                                    "tool_call_id": tool_call_id,
                                    "tool_name": tool_name,
                                    "arguments": tool_args,
                                    "result": str(tool_result)[:1000],
                                    "status": "success",
                                    "latency_ms": tool_latency_ms,
                                    "timestamp": _get_current_timestamp(),
                                    "response_metadata": {
                                        "tool_execution": True,
                                        "llm.vendor": "unknown",
                                    },
                                    "additional_kwargs": {},
                                    "tool_calls": [],
                                    "invalid_tool_calls": [],
                                    "name": tool_name,
                                    "example": False,
                                }
                                tracer.add_message(
                                    tool_message, span_id=getattr(tool_span, "span_id", None)
                                )

            return result

        except Exception as e:
            raise

    def _is_rag_tool(self, tool_name: str, tool_result) -> bool:
        """
        Determine if a tool is a RAG/retrieval tool based on generic patterns.
        Uses name patterns and result structure to detect retrieval operations.
        """
        name_lower = tool_name.lower()

        # Name-based detection - common retrieval patterns
        rag_indicators = [
            "search",
            "retriev",
            "query",
            "find",
            "lookup",
            "fetch",
            "docs",
            "document",
            "knowledge",
            "vectorstore",
            "vector",
            "web",
            "tavily",
            "bing",
            "google",
            "rag",
            "index",
        ]

        if any(indicator in name_lower for indicator in rag_indicators):
            return True

        # Result-based detection - check if result looks like search results
        if tool_result:
            result_str = str(tool_result).lower()
            # Check for URL patterns or document-like structures
            if "url" in result_str or "content" in result_str or "snippet" in result_str:
                return True
            # Check for list of results (common in search tools)
            if isinstance(tool_result, list) and len(tool_result) > 0:
                if isinstance(tool_result[0], dict):
                    return True

        return False

    def _create_rag_span_for_tool(
        self,
        tracer,
        tool_name: str,
        tool_call_id: str,
        tool_args: dict,
        tool_result,
        latency_ms: float,
    ):
        """
        Create a RAG span for retrieval tool results with proper hit extraction.
        """
        import time

        # Extract query from tool args
        query = tool_args.get("query", "") or tool_args.get("q", "") or str(tool_args)

        # Parse results into hits
        hits = []
        if tool_result:
            if isinstance(tool_result, list):
                for i, item in enumerate(tool_result[:5]):  # Take first 5
                    if isinstance(item, dict):
                        hits.append(
                            {
                                "doc_id": f"result_{i+1}",
                                "rank": i + 1,
                                "score": 1.0 - (i * 0.1),
                                "snippet_preview": str(
                                    item.get("content", item.get("snippet", str(item)))
                                )[:300],
                                "metadata": {
                                    "source": tool_name,
                                    "title": item.get("title", ""),
                                    "url": item.get("url", ""),
                                    "result_index": i + 1,
                                },
                            }
                        )
                    else:
                        hits.append(
                            {
                                "doc_id": f"result_{i+1}",
                                "rank": i + 1,
                                "score": 1.0 - (i * 0.1),
                                "snippet_preview": str(item)[:300],
                                "metadata": {"source": tool_name, "item_index": i + 1},
                            }
                        )
            elif isinstance(tool_result, str):
                # Parse string result
                chunks = tool_result.split("\n\n")[:5]
                for i, chunk in enumerate(chunks):
                    if chunk.strip():
                        hits.append(
                            {
                                "doc_id": f"doc_{i+1}",
                                "rank": i + 1,
                                "score": 1.0 - (i * 0.1),
                                "snippet_preview": chunk.strip()[:300],
                                "metadata": {"source": tool_name, "chunk_index": i + 1},
                            }
                        )

        # Create the RAG span
        with _auto_span(
            tool_name,
            {
                "rag.operation": "retrieval",
                "rag.retriever_type": f"ToolWrapped_{tool_name}",
                "rag.query": query[:500],
                "rag.documents_retrieved": len(hits),
                "rag.embedding_model": "unknown",
                "rag.top_k": len(hits),
                "rag.hit_count": len(hits),
                "rag.retrieval_latency_ms": latency_ms,
            },
            stage=ValiqorStage.RETRIEVAL,
            span_kind=ValiqorSpanKind.RETRIEVER,
            is_rag_span=True,
        ) as rag_span:

            # Add the retrieval data to the span
            rag_span.retrieval = {
                "retriever": f"ToolWrapped_{tool_name}",
                "embedding_model": "unknown",
                "top_k": len(hits),
                "query": query[:500],
                "hits": hits,
                "latency_ms": latency_ms,
                "total_documents": len(hits),
            }

            # Add tool message with RAG context
            tool_message = {
                "type": "tool",
                "id": f"tool-msg-{str(uuid.uuid4())[:8]}",
                "tool_call_id": tool_call_id,
                "tool_name": tool_name,
                "arguments": tool_args,
                "result": str(tool_result)[:1000],
                "status": "success",
                "latency_ms": latency_ms,
                "timestamp": _get_current_timestamp(),
                "response_metadata": {
                    "tool_execution": True,
                    "rag_operation": True,
                    "llm.vendor": "unknown",
                },
                "additional_kwargs": {},
                "tool_calls": [],
                "invalid_tool_calls": [],
                "name": None,
                "example": False,
            }
            tracer.add_message(tool_message, span_id=getattr(rag_span, "span_id", None))

            # Format retrieved content for display
            if hits:
                formatted_content = f"Retrieved {len(hits)} documents:\n\n"
                for hit in hits:
                    formatted_content += f"📄 Document {hit['rank']} (ID: {hit['doc_id']}, Score: {hit['score']:.2f}, Source: {hit['metadata'].get('source', 'unknown')}):\n{hit['snippet_preview']}\n\n---\n\n"
                tool_message["content"] = formatted_content

    def _extract_and_add_human_message(self, tracer, input_data, span_id=None):
        """
        Extract human message from LangGraph input state and add it to the trace.
        Supports various LangGraph state patterns (MessagesState, TypedDict with messages, etc.)
        
        Args:
            tracer: The tracer instance
            input_data: The input data from LangGraph
            span_id: Optional span_id to associate the message with (typically root span)
        """
        try:
            messages = None
            user_content = None

            # Pattern 1: Dict with "messages" key (common MessagesState pattern)
            if isinstance(input_data, dict) and "messages" in input_data:
                messages = input_data["messages"]
            # Pattern 2: Dict with "input" key containing user query
            elif isinstance(input_data, dict) and "input" in input_data:
                user_content = input_data["input"]
            # Pattern 3: Dict with "question" or "query" key
            elif isinstance(input_data, dict):
                user_content = (
                    input_data.get("question")
                    or input_data.get("query")
                    or input_data.get("user_query")
                )
            # Pattern 4: Direct list of messages
            elif isinstance(input_data, list):
                messages = input_data

            # Extract content from messages list
            if messages and not user_content:
                for msg in messages:
                    # Check if it's a HumanMessage object
                    msg_type = type(msg).__name__
                    if msg_type == "HumanMessage" or (hasattr(msg, "type") and msg.type == "human"):
                        user_content = getattr(msg, "content", str(msg))
                        break
                    # Check if it's a dict with type == "human"
                    elif isinstance(msg, dict) and msg.get("type") == "human":
                        user_content = msg.get("content", "")
                        break
                    # Check for first message if it looks like user input (tuple format from some LangGraph apps)
                    elif isinstance(msg, tuple) and len(msg) >= 2 and msg[0] in ("human", "user"):
                        user_content = msg[1]
                        break

            # Add the human message to the trace
            if user_content:
                human_message = {
                    "type": "human",
                    "id": f"human-{str(uuid.uuid4())}",
                    "content": str(user_content),
                    "name": None,
                    "example": False,
                    "additional_kwargs": {},
                    "response_metadata": {
                        "timestamp": _get_current_timestamp(),
                        "source": "user_input",
                        "llm.vendor": "unknown",
                        "request_id": f"req_{str(uuid.uuid4())[:8]}",
                        "endpoint_url": "https://api.unknown.com/v1/completions",
                    },
                    "tool_calls": [],
                    "invalid_tool_calls": [],
                }
                # Pass span_id to associate message with root span for proper event tracking
                tracer.add_message(human_message, span_id=span_id)
                _debug_print(f"[Autolog] Added human message: {str(user_content)[:100]}...")
        except Exception as e:
            _debug_print(f"[Autolog] Failed to extract human message: {e}")

    def _trace_graph_call(self, original_func, instance, input_data, *args, **kwargs):
        """Trace LangGraph execution"""
        tracer = _ensure_tracer()

        graph_name = getattr(instance, "name", "LangGraph")

        trace_started = _ensure_auto_trace(
            "agentic_workflow",
            {
                "graph_name": graph_name,
                "graph_type": instance.__class__.__name__,
                "input_preview": str(input_data)[:200] + "...",
            },
            is_workflow_entry=True,
        )

        # Extract and add human message from LangGraph input state (MessagesState pattern)
        # Get root span_id to associate user message with root span for proper event tracking
        if tracer:
            trace = tracer._get_current_trace()
            root_span_id = trace.get("root_span_id") if trace else None
            self._extract_and_add_human_message(tracer, input_data, span_id=root_span_id)

        try:
            with _auto_span(
                "graph_execution",
                {
                    "graph.name": graph_name,
                    "graph.type": instance.__class__.__name__,
                    "graph.input_type": type(input_data).__name__,
                },
                stage=ValiqorStage.ORCHESTRATION,
                span_kind=ValiqorSpanKind.WORKFLOW_NODE,
            ) as span:

                result = original_func(instance, input_data, *args, **kwargs)

                span.add_event(
                    "graph_completed",
                    {
                        "output_type": type(result).__name__ if result else "None",
                        "has_messages": "messages" in result if isinstance(result, dict) else False,
                    },
                )

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("graph_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    def _trace_graph_stream(self, original_func, instance, input_data, *args, **kwargs):
        """Trace LangGraph streaming execution"""
        tracer = _ensure_tracer()

        graph_name = getattr(instance, "name", "LangGraph")

        trace_started = _ensure_auto_trace(
            f"Graph Stream: {graph_name}",
            {
                "graph_type": instance.__class__.__name__,
                "streaming": True,
                "input_preview": str(input_data)[:200] + "...",
            },
            is_workflow_entry=True,
        )

        # Extract and add human message from LangGraph input state (MessagesState pattern)
        # Get root span_id to associate user message with root span for proper event tracking
        if tracer:
            trace = tracer._get_current_trace()
            root_span_id = trace.get("root_span_id") if trace else None
            self._extract_and_add_human_message(tracer, input_data, span_id=root_span_id)

        try:
            with _auto_span(
                "graph_stream",
                {
                    "graph.name": graph_name,
                    "graph.type": instance.__class__.__name__,
                    "graph.streaming": True,
                },
                stage=ValiqorStage.ORCHESTRATION,
                span_kind=ValiqorSpanKind.WORKFLOW_NODE,
            ) as span:

                stream = original_func(instance, input_data, *args, **kwargs)

                # Wrap the stream to trace individual chunks
                def traced_stream():
                    chunk_count = 0
                    for chunk in stream:
                        chunk_count += 1
                        span.add_event(
                            "stream_chunk",
                            {"chunk_number": chunk_count, "chunk_type": type(chunk).__name__},
                        )
                        yield chunk

                    span.add_event("stream_completed", {"total_chunks": chunk_count})

                return traced_stream()

        except Exception as e:
            if "span" in locals():
                span.add_event("graph_stream_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    async def _trace_graph_async_call(self, original_func, instance, input_data, *args, **kwargs):
        """Trace LangGraph async execution (ainvoke)"""
        tracer = _ensure_tracer()

        graph_name = getattr(instance, "name", "LangGraph")

        trace_started = _ensure_auto_trace(
            "agentic_workflow",
            {
                "graph_name": graph_name,
                "graph_type": instance.__class__.__name__,
                "input_preview": str(input_data)[:200] + "...",
                "async": True,
            },
            is_workflow_entry=True,
        )

        if tracer:
            trace = tracer._get_current_trace()
            root_span_id = trace.get("root_span_id") if trace else None
            self._extract_and_add_human_message(tracer, input_data, span_id=root_span_id)

        try:
            with _auto_span(
                "graph_execution",
                {
                    "graph.name": graph_name,
                    "graph.type": instance.__class__.__name__,
                    "graph.input_type": type(input_data).__name__,
                    "graph.async": True,
                },
                stage=ValiqorStage.ORCHESTRATION,
                span_kind=ValiqorSpanKind.WORKFLOW_NODE,
            ) as span:

                result = await original_func(instance, input_data, *args, **kwargs)

                span.add_event(
                    "graph_completed",
                    {
                        "output_type": type(result).__name__ if result else "None",
                        "has_messages": "messages" in result if isinstance(result, dict) else False,
                    },
                )

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("graph_async_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    async def _trace_graph_async_stream(self, original_func, instance, input_data, *args, **kwargs):
        """Trace LangGraph async streaming execution (astream)"""
        tracer = _ensure_tracer()

        graph_name = getattr(instance, "name", "LangGraph")

        trace_started = _ensure_auto_trace(
            f"Graph Stream: {graph_name}",
            {
                "graph_type": instance.__class__.__name__,
                "streaming": True,
                "async": True,
                "input_preview": str(input_data)[:200] + "...",
            },
            is_workflow_entry=True,
        )

        if tracer:
            trace = tracer._get_current_trace()
            root_span_id = trace.get("root_span_id") if trace else None
            self._extract_and_add_human_message(tracer, input_data, span_id=root_span_id)

        try:
            with _auto_span(
                "graph_stream",
                {
                    "graph.name": graph_name,
                    "graph.type": instance.__class__.__name__,
                    "graph.streaming": True,
                    "graph.async": True,
                },
                stage=ValiqorStage.ORCHESTRATION,
                span_kind=ValiqorSpanKind.WORKFLOW_NODE,
            ) as span:

                stream = original_func(instance, input_data, *args, **kwargs)

                chunk_count = 0
                async for chunk in stream:
                    chunk_count += 1
                    span.add_event(
                        "stream_chunk",
                        {"chunk_number": chunk_count, "chunk_type": type(chunk).__name__},
                    )
                    yield chunk

                span.add_event("stream_completed", {"total_chunks": chunk_count})

        except Exception as e:
            if "span" in locals():
                span.add_event("graph_astream_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})

    def _detect_retriever_tool(self, instance, tool_name, input_data):
        """
        Generic retriever tool detection using multiple strategies.
        This makes the instrumentation portable across different applications.
        """

        # Strategy 1: Name-based detection (common patterns + custom patterns)
        name_indicators = [
            "search",
            "retriev",
            "query",
            "find",
            "lookup",
            "fetch",
            "docs",
            "document",
            "knowledge",
            "vectorstore",
            "vector",
            "embed",
            "similarity",
            "rag",
            "index",
            "web",
            "tavily",
            "google",
            "bing",
            "duckduckgo",
            "serp",
            "browse",
        ]

        # Add custom patterns from configuration
        custom_patterns = _global_config.get("custom_retriever_patterns", {})
        name_indicators.extend(custom_patterns.get("name_indicators", []))

        tool_name_lower = tool_name.lower()

        if any(indicator in tool_name_lower for indicator in name_indicators):
            matched_indicator = next(ind for ind in name_indicators if ind in tool_name_lower)
            return True

        # Strategy 2: Class-based detection (LangChain specific patterns + custom)
        class_name = instance.__class__.__name__
        retriever_classes = [
            "TavilySearchResults",
            "GoogleSearchResults",
            "BingSearchResults",
            "VectorStoreRetriever",
            "EnsembleRetriever",
            "MultiQueryRetriever",
            "DocumentSearch",
            "WebSearch",
            "KnowledgeBase",
        ]

        # Add custom class patterns
        retriever_classes.extend(custom_patterns.get("class_patterns", []))

        if any(cls in class_name for cls in retriever_classes):
            matched_class = next(cls for cls in retriever_classes if cls in class_name)
            return True

        # Strategy 3: Description-based detection (if available)
        description = getattr(instance, "description", "") or getattr(instance, "__doc__", "")
        if description:
            description_lower = description.lower()
            if any(
                indicator in description_lower
                for indicator in ["search", "retrieve", "find", "query"]
            ):
                return True

        # Strategy 4: Input/Output pattern detection
        if input_data:
            input_str = str(input_data).lower()
            # Check if input looks like a search query
            if any(
                keyword in input_str
                for keyword in ["query", "search", "find", "what", "how", "when", "where", "why"]
            ):
                # Additional check: see if it's likely a retrieval tool based on expected output
                try:
                    # Check if the tool typically returns structured data (hint of retrieval)
                    if hasattr(instance, "args_schema") and instance.args_schema:
                        schema_str = str(instance.args_schema).lower()
                        if "query" in schema_str or "search" in schema_str:
                            return True
                except:
                    pass

        # Strategy 5: Module-based detection (check the module path + custom)
        module_name = instance.__class__.__module__
        if module_name:
            module_lower = module_name.lower()
            retrieval_modules = ["tavily", "search", "retrieval", "vectorstore", "rag"]

            # Add custom module patterns
            retrieval_modules.extend(custom_patterns.get("module_patterns", []))

            if any(mod in module_lower for mod in retrieval_modules):
                matched_module = next(mod for mod in retrieval_modules if mod in module_lower)
                return True

        return False


class AgnoInstrumentor(AutoInstrumentor):
    """Agno Agent auto-instrumentor - patches Agno Agent's arun method"""

    def _patch_target_functions(self):
        try:
            from agno.agent import Agent

            # Patch Agent.arun (async method)
            original_arun = Agent.arun
            instrumentor = self

            async def traced_arun(self, *args, **kwargs):
                return await instrumentor._trace_agno_call(original_arun, self, *args, **kwargs)

            self.original_functions[(Agent, "arun")] = original_arun
            Agent.arun = traced_arun

            _debug_print("✅ Valiqor: Patched Agno Agent.arun for automatic tracing")

        except ImportError:
            _debug_print("⚠️  Agno package not found - install with: pip install agno")
        except Exception as e:
            _debug_print(f"⚠️  Could not instrument Agno: {e}")

    async def _trace_agno_call(self, original_func, agent_instance, *args, **kwargs):
        """Trace Agno Agent arun call"""
        import time
        import uuid

        tracer = _ensure_tracer()

        # Extract message from args (first positional arg)
        message = args[0] if args else kwargs.get("message", "Unknown query")

        # Get model from agent instance (may not be directly accessible)
        model = (
            getattr(agent_instance, "model", None)
            or getattr(agent_instance, "_model", None)
            or "gpt-4o"
        )  # Default fallback

        # Auto-start trace - Agno agent.arun is a workflow entry point
        trace_started = _ensure_auto_trace(
            "Agno Agent Call",
            {"message": str(message)[:200] + "...", "model": model},
            is_workflow_entry=True,
        )

        try:
            with _auto_span(
                "agno_agent_call",
                {
                    "llm.provider": "agno",
                    "llm.model": model,
                    "llm.request.message": str(message)[:200] + "...",
                },
                stage=ValiqorStage.LLM_CALL,
                span_kind=ValiqorSpanKind.LLM_CALL,
            ) as span:

                # Add the user message to the trace when we start a new trace
                if trace_started and tracer:
                    tracer.add_message(
                        {
                            "type": "human",
                            "id": f"human-{uuid.uuid4()}",
                            "content": str(message),
                            "timestamp": time.time(),
                            "span_id": getattr(span, "span_id", None),
                            "response_metadata": {
                                "timestamp": time.time(),
                                "source": "user_input",
                                "llm.vendor": "agno",
                            },
                        }
                    )

                # Make the actual agent call
                start_time = time.time()
                result = await original_func(agent_instance, *args, **kwargs)
                latency_ms = (time.time() - start_time) * 1000

                # Extract response content
                response_content = ""
                if hasattr(result, "content"):
                    response_content = result.content
                elif isinstance(result, str):
                    response_content = result
                else:
                    response_content = str(result)

                # Extract token usage from result.metrics (Agno's token storage)
                prompt_tokens = 0
                completion_tokens = 0
                total_tokens = 0

                if hasattr(result, "metrics") and result.metrics:
                    # Agno stores tokens in result.metrics
                    metrics = result.metrics
                    prompt_tokens = getattr(metrics, "input_tokens", 0) or 0
                    completion_tokens = getattr(metrics, "output_tokens", 0) or 0
                    total_tokens = getattr(metrics, "total_tokens", 0) or (
                        prompt_tokens + completion_tokens
                    )
                elif hasattr(result, "usage"):
                    # Fallback: check for usage attribute
                    usage = result.usage
                    prompt_tokens = getattr(usage, "prompt_tokens", 0) or getattr(
                        usage, "input_tokens", 0
                    )
                    completion_tokens = getattr(usage, "completion_tokens", 0) or getattr(
                        usage, "output_tokens", 0
                    )
                    total_tokens = prompt_tokens + completion_tokens

                # Set span attributes with multiple naming conventions for compatibility
                span.set_attribute("llm.response.content_length", len(response_content))
                span.set_attribute("llm.latency_ms", latency_ms)

                # Standard token attributes (used by cost calculator)
                span.set_attribute("llm.input_tokens", prompt_tokens)
                span.set_attribute("llm.output_tokens", completion_tokens)
                span.set_attribute("llm.total_tokens", total_tokens)

                # Alternative token count attributes (for compatibility)
                span.set_attribute("llm.token_count.prompt", prompt_tokens)
                span.set_attribute("llm.token_count.completion", completion_tokens)
                span.set_attribute("llm.token_count.total", total_tokens)

                # Calculate cost using tracer's cost calculator
                if prompt_tokens > 0 or completion_tokens > 0:
                    cost = tracer.calculate_cost(model, prompt_tokens, completion_tokens)
                    span.set_attribute("llm.cost_usd", cost)

                # First, build a map of tool_call_id to message content from result.messages
                tool_content_map = {}
                tool_request_map = {}
                if hasattr(result, "messages") and result.messages:
                    for message in result.messages:
                        # Map tool responses by call_id
                        if message.role == "tool" and hasattr(message, "tool_call_id"):
                            tool_content_map[message.tool_call_id] = {
                                "content": message.content,
                                "tool_name": (
                                    message.tool_name if hasattr(message, "tool_name") else None
                                ),
                            }
                        # Map tool requests (assistant messages with tool_calls)
                        elif (
                            message.role == "assistant"
                            and hasattr(message, "tool_calls")
                            and message.tool_calls
                        ):
                            for tc in message.tool_calls:
                                call_id = tc.get("id", "")
                                if call_id:
                                    tool_request_map[call_id] = {
                                        "name": tc.get("function", {}).get("name", ""),
                                        "arguments": tc.get("function", {}).get("arguments", "{}"),
                                    }

                # Extract MCP tool schemas from agent's tools (if MCPTools)
                tool_schemas = {}
                mcp_server_info = {}
                if hasattr(agent_instance, "tools") and agent_instance.tools:
                    for tool_provider in agent_instance.tools:
                        # Check if this is an MCPTools instance
                        if hasattr(tool_provider, "functions") and tool_provider.functions:
                            # Extract tool schemas from MCPTools
                            for func_name, func in tool_provider.functions.items():
                                tool_schemas[func_name] = {
                                    "name": getattr(func, "name", func_name),
                                    "description": getattr(func, "description", ""),
                                    "parameters": getattr(func, "parameters", {}),
                                }
                            # Extract MCP server info
                            mcp_server_info = {
                                "name": getattr(tool_provider, "name", "MCPTools"),
                                "transport": getattr(tool_provider, "transport", "stdio"),
                                "url": getattr(tool_provider, "url", None),
                                "initialized": getattr(tool_provider, "initialized", False),
                            }
                            # Try to get server params if available
                            if hasattr(tool_provider, "session") and tool_provider.session:
                                session = tool_provider.session
                                if hasattr(session, "server_info"):
                                    mcp_server_info["server_info"] = (
                                        str(session.server_info)[:500]
                                        if session.server_info
                                        else None
                                    )

                # Extract and trace tool calls from result.tools
                tool_calls_count = 0
                if hasattr(result, "tools") and result.tools:
                    tool_calls_count = len(result.tools)

                    for tool_exec in result.tools:
                        # Create a child span for each tool call
                        tool_span = tracer.start_span(
                            name=f"tool_call_{tool_exec.tool_name}",
                            parent_span_id=getattr(span, "span_id", None),
                        )

                        # Get enriched content from messages if available
                        tool_call_id = tool_exec.tool_call_id
                        enriched_content = tool_content_map.get(tool_call_id, {}).get("content", "")
                        request_info = tool_request_map.get(tool_call_id, {})

                        # Use enriched content from messages if available, fallback to tool_exec.result
                        tool_result = (
                            enriched_content if enriched_content else str(tool_exec.result)
                        )

                        # Get tool schema if available
                        tool_name = tool_exec.tool_name
                        tool_schema = tool_schemas.get(tool_name, {})

                        # Parse arguments to structured format
                        raw_args = request_info.get(
                            "arguments",
                            json.dumps(tool_exec.tool_args) if tool_exec.tool_args else "{}",
                        )
                        try:
                            parsed_args = (
                                json.loads(raw_args) if isinstance(raw_args, str) else raw_args
                            )
                        except:
                            parsed_args = tool_exec.tool_args or {}

                        # Build detailed input with parameter descriptions
                        input_details = {}
                        if tool_schema.get("parameters", {}).get("properties"):
                            param_props = tool_schema["parameters"]["properties"]
                            for param_name, param_value in parsed_args.items():
                                param_schema = param_props.get(param_name, {})
                                input_details[param_name] = {
                                    "value": param_value,
                                    "type": param_schema.get("type", "unknown"),
                                    "description": param_schema.get("description", ""),
                                }
                        else:
                            # No schema available, just use raw args
                            for param_name, param_value in parsed_args.items():
                                input_details[param_name] = {
                                    "value": param_value,
                                    "type": type(param_value).__name__,
                                    "description": "",
                                }

                        # === TOOL IDENTIFICATION ===
                        tool_span.set_attribute("tool.name", tool_name)
                        tool_span.set_attribute("tool.call_id", tool_call_id)
                        tool_span.set_attribute(
                            "tool.description", tool_schema.get("description", "")
                        )

                        # === TOOL PROVIDER INFO ===
                        tool_span.set_attribute("tool.provider", "agno")
                        tool_span.set_attribute(
                            "tool.provider_type", "mcp" if tool_schemas else "function"
                        )
                        if mcp_server_info:
                            tool_span.set_attribute(
                                "tool.mcp.server_name", mcp_server_info.get("name", "")
                            )
                            tool_span.set_attribute(
                                "tool.mcp.transport", mcp_server_info.get("transport", "")
                            )
                            if mcp_server_info.get("url"):
                                tool_span.set_attribute("tool.mcp.url", mcp_server_info["url"])

                        # === TOOL INPUT (How it was invoked) ===
                        tool_span.set_attribute("tool.input.raw_arguments", raw_args)
                        tool_span.set_attribute(
                            "tool.input.parsed_arguments", json.dumps(parsed_args)
                        )
                        tool_span.set_attribute("tool.input.detailed", json.dumps(input_details))

                        # Also add individual parameters as attributes for easy access
                        for param_name, param_value in parsed_args.items():
                            safe_value = str(param_value)[:500] if param_value else ""
                            tool_span.set_attribute(f"tool.input.param.{param_name}", safe_value)

                        # === TOOL SCHEMA (Parameter definitions) ===
                        if tool_schema.get("parameters"):
                            tool_span.set_attribute(
                                "tool.schema.parameters", json.dumps(tool_schema["parameters"])
                            )
                            required_params = tool_schema["parameters"].get("required", [])
                            tool_span.set_attribute(
                                "tool.schema.required_params", json.dumps(required_params)
                            )

                        # === TOOL OUTPUT (Result) ===
                        tool_span.set_attribute(
                            "tool.output.result", str(tool_result)[:5000] if tool_result else ""
                        )
                        tool_span.set_attribute("tool.output.result_length", len(str(tool_result)))
                        tool_span.set_attribute(
                            "tool.output.truncated", len(str(tool_result)) > 5000
                        )
                        tool_span.set_attribute("tool.error", tool_exec.tool_call_error)

                        # === TOOL EXECUTION METRICS ===
                        if hasattr(tool_exec, "created_at") and tool_exec.created_at:
                            tool_span.set_attribute(
                                "tool.execution.created_at", tool_exec.created_at
                            )
                        if hasattr(tool_exec, "metrics") and tool_exec.metrics:
                            tool_metrics = tool_exec.metrics
                            tool_span.set_attribute(
                                "tool.metrics.input_tokens",
                                getattr(tool_metrics, "input_tokens", 0),
                            )
                            tool_span.set_attribute(
                                "tool.metrics.output_tokens",
                                getattr(tool_metrics, "output_tokens", 0),
                            )

                        # Backward compatibility attributes
                        tool_span.set_attribute("tool.arguments", raw_args)
                        tool_span.set_attribute(
                            "tool.result", str(tool_result)[:5000] if tool_result else ""
                        )
                        tool_span.set_attribute("tool.result_length", len(str(tool_result)))

                        # Add comprehensive tool execution event
                        tool_span.add_event(
                            "tool_invocation",
                            {
                                "tool.name": tool_name,
                                "tool.description": tool_schema.get("description", ""),
                                "tool.call_id": tool_call_id,
                                "tool.provider_type": "mcp" if tool_schemas else "function",
                                "tool.input.parameters": parsed_args,
                                "tool.input.detailed": input_details,
                                "tool.output.preview": (
                                    str(tool_result)[:500] if tool_result else ""
                                ),
                                "tool.output.length": len(str(tool_result)),
                                "tool.error": tool_exec.tool_call_error,
                            },
                        )

                        # End tool span with finish() method
                        tool_span.finish("success" if not tool_exec.tool_call_error else "error")

                # Set tool calls count on agent span
                span.set_attribute("tool.calls_count", tool_calls_count)

                # Extract tool messages from result.messages
                if hasattr(result, "messages") and result.messages:
                    for message in result.messages:
                        # Log tool response messages
                        if message.role == "tool":
                            tracer.add_message(
                                {
                                    "type": "tool",
                                    "tool_call_id": message.tool_call_id,
                                    "tool_name": message.tool_name,
                                    "content": message.content,
                                    "timestamp": (
                                        message.created_at
                                        if hasattr(message, "created_at")
                                        else time.time()
                                    ),
                                    "span_id": getattr(span, "span_id", None),
                                }
                            )
                        # Check for assistant messages with tool_calls
                        elif (
                            message.role == "assistant"
                            and hasattr(message, "tool_calls")
                            and message.tool_calls
                        ):
                            # Log that tools are being called
                            for tc in message.tool_calls:
                                span.add_event(
                                    "tool_call_request",
                                    {
                                        "tool.call_id": tc.get("id", ""),
                                        "tool.name": tc.get("function", {}).get("name", ""),
                                        "tool.arguments": tc.get("function", {}).get(
                                            "arguments", "{}"
                                        ),
                                    },
                                )

                # Log the AI response message
                tracer.add_message(
                    {
                        "type": "ai",
                        "id": f"ai-{uuid.uuid4()}",
                        "content": response_content,
                        "timestamp": time.time(),
                        "span_id": getattr(span, "span_id", None),
                        "response_metadata": {
                            "model_name": model,
                            "finish_reason": "stop",
                            "token_usage": {
                                "prompt_tokens": prompt_tokens,
                                "completion_tokens": completion_tokens,
                                "total_tokens": total_tokens,
                            },
                        },
                        "usage_metadata": {
                            "input_tokens": prompt_tokens,
                            "output_tokens": completion_tokens,
                            "total_tokens": total_tokens,
                        },
                    }
                )

                span.add_event(
                    "agno_agent_completed",
                    {
                        "response_length": len(response_content),
                        "latency_ms": latency_ms,
                        "tokens_used": total_tokens,
                        "tool_calls": tool_calls_count,
                    },
                )

                return result

        except Exception as e:
            if "span" in locals():
                span.add_event("agno_agent_error", {"error": str(e)})
            raise
        finally:
            if trace_started:
                _end_auto_trace({"status": "success"})


# Global instrumentor instances
_instrumentors = {
    "openai": OpenAIInstrumentor(),
    "anthropic": AnthropicInstrumentor(),
    "ollama": OllamaInstrumentor(),
    "agno": AgnoInstrumentor(),
    "langchain": LangChainInstrumentor(),
}

# Import Valiqor Cloud URLs from compiled config module (protected)
try:
    from valiqor.common import VALIQOR_CLOUD_TRACES_API as VALIQOR_CLOUD_API
    from valiqor.common import VALIQOR_SIGNUP_URL
except ImportError:
    # Fallback for standalone usage - these will fail at runtime if cloud features used
    VALIQOR_CLOUD_API = None
    VALIQOR_SIGNUP_URL = None


def configure(
    exporters=None,
    app_name=None,
    app_version=None,
    auto_trace=None,
    eval_steps_callback=None,
    trace_dir=None,
    backend_url=None,
    api_key=None,
    organization_id=None,
    project_id=None,
    project_name=None,
    project=None,
    environment=None,
    local_export=None,
    debug=None,
    config_file=None,
    export_mode=None,
):
    """Configure global Valiqor autolog settings

    Args:
        exporters: List of exporters for trace output
        app_name: Application name for tracing metadata
        app_version: Application version for tracing metadata
        auto_trace: Whether to automatically create traces
        eval_steps_callback: Optional callback(trace_data, trace_id) for custom processing
        trace_dir: Directory for JSON trace files (default: valiqor_output/traces)
        backend_url: Custom backend URL (optional - uses Valiqor Cloud if api_key provided)
        api_key: Valiqor API key - enables automatic cloud upload & analytics
        organization_id: Organization ID (auto-created from user_id based on api_key)
        project_id: Project ID for organizing traces (auto-created from project_name)
        project_name: Human-readable project name - backend creates UUID (recommended)
        project: Alias for project_name (for convenience)
        environment: Environment name (development, staging, production)
        local_export: Whether to also save traces locally as JSON (default: True if no api_key)
        debug: Enable debug logging
        config_file: Path to .valiqorrc config file (default: auto-discover)
        export_mode: Export mode - 'file', 'api', or 'console'

    Quick Start:
        # Simplest setup - just add your API key:
        valiqor.configure(api_key="your-valiqor-api-key", project_name="my-chatbot")

        # Get your API key at: https://app.valiqor.com

    Note:
        Configuration priority: Parameters > Environment Variables > .valiqorrc file

        Environment variables:
        - VALIQOR_API_KEY: Your Valiqor API key (recommended)
        - VALIQOR_PROJECT_NAME: Project name for organizing traces
        - VALIQOR_TRACE_DIR: Local trace directory (default: valiqor_output/traces)
        - VALIQOR_INTELLIGENCE: Enable cloud upload (default: true)
    """
    global _global_config

    # Load configuration from .valiqorrc using unified config system
    try:
        from ..common.config import (
            DEFAULT_TRACE_DIR,
            ensure_output_dirs,
            get_config,
            get_intelligence_message,
            should_upload,
        )

        file_config = get_config(config_file=config_file)
        # Ensure output directories exist
        ensure_output_dirs(file_config)
    except ImportError:
        file_config = {}

    # Merge configuration: parameters > env > file config > defaults
    import os

    # Use project_name as app_name (they are the same concept)
    final_project_name = project_name or project or file_config.get("project_name")
    final_app_name = app_name or file_config.get("app_name") or final_project_name or "valiqor-app"
    final_app_version = app_version or file_config.get("app_version", "1.0.0")
    final_auto_trace = auto_trace if auto_trace is not None else file_config.get("auto_trace", True)
    final_debug = debug if debug is not None else file_config.get("debug", False)

    # Use simplified config keys
    final_trace_dir = trace_dir or file_config.get(
        "trace_dir", DEFAULT_TRACE_DIR if "DEFAULT_TRACE_DIR" in dir() else "valiqor_output/traces"
    )
    final_api_key = api_key or file_config.get("api_key")
    # final_project_name already set above (used for app_name too)

    # valiqor_intelligence controls whether to attempt uploads
    valiqor_intelligence = file_config.get("valiqor_intelligence", True)

    # Backend URL from computed config
    final_backend_url = None
    if valiqor_intelligence:
        final_backend_url = backend_url or file_config.get("trace_upload_url")

    # org_id and project_id for backwards compatibility
    final_org_id = organization_id or file_config.get("organization_id")
    final_project_id = project_id or file_config.get("project_id")
    final_environment = environment or file_config.get("environment", "development")

    # Export mode - always save locally, upload if intelligence enabled
    final_local_export = True  # Always save traces locally
    final_export_mode = "file"

    _global_config["exporters"] = exporters if exporters is not None else []
    _global_config["app_info"] = {"name": final_app_name, "version": final_app_version}
    _global_config["auto_trace"] = final_auto_trace
    _global_config["enabled"] = True
    _global_config["debug"] = final_debug
    _global_config["local_export"] = final_local_export
    _global_config["export_mode"] = final_export_mode
    _global_config["has_api_key"] = bool(final_api_key)
    _global_config["valiqor_intelligence"] = valiqor_intelligence

    # Eval steps callback configuration
    _global_config["eval_steps_callback"] = eval_steps_callback

    _global_config["backend_url"] = final_backend_url
    _global_config["api_key"] = final_api_key
    _global_config["organization_id"] = final_org_id
    _global_config["project_name"] = final_project_name
    _global_config["project_id"] = final_project_id
    _global_config["environment"] = final_environment
    _global_config["trace_dir"] = final_trace_dir

    # Create global tracer with backend API support
    _global_config["tracer"] = TracerV2(
        app=_global_config["app_info"],
        exporters=_global_config["exporters"],
        trace_dir=final_trace_dir,
        backend_url=final_backend_url if valiqor_intelligence else None,
        api_key=final_api_key,
        organization_id=final_org_id,
        project_name=final_project_name,
        project_id=final_project_id,
    )

    # Store environment in tracer for trace metadata
    _global_config["tracer"]._environment = final_environment
    _global_config["tracer"]._valiqor_intelligence = valiqor_intelligence

    # Print configuration status (only once)
    if not _global_config.get("_configure_message_shown"):
        _global_config["_configure_message_shown"] = True
        print(f"✅ Valiqor configured: {final_app_name} v{final_app_version}")
        print(f"   💾 Traces saved to: {final_trace_dir}")

        if valiqor_intelligence and final_api_key:
            if final_project_name:
                print(f"   📁 Project: {final_project_name}")
            print(f"   📤 Valiqor Intelligence: Enabled")
        elif valiqor_intelligence and not final_api_key:
            print()
            print(f"   💡 Tip: Get automated evals & analytics by adding your Valiqor API key:")
            print(f"      valiqor.configure(api_key='your-key')")
            print(f"      Sign up free: {VALIQOR_SIGNUP_URL}")


def _show_trace_completion_message(trace_id: str, trace_file: str = None, uploaded: bool = False):
    """Show message when a trace is completed - encourages API key signup if not configured."""
    if uploaded:
        # Trace was actually uploaded - show confirmation
        print(f"   📤 Trace uploaded: {trace_id}")
    elif _global_config.get("has_api_key"):
        # Has API key but upload failed - show saved message
        print(f"   💾 Trace saved: {trace_file}")
    else:
        # No API key - show promotional message occasionally
        if not hasattr(_show_trace_completion_message, "_shown_promo"):
            _show_trace_completion_message._shown_promo = 0

        _show_trace_completion_message._shown_promo += 1

        # Show promo every 3rd trace to avoid being annoying
        if _show_trace_completion_message._shown_promo % 3 == 1:
            print()
            print(f"   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            print(f"   💡 Want automated evals & deeper insights on your traces?")
            print(f"   ")
            print(f"      Set your Valiqor API key:")
            print(f"      → valiqor.configure(api_key='your-key')")
            print(f"   ")
            print(f"      Sign up free: {VALIQOR_SIGNUP_URL}")
            print(f"   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        elif trace_file:
            print(f"   💾 Trace saved: {trace_file}")


def configure_retriever_detection(
    name_patterns=None, class_patterns=None, module_patterns=None, enable_rag_instrumentation=True
):
    """
    Configure custom patterns for retriever tool detection.
    This makes the RAG instrumentation portable across different applications.

    Args:
        name_patterns: List of tool name patterns to detect (e.g., ['my_search', 'custom_retriever'])
        class_patterns: List of class name patterns (e.g., ['MySearchTool', 'CustomRetriever'])
        module_patterns: List of module name patterns (e.g., ['my_app.tools', 'custom_search'])
        enable_rag_instrumentation: Whether to enable RAG instrumentation

    Example:
        import valiqor_tracing
        valiqor_tracing.configure_retriever_detection(
            name_patterns=['my_search_tool', 'doc_finder'],
            class_patterns=['MyCustomRetriever'],
            module_patterns=['my_app.search', 'my_app.retrieval']
        )
        valiqor_tracing.autolog(['langchain'])
    """
    global _global_config

    if not _global_config.get("custom_retriever_patterns"):
        _global_config["custom_retriever_patterns"] = {
            "name_indicators": [],
            "class_patterns": [],
            "module_patterns": [],
        }

    custom_patterns = _global_config["custom_retriever_patterns"]

    if name_patterns:
        custom_patterns["name_indicators"].extend(name_patterns)

    if class_patterns:
        custom_patterns["class_patterns"].extend(class_patterns)

    if module_patterns:
        custom_patterns["module_patterns"].extend(module_patterns)

    # Enable RAG instrumentation
    _global_config["rag_instrumentation"] = enable_rag_instrumentation

    if name_patterns:
        _debug_print(f"   - Name patterns: {name_patterns}")
    if class_patterns:
        _debug_print(f"   - Class patterns: {class_patterns}")
    if module_patterns:
        _debug_print(f"   - Module patterns: {module_patterns}")


def autolog(providers=None):
    """
    Enable automatic tracing for specified LLM providers.

    Args:
        providers: List of provider names or None for all available

    Example:
        import valiqor_tracing
        valiqor_tracing.autolog()  # Enable all
        valiqor_tracing.autolog(["openai", "anthropic"])  # Enable specific
    """
    # Ensure configuration
    if not _global_config["enabled"]:
        configure()

    # Enable RAG instrumentation by default when autolog is called
    _global_config["rag_instrumentation"] = True
    _debug_print(
        "[RAG] Valiqor: RAG instrumentation ENABLED - debug messages will show during retrieval operations"
    )

    # Default to all providers if none specified
    if providers is None:
        providers = list(_instrumentors.keys())
    elif isinstance(providers, str):
        providers = [providers]

    # Instrument specified providers
    for provider in providers:
        if provider in _instrumentors:
            _instrumentors[provider].instrument()
        else:
            pass  # Skip unknown providers

    _debug_print(f"[OK] Valiqor autolog enabled for: {', '.join(providers)}")


def disable_autolog(providers=None):
    """Disable automatic tracing for specified providers"""
    if providers is None:
        providers = list(_instrumentors.keys())
    elif isinstance(providers, str):
        providers = [providers]

    for provider in providers:
        if provider in _instrumentors:
            _instrumentors[provider].uninstrument()


# Provider-specific autolog functions (competitor-style)
def openai_autolog():
    """Enable OpenAI automatic tracing - mlflow.openai.autolog() style"""
    autolog(["openai"])


def anthropic_autolog():
    """Enable Anthropic automatic tracing - mlflow.anthropic.autolog() style"""
    autolog(["anthropic"])


def langchain_autolog():
    """Enable LangChain automatic tracing - mlflow.langchain.autolog() style"""
    autolog(["langchain"])


def ollama_autolog():
    """Enable Ollama automatic tracing"""
    autolog(["ollama"])


def agno_autolog():
    """Enable Agno Agent automatic tracing"""
    autolog(["agno"])


def start_conversation_trace(name: str = "agentic_workflow", input_data: Dict = None):
    """Start a conversation-level trace manually"""
    tracer = _ensure_tracer()
    input_data = input_data or {}

    # End any existing trace first
    if hasattr(_thread_local, "current_trace_id") and _thread_local.current_trace_id:
        try:
            tracer.end_trace({"status": "completed"})
        except:
            pass

    # Start new trace
    trace_id = tracer.start_trace(name, input_data)
    _thread_local.current_trace_id = trace_id
    _thread_local.auto_managed = True
    _thread_local.conversation_level = True
    return trace_id


def end_conversation_trace(output_data: Dict = None):
    """End the current conversation-level trace manually"""
    tracer = _ensure_tracer()
    output_data = output_data or {"status": "completed"}

    if hasattr(_thread_local, "current_trace_id") and _thread_local.current_trace_id:
        tracer.end_trace(output_data)
        _thread_local.current_trace_id = None
        _thread_local.auto_managed = False
        _thread_local.conversation_level = False


class trace_workflow:
    """
    Context manager and decorator for workflow-level tracing.

    Automatically configures tracing if not already enabled, eliminating the need
    for manual setup in user code.

    IMPORTANT: Use this to group multiple LLM/LangGraph calls into a single trace.
    Without trace_workflow, each LangGraph invoke() creates a separate trace file.

    Usage as context manager:
        with valiqor.trace_workflow("my_workflow", {"user_query": query}):
            # All LLM calls here are grouped under ONE trace
            response1 = graph.invoke(...)
            response2 = graph.invoke(...)  # Same trace file!

    Usage as decorator:
        @valiqor.trace_workflow("my_workflow")
        def my_function(query):
            # Function calls are traced as a workflow
            pass
    """

    def __init__(self, name: str = "workflow", input_data: Dict = None):
        self.name = name
        self.input_data = input_data or {}
        self.trace_id = None
        # Don't check enabled here - check at runtime in __enter__

    def __enter__(self):
        # Auto-configure if not already enabled
        if not _global_config.get("enabled", False):
            configure()  # This sets enabled=True and creates tracer

        self.trace_id = start_conversation_trace(self.name, self.input_data)

        # Add human message if user query is provided in input_data
        tracer = _ensure_tracer()
        if tracer and self.input_data.get("user_query"):
            human_message = {
                "type": "human",
                "id": f"human-{str(uuid.uuid4())}",
                "content": self.input_data["user_query"],
                "name": None,
                "example": False,
                "additional_kwargs": {},
                "response_metadata": {
                    "timestamp": _get_current_timestamp(),
                    "source": "user_input",
                    "llm.vendor": "unknown",
                    "request_id": f"req_{str(uuid.uuid4())[:8]}",
                    "endpoint_url": "https://api.unknown.com/v1/completions",
                },
                "tool_calls": [],
                "invalid_tool_calls": [],
            }
            tracer.add_message(human_message)

        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        # Only end trace if we started one
        if self.trace_id is None:
            return False

        if exc_type is None:
            # Success case
            end_conversation_trace({"status": "success", "workflow_completed": True})
        else:
            # Error case - automatically handle the exception
            end_conversation_trace(
                {
                    "status": "error",
                    "error": str(exc_val),
                    "error_type": exc_type.__name__ if exc_type else "Unknown",
                }
            )
        # Don't suppress the exception, let it propagate
        return False

    def __call__(self, func):
        """Allow trace_workflow to be used as a decorator."""

        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Extract input data from function arguments
            input_data = self.input_data.copy()
            input_data["function"] = func.__name__

            # Try to capture function arguments
            import inspect

            sig = inspect.signature(func)
            params = list(sig.parameters.keys())
            for i, param in enumerate(params):
                if i < len(args):
                    input_data[param] = str(args[i])[:200]
            for k, v in kwargs.items():
                input_data[k] = str(v)[:200]

            # Use context manager
            with trace_workflow(self.name, input_data):
                return func(*args, **kwargs)

        return wrapper


def trace_function(name: str = None, input_fields: list = None):
    """
    Decorator for tracing individual functions as spans within a workflow.

    Unlike @trace_workflow which creates a new trace, @trace_function creates
    a span that nests under the current active trace (if any).

    Usage:
        @trace_function("my_step")
        def process_data(data):
            # This creates a span, not a new trace
            return transformed_data
    """

    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            # Auto-configure if not enabled
            if not _global_config.get("enabled", False):
                configure()

            # Auto-generate name from function name if not provided
            span_name = name or func.__name__

            # Extract input data from function arguments
            input_data = {"function": func.__name__}
            if input_fields and args:
                for i, field in enumerate(input_fields):
                    if i < len(args):
                        input_data[field] = str(args[i])[:200]  # Limit size
            if kwargs:
                input_data.update({k: str(v)[:200] for k, v in kwargs.items()})

            # Check if there's an active trace - if not, create one
            current_trace = getattr(_thread_local, "current_trace_id", None)
            trace_started = False

            if not current_trace:
                # No active trace - create one (standalone function call)
                tracer = _ensure_tracer()
                trace_id = tracer.start_trace(f"{span_name}_workflow", input_data)
                _thread_local.current_trace_id = trace_id
                _thread_local.auto_managed = True
                trace_started = True

            # Create a span for this function (nests under current trace)
            try:
                with _auto_span(
                    span_name,
                    {
                        "function.name": func.__name__,
                        "function.input_preview": str(input_data)[:200],
                    },
                    stage=ValiqorStage.ORCHESTRATION,
                    span_kind=ValiqorSpanKind.WORKFLOW_NODE,
                ) as span:
                    result = func(*args, **kwargs)
                    return result
            finally:
                # Only end trace if we started it
                if trace_started:
                    tracer = _ensure_tracer()
                    tracer.end_trace({"status": "success"})
                    _thread_local.current_trace_id = None
                    _thread_local.auto_managed = False

        return wrapper

    return decorator


# Internal helper functions
def _ensure_tracer():
    """Ensure we have a tracer available"""
    if not _global_config["tracer"]:
        configure()  # Auto-configure with defaults
    return _global_config["tracer"]


def _get_current_timestamp():
    """Get current timestamp in the format expected by the tracing system"""
    import time

    return time.time()


def _ensure_auto_trace(name: str, input_data: Dict, is_workflow_entry: bool = False):
    """Ensure we have an active trace, creating one if needed.

    Args:
        name: Name for the trace (used for identification)
        input_data: Initial input data for the trace
        is_workflow_entry: If True, this is a top-level workflow entry point
                          (e.g., LangGraph invoke, Agno agent.arun) that should
                          auto-create a trace. Individual LLM calls should pass False.

    Returns:
        True if a new trace was created (and should be auto-ended), False otherwise.
    """
    tracer = _ensure_tracer()

    # Check if we already have an active trace
    current_trace = getattr(_thread_local, "current_trace_id", None)
    if current_trace:
        return False  # Reuse existing trace, don't auto-end

    # Only create traces for workflow entry points when auto_trace is enabled
    if _global_config.get("auto_trace", True) and is_workflow_entry:
        trace_name = "agentic_workflow"
        trace_id = tracer.start_trace(trace_name, input_data)
        _thread_local.current_trace_id = trace_id
        _thread_local.auto_managed = True
        _thread_local.conversation_level = True
        _thread_local.graph_auto_started = True
        return True  # We started this trace, should auto-end it

    return False


def _end_auto_trace(output_data: Dict):
    """End auto-managed trace - end graph-auto-started traces, but not manual conversation traces"""
    tracer = _ensure_tracer()

    # Check if this trace was auto-started by graph instrumentation
    # graph_auto_started traces should be ended automatically
    # Manual conversation traces (started via start_conversation_trace) should NOT be auto-ended
    is_graph_auto_started = getattr(_thread_local, "graph_auto_started", False)

    if (
        hasattr(_thread_local, "auto_managed")
        and _thread_local.auto_managed
        and hasattr(_thread_local, "current_trace_id")
        and (is_graph_auto_started or not getattr(_thread_local, "conversation_level", False))
    ):

        tracer.end_trace(output_data)
        _thread_local.current_trace_id = None
        _thread_local.auto_managed = False
        _thread_local.conversation_level = False
        _thread_local.graph_auto_started = False


class _auto_span:
    """Context manager for auto-created spans with full enrichment support."""

    def __init__(
        self,
        name: str,
        attributes: Dict = None,
        stage: str = None,
        span_kind: str = None,
        is_rag_span: bool = False,
    ):
        """Create an auto-managed span.

        Args:
            name: Span name
            attributes: Optional dict of span attributes
            stage: Optional stage override (otherwise inferred from name)
            span_kind: Optional span kind override (otherwise inferred)
            is_rag_span: Whether to create a RAGSpan (for retrieval/RAG operations)
        """
        self.name = name
        self.attributes = attributes or {}
        self.stage = stage
        self.span_kind = span_kind
        self.is_rag_span = is_rag_span
        self.span = None
        self.tracer = None

        # Auto-detect if this should be a RAG span based on stage/span_kind
        if not is_rag_span:
            if span_kind == ValiqorSpanKind.RETRIEVER or stage == ValiqorStage.RETRIEVAL:
                self.is_rag_span = True

    def __enter__(self):
        self.tracer = _ensure_tracer()
        try:
            # Get and pass parent span to maintain hierarchy
            current_span = self.tracer._get_current_span()
            parent_span_id = current_span.span_id if current_span else None
            self.span = self.tracer.start_span(
                self.name,
                parent_span_id=parent_span_id,
                attributes=self.attributes,
                stage=self.stage,
                span_kind=self.span_kind,
                is_rag_span=self.is_rag_span,  # Pass RAG span flag
            )
            return self.span
        except Exception as e:
            # If we can't create a span, create a minimal mock
            _debug_print(f"⚠️  Could not create span '{self.name}': {e}")
            return MockSpan(self.name)

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.span and self.tracer:
            try:
                status = "error" if exc_type else "success"
                self.tracer.finish_span(self.span, status)
            except Exception as e:
                _debug_print(f"⚠️  Could not finish span '{self.name}': {e}")


class MockSpan:
    """Minimal span for fallback when tracing fails"""

    def __init__(self, name):
        self.name = name
        self.span_id = f"mock-{name}"

    def set_attribute(self, key, value):
        pass

    def add_event(self, name, data=None):
        pass


# Convenience namespace classes (competitor-style API)
class OpenAI:
    @staticmethod
    def autolog():
        openai_autolog()


class Anthropic:
    @staticmethod
    def autolog():
        anthropic_autolog()


class LangChain:
    @staticmethod
    def autolog():
        langchain_autolog()
