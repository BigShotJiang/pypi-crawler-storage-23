"""
Tracing CLI Commands

Command handlers for tracing feature.
"""

import argparse
import json
import os
from pathlib import Path
from typing import Any, Dict

from ..common import (
    CONFIG_FILE,
)
from ..common import VALIQOR_CLOUD_TRACES_API as VALIQOR_CLOUD_API
from ..common import (
    VALIQOR_SIGNUP_URL,
)
from ..common.config import get_config_path, load_config_file, save_config
from ..common.exceptions import ConfigurationError

DEFAULT_TRACING_CONFIG = {
    "enabled": True,
    "export_mode": "file",
    "trace_dir": "valiqor_output/traces",
    "auto_providers": ["openai", "langchain", "anthropic"],
}


def cmd_init(args: argparse.Namespace) -> int:
    """Initialize Valiqor in the current project"""
    print("🚀 Initializing Valiqor Trace...")
    print()

    config_path = get_config_path()

    if config_path.exists() and not args.force:
        print(f"⚠️  Valiqor is already initialized (.valiqorrc exists)")
        print("   Use --force to reinitialize")
        return 1

    config = {
        "version": "3.0",
        "api_key": "",
        "backend_url": "",
        "project_name": "",
        "tracing": DEFAULT_TRACING_CONFIG.copy(),
        "scanner": {
            "enabled": False,
            "output_dir": "valiqor_output/scans",
            "skip_patterns": ["node_modules", ".git", "__pycache__"],
            "auto_upload": True,
        },
    }

    if not args.defaults:
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print("💡 Get your free API key at: " + VALIQOR_SIGNUP_URL)
        print("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
        print()

        api_key = input("Valiqor API Key (press Enter to skip): ").strip()
        if api_key:
            config["api_key"] = api_key
            config["tracing"]["export_mode"] = "api"
            print("   ✅ API key configured")
        else:
            trace_dir = input(f"Trace directory [valiqor_output/traces]: ").strip()
            if trace_dir:
                config["tracing"]["trace_dir"] = trace_dir

    save_config(config)

    print()
    print("✅ Valiqor initialized successfully!")
    print(f"   Config file: {config_path}")
    print()
    print("Next steps:")
    print("  1. Import Valiqor in your code:")
    print("     from valiqor_sdk import autolog, configure")
    print("  2. Configure and enable auto-instrumentation:")
    print("     configure()")
    print("     autolog()")

    return 0


def cmd_test(args: argparse.Namespace) -> int:
    """Test Valiqor configuration"""
    try:
        config = load_config_file()
        print("✅ Configuration loaded successfully")
        print(f"   Tracing enabled: {config.get('tracing', {}).get('enabled', False)}")
        print(f"   Scanner enabled: {config.get('scanner', {}).get('enabled', False)}")
        print(f"   Export mode: {config.get('tracing', {}).get('export_mode', 'unknown')}")
        return 0
    except Exception as e:
        print(f"❌ Configuration error: {e}")
        return 1


def add_tracing_commands(subparsers) -> None:
    """Add tracing commands to CLI"""

    # init command
    init_parser = subparsers.add_parser("init", help="Initialize Valiqor")
    init_parser.add_argument("--force", action="store_true", help="Force reinitialize")
    init_parser.add_argument("--defaults", action="store_true", help="Use defaults")
    init_parser.set_defaults(func=cmd_init)

    # test command
    test_parser = subparsers.add_parser("test", help="Test configuration")
    test_parser.set_defaults(func=cmd_test)
