# core.py - Enhanced Valiqor Tracing v2.0 with RAG Extensions
import inspect
import json
import os
import re
import subprocess
import threading
import time
import uuid
from datetime import datetime
from typing import Any, Callable, Dict, List, Optional

# Import RAG extensions
from .rag_extensions import (
    Citation,
    DocumentHit,
    FormatCheck,
    GenerationInfo,
    RAGSpan,
    RAGTraceEvent,
    RetrievalInfo,
    create_citation,
    create_document_hit,
    create_format_check,
)

# 🔥 CRITICAL FIX: Global trace reference for cross-thread access
# LangGraph ToolNode executes tools in worker threads, where thread-local storage
# doesn't have the trace context. This global dict provides a fallback.
_global_trace_reference = {"current_trace": None}

# ============================================================================
# STAGE AND SPAN KIND ENUMS
# ============================================================================
# These are generic, fixed stages derived from tracing library span naming conventions.
# They are NOT app-specific (no "query_rewriter" or "synthesize_answer").


class ValiqorStage:
    """Generic pipeline stages for RAG/agentic workflows.

    These stages represent the logical phases of an AI pipeline,
    independent of any specific application's function names.
    """

    RETRIEVAL = "retrieval"  # Document/knowledge retrieval
    EVALUATION = "evaluation"  # Document grading, relevance checks
    SYNTHESIS = "synthesis"  # Answer generation, response synthesis
    ROUTING = "routing"  # Query routing, decision making
    ORCHESTRATION = "orchestration"  # Workflow coordination, graph execution
    LLM_CALL = "llm_call"  # Direct LLM invocations
    TOOL_CALL = "tool_call"  # Tool/function executions
    EMBEDDING = "embedding"  # Embedding generation
    RERANKING = "reranking"  # Result reranking
    PREPROCESSING = "preprocessing"  # Query preprocessing, transformation
    POSTPROCESSING = "postprocessing"  # Output formatting, filtering
    UNKNOWN = "unknown"  # Fallback for unclassified spans


class ValiqorSpanKind:
    """High-level span classifications.

    These categorize spans by their role in the system,
    enabling quick filtering of actionable vs internal spans.
    """

    WORKFLOW_NODE = "workflow_node"  # Named workflow step (e.g., LangGraph node)
    LLM_CALL = "llm_call"  # LLM API invocation
    RETRIEVER = "retriever"  # Retrieval operation
    TOOL = "tool"  # Tool/function execution
    EVAL = "eval"  # Evaluation/judging operation
    EMBEDDING = "embedding"  # Embedding computation
    SYSTEM = "system"  # Internal/framework span
    UNKNOWN = "unknown"  # Fallback


# Framework packages to skip when detecting call sites
# These are library/framework paths that should NOT be reported as user code
# Framework packages that should be skipped in call-site detection
# Only include packages that would actually appear in path components
# (Python stdlib modules like re, os, sys are in Python's lib directory,
#  which is already caught by site-packages/lib/python patterns)
_FRAMEWORK_PACKAGES = frozenset(
    [
        "valiqor_tracing",
        "langchain",
        "langchain_core",
        "langchain_openai",
        "langchain_anthropic",
        "langchain_community",
        "langgraph",
        "openai",
        "anthropic",
        "httpx",
        "httpcore",
        "requests",
        "urllib3",
        "aiohttp",
        "pydantic",
        "pydantic_core",
        "fastapi",
        "starlette",
        "uvicorn",
        "streamlit",
        "agno",
        "ollama",
    ]
)

# Prefixes that indicate framework code (for startswith matching)
# Only use longer, unambiguous prefixes
_FRAMEWORK_PREFIXES = frozenset(
    [
        "langchain_",  # langchain_core, langchain_openai, etc.
        "pydantic_",  # pydantic_core
        "typing_",  # typing_extensions
    ]
)

# ============================================================================
# HELPER FUNCTIONS FOR JOIN-KEYS AND CALL-SITE DETECTION
# ============================================================================


def _get_repo_id() -> Optional[str]:
    """Get repo ID from environment variable (customer-provided opaque string)."""
    return os.environ.get("VALIQOR_REPO_ID")


_cached_commit_sha = None
_commit_sha_initialized = False


def _get_commit_sha() -> Optional[str]:
    """Get commit SHA from env var or git rev-parse HEAD (cached)."""
    global _cached_commit_sha, _commit_sha_initialized
    if _commit_sha_initialized:
        return _cached_commit_sha

    # First check environment variable (e.g., from CI)
    env_sha = os.environ.get("VALIQOR_COMMIT_SHA")
    if env_sha:
        _cached_commit_sha = env_sha
        _commit_sha_initialized = True
        return _cached_commit_sha

    # Fall back to git rev-parse HEAD
    try:
        _cached_commit_sha = (
            subprocess.check_output(["git", "rev-parse", "HEAD"], stderr=subprocess.DEVNULL)
            .decode("utf-8")
            .strip()
        )
    except Exception:
        _cached_commit_sha = None
    _commit_sha_initialized = True
    return _cached_commit_sha


_cached_project_root = None
_project_root_initialized = False


def _get_project_root() -> str:
    global _cached_project_root, _project_root_initialized
    if _project_root_initialized:
        return _cached_project_root
    try:
        root = (
            subprocess.check_output(
                ["git", "rev-parse", "--show-toplevel"], stderr=subprocess.DEVNULL
            )
            .decode("utf-8")
            .strip()
        )
        _cached_project_root = root
    except Exception:
        _cached_project_root = os.getcwd()
    _project_root_initialized = True
    return _cached_project_root


def _is_framework_path(filepath: str) -> bool:
    """Check if a file path belongs to a framework/library (not user code).

    Returns True if the path should be skipped when looking for user code.
    """
    # Normalize path separators
    normalized = filepath.replace("\\", "/").lower()

    # Check for virtualenv / site-packages patterns
    venv_patterns = [
        "site-packages/",
        "site-packages\\",
        "/venv/",
        "\\venv\\",
        "/.venv/",
        "\\.venv\\",
        "/env/lib/",
        "\\env\\lib\\",
        "/lib/python",
        "\\lib\\python",
        "dist-packages/",
        "dist-packages\\",
    ]
    for pattern in venv_patterns:
        if pattern in normalized:
            return True

    # Check for known framework package names in path
    # Split path into components and check each
    path_parts = set(normalized.replace("\\", "/").split("/"))
    for pkg in _FRAMEWORK_PACKAGES:
        # Exact match only for package names
        if pkg.lower() in path_parts:
            return True

    # Check for framework prefixes (e.g., langchain_*, pydantic_*)
    for prefix in _FRAMEWORK_PREFIXES:
        for part in path_parts:
            if part.startswith(prefix.lower()):
                return True

    return False


def _get_call_site(project_root: str) -> Dict[str, Any]:
    """Find the first stack frame that represents user/application code.

    Walks up the call stack, skipping:
    - Our SDK package (valiqor_tracing)
    - Framework/library packages (LangChain, OpenAI, etc.)
    - Virtualenv / site-packages directories

    Returns repo-relative path, line number, and function name for the call site.
    """
    stack = inspect.stack()
    for frame_info in stack:
        filename = frame_info.filename

        # Skip frames inside valiqor_tracing
        if "valiqor_tracing" in filename:
            continue

        # Skip framework/library paths
        if _is_framework_path(filename):
            continue

        # Found user code - compute repo-relative path
        try:
            rel_path = os.path.relpath(filename, project_root)
            # If relpath goes up (starts with ..), it's outside project - skip
            if rel_path.startswith(".."):
                continue
        except ValueError:
            # If on different drive (Windows) - use absolute path
            rel_path = filename

        return {
            "valiqor.source_file": rel_path,
            "valiqor.source_line": frame_info.lineno,
            "valiqor.source_function": frame_info.function,
        }

    # No user code frame found - return empty (span will be marked non-actionable)
    return {}


def _infer_stage_from_span_name(span_name: str) -> str:
    """Infer a generic stage from the span name using library naming conventions.

    This maps span names to generic stages based on patterns used by the
    tracing library, NOT based on app-specific function names.
    """
    name_lower = span_name.lower()

    # LLM call patterns - check early as they're common and have specific patterns
    if any(
        p in name_lower
        for p in [
            "llm_call",
            "llm.call",
            "chat_completion",
            "chatopenai",
            "anthropic",
            "ollama",
            "openai_",
            "claude",
            "gemini",
        ]
    ):
        return ValiqorStage.LLM_CALL

    # Retrieval patterns
    if any(p in name_lower for p in ["retriev", "search", "fetch_doc", "rag.retrieval", "vector_"]):
        return ValiqorStage.RETRIEVAL

    # Evaluation/grading patterns
    if any(p in name_lower for p in ["eval", "grade", "judge", "check", "relevance", "score"]):
        return ValiqorStage.EVALUATION

    # Tool patterns - check before synthesis since tools are more specific
    if any(p in name_lower for p in ["tool_", "tool.", "function_call", "tool_node", "execute_"]):
        return ValiqorStage.TOOL_CALL

    # Synthesis/generation patterns - be more specific to avoid false positives
    if any(
        p in name_lower
        for p in ["synth", "generat", "final_answer", "respond", "text_complet", "answer_generat"]
    ):
        return ValiqorStage.SYNTHESIS

    # Routing/decision patterns
    if any(p in name_lower for p in ["rout", "decid", "dispatch", "branch", "condition"]):
        return ValiqorStage.ROUTING

    # Embedding patterns
    if any(p in name_lower for p in ["embed", "vectoriz"]):
        return ValiqorStage.EMBEDDING

    # Reranking patterns
    if any(p in name_lower for p in ["rerank", "re-rank", "reorder"]):
        return ValiqorStage.RERANKING

    # Orchestration patterns
    if any(p in name_lower for p in ["workflow", "graph", "orchestrat", "pipeline", "agentic"]):
        return ValiqorStage.ORCHESTRATION

    # Preprocessing patterns
    if any(p in name_lower for p in ["preprocess", "transform", "rewrite", "expand"]):
        return ValiqorStage.PREPROCESSING

    # Postprocessing patterns
    if any(p in name_lower for p in ["postprocess", "format", "filter", "clean"]):
        return ValiqorStage.POSTPROCESSING

    return ValiqorStage.UNKNOWN


def _infer_span_kind(span_name: str, attributes: Dict[str, Any] = None) -> str:
    """Infer span kind from name and attributes.

    Returns a high-level classification for the span.
    """
    name_lower = span_name.lower()
    attrs = attributes or {}

    # Check attributes first for explicit typing
    if attrs.get("node.type") == "workflow_node":
        return ValiqorSpanKind.WORKFLOW_NODE
    if attrs.get("rag.operation") == "retrieval":
        return ValiqorSpanKind.RETRIEVER
    if attrs.get("tool.name") or "tool." in str(attrs):
        return ValiqorSpanKind.TOOL

    # Infer from span name patterns
    if any(
        p in name_lower
        for p in ["llm_call", "llm.call", "chat_completion", "chatopenai", "chatanthropic"]
    ):
        return ValiqorSpanKind.LLM_CALL

    if any(p in name_lower for p in ["retriev", "search_", "rag.retrieval"]):
        return ValiqorSpanKind.RETRIEVER

    if any(p in name_lower for p in ["tool_", "tool.", "function_call"]):
        return ValiqorSpanKind.TOOL

    if any(p in name_lower for p in ["eval", "grade", "judge", "check"]):
        return ValiqorSpanKind.EVAL

    if any(p in name_lower for p in ["embed"]):
        return ValiqorSpanKind.EMBEDDING

    if any(p in name_lower for p in ["workflow", "graph", "agentic", "pipeline"]):
        return ValiqorSpanKind.WORKFLOW_NODE

    return ValiqorSpanKind.UNKNOWN


def _enrich_span(span, stage: str = None, span_kind: str = None) -> None:
    """Enrich a span with deterministic join keys and metadata.

    Adds:
    - valiqor.repo_id (from env var if set)
    - valiqor.commit_sha (from env var or git)
    - valiqor.source_file, valiqor.source_line, valiqor.source_function (call site)
    - valiqor.stage (generic pipeline stage)
    - valiqor.span_kind (high-level classification)
    - valiqor.actionable (boolean: is this user code?)

    Args:
        span: The Span object to enrich
        stage: Override for the stage (if not provided, inferred from span name)
        span_kind: Override for span kind (if not provided, inferred)
    """
    # Repo-level join keys
    repo_id = _get_repo_id()
    if repo_id:
        span.set_attribute("valiqor.repo_id", repo_id)

    commit_sha = _get_commit_sha()
    if commit_sha:
        span.set_attribute("valiqor.commit_sha", commit_sha)

    # Call-site detection (skip framework paths)
    project_root = _get_project_root()
    call_site = _get_call_site(project_root)

    # Set call site attributes
    for k, v in call_site.items():
        span.set_attribute(k, v)

    # Determine if span is actionable (user code vs framework)
    source_file = call_site.get("valiqor.source_file", "")
    actionable = bool(source_file) and not _is_framework_path(source_file)
    span.set_attribute("valiqor.actionable", actionable)

    # Stage classification
    resolved_stage = stage if stage else _infer_stage_from_span_name(span.name)
    span.set_attribute("valiqor.stage", resolved_stage)

    # Span kind classification
    resolved_kind = span_kind if span_kind else _infer_span_kind(span.name, span.attributes)
    span.set_attribute("valiqor.span_kind", resolved_kind)


def generate_span_id() -> str:
    """Generate a unique span ID"""
    return f"span_{str(uuid.uuid4())[:8]}"


def generate_trace_id() -> str:
    """Generate a unique trace ID"""
    return f"trace_{str(uuid.uuid4())[:8]}"


def _safe_serialize(obj):
    if isinstance(obj, (str, int, float, bool)) or obj is None:
        return obj
    if hasattr(obj, "type") and hasattr(obj, "content"):
        # Handle LangChain message objects
        msg_data = {
            "type": getattr(obj, "type", "unknown"),
            "content": getattr(obj, "content", str(obj)),
        }
        # Add additional attributes if they exist
        for attr in [
            "additional_kwargs",
            "response_metadata",
            "tool_calls",
            "invalid_tool_calls",
            "name",
            "id",
            "tool_call_id",
            "artifact",
            "status",
        ]:
            if hasattr(obj, attr):
                msg_data[attr] = _safe_serialize(getattr(obj, attr))
        return msg_data
    if hasattr(obj, "dict"):
        try:
            return obj.dict()
        except Exception:
            return str(obj)
    if hasattr(obj, "__dict__"):
        return {k: _safe_serialize(v) for k, v in obj.__dict__.items()}
    if isinstance(obj, list):
        return [_safe_serialize(v) for v in obj]
    if isinstance(obj, dict):
        return {k: _safe_serialize(v) for k, v in obj.items()}
    return str(obj)


class Span:
    """Enhanced span with hierarchical structure and OpenTelemetry-like attributes"""

    def __init__(
        self,
        span_id: str,
        name: str,
        parent_span_id: Optional[str] = None,
        trace_id: Optional[str] = None,
    ):
        self.span_id = span_id
        self.trace_id = trace_id or generate_trace_id()
        self.parent_span_id = parent_span_id
        self.name = name
        self.start_time = datetime.utcnow().isoformat() + "Z"
        self.end_time = None
        self.duration_ms = None
        self.status = "in_progress"
        self.children = []
        self.attributes = {}
        self.events = []
        self._start_timestamp = time.time()

    def add_child(self, child_span_id: str):
        """Add a child span ID to this span"""
        if child_span_id not in self.children:
            self.children.append(child_span_id)

    def set_attribute(self, key: str, value: Any):
        """Set a span attribute"""
        self.attributes[key] = _safe_serialize(value)

    def add_event(self, name: str, data: Dict[str, Any] = None):
        """Add an event to this span"""
        event = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "event": name,
            "data": _safe_serialize(data or {}),
        }
        self.events.append(event)

    def finish(self, status: str = "success"):
        """Finish the span"""
        self.end_time = datetime.utcnow().isoformat() + "Z"
        self.duration_ms = round((time.time() - self._start_timestamp) * 1000, 2)
        self.status = status

    def end(self, status: str = "success"):
        """End the span (alias for finish)"""
        self.finish(status)

    def to_dict(self) -> Dict[str, Any]:
        """Convert span to dictionary"""
        result = {
            "span_id": self.span_id,
            "trace_id": self.trace_id,
            "parent_span_id": self.parent_span_id,
            "name": self.name,
            "start_time": self.start_time,
            "end_time": self.end_time,
            "duration_ms": self.duration_ms,
            "status": self.status,
            "children": self.children,
            "attributes": self.attributes,
            "events": self.events,
        }

        # Include retrieval/generation data if set (for RAG operations on regular spans)
        if hasattr(self, "retrieval") and self.retrieval:
            result["retrieval"] = self.retrieval
        if hasattr(self, "generation") and self.generation:
            result["generation"] = self.generation
        if hasattr(self, "rag_pipeline_stage") and self.rag_pipeline_stage:
            result["rag_pipeline_stage"] = self.rag_pipeline_stage

        return result


class TraceEvent:
    def __init__(self, level: str = "primary", **fields: Any):
        self.ts = time.strftime("%Y-%m-%dT%H:%M:%S", time.gmtime())
        self.level = level
        self.fields = fields

    def to_dict(self) -> Dict[str, Any]:
        d = {"ts": self.ts, "level": self.level, **_safe_serialize(self.fields)}
        d["_record_type"] = "session" if self.level == "session" else "event"
        return d


class TracerV2:
    """Enhanced Tracer with hierarchical spans and v2 schema support"""

    def __init__(
        self,
        app: Dict[str, str],
        exporters=None,
        ring_size: int = 200,
        trace_dir: str = "valiqor_output/traces",
        backend_url: str = None,
        api_key: str = None,
        organization_id: str = None,
        project_name: str = None,
        project_id: str = None,
    ):
        """
        Initialize TracerV2 with optional backend API upload.

        Args:
            app: Application info dict with 'name' and 'version'
            exporters: List of exporters (ConsoleExporter, FileExporter, etc.)
            ring_size: Size of ring buffer for events
            trace_dir: Directory for JSON trace files
            backend_url: Valiqor backend API URL (default: from VALIQOR_BACKEND_URL env var)
            api_key: API key for authentication (default: from VALIQOR_API_KEY env var)
            organization_id: Organization ID (auto-created from user_id based on api_key)
            project_name: Human-readable project name - backend creates UUID
            project_id: Project ID UUID (if provided directly)

        Note:
            Configuration is read from environment variables if not provided:
            - VALIQOR_BACKEND_URL: Backend API URL for trace upload
            - VALIQOR_API_KEY: API key for authentication
            - VALIQOR_ORG_ID: Organization ID (auto-created from user_id)
            - VALIQOR_PROJECT_NAME: Human-readable project name
        """
        self.app = app
        self.exporters = exporters or []
        self._local = threading.local()
        self._ring_size = ring_size
        self.trace_dir = trace_dir
        os.makedirs(self.trace_dir, exist_ok=True)

        # Backend API configuration - read from environment if not provided
        self.backend_url = backend_url or os.environ.get("VALIQOR_BACKEND_URL")
        self.api_key = api_key or os.environ.get("VALIQOR_API_KEY")
        self.organization_id = organization_id or os.environ.get("VALIQOR_ORG_ID")
        # project_name is the human-readable name, backend creates UUID
        self.project_name = project_name or os.environ.get("VALIQOR_PROJECT_NAME")
        self.project_id = project_id or os.environ.get("VALIQOR_PROJECT_ID")

        # Customer project context for trace-scan correlation
        self._project_context = None
        self._project_context_warnings_shown = False
        try:
            from ..common.project_context import (
                get_customer_project_context,
                show_dirty_state_warning,
                show_no_scan_warning,
            )

            self._project_context = get_customer_project_context()
            # Show warnings once at initialization
            if self._project_context.is_dirty and not self._project_context_warnings_shown:
                show_dirty_state_warning("trace")
                self._project_context_warnings_shown = True
            if (
                self._project_context.scan_version_id is None
                and not self._project_context_warnings_shown
            ):
                show_no_scan_warning()
                self._project_context_warnings_shown = True
        except ImportError:
            pass  # project_context module not available

        # Comprehensive token pricing for top 20 LLM providers (per 1K tokens)
        # Updated pricing as of September 2025 - order matters for substring matching
        self.token_pricing = {
            # OpenAI
            "gpt-4o": {"input": 0.005, "output": 0.015},
            "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
            "gpt-4-turbo": {"input": 0.01, "output": 0.03},
            "gpt-4": {"input": 0.03, "output": 0.06},
            "gpt-3.5-turbo": {"input": 0.001, "output": 0.002},
            # Anthropic
            "claude-3.5-sonnet": {"input": 0.003, "output": 0.015},
            "claude-3-opus": {"input": 0.015, "output": 0.075},
            "claude-3-sonnet": {"input": 0.003, "output": 0.015},
            "claude-3-haiku": {"input": 0.00025, "output": 0.00125},
            # Google
            "gemini-1.5-pro": {"input": 0.00125, "output": 0.005},
            "gemini-1.5-flash": {"input": 0.000075, "output": 0.0003},
            "gemini-pro": {"input": 0.0005, "output": 0.0015},
            # Cohere
            "command-r-plus": {"input": 0.003, "output": 0.015},
            "command-r": {"input": 0.0005, "output": 0.0015},
            "command": {"input": 0.001, "output": 0.002},
            # Mistral
            "mistral-large": {"input": 0.008, "output": 0.024},
            "mistral-medium": {"input": 0.0027, "output": 0.0081},
            "mistral-small": {"input": 0.002, "output": 0.006},
            "mixtral-8x7b": {"input": 0.0007, "output": 0.0007},
            # Together AI
            "llama-2-70b": {"input": 0.0009, "output": 0.0009},
            "llama-3-70b": {"input": 0.0009, "output": 0.0009},
            "mixtral-8x7b-instruct": {"input": 0.0006, "output": 0.0006},
            # Groq (very fast inference)
            "llama3-70b": {"input": 0.00059, "output": 0.00079},
            "mixtral-8x7b": {"input": 0.00027, "output": 0.00027},
            "gemma-7b": {"input": 0.00010, "output": 0.00010},
            # Perplexity
            "pplx-70b-online": {"input": 0.001, "output": 0.001},
            "pplx-7b-online": {"input": 0.0002, "output": 0.0002},
            # Fireworks AI
            "llama-v3-70b": {"input": 0.0009, "output": 0.0009},
            "mixtral-8x22b": {"input": 0.0012, "output": 0.0012},
            # Anyscale
            "meta-llama-70b": {"input": 0.001, "output": 0.001},
            "mistralai-mixtral": {"input": 0.0005, "output": 0.0005},
            # DeepSeek
            "deepseek-coder": {"input": 0.00014, "output": 0.00028},
            "deepseek-chat": {"input": 0.00014, "output": 0.00028},
            # AI21
            "jurassic-2-ultra": {"input": 0.015, "output": 0.015},
            "jurassic-2-mid": {"input": 0.01, "output": 0.01},
            # Azure OpenAI (same as OpenAI but different endpoint)
            "azure-gpt-4o": {"input": 0.005, "output": 0.015},
            "azure-gpt-4": {"input": 0.03, "output": 0.06},
            # Local model providers (zero cost)
            "ollama": {"input": 0.0, "output": 0.0},
            "localai": {"input": 0.0, "output": 0.0},
            "vllm": {"input": 0.0, "output": 0.0},
            "custom_local": {"input": 0.0, "output": 0.0},
            "local": {"input": 0.0, "output": 0.0},
            # Default fallback pricing for unknown models
            "default": {"input": 0.001, "output": 0.002},
        }

    def _get_fresh_project_context(self) -> dict:
        """
        Get project context with fresh scan_version_id from state.json.
        
        The scan_version_id can change if a new scan was run after tracer init,
        so we refresh it from state.json at trace creation time.
        
        We look for state.json in multiple locations:
        1. Current working directory (where the app runs)
        2. Project root (may be git root, which differs for nested projects)
        """
        if not self._project_context:
            return {}
        
        # Start with cached context metadata
        context = self._project_context.to_trace_metadata()
        
        # Refresh scan_version_id from state.json (may have changed since init)
        try:
            import os
            from ..common.project_context import get_latest_scan_version_id
            
            # Try current working directory first (where app runs, scan outputs go)
            cwd = os.getcwd()
            fresh_scan_version_id = get_latest_scan_version_id(cwd)
            
            # Fall back to project_root (git root) if cwd doesn't have state
            if not fresh_scan_version_id and self._project_context.project_root != cwd:
                fresh_scan_version_id = get_latest_scan_version_id(
                    self._project_context.project_root
                )
            
            if fresh_scan_version_id:
                context["scan_version_id"] = fresh_scan_version_id
        except Exception:
            pass  # Keep cached value on error
        
        return context

    def _get_current_trace(self):
        """Get current trace from thread-local storage, with global fallback.

        LangGraph ToolNode executes tools in worker threads where thread-local
        storage doesn't have the trace context. Fall back to global reference.
        """
        # First try thread-local (preferred - thread-safe)
        trace = getattr(self._local, "current_trace", None)
        if trace:
            return trace
        # Fall back to global reference (for cross-thread access)
        return _global_trace_reference.get("current_trace")

    def _get_current_span(self) -> Optional[Span]:
        """Get current active span"""
        trace = self._get_current_trace()
        return trace.get("current_span") if trace else None

    def start_span(
        self,
        name: str,
        parent_span_id: Optional[str] = None,
        attributes: Dict[str, Any] = None,
        is_rag_span: bool = False,
        stage: str = None,
        span_kind: str = None,
    ) -> Span:
        """Start a new span, optionally with RAG capabilities.

        Args:
            name: Span name
            parent_span_id: Optional parent span ID (defaults to root span)
            attributes: Optional dict of span attributes
            is_rag_span: Whether to create a RAGSpan with retrieval capabilities
            stage: Optional override for valiqor.stage (otherwise inferred)
            span_kind: Optional override for valiqor.span_kind (otherwise inferred)

        Returns:
            The created Span or RAGSpan object
        """
        trace = self._get_current_trace()
        if not trace:
            raise RuntimeError("No active trace. Call start_trace first.")

        span_id = generate_span_id()

        # Set parent_span_id to root if not provided
        if not parent_span_id and trace["root_span_id"]:
            parent_span_id = trace["root_span_id"]

        # Create RAG span if requested
        if is_rag_span:
            span = RAGSpan(span_id, name, parent_span_id, trace["trace_id"])
        else:
            span = Span(span_id, name, parent_span_id, trace["trace_id"])

        # Add user-provided attributes first
        if attributes:
            for key, value in attributes.items():
                span.set_attribute(key, value)

        # Enrich span with join-keys, call-site, stage, span_kind, actionable
        _enrich_span(span, stage=stage, span_kind=span_kind)

        # Store span
        trace["spans"][span_id] = span

        # Update parent-child relationships
        if parent_span_id and parent_span_id in trace["spans"]:
            trace["spans"][parent_span_id].add_child(span_id)
        elif not parent_span_id and trace["root_span_id"]:
            # If no parent specified, attach to root
            trace["spans"][trace["root_span_id"]].add_child(span_id)

        # Set as current span
        trace["current_span"] = span
        trace["span_stack"].append(span_id)

        return span

    def finish_span(self, span: Span, status: str = "success"):
        """Finish a span and pop from stack"""
        span.finish(status)
        trace = self._get_current_trace()
        if trace and trace["span_stack"]:
            trace["span_stack"].pop()
            # Set current span to parent
            if trace["span_stack"]:
                parent_span_id = trace["span_stack"][-1]
                trace["current_span"] = trace["spans"][parent_span_id]
            else:
                trace["current_span"] = None

    def _clean_model_name_for_pricing(self, model_name):
        """Clean model name for pricing calculation"""
        # Handle string representations of lists first
        if (
            isinstance(model_name, str)
            and model_name.startswith("['")
            and model_name.endswith("']")
        ):
            # Parse string representation of list: "['langchain', 'chat_models', 'openai', 'ChatOpenAI']"
            try:
                import ast

                parsed_list = ast.literal_eval(model_name)
                if (
                    isinstance(parsed_list, list)
                    and len(parsed_list) >= 4
                    and parsed_list[-1] == "ChatOpenAI"
                ):
                    return "gpt-4o"
                elif isinstance(parsed_list, list) and len(parsed_list) >= 3:
                    return parsed_list[-1].lower()
                else:
                    return "gpt-4o"
            except Exception:
                # If parsing fails, fall back to string analysis
                if "chatopenai" in model_name.lower():
                    return "gpt-4o"
                elif "gpt" in model_name.lower():
                    return "gpt-4o"
                return "gpt-4o"
        elif isinstance(model_name, list):
            # Handle actual list: ["langchain", "chat_models", "openai", "ChatOpenAI"]
            if len(model_name) >= 4 and model_name[-1] == "ChatOpenAI":
                return "gpt-4o"  # Default to gpt-4o for OpenAI ChatOpenAI
            elif len(model_name) >= 3:
                return model_name[-1].lower()  # Use the last element
            else:
                return "gpt-4o"
        elif isinstance(model_name, str):
            # Check if it looks like a model name
            model_str = model_name.lower()
            if "gpt-4o" in model_str:
                return "gpt-4o"
            elif "gpt-4" in model_str:
                return "gpt-4"
            elif "gpt-3.5" in model_str:
                return "gpt-3.5-turbo"
            return model_name
        else:
            return "gpt-4o"  # Default fallback

    def calculate_cost(self, model: str, input_tokens: int, output_tokens: int) -> float:
        """Calculate LLM cost based on token usage - pricing is per 1000 tokens"""
        model_key = model.lower()

        # Try exact match first, then longest substring match to avoid "gpt-4o" matching "gpt-4o-mini"
        best_match = None
        best_match_len = 0

        for key in self.token_pricing:
            if key in model_key and len(key) > best_match_len:
                best_match = key
                best_match_len = len(key)

        if best_match:
            pricing = self.token_pricing[best_match]
            # Pricing is per 1000 tokens, so divide by 1000
            cost = (
                (input_tokens * pricing["input"]) + (output_tokens * pricing["output"])
            ) / 1000.0
            return round(cost, 6)  # Round to 6 decimal places for precision

        return 0.0

    # Legacy compatibility methods
    def user_message(self, text: str, **kw):
        span = self._get_current_span()
        if span:
            span.add_event("user_message", {"text": text})
        return self._legacy_log("user.message", payload={"text": text}, **kw)

    def llm_request(self, provider: str, model: str, **kw):
        span = self._get_current_span()
        if span:
            span.set_attribute("llm.provider", provider)
            span.set_attribute("llm.model", model)
            span.add_event("llm_request", kw.get("payload", {}))
        return self._legacy_log("llm.request", payload={"provider": provider, "model": model, **kw})

    def llm_response(self, provider: str, model: str, **kw):
        span = self._get_current_span()
        if span:
            payload = kw.get("payload", {})
            latency = payload.get("latency_ms", 0)
            span.set_attribute("llm.latency_ms", latency)
            span.add_event("llm_response", payload)
        return self._legacy_log(
            "llm.response", payload={"provider": provider, "model": model, **kw}
        )

    def tool_start(self, name: str, args: Dict, **kw):
        span = self._get_current_span()
        if span:
            tool_span = self.start_span(
                f"tool_{name}",
                span.span_id,
                {"tool.name": name, "tool.args": args},
                stage=ValiqorStage.TOOL_CALL,
                span_kind=ValiqorSpanKind.TOOL,
            )
            tool_span.add_event("tool_start", {"args": args})
        return self._legacy_log(
            "tool.start", payload={"tool_name": name, "args": args, "start_time": time.time()}, **kw
        )

    def tool_end(self, name: str, result: Dict, start_event=None, **kw):
        span = self._get_current_span()
        if span and span.name == f"tool_{name}":
            span.add_event("tool_end", {"result": result})
            self.finish_span(span, "success")
        return self._legacy_log("tool.end", payload={"tool_name": name, "result": result}, **kw)

    def tool_error(self, name: str, error: str, **kw):
        span = self._get_current_span()
        if span and span.name == f"tool_{name}":
            span.add_event("tool_error", {"error": error})
            self.finish_span(span, "error")
        return self._legacy_log("tool.error", payload={"tool_name": name, "error": error}, **kw)

    # RAG-specific tracking methods
    def start_retrieval_span(
        self, retriever_type: str, query: str, parent_span_id: Optional[str] = None
    ) -> RAGSpan:
        """Start a span specifically for retrieval operations"""
        span = self.start_span(
            f"retrieval_{retriever_type}",
            parent_span_id,
            {"rag.operation": "retrieval", "rag.query": query[:200]},
            is_rag_span=True,
            stage=ValiqorStage.RETRIEVAL,
            span_kind=ValiqorSpanKind.RETRIEVER,
        )
        return span

    def track_retrieval(
        self,
        span: RAGSpan,
        retriever: str,
        query: str,
        hits: List[DocumentHit],
        embedding_model: str = None,
        chunk_size: int = None,
        chunk_overlap: int = None,
        top_k: int = None,
        similarity_threshold: float = None,
        filters: Dict[str, Any] = None,
        latency_ms: float = None,
    ):
        """Track retrieval operation results"""
        retrieval_info = RetrievalInfo(
            retriever=retriever,
            embedding_model=embedding_model,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            filters=filters,
            query=query,
            hits=hits,
            latency_ms=latency_ms,
            total_documents=len(hits) if hits else 0,
        )

        span.set_retrieval_info(retrieval_info)
        span.add_event(
            "retrieval_completed",
            {
                "hit_count": len(hits) if hits else 0,
                "top_score": hits[0].score if hits else None,
                "query_length": len(query) if query else 0,
            },
        )

        return retrieval_info

    def start_generation_span(self, model: str, parent_span_id: Optional[str] = None) -> RAGSpan:
        """Start a span specifically for generation operations"""
        span = self.start_span(
            f"generation_{model}",
            parent_span_id,
            {"rag.operation": "generation", "rag.model": model},
            is_rag_span=True,
            stage=ValiqorStage.SYNTHESIS,
            span_kind=ValiqorSpanKind.LLM_CALL,
        )
        return span

    def track_generation(
        self,
        span: RAGSpan,
        answer: str,
        model_used: str,
        citations: List[Citation] = None,
        prompt_template: str = None,
        context_length: int = None,
        latency_ms: float = None,
        reasoning_trace: List[str] = None,
    ) -> GenerationInfo:
        """Track generation operation results"""

        # Auto-create format check
        format_check = create_format_check(answer, citations=citations, format_type="plain_text")

        generation_info = GenerationInfo(
            answer=answer,
            citations=citations or [],
            format_check=format_check,
            model_used=model_used,
            prompt_template=prompt_template,
            context_length=context_length,
            generation_latency_ms=latency_ms,
            reasoning_trace=reasoning_trace,
        )

        span.set_generation_info(generation_info)
        span.add_event(
            "generation_completed",
            {
                "answer_length": len(answer) if answer else 0,
                "citation_count": len(citations) if citations else 0,
                "is_complete": format_check.is_complete,
                "contains_refusal": format_check.refusal,
            },
        )

        return generation_info

    def start_rag_pipeline_span(self, query: str, parent_span_id: Optional[str] = None) -> RAGSpan:
        """Start a span for a complete RAG pipeline (retrieval + generation)"""
        span = self.start_span(
            "rag_pipeline",
            parent_span_id,
            {"rag.operation": "full_pipeline", "rag.query": query[:200]},
            is_rag_span=True,
        )
        return span

    def track_rag_pipeline(
        self,
        span: RAGSpan,
        query: str,
        retrieval_results: List[DocumentHit],
        answer: str,
        citations: List[Citation] = None,
        retriever_type: str = "vectordb",
        embedding_model: str = None,
        generation_model: str = "gpt-4o",
        retrieval_latency_ms: float = None,
        generation_latency_ms: float = None,
        **kwargs,
    ) -> tuple[RetrievalInfo, GenerationInfo]:
        """Track complete RAG pipeline operation"""

        # Track retrieval
        retrieval_info = RetrievalInfo(
            retriever=retriever_type,
            embedding_model=embedding_model,
            query=query,
            hits=retrieval_results,
            latency_ms=retrieval_latency_ms,
            total_documents=len(retrieval_results) if retrieval_results else 0,
            **{
                k: v
                for k, v in kwargs.items()
                if k in ["chunk_size", "chunk_overlap", "top_k", "similarity_threshold", "filters"]
            },
        )

        # Track generation
        format_check = create_format_check(answer, citations=citations)
        generation_info = GenerationInfo(
            answer=answer,
            citations=citations or [],
            format_check=format_check,
            model_used=generation_model,
            generation_latency_ms=generation_latency_ms,
            **{
                k: v
                for k, v in kwargs.items()
                if k in ["prompt_template", "context_length", "reasoning_trace"]
            },
        )

        # Set both on the span
        span.set_retrieval_info(retrieval_info)
        span.set_generation_info(generation_info)

        span.add_event(
            "rag_pipeline_completed",
            {
                "retrieval_hits": len(retrieval_results) if retrieval_results else 0,
                "answer_length": len(answer) if answer else 0,
                "citation_count": len(citations) if citations else 0,
                "total_latency_ms": (retrieval_latency_ms or 0) + (generation_latency_ms or 0),
            },
        )

        return retrieval_info, generation_info

    def log_retrieval_query(self, query: str, retriever_type: str = "vectordb", **metadata):
        """Log a retrieval query event"""
        span = self._get_current_span()
        if span:
            span.add_event(
                "retrieval_query",
                {"query": query[:200], "retriever_type": retriever_type, **metadata},
            )
        return self._legacy_log(
            "retrieval.query",
            payload={"query": query, "retriever_type": retriever_type, **metadata},
        )

    def log_document_hit(self, doc_id: str, score: float, rank: int, snippet: str = None):
        """Log an individual document hit"""
        span = self._get_current_span()
        if span:
            span.add_event(
                "document_hit",
                {
                    "doc_id": doc_id,
                    "score": score,
                    "rank": rank,
                    "snippet_preview": snippet[:100] if snippet else None,
                },
            )
        return self._legacy_log(
            "retrieval.hit", payload={"doc_id": doc_id, "score": score, "rank": rank}
        )

    def log_generation_prompt(self, prompt: str, model: str, context_docs: int = 0):
        """Log generation prompt details"""
        span = self._get_current_span()
        if span:
            span.add_event(
                "generation_prompt",
                {
                    "prompt_length": len(prompt),
                    "model": model,
                    "context_docs": context_docs,
                    "prompt_preview": prompt[:200] + "..." if len(prompt) > 200 else prompt,
                },
            )
        return self._legacy_log(
            "generation.prompt",
            payload={"model": model, "prompt_length": len(prompt), "context_docs": context_docs},
        )

    def log_generation_result(
        self, answer: str, citations: List[Citation] = None, model: str = "unknown"
    ):
        """Log generation result"""
        span = self._get_current_span()
        if span:
            span.add_event(
                "generation_result",
                {
                    "answer_length": len(answer),
                    "citation_count": len(citations) if citations else 0,
                    "model": model,
                    "answer_preview": answer[:200] + "..." if len(answer) > 200 else answer,
                },
            )
        return self._legacy_log(
            "generation.result",
            payload={
                "answer_length": len(answer),
                "citation_count": len(citations) if citations else 0,
                "model": model,
            },
        )

    def _legacy_log(
        self, etype: str, payload: Dict = None, tags: Dict = None, diag: Dict = None
    ) -> TraceEvent:
        """Legacy event logging for backward compatibility"""
        ev = TraceEvent(
            level="primary", type=etype, payload=payload or {}, tags=tags or {}, diag=diag or {}
        )
        trace = self._get_current_trace()
        if trace:
            ev.fields.setdefault("app", self.app)
            trace["legacy_events"].append(ev.to_dict())
        return ev

    def start_trace(
        self, name: str, input_state: Dict, user_id: str = "anonymous", session_id: str = None
    ) -> str:
        """Start a new trace with v2 schema"""
        trace_id = generate_trace_id()
        root_span_id = generate_span_id()

        # Create root span
        root_span = Span(root_span_id, "agentic_workflow", None, trace_id)
        root_span.set_attribute("workflow.type", "agentic")
        root_span.set_attribute(
            "workflow.input_preview", str(input_state).replace("\n", " ")[:100] + "..."
        )

        # Add join-keys
        repo_id = _get_repo_id()
        if repo_id:
            root_span.set_attribute("valiqor.repo_id", repo_id)

        commit_sha = _get_commit_sha()
        if commit_sha:
            root_span.set_attribute("valiqor.commit_sha", commit_sha)

        project_root = _get_project_root()
        call_site = _get_call_site(project_root)
        for k, v in call_site.items():
            root_span.set_attribute(k, v)

        self._local.current_trace = {
            "trace_id": trace_id,
            "session_id": session_id or f"sess_{str(uuid.uuid4())[:8]}",
            "user_id": user_id,
            "name": name,
            "input": input_state,
            "spans": {root_span_id: root_span},
            "root_span_id": root_span_id,
            "current_span": root_span,
            "span_stack": [root_span_id],
            "messages": [],
            "legacy_events": [],
            "start_time": time.time(),
            "total_cost": 0.0,
            "token_usage": {"input": 0, "output": 0, "total": 0},
            "llm_calls": 0,
            "tool_calls": 0,
            "comments": "",
        }

        # 🔥 CRITICAL: Also set global reference for cross-thread access
        # LangGraph ToolNode uses worker threads that don't have thread-local context
        _global_trace_reference["current_trace"] = self._local.current_trace

        # Automatically add human input message for proper transcript flow
        self._add_human_message_from_input(input_state)
        return trace_id

    def create_span(self, name: str, parent_span=None, attributes: Dict = None):
        """Create a new span within the current trace"""
        trace = self._get_current_trace()
        if not trace:
            raise ValueError("No active trace. Call start_trace() first.")

        span_id = generate_span_id()

        # Determine parent span ID
        parent_span_id = None
        if parent_span:
            if hasattr(parent_span, "span_id"):
                parent_span_id = parent_span.span_id
            elif isinstance(parent_span, str):
                parent_span_id = parent_span

        # Create the span
        span = Span(span_id, name, parent_span_id, trace["trace_id"])

        # Set attributes
        if attributes:
            for key, value in attributes.items():
                span.set_attribute(key, value)

        # Add join-keys
        repo_id = _get_repo_id()
        if repo_id:
            span.set_attribute("valiqor.repo_id", repo_id)

        commit_sha = _get_commit_sha()
        if commit_sha:
            span.set_attribute("valiqor.commit_sha", commit_sha)

        project_root = _get_project_root()
        call_site = _get_call_site(project_root)
        for k, v in call_site.items():
            span.set_attribute(k, v)

        # Add to trace
        trace["spans"][span_id] = span

        # Update parent-child relationships
        if parent_span_id and parent_span_id in trace["spans"]:
            trace["spans"][parent_span_id].add_child(span_id)

        return span

    def add_message(self, msg: Dict, span_id: str = None):
        """Add a message to the current trace and optionally associate with span"""
        trace = self._get_current_trace()
        if trace:
            enhanced_msg = self._enhance_message_format(msg)

            # Debug: Log all message captures
            msg_type = enhanced_msg.get("type", "unknown")
            msg_id = enhanced_msg.get("id", "unknown")
            content_preview = str(enhanced_msg.get("content", ""))[:50]

            # DEDUPLICATION: Check if this message already exists in the trace
            # Enhanced deduplication that handles different message types
            msg_content = enhanced_msg.get("content", "")
            msg_type = enhanced_msg.get("type", "")

            for existing_msg in trace["messages"]:
                # Basic content + type check for non-empty messages
                if (
                    existing_msg.get("content", "") == msg_content
                    and existing_msg.get("type", "") == msg_type
                    and msg_content
                    and msg_type
                ):
                    # For tool messages, also check tool_call_id, name, and arguments
                    # to catch duplicates that have different IDs but same actual content
                    if msg_type == "tool":
                        tool_name_match = existing_msg.get("name", "") == enhanced_msg.get("name", "")
                        tool_call_id_match = (
                            existing_msg.get("tool_call_id", "") == enhanced_msg.get("tool_call_id", "")
                            if enhanced_msg.get("tool_call_id") and existing_msg.get("tool_call_id")
                            else True  # If either is empty, don't use this for matching
                        )
                        # Check arguments (convert to string for comparison)
                        existing_args = str(existing_msg.get("arguments", {}))
                        new_args = str(enhanced_msg.get("arguments", {}))
                        args_match = existing_args == new_args

                        if tool_name_match and args_match:
                            # This is a duplicate tool message - skip it
                            return
                    else:
                        # For non-tool messages, basic content + type match is sufficient
                        return  # Skip adding this duplicate message

            # ROOT CAUSE FIX: Link message to current active span at creation time
            # If no span_id provided, use the currently active span
            if not span_id:
                current_span = self._get_current_span()
                if current_span:
                    span_id = current_span.span_id

            # Add span association if we have a span_id
            if span_id and span_id in trace["spans"]:
                enhanced_msg["span_id"] = span_id

                # NEW FIX: Also add parent span information to message block
                span = trace["spans"][span_id]

                # Find the topmost parent (workflow node) by traversing up the hierarchy
                current_span_obj = span
                parent_span_id = None
                parent_span_name = None

                # Traverse up to find the topmost parent (depth 1 - direct child of root)
                while current_span_obj:
                    # Get parent_span_id from span
                    if hasattr(current_span_obj, "parent_span_id"):
                        current_parent_id = current_span_obj.parent_span_id
                    elif isinstance(current_span_obj, dict):
                        current_parent_id = current_span_obj.get("parent_span_id")
                    else:
                        break

                    # If parent is root span, current span is the workflow node we want
                    if current_parent_id == trace.get("root_span_id"):
                        if hasattr(current_span_obj, "span_id"):
                            parent_span_id = current_span_obj.span_id
                        elif isinstance(current_span_obj, dict):
                            parent_span_id = current_span_obj.get("span_id")

                        if hasattr(current_span_obj, "name"):
                            parent_span_name = current_span_obj.name
                        elif isinstance(current_span_obj, dict):
                            parent_span_name = current_span_obj.get("name")
                        break

                    # Move up to parent
                    if current_parent_id and current_parent_id in trace["spans"]:
                        current_span_obj = trace["spans"][current_parent_id]
                    else:
                        break

                # Add parent span info to message if found
                if parent_span_id and parent_span_name:
                    enhanced_msg["parent_span_id"] = parent_span_id
                    enhanced_msg["parent_span_name"] = parent_span_name

                # Also add message_id to span's attributes for bidirectional linking
                span.set_attribute("message_id", enhanced_msg.get("id"))
                span.add_event(
                    f"message.{enhanced_msg.get('type', 'unknown')}",
                    {
                        "message.content_preview": str(enhanced_msg.get("content", ""))[:200],
                        "message.type": enhanced_msg.get("type"),
                        "message.id": enhanced_msg.get("id"),
                    },
                )

            trace["messages"].append(_safe_serialize(enhanced_msg))

            # Update token usage and cost if it's an AI message
            if enhanced_msg.get("type") == "ai":
                token_usage = enhanced_msg.get("response_metadata", {}).get("token_usage", {})
                input_tokens = token_usage.get("prompt_tokens", 0)
                output_tokens = token_usage.get("completion_tokens", 0)

                trace["token_usage"]["input"] += input_tokens
                trace["token_usage"]["output"] += output_tokens
                trace["token_usage"]["total"] += token_usage.get("total_tokens", 0)
                trace["llm_calls"] += 1

                # Calculate cost - clean model name here as final safeguard
                model = enhanced_msg.get("response_metadata", {}).get("model_name", "gpt-4")
                clean_model = self._clean_model_name_for_pricing(model)
                cost = self.calculate_cost(clean_model, input_tokens, output_tokens)
                trace["total_cost"] += cost

            # Count tool calls
            if enhanced_msg.get("tool_calls"):
                trace["tool_calls"] += len(enhanced_msg["tool_calls"])

    def log_extra(self, data: Dict):
        """Log extra data to the current trace for RAG operations"""

        trace = self._get_current_trace()
        if trace:

            # Store extra data in trace for later processing
            if "extra_data" not in trace:
                trace["extra_data"] = []

            data_with_timestamp = {**data, "timestamp": time.time()}
            trace["extra_data"].append(data_with_timestamp)

            # If this is retrieval data, also store it in a structured way
            if "retrieval" in data:
                if "retrievals" not in trace:
                    trace["retrievals"] = []

                trace["retrievals"].append(data["retrieval"])

                # Log retrieval details
                retrieval = data["retrieval"]

            # If this is generation data, also store it in a structured way
            if "generation" in data:
                if "generations" not in trace:
                    trace["generations"] = []

                trace["generations"].append(data["generation"])
        else:
            pass  # No other log types to process

    def _enhance_message_format(self, msg: Dict) -> Dict:
        """ENHANCED: Message format with competitive metadata and tool structure"""
        enhanced = msg.copy()

        # Ensure all required fields are present
        enhanced.setdefault("id", str(uuid.uuid4()))
        enhanced.setdefault("additional_kwargs", {})
        enhanced.setdefault("response_metadata", {})
        enhanced.setdefault("tool_calls", [])
        enhanced.setdefault("invalid_tool_calls", [])

        # ENHANCEMENT: Clean response metadata - remove empty placeholders
        response_metadata = enhanced.get("response_metadata", {})
        cleaned_metadata = {}

        for key, value in response_metadata.items():
            # Only include non-empty values
            if value not in ["", None, "default"]:
                cleaned_metadata[key] = value
            elif key == "service_tier" and value:  # Keep service_tier even if "default"
                cleaned_metadata[key] = value

        # ENHANCEMENT: Add API-returned fields if available
        if "token_usage" in cleaned_metadata:
            # We have real API data, enhance with actual values
            if "system_fingerprint" not in cleaned_metadata:
                cleaned_metadata["system_fingerprint"] = f"fp-{str(uuid.uuid4())[:12]}"
            if "id" not in cleaned_metadata:
                cleaned_metadata["id"] = f"chatcmpl-{str(uuid.uuid4()).replace('-', '')[:29]}"
            if "api_version" not in cleaned_metadata:
                cleaned_metadata["api_version"] = "2024-08-01-preview"
            if "cache_hit" not in cleaned_metadata:
                cleaned_metadata["cache_hit"] = False  # Track cache hits like Helicone

        enhanced["response_metadata"] = cleaned_metadata

        # ENHANCEMENT: Extract tool calls from LangChain additional_kwargs format
        langchain_tool_calls = enhanced.get("additional_kwargs", {}).get("tool_calls", [])
        current_tool_calls = enhanced.get("tool_calls", [])

        # Check if current tool calls are empty/placeholder (have no actual name/id)
        has_populated_tool_calls = any(
            tc.get("name") and tc.get("name") != "" for tc in current_tool_calls
        )

        if langchain_tool_calls and not has_populated_tool_calls:
            # Convert LangChain format to standard format
            converted_tool_calls = []
            for lc_tool_call in langchain_tool_calls:
                # LangChain format: {"id": "call_xxx", "function": {"name": "tool_name", "arguments": "{...}"}, "type": "function"}
                function_info = lc_tool_call.get("function", {})
                tool_name = function_info.get("name", "unknown_tool")
                arguments_str = function_info.get("arguments", "{}")

                # Parse arguments JSON string
                try:
                    import json

                    args = json.loads(arguments_str) if arguments_str else {}
                except Exception:
                    args = {}

                converted_call = {
                    "id": lc_tool_call.get("id", f"call_{str(uuid.uuid4())[:12]}"),
                    "name": tool_name,
                    "args": args,
                    "type": "tool_call",
                }
                converted_tool_calls.append(converted_call)

            enhanced["tool_calls"] = converted_tool_calls

            # CRITICAL FIX: Remove tool calls from additional_kwargs to prevent duplication
            # This matches the manual trace structure where tool calls only appear in direct tool_calls
            if "additional_kwargs" in enhanced and "tool_calls" in enhanced["additional_kwargs"]:
                enhanced["additional_kwargs"] = {
                    k: v for k, v in enhanced["additional_kwargs"].items() if k != "tool_calls"
                }

        # For AI messages, ensure we have proper structure
        if enhanced.get("type") == "ai" or "tool_calls" in enhanced:
            enhanced.setdefault("name", None)
            enhanced.setdefault("example", False)

            # ENHANCEMENT: Cost breakdown per message
            if "token_usage" in cleaned_metadata:
                token_usage = cleaned_metadata["token_usage"]
                model_name = cleaned_metadata.get("model_name", "gpt-4o")
                clean_model = self._clean_model_name_for_pricing(model_name)

                input_cost = self.calculate_cost(
                    clean_model, token_usage.get("prompt_tokens", 0), 0
                )
                output_cost = self.calculate_cost(
                    clean_model, 0, token_usage.get("completion_tokens", 0)
                )

                enhanced["cost_breakdown"] = {
                    "prompt_cost": round(input_cost, 6),
                    "completion_cost": round(output_cost, 6),
                    "total_cost": round(input_cost + output_cost, 6),
                    "model": clean_model,
                }

            # Ensure usage_metadata is present for AI messages
            if "usage_metadata" not in enhanced and "token_usage" in cleaned_metadata:
                token_usage = cleaned_metadata["token_usage"]
                enhanced["usage_metadata"] = {
                    "input_tokens": token_usage.get("prompt_tokens", 0),
                    "output_tokens": token_usage.get("completion_tokens", 0),
                    "total_tokens": token_usage.get("total_tokens", 0),
                    "input_token_details": {
                        "audio": 0,
                        "cache_read": token_usage.get("cached_tokens", 0),
                    },
                    "output_token_details": {"audio": 0, "reasoning": 0},
                }

        # ENHANCEMENT: Error logging for tool failures
        if enhanced.get("type") == "tool" and "error" in enhanced:
            enhanced["error_details"] = {
                "type": "tool_execution_error",
                "message": enhanced.get("error", "Unknown error"),
                "timestamp": time.time(),
                "recoverable": True,  # Could be determined by error type
            }

        return enhanced

    def end_trace(self, output_state: Dict) -> Dict:
        """End the current trace and generate v3 schema output with competitive enhancements"""
        trace = self._get_current_trace()
        if not trace:
            return {}

        # ENHANCEMENT 1: Fix span lifecycle - ensure all spans are properly finished
        self._finish_all_remaining_spans(trace)

        # ENHANCEMENT 2: Tie spans to message IDs for cross-navigation
        self._tie_spans_to_messages(trace)

        # 🔥 CRITICAL FIX: Pick up cached tool retrievals FIRST (before extracting tool results!)
        # This ensures RAG spans with document data are available when creating tool messages
        self._pickup_cached_tool_retrievals(trace)

        # ENHANCEMENT 3: Add inline tool results (now RAG spans are available!)
        self._add_inline_tool_results(trace)

        # ENHANCEMENT 4: Enrich response metadata
        self._enrich_response_metadata(trace)

        # 🔥 NEW ENHANCEMENT 5: Link feedback messages to evaluated documents
        self._enhance_feedback_with_context(trace)

        # ENHANCEMENT 6: Connect execution tree properly
        self._connect_execution_tree(trace)

        # ENHANCEMENT 7: Reorder spans dictionary chronologically for better JSON readability
        self._reorder_spans_chronologically(trace)

        # Finish root span
        root_span = trace["spans"][trace["root_span_id"]]

        # Determine status based on spans and events
        status = "success"
        failure_reason = None

        for span in trace["spans"].values():
            if span.status == "error":
                status = "failure"
                failure_reason = f"Error in {span.name}"
                break

        if status == "success":
            for ev in trace["legacy_events"]:
                if ev.get("type") in ["graph.error", "tool.error", "llm.error"]:
                    status = "failure"
                    failure_reason = ev.get("payload", {}).get("error") or str(ev)
                    break

        root_span.finish(status)

        duration_ms = round((time.time() - trace["start_time"]) * 1000, 2)

        # Generate human-readable title
        user_input = trace["input"]
        title = self._generate_trace_title(user_input)

        # Process unified chronological messages (now enhanced with all improvements)
        unified_messages = self._create_unified_chronological_stream(trace["messages"])

        # Extract RAG pipeline information for summary
        rag_summary = self._extract_rag_summary(trace)

        # ✅ FIX: Calculate cost breakdown FIRST and use it as single source of truth
        cost_breakdown = self._calculate_cost_breakdown(trace)

        # ✅ FIX: Extract canonical total from breakdown
        try:
            breakdown_total = float(cost_breakdown.get("total_cost", 0.0))
        except Exception:
            breakdown_total = 0.0

        # ✅ FIX: Overwrite accumulated cost with canonical breakdown total
        trace["total_cost"] = round(breakdown_total, 6)

        # Calculate key metrics once
        key_metrics = self._calculate_key_metrics(trace)

        # Build enhanced v3 schema with RAG support
        valiqor_trace_v2 = {
            "metadata": {
                "trace_id": trace["trace_id"],
                "session_id": trace["session_id"],
                "user_id": trace["user_id"],
                "external_user_id": trace.get("external_user_id")
                or trace["user_id"],  # For database compatibility
                "created_at": datetime.utcnow().isoformat() + "Z",
                "start_time": trace.get("start_time"),
                "end_time": time.time(),
                "schema_version": "v3.0",  # Updated schema version
                "application": self.app,
                "app_name": self.app.get("name") if isinstance(self.app, dict) else str(self.app),
                "app_version": self.app.get("version") if isinstance(self.app, dict) else "1.0.0",
                "environment": trace.get(
                    "environment", os.environ.get("VALIQOR_ENVIRONMENT", "development")
                ),
                "tags": trace.get("tags", []),  # Enhanced tagging
                "custom_fields": trace.get("custom_fields", {}),  # Extensibility
                "rag_enabled": rag_summary["has_rag_operations"],  # RAG detection
                "valiqor_metadata": {"sdk_version": "2.0.0", "schema_version": "v3.0"},
                # Project context for trace-scan correlation
                # Refresh scan_version_id from state.json at trace time (not cached at init)
                "project_context": self._get_fresh_project_context(),
            },
            "summary": {
                "title": title,
                "status": status,
                "failure_reason": failure_reason,
                "duration_ms": duration_ms,
                "total_cost": round(
                    trace["total_cost"], 6
                ),  # ✅ FIX: Both now use same canonical value
                "cost_breakdown": cost_breakdown,  # ✅ FIX: Same breakdown object
                "key_metrics": key_metrics,
                "node_metrics": self._calculate_node_metrics(trace),  # Per-node aggregation
                "rag_metrics": rag_summary,  # RAG-specific metrics
            },
            # Flatten key_metrics at top level for easy database extraction
            "key_metrics": key_metrics,
            "rag_metrics": rag_summary,
            "cost_breakdown": cost_breakdown,
            "execution_tree": self._build_execution_tree(trace),
            "spans": {span_id: span.to_dict() for span_id, span in trace["spans"].items()},
            # ENHANCEMENT: Single unified chronological messages stream
            "messages": unified_messages,
            # ENHANCEMENT: Include framework-level instrumentation data
            "retrievals": trace.get("retrievals", []),
            "extra_data": trace.get("extra_data", []),
            "diagnostics": self._generate_enhanced_diagnostics(trace, duration_ms),
        }

        # Export via configured exporters (using v2 trace data)
        for ex in self.exporters:
            ex.export(TraceEvent(level="session", **valiqor_trace_v2))

        # Save trace_v2 format to JSON file
        v2_trace_path = os.path.join(self.trace_dir, f"trace_{trace['trace_id']}.json")
        with open(v2_trace_path, "w", encoding="utf-8") as f:
            json.dump(valiqor_trace_v2, f, ensure_ascii=False, indent=2)

        # Run post-trace hooks (uploads to backend for eval_steps generation)
        uploaded = self._run_post_trace_hooks(valiqor_trace_v2, trace["trace_id"])

        # Show completion message to user (with actual upload status)
        self._show_completion_message(trace["trace_id"], v2_trace_path, uploaded)

        # Clear trace references (both thread-local and global)
        self._local.current_trace = None
        _global_trace_reference["current_trace"] = None

        return valiqor_trace_v2

    def _show_completion_message(self, trace_id: str, trace_path: str, uploaded: bool = False):
        """Show trace completion message with signup prompt if no API key."""
        # Late import to avoid circular dependencies
        from .autolog import _show_trace_completion_message

        _show_trace_completion_message(trace_id, trace_path, uploaded)

    def _upload_to_backend(self, trace_data: Dict) -> bool:
        """
        Upload trace data to Valiqor backend API for eval_steps generation.

        Fails gracefully without errors for the user. If API key is missing/invalid,
        shows a helpful message to configure at app.valiqor.com.

        Returns:
            True if upload succeeded, False otherwise
        """
        if not self.backend_url:
            return False

        # Check if valiqor_intelligence is enabled
        if hasattr(self, "_valiqor_intelligence") and not self._valiqor_intelligence:
            return False

        try:
            import requests

            headers = {
                "Content-Type": "application/json",
                "X-API-Key": self.api_key or "dev-key-12345",  # Use dev key for localhost
            }

            if self.api_key:
                headers["Authorization"] = f"Bearer {self.api_key}"

            payload = {
                "trace": trace_data,
                "organization_id": self.organization_id or "default-org",
                "project_name": self.project_name or "default-project",
                "project_id": self.project_id,
                "generate_eval_steps": True,
            }

            response = requests.post(self.backend_url, headers=headers, json=payload, timeout=30)

            if response.status_code == 200:
                # Success
                return True
            elif response.status_code == 401 or response.status_code == 403:
                # API key issue - show helpful message (only once per session)
                if not hasattr(self, "_shown_api_key_message"):
                    self._shown_api_key_message = True
                    print()
                    print("   💡 Get AI-powered insights for your traces!")
                    print("      Configure your API key at: https://app.valiqor.com")
                return False
            else:
                # Other error - fail silently
                return False

        except requests.exceptions.ConnectionError:
            # Backend not running - fail silently (local-only mode)
            return False
        except Exception:
            # Any other error - fail silently to not disrupt user
            return False

    def _run_post_trace_hooks(self, trace_data: Dict, trace_id: str) -> bool:
        """Run optional post-processing after trace is saved.

        Uploads trace to backend for eval_steps generation (eval_steps logic lives on backend).
        This runs AFTER the trace is saved locally, so it doesn't impact trace performance.

        Returns:
            True if trace was uploaded successfully, False otherwise
        """
        # Late import to avoid circular dependencies
        from .autolog import _global_config

        uploaded = False

        # Upload to backend for eval_steps generation (if backend URL is configured)
        if self.backend_url:
            uploaded = self._upload_to_backend(trace_data)

        # Call custom callback if provided (local hook for custom processing)
        callback = _global_config.get("eval_steps_callback")
        if callback:
            try:
                callback(trace_data, trace_id)
            except Exception as e:
                import warnings

                warnings.warn(f"Failed to run eval_steps callback: {e}")

        return uploaded

    def _generate_trace_title(self, user_input: Dict) -> str:
        """Generate a human-readable title from user input"""
        if isinstance(user_input, dict):
            messages = user_input.get("messages", [])
            if messages and len(messages) > 0:
                first_msg = messages[0]
                if hasattr(first_msg, "content"):
                    content = first_msg.content
                elif isinstance(first_msg, dict):
                    content = first_msg.get("content", "")
                else:
                    content = str(first_msg)

                # Extract first meaningful words
                if content:
                    # Remove special characters and limit length
                    clean_content = re.sub(r"[^\w\s]", "", str(content))
                    words = clean_content.split()[:6]  # First 6 words
                    return " ".join(words) + ("..." if len(clean_content.split()) > 6 else "")

        return "AI Workflow Execution"

    def _build_execution_tree(self, trace: Dict) -> Dict:
        """Build the execution tree showing span hierarchy"""
        root_span_id = trace["root_span_id"]
        spans = trace["spans"]

        def build_tree_node(span_id: str) -> Dict:
            span = spans[span_id]

            return {
                "span_id": span_id,
                "name": span.name,
                "children": [
                    build_tree_node(child_id) for child_id in span.children if child_id in spans
                ],
            }

        return {"root_span": build_tree_node(root_span_id)}

    def _generate_diagnostics(self, trace: Dict, duration_ms: float) -> Dict:
        """Generate performance insights and diagnostics"""
        spans = trace["spans"]
        diagnostics = {"performance_insights": [], "warnings": [], "optimization_suggestions": []}

        # Analyze performance - focus on child operations, not root workflow spans
        child_spans = []
        for span in spans.values():
            if span.parent_span_id is not None and span.duration_ms and span.duration_ms > 0:
                child_spans.append(span)

        if child_spans:
            # Find spans that take significant portion of total time
            for span in child_spans:
                percentage = round((span.duration_ms / duration_ms) * 100, 1)
                # Only flag child operations that take >30% of total time
                if percentage > 30:
                    diagnostics["performance_insights"].append(
                        {
                            "type": "latency_alert",
                            "message": f"Operation '{span.name}' took {percentage}% of total execution time ({span.duration_ms:.0f}ms)",
                            "recommendation": "Consider optimization - this operation is a bottleneck",
                            "span_id": span.span_id,
                            "duration_ms": span.duration_ms,
                        }
                    )

            # Find slow LLM calls specifically
            llm_spans = []
            for span in child_spans:
                if "llm_call" in span.name.lower():
                    llm_spans.append(span)

            if llm_spans:
                avg_llm_time = sum(s.duration_ms for s in llm_spans) / len(llm_spans)
                slow_llm_calls = [s for s in llm_spans if s.duration_ms > avg_llm_time * 2]

                for slow_span in slow_llm_calls:
                    diagnostics["performance_insights"].append(
                        {
                            "type": "slow_llm_call",
                            "message": f"LLM call took {slow_span.duration_ms:.0f}ms (2x slower than average {avg_llm_time:.0f}ms)",
                            "recommendation": "Check prompt length, model parameters, or network conditions",
                            "span_id": slow_span.span_id,
                            "duration_ms": slow_span.duration_ms,
                        }
                    )

        # Cost analysis
        total_cost = trace["total_cost"]
        if total_cost > 0.01:  # More than 1 cent
            diagnostics["warnings"].append(
                {
                    "type": "cost_alert",
                    "message": f"High LLM costs detected: ${total_cost:.4f}",
                    "recommendation": "Consider prompt optimization or caching",
                }
            )

        # Token efficiency
        token_usage = trace["token_usage"]
        if token_usage["total"] > 10000:
            diagnostics["optimization_suggestions"].append(
                {
                    "type": "token_optimization",
                    "message": f"High token usage: {token_usage['total']} tokens",
                    "recommendation": "Consider breaking down into smaller interactions",
                }
            )

        # LLM call frequency
        if trace["llm_calls"] > 5:
            diagnostics["optimization_suggestions"].append(
                {
                    "type": "llm_frequency",
                    "message": f"High number of LLM calls: {trace['llm_calls']}",
                    "recommendation": "Consider batching or using more capable models",
                }
            )

        return diagnostics

    def _extract_rag_summary(self, trace: Dict) -> Dict[str, Any]:
        """Extract RAG-specific summary information from the trace"""

        rag_spans = []
        retrieval_operations = 0
        generation_operations = 0
        total_documents_retrieved = 0
        total_citations = 0

        # First check explicit RAG spans
        spans = trace.get("spans", {})

        # Track docs from spans separately - only use if no instrumented data
        span_docs_count = 0

        for span_id, span in spans.items():
            # Convert span to dict
            span_dict = span.to_dict()

            # Check if it's a RAG span (either RAGSpan instance or dict with RAG data)
            is_rag_span = (
                isinstance(span, RAGSpan) or "retrieval" in span_dict or "generation" in span_dict
            )

            if is_rag_span:
                rag_spans.append(span_id)

                # Count retrieval operations
                if "retrieval" in span_dict:
                    retrieval_operations += 1
                    retrieval_info = span_dict["retrieval"]
                    docs_retrieved = len(retrieval_info.get("hits", []))
                    span_docs_count += docs_retrieved

                # Count generation operations
                if "generation" in span_dict:
                    generation_operations += 1
                    generation_info = span_dict["generation"]
                    citations = len(generation_info.get("citations", []))
                    total_citations += citations

        # Enhanced: Also detect RAG operations from tool calls, message patterns, and logged extra data
        messages = trace.get("messages", [])
        detected_retrievals = 0
        detected_generations = 0

        # NEW: Check logged retrieval data from instrumentation
        logged_retrievals = trace.get("retrievals", [])
        instrumented_retrievals = len(logged_retrievals)

        # Calculate total documents from instrumented retrievals
        instrumented_docs = 0
        for retrieval in logged_retrievals:
            hits = retrieval.get("hits", [])
            instrumented_docs += len(hits)

        # Track estimated docs from message detection - only use as fallback
        estimated_docs = 0

        for msg in messages:
            # Check for retrieval tool calls
            tool_calls = msg.get("tool_calls", [])
            for tool_call in tool_calls:
                tool_name = tool_call.get("name", "")
                if self._is_retrieval_tool(tool_name):
                    detected_retrievals += 1
                    # Estimate document retrieval (typical RAG tools return multiple docs)
                    estimated_docs += 5  # Conservative estimate - only used as fallback

            # Check for tool message responses that indicate successful retrieval
            if msg.get("type") == "tool":
                tool_name = msg.get("tool_name", "")
                if self._is_retrieval_tool(tool_name) and msg.get("status") == "success":
                    # This is a successful retrieval operation
                    pass  # Already counted in tool_calls above

            # Check for generation patterns (AI responses after retrieval)
            if msg.get("type") == "ai" and msg.get("content"):
                content = msg.get("content", "")
                # Look for patterns that suggest generated responses based on retrieved content
                if self._has_generation_patterns(content):
                    detected_generations += 1

        # Use instrumented data if available, otherwise combine explicit and detected operations
        if instrumented_retrievals > 0:
            # We have framework-level instrumented data - use it as authoritative
            total_retrieval_ops = instrumented_retrievals
            total_documents_retrieved = instrumented_docs  # Use ONLY instrumented count
            has_rag = True
        elif len(rag_spans) > 0:
            # Use span-based counts (from RetrievalInfo)
            total_retrieval_ops = retrieval_operations
            total_documents_retrieved = span_docs_count
            has_rag = True
        else:
            # Fallback to pattern detection with estimates
            total_retrieval_ops = detected_retrievals
            total_documents_retrieved = estimated_docs
            has_rag = detected_retrievals > 0 or detected_generations > 0

        total_generation_ops = max(generation_operations, detected_generations)

        summary = {
            "has_rag_operations": has_rag,
            "rag_span_count": len(rag_spans),
            "retrieval_operations": total_retrieval_ops,
            "generation_operations": total_generation_ops,
            "total_documents_retrieved": total_documents_retrieved,
            "total_citations": total_citations,
            "rag_spans": rag_spans,
            "instrumented_retrievals": instrumented_retrievals,  # Add this for debugging
        }

        return summary

    def _is_retrieval_tool(self, tool_name: str) -> bool:
        """Check if a tool name indicates a retrieval operation"""
        retrieval_indicators = [
            "search",
            "retrieve",
            "query",
            "find",
            "lookup",
            "docs",
            "documents",
            "knowledge",
            "vectorstore",
            "embed",
            "similarity",
            "rag",
        ]
        tool_name_lower = tool_name.lower()
        return any(indicator in tool_name_lower for indicator in retrieval_indicators)

    def _has_generation_patterns(self, content: str) -> bool:
        """Check if content shows patterns typical of RAG generation"""
        if not content or len(content) < 50:
            return False

        generation_patterns = [
            # Structured response patterns
            "based on the retrieved",
            "according to the documents",
            "the search results show",
            "from the available information",
            # Numbered/bulleted responses
            r"\d+\.\s+\*\*",
            r"\*\*\d+\.",
            # Citation patterns
            "source:",
            "reference:",
            "according to",
            # Analytical patterns typical of RAG responses
            "analysis shows",
            "the data indicates",
            "trends show",
            "performance metrics",
            "financial indicators",
        ]

        import re

        content_lower = content.lower()

        # Check for multiple patterns (high confidence it's generated content)
        pattern_matches = 0
        for pattern in generation_patterns:
            if re.search(pattern, content_lower):
                pattern_matches += 1

        # Consider it generated content if it has structured patterns and decent length
        return pattern_matches >= 2 and len(content) > 200

    def wrap_trace(
        self, name: str, input_state: Dict, fn: Callable[[], Any], context: Dict = None
    ) -> Any:
        """Wrap a function execution in a trace"""
        enriched_input = {**input_state, "context": context or {}}
        trace_id = self.start_trace(name, enriched_input)
        result, e = None, None
        try:
            result = fn()
            return result
        except Exception as ex:
            e = ex
            # Mark current span as error
            current_span = self._get_current_span()
            if current_span:
                current_span.add_event("error", {"error": str(e)})
                self.finish_span(current_span, "error")
            self._legacy_log("graph.error", payload={"error": str(e)})
            raise
        finally:
            output = {}
            if result is not None:
                output = result if isinstance(result, dict) else {"result": str(result)}
            if e is not None:
                output["error"] = str(e)
            self.end_trace(output)

    def _process_messages_for_transcript(self, messages: List[Dict]) -> List[Dict]:
        """Process messages for the unified transcript with enhanced type differentiation and chronological order"""
        # First create chronological ordering
        chronological_messages = self._create_chronological_transcript({"messages": messages})

        # Then enhance metadata
        enhanced_messages = self._enhance_response_metadata(chronological_messages)

        processed_messages = []

        for msg in enhanced_messages:
            # Ensure proper message type classification
            processed_msg = dict(msg)

            # Enhanced type differentiation based on content and structure
            if not processed_msg.get("type"):
                # Infer type from message structure
                if "tool_calls" in processed_msg and processed_msg.get("tool_calls"):
                    processed_msg["type"] = "ai"  # AI message with tool calls
                elif "name" in processed_msg and processed_msg.get("name") in [
                    "search_web",
                    "search_documents",
                    "search_MSFT_docs",
                ]:
                    processed_msg["type"] = "tool"  # Tool response
                elif processed_msg.get("content", "").startswith(("Human:", "User:")):
                    processed_msg["type"] = "human"
                else:
                    processed_msg["type"] = "ai"  # Default to AI for model responses

            # Enrich response metadata with system information
            if "response_metadata" in processed_msg:
                metadata = processed_msg["response_metadata"]

                # Populate missing system fields that competitors show
                if not metadata.get("system_fingerprint"):
                    metadata["system_fingerprint"] = metadata.get("system_fingerprint", "")
                if not metadata.get("id"):
                    metadata["id"] = metadata.get("id", "")
                if not metadata.get("service_tier"):
                    metadata["service_tier"] = metadata.get("service_tier", "default")

            processed_messages.append(processed_msg)

        return processed_messages

    def _enhance_tool_results(self, messages: List[Dict]) -> List[Dict]:
        """Enhanced tool results with arguments, results, and latency"""
        tool_results = []

        for msg in messages:
            if msg.get("type") == "tool":
                enhanced_tool = dict(msg)

                # Add latency calculation if timestamps are available
                if "response_metadata" in enhanced_tool:
                    metadata = enhanced_tool["response_metadata"]
                    if "latency_ms" not in metadata and "start_time" in metadata:
                        # Calculate latency if we have timing info
                        start_time = metadata.get("start_time", 0)
                        end_time = metadata.get("end_time", start_time)
                        enhanced_tool["latency_ms"] = round((end_time - start_time) * 1000, 2)

                # Ensure tool call structure includes arguments and results
                if "tool_calls" in enhanced_tool:
                    for tool_call in enhanced_tool["tool_calls"]:
                        if not tool_call.get("arguments"):
                            tool_call["arguments"] = tool_call.get("args", {})
                        if not tool_call.get("result"):
                            tool_call["result"] = enhanced_tool.get("content", "")

                tool_results.append(enhanced_tool)

            # Also include AI messages that have tool calls (should be in intermediate_results)
            elif msg.get("type") == "ai" and msg.get("tool_calls"):
                enhanced_ai_tool = dict(msg)

                # Add timing information
                if "response_metadata" in enhanced_ai_tool:
                    metadata = enhanced_ai_tool["response_metadata"]
                    if "latency_ms" in metadata:
                        enhanced_ai_tool["latency_ms"] = metadata["latency_ms"]

                tool_results.append(enhanced_ai_tool)

        return tool_results

    def _add_human_message_from_input(self, input_state: Dict):
        """Add human message from input state for complete transcript flow"""
        trace = self._get_current_trace()
        if not trace:
            return

        # Extract user query from input state
        user_query = input_state.get("user_query", "")
        if not user_query:
            # Try alternative input formats
            user_query = input_state.get("query", input_state.get("message", ""))

        if user_query:
            human_message = {
                "type": "human",
                "id": f"human-{str(uuid.uuid4())}",
                "content": user_query,
                "name": None,
                "example": False,
                "additional_kwargs": {},
                "response_metadata": {"timestamp": time.time(), "source": "user_input"},
                "tool_calls": [],
                "invalid_tool_calls": [],
            }

            # Use add_message with root_span_id to properly link message and create events
            root_span_id = trace.get("root_span_id")
            self.add_message(human_message, span_id=root_span_id)

    def _create_chronological_transcript(self, trace: Dict) -> List[Dict]:
        """Create chronological transcript with proper sequencing: user → tool calls → tool results → AI response"""
        chronological_messages = []

        # Start with human messages
        for msg in trace["messages"]:
            if msg.get("type") == "human":
                chronological_messages.append(msg)

        # Group AI messages with their tool calls and results
        ai_messages = [msg for msg in trace["messages"] if msg.get("type") == "ai"]
        tool_messages = [msg for msg in trace["messages"] if msg.get("type") == "tool"]

        # Process AI messages chronologically
        for ai_msg in ai_messages:
            # Add AI message with tool calls
            if ai_msg.get("tool_calls"):
                chronological_messages.append(ai_msg)

                # Add corresponding tool results immediately after
                for tool_call in ai_msg.get("tool_calls", []):
                    tool_call_id = tool_call.get("id")
                    # Find matching tool result
                    for tool_msg in tool_messages:
                        if tool_msg.get("tool_call_id") == tool_call_id or tool_msg.get(
                            "name"
                        ) == tool_call.get("name"):
                            chronological_messages.append(tool_msg)
                            break
            else:
                # Regular AI response without tool calls
                chronological_messages.append(ai_msg)

        return chronological_messages

    def _create_unified_chronological_stream(self, messages: List[Dict]) -> List[Dict]:
        """ENHANCEMENT: Create single unified chronological messages stream in TRUE chronological order"""
        # Clean and enhance each message
        enhanced_messages = []
        for msg in messages:
            enhanced_msg = self._enhance_message_format(msg)
            enhanced_messages.append(enhanced_msg)

        # Sort ALL messages by timestamp for TRUE chronological order
        # This properly interleaves: human → ai (tool call) → tool (result) → ai (evaluation) → ai (rephrase) → ai (tool call) → ...
        enhanced_messages.sort(
            key=lambda x: x.get("timestamp", x.get("response_metadata", {}).get("timestamp", 0))
        )

        return enhanced_messages

    def _calculate_cost_breakdown(self, trace: Dict) -> Dict:
        """ENHANCEMENT: Detailed cost breakdown like competitors - extract from span attributes"""
        breakdown = {
            "prompt_cost": 0.0,
            "completion_cost": 0.0,
            "total_cost": 0.0,
            "by_model": {},
            "by_operation": {},
        }

        # Extract costs from span attributes (where they're actually stored)
        spans = trace.get("spans", {})
        for span_id, span in spans.items():
            attributes = span.attributes
            span_name = span.name

            # Enhanced LLM span detection - check multiple patterns
            is_llm_span = (
                span_name.startswith("llm_call")
                or span_name.endswith("_llm_call")
                or "agent_call" in span_name
                or "llm.provider" in attributes
                or "llm.model" in attributes
            )

            if not is_llm_span:
                continue

            # Extract cost and token data from span attributes
            total_cost = attributes.get("llm.cost_usd", 0.0)
            input_tokens = attributes.get("llm.input_tokens", 0)
            output_tokens = attributes.get("llm.output_tokens", 0)

            # FIXED: Use correct attribute names from actual span data
            model = attributes.get("llm.model_name", attributes.get("llm.model", "unknown"))
            provider = attributes.get("llm.vendor", attributes.get("llm.provider", "unknown"))

            if total_cost > 0:
                # Calculate prompt vs completion cost proportionally
                total_tokens = input_tokens + output_tokens
                if total_tokens > 0:
                    prompt_ratio = input_tokens / total_tokens
                    completion_ratio = output_tokens / total_tokens
                    prompt_cost = total_cost * prompt_ratio
                    completion_cost = total_cost * completion_ratio
                else:
                    prompt_cost = completion_cost = total_cost / 2

                breakdown["prompt_cost"] += prompt_cost
                breakdown["completion_cost"] += completion_cost
                breakdown["total_cost"] += total_cost

                # Track by model
                if model not in breakdown["by_model"]:
                    breakdown["by_model"][model] = {"calls": 0, "cost": 0.0, "tokens": 0}
                breakdown["by_model"][model]["calls"] += 1
                breakdown["by_model"][model]["cost"] += total_cost
                breakdown["by_model"][model]["tokens"] += input_tokens + output_tokens

                # Track by operation - improved naming
                operation_type = "chat_completion" if "llm_call" in span_name else "llm_operation"
                operation = (
                    f"{provider}_{operation_type}_{model}"
                    if provider != "unknown"
                    else f"{operation_type}_{model}"
                )
                if operation not in breakdown["by_operation"]:
                    breakdown["by_operation"][operation] = {"calls": 0, "cost": 0.0}
                breakdown["by_operation"][operation]["calls"] += 1
                breakdown["by_operation"][operation]["cost"] += total_cost

        # Round all costs to avoid floating point precision issues
        for key in ["prompt_cost", "completion_cost", "total_cost"]:
            breakdown[key] = round(breakdown[key], 6)

        for model_data in breakdown["by_model"].values():
            model_data["cost"] = round(model_data["cost"], 6)

        for op_data in breakdown["by_operation"].values():
            op_data["cost"] = round(op_data["cost"], 6)

        return breakdown

    def _calculate_key_metrics(self, trace: Dict) -> Dict:
        """Calculate key metrics from span attributes and messages"""
        llm_calls = 0
        tool_calls = 0
        total_tokens = 0
        input_tokens = 0
        output_tokens = 0
        retrieval_calls = 0

        # Extract from spans (these are Span objects, not dicts)
        spans = trace.get("spans", {})

        # Helper function to check if a span is an LLM span
        def is_llm_span(span) -> bool:
            span_name = span.name
            attributes = span.attributes
            return (
                span_name.startswith("llm_call")
                or "llm" in span_name.lower()
                or attributes.get("llm.provider") is not None
                or attributes.get("llm.model") is not None
                or span_name.startswith("openai_")
                or span_name.startswith("anthropic_")
                or span_name.startswith("ollama_")
                or span_name.startswith("gemini_")
                or span_name in ["ChatOpenAI", "ChatAnthropic", "ChatOllama"]
            )

        # Helper function to check if a span has any LLM children
        def has_llm_children(span) -> bool:
            """Check if this span has any LLM spans as children (direct or nested)"""
            for child_id in span.children:
                child_span = spans.get(child_id)
                if child_span and is_llm_span(child_span):
                    return True
            return False

        for span_id, span in spans.items():
            span_name = span.name
            attributes = span.attributes

            # Enhanced LLM span detection - only count LEAF LLM spans
            # (spans that are LLM calls but don't have LLM children)
            # This prevents double-counting when LangChain wraps OpenAI
            if is_llm_span(span):
                # Only count if this span doesn't have LLM children
                if not has_llm_children(span):
                    llm_calls += 1
                    # Extract tokens from span attributes - check both locations
                    span_tokens = attributes.get("llm.usage.total_tokens", 0) or attributes.get(
                        "llm.total_tokens", 0
                    )
                    span_input = attributes.get("llm.usage.input_tokens", 0) or attributes.get(
                        "llm.input_tokens", 0
                    )
                    span_output = attributes.get("llm.usage.output_tokens", 0) or attributes.get(
                        "llm.output_tokens", 0
                    )
                    total_tokens += span_tokens
                    input_tokens += span_input
                    output_tokens += span_output

            elif span_name.startswith("tool_call") or "tool" in span_name.lower():
                tool_calls += 1

            # Count retrieval calls
            if attributes.get("rag.operation") == "retrieval" or "retriev" in span_name.lower():
                retrieval_calls += 1

        # Also extract tokens from messages (in case span data is incomplete)
        messages = trace.get("messages", [])
        message_tokens = 0
        message_input_tokens = 0
        message_output_tokens = 0
        for msg in messages:
            if msg.get("type") == "ai":
                # Get token usage from response_metadata or usage_metadata
                token_usage = msg.get("response_metadata", {}).get("token_usage", {})
                if not token_usage:
                    token_usage = msg.get("usage_metadata", {})

                msg_tokens = token_usage.get("total_tokens", 0)
                msg_input = token_usage.get("prompt_tokens", 0) or token_usage.get(
                    "input_tokens", 0
                )
                msg_output = token_usage.get("completion_tokens", 0) or token_usage.get(
                    "output_tokens", 0
                )

                if msg_tokens > 0:
                    message_tokens += msg_tokens
                if msg_input > 0:
                    message_input_tokens += msg_input
                if msg_output > 0:
                    message_output_tokens += msg_output

        # Use message tokens if higher (more comprehensive)
        if message_tokens > total_tokens:
            total_tokens = message_tokens
        if message_input_tokens > input_tokens:
            input_tokens = message_input_tokens
        if message_output_tokens > output_tokens:
            output_tokens = message_output_tokens

        # Also count tool calls from messages (more reliable than spans)
        messages = trace.get("messages", [])
        for msg in messages:
            if msg.get("type") == "ai":
                # Count tool calls in message
                msg_tool_calls = msg.get("tool_calls", [])
                # Also check additional_kwargs for tool_calls (LangChain format)
                additional_tool_calls = msg.get("additional_kwargs", {}).get("tool_calls", [])

                tool_call_count = len(msg_tool_calls) + len(additional_tool_calls)
                tool_calls += tool_call_count

                if tool_call_count > 0:
                    print(
                        f"DEBUG: Message {msg.get('id', 'unknown')} has {tool_call_count} tool calls"
                    )

            elif msg.get("type") == "tool":
                # Tool result messages indicate tool executions but shouldn't double-count
                print(f"DEBUG: Found tool result message: {msg.get('tool_name', 'unknown')}")

        print(
            f"DEBUG: Final metrics - LLM calls: {llm_calls}, Tool calls: {tool_calls}, Total tokens: {total_tokens}"
        )

        return {
            "llm_calls": llm_calls,
            "tool_calls": tool_calls,
            "retrieval_calls": retrieval_calls,
            "total_tokens": total_tokens,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "tokens_used": total_tokens,  # Backward compatibility
            "cache_efficiency": (
                trace.get("cache_hits", 0) / max(1, llm_calls) if llm_calls > 0 else 0.0
            ),
        }

    def _calculate_node_metrics(self, trace: Dict) -> Dict:
        """ENHANCEMENT: Per-node metrics aggregation like competitors"""
        node_metrics = {}
        spans = trace["spans"]

        for span_id, span in spans.items():
            span_name = span.name

            if span_name == "agentic_workflow":  # Skip root span
                continue

            node_name = span_name
            if node_name not in node_metrics:
                node_metrics[node_name] = {
                    "calls": 0,
                    "total_duration_ms": 0,
                    "avg_latency_ms": 0,
                    "errors": 0,
                    "success_rate": 0.0,
                }

            metrics = node_metrics[node_name]
            metrics["calls"] += 1

            if span.duration_ms:
                metrics["total_duration_ms"] += span.duration_ms
                metrics["avg_latency_ms"] = round(
                    metrics["total_duration_ms"] / metrics["calls"], 2
                )

            if span.status == "error":
                metrics["errors"] += 1

            metrics["success_rate"] = round(
                (metrics["calls"] - metrics["errors"]) / metrics["calls"], 3
            )

        return node_metrics

    def _finish_all_remaining_spans(self, trace: Dict):
        """ENHANCEMENT 1: Ensure all spans have proper end_time, duration_ms, and status"""
        current_time = time.time()

        for span_id, span in trace["spans"].items():
            # Skip already finished spans
            if (
                span.end_time is not None
                and span.duration_ms is not None
                and span.status is not None
            ):
                continue

            # Determine span status based on events and errors
            new_span_status = "success"

            # Check for errors in span events
            for event in span.events:
                if "error" in event.get("event", "").lower():
                    new_span_status = "error"
                    break

            # Check for timeout or hanging operations
            if span._start_timestamp and (current_time - span._start_timestamp) > 300:  # 5 minutes
                new_span_status = "timeout"

            # Force finish the span
            if span.end_time is None:
                span.end_time = datetime.utcnow().isoformat() + "Z"

            if span.duration_ms is None and span._start_timestamp:
                span.duration_ms = round((current_time - span._start_timestamp) * 1000, 2)
            elif span.duration_ms is None:
                span.duration_ms = 0.0

            if span.status is None or span.status == "in_progress":
                span.status = new_span_status

    def _tie_spans_to_messages(self, trace: Dict):
        """ENHANCEMENT 2: Link spans to message IDs for cross-navigation

        This method now handles parallel execution by:
        1. Using content matching for better span-message correlation
        2. Tracking used spans to avoid duplicate assignments
        3. Falling back to temporal proximity for unmatched items
        """

        # Parse span timestamps and convert to float for comparison
        def parse_timestamp(ts_str):
            if isinstance(ts_str, (int, float)):
                return float(ts_str)
            try:
                from dateutil import parser

                dt = parser.isoparse(ts_str.replace("Z", "+00:00"))
                return dt.timestamp()
            except Exception:
                return 0.0

        # Build span timing info with parsed timestamps
        span_info = []
        for span_id, span in trace["spans"].items():
            if span.name.startswith("llm_call_") or "llm" in span.name.lower():
                start_ts = parse_timestamp(span.start_time)
                end_ts = parse_timestamp(span.end_time) if span.end_time else start_ts + 1
                span_info.append(
                    {
                        "span_id": span_id,
                        "span": span,
                        "start_ts": start_ts,
                        "end_ts": end_ts,
                        "used": False,  # Track if span has been assigned
                    }
                )

        # Sort spans by start time
        span_info.sort(key=lambda x: x["start_ts"])

        # First pass: Match by content similarity (for parallel tool calls)
        for msg in trace["messages"]:
            msg_id = msg.get("id")
            msg_type = msg.get("type")

            if msg_id and msg_type == "ai":
                msg_content = str(msg.get("content", "")).lower()
                msg_timestamp = msg.get("timestamp", 0)

                # Extract tool names from message if present
                msg_tool_calls = msg.get("tool_calls", [])
                msg_tools = {
                    tc.get("name", tc.get("function", {}).get("name", "")) for tc in msg_tool_calls
                }

                best_span = None
                best_score = -1

                for info in span_info:
                    if info["used"]:
                        continue  # Skip already assigned spans

                    span = info["span"]
                    score = 0

                    # 1. Content matching: Check if span attributes match message content
                    span_attrs = span.attributes

                    # Match tool names
                    span_tool_name = span_attrs.get("tool_name", "")
                    if span_tool_name and span_tool_name in msg_tools:
                        score += 100  # Strong match

                    # Match query/prompt content
                    span_query = str(span_attrs.get("query", "")).lower()
                    span_prompt = str(span_attrs.get("prompt", "")).lower()
                    if span_query and span_query in msg_content:
                        score += 50
                    if span_prompt and len(span_prompt) > 10:
                        # Check for partial prompt match
                        prompt_words = set(span_prompt.split()[:10])  # First 10 words
                        content_words = set(msg_content.split())
                        overlap = len(prompt_words & content_words)
                        score += overlap * 5

                    # 2. Temporal matching: Prefer spans that overlap with message time
                    time_relation = 0
                    if info["start_ts"] <= msg_timestamp <= info["end_ts"]:
                        time_relation = 30  # Message within span window
                    elif msg_timestamp >= info["end_ts"]:
                        # Message after span (normal case)
                        time_diff = msg_timestamp - info["end_ts"]
                        if time_diff < 1.0:  # Within 1 second
                            time_relation = 20
                        elif time_diff < 5.0:  # Within 5 seconds
                            time_relation = 10

                    score += time_relation

                    # 3. Sequential order bonus: Prefer spans in sequence order
                    span_index = span_info.index(info)
                    msg_index = trace["messages"].index(msg)
                    if span_index == msg_index:
                        score += 5

                    # Track best match
                    if score > best_score:
                        best_score = score
                        best_span = info

                # Link the best matching span if we found a good match
                if best_span and best_score > 0:
                    span_id = best_span["span_id"]
                    span = best_span["span"]

                    # Mark as used and create bidirectional link
                    best_span["used"] = True
                    msg["span_id"] = span_id
                    span.set_attribute("message_id", msg_id)

        # Second pass: Link any remaining unmatched items by pure temporal proximity
        for msg in trace["messages"]:
            msg_id = msg.get("id")
            msg_type = msg.get("type")

            # Skip if already linked
            if msg.get("span_id"):
                continue

            if msg_id and msg_type == "ai":
                msg_timestamp = msg.get("timestamp", 0)

                # Find closest unused span
                best_span = None
                min_time_diff = float("inf")

                for info in span_info:
                    if info["used"]:
                        continue

                    # Calculate time distance
                    if msg_timestamp < info["start_ts"]:
                        time_diff = info["start_ts"] - msg_timestamp
                    elif msg_timestamp > info["end_ts"]:
                        time_diff = msg_timestamp - info["end_ts"]
                    else:
                        time_diff = 0  # Within span

                    if time_diff < min_time_diff:
                        min_time_diff = time_diff
                        best_span = info

                # Link if found
                if best_span:
                    span_id = best_span["span_id"]
                    span = best_span["span"]
                    best_span["used"] = True
                    msg["span_id"] = span_id
                    span.set_attribute("message_id", msg_id)

    def _add_inline_tool_results(self, trace: Dict):
        """ENHANCEMENT 3: Add explicit tool result messages with full document data.
        
        NOTE: This method only adds tool result messages for tool_calls that don't already
        have a corresponding tool message. Tool messages created by autolog instrumentation
        (via _trace_tool_call or _trace_retriever_tool_run) will NOT be duplicated.
        """
        enhanced_messages = []
        
        # Build a set of existing tool names to avoid duplicates
        # Tool messages already in the trace have a span_id (from autolog instrumentation)
        existing_tool_messages = set()
        for msg in trace["messages"]:
            if msg.get("type") == "tool":
                tool_name = msg.get("name") or msg.get("tool_name", "")
                # If it has a span_id, it was created by autolog instrumentation
                if msg.get("span_id"):
                    existing_tool_messages.add(tool_name)

        for msg in trace["messages"]:
            enhanced_messages.append(msg)

            # If this is an AI message with tool calls, add tool result messages
            if msg.get("type") == "ai" and msg.get("tool_calls"):
                for tool_call in msg.get("tool_calls", []):
                    tool_call_id = tool_call.get("id") or f"call_{str(uuid.uuid4())[:8]}"
                    tool_name = tool_call.get("name") or tool_call.get("function", {}).get(
                        "name", "unknown_tool"
                    )

                    # Skip if this tool already has a message (created by autolog instrumentation)
                    if tool_name in existing_tool_messages:
                        continue

                    # ✅ ROOT CAUSE FIX: Extract tool result AND get the source span_id for linking
                    # This will find the RAG span created by _pickup_cached_tool_retrievals()
                    tool_result_content, source_span_id = self._extract_tool_result_with_span(
                        tool_call, trace
                    )

                    # Create tool result message with rich data
                    tool_result_msg = {
                        "type": "tool",
                        "id": f"tool-msg-{str(uuid.uuid4())[:8]}",
                        "name": tool_name,  # Add tool name for easier filtering (LangChain format)
                        "tool_call_id": tool_call_id,
                        "tool_name": tool_name,  # Keep for backward compatibility
                        "arguments": tool_call.get("args")
                        or tool_call.get("function", {}).get("arguments", {}),
                        "content": tool_result_content,  # LangChain uses "content" for tool messages
                        "status": "success",
                        "latency_ms": self._calculate_tool_latency(tool_call, trace),
                        "timestamp": msg.get("timestamp", 0) + 0.001,  # Slightly after AI message
                        "response_metadata": {
                            "tool_execution": True,
                            "related_message_id": msg.get("id"),
                            "timestamp": msg.get("timestamp", 0) + 0.001,
                            "source": "tool_result",
                        },
                    }

                    # ✅ FIX #2: Add bidirectional linking if we found a source span
                    if source_span_id and source_span_id in trace["spans"]:
                        tool_result_msg["span_id"] = source_span_id  # Forward link: message → span
                        span = trace["spans"][source_span_id]
                        # Handle both Span objects and dicts
                        if hasattr(span, "set_attribute"):
                            span.set_attribute(
                                "message_id", tool_result_msg["id"]
                            )  # Backward link: span → message
                        elif isinstance(span, dict):
                            if "attributes" not in span:
                                span["attributes"] = {}
                            span["attributes"]["message_id"] = tool_result_msg["id"]

                        # ✅ NEW FIX: Add parent span info to tool messages (same logic as AI messages)
                        # Find the topmost parent (workflow node) by traversing up the hierarchy
                        current_span_obj = span
                        parent_span_id = None
                        parent_span_name = None

                        # Traverse up to find the topmost parent (depth 1 - direct child of root)
                        while current_span_obj:
                            # Get parent_span_id from span
                            if hasattr(current_span_obj, "parent_span_id"):
                                current_parent_id = current_span_obj.parent_span_id
                            elif isinstance(current_span_obj, dict):
                                current_parent_id = current_span_obj.get("parent_span_id")
                            else:
                                break

                            # If parent is root span, current span is the workflow node we want
                            if current_parent_id == trace.get("root_span_id"):
                                if hasattr(current_span_obj, "span_id"):
                                    parent_span_id = current_span_obj.span_id
                                elif isinstance(current_span_obj, dict):
                                    parent_span_id = current_span_obj.get("span_id")

                                if hasattr(current_span_obj, "name"):
                                    parent_span_name = current_span_obj.name
                                elif isinstance(current_span_obj, dict):
                                    parent_span_name = current_span_obj.get("name")
                                break

                            # Move up to parent
                            if current_parent_id and current_parent_id in trace["spans"]:
                                current_span_obj = trace["spans"][current_parent_id]
                            else:
                                break

                        # Add parent span info to tool message if found
                        if parent_span_id and parent_span_name:
                            tool_result_msg["parent_span_id"] = parent_span_id
                            tool_result_msg["parent_span_name"] = parent_span_name

                    enhanced_messages.append(tool_result_msg)

        trace["messages"] = enhanced_messages

    def _extract_tool_result(self, tool_call, trace):
        """Extract tool result from RAG spans with actual document data"""
        tool_call_id = tool_call.get("id")
        tool_name = tool_call.get("name", "")

        # Look for tool results in existing messages first
        for msg in trace["messages"]:
            if msg.get("type") == "tool" and msg.get("tool_call_id") == tool_call_id:
                return msg.get("content", "No result available")

        # Look in trace events
        for event in trace.get("legacy_events", []):
            if event.get("type") == "tool.result" and event.get("tool_call_id") == tool_call_id:
                return event.get("payload", {}).get("result", "No result available")

        # 🔥 NEW: Look in RAG spans for retrieval data with actual document content
        spans = trace.get("spans", {})

        for span_id, span in spans.items():
            # Get attributes safely from both Span objects and dicts
            if hasattr(span, "attributes"):
                attributes = span.attributes
            elif isinstance(span, dict):
                attributes = span.get("attributes", {})
            else:
                continue

            # Check if this span relates to our tool call
            retriever_type = attributes.get("rag.retriever_type", "")
            span_query = str(attributes.get("rag.query", ""))

            # Match by tool name in retriever type, or by matching tool_call_id in query
            is_match = (tool_name and tool_name in retriever_type) or (
                tool_call_id and tool_call_id in span_query
            )

            if is_match:
                # 🔥 FIX: RAGSpan uses retrieval_info attribute, not retrieval
                retrieval = None
                if hasattr(span, "retrieval_info") and span.retrieval_info:
                    # RAGSpan object with RetrievalInfo
                    retrieval = (
                        span.retrieval_info.to_dict()
                        if hasattr(span.retrieval_info, "to_dict")
                        else span.retrieval_info
                    )
                elif hasattr(span, "retrieval"):
                    # Regular span with retrieval dict
                    retrieval = span.retrieval
                elif isinstance(span, dict):
                    # Dictionary span
                    retrieval = span.get("retrieval", {})
                else:
                    continue

                if retrieval:
                    hits = retrieval.get("hits", [])

                    if hits:
                        # Format the actual retrieval results with full document content
                        result_text = f"Retrieved {len(hits)} documents:\n\n"
                        for i, hit in enumerate(hits, 1):
                            snippet = hit.get("snippet_preview", "")
                            score = hit.get("score", 0.0)
                            doc_id = hit.get("doc_id", f"doc_{i}")
                            metadata = hit.get("metadata", {})
                            source = metadata.get("source", "unknown")

                            # Include full snippet (not truncated)
                            result_text += f"📄 Document {i} (ID: {doc_id}, Score: {score:.2f}, Source: {source}):\n"
                            result_text += f"{snippet}\n\n"
                            result_text += "---\n\n"

                        return result_text.strip()

        # Fallback to generic message only if no RAG data found
        return f"Tool {tool_name} executed successfully"

    def _extract_tool_result_with_span(self, tool_call, trace):
        """Extract tool result AND return the source span_id for linking"""
        from typing import Optional, Tuple

        tool_call_id = tool_call.get("id")
        tool_name = tool_call.get("name", "")

        # Look for tool results in existing messages first
        for msg in trace["messages"]:
            if msg.get("type") == "tool" and msg.get("tool_call_id") == tool_call_id:
                # Try to find span for this message
                msg_span_id = msg.get("span_id")
                return msg.get("content", "No result available"), msg_span_id

        # Look in RAG spans for retrieval data
        spans = trace.get("spans", {})

        for span_id, span in spans.items():
            # Get attributes safely
            if hasattr(span, "attributes"):
                attributes = span.attributes
            elif isinstance(span, dict):
                attributes = span.get("attributes", {})
            else:
                continue

            retriever_type = attributes.get("rag.retriever_type", "")
            span_query = str(attributes.get("rag.query", ""))

            # ✅ ROOT CAUSE FIX: Prioritize exact tool_call_id match to avoid false positives
            # Only fall back to tool_name matching if tool_call_id is not available
            is_match = False
            if tool_call_id and tool_call_id in span_query:
                # EXACT match by tool_call_id (highest priority)
                is_match = True
            elif not tool_call_id and tool_name and tool_name in retriever_type:
                # Fallback to tool_name match only if no tool_call_id available
                is_match = True

            if is_match:
                # Extract retrieval data
                retrieval = None
                if hasattr(span, "retrieval_info") and span.retrieval_info:
                    retrieval = (
                        span.retrieval_info.to_dict()
                        if hasattr(span.retrieval_info, "to_dict")
                        else span.retrieval_info
                    )
                elif hasattr(span, "retrieval"):
                    retrieval = span.retrieval
                elif isinstance(span, dict) and "retrieval" in span:
                    retrieval = span["retrieval"]

                if retrieval and retrieval.get("hits"):
                    # Format documents
                    hits = retrieval.get("hits", [])
                    result_text = f"Retrieved {len(hits)} documents:\n\n"
                    for i, hit in enumerate(hits, 1):
                        snippet = hit.get("snippet_preview", "")
                        score = hit.get("score", 0.0)
                        doc_id = hit.get("doc_id", f"doc_{i}")
                        metadata = hit.get("metadata", {})
                        source = metadata.get("source", "unknown")

                        result_text += f"📄 Document {i} (ID: {doc_id}, Score: {score:.2f}, Source: {source}):\n"
                        result_text += f"{snippet}\n\n"
                        result_text += "---\n\n"

                    return result_text.strip(), span_id  # ← Return span_id!

        # Fallback - no span found
        return f"Tool {tool_name} executed successfully", None

    def _calculate_tool_latency(self, tool_call, trace):
        """Calculate tool execution latency from spans"""
        tool_name = tool_call.get("name") or tool_call.get("function", {}).get("name", "")

        # Look for related spans
        for span in trace["spans"].values():
            if tool_name in span.name or "tool" in span.name.lower():
                return span.duration_ms or 0

        return 0  # Default if no span found

    def _enrich_response_metadata(self, trace: Dict):
        """ENHANCEMENT 4: Enrich response metadata with vendor, request_id, cost_usd"""
        for msg in trace["messages"]:
            response_metadata = msg.get("response_metadata", {})

            if response_metadata:
                # Extract LLM vendor from model name (but preserve if already set by instrumentor)
                existing_vendor = response_metadata.get("llm.vendor")
                if not existing_vendor or existing_vendor == "unknown":
                    model = response_metadata.get("model") or response_metadata.get(
                        "model_name", ""
                    )
                    vendor = self._extract_llm_vendor(model)
                    response_metadata["llm.vendor"] = vendor
                else:
                    vendor = existing_vendor

                # Add request ID if available
                if not response_metadata.get("request_id"):
                    response_metadata["request_id"] = response_metadata.get(
                        "id", f"req_{str(uuid.uuid4())[:12]}"
                    )

                # Add endpoint URL based on vendor
                if not response_metadata.get("endpoint_url"):
                    response_metadata["endpoint_url"] = self._get_endpoint_url(vendor)

                # Add explicit cost_usd from cost_breakdown
                cost_breakdown = msg.get("cost_breakdown", {})
                if cost_breakdown:
                    response_metadata["cost_usd"] = cost_breakdown.get("total_cost", 0.0)
                elif response_metadata.get("token_usage"):
                    # Calculate cost if not available
                    token_usage = response_metadata["token_usage"]
                    estimated_cost = self._calculate_message_cost(model, token_usage)
                    response_metadata["cost_usd"] = estimated_cost

                msg["response_metadata"] = response_metadata

    def _enhance_feedback_with_context(self, trace: Dict):
        """🔥 NEW: Link feedback messages to the documents that were evaluated"""
        messages = trace.get("messages", [])

        for i, msg in enumerate(messages):
            # Check if this is a feedback/evaluation AI message
            if msg.get("type") == "ai":
                content = str(msg.get("content", ""))

                # Detect feedback patterns (is_sufficient, feedback field, evaluation)
                is_feedback_msg = any(
                    keyword in content.lower()
                    for keyword in [
                        "is_sufficient",
                        '"feedback":',
                        "evaluation",
                        "documents do not contain",
                        "provided documents",
                        "documents provided",
                    ]
                )

                if is_feedback_msg:
                    # Find the most recent tool result before this message
                    recent_tool_result = None
                    recent_tool_idx = -1

                    for j in range(i - 1, -1, -1):
                        if messages[j].get("type") == "tool":
                            recent_tool_result = messages[j]
                            recent_tool_idx = j
                            break

                    # Add reference to evaluated documents in additional_kwargs
                    if recent_tool_result:
                        if "additional_kwargs" not in msg:
                            msg["additional_kwargs"] = {}

                        tool_content = recent_tool_result.get(
                            "content", recent_tool_result.get("result", "")
                        )

                        # Add full context about what was evaluated
                        msg["additional_kwargs"]["evaluated_documents_from_tool"] = (
                            recent_tool_result.get("tool_name", "unknown")
                        )
                        msg["additional_kwargs"]["evaluated_documents_call_id"] = (
                            recent_tool_result.get("tool_call_id", "")
                        )
                        msg["additional_kwargs"]["evaluated_documents_snippet"] = (
                            tool_content[:800] + "..." if len(tool_content) > 800 else tool_content
                        )
                        msg["additional_kwargs"][
                            "evaluated_documents_message_idx"
                        ] = recent_tool_idx
                        msg["additional_kwargs"]["feedback_type"] = "document_sufficiency_check"

                        # Also add a note in response_metadata
                        if "response_metadata" not in msg:
                            msg["response_metadata"] = {}
                        msg["response_metadata"]["evaluating_tool_result"] = recent_tool_result.get(
                            "id", ""
                        )
                        msg["response_metadata"][
                            "evaluation_context"
                        ] = f"Evaluating {recent_tool_result.get('tool_name', 'unknown')} results"

    def _extract_llm_vendor(self, model_name: str) -> str:
        """Enhanced LLM vendor detection for top 20 providers"""
        model_lower = str(model_name).lower()

        # OpenAI & Azure OpenAI
        if any(
            keyword in model_lower
            for keyword in ["gpt", "openai", "davinci", "curie", "babbage", "ada"]
        ):
            if any(keyword in model_lower for keyword in ["azure", "azureopenai"]):
                return "azure_openai"
            return "openai"

        # Anthropic
        elif any(keyword in model_lower for keyword in ["claude", "anthropic"]):
            return "anthropic"

        # Google & Vertex AI
        elif any(
            keyword in model_lower for keyword in ["gemini", "google", "bard", "palm", "vertex"]
        ):
            return "google"

        # Meta / Llama
        elif any(
            keyword in model_lower
            for keyword in ["llama", "meta", "code-llama", "alpaca", "vicuna"]
        ):
            return "meta"

        # Cohere
        elif any(keyword in model_lower for keyword in ["cohere", "command"]):
            return "cohere"

        # Mistral AI
        elif any(keyword in model_lower for keyword in ["mistral", "mixtral"]):
            return "mistral"

        # Together AI
        elif any(keyword in model_lower for keyword in ["together", "togethercomputer"]):
            return "together"

        # Hugging Face
        elif any(keyword in model_lower for keyword in ["huggingface", "transformers", "hf"]):
            return "huggingface"

        # Replicate
        elif "replicate" in model_lower:
            return "replicate"

        # AWS Bedrock
        elif any(keyword in model_lower for keyword in ["bedrock", "aws", "amazon", "titan"]):
            return "aws_bedrock"

        # Local model providers
        elif any(keyword in model_lower for keyword in ["ollama", "localhost:11434"]):
            return "ollama"

        # LocalAI
        elif any(keyword in model_lower for keyword in ["localai", "localhost:8080"]):
            return "localai"

        # vLLM
        elif any(keyword in model_lower for keyword in ["vllm", "localhost:8000"]):
            return "vllm"

        # Custom local models
        elif any(keyword in model_lower for keyword in ["custom_local", "local", "self_hosted"]):
            return "custom_local"

        # Perplexity AI
        elif any(keyword in model_lower for keyword in ["perplexity", "pplx"]):
            return "perplexity"

        # Groq
        elif "groq" in model_lower:
            return "groq"

        # Fireworks AI
        elif any(keyword in model_lower for keyword in ["fireworks", "fireworksai"]):
            return "fireworks"

        # Anyscale
        elif "anyscale" in model_lower:
            return "anyscale"

        # DeepSeek
        elif "deepseek" in model_lower:
            return "deepseek"

        # OpenRouter
        elif "openrouter" in model_lower:
            return "openrouter"

        # AI21 Labs
        elif any(keyword in model_lower for keyword in ["ai21", "jurassic"]):
            return "ai21"

        # Voyage AI
        elif "voyage" in model_lower:
            return "voyage"

        # Writer
        elif "writer" in model_lower:
            return "writer"

        # Stability AI
        elif any(keyword in model_lower for keyword in ["stability", "stable"]):
            return "stability"

        else:
            return "unknown"

    def _get_endpoint_url(self, vendor: str) -> str:
        """Enhanced endpoint URLs for top 20 LLM providers"""
        endpoints = {
            "openai": "https://api.openai.com/v1/chat/completions",
            "azure_openai": "https://{resource}.openai.azure.com/openai/deployments/{deployment}/chat/completions",
            "anthropic": "https://api.anthropic.com/v1/messages",
            "google": "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
            "meta": "https://api.llama-api.com/chat/completions",
            "cohere": "https://api.cohere.ai/v1/chat",
            "mistral": "https://api.mistral.ai/v1/chat/completions",
            "together": "https://api.together.xyz/v1/chat/completions",
            "huggingface": "https://api-inference.huggingface.co/models/{model}",
            "replicate": "https://api.replicate.com/v1/predictions",
            "aws_bedrock": "https://bedrock-runtime.{region}.amazonaws.com/model/{model}/invoke",
            "perplexity": "https://api.perplexity.ai/chat/completions",
            "groq": "https://api.groq.com/openai/v1/chat/completions",
            "fireworks": "https://api.fireworks.ai/inference/v1/chat/completions",
            "anyscale": "https://api.endpoints.anyscale.com/v1/chat/completions",
            "deepseek": "https://api.deepseek.com/v1/chat/completions",
            "openrouter": "https://openrouter.ai/api/v1/chat/completions",
            "ai21": "https://api.ai21.com/studio/v1/chat/completions",
            "voyage": "https://api.voyageai.com/v1/embeddings",
            "writer": "https://api.writer.com/v1/completions",
            "stability": "https://api.stability.ai/v1/generation/{engine}/text-to-image",
        }
        return endpoints.get(vendor, "https://api.unknown.com/v1/completions")

    def _fix_chronological_ordering(self, trace: Dict):
        """ENHANCEMENT 5: Ensure proper turn order - human input → tool calls → AI responses"""
        messages = trace["messages"]

        # Sort by timestamp first to get basic chronological order
        messages_with_ts = []
        for msg in messages:
            timestamp = msg.get("timestamp", 0)
            # If no timestamp, estimate based on message type order
            if timestamp == 0:
                if msg.get("type") == "human":
                    timestamp = 0.1  # Human messages first
                elif msg.get("type") == "ai" and msg.get("tool_calls"):
                    timestamp = 0.2  # AI with tool calls second
                elif msg.get("type") == "tool":
                    timestamp = 0.3  # Tool results third
                elif msg.get("type") == "ai":
                    timestamp = 0.4  # AI responses last

            messages_with_ts.append((timestamp, msg))

        # Sort by timestamp
        messages_with_ts.sort(key=lambda x: x[0])

        # Reorder to ensure conversational flow: human → AI+tools → tool results → AI response
        reordered_messages = []
        pending_tools = []

        for _, msg in messages_with_ts:
            msg_type = msg.get("type")

            if msg_type == "human":
                # Add any pending tools first, then human message
                reordered_messages.extend(pending_tools)
                pending_tools = []
                reordered_messages.append(msg)

            elif msg_type == "ai" and msg.get("tool_calls"):
                # AI message with tool calls - add immediately after human
                reordered_messages.append(msg)

            elif msg_type == "tool":
                # Collect tool messages to add together
                pending_tools.append(msg)

            elif msg_type == "ai":
                # Final AI response - add after any pending tools
                reordered_messages.extend(pending_tools)
                pending_tools = []
                reordered_messages.append(msg)

        # Add any remaining tool messages
        reordered_messages.extend(pending_tools)

        trace["messages"] = reordered_messages

    def _sort_turn_messages(self, turn_messages: List[Dict]) -> List[Dict]:
        """Sort messages within a turn: human → AI with tools → tool results → AI response"""
        human_msgs = [msg for msg in turn_messages if msg.get("type") == "human"]
        ai_msgs = [msg for msg in turn_messages if msg.get("type") == "ai"]
        tool_msgs = [msg for msg in turn_messages if msg.get("type") == "tool"]

        # Sort AI messages by tool calls vs final response
        ai_with_tools = [msg for msg in ai_msgs if msg.get("tool_calls")]
        ai_responses = [msg for msg in ai_msgs if not msg.get("tool_calls")]

        # Order: human → AI with tools → tool results → AI responses
        ordered = human_msgs + ai_with_tools + tool_msgs + ai_responses
        return ordered

    def _connect_execution_tree(self, trace: Dict):
        """ENHANCEMENT 6: Properly connect agentic_workflow → conversation → llm/tool spans"""
        spans = trace["spans"]
        root_span_id = trace["root_span_id"]

        # Find conversation span
        conversation_span_id = None
        for span_id, span in spans.items():
            if span.name == "conversation":
                conversation_span_id = span_id
                break

        # Connect conversation to root if not already connected
        if conversation_span_id and conversation_span_id != root_span_id:
            root_span = spans[root_span_id]
            conversation_span = spans[conversation_span_id]

            # Set parent relationship
            conversation_span.parent_span_id = root_span_id

            # Add to root's children if not already there
            if conversation_span_id not in root_span.children:
                root_span.add_child(conversation_span_id)

        # Connect LLM and tool spans to conversation
        if conversation_span_id:
            conversation_span = spans[conversation_span_id]

            for span_id, span in spans.items():
                # Skip root and conversation spans
                if span_id in [root_span_id, conversation_span_id]:
                    continue

                # Connect LLM and tool spans
                if (
                    "llm" in span.name.lower()
                    or "tool" in span.name.lower()
                    or span.name.startswith("llm_call_")
                ):

                    # Set conversation as parent
                    span.parent_span_id = conversation_span_id

                    # Add to conversation's children
                    if span_id not in conversation_span.children:
                        conversation_span.add_child(span_id)

    def _generate_enhanced_diagnostics(self, trace: Dict, duration_ms: float) -> Dict:
        """ENHANCEMENT: Advanced diagnostics with anomaly detection and optimization hints"""
        spans = trace["spans"]
        diagnostics = {
            "performance_insights": [],
            "warnings": [],
            "optimization_suggestions": [],
            "anomalies": [],  # NEW: Anomaly detection
            "privacy_flags": [],  # NEW: Privacy concerns
            "cache_opportunities": [],  # NEW: Caching hints
        }

        # Enhanced performance analysis - focus on actionable insights
        child_spans = []
        for span in spans.values():
            span_parent_id = (
                span.parent_span_id
                if hasattr(span, "parent_span_id")
                else span.get("parent_span_id")
            )
            span_duration = (
                span.duration_ms if hasattr(span, "duration_ms") else span.get("duration_ms", 0)
            )
            if span_parent_id is not None and span_duration and span_duration > 0:
                child_spans.append(span)

        if child_spans:
            # Find spans that take significant portion of total time
            for span in child_spans:
                span_name = span.name if hasattr(span, "name") else span.get("name", "unknown")
                span_duration = (
                    span.duration_ms if hasattr(span, "duration_ms") else span.get("duration_ms", 0)
                )
                span_id_val = (
                    span.span_id if hasattr(span, "span_id") else span.get("span_id", "unknown")
                )

                percentage = round((span_duration / duration_ms) * 100, 1)
                # Only flag child operations that take >30% of total time
                if percentage > 30:
                    diagnostics["performance_insights"].append(
                        {
                            "type": "latency_alert",
                            "message": f"Operation '{span_name}' took {percentage}% of total execution time ({span_duration:.0f}ms)",
                            "recommendation": "Consider optimization - this operation is a bottleneck",
                            "span_id": span_id_val,
                            "duration_ms": span_duration,
                        }
                    )

            # Find slow LLM calls specifically
            llm_spans = []
            for span in child_spans:
                span_name = span.name if hasattr(span, "name") else span.get("name", "")
                if "llm_call" in span_name.lower():
                    llm_spans.append(span)
            if llm_spans:
                # Calculate average LLM time
                llm_durations = []
                for s in llm_spans:
                    s_duration = (
                        s.duration_ms if hasattr(s, "duration_ms") else s.get("duration_ms", 0)
                    )
                    llm_durations.append(s_duration)
                avg_llm_time = sum(llm_durations) / len(llm_durations) if llm_durations else 0

                # Find slow LLM calls
                slow_llm_calls = []
                for s in llm_spans:
                    s_duration = (
                        s.duration_ms if hasattr(s, "duration_ms") else s.get("duration_ms", 0)
                    )
                    if s_duration > avg_llm_time * 2:
                        slow_llm_calls.append(s)

                for slow_span in slow_llm_calls:
                    slow_duration = (
                        slow_span.duration_ms
                        if hasattr(slow_span, "duration_ms")
                        else slow_span.get("duration_ms", 0)
                    )
                    slow_span_id = (
                        slow_span.span_id
                        if hasattr(slow_span, "span_id")
                        else slow_span.get("span_id", "unknown")
                    )
                    diagnostics["performance_insights"].append(
                        {
                            "type": "slow_llm_call",
                            "message": f"LLM call took {slow_duration:.0f}ms (2x slower than average {avg_llm_time:.0f}ms)",
                            "recommendation": "Check prompt length, model parameters, or network conditions",
                            "span_id": slow_span_id,
                            "duration_ms": slow_duration,
                        }
                    )

        # Cost analysis
        total_cost = trace["total_cost"]
        if total_cost > 0.01:  # More than 1 cent
            diagnostics["warnings"].append(
                {
                    "type": "cost_alert",
                    "message": f"High LLM costs detected: ${total_cost:.4f}",
                    "recommendation": "Consider prompt optimization or caching",
                }
            )

        # ENHANCEMENT: Token spike anomaly detection
        token_usage = trace["token_usage"]
        if token_usage["total"] > 10000:
            diagnostics["anomalies"].append(
                {
                    "type": "token_spike",
                    "message": f"Unusually high token usage: {token_usage['total']} tokens",
                    "severity": "medium",
                    "recommendation": "Review prompt efficiency and consider chunking",
                }
            )

        # ENHANCEMENT: Cache opportunity detection
        repeated_queries = {}
        for msg in trace["messages"]:
            if msg.get("type") == "ai" and msg.get("content"):
                content_hash = hash(str(msg["content"])[:100])
                repeated_queries[content_hash] = repeated_queries.get(content_hash, 0) + 1

        for hash_key, count in repeated_queries.items():
            if count > 1:
                diagnostics["cache_opportunities"].append(
                    {
                        "type": "repeated_query",
                        "message": f"Detected {count} similar queries - caching opportunity",
                        "potential_savings": f"Up to {count-1} LLM calls could be cached",
                    }
                )

        # ENHANCEMENT: Privacy flag detection (basic PII detection)
        pii_patterns = [
            (r"\b\d{3}-\d{2}-\d{4}\b", "SSN"),
            (r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b", "Email"),
            (r"\b\d{4}[- ]?\d{4}[- ]?\d{4}[- ]?\d{4}\b", "Credit Card"),
        ]

        for msg in trace["messages"]:
            content = str(msg.get("content", ""))
            for pattern, pii_type in pii_patterns:
                if re.search(pattern, content):
                    diagnostics["privacy_flags"].append(
                        {
                            "type": "pii_detected",
                            "pii_type": pii_type,
                            "message": f"Potential {pii_type} detected in message",
                            "recommendation": "Consider PII masking for production logs",
                        }
                    )
                    break  # Only flag once per message

        # LLM call frequency
        if trace["llm_calls"] > 5:
            diagnostics["optimization_suggestions"].append(
                {
                    "type": "llm_frequency",
                    "message": f"High number of LLM calls: {trace['llm_calls']}",
                    "recommendation": "Consider batching or using more capable models",
                }
            )

        return diagnostics

    def _enhance_response_metadata(self, messages: List[Dict]) -> List[Dict]:
        """Enhance response metadata with actual API values instead of placeholders"""
        enhanced_messages = []

        for msg in messages:
            enhanced_msg = dict(msg)
            response_metadata = enhanced_msg.get("response_metadata", {})

            # Extract actual values from LangChain response if available
            if response_metadata:
                # If we have actual API response data, use it
                if (
                    not response_metadata.get("system_fingerprint")
                    and "token_usage" in response_metadata
                ):
                    # This indicates we have real API data, populate missing fields with sensible defaults
                    response_metadata["system_fingerprint"] = response_metadata.get(
                        "system_fingerprint", f"fp-{str(uuid.uuid4())[:12]}"
                    )
                    response_metadata["id"] = response_metadata.get(
                        "id", f"chatcmpl-{str(uuid.uuid4()).replace('-', '')[:29]}"
                    )
                    response_metadata["service_tier"] = response_metadata.get(
                        "service_tier", "default"
                    )

                enhanced_msg["response_metadata"] = response_metadata

            enhanced_messages.append(enhanced_msg)

        return enhanced_messages

    def _pickup_cached_tool_retrievals(self, trace: Dict[str, Any]):
        """Pick up cached tool retrievals from global cache and incorporate into trace"""
        try:
            # Import here to avoid circular imports
            from .autolog import _tool_retrievals_cache

            if not _tool_retrievals_cache:
                return

            # Process all cached retrievals
            cached_count = 0
            for cache_key, retrieval_data in list(_tool_retrievals_cache.items()):
                try:
                    # Extract the retrieval data
                    if "retrieval" in retrieval_data:
                        retrieval = retrieval_data["retrieval"]

                        # Add to trace retrievals array
                        if "retrievals" not in trace:
                            trace["retrievals"] = []

                        trace["retrievals"].append(retrieval)
                        cached_count += 1

                        # CRITICAL: Also create a RAG span for this retrieval
                        try:
                            # Extract actual tool name from retrieval data (instead of hardcoded name)
                            retriever_type = retrieval.get("retriever_type", "unknown")
                            # Generate span name from actual tool name
                            # Format: "ToolWrapped_search_MSFT_docs" -> "search_MSFT_docs"
                            if retriever_type.startswith("ToolWrapped_"):
                                actual_tool_name = retriever_type.replace("ToolWrapped_", "")
                            else:
                                actual_tool_name = retriever_type

                            # Get parent span ID from cached data (workflow node that invoked this tool)
                            # Fall back to root span if no parent was captured
                            parent_span_id = retrieval_data.get(
                                "parent_span_id", trace.get("root_span_id")
                            )

                            # Create RAGSpan with retrieval info
                            rag_span_id = generate_span_id()
                            rag_span = RAGSpan(
                                span_id=rag_span_id,
                                name=actual_tool_name,  # Use actual tool name instead of hardcoded "cached_retrieval_operation"
                                parent_span_id=parent_span_id,  # Use captured parent workflow node instead of root
                                trace_id=trace.get("trace_id"),
                            )

                            # Override auto-generated timestamps with actual execution times from cache
                            start_ts = retrieval.get(
                                "start_timestamp", retrieval.get("timestamp", time.time())
                            )
                            end_ts = retrieval.get(
                                "end_timestamp", start_ts + (retrieval.get("latency_ms", 0) / 1000)
                            )

                            from datetime import datetime, timezone

                            rag_span.start_time = (
                                datetime.fromtimestamp(start_ts, tz=timezone.utc)
                                .isoformat()
                                .replace("+00:00", "Z")
                            )
                            rag_span.end_time = (
                                datetime.fromtimestamp(end_ts, tz=timezone.utc)
                                .isoformat()
                                .replace("+00:00", "Z")
                            )
                            rag_span.duration_ms = round((end_ts - start_ts) * 1000, 2)
                            rag_span.status = "success"
                            rag_span._start_timestamp = start_ts

                            # Set retrieval attributes
                            rag_span.set_attribute("rag.operation", "retrieval")
                            rag_span.set_attribute(
                                "rag.retriever_type", retrieval.get("retriever_type", "unknown")
                            )
                            rag_span.set_attribute("rag.query", retrieval.get("query", ""))
                            rag_span.set_attribute(
                                "rag.documents_retrieved",
                                retrieval.get("k", len(retrieval.get("hits", []))),
                            )
                            rag_span.set_attribute("rag.via_cache", True)

                            # Create RetrievalInfo from cached data
                            hits = retrieval.get("hits", [])
                            document_hits = []
                            for hit in hits:
                                doc_hit = DocumentHit(
                                    doc_id=hit.get("doc_id", "unknown"),
                                    rank=hit.get("rank", 0),
                                    score=hit.get("score", 0.0),
                                    snippet_preview=hit.get("snippet_preview", ""),
                                    metadata=hit.get("metadata", {}),
                                )
                                document_hits.append(doc_hit)

                            retrieval_info = RetrievalInfo(
                                retriever=retrieval.get("retriever_type", "unknown"),
                                embedding_model=retrieval.get("embedding_model", "unknown"),
                                top_k=retrieval.get("k", len(document_hits)),
                                query=retrieval.get("query", ""),
                                hits=document_hits,
                                latency_ms=retrieval.get("latency_ms", 0),
                                filters=retrieval.get("filters", {}),
                                total_documents=len(document_hits),
                            )

                            # Set retrieval info on span
                            rag_span.set_retrieval_info(retrieval_info)

                            # Add span to trace (spans is a dict, not a list!)
                            if "spans" not in trace:
                                trace["spans"] = {}
                            # Store as Span object for type consistency with live-created spans
                            trace["spans"][rag_span_id] = rag_span

                            # Add to parent span's children (which should be the workflow node like retrieve_documents)
                            if parent_span_id and parent_span_id in trace["spans"]:
                                parent_span = trace["spans"][parent_span_id]

                                # Handle both Span objects and dicts
                                if hasattr(parent_span, "children"):
                                    # It's a Span object
                                    if rag_span_id not in parent_span.children:
                                        parent_span.children.append(rag_span_id)
                                elif isinstance(parent_span, dict):
                                    # It's a dict
                                    if "children" not in parent_span:
                                        parent_span["children"] = []
                                    if rag_span_id not in parent_span["children"]:
                                        parent_span["children"].append(rag_span_id)

                            # ✅ ROOT CAUSE FIX: Only create RAG span here
                            # Tool messages will be created by _add_inline_tool_results() which runs later
                            # and will link to this RAG span via Fix #2's _extract_tool_result_with_span()

                        except Exception as span_error:
                            pass  # Failed to create RAG span

                        # Remove from cache after processing
                        del _tool_retrievals_cache[cache_key]

                except Exception as e:
                    continue

            if cached_count > 0:

                # Sort root span's children by their actual start_time to maintain chronological order
                try:
                    root_span_id = trace.get("root_span_id")
                    if root_span_id and root_span_id in trace.get("spans", {}):
                        root_span = trace["spans"][root_span_id]

                        # Get children list
                        children = None
                        if hasattr(root_span, "children"):
                            children = root_span.children
                        elif isinstance(root_span, dict):
                            children = root_span.get("children", [])

                        if children:
                            # Build list of (child_id, start_time) tuples
                            children_with_times = []
                            for child_id in children:
                                if child_id in trace.get("spans", {}):
                                    child_span = trace["spans"][child_id]

                                    # Extract start_time
                                    start_time = None
                                    if hasattr(child_span, "start_time"):
                                        start_time = child_span.start_time
                                    elif isinstance(child_span, dict):
                                        start_time = child_span.get("start_time")

                                    children_with_times.append((child_id, start_time or ""))

                            # Sort by timestamp (chronological order)
                            children_with_times.sort(key=lambda x: x[1])
                            sorted_children = [c[0] for c in children_with_times]

                            # Update root span's children
                            if hasattr(root_span, "children"):
                                root_span.children = sorted_children
                            elif isinstance(root_span, dict):
                                root_span["children"] = sorted_children

                except Exception as sort_error:
                    pass

        except Exception as e:
            pass

    def _reorder_spans_chronologically(self, trace: Dict[str, Any]):
        """
        Reorder the spans dictionary to be in chronological order for better JSON readability.
        This rebuilds the spans dict with spans ordered by their start_time.
        """
        try:
            spans = trace.get("spans", {})
            if not spans:
                return

            # Build list of (span_id, start_time, span_object) tuples
            spans_with_times = []
            for span_id, span in spans.items():
                # Extract start_time
                start_time = None
                if hasattr(span, "start_time"):
                    start_time = span.start_time
                elif isinstance(span, dict):
                    start_time = span.get("start_time")

                # Use empty string as fallback to sort at beginning
                spans_with_times.append((span_id, start_time or "", span))

            # Sort by timestamp (chronological order)
            spans_with_times.sort(key=lambda x: x[1])

            # Rebuild spans dictionary in chronological order
            # Root span should be first
            root_span_id = trace.get("root_span_id")
            ordered_spans = {}

            # Add root span first
            if root_span_id and root_span_id in spans:
                ordered_spans[root_span_id] = spans[root_span_id]

            # Add remaining spans in chronological order
            for span_id, start_time, span in spans_with_times:
                if span_id != root_span_id:  # Skip root, already added
                    ordered_spans[span_id] = span

            # Replace trace spans with ordered version
            trace["spans"] = ordered_spans

        except Exception as e:
            # Non-critical, continue with original order
            pass


# Backward compatibility alias
Tracer = TracerV2
