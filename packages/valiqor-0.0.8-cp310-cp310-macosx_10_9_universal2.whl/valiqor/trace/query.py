"""
Valiqor Trace Query Client - Read Traces from Backend

Query, list, and inspect traces that have been uploaded to the
Valiqor backend.  This is the read-side counterpart of the
instrumentation provided by ``TracerV2`` / ``autolog``.

The backend routes live under ``/api/v1/traces``.
"""

from typing import Any, Dict, List, Optional, Union

from valiqor.common import DEFAULT_BACKEND_URL, get_config, HTTPClient
from valiqor.common.exceptions import AuthenticationError, ValidationError
from valiqor.trace.models import (
    TraceEvalStep,
    TraceFullResult,
    TraceListResponse,
    TraceMessage,
    TraceOverview,
    TraceSpan,
    TraceSummary,
)


class TraceQueryClient:
    """
    Client for querying traces stored in the Valiqor backend.

    Provides methods that mirror the frontend dashboard's trace
    inspection screens — listing, detail views, messages, spans,
    full JSON, and eval steps.

    Args:
        api_key: API key for authentication
        base_url: Backend URL override
        timeout: Request timeout in seconds (default: 300)
        _config: Internal config dict (from ValiqorClient facade)

    Example:
        client = TraceQueryClient(api_key="vq_xxx")

        traces = client.list_traces(project_name="my-app", page=1)
        for t in traces["traces"]:
            print(t["trace_id"], t["status"])

        detail = client.get_trace(trace_id=traces["traces"][0]["trace_id"])
    """

    # Trace routes use /api/v1 prefix (separate from /v2 eval/security)
    API_PREFIX = "/api/v1/traces"

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: int = 300,
        _config: Optional[Dict[str, Any]] = None,
    ):
        if _config:
            self._config = _config
        else:
            overrides: Dict[str, Any] = {}
            if api_key:
                overrides["api_key"] = api_key
            if base_url:
                overrides["backend_url"] = base_url
            self._config = get_config(**overrides)

        self._api_key = api_key or self._config.get("api_key", "")
        self._base_url = base_url or self._config.get("backend_url", DEFAULT_BACKEND_URL)
        self._timeout = timeout

        if not self._api_key:
            raise AuthenticationError(
                "API key required. Pass api_key parameter or set VALIQOR_API_KEY env var."
            )

        self._http = HTTPClient(
            base_url=self._base_url,
            api_key=self._api_key,
            timeout=self._timeout,
            user_agent="valiqor-sdk/1.0.0 (trace-query)",
        )

    # ------------------------------------------------------------------
    # List / Search
    # ------------------------------------------------------------------

    _project_cache: Dict[str, str] = {}  # name → id

    def _resolve_project_id(
        self, project_name: str, refresh: bool = False
    ) -> str:
        """Resolve project name → UUID via ``GET /v2/projects``."""
        if not refresh and project_name in self._project_cache:
            return self._project_cache[project_name]

        projects = self._http.get("/v2/projects")
        proj_list = projects if isinstance(projects, list) else projects.get("projects", [])
        self._project_cache = {p["name"]: p["id"] for p in proj_list}

        if project_name not in self._project_cache:
            raise ValidationError(
                f"Project '{project_name}' not found. "
                f"Available: {list(self._project_cache.keys())}"
            )
        return self._project_cache[project_name]

    def list_traces(
        self,
        project_name: Optional[str] = None,
        project_id: Optional[str] = None,
        page: int = 1,
        page_size: int = 20,
    ) -> TraceListResponse:
        """
        List traces for a project (paginated).

        The backend requires ``project_id`` (UUID).  You may pass either
        ``project_id`` directly or ``project_name`` which is resolved
        automatically.

        Args:
            project_name: Project name (resolved to UUID)
            project_id: Project UUID (preferred; skips resolution)
            page: Page number (1-indexed, default 1)
            page_size: Items per page (1-100, default 20)

        Returns:
            TraceListResponse with typed TraceRecord items and pagination.

        Example:
            result = client.list_traces("my-app", page=1, page_size=50)
            for t in result.traces:
                print(t.trace_id, t.status)
        """
        if not project_id:
            if not project_name:
                raise ValidationError("project_name or project_id is required")
            project_id = self._resolve_project_id(project_name)
        params: Dict[str, Any] = {
            "project_id": project_id,
            "page": page,
            "page_size": page_size,
        }
        data = self._http.get(self.API_PREFIX, params=params)
        return TraceListResponse.from_dict(data)

    # ------------------------------------------------------------------
    # Single Trace Views
    # ------------------------------------------------------------------

    def get_trace(self, trace_id: str) -> TraceOverview:
        """
        Get overview / metadata for a single trace.

        Args:
            trace_id: Trace UUID

        Returns:
            TraceOverview with trace metadata.
        """
        data = self._http.get(f"{self.API_PREFIX}/{trace_id}")
        return TraceOverview.from_dict(data)

    def get_summary(self, trace_id: str) -> TraceSummary:
        """
        Get a condensed summary of the trace.

        The summary includes token counts, cost, span count, message count,
        and any high-level annotations attached by the backend.

        Args:
            trace_id: Trace UUID

        Returns:
            TraceSummary with all summary fields.
        """
        data = self._http.get(f"{self.API_PREFIX}/{trace_id}/summary")
        return TraceSummary.from_dict(data)

    def get_messages(self, trace_id: str) -> List[TraceMessage]:
        """
        Get the message list (user ↔ assistant turns) for a trace.

        Args:
            trace_id: Trace UUID

        Returns:
            List of TraceMessage objects.
        """
        data = self._http.get(f"{self.API_PREFIX}/{trace_id}/messages")
        raw = data if isinstance(data, list) else data.get("messages", [])
        return [TraceMessage.from_dict(m) for m in raw]

    def get_spans(self, trace_id: str) -> List[TraceSpan]:
        """
        Get the span tree for a trace.

        Each span includes: span_id, parent_span_id, name, kind,
        start_time, end_time, attributes, status, etc.

        Args:
            trace_id: Trace UUID

        Returns:
            List of TraceSpan objects.
        """
        data = self._http.get(f"{self.API_PREFIX}/{trace_id}/spans")
        raw = data if isinstance(data, list) else data.get("spans", [])
        return [TraceSpan.from_dict(s) for s in raw]

    def get_full_trace(self, trace_id: str) -> TraceFullResult:
        """
        Get the complete raw trace JSON as stored in the backend.

        This returns the full uploaded trace payload including all
        messages, spans, retrievals, metadata, and execution tree.

        Args:
            trace_id: Trace UUID

        Returns:
            TraceFullResult with all trace data.
        """
        data = self._http.get(f"{self.API_PREFIX}/{trace_id}/full")
        return TraceFullResult.from_dict(data)

    def get_eval_steps(self, trace_id: str) -> List[TraceEvalStep]:
        """
        Get evaluation steps that were run against this trace.

        If the trace was evaluated (e.g. via ``evaluate_trace``), this
        returns the per-metric eval steps with scores and explanations.

        Args:
            trace_id: Trace UUID

        Returns:
            List of TraceEvalStep objects.
        """
        data = self._http.get(f"{self.API_PREFIX}/{trace_id}/eval_steps")
        raw = data if isinstance(data, list) else data.get("eval_steps", [])
        return [TraceEvalStep.from_dict(s) for s in raw]

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    def close(self):
        """Close the HTTP session."""
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()

    def __repr__(self) -> str:
        return f"TraceQueryClient(base_url={self._base_url!r})"
