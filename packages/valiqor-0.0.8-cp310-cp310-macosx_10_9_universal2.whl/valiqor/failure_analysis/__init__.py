"""
Valiqor Failure Analysis - Failure Forensics for LLM Applications

Analyze LLM outputs for failure patterns across hallucination, instruction compliance,
safety, retrieval quality, tool usage, and more.

Example:
    from valiqor.failure_analysis import ValiqorFAClient

    client = ValiqorFAClient(api_key="vq_xxx", project_name="my-app")

    # Analyze a trace
    result = client.run(trace_id="trace_abc123")

    # Analyze dataset items
    result = client.run(dataset=[
        {"input": "What is 2+2?", "output": "5", "context": ["2+2=4"]}
    ])

    print(result.summary)
"""

from typing import TYPE_CHECKING

# =============================================================================
# MODELS (always available - plain Python dataclasses)
# =============================================================================
from valiqor.failure_analysis.models import (
    FABucket,
    FABucketDistribution,
    FAEvidenceItem,
    FAInsightsSummary,
    FAJobStatus,
    FAPlaygroundResult,
    FARecurringFailure,
    FARunInput,
    FARunListItem,
    FARunListPage,
    FARunResult,
    FAScoringBreakdown,
    FASecurityCategoryIssue,
    FASecurityInsightsSummary,
    FASubcategory,
    FASummary,
    FATag,
    FATrendDataPoint,
    FATrends,
)

# =============================================================================
# COMPILED CLIENT LOADER
# =============================================================================
# The client module is compiled for distribution:
# - client.py -> _client_impl.so/.pyd


def _load_fa_client():
    """Load the failure analysis client (compiled or source)."""
    try:
        # Try compiled extension first (PyPI distribution)
        from valiqor.failure_analysis import _client_impl

        return _client_impl.ValiqorFAClient
    except ImportError:
        try:
            # Fallback to source (development mode)
            from valiqor.failure_analysis.client import ValiqorFAClient

            return ValiqorFAClient
        except ImportError as e:
            raise ImportError(
                "Failure Analysis client not available. Install valiqor from PyPI or "
                "ensure you're in the development environment.\n"
                f"Original error: {e}"
            ) from None


# Load the client class
ValiqorFAClient = _load_fa_client()

# =============================================================================
# PUBLIC API
# =============================================================================
__all__ = [
    "ValiqorFAClient",
    "FARunResult",
    "FARunInput",
    "FASummary",
    "FATag",
    "FAEvidenceItem",
    "FAScoringBreakdown",
    "FARunListItem",
    "FARunListPage",
    "FASubcategory",
    "FABucket",
    "FARecurringFailure",
    "FABucketDistribution",
    "FAInsightsSummary",
    "FATrendDataPoint",
    "FATrends",
    "FASecurityCategoryIssue",
    "FASecurityInsightsSummary",
    "FAPlaygroundResult",
    "FAJobStatus",
]
