"""
Valiqor Failure Analysis Models - Data Classes for Failure Analysis Results

Matches the backend's failure_analysis/api/models.py response shapes.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


@dataclass
class FAEvidenceItem:
    """Evidence item supporting a failure tag."""

    item_id: str
    evidence_type: str
    description: str
    source: str
    confidence: float = 1.0
    content_snippet: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "item_id": self.item_id,
            "evidence_type": self.evidence_type,
            "description": self.description,
            "source": self.source,
            "confidence": self.confidence,
            "content_snippet": self.content_snippet,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FAEvidenceItem":
        """Create from a backend response dict."""
        return cls(
            item_id=data.get("item_id", ""),
            evidence_type=data.get("evidence_type", ""),
            description=data.get("description", ""),
            source=data.get("source", ""),
            confidence=data.get("confidence", 1.0),
            content_snippet=data.get("content_snippet"),
            metadata=data.get("metadata", {}),
        )


@dataclass
class FAScoringBreakdown:
    """Scoring breakdown for a failure tag."""

    impact: int
    risk: int
    final_severity: float
    final_confidence: float
    frequency_weight: float = 1.0
    security_override: Optional[str] = None
    deterministic_weight: float = 0.0
    judge_weight: float = 0.0
    security_weight: float = 0.0
    metric_agreement_bonus: float = 0.0
    disagreement_penalty: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "impact": self.impact,
            "risk": self.risk,
            "final_severity": self.final_severity,
            "final_confidence": self.final_confidence,
            "frequency_weight": self.frequency_weight,
            "security_override": self.security_override,
            "deterministic_weight": self.deterministic_weight,
            "judge_weight": self.judge_weight,
            "security_weight": self.security_weight,
            "metric_agreement_bonus": self.metric_agreement_bonus,
            "disagreement_penalty": self.disagreement_penalty,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FAScoringBreakdown":
        """Create from a backend response dict."""
        return cls(
            impact=data.get("impact", 0),
            risk=data.get("risk", 0),
            final_severity=data.get("final_severity", 0.0),
            final_confidence=data.get("final_confidence", 0.0),
            frequency_weight=data.get("frequency_weight", 1.0),
            security_override=data.get("security_override"),
            deterministic_weight=data.get("deterministic_weight", 0.0),
            judge_weight=data.get("judge_weight", 0.0),
            security_weight=data.get("security_weight", 0.0),
            metric_agreement_bonus=data.get("metric_agreement_bonus", 0.0),
            disagreement_penalty=data.get("disagreement_penalty", 0.0),
        )


@dataclass
class FATag:
    """Single failure tag result."""

    tag_id: str
    bucket_id: str
    bucket_name: str
    subcategory_id: str
    subcategory_name: str
    decision: str  # "pass", "fail", or "unsure"
    severity: float  # 0.0-5.0
    confidence: float  # 0.0-1.0
    detector_type_used: str  # "deterministic", "llm_judge", or "hybrid"
    judge_rationale: Optional[str] = None
    scoring_breakdown: Optional[FAScoringBreakdown] = None
    eval_metric_values: Dict[str, float] = field(default_factory=dict)
    evidence_items: List[FAEvidenceItem] = field(default_factory=list)
    item_index: Optional[int] = None  # 0-based index of the dataset item this tag belongs to

    # Human review tracking
    is_reviewed: bool = False
    reviewed_at: Optional[str] = None
    issue_url: Optional[str] = None

    def __str__(self) -> str:
        item_str = f", item={self.item_index}" if self.item_index is not None else ""
        return (
            f"[{self.decision.upper()}] {self.subcategory_name} "
            f"(severity={self.severity:.1f}, confidence={self.confidence:.2f}{item_str})"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "tag_id": self.tag_id,
            "bucket_id": self.bucket_id,
            "bucket_name": self.bucket_name,
            "subcategory_id": self.subcategory_id,
            "subcategory_name": self.subcategory_name,
            "decision": self.decision,
            "severity": self.severity,
            "confidence": self.confidence,
            "detector_type_used": self.detector_type_used,
            "judge_rationale": self.judge_rationale,
            "scoring_breakdown": self.scoring_breakdown.to_dict() if self.scoring_breakdown else None,
            "eval_metric_values": self.eval_metric_values,
            "evidence_items": [e.to_dict() for e in self.evidence_items],
            "item_index": self.item_index,
            "is_reviewed": self.is_reviewed,
            "reviewed_at": self.reviewed_at,
            "issue_url": self.issue_url,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FATag":
        """Create from a backend response dict."""
        scoring = data.get("scoring_breakdown")
        scoring_obj = FAScoringBreakdown.from_dict(scoring) if scoring else None
        evidence = [
            FAEvidenceItem.from_dict(e) for e in data.get("evidence_items", [])
        ]
        return cls(
            tag_id=data.get("tag_id", ""),
            bucket_id=data.get("bucket_id", ""),
            bucket_name=data.get("bucket_name", ""),
            subcategory_id=data.get("subcategory_id", ""),
            subcategory_name=data.get("subcategory_name", ""),
            decision=data.get("decision", ""),
            severity=data.get("severity", 0.0),
            confidence=data.get("confidence", 0.0),
            detector_type_used=data.get("detector_type_used", ""),
            judge_rationale=data.get("judge_rationale"),
            scoring_breakdown=scoring_obj,
            eval_metric_values=data.get("eval_metric_values", {}),
            evidence_items=evidence,
            item_index=data.get("item_index"),
            is_reviewed=data.get("is_reviewed", False),
            reviewed_at=data.get("reviewed_at"),
            issue_url=data.get("issue_url"),
        )


@dataclass
class FASummary:
    """Summary of failure analysis results."""

    total_failures_detected: int = 0
    total_passes: int = 0
    total_uncertain: int = 0
    overall_severity: float = 0.0
    overall_confidence: float = 0.0
    primary_failure: Optional[str] = None
    primary_failure_name: Optional[str] = None
    buckets_affected: List[str] = field(default_factory=list)
    should_alert: bool = False
    should_gate_ci: bool = False
    needs_human_review: bool = False
    total_items: int = 0  # Total dataset items analyzed
    items_with_failures: int = 0  # Items that have at least one failure tag
    items_all_passed: int = 0  # Items where all checks passed

    def __str__(self) -> str:
        return (
            f"FA Summary: {self.total_failures_detected} failures, "
            f"{self.total_passes} passes, severity={self.overall_severity:.1f}"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_failures_detected": self.total_failures_detected,
            "total_passes": self.total_passes,
            "total_uncertain": self.total_uncertain,
            "overall_severity": self.overall_severity,
            "overall_confidence": self.overall_confidence,
            "primary_failure": self.primary_failure,
            "primary_failure_name": self.primary_failure_name,
            "buckets_affected": self.buckets_affected,
            "should_alert": self.should_alert,
            "should_gate_ci": self.should_gate_ci,
            "needs_human_review": self.needs_human_review,
            "total_items": self.total_items,
            "items_with_failures": self.items_with_failures,
            "items_all_passed": self.items_all_passed,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FASummary":
        """Create from a backend response dict."""
        if not data:
            return cls()
        return cls(
            total_failures_detected=data.get("total_failures_detected", 0),
            total_passes=data.get("total_passes", 0),
            total_uncertain=data.get("total_uncertain", 0),
            overall_severity=data.get("overall_severity", 0.0),
            overall_confidence=data.get("overall_confidence", 0.0),
            primary_failure=data.get("primary_failure"),
            primary_failure_name=data.get("primary_failure_name"),
            buckets_affected=data.get("buckets_affected", []),
            should_alert=data.get("should_alert", False),
            should_gate_ci=data.get("should_gate_ci", False),
            needs_human_review=data.get("needs_human_review", False),
            total_items=data.get("total_items", 0),
            items_with_failures=data.get("items_with_failures", 0),
            items_all_passed=data.get("items_all_passed", 0),
        )


@dataclass
class FARunInput:
    """Original input item with per-item failure stats."""

    item_index: int
    input_text: str
    output_text: str
    input_preview: str = ""
    output_preview: str = ""
    context: Optional[List[str]] = None
    tool_calls: Optional[List[Dict[str, Any]]] = None
    trace_id: Optional[str] = None
    failure_count: int = 0
    pass_count: int = 0
    unsure_count: int = 0
    max_severity: float = 0.0

    @property
    def total_checks(self) -> int:
        return self.failure_count + self.pass_count + self.unsure_count

    @property
    def has_failures(self) -> bool:
        return self.failure_count > 0

    def __str__(self) -> str:
        status = "FAIL" if self.has_failures else "PASS"
        return (
            f"[{status}] Item {self.item_index}: "
            f"{self.failure_count} failures, {self.pass_count} passes"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "item_index": self.item_index,
            "input_text": self.input_text,
            "output_text": self.output_text,
            "input_preview": self.input_preview,
            "output_preview": self.output_preview,
            "context": self.context,
            "tool_calls": self.tool_calls,
            "trace_id": self.trace_id,
            "failure_count": self.failure_count,
            "pass_count": self.pass_count,
            "unsure_count": self.unsure_count,
            "max_severity": self.max_severity,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FARunInput":
        """Create from a backend response dict."""
        return cls(
            item_index=data.get("item_index", 0),
            input_text=data.get("input_text", ""),
            output_text=data.get("output_text", ""),
            input_preview=data.get("input_preview", ""),
            output_preview=data.get("output_preview", ""),
            context=data.get("context"),
            tool_calls=data.get("tool_calls"),
            trace_id=data.get("trace_id"),
            failure_count=data.get("failure_count", 0),
            pass_count=data.get("pass_count", 0),
            unsure_count=data.get("unsure_count", 0),
            max_severity=data.get("max_severity", 0.0),
        )


@dataclass
class FARunResult:
    """Full failure analysis response."""

    run_id: str
    status: str  # "completed", "processing", "failed"
    mode: str  # "minimal" or "full"
    input_type: str  # "trace", "json", or "csv"
    feature_kind: str  # "rag", "agent", "agentic_rag", "generic_llm"
    summary: FASummary
    failure_tags: List[FATag] = field(default_factory=list)
    eval_metrics: Optional[Dict[str, float]] = None
    eval_run_id: Optional[str] = None
    security_flags: Optional[Dict[str, str]] = None
    security_batch_id: Optional[str] = None
    detectors_run: List[str] = field(default_factory=list)
    detectors_skipped: List[str] = field(default_factory=list)
    duration_ms: int = 0
    tokens_used: int = 0
    created_at: Optional[str] = None
    inputs: List[FARunInput] = field(default_factory=list)  # Original input items with per-item stats

    def __str__(self) -> str:
        items_str = f", Items: {len(self.inputs)}" if self.inputs else ""
        return (
            f"FA Run {self.run_id} ({self.status})\n"
            f"Mode: {self.mode}, Type: {self.input_type}, Feature: {self.feature_kind}\n"
            f"Failures: {self.summary.total_failures_detected}, "
            f"Passes: {self.summary.total_passes}{items_str}\n"
            f"Severity: {self.summary.overall_severity:.1f}"
        )

    @property
    def tags(self) -> List[FATag]:
        """Alias for failure_tags (convenience)."""
        return self.failure_tags

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "status": self.status,
            "mode": self.mode,
            "input_type": self.input_type,
            "feature_kind": self.feature_kind,
            "summary": self.summary.to_dict(),
            "failure_tags": [t.to_dict() for t in self.failure_tags],
            "eval_metrics": self.eval_metrics,
            "eval_run_id": self.eval_run_id,
            "security_flags": self.security_flags,
            "security_batch_id": self.security_batch_id,
            "detectors_run": self.detectors_run,
            "detectors_skipped": self.detectors_skipped,
            "duration_ms": self.duration_ms,
            "tokens_used": self.tokens_used,
            "created_at": self.created_at,
            "inputs": [i.to_dict() for i in self.inputs],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FARunResult":
        """Create from a backend response dict."""
        summary = FASummary.from_dict(data.get("summary", {}))
        tags = [FATag.from_dict(t) for t in data.get("failure_tags", [])]
        inputs = [FARunInput.from_dict(i) for i in data.get("inputs", [])]
        return cls(
            run_id=data.get("run_id", ""),
            status=data.get("status", ""),
            mode=data.get("mode", ""),
            input_type=data.get("input_type", ""),
            feature_kind=data.get("feature_kind", ""),
            summary=summary,
            failure_tags=tags,
            eval_metrics=data.get("eval_metrics"),
            eval_run_id=data.get("eval_run_id"),
            security_flags=data.get("security_flags"),
            security_batch_id=data.get("security_batch_id"),
            detectors_run=data.get("detectors_run", []),
            detectors_skipped=data.get("detectors_skipped", []),
            duration_ms=data.get("duration_ms", 0),
            tokens_used=data.get("tokens_used", 0),
            created_at=data.get("created_at"),
            inputs=inputs,
        )

    def get_item_tags(self, item_index: int) -> List[FATag]:
        """Get all failure tags for a specific dataset item."""
        return [t for t in self.failure_tags if t.item_index == item_index]

    def get_failed_items(self) -> List[FARunInput]:
        """Get input items that have at least one failure."""
        return [i for i in self.inputs if i.has_failures]

    def get_clean_items(self) -> List[FARunInput]:
        """Get input items where all checks passed."""
        return [i for i in self.inputs if not i.has_failures]


@dataclass
class FARunListItem:
    """Summary item for FA runs list."""

    run_id: str
    status: str
    input_type: str
    minimal_mode: bool
    dataset_item_count: int
    created_at: str
    feature_kind: Optional[str] = None
    project_name: Optional[str] = None
    trace_id: Optional[str] = None
    total_failures_detected: Optional[int] = None
    total_passes: Optional[int] = None
    primary_failure: Optional[str] = None
    overall_severity: Optional[float] = None
    eval_run_id: Optional[str] = None
    security_batch_id: Optional[str] = None
    has_security_issues: Optional[bool] = None
    duration_ms: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "status": self.status,
            "input_type": self.input_type,
            "minimal_mode": self.minimal_mode,
            "dataset_item_count": self.dataset_item_count,
            "created_at": self.created_at,
            "feature_kind": self.feature_kind,
            "project_name": self.project_name,
            "trace_id": self.trace_id,
            "total_failures_detected": self.total_failures_detected,
            "total_passes": self.total_passes,
            "primary_failure": self.primary_failure,
            "overall_severity": self.overall_severity,
            "eval_run_id": self.eval_run_id,
            "security_batch_id": self.security_batch_id,
            "has_security_issues": self.has_security_issues,
            "duration_ms": self.duration_ms,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FARunListItem":
        """Create from a backend response dict."""
        return cls(
            run_id=data.get("run_id", ""),
            status=data.get("status", ""),
            input_type=data.get("input_type", ""),
            minimal_mode=data.get("minimal_mode", False),
            dataset_item_count=data.get("dataset_item_count", 0),
            created_at=data.get("created_at", ""),
            feature_kind=data.get("feature_kind"),
            project_name=data.get("project_name"),
            trace_id=data.get("trace_id"),
            total_failures_detected=data.get("total_failures_detected"),
            total_passes=data.get("total_passes"),
            primary_failure=data.get("primary_failure"),
            overall_severity=data.get("overall_severity"),
            eval_run_id=data.get("eval_run_id"),
            security_batch_id=data.get("security_batch_id"),
            has_security_issues=data.get("has_security_issues"),
            duration_ms=data.get("duration_ms"),
        )


@dataclass
class FASubcategory:
    """Subcategory in the failure taxonomy."""

    subcategory_id: str
    subcategory_name: str
    description: str
    detection_approach: str  # "deterministic", "llm_judge", or "hybrid"
    applies_to: List[str] = field(default_factory=list)
    requires_retrieval: bool = False
    requires_tools: bool = False
    minimal_mode_compatible: bool = False
    required_inputs: List[str] = field(default_factory=list)
    related_eval_metrics: List[str] = field(default_factory=list)
    related_security_categories: List[str] = field(default_factory=list)
    impact_score: int = 1
    risk_category: str = "medium"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "subcategory_id": self.subcategory_id,
            "subcategory_name": self.subcategory_name,
            "description": self.description,
            "detection_approach": self.detection_approach,
            "applies_to": self.applies_to,
            "requires_retrieval": self.requires_retrieval,
            "requires_tools": self.requires_tools,
            "minimal_mode_compatible": self.minimal_mode_compatible,
            "required_inputs": self.required_inputs,
            "related_eval_metrics": self.related_eval_metrics,
            "related_security_categories": self.related_security_categories,
            "impact_score": self.impact_score,
            "risk_category": self.risk_category,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FASubcategory":
        """Create from a backend response dict."""
        return cls(
            subcategory_id=data.get("subcategory_id", ""),
            subcategory_name=data.get("subcategory_name", ""),
            description=data.get("description", ""),
            detection_approach=data.get("detection_approach", ""),
            applies_to=data.get("applies_to", []),
            requires_retrieval=data.get("requires_retrieval", False),
            requires_tools=data.get("requires_tools", False),
            minimal_mode_compatible=data.get("minimal_mode_compatible", False),
            required_inputs=data.get("required_inputs", []),
            related_eval_metrics=data.get("related_eval_metrics", []),
            related_security_categories=data.get("related_security_categories", []),
            impact_score=data.get("impact_score", 1),
            risk_category=data.get("risk_category", "medium"),
        )


@dataclass
class FABucket:
    """Bucket (L1 category) in the failure taxonomy."""

    bucket_id: str
    bucket_name: str
    description: str
    subcategories: List[FASubcategory] = field(default_factory=list)

    def __str__(self) -> str:
        return f"{self.bucket_name} ({len(self.subcategories)} subcategories)"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "bucket_id": self.bucket_id,
            "bucket_name": self.bucket_name,
            "description": self.description,
            "subcategories": [s.to_dict() for s in self.subcategories],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FABucket":
        """Create from a backend response dict."""
        return cls(
            bucket_id=data.get("bucket_id", ""),
            bucket_name=data.get("bucket_name", ""),
            description=data.get("description", ""),
            subcategories=[
                FASubcategory.from_dict(s) for s in data.get("subcategories", [])
            ],
        )


@dataclass
class FARecurringFailure:
    """A recurring failure pattern across runs."""

    subcategory_id: str
    subcategory_name: str
    bucket_id: str
    bucket_name: str
    occurrence_count: int
    affected_runs: int
    trend_percent: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "subcategory_id": self.subcategory_id,
            "subcategory_name": self.subcategory_name,
            "bucket_id": self.bucket_id,
            "bucket_name": self.bucket_name,
            "occurrence_count": self.occurrence_count,
            "affected_runs": self.affected_runs,
            "trend_percent": self.trend_percent,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FARecurringFailure":
        """Create from a backend response dict."""
        return cls(
            subcategory_id=data.get("subcategory_id", ""),
            subcategory_name=data.get("subcategory_name", ""),
            bucket_id=data.get("bucket_id", ""),
            bucket_name=data.get("bucket_name", ""),
            occurrence_count=data.get("occurrence_count", 0),
            affected_runs=data.get("affected_runs", 0),
            trend_percent=data.get("trend_percent", 0.0),
        )


@dataclass
class FABucketDistribution:
    """Distribution of failures by bucket."""

    bucket_id: str
    bucket_name: str
    failure_count: int
    percentage: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "bucket_id": self.bucket_id,
            "bucket_name": self.bucket_name,
            "failure_count": self.failure_count,
            "percentage": self.percentage,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FABucketDistribution":
        """Create from a backend response dict."""
        return cls(
            bucket_id=data.get("bucket_id", ""),
            bucket_name=data.get("bucket_name", ""),
            failure_count=data.get("failure_count", 0),
            percentage=data.get("percentage", 0.0),
        )


@dataclass
class FAInsightsSummary:
    """Aggregated insights across FA runs."""

    total_runs: int
    total_items_analyzed: int
    overall_failure_rate: float = 0.0
    average_severity: float = 0.0
    period_days: int = 30
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    project_name: Optional[str] = None
    top_recurring_failures: List[FARecurringFailure] = field(default_factory=list)
    bucket_distribution: List[FABucketDistribution] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_runs": self.total_runs,
            "total_items_analyzed": self.total_items_analyzed,
            "overall_failure_rate": self.overall_failure_rate,
            "average_severity": self.average_severity,
            "period_days": self.period_days,
            "period_start": self.period_start,
            "period_end": self.period_end,
            "project_name": self.project_name,
            "top_recurring_failures": [
                {
                    "subcategory_id": f.subcategory_id,
                    "subcategory_name": f.subcategory_name,
                    "bucket_id": f.bucket_id,
                    "bucket_name": f.bucket_name,
                    "occurrence_count": f.occurrence_count,
                    "affected_runs": f.affected_runs,
                    "trend_percent": f.trend_percent,
                }
                for f in self.top_recurring_failures
            ],
            "bucket_distribution": [
                {
                    "bucket_id": b.bucket_id,
                    "bucket_name": b.bucket_name,
                    "failure_count": b.failure_count,
                    "percentage": b.percentage,
                }
                for b in self.bucket_distribution
            ],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FAInsightsSummary":
        """Create from a backend response dict."""
        return cls(
            total_runs=data.get("total_runs", 0),
            total_items_analyzed=data.get("total_items_analyzed", 0),
            overall_failure_rate=data.get("overall_failure_rate", 0.0),
            average_severity=data.get("average_severity", 0.0),
            period_days=data.get("period_days", 30),
            period_start=data.get("period_start"),
            period_end=data.get("period_end"),
            project_name=data.get("project_name"),
            top_recurring_failures=[
                FARecurringFailure.from_dict(f)
                for f in data.get("top_recurring_failures", [])
            ],
            bucket_distribution=[
                FABucketDistribution.from_dict(b)
                for b in data.get("bucket_distribution", [])
            ],
        )


@dataclass
class FATrendDataPoint:
    """Single data point for trend chart."""

    date: str
    failure_count: int
    pass_count: int
    total_runs: int
    failure_rate: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "date": self.date,
            "failure_count": self.failure_count,
            "pass_count": self.pass_count,
            "total_runs": self.total_runs,
            "failure_rate": self.failure_rate,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FATrendDataPoint":
        """Create from a backend response dict."""
        return cls(
            date=data.get("date", ""),
            failure_count=data.get("failure_count", 0),
            pass_count=data.get("pass_count", 0),
            total_runs=data.get("total_runs", 0),
            failure_rate=data.get("failure_rate", 0.0),
        )


@dataclass
class FATrends:
    """Time-series trend data for FA insights."""

    period_days: int
    project_name: Optional[str] = None
    trend_data: List[FATrendDataPoint] = field(default_factory=list)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "period_days": self.period_days,
            "project_name": self.project_name,
            "trend_data": [
                {
                    "date": t.date,
                    "failure_count": t.failure_count,
                    "pass_count": t.pass_count,
                    "total_runs": t.total_runs,
                    "failure_rate": t.failure_rate,
                }
                for t in self.trend_data
            ],
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FATrends":
        """Create from a backend response dict."""
        return cls(
            period_days=data.get("period_days", 30),
            project_name=data.get("project_name"),
            trend_data=[
                FATrendDataPoint.from_dict(t)
                for t in data.get("trend_data", [])
            ],
        )


@dataclass
class FASecurityCategoryIssue:
    """Security category with issue count."""

    category_id: str
    category_name: str
    issue_count: int = 0
    severity: str = "medium"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "category_id": self.category_id,
            "category_name": self.category_name,
            "issue_count": self.issue_count,
            "severity": self.severity,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FASecurityCategoryIssue":
        """Create from a backend response dict."""
        return cls(
            category_id=data.get("category_id", ""),
            category_name=data.get("category_name", ""),
            issue_count=data.get("issue_count", 0),
            severity=data.get("severity", "medium"),
        )


@dataclass
class FASecurityInsightsSummary:
    """Aggregated security insights across FA runs."""

    total_runs_with_security: int = 0
    runs_with_issues: int = 0
    total_issues_found: int = 0
    issues_by_category: List[FASecurityCategoryIssue] = field(default_factory=list)
    top_categories: List[FASecurityCategoryIssue] = field(default_factory=list)
    period_days: int = 30
    period_start: Optional[str] = None
    period_end: Optional[str] = None
    project_name: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return {
            "total_runs_with_security": self.total_runs_with_security,
            "runs_with_issues": self.runs_with_issues,
            "total_issues_found": self.total_issues_found,
            "issues_by_category": [
                {
                    "category_id": c.category_id,
                    "category_name": c.category_name,
                    "issue_count": c.issue_count,
                    "severity": c.severity,
                }
                for c in self.issues_by_category
            ],
            "top_categories": [
                {
                    "category_id": c.category_id,
                    "category_name": c.category_name,
                    "issue_count": c.issue_count,
                    "severity": c.severity,
                }
                for c in self.top_categories
            ],
            "period_days": self.period_days,
            "period_start": self.period_start,
            "period_end": self.period_end,
            "project_name": self.project_name,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FASecurityInsightsSummary":
        """Create from a backend response dict."""
        return cls(
            total_runs_with_security=data.get("total_runs_with_security", 0),
            runs_with_issues=data.get("runs_with_issues", 0),
            total_issues_found=data.get("total_issues_found", 0),
            issues_by_category=[
                FASecurityCategoryIssue.from_dict(c)
                for c in data.get("issues_by_category", [])
            ],
            top_categories=[
                FASecurityCategoryIssue.from_dict(c)
                for c in data.get("top_categories", [])
            ],
            period_days=data.get("period_days", 30),
            period_start=data.get("period_start"),
            period_end=data.get("period_end"),
            project_name=data.get("project_name"),
        )


@dataclass
class FAPlaygroundResult:
    """Response from playground analysis."""

    run_id: str
    summary: FASummary
    failure_tags: List[FATag] = field(default_factory=list)
    checks_passed: int = 0
    security_flags: Dict[str, str] = field(default_factory=dict)
    duration_ms: int = 0
    playground_runs_today: int = 0
    playground_limit_per_day: int = 10

    def __str__(self) -> str:
        return (
            f"Playground {self.run_id}: "
            f"{self.summary.total_failures_detected} failures, "
            f"{self.checks_passed} passed "
            f"({self.playground_runs_today}/{self.playground_limit_per_day} runs today)"
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "summary": self.summary.to_dict(),
            "failure_tags": [t.to_dict() for t in self.failure_tags],
            "checks_passed": self.checks_passed,
            "security_flags": self.security_flags,
            "duration_ms": self.duration_ms,
            "playground_runs_today": self.playground_runs_today,
            "playground_limit_per_day": self.playground_limit_per_day,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FAPlaygroundResult":
        """Create from a backend response dict."""
        summary = FASummary.from_dict(data.get("summary", {}))
        tags = [FATag.from_dict(t) for t in data.get("failure_tags", [])]
        return cls(
            run_id=data.get("run_id", ""),
            summary=summary,
            failure_tags=tags,
            checks_passed=data.get("checks_passed", 0),
            security_flags=data.get("security_flags", {}),
            duration_ms=data.get("duration_ms", 0),
            playground_runs_today=data.get("playground_runs_today", 0),
            playground_limit_per_day=data.get("playground_limit_per_day", 10),
        )


@dataclass
class FAJobStatus:
    """Status of an async failure analysis job."""

    job_id: str
    job_type: str = "failure_analysis"
    status: str = "queued"  # "queued", "running", "completed", "failed", "cancelled"
    progress_percent: float = 0.0
    current_item: int = 0
    total_items: int = 0
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    estimated_remaining_seconds: Optional[int] = None
    error: Optional[str] = None

    @property
    def is_running(self) -> bool:
        return self.status in ("queued", "running")

    @property
    def is_completed(self) -> bool:
        return self.status == "completed"

    @property
    def is_failed(self) -> bool:
        return self.status in ("failed", "cancelled")

    def __str__(self) -> str:
        if self.is_running:
            return (
                f"FA Job {self.job_id}: {self.status} "
                f"({self.progress_percent:.1f}% - {self.current_item}/{self.total_items})"
            )
        return f"FA Job {self.job_id}: {self.status}"

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FAJobStatus":
        """Create from a backend response dict."""
        return cls(
            job_id=data.get("job_id", ""),
            job_type=data.get("job_type", "failure_analysis"),
            status=data.get("status", "queued"),
            progress_percent=data.get("progress_percent", 0.0),
            current_item=data.get("current_item", 0),
            total_items=data.get("total_items", 0),
            started_at=data.get("started_at"),
            finished_at=data.get("finished_at"),
            estimated_remaining_seconds=data.get("estimated_remaining_seconds"),
            error=data.get("error"),
        )


# =========================================================================
# Paginated Response Wrapper
# =========================================================================


@dataclass
class FARunListPage:
    """Paginated list of FA run summaries."""

    items: List[FARunListItem]
    total: int
    page: int
    page_size: int
    has_more: bool = False

    def __str__(self) -> str:
        return f"FARunListPage(page={self.page}, showing={len(self.items)}, total={self.total})"

    def __len__(self) -> int:
        return len(self.items)

    def __iter__(self):
        return iter(self.items)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "items": [item.to_dict() for item in self.items],
            "total": self.total,
            "page": self.page,
            "page_size": self.page_size,
            "has_more": self.has_more,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FARunListPage":
        """Create from a backend response dict."""
        raw_items = data.get("items", [])
        items = [FARunListItem.from_dict(item) for item in raw_items]
        return cls(
            items=items,
            total=data.get("total", len(items)),
            page=data.get("page", 1),
            page_size=data.get("page_size", 20),
            has_more=data.get("has_more", False),
        )
