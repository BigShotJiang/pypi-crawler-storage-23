"""
Valiqor SDK Scanner Core Modules

This package contains the core analysis modules:
- ast_scanner: AST-based code analysis
- gitingest_preprocessor: Metadata extraction from gitingest
- merger: Combines AST and gitingest data
- stage1_classifier: Feature classification

These modules are compiled for distribution to protect core IP.
"""

from typing import TYPE_CHECKING

# =============================================================================
# COMPILED MODULE LOADERS
# =============================================================================


def _load_ast_scanner():
    """Load AST scanner module."""
    try:
        from valiqor.scanner.core import _ast_scanner_impl as mod

        return mod
    except ImportError:
        try:
            from valiqor.scanner.core import ast_scanner as mod

            return mod
        except ImportError as e:
            raise ImportError(
                "AST scanner not available. Install valiqor[scanner] from PyPI.\n"
                f"Original error: {e}"
            ) from None


def _load_preprocessor():
    """Load gitingest preprocessor module."""
    try:
        from valiqor.scanner.core import _gitingest_preprocessor_impl as mod

        return mod
    except ImportError:
        try:
            from valiqor.scanner.core import gitingest_preprocessor as mod

            return mod
        except ImportError as e:
            raise ImportError(
                "Preprocessor not available. Install valiqor[scanner] from PyPI.\n"
                f"Original error: {e}"
            ) from None


def _load_merger():
    """Load merger module."""
    try:
        from valiqor.scanner.core import _merger_impl as mod

        return mod
    except ImportError:
        try:
            from valiqor.scanner.core import merger as mod

            return mod
        except ImportError as e:
            raise ImportError(
                "Merger not available. Install valiqor[scanner] from PyPI.\n" f"Original error: {e}"
            ) from None


def _load_classifier():
    """Load stage1 classifier module."""
    try:
        from valiqor.scanner.core import _stage1_classifier_impl as mod

        return mod
    except ImportError:
        try:
            from valiqor.scanner.core import stage1_classifier as mod

            return mod
        except ImportError as e:
            raise ImportError(
                "Classifier not available. Install valiqor[scanner] from PyPI.\n"
                f"Original error: {e}"
            ) from None


# Load modules
_ast_mod = _load_ast_scanner()
_prep_mod = _load_preprocessor()
_merge_mod = _load_merger()
_class_mod = _load_classifier()

# Export functions
run_scanner = _ast_mod.run_scanner
run_preprocessor = _prep_mod.run_preprocessor
run_merger = _merge_mod.run_merger
run_classifier = _class_mod.run_classifier

# =============================================================================
# PUBLIC API
# =============================================================================
__all__ = [
    "run_scanner",
    "run_preprocessor",
    "run_merger",
    "run_classifier",
]
