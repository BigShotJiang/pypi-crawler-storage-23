"""
Valiqor Async Job - Shared Async Job Handle for All Modules

Provides a unified handle for tracking async jobs (evaluation, security, failure analysis).
"""

import time
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional


@dataclass
class AsyncJobStatus:
    """
    Typed status returned by AsyncJobHandle.status() and wait().

    Replaces raw Dict[str, Any] for consistent return types across all modules.
    """

    job_id: str
    job_type: str
    status: str  # "queued", "running", "processing", "completed", "failed", "cancelled"
    progress_percent: float = 0.0
    current_item: int = 0
    total_items: int = 0
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    error: Optional[str] = None

    @property
    def is_running(self) -> bool:
        """Check if job is still running."""
        return self.status in ("queued", "running", "processing")

    @property
    def is_completed(self) -> bool:
        """Check if job completed successfully."""
        return self.status == "completed"

    @property
    def is_failed(self) -> bool:
        """Check if job failed or was cancelled."""
        return self.status in ("failed", "cancelled")

    def __str__(self) -> str:
        if self.is_running:
            return (
                f"AsyncJob {self.job_id}: {self.status} "
                f"({self.progress_percent:.1f}% - {self.current_item}/{self.total_items})"
            )
        return f"AsyncJob {self.job_id}: {self.status}"

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "job_id": self.job_id,
            "job_type": self.job_type,
            "status": self.status,
            "progress_percent": self.progress_percent,
            "current_item": self.current_item,
            "total_items": self.total_items,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "error": self.error,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any], job_type: str = "") -> "AsyncJobStatus":
        """Create from a backend response dict."""
        return cls(
            job_id=data.get("job_id", ""),
            job_type=data.get("job_type", job_type),
            status=data.get("status", ""),
            progress_percent=data.get("progress_percent", 0.0),
            current_item=data.get("current_item", 0),
            total_items=data.get("total_items", 0),
            started_at=data.get("started_at"),
            finished_at=data.get("finished_at"),
            error=data.get("error"),
        )


class AsyncJobHandle:
    """
    Unified handle for tracking async jobs across all Valiqor modules.

    Used by evaluation, security, and failure analysis clients for
    polling job status, waiting for completion, and retrieving results.

    Args:
        http_client: HTTPClient instance for making API calls
        job_id: Unique job identifier
        job_type: Type of job ("evaluation", "security", "redteam", "failure_analysis")
        status_endpoint: URL path to poll for job status
        cancel_endpoint: URL path to cancel the job
        result_fetcher: Callable(job_id) -> result object, called on completion
        total_items: Total number of items being processed
        _completed_result: Pre-populated result for sync responses

    Example:
        job = client.evaluate_async(dataset, metrics)

        # Option 1: Wait with callback
        job.wait(on_progress=lambda s: print(f"{s['progress_percent']}%"))
        result = job.result()

        # Option 2: Poll manually
        while job.is_running():
            status = job.status()
            print(f"{status['progress_percent']}%")
            time.sleep(2)
        result = job.result()
    """

    def __init__(
        self,
        http_client,
        job_id: str,
        job_type: str,
        status_endpoint: str,
        cancel_endpoint: str,
        result_fetcher: Callable[[str], Any],
        total_items: int = 0,
        _completed_result: Any = None,
    ):
        self._http = http_client
        self._job_id = job_id
        self._job_type = job_type
        self._status_endpoint = status_endpoint
        self._cancel_endpoint = cancel_endpoint
        self._result_fetcher = result_fetcher
        self._total_items = total_items
        self._completed_result = _completed_result
        self._last_status: Optional[AsyncJobStatus] = None

    @property
    def job_id(self) -> str:
        """Get the job ID."""
        return self._job_id

    @property
    def job_type(self) -> str:
        """Get the job type."""
        return self._job_type

    def status(self) -> AsyncJobStatus:
        """
        Get current job status.

        Returns:
            AsyncJobStatus with progress information
        """
        if self._completed_result is not None:
            return AsyncJobStatus(
                job_id=self._job_id,
                job_type=self._job_type,
                status="completed",
                progress_percent=100.0,
                current_item=self._total_items,
                total_items=self._total_items,
            )

        data = self._http.get(self._status_endpoint)
        s = AsyncJobStatus.from_dict(data, job_type=self._job_type)
        self._last_status = s
        return s

    def is_running(self) -> bool:
        """Check if job is still running."""
        if self._completed_result is not None:
            return False
        return self.status().is_running

    def is_completed(self) -> bool:
        """Check if job completed successfully."""
        if self._completed_result is not None:
            return True
        return self.status().is_completed

    def cancel(self) -> Dict[str, Any]:
        """Request cancellation of this job."""
        if self._completed_result is not None:
            return {"status": "completed", "message": "Job already completed"}
        return self._http.post(self._cancel_endpoint)

    def result(self) -> Any:
        """
        Get the result (blocks until complete).

        Returns:
            Module-specific result object

        Raises:
            RuntimeError: If job failed or was cancelled
        """
        if self._completed_result is not None:
            return self._completed_result

        self.wait()

        last = self._last_status or self.status()
        if last.is_failed:
            raise RuntimeError(f"Job {last.status}: {last.error or 'unknown error'}")

        return self._result_fetcher(self._job_id)

    def wait(
        self,
        poll_interval: float = 2.0,
        timeout: Optional[float] = None,
        on_progress: Optional[Callable[[AsyncJobStatus], None]] = None,
    ) -> AsyncJobStatus:
        """
        Wait for job completion with optional progress callback.

        Args:
            poll_interval: Seconds between status checks (default: 2.0)
            timeout: Maximum seconds to wait (default: None = no timeout)
            on_progress: Optional callback(AsyncJobStatus) called on each poll

        Returns:
            Final AsyncJobStatus

        Raises:
            TimeoutError: If timeout exceeded
        """
        if self._completed_result is not None:
            s = self.status()
            if on_progress:
                on_progress(s)
            return s

        start_time = time.time()

        while True:
            s = self.status()

            if on_progress:
                on_progress(s)

            if not s.is_running:
                return s

            if timeout and (time.time() - start_time) > timeout:
                from valiqor.common.exceptions import TimeoutError

                raise TimeoutError(f"Job did not complete within {timeout} seconds")

            time.sleep(poll_interval)

    def __repr__(self) -> str:
        return f"AsyncJobHandle(job_id={self._job_id!r}, type={self._job_type!r})"
