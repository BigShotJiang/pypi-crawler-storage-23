"""
Valiqor Common - Shared Utilities

Common configuration, exceptions, and HTTP utilities used by all Valiqor modules.

This module provides:
- Configuration loading and management
- Exception hierarchy for all Valiqor errors
- HTTP client for API communication
- Project context for trace-scan correlation
"""

import importlib

# =============================================================================
# EXCEPTIONS (always available - plain Python)
# =============================================================================
_exc_mod = importlib.import_module("valiqor.common.exceptions")

ValiqorError = _exc_mod.ValiqorError
ConfigurationError = _exc_mod.ConfigurationError
AuthenticationError = _exc_mod.AuthenticationError
ValidationError = _exc_mod.ValidationError
APIError = _exc_mod.APIError
NetworkError = _exc_mod.NetworkError
TimeoutError = _exc_mod.TimeoutError
RateLimitError = _exc_mod.RateLimitError
QuotaExceededError = _exc_mod.QuotaExceededError
TracingError = _exc_mod.TracingError
ScanError = _exc_mod.ScanError
UploadError = _exc_mod.UploadError
EvaluationError = _exc_mod.EvaluationError

# =============================================================================
# COMPILED MODULE LOADER
# =============================================================================
# The following modules are compiled for distribution:
# - config.py -> _config_impl.so/.pyd
# - http.py -> _http_impl.so/.pyd
# - project_context.py -> _project_context_impl.so/.pyd


def _load_config_module():
    """Load the config module (compiled or source)."""
    try:
        return importlib.import_module("valiqor.common._config_impl")
    except ImportError:
        try:
            return importlib.import_module("valiqor.common.config")
        except ImportError as e:
            raise ImportError(
                "Config module not available. Install valiqor from PyPI or "
                "ensure you're in the development environment.\n"
                f"Original error: {e}"
            ) from None


def _load_http_module():
    """Load the HTTP module (compiled or source)."""
    try:
        return importlib.import_module("valiqor.common._http_impl")
    except ImportError:
        try:
            return importlib.import_module("valiqor.common.http")
        except ImportError as e:
            raise ImportError(
                "HTTP module not available. Install valiqor from PyPI.\n" f"Original error: {e}"
            ) from None


def _load_project_context_module():
    """Load the project context module (compiled or source)."""
    try:
        return importlib.import_module("valiqor.common._project_context_impl")
    except ImportError:
        try:
            return importlib.import_module("valiqor.common.project_context")
        except ImportError as e:
            raise ImportError(
                "Project context module not available. Install valiqor from PyPI.\n"
                f"Original error: {e}"
            ) from None


# Load compiled/source modules
_config_mod = _load_config_module()
_http_mod = _load_http_module()
_context_mod = _load_project_context_module()

# =============================================================================
# RE-EXPORTS FROM CONFIG MODULE
# =============================================================================
load_config_file = _config_mod.load_config_file
get_config = _config_mod.get_config
save_config = _config_mod.save_config
find_config_file = _config_mod.find_config_file
ensure_output_dirs = _config_mod.ensure_output_dirs
should_upload = _config_mod.should_upload
get_intelligence_message = _config_mod.get_intelligence_message

# Constants
CONFIG_FILE = _config_mod.CONFIG_FILE
DEFAULT_BACKEND_URL = _config_mod.DEFAULT_BACKEND_URL
DEFAULT_TRACE_DIR = _config_mod.DEFAULT_TRACE_DIR
DEFAULT_SCAN_DIR = _config_mod.DEFAULT_SCAN_DIR
TRACE_UPLOAD_ENDPOINT = _config_mod.TRACE_UPLOAD_ENDPOINT
SCAN_UPLOAD_ENDPOINT = _config_mod.SCAN_UPLOAD_ENDPOINT
VALIQOR_CLOUD_API = _config_mod.VALIQOR_CLOUD_API
VALIQOR_CLOUD_TRACES_API = _config_mod.VALIQOR_CLOUD_TRACES_API
VALIQOR_CLOUD_SCANS_API = _config_mod.VALIQOR_CLOUD_SCANS_API
VALIQOR_SIGNUP_URL = _config_mod.VALIQOR_SIGNUP_URL

# Alias for backward compatibility
load_config = load_config_file

# =============================================================================
# RE-EXPORTS FROM HTTP MODULE
# =============================================================================
HTTPClient = _http_mod.HTTPClient

# Try to get make_request if it exists (backward compat)
make_request = getattr(_http_mod, "make_request", None)

# =============================================================================
# RE-EXPORTS FROM PROJECT CONTEXT MODULE
# =============================================================================
CustomerProjectContext = _context_mod.CustomerProjectContext
get_customer_project_context = _context_mod.get_customer_project_context

# Optional exports that may not exist in all versions
show_dirty_state_warning = getattr(_context_mod, "show_dirty_state_warning", None)

# =============================================================================
# ASYNC JOB MODELS
# =============================================================================
from valiqor.common.async_job import AsyncJobHandle, AsyncJobStatus

# =============================================================================
# PUBLIC API
# =============================================================================
__all__ = [
    # Config functions
    "load_config",
    "load_config_file",
    "get_config",
    "save_config",
    "find_config_file",
    "ensure_output_dirs",
    "should_upload",
    "get_intelligence_message",
    # Config constants
    "CONFIG_FILE",
    "DEFAULT_BACKEND_URL",
    "DEFAULT_TRACE_DIR",
    "DEFAULT_SCAN_DIR",
    "TRACE_UPLOAD_ENDPOINT",
    "SCAN_UPLOAD_ENDPOINT",
    "VALIQOR_CLOUD_API",
    "VALIQOR_CLOUD_TRACES_API",
    "VALIQOR_SIGNUP_URL",
    # Exceptions
    "ValiqorError",
    "ConfigurationError",
    "AuthenticationError",
    "ValidationError",
    "APIError",
    "NetworkError",
    "TimeoutError",
    "RateLimitError",
    "QuotaExceededError",
    "TracingError",
    "ScanError",
    "UploadError",
    "EvaluationError",
    # HTTP
    "HTTPClient",
    "make_request",
    # Async Job
    "AsyncJobHandle",
    "AsyncJobStatus",
    # Project Context
    "CustomerProjectContext",
    "get_customer_project_context",
    "show_dirty_state_warning",
]
