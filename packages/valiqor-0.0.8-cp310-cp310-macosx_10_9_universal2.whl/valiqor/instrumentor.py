"""
Instrumentor module for auto-applying trace_workflow decorators to customer code.

This module provides functionality to automatically instrument Python source files
with valiqor tracing decorators based on workflow suggestions from the scanner.
"""

import ast
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple


@dataclass
class InstrumentationResult:
    """Result of instrumenting a single file."""

    file_path: str
    success: bool
    functions_instrumented: List[str]
    error: Optional[str] = None
    backup_path: Optional[str] = None


@dataclass
class ModuleBlockInfo:
    """Information about a module-level code block containing LLM calls."""

    start_line: int  # 1-indexed
    end_line: int  # 1-indexed
    indent: str  # Indentation of the block
    block_type: str  # 'if_main', 'if_block', 'top_level', 'with_block', 'loop_block'


def _is_main_block(node: ast.If) -> bool:
    """Check if an If node is 'if __name__ == "__main__"'."""
    if not isinstance(node.test, ast.Compare):
        return False

    left = node.test.left
    if not isinstance(left, ast.Name) or left.id != "__name__":
        return False

    if len(node.test.comparators) != 1:
        return False

    right = node.test.comparators[0]
    if isinstance(right, ast.Constant):
        return right.value == "__main__"
    elif isinstance(right, ast.Str):  # Python 3.7 compatibility
        return right.s == "__main__"


def _validate_syntax(source: str, file_path: str = "<unknown>") -> Tuple[bool, Optional[str]]:
    """
    Validate that source code has valid Python syntax.

    Args:
        source: Python source code to validate
        file_path: File path for error messages

    Returns:
        Tuple of (is_valid, error_message). error_message is None if valid.
    """
    try:
        ast.parse(source, filename=file_path)
        return True, None
    except SyntaxError as e:
        error_msg = f"Line {e.lineno}: {e.msg}"
        if e.text:
            error_msg += f" → {e.text.strip()}"
        return False, error_msg

    return False


def _find_module_level_block(source: str, target_line: int) -> Optional[ModuleBlockInfo]:
    """
    Find the enclosing module-level block that contains the target line.

    Uses AST to find the proper boundaries of:
    - if __name__ == "__main__" blocks
    - Top-level if/for/while/with blocks
    - Or returns the statement itself if standalone

    Args:
        source: Python source code
        target_line: The line number (1-indexed) containing the LLM call

    Returns:
        ModuleBlockInfo with block boundaries, or None if not found
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None

    lines = source.splitlines()

    # Find module-level statements that contain the target line
    for node in ast.iter_child_nodes(tree):
        # Skip imports, function defs, class defs
        if isinstance(
            node, (ast.Import, ast.ImportFrom, ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
        ):
            continue

        node_start = node.lineno
        node_end = getattr(node, "end_lineno", node.lineno)

        # Check if target line is within this node
        if node_start <= target_line <= node_end:
            # Found the containing statement
            indent = ""
            if 0 < node_start <= len(lines):
                line = lines[node_start - 1]
                indent = line[: len(line) - len(line.lstrip())]

            # Determine block type
            block_type = "top_level"
            if isinstance(node, ast.If):
                block_type = "if_main" if _is_main_block(node) else "if_block"
            elif isinstance(node, ast.With):
                block_type = "with_block"
            elif isinstance(node, (ast.For, ast.While)):
                block_type = "loop_block"
            elif isinstance(node, ast.Expr):
                block_type = "expression"

            return ModuleBlockInfo(
                start_line=node_start, end_line=node_end, indent=indent, block_type=block_type
            )

    return None


def _apply_module_level_context_manager(
    lines: List[str],
    block_info: ModuleBlockInfo,
    workflow_name: str,
    input_variable: Optional[str] = None,
) -> List[str]:
    """
    Wrap a module-level block with a context manager.

    Args:
        lines: Source code lines (will be modified)
        block_info: Information about the block to wrap
        workflow_name: Name for the workflow
        input_variable: Detected user input variable (optional)

    Returns:
        Modified lines
    """
    start_idx = block_info.start_line - 1  # Convert to 0-indexed
    end_idx = block_info.end_line  # end_lineno is inclusive

    # Get the indentation
    indent = block_info.indent
    extra_indent = "    "

    # Build context manager line with optional input_data
    if input_variable:
        cm_open = f'{indent}with trace_workflow("{workflow_name}", {{"user_query": {input_variable}}}):  # valiqor-instrumented\n'
    else:
        cm_open = f'{indent}with trace_workflow("{workflow_name}"):  # valiqor-instrumented\n'

    lines.insert(start_idx, cm_open)

    # Indent all lines in the block (now shifted by 1 due to insert)
    for i in range(start_idx + 1, end_idx + 1):
        if i < len(lines) and lines[i].strip():  # Don't indent empty lines
            lines[i] = extra_indent + lines[i]

    return lines


def _build_function_map(source: str) -> Dict[str, int]:
    """
    Use AST to build a map of function names to their definition line numbers.

    Includes both simple function names and class-qualified method names
    (e.g., "ClassName.method_name").

    Args:
        source: Python source code

    Returns:
        Dictionary mapping function names to their line numbers (1-indexed)
    """
    function_map = {}
    try:
        tree = ast.parse(source)

        for node in ast.iter_child_nodes(tree):
            # Top-level functions
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                function_map[node.name] = node.lineno
            # Class methods
            elif isinstance(node, ast.ClassDef):
                class_name = node.name
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        # Add both qualified and simple name
                        qualified_name = f"{class_name}.{item.name}"
                        function_map[qualified_name] = item.lineno
                        # Also add simple name for backward compatibility
                        if item.name not in function_map:
                            function_map[item.name] = item.lineno
    except SyntaxError:
        pass  # Return empty map if source has syntax errors
    return function_map


def _get_function_indent(lines: List[str], func_line: int) -> str:
    """
    Get the indentation of a function definition line.

    Args:
        lines: Source code lines
        func_line: 1-indexed line number of function definition

    Returns:
        Indentation string (spaces/tabs)
    """
    if 0 < func_line <= len(lines):
        line = lines[func_line - 1]
        return line[: len(line) - len(line.lstrip())]
    return ""


def _is_already_instrumented(
    lines: List[str], func_line: int, check_line_itself: bool = False
) -> bool:
    """
    Check if a function/block is already instrumented with valiqor decorators.

    Args:
        lines: Source code lines
        func_line: 1-indexed line number of function definition or block start
        check_line_itself: If True, also check if the line itself contains instrumentation
                          (useful for module-level blocks where context manager is on that line)

    Returns:
        True if already instrumented
    """
    # Check the line itself if requested (for module-level blocks)
    if check_line_itself and 0 < func_line <= len(lines):
        line = lines[func_line - 1].strip()
        if "valiqor-instrumented" in line:
            return True

    # Check lines above the function for existing decorator
    for i in range(func_line - 2, max(0, func_line - 10), -1):
        line = lines[i].strip()
        if not line or line.startswith("#"):
            continue
        if "@trace_workflow" in line or "valiqor-instrumented" in line:
            return True
        if not line.startswith("@"):
            break
    return False


def _find_function_body_start(lines: List[str], func_line: int) -> Tuple[int, str]:
    """
    Find the line where the function body starts (after def and docstring).

    Args:
        lines: Source code lines
        func_line: 1-indexed line number of function definition

    Returns:
        Tuple of (body_start_line_index, body_indent)
    """
    # Find the end of the function signature (may span multiple lines)
    i = func_line - 1
    paren_count = 0
    found_colon = False

    while i < len(lines):
        line = lines[i]
        paren_count += line.count("(") - line.count(")")
        if ":" in line and paren_count <= 0:
            found_colon = True
            break
        i += 1

    if not found_colon:
        return func_line, "    "

    # Move to the line after the def statement
    body_start = i + 1

    # Skip docstrings
    if body_start < len(lines):
        first_body_line = lines[body_start].strip()
        if first_body_line.startswith('"""') or first_body_line.startswith("'''"):
            quote = first_body_line[:3]
            if first_body_line.count(quote) >= 2 and len(first_body_line) > 3:
                # Single line docstring
                body_start += 1
            else:
                # Multi-line docstring
                body_start += 1
                while body_start < len(lines):
                    if quote in lines[body_start]:
                        body_start += 1
                        break
                    body_start += 1

    # Get the indentation of the body
    body_indent = "    "  # default
    if body_start < len(lines):
        body_line = lines[body_start]
        if body_line.strip():
            body_indent = body_line[: len(body_line) - len(body_line.lstrip())]

    return body_start, body_indent


def _apply_decorator(
    lines: List[str],
    func_line: int,
    workflow_name: str,
    indent: str,
    input_variable: Optional[str] = None,
) -> List[str]:
    """
    Insert a decorator line before the function definition.

    Args:
        lines: Source code lines (will be modified)
        func_line: 1-indexed line number of function definition
        indent: Indentation to use for the decorator
        workflow_name: Name for the workflow
        input_variable: Detected user input variable (optional, not used for decorators
                       as input is captured at runtime from function args)

    Returns:
        Modified lines
    """
    # Note: For decorators, we don't include input_variable in the static decorator
    # because the function will receive input at runtime. The trace_workflow decorator
    # can capture function arguments automatically.
    decorator_line = f'{indent}@trace_workflow("{workflow_name}")  # valiqor-instrumented\n'
    lines.insert(func_line - 1, decorator_line)
    return lines


def _apply_context_manager(
    lines: List[str],
    func_line: int,
    workflow_name: str,
    function_map: Dict[str, int],
    input_variable: Optional[str] = None,
) -> List[str]:
    """
    Wrap function body with a context manager.

    Args:
        lines: Source code lines (will be modified)
        func_line: 1-indexed line number of function definition
        workflow_name: Name for the workflow
        function_map: Map of function names to line numbers
        input_variable: Detected user input variable (optional)

    Returns:
        Modified lines
    """
    body_start, body_indent = _find_function_body_start(lines, func_line)

    # Find the end of the function by looking for the next function or end of indent
    func_end = len(lines)
    func_indent = _get_function_indent(lines, func_line)

    for i in range(body_start, len(lines)):
        line = lines[i]
        if line.strip() and not line.strip().startswith("#"):
            current_indent = line[: len(line) - len(line.lstrip())]
            if len(current_indent) <= len(func_indent) and line.strip():
                func_end = i
                break

    # Build context manager line with optional input_data
    if input_variable:
        cm_open = f'{body_indent}with trace_workflow("{workflow_name}", {{"user_query": {input_variable}}}):  # valiqor-instrumented\n'
    else:
        cm_open = f'{body_indent}with trace_workflow("{workflow_name}"):  # valiqor-instrumented\n'

    lines.insert(body_start, cm_open)

    # Indent the function body
    extra_indent = "    "
    for i in range(body_start + 1, func_end + 1):  # +1 because we inserted a line
        if lines[i].strip():  # Don't indent empty lines
            lines[i] = extra_indent + lines[i]

    return lines


def _ensure_import(lines: List[str]) -> List[str]:
    """
    Ensure trace_workflow is imported at the top of the file.

    Args:
        lines: Source code lines

    Returns:
        Modified lines with import added if needed
    """
    import_line = "from valiqor_sdk import trace_workflow  # valiqor-auto-import\n"

    # Check if already imported
    for line in lines:
        if "trace_workflow" in line and "import" in line:
            return lines
        if "valiqor-auto-import" in line:
            return lines

    # Find the best place to insert the import
    insert_pos = 0
    in_docstring = False
    docstring_char = None
    in_multiline_import = False  # Track multi-line imports

    for i, line in enumerate(lines):
        stripped = line.strip()

        # Handle module docstrings
        if i == 0 and (stripped.startswith('"""') or stripped.startswith("'''")):
            docstring_char = stripped[:3]
            if stripped.count(docstring_char) >= 2:
                insert_pos = i + 1
            else:
                in_docstring = True
            continue

        if in_docstring:
            if docstring_char and docstring_char in stripped:
                in_docstring = False
                insert_pos = i + 1
            continue

        # Handle multi-line imports (from x import (\n    a,\n    b\n))
        if in_multiline_import:
            insert_pos = i + 1
            if ")" in stripped:
                in_multiline_import = False
            continue

        # Skip comments and empty lines at the top
        if not stripped or stripped.startswith("#"):
            insert_pos = i + 1
            continue

        # Found first real code
        if stripped.startswith("from __future__"):
            insert_pos = i + 1
            continue

        if stripped.startswith("import ") or stripped.startswith("from "):
            insert_pos = i + 1
            # Check if this is a multi-line import (has '(' but no ')')
            if "(" in stripped and ")" not in stripped:
                in_multiline_import = True
            continue

        # Found non-import code, stop here
        break

    lines.insert(insert_pos, import_line)
    return lines


def apply_decorators(
    suggestions: List, create_backup: bool = True, dry_run: bool = False, first_only: bool = False
) -> List[InstrumentationResult]:
    """
    Apply trace_workflow decorators to files based on suggestions.

    Args:
        suggestions: List of WorkflowSuggestion objects from scanner
        create_backup: Whether to create .bak backup files
        dry_run: If True, don't modify files, just report what would be done
        first_only: If True, only instrument the first suggestion per file

    Returns:
        List of InstrumentationResult objects
    """
    results = []

    # Group suggestions by file
    file_suggestions: Dict[str, List] = {}
    for suggestion in suggestions:
        file_path = suggestion.file
        if file_path not in file_suggestions:
            file_suggestions[file_path] = []
        file_suggestions[file_path].append(suggestion)

    for file_path, file_suggs in file_suggestions.items():
        try:
            path = Path(file_path)
            if not path.exists():
                results.append(
                    InstrumentationResult(
                        file_path=file_path,
                        success=False,
                        functions_instrumented=[],
                        error=f"File not found: {file_path}",
                    )
                )
                continue

            source = path.read_text(encoding="utf-8")
            lines = source.splitlines(keepends=True)

            # Ensure last line has newline
            if lines and not lines[-1].endswith("\n"):
                lines[-1] += "\n"

            # Build function map using AST for accurate line numbers
            function_map = _build_function_map(source)

            functions_instrumented = []
            line_offset = 0  # Track insertions to adjust line numbers

            # Sort suggestions by line number (descending) to avoid line offset issues
            # when applying multiple suggestions to same file
            sorted_suggs = sorted(file_suggs, key=lambda s: s.line, reverse=True)

            if first_only:
                sorted_suggs = sorted_suggs[:1]

            for suggestion in sorted_suggs:
                func_name = suggestion.function_name
                workflow_name = suggestion.workflow_name
                suggestion_type = getattr(suggestion, "suggestion_type", "decorator")
                input_variable = getattr(suggestion, "input_variable", None)

                # Handle <module> level suggestions using AST block detection
                if func_name == "<module>":
                    # Find the enclosing block at module level
                    block_info = _find_module_level_block(source, suggestion.line)
                    if block_info is None:
                        continue  # Can't determine block boundaries

                    # Check if already instrumented (check line itself for module-level)
                    if _is_already_instrumented(
                        lines, block_info.start_line, check_line_itself=True
                    ):
                        continue

                    # Apply context manager around the block with input_variable
                    lines = _apply_module_level_context_manager(
                        lines, block_info, workflow_name, input_variable
                    )
                    func_desc = f"<module>:{block_info.block_type}"
                    if input_variable:
                        func_desc += f" (input: {input_variable})"
                    functions_instrumented.append(func_desc)
                    continue

                # Use AST-derived line number if available, otherwise use suggestion
                func_line = function_map.get(func_name, suggestion.line)

                # Adjust for previous insertions (only if processing in ascending order)
                # Since we're processing in descending order, no adjustment needed

                # Check if already instrumented
                if _is_already_instrumented(lines, func_line):
                    continue

                indent = _get_function_indent(lines, func_line)

                if suggestion_type == "context_manager":
                    lines = _apply_context_manager(
                        lines, func_line, workflow_name, function_map, input_variable
                    )
                else:
                    lines = _apply_decorator(
                        lines, func_line, workflow_name, indent, input_variable
                    )

                func_desc = func_name
                if input_variable:
                    func_desc += f" (input: {input_variable})"
                functions_instrumented.append(func_desc)

            if not functions_instrumented:
                results.append(
                    InstrumentationResult(
                        file_path=file_path,
                        success=True,
                        functions_instrumented=[],
                        error="All functions already instrumented or no valid targets",
                    )
                )
                continue

            # Ensure import is present
            lines = _ensure_import(lines)

            # Validate syntax before writing to prevent breaking user code
            modified_source = "".join(lines)
            is_valid, syntax_error = _validate_syntax(modified_source, file_path)

            if not is_valid:
                # Syntax validation failed - skip this file entirely
                results.append(
                    InstrumentationResult(
                        file_path=file_path,
                        success=False,
                        functions_instrumented=[],
                        error=f"Syntax validation failed: {syntax_error}",
                    )
                )
                continue

            if dry_run:
                results.append(
                    InstrumentationResult(
                        file_path=file_path,
                        success=True,
                        functions_instrumented=functions_instrumented,
                        error="DRY RUN - syntax valid, no changes made",
                    )
                )
                continue

            # Create backup if requested
            backup_path = None
            if create_backup:
                backup_path = str(path) + ".bak"
                Path(backup_path).write_text(source, encoding="utf-8")

            # Write modified file (already validated)
            path.write_text(modified_source, encoding="utf-8")

            results.append(
                InstrumentationResult(
                    file_path=file_path,
                    success=True,
                    functions_instrumented=functions_instrumented,
                    backup_path=backup_path,
                )
            )

        except Exception as e:
            results.append(
                InstrumentationResult(
                    file_path=file_path, success=False, functions_instrumented=[], error=str(e)
                )
            )

    return results


def remove_instrumentation(
    file_paths: List[str], dry_run: bool = False
) -> List[InstrumentationResult]:
    """
    Remove valiqor instrumentation from files.

    Removes lines containing 'valiqor-instrumented' or 'valiqor-auto-import' markers.
    Also fixes indentation for code that was wrapped in context managers.

    Args:
        file_paths: List of file paths to process
        dry_run: If True, don't modify files, just report what would be done

    Returns:
        List of InstrumentationResult objects
    """
    results = []

    for file_path in file_paths:
        try:
            path = Path(file_path)
            if not path.exists():
                results.append(
                    InstrumentationResult(
                        file_path=file_path,
                        success=False,
                        functions_instrumented=[],
                        error=f"File not found: {file_path}",
                    )
                )
                continue

            source = path.read_text(encoding="utf-8")
            lines = source.splitlines(keepends=True)

            new_lines = []
            removed_count = 0
            in_context_manager = False
            cm_indent = ""

            i = 0
            while i < len(lines):
                line = lines[i]

                # Check for instrumentation markers
                if "valiqor-instrumented" in line or "valiqor-auto-import" in line:
                    # Check if this is a context manager line
                    if "with trace_workflow" in line and "valiqor-instrumented" in line:
                        # Start tracking context manager indentation
                        in_context_manager = True
                        cm_indent = line[: len(line) - len(line.lstrip())]
                        removed_count += 1
                        i += 1
                        continue

                    # Regular decorator or import line - just skip it
                    removed_count += 1
                    i += 1
                    continue

                # If we're inside a removed context manager, dedent the code
                if in_context_manager:
                    # Check if we've exited the context manager block
                    if line.strip():  # Non-empty line
                        current_indent = line[: len(line) - len(line.lstrip())]
                        if len(current_indent) <= len(cm_indent):
                            # We've exited the context manager
                            in_context_manager = False
                            new_lines.append(line)
                        else:
                            # Still inside - remove one level of indentation
                            if line.startswith(cm_indent + "    "):
                                line = cm_indent + line[len(cm_indent) + 4 :]
                            new_lines.append(line)
                    else:
                        new_lines.append(line)
                else:
                    new_lines.append(line)

                i += 1

            if removed_count == 0:
                results.append(
                    InstrumentationResult(
                        file_path=file_path,
                        success=True,
                        functions_instrumented=[],
                        error="No instrumentation found to remove",
                    )
                )
                continue

            if dry_run:
                results.append(
                    InstrumentationResult(
                        file_path=file_path,
                        success=True,
                        functions_instrumented=[f"Would remove {removed_count} instrumented lines"],
                        error="DRY RUN - no changes made",
                    )
                )
                continue

            # Write modified file
            path.write_text("".join(new_lines), encoding="utf-8")

            results.append(
                InstrumentationResult(
                    file_path=file_path,
                    success=True,
                    functions_instrumented=[f"Removed {removed_count} instrumented lines"],
                )
            )

        except Exception as e:
            results.append(
                InstrumentationResult(
                    file_path=file_path, success=False, functions_instrumented=[], error=str(e)
                )
            )

    return results


def print_results(results: List[InstrumentationResult], action: str = "instrumented") -> None:
    """
    Print instrumentation results in a user-friendly format.

    Args:
        results: List of InstrumentationResult objects
        action: Action description ("instrumented" or "uninstrumented")
    """
    print(f"\n{'='*60}")
    print(f"Instrumentation Results")
    print(f"{'='*60}\n")

    applied_count = 0  # Files where changes were actually made
    skipped_count = 0  # Files already instrumented or no targets
    validation_fail_count = 0  # Files that failed syntax validation
    other_fail_count = 0  # Other failures

    for result in results:
        if result.success:
            # Check if any actual instrumentation was applied
            has_actual_changes = result.functions_instrumented and not (
                result.error and "already instrumented" in result.error.lower()
            )

            if has_actual_changes:
                applied_count += 1
                print(f"✓ {result.file_path}")
                for func in result.functions_instrumented:
                    print(f"    - {func}")
                if result.backup_path:
                    print(f"    Backup: {result.backup_path}")
                if result.error and "DRY RUN" in result.error:
                    print(f"    Note: {result.error}")
            else:
                skipped_count += 1
                print(f"○ {result.file_path}")
                if result.error:
                    print(f"    Note: {result.error}")
        else:
            # Distinguish validation failures from other errors
            is_validation_error = (
                result.error and "syntax validation failed" in result.error.lower()
            )
            if is_validation_error:
                validation_fail_count += 1
                print(f"⚠ {result.file_path}")
                print(f"    Syntax Error: {result.error.replace('Syntax validation failed: ', '')}")
                print(f"    File skipped to prevent breaking code")
            else:
                other_fail_count += 1
                print(f"✗ {result.file_path}")
                print(f"    Error: {result.error}")
        print()

    print(f"{'='*60}")
    # Build summary message
    parts = []
    if applied_count > 0:
        parts.append(f"{applied_count} file{'s' if applied_count != 1 else ''} {action}")
    if skipped_count > 0:
        parts.append(f"{skipped_count} skipped (already {action})")
    if validation_fail_count > 0:
        parts.append(f"{validation_fail_count} skipped (syntax error)")
    if other_fail_count > 0:
        parts.append(f"{other_fail_count} failed")

    if not parts:
        print("Summary: No files processed")
    else:
        print(f"Summary: {', '.join(parts)}")
    print(f"{'='*60}\n")
