"""
Valiqor Security - Security Testing and Red-Teaming Module

Evaluate LLM outputs for safety violations and run adversarial attacks.

Usage:
    from valiqor.security import ValiqorSecurityClient

    client = ValiqorSecurityClient(api_key="vq_xxx", project_name="my-app")

    # Safety audit
    result = client.audit(
        dataset=[
            {"user_input": "How to hack?", "assistant_response": "I cannot help with that."}
        ]
    )

    # Red team simulation
    red_team = client.red_team(
        attack_vectors=["jailbreak", "prompt_injection"],
        attacks_per_vector=5
    )

Or via unified client:
    from valiqor import ValiqorClient

    client = ValiqorClient(api_key="vq_xxx")
    client.security.audit(...)
"""

from typing import TYPE_CHECKING

# =============================================================================
# MODELS (always available - plain Python dataclasses)
# =============================================================================
from valiqor.security.models import (
    AttackVectorInfo,
    AuditBatch,
    AuditBatchItem,
    AuditBatchItemsPage,
    AuthInfo,
    CancelResponse,
    ProjectAttackVector,
    ProjectVulnerability,
    RedTeamAttack,
    RedTeamAttacksPage,
    RedTeamComparison,
    RedTeamResult,
    RedTeamRun,
    SecurityAuditResult,
    SecurityJobStatus,
    UsageInfo,
    VulnerabilityInfo,
)

# Backward compatibility alias
SecurityEvaluationResult = SecurityAuditResult

# =============================================================================
# COMPILED CLIENT LOADER
# =============================================================================
# The client module is compiled for distribution:
# - client.py -> _client_impl.so/.pyd


def _load_security_client():
    """Load the security client (compiled or source)."""
    try:
        # Try compiled extension first (PyPI distribution)
        from valiqor.security import _client_impl

        return _client_impl.ValiqorSecurityClient, getattr(_client_impl, "SecurityJobHandle", None)
    except ImportError:
        try:
            # Fallback to source (development mode)
            from valiqor.security.client import SecurityJobHandle, ValiqorSecurityClient

            return ValiqorSecurityClient, SecurityJobHandle
        except ImportError as e:
            raise ImportError(
                "Security client not available. Install valiqor[security] from PyPI or "
                "ensure you're in the development environment.\n"
                f"Original error: {e}"
            ) from None


# Load the client class
ValiqorSecurityClient, SecurityJobHandle = _load_security_client()

# =============================================================================
# PUBLIC API
# =============================================================================
__all__ = [
    "ValiqorSecurityClient",
    "SecurityJobHandle",
    "SecurityAuditResult",
    "SecurityEvaluationResult",  # Backward compat alias
    "SecurityJobStatus",
    "RedTeamResult",
    "UsageInfo",
    "AuthInfo",
    "VulnerabilityInfo",
    "AttackVectorInfo",
    "CancelResponse",
    # Read-back models
    "AuditBatch",
    "AuditBatchItem",
    "AuditBatchItemsPage",
    "RedTeamRun",
    "RedTeamAttack",
    "RedTeamAttacksPage",
    "RedTeamComparison",
    "ProjectVulnerability",
    "ProjectAttackVector",
]
