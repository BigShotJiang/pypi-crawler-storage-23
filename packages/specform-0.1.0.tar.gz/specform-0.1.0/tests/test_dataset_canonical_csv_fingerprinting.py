from __future__ import annotations

from pathlib import Path

import pytest

from specform import Specform

pd = pytest.importorskip("pandas")


def test_csv_newlines_do_not_change_ds_identity(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv_lf = tmp_path / "data_lf.csv"
    csv_crlf = tmp_path / "data_crlf.csv"

    csv_lf.write_text("a,b\n1,2\n3,4\n", encoding="utf-8")
    csv_crlf.write_bytes(b"a,b\r\n1,2\r\n3,4\r\n")

    first = sf.dataset("lf").add(csv_lf, return_version=True)
    second = sf.dataset("crlf").add(csv_crlf, return_version=True)

    assert first.ds_id == second.ds_id


def test_csv_roundtrip_df_dedupes(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv_path = tmp_path / "roundtrip.csv"
    csv_path.write_text("x,y\n10,20\n30,40\n", encoding="utf-8")

    first = sf.dataset("rt").add(csv_path, return_version=True)
    df = sf.dataset("rt").df()
    second = sf.dataset("rt").add_df(df, return_version=True)

    assert first.ds_id == second.ds_id
