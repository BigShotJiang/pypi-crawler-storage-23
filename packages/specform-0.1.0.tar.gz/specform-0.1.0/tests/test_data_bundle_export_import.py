# tests/test_data_bundle_export_import.py
from __future__ import annotations

from pathlib import Path

from specform import Specform
from specform.core.registry import Registry

from conftest import write_csv


def _make_csv(path: Path, offset: int) -> None:
    header = ["tte", "event", "x1", "x2"]
    rows = [
        [5 + offset, 1, 0.2, 3],
        [7 + offset, 0, 0.1, 2],
        [4 + offset, 1, 0.4, 1],
        [9 + offset, 0, 0.3, 4],
    ]
    write_csv(path, header, rows)


def _ds_blob_dirs(home: Path) -> list[Path]:
    return sorted([p for p in (home / ".specform" / "blobs" / "ds").iterdir() if p.is_dir()])


def test_bundle_export_by_alias_includes_all_versions(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv1 = tmp_path / "v1.csv"
    csv2 = tmp_path / "v2.csv"
    _make_csv(csv1, 0)
    _make_csv(csv2, 10)

    sf.dataset("brca").add(csv1)
    sf.dataset("brca").add(csv2)

    bundle = sf.data_bundle("b1", "brca")
    out_path = tmp_path / "bundle.sfds"
    bundle.export(out_path)

    report = sf.inspect_data_bundle(out_path)
    assert len(report.datasets) == 2
    assert len(report.aliases) == 1
    alias = report.aliases[0]
    assert alias["alias_name"] == "brca"
    assert [event["target_id"] for event in alias["events"]] == [
        event["target_id"] for event in Registry(tmp_path).alias_events("brca", "dataset")
    ]


def test_bundle_import_dedupes_by_fingerprint(tmp_path: Path) -> None:
    home1 = tmp_path / "home1"
    home2 = tmp_path / "home2"
    sf1 = Specform(home=home1)
    csv1 = tmp_path / "data.csv"
    _make_csv(csv1, 0)
    sf1.dataset("brca").add(csv1)
    bundle_path = home1 / "bundle.sfds"
    sf1.data_bundle("b1", "brca").export(bundle_path)

    sf2 = Specform(home=home2)
    sf2.dataset("x").add(csv1)
    before_count = len(_ds_blob_dirs(home2))
    report = sf2.import_data_bundle(bundle_path)
    after_count = len(_ds_blob_dirs(home2))

    assert report.reused_count == 1
    assert report.imported_count == 0
    assert before_count == after_count

    registry = Registry(home2)
    ds_id = registry.get_alias("x", "dataset")
    current_version = sf2.dataset("x").current()
    ds_obj = current_version.raw if current_version else {}
    fingerprint = ds_obj.get("fingerprint")
    assert fingerprint
    assert registry.get_ds_by_fingerprint(fingerprint) == ds_id


def test_bundle_import_alias_rename_on_conflict(tmp_path: Path) -> None:
    home1 = tmp_path / "home1"
    home2 = tmp_path / "home2"
    sf1 = Specform(home=home1)
    csv1 = tmp_path / "v1.csv"
    csv2 = tmp_path / "v2.csv"
    _make_csv(csv1, 0)
    _make_csv(csv2, 10)
    sf1.dataset("brca").add(csv1)
    sf1.dataset("brca").add(csv2)
    bundle_path = home1 / "bundle.sfds"
    sf1.data_bundle("b1", "brca").export(bundle_path)

    sf2 = Specform(home=home2)
    sf2.dataset("brca").add(csv1)
    report = sf2.import_data_bundle(bundle_path, conflict="rename")

    alias_result = report.alias_results[0]
    assert alias_result["status"] == "renamed"
    created_alias = alias_result["created_alias"]
    assert created_alias.startswith("brca__import")
    events = Registry(home2).alias_events(created_alias, "dataset")
    assert len(events) == 2


def test_bundle_import_aliases_none(tmp_path: Path) -> None:
    home1 = tmp_path / "home1"
    home2 = tmp_path / "home2"
    sf1 = Specform(home=home1)
    csv1 = tmp_path / "v1.csv"
    _make_csv(csv1, 0)
    sf1.dataset("brca").add(csv1)
    bundle_path = home1 / "bundle.sfds"
    sf1.data_bundle("b1", "brca").export(bundle_path)

    sf2 = Specform(home=home2)
    sf2.import_data_bundle(bundle_path, aliases="none")
    registry = Registry(home2)
    assert not registry.alias_type_exists("brca", "dataset")


def test_bundle_import_preserves_ordering(tmp_path: Path) -> None:
    home_remote = tmp_path / "remote"
    home_local = tmp_path / "local"
    sf_remote = Specform(home=home_remote)
    csv1 = tmp_path / "r1.csv"
    csv2 = tmp_path / "r2.csv"
    _make_csv(csv1, 0)
    _make_csv(csv2, 10)
    sf_remote.dataset("brca").add(csv1)
    sf_remote.dataset("brca").add(csv2)
    bundle_path = home_remote / "bundle.sfds"
    sf_remote.data_bundle("b1", "brca").export(bundle_path)

    sf_local = Specform(home=home_local)
    sf_local.dataset("brca").add(csv1)

    report = sf_local.import_data_bundle(bundle_path, conflict="rename")
    created_alias = report.alias_results[0]["created_alias"]

    mapping = {row["source_ds_id"]: row["local_ds_id"] for row in report.ds_mapping}
    expected_order = [mapping[event["target_id"]] for event in Registry(home_remote).alias_events("brca", "dataset")]
    actual_order = [event["target_id"] for event in Registry(home_local).alias_events(created_alias, "dataset")]
    assert actual_order == expected_order


def test_bundle_inspect_does_not_import(tmp_path: Path) -> None:
    home1 = tmp_path / "home1"
    sf1 = Specform(home=home1)
    csv1 = tmp_path / "v1.csv"
    _make_csv(csv1, 0)
    sf1.dataset("brca").add(csv1)
    bundle_path = home1 / "bundle.sfds"
    sf1.data_bundle("b1", "brca").export(bundle_path)

    home2 = tmp_path / "home2"
    sf2 = Specform(home=home2)
    sf2.inspect_data_bundle(bundle_path)
    assert _ds_blob_dirs(home2) == []
