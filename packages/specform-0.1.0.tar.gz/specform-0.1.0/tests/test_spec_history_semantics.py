# tests/test_spec_history_semantics.py
from __future__ import annotations

from pathlib import Path

from conftest import (
    ensure_dataset_added,
    ensure_spec_new,
    run_cli,
    specform_home,
    alias_events,
    alias_current_target,
    load_json,
    sample_csv,
    set_spec_bindings,
)


def test_spec_history_increments_only_on_locked_as_creation(tmp_path: Path, sample_csv):
    ensure_dataset_added(tmp_path, sample_csv)
    draft = ensure_spec_new(tmp_path, "cox_primary", sample_csv.alias)

    # First run invalid -> should NOT create spec version
    rc, out = run_cli(["run", "--spec", "cox_primary"], cwd=tmp_path)
    assert rc != 0
    assert alias_events(tmp_path, "cox_primary", "spec") == []

    # Make it valid -> should create spec version 1
    set_spec_bindings(draft)
    rc, out = run_cli(["run", "--spec", "cox_primary"], cwd=tmp_path)
    assert rc == 0, out
    ev = alias_events(tmp_path, "cox_primary", "spec")
    assert len(ev) == 1

    # Run again -> version 2
    rc, out = run_cli(["run", "--spec", "cox_primary"], cwd=tmp_path)
    assert rc == 0, out
    ev2 = alias_events(tmp_path, "cox_primary", "spec")
    assert len(ev2) == 2


def test_locked_as_embeds_resolved_ds_id_not_alias(tmp_path: Path, sample_csv):
    ensure_dataset_added(tmp_path, sample_csv)
    draft = ensure_spec_new(tmp_path, "cox_primary", sample_csv.alias)
    set_spec_bindings(draft)

    rc, out = run_cli(["run", "--spec", "cox_primary"], cwd=tmp_path)
    assert rc == 0, out

    # Determine as_id from run output or registry spec alias pointer.
    as_id = None
    if isinstance(out, dict):
        as_id = out.get("as_id") or out.get("locked_as_id")
    if not as_id:
        as_id = alias_current_target(tmp_path, "cox_primary", "spec")
    assert as_id

    as_path = specform_home(tmp_path) / "blobs" / "as" / f"{as_id}.json"
    assert as_path.exists()
    locked = load_json(as_path)

    assert "ds_id" in locked, locked
    assert locked["ds_id"].startswith("ds_")
    # Must NOT be just the dataset alias name
    assert locked["ds_id"] != sample_csv.alias
