from __future__ import annotations

from pathlib import Path

from specform import Specform, ops


def test_spec_version_run_creates_receipt_only(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path, author="pytest")
    csv_path = tmp_path / "data.csv"
    csv_path.write_text("tte,event,age\n5,1,33\n7,0,44\n", encoding="utf-8")

    sf.dataset("demo").add(csv_path)
    draft = sf.spec("spec1").new(template="coxph", dataset="demo")
    draft.bind(duration_col="tte", event_col="event", covariates=["age"])
    draft.save(force=True)

    first = draft.run()
    history_before = sf.spec("spec1").history().rows
    current_before = sf.spec("spec1").current()
    assert current_before is not None

    second = current_before.run()
    history_after = sf.spec("spec1").history().rows
    current_after = sf.spec("spec1").current()
    assert current_after is not None

    assert first.as_id == second.as_id
    assert current_before.as_id == current_after.as_id
    assert len(history_after) == len(history_before)

    receipts = ops.receipts_for_as(home=sf.home, as_id=first.as_id)
    assert len(receipts) >= 2
