from __future__ import annotations

from pathlib import Path

from specform.core.yamlutil import dump_yaml, load_yaml

from conftest import fetchall, run_cli, sqlite_conn


def test_run_success_creates_locked_as_and_er(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    data.write_text("time,event,age\n1,0,33\n2,1,44\n")
    run_cli(["dataset", "add", str(data), "--name", "demo"], tmp_path)
    run_cli(["spec", "new", "--template", "coxph", "--dataset", "demo", "--name", "spec1"], tmp_path)

    draft_path = tmp_path / ".specform" / "drafts" / "as" / "spec1.yaml"
    draft = load_yaml(draft_path.read_text())
    draft["bindings"]["duration_col"] = "time"
    draft["bindings"]["event_col"] = "event"
    draft["bindings"]["covariates"] = ["age"]
    draft_path.write_text(dump_yaml(draft))

    code, result = run_cli(["run", "--spec", "spec1"], tmp_path)
    assert code == 0
    as_path = tmp_path / ".specform" / "blobs" / "as" / f"{result['as_id']}.json"
    er_path = tmp_path / ".specform" / "blobs" / "er" / f"{result['er_id']}.json"
    assert as_path.exists()
    assert er_path.exists()

    _, history = run_cli(["history", "spec1"], tmp_path)
    assert history[-1]["version"] == 1
    assert history[-1]["receipt_id"] == result["er_id"]

    with sqlite_conn(tmp_path) as conn:
        receipts = fetchall(conn, "SELECT * FROM receipts WHERE as_id=?", (result["as_id"],))
    assert receipts
