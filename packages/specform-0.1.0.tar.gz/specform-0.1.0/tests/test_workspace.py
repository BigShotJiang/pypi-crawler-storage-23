from __future__ import annotations

from pathlib import Path

from conftest import run_cli


def test_workspace_auto_creates(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    data.write_text("time,event\n1,0\n")
    code, _ = run_cli(["dataset", "add", str(data), "--name", "demo"], tmp_path)
    assert code == 0
    assert (tmp_path / ".specform" / "registry.sqlite").exists()
