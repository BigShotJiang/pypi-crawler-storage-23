from __future__ import annotations

from pathlib import Path

from conftest import run_cli


def test_dataset_use_navigation(tmp_path: Path) -> None:
    data_a = tmp_path / "data_a.csv"
    data_b = tmp_path / "data_b.csv"
    data_a.write_text("time,event\n1,0\n")
    data_b.write_text("time,event\n3,1\n")
    run_cli(["dataset", "add", str(data_a), "--name", "demo"], tmp_path)
    run_cli(["dataset", "add", str(data_b), "--name", "demo"], tmp_path)

    code, _ = run_cli(["dataset", "use", "--name", "demo", "--version", "1"], tmp_path)
    assert code == 0

    _, history = run_cli(["history", "demo"], tmp_path)
    assert history[-1]["current"] is True
    assert history[-1]["version"] == 3
