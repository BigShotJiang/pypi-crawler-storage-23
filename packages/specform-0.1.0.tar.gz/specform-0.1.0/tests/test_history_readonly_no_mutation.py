# tests/test_history_readonly_no_mutation.py
from __future__ import annotations

from pathlib import Path

from conftest import alias_events, run_cli, assert_workspace_exists


def test_history_creates_workspace_but_no_alias_events(tmp_path: Path):
    rc, out = run_cli(["history", "nonexistent"], cwd=tmp_path)
    # history on nonexistent might return nonzero; workspace should still exist.
    assert_workspace_exists(tmp_path)

    # No alias events should exist for arbitrary alias.
    ev = alias_events(tmp_path, "nonexistent", "dataset")
    assert ev == []
    ev2 = alias_events(tmp_path, "nonexistent", "spec")
    assert ev2 == []
