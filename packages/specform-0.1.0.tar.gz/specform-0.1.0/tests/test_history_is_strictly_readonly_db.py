from __future__ import annotations

from pathlib import Path

from tests.conftest import run_cli, sqlite_conn, fetchall, sample_csv, ensure_dataset_added


def test_history_does_not_write_alias_events(tmp_path: Path, sample_csv) -> None:
    ensure_dataset_added(tmp_path, sample_csv)

    with sqlite_conn(tmp_path) as conn:
        before = fetchall(conn, "SELECT * FROM alias_events")

    rc, out = run_cli(["history", sample_csv.alias], cwd=tmp_path)
    assert rc == 0, out

    with sqlite_conn(tmp_path) as conn:
        after = fetchall(conn, "SELECT * FROM alias_events")

    assert len(after) == len(before), "history() should not append alias events"
