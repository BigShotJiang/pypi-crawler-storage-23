from __future__ import annotations

import os
from pathlib import Path

import pytest

from tests.conftest import run_cli, run_cli_raw, assert_workspace_exists, specform_home


def _supports_home_flag(tmp_path: Path) -> bool:
    # Try running any command with --home; if CLI errors "unrecognized arguments", return False.
    # We use raw to see stderr.
    cp = run_cli_raw(["history", "nonexistent", "--home", str(tmp_path / "h")], cwd=tmp_path)
    # If argparse rejects --home it will mention "unrecognized arguments: --home"
    if "unrecognized arguments: --home" in (cp.stderr or ""):
        return False
    return True


@pytest.mark.parametrize("mode", ["home_flag", "env_var", "parent_discovery", "default_cwd"])
def test_workspace_resolution_priority(tmp_path: Path, monkeypatch: pytest.MonkeyPatch, mode: str) -> None:
    """
    Verifies workspace location resolution:
      1) --home <path>
      2) SPECFORM_HOME
      3) nearest parent containing .specform/
      4) else create in cwd
    """
    if mode == "home_flag" and not _supports_home_flag(tmp_path):
        pytest.skip("--home flag not supported by CLI yet")

    # Clean env
    monkeypatch.delenv("SPECFORM_HOME", raising=False)

    # Prepare directory layout
    base = tmp_path
    a = base / "a"
    b = a / "b"
    c = b / "c"
    c.mkdir(parents=True)

    if mode == "home_flag":
        custom_home = base / "custom_home"
        rc, out = run_cli(["history", "nope", "--home", str(custom_home)], cwd=c)
        # history on unknown alias may return rc=0 or rc!=0 depending on your CLI; we only assert workspace placement
        assert (custom_home / ".specform").exists() or (custom_home / "registry.sqlite").exists() or custom_home.exists()
        # Prefer the spec: custom_home contains .specform/
        # If you made --home point to specform root directly, allow either.
        if (custom_home / ".specform").exists():
            assert_workspace_exists(custom_home)
        else:
            assert_workspace_exists(custom_home.parent if custom_home.name == ".specform" else custom_home)

    elif mode == "env_var":
        env_home = base / "env_home"
        monkeypatch.setenv("SPECFORM_HOME", str(env_home))
        rc, out = run_cli(["history", "nope"], cwd=c)
        # Similar flexibility as above
        if (env_home / ".specform").exists():
            assert_workspace_exists(env_home)
        else:
            assert_workspace_exists(env_home)

    elif mode == "parent_discovery":
        # Create workspace in parent (a), then run from deeper directory and ensure it uses parent.
        # Ensure parent workspace exists first.
        rc, out = run_cli(["history", "nope"], cwd=a)
        assert_workspace_exists(a)
        # Now run from c; should discover a/.specform not create c/.specform
        rc2, out2 = run_cli(["history", "nope"], cwd=c)
        assert_workspace_exists(a)
        assert not specform_home(c).exists(), "should not create a new workspace in child when parent exists"

    elif mode == "default_cwd":
        rc, out = run_cli(["history", "nope"], cwd=c)
        assert_workspace_exists(c)
