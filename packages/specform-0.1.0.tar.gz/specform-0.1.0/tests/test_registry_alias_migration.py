from __future__ import annotations

import sqlite3

from specform.core.home import ensure_home
from specform.core.registry import Registry


def test_alias_pk_migration(tmp_path):
    home = ensure_home(str(tmp_path))
    db_path = home / ".specform" / "registry.sqlite"

    with sqlite3.connect(db_path) as conn:
        conn.executescript(
            """
            DROP TABLE IF EXISTS aliases;
            CREATE TABLE aliases (
                alias_name TEXT PRIMARY KEY,
                alias_type TEXT CHECK (alias_type IN ('dataset','spec')),
                current_target_id TEXT,
                updated_at TEXT
            );
            """
        )
        conn.execute(
            "INSERT INTO aliases (alias_name, alias_type, current_target_id, updated_at) VALUES (?, ?, ?, ?)",
            ("shared", "dataset", "ds_1", "2024-01-01T00:00:00Z"),
        )

    registry = Registry(home)

    assert registry.get_alias("shared", "dataset") == "ds_1"

    registry.set_alias("shared", "spec", "as_1", "krish", {})

    aliases = {(row["alias_name"], row["alias_type"]) for row in registry.list_aliases()}
    assert ("shared", "dataset") in aliases
    assert ("shared", "spec") in aliases
