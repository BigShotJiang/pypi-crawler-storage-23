from __future__ import annotations

from pathlib import Path

from specform import Specform


def test_sdk_surface_smoke(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path, author="krish")
    csv_path = tmp_path / "brca.csv"
    csv_path.write_text("tte,event,age\n5,1,33\n7,0,44\n", encoding="utf-8")

    snap = sf.dataset("brca").add(csv_path, return_version=True)
    assert snap.ds_id.startswith("ds_")

    draft = sf.spec("cox_primary").new(template="coxph", dataset="brca")
    assert draft.name == "cox_primary"

    draft.bind(time_to_event="tte", event="event", covariates=["age"])
    draft.save(force=True)

    reloaded = sf.draft("cox_primary")
    assert reloaded.bindings.time_to_event == "tte"
    assert reloaded.bindings.event == "event"
    assert reloaded.bindings.covariates == ["age"]

    drafts = sf.drafts()
    assert any(row.get("name") == "cox_primary" for row in drafts)

    history = sf.dataset("brca").history()
    assert history.rows
