from __future__ import annotations

from pathlib import Path

from conftest import run_cli


def test_dataset_add_reuse_same_fingerprint(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    data.write_text("time,event\n1,0\n")
    _, first = run_cli(["dataset", "add", str(data), "--name", "demo"], tmp_path)
    _, second = run_cli(["dataset", "add", str(data), "--name", "demo"], tmp_path)
    assert first["ds_id"] == second["ds_id"]

    _, history = run_cli(["history", "demo"], tmp_path)
    assert len(history) == 2
