from __future__ import annotations

from pathlib import Path

import importlib.util
import pytest

from conftest import SampleDataset, ensure_dataset_added, load_json, run_cli, write_csv
from specform import ops

missing_deps = [
    dep for dep in ("pandas", "lifelines") if importlib.util.find_spec(dep) is None
]
pytestmark = pytest.mark.skipif(
    missing_deps,
    reason=f"Missing dependencies for CoxPH tests: {', '.join(missing_deps)}",
)


def _make_dataset(tmp_path: Path) -> tuple[Path, str]:
    path = tmp_path / "coxph.csv"
    header = ["tte", "event", "x1", "x2", "weights", "group", "group2", "lower", "upper"]
    rows = [
        [5, 1, 0.2, 3, 1.0, "a", "x", 5, 5],
        [7, 0, 0.1, 2, 0.8, "a", "y", 2, 7],
        [4, 1, 0.4, 1, 1.2, "b", "x", 4, 4],
        [9, 0, 0.3, 4, 0.9, "b", "y", 3, 9],
    ]
    write_csv(path, header, rows)
    return path, "coxph_ds"


def test_validation_baseline_estimation_methods(tmp_path: Path) -> None:
    path, alias = _make_dataset(tmp_path)
    code, _ = run_cli(["dataset", "add", str(path), "--name", alias], tmp_path)
    assert code == 0

    base_draft = {
        "spec_name": "spec1",
        "template": "coxph.right",
        "template_id": "survival.coxph.right.v1",
        "dataset_ref": alias,
        "dataset_pin": None,
        "bindings": {"time_to_event": "tte", "event": "event", "covariates": ["x1"]},
        "params": {},
        "outputs": {},
    }

    draft = dict(base_draft)
    draft["params"] = {"init": {"baseline_estimation_method": "bad"}}
    issues = ops.validate_draft(home=tmp_path, draft=draft)
    assert any("baseline_estimation_method" in issue for issue in issues)

    draft = dict(base_draft)
    draft["params"] = {"init": {"baseline_estimation_method": "spline"}}
    issues = ops.validate_draft(home=tmp_path, draft=draft)
    assert any("n_baseline_knots" in issue or "knots" in issue for issue in issues)

    draft = dict(base_draft)
    draft["params"] = {"init": {"baseline_estimation_method": "piecewise"}}
    issues = ops.validate_draft(home=tmp_path, draft=draft)
    assert any("breakpoints" in issue for issue in issues)


def test_executor_params_and_outputs(tmp_path: Path) -> None:
    path, alias = _make_dataset(tmp_path)
    ensure_dataset_added(tmp_path, SampleDataset(path=path, alias=alias, header=[]))

    result = ops.spec_run_inline(
        home=tmp_path,
        spec_alias="coxph_spec",
        template="coxph.right",
        dataset=alias,
        bindings={
            "time_to_event": "tte",
            "event": "event",
            "covariates": ["x1", "x2"],
            "weights_col": "weights",
            "strata": ["group"],
        },
        params={
            "init": {"penalizer": "0.5", "l1_ratio": "0.2"},
            "fit": {"robust": True},
        },
        outputs={},
    )
    receipt = ops.receipt_get(home=tmp_path, receipt_id=result["receipt_id"])
    run_dir = tmp_path / ".specform" / "runs" / receipt["run_id"]
    summary = load_json(run_dir / receipt["artifacts"]["summary_json"])

    assert summary["status"] == "success"
    assert summary["penalizer"] == 0.5
    assert summary["l1_ratio"] == 0.2
    assert summary["robust"] is True
    assert summary["weights_col"] == "weights"
    assert summary["strata_used"] == ["group"]

    coeff_path = run_dir / receipt["artifacts"]["coefficients_csv"]
    assert coeff_path.exists()

    baseline_path = run_dir / receipt["artifacts"]["baseline_hazard_csv"]
    cumulative_path = run_dir / receipt["artifacts"]["baseline_cumulative_hazard_csv"]
    survival_path = run_dir / receipt["artifacts"]["baseline_survival_csv"]
    diagnostics_path = run_dir / receipt["artifacts"]["diagnostics_json"]
    assert baseline_path.exists()
    assert cumulative_path.exists()
    assert survival_path.exists()
    assert diagnostics_path.exists()


def test_mode_runs_and_interval_validation(tmp_path: Path) -> None:
    path, alias = _make_dataset(tmp_path)
    ensure_dataset_added(tmp_path, SampleDataset(path=path, alias=alias, header=[]))

    right = ops.spec_run_inline(
        home=tmp_path,
        spec_alias="coxph_right",
        template="coxph.right",
        dataset=alias,
        bindings={"time_to_event": "tte", "event": "event", "covariates": ["x1", "x2"]},
    )
    right_receipt = ops.receipt_get(home=tmp_path, receipt_id=right["receipt_id"])
    right_summary = load_json(tmp_path / ".specform" / "runs" / right_receipt["run_id"] / right_receipt["artifacts"]["summary_json"])
    assert right_summary["fit_mode"] == "right"

    left = ops.spec_run_inline(
        home=tmp_path,
        spec_alias="coxph_left",
        template="coxph.left",
        dataset=alias,
        bindings={"time_to_event": "tte", "event": "event", "covariates": ["x1", "x2"]},
        params={"init": {"baseline_estimation_method": "spline", "n_baseline_knots": 3}},
    )
    left_receipt = ops.receipt_get(home=tmp_path, receipt_id=left["receipt_id"])
    left_summary = load_json(tmp_path / ".specform" / "runs" / left_receipt["run_id"] / left_receipt["artifacts"]["summary_json"])
    assert left_summary["fit_mode"] == "left"

    interval = ops.spec_run_inline(
        home=tmp_path,
        spec_alias="coxph_interval",
        template="coxph.interval",
        dataset=alias,
        bindings={
            "event": "event",
            "covariates": ["x1", "x2"],
            "lower_bound_col": "lower",
            "upper_bound_col": "upper",
        },
        params={"init": {"baseline_estimation_method": "spline", "n_baseline_knots": 3}},
    )
    interval_receipt = ops.receipt_get(home=tmp_path, receipt_id=interval["receipt_id"])
    interval_summary = load_json(
        tmp_path / ".specform" / "runs" / interval_receipt["run_id"] / interval_receipt["artifacts"]["summary_json"]
    )
    assert interval_summary["fit_mode"] == "interval"

    draft = {
        "spec_name": "interval_spec",
        "template": "coxph.interval",
        "template_id": "survival.coxph.interval.v1",
        "dataset_ref": alias,
        "dataset_pin": None,
        "bindings": {"covariates": ["x1", "x2"]},
        "params": {},
        "outputs": {},
    }
    issues = ops.validate_draft(home=tmp_path, draft=draft)
    assert any("lower_bound_col" in issue for issue in issues)
    assert any("upper_bound_col" in issue for issue in issues)


def test_strata_precedence_and_legacy_alias(tmp_path: Path) -> None:
    path, alias = _make_dataset(tmp_path)
    ensure_dataset_added(tmp_path, SampleDataset(path=path, alias=alias, header=[]))

    result = ops.spec_run_inline(
        home=tmp_path,
        spec_alias="coxph_strata",
        template="coxph.right",
        dataset=alias,
        bindings={"time_to_event": "tte", "event": "event", "covariates": ["x1", "x2"], "strata": ["group"]},
        params={
            "init": {"strata": ["group"], "penalizer": "0.1"},
            "fit": {"strata": ["group2"]},
        },
    )
    receipt = ops.receipt_get(home=tmp_path, receipt_id=result["receipt_id"])
    summary = load_json(tmp_path / ".specform" / "runs" / receipt["run_id"] / receipt["artifacts"]["summary_json"])
    assert summary["strata_used"] == ["group2"]

    legacy = ops.spec_run_inline(
        home=tmp_path,
        spec_alias="coxph_legacy",
        template="coxph",
        dataset=alias,
        bindings={"time_to_event": "tte", "event": "event", "covariates": ["x1", "x2"]},
    )
    legacy_receipt = ops.receipt_get(home=tmp_path, receipt_id=legacy["receipt_id"])
    legacy_summary = load_json(
        tmp_path / ".specform" / "runs" / legacy_receipt["run_id"] / legacy_receipt["artifacts"]["summary_json"]
    )
    assert legacy_summary["template_id"] == "survival.coxph.v1"
    assert legacy_summary["fit_mode"] == "right"


def test_formula_support(tmp_path: Path) -> None:
    path, alias = _make_dataset(tmp_path)
    ensure_dataset_added(tmp_path, SampleDataset(path=path, alias=alias, header=[]))

    result = ops.spec_run_inline(
        home=tmp_path,
        spec_alias="coxph_formula",
        template="coxph.right",
        dataset=alias,
        bindings={"time_to_event": "tte", "event": "event"},
        params={"fit": {"formula": "x1 + x2"}},
    )
    receipt = ops.receipt_get(home=tmp_path, receipt_id=result["receipt_id"])
    summary = load_json(tmp_path / ".specform" / "runs" / receipt["run_id"] / receipt["artifacts"]["summary_json"])
    assert summary["status"] == "success"
