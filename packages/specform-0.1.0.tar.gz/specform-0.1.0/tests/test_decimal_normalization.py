# tests/test_decimal_normalization.py
from __future__ import annotations

import json

from specform.core.canonical import canonical_dumps


def test_decimal_string_normalization_equivalent_strings():
    """
    Kernel rule: no floats; decimals are stored as strings in canonical JSON.
    We validate that your canonicalization produces identical bytes for semantically-equal decimals,
    IF your implementation normalizes decimal strings (recommended).

    If you do not normalize, this test will fail — either implement normalization or delete this test.
    """
    obj1 = {"penalizer": "0.10"}
    obj2 = {"penalizer": "0.1"}

    b1 = canonical_dumps(obj1)
    b2 = canonical_dumps(obj2)

    # If you normalize decimals, these should be identical:
    assert b1 == b2, f"Expected normalized decimals to canonicalize equally.\n{b1}\n{b2}"


def test_rejects_float_values():
    """
    Canonicalization should refuse floats to keep hashing stable.
    """
    obj = {"penalizer": 0.1}
    try:
        canonical_dumps(obj)
    except Exception:
        return
    raise AssertionError("canonical_dumps should reject float values (use decimal strings).")
