from __future__ import annotations

import json
from pathlib import Path

import pytest

from conftest import alias_current_target, write_csv
from specform.core.home import ensure_home
from specform.ops.datasets import dataset_add
from specform.ops.packs import export_pack, import_pack


def _lineage_root(home: Path) -> Path:
    return home / ".specform" / "lineage" / "events"


def _load_events(home: Path, event_type: str) -> list[dict]:
    event_dir = _lineage_root(home) / event_type
    if not event_dir.exists():
        return []
    events = []
    for path in sorted(event_dir.glob("*.json")):
        events.append(json.loads(path.read_text(encoding="utf-8")))
    return events


def test_dataset_add_creates_ds_seen_event(tmp_path: Path) -> None:
    ensure_home(str(tmp_path))
    data = tmp_path / "data.csv"
    write_csv(data, ["time", "event"], [[1, 0], [2, 1]])
    result = dataset_add(home=tmp_path, path=data, alias="demo", note="hello", author="tester")

    events = _load_events(tmp_path, "ds_seen")
    assert len(events) == 1
    event = events[0]

    assert event["schema_version"] == 1
    assert event["event_type"] == "ds_seen"
    assert event["created_at"]
    assert event["author"] == "tester"

    payload = event["payload"]
    assert payload["ds_id"] == result["ds_id"]
    assert payload["alias"] == "demo"
    assert payload["reused"] is False
    assert payload["how"] == "dataset_add"
    assert payload["fingerprint"].startswith("sha256:")
    assert payload["fingerprint_algo"]
    assert payload["note"] == "hello"
    assert "data" not in payload
    assert "rows" not in payload
    assert "values" not in payload

    event_path = sorted((_lineage_root(tmp_path) / "ds_seen").glob("*.json"))[0]
    assert event_path.stem == event["event_id"]


def test_dataset_add_dedupe_reuse_logs_lineage(tmp_path: Path, sample_csv) -> None:
    ensure_home(str(tmp_path))
    first = dataset_add(home=tmp_path, path=sample_csv.path, alias="alpha", author="tester")
    second = dataset_add(home=tmp_path, path=sample_csv.path, alias="beta", author="tester")

    assert first["ds_id"] == second["ds_id"]
    assert alias_current_target(tmp_path, "alpha", "dataset") == first["ds_id"]
    assert alias_current_target(tmp_path, "beta", "dataset") == first["ds_id"]

    events = _load_events(tmp_path, "ds_seen")
    assert len(events) == 2
    assert events[1]["payload"]["how"] == "dedupe_reuse"
    assert events[1]["payload"]["reused"] is True
    assert events[1]["payload"]["ds_id"] == first["ds_id"]
    assert events[1]["payload"]["alias"] == "beta"

    assert "note" not in events[1]["payload"]


def test_dataset_add_lineage_best_effort(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    ensure_home(str(tmp_path))
    data = tmp_path / "data.csv"
    write_csv(data, ["time", "event"], [[1, 0], [2, 1]])

    def _fail_write(*_args, **_kwargs):
        raise IOError("boom")

    from specform.core import lineage as lineage_module

    monkeypatch.setattr(lineage_module.LineageStore, "write_event", _fail_write)
    result = dataset_add(home=tmp_path, path=data, alias="demo", author="tester")

    assert result["ds_id"].startswith("ds_")
    assert alias_current_target(tmp_path, "demo", "dataset") == result["ds_id"]
    assert (tmp_path / ".specform" / "blobs" / "ds" / result["ds_id"] / "ds.json").exists()

    assert _load_events(tmp_path, "ds_seen") == []


def test_lineage_write_cleanup_on_error(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    ensure_home(str(tmp_path))
    data = tmp_path / "data.csv"
    write_csv(data, ["time", "event"], [[1, 0], [2, 1]])

    from specform.core import lineage as lineage_module

    def _fail_replace(*_args, **_kwargs):
        raise OSError("replace failed")

    monkeypatch.setattr(lineage_module.os, "replace", _fail_replace)

    result = dataset_add(home=tmp_path, path=data, alias="demo", author="tester")
    assert result["ds_id"].startswith("ds_")

    lineage_dir = _lineage_root(tmp_path) / "ds_seen"
    assert lineage_dir.exists()
    assert not list(lineage_dir.glob("*.tmp"))


def test_lineage_atomic_write_leaves_no_tmp(tmp_path: Path) -> None:
    ensure_home(str(tmp_path))
    data = tmp_path / "data.csv"
    write_csv(data, ["time", "event"], [[1, 0], [2, 1]])
    dataset_add(home=tmp_path, path=data, alias="demo", author="tester")

    lineage_dir = _lineage_root(tmp_path) / "ds_seen"
    assert lineage_dir.exists()
    assert not list(lineage_dir.glob("*.tmp"))


def test_lineage_directories_created(tmp_path: Path) -> None:
    ensure_home(str(tmp_path))
    data = tmp_path / "data.csv"
    write_csv(data, ["time", "event"], [[1, 0], [2, 1]])
    dataset_add(home=tmp_path, path=data, alias="demo", author="tester")

    events_root = _lineage_root(tmp_path)
    assert (events_root / "ds_seen").exists()
    assert (events_root / "ds_edge").exists()
    assert (events_root / "import_pack").exists()


@pytest.mark.slow
def test_import_pack_emits_lineage_events(tmp_path: Path, sample_csv) -> None:
    ensure_home(str(tmp_path))
    dataset_add(home=tmp_path, path=sample_csv.path, alias=sample_csv.alias, author="tester")

    pack_path = tmp_path / "bundle.sfpack"
    export_pack(home=tmp_path, out=pack_path, alias=sample_csv.alias)
    assert pack_path.exists()

    dest = tmp_path / "dest"
    dest.mkdir()
    ensure_home(str(dest))

    import_pack(home=dest, pack=pack_path)
    ds_events = _load_events(dest, "ds_seen")
    pack_events = _load_events(dest, "import_pack")
    assert len(pack_events) == 1
    assert len(ds_events) >= 1
    assert any(event["payload"]["reused"] is False for event in ds_events)

    import_pack(home=dest, pack=pack_path)
    ds_events_after = _load_events(dest, "ds_seen")
    pack_events_after = _load_events(dest, "import_pack")
    assert len(pack_events_after) == 2
    assert len(ds_events_after) >= len(ds_events) + 1
    assert any(event["payload"]["reused"] is True for event in ds_events_after)

    payload = pack_events_after[-1]["payload"]
    assert payload["source"] == "file"
    assert payload["import_mode"] == "copy"
    assert isinstance(payload["imported_ds_ids"], list)
    assert isinstance(payload["imported_aliases"], list)

    pack_event = pack_events_after[-1]
    assert pack_event["schema_version"] == 1
    assert pack_event["event_type"] == "import_pack"
    assert pack_event["event_id"]
    assert pack_event["created_at"]


def test_lineage_payload_phi_safe(tmp_path: Path) -> None:
    ensure_home(str(tmp_path))
    data = tmp_path / "data.csv"
    write_csv(data, ["time", "event"], [[1, 0], [2, 1]])
    dataset_add(home=tmp_path, path=data, alias="demo", author="tester")

    event = _load_events(tmp_path, "ds_seen")[0]
    payload = event["payload"]
    forbidden_keys = {"data", "rows", "values", "content", "bytes", "records"}
    assert not forbidden_keys.intersection(payload.keys())
    assert payload["fingerprint"].startswith("sha256:")
