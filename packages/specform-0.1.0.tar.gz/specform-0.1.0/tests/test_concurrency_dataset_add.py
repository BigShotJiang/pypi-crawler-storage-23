from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

from tests.conftest import ROOT, write_csv, specform_home, sqlite_conn, fetchall


@pytest.mark.slow
def test_concurrent_dataset_adds_do_not_corrupt_registry(tmp_path: Path) -> None:
    """
    Spawns multiple processes that all add datasets to the same alias.
    Requires your CLI to be robust under concurrent writes (locking / sqlite retries).
    """
    # Prepare small CSVs
    header = ["tte", "event", "x1"]
    paths = []
    for i in range(5):
        p = tmp_path / f"data_{i}.csv"
        rows = [[5 + i, i % 2, 0.1 * i], [6 + i, (i + 1) % 2, 0.2 * i]]
        write_csv(p, header, rows)
        paths.append(p)

    env = os.environ.copy()
    env["PYTHONPATH"] = os.pathsep.join([str(ROOT), env.get("PYTHONPATH", "")]).strip(os.pathsep)

    procs = []
    for i, p in enumerate(paths):
        cmd = [sys.executable, "-m", "specform.cli", "dataset", "add", str(p), "--name", "brca", "--author", f"p{i}", "--json"]
        procs.append(subprocess.Popen(cmd, cwd=tmp_path, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True))

    outs = []
    for pr in procs:
        out, err = pr.communicate(timeout=60)
        outs.append((pr.returncode, out, err))

    # We don't require all to succeed if your code serializes, but we do require "no corruption" and at least 1 success.
    assert any(rc == 0 for rc, _, _ in outs), f"no successful adds. results={outs}"

    # Registry should be readable; alias_events should exist; current pointer should reference a ds_*
    home = specform_home(tmp_path)
    assert home.exists(), "workspace missing after concurrent adds"
    with sqlite_conn(tmp_path) as conn:
        rows = fetchall(conn, "SELECT * FROM alias_events WHERE alias_name=? AND alias_type='dataset'", ("brca",))
        assert len(rows) >= 1
        cur = fetchall(conn, "SELECT current_target_id FROM aliases WHERE alias_name=? AND alias_type='dataset'", ("brca",))
        assert cur and cur[0]["current_target_id"].startswith("ds_")
