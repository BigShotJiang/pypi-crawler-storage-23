from __future__ import annotations

from pathlib import Path

from specform.core.yamlutil import dump_yaml, load_yaml

from conftest import run_cli


def test_run_creates_run_dir(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    data.write_text("time,event,age\n1,0,33\n2,1,44\n")
    run_cli(["dataset", "add", str(data), "--name", "demo"], tmp_path)
    run_cli(["spec", "new", "--template", "coxph", "--dataset", "demo", "--name", "spec1"], tmp_path)

    draft_path = tmp_path / ".specform" / "drafts" / "as" / "spec1.yaml"
    draft = load_yaml(draft_path.read_text())
    draft["bindings"]["time_to_event"] = "time"
    draft["bindings"]["event"] = "event"
    draft["bindings"]["covariates"] = ["age"]
    draft_path.write_text(dump_yaml(draft))

    _, result = run_cli(["run", "--spec", "spec1"], tmp_path)
    run_dir = tmp_path / ".specform" / "runs" / result["run_id"]
    assert run_dir.exists()
