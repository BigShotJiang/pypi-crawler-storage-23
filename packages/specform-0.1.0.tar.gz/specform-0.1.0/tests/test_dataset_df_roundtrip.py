from __future__ import annotations

import json
from pathlib import Path

import pytest

pd = pytest.importorskip("pandas")

from specform import Specform
from specform.core.store import require_ds_data
from tests.conftest import alias_events


def test_dataset_df_loads_current(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv_path = tmp_path / "brca.csv"
    csv_path.write_text("tte,event,age\n5,1,33\n7,0,44\n", encoding="utf-8")

    snapshot = sf.dataset("brca").add(csv_path, return_version=True)
    df = sf.dataset("brca").df()
    assert list(df.columns) == ["tte", "event", "age"]
    assert df.shape == (2, 3)

    data_path = require_ds_data(tmp_path, snapshot.ds_id)
    expected = pd.read_csv(data_path)
    pd.testing.assert_frame_equal(df, expected)


def test_dataset_add_df_creates_new_version_and_pointer_moves(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv_path = tmp_path / "brca.csv"
    csv_path.write_text("tte,event,age\n5,1,33\n7,0,44\n", encoding="utf-8")

    first = sf.dataset("brca").add(csv_path, return_version=True)
    df = sf.dataset("brca").df()
    df = df[df["event"] == 1].reset_index(drop=True)

    history_before = sf.dataset("brca").history().rows
    second = sf.dataset("brca").add_df(df, note="filtered", return_version=True)
    history_after = sf.dataset("brca").history().rows
    assert len(history_after) == len(history_before) + 1
    assert second.ds_id != first.ds_id

    events = alias_events(tmp_path, "brca", "dataset")
    meta = json.loads(events[-1]["meta_json"])
    assert meta.get("note") == "filtered"


def test_dataset_add_df_dedupes_when_identical(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv_path = tmp_path / "brca.csv"
    csv_path.write_text("tte,event,age\n5,1,33\n7,0,44\n", encoding="utf-8")

    first = sf.dataset("brca").add(csv_path, return_version=True)
    df = sf.dataset("brca").df()
    history_before = sf.dataset("brca").history().rows

    second = sf.dataset("brca").add_df(df, note="same-data", return_version=True)
    history_after = sf.dataset("brca").history().rows

    assert second.ds_id == first.ds_id
    assert len(history_after) == len(history_before) + 1
