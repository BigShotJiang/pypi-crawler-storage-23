from __future__ import annotations

from pathlib import Path

import pytest

from specform import Specform
from specform.sdk.dataset import DatasetRef, DatasetVersion

pd = pytest.importorskip("pandas")


def _write_csv(path: Path, rows: list[list[int]]) -> None:
    lines = ["a,b"]
    for row in rows:
        lines.append(f"{row[0]},{row[1]}")
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def test_add_returns_dao_by_default(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv_path = tmp_path / "data.csv"
    _write_csv(csv_path, [[1, 10]])

    brca = sf.dataset("brca").add(csv_path)
    assert isinstance(brca, DatasetRef)


def test_add_version_returns_version(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv_path = tmp_path / "data.csv"
    _write_csv(csv_path, [[1, 10]])

    v = sf.dataset("brca").add(csv_path, return_version=True)
    assert isinstance(v, DatasetVersion)
    assert v.ds_id.startswith("ds_")


def test_df_selector(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv1 = tmp_path / "data1.csv"
    csv2 = tmp_path / "data2.csv"
    _write_csv(csv1, [[1, 10]])
    _write_csv(csv2, [[1, 10], [2, 20]])

    brca = sf.dataset("brca")
    brca.add(csv1)
    brca.add(csv2)

    df1 = brca.df(1)
    df_latest = brca.df("latest")
    assert df1.shape != df_latest.shape


def test_v_shorthand(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv1 = tmp_path / "data1.csv"
    csv2 = tmp_path / "data2.csv"
    _write_csv(csv1, [[1, 10]])
    _write_csv(csv2, [[1, 10], [2, 20]])

    brca = sf.dataset("brca")
    brca.add(csv1)
    brca.add(csv2)

    assert brca.v(1).ds_id == brca.version(1).ds_id
