from __future__ import annotations

from pathlib import Path

from specform import Specform, ops
from specform.core.store import load_as
from specform.engine.runner import run_executable


def _write_brca_csv(path: Path) -> None:
    path.write_text(
        "tte,event,age,bmi,sex,stage\n"
        "5,1,55,22.1,F,2\n"
        "7,0,63,27.3,M,1\n"
        "4,1,49,19.5,F,3\n"
        "9,0,52,24.0,M,2\n",
        encoding="utf-8",
    )


def test_spec_run_inline_one_liner(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path, author="pytest")
    csv_path = tmp_path / "brca.csv"
    _write_brca_csv(csv_path)

    brca = sf.dataset("brca").add(csv_path)
    cox = sf.spec("cox_primary")
    run = cox.run(
        template="coxph",
        dataset=brca,
        time="tte",
        event="event",
        covariates=["age", "bmi", "sex"],
    )

    assert run.status == "success"
    assert cox.current() is not None

    history = cox.history().rows
    assert len(history) == 1
    row = history[0]
    assert row["ds_id"] == run.ds_id
    assert row["template_id"] == "survival.coxph.v1"
    assert row["receipt_id"] == run.receipt_id
    assert row["status"] == run.status


def test_spec_rerun_overrides_create_new_as_version(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path, author="pytest")
    csv_path = tmp_path / "brca.csv"
    _write_brca_csv(csv_path)

    brca = sf.dataset("brca").add(csv_path)
    cox = sf.spec("cox_primary")
    run1 = cox.run(
        template="coxph",
        dataset=brca,
        time="tte",
        event="event",
        covariates=["age", "bmi", "sex"],
    )
    run2 = cox.rerun(covariates=["age", "bmi"], note="drop sex")

    history = cox.history().rows
    assert len(history) == 2
    assert history[-1]["current"] is True
    assert history[-1]["as_id"] != history[0]["as_id"]
    assert history[-1]["ds_id"] == run1.ds_id
    assert run2.ds_id == run1.ds_id


def test_spec_use_and_v_mirror_ds(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path, author="pytest")
    csv_path = tmp_path / "brca.csv"
    _write_brca_csv(csv_path)

    brca = sf.dataset("brca").add(csv_path)
    cox = sf.spec("cox_primary")
    cox.run(
        template="coxph",
        dataset=brca,
        time="tte",
        event="event",
        covariates=["age", "bmi", "sex"],
    )
    cox.rerun(covariates=["age", "bmi"], note="drop sex")

    v1 = cox.v(1)
    v2 = cox.v(2)
    assert v1.as_id != v2.as_id

    cox.use(1)
    assert cox.current() is not None
    assert cox.current().as_id == v1.as_id


def test_spec_open_and_draft_run_still_works(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path, author="pytest")
    csv_path = tmp_path / "brca.csv"
    _write_brca_csv(csv_path)

    brca = sf.dataset("brca").add(csv_path)
    cox = sf.spec("cox_primary")
    cox.run(
        template="coxph",
        dataset=brca,
        time="tte",
        event="event",
        covariates=["age", "bmi", "sex"],
    )

    draft = cox.open(version=1, name="cox_edit")
    draft.bind(covariates=["age"])
    draft.save(force=True)
    draft.run()

    assert len(cox.history().rows) == 1
    assert len(sf.spec("cox_edit").history().rows) == 1


def test_executor_registration_dispatch(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path, author="pytest")
    csv_path = tmp_path / "brca.csv"
    _write_brca_csv(csv_path)

    brca = sf.dataset("brca").add(csv_path)
    cox = sf.spec("cox_primary")
    run = cox.run(
        template="coxph",
        dataset=brca,
        time="tte",
        event="event",
        covariates=["age", "bmi", "sex"],
    )

    locked = load_as(sf.home, run.as_id)
    run_dir = tmp_path / "manual_run"
    manifest = run_executable(locked, run_dir)
    assert "summary_json" in manifest


def test_backward_compat_time_to_event_binding(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path, author="pytest")
    csv_path = tmp_path / "brca.csv"
    _write_brca_csv(csv_path)

    sf.dataset("brca").add(csv_path)
    result = ops.spec_run_inline(
        home=sf.home,
        spec_alias="cox_primary",
        template="coxph",
        dataset="brca",
        bindings={"time_to_event": "tte", "event": "event", "covariates": ["age", "bmi", "sex"]},
    )
    assert result["status"] == "success"
