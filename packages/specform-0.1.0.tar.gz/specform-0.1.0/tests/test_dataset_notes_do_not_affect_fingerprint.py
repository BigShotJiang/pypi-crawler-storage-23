from __future__ import annotations

from copy import deepcopy
from pathlib import Path

from specform import Specform
from specform.core.store import compute_object_hash, load_ds


def test_note_does_not_change_fingerprint_for_same_bytes(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    path1 = tmp_path / "data1.csv"
    path2 = tmp_path / "data2.csv"
    payload = "tte,event,age\n5,1,33\n7,0,44\n"
    path1.write_text(payload, encoding="utf-8")
    path2.write_text(payload, encoding="utf-8")

    ds1 = sf.dataset("brca").add(path1, note="note A", return_version=True)
    ds2 = sf.dataset("brca_alt").add(path2, note="note B", return_version=True)
    assert ds1.ds_id == ds2.ds_id


def test_alias_does_not_change_fingerprint_for_same_bytes(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv_path = tmp_path / "data.csv"
    csv_path.write_text("tte,event,age\n5,1,33\n7,0,44\n", encoding="utf-8")

    ds1 = sf.dataset("brca").add(csv_path, return_version=True)
    ds2 = sf.dataset("brca_alt").add(csv_path, return_version=True)
    assert ds1.ds_id == ds2.ds_id


def test_ds_metadata_note_not_in_fingerprint(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv_path = tmp_path / "data.csv"
    csv_path.write_text("tte,event,age\n5,1,33\n7,0,44\n", encoding="utf-8")

    ds = sf.dataset("brca").add(csv_path, note="original", return_version=True)
    ds_obj = load_ds(tmp_path, ds.ds_id)
    ds_with_other_note = deepcopy(ds_obj)
    ds_with_other_note["note"] = "different"

    assert compute_object_hash(ds_obj) == compute_object_hash(ds_with_other_note)
