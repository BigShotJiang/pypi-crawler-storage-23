from __future__ import annotations

import ast
from pathlib import Path


def _forbidden_import(module: str | None, level: int) -> str | None:
    if not module:
        return None
    root = module.split(".")[0]
    if root == "rich":
        return module
    if root == "specform" and (
        module == "specform.cli"
        or module.startswith("specform.cli.")
        or module == "specform.api"
        or module.startswith("specform.api.")
    ):
        return module
    if level > 0 and (module == "cli" or module.startswith("cli.") or module == "api" or module.startswith("api.")):
        return f"relative:{module}"
    return None


def test_ops_modules_do_not_import_cli_or_rich() -> None:
    ops_dir = Path("specform/ops")
    assert ops_dir.exists(), "specform/ops package is missing"
    violations: list[str] = []

    for path in sorted(ops_dir.glob("*.py")):
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    forbidden = _forbidden_import(alias.name, 0)
                    if forbidden:
                        violations.append(f"{path}: import {forbidden}")
            elif isinstance(node, ast.ImportFrom):
                forbidden = _forbidden_import(node.module, node.level)
                if forbidden:
                    violations.append(f"{path}: from {forbidden} import ...")

    assert not violations, "Forbidden imports found:\n" + "\n".join(violations)
