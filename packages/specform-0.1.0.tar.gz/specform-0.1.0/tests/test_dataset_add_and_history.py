from __future__ import annotations

from pathlib import Path

from conftest import run_cli


def test_dataset_add_and_history(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    data.write_text("time,event\n1,0\n2,1\n")
    code, result = run_cli(["dataset", "add", str(data), "--name", "demo"], tmp_path)
    assert code == 0
    assert result["ds_id"].startswith("ds_")

    code, history = run_cli(["history", "demo"], tmp_path)
    assert code == 0
    assert history[0]["version"] == 1
    assert history[0]["current"] is True
