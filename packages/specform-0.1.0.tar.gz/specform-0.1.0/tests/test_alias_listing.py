from __future__ import annotations

from specform import Specform, ops
from specform.core.home import ensure_home
from specform.core.registry import Registry


def test_alias_listing_via_ops(tmp_path, sample_csv):
    home = ensure_home(str(tmp_path))

    ops.dataset_add(home=home, path=sample_csv.path, alias=sample_csv.alias)
    dataset_aliases = ops.dataset_aliases_list(home=home)

    assert sample_csv.alias in dataset_aliases

    registry = Registry(home)
    registry.set_alias("spec-one", "spec", "as_1", "pytest", {})

    spec_aliases = ops.spec_aliases_list(home=home)
    assert "spec-one" in spec_aliases


def test_alias_listing_via_sdk(tmp_path, sample_csv):
    home = ensure_home(str(tmp_path))
    sf = Specform(home=home)

    sf.dataset(sample_csv.alias).add(sample_csv.path)
    registry = Registry(home)
    registry.set_alias("spec-two", "spec", "as_2", "pytest", {})

    assert sample_csv.alias in sf.datasets()
    assert "spec-two" in sf.specs()
