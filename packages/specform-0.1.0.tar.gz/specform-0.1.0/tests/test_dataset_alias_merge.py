from __future__ import annotations

from pathlib import Path

from specform import Specform, ops

from conftest import write_csv


def _make_csv(tmp_path: Path, name: str, rows: list[list[int]]) -> Path:
    path = tmp_path / name
    write_csv(path, ["a", "b"], rows)
    return path


def test_merge_keeps_local_order_and_appends_unique(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)

    csv1 = _make_csv(tmp_path, "csv1.csv", [[1, 10]])
    csv2 = _make_csv(tmp_path, "csv2.csv", [[2, 20]])
    csv3 = _make_csv(tmp_path, "csv3.csv", [[3, 30]])
    csv4 = _make_csv(tmp_path, "csv4.csv", [[4, 40]])
    csv5 = _make_csv(tmp_path, "csv5.csv", [[5, 50]])

    local = sf.dataset("local")
    local.add_version(csv1)
    local.add_version(csv2)
    local.add_version(csv3)

    history_before = ops.dataset_history(home=sf.home, name="local")
    before_ids = [row["target_id"] for row in history_before]
    current_before = ops.dataset_current(home=sf.home, alias="local")

    remote = sf.dataset("remote")
    remote.add_version(csv2)
    v4 = remote.add_version(csv4)
    remote.add_version(csv1)
    v5 = remote.add_version(csv5)

    sf.dataset("local").merge_from("remote")

    history_after = ops.dataset_history(home=sf.home, name="local")
    after_ids = [row["target_id"] for row in history_after]

    assert after_ids[: len(before_ids)] == before_ids
    assert after_ids[len(before_ids) :] == [v4.ds_id, v5.ds_id]
    assert len(history_after) == len(history_before) + 2
    assert ops.dataset_current(home=sf.home, alias="local") == current_before


def test_merge_dry_run_reports_append(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)

    csv1 = _make_csv(tmp_path, "csv1.csv", [[1, 10]])
    csv2 = _make_csv(tmp_path, "csv2.csv", [[2, 20]])
    csv3 = _make_csv(tmp_path, "csv3.csv", [[3, 30]])

    sf.dataset("local").add_version(csv1)
    remote = sf.dataset("remote")
    v2 = remote.add_version(csv2)
    v3 = remote.add_version(csv3)

    history_before = ops.dataset_history(home=sf.home, name="local")
    report = sf.dataset("local").merge_from("remote", dry_run=True)

    assert report["append_ds_ids"] == [v2.ds_id, v3.ds_id]
    history_after = ops.dataset_history(home=sf.home, name="local")
    assert len(history_after) == len(history_before)


def test_merge_into_new_alias_adopts_incoming_order(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)

    csv1 = _make_csv(tmp_path, "csv1.csv", [[1, 10]])
    csv2 = _make_csv(tmp_path, "csv2.csv", [[2, 20]])

    remote = sf.dataset("remote")
    v1 = remote.add_version(csv1)
    v2 = remote.add_version(csv2)

    sf.dataset("into").merge_from("remote")

    history = ops.dataset_history(home=sf.home, name="into")
    assert [row["target_id"] for row in history] == [v1.ds_id, v2.ds_id]
    assert ops.dataset_current(home=sf.home, alias="into") == v2.ds_id


def test_merge_is_idempotent(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)

    csv1 = _make_csv(tmp_path, "csv1.csv", [[1, 10]])
    csv2 = _make_csv(tmp_path, "csv2.csv", [[2, 20]])
    csv3 = _make_csv(tmp_path, "csv3.csv", [[3, 30]])

    sf.dataset("local").add_version(csv1)
    remote = sf.dataset("remote")
    remote.add_version(csv2)
    remote.add_version(csv3)

    sf.dataset("local").merge_from("remote")
    history_after_first = ops.dataset_history(home=sf.home, name="local")

    sf.dataset("local").merge_from("remote")
    history_after_second = ops.dataset_history(home=sf.home, name="local")

    assert len(history_after_second) == len(history_after_first)
