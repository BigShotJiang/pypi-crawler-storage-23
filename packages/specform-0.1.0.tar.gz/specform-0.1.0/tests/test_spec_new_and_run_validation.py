from __future__ import annotations

from pathlib import Path

from conftest import run_cli


def test_spec_new_and_run_validation(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    data.write_text("time,event\n1,0\n")
    run_cli(["dataset", "add", str(data), "--name", "demo"], tmp_path)
    code, _ = run_cli(["spec", "new", "--template", "coxph", "--dataset", "demo", "--name", "spec1"], tmp_path)
    assert code == 0

    draft_path = tmp_path / ".specform" / "drafts" / "as" / "spec1.yaml"
    before = draft_path.read_text()

    code, result = run_cli(["run", "--spec", "spec1"], tmp_path)
    assert code == 1
    assert result["status"] == "validation_failed"
    assert draft_path.read_text() == before

    as_dir = tmp_path / ".specform" / "blobs" / "as"
    er_dir = tmp_path / ".specform" / "blobs" / "er"
    assert not any(as_dir.glob("*.json"))
    assert not any(er_dir.glob("*.json"))
