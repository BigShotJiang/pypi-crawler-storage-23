from __future__ import annotations

import os
from pathlib import Path

import pytest

from tests.conftest import (
    run_cli,
    run_cli_raw,
    sample_csv,
    ensure_dataset_added,
    ensure_spec_new,
    set_spec_bindings,
    specform_home,
)


def _supports_fault_injection(tmp_path: Path) -> bool:
    # We detect by running a harmless command with SPECFORM_FAULT and checking if stderr mentions unknown fault
    cp = run_cli_raw(["history", "nope"], cwd=tmp_path, env_extra={"SPECFORM_FAULT": "noop"})
    # If your system ignores unknown faults, this should still work.
    # If it errors "unknown fault", consider that "supported".
    return True


@pytest.mark.slow
def test_crash_after_locked_as_write_does_not_corrupt_workspace(tmp_path: Path, sample_csv) -> None:
    """
    Requires you to implement a fault point, e.g.:
      SPECFORM_FAULT=after_locked_as_write -> os._exit(137)
    The key invariant: after crash, history/doctor works and workspace isn't corrupted.
    """
    # If you don't have fault points, skip.
    # (Replace this with stricter detection if you expose a 'doctor' command or fault listing.)
    if not _supports_fault_injection(tmp_path):
        pytest.skip("fault injection not supported")

    ensure_dataset_added(tmp_path, sample_csv)
    draft = ensure_spec_new(tmp_path, "cox_primary", sample_csv.alias)
    set_spec_bindings(draft)

    # Induce crash mid-run
    cp = run_cli_raw(
        ["run", "--spec", "cox_primary", "--author", "pytest", "--json"],
        cwd=tmp_path,
        env_extra={"SPECFORM_FAULT": "after_locked_as_write"},
    )
    assert cp.returncode != 0, "expected crash/non-zero exit from fault injection"

    # After crash, history should still be callable without exceptions
    rc, out = run_cli(["history", sample_csv.alias], cwd=tmp_path)
    # rc may be 0 or nonzero depending on how you handle missing alias; we only require it doesn't crash.
    assert specform_home(tmp_path).exists(), "workspace vanished after crash"
