from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

import pytest

from tests.conftest import (
    ROOT,
    sample_csv,
    ensure_dataset_added,
    ensure_spec_new,
    set_spec_bindings,
    specform_home,
    sqlite_conn,
    fetchall,
)


@pytest.mark.slow
def test_concurrent_runs_create_distinct_ers_and_runs(tmp_path: Path, sample_csv) -> None:
    """
    Launch two run processes at the same time.
    Expect two ERs and two run dirs without registry corruption.
    """
    ensure_dataset_added(tmp_path, sample_csv)
    draft = ensure_spec_new(tmp_path, "cox_primary", sample_csv.alias)
    set_spec_bindings(draft)

    env = os.environ.copy()
    env["PYTHONPATH"] = os.pathsep.join([str(ROOT), env.get("PYTHONPATH", "")]).strip(os.pathsep)

    cmd = [sys.executable, "-m", "specform.cli", "run", "--spec", "cox_primary", "--author", "conc", "--json"]
    p1 = subprocess.Popen(cmd, cwd=tmp_path, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    p2 = subprocess.Popen(cmd, cwd=tmp_path, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    out1, err1 = p1.communicate(timeout=120)
    out2, err2 = p2.communicate(timeout=120)

    assert p1.returncode == 0, f"p1 failed: {err1}\n{out1}"
    assert p2.returncode == 0, f"p2 failed: {err2}\n{out2}"

    # Expect at least 2 run dirs
    runs_root = specform_home(tmp_path) / "runs"
    run_dirs = [p for p in runs_root.iterdir() if p.is_dir()]
    assert len(run_dirs) >= 2, "expected multiple run directories from concurrent runs"

    # Expect multiple ER blobs
    er_blobs = list((specform_home(tmp_path) / "blobs" / "er").glob("er_*.json"))
    assert len(er_blobs) >= 2, "expected multiple ERs from concurrent runs"

    # Registry should show multiple receipt rows
    with sqlite_conn(tmp_path) as conn:
        receipt_rows = fetchall(conn, "SELECT * FROM receipts")
        assert len(receipt_rows) >= 2
