from __future__ import annotations

from pathlib import Path
import pytest

from tests.conftest import run_cli, write_csv, alias_events


def test_author_precedence_flag_over_env_over_os(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    """
    Ensures author follows precedence for *actions* (alias_events):
      --author flag > SPECFORM_AUTHOR env var > OS username fallback

    Note: DS blobs are immutable and may be deduped; adding the same dataset again
    should NOT change the DS's author. We therefore check alias_events attribution.
    """
    csv = tmp_path / "data.csv"
    header = ["tte", "event", "x1"]
    rows = [[5, 1, 0.2], [6, 0, 0.1]]
    write_csv(csv, header, rows)

    # Case 1: env only
    monkeypatch.setenv("SPECFORM_AUTHOR", "env_author")
    rc, out = run_cli(["dataset", "add", str(csv), "--name", "brca_env"], cwd=tmp_path)
    assert rc == 0, out
    ev = alias_events(tmp_path, "brca_env", "dataset")
    assert ev[-1]["author"] == "env_author"

    # Case 2: flag overrides env (even if DS is reused)
    rc2, out2 = run_cli(["dataset", "add", str(csv), "--name", "brca_env", "--author", "flag_author"], cwd=tmp_path)
    assert rc2 == 0, out2
    ev2 = alias_events(tmp_path, "brca_env", "dataset")
    assert ev2[-1]["author"] == "flag_author"

    # Case 3: no env, no flag => OS fallback (non-empty)
    monkeypatch.delenv("SPECFORM_AUTHOR", raising=False)
    rc3, out3 = run_cli(["dataset", "add", str(csv), "--name", "brca_env"], cwd=tmp_path)
    assert rc3 == 0, out3
    ev3 = alias_events(tmp_path, "brca_env", "dataset")
    assert isinstance(ev3[-1]["author"], str) and ev3[-1]["author"]
