# tests/test_dataset_presence_and_integrity.py
from __future__ import annotations

from pathlib import Path

import pytest

from conftest import (
    ensure_dataset_added,
    run_cli,
    specform_home,
    alias_current_target,
    load_json,
    sample_csv,
    set_spec_bindings,
)


def test_history_shows_presence_missing_when_blob_data_deleted(tmp_path: Path, sample_csv):
    ds_id = ensure_dataset_added(tmp_path, sample_csv)

    # Remove DS bytes to simulate missing data.
    ds_dir = specform_home(tmp_path) / "blobs" / "ds" / ds_id
    data_files = list(ds_dir.glob("data.*")) + list(ds_dir.glob("data"))
    assert data_files, "expected stored dataset bytes"
    for f in data_files:
        f.unlink()

    rc, out = run_cli(["history", sample_csv.alias], cwd=tmp_path)
    assert rc == 0, out
    rows = out["rows"] if isinstance(out, dict) else out
    assert isinstance(rows, list) and rows, out
    assert rows, "expected at least one history row"
    # The current row should report missing presence
    current = next((r for r in rows if r.get("current") is True), rows[-1])
    assert current.get("presence") in ("missing", "present"), current
    assert current.get("presence") == "missing", current
    assert "fingerprint" in current or "fingerprint_short" in current


def test_run_refuses_when_ds_bytes_missing(tmp_path: Path, sample_csv):
    ensure_dataset_added(tmp_path, sample_csv)
    # Create spec
    rc, out = run_cli(
        ["spec", "new", "--template", "coxph", "--dataset", sample_csv.alias, "--name", "cox_primary"],
        cwd=tmp_path,
    )
    assert rc == 0, out

    # Delete DS bytes
    ds_id = alias_current_target(tmp_path, sample_csv.alias, "dataset")
    assert ds_id
    ds_dir = specform_home(tmp_path) / "blobs" / "ds" / ds_id
    for f in ds_dir.glob("data*"):
        if f.is_file():
            f.unlink()

    # Fill bindings in draft (even though bytes are missing)
    draft = specform_home(tmp_path) / "drafts" / "as" / "cox_primary.yaml"
    set_spec_bindings(draft)

    rc, out = run_cli(["run", "--spec", "cox_primary"], cwd=tmp_path)
    assert rc != 0, out
    # Expect an error payload. Shape may vary; just require it's informative.
    assert out is not None, "expected JSON error payload"
    msg = str(out)
    assert "missing" in msg.lower() or "not found" in msg.lower() or "ds" in msg.lower()


def test_fingerprint_integrity_check_detects_corruption(tmp_path: Path, sample_csv):
    """
    Requires the runtime to verify stored DS bytes match fingerprint before run.
    If you haven't implemented that yet, mark xfail.
    """
    ensure_dataset_added(tmp_path, sample_csv)
    rc, out = run_cli(
        ["spec", "new", "--template", "coxph", "--dataset", sample_csv.alias, "--name", "cox_primary"],
        cwd=tmp_path,
    )
    assert rc == 0, out

    # Fill bindings
    draft = specform_home(tmp_path) / "drafts" / "as" / "cox_primary.yaml"
    set_spec_bindings(draft)

    # Corrupt stored DS bytes
    ds_id = alias_current_target(tmp_path, sample_csv.alias, "dataset")
    assert ds_id
    ds_dir = specform_home(tmp_path) / "blobs" / "ds" / ds_id
    data_files = list(ds_dir.glob("data*"))
    assert data_files
    data_path = next((p for p in data_files if p.is_file()), None)
    assert data_path
    orig = data_path.read_bytes()
    data_path.write_bytes(orig + b"\nCORRUPTION\n")

    rc, out = run_cli(["run", "--spec", "cox_primary"], cwd=tmp_path)
    if rc == 0:
        pytest.xfail("Fingerprint integrity check not enforced (run succeeded despite corrupted DS bytes).")
    msg = str(out).lower()
    assert "fingerprint" in msg or "hash" in msg or "mismatch" in msg
