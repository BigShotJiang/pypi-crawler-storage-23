from __future__ import annotations

from pathlib import Path

from specform.core.yamlutil import dump_yaml, load_yaml

from conftest import alias_current_target, run_cli


def test_spec_open_creates_new_draft_and_restores_ds_version(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    data.write_text("time,event,age\n1,0,33\n2,1,44\n")
    run_cli(["dataset", "add", str(data), "--name", "demo"], tmp_path)
    run_cli(["spec", "new", "--template", "coxph", "--dataset", "demo", "--name", "spec1"], tmp_path)

    draft_path = tmp_path / ".specform" / "drafts" / "as" / "spec1.yaml"
    draft = load_yaml(draft_path.read_text())
    draft["bindings"]["duration_col"] = "time"
    draft["bindings"]["event_col"] = "event"
    draft["bindings"]["covariates"] = ["age"]
    draft_path.write_text(dump_yaml(draft))

    run_cli(["run", "--spec", "spec1"], tmp_path)
    before_ds = alias_current_target(tmp_path, "demo", "dataset")

    code, result = run_cli(["spec", "open", "--spec", "spec1", "--version", "1", "--name", "spec2"], tmp_path)
    assert code == 0
    new_path = Path(result["draft"])
    assert new_path.exists()
    reopened = load_yaml(new_path.read_text())
    assert reopened["dataset_ref"] == "demo"
    assert reopened["dataset_pin"].startswith("ds_")
    after_ds = alias_current_target(tmp_path, "demo", "dataset")
    assert before_ds == after_ds
