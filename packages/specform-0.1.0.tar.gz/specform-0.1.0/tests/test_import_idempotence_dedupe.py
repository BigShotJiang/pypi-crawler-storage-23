from __future__ import annotations

from pathlib import Path

import pytest

from tests.conftest import (
    run_cli,
    sample_csv,
    ensure_dataset_added,
    ensure_spec_new,
    set_spec_bindings,
    specform_home,
)


def _supports_export_import(tmp_path: Path) -> bool:
    # If CLI doesn't support export/import it will error; detect and skip.
    rc, out = run_cli(["help"], cwd=tmp_path)
    # If your CLI doesn't have help, just attempt export and see.
    rc2, out2 = run_cli(["export", "--help"], cwd=tmp_path)
    return rc2 == 0


@pytest.mark.slow
def test_import_same_pack_twice_does_not_duplicate_blobs(tmp_path: Path, sample_csv) -> None:
    """
    Requires: specform export/import implemented.
    Expectation: importing the same pack twice does not create duplicate DS/AS/ER blobs.
    """
    # Best-effort command detection
    rc_check, out_check = run_cli(["export", "--help"], cwd=tmp_path)
    if rc_check != 0:
        pytest.skip("export/import not implemented")

    # Create a run so we have DS + AS + ER
    ds_id = ensure_dataset_added(tmp_path, sample_csv)
    draft = ensure_spec_new(tmp_path, "cox_primary", sample_csv.alias)
    set_spec_bindings(draft)
    rc, out = run_cli(["run", "--spec", "cox_primary"], cwd=tmp_path)
    assert rc == 0, out

    # Export
    pack = tmp_path / "pilot.sfpack"
    rc2, out2 = run_cli(["export", "--out", str(pack)], cwd=tmp_path)
    assert rc2 == 0, out2
    assert pack.exists(), "export did not create pack file"

    # Import twice into fresh workspace
    dest = tmp_path / "dest"
    dest.mkdir()

    rc3, out3 = run_cli(["import", str(pack)], cwd=dest)
    assert rc3 == 0, out3
    ds_before = list((specform_home(dest) / "blobs" / "ds").glob("ds_*"))
    as_before = list((specform_home(dest) / "blobs" / "as").glob("as_*.json"))
    er_before = list((specform_home(dest) / "blobs" / "er").glob("er_*.json"))

    rc4, out4 = run_cli(["import", str(pack)], cwd=dest)
    assert rc4 == 0, out4
    ds_after = list((specform_home(dest) / "blobs" / "ds").glob("ds_*"))
    as_after = list((specform_home(dest) / "blobs" / "as").glob("as_*.json"))
    er_after = list((specform_home(dest) / "blobs" / "er").glob("er_*.json"))

    assert len(ds_after) == len(ds_before), "duplicate DS blobs created on second import"
    assert len(as_after) == len(as_before), "duplicate AS blobs created on second import"
    assert len(er_after) == len(er_before), "duplicate ER blobs created on second import"
