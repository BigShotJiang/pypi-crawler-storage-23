from __future__ import annotations

from pathlib import Path

from specform import Specform, ops


def test_sdk_smoke(tmp_path: Path) -> None:
    sf = Specform(home=tmp_path)
    csv_path = tmp_path / "brca.csv"
    csv_path.write_text("time,event,x1\n1,1,10\n2,0,20\n", encoding="utf-8")

    snapshot = sf.dataset("brca").add(csv_path, return_version=True)
    assert snapshot.ds_id.startswith("ds_")
    assert (tmp_path / ".specform").exists()

    draft = sf.spec("cox_primary").new(template="coxph", dataset="brca")
    draft.bind(duration_col="time", event_col="event", covariates=["x1"])
    draft.save(force=True)

    issues = ops.validate_draft(home=sf.home, draft=draft.draft)
    assert isinstance(issues, list)

    result = draft.run()
    assert result.receipt_id.startswith("er_")

    history = sf.spec("cox_primary").history()
    assert history.rows
    assert history.rows[-1]["receipt_id"] == result.receipt_id
