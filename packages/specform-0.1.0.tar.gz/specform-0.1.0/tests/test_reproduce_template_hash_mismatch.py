# tests/test_reproduce_template_hash_mismatch.py
from __future__ import annotations

from pathlib import Path

import pytest

from conftest import (
    ensure_dataset_added,
    ensure_spec_new,
    run_cli,
    specform_home,
    alias_current_target,
    load_json,
    sample_csv,
    set_spec_bindings,
)


def test_reproduce_refuses_on_template_hash_mismatch(tmp_path: Path, sample_csv):
    """
    This test expects reproduce() to require template_hash availability and equality.
    If your kernel currently allows reproduce without checking, this will xfail until implemented.
    """
    ensure_dataset_added(tmp_path, sample_csv)
    draft = ensure_spec_new(tmp_path, "cox_primary", sample_csv.alias)
    set_spec_bindings(draft)

    rc, out = run_cli(["run", "--spec", "cox_primary"], cwd=tmp_path)
    assert rc == 0, out

    er_id = None
    if isinstance(out, dict):
        er_id = out.get("er_id")
    if not er_id:
        # Try reading latest ER by scanning blobs (best effort)
        er_dir = specform_home(tmp_path) / "blobs" / "er"
        ers = sorted(er_dir.glob("er_*.json"))
        assert ers, "no ER blobs found"
        er_id = ers[-1].stem

    er_path = specform_home(tmp_path) / "blobs" / "er" / f"{er_id}.json"
    er = load_json(er_path)
    as_id = er.get("as_id")
    assert as_id

    as_path = specform_home(tmp_path) / "blobs" / "as" / f"{as_id}.json"
    locked = load_json(as_path)

    # Corrupt template_hash in Locked AS (simulating mismatch)
    locked["template_hash"] = "sha256:" + ("0" * 64)
    as_path.write_text(__import__("json").dumps(locked), encoding="utf-8")

    rc2, out2 = run_cli(["reproduce", "--er", er_id], cwd=tmp_path)
    if rc2 == 0:
        pytest.xfail("reproduce did not enforce template_hash mismatch refusal.")
    msg = str(out2).lower()
    assert "template" in msg or "hash" in msg or "mismatch" in msg
