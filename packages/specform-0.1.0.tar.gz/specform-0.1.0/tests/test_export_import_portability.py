# tests/test_export_import_portability.py
from __future__ import annotations

from pathlib import Path

import pytest

from conftest import (
    ensure_dataset_added,
    ensure_spec_new,
    run_cli,
    specform_home,
    sample_csv,
    set_spec_bindings,
)


def _command_supported(tmp_path: Path, args: list[str]) -> bool:
    rc, out = run_cli(args, cwd=tmp_path)
    # Heuristic: if unsupported, many CLIs return nonzero with a generic error.
    # We'll treat "ok" only as rc==0.
    return rc == 0


@pytest.mark.slow
def test_export_import_allows_reproduce_on_fresh_workspace(tmp_path: Path, sample_csv):
    # Skip if export/import not implemented
    if not _command_supported(tmp_path, ["export", "--help"]):
        pytest.skip("export/import commands not implemented (skipping portability test)")

    ensure_dataset_added(tmp_path, sample_csv)
    draft = ensure_spec_new(tmp_path, "cox_primary", sample_csv.alias)
    set_spec_bindings(draft)
    rc, out = run_cli(["run", "--spec", "cox_primary"], cwd=tmp_path)
    assert rc == 0, out

    pack = tmp_path / "bundle.sfpack"
    rc, out = run_cli(["export", "--alias", sample_csv.alias, "--out", str(pack)], cwd=tmp_path)
    assert rc == 0, out
    assert pack.exists()

    new_ws = tmp_path / "fresh"
    new_ws.mkdir()
    rc, out = run_cli(["import", str(pack)], cwd=new_ws)
    assert rc == 0, out

    # Should have history in new workspace
    rc, out = run_cli(["history", sample_csv.alias], cwd=new_ws)
    assert rc == 0, out
    assert isinstance(out, list) and len(out) > 0, out

    # Reproduce in new workspace: need an ER id. Find latest ER blob.
    er_dir = (new_ws / ".specform" / "blobs" / "er")
    ers = sorted(er_dir.glob("er_*.json"))
    assert ers, "import did not restore ER blobs"
    er_id = ers[-1].stem

    rc, out = run_cli(["reproduce", "--er", er_id], cwd=new_ws)
    assert rc == 0, out
