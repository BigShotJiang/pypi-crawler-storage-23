# tests/test_validation_error_messages.py
from __future__ import annotations

from pathlib import Path

from conftest import ensure_dataset_added, ensure_spec_new, run_cli, sample_csv
from specform.core.yamlutil import load_yaml, dump_yaml


def test_invalid_column_name_error_is_actionable(tmp_path: Path, sample_csv):
    ensure_dataset_added(tmp_path, sample_csv)
    draft = ensure_spec_new(tmp_path, "cox_primary", sample_csv.alias)

    # Set a bad time_to_event column
    data = load_yaml(draft.read_text(encoding="utf-8"))
    assert isinstance(data, dict)
    bindings = data.setdefault("bindings", {})
    assert isinstance(bindings, dict)
    bindings["time_to_event"] = "does_not_exist"
    bindings["event"] = "event"
    bindings["covariates"] = ["x1"]
    draft.write_text(dump_yaml(data), encoding="utf-8")

    rc, out = run_cli(["run", "--spec", "cox_primary"], cwd=tmp_path)
    assert rc != 0, out
    s = str(out).lower()
    # Must mention which binding/column is wrong.
    assert "duration_col" in s or "time_to_event" in s or "does_not_exist" in s or "column" in s
