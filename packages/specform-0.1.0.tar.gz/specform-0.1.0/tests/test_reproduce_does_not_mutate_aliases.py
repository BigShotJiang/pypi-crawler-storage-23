from __future__ import annotations

from pathlib import Path

from specform.core.yamlutil import dump_yaml, load_yaml

from conftest import alias_current_target, load_json, run_cli


def test_reproduce_does_not_mutate_aliases(tmp_path: Path) -> None:
    data = tmp_path / "data.csv"
    data.write_text("time,event,age\n1,0,33\n2,1,44\n")
    run_cli(["dataset", "add", str(data), "--name", "demo"], tmp_path)
    run_cli(["spec", "new", "--template", "coxph", "--dataset", "demo", "--name", "spec1"], tmp_path)

    draft_path = tmp_path / ".specform" / "drafts" / "as" / "spec1.yaml"
    draft = load_yaml(draft_path.read_text())
    draft["bindings"]["time_to_event"] = "time"
    draft["bindings"]["event"] = "event"
    draft["bindings"]["covariates"] = ["age"]
    draft_path.write_text(dump_yaml(draft))

    _, run_result = run_cli(["run", "--spec", "spec1"], tmp_path)
    _, history_before = run_cli(["history", "spec1"], tmp_path)
    spec_before = alias_current_target(tmp_path, "spec1", "spec")
    ds_before = alias_current_target(tmp_path, "demo", "dataset")

    original_receipt = load_json(tmp_path / ".specform" / "blobs" / "er" / f"{run_result['er_id']}.json")
    code, result = run_cli(["reproduce", "--er", run_result["er_id"]], tmp_path)
    assert code == 0
    new_receipt_id = result.get("receipt_id") or result.get("er_id")
    assert new_receipt_id
    assert new_receipt_id != run_result["er_id"]
    new_receipt = load_json(tmp_path / ".specform" / "blobs" / "er" / f"{new_receipt_id}.json")
    assert new_receipt["as_id"] == original_receipt["as_id"]
    assert new_receipt["ds_id"] == original_receipt["ds_id"]

    _, history_after = run_cli(["history", "spec1"], tmp_path)
    assert len(history_after) == len(history_before)
    spec_after = alias_current_target(tmp_path, "spec1", "spec")
    ds_after = alias_current_target(tmp_path, "demo", "dataset")
    assert spec_before == spec_after
    assert ds_before == ds_after
