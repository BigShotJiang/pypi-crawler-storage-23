from __future__ import annotations

from specform.core.home import ensure_home
from specform.core.registry import Registry


def test_alias_pk_allows_shared_name(tmp_path):
    home = ensure_home(str(tmp_path))
    registry = Registry(home)

    registry.set_alias("same", "dataset", "ds_1", "krish", {})
    registry.set_alias("same", "spec", "as_1", "krish", {})

    assert registry.get_alias("same", "dataset") == "ds_1"
    assert registry.get_alias("same", "spec") == "as_1"

    aliases = {(row["alias_name"], row["alias_type"]) for row in registry.list_aliases()}
    assert ("same", "dataset") in aliases
    assert ("same", "spec") in aliases
