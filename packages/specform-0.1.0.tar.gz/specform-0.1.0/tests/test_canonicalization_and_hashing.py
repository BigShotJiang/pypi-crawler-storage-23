# tests/test_canonicalization_and_hashing.py
from __future__ import annotations

from specform.core.canonical import canonical_dumps
from specform.core.hashing import sha256_hex, content_hash


def test_canonical_dumps_stable_across_calls():
    obj = {"b": 2, "a": 1, "nested": {"z": 9, "y": 8}}
    b1 = canonical_dumps(obj)
    b2 = canonical_dumps(obj)
    assert b1 == b2
    assert sha256_hex(b1) == sha256_hex(b2)
    assert content_hash(obj) == content_hash(obj)


def test_canonical_sorted_keys_minified():
    obj1 = {"b": 2, "a": 1}
    obj2 = {"a": 1, "b": 2}
    assert canonical_dumps(obj1) == canonical_dumps(obj2)
