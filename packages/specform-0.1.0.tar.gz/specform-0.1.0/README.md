# Specform Kernel v0.1

Specform Kernel is a CLI-first, single-user pilot for append-only dataset and analysis spec tracking. It stores immutable blobs on disk and records alias history in SQLite.

## Quickstart

### 1) Add a dataset

```bash
specform dataset add path/to/data.csv --name demo_ds
```

### 2) Create a draft analysis spec

```bash
specform spec new --template coxph --dataset demo_ds --name demo_spec
```

Edit the draft at `.specform/drafts/as/demo_spec.yaml` and fill in bindings:

```yaml
bindings:
  duration_col: time
  event_col: status
  covariates: [age, sex]
```

Specform supports multiple CoxPH lifelines modes:

* `survival.coxph.right.v1` (right-censored, maps to `CoxPHFitter.fit`)
* `survival.coxph.interval.v1` (interval-censored, maps to `CoxPHFitter.fit_interval_censoring`)
* `survival.coxph.left.v1` (left-censored, maps to `CoxPHFitter.fit_left_censoring`)
* `survival.coxph.v1` remains as a legacy alias for right-censoring.

Formulas require `formulaic` to be installed; otherwise provide explicit covariates.

### 3) Run

```bash
specform run --spec demo_spec
```

This freezes a Locked AS blob, runs the engine stub, writes artifacts under `.specform/runs/<run_id>/`, and writes an ER blob.

### 4) Inspect history

```bash
specform history demo_ds
specform history demo_spec
```

### 5) Reproduce from an ER

```bash
specform reproduce --er er_abc123
```

This re-runs the engine with the same Locked AS and DS and writes a new ER. It does not mutate alias pointers.

### 6) Open a spec from history

```bash
specform spec open --spec demo_spec --version 1 --name reopened_spec
```

This creates a new draft using the Locked AS from the chosen version and pins the dataset ID.

## Docs smoke test

```bash
pip install mkdocs mkdocs-material
mkdocs serve
```
