from __future__ import annotations

from pathlib import Path
from typing import Any

import json
import zipfile

from ..core.errors import SpecformUserError
from ..core.lineage import LineageStore, generate_lineage_id
from ..core.portability import _dbg_file, create_sfpack, import_sfpack
from ..core.store import ds_blob_dir, load_ds
from ._paths import _er_root_dir
from .workspace import resolve_author, resolve_home


def export_pack(*, home: Path, out: str | Path, alias: str | None = None) -> dict[str, Any]:
    pack_path = Path(out)

    if pack_path.exists() and pack_path.is_dir():
        raise SpecformUserError(
            issues=[f"--out points to a directory, expected a file: {pack_path}"],
            hint="Provide a file path ending in .sfpack, e.g. --out mybundle.sfpack",
        )

    try:
        return create_sfpack(home, pack_path, alias=alias)
    except PermissionError:
        raise SpecformUserError(
            issues=[f"Permission denied writing pack: {pack_path}"],
            hint="Choose a writable folder (e.g., your project directory) or run with appropriate permissions.",
        )


def import_pack(*, home: Path, pack: str | Path) -> dict[str, Any]:
    resolved_home = resolve_home(str(home))
    _dbg_file(resolved_home, f"CLI cmd_import resolved home={resolved_home} cwd={Path.cwd().resolve()}")

    pack_path = Path(pack)
    if not pack_path.exists():
        raise SpecformUserError(
            issues=[f"Pack not found: {pack_path}"],
            hint="Provide the path to a .sfpack created by specform export.",
        )
    if not pack_path.is_file():
        raise SpecformUserError(
            issues=[f"Pack path is not a file: {pack_path}"],
            hint="Provide the path to a .sfpack file.",
        )

    ds_ids_in_pack: list[str] = []
    manifest: dict[str, Any] = {}
    try:
        with zipfile.ZipFile(pack_path, "r") as zf:
            try:
                manifest_bytes = zf.read("sfpack_manifest.json")
                manifest = json.loads(manifest_bytes.decode("utf-8"))
            except KeyError:
                manifest = {}
            for name in zf.namelist():
                if not name.startswith(".specform/blobs/ds/"):
                    continue
                parts = name.split("/")
                if len(parts) >= 4:
                    ds_id = parts[3]
                    if ds_id and ds_id not in ds_ids_in_pack:
                        ds_ids_in_pack.append(ds_id)
    except Exception:
        ds_ids_in_pack = []
        manifest = {}

    preexisting_ds = {ds_id for ds_id in ds_ids_in_pack if ds_blob_dir(resolved_home, ds_id).exists()}
    res = import_sfpack(resolved_home, pack_path)
    er_dir = _er_root_dir(resolved_home)
    er_files = sorted([p.name for p in er_dir.glob("er_*.json")]) if er_dir.exists() else []

    lineage = LineageStore(resolved_home)
    pack_id = str(manifest.get("id") or manifest.get("pack_id") or generate_lineage_id())
    imported_aliases: list[str] = []
    for ds_id in ds_ids_in_pack:
        try:
            ds_obj = load_ds(resolved_home, ds_id)
        except Exception:
            continue
        payload = {
            "ds_id": ds_id,
            "fingerprint": ds_obj.get("fingerprint", ""),
            "fingerprint_algo": ds_obj.get("fingerprint_algo", ""),
            "how": "import_bundle",
            "reused": ds_id in preexisting_ds,
        }
        lineage.safe_write_event(
            "ds_seen",
            payload,
            author=resolve_author(None),
        )

    lineage.safe_write_event(
        "import_pack",
        {
            "pack_id": pack_id,
            "source": "file",
            "import_mode": "copy",
            "imported_ds_ids": ds_ids_in_pack,
            "imported_aliases": imported_aliases,
        },
        author=resolve_author(None),
    )
    return {
        "imported": res.imported,
        "skipped": res.skipped,
        "home": str(resolved_home),
        "cwd": str(Path.cwd().resolve()),
        "er_dir": str(er_dir),
        "er_count": len(er_files),
        "er_sample": er_files[:5],
    }
