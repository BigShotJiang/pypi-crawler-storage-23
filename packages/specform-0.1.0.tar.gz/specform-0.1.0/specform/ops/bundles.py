from __future__ import annotations

import json
import tempfile
import zipfile
from pathlib import Path
from typing import Any

from ..core.canonical import canonical_dumps
from ..core.errors import SpecformUserError
from ..core.registry import Registry
from ..core.store import compute_object_hash, load_ds, require_ds_data, write_ds_blob
from ..core.timeutil import utc_now
from ._ids import make_id
from .workspace import resolve_author


def _looks_like_ds_id(value: str) -> bool:
    return value.startswith("ds_")


def _alias_not_found(alias: str) -> SpecformUserError:
    return SpecformUserError(
        issues=[f"Dataset alias not found: {alias}"],
        hint=f"Create it first: specform dataset add <path.csv> --name {alias}",
    )


def _validate_alias_type(registry: Registry, alias: str) -> None:
    if registry.alias_type_exists(alias, "dataset"):
        return
    types = registry.all_alias_types(alias)
    if types:
        raise SpecformUserError(
            issues=[f"Alias '{alias}' exists as type(s): {', '.join(types)}"],
            hint="Dataset bundles only support dataset aliases.",
        )
    raise _alias_not_found(alias)


def _alias_bundle_view(registry: Registry, alias: str) -> tuple[list[str], dict[str, Any]]:
    _validate_alias_type(registry, alias)
    events = registry.alias_events(alias, "dataset")
    if not events:
        raise SpecformUserError(
            issues=[f"No history exists for dataset alias: {alias}"],
            hint=f"Add a dataset first: specform dataset add <path.csv> --name {alias}",
        )
    current = registry.get_alias(alias, "dataset")
    view = {
        "alias_name": alias,
        "alias_type": "dataset",
        "current_target_id": current,
        "events": [],
    }
    ds_ids: list[str] = []
    for event in events:
        meta = json.loads(event["meta_json"]) if event["meta_json"] else {}
        ds_ids.append(event["target_id"])
        view["events"].append(
            {
                "target_id": event["target_id"],
                "created_at": event["created_at"],
                "author": event["author"],
                "meta": meta,
            }
        )
    return ds_ids, view


def bundle_prepare(*, home: Path, name: str, items: list[str]) -> dict[str, Any]:
    if not items:
        raise SpecformUserError(
            issues=["No datasets or aliases provided."],
            hint="Provide dataset aliases or ds_ IDs to bundle.",
        )

    registry = Registry(home)
    ds_ids: list[str] = []
    seen: set[str] = set()
    alias_views: list[dict[str, Any]] = []

    for item in items:
        if _looks_like_ds_id(item):
            if item in seen:
                continue
            try:
                load_ds(home, item)
            except FileNotFoundError:
                raise SpecformUserError(
                    issues=[f"Dataset ID not found: {item}"],
                    hint="Check the ds_id or use a dataset alias instead.",
                )
            ds_ids.append(item)
            seen.add(item)
            continue

        alias_ds_ids, view = _alias_bundle_view(registry, item)
        alias_views.append(view)
        for ds_id in alias_ds_ids:
            if ds_id in seen:
                continue
            ds_ids.append(ds_id)
            seen.add(ds_id)

    datasets: list[dict[str, Any]] = []
    for ds_id in ds_ids:
        ds = load_ds(home, ds_id)
        schema = ds.get("schema") or {}
        profile = ds.get("profile") or {}
        datasets.append(
            {
                "ds_id": ds_id,
                "fingerprint": ds.get("fingerprint"),
                "row_count": profile.get("row_count"),
                "note": ds.get("note"),
                "schema_columns": schema.get("columns") or [],
            }
        )

    return {"name": name, "datasets": datasets, "aliases": alias_views, "ds_ids": ds_ids}


def bundle_export(*, home: Path, plan: dict[str, Any], out: str | Path, author: str | None = None) -> Path:
    out_path = Path(out)
    if out_path.exists() and out_path.is_dir():
        raise SpecformUserError(
            issues=[f"--out points to a directory, expected a file: {out_path}"],
            hint="Provide a file path ending in .sfds, e.g. --out datasets.sfds",
        )

    out_path.parent.mkdir(parents=True, exist_ok=True)
    if out_path.exists():
        out_path.unlink()

    resolved_author = resolve_author(author)
    manifest = {
        "bundle_type": "datasets",
        "bundle_version": "v1",
        "created_at": utc_now(),
        "created_by": resolved_author,
        "datasets": plan.get("datasets", []),
        "aliases": plan.get("aliases", []),
    }

    with zipfile.ZipFile(out_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps(manifest, sort_keys=True))

        for ds_id in plan.get("ds_ids", []):
            ds = load_ds(home, ds_id)
            data_path = require_ds_data(home, ds_id)
            ds_json_path = f"objects/ds/{ds_id}/ds.json"
            data_zip_path = f"objects/ds/{ds_id}/data.csv"
            zf.writestr(ds_json_path, canonical_dumps(ds))
            zf.writestr(data_zip_path, data_path.read_bytes())

        aliases = plan.get("aliases", [])
        if aliases:
            zf.writestr("views/aliases.json", json.dumps(aliases, sort_keys=True))

    return out_path


def _read_bundle(path: Path) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    if not path.exists():
        raise SpecformUserError(
            issues=[f"Bundle not found: {path}"],
            hint="Provide the path to a Specform dataset bundle (.sfds).",
        )
    if not path.is_file():
        raise SpecformUserError(
            issues=[f"Bundle path is not a file: {path}"],
            hint="Provide the path to a Specform dataset bundle file.",
        )

    try:
        with zipfile.ZipFile(path, "r") as zf:
            try:
                manifest_bytes = zf.read("manifest.json")
            except KeyError:
                raise SpecformUserError(
                    issues=[f"manifest.json missing from bundle: {path}"],
                    hint="Not a Specform dataset bundle.",
                )
            try:
                manifest = json.loads(manifest_bytes)
            except json.JSONDecodeError:
                raise SpecformUserError(
                    issues=[f"manifest.json is not valid JSON: {path}"],
                    hint="Not a Specform dataset bundle.",
                )
            if manifest.get("bundle_type") != "datasets":
                raise SpecformUserError(
                    issues=[f"Unsupported bundle_type: {manifest.get('bundle_type')}"],
                    hint="Provide a Specform dataset bundle (.sfds).",
                )
            if manifest.get("bundle_version") != "v1":
                raise SpecformUserError(
                    issues=[f"Unsupported bundle_version: {manifest.get('bundle_version')}"],
                    hint="Provide a Specform dataset bundle created with v1 format.",
                )
            aliases = manifest.get("aliases") or []
            if "views/aliases.json" in zf.namelist():
                aliases = json.loads(zf.read("views/aliases.json"))
            return manifest, aliases
    except zipfile.BadZipFile:
        raise SpecformUserError(
            issues=[f"Invalid bundle file: {path}"],
            hint="Not a Specform dataset bundle.",
        )


def bundle_inspect(*, home: Path, path: str | Path) -> dict[str, Any]:
    bundle_path = Path(path)
    manifest, aliases = _read_bundle(bundle_path)
    datasets = manifest.get("datasets") or []
    return {"manifest": manifest, "datasets": datasets, "aliases": aliases}


def _choose_renamed_alias(registry: Registry, alias: str) -> str:
    if not registry.alias_type_exists(alias, "dataset"):
        return alias
    for idx in range(1, 1000):
        candidate = f"{alias}__import{idx}"
        if not registry.alias_type_exists(candidate, "dataset"):
            return candidate
    raise SpecformUserError(
        issues=[f"Could not find an available alias name for {alias}"],
        hint="Rename or delete existing aliases and retry.",
    )


def bundle_import(
    *,
    home: Path,
    path: str | Path,
    aliases: str = "recreate",
    conflict: str = "rename",
    author: str | None = None,
) -> dict[str, Any]:
    bundle_path = Path(path)
    manifest, alias_views = _read_bundle(bundle_path)

    if aliases not in ("recreate", "none"):
        raise SpecformUserError(
            issues=[f"Unknown aliases policy: {aliases}"],
            hint="Use 'recreate' or 'none'.",
        )
    if conflict not in ("rename", "skip"):
        raise SpecformUserError(
            issues=[f"Unknown conflict policy: {conflict}"],
            hint="Use 'rename' or 'skip'.",
        )

    registry = Registry(home)
    resolved_author = resolve_author(author)
    datasets = manifest.get("datasets") or []

    source_id_to_fingerprint = {
        row.get("ds_id"): row.get("fingerprint") for row in datasets if row.get("ds_id")
    }

    ds_mapping: list[dict[str, Any]] = []
    fingerprint_to_local: dict[str, str] = {}
    imported_count = 0
    reused_count = 0
    warnings: list[str] = []

    with zipfile.ZipFile(bundle_path, "r") as zf:
        for row in datasets:
            source_ds_id = row.get("ds_id")
            if not source_ds_id:
                warnings.append("Dataset entry missing ds_id; skipping.")
                continue
            ds_json_path = f"objects/ds/{source_ds_id}/ds.json"
            data_zip_path = f"objects/ds/{source_ds_id}/data.csv"
            try:
                ds_obj = json.loads(zf.read(ds_json_path))
            except KeyError:
                raise SpecformUserError(
                    issues=[f"Dataset entry missing ds.json: {source_ds_id}"],
                    hint="Bundle is missing required dataset objects.",
                )
            fingerprint = ds_obj.get("fingerprint")
            if not fingerprint:
                raise SpecformUserError(
                    issues=[f"Dataset fingerprint missing for {source_ds_id}"],
                    hint="Bundle is missing required dataset metadata.",
                )

            if fingerprint in fingerprint_to_local:
                local_ds_id = fingerprint_to_local[fingerprint]
                reused_count += 1
                ds_mapping.append(
                    {
                        "fingerprint": fingerprint,
                        "source_ds_id": source_ds_id,
                        "local_ds_id": local_ds_id,
                        "reused": True,
                    }
                )
                continue

            existing_ds_id = registry.get_ds_by_fingerprint(fingerprint)
            if existing_ds_id:
                fingerprint_to_local[fingerprint] = existing_ds_id
                reused_count += 1
                ds_mapping.append(
                    {
                        "fingerprint": fingerprint,
                        "source_ds_id": source_ds_id,
                        "local_ds_id": existing_ds_id,
                        "reused": True,
                    }
                )
                continue

            try:
                data_bytes = zf.read(data_zip_path)
            except KeyError:
                raise SpecformUserError(
                    issues=[f"Dataset entry missing data.csv: {source_ds_id}"],
                    hint="Bundle is missing required dataset bytes.",
                )

            ds_obj = dict(ds_obj)
            ds_hash = compute_object_hash(ds_obj)
            local_ds_id = make_id("ds", ds_hash)
            ds_obj["ds_id"] = local_ds_id
            ds_obj["ds_hash"] = ds_hash

            with tempfile.TemporaryDirectory() as tmp_dir:
                tmp_path = Path(tmp_dir) / "data.csv"
                tmp_path.write_bytes(data_bytes)
                write_ds_blob(home, ds_obj, tmp_path)

            registry.add_ds_index(fingerprint, local_ds_id)
            fingerprint_to_local[fingerprint] = local_ds_id
            imported_count += 1
            ds_mapping.append(
                {
                    "fingerprint": fingerprint,
                    "source_ds_id": source_ds_id,
                    "local_ds_id": local_ds_id,
                    "reused": False,
                }
            )

    alias_results: list[dict[str, Any]] = []
    if aliases == "recreate":
        for alias_view in alias_views:
            alias_name = alias_view.get("alias_name")
            alias_type = alias_view.get("alias_type")
            if alias_type and alias_type != "dataset":
                raise SpecformUserError(
                    issues=[f"Unsupported alias_type in bundle: {alias_type}"],
                    hint="Dataset bundles only support dataset aliases.",
                )
            if not alias_name:
                warnings.append("Alias entry missing alias_name; skipping.")
                continue

            exists = registry.alias_type_exists(alias_name, "dataset")
            if exists and conflict == "skip":
                alias_results.append(
                    {
                        "source_alias": alias_name,
                        "created_alias": alias_name,
                        "status": "skipped",
                        "versions_added": 0,
                    }
                )
                continue

            created_alias = alias_name
            status = "created"
            if exists and conflict == "rename":
                created_alias = _choose_renamed_alias(registry, alias_name)
                status = "renamed" if created_alias != alias_name else "created"

            versions_added = 0
            for event in alias_view.get("events") or []:
                source_target = event.get("target_id")
                fingerprint = source_id_to_fingerprint.get(source_target)
                if not fingerprint:
                    warnings.append(
                        f"Alias event for {alias_name} references unknown ds_id: {source_target}"
                    )
                    continue
                local_ds_id = fingerprint_to_local.get(fingerprint)
                if not local_ds_id:
                    warnings.append(
                        f"Alias event for {alias_name} references missing fingerprint: {fingerprint}"
                    )
                    continue
                meta = dict(event.get("meta") or {})
                meta["source_created_at"] = event.get("created_at")
                meta["source_author"] = event.get("author")
                registry.append_alias_event(
                    created_alias,
                    "dataset",
                    local_ds_id,
                    resolved_author,
                    meta,
                )
                versions_added += 1

            alias_results.append(
                {
                    "source_alias": alias_name,
                    "created_alias": created_alias,
                    "status": status,
                    "versions_added": versions_added,
                }
            )

    return {
        "imported_count": imported_count,
        "reused_count": reused_count,
        "ds_mapping": ds_mapping,
        "alias_results": alias_results,
        "warnings": warnings,
    }
