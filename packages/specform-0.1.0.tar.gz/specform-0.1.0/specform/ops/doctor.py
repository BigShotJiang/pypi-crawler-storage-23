from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..core.registry import Registry
from ..core.store import ds_data_present, verify_ds_fingerprint
from ..templates import TEMPLATES
from ._paths import _as_root_dir, _ds_root_dir, _er_root_dir


def doctor(*, home: Path, verify: bool = False, sample: int = 20) -> dict[str, Any]:
    checks: list[dict[str, Any]] = []

    def add(name: str, status: str, details: dict[str, Any] | None = None) -> None:
        row: dict[str, Any] = {"name": name, "status": status}
        if details is not None:
            row["details"] = details
        checks.append(row)

    spec = home / ".specform"
    layout = {
        "specform_dir": str(spec),
        "blobs": str(spec / "blobs"),
        "blobs_ds": str(_ds_root_dir(home)),
        "blobs_as": str(_as_root_dir(home)),
        "blobs_er": str(_er_root_dir(home)),
        "drafts_as": str(spec / "drafts" / "as"),
        "runs": str(spec / "runs"),
    }

    missing: list[str] = []
    for k, p in layout.items():
        if not Path(p).exists():
            missing.append(k)
    add("workspace.layout", "ok" if not missing else "error", {"missing": missing, **layout})

    try:
        registry = Registry(home)
        registry.alias_type_exists("__doctor__", "dataset")
        add("registry.open", "ok", {"registry": str(home / ".specform" / "registry.sqlite")})
    except Exception as exc:
        add("registry.open", "error", {"type": type(exc).__name__, "message": str(exc)})

    try:
        ds_root = _ds_root_dir(home)
        ds_dirs = sorted([p for p in ds_root.iterdir() if p.is_dir()]) if ds_root.exists() else []
        ds_count = len(ds_dirs)
        sample_n = max(0, int(sample))
        sampled = ds_dirs[:sample_n]

        present_data = 0
        missing_data = 0
        sampled_ids: list[str] = []

        for d in sampled:
            ds_json = d / "ds.json"
            if not ds_json.exists():
                continue
            obj = json.loads(ds_json.read_text(encoding="utf-8"))
            ds_id = obj.get("ds_id")
            if not ds_id:
                continue
            sampled_ids.append(ds_id)
            if ds_data_present(home, ds_id):
                present_data += 1
            else:
                missing_data += 1

        st = "ok" if missing_data == 0 else ("warning" if present_data > 0 else "error")
        add(
            "blobs.ds",
            st,
            {"count": ds_count, "sampled": len(sampled_ids), "present_data": present_data, "missing_data": missing_data},
        )
    except Exception as exc:
        add("blobs.ds", "error", {"type": type(exc).__name__, "message": str(exc)})

    if verify:
        try:
            ds_root = _ds_root_dir(home)
            ds_dirs = sorted([p for p in ds_root.iterdir() if p.is_dir()]) if ds_root.exists() else []
            sample_n = max(0, int(sample))
            sampled = ds_dirs[:sample_n]

            verified = 0
            failed: list[dict[str, Any]] = []

            for d in sampled:
                ds_json = d / "ds.json"
                if not ds_json.exists():
                    continue
                obj = json.loads(ds_json.read_text(encoding="utf-8"))
                ds_id = obj.get("ds_id")
                if not ds_id:
                    continue
                try:
                    verify_ds_fingerprint(home, ds_id)
                    verified += 1
                except Exception as exc:
                    failed.append({"ds_id": ds_id, "type": type(exc).__name__, "message": str(exc)})

            st = "ok" if not failed else "warning"
            add("blobs.ds_fingerprint", st, {"verified": verified, "failed": len(failed), "failures": failed[:5]})
        except Exception as exc:
            add("blobs.ds_fingerprint", "error", {"type": type(exc).__name__, "message": str(exc)})

    try:
        as_files = sorted(_as_root_dir(home).glob("as_*.json")) if _as_root_dir(home).exists() else []
        add("blobs.as", "ok", {"count": len(as_files)})
    except Exception as exc:
        add("blobs.as", "warning", {"type": type(exc).__name__, "message": str(exc)})

    try:
        er_files = sorted(_er_root_dir(home).glob("er_*.json")) if _er_root_dir(home).exists() else []
        add("blobs.er", "ok", {"count": len(er_files)})
    except Exception as exc:
        add("blobs.er", "warning", {"type": type(exc).__name__, "message": str(exc)})

    try:
        _ = TEMPLATES["coxph"]
        add("templates.coxph", "ok")
    except Exception as exc:
        add("templates.coxph", "error", {"type": type(exc).__name__, "message": str(exc)})

    ok_n = sum(1 for c in checks if c["status"] == "ok")
    warn_n = sum(1 for c in checks if c["status"] == "warning")
    err_n = sum(1 for c in checks if c["status"] == "error")

    status = "ok"
    if err_n > 0:
        status = "error"
    elif warn_n > 0:
        status = "warning"

    return {"status": status, "home": str(home), "checks": checks, "summary": {"ok": ok_n, "warning": warn_n, "error": err_n}}
