from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from ..core.errors import SpecformUserError
from ..core.registry import Registry
from ..core.yamlutil import dump_yaml, load_yaml
from ._paths import _draft_path
from .workspace import resolve_author


def draft_exists(home: Path, name: str) -> bool:
    return _draft_path(home, name).exists()


def draft_load(*, home: Path, name: str) -> dict[str, Any]:
    draft_path = _draft_path(home, name)
    if not draft_path.exists():
        raise SpecformUserError(
            issues=[f"Draft spec not found: {draft_path}"],
            hint=(
                "Create one with: specform spec new --template coxph "
                f"--dataset <dataset_alias> --name {name}"
            ),
        )
    obj = load_yaml(draft_path.read_text(encoding="utf-8"))
    if not isinstance(obj, dict):
        raise SpecformUserError(
            issues=[f"Draft YAML did not parse to a mapping: {draft_path}"],
            hint="Open the draft and ensure it is valid YAML (a top-level dict).",
        )
    return obj


def draft_save(*, home: Path, name: str, draft: dict[str, Any], force: bool) -> dict[str, Any]:
    draft_path = _draft_path(home, name)
    if draft_path.exists() and not force:
        raise SpecformUserError(
            issues=[f"Draft already exists: {draft_path}"],
            hint=f"Use --force to overwrite: specform spec new ... --name {name} --force",
        )
    draft_path.parent.mkdir(parents=True, exist_ok=True)
    draft_path.write_text(dump_yaml(draft), encoding="utf-8")
    return {"draft": str(draft_path)}


def _resolve_dataset_ref_or_pin(*, home: Path, dataset_ref_or_pin: str) -> dict[str, str | None]:
    if dataset_ref_or_pin.startswith("ds_"):
        return {"dataset_ref": None, "dataset_pin": dataset_ref_or_pin}
    if not Registry(home).alias_type_exists(dataset_ref_or_pin, "dataset"):
        raise SpecformUserError(
            issues=[f"Dataset alias does not exist: {dataset_ref_or_pin}"],
            hint=f"Add a dataset first: specform dataset add <path.csv> --name {dataset_ref_or_pin}",
        )
    return {"dataset_ref": dataset_ref_or_pin, "dataset_pin": None}


def draft_new(
    *,
    home: Path,
    template: str,
    dataset_ref_or_pin: str,
    name: str,
    force: bool,
    author: str | None = None,
) -> dict[str, Any]:
    template_map = {
        "coxph": "survival.coxph.v1",
        "coxph.right": "survival.coxph.right.v1",
        "coxph.interval": "survival.coxph.interval.v1",
        "coxph.left": "survival.coxph.left.v1",
    }
    template_id = template_map.get(template)
    if not template_id:
        raise SpecformUserError(
            issues=[f"Unsupported template: {template}"],
            hint="Supported templates: coxph, coxph.right, coxph.interval, coxph.left",
        )

    resolved = _resolve_dataset_ref_or_pin(home=home, dataset_ref_or_pin=dataset_ref_or_pin)

    draft = {
        "spec_name": name,
        "template": template,
        "template_id": template_id,
        "dataset_ref": resolved["dataset_ref"],
        "dataset_pin": resolved["dataset_pin"],
        "bindings": {"time_to_event": None, "event": None, "covariates": []},
        "params": {},
        "outputs": {},
        "author": resolve_author(author),
    }
    return draft_save(home=home, name=name, draft=draft, force=force)


def draft_list(*, home: Path) -> list[dict[str, Any]]:
    drafts_dir = home / ".specform" / "drafts" / "as"
    drafts: list[dict[str, Any]] = []
    if not drafts_dir.exists():
        return drafts

    for p in sorted(drafts_dir.glob("*.yaml")):
        name = p.stem
        template_id = None
        dataset_ref = None
        modified_at = datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc).isoformat()
        obj = load_yaml(p.read_text(encoding="utf-8"))
        if isinstance(obj, dict):
            template_id = obj.get("template_id")
            dataset_ref = obj.get("dataset_ref")
        drafts.append(
            {
                "name": name,
                "path": str(p),
                "template_id": template_id,
                "dataset_ref": dataset_ref,
                "modified_at": modified_at,
            }
        )
    return drafts


def draft_set_dataset(*, home: Path, name: str, dataset_ref_or_pin: str) -> dict[str, Any]:
    draft = draft_load(home=home, name=name)
    resolved = _resolve_dataset_ref_or_pin(home=home, dataset_ref_or_pin=dataset_ref_or_pin)
    draft["dataset_ref"] = resolved["dataset_ref"]
    draft["dataset_pin"] = resolved["dataset_pin"]
    return draft_save(home=home, name=name, draft=draft, force=True)


def draft_bindings(*, home: Path, name: str) -> dict[str, Any]:
    draft = draft_load(home=home, name=name)
    bindings = draft.get("bindings")
    if not isinstance(bindings, dict):
        bindings = {}
        draft["bindings"] = bindings
    return bindings


def draft_params(*, home: Path, name: str) -> dict[str, Any]:
    draft = draft_load(home=home, name=name)
    params = draft.get("params")
    if not isinstance(params, dict):
        params = {}
        draft["params"] = params
    return params


def draft_resolve_dataset(*, home: Path, name: str) -> str | None:
    draft = draft_load(home=home, name=name)
    dataset_pin = draft.get("dataset_pin")
    if dataset_pin:
        return str(dataset_pin)
    dataset_ref = draft.get("dataset_ref")
    if isinstance(dataset_ref, str):
        from .datasets import dataset_current

        return dataset_current(home=home, alias=dataset_ref)
    return None
