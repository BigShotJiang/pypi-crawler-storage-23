from __future__ import annotations

import getpass
import json
import os
import shutil
from pathlib import Path
from typing import Any

from ..core.errors import ValidationError
from ..core.home import ensure_home


def resolve_home(home: str | None) -> Path:
    """
    Resolve and ensure the Specform workspace root.
    """
    return ensure_home(home)


def resolve_author(author: str | None) -> str:
    """
    Resolve author attribution (explicit > env > current user).
    """
    return author or os.environ.get("SPECFORM_AUTHOR") or getpass.getuser()


DEFAULT_NOTEBOOK_NAME = "specform_template.ipynb"
DEFAULT_DEMO_CSV_NAME = "demo_brca_03-22-2006.csv"


def _default_notebook_template() -> dict[str, Any]:
    return {
        "cells": [
            {
                "cell_type": "markdown",
                "metadata": {},
                "source": [
                    "# Specform Quickstart (showcase)\n",
                    "\n",
                    "Add a CSV to a dataset alias (`brca`), edit as a DataFrame, checkpoint back into the same alias, view history, and export a portable bundle.\n",
                    "Read More: https://www.specform.app",
                ],
            },
            {
                "cell_type": "code",
                "execution_count": None,
                "metadata": {},
                "outputs": [],
                "source": [
                    "from specform import Specform\n",
                    "import pandas as pd\n",
                    "\n",
                    "sf = Specform(home=\".\", author=\"your_name\")\n",
                    "brca = sf.dataset(\"brca\")\n",
                    "\n",
                    "# 1) Add CSV snapshot under alias \"brca\" (notes are metadata; identity is bytes/fingerprint)\n",
                    "brca.note(\"raw import from demo_brca_03-22-2006.csv\").add(\"demo_brca_03-22-2006.csv\")\n",
                    "\n",
                    "# 2) Load as DataFrame, make a tiny edit, checkpoint back into the SAME alias\n",
                    "df = brca.df()\n",
                    "df[\"_qc_pass\"] = True  # minimal illustrative change\n",
                    "brca.note(\"added _qc_pass flag\").checkpoint(df)\n",
                    "\n",
                    "# 3) Showcase: history + quick peek + exportability\n",
                    "history = brca.history()\n",
                    "preview = brca.head(5)\n",
                    "\n",
                    "bundle = sf.data_bundle(\"brca_showcase\", brca)\n",
                    "bundle_path = bundle.export(\"brca_showcase.sfds\")\n",
                    "\n",
                    "brca.history()\n",
                ],
            },
            {
                "cell_type": "code",
                "execution_count": None,
                "metadata": {},
                "outputs": [],
                "source": [
                    "# Let's go back to the original!\n",
                    "brca.use(1, note='reverting because more patients')\n",
                    "brca.history()\n",
                ],
            },
        ],
        "metadata": {
            "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
            "language_info": {"name": "python", "version": "3.x"},
        },
        "nbformat": 4,
        "nbformat_minor": 5,
    }


def _ensure_init_notebook(cwd: Path) -> tuple[bool, Path, str]:
    notebook_path = cwd / DEFAULT_NOTEBOOK_NAME
    if notebook_path.exists():
        return False, notebook_path, f"Notebook already exists: {notebook_path}"
    template = _default_notebook_template()
    notebook_path.write_text(json.dumps(template, indent=2) + "\n", encoding="utf-8")
    return True, notebook_path, f"Notebook created: {notebook_path}"


def _default_demo_brca_csv_text() -> str:
    # Small, stable, human-readable CSV. Keep it deterministic (no randomness).
    # Columns are generic enough to work across many templates / demos.
    return (
        "patient_id,age,sex,stage,event,tte_days\n"
        "BRCA-0001,63,F,II,1,120\n"
        "BRCA-0002,51,M,I,0,310\n"
        "BRCA-0003,44,F,III,0,450\n"
        "BRCA-0004,72,M,II,1,90\n"
        "BRCA-0005,58,F,I,0,220\n"
        "BRCA-0006,66,F,III,1,140\n"
        "BRCA-0007,39,M,I,0,500\n"
        "BRCA-0008,47,F,II,0,365\n"
        "BRCA-0009,55,M,IV,1,60\n"
        "BRCA-0010,61,F,II,0,280\n"
    )


def _ensure_demo_brca_csv(cwd: Path) -> tuple[bool, Path, str]:
    """
    Ensure demo_brca_03-22-2006.csv exists in the workspace root.

    We DO NOT overwrite if it already exists (user may have their own file).
    """
    demo_path = cwd / DEFAULT_DEMO_CSV_NAME
    if demo_path.exists():
        return False, demo_path, f"Demo CSV already exists: {demo_path}"
    demo_path.write_text(_default_demo_brca_csv_text(), encoding="utf-8")
    return True, demo_path, f"Demo CSV created: {demo_path}"


def init_workspace() -> dict[str, Any]:
    cwd = Path.cwd().resolve()
    spec_dir = cwd / ".specform"
    existed = spec_dir.exists()

    ensured = resolve_home(str(cwd))

    demo_created, demo_path, demo_message = _ensure_demo_brca_csv(cwd)
    notebook_created, notebook_path, notebook_message = _ensure_init_notebook(cwd)

    return {
        "status": "ok",
        "initialized": (not existed),
        "home": str(ensured),
        "demo_csv_created": demo_created,
        "demo_csv_path": str(demo_path),
        "demo_csv_message": demo_message,
        "notebook_created": notebook_created,
        "notebook_path": str(notebook_path),
        "notebook_message": notebook_message,
    }


def reset(*, home: Path, yes: bool, json_mode: bool) -> dict[str, Any]:
    spec = home / ".specform"

    if spec.name != ".specform" or spec.parent != home:
        raise ValidationError(
            [
                "Refusing to reset: resolved workspace layout looks unsafe.",
                f"Resolved home: {home}",
                f"Resolved specform dir: {spec}",
            ]
        )

    if not spec.exists():
        resolve_home(str(home))
        return {
            "status": "ok",
            "reset": False,
            "home": str(home),
            "message": "No .specform directory found; nothing to reset.",
        }

    if not yes:
        raise ValidationError(
            [
                "Reset requires confirmation in non-interactive mode.",
                "Re-run with: specform reset --yes",
            ]
        )

    shutil.rmtree(spec)
    resolve_home(str(home))

    return {"status": "ok", "reset": True, "home": str(home)}