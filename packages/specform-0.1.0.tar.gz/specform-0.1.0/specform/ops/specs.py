from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from ..core.errors import SpecformUserError
from ..core.registry import Registry
from ..core.store import (
    compute_object_hash,
    load_as,
    load_ds,
    require_ds_data,
    verify_ds_fingerprint,
    write_as_blob,
)
from ..templates import get_template, get_template_by_id, get_template_name
from ._ids import make_id
from .drafts import draft_exists, draft_save
from .runs import receipts_for_as, run_locked_as
from .workspace import resolve_author


def spec_aliases_list(*, home: Path) -> list[str]:
    registry = Registry(home)
    return registry.list_alias_names(alias_type="spec")


def spec_use(
    *,
    home: Path,
    alias: str,
    version: int | str,
    note: str | None = None,
    author: str | None = None,
) -> dict[str, Any]:
    registry = Registry(home)
    if not registry.alias_type_exists(alias, "spec"):
        raise SpecformUserError(
            issues=[f"Spec alias not found: {alias}"],
            hint="Run a draft first to create spec history.",
        )
    events = registry.alias_events(alias, "spec")
    if not events:
        raise SpecformUserError(
            issues=[f"No history exists for spec alias: {alias}"],
            hint=f"Run your draft first: specform run --spec {alias}",
        )
    target: str | None = None
    if isinstance(version, str):
        if version not in ("latest", "prev"):
            raise SpecformUserError(
                issues=[f"Unknown version selector: {version}"],
                hint="Use a numeric version, or 'latest'/'prev'.",
            )
        if version == "latest":
            target = events[-1]["target_id"]
        elif version == "prev":
            if len(events) < 2:
                raise SpecformUserError(
                    issues=[f"No previous version exists for alias: {alias}"],
                    hint=f"See available versions: specform history {alias}",
                )
            target = events[-2]["target_id"]
    else:
        if version < 1 or version > len(events):
            raise SpecformUserError(
                issues=[f"Version out of range: {version} (valid: 1..{len(events)})"],
                hint=f"See available versions: specform history {alias}",
            )
        target = events[version - 1]["target_id"]

    if target is None:
        raise SpecformUserError(
            issues=[f"Could not resolve spec version for alias: {alias}"],
            hint=f"See available versions: specform history {alias}",
        )

    cur = registry.get_alias(alias, "spec")
    locked = load_as(home, target)
    resolved_author = resolve_author(author)
    registry.append_alias_event(
        alias,
        "spec",
        target,
        resolved_author,
        {
            "action": "use",
            "from": cur,
            "to": target,
            "note": note,
            "ds_id": locked.get("ds_id"),
            "template_id": locked.get("template_id"),
        },
    )
    return {"alias": alias, "as_id": target}


def spec_current(*, home: Path, alias: str) -> str | None:
    registry = Registry(home)
    return registry.get_alias(alias, "spec")


def spec_history(*, home: Path, alias: str) -> list[dict[str, Any]]:
    registry = Registry(home)
    if not registry.alias_type_exists(alias, "spec"):
        if draft_exists(home, alias):
            raise SpecformUserError(
                issues=[f"'{alias}' exists as a draft spec but has no history yet."],
                hint=f"Run once to create history: specform run --spec {alias}",
            )
        raise SpecformUserError(
            issues=[f"Spec alias not found: {alias}"],
            hint="Run a draft first to create spec history.",
        )
    events = registry.alias_events(alias, "spec")
    current = registry.get_alias(alias, "spec")
    history: list[dict[str, Any]] = []
    for idx, event in enumerate(events, start=1):
        meta = json.loads(event["meta_json"]) if event["meta_json"] else {}
        as_id = event["target_id"]
        ds_id = meta.get("ds_id")
        template_id = meta.get("template_id")
        receipt_id = meta.get("receipt_id")
        status = meta.get("status")
        action = meta.get("action")
        note = meta.get("note")

        if not ds_id or not template_id:
            locked = load_as(home, as_id)
            ds_id = ds_id or locked.get("ds_id")
            template_id = template_id or locked.get("template_id")

        if not receipt_id or not status:
            receipts = receipts_for_as(home=home, as_id=as_id, limit=1)
            if receipts:
                receipt_id = receipt_id or receipts[0].get("receipt_id")
                status = status or receipts[0].get("status")

        history.append(
            {
                "version": idx,
                "current": as_id == current,
                "created_at": event["created_at"],
                "author": event["author"],
                "template_id": template_id,
                "ds_id": ds_id,
                "status": status,
                "receipt_id": receipt_id,
                "action": action,
                "note": note,
                "as_id": as_id,
            }
        )
    return history


def spec_open(
    *,
    home: Path,
    spec_alias: str,
    version: int,
    new_draft_name: str,
    restore_dataset_behavior: str | None = None,
    author: str | None = None,
) -> dict[str, Any]:
    registry = Registry(home)

    if not registry.alias_type_exists(spec_alias, "spec"):
        if draft_exists(home, spec_alias):
            raise SpecformUserError(
                issues=[f"'{spec_alias}' is a draft name, not a spec history alias."],
                hint=(
                    f"To create history, run it once: specform run --spec {spec_alias}\n"
                    f"Then you can open by version: specform spec open --spec {spec_alias} "
                    "--version 1 --name <new_draft>"
                ),
            )
        raise SpecformUserError(
            issues=[f"Spec alias not found: {spec_alias}"],
            hint="Use: specform history <spec_alias> to see spec versions once you have run at least once.",
        )

    events = registry.alias_events(spec_alias, "spec")
    if not events:
        raise SpecformUserError(
            issues=[f"No history exists for spec alias: {spec_alias}"],
            hint=f"Run your draft first: specform run --spec {spec_alias}",
        )

    if version < 1 or version > len(events):
        raise SpecformUserError(
            issues=[f"Version out of range: {version} (valid: 1..{len(events)})"],
            hint=f"See available versions: specform history {spec_alias}",
        )

    as_id = events[version - 1]["target_id"]
    locked = load_as(home, as_id)

    template = get_template_by_id(locked.get("template_id") or "")
    if not template:
        raise SpecformUserError(
            issues=[f"Unknown template_id for locked AS: {locked.get('template_id')}"],
            hint="Install the Specform version that created this AS or re-run from draft.",
        )
    draft = template.draft_from_locked(locked)
    draft["spec_name"] = new_draft_name

    return draft_save(home=home, name=new_draft_name, draft=draft, force=False)


def spec_open_version(
    *,
    home: Path,
    spec_alias: str,
    version: int,
    new_draft_name: str,
    author: str | None = None,
) -> dict[str, Any]:
    return spec_open(
        home=home,
        spec_alias=spec_alias,
        version=version,
        new_draft_name=new_draft_name,
        restore_dataset_behavior=None,
        author=author,
    )


def _resolve_dataset_id(*, home: Path, dataset: str, registry: Registry) -> tuple[str, str | None]:
    if dataset.startswith("ds_"):
        return dataset, None
    ds_id = registry.get_alias(dataset, "dataset")
    if not ds_id:
        raise SpecformUserError(
            issues=[f"Dataset alias not found: {dataset}"],
            hint="Add the dataset first: specform dataset add <path.csv> --name <alias>",
        )
    return ds_id, dataset


def spec_run_inline(
    *,
    home: Path,
    spec_alias: str,
    template: str,
    dataset: str,
    bindings: dict[str, Any],
    params: dict[str, Any] | None = None,
    outputs: dict[str, Any] | None = None,
    note: str | None = None,
    author: str | None = None,
) -> dict[str, Any]:
    registry = Registry(home)
    resolved_author = resolve_author(author)
    template_obj = get_template(template)
    ds_id, dataset_alias = _resolve_dataset_id(home=home, dataset=dataset, registry=registry)
    ds = load_ds(home, ds_id)

    draft = {
        "spec_name": spec_alias,
        "template": template,
        "template_id": template_obj.template_id,
        "dataset_ref": dataset_alias,
        "dataset_pin": None if dataset_alias else ds_id,
        "bindings": bindings,
        "params": params or {},
        "outputs": outputs or {},
    }

    issues = template_obj.validate_draft(draft, ds)
    if issues:
        raise SpecformUserError(
            issues=issues,
            hint="Fix the issues above in your spec bindings/params.",
            type="validation_failed",
        )

    locked_as = template_obj.compile(draft, ds, resolved_author)
    as_hash = compute_object_hash(locked_as)
    as_id = make_id("as", as_hash)
    locked_as["as_id"] = as_id
    locked_as["as_hash"] = as_hash

    write_as_blob(home, locked_as)

    try:
        require_ds_data(home, ds_id)
        verify_ds_fingerprint(home, ds_id)
    except FileNotFoundError as exc:
        raise SpecformUserError(
            issues=[str(exc)],
            hint="Dataset bytes are missing. If this was moved between machines, import the .sfpack first.",
        )
    except ValueError as exc:
        raise SpecformUserError(
            issues=[str(exc)],
            hint="Dataset fingerprint mismatch. The dataset blob may be corrupted; re-import/re-add the DS.",
        )

    receipt = run_locked_as(home=home, as_id=as_id, ds_id=ds_id, author=resolved_author)

    registry.append_alias_event(
        spec_alias,
        "spec",
        as_id,
        resolved_author,
        {
            "action": "run",
            "ds_id": ds_id,
            "receipt_id": receipt["receipt_id"],
            "status": receipt["status"],
            "template_id": locked_as.get("template_id"),
            "note": note,
        },
    )

    return {
        "receipt_id": receipt["receipt_id"],
        "as_id": as_id,
        "ds_id": ds_id,
        "status": receipt["status"],
    }


def spec_rerun_current(
    *,
    home: Path,
    spec_alias: str,
    overrides: dict[str, Any],
    note: str | None = None,
    author: str | None = None,
) -> dict[str, Any]:
    registry = Registry(home)
    current = registry.get_alias(spec_alias, "spec")
    if not current:
        raise SpecformUserError(
            issues=[f"No spec history exists for alias: {spec_alias}"],
            hint="Run a spec once first (e.g. spec.run(template=..., dataset=...)).",
        )
    locked = load_as(home, current)
    template_id = locked.get("template_id")
    template_obj = get_template_by_id(template_id or "")
    if not template_obj:
        raise SpecformUserError(
            issues=[f"Unknown template_id for locked AS: {template_id}"],
            hint="Install the Specform version that created this AS or re-run from draft.",
        )
    template_name = get_template_name(template_id or "") or template_id or ""
    draft = template_obj.draft_from_locked(locked)

    dataset_override = overrides.pop("dataset", None)
    if dataset_override:
        ds_id, dataset_alias = _resolve_dataset_id(home=home, dataset=str(dataset_override), registry=registry)
        draft["dataset_ref"] = dataset_alias
        draft["dataset_pin"] = None if dataset_alias else ds_id

    bindings_override = overrides.pop("bindings", None)
    if isinstance(bindings_override, dict):
        draft.setdefault("bindings", {}).update(bindings_override)

    params_override = overrides.pop("params", None)
    if isinstance(params_override, dict):
        draft.setdefault("params", {}).update(params_override)

    outputs_override = overrides.pop("outputs", None)
    if isinstance(outputs_override, dict):
        draft.setdefault("outputs", {}).update(outputs_override)

    dataset_ref = draft.get("dataset_ref") or draft.get("dataset_pin")
    if not dataset_ref:
        raise SpecformUserError(
            issues=["No dataset reference available for rerun."],
            hint="Provide dataset=<alias or ds_id> in rerun overrides.",
        )

    return spec_run_inline(
        home=home,
        spec_alias=spec_alias,
        template=template_name or "coxph",
        dataset=str(dataset_ref),
        bindings=draft.get("bindings", {}),
        params=draft.get("params", {}),
        outputs=draft.get("outputs", {}),
        note=note,
        author=author,
    )
