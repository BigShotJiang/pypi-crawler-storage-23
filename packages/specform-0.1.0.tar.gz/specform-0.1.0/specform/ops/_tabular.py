from __future__ import annotations

import csv
import io
from pathlib import Path
from typing import Any


def _canonical_csv_bytes(df: Any) -> bytes:
    buf = io.StringIO()
    df.to_csv(
        buf,
        index=False,
        float_format="%.10g",
        na_rep="",
        lineterminator="\n",
    )
    return buf.getvalue().encode("utf-8")


def canonical_csv_bytes_from_path(path: Path) -> bytes:
    """
    Read a CSV path into a canonical, OS-stable CSV byte representation.
    """
    try:
        import pandas as pd
    except ModuleNotFoundError:
        with path.open("r", newline="", encoding="utf-8") as handle:
            reader = csv.reader(handle)
            buf = io.StringIO()
            writer = csv.writer(buf, lineterminator="\n")
            writer.writerows(reader)
            return buf.getvalue().encode("utf-8")

    df = pd.read_csv(path)
    return _canonical_csv_bytes(df)


def canonical_csv_bytes_from_df(df: Any) -> bytes:
    """
    Serialize a DataFrame to canonical, OS-stable CSV bytes.
    """
    return _canonical_csv_bytes(df)
