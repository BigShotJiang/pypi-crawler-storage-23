from __future__ import annotations

import os
import uuid
from pathlib import Path
from typing import Any

from ..core.errors import SpecformUserError
from ..core.hashing import content_hash
from ..core.registry import Registry
from ..core.store import (
    load_as,
    load_ds,
    load_er,
    require_ds_data,
    verify_ds_fingerprint,
    write_as_blob,
    write_er_blob,
)
from ..core.timeutil import utc_now
from ..templates import get_template, get_template_by_id, get_template_name
from ._ids import make_id
from ._paths import _er_root_dir
from .drafts import draft_load
from .workspace import resolve_author


def _resolve_dataset_for_run(home: Path, draft: dict[str, Any], registry: Registry) -> dict[str, Any]:
    ds_ref = draft.get("dataset_ref")
    ds_pin = draft.get("dataset_pin")
    if (not ds_ref or not isinstance(ds_ref, str)) and not ds_pin:
        raise SpecformUserError(
            issues=["Draft spec is missing 'dataset_ref' or 'dataset_pin'."],
            hint="Set dataset_ref to a dataset alias, or dataset_pin to a dataset snapshot id.",
        )

    ds_id = ds_pin or registry.get_alias(str(ds_ref), "dataset")
    if not ds_id:
        raise SpecformUserError(
            issues=[f"Dataset alias does not resolve: {ds_ref}"],
            hint=(
                f"Check dataset aliases with: specform history {ds_ref}\n"
                f"If it doesn't exist yet: specform dataset add <path.csv> --name {ds_ref}"
            ),
        )

    return load_ds(home, ds_id)


def _resolve_template_from_draft(draft: dict[str, Any]) -> tuple[str, Any]:
    template_id = draft.get("template_id")
    if isinstance(template_id, str):
        template = get_template_by_id(template_id)
        if template:
            template_name = get_template_name(template_id) or template_id
            return template_name, template
    template_name = draft.get("template") or "coxph"
    template = get_template(template_name)
    return template_name, template


def _validate_and_compile(home: Path, draft: dict[str, Any], author: str) -> dict[str, Any]:
    template_name, template = _resolve_template_from_draft(draft)
    ds = _resolve_dataset_for_run(home, draft, Registry(home))

    issues = template.validate_draft(draft, ds)
    if issues:
        raise SpecformUserError(
            issues=issues,
            hint="Fix the issues above in your draft YAML (or use the SDK's spec_update).",
            type="validation_failed",
        )

    executable = template.compile(draft, ds, author)
    executable["spec_alias"] = draft.get("spec_name")
    executable["template_name"] = template_name
    exec_issues = template.validate_executable(executable)
    if exec_issues:
        raise SpecformUserError(
            issues=exec_issues,
            hint=(
                "This looks like an internal compile issue. If it persists, "
                "run with --debug and report the traceback."
            ),
            type="compile_failed",
        )

    as_hash = content_hash({k: v for k, v in executable.items() if k not in ("as_id", "as_hash")})
    as_id = make_id("as", as_hash)
    executable["as_id"] = as_id
    executable["as_hash"] = as_hash
    return executable


def validate_draft(*, home: Path, draft: dict[str, Any]) -> list[str]:
    _, template = _resolve_template_from_draft(draft)
    ds = _resolve_dataset_for_run(home, draft, Registry(home))
    return template.validate_draft(draft, ds)


def run_from_draft(*, home: Path, draft_name: str, author: str | None = None) -> dict[str, Any]:
    registry = Registry(home)
    resolved_author = resolve_author(author)

    draft = draft_load(home=home, name=draft_name)
    executable = _validate_and_compile(home, draft, resolved_author)

    try:
        require_ds_data(home, executable["ds_id"])
        verify_ds_fingerprint(home, executable["ds_id"])
    except FileNotFoundError as exc:
        raise SpecformUserError(
            issues=[str(exc)],
            hint=(
                "Your workspace has DS metadata but the DS bytes are missing.\n"
                "If you imported a pack, ensure you imported blobs.\n"
                "Run: specform doctor --verify"
            ),
        )
    except ValueError as exc:
        raise SpecformUserError(
            issues=[str(exc)],
            hint=(
                "The dataset bytes on disk do not match the recorded fingerprint.\n"
                "This usually means the blob was edited or corrupted. Re-import or re-add the dataset."
            ),
        )

    write_as_blob(home, executable)

    if os.environ.get("SPECFORM_FAULT") == "after_locked_as_write":  # pragma: no cover
        os._exit(137)

    receipt = run_locked_as(home=home, as_id=executable["as_id"], ds_id=executable["ds_id"], author=resolved_author)
    registry.set_alias(
        draft_name,
        "spec",
        executable["as_id"],
        resolved_author,
        {
            "action": "run",
            "ds_id": executable["ds_id"],
            "receipt_id": receipt["receipt_id"],
            "status": receipt["status"],
            "template_id": executable["template_id"],
        },
    )
    return {
        "status": receipt["status"],
        "run_id": receipt["run_id"],
        "as_id": executable["as_id"],
        "er_id": receipt["receipt_id"],
        "receipt_id": receipt["receipt_id"],
    }


def run_locked_as(*, home: Path, as_id: str, ds_id: str | None = None, author: str | None = None) -> dict[str, Any]:
    registry = Registry(home)
    resolved_author = resolve_author(author)
    locked = load_as(home, as_id)
    resolved_ds_id = ds_id or locked.get("ds_id")
    if not resolved_ds_id:
        raise SpecformUserError(
            issues=[f"Locked AS missing ds_id: {as_id}"],
            hint="Re-run the draft to regenerate a valid locked AS.",
        )

    try:
        require_ds_data(home, resolved_ds_id)
        verify_ds_fingerprint(home, resolved_ds_id)
    except FileNotFoundError as exc:
        raise SpecformUserError(
            issues=[str(exc)],
            hint="Dataset bytes are missing. If this was moved between machines, import the .sfpack first.",
        )
    except ValueError as exc:
        raise SpecformUserError(
            issues=[str(exc)],
            hint="Dataset fingerprint mismatch. The dataset blob may be corrupted; re-import/re-add the DS.",
        )

    run_id = str(uuid.uuid4())
    run_dir = home / ".specform" / "runs" / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    status = "success"
    error_payload: dict[str, Any] | None = None
    manifest: dict[str, str] = {}

    from ..engine.runner import run_executable

    started_at = utc_now()
    try:
        executable = dict(locked)
        executable["ds_id"] = resolved_ds_id
        manifest = run_executable(executable, run_dir)
    except Exception as exc:
        status = "failed"
        error_payload = {"type": type(exc).__name__, "message": str(exc)}
    finished_at = utc_now()

    er_spec = {
        "er_id": None,
        "er_hash": None,
        "created_at": finished_at,
        "started_at": started_at,
        "finished_at": finished_at,
        "author": resolved_author,
        "status": status,
        "ds_id": resolved_ds_id,
        "as_id": locked["as_id"],
        "engine": locked["engine"],
        "artifacts": manifest,
        "error": error_payload,
        "run_id": run_id,
    }
    er_hash = content_hash({k: v for k, v in er_spec.items() if k not in ("er_id", "er_hash")})
    er_id = make_id("er", er_hash)
    er_spec["er_id"] = er_id
    er_spec["er_hash"] = er_hash
    write_er_blob(home, er_spec)

    registry.insert_receipt(
        receipt_id=er_id,
        run_id=run_id,
        created_at=er_spec["created_at"],
        started_at=er_spec["started_at"],
        finished_at=er_spec["finished_at"],
        ds_id=resolved_ds_id,
        as_id=locked["as_id"],
        status=status,
        author=resolved_author,
    )
    return {"status": status, "run_id": run_id, "receipt_id": er_id}


def receipt_get(*, home: Path, receipt_id: str) -> dict[str, Any]:
    try:
        return load_er(home, receipt_id)
    except FileNotFoundError:
        raise SpecformUserError(
            issues=[f"Execution receipt not found: {receipt_id}"],
            hint=f"Check: {_er_root_dir(home)}",
        )


def receipts_for_as(*, home: Path, as_id: str, limit: int | None = None, status_filter: str | None = None) -> list[dict[str, Any]]:
    registry = Registry(home)
    rows = registry.receipts_for_as(as_id, limit=limit)
    if status_filter:
        rows = [row for row in rows if row.get("status") == status_filter]
    return rows


def receipt_reproduce(*, home: Path, receipt_id: str, author: str | None = None) -> dict[str, Any]:
    resolved_author = resolve_author(author)

    er = receipt_get(home=home, receipt_id=receipt_id)
    locked = load_as(home, er["as_id"])

    template_id = locked.get("template_id")
    if not template_id:
        raise SpecformUserError(
            issues=["Locked AS is missing template_id (corrupt AS blob)."],
            hint="Re-run the analysis from the original draft, or re-import the pack that contained this AS.",
        )

    template = get_template_by_id(template_id) or get_template("coxph")
    expected = locked.get("template_hash")
    current = getattr(template, "template_hash", None)
    if expected and current and expected != current:
        raise SpecformUserError(
            issues=["template_hash mismatch: this AS was produced by a different template version."],
            hint=(
                "Use the exact Specform version that created the ER/AS, "
                "or re-run from draft on the current version."
            ),
        )

    receipt = run_locked_as(home=home, as_id=locked["as_id"], ds_id=er["ds_id"], author=resolved_author)
    return {"status": receipt["status"], "run_id": receipt["run_id"], "receipt_id": receipt["receipt_id"]}


def reproduce_from_er(*, home: Path, er_id: str, author: str | None = None) -> dict[str, Any]:
    return receipt_reproduce(home=home, receipt_id=er_id, author=author)
