from __future__ import annotations

from pathlib import Path


def _draft_path(home: Path, spec_name: str) -> Path:
    return home / ".specform" / "drafts" / "as" / f"{spec_name}.yaml"


def _ds_root_dir(home: Path) -> Path:
    return home / ".specform" / "blobs" / "ds"


def _as_root_dir(home: Path) -> Path:
    return home / ".specform" / "blobs" / "as"


def _er_root_dir(home: Path) -> Path:
    return home / ".specform" / "blobs" / "er"
