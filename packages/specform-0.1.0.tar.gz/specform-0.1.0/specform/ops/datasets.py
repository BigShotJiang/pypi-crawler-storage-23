from __future__ import annotations

import csv
import json
import shutil
import tempfile
from pathlib import Path
from typing import Any

from ..core.errors import SpecformUserError
from ..core.hashing import sha256_hex, sha256_stream
from ..core.lineage import LineageStore
from ..core.registry import Registry
from ..core.store import (
    compute_object_hash,
    ds_data_present,
    load_ds,
    new_ds_object,
    require_ds_data,
    write_ds_blob,
)
from ._ids import make_id
from ._tabular import canonical_csv_bytes_from_df, canonical_csv_bytes_from_path
from .drafts import draft_exists
from .workspace import resolve_author


def _read_csv_schema(path: Path) -> dict[str, Any]:
    import unicodedata

    def _norm(s: str) -> str:
        s = unicodedata.normalize("NFKC", s)
        s = s.replace("\u00A0", " ")
        return s.strip()

    with path.open("r", newline="", encoding="utf-8") as handle:
        reader = csv.reader(handle)
        try:
            header = [_norm(h) for h in next(reader)]
        except StopIteration:
            return {"columns": []}

    return {"columns": header}


def _csv_row_count(path: Path) -> int:
    with path.open("r", newline="", encoding="utf-8") as handle:
        return max(sum(1 for _ in handle) - 1, 0)


def _dataset_fingerprint(path: Path) -> str:
    if path.suffix.lower() == ".csv":
        prefix = b"csv_canonical_v0.1\n"
        return f"sha256:{sha256_hex(prefix + canonical_csv_bytes_from_path(path))}"
    prefix = b"csv_stream_v0.1\n"
    return f"sha256:{sha256_stream(path, prefix=prefix)}"


def _dataset_profile(path: Path) -> dict[str, Any]:
    return {"row_count": _csv_row_count(path), "missingness": {}}


def dataset_aliases_list(*, home: Path) -> list[str]:
    registry = Registry(home)
    return registry.list_alias_names(alias_type="dataset")


def dataset_alias_merge(
    *,
    home: Path,
    into: str,
    incoming: str,
    note: str | None = None,
    author: str | None = None,
    set_current: str | None = None,
    dry_run: bool = False,
) -> dict[str, Any]:
    registry = Registry(home)
    resolved_author = resolve_author(author)

    if set_current is None:
        set_current = "keep"
    if set_current not in ("keep", "incoming", "latest"):
        raise SpecformUserError(
            issues=[f"Unknown set_current policy: {set_current}"],
            hint="Use 'keep', 'incoming', or 'latest'.",
        )

    if not registry.alias_type_exists(incoming, "dataset"):
        raise SpecformUserError(
            issues=[f"Dataset alias not found: {incoming}"],
            hint=f"Import or create it first: specform dataset add <path.csv> --name {incoming}",
        )

    into_exists = registry.alias_type_exists(into, "dataset")
    into_events = registry.alias_events(into, "dataset") if into_exists else []
    incoming_events = registry.alias_events(incoming, "dataset")

    into_seq = [event["target_id"] for event in into_events]
    incoming_seq = [event["target_id"] for event in incoming_events]

    into_unique = set(into_seq)
    appended: list[str] = []
    appended_set: set[str] = set()
    for ds_id in incoming_seq:
        if ds_id in into_unique or ds_id in appended_set:
            continue
        appended.append(ds_id)
        appended_set.add(ds_id)

    overlap_count = len(set(incoming_seq) & into_unique)
    into_current = registry.get_alias(into, "dataset") if into_exists else None
    incoming_current = registry.get_alias(incoming, "dataset")
    merged_latest = appended[-1] if appended else (into_seq[-1] if into_seq else None)

    def _would_change_current() -> bool:
        if set_current == "keep":
            return into_current is None and merged_latest is not None
        if set_current == "incoming":
            return incoming_current is not None and into_current != incoming_current
        if set_current == "latest":
            return merged_latest is not None and into_current != merged_latest
        return False

    report: dict[str, Any] = {
        "into": into,
        "incoming": incoming,
        "into_versions": len(into_events),
        "incoming_versions": len(incoming_events),
        "overlap_count": overlap_count,
        "append_count": len(appended),
        "append_ds_ids": appended,
        "would_change_current": _would_change_current(),
    }

    if dry_run:
        return report

    update_current_on_append = set_current == "keep" and into_current is None and bool(appended)
    for ds_id in appended:
        registry.append_alias_event(
            into,
            "dataset",
            ds_id,
            resolved_author,
            {"action": "merge_add", "source_alias": incoming, "note": note},
            update_current=update_current_on_append,
        )

    if set_current == "keep":
        if into_current is None and merged_latest is not None and not update_current_on_append:
            registry.set_alias(
                into,
                "dataset",
                merged_latest,
                resolved_author,
                {"action": "merge_set_current", "source_alias": incoming, "note": note},
            )
    elif set_current == "incoming":
        if incoming_current is not None and into_current != incoming_current:
            registry.set_alias(
                into,
                "dataset",
                incoming_current,
                resolved_author,
                {"action": "merge_set_current", "source_alias": incoming, "note": note},
            )
    elif set_current == "latest":
        if merged_latest is not None and into_current != merged_latest:
            registry.set_alias(
                into,
                "dataset",
                merged_latest,
                resolved_author,
                {"action": "merge_set_current", "source_alias": incoming, "note": note},
            )

    return report


def dataset_add(
    *,
    home: Path,
    path: str | Path,
    alias: str,
    note: str | None = None,
    author: str | None = None,
) -> dict[str, Any]:
    registry = Registry(home)
    resolved_author = resolve_author(author)
    lineage = LineageStore(home)

    dataset_path = Path(path)
    if not dataset_path.exists():
        raise SpecformUserError(
            issues=[f"Dataset file not found: {dataset_path}"],
            hint=(
                "Check the path, or run from the directory that contains the file. "
                "If you meant a relative path, try prefixing with ./"
            ),
        )
    if not dataset_path.is_file():
        raise SpecformUserError(
            issues=[f"Dataset path is not a file: {dataset_path}"],
            hint="Provide a path to a CSV file.",
        )
    if dataset_path.stat().st_size == 0:
        raise SpecformUserError(
            issues=[f"Dataset file is empty: {dataset_path}"],
            hint="Export a CSV with a header row and at least one data row.",
        )

    try:
        fingerprint = _dataset_fingerprint(dataset_path)
    except PermissionError:
        raise SpecformUserError(
            issues=[f"Permission denied reading dataset: {dataset_path}"],
            hint="Close the file if it's open in Excel, or move it to a readable location.",
        )

    existing_ds_id = registry.get_ds_by_fingerprint(fingerprint)
    if existing_ds_id:
        registry.set_alias(
            alias,
            "dataset",
            existing_ds_id,
            resolved_author,
            {"action": "add", "reused": True, "note": note},
        )
        payload = {
            "ds_id": existing_ds_id,
            "fingerprint": fingerprint,
            "fingerprint_algo": "csv_canonical_v0.1" if dataset_path.suffix.lower() == ".csv" else "csv_stream_v0.1",
            "how": "dedupe_reuse",
            "alias": alias,
            "reused": True,
        }
        if note is not None:
            payload["note"] = note
        lineage.safe_write_event("ds_seen", payload, author=resolved_author)
        return {"ds_id": existing_ds_id, "reused": True}

    schema = _read_csv_schema(dataset_path)
    if not schema.get("columns"):
        raise SpecformUserError(
            issues=[f"Could not read a header row from CSV: {dataset_path}"],
            hint="Ensure the first row of the CSV contains column names.",
        )

    profile = _dataset_profile(dataset_path)
    # Notes are DS metadata only and do not affect fingerprints or hashes.
    fingerprint_algo = "csv_canonical_v0.1" if dataset_path.suffix.lower() == ".csv" else "csv_stream_v0.1"
    ds_obj = new_ds_object("", fingerprint, fingerprint_algo, schema, profile, resolved_author, note=note)

    ds_hash = compute_object_hash(ds_obj)
    ds_id = make_id("ds", ds_hash)
    ds_obj["ds_id"] = ds_id
    ds_obj["ds_hash"] = ds_hash

    data_path = dataset_path
    if dataset_path.suffix.lower() == ".csv":
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir) / "data.csv"
            tmp_path.write_bytes(canonical_csv_bytes_from_path(dataset_path))
            data_path = tmp_path
            write_ds_blob(home, ds_obj, data_path)
    else:
        write_ds_blob(home, ds_obj, data_path)
    registry.add_ds_index(fingerprint, ds_id)
    registry.set_alias(
        alias,
        "dataset",
        ds_id,
        resolved_author,
        {"action": "add", "reused": False, "note": note},
    )
    payload = {
        "ds_id": ds_id,
        "fingerprint": fingerprint,
        "fingerprint_algo": fingerprint_algo,
        "how": "dataset_add",
        "alias": alias,
        "reused": False,
    }
    if note is not None:
        payload["note"] = note
    lineage.safe_write_event("ds_seen", payload, author=resolved_author)
    return {"ds_id": ds_id, "reused": False}


def _resolve_dataset_version(*, home: Path, alias: str, version: int | str | None) -> str:
    registry = Registry(home)
    if not registry.alias_type_exists(alias, "dataset"):
        raise SpecformUserError(
            issues=[f"Dataset alias not found: {alias}"],
            hint=f"Create it first: specform dataset add <path.csv> --name {alias}",
        )
    events = registry.alias_events(alias, "dataset")
    if not events:
        raise SpecformUserError(
            issues=[f"No history exists for dataset alias: {alias}"],
            hint=f"Add a dataset first: specform dataset add <path.csv> --name {alias}",
        )
    if version is None:
        current = registry.get_alias(alias, "dataset")
        if current:
            return current
        raise SpecformUserError(
            issues=[f"Dataset alias does not resolve: {alias}"],
            hint=f"See available versions: specform history {alias}",
        )
    target: str | None = None
    if isinstance(version, str):
        if version not in ("latest", "prev"):
            raise SpecformUserError(
                issues=[f"Unknown version selector: {version}"],
                hint="Use a numeric version, or 'latest'/'prev'.",
            )
        if version == "latest":
            target = events[-1]["target_id"]
        elif version == "prev":
            if len(events) < 2:
                raise SpecformUserError(
                    issues=[f"No previous version exists for alias: {alias}"],
                    hint=f"See available versions: specform history {alias}",
                )
            target = events[-2]["target_id"]
    else:
        if version < 1 or version > len(events):
            raise SpecformUserError(
                issues=[f"Version out of range: {version} (valid: 1..{len(events)})"],
                hint=f"See available versions: specform history {alias}",
            )
        target = events[version - 1]["target_id"]

    if target is None:
        raise SpecformUserError(
            issues=[f"Could not resolve dataset version for alias: {alias}"],
            hint=f"See available versions: specform history {alias}",
        )
    return target


def _df_to_canonical_csv(df: Any, path: Path) -> None:
    path.write_bytes(canonical_csv_bytes_from_df(df))


def dataset_load_df(*, home: Path, alias: str, version: int | str | None = None, **read_kwargs: Any) -> Any:
    ds_id = _resolve_dataset_version(home=home, alias=alias, version=version)
    data_path = require_ds_data(home, ds_id)
    import pandas as pd

    return pd.read_csv(data_path, **read_kwargs)


def dataset_export_csv(
    *,
    home: Path,
    alias: str,
    out_path: str | Path,
    version: int | str | None = None,
) -> Path:
    ds_id = _resolve_dataset_version(home=home, alias=alias, version=version)
    data_path = require_ds_data(home, ds_id)
    dest = Path(out_path)
    if dest.exists() and dest.is_dir():
        dest = dest / data_path.name
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(data_path, dest)
    return dest


def dataset_add_df(
    *,
    home: Path,
    alias: str,
    df: Any,
    note: str | None = None,
    author: str | None = None,
    filename: str = "data.csv",
) -> dict[str, Any]:
    import pandas as pd

    if not isinstance(df, pd.DataFrame):
        raise SpecformUserError(
            issues=["dataset_add_df requires a pandas DataFrame."],
            hint="Pass a pandas DataFrame or use dataset_add(path=...).",
        )
    with tempfile.TemporaryDirectory() as tmp_dir:
        tmp_path = Path(tmp_dir) / filename
        _df_to_canonical_csv(df, tmp_path)
        return dataset_add(home=home, path=tmp_path, alias=alias, note=note, author=author)


def dataset_use(
    *,
    home: Path,
    alias: str,
    version: int | str,
    note: str | None = None,
    author: str | None = None,
) -> dict[str, Any]:
    registry = Registry(home)
    resolved_author = resolve_author(author)

    if not registry.alias_type_exists(alias, "dataset"):
        raise SpecformUserError(
            issues=[f"Dataset alias not found: {alias}"],
            hint=f"Create it first: specform dataset add <path.csv> --name {alias}",
        )

    events = registry.alias_events(alias, "dataset")
    if not events:
        raise SpecformUserError(
            issues=[f"No history exists for dataset alias: {alias}"],
            hint=f"Add a dataset first: specform dataset add <path.csv> --name {alias}",
        )

    target: str | None = None
    if isinstance(version, str):
        if version not in ("latest", "prev"):
            raise SpecformUserError(
                issues=[f"Unknown version selector: {version}"],
                hint="Use a numeric version, or 'latest'/'prev'.",
            )
        if version == "latest":
            target = events[-1]["target_id"]
        elif version == "prev":
            if len(events) < 2:
                raise SpecformUserError(
                    issues=[f"No previous version exists for alias: {alias}"],
                    hint=f"See available versions: specform history {alias}",
                )
            target = events[-2]["target_id"]
    else:
        if version < 1 or version > len(events):
            raise SpecformUserError(
                issues=[f"Version out of range: {version} (valid: 1..{len(events)})"],
                hint=f"See available versions: specform history {alias}",
            )
        target = events[version - 1]["target_id"]

    if target is None:
        raise SpecformUserError(
            issues=[f"Could not resolve dataset version for alias: {alias}"],
            hint=f"See available versions: specform history {alias}",
        )
    cur = registry.get_alias(alias, "dataset")
    registry.append_alias_event(
        alias,
        "dataset",
        target,
        resolved_author,
        {"action": "use", "from": cur, "to": target, "note": note},
    )
    return {"alias": alias, "target_id": target}


def dataset_history(*, home: Path, name: str) -> list[dict[str, Any]]:
    registry = Registry(home)

    if not registry.alias_type_exists(name, "dataset"):
        if draft_exists(home, name):
            raise SpecformUserError(
                issues=[f"'{name}' exists as a draft spec but has no dataset history."],
                hint=f"Use: specform history {name} for spec history after running once.",
            )
        raise SpecformUserError(
            issues=[f"Dataset alias not found: {name}"],
            hint=(
                "History is for dataset aliases and spec aliases (Locked AS history), not drafts.\n"
                "If you meant a dataset: specform dataset add <path.csv> --name <alias>"
            ),
        )

    events = registry.alias_events(name, "dataset")
    current = registry.get_alias(name, "dataset")
    history: list[dict[str, Any]] = []

    for idx, event in enumerate(events, start=1):
        row: dict[str, Any] = {
            "version": idx,
            "created_at": event["created_at"],
            "author": event["author"],
            "target_id": event["target_id"],
            "note": json.loads(event["meta_json"]).get("note") if event["meta_json"] else None,
            "current": event["target_id"] == current,
        }
        ds = load_ds(home, event["target_id"])
        fp = ds.get("fingerprint", "")
        row.update(
            {
                "row_count": ds.get("profile", {}).get("row_count"),
                "fingerprint_short": fp.split(":", 1)[1][:12] if fp else "",
                "presence": "present" if ds_data_present(home, ds["ds_id"]) else "missing",
            }
        )
        history.append(row)

    return history


def dataset_current(*, home: Path, alias: str) -> str | None:
    registry = Registry(home)
    return registry.get_alias(alias, "dataset")


def dataset_current_ds_id(*, home: Path, alias: str) -> str | None:
    return dataset_current(home=home, alias=alias)
