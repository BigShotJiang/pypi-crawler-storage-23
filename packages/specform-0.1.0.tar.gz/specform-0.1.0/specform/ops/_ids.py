from __future__ import annotations


def make_id(prefix: str, hash_value: str) -> str:
    """
    Build a compact Specform identifier from a content hash.
    """
    return f"{prefix}_{hash_value.split(':', 1)[1][:12]}"
