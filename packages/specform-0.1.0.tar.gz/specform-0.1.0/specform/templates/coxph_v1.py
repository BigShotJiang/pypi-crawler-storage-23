from __future__ import annotations

from .coxph import CoxPHLegacyV1 as CoxPHV1

__all__ = ["CoxPHV1"]
