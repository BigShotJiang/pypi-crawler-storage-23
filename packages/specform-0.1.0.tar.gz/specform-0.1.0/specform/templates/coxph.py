from __future__ import annotations

from typing import Any
import importlib.util
import json

from .base import BaseTemplate
from ..core.canonical import canonical_dumps
from ..core.hashing import sha256_hex
from ..core.timeutil import utc_now

ALLOWED_BASELINE_METHODS = {"breslow", "spline", "piecewise"}


def _formulaic_available() -> bool:
    return importlib.util.find_spec("formulaic") is not None


def _stringify_float(value: Any) -> Any:
    if isinstance(value, float):
        return f"{value}"
    if isinstance(value, list):
        return [_stringify_float(v) for v in value]
    if isinstance(value, dict):
        return {k: _stringify_float(v) for k, v in value.items()}
    return value


class CoxPHBaseTemplate(BaseTemplate):
    fit_mode: str

    def __init__(self, *, template_id: str, fit_mode: str, version: str = "1.0") -> None:
        self.template_id = template_id
        self.fit_mode = fit_mode
        self.template_hash = f"sha256:{sha256_hex(canonical_dumps({'template_id': template_id, 'version': version}))}"

    def _parse_strata(self, strata: Any) -> list[str]:
        if isinstance(strata, str) and strata:
            return [strata]
        if isinstance(strata, list):
            return [str(s) for s in strata if isinstance(s, str) and s]
        return []

    def _resolve_duration_event(self, bindings: dict[str, Any]) -> tuple[str | None, str | None]:
        duration = bindings.get("time_to_event") or bindings.get("duration_col")
        event = bindings.get("event") or bindings.get("event_col")
        return duration if isinstance(duration, str) else None, event if isinstance(event, str) else None

    def _resolve_formula(self, bindings: dict[str, Any], params_fit: dict[str, Any]) -> str | None:
        formula = params_fit.get("formula")
        if isinstance(formula, str) and formula.strip():
            return formula.strip()
        formula = bindings.get("formula")
        if isinstance(formula, str) and formula.strip():
            return formula.strip()
        return None

    def _normalize_params(self, params: dict[str, Any]) -> dict[str, Any]:
        return _stringify_float(params)

    def _split_params(self, raw_params: dict[str, Any]) -> dict[str, Any]:
        if any(k in raw_params for k in ("init", "fit", "preprocess")):
            init = raw_params.get("init") if isinstance(raw_params.get("init"), dict) else {}
            fit = raw_params.get("fit") if isinstance(raw_params.get("fit"), dict) else {}
            preprocess = (
                raw_params.get("preprocess") if isinstance(raw_params.get("preprocess"), dict) else {}
            )
            force_fail = raw_params.get("force_fail")
        else:
            init = {}
            fit = {}
            preprocess = {}
            force_fail = raw_params.get("force_fail")
            for key, value in raw_params.items():
                if key in {"baseline_estimation_method", "penalizer", "strata", "l1_ratio", "n_baseline_knots", "knots", "breakpoints", "alpha"}:
                    init[key] = value
                elif key in {
                    "show_progress",
                    "initial_point",
                    "strata",
                    "weights_col",
                    "cluster_col",
                    "robust",
                    "batch_mode",
                    "timeline",
                    "formula",
                    "entry_col",
                    "fit_options",
                }:
                    fit[key] = value
                elif key in {"encode_categoricals"}:
                    preprocess[key] = value
                elif key == "force_fail":
                    force_fail = value
                else:
                    fit[key] = value
        return {"init": init, "fit": fit, "preprocess": preprocess, "force_fail": force_fail}

    def _validate_params(self, params: dict[str, Any], issues: list[str]) -> dict[str, Any]:
        split = self._split_params(params)
        init = split["init"]
        fit = split["fit"]
        preprocess = split["preprocess"]

        allowed_init = {
            "baseline_estimation_method",
            "penalizer",
            "strata",
            "l1_ratio",
            "n_baseline_knots",
            "knots",
            "breakpoints",
            "alpha",
        }
        allowed_fit = {
            "show_progress",
            "initial_point",
            "strata",
            "weights_col",
            "cluster_col",
            "robust",
            "batch_mode",
            "timeline",
            "formula",
            "entry_col",
            "fit_options",
        }
        allowed_preprocess = {"encode_categoricals"}

        for key in init:
            if key not in allowed_init:
                issues.append(f"params.init.{key} is not supported")
        for key in fit:
            if key not in allowed_fit:
                issues.append(f"params.fit.{key} is not supported")
        for key in preprocess:
            if key not in allowed_preprocess:
                issues.append(f"params.preprocess.{key} is not supported")
        force_fail = params.get("force_fail")
        if force_fail is not None and not isinstance(force_fail, bool):
            issues.append("params.force_fail must be a boolean if set")

        baseline_method = init.get("baseline_estimation_method", "breslow")
        if isinstance(baseline_method, str):
            if baseline_method not in ALLOWED_BASELINE_METHODS:
                issues.append(
                    "params.init.baseline_estimation_method must be one of: breslow, spline, piecewise"
                )
        else:
            issues.append("params.init.baseline_estimation_method must be a string")

        if baseline_method == "spline":
            if init.get("n_baseline_knots") is None and init.get("knots") is None:
                issues.append("params.init.n_baseline_knots or params.init.knots is required for spline baseline")
        if baseline_method == "piecewise":
            if init.get("breakpoints") is None:
                issues.append("params.init.breakpoints is required for piecewise baseline")

        fit_options = fit.get("fit_options")
        if fit_options is not None:
            try:
                json.dumps(_stringify_float(fit_options))
            except TypeError:
                issues.append("params.fit.fit_options must be JSON-serializable")

        return split

    def validate_draft(self, draft: dict[str, Any], ds: dict[str, Any]) -> list[str]:
        issues: list[str] = []
        bindings = draft.get("bindings", {})
        if not isinstance(bindings, dict):
            issues.append("bindings must be a dict")
            return issues

        params = draft.get("params") or {}
        if not isinstance(params, dict):
            issues.append("params must be a dict")
            return issues

        split_params = self._validate_params(params, issues)
        params_fit = split_params["fit"]
        params_init = split_params["init"]

        if self.fit_mode in {"right", "left"}:
            duration_col, event_col = self._resolve_duration_event(bindings)
            if duration_col is None:
                issues.append("bindings.time_to_event must be set")
        else:
            duration_col = None
            event_col = bindings.get("event") or bindings.get("event_col")
            if not isinstance(event_col, str):
                event_col = None

        covariates = bindings.get("covariates")
        formula = self._resolve_formula(bindings, params_fit)

        has_covariates = isinstance(covariates, list) and any(isinstance(c, str) and c for c in covariates)
        has_formula = isinstance(formula, str) and formula.strip()
        if has_covariates and has_formula:
            issues.append("Provide either bindings.covariates or formula, not both")
        if not has_covariates and not has_formula:
            issues.append("Provide bindings.covariates or a formula")

        if has_formula and not _formulaic_available():
            issues.append("formula requires formulaic; install formulaic or provide covariates explicitly")

        if self.fit_mode == "interval":
            lower = bindings.get("lower_bound_col")
            upper = bindings.get("upper_bound_col")
            if not isinstance(lower, str) or not lower:
                issues.append("bindings.lower_bound_col must be set for interval censoring")
            if not isinstance(upper, str) or not upper:
                issues.append("bindings.upper_bound_col must be set for interval censoring")

        columns = ds.get("schema", {}).get("columns", [])
        if not isinstance(columns, list):
            columns = []
        if duration_col and duration_col not in columns:
            issues.append(f"time_to_event column '{duration_col}' not in dataset schema")
        if event_col and event_col not in columns:
            issues.append(f"event column '{event_col}' not in dataset schema")

        if has_covariates:
            for c in covariates:
                if isinstance(c, str) and c and c not in columns:
                    issues.append(f"covariate column '{c}' not in dataset schema")

        strata_candidates: list[str] = []
        strata_candidates.extend(self._parse_strata(bindings.get("strata")))
        strata_candidates.extend(self._parse_strata(params_init.get("strata")))
        strata_candidates.extend(self._parse_strata(params_fit.get("strata")))
        for col in strata_candidates:
            if col not in columns:
                issues.append(f"strata column '{col}' not in dataset schema")

        weights_col = params_fit.get("weights_col") or bindings.get("weights_col")
        weights_col = weights_col if isinstance(weights_col, str) else None
        if weights_col and weights_col not in columns:
            issues.append(f"weights_col column '{weights_col}' not in dataset schema")

        cluster_col = params_fit.get("cluster_col") or bindings.get("cluster_col")
        cluster_col = cluster_col if isinstance(cluster_col, str) else None
        if cluster_col and cluster_col not in columns:
            issues.append(f"cluster_col column '{cluster_col}' not in dataset schema")

        entry_col = params_fit.get("entry_col") or bindings.get("entry_col")
        entry_col = entry_col if isinstance(entry_col, str) else None
        if entry_col and entry_col not in columns:
            issues.append(f"entry_col column '{entry_col}' not in dataset schema")

        if self.fit_mode == "interval":
            lower = bindings.get("lower_bound_col")
            upper = bindings.get("upper_bound_col")
            if isinstance(lower, str) and lower and lower not in columns:
                issues.append(f"lower_bound_col column '{lower}' not in dataset schema")
            if isinstance(upper, str) and upper and upper not in columns:
                issues.append(f"upper_bound_col column '{upper}' not in dataset schema")

        return issues

    def compile(self, draft: dict[str, Any], ds: dict[str, Any], author: str) -> dict[str, Any]:
        bindings = draft.get("bindings", {})
        params = draft.get("params") or {}

        split_params = self._split_params(params)

        params_init = {
            "baseline_estimation_method": "breslow",
            "penalizer": "0.0",
            "strata": None,
            "l1_ratio": "0.0",
            "n_baseline_knots": None,
            "knots": None,
            "breakpoints": None,
            "alpha": "0.05",
        }
        params_fit = {
            "show_progress": False,
            "initial_point": None,
            "strata": None,
            "weights_col": None,
            "cluster_col": None,
            "robust": False,
            "batch_mode": None,
            "timeline": None,
            "formula": None,
            "entry_col": None,
            "fit_options": None,
        }
        params_preprocess = {"encode_categoricals": True}

        params_init.update(split_params.get("init", {}))
        params_fit.update(split_params.get("fit", {}))
        params_preprocess.update(split_params.get("preprocess", {}))

        params_payload = {
            "init": self._normalize_params(params_init),
            "fit": self._normalize_params(params_fit),
            "preprocess": self._normalize_params(params_preprocess),
        }
        if split_params.get("force_fail") is not None:
            params_payload["force_fail"] = split_params.get("force_fail")

        duration_col, event_col = self._resolve_duration_event(bindings)

        executable = {
            "as_id": None,
            "as_hash": None,
            "created_at": utc_now(),
            "author": author,
            "template_id": self.template_id,
            "template_hash": self.template_hash,
            "ds_id": ds["ds_id"],
            "ds_hash": ds["ds_hash"],
            "dataset_alias": draft.get("dataset_ref"),
            "engine": {"name": "specform.engine.coxph", "version": "0.2"},
            "bindings": {
                "time_to_event": duration_col,
                "event": event_col,
                "covariates": bindings.get("covariates"),
                "formula": bindings.get("formula"),
                "strata": bindings.get("strata"),
                "weights_col": bindings.get("weights_col"),
                "cluster_col": bindings.get("cluster_col"),
                "entry_col": bindings.get("entry_col"),
                "lower_bound_col": bindings.get("lower_bound_col"),
                "upper_bound_col": bindings.get("upper_bound_col"),
            },
            "params": params_payload,
            "outputs": draft.get("outputs")
            or {
                "summary_json": "summary.json",
                "coefficients_csv": "coefficients.csv",
                "baseline_hazard_csv": "baseline_hazard.csv",
                "baseline_cumulative_hazard_csv": "baseline_cumulative_hazard.csv",
                "baseline_survival_csv": "baseline_survival.csv",
                "diagnostics_json": "diagnostics.json",
            },
            "fit_mode": self.fit_mode,
        }
        return executable

    def draft_from_locked(self, locked: dict[str, Any]) -> dict[str, Any]:
        return {
            "spec_name": None,
            "template": "coxph",
            "template_id": self.template_id,
            "dataset_ref": locked.get("dataset_alias"),
            "dataset_pin": locked.get("ds_id"),
            "bindings": locked.get("bindings", {}),
            "params": locked.get("params", {}),
            "outputs": locked.get("outputs", {}),
        }


class CoxPHRightV1(CoxPHBaseTemplate):
    def __init__(self) -> None:
        super().__init__(template_id="survival.coxph.right.v1", fit_mode="right")


class CoxPHIntervalV1(CoxPHBaseTemplate):
    def __init__(self) -> None:
        super().__init__(template_id="survival.coxph.interval.v1", fit_mode="interval")


class CoxPHLeftV1(CoxPHBaseTemplate):
    def __init__(self) -> None:
        super().__init__(template_id="survival.coxph.left.v1", fit_mode="left")


class CoxPHLegacyV1(CoxPHBaseTemplate):
    def __init__(self) -> None:
        super().__init__(template_id="survival.coxph.v1", fit_mode="right")
