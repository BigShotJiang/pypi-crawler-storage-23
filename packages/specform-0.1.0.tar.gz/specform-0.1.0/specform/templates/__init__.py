"""Template implementations."""

from __future__ import annotations

from typing import Optional

from ..core.errors import SpecformUserError
from .base import BaseTemplate
from .coxph import CoxPHIntervalV1, CoxPHLeftV1, CoxPHLegacyV1, CoxPHRightV1

TEMPLATES: dict[str, BaseTemplate] = {
    "coxph": CoxPHLegacyV1(),
    "coxph.right": CoxPHRightV1(),
    "coxph.interval": CoxPHIntervalV1(),
    "coxph.left": CoxPHLeftV1(),
}
TEMPLATES_BY_ID: dict[str, BaseTemplate] = {
    tmpl.template_id: tmpl for tmpl in TEMPLATES.values()
}
TEMPLATE_NAME_BY_ID: dict[str, str] = {
    tmpl.template_id: name for name, tmpl in TEMPLATES.items()
}


def get_template(name: str) -> BaseTemplate:
    template = TEMPLATES.get(name) or TEMPLATES_BY_ID.get(name)
    if not template:
        raise SpecformUserError(
            issues=[f"Unknown template: {name}"],
            hint="Check the template name or update Specform for new templates.",
        )
    return template


def get_template_by_id(template_id: str) -> Optional[BaseTemplate]:
    return TEMPLATES_BY_ID.get(template_id)


def get_template_name(template_id: str) -> Optional[str]:
    return TEMPLATE_NAME_BY_ID.get(template_id)
