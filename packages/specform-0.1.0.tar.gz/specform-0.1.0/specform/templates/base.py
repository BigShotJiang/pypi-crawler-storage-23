from __future__ import annotations

from typing import Any


class BaseTemplate:
    template_id: str
    template_hash: str

    def validate_draft(self, draft: dict[str, Any], ds: dict[str, Any]) -> list[str]:
        raise NotImplementedError

    def compile(self, draft: dict[str, Any], ds: dict[str, Any], author: str) -> dict[str, Any]:
        raise NotImplementedError

    def validate_executable(self, executable: dict[str, Any]) -> list[str]:
        return []

    def draft_from_locked(self, locked: dict[str, Any]) -> dict[str, Any]:
        raise NotImplementedError
