from __future__ import annotations

from pathlib import Path
from typing import Any, Callable

from .coxph import (
    TEMPLATE_ID_INTERVAL,
    TEMPLATE_ID_LEFT,
    TEMPLATE_ID_RIGHT,
    run_coxph_interval_v1,
    run_coxph_left_v1,
    run_coxph_right_v1,
)
from .coxph_v1 import TEMPLATE_ID as COXPH_TEMPLATE_ID
from .coxph_v1 import run_coxph_v1

Executor = Callable[[dict[str, Any], Path], dict[str, str]]

EXECUTORS: dict[str, Executor] = {
    COXPH_TEMPLATE_ID: run_coxph_v1,
    TEMPLATE_ID_RIGHT: run_coxph_right_v1,
    TEMPLATE_ID_INTERVAL: run_coxph_interval_v1,
    TEMPLATE_ID_LEFT: run_coxph_left_v1,
}
