from __future__ import annotations

from pathlib import Path
from typing import Any

from .coxph import run_coxph_right_v1

TEMPLATE_ID = "survival.coxph.v1"


def run_coxph_v1(executable: dict[str, Any], run_dir: Path) -> dict[str, str]:
    return run_coxph_right_v1(executable, run_dir)
