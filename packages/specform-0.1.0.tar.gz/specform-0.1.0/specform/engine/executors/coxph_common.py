from __future__ import annotations

import json
import unicodedata
from pathlib import Path
from typing import Any, Iterable
import importlib.util

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import pandas as pd

from specform.core.home import ensure_home
from specform.core.store import require_ds_data


ALLOWED_BASELINE_METHODS = {"breslow", "spline", "piecewise"}


def _infer_ws_root(run_dir: Path) -> Path:
    """
    run_dir is usually: <ws_root>/.specform/runs/<run_id>
    We infer ws_root by walking upward until we see a '.specform' dir.
    """
    cur = run_dir.resolve()
    for p in [cur, *cur.parents]:
        if (p / ".specform").exists():
            return p
    raise RuntimeError(f"Could not infer workspace root from run_dir={run_dir}")


def _require_str(d: dict[str, Any], key: str) -> str:
    v = d.get(key)
    if not isinstance(v, str) or not v:
        raise ValueError(f"Missing or invalid {key!r}")
    return v


def _norm(s: str) -> str:
    s = unicodedata.normalize("NFKC", s)
    s = s.replace("\u00A0", " ")  # NBSP → normal space
    return s.strip()


def _parse_numeric(value: Any) -> Any:
    if isinstance(value, list):
        return [_parse_numeric(v) for v in value]
    if isinstance(value, dict):
        return {k: _parse_numeric(v) for k, v in value.items()}
    if isinstance(value, str):
        try:
            if value.strip() == "":
                return value
            return float(value)
        except ValueError:
            return value
    return value


def _parse_int(value: Any) -> int | None:
    if value is None:
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str):
        try:
            return int(float(value))
        except ValueError:
            return None
    return None


def _parse_float(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        try:
            return float(value)
        except ValueError:
            return None
    return None


def _parse_penalizer(value: Any) -> float | list[float] | None:
    if value is None:
        return None
    if isinstance(value, list):
        parsed: list[float] = []
        for item in value:
            parsed_item = _parse_float(item)
            if parsed_item is None:
                raise ValueError("penalizer list must contain numeric values")
            parsed.append(parsed_item)
        return parsed
    if isinstance(value, (float, int, str)):
        parsed_value = _parse_float(value)
        if parsed_value is None:
            raise ValueError("penalizer must be numeric")
        return parsed_value
    raise ValueError("penalizer must be a number or list of numbers")


def _parse_strata(value: Any) -> list[str] | None:
    if isinstance(value, str) and value:
        return [value]
    if isinstance(value, list):
        items = [str(v) for v in value if isinstance(v, str) and v]
        return items or None
    return None


def _resolve_column(value: Any) -> str | None:
    if isinstance(value, str) and value:
        return value
    return None


def _require_columns(df: Any, columns: Iterable[str]) -> None:
    missing = [c for c in columns if c not in df.columns]
    if missing:
        raise ValueError(f"Dataset missing required columns: {missing}")


def _maybe_write_df(path: Path, df: Any | None) -> bool:
    if df is None:
        return False
    if df.empty:
        return False
    df.to_csv(path, index=True)
    return True


def _safe_stat(getter: Any, default: float = float("nan")) -> float:
    try:
        value = getter()
    except Exception:
        return default
    try:
        return float(value)
    except Exception:
        return default


def _extract_outputs(outputs: dict[str, Any]) -> dict[str, str]:
    if not isinstance(outputs, dict):
        return {}
    return {k: v for k, v in outputs.items() if isinstance(v, str) and v}


def _resolve_formula(params_fit: dict[str, Any], bindings: dict[str, Any]) -> str | None:
    formula = params_fit.get("formula")
    if isinstance(formula, str) and formula.strip():
        return formula.strip()
    formula = bindings.get("formula")
    if isinstance(formula, str) and formula.strip():
        return formula.strip()
    return None


def _formulaic_available() -> bool:
    return importlib.util.find_spec("formulaic") is not None


def _resolve_fit_strata(params_fit: dict[str, Any], params_init: dict[str, Any], bindings: dict[str, Any]) -> list[str] | None:
    fit_strata = _parse_strata(params_fit.get("strata"))
    if fit_strata:
        return fit_strata
    init_strata = _parse_strata(params_init.get("strata"))
    if init_strata:
        return init_strata
    binding_strata = _parse_strata(bindings.get("strata"))
    return binding_strata


def _resolve_init_strata(params_fit: dict[str, Any], params_init: dict[str, Any], bindings: dict[str, Any]) -> list[str] | None:
    if _parse_strata(params_fit.get("strata")):
        return None
    init_strata = _parse_strata(params_init.get("strata"))
    if init_strata:
        return init_strata
    return _parse_strata(bindings.get("strata"))


def _build_fit_kwargs(
    *,
    mode: str,
    duration_col: str | None,
    event_col: str | None,
    lower_bound_col: str | None,
    upper_bound_col: str | None,
    fit_strata: list[str] | None,
    weights_col: str | None,
    cluster_col: str | None,
    entry_col: str | None,
    params_fit: dict[str, Any],
) -> dict[str, Any]:
    fit_kwargs: dict[str, Any] = {
        "show_progress": bool(params_fit.get("show_progress", False)),
    }
    if mode in {"right", "left"}:
        if duration_col is None:
            raise ValueError("Missing duration column")
        fit_kwargs["duration_col"] = duration_col
        if event_col:
            fit_kwargs["event_col"] = event_col
    if mode == "interval":
        if lower_bound_col is None or upper_bound_col is None:
            raise ValueError("Interval censoring requires lower_bound_col and upper_bound_col")
        fit_kwargs["lower_bound_col"] = lower_bound_col
        fit_kwargs["upper_bound_col"] = upper_bound_col
        if event_col:
            fit_kwargs["event_col"] = event_col
    if fit_strata:
        fit_kwargs["strata"] = fit_strata
    if weights_col:
        fit_kwargs["weights_col"] = weights_col
    if cluster_col:
        fit_kwargs["cluster_col"] = cluster_col
    if entry_col:
        fit_kwargs["entry_col"] = entry_col

    if "robust" in params_fit:
        fit_kwargs["robust"] = bool(params_fit.get("robust"))
    if "batch_mode" in params_fit:
        fit_kwargs["batch_mode"] = params_fit.get("batch_mode")
    if "timeline" in params_fit and params_fit.get("timeline") is not None:
        fit_kwargs["timeline"] = _parse_numeric(params_fit.get("timeline"))
    if "initial_point" in params_fit and params_fit.get("initial_point") is not None:
        fit_kwargs["initial_point"] = _parse_numeric(params_fit.get("initial_point"))
    if "fit_options" in params_fit and params_fit.get("fit_options") is not None:
        fit_kwargs["fit_options"] = _parse_numeric(params_fit.get("fit_options"))
    formula = _resolve_formula(params_fit, {})
    if formula:
        fit_kwargs["formula"] = formula
    return fit_kwargs


def run_coxph_mode(executable: dict[str, Any], run_dir: Path, *, mode: str) -> dict[str, str]:
    try:
        import pandas as pd
    except ModuleNotFoundError as exc:
        raise RuntimeError("pandas is required to run CoxPH models") from exc

    try:
        from lifelines import CoxPHFitter
    except ModuleNotFoundError as exc:
        raise RuntimeError("lifelines is required to run CoxPH models") from exc

    template_id = _require_str(executable, "template_id")
    ds_id = _require_str(executable, "ds_id")
    as_id = _require_str(executable, "as_id")

    bindings = executable.get("bindings") or {}
    if not isinstance(bindings, dict):
        raise ValueError("bindings must be a dict")

    params = executable.get("params") or {}
    if not isinstance(params, dict):
        params = {}

    params_init = params.get("init") if isinstance(params.get("init"), dict) else {}
    params_fit = params.get("fit") if isinstance(params.get("fit"), dict) else {}
    params_preprocess = params.get("preprocess") if isinstance(params.get("preprocess"), dict) else {}

    duration_col = _resolve_column(bindings.get("time_to_event") or bindings.get("duration_col"))
    event_col = _resolve_column(bindings.get("event") or bindings.get("event_col"))
    lower_bound_col = _resolve_column(bindings.get("lower_bound_col"))
    upper_bound_col = _resolve_column(bindings.get("upper_bound_col"))

    covariates = bindings.get("covariates")
    if isinstance(covariates, list):
        covariates_list = [str(c) for c in covariates if isinstance(c, str) and c]
    else:
        covariates_list = []

    formula = _resolve_formula(params_fit, bindings)

    if formula and covariates_list:
        raise ValueError("Provide either covariates or formula, not both")
    if not formula and not covariates_list:
        raise ValueError("Missing covariates or formula")
    if formula and not _formulaic_available():
        raise ValueError("formula requires formulaic; install formulaic or provide covariates explicitly")

    weights_col = _resolve_column(params_fit.get("weights_col") or bindings.get("weights_col"))
    cluster_col = _resolve_column(params_fit.get("cluster_col") or bindings.get("cluster_col"))
    entry_col = _resolve_column(params_fit.get("entry_col") or bindings.get("entry_col"))

    fit_strata = _resolve_fit_strata(params_fit, params_init, bindings)
    init_strata = _resolve_init_strata(params_fit, params_init, bindings)

    # Resolve dataset CSV from DS blob (via store abstraction)
    ws_root = _infer_ws_root(run_dir)
    home = ensure_home(str(ws_root))
    csv_path = require_ds_data(home, ds_id)  # Path to CSV inside blobs/ds/<ds_id>/

    # Load + normalize columns
    df = pd.read_csv(csv_path, encoding="utf-8")
    df.columns = [_norm(str(c)) for c in df.columns]

    # normalize bindings to canonical columns
    duration_col = _norm(duration_col) if duration_col else None
    event_col = _norm(event_col) if event_col else None
    lower_bound_col = _norm(lower_bound_col) if lower_bound_col else None
    upper_bound_col = _norm(upper_bound_col) if upper_bound_col else None
    covariates_list = [_norm(c) for c in covariates_list]
    weights_col = _norm(weights_col) if weights_col else None
    cluster_col = _norm(cluster_col) if cluster_col else None
    entry_col = _norm(entry_col) if entry_col else None
    if fit_strata:
        fit_strata = [_norm(s) for s in fit_strata]
    if init_strata:
        init_strata = [_norm(s) for s in init_strata]

    if mode in {"right", "left"}:
        if duration_col is None:
            raise ValueError("Missing duration column")
    if mode == "interval":
        if lower_bound_col is None or upper_bound_col is None:
            raise ValueError("Interval censoring requires lower_bound_col and upper_bound_col")

    required = []
    if mode in {"right", "left"}:
        required.append(duration_col)
    if mode == "interval":
        required.extend([lower_bound_col, upper_bound_col])
    if event_col:
        required.append(event_col)
    required.extend(covariates_list)
    if weights_col:
        required.append(weights_col)
    if cluster_col:
        required.append(cluster_col)
    if entry_col:
        required.append(entry_col)
    if fit_strata:
        required.extend(fit_strata)
    if init_strata:
        required.extend(init_strata)

    _require_columns(df, required)

    if formula:
        work = df.copy()
    else:
        work = df[sorted(set(required), key=required.index)].copy()

    # coerce numeric durations/events/interval bounds
    if duration_col:
        work[duration_col] = pd.to_numeric(work[duration_col], errors="coerce")
    if event_col:
        work[event_col] = pd.to_numeric(work[event_col], errors="coerce")
    if lower_bound_col:
        work[lower_bound_col] = pd.to_numeric(work[lower_bound_col], errors="coerce")
    if upper_bound_col:
        work[upper_bound_col] = pd.to_numeric(work[upper_bound_col], errors="coerce")

    encode_categoricals = bool(params_preprocess.get("encode_categoricals", True))
    penalizer = _parse_penalizer(params_init.get("penalizer", 0.0))

    if isinstance(penalizer, list) and formula:
        raise ValueError("penalizer list requires explicit covariates (formula not supported)")

    if covariates_list and encode_categoricals:
        cat_cols = [c for c in covariates_list if str(work[c].dtype) in ("object", "category")]
        if isinstance(penalizer, list) and cat_cols:
            raise ValueError("penalizer list not supported when categorical encoding expands features")
        if cat_cols:
            work = pd.get_dummies(work, columns=cat_cols, drop_first=True)

    if isinstance(penalizer, list):
        excluded = {duration_col, event_col, lower_bound_col, upper_bound_col, weights_col, cluster_col, entry_col}
        if fit_strata:
            excluded.update(fit_strata)
        if init_strata:
            excluded.update(init_strata)
        feature_cols = [c for c in work.columns if c not in excluded]
        if len(penalizer) != len(feature_cols):
            raise ValueError(
                f"penalizer list length {len(penalizer)} does not match feature count {len(feature_cols)}"
            )

    drop_cols = required if formula else list(work.columns)
    work = work.dropna(axis=0, how="any", subset=drop_cols)

    if work.shape[0] == 0:
        raise ValueError("No rows left after filtering/NA drop for required columns")

    baseline_method = params_init.get("baseline_estimation_method", "breslow")
    if baseline_method not in ALLOWED_BASELINE_METHODS:
        raise ValueError("baseline_estimation_method must be one of: breslow, spline, piecewise")

    init_kwargs: dict[str, Any] = {
        "baseline_estimation_method": baseline_method,
        "penalizer": penalizer if penalizer is not None else 0.0,
        "l1_ratio": _parse_float(params_init.get("l1_ratio", 0.0)) or 0.0,
        "alpha": _parse_float(params_init.get("alpha", 0.05)) or 0.05,
    }
    if init_strata:
        init_kwargs["strata"] = init_strata

    n_baseline_knots = _parse_int(params_init.get("n_baseline_knots"))
    if n_baseline_knots is not None:
        init_kwargs["n_baseline_knots"] = n_baseline_knots

    if params_init.get("knots") is not None:
        init_kwargs["knots"] = _parse_numeric(params_init.get("knots"))
    if params_init.get("breakpoints") is not None:
        init_kwargs["breakpoints"] = _parse_numeric(params_init.get("breakpoints"))

    cph = CoxPHFitter(**init_kwargs)

    fit_kwargs = _build_fit_kwargs(
        mode=mode,
        duration_col=duration_col,
        event_col=event_col,
        lower_bound_col=lower_bound_col,
        upper_bound_col=upper_bound_col,
        fit_strata=fit_strata,
        weights_col=weights_col,
        cluster_col=cluster_col,
        entry_col=entry_col,
        params_fit=params_fit,
    )

    if formula:
        fit_kwargs["formula"] = formula

    if mode == "right":
        cph.fit(work, **fit_kwargs)
    elif mode == "left":
        cph.fit_left_censoring(work, **fit_kwargs)
    elif mode == "interval":
        cph.fit_interval_censoring(work, **fit_kwargs)
    else:
        raise ValueError(f"Unknown fit mode: {mode}")

    manifest: dict[str, str] = {}
    outputs = _extract_outputs(executable.get("outputs") or {})

    summary_payload: dict[str, Any] = {
        "template_id": template_id,
        "ds_id": ds_id,
        "as_id": as_id,
        "status": "success",
        "n_rows_used": int(work.shape[0]),
        "n_features_used": int(cph.summary.shape[0]) if hasattr(cph, "summary") else 0,
        "concordance_index": _safe_stat(lambda: getattr(cph, "concordance_index_", float("nan"))),
        "log_likelihood": _safe_stat(lambda: getattr(cph, "log_likelihood_", float("nan"))),
        "AIC": _safe_stat(lambda: cph.AIC_),
        "partial_AIC": _safe_stat(lambda: getattr(cph, "AIC_partial_", float("nan"))),
        "baseline_estimation_method": baseline_method,
        "penalizer": penalizer,
        "l1_ratio": float(init_kwargs.get("l1_ratio", 0.0)),
        "robust": bool(params_fit.get("robust", False)),
        "weights_col": weights_col,
        "cluster_col": cluster_col,
        "entry_col": entry_col,
        "strata_used": fit_strata or init_strata,
        "fit_mode": mode,
        "dataset_csv": str(csv_path.name),
    }

    written_outputs: list[str] = []

    summary_name = outputs.get("summary_json", "summary.json")
    summary_path = run_dir / summary_name
    summary_path.write_text(json.dumps(summary_payload, indent=2), encoding="utf-8")
    manifest["summary_json"] = summary_path.name
    written_outputs.append("summary_json")

    coeff_name = outputs.get("coefficients_csv", "coefficients.csv")
    coeff_path = run_dir / coeff_name
    summ = cph.summary.reset_index().rename(columns={"index": "covariate"})
    summ.to_csv(coeff_path, index=False)
    manifest["coefficients_csv"] = coeff_path.name
    written_outputs.append("coefficients_csv")

    baseline_hazard_path = outputs.get("baseline_hazard_csv")
    if baseline_hazard_path:
        if _maybe_write_df(run_dir / baseline_hazard_path, getattr(cph, "baseline_hazard_", None)):
            manifest["baseline_hazard_csv"] = baseline_hazard_path
            written_outputs.append("baseline_hazard_csv")

    baseline_cum_hazard_path = outputs.get("baseline_cumulative_hazard_csv")
    if baseline_cum_hazard_path:
        if _maybe_write_df(run_dir / baseline_cum_hazard_path, getattr(cph, "baseline_cumulative_hazard_", None)):
            manifest["baseline_cumulative_hazard_csv"] = baseline_cum_hazard_path
            written_outputs.append("baseline_cumulative_hazard_csv")

    baseline_survival_path = outputs.get("baseline_survival_csv")
    if baseline_survival_path:
        if _maybe_write_df(run_dir / baseline_survival_path, getattr(cph, "baseline_survival_", None)):
            manifest["baseline_survival_csv"] = baseline_survival_path
            written_outputs.append("baseline_survival_csv")

    diagnostics_path = outputs.get("diagnostics_json")
    if diagnostics_path:
        diagnostics_payload = {
            "concordance_index": summary_payload["concordance_index"],
            "log_likelihood": summary_payload["log_likelihood"],
            "AIC": summary_payload["AIC"],
            "partial_AIC": summary_payload["partial_AIC"],
        }
        diag_path = run_dir / diagnostics_path
        diag_path.write_text(json.dumps(diagnostics_payload, indent=2), encoding="utf-8")
        manifest["diagnostics_json"] = diag_path.name
        written_outputs.append("diagnostics_json")

    summary_payload["outputs_written"] = written_outputs
    summary_path.write_text(json.dumps(summary_payload, indent=2), encoding="utf-8")

    return manifest
