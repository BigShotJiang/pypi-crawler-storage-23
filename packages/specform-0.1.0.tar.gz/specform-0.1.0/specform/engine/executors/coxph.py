from __future__ import annotations

from pathlib import Path
from typing import Any

from .coxph_common import run_coxph_mode


TEMPLATE_ID_RIGHT = "survival.coxph.right.v1"
TEMPLATE_ID_INTERVAL = "survival.coxph.interval.v1"
TEMPLATE_ID_LEFT = "survival.coxph.left.v1"


def run_coxph_right_v1(executable: dict[str, Any], run_dir: Path) -> dict[str, str]:
    return run_coxph_mode(executable, run_dir, mode="right")


def run_coxph_interval_v1(executable: dict[str, Any], run_dir: Path) -> dict[str, str]:
    return run_coxph_mode(executable, run_dir, mode="interval")


def run_coxph_left_v1(executable: dict[str, Any], run_dir: Path) -> dict[str, str]:
    return run_coxph_mode(executable, run_dir, mode="left")
