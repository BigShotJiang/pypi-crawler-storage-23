from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from specform.engine.executors import EXECUTORS

def _write_error_summary(executable: dict[str, Any], run_dir: Path, err: Exception) -> dict[str, str]:
    outputs = executable.get("outputs") or {}
    if not isinstance(outputs, dict):
        outputs = {}
    summary_name = outputs.get("summary_json", "summary.json")
    summary_path = run_dir / summary_name
    payload = {
        "template_id": executable.get("template_id"),
        "ds_id": executable.get("ds_id"),
        "as_id": executable.get("as_id"),
        "status": "error",
        "error_type": type(err).__name__,
        "error_message": str(err),
    }
    summary_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    return {"summary_json": summary_path.name}

def run_executable(executable: dict[str, Any], run_dir: Path) -> dict[str, str]:
    template_id = executable.get("template_id")
    if not isinstance(template_id, str) or not template_id:
        raise ValueError("Executable missing template_id")

    params = executable.get("params") or {}
    if not isinstance(params, dict):
        params = {}

    if params.get("force_fail"):
        raise RuntimeError("Forced failure for testing")

    run_dir.mkdir(parents=True, exist_ok=True)

    try:
        fn = EXECUTORS.get(template_id)
        if not fn:
            raise ValueError(f"No executor registered for template_id={template_id!r}")
        manifest = fn(executable, run_dir)
        if not isinstance(manifest, dict):
            raise TypeError("Executor must return a manifest dict")
        return manifest
    except Exception as e:
        return _write_error_summary(executable, run_dir, e)
