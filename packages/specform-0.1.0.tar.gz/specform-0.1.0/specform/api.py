from __future__ import annotations

from pathlib import Path

from .sdk.run import RunResult
from .sdk.specform import Specform
from .core.store import load_er
from .ops import receipt_reproduce, resolve_home


def open(home: str | Path | None = None, author: str | None = None) -> Specform:
    """
    Convenience constructor for the Specform SDK.
    """
    return Specform(home=home, author=author)


def load_receipt(receipt_id: str, *, home: str | Path | None = None) -> RunResult:
    resolved_home = resolve_home(str(home) if home is not None else None)
    return RunResult(home=resolved_home, receipt=load_er(resolved_home, receipt_id))


def reproduce(receipt_id: str, *, home: str | Path | None = None, author: str | None = None) -> RunResult:
    resolved_home = resolve_home(str(home) if home is not None else None)
    result = receipt_reproduce(home=resolved_home, receipt_id=receipt_id, author=author)
    return RunResult(home=resolved_home, receipt=load_er(resolved_home, result["receipt_id"]))


__all__ = ["Specform", "open", "load_receipt", "reproduce"]
