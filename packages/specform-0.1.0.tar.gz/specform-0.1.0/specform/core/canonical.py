from __future__ import annotations

import json
import re
from typing import Any

_DEC_RE = re.compile(r"^[+-]?\d+(\.\d+)?$")

def _normalize_decimal_string(s: str) -> str:
    if not _DEC_RE.match(s):
        return s

    # strip leading +
    if s.startswith("+"):
        s = s[1:]

    sign = ""
    if s.startswith("-"):
        sign = "-"
        s = s[1:]

    if "." in s:
        whole, frac = s.split(".", 1)
        frac = frac.rstrip("0")
        if frac == "":
            s2 = whole
        else:
            s2 = f"{whole}.{frac}"
    else:
        s2 = s

    # normalize -0 / -0.0 / -000.000 -> 0
    stripped = s2.lstrip("0")
    if stripped == "" or stripped == ".":
        return "0"

    return sign + s2

def _normalize_obj(obj: Any) -> Any:
    if isinstance(obj, float):
        raise TypeError("canonical_dumps rejects float values; use decimal strings or integers")
    if isinstance(obj, dict):
        return {k: _normalize_obj(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_normalize_obj(v) for v in obj]
    if isinstance(obj, str):
        return _normalize_decimal_string(obj)
    return obj


def canonical_dumps(obj: Any) -> bytes:
    obj = _normalize_obj(obj)
    return json.dumps(
        obj,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
        allow_nan=False,
    ).encode("utf-8")
