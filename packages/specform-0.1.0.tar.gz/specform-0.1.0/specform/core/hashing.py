from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any

from .canonical import canonical_dumps


def sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_stream(path: Path, *, prefix: bytes = b"") -> str:
    """
    Compute sha256 over a file without loading it into memory.

    prefix:
        Optional domain-separation prefix, e.g. b"csv_stream_v0.1\\n"
    """
    h = hashlib.sha256()
    if prefix:
        h.update(prefix)
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def content_hash(obj: Any) -> str:
    """
    Hash a structured object deterministically via canonical JSON.
    """
    return f"sha256:{sha256_hex(canonical_dumps(obj))}"
