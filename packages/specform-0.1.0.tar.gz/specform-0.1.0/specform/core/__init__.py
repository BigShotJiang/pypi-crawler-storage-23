"""Core utilities for Specform Kernel."""
