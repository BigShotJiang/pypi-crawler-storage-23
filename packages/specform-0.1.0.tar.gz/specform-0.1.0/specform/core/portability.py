from __future__ import annotations

import json
import sys
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable

# ---------------------------------------------------------------------
# Debug: ALWAYS ON (stderr + a logfile inside the workspace)
# ---------------------------------------------------------------------

DEBUG_PORTABILITY = True  # flip to False when done

def _ts() -> str:
    return datetime.utcnow().isoformat(timespec="seconds") + "Z"

def _dbg(msg: str) -> None:
    if not DEBUG_PORTABILITY:
        return
    # IMPORTANT: tests parse stdout as JSON; stderr is safe
    print(f"[specform.portability] {msg}", file=sys.stderr, flush=True)

def _dbg_file(ws_root: Path, msg: str) -> None:
    if not DEBUG_PORTABILITY:
        return
    try:
        log_path = ws_root / ".specform" / "portability.debug.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with log_path.open("a", encoding="utf-8") as f:
            f.write(f"{_ts()} {msg}\n")
    except Exception:
        pass

# ---------------------------------------------------------------------
# Helpers: workspace + safe path handling
# ---------------------------------------------------------------------

def _normalize_home_to_ws_root(home: Path) -> Path:
    """
    Contract: Specform 'home' should be the workspace root that contains ".specform/".
    But callers might accidentally pass ".../.specform". Normalize that.
    """
    if home.name == ".specform":
        return home.parent
    return home

def _spec_dir(ws_root: Path) -> Path:
    return ws_root / ".specform"

def _iter_files(root: Path) -> Iterable[Path]:
    if not root.exists():
        return []
    for p in root.rglob("*"):
        if p.is_file():
            yield p

def _is_safe_relpath(name: str) -> bool:
    # zip uses "/" always
    name = name.replace("\\", "/").lstrip("./")
    parts = [p for p in name.split("/") if p not in ("", ".")]
    if any(p == ".." for p in parts):
        return False
    if name.startswith("/") or name.startswith("\\"):
        return False
    return True

def _same_bytes(dest: Path, src_bytes: bytes) -> bool:
    if not dest.exists():
        return False
    try:
        if dest.stat().st_size != len(src_bytes):
            return False
        return dest.read_bytes() == src_bytes
    except OSError:
        return False

def _normalize_pack_member(name: str) -> str:
    name = name.replace("\\", "/")
    if name.startswith("./"):
        name = name[2:]

    # Collapse repeated ".specform/" prefixes
    while name.startswith(".specform/.specform/"):
        name = name[len(".specform/"):]

    if name.startswith(".specform/"):
        return name
    if name.startswith("blobs/"):
        return ".specform/" + name
    if name == "registry.sqlite":
        return ".specform/registry.sqlite"

    return name

# ---------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------

@dataclass(frozen=True)
class ImportResult:
    imported: int
    skipped: int

def probe_er_locations(home: Path) -> dict:
    ws_root = _normalize_home_to_ws_root(home)
    candidates = [
        ws_root / ".specform" / "blobs" / "er",
        ws_root / ".specform" / ".specform" / "blobs" / "er",
        ws_root / "blobs" / "er",
    ]

    out = {"candidates": []}
    for d in candidates:
        ers = sorted([p.name for p in d.glob("er_*.json")]) if d.exists() else []
        out["candidates"].append(
            {"dir": str(d), "exists": d.exists(), "count": len(ers), "sample": ers[:5]}
        )
    return out

def create_sfpack(home: Path, out_path: Path, alias: str | None = None) -> dict:
    """
    v0.1 portability pack exports:
      - .specform/blobs/**  (ds/, as/, er/)
      - .specform/registry.sqlite (if exists)

    It exports the *whole blobs tree* (coarse but correct for MVP).
    """
    ws_root = _normalize_home_to_ws_root(home)
    spec = _spec_dir(ws_root)
    blobs_root = spec / "blobs"
    registry_path = spec / "registry.sqlite"

    _dbg(f"EXPORT ws_root={ws_root} out={out_path}")
    _dbg_file(ws_root, f"EXPORT ws_root={ws_root} out={out_path}")
    _dbg(f"EXPORT blobs_root={blobs_root} exists={blobs_root.exists()}")
    _dbg_file(ws_root, f"EXPORT blobs_root={blobs_root} exists={blobs_root.exists()}")

    er_dir = blobs_root / "er"
    if er_dir.exists():
        ers = sorted([p.name for p in er_dir.glob("er_*.json")])
        _dbg(f"EXPORT er_dir count={len(ers)} sample={ers[:10]}")
        _dbg_file(ws_root, f"EXPORT er_dir count={len(ers)} sample={ers[:10]}")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    if out_path.exists():
        out_path.unlink()

    manifest = {
        "format": "specform.sfpack",
        "version": "0.1",
        "alias": alias,
        "paths": [".specform/blobs/", ".specform/registry.sqlite"],
        "notes": "v0.1 exports full blobs tree; alias filtering is deferred.",
    }

    file_count = 0
    with zipfile.ZipFile(out_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("sfpack_manifest.json", json.dumps(manifest, sort_keys=True))

        # Export blobs
        for p in _iter_files(blobs_root):
            # IMPORTANT: store paths RELATIVE TO WORKSPACE ROOT
            arcname = str(p.relative_to(ws_root)).replace("\\", "/")
            zf.write(p, arcname=arcname)
            file_count += 1

        # Export registry if present
        if registry_path.exists():
            arcname = str(registry_path.relative_to(ws_root)).replace("\\", "/")
            zf.write(registry_path, arcname=arcname)
            file_count += 1

    # Verify zip contents (debug only)
    with zipfile.ZipFile(out_path, "r") as zf2:
        names = zf2.namelist()
        er_entries = [n for n in names if n.startswith(".specform/blobs/er/") and n.endswith(".json")]
        _dbg(f"EXPORT zip entries={len(names)} er_entries={len(er_entries)} sample={er_entries[:10]}")
        _dbg_file(ws_root, f"EXPORT zip entries={len(names)} er_entries={len(er_entries)} sample={er_entries[:10]}")

    return {"pack": str(out_path), "files": file_count, "manifest": manifest}

def import_sfpack(home: Path, pack_path: Path) -> ImportResult:
    """
    Idempotent import:
      - blobs: write only if missing or different
      - registry.sqlite: write only if missing (no merge in v0.1)

    Normalizes member paths to avoid extraction into wrong place.
    """
    ws_root = _normalize_home_to_ws_root(home)
    spec = _spec_dir(ws_root)

    if not pack_path.exists():
        raise FileNotFoundError(f"Pack not found: {pack_path}")

    _dbg(f"IMPORT ws_root={ws_root} pack={pack_path}")
    _dbg_file(ws_root, f"IMPORT ws_root={ws_root} pack={pack_path}")

    imported = 0
    skipped = 0

    with zipfile.ZipFile(pack_path, "r") as zf:
        # debug pack scan
        names = zf.namelist()
        er_entries = [n for n in names if "blobs/er/" in n and n.endswith(".json")]
        _dbg(f"IMPORT pack entries={len(names)} er_entries={len(er_entries)} sample={er_entries[:10]}")
        _dbg_file(ws_root, f"IMPORT pack entries={len(names)} er_entries={len(er_entries)} sample={er_entries[:10]}")

        for info in zf.infolist():
            raw_name = info.filename.replace("\\", "/")

            if raw_name == "sfpack_manifest.json":
                continue
            if info.is_dir() or raw_name.endswith("/"):
                continue

            name = _normalize_pack_member(raw_name)

            if not _is_safe_relpath(name):
                raise ValueError(f"Unsafe path in pack: raw={raw_name} normalized={name}")

            # force extraction UNDER workspace root
            dest = ws_root / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            data = zf.read(info.filename)

            _dbg(f"IMPORT member raw={raw_name} normalized={name} dest={dest}")
            _dbg_file(ws_root, f"IMPORT member raw={raw_name} normalized={name} dest={dest}")

            # Registry: don't overwrite existing
            # Registry: overwrite ONLY if the existing file is empty (fresh workspace touched by ensure_home)
            if name == ".specform/registry.sqlite":
                if dest.exists():
                    try:
                        if dest.stat().st_size > 0:
                            skipped += 1
                            continue
                    except OSError:
                        skipped += 1
                        continue
                dest.write_bytes(data)
                imported += 1
                continue

            # Normal idempotent copy
            if dest.exists() and _same_bytes(dest, data):
                skipped += 1
                continue

            dest.write_bytes(data)
            imported += 1

    # Ensure spec layout exists (tests assume dirs exist)
    (spec / "blobs" / "ds").mkdir(parents=True, exist_ok=True)
    (spec / "blobs" / "as").mkdir(parents=True, exist_ok=True)
    (spec / "blobs" / "er").mkdir(parents=True, exist_ok=True)

    # Post-import probe
    er_dir = spec / "blobs" / "er"
    ers = sorted([p.name for p in er_dir.glob("er_*.json")]) if er_dir.exists() else []
    _dbg(f"IMPORT post er_dir={er_dir} count={len(ers)} sample={ers[:10]}")
    _dbg_file(ws_root, f"IMPORT post er_dir={er_dir} count={len(ers)} sample={ers[:10]}")
    _dbg(f"IMPORT done imported={imported} skipped={skipped}")
    _dbg_file(ws_root, f"IMPORT done imported={imported} skipped={skipped}")

    return ImportResult(imported=imported, skipped=skipped)
