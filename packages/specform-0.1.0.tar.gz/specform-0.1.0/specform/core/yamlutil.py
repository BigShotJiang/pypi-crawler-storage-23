from __future__ import annotations

import json
from typing import Any

try:
    import yaml  # type: ignore
except Exception:  # pragma: no cover
    yaml = None


def load_yaml(text: str) -> Any:
    if yaml:
        return yaml.safe_load(text)
    return json.loads(text)


def dump_yaml(data: Any) -> str:
    if yaml:
        return yaml.safe_dump(data, sort_keys=False)
    return json.dumps(data, indent=2)
