class SpecformError(Exception):
    pass


class ValidationError(SpecformError):
    def __init__(self, issues: list[str]):
        super().__init__("Validation failed")
        self.issues = issues


class SpecformUserError(SpecformError):
    """
    A deliberate, user-facing failure.
    """

    def __init__(
        self,
        issues: list[str],
        hint: str | None = None,
        code: int = 1,
        type: str = "user_error",
    ) -> None:
        super().__init__("User error")
        self.issues = issues
        self.hint = hint
        self.code = code
        self.type = type

    def to_json(self, *, debug: bool = False, tb: str | None = None) -> dict[str, object]:
        payload: dict[str, object] = {
            "status": "validation_failed",
            "type": self.type,
            "issues": self.issues,
        }
        if self.hint:
            payload["hint"] = self.hint
        if debug and tb:
            payload["traceback"] = tb
        return payload
