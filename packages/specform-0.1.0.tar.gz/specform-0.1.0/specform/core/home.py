from __future__ import annotations

import os
from pathlib import Path

def resolve_home(home_override: str | None) -> Path:
    if home_override:
        root = Path(home_override).expanduser().resolve()
    else:
        env_home = os.environ.get("SPECFORM_HOME")
        if env_home:
            root = Path(env_home).expanduser().resolve()
        else:
            root = _find_existing_home(Path.cwd())
            if root is None:
                root = Path.cwd().resolve()
    if root.name == ".specform":
        root = root.parent
    return root
def ensure_home(home_override: str | None) -> Path:
    root = resolve_home(home_override)
    specform_dir = root / ".specform"
    _ensure_layout(specform_dir)
    return root




def _find_existing_home(start: Path) -> Path | None:
    current = start.resolve()
    for parent in [current, *current.parents]:
        if (parent / ".specform").exists():
            return parent
    return None


def _ensure_layout(specform_dir: Path) -> None:
    (specform_dir / "blobs" / "ds").mkdir(parents=True, exist_ok=True)
    (specform_dir / "blobs" / "as").mkdir(parents=True, exist_ok=True)
    (specform_dir / "blobs" / "er").mkdir(parents=True, exist_ok=True)
    (specform_dir / "drafts" / "as").mkdir(parents=True, exist_ok=True)
    (specform_dir / "runs").mkdir(parents=True, exist_ok=True)
    registry_path = specform_dir / "registry.sqlite"
    if not registry_path.exists():
        registry_path.touch()
