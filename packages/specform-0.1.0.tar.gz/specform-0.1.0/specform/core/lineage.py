from __future__ import annotations

import json
import logging
import os
import secrets
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .timeutil import utc_now

LOGGER = logging.getLogger(__name__)


def _normalize_home(home: Path) -> Path:
    if home.name == ".specform":
        return home.parent
    return home


def _new_event_id() -> str:
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    return f"{stamp}_{secrets.token_hex(4)}"


class LineageStore:
    def __init__(self, home: Path) -> None:
        self._home = _normalize_home(home)

    def _events_root(self) -> Path:
        return self._home / ".specform" / "lineage" / "events"

    def ensure_dirs(self) -> None:
        root = self._events_root()
        for name in ("ds_seen", "ds_edge", "import_pack"):
            (root / name).mkdir(parents=True, exist_ok=True)

    def write_event(self, event_type: str, payload: dict[str, Any], author: str | None = None) -> Path:
        self.ensure_dirs()
        event_id = _new_event_id()
        event_dir = self._events_root() / event_type
        event = {
            "schema_version": 1,
            "event_id": event_id,
            "event_type": event_type,
            "created_at": utc_now(),
            "author": author or "",
            "payload": payload,
        }

        event_dir.mkdir(parents=True, exist_ok=True)
        final_path = event_dir / f"{event_id}.json"
        tmp_path: Path | None = None
        try:
            with tempfile.NamedTemporaryFile(
                "w",
                encoding="utf-8",
                dir=event_dir,
                prefix=f".{event_id}.",
                suffix=".tmp",
                delete=False,
            ) as handle:
                tmp_path = Path(handle.name)
                json.dump(event, handle, ensure_ascii=False, sort_keys=True)
                handle.write("\n")
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_path, final_path)
        except Exception:
            if tmp_path and tmp_path.exists():
                try:
                    tmp_path.unlink()
                except OSError:
                    pass
            raise

        return final_path

    def safe_write_event(self, event_type: str, payload: dict[str, Any], author: str | None = None) -> Path | None:
        try:
            return self.write_event(event_type, payload, author=author)
        except Exception:
            LOGGER.debug("Lineage event write failed", exc_info=True)
            return None


def generate_lineage_id() -> str:
    return _new_event_id()
