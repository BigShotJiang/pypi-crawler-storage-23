from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

from .canonical import canonical_dumps
from .hashing import content_hash, sha256_stream
from .timeutil import utc_now

HASH_STRIP_KEYS = {"ds_hash", "as_hash", "er_hash"}  # hashes
ID_STRIP_KEYS = {"ds_id", "as_id", "er_id"}          # ids you generate
NON_CONTENT_KEYS = {"note"}  # metadata that must not affect hashing

def _strip_hash_fields(obj: dict[str, Any]) -> dict[str, Any]:
    return {
        k: v
        for k, v in obj.items()
        if k not in HASH_STRIP_KEYS and k not in ID_STRIP_KEYS and k not in NON_CONTENT_KEYS
    }



def compute_object_hash(obj: dict[str, Any]) -> str:
    return content_hash(_strip_hash_fields(obj))


def ds_blob_dir(home: Path, ds_id: str) -> Path:
    return home / ".specform" / "blobs" / "ds" / ds_id


def as_blob_path(home: Path, as_id: str) -> Path:
    return home / ".specform" / "blobs" / "as" / f"{as_id}.json"


def er_blob_path(home: Path, er_id: str) -> Path:
    return home / ".specform" / "blobs" / "er" / f"{er_id}.json"

from .hashing import sha256_hex  # you already have this in cli, but import here
# or import content_hash helpers if you prefer

def verify_ds_fingerprint(home: Path, ds_id: str) -> None:
    ds = load_ds(home, ds_id)
    fp = ds.get("fingerprint")
    algo = ds.get("fingerprint_algo")
    if not fp or not algo:
        # conservative: if missing metadata, treat as unverifiable
        raise FileNotFoundError(f"Dataset fingerprint metadata missing for {ds_id}")

    data_path = require_ds_data(home, ds_id)
    data = data_path.read_bytes()


    if algo == "csv_stream_v0.1":
        prefix = b"csv_stream_v0.1\n"
        digest = sha256_stream(data_path, prefix=prefix)
        got = f"sha256:{digest}"
    elif algo == "csv_canonical_v0.1":
        prefix = b"csv_canonical_v0.1\n"
        got = f"sha256:{sha256_hex(prefix + data)}"
    else:
        raise ValueError(f"Unknown fingerprint_algo: {algo}")

    if got != fp:
        raise ValueError(f"Dataset bytes corrupted for {ds_id}: fingerprint mismatch")

def write_ds_blob(home: Path, ds: dict[str, Any], data_path: Path) -> Path:
    ds_hash = compute_object_hash(ds)
    ds["ds_hash"] = ds_hash
    ds_id = ds["ds_id"]
    blob_dir = ds_blob_dir(home, ds_id)
    blob_dir.mkdir(parents=True, exist_ok=True)
    ds_json_path = blob_dir / "ds.json"
    ds_json_path.write_bytes(canonical_dumps(ds))
    ext = data_path.suffix.lstrip(".") or "data"
    blob_data_path = blob_dir / f"data.{ext}"
    if not blob_data_path.exists():
        shutil.copyfile(data_path, blob_data_path)
    return ds_json_path


def load_ds(home: Path, ds_id: str) -> dict[str, Any]:
    ds_json_path = ds_blob_dir(home, ds_id) / "ds.json"
    return json.loads(ds_json_path.read_text())


def write_as_blob(home: Path, as_spec: dict[str, Any]) -> tuple[str, Path]:
    as_hash = compute_object_hash(as_spec)
    as_spec["as_hash"] = as_hash
    as_id = as_spec["as_id"]
    path = as_blob_path(home, as_id)
    path.write_bytes(canonical_dumps(as_spec))
    return as_id, path


def load_as(home: Path, as_id: str) -> dict[str, Any]:
    path = as_blob_path(home, as_id)
    return json.loads(path.read_text())


def write_er_blob(home: Path, er_spec: dict[str, Any]) -> tuple[str, Path]:
    er_hash = compute_object_hash(er_spec)
    er_spec["er_hash"] = er_hash
    er_id = er_spec["er_id"]
    path = er_blob_path(home, er_id)
    path.write_bytes(canonical_dumps(er_spec))
    return er_id, path


def load_er(home: Path, er_id: str) -> dict[str, Any]:
    path = er_blob_path(home, er_id)
    return json.loads(path.read_text())

def ds_data_present(home: Path, ds_id: str) -> bool:
    return len(ds_data_paths(home, ds_id)) > 0


def require_ds_data(home: Path, ds_id: str) -> Path:
    """
    Returns a usable dataset blob path or raises a clear error.
    """
    paths = ds_data_paths(home, ds_id)
    if not paths:
        raise FileNotFoundError(f"Dataset bytes missing for {ds_id} (no data blob found in {ds_blob_dir(home, ds_id)})")
    return paths[0]


def new_ds_object(
    ds_id: str,
    fingerprint: str,
    fingerprint_algo: str,
    schema: dict[str, Any],
    profile: dict[str, Any],
    author: str,
    note: str | None = None,
) -> dict[str, Any]:
    return {
        "ds_id": ds_id,
        "ds_hash": None,
        "created_at": utc_now(),
        "author": author,
        "note": note,
        "fingerprint": fingerprint,
        "fingerprint_algo": fingerprint_algo,
        "format": "csv" if schema.get("columns") else "unknown",
        "schema": schema,
        "profile": profile,
    }
def ds_data_paths(home: Path, ds_id: str) -> list[Path]:
    """
    Returns all candidate data files stored for a DS.
    Supports both data and data.<ext>.
    """
    blob_dir = ds_blob_dir(home, ds_id)
    candidates: list[Path] = []
    p = blob_dir / "data"
    if p.exists() and p.is_file():
        candidates.append(p)
    candidates.extend(sorted([x for x in blob_dir.glob("data.*") if x.is_file()]))
    return candidates
