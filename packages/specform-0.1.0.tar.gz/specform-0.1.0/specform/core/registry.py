from __future__ import annotations

import json
import sqlite3
from pathlib import Path
from typing import Any

from .timeutil import utc_now


class Registry:
    def __init__(self, home: Path):
        self.db_path = home / ".specform" / "registry.sqlite"
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS aliases (
                    alias_name TEXT,
                    alias_type TEXT CHECK (alias_type IN ('dataset','spec')),
                    current_target_id TEXT,
                    updated_at TEXT,
                    PRIMARY KEY (alias_name, alias_type)
                );
                CREATE TABLE IF NOT EXISTS alias_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    alias_name TEXT,
                    alias_type TEXT,
                    target_id TEXT,
                    created_at TEXT,
                    author TEXT,
                    meta_json TEXT
                );
                CREATE TABLE IF NOT EXISTS receipts (
                    receipt_id TEXT PRIMARY KEY,
                    run_id TEXT,
                    created_at TEXT,
                    started_at TEXT,
                    finished_at TEXT,
                    ds_id TEXT,
                    as_id TEXT,
                    status TEXT,
                    author TEXT
                );
                CREATE TABLE IF NOT EXISTS runs (
                    run_id TEXT PRIMARY KEY,
                    created_at TEXT,
                    ds_id TEXT,
                    as_id TEXT,
                    er_id TEXT,
                    status TEXT,
                    author TEXT
                );
                CREATE TABLE IF NOT EXISTS ds_index (
                    fingerprint_hash TEXT PRIMARY KEY,
                    ds_id TEXT
                );
                """
            )
            self._migrate_aliases_pk(conn)

    def _migrate_aliases_pk(self, conn: sqlite3.Connection) -> None:
        row = conn.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='aliases'"
        ).fetchone()
        if not row:
            return
        info = conn.execute("PRAGMA table_info(aliases)").fetchall()
        pk_cols = [col["name"] for col in info if col["pk"]]
        if set(pk_cols) == {"alias_name", "alias_type"} and len(pk_cols) == 2:
            return
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS aliases_new (
                alias_name TEXT,
                alias_type TEXT CHECK (alias_type IN ('dataset','spec')),
                current_target_id TEXT,
                updated_at TEXT,
                PRIMARY KEY (alias_name, alias_type)
            )
            """
        )
        conn.execute("DELETE FROM aliases_new")
        conn.execute(
            """
            INSERT INTO aliases_new (alias_name, alias_type, current_target_id, updated_at)
            SELECT alias_name, alias_type, current_target_id, updated_at
            FROM aliases
            """
        )
        conn.execute("DROP TABLE aliases")
        conn.execute("ALTER TABLE aliases_new RENAME TO aliases")

    def get_alias(self, alias_name: str, alias_type: str) -> str | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT current_target_id FROM aliases WHERE alias_name=? AND alias_type=?",
                (alias_name, alias_type),
            ).fetchone()
        if row:
            return row["current_target_id"]
        return None

    def set_alias(self, alias_name: str, alias_type: str, target_id: str, author: str, meta: dict) -> None:
        created_at = utc_now()
        meta_json = json.dumps(meta, sort_keys=True)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO aliases (alias_name, alias_type, current_target_id, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(alias_name, alias_type) DO UPDATE SET
                    current_target_id=excluded.current_target_id,
                    updated_at=excluded.updated_at
                """,
                (alias_name, alias_type, target_id, created_at),
            )
            conn.execute(
                """
                INSERT INTO alias_events (alias_name, alias_type, target_id, created_at, author, meta_json)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (alias_name, alias_type, target_id, created_at, author, meta_json),
            )

    def append_alias_event(
        self,
        alias_name: str,
        alias_type: str,
        target_id: str,
        author: str,
        meta: dict,
        *,
        update_current: bool = True,
    ) -> None:
        created_at = utc_now()
        meta_json = json.dumps(meta, sort_keys=True)
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO alias_events (alias_name, alias_type, target_id, created_at, author, meta_json)
                VALUES (?, ?, ?, ?, ?, ?)
                """,
                (alias_name, alias_type, target_id, created_at, author, meta_json),
            )
            if update_current:
                conn.execute(
                    """
                    INSERT INTO aliases (alias_name, alias_type, current_target_id, updated_at)
                    VALUES (?, ?, ?, ?)
                    ON CONFLICT(alias_name, alias_type) DO UPDATE SET
                        current_target_id=excluded.current_target_id,
                        updated_at=excluded.updated_at
                    """,
                    (alias_name, alias_type, target_id, created_at),
                )
            else:
                row = conn.execute(
                    "SELECT 1 FROM aliases WHERE alias_name=? AND alias_type=?",
                    (alias_name, alias_type),
                ).fetchone()
                if row:
                    conn.execute(
                        """
                        UPDATE aliases
                        SET updated_at=?
                        WHERE alias_name=? AND alias_type=?
                        """,
                        (created_at, alias_name, alias_type),
                    )

    def alias_events(self, alias_name: str, alias_type: str) -> list[sqlite3.Row]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT * FROM alias_events
                WHERE alias_name=? AND alias_type=?
                ORDER BY created_at ASC, id ASC
                """,
                (alias_name, alias_type),
            ).fetchall()
        return rows

    def list_aliases(self, *, alias_type: str | None = None) -> list[dict[str, Any]]:
        with self._connect() as conn:
            if alias_type is None:
                rows = conn.execute(
                    """
                    SELECT alias_name, alias_type, current_target_id, updated_at
                    FROM aliases
                    ORDER BY alias_name ASC
                    """
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT alias_name, alias_type, current_target_id, updated_at
                    FROM aliases
                    WHERE alias_type=?
                    ORDER BY alias_name ASC
                    """,
                    (alias_type,),
                ).fetchall()
        return [dict(row) for row in rows]

    def list_alias_names(self, *, alias_type: str) -> list[str]:
        aliases = self.list_aliases(alias_type=alias_type)
        return [row["alias_name"] for row in aliases]

    def insert_receipt(
        self,
        receipt_id: str,
        run_id: str,
        created_at: str,
        started_at: str,
        finished_at: str,
        ds_id: str,
        as_id: str,
        status: str,
        author: str,
    ) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO receipts (
                    receipt_id, run_id, created_at, started_at, finished_at, ds_id, as_id, status, author
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (receipt_id, run_id, created_at, started_at, finished_at, ds_id, as_id, status, author),
            )

    def insert_run(self, run_id: str, created_at: str, ds_id: str, as_id: str, er_id: str, status: str, author: str) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO runs (run_id, created_at, ds_id, as_id, er_id, status, author)
                VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (run_id, created_at, ds_id, as_id, er_id, status, author),
            )

    def get_ds_by_fingerprint(self, fingerprint_hash: str) -> str | None:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT ds_id FROM ds_index WHERE fingerprint_hash=?",
                (fingerprint_hash,),
            ).fetchone()
        if row:
            return row["ds_id"]
        return None

    def add_ds_index(self, fingerprint_hash: str, ds_id: str) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                INSERT OR IGNORE INTO ds_index (fingerprint_hash, ds_id)
                VALUES (?, ?)
                """,
                (fingerprint_hash, ds_id),
            )

    def alias_type_exists(self, alias_name: str, alias_type: str) -> bool:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT 1 FROM alias_events WHERE alias_name=? AND alias_type=? LIMIT 1",
                (alias_name, alias_type),
            ).fetchone()
        return row is not None

    def all_alias_types(self, alias_name: str) -> list[str]:
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT DISTINCT alias_type FROM alias_events WHERE alias_name=?",
                (alias_name,),
            ).fetchall()
        return [row["alias_type"] for row in rows]

    def get_receipt(self, receipt_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM receipts WHERE receipt_id=?", (receipt_id,)).fetchone()
        return dict(row) if row else None

    def receipts_for_as(self, as_id: str, *, limit: int | None = None) -> list[dict[str, Any]]:
        query = "SELECT * FROM receipts WHERE as_id=? ORDER BY finished_at DESC, created_at DESC"
        params: list[Any] = [as_id]
        if limit is not None:
            query += " LIMIT ?"
            params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]

    def receipts_for_ds(self, ds_id: str, *, limit: int | None = None) -> list[dict[str, Any]]:
        query = "SELECT * FROM receipts WHERE ds_id=? ORDER BY finished_at DESC, created_at DESC"
        params: list[Any] = [ds_id]
        if limit is not None:
            query += " LIMIT ?"
            params.append(limit)
        with self._connect() as conn:
            rows = conn.execute(query, params).fetchall()
        return [dict(row) for row in rows]

    def get_run(self, run_id: str) -> dict[str, Any] | None:
        with self._connect() as conn:
            row = conn.execute("SELECT * FROM runs WHERE run_id=?", (run_id,)).fetchone()
        return dict(row) if row else None
