from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from .. import ops
from ..core.store import ds_data_present, load_ds, require_ds_data, verify_ds_fingerprint
from .history import HistoryView


class DatasetVersion:
    """
    Immutable handle to a dataset snapshot.
    """

    def __init__(self, *, home: Path, ds: dict[str, Any]) -> None:
        self._home = home
        self._ds = ds

    @property
    def raw(self) -> dict[str, Any]:
        return self._ds

    @property
    def ds_id(self) -> str:
        return str(self._ds.get("ds_id"))

    @property
    def fingerprint_short(self) -> str:
        fp = self._ds.get("fingerprint", "")
        if not fp:
            return ""
        return fp.split(":", 1)[1][:12]

    @property
    def row_count(self) -> int | None:
        profile = self._ds.get("profile", {})
        if isinstance(profile, dict):
            return profile.get("row_count")
        return None

    @property
    def columns(self) -> list[str]:
        schema = self._ds.get("schema", {})
        if not isinstance(schema, dict):
            return []
        cols = schema.get("columns")
        if isinstance(cols, list):
            return [str(c) for c in cols]
        return []

    @property
    def presence(self) -> str:
        return "present" if ds_data_present(self._home, self.ds_id) else "missing"

    def df(self, **read_kwargs: Any) -> Any:
        """
        Load this dataset snapshot into a pandas DataFrame.
        """
        import pandas as pd

        data_path = require_ds_data(self._home, self.ds_id)
        return pd.read_csv(data_path, **read_kwargs)

    def __repr__(self) -> str:
        return f"DatasetVersion(ds_id={self.ds_id!r}, row_count={self.row_count!r})"


class DatasetRef:
    """
    Dataset alias reference (cyclable via alias events).
    """

    def __init__(self, sf: "Specform", alias: str) -> None:
        self._sf = sf
        self._alias = alias
        self._pending_note: str | None = None

    @property
    def alias(self) -> str:
        return self._alias

    def note(self, note: str) -> "DatasetRef":
        self._pending_note = note
        return self

    def _consume_note(self, note: str | None) -> str | None:
        if note is not None:
            self._pending_note = None
            return note
        pending = self._pending_note
        self._pending_note = None
        return pending

    def add(self, path: str | Path, *, note: str | None = None, return_version: bool = False) -> "DatasetRef | DatasetVersion":
        """
        Add a dataset snapshot from a CSV file path.

        Notes are stored as metadata and do not affect fingerprints.
        """
        resolved_note = self._consume_note(note)
        res = ops.dataset_add(
            home=self._sf.home,
            path=path,
            alias=self._alias,
            note=resolved_note,
            author=self._sf.author,
        )
        if return_version:
            ds = load_ds(self._sf.home, res["ds_id"])
            return DatasetVersion(home=self._sf.home, ds=ds)
        return self

    def add_version(self, path: str | Path, *, note: str | None = None) -> DatasetVersion:
        return self.add(path, note=note, return_version=True)

    def use(self, version: int | str, *, note: str | None = None) -> DatasetVersion:
        resolved_note = self._consume_note(note)
        if resolved_note is None and isinstance(version, str):
            if version == "prev":
                resolved_note = "rollback to prev"
            elif version == "latest":
                resolved_note = "jump to latest"
        res = ops.dataset_use(
            home=self._sf.home,
            alias=self._alias,
            version=version,
            note=resolved_note,
            author=self._sf.author,
        )
        ds = load_ds(self._sf.home, res["target_id"])
        return DatasetVersion(home=self._sf.home, ds=ds)

    def df(self, version: int | str | None = None, **read_kwargs: Any) -> Any:
        """
        Load a dataset snapshot into a pandas DataFrame without mutating alias pointers.

        Notes are metadata and do not affect fingerprints or identity.
        """
        return ops.dataset_load_df(home=self._sf.home, alias=self._alias, version=version, **read_kwargs)

    def to_csv(
        self,
        out_path: str | Path,
        *,
        version: int | str | None = None,
        index: bool = False,
        **to_csv_kwargs: Any,
    ) -> Path:
        """
        Export a dataset snapshot to CSV without mutating alias pointers.
        """
        if to_csv_kwargs or index:
            df = self.df(version=version)
            df.to_csv(out_path, index=index, **to_csv_kwargs)
            return Path(out_path)
        return ops.dataset_export_csv(home=self._sf.home, alias=self._alias, out_path=out_path, version=version)

    def add_df(
        self,
        df: Any,
        *,
        note: str | None = None,
        filename: str = "data.csv",
        return_version: bool = False,
    ) -> "DatasetRef | DatasetVersion":
        """
        Checkpoint a pandas DataFrame as a new dataset snapshot under this alias.

        Notes are stored as metadata and do not affect fingerprints.
        """
        resolved_note = self._consume_note(note)
        res = ops.dataset_add_df(
            home=self._sf.home,
            alias=self._alias,
            df=df,
            note=resolved_note,
            author=self._sf.author,
            filename=filename,
        )
        if return_version:
            ds = load_ds(self._sf.home, res["ds_id"])
            return DatasetVersion(home=self._sf.home, ds=ds)
        return self

    def checkpoint(
        self,
        df: Any,
        *,
        note: str | None = None,
        filename: str = "data.csv",
        return_version: bool = False,
    ) -> "DatasetRef | DatasetVersion":
        return self.add_df(df, note=note, filename=filename, return_version=return_version)

    def merge_from(
        self,
        incoming: str | "DatasetRef",
        *,
        note: str | None = None,
        dry_run: bool = False,
    ) -> "DatasetRef | dict[str, Any]":
        incoming_alias = incoming.alias if isinstance(incoming, DatasetRef) else incoming
        resolved_note = self._consume_note(note)
        report = ops.dataset_alias_merge(
            home=self._sf.home,
            into=self._alias,
            incoming=incoming_alias,
            note=resolved_note,
            author=self._sf.author,
            dry_run=dry_run,
        )
        if dry_run:
            return report
        return self

    def current(self) -> DatasetVersion | None:
        ds_id = ops.dataset_current(home=self._sf.home, alias=self._alias)
        if not ds_id:
            return None
        ds = load_ds(self._sf.home, ds_id)
        return DatasetVersion(home=self._sf.home, ds=ds)

    def history(self) -> HistoryView:
        return HistoryView(ops.dataset_history(home=self._sf.home, name=self._alias))

    def version(self, version: int) -> DatasetVersion:
        rows = ops.dataset_history(home=self._sf.home, name=self._alias)
        if version < 1 or version > len(rows):
            raise ValueError(f"Version out of range: {version}")
        ds_id = rows[version - 1]["target_id"]
        ds = load_ds(self._sf.home, ds_id)
        return DatasetVersion(home=self._sf.home, ds=ds)

    def v(self, version: int | str) -> DatasetVersion:
        if isinstance(version, str):
            return self.version(int(version))
        return self.version(version)

    def head(self, n: int = 5) -> Any:
        return self.df().head(n)

    def show(self, n: int = 5) -> Any:
        head = self.df().head(n)
        print(head)
        return head

    def describe(self, **kwargs: Any) -> Any:
        if "include" not in kwargs:
            kwargs["include"] = "all"
        return self.df().describe(**kwargs)

    def verify_current(self) -> None:
        current = self.current()
        if current is None:
            return None
        verify_ds_fingerprint(self._sf.home, current.ds_id)
        return None


if TYPE_CHECKING:
    from .specform import Specform
