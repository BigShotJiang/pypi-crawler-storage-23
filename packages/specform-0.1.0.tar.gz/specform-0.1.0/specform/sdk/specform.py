from __future__ import annotations

from pathlib import Path
from typing import Any

from .. import ops
from ..core.store import load_er
from .bundle import BundleReport, DataBundle, ImportReport
from .dataset import DatasetRef, DatasetVersion
from .run import RunResult
from .spec import DraftSpec, SpecRef


class Specform:
    """
    Object-first Specform SDK.
    """

    def __init__(self, home: str | Path | None = None, author: str | None = None) -> None:
        self._home = ops.resolve_home(str(home) if home is not None else None)
        self._author = author

    @property
    def home(self) -> Path:
        return self._home

    @property
    def author(self) -> str | None:
        return self._author

    def dataset(self, alias: str) -> DatasetRef:
        return DatasetRef(self, alias)

    def spec(self, alias: str) -> SpecRef:
        return SpecRef(self, alias)

    def draft(self, name: str) -> DraftSpec:
        draft = ops.draft_load(home=self._home, name=name)
        return DraftSpec(sf=self, name=name, draft=draft)

    def drafts(self) -> list[dict[str, Any]]:
        return ops.draft_list(home=self._home)

    def datasets(self) -> list[str]:
        return ops.dataset_aliases_list(home=self._home)

    def specs(self) -> list[str]:
        return ops.spec_aliases_list(home=self._home)

    def aliases(self) -> dict[str, list[str]]:
        return {"datasets": self.datasets(), "specs": self.specs()}

    def reproduce(self, receipt_id: str) -> RunResult:
        result = ops.receipt_reproduce(home=self._home, receipt_id=receipt_id, author=self._author)
        receipt = load_er(self._home, result["receipt_id"])
        return RunResult(home=self._home, receipt=receipt)

    def load_receipt(self, receipt_id: str) -> RunResult:
        receipt = load_er(self._home, receipt_id)
        return RunResult(home=self._home, receipt=receipt)

    def export(self, out: str | Path, *, alias: str | None = None) -> dict[str, Any]:
        return ops.export_pack(home=self._home, out=out, alias=alias)

    def import_pack(self, path: str | Path) -> dict[str, Any]:
        return ops.import_pack(home=self._home, pack=path)

    def doctor(self, *, verify: bool = False, sample: int = 20) -> dict[str, Any]:
        return ops.doctor(home=self._home, verify=verify, sample=sample)

    def data_bundle(self, name: str, *items: str | DatasetRef | DatasetVersion) -> DataBundle:
        resolved: list[str] = []
        for item in items:
            if isinstance(item, DatasetRef):
                resolved.append(item.alias)
            elif isinstance(item, DatasetVersion):
                resolved.append(item.ds_id)
            else:
                resolved.append(str(item))
        plan = ops.bundle_prepare(home=self._home, name=name, items=resolved)
        return DataBundle(home=self._home, name=name, plan=plan, author=self._author)

    def inspect_data_bundle(self, path: str | Path) -> BundleReport:
        report = ops.bundle_inspect(home=self._home, path=path)
        return BundleReport(
            manifest=report["manifest"],
            datasets=report["datasets"],
            aliases=report["aliases"],
        )

    def import_data_bundle(
        self,
        path: str | Path,
        *,
        aliases: str = "recreate",
        conflict: str = "rename",
    ) -> ImportReport:
        report = ops.bundle_import(
            home=self._home,
            path=path,
            aliases=aliases,
            conflict=conflict,
            author=self._author,
        )
        return ImportReport(
            imported_count=report["imported_count"],
            reused_count=report["reused_count"],
            ds_mapping=report["ds_mapping"],
            alias_results=report["alias_results"],
            warnings=report["warnings"],
        )
