from __future__ import annotations

import importlib.util
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .. import ops


@dataclass(frozen=True)
class BundleReport:
    manifest: dict[str, Any]
    datasets: list[dict[str, Any]]
    aliases: list[dict[str, Any]]

    def to_df(self) -> Any:
        if importlib.util.find_spec("pandas") is None:
            return {"datasets": self.datasets, "aliases": self.aliases}
        import pandas as pd

        return {
            "datasets": pd.DataFrame(self.datasets),
            "aliases": pd.DataFrame(self.aliases),
        }

    def __repr__(self) -> str:
        return f"BundleReport(datasets={len(self.datasets)}, aliases={len(self.aliases)})"

    def _repr_html_(self) -> str:
        frames = self.to_df()
        if isinstance(frames, dict) and "datasets" in frames and hasattr(frames["datasets"], "to_html"):
            ds_html = frames["datasets"].to_html(index=False)
            alias_html = frames["aliases"].to_html(index=False)
            return f"<h4>Datasets</h4>{ds_html}<h4>Aliases</h4>{alias_html}"
        return f"<pre>{self!r}</pre>"


@dataclass(frozen=True)
class ImportReport:
    imported_count: int
    reused_count: int
    ds_mapping: list[dict[str, Any]]
    alias_results: list[dict[str, Any]]
    warnings: list[str]

    def to_df(self) -> Any:
        if importlib.util.find_spec("pandas") is None:
            return {"ds_mapping": self.ds_mapping, "alias_results": self.alias_results}
        import pandas as pd

        return {
            "ds_mapping": pd.DataFrame(self.ds_mapping),
            "alias_results": pd.DataFrame(self.alias_results),
        }

    def __repr__(self) -> str:
        return (
            "ImportReport("
            f"imported_count={self.imported_count}, reused_count={self.reused_count}, "
            f"aliases={len(self.alias_results)})"
        )

    def _repr_html_(self) -> str:
        frames = self.to_df()
        if isinstance(frames, dict) and "ds_mapping" in frames and hasattr(frames["ds_mapping"], "to_html"):
            ds_html = frames["ds_mapping"].to_html(index=False)
            alias_html = frames["alias_results"].to_html(index=False)
            return f"<h4>Datasets</h4>{ds_html}<h4>Aliases</h4>{alias_html}"
        return f"<pre>{self!r}</pre>"


class DataBundle:
    def __init__(self, *, home: Path, name: str, plan: dict[str, Any], author: str | None = None) -> None:
        self._home = home
        self._name = name
        self._plan = plan
        self._author = author

    @property
    def name(self) -> str:
        return self._name

    @property
    def datasets(self) -> list[dict[str, Any]]:
        return list(self._plan.get("datasets", []))

    @property
    def aliases(self) -> list[dict[str, Any]]:
        return list(self._plan.get("aliases", []))

    def export(self, out_path: str | Path) -> Path:
        return ops.bundle_export(home=self._home, plan=self._plan, out=out_path, author=self._author)

    def __repr__(self) -> str:
        return f"DataBundle(name={self._name!r}, datasets={len(self.datasets)}, aliases={len(self.aliases)})"
