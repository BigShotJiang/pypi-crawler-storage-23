from __future__ import annotations

from collections.abc import MutableMapping, Iterator
from typing import Any


class DictProxy(MutableMapping[str, Any]):
    """
    A mutable mapping proxy that writes directly into an underlying dict.
    """

    def __init__(self, data: MutableMapping[str, Any]) -> None:
        self._data = data

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value

    def __delitem__(self, key: str) -> None:
        del self._data[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self._data!r})"

    @property
    def raw(self) -> MutableMapping[str, Any]:
        """
        Return the underlying mutable mapping.
        """
        return self._data


class BindingProxy(DictProxy):
    """
    Dict proxy with attribute access for binding keys.
    """

    def __getattr__(self, name: str) -> Any:
        if name in self._data:
            return self._data[name]
        raise AttributeError(name)

    def __setattr__(self, name: str, value: Any) -> None:
        if name == "_data":
            object.__setattr__(self, name, value)
            return
        self._data[name] = value
