from __future__ import annotations

from typing import TYPE_CHECKING, Any

from .. import ops
from ..core.errors import SpecformUserError
from ..core.registry import Registry
from ..core.store import load_as
from .proxies import BindingProxy, DictProxy
from .run import RunResult
from .history import HistoryView


class DraftSpec:
    """
    Editable draft surface (in-memory). Use save() to persist.
    """

    def __init__(self, *, sf: "Specform", name: str, draft: dict[str, Any]) -> None:
        self._sf = sf
        self._name = name
        self._draft = draft
        self.bindings = BindingProxy(self._draft.setdefault("bindings", {}))
        self.params = DictProxy(self._draft.setdefault("params", {}))
        self.outputs = DictProxy(self._draft.setdefault("outputs", {}))

    @property
    def name(self) -> str:
        return self._name

    @property
    def draft(self) -> dict[str, Any]:
        return self._draft

    def save(self, *, force: bool = False) -> None:
        ops.draft_save(home=self._sf.home, name=self._name, draft=self._draft, force=force)

    def set_dataset(self, dataset_ref_or_pin: str) -> None:
        ops.draft_set_dataset(home=self._sf.home, name=self._name, dataset_ref_or_pin=dataset_ref_or_pin)
        self._draft = ops.draft_load(home=self._sf.home, name=self._name)

    def validate(self) -> list[str]:
        return ops.validate_draft(home=self._sf.home, draft=self._draft)

    def run(self) -> RunResult:
        result = ops.run_from_draft(home=self._sf.home, draft_name=self._name, author=self._sf.author)
        receipt = ops.receipt_get(home=self._sf.home, receipt_id=result["receipt_id"])
        return RunResult(home=self._sf.home, receipt=receipt)

    def bind(self, **kwargs: Any) -> "DraftSpec":
        for key, value in kwargs.items():
            self.bindings[key] = value
        return self

    def autocovariates(self, *, exclude: list[str] | None = None) -> "DraftSpec":
        ds = ops._resolve_dataset_for_run(self._sf.home, self._draft, Registry(self._sf.home))
        schema = ds.get("schema", {})
        columns = schema.get("columns") if isinstance(schema, dict) else []
        if not isinstance(columns, list):
            columns = []
        excluded = {
            self.bindings.get("duration_col") or self.bindings.get("time_to_event"),
            self.bindings.get("event_col") or self.bindings.get("event"),
        }
        if exclude:
            excluded.update(exclude)
        covariates = [str(c) for c in columns if c not in excluded]
        self.bindings["covariates"] = covariates
        return self


class SpecVersion:
    """
    Immutable handle to a locked analysis spec.
    """

    def __init__(self, *, sf: "Specform", as_id: str) -> None:
        self._sf = sf
        self._as_id = as_id

    @property
    def as_id(self) -> str:
        return self._as_id

    @property
    def locked(self) -> dict[str, Any]:
        return load_as(self._sf.home, self._as_id)

    def last_receipt(self) -> RunResult | None:
        receipts = ops.receipts_for_as(home=self._sf.home, as_id=self._as_id, limit=1)
        if not receipts:
            return None
        receipt = ops.receipt_get(home=self._sf.home, receipt_id=receipts[0]["receipt_id"])
        return RunResult(home=self._sf.home, receipt=receipt)

    def receipts(self, *, limit: int | None = None, status_filter: str | None = None) -> list[RunResult]:
        rows = ops.receipts_for_as(home=self._sf.home, as_id=self._as_id, limit=limit, status_filter=status_filter)
        results: list[RunResult] = []
        for row in rows:
            receipt = ops.receipt_get(home=self._sf.home, receipt_id=row["receipt_id"])
            results.append(RunResult(home=self._sf.home, receipt=receipt))
        return results

    def run(self) -> RunResult:
        receipt = ops.run_locked_as(home=self._sf.home, as_id=self._as_id, author=self._sf.author)
        receipt_blob = ops.receipt_get(home=self._sf.home, receipt_id=receipt["receipt_id"])
        return RunResult(home=self._sf.home, receipt=receipt_blob)


class SpecRef:
    """
    Spec alias reference (cyclable via alias events).
    """

    def __init__(self, sf: "Specform", alias: str) -> None:
        self._sf = sf
        self._alias = alias

    @property
    def alias(self) -> str:
        return self._alias

    def new(self, *, template: str, dataset: str, force: bool = False) -> DraftSpec:
        ops.draft_new(
            home=self._sf.home,
            template=template,
            dataset_ref_or_pin=dataset,
            name=self._alias,
            force=force,
            author=self._sf.author,
        )
        draft = ops.draft_load(home=self._sf.home, name=self._alias)
        return DraftSpec(sf=self._sf, name=self._alias, draft=draft)

    def open(self, *, version: int, name: str) -> DraftSpec:
        ops.spec_open(home=self._sf.home, spec_alias=self._alias, version=version, new_draft_name=name, author=self._sf.author)
        draft = ops.draft_load(home=self._sf.home, name=name)
        return DraftSpec(sf=self._sf, name=name, draft=draft)

    def use(self, version: int | str, *, note: str | None = None) -> SpecVersion:
        res = ops.spec_use(home=self._sf.home, alias=self._alias, version=version, note=note, author=self._sf.author)
        return SpecVersion(sf=self._sf, as_id=res["as_id"])

    def run(
        self,
        *,
        template: str | None = None,
        dataset: Any | None = None,
        time: str | None = None,
        event: str | None = None,
        covariates: list[str] | None = None,
        formula: str | None = None,
        strata: list[str] | None = None,
        weights: str | None = None,
        cluster: str | None = None,
        note: str | None = None,
        **params: Any,
    ) -> RunResult:
        bindings: dict[str, Any] = {
            "duration_col": time,
            "event_col": event,
            "covariates": covariates,
            "formula": formula,
            "strata": strata,
            "weights_col": weights,
            "cluster_col": cluster,
        }
        bindings = {k: v for k, v in bindings.items() if v is not None}

        dataset_ref: str | None = None
        if dataset is not None:
            from .dataset import DatasetRef, DatasetVersion

            if isinstance(dataset, DatasetRef):
                dataset_ref = dataset.alias
            elif isinstance(dataset, DatasetVersion):
                dataset_ref = dataset.ds_id
            elif isinstance(dataset, str):
                dataset_ref = dataset
            else:
                dataset_ref = str(dataset)

        has_history = ops.spec_current(home=self._sf.home, alias=self._alias) is not None
        if template is None and not has_history:
            raise SpecformUserError(
                issues=[f"Spec alias has no history yet: {self._alias}"],
                hint="Provide template=... and dataset=... for the first run.",
            )

        if template is not None or not has_history:
            if dataset_ref is None:
                raise SpecformUserError(
                    issues=["dataset is required for inline run"],
                    hint="Pass dataset=<alias or ds_id> to run the spec.",
                )
            result = ops.spec_run_inline(
                home=self._sf.home,
                spec_alias=self._alias,
                template=template or "coxph",
                dataset=dataset_ref,
                bindings=bindings,
                params=params or {},
                outputs={},
                note=note,
                author=self._sf.author,
            )
        else:
            overrides: dict[str, Any] = {}
            if bindings:
                overrides["bindings"] = bindings
            if params:
                overrides["params"] = params
            if dataset_ref is not None:
                overrides["dataset"] = dataset_ref
            result = ops.spec_rerun_current(
                home=self._sf.home,
                spec_alias=self._alias,
                overrides=overrides,
                note=note,
                author=self._sf.author,
            )
        receipt = ops.receipt_get(home=self._sf.home, receipt_id=result["receipt_id"])
        return RunResult(home=self._sf.home, receipt=receipt)

    def rerun(
        self,
        *,
        note: str | None = None,
        dataset: Any | None = None,
        time: str | None = None,
        event: str | None = None,
        covariates: list[str] | None = None,
        formula: str | None = None,
        strata: list[str] | None = None,
        weights: str | None = None,
        cluster: str | None = None,
        **params: Any,
    ) -> RunResult:
        overrides_payload: dict[str, Any] = {}
        if dataset is not None:
            from .dataset import DatasetRef, DatasetVersion

            if isinstance(dataset, DatasetRef):
                overrides_payload["dataset"] = dataset.alias
            elif isinstance(dataset, DatasetVersion):
                overrides_payload["dataset"] = dataset.ds_id
            else:
                overrides_payload["dataset"] = dataset

        bindings: dict[str, Any] = {
            "duration_col": time,
            "event_col": event,
            "covariates": covariates,
            "formula": formula,
            "strata": strata,
            "weights_col": weights,
            "cluster_col": cluster,
        }
        bindings = {k: v for k, v in bindings.items() if v is not None}
        if bindings:
            overrides_payload["bindings"] = bindings
        if params:
            overrides_payload["params"] = params

        result = ops.spec_rerun_current(
            home=self._sf.home,
            spec_alias=self._alias,
            overrides=overrides_payload,
            note=note,
            author=self._sf.author,
        )
        receipt = ops.receipt_get(home=self._sf.home, receipt_id=result["receipt_id"])
        return RunResult(home=self._sf.home, receipt=receipt)

    def current(self) -> SpecVersion | None:
        as_id = ops.spec_current(home=self._sf.home, alias=self._alias)
        if not as_id:
            return None
        return SpecVersion(sf=self._sf, as_id=as_id)

    def version(self, version: int) -> SpecVersion:
        rows = ops.spec_history(home=self._sf.home, alias=self._alias)
        if version < 1 or version > len(rows):
            raise ValueError(f"Version out of range: {version}")
        return SpecVersion(sf=self._sf, as_id=rows[version - 1]["as_id"])

    def history(self) -> HistoryView:
        return HistoryView(ops.spec_history(home=self._sf.home, alias=self._alias))

    def v(self, version: int | str) -> SpecVersion:
        if isinstance(version, str):
            return self.version(int(version))
        return self.version(version)


if TYPE_CHECKING:
    from .specform import Specform
