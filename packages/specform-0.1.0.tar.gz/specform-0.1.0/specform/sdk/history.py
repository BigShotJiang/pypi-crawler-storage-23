from __future__ import annotations

import importlib
import importlib.util
from typing import Any

class HistoryView:
    def __init__(self, rows: list[dict[str, Any]]) -> None:
        self._rows = rows

    @property
    def rows(self) -> list[dict[str, Any]]:
        return self._rows

    def to_df(self) -> Any:
        import importlib.util
        if importlib.util.find_spec("pandas") is None:
            return self._rows
        import pandas as pd
        return pd.DataFrame(self._rows)

    def __repr__(self) -> str:
        return f"HistoryView(rows={len(self._rows)})"

    def __str__(self) -> str:
        if not self._rows:
            return "(empty history)"
        try:
            from tabulate import tabulate
            return tabulate(self._rows, headers="keys", tablefmt="simple")
        except Exception:
            return "\n".join(str(row) for row in self._rows)

    def _repr_html_(self) -> str:
        df = self.to_df()
        if hasattr(df, "to_html"):
            return df.to_html(index=False)
        return f"<pre>{self._rows}</pre>"
