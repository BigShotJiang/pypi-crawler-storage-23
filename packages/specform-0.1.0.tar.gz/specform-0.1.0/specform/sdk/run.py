from __future__ import annotations

from pathlib import Path
from typing import Any

from .. import ops


class RunResult:
    """
    Object wrapper for an execution receipt.
    """

    def __init__(self, *, home: Path, receipt: dict[str, Any]) -> None:
        self._home = home
        self._receipt = receipt

    @property
    def raw(self) -> dict[str, Any]:
        return self._receipt

    @property
    def receipt_id(self) -> str:
        return str(self._receipt.get("er_id") or self._receipt.get("receipt_id"))

    @property
    def status(self) -> str:
        return str(self._receipt.get("status"))

    @property
    def as_id(self) -> str:
        return str(self._receipt.get("as_id"))

    @property
    def ds_id(self) -> str:
        return str(self._receipt.get("ds_id"))

    @property
    def run_id(self) -> str:
        return str(self._receipt.get("run_id"))

    @property
    def artifacts(self) -> dict[str, str]:
        art = self._receipt.get("artifacts") or {}
        return dict(art)

    @property
    def error(self) -> dict[str, Any] | None:
        err = self._receipt.get("error")
        if isinstance(err, dict):
            return err
        return None

    @property
    def times(self) -> dict[str, str | None]:
        return {
            "started_at": self._receipt.get("started_at"),
            "finished_at": self._receipt.get("finished_at"),
            "created_at": self._receipt.get("created_at"),
        }

    @property
    def run_dir(self) -> Path:
        return self._home / ".specform" / "runs" / self.run_id

    def artifact_path(self, key: str) -> Path:
        artifacts = self.artifacts
        if key not in artifacts:
            raise KeyError(f"Unknown artifact key: {key}")
        return (self.run_dir / artifacts[key]).resolve()

    def reproduce(self) -> "RunResult":
        result = ops.receipt_reproduce(home=self._home, receipt_id=self.receipt_id)
        receipt = ops.receipt_get(home=self._home, receipt_id=result["receipt_id"])
        return RunResult(home=self._home, receipt=receipt)

    def __repr__(self) -> str:
        return (
            f"RunResult(status={self.status!r}, receipt_id={self.receipt_id!r}, run_id={self.run_id!r}, "
            f"as_id={self.as_id!r}, ds_id={self.ds_id!r})"
        )
