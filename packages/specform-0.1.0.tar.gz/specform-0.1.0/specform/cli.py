# specform/cli.py
from __future__ import annotations

import argparse
import io
import json
import os
import sys
import traceback
from pathlib import Path
from typing import Any

from .core.errors import SpecformUserError, ValidationError
from .core.registry import Registry
from . import ops

# -----------------------------
# Rich (optional)
# -----------------------------
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.text import Text

    _RICH = True
except Exception:  # pragma: no cover
    _RICH = False
    Console = None  # type: ignore[misc]


# -----------------------------
# Helpers: debug + printing
# -----------------------------
def _debug_enabled(args: argparse.Namespace) -> bool:
    if getattr(args, "debug", False):
        return True
    v = os.environ.get("SPECFORM_DEBUG", "").strip().lower()
    return v in ("1", "true", "yes", "y", "on")


def _ws_root_from_args(args: argparse.Namespace) -> Path:
    # Workspace root is the folder that CONTAINS ".specform"
    return ops.resolve_home(getattr(args, "home", None))


def _safe_json_print(payload: dict[str, Any]) -> None:
    # Single JSON line, stdout only
    print(json.dumps(payload, sort_keys=True))


def _console() -> Any:
    if _RICH:
        return Console()
    return None


def _print_table_plain(rows: list[dict[str, Any]]) -> None:
    if not rows:
        print("(no rows)")
        return
    headers = list(rows[0].keys())
    col_widths = {h: max(len(str(h)), max(len(str(r.get(h, ""))) for r in rows)) for h in headers}
    header_row = " | ".join(str(h).ljust(col_widths[h]) for h in headers)
    print(header_row)
    print("-+-".join("-" * col_widths[h] for h in headers))
    for row in rows:
        print(" | ".join(str(row.get(h, "")).ljust(col_widths[h]) for h in headers))


def _print_table_rich(rows: list[dict[str, Any]], title: str | None = None) -> None:
    if not _RICH:
        _print_table_plain(rows)
        return
    c = _console()
    if not rows:
        c.print("(no rows)")
        return
    headers = list(rows[0].keys())
    t = Table(title=title, show_header=True, header_style="bold")
    for h in headers:
        t.add_column(str(h))
    for r in rows:
        t.add_row(*[str(r.get(h, "")) for h in headers])
    c.print(t)


# -----------------------------
# User-facing error type
# -----------------------------
def _emit_user_error(args: argparse.Namespace, err: SpecformUserError, *, tb: str | None = None) -> int:
    debug = _debug_enabled(args)

    if getattr(args, "json", False):
        _safe_json_print(err.to_json(debug=debug, tb=tb))
        return err.code

    # Non-JSON path
    if _RICH:
        c = _console()
        lines = []
        for s in err.issues:
            lines.append(f"• {s}")
        body = "\n".join(lines)
        if err.hint:
            body += f"\n\n[bold]Hint:[/bold] {err.hint}"
        c.print(Panel(body, title="Specform", border_style="red"))
        if debug and tb:
            c.print("\n[bold]Traceback (debug):[/bold]")
            c.print(tb)
        return err.code

    # Plain fallback
    for s in err.issues:
        print(f"- {s}", file=sys.stderr)
    if err.hint:
        print(f"Hint: {err.hint}", file=sys.stderr)
    if debug and tb:
        print(tb, file=sys.stderr)
    return err.code


def _emit_unexpected_error(args: argparse.Namespace, exc: Exception) -> int:
    debug = _debug_enabled(args)
    tb = traceback.format_exc()

    if getattr(args, "json", False):
        payload: dict[str, Any] = {
            "status": "error",
            "type": type(exc).__name__,
            "message": str(exc),
        }
        if debug:
            payload["traceback"] = tb
        _safe_json_print(payload)
        return 1

    if _RICH:
        c = _console()
        msg = f"[bold red]Unexpected error:[/bold red] {type(exc).__name__}: {exc}"
        if not debug:
            msg += "\n\n[bold]Hint:[/bold] Re-run with [bold]specform --debug ...[/bold] to see a traceback."
        c.print(Panel(msg, title="Specform", border_style="red"))
        if debug:
            c.print_exception()
        return 1

    print(f"Unexpected error: {type(exc).__name__}: {exc}", file=sys.stderr)
    if debug:
        print(tb, file=sys.stderr)
    else:
        print("Hint: Re-run with `specform --debug ...` to see a traceback.", file=sys.stderr)
    return 1


# -----------------------------
# Commands
# -----------------------------
def cmd_init(args: argparse.Namespace) -> dict[str, Any]:
    return ops.init_workspace()


def cmd_dataset_add(args: argparse.Namespace) -> dict[str, Any]:
    home = _ws_root_from_args(args)
    return ops.dataset_add(home=home, path=args.path, alias=args.name, author=args.author)


def cmd_dataset_use(args: argparse.Namespace) -> dict[str, Any]:
    home = _ws_root_from_args(args)
    return ops.dataset_use(home=home, alias=args.name, version=args.version, author=args.author)

def cmd_dataset_merge(args: argparse.Namespace) -> dict[str, Any]:
    home = _ws_root_from_args(args)
    return ops.dataset_alias_merge(
        home=home,
        into=args.into,
        incoming=args.incoming,
        note=getattr(args, "note", None),
        author=args.author,
        dry_run=getattr(args, "dry_run", False),
    )


def cmd_history(args: argparse.Namespace) -> list[dict[str, Any]]:
    home = _ws_root_from_args(args)
    if Registry(home).alias_type_exists(args.name, "spec"):
        return ops.spec_history(home=home, alias=args.name)
    return ops.dataset_history(home=home, name=args.name)


def cmd_datasets(args: argparse.Namespace) -> list[str]:
    home = _ws_root_from_args(args)
    return ops.dataset_aliases_list(home=home)


def cmd_specs(args: argparse.Namespace) -> list[str]:
    home = _ws_root_from_args(args)
    return ops.spec_aliases_list(home=home)


def cmd_spec_new(args: argparse.Namespace) -> dict[str, Any]:
    home = _ws_root_from_args(args)
    return ops.draft_new(
        home=home,
        template=args.template,
        dataset_ref_or_pin=args.dataset,
        name=args.name,
        force=args.force,
        author=args.author,
    )

def cmd_reset(args: argparse.Namespace) -> dict[str, Any]:
    home = _ws_root_from_args(args)
    yes = getattr(args, "yes", False)
    json_mode = getattr(args, "json", False)
    if yes:
        return ops.reset(home=home, yes=True, json_mode=json_mode)
    if json_mode:
        return ops.reset(home=home, yes=False, json_mode=True)

    from rich.prompt import Confirm

    msg = f"This will permanently delete all Specform state at:\n  {home / '.specform'}\nContinue?"
    if not Confirm.ask(msg, default=False):
        return {"status": "ok", "reset": False, "home": str(home), "message": "Cancelled."}
    return ops.reset(home=home, yes=True, json_mode=json_mode)

def cmd_run(args: argparse.Namespace) -> dict[str, Any]:
    home = _ws_root_from_args(args)
    return ops.run_from_draft(home=home, draft_name=args.spec, author=args.author)


def cmd_reproduce(args: argparse.Namespace) -> dict[str, Any]:
    home = _ws_root_from_args(args)
    return ops.reproduce_from_er(home=home, er_id=args.er, author=args.author)


def cmd_spec_open(args: argparse.Namespace) -> dict[str, Any]:
    home = _ws_root_from_args(args)
    return ops.spec_open(
        home=home,
        spec_alias=args.spec,
        version=args.version,
        new_draft_name=args.name,
        author=args.author,
    )


def cmd_export(args: argparse.Namespace) -> dict[str, Any]:
    home = _ws_root_from_args(args)
    return ops.export_pack(home=home, out=args.out, alias=getattr(args, "alias", None))


def cmd_import(args: argparse.Namespace) -> dict[str, Any]:
    home = ops.resolve_home(args.home or str(Path.cwd().resolve()))
    return ops.import_pack(home=home, pack=args.pack)


def cmd_doctor(args: argparse.Namespace) -> dict[str, Any]:
    home = _ws_root_from_args(args)
    return ops.doctor(home=home, verify=getattr(args, "verify", False), sample=getattr(args, "sample", 20))


def cmd_bundle_export(args: argparse.Namespace) -> dict[str, Any]:
    home = _ws_root_from_args(args)
    plan = ops.bundle_prepare(home=home, name=args.name, items=list(args.items))
    bundle_path = ops.bundle_export(home=home, plan=plan, out=args.out, author=args.author)
    return {
        "bundle": str(bundle_path),
        "datasets": len(plan.get("ds_ids", [])),
        "aliases": len(plan.get("aliases", [])),
    }


def cmd_bundle_inspect(args: argparse.Namespace) -> dict[str, Any] | None:
    home = _ws_root_from_args(args)
    report = ops.bundle_inspect(home=home, path=args.path)
    if getattr(args, "json", False):
        return report
    _print_table_rich(report["datasets"], title="Datasets")
    _print_table_rich(report["aliases"], title="Aliases")
    return None


def cmd_bundle_import(args: argparse.Namespace) -> dict[str, Any] | None:
    home = _ws_root_from_args(args)
    report = ops.bundle_import(
        home=home,
        path=args.path,
        aliases=args.aliases,
        conflict=args.conflict,
        author=args.author,
    )
    if getattr(args, "json", False):
        return report
    summary_rows = [
        {
            "imported": report["imported_count"],
            "reused": report["reused_count"],
            "aliases": len(report["alias_results"]),
            "warnings": len(report["warnings"]),
        }
    ]
    _print_table_rich(summary_rows, title="Bundle Import Summary")
    _print_table_rich(report["alias_results"], title="Alias Results")
    return None


# -----------------------------
# Parser
# -----------------------------
def build_parser() -> argparse.ArgumentParser:
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--home", help="Workspace root (directory that will contain .specform/)")
    common.add_argument("--author", help="Author attribution")
    common.add_argument("--json", action="store_true", help="JSON output (SDK contract)")
    common.add_argument("--debug", action="store_true", help="Show tracebacks for unexpected errors")

    parser = argparse.ArgumentParser(prog="specform", parents=[common])
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init", parents=[common])
    init_parser.set_defaults(func=cmd_init)

    dataset_parser = subparsers.add_parser("dataset", parents=[common])
    dataset_sub = dataset_parser.add_subparsers(dest="dataset_command", required=True)

    dataset_add = dataset_sub.add_parser("add", parents=[common])
    dataset_add.add_argument("path")
    dataset_add.add_argument("--name", required=True)
    dataset_add.set_defaults(func=cmd_dataset_add)

    reset_parser = subparsers.add_parser("reset", parents=[common],
                                         help="Delete .specform and reinitialize the workspace")
    reset_parser.add_argument("--yes", action="store_true", help="Skip confirmation (non-interactive)")
    reset_parser.set_defaults(func=cmd_reset)

    dataset_use = dataset_sub.add_parser("use", parents=[common])
    dataset_use.add_argument("--name", required=True)
    dataset_use.add_argument("--version", type=int, required=True)
    dataset_use.set_defaults(func=cmd_dataset_use)

    dataset_merge = dataset_sub.add_parser("merge", parents=[common])
    dataset_merge.add_argument("into", help="Target dataset alias (local)")
    dataset_merge.add_argument("incoming", help="Incoming dataset alias")
    dataset_merge.add_argument("--note", required=False)
    dataset_merge.add_argument("--dry-run", action="store_true")
    dataset_merge.set_defaults(func=cmd_dataset_merge)

    history_parser = subparsers.add_parser("history", parents=[common])
    history_parser.add_argument("name")
    history_parser.set_defaults(func=cmd_history)

    datasets_parser = subparsers.add_parser("datasets", parents=[common])
    datasets_parser.set_defaults(func=cmd_datasets)

    specs_parser = subparsers.add_parser("specs", parents=[common])
    specs_parser.set_defaults(func=cmd_specs)

    spec_parser = subparsers.add_parser("spec", parents=[common])
    spec_sub = spec_parser.add_subparsers(dest="spec_command", required=True)

    spec_new = spec_sub.add_parser("new", parents=[common])
    spec_new.add_argument("--template", required=True)
    spec_new.add_argument("--dataset", required=True)
    spec_new.add_argument("--name", required=True)
    spec_new.add_argument("--force", action="store_true")
    spec_new.set_defaults(func=cmd_spec_new)

    spec_open = spec_sub.add_parser("open", parents=[common])
    spec_open.add_argument("--spec", required=True)
    spec_open.add_argument("--version", type=int, required=True)
    spec_open.add_argument("--name", required=True)
    spec_open.set_defaults(func=cmd_spec_open)

    run_parser = subparsers.add_parser("run", parents=[common])
    run_parser.add_argument("--spec", required=True)
    run_parser.set_defaults(func=cmd_run)

    reproduce_parser = subparsers.add_parser("reproduce", parents=[common])
    reproduce_parser.add_argument("--er", required=True)
    reproduce_parser.set_defaults(func=cmd_reproduce)

    export_parser = subparsers.add_parser("export", parents=[common])
    export_parser.add_argument("--out", required=True, help="Output .sfpack path")
    export_parser.add_argument("--alias", required=False, help="Optional dataset alias (MVP may ignore filter)")
    export_parser.set_defaults(func=cmd_export)

    import_parser = subparsers.add_parser("import", parents=[common])
    import_parser.add_argument("pack", help="Path to .sfpack")
    import_parser.set_defaults(func=cmd_import)

    doctor_parser = subparsers.add_parser("doctor", parents=[common])
    doctor_parser.add_argument("--verify", action="store_true", help="Verify DS fingerprints (sampled)")
    doctor_parser.add_argument("--sample", type=int, default=20, help="How many DS blobs to sample")
    doctor_parser.set_defaults(func=cmd_doctor)

    bundle_parser = subparsers.add_parser("bundle", parents=[common])
    bundle_sub = bundle_parser.add_subparsers(dest="bundle_command", required=True)

    bundle_export = bundle_sub.add_parser("export", parents=[common])
    bundle_export.add_argument("name", help="Bundle name")
    bundle_export.add_argument("items", nargs="*", help="Dataset aliases or ds_ IDs")
    bundle_export.add_argument("--out", required=True, help="Output .sfds path")
    bundle_export.set_defaults(func=cmd_bundle_export)

    bundle_inspect = bundle_sub.add_parser("inspect", parents=[common])
    bundle_inspect.add_argument("path", help="Path to .sfds bundle")
    bundle_inspect.set_defaults(func=cmd_bundle_inspect)

    bundle_import = bundle_sub.add_parser("import", parents=[common])
    bundle_import.add_argument("path", help="Path to .sfds bundle")
    bundle_import.add_argument("--aliases", default="recreate", choices=["recreate", "none"])
    bundle_import.add_argument("--conflict", default="rename", choices=["rename", "skip"])
    bundle_import.set_defaults(func=cmd_bundle_import)

    return parser


# -----------------------------
# Main
# -----------------------------
def main(argv: list[str] | None = None) -> int:
    argv = list(argv) if argv is not None else sys.argv[1:]

    # Help path: if --json, wrap help in JSON.
    if "--help" in argv or "-h" in argv:
        if "--json" in argv:
            parser = build_parser()
            buf = io.StringIO()
            # Let argparse print help into buf
            try:
                parser.parse_args([a for a in argv if a not in ("--json",)])
            except SystemExit:
                pass
            help_text = buf.getvalue().strip()
            _safe_json_print({"status": "ok", "help": help_text})
            return 0

        parser = build_parser()
        parser.parse_args(argv)  # prints help and exits
        return 0  # unreachable

    parser = build_parser()
    args = parser.parse_args(argv)

    try:
        # argparse sets func on each command
        result = args.func(args)

        if result is None:
            return 0

        # Normal printing path
        if getattr(args, "json", False):
            # IMPORTANT: preserve legacy contract:
            # - if command returns a list, print a list (not {"status":"ok","result":...})
            # - if command returns a dict, print a dict
            print(json.dumps(result, sort_keys=True))
        else:
            if isinstance(result, list):
                if result and isinstance(result[0], dict):
                    _print_table_rich(result, title="History")
                elif result:
                    for item in result:
                        print(item)
                else:
                    print("(no rows)")
            else:
                if _RICH:
                    _console().print(result)
                else:
                    print(json.dumps(result, indent=2, sort_keys=True))

        # Exit codes
        if isinstance(result, dict) and result.get("status") in ("validation_failed", "error"):
            return 1
        return 0

    except SpecformUserError as exc:
        tb = traceback.format_exc()
        return _emit_user_error(args, exc, tb=tb)

    except ValidationError as exc:
        # Keep your existing semantics but upgrade the message
        ue = SpecformUserError(
            issues=exc.issues,
            hint="Fix the issues above and re-run. If you are in a notebook, update the draft YAML or use sf.spec_update().",
            type="validation_failed",
        )
        tb = traceback.format_exc()
        return _emit_user_error(args, ue, tb=tb)

    except FileNotFoundError as exc:
        ue = SpecformUserError(
            issues=[str(exc)],
            hint="If this refers to a draft, create it with `specform spec new ...`.\n"
                 "If this refers to dataset bytes, run `specform doctor --verify`.",
            type="not_found",
        )
        tb = traceback.format_exc()
        return _emit_user_error(args, ue, tb=tb)

    except PermissionError as exc:
        ue = SpecformUserError(
            issues=[str(exc)],
            hint="Close files that might be locked (Excel), and ensure you have read/write permission in the workspace.",
            type="permission_error",
        )
        tb = traceback.format_exc()
        return _emit_user_error(args, ue, tb=tb)

    except ValueError as exc:
        ue = SpecformUserError(
            issues=[str(exc)],
            hint="This usually means an argument is out of range or an alias is missing.\n"
                 "Try: specform doctor  OR  specform --debug ... to see details.",
            type="value_error",
        )
        tb = traceback.format_exc()
        return _emit_user_error(args, ue, tb=tb)

    except SystemExit as exc:
        code = exc.code if isinstance(exc.code, int) else 1
        if getattr(args, "json", False):
            msg = exc.code if isinstance(exc.code, str) else "exited"
            _safe_json_print({"status": "error", "message": str(msg)})
        else:
            print(str(exc), file=sys.stderr)
        return code

    except Exception as exc:
        return _emit_unexpected_error(args, exc)


if __name__ == "__main__":
    raise SystemExit(main())
