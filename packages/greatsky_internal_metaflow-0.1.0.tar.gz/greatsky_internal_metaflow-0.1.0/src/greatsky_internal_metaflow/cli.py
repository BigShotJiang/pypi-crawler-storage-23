"""GSM CLI — authenticate and manage the GreatSky Metaflow platform."""

from __future__ import annotations

import os
import re
import webbrowser
from pathlib import Path

import click
import httpx
from rich.console import Console
from rich.table import Table

from greatsky_internal_metaflow import auth, config, settings, validate

console = Console()


# ── Root ────────────────────────────────────────────────────────────────────


@click.group()
@click.version_option(package_name="greatsky-internal-metaflow")
def cli():
    """GreatSky Metaflow Platform CLI."""


# ── Login ───────────────────────────────────────────────────────────────────


@cli.command()
@click.option(
    "--scope",
    type=click.Choice(["project", "venv", "global"]),
    default=None,
    help="Where to store credentials (default: auto-detect).",
)
def login(scope: str | None):
    """Authenticate with the GreatSky Metaflow platform via GitHub."""
    console.print("\n  [bold]GreatSky Metaflow Platform[/bold]\n")

    # Determine write target
    target = _resolve_write_target(scope)

    # 1. Discover bootstrap config (public — just client_id and domain)
    with console.status("Fetching platform config..."):
        try:
            platform_config = auth.fetch_bootstrap_config()
        except httpx.HTTPError as exc:
            console.print(f"  [red]Error:[/red] Cannot reach auth API: {exc}")
            raise SystemExit(1)

    client_id = platform_config.get("github_client_id")
    if not client_id:
        console.print("  [red]Error:[/red] Platform did not return a GitHub client ID")
        raise SystemExit(1)

    # 2. Start Device Flow
    try:
        device_code = auth.request_device_code(client_id)
    except httpx.HTTPError as exc:
        console.print(f"  [red]Error:[/red] Failed to start GitHub Device Flow: {exc}")
        raise SystemExit(1)

    console.print(f"  Open this URL:  [bold cyan]{device_code.verification_uri}[/bold cyan]")
    console.print(f"  Enter code:     [bold yellow]{device_code.user_code}[/bold yellow]\n")

    try:
        webbrowser.open(device_code.verification_uri)
    except Exception:
        pass

    # 3. Poll for GitHub token
    with console.status("Waiting for authorization..."):
        try:
            github_token = auth.poll_for_token(client_id, device_code)
        except RuntimeError as exc:
            console.print(f"  [red]Error:[/red] {exc}")
            raise SystemExit(1)

    console.print("  Authorization received [green]✓[/green]")

    # 4. Exchange for platform credentials
    with console.status("Exchanging token with platform..."):
        try:
            creds = auth.exchange_token(github_token)
        except PermissionError as exc:
            console.print(f"\n  [red]Access denied:[/red] {exc}")
            raise SystemExit(1)
        except httpx.HTTPError as exc:
            console.print(f"\n  [red]Error:[/red] Token exchange failed: {exc}")
            raise SystemExit(1)

    # 5. Write config files to the resolved GSM directory
    config.write_config(
        {
            "GSM_AUTH_API": platform_config.get("auth_url", settings.AUTH_API_BASE),
            "METAFLOW_SERVICE_AUTH_KEY": creds.api_key,
        },
        target=target,
    )
    config.write_credentials(
        api_key=creds.api_key,
        expires_at=creds.expires_at,
        github_user=creds.github_user,
        name=creds.name,
        access_type=creds.access_type,
        invited_by=creds.invited_by,
        guest_expires=creds.guest_expires,
        target=target,
    )

    # 6. Success output
    console.print(f"\n  Welcome, [bold]{creds.name}[/bold]")

    access_label = "org member" if creds.access_type == "org_member" else "invited guest"
    console.print(f"  Access: {access_label}")
    if creds.invited_by:
        console.print(f"  Invited by: {creds.invited_by}")

    expires_display = creds.expires_at[:10] if len(creds.expires_at) >= 10 else creds.expires_at
    console.print(f"\n  Config saved to [dim]{target}[/dim]")
    console.print(f"  API key expires: {expires_display}")
    console.print("\n  You're all set! Try:")
    console.print("    [dim]python my_flow.py run[/dim]\n")


def _resolve_write_target(scope: str | None) -> Path:
    """Map the --scope flag to a concrete directory path."""
    if scope == "global":
        return config.GLOBAL_DIR
    if scope == "venv":
        venv_dir = config._venv_gsm_dir()
        if venv_dir is None:
            console.print("  [red]Error:[/red] No active virtualenv detected for --scope=venv")
            raise SystemExit(1)
        return venv_dir
    if scope == "project":
        project_root = config._find_project_root()
        if project_root is None:
            console.print("  [red]Error:[/red] No project root found for --scope=project")
            raise SystemExit(1)
        return project_root / config.PROJECT_DIR_NAME
    return config.write_target_dir()


# ── Logout ──────────────────────────────────────────────────────────────────


@cli.command()
def logout():
    """Remove local credentials and config from the resolved GSM directory."""
    removed = config.clear_all()
    if removed:
        console.print("  Logged out — local config and credentials removed.")
    else:
        console.print("  Already logged out (no credentials found).")


# ── Status ──────────────────────────────────────────────────────────────────


@cli.command()
def status():
    """Show current authentication state."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [yellow]Not logged in.[/yellow] Run: [bold]gsm login[/bold]")
        return

    gsm_dir = config.resolve_gsm_dir()
    gsm_config = config.read_config()

    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column(style="dim")
    table.add_column()

    table.add_row("User", creds.get("github_user", "unknown"))
    table.add_row("Name", creds.get("name", ""))

    access = creds.get("access_type", "")
    access_label = "org member" if access == "org_member" else "invited guest"
    table.add_row("Access", access_label)

    if creds.get("invited_by"):
        table.add_row("Invited by", creds["invited_by"])

    expires = creds.get("expires_at", "")
    table.add_row("Key expires", expires[:10] if len(expires) >= 10 else expires)

    if gsm_config:
        table.add_row("Auth API", gsm_config.get("GSM_AUTH_API", ""))

    if gsm_dir:
        table.add_row("Config dir", str(gsm_dir))

    console.print()
    console.print(table)
    console.print()


# ── Refresh ─────────────────────────────────────────────────────────────────


@cli.command()
def refresh():
    """Force re-fetch the platform config from the auth API (bypasses cache TTL)."""
    gsm_dir = config.resolve_gsm_dir()
    if gsm_dir is None:
        console.print("  [yellow]Not logged in.[/yellow] Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    gsm_config = config.read_config()
    if not gsm_config:
        console.print("  [red]Error:[/red] No config found. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    auth_api = gsm_config.get("GSM_AUTH_API")
    api_key = gsm_config.get("METAFLOW_SERVICE_AUTH_KEY", "")
    if not auth_api:
        console.print("  [red]Error:[/red] Missing GSM_AUTH_API in config.")
        raise SystemExit(1)

    with console.status("Fetching platform config..."):
        try:
            resp = httpx.get(
                f"{auth_api}/auth/client-config",
                headers={"X-Api-Key": api_key} if api_key else {},
                timeout=10,
            )
            resp.raise_for_status()
            data = resp.json()
            remote_config = data.get("metaflow_config", {})
        except httpx.HTTPError as exc:
            console.print(f"  [red]Error:[/red] {exc}")
            raise SystemExit(1)

    config.write_config_cache(remote_config, target=gsm_dir)

    # Clear the env cache so the next import picks up the fresh values
    os.environ.pop("__GSM_CONFIG_RESOLVED__", None)

    console.print(f"  Config cache refreshed ({len(remote_config)} keys)")
    console.print(f"  Saved to [dim]{gsm_dir / 'config_cache.json'}[/dim]\n")


# ── Cleanup ─────────────────────────────────────────────────────────────────


@cli.command()
def cleanup():
    """Remove legacy global config files from before per-env scoping.

    Removes: ~/.metaflowconfig/config.json (if it contains GSM keys)
             ~/.greatsky/ (entire directory)
    """
    from pathlib import Path

    removed = []

    # Legacy metaflow config
    mf_config = Path.home() / ".metaflowconfig" / "config.json"
    if mf_config.exists():
        try:
            import json

            data = json.loads(mf_config.read_text())
            if "GSM_AUTH_API" in data:
                mf_config.unlink()
                removed.append(str(mf_config))
            else:
                console.print(f"  [dim]Skipped {mf_config} (not a GSM config)[/dim]")
        except (json.JSONDecodeError, OSError):
            pass

    # Legacy global GSM dir (only if we now have a project or venv config)
    legacy_global = Path.home() / ".greatsky"
    current_dir = config.resolve_gsm_dir()
    if legacy_global.is_dir() and current_dir is not None and current_dir != legacy_global:
        import shutil

        shutil.rmtree(legacy_global, ignore_errors=True)
        removed.append(str(legacy_global))

    if removed:
        for r in removed:
            console.print(f"  Removed [dim]{r}[/dim]")
        console.print()
    else:
        console.print("  No legacy files to clean up.\n")


# ── Revoke ──────────────────────────────────────────────────────────────────


@cli.command(name="revoke")
def revoke_cmd():
    """Immediately revoke your current API key (no re-auth needed)."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [yellow]Not logged in.[/yellow] Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    api_key = creds.get("api_key", "")
    if not api_key:
        console.print("  [red]Error:[/red] No API key found in credentials.")
        raise SystemExit(1)

    with console.status("Revoking API key..."):
        try:
            resp = httpx.delete(
                settings.REVOKE_KEY_ENDPOINT,
                headers={"X-Api-Key": api_key},
                timeout=10,
            )
        except httpx.HTTPError as exc:
            console.print(f"  [red]Error:[/red] {exc}")
            raise SystemExit(1)

    if resp.status_code == 200:
        config.clear_all()
        console.print("  API key revoked and local credentials removed.")
        console.print("  Run [bold]gsm login[/bold] to re-authenticate.\n")
    elif resp.status_code == 401:
        config.clear_all()
        console.print("  Key was already invalid. Local credentials removed.")
    else:
        detail = resp.json().get("error", resp.text)
        console.print(f"  [red]Error:[/red] {detail}")
        raise SystemExit(1)


# ── Validate ────────────────────────────────────────────────────────────────


@cli.command(name="validate")
def validate_cmd():
    """Check that authentication and platform connectivity are working."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [yellow]Not logged in.[/yellow] Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    api_key = creds.get("api_key", "")
    with console.status("Validating..."):
        result = validate.validate(api_key)

    _check("Auth API reachable", result.auth_api_ok)
    _check("API key valid", result.api_key_valid)
    if result.auth_user:
        console.print(f"    Authenticated as: {result.auth_user}")
    _check("Metadata service reachable", result.metadata_api_ok)

    if result.error:
        console.print(f"\n  [red]Issue:[/red] {result.error}")
        raise SystemExit(1)

    console.print("\n  [green]All checks passed.[/green]\n")


def _check(label: str, ok: bool):
    icon = "[green]✓[/green]" if ok else "[red]✗[/red]"
    console.print(f"  {icon} {label}")


# ── Admin ───────────────────────────────────────────────────────────────────


@cli.group()
def admin():
    """Guest access management (org members only)."""


@admin.command()
@click.argument("username")
@click.option(
    "--expires",
    default="90d",
    show_default=True,
    help="Access duration (e.g. 30d, 90d, 365d).",
)
def invite(username: str, expires: str):
    """Invite a GitHub user as a guest collaborator."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [red]Error:[/red] Not logged in. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    days = _parse_duration(expires)
    if days is None:
        console.print(f"  [red]Error:[/red] Invalid duration: {expires} (use e.g. 30d, 90d)")
        raise SystemExit(1)

    try:
        resp = httpx.post(
            settings.ADMIN_INVITE_ENDPOINT,
            json={"github_username": username, "expires_days": days},
            headers={"X-Api-Key": creds["api_key"]},
            timeout=10,
        )
    except httpx.HTTPError as exc:
        console.print(f"  [red]Error:[/red] {exc}")
        raise SystemExit(1)

    if resp.status_code == 403:
        console.print("  [red]Error:[/red] Admin endpoints require org membership.")
        raise SystemExit(1)
    if resp.status_code != 200:
        detail = resp.json().get("error", resp.text)
        console.print(f"  [red]Error:[/red] {detail}")
        raise SystemExit(1)

    data = resp.json()
    console.print(f"\n  Invited [bold]{username}[/bold] as guest")
    console.print(f"  Expires: {data.get('expires_at', 'unknown')}")
    console.print("  They can now: [dim]pip install greatsky-internal-metaflow && gsm login[/dim]\n")


@admin.command()
@click.argument("username")
def revoke(username: str):
    """Remove a guest's access and deactivate their API key."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [red]Error:[/red] Not logged in. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    try:
        resp = httpx.delete(
            f"{settings.ADMIN_INVITE_ENDPOINT}/{username}",
            headers={"X-Api-Key": creds["api_key"]},
            timeout=10,
        )
    except httpx.HTTPError as exc:
        console.print(f"  [red]Error:[/red] {exc}")
        raise SystemExit(1)

    if resp.status_code == 403:
        console.print("  [red]Error:[/red] Admin endpoints require org membership.")
        raise SystemExit(1)
    if resp.status_code != 200:
        detail = resp.json().get("error", resp.text)
        console.print(f"  [red]Error:[/red] {detail}")
        raise SystemExit(1)

    console.print(f"  Revoked access for [bold]{username}[/bold].")


@admin.command(name="revoke-keys")
@click.argument("username")
def revoke_keys(username: str):
    """Immediately revoke all active API keys for a user."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [red]Error:[/red] Not logged in. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    try:
        resp = httpx.post(
            settings.ADMIN_REVOKE_KEYS_ENDPOINT,
            json={"github_username": username},
            headers={"X-Api-Key": creds["api_key"]},
            timeout=10,
        )
    except httpx.HTTPError as exc:
        console.print(f"  [red]Error:[/red] {exc}")
        raise SystemExit(1)

    if resp.status_code == 403:
        console.print("  [red]Error:[/red] Admin endpoints require org membership.")
        raise SystemExit(1)
    if resp.status_code != 200:
        detail = resp.json().get("error", resp.text)
        console.print(f"  [red]Error:[/red] {detail}")
        raise SystemExit(1)

    data = resp.json()
    count = data.get("keys_revoked", 0)
    console.print(f"  Revoked {count} active key(s) for [bold]{username}[/bold].")


@admin.command()
def guests():
    """List all invited guests."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [red]Error:[/red] Not logged in. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    try:
        resp = httpx.get(
            settings.ADMIN_GUESTS_ENDPOINT,
            headers={"X-Api-Key": creds["api_key"]},
            timeout=10,
        )
    except httpx.HTTPError as exc:
        console.print(f"  [red]Error:[/red] {exc}")
        raise SystemExit(1)

    if resp.status_code == 403:
        console.print("  [red]Error:[/red] Admin endpoints require org membership.")
        raise SystemExit(1)
    if resp.status_code != 200:
        detail = resp.json().get("error", resp.text)
        console.print(f"  [red]Error:[/red] {detail}")
        raise SystemExit(1)

    guest_list = resp.json().get("guests", [])
    if not guest_list:
        console.print("  No guests invited.")
        return

    table = Table(title="Invited Guests")
    table.add_column("Username", style="bold")
    table.add_column("Invited by")
    table.add_column("Expires")
    table.add_column("Status")

    for g in guest_list:
        status_style = "green" if g["status"] == "active" else "red"
        table.add_row(
            g["github_username"],
            g.get("invited_by", ""),
            g.get("expires_at", ""),
            f"[{status_style}]{g['status']}[/{status_style}]",
        )

    console.print()
    console.print(table)
    console.print()


def _parse_duration(value: str) -> int | None:
    """Parse a duration string like '30d' into days."""
    match = re.fullmatch(r"(\d+)d", value.strip())
    if match:
        return int(match.group(1))
    return None


# ── Service Keys ─────────────────────────────────────────────────────────────


@cli.group(name="service-key")
def service_key():
    """Manage service keys for programmatic access."""


@service_key.command()
@click.argument("label")
@click.option(
    "--ttl",
    type=click.Choice(["7d", "30d", "90d", "365d"]),
    default="30d",
    show_default=True,
    help="Time-to-live for the service key.",
)
def create(label: str, ttl: str):
    """Create a new service key with the given LABEL."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [red]Error:[/red] Not logged in. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    ttl_days = int(ttl.rstrip("d"))

    with console.status("Creating service key..."):
        try:
            resp = httpx.post(
                settings.SERVICE_KEYS_ENDPOINT,
                json={"label": label, "ttl_days": ttl_days},
                headers={"X-Api-Key": creds["api_key"]},
                timeout=10,
            )
        except httpx.HTTPError as exc:
            console.print(f"  [red]Error:[/red] {exc}")
            raise SystemExit(1)

    if resp.status_code == 201:
        data = resp.json()
        raw_key = data.get("api_key", "")
        console.print("\n  [bold green]Service key created![/bold green]")
        console.print(f"\n  [bold yellow]{raw_key}[/bold yellow]")
        console.print("\n  [red]⚠  Save this key now — it cannot be retrieved again.[/red]")
        console.print(f"  Label: {label}")
        console.print(f"  Expires: {data.get('expires_at', 'unknown')}\n")
    elif resp.status_code == 409:
        console.print(f"  [red]Error:[/red] A service key with label [bold]{label}[/bold] already exists.")
        raise SystemExit(1)
    elif resp.status_code == 429:
        console.print("  [red]Error:[/red] Too many active service keys.")
        raise SystemExit(1)
    elif resp.status_code in (401, 403):
        console.print("  [red]Error:[/red] Authentication failed. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)
    else:
        detail = resp.json().get("error", resp.text)
        console.print(f"  [red]Error:[/red] {detail}")
        raise SystemExit(1)


@service_key.command(name="list")
def list_keys():
    """List your active service keys."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [red]Error:[/red] Not logged in. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    with console.status("Fetching service keys..."):
        try:
            resp = httpx.get(
                settings.SERVICE_KEYS_ENDPOINT,
                headers={"X-Api-Key": creds["api_key"]},
                timeout=10,
            )
        except httpx.HTTPError as exc:
            console.print(f"  [red]Error:[/red] {exc}")
            raise SystemExit(1)

    if resp.status_code in (401, 403):
        console.print("  [red]Error:[/red] Authentication failed. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)
    if resp.status_code != 200:
        detail = resp.json().get("error", resp.text)
        console.print(f"  [red]Error:[/red] {detail}")
        raise SystemExit(1)

    keys = resp.json().get("service_keys", [])
    if not keys:
        console.print("  No service keys found.")
        return

    table = Table(title="Service Keys")
    table.add_column("Label", style="bold")
    table.add_column("Expires At")
    table.add_column("IP")
    table.add_column("Status")

    for k in keys:
        status_val = k.get("status", "")
        status_style = "green" if status_val == "active" else "red"
        table.add_row(
            k.get("label", ""),
            k.get("expires_at", ""),
            k.get("ip", ""),
            f"[{status_style}]{status_val}[/{status_style}]",
        )

    console.print()
    console.print(table)
    console.print()


@service_key.command(name="revoke")
@click.argument("label")
def revoke_service_key(label: str):
    """Revoke the service key with the given LABEL."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [red]Error:[/red] Not logged in. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    with console.status("Revoking service key..."):
        try:
            resp = httpx.request(
                "DELETE",
                settings.SERVICE_KEYS_ENDPOINT,
                json={"label": label},
                headers={"X-Api-Key": creds["api_key"]},
                timeout=10,
            )
        except httpx.HTTPError as exc:
            console.print(f"  [red]Error:[/red] {exc}")
            raise SystemExit(1)

    if resp.status_code == 200:
        console.print(f"  Service key [bold]{label}[/bold] revoked.")
    elif resp.status_code in (401, 403):
        console.print("  [red]Error:[/red] Authentication failed. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)
    elif resp.status_code == 404:
        console.print(f"  [red]Error:[/red] No service key found with label [bold]{label}[/bold].")
        raise SystemExit(1)
    else:
        detail = resp.json().get("error", resp.text)
        console.print(f"  [red]Error:[/red] {detail}")
        raise SystemExit(1)


# ── Admin: Service Keys ─────────────────────────────────────────────────────


@admin.command(name="list-service-keys")
def admin_list_service_keys():
    """List all service keys across all users (org members only)."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [red]Error:[/red] Not logged in. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    with console.status("Fetching service keys..."):
        try:
            resp = httpx.get(
                settings.ADMIN_SERVICE_KEYS_ENDPOINT,
                headers={"X-Api-Key": creds["api_key"]},
                timeout=10,
            )
        except httpx.HTTPError as exc:
            console.print(f"  [red]Error:[/red] {exc}")
            raise SystemExit(1)

    if resp.status_code == 403:
        console.print("  [red]Error:[/red] Admin endpoints require org membership.")
        raise SystemExit(1)
    if resp.status_code != 200:
        detail = resp.json().get("error", resp.text)
        console.print(f"  [red]Error:[/red] {detail}")
        raise SystemExit(1)

    keys = resp.json().get("service_keys", [])
    if not keys:
        console.print("  No service keys found.")
        return

    table = Table(title="All Service Keys")
    table.add_column("Label", style="bold")
    table.add_column("Created By")
    table.add_column("Expires At")
    table.add_column("IP")
    table.add_column("Status")

    for k in keys:
        status_val = k.get("status", "")
        status_style = "green" if status_val == "active" else "red"
        table.add_row(
            k.get("label", ""),
            k.get("created_by", ""),
            k.get("expires_at", ""),
            k.get("ip", ""),
            f"[{status_style}]{status_val}[/{status_style}]",
        )

    console.print()
    console.print(table)
    console.print()


@admin.command(name="revoke-service-key")
@click.option("--user", required=True, help="GitHub username of the key owner.")
@click.option("--label", required=True, help="Label of the service key to revoke.")
def admin_revoke_service_key(user: str, label: str):
    """Revoke a specific user's service key (org members only)."""
    creds = config.read_credentials()
    if not creds:
        console.print("  [red]Error:[/red] Not logged in. Run: [bold]gsm login[/bold]")
        raise SystemExit(1)

    with console.status("Revoking service key..."):
        try:
            resp = httpx.request(
                "DELETE",
                settings.ADMIN_SERVICE_KEYS_ENDPOINT,
                json={"user": user, "label": label},
                headers={"X-Api-Key": creds["api_key"]},
                timeout=10,
            )
        except httpx.HTTPError as exc:
            console.print(f"  [red]Error:[/red] {exc}")
            raise SystemExit(1)

    if resp.status_code == 200:
        console.print(f"  Service key [bold]{label}[/bold] for user [bold]{user}[/bold] revoked.")
    elif resp.status_code == 403:
        console.print("  [red]Error:[/red] Admin endpoints require org membership.")
        raise SystemExit(1)
    elif resp.status_code == 404:
        console.print(f"  [red]Error:[/red] No service key [bold]{label}[/bold] found for user [bold]{user}[/bold].")
        raise SystemExit(1)
    else:
        detail = resp.json().get("error", resp.text)
        console.print(f"  [red]Error:[/red] {detail}")
        raise SystemExit(1)
