"""Remote config resolution for the GreatSky Metaflow extension.

Replaces Metaflow's default config loading with a flow that:
  1. Checks an env-var cache (subprocess stability — API key excluded)
  2. Reads the GSM config from the 3-tier hierarchy (project -> venv -> global)
  3. Uses file cache if fresh (< CACHE_TTL_SECONDS old), otherwise fetches from API
  4. Merges in the API key (always from disk) and METAFLOW_USER from credentials
  5. Caches the result (env var sans key + local file for offline fallback)
  6. Warns if the API key expires within 24 hours
"""

from __future__ import annotations

import json
import os
import sys
import time
from typing import Dict, Optional

ENV_CACHE_KEY = "__GSM_CONFIG_RESOLVED__"
GSM_AUTH_API_KEY = "GSM_AUTH_API"
AUTH_KEY_FIELD = "METAFLOW_SERVICE_AUTH_KEY"

CACHE_TTL_SECONDS = 3600  # 1 hour


def init_config() -> Dict[str, str]:
    """Load the full Metaflow config, fetching from the platform if needed."""

    from greatsky_internal_metaflow.config import resolve_gsm_dir

    cached = os.environ.get(ENV_CACHE_KEY)
    if cached:
        _debug("Using env cache")
        merged = json.loads(cached)
        api_key = _read_api_key_from_disk(resolve_gsm_dir)
        if api_key:
            merged[AUTH_KEY_FIELD] = api_key
        return merged

    gsm_dir = resolve_gsm_dir()
    if gsm_dir is None:
        return {}

    local_config = _read_json(gsm_dir / "config.json")
    if not local_config:
        return {}

    auth_api = local_config.get(GSM_AUTH_API_KEY)
    api_key = local_config.get(AUTH_KEY_FIELD)

    if not auth_api or not api_key:
        return local_config

    credentials = _read_json(gsm_dir / "credentials.json")

    cache_path = gsm_dir / "config_cache.json"
    remote_config = None

    if _cache_is_fresh(cache_path):
        remote_config = _read_json(cache_path)
        if remote_config is not None:
            _debug("Using fresh file cache (age < %ds)" % CACHE_TTL_SECONDS)

    if remote_config is None:
        fetched = _fetch_remote_config(auth_api, api_key)
        if fetched is not None:
            remote_config = fetched
            _write_config_cache(gsm_dir, remote_config)
        else:
            remote_config = _read_json(cache_path)
            if remote_config is None:
                _warn("Could not reach auth API and no cached config found.")
                return local_config
            _debug("Using stale file cache (API unreachable)")

    merged = dict(remote_config)
    merged[AUTH_KEY_FIELD] = api_key

    if credentials:
        github_user = credentials.get("github_user")
        if github_user and "METAFLOW_USER" not in os.environ:
            merged["METAFLOW_USER"] = github_user

        _check_expiry(credentials)

    _debug("Resolved %d config keys from %s" % (len(merged), gsm_dir))

    env_safe = {k: v for k, v in merged.items() if k != AUTH_KEY_FIELD}
    os.environ[ENV_CACHE_KEY] = json.dumps(env_safe)
    return merged


def _read_api_key_from_disk(resolve_gsm_dir) -> Optional[str]:
    """Read the API key from config.json on disk (never from env cache)."""
    try:
        gsm_dir = resolve_gsm_dir()
        if gsm_dir is None:
            return None
        local_config = _read_json(gsm_dir / "config.json")
        if local_config:
            return local_config.get(AUTH_KEY_FIELD)
    except Exception:
        pass
    return None


def _cache_is_fresh(cache_path) -> bool:
    """Check if the cache file exists and was modified within CACHE_TTL_SECONDS."""
    try:
        mtime = cache_path.stat().st_mtime
        return (time.time() - mtime) < CACHE_TTL_SECONDS
    except OSError:
        return False


def _read_json(path) -> Optional[Dict]:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text())
    except (json.JSONDecodeError, OSError):
        return None


def _fetch_remote_config(auth_api: str, api_key: str = "") -> Optional[Dict]:
    """Fetch the metaflow_config dict from /auth/client-config (authenticated)."""
    try:
        import httpx

        headers = {}
        if api_key:
            headers["X-Api-Key"] = api_key
        resp = httpx.get("%s/auth/client-config" % auth_api, headers=headers, timeout=10)
        resp.raise_for_status()
        data = resp.json()
        return data.get("metaflow_config", {})
    except Exception as exc:
        _debug("Remote config fetch failed: %s: %s" % (type(exc).__name__, exc))
        return None


def _write_config_cache(gsm_dir, config: Dict) -> None:
    try:
        gsm_dir.mkdir(parents=True, exist_ok=True)
        (gsm_dir / "config_cache.json").write_text(json.dumps(config, indent=2) + "\n")
    except OSError:
        pass


def _check_expiry(credentials: Dict) -> None:
    expires_at = credentials.get("expires_at", "")
    if not expires_at:
        return
    try:
        from datetime import datetime, timezone

        if expires_at.endswith("Z"):
            expires_at = expires_at[:-1] + "+00:00"
        expiry = datetime.fromisoformat(expires_at)
        now = datetime.now(timezone.utc)
        hours_left = (expiry - now).total_seconds() / 3600
        if hours_left < 0:
            _warn("API key has expired. Run: gsm login")
        elif hours_left < 24:
            _warn("API key expires in %d hours. Run: gsm login" % int(hours_left))
    except (ValueError, TypeError):
        pass


def _warn(msg: str) -> None:
    print("[greatsky] %s" % msg, file=sys.stderr)


_DEBUG = os.environ.get("GSM_DEBUG_CONFIG", "")


def _debug(msg: str) -> None:
    if _DEBUG:
        print("[greatsky:debug] %s" % msg, file=sys.stderr)
