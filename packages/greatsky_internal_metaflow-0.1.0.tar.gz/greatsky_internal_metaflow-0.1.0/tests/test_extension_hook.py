"""Test that the config extension properly injects values into metaflow_config."""

import json
import os

import pytest

pytest.importorskip("metaflow")

from greatsky_internal_metaflow import config as gsm_config
from metaflow_extensions.greatsky import remote_config

FAKE_REMOTE_CONFIG = {
    "METAFLOW_DEFAULT_DATASTORE": "s3",
    "METAFLOW_DATASTORE_SYSROOT_S3": "s3://bucket/metaflow",
    "METAFLOW_DEFAULT_METADATA": "service",
    "METAFLOW_SERVICE_URL": "https://metaflow-api.example.com/",
    "METAFLOW_KUBERNETES_NAMESPACE": "metaflow-jobs",
}


def test_config_extension_injects_globals(tmp_path, monkeypatch):
    """Verify that the config extension's globals (prefix-stripped) appear in the
    config module's __dict__, which is how metaflow_config.py picks them up."""
    gsm_dir = tmp_path / ".greatsky_gsm"
    gsm_dir.mkdir()
    (gsm_dir / "config.json").write_text(
        json.dumps(
            {
                "GSM_AUTH_API": "https://auth.example.com",
                "METAFLOW_SERVICE_AUTH_KEY": "gsk_test123",
            }
        )
    )
    (gsm_dir / "credentials.json").write_text(
        json.dumps(
            {
                "github_user": "testuser",
                "expires_at": "2099-01-01T00:00:00Z",
            }
        )
    )

    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.delenv("METAFLOW_USER", raising=False)
    os.environ.pop(remote_config.ENV_CACHE_KEY, None)

    class FakeResponse:
        status_code = 200

        def raise_for_status(self):
            pass

        def json(self):
            return {"metaflow_config": FAKE_REMOTE_CONFIG}

    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, **kw: FakeResponse())

    config = remote_config.init_config()

    assert config["METAFLOW_SERVICE_URL"] == "https://metaflow-api.example.com/"
    assert config["METAFLOW_DEFAULT_DATASTORE"] == "s3"
    assert config["METAFLOW_SERVICE_AUTH_KEY"] == "gsk_test123"
    assert config["METAFLOW_USER"] == "testuser"

    import importlib

    from metaflow_extensions.greatsky import config as config_mod

    importlib.reload(config_mod)

    assert config_mod.SERVICE_URL == "https://metaflow-api.example.com/"
    assert config_mod.DEFAULT_DATASTORE == "s3"
    assert config_mod.KUBERNETES_NAMESPACE == "metaflow-jobs"

    os.environ.pop(remote_config.ENV_CACHE_KEY, None)


def test_init_config_replaced_on_config_funcs(tmp_path, monkeypatch):
    """Verify that metaflow_config_funcs.init_config points to our version."""
    import metaflow.metaflow_config_funcs as mf_funcs

    from metaflow_extensions.greatsky.remote_config import init_config

    assert mf_funcs.init_config is init_config
