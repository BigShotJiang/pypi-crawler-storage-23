from k8s_ai.cli import app

if __name__ == "__main__":
    app()
