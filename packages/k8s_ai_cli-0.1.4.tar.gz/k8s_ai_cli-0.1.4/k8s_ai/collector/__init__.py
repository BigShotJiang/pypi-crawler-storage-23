from .kubectl_collector import KubectlCollector

__all__ = ["KubectlCollector"]
