from .command_generator import augment_with_safe_kubectl_commands

__all__ = ["augment_with_safe_kubectl_commands"]
