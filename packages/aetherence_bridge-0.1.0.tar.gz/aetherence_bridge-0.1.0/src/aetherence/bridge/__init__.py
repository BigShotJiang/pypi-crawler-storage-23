"""Aetherence bridge Module"""
__version__ = "0.1.0"
