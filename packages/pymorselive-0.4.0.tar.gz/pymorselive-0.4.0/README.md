# PyMorseLive

Simple multi-channel timing-based morse decoder written in ~300 lines of Python. 

https://github.com/user-attachments/assets/a94d5f75-3a7c-4923-a95c-cbe88091b095

## Installation
Install from PyPI using

```
pip install PyMorseLive
```
## Using
Open a command window and type 
```
pymorse
```
Alternatively download the source file (there's only one currently in the pymorse folder) and edit it as needed.

Type
```
pymorse --help
```
to show the available command line options
