# Copyright 2024 Klira AI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Evaluation types — test cases and results."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class KliraTestCase:
    """A single test case for evaluation."""

    input: str
    expected_output: str | None = None
    context: list[str] | None = None
    metadata: dict[str, Any] | None = None


@dataclass(frozen=True)
class KliraEvalResult:
    """Result of an evaluation run.

    The SDK captures traces — the platform evaluates them server-side.
    """

    test_cases: list[KliraTestCase]
    total_test_cases: int
    duration_seconds: float
    experiment_id: str | None = None
    errors: list[str] = field(default_factory=list)
