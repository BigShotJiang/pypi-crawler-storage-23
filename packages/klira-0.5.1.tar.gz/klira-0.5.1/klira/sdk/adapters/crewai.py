# Copyright 2024 Klira AI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""CrewAI adapter.

No double instrumentation — Klira patches only. Traceloop auto-
instrumentation is gone in v2. No separate @crew decorator needed.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from klira.sdk.adapters.base_framework import BaseFrameworkAdapter

logger = logging.getLogger(__name__)


class CrewAIAdapter(BaseFrameworkAdapter):
    """Adapter for CrewAI."""

    @property
    def framework_name(self) -> str:
        return "crewai"

    def adapt_workflow(self, func: Callable[..., Any]) -> Callable[..., Any]:
        return func

    def adapt_agent(self, func: Callable[..., Any]) -> Callable[..., Any]:
        return func

    def adapt_tool(self, func: Callable[..., Any]) -> Callable[..., Any]:
        """Must preserve callability (Learning #12)."""
        return func

    def adapt_task(self, func: Callable[..., Any]) -> Callable[..., Any]:
        return func

    def patch_framework(self) -> None:
        """Suppress CrewAI/Traceloop auto-instrumentation."""
        try:
            import crewai  # type: ignore[import-untyped]

            # Disable any Traceloop-based tracing that CrewAI might use
            if hasattr(crewai, "telemetry"):
                telemetry = crewai.telemetry
                if hasattr(telemetry, "Telemetry"):
                    telemetry.Telemetry._ready = False  # type: ignore[attr-defined]
            logger.debug("CrewAI telemetry disabled")
        except ImportError:
            logger.debug("CrewAI not available, skipping suppression")

    def verify_suppression(self) -> bool:
        """Verify CrewAI native telemetry is disabled."""
        try:
            import crewai  # type: ignore[import-untyped]

            if hasattr(crewai, "telemetry") and hasattr(crewai.telemetry, "Telemetry"):
                return not getattr(crewai.telemetry.Telemetry, "_ready", True)
        except ImportError:
            pass
        return True
