# Copyright 2024 Klira AI
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""LlamaIndex adapter.

Suppresses LlamaIndex's optional callback-based tracing.
"""

from __future__ import annotations

import logging
from typing import Any, Callable

from klira.sdk.adapters.base_framework import BaseFrameworkAdapter

logger = logging.getLogger(__name__)


class LlamaIndexAdapter(BaseFrameworkAdapter):
    """Adapter for LlamaIndex."""

    @property
    def framework_name(self) -> str:
        return "llamaindex"

    def adapt_workflow(self, func: Callable[..., Any]) -> Callable[..., Any]:
        return func

    def adapt_agent(self, func: Callable[..., Any]) -> Callable[..., Any]:
        return func

    def adapt_tool(self, func: Callable[..., Any]) -> Callable[..., Any]:
        """Must preserve callability (Learning #12)."""
        return func

    def adapt_task(self, func: Callable[..., Any]) -> Callable[..., Any]:
        return func

    def patch_framework(self) -> None:
        """Suppress LlamaIndex callback tracing."""
        try:
            from llama_index.core import Settings  # type: ignore[import-untyped]

            Settings.callback_manager = None  # type: ignore[assignment]
            logger.debug("LlamaIndex callback tracing disabled")
        except ImportError:
            logger.debug("LlamaIndex not available, skipping suppression")

    def verify_suppression(self) -> bool:
        """Verify LlamaIndex callback tracing is disabled."""
        try:
            from llama_index.core import Settings  # type: ignore[import-untyped]

            return Settings.callback_manager is None
        except ImportError:
            return True
