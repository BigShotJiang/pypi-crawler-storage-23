"""This is used to allow unit tests to instantiate fake actor objects
from within the test directory structure."""
