"""TUS protocol server implementation."""

import base64
import binascii
import hashlib
import logging
import re
import threading
import uuid
from datetime import datetime, timedelta, timezone
from email.utils import formatdate
from http.server import BaseHTTPRequestHandler
from typing import Any, Optional

from resumable_upload.storage import SQLiteStorage, Storage

logger = logging.getLogger(__name__)

_UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")

_TUS_EXPOSE_HEADERS = (
    "Upload-Offset,Location,Upload-Length,Tus-Version,Tus-Resumable,"
    "Tus-Max-Size,Tus-Extension,Upload-Metadata,Upload-Expires"
)
_TUS_ALLOW_HEADERS = (
    "Origin,X-Requested-With,Content-Type,Upload-Length,Upload-Offset,"
    "Tus-Resumable,Upload-Metadata,Upload-Checksum,Upload-Expires"
)


class TusServer:
    """TUS protocol server implementation.

    This server implements TUS protocol version 1.0.0 as specified at:
    https://tus.io/protocols/resumable-upload.html

    Version Handling:
        - Supports only TUS version 1.0.0
        - Requires clients to send "Tus-Resumable: 1.0.0" header
        - Returns 412 Precondition Failed for other versions
        - This is compliant with TUS specification

    Supported Extensions:
        - creation: Upload creation via POST
        - termination: Upload deletion via DELETE
        - checksum: SHA1 checksum verification
        - expiration: Upload expiration support
        - creation-with-upload: Initial data in POST body

    Example:
        >>> storage = SQLiteStorage()
        >>> server = TusServer(storage=storage, base_path="/files")
        >>> status, headers, body = server.handle_request(
        ...     "POST",
        ...     "/files",
        ...     {"tus-resumable": "1.0.0", "upload-length": "1024"},
        ...     b"",
        ... )
    """

    TUS_VERSION = "1.0.0"
    _MAX_METADATA_SIZE = 4096  # 4 KB limit to guard against DoS
    SUPPORTED_EXTENSIONS = [
        "creation",
        "termination",
        "checksum",
        "expiration",
        "creation-with-upload",
    ]

    def __init__(
        self,
        storage: Optional[Storage] = None,
        base_path: str = "/files",
        max_size: int = 0,
        upload_expiry: Optional[int] = None,
        cors_allow_origins: Optional[str] = None,
        cleanup_interval: int = 60,
        request_timeout: int = 30,
    ):
        """Initialize TUS server.

        Args:
            storage: Storage backend (defaults to SQLiteStorage)
            base_path: Base URL path for uploads
            max_size: Maximum upload size in bytes (0 = unlimited)
            upload_expiry: Upload expiry in seconds (None = no expiry)
            cors_allow_origins: CORS allowed origins (None = no CORS headers)
            cleanup_interval: Minimum seconds between expired-upload cleanup runs (default: 60)
            request_timeout: Socket read timeout in seconds for HTTP handler (default: 30)
        """
        self.storage = storage or SQLiteStorage()
        self.base_path = base_path.rstrip("/")
        self.max_size = max_size
        self.upload_expiry = upload_expiry
        self.cors_allow_origins = cors_allow_origins
        self.cleanup_interval = cleanup_interval
        self.request_timeout = request_timeout
        self._last_cleanup: Optional[datetime] = None
        self._cleanup_lock = threading.Lock()

    def _validate_upload_id(self, upload_id: str) -> bool:
        """Validate that upload_id is a valid UUID to prevent path traversal."""
        return bool(_UUID_RE.match(upload_id))

    def _error_response(self, status: int, message: str) -> tuple[int, dict, bytes]:
        """Build a consistent error response with Tus-Resumable header."""
        return (status, {"Tus-Resumable": self.TUS_VERSION}, message.encode())

    def _add_cors_headers(self, headers: dict) -> dict:
        """Add CORS headers if cors_allow_origins is configured."""
        if self.cors_allow_origins:
            headers["Access-Control-Allow-Origin"] = self.cors_allow_origins
            headers["Access-Control-Expose-Headers"] = _TUS_EXPOSE_HEADERS
            headers["Access-Control-Allow-Methods"] = "GET,POST,HEAD,PATCH,DELETE,OPTIONS"
            headers["Access-Control-Allow-Headers"] = _TUS_ALLOW_HEADERS
        return headers

    def _format_expiry(self, expires_at: datetime) -> str:
        """Format expiry datetime as RFC 7231 date string."""
        return formatdate(expires_at.timestamp(), usegmt=True)

    def handle_request(
        self, method: str, path: str, headers: dict[str, str], body: bytes = b""
    ) -> tuple[int, dict[str, str], bytes]:
        """Handle an incoming HTTP request.

        Args:
            method: HTTP method
            path: Request path
            headers: Request headers
            body: Request body

        Returns:
            Tuple of (status_code, response_headers, response_body)
        """
        logger.info(f"Received {method} request for {path}")

        # Normalize headers to lowercase
        headers = {k.lower(): v for k, v in headers.items()}

        # Check TUS version (required by TUS spec for all non-OPTIONS requests)
        if method != "OPTIONS":
            tus_version = headers.get("tus-resumable")
            if tus_version != self.TUS_VERSION:
                logger.warning(f"Invalid TUS version: {tus_version}, expected {self.TUS_VERSION}")
                status, resp_headers, resp_body = (
                    412,
                    {"Tus-Resumable": self.TUS_VERSION},
                    b"Precondition Failed: Invalid TUS version",
                )
                return (status, self._add_cors_headers(resp_headers), resp_body)

        # Route request
        if method == "OPTIONS":
            result = self._handle_options(path, headers)
        elif method == "POST" and path == self.base_path:
            result = self._handle_create(headers, body)
        elif method == "HEAD" and path.startswith(self.base_path + "/"):
            upload_id = path[len(self.base_path) + 1 :]
            if not self._validate_upload_id(upload_id):
                result = self._error_response(400, "Invalid upload ID format")
            else:
                result = self._handle_head(upload_id, headers)
        elif method == "PATCH" and path.startswith(self.base_path + "/"):
            upload_id = path[len(self.base_path) + 1 :]
            if not self._validate_upload_id(upload_id):
                result = self._error_response(400, "Invalid upload ID format")
            else:
                result = self._handle_patch(upload_id, headers, body)
        elif method == "DELETE" and path.startswith(self.base_path + "/"):
            upload_id = path[len(self.base_path) + 1 :]
            if not self._validate_upload_id(upload_id):
                result = self._error_response(400, "Invalid upload ID format")
            else:
                result = self._handle_delete(upload_id, headers)
        else:
            logger.warning(f"Route not found: {method} {path}")
            result = self._error_response(404, "Not Found")

        status, resp_headers, resp_body = result

        # Periodically clean up expired uploads after the current request is handled,
        # so the current request still gets 410 for an expired upload before it's deleted
        if self.upload_expiry is not None:
            now = datetime.now(timezone.utc)
            if (
                self._last_cleanup is None
                or (now - self._last_cleanup).total_seconds() >= self.cleanup_interval
            ):
                with self._cleanup_lock:
                    # Re-check after acquiring lock (double-check pattern)
                    if (
                        self._last_cleanup is None
                        or (now - self._last_cleanup).total_seconds() >= self.cleanup_interval
                    ):
                        self._last_cleanup = now
                        count = self.storage.cleanup_expired_uploads()
                        if count:
                            logger.info(f"Cleaned up {count} expired upload(s)")

        return (status, self._add_cors_headers(resp_headers), resp_body)

    def _handle_options(
        self, path: str, headers: dict[str, str]
    ) -> tuple[int, dict[str, str], bytes]:
        """Handle OPTIONS request for capability discovery."""
        logger.debug("Handling OPTIONS request")
        response_headers = {
            "Tus-Resumable": self.TUS_VERSION,
            "Tus-Version": self.TUS_VERSION,
            "Tus-Extension": ",".join(self.SUPPORTED_EXTENSIONS),
            "Tus-Checksum-Algorithm": "sha1",
        }

        if self.max_size > 0:
            response_headers["Tus-Max-Size"] = str(self.max_size)

        return (204, response_headers, b"")

    def _handle_create(
        self, headers: dict[str, str], body: bytes
    ) -> tuple[int, dict[str, str], bytes]:
        """Handle POST request to create a new upload."""
        upload_length_str = headers.get("upload-length")
        if not upload_length_str:
            logger.error("Missing Upload-Length header")
            return self._error_response(400, "Missing Upload-Length header")

        try:
            upload_length = int(upload_length_str)
        except ValueError:
            logger.error(f"Invalid Upload-Length header: {upload_length_str}")
            return self._error_response(400, "Invalid Upload-Length header")

        if upload_length < 0:
            logger.error(f"Negative Upload-Length header: {upload_length}")
            return self._error_response(400, "Upload-Length must not be negative")

        if self.max_size > 0 and upload_length > self.max_size:
            logger.warning(f"Upload size {upload_length} exceeds maximum {self.max_size}")
            return self._error_response(413, "Upload exceeds maximum size")

        # Parse metadata
        metadata = {}
        upload_metadata = headers.get("upload-metadata", "")
        if upload_metadata:
            if len(upload_metadata) > self._MAX_METADATA_SIZE:
                return self._error_response(
                    400, f"Upload-Metadata exceeds maximum size of {self._MAX_METADATA_SIZE} bytes"
                )
            for pair in upload_metadata.split(","):
                pair = pair.strip()
                if " " in pair:
                    key, value = pair.split(" ", 1)
                    try:
                        metadata[key] = base64.b64decode(value).decode("utf-8")
                    except (ValueError, UnicodeDecodeError, binascii.Error) as e:
                        return self._error_response(
                            400, f"Invalid base64 encoding for metadata key '{key}': {e}"
                        )

        # Generate upload ID
        upload_id = str(uuid.uuid4())

        # Compute expiry
        expires_at = None
        if self.upload_expiry:
            expires_at = datetime.now(timezone.utc) + timedelta(seconds=self.upload_expiry)

        # Create upload
        self.storage.create_upload(upload_id, upload_length, metadata, expires_at)
        logger.info(f"Created upload {upload_id} with length {upload_length}, metadata: {metadata}")

        # Handle creation-with-upload: process initial data if provided
        initial_offset = 0
        content_type = headers.get("content-type", "")
        if body and content_type != "application/offset+octet-stream":
            # Body present but Content-Type doesn't match — body is silently ignored per TUS spec.
            # Log a warning so developers can catch misconfigurations.
            logger.warning(
                "POST body received with Content-Type '%s' instead of "
                "application/offset+octet-stream; body ignored (not creation-with-upload)",
                content_type,
            )
        if body and content_type == "application/offset+octet-stream":
            self.storage.write_chunk(upload_id, 0, body)
            initial_offset = len(body)
            self.storage.update_offset(upload_id, initial_offset)
            logger.info(f"creation-with-upload: wrote {initial_offset} bytes for {upload_id}")

        # Return response
        response_headers = {
            "Tus-Resumable": self.TUS_VERSION,
            "Location": f"{self.base_path}/{upload_id}",
            "Upload-Offset": str(initial_offset),
        }

        if expires_at:
            response_headers["Upload-Expires"] = self._format_expiry(expires_at)

        return (201, response_headers, b"")

    def _handle_head(
        self, upload_id: str, headers: dict[str, str]
    ) -> tuple[int, dict[str, str], bytes]:
        """Handle HEAD request to get upload offset."""
        upload = self.storage.get_upload(upload_id)
        if not upload:
            logger.warning(f"Upload not found: {upload_id}")
            return self._error_response(404, "Upload not found")

        # Check expiration
        expires_at = upload.get("expires_at")
        if expires_at and expires_at < datetime.now(timezone.utc):
            logger.warning(f"Upload expired: {upload_id}")
            return self._error_response(410, "Upload has expired")

        logger.debug(
            f"HEAD request for upload {upload_id}: "
            f"offset={upload['offset']}, length={upload['upload_length']}"
        )
        response_headers = {
            "Tus-Resumable": self.TUS_VERSION,
            "Upload-Offset": str(upload["offset"]),
            "Upload-Length": str(upload["upload_length"]),
            "Cache-Control": "no-store",
        }

        if expires_at:
            response_headers["Upload-Expires"] = self._format_expiry(expires_at)

        # Include metadata if present
        metadata = upload.get("metadata", {})
        if metadata:
            encoded_metadata = []
            for key, value in metadata.items():
                value_bytes = value.encode("utf-8")
                encoded_value = base64.b64encode(value_bytes).decode("ascii")
                encoded_metadata.append(f"{key} {encoded_value}")
            response_headers["Upload-Metadata"] = ",".join(encoded_metadata)

        return (200, response_headers, b"")

    def _handle_patch(
        self, upload_id: str, headers: dict[str, str], body: bytes
    ) -> tuple[int, dict[str, str], bytes]:
        """Handle PATCH request to append data to upload."""
        upload = self.storage.get_upload(upload_id)
        if not upload:
            logger.warning(f"Upload not found: {upload_id}")
            return self._error_response(404, "Upload not found")

        # Check expiration
        expires_at = upload.get("expires_at")
        if expires_at and expires_at < datetime.now(timezone.utc):
            logger.warning(f"Upload expired: {upload_id}")
            return self._error_response(410, "Upload has expired")

        # Check if already completed
        if upload.get("completed"):
            logger.warning(f"Upload already completed: {upload_id}")
            return self._error_response(403, "Upload already completed")

        # Check content type
        content_type = headers.get("content-type", "")
        if content_type != "application/offset+octet-stream":
            logger.error(f"Invalid Content-Type: {content_type}")
            return self._error_response(415, "Invalid Content-Type")

        # Check upload offset
        upload_offset_str = headers.get("upload-offset")
        if not upload_offset_str:
            logger.error("Missing Upload-Offset header")
            return self._error_response(400, "Missing Upload-Offset header")

        try:
            upload_offset = int(upload_offset_str)
        except ValueError:
            logger.error(f"Invalid Upload-Offset header: {upload_offset_str}")
            return self._error_response(400, "Invalid Upload-Offset header")

        if upload_offset < 0:
            logger.error(f"Negative Upload-Offset: {upload_offset}")
            return self._error_response(400, "Upload-Offset must not be negative")

        if upload_offset != upload["offset"]:
            logger.error(
                f"Upload-Offset mismatch: expected {upload['offset']}, got {upload_offset}"
            )
            return self._error_response(409, "Upload-Offset mismatch")

        # Verify checksum if provided
        upload_checksum = headers.get("upload-checksum")
        if upload_checksum:
            try:
                algo, checksum = upload_checksum.split(" ", 1)
                if algo == "sha1":
                    computed = hashlib.sha1(body).hexdigest()
                    provided = base64.b64decode(checksum).hex()
                    if computed != provided:
                        logger.error(f"Checksum mismatch for upload {upload_id}")
                        return self._error_response(460, "Checksum mismatch")
            except (ValueError, binascii.Error) as e:
                logger.error(f"Invalid Upload-Checksum header: {e}")
                return self._error_response(400, "Invalid Upload-Checksum header")

        # Reject chunk if it would exceed the declared upload length
        new_offset = upload_offset + len(body)
        if new_offset > upload["upload_length"]:
            logger.error(f"Chunk exceeds upload length: {new_offset} > {upload['upload_length']}")
            return self._error_response(400, "Chunk would exceed declared upload length")

        # Write chunk then atomically advance offset.
        # If another concurrent request already advanced the offset, return 409.
        self.storage.write_chunk(upload_id, upload_offset, body)
        if not self.storage.update_offset_atomic(upload_id, upload_offset, new_offset):
            return self._error_response(409, "Concurrent write conflict; use HEAD to re-sync")

        logger.info(
            f"PATCH upload {upload_id}: wrote {len(body)} bytes, "
            f"new offset: {new_offset}/{upload['upload_length']}"
        )

        # Return response
        response_headers = {
            "Tus-Resumable": self.TUS_VERSION,
            "Upload-Offset": str(new_offset),
        }

        if expires_at:
            response_headers["Upload-Expires"] = self._format_expiry(expires_at)

        return (204, response_headers, b"")

    def _handle_delete(
        self, upload_id: str, headers: dict[str, str]
    ) -> tuple[int, dict[str, str], bytes]:
        """Handle DELETE request to terminate upload."""
        upload = self.storage.get_upload(upload_id)
        if not upload:
            logger.warning(f"Upload not found for deletion: {upload_id}")
            return self._error_response(404, "Upload not found")

        self.storage.delete_upload(upload_id)
        logger.info(f"Deleted upload {upload_id}")

        response_headers = {
            "Tus-Resumable": self.TUS_VERSION,
        }

        return (204, response_headers, b"")


class TusHTTPRequestHandler(BaseHTTPRequestHandler):
    """HTTP request handler for TUS server."""

    tus_server: TusServer = None

    def do_OPTIONS(self) -> None:
        """Handle OPTIONS request."""
        self._handle_request("OPTIONS")

    def do_POST(self) -> None:
        """Handle POST request."""
        self._handle_request("POST")

    def do_HEAD(self) -> None:
        """Handle HEAD request."""
        self._handle_request("HEAD")

    def do_PATCH(self) -> None:
        """Handle PATCH request."""
        self._handle_request("PATCH")

    def do_DELETE(self) -> None:
        """Handle DELETE request."""
        self._handle_request("DELETE")

    def setup(self) -> None:
        """Set socket read timeout from server config to guard against Slowloris."""
        super().setup()
        if self.tus_server and self.tus_server.request_timeout > 0:
            self.connection.settimeout(self.tus_server.request_timeout)

    def _handle_request(self, method: str) -> None:
        """Handle incoming request."""
        # Read body for POST/PATCH
        body = b""
        if method in ("POST", "PATCH"):
            try:
                content_length = int(self.headers.get("Content-Length", 0))
            except (ValueError, TypeError):
                self.send_response(400)
                self.send_header("Tus-Resumable", self.tus_server.TUS_VERSION)
                self.end_headers()
                self.wfile.write(b"Invalid Content-Length header")
                return
            if content_length < 0:
                self.send_response(400)
                self.send_header("Tus-Resumable", self.tus_server.TUS_VERSION)
                self.end_headers()
                self.wfile.write(b"Content-Length must not be negative")
                return
            max_size = self.tus_server.max_size
            if max_size > 0 and content_length > max_size:
                self.send_response(413)
                self.send_header("Tus-Resumable", self.tus_server.TUS_VERSION)
                self.end_headers()
                self.wfile.write(b"Request entity too large")
                return
            if content_length > 0:
                body = self.rfile.read(content_length)

        # Convert headers to dict
        headers = dict(self.headers)

        # Handle request
        status, response_headers, response_body = self.tus_server.handle_request(
            method, self.path, headers, body
        )

        # Send response
        self.send_response(status)
        for key, value in response_headers.items():
            self.send_header(key, value)
        self.end_headers()
        if response_body:
            self.wfile.write(response_body)

    def log_message(self, format: str, *args: Any) -> None:
        """Suppress default logging."""
        pass
