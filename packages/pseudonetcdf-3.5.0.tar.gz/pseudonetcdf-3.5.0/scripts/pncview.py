#!/usr/bin/env python
from PseudoNetCDF.pncview import main
main()
