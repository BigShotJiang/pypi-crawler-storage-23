#!/usr/bin/env python
from PseudoNetCDF.pncgen import main
main()
