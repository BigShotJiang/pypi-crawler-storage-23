#!/usr/bin/env python
from PseudoNetCDF.pnceval import main
main()
