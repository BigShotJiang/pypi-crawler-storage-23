#!/usr/bin/env python
from PseudoNetCDF.pncdump import main
main()
