from __future__ import print_function
__all__ = ['registerreader', 'registerwriter']
from ._getreader import registerreader
from ._getwriter import registerwriter
