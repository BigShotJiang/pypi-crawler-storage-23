__all__ = ['test_ffi1001']

from PseudoNetCDF.icarttfiles.ffi1001 import TestFfi1001 as test_ffi1001
