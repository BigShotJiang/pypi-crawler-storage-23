__all__ = ['test_pncopen']

from PseudoNetCDF._getreader import TestPNCOPEN as test_pncopen
