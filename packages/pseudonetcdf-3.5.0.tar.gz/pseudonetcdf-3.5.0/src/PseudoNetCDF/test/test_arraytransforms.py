__all__ = ['test_interiorvertex']

from PseudoNetCDF.ArrayTransforms import TestInteriorVertex
test_interiorvertex = TestInteriorVertex
