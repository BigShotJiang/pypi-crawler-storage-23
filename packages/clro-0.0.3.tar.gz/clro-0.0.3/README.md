# clro
clear object

## how 2 use

1\. `pip install clro`

2\. usinf in shell
```python
>>> import clro
>>> -c
input clrcmd : clear
>>> -x
```

## updated

- owopkg is not more included in this project.