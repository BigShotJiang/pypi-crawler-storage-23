"""
rapid-rag: Fast local RAG - search your documents with AI, no cloud needed.

Usage:
    from rapid_rag import RapidRAG

    # Create a RAG instance
    rag = RapidRAG("my_documents")

    # Add documents
    rag.add("doc1", "The quick brown fox jumps over the lazy dog.")
    rag.add_file("report.pdf")
    rag.add_directory("./docs/")

    # Search
    results = rag.search("fox jumping")

    # RAG query (with LLM)
    answer = rag.query("What does the fox do?", model="qwen2.5:7b")
"""

from .core import RapidRAG
from .ingest import DocumentIngester
from .search import SemanticSearch
from .tibet import TIBETProvider, TIBETToken

__version__ = "0.2.0"
__all__ = ["RapidRAG", "DocumentIngester", "SemanticSearch", "TIBETProvider", "TIBETToken"]
