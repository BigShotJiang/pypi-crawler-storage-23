#!/usr/bin/env python3
"""
Add indexes to support efficient MongoDB joins for task live data architecture
"""

import os
import asyncio
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING, DESCENDING
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# MongoDB connection settings
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "smart_table")


async def add_task_join_indexes():
    """Add indexes to support efficient task queue $lookup operations"""

    # Safety check: Only run on local development environment
    if "localhost" not in MONGODB_URI and "127.0.0.1" not in MONGODB_URI:
        logger.error("❌ SAFETY CHECK: This migration should only run on local development environment!")
        logger.error(f"Current MONGODB_URI: {MONGODB_URI}")
        logger.error("Refusing to run on production database. Use localhost MongoDB for development.")
        return

    logger.info(f"✅ Running on local development environment: {MONGODB_URI}")

    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]

    try:
        # Helper function to safely create index if it doesn't exist
        async def create_index_if_not_exists(collection, index_spec, index_name=None):
            existing_indexes = await collection.list_indexes().to_list(length=None)
            existing_index_names = {idx['name'] for idx in existing_indexes}

            # Check if an index with the same fields already exists
            for idx in existing_indexes:
                if 'key' in idx and list(idx['key'].items()) == index_spec:
                    logger.info(f"Index with same fields already exists: {idx['name']}")
                    return

            # Create index if not exists
            try:
                await collection.create_index(index_spec, name=index_name)
                logger.info(f"Created index: {index_name or 'unnamed'}")
            except Exception as e:
                if "already exists" in str(e):
                    logger.info(f"Index already exists, skipping: {e}")
                else:
                    raise

        # 1. Task queue indexes for JOIN performance
        logger.info("Creating compound index on task_queue (organization_id, lead_id)")
        await create_index_if_not_exists(db.task_queue, [
            ("organization_id", ASCENDING),
            ("lead_id", ASCENDING)
        ], "task_lead_join_index")

        logger.info("Creating compound index on task_queue (organization_id, company_id)")
        await create_index_if_not_exists(db.task_queue, [
            ("organization_id", ASCENDING),
            ("company_id", ASCENDING)
        ], "task_company_join_index")

        logger.info("Creating compound index on task_queue (organization_id, assigned_to)")
        await create_index_if_not_exists(db.task_queue, [
            ("organization_id", ASCENDING),
            ("assigned_to", ASCENDING)
        ], "task_assigned_to_index")

        # 2. Task queue filtering and sorting indexes
        logger.info("Creating compound index on task_queue (organization_id, task_status)")
        await db.task_queue.create_index([
            ("organization_id", ASCENDING),
            ("task_status", ASCENDING)
        ])

        logger.info("Creating compound index on task_queue (organization_id, due_date)")
        await db.task_queue.create_index([
            ("organization_id", ASCENDING),
            ("due_date", ASCENDING)
        ])

        logger.info("Creating compound index on task_queue (organization_id, priority)")
        await db.task_queue.create_index([
            ("organization_id", ASCENDING),
            ("priority", ASCENDING)
        ])

        logger.info("Creating compound index on task_queue (organization_id, channel)")
        await db.task_queue.create_index([
            ("organization_id", ASCENDING),
            ("channel", ASCENDING)
        ])

        logger.info("Creating compound index on task_queue (organization_id, lead_timezone)")
        await db.task_queue.create_index([
            ("organization_id", ASCENDING),
            ("lead_timezone", ASCENDING)
        ])

        # 3. Leads collection indexes for JOIN performance
        logger.info("Creating compound index on leads (organization_id, _id)")
        await db.leads.create_index([
            ("organization_id", ASCENDING),
            ("_id", ASCENDING)
        ])

        # 4. Companies collection indexes for JOIN performance
        logger.info("Creating compound index on companies (organization_id, _id)")
        await db.companies.create_index([
            ("organization_id", ASCENDING),
            ("_id", ASCENDING)
        ])

        # 5. Performance optimization: Compound index for common queries
        logger.info("Creating compound index on task_queue for common list queries")
        await db.task_queue.create_index([
            ("organization_id", ASCENDING),
            ("task_status", ASCENDING),
            ("due_date", ASCENDING),
            ("_id", ASCENDING)  # For pagination stability
        ])

        # List all task_queue indexes
        logger.info("\nCurrent indexes on task_queue collection:")
        task_indexes = await db.task_queue.list_indexes().to_list(None)
        for idx in task_indexes:
            logger.info(f"  - {idx['name']}: {idx['key']}")

        logger.info("\nCurrent indexes on leads collection:")
        leads_indexes = await db.leads.list_indexes().to_list(None)
        for idx in leads_indexes:
            logger.info(f"  - {idx['name']}: {idx['key']}")

        logger.info("\nCurrent indexes on companies collection:")
        companies_indexes = await db.companies.list_indexes().to_list(None)
        for idx in companies_indexes:
            logger.info(f"  - {idx['name']}: {idx['key']}")

        logger.info("\nTask join indexes created successfully!")

    except Exception as e:
        logger.error(f"Error creating task join indexes: {e}")
        raise
    finally:
        client.close()


async def analyze_task_join_performance():
    """Analyze task aggregation pipeline performance with explain()"""

    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]

    try:
        # Get a sample organization
        sample_task = await db.task_queue.find_one()
        if not sample_task:
            logger.warning("No tasks found for performance analysis")
            return

        organization_id = sample_task["organization_id"]
        logger.info(f"\nAnalyzing task aggregation performance for organization: {organization_id}")

        # Test aggregation pipeline performance with $lookup
        pipeline = [
            # Stage 1: Match organization tasks
            {"$match": {"organization_id": organization_id}},

            # Stage 2: Lookup lead data
            {"$lookup": {
                "from": "leads",
                "let": {"leadId": {"$toObjectId": "$lead_id"}},
                "pipeline": [
                    {"$match": {
                        "$expr": {"$eq": ["$_id", "$$leadId"]},
                        "organization_id": organization_id
                    }},
                    {"$project": {
                        "first_name": 1, "last_name": 1, "title": 1,
                        "company_domain": 1, "company_name": 1
                    }}
                ],
                "as": "lead_data"
            }},

            # Stage 3: Lookup company data
            {"$lookup": {
                "from": "companies",
                "let": {"companyId": {"$toObjectId": "$company_id"}},
                "pipeline": [
                    {"$match": {
                        "$expr": {"$and": [
                            {"$ne": ["$$companyId", None]},
                            {"$eq": ["$_id", "$$companyId"]}
                        ]},
                        "organization_id": organization_id
                    }},
                    {"$project": {"name": 1, "domain": 1, "phone": 1}}
                ],
                "as": "company_data"
            }},

            # Stage 4: Add computed fields
            {"$addFields": {
                "lead": {"$arrayElemAt": ["$lead_data", 0]},
                "company": {"$arrayElemAt": ["$company_data", 0]}
            }},

            # Stage 5: Sort and limit
            {"$sort": {"due_date": 1, "_id": 1}},
            {"$limit": 50},

            # Stage 6: Clean up
            {"$unset": ["lead_data", "company_data"]}
        ]

        # Get execution stats (explain with executionStats)
        result = await db.task_queue.aggregate(pipeline, explain=True)
        logger.info(f"\nTask aggregation pipeline created and ready for performance analysis")
        logger.info(f"Pipeline stages: {len(pipeline)}")

        # Test a simpler query performance
        simple_query = {"organization_id": organization_id, "task_status": "pending"}
        count_result = await db.task_queue.count_documents(simple_query)
        logger.info(f"Found {count_result} pending tasks for organization")

    except Exception as e:
        logger.error(f"Error analyzing task performance: {e}")
    finally:
        client.close()


if __name__ == "__main__":
    # Run migrations
    asyncio.run(add_task_join_indexes())

    # Analyze performance
    asyncio.run(analyze_task_join_performance())