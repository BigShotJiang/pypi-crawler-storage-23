#!/usr/bin/env python3
"""
Backfill research_values and research_row_id for task_queue documents.

This script can be run against a MongoDB database to populate the new snapshot
fields introduced for faster task list rendering.
"""

import asyncio
import logging
import os
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorClient

# Ensure apps/ modules are importable when running as a script
REPO_ROOT = Path(__file__).resolve().parents[2]
if str(REPO_ROOT) not in sys.path:
    sys.path.append(str(REPO_ROOT))

from apps.api.services.research_table.snapshots.research_snapshot_service import (  # noqa: E402
    ResearchSnapshot,
    build_research_snapshots,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("backfill_task_research_values")


def _coerce_object_id(value: Any) -> Optional[ObjectId]:
    if value is None:
        return None
    if isinstance(value, ObjectId):
        return value
    try:
        return ObjectId(str(value))
    except Exception:
        return None


async def _load_lead(
    db,
    lead_id: Any,
    organization_id: Any,
) -> Optional[Dict[str, Any]]:
    lead_oid = _coerce_object_id(lead_id)
    if not lead_oid:
        return None

    lead = await db.leads.find_one(
        {"_id": lead_oid, "organization_id": organization_id},
        {"company_id": 1},
    )
    if not lead:
        return None

    lead["_id"] = lead_oid
    return lead


async def backfill_batch(db, tasks: List[Dict[str, Any]]) -> int:
    updated = 0

    for task in tasks:
        research_context = task.get("research_context") or {}
        if not research_context:
            continue

        # Skip tasks that already have research_values populated
        if task.get("research_values"):
            continue

        lead = await _load_lead(db, task.get("lead_id"), task.get("organization_id"))
        if not lead:
            continue

        snapshots, field_meta = await build_research_snapshots(db, [lead], research_context)
        snapshot: ResearchSnapshot = snapshots.get(str(lead["_id"]))  # type: ignore[index]
        if not snapshot:
            continue

        set_updates: Dict[str, Any] = {
            "research_values": snapshot.values,
            "research_row_id": snapshot.row_id,
        }
        unset_updates: Dict[str, Any] = {}

        if field_meta:
            selected_field_ids = research_context.get("user_selected_field_ids") or []
            selected_fields_payload = []
            for field_id in selected_field_ids:
                meta = field_meta.get(field_id, {})
                if not meta:
                    continue
                selected_fields_payload.append(
                    {
                        "id": field_id,
                        "name": meta.get("label") or meta.get("name") or meta.get("key") or field_id,
                        "type": meta.get("data_type") or meta.get("dataType") or meta.get("type") or "string",
                    }
                )
            if selected_fields_payload:
                set_updates["research_context.selected_fields"] = selected_fields_payload
            unset_updates["research_context.all_fields"] = ""

        update_body: Dict[str, Any] = {"$set": set_updates}
        if unset_updates:
            update_body["$unset"] = unset_updates

        result = await db.task_queue.update_one({"_id": task["_id"]}, update_body)
        if result.modified_count:
            updated += 1

    return updated


async def main() -> None:
    mongodb_uri = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
    mongodb_db_name = os.getenv("MONGODB_DB_NAME", "autotouch")

    client = AsyncIOMotorClient(mongodb_uri)
    db = client[mongodb_db_name]

    batch_size = int(os.getenv("BATCH_SIZE", "100"))
    total_updated = 0
    cursor = db.task_queue.find(
        {"research_context": {"$exists": True, "$ne": None}},
        {"research_context": 1, "lead_id": 1, "organization_id": 1},
    )

    try:
        while True:
            batch = await cursor.to_list(length=batch_size)
            if not batch:
                break
            updated = await backfill_batch(db, batch)
            total_updated += updated
            logger.info("Processed %d tasks (updated %d)", len(batch), updated)

    finally:
        client.close()

    logger.info("Backfill complete. Updated %d tasks.", total_updated)


if __name__ == "__main__":
    asyncio.run(main())
