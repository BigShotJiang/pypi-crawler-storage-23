"""
Normalize legacy user permissions to the simplified role model.

Usage:
    python3 scripts/migrations/20260113_set_user_permissions_user_admin.py --uri "<mongodb uri>" --db autotouch --apply

Defaults to dry-run; pass --apply to write changes.
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
from typing import Iterable, List

from pymongo import MongoClient


def _normalize_permissions(raw_permissions) -> List[str]:
    if raw_permissions is None:
        return []
    if isinstance(raw_permissions, str):
        return [raw_permissions]
    if isinstance(raw_permissions, Iterable):
        return [perm for perm in raw_permissions if isinstance(perm, str)]
    return []


def migrate_permissions(db, apply: bool) -> dict:
    stats = {
        "scanned": 0,
        "updated_user_admin": 0,
        "updated_internal_admin": 0,
        "skipped": 0,
    }

    cursor = db.users.find({}, {"permissions": 1})
    for user in cursor:
        stats["scanned"] += 1
        permissions = _normalize_permissions(user.get("permissions"))

        if "internal_admin" in permissions:
            target = ["internal_admin"]
            label = "updated_internal_admin"
        else:
            target = ["user_admin"]
            label = "updated_user_admin"

        if permissions == target:
            stats["skipped"] += 1
            continue

        if apply:
            db.users.update_one(
                {"_id": user["_id"]},
                {
                    "$set": {
                        "permissions": target,
                        "updated_at": datetime.now(timezone.utc),
                    }
                },
            )

        stats[label] += 1

    return stats


def main(uri: str, db_name: str, apply: bool, allow_invalid_certificates: bool) -> None:
    client = MongoClient(uri, tlsAllowInvalidCertificates=allow_invalid_certificates)
    db = client[db_name]

    stats = migrate_permissions(db, apply)

    print(
        f"[users] scanned={stats['scanned']} "
        f"updated_user_admin={stats['updated_user_admin']} "
        f"updated_internal_admin={stats['updated_internal_admin']} "
        f"skipped={stats['skipped']}"
    )
    if not apply:
        print("Dry run only. Re-run with --apply to persist changes.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Normalize user permissions to user_admin/internal_admin.")
    parser.add_argument("--uri", required=True, help="MongoDB connection string")
    parser.add_argument("--db", default="autotouch", help="Database name (default: autotouch)")
    parser.add_argument(
        "--allow-invalid-certificates",
        action="store_true",
        help="Allow invalid TLS certificates (use only if your environment lacks CA bundles).",
    )
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Apply changes (otherwise dry-run)",
    )
    args = parser.parse_args()
    main(args.uri, args.db, args.apply, args.allow_invalid_certificates)
