#!/usr/bin/env python3
"""
Migration to add user_id and organization_id fields to existing tables.

This migration:
1. Adds user_id and organization_id fields to all tables
2. Sets default values for existing tables
3. Safe to run multiple times (idempotent)
"""

import os
import sys
from datetime import datetime
from pymongo import MongoClient
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')
logger = logging.getLogger(__name__)

def run_migration():
    # Connect to MongoDB
    mongo_uri = os.getenv('MONGODB_URI', 'mongodb://localhost:27017')
    db_name = os.getenv('MONGODB_DB_NAME', 'smart_table')
    
    logger.info(f"Connecting to MongoDB at {mongo_uri}")
    client = MongoClient(mongo_uri)
    db = client[db_name]
    
    # Get tables collection
    tables_collection = db['tables']
    
    # Find tables without user_id or organization_id
    query = {
        '$or': [
            {'user_id': {'$exists': False}},
            {'organization_id': {'$exists': False}}
        ]
    }
    
    tables_to_update = list(tables_collection.find(query))
    logger.info(f"Found {len(tables_to_update)} tables to update")
    
    # Update each table
    updated_count = 0
    for table in tables_to_update:
        update_fields = {}
        
        # Add user_id if missing
        if 'user_id' not in table:
            # Default to a system user or null
            update_fields['user_id'] = None
            
        # Add organization_id if missing  
        if 'organization_id' not in table:
            update_fields['organization_id'] = None
            
        if update_fields:
            result = tables_collection.update_one(
                {'_id': table['_id']},
                {'$set': update_fields}
            )
            if result.modified_count > 0:
                updated_count += 1
                logger.info(f"Updated table {table.get('name', 'Unknown')} (ID: {table['_id']})")
    
    logger.info(f"Migration complete. Updated {updated_count} tables")
    
    # Add indexes for better query performance
    logger.info("Creating indexes...")
    tables_collection.create_index('user_id')
    tables_collection.create_index('organization_id')
    tables_collection.create_index([('user_id', 1), ('organization_id', 1)])
    logger.info("Indexes created successfully")
    
    client.close()

if __name__ == '__main__':
    try:
        run_migration()
        logger.info("Migration completed successfully!")
    except Exception as e:
        logger.error(f"Migration failed: {e}")
        sys.exit(1)