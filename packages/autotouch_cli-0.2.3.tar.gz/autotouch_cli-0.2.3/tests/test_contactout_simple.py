#!/usr/bin/env python3
"""
Simple ContactOut API Test - Focus on Phone Numbers and Emails
Quick test script to verify ContactOut API functionality
"""

import os
import sys
import requests
import json
from urllib.parse import quote
from dotenv import load_dotenv

# Load environment variables
load_dotenv('/Users/nicnicolo/Projects/smart_table/.env')

class ContactOutTester:
    def __init__(self):
        self.api_token = os.getenv('CONTACTOUT_API_KEY')
        if not self.api_token:
            print("❌ Error: CONTACTOUT_API_KEY not found in environment variables")
            sys.exit(1)

        self.base_url = "https://api.contactout.com/v1"
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "token": self.api_token
        }
        print(f"✅ API token loaded: {self.api_token[:8]}...")

    def test_linkedin_enrichment(self, profile_url):
        """Test LinkedIn profile enrichment"""
        print(f"\n🔍 Testing LinkedIn Profile: {profile_url}")
        print("-" * 60)

        endpoint = f"{self.base_url}/linkedin/enrich"
        params = {"profile": profile_url}

        try:
            response = requests.get(endpoint, headers=self.headers, params=params)
            print(f"Status Code: {response.status_code}")

            if response.status_code == 200:
                data = response.json()
                profile = data.get('profile', {})

                # Extract key information
                print(f"Full Name: {profile.get('full_name', 'Not found')}")
                print(f"Headline: {profile.get('headline', 'Not found')}")
                print(f"Company: {profile.get('company', {}).get('name', 'Not found')}")

                # Phone numbers
                phones = profile.get('phone', [])
                if phones:
                    print(f"📞 Phone Numbers Found: {len(phones)}")
                    for phone in phones:
                        print(f"  - {phone}")
                else:
                    print("📞 Phone Numbers: None found")

                # Email addresses
                emails = profile.get('email', [])
                work_emails = profile.get('work_email', [])
                personal_emails = profile.get('personal_email', [])

                if emails:
                    print(f"📧 Total Emails Found: {len(emails)}")
                    for email in emails:
                        print(f"  - {email}")

                if work_emails:
                    print(f"💼 Work Emails: {len(work_emails)}")
                    for email in work_emails:
                        print(f"  - {email}")

                if personal_emails:
                    print(f"👤 Personal Emails: {len(personal_emails)}")
                    for email in personal_emails:
                        print(f"  - {email}")

                if not emails and not work_emails and not personal_emails:
                    print("📧 Emails: None found")

                return True

            else:
                print(f"❌ Request failed: {response.text}")
                return False

        except Exception as e:
            print(f"❌ Exception: {str(e)}")
            return False

    def test_email_enrichment(self, email):
        """Test email enrichment"""
        print(f"\n📧 Testing Email: {email}")
        print("-" * 60)

        endpoint = f"{self.base_url}/email/enrich"
        params = {"email": email, "include": "work_email"}

        try:
            response = requests.get(endpoint, headers=self.headers, params=params)
            print(f"Status Code: {response.status_code}")

            if response.status_code == 200:
                data = response.json()
                profile = data.get('profile', {})

                if not profile:
                    print("🔍 No profile found for this email")
                    return False

                # Extract key information
                print(f"Full Name: {profile.get('fullName', 'Not found')}")
                print(f"Headline: {profile.get('headline', 'Not found')}")
                print(f"LinkedIn URL: {profile.get('linkedinUrl', 'Not found')}")

                # Phone number
                phone = profile.get('phone')
                if phone:
                    print(f"📞 Phone: {phone}")
                else:
                    print("📞 Phone: Not found")

                # Work email
                work_email = profile.get('workEmail')
                if work_email:
                    print(f"💼 Work Email: {work_email}")
                    print(f"💼 Work Email Status: {profile.get('workEmailStatus', 'Unknown')}")
                else:
                    print("💼 Work Email: Not found")

                return True

            elif response.status_code == 404:
                print("🔍 No profile found for this email")
                return False
            else:
                print(f"❌ Request failed: {response.text}")
                return False

        except Exception as e:
            print(f"❌ Exception: {str(e)}")
            return False

    def test_contact_info_only(self, profile_url):
        """Test contact info API (emails and phones only)"""
        print(f"\n📞 Testing Contact Info Only: {profile_url}")
        print("-" * 60)

        endpoint = f"{self.base_url}/people/linkedin"
        params = {
            "profile": profile_url,
            "include_phone": True
        }

        try:
            response = requests.get(endpoint, headers=self.headers, params=params)
            print(f"Status Code: {response.status_code}")

            if response.status_code == 200:
                data = response.json()
                profile = data.get('profile', {})

                if not profile:
                    print("🔍 No contact info found")
                    return False

                # Phone numbers
                phones = profile.get('phone', [])
                if phones:
                    print(f"📞 Phone Numbers: {len(phones)}")
                    for phone in phones:
                        print(f"  - {phone}")
                else:
                    print("📞 Phone Numbers: None found")

                # Email addresses
                emails = profile.get('email', [])
                work_emails = profile.get('work_email', [])
                personal_emails = profile.get('personal_email', [])

                if emails:
                    print(f"📧 All Emails: {len(emails)}")
                    for email in emails:
                        print(f"  - {email}")

                if work_emails:
                    print(f"💼 Work Emails: {len(work_emails)}")
                    for email in work_emails:
                        print(f"  - {email}")

                if personal_emails:
                    print(f"👤 Personal Emails: {len(personal_emails)}")
                    for email in personal_emails:
                        print(f"  - {email}")

                return True

            elif response.status_code == 404:
                print("🔍 No contact info found")
                return False
            else:
                print(f"❌ Request failed: {response.text}")
                return False

        except Exception as e:
            print(f"❌ Exception: {str(e)}")
            return False

    def run_tests(self):
        """Run all tests with sample data"""
        print("🚀 ContactOut API Simple Test")
        print("="*60)

        # Test LinkedIn profiles
        linkedin_profiles = [
            "https://www.linkedin.com/in/williamhgates",  # Bill Gates
            "https://www.linkedin.com/in/reidhoffman",     # Reid Hoffman
            "https://www.linkedin.com/in/example-person"   # Example profile
        ]

        # Test emails
        test_emails = [
            "0getfisher@gmail.com",  # Example from docs
            "test@example.com",      # Generic test
        ]

        results = {
            'linkedin_tests': 0,
            'linkedin_success': 0,
            'email_tests': 0,
            'email_success': 0,
            'contact_tests': 0,
            'contact_success': 0
        }

        # Test LinkedIn enrichment
        for profile in linkedin_profiles:
            results['linkedin_tests'] += 1
            if self.test_linkedin_enrichment(profile):
                results['linkedin_success'] += 1

        # Test email enrichment
        for email in test_emails:
            results['email_tests'] += 1
            if self.test_email_enrichment(email):
                results['email_success'] += 1

        # Test contact info only
        for profile in linkedin_profiles[:2]:  # Test fewer for contact-only
            results['contact_tests'] += 1
            if self.test_contact_info_only(profile):
                results['contact_success'] += 1

        # Print summary
        print("\n" + "="*60)
        print("📊 TEST SUMMARY")
        print("="*60)
        print(f"LinkedIn Enrichment: {results['linkedin_success']}/{results['linkedin_tests']} successful")
        print(f"Email Enrichment: {results['email_success']}/{results['email_tests']} successful")
        print(f"Contact Info Only: {results['contact_success']}/{results['contact_tests']} successful")

        total_tests = results['linkedin_tests'] + results['email_tests'] + results['contact_tests']
        total_success = results['linkedin_success'] + results['email_success'] + results['contact_success']

        print(f"\nOverall Success Rate: {total_success}/{total_tests} ({(total_success/total_tests)*100:.1f}%)")

        if total_success > 0:
            print("\n✅ ContactOut API is working! You can find phone numbers and emails.")
        else:
            print("\n❌ No successful API calls. Check your API key and network connection.")


def main():
    """Run the simple test"""
    tester = ContactOutTester()
    tester.run_tests()


if __name__ == "__main__":
    main()