# CKD Staging — KDIGO 2024

## GFR Categories

| Stage | GFR (mL/min/1.73m²) | Description |
|-------|---------------------|-------------|
| G1 | ≥ 90 | Normal or high |
| G2 | 60–89 | Mildly decreased |
| G3a | 45–59 | Mildly to moderately decreased |
| G3b | 30–44 | Moderately to severely decreased |
| G4 | 15–29 | Severely decreased |
| G5 | < 15 | Kidney failure |

## Monitoring Frequency

Based on GFR category and albuminuria level:
- **G1-G2, A1:** Annual monitoring of eGFR and ACR.
- **G3a, A1 or G1-G2, A2:** Monitor every 6–12 months.
- **G3b or A2-A3:** Monitor every 3–6 months.
- **G4-G5:** Monitor every 1–3 months.

## Pharmacological Management by Stage & Actionable Dosing

### 1. RAS Inhibitors (ACEi or ARB)
- **Indication:** First-line for ALL CKD stages (G1-G5) with albuminuria (ACR ≥ 30 mg/g) and/or hypertension.
- **Dosing Strategy:** Initiate at standard starting dose (e.g., Losartan 50 mg daily or Lisinopril 10 mg daily) and titrate up to the **maximum approved, tolerated dose** (e.g., Losartan 100 mg daily or Lisinopril 40 mg daily) to achieve maximum renal benefit (Grade 1B).
- **Caveats:** Check eGFR and potassium 2-4 weeks after initiation/titration. Continue therapy unless potassium is unmanageable or eGFR declines >30% within 4 weeks.

### 2. SGLT2 Inhibitors
- **Indication:** Recommended for adults with CKD (G1-G4) regardless of diabetes status (Grade 1A/1B).
- **Dosing Strategy:** Initiate at standard dose without need for titration (e.g., Dapagliflozin 10 mg daily or Empagliflozin 10 mg daily). 
- **Initiation Threshold:** Start if eGFR ≥ 20 mL/min/1.73m².
- **Continuation:** Once initiated, continue even if eGFR falls below 20, until dialysis is required or intolerance occurs.
- **Caveat:** Expect an initial transient dip in eGFR. Do not stop SGLT2i for this dip unless it exceeds 25-30% from baseline.

### 3. Non-Steroidal MRA (Finerenone)
- **Indication:** Add to maximum tolerated RAS inhibitor in patients with **Type 2 Diabetes** and CKD (G3-G4 with ACR ≥ 30, or G1-G2 with ACR ≥ 300) (Grade 1B).
- **Dosing Strategy (requires Baseline K+ ≤ 4.8):**
  - eGFR ≥ 60: Start Finerenone 20 mg daily.
  - eGFR 25-59: Start Finerenone 10 mg daily.
- **Titration:** Check potassium at 1 month. If K+ ≤ 4.8, increase 10 mg dose to 20 mg. If K+ > 5.5, hold drug until ≤ 5.0, then restart at 10 mg.

### 4. Advanced CKD (G4-G5)
- Prepare for renal replacement therapy (dialysis or transplantation). 
- Refer to nephrology early if not already followed.

## Blood Pressure Targets

- Target systolic BP **< 120 mmHg** (measured by standardized office measurement) in adults with CKD (Grade 2B).
- Avoid hypotension (< 110 mmHg systolic) in advanced CKD to preserve remaining renal perfusion.
