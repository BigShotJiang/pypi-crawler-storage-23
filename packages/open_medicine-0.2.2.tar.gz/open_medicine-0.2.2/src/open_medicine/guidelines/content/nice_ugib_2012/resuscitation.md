# Resuscitation and Initial Management of Upper GI Bleeding — NICE CG141 (2012)

## Massive Bleeding Protocol

For patients with massive upper GI bleeding, transfuse with blood, platelets, and clotting factors in line with local protocols for managing massive bleeding (NICE CG141, Recommendation 1.2.1).

### Transfusion Principles

- Base decisions on blood transfusion on the **full clinical picture** — over-transfusion may be as damaging as under-transfusion (Recommendation 1.2.2).
- **Do NOT offer platelet transfusion** to patients who are not actively bleeding and are haemodynamically stable (Recommendation 1.2.3).

### Specific Transfusion Thresholds

| Component | Threshold for Transfusion | Details |
|---|---|---|
| **Platelets** | Actively bleeding AND platelets < 50 × 10⁹/L | Offer platelet transfusion (Recommendation 1.2.4) |
| **Fresh Frozen Plasma (FFP)** | Actively bleeding AND PT/INR or aPTT > 1.5× normal | Offer FFP |
| **Cryoprecipitate** | Fibrinogen < 1.5 g/L despite FFP | Add cryoprecipitate |

## Anticoagulant Reversal

### Warfarin
- **Actively bleeding on warfarin:** Offer **prothrombin complex concentrate (PCC)** (Recommendation 1.2.5).
- **Bleeding stopped on warfarin:** Treat in line with local warfarin management protocols (Recommendation 1.2.6).

### Direct Oral Anticoagulants (DOACs)
- For reversing DOACs, follow MHRA safety advice:
  - **Apixaban or rivaroxaban:** Andexanet alfa is recommended for life-threatening or uncontrolled GI bleeding (NICE TA697, 2025).
  - **Dabigatran:** Idarucizumab 5 g IV for life-threatening bleeding.

### Recombinant Factor VIIa
- **Do NOT use** recombinant factor VIIa except when all other methods have failed (Recommendation 1.2.7).

## Variceal Bleeding — Specific Initial Management

### Terlipressin (Recommendation 1.5.1)
- **Action:** Offer terlipressin to patients with **suspected variceal bleeding at presentation**.
- **Dose:** 2 mg IV every 4 hours (body weight ≥ 70 kg) or 1 mg IV every 4 hours (body weight < 70 kg).
- **Duration:** Continue until definitive haemostasis is achieved, or for up to 5 days.
- **Monitor for:** Hyponatremia, cardiac ischemia, peripheral ischemia.

### Prophylactic Antibiotics (Recommendation 1.5.2)
- **Action:** Offer prophylactic antibiotic therapy at presentation to all patients with suspected or confirmed variceal bleeding.
- **Recommended agent:** Ceftriaxone 1 g IV once daily for up to 7 days (reduces bacterial infections, re-bleeding, and mortality).
- **Alternative (if cephalosporin allergy):** Norfloxacin 400 mg PO BID for 7 days.

## Resuscitation Algorithm

```
Patient presents with acute upper GI bleeding
  → ABCs: Secure airway (intubate if GCS < 8 or massive hematemesis),
    establish 2 large-bore IV access (≥ 16G), initiate crystalloid resuscitation
      → Haemodynamically unstable (SBP < 90 or HR > 120)?
          → YES → Activate massive transfusion protocol
                   → Transfuse RBCs, FFP, platelets per protocol
                   → On warfarin? → PCC
                   → On DOAC? → Specific reversal agent
                   → Suspected variceal? → Terlipressin + prophylactic antibiotics
                   → Endoscopy immediately after resuscitation
          → NO → GBS assessment → further management per risk score
                → Endoscopy within 24 hours
```

## NSAIDs, Aspirin, and Antiplatelet Considerations

### Aspirin (Secondary Prevention)
- **Continue low-dose aspirin** for secondary prevention of vascular events in patients with UGIB in whom haemostasis has been achieved (Recommendation 1.6.1).

### NSAIDs
- **Stop all other NSAIDs** (including COX-2 inhibitors) during the acute phase (Recommendation 1.6.2).

### Clopidogrel/Thienopyridines
- **Discuss risks and benefits** of continuing clopidogrel with the appropriate specialist (cardiologist or stroke specialist) and the patient (Recommendation 1.6.3).
- Do NOT unilaterally discontinue antiplatelet therapy without specialist input.
