# Anticoagulation in Atrial Fibrillation — ACC/AHA 2023

## Stroke Risk Assessment (CHA2DS2-VASc)

The CHA2DS2-VASc score is the recommended tool for assessing thromboembolic risk in patients with AF.

### Recommendations for Oral Anticoagulation (OAC)

**Men:**
- CHA2DS2-VASc = 0: No antithrombotic therapy is recommended (Class III: No Benefit).
- CHA2DS2-VASc = 1: OAC may be considered to reduce thromboembolic stroke risk (Class IIb).
- CHA2DS2-VASc ≥ 2: OAC is recommended to reduce thromboembolic stroke risk (Class I).

**Women:**
- CHA2DS2-VASc = 1 (with sex being the only factor): No antithrombotic therapy is recommended (Class III: No Benefit).
- CHA2DS2-VASc = 2: OAC may be considered (Class IIb).
- CHA2DS2-VASc ≥ 3: OAC is recommended (Class I).

### Choice of Anticoagulant

- Direct oral anticoagulants (DOACs: apixaban, dabigatran, edoxaban, rivaroxaban) are recommended over warfarin in DOAC-eligible patients with AF (Class I).
- Warfarin is recommended only when DOACs are contraindicated (e.g., moderate-to-severe mitral stenosis, mechanical heart valves).
- When warfarin is used, target INR is 2.0–3.0 with time in therapeutic range (TTR) ≥ 70%.

#### DOAC Dosing and Adjustments
Standard dosing and criteria for dose reduction in non-valvular AF:

- **Apixaban:** Standard dose is 5 mg BID. 
  - *Dose Reduction:* Reduce to 2.5 mg BID if the patient has **at least two** of the following characteristics: Age ≥ 80 years, Body weight ≤ 60 kg, or Serum creatinine ≥ 1.5 mg/dL.
- **Rivaroxaban:** Standard dose is 20 mg once daily with the evening meal. 
  - *Dose Reduction:* Reduce to 15 mg once daily if CrCl ≤ 50 mL/min.
- **Edoxaban:** Standard dose is 60 mg once daily. 
  - *Dose Reduction:* Reduce to 30 mg once daily if CrCl 15–50 mL/min. (Note: Edoxaban is not recommended if CrCl > 95 mL/min).
- **Dabigatran:** Standard dose is 150 mg BID. 
  - *Dose Reduction:* Reduce to 75 mg BID if CrCl 15–30 mL/min.

## Bleeding Risk Assessment

The 2023 guideline recommends that bleeding risk scores (including HAS-BLED, HEMORR2HAGES, and ATRIA) should NOT be used in isolation to determine eligibility for oral anticoagulation. These scores poorly differentiate between patients who will or will not experience bleeding events, and they share many risk factors with stroke risk scores.

Instead, bleeding risk assessment should be used to:
1. Identify and correct **modifiable bleeding risk factors** (uncontrolled hypertension, labile INR, concomitant antiplatelet/NSAID use, excess alcohol).
2. Inform **shared medical decision-making** between clinician and patient.
3. Guide **selection of anticoagulant and monitoring frequency**.

### Key Principle
A high bleeding risk does NOT contraindicate anticoagulation. The net clinical benefit of OAC generally favors treatment even in patients at elevated bleeding risk. DOACs are preferred over warfarin due to lower intracranial hemorrhage risk.

## Special Populations

- **Elderly (≥ 75 years):** Age alone is not a reason to withhold OAC. DOACs preferred over warfarin.
- **CKD (CrCl 15-30 mL/min):** Reduced-dose DOACs may be used. Below CrCl 15 mL/min, consult nephrology.
- **Post-PCI/ACS:** Duration of triple therapy (OAC + dual antiplatelet) should be minimized. Early transition to OAC + single antiplatelet is preferred.
