# Antithrombotic Therapy in Acute Coronary Syndromes — ESC 2023

## Antiplatelet Therapy

### Aspirin (Class I, Level of Evidence A)
- **Loading dose:** 150–300 mg orally; OR 75–250 mg intravenously if oral intake is not possible.
- **Maintenance dose:** 75–100 mg once daily, continued indefinitely.
- No dose adjustment required for chronic kidney disease (CKD).

### P2Y12 Inhibitors — Default Dual Antiplatelet Therapy (DAPT)

DAPT with aspirin plus a potent P2Y12 inhibitor (prasugrel or ticagrelor) is recommended for 12 months, unless excessive bleeding risk (Class I, Level of Evidence A).

#### Ticagrelor (Class I, Level of Evidence B)
- **Loading dose:** 180 mg orally.
- **Maintenance dose:** 90 mg twice daily.
- **Extended therapy (> 12 months):** 60 mg twice daily may be considered in patients at high ischemic risk without increased bleeding risk.
- Recommended irrespective of initial management strategy (invasive or conservative).
- **Contraindications:** Active pathological bleeding, history of intracranial hemorrhage, severe hepatic impairment.
- **Key side effects:** Dyspnea (usually transient, does not require discontinuation), ventricular pauses > 3 seconds (first week).

#### Prasugrel (Class I, Level of Evidence B)
- **Loading dose:** 60 mg orally.
- **Maintenance dose:** 10 mg once daily.
- **Dose reduction:** 5 mg once daily if body weight < 60 kg OR age ≥ 75 years.
- Should be used **only in patients proceeding to PCI** (coronary anatomy must be known).
- May be considered in preference to ticagrelor for ACS patients undergoing PCI (Class IIa).
- **Contraindication:** Prior stroke or TIA (absolute contraindication).
- **Caution:** Age ≥ 75 years (generally not recommended unless high ischemic risk).

#### Clopidogrel (Class I, Level of Evidence A — when others unavailable)
- **Loading dose:** 300–600 mg orally.
- **Maintenance dose:** 75 mg once daily.
- **When to use:**
  - Prasugrel or ticagrelor are unavailable, not tolerated, or contraindicated
  - Elderly patients (≥ 70 years) at high bleeding risk
  - Patients on oral anticoagulation (triple therapy → dual pathway)

### Pre-Treatment with P2Y12 Inhibitors in NSTE-ACS

- **Routine pre-treatment is NOT recommended** when early invasive strategy (< 24 hours) is planned (Class III, Level of Evidence A) — increased bleeding without clear ischemic benefit.
- **If delay to angiography is anticipated (> 24 hours):** Pre-treatment may be considered, weighing ischemic benefit against bleeding risk (Class IIb).

### DAPT Duration and De-Escalation

- **Default:** 12 months of DAPT after ACS event (Class I).
- **Extended (> 12 months):** Consider ticagrelor 60 mg BID if high ischemic risk and tolerated DAPT without bleeding (Class IIb).
- **Shortened DAPT (3–6 months):** May be considered in event-free patients NOT at high ischemic risk, followed by single antiplatelet therapy (preferably P2Y12 inhibitor monotherapy) (Class IIa).
- **Shortened DAPT (1 month):** May be considered in high bleeding risk patients (Class IIb).
- **De-escalation:** Switching from ticagrelor/prasugrel to clopidogrel may be considered to reduce bleeding risk (Class IIb). **Do NOT de-escalate within the first 30 days.**

---

## Parenteral Anticoagulation

Parenteral anticoagulation is recommended for all ACS patients at diagnosis (Class I, Level of Evidence A).

### Unfractionated Heparin (UFH)
- **During PCI:** 70–100 IU/kg IV bolus (weight-adjusted). If concomitant GP IIb/IIIa inhibitor: 50–70 IU/kg bolus.
- **Medical management (no PCI):** 60 IU/kg IV bolus (max 4,000 IU), then 12 IU/kg/h infusion (max 1,000 IU/h). Target aPTT 50–70 seconds.
- Standard parenteral anticoagulation for NSTE-ACS patients undergoing invasive angiography.

### Enoxaparin (Class IIa, Level of Evidence B)
- Should be considered as an alternative to UFH when **early invasive angiography (< 24 hours)** is anticipated.
- **Dose:** 1 mg/kg subcutaneously every 12 hours (reduce to 1 mg/kg once daily if CrCl < 30 mL/min).
- **At PCI:** If last SC dose was > 8 hours ago, give 0.3 mg/kg IV bolus at the time of PCI.
- **Do NOT switch between UFH and enoxaparin** (increases bleeding).

### Fondaparinux (Class I, Level of Evidence B)
- **Recommended in preference to enoxaparin** when early invasive angiography (< 24 hours) is **NOT** planned.
- **Dose:** 2.5 mg subcutaneously once daily.
- **At PCI:** If patient on fondaparinux proceeds to PCI, add a single bolus of UFH (85 IU/kg, or 60 IU/kg with GP IIb/IIIa inhibitor) to prevent catheter thrombosis.
- **Contraindication:** CrCl < 20 mL/min.

---

## Special Populations

### Patients on Oral Anticoagulation (OAC)

After ACS in patients requiring ongoing OAC (e.g., atrial fibrillation with CHA₂DS₂-VASc ≥ 1 in men, ≥ 2 in women):

- **Default regimen:** Dual antithrombotic therapy — NOAC (at stroke-prevention dose) + single antiplatelet agent (preferably clopidogrel 75 mg daily) for up to 12 months (Class I).
- **Triple therapy (OAC + aspirin + clopidogrel):** Should be as brief as possible (≤ 1 week peri-PCI) (Class IIa).
- After 12 months: OAC monotherapy.
- **Avoid prasugrel or ticagrelor with OAC** — increased bleeding without proven benefit in this population.

### Elderly (≥ 75 years)
- Prasugrel maintenance dose 5 mg daily (if used).
- Consider clopidogrel over ticagrelor/prasugrel if high bleeding risk.
- Renal-adjusted enoxaparin dosing mandatory.

### Renal Impairment (CrCl < 30 mL/min)
- **UFH preferred** (no renal accumulation).
- Enoxaparin: 1 mg/kg once daily (not BID).
- Fondaparinux: contraindicated if CrCl < 20 mL/min.
- No dose adjustment needed for aspirin, ticagrelor, or clopidogrel.
- Prasugrel: no specific renal adjustment, but use with caution.
