# Mechanical Thrombectomy for Acute Ischemic Stroke — AHA/ASA 2019

## Indications for Endovascular Thrombectomy

Mechanical thrombectomy (using stent retrievers or aspiration devices) is the standard of care for acute ischemic stroke caused by Large Vessel Occlusion (LVO) of the anterior circulation.

### Standard Time Window: 0–6 Hours (Class I, Level of Evidence A)
Thrombectomy is recommended for patients who meet ALL of the following criteria:
- Pre-stroke modified Rankin Scale (mRS) 0–1 (functionally independent)
- Causative occlusion of the **Internal Carotid Artery (ICA)** or **Middle Cerebral Artery M1 segment**
- Age ≥ 18 years
- NIHSS ≥ 6
- ASPECTS ≥ 6 (Alberta Stroke Program Early CT Score — indicating limited early ischemic changes on non-contrast CT)
- Treatment can be initiated (groin puncture) within **6 hours** of symptom onset

### Extended Time Window: 6–24 Hours (Class I, Level of Evidence A)
Based on the landmark DAWN and DEFUSE-3 trials, thrombectomy is recommended for selected patients within 6–24 hours who meet specific perfusion imaging criteria:

#### DAWN Trial Criteria (6–24 hours)
Patients with LVO (ICA or M1) AND a mismatch between clinical severity and infarct volume on CT perfusion or DWI-MRI:
- **Group A (Age ≥ 80):** NIHSS ≥ 10 AND infarct core < 21 mL
- **Group B (Age < 80):** NIHSS ≥ 10 AND infarct core < 31 mL
- **Group C (Age < 80):** NIHSS ≥ 20 AND infarct core 31–51 mL

#### DEFUSE-3 Trial Criteria (6–16 hours)
Patients with LVO (ICA or M1) AND:
- Infarct core < 70 mL
- Mismatch ratio ≥ 1.8
- Mismatch volume ≥ 15 mL

## Relationship to IV Alteplase

- **IV alteplase should NOT be withheld or delayed** while awaiting thrombectomy evaluation (Class I). Administer alteplase if eligible, then proceed with thrombectomy.
- Thrombectomy can be performed with or without prior IV thrombolysis.

## Post-Thrombectomy Care
- Confirm reperfusion with final angiographic imaging (TICI grade 2b–3 = successful reperfusion).
- Maintain BP **< 180/105 mmHg** for 24 hours post-procedure (same as post-alteplase protocol).
- Monitor in a neurocritical care or stroke unit setting.
- Follow-up imaging (MRI or CT) at 24 hours to assess for hemorrhagic transformation before starting antithrombotic therapy.
