from posthoganalytics.ai.prompts import Prompts

__all__ = ["Prompts"]
