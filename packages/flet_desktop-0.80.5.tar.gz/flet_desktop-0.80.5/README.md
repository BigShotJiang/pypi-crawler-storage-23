# Flet Desktop client in Flutter

This package contains a compiled Flutter Flet desktop client.