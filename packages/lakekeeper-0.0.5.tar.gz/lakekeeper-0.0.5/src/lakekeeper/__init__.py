"""Lakekeeper - Safe compaction of Hive external tables on on-premises Kerberized Hadoop clusters."""

__version__ = "0.0.5"
