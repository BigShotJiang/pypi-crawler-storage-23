"""Core modules for Beekeeper compaction workflow."""
