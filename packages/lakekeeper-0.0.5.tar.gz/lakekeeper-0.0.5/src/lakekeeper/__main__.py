"""Allow running lakekeeper as a module: python -m lakekeeper."""

from lakekeeper.cli import main

main()
