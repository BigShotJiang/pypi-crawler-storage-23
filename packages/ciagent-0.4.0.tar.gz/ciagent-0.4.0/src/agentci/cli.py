"""
Agent CI Command Line Interface.

Commands:
  agentci init          Scaffold a new test suite
  agentci run           Execute test suite
  agentci run --runs N  Statistical mode (run N times)
  agentci record        Run agent live, save golden trace
  agentci diff          Compare latest run against golden
  agentci report        Generate HTML report from last run
"""

import os
import sys
import shutil
import click
from rich.console import Console
from rich.table import Table
from rich.prompt import Confirm

from .config import load_config
from .runner import TestRunner
from .models import TestResult

console = Console()

def _print_error_panel(e):
    from rich.panel import Panel
    from rich.text import Text
    raw_msg = str(e)
    fix_idx = raw_msg.find("\n  Fix: ")
    if fix_idx != -1:
        raw_msg = raw_msg[:fix_idx]
    text = Text(raw_msg)
    if getattr(e, "fix", None):
        text.append("\n\n💡 Fix: ", style="bold green")
        text.append(e.fix)
    console.print(Panel(text, title=f"[bold red]{e.__class__.__name__}[/]", border_style="red"))

__version__ = "0.4.0"


# ── agentci init --generate helpers ───────────────────────────────────────────

_AGENT_KEYWORDS = [
    "@tool", "def retrieve", "def run", "SystemMessage",
    "bind_tools", "add_node", "add_edge", "ChatOpenAI", "ChatAnthropic",
]
_KB_DIR_NAMES = {"knowledge_base", "kb", "docs", "data", "knowledge"}
_SKIP_DIRS = {"__pycache__", ".venv", "venv", ".git", "node_modules", "dist"}
_MAX_CONTEXT_CHARS = 48_000  # ~12k tokens at ~4 chars/token
_MAX_KB_FILE_CHARS = 2000    # deep-read per KB file

# Agent-type detection keywords (used in guided init interview)
_RAG_KEYWORDS = {"knowledge", "document", "retriev", "rag", "faq", "support", "qa", "question"}
_TOOL_KEYWORDS = {"tool", "function", "api", "action", "booking", "search", "plugin"}


def _scan_project(project_dir, kb_override: str | None = None) -> dict:
    """Scan project directory and return context for LLM test generation.

    Parameters
    ----------
    project_dir : path-like
        Root directory of the agent project.
    kb_override : str | None
        If provided, use this path as the knowledge base directory instead
        of auto-detecting from ``_KB_DIR_NAMES``.
    """
    from pathlib import Path

    project_dir = Path(project_dir)
    context: dict = {
        "agent_files": [],
        "knowledge_base": [],
        "existing_tests": [],
    }

    # 1. Agent code
    for py_file in project_dir.rglob("*.py"):
        parts = py_file.parts
        if any(skip in parts for skip in _SKIP_DIRS):
            continue
        if "tests" in parts or "test" in parts:
            continue
        try:
            content = py_file.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if any(kw in content for kw in _AGENT_KEYWORDS):
            lines = content.splitlines()[:150]
            context["agent_files"].append({
                "path": str(py_file.relative_to(project_dir)),
                "content": "\n".join(lines),
            })

    # 2. Knowledge base — deep sampling (up to _MAX_KB_FILE_CHARS per file)
    if kb_override is not None:
        kb_dirs_to_check = [Path(kb_override)]
    else:
        kb_dirs_to_check = [project_dir / d for d in _KB_DIR_NAMES]
    for kb_dir in kb_dirs_to_check:
        if not kb_dir.is_dir():
            continue
        # Sort by size ascending — smaller, focused files are more useful per char
        kb_files = sorted(
            [f for f in kb_dir.rglob("*") if f.suffix.lower() in {".md", ".txt"}],
            key=lambda f: f.stat().st_size,
        )
        for kb_file in kb_files:
            try:
                content = kb_file.read_text(encoding="utf-8", errors="ignore")
            except OSError:
                continue
            if len(content) > _MAX_KB_FILE_CHARS:
                snippet = content[:1000] + "\n...\n" + content[-500:]
            else:
                snippet = content
            context["knowledge_base"].append({
                "path": str(kb_file.relative_to(project_dir)),
                "snippet": snippet,
            })

    # 3. Existing tests
    for test_dir_name in ("tests", "test"):
        test_dir = project_dir / test_dir_name
        if not test_dir.is_dir():
            continue
        for test_file in test_dir.rglob("*.py"):
            try:
                lines = test_file.read_text(encoding="utf-8", errors="ignore").splitlines()[:100]
            except OSError:
                continue
            context["existing_tests"].append({
                "path": str(test_file.relative_to(project_dir)),
                "content": "\n".join(lines),
            })
        break  # only first matching test dir

    # Enforce total context limit (truncate longest pieces first)
    def _total_chars(ctx: dict) -> int:
        total = 0
        for f in ctx["agent_files"]:
            total += len(f["content"])
        for f in ctx["knowledge_base"]:
            total += len(f["snippet"])
        for f in ctx["existing_tests"]:
            total += len(f["content"])
        return total

    while _total_chars(context) > _MAX_CONTEXT_CHARS:
        # Find largest item and truncate it by 20%
        candidates = []
        for group, key in [("agent_files", "content"), ("knowledge_base", "snippet"), ("existing_tests", "content")]:
            for i, item in enumerate(context[group]):
                candidates.append((len(item[key]), group, i, key))
        if not candidates:
            break
        candidates.sort(reverse=True)
        _, group, idx, key = candidates[0]
        current = context[group][idx][key]
        context[group][idx][key] = current[:int(len(current) * 0.8)]

    return context


def _detect_agent_type(description: str) -> str:
    """Infer agent type from user description. Returns 'rag', 'tool', or 'conversational'."""
    desc_lower = description.lower()
    if any(kw in desc_lower for kw in _RAG_KEYWORDS):
        return "rag"
    if any(kw in desc_lower for kw in _TOOL_KEYWORDS):
        return "tool"
    return "conversational"


def _detect_tools_from_code(project_dir) -> list[str]:
    """Scan agent code for tool/function definitions and return their names."""
    import re
    from pathlib import Path

    project_dir = Path(project_dir)
    tools: list[str] = []
    tool_pattern = re.compile(r'@tool\s*(?:\(.*?\))?\s*\ndef\s+(\w+)', re.DOTALL)
    bind_pattern = re.compile(r'\.bind_tools\s*\(\s*\[([^\]]+)\]', re.DOTALL)

    for py_file in project_dir.rglob("*.py"):
        parts = py_file.parts
        if any(skip in parts for skip in _SKIP_DIRS):
            continue
        if "tests" in parts or "test" in parts:
            continue
        try:
            content = py_file.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        # @tool decorated functions
        tools.extend(tool_pattern.findall(content))
        # bind_tools([tool1, tool2])
        for match in bind_pattern.findall(content):
            tools.extend(name.strip().strip("'\"") for name in match.split(","))

    # Deduplicate, preserve order
    seen: set[str] = set()
    unique: list[str] = []
    for t in tools:
        if t and t not in seen:
            seen.add(t)
            unique.append(t)
    return unique


def _detect_kb_dir(project_dir) -> str | None:
    """Return the first matching knowledge base directory path, or None."""
    from pathlib import Path
    project_dir = Path(project_dir)
    for dir_name in _KB_DIR_NAMES:
        kb_dir = project_dir / dir_name
        if kb_dir.is_dir():
            kb_files = [f for f in kb_dir.rglob("*") if f.suffix.lower() in {".md", ".txt"}]
            if kb_files:
                return str(kb_dir)
    return None


def _load_golden_pairs(path: str) -> list[dict]:
    """Load golden Q&A pairs from a JSON or CSV file.

    Expected formats:
    - JSON: list of {"question": "...", "answer": "..."}
    - CSV: columns named 'question' and 'answer'
    """
    import json
    from pathlib import Path

    path_obj = Path(path)
    if not path_obj.exists():
        return []

    if path_obj.suffix.lower() == ".json":
        with open(path_obj) as f:
            data = json.load(f)
        if isinstance(data, list):
            return [p for p in data if isinstance(p, dict) and "question" in p and "answer" in p]
        return []

    if path_obj.suffix.lower() == ".csv":
        import csv
        pairs: list[dict] = []
        with open(path_obj, newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                if "question" in row and "answer" in row:
                    pairs.append({"question": row["question"], "answer": row["answer"]})
        return pairs

    return []


_RUNNER_FN_NAMES = {"run_for_agentci", "run_agent", "run_for_agent", "run"}
_RUNNER_BODY_HINTS = ("ctx.trace", "-> Trace", "TraceContext", "langgraph_trace")


def _detect_runner(project_dir) -> str | None:
    """Scan project files and return a best-guess 'module:function' runner path."""
    import re
    from pathlib import Path

    project_dir = Path(project_dir)
    fn_pattern = re.compile(r"^def (\w+)\s*\(", re.MULTILINE)

    best: tuple[int, str] | None = None  # (priority, "module:fn")

    for py_file in project_dir.rglob("*.py"):
        parts = py_file.parts
        if any(skip in parts for skip in _SKIP_DIRS):
            continue
        if "tests" in parts or "test" in parts:
            continue
        try:
            content = py_file.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue

        # Only consider files that look like runner files
        if not any(hint in content for hint in _RUNNER_BODY_HINTS):
            continue

        # Convert file path to dotted module name
        try:
            rel = py_file.relative_to(project_dir)
        except ValueError:
            continue
        module = ".".join(rel.with_suffix("").parts)

        for fn_name in fn_pattern.findall(content):
            priority = (
                0 if fn_name == "run_for_agentci" else
                1 if fn_name == "run_agent" else
                2 if fn_name in _RUNNER_FN_NAMES else
                3
            )
            if best is None or priority < best[0]:
                best = (priority, f"{module}:{fn_name}")

    return best[1] if best else None


def _generate_queries(context: dict, runner_path: str, interview: dict | None = None) -> list[dict]:
    """Call an LLM (Anthropic or OpenAI) to generate test queries from project context.

    Uses ANTHROPIC_API_KEY if set, falls back to OPENAI_API_KEY.

    Parameters
    ----------
    context : dict
        Output of ``_scan_project()`` with agent_files, knowledge_base, existing_tests.
    runner_path : str
        The ``module:function`` runner import path.
    interview : dict | None
        Guided interview answers: agent_description, agent_type, kb_path, tools,
        handle_topics, decline_topics, golden_pairs.
    """
    import yaml

    agent_files_text = "\n\n".join(
        f"# {f['path']}\n{f['content']}" for f in context["agent_files"]
    ) or "(none found)"

    kb_text = "\n\n".join(
        f"## {f['path']}\n{f['snippet']}" for f in context["knowledge_base"]
    ) or "(none found)"

    tests_text = "\n\n".join(
        f"# {f['path']}\n{f['content']}" for f in context["existing_tests"]
    ) or "(none found)"

    # Build interview context section
    interview_section = ""
    query_count = "10-15"
    query_guidance = ""
    if interview:
        parts: list[str] = []
        if interview.get("agent_description"):
            parts.append(f"AGENT DESCRIPTION:\n{interview['agent_description']}")
        if interview.get("agent_type"):
            parts.append(f"AGENT TYPE: {interview['agent_type']}")
        if interview.get("tools"):
            parts.append(f"TOOLS AVAILABLE: {', '.join(interview['tools'])}")
        if interview.get("handle_topics"):
            parts.append(f"TOPICS TO HANDLE: {interview['handle_topics']}")
        if interview.get("decline_topics"):
            parts.append(f"TOPICS TO DECLINE: {interview['decline_topics']}")
        if interview.get("golden_pairs"):
            pairs_text = "\n".join(
                f"  Q: {p['question']}\n  A: {p['answer']}" for p in interview["golden_pairs"]
            )
            parts.append(f"GOLDEN Q&A PAIRS (use these exact expected answers):\n{pairs_text}")
        if interview.get("_smoke_context"):
            parts.append(interview["_smoke_context"])
        interview_section = "\n\n".join(parts)
        query_count = interview.get("_query_count", "10-15")
        query_guidance = interview.get("_query_guidance", "")

    if query_guidance:
        query_instruction = query_guidance
    else:
        query_instruction = (
            f"Generate {query_count} test queries covering:\n"
            "1. Happy path (in-scope questions the agent should retrieve and answer)\n"
            "2. Out-of-scope (questions the agent must decline, max_tool_calls: 0)\n"
            "3. Edge cases (mixed intent, compound questions, unanswerable)\n"
            "4. At least 2 boundary cases (greeting, completely off-topic)"
        )

    prompt = f"""You are an expert AI agent test engineer. Given the following agent project context,
generate a diverse set of test queries for AgentCI's agentci_spec.yaml.

{interview_section}

AGENT CODE:
{agent_files_text}

KNOWLEDGE BASE CONTENT:
{kb_text}

EXISTING TEST COVERAGE:
{tests_text}

{query_instruction}

For each query, produce a YAML block with:
- query: the question string
- description: one sentence explaining what this tests
- tags: list of tags (smoke, in-scope, out-of-scope, edge-case, etc.)
- path: expected_tools list OR max_tool_calls: 0 for decline cases
- correctness: expected_in_answer keywords if deterministic, or llm_judge rule
- cost: max_llm_calls budget

IMPORTANT: All expected_in_answer values MUST come directly from the knowledge base
content or golden Q&A pairs above. Do NOT invent or hallucinate facts, numbers, or
specific details. If a fact is not present in the provided content, use llm_judge
with a descriptive rule instead of expected_in_answer.

Respond ONLY with valid YAML (a list of query objects, no surrounding text).
"""

    if os.environ.get("ANTHROPIC_API_KEY"):
        import anthropic as _anthropic
        client = _anthropic.Anthropic()
        message = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=4096,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = message.content[0].text.strip()
    else:
        import openai as _openai
        client = _openai.OpenAI()
        response = client.chat.completions.create(
            model="gpt-4o",
            max_tokens=4096,
            messages=[{"role": "user", "content": prompt}],
        )
        raw = response.choices[0].message.content.strip()

    # Strip markdown code fences if present
    if raw.startswith("```"):
        lines = raw.splitlines()
        raw = "\n".join(lines[1:-1] if lines[-1].strip() == "```" else lines[1:])

    parsed = yaml.safe_load(raw)
    # Filter out entries with missing or empty query strings
    return [
        q for q in parsed
        if isinstance(q, dict) and isinstance(q.get("query"), str) and q["query"].strip()
    ]


def _generate_smoke_queries(context: dict, runner_path: str, interview: dict | None = None) -> list[dict]:
    """Generate a small batch of 3 smoke-test queries for quick validation.

    Uses the same LLM as ``_generate_queries`` but with a tighter prompt
    requesting only 3 diverse queries (1 happy path, 1 out-of-scope, 1 boundary).
    """
    # Temporarily override the prompt count via a patched interview
    smoke_interview = dict(interview or {})
    smoke_interview["_query_count"] = "exactly 3"
    smoke_interview["_query_guidance"] = (
        "Generate exactly 3 queries:\n"
        "1. One happy-path in-scope question the agent should answer well\n"
        "2. One out-of-scope question the agent should decline\n"
        "3. One boundary case (greeting or off-topic)\n"
    )
    return _generate_queries(context, runner_path, interview=smoke_interview)[:3]


def _generate_full_queries(
    context: dict,
    runner_path: str,
    interview: dict | None = None,
    smoke_results: list[dict] | None = None,
) -> list[dict]:
    """Generate a full batch of 10-12 additional queries, informed by smoke results.

    Parameters
    ----------
    smoke_results : list[dict] | None
        Summaries of smoke test results so the LLM can avoid similar mistakes.
        Each dict has keys: query, passed (bool), issues (str).
    """
    full_interview = dict(interview or {})
    if smoke_results:
        results_text = "\n".join(
            f"  - \"{r['query']}\": {'PASSED' if r['passed'] else 'FAILED'}"
            + (f" ({r['issues']})" if r.get("issues") else "")
            for r in smoke_results
        )
        full_interview["_smoke_context"] = (
            f"Previous smoke test results (avoid repeating mistakes):\n{results_text}"
        )
    full_interview["_query_count"] = "10-12"
    return _generate_queries(context, runner_path, interview=full_interview)


@click.group()
@click.version_option(version=__version__, prog_name="agentci")
def cli():
    """Agent CI — Continuous Integration for AI Agents"""
    # Load .env variables
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass
    
    # Ensure current directory is in sys.path so we can import agents
    import sys
    import os
    if os.getcwd() not in sys.path:
        sys.path.insert(0, os.getcwd())
    pass


@cli.command()
@click.option('--hook', is_flag=True, help='Also install a .git/hooks/pre-push script')
@click.option('--force', is_flag=True, help='Overwrite existing files')
@click.option('--example', is_flag=True, help='Generate a pre-populated agentci_spec.yaml with RAG example')
@click.option('--generate', is_flag=True,
              help='Scan project code + knowledge base and auto-generate agentci_spec.yaml using AI')
@click.option('--agent-description', default=None,
              help='What your agent does (non-interactive mode)')
@click.option('--kb-path', default=None, type=click.Path(exists=True),
              help='Path to knowledge base directory (non-interactive mode)')
@click.option('--mode', 'run_mode', default=None,
              type=click.Choice(['live', 'mock']),
              help='Test run mode: live (real API) or mock (synthetic traces)')
def init(hook, force, example, generate, agent_description, kb_path, run_mode):
    """Scaffold a new AgentCI test suite and CI/CD pipeline."""
    import jinja2
    from rich.prompt import Prompt
    from pathlib import Path

    # Guard: --generate in live mode requires at least one LLM API key
    if generate and run_mode != "mock":
        if not os.environ.get("ANTHROPIC_API_KEY") and not os.environ.get("OPENAI_API_KEY"):
            console.print(
                "[bold red]Error:[/] --generate requires ANTHROPIC_API_KEY or OPENAI_API_KEY to be set.\n"
                "Set one and retry, or use [cyan]`agentci init --generate --mode mock`[/] for mock testing,\n"
                "or [cyan]`agentci init --example`[/] for a hardcoded starter."
            )
            sys.exit(1)

    # 0. Generate agentci_spec.yaml
    spec_dest = Path("agentci_spec.yaml")
    if spec_dest.exists() and not force:
        console.print(f"[yellow]Skipped:[/] {spec_dest} already exists. Use --force to overwrite.")
    else:
        console.print("\n[bold green]AgentCI Setup[/]")

        if generate:
            import yaml as _yaml

            # ── Guided Interview ─────────────────────────────────────
            interview: dict = {}

            # Q1: What does your agent do?
            if agent_description:
                interview["agent_description"] = agent_description
            else:
                interview["agent_description"] = Prompt.ask(
                    "\n[bold]Q1.[/] What does your agent do?\n"
                    "    [dim](e.g., 'Answers customer questions about NovaCorp using a knowledge base')[/]\n"
                )

            agent_type = _detect_agent_type(interview["agent_description"])
            interview["agent_type"] = agent_type

            # Q2: Run mode
            if run_mode:
                interview["run_mode"] = run_mode
            else:
                mode_choice = Prompt.ask(
                    "\n[bold]Q2.[/] How do you want to run tests?",
                    choices=["live", "mock"],
                    default="live",
                )
                interview["run_mode"] = mode_choice

            # Q3: Conditional follow-up based on agent type
            if agent_type == "rag":
                # Auto-detect KB directory
                detected_kb = kb_path or _detect_kb_dir(Path("."))
                if detected_kb and not kb_path:
                    from pathlib import Path as _P
                    kb_file_count = len([f for f in _P(detected_kb).rglob("*") if f.suffix.lower() in {".md", ".txt"}])
                    confirmed_kb = Prompt.ask(
                        f"\n[bold]Q3.[/] Where is your knowledge base directory?\n"
                        f"    [dim]Auto-detected: {detected_kb}/ ({kb_file_count} files)[/]",
                        default=detected_kb,
                    )
                    interview["kb_path"] = confirmed_kb
                elif kb_path:
                    interview["kb_path"] = kb_path
                else:
                    interview["kb_path"] = Prompt.ask(
                        "\n[bold]Q3.[/] Where is your knowledge base directory?",
                        default="./knowledge_base",
                    )

                # Golden pairs (optional)
                golden_path = Prompt.ask(
                    "\n    Do you have golden Q&A pairs? (JSON/CSV path, or Enter to skip)",
                    default="",
                )
                if golden_path:
                    interview["golden_pairs"] = _load_golden_pairs(golden_path)

            elif agent_type == "tool":
                detected_tools = _detect_tools_from_code(Path("."))
                if detected_tools:
                    tools_str = Prompt.ask(
                        f"\n[bold]Q3.[/] What tools does your agent expose?\n"
                        f"    [dim]Auto-detected: {detected_tools}[/]\n"
                        f"    [dim](Enter to confirm, or type comma-separated list)[/]",
                        default=", ".join(detected_tools),
                    )
                else:
                    tools_str = Prompt.ask(
                        "\n[bold]Q3.[/] What tools does your agent expose? (comma-separated)",
                        default="",
                    )
                if tools_str:
                    interview["tools"] = [t.strip() for t in tools_str.split(",") if t.strip()]

            else:  # conversational
                handle = Prompt.ask(
                    "\n[bold]Q3a.[/] What topics should your agent handle? (comma-separated)",
                    default="",
                )
                decline = Prompt.ask(
                    "[bold]Q3b.[/] What topics should your agent decline? (comma-separated)",
                    default="",
                )
                if handle:
                    interview["handle_topics"] = handle
                if decline:
                    interview["decline_topics"] = decline

            # ── Scan & Generate ──────────────────────────────────────
            console.print("\nScanning project...")

            # If KB path was provided via interview, override scanning
            if interview.get("kb_path"):
                context = _scan_project(Path("."), kb_override=interview["kb_path"])
            else:
                context = _scan_project(Path("."))

            console.print(
                f"Found [cyan]{len(context['agent_files'])}[/] agent files, "
                f"[cyan]{len(context['knowledge_base'])}[/] knowledge base documents, "
                f"[cyan]{len(context['existing_tests'])}[/] existing test files"
            )

            detected = _detect_runner(Path("."))
            runner_default = detected or "myagent.run:run_agent"
            if detected:
                console.print(f"Detected runner: [cyan]{detected}[/]")
            runner_path = Prompt.ask(
                "Runner import path",
                default=runner_default,
            )

            # ── Progressive spec building ────────────────────────────
            console.print("\nGenerating initial smoke-test queries...")
            queries = None
            try:
                smoke_queries = _generate_smoke_queries(context, runner_path, interview=interview)
            except Exception as e:
                console.print(f"[yellow]Warning:[/] AI generation failed ({e}). Falling back to --example template.")
                smoke_queries = None

            if smoke_queries:
                console.print(f"Generated [cyan]{len(smoke_queries)}[/] smoke-test queries:")
                for i, q in enumerate(smoke_queries, 1):
                    tags = ", ".join(q.get("tags", [])) if q.get("tags") else ""
                    console.print(f"  {i}. \"{q['query']}\" [dim]{tags}[/]")

                from rich.prompt import Confirm
                if Confirm.ask("\nGenerate more queries?", default=True):
                    console.print("Generating full test suite...")
                    try:
                        full_queries = _generate_full_queries(
                            context, runner_path, interview=interview,
                        )
                        queries = smoke_queries + full_queries
                        console.print(f"Generated [cyan]{len(queries)}[/] total test queries")
                    except Exception as e:
                        console.print(f"[yellow]Warning:[/] Full generation failed ({e}). Using smoke queries only.")
                        queries = smoke_queries
                else:
                    queries = smoke_queries
                    console.print(f"Using [cyan]{len(queries)}[/] smoke-test queries")
            else:
                # Fallback: try full generation directly
                try:
                    queries = _generate_queries(context, runner_path, interview=interview)
                except Exception as e:
                    console.print(f"[yellow]Warning:[/] AI generation failed ({e}). Falling back to --example template.")

            if queries and isinstance(queries, list):
                console.print(f"[green]✓[/] {len(queries)} test queries ready")
                spec_dict = {
                    "agent": "my-agent",
                    "runner": runner_path,
                    "version": 1.0,
                    "judge_config": {"model": "openai:gpt-4o-mini", "temperature": 0.1},
                    "baseline_dir": "./baselines",
                    "queries": queries,
                }
                spec_content = _yaml.dump(spec_dict, sort_keys=False, allow_unicode=True)
            else:
                # Fallback to example template
                spec_content = f'''agent: my-agent
runner: "{runner_path}"
version: 1.0

judge_config:
  model: openai:gpt-4o-mini
  temperature: 0.1

baseline_dir: ./baselines

queries:
  # Add your test queries here
'''

        else:
            runner_path = Prompt.ask(
                "What is the import path for your agent runner function?",
                default="myagent.run:run_agent"
            )

            if example:
                spec_content = f'''agent: rag-agent
runner: "{runner_path}"
version: 1.0

judge_config:
  model: openai:gpt-4o-mini
  temperature: 0.1

baseline_dir: ./baselines

queries:
  - query: "How do I reset my password?"
    description: "Documentation retrieval test"
    expected_tools:
      - search_docs
    max_tool_calls: 3
    max_total_tokens: 2000
    llm_judge: "Response must provide clear, step-by-step instructions to reset a password."

  - query: "What is the weather in Tokyo?"
    description: "Out of scope query test"
    max_tool_calls: 0
    not_in_answer: ["degrees", "celsius", "fahrenheit", "cloudy", "sunny"]
'''
            else:
                spec_content = f'''agent: my-agent
runner: "{runner_path}"
version: 1.0

judge_config:
  model: openai:gpt-4o-mini

baseline_dir: ./baselines

queries:
  # Add your test queries here
'''
        with open(spec_dest, "w") as f:
            f.write(spec_content)
        console.print(f"[green]✓ Created[/] {spec_dest}")
        console.print()

    # Auto-detect project characteristics
    dependency_file = "requirements.txt"
    if os.path.exists("pyproject.toml"):
        dependency_file = "pyproject.toml"
        
    test_path = "tests/"
    if not os.path.exists("tests") and os.path.exists("test"):
        test_path = "test/"
        
    # Python version (defaulting to current running version)
    python_version = f"{sys.version_info.major}.{sys.version_info.minor}"
    
    template_data = {
        "python_version": python_version,
        "dependency_file": dependency_file,
        "test_path": test_path
    }
    
    # Set up Jinja environment pointing to the templates package
    from pathlib import Path
    template_dir = Path(__file__).parent / "templates"
    
    # If templates aren't packaged (e.g. during dev), fallback to basic string replacement
    # We'll use a simple manual replacement if jinja2 fails to load the file
    github_action_dest = Path(".github/workflows/agentci.yml")
    pre_push_dest = Path(".git/hooks/pre-push")
    
    # 1. Create GitHub Actions Workflow
    github_action_dest.parent.mkdir(parents=True, exist_ok=True)
    if github_action_dest.exists() and not force:
        console.print(f"[yellow]Skipped:[/] {github_action_dest} already exists. Use --force to overwrite.")
    else:
        template_path = template_dir / "github_action.yml.j2"
        try:
            with open(template_path, "r") as f:
                template_str = f.read()
            import jinja2
            template = jinja2.Template(template_str)
            content = template.render(**template_data)
        except Exception as e:
            console.print(f"[yellow]Warning:[/] Could not load Jinja template ({e}). Using fallback.")
            content = f"# Scaffolded by AgentCI\n# Test Path: {test_path}\n# Deps: {dependency_file}\n"
            
        with open(github_action_dest, "w") as f:
            f.write(content)
        console.print(f"[green]✓ Created[/] {github_action_dest}")
        
    # 2. Create Pre-push Hook (if requested)
    if hook:
        if not Path(".git").exists():
            console.print("[red]Error:[/] Not a git repository. Cannot install pre-push hook.")
        else:
            pre_push_dest.parent.mkdir(parents=True, exist_ok=True)
            if pre_push_dest.exists() and not force:
                console.print(f"[yellow]Skipped:[/] {pre_push_dest} already exists.")
            else:
                template_path = template_dir / "pre_push_hook.sh.j2"
                try:
                    with open(template_path, "r") as f:
                        template_str = f.read()
                    template = jinja2.Template(template_str)
                    content = template.render(**template_data)
                except Exception as e:
                    content = f"#!/bin/sh\npytest {test_path} -m 'not live'"
                
                with open(pre_push_dest, "w") as f:
                    f.write(content)
                os.chmod(pre_push_dest, 0o755)  # Make executable
                console.print(f"[green]✓ Installed[/] {pre_push_dest}")

    console.print("\n[bold green]AgentCI Initialization Complete! 🚀[/]")
    console.print("\n[bold]Next Steps:[/]")
    console.print("1. Commit the newly generated files: [cyan]git add .github/[/]")
    console.print("2. Add [cyan]ANTHROPIC_API_KEY[/] to your GitHub repository secrets.")
    console.print(f"3. Push your code to see the CI run: [cyan]git push[/]")


@cli.command()
@click.option('--queries', type=click.Path(exists=True), help='Text file with one query per line (optional, falls back to interactive)')
@click.option('--agent', default='my-agent', help='Agent name for the spec')
@click.option('--runner', required=True, help='Import path for runner function, e.g. myagent.run:run')
@click.option('--output', default='agentci_spec.yaml', help='Output spec file')
@click.option('--baseline-dir', default='./baselines', help='Directory for baselines')
def bootstrap(queries, agent, runner, output, baseline_dir):
    """Zero-to-Golden interactive bootstrapper."""
    import yaml
    import json
    import re
    from datetime import datetime, timezone
    from pathlib import Path
    from rich.prompt import Prompt, Confirm
    from .engine.parallel import resolve_runner

    try:
        runner_fn = resolve_runner(runner)
    except Exception as e:
        console.print(f"[bold red]Failed to load runner:[/] {e}")
        sys.exit(1)

    query_list = []
    if queries:
        with open(queries) as f:
            query_list = [q.strip() for q in f if q.strip()]
    else:
        console.print("\n[bold green]Zero-to-Golden Bootstrapper[/]")
        console.print("Enter test queries one by one (empty line to finish):")
        while True:
            q = Prompt.ask("Query")
            if not q.strip():
                break
            query_list.append(q.strip())

    if not query_list:
        console.print("[yellow]No queries provided. Exiting.[/]")
        sys.exit(0)

    spec_dict = {
        "agent": agent,
        "runner": runner,
        "version": 1.0,
        "judge_config": {
            "model": "openai:gpt-4o-mini",
            "temperature": 0.1
        },
        "baseline_dir": baseline_dir,
        "queries": []
    }

    baseline_path = Path(baseline_dir) / agent
    baseline_path.mkdir(parents=True, exist_ok=True)

    for i, q in enumerate(query_list):
        console.print(f"\n[bold cyan]Running Query {i+1}/{len(query_list)}:[/] {q}")
        try:
            trace = runner_fn(q)
            
            # Print Tier 1 summary
            console.print(f"  Duration:   {trace.total_duration_ms:.1f}ms")
            console.print(f"  Cost:       ${trace.total_cost_usd:.4f}")
            console.print(f"  Tokens:     {trace.total_tokens}")
            console.print(f"  Tool Calls: {len(trace.tool_call_sequence)}")
            if trace.tool_call_sequence:
                console.print(f"  Path:       {' → '.join(trace.tool_call_sequence)}")
            
            if Confirm.ask("Accept this trace as golden?", default=True):
                # Generates assertions
                expected_tools = trace.tool_call_sequence
                max_tool_calls = len(trace.tool_call_sequence) + 1
                max_total_tokens = int(trace.total_tokens * 1.5) or 2000
                
                query_entry = {
                    "query": q,
                    "description": f"Auto-generated test {i+1}",
                    "path": {
                        "expected_tools": expected_tools,
                        "max_tool_calls": max_tool_calls,
                    },
                    "cost": {
                        "max_total_tokens": max_total_tokens,
                    }
                }
                spec_dict["queries"].append(query_entry)
                
                # Save baseline
                baseline_data = {
                    "version": "v1",
                    "agent": agent,
                    "captured_at": datetime.now(timezone.utc).isoformat(),
                    "query": q,
                    "metadata": {
                        "model": "auto",
                        "precheck_passed": False
                    },
                    "trace": json.loads(trace.model_dump_json())
                }
                
                slug = re.sub(r'[^a-z0-9]+', '-', q.lower())[:30].strip('-') or f"query_{i}"
                b_file = baseline_path / f"v1-{slug}.json"
                with open(b_file, "w") as bf:
                    json.dump(baseline_data, bf, indent=2)
                console.print(f"[green]Saved baseline to {b_file}[/]")
        except Exception as e:
            console.print(f"[bold red]Error running agent:[/] {e}")

    if spec_dict["queries"]:
        with open(output, "w") as f:
            yaml.dump(spec_dict, f, sort_keys=False)
        console.print(f"\n[bold green]Bootstrap complete![/] Spec saved to {output}")
        console.print("Run [cyan]agentci test[/] to verify.")


from collections import defaultdict
@cli.command()
@click.option('--suite', '-s', default='agentci.yaml', help='Path to test suite YAML')
@click.option('--runs', '-n', default=1, help='Number of runs for statistical mode')
@click.option('--tag', '-t', multiple=True, help='Only run tests with these tags')
@click.option('--diff/--no-diff', default=True, help='Compare against golden traces')
@click.option('--html', type=click.Path(), help='Generate HTML report at this path')
@click.option('--fail-on-cost', type=float, help='Fail if total cost exceeds threshold')
@click.option('--ci', is_flag=True, help='CI mode: exit code 1 on any failure')
@click.option('--json', 'output_json', is_flag=True, help='Output results as JSON (for agent consumption)')
def run(suite, runs, tag, diff, html, fail_on_cost, ci, output_json):
    """Execute the test suite."""
    if not output_json:
        console.print(f"[bold blue]Agent CI[/] Running suite: [cyan]{suite}[/]")

    try:
        config = load_config(suite)
        runner = TestRunner(config)

        # Filter tests by tag if provided
        if tag:
            config.tests = [t for t in config.tests if any(tg in t.tags for tg in tag)]
            if not output_json:
                console.print(f"Filtered to [yellow]{len(config.tests)}[/] tests with tags: {tag}")

        suite_result = runner.run_suite(runs=runs)

        # JSON output mode — structured, machine-readable
        if output_json:
            import json as json_mod
            click.echo(suite_result.model_dump_json(indent=2))

            # Exit with appropriate code
            if fail_on_cost and suite_result.total_cost_usd > fail_on_cost:
                sys.exit(1)
            if ci and (suite_result.total_failed > 0 or suite_result.total_errors > 0):
                sys.exit(1)
            return

        # Display Results Table (human-readable)
        table = Table(title=f"Results: {suite_result.suite_name}")

        if runs > 1:
            # Statistical Display
            table.add_column("Test Case", style="cyan")
            table.add_column("Pass Rate", justify="center")
            table.add_column("Mean Cost", justify="right")
            table.add_column("Mean Duration", justify="right")
            table.add_column("Status")

            # Group by test name
            from collections import defaultdict
            grouped_results = defaultdict(list)
            for res in suite_result.results:
                grouped_results[res.test_name].append(res)

            for test_name, results in grouped_results.items():
                passed_count = sum(1 for r in results if r.result == TestResult.PASSED)
                pass_rate = (passed_count / len(results)) * 100
                mean_cost = sum(r.trace.total_cost_usd for r in results) / len(results)
                mean_duration = sum(r.duration_ms for r in results) / len(results)

                status_style = "green" if passed_count == len(results) else "yellow" if passed_count > 0 else "red"
                status_str = "STABLE" if passed_count == len(results) else "FLAKY" if passed_count > 0 else "FAILING"

                table.add_row(
                    test_name,
                    f"{passed_count}/{len(results)} ({pass_rate:.0f}%)",
                    f"${mean_cost:.4f}",
                    f"{mean_duration:.1f}ms",
                    f"[{status_style}]{status_str}[/]"
                )
        else:
            # Single Run Display (Existing logic)
            table.add_column("Test Case", style="cyan")
            table.add_column("Result", justify="center")
            table.add_column("Cost (USD)", justify="right")
            table.add_column("Duration (ms)", justify="right")
            table.add_column("Diffs/Details")

            for res in suite_result.results:
                result_str = "[green]PASSED[/]" if res.result == TestResult.PASSED else \
                             "[red]FAILED[/]" if res.result == TestResult.FAILED else \
                             "[bold red]ERROR[/]"

                details = []
                if res.error_message:
                    details.append(f"[red]{res.error_message}[/]")

                if res.assertion_results:
                    for r in res.assertion_results:
                        if not r['passed']:
                            details.append(r['message'])

                # Add Diff Details
                if res.diffs:
                    for d in res.diffs:
                        color = "red" if d.severity == "error" else "yellow"
                        details.append(f"[{color}]{d.message}[/]")

                table.add_row(
                    res.test_name,
                    result_str,
                    f"${res.trace.total_cost_usd:.4f}",
                    f"{res.duration_ms:.1f}",
                    "\n".join(details)
                )

        console.print(table)

        # Summary
        console.print(f"\n[bold]Summary:[/] [green]{suite_result.total_passed} Passed[/], "
                      f"[red]{suite_result.total_failed} Failed[/], "
                      f"[bold red]{suite_result.total_errors} Errors[/]")
        console.print(f"Total Cost: [bold]${suite_result.total_cost_usd:.4f}[/]")
        console.print(f"Total Duration: [bold]{suite_result.duration_ms:.1f}ms[/]")

        # Check fail-on-cost
        if fail_on_cost and suite_result.total_cost_usd > fail_on_cost:
             console.print(f"[bold red]FAILURE:[/] Total cost ${suite_result.total_cost_usd:.4f} "
                           f"exceeds limit ${fail_on_cost:.4f}")
             if ci:
                 sys.exit(1)

        if ci and (suite_result.total_failed > 0 or suite_result.total_errors > 0):
            sys.exit(1)

    except Exception as e:
        if output_json:
            import json as json_mod
            click.echo(json_mod.dumps({"error": str(e)}))
        else:
            console.print(f"[bold red]Error:[/] {e}")
        if ci:
            sys.exit(1)


@cli.command()
@click.argument('test_name')
@click.option('--suite', '-s', default='agentci.yaml')
@click.option('--output', '-o', help='Output path for golden trace')
@click.option('--json', 'output_json', is_flag=True, help='Output trace as JSON (for agent consumption)')
def record(test_name, suite, output, output_json):
    """Run agent live and save the trace as a golden baseline."""
    try:
        config = load_config(suite)
        runner = TestRunner(config)
        agent_fn = runner._import_agent()

        # Find the specific test
        test = next((t for t in config.tests if t.name == test_name), None)
        if not test:
            if output_json:
                import json as json_mod
                click.echo(json_mod.dumps({"error": f"Test '{test_name}' not found in {suite}"}))
            else:
                console.print(f"[bold red]Error:[/] Test '{test_name}' not found in {suite}")
            return

        if not output_json:
            console.print(f"Recording trace for [cyan]{test_name}[/]...")

        # Run the test
        result = runner.run_test(test, agent_fn)

        # Attach the final output text to the trace
        if result.trace and result.final_output:
            result.trace.metadata["final_output"] = str(result.final_output)
            if result.trace.spans:
                result.trace.spans[-1].output_data = str(result.final_output)

        # Determine output path
        if output:
            save_path = output
        elif test.golden_trace:
            save_path = test.golden_trace
        else:
            save_path = f"golden/{test_name}.golden.json"

        # JSON output mode — structured, machine-readable
        if output_json:
            import json as json_mod
            output_data = {
                "test_name": test_name,
                "save_path": save_path,
                "duration_ms": result.duration_ms,
                "cost_usd": result.trace.total_cost_usd,
                "tool_calls": result.trace.tool_call_sequence,
                "error": result.error_message,
            }
            # Auto-save in JSON mode (no interactive prompt)
            os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)
            with open(save_path, 'w') as f:
                f.write(result.trace.model_dump_json(indent=2))
            output_data["saved"] = True
            click.echo(json_mod.dumps(output_data, indent=2))
            return

        # Show summary (human-readable)
        console.print(f"Duration: {result.duration_ms:.1f}ms")
        console.print(f"Cost: ${result.trace.total_cost_usd:.4f}")
        console.print(f"Tool Calls: {len(result.trace.tool_call_sequence)}")

        if result.error_message:
             console.print(f"[bold red]Error during run:[/] {result.error_message}")

        # Ensure directory exists
        os.makedirs(os.path.dirname(os.path.abspath(save_path)), exist_ok=True)

        # Prompt user
        from rich.prompt import Confirm
        if Confirm.ask(f"Save golden trace to [yellow]{save_path}[/]?", default=True):
            with open(save_path, 'w') as f:
                f.write(result.trace.model_dump_json(indent=2))
            console.print(f"[green]Saved![/]")
        else:
            console.print("[yellow]Cancelled.[/]")

    except Exception as e:
        if output_json:
            import json as json_mod
            click.echo(json_mod.dumps({"error": str(e)}))
        else:
            console.print(f"[bold red]Error:[/] {e}")


@cli.command(name="diff")
@click.option('--baseline', '-b', required=True, help="Baseline version tag (e.g. 'v1-broken')")
@click.option('--compare', '-c', required=True, help="Compare version tag (e.g. 'v2-fixed')")
@click.option('--agent', '-a', required=True, help="Agent identifier (matches baseline file naming)")
@click.option('--config', 'spec_path', default=None, type=click.Path(exists=True),
              help='Path to agentci_spec.yaml for correctness evaluation (optional)')
@click.option('--baseline-dir', default='./baselines', show_default=True,
              help='Directory containing versioned baseline JSON files')
@click.option('--format', 'fmt', type=click.Choice(['console', 'github', 'json']),
              default='console', show_default=True, help='Output format')
@click.option('--query', 'query_filter', default=None,
              help='Only compare baselines for this specific query (partial match)')
def diff_cmd(baseline, compare, agent, spec_path, baseline_dir, fmt, query_filter):
    """Compare two versioned baselines with three-tier (Correctness/Path/Cost) analysis.

    Loads the AGENT.BASELINE.json and AGENT.COMPARE.json files from BASELINE_DIR
    and renders a structured diff report.

    Example:
        agentci diff --baseline v1-broken --compare v2-fixed --agent rag-agent

    Exit codes:
        0  No regressions detected
        1  Correctness regression (pass → fail)
        2  Error loading baselines
    """
    import json as json_mod
    from pathlib import Path
    from .engine.diff import diff_baselines

    baseline_dir_path = Path(baseline_dir)

    # Collect matching baseline files
    baseline_pattern = f"{agent}.{baseline}.json"
    compare_pattern = f"{agent}.{compare}.json"

    baseline_file = baseline_dir_path / baseline_pattern
    compare_file = baseline_dir_path / compare_pattern

    if not baseline_file.exists():
        # Try glob — maybe multiple queries are stored as separate files
        baseline_files = sorted(baseline_dir_path.glob(f"{agent}.{baseline}.*.json"))
        compare_files = sorted(baseline_dir_path.glob(f"{agent}.{compare}.*.json"))
    else:
        baseline_files = [baseline_file]
        compare_files = [compare_file]

    if not baseline_files:
        console.print(f"[red]Error:[/] No baseline files found for '{agent}.{baseline}' in {baseline_dir}")
        console.print(f"[dim]Looked for: {baseline_dir_path / baseline_pattern}[/]")
        sys.exit(2)

    if not compare_files:
        console.print(f"[red]Error:[/] No compare files found for '{agent}.{compare}' in {baseline_dir}")
        sys.exit(2)

    # Pair up files by query index
    pairs = list(zip(baseline_files, compare_files))

    # Apply query filter
    if query_filter:
        pairs = [(b, c) for b, c in pairs if query_filter.lower() in b.stem.lower()]

    # Load optional spec
    spec = None
    if spec_path:
        from .loader import load_spec
        try:
            spec = load_spec(spec_path)
        except Exception as e:
            console.print(f"[yellow]Warning:[/] Could not load spec ({e}) — correctness comparison disabled")

    # Run diff for each pair
    reports = []
    for b_file, c_file in pairs:
        try:
            with open(b_file) as f:
                b_data = json_mod.load(f)
            with open(c_file) as f:
                c_data = json_mod.load(f)
        except Exception as e:
            console.print(f"[red]Error loading baselines:[/] {e}")
            sys.exit(2)

        report = diff_baselines(b_data, c_data, spec=spec)
        reports.append(report)

    if not reports:
        console.print("[yellow]No matching baseline pairs found.[/]")
        sys.exit(0)

    # Render output
    any_regression = False
    for report in reports:
        if report.has_regression:
            any_regression = True

        if fmt == "console":
            console.print(report.summary_console())
            if len(pairs) > 1:
                console.print()  # blank line between multiple reports

        elif fmt == "json":
            import json as json_mod
            click.echo(json_mod.dumps(report.summary_json(), indent=2))

        elif fmt == "github":
            j = report.summary_json()
            prefix = "error" if report.has_regression else "notice"
            title = f"AgentCI Diff: {report.agent} ({report.from_version} → {report.to_version})"
            body_parts = []
            for p in j.get("path", []):
                pct = f" ({p['pct_change']:+.1f}%)" if p.get("pct_change") is not None else ""
                body_parts.append(f"{p['metric']}: {p['before']} → {p['after']}{pct}")
            for c in j.get("cost", []):
                pct = f" ({c['pct_change']:+.1f}%)" if c.get("pct_change") is not None else ""
                body_parts.append(f"{c['metric']}: {c['before']} → {c['after']}{pct}")
            body = " | ".join(body_parts) if body_parts else "No metric changes"
            click.echo(f"::{prefix} title={title}::{body}")

    sys.exit(1 if any_regression else 0)


@cli.command()
@click.option('--input', '-i', type=click.Path(exists=True), required=True)
@click.option('--output', '-o', type=click.Path(), required=True)
def report(input, output):
    """Generate an HTML report from a JSON results file."""
    pass


# ── v2 Commands ────────────────────────────────────────────────────────────────


@cli.command()
@click.argument('spec_path', type=click.Path(exists=True))
def validate(spec_path):
    """Validate an agentci_spec.yaml file against the schema.

    Exits 0 on success, 1 on validation failure.
    """
    from .loader import load_spec
    from .exceptions import ConfigError
    from pydantic import ValidationError

    try:
        spec = load_spec(spec_path)
        console.print(
            f"[green]✅ Valid:[/] {len(spec.queries)} queries, agent='{spec.agent}'"
        )
        sys.exit(0)
    except (ConfigError, ValidationError) as e:
        console.print(f"[bold red]❌ Validation failed:[/]\n{e}")
        sys.exit(1)


@cli.command(name="doctor")
@click.option('--config', '-c', default='agentci_spec.yaml',
              help='Path to agentci_spec.yaml', show_default=True)
def doctor_cmd(config):
    """Check your AgentCI setup for common issues.

    Validates the spec, runner, API keys, knowledge base, dependencies,
    and CI configuration. Prints a pass/warn/fail summary with fix hints.
    """
    from pathlib import Path

    checks: list[tuple[str, str, str]] = []  # (status, message, fix_hint)

    # 1. Spec file exists and validates
    spec = None
    if not Path(config).exists():
        checks.append(("fail", f"{config} not found", "Run: agentci init --generate"))
    else:
        try:
            from .loader import load_spec
            spec = load_spec(config)
            checks.append(("pass", f"{config} valid ({len(spec.queries)} queries)", ""))
        except Exception as e:
            checks.append(("fail", f"{config} invalid: {e}", "Run: agentci validate"))

    # 2. Runner imports successfully
    if spec and spec.runner:
        try:
            from .engine.parallel import resolve_runner
            resolve_runner(spec.runner)
            checks.append(("pass", f"Runner '{spec.runner}' imports successfully", ""))
        except Exception as e:
            checks.append(("fail", f"Runner '{spec.runner}' failed: {e}",
                           "Check the module:function path in your spec"))
    elif spec:
        checks.append(("warn", "No runner declared in spec",
                        "Add runner: \"module:function\" to your spec, or use --mock"))

    # 3. API keys
    if os.environ.get("ANTHROPIC_API_KEY"):
        checks.append(("pass", "ANTHROPIC_API_KEY is set", ""))
    else:
        checks.append(("warn", "ANTHROPIC_API_KEY is not set",
                        "Set it for LLM judge evaluation"))

    if os.environ.get("OPENAI_API_KEY"):
        checks.append(("pass", "OPENAI_API_KEY is set", ""))
    else:
        checks.append(("warn", "OPENAI_API_KEY is not set",
                        "Needed if agent uses OpenAI models"))

    # 4. Knowledge base directory
    detected_kb = _detect_kb_dir(Path("."))
    if detected_kb:
        from pathlib import Path as _P
        kb_count = len([f for f in _P(detected_kb).rglob("*") if f.suffix.lower() in {".md", ".txt"}])
        checks.append(("pass", f"Knowledge base: {detected_kb}/ ({kb_count} files)", ""))
    else:
        checks.append(("warn", "No knowledge base directory found",
                        "Create knowledge_base/, kb/, or docs/ with .md/.txt files"))

    # 5. Python version
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    if sys.version_info >= (3, 10):
        checks.append(("pass", f"Python {py_ver} (>=3.10 required)", ""))
    else:
        checks.append(("fail", f"Python {py_ver} (>=3.10 required)",
                        "Upgrade Python to 3.10+"))

    # 6. Key dependencies
    for pkg in ["numpy", "pydantic", "click", "rich", "pyyaml"]:
        import_name = "yaml" if pkg == "pyyaml" else pkg
        try:
            __import__(import_name)
            checks.append(("pass", f"{pkg} is installed", ""))
        except ImportError:
            checks.append(("fail", f"{pkg} is not installed", f"pip install {pkg}"))

    # 7. GitHub Actions workflow
    if Path(".github/workflows/agentci.yml").exists():
        checks.append(("pass", ".github/workflows/agentci.yml exists", ""))
    else:
        checks.append(("warn", "No GitHub Actions workflow found",
                        "Run: agentci init"))

    # 8. requirements.txt includes ciagent
    for req_file in ("requirements.txt", "pyproject.toml"):
        if Path(req_file).exists():
            content = Path(req_file).read_text()
            if "ciagent" in content:
                checks.append(("pass", f"{req_file} includes ciagent", ""))
            else:
                checks.append(("warn", f"{req_file} does not mention ciagent",
                                f"Add ciagent to {req_file}"))
            break

    # ── Print results ─────────────────────────────────────────────────────
    icons = {"pass": "[green]✓[/]", "warn": "[yellow]![/]", "fail": "[red]✗[/]"}
    console.print("\n[bold blue]AgentCI Doctor[/]\n")
    for status, msg, fix in checks:
        line = f"  {icons[status]} {msg}"
        if fix and status != "pass":
            line += f"  [dim]→ {fix}[/]"
        console.print(line)

    passed = sum(1 for s, _, _ in checks if s == "pass")
    warned = sum(1 for s, _, _ in checks if s == "warn")
    failed = sum(1 for s, _, _ in checks if s == "fail")
    console.print(f"\n  [bold]{passed} passed[/], {warned} warnings, {failed} failures\n")

    sys.exit(1 if failed > 0 else 0)


@cli.command(name="test")
@click.option('--config', '-c', default='agentci_spec.yaml',
              help='Path to agentci_spec.yaml', show_default=True)
@click.option('--tags', '-t', multiple=True, help='Only evaluate queries with these tags')
@click.option('--format', 'fmt',
              type=click.Choice(['console', 'github', 'json', 'prometheus']),
              default='console', show_default=True, help='Output format')
@click.option('--baseline-dir', default=None,
              help='Override baseline directory from spec')
@click.option('--workers', '-w', default=4, show_default=True, type=int,
              help='Max parallel workers for query execution')
@click.option('--sample-ensemble', default=None, type=float,
              help='Fraction of queries to use ensemble judging (0.0-1.0, e.g. 0.2)')
@click.option('--mock', is_flag=True,
              help='Run with synthetic traces (no API calls). Validates spec structure.')
@click.option('--yes', '-y', is_flag=True,
              help='Skip cost estimate confirmation (for CI)')
def test_cmd(config, tags, fmt, baseline_dir, workers, sample_ensemble, mock, yes):
    """Run AgentCI v2 evaluation against a spec file.

    Loads agentci_spec.yaml, runs the agent for each query (capturing traces),
    evaluates all three layers (Correctness / Path / Cost), and reports results.

    Use --mock to validate your spec with synthetic traces (zero API cost).

    \b
    Requires the spec to declare a runner (unless --mock is used):
        runner: "myagent.run:run_agent"

    The runner function must accept (query: str) and return an agentci.models.Trace.

    \b
    Exit codes:
        0 — all correctness checks pass (warnings emitted as annotations)
        1 — one or more correctness failures
        2 — runtime / infrastructure error
    """
    import json as _json
    from pathlib import Path

    from .loader import load_spec, filter_by_tags
    from .engine.reporter import report_results
    from .engine.runner import evaluate_spec
    from .exceptions import ConfigError

    try:
        spec = load_spec(config)
    except ConfigError as e:
        console.print(f"[bold red]Config error:[/] {e}")
        sys.exit(2)

    if tags:
        spec = filter_by_tags(spec, list(tags))
        if not spec.queries:
            console.print(f"[yellow]No queries match tags: {tags}[/]")
            sys.exit(0)

    effective_baseline_dir = baseline_dir or spec.baseline_dir

    # ── Mock mode ─────────────────────────────────────────────────────────────
    if mock:
        from .engine.mock_runner import run_mock_spec

        console.print(
            f"[bold blue]AgentCI v2[/] │ agent: [cyan]{spec.agent}[/] │ "
            f"queries: [cyan]{len(spec.queries)}[/] │ mode: [cyan]mock[/]"
        )
        console.print("[dim]Running with synthetic traces — zero API cost[/]\n")

        traces = run_mock_spec(spec)
        try:
            results = evaluate_spec(spec, traces, None)
        except Exception as e:  # noqa: BLE001
            console.print(f"[bold red]Evaluation error:[/] {e}")
            sys.exit(2)
        exit_code = report_results(results, format=fmt, spec_file=config)
        sys.exit(exit_code)

    # ── Check for runner ──────────────────────────────────────────────────────
    if not spec.runner:
        console.print(
            f"[bold blue]AgentCI v2[/] spec has [cyan]{len(spec.queries)}[/] "
            f"queries for agent '[cyan]{spec.agent}[/]'\n"
        )
        console.print(
            "[yellow]ℹ[/] No [bold]runner[/] declared in spec. Add one to run live:\n\n"
            "  [cyan]runner: \"myagent.run:run_agent\"[/]\n\n"
            "The function must accept [bold](query: str) → Trace[/].\n\n"
            "Or use [cyan]agentci test --mock[/] to validate your spec without API calls.\n\n"
            "Or use the Python API in your test suite:\n"
            "  [cyan]from agentci import load_spec, run_spec[/]\n"
            "  [cyan]results = run_spec(spec, my_agent_fn)[/]"
        )
        sys.exit(0)

    # ── Resolve runner ────────────────────────────────────────────────────────
    from .engine.parallel import run_spec_parallel, resolve_runner

    try:
        runner_fn = resolve_runner(spec.runner)
    except (ImportError, AttributeError, ValueError) as e:
        console.print(f"[bold red]Runner error:[/] {e}")
        sys.exit(2)

    # ── Inject sample-ensemble into judge_config ──────────────────────────────
    if sample_ensemble is not None:
        if not (0.0 <= sample_ensemble <= 1.0):
            console.print("[bold red]--sample-ensemble must be between 0.0 and 1.0[/]")
            sys.exit(2)
        spec.judge_config = spec.judge_config or {}
        spec.judge_config["sample_ensemble"] = sample_ensemble

    # ── Cost estimate ─────────────────────────────────────────────────────────
    if not yes and fmt == "console":
        from .engine.cost_estimator import estimate_cost, format_estimate

        # Detect if any queries use llm_judge
        has_judge = any(
            (q.correctness and q.correctness.llm_judge)
            for q in spec.queries
            if q.correctness
        )
        judge_model = (spec.judge_config or {}).get("model", "claude-sonnet-4-6")
        # Strip provider prefix (e.g. "openai:gpt-4o-mini" -> "gpt-4o-mini")
        if ":" in judge_model:
            judge_model = judge_model.split(":", 1)[1]

        est = estimate_cost(
            num_queries=len(spec.queries),
            judge_model=judge_model,
            has_llm_judge=has_judge,
        )
        console.print(f"\n[dim]{format_estimate(est, len(spec.queries))}[/]")

        from rich.prompt import Confirm
        if not Confirm.ask("Proceed?", default=True):
            console.print("[yellow]Aborted.[/]")
            sys.exit(0)

    # ── Run queries in parallel ───────────────────────────────────────────────
    console.print(
        f"[bold blue]AgentCI v2[/] │ agent: [cyan]{spec.agent}[/] │ "
        f"queries: [cyan]{len(spec.queries)}[/] │ workers: [cyan]{workers}[/]"
    )
    if fmt in ("console", "github"):
        console.print("")

    try:
        traces = run_spec_parallel(spec, runner_fn, max_workers=workers)
    except Exception as e:  # noqa: BLE001
        console.print(f"[bold red]Infrastructure error:[/] {e}")
        sys.exit(2)

    if not traces:
        console.print("[bold red]Error:[/] No traces captured — runner may have failed for all queries.")
        sys.exit(1)

    # ── Load baselines (optional) ─────────────────────────────────────────────
    baselines: dict = {}
    baseline_path = Path(effective_baseline_dir)
    if baseline_path.exists() and baseline_path.is_dir():
        import glob
        from .baselines import load_baseline
        for f in glob.glob(str(baseline_path / "*.json")):
            try:
                b = load_baseline(f)
                if "trace" in b and "query" in b.get("trace", {}):
                    q = b["trace"]["query"]
                    from .models import Trace
                    baselines[q] = Trace.from_dict(b["trace"])
            except Exception:  # noqa: BLE001
                pass  # Skip malformed baseline files

    # ── Evaluate ──────────────────────────────────────────────────────────────
    try:
        results = evaluate_spec(spec, traces, baselines or None)
    except Exception as e:  # noqa: BLE001
        console.print(f"[bold red]Evaluation error:[/] {e}")
        sys.exit(2)
    except AgentCIError as e:
        _print_error_panel(e)
        sys.exit(2)
    except Exception as e:  # noqa: BLE001
        console.print(f"[bold red]Evaluation error:[/] {e}")
        sys.exit(2)

    # ── Report ───────────────────────────────────────────────────────────────
    exit_code = report_results(results, format=fmt, spec_file=config)
    sys.exit(exit_code)

@cli.command(name="eval")
@click.option('--config', '-c', default='agentci_spec.yaml',
              help='Path to agentci_spec.yaml', show_default=True)
@click.option('--tags', '-t', multiple=True, help='Only evaluate queries with these tags')
@click.option('--format', 'fmt',
              type=click.Choice(['console', 'github', 'json', 'prometheus']),
              default='console', show_default=True, help='Output format')
@click.option('--workers', '-w', default=4, show_default=True, type=int,
              help='Max parallel workers for query execution')
@click.option('--sample-ensemble', default=None, type=float,
              help='Fraction of queries to use ensemble judging (0.0-1.0, e.g. 0.2)')
def eval_cmd(config, tags, fmt, workers, sample_ensemble):
    """Run evaluation WITHOUT requiring golden baselines.

    Useful for correctness-only checks or absolute cost/path boundaries.
    Skips relative assertions like max_cost_multiplier and min_sequence_similarity.
    """
    from .loader import load_spec, filter_by_tags
    from .engine.reporter import report_results
    from .engine.parallel import run_spec_parallel, resolve_runner
    from .engine.runner import evaluate_spec
    from .exceptions import ConfigError, AgentCIError

    try:
        spec = load_spec(config)
    except AgentCIError as e:
        _print_error_panel(e)
        sys.exit(2)

    if tags:
        spec = filter_by_tags(spec, list(tags))
        if not spec.queries:
            console.print(f"[yellow]No queries match tags: {tags}[/]")
            sys.exit(0)

    if not spec.runner:
        console.print(
            "[yellow]ℹ[/] No [bold]runner[/] declared in spec. Add one to run locally:\n\n"
            "  [cyan]runner: \"myagent.run:run_agent\"[/]\n"
        )
        sys.exit(0)

    try:
        runner_fn = resolve_runner(spec.runner)
    except (ImportError, AttributeError, ValueError) as e:
        console.print(f"[bold red]Runner error:[/] {e}")
        sys.exit(2)

    if sample_ensemble is not None:
        if not (0.0 <= sample_ensemble <= 1.0):
            console.print("[bold red]--sample-ensemble must be between 0.0 and 1.0[/]")
            sys.exit(2)
        spec.judge_config = spec.judge_config or {}
        spec.judge_config["sample_ensemble"] = sample_ensemble

    console.print(
        f"[bold blue]AgentCI Eval[/] │ agent: [cyan]{spec.agent}[/] │ "
        f"queries: [cyan]{len(spec.queries)}[/] │ workers: [cyan]{workers}[/]"
    )
    if fmt in ("console", "github"):
        console.print("")

    try:
        traces = run_spec_parallel(spec, runner_fn, max_workers=workers)
    except Exception as e:
        console.print(f"[bold red]Infrastructure error:[/] {e}")
        sys.exit(2)

    if not traces:
        console.print("[bold red]Error:[/] No traces captured.")
        sys.exit(1)

    # Note: Explicitly passing None for baselines
    try:
        results = evaluate_spec(spec, traces, None)
    except Exception as e:
        console.print(f"[bold red]Evaluation error:[/] {e}")
        sys.exit(2)

    exit_code = report_results(results, format=fmt, spec_file=config)
    sys.exit(exit_code)




@cli.command(name="save")
@click.option('--agent', required=True, help='Agent identifier (matches spec agent field)')
@click.option('--version', required=True, help='Version tag, e.g. v1-broken or v2-fixed')
@click.option('--query', 'query_text', default='', help='Query text this baseline corresponds to')
@click.option('--config', '-c', default='agentci_spec.yaml', show_default=True)
@click.option('--baseline-dir', default=None, help='Override baseline directory')
@click.option('--force-save', is_flag=True,
              help='Bypass correctness precheck and save anyway')
@click.option('--trace-file', type=click.Path(exists=True), required=True,
              help='Path to trace JSON file to save as baseline')
def save_cmd(agent, version, query_text, config, baseline_dir, force_save, trace_file):
    """Save a trace as a versioned golden baseline.

    By default runs a correctness precheck against the spec before saving.
    Use --force-save to bypass (e.g. for intentional "broken" demo baselines).
    """
    import json
    from .loader import load_spec
    from .baselines import save_baseline
    from .models import Trace
    from .exceptions import ConfigError

    try:
        spec = load_spec(config)
    except ConfigError as e:
        console.print(f"[bold red]Config error:[/] {e}")
        sys.exit(2)

    try:
        trace_data = json.loads(open(trace_file).read())
        trace = Trace.model_validate(trace_data)
    except Exception as e:
        console.print(f"[bold red]Failed to load trace:[/] {e}")
        sys.exit(2)

    effective_dir = baseline_dir or spec.baseline_dir

    try:
        out_path = save_baseline(
            trace=trace,
            agent=agent,
            version=version,
            spec=spec,
            query_text=query_text,
            baseline_dir=effective_dir,
            force=force_save,
        )
        console.print(f"[green]✅ Saved baseline:[/] {out_path}")
    except ConfigError as e:
        console.print(f"[bold red]Config error:[/] {e}")
        if e.recovery_hint:
            console.print(f"  [yellow]Fix:[/] {e.recovery_hint}")
        sys.exit(1)
    except ValueError as e:
        console.print(f"[bold red]Precheck failed:[/] {e}")
        sys.exit(1)
    except Exception as e:
        console.print(f"[bold red]Error:[/] {e}")
        sys.exit(2)


@cli.command(name="baselines")
@click.option('--agent', required=True, help='Agent identifier')
@click.option('--config', '-c', default='agentci_spec.yaml', show_default=True)
@click.option('--baseline-dir', default=None)
def baselines_cmd(agent, config, baseline_dir):
    """List available baseline versions for an agent."""
    from .baselines import list_baselines
    from .loader import load_spec
    from .exceptions import ConfigError

    effective_dir = baseline_dir
    if not effective_dir:
        try:
            spec = load_spec(config)
            effective_dir = spec.baseline_dir
        except ConfigError:
            effective_dir = "./baselines"

    entries = list_baselines(agent, effective_dir)
    if not entries:
        console.print(f"[yellow]No baselines found for agent '{agent}' in {effective_dir}[/]")
        return

    table = Table(title=f"Baselines: {agent}")
    table.add_column("Version", style="cyan")
    table.add_column("Captured At")
    table.add_column("Query")
    table.add_column("Precheck")
    table.add_column("Spec Hash")

    for e in entries:
        meta = e.get("metadata", {})
        precheck = "[green]✅[/]" if meta.get("precheck_passed") else "[yellow]⚠ forced[/]"
        table.add_row(
            e["version"],
            e.get("captured_at", "—")[:19],  # Trim to datetime only
            (e.get("query") or "—")[:50],
            precheck,
            (meta.get("spec_hash") or "—")[:16],
        )

    console.print(table)


if __name__ == '__main__':
    cli()
