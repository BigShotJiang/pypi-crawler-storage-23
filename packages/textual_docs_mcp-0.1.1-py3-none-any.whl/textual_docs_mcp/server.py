"""FastMCP server entry point for textual-docs-mcp.

Start with::

    python -m textual_docs_mcp.server
    # or, after ``pip install -e .``:
    textual-docs-mcp

The server advertises the following tools to MCP clients:

* ``search_textual_docs``  – BM25 full-text search over all docs & examples.
* ``get_guide``            – Fetch a specific Textual guide by name.
* ``get_widget_docs``      – Fetch a specific widget's documentation.
* ``get_code_examples``    – Fetch runnable code examples by topic.
* ``list_guides``          – Catalogue of all guide/how-to topics.
* ``list_widgets``         – Catalogue of all widget documentation pages.
* ``get_textual_overview`` – High-level Textual framework introduction.
"""

from __future__ import annotations

import logging
import sys
from functools import lru_cache

from mcp.server.fastmcp import FastMCP

from textual_docs_mcp import __version__
from textual_docs_mcp.constants import (
    DEFAULT_SEARCH_RESULTS,
    MAX_SEARCH_RESULTS,
    SERVER_NAME,
)
from textual_docs_mcp.loader import load_entries
from textual_docs_mcp.search import BM25Search
from textual_docs_mcp.tools import (
    get_code_examples,
    get_guide,
    get_textual_overview,
    get_widget_docs,
    list_guides,
    list_widgets,
    search_textual_docs,
)

# ---------------------------------------------------------------------------
# Logging: use stderr so stdout stays clean for the MCP stdio protocol
# ---------------------------------------------------------------------------
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Lazy singleton – built once per process
# ---------------------------------------------------------------------------


@lru_cache(maxsize=1)
def _get_searcher() -> BM25Search:
    """Build and cache the BM25 search index (called once on first tool use)."""
    entries = load_entries()
    return BM25Search(entries)


# ---------------------------------------------------------------------------
# FastMCP server
# ---------------------------------------------------------------------------

mcp = FastMCP(
    SERVER_NAME,
    instructions=(
        "Use this server to retrieve up-to-date Textual TUI library documentation, "
        "code examples, widget references, CSS guides, and best practices. "
        "Start with `search_textual_docs` for topic discovery or `list_guides` / "
        "`list_widgets` for a full topic catalogue."
    ),
)


# ---------------------------------------------------------------------------
# Tool registrations
# ---------------------------------------------------------------------------


@mcp.tool()
def search_textual_docs_tool(
    query: str,
    category: str | None = None,
    max_results: int = DEFAULT_SEARCH_RESULTS,
) -> str:
    """Search across all Textual TUI documentation, guides, widgets, and code examples.

    This is the primary discovery tool. Use it when you need to find relevant
    documentation for a Textual concept, widget, CSS property, or task.

    Supported categories (optional filter):
    ``guide``, ``widget``, ``api``, ``event``, ``style``, ``css_type``,
    ``how_to``, ``example``, ``tutorial``, ``reference``, ``faq``.

    Examples of good queries:
    - "how to handle key events"
    - "DataTable row selection and sorting"
    - "CSS grid layout containers"
    - "reactive attribute update"
    - "async worker background tasks"

    Parameters
    ----------
    query:
        Natural-language question or keyword phrase.
    category:
        Optional document category to restrict search results.
    max_results:
        Number of results to return (1–20, default 5).
    """
    return search_textual_docs(
        _get_searcher(),
        query=query,
        category=category,
        max_results=min(max(1, max_results), MAX_SEARCH_RESULTS),
    )


@mcp.tool()
def get_guide_tool(guide_name: str) -> str:
    """Retrieve the full content of a specific Textual guide.

    Guides explain core framework concepts: layouts, events, reactivity,
    CSS, workers, screens, actions, animation, bindings, and more.

    Call ``list_guides_tool`` first if you are unsure which guide to fetch.

    Parameters
    ----------
    guide_name:
        Guide slug or human-readable name.  Examples:
        ``"layout"``, ``"events"``, ``"reactivity"``, ``"workers"``,
        ``"screens"``, ``"styles"``, ``"actions"``, ``"animation"``,
        ``"design"``, ``"input"``, ``"queries"``, ``"app"``.
    """
    return get_guide(_get_searcher(), guide_name=guide_name)


@mcp.tool()
def get_widget_docs_tool(widget_name: str) -> str:
    """Retrieve complete documentation for a specific Textual built-in widget.

    Covers widget purpose, constructor parameters, reactive attributes,
    CSS pseudo-classes, events / messages emitted, and usage examples.

    Call ``list_widgets_tool`` first if you are unsure of the exact name.

    Parameters
    ----------
    widget_name:
        Widget name or slug.  Examples:
        ``"Button"``, ``"DataTable"``, ``"Input"``, ``"TextArea"``,
        ``"ListView"``, ``"Tree"``, ``"Switch"``, ``"Select"``,
        ``"ProgressBar"``, ``"Tabs"``, ``"TabbedContent"``.
    """
    return get_widget_docs(_get_searcher(), widget_name=widget_name)


@mcp.tool()
def get_code_examples_tool(topic: str, max_results: int = 3) -> str:
    """Fetch runnable Textual Python code examples relevant to a topic.

    Examples are taken directly from the Textual repository and demonstrate
    idiomatic, production-ready usage of the framework.

    Parameters
    ----------
    topic:
        A topic, widget name, or concept.  Examples:
        ``"calculator"``, ``"DataTable sorting"``, ``"async workers"``,
        ``"CSS animation"``, ``"code browser"``, ``"markdown viewer"``.
    max_results:
        Number of example files to return (1–10, default 3).
    """
    return get_code_examples(_get_searcher(), topic=topic, max_results=max_results)


@mcp.tool()
def list_guides_tool() -> str:
    """List all available Textual guide topics, how-to articles, and tutorials.

    Returns the full catalogue with slugs and brief descriptions.
    Use a slug with ``get_guide_tool`` to retrieve the full content of a guide.
    """
    return list_guides(_get_searcher())


@mcp.tool()
def list_widgets_tool() -> str:
    """List all available Textual built-in widget documentation pages.

    Returns the widget catalogue with slugs and brief descriptions.
    Use a slug with ``get_widget_docs_tool`` to retrieve full documentation.
    """
    return list_widgets(_get_searcher())


@mcp.tool()
def get_textual_overview_tool() -> str:
    """Return a high-level overview and getting-started guide for the Textual framework.

    Covers what Textual is, its key architectural concepts, and the recommended
    path to building your first TUI application.  Ideal as the first call in a
    new session involving Textual development.
    """
    return get_textual_overview(_get_searcher())


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main() -> None:
    """Start the textual-docs-mcp server (stdio transport)."""
    logger.info("Starting %s v%s", SERVER_NAME, __version__)
    mcp.run()


if __name__ == "__main__":
    main()
