"""MCP tool implementations for the textual-docs-mcp server.

Each function in this module corresponds to an MCP tool registered in
:mod:`textual_docs_mcp.server`.  Functions are intentionally thin: they
delegate all retrieval/search logic to
:class:`~textual_docs_mcp.search.BM25Search`.
"""

from __future__ import annotations

import logging
from pathlib import Path

from textual_docs_mcp.constants import MAX_CONTENT_CHARS, MAX_SEARCH_RESULTS
from textual_docs_mcp.models import Category, DocEntry, SearchResult
from textual_docs_mcp.search import BM25Search

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Formatting helpers
# ---------------------------------------------------------------------------


def _relative_label(path: Path) -> str:
    """Return a short, human-readable relative path label."""
    parts = path.parts
    # Trim to the last three path components for brevity
    return "/".join(parts[-3:]) if len(parts) >= 3 else str(path)


def _format_search_results(query: str, results: list[SearchResult]) -> str:
    """Render a list of :class:`SearchResult` objects as Markdown text."""
    if not results:
        return (
            f"No results found for **{query}**.\n\n"
            "Try `list_guides` or `list_widgets` to browse available topics."
        )

    lines: list[str] = [f'## Search Results for "{query}"\n']
    for rank, result in enumerate(results, start=1):
        entry = result.entry
        label = _relative_label(entry.path)
        lines.append(f"### {rank}. {entry.title}")
        lines.append(f"**Category:** `{entry.category.value}` | **File:** `{label}`\n")
        lines.append(result.snippet)
        lines.append("\n---\n")

    return "\n".join(lines)


def _format_doc_entry(entry: DocEntry, max_chars: int = MAX_CONTENT_CHARS) -> str:
    """Render a :class:`DocEntry` as full Markdown content (truncated if needed)."""
    content = entry.content
    truncated = len(content) > max_chars
    if truncated:
        content = content[:max_chars]

    header = (
        f"# {entry.title}\n\n"
        f"**Category:** `{entry.category.value}` | **File:** `{_relative_label(entry.path)}`"
        "\n\n---\n\n"
    )
    footer = (
        "\n\n> *Content truncated. Use a more specific query to retrieve further sections.*"
        if truncated
        else ""
    )
    return header + content + footer


def _format_entry_list(entries: list[DocEntry], heading: str) -> str:
    """Format a list of :class:`DocEntry` objects as a Markdown catalogue."""
    if not entries:
        return f"No entries found for category: {heading}"

    lines: list[str] = [f"## {heading}\n"]
    for entry in entries:
        lines.append(f"- **{entry.title}** (`{entry.slug}`)")
        if entry.excerpt:
            first_line = entry.excerpt.splitlines()[0][:120]
            lines.append(f"  {first_line}")
    return "\n".join(lines)


def _not_found_message(name: str, category: Category, searcher: BM25Search) -> str:
    """Build a helpful "not found" message with similar entries."""
    available = searcher.list_by_category(category)
    suggestions = ", ".join(f"`{e.slug}`" for e in available[:10])
    return (
        f"No {category.value} documentation found for **{name!r}**.\n\n"
        f"Available {category.value}s: {suggestions}\n\n"
        "Use `list_guides` or `list_widgets` for a full catalogue."
    )


# ---------------------------------------------------------------------------
# Tool functions
# ---------------------------------------------------------------------------


def search_textual_docs(
    searcher: BM25Search,
    query: str,
    category: str | None = None,
    max_results: int = 5,
) -> str:
    """Search across all Textual documentation, guides, examples, and API references.

    This is the primary discovery tool.  Use it when you need to find relevant
    documentation for a concept, widget, CSS property, or task.

    Parameters
    ----------
    query:
        Natural-language query, e.g. ``"how to handle key events"``,
        ``"DataTable row selection"``, ``"CSS layout grid"``.
    category:
        Optional filter.  One of: ``guide``, ``widget``, ``api``,
        ``event``, ``style``, ``css_type``, ``how_to``, ``example``,
        ``tutorial``, ``reference``, ``faq``.
    max_results:
        Number of results to return (1–20, default 5).
    """
    cat: Category | None = None
    if category:
        try:
            cat = Category(category)
        except ValueError:
            valid = [c.value for c in Category]
            return f"Unknown category '{category}'. Valid options: {', '.join(valid)}"

    capped = min(max(1, max_results), MAX_SEARCH_RESULTS)
    results = searcher.search(query, max_results=capped, category=cat)
    return _format_search_results(query, results)


def get_guide(searcher: BM25Search, guide_name: str) -> str:
    """Retrieve the full content of a specific Textual guide.

    Guides explain core concepts such as layouts, events, reactivity,
    CSS, workers, screens, and more.

    Parameters
    ----------
    guide_name:
        Guide slug or human-readable name, e.g. ``"layout"``,
        ``"events"``, ``"reactivity"``, ``"workers"``, ``"screens"``,
        ``"styles"``, ``"actions"``, ``"animation"``, ``"design"``.
        Call ``list_guides`` first if you are unsure of the exact name.
    """
    entry = searcher.fuzzy_get(guide_name, category=Category.GUIDE)
    if entry is None:
        return _not_found_message(guide_name, Category.GUIDE, searcher)
    return _format_doc_entry(entry)


def get_widget_docs(searcher: BM25Search, widget_name: str) -> str:
    """Retrieve complete documentation for a specific Textual widget.

    Covers widget purpose, constructor options, CSS pseudo-classes,
    reactive attributes, messages/events it emits, and usage examples.

    Parameters
    ----------
    widget_name:
        Widget name or slug, e.g. ``"Button"``, ``"DataTable"``,
        ``"Input"``, ``"TextArea"``, ``"ListView"``, ``"Tree"``.
        Call ``list_widgets`` first if you are unsure of the exact name.
    """
    entry = searcher.fuzzy_get(widget_name, category=Category.WIDGET)
    if entry is None:
        return _not_found_message(widget_name, Category.WIDGET, searcher)
    return _format_doc_entry(entry)


def get_code_examples(
    searcher: BM25Search,
    topic: str,
    max_results: int = 3,
) -> str:
    """Find and return Textual Python code examples relevant to a topic.

    Examples are real, runnable scripts taken from the Textual repository and
    demonstrate idiomatic usage of the framework.

    Parameters
    ----------
    topic:
        Topic or widget name to search for, e.g. ``"calculator"``,
        ``"DataTable"``, ``"async workers"``, ``"CSS animation"``.
    max_results:
        Number of example files to return (1–10, default 3).
    """
    capped = min(max(1, max_results), 10)
    results = searcher.search(topic, max_results=capped, category=Category.EXAMPLE)

    if not results:
        return (
            f"No code examples found for **{topic}**.\n\n"
            "Try `search_textual_docs` with a broader query."
        )

    lines: list[str] = [f'## Code Examples for "{topic}"\n']
    for rank, result in enumerate(results, start=1):
        entry = result.entry
        label = _relative_label(entry.path)
        lines.append(f"### {rank}. `{label}`\n")
        lines.append(f"```python\n{entry.content[:MAX_CONTENT_CHARS // capped]}\n```\n")
        if len(entry.content) > MAX_CONTENT_CHARS // capped:
            lines.append("> *File truncated for brevity.*\n")

    return "\n".join(lines)


def list_guides(searcher: BM25Search) -> str:
    """List all available Textual guide topics.

    Returns the full catalogue of guides with their slugs and brief
    descriptions.  Use a slug with ``get_guide`` to fetch the full content.
    """
    guides = searcher.list_by_category(Category.GUIDE)
    tutorials = searcher.list_by_category(Category.TUTORIAL)
    how_tos = searcher.list_by_category(Category.HOW_TO)

    sections: list[str] = []
    if guides:
        sections.append(_format_entry_list(guides, "Guides"))
    if tutorials:
        sections.append(_format_entry_list(tutorials, "Tutorials"))
    if how_tos:
        sections.append(_format_entry_list(how_tos, "How-To Articles"))

    if not sections:
        return "No guides found in the index."

    return "\n\n".join(sections)


def list_widgets(searcher: BM25Search) -> str:
    """List all available Textual widget documentation pages.

    Returns the full widget catalogue with slugs and brief descriptions.
    Use a slug with ``get_widget_docs`` to fetch the full documentation.
    """
    widgets = searcher.list_by_category(Category.WIDGET)
    return _format_entry_list(widgets, "Textual Widgets")


def get_textual_overview(searcher: BM25Search) -> str:
    """Return a high-level overview of the Textual framework.

    Covers what Textual is, its key concepts, and where to start.
    Ideal as a first call when starting to build a Textual TUI application.
    """
    # Prefer getting_started guide
    entry = (
        searcher.get_by_slug("getting_started")
        or searcher.get_by_slug("getting-started")
        or searcher.fuzzy_get("getting started")
    )
    if entry:
        return _format_doc_entry(entry)

    # Fallback: run a broad search
    results = searcher.search("what is textual how to get started", max_results=3)
    if results:
        return _format_search_results("Textual overview / getting started", results)

    return (
        "**Textual** is a Python framework for building rich terminal (TUI) applications.\n\n"
        "Use `list_guides` to explore available documentation topics, or "
        "`search_textual_docs` to look up specific features."
    )
