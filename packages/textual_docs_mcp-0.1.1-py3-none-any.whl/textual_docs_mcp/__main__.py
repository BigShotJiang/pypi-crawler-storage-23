"""Allow running the server as ``python -m textual_docs_mcp``."""

from textual_docs_mcp.server import main

if __name__ == "__main__":
    main()
