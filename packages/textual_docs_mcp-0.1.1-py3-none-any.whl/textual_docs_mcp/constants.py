"""Package-wide runtime constants for textual-docs-mcp."""

from __future__ import annotations

SERVER_NAME = "textual-docs-mcp"
SERVER_VERSION = "0.1.0"

# Maximum characters returned in a single document fetch
MAX_CONTENT_CHARS: int = 32_000

# Maximum characters for a search result excerpt
EXCERPT_CHARS: int = 600

# Default number of search results returned by search tools
DEFAULT_SEARCH_RESULTS: int = 5
MAX_SEARCH_RESULTS: int = 20
