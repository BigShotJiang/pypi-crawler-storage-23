"""Cron scheduler for recurring workflow executions."""

from __future__ import annotations

import logging
import uuid
from datetime import datetime, timezone
from pathlib import Path

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from sandcastle.config import settings

logger = logging.getLogger(__name__)

# Global scheduler instance
_scheduler: AsyncIOScheduler | None = None


def get_scheduler() -> AsyncIOScheduler:
    """Get or create the global scheduler instance."""
    global _scheduler
    if _scheduler is None:
        _scheduler = AsyncIOScheduler()
    return _scheduler


async def start_scheduler() -> None:
    """Start the cron scheduler and register periodic jobs."""
    scheduler = get_scheduler()
    if not scheduler.running:
        scheduler.start()
        # Register approval timeout checker every 60 seconds
        from apscheduler.triggers.interval import IntervalTrigger

        scheduler.add_job(
            _check_approval_timeouts,
            trigger=IntervalTrigger(seconds=60),
            id="approval_timeout_checker",
            replace_existing=True,
            misfire_grace_time=30,
        )
        logger.info("Scheduler started")


async def stop_scheduler() -> None:
    """Stop the cron scheduler."""
    scheduler = get_scheduler()
    if scheduler.running:
        scheduler.shutdown(wait=False)
        logger.info("Scheduler stopped")


async def restore_schedules() -> None:
    """Restore enabled schedules from the database on startup."""
    try:
        from sqlalchemy import select

        from sandcastle.models.db import Schedule, async_session

        async with async_session() as session:
            stmt = select(Schedule).where(Schedule.enabled.is_(True))
            result = await session.execute(stmt)
            schedules = result.scalars().all()

        for schedule in schedules:
            try:
                add_schedule(
                    schedule_id=str(schedule.id),
                    cron_expression=schedule.cron_expression,
                    workflow_name=schedule.workflow_name,
                    input_data=schedule.input_data,
                )
            except ValueError as e:
                # Invalid cron expression - disable the schedule to prevent
                # repeated failures on every restart
                logger.warning(
                    f"Could not restore schedule {schedule.id}: {e}. "
                    "Disabling invalid schedule."
                )
                try:
                    async with async_session() as dsession:
                        bad = await dsession.get(Schedule, schedule.id)
                        if bad:
                            bad.enabled = False
                            await dsession.commit()
                except Exception as de:
                    logger.error(
                        f"Failed to disable invalid schedule {schedule.id}: {de}"
                    )
            except Exception as e:
                logger.warning(f"Could not restore schedule {schedule.id}: {e}")

        logger.info(f"Restored {len(schedules)} schedule(s) from database")
    except Exception as e:
        logger.warning(f"Could not restore schedules from database: {e}")


def _load_workflow_yaml(workflow_name: str) -> str:
    """Load workflow YAML content from the workflows directory by name."""
    workflows_dir = Path(settings.workflows_dir).resolve()
    for candidate in [
        workflows_dir / f"{workflow_name}.yaml",
        workflows_dir / workflow_name,
    ]:
        resolved = candidate.resolve()
        if not resolved.is_relative_to(workflows_dir):
            raise ValueError(
                f"Path traversal detected in workflow_name: {workflow_name!r}"
            )
        if resolved.exists() and resolved.is_file():
            return resolved.read_text()
    raise FileNotFoundError(f"Workflow '{workflow_name}' not found in {workflows_dir}")


async def _run_scheduled_workflow(
    schedule_id: str,
    workflow_name: str,
    input_data: dict,
) -> None:
    """Job function: enqueue a workflow run from a schedule trigger."""
    from sandcastle.models.db import Run, RunStatus, Schedule, async_session
    from sandcastle.queue.worker import enqueue_workflow

    run_id = str(uuid.uuid4())
    logger.info(f"Schedule '{schedule_id}' triggered: creating run {run_id}")

    try:
        workflow_yaml = _load_workflow_yaml(workflow_name)

        # Load tenant context and budget from the schedule record
        tenant_id = None
        max_cost_usd = None
        async with async_session() as session:
            schedule = await session.get(
                Schedule, uuid.UUID(schedule_id)
            )
            if not schedule:
                logger.warning(
                    f"Schedule '{schedule_id}' no longer exists in database, "
                    "skipping execution"
                )
                return
            if not schedule.enabled:
                logger.info(
                    f"Schedule '{schedule_id}' is disabled, skipping execution"
                )
                return
            tenant_id = schedule.tenant_id

            # Resolve tenant budget from API key if available
            if tenant_id:
                from sqlalchemy import select

                from sandcastle.models.db import ApiKey

                stmt = select(ApiKey.max_cost_per_run_usd).where(
                    ApiKey.tenant_id == tenant_id,
                    ApiKey.is_active.is_(True),
                ).limit(1)
                max_cost_usd = await session.scalar(stmt)

        # Create the run record with tenant context
        async with async_session() as session:
            db_run = Run(
                id=uuid.UUID(run_id),
                workflow_name=workflow_name,
                status=RunStatus.QUEUED,
                input_data=input_data,
                tenant_id=tenant_id,
                max_cost_usd=max_cost_usd,
            )
            session.add(db_run)

            # Update schedule's last_run_id
            schedule = await session.get(
                Schedule, uuid.UUID(schedule_id)
            )
            if schedule:
                schedule.last_run_id = uuid.UUID(run_id)

            await session.commit()

        # Enqueue the job (budget is read from DB by worker)
        await enqueue_workflow(workflow_yaml, input_data, run_id)
        logger.info(f"Schedule '{schedule_id}' enqueued run {run_id}")

    except Exception as e:
        logger.error(
            f"Schedule '{schedule_id}' failed to create/enqueue run: {e}"
        )
        # Mark the run as FAILED so it doesn't stay stuck in QUEUED
        try:
            from sandcastle.models.db import Run, RunStatus, async_session

            async with async_session() as session:
                stuck_run = await session.get(Run, uuid.UUID(run_id))
                if stuck_run and stuck_run.status == RunStatus.QUEUED:
                    stuck_run.status = RunStatus.FAILED
                    stuck_run.error = f"Schedule enqueue failed: {e}"
                    stuck_run.completed_at = datetime.now(timezone.utc)
                    await session.commit()
                    logger.info(f"Marked stuck run {run_id} as FAILED")
        except Exception as cleanup_err:
            logger.error(f"Failed to mark run {run_id} as FAILED: {cleanup_err}")


async def _check_approval_timeouts() -> None:
    """Check for timed-out approval requests and apply on_timeout action."""
    from datetime import timezone

    from sqlalchemy import select

    from sandcastle.models.db import (
        ApprovalRequest,
        ApprovalStatus,
        Run,
        RunStatus,
        async_session,
    )

    now = datetime.now(timezone.utc)

    try:
        # Fetch only IDs to avoid stale object references across sessions
        async with async_session() as session:
            stmt = select(ApprovalRequest.id).where(
                ApprovalRequest.status == ApprovalStatus.PENDING,
                ApprovalRequest.timeout_at.isnot(None),
                ApprovalRequest.timeout_at <= now,
            )
            result = await session.execute(stmt)
            timed_out_ids = [row[0] for row in result.all()]

        processed = 0
        for approval_id in timed_out_ids:
            try:
                async with async_session() as session:
                    # Re-fetch with fresh state to avoid TOCTOU race
                    ap = await session.get(ApprovalRequest, approval_id)
                    if not ap or ap.status != ApprovalStatus.PENDING:
                        continue

                    logger.info(
                        f"Approval {ap.id} for step '{ap.step_id}' timed out "
                        f"(on_timeout={ap.on_timeout})"
                    )

                    ap.status = ApprovalStatus.TIMED_OUT
                    ap.resolved_at = now

                    run = await session.get(Run, ap.run_id)
                    if not run:
                        logger.warning(
                            f"Approval {ap.id} references non-existent run "
                            f"{ap.run_id}, marking as timed out"
                        )
                        await session.commit()
                        processed += 1
                        continue

                    run_status = run.status.value if hasattr(run.status, "value") else run.status
                    if run_status in ("completed", "failed", "cancelled", "budget_exceeded"):
                        logger.info(
                            f"Approval {ap.id} for already-finished run "
                            f"(status={run_status}), marking as timed out only"
                        )
                        await session.commit()
                        processed += 1
                        continue

                    on_timeout = ap.on_timeout
                    if on_timeout == "skip":
                        await session.commit()
                        try:
                            from sandcastle.api.routes import _resume_after_approval

                            await _resume_after_approval(ap, output_data=None)
                        except Exception as e:
                            logger.error(f"Failed to resume after timeout skip: {e}")
                    else:
                        run.status = RunStatus.FAILED
                        run.completed_at = now
                        run.error = f"Approval timed out at step '{ap.step_id}'"
                        await session.commit()

                    processed += 1

            except Exception as e:
                logger.error(f"Error processing approval timeout {approval_id}: {e}")

        if processed:
            logger.info(f"Processed {processed} timed-out approval(s)")

    except Exception as e:
        logger.error(f"Error checking approval timeouts: {e}")


def add_schedule(
    schedule_id: str,
    cron_expression: str,
    workflow_name: str,
    input_data: dict | None = None,
) -> None:
    """Register a cron job for a workflow schedule."""
    if not cron_expression or not cron_expression.strip():
        raise ValueError("cron_expression must not be empty")
    if not workflow_name or not workflow_name.strip():
        raise ValueError("workflow_name must not be empty")

    scheduler = get_scheduler()

    try:
        trigger = CronTrigger.from_crontab(cron_expression)
    except ValueError as e:
        raise ValueError(f"Invalid cron expression '{cron_expression}': {e}")

    scheduler.add_job(
        _run_scheduled_workflow,
        trigger=trigger,
        id=schedule_id,
        args=[schedule_id, workflow_name, input_data or {}],
        replace_existing=True,
        misfire_grace_time=60,
    )

    logger.info(f"Schedule '{schedule_id}' registered: {cron_expression} for '{workflow_name}'")


def remove_schedule(schedule_id: str) -> bool:
    """Remove a scheduled job."""
    scheduler = get_scheduler()
    try:
        scheduler.remove_job(schedule_id)
        logger.info(f"Schedule '{schedule_id}' removed")
        return True
    except Exception:
        logger.warning(f"Schedule '{schedule_id}' not found for removal")
        return False


def list_schedules() -> list[dict]:
    """List all active scheduled jobs."""
    scheduler = get_scheduler()
    jobs = []
    for job in scheduler.get_jobs():
        jobs.append({
            "id": job.id,
            "name": job.name,
            "next_run_time": str(job.next_run_time) if job.next_run_time else None,
            "trigger": str(job.trigger),
        })
    return jobs
