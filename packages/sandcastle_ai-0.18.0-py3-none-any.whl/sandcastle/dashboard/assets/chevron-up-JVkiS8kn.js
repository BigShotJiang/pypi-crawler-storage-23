import{c as o}from"./index-1fzZ9Mnj.js";const c=[["path",{d:"m18 15-6-6-6 6",key:"153udz"}]],n=o("chevron-up",c);export{n as C};
