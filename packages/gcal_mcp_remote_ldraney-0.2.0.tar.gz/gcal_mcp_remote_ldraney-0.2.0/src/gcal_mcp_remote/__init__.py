"""Remote MCP connector wrapping gcal-mcp with Google OAuth 2.0 over Streamable HTTP."""
