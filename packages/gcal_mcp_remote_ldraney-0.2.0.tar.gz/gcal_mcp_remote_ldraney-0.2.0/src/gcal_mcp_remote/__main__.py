"""Entry point for `python -m gcal_mcp_remote`."""

from gcal_mcp_remote.server import main

main()
