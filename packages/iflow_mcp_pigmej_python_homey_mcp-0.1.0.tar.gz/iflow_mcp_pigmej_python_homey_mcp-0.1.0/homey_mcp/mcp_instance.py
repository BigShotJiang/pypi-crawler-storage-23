"""Shared MCP instance for all tool modules."""

from fastmcp import FastMCP

# Shared MCP server instance
mcp = FastMCP("HomeyPro")