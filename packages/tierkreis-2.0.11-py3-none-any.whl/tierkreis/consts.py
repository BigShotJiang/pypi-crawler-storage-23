from pathlib import Path


PACKAGE_PATH = Path(__file__).parent.parent
TESTS_PATH = PACKAGE_PATH / "tests"
TKR_DIR_KEY = "TKR_DIR"
WORKERS_DIR = PACKAGE_PATH / ".." / "tierkreis_workers"
TKR_LOG_LEVEL_KEY = "TKR_LOG_LEVEL"
TKR_LOG_FMT_KEY = "TKR_LOG_FORMAT"
TKR_DATE_FMT_KEY = "TKR_DATE_FORMAT"
WORKER_CACHE = Path.home() / ".tierkreis" / "workers"
