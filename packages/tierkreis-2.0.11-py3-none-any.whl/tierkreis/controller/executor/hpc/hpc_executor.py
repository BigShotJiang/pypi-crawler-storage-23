import logging
import subprocess
from pathlib import Path
from tempfile import NamedTemporaryFile
from typing import Callable, Protocol

from tierkreis.consts import TKR_DIR_KEY
from tierkreis.controller.executor.commands import add_std_handlers
from tierkreis.controller.executor.hpc.job_spec import JobSpec
from tierkreis.controller.storage.data import ExecutorDebugData
from tierkreis.exceptions import TierkreisError

logger = logging.getLogger(__name__)


class HPCExecutor(Protocol):
    launchers_path: Path | None
    logs_path: Path
    errors_path: Path
    spec: JobSpec
    script_fn: Callable[[JobSpec], str]
    command: str

    def job_id(self, std_out: str) -> str: ...


def generate_script(
    template_fn: Callable[[JobSpec], str], spec: JobSpec, path: Path
) -> None:
    with open(path, "w+", encoding="utf-8") as fh:
        fh.write(template_fn(spec))


def run_hpc_executor(
    executor: HPCExecutor, launcher_name: str, worker_call_args_path: Path
) -> ExecutorDebugData:
    logger.info("START %s %s", launcher_name, worker_call_args_path)

    spec = executor.spec.model_copy()
    if executor.launchers_path:
        spec.command = f"cd {executor.launchers_path}/{launcher_name} && {spec.command}"

    spec.command += " " + str(worker_call_args_path)
    spec.command = add_std_handlers(
        executor.logs_path, executor.errors_path, spec.command
    )

    submission_cmd = [executor.command]
    if spec.include_no_check_directory_flag:
        submission_cmd += ["--no-check-directory"]

    if TKR_DIR_KEY not in spec.environment:  # User can override by setting TKR_DIR
        spec.environment[TKR_DIR_KEY] = str(executor.logs_path.parent.parent)

    with NamedTemporaryFile(
        mode="w+",
        delete=True,
        suffix=".sh",
        prefix=f"{spec.job_name}-",
    ) as script_file:
        generate_script(executor.script_fn, spec, Path(script_file.name))
        submission_cmd.append(script_file.name)

        process = subprocess.run(
            submission_cmd,
            start_new_session=True,
            capture_output=True,
            universal_newlines=True,
        )

    with open(executor.logs_path, "a+") as fh:
        fh.write(process.stdout)

    with open(executor.errors_path, "a+") as fh:
        fh.write(process.stdout)

    if process.returncode != 0:
        with open(executor.errors_path, "a") as efh:
            efh.write("Error from script")
            efh.write(process.stderr)
        print(process.stderr)
        print("\n\nsubmission script\n\n")
        print(executor.script_fn(spec))

        raise TierkreisError(f"Executor failed with return code {process.returncode}")

    return ExecutorDebugData(
        executor=str(executor.__class__),
        launch_command=" ".join(submission_cmd),
        job_id=executor.job_id(process.stdout),  # TODO parse JOB ID somehow
    )
