import os
from pathlib import Path

BODY_PORT = "body"
PACKAGE_PATH = Path(os.path.dirname(os.path.realpath(__file__)))
