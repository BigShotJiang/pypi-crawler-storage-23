class TierkreisError(Exception):
    """An error thrown in the Tierkreis library."""
