"""
Reno AI SDK — Official Python client for the Reno API.
"""

from .client import Reno, Conversation
from .exceptions import (
    RenoError,
    RenoConnectionError,
    RenoTimeoutError,
    RenoValidationError,
)
from .models import Completion, Choice, Usage, StreamChunk

__version__ = "0.1.6"
__author__ = "Sazuke Hiroshima"
__email__ = "sazuketech12@gmail.com"
__license__ = "MIT"

__all__ = [
    # Client
    "Reno",
    "Conversation",
    # Exceptions
    "RenoError",
    "RenoConnectionError",
    "RenoTimeoutError",
    "RenoValidationError",
    # Models
    "Completion",
    "Choice",
    "Usage",
    "StreamChunk",
]
