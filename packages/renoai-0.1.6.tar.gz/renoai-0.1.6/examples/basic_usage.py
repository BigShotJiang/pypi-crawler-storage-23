"""
Basic usage example for Reno AI SDK
"""

from renoai import Reno, RenoError

def main():
    # Initialize client
    api_key = "reno_sk_your_api_key_here"  # Replace with your actual API key
    client = Reno(api_key=api_key)
    
    try:
        # Simple question
        print("=== Simple Question ===")
        answer = client.ask("What is Python?")
        print(answer)
        print()
        
        # With system message
        print("=== With System Message ===")
        answer = client.ask(
            prompt="Explain recursion",
            system="You are a computer science professor. Be concise."
        )
        print(answer)
        print()
        
        # Chat with history
        print("=== Chat with History ===")
        messages = [
            {"role": "system", "content": "You are a helpful assistant."},
            {"role": "user", "content": "What's the capital of France?"},
        ]
        response = client.chat(messages)
        print(response.text)
        print(f"Model: {response.model}")
        print(f"Tokens: {response.usage.total_tokens}")
        print()
        
    except RenoError as e:
        print(f"Error: {e}")
        print(e.user_friendly())
    finally:
        client.close()


if __name__ == "__main__":
    main()
