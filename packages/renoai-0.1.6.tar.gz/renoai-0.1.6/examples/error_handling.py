"""
Error handling example for Reno AI SDK
"""

from renoai import Reno, RenoError, RenoTimeoutError, RenoConnectionError

def main():
    # Initialize client with short timeout for demonstration
    api_key = "reno_sk_your_api_key_here"  # Replace with your actual API key
    
    print("=== Testing Error Handling ===\n")
    
    # Example 1: Invalid API key
    print("1. Testing invalid API key:")
    try:
        client = Reno(api_key="reno_sk_invalid_key")
        client.ask("Hello")
    except RenoError as e:
        print(f"   Error Code: {e.code}")
        print(f"   Message: {e.message}")
        print(f"   User-friendly:\n   {e.user_friendly()}")
        print()
    
    # Example 2: Connection error (invalid URL)
    print("2. Testing connection error:")
    try:
        client = Reno(
            api_key=api_key,
            base_url="http://invalid-url-that-does-not-exist.com"
        )
        client.ask("Hello")
    except RenoConnectionError as e:
        print(f"   Connection failed: {e.message}")
        print()
    
    # Example 3: Timeout
    print("3. Testing timeout (1 second):")
    try:
        client = Reno(api_key=api_key, timeout=1)
        # This might timeout if the server is slow
        client.ask("Write a very long essay about the history of computing")
    except RenoTimeoutError as e:
        print(f"   Timeout: {e.message}")
        print()
    except RenoError as e:
        print(f"   Completed successfully or different error: {e.message}")
        print()
    
    # Example 4: Generic error handling
    print("4. Generic error handling:")
    try:
        client = Reno(api_key=api_key)
        # Example of catching all Reno errors
        response = client.ask("Hello!")
        print(f"   Success: {response}")
    except RenoError as e:
        print(f"   Any Reno error caught: [{e.code}] {e.message}")
        if e.details:
            print(f"   Details: {e.details}")
        print()
    
    print("=== Error Handling Demo Complete ===")


if __name__ == "__main__":
    main()
