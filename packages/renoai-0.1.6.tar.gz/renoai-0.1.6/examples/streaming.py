"""
Streaming response example for Reno AI SDK
"""

from renoai import Reno, RenoError

def main():
    # Initialize client
    api_key = "reno_sk_your_api_key_here"  # Replace with your actual API key
    
    with Reno(api_key=api_key) as client:
        try:
            print("=== Streaming Response ===")
            print("Asking: 'Write a short poem about Python programming'\n")
            
            messages = [
                {"role": "user", "content": "Write a short poem about Python programming"}
            ]
            
            # Stream the response
            full_response = ""
            for chunk in client.chat(messages, stream=True):
                if chunk.delta:
                    print(chunk.delta, end="", flush=True)
                    full_response += chunk.delta
            
            print("\n\n=== Stream Complete ===")
            print(f"Total characters received: {len(full_response)}")
            
        except RenoError as e:
            print(f"\nError occurred: {e}")
            print(e.user_friendly())


if __name__ == "__main__":
    main()
