"""
Setup configuration for renoai package.
This file exists for backwards compatibility.
Modern installations should use pyproject.toml.
"""

from setuptools import setup

# Configuration is in pyproject.toml
setup()
