# Contributing to MCP YAML Server

Thank you for your interest in contributing! This document provides guidelines and instructions for contributing.

## 🚀 Getting Started

### Prerequisites

- Python 3.10 or higher
- Git
- pip

### Development Setup

```bash
# Clone the repository
git clone https://github.com/labtessi/mcp-yaml-server.git
cd mcp-yaml-server

# Create a virtual environment
python -m venv .venv
source .venv/bin/activate  # On Windows: .venv\Scripts\activate

# Install in development mode with all dependencies
pip install -e ".[dev]"

# Install pre-commit hooks (optional but recommended)
pre-commit install
```

## 📁 Project Structure

```
mcp-yaml-server/
├── src/
│   └── mcp_yaml_generator/
│       ├── __init__.py
│       ├── __main__.py          # CLI entry points
│       ├── client/
│       │   ├── auth.py          # Authentication strategies
│       │   └── http_client.py   # HTTP client implementation
│       ├── config/
│       │   ├── parser.py        # YAML parsing and validation
│       │   └── schema.py        # Pydantic models
│       ├── generator/
│       │   ├── metadata.py      # Tool metadata generation
│       │   └── tool_factory.py  # Tool function generation
│       └── server/
│           └── mcp_server.py    # MCP server setup
├── tests/                       # Test files
├── examples/                    # Example configurations
├── specs/                       # Specifications and docs
├── pyproject.toml              # Project configuration
├── README.md
├── CHANGELOG.md
├── CONTRIBUTING.md
└── LICENSE
```

## 🧪 Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=mcp_yaml_generator --cov-report=html

# Run specific test file
pytest tests/test_parser.py

# Run specific test
pytest tests/test_parser.py::test_parse_yaml_config
```

## 🔍 Code Quality

### Linting

```bash
# Run ruff linter
ruff check src/ tests/

# Auto-fix issues
ruff check --fix src/ tests/
```

### Formatting

```bash
# Format code with black
black src/ tests/

# Check formatting without changes
black --check src/ tests/
```

### Type Checking

```bash
# Run mypy
mypy src/
```

### All Checks

```bash
# Run all checks before committing
ruff check src/ tests/
black --check src/ tests/
mypy src/
pytest
```

## 📝 Code Style Guidelines

### General

- Follow PEP 8 style guidelines
- Use type hints for all function signatures
- Write docstrings for all public functions and classes
- Keep functions focused and under 50 lines when possible
- Use descriptive variable and function names

### Docstrings

Use Google-style docstrings:

```python
def function_name(param1: str, param2: int) -> dict[str, Any]:
    """Short description of the function.
    
    Longer description if needed, explaining the function's
    behavior in more detail.
    
    Args:
        param1: Description of param1.
        param2: Description of param2.
        
    Returns:
        Description of return value.
        
    Raises:
        ValueError: When param1 is empty.
        
    Example:
        >>> result = function_name("test", 42)
        >>> print(result)
        {'key': 'value'}
    """
```

### Imports

```python
# Standard library
import logging
from pathlib import Path
from typing import Any, Optional

# Third-party
import httpx
from pydantic import BaseModel

# Local
from .schema import EndpointConfig
from ..client.http_client import HTTPClient
```

## 🔄 Pull Request Process

### Before Submitting

1. **Create an issue** describing the bug or feature (if one doesn't exist)
2. **Fork the repository** and create a feature branch
3. **Write tests** for your changes
4. **Run all checks** (linting, formatting, type checking, tests)
5. **Update documentation** if needed
6. **Update CHANGELOG.md** with your changes

### Branch Naming

- `feature/description` - New features
- `fix/description` - Bug fixes
- `docs/description` - Documentation changes
- `refactor/description` - Code refactoring

### Commit Messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
type(scope): description

[optional body]

[optional footer]
```

Types:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Formatting (no code change)
- `refactor`: Code refactoring
- `test`: Adding tests
- `chore`: Maintenance

Examples:
```
feat(auth): add OAuth2 authentication support
fix(upload): handle empty file parameters
docs(readme): add Docker deployment section
```

### Pull Request Template

```markdown
## Description
Brief description of the changes.

## Related Issue
Fixes #123

## Type of Change
- [ ] Bug fix
- [ ] New feature
- [ ] Breaking change
- [ ] Documentation update

## Checklist
- [ ] Tests pass locally
- [ ] Code follows style guidelines
- [ ] Documentation updated
- [ ] CHANGELOG.md updated
```

## 🐛 Reporting Bugs

When reporting bugs, please include:

1. **Python version** (`python --version`)
2. **Package version** (`pip show mcp-yaml-server`)
3. **Operating system**
4. **Minimal reproducible example**
5. **Full error traceback**
6. **Expected vs actual behavior**

## 💡 Feature Requests

When requesting features, please include:

1. **Use case** - Why do you need this feature?
2. **Proposed solution** - How should it work?
3. **Alternatives considered** - Other approaches you've thought of
4. **Example configuration** - How would it look in YAML?

## 📚 Adding Examples

When adding example configurations:

1. Place in `examples/` directory
2. Use descriptive filename: `service-name-config.yaml`
3. Include comments explaining each section
4. Test with `mcp-yaml-server --dry-run examples/your-example.yaml`
5. Update README.md if it's a notable example

## 🔐 Security

- Never commit credentials or API keys
- Use `${ENV_VAR}` syntax for sensitive values
- Report security vulnerabilities privately to the maintainers

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

## 🙏 Thank You!

Your contributions make this project better for everyone. Thank you for taking the time to contribute!
