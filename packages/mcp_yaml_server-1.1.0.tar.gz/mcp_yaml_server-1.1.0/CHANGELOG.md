# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.1.0] - 2026-03-03

### Added
- **Remote file upload support**: File parameters now work with remote MCP servers by reading file content on the client side before transmission
- **Base64 file content support**: Accept base64-encoded file content and data URIs for programmatic file uploads
- **HTTP transport modes**: Added `--transport` flag with support for `stdio`, `http`, and `streamable-http` transports
- **Stateless HTTP mode**: Better compatibility with SSE/streaming MCP clients like GitHub Copilot
- **Docker support**: Added Dockerfile and docker-compose examples for containerized deployment
- **HTTP/2 support**: Added `httpx[http2]` dependency for improved performance

### Changed
- Renamed package from `mcp-yaml-generator` to `mcp-yaml-server` for clarity
- Improved error messages for file upload failures
- Enhanced parameter validation with helpful error messages

### Fixed
- Fixed "File not found" errors when using remote MCP servers with local file paths
- Fixed Ctrl+C shutdown handling for graceful server termination
- Fixed FastMCP 2.x compatibility issues with tool registration

## [1.0.0] - 2026-01-14

### Added
- Initial release
- YAML-based configuration for MCP tools
- Support for GET, POST, PUT, PATCH, DELETE HTTP methods
- Authentication: API key, Bearer token, Basic auth, custom headers
- File upload support with multipart/form-data
- Response handling with JSONPath extraction
- Environment variable substitution with `${VAR}` syntax
- CLI tools: `mcp-yaml-server` and `mcp-yaml-validate`
- Comprehensive error handling and validation
- Debug mode with verbose logging
- Dry-run mode for configuration validation

[1.1.0]: https://github.com/labtessi/mcp-yaml-server/compare/v1.0.0...v1.1.0
[1.0.0]: https://github.com/labtessi/mcp-yaml-server/releases/tag/v1.0.0
