"""Authentication strategies for HTTP requests."""

import re
from typing import Optional

import httpx

from ..config.schema import AuthConfig, AuthType


def mask_credential(value: str) -> str:
    """
    Mask sensitive credential values for logging.
    
    Args:
        value: Credential string to mask
        
    Returns:
        Masked string (shows first/last 2 chars, rest as asterisks)
        
    Example:
        >>> mask_credential("secret_token_12345")
        'se***45'
    """
    if len(value) <= 4:
        return "***"
    return f"{value[:2]}***{value[-2:]}"


def apply_api_key_header(
    headers: dict[str, str],
    header_name: str,
    token: str,
) -> dict[str, str]:
    """
    Apply API key authentication as HTTP header.
    
    Args:
        headers: Existing headers dictionary
        header_name: Name of the header to add
        token: API key token value
        
    Returns:
        Headers dictionary with API key added
    """
    headers[header_name] = token
    return headers


def apply_api_key_query(
    url: str,
    query_param: str,
    token: str,
) -> str:
    """
    Apply API key authentication as query parameter.
    
    Args:
        url: Base URL (may already have query params)
        query_param: Name of the query parameter
        token: API key token value
        
    Returns:
        URL with API key query parameter added
    """
    separator = "&" if "?" in url else "?"
    return f"{url}{separator}{query_param}={token}"


def apply_bearer_token(
    headers: dict[str, str],
    token: str,
) -> dict[str, str]:
    """
    Apply bearer token authentication.
    
    Args:
        headers: Existing headers dictionary
        token: Bearer token value
        
    Returns:
        Headers dictionary with Authorization header
    """
    headers["Authorization"] = f"Bearer {token}"
    return headers


def apply_basic_auth(
    headers: dict[str, str],
    username: str,
    password: str,
) -> dict[str, str]:
    """
    Apply HTTP Basic authentication.
    
    Args:
        headers: Existing headers dictionary
        username: Username
        password: Password
        
    Returns:
        Headers dictionary with Authorization header
    """
    import base64
    
    credentials = f"{username}:{password}"
    encoded = base64.b64encode(credentials.encode()).decode()
    headers["Authorization"] = f"Basic {encoded}"
    return headers


def apply_custom_headers(
    headers: dict[str, str],
    custom_headers: dict[str, str],
) -> dict[str, str]:
    """
    Apply custom authentication headers.
    
    Args:
        headers: Existing headers dictionary
        custom_headers: Custom headers to add
        
    Returns:
        Headers dictionary with custom headers merged
    """
    headers.update(custom_headers)
    return headers


class AuthStrategy:
    """
    Authentication strategy that applies auth to requests.
    
    Factory pattern for different auth types.
    """
    
    def __init__(self, auth_config: Optional[AuthConfig] = None):
        """
        Initialize auth strategy.
        
        Args:
            auth_config: Authentication configuration (None for no auth)
        """
        self.auth_config = auth_config
    
    def apply_to_headers(self, headers: dict[str, str]) -> dict[str, str]:
        """
        Apply authentication to request headers.
        
        Args:
            headers: Existing headers dictionary
            
        Returns:
            Headers with authentication applied
        """
        if not self.auth_config:
            return headers
        
        auth_type = self.auth_config.type
        
        if auth_type == AuthType.API_KEY:
            if not self.auth_config.api_key:
                raise ValueError("API key configuration missing")
            
            # T046: API key in header
            if self.auth_config.api_key.header_name:
                return apply_api_key_header(
                    headers,
                    self.auth_config.api_key.header_name,
                    self.auth_config.api_key.token,
                )
            # T047: API key in query - handled separately in apply_to_url
            return headers
        
        elif auth_type == AuthType.BEARER:
            # T048: Bearer token
            if not self.auth_config.bearer:
                raise ValueError("Bearer token configuration missing")
            return apply_bearer_token(headers, self.auth_config.bearer.token)
        
        elif auth_type == AuthType.BASIC:
            # T049: Basic auth
            if not self.auth_config.basic:
                raise ValueError("Basic auth configuration missing")
            return apply_basic_auth(
                headers,
                self.auth_config.basic.username,
                self.auth_config.basic.password,
            )
        
        elif auth_type == AuthType.CUSTOM:
            # T050: Custom headers
            if not self.auth_config.custom:
                raise ValueError("Custom headers configuration missing")
            return apply_custom_headers(headers, self.auth_config.custom.headers)
        
        return headers
    
    def apply_to_url(self, url: str) -> str:
        """
        Apply authentication to URL (for query param auth).
        
        Args:
            url: Request URL
            
        Returns:
            URL with authentication applied
        """
        if not self.auth_config:
            return url
        
        # T047: API key in query parameter
        if self.auth_config.type == AuthType.API_KEY:
            if self.auth_config.api_key and self.auth_config.api_key.query_param:
                return apply_api_key_query(
                    url,
                    self.auth_config.api_key.query_param,
                    self.auth_config.api_key.token,
                )
        
        return url
    
    def get_safe_description(self) -> str:
        """
        Get safe description of auth for logging (credentials masked).
        
        Returns:
            Human-readable auth description with masked credentials
        """
        if not self.auth_config:
            return "No authentication"
        
        auth_type = self.auth_config.type
        
        if auth_type == AuthType.API_KEY and self.auth_config.api_key:
            token = mask_credential(self.auth_config.api_key.token)
            if self.auth_config.api_key.header_name:
                return f"API Key (header: {self.auth_config.api_key.header_name}, token: {token})"
            elif self.auth_config.api_key.query_param:
                return f"API Key (query: {self.auth_config.api_key.query_param}, token: {token})"
        
        elif auth_type == AuthType.BEARER and self.auth_config.bearer:
            token = mask_credential(self.auth_config.bearer.token)
            return f"Bearer token: {token}"
        
        elif auth_type == AuthType.BASIC and self.auth_config.basic:
            user = self.auth_config.basic.username
            return f"Basic auth: {user}:***"
        
        elif auth_type == AuthType.CUSTOM:
            return "Custom headers"
        
        return f"Unknown auth type: {auth_type}"


def create_auth_strategy(auth_config: Optional[AuthConfig] = None) -> AuthStrategy:
    """
    Factory function to create auth strategy.
    
    Args:
        auth_config: Authentication configuration
        
    Returns:
        AuthStrategy instance
    """
    return AuthStrategy(auth_config)
