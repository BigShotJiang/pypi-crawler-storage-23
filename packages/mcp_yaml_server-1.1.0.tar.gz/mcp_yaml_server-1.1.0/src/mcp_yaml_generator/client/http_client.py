"""HTTP client for making API requests with parameter handling."""

import logging
import re
from typing import Any, Optional
from urllib.parse import urlencode

import httpx

from ..config.schema import AuthConfig, FileConfig, ResponseConfig, ErrorHandling
from .auth import AuthStrategy, create_auth_strategy

# T081: Setup logger for HTTP client
logger = logging.getLogger(__name__)


def interpolate_path_params(path: str, params: dict[str, Any]) -> str:
    """
    Interpolate path parameters into URL path.
    
    Replaces {param_name} placeholders with actual values.
    
    Args:
        path: URL path with {param} placeholders
        params: Dictionary of parameter values
        
    Returns:
        Path with parameters interpolated
        
    Raises:
        ValueError: If required path parameter is missing
        
    Example:
        >>> interpolate_path_params("/users/{user_id}/repos", {"user_id": 123})
        '/users/123/repos'
    """
    # Find all {param_name} placeholders
    placeholders = re.findall(r'\{([^}]+)\}', path)
    
    result = path
    for placeholder in placeholders:
        if placeholder not in params:
            raise ValueError(f"Missing required path parameter: {placeholder}")
        
        # Replace {placeholder} with actual value
        value = params[placeholder]
        result = result.replace(f"{{{placeholder}}}", str(value))
    
    return result


def build_query_params(params: dict[str, Any]) -> str:
    """
    Build URL query string from parameters.
    
    Handles encoding and formatting of query parameters.
    
    Args:
        params: Dictionary of query parameter values
        
    Returns:
        URL-encoded query string (without leading '?')
        
    Example:
        >>> build_query_params({"q": "search term", "limit": 10})
        'q=search+term&limit=10'
    """
    if not params:
        return ""
    
    # Filter out None values
    filtered = {k: v for k, v in params.items() if v is not None}
    
    return urlencode(filtered)


class HTTPClient:
    """
    Async HTTP client wrapper for making API requests.
    
    Handles connection pooling, timeouts, and request construction.
    """
    
    # T092: Default size limits (configurable)
    DEFAULT_MAX_REQUEST_SIZE = 10 * 1024 * 1024  # 10 MB
    DEFAULT_MAX_RESPONSE_SIZE = 50 * 1024 * 1024  # 50 MB
    
    def __init__(
        self,
        base_url: str,
        timeout: int = 30,
        default_headers: Optional[dict[str, str]] = None,
        auth_config: Optional[AuthConfig] = None,
        max_request_size: Optional[int] = None,
        max_response_size: Optional[int] = None,
    ):
        """
        Initialize HTTP client.
        
        Args:
            base_url: Base URL for all requests
            timeout: Default timeout in seconds
            default_headers: Default headers for all requests
            auth_config: Authentication configuration
            max_request_size: Maximum request body size in bytes (default: 10MB)
            max_response_size: Maximum response size in bytes (default: 50MB)
        """
        self.base_url = base_url.rstrip('/')
        self.timeout = httpx.Timeout(timeout)
        self.default_headers = default_headers or {}
        self.auth_strategy = create_auth_strategy(auth_config)
        self._client: Optional[httpx.AsyncClient] = None
        
        # T092: Set size limits
        self.max_request_size = max_request_size or self.DEFAULT_MAX_REQUEST_SIZE
        self.max_response_size = max_response_size or self.DEFAULT_MAX_RESPONSE_SIZE
        
        # T081: Log client initialization (without sensitive data)
        logger.debug(
            f"HTTPClient initialized with base_url={base_url}, timeout={timeout}s, "
            f"max_request={self.max_request_size} bytes, max_response={self.max_response_size} bytes"
        )
        if auth_config:
            logger.debug(f"Authentication configured: type={auth_config.type}")
    
    async def get_client(self) -> httpx.AsyncClient:
        """
        Get or create async HTTP client.
        
        Implements lazy initialization with connection pooling.
        
        Returns:
            Configured httpx.AsyncClient instance
        """
        if self._client is None:
            logger.debug("Creating new httpx.AsyncClient with HTTP/2 support")
            self._client = httpx.AsyncClient(
                timeout=self.timeout,
                headers=self.default_headers,
                http2=True,  # Enable HTTP/2 support
                follow_redirects=True,
            )
        return self._client
    
    async def close(self) -> None:
        """Close HTTP client and cleanup connections."""
        if self._client is not None:
            logger.debug("Closing HTTP client and cleaning up connections")
            await self._client.aclose()
            self._client = None
    
    def _check_request_size(self, body_data: Optional[dict[str, Any]]) -> None:
        """
        T092: Check if request body size is within limits.
        
        Args:
            body_data: Request body data
            
        Raises:
            ValueError: If request body exceeds size limit
        """
        if body_data:
            import json
            body_bytes = json.dumps(body_data).encode('utf-8')
            body_size = len(body_bytes)
            
            if body_size > self.max_request_size:
                size_mb = body_size / (1024 * 1024)
                limit_mb = self.max_request_size / (1024 * 1024)
                error_msg = (
                    f"Request body size ({size_mb:.2f} MB) exceeds limit "
                    f"({limit_mb:.2f} MB)"
                )
                logger.error(error_msg)
                raise ValueError(error_msg)
    
    def _check_response_size(self, response: httpx.Response) -> None:
        """
        T092: Check if response size is within limits.
        
        Args:
            response: HTTP response
            
        Raises:
            ValueError: If response exceeds size limit
        """
        content_length = len(response.content)
        
        if content_length > self.max_response_size:
            size_mb = content_length / (1024 * 1024)
            limit_mb = self.max_response_size / (1024 * 1024)
            error_msg = (
                f"Response size ({size_mb:.2f} MB) exceeds limit "
                f"({limit_mb:.2f} MB)"
            )
            logger.error(error_msg)
            raise ValueError(error_msg)

    def _prepare_files_payload(
        self, file_params: Optional[dict[str, Any]], file_config: Optional[FileConfig]
    ) -> Optional[list[tuple[str, tuple[str, bytes, str]]]]:
        """Prepare httpx-compatible files payload from file parameters.

        Supports:
        - New format: dict with 'content' (bytes), 'filename', 'mime_type'
        - Legacy format: file paths (for local MCP servers)
        - Multiple file uploads
        
        Validates type and size constraints from file_config.
        """
        if not file_params:
            return None

        import mimetypes
        from pathlib import Path

        payload: list[tuple[str, tuple[str, bytes, str]]] = []

        max_size_mb = file_config.max_size_mb if file_config else 100
        allowed_types = file_config.allowed_types if file_config else None
        field_name_cfg = file_config.field_name if file_config else None
        multiple_allowed = file_config.multiple if file_config else False

        def add_file_from_dict(field_name: str, file_data: dict) -> None:
            """Add file from resolved dict format (content, filename, mime_type)."""
            file_content = file_data['content']
            filename = file_data.get('filename', 'file')
            mime_type = file_data.get('mime_type', 'application/octet-stream')
            
            size_bytes = len(file_content)
            size_mb = size_bytes / (1024 * 1024)
            
            if size_mb > max_size_mb:
                msg = f"File '{filename}' is {size_mb:.2f} MB which exceeds max_size_mb={max_size_mb} MB"
                logger.error(msg)
                raise ValueError(msg)

            if allowed_types and mime_type not in allowed_types:
                msg = f"File '{filename}' has unsupported type '{mime_type}'. Allowed: {allowed_types}"
                logger.error(msg)
                raise ValueError(msg)

            logger.debug(
                f"Prepared file '{filename}' for upload as field '{field_name}' ({mime_type}), size={size_mb:.2f} MB"
            )
            payload.append((field_name, (filename, file_content, mime_type)))

        def add_file_from_path(field_name: str, file_path: str) -> None:
            """Add file from local path (legacy format for local MCP servers)."""
            p = Path(str(file_path))
            if not p.exists() or not p.is_file():
                msg = f"File not found or not a file: {p}"
                logger.error(msg)
                raise ValueError(msg)

            size_bytes = p.stat().st_size
            size_mb = size_bytes / (1024 * 1024)
            if size_mb > max_size_mb:
                msg = f"File '{p.name}' is {size_mb:.2f} MB which exceeds max_size_mb={max_size_mb} MB"
                logger.error(msg)
                raise ValueError(msg)

            mime_type, _ = mimetypes.guess_type(p.name)
            if allowed_types and mime_type not in allowed_types:
                msg = f"File '{p.name}' has unsupported type '{mime_type}'. Allowed: {allowed_types}"
                logger.error(msg)
                raise ValueError(msg)

            file_content = p.read_bytes()
            logger.debug(
                f"Prepared file '{p.name}' for upload as field '{field_name}' ({mime_type}), size={size_mb:.2f} MB"
            )
            payload.append((field_name, (p.name, file_content, mime_type or 'application/octet-stream')))

        def add_file(field_name: str, value: Any) -> None:
            """Add file from any supported format."""
            if isinstance(value, dict) and 'content' in value:
                # New resolved format from tool_factory
                add_file_from_dict(field_name, value)
            elif isinstance(value, str):
                # Legacy path format (local MCP server)
                add_file_from_path(field_name, value)
            else:
                raise ValueError(f"Unsupported file parameter type: {type(value).__name__}")

        for param_name, value in file_params.items():
            field_name = field_name_cfg or param_name
            if isinstance(value, (list, tuple, set)):
                if not multiple_allowed:
                    msg = (
                        f"Multiple files provided for parameter '{param_name}' but configuration allows only a single file"
                    )
                    logger.error(msg)
                    raise ValueError(msg)
                for item in value:
                    add_file(field_name, item)
            else:
                add_file(field_name, value)

        return payload


    def _detect_content_type(self, response: httpx.Response) -> str:
        """Detect simplified content type for a response.

        Returns 'json' when JSON is likely, otherwise 'text'.
        """
        content_type = response.headers.get('Content-Type', '')
        if 'application/json' in content_type:
            return 'json'
        return 'text'

    def _extract_json_path(self, data: Any, path: str) -> Any:
        """Very small JSONPath implementation supporting $.foo.bar[0].baz.

        Raises KeyError/IndexError on invalid paths.
        """
        import re as _re

        if not path or path == '$':
            return data
        if not path.startswith('$'):
            raise KeyError(f"JSONPath must start with '$', got: {path}")
        # Strip leading '$' and optional dot
        path = path[1:]
        if path.startswith('.'):
            path = path[1:]

        current: Any = data
        token_re = _re.compile(r'([^\.\[]+)(\[\d+\])?$')

        for part in path.split('.'):
            if not part:
                continue
            m = token_re.match(part)
            if not m:
                raise KeyError(f"Invalid JSONPath token: {part}")
            key = m.group(1)
            index_part = m.group(2)

            if isinstance(current, dict):
                current = current[key]
            else:
                raise KeyError(f"Cannot access key '{key}' on non-object type")

            if index_part:
                idx = int(index_part[1:-1])
                if isinstance(current, list):
                    current = current[idx]
                else:
                    raise IndexError(f"Cannot index into non-list for token {part}")

        return current


    def process_response(
        self, response: httpx.Response, response_config: Optional[ResponseConfig]
    ) -> Any:
        """Process HTTP response according to ResponseConfig (US5).

        Applies success code validation, JSONPath extraction, and error handling.
        """
        # Fast path when no special configuration provided
        if response_config is None:
            try:
                return response.json()
            except Exception:
                return {"content": response.text}

        status = response.status_code
        is_json = self._detect_content_type(response) == 'json'

        # Parse JSON if possible
        json_data: Any | None = None
        if is_json:
            try:
                json_data = response.json()
            except Exception:
                json_data = None

        # T069: Validate HTTP status code against success_codes
        if status not in (response_config.success_codes or []):
            eh: Optional[ErrorHandling] = response_config.error_handling
            message = eh.default_message if eh and eh.default_message else 'Request failed'

            # T070: Try to extract error message from JSON body using extract_message_path
            if eh and eh.extract_message_path and json_data is not None:
                try:
                    extracted = self._extract_json_path(json_data, eh.extract_message_path)
                    message = str(extracted)
                except Exception as exc:
                    logger.debug(f"Failed to extract error message via JSONPath: {exc}")

            parts = []
            if eh is None or eh.include_status_code:
                parts.append(f"HTTP {status}")
            parts.append(message)

            if eh and eh.include_response_body:
                body_preview = response.text
                if len(body_preview) > 500:
                    body_preview = body_preview[:500] + '... [truncated]'
                parts.append(f"Body: {body_preview}")

            error_msg = ' - '.join(parts)
            logger.error(error_msg)
            raise ValueError(error_msg)

        # Success path
        if json_data is None:
            # Non-JSON success
            return {"content": response.text}

        # T068: Extract data using extract_path when configured
        extract_path = response_config.extract_path or '$'
        if extract_path and extract_path != '$':
            try:
                extracted = self._extract_json_path(json_data, extract_path)
                return extracted
            except Exception as exc:
                logger.debug(f"Failed to apply extract_path '{extract_path}': {exc}")
                # Fall back to full JSON body
        return json_data


    async def request_get(
        self,
        path: str,
        path_params: Optional[dict[str, Any]] = None,
        query_params: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
        timeout: Optional[int] = None,
    ) -> httpx.Response:
        """
        Make GET request.
        
        Args:
            path: URL path (may contain {param} placeholders)
            path_params: Parameters to interpolate into path
            query_params: Query string parameters
            headers: Additional headers for this request
            timeout: Override default timeout
            
        Returns:
            HTTP response
            
        Raises:
            httpx.TimeoutException: If request times out
            httpx.HTTPError: For network errors
        """
        # T024: Interpolate path parameters
        if path_params:
            path = interpolate_path_params(path, path_params)
        
        # Construct full URL
        url = f"{self.base_url}{path}"
        
        # T025: Build query string
        if query_params:
            query_string = build_query_params(query_params)
            if query_string:
                url = f"{url}?{query_string}"
        
        # T052: Apply authentication to URL (for query param auth)
        url = self.auth_strategy.apply_to_url(url)
        
        # T053: Merge headers (default + endpoint + auth)
        request_headers = {**self.default_headers}
        if headers:
            request_headers.update(headers)
        request_headers = self.auth_strategy.apply_to_headers(request_headers)
        
        # T081: Log request (without auth credentials)
        logger.info(f"GET {url}")
        logger.debug(f"GET request headers: {list(request_headers.keys())}")
        
        # T026: Use httpx AsyncClient
        client = await self.get_client()
        
        # Override timeout if specified
        request_timeout = httpx.Timeout(timeout) if timeout else self.timeout
        
        try:
            # T027: Execute GET request
            response = await client.get(
                url,
                headers=request_headers,
                timeout=request_timeout,
            )
            
            # T092: Check response size
            self._check_response_size(response)
            
            # T081: Log response
            logger.info(f"GET {url} -> {response.status_code}")
            logger.debug(f"Response size: {len(response.content)} bytes")
            
            return response
            
        except httpx.TimeoutException as e:
            logger.error(f"GET {url} -> TIMEOUT after {request_timeout.read}s")
            raise
        except httpx.HTTPError as e:
            logger.error(f"GET {url} -> ERROR: {e}")
            raise
    
    def serialize_json_body(self, data: dict[str, Any]) -> bytes:
        """
        Serialize request body as JSON.
        
        Args:
            data: Dictionary to serialize
            
        Returns:
            JSON-encoded bytes
        """
        import json
        return json.dumps(data).encode('utf-8')
    
    def serialize_form_body(self, data: dict[str, Any]) -> str:
        """
        Serialize request body as form-urlencoded.
        
        Args:
            data: Dictionary to serialize
            
        Returns:
            URL-encoded form data string
        """
        return urlencode(data)
    
    async def request_post(
        self,
        path: str,
        path_params: Optional[dict[str, Any]] = None,
        query_params: Optional[dict[str, Any]] = None,
        body_data: Optional[dict[str, Any]] = None,
        body_type: str = "json",
        headers: Optional[dict[str, str]] = None,
        timeout: Optional[int] = None,
        files: Optional[dict[str, Any]] = None,
        file_config: Optional[FileConfig] = None,
    ) -> httpx.Response:
        """
        Make POST request.
        
        Args:
            path: URL path (may contain {param} placeholders)
            path_params: Parameters to interpolate into path
            query_params: Query string parameters
            body_data: Request body data
            body_type: Body encoding ("json" or "form")
            headers: Additional headers for this request
            timeout: Override default timeout
            
        Returns:
            HTTP response
        """
        # Interpolate path parameters
        if path_params:
            path = interpolate_path_params(path, path_params)
        
        # Construct full URL
        url = f"{self.base_url}{path}"
        if query_params:
            query_string = build_query_params(query_params)
            if query_string:
                url = f"{url}?{query_string}"
        
        # Apply authentication to URL
        url = self.auth_strategy.apply_to_url(url)
        
        # Merge headers and set Content-Type (skip explicit header for multipart so httpx can set boundary)
        request_headers = {**self.default_headers}
        is_multipart = body_type == "multipart" or files is not None
        if not is_multipart:
            if body_type == "json":
                request_headers["Content-Type"] = "application/json"
            elif body_type == "form":
                request_headers["Content-Type"] = "application/x-www-form-urlencoded"
        if headers:
            request_headers.update(headers)
        # Apply authentication to headers
        request_headers = self.auth_strategy.apply_to_headers(request_headers)
        
        # T081: Log request
        logger.info(f"POST {url}")
        logger.debug(f"POST body_type={body_type}, has_body={body_data is not None}, has_files={files is not None}")
        
        # T092: Check request size for non-multipart bodies
        if body_data and not is_multipart:
            self._check_request_size(body_data)
        
        # Prepare files payload for multipart uploads
        files_payload = None
        if is_multipart:
            files_payload = self._prepare_files_payload(files, file_config)
        
        # Get client
        client = await self.get_client()
        request_timeout = httpx.Timeout(timeout) if timeout else self.timeout
        
        try:
            # Prepare body and execute request
            if is_multipart:
                response = await client.post(
                    url,
                    data=body_data,
                    files=files_payload,
                    headers=request_headers,
                    timeout=request_timeout,
                )
            elif body_data:
                if body_type == "json":
                    response = await client.post(
                        url,
                        json=body_data,
                        headers=request_headers,
                        timeout=request_timeout,
                    )
                else:  # form
                    response = await client.post(
                        url,
                        data=body_data,
                        headers=request_headers,
                        timeout=request_timeout,
                    )
            else:
                response = await client.post(
                    url,
                    headers=request_headers,
                    timeout=request_timeout,
                )
            
            # T092: Check response size
            self._check_response_size(response)
            
            # T081: Log response
            logger.info(f"POST {url} -> {response.status_code}")
            logger.debug(f"Response size: {len(response.content)} bytes")
            
            return response
            
        except httpx.TimeoutException as e:
            logger.error(f"POST {url} -> TIMEOUT")
            raise
        except httpx.HTTPError as e:
            logger.error(f"POST {url} -> ERROR: {e}")
            raise
    
    async def request_put(
        self,
        path: str,
        path_params: Optional[dict[str, Any]] = None,
        query_params: Optional[dict[str, Any]] = None,
        body_data: Optional[dict[str, Any]] = None,
        body_type: str = "json",
        headers: Optional[dict[str, str]] = None,
        timeout: Optional[int] = None,
        files: Optional[dict[str, Any]] = None,
        file_config: Optional[FileConfig] = None,
    ) -> httpx.Response:
        """Make PUT request (same signature as POST)."""
        # Interpolate path parameters
        if path_params:
            path = interpolate_path_params(path, path_params)
        
        url = f"{self.base_url}{path}"
        if query_params:
            query_string = build_query_params(query_params)
            if query_string:
                url = f"{url}?{query_string}"
        
        # Apply authentication to URL
        url = self.auth_strategy.apply_to_url(url)
        
        request_headers = {**self.default_headers}
        is_multipart = body_type == "multipart" or files is not None
        if not is_multipart:
            if body_type == "json":
                request_headers["Content-Type"] = "application/json"
            elif body_type == "form":
                request_headers["Content-Type"] = "application/x-www-form-urlencoded"
        if headers:
            request_headers.update(headers)
        # Apply authentication to headers
        request_headers = self.auth_strategy.apply_to_headers(request_headers)
        
        # T081: Log request
        logger.info(f"PUT {url}")
        logger.debug(f"PUT body_type={body_type}, has_body={body_data is not None}, has_files={files is not None}")
        
        # T092: Check request size for non-multipart bodies
        if body_data and not is_multipart:
            self._check_request_size(body_data)
        
        files_payload = None
        if is_multipart:
            files_payload = self._prepare_files_payload(files, file_config)
        
        client = await self.get_client()
        request_timeout = httpx.Timeout(timeout) if timeout else self.timeout
        
        try:
            if is_multipart:
                response = await client.put(
                    url, data=body_data, files=files_payload, headers=request_headers, timeout=request_timeout
                )
            elif body_data:
                if body_type == "json":
                    response = await client.put(
                        url, json=body_data, headers=request_headers, timeout=request_timeout
                    )
                else:
                    response = await client.put(
                        url, data=body_data, headers=request_headers, timeout=request_timeout
                    )
            else:
                response = await client.put(url, headers=request_headers, timeout=request_timeout)
            
            # T092: Check response size
            self._check_response_size(response)
            
            # T081: Log response
            logger.info(f"PUT {url} -> {response.status_code}")
            logger.debug(f"Response size: {len(response.content)} bytes")
            
            return response
            
        except httpx.TimeoutException as e:
            logger.error(f"PUT {url} -> TIMEOUT")
            raise
        except httpx.HTTPError as e:
            logger.error(f"PUT {url} -> ERROR: {e}")
            raise
    
    async def request_patch(
        self,
        path: str,
        path_params: Optional[dict[str, Any]] = None,
        query_params: Optional[dict[str, Any]] = None,
        body_data: Optional[dict[str, Any]] = None,
        body_type: str = "json",
        headers: Optional[dict[str, str]] = None,
        timeout: Optional[int] = None,
        files: Optional[dict[str, Any]] = None,
        file_config: Optional[FileConfig] = None,
    ) -> httpx.Response:
        """Make PATCH request (same signature as POST)."""
        if path_params:
            path = interpolate_path_params(path, path_params)
        
        url = f"{self.base_url}{path}"
        if query_params:
            query_string = build_query_params(query_params)
            if query_string:
                url = f"{url}?{query_string}"
        
        # Apply authentication to URL
        url = self.auth_strategy.apply_to_url(url)
        
        request_headers = {**self.default_headers}
        is_multipart = body_type == "multipart" or files is not None
        if not is_multipart:
            if body_type == "json":
                request_headers["Content-Type"] = "application/json"
            elif body_type == "form":
                request_headers["Content-Type"] = "application/x-www-form-urlencoded"
        if headers:
            request_headers.update(headers)
        # Apply authentication to headers
        request_headers = self.auth_strategy.apply_to_headers(request_headers)
        
        # T081: Log request
        logger.info(f"PATCH {url}")
        logger.debug(f"PATCH body_type={body_type}, has_body={body_data is not None}, has_files={files is not None}")
        
        # T092: Check request size
        if body_data and not is_multipart:
            self._check_request_size(body_data)
        
        client = await self.get_client()
        request_timeout = httpx.Timeout(timeout) if timeout else self.timeout
        
        files_payload = None
        if is_multipart:
            files_payload = self._prepare_files_payload(files, file_config)
        
        try:
            if is_multipart:
                response = await client.patch(
                    url, data=body_data, files=files_payload, headers=request_headers, timeout=request_timeout
                )
            elif body_data:
                if body_type == "json":
                    response = await client.patch(
                        url, json=body_data, headers=request_headers, timeout=request_timeout
                    )
                else:
                    response = await client.patch(
                        url, data=body_data, headers=request_headers, timeout=request_timeout
                    )
            else:
                response = await client.patch(url, headers=request_headers, timeout=request_timeout)
            
            # T092: Check response size
            self._check_response_size(response)
            
            # T081: Log response
            logger.info(f"PATCH {url} -> {response.status_code}")
            logger.debug(f"Response size: {len(response.content)} bytes")
            
            return response
            
        except httpx.TimeoutException as e:
            logger.error(f"PATCH {url} -> TIMEOUT")
            raise
        except httpx.HTTPError as e:
            logger.error(f"PATCH {url} -> ERROR: {e}")
            raise
    
    async def request_delete(
        self,
        path: str,
        path_params: Optional[dict[str, Any]] = None,
        query_params: Optional[dict[str, Any]] = None,
        headers: Optional[dict[str, str]] = None,
        timeout: Optional[int] = None,
    ) -> httpx.Response:
        """
        Make DELETE request.
        
        Args:
            path: URL path (may contain {param} placeholders)
            path_params: Parameters to interpolate into path
            query_params: Query string parameters
            headers: Additional headers for this request
            timeout: Override default timeout
            
        Returns:
            HTTP response
        """
        if path_params:
            path = interpolate_path_params(path, path_params)
        
        url = f"{self.base_url}{path}"
        if query_params:
            query_string = build_query_params(query_params)
            if query_string:
                url = f"{url}?{query_string}"
        
        # Apply authentication to URL
        url = self.auth_strategy.apply_to_url(url)
        
        request_headers = {**self.default_headers}
        if headers:
            request_headers.update(headers)
        # Apply authentication to headers
        request_headers = self.auth_strategy.apply_to_headers(request_headers)
        
        # T081: Log request
        logger.info(f"DELETE {url}")
        
        client = await self.get_client()
        request_timeout = httpx.Timeout(timeout) if timeout else self.timeout
        
        try:
            response = await client.delete(
                url,
                headers=request_headers,
                timeout=request_timeout,
            )
            
            # T092: Check response size
            self._check_response_size(response)
            
            # T081: Log response
            logger.info(f"DELETE {url} -> {response.status_code}")
            
            return response
            
        except httpx.TimeoutException as e:
            logger.error(f"DELETE {url} -> TIMEOUT")
            raise
        except httpx.HTTPError as e:
            logger.error(f"DELETE {url} -> ERROR: {e}")
            raise
