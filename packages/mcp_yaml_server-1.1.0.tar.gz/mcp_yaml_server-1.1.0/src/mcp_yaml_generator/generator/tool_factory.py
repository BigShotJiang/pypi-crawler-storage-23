"""Tool factory for generating MCP tool functions from endpoint configurations."""

import logging
from typing import Any, Callable, Optional

from ..client.http_client import HTTPClient
from ..config.schema import EndpointConfig, HTTPMethod, ParamLocation

# T082: Setup logger for tool factory
logger = logging.getLogger(__name__)


def _resolve_file_param(value: Any, param_name: str) -> dict[str, Any]:
    """
    Resolve a file parameter to a dict with file content.
    
    Supports:
    - Local file paths (reads content immediately)
    - Base64-encoded content (decodes to bytes)
    - Dict with 'content' and 'filename' keys (pass-through)
    - Raw bytes (pass-through)
    
    Returns:
        Dict with keys: 'content' (bytes), 'filename' (str), 'mime_type' (str)
    """
    import base64
    import mimetypes
    from pathlib import Path
    
    # Already resolved (dict with content)
    if isinstance(value, dict) and 'content' in value:
        return value
    
    # Raw bytes
    if isinstance(value, bytes):
        return {
            'content': value,
            'filename': f'{param_name}_file',
            'mime_type': 'application/octet-stream',
        }
    
    # String: could be path, base64, or data URI
    if isinstance(value, str):
        # Handle data URI format first: data:mime/type;base64,CONTENT
        if value.startswith('data:') and ';base64,' in value:
            try:
                header, b64_content = value.split(',', 1)
                mime_type = header.split(':')[1].split(';')[0]
                file_content = base64.b64decode(b64_content)
                logger.debug(f"Decoded data URI ({len(file_content)} bytes, {mime_type}) for param '{param_name}'")
                return {
                    'content': file_content,
                    'filename': f'{param_name}_file',
                    'mime_type': mime_type,
                }
            except Exception as e:
                logger.debug(f"Data URI decode failed: {e}")
        
        # Check if it looks like base64 (no path separators, long enough)
        is_likely_base64 = (
            len(value) > 100 and
            '/' not in value and
            '\\' not in value and
            not value.startswith('~')
        )
        
        # Try as a file path
        try:
            p = Path(value).expanduser()
            if p.exists() and p.is_file():
                file_content = p.read_bytes()
                mime_type, _ = mimetypes.guess_type(p.name)
                logger.debug(f"Read file '{p.name}' ({len(file_content)} bytes) for param '{param_name}'")
                return {
                    'content': file_content,
                    'filename': p.name,
                    'mime_type': mime_type or 'application/octet-stream',
                }
        except Exception as e:
            logger.debug(f"Path resolution failed for '{value[:50]}...': {e}")
        
        # Try as raw base64 if path didn't work
        if is_likely_base64:
            try:
                file_content = base64.b64decode(value)
                logger.debug(f"Decoded base64 content ({len(file_content)} bytes) for param '{param_name}'")
                return {
                    'content': file_content,
                    'filename': f'{param_name}_file',
                    'mime_type': 'application/octet-stream',
                }
            except Exception as e:
                logger.debug(f"Base64 decode failed: {e}")
        
        # If nothing worked, raise a helpful error
        raise ValueError(
            f"File parameter '{param_name}' could not be resolved. "
            f"Value '{value[:100]}{'...' if len(value) > 100 else ''}' is neither a valid local file path "
            f"nor valid base64 content. For remote MCP servers, provide base64-encoded file content "
            f"or a data URI (data:mime/type;base64,CONTENT)."
        )
    
    raise ValueError(
        f"File parameter '{param_name}' has unsupported type {type(value).__name__}. "
        f"Expected: file path (str), base64 string, bytes, or dict with 'content' key."
    )


def create_tool_function(
    endpoint: EndpointConfig,
    http_client: HTTPClient,
) -> Callable:
    """
    Create an async function that implements the tool logic.
    
    Generates a callable function that:
    1. Extracts parameters by location (path, query, header)
    2. Makes HTTP request using the configured method
    3. Returns response data
    
    Args:
        endpoint: Endpoint configuration
        http_client: HTTP client instance to use for requests
        
    Returns:
        Async callable function implementing the tool
        
    Example:
        >>> endpoint = EndpointConfig(...)
        >>> client = HTTPClient("https://api.example.com")
        >>> tool_func = create_tool_function(endpoint, client)
        >>> result = await tool_func(user_id=123, limit=10)
    """
    
    async def tool_impl(**kwargs: Any) -> dict[str, Any]:
        """
        Tool implementation function.
        
        Dynamically generated based on endpoint configuration.
        
        Args:
            **kwargs: Tool parameters as keyword arguments
            
        Returns:
            Response data from API
            
        Raises:
            ValueError: If required parameters are missing
            httpx.HTTPError: If request fails
        """
        # T082: Log tool invocation
        logger.info(f"Tool '{endpoint.name}' invoked with {len(kwargs)} parameter(s)")
        logger.debug(f"Tool '{endpoint.name}' parameters: {list(kwargs.keys())}")
        
        # T035: Validate required parameters
        if endpoint.parameters:
            for param in endpoint.parameters:
                if param.required and param.name not in kwargs:
                    logger.error(f"Tool '{endpoint.name}' missing required parameter: {param.name}")
                    raise ValueError(f"Missing required parameter: {param.name}")
        
        # Separate parameters by location
        path_params: dict[str, Any] = {}
        query_params: dict[str, Any] = {}
        header_params: dict[str, str] = {}
        body_params: dict[str, Any] = {}
        file_params: dict[str, Any] = {}
        
        if endpoint.parameters:
            for param in endpoint.parameters:
                param_value = kwargs.get(param.name, param.default)
                
                # Skip if not provided and not required
                if param_value is None and not param.required:
                    continue
                
                if param.location == ParamLocation.PATH:
                    path_params[param.name] = param_value
                elif param.location == ParamLocation.QUERY:
                    query_params[param.name] = param_value
                elif param.location == ParamLocation.HEADER:
                    header_params[param.name] = str(param_value)
                elif param.location == ParamLocation.BODY:
                    body_params[param.name] = param_value
                elif param.location == ParamLocation.FILE:
                    # Handle file parameters: support both local paths and base64 content
                    file_params[param.name] = _resolve_file_param(param_value, param.name)
        
        # Merge endpoint-specific headers
        request_headers = {}
        if endpoint.request_config and endpoint.request_config.headers:
            request_headers.update(endpoint.request_config.headers)
        request_headers.update(header_params)
        
        # Get timeout override
        timeout = None
        if endpoint.request_config and endpoint.request_config.timeout:
            timeout = endpoint.request_config.timeout
        
        # Determine body type
        body_type = "json"  # default
        if endpoint.request_config and endpoint.request_config.body_type:
            body_type = endpoint.request_config.body_type.value
        
        # T043: Make HTTP request based on method
        if endpoint.method == HTTPMethod.GET:
            response = await http_client.request_get(
                path=endpoint.path,
                path_params=path_params if path_params else None,
                query_params=query_params if query_params else None,
                headers=request_headers if request_headers else None,
                timeout=timeout,
            )
        elif endpoint.method == HTTPMethod.POST:
            response = await http_client.request_post(
                path=endpoint.path,
                path_params=path_params if path_params else None,
                query_params=query_params if query_params else None,
                body_data=body_params if body_params else None,
                body_type=body_type,
                headers=request_headers if request_headers else None,
                timeout=timeout,
                files=file_params if file_params else None,
                file_config=endpoint.request_config.files if endpoint.request_config and endpoint.request_config.files else None,
            )
        elif endpoint.method == HTTPMethod.PUT:
            response = await http_client.request_put(
                path=endpoint.path,
                path_params=path_params if path_params else None,
                query_params=query_params if query_params else None,
                body_data=body_params if body_params else None,
                body_type=body_type,
                headers=request_headers if request_headers else None,
                timeout=timeout,
                files=file_params if file_params else None,
                file_config=endpoint.request_config.files if endpoint.request_config and endpoint.request_config.files else None,
            )
        elif endpoint.method == HTTPMethod.PATCH:
            response = await http_client.request_patch(
                path=endpoint.path,
                path_params=path_params if path_params else None,
                query_params=query_params if query_params else None,
                body_data=body_params if body_params else None,
                body_type=body_type,
                headers=request_headers if request_headers else None,
                timeout=timeout,
                files=file_params if file_params else None,
                file_config=endpoint.request_config.files if endpoint.request_config and endpoint.request_config.files else None,
            )
        elif endpoint.method == HTTPMethod.DELETE:
            response = await http_client.request_delete(
                path=endpoint.path,
                path_params=path_params if path_params else None,
                query_params=query_params if query_params else None,
                headers=request_headers if request_headers else None,
                timeout=timeout,
            )
        else:
            raise NotImplementedError(f"HTTP method {endpoint.method} not supported")
        
        # Use HTTP client response processing (status codes, JSONPath, error handling)
        data = http_client.process_response(response, endpoint.response_config)
        logger.info(f"Tool '{endpoint.name}' completed successfully")
        return data
    
    return tool_impl


def create_mcp_tool_function(
    endpoint: EndpointConfig,
    http_client: HTTPClient,
) -> Callable:
    """Create a FastMCP-compatible tool function with explicit parameters.

    Wraps the generic **kwargs implementation so FastMCP can generate a schema
    without using **kwargs directly.
    """
    base_impl = create_tool_function(endpoint, http_client)

    # Build a function signature with named parameters for each endpoint parameter
    if endpoint.parameters:
        param_parts: list[str] = []
        for param in endpoint.parameters:
            param_str = param.name
            if not param.required:
                default = param.default
                default_repr = repr(default) if default is not None else "None"
                param_str += f"={default_repr}"
            param_parts.append(param_str)
        params_sig = ", ".join(param_parts)
    else:
        params_sig = ""

    # Define an async wrapper that forwards arguments to the base implementation
    namespace: dict[str, Any] = {"_impl": base_impl}
    if params_sig:
        code = f"async def tool_impl({params_sig}):\n"
        code += "    return await _impl(**locals())\n"
    else:
        code = "async def tool_impl():\n"
        code += "    return await _impl(**locals())\n"

    exec(code, namespace)
    return namespace["tool_impl"]


def generate_tool_descriptor(
    endpoint: EndpointConfig,
    http_client: HTTPClient,
) -> dict[str, Any]:
    """
    Generate complete tool descriptor for MCP registration.
    
    Combines metadata and implementation function.
    
    Args:
        endpoint: Endpoint configuration
        http_client: HTTP client instance
        
    Returns:
        Tool descriptor with metadata and implementation
    """
    from .metadata import generate_tool_metadata
    
    # T082: Log tool generation
    logger.debug(f"Generating tool descriptor for '{endpoint.name}'")
    
    metadata = generate_tool_metadata(endpoint)
    implementation = create_mcp_tool_function(endpoint, http_client)
    
    logger.info(f"Tool '{endpoint.name}' generated: {endpoint.method} {endpoint.path}")
    
    return {
        **metadata,
        "implementation": implementation,
    }
