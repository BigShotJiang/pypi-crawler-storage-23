"""Tool metadata and parameter schema generation for MCP tools."""

from typing import Any

from ..config.schema import EndpointConfig, ParameterSchema, ParameterType


def parameter_type_to_json_schema(param_type: ParameterType) -> str:
    """
    Convert ParameterType enum to JSON Schema type string.
    
    Args:
        param_type: Parameter type enum value
        
    Returns:
        JSON Schema type string
    """
    # Direct mapping from ParameterType to JSON Schema types
    return param_type.value


def parameter_to_json_schema(param: ParameterSchema) -> dict[str, Any]:
    """
    Convert ParameterSchema to JSON Schema property definition.
    
    Args:
        param: Parameter schema definition
        
    Returns:
        JSON Schema property object
        
    Example:
        >>> param = ParameterSchema(
        ...     name="user_id",
        ...     type=ParameterType.INTEGER,
        ...     description="User ID",
        ...     required=True
        ... )
        >>> parameter_to_json_schema(param)
        {
            "type": "integer",
            "description": "User ID"
        }
    """
    schema: dict[str, Any] = {
        "type": parameter_type_to_json_schema(param.type),
        "description": param.description,
        # Non-standard extensions to help AI agents understand parameters
        "x-location": param.location.value,
        "x-required": param.required,
    }
    
    # Add default value if present
    if param.default is not None:
        schema["default"] = param.default
        # Also mention default in description for better UX
        schema["description"] = f"{param.description} (Default: {param.default})"
    
    return schema


def generate_tool_input_schema(endpoint: EndpointConfig) -> dict[str, Any]:
    """
    Generate JSON Schema for tool input parameters.
    
    Converts endpoint parameters to FastMCP-compatible JSON Schema.
    
    Args:
        endpoint: Endpoint configuration
        
    Returns:
        JSON Schema object for tool parameters
        
    Example:
        {
            "type": "object",
            "properties": {
                "user_id": {
                    "type": "integer",
                    "description": "User ID"
                },
                "limit": {
                    "type": "integer",
                    "description": "Max results",
                    "default": 10
                }
            },
            "required": ["user_id"]
        }
    """
    if not endpoint.parameters:
        return {
            "type": "object",
            "properties": {},
            "required": [],
        }
    
    properties = {}
    required = []
    
    for param in endpoint.parameters:
        properties[param.name] = parameter_to_json_schema(param)
        
        if param.required:
            required.append(param.name)
    
    return {
        "type": "object",
        "properties": properties,
        "required": required,
    }


def generate_tool_metadata(endpoint: EndpointConfig) -> dict[str, Any]:
    """
    Generate complete tool metadata from endpoint configuration.
    
    Creates metadata suitable for FastMCP tool registration.
    
    Args:
        endpoint: Endpoint configuration
        
    Returns:
        Tool metadata dictionary with name, description, and input schema
        
    Example:
        {
            "name": "get_user_repos",
            "description": "Fetch all repositories for a GitHub user",
            "input_schema": {
                "type": "object",
                "properties": {...},
                "required": [...]
            }
        }
    """
    # Enrich description with HTTP method and path for better tooling context
    description = f"{endpoint.description} [HTTP {endpoint.method.value} {endpoint.path}]"

    meta: dict[str, Any] = {
        "http": {
            "method": endpoint.method.value,
            "path": endpoint.path,
        },
        "yaml": {
            "endpoint_name": endpoint.name,
        },
    }

    return {
        "name": endpoint.name,
        "description": description,
        "input_schema": generate_tool_input_schema(endpoint),
        "meta": meta,
    }
