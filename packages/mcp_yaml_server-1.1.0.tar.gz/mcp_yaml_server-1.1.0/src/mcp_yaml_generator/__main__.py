"""CLI entry points for MCP YAML Generator."""

import argparse
import sys
from pathlib import Path

from .config.parser import parse_multiple_configs, parse_yaml_config
from .server.mcp_server import create_mcp_server


def main() -> None:
    """
    Main CLI entry point for starting MCP server.
    
    Usage:
        mcp-yaml-server config.yaml
        mcp-yaml-server config1.yaml config2.yaml
        mcp-yaml-server --dry-run config.yaml
        mcp-yaml-server --debug config.yaml
    """
    parser = argparse.ArgumentParser(
        description="Generate MCP tools from YAML configuration files",
        prog="mcp-yaml-server",
    )
    
    parser.add_argument(
        "config_files",
        nargs="+",
        type=str,
        help="YAML configuration file(s) to load",
    )
    
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate configuration without starting server",
    )
    
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable debug logging",
    )

    parser.add_argument(
        "--transport",
        choices=["stdio", "http", "streamable-http"],
        default="stdio",
        help="Transport to use for FastMCP server (default: stdio)",
    )

    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host to bind for HTTP transports (ignored for stdio)",
    )

    parser.add_argument(
        "--port",
        type=int,
        default=8000,
        help="Port to bind for HTTP transports (ignored for stdio)",
    )
    
    args = parser.parse_args()
    
    # Configure logging
    if args.debug:
        import logging
        logging.basicConfig(level=logging.DEBUG)
    
    try:
        # Parse configuration files
        config_paths = [Path(f) for f in args.config_files]
        
        if len(config_paths) == 1:
            # T020: Single configuration file
            config = parse_yaml_config(config_paths[0])
            
            if args.dry_run:
                print(f"✓ Configuration valid: {config_paths[0]}")
                print(f"  Server: {config.server.name} v{config.server.version}")
                print(f"  Endpoints: {len(config.endpoints)}")
                for endpoint in config.endpoints:
                    print(f"    - {endpoint.name}: {endpoint.method} {endpoint.path}")
                return
            
            # T031-T032: Create and start server
            server = create_mcp_server(config)
            print(f"Starting MCP server: {config.server.name}")
            print(f"Loaded {len(config.endpoints)} tool(s)")
            if args.transport in {"http", "streamable-http"}:
                print(f"Using {args.transport} transport on {args.host}:{args.port}")
            server.run(transport=args.transport, host=args.host, port=args.port)
            
        else:
            # Multiple configuration files
            configs = parse_multiple_configs(config_paths)
            
            if args.dry_run:
                print(f"✓ {len(configs)} configuration(s) valid")
                for config in configs:
                    print(f"\n  {config.server.name} v{config.server.version}")
                    print(f"    Endpoints: {len(config.endpoints)}")
                return
            
            print("Error: Multiple configuration files not yet fully supported")
            print("Please start separate servers for each configuration")
            sys.exit(1)
    
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    
    except ValueError as e:
        print(f"Configuration Error: {e}", file=sys.stderr)
        sys.exit(1)
    
    except KeyboardInterrupt:
        print("\nServer stopped")
        sys.exit(0)
    
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        if args.debug:
            raise
        sys.exit(1)


def validate() -> None:
    """
    CLI entry point for validating YAML configuration.
    
    Usage:
        mcp-yaml-validate config.yaml
    """
    parser = argparse.ArgumentParser(
        description="Validate YAML configuration files",
        prog="mcp-yaml-validate",
    )
    
    parser.add_argument(
        "config_file",
        type=str,
        help="YAML configuration file to validate",
    )
    
    args = parser.parse_args()
    
    try:
        config = parse_yaml_config(Path(args.config_file))
        
        print(f"✓ Configuration is valid")
        print(f"\nServer: {config.server.name} v{config.server.version}")
        if config.server.description:
            print(f"Description: {config.server.description}")
        
        print(f"\nGlobal Settings:")
        print(f"  Base URL: {config.global_.base_url}")
        print(f"  Timeout: {config.global_.timeout}s")
        if config.global_.auth:
            print(f"  Auth Type: {config.global_.auth.type}")
        
        print(f"\nEndpoints ({len(config.endpoints)}):")
        for endpoint in config.endpoints:
            param_count = len(endpoint.parameters) if endpoint.parameters else 0
            print(f"  • {endpoint.name}")
            print(f"    {endpoint.method} {endpoint.path}")
            print(f"    Parameters: {param_count}")
        
        print(f"\n✓ All validations passed")
        
    except FileNotFoundError as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    
    except ValueError as e:
        print(f"Validation Error:\n{e}", file=sys.stderr)
        sys.exit(1)
    
    except Exception as e:
        print(f"Unexpected error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
