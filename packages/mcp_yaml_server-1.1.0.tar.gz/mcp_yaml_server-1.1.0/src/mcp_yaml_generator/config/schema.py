"""Pydantic models for YAML configuration schema validation."""

from enum import Enum
from typing import Any, Literal, Optional

from pydantic import BaseModel, Field, HttpUrl, field_validator, model_validator


class HTTPMethod(str, Enum):
    """Supported HTTP methods."""

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"


class AuthType(str, Enum):
    """Supported authentication types."""

    API_KEY = "api_key"
    BEARER = "bearer"
    BASIC = "basic"
    CUSTOM = "custom"


class ParameterType(str, Enum):
    """Parameter data types (JSON Schema compatible)."""

    STRING = "string"
    INTEGER = "integer"
    NUMBER = "number"
    BOOLEAN = "boolean"
    ARRAY = "array"
    OBJECT = "object"


class ParamLocation(str, Enum):
    """Where parameters are sent in the HTTP request."""

    PATH = "path"
    QUERY = "query"
    BODY = "body"
    HEADER = "header"
    FILE = "file"


class BodyType(str, Enum):
    """Request body encoding types."""

    JSON = "json"
    FORM = "form"
    MULTIPART = "multipart"


# T010: ServerConfig
class ServerConfig(BaseModel):
    """MCP server metadata configuration."""

    name: str = Field(..., pattern=r"^[a-zA-Z][a-zA-Z0-9_]*$")
    version: str = "1.0.0"
    description: Optional[str] = Field(None, max_length=500)


# T011: AuthConfig models
class AuthApiKey(BaseModel):
    """API key authentication configuration."""

    header_name: Optional[str] = None
    query_param: Optional[str] = None
    token: str

    @model_validator(mode="after")
    def validate_location(self) -> "AuthApiKey":
        """Ensure either header_name or query_param is specified."""
        if not self.header_name and not self.query_param:
            raise ValueError("Either header_name or query_param must be specified for api_key auth")
        if self.header_name and self.query_param:
            raise ValueError("Cannot specify both header_name and query_param for api_key auth")
        return self


class AuthBearer(BaseModel):
    """Bearer token authentication configuration."""

    token: str


class AuthBasic(BaseModel):
    """Basic authentication configuration."""

    username: str
    password: str


class AuthCustom(BaseModel):
    """Custom headers authentication configuration."""

    headers: dict[str, str]


class AuthConfig(BaseModel):
    """Authentication configuration with type-specific validation."""

    type: AuthType
    # Conditional fields based on type
    api_key: Optional[AuthApiKey] = None
    bearer: Optional[AuthBearer] = None
    basic: Optional[AuthBasic] = None
    custom: Optional[AuthCustom] = None

    @model_validator(mode="after")
    def validate_auth_fields(self) -> "AuthConfig":
        """Validate that required fields for auth type are present."""
        if self.type == AuthType.API_KEY and not self.api_key:
            raise ValueError("api_key field required when type is 'api_key'")
        if self.type == AuthType.BEARER and not self.bearer:
            raise ValueError("bearer field required when type is 'bearer'")
        if self.type == AuthType.BASIC and not self.basic:
            raise ValueError("basic field required when type is 'basic'")
        if self.type == AuthType.CUSTOM and not self.custom:
            raise ValueError("custom field required when type is 'custom'")
        return self


# T012: ParameterSchema
class ParameterSchema(BaseModel):
    """Input parameter definition for MCP tools."""

    name: str
    type: ParameterType
    description: str = Field(..., min_length=20, max_length=500)
    required: bool = False
    default: Optional[Any] = None
    location: ParamLocation

    @field_validator("default")
    @classmethod
    def validate_default_type(cls, v: Any, info: Any) -> Any:
        """Validate default value matches declared type."""
        if v is None:
            return v
        # Type validation happens at runtime during tool invocation
        return v


# T013: FileConfig and RequestConfig
class FileConfig(BaseModel):
    """File upload configuration."""

    max_size_mb: int = Field(100, ge=1, le=1000)
    allowed_types: Optional[list[str]] = None
    field_name: str = "file"
    multiple: bool = False


class RequestConfig(BaseModel):
    """Request-specific configuration overrides."""

    headers: Optional[dict[str, str]] = None
    query_params: Optional[dict[str, str]] = None
    body_type: Optional[BodyType] = None
    timeout: Optional[int] = Field(None, ge=1, le=300)
    files: Optional[FileConfig] = None


# T014: ResponseConfig and ErrorHandling
class ErrorHandling(BaseModel):
    """Error response handling configuration."""

    extract_message_path: Optional[str] = None
    default_message: str = "Request failed"
    include_status_code: bool = True
    include_response_body: bool = False


class ResponseConfig(BaseModel):
    """Response handling and transformation configuration."""

    extract_path: str = "$"
    success_codes: list[int] = [200, 201, 202, 204]
    error_handling: Optional[ErrorHandling] = None


# T015: GlobalConfig
class GlobalConfig(BaseModel):
    """Global configuration applied to all endpoints."""

    base_url: HttpUrl
    timeout: int = Field(30, ge=1, le=300)
    headers: Optional[dict[str, str]] = None
    auth: Optional[AuthConfig] = None


# T016: EndpointConfig
class EndpointConfig(BaseModel):
    """API endpoint configuration that becomes an MCP tool."""

    name: str = Field(..., pattern=r"^[a-zA-Z][a-zA-Z0-9_]*$")
    description: str = Field(..., min_length=20, max_length=500)
    method: HTTPMethod
    path: str
    parameters: Optional[list[ParameterSchema]] = None
    request_config: Optional[RequestConfig] = None
    response_config: Optional[ResponseConfig] = None

    @model_validator(mode="after")
    def validate_method_compatibility(self) -> "EndpointConfig":
        """Validate HTTP method is compatible with parameter locations."""
        if self.parameters:
            for param in self.parameters:
                # GET and DELETE cannot have body parameters
                if self.method in [HTTPMethod.GET, HTTPMethod.DELETE]:
                    if param.location in [ParamLocation.BODY, ParamLocation.FILE]:
                        raise ValueError(
                            f"{self.method} method cannot have {param.location} parameters"
                        )
        return self


# T017: YAMLConfig root model
class YAMLConfig(BaseModel):
    """Root configuration model for YAML files."""

    server: ServerConfig
    global_: GlobalConfig = Field(..., alias="global")
    endpoints: list[EndpointConfig] = Field(..., min_length=1)

    model_config = {"populate_by_name": True}

    @model_validator(mode="after")
    def validate_endpoint_names_unique(self) -> "YAMLConfig":
        """Ensure all endpoint names are unique."""
        names = [ep.name for ep in self.endpoints]
        duplicates = [name for name in names if names.count(name) > 1]
        if duplicates:
            raise ValueError(f"Duplicate endpoint names found: {set(duplicates)}")
        return self
