"""YAML configuration parser with environment variable substitution and validation."""

import logging
import os
import re
from pathlib import Path
from typing import Any

import yaml
from pydantic import ValidationError

from .schema import EndpointConfig, ParamLocation, YAMLConfig

# T083: Setup logger for parser
logger = logging.getLogger(__name__)


def substitute_env_vars(value: Any) -> Any:
    """
    Recursively substitute environment variables in configuration values.
    
    Supports syntax: ${VAR_NAME} or ${VAR_NAME:default_value}
    
    Args:
        value: Configuration value (can be string, dict, list, or primitive)
        
    Returns:
        Value with environment variables substituted
        
    Raises:
        ValueError: If referenced environment variable is not set and no default provided
    """
    if isinstance(value, str):
        # Pattern: ${VAR_NAME} or ${VAR_NAME:default}
        pattern = r'\$\{([^}:]+)(?::([^}]*))?\}'
        
        def replacer(match: re.Match[str]) -> str:
            var_name = match.group(1)
            default_value = match.group(2)
            
            env_value = os.getenv(var_name)
            if env_value is not None:
                logger.debug(f"Substituting environment variable: {var_name}")
                return env_value
            if default_value is not None:
                logger.debug(f"Using default value for {var_name}: {default_value}")
                return default_value
            
            # T085: Detailed error message for missing environment variables
            logger.error(f"Environment variable '{var_name}' is not set and no default value provided")
            raise ValueError(
                f"Environment variable '{var_name}' is not set and no default value provided"
            )
        
        return re.sub(pattern, replacer, value)
    
    elif isinstance(value, dict):
        return {k: substitute_env_vars(v) for k, v in value.items()}
    
    elif isinstance(value, list):
        return [substitute_env_vars(item) for item in value]
    
    else:
        return value


def load_yaml_file(file_path: str | Path) -> dict[str, Any]:
    """
    Load and parse YAML file using safe_load.
    
    Args:
        file_path: Path to YAML configuration file
        
    Returns:
        Parsed YAML as dictionary
        
    Raises:
        FileNotFoundError: If file doesn't exist
        yaml.YAMLError: If YAML syntax is invalid
    """
    path = Path(file_path)
    
    # T083: Log file loading
    logger.info(f"Loading YAML configuration from: {path}")
    
    if not path.exists():
        logger.error(f"Configuration file not found: {file_path}")
        raise FileNotFoundError(f"Configuration file not found: {file_path}")
    
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = yaml.safe_load(f)
        
        if not isinstance(data, dict):
            logger.error(f"YAML file must contain a mapping/object at root, got {type(data)}")
            raise ValueError(f"YAML file must contain a mapping/object at root, got {type(data)}")
        
        logger.debug(f"Successfully loaded YAML file with {len(data)} top-level keys")
        return data
        
    except yaml.YAMLError as e:
        # T084: Detailed error message for YAML validation failures
        logger.error(f"Invalid YAML syntax in {file_path}: {e}")
        raise ValueError(f"Invalid YAML syntax in {file_path}: {e}") from e


def validate_path_parameters(endpoint: EndpointConfig) -> None:
    """
    Validate that path parameters in URL have corresponding parameter definitions.
    
    Args:
        endpoint: Endpoint configuration to validate
        
    Raises:
        ValueError: If path parameters are missing or mismatched
    """
    # Extract {param_name} placeholders from path
    path_placeholders = set(re.findall(r'\{([^}]+)\}', endpoint.path))
    
    if not path_placeholders:
        return  # No path parameters to validate
    
    # Get path parameter names from parameter list
    path_params = {
        param.name 
        for param in (endpoint.parameters or []) 
        if param.location == ParamLocation.PATH
    }
    
    # Check for missing parameter definitions
    missing_defs = path_placeholders - path_params
    if missing_defs:
        raise ValueError(
            f"Endpoint '{endpoint.name}': Path contains placeholders {missing_defs} "
            f"but no corresponding path parameters defined"
        )
    
    # Check for unused parameter definitions
    unused_params = path_params - path_placeholders
    if unused_params:
        raise ValueError(
            f"Endpoint '{endpoint.name}': Path parameters {unused_params} defined "
            f"but not used in path '{endpoint.path}'"
        )


def parse_yaml_config(file_path: str | Path) -> YAMLConfig:
    """
    Parse and validate YAML configuration file.
    
    Performs:
    1. YAML file loading
    2. Environment variable substitution
    3. Pydantic model validation
    4. Cross-field validation (path parameters, method compatibility)
    
    Args:
        file_path: Path to YAML configuration file
        
    Returns:
        Validated YAMLConfig model
        
    Raises:
        FileNotFoundError: If file doesn't exist
        ValueError: If YAML syntax is invalid or validation fails
        ValidationError: If Pydantic validation fails
    """
    logger.info(f"Parsing configuration file: {file_path}")
    
    # T019: Load YAML file
    raw_data = load_yaml_file(file_path)
    
    # T018: Substitute environment variables
    try:
        data = substitute_env_vars(raw_data)
        logger.debug("Environment variable substitution completed")
    except ValueError as e:
        logger.error(f"Environment variable substitution failed: {e}")
        raise ValueError(f"Environment variable substitution failed: {e}") from e
    
    # T020: Validate with Pydantic
    try:
        config = YAMLConfig.model_validate(data)
        logger.info(f"Configuration validated: {config.server.name} v{config.server.version}")
        logger.info(f"Loaded {len(config.endpoints)} endpoint(s)")
    except ValidationError as e:
        # T084: Format validation errors with field locations
        error_messages = []
        for error in e.errors():
            loc = " -> ".join(str(l) for l in error['loc'])
            msg = error['msg']
            error_messages.append(f"  {loc}: {msg}")
        
        error_text = f"Configuration validation failed:\n" + "\n".join(error_messages)
        logger.error(error_text)
        raise ValueError(error_text) from e
    
    # T021: Validate path parameters
    for endpoint in config.endpoints:
        try:
            validate_path_parameters(endpoint)
        except ValueError as e:
            logger.error(f"Path parameter validation failed for '{endpoint.name}': {e}")
            raise ValueError(f"Path parameter validation failed: {e}") from e
    
    # T022: Method compatibility already validated in EndpointConfig.validate_method_compatibility
    # T023: Endpoint name uniqueness already validated in YAMLConfig.validate_endpoint_names_unique
    
    logger.info(f"Configuration parsing completed successfully")
    return config


def parse_multiple_configs(file_paths: list[str | Path]) -> list[YAMLConfig]:
    """
    Parse multiple YAML configuration files.
    
    Args:
        file_paths: List of paths to YAML configuration files
        
    Returns:
        List of validated YAMLConfig models
        
    Raises:
        ValueError: If any configuration is invalid
    """
    logger.info(f"Parsing {len(file_paths)} configuration file(s)")
    
    configs = []
    errors = []
    
    for file_path in file_paths:
        try:
            config = parse_yaml_config(file_path)
            configs.append(config)
        except (FileNotFoundError, ValueError, ValidationError) as e:
            errors.append(f"{file_path}: {e}")
    
    if errors:
        error_text = f"Failed to parse {len(errors)} configuration file(s):\n" + "\n".join(errors)
        logger.error(error_text)
        raise ValueError(error_text)
    
    # T023 & T086: Check for tool name collisions across files
    all_tool_names: dict[str, str] = {}
    for config in configs:
        for endpoint in config.endpoints:
            tool_name = endpoint.name
            if tool_name in all_tool_names:
                error_msg = (
                    f"Tool name collision: '{tool_name}' defined in both "
                    f"{all_tool_names[tool_name]} and {config.server.name}"
                )
                logger.error(error_msg)
                raise ValueError(error_msg)
            all_tool_names[tool_name] = config.server.name
    
    logger.info(f"Successfully parsed {len(configs)} configuration(s)")
    return configs
