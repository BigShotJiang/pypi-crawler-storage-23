"""MCP YAML Configuration Generator.

Generate MCP tools from YAML configuration files for webservice integrations.
"""

__version__ = "1.0.0"
__author__ = "MCP YAML Generator Contributors"
__all__ = ["__version__"]
