"""MCP server setup and tool registration using FastMCP."""

import asyncio
import logging
import signal
from typing import Any, Optional

from fastmcp import FastMCP

from ..client.http_client import HTTPClient
from ..config.schema import YAMLConfig
from ..generator.tool_factory import create_tool_function, generate_tool_descriptor

logger = logging.getLogger(__name__)


class MCPYAMLServer:
    """
    MCP server that dynamically registers tools from YAML configuration.
    
    Manages FastMCP server initialization and tool registration.
    """
    
    def __init__(self, config: YAMLConfig):
        """
        Initialize MCP server with configuration.
        
        Args:
            config: Validated YAML configuration
        """
        self.config = config
        self._shutdown_requested = False
        
        # T031: Initialize FastMCP server
        self.mcp = FastMCP(
            name=config.server.name,
            version=config.server.version,
        )
        
        # Initialize HTTP client with global settings
        self.http_client = HTTPClient(
            base_url=str(config.global_.base_url),
            timeout=config.global_.timeout,
            default_headers=config.global_.headers,
            auth_config=config.global_.auth,  # T052: Pass auth config
        )
        
        # T032: Register tools from configuration
        self._register_tools()
        
        # T091: Setup signal handlers for graceful shutdown
        self._setup_shutdown_handlers()
    
    def _register_tools(self) -> None:
        """
        Register all endpoint configurations as MCP tools.
        
        Creates tool functions and registers them with FastMCP.
        """
        for endpoint in self.config.endpoints:
            # Generate tool descriptor
            descriptor = generate_tool_descriptor(endpoint, self.http_client)
            
            # Extract components
            tool_name = descriptor["name"]
            tool_description = descriptor["description"]
            tool_impl = descriptor["implementation"]
            input_schema = descriptor["input_schema"]
            meta = descriptor.get("meta")

            # Register with FastMCP
            # FastMCP uses decorator pattern, but we can also register programmatically
            # Stash meta on the instance so _register_tool can access it without changing signature
            self._current_tool_meta = meta
            self._register_tool(
                name=tool_name,
                description=tool_description,
                implementation=tool_impl,
                input_schema=input_schema,
            )
    
    def _register_tool(
        self,
        name: str,
        description: str,
        implementation: Any,
        input_schema: dict[str, Any],
    ) -> None:
        """
        Register a single tool with FastMCP.
        
        Args:
            name: Tool name
            description: Tool description
            implementation: Async function implementing the tool
            input_schema: JSON Schema for tool parameters
        """
        # FastMCP tool registration
        # The @mcp.tool decorator would be used for static registration
        # For dynamic registration with FastMCP 2.x, use the .tool() helper
        # Include metadata to expose HTTP method, path, and schema details
        meta = getattr(self, "_current_tool_meta", None)
        self.mcp.tool(
            implementation,
            name=name,
            description=description,
            meta=meta,
        )
    
    async def cleanup(self) -> None:
        """
        Cleanup server resources.
        
        Closes HTTP client connections.
        """
        logger.info("Cleaning up server resources...")
        await self.http_client.close()
        logger.info("Server cleanup completed")
    
    def _setup_shutdown_handlers(self) -> None:
        """
        T091: Setup signal handlers for graceful shutdown.
        
        Registers handlers for SIGINT and SIGTERM to perform cleanup.
        """
        def shutdown_handler(signum: int, frame: Any) -> None:
            """Handle shutdown signals.

            We re-raise KeyboardInterrupt so that anyio/FastMCP can stop its loop
            and our run() method can proceed to the cleanup block.
            """
            signal_name = signal.Signals(signum).name
            logger.info(f"Received {signal_name}, initiating graceful shutdown...")
            self._shutdown_requested = True
            
            # Schedule cleanup in async context when a loop is running
            try:
                loop = asyncio.get_event_loop()
                if loop.is_running():
                    loop.create_task(self.cleanup())
            except RuntimeError:
                # No event loop running, cleanup will happen in run()
                pass

            # Propagate KeyboardInterrupt so FastMCP/anyio can exit
            raise KeyboardInterrupt
        
        # Register signal handlers
        signal.signal(signal.SIGINT, shutdown_handler)
        signal.signal(signal.SIGTERM, shutdown_handler)
        logger.debug("Shutdown handlers registered for SIGINT and SIGTERM")
    
    def run(
        self,
        transport: str = "stdio",
        host: Optional[str] = None,
        port: Optional[int] = None,
    ) -> None:
        """Start the MCP server.
        
        By default uses stdio transport for CLI/MCP clients, but can also run an
        HTTP or streamable HTTP server when requested.
        """
        logger.info(f"Starting MCP server: {self.config.server.name} (transport={transport})")
        
        try:
            # FastMCP handles the server loop
            if transport == "stdio":
                self.mcp.run()
            elif transport in {"http", "streamable-http"}:
                # Use HTTP-based transports with configurable host/port
                bind_host = host or "127.0.0.1"
                bind_port = port or 8000
                logger.info(f"Listening on {bind_host}:{bind_port} via {transport}")
                if transport == "http":
                    self.mcp.run(transport="http", host=bind_host, port=bind_port)
                else:
                    # Use stateless_http for better compatibility with MCP HTTP/SSE clients
                    self.mcp.run(
                        transport="streamable-http",
                        host=bind_host,
                        port=bind_port,
                        stateless_http=True,
                    )
            else:
                raise ValueError(f"Unsupported transport: {transport}")
        except KeyboardInterrupt:
            logger.info("Server interrupted by user")
        finally:
            # T091: Ensure cleanup happens on shutdown
            logger.info("Shutting down server...")
            try:
                # Run cleanup in a new event loop if needed
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                loop.run_until_complete(self.cleanup())
                loop.close()
            except Exception as e:
                logger.error(f"Error during cleanup: {e}")
            
            logger.info("Server shut down complete")


def create_mcp_server(config: YAMLConfig) -> MCPYAMLServer:
    """
    Create and configure MCP server from YAML configuration.
    
    Args:
        config: Validated YAML configuration
        
    Returns:
        Configured MCP server instance
    """
    return MCPYAMLServer(config)


def create_mcp_servers(configs: list[YAMLConfig]) -> list[MCPYAMLServer]:
    """
    Create multiple MCP servers from multiple configurations.
    
    Args:
        configs: List of validated YAML configurations
        
    Returns:
        List of configured MCP server instances
    """
    return [create_mcp_server(config) for config in configs]
