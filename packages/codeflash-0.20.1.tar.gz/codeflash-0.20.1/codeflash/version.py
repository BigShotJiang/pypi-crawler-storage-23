# These version placeholders will be replaced by uv-dynamic-versioning during build.
__version__ = "0.20.1"
