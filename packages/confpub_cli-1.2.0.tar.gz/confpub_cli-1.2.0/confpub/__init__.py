"""confpub — Agent-first CLI to publish Markdown to Confluence."""

__version__ = "1.2.0"
