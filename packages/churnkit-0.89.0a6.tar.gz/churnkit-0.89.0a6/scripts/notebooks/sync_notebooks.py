#!/usr/bin/env python3
from customer_retention.generators.notebook_sync.cli import main

if __name__ == "__main__":
    main()
