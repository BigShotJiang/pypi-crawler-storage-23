:orphan:

=========
Changelog
=========

* :release:`0.1.10 <2019-08-20>`
* :bug:`0` When times of a task is changed, a check is performed over all affected volunteers to see if affectation is still consistent


