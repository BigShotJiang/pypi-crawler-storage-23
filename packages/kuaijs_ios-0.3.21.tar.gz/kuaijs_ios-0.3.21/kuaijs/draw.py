def drawRect(
    x: float,
    y: float,
    ex: float,
    ey: float,
    lineWidth: float = 1.0,
    color: str = "#000000",
) -> str:
    """
    绘制矩形

    Args:
        x (float): 矩形左上角 x 坐标
        y (float): 矩形左上角 y 坐标
        ex (float): 矩形右下角 x 坐标
        ey (float): 矩形右下角 y 坐标
        lineWidth (float, optional): 矩形边框宽度. Defaults to 1.0.
        color (str, optional): 矩形边框颜色，支持#RRGGBB、#AARRGGBB、rgb(r,g,b)、rgba(r,g,b,a)格式. Defaults to "#000000".

    Returns:
        str: 绘制的矩形ID，用于后续操作

    Example:
        >>> rectId = draw.drawRect(0, 0, 100, 100)
    """
    return ""


def drawCircle(
    x: float,
    y: float,
    radius: float,
    lineWidth: float = 1.0,
    color: str = "#000000",
) -> str:
    """
    绘制圆

    Args:
        x (float): 圆中心 x 坐标
        y (float): 圆中心 y 坐标
        radius (float): 圆半径
        lineWidth (float, optional): 线宽. Defaults to 1.0.
        color (str, optional): 颜色，支持#RRGGBB、#AARRGGBB、rgb(r,g,b)、rgba(r,g,b,a)格式. Defaults to "#000000".

    Returns:
        str: 绘制的圆ID，用于后续操作

    Example:
        >>> circleId = draw.drawCircle(50, 50, 25)
    """
    return ""


def drawText(
    text: str,
    x: float,
    y: float,
    ex: float,
    ey: float,
    fontSize: float = 12.0,
    color: str = "#000000",
    bgColor: str = "transparent",
) -> str:
    """
    绘制文本

    Args:
        text (str): 文本内容
        x (float): 文本左上角 x 坐标
        y (float): 文本左上角 y 坐标
        ex (float): 文本右下角 x 坐标
        ey (float): 文本右下角 y 坐标
        fontSize (float, optional): 字体大小. Defaults to 12.0.
        color (str, optional): 颜色，支持#RRGGBB、#AARRGGBB、rgb(r,g,b)、rgba(r,g,b,a)格式. Defaults to "#000000".
        bgColor (str, optional): 背景颜色，支持#RRGGBB、#AARRGGBB、rgb(r,g,b)、rgba(r,g,b,a)格式. Defaults to "transparent".

    Returns:
        str: 绘制的文本ID，用于后续操作

    Example:
        >>> textId = draw.drawText("Hello, World!", 0, 0, 100, 100)
    """
    return ""


def clear(id: str = "") -> None:
    """
    清除绘制内容

    Args:
        id (str, optional): 绘制的内容ID。不传清除所有绘制内容，传ID清除指定绘制内容. Defaults to "".

    Example:
        >>> draw.clear("rect1")
        >>> draw.clear()
    """
    pass


def close() -> None:
    """
    关闭绘制层并清除绘图模块

    Example:
        >>> draw.close()
    """
    pass


def show() -> None:
    """
    显示绘制层

    Example:
        >>> draw.show()
    """
    pass


def hide() -> None:
    """
    隐藏绘制层

    Example:
        >>> draw.hide()
    """
    pass
