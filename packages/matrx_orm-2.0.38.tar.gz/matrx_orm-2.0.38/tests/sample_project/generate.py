from matrx_orm.schema_builder import run_schema_generation
from matrx_utils import clear_terminal


clear_terminal()


run_schema_generation("matrx_orm.yaml")
