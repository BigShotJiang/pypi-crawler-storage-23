"""
Bamboo Examples Module

Contains example scripts for using the Bamboo Franka controller.
"""
