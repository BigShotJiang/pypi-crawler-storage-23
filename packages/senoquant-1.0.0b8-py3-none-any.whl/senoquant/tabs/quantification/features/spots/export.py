"""Spots feature export logic.

This module always exports a **spots** table with per-spot geometry, ROI
membership, and channel metadata.

When one or more valid nuclear/cytoplasmic segmentations are configured, it
also exports matching **cells** tables with morphology and per-channel spot
summaries (counts and mean spot intensity per cell).

The export matches the markers feature style for morphology and physical
unit reporting. If physical pixel sizes are available in the metadata for
the first configured channel image, both pixel and physical units are
saved for centroids and areas/volumes.
It also writes segmentation mask arrays and a unified settings bundle
containing per-layer run history for future settings reload workflows.
"""

from __future__ import annotations

import csv
from dataclasses import asdict
import json
import warnings
from pathlib import Path
from typing import Iterable, Sequence, TYPE_CHECKING

import numpy as np
from skimage.measure import regionprops_table

from senoquant.utils.settings_bundle import build_settings_bundle
from senoquant.utils import layer_data_asarray
from .config import SpotsFeatureData
from ..base import FeatureConfig
from .morphology import add_morphology_columns

if TYPE_CHECKING:
    from ..roi import ROIConfig

OVERLAP_PAIR_CHUNK_SIZE = 8_000_000


def export_spots(
    feature: FeatureConfig,
    temp_dir: Path,
    viewer=None,
    export_format: str = "csv",
) -> Iterable[Path]:
    """Export spots feature outputs into a temporary directory.

    Parameters
    ----------
    feature : FeatureConfig
        Spots feature configuration to export. Must contain a
        :class:`SpotsFeatureData` payload with at least one channel.
        Cell segmentations are optional.
    temp_dir : Path
        Temporary directory where outputs should be written.
    viewer : object, optional
        napari viewer instance used to resolve layers by name and read
        layer data. When ``None``, export is skipped.
    export_format : str, optional
        File format for exports (``"csv"`` or ``"xlsx"``). Values are
        normalized to lower case.

    Returns
    -------
    iterable of Path
        Paths to files produced by the export routine.
        - With valid segmentations: each segmentation produces
          ``*_cells`` and ``*_spots`` tables.
        - Without valid segmentations: a single ``all_spots`` table is
          produced.
        Segmentation masks (``.npy``) and a shared
        ``feature_settings.json`` bundle are also written, including
        timestamped run history for layer run ordering. If no outputs are
        produced, an empty list is returned.

    Notes
    -----
    - Cell morphology comes from segmentation labels when segmentation is
      configured.
    - Spot-to-cell assignment is based on the spot centroid location.
      Spots whose centroids fall outside segmentation are retained in the
      spots table with ``cell_id = 0`` and ``within_segmentation = 0``.
      Per-cell spot metrics count only spots with ``within_segmentation = 1``.
    - Spot intensities are computed from the channel image referenced by
      each channel config. Missing or mismatched images result in ``NaN``
      mean intensities for those spots.
    - When ``export_colocalization`` is enabled on the feature, additional
      colocalization columns are appended to both tables.
    - Physical units are derived from ``layer.metadata["physical_pixel_sizes"]``
      when available (same convention as the markers export).

    Workflow summary
    ----------------
    1. Resolve configured cell segmentations (if any) and compute cell
       morphology.
    2. Build per-channel spot exports (counts, mean intensity, spot rows).
    3. Optionally compute colocalization adjacency and append columns.
    4. Write ``*_cells`` + ``*_spots`` per segmentation, or ``all_spots``
       when no valid cell segmentation exists.
    """
    data = feature.data
    if not isinstance(data, SpotsFeatureData) or viewer is None:
        return []

    # --- Normalize inputs and pre-filter channel configs ---
    export_format = (export_format or "csv").lower()
    outputs: list[Path] = []
    segmentation_runs: list[dict[str, object]] = []
    exported_layers: set[tuple[str, str]] = set()
    channels = [
        channel
        for channel in data.channels
        if channel.channel and channel.spots_segmentation
    ]
    # Channels are required; segmentation filters are optional.
    if not channels:
        return []

    if len(data.segmentations) > 1:
        cross_map = _build_cell_cross_segmentation_map(viewer, data.segmentations)
    else:
        cross_map = {}

    # --- Resolve a reference channel for physical pixel sizes ---
    first_channel_layer = None
    for channel in channels:
        first_channel_layer = _find_layer(viewer, channel.channel, "Image")
        if first_channel_layer is not None:
            break
    file_path = ""
    if first_channel_layer is not None:
        metadata = getattr(first_channel_layer, "metadata", None)
        if isinstance(metadata, dict):
            raw_path = metadata.get("path")
            if raw_path:
                file_path = str(raw_path)

    valid_segmentations: list[
        tuple[int, str, object, np.ndarray, np.ndarray, np.ndarray]
    ] = []
    for index, segmentation in enumerate(data.segmentations, start=0):
        label_name = segmentation.label.strip()
        if not label_name:
            continue
        labels_layer = _find_layer(viewer, label_name, "Labels")
        if labels_layer is None:
            continue
        cell_labels = layer_data_asarray(labels_layer)
        if cell_labels.size == 0:
            continue
        cell_ids, cell_centroids = _compute_centroids(cell_labels)
        if cell_ids.size == 0:
            continue
        valid_segmentations.append(
            (
                index,
                label_name,
                labels_layer,
                cell_labels,
                cell_ids,
                cell_centroids,
            )
        )

    segmentation_contexts: list[
        tuple[int, str | None, object | None, np.ndarray | None, np.ndarray, np.ndarray]
    ] = []
    for (
        index,
        label_name,
        labels_layer,
        cell_labels,
        cell_ids,
        cell_centroids,
    ) in valid_segmentations:
        segmentation_contexts.append(
            (index, label_name, labels_layer, cell_labels, cell_ids, cell_centroids)
        )
    if not segmentation_contexts:
        segmentation_contexts.append(
            (
                0,
                None,
                None,
                None,
                np.empty((0,), dtype=int),
                np.empty((0, 0), dtype=float),
            )
        )

    for (
        index,
        label_name,
        labels_layer,
        cell_labels,
        cell_ids,
        cell_centroids,
    ) in segmentation_contexts:
        has_segmentation = (
            label_name is not None and labels_layer is not None and cell_labels is not None
        )
        if has_segmentation:
            assert label_name is not None
            assert labels_layer is not None
            assert cell_labels is not None
            file_stem = _sanitize_name(label_name or f"segmentation_{index}")
            cell_task = _segmentation_task_from_layer(
                labels_layer, label_name, default_task="nuclear"
            )
            if ("cell_segmentation", label_name) not in exported_layers:
                mask_path = _write_mask_output(
                    temp_dir,
                    stem=f"{file_stem}_cells_mask",
                    labels=cell_labels,
                )
                outputs.append(mask_path)
                segmentation_runs.append(
                    {
                        "layer_name": label_name,
                        "role": "cell_segmentation",
                        "task": cell_task,
                        "mask_file": mask_path.name,
                        "run_history": _layer_run_history(labels_layer),
                    }
                )
                exported_layers.add(("cell_segmentation", label_name))
        else:
            file_stem = "all"

        # --- Derive physical pixel sizes from metadata if available ---
        cell_pixel_sizes = None
        if has_segmentation and cell_labels is not None and labels_layer is not None:
            cell_pixel_sizes = _pixel_sizes(labels_layer, cell_labels.ndim)
            if cell_pixel_sizes is None and first_channel_layer is not None:
                cell_pixel_sizes = _pixel_sizes(
                    first_channel_layer, cell_labels.ndim
                )

        # --- Seed the cell table with morphology and ROI membership columns ---
        cell_rows: list[dict[str, object]] = []
        cell_header: list[str] = []
        if has_segmentation and cell_labels is not None and label_name is not None:
            cell_rows = _initialize_rows(
                cell_ids,
                cell_centroids,
                cell_pixel_sizes,
            )
            for row in cell_rows:
                row["file_path"] = file_path
            add_morphology_columns(
                cell_rows, cell_labels, cell_ids, cell_pixel_sizes
            )
            _add_roi_columns(
                cell_rows,
                cell_labels,
                cell_ids,
                viewer,
                data.rois,
                label_name,
            )
            _add_cross_reference_column(cell_rows, label_name, cell_ids, cross_map)
            cell_header = list(cell_rows[0].keys()) if cell_rows else []

        # --- Resolve per-channel label layers before heavy computation ---
        spot_shape: tuple[int, ...] | None = None
        if has_segmentation and cell_labels is not None and label_name is not None:
            channel_entries = _build_channel_entries(
                viewer,
                channels,
                cell_labels.shape,
                label_name,
            )
            spot_shape = cell_labels.shape
        else:
            channel_entries, spot_shape = _build_channel_entries_without_segmentation(
                viewer,
                channels,
            )
        if spot_shape is None:
            continue

        for entry in channel_entries:
            spot_layer_name = str(entry.get("spots_layer_name", "")).strip()
            spot_layer = entry.get("spots_layer")
            if (
                not spot_layer_name
                or spot_layer is None
                or ("spots_segmentation", spot_layer_name) in exported_layers
            ):
                continue
            spot_task = _segmentation_task_from_layer(
                spot_layer, spot_layer_name, default_task="spots"
            )
            spot_mask = np.asarray(entry.get("spots_labels"))
            mask_path = _write_mask_output(
                temp_dir,
                stem=f"{_sanitize_name(spot_layer_name)}_spots_mask",
                labels=spot_mask,
            )
            outputs.append(mask_path)
            segmentation_runs.append(
                {
                    "layer_name": spot_layer_name,
                    "role": "spots_segmentation",
                    "task": spot_task,
                    "mask_file": mask_path.name,
                    "run_history": _layer_run_history(spot_layer),
                }
            )
            exported_layers.add(("spots_segmentation", spot_layer_name))

        # --- Prepare containers and ROI masks for the spots table ---
        spot_rows: list[dict[str, object]] = []
        spot_header: list[str] = []
        spot_table_pixel_sizes = None
        if first_channel_layer is not None:
            spot_table_pixel_sizes = _pixel_sizes(
                first_channel_layer, len(spot_shape)
            )
        spot_roi_columns = _spot_roi_columns(
            viewer,
            data.rois,
            label_name or "all_spots",
            spot_shape,
        )

        adjacency: dict[tuple[int, int], set[tuple[int, int]]] = {}
        if data.export_colocalization and len(channel_entries) >= 2:
            adjacency = _build_colocalization_adjacency(channel_entries)

        # --- Compute per-channel cell metrics + per-spot rows ---
        spot_lookup: dict[tuple[int, int], dict[str, object]] = {}
        for channel_index, entry in enumerate(channel_entries):
            _append_channel_exports(
                channel_index,
                entry,
                cell_labels,
                cell_ids,
                cell_header,
                cell_rows,
                spot_rows,
                spot_header,
                spot_lookup,
                spot_table_pixel_sizes,
                spot_roi_columns,
                file_path,
            )

        # --- Apply colocalization columns (if requested) ---
        if data.export_colocalization:
            max_cell_id = int(cell_labels.max()) if cell_labels is not None else 0
            _apply_colocalization_columns(
                cell_rows,
                cell_ids,
                cell_header,
                spot_rows,
                spot_lookup,
                adjacency,
                channel_entries,
                max_cell_id,
            )

        # --- Emit cells and spots tables for the segmentation ---
        if has_segmentation and cell_rows:
            cell_path = temp_dir / f"{file_stem}_cells.{export_format}"
            _write_table(cell_path, cell_header, cell_rows, export_format)
            outputs.append(cell_path)
        if not spot_header:
            spot_header = _spot_header(
                len(spot_shape),
                spot_table_pixel_sizes,
                spot_roi_columns,
                include_within_segmentation=has_segmentation,
            )
        if data.export_colocalization:
            if "colocalizes_with" not in spot_header:
                spot_header.append("colocalizes_with")
            for row in spot_rows:
                row.setdefault("colocalizes_with", "")
        spot_path = temp_dir / f"{file_stem}_spots.{export_format}"
        _write_table(spot_path, spot_header, spot_rows, export_format)
        outputs.append(spot_path)

    settings_path = _write_spots_settings_bundle(
        temp_dir=temp_dir,
        feature=feature,
        data=data,
        export_format=export_format,
        segmentation_runs=segmentation_runs,
    )
    if settings_path is not None:
        outputs.append(settings_path)

    return outputs


def _build_cell_cross_segmentation_map(
    viewer: object, segmentations: Sequence[object]
) -> dict[tuple[str, int], list[tuple[str, int]]]:
    """Build overlap mapping for configured cell segmentations.

    Parameters
    ----------
    viewer : object
        napari viewer instance containing labels layers.
    segmentations : sequence of object
        Segmentation configs with ``label`` attributes.

    Returns
    -------
    dict
        Mapping from ``(segmentation_name, label_id)`` to overlapping
        ``(other_segmentation_name, other_label_id)`` entries.
    """
    all_segmentations: dict[str, tuple[np.ndarray, np.ndarray]] = {}
    for segmentation in segmentations:
        label_name = str(getattr(segmentation, "label", "")).strip()
        if not label_name:
            continue
        labels_layer = _find_layer(viewer, label_name, "Labels")
        if labels_layer is None:
            continue
        labels = layer_data_asarray(labels_layer)
        if labels.size == 0:
            continue
        label_ids = _nonzero_label_ids(labels)
        if label_ids.size == 0:
            continue
        all_segmentations[label_name] = (labels, label_ids)
    return _build_cross_segmentation_map(all_segmentations)


def _build_cross_segmentation_map(
    all_segmentations: dict[str, tuple[np.ndarray, np.ndarray]]
) -> dict[tuple[str, int], list[tuple[str, int]]]:
    """Build bidirectional overlap mapping across segmentations.

    Parameters
    ----------
    all_segmentations : dict
        Mapping from segmentation name to ``(labels, label_ids)`` tuples.

    Returns
    -------
    dict
        Mapping from ``(seg_name, label_id)`` to list of overlapping
        ``(other_seg_name, other_label_id)`` tuples.
    """
    cross_map: dict[tuple[str, int], list[tuple[str, int]]] = {}
    valid_ids: dict[str, set[int]] = {}

    for seg_name, (_labels, label_ids) in all_segmentations.items():
        ids = {int(label_id) for label_id in np.asarray(label_ids, dtype=int)}
        valid_ids[seg_name] = ids
        for label_id in ids:
            cross_map[(seg_name, label_id)] = []

    seg_names = list(all_segmentations.keys())
    for idx_a, seg_name_a in enumerate(seg_names):
        labels_a, _label_ids_a = all_segmentations[seg_name_a]
        for seg_name_b in seg_names[idx_a + 1 :]:
            labels_b, _label_ids_b = all_segmentations[seg_name_b]
            if labels_a.shape != labels_b.shape:
                warnings.warn(
                    "Spots export: segmentation shape mismatch for "
                    f"'{seg_name_a}' vs '{seg_name_b}'. "
                    "Skipping cross-segmentation overlap mapping for this pair.",
                    RuntimeWarning,
                )
                continue

            for label_id_a, label_id_b in _unique_overlap_pairs(
                labels_a, labels_b, chunk_size=OVERLAP_PAIR_CHUNK_SIZE
            ):
                id_a = int(label_id_a)
                id_b = int(label_id_b)
                if (
                    id_a not in valid_ids[seg_name_a]
                    or id_b not in valid_ids[seg_name_b]
                ):
                    continue
                cross_map[(seg_name_a, id_a)].append((seg_name_b, id_b))
                cross_map[(seg_name_b, id_b)].append((seg_name_a, id_a))

    return cross_map


def _add_cross_reference_column(
    rows: list[dict[str, object]],
    segmentation_name: str,
    label_ids: np.ndarray,
    cross_map: dict[tuple[str, int], list[tuple[str, int]]],
) -> str:
    """Add cross-segmentation overlap references to cell rows.

    Parameters
    ----------
    rows : list of dict
        Cell table rows to update in-place.
    segmentation_name : str
        Name of the segmentation being exported.
    label_ids : numpy.ndarray
        Cell label ids corresponding to ``rows``.
    cross_map : dict
        Overlap mapping from :func:`_build_cross_segmentation_map`.

    Returns
    -------
    str
        Name of the added column (``"overlaps_with"``).
    """
    for row, label_id in zip(rows, label_ids):
        overlaps = cross_map.get((segmentation_name, int(label_id)), [])
        if overlaps:
            row["overlaps_with"] = ";".join(
                f"{seg_name}_{other_id}" for seg_name, other_id in overlaps
            )
        else:
            row["overlaps_with"] = ""
    return "overlaps_with"


def _build_channel_entries(
    viewer: object,
    channels: list,
    cell_shape: tuple[int, ...],
    label_name: str,
) -> list[dict[str, object]]:
    """Resolve channel layers into export-ready entries.

    Parameters
    ----------
    viewer : object
        napari viewer instance used to resolve layers.
    channels : list
        Spots channel configurations (image + labels names).
    cell_shape : tuple of int
        Shape of the cell segmentation labels for validation.
    label_name : str
        Cell labels layer name (for warning context).

    Returns
    -------
    list of dict
        Each entry includes:
        - ``channel_label`` : str
            Display label for the channel.
        - ``channel_layer`` : object or None
            Image layer for intensity calculation.
        - ``spots_labels`` : numpy.ndarray
            Spots segmentation labels aligned to ``cell_shape``.

    Notes
    -----
    Channels are filtered out when their segmentation layer is missing or
    the segmentation does not match the cell labels shape.
    """
    entries: list[dict[str, object]] = []
    for channel in channels:
        # Resolve channel display label and layer references.
        channel_label = _channel_label(channel)
        channel_layer = _find_layer(viewer, channel.channel, "Image")
        spots_layer = _find_layer(viewer, channel.spots_segmentation, "Labels")
        if spots_layer is None:
            warnings.warn(
                "Spots export: spots segmentation layer "
                f"'{channel.spots_segmentation}' not found.",
                RuntimeWarning,
            )
            continue
        spots_labels = layer_data_asarray(spots_layer)
        if spots_labels.shape != cell_shape:
            warnings.warn(
                "Spots export: segmentation shape mismatch for "
                f"'{label_name}' vs '{channel.spots_segmentation}'. "
                "Skipping this channel for the segmentation.",
                RuntimeWarning,
            )
            continue
        entries.append(
            {
                "channel_label": channel_label,
                "channel_layer": channel_layer,
                "spots_layer": spots_layer,
                "spots_layer_name": channel.spots_segmentation,
                "spots_labels": spots_labels,
            }
        )
    return entries


def _build_channel_entries_without_segmentation(
    viewer: object,
    channels: list,
) -> tuple[list[dict[str, object]], tuple[int, ...] | None]:
    """Resolve channels for export when no cell segmentation is configured.

    Parameters
    ----------
    viewer : object
        napari viewer instance used to resolve layers.
    channels : list
        Spots channel configurations (image + labels names).

    Returns
    -------
    tuple
        ``(entries, shape)`` where ``entries`` mirrors
        :func:`_build_channel_entries` and ``shape`` is the shared spots
        segmentation shape used for ROI checks and header generation.
    """
    entries: list[dict[str, object]] = []
    reference_shape: tuple[int, ...] | None = None
    for channel in channels:
        channel_label = _channel_label(channel)
        channel_layer = _find_layer(viewer, channel.channel, "Image")
        spots_layer = _find_layer(viewer, channel.spots_segmentation, "Labels")
        if spots_layer is None:
            warnings.warn(
                "Spots export: spots segmentation layer "
                f"'{channel.spots_segmentation}' not found.",
                RuntimeWarning,
            )
            continue
        spots_labels = layer_data_asarray(spots_layer)
        if reference_shape is None:
            reference_shape = spots_labels.shape
        elif spots_labels.shape != reference_shape:
            warnings.warn(
                "Spots export: segmentation shape mismatch for unsegmented export "
                f"'{channel.spots_segmentation}' vs {reference_shape}. "
                "Skipping this channel.",
                RuntimeWarning,
            )
            continue
        entries.append(
            {
                "channel_label": channel_label,
                "channel_layer": channel_layer,
                "spots_layer": spots_layer,
                "spots_layer_name": channel.spots_segmentation,
                "spots_labels": spots_labels,
            }
        )
    return entries, reference_shape


def _append_channel_exports(
    channel_index: int,
    entry: dict[str, object],
    cell_labels: np.ndarray | None,
    cell_ids: np.ndarray,
    cell_header: list[str],
    cell_rows: list[dict[str, object]],
    spot_rows: list[dict[str, object]],
    spot_header: list[str],
    spot_lookup: dict[tuple[int, int], dict[str, object]],
    spot_table_pixel_sizes: np.ndarray | None,
    spot_roi_columns: list[tuple[str, np.ndarray]],
    file_path: str,
) -> None:
    """Compute and append per-channel cell/spot metrics.

    Parameters
    ----------
    channel_index : int
        Index of the channel in the resolved channel list.
    entry : dict
        Channel entry from :func:`_build_channel_entries`.
    cell_labels : numpy.ndarray or None
        Cell segmentation labels array. ``None`` means no cell segmentation
        is available and all spots are exported without cell assignment.
    cell_ids : numpy.ndarray
        Cell ids derived from the segmentation.
    cell_header : list of str
        Header list for the cells table, updated in-place.
    cell_rows : list of dict
        Cell rows updated in-place.
    spot_rows : list of dict
        Spot rows appended to in-place.
    spot_header : list of str
        Spot header list updated in-place.
    spot_lookup : dict
        Mapping from ``(channel_index, spot_id)`` to row metadata.
    spot_table_pixel_sizes : numpy.ndarray or None
        Pixel sizes to use for spot physical units.
    spot_roi_columns : list of tuple
        ROI masks for spot ROI membership columns.
    file_path : str
        Source image path copied to exported spot rows.

    Notes
    -----
    Spot rows are always exported for every detected spot. When cell
    segmentation exists, spot rows include a ``within_segmentation`` flag
    and keep ``cell_id = 0`` for spots outside segmentation.
    """
    channel_label = entry["channel_label"]
    channel_layer = entry["channel_layer"]
    spots_labels = entry["spots_labels"]
    has_segmentation = cell_labels is not None and cell_rows and cell_ids.size > 0

    # Compute spot centroids in the channel segmentation.
    spot_ids, spot_centroids = _compute_centroids(spots_labels)
    if spot_ids.size == 0:
        # No spots -> still emit per-cell count/mean columns with zeros/nans.
        if has_segmentation:
            _append_cell_metrics(
                cell_rows,
                np.zeros_like(cell_ids, dtype=int),
                np.full_like(cell_ids, np.nan, dtype=float),
                channel_label,
                cell_header,
            )
        return

    # Spot areas (pixels) and mean intensity (per spot).
    spot_area_px = _pixel_counts(spots_labels, spot_ids)
    spot_mean_intensity = None
    if channel_layer is not None:
        image = layer_data_asarray(channel_layer)
        if image.shape != spots_labels.shape:
            warnings.warn(
                "Spots export: image/spot shape mismatch for "
                f"'{channel_label}'. Spot intensity values will be empty.",
                RuntimeWarning,
            )
        else:
            raw_sum = _intensity_sum(spots_labels, image, spot_ids)
            spot_mean_intensity = _safe_divide(raw_sum, spot_area_px)
    if spot_mean_intensity is None:
        spot_mean_intensity = np.full(spot_area_px.shape, np.nan, dtype=float)

    # Assign spots to cells using the centroid location when segmentation exists.
    if has_segmentation and cell_labels is not None:
        cell_ids_for_spots = _spot_cell_ids_from_centroids(
            cell_labels, spot_centroids
        )
        within_segmentation = cell_ids_for_spots > 0
        valid_cell_ids = cell_ids_for_spots[within_segmentation]
        valid_means = spot_mean_intensity[within_segmentation]
        cell_counts, cell_means = _cell_spot_metrics(
            valid_cell_ids, valid_means, int(cell_labels.max())
        )
        _append_cell_metrics(
            cell_rows,
            cell_counts[cell_ids],
            cell_means[cell_ids],
            channel_label,
            cell_header,
        )
    else:
        cell_ids_for_spots = np.zeros_like(spot_ids, dtype=int)
        within_segmentation = np.ones_like(spot_ids, dtype=bool)

    # Append per-spot rows for this channel (all spots), preserving ROI membership.
    spot_rows_for_channel = _spot_rows(
        spot_ids,
        cell_ids_for_spots,
        spot_centroids,
        spot_area_px,
        spot_mean_intensity,
        channel_label,
        spot_table_pixel_sizes,
        spot_roi_columns,
        file_path,
        within_segmentation=within_segmentation if has_segmentation else None,
    )
    if spot_rows_for_channel:
        if not spot_header:
            spot_header.extend(list(spot_rows_for_channel[0].keys()))
        for row, spot_id, cell_id in zip(
            spot_rows_for_channel, spot_ids, cell_ids_for_spots
        ):
            spot_lookup[(channel_index, int(spot_id))] = {
                "row": row,
                "cell_id": int(cell_id),
            }
        spot_rows.extend(spot_rows_for_channel)


def _build_colocalization_adjacency(
    channel_entries: list[dict[str, object]]
) -> dict[tuple[int, int], set[tuple[int, int]]]:
    """Build adjacency between overlapping spots across channels.

    Parameters
    ----------
    channel_entries : list of dict
        Channel entries with ``spots_labels`` arrays.

    Returns
    -------
    dict
        Mapping of ``(channel_index, spot_id)`` to a set of overlapping
        ``(channel_index, spot_id)`` pairs.

    Notes
    -----
    Two spots are considered colocalized when their label masks overlap.
    """
    adjacency: dict[tuple[int, int], set[tuple[int, int]]] = {}
    for idx_a, entry_a in enumerate(channel_entries):
        labels_a = entry_a["spots_labels"]
        for idx_b in range(idx_a + 1, len(channel_entries)):
            labels_b = channel_entries[idx_b]["spots_labels"]
            for spot_a, spot_b in _unique_overlap_pairs(
                labels_a, labels_b, chunk_size=OVERLAP_PAIR_CHUNK_SIZE
            ):
                key_a = (idx_a, int(spot_a))
                key_b = (idx_b, int(spot_b))
                adjacency.setdefault(key_a, set()).add(key_b)
                adjacency.setdefault(key_b, set()).add(key_a)
    return adjacency


def _apply_colocalization_columns(
    cell_rows: list[dict[str, object]],
    cell_ids: np.ndarray,
    cell_header: list[str],
    spot_rows: list[dict[str, object]],
    spot_lookup: dict[tuple[int, int], dict[str, object]],
    adjacency: dict[tuple[int, int], set[tuple[int, int]]],
    channel_entries: list[dict[str, object]],
    max_cell_id: int,
) -> None:
    """Append colocalization columns to cell and spot rows.

    Parameters
    ----------
    cell_rows : list of dict
        Cell rows updated in-place.
    cell_ids : numpy.ndarray
        Cell id array aligned to ``cell_rows``.
    cell_header : list of str
        Cell header updated in-place.
    spot_rows : list of dict
        Spot rows updated in-place.
    spot_lookup : dict
        Mapping from ``(channel_index, spot_id)`` to spot row and cell id.
    adjacency : dict
        Colocalization adjacency built by
        :func:`_build_colocalization_adjacency`.
    channel_entries : list of dict
        Channel entries used to map channel indices to labels.
    max_cell_id : int
        Maximum cell id in the segmentation, used to size count arrays.

    Notes
    -----
    ``colocalizes_with`` is a semicolon-delimited list of
    ``"<channel_label>:<spot_id>"`` entries.
    ``colocalization_event_count`` counts unique overlapping spot pairs
    within the same cell.
    """
    channel_labels = [entry["channel_label"] for entry in channel_entries]
    for key, info in spot_lookup.items():
        others = adjacency.get(key, set())
        names: list[str] = []
        for other in others:
            if other not in spot_lookup:
                continue
            other_label = channel_labels[other[0]]
            names.append(f"{other_label}:{other[1]}")
        info["row"]["colocalizes_with"] = (
            ";".join(sorted(set(names))) if names else ""
        )
    for row in spot_rows:
        row.setdefault("colocalizes_with", "")

    colocalization_key = "colocalization_event_count"
    event_counts = np.zeros(max_cell_id + 1, dtype=int)
    seen_pairs: set[tuple[tuple[int, int], tuple[int, int]]] = set()
    for key, others in adjacency.items():
        if key not in spot_lookup:
            continue
        for other in others:
            if other not in spot_lookup:
                continue
            pair = (key, other) if key < other else (other, key)
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)
            cell_id_a = spot_lookup[key]["cell_id"]
            cell_id_b = spot_lookup[other]["cell_id"]
            if cell_id_a > 0 and cell_id_a == cell_id_b:
                event_counts[cell_id_a] += 1
    for row, cell_id in zip(cell_rows, cell_ids):
        row[colocalization_key] = int(event_counts[cell_id])
    if colocalization_key not in cell_header:
        cell_header.append(colocalization_key)


def _find_layer(viewer, name: str, layer_type: str):
    """Return a viewer layer by name and class name.

    Parameters
    ----------
    viewer : object
        napari viewer instance containing layers.
    name : str
        Layer name to locate.
    layer_type : str
        Layer class name to match (e.g., ``"Image"`` or ``"Labels"``).

    Returns
    -------
    object or None
        Matching layer instance, or ``None`` if not found.
    """
    for layer in viewer.layers:
        if layer.__class__.__name__ == layer_type and layer.name == name:
            return layer
    return None


def _compute_centroids(labels: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Compute centroid coordinates for each non-zero label.

    Parameters
    ----------
    labels : numpy.ndarray
        Integer label image. ``0`` is treated as background.

    Returns
    -------
    tuple of numpy.ndarray
        ``(label_ids, centroids)`` where ``label_ids`` is a 1D array of
        label ids and ``centroids`` is an ``(N, D)`` array of centroid
        coordinates in pixel units.
    """
    props = regionprops_table(labels, properties=("label", "centroid"))
    label_ids = np.asarray(props.get("label", []), dtype=int)
    centroid_cols = [key for key in props if key.startswith("centroid-")]
    if not centroid_cols:
        return label_ids, np.empty((0, labels.ndim), dtype=float)
    centroids = np.column_stack([props[key] for key in centroid_cols]).astype(
        float
    )
    return label_ids, centroids


def _pixel_counts(labels: np.ndarray, label_ids: np.ndarray) -> np.ndarray:
    """Return pixel counts for each label id.

    Parameters
    ----------
    labels : numpy.ndarray
        Integer label image.
    label_ids : numpy.ndarray
        Label ids to extract counts for.

    Returns
    -------
    numpy.ndarray
        Pixel counts for each provided label id.
    """
    labels_flat = labels.ravel()
    max_label = int(labels_flat.max()) if labels_flat.size else 0
    counts = np.bincount(labels_flat, minlength=max_label + 1)
    return counts[label_ids]


def _intensity_sum(
    labels: np.ndarray, image: np.ndarray, label_ids: np.ndarray
) -> np.ndarray:
    """Return raw intensity sums for each label id.

    Parameters
    ----------
    labels : numpy.ndarray
        Integer label image.
    image : numpy.ndarray
        Image data aligned to ``labels``.
    label_ids : numpy.ndarray
        Label ids to extract sums for.

    Returns
    -------
    numpy.ndarray
        Raw integrated intensities for each provided label id.
    """
    labels_flat = labels.ravel()
    image_flat = image.ravel()
    if np.isfinite(image_flat).all():
        weights = image_flat
    else:
        weights = np.nan_to_num(image_flat, nan=0.0)
    max_label = int(labels_flat.max()) if labels_flat.size else 0
    sums = np.bincount(labels_flat, weights=weights, minlength=max_label + 1)
    return sums[label_ids]


def _nonzero_label_ids(labels: np.ndarray) -> np.ndarray:
    """Return sorted non-zero label ids present in ``labels``."""
    unique = np.unique(labels)
    return unique[unique > 0].astype(int, copy=False)


def _unique_overlap_pairs(
    labels_a: np.ndarray,
    labels_b: np.ndarray,
    *,
    chunk_size: int,
) -> list[tuple[int, int]]:
    """Return unique non-zero overlap pairs between two labels arrays.

    Uses chunked uint64 bit-packing to reduce peak memory usage on large
    arrays. Falls back to full-array pair extraction when label ids exceed
    uint32 bounds.
    """
    max_u32 = np.iinfo(np.uint32).max
    max_label_a = int(labels_a.max()) if labels_a.size else 0
    max_label_b = int(labels_b.max()) if labels_b.size else 0
    if max_label_a > max_u32 or max_label_b > max_u32:
        mask = (labels_a > 0) & (labels_b > 0)
        if not np.any(mask):
            return []
        pairs = np.column_stack((labels_a[mask], labels_b[mask]))
        unique_pairs = np.unique(pairs, axis=0)
        return [(int(label_a), int(label_b)) for label_a, label_b in unique_pairs]

    flat_a = labels_a.ravel()
    flat_b = labels_b.ravel()
    encoded_pairs: set[int] = set()
    for start in range(0, flat_a.size, chunk_size):
        chunk_a = flat_a[start : start + chunk_size]
        chunk_b = flat_b[start : start + chunk_size]
        mask = (chunk_a > 0) & (chunk_b > 0)
        if not np.any(mask):
            continue
        keys = (
            chunk_a[mask].astype(np.uint64) << np.uint64(32)
        ) | chunk_b[mask].astype(np.uint64)
        encoded_pairs.update(int(key) for key in np.unique(keys))

    return [
        (int((key >> 32) & max_u32), int(key & max_u32))
        for key in sorted(encoded_pairs)
    ]


def _safe_float(value) -> float | None:
    """Convert a metadata value to float when possible.

    Parameters
    ----------
    value : object
        Metadata value to convert.

    Returns
    -------
    float or None
        Converted value, or ``None`` when conversion fails.
    """
    if value is None:
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def _pixel_sizes(layer, ndim: int) -> np.ndarray | None:
    """Return per-axis pixel sizes from layer metadata.

    Parameters
    ----------
    layer : object
        napari layer providing ``metadata``.
    ndim : int
        Dimensionality of the labels or image array.

    Returns
    -------
    numpy.ndarray or None
        Per-axis pixel sizes in micrometers, ordered to match array axes.
        Returns ``None`` when metadata is missing or incomplete.

    Notes
    -----
    The SenoQuant reader stores sizes under
    ``layer.metadata["physical_pixel_sizes"]`` using ``"Z"``, ``"Y"``,
    and ``"X"`` keys (micrometers).
    """
    metadata = getattr(layer, "metadata", None)
    if not isinstance(metadata, dict):
        return None
    physical_sizes = metadata.get("physical_pixel_sizes")
    if not isinstance(physical_sizes, dict):
        return None
    size_x = physical_sizes.get("X")
    size_y = physical_sizes.get("Y")
    size_z = physical_sizes.get("Z")
    return _pixel_sizes_from_metadata(size_x, size_y, size_z, ndim)


def _pixel_sizes_from_metadata(
    size_x, size_y, size_z, ndim: int
) -> np.ndarray | None:
    """Normalize metadata sizes into axis-ordered pixel sizes.

    Parameters
    ----------
    size_x, size_y, size_z : object
        Physical sizes from metadata (may be ``None`` or non-numeric).
    ndim : int
        Dimensionality of the labels or image array.

    Returns
    -------
    numpy.ndarray or None
        Axis-ordered pixel sizes in micrometers, or ``None`` if sizes are
        incomplete or ``ndim`` is unsupported.
    """
    axis_sizes = {
        "x": _safe_float(size_x),
        "y": _safe_float(size_y),
        "z": _safe_float(size_z),
    }
    if ndim == 2:
        sizes = [axis_sizes["y"], axis_sizes["x"]]
    elif ndim == 3:
        sizes = [axis_sizes["z"], axis_sizes["y"], axis_sizes["x"]]
    else:
        return None
    if any(value is None for value in sizes):
        return None
    return np.asarray(sizes, dtype=float)


def _axis_names(ndim: int) -> list[str]:
    """Return axis suffixes for centroid columns.

    Parameters
    ----------
    ndim : int
        Number of spatial dimensions.

    Returns
    -------
    list of str
        Axis suffixes in display order.
    """
    if ndim == 2:
        return ["y", "x"]
    if ndim == 3:
        return ["z", "y", "x"]
    return [f"axis_{idx}" for idx in range(ndim)]


def _initialize_rows(
    label_ids: np.ndarray,
    centroids: np.ndarray,
    pixel_sizes: np.ndarray | None,
) -> list[dict[str, float]]:
    """Initialize output rows with label ids and centroid coordinates.

    Parameters
    ----------
    label_ids : numpy.ndarray
        Label identifiers for each row.
    centroids : numpy.ndarray
        Centroid coordinates in pixel units.
    pixel_sizes : numpy.ndarray or None
        Per-axis pixel sizes in micrometers. When provided, physical
        centroid columns are added.

    Returns
    -------
    list of dict
        Row dictionaries with ``label_id`` and centroid columns.
    """
    axes = _axis_names(centroids.shape[1] if centroids.size else 0)
    rows: list[dict[str, float]] = []
    for label_id, centroid in zip(label_ids, centroids):
        row: dict[str, float] = {"label_id": int(label_id)}
        for axis, value in zip(axes, centroid):
            row[f"centroid_{axis}_pixels"] = float(value)
        if pixel_sizes is not None and pixel_sizes.size == len(axes):
            for axis, value, scale in zip(axes, centroid, pixel_sizes):
                row[f"centroid_{axis}_um"] = float(value * scale)
        rows.append(row)
    return rows


def _add_roi_columns(
    rows: list[dict[str, float]],
    labels: np.ndarray,
    label_ids: np.ndarray,
    viewer: object | None,
    rois: Sequence["ROIConfig"],
    label_name: str,
) -> None:
    """Add per-ROI inclusion columns to the output rows.

    Parameters
    ----------
    rows : list of dict
        Output rows to update in-place.
    labels : numpy.ndarray
        Label image used to compute ROI intersections.
    label_ids : numpy.ndarray
        Label ids corresponding to the output rows.
    viewer : object or None
        napari viewer used to resolve shapes layers.
    rois : sequence of ROIConfig
        ROI configuration entries to evaluate.
    label_name : str
        Name of the labels layer, used in warning messages.
    """
    if viewer is None or not rois or not rows:
        return
    labels_flat = labels.ravel()
    max_label = int(labels_flat.max()) if labels_flat.size else 0
    for index, roi in enumerate(rois, start=0):
        layer_name = getattr(roi, "layer", "")
        if not layer_name:
            continue
        shapes_layer = _find_layer(viewer, layer_name, "Shapes")
        if shapes_layer is None:
            warnings.warn(
                f"ROI layer '{layer_name}' not found for labels '{label_name}'.",
                RuntimeWarning,
            )
            continue
        mask = _shapes_layer_mask(shapes_layer, labels.shape)
        if mask is None:
            warnings.warn(
                f"ROI layer '{layer_name}' could not be rasterized.",
                RuntimeWarning,
            )
            continue
        intersect_counts = np.bincount(
            labels_flat[mask.ravel()], minlength=max_label + 1
        )
        included = intersect_counts[label_ids] > 0
        roi_name = getattr(roi, "name", "") or f"roi_{index}"
        roi_type = getattr(roi, "roi_type", "Include") or "Include"
        if roi_type.lower() == "exclude":
            prefix = "excluded_from_roi"
        else:
            prefix = "included_in_roi"
        column = f"{prefix}_{_sanitize_name(roi_name)}"
        for row, value in zip(rows, included):
            row[column] = int(value)


def _shapes_layer_mask(
    layer: object, shape: tuple[int, ...]
) -> np.ndarray | None:
    """Render a shapes layer into a boolean mask.

    Parameters
    ----------
    layer : object
        napari shapes layer instance.
    shape : tuple of int
        Target mask shape matching the labels array.

    Returns
    -------
    numpy.ndarray or None
        Boolean mask array when rendering succeeds.
    """
    masks_array = _shape_masks_array(layer, shape)
    if masks_array is None:
        return None
    if masks_array.ndim == len(shape):
        combined = masks_array
    else:
        combined = np.any(masks_array, axis=0)
    combined = np.asarray(combined)
    combined = np.squeeze(combined)
    if combined.shape != shape:
        return None
    return combined.astype(bool)


def _shape_masks_array(
    layer: object, shape: tuple[int, ...]
) -> np.ndarray | None:
    """Return the raw masks array from a shapes layer.

    Parameters
    ----------
    layer : object
        napari shapes layer instance.
    shape : tuple of int
        Target mask shape.

    Returns
    -------
    numpy.ndarray or None
        Raw masks array, or ``None`` if rendering fails.
    """
    to_masks = getattr(layer, "to_masks", None)
    if callable(to_masks):
        try:
            return np.asarray(to_masks(mask_shape=shape))
        except Exception:
            return None
    return None


def _spot_cell_ids_from_centroids(
    cell_labels: np.ndarray, centroids: np.ndarray
) -> np.ndarray:
    """Assign each spot to a cell id using its centroid position.

    Parameters
    ----------
    cell_labels : numpy.ndarray
        Cell segmentation labels array.
    centroids : numpy.ndarray
        Spot centroid coordinates in pixel units.

    Returns
    -------
    numpy.ndarray
        Cell id for each spot, with ``0`` indicating background.
    """
    if centroids.size == 0:
        return np.empty((0,), dtype=int)
    coords = np.round(centroids).astype(int)
    max_indices = np.asarray(cell_labels.shape) - 1
    coords = np.clip(coords, 0, max_indices)
    indices = tuple(coords[:, axis] for axis in range(coords.shape[1]))
    return cell_labels[indices].astype(int)


def _cell_spot_metrics(
    cell_ids: np.ndarray, spot_means: np.ndarray, max_cell: int
) -> tuple[np.ndarray, np.ndarray]:
    """Compute per-cell spot counts and mean intensities.

    Parameters
    ----------
    cell_ids : numpy.ndarray
        Cell ids for valid spots.
    spot_means : numpy.ndarray
        Mean intensity for each valid spot.
    max_cell : int
        Maximum label id in the cell segmentation.

    Returns
    -------
    tuple of numpy.ndarray
        ``(counts, means)`` arrays indexed by cell id.
    """
    counts = np.bincount(cell_ids, minlength=max_cell + 1)
    mean_sum = np.bincount(
        cell_ids, weights=spot_means, minlength=max_cell + 1
    )
    mean_values = _safe_divide(mean_sum, counts)
    return counts, mean_values


def _append_cell_metrics(
    rows: list[dict[str, object]],
    counts: np.ndarray,
    means: np.ndarray,
    channel_label: str,
    header: list[str],
) -> None:
    """Append channel spot metrics to cell rows.

    Parameters
    ----------
    rows : list of dict
        Cell rows to update in-place.
    counts : numpy.ndarray
        Spot counts per row.
    means : numpy.ndarray
        Mean spot intensity per row.
    channel_label : str
        Display label for the channel.
    header : list of str
        Header list to extend with the new column names.
    """
    prefix = _sanitize_name(channel_label)
    count_key = f"{prefix}_spot_count"
    mean_key = f"{prefix}_spot_mean_intensity"
    for row, count, mean in zip(rows, counts, means):
        row[count_key] = int(count)
        row[mean_key] = float(mean) if np.isfinite(mean) else np.nan
    header.extend([count_key, mean_key])


def _spot_rows(
    spot_ids: np.ndarray,
    cell_ids: np.ndarray,
    centroids: np.ndarray,
    areas_px: np.ndarray,
    mean_intensity: np.ndarray,
    channel_label: str,
    pixel_sizes: np.ndarray | None,
    roi_columns: list[tuple[str, np.ndarray]],
    file_path: str,
    within_segmentation: np.ndarray | None = None,
) -> list[dict[str, object]]:
    """Build per-spot rows for export.

    Parameters
    ----------
    spot_ids : numpy.ndarray
        Spot label identifiers.
    cell_ids : numpy.ndarray
        Cell ids associated with each spot.
    centroids : numpy.ndarray
        Spot centroid coordinates in pixel units.
    areas_px : numpy.ndarray
        Spot area (2D) or volume (3D) in pixel units.
    mean_intensity : numpy.ndarray
        Mean intensity of each spot for the channel image.
    channel_label : str
        Display label for the channel to store in the row.
    pixel_sizes : numpy.ndarray or None
        Per-axis pixel sizes in micrometers. When provided, physical
        centroid coordinates and area/volume are included.
    roi_columns : list of tuple
        Precomputed ROI column names and boolean masks.
    file_path : str
        Source image path to include on each row.
    within_segmentation : numpy.ndarray or None, optional
        Optional mask aligned to ``spot_ids`` indicating whether each spot
        falls within the configured cell segmentation.

    Returns
    -------
    list of dict
        Rows ready for serialization in the spots table.
    """
    rows: list[dict[str, object]] = []
    axes = _axis_names(centroids.shape[1] if centroids.size else 0)
    size_key_px, size_key_um, size_scale = _spot_size_keys(
        centroids.shape[1] if centroids.size else 0, pixel_sizes
    )
    roi_values = _spot_roi_values(centroids, roi_columns)
    for idx, (spot_id, cell_id, centroid, area_px, mean_val) in enumerate(
        zip(spot_ids, cell_ids, centroids, areas_px, mean_intensity)
    ):
        row: dict[str, object] = {
            "spot_id": int(spot_id),
            "cell_id": int(cell_id),
            "channel": channel_label,
            "file_path": file_path,
        }
        if within_segmentation is not None and idx < within_segmentation.size:
            row["within_segmentation"] = int(bool(within_segmentation[idx]))
        for axis, value in zip(axes, centroid):
            row[f"centroid_{axis}_pixels"] = float(value)
        if pixel_sizes is not None and pixel_sizes.size == len(axes):
            for axis, value, scale in zip(axes, centroid, pixel_sizes):
                row[f"centroid_{axis}_um"] = float(value * scale)
        row[size_key_px] = float(area_px)
        if size_scale is not None and size_key_um:
            row[size_key_um] = float(area_px * size_scale)
        row["spot_mean_intensity"] = (
            float(mean_val) if np.isfinite(mean_val) else np.nan
        )
        for column, values in roi_values:
            row[column] = int(values[idx])
        rows.append(row)
    return rows


def _spot_size_keys(
    ndim: int, pixel_sizes: np.ndarray | None
) -> tuple[str, str | None, float | None]:
    """Return size column names and physical scale for spot sizes.

    Parameters
    ----------
    ndim : int
        Number of spatial dimensions.
    pixel_sizes : numpy.ndarray or None
        Per-axis pixel sizes in micrometers.

    Returns
    -------
    tuple
        ``(pixel_key, physical_key, scale)`` where ``scale`` is the
        multiplicative factor to convert pixel area/volume to physical
        units, or ``None`` if physical sizes are unavailable.
    """
    if ndim == 3:
        size_key_px = "spot_volume_pixels"
        size_key_um = "spot_volume_um3"
    else:
        size_key_px = "spot_area_pixels"
        size_key_um = "spot_area_um2"
    if pixel_sizes is None:
        return size_key_px, None, None
    scale = float(np.prod(pixel_sizes))
    return size_key_px, size_key_um, scale


def _spot_roi_columns(
    viewer: object | None,
    rois: Sequence["ROIConfig"],
    label_name: str,
    shape: tuple[int, ...],
) -> list[tuple[str, np.ndarray]]:
    """Prepare ROI mask columns for spots export.

    Parameters
    ----------
    viewer : object or None
        napari viewer instance used to resolve shapes layers.
    rois : sequence of ROIConfig
        ROI configuration entries to evaluate.
    label_name : str
        Name of the labels layer, used in warning messages.
    shape : tuple of int
        Target mask shape matching the labels array.

    Returns
    -------
    list of tuple
        List of ``(column_name, mask)`` entries for ROI membership.
    """
    if viewer is None or not rois:
        return []
    columns: list[tuple[str, np.ndarray]] = []
    for index, roi in enumerate(rois, start=0):
        layer_name = getattr(roi, "layer", "")
        if not layer_name:
            continue
        shapes_layer = _find_layer(viewer, layer_name, "Shapes")
        if shapes_layer is None:
            warnings.warn(
                f"ROI layer '{layer_name}' not found for labels '{label_name}'.",
                RuntimeWarning,
            )
            continue
        mask = _shapes_layer_mask(shapes_layer, shape)
        if mask is None:
            warnings.warn(
                f"ROI layer '{layer_name}' could not be rasterized.",
                RuntimeWarning,
            )
            continue
        roi_name = getattr(roi, "name", "") or f"roi_{index}"
        roi_type = getattr(roi, "roi_type", "Include") or "Include"
        if roi_type.lower() == "exclude":
            prefix = "excluded_from_roi"
        else:
            prefix = "included_in_roi"
        column = f"{prefix}_{_sanitize_name(roi_name)}"
        columns.append((column, mask))
    return columns


def _spot_roi_values(
    centroids: np.ndarray, roi_columns: list[tuple[str, np.ndarray]]
) -> list[tuple[str, np.ndarray]]:
    """Return ROI membership values for each spot centroid.

    Parameters
    ----------
    centroids : numpy.ndarray
        Spot centroid coordinates in pixel units.
    roi_columns : list of tuple
        ROI columns from :func:`_spot_roi_columns`.

    Returns
    -------
    list of tuple
        List of ``(column_name, values)`` pairs aligned to the spot order.
    """
    if not roi_columns or centroids.size == 0:
        return []
    coords = np.round(centroids).astype(int)
    roi_values: list[tuple[str, np.ndarray]] = []
    for column, mask in roi_columns:
        max_indices = np.asarray(mask.shape) - 1
        clipped = np.clip(coords, 0, max_indices)
        indices = tuple(
            clipped[:, axis] for axis in range(clipped.shape[1])
        )
        values = mask[indices].astype(int)
        roi_values.append((column, values))
    return roi_values


def _spot_header(
    ndim: int,
    pixel_sizes: np.ndarray | None,
    roi_columns: list[tuple[str, np.ndarray]],
    *,
    include_within_segmentation: bool = False,
) -> list[str]:
    """Build the header for the spots table.

    Parameters
    ----------
    ndim : int
        Number of spatial dimensions.
    pixel_sizes : numpy.ndarray or None
        Per-axis pixel sizes in micrometers.
    roi_columns : list of tuple
        ROI columns to append to the header.
    include_within_segmentation : bool, optional
        Whether to include a ``within_segmentation`` column in the header.

    Returns
    -------
    list of str
        Column names for the spots export table.
    """
    axes = _axis_names(ndim)
    size_key_px, size_key_um, _scale = _spot_size_keys(ndim, pixel_sizes)
    header = ["spot_id", "cell_id", "channel", "file_path"]
    if include_within_segmentation:
        header.append("within_segmentation")
    header.extend([f"centroid_{axis}_pixels" for axis in axes])
    if pixel_sizes is not None and pixel_sizes.size == len(axes):
        header.extend([f"centroid_{axis}_um" for axis in axes])
    header.append(size_key_px)
    if size_key_um:
        header.append(size_key_um)
    header.append("spot_mean_intensity")
    if roi_columns:
        header.extend([column for column, _mask in roi_columns])
    return header


def _channel_label(channel) -> str:
    """Return a display label for a channel.

    Parameters
    ----------
    channel : object
        Channel configuration object.

    Returns
    -------
    str
        Human-readable label for the channel.
    """
    label = channel.name.strip() if channel.name else ""
    return label or channel.channel


def _sanitize_name(value: str) -> str:
    """Normalize names for filenames and column prefixes.

    Parameters
    ----------
    value : str
        Raw name to sanitize.

    Returns
    -------
    str
        Lowercase name with spaces normalized and unsafe characters removed.
    """
    cleaned = "".join(
        char if char.isalnum() or char in "-_ " else "_" for char in value
    )
    return cleaned.strip().replace(" ", "_").lower()


def _safe_divide(numerator: np.ndarray, denominator: np.ndarray) -> np.ndarray:
    """Compute numerator/denominator with zero-safe handling.

    Parameters
    ----------
    numerator : numpy.ndarray
        Numerator values.
    denominator : numpy.ndarray
        Denominator values.

    Returns
    -------
    numpy.ndarray
        Division results with zeros where denominator is zero.
    """
    result = np.zeros_like(numerator, dtype=float)
    np.divide(numerator, denominator, out=result, where=denominator != 0)
    return result


def _write_mask_output(temp_dir: Path, stem: str, labels: np.ndarray) -> Path:
    """Write a segmentation mask as a ``.npy`` array file."""
    output_path = _next_available_path(temp_dir, stem, ".npy")
    np.save(output_path, np.asarray(labels))
    return output_path


def _next_available_path(temp_dir: Path, stem: str, suffix: str) -> Path:
    """Return a non-conflicting output path under ``temp_dir``."""
    candidate = temp_dir / f"{stem}{suffix}"
    if not candidate.exists():
        return candidate
    index = 1
    while True:
        candidate = temp_dir / f"{stem}_{index}{suffix}"
        if not candidate.exists():
            return candidate
        index += 1


def _layer_run_history(layer: object) -> list[dict]:
    """Return sanitized layer run-history entries in stored order."""
    metadata = getattr(layer, "metadata", None)
    if not isinstance(metadata, dict):
        return []
    history = metadata.get("run_history")
    if not isinstance(history, list):
        return []
    runs: list[dict] = []
    for item in history:
        if isinstance(item, dict):
            runs.append(dict(item))
    return runs


def _segmentation_task_from_layer(
    layer: object,
    layer_name: str,
    *,
    default_task: str,
) -> str:
    """Resolve segmentation task from metadata with suffix fallback."""
    metadata = getattr(layer, "metadata", None)
    if isinstance(metadata, dict):
        task = metadata.get("task")
        if isinstance(task, str):
            normalized = task.strip().lower()
            if normalized:
                return normalized
    if layer_name.endswith("_cyto_labels"):
        return "cytoplasmic"
    if layer_name.endswith("_nuc_labels"):
        return "nuclear"
    if layer_name.endswith("_spot_labels"):
        return "spots"
    return default_task


def _write_spots_settings_bundle(
    *,
    temp_dir: Path,
    feature: FeatureConfig,
    data: SpotsFeatureData,
    export_format: str,
    segmentation_runs: list[dict[str, object]],
) -> Path | None:
    """Write the canonical spots export settings bundle.

    The bundle mirrors the shared settings-bundle schema and includes:
    - Feature configuration snapshot.
    - Segmentation mask references.
    - Timestamped layer run history for replaying run order.
    """
    feature_payload = {
        "kind": "feature_settings",
        "feature_id": feature.feature_id,
        "feature_type": feature.type_name or "Spots",
        "feature_name": feature.name,
        "export_format": export_format,
        "config": asdict(data),
    }
    payload = build_settings_bundle(
        feature_settings=feature_payload,
        segmentation_runs=segmentation_runs,
    )
    output_path = temp_dir / "feature_settings.json"
    with output_path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    return output_path


def _write_table(
    path: Path, header: list[str], rows: list[dict[str, object]], fmt: str
) -> None:
    """Write rows to disk as CSV or XLSX.

    Parameters
    ----------
    path : pathlib.Path
        Destination file path.
    header : list of str
        Column names for the output table.
    rows : list of dict
        Table rows keyed by column name.
    fmt : str
        Output format (``"csv"`` or ``"xlsx"``).

    Raises
    ------
    RuntimeError
        If ``fmt`` is ``"xlsx"`` and ``openpyxl`` is unavailable.
    ValueError
        If ``fmt`` is not a supported format.
    """
    if fmt == "csv":
        with path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=header)
            writer.writeheader()
            writer.writerows(rows)
        return

    if fmt == "xlsx":
        try:
            import openpyxl
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError(
                "openpyxl is required for xlsx export"
            ) from exc
        workbook = openpyxl.Workbook()
        sheet = workbook.active
        sheet.append(header)
        for row in rows:
            sheet.append([row.get(column) for column in header])
        workbook.save(path)
        return

    raise ValueError(f"Unsupported export format: {fmt}")
