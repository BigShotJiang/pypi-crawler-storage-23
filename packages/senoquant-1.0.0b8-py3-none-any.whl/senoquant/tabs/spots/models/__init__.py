"""Spot detector definitions and storage."""

from .base import SenoQuantSpotDetector

__all__ = ["SenoQuantSpotDetector"]
