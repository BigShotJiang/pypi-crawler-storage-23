"""Prediction model definitions and storage."""

from senoquant.tabs.prediction.models.base import SenoQuantPredictionModel

__all__ = ["SenoQuantPredictionModel"]
