"""Private frontend mixin modules for the SenNet Portal tab."""

