import{c as r}from"./graph-CO6e1Y9R.js";var e=4;function a(o){return r(o,e)}export{a as c};
