# Bundled React viewer assets (built from frontend/).
# This directory is included as package data so `--json` can output
# a fully functional interactive viewer alongside hld_data.json.
