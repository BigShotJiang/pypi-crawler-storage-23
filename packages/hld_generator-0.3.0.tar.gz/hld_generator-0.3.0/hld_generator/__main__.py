"""Allow running as `python -m hld_generator`."""

import sys

from hld_generator.cli import main

if __name__ == "__main__":
    sys.exit(main())
