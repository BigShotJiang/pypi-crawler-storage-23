"""
HLD Generator — Language-agnostic High-Level Design generator.
Scans codebases using Tree-sitter for AST parsing and LLMs for semantic understanding.
"""

__version__ = "0.3.0"
