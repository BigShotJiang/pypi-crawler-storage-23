# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from bennyapi import Benny, AsyncBenny
from tests.utils import assert_matches_type
from bennyapi.types import (
    PaymentRefundResponse,
    PaymentReverseResponse,
    PaymentCreateIntentResponse,
    PaymentGetPinAttemptCountResponse,
)

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestPayment:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_intent(self, client: Benny) -> None:
        payment = client.payment.create_intent(
            amount=0,
            external_user_id="externalUserId",
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            tender_type="EBT_CASH",
            token_id="tokenId",
        )
        assert_matches_type(PaymentCreateIntentResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_intent_with_all_params(self, client: Benny) -> None:
        payment = client.payment.create_intent(
            amount=0,
            external_user_id="externalUserId",
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
                "address2": "address2",
                "country": "US",
            },
            fulfillment_type="DELIVERY",
            tender_type="EBT_CASH",
            token_id="tokenId",
            order_id="orderId",
        )
        assert_matches_type(PaymentCreateIntentResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create_intent(self, client: Benny) -> None:
        response = client.payment.with_raw_response.create_intent(
            amount=0,
            external_user_id="externalUserId",
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            tender_type="EBT_CASH",
            token_id="tokenId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert_matches_type(PaymentCreateIntentResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create_intent(self, client: Benny) -> None:
        with client.payment.with_streaming_response.create_intent(
            amount=0,
            external_user_id="externalUserId",
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            tender_type="EBT_CASH",
            token_id="tokenId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert_matches_type(PaymentCreateIntentResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_method(self, client: Benny) -> None:
        payment = client.payment.create_method(
            external_user_id="externalUserId",
            mask="mask",
            token_id="tokenId",
        )
        assert_matches_type(object, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create_method(self, client: Benny) -> None:
        response = client.payment.with_raw_response.create_method(
            external_user_id="externalUserId",
            mask="mask",
            token_id="tokenId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert_matches_type(object, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create_method(self, client: Benny) -> None:
        with client.payment.with_streaming_response.create_method(
            external_user_id="externalUserId",
            mask="mask",
            token_id="tokenId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert_matches_type(object, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_delete_intent(self, client: Benny) -> None:
        payment = client.payment.delete_intent(
            payment_intent_id="paymentIntentId",
        )
        assert payment is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_delete_intent(self, client: Benny) -> None:
        response = client.payment.with_raw_response.delete_intent(
            payment_intent_id="paymentIntentId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert payment is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_delete_intent(self, client: Benny) -> None:
        with client.payment.with_streaming_response.delete_intent(
            payment_intent_id="paymentIntentId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert payment is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_get_pin_attempt_count(self, client: Benny) -> None:
        payment = client.payment.get_pin_attempt_count(
            retrieval_reference_number="retrievalReferenceNumber",
        )
        assert_matches_type(PaymentGetPinAttemptCountResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_get_pin_attempt_count(self, client: Benny) -> None:
        response = client.payment.with_raw_response.get_pin_attempt_count(
            retrieval_reference_number="retrievalReferenceNumber",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert_matches_type(PaymentGetPinAttemptCountResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_get_pin_attempt_count(self, client: Benny) -> None:
        with client.payment.with_streaming_response.get_pin_attempt_count(
            retrieval_reference_number="retrievalReferenceNumber",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert_matches_type(PaymentGetPinAttemptCountResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_refund(self, client: Benny) -> None:
        payment = client.payment.refund(
            amount=0,
            payment_type="SNAP",
            token_id="tokenId",
        )
        assert_matches_type(PaymentRefundResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_refund_with_all_params(self, client: Benny) -> None:
        payment = client.payment.refund(
            amount=0,
            payment_type="SNAP",
            token_id="tokenId",
            order_id="orderId",
            payment_intent_id="paymentIntentId",
            idempotency_key="",
        )
        assert_matches_type(PaymentRefundResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_refund(self, client: Benny) -> None:
        response = client.payment.with_raw_response.refund(
            amount=0,
            payment_type="SNAP",
            token_id="tokenId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert_matches_type(PaymentRefundResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_refund(self, client: Benny) -> None:
        with client.payment.with_streaming_response.refund(
            amount=0,
            payment_type="SNAP",
            token_id="tokenId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert_matches_type(PaymentRefundResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_reverse(self, client: Benny) -> None:
        payment = client.payment.reverse()
        assert_matches_type(PaymentReverseResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_reverse_with_all_params(self, client: Benny) -> None:
        payment = client.payment.reverse(
            payment_intent_id="paymentIntentId",
            refund_intent_id="refundIntentId",
        )
        assert_matches_type(PaymentReverseResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_reverse(self, client: Benny) -> None:
        response = client.payment.with_raw_response.reverse()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert_matches_type(PaymentReverseResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_reverse(self, client: Benny) -> None:
        with client.payment.with_streaming_response.reverse() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert_matches_type(PaymentReverseResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_intent(self, client: Benny) -> None:
        payment = client.payment.update_intent(
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            payment_intent_id="paymentIntentId",
        )
        assert_matches_type(object, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_update_intent_with_all_params(self, client: Benny) -> None:
        payment = client.payment.update_intent(
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
                "address2": "address2",
                "country": "US",
            },
            fulfillment_type="DELIVERY",
            payment_intent_id="paymentIntentId",
        )
        assert_matches_type(object, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_update_intent(self, client: Benny) -> None:
        response = client.payment.with_raw_response.update_intent(
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            payment_intent_id="paymentIntentId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = response.parse()
        assert_matches_type(object, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_update_intent(self, client: Benny) -> None:
        with client.payment.with_streaming_response.update_intent(
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            payment_intent_id="paymentIntentId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = response.parse()
            assert_matches_type(object, payment, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncPayment:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_intent(self, async_client: AsyncBenny) -> None:
        payment = await async_client.payment.create_intent(
            amount=0,
            external_user_id="externalUserId",
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            tender_type="EBT_CASH",
            token_id="tokenId",
        )
        assert_matches_type(PaymentCreateIntentResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_intent_with_all_params(self, async_client: AsyncBenny) -> None:
        payment = await async_client.payment.create_intent(
            amount=0,
            external_user_id="externalUserId",
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
                "address2": "address2",
                "country": "US",
            },
            fulfillment_type="DELIVERY",
            tender_type="EBT_CASH",
            token_id="tokenId",
            order_id="orderId",
        )
        assert_matches_type(PaymentCreateIntentResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create_intent(self, async_client: AsyncBenny) -> None:
        response = await async_client.payment.with_raw_response.create_intent(
            amount=0,
            external_user_id="externalUserId",
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            tender_type="EBT_CASH",
            token_id="tokenId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert_matches_type(PaymentCreateIntentResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create_intent(self, async_client: AsyncBenny) -> None:
        async with async_client.payment.with_streaming_response.create_intent(
            amount=0,
            external_user_id="externalUserId",
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            tender_type="EBT_CASH",
            token_id="tokenId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert_matches_type(PaymentCreateIntentResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_method(self, async_client: AsyncBenny) -> None:
        payment = await async_client.payment.create_method(
            external_user_id="externalUserId",
            mask="mask",
            token_id="tokenId",
        )
        assert_matches_type(object, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create_method(self, async_client: AsyncBenny) -> None:
        response = await async_client.payment.with_raw_response.create_method(
            external_user_id="externalUserId",
            mask="mask",
            token_id="tokenId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert_matches_type(object, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create_method(self, async_client: AsyncBenny) -> None:
        async with async_client.payment.with_streaming_response.create_method(
            external_user_id="externalUserId",
            mask="mask",
            token_id="tokenId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert_matches_type(object, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_delete_intent(self, async_client: AsyncBenny) -> None:
        payment = await async_client.payment.delete_intent(
            payment_intent_id="paymentIntentId",
        )
        assert payment is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_delete_intent(self, async_client: AsyncBenny) -> None:
        response = await async_client.payment.with_raw_response.delete_intent(
            payment_intent_id="paymentIntentId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert payment is None

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_delete_intent(self, async_client: AsyncBenny) -> None:
        async with async_client.payment.with_streaming_response.delete_intent(
            payment_intent_id="paymentIntentId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert payment is None

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_get_pin_attempt_count(self, async_client: AsyncBenny) -> None:
        payment = await async_client.payment.get_pin_attempt_count(
            retrieval_reference_number="retrievalReferenceNumber",
        )
        assert_matches_type(PaymentGetPinAttemptCountResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_get_pin_attempt_count(self, async_client: AsyncBenny) -> None:
        response = await async_client.payment.with_raw_response.get_pin_attempt_count(
            retrieval_reference_number="retrievalReferenceNumber",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert_matches_type(PaymentGetPinAttemptCountResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_get_pin_attempt_count(self, async_client: AsyncBenny) -> None:
        async with async_client.payment.with_streaming_response.get_pin_attempt_count(
            retrieval_reference_number="retrievalReferenceNumber",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert_matches_type(PaymentGetPinAttemptCountResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_refund(self, async_client: AsyncBenny) -> None:
        payment = await async_client.payment.refund(
            amount=0,
            payment_type="SNAP",
            token_id="tokenId",
        )
        assert_matches_type(PaymentRefundResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_refund_with_all_params(self, async_client: AsyncBenny) -> None:
        payment = await async_client.payment.refund(
            amount=0,
            payment_type="SNAP",
            token_id="tokenId",
            order_id="orderId",
            payment_intent_id="paymentIntentId",
            idempotency_key="",
        )
        assert_matches_type(PaymentRefundResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_refund(self, async_client: AsyncBenny) -> None:
        response = await async_client.payment.with_raw_response.refund(
            amount=0,
            payment_type="SNAP",
            token_id="tokenId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert_matches_type(PaymentRefundResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_refund(self, async_client: AsyncBenny) -> None:
        async with async_client.payment.with_streaming_response.refund(
            amount=0,
            payment_type="SNAP",
            token_id="tokenId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert_matches_type(PaymentRefundResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_reverse(self, async_client: AsyncBenny) -> None:
        payment = await async_client.payment.reverse()
        assert_matches_type(PaymentReverseResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_reverse_with_all_params(self, async_client: AsyncBenny) -> None:
        payment = await async_client.payment.reverse(
            payment_intent_id="paymentIntentId",
            refund_intent_id="refundIntentId",
        )
        assert_matches_type(PaymentReverseResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_reverse(self, async_client: AsyncBenny) -> None:
        response = await async_client.payment.with_raw_response.reverse()

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert_matches_type(PaymentReverseResponse, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_reverse(self, async_client: AsyncBenny) -> None:
        async with async_client.payment.with_streaming_response.reverse() as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert_matches_type(PaymentReverseResponse, payment, path=["response"])

        assert cast(Any, response.is_closed) is True

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_intent(self, async_client: AsyncBenny) -> None:
        payment = await async_client.payment.update_intent(
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            payment_intent_id="paymentIntentId",
        )
        assert_matches_type(object, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_update_intent_with_all_params(self, async_client: AsyncBenny) -> None:
        payment = await async_client.payment.update_intent(
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
                "address2": "address2",
                "country": "US",
            },
            fulfillment_type="DELIVERY",
            payment_intent_id="paymentIntentId",
        )
        assert_matches_type(object, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_update_intent(self, async_client: AsyncBenny) -> None:
        response = await async_client.payment.with_raw_response.update_intent(
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            payment_intent_id="paymentIntentId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        payment = await response.parse()
        assert_matches_type(object, payment, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_update_intent(self, async_client: AsyncBenny) -> None:
        async with async_client.payment.with_streaming_response.update_intent(
            fulfillment_address={
                "address1": "address1",
                "city": "city",
                "postal_code": "postalCode",
                "state": "AL",
            },
            fulfillment_type="DELIVERY",
            payment_intent_id="paymentIntentId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            payment = await response.parse()
            assert_matches_type(object, payment, path=["response"])

        assert cast(Any, response.is_closed) is True
