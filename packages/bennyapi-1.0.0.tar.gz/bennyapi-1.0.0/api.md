# Orders

Types:

```python
from bennyapi.types import (
    Address,
    AllocatedAmounts,
    FulfillmentDetails,
    Item,
    OrderState,
    OrderCreateSessionResponse,
)
```

Methods:

- <code title="post /v1/order/session">client.orders.<a href="./src/bennyapi/resources/orders.py">create_session</a>(\*\*<a href="src/bennyapi/types/order_create_session_params.py">params</a>) -> <a href="./src/bennyapi/types/order_create_session_response.py">OrderCreateSessionResponse</a></code>

# Payment

Types:

```python
from bennyapi.types import (
    FulfillmentType,
    TenderType,
    PaymentCreateIntentResponse,
    PaymentGetPinAttemptCountResponse,
    PaymentRefundResponse,
    PaymentReverseResponse,
)
```

Methods:

- <code title="post /v1/payment/intent">client.payment.<a href="./src/bennyapi/resources/payment.py">create_intent</a>(\*\*<a href="src/bennyapi/types/payment_create_intent_params.py">params</a>) -> <a href="./src/bennyapi/types/payment_create_intent_response.py">PaymentCreateIntentResponse</a></code>
- <code title="post /v1/payment/method">client.payment.<a href="./src/bennyapi/resources/payment.py">create_method</a>(\*\*<a href="src/bennyapi/types/payment_create_method_params.py">params</a>) -> object</code>
- <code title="delete /v1/payment/intent">client.payment.<a href="./src/bennyapi/resources/payment.py">delete_intent</a>(\*\*<a href="src/bennyapi/types/payment_delete_intent_params.py">params</a>) -> None</code>
- <code title="post /v1/payment/pin-attempt">client.payment.<a href="./src/bennyapi/resources/payment.py">get_pin_attempt_count</a>(\*\*<a href="src/bennyapi/types/payment_get_pin_attempt_count_params.py">params</a>) -> <a href="./src/bennyapi/types/payment_get_pin_attempt_count_response.py">PaymentGetPinAttemptCountResponse</a></code>
- <code title="post /v1/payment/refund">client.payment.<a href="./src/bennyapi/resources/payment.py">refund</a>(\*\*<a href="src/bennyapi/types/payment_refund_params.py">params</a>) -> <a href="./src/bennyapi/types/payment_refund_response.py">PaymentRefundResponse</a></code>
- <code title="post /v1/payment/reverse">client.payment.<a href="./src/bennyapi/resources/payment.py">reverse</a>(\*\*<a href="src/bennyapi/types/payment_reverse_params.py">params</a>) -> <a href="./src/bennyapi/types/payment_reverse_response.py">PaymentReverseResponse</a></code>
- <code title="patch /v1/payment/intent">client.payment.<a href="./src/bennyapi/resources/payment.py">update_intent</a>(\*\*<a href="src/bennyapi/types/payment_update_intent_params.py">params</a>) -> object</code>

# Sessions

Types:

```python
from bennyapi.types import SessionCreateTokenResponse
```

Methods:

- <code title="post /v1/session">client.sessions.<a href="./src/bennyapi/resources/sessions.py">create_token</a>(\*\*<a href="src/bennyapi/types/session_create_token_params.py">params</a>) -> <a href="./src/bennyapi/types/session_create_token_response.py">SessionCreateTokenResponse</a></code>
