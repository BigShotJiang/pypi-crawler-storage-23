# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .address_param import AddressParam
from .fulfillment_type import FulfillmentType

__all__ = ["PaymentUpdateIntentParams"]


class PaymentUpdateIntentParams(TypedDict, total=False):
    fulfillment_address: Required[Annotated[AddressParam, PropertyInfo(alias="fulfillmentAddress")]]
    """The fulfillment address."""

    fulfillment_type: Required[Annotated[FulfillmentType, PropertyInfo(alias="fulfillmentType")]]
    """The fulfillment type."""

    payment_intent_id: Required[Annotated[str, PropertyInfo(alias="paymentIntentId")]]
    """The payment intent ID requiring update."""
