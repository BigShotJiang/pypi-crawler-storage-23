# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .tender_type import TenderType

__all__ = ["ItemParam", "Tender"]


class Tender(TypedDict, total=False):
    amount: Required[int]
    """Amount in cents."""

    tender: Required[TenderType]
    """Tender type."""


class ItemParam(TypedDict, total=False):
    """Item in an order."""

    id: Required[str]
    """Required unique identifier for the item."""

    description: Required[str]
    """Description or name of the item."""

    name: Required[str]
    """Item name."""

    price: Required[int]
    """Price per unit of the item in cents."""

    quantity: Required[float]
    """Quantity of the item (discrete count or weight)."""

    snap_eligible: Required[Annotated[bool, PropertyInfo(alias="snapEligible")]]
    """Whether the item is eligible for SNAP benefits."""

    tax_rate: Required[Annotated[float, PropertyInfo(alias="taxRate")]]
    """Tax rate applicable to the item (as decimal, e.g., 0.07 for 7 percent)."""

    tenders: Required[Iterable[Tender]]

    unit: Required[Literal["COUNT", "LBS"]]
    """Unit of measurement for the item quantity."""

    is_refunded: Annotated[bool, PropertyInfo(alias="isRefunded")]

    padded_price: Annotated[int, PropertyInfo(alias="paddedPrice")]
    """
    Padded price for weight-based items in cents (up to 10 percent padding allowed).
    """

    photo_url: Annotated[str, PropertyInfo(alias="photoUrl")]
    """Optional URL for the item's photo."""
