# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["PaymentReverseResponse"]


class PaymentReverseResponse(BaseModel):
    retrieval_reference_number: str = FieldInfo(alias="retrievalReferenceNumber")
    """
    The underlying retrieval reference number representing the transaction for
    auditing purpsoes
    """
