# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal, Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["PaymentRefundParams"]


class PaymentRefundParams(TypedDict, total=False):
    amount: Required[int]

    payment_type: Required[Annotated[Literal["SNAP", "EBT_CASH"], PropertyInfo(alias="paymentType")]]

    token_id: Required[Annotated[str, PropertyInfo(alias="tokenId")]]

    order_id: Annotated[str, PropertyInfo(alias="orderId")]

    payment_intent_id: Annotated[str, PropertyInfo(alias="paymentIntentId")]

    idempotency_key: Annotated[str, PropertyInfo(alias="Idempotency-Key")]
