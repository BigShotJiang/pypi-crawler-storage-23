# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from datetime import datetime

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["SessionCreateTokenResponse"]


class SessionCreateTokenResponse(BaseModel):
    token: str
    """The session token."""

    expires_at: datetime = FieldInfo(alias="expiresAt")
    """The UTC time at which the token expires."""
