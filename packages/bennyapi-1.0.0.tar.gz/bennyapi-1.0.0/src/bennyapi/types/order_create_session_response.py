# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["OrderCreateSessionResponse"]


class OrderCreateSessionResponse(BaseModel):
    """Response containing the created order details."""

    session_url: str = FieldInfo(alias="sessionUrl")
    """The unique checkout session URL for the customer to complete their EBT order."""
