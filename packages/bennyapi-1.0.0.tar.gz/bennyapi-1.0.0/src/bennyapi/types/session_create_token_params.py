# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo

__all__ = ["SessionCreateTokenParams"]


class SessionCreateTokenParams(TypedDict, total=False):
    external_user_id: Required[Annotated[str, PropertyInfo(alias="externalUserId")]]
    """Your organization's representation of the customer ID."""

    order_id: Annotated[str, PropertyInfo(alias="orderId")]
    """Your organization's representation of the order ID."""
