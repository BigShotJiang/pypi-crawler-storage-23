# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .tender_type import TenderType
from .address_param import AddressParam
from .fulfillment_type import FulfillmentType

__all__ = ["PaymentCreateIntentParams"]


class PaymentCreateIntentParams(TypedDict, total=False):
    amount: Required[int]
    """The amount in cents for the payment."""

    external_user_id: Required[Annotated[str, PropertyInfo(alias="externalUserId")]]
    """Your organization's representation of the customer ID."""

    fulfillment_address: Required[Annotated[AddressParam, PropertyInfo(alias="fulfillmentAddress")]]
    """The fulfillment address"""

    fulfillment_type: Required[Annotated[FulfillmentType, PropertyInfo(alias="fulfillmentType")]]
    """The fulfillment type."""

    tender_type: Required[Annotated[TenderType, PropertyInfo(alias="tenderType")]]
    """The tender type of SNAP or EBT Cash."""

    token_id: Required[Annotated[str, PropertyInfo(alias="tokenId")]]
    """The payment method ID."""

    order_id: Annotated[str, PropertyInfo(alias="orderId")]
    """Your organization's representation of the order ID ID."""
