# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable
from typing_extensions import Required, Annotated, TypedDict

from .._utils import PropertyInfo
from .item_param import ItemParam

__all__ = ["OrderCreateSessionParams"]


class OrderCreateSessionParams(TypedDict, total=False):
    items: Required[Iterable[ItemParam]]
    """List of items in the shopping cart"""

    on_exit_redirect_url: Required[Annotated[str, PropertyInfo(alias="onExitRedirectUrl")]]
    """The URL to redirect the customer to on checkout exit"""

    on_success_redirect_url: Required[Annotated[str, PropertyInfo(alias="onSuccessRedirectUrl")]]
    """The URL to redirect the customer to on checkout success"""

    external_customer_id: Annotated[str, PropertyInfo(alias="externalCustomerId")]
    """An optional ID unique to your organization representing the customer"""

    external_order_id: Annotated[str, PropertyInfo(alias="externalOrderId")]
    """An optional ID unique to your organization representing the order"""
