# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Literal

import httpx

from ..types import (
    TenderType,
    FulfillmentType,
    payment_refund_params,
    payment_reverse_params,
    payment_create_intent_params,
    payment_create_method_params,
    payment_delete_intent_params,
    payment_update_intent_params,
    payment_get_pin_attempt_count_params,
)
from .._types import Body, Omit, Query, Headers, NoneType, NotGiven, omit, not_given
from .._utils import maybe_transform, strip_not_given, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.tender_type import TenderType
from ..types.address_param import AddressParam
from ..types.fulfillment_type import FulfillmentType
from ..types.payment_refund_response import PaymentRefundResponse
from ..types.payment_reverse_response import PaymentReverseResponse
from ..types.payment_create_intent_response import PaymentCreateIntentResponse
from ..types.payment_get_pin_attempt_count_response import PaymentGetPinAttemptCountResponse

__all__ = ["PaymentResource", "AsyncPaymentResource"]


class PaymentResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> PaymentResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Benny-API/benny-python#accessing-raw-response-data-eg-headers
        """
        return PaymentResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> PaymentResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Benny-API/benny-python#with_streaming_response
        """
        return PaymentResourceWithStreamingResponse(self)

    def create_intent(
        self,
        *,
        amount: int,
        external_user_id: str,
        fulfillment_address: AddressParam,
        fulfillment_type: FulfillmentType,
        tender_type: TenderType,
        token_id: str,
        order_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentCreateIntentResponse:
        """
        Creates a payment intent that will be passed to the appropriate web or mobile
        SDK to collect payment. A payment intent represents an "intended" money
        movement, and will expire after 1 hour if not completed.

        Args:
          amount: The amount in cents for the payment.

          external_user_id: Your organization's representation of the customer ID.

          fulfillment_address: The fulfillment address

          fulfillment_type: The fulfillment type.

          tender_type: The tender type of SNAP or EBT Cash.

          token_id: The payment method ID.

          order_id: Your organization's representation of the order ID ID.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/payment/intent",
            body=maybe_transform(
                {
                    "amount": amount,
                    "external_user_id": external_user_id,
                    "fulfillment_address": fulfillment_address,
                    "fulfillment_type": fulfillment_type,
                    "tender_type": tender_type,
                    "token_id": token_id,
                    "order_id": order_id,
                },
                payment_create_intent_params.PaymentCreateIntentParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentCreateIntentResponse,
        )

    def create_method(
        self,
        *,
        external_user_id: str,
        mask: str,
        token_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Enables creation of an EBT payment method.

        Args:
          external_user_id: The representation of your customer ID.

          token_id: The token ID returned from the mobile or web SDK representing the EBT card.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/payment/method",
            body=maybe_transform(
                {
                    "external_user_id": external_user_id,
                    "mask": mask,
                    "token_id": token_id,
                },
                payment_create_method_params.PaymentCreateMethodParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )

    def delete_intent(
        self,
        *,
        payment_intent_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Enables deletion of a pending payment intent.

        Payment intents in a terminal
        state cannot be deleted.

        Args:
          payment_intent_id: The payment intent ID.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return self._delete(
            "/v1/payment/intent",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=maybe_transform(
                    {"payment_intent_id": payment_intent_id}, payment_delete_intent_params.PaymentDeleteIntentParams
                ),
            ),
            cast_to=NoneType,
        )

    def get_pin_attempt_count(
        self,
        *,
        retrieval_reference_number: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentGetPinAttemptCountResponse:
        """
        Endpoint for getting the pin attempt count for the day.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/payment/pin-attempt",
            body=maybe_transform(
                {"retrieval_reference_number": retrieval_reference_number},
                payment_get_pin_attempt_count_params.PaymentGetPinAttemptCountParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentGetPinAttemptCountResponse,
        )

    def refund(
        self,
        *,
        amount: int,
        payment_type: Literal["SNAP", "EBT_CASH"],
        token_id: str,
        order_id: str | Omit = omit,
        payment_intent_id: str | Omit = omit,
        idempotency_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRefundResponse:
        """
        Allows a payment to be fully or partially refunded based on the refund intent
        parameters. A refunded payment will appear on a customer's EBT account.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Idempotency-Key": idempotency_key}), **(extra_headers or {})}
        return self._post(
            "/v1/payment/refund",
            body=maybe_transform(
                {
                    "amount": amount,
                    "payment_type": payment_type,
                    "token_id": token_id,
                    "order_id": order_id,
                    "payment_intent_id": payment_intent_id,
                },
                payment_refund_params.PaymentRefundParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRefundResponse,
        )

    def reverse(
        self,
        *,
        payment_intent_id: str | Omit = omit,
        refund_intent_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentReverseResponse:
        """Allows a payment or refund to be reversed.

        A reversed payment will not appear on
        a customer's EBT account.

        Args:
          payment_intent_id: The payment intent ID.

          refund_intent_id: The refund intent ID.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/payment/reverse",
            body=maybe_transform(
                {
                    "payment_intent_id": payment_intent_id,
                    "refund_intent_id": refund_intent_id,
                },
                payment_reverse_params.PaymentReverseParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentReverseResponse,
        )

    def update_intent(
        self,
        *,
        fulfillment_address: AddressParam,
        fulfillment_type: FulfillmentType,
        payment_intent_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Enables updating a payment intent that is not in a terminal state.

        Args:
          fulfillment_address: The fulfillment address.

          fulfillment_type: The fulfillment type.

          payment_intent_id: The payment intent ID requiring update.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._patch(
            "/v1/payment/intent",
            body=maybe_transform(
                {
                    "fulfillment_address": fulfillment_address,
                    "fulfillment_type": fulfillment_type,
                    "payment_intent_id": payment_intent_id,
                },
                payment_update_intent_params.PaymentUpdateIntentParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class AsyncPaymentResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncPaymentResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Benny-API/benny-python#accessing-raw-response-data-eg-headers
        """
        return AsyncPaymentResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncPaymentResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Benny-API/benny-python#with_streaming_response
        """
        return AsyncPaymentResourceWithStreamingResponse(self)

    async def create_intent(
        self,
        *,
        amount: int,
        external_user_id: str,
        fulfillment_address: AddressParam,
        fulfillment_type: FulfillmentType,
        tender_type: TenderType,
        token_id: str,
        order_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentCreateIntentResponse:
        """
        Creates a payment intent that will be passed to the appropriate web or mobile
        SDK to collect payment. A payment intent represents an "intended" money
        movement, and will expire after 1 hour if not completed.

        Args:
          amount: The amount in cents for the payment.

          external_user_id: Your organization's representation of the customer ID.

          fulfillment_address: The fulfillment address

          fulfillment_type: The fulfillment type.

          tender_type: The tender type of SNAP or EBT Cash.

          token_id: The payment method ID.

          order_id: Your organization's representation of the order ID ID.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/payment/intent",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "external_user_id": external_user_id,
                    "fulfillment_address": fulfillment_address,
                    "fulfillment_type": fulfillment_type,
                    "tender_type": tender_type,
                    "token_id": token_id,
                    "order_id": order_id,
                },
                payment_create_intent_params.PaymentCreateIntentParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentCreateIntentResponse,
        )

    async def create_method(
        self,
        *,
        external_user_id: str,
        mask: str,
        token_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Enables creation of an EBT payment method.

        Args:
          external_user_id: The representation of your customer ID.

          token_id: The token ID returned from the mobile or web SDK representing the EBT card.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/payment/method",
            body=await async_maybe_transform(
                {
                    "external_user_id": external_user_id,
                    "mask": mask,
                    "token_id": token_id,
                },
                payment_create_method_params.PaymentCreateMethodParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )

    async def delete_intent(
        self,
        *,
        payment_intent_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> None:
        """Enables deletion of a pending payment intent.

        Payment intents in a terminal
        state cannot be deleted.

        Args:
          payment_intent_id: The payment intent ID.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {"Accept": "*/*", **(extra_headers or {})}
        return await self._delete(
            "/v1/payment/intent",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=await async_maybe_transform(
                    {"payment_intent_id": payment_intent_id}, payment_delete_intent_params.PaymentDeleteIntentParams
                ),
            ),
            cast_to=NoneType,
        )

    async def get_pin_attempt_count(
        self,
        *,
        retrieval_reference_number: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentGetPinAttemptCountResponse:
        """
        Endpoint for getting the pin attempt count for the day.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/payment/pin-attempt",
            body=await async_maybe_transform(
                {"retrieval_reference_number": retrieval_reference_number},
                payment_get_pin_attempt_count_params.PaymentGetPinAttemptCountParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentGetPinAttemptCountResponse,
        )

    async def refund(
        self,
        *,
        amount: int,
        payment_type: Literal["SNAP", "EBT_CASH"],
        token_id: str,
        order_id: str | Omit = omit,
        payment_intent_id: str | Omit = omit,
        idempotency_key: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentRefundResponse:
        """
        Allows a payment to be fully or partially refunded based on the refund intent
        parameters. A refunded payment will appear on a customer's EBT account.

        Args:
          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        extra_headers = {**strip_not_given({"Idempotency-Key": idempotency_key}), **(extra_headers or {})}
        return await self._post(
            "/v1/payment/refund",
            body=await async_maybe_transform(
                {
                    "amount": amount,
                    "payment_type": payment_type,
                    "token_id": token_id,
                    "order_id": order_id,
                    "payment_intent_id": payment_intent_id,
                },
                payment_refund_params.PaymentRefundParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentRefundResponse,
        )

    async def reverse(
        self,
        *,
        payment_intent_id: str | Omit = omit,
        refund_intent_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> PaymentReverseResponse:
        """Allows a payment or refund to be reversed.

        A reversed payment will not appear on
        a customer's EBT account.

        Args:
          payment_intent_id: The payment intent ID.

          refund_intent_id: The refund intent ID.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/payment/reverse",
            body=await async_maybe_transform(
                {
                    "payment_intent_id": payment_intent_id,
                    "refund_intent_id": refund_intent_id,
                },
                payment_reverse_params.PaymentReverseParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=PaymentReverseResponse,
        )

    async def update_intent(
        self,
        *,
        fulfillment_address: AddressParam,
        fulfillment_type: FulfillmentType,
        payment_intent_id: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> object:
        """
        Enables updating a payment intent that is not in a terminal state.

        Args:
          fulfillment_address: The fulfillment address.

          fulfillment_type: The fulfillment type.

          payment_intent_id: The payment intent ID requiring update.

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._patch(
            "/v1/payment/intent",
            body=await async_maybe_transform(
                {
                    "fulfillment_address": fulfillment_address,
                    "fulfillment_type": fulfillment_type,
                    "payment_intent_id": payment_intent_id,
                },
                payment_update_intent_params.PaymentUpdateIntentParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=object,
        )


class PaymentResourceWithRawResponse:
    def __init__(self, payment: PaymentResource) -> None:
        self._payment = payment

        self.create_intent = to_raw_response_wrapper(
            payment.create_intent,
        )
        self.create_method = to_raw_response_wrapper(
            payment.create_method,
        )
        self.delete_intent = to_raw_response_wrapper(
            payment.delete_intent,
        )
        self.get_pin_attempt_count = to_raw_response_wrapper(
            payment.get_pin_attempt_count,
        )
        self.refund = to_raw_response_wrapper(
            payment.refund,
        )
        self.reverse = to_raw_response_wrapper(
            payment.reverse,
        )
        self.update_intent = to_raw_response_wrapper(
            payment.update_intent,
        )


class AsyncPaymentResourceWithRawResponse:
    def __init__(self, payment: AsyncPaymentResource) -> None:
        self._payment = payment

        self.create_intent = async_to_raw_response_wrapper(
            payment.create_intent,
        )
        self.create_method = async_to_raw_response_wrapper(
            payment.create_method,
        )
        self.delete_intent = async_to_raw_response_wrapper(
            payment.delete_intent,
        )
        self.get_pin_attempt_count = async_to_raw_response_wrapper(
            payment.get_pin_attempt_count,
        )
        self.refund = async_to_raw_response_wrapper(
            payment.refund,
        )
        self.reverse = async_to_raw_response_wrapper(
            payment.reverse,
        )
        self.update_intent = async_to_raw_response_wrapper(
            payment.update_intent,
        )


class PaymentResourceWithStreamingResponse:
    def __init__(self, payment: PaymentResource) -> None:
        self._payment = payment

        self.create_intent = to_streamed_response_wrapper(
            payment.create_intent,
        )
        self.create_method = to_streamed_response_wrapper(
            payment.create_method,
        )
        self.delete_intent = to_streamed_response_wrapper(
            payment.delete_intent,
        )
        self.get_pin_attempt_count = to_streamed_response_wrapper(
            payment.get_pin_attempt_count,
        )
        self.refund = to_streamed_response_wrapper(
            payment.refund,
        )
        self.reverse = to_streamed_response_wrapper(
            payment.reverse,
        )
        self.update_intent = to_streamed_response_wrapper(
            payment.update_intent,
        )


class AsyncPaymentResourceWithStreamingResponse:
    def __init__(self, payment: AsyncPaymentResource) -> None:
        self._payment = payment

        self.create_intent = async_to_streamed_response_wrapper(
            payment.create_intent,
        )
        self.create_method = async_to_streamed_response_wrapper(
            payment.create_method,
        )
        self.delete_intent = async_to_streamed_response_wrapper(
            payment.delete_intent,
        )
        self.get_pin_attempt_count = async_to_streamed_response_wrapper(
            payment.get_pin_attempt_count,
        )
        self.refund = async_to_streamed_response_wrapper(
            payment.refund,
        )
        self.reverse = async_to_streamed_response_wrapper(
            payment.reverse,
        )
        self.update_intent = async_to_streamed_response_wrapper(
            payment.update_intent,
        )
