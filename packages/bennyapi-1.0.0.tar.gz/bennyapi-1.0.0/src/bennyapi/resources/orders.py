# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable

import httpx

from ..types import order_create_session_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.item_param import ItemParam
from ..types.order_create_session_response import OrderCreateSessionResponse

__all__ = ["OrdersResource", "AsyncOrdersResource"]


class OrdersResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> OrdersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Benny-API/benny-python#accessing-raw-response-data-eg-headers
        """
        return OrdersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> OrdersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Benny-API/benny-python#with_streaming_response
        """
        return OrdersResourceWithStreamingResponse(self)

    def create_session(
        self,
        *,
        items: Iterable[ItemParam],
        on_exit_redirect_url: str,
        on_success_redirect_url: str,
        external_customer_id: str | Omit = omit,
        external_order_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OrderCreateSessionResponse:
        """
        Returns a unique URL for the Benny-hosted checkout session to complete an EBT
        order.

        Args:
          items: List of items in the shopping cart

          on_exit_redirect_url: The URL to redirect the customer to on checkout exit

          on_success_redirect_url: The URL to redirect the customer to on checkout success

          external_customer_id: An optional ID unique to your organization representing the customer

          external_order_id: An optional ID unique to your organization representing the order

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/order/session",
            body=maybe_transform(
                {
                    "items": items,
                    "on_exit_redirect_url": on_exit_redirect_url,
                    "on_success_redirect_url": on_success_redirect_url,
                    "external_customer_id": external_customer_id,
                    "external_order_id": external_order_id,
                },
                order_create_session_params.OrderCreateSessionParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OrderCreateSessionResponse,
        )


class AsyncOrdersResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncOrdersResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/Benny-API/benny-python#accessing-raw-response-data-eg-headers
        """
        return AsyncOrdersResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncOrdersResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/Benny-API/benny-python#with_streaming_response
        """
        return AsyncOrdersResourceWithStreamingResponse(self)

    async def create_session(
        self,
        *,
        items: Iterable[ItemParam],
        on_exit_redirect_url: str,
        on_success_redirect_url: str,
        external_customer_id: str | Omit = omit,
        external_order_id: str | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> OrderCreateSessionResponse:
        """
        Returns a unique URL for the Benny-hosted checkout session to complete an EBT
        order.

        Args:
          items: List of items in the shopping cart

          on_exit_redirect_url: The URL to redirect the customer to on checkout exit

          on_success_redirect_url: The URL to redirect the customer to on checkout success

          external_customer_id: An optional ID unique to your organization representing the customer

          external_order_id: An optional ID unique to your organization representing the order

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/order/session",
            body=await async_maybe_transform(
                {
                    "items": items,
                    "on_exit_redirect_url": on_exit_redirect_url,
                    "on_success_redirect_url": on_success_redirect_url,
                    "external_customer_id": external_customer_id,
                    "external_order_id": external_order_id,
                },
                order_create_session_params.OrderCreateSessionParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=OrderCreateSessionResponse,
        )


class OrdersResourceWithRawResponse:
    def __init__(self, orders: OrdersResource) -> None:
        self._orders = orders

        self.create_session = to_raw_response_wrapper(
            orders.create_session,
        )


class AsyncOrdersResourceWithRawResponse:
    def __init__(self, orders: AsyncOrdersResource) -> None:
        self._orders = orders

        self.create_session = async_to_raw_response_wrapper(
            orders.create_session,
        )


class OrdersResourceWithStreamingResponse:
    def __init__(self, orders: OrdersResource) -> None:
        self._orders = orders

        self.create_session = to_streamed_response_wrapper(
            orders.create_session,
        )


class AsyncOrdersResourceWithStreamingResponse:
    def __init__(self, orders: AsyncOrdersResource) -> None:
        self._orders = orders

        self.create_session = async_to_streamed_response_wrapper(
            orders.create_session,
        )
