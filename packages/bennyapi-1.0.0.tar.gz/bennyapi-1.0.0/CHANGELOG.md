# Changelog

## 1.0.0 (2026-02-22)

Full Changelog: [v0.1.0...v1.0.0](https://github.com/Benny-API/benny-python/compare/v0.1.0...v1.0.0)

### Features

* **api:** add is_refunded field to item parameters ([eabd186](https://github.com/Benny-API/benny-python/commit/eabd1869aaefa3f8a0c636ffcab4a36bccb06609))
* **api:** add mask param, rename payment_method_id to token_id in payment resource ([a5a4191](https://github.com/Benny-API/benny-python/commit/a5a4191f6d5ced37e2a6e66dadb2381f1d3f65b9))


### Chores

* **internal:** remove mock server code ([ca7d92f](https://github.com/Benny-API/benny-python/commit/ca7d92fb5771a66f9f134394632fa15ac0ec3c21))
* update mock server docs ([f068eb4](https://github.com/Benny-API/benny-python/commit/f068eb4705ca8524224ca59f10afc7eb610ccb39))

## 0.1.0 (2026-02-15)

Full Changelog: [v0.0.2...v0.1.0](https://github.com/Benny-API/benny-python/compare/v0.0.2...v0.1.0)

### Features

* **api:** manual updates ([4a46438](https://github.com/Benny-API/benny-python/commit/4a4643800faf0ab9c7aba6e8214864f2bf360cb0))

## 0.0.2 (2026-02-15)

Full Changelog: [v0.0.1...v0.0.2](https://github.com/Benny-API/benny-python/compare/v0.0.1...v0.0.2)

### Chores

* configure new SDK language ([2eeaa20](https://github.com/Benny-API/benny-python/commit/2eeaa208aa728bb9c0712ece9067a188debb53d3))
* update SDK settings ([548f3e4](https://github.com/Benny-API/benny-python/commit/548f3e434e266fa51f838353dc5c34bb5e874251))
* update SDK settings ([4a26383](https://github.com/Benny-API/benny-python/commit/4a26383d1d85d3af5085cbbdfbab2e82fdfb16d9))
* update SDK settings ([862a7e0](https://github.com/Benny-API/benny-python/commit/862a7e0eb2b483368855d246f5dd138403ee4359))
