"""Tool: scheduler — View scheduler status or toggle on/off.

Thin dispatcher that routes to existing run_* functions based on the action parameter.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


async def run_scheduler(
    action: str = "status",
    enabled: bool = True,
    cloud: bool = False,
    hours: int = 24,
    event_type: str = "",
    campaign_id: str = "",
) -> str:
    """Manage the autonomous scheduler.

    Actions:
      status      — Show scheduler status, pending jobs, and recent activity
      toggle      — Enable or disable the scheduler
      logs        — Event log with metrics and recent failures
      diagnostics — Full system diagnostics: rate limits, timers, blockers

    Args:
        action: What to do: 'status', 'toggle', 'logs', or 'diagnostics'.
        enabled: True to enable, False to disable (for 'toggle').
        cloud: If True, toggle the cloud scheduler for 24/7 operation (for 'toggle').
        hours: Lookback window in hours for 'logs' (default 24).
        event_type: Filter events by type for 'logs'.
        campaign_id: Filter by campaign for 'logs' and 'diagnostics'.
    """
    action = action.lower().strip()

    if action == "status":
        from .scheduler_status import run_scheduler_status
        return await run_scheduler_status()

    if action == "toggle":
        from .scheduler_status import run_toggle_scheduler
        return await run_toggle_scheduler(enabled=enabled, cloud=cloud)

    if action == "logs":
        from .scheduler_status import run_scheduler_logs
        return await run_scheduler_logs(
            hours=hours, event_type=event_type, campaign_id=campaign_id,
        )

    if action == "diagnostics":
        from .scheduler_status import run_scheduler_diagnostics
        return await run_scheduler_diagnostics(campaign_id=campaign_id)

    return f"Unknown action: '{action}'. Use 'status', 'toggle', 'logs', or 'diagnostics'."
