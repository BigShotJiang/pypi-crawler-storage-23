"""Tool: account — Manage LinkedIn accounts (list, switch, unlink).

Thin dispatcher that routes to existing run_* functions based on the action parameter.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


async def run_account(
    action: str = "list",
    account_id: str = "",
) -> str:
    """Manage LinkedIn accounts.

    Actions:
      list      — Show all connected LinkedIn accounts
      switch    — List accounts and pick one to switch to
      switch_to — Switch to a specific account by ID
      unlink    — Disconnect the current LinkedIn account

    Args:
        action: What to do: 'list', 'switch', 'switch_to', 'unlink'.
        account_id: The Unipile account ID (required for 'switch_to').
    """
    action = action.lower().strip()

    if action == "list":
        from .switch_account import run_list_linkedin_accounts
        return await run_list_linkedin_accounts()

    if action == "switch":
        from .switch_account import run_switch_account
        return await run_switch_account()

    if action == "switch_to":
        if not account_id:
            return "Error: 'account_id' is required for action='switch_to'. Use account(action='list') to see IDs."
        from .switch_account import run_switch_account_to
        return await run_switch_account_to(account_id)

    if action == "unlink":
        from .unlink_account import run_unlink_account
        return await run_unlink_account()

    return f"Unknown action: '{action}'. Use 'list', 'switch', 'switch_to', or 'unlink'."
