package com.ruoyi.common.utils;

import org.assertj.core.util.Lists;
import org.springframework.util.CollectionUtils;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ListUtil {

    /**
     * 获取 List<T> 移除第一个和最后一个元素后的集合
     *
     * @param originalList
     * @param <T>
     * @return
     */
    public static <T> List<T> removeFirstAndLastUsingStream(List<T> originalList) {
        // 检查 List 大小，如果小于 2，则无法移除第一个和最后一个
        if (CollectionUtils.isEmpty(originalList) || originalList.size() < 2) {
            return new ArrayList<>();
        }

        return originalList.stream()
                .skip(1) // 跳过第一个元素
                .limit(originalList.size() - 2) // 限制流中元素的数量为原始大小减去 2
                .collect(Collectors.toList());
    }

    public static <T> List<List<T>> split(List<T> list, int size) {
        if (CollectionUtils.isEmpty(list)) return Lists.newArrayList();
        return IntStream.range(0, (list.size() + size - 1) / size)
                .mapToObj(i -> list.subList(i * size, Math.min((i + 1) * size, list.size())))
                .collect(Collectors.toList());
    }

    public static <T, E> List<T> sortList(List<T> list, List<E> order, Function<T, E> key) {
        if (CollectionUtils.isEmpty(list) || CollectionUtils.isEmpty(order) || key == null) return list;
        return list.stream().sorted(Comparator.comparing(item -> order.indexOf(key.apply(item)))).collect(Collectors.toList());
    }

    public static void sortMapList(List<Map<String, Object>> mapList, List<String> order, String key) {
        if (CollectionUtils.isEmpty(mapList) || CollectionUtils.isEmpty(order) || StringUtils.isEmpty(key)) return;
        Comparator<Map<String, Object>> comparator = Comparator.comparing(entry -> order.indexOf(entry.get(key)));
        mapList.sort(comparator);
    }

}
