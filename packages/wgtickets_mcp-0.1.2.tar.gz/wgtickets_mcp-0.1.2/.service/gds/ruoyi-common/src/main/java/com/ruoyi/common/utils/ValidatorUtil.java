package com.ruoyi.common.utils;

import org.apache.commons.collections4.CollectionUtils;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.Set;
import java.util.stream.Collectors;

public class ValidatorUtil {

    private static final Validator validator;

    static {
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        validator = factory.getValidator();
    }

    public static <T> Set<ConstraintViolation<T>> validateObj(T t, Class<?>... groups) {
        return validator.validate(t, groups);
    }

    public static <T> String validate(T t, Class<?>... groups) {
        Set<ConstraintViolation<T>> violationSet = validateObj(t, groups);
        if (CollectionUtils.isEmpty(violationSet)) return "";

        /*violationSet.forEach(item -> System.out.println(item.getPropertyPath() + ": " + item.getMessage()));*/

        return violationSet.stream().map(ConstraintViolation::getMessage).filter(StringUtils::isNotBlank).distinct().collect(Collectors.joining(";\n"));
    }

}
