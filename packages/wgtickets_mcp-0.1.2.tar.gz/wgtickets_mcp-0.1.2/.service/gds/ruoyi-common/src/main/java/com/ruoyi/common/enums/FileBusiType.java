package com.ruoyi.common.enums;

import lombok.Getter;

@Getter
public enum FileBusiType {


    POLICY_FILE(33,"政策文件"),
    ;

    private final int code;
    private final String desc;

    FileBusiType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static FileBusiType get(Integer code){
        if (code == null){
            return null;
        }
        for (FileBusiType typeEnum : FileBusiType.values()){
            if (typeEnum.getCode() == code){
                return typeEnum;
            }
        }
        return null;
    }

    public int getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }
}
