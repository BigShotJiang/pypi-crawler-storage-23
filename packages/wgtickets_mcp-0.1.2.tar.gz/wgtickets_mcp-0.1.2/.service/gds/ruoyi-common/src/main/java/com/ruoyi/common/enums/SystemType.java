package com.ruoyi.common.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum SystemType {

    TMC("TMC", "Ticket"),
    OTA("OTA", "OTA"),
    VISA_CENTER("VISA", "签证中心"),
    ADMINISTRATIVE("ADMINISTRATIVE", "行政書士");

    private final String code;

    private final String desc;

    // 构造器
    SystemType(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    // 根据状态码获取枚举
    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static SystemType fromCode(String code) {
        return Arrays.stream(SystemType.values())
                .filter(item -> Objects.nonNull(code) && item.code.equalsIgnoreCase(code))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }
    
}
