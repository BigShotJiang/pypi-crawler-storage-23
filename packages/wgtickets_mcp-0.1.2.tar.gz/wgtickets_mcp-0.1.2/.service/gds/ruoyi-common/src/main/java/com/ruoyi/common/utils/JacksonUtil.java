package com.ruoyi.common.utils;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
public class JacksonUtil {

    private static final ObjectMapper mapper;

    private static final ObjectMapper mapper_nonull;

    static {
        mapper = new ObjectMapper();
        mapper.registerModule(new JavaTimeModule());
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);

        mapper_nonull = new ObjectMapper();
        mapper_nonull.registerModule(new JavaTimeModule());
        mapper_nonull.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
        mapper_nonull.setSerializationInclusion(JsonInclude.Include.NON_NULL);
    }

    public static String toJsonString(Object obj) {
        if (Objects.isNull(obj)) {
            return null;
        }

        try {
            return mapper.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            log.error("Bean转Json失败", e);
            return null;
        }
    }

    public static String toJsonStringNoNull(Object obj) {
        if (Objects.isNull(obj)) {
            return null;
        }

        try {
            return mapper_nonull.writeValueAsString(obj);
        } catch (JsonProcessingException e) {
            log.error("Bean转Json失败", e);
            return null;
        }
    }

    public static <T> List<T> toBeanList(String json, Class<T> clazz) {
        if (StringUtils.isBlank(json)) {
            return Collections.emptyList();
        }

        try {
            List<T> rawList = mapper.readValue(json, new TypeReference<List<T>>() {}); // 先读取为 List<?>
            return rawList.stream()
                    .map(item -> mapper.convertValue(item, clazz))
                    .collect(Collectors.<T>toList());
        } catch (JsonProcessingException e) {
            log.error("Json转Bean数组失败", e);
            return Collections.emptyList();
        }
    }

    public static <T> T toBean(String json, Class<T> clazz) {
        if (StringUtils.isBlank(json)) {
            return null;
        }

        try {
            return mapper.readValue(json, clazz);
        } catch (JsonProcessingException e) {
            log.error("Json转Bean失败", e);
            return null;
        }
    }


}
