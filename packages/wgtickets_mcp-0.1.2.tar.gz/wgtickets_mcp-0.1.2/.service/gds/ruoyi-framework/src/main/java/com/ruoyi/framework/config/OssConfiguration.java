package com.ruoyi.framework.config;

import com.ruoyi.common.utils.oss.OssBootUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * 云存储 配置
 */
@Configuration
public class OssConfiguration {

    @Value("${ruoyi.oss.endpoint}")
    private String endpoint;
    @Value("${ruoyi.oss.accessKey}")
    private String accessKeyId;
    @Value("${ruoyi.oss.secretKey}")
    private String accessKeySecret;
    @Value("${ruoyi.oss.bucketName}")
    private String bucketName;
    @Value("${ruoyi.oss.staticDomain}")
    private String staticDomain;
    @Value("${ruoyi.oss.profile}")
    private String profile;



    @Bean
    public void initOssBootConfiguration() {
        OssBootUtil.setEndPoint(endpoint);
        OssBootUtil.setAccessKeyId(accessKeyId);
        OssBootUtil.setAccessKeySecret(accessKeySecret);
        OssBootUtil.setBucketName(bucketName);
        OssBootUtil.setStaticDomain(staticDomain);
        OssBootUtil.setProfile(profile);
    }
}