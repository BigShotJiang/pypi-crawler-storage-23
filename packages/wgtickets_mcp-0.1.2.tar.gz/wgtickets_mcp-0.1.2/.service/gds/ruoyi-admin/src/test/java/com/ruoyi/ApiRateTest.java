package com.ruoyi;

import com.ruoyi.gds.config.GDSConfig;
import com.ruoyi.gds.enums.BusinessType;
import com.ruoyi.gds.forest.IBEApi;
import com.ruoyi.gds.schema.ibe.*;
import com.ruoyi.gds.utils.StrUtil;
import com.ruoyi.gds.utils.XmlUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;
import java.util.Optional;
import java.util.concurrent.Future;

@Slf4j
@SpringBootTest
@RunWith(SpringRunner.class)
public class ApiRateTest {

    @Autowired
    private IBEApi ibeApi;
    @Autowired
    private GDSConfig gdsConfig;
    @Autowired
    @Qualifier("taskExecutor")
    private ThreadPoolTaskExecutor taskExecutor;

    @Test
    public void apiRateTest() {
        String requestXml = StrUtil.readFile("/Users/huqiquan/Desktop/ibe-search-low-price.xml");
        byte[] bytes = StrUtil.zip(requestXml);

        List<Future<Boolean>> futures = Lists.newArrayList();
        for (int i = 0; i < 10; i++) {
            try {
                Future<Boolean> future = taskExecutor.submit(() -> {
                    String responseXml = ibeApi.send(BusinessType.QUERY_PRICE, "807659166830301184", "/develop/xml/AirFarePrice/I", bytes);

                    try {
                        TSKAirfarePrice resultVo = XmlUtil.xmlToBeanByJAXB(responseXml, TSKAirfarePrice.class);
                        return true;
                    } catch (Exception e) {
                        TSKAirfarePriceNoNS resultVoNoNS = XmlUtil.xmlToBeanByJAXB(responseXml, TSKAirfarePriceNoNS.class);
                        String errorMsg = Optional.ofNullable(resultVoNoNS)
                                .map(TSKAirfarePriceNoNS::getResponse)
                                .map(ResponseNoNS::getPriceError)
                                .map(PriceError::getCnMessage)
                                .orElse(Optional.ofNullable(resultVoNoNS)
                                        .map(TSKAirfarePriceNoNS::getResponse)
                                        .map(ResponseNoNS::getSitaAirfarePriceRS)
                                        .map(SITAAirfarePriceRSNoNS::getOtaAirPriceRS)
                                        .map(OTAAirPriceRSNoNS::getErrorMsg)
                                        .orElse(null));
                        if (StringUtils.isNotBlank(errorMsg)) System.out.println(errorMsg);
                        return false;
                    }
                });
                futures.add(future);
            } catch (Exception e) {
                log.error("行程报价—异步查询—失败", e);
            }
        }

        List<Boolean> flags = Lists.newArrayList();
        for (Future<Boolean> future : futures) {
            try {
                flags.add(future.get());
            } catch (Exception e) {
                log.error("行程报价—异步查询—获取结果失败", e);
            }
        }

        long successCount = flags.stream().filter(flag -> flag).count();
        long failCount = flags.stream().filter(flag -> !flag).count();
        System.out.println("执行完毕. 成功: " +  successCount + ", 失败: " + failCount);
    }

}
