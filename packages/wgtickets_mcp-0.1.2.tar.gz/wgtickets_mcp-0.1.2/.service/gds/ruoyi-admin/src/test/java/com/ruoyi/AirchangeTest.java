package com.ruoyi;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.crypto.digest.DigestUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.annotation.ExcelProperty;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.read.listener.ReadListener;
import com.ruoyi.common.core.redis.RedisCache;
import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.fileupload.easyexcel.CustomCellWriteHandler;
import com.ruoyi.gds.enums.FczFlightStatus;
import com.ruoyi.gds.forest.FczApi;
import com.ruoyi.gds.module.QueryPnrInfoReq;
import com.ruoyi.gds.module.QueryPnrRsp;
import com.ruoyi.gds.module.vo.FczAirchangeFlightInfo;
import com.ruoyi.gds.service.AirService;
import com.ruoyi.gds.utils.IntConvertUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Slf4j
@SpringBootTest
@RunWith(SpringRunner.class)
public class AirchangeTest {

    @Autowired
    private RedisCache redisCache;
    @Autowired
    private FczApi fczApi;
    @Autowired
    private AirService airService;


    @Value("${fcz.app-id}")
    private String fczAppid;
    @Value("${fcz.app-security}")
    private String fczAppSecurity;

    private final AtomicInteger COUNT = new AtomicInteger(0);
    private static final String FILE_PARENT_PATH = "/Users/huqiquan/Desktop/航变修数据/已出票";
    private static final String FILE_NAME = "航班-已出票_副本6.xlsx";

    private static final List<String> AIRCHANGED_STATUS = FczFlightStatus.airchangedStatus().stream().map(FczFlightStatus::getDesc).collect(Collectors.toList());

    private static final String AIRCHANGED_YES = "是";
    private static final String AIRCHANGED_NO = "否";

    @Test
    public void check_ticket_airchange() throws IOException {
        List<FlightInfo> flightInfos = readData();

        List<TicketFlightCheckResult> checkResults = Lists.newArrayList();
        for (FlightInfo flightInfo : flightInfos) {
            TicketFlightCheckResult checkResult = new TicketFlightCheckResult();
            BeanUtils.copyProperties(flightInfo, checkResult);

            Boolean airchanged = checkAirchangedByGDS(flightInfo.getPnr());
            if (Objects.nonNull(airchanged)) {
                checkResult.setAirchanged(airchanged ? AIRCHANGED_YES : AIRCHANGED_NO);
                checkResults.add(checkResult);
                continue;
            }

            List<FczAirchangeFlightInfo> fczAirchangeFlightInfos = queryFlightInfo(flightInfo.getDepDate(), flightInfo.getFlightNumber());
            if (CollectionUtil.isEmpty(fczAirchangeFlightInfos)) {
                checkResult.setRemark("查询飞常准航班信息为空");
                checkResults.add(checkResult);
                continue;
            }

            long airchangeNum = fczAirchangeFlightInfos.stream()
                    .filter(fczAirchangeFlightInfo -> StringUtils.isNotBlank(fczAirchangeFlightInfo.getFlightState()) && AIRCHANGED_STATUS.contains(fczAirchangeFlightInfo.getFlightState().trim()))
                    .count();

            checkResult.setAirchanged(airchangeNum > 0 ? AIRCHANGED_YES : AIRCHANGED_NO);
            checkResults.add(checkResult);
        }

        String fileName = FILE_PARENT_PATH + File.separator + FILE_NAME.split("\\.")[0] + "-查询结果.xlsx";
        EasyExcel.write(fileName, TicketFlightCheckResult.class).registerWriteHandler(new CustomCellWriteHandler()).sheet("航班信息").doWrite(checkResults);
        System.out.println("飞常准查询次数: " + COUNT.get());

        generateSql(checkResults, false);
    }

    @Test
    public void read_ticket_airchange_result() throws IOException {
        FileInputStream fis = new FileInputStream(FILE_PARENT_PATH + File.separator + FILE_NAME.split("\\.")[0] + "-查询结果.xlsx");
        List<TicketFlightCheckResult> checkResults = Lists.newArrayList();
        EasyExcel.read(fis, TicketFlightCheckResult.class, new CustomListener<>(checkResults)).headRowNumber(1).sheet().doRead();
        generateSql(checkResults, false);
    }

    private void generateSql(List<TicketFlightCheckResult> checkResults, boolean recheckByGDS) throws IOException {
        Map<String, List<TicketFlightCheckResult>> ticketMap = checkResults.stream().collect(Collectors.groupingBy(TicketFlightCheckResult::getTicketId));
        String temp = "update fin_ticket set air_change_status = 0 where id = %s;\n";
        StringBuilder builder = new StringBuilder();
        for (Map.Entry<String, List<TicketFlightCheckResult>> entry : ticketMap.entrySet()) {
            long airchangedSegmentCount = entry.getValue().stream()
                    .filter(checkResult -> StringUtils.isNotBlank(checkResult.getAirchanged()) && AIRCHANGED_YES.equals(checkResult.getAirchanged()))
                    .count();
            if (airchangedSegmentCount > 0) {
                if (recheckByGDS) {
                    Boolean airchanged = checkAirchangedByGDS(entry.getValue().get(0).getPnr());
                    if (Objects.nonNull(airchanged) && !airchanged) {
                        builder.append(String.format(temp, entry.getKey()));
                    }
                }
            } else {
                builder.append(String.format(temp, entry.getKey()));
            }
        }

        Files.write(Paths.get(FILE_PARENT_PATH + File.separator + FILE_NAME.split("\\.")[0] + "-update.sql"), builder.toString().getBytes());
    }

    private Boolean checkAirchangedByGDS(String pnr) {
        if (StringUtils.isBlank(pnr) || pnr.length() != 6 || IntConvertUtil.isNumber(pnr)) {
            return null;
        }

        QueryPnrInfoReq queryPnrInfoReq = QueryPnrInfoReq.builder().gds(null).pnr(pnr).build();
        QueryPnrRsp<Object> queryPnrRsp = airService.queryPnr(queryPnrInfoReq);
        if (Objects.isNull(queryPnrRsp) || CollectionUtil.isEmpty(queryPnrRsp.getFlights())) return null;
        long notHKCount = queryPnrRsp.getFlights().stream()
                .filter(flight -> !"HK".equalsIgnoreCase(flight.getStatus()))
                .count();
        return notHKCount > 0;
    }

    private List<FczAirchangeFlightInfo> queryFlightInfo(LocalDate date, String carrierFlightNumber) {
        try {
            String carrier = carrierFlightNumber.substring(0, 2);
            Integer flightNumber = Integer.parseInt(carrierFlightNumber.substring(2));

            String redisCacheKey = getRedisCacheKey(date, carrier, flightNumber);
            List<FczAirchangeFlightInfo> fczAirchangeFlightInfos = redisCache.getCacheList(redisCacheKey);
            if (CollectionUtil.isNotEmpty(fczAirchangeFlightInfos)) return fczAirchangeFlightInfos;

            fczAirchangeFlightInfos = queryAirchangeFcz(date.format(DateTimeFormatter.ofPattern(DatePattern.NORM_DATE_PATTERN)), carrier + flightNumber);
            redisCache.setCacheList(redisCacheKey, fczAirchangeFlightInfos);
            return fczAirchangeFlightInfos;
        } catch (Exception e) {
            log.error("【{}】【{}】查询航班异常", date.format(DateTimeFormatter.ofPattern(DatePattern.NORM_DATE_PATTERN)), carrierFlightNumber, e);
            return Lists.newArrayList();
        }
    }

    private static String getRedisCacheKey(LocalDate date, String carrier, Integer flightNumber) {
        String dateStr = date.format(DateTimeFormatter.ofPattern(DatePattern.PURE_DATE_PATTERN));
        return "fcz_flight_info:" + dateStr + carrier.toUpperCase() + flightNumber;
    }

    private List<FczAirchangeFlightInfo> queryAirchangeFcz(String date, String fnum) {
        TreeMap<String, String> treeMap = new TreeMap<>();
        treeMap.put("appid", fczAppid);
        treeMap.put("date", date);
        treeMap.put("fnum", fnum);
        String param = treeMap.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue()).collect(Collectors.joining("&")) + fczAppSecurity;
        String md5Param = DigestUtil.md5Hex(DigestUtil.md5Hex(param));
        // System.out.println("[encrypt] before: " + param + ", after: " + md5Param);

        Object result = fczApi.airchangeQuery(fczAppid, date, fnum, md5Param);
        COUNT.incrementAndGet();
        if (result instanceof HashMap) {
            log.info("【{}】【{}】>>>Map: {}", date, fnum, JacksonUtil.toJsonString(result));
            return Lists.newArrayList();
        } else if (result instanceof ArrayList) {
            log.info("【{}】【{}】>>>List: {}", date, fnum, JacksonUtil.toJsonString(result));
            return JacksonUtil.toBeanList(JacksonUtil.toJsonString(result), FczAirchangeFlightInfo.class);
        } else {
            log.info("【{}】【{}】>>>Other: {}", date, fnum, JacksonUtil.toJsonString(result));
            return Lists.newArrayList();
        }
    }

    private List<FlightInfo> readData() throws FileNotFoundException {
        FileInputStream fis = new FileInputStream(FILE_PARENT_PATH + File.separator + FILE_NAME);
        List<FlightInfo> flightInfos = Lists.newArrayList();
        EasyExcel.read(fis, FlightInfo.class, new CustomListener<>(flightInfos)).headRowNumber(1).sheet().doRead();
        return flightInfos;
    }

    public static class CustomListener<T> implements ReadListener<T> {
        private final List<T> rows;

        public CustomListener(List<T> rows) {
            this.rows = rows;
        }

        @Override
        public void invoke(T t, AnalysisContext analysisContext) {
            rows.add(t);
        }

        @Override
        public void doAfterAllAnalysed(AnalysisContext analysisContext) {

        }
    }

    @Data
    @SuperBuilder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FlightInfo implements Serializable {

        private static final long serialVersionUID = 1L;

        @ExcelProperty(value = "票ID", index = 0)
        private String ticketId;

        @ExcelProperty(value = "PNR", index = 1)
        private String pnr;

        @ExcelProperty(value = "出发日期", index = 2)
        private LocalDate depDate;

        @ExcelProperty(value = "航班号", index = 3)
        private String flightNumber;

        @ExcelProperty(value = "出发机场", index = 4)
        private String origin;

        @ExcelProperty(value = "到达机场", index = 5)
        private String destination;
    }

    @EqualsAndHashCode(callSuper = true)
    @Data
    @SuperBuilder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TicketFlightCheckResult extends FlightInfo {

        private static final long serialVersionUID = 1L;

        @ExcelProperty(value = "已航变", index = 6)
        private String airchanged;

        @ExcelProperty(value = "备注", index = 7)
        private String remark;

    }

}
