package com.ruoyi;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.io.FileUtil;
import cn.hutool.crypto.digest.DigestUtil;
import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.dtflys.forest.Forest;
import com.dtflys.forest.http.ForestQueryMap;
import com.dtflys.forest.http.ForestResponse;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.module.vo.ResultVo;
import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.UUIDUtil;
import com.ruoyi.common.utils.sign.Md5Utils;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.common.RabbitmqConstant;
import com.ruoyi.gds.common.SabreConstant;
import com.ruoyi.gds.config.GDSConfig;
import com.ruoyi.gds.enums.*;
import com.ruoyi.gds.enums.PassengerType;
import com.ruoyi.gds.enums.ibe.IBECarbinType;
import com.ruoyi.gds.enums.ibe.IBELocationType;
import com.ruoyi.gds.enums.sabre.SabrePartyIdType;
import com.ruoyi.gds.enums.sabre.WebSvcAction;
import com.ruoyi.gds.forest.*;
import com.ruoyi.gds.module.*;
import com.ruoyi.gds.module.domain.*;
import com.ruoyi.gds.module.dto.CabinScanDto;
import com.ruoyi.gds.module.dto.galileo.RequestBuilder;
import com.ruoyi.gds.module.dto.ibe.*;
import com.ruoyi.gds.module.vo.*;
import com.ruoyi.gds.module.vo.RateRsp;
import com.ruoyi.gds.module.vo.eightyi.*;
import com.ruoyi.gds.module.vo.galileo.FlightBookingVo;
import com.ruoyi.gds.module.vo.galileo.FlightPlantVo;
import com.ruoyi.gds.module.vo.huanyu.HuanYuPnrPolicyPriceReq;
import com.ruoyi.gds.module.vo.huanyu.HuanYuPnrPolicyPriceResp;
import com.ruoyi.gds.module.vo.ibe.IBESearchFlightResultVo;
import com.ruoyi.gds.module.vo.sabre.OfferPriceRequestV1;
import com.ruoyi.gds.module.vo.sabre.Query;
import com.ruoyi.gds.schema.galileo.air_v50_0.*;
import com.ruoyi.gds.schema.galileo.common_v50_0.*;
import com.ruoyi.gds.schema.galileo.gdsqueue_v50_0.*;
import com.ruoyi.gds.schema.galileo.req.*;
import com.ruoyi.gds.schema.galileo.rsp.*;
import com.ruoyi.gds.schema.galileo.universal_v50_0.*;
import com.ruoyi.gds.schema.galileo.util_v50_0.CurrencyConversion;
import com.ruoyi.gds.schema.galileo.util_v50_0.CurrencyConversionReq;
import com.ruoyi.gds.schema.ibe.*;
import com.ruoyi.gds.schema.ibe.AirItinerary;
import com.ruoyi.gds.schema.ibe.FlightSegment;
import com.ruoyi.gds.schema.sabre.com.sabre.webservices.TokenCreateRQ;
import com.ruoyi.gds.schema.sabre.com.sabre.webservices.pnrbuilder.v1_19.*;
import com.ruoyi.gds.schema.sabre.com.sabre.webservices.sabrexml._2003._07.pnrpricing.v144.PNRPricingRQ;
import com.ruoyi.gds.schema.sabre.com.sabre.webservices.sabrexml._2011._10.FareLLSRQ.FareRQ;
import com.ruoyi.gds.schema.sabre.com.sabre.webservices.sabrexml._2011._10.OTA_AirAvailLLS.OTAAirAvailRQ;
import com.ruoyi.gds.schema.sabre.com.sabre.webservices.sabrexml._2011._10.OTA_AirAvailLLS.OTAAirAvailRS;
import com.ruoyi.gds.schema.sabre.org.ebxml.namespaces.messageheader.From;
import com.ruoyi.gds.schema.sabre.org.ebxml.namespaces.messageheader.MessageHeader;
import com.ruoyi.gds.schema.sabre.org.ebxml.namespaces.messageheader.PartyId;
import com.ruoyi.gds.schema.sabre.org.ebxml.namespaces.messageheader.To;
import com.ruoyi.gds.schema.sabre.org.opentravel.ota._2002._11.SessionCreateRQ;
import com.ruoyi.gds.schema.sabre.org.xmlsoap.schemas.soap.envelope.Body;
import com.ruoyi.gds.schema.sabre.org.xmlsoap.schemas.soap.envelope.Envelope;
import com.ruoyi.gds.schema.sabre.org.xmlsoap.schemas.soap.envelope.Header;
import com.ruoyi.gds.schema.sabre.org.xmlsoap.schemas.soap.envelope.ObjectFactory;
import com.ruoyi.gds.schema.sabre.org.xmlsoap.schemas.ws._2002._12.secext.Security;
import com.ruoyi.gds.schema.sabre.req.SabreBuilder;
import com.ruoyi.gds.schema.sabre.rsp.BinarySecurityToken;
import com.ruoyi.gds.schema.sabre.rsp.SoapBody;
import com.ruoyi.gds.schema.sabre.rsp.SoapEnvelope;
import com.ruoyi.gds.schema.sabre.rsp.SoapHeader;
import com.ruoyi.gds.service.*;
import com.ruoyi.gds.service.impl.GalileoServiceImpl;
import com.ruoyi.gds.task.RateTask;
import com.ruoyi.gds.utils.*;
import com.ruoyi.system.service.ISysConfigService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.core.env.Environment;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.test.context.junit4.SpringRunner;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
import javax.xml.namespace.QName;
import java.io.IOException;
import java.io.InputStream;
import java.io.StringReader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@SpringBootTest
@RunWith(SpringRunner.class)
public class MyTest {

    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private IBEApi ibeApi;
    @Autowired
    private GalileoApi galileoApi;
    @Autowired
    private SabreRestApi sabreApi;
    @Autowired
    private TicketApi ticketApi;
    @Autowired
    private AirportsService airportsService;
    @Autowired
    private GDSConfig gdsConfig;
    @Autowired
    private GalileoService galileoService;
    @Autowired
    private ISysConfigService sysConfigService;
    @Autowired
    private AirService airService;
    @Autowired
    private IFlightReservationService flightReservationService;
    @Autowired
    private RabbitTemplate rabbitTemplate;
    @Autowired
    private IBEService ibeService;
    @Autowired
    private SabreService sabreService;
    @Autowired
    private IFlightSolutionService flightSolutionService;
    @Autowired
    private IFlightSearchParamSolutionService flightSearchParamSolutionService;
    @Autowired
    @Qualifier("taskExecutor")
    private ThreadPoolTaskExecutor taskExecutor;
    @Autowired
    private IdWorker idWorker;
    @Autowired
    private IFczAirchangeCustomService fczAirchangeCustomService;
    @Autowired
    private FczApi fczApi;
    @Autowired
    private RedissonClient redissonClient;
    @Autowired
    private FunboxApi funBoxApi;
//    @Autowired
//    private PnrTask pnrTask;
    @Autowired
    private RateTask rateTask;

    @Value("${gds.cabin-scan-mock}")
    private String cabinScanMock;

    @Value("${fcz.app-id}")
    private String fczAppid;
    @Value("${fcz.app-security}")
    private String fczAppSecurity;

    @Autowired
    private EightYiForestApi eightYiForestApi;
    @Autowired
    private SabreWebSvcApi sabreWebSvcApi;
    @Autowired
    private Environment env;


    @Test
    public void t() {
        String property = env.getProperty("mq.consume.enable");
        // AirChangeFczReqListener airChangeFczReqListener = SpringUtils.getBean(AirChangeFczReqListener.class);
        System.out.println("");
    }


    private String sendRequestWithLock(String url) {
        // 获取锁对象
        RLock lock = redissonClient.getLock("ibeUrlLock:" + url);

        try {
            // 尝试获取锁，等待3000ms，锁定1秒
            boolean locked = lock.tryLock(20000, 1, TimeUnit.SECONDS);
            if (!locked) throw new ServiceException("访问频率限制，请稍后重试");

            try {
                Thread.sleep(1200);
                if (lock.isHeldByCurrentThread()) lock.unlock();

                Thread.sleep(5000);
                return url;
            } catch (Exception e) {
                // 恢复中断状态
                // Thread.currentThread().interrupt();
                log.error("[IBE] Url: {}, 请求失败.", url, e);
                return null;
            } finally {
                // 安全释放：检查当前线程是否持有锁
                if (lock.isHeldByCurrentThread()) lock.unlock();
            }
        } catch (Exception e) {
            log.error("[IBE] Url: {}, 获取锁失败.", url, e);
            throw new ServiceException("获取锁失败");
        }
    }

    @Test
    public void rate_task() {
        rateTask.rateTask();
    }

    @Test
    public void bank_rate() {
        ForestResponse<ResultVo<FunboxRateVo>> forestResponse = funBoxApi.bankRate("2026-01-26");
        System.out.println(forestResponse.getResult());

        BigDecimal rate = Optional.ofNullable(forestResponse.getResult())
                .map(ResultVo::getData)
                .map(FunboxRateVo::getMiddle)
                .map(middle -> middle.divide(new BigDecimal(100)))
                .orElse(null);
        System.out.println(rate);
    }

    @Test
    public void search_cabin_quantity() {
        SearchCabinReq searchCabinReq = SearchCabinReq.builder()
                .flightFareKeys(Lists.newArrayList("796400908660510722"))
                .passengers(Lists.newArrayList(PassengerType.ADT))
                .useOperating(true)
                .build();
        LinkedList<FlightNumberCabinVo> flightNumberCabinVos = airService.searchCabin(searchCabinReq);
        System.out.println(JacksonUtil.toJsonString(flightNumberCabinVos));
    }

    @Test
    public void sabre_pnr_change_segment_status_2() {
        OrganizeSegmentStatusRsp<UpdateReservationRS> organizeSegmentStatusRsp = sabreService.organizeSegmentStatus("MUHIXS");
        System.out.println(JacksonUtil.toJsonString(organizeSegmentStatusRsp));
    }

    @Test
    public void sabre_pnr_get_reservation_2() {
        QueryPnrRsp<GetReservationRS> queryPnrRsp = sabreService.queryPnrBySoap("MUHIXS");
        System.out.println(JacksonUtil.toJsonString(queryPnrRsp));
    }

    @Test
    public void sabre_pnr_get_reservation() {
        String webSvcSession = sabreService.getWebSvcSession();
        Header header = SabreBuilder.buildHeader(webSvcSession, WebSvcAction.GetReservationRQ);

        String pnr = "MUHIXS";
        GetReservationRQ getReservationRQ = SabreBuilder.buildGetReservationRQ(pnr);

        ObjectFactory objectFactory = new ObjectFactory();
        Body body = objectFactory.createBody();
        body.setGetReservationRQ(getReservationRQ);

        Envelope envelope = objectFactory.createEnvelope();
        envelope.getHeader().add(header);
        envelope.setBody(body);

        String envelopeXml = XmlUtil.beanToXmlByJAXB(envelope);
        ForestResponse<String> response = sabreWebSvcApi.requestWebSvc(BusinessType.QUERY_PNR, "", envelopeXml);

        SoapEnvelope soapEnvelope = XmlUtil.xmlToBeanByJAXB(response.getResult(), SoapEnvelope.class);
        GetReservationRS getReservationRS = Optional.ofNullable(soapEnvelope)
                .map(SoapEnvelope::getBody)
                .map(SoapBody::getGetReservationRS)
                .orElse(null);
        System.out.println("[GetReservationRS] >>> " + JacksonUtil.toJsonString(getReservationRS));

        String updateToken = Optional.ofNullable(getReservationRS)
                .map(GetReservationRS::getReservation)
                .map(ReservationPNRB::getBookingDetails)
                .map(BookingDetailsPNRB::getUpdateToken)
                .orElse(null);
        System.out.println("[PNR] >>> " + pnr + ", [UpdateToken] >>> " + updateToken);
    }

    @Test
    public void sabre_pnr_change_segment_status() {
        String webSvcSession = sabreService.getWebSvcSession();
        Header header = SabreBuilder.buildHeader(webSvcSession, WebSvcAction.UpdateReservationRQ);

        String updateToken = "bVeAjlHN0m3tyMD4xO2MZGHN27vUtu2+i25JRdNfPz6mqnRm3nSv1w==";
        UpdateReservationRQ updateReservationRQ = SabreBuilder.buildUpdateReservationRQForConfirmSegment(updateToken);

        ObjectFactory objectFactory = new ObjectFactory();
        Body body = objectFactory.createBody();
        body.setUpdateReservationRQ(updateReservationRQ);

        Envelope envelope = objectFactory.createEnvelope();
        envelope.getHeader().add(header);
        envelope.setBody(body);

        String envelopeXml = XmlUtil.beanToXmlByJAXB(envelope);
        ForestResponse<String> response = sabreWebSvcApi.requestWebSvc(BusinessType.CHANGE_SEGMENT_STATUS, "", envelopeXml);
        SoapEnvelope soapEnvelope = XmlUtil.xmlToBeanByJAXB(response.getResult(), SoapEnvelope.class);
        UpdateReservationRS updateReservationRS = Optional.ofNullable(soapEnvelope)
                .map(SoapEnvelope::getBody)
                .map(SoapBody::getUpdateReservationRS)
                .orElse(null);
        System.out.println("[UpdateReservationRS] >>> " + JacksonUtil.toJsonString(updateReservationRS));

        String updateTokenNew = Optional.ofNullable(updateReservationRS)
                .map(UpdateReservationRS::getReservation)
                .map(ReservationPNRB::getBookingDetails)
                .map(BookingDetailsPNRB::getUpdateToken)
                .orElse(null);
        System.out.println("[UpdateTokenNew] >>> " + updateTokenNew);
    }

    @Test
    public void sabre_pnr_delete_segment() {
        String webSvcSession = sabreService.getWebSvcSession();
        Header header = SabreBuilder.buildHeader(webSvcSession, WebSvcAction.UpdateReservationRQ);

        String updateToken = "aleAjlHN0m3swcn+xOqJbWPI2bvUtu25mRFMvGHRnzNYC3RL+hTdHQ==";
        List<String> segmentIds = Lists.newArrayList("13");
        UpdateReservationRQ updateReservationRQ = SabreBuilder.buildUpdateReservationRQForDeleteSegment(updateToken, segmentIds);

        ObjectFactory objectFactory = new ObjectFactory();
        Body body = objectFactory.createBody();
        body.setUpdateReservationRQ(updateReservationRQ);

        Envelope envelope = objectFactory.createEnvelope();
        envelope.getHeader().add(header);
        envelope.setBody(body);

        String envelopeXml = XmlUtil.beanToXmlByJAXB(envelope);
        ForestResponse<String> response = sabreWebSvcApi.requestWebSvc(BusinessType.DELETE_SEGMENT, "", envelopeXml);
        SoapEnvelope soapEnvelope = XmlUtil.xmlToBeanByJAXB(response.getResult(), SoapEnvelope.class);
        UpdateReservationRS updateReservationRS = Optional.ofNullable(soapEnvelope)
                .map(SoapEnvelope::getBody)
                .map(SoapBody::getUpdateReservationRS)
                .orElse(null);
        System.out.println("[UpdateReservationRS] >>> " + JacksonUtil.toJsonString(updateReservationRS));

        String updateTokenNew = Optional.ofNullable(updateReservationRS)
                .map(UpdateReservationRS::getReservation)
                .map(ReservationPNRB::getBookingDetails)
                .map(BookingDetailsPNRB::getUpdateToken)
                .orElse(null);
        System.out.println("[UpdateTokenNew] >>> " + updateTokenNew);
    }

    @Test
    public void ibe_pnr_change_segment_status() {
        OrganizeSegmentDto organizeSegmentDto = OrganizeSegmentDto.builder()
                .pnr("ZSW4Y5")
                .orderNo("251222193429eb95028")
                .build();
        OrganizeSegmentStatusRsp<OTAAirBookRS> organizeSegmentStatusRsp = ibeService.organizeSegmentStatus(organizeSegmentDto);
        System.out.println(JacksonUtil.toJsonString(organizeSegmentStatusRsp));
    }

    @Test
    public void search_low_price() {
        String content = StrUtil.readFile("/Users/huqiquan/Desktop/1S-search-price.json");
        SearchPriceReq searchPriceReq = JacksonUtil.toBean(content, SearchPriceReq.class);
        SearchPriceRsp<Object> searchPriceRsp = airService.searchLowPrice(searchPriceReq);
        System.out.println(JacksonUtil.toJsonString(searchPriceRsp));
    }

    @Test
    public void issued_pnr_galileo() {
        String content = FileUtil.readString("/Users/huqiquan/Desktop/出票结果.xml", StandardCharsets.UTF_8);
        if (StringUtils.isBlank(content)) throw new RuntimeException("文件内容为空");
        AirTicketingRspSoap airTicketingRspSoap = XmlUtil.xmlToBeanByJAXB(content, AirTicketingRspSoap.class);
        SearchPriceRsp<Object> searchPriceRsp = GalileoServiceImpl.getSearchPriceRsp(airTicketingRspSoap.getBody().getAirTicketingRsp());
        System.out.println(JacksonUtil.toJsonString(AjaxResult.success(searchPriceRsp)));
    }

    @Test
    public void sabre_soap_PO_PNRPricingRQ() {
        WebSvcAction action = WebSvcAction.PO_PNRPricingRQ;

        String webSvcSession = sabreService.getWebSvcSession();

        Header header = SabreBuilder.buildHeader(webSvcSession, action);

        PNRPricingRQ.PriceRequestInformation priceRequestInformation = buildPriceRequestInformation(Lists.newArrayList(PassengerType.ADT));

        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.DepartureAirport departureAirport1 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.DepartureAirport();
        departureAirport1.setLocationCode("NRT");
        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.ArrivalAirport arrivalAirport1 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.ArrivalAirport();
        arrivalAirport1.setLocationCode("FOC");
        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.MarketingAirline marketingAirline1 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.MarketingAirline();
        marketingAirline1.setCode("MF");
        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.OperatingAirline operatingAirline1 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.OperatingAirline();
        operatingAirline1.setCode("MF");

        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment flightSegment1 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment();
        flightSegment1.setSegmentNumber(Short.parseShort("1"));
        flightSegment1.setSegmentType("A");
        flightSegment1.setDepartureDate("2026-03-29T15:30:00");
        flightSegment1.setArrivalDate("2026-03-29T18:30:00");
        flightSegment1.setFlightNumber(Short.parseShort("810"));
        flightSegment1.setRealReservationStatus("SS");
        flightSegment1.setResBookDesigCode("P");
        flightSegment1.setReservationStatus("OK");
        flightSegment1.setDepartureAirport(departureAirport1);
        flightSegment1.setArrivalAirport(arrivalAirport1);
        flightSegment1.setMarketingAirline(marketingAirline1);
        flightSegment1.setOperatingAirline(operatingAirline1);

        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.SegmentInformation segmentInformation1 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.SegmentInformation();
        segmentInformation1.setSegmentNumber(Short.parseShort("1"));



        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.DepartureAirport departureAirport2 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.DepartureAirport();
        departureAirport2.setLocationCode("NRT");
        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.ArrivalAirport arrivalAirport2 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.ArrivalAirport();
        arrivalAirport2.setLocationCode("FOC");
        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.MarketingAirline marketingAirline2 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.MarketingAirline();
        marketingAirline2.setCode("MF");
        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.OperatingAirline operatingAirline2 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment.OperatingAirline();
        operatingAirline2.setCode("MF");

        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment flightSegment2 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.FlightSegment();
        flightSegment2.setSegmentNumber(Short.parseShort("2"));
        flightSegment2.setSegmentType("A");
        flightSegment2.setDepartureDate("2026-04-26T13:40:00");
        flightSegment2.setArrivalDate("2026-04-26T09:10:00");
        flightSegment2.setFlightNumber(Short.parseShort("809"));
        flightSegment2.setRealReservationStatus("SS");
        flightSegment2.setResBookDesigCode("R");
        flightSegment2.setReservationStatus("OK");
        flightSegment2.setDepartureAirport(departureAirport2);
        flightSegment2.setArrivalAirport(arrivalAirport2);
        flightSegment2.setMarketingAirline(marketingAirline2);
        flightSegment2.setOperatingAirline(operatingAirline2);

        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.SegmentInformation segmentInformation2 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption.SegmentInformation();
        segmentInformation2.setSegmentNumber(Short.parseShort("2"));

        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption originDestinationOption1 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption();
        originDestinationOption1.setSegmentInformation(segmentInformation1);
        originDestinationOption1.setFlightSegment(flightSegment1);

        PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption originDestinationOption2 = new PNRPricingRQ.AirItinerary.OriginDestinationOptions.OriginDestinationOption();
        originDestinationOption2.setSegmentInformation(segmentInformation2);
        originDestinationOption2.setFlightSegment(flightSegment2);

        PNRPricingRQ.AirItinerary.OriginDestinationOptions originDestinationOptions = new PNRPricingRQ.AirItinerary.OriginDestinationOptions();
        originDestinationOptions.getOriginDestinationOption().add(originDestinationOption1);
        originDestinationOptions.getOriginDestinationOption().add(originDestinationOption2);

        PNRPricingRQ.AirItinerary airItinerary = new PNRPricingRQ.AirItinerary();
        airItinerary.setOriginDestinationOptions(originDestinationOptions);

        PNRPricingRQ pnrPricingRQ = new PNRPricingRQ();
        pnrPricingRQ.setVersion(action.getVersion());
        pnrPricingRQ.setPriceRequestInformation(priceRequestInformation);
        pnrPricingRQ.setAirItinerary(airItinerary);

        QName qName = new QName("", "xmlns");
        pnrPricingRQ.getOtherAttributes().put(qName, "http://webservices.sabre.com/sabreXML/2003/07");

        ObjectFactory objectFactory = new ObjectFactory();
        Body body = objectFactory.createBody();
        body.setPnrPricingRQ(pnrPricingRQ);

        Envelope envelope = objectFactory.createEnvelope();
        envelope.getHeader().add(header);
        envelope.setBody(body);

        String envelopeXml = XmlUtil.beanToXmlByJAXB(envelope);
        System.out.println("=====> " + envelopeXml);

        ForestResponse<String> response = sabreWebSvcApi.requestWebSvc(null, null, envelopeXml);
        SoapEnvelope resultEnvelope = XmlUtil.xmlToBeanByJAXB(response.getResult(), SoapEnvelope.class);
        System.out.println(Optional.ofNullable(response).map(ForestResponse::getResult).orElse(null));
    }

    private static PNRPricingRQ.PriceRequestInformation buildPriceRequestInformation(List<PassengerType> passengerTypeList) {
        List<PNRPricingRQ.PriceRequestInformation.PassengerTypes.PassengerType> sabrePassengerTypes = passengerTypeList.stream().collect(Collectors.groupingBy(PassengerType::getCode))
                .entrySet().stream().map(entry -> {
                    PNRPricingRQ.PriceRequestInformation.PassengerTypes.PassengerType passengerType = new PNRPricingRQ.PriceRequestInformation.PassengerTypes.PassengerType();
                    passengerType.setCode(entry.getKey());
                    passengerType.setCount(Short.parseShort(String.valueOf(entry.getValue().size())));
                    return passengerType;
                }).collect(Collectors.toList());

        PNRPricingRQ.PriceRequestInformation.PassengerTypes passengerTypes = new PNRPricingRQ.PriceRequestInformation.PassengerTypes();
        passengerTypes.getPassengerType().addAll(sabrePassengerTypes);

        PNRPricingRQ.PriceRequestInformation.ApplyOBFees applyOBFees = new PNRPricingRQ.PriceRequestInformation.ApplyOBFees();
        applyOBFees.setInd(true);

        PNRPricingRQ.PriceRequestInformation.ApplyOCFees applyOCFees = new PNRPricingRQ.PriceRequestInformation.ApplyOCFees();
        applyOCFees.setInd(true);

        PNRPricingRQ.PriceRequestInformation.ReturnAllData returnAllData = new PNRPricingRQ.PriceRequestInformation.ReturnAllData();
        returnAllData.setValue("1");

        PNRPricingRQ.PriceRequestInformation.EticketableFare eticketableFare = new PNRPricingRQ.PriceRequestInformation.EticketableFare();
        eticketableFare.setInd(true);

        PNRPricingRQ.PriceRequestInformation.FreeBaggageSubscriber freeBaggageSubscriber = new PNRPricingRQ.PriceRequestInformation.FreeBaggageSubscriber();
        freeBaggageSubscriber.setInd(true);

        PNRPricingRQ.PriceRequestInformation priceRequestInformation = new PNRPricingRQ.PriceRequestInformation();
        priceRequestInformation.setCurrencyCode(CurrencyType.JPY.name());
        priceRequestInformation.setPassengerTypes(passengerTypes);
        priceRequestInformation.setApplyOBFees(applyOBFees);
        priceRequestInformation.setApplyOCFees(applyOCFees);
        priceRequestInformation.setReturnAllData(returnAllData);
        priceRequestInformation.setEticketableFare(eticketableFare);
        priceRequestInformation.setFreeBaggageSubscriber(freeBaggageSubscriber);

        return priceRequestInformation;
    }

    @Test
    public void sabre_soap_OTA_AirAvailLLS() {
        String webSvcSession = sabreService.getWebSvcSession();

        Header header = SabreBuilder.buildHeader(webSvcSession, WebSvcAction.OTA_AirAvailLLSRQ);

        OTAAirAvailRQ.OriginDestinationInformation.FlightSegment.OriginLocation originLocation = new OTAAirAvailRQ.OriginDestinationInformation.FlightSegment.OriginLocation();
        originLocation.setLocationCode("KIX");

        OTAAirAvailRQ.OriginDestinationInformation.FlightSegment.DestinationLocation destinationLocation = new OTAAirAvailRQ.OriginDestinationInformation.FlightSegment.DestinationLocation();
        destinationLocation.setLocationCode("PVG");

        OTAAirAvailRQ.OriginDestinationInformation.FlightSegment flightSegment = new OTAAirAvailRQ.OriginDestinationInformation.FlightSegment();
        flightSegment.setOriginLocation(originLocation);
        flightSegment.setDestinationLocation(destinationLocation);
        flightSegment.setDepartureDateTime("2026-03-20");
//        flightSegment.setFlightNumber("HO1338");

        OTAAirAvailRQ.OriginDestinationInformation originDestinationInformation = new OTAAirAvailRQ.OriginDestinationInformation();
        originDestinationInformation.setFlightSegment(flightSegment);

        OTAAirAvailRQ otaAirAvailRQ = new OTAAirAvailRQ();
        otaAirAvailRQ.setVersion(WebSvcAction.OTA_AirAvailLLSRQ.getVersion());
        otaAirAvailRQ.setReturnHostCommand(true);
        otaAirAvailRQ.setOriginDestinationInformation(originDestinationInformation);

        QName qName = new QName("", "xmlns");
        otaAirAvailRQ.getOtherAttributes().put(qName, "http://webservices.sabre.com/sabreXML/2011/10");

        ObjectFactory objectFactory = new ObjectFactory();
        Body body = objectFactory.createBody();
        body.setOtaAirAvailRQ(otaAirAvailRQ);

        Envelope envelope = objectFactory.createEnvelope();
        envelope.getHeader().add(header);
        envelope.setBody(body);

        String envelopeXml = XmlUtil.beanToXmlByJAXB(envelope);
        System.out.println("=====> " + envelopeXml);

        ForestResponse<String> response = sabreWebSvcApi.requestWebSvc(null, null, envelopeXml);
        System.out.println(Optional.ofNullable(response).map(ForestResponse::getResult).orElse(null));

        SoapEnvelope resultEnvelope = XmlUtil.xmlToBeanByJAXB(response.getResult(), SoapEnvelope.class);
        List<OTAAirAvailRS.OriginDestinationOptions.OriginDestinationOption> originDestinationOptions = Optional.ofNullable(resultEnvelope)
                .map(SoapEnvelope::getBody)
                .map(SoapBody::getOtaAirAvailRS)
                .map(OTAAirAvailRS::getOriginDestinationOptions)
                .map(OTAAirAvailRS.OriginDestinationOptions::getOriginDestinationOption)
                .orElse(Lists.newArrayList());

        List<FlightNumberCabinVo> flightNumberCabinVos = originDestinationOptions.stream().map(originDestinationOption -> {
                    List<OTAAirAvailRS.OriginDestinationOptions.OriginDestinationOption.FlightSegment> flightSegmentList = originDestinationOption.getFlightSegment();
                    if (CollectionUtil.isEmpty(flightSegmentList)) return Lists.<FlightNumberCabinVo>newArrayList();

                    return flightSegmentList.stream().map(segment -> {
                                List<OTAAirAvailRS.OriginDestinationOptions.OriginDestinationOption.FlightSegment.BookingClassAvail> bookingClassAvails = segment.getBookingClassAvail();
                                if (CollectionUtil.isEmpty(bookingClassAvails)) return null;

                                List<CabinQuantityVo> cabinQuantityVos = segment.getBookingClassAvail().stream()
                                        .map(bookingClassAvail -> CabinQuantityVo.builder()
                                                .cabin(bookingClassAvail.getResBookDesigCode())
                                                .quantity(parseCabinQuanity(bookingClassAvail.getAvailability()))
                                                .build())
                                        .collect(Collectors.<CabinQuantityVo>toList());

                                String flightNumber = Optional.ofNullable(segment.getMarketingAirline()).map(marketingAirline -> marketingAirline.getCode() + marketingAirline.getFlightNumber()).orElse("");
                                return FlightNumberCabinVo.builder().flightNumber(flightNumber).cabins(cabinQuantityVos).build();
                            })
                            .filter(Objects::nonNull)
                            .collect(Collectors.<FlightNumberCabinVo>toList());
                })
                .filter(CollectionUtil::isNotEmpty)
                .collect(ArrayList::new, List::addAll, List::addAll);
        System.out.println(JacksonUtil.toJsonString(flightNumberCabinVos));
    }

    private Integer parseCabinQuanity(String cabinQuanity) {
        try {
            return Integer.parseInt(cabinQuanity);
        } catch (Exception e) {
            return 0;
        }
    }

    @Test
    public void sabre_soap_FareLLSRQ() {
        String webSvcSession = sabreService.getWebSvcSession();

        Header header = SabreBuilder.buildHeader(webSvcSession, WebSvcAction.FareLLSRQ);

        FareRQ.OptionalQualifiers.TimeQualifiers.TravelDateOptions travelDateOptions = new FareRQ.OptionalQualifiers.TimeQualifiers.TravelDateOptions();
        travelDateOptions.setStart("12-21");

        FareRQ.OptionalQualifiers.TimeQualifiers timeQualifiers = new FareRQ.OptionalQualifiers.TimeQualifiers();
        timeQualifiers.setTravelDateOptions(travelDateOptions);

        FareRQ.OptionalQualifiers optionalQualifiers = new FareRQ.OptionalQualifiers();
        optionalQualifiers.setTimeQualifiers(timeQualifiers);

        FareRQ.OriginDestinationInformation.FlightSegment.OriginLocation originLocation = new FareRQ.OriginDestinationInformation.FlightSegment.OriginLocation();
        originLocation.setLocationCode("NRT");

        FareRQ.OriginDestinationInformation.FlightSegment.DestinationLocation destinationLocation = new FareRQ.OriginDestinationInformation.FlightSegment.DestinationLocation();
        destinationLocation.setLocationCode("PVG");

        FareRQ.OriginDestinationInformation.FlightSegment flightSegment = new FareRQ.OriginDestinationInformation.FlightSegment();
        flightSegment.setOriginLocation(originLocation);
        flightSegment.setDestinationLocation(destinationLocation);

        FareRQ.OriginDestinationInformation originDestinationInformation = new FareRQ.OriginDestinationInformation();
        originDestinationInformation.setFlightSegment(flightSegment);

        FareRQ fareRQ = new FareRQ();
        fareRQ.setVersion(WebSvcAction.FareLLSRQ.getVersion());
        fareRQ.setOptionalQualifiers(optionalQualifiers);
        fareRQ.setOriginDestinationInformation(originDestinationInformation);

        QName qName = new QName("", "xmlns");
        fareRQ.getOtherAttributes().put(qName, "http://webservices.sabre.com/sabreXML/2011/10");

        ObjectFactory objectFactory = new ObjectFactory();
        Body body = objectFactory.createBody();
        body.setFareRQ(fareRQ);

        Envelope envelope = objectFactory.createEnvelope();
        envelope.getHeader().add(header);
        envelope.setBody(body);

        String envelopeXml = XmlUtil.beanToXmlByJAXB(envelope);
        System.out.println("=====> " + envelopeXml);

        ForestResponse<String> response = sabreWebSvcApi.requestWebSvc(null, null, envelopeXml);

        /*String result = Forest.post("https://webservices.platform.sabre.com")
                .addHeader("Content-Type", "text/xml")
                .addBody(envelopeXml)
                .execute(String.class);*/
        System.out.println(Optional.ofNullable(response).map(ForestResponse::getResult).orElse(null));
    }

    @Test
    public void sabre_token_sesison() {
        String restAccessToken = sabreService.getRestAccessToken();
        System.out.println(">>> RestAccessToken: " + restAccessToken);
        String webSvcToken = sabreService.getWebSvcToken();
        System.out.println(">>> WebSvcToken: " + webSvcToken);
        String webSvcSession = sabreService.getWebSvcSession();
        System.out.println(">>> WebSvcSession: " + webSvcSession);
    }

    @Test
    public void sabre_soap_create_token() {
        String result = Forest.post("https://webservices.platform.sabre.com")
                .addHeader("Content-Type", "text/xml")
                .addBody("<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                        "    <SOAP-ENV:Header>\n" +
                        "        <MessageHeader xmlns=\"http://www.ebxml.org/namespaces/messageHeader\">\n" +
                        "            <From>\n" +
                        "                <PartyId>Agency</PartyId>\n" +
                        "            </From>\n" +
                        "            <To>\n" +
                        "                <PartyId>Sabre_API</PartyId>\n" +
                        "            </To>\n" +
                        "            <ConversationId>2021.01.DevStudio</ConversationId>\n" +
                        "            <Action>TokenCreateRQ</Action>\n" +
                        "        </MessageHeader>\n" +
                        "        <Security xmlns=\"http://schemas.xmlsoap.org/ws/2002/12/secext\">\n" +
                        "            <UsernameToken>\n" +
                        "                <Username>740238</Username>\n" +
                        "                <Password>1F122090</Password>\n" +
                        "                <Organization>L0AL</Organization>\n" +
                        "                <Domain>DEFAULT</Domain>\n" +
                        "            </UsernameToken>\n" +
                        "        </Security>\n" +
                        "    </SOAP-ENV:Header>\n" +
                        "    <SOAP-ENV:Body>\n" +
                        "        <TokenCreateRQ Version=\"1.0.0\" xmlns=\"http://webservices.sabre.com\"/>\n" +
                        "    </SOAP-ENV:Body>\n" +
                        "</SOAP-ENV:Envelope>")
                .execute(String.class);
        System.out.println(result);
    }

    @Test
    public void sabre_soap_create_session() {
        String body = "<SOAP-ENV:Envelope xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\">\n" +
                "    <SOAP-ENV:Header>\n" +
                "        <MessageHeader xmlns=\"http://www.ebxml.org/namespaces/messageHeader\">\n" +
                "            <From>\n" +
                "                <PartyId>Agency</PartyId>\n" +
                "            </From>\n" +
                "            <To>\n" +
                "                <PartyId>Sabre_API</PartyId>\n" +
                "            </To>\n" +
                "            <ConversationId>2021.01.DevStudio</ConversationId>\n" +
                "            <Action>SessionCreateRQ</Action>\n" +
                "        </MessageHeader>\n" +
                "        <Security xmlns=\"http://schemas.xmlsoap.org/ws/2002/12/secext\">\n" +
                "            <UsernameToken>\n" +
                "                <Username>740238</Username>\n" +
                "                <Password>1F122090</Password>\n" +
                "                <Organization>L0AL</Organization>\n" +
                "                <Domain>DEFAULT</Domain>\n" +
                "            </UsernameToken>\n" +
                "        </Security>\n" +
                "    </SOAP-ENV:Header>\n" +
                "    <SOAP-ENV:Body>\n" +
                "        <SessionCreateRQ returnContextID=\"true\" Version=\"1.0.0\" xmlns=\"http://www.opentravel.org/OTA/2002/11\"/>\n" +
                "    </SOAP-ENV:Body>\n" +
                "</SOAP-ENV:Envelope>";

        String result = Forest.post("https://webservices.platform.sabre.com")
                .addHeader("Content-Type", "text/xml")
                .addBody(body)
                .execute(String.class);
        System.out.println(result);
    }

    @Test
    public void sabre_soap_create_token_code() {
        ObjectFactory objectFactory = new ObjectFactory();

        PartyId fromPartyId = new PartyId();
        fromPartyId.setValue(SabrePartyIdType.Agency.name());

        From from = new From();
        from.getPartyId().add(fromPartyId);

        PartyId toPartyId = new PartyId();
        toPartyId.setValue(SabrePartyIdType.Sabre_API.name());

        To to = new To();
        to.getPartyId().add(toPartyId);

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setCPAId(gdsConfig.getSabre().getPcc());
        messageHeader.setConversationId(SabreConstant.CONVERSATION_ID);
        messageHeader.setAction(WebSvcAction.TokenCreateRQ.getAction());
        messageHeader.setFrom(from);
        messageHeader.setTo(to);

        Security.UsernameToken usernameToken = new Security.UsernameToken();
        usernameToken.setUsername(gdsConfig.getSabre().getUsername());
        usernameToken.setPassword(gdsConfig.getSabre().getPassword());
        usernameToken.setOrganization(gdsConfig.getSabre().getPcc());
        usernameToken.setDomain("DEFAULT");

        Security security = new Security();
        security.setUsernameToken(usernameToken);

        Header header = objectFactory.createHeader();
        header.setMessageHeader(messageHeader);
        header.setSecurity(security);

        TokenCreateRQ tokenCreateRQ = new TokenCreateRQ();
        tokenCreateRQ.setVersion("1.0.0");

        QName qName = new QName("", "xmlns");
        tokenCreateRQ.getOtherAttributes().put(qName, "http://webservices.sabre.com");

        Body body = objectFactory.createBody();
        body.setTokenCreateRQ(tokenCreateRQ);

        Envelope envelope = objectFactory.createEnvelope();
        envelope.getHeader().add(header);
        envelope.setBody(body);

        String bodyStr = XmlUtil.beanToXmlByJAXB(envelope);
        String result = Forest.post("https://webservices.platform.sabre.com")
                .addHeader("Content-Type", "text/xml")
                .addBody(bodyStr)
                .execute(String.class);

        System.out.println();
        System.out.println(result);

        SoapEnvelope resultEnvelope = XmlUtil.xmlToBeanByJAXB(result, SoapEnvelope.class);
        Optional.ofNullable(resultEnvelope)
                .map(SoapEnvelope::getHeader)
                .map(SoapHeader::getSecurity)
                .map(com.ruoyi.gds.schema.sabre.rsp.Security::getBinarySecurityToken)
                .map(BinarySecurityToken::getValue)
                .ifPresent(session -> System.out.println("Session >>>" + session));
    }

    @Test
    public void sabre_soap_create_session_code() {
        ObjectFactory objectFactory = new ObjectFactory();

        PartyId fromPartyId = new PartyId();
        fromPartyId.setValue(SabrePartyIdType.Agency.name());

        From from = new From();
        from.getPartyId().add(fromPartyId);

        PartyId toPartyId = new PartyId();
        toPartyId.setValue(SabrePartyIdType.Sabre_API.name());

        To to = new To();
        to.getPartyId().add(toPartyId);

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setCPAId(gdsConfig.getSabre().getPcc());
        messageHeader.setConversationId(SabreConstant.CONVERSATION_ID);
        messageHeader.setAction(WebSvcAction.SessionCreateRQ.getAction());
        messageHeader.setFrom(from);
        messageHeader.setTo(to);

        Security.UsernameToken usernameToken = new Security.UsernameToken();
        usernameToken.setUsername(gdsConfig.getSabre().getUsername());
        usernameToken.setPassword(gdsConfig.getSabre().getPassword());
        usernameToken.setOrganization(gdsConfig.getSabre().getPcc());
        usernameToken.setDomain("DEFAULT");

        Security security = new Security();
        security.setUsernameToken(usernameToken);

        Header header = objectFactory.createHeader();
        header.setMessageHeader(messageHeader);
        header.setSecurity(security);

        SessionCreateRQ sessionCreateRQ = new SessionCreateRQ();
        sessionCreateRQ.setReturnContextID(true);
        sessionCreateRQ.setVersion("1.0.0");

        QName qName = new QName("", "xmlns");
        sessionCreateRQ.getOtherAttributes().put(qName, "http://www.opentravel.org/OTA/2002/11");

        Body body = objectFactory.createBody();
        body.setSessionCreateRQ(sessionCreateRQ);

        Envelope envelope = objectFactory.createEnvelope();
        envelope.getHeader().add(header);
        envelope.setBody(body);

        String bodyStr = XmlUtil.beanToXmlByJAXB(envelope);
        String result = Forest.post("https://webservices.platform.sabre.com")
                .addHeader("Content-Type", "text/xml")
                .addBody(bodyStr)
                .execute(String.class);

        System.out.println();
        System.out.println(result);

        SoapEnvelope resultEnvelope = XmlUtil.xmlToBeanByJAXB(result, SoapEnvelope.class);
        Optional.ofNullable(resultEnvelope)
                .map(SoapEnvelope::getHeader)
                .map(SoapHeader::getSecurity)
                .map(com.ruoyi.gds.schema.sabre.rsp.Security::getBinarySecurityToken)
                .map(BinarySecurityToken::getValue)
                .ifPresent(session -> System.out.println("Session >>>" + session));
    }

    @Test
    public void test() throws InterruptedException {
        List<String> urls = Lists.newArrayList("/develop/xml/AirFareSearchOne/I", "/develop/xml/AirFarePrice/I", "/develop/xml/AirFareBestBuy/I");
        Random random = new Random();
        for (int i = 0; i < 100; i++) {
            taskExecutor.execute(() -> {
                String url = urls.get(random.nextInt(urls.size()));
                String result = sendRequestWithLock(url);
                System.out.println(url + " >>> " + result);
            });
        }

        Thread.sleep(10000 * 1000L);
    }

    @Test
    public void refreshSolutionFare() {
        flightSolutionService.refreshSolutionFare();
    }

//    @Test
//    public void removeGdsLog() {
//        pnrTask.removeGdsLog();
//    }

    @Test
    public void fcz_air_change_custom_check_exists() {
        AirchangeVo airchangeVo = AirchangeVo.builder()
                .origin("TFU")
                .destination("NRT")
                .depDateTime(LocalDateTime.of(2026, 3, 11, 12,30,0))
                .carrier("3U")
                .flightNumber(3961)
                .build();
        LambdaQueryWrapper<FczAirchangeCustom> queryWrapper = Wrappers.lambdaQuery(FczAirchangeCustom.class)
                .eq(FczAirchangeCustom::getOrigin, airchangeVo.getOrigin())
                .eq(FczAirchangeCustom::getDestination, airchangeVo.getDestination())
                .eq(FczAirchangeCustom::getDepDate, airchangeVo.getDepDateTime().toLocalDate())
                .eq(FczAirchangeCustom::getCarrier, airchangeVo.getCarrier())
                .eq(FczAirchangeCustom::getFlightNumber, airchangeVo.getFlightNumber())
                .eq(FczAirchangeCustom::getStatus, FczAirchangeCustomErrorCode.SUCCESS.getErrorCode())
                .eq(FczAirchangeCustom::isDelFlag, false);
        long count = fczAirchangeCustomService.count(queryWrapper);
        System.out.println(count);
    }

    @Test
    public void fcz_air_change_custom() throws IOException {
        String path = "/Users/huqiquan/Desktop/airchange.json";
        String content = new String(Files.readAllBytes(Paths.get(path)));

        AirchangeVo airchangeVo = JacksonUtil.toBean(content, AirchangeVo.class);
        FczAirchangeCustom fczAirchangeCustom = fczAirchangeCustomService.mqMsgHandle(airchangeVo);
        System.out.println(JacksonUtil.toJsonString(fczAirchangeCustom));
    }

    /**
     * 飞常准—航班动态（日期 + 航班号）
     */
    @Test
    public void fcz_air_change_method1() {
//        queryAirchangeFczNew("2025-12-17", "CZ346");
//        queryAirchangeFczNew("2025-12-18", "CZ8811");
//        queryAirchangeFczNew("2025-12-24", "9C6330");
//        queryAirchangeFczNew("2026-01-05", "9C6329");
        queryAirchangeFczNew("2026-01-03", "GS7989");

        // result
        // [{"fcategory":"1","org_timezone":"28800","dst_timezone":"32400","FlightNo":"SC8085","FlightCompany":"山东航空股份有限公司","FlightDepcode":"TNA","FlightArrcode":"KIX","FlightDeptimePlanDate":"2026-03-01 11:25:00","FlightArrtimePlanDate":"2026-03-01 15:10:00","FlightDeptimeReadyDate":"","FlightArrtimeReadyDate":"","FlightDeptimeDate":"","FlightArrtimeDate":"","CheckinTable":"E22-E24","BoardGate":"","BaggageID":"","FlightState":"计划","FlightHTerminal":"","FlightTerminal":"T1","ShareFlightNo":"","StopFlag":"","ShareFlag":"","FlightDep":"济南","FlightArr":"大阪","FlightDepAirport":"济南遥墙","FlightArrAirport":"关西"}]
    }

    private void queryAirchangeFczNew(String date, String fnum) {
        TreeMap<String, String> treeMap = new TreeMap<>();
        treeMap.put("appid", fczAppid);
        treeMap.put("date", date);
        treeMap.put("fnum", fnum);
        String param = treeMap.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue()).collect(Collectors.joining("&")) + fczAppSecurity;
        String md5Param = DigestUtil.md5Hex(DigestUtil.md5Hex(param));
        System.out.println("[encrypt] before: " + param + ", after: " + md5Param);

        Object result = fczApi.airchangeQuery(fczAppid, date, fnum, md5Param);
        if (result instanceof HashMap) {
            System.out.println(">>>Map: " + JacksonUtil.toJsonString(result));
        } else if (result instanceof ArrayList) {
            System.out.println(">>>List: " + JacksonUtil.toJsonString(result));
        }
    }

    /**
     * 飞常准—航班动态（日期 + 出发机场三字码 + 到达机场三字码）
     */
    @Test
    public void fcz_air_change_method2() {
        String appid = "11770";
        String appSecurity  = "67ab2a53ca319";

        TreeMap<String, String> treeMap = new TreeMap<>();
        treeMap.put("appid", appid);
        treeMap.put("date", "2026-03-01");
        treeMap.put("dep", "TNA");  // 出发机场三字码
        treeMap.put("arr", "KIX");  // 到达机场三字码

        String param = treeMap.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue()).collect(Collectors.joining("&")) + appSecurity;
        String md5Param = DigestUtil.md5Hex(DigestUtil.md5Hex(param));
        System.out.println("[encrypt] before: " + param + ", after: " + md5Param);

        ForestQueryMap forestQueryMap = new ForestQueryMap();
        forestQueryMap.putAll(treeMap);
        forestQueryMap.put("token", md5Param);

        Object result = Forest.get("https://open-al.variflight.com/api/flight")
                .addAllQuery(forestQueryMap)
                .execute(Object.class);
        if (result instanceof HashMap) {
            System.out.println(">>>Map: " + JacksonUtil.toJsonString(result));
        } else if (result instanceof ArrayList) {
            System.out.println(">>>List: " + JacksonUtil.toJsonString(result));
        }

        // result
        // [{"fcategory": "1","org_timezone": "28800","dst_timezone": "32400","FlightNo": "SC8085","FlightCompany": "山东航空股份有限公司","FlightDepcode": "TNA","FlightArrcode": "KIX","FlightDeptimePlanDate": "2026-03-01 11:25:00","FlightArrtimePlanDate": "2026-03-01 15:10:00","FlightDeptimeReadyDate": "","FlightArrtimeReadyDate": "","FlightDeptimeDate": "","FlightArrtimeDate": "","CheckinTable": "E22-E24","BoardGate": "","BaggageID": "","FlightState": "计划","FlightHTerminal": "","FlightTerminal": "T1","ShareFlightNo": "","StopFlag": "","ShareFlag": "","FlightDep": "济南","FlightArr": "大阪","FlightDepAirport": "济南遥墙","FlightArrAirport": "关西"},{"fcategory": "1","org_timezone": "28800","dst_timezone": "32400","FlightNo": "NH6570","FlightCompany": "全日本航空公司","FlightDepcode": "TNA","FlightArrcode": "KIX","FlightDeptimePlanDate": "2026-03-01 11:25:00","FlightArrtimePlanDate": "2026-03-01 15:10:00","FlightDeptimeReadyDate": "","FlightArrtimeReadyDate": "","FlightDeptimeDate": "","FlightArrtimeDate": "","CheckinTable": "E22-E24","BoardGate": "","BaggageID": "","FlightState": "计划","FlightHTerminal": "","FlightTerminal": "T1","ShareFlightNo": "SC8085","StopFlag": "","ShareFlag": "","FlightDep": "济南","FlightArr": "大阪","FlightDepAirport": "济南遥墙","FlightArrAirport": "关西"},{"fcategory": "1","org_timezone": "28800","dst_timezone": "32400","FlightNo": "CA8883","FlightCompany": "中国国际航空股份有限公司","FlightDepcode": "TNA","FlightArrcode": "KIX","FlightDeptimePlanDate": "2026-03-01 11:25:00","FlightArrtimePlanDate": "2026-03-01 15:10:00","FlightDeptimeReadyDate": "","FlightArrtimeReadyDate": "","FlightDeptimeDate": "","FlightArrtimeDate": "","CheckinTable": "E22-E24","BoardGate": "","BaggageID": "","FlightState": "计划","FlightHTerminal": "","FlightTerminal": "T1","ShareFlightNo": "SC8085","StopFlag": "","ShareFlag": "","FlightDep": "济南","FlightArr": "大阪","FlightDepAirport": "济南遥墙","FlightArrAirport": "关西"},{"fcategory": "1","org_timezone": "28800","dst_timezone": "32400","FlightNo": "SC8087","FlightCompany": "山东航空股份有限公司","FlightDepcode": "TNA","FlightArrcode": "KIX","FlightDeptimePlanDate": "2026-03-01 17:00:00","FlightArrtimePlanDate": "2026-03-01 20:45:00","FlightDeptimeReadyDate": "","FlightArrtimeReadyDate": "","FlightDeptimeDate": "","FlightArrtimeDate": "","CheckinTable": "E22-E24","BoardGate": "","BaggageID": "","FlightState": "计划","FlightHTerminal": "","FlightTerminal": "T1","ShareFlightNo": "","StopFlag": "","ShareFlag": "","FlightDep": "济南","FlightArr": "大阪","FlightDepAirport": "济南遥墙","FlightArrAirport": "关西"},{"fcategory": "1","org_timezone": "28800","dst_timezone": "32400","FlightNo": "NH6574","FlightCompany": "全日本航空公司","FlightDepcode": "TNA","FlightArrcode": "KIX","FlightDeptimePlanDate": "2026-03-01 17:00:00","FlightArrtimePlanDate": "2026-03-01 20:45:00","FlightDeptimeReadyDate": "","FlightArrtimeReadyDate": "","FlightDeptimeDate": "","FlightArrtimeDate": "","CheckinTable": "E22-E24","BoardGate": "","BaggageID": "","FlightState": "计划","FlightHTerminal": "","FlightTerminal": "T1","ShareFlightNo": "SC8087","StopFlag": "","ShareFlag": "","FlightDep": "济南","FlightArr": "大阪","FlightDepAirport": "济南遥墙","FlightArrAirport": "关西"},{"fcategory": "1","org_timezone": "28800","dst_timezone": "32400","FlightNo": "CA8889","FlightCompany": "中国国际航空股份有限公司","FlightDepcode": "TNA","FlightArrcode": "KIX","FlightDeptimePlanDate": "2026-03-01 17:00:00","FlightArrtimePlanDate": "2026-03-01 20:45:00","FlightDeptimeReadyDate": "","FlightArrtimeReadyDate": "","FlightDeptimeDate": "","FlightArrtimeDate": "","CheckinTable": "E22-E24","BoardGate": "","BaggageID": "","FlightState": "计划","FlightHTerminal": "","FlightTerminal": "T1","ShareFlightNo": "SC8087","StopFlag": "","ShareFlag": "","FlightDep": "济南","FlightArr": "大阪","FlightDepAirport": "济南遥墙","FlightArrAirport": "关西"}]
    }

    /**
     * 飞常准—航班动态（日期 + 出发城市三字码 + 到达城市三字码）
     */
    @Test
    public void fcz_air_change_method3() {
        String appid = "11770";
        String appSecurity  = "67ab2a53ca319";

        TreeMap<String, String> treeMap = new TreeMap<>();
        treeMap.put("appid", appid);
        treeMap.put("date", "2026-03-01");
        treeMap.put("depcity", "TNA");  // 出发城市三字码
        treeMap.put("arrcity", "KIX");  // 到达城市三字码

        String param = treeMap.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue()).collect(Collectors.joining("&")) + appSecurity;
        String md5Param = DigestUtil.md5Hex(DigestUtil.md5Hex(param));
        System.out.println("[encrypt] before: " + param + ", after: " + md5Param);

        ForestQueryMap forestQueryMap = new ForestQueryMap();
        forestQueryMap.putAll(treeMap);
        forestQueryMap.put("token", md5Param);

        Object result = Forest.get("https://open-al.variflight.com/api/flight")
                .addAllQuery(forestQueryMap)
                .execute(Object.class);
        if (result instanceof HashMap) {
            System.out.println(">>>Map: " + JacksonUtil.toJsonString(result));
        } else if (result instanceof ArrayList) {
            System.out.println(">>>List: " + JacksonUtil.toJsonString(result));
        }

        // result
        // {"error_code":10,"error":"暂无数据"}
    }

    /**
     * 飞常准—定制航班动态（日期 + 航班号）
     */
    @Test
    public void fcz_air_change_customize() {
        // send("TYO", "PVG", "2025-12-25", "JL873");
        send("TYO", "PVG", "2025-12-25", "JL873", String.valueOf(idWorker.nextId()));
        // result
        // {"error_code":8,"error":"定制成功","FlightDeptimePlanDate":"2026-03-01 11:25:00","FlightArrtimePlanDate":"2026-03-01 15:10:00"}
    }

    /**
     * 飞常准—定制航班动态（日期 + 航班号）
     */
    @Test
    public void fcz_air_change_customize_batch() {
        String pnrs = "DFK5BF,DHS1MW,DKNB3V,D8XP8W,DDG99J,DJHYD7,D32KD2,DQFPLZ,D7T8Z2,D84Q3M,DS6B18,DKJNM6,DR578L,DMQN6S,D5D9ZV,DJ3CZN,D9B90S,D29BCQ,D7LPL4,DHDPS6,DL01W4,D7H96F,D9DTN0,DGBFWX,DR8JW1,DR8HS8,DCQZC2,D9002D,DKXX8R,DKD15P,DJ4PMK,DRTJP2,DRJCLG,DHH008,D1BW8R,DK7H7T,D8LWMM,DD22GY,DGNT7Q,D5CQCN,D7GK7Z,DDJQLW,DH6R2L,D5F2QF,DKKZVX,D84QNG,D84V7T,DPZF53,DJY74F,D7MB7B,D248MR,D8MCGB,DB5C8Q,DBX0X1,DLD25H,DD2FBR,D5PWTB,D9S5R1,D8D5X2,D1T6TB,D85BVH,DFMR4F,DD3Z00,DDFNCG,DJLQF8,D1FGV3,DKKBMT,DJ6BZL,D4PP3B,DQFFWX,DQF9S5,DH01F1,D304QW,D30G70,DMR2C2,D3B45Z,D8CVZR,DB7HF6,DJ3X3J,D9B0RG,D5C8XF,D7JWCF,DD3JCQ,DQH367,D6FXJV,D5F65N,D84Q3M,DKJNM6,DHDXK2,DJ3CZN,D9B90S,D6QBG6,D9002D,DKD15P,D7H8NP,DQHXNY,DB39L5,DJGWGG,DJWFKD,DG2V6F,D84V7T,D30856,D8MCGB,D248MR,D1BDMY,D8KMK8,D504FG,DQH626,DFY54F,DLBF7T,DDGQCW,DFLHV7,DQCDL8,D7GS1Z,DH01F1,D304QW,DFJZ98,D3B45Z,D49P0Q,D8CVZR,DJL22F,DJK2HV,DH19ZD,D6R36S,DL1X04,DMD9T3,D74DHN,DPSG1N,DJ5Q18,DJGYBH,D6CL65,D8M9SB,DR442B,D9BYLH,DFLXK9,DJGWGG,DCQ9N0,DFYCZR,DFY54F,DB3BDY,D6QBWR,DTM85N,DTM9DR,DKJN3Q,DDG9TS,DFLHV7,D7GKR3,D6R36S,DJ76YR,DJGYBH,D92567,D6CL65,DL0YMX,DKC4H7,DTNFRJ,DNJ6DW,DNJG0Q,DP7KXQ,D8M9SB,DB5L6H,D9RNQB,D6QT1Q,DCCMN2,DDG9TS,DL0YMX,D9DK0H,DKC4H7,DBWRN0,D8CJ1N,DL1W0R,DJ5P5T,D5TVK2,DR4DFN,DTNDCV,DKYQKG,DQR6FT,DMS91X,DB651F,DGQ1GQ,D08C7T,DJ5RB9,DKYQKG,DGP2CH,DD5KNS,DKZYCC,DBQ050,D6QRZF,DKZYCC,DKNDNS,DNW8MW,D6FMH5,D3CHNB,DBW397,D7V56S,DQF1DZ,DN3H4M,DNHNPN,D33DPG,D2QJFH,DL05NR,D0Z7BS,D3CHNB,D7V56S,DKYJ90,D33DPG,DJTV4H,D1F70D,D0Z7BS,DDFMMQ,DH01W7,D03T33,DNH6MN,DNWS45,DKYCHV,D03T33,DR4K1M,D4QTZ4,DS9ZVG,DHHDFZ,DB3D86,D7T7ZF,D7T7MP,DFMS8D,DHHDFZ,DB3D86,DJ4N3D,DB48GH,DCP85N,D7T7MP,D86BJT,D5HW7Y,DBW41F,D42LD1,DB5Z0N,D8LY1Z,D1YQW3";
        List<QueryPnrInfoReq> queryPnrInfoReqs = Arrays.stream(pnrs.split(","))
                .map(pnr -> QueryPnrInfoReq.builder().gds(GDSType.GALELIO).pnr(pnr).build())
                .collect(Collectors.toList());

        for (QueryPnrInfoReq queryPnrInfoReq : queryPnrInfoReqs) {
            QueryPnrRsp<Object> pnrRsp = airService.queryPnr(queryPnrInfoReq);
            for (FlightBookingVo flight : pnrRsp.getFlights()) {
                String date = DateUtil.dateTimeFormat(flight.getDepartureTime(), DatePattern.NORM_DATE_PATTERN);
                if (StringUtils.isBlank(date)) continue;
                send(flight.getOrigin(), flight.getDestination(), date, flight.getCarrier() + flight.getFlightNumber());
            }
        }
    }

    private void send(String dep, String arr, String date, String fnum) {
        String fid = String.valueOf(idWorker.nextId());

        TreeMap<String, String> treeMap = new TreeMap<>();
        treeMap.put("appid", fczAppid);
        treeMap.put("dep", dep);  // 出发机场三字码
        treeMap.put("arr", arr);  // 到达机场三字码
        treeMap.put("date", date);
        treeMap.put("fnum", fnum);
        treeMap.put("fid", fid);  // 用于推送实时数据时，反馈给用户的航班识别字符串，数字或字母组成，不超过20位，可为空，可选

        String param = treeMap.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue()).collect(Collectors.joining("&")) + fczAppSecurity;
        String md5Param = DigestUtil.md5Hex(DigestUtil.md5Hex(param));
        System.out.println("[encrypt] before: " + param + ", after: " + md5Param);

        /*ForestQueryMap forestQueryMap = new ForestQueryMap();
        forestQueryMap.putAll(treeMap);
        forestQueryMap.put("token", md5Param);

        Object result = Forest.get("https://open-al.variflight.com/api/addflightpush")
                .addAllQuery(forestQueryMap)
                .execute(Object.class);
        if (result instanceof HashMap) {
            System.out.println("[Result]>>>Map: " + JacksonUtil.toJsonString(result));
        } else if (result instanceof ArrayList) {
            System.out.println("[Result]>>>List: " + JacksonUtil.toJsonString(result));
        }*/

        FczAirchangeCustomResultVo resultVo = fczApi.airchangeCustom(fczAppid, dep, arr, date, fnum, fid, md5Param);
        System.out.println("[Result]>>>: " + JacksonUtil.toJsonString(resultVo));
    }

    private FczAirchangeCustomResultVo send(String origin, String destination, String depDate, String flightNumber, String businessId) {
        try {
            TreeMap<String, String> treeMap = new TreeMap<>();
            treeMap.put("appid", fczAppid);
            treeMap.put("dep", origin);         // 出发机场三字码
            treeMap.put("arr", destination);    // 到达机场三字码
            treeMap.put("date", depDate);       // 出发日期
            treeMap.put("fnum", flightNumber);  // 航班号
            treeMap.put("fid", businessId);     // 用于推送实时数据时，反馈给用户的航班识别字符串，数字或字母组成，不超过20位，可为空，可选

            String param = treeMap.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue()).collect(Collectors.joining("&")) + fczAppSecurity;
            String md5Param = DigestUtil.md5Hex(DigestUtil.md5Hex(param));
            // System.out.println("[encrypt] before: " + param + ", after: " + md5Param);

            return fczApi.airchangeCustom(fczAppid, origin, destination, depDate, flightNumber, businessId, md5Param);
        } catch (Exception e) {
            log.error("定制飞常准航变—异常.", e);
            return null;
        }
    }

    /**
     * 飞常准机票过境签和行李额对接文档
     */
    @Test
    public void fcz_sign_baggage() {
        String appId = "wuhanwaiguo";
        String appkey = "IUSFxibeJ8z82lLyU8vMdb";
        long timeStamp = LocalDateTime.now().withNano(0).atZone(ZoneOffset.systemDefault()).toEpochSecond();

        String token = DigestUtil.md5Hex(appId + appkey + timeStamp);

//        LinkedList<Map<String, Object>> dataJsons = getDataJson_wangfan_zhifei();
        LinkedList<Map<String, Object>> dataJsons = getDataJson_zhongzhuan_zhifei();

        List<String> keyOrders = Lists.newArrayList("ticket_index", "segment_no", "sequence_no",
                "dep_port_code", "dep_city_code", "dep_datetime", "dep_terminal",
                "arr_port_code", "arr_city_code", "arr_datetime", "arr_terminal",
                "al_code", "flight_no", "act_al_code", "act_flight_no", "stop_info_list");
        List<LinkedHashMap<String, Object>> sortedDataJsons = dataJsons.stream().map(dataJson -> mapSort(dataJson, keyOrders)).collect(Collectors.toList());
        System.out.println(">>>" + JacksonUtil.toJsonString(sortedDataJsons));

        ForestQueryMap forestQueryMap = new ForestQueryMap();
        forestQueryMap.put("appId", appId);
        forestQueryMap.put("timeStamp", timeStamp);
        forestQueryMap.put("action", "search.IntlBaggageVisa");
        forestQueryMap.put("token", token);
        forestQueryMap.put("dataJson", JacksonUtil.toJsonString(dataJsons));

        HashMap result = Forest.get("https://ticket.variflight.com/oapi/open_api/ticketApiJsonV1")
                .addAllQuery(forestQueryMap)
                .execute(HashMap.class);
        System.out.println(">>>" + JacksonUtil.toJsonString(result));

        // result
        // {"baggage": {"1": {"1": true}},"passage": {"1": {"1": {"title": "需过境签","text": "此行程经中国台湾，中国大陆公民需提前办理台湾通行证和入台证（自2019年8月1日起，中国大陆公民暂停办理台湾自由行个人旅游签注），请确认证件无误后再出行。持团队签旅客无法单独购买机票。\n"}}},"inbound": {"1": {"1": {"0": {"title": "预订提醒","text": "持商务、旅游等短期签证的旅客或免签的旅客建议购买返程票或第三地机票，护照有效期不得少于6个月，以免无法办理乘机和出境手续。"},"1": {"title": "中转提醒","text": "目前各航司和国家/地区政策变化频繁，为保障您的出行顺利，请务必在出行前了解各航司及中转国（地）相关政策。"}},"2": {"0": {"title": "入境美国须知","text": "持有中国大陆护照并拥有10年有效B1、B2或B1/B2美国签证的旅客，请在出行前确认已根据实际出行所用的护照信息登记 EVUS 。持外籍护照的旅客，请在出行前确认已根据实际出行所用的护照信息登记ESTA，以免影响入境或过境美国。"}}}},"stopOverPassage": {}}
    }

    // JRJ0MR
    private LinkedList<Map<String, Object>> getDataJson_zhongzhuan_zhifei() {
        Map<String, Object> segmentMap = new HashMap<>();
        segmentMap.put("ticket_index", 0);  // 票序号(从0开始)，用于判断哪些票属于同一张
        segmentMap.put("segment_no", 1);    // 航线顺序
        segmentMap.put("sequence_no", 1);   // 航班顺序
        segmentMap.put("dep_port_code", "XMN");  // 出发机场三字码
        segmentMap.put("dep_city_code", "XMN");  // 出发城市三字码
        segmentMap.put("dep_datetime", "2025-11-15 11:35:00");  // 出发时间
        segmentMap.put("dep_terminal", "T3");     // 出发航站楼
        segmentMap.put("arr_port_code", "TPE");  // 到达机场三字码
        segmentMap.put("arr_city_code", "TPE");  // 到达城市三字码
        segmentMap.put("arr_datetime", "2025-11-15 13:20:00");  // 到达时间
        segmentMap.put("arr_terminal", "T2");        // 到达航站楼
        segmentMap.put("al_code", "AE");            // 市场运营航司二字码
        segmentMap.put("flight_no", "AE992");      // 市场运营航班号
        segmentMap.put("act_al_code", "");        // 实际执飞航司二字码（说明该航班是共享航班），共享航班则必填
        segmentMap.put("act_flight_no", "");  // 实际执飞航班号（说明该航班是共享航班），共享航班必填
        segmentMap.put("stop_info_list", new ArrayList<>());
//        segmentMap.put("stop_info_list", new HashMap<String, Object>(){{  // 经停信息数组，存在经停必填
//            put("", "");
//        }});

        Map<String, Object> segmentMap2 = new HashMap<>();
        segmentMap2.put("ticket_index", 0);  // 票序号(从0开始)，用于判断哪些票属于同一张
        segmentMap2.put("segment_no", 1);    // 航线顺序
        segmentMap2.put("sequence_no", 2);   // 航班顺序
        segmentMap2.put("dep_port_code", "TPE");  // 出发机场三字码
        segmentMap2.put("dep_city_code", "TPE");  // 出发城市三字码
        segmentMap2.put("dep_datetime", "2025-11-15 21:25:00");  // 出发时间
        segmentMap2.put("dep_terminal", "T2");     // 出发航站楼
        segmentMap2.put("arr_port_code", "ONT");  // 到达机场三字码
        segmentMap2.put("arr_city_code", "ONT");  // 到达城市三字码
        segmentMap2.put("arr_datetime", "2025-11-15 16:50:00");  // 到达时间
        segmentMap2.put("arr_terminal", "TI");        // 到达航站楼
        segmentMap2.put("al_code", "CI");            // 市场运营航司二字码
        segmentMap2.put("flight_no", "CI024");      // 市场运营航班号
        segmentMap2.put("act_al_code", "");        // 实际执飞航司二字码（说明该航班是共享航班），共享航班则必填
        segmentMap2.put("act_flight_no", "");  // 实际执飞航班号（说明该航班是共享航班），共享航班必填
        segmentMap2.put("stop_info_list", new ArrayList<>());
//        segmentMap.put("stop_info_list", new HashMap<String, Object>(){{  // 经停信息数组，存在经停必填
//            put("", "");
//        }});

        LinkedList<Map<String, Object>> segmentMaps = new LinkedList<>();
        segmentMaps.add(segmentMap);
        segmentMaps.add(segmentMap2);

        return segmentMaps;
    }

    // DW3Q6D
    private LinkedList<Map<String, Object>> getDataJson_wangfan_zhifei() {
        Map<String, Object> segmentMap = new HashMap<>();
        segmentMap.put("ticket_index", 0);  // 票序号(从0开始)，用于判断哪些票属于同一张
        segmentMap.put("segment_no", 1);    // 航线顺序
        segmentMap.put("sequence_no", 1);   // 航班顺序
        segmentMap.put("dep_port_code", "HND");  // 出发机场三字码
        segmentMap.put("dep_city_code", "TYO");  // 出发城市三字码
        segmentMap.put("dep_datetime", "2026-03-16 02:15:00");  // 出发时间
        segmentMap.put("dep_terminal", "T3");     // 出发航站楼
        segmentMap.put("arr_port_code", "PVG");  // 到达机场三字码
        segmentMap.put("arr_city_code", "SHA");  // 到达城市三字码
        segmentMap.put("arr_datetime", "2026-03-16 04:45:00");  // 到达时间
        segmentMap.put("arr_terminal", "T2");        // 到达航站楼
        segmentMap.put("al_code", "HO");            // 市场运营航司二字码
        segmentMap.put("flight_no", "HO1386");      // 市场运营航班号
        segmentMap.put("act_al_code", "");        // 实际执飞航司二字码（说明该航班是共享航班），共享航班则必填
        segmentMap.put("act_flight_no", "");  // 实际执飞航班号（说明该航班是共享航班），共享航班必填
        segmentMap.put("stop_info_list", new ArrayList<>());
//        segmentMap.put("stop_info_list", new HashMap<String, Object>(){{  // 经停信息数组，存在经停必填
//            put("", "");
//        }});

        Map<String, Object> segmentMap2 = new HashMap<>();
        segmentMap2.put("ticket_index", 0);  // 票序号(从0开始)，用于判断哪些票属于同一张
        segmentMap2.put("segment_no", 1);    // 航线顺序
        segmentMap2.put("sequence_no", 2);   // 航班顺序
        segmentMap2.put("dep_port_code", "PVG");  // 出发机场三字码
        segmentMap2.put("dep_city_code", "SHA");  // 出发城市三字码
        segmentMap2.put("dep_datetime", "2026-03-16 08:25:00");  // 出发时间
        segmentMap2.put("dep_terminal", "T2");     // 出发航站楼
        segmentMap2.put("arr_port_code", "NRT");  // 到达机场三字码
        segmentMap2.put("arr_city_code", "TYO");  // 到达城市三字码
        segmentMap2.put("arr_datetime", "2026-03-16 12:00:00");  // 到达时间
        segmentMap2.put("arr_terminal", "T2");        // 到达航站楼
        segmentMap2.put("al_code", "HO");            // 市场运营航司二字码
        segmentMap2.put("flight_no", "HO1379");      // 市场运营航班号
        segmentMap2.put("act_al_code", "");        // 实际执飞航司二字码（说明该航班是共享航班），共享航班则必填
        segmentMap2.put("act_flight_no", "");  // 实际执飞航班号（说明该航班是共享航班），共享航班必填
        segmentMap2.put("stop_info_list", new ArrayList<>());
//        segmentMap.put("stop_info_list", new HashMap<String, Object>(){{  // 经停信息数组，存在经停必填
//            put("", "");
//        }});

        LinkedList<Map<String, Object>> segmentMaps = new LinkedList<>();
        segmentMaps.add(segmentMap);
        segmentMaps.add(segmentMap2);

        return segmentMaps;
    }

    /**
     * 按照指定的键顺序对Map进行排序
     * @param originalMap 原始Map
     * @param specifiedOrder 指定的键顺序列表
     * @return 排序后的LinkedHashMap
     */
    public static LinkedHashMap<String, Object> mapSort(Map<String, Object> originalMap, List<String> specifiedOrder) {
        // 创建新的LinkedHashMap来保持顺序
        LinkedHashMap<String, Object> sortedMap = new LinkedHashMap<>();

        // 首先按照指定顺序添加存在的键
        for (String key : specifiedOrder) {
            if (originalMap.containsKey(key)) {
                sortedMap.put(key, originalMap.get(key));
            }
        }

        // 然后添加剩余不在指定顺序中的键（按原始顺序）
        for (Map.Entry<String, Object> entry : originalMap.entrySet()) {
            if (!specifiedOrder.contains(entry.getKey())) {
                sortedMap.put(entry.getKey(), entry.getValue());
            }
        }

        return sortedMap;
    }

//    /**
//     * 航班动态数据-查询
//     */
//    @Test
//    public void am_flight() {
//        String appid = "10373";
//        String appsecurity = "68d891c6dcc08";
//
//        TreeMap<String, String> treeMap = new TreeMap<>();
//        treeMap.put("appid", appid);
//        treeMap.put("date", "2026-03-05");
//        treeMap.put("fnum", "CA745");
//
//        String param = treeMap.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue()).collect(Collectors.joining("&")) + appsecurity;
//        String md5Param = DigestUtil.md5Hex(DigestUtil.md5Hex(param));
//        System.out.println("[encrypt] before: " + param + ", after: " + md5Param);
//
//        ForestQueryMap forestQueryMap = new ForestQueryMap();
//        forestQueryMap.putAll(treeMap);
//
//        HashMap result = Forest.get("https://api.133.cn/api/flight")
//                .addAllQuery(forestQueryMap)
//                .addQuery("token", md5Param)
//                .execute(HashMap.class);
//        System.out.println(JacksonUtil.toJsonString(result));
//    }

    /**
     * 航班动态数据-定制
     */
//    @Test
//    public void am_flightSubscribe() {
//        String appid = "10373";
//        String appsecurity = "68d891c6dcc08";
//
//        TreeMap<String, String> treeMap = new TreeMap<>();
//        treeMap.put("appid", appid);
//        treeMap.put("depCode", "NRT");
//        treeMap.put("arrCode", "PVG");
//        treeMap.put("fnum", "CA745");
//        treeMap.put("date", "2026-03-05");
//        treeMap.put("fid", "123456789");
//
//        String param = treeMap.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue()).collect(Collectors.joining("&")) + appsecurity;
//        String md5Param = DigestUtil.md5Hex(DigestUtil.md5Hex(param));
//        System.out.println("[encrypt] before: " + param + ", after: " + md5Param);
//
//        ForestQueryMap forestQueryMap = new ForestQueryMap();
//        forestQueryMap.putAll(treeMap);
//
//        HashMap result = Forest.get("https://api.133.cn/api/flightSubscribe")
//                .addAllQuery(forestQueryMap)
//                .addQuery("token", md5Param)
//                .execute(HashMap.class);
//        System.out.println(JacksonUtil.toJsonString(result));
//    }

    @Test
    public void batchInsert_FlightSearchParamSolution() {
        FlightSearchParamSolution flightSearchParamSolution = FlightSearchParamSolution.builder().searchParamKey("a01").solutionKey("r01").createBy("1").createTime(LocalDateTime.now().withNano(0)).build();
        FlightSearchParamSolution flightSearchParamSolution2 = FlightSearchParamSolution.builder().searchParamKey("a01").solutionKey("r01").createBy("1").createTime(LocalDateTime.now().withNano(0)).build();
        FlightSearchParamSolution flightSearchParamSolution3 = FlightSearchParamSolution.builder().searchParamKey("a01").solutionKey("r02").createBy("1").createTime(LocalDateTime.now().withNano(0)).build();
        FlightSearchParamSolution flightSearchParamSolution4 = FlightSearchParamSolution.builder().searchParamKey("a02").solutionKey("r01").createBy("1").createTime(LocalDateTime.now().withNano(0)).build();
        FlightSearchParamSolution flightSearchParamSolution5 = FlightSearchParamSolution.builder().searchParamKey("a02").solutionKey("r01").createBy("1").createTime(LocalDateTime.now().withNano(0)).build();
        FlightSearchParamSolution flightSearchParamSolution6 = FlightSearchParamSolution.builder().searchParamKey("a02").solutionKey("r02").createBy("1").createTime(LocalDateTime.now().withNano(0)).build();
        ArrayList<FlightSearchParamSolution> flightSearchParamSolutions = Lists.newArrayList(flightSearchParamSolution,
                flightSearchParamSolution2,
                flightSearchParamSolution3,
                flightSearchParamSolution4,
                flightSearchParamSolution5,
                flightSearchParamSolution6);
        int i = flightSearchParamSolutionService.batchInsert(flightSearchParamSolutions);
        System.out.println(i);
    }

    @Test
    public void batchInsert_FlightSolution() {
        FlightSolution flightSolution = FlightSolution.builder().solutionKey("a").createBy("1").createTime(LocalDateTime.now().withNano(0)).build();
        FlightSolution flightSolution2 = FlightSolution.builder().solutionKey("a").createBy("1").createTime(LocalDateTime.now().withNano(0)).build();
        FlightSolution flightSolution3 = FlightSolution.builder().solutionKey("b").createBy("1").createTime(LocalDateTime.now().withNano(0)).build();
        int i = flightSolutionService.batchInsert(Lists.newArrayList(flightSolution, flightSolution2, flightSolution3));
        System.out.println(i);
    }

    @Test
    public void idworder() throws InterruptedException {
        Set<Long> idSet = new HashSet<>();
        for (int i = 0; i < 20000; i++) {
            taskExecutor.execute(() -> {
                long id = idWorker.nextId();
                idSet.add(id);
                System.out.println(id);
            });
        }

        Thread.sleep(10000L);
    }

    @Test
    public void sabre_atpco_search_price() {
        Query query = Query.builder().offerItemId(Lists.newArrayList("pe7d7f9df8474xgn9mf50t0pa0-1-1")).build();
        OfferPriceRequestV1 request = OfferPriceRequestV1.builder().query(Lists.newArrayList(query)).build();

        List<String> offerItemIds = request.getQuery().stream().map(Query::getOfferItemId).collect(ArrayList::new, List::addAll, List::addAll);
        String response = sabreApi.searchPriceByNDC(BusinessType.QUERY_PRICE, String.join(",", offerItemIds), request);
        System.out.println(response);
    }

    @Test
    public void sabre_ndc_search_price() {
        Query query = Query.builder().offerItemId(Lists.newArrayList("pe7d7f9df8474xgn9mf50t0pa0-1-1")).build();
        OfferPriceRequestV1 request = OfferPriceRequestV1.builder().query(Lists.newArrayList(query)).build();

        List<String> offerItemIds = request.getQuery().stream().map(Query::getOfferItemId).collect(ArrayList::new, List::addAll, List::addAll);
        String response = sabreApi.searchPriceByNDC(BusinessType.QUERY_PRICE, String.join(",", offerItemIds), request);
        System.out.println(response);
    }

    @Test
    public void sabre_search_flight() {
        String json = "{\"OTA_AirLowFareSearchRQ\":{\"Version\":\"5\",\"POS\":{\"Source\":[{\"PseudoCityCode\":\"L0LA\",\"RequestorID\":{\"Type\":\"1\",\"ID\":\"1\",\"CompanyName\":{\"Code\":\"TN\"}}}]},\"OriginDestinationInformation\":[{\"DepartureDateTime\":\"2025-09-11T20:00:00\",\"OriginLocation\":{\"LocationCode\":\"WAW\"},\"DestinationLocation\":{\"LocationCode\":\"SPU\"}},{\"DepartureDateTime\":\"2025-09-18T20:00:00\",\"OriginLocation\":{\"LocationCode\":\"SPU\"},\"DestinationLocation\":{\"LocationCode\":\"WAW\"}}],\"TravelPreferences\":{\"MaxStopsQuantity\":0,\"VendorPref\":[{\"Code\":\"LO\"}]},\"TravelerInfoSummary\":{\"AirTravelerAvail\":[{\"PassengerTypeQuantity\":[{\"Code\":\"ADT\",\"Quantity\":1}]}]},\"TPA_Extensions\":{\"IntelliSellTransaction\":{\"RequestType\":{\"Name\":\"50ITINS\"}}}}}";
        List<FlightPlantVo> flightPlantVos = sabreService.searchFlight(null);
        System.out.println(JacksonUtil.toJsonString(flightPlantVos));
    }

    @Test
    public void sabre_access_token() {
        String accessToken = sabreService.getRestAccessToken();
        System.out.println(accessToken);
    }

    @Test
    public void galileo_queue_enter() {
        String pcc = Optional.ofNullable(PccType.fromBranch(gdsConfig.getGalileo().getBranch())).map(PccType::getPcc).orElse(null);

        QueueSelector queueSelector = new QueueSelector();
        queueSelector.setQueue(gdsConfig.getGalileo().getAirChangeQueue());

        GdsEnterQueueReq gdsEnterQueueReq = new  GdsEnterQueueReq();
        gdsEnterQueueReq.setPseudoCityCode(pcc);
        gdsEnterQueueReq.setQueueSelector(queueSelector);

        GdsEnterQueueReqSoap gdsEnterQueueReqSoap = GdsEnterQueueReqSoap.build(gdsEnterQueueReq);
        String requestXml = XmlUtil.beanToXmlByJAXB(gdsEnterQueueReqSoap);
        String responseXml = galileoApi.gdsQueueService(BusinessType.QUEUE_ENTER, gdsConfig.getGalileo().getAirChangeQueue(), requestXml);
        GdsEnterQueueRspSoap resultVo = XmlUtil.xmlToBeanByJAXB(responseXml, GdsEnterQueueRspSoap.class);
        System.out.println(JacksonUtil.toJsonString(resultVo));
        System.out.println(">>>>> QueueSessionToken : " + Optional.ofNullable(resultVo).map(GdsEnterQueueRspSoap::getBody).map(GdsEnterQueueRspSoap.SoapBody::getGdsEnterQueueRsp).map(GdsEnterQueueRsp::getQueueSessionToken).orElse(null));
    }

    @Test
    public void galileo_queue_next_on() {
        String pcc = Optional.ofNullable(PccType.fromBranch(gdsConfig.getGalileo().getBranch())).map(PccType::getPcc).orElse(null);

        QueueSelector queueSelector = new QueueSelector();
        queueSelector.setQueue(gdsConfig.getGalileo().getAirChangeQueue());

        QueuePseudoCitySelector queuePseudoCitySelector = new QueuePseudoCitySelector();
        queuePseudoCitySelector.setPseudoCityCode(pcc);
        queuePseudoCitySelector.setQueueSelector(queueSelector);

        GdsNextOnQueueReq gdsNextOnQueueReq = new GdsNextOnQueueReq();
        gdsNextOnQueueReq.setQueuePseudoCitySelector(queuePseudoCitySelector);
        gdsNextOnQueueReq.setRemoveCurrent(true);
        gdsNextOnQueueReq.setQueueSessionToken("026CB4500A0EE0E73CC11297B7E06E5C");

        GdsNextOnQueueReqSoap gdsNextOnQueueReqSoap = GdsNextOnQueueReqSoap.build(gdsNextOnQueueReq);
        String requestXml = XmlUtil.beanToXmlByJAXB(gdsNextOnQueueReqSoap);
        String responseXml = galileoApi.gdsQueueService(BusinessType.QUEUE_NEXT_ONE, gdsConfig.getGalileo().getAirChangeQueue(), requestXml);
        GdsNextOnQueueRspSoap resultVo = XmlUtil.xmlToBeanByJAXB(responseXml, GdsNextOnQueueRspSoap.class);
        System.out.println(JacksonUtil.toJsonString(resultVo));
        System.out.println(">>>>> QueueSessionToken : " + Optional.ofNullable(resultVo).map(GdsNextOnQueueRspSoap::getBody).map(GdsNextOnQueueRspSoap.SoapBody::getGdsNextOnQueueRsp).map(GdsNextOnQueueRsp::getQueueSessionToken).orElse(null));
    }

    @Test
    public void galileo_queue_exit() {
        String pcc = Optional.ofNullable(PccType.fromBranch(gdsConfig.getGalileo().getBranch())).map(PccType::getPcc).orElse(null);

        QueueSelector queueSelector = new QueueSelector();
        queueSelector.setQueue(gdsConfig.getGalileo().getAirChangeQueue());

        QueuePseudoCitySelector queuePseudoCitySelector = new QueuePseudoCitySelector();
        queuePseudoCitySelector.setPseudoCityCode(pcc);
        queuePseudoCitySelector.setQueueSelector(queueSelector);

        GdsExitQueueReq gdsExitQueueReq = new GdsExitQueueReq();
        gdsExitQueueReq.setQueuePseudoCitySelector(queuePseudoCitySelector);
        gdsExitQueueReq.setRemoveCurrent(true);
        gdsExitQueueReq.setQueueSessionToken("026ECA000A0EE1B62B9243C072C260BF");

        GdsExitQueueReqSoap gdsExitQueueReqSoap = GdsExitQueueReqSoap.build(gdsExitQueueReq);
        String requestXml = XmlUtil.beanToXmlByJAXB(gdsExitQueueReqSoap);
        String responseXml = galileoApi.gdsQueueService(BusinessType.QUEUE_EXIT, gdsConfig.getGalileo().getAirChangeQueue(), requestXml);
        GdsExitQueueRspSoap resultVo = XmlUtil.xmlToBeanByJAXB(responseXml, GdsExitQueueRspSoap.class);
        System.out.println(JacksonUtil.toJsonString(resultVo));
    }

    @Test
    public void galileo_change_segment_status() {
        QueryPnrRsp<UniversalRecordRetrieveRspSoap> queryPnrRsp = galileoService.queryPnr("FC12MZ");

        AckScheduleChangeReq ackScheduleChangeReq = new  AckScheduleChangeReq();
        ackScheduleChangeReq.setUniversalRecordLocatorCode(queryPnrRsp.getUniversalRecordCode());
        ackScheduleChangeReq.setProviderCode(GDSType.GALELIO.getCode());
        ackScheduleChangeReq.setProviderLocatorCode(queryPnrRsp.getProviderReservationCode());
        ackScheduleChangeReq.setVersion(queryPnrRsp.getVersion());

        AckScheduleChangeReqSoap ackScheduleChangeReqSoap = AckScheduleChangeReqSoap.build(ackScheduleChangeReq);
        String requestXml = XmlUtil.beanToXmlByJAXB(ackScheduleChangeReqSoap);
        String responseXml = galileoApi.scheduleChangeService(BusinessType.CHANGE_SEGMENT_STATUS, ackScheduleChangeReq.getProviderLocatorCode(), requestXml);
        AckScheduleChangeRspSoap resultVo = XmlUtil.xmlToBeanByJAXB(responseXml, AckScheduleChangeRspSoap.class);
        System.out.println(JacksonUtil.toJsonString(resultVo));
    }

    @Test
    public void galileo_ticketno_info() {
        QueryTicketNumberInfoReq queryTicketNoInfoReq = QueryTicketNumberInfoReq.builder()
//                .pnr("DD3129")
//                .ticketNumbers(Lists.newArrayList("9995517726001"))

//                .pnr("DZX976")
//                .ticketNumbers(Lists.newArrayList("7812417285193", "7812417285192"))

//                .pnr("F92CFM")
//                .ticketNumbers(Lists.newArrayList("7815518076482", "7815518076483"))

                .pnr("F5SBC2")
                .ticketNumbers(Lists.newArrayList("7815518037730", "7815518037732"))

//                .pnr("DWWLT7")
//                .ticketNumbers(Lists.newArrayList("9995517926944"))
                .build();
        CommonRsp<AirRetrieveDocumentRsp> airRetrieveDocumentRsp = galileoService.queryTicketNumberInfo(queryTicketNoInfoReq);
        System.out.println(JacksonUtil.toJsonString(airRetrieveDocumentRsp));
    }

    @Test
    public void galileo_modify_traveler_phone() {
        PhoneNumber phoneNumber = new PhoneNumber();
        phoneNumber.setKey("gz2kGibEuDKA4mKq7BAAAA==");
        phoneNumber.setNumber("13100000001");

        BookingTravelerInfo bookingTravelerInfo = new BookingTravelerInfo();
        bookingTravelerInfo.setKey("gz2kGibEuDKA3mKq7BAAAA==");
        bookingTravelerInfo.setPhoneNumber(phoneNumber);

        UniversalUpdate universalUpdate = new UniversalUpdate();
        universalUpdate.setBookingTravelerInfo(bookingTravelerInfo);

        UniversalModifyCmd universalModifyCmd = new UniversalModifyCmd();
        universalModifyCmd.setKey(UUIDUtil.getUUID());
        universalModifyCmd.setUniversalUpdate(universalUpdate);

        RecordIdentifier recordIdentifier = new RecordIdentifier();
        recordIdentifier.setProviderCode(GDSType.GALELIO.getCode());
        recordIdentifier.setUniversalLocatorCode("3N47AY");
        recordIdentifier.setProviderLocatorCode("D1S8TR");

        UniversalRecordModifyReq universalRecordModifyReq = new UniversalRecordModifyReq();
        universalRecordModifyReq.setVersion(BigInteger.valueOf(3));
        universalRecordModifyReq.setReturnRecord(true);
        universalRecordModifyReq.setRecordIdentifier(recordIdentifier);
        universalRecordModifyReq.getUniversalModifyCmd().add(universalModifyCmd);

        UniversalRecordModifyReqSoap universalRecordModifyReqSoap = UniversalRecordModifyReqSoap.build(universalRecordModifyReq);
        String requestXml = XmlUtil.beanToXmlByJAXB(universalRecordModifyReqSoap);
        String responseXml = galileoApi.universalRecordService(BusinessType.MODIFY_TRAVELER_PHONE, recordIdentifier.getProviderLocatorCode(), requestXml);
        System.out.println(responseXml);
    }

    @Test
    public void ibe_printer_number_quota() {
        CommonRsp<TESAirTicketDeviceRS> commonRsp = ibeService.queryBspQuota();
        System.out.println(commonRsp);
    }

    @Test
    public void galileo_ticket_success_response() throws Exception {
        InputStream inputStream = Files.newInputStream(Paths.get("C:\\Users\\dy123\\Desktop\\ticket-success-response.xml"));
        String xml = IOUtils.toString(inputStream, StandardCharsets.UTF_8);

        JAXBContext JAXB_CONTEXT = JAXBContext.newInstance(AirTicketingRspSoap.class);
        Unmarshaller unmarshaller = JAXB_CONTEXT.createUnmarshaller();
        AirTicketingRspSoap airTicketingRspSoap = (AirTicketingRspSoap) unmarshaller.unmarshal(new StringReader(xml));

        SearchPriceRsp<Object> searchPriceRsp = GalileoServiceImpl.getSearchPriceRsp(airTicketingRspSoap.getBody().getAirTicketingRsp());
        System.out.println(JacksonUtil.toJsonString(searchPriceRsp));
    }

    @Test
    public void ibe_rate() {
        TSKAirfarePrice tskAirfarePrice = com.ruoyi.gds.module.dto.ibe.RequestBuilder.buildTskAirfarePriceForRate(RateType.JPY_TO_CNY);
        String requestXml = XmlUtil.beanToXmlByJAXB(tskAirfarePrice);
        byte[] bytes = StrUtil.zip(requestXml);
        String responseXml = ibeApi.send(BusinessType.QUERY_RATE, UUIDUtil.getUUID(), gdsConfig.getIbe().getQueryRateUri(), bytes);
        TSKAirfarePrice tskAirfarePriceRsp = XmlUtil.xmlToBeanByJAXB(responseXml, TSKAirfarePrice.class);

        BigDecimal rate = Optional.ofNullable(tskAirfarePriceRsp)
                .map(TSKAirfarePrice::getResponse)
                .map(Response::getSitaAirfareCalculateCurrencyRS)
                .map(SITAAirfareCalculateCurrencyRS::getCurrencyCalculation)
                .map(CurrencyCalculation::getExchangeRateDetail)
                .map(ExchangeRateDetail::getRateOfExchange)
                .map(BigDecimal::new)
                .orElse(null);

        String errorMsg = Optional.ofNullable(tskAirfarePriceRsp)
                .map(TSKAirfarePrice::getResponse)
                .map(Response::getSitaAirfareCalculateCurrencyRS)
                .map(SITAAirfareCalculateCurrencyRS::getErrorMsg)
                .orElse(null);

        System.out.println(rate);
    }
    @Test
    public void galileo_rate() {
        CurrencyConversion currencyConversion = new CurrencyConversion();
        currencyConversion.setFrom("CNY");
        currencyConversion.setTo("JPY");
        currencyConversion.setOriginalAmount(Float.parseFloat("200"));

        CurrencyConversionReq currencyConversionReq = new CurrencyConversionReq();
        currencyConversionReq.getCurrencyConversion().add(currencyConversion);

        CurrencyConversionReqSoap conversionReqSoap = CurrencyConversionReqSoap.build(currencyConversionReq);
        String xml = XmlUtil.beanToXmlByJAXB(conversionReqSoap);
        String responseXml = galileoApi.currencyConversionService(BusinessType.QUERY_RATE, UUIDUtil.getUUID(), xml);
        CurrencyConversionRspSoap conversionRspSoap = XmlUtil.xmlToBeanByJAXB(responseXml, CurrencyConversionRspSoap.class);
        System.out.println(xml);
    }

    @Test
    public void void_pnr() throws InterruptedException {
        AirReservationLocatorCode airReservationLocatorCode = new AirReservationLocatorCode();
        airReservationLocatorCode.setValue("D0B55T");

        AirVoidDocumentReq airVoidDocumentReq = new AirVoidDocumentReq();
        airVoidDocumentReq.setAirReservationLocatorCode(airReservationLocatorCode);

        AirVoidDocumentReqSoap airVoidDocumentReqSoap = AirVoidDocumentReqSoap.build(airVoidDocumentReq);
        String xml = XmlUtil.beanToXmlByJAXB(airVoidDocumentReqSoap);
        System.out.println(xml);
    }

    @Test
    public void firstCabinScan() {
        String json = "{\n" +
                "    \"cabins\": [\n" +
                "        \"C\"\n" +
                "    ],\n" +
                "    \"gds\": \"1S\",\n" +
                "    \"passengers\": [\n" +
                "        \"ADT\"\n" +
                "    ],\n" +
                "    \"segments\": [\n" +
                "        {\n" +
                "            \"group\": 0,\n" +
                "            \"origin\": \"NRT\",\n" +
                "            \"destination\": \"PVG\",\n" +
                "            \"carrier\": \"GK\",\n" +
                "            \"flightNumber\": \"35\",\n" +
                "            \"operatingCarrier\": \"GK\",\n" +
                "            \"operatingFlightNumber\": \"35\",\n" +
                "            \"departureTime\": \"2026-02-16T22:25:00\",\n" +
                "            \"arrivalTime\": \"2026-02-17T01:10:00\"\n" +
                "        }\n" +
                "    ],\n" +
                "    \"ruleId\": 9,\n" +
                "    \"taskId\": 108\n" +
                "}";
        CabinScanDto cabinScanDto = JacksonUtil.toBean(json, CabinScanDto.class);
//        Assert.assertNotNull(cabinScanDto);
//        rabbitTemplate.convertAndSend(RabbitmqConstant.DEFAUL_EXCHANGE, RabbitmqConstant.TICKET_FIRST_CABIN_SCAN_REQ_ROUTING, cabinScanDto);
        CabinScanVo cabinScanVo = airService.cabinScan(cabinScanDto);
        System.out.println(JacksonUtil.toJsonString(cabinScanVo));
    }

    @Test
    public void rabbitmqTest() throws InterruptedException {
        for (int i = 0; i < 100; i++) {
            Thread.sleep(1000);

            Map<String, String> map = new HashMap<>();
            map.put("gds", "D8J63Z");

            /*IssuedPnrBaggage baggage = IssuedPnrBaggage.builder().baggagePiece(String.valueOf(i + 1)).build();*/
            rabbitTemplate.convertAndSend(RabbitmqConstant.DEFAUL_EXCHANGE, RabbitmqConstant.TICKET_AIR_CHANGE_QUERY_PNR_REQ_ROUTING, map);
        }
    }

    @Test
    public void test3() throws JsonProcessingException, InterruptedException {
        String flightUrl = "https://linkstar.travelsky.com.cn/develop/xml/AirFareSearchOne/I";
        String json = "{\"segments\":[{\"origin\":[{\"name\":\"NRT\"}],\"destination\":[{\"name\":\"SHA\"}],\"departureDate\":{\"year\":2025,\"month\":8,\"day\":25},\"preferences\":{}}],\"agencies\":[{\"channel\":\"1E\",\"pos\":\"SHA\",\"iataNumber\":\"08348513\",\"travelAgencyCode\":\"WUH161\"}],\"passengers\":[{\"ptc\":[\"ADT\"]},{\"ptc\":[\"ADT\"]},{\"ptc\":[\"CNN\"],\"birthDay\":[2019,7,24],\"dateOfBirth\":{\"year\":2019,\"month\":7,\"day\":24}}],\"preferences\":{\"allowedStops\":\"0\",\"cabins\":{\"codes\":[\"ECONOMY\"],\"virtual\":false},\"downsell\":false,\"upsell\":false},\"journeyPreferences\":{\"includeBaggage\":true,\"includeCommission\":true,\"includeSurcharge\":true,\"includePenalties\":true,\"includeDebugOutput\":false,\"includeIataTax\":true,\"includeYqyr\":true,\"searchSpeed\":2,\"multiCabin\":false,\"allowMultiCabinCombo\":false,\"detailedPricing\":true,\"availability\":\"CACHE_PLUS\",\"maxResponse\":100}}";
        IBESearchFlightDto flightDto = JacksonUtil.toBean(json, IBESearchFlightDto.class);
        byte[] flightBytes = StrUtil.beanToZipByteWithoutNullEmpty(flightDto);

        String priceUrl = "https://linkstar.travelsky.com.cn/develop/xml/AirFarePrice/I";
        String priceJson = "{\"batchCode\":null,\"flightKey\":\"9eb4df0e4a1a4512bd2350dc3c30c02b\",\"flightFareKey\":\"196fcc4408164df5b688494ad4d11764\",\"providerCode\":\"1E\",\"currencyCode\":\"CNY\",\"segements\":[{\"seq\":1,\"segmentKey\":\"IrXurfYAuDKAKt+cE6AAAA==\",\"providerCode\":\"1E\",\"group\":0,\"carrier\":\"CZ\",\"flightNumber\":\"8310\",\"operatingCarrier\":\"CZ\",\"operatingFlightNumber\":\"8310\",\"origin\":\"NRT\",\"destination\":\"PVG\",\"departureTime\":\"2025-08-25T14:35:00.000+09:00\",\"arrivalTime\":\"2025-08-25T17:05:00.000+08:00\",\"classOfService\":\"Y\",\"cabinType\":\"Economy\"}],\"passengers\":[\"ADT\",\"ADT\",\"CNN\"],\"searchPriceType\":\"C3\"}";
        SearchPriceReq searchPriceReq = JacksonUtil.toBean(priceJson, SearchPriceReq.class);
        TSKAirfarePrice tskAirfarePrice = com.ruoyi.gds.module.dto.ibe.RequestBuilder.buildTskAirfarePrice(searchPriceReq);
        String requestXml = XmlUtil.beanToXmlByJAXB(tskAirfarePrice);
        byte[] priceBytes = StrUtil.zip(requestXml);

        for (int i = 0; i < 50; i++) {
            taskExecutor.execute(() -> {
                try {
                    String response = excute(flightUrl, flightBytes);
                    String resultXml = StrUtil.unZip(response);
                    IBESearchFlightResultVo resultVo = objectMapper.readValue(resultXml, new TypeReference<IBESearchFlightResultVo>() {
                    });
                    System.out.println("===航班：" + JacksonUtil.toJsonString(resultVo.getErrorInformation()));
                } catch (JsonProcessingException e) {
                    throw new RuntimeException(e);
                }
            });
        }

        for (int i = 0; i < 50; i++) {
            taskExecutor.execute(() -> {
                String resultXml = excute(priceUrl, priceBytes);
                TSKAirfarePrice resultVo = XmlUtil.xmlToBeanByJAXB(resultXml, TSKAirfarePrice.class);
                System.out.println("===查价：" + JacksonUtil.toJsonString(resultVo.getResponse().getSitaAirfarePriceRS().getOtaAirPriceRS().getSuccess()));
            });
        }

        Thread.sleep(30 * 60 * 1000);
    }

    private String excute(String url, byte[] compressedBody) {
        synchronized (url) {
            try {
                Thread.sleep(1000);
                return ibeApi.send(null, null, url, compressedBody);
            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }
    }

    @Test
    public void test2() {
        ResultVo<List<BusinessFlightSavedVo>> resultVo = ticketApi.businessSavedFlight("241041");
        System.out.println(resultVo);
    }

    @Test
    public void pasr_pnr_expire_time() {
        String adtks = sysConfigService.selectConfigByKey(CommonConstant.PNR_EXPIRE_TIME_LABEL);
        List<ADTKVo> adtkList = JacksonUtil.toBeanList(adtks, ADTKVo.class);
        System.out.println(adtkList);

        LocalDateTime dateTime = DateUtil.getPnrExpireTimeFromADTK(adtkList, "ADTK 1E BY WUH23MAY25/1806 OR CXL 3U3963 N08JUN");
        System.out.println(dateTime);
    }

    @Test
    public void pasr_pnr_expire_time_by_pnr() {
        QueryPnrRsp<OTAAirResRetRS> queryPnrRsp = ibeService.queryPnr("KGFND7");
        System.out.println(JacksonUtil.toJsonString(queryPnrRsp));
    }

    @Test
    public void test1() {
        String requestXml = RequestBuilder.buildUniversalRecordSearchReq("CJGG8R");
        String responseXml = galileoApi.universalRecordService(BusinessType.QUERY_PNR, "CJGG8R", requestXml);
        UniversalRecordSearchRspSoap universalRecordSearchRspSoap = XmlUtil.xmlToBeanByJAXB(responseXml, UniversalRecordSearchRspSoap.class);

        String errorMsg = Optional.ofNullable(universalRecordSearchRspSoap)
                .map(UniversalRecordSearchRspSoap::getBody)
                .map(UniversalRecordSearchRspSoap.SoapBody::getUniversalRecordSearchRsp)
                .map(UniversalRecordSearchRsp::getResponseMessage)
                .map(responseMessages -> responseMessages.stream().map(ResponseMessage::getValue).collect(Collectors.joining(";")))
                .orElse(null);

        System.out.println(responseXml);
    }

    @Test
    public void check_pnr_occupancy_status() {
        LambdaQueryWrapper<FlightReservation> queryWrapper = Wrappers.lambdaQuery(FlightReservation.class)
//                .eq(FlightReservation::getStatus, FlightReservationStatus.SUCCESS.getCode())
                .eq(FlightReservation::isDelFlag, false);
        List<FlightReservation> flightReservations = flightReservationService.list(queryWrapper);
        if (CollectionUtil.isEmpty(flightReservations)) {
            return;
        }

        for (FlightReservation flightReservation : flightReservations) {
            if (StringUtils.isBlank(flightReservation.getCreatePnrRsp())) {
                continue;
            }

            String warnings = "";
            if (GDSType.GALELIO.getCode().equalsIgnoreCase(flightReservation.getProviderCode())) {
                AirCreateReservationRspSoap resultVo = XmlUtil.xmlToBeanByJAXB(flightReservation.getCreatePnrRsp(), AirCreateReservationRspSoap.class);
                warnings = GalileoDataUtil.getWarningByCreatePnrRsp(resultVo);
            }
            if (GDSType.IBE.getCode().equalsIgnoreCase(flightReservation.getProviderCode())) {
                OTAAirBookRS otaAirBookRS = XmlUtil.xmlToBeanByJAXB(flightReservation.getCreatePnrRsp(), OTAAirBookRS.class);
                warnings = IBEDataUtil.getWarningByCreatePnrRsp(otaAirBookRS);
            }

            if (StringUtils.isNotBlank(warnings)) {
                System.out.println(flightReservation.getPnr() + "\n" + warnings + "\n");
            }
        }
    }

    @Test
    public void galileo_update_pnr_add_price() {
        SearchPriceReq searchPriceReq = SearchPriceReq.builder()
                .flightKey("f91a0324d2a44e2687cb31dd70d665bd")
                .flightFareKey("ec9023a2a1a7440bb84d2f2c0abd3250")
                .passengers(Lists.newArrayList(PassengerType.ADT))
                .build();
        SearchPriceRsp<Object> searchPriceRsp = airService.searchLowPrice(searchPriceReq);

        AirPriceRspSoap airPriceRspSoap = XmlUtil.xmlToBeanByJAXB(searchPriceRsp.getOrignalInfo(), AirPriceRspSoap.class);
        List<AirPricingInfo> airPricingInfos = Optional.ofNullable(airPriceRspSoap)
                .map(AirPriceRspSoap::getBody)
                .map(AirPriceRspSoap.SoapBody::getAirPriceRsp)
                .map(AirPriceRsp::getAirPriceResult)
                .map(airPriceResults -> airPriceResults.stream()
                        .map(airPriceResult -> airPriceResult.getAirPricingSolution().stream().min(Comparator.comparingInt(o -> Integer.parseInt(StrUtil.removeChar(o.getApproximateTotalPrice())))).orElse(null))
                        .filter(Objects::nonNull)
                        .map(AirPricingSolution::getAirPricingInfo)
                        .collect(ArrayList<AirPricingInfo>::new, List::addAll, List::addAll)
                )
                .orElse(Lists.newArrayList());

        AirAdd airAdd = new AirAdd();
        airAdd.setReservationLocatorCode("2GWPGE");
        airAdd.getAirPricingInfo().addAll(airPricingInfos);

        UniversalModifyCmd universalModifyCmd = new UniversalModifyCmd();
        universalModifyCmd.setKey("1");
        universalModifyCmd.setAirAdd(airAdd);

        RecordIdentifier recordIdentifier = new RecordIdentifier();
        recordIdentifier.setProviderCode(GDSType.GALELIO.getCode());
        recordIdentifier.setUniversalLocatorCode("2GWPFF");
        recordIdentifier.setProviderLocatorCode("CDLM38");

        UniversalRecordModifyReq universalRecordModifyReq = new UniversalRecordModifyReq();
        universalRecordModifyReq.setVersion(BigInteger.valueOf(2));
        universalRecordModifyReq.setReturnRecord(true);
        universalRecordModifyReq.setRecordIdentifier(recordIdentifier);
        universalRecordModifyReq.getUniversalModifyCmd().add(universalModifyCmd);

        UniversalRecordModifyReqSoap universalRecordModifyReqSoap = UniversalRecordModifyReqSoap.build(universalRecordModifyReq);

        String requestXml = XmlUtil.beanToXmlByJAXB(universalRecordModifyReqSoap);
//        String response = galileoApi.universalRecordService(requestXml);
        System.out.println("");
    }

    @Test
    public void galileo_update_pnr_delete_price() {
        AirDelete airDelete = new AirDelete();
        airDelete.setKey("6aexVbqwnDKATEIyrrAAAA==");
        airDelete.setReservationLocatorCode("2GWPGE");
        airDelete.setElement(TypeElement.AIR_PRICING_INFO);

        UniversalModifyCmd universalModifyCmd = new UniversalModifyCmd();
        universalModifyCmd.setKey("1");
        universalModifyCmd.setAirDelete(airDelete);

        RecordIdentifier recordIdentifier = new RecordIdentifier();
        recordIdentifier.setProviderCode(GDSType.GALELIO.getCode());
        recordIdentifier.setUniversalLocatorCode("2GWPFF");
        recordIdentifier.setProviderLocatorCode("CDLM38");

        UniversalRecordModifyReq universalRecordModifyReq = new UniversalRecordModifyReq();
        universalRecordModifyReq.setVersion(BigInteger.valueOf(1));
        universalRecordModifyReq.setReturnRecord(true);
        universalRecordModifyReq.setRecordIdentifier(recordIdentifier);
        universalRecordModifyReq.getUniversalModifyCmd().add(universalModifyCmd);

        UniversalRecordModifyReqSoap universalRecordModifyReqSoap = UniversalRecordModifyReqSoap.build(universalRecordModifyReq);

        String requestXml = XmlUtil.beanToXmlByJAXB(universalRecordModifyReqSoap);
//        String response = galileoApi.universalRecordService(requestXml);
        System.out.println("");
    }

    @Test
    public void galileo_update_pnr_price() {
        Adjustment adjustment = new Adjustment();
        adjustment.setAdjustedTotalPrice("JPY50000");

        AirPricingAdjustment airPricingAdjustment = new AirPricingAdjustment();
        airPricingAdjustment.setKey("1");
        airPricingAdjustment.setAdjustment(adjustment);

        AirUpdate airUpdate = new AirUpdate();
        airUpdate.setReservationLocatorCode("2GR8E0");
        airUpdate.getAirPricingAdjustment().add(airPricingAdjustment);

        UniversalModifyCmd universalModifyCmd = new UniversalModifyCmd();
        universalModifyCmd.setKey("1");
        universalModifyCmd.setAirUpdate(airUpdate);

        RecordIdentifier recordIdentifier = new RecordIdentifier();
        recordIdentifier.setProviderCode(GDSType.GALELIO.getCode());
        recordIdentifier.setUniversalLocatorCode("2GR8DK");
        recordIdentifier.setProviderLocatorCode("CDJ97F");

        UniversalRecordModifyReq universalRecordModifyReq = new UniversalRecordModifyReq();
        universalRecordModifyReq.setVersion(BigInteger.valueOf(2));
        universalRecordModifyReq.setReturnRecord(true);
        universalRecordModifyReq.setRecordIdentifier(recordIdentifier);
        universalRecordModifyReq.getUniversalModifyCmd().add(universalModifyCmd);

        UniversalRecordModifyReqSoap universalRecordModifyReqSoap = UniversalRecordModifyReqSoap.build(universalRecordModifyReq);

        String requestXml = XmlUtil.beanToXmlByJAXB(universalRecordModifyReqSoap);
//        String response = galileoApi.universalRecordService(requestXml);
        System.out.println("");
    }

    @Test
    public void ibe_calculatePnrPrice() {
        BookingReferenceID bookingReferenceID = BookingReferenceID.builder()
                .idContext("PNR")
                .id("HNWW5S")
                .build();
        BookingReferenceID bookingReferenceID2 = BookingReferenceID.builder()
                .idContext("ORDER")
                .id("250526153529bea2f8b")
                .build();
        List<BookingReferenceID> bookingReferenceIDS = Lists.newArrayList(bookingReferenceID, bookingReferenceID2);

        PriceRequestInformation priceRequestInformation = PriceRequestInformation.builder()
                .currencyCode("CNY")
                .negotiatedFaresOnly(true)
                .build();

        PassengerTypeQuantity passengerTypeQuantity = PassengerTypeQuantity.builder()
                .code("ADT")
                .quantity(1)
                .build();
        List<PassengerTypeQuantity> passengerTypeQuantities = Lists.newArrayList(passengerTypeQuantity);

        AirTravelerAvail airTravelerAvail = AirTravelerAvail.builder()
                .passengerTypeQuantity(passengerTypeQuantities)
                .build();

        TravelerInfoSummary travelerInfoSummary = TravelerInfoSummary.builder()
                .airTravelerAvail(airTravelerAvail)
                .priceRequestInformation(priceRequestInformation)
                .build();

        FlightSegment segment = FlightSegment.builder()
                .flightNumber("920")
                .departureDateTime("2025-08-20T20:00:00.000+09:00")
                .departureAirport(DepartureAirport.builder().locationCode("NRT").build())
                .arrivalAirport(ArrivalAirport.builder().locationCode("PVG").build())
                .build();

        OriginDestinationOption originDestinationOption = OriginDestinationOption.builder()
                .flightSegment(Lists.newArrayList(segment))
                .build();
        OriginDestinationOptions originDestinationOptions = OriginDestinationOptions.builder()
                .originDestinationOption(Lists.newArrayList(originDestinationOption))
                .build();
        AirItinerary airItinerary = AirItinerary.builder()
                .originDestinationOptions(originDestinationOptions)
                .build();


        Source source = Source.builder()
                .reuqestorID(RequestorID.builder().idContext("IATA_Number").id(gdsConfig.getIbe().getIata()).build())
                .build();
        Source source2 = Source.builder()
                .pseudoCityCode(gdsConfig.getIbe().getOffice())
                .build();
        Pos pos = Pos.builder()
                .source(Lists.newArrayList(source, source2))
                .build();

        OTAAirPriceRQ otaAirPriceRQ = OTAAirPriceRQ.builder()
                .pos(pos)
                .airItinerary(airItinerary)
                .travelerInfoSummary(travelerInfoSummary)
                .bookingReferenceID(bookingReferenceIDS)
                .build();

        TESAirfarePriceRQ tesAirfarePriceRQ = TESAirfarePriceRQ.builder()
                .otaAirPriceRQ(otaAirPriceRQ)
                .build();

        String requestXml = XmlUtil.beanToXmlByJAXB(tesAirfarePriceRQ);
        byte[] bytes = StrUtil.zip(requestXml);
        String result = ibeApi.send(BusinessType.QUERY_PRICE, UUIDUtil.getUUID(), gdsConfig.getIbe().getQueryPnrPriceUri(), bytes);
        TESAirfarePriceRS tesAirfarePriceRS = XmlUtil.xmlToBeanByJAXB(result, TESAirfarePriceRS.class);
        System.out.println(result);
    }

    @Test
    public void galileo_query_pnr() {
        QueryPnrRsp<UniversalRecordRetrieveRspSoap> pnrRsp = galileoService.queryPnr("C9TTRJ");
        System.out.println(JacksonUtil.toJsonString(pnrRsp));
    }

    @Test
    public void ibe_forward_cancel_pnr() throws JsonProcessingException {
        String requestXml = "<OTA_AirBookModifyRQ>\n" +
                "    <POS>\n" +
                "        <Source PseudoCityCode=\"WUH161\" />\n" +
                "    </POS>\n" +
                "    <AirBookModifyRQ ModificationType=\"PNR_CANCEL\">\n" +
                "    </AirBookModifyRQ>\n" +
                "    <AirReservation>\n" +
                "        <BookingReferenceID ID=\"KV261D\"/>\n" +
                "    </AirReservation>\n" +
                "</OTA_AirBookModifyRQ>";
        byte[] bytes = StrUtil.zip(requestXml);
        String s = ibeApi.send(BusinessType.CANCEL_PNR, "KV261D", "http://localhost:8083/air/ibe/forward?path=ota/xml/AirBookModify", bytes);
        System.out.println(s);
    }

    @Test
    public void ibe_forward_create_pnr() {
        String requestXml = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n" +
                "<OTA_AirBookRQ\n" +
                "    xmlns=\"http://espeed.travelsky.com\" EchoToken=\"d72e94fc62ed90fd4e93566a7777c407\" SegmentCheckInd=\"true\" AutoINFSuffixInd=\"false\">\n" +
                "    <POS>\n" +
                "        <Source PseudoCityCode=\"WUH161\"/>\n" +
                "    </POS>\n" +
                "    <SegmentStatusValid>\n" +
                "        <Status>HK</Status>\n" +
                "        <Status>DK</Status>\n" +
                "        <Status>KK</Status>\n" +
                "        <Status>KL</Status>\n" +
                "    </SegmentStatusValid>\n" +
                "    <AirItinerary>\n" +
                "        <OriginDestinationOptions>\n" +
                "            <OriginDestinationOption>\n" +
                "                <FlightSegment RPH=\"1\" DepartureDateTime=\"2025-05-07T11:50:00\" ArrivalDateTime=\"2025-05-07T15:00:00\" FlightNumber=\"1579\" CoHostInd=\"false\" Status=\"NN\" SegmentType=\"NORMAL\">\n" +
                "                    <DepartureAirport LocationCode=\"PVG\"/>\n" +
                "                    <ArrivalAirport LocationCode=\"KIX\"/>\n" +
                "                    <MarketingAirline Code=\"HO\"/>\n" +
                "                    <BookingClassAvail ResBookDesigCode=\"L\"/>\n" +
                "                </FlightSegment>\n" +
                "            </OriginDestinationOption>\n" +
                "        </OriginDestinationOptions>\n" +
                "    </AirItinerary>\n" +
                "    <TravelerInfo>\n" +
                "        <AirTraveler BirthDate=\"1992-08-13\" Gender=\"MALE\" PassengerTypeCode=\"ADT\">\n" +
                "            <PersonName LanguageType=\"EN\">\n" +
                "                <Surname>HAO/DEMING MR</Surname>\n" +
                "            </PersonName>\n" +
                "            <Document DocType=\"PP\" DocTypeDetail=\"P\" DocID=\"EH4938790\" DocIssueCountry=\"CN\" DocHolderNationality=\"CN\" DocHolderInd=\"false\" BirthDate=\"1992-08-13\" Gender=\"MALE\" ExpireDate=\"2029-12-26\" RPH=\"1\">\n" +
                "                <DocHolderFormattedName>\n" +
                "                    <GivenName>DEMING</GivenName>\n" +
                "                    <Surname>HAO</Surname>\n" +
                "                </DocHolderFormattedName>\n" +
                "            </Document>\n" +
                "            <TravelerRefNumber RPH=\"1\"/>\n" +
                "        </AirTraveler>\n" +
                "        <AirTraveler BirthDate=\"2023-01-15\" Gender=\"FEMALE\" PassengerTypeCode=\"ADT\">\n" +
                "            <PersonName LanguageType=\"EN\">\n" +
                "                <Surname>HAO/ZHOULING CHD</Surname>\n" +
                "            </PersonName>\n" +
                "            <Document DocType=\"PP\" DocTypeDetail=\"P\" DocID=\"EK2912831\" DocIssueCountry=\"CN\" DocHolderNationality=\"CN\" DocHolderInd=\"false\" BirthDate=\"2023-01-15\" Gender=\"FEMALE\" ExpireDate=\"2028-06-25\" RPH=\"2\">\n" +
                "                <DocHolderFormattedName>\n" +
                "                    <GivenName>ZHOULING</GivenName>\n" +
                "                    <Surname>HAO</Surname>\n" +
                "                </DocHolderFormattedName>\n" +
                "            </Document>\n" +
                "            <TravelerRefNumber RPH=\"2\"/>\n" +
                "        </AirTraveler>\n" +
                "        <AirTraveler BirthDate=\"1993-12-28\" Gender=\"FEMALE\" PassengerTypeCode=\"ADT\">\n" +
                "            <PersonName LanguageType=\"EN\">\n" +
                "                <Surname>ZHOU/HENAN MS</Surname>\n" +
                "            </PersonName>\n" +
                "            <Document DocType=\"PP\" DocTypeDetail=\"P\" DocID=\"EK5173112\" DocIssueCountry=\"CN\" DocHolderNationality=\"CN\" DocHolderInd=\"false\" BirthDate=\"1993-12-28\" Gender=\"FEMALE\" ExpireDate=\"2033-08-08\" RPH=\"3\">\n" +
                "                <DocHolderFormattedName>\n" +
                "                    <GivenName>HENAN</GivenName>\n" +
                "                    <Surname>ZHOU</Surname>\n" +
                "                </DocHolderFormattedName>\n" +
                "            </Document>\n" +
                "            <TravelerRefNumber RPH=\"3\"/>\n" +
                "        </AirTraveler>\n" +
                "        <SpecialReqDetails>\n" +
                "            <SpecialServiceRequests>\n" +
                "                <SpecialServiceRequest SSRCode=\"CHLD\" Status=\"HK\">\n" +
                "                    <Airline Code=\"HO\"/>\n" +
                "                    <Text>15JAN23</Text>\n" +
                "                    <TravelerRefNumber RPH=\"2\"/>\n" +
                "                </SpecialServiceRequest>\n" +
                "            </SpecialServiceRequests>\n" +
                "            <OtherServiceInformations>\n" +
                "                <OtherServiceInformation Code=\"OTHS\">\n" +
                "                    <Airline Code=\"HO\"/>\n" +
                "                    <Text>CTCM13862034733/P1/2/3</Text>\n" +
                "                </OtherServiceInformation>\n" +
                "                <OtherServiceInformation Code=\"OTHS\">\n" +
                "                    <Airline Code=\"HO\"/>\n" +
                "                    <Text>CTCEtctkt0428//outlook.com</Text>\n" +
                "                </OtherServiceInformation>\n" +
                "                <OtherServiceInformation Code=\"OTHS\">\n" +
                "                    <Airline Code=\"HO\"/>\n" +
                "                    <Text>CTCT18912790729</Text>\n" +
                "                </OtherServiceInformation>\n" +
                "            </OtherServiceInformations>\n" +
                "            <SpecialRemarks/>\n" +
                "        </SpecialReqDetails>\n" +
                "    </TravelerInfo>\n" +
                "    <Ticketing TicketTimeLimit=\"2025-05-07T09:50:00\"/>\n" +
                "    <TPA_Extensions>\n" +
                "        <EnvelopType>KI</EnvelopType>\n" +
                "        <EnvelopDelay>false</EnvelopDelay>\n" +
                "    </TPA_Extensions>\n" +
                "</OTA_AirBookRQ>";
        byte[] bytes = StrUtil.zip(requestXml);
        String s = ibeApi.send(null, null, "http://localhost:8083/air/ibe/forward?path=ota/xml/AirBook", bytes);
        System.out.println(s);
    }

    @Test
    public void airports() throws JsonProcessingException {
        AirportsVo airportsVo = airportsService.query("KIX");
        System.out.println("");
    }

    @Test
    public void rateTest() throws JsonProcessingException {
        RateRsp s = ticketApi.todayRate(new HashMap<>());
        System.out.println(s);
    }

    @Test
    public void ibeApiTest() throws JsonProcessingException {
        String requestXml = "<TSK_AirfarePrice>\n" +
                "    <Request>\n" +
                "        <SITA_AirfarePriceRQ xmlns=\"http://www.sita.aero/PTS/fare/2005/11/PriceRQ\" Version=\"0.3\">\n" +
                "            <ns:OTA_AirPriceRQ xmlns:ns=\"http://www.opentravel.org/OTA/2003/05\" Target=\"Test\" Version=\"2.0001\" EchoToken=\"TravelSky_IBE_LINE\" TimeStamp=\"2025-04-07T09:00:00\">\n" +
                "                <ns:POS>\n" +
                "                    <ns:Source>\n" +
                "                        <ns:RequestorID ID=\"8Le0x-ee4wR-II49g-MsCDk\" Type=\"7\" ID_Context=\"Airfare\" />\n" +
                "                    </ns:Source>\n" +
                "                    <ns:Source>\n" +
                "                        <ns:RequestorID ID=\"1E\" Type=\"7\" ID_Context=\"CRSCode\" />\n" +
                "                    </ns:Source>\n" +
                "                    <ns:Source AirportCode=\"WUH\" />\n" +
                "                    <ns:Source>\n" +
                "                        <ns:RequestorID ID=\"08348513\" Type=\"13\" ID_Context=\"IATA_Number\" />\n" +
                "                    </ns:Source>\n" +
                "                    <ns:Source PseudoCityCode=\"WUH161\" />\n" +
                "                </ns:POS>\n" +
                "                <ns:AirItinerary>\n" +
                "                    <ns:OriginDestinationOptions>\n" +
                "                        <ns:OriginDestinationOption>\n" +
                "                            <ns:FlightSegment DepartureDateTime=\"2025-05-15T09:50:00\" RPH=\"1\" ArrivalDateTime=\"2025-05-15T11:55:00\" Status=\"26\" FlightNumber=\"8203\" ResBookDesigCode=\"P\">\n" +
                "                                <ns:DepartureAirport LocationCode=\"WUH\" />\n" +
                "                                <ns:ArrivalAirport LocationCode=\"PEK\" />\n" +
                "                                <ns:MarketingAirline Code=\"CA\" />\n" +
                "                            </ns:FlightSegment>\n" +
                "                        </ns:OriginDestinationOption>\n" +
                "                        <ns:OriginDestinationOption>\n" +
                "                            <ns:FlightSegment DepartureDateTime=\"2025-05-15T14:15:00\" RPH=\"2\" ArrivalDateTime=\"2025-05-15T18:50:00\" Status=\"26\" FlightNumber=\"113\" ResBookDesigCode=\"P\">\n" +
                "                                <ns:DepartureAirport LocationCode=\"PEK\" />\n" +
                "                                <ns:ArrivalAirport LocationCode=\"NRT\" />\n" +
                "                                <ns:MarketingAirline Code=\"CA\" />\n" +
                "                            </ns:FlightSegment>\n" +
                "                        </ns:OriginDestinationOption>\n" +
                "                    </ns:OriginDestinationOptions>\n" +
                "                </ns:AirItinerary>\n" +
                "                <ns:TravelerInfoSummary>\n" +
                "                    <ns:AirTravelerAvail>\n" +
                "                        <ns:PassengerTypeQuantity Code=\"ADT\" Quantity=\"2\" />\n" +
                "                        <ns:PassengerTypeQuantity Code=\"CNN\" Quantity=\"1\" />\n" +
                "                    </ns:AirTravelerAvail>\n" +
                "                    <ns:PriceRequestInformation Reprice=\"false\" PricingSource=\"Both\" CurrencyCode=\"CNY\" />\n" +
                "                </ns:TravelerInfoSummary>\n" +
                "            </ns:OTA_AirPriceRQ>\n" +
                "            <AdditionalPriceRQData MaxResponses=\"20\" ETicketIndicator=\"true\" TaxSummaryInd=\"false\" TaxBreakdownInd=\"true\" IncludeNegotiatedFares=\"false\" ReturnAllEndos=\"true\" IncludeBrandRs=\"true\" IncludeBrandTranslation=\"true\">\n" +
                "                <FareTypeInfo Code=\"ALLB\" CodeContext=\"SITA\" />\n" +
                "                <TicketingCarrier Code=\"CA\" />\n" +
                "            </AdditionalPriceRQData>\n" +
                "        </SITA_AirfarePriceRQ>\n" +
                "    </Request>\n" +
                "</TSK_AirfarePrice>";
        byte[] bytes = StrUtil.zip(requestXml);
        String responseXml = ibeApi.send(BusinessType.QUERY_PRICE, UUIDUtil.getUUID(), gdsConfig.getIbe().getSearchFlightPriceC3Uri(), bytes);
        System.out.println(responseXml);
    }


    @Test
    public void testSearchPnr() {

        BillingPointOfSaleInfo billingPointOfSaleInfo = new BillingPointOfSaleInfo();
        billingPointOfSaleInfo.setOriginApplication("uAPI");

        UniversalRecordRetrieveReq universalRecordRetrieveReq = new UniversalRecordRetrieveReq();
        universalRecordRetrieveReq.setBillingPointOfSaleInfo(billingPointOfSaleInfo);
        universalRecordRetrieveReq.setUniversalRecordLocatorCode("1T354D");

        UniversalRecordRetrieveReqSoap universalRecordRetrieveReqSoap = UniversalRecordRetrieveReqSoap.build(universalRecordRetrieveReq);
        String requestXml2 = XmlUtil.beanToXmlByJAXB(universalRecordRetrieveReqSoap);
        String s = galileoApi.universalRecordService(BusinessType.QUERY_PNR, universalRecordRetrieveReq.getUniversalRecordLocatorCode(), requestXml2);
        System.out.println(s);
    }

    @Test
    public void testCreatePNR() {
//        CreateReservationDto createReservationDto = CreateReservationDto.builder().build();
//        OTAAirBookRQ otaAirBookRQ = RequestBuilder.buildOTAAirBookRQ(createReservationDto);
//        String requestXml =  XmlUtil.beanToXmlByJAXB(otaAirBookRQ);

        String requestXml = "<OTA_AirBookRQ SegmentCheckInd=\"true\" PTCBindInd=\"true\">\n" +
                "    <POS>\n" +
                "        <Source PseudoCityCode=\"WUH161\" />\n" +
                "    </POS>\n" +
                "    <AirItinerary>\n" +
                "        <OriginDestinationOptions>\n" +
                "            <OriginDestinationOption>\n" +
                "                <FlightSegment RPH=\"1\" DepartureDateTime=\"2025-05-01T08:30:00\" ArrivalDateTime=\"2025-05-01T10:05:00\" CodeshareInd=\"true\" FlightNumber=\"2501\" NumberInParty=\"1\" Status=\"NN\" SegmentType=\"NORMAL\" InterSegment=\"false\">\n" +
                "                    <OperatingAirline Code=\"MU\" FlightNumber=\"2501\" />\n" +
                "                    <DepartureAirport LocationCode=\"WUH\" />\n" +
                "                    <ArrivalAirport LocationCode=\"SHA\" />\n" +
                "                    <MarketingAirline Code=\"MU\" />\n" +
                "                    <BookingClassAvail ResBookDesigCode=\"J\" />\n" +
                "                </FlightSegment>\n" +
                "                <FlightSegment RPH=\"2\" DepartureDateTime=\"2025-05-02T00:15:00\" ArrivalDateTime=\"2025-05-02T06:30:00\" CodeshareInd=\"true\" FlightNumber=\"553\" NumberInParty=\"1\" Status=\"NN\" SegmentType=\"NORMAL\" InterSegment=\"false\">\n" +
                "                    <OperatingAirline Code=\"MU\" FlightNumber=\"553\" />\n" +
                "                    <DepartureAirport LocationCode=\"PVG\" />\n" +
                "                    <ArrivalAirport LocationCode=\"CDG\" />\n" +
                "                    <MarketingAirline Code=\"MU\" />\n" +
                "                    <BookingClassAvail ResBookDesigCode=\"F\" />\n" +
                "                </FlightSegment>\n" +
                "            </OriginDestinationOption>\n" +
                "        </OriginDestinationOptions>\n" +
                "    </AirItinerary>\n" +
                "    <TravelerInfo>\n" +
                "        <AirTraveler Gender=\"MALE\" PassengerTypeCode=\"ADT\">\n" +
                "            <PersonName LanguageType=\"ZH\">\n" +
                "                <Surname>xintong/su</Surname>\n" +
                "            </PersonName>\n" +
                "            <Document DocType=\"NI\" DocID=\"350201199308194277\" />\n" +
                "            <TravelerRefNumber RPH=\"1\" />\n" +
                "            <FlightSegmentRPHs>\n" +
                "                <FlightSegmentRPH>1</FlightSegmentRPH>\n" +
                "                <FlightSegmentRPH>2</FlightSegmentRPH>\n" +
                "            </FlightSegmentRPHs>\n" +
                "            <Comment>HK</Comment>\n" +
                "        </AirTraveler>\n" +
                "        <SpecialReqDetails>\n" +
                "            <OtherServiceInformations>\n" +
                "                <OtherServiceInformation Code=\"OTHS\">\n" +
                "                    <Airline Code=\"MU\" />\n" +
                "                    <Text>CTCT13666666666</Text>\n" +
                "                    <TravelerRefNumber RPH=\"1\" />\n" +
                "                </OtherServiceInformation>\n" +
                "            </OtherServiceInformations>\n" +
                "        </SpecialReqDetails>\n" +
                "    </TravelerInfo>\n" +
                "    <TPA_Extensions>\n" +
                "        <ContactInfo>023-57651234</ContactInfo>\n" +
                "        <EnvelopType>KI</EnvelopType>\n" +
                "    </TPA_Extensions>\n" +
                "</OTA_AirBookRQ>";

        byte[] bytes = StrUtil.zip(requestXml);

        String result = ibeApi.send(BusinessType. CREATE_PNR, UUIDUtil.getUUID(), gdsConfig.getIbe().getCreatePnrUri(), bytes);

        System.out.println(result);
    }

    @Test
    public void searchFlight() throws JsonProcessingException {
        IBESegmentDto segmentDtoGo = IBESegmentDto.builder()
                .origin(Lists.newArrayList(IBESegmentDto.SegmentInfo.builder().name("PEK").type(IBELocationType.AIRPORT).build()))
                .destination(Lists.newArrayList(IBESegmentDto.SegmentInfo.builder().name("CDG").type(IBELocationType.AIRPORT).build()))
                .depDate(LocalDate.of(2025, 5, 1))
//                .departAfterTime(IBETimeDto.builder().hour(0).minutes(0).build())
//                .departBeforeTime(IBETimeDto.builder().hour(23).minutes(59).build())
                .build();
        IBESegmentDto segmentDtoBack = IBESegmentDto.builder()
                .origin(Lists.newArrayList(IBESegmentDto.SegmentInfo.builder().name("CDG").type(IBELocationType.AIRPORT).build()))
                .destination(Lists.newArrayList(IBESegmentDto.SegmentInfo.builder().name("PEK").type(IBELocationType.AIRPORT).build()))
                .depDate(LocalDate.of(2025, 5, 15))
//                .departAfterTime(IBETimeDto.builder().hour(0).minutes(0).build())
//                .departBeforeTime(IBETimeDto.builder().hour(23).minutes(59).build())
                .build();

        IBEAgencyDto agencyDto = IBEAgencyDto.builder()
                .pos("CNY")
                .accountCodes(Lists.newArrayList(IBEAgencyDto.AccountInfo.builder().carrier("MU").build(), IBEAgencyDto.AccountInfo.builder().carrier("CA").build()))
                .build();

        IBEPassengerDto adt1 = IBEPassengerDto.builder().ptc(Lists.newArrayList(PassengerType.ADT)).build();
        IBEPassengerDto cnn1 = IBEPassengerDto.builder().ptc(Lists.newArrayList(PassengerType.CNN)).birthDay(LocalDate.of(2020, 1, 1)).build();

        IBEPreferenceDto preferenceDto = IBEPreferenceDto.builder()
                .changeable(true)
                .refundable(true)
                .upgradable(true)
                .cabins(IBEPreferenceDto.CabinInfo.builder().codes(Lists.newArrayList(IBECarbinType.ECONOMY)).virtual(false).build())
                .downsell(true)
                .upsell(true)
                .build();

        IBEJourneyPreferenceDto journeyPreferenceDto = IBEJourneyPreferenceDto.builder()
//                .splitTicket(false)
//                .noInterline(false)
//                .fareTypes(Lists.newArrayList("PUBLIC", "PRIVATE"))
//                .includeBaggage(true)
//                .includeCommission(false)
//                .includeSurcharge(false)
//                .includePenalties(false)
                .includeDebugOutput(true)
                .includeIataTax(true)
                .includeYqyr(true)
                .searchSpeed(3)
//                .multiCabin(false)
//                .allowMultiCabinCombo(false)
                .detailedPricing(true)
//                .availability("CACHE_PLUS")
//                .sameCarrierFare(false)
                .build();

        IBESearchFlightDto searchFlightDto = IBESearchFlightDto.builder()
                .segments(Lists.newArrayList(segmentDtoGo, segmentDtoBack))
                .agencies(Lists.newArrayList(agencyDto))
                .passengers(Lists.newArrayList(adt1, cnn1))
                .preferences(preferenceDto)
                .journeyPreferences(journeyPreferenceDto)
                .build();

        byte[] bytes = StrUtil.beanToZipByteWithoutNullEmpty(searchFlightDto);

        String s = ibeApi.send(BusinessType.SEARCH_FLIGHT, UUIDUtil.getUUID(), gdsConfig.getIbe().getSearchFlightUri(), bytes);
        String uncompress = StrUtil.unZip(s);

        IBESearchFlightResultVo resultVo = objectMapper.readValue(uncompress, new TypeReference<IBESearchFlightResultVo>() {
        });
        System.out.println(objectMapper.writeValueAsString(resultVo));
    }


    public static void main(String[] args) throws IOException {
        String path = "C:\\Users\\dy123\\Desktop\\ibe-search-result.json";

        String content = new String(Files.readAllBytes(Paths.get(path)));

        ObjectMapper objectMapper = new ObjectMapper();
        objectMapper.registerModule(new JavaTimeModule());

        IBESearchFlightResultVo resultVo = objectMapper.readValue(content, new TypeReference<IBESearchFlightResultVo>() {
        });
        System.out.println(objectMapper.writeValueAsString(resultVo));
    }

    public static String readClasspathFile(String filePath) {
        ClassPathResource resource = new ClassPathResource(filePath);
        try (InputStream inputStream = resource.getInputStream()) {
            return IOUtils.toString(inputStream, StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }


    /**
     * 航班动态数据-查询
     */
    @Test
    public void am_flight() {
        String appid = "10373";
        String appsecurity = "68d891c6dcc08";

        TreeMap<String, String> treeMap = new TreeMap<>();
//        treeMap.put("appid", appid);
//        treeMap.put("date", "2025-12-26");
//        treeMap.put("fnum", "SC8088");
//        treeMap.put("depCode", "KIX");
//        treeMap.put("arrCode", "TNA");
                treeMap.put("appid", appid);
        treeMap.put("date", "2026-03-05");
        treeMap.put("fnum", "CA745");

        String param = treeMap.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue()).collect(Collectors.joining("&")) + appsecurity;
        String md5Param = DigestUtil.md5Hex(DigestUtil.md5Hex(param));
        System.out.println("[encrypt] before: " + param + ", after: " + md5Param);

        ForestQueryMap forestQueryMap = new ForestQueryMap();
        forestQueryMap.putAll(treeMap);
        System.out.println(JacksonUtil.toJsonString(forestQueryMap));
        HashMap result = Forest.get("https://api.133.cn/api/flight")
                .addAllQuery(forestQueryMap)
                .addQuery("token", md5Param)
                .execute(HashMap.class);
        System.out.println(result);
        String jss=JacksonUtil.toJsonString(result);
        JSONObject object=JSONObject.parseObject(jss);
        String data=object.getString("data");
        List<FlightListVo> list=JacksonUtil.toBeanList(data,FlightListVo.class);
        System.out.println(JacksonUtil.toJsonString(list));
    }

    /**
     * 航班动态数据-定制
     */
    @Test
    public void am_flightSubscribe() {
        String appid = "10373";
        String appsecurity = "68d891c6dcc08";

        List<FlightChange> flightChanges=Lists.newArrayList();
        FlightChange flightChange = FlightChange.builder()
                .fnum("SC8088")
                .depTime("2025-12-26")
                .build();
//        FlightChange flightChange2 = FlightChange.builder()
//                .fnum("CZ620")
//                .depTime("2025-10-18")
//                .build();
//        FlightChange flightChange3 = FlightChange.builder()
//                .fnum("CA751")
//                .depTime("2025-11-18")
//                .build();
//        FlightChange flightChange4 = FlightChange.builder()
//                .fnum("CZ619")
//                .depTime("2025-11-15")
//                .build();
//        FlightChange flightChange5 = FlightChange.builder()
//                .fnum("MU5619")
//                .depTime("2025-10-18")
//                .build();
        flightChanges.add(flightChange);
//        flightChanges.add(flightChange2);
//        flightChanges.add(flightChange3);
//        flightChanges.add(flightChange4);
//        flightChanges.add(flightChange5);
        for( FlightChange flight : flightChanges){
            TreeMap<String, String> treeMap = new TreeMap<>();
            treeMap.put("appid", appid);
            treeMap.put("depCode", "KIX");
            treeMap.put("arrCode", "TNA");
            treeMap.put("fnum", flight.getFnum());
            treeMap.put("date", flight.getDepTime());
            Random random = new Random(12345);
            treeMap.put("fid", flightChange.getFnum()+String.valueOf(random.nextInt()));

            String param = treeMap.entrySet().stream().map(entry -> entry.getKey() + "=" + entry.getValue()).collect(Collectors.joining("&")) + appsecurity;
            String md5Param = DigestUtil.md5Hex(DigestUtil.md5Hex(param));
            System.out.println("[encrypt] before: " + param + ", after: " + md5Param);

            ForestQueryMap forestQueryMap = new ForestQueryMap();
            forestQueryMap.putAll(treeMap);

            HashMap result = Forest.get("https://api.133.cn/api/flightSubscribe")
                    .addAllQuery(forestQueryMap)
                    .addQuery("token", md5Param)
                    .execute(HashMap.class);
            System.out.println(result);
//            System.out.println(JacksonUtil.toJsonString(result));
        }
//
//
//        Random random = new Random(12345); // 使用固定的种子值
//        System.out.println(String.valueOf(random.nextInt()));
//
//        String results="{\"msg\":\"请求成功\",\"data\":[{\"flightNo\":\"TV9877\",\"flightProperty\":\"0\",\"depCode\":\"CTU\",\"arrCode\":\"CGQ\",\"depLngLat\":\"103.9568|30.581134\",\"arrLngLat\":\"125.19834|43.902836\",\"depAirport\":\"成都双流\",\"arrAirport\":\"长春龙嘉\",\"depCountryCode\":\"CN\",\"arrCountryCode\":\"CN\",\"depCountryName\":\"China\",\"arrCountryName\":\"China\",\"depRegionName\":\"Asia\",\"arrRegionName\":\"Asia\",\"depCityName\":\"成都\",\"arrCityName\":\"长春\",\"localDate\":\"2026-03-05\",\"depPlanTime\":\"2018-10-23 05:50:00\",\"arrPlanTime\":\"2018-10-23 11:30:00\",\"depReadyTime\":\"\",\"arrReadyTime\":\"\",\"depActTime\":\"\",\"arrActTime\":\"\",\"flightState\":\"计划\",\"shareFlag\":\"0\",\"mainFlightNo\":\"\",\"airlineShare\":\"\",\"usualShare\":\"CA3961\",\"stopFlag\":\"1\",\"stopAirportCode\":\"TSN\",\"depTerminal\":\"T2\",\"arrTerminal\":\"T1\",\"depTimezone\":\"28800\",\"arrTimezone\":\"28800\",\"airlineCompany\":\"西藏航空公司\",\"airlineInterFlag\":\"0\",\"fillFlightNo\":\"\",\"flightCancelTime\":\"\",\"sections\":[{\"sectionType\":\"stop\",\"sectionAirportCode\":\"TSN\",\"sectionAirportName\":\"天津滨海\",\"sectionCityName\":\"天津\",\"sectionLngLat\":\"117.3559|39.128273\",\"sectionTimezone\":\"28800\",\"sectionFlightState\":\"\",\"sectionDepReadyTime\":\"2018-10-23 10:20:00\",\"sectionDepActTime\":\"2018-10-23 10:14:00\",\"sectionArrReadyTime\":\"2018-10-23 08:11:00\",\"sectionArrActTime\":\"2018-10-23 08:10:00\",\"sectionDepTerminal\":\"T2\",\"sectionArrTerminal\":\"T2\"}]},{\"flightNo\":\"TV9877\",\"flightProperty\":\"0\",\"depCode\":\"CTU\",\"arrCode\":\"TSN\",\"depLngLat\":\"103.9568|30.581134\",\"arrLngLat\":\"117.3559|39.128273\",\"depAirport\":\"成都双流\",\"arrAirport\":\"天津滨海\",\"depCountryCode\":\"CN\",\"arrCountryCode\":\"CN\",\"depCountryName\":\"China\",\"arrCountryName\":\"China\",\"depRegionName\":\"Asia\",\"arrRegionName\":\"Asia\",\"depCityName\":\"成都\",\"arrCityName\":\"天津\",\"localDate\":\"2026-03-05\",\"depPlanTime\":\"2018-10-23 05:50:00\",\"arrPlanTime\":\"2018-10-23 08:30:00\",\"depReadyTime\":\"\",\"arrReadyTime\":\"\",\"depActTime\":\"\",\"arrActTime\":\"\",\"flightState\":\"计划\",\"shareFlag\":\"0\",\"mainFlightNo\":\"\",\"airlineShare\":\"\",\"usualShare\":\"CA3961\",\"stopFlag\":\"0\",\"stopAirportCode\":\"\",\"depTerminal\":\"T2\",\"arrTerminal\":\"T2\",\"depTimezone\":\"28800\",\"arrTimezone\":\"28800\",\"airlineCompany\":\"西藏航空公司\",\"airlineInterFlag\":\"0\",\"fillFlightNo\":\"\",\"flightCancelTime\":\"\",\"sections\":[]},{\"flightNo\":\"TV9877\",\"flightProperty\":\"0\",\"depCode\":\"TSN\",\"arrCode\":\"CGQ\",\"depLngLat\":\"117.3559|39.128273\",\"arrLngLat\":\"125.19834|43.902836\",\"depAirport\":\"天津滨海\",\"arrAirport\":\"长春龙嘉\",\"depCountryCode\":\"CN\",\"arrCountryCode\":\"CN\",\"depCountryName\":\"China\",\"arrCountryName\":\"China\",\"depRegionName\":\"Asia\",\"arrRegionName\":\"Asia\",\"depCityName\":\"天津\",\"arrCityName\":\"长春\",\"localDate\":\"2026-03-05\",\"depPlanTime\":\"2018-10-23 09:50:00\",\"arrPlanTime\":\"2018-10-23 11:30:00\",\"depReadyTime\":\"\",\"arrReadyTime\":\"\",\"depActTime\":\"\",\"arrActTime\":\"\",\"flightState\":\"计划\",\"shareFlag\":\"0\",\"mainFlightNo\":\"\",\"airlineShare\":\"\",\"usualShare\":\"CA3961\",\"stopFlag\":\"0\",\"stopAirportCode\":\"\",\"depTerminal\":\"T2\",\"arrTerminal\":\"T1\",\"depTimezone\":\"28800\",\"arrTimezone\":\"28800\",\"airlineCompany\":\"西藏航空公司\",\"airlineInterFlag\":\"0\",\"fillFlightNo\":\"\",\"flightCancelTime\":\"\",\"sections\":[]}],\"status\":1000}\n";
//        String jss=JacksonUtil.toJsonString(results);
//        JSONObject object=JSONObject.parseObject(jss);
//        String data=object.getString("data");
//        List<FlightListVo> list=JacksonUtil.toBeanList(data,FlightListVo.class);
//        System.out.println( list);
    }
    /**
     * 获取详情
     */
    @Test
    public void eightYi_orderDetail() throws JsonProcessingException {
        String orderId = "ET22064903104124";
        Map<String, String> paramMap = new HashMap<String, String>() {{
            put("orderId", orderId);
        }};
        String params = objectMapper.writeValueAsString(paramMap);
        String sign = Md5Utils.hash(gdsConfig.getEightYi().getAccount() + gdsConfig.getEightYi().getPid() + gdsConfig.getEightYi().getGetOrderDetails() + params + gdsConfig.getEightYi().getKey());
        EightYiOrderDetailVo result = eightYiForestApi.getOrderDetail(gdsConfig.getEightYi().getGetOrderDetails(), gdsConfig.getEightYi().getAccount(), gdsConfig.getEightYi().getPid(),sign, orderId);
        System.out.println(JSONObject.toJSONString(result));
    }


    /**
     * 航程信息询价接口
     */
    @Test
    public void eightYi_getVoyagePolicyPrice() throws JsonProcessingException {
        VoyagePolicyPriceReq auditDto = VoyagePolicyPriceReq.builder()
                .adtType("101")
                .adtNum(1)
                .chdNum(1)
                .containForeign(false)
                .adtTicketNo("")
                .showAuditing(false).build();
        List<Voyage> voyageList=Lists.newArrayList(Voyage.builder().index("1")
                .carrier("CI").carrierName("中华航空公司").depCode("NRT").arrCode("TPE").flightNo("CI105")
                .cabin("N").cabinStatus("Y").depTime("2025-10-23").arrTime("2025-10-23")
                .depAirport("成田国际机场").arrAirport("广岛机场").depCity("东京").arrCity("台北").depTerminal("T3").arrTerminal("T2").baggages("").build());
        auditDto.setVoyageList(voyageList);
        String params = objectMapper.writeValueAsString(auditDto);
        System.out.println(params);
        System.out.println(gdsConfig.getEightYi().getAccount() + gdsConfig.getEightYi().getPid() + gdsConfig.getEightYi().getQueryVoyagePolicyPrice() + params + gdsConfig.getEightYi().getKey());
        String sign = Md5Utils.hash(gdsConfig.getEightYi().getAccount() + gdsConfig.getEightYi().getPid() + gdsConfig.getEightYi().getQueryVoyagePolicyPrice() + params + gdsConfig.getEightYi().getKey());
        System.out.println(sign);
        VoyagePolicyPriceDetailVo result = eightYiForestApi.getVoyagePolicyPrice(sign, auditDto);
        System.out.println(JSONObject.toJSONString(result));
    }

    /**
     * 航程信息下单接口
     * @throws JsonProcessingException
     */
//    @Test
//    public void eightYi_voyageCreateOrder() throws JsonProcessingException {
//        VoyageCreateOrderReq createOrderReq=VoyageCreateOrderReq.builder()
//                .policyId("2017030700055078")
//                .policySign("ac47ec812289ed55b43dc966558d96dd")
//                .rawId("TT17041300713171")
//                .contacter("zhangsan")
//                .mobile("13800000000")
//                .originalPNR("UTI9PO")
//                .build();
//        List<Passenger> passengerList=Lists.newArrayList(Passenger.builder().index("1").name("张三").title("MR").sex("M").psgType("1").
//                psgClass("101").nation("CHN").birthday("1961-08-01").certificate("123456789012345678").expireDate("2025-01-01").
//                ticketNo("123456789012345678").tel("13800000000").email("198000000@qq.com").issueCountry("中国").certificateType("身份证").build());
//        createOrderReq.setPassengerList(passengerList);
//        String params = objectMapper.writeValueAsString(createOrderReq);
//        System.out.println(params);
//        System.out.println(gdsConfig.getEightYi().getAccount() + gdsConfig.getEightYi().getPid() + gdsConfig.getEightYi().getVoyageCreateOrder() + params + gdsConfig.getEightYi().getKey());
//        String sign = Md5Utils.hash(gdsConfig.getEightYi().getAccount() + gdsConfig.getEightYi().getPid() + gdsConfig.getEightYi().getVoyageCreateOrder() + params + gdsConfig.getEightYi().getKey());
//        System.out.println(sign);
//        VoyageCreateOrderResp result = eightYiForestApi.voyageCreateOrder(gdsConfig.getEightYi().getVoyageCreateOrder(),
//                gdsConfig.getEightYi().getAccount(), gdsConfig.getEightYi().getPid(),sign, createOrderReq);
//        System.out.println(JSONObject.toJSONString(result));
//    }

    /**
     * 订单支付前检查接口
     */
    @Test
    public void eightYi_payBeforeCheck() throws JsonProcessingException {
        String orderId = "ET22064903104124";
        Map<String, String> paramMap = new HashMap<String, String>() {{
            put("orderId", orderId);
        }};
        String sign = Md5Utils.hash(gdsConfig.getEightYi().getAccount() + gdsConfig.getEightYi().getPid() + gdsConfig.getEightYi().getPayVerifyOrder() + objectMapper.writeValueAsString(paramMap) + gdsConfig.getEightYi().getKey());
        EightYiPayBeResp result = eightYiForestApi.payBeforeCheck(sign, orderId);
        System.out.println(JSONObject.toJSONString(result));
    }

    /**
     * 订单支付接口
     */
    @Test
    public void eightYi_pay() throws JsonProcessingException {
        EightYiPayReq payDto = EightYiPayReq.builder()
                .orderId("ET93146035204438")
                .payWay("3")
                .payType("2")
                .build();
        System.out.println(objectMapper.writeValueAsString(payDto));
        String sign = Md5Utils.hash(gdsConfig.getEightYi().getAccount() + gdsConfig.getEightYi().getPid() + gdsConfig.getEightYi().getPayOrder() + objectMapper.writeValueAsString(payDto) + gdsConfig.getEightYi().getKey());
        System.out.println(sign);
        EightYiPayResp result = eightYiForestApi.eightYiPay(sign, payDto);
        System.out.println(JSONObject.toJSONString(result));
    }

    /**
     * PNR导入询价接口
     */
    @Test
    public void eightYi_queryPnrPolicyPrice() throws JsonProcessingException {
        PnrPolicyPriceReq auditDto = PnrPolicyPriceReq.builder()
                .adtType("101")
                .pnrContent("1.SUZUKI/AKIKO MS KTETSC \n" +
                        "2.MU5079 T SA16MAY TAONRT HK1 1000 1355 E -- 2 \n" +
                        "3.WUH/T WUH/T 18164117051/WUHAN WAIGUO TECHNOLOGY CO.,LTD/DINGWEI \n" +
                        "4.TL/0800/16MAY/WUH161 \n" +
                        "5.SSR OTHS 1E KK1 MU5079TTAONRT16MAY26 TAONRT TAONRT \n" +
                        "6.SSR ADTK 1E BY WUH29OCT25/1355 OR CXL MU5079 T16MAY \n" +
                        "7.SSR DOCS MU HK1 P/JP/TT6482871/JP/22MAR64/F/09JUL34/SUZUKI/AKIKO/P1 \n" +
                        "8.OSI MU CTCT15607122230 \n" +
                        "9.OSI MU CTCEWIGUOTECH//OUTLOOK.COM \n" +
                        "10.RMK CA/PE8EZC \n" +
                        "11.WUH161")
                .showAuditing(false).build();
        String params = objectMapper.writeValueAsString(auditDto);
        System.out.println(params);
        System.out.println(gdsConfig.getEightYi().getAccount() + gdsConfig.getEightYi().getPid() + gdsConfig.getEightYi().getQueryPnrPolicyPrice() + params + gdsConfig.getEightYi().getKey());
        String sign = Md5Utils.hash(gdsConfig.getEightYi().getAccount() + gdsConfig.getEightYi().getPid() + gdsConfig.getEightYi().getQueryPnrPolicyPrice() + params + gdsConfig.getEightYi().getKey());
        System.out.println(sign);
        VoyagePolicyPriceDetailVo result = eightYiForestApi.queryPnrPolicyPrice(sign, auditDto);
        System.out.println(JSONObject.toJSONString(result));
    }

    /**
     *通过PNR信息及获取的运价信息在国际平台生成订单
     */
    @Test
    public void eightYi_createOrder() throws JsonProcessingException {
        CreateOrderReq auditDto = CreateOrderReq.builder()
                .policyId("2049434635940532")
                .policySign("8b0c504aa30a0edb4f24bd24be4eac89")
                .rawId("TT61634326778127")
                .contacter("zhangsan")
                .mobile("18986188370")
                .build();
        String params = objectMapper.writeValueAsString(auditDto);
        System.out.println(params);
        System.out.println(gdsConfig.getEightYi().getAccount() + gdsConfig.getEightYi().getPid() + gdsConfig.getEightYi().getCreateOrder() + params + gdsConfig.getEightYi().getKey());
        String sign = Md5Utils.hash(gdsConfig.getEightYi().getAccount() + gdsConfig.getEightYi().getPid() + gdsConfig.getEightYi().getCreateOrder() + params + gdsConfig.getEightYi().getKey());
        System.out.println(sign);
        VoyageCreateOrderResp result = eightYiForestApi.createOrder(sign, auditDto);
        System.out.println(JSONObject.toJSONString(result));
    }

    /**---------------------------huanyu出票开始-------------------------------*/
    @Test
    public void huanYu_queryPnrPolicyPrice() throws JsonProcessingException {
        String timestamp=DateUtil.getLocalDate();
        HuanYuPnrPolicyPriceReq priceReq= HuanYuPnrPolicyPriceReq.builder()
                .PnrText("1.GAO/JINGWEN KGFND7\n" +
                        "2. MU539 T TU23DEC PVGHND HK1 1455 1830 E T13\n" +
                        "3. MU748 Z TH01JAN KIXPVG HK1 1630 1815 E 1 T1\n" +
                        "4.WUH/T WUH/T 18164117051/WUHAN WAIGUO TECHNOLOGY CO.,LTD/DINGWEI\n" +
                        "5.13164698698\n" +
                        "6.TL/0943/31OCT/WUH161\n" +
                        "7.SSR OTHS 1E KK1 MU0748ZKIXPVG01JAN26 KIXPVG KIXPVG\n" +
                        "8.SSR OTHS 1E KK1 MU0539TPVGHND23DEC25 PVGHND PVGHND\n" +
                        "9.SSR FQTV MU HK1 PVGHND 539 T23DEC MU633013957101/P1\n" +
                        "10.SSR FQTV MU HK1 KIXPVG 748 Z01JAN MU633013957101/P1\n" +
                        "11.SSR ADTK 1E BY WUH29OCT25/0943 OR CXL MU539 T23DEC\n" +
                        "12.SSR DOCS MU HK1 P/CN/EC5526528/CN/22FEB96/F/08MAR28/GAO/JINGWEN/P1\n" +
                        "13.OSI MU CTCM13487167377/P1\n" +
                        "14.OSI MU CTCT13164698698\n" +
                        "15.RMK CA/PTGPBY\n" +
                        "16.WUH161").ChangePnrType("0").build();
        String params = objectMapper.writeValueAsString(priceReq);
        System.out.println(params);
        String sign = Md5Utils.hash(gdsConfig.getHuanYu().getPid() +params+ timestamp + gdsConfig.getHuanYu().getPidKey());
        HashMap<String, Object> requestParam = new HashMap<>();
        requestParam.put("Pid", gdsConfig.getHuanYu().getPid());
        requestParam.put("Timestamp", timestamp);
        requestParam.put("Sign", sign);
        requestParam.put("RequestBody", params);
        String newPa=objectMapper.writeValueAsString(requestParam);
        String result = HttpClientUtils.sendPostJson("http://47.108.255.47/Api/GJBuyerApi/Recommend", newPa);
        HuanYuPnrPolicyPriceResp results = JSONObject.parseObject(result, HuanYuPnrPolicyPriceResp.class);
        System.out.println(JSONObject.toJSONString(results));
    }
    /**
     * 创建订单
     * @throws JsonProcessingException
     */
//    @Test
//    public void huanYu_createOrder() throws JsonProcessingException {
//        HuanYuCreateOrderReq auditDto= HuanYuCreateOrderReq.builder()
//                .PolicyId("25061214050284901")
//                .SessionId("LH25102713181402801")
//                .Name("CAO/KAI")
//                .Phone("18164116030")
//                .TotalPrice(BigDecimal.valueOf(3294))
//                .build();
//        List<HuanYuPassenger> passengerList =Lists.newArrayList(
//                HuanYuPassenger.builder()
//                        .PassengerNo(1)
//                        .PassengerType(1)
//                        .Name("CAO/KAI")
//                        .Title("1")
//                        .Sex("M")
//                        .BirthDate("1991-11-07")
//                        .CredentialNo("EQ0144332")
//                        .CredentialType("P")
//                        .IssueCountry("CN")
//                        .Nationality("CN").ValidiDate("2035-06-25").Mobile("18164116030").build(),HuanYuPassenger.builder()
//                        .PassengerNo(2)
//                        .PassengerType(1)
//                        .Name("ZHOU/HONGXING")
//                        .Title("1")
//                        .Sex("M")
//                        .BirthDate("1988-03-01")
//                        .CredentialNo("EP6308952")
//                        .CredentialType("P")
//                        .IssueCountry("CN")
//                        .Nationality("CN").ValidiDate("2035-05-21").Mobile("15907128354").build()
//                ,HuanYuPassenger.builder()
//                        .PassengerNo(3)
//                        .PassengerType(1)
//                        .Name("ZHOU/QUANWEI")
//                        .Title("1")
//                        .Sex("M")
//                        .BirthDate("1989-04-28")
//                        .CredentialNo("EJ9761391")
//                        .CredentialType("P")
//                        .IssueCountry("CN")
//                        .Nationality("CN").ValidiDate("2033-02-19").Mobile("18771115253").build()
//        );
//        auditDto.setPassengerList(passengerList);
//        String params = objectMapper.writeValueAsString(auditDto);
//        System.out.println(params);
//        String timestamp=DateUtil.getLocalDate();
//        System.out.println(gdsConfig.getHuanYu().getPid() +params+ timestamp + gdsConfig.getHuanYu().getPidKey());
//        String sign = Md5Utils.hash(gdsConfig.getHuanYu().getPid() +params+ timestamp + gdsConfig.getHuanYu().getPidKey());
//        HashMap<String, Object> requestParam = new HashMap<>();
//        requestParam.put("Pid", gdsConfig.getHuanYu().getPid());
//        requestParam.put("Timestamp", timestamp);
//        requestParam.put("Sign", sign);
//        requestParam.put("RequestBody", params);
//        String newPa=objectMapper.writeValueAsString(requestParam);
//        String result = HttpClientUtils.sendPostJson("http://47.108.255.47/Api/GJBuyerApi/CreateOrder", newPa);
//        HuanYuResp results = JSONObject.parseObject(result, HuanYuResp.class);
//        System.out.println(JSONObject.toJSONString(results));
//    }
//
//    /**
//     * 订单支付
//     */
//    @Test
//    public void huanYu_pay() throws JsonProcessingException {
//        HuanYuPayReq auditDto= HuanYuPayReq.builder()
//                .OrderId("CH25102511082847001")
//                .build();
//        String params = objectMapper.writeValueAsString(auditDto);
//        System.out.println(params);
//        String timestamp=DateUtil.getLocalDate();
//        System.out.println(gdsConfig.getHuanYu().getPid() +params+ timestamp + gdsConfig.getHuanYu().getPidKey());
//        String sign = Md5Utils.hash(gdsConfig.getHuanYu().getPid() +params+ timestamp + gdsConfig.getHuanYu().getPidKey());
//        HashMap<String, Object> requestParam = new HashMap<>();
//        requestParam.put("Pid", gdsConfig.getHuanYu().getPid());
//        requestParam.put("Timestamp", timestamp);
//        requestParam.put("Sign", sign);
//        requestParam.put("RequestBody", params);
//        String newPa=objectMapper.writeValueAsString(requestParam);
//        String result = HttpClientUtils.sendPostJson("http://47.108.255.47/Api/GJBuyerApi/PayOrder", newPa);
//        HuanYuResp results = JSONObject.parseObject(result, HuanYuResp.class);
//        System.out.println(JSONObject.toJSONString(results));
//    }
}
