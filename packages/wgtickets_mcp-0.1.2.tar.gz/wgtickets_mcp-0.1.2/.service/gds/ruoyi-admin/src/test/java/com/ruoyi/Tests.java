package com.ruoyi;

import cn.hutool.core.io.FileUtil;
import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.module.vo.FczAirchangeFlightInfo;
import com.ruoyi.gds.module.vo.sabre.Booking;
import com.ruoyi.gds.module.vo.sabre.CreateBookingResponse;
import com.ruoyi.gds.module.vo.sabre.FulfillTicketsResponse;
import com.ruoyi.gds.module.vo.sabre.SearchFlightRsp;
import com.ruoyi.gds.schema.sabre.rsp.SoapEnvelope;
import com.ruoyi.gds.utils.XmlUtil;
import org.junit.Test;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Tests {

    @Test
    public void sabre_parse_search_flight() {
        String response = FileUtil.readString("/Users/huqiquan/Desktop/flight.json", StandardCharsets.UTF_8);
        SearchFlightRsp searchFlightRsp = JacksonUtil.toBean(response, SearchFlightRsp.class);
        System.out.println(JacksonUtil.toJsonString(searchFlightRsp));
    }

    @Test
    public void sabre_parse_create_pnr() {
        String response = FileUtil.readString("C:\\Users\\fly\\Desktop\\create-pnr.json", StandardCharsets.UTF_8);
        CreateBookingResponse createBookingResponse = JacksonUtil.toBean(response, CreateBookingResponse.class);
        System.out.println(JacksonUtil.toJsonString(createBookingResponse));
    }

    @Test
    public void sabre_parse_query_pnr() {
        String response = FileUtil.readString("C:\\Users\\fly\\Desktop\\query-pnr.json", StandardCharsets.UTF_8);
        Booking booking = JacksonUtil.toBean(response, Booking.class);
        System.out.println(JacksonUtil.toJsonString(booking));
    }

    @Test
    public void sabre_parse_issue_response() {
        String response = FileUtil.readString("/Users/huqiquan/Desktop/issue-response.json", StandardCharsets.UTF_8);
        FulfillTicketsResponse ticketsResponse = JacksonUtil.toBean(response, FulfillTicketsResponse.class);
        System.out.println(JacksonUtil.toJsonString(ticketsResponse));
    }

    @Test
    public void sabre_parse_get_reservation_response() {
        String response = FileUtil.readString("/Users/huqiquan/Desktop/GetReservationRS.xml", StandardCharsets.UTF_8);
        SoapEnvelope resultEnvelope = XmlUtil.xmlToBeanByJAXB(response, SoapEnvelope.class);
        System.out.println(JacksonUtil.toJsonString(resultEnvelope));
    }

    @Test
    public void pnr_txt() {
        String content = FileUtil.readString("/Users/huqiquan/Desktop/pnr.txt", StandardCharsets.UTF_8);
        if (StringUtils.isBlank(content)) throw new RuntimeException("文件内容为空");
        List<String> pnrs = Arrays.stream(content.split("\\n")).map(String::trim).filter(StringUtils::isNotBlank).collect(Collectors.toList());
        System.out.println(JacksonUtil.toJsonString(pnrs));
    }

    @Test
    public void fcz_query_flight_result() {
        String result = FileUtil.readString("/Users/huqiquan/Desktop/fcz.json", StandardCharsets.UTF_8);
        List<FczAirchangeFlightInfo> fczAirchangeFlightInfos = JacksonUtil.toBeanList(result, FczAirchangeFlightInfo.class);
        System.out.println(fczAirchangeFlightInfos);
    }


}
