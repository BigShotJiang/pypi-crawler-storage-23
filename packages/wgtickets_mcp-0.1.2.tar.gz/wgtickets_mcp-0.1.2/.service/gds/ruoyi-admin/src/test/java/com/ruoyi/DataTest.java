package com.ruoyi;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import cn.hutool.core.io.FileUtil;
import com.alibaba.excel.EasyExcel;
import com.alibaba.excel.annotation.ExcelProperty;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.fileupload.easyexcel.CustomCellWriteHandler;
import com.ruoyi.gds.config.GDSConfig;
import com.ruoyi.gds.enums.BusinessType;
import com.ruoyi.gds.forest.IBEApi;
import com.ruoyi.gds.module.dto.ibe.RequestBuilder;
import com.ruoyi.gds.schema.ibe.*;
import com.ruoyi.gds.utils.StrUtil;
import com.ruoyi.gds.utils.XmlUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.redisson.api.RLock;
import org.redisson.api.RedissonClient;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

@Slf4j
@SpringBootTest
@RunWith(SpringRunner.class)
public class DataTest {

    @Autowired
    private IBEApi ibeApi;
    @Autowired
    private GDSConfig gdsConfig;
    @Autowired
    private RedissonClient redissonClient;

    @Test
    public void test() {
        // todo IBE使用生产环境配置
        List<PnrTicketNumber> pnrTicketNumbers = readData();

        List<PnrInfo> pnrInfos = Lists.newArrayList();
        int total = pnrTicketNumbers.size();
        for (PnrTicketNumber pnrTicketNumber : pnrTicketNumbers) {
            try {
                String progressing = (pnrTicketNumbers.indexOf(pnrTicketNumber) + 1) + " / " + total;
                List<PnrInfo> pnrInfoList = getTicketNumberForOpenSegment(pnrTicketNumber.getPnr(), pnrTicketNumber.getTicketNumbers(), progressing);
                if (CollectionUtil.isNotEmpty(pnrInfoList)) pnrInfos.addAll(pnrInfoList);
            } catch (Exception e) {
                if (CollectionUtil.isNotEmpty(pnrTicketNumber.getTicketNumbers())) {
                    List<PnrInfo> pnrInfoList = pnrTicketNumber.getTicketNumbers().stream()
                            .map(ticketNumber -> PnrInfo.builder().pnr(pnrTicketNumber.getPnr()).ticketNumber(ticketNumber).remark("提取票信息失败: " + e.getMessage()).build())
                            .collect(Collectors.toList());
                    pnrInfos.addAll(pnrInfoList);
                } else {
                    PnrInfo pnrInfo = PnrInfo.builder().pnr(pnrTicketNumber.getPnr()).remark("提取票信息失败: " + e.getMessage()).build();
                    pnrInfos.add(pnrInfo);
                }
            }
        }

        // pnrInfos.sort(Comparator.comparing(PnrInfo::getPnr));

        String now = LocalDateTime.now().format(DateTimeFormatter.ofPattern(DatePattern.PURE_DATETIME_PATTERN));
        // 文件内容格式如下：
        // HN1E23/784-5500111512
        // JNZ6RY/784-5500111726
        // HE3M8Z/784-5500112997
        // HE3M8Z/784-5500112998
        // HR25GG/784-5500116740
        String fileName = "/Users/huqiquan/Desktop/PNR扫描/OTA-Open票号-" + now + ".xlsx";
        EasyExcel.write(fileName, PnrInfo.class).registerWriteHandler(new CustomCellWriteHandler()).sheet("票信息").doWrite(pnrInfos);
    }

    private List<PnrTicketNumber> readData() {
        String content = FileUtil.readString("/Users/huqiquan/Desktop/PNR扫描/pnr.txt", StandardCharsets.UTF_8);
        if (StringUtils.isBlank(content)) throw new RuntimeException("文件内容为空");

        return Arrays.stream(content.split("\\n"))
                .map(String::trim)
                .filter(StringUtils::isNotBlank)
                .map(line -> Arrays.stream(line.split("/")).filter(StringUtils::isNotBlank).collect(Collectors.toList()))
                .filter(CollectionUtil::isNotEmpty)
                .map(list -> {
                    if (list.size() == 1) {
                        return PnrTicketNumber.builder().pnr(list.get(0)).build();
                    } else {
                        List<String> ticketNumbers = list.subList(1, list.size()).stream().distinct().collect(Collectors.toList());
                        return PnrTicketNumber.builder().pnr(list.get(0)).ticketNumbers(ticketNumbers).build();
                    }
                })
                .collect(Collectors.toList());

        /*return ticketNumberList.stream().collect(Collectors.groupingBy(PnrTicketNumber::getPnr))
                .entrySet().stream().collect(Collectors.toMap(Map.Entry::getKey, entry -> entry.getValue().stream().map(PnrTicketNumber::getTicketNumbers).collect(HashSet<String>::new, Set::addAll, Set::addAll)))
                .entrySet().stream().map(entry -> PnrTicketNumber.builder().pnr(entry.getKey()).ticketNumbers(Lists.newArrayList(entry.getValue())).build())
                .collect(Collectors.toList());*/
    }

    private List<PnrInfo> getTicketNumberForOpenSegment(String pnr, List<String> ticketNumbers, String progressing) {
        /*try {
            Thread.sleep(1100);
        } catch (InterruptedException e) {
            log.error("【{}】线程阻塞异常", pnr, e);
            return Lists.newArrayList();
        }*/

        TESAirTicketRetRQ tesAirTicketRetRQ = RequestBuilder.buildTESAirTicketRetRQ(pnr, ticketNumbers);
        String requestXml = XmlUtil.beanToXmlByJAXB(tesAirTicketRetRQ);
        log.info("【{}】【{}】【请求】{}", pnr, progressing, requestXml);
        byte[] bytes = StrUtil.zip(requestXml);
        String responseXml = sendRequestWithLock(BusinessType.QUERY_PNR, pnr, gdsConfig.getIbe().getQueryIssuedPnrUri(), bytes);
        log.info("【{}】【{}】【响应】{}", pnr, progressing, responseXml);
        TESAirTicketRetRS tesAirTicketRetRS = XmlUtil.xmlToBeanByJAXB(responseXml, TESAirTicketRetRS.class);

        String errorMsg = Optional.ofNullable(tesAirTicketRetRS).map(TESAirTicketRetRS::getErrorMsg).orElse(null);
        if (StringUtils.isNotBlank(errorMsg)) {
            if (CollectionUtil.isNotEmpty(ticketNumbers)) {
                return ticketNumbers.stream()
                        .map(ticketNumber -> PnrInfo.builder().pnr(pnr).ticketNumber(ticketNumber).remark(errorMsg).build())
                        .collect(Collectors.toList());
            } else {
                PnrInfo pnrInfo = PnrInfo.builder().pnr(pnr).remark(errorMsg).build();
                return Lists.newArrayList(pnrInfo);
            }
        }

        return Optional.ofNullable(tesAirTicketRetRS)
                .map(TESAirTicketRetRS::getAirTicketRet)
                .map(airTicketRets -> airTicketRets.stream()
                        .map(airTicketRet -> {
                            String ticketStatus = airTicketRet.getFlightSegmentsNoNS()
                                    .stream().map(FlightSegmentsNoNS::getFlightSegment).collect(ArrayList<FlightSegmentNoNS>::new, List::addAll, List::addAll)
                                    .stream().map(FlightSegmentNoNS::getTicketStatus)
                                    .collect(Collectors.joining(" | "));
                            long openSegmentCount = airTicketRet.getFlightSegmentsNoNS()
                                    .stream().map(FlightSegmentsNoNS::getFlightSegment).collect(ArrayList<FlightSegmentNoNS>::new, List::addAll, List::addAll)
                                    .stream().filter(flightSegmentNoNS -> StringUtils.isNotBlank(flightSegmentNoNS.getTicketStatus()) && "OPEN FOR USE".equalsIgnoreCase(flightSegmentNoNS.getTicketStatus()))
                                    .count();
                            String ticketNumber = Optional.ofNullable(airTicketRet.getTicketing())
                                    .map(Ticketing::getTicketItemInfo)
                                    .map(TicketItemInfo::getTicketNumber)
                                    .orElse(null);
                            String open = openSegmentCount > 0 ? "是" : "否";
                            return PnrInfo.builder().pnr(pnr).ticketNumber(ticketNumber).ticketStatus(ticketStatus).open(open).build();
                        })
                        .filter(Objects::nonNull)
                        .collect(Collectors.toList()))
                .orElse(Lists.newArrayList());
    }

    private String sendRequestWithLock(BusinessType businessType, String businessCode, String url, byte[] compressedBody) {
        // 获取锁对象
        RLock lock = redissonClient.getLock("ibeUrlLock:" + url);

        try {
            // 尝试获取锁，等待3000ms，锁定5秒
            boolean locked = lock.tryLock(3000, 5, TimeUnit.SECONDS);
            if (!locked) throw new ServiceException("访问频率限制，请稍后重试");

            try {
                long s = System.currentTimeMillis();
                String result = ibeApi.send(businessType, businessCode, url, compressedBody);
                long difference = System.currentTimeMillis() - s;
                if (difference < 1200) Thread.sleep(1200 - difference);
                return result;
            } catch (Exception e) {
                // 恢复中断状态
                // Thread.currentThread().interrupt();
                log.error("[IBE] Url: {}, 请求失败.", url, e);
                return null;
            } finally {
                // 安全释放：检查当前线程是否持有锁
                if (lock.isHeldByCurrentThread()) lock.unlock();
            }
        } catch (Exception e) {
            log.error("[IBE] Url: {}, 获取锁失败.", url, e);
            throw new ServiceException("获取锁失败");
        }
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PnrTicketNumber implements Serializable {
        private static final long serialVersionUID = 1L;

        private String pnr;

        private List<String> ticketNumbers;

    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PnrInfo implements Serializable {
        private static final long serialVersionUID = 1L;

        @ExcelProperty(value = "PNR")
        private String pnr;

        @ExcelProperty(value = "票号")
        private String ticketNumber;

        @ExcelProperty(value = "OPEN")
        private String open;

        @ExcelProperty(value = "票航段状态")
        private String ticketStatus;

        @ExcelProperty(value = "备注")
        private String remark;
    }

}
