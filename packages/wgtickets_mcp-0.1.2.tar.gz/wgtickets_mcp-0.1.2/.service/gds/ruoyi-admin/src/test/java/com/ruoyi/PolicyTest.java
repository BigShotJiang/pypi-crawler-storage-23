package com.ruoyi;

import com.ruoyi.common.core.redis.RedisCache;
import com.ruoyi.common.enums.SystemType;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.policy.constant.RedisKey;
import com.ruoyi.policy.enums.PolicyEffectiveStatus;
import com.ruoyi.policy.matcher.module.vo.PolicyVo;
import com.ruoyi.policy.service.IPolicyService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@SpringBootTest
@RunWith(SpringRunner.class)
public class PolicyTest {

    @Autowired
    private RedisCache redisCache;
    @Autowired
    private IPolicyService policyService;

    @Test
    public void policy_cache() {
        SystemType system = SystemType.OTA;
        PolicyEffectiveStatus effectiveStatus = PolicyEffectiveStatus.EFFECTIVE;
        Long policyPackageId = 23L;
        LocalDate today = LocalDate.now();

        List<PolicyVo> cachePolicyList = redisCache.getCacheList(RedisKey.POLICY);
        List<PolicyVo> cachePolicies = Optional.ofNullable(cachePolicyList)
                .map(policyList -> policyList.stream()
                        .filter(policy -> Objects.equals(policy.getPolicyPackgeId(), policyPackageId))
                        .filter(policy -> "OBXST5KT".equalsIgnoreCase(policy.getCode()) || "DY1CQH32".equalsIgnoreCase(policy.getCode()))
                        .filter(policy -> {
                            boolean deptMatched = Objects.isNull(system) || (StringUtils.isNotBlank(policy.getDept()) && policy.getDept().contains(system.getCode()));

                            boolean dateMatched = true;
                            if (Objects.nonNull(effectiveStatus)) {
                                switch (effectiveStatus) {
                                    case EFFECTIVE:
                                        dateMatched = !today.isAfter(policy.getNextUpdateTime());
                                        break;
                                    case EXPIRE:
                                        dateMatched = today.isBefore(policy.getNextUpdateTime());
                                        break;
                                    default:
                                        break;
                                }
                            }

                            return deptMatched && dateMatched;
                        })
                        .collect(Collectors.toList()))
                .orElse(Lists.newArrayList());

        System.out.println("");
    }

    @Test
    public void publish_policy() {
        Map<Long, List<PolicyVo>> policyPackageMap = policyService.selectPolicyListByPackageIdsNew(null);
        System.out.println(policyPackageMap);
    }

}
