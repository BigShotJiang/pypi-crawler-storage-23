package com.ruoyi.channel.controller;

import com.alibaba.excel.EasyExcel;
import com.ruoyi.channel.easyexcel.UploadChannelListener;
import com.ruoyi.channel.module.domain.Channel;
import com.ruoyi.channel.module.vo.ChannelUploadVo;
import com.ruoyi.channel.service.IChannelService;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Objects;

/**
 * 渠道Controller
 * 
 * @author ruoyi
 * @date 2025-07-15
 */
@RestController
@RequestMapping("/channel")
public class ChannelController extends BaseController
{
    @Autowired
    private IChannelService channelService;

    /**
     * 查询渠道列表
     */
//    @PreAuthorize("@ss.hasPermi('system:channel:list')")
    @GetMapping("/list")
    public TableDataInfo list(Channel channel)
    {
        startPage();
        List<Channel> list = channelService.selectChannelList(channel);
        return getDataTable(list);
    }

    /**
     * 导出渠道列表
     */
//    @PreAuthorize("@ss.hasPermi('system:channel:export')")
    @Log(title = "渠道", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, Channel channel)
    {
        List<Channel> list = channelService.selectChannelList(channel);
        ExcelUtil<Channel> util = new ExcelUtil<Channel>(Channel.class);
        util.exportExcel(response, list, "渠道数据");
    }

    /**
     * 获取渠道详细信息
     */
//    @PreAuthorize("@ss.hasPermi('system:channel:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(channelService.selectChannelById(id));
    }

    /**
     * 新增渠道
     */
//    @PreAuthorize("@ss.hasPermi('system:channel:add')")
//    @Log(title = "渠道", businessType = BusinessType.INSERT)
    @PostMapping(value = "/add")
    public AjaxResult add(@RequestBody Channel channel)
    {
        if (StringUtils.isBlank(channel.getName())) {
            throw new ServiceException("渠道名称为空", HttpStatus.BAD_REQUEST);
        }
        if (StringUtils.isBlank(channel.getChannelCode())) {
            throw new ServiceException("渠道编码为空", HttpStatus.BAD_REQUEST);
        }
        Long channelId = channelService.insertChannel(channel);
        return AjaxResult.success(channelId);
    }

    /**
     * 修改渠道
     */
//    @PreAuthorize("@ss.hasPermi('system:channel:edit')")
//    @Log(title = "渠道", businessType = BusinessType.UPDATE)
    @PostMapping(value = "/update")
    public AjaxResult edit(@RequestBody Channel channel)
    {
        return toAjax(channelService.updateChannel(channel));
    }

    /**
     * 删除渠道
     */
//    @PreAuthorize("@ss.hasPermi('system:channel:remove')")
//    @Log(title = "渠道", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(channelService.deleteChannelByIds(ids, SecurityUtils.getUserId()));
    }

    /**
     * 上传渠道
     * @param file
     * @return
     */
    @PostMapping(value = "/upload")
    public AjaxResult upload(@RequestParam("file") MultipartFile file) {
        if (Objects.isNull(file) || file.isEmpty()) {
            return AjaxResult.error(HttpStatus.BAD_REQUEST, "文件内容为空");
        }

        try {
            EasyExcel.read(file.getInputStream(), ChannelUploadVo.class, new UploadChannelListener(channelService)).doReadAll();
            return AjaxResult.success();
        } catch (Exception e) {
            return AjaxResult.error(HttpStatus.ERROR, "系统错误");
        }
    }
}
