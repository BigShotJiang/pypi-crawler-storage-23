package com.ruoyi.channel.service;


import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.channel.module.domain.Channel;

import java.util.List;

/**
 * 渠道Service接口
 * 
 * @author ruoyi
 * @date 2025-07-15
 */
public interface IChannelService extends IService<Channel>
{
    /**
     * 查询渠道
     * 
     * @param id 渠道主键
     * @return 渠道
     */
    public Channel selectChannelById(Long id);

    /**
     * 查询渠道列表
     * 
     * @param channel 渠道
     * @return 渠道集合
     */
    public List<Channel> selectChannelList(Channel channel);

    /**
     * 新增渠道
     * 
     * @param channel 渠道
     * @return 结果
     */
    public Long insertChannel(Channel channel);

    /**
     * 修改渠道
     * 
     * @param channel 渠道
     * @return 结果
     */
    public int updateChannel(Channel channel);

    /**
     * 批量删除渠道
     * 
     * @param ids 需要删除的渠道主键集合
     * @return 结果
     */
    public int deleteChannelByIds(Long[] ids, Long userId);

    /**
     * 删除渠道信息
     * 
     * @param id 渠道主键
     * @return 结果
     */
    public int deleteChannelById(Long id, Long userId);
}
