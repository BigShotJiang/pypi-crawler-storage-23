package com.ruoyi.channel.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum ChannelBusinessType {

    TICKET(0, "机票"),
    NUCLEIC_ACID(1, "核酸"),
    HOTEL(2, "酒店"),
    CAR(3, "订车"),
    X_RAY(4, "X光"),
    OTHER(5, "其它"),
    BAGGAGE(6, "加行李"),
    CABIN_UPGRAD(7, "升舱"),
    SEAT(8, "选座"),
    VISA(9, "签证"),
    ADMISSION_FEE(10, "门票");

    @JsonValue
    private final Integer code;

    private final String desc;

    ChannelBusinessType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static ChannelBusinessType fromCode(Integer code) {
        return Arrays.stream(ChannelBusinessType.values())
                .filter(item -> Objects.nonNull(code) && Objects.equals(item.code, code))
                .findFirst()
                .orElse(null);
    }

    public static ChannelBusinessType fromDesc(String desc) {
        return Arrays.stream(ChannelBusinessType.values())
                .filter(item -> StringUtils.isNotBlank(desc) && desc.equalsIgnoreCase(item.desc))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
