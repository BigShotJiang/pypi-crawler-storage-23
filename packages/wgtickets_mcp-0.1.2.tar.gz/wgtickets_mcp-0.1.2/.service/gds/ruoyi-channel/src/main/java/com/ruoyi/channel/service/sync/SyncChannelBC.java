package com.ruoyi.channel.service.sync;

import com.ruoyi.channel.module.domain.Channel;
import com.ruoyi.common.enums.SystemType;

import java.util.List;

public abstract class SyncChannelBC {

    public abstract SystemType getSystemType();

    public abstract String saveOrUpdate(Channel channel);

    public abstract Boolean remove(List<String> channelCodes);

}
