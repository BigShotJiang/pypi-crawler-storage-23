package com.ruoyi.channel.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum YesNoType {

    NO(0, "否", false),
    YES(1, "是", true);

    @JsonValue
    private final Integer code;

    private final String desc;

    private final boolean flag;

    YesNoType(Integer code, String desc, boolean flag) {
        this.code = code;
        this.desc = desc;
        this.flag = flag;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static YesNoType fromCode(Integer code) {
        return Arrays.stream(YesNoType.values())
                .filter(item -> Objects.nonNull(code) && Objects.equals(item.code, code))
                .findFirst()
                .orElse(null);
    }

    public static YesNoType fromDesc(String desc) {
        return Arrays.stream(YesNoType.values())
                .filter(item -> StringUtils.isNotBlank(desc) && desc.equalsIgnoreCase(item.desc))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
