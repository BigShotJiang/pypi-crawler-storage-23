package com.ruoyi.channel.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum ChannelPaymentType {

    BILL(0, "账单付款"),
    IMMEDIATE(1, "即时付款"),
    ADVANCE(2, "预付款");

    @JsonValue
    private final Integer code;

    private final String desc;

    ChannelPaymentType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static ChannelPaymentType fromCode(Integer code) {
        return Arrays.stream(ChannelPaymentType.values())
                .filter(item -> Objects.nonNull(code) && Objects.equals(item.code, code))
                .findFirst()
                .orElse(null);
    }

    public static ChannelPaymentType fromDesc(String desc) {
        return Arrays.stream(ChannelPaymentType.values())
                .filter(item -> StringUtils.isNotBlank(desc) && desc.equalsIgnoreCase(item.desc))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
