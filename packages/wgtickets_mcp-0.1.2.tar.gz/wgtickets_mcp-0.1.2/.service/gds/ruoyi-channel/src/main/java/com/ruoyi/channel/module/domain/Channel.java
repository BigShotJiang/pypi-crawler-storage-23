package com.ruoyi.channel.module.domain;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 渠道对象 channel
 * 
 * @author ruoyi
 * @date 2025-07-15
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Channel implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 一级类目 */
    @Excel(name = "一级类目")
    private String firstCategory;

    /** 二级类目 */
    @Excel(name = "二级类目")
    private String secondCategory;

    /** 三级类目 */
    @Excel(name = "三级类目")
    private String thirdCategory;

    /** 适用部门，多个时用逗号拼接(OTA，TMC) */
    @Excel(name = "适用部门，多个时用逗号拼接(OTA，TMC)")
    private String dept;

    /** 渠道名称 */
    @Excel(name = "渠道名称")
    private String name;

    /** 渠道编码 */
    @Excel(name = "渠道编码")
    private String channelCode;

    /** GDS(GALILEO：伽利略，SABRE：塞班，TYO100：TYO100，WUH161：WUH161，HUAN_YU：外采，B2T：B2T，B2B：B2B，其他：其他，黑屏：黑屏) */
    @Excel(name = "GDS(GALILEO：伽利略，SABRE：塞班，TYO100：TYO100，WUH161：WUH161，HUAN_YU：外采，B2T：B2T，B2B：B2B，其他：其他，黑屏：黑屏)")
    private String gds;

    /** 开票地类型(1：三方网站，2：国际免票，3：渠道开票，4：国内免票，5：张成渠道，6：歪裹国内，7：附加产品) */
    @Excel(name = "开票地类型(1：三方网站，2：国际免票，3：渠道开票，4：国内免票，5：张成渠道，6：歪裹国内，7：附加产品)")
    private Integer issuePlaceType;

    /** 出票地 */
    @Excel(name = "出票地")
    private String issuePlace;

    /** 币种(CNY，JPY) */
    @Excel(name = "币种(CNY，JPY)")
    private String currency;

    /** 开票类型(OTA称：渠道类型。1：境内自开，2：境外自开，3：非自开) */
    @Excel(name = "开票类型(OTA称：渠道类型。1：境内自开，2：境外自开，3：非自开)")
    private Integer issueType;

    /** 类型(0：机票，1：核酸，2：酒店，3：订车，4：X光，5：其它，6：加行李：7：升舱，8：选座，9：签证，10：门票) */
    @Excel(name = "类型(0：机票，1：核酸，2：酒店，3：订车，4：X光，5：其它，6：加行李：7：升舱，8：选座，9：签证，10：门票)")
    private Integer type;

    /** 结算方式(0：账单付款，1：即时付款，2：预付款) */
    @Excel(name = "结算方式(0：账单付款，1：即时付款，2：预付款)")
    private Integer paymentType;

    /** 是否有返金(0：无，1：有) */
    @Excel(name = "是否有返金(0：无，1：有)")
    private Boolean hasRebate;

    /** 是否有株主割引券(0：无，1：有) */
    @Excel(name = "是否有株主割引券(0：无，1：有)")
    private Boolean hasOnceCard;

    /** 开票人 */
    @Excel(name = "开票人")
    private String ticketUser;

    /** 联系电话 */
    @Excel(name = "联系电话")
    private String contactMobile;

    /** 联系人 */
    @Excel(name = "联系人")
    private String contactUser;

    /** 余额 */
    @Excel(name = "余额")
    private BigDecimal balance;

    /** 显示排序 */
    @Excel(name = "显示排序")
    private Integer seq;

    /** 是否已停用(0：未停用，1：已停用) */
    @Excel(name = "是否已停用(0：未停用，1：已停用)")
    private Boolean stoped;

    /** 备注 */
    @Excel(name = "备注")
    private String remark;

    /** 创建者 */
    private Long createBy;

    /** 创建时间 */
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTime;

    /** 更新者 */
    private Long updateBy;

    /** 更新时间 */
    @Excel(name = "更新时间", width = 30, dateFormat = "yyyy-MM-dd")
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime updateTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;

}
