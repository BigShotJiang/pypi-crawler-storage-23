package com.ruoyi.channel.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum ChannelGdsType {

    GALILEO(1, "GALILEO", "1G", "伽利略"),
    SABRE(2, "SABRE", "1S", "塞班"),
    TYO100(3, "TYO100", "TYO100", "TYO100"),
    WUH161(4, "WUH161", "1E", "WUH161"),
    HUAN_YU(5, "HUAN_YU", "HUAN_YU", "外采"),
    B2T(6, "B2T", "B2T", "B2T"),
    B2B(7, "B2B", "B2B", "B2B"),
    OTHER(8, "OTHER", "OTHER", "其他"),
    BLACK_SCREEN(9, "BLACK_SCREEN", "BLACK_SCREEN", "黑屏");

    private final Integer num;

    @JsonValue
    private final String code;

    private final String symbol;

    private final String desc;

    ChannelGdsType(Integer num, String code, String symbol, String desc) {
        this.num = num;
        this.code = code;
        this.symbol = symbol;
        this.desc = desc;
    }

    public static ChannelGdsType fromNum(Integer num) {
        if (Objects.isNull(num)) return null;
        return Arrays.stream(ChannelGdsType.values()).filter(item -> num.equals(item.num)).findFirst().orElse(null);
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static ChannelGdsType fromCode(String code) {
        return Arrays.stream(ChannelGdsType.values())
                .filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.code))
                .findFirst()
                .orElse(null);
    }

    public static ChannelGdsType fromSymbol(String symbol) {
        if (StringUtils.isBlank(symbol)) return null;
        return Arrays.stream(ChannelGdsType.values()).filter(item -> symbol.equalsIgnoreCase(item.symbol)).findFirst().orElse(null);
    }

    public static ChannelGdsType fromDesc(String desc) {
        return Arrays.stream(ChannelGdsType.values())
                .filter(item -> StringUtils.isNotBlank(desc) && desc.equalsIgnoreCase(item.desc))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }
    
}
