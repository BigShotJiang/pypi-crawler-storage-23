package com.ruoyi.channel.mapper;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.channel.module.domain.Channel;
import org.apache.ibatis.annotations.Param;

/**
 * 渠道Mapper接口
 * 
 * @author ruoyi
 * @date 2025-07-15
 */
public interface ChannelMapper extends BaseMapper<Channel>
{
    /**
     * 查询渠道
     * 
     * @param id 渠道主键
     * @return 渠道
     */
    public Channel selectChannelById(Long id);

    /**
     * 查询渠道列表
     * 
     * @param channel 渠道
     * @return 渠道集合
     */
    public List<Channel> selectChannelList(Channel channel);

    /**
     * 新增渠道
     * 
     * @param channel 渠道
     * @return 结果
     */
    public int insertChannel(Channel channel);

    /**
     * 修改渠道
     * 
     * @param channel 渠道
     * @return 结果
     */
    public int updateChannel(Channel channel);

    /**
     * 删除渠道
     * 
     * @param id 渠道主键
     * @return 结果
     */
    public int deleteChannelById(@Param("id") Long id, @Param("userId") Long userId);

    /**
     * 批量删除渠道
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteChannelByIds(@Param("ids") Long[] ids, @Param("userId") Long userId);
}
