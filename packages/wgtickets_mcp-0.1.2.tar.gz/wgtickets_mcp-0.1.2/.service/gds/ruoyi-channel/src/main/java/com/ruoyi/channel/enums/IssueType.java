package com.ruoyi.channel.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum IssueType {

    DOMESTIC_SELF(1, "境内自开"),
    OVERSEAS_SELF(2, "境外自开"),
    NOT_SELF(3, "非自开");

    @JsonValue
    private final Integer code;

    private final String desc;

    IssueType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static IssueType fromCode(Integer code) {
        return Arrays.stream(IssueType.values())
                .filter(item -> Objects.nonNull(code) && Objects.equals(item.code, code))
                .findFirst()
                .orElse(null);
    }

    public static IssueType fromDesc(String desc) {
        return Arrays.stream(IssueType.values())
                .filter(item -> StringUtils.isNotBlank(desc) && desc.equalsIgnoreCase(item.desc))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
