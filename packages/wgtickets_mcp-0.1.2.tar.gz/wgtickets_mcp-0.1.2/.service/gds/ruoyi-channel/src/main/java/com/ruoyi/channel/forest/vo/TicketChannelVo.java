package com.ruoyi.channel.forest.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TicketChannelVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 编码 */
    private String channelCode;

    /** 渠道名称 */
    private String name;

    /** GDS(GALILEO：伽利略，SABRE：塞班，TYO100：TYO100，WUH161：WUH161，HUAN_YU：外采，B2T：B2T，B2B：B2B，其他：其他，黑屏：黑屏) */
    private String gds;

    /** 开票地类型(1：三方网站，2：国际免票，3：渠道开票，4：国内免票，5：张成渠道，6：歪裹国内，7：附加产品) */
    private Integer channelType;

    /** 类型(0：机票，1：核酸，2：酒店，3：订车，4：X光，5：其它，6：加行李：7：升舱，8：选座，9：签证，10：门票) */
    private Integer type;

    /** 是否有返金(0：无，1：有) */
    private Integer isRebate;

    /** 是否有株主割引券(0：无，1：有) */
    private Integer isOnceCard;

    /** 开票人 */
    private String ticketName;

    /** 结算方式(0：账单付款，1：即时付款，2：预付款) */
    private Integer paymentType;

    /** 是否已停用(0：未停用，1：已停用) */
    private Integer isStop;

    /** 余额 */
    private BigDecimal balance;

    /** 显示排序 */
    private Integer orderNum;

    /** 联系电话 */
    private String mobile;

    /** 联系人 */
    private String contacts;

    /** 备注 */
    private String remark;

}
