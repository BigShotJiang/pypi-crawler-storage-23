package com.ruoyi.channel.service.impl;

import cn.hutool.core.collection.CollectionUtil;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.channel.mapper.ChannelMapper;
import com.ruoyi.channel.module.domain.Channel;
import com.ruoyi.channel.service.IChannelService;
import com.ruoyi.channel.service.sync.SyncChannelBC;
import com.ruoyi.channel.service.sync.SyncChannelBCContext;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

/**
 * 渠道Service业务层处理
 * 
 * @author ruoyi
 * @date 2025-07-15
 */
@Slf4j
@Service
public class ChannelServiceImpl extends ServiceImpl<ChannelMapper, Channel> implements IChannelService
{
    @Autowired
    private ChannelMapper channelMapper;
    @Autowired
    private SyncChannelBCContext syncChannelBCContext;
    @Autowired
    @Qualifier("taskExecutor")
    private ThreadPoolTaskExecutor taskExecutor;

    /**
     * 查询渠道
     * 
     * @param id 渠道主键
     * @return 渠道
     */
    @Override
    public Channel selectChannelById(Long id)
    {
        return channelMapper.selectChannelById(id);
    }

    /**
     * 查询渠道列表
     * 
     * @param channel 渠道
     * @return 渠道
     */
    @Override
    public List<Channel> selectChannelList(Channel channel)
    {
        return channelMapper.selectChannelList(channel);
    }

    /**
     * 新增渠道
     * 
     * @param channel 渠道
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public Long insertChannel(Channel channel)
    {
        LambdaQueryWrapper<Channel> codeWrapper = Wrappers.lambdaQuery(Channel.class)
                .eq(Channel::getChannelCode, channel.getChannelCode())
                .eq(Channel::isDelFlag, false);
        long codeCount = count(codeWrapper);
        if (codeCount > 0) throw new ServiceException("渠道编码已存在");

        LambdaQueryWrapper<Channel> nameWrapper = Wrappers.lambdaQuery(Channel.class)
                .eq(Channel::getName, channel.getName())
                .eq(Channel::isDelFlag, false);
        long nameCount = count(nameWrapper);
        if (nameCount > 0) throw new ServiceException("渠道名称已存在");

        Long userId = SecurityUtils.getUserId();
        LocalDateTime now = LocalDateTime.now().withNano(0);
        channel.setCreateBy(userId);
        channel.setCreateTime(now);
        channel.setUpdateBy(userId);
        channel.setCreateTime(now);
        channelMapper.insertChannel(channel);

        // 渠道同步到票务、OTA
        sync(channel);

        return channel.getId();
    }

    /**
     * 修改渠道
     * 
     * @param channel 渠道
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public int updateChannel(Channel channel)
    {
        channel.setChannelCode(null);

        LambdaQueryWrapper<Channel> nameWrapper = Wrappers.lambdaQuery(Channel.class)
                .ne(Channel::getId, channel.getId())
                .eq(Channel::getName, channel.getName())
                .eq(Channel::isDelFlag, false);
        long nameCount = count(nameWrapper);
        if (nameCount > 0) throw new ServiceException("渠道名称已存在");

        channel.setUpdateBy(SecurityUtils.getUserId());
        channel.setUpdateTime(LocalDateTime.now().withNano(0));
        int cnt = channelMapper.updateChannel(channel);

        // 渠道同步到票务、OTA
        Channel dbChannel = selectChannelById(channel.getId());
        if (StringUtils.isNotBlank(dbChannel.getDept())) {
            sync(dbChannel);
        } else {
            syncRemove(Lists.newArrayList(dbChannel.getId()));
        }

        return cnt;
    }

    /**
     * 批量删除渠道
     * 
     * @param ids 需要删除的渠道主键
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public int deleteChannelByIds(Long[] ids, Long userId)
    {
        int count = channelMapper.deleteChannelByIds(ids, userId);

        syncRemove(Lists.newArrayList(ids));

        return count;
    }

    /**
     * 删除渠道信息
     * 
     * @param id 渠道主键
     * @return 结果
     */
    @Transactional(rollbackFor = Exception.class)
    @Override
    public int deleteChannelById(Long id, Long userId)
    {
        int count = channelMapper.deleteChannelById(id, userId);

        syncRemove(Lists.newArrayList(id));

        return count;
    }

    private void syncRemove(List<Long> ids) {
        if (CollectionUtil.isEmpty(ids)) {
            return;
        }

        LambdaQueryWrapper<Channel> queryWrapper = Wrappers.lambdaQuery(Channel.class)
                .select(Channel::getDept, Channel::getChannelCode)
                .in(Channel::getId, ids);
        List<Channel> channels = list(queryWrapper);
        if (CollectionUtil.isEmpty(channels)) {
            return;
        }

        List<Channel> deptChannels = channels.stream().filter(channel -> StringUtils.isNotBlank(channel.getDept())).collect(Collectors.toList());
        List<String> noDeptChannelCodes = channels.stream().map(Channel::getChannelCode).filter(StringUtils::isBlank).collect(Collectors.toList());

        Map<String, List<String>> deptMap = new HashMap<>();
        for (Channel channel : deptChannels) {
            List<String> depts = Arrays.stream(channel.getDept().split(",")).collect(Collectors.toList());
            for (String dept : depts) {
                if (Objects.isNull(deptMap.get(dept))) {
                    deptMap.put(dept, Lists.newArrayList());
                }
                deptMap.get(dept).add(channel.getChannelCode());
            }
        }

        // 异步删除
        List<Future<Boolean>> futures = Lists.newArrayList();
        for (Map.Entry<String, List<String>> entry : deptMap.entrySet()) {
            try {
                SyncChannelBC syncChannelBC = syncChannelBCContext.getSyncChannelBC(entry.getKey());
                Future<Boolean> future = taskExecutor.submit(() -> {
                    List<String> channelCodeList = Lists.newArrayList(entry.getValue());
                    channelCodeList.addAll(noDeptChannelCodes);
                    return syncChannelBC.remove(channelCodeList);
                });
                futures.add(future);
            } catch (Exception e) {
                log.error("[渠道] 异步删除失败", e);
            }
        }

        List<Boolean> results = Lists.newArrayList();
        for (Future<Boolean> future : futures) {
            try {
                results.add(future.get());
            } catch (InterruptedException | ExecutionException e) {
                throw new ServiceException("获取渠道异步删除结果失败", HttpStatus.ERROR);
            }
        }

        results.removeAll(Collections.singleton(true));
        if (CollectionUtil.isNotEmpty(results)) {
            throw new ServiceException("异步删除失败", HttpStatus.ERROR);
        }
    }

    private void sync(Channel channel) {
        if (StringUtils.isBlank(channel.getDept())) {
            return;
        }

        List<String> depts = Arrays.stream(channel.getDept().split(",")).collect(Collectors.toList());
        List<Future<String>> futures = Lists.newArrayList();
        for (String dept : depts) {
            try {
                SyncChannelBC syncChannelBC = syncChannelBCContext.getSyncChannelBC(dept);
                Future<String> future = taskExecutor.submit(() -> syncChannelBC.saveOrUpdate(channel));
                futures.add(future);
            } catch (Exception e) {
                log.error("[渠道] 异步更新失败", e);
            }
        }

        List<String> errMsgs = Lists.newArrayList();
        for (Future<String> future : futures) {
            try {
                String errMsg = future.get();
                if (StringUtils.isNotBlank(errMsg)) {
                    errMsgs.add(errMsg);
                }
            } catch (InterruptedException | ExecutionException e) {
                throw new ServiceException("获取渠道异步更新结果失败", HttpStatus.ERROR);
            }
        }

        if (CollectionUtil.isNotEmpty(errMsgs)) {
            throw new ServiceException(String.join(";", errMsgs), HttpStatus.ERROR);
        }
    }

}
