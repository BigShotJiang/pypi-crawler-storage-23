package com.ruoyi.channel.module.vo;

import com.alibaba.excel.annotation.ExcelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 导入渠道对象 channel
 * 
 * @author ruoyi
 * @date 2025-07-15
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ChannelUploadVo implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 序号 */
    @ExcelProperty(value = "序号")
    private String index;

    /** 一级类目 */
    @ExcelProperty(value = "一级类目")
    private String firstCategory;

    /** 二级类目 */
    @ExcelProperty(value = "二级类目")
    private String secondCategory;

    /** 三级类目 */
    @ExcelProperty(value = "三级类目")
    private String thirdCategory;

    /** 适用部门，多个时用逗号拼接(OTA，TMC) */
    @ExcelProperty(value = "适用部门")
    private String dept;

    /** 渠道名称 */
    @ExcelProperty(value = "渠道名称")
    private String name;

    /** 渠道编码 */
    @ExcelProperty(value = "渠道编码")
    private String channelCode;

    /** GDS(GALILEO：伽利略，SABRE：塞班，TYO100：TYO100，WUH161：WUH161，HUAN_YU：外采，B2T：B2T，B2B：B2B，其他：其他，黑屏：黑屏) */
    @ExcelProperty(value = "GDS")
    private String gds;

    /** 开票地类型(1：三方网站，2：国际免票，3：渠道开票，4：国内免票，5：张成渠道，6：歪裹国内，7：附加产品) */
    @ExcelProperty(value = "开票地类型")
    private String issuePlaceType;

    /** 出票地 */
    @ExcelProperty(value = "出票地")
    private String issuePlace;

    /** 币种(CNY，JPY) */
    @ExcelProperty(value = "币种")
    private String currency;

    /** 开票类型(OTA称：渠道类型。1：境内自开，2：境外自开，3：非自开) */
    @ExcelProperty(value = "开票类型")
    private String issueType;

    /** 类型(0：机票，1：核酸，2：酒店，3：订车，4：X光，5：其它，6：加行李：7：升舱，8：选座，9：签证，10：门票) */
    @ExcelProperty(value = "类型")
    private String type;

    /** 结算方式(0：账单付款，1：即时付款，2：预付款) */
    @ExcelProperty(value = "结算方式")
    private String paymentType;

    /** 是否有返金(0：否，1：是) */
    @ExcelProperty(value = "是否返金")
    private String hasRebate;

    /** 是否株主割引(0：否，1：是) */
    @ExcelProperty(value = "是否株主割引")
    private String hasOnceCard;

    /** 开票人 */
    @ExcelProperty(value = "开票人")
    private String ticketUser;

    /** 联系人 */
    @ExcelProperty(value = "联系人")
    private String contactUser;

    /** 联系电话 */
    @ExcelProperty(value = "联系电话")
    private String contactMobile;

    /** 余额 */
    @ExcelProperty(value = "余额")
    private BigDecimal balance;

    /** 排序 */
    @ExcelProperty(value = "排序")
    private Integer seq;

    /** 是否已停用(0：未停用，1：已停用) */
    @ExcelProperty(value = "是否已停用")
    private String stoped;

    /** 备注 */
    @ExcelProperty(value = "备注")
    private String remark;

}
