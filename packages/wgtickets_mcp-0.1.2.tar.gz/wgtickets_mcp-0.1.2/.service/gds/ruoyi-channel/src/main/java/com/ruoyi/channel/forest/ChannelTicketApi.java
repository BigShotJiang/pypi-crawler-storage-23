package com.ruoyi.channel.forest;

import com.dtflys.forest.annotation.BaseRequest;
import com.dtflys.forest.annotation.JSONBody;
import com.dtflys.forest.annotation.Post;
import com.ruoyi.channel.forest.vo.TicketChannelVo;
import com.ruoyi.common.module.vo.ResultVo;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BaseRequest(baseURL = "${tickets_base_url}")
public interface ChannelTicketApi {


    /**
     * 渠道同步到票务
     * @param channelVo
     * @return
     */
    @Post(url = "/ticket/channel/saveOrUpdate", headers = {"Content-Type:application/json"})
    ResultVo<Integer> channelSaveOrUpdate(@JSONBody TicketChannelVo channelVo);

    /**
     * 逻辑删除票务渠道
     * @param channelCodes
     * @return
     */
    @Post(url = "/ticket/channel/removeByCodes", headers = {"Content-Type:application/json"})
    ResultVo<Boolean> removeByCodes(@JSONBody List<String> channelCodes);

}
