package com.ruoyi.channel.easyexcel;

import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.event.AnalysisEventListener;
import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruoyi.channel.enums.*;
import com.ruoyi.channel.module.domain.Channel;
import com.ruoyi.channel.module.vo.ChannelUploadVo;
import com.ruoyi.channel.service.IChannelService;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.common.utils.SecurityUtils;
import com.ruoyi.common.utils.StringUtils;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.util.Objects;
import java.util.Optional;

@Slf4j
public class UploadChannelListener extends AnalysisEventListener<ChannelUploadVo> {

    private IChannelService channelService;

    public UploadChannelListener(IChannelService channelService) {
        this.channelService = channelService;
    }

    @Override
    public void invoke(ChannelUploadVo channelUploadVo, AnalysisContext analysisContext) {
        try {
            String jsonString = JSONObject.toJSONString(channelUploadVo);
            if ("{}".equals(jsonString)) {
                return;
            }

            if (StringUtils.isBlank(channelUploadVo.getChannelCode())) {
                throw new ServiceException("渠道编码为空", HttpStatus.BAD_REQUEST);
            }

            LambdaQueryWrapper<Channel> queryWrapper = Wrappers.lambdaQuery(Channel.class)
                    .eq(Channel::getChannelCode, channelUploadVo.getChannelCode())
                    .eq(Channel::isDelFlag, 0);
            Channel channel = channelService.getOne(queryWrapper);
            channel = getChannel(channel, channelUploadVo);
            if (Objects.nonNull(channel.getId())) {
                channelService.updateChannel(channel);
            } else {
                channelService.insertChannel(channel);
            }
        } catch (Exception e) {
            log.error("导入渠道失败. 渠道: {}", JacksonUtil.toJsonString(channelUploadVo), e);
        }
    }

    private Channel getChannel(Channel channel, ChannelUploadVo excelChannelEntity) {
        String gds = Optional.ofNullable(excelChannelEntity.getGds())
                .filter(StringUtils::isNotBlank)
                .map(val -> {
                    ChannelGdsType channelGdsType = ChannelGdsType.fromCode(val);
                    return Objects.nonNull(channelGdsType) ? channelGdsType : ChannelGdsType.fromDesc(val);
                })
                .map(ChannelGdsType::getCode)
                .orElse(null);
        Integer issuePlaceType = Optional.ofNullable(excelChannelEntity.getIssuePlaceType())
                .filter(StringUtils::isNotBlank)
                .map(IssuePlaceType::fromDesc)
                .map(IssuePlaceType::getCode)
                .orElse(null);
        Integer issueType = Optional.ofNullable(excelChannelEntity.getIssueType())
                .filter(StringUtils::isNotBlank)
                .map(IssueType::fromDesc)
                .map(IssueType::getCode)
                .orElse(null);
        Integer type = Optional.ofNullable(excelChannelEntity.getType())
                .filter(StringUtils::isNotBlank)
                .map(ChannelBusinessType::fromDesc)
                .map(ChannelBusinessType::getCode)
                .orElse(null);
        Integer paymentType = Optional.ofNullable(excelChannelEntity.getPaymentType())
                .filter(StringUtils::isNotBlank)
                .map(ChannelPaymentType::fromDesc)
                .map(ChannelPaymentType::getCode)
                .orElse(null);
        Boolean hasRebate = Optional.ofNullable(excelChannelEntity.getHasRebate())
                .filter(StringUtils::isNotBlank)
                .map(YesNoType::fromDesc)
                .map(YesNoType::isFlag)
                .orElse(null);
        Boolean hasOnceCard = Optional.ofNullable(excelChannelEntity.getHasOnceCard())
                .filter(StringUtils::isNotBlank)
                .map(YesNoType::fromDesc)
                .map(YesNoType::isFlag)
                .orElse(null);
        Boolean stoped = Optional.ofNullable(excelChannelEntity.getStoped())
                .filter(StringUtils::isNotBlank)
                .map(YesNoType::fromDesc)
                .map(YesNoType::isFlag)
                .orElse(null);

        if (Objects.isNull(channel)) {
            channel = new Channel();
            channel.setCreateBy(SecurityUtils.getUserId());
            channel.setCreateTime(LocalDateTime.now().withNano(0));
        }

        channel.setFirstCategory(excelChannelEntity.getFirstCategory());
        channel.setSecondCategory(excelChannelEntity.getSecondCategory());
        channel.setThirdCategory(excelChannelEntity.getThirdCategory());
        channel.setDept(excelChannelEntity.getDept());
        channel.setName(excelChannelEntity.getName());
        channel.setChannelCode(excelChannelEntity.getChannelCode());
        channel.setGds(gds);
        channel.setIssuePlaceType(issuePlaceType);
        channel.setIssuePlace(excelChannelEntity.getIssuePlace());
        channel.setCurrency(excelChannelEntity.getCurrency());
        channel.setIssueType(issueType);
        channel.setType(type);
        channel.setPaymentType(paymentType);
        channel.setHasRebate(hasRebate);
        channel.setHasOnceCard(hasOnceCard);
        channel.setTicketUser(excelChannelEntity.getTicketUser());
        channel.setContactUser(excelChannelEntity.getContactUser());
        channel.setContactMobile(excelChannelEntity.getContactMobile());
        channel.setBalance(excelChannelEntity.getBalance());
        channel.setSeq(excelChannelEntity.getSeq());
        channel.setStoped(stoped);
        channel.setRemark(excelChannelEntity.getRemark());
        channel.setUpdateBy(SecurityUtils.getUserId());
        channel.setUpdateTime(LocalDateTime.now().withNano(0));
        channel.setDelFlag(false);

        return channel;
    }

    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
        log.info("excel读取完成");
    }

}
