package com.ruoyi.channel.service.sync.subset;

import cn.hutool.core.collection.CollectionUtil;
import com.ruoyi.channel.forest.ChannelOTAApi;
import com.ruoyi.channel.forest.vo.OTAChannelVo;
import com.ruoyi.channel.module.domain.Channel;
import com.ruoyi.channel.service.sync.SyncChannelBC;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.enums.SystemType;
import com.ruoyi.common.module.vo.ResultVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;

@Component
public class OTABC extends SyncChannelBC {

    @Autowired
    private ChannelOTAApi channelOtaApi;

    @Override
    public SystemType getSystemType() {
        return SystemType.OTA;
    }

    @Override
    public String saveOrUpdate(Channel channel) {
        OTAChannelVo otaChannelVo = OTAChannelVo.builder()
                .channelCode(channel.getChannelCode())
                // .name(channel.getName())
                .gds(channel.getGds())
                .currency(channel.getCurrency())
                .channelType(channel.getIssueType())
                .orderNum(channel.getSeq())
                .ticketPlace(channel.getIssuePlace())
                .remark(channel.getRemark())
                .build();
        ResultVo<Integer> resultVo = channelOtaApi.channelSaveOrUpdate(otaChannelVo);
        if (Objects.isNull(resultVo)) {
            return "渠道同步到OTA失败";
        }

        if (Objects.isNull(resultVo.getCode()) || resultVo.getCode() != HttpStatus.SUCCESS) {
            return "OTA: " + resultVo.getMsg();
        }

        return null;
    }

    @Override
    public Boolean remove(List<String> channelCodes) {
        if (CollectionUtil.isEmpty(channelCodes)) {
            return true;
        }

        ResultVo<Boolean> resultVo = channelOtaApi.removeByCodes(channelCodes);
        return Objects.nonNull(resultVo) && Objects.nonNull(resultVo.getCode()) && resultVo.getCode() == HttpStatus.SUCCESS;
    }

}
