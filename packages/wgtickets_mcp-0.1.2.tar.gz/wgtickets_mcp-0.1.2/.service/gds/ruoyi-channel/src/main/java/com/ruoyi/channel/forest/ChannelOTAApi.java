package com.ruoyi.channel.forest;

import com.dtflys.forest.annotation.BaseRequest;
import com.dtflys.forest.annotation.JSONBody;
import com.dtflys.forest.annotation.Post;
import com.ruoyi.channel.forest.vo.OTAChannelVo;
import com.ruoyi.common.module.vo.ResultVo;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@BaseRequest(baseURL = "${ota_base_url}")
public interface ChannelOTAApi {

    /**
     * 渠道同步到OTA
     * @param channelVo
     * @return
     */
    @Post(url = "/system/channel/saveOrUpdate", headers = {"Content-Type:application/json"})
    ResultVo<Integer> channelSaveOrUpdate(@JSONBody OTAChannelVo channelVo);

    /**
     * 逻辑删除OTA渠道
     * @param channelCodes
     * @return
     */
    @Post(url = "/system/channel/removeByCodes", headers = {"Content-Type:application/json"})
    ResultVo<Boolean> removeByCodes(@JSONBody List<String> channelCodes);

}
