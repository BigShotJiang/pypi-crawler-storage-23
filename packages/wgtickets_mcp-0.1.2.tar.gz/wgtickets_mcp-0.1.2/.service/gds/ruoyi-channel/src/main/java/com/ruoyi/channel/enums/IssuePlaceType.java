package com.ruoyi.channel.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum IssuePlaceType {

    THIRD_WEBSITE(1, "三方网站"),
    INTERNATIONAL_FREE_TICKETS(2, "国际免票"),
    CHANNEL_ISSUE(3, "渠道开票"),
    DOMESTIC_FREE_ADMISSION(4, "国内免票"),
    ZHANG_CHENG_CHANNEL(5, "张成渠道"),
    WG_DOMESTIC(6, "歪裹国内"),
    ADDITIONAL_PRODUCTS(7, "附加产品");

    @JsonValue
    private final Integer code;

    private final String desc;

    IssuePlaceType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static IssuePlaceType fromCode(Integer code) {
        return Arrays.stream(IssuePlaceType.values())
                .filter(item -> Objects.nonNull(code) && Objects.equals(item.code, code))
                .findFirst()
                .orElse(null);
    }

    public static IssuePlaceType fromDesc(String desc) {
        return Arrays.stream(IssuePlaceType.values())
                .filter(item -> StringUtils.isNotBlank(desc) && desc.equalsIgnoreCase(item.desc))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
