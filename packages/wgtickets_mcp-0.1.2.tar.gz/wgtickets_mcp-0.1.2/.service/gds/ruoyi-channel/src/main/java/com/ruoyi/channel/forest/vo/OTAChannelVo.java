package com.ruoyi.channel.forest.vo;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OTAChannelVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /** 编码 */
    private String channelCode;

    /** 渠道名称 */
    private String name;

    /** 对应gds */
    /** GDS(GALILEO：伽利略，SABRE：塞班，TYO100：TYO100，WUH161：WUH161，HUAN_YU：外采，B2T：B2T，B2B：B2B，其他：其他，黑屏：黑屏) */
    private String gds;

    /** 币种 */
    private String currency;

    /** 渠道类型 */
    /** 开票类型(OTA称：渠道类型。1：境内自开，2：境外自开，3：非自开) */
    private Integer channelType;

    /** 显示排序 */
    private Integer orderNum;

    /** 开票地 */
    private String ticketPlace;

    /** 备注 */
    private String remark;

}
