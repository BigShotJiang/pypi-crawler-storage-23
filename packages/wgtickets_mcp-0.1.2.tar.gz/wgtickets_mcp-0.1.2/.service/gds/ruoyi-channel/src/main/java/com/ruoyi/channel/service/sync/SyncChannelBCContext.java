package com.ruoyi.channel.service.sync;

import cn.hutool.core.collection.CollectionUtil;
import com.ruoyi.common.utils.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Component
public class SyncChannelBCContext {

    @Autowired
    private List<SyncChannelBC> syncChannelBCList;

    private final Map<String, SyncChannelBC> syncChannelBCMap = new HashMap<>();

    @PostConstruct
    private void init() {
        if (CollectionUtil.isEmpty(syncChannelBCList)) return;

        Optional.ofNullable(syncChannelBCList)
                .ifPresent(syncChannelBCS -> syncChannelBCS.forEach(syncChannelBC ->
                        syncChannelBCMap.put(syncChannelBC.getSystemType().getCode().toUpperCase(), syncChannelBC)
                ));
    }

    public SyncChannelBC getSyncChannelBC(String code) {
        if (StringUtils.isBlank(code)) throw new IllegalArgumentException("code is blank");
        if (CollectionUtil.isEmpty(syncChannelBCMap)) init();
        return Optional.ofNullable(syncChannelBCMap.get(code.toUpperCase())).orElseThrow(() -> new RuntimeException("bc undefined. code=" + code));
    }

}
