package com.ruoyi.channel.service.sync.subset;

import cn.hutool.core.collection.CollectionUtil;
import com.ruoyi.channel.enums.ChannelGdsType;
import com.ruoyi.channel.forest.ChannelTicketApi;
import com.ruoyi.channel.forest.vo.TicketChannelVo;
import com.ruoyi.channel.module.domain.Channel;
import com.ruoyi.channel.service.sync.SyncChannelBC;
import com.ruoyi.common.enums.SystemType;
import com.ruoyi.common.module.vo.ResultVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

@Component
public class TicketBC extends SyncChannelBC {

    @Autowired
    private ChannelTicketApi channelTicketApi;

    @Override
    public SystemType getSystemType() {
        return SystemType.TMC;
    }

    @Override
    public String saveOrUpdate(Channel channel) {
        TicketChannelVo ticketChannelVo = TicketChannelVo.builder()
                .name(channel.getName())
                .channelCode(channel.getChannelCode())
                .gds(Optional.ofNullable(ChannelGdsType.fromCode(channel.getGds())).map(ChannelGdsType::getDesc).orElse(null))
                .channelType(channel.getIssuePlaceType())
                .type(channel.getType())
                .isRebate(Objects.nonNull(channel.getHasRebate()) && channel.getHasRebate() ? 1 : 0)
                .isOnceCard(Objects.nonNull(channel.getHasOnceCard()) && channel.getHasOnceCard() ? 1 : 0)
                .ticketName(channel.getTicketUser())
                .paymentType(channel.getPaymentType())
                .isStop(Objects.nonNull(channel.getStoped()) && channel.getStoped() ? 1 : 0)
                .balance(channel.getBalance())
                .orderNum(channel.getSeq())
                .mobile(channel.getContactMobile())
                .contacts(channel.getContactUser())
                .remark(channel.getRemark())
                .build();

        ResultVo<Integer> resultVo = channelTicketApi.channelSaveOrUpdate(ticketChannelVo);
        if (Objects.isNull(resultVo)) {
            return "渠道同步到票务失败";
        }

        if (Objects.isNull(resultVo.getCode()) || resultVo.getCode() != 0) {
            return "票务: " + resultVo.getMsg();
        }

        return null;
    }

    @Override
    public Boolean remove(List<String> channelCodes) {
        if (CollectionUtil.isEmpty(channelCodes)) {
            return true;
        }

        ResultVo<Boolean> resultVo = channelTicketApi.removeByCodes(channelCodes);
        return Objects.nonNull(resultVo) && Objects.nonNull(resultVo.getCode()) && resultVo.getCode() == 0;
    }
}
