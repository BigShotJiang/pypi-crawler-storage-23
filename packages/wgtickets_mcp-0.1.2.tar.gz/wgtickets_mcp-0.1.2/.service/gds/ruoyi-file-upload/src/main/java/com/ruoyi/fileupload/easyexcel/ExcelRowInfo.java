package com.ruoyi.fileupload.easyexcel;

import com.ruoyi.common.utils.JacksonUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.ConstraintViolation;
import java.io.Serializable;
import java.util.Set;


/**
 * Excel按行导入结果
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExcelRowInfo<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 行号, 从0开始
     */
    private Integer rowIndex;

    /**
     * 导入的数据
     */
    private T target;

    /**
     * 校验结果
     */
    private Set<ConstraintViolation<T>> violation;

    /**
     * 业务异常错误信息
     */
    private String bizError;

    @Override
    public String toString() {
        return JacksonUtil.toJsonStringNoNull(this);
    }

}
