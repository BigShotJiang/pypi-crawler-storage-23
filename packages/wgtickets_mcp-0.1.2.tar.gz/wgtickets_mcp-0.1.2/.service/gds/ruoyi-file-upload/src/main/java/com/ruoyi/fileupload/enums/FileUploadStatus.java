package com.ruoyi.fileupload.enums;

import lombok.Getter;

@Getter
public enum FileUploadStatus {

    UPLOADING(1, "导入中"),
    UPLOAD_FAIL(2, "导入失败"),
    GENERATING_FAIL_RESULT(3, "生成反馈中"),
    UPLOAD_SUCCESS(4, "导入完成");

    private final Integer code;

    private final String desc;

    // 构造器
    FileUploadStatus(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }
    
}
