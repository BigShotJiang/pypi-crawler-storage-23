package com.ruoyi.fileupload.enums;

import lombok.Getter;

@Getter
public enum FileUploadScene {

    POLICY(10, "政策");

    private final Integer code;

    private final String desc;

    // 构造器
    FileUploadScene(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }
    
}
