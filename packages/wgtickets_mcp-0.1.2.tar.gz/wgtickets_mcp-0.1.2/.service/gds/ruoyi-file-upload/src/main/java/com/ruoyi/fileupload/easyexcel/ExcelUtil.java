package com.ruoyi.fileupload.easyexcel;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.excel.EasyExcel;
import com.ruoyi.common.utils.spring.SpringUtils;
import com.ruoyi.fileupload.enums.FileUploadStatus;
import com.ruoyi.fileupload.service.IFileUploadRecordService;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.stream.Collectors;

/**
 * excel工具
 *
 */
@Slf4j
public class ExcelUtil {

    private static final IFileUploadRecordService fileUploadRecordService = SpringUtils.getBean(IFileUploadRecordService.class);

    /**
     * 导入, 标题行默认为1
     *
     * @param file      文件
     * @param pojoClass 实体类
     * @param consumer  消费数据, 执行SQL逻辑或其他逻辑等等,
     *                  如果抛出LyException异常, 则异常message将作为Excel导入失败原因
     *                  否则为未知异常导致导入失败
     * @param <T>       对应类型
     * @return          导入结果
     */
    public static <T> ExcelImportResult read(MultipartFile file, Class<T> pojoClass, Consumer<T> consumer, Long fileUploadRecordId) {
        return read(file, pojoClass, consumer, 1, fileUploadRecordId);
    }

    /**
     * 导入
     *
     * @param file            文件
     * @param pojoClass       实体类
     * @param consumer        消费数据, 执行SQL逻辑或其他逻辑等等,
     *                        如果抛出LyException异常, 则异常message将作为Excel导入失败原因
     *                        否则为未知异常导致导入失败
     * @param titleLineNumber 标题所在行, 从1开始
     * @param <T>             对应类型
     * @return                导入结果
     */
    public static <T> ExcelImportResult read(MultipartFile file, Class<T> pojoClass, Consumer<T> consumer, Integer titleLineNumber, Long fileUploadRecordId) {
        try {
            return read(file.getBytes(), pojoClass, consumer, titleLineNumber, fileUploadRecordId);
        } catch (Exception e) {
            log.error("文件读取失败", e);
        }

        return null;
    }

    /**
     * 导入, 标题行默认为1
     *
     * @param fileBytes 文件字节码
     * @param pojoClass 实体类
     * @param consumer  消费数据, 执行SQL逻辑或其他逻辑等等,
     *                  如果抛出LyException异常, 则异常message将作为Excel导入失败原因
     *                  否则为未知异常导致导入失败
     * @param <T>       对应类型
     * @return                导入结果
     */
    public static <T> ExcelImportResult read(byte[] fileBytes, Class<T> pojoClass, Consumer<T> consumer, Long fileUploadRecordId) {
        return read(fileBytes, pojoClass, consumer, 1,  fileUploadRecordId);
    }

    /**
     * 导入
     *
     * @param fileBytes       文件字节码
     * @param pojoClass       实体类
     * @param consumer        消费数据, 执行SQL逻辑或其他逻辑等等,
     *                        如果抛出LyException异常, 则异常message将作为Excel导入失败原因
     *                        否则为未知异常导致导入失败
     * @param titleLineNumber 标题所在行, 从1开始
     * @param <T>             对应类型
     * @return                导入结果
     */
    public static <T> ExcelImportResult read(byte[] fileBytes, Class<T> pojoClass, Consumer<T> consumer, Integer titleLineNumber, Long fileUploadRecordId) {
        try (InputStream inputStream = new ByteArrayInputStream(fileBytes);
             InputStream templateIs = new ByteArrayInputStream(fileBytes);
             ByteArrayOutputStream outputStream = new ByteArrayOutputStream()) {
            long s1 = System.currentTimeMillis();
            log.info("[{}] 读取并入库—开始...", consumer.getClass().getSimpleName());

            ExcelImportListener<T> listener = new ExcelImportListener<>(consumer, fileUploadRecordId);
            EasyExcel.read(inputStream, pojoClass, listener).headRowNumber(titleLineNumber).sheet().doRead();
            List<ExcelRowInfo<T>> resultList = listener.getRowInfos();
            int total = listener.getProcessedCount().get();
            int successCount = listener.getSuccessCount().get();
            int faileCount = listener.getFaileCount().get();
            ExcelImportResult result = ExcelImportResult.builder().total(total).success(successCount).fail(faileCount).build();
            log.info("[{}] 读取并入库—完成。耗时: {} 秒", consumer.getClass().getSimpleName(), String.format("%.2f", (System.currentTimeMillis() - s1) / 1000.0));

            List<ExcelRowInfo<T>> failRows = resultList.stream()
                    .filter(rowInfo -> CollectionUtil.isNotEmpty(rowInfo.getViolation()) || StringUtils.isNotBlank(rowInfo.getBizError()))
                    .collect(Collectors.toList());
            if (CollectionUtil.isEmpty(failRows)) {
                // 更新导入状态
                fileUploadRecordService.updateStatus(fileUploadRecordId, FileUploadStatus.UPLOAD_SUCCESS);
                return result;
            };

            long s2 = System.currentTimeMillis();
            log.info("[{}] 生成导入失败文件—开始...", consumer.getClass().getSimpleName());

            // 更新导入状态
            fileUploadRecordService.updateStatus(fileUploadRecordId, FileUploadStatus.GENERATING_FAIL_RESULT);

            EasyExcel.write(outputStream, pojoClass)
                    .withTemplate(templateIs)
                    .autoCloseStream(false)
                    .registerWriteHandler(new ExcelErrorFillHandler<>(resultList, titleLineNumber))
                    .needHead(false)
                    .sheet()
                    .doWrite(Collections.emptyList());
            result.setErrorFileBytes(outputStream.toByteArray());
            log.info("[{}] 生成导入失败文件—完成。耗时: {} 秒", consumer.getClass().getSimpleName(), String.format("%.2f", (System.currentTimeMillis() - s2) / 1000.0));

            // 更新导入状态
            fileUploadRecordService.updateStatus(fileUploadRecordId, FileUploadStatus.UPLOAD_SUCCESS);

            return result;
        } catch (Exception e) {
            log.error("文件读取失败", e);
        }

        return new ExcelImportResult();
    }

}
