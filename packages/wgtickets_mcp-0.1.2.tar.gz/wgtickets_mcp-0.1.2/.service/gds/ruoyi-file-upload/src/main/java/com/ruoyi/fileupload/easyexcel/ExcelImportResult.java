package com.ruoyi.fileupload.easyexcel;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExcelImportResult implements Serializable {

    private static final long serialVersionUID = 1L;

    private int total;

    private int success;

    private int fail;

    private byte[] errorFileBytes;

}
