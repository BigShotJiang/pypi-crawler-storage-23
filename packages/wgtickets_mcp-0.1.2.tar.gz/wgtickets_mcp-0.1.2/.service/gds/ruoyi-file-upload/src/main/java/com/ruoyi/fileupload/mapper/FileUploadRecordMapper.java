package com.ruoyi.fileupload.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.fileupload.module.domain.FileUploadRecord;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 文件导入记录Mapper接口
 * 
 * @author ruoyi
 * @date 2025-10-27
 */
public interface FileUploadRecordMapper extends BaseMapper<FileUploadRecord>
{
    /**
     * 查询文件导入记录
     * 
     * @param id 文件导入记录主键
     * @return 文件导入记录
     */
    public FileUploadRecord selectFileUploadRecordById(Long id);

    /**
     * 查询文件导入记录列表
     * 
     * @param fileUploadRecord 文件导入记录
     * @return 文件导入记录集合
     */
    public List<FileUploadRecord> selectFileUploadRecordList(FileUploadRecord fileUploadRecord);

    /**
     * 新增文件导入记录
     * 
     * @param fileUploadRecord 文件导入记录
     * @return 结果
     */
    public int insertFileUploadRecord(FileUploadRecord fileUploadRecord);

    /**
     * 修改文件导入记录
     * 
     * @param fileUploadRecord 文件导入记录
     * @return 结果
     */
    public int updateFileUploadRecord(FileUploadRecord fileUploadRecord);

    /**
     * 删除文件导入记录
     * 
     * @param id 文件导入记录主键
     * @return 结果
     */
    public int deleteFileUploadRecordById(Long id);

    /**
     * 批量删除文件导入记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFileUploadRecordByIds(Long[] ids);

    int incrementSuccess(@Param("id") Long id);

    int incrementFail(@Param("id") Long id);

    int updateTotal(@Param("id") Long id, @Param("total") Long total);

    int updateStatus(@Param("id") Long id, @Param("status") Integer status);
}
