package com.ruoyi.fileupload.enums;

import lombok.Getter;

@Getter
public enum IncrementType {

    SUCCESS,

    FAIL

}
