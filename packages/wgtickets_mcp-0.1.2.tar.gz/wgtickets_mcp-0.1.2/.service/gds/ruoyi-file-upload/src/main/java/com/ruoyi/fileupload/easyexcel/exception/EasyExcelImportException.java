package com.ruoyi.fileupload.easyexcel.exception;

/**
 * 导入异常
 */
public class EasyExcelImportException extends RuntimeException {

    public EasyExcelImportException(String message) {
        super(message);
    }
}
