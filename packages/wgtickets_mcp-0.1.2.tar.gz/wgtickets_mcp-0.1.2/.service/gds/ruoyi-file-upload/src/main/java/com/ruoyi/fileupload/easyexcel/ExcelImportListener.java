package com.ruoyi.fileupload.easyexcel;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.excel.context.AnalysisContext;
import com.alibaba.excel.read.listener.ReadListener;
import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.common.utils.ValidatorUtil;
import com.ruoyi.common.utils.spring.SpringUtils;
import com.ruoyi.fileupload.easyexcel.exception.EasyExcelImportException;
import com.ruoyi.fileupload.enums.IncrementType;
import com.ruoyi.fileupload.service.IFileUploadRecordService;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.validation.ConstraintViolation;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;

/**
 * 读取并校验 Excel行数据
 */
@Slf4j
@RequiredArgsConstructor
@AllArgsConstructor
public class ExcelImportListener<T> implements ReadListener<T> {
    private final List<ExcelRowInfo<T>> rowInfos = new ArrayList<>();
    private final static String defaultBizError = "未知异常";

    private final ExecutorService executor = Executors.newFixedThreadPool(20);
    private final AtomicInteger processedCount = new AtomicInteger(0);
    private final AtomicInteger successCount = new AtomicInteger(0);
    private final AtomicInteger faileCount = new AtomicInteger(0);

    public static Map<String, Set<String>> consumerMap = new HashMap<>();

    private final IFileUploadRecordService fileUploadRecordService = SpringUtils.getBean(IFileUploadRecordService.class);

    /**
     * 业务处理, 入库, 解析等
     */
    private final Consumer<T> consumer;

    /**
     * 业务ID
     */
    private Long fileUploadRecordId;

    /**
     * excel数据行
     */
    @Override
    public void invoke(T t, AnalysisContext analysisContext) {
        ExcelRowInfo<T> lineResult = ExcelRowInfo.<T>builder()
                .rowIndex(analysisContext.readRowHolder().getRowIndex())
                .target(t)
                .build();
        rowInfos.add(lineResult);
    }

    /**
     * 读取完毕后执行校验
     */
    @Override
    public void doAfterAllAnalysed(AnalysisContext analysisContext) {
        Long total = Optional.of(rowInfos).map(List::size).map(Long::valueOf).orElse(0L);
        fileUploadRecordService.updateTotal(fileUploadRecordId, total);

        if (CollectionUtil.isEmpty(rowInfos)) return;

        List<Future<ExcelRowInfo<T>>> futures = new ArrayList<>();
        for (ExcelRowInfo<T> rowInfo : rowInfos) {
            try {
                Future<ExcelRowInfo<T>> future = executor.submit(() -> dataHandle(rowInfo));
                futures.add(future);
            } catch (Exception e) {
                log.error("行数据—提交异步处理失败", e);
            }
        }

        for (Future<ExcelRowInfo<T>> future : futures) {
            try {
                future.get();
            } catch (InterruptedException | ExecutionException e) {
                log.error("行数据—获取异步处理结果失败", e);
            }
        }

        try {
            executor.shutdown(); // 关闭线程池，不再接受新的任务
            executor.awaitTermination(Long.MAX_VALUE, TimeUnit.NANOSECONDS); // 等待所有任务完成
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt(); // 重新设置中断状态
        }

        log.info("Excel读取完成. 总条数: {}", processedCount.get());
        log.info("Excel读取完成. [{}] 不存在的Code: {}", consumer.getClass().getSimpleName(), JacksonUtil.toJsonString(consumerMap.getOrDefault(consumer.getClass().getSimpleName(), new HashSet<>())));
        consumerMap.remove(consumer.getClass().getSimpleName());
        // log.info("Excel读取完成. [{}] 不存在的Code[内存清理后]: {}", consumer.getClass().getSimpleName(), JacksonUtil.toJsonString(consumerMap.getOrDefault(consumer.getClass().getSimpleName(), new HashSet<>())));
    }

    private ExcelRowInfo<T> dataHandle(ExcelRowInfo<T> rowInfo) {
        try {
            processedCount.incrementAndGet();

            Set<ConstraintViolation<T>> validateSet = ValidatorUtil.validateObj(rowInfo.getTarget());
            rowInfo.setViolation(validateSet);
            // 校验不通过, 不必执行业务逻辑
            if (CollectionUtil.isNotEmpty(validateSet)) return rowInfo;
            // 执行业务逻辑
            consumer.accept(rowInfo.getTarget());
            successCount.incrementAndGet();
            fileUploadRecordService.increment(fileUploadRecordId, IncrementType.SUCCESS);
        } catch (EasyExcelImportException e) {
            // log.error("解析数据失败. 业务处理异常. 数据: {}", rowInfo, e);
            rowInfo.setBizError(e.getMessage());
            faileCount.incrementAndGet();
            fileUploadRecordService.increment(fileUploadRecordId, IncrementType.FAIL);
        } catch (Exception e) {
            // log.error("解析数据失败. 未知异常. 数据: {}", rowInfo, e);
            rowInfo.setBizError(defaultBizError + ": " + e.getMessage());
            faileCount.incrementAndGet();
            fileUploadRecordService.increment(fileUploadRecordId, IncrementType.FAIL);
        }

        return rowInfo;
    }

    public Consumer<T> getConsumer() {
        return consumer;
    }

    public List<ExcelRowInfo<T>> getRowInfos() {
        return rowInfos;
    }

    public AtomicInteger getProcessedCount() {
        return processedCount;
    }

    public AtomicInteger getSuccessCount() {
        return successCount;
    }

    public AtomicInteger getFaileCount() {
        return faileCount;
    }
}
