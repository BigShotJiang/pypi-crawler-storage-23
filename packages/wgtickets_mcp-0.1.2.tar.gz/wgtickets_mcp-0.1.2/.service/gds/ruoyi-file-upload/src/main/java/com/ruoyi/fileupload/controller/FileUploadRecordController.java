package com.ruoyi.fileupload.controller;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.fileupload.module.domain.FileUploadRecord;
import com.ruoyi.fileupload.service.IFileUploadRecordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 文件导入记录Controller
 * 
 * @author ruoyi
 * @date 2025-10-27
 */
@RestController
@RequestMapping("/fileupload/record")
public class FileUploadRecordController extends BaseController
{
    @Autowired
    private IFileUploadRecordService fileUploadRecordService;

    /**
     * 查询文件导入记录列表
     */
    @GetMapping("/list")
    public TableDataInfo list(FileUploadRecord fileUploadRecord)
    {
        startPage();
        List<FileUploadRecord> list = fileUploadRecordService.selectFileUploadRecordList(fileUploadRecord);
        return getDataTable(list);
    }

    /**
     * 导出文件导入记录列表
     */
    @Log(title = "文件导入记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FileUploadRecord fileUploadRecord)
    {
        List<FileUploadRecord> list = fileUploadRecordService.selectFileUploadRecordList(fileUploadRecord);
        ExcelUtil<FileUploadRecord> util = new ExcelUtil<FileUploadRecord>(FileUploadRecord.class);
        util.exportExcel(response, list, "文件导入记录数据");
    }

    /**
     * 获取文件导入记录详细信息
     */
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(fileUploadRecordService.selectFileUploadRecordById(id));
    }

    /**
     * 新增文件导入记录
     */
    @Log(title = "文件导入记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FileUploadRecord fileUploadRecord)
    {
        return toAjax(fileUploadRecordService.insertFileUploadRecord(fileUploadRecord));
    }

    /**
     * 修改文件导入记录
     */
    @Log(title = "文件导入记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FileUploadRecord fileUploadRecord)
    {
        return toAjax(fileUploadRecordService.updateFileUploadRecord(fileUploadRecord));
    }

    /**
     * 删除文件导入记录
     */
    @Log(title = "文件导入记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(fileUploadRecordService.deleteFileUploadRecordByIds(ids));
    }
}
