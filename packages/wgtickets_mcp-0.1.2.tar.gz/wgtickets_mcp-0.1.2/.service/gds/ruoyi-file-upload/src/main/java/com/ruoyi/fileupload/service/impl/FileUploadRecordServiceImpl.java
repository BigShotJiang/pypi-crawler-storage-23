package com.ruoyi.fileupload.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.DateUtils;
import com.ruoyi.common.utils.oss.OssBootUtil;
import com.ruoyi.fileupload.easyexcel.ExcelImportResult;
import com.ruoyi.fileupload.easyexcel.ExcelUtil;
import com.ruoyi.fileupload.enums.FileUploadScene;
import com.ruoyi.fileupload.enums.FileUploadStatus;
import com.ruoyi.fileupload.enums.IncrementType;
import com.ruoyi.fileupload.mapper.FileUploadRecordMapper;
import com.ruoyi.fileupload.module.domain.FileUploadRecord;
import com.ruoyi.fileupload.service.IFileUploadRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Consumer;

/**
 * 文件导入记录Service业务层处理
 * 
 * @author ruoyi
 * @date 2025-10-27
 */
@Slf4j
@Service
public class FileUploadRecordServiceImpl extends ServiceImpl<FileUploadRecordMapper, FileUploadRecord> implements IFileUploadRecordService
{
    @Autowired
    private FileUploadRecordMapper fileUploadRecordMapper;

    /**
     * 查询文件导入记录
     * 
     * @param id 文件导入记录主键
     * @return 文件导入记录
     */
    @Override
    public FileUploadRecord selectFileUploadRecordById(Long id)
    {
        return fileUploadRecordMapper.selectFileUploadRecordById(id);
    }

    /**
     * 查询文件导入记录列表
     * 
     * @param fileUploadRecord 文件导入记录
     * @return 文件导入记录
     */
    @Override
    public List<FileUploadRecord> selectFileUploadRecordList(FileUploadRecord fileUploadRecord)
    {
        return fileUploadRecordMapper.selectFileUploadRecordList(fileUploadRecord);
    }

    /**
     * 新增文件导入记录
     * 
     * @param fileUploadRecord 文件导入记录
     * @return 结果
     */
    @Override
    public int insertFileUploadRecord(FileUploadRecord fileUploadRecord)
    {
        fileUploadRecord.setCreateTime(DateUtils.getNowDate());
        return fileUploadRecordMapper.insertFileUploadRecord(fileUploadRecord);
    }

    /**
     * 修改文件导入记录
     * 
     * @param fileUploadRecord 文件导入记录
     * @return 结果
     */
    @Override
    public int updateFileUploadRecord(FileUploadRecord fileUploadRecord)
    {
        fileUploadRecord.setUpdateTime(DateUtils.getNowDate());
        return fileUploadRecordMapper.updateFileUploadRecord(fileUploadRecord);
    }

    /**
     * 批量删除文件导入记录
     * 
     * @param ids 需要删除的文件导入记录主键
     * @return 结果
     */
    @Override
    public int deleteFileUploadRecordByIds(Long[] ids)
    {
        return fileUploadRecordMapper.deleteFileUploadRecordByIds(ids);
    }

    /**
     * 删除文件导入记录信息
     * 
     * @param id 文件导入记录主键
     * @return 结果
     */
    @Override
    public int deleteFileUploadRecordById(Long id)
    {
        return fileUploadRecordMapper.deleteFileUploadRecordById(id);
    }

    @Override
    public int increment(Long id, IncrementType type) {
        if (Objects.isNull(id) || id <= 0 || Objects.isNull(type)) return 0;

        switch (type) {
            case SUCCESS:
                return fileUploadRecordMapper.incrementSuccess(id);
            case FAIL:
                return fileUploadRecordMapper.incrementFail(id);
            default:
                return 0;
        }
    }

    @Override
    public int updateTotal(Long id, Long total) {
        if (Objects.isNull(id) || id <= 0 || Objects.isNull(total)) return 0;
        return fileUploadRecordMapper.updateTotal(id, total);
    }

    @Override
    public int updateStatus(Long id, FileUploadStatus status) {
        if (Objects.isNull(id) || id <= 0 || Objects.isNull(status)) return 0;
        return fileUploadRecordMapper.updateStatus(id, status.getCode());
    }

    @Override
    public <T> FileUploadRecord importExcel(FileUploadScene scene, MultipartFile file, Integer titleRows, Class<T> clazz, Consumer<T> consumer, Long userId) {
        if (Objects.isNull(scene)) throw new ServiceException("文件导入场景为空", HttpStatus.ERROR);
        if (Objects.isNull(file) || file.isEmpty()) throw new ServiceException("文件内容为空", HttpStatus.BAD_REQUEST);
        if (Objects.isNull(clazz)) throw new ServiceException("文件内容接收实体为空", HttpStatus.ERROR);
        if (Objects.isNull(consumer)) throw new ServiceException("文件内容处理类为空", HttpStatus.ERROR);

        try {
            byte[] fileBytes = file.getBytes();
            return importExcel(scene, file.getOriginalFilename(), fileBytes, titleRows, clazz, consumer, userId);
        } catch (IOException e) {
            throw new ServiceException("[" + scene.getDesc() + "] 读取文件内容失败", HttpStatus.ERROR);
        }
    }

    @Override
    public <T> FileUploadRecord importExcel(FileUploadScene scene, String fileName, byte[] fileBytes, Integer titleRows, Class<T> clazz, Consumer<T> consumer, Long userId) {
        if (Objects.isNull(scene)) throw new ServiceException("文件导入场景为空", HttpStatus.ERROR);
        if (Objects.isNull(fileBytes) || fileBytes.length == 0) throw new ServiceException("文件内容为空", HttpStatus.BAD_REQUEST);
        if (Objects.isNull(clazz)) throw new ServiceException("文件内容接收实体为空", HttpStatus.ERROR);
        if (Objects.isNull(consumer)) throw new ServiceException("文件内容处理类为空", HttpStatus.ERROR);

        // OSS上传文件路径
        String filePath = OssBootUtil.getProfile();
        // 上传源文件
        MultipartFile sourceFile = convertToMultipartFile(fileBytes, fileName);
        String sourceFileUrl = OssBootUtil.upload(sourceFile, filePath);

        String userIdStr = Optional.ofNullable(userId).map(String::valueOf).orElse("0");
        Date nowDate = DateUtils.getNowDate();
        FileUploadRecord fileUploadRecord = FileUploadRecord.builder()
                .scene(scene.name())
                .fileName(fileName)
                .originalUrl(sourceFileUrl)
                .status(FileUploadStatus.UPLOADING.getCode())
                .createBy(userIdStr)
                .createTime(nowDate)
                .updateBy(userIdStr)
                .updateTime(nowDate)
                .delFlag(Boolean.FALSE)
                .build();
        insertFileUploadRecord(fileUploadRecord);

        try {
            String failFileUrl = null;
            long t1 = System.currentTimeMillis();
            ExcelImportResult importResult = ExcelUtil.read(fileBytes, clazz, consumer, Optional.ofNullable(titleRows).orElse(1), fileUploadRecord.getId());
            log.info("[{}]-[{}] 导入总耗时: {} 秒", scene.getDesc(), fileName, String.format("%.2f", (System.currentTimeMillis() - t1) / 1000.0));

            // 更新导入状态
            updateStatus(fileUploadRecord.getId(), FileUploadStatus.GENERATING_FAIL_RESULT);

            if (Objects.nonNull(importResult)) {
                log.info("[{}]-[{}] 导入完成. 总数: {}, 成功: {}, 失败: {}", scene.getDesc(), fileName, importResult.getTotal(), importResult.getSuccess(), importResult.getFail());
                if (Objects.nonNull(importResult.getErrorFileBytes())) {
                    // 上传导入失败文件
                    MultipartFile faileFile = convertToMultipartFile(importResult.getErrorFileBytes(), "fail_" + fileName);
                    failFileUrl = OssBootUtil.upload(faileFile, filePath);

                    // 写到本地
                    /*String fileNameLocal = "./" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS")) + "_" + fileName;
                    IOUtils.write(importResult.getErrorFileBytes(), Files.newOutputStream(Paths.get(fileNameLocal)));*/
                }
            }

            log.info("[{}]-[{}] 源文件OSS: {}", scene.getDesc(), fileName, sourceFileUrl);
            log.info("[{}]-[{}] 失败文件OSS: {}", scene.getDesc(), fileName, failFileUrl);

            fileUploadRecord.setFailUrl(failFileUrl);
            fileUploadRecord.setTotalNum(Optional.ofNullable(importResult).map(ExcelImportResult::getTotal).map(Long::valueOf).orElse(0L));
            fileUploadRecord.setSuccessNum(Optional.ofNullable(importResult).map(ExcelImportResult::getSuccess).map(Long::valueOf).orElse(0L));
            fileUploadRecord.setFailNum(Optional.ofNullable(importResult).map(ExcelImportResult::getFail).map(Long::valueOf).orElse(0L));
            fileUploadRecord.setStatus(FileUploadStatus.UPLOAD_SUCCESS.getCode());
            fileUploadRecord.setUpdateTime(DateUtils.getNowDate());
        } catch (Exception e) {
            log.error("[{}]-[{}] 导入失败.", scene.getDesc(), fileName, e);
            fileUploadRecord.setStatus(FileUploadStatus.UPLOAD_FAIL.getCode());
            fileUploadRecord.setUpdateTime(DateUtils.getNowDate());
        }

        updateFileUploadRecord(fileUploadRecord);
        return fileUploadRecord;
    }

    public static MultipartFile convertToMultipartFile(byte[] bytes, String fileName) {
        return new MockMultipartFile("file", fileName, null, bytes);
    }

}
