package com.ruoyi.fileupload.module.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

/**
 * 文件导入记录对象 file_upload_record
 * 
 * @author ruoyi
 * @date 2025-10-27
 */
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class FileUploadRecord extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    private Long id;

    /** 场景（POLICY：政策） */
    @Excel(name = "场景", readConverterExp = "P=OLICY：政策")
    private String scene;

    /** 文件名 */
    @Excel(name = "文件名")
    private String fileName;

    /** 原始文件 OSS URL */
    @Excel(name = "原始文件 OSS URL")
    private String originalUrl;

    /** 上传失败文件 OSS URL */
    @Excel(name = "上传失败文件 OSS URL")
    private String failUrl;

    /** 总条数 */
    @Excel(name = "总条数")
    private Long totalNum;

    /** 成功条数 */
    @Excel(name = "成功条数")
    private Long successNum;

    /** 失败条数 */
    @Excel(name = "失败条数")
    private Long failNum;

    /** 导入状态（1：导入中，2：导入失败，3：生成反馈中，4：导入完成） */
    @Excel(name = "失败条数")
    private Integer status;

    /** 是否已删除（false：未删除，true：已删除） */
    private boolean delFlag;

}
