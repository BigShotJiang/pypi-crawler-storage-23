package com.ruoyi.fileupload.easyexcel;

import com.alibaba.excel.enums.CellDataTypeEnum;
import com.alibaba.excel.metadata.Head;
import com.alibaba.excel.metadata.data.CellData;
import com.alibaba.excel.metadata.data.WriteCellData;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.style.column.AbstractColumnWidthStyleStrategy;
import org.apache.poi.ss.usermodel.Cell;

import java.util.List;

public class CustomCellWriteHandler extends AbstractColumnWidthStyleStrategy {

    @Override
    protected void setColumnWidth(WriteSheetHolder writeSheetHolder, List<WriteCellData<?>> cellDataList, Cell cell, Head head, Integer relativeRowIndex, Boolean isHead) {
        int columnWidth = 0;
        if (isHead) {
            columnWidth = Math.min(cell.getStringCellValue().length() * 5, 200);
        } else {
            for (CellData cellData : cellDataList) {
                if (cellData.getType() == CellDataTypeEnum.STRING) {
                    columnWidth = Math.max(columnWidth, cellData.getStringValue().length() * 5);
                }
            }
            columnWidth = Math.min(columnWidth, 200); // 限制最大宽度
        }
        if (columnWidth < 20) {
            columnWidth = 20; // 最小宽度
        }
        writeSheetHolder.getSheet().setColumnWidth(cell.getColumnIndex(), columnWidth * 200);
    }

}
