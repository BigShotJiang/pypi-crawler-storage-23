package com.ruoyi.fileupload.easyexcel;

import cn.hutool.core.collection.CollectionUtil;
import com.alibaba.excel.write.handler.RowWriteHandler;
import com.alibaba.excel.write.handler.SheetWriteHandler;
import com.alibaba.excel.write.handler.context.SheetWriteHandlerContext;
import com.alibaba.excel.write.metadata.holder.WriteSheetHolder;
import com.alibaba.excel.write.metadata.holder.WriteWorkbookHolder;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.*;

import javax.validation.ConstraintViolation;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Slf4j
@RequiredArgsConstructor
public class ExcelErrorFillHandler<T> implements SheetWriteHandler, RowWriteHandler {
    /**
     * 错误结果集
     */
    private final List<ExcelRowInfo<T>> rows;

    /**
     * 标题所在行, 从1开始
     */
    private final Integer titleLineNumber;

    /**
     * 结果列序号
     */
    private int resultColNum;

    /**
     * 默认导入成功的提示
     */
    private static final String SUCCESS_MSG = "导入成功";


    private static void setCellStyle(Cell cell, IndexedColors color) {
        Workbook workbook = cell.getSheet().getWorkbook();
        CellStyle style = workbook.createCellStyle();
        Font font = workbook.createFont();
        font.setColor(color.getIndex());
        style.setFont(font);
        cell.setCellStyle(style);
    }

    @Override
    public void afterSheetCreate(SheetWriteHandlerContext context) {
        SheetWriteHandler.super.afterSheetCreate(context);
    }

    @Override
    public void afterSheetCreate(WriteWorkbookHolder writeWorkbookHolder, WriteSheetHolder writeSheetHolder) {
        Sheet cachedSheet = writeSheetHolder.getCachedSheet();
        boolean importResultCellExists = false;
        for (int i = 1; i <= cachedSheet.getLastRowNum() + 1; i++) {
            // 空白数据, 不做处理
            if (i < titleLineNumber) {
                continue;
            }
            Row row = cachedSheet.getRow(i - 1);

            // 【导入结果】列，存在则直接使用，不存在则新添加
            // 标题行, 创建标题
            if (i == titleLineNumber) {
                this.resultColNum = row.getLastCellNum();
                Cell lastCell = row.getCell(row.getLastCellNum() - 1);
                if (Objects.nonNull(lastCell) && !"导入结果".equalsIgnoreCase(lastCell.getStringCellValue())) {
                    Cell cell = row.createCell(row.getLastCellNum(), CellType.STRING);
                    setCellStyle(cell, IndexedColors.BLACK);
                    cell.setCellValue("导入结果");
                    continue;
                }
                importResultCellExists = true;
            }
            // 结果行
            Cell cell = importResultCellExists ? row.getCell(row.getLastCellNum() - 1) : row.createCell(this.resultColNum, CellType.STRING);
            try {
                String errMsg = convertErrMsg(rows.get(i - titleLineNumber - 1));
                if (StringUtils.isNotBlank(errMsg)) {
                    setCellStyle(cell, IndexedColors.RED);
                    cell.setCellValue(errMsg);
                } else {
                    setCellStyle(cell, IndexedColors.GREEN);
                    cell.setCellValue(SUCCESS_MSG);
                }
            } catch (Exception e) {
                // log.error(e.getMessage());
            }

            // 总是新添加【导入结果】列
            /*// 标题行, 创建标题
            if (i == titleLineNumber) {
                this.resultColNum = row.getLastCellNum();
                Cell cell = row.createCell(row.getLastCellNum(), CellType.STRING);
                setCellStyle(cell, IndexedColors.BLACK);
                cell.setCellValue("导入结果");
                continue;
            }
            // 结果行
            Cell cell = row.createCell(this.resultColNum, CellType.STRING);
            try {
                String errMsg = convertErrMsg(rows.get(i - titleLineNumber - 1));
                if (StringUtils.isNotBlank(errMsg)) {
                    setCellStyle(cell, IndexedColors.RED);
                    cell.setCellValue(errMsg);
                } else {
                    setCellStyle(cell, IndexedColors.GREEN);
                    cell.setCellValue(SUCCESS_MSG);
                }
            } catch (Exception e) {
                log.error(e.getMessage());
            }*/
        }

        // 获取需要删除的行
        List<Integer> needRemoveRowNums = new ArrayList<>();
        for (Row row : cachedSheet) {
            if (row.getRowNum() == (titleLineNumber - 1)) continue;
            Cell cell = row.getCell(row.getLastCellNum() - 1);
            if (StringUtils.isBlank(cell.getStringCellValue()) || SUCCESS_MSG.equalsIgnoreCase(cell.getStringCellValue())) {
                needRemoveRowNums.add(row.getRowNum());
            }
        }

        // 从后向前删除，避免行号变化
        needRemoveRowNums.sort(Collections.reverseOrder());
        for (int rowIndex : needRemoveRowNums) {
            int lastRowNum = cachedSheet.getLastRowNum();
            // 修改条件，允许删除最后一行
            if (rowIndex >= 0 && rowIndex <= lastRowNum) {
                // 注意：删除最后一行时，rowIndex + 1 可能大于 lastRowNum
                int startRow = rowIndex + 1;
                int endRow = lastRowNum;
                // 确保起始行不超过结束行
                if (startRow <= endRow) {
                    cachedSheet.shiftRows(startRow, endRow, -1);
                } else {
                    // 如果是最后一行，直接移除
                    Row rowToRemove = cachedSheet.getRow(rowIndex);
                    if (rowToRemove != null) {
                        cachedSheet.removeRow(rowToRemove);
                    }
                }
            }
        }
    }

    /**
     * 解析每行的错误信息
     *
     * @param result 读取结果
     * @return 错误信息
     */
    private String convertErrMsg(ExcelRowInfo<T> result) {
        if (StringUtils.isNotBlank(result.getBizError())) {
            return result.getBizError();
        }
        if (CollectionUtil.isEmpty(result.getViolation())) {
            return null;
        }
        return result.getViolation().stream().map(ConstraintViolation::getMessage).collect(Collectors.joining(";\n"));
    }
}
