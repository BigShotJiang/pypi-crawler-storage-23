package com.ruoyi.fileupload.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.ruoyi.fileupload.enums.FileUploadScene;
import com.ruoyi.fileupload.enums.FileUploadStatus;
import com.ruoyi.fileupload.enums.IncrementType;
import com.ruoyi.fileupload.module.domain.FileUploadRecord;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.function.Consumer;

/**
 * 文件导入记录Service接口
 * 
 * @author ruoyi
 * @date 2025-10-27
 */
public interface IFileUploadRecordService extends IService<FileUploadRecord>
{
    /**
     * 查询文件导入记录
     * 
     * @param id 文件导入记录主键
     * @return 文件导入记录
     */
    public FileUploadRecord selectFileUploadRecordById(Long id);

    /**
     * 查询文件导入记录列表
     * 
     * @param fileUploadRecord 文件导入记录
     * @return 文件导入记录集合
     */
    public List<FileUploadRecord> selectFileUploadRecordList(FileUploadRecord fileUploadRecord);

    /**
     * 新增文件导入记录
     * 
     * @param fileUploadRecord 文件导入记录
     * @return 结果
     */
    public int insertFileUploadRecord(FileUploadRecord fileUploadRecord);

    /**
     * 修改文件导入记录
     * 
     * @param fileUploadRecord 文件导入记录
     * @return 结果
     */
    public int updateFileUploadRecord(FileUploadRecord fileUploadRecord);

    /**
     * 批量删除文件导入记录
     * 
     * @param ids 需要删除的文件导入记录主键集合
     * @return 结果
     */
    public int deleteFileUploadRecordByIds(Long[] ids);

    /**
     * 删除文件导入记录信息
     * 
     * @param id 文件导入记录主键
     * @return 结果
     */
    public int deleteFileUploadRecordById(Long id);

    int increment(Long id, IncrementType type);

    int updateTotal(Long id, Long total);

    int updateStatus(Long id, FileUploadStatus status);

    <T> FileUploadRecord importExcel(FileUploadScene scene, MultipartFile file, Integer titleRows, Class<T> clazz, Consumer<T> consumer, Long userId);

    <T> FileUploadRecord importExcel(FileUploadScene scene, String fileName, byte[] fileBytes, Integer titleRows, Class<T> clazz, Consumer<T> consumer, Long userId);
}
