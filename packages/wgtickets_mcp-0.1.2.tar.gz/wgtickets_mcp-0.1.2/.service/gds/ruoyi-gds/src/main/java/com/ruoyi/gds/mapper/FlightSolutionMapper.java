package com.ruoyi.gds.mapper;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightSolution;
import org.apache.ibatis.annotations.Param;

/**
 * 行程方案Mapper接口
 *
 * @author ruoyi
 * @date 2025-09-24
 */
public interface FlightSolutionMapper extends BaseMapper<FlightSolution> {
    /**
     * 查询行程方案
     *
     * @param id 行程方案主键
     * @return 行程方案
     */
    public FlightSolution selectFlightSolutionById(Long id);

    /**
     * 查询行程方案列表
     *
     * @param flightSolution 行程方案
     * @return 行程方案集合
     */
    public List<FlightSolution> selectFlightSolutionList(FlightSolution flightSolution);

    /**
     * 新增行程方案
     *
     * @param flightSolution 行程方案
     * @return 结果
     */
    public int insertFlightSolution(FlightSolution flightSolution);

    /**
     * 修改行程方案
     *
     * @param flightSolution 行程方案
     * @return 结果
     */
    public int updateFlightSolution(FlightSolution flightSolution);

    /**
     * 删除行程方案
     *
     * @param id 行程方案主键
     * @return 结果
     */
    public int deleteFlightSolutionById(Long id);

    /**
     * 批量删除行程方案
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightSolutionByIds(Long[] ids);

    /**
     * 批量写入，重复时跳过
     * @param flightSolutions
     * @return
     */
    int batchInsert(@Param("flightSolutions") List<FlightSolution> flightSolutions);

    Integer getTripTypeBySolutionkey(@Param("solutionKey") String solutionKey);

}
