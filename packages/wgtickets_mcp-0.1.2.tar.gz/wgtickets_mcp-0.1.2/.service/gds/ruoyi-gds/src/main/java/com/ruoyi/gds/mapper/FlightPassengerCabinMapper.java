package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightPassengerCabin;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 乘机人舱位Mapper接口
 *
 * @author ruoyi
 * @date 2025-09-24
 */
public interface FlightPassengerCabinMapper extends BaseMapper<FlightPassengerCabin> {
    /**
     * 查询乘机人舱位
     *
     * @param id 乘机人舱位主键
     * @return 乘机人舱位
     */
    public FlightPassengerCabin selectFlightPassengerCabinById(Long id);

    /**
     * 查询乘机人舱位列表
     *
     * @param flightPassengerCabin 乘机人舱位
     * @return 乘机人舱位集合
     */
    public List<FlightPassengerCabin> selectFlightPassengerCabinList(FlightPassengerCabin flightPassengerCabin);

    /**
     * 新增乘机人舱位
     *
     * @param flightPassengerCabin 乘机人舱位
     * @return 结果
     */
    public int insertFlightPassengerCabin(FlightPassengerCabin flightPassengerCabin);

    /**
     * 修改乘机人舱位
     *
     * @param flightPassengerCabin 乘机人舱位
     * @return 结果
     */
    public int updateFlightPassengerCabin(FlightPassengerCabin flightPassengerCabin);

    /**
     * 删除乘机人舱位
     *
     * @param id 乘机人舱位主键
     * @return 结果
     */
    public int deleteFlightPassengerCabinById(Long id);

    /**
     * 批量删除乘机人舱位
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightPassengerCabinByIds(Long[] ids);

    /**
     * 批量写入，重复时跳过
     * @param flightPassengerCabins
     * @return
     */
    int batchInsert(@Param("flightPassengerCabins") List<FlightPassengerCabin> flightPassengerCabins);

}
