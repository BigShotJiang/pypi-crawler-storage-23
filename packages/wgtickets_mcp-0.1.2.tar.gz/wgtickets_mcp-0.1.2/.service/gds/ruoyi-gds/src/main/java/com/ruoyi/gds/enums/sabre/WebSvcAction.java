package com.ruoyi.gds.enums.sabre;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.utils.StrUtil;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum WebSvcAction {

    TokenCreateRQ("TokenCreateRQ", "2.0.0", "塞班 WebSvc Token"),

    SessionCreateRQ("SessionCreateRQ", "2.0.0", "塞班 WebSvc Session"),

    PO_PNRPricingRQ("PO_PNRPricingRQ", "1.4.4", "塞班 WebSvc 预约号查价"),

    FareLLSRQ("FareLLSRQ", "2.9.0", "塞班 WebSvc 查价"),

    OTA_AirAvailLLSRQ("OTA_AirAvailLLSRQ", "2.4.0", "塞班 WebSvc 查询舱位号及剩余数量"),

    GetReservationRQ("GetReservationRQ", "1.19.22", "提取预约信息"),

    UpdateReservationRQ("UpdateReservationRQ", "1.19.22", "更新航段状态为HK");


    @JsonValue
    private final String action;

    private final String version;

    private final String desc;

    WebSvcAction(String action, String version, String desc) {
        this.action = action;
        this.version = version;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static WebSvcAction fromCode(String action) {
        return Arrays.stream(WebSvcAction.values())
                .filter(item -> StringUtils.isNotBlank(action) && StrUtil.removeWhiteSpaces(action).equalsIgnoreCase(StrUtil.removeWhiteSpaces(item.action)))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return action + ":" + version + ":" + desc;
    }

}
