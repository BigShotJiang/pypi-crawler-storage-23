package com.ruoyi.gds.module;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.ruoyi.gds.enums.GDSType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;


@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CommonRsp<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * GDS类型
     */
    private GDSType providerCode;

    /**
     * GDS返回的原始信息
     */
    @JsonIgnore
    private String orignalInfo;

    /**
     * 错误信息
     */
    private String errMsg;

    /**
     * 转换后信息
     */
    @JsonIgnore
    private T convertInfo;

}
