package com.ruoyi.gds.enums;

public enum TicketSegmentStatus {
    // 正常
    OPEN,
    // 已废票
    VOID,
    // 已使用
    USED,
    // 已改签
    EXCHANGED,
    // 已退票
    REFUNDED
}
