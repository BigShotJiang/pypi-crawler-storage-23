package com.ruoyi.gds.controller;

import cn.hutool.core.date.DatePattern;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.gds.enums.RateType;
import com.ruoyi.gds.module.RateRecord;
import com.ruoyi.gds.service.IRateRecordService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

/**
 * 汇率Controller
 * 
 * @author ruoyi
 * @date 2025-08-11
 */
@RestController
@RequestMapping("/rate")
public class RateRecordController extends BaseController
{
    @Autowired
    private IRateRecordService rateRecordService;

    /**
     * 查询汇率列表
     */
    @GetMapping("/list")
    public TableDataInfo list(RateRecord rateRecord)
    {
        rateRecord.setRateType(RateType.JPY_TO_CNY.getCode());
        startPage();
        List<RateRecord> list = rateRecordService.selectRateRecordList(rateRecord);
        return getDataTable(list);
    }

    /**
     * 导出汇率列表
     */
    @PostMapping("/export")
    public void export(HttpServletResponse response, RateRecord rateRecord)
    {
        List<RateRecord> list = rateRecordService.selectRateRecordList(rateRecord);
        ExcelUtil<RateRecord> util = new ExcelUtil<RateRecord>(RateRecord.class);
        util.exportExcel(response, list, "汇率数据");
    }

    /**
     * 获取汇率详细信息
     */
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(rateRecordService.selectRateRecordById(id));
    }

    /**
     * 新增汇率
     */
    @PostMapping
    public AjaxResult add(@RequestBody RateRecord rateRecord)
    {
        return toAjax(rateRecordService.insertRateRecord(rateRecord));
    }

    /**
     * 修改汇率
     */
    @PutMapping
    public AjaxResult edit(@RequestBody RateRecord rateRecord)
    {
        return toAjax(rateRecordService.updateRateRecord(rateRecord));
    }

    /**
     * 删除汇率
     */
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(rateRecordService.deleteRateRecordByIds(ids));
    }

    /**
     * 查询指定日期汇率
     */
    @GetMapping("/queryRate")
    public AjaxResult queryRate(@RequestParam(required = false) String rateDate, @RequestParam(required = false) String rateType)
    {
        LocalDate date = Optional.ofNullable(rateDate)
                .filter(StringUtils::isNotBlank)
                .map(rateDate2 -> LocalDate.parse(rateDate2, DateTimeFormatter.ofPattern(DatePattern.NORM_DATE_PATTERN)))
                .orElse(LocalDate.now());
        RateType type = Optional.ofNullable(rateType)
                .filter(StringUtils::isNotBlank)
                .map(RateType::valueOf)
                .orElse(RateType.JPY_TO_CNY);
        RateRecord rateRecord = rateRecordService.selectByDate(date, type);
        return AjaxResult.success(rateRecord);
    }
}
