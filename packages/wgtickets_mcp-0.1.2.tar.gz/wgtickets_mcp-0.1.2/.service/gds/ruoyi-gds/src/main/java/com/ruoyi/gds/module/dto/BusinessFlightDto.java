package com.ruoyi.gds.module.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

/**
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BusinessFlightDto implements Serializable
{

    private static final long serialVersionUID = 1L;

    /** 业务ID（问票ID） */
    @NotEmpty(message = "业务ID为空")
    private String businessId;

    /** 出发到达集合 */
    private String departureArrival;

    /** 出发日期集合 */
    private String departureDate;

}
