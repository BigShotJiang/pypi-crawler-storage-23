package com.ruoyi.gds.module.dto.ibe;

import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.spring.SpringUtils;
import com.ruoyi.gds.config.GDSConfig;
import com.ruoyi.gds.enums.GDSType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IBEAgencyDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * agency 的 booking channe
     * <p>
     * 不填默认为 1E
     */
    private String channel;

    /**
     * 销售地
     * <p>
     * city code，不允许为空，返回结果默认为销售地所在的国家的货币代码
     */
    @NotBlank(message = "销售地不能为空")
    private String pos;

    /**
     * 八位 Iata 号
     * <p>
     * 不建议为空。若为空系统会自动匹配office 的 IATA 号，匹配不准确将影响私有价计算。
     * <p>
     * 后端从配置中获取值后赋值给此字段
     */
    private String iataNumber;

    /**
     * Office 号
     * <p>
     * 不允许为空。
     * <p>
     * 后端从配置中获取值后赋值给此字段
     */
    private String travelAgencyCode;

    /**
     * 大客户编码
     * <p>
     * 可以为空，最多 30 个
     */
    @Size(max = 30)
    private List<AccountInfo> accountCodes;

    public String getChannel() {
        return StringUtils.isNotBlank(channel) ? channel : GDSType.IBE.getCode();
    }

    public String getIataNumber() {
        return StringUtils.isNotBlank(iataNumber) ? iataNumber : SpringUtils.getBean(GDSConfig.class).getIbe().getIata();
    }

    public String getTravelAgencyCode() {
        return StringUtils.isNotBlank(travelAgencyCode) ? travelAgencyCode : SpringUtils.getBean(GDSConfig.class).getIbe().getOffice();
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class AccountInfo implements Serializable {

        private static final long serialVersionUID = 1L;

        /**
         * 航空公司编码
         */
        private String carrier;

        /**
         * 大客户编码
         */
        private String code;



        public void check() {
            if (StringUtils.isBlank(carrier) && StringUtils.isBlank(code)) {
                throw new ServiceException("航空公司编码和大客户编码必填一个", HttpStatus.BAD_REQUEST);
            }
        }
    }

}
