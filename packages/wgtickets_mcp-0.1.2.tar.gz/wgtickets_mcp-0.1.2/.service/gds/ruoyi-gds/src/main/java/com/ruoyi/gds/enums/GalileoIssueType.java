package com.ruoyi.gds.enums;

public enum GalileoIssueType {

    CreditCard,

    Cash

}
