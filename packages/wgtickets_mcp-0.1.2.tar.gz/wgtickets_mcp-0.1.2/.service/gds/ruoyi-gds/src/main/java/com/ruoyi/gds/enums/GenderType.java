package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum GenderType {

    U(0, "UNDISCLOSED", "U","UNDISCLOSED", "保密"),
    M(1, "MALE", "M","MALE","男"),
    F(2, "FEMALE", "F","FEMALE","女");

    private final Integer num;

    private final String ibeCode;

    private final String galelioCode;

    private final String sabreCode;

    private final String description;

    GenderType(Integer num, String ibeCode, String galelioCode, String sabreCode, String description) {
        this.num = num;
        this.ibeCode = ibeCode;
        this.galelioCode = galelioCode;
        this.sabreCode = sabreCode;
        this.description = description;
    }

    public static GenderType fromNum(Integer num) {
        return Arrays.stream(GenderType.values()).filter(item -> Objects.nonNull(num) && num.equals(item.num)).findFirst().orElse(null);
    }

    public static GenderType fromIbeCode(String code) {
        return Arrays.stream(GenderType.values()).filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.ibeCode)).findFirst().orElse(null);
    }

    public static GenderType fromGalelioCode(String code) {
        return Arrays.stream(GenderType.values()).filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.galelioCode)).findFirst().orElse(null);
    }

    public static GenderType fromSabreCode(String code) {
        return Arrays.stream(GenderType.values()).filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.sabreCode)).findFirst().orElse(null);
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static GenderType fromName(String name) {
        return Arrays.stream(GenderType.values()).filter(item -> StringUtils.isNotBlank(name) && name.equalsIgnoreCase(item.name())).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return ibeCode + ": " + description;
    }
    
}
