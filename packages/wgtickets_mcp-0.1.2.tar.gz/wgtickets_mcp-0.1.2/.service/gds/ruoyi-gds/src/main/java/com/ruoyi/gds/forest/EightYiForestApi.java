package com.ruoyi.gds.forest;

import com.dtflys.forest.annotation.*;
import com.ruoyi.gds.forest.interceptor.BaseInterceptor;
import com.ruoyi.gds.module.vo.eightyi.*;
import org.springframework.stereotype.Component;

@Component
@BaseRequest(
        headers = {"Accept-Charset: utf-8", "Content-Type: text/plain", "Accept-Encoding: gzip, deflate"},
        interceptor = BaseInterceptor.class
)
public interface EightYiForestApi {

    /**
     * 航程信息询价接口
     *
     * @param auditDto
     * @return
     */
    @PostRequest(url = "${eightYi_api_url_base}?action=${eightYi_api_url_query_voyage_policy_price}&account=${eightYi_api_url_account}&pid=${eightYi_api_url_pid}&sign=${sign}")
    VoyagePolicyPriceDetailVo getVoyagePolicyPrice(@Var("sign") String sign, @JSONBody VoyagePolicyPriceReq auditDto);

    /**
     * 格式化信息询价接口
     *
     * @param sign
     * @param auditDto
     * @return
     */
    @PostRequest(url = "${eightYi_api_url_base}?action=${eightYi_api_url_query_info_policy_price}&account=${eightYi_api_url_account}&pid=${eightYi_api_url_pid}&sign=${sign}")
    VoyagePolicyPriceDetailVo queryInfoPolicyPrice(@Var("sign") String sign, @JSONBody VoyageInfoPolicyPriceReq auditDto);

    /**
     * 航程信息生单接口
     *
     * @return
     */
    @PostRequest(url = "${eightYi_api_url_base}?action=${action}&account=${account}&pid=${pid}&sign=${sign}")
    VoyageCreateOrderResp voyageCreateOrder(
            @Var("action") String action,
            @Var("account") String account,
            @Var("pid") String pid,
            @Var("sign") String sign, @JSONBody VoyageCreateOrderReq createOrderReq);

    /**
     * 获取订单详情
     * @param sign
     * @param orderId
     * @return
     */
    @PostRequest(url = "${eightYi_api_url_base}?action=${action}&account=${account}&pid=${pid}&sign=${sign}")
    EightYiOrderDetailVo getOrderDetail(
            @Var("action") String action,
            @Var("account") String account,
            @Var("pid") String pid,
            @Var("sign") String sign, @JSONBody(name = "orderId") String orderId);

    /**
     * 支付前校验
     * @param sign
     * @param orderId
     * @return
     */
    @PostRequest(url = "${eightYi_api_url_base}?action=${eightYi_api_url_pay_verify_order}&account=${eightYi_api_url_account}&pid=${eightYi_api_url_pid}&sign=${sign}")
    EightYiPayBeResp payBeforeCheck(@Var("sign") String sign, @JSONBody(name = "orderId") String orderId);

    /**
     * 支付接口
     * @param sign
     * @param payDto
     * @return
     */
    @PostRequest(url = "${eightYi_api_url_base}?action=${eightYi_api_url_pay_order}&account=${eightYi_api_url_account}&pid=${eightYi_api_url_pid}&sign=${sign}")
    EightYiPayResp eightYiPay(@Var("sign") String sign, @JSONBody EightYiPayReq payDto);


    /**
     * PNR导入询价接口
     *query_pnr_policy_price
     * @param auditDto
     * @return
     */
    @PostRequest(url = "${eightYi_api_url_base}?action=${eightYi_api_url_query_pnr_policy_price}&account=${eightYi_api_url_account}&pid=${eightYi_api_url_pid}&sign=${sign}")
    VoyagePolicyPriceDetailVo queryPnrPolicyPrice(@Var("sign") String sign, @JSONBody PnrPolicyPriceReq auditDto);


    /**
     * 生成订单接口
     *create_order
     * @return
     */
    @PostRequest(url = "${eightYi_api_url_base}?action=${eightYi_api_url_create_order}&account=${eightYi_api_url_account}&pid=${eightYi_api_url_pid}&sign=${sign}")
    VoyageCreateOrderResp createOrder(@Var("sign") String sign, @JSONBody CreateOrderReq createOrderReq);
}
