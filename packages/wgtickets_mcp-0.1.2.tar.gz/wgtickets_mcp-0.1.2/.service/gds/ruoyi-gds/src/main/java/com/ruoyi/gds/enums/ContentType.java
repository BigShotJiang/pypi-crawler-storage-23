package com.ruoyi.gds.enums;

import lombok.Getter;

@Getter
public enum ContentType {

    REQUEST,

    RESPONSE
    
}
