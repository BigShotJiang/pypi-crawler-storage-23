package com.ruoyi.gds.module;

import cn.hutool.core.date.DatePattern;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.gds.module.vo.FlightTravelerVo;
import com.ruoyi.gds.module.vo.galileo.*;
import lombok.*;
import lombok.experimental.SuperBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class QueryPnrRsp<T> extends CommonRsp<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    private String pcc;

    /**
     * UniversalRecord 预定代码
     */
    private String universalRecordCode;

    /**
     * Host 预定代码。PNR
     */
    private String providerReservationCode;

    /**
     * Air 预定代码
     */
    private String airReservationCode;

    /**
     * 版本号
     */
    private BigInteger version;

    /**
     * PNR
     */
    private String pnr;

    /**
     * 大编码
     */
    private String bigPnr;

    /**
     * 行程信息
     */
    private List<FlightBookingVo> flights;

    /**
     * 报价
     */
    private BasePriceVo price;

    /**
     * 人员类型价格
     */
    private List<FlightPriceVo> passengerPrices;

    /**
     * 乘客信息
     */
    private List<FlightTravelerVo> travelers;

    /**
     * PNR过期时间
     */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime expireTime;

    /**
     * 确认PNR信息
     */
    private Object confirmInfo;

    /**
     * 是否已出票
     */
    private Boolean issued;

    /**
     * 出票信息
     */
    private List<TicketInfoVo> ticketInfos;

    /**
     * GDS PNR 标识
     */
    private String pnrSignature;

    /**
     * 运价信息
     */
    private List<QueryFlightPnrRsp> queryFlightPnrRsp;
}
