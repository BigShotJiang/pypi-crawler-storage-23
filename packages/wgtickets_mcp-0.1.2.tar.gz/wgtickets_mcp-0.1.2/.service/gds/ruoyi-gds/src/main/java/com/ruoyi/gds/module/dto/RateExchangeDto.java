package com.ruoyi.gds.module.dto;

import com.ruoyi.gds.enums.CurrencyType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RateExchangeDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 源币种
     */
    @NotNull(message = "源币种为空")
    private CurrencyType sourceCurrency;

    /**
     * 源金额
     */
    @NotNull(message = "源金额为空")
    private BigDecimal sourceAmount;

    /**
     * 目标币种
     */
    @NotNull(message = "目标币种为空")
    private CurrencyType targetCurrency;

}
