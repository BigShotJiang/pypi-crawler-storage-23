package com.ruoyi.gds.module.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

/**
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AirportsDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private List<String> areaCodes;
    private List<String> countryCodes;
    private List<String> regionCodes;
    private List<String> cityCodes;
    private List<String> airportCodes;

}
