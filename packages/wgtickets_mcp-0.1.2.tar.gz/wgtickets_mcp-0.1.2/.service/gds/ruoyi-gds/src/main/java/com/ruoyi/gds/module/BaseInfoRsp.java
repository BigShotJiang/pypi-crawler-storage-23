package com.ruoyi.gds.module;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BaseInfoRsp<T>  implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 响应码
     * 1000	请求成功
     * 1001	内部异常
     * 1002	内部异常
     * 1003	缺少必填参数
     * 1004	航班号格式不正确
     * 1005	机场三字码格式不正确
     * 1006	日期格式不正确
     * 1007	暂无数据权限
     * 1008	无效的用户
     * 1009	token验证失败
     * 1010	IP未加入白名单:x.x.x.x
     * 1500	服务内部错误
     */
    private String code;

    private String message;

    private T data;
}
