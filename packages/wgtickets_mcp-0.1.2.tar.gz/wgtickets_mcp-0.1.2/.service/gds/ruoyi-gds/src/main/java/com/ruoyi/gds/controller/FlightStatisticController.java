package com.ruoyi.gds.controller;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.gds.module.domain.FlightStatistic;
import com.ruoyi.gds.service.IFlightStatisticService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 航班统计Controller
 * 
 * @author ruoyi
 * @date 2025-04-14
 */
@RestController
@RequestMapping("/flight/statistic")
public class FlightStatisticController extends BaseController
{
    @Autowired
    private IFlightStatisticService flightStatisticService;

    /**
     * 查询航班统计列表
     */
    @GetMapping("/list")
    public TableDataInfo list(FlightStatistic flightStatistic)
    {
        startPage();
        List<FlightStatistic> list = flightStatisticService.selectFlightStatisticList(flightStatistic);
        return getDataTable(list);
    }

    /**
     * 导出航班统计列表
     */
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightStatistic flightStatistic)
    {
        List<FlightStatistic> list = flightStatisticService.selectFlightStatisticList(flightStatistic);
        ExcelUtil<FlightStatistic> util = new ExcelUtil<FlightStatistic>(FlightStatistic.class);
        util.exportExcel(response, list, "航班统计数据");
    }

    /**
     * 获取航班统计详细信息
     */
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(flightStatisticService.selectFlightStatisticById(id));
    }

    /**
     * 新增航班统计
     */
    @PostMapping
    public AjaxResult add(@RequestBody FlightStatistic flightStatistic)
    {
        return toAjax(flightStatisticService.insertFlightStatistic(flightStatistic));
    }

    /**
     * 修改航班统计
     */
    @PutMapping
    public AjaxResult edit(@RequestBody FlightStatistic flightStatistic)
    {
        return toAjax(flightStatisticService.updateFlightStatistic(flightStatistic));
    }

    /**
     * 删除航班统计
     */
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(flightStatisticService.deleteFlightStatisticByIds(ids));
    }
}
