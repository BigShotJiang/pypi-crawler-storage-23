package com.ruoyi.gds.controller;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.common.utils.ServletUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.ValidatorUtil;
import com.ruoyi.gds.annotation.FlightLog;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.enums.*;
import com.ruoyi.gds.enums.ibe.SearchPriceCallerType;
import com.ruoyi.gds.module.*;
import com.ruoyi.gds.module.domain.CallbackRecord;
import com.ruoyi.gds.module.dto.CabinScanDto;
import com.ruoyi.gds.module.dto.FixedFlightFareDto;
import com.ruoyi.gds.module.dto.validation.AIR;
import com.ruoyi.gds.module.dto.validation.AIRBatchSearciPrice;
import com.ruoyi.gds.module.vo.*;
import com.ruoyi.gds.module.vo.aggregation.GdsFlightVo;
import com.ruoyi.gds.module.vo.galileo.BaseFlightVo;
import com.ruoyi.gds.service.AirService;
import com.ruoyi.gds.service.ICallbackRecordService;
import com.ruoyi.gds.utils.IntConvertUtil;
import com.ruoyi.gds.utils.RedisUtil;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Anonymous
@RestController
@RequestMapping("/air")
public class AirController {

    @Autowired
    private AirService airService;
    @Autowired
    private RedisUtil redisUtil;
    @Autowired
    private ICallbackRecordService callbackRecordService;

    /**
     * 搜索航班
     *
     * @param searchFlightReq
     * @return
     */
    @FlightLog(type = FlightReqType.SEARCH_FLIGHT)
    @PostMapping(value = "/searchFlight")
    public AjaxResult searchFlight(@RequestBody SearchFlightReq searchFlightReq) {
        if (StringUtils.isBlank(searchFlightReq.getBatchCode())) {
            if (Objects.isNull(searchFlightReq.getTripType())) {
                throw new ServiceException("行程类型为空", HttpStatus.BAD_REQUEST);
            }
            if (CollectionUtil.isEmpty(searchFlightReq.getFlights())) {
                throw new ServiceException("行程信息为空", HttpStatus.BAD_REQUEST);
            }
            if (CollectionUtil.isEmpty(searchFlightReq.getPassengers())) {
                throw new ServiceException("乘客信息为空", HttpStatus.BAD_REQUEST);
            }
        }

        List<GdsFlightVo> flightPlantVos = airService.searchFlight(searchFlightReq);
        return AjaxResult.success(flightPlantVos);
    }

    /**
     * 常规搜索航班（航线查询）
     *
     * @param searchFlightReq
     * @return
     */
    @FlightLog(type = FlightReqType.SEARCH_FLIGHT)
    @PostMapping(value = "/normalSearchFlight")
    public AjaxResult normalSearchFlight(@RequestBody SearchFlightReq searchFlightReq) {
        if (StringUtils.isBlank(searchFlightReq.getBatchCode())) {
            if (Objects.isNull(searchFlightReq.getSearchType())) {
                throw new ServiceException("搜索方式为空", HttpStatus.BAD_REQUEST);
            }
            if (StringUtils.isBlank(searchFlightReq.getBusinessId())) {
                throw new ServiceException("业务ID为空", HttpStatus.BAD_REQUEST);
            }
            if (Objects.isNull(searchFlightReq.getTripType())) {
                throw new ServiceException("行程类型为空", HttpStatus.BAD_REQUEST);
            }
            if (CollectionUtil.isEmpty(searchFlightReq.getFlights())) {
                throw new ServiceException("行程信息为空", HttpStatus.BAD_REQUEST);
            }
            if (CollectionUtil.isEmpty(searchFlightReq.getPassengers())) {
                throw new ServiceException("乘客信息为空", HttpStatus.BAD_REQUEST);
            }
        }

        Map<String, LinkedHashMap<String, SearchFlightVo>> resultMap = airService.normalSearchFlight(searchFlightReq);
        return AjaxResult.success(resultMap);
    }

    /**
     * 批量搜索航班
     *
     * @param batchSearchFlightReq
     * @return
     */
    @FlightLog(type = FlightReqType.BATCH_SEARCH_FLIGHT)
    @PostMapping(value = "/batchSearchFlight")
    public AjaxResult batchSearchFlight(@RequestBody BatchSearchFlightReq batchSearchFlightReq) {
        if (StringUtils.isBlank(batchSearchFlightReq.getBatchCode())) {
            String errorMsg = ValidatorUtil.validate(batchSearchFlightReq);
            if (StringUtils.isNotBlank(errorMsg)) {
                throw new ServiceException(errorMsg, HttpStatus.BAD_REQUEST);
            }

            if (TripType.SINGLE.equals(batchSearchFlightReq.getTripType())) {
                List<FlightDateVo> flightDateVoList = batchSearchFlightReq.getFlightDates().stream().map(flightDateVo -> {
                    FlightDateVo dateVo = FlightDateVo.builder().outboundDate(flightDateVo.getOutboundDate()).build();
                    List<FlightDateVo> flightDateVos = Lists.newArrayList(dateVo);
                    if (Objects.nonNull(flightDateVo.getInboundDate())) {
                        LocalDate day = flightDateVo.getOutboundDate().plusDays(1);
                        while (!flightDateVo.getInboundDate().isBefore(day)) {
                            FlightDateVo flightDate = FlightDateVo.builder().outboundDate(day).build();
                            flightDateVos.add(flightDate);
                            day = day.plusDays(1);
                        }
                    }
                    return flightDateVos;
                }).collect(ArrayList::new, List::addAll, List::addAll);

                batchSearchFlightReq.setFlightDates(flightDateVoList);
            }
        }

        Map<String, LinkedHashMap<String, SearchFlightVo>> map = airService.batchSearchFlight(batchSearchFlightReq);
        return AjaxResult.success(map);
    }

    /**
     * 指令搜索航班
     *
     * @param commandSearchFlightReq
     * @return
     */
    @FlightLog(type = FlightReqType.COMMAND_SEARCH_FLIGHT)
    @PostMapping(value = "/commandSearchFlight")
    public AjaxResult commandSearchFlight(@RequestBody @Validated CommandSearchFlightReq commandSearchFlightReq) {
        Map<String, LinkedHashMap<String, SearchFlightVo>> map = airService.commandSearchFlight(commandSearchFlightReq);
        return AjaxResult.success(map);
    }

    /**
     * 根据行程方案报价key获取行程信息
     * @param solutionFareKey
     * @return
     */
    @GetMapping(value = "/getSolution")
    public AjaxResult getSolution(@RequestParam String solutionFareKey) {
        if (!IntConvertUtil.isNumber(solutionFareKey)) throw new ServiceException("行程方案报价Key为空", HttpStatus.BAD_REQUEST);
        GdsFlightVo gdsFlightVo = airService.querySolution(solutionFareKey);
        return AjaxResult.success(gdsFlightVo);
    }

    /**
     * 解析搜索航班指令
     *
     * @param commandSearchFlightReq
     * @return
     */
    @PostMapping(value = "/parseSearchCommand")
    public AjaxResult parseSearchCommand(@RequestBody @Validated CommandSearchFlightReq commandSearchFlightReq) {
        ParseCommandVo parseCommandVo = airService.parseSearchCommand(commandSearchFlightReq);
        String json = JacksonUtil.toJsonStringNoNull(parseCommandVo.getSearchFlightReqs());
        List<HashMap> maps = JacksonUtil.toBeanList(json, HashMap.class);
        return AjaxResult.success(maps);
    }

    /**
     * 根据业务ID查询批量搜索航班结果
     *
     * @param businessId
     * @return
     */
    @GetMapping(value = "/batchSearchFlight/{businessId}")
    public AjaxResult batchSearchFlight(@PathVariable String businessId) {
        SearchFlightReqRsp searchFlightReqRsp = airService.getBatchSearchFlightResult(businessId);
        return AjaxResult.success(searchFlightReqRsp);
    }

    /**
     * 查询指定(收藏)的航班信息
     *
     * @param fixedFlightFareDtos
     * @return
     */
    @PostMapping(value = "/getFixedFlight")
    public AjaxResult getFixedFlight(@RequestBody List<FixedFlightFareDto> fixedFlightFareDtos) {
        if (CollectionUtil.isEmpty(fixedFlightFareDtos)) {
            return AjaxResult.success();
        }

        List<GdsFlightVo> gdsFlightVos = airService.getFixedFlight(fixedFlightFareDtos);
        return AjaxResult.success(gdsFlightVos);
    }

    /**
     * 查询航班价格
     *
     * @param searchPriceReq
     * @return
     */
    @FlightLog(type = FlightReqType.SEARCH_PRICE)
    @PostMapping(value = "/searchFlightPrice")
    public AjaxResult searchLowPrice(@RequestBody @Validated(value = AIR.class) SearchPriceReq searchPriceReq) {
        redisUtil.solutionQueryCountIncrement(searchPriceReq.getFlightKey());
        searchPriceReq.setCaller(SearchPriceCallerType.USER);
        SearchPriceRsp<Object> searchPriceRsp = airService.searchLowPrice(searchPriceReq);
        return AjaxResult.success(searchPriceRsp);
    }

    /**
     * 批量查询航班价格
     *
     * @param searchPriceReqs
     * @return
     */
    @FlightLog(type = FlightReqType.BATCH_SEARCH_PRICE)
    @PostMapping(value = "/batchSearchFlightPrice")
    public AjaxResult batchSearchLowPrice(@RequestBody @Validated(AIRBatchSearciPrice.class) List<SearchPriceReq> searchPriceReqs) {
        if (CollectionUtil.isNotEmpty(searchPriceReqs)) {
            searchPriceReqs.forEach(searchPriceReq -> searchPriceReq.setCaller(SearchPriceCallerType.USER));
        }
        List<SearchPriceRsp<Object>> searchPriceRsps = airService.batchSearchLowPrice(searchPriceReqs);
        return AjaxResult.success(searchPriceRsps);
    }

    /**
     * 根据某GDS的行程及舱位查询指定GDS的报价
     *
     * @param searchPriceReq
     * @return
     */
    @PostMapping(value = "/searchLowPriceForSpecifyGDS")
    public AjaxResult searchLowPriceForSpecifyGDS(@RequestBody SearchPriceReq searchPriceReq) {
        searchPriceReq.setCaller(SearchPriceCallerType.USER);
        List<SearchPriceRsp<Object>> searchPriceRsps = airService.searchLowPriceForSpecifyGDS(searchPriceReq);
        return AjaxResult.success(searchPriceRsps);
    }

    /**
     * 查询舱位数量
     *
     * @param searchReq
     * @return
     */
    @PostMapping(value = "/searchCabinQuantity")
    public AjaxResult searchCabinQuantity(@RequestBody @Validated(value = AIR.class) SearchCabinQuantityReq searchReq) {
        SearchCabinQuantityRsp searchRsp = airService.searchCabinQuantity(searchReq);

        Map<String, List<CarrierCabinQuantityBaseVo>> carrierMap = Optional.ofNullable(searchRsp)
                .map(SearchCabinQuantityRsp::getCabins)
                .map(cabins -> cabins.stream().map(cabin -> CarrierCabinQuantityBaseVo.builder()
                        .carrier(cabin.getCarrier())
                        .flightNumber(cabin.getFlightNumber())
                        .cabin(cabin.getCabin())
                        .quantity(cabin.getQuantity())
                        .build()).collect(Collectors.<CarrierCabinQuantityBaseVo>toList()))
                .map(cabins -> cabins.stream().collect(Collectors.groupingBy(o -> o.getCarrier() + o.getFlightNumber())))
                .orElse(new HashMap<>());

        return AjaxResult.success(carrierMap);
    }

    /**
     * 查询舱位号
     *
     * @param searchReq
     * @return
     */
    @PostMapping(value = "/searchCabin")
    public AjaxResult searchCabin(@RequestBody SearchCabinReq searchReq) {
        LinkedList<FlightNumberCabinVo> cabinVos = airService.searchCabin(searchReq);
        return AjaxResult.success(cabinVos);
    }

    /**
     * 创建PNR前校验
     *
     * @param createPnrReq
     * @return
     */
    @PostMapping(value = "/createPnrCheck")
    public AjaxResult createPnrCheck(@RequestBody CreatePnrReq createPnrReq) {
        if (StringUtils.isNull(createPnrReq.getReservationId())) {
            String validate = ValidatorUtil.validate(createPnrReq, AIR.class);
            if (StringUtils.isNotBlank(validate)) {
                throw new ServiceException(validate, HttpStatus.BAD_REQUEST);
            }
        }

        List<CreatePnrPreCheckResultVo> resultVos = airService.createPnrPreCheck(createPnrReq);
        return AjaxResult.success(resultVos);
    }

    /**
     * 创建PNR
     *
     * @param createPnrReq
     * @return
     */
    @FlightLog(type = FlightReqType.CREATE_PNR)
    @PostMapping(value = "/createPnr")
    public AjaxResult createPnr(@RequestBody CreatePnrReq createPnrReq) {
        if (StringUtils.isNull(createPnrReq.getReservationId())) {
            String validate = ValidatorUtil.validate(createPnrReq, AIR.class);
            if (StringUtils.isNotBlank(validate)) {
                throw new ServiceException(validate, HttpStatus.BAD_REQUEST);
            }
        }

        /*if (Objects.nonNull(createPnrReq.getBusinessScene())) {
            Optional.ofNullable(ServletUtils.getHeader(CommonConstant.HEADER_BUSINESS_SCENE))
                    .map(BusinessScene::fromCode)
                    .ifPresent(createPnrReq::setBusinessScene);
        }
        if (StringUtils.isBlank(createPnrReq.getBusinessId())) {
            Optional.ofNullable(ServletUtils.getHeader(CommonConstant.HEADER_BUSINESS_ID))
                    .filter(StringUtils::isNotBlank)
                    .ifPresent(createPnrReq::setBusinessId);
        }*/

        CreatePnrRsp<Object> createPnrRsp = airService.createPnr(createPnrReq);

        if (StringUtils.isNotBlank(createPnrRsp.getWarning())) {
            throw new ServiceException(createPnrRsp.getWarning(), HttpStatus.ERROR);
        }

        return StringUtils.isNotBlank(createPnrRsp.getPnr())
                ? AjaxResult.success(createPnrRsp.getPnr(), createPnrRsp)
                : Optional.ofNullable(createPnrRsp.getErrMsg()).map(errMsg -> AjaxResult.error(errMsg, createPnrRsp)).orElse(AjaxResult.error("预定失败", createPnrRsp));
    }

    /**
     * 根据行程及乘机人创建新PNR
     *
     * @param createNewPnrByFlightReq
     * @return
     */
    @FlightLog(type = FlightReqType.CREATE_PNR)
    @PostMapping(value = "/createNewPnrByFlight")
    public AjaxResult createNewPnrByFlight(@RequestBody @Validated CreateNewPnrByFlightReq createNewPnrByFlightReq) {
        /*if (Objects.nonNull(createNewPnrByFlightReq.getBusinessScene())) {
            Optional.ofNullable(ServletUtils.getHeader(CommonConstant.HEADER_BUSINESS_SCENE))
                    .map(BusinessScene::fromCode)
                    .ifPresent(createNewPnrByFlightReq::setBusinessScene);
        }
        if (StringUtils.isBlank(createNewPnrByFlightReq.getBusinessId())) {
            Optional.ofNullable(ServletUtils.getHeader(CommonConstant.HEADER_BUSINESS_ID))
                    .filter(StringUtils::isNotBlank)
                    .ifPresent(createNewPnrByFlightReq::setBusinessId);
        }*/

        CreatePnrRsp<Object> createPnrRsp = airService.createNewPnrByFlight(createNewPnrByFlightReq);
        CreatePnrBaseVo createPnrBaseVo = CreatePnrBaseVo.builder().pnr(createPnrRsp.getPnr()).bigPnr(createPnrRsp.getBigPnr()).cancelPnr(createPnrRsp.getCancelPnrDto()).build();
        return StringUtils.isNotBlank(createPnrRsp.getPnr())
                ? AjaxResult.success(createPnrBaseVo)
                : Optional.ofNullable(createPnrRsp.getErrMsg()).map(errMsg -> AjaxResult.error(errMsg, createPnrRsp.getReservationId())).orElse(AjaxResult.error("预定失败", createPnrRsp.getReservationId()));
    }

    /**
     * 根据原PNR创建新PNR
     *
     * @param createNewPnrByPnrReq
     * @return
     */
    @FlightLog(type = FlightReqType.CREATE_PNR)
    @PostMapping(value = "/createNewPnrByPnr")
    public AjaxResult createNewPnrByPnr(@RequestBody @Validated CreateNewPnrByPnrReq createNewPnrByPnrReq) {
        /*if (Objects.nonNull(createNewPnrByPnrReq.getBusinessScene())) {
            Optional.ofNullable(ServletUtils.getHeader(CommonConstant.HEADER_BUSINESS_SCENE))
                    .map(BusinessScene::fromCode)
                    .ifPresent(createNewPnrByPnrReq::setBusinessScene);
        }
        if (StringUtils.isBlank(createNewPnrByPnrReq.getBusinessId())) {
            Optional.ofNullable(ServletUtils.getHeader(CommonConstant.HEADER_BUSINESS_ID))
                    .filter(StringUtils::isNotBlank)
                    .ifPresent(createNewPnrByPnrReq::setBusinessId);
        }*/
        CreatePnrRsp<Object> createPnrRsp = airService.createNewPnrByPnr(createNewPnrByPnrReq);
        CreatePnrBaseVo createPnrBaseVo = CreatePnrBaseVo.builder().pnr(createPnrRsp.getPnr()).bigPnr(createPnrRsp.getBigPnr()).cancelPnr(createPnrRsp.getCancelPnrDto()).build();
        return StringUtils.isNotBlank(createPnrRsp.getPnr())
                ? AjaxResult.success(createPnrBaseVo)
                : Optional.ofNullable(createPnrRsp.getErrMsg()).map(errMsg -> AjaxResult.error(errMsg, createPnrRsp.getReservationId())).orElse(AjaxResult.error("预定失败", createPnrRsp.getReservationId()));
    }

    /**
     * 查询PNR
     *
     * @param queryPnrInfoReq
     * @return
     */
    @PostMapping(value = "/queryPnr")
    public AjaxResult queryPnr(@RequestBody @Validated QueryPnrInfoReq queryPnrInfoReq) {
        QueryPnrRsp<Object> pnrRsp = airService.queryPnr(queryPnrInfoReq);
        return AjaxResult.success(pnrRsp);
    }

    /**
     * 查询GDS PNR原始报文
     *
     * @param queryPnrInfoReq
     * @return
     */
    @PostMapping(value = "/pnrOriginalInfo")
    public AjaxResult pnrOriginalInfo(@RequestBody @Validated QueryPnrInfoReq queryPnrInfoReq) {
        Object pnrOriginalInfo = airService.pnrOriginalInfo(queryPnrInfoReq);
        return AjaxResult.success(null, pnrOriginalInfo);
    }

    /**
     * 整理航段状态
     *
     * @param queryPnrInfoReq
     * @return
     */
    @PostMapping(value = "/organizeSegmentStatus")
    public AjaxResult organizeSegmentStatus(@RequestBody @Validated QueryPnrInfoReq queryPnrInfoReq) {
        OrganizeSegmentStatusRsp<Object> organizeSegmentStatusRsp = airService.organizeSegmentStatus(queryPnrInfoReq);
        return Objects.nonNull(organizeSegmentStatusRsp) && StringUtils.isNotBlank(organizeSegmentStatusRsp.getErrMsg())
                ? AjaxResult.error(organizeSegmentStatusRsp.getErrMsg())
                : AjaxResult.success();
    }

    /**
     * 查询PNR乘机人票号
     *
     * @param queryPnrInfoReq
     * @return
     */
    @PostMapping(value = "/queryPnrTicketNo")
    public AjaxResult queryPnrTicketNo(@RequestBody @Validated QueryPnrInfoReq queryPnrInfoReq){
        List<PnrTravelerTicketNoVo> travelerTicketNoVos = airService.queryPnrTicketNo(queryPnrInfoReq);
        return AjaxResult.success(travelerTicketNoVos);
    }

    /**
     * 根据票号提取信息
     *
     * @param queryTicketNumberInfoReq
     * @return
     */
    @PostMapping(value = "/queryTicketNumberInfo")
    public AjaxResult queryTicketNumberInfo(@RequestBody QueryTicketNumberInfoReq queryTicketNumberInfoReq){
        if (StringUtils.isBlank(queryTicketNumberInfoReq.getPnr())) {
            throw new ServiceException("PNR为空", HttpStatus.BAD_REQUEST);
        }
        if (CollectionUtil.isEmpty(queryTicketNumberInfoReq.getTicketNumbers())) {
            throw new ServiceException("票号为空", HttpStatus.BAD_REQUEST);
        }
        QueryTicketNumberInfoRsp<Object> queryTicketNumberInfoRsp = airService.queryTicketNumberInfo(queryTicketNumberInfoReq);
        return AjaxResult.success(queryTicketNumberInfoRsp);
    }

    /**
     * 查询已出票PNR
     *
     * @param queryPnrInfoReq
     * @return
     */
    @PostMapping(value = "/queryIssuedPnr")
    public AjaxResult queryIssuedPnr(@RequestBody @Validated QueryPnrInfoReq queryPnrInfoReq) {
        QueryPnrRsp<Object> pnrRsp = airService.queryIssuedPnr(queryPnrInfoReq);
        return AjaxResult.success(pnrRsp);
    }

    /**
     * 查询PNR的行程
     *
     * @param queryPnrInfoReq
     * @return
     */
    @PostMapping(value = "/queryPnrSegment")
    public AjaxResult queryPnrSegment(@RequestBody @Validated QueryPnrInfoReq queryPnrInfoReq) {
        List<BaseFlightVo> flightVos = airService.queryPnrSegment(queryPnrInfoReq);
        return AjaxResult.success(flightVos);
    }

    /**
     * 查询PNR的行程和乘机人
     *
     * @param queryPnrInfoReq
     * @return
     */
    @PostMapping(value = "/queryPnrSegmentTraveler")
    public AjaxResult queryPnrSegmentTraveler(@RequestBody @Validated QueryPnrInfoReq queryPnrInfoReq) {
        QueryPnrBaseRsp queryPnrBaseRsp = airService.queryPnrSegmentTraveler(queryPnrInfoReq);
        return AjaxResult.success(queryPnrBaseRsp);
    }

    /**
     * 查询PNR存储的报价
     *
     * @param queryPnrInfoReq
     * @return
     */
    @PostMapping(value = "/queryPnrPrice")
    public AjaxResult queryPnrPrice(@RequestBody @Validated QueryPnrInfoReq queryPnrInfoReq) {
        SearchPriceRsp searchPriceRsp = airService.queryPnrPrice(queryPnrInfoReq);
        return AjaxResult.success(searchPriceRsp);
    }

    /**
     * 根据PNR行程查报价
     *
     * @param queryPnrInfoReq
     * @return
     */
    @PostMapping(value = "/queryPriceByPnr")
    public AjaxResult queryPriceByPnr(@RequestBody @Validated QueryPnrInfoReq queryPnrInfoReq) {
        SearchPriceRsp searchPriceRsp = airService.queryPriceByPnr(queryPnrInfoReq);
        return AjaxResult.success(searchPriceRsp);
    }

    /**
     * 根据PNR行程及乘机人查指定GDS的报价
     *
     * @param queryFixedGdsPriceReq
     * @return
     */
    @PostMapping(value = "/queryFixedGdsPrice")
    public AjaxResult queryFixedGdsPrice(@RequestBody @Validated QueryFixedGdsPriceReq queryFixedGdsPriceReq) {
        List<PriceVo> priceVos = airService.queryPnrPriceByFixedGds(queryFixedGdsPriceReq);
        return AjaxResult.success(priceVos);
    }

    /**
     * 查询PNR过期时间
     *
     * @param pnr
     * @return
     */
    @GetMapping(value = "/pnrExpireTime")
    public AjaxResult pnrExpireTime(@RequestParam(required = false) String gds, @RequestParam String pnr) {
        if (StringUtils.isNotBlank(gds) && Objects.isNull(GDSType.fromCode(gds))) {
            throw new ServiceException("gds错误", HttpStatus.BAD_REQUEST);
        }
        if (StringUtils.isBlank(pnr)) {
            throw new ServiceException("PNR为空", HttpStatus.BAD_REQUEST);
        }
        if (pnr.length() != 6) {
            throw new ServiceException("PNR格式错误", HttpStatus.BAD_REQUEST);
        }

        QueryPnrInfoReq queryPnrInfoReq = QueryPnrInfoReq.builder().gds(GDSType.fromCode(gds)).pnr(pnr).build();
        LocalDateTime expireTime = airService.queryPnrExpireTime(queryPnrInfoReq);
        Object expireTimetr = Optional.ofNullable(expireTime)
                .map(time -> time.format(DateTimeFormatter.ofPattern(DatePattern.NORM_DATETIME_PATTERN)))
                .orElse(null);

        return AjaxResult.success(expireTimetr);
    }

    /**
     * 取消PNR
     *
     * @param pnr
     * @return
     */
    @FlightLog(type = FlightReqType.CANCEL_PNR)
    @GetMapping(value = "/cancelPnr")
    public AjaxResult cancelPnr(@RequestParam String pnr) {
        return airService.cancelPnr(pnr);
    }

//    /**
//     * 出票前校验
//     *
//     * @param queryPnrInfoReq
//     * @return
//     */
//    @PostMapping(value = "/issueTicketCheck")
//    public AjaxResult issueTicketCheck(@RequestBody @Validated QueryPnrInfoReq queryPnrInfoReq) {
//        airService.issueTicketCheck(queryPnrInfoReq);
//        return AjaxResult.success();
//    }

    /**
     * 出票
     *
     * @param issueTicketReq
     * @return
     */
    @FlightLog(type = FlightReqType.ISSUE_TICKET)
    @PostMapping(value = "/issueTicket")
    public AjaxResult issueTicket(@RequestBody @Validated IssueTicketReq issueTicketReq) {
        log.info("出票入参: {}", JacksonUtil.toJsonString(issueTicketReq));
        SearchPriceRsp<Object> issueTicketRsp = airService.issueTicket(issueTicketReq);
        return AjaxResult.success(issueTicketRsp);
    }

    /**
     * 搜索条件选项
     *
     * @param batchCode
     * @param optionType
     * @return
     */
    @GetMapping(value = "/options")
    public AjaxResult options(@RequestParam String batchCode, @RequestParam Integer optionType) {
        FlightSearchOptionType searchOptionType = FlightSearchOptionType.fromCode(optionType);
        if (Objects.isNull(searchOptionType)) {
            throw new ServiceException("选项类型错误", HttpStatus.BAD_REQUEST);
        }

        List<LabelNameVo> options = airService.options(batchCode, searchOptionType);

        return AjaxResult.success(options);
    }

    /**
     * 扫舱——OTA专用
     *
     * @param cabinScanDto
     * @return
     */
    @PostMapping(value = "/cabinScan")
    public CabinScanVo cabinScan(@RequestBody CabinScanDto cabinScanDto) {
        String errMsg = ValidatorUtil.validate(cabinScanDto);
        if (StringUtils.isNotBlank(errMsg)) {
            return CabinScanVo.builder()
                    .taskId(cabinScanDto.getTaskId())
                    .ruleId(cabinScanDto.getRuleId())
                    .orderSerialNo(cabinScanDto.getOrderSerialNo())
                    .errMsg(errMsg)
                    .build();
        }

        return airService.cabinScan(cabinScanDto);
    }

    /**
     * 查询PNR航变信息
     *
     * @param flightChange
     * @return
     */
    @PostMapping(value = "/queryFlightChange")
    public AjaxResult queryFlightChange(@RequestBody @Validated FlightChangeVo flightChange) {
        List<FlightChangeResultVo> changeResultVos = airService.queryFlightChange(flightChange);
        return AjaxResult.success(changeResultVos);
    }

    /**
     * 判断是否为国际航段
     * @param segmentVos
     * @return
     */
    @PostMapping(value = "/internationalSegment")
    public AjaxResult internationalSegmentHandle(@RequestBody @Validated List<@Valid InternationalSegmentVo> segmentVos){
        List<InternationalSegmentVo> internationalSegmentVos = airService.internationalSegmentHandle(segmentVos);
        return  AjaxResult.success(internationalSegmentVos);
    }

    /**
     * 获取大客户编码和TC编码
     * @param queryPnrInfoReq
     * @return
     */
    @PostMapping(value = "/getFareCode")
    public AjaxResult getFareCode(@RequestBody @Validated QueryPnrInfoReq queryPnrInfoReq) {
        FareCodeVo fareCode = airService.getFareCode(queryPnrInfoReq);
        return AjaxResult.success(fareCode);
    }

    /**
     * 支付订单
     */
    @PostMapping(value = "/payOrder")
    public AjaxResult payOrder(@RequestBody @Validated PayOrderReq payOrderReq) {
        CallbackRecord callbackRecord = CallbackRecord.builder()
                .orderSn(payOrderReq.getOrderId())
                .price(payOrderReq.getTotalPrice())
                .gds(payOrderReq.getGds().getCode())
                .platform("TICKET")
                .build();
        callbackRecordService.insertCallbackRecord(callbackRecord);
        return AjaxResult.success(airService.payOrder(payOrderReq));
    }

    /**
     * 开票支付合并
     */
    @PostMapping(value = "/payOrderAndIssueTicket")
    public AjaxResult payOrderAndIssueTicket(@RequestBody @Validated IssueTicketReq issueTicketReq) {
        SearchPriceRsp<Object> issueTicketRsp = airService.issueTicket(issueTicketReq);
        if (StringUtils.isBlank(issueTicketRsp.getOrderId())) {
            return AjaxResult.error("出票失败");
        }
        PayOrderReq payOrderReq = PayOrderReq.builder()
                .orderId(issueTicketRsp.getOrderId())
                .totalPrice(issueTicketReq.getIssueAmount())
                .gds(issueTicketReq.getGds())
                .build();

        CallbackRecord callbackRecord = CallbackRecord.builder()
                .orderSn(issueTicketReq.getOrderNo())
                .price(issueTicketReq.getIssueAmount())
                .gds(issueTicketReq.getGds().getCode())
                .platform("OTA")
                .build();
        callbackRecordService.insertCallbackRecord(callbackRecord);
        return AjaxResult.success(airService.payOrder(payOrderReq));
    }

}
