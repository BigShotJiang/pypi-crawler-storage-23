package com.ruoyi.gds.mapper;

import com.ruoyi.gds.module.domain.FlightReqLog;
import com.ruoyi.gds.module.dto.FlightReqLogSearchDto;
import com.ruoyi.gds.module.vo.FlightReqLogStatistic;

import java.util.List;

/**
 * 机票预定使用记录Mapper接口
 * 
 * @author ruoyi
 * @date 2025-05-19
 */
public interface FlightReqLogMapper 
{
    /**
     * 查询机票预定使用记录
     * 
     * @param id 机票预定使用记录主键
     * @return 机票预定使用记录
     */
    public FlightReqLog selectFlightReqLogById(Long id);

    /**
     * 查询机票预定使用记录列表
     * 
     * @param flightReqLog 机票预定使用记录
     * @return 机票预定使用记录集合
     */
    public List<FlightReqLog> selectFlightReqLogList(FlightReqLog flightReqLog);

    /**
     * 新增机票预定使用记录
     * 
     * @param flightReqLog 机票预定使用记录
     * @return 结果
     */
    public int insertFlightReqLog(FlightReqLog flightReqLog);

    /**
     * 修改机票预定使用记录
     * 
     * @param flightReqLog 机票预定使用记录
     * @return 结果
     */
    public int updateFlightReqLog(FlightReqLog flightReqLog);

    /**
     * 删除机票预定使用记录
     * 
     * @param id 机票预定使用记录主键
     * @return 结果
     */
    public int deleteFlightReqLogById(Long id);

    /**
     * 批量删除机票预定使用记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightReqLogByIds(Long[] ids);

    List<FlightReqLogStatistic> statistic(FlightReqLogSearchDto searchDto);

}
