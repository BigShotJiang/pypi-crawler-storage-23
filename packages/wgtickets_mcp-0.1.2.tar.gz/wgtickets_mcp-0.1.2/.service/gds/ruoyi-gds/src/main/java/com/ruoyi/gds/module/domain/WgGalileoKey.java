package com.ruoyi.gds.module.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 歪裹Key与伽利略Key对照对象 wg_galileo_key
 * 
 * @author ruoyi
 * @date 2025-10-29
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WgGalileoKey implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 搜索条件Key */
    @Excel(name = "搜索条件Key")
    private String searchParamKey;

    /** 伽利略KEY类型（AIR_PRICING_SOLUTION_KEY, SEGMENT_KEY） */
    @Excel(name = "伽利略KEY类型", readConverterExp = "A=IR_PRICING_SOLUTION_KEY,,S=EGMENT_KEY")
    private String keyType;

    /** 歪裹Key(solutionKey、 segmentKey) */
    @Excel(name = "歪裹Key(solutionKey、 segmentKey)")
    private String wgKey;

    /** 伽利略Key */
    @Excel(name = "伽利略Key")
    private String galileoKey;

    /**
     * 创建人
     */
    private Long createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新人
     */
    private Long updateBy;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;

}
