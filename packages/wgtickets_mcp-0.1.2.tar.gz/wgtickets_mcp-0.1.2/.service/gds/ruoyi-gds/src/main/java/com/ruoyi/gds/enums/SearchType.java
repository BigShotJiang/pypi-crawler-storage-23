package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum SearchType {

    NORMAL(1, "航线查询"),
    BATCH(2, "批量查询"),
    COMMAND(3, "指令查询");

    @JsonValue
    private final int code;

    private final String desc;

    SearchType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static SearchType fromCode(int code) {
        return Arrays.stream(SearchType.values()).filter(item -> code == item.code).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
