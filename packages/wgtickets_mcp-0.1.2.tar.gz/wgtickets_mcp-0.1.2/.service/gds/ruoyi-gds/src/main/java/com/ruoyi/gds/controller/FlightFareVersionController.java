package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.gds.module.domain.FlightFareVersion;
import com.ruoyi.gds.service.IFlightFareVersionService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 行程报价版本Controller
 * 
 * @author ruoyi
 * @date 2025-06-25
 */
@RestController
@RequestMapping("/system/version")
public class FlightFareVersionController extends BaseController
{
    @Autowired
    private IFlightFareVersionService flightFareVersionService;

    /**
     * 查询行程报价版本列表
     */
    @PreAuthorize("@ss.hasPermi('system:version:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightFareVersion flightFareVersion)
    {
        startPage();
        List<FlightFareVersion> list = flightFareVersionService.selectFlightFareVersionList(flightFareVersion);
        return getDataTable(list);
    }

    /**
     * 导出行程报价版本列表
     */
    @PreAuthorize("@ss.hasPermi('system:version:export')")
    @Log(title = "行程报价版本", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightFareVersion flightFareVersion)
    {
        List<FlightFareVersion> list = flightFareVersionService.selectFlightFareVersionList(flightFareVersion);
        ExcelUtil<FlightFareVersion> util = new ExcelUtil<FlightFareVersion>(FlightFareVersion.class);
        util.exportExcel(response, list, "行程报价版本数据");
    }

    /**
     * 获取行程报价版本详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:version:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(flightFareVersionService.selectFlightFareVersionById(id));
    }

    /**
     * 新增行程报价版本
     */
    @PreAuthorize("@ss.hasPermi('system:version:add')")
    @Log(title = "行程报价版本", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightFareVersion flightFareVersion)
    {
        return toAjax(flightFareVersionService.insertFlightFareVersion(flightFareVersion));
    }

    /**
     * 修改行程报价版本
     */
    @PreAuthorize("@ss.hasPermi('system:version:edit')")
    @Log(title = "行程报价版本", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightFareVersion flightFareVersion)
    {
        return toAjax(flightFareVersionService.updateFlightFareVersion(flightFareVersion));
    }

    /**
     * 删除行程报价版本
     */
    @PreAuthorize("@ss.hasPermi('system:version:remove')")
    @Log(title = "行程报价版本", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(flightFareVersionService.deleteFlightFareVersionByIds(ids));
    }
}
