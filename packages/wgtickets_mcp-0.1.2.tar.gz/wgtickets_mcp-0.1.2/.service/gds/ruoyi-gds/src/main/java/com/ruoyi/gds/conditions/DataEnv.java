package com.ruoyi.gds.conditions;

import org.apache.commons.lang3.StringUtils;
import org.springframework.context.annotation.Condition;
import org.springframework.context.annotation.ConditionContext;
import org.springframework.core.type.AnnotatedTypeMetadata;

public class DataEnv implements Condition {
    @Override
    public boolean matches(ConditionContext context, AnnotatedTypeMetadata metadata) {
        String env = context.getEnvironment().getProperty("task.specify.env");  // dev/prod/data
        return StringUtils.isNotBlank(env) && env.equalsIgnoreCase("data");
    }
}
