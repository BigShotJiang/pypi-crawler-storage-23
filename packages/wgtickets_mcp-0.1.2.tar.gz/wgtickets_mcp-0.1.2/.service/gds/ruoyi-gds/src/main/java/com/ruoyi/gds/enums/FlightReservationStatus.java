package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum FlightReservationStatus {

    WAIT(0, "待预订"),
    FAIL(1, "预订失败"),
    SUCCESS(2, "预订成功"),
    CANCEL(3, "已取消"),
    ISSUE_SUCCESS(4, "出票成功"),
    ISSUE_FAIL(5, "出票失败"),
    OCCUPANCY_FAIL(6, "占座失败");

    @JsonValue
    private final Integer code;

    private final String desc;

    FlightReservationStatus(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static FlightReservationStatus fromCode(Integer code) {
        return Arrays.stream(FlightReservationStatus.values()).filter(item -> Objects.nonNull(code) && Objects.equals(item.code, code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
