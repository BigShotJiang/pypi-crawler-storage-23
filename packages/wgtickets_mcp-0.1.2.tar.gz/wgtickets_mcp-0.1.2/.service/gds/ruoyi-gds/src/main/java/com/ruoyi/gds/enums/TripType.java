package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum TripType {

    SINGLE(0, "单程"),
    ROUND(1, "往返"),
    MULTIPLE_BOUND(2, "多程");

    @JsonValue
    private final int code;

    private final String desc;

    TripType(int code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static TripType fromCode(int code) {
        return Arrays.stream(TripType.values()).filter(item -> code == item.code).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
