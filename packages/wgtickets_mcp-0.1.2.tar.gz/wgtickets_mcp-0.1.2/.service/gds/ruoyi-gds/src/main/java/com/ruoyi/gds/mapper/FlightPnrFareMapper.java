package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightPnrFare;

import java.util.List;

/**
 * PNR预定价格Mapper接口
 * 
 * @author ruoyi
 * @date 2025-09-30
 */
public interface FlightPnrFareMapper extends BaseMapper<FlightPnrFare>
{
    /**
     * 查询PNR预定价格
     * 
     * @param id PNR预定价格主键
     * @return PNR预定价格
     */
    public FlightPnrFare selectFlightPnrFareById(Long id);

    /**
     * 查询PNR预定价格列表
     * 
     * @param flightPnrFare PNR预定价格
     * @return PNR预定价格集合
     */
    public List<FlightPnrFare> selectFlightPnrFareList(FlightPnrFare flightPnrFare);

    /**
     * 新增PNR预定价格
     * 
     * @param flightPnrFare PNR预定价格
     * @return 结果
     */
    public int insertFlightPnrFare(FlightPnrFare flightPnrFare);

    /**
     * 修改PNR预定价格
     * 
     * @param flightPnrFare PNR预定价格
     * @return 结果
     */
    public int updateFlightPnrFare(FlightPnrFare flightPnrFare);

    /**
     * 删除PNR预定价格
     * 
     * @param id PNR预定价格主键
     * @return 结果
     */
    public int deleteFlightPnrFareById(Long id);

    /**
     * 批量删除PNR预定价格
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightPnrFareByIds(Long[] ids);
}
