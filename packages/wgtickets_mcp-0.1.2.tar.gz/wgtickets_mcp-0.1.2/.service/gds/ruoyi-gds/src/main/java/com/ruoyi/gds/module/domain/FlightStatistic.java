package com.ruoyi.gds.module.domain;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 航班统计对象 flight_statistic
 *
 * @author ruoyi
 * @date 2025-04-14
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightStatistic implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 批次号 */
    @Excel(name = "批次号")
    private String batchCode;

    /** 总行程编号 */
    @Excel(name = "总行程编号")
    private String flightKey;

    /** 行程类型（0：去程，1：回程） */
    @Excel(name = "行程类型", readConverterExp = "0=：去程，1：回程")
    @TableField("`group`")
    private Integer group;

    /** 航司，多个时用逗号拼接 */
    @Excel(name = "航司，多个时用逗号拼接")
    private String carriers;

    /** 出发机场 */
    @Excel(name = "出发机场")
    private String departureAirport;

    /** 到达机场 */
    @Excel(name = "到达机场")
    private String arrivalAirport;

    /** 出发时间 */
    @Excel(name = "出发时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime departureTime;

    /** 到达时间 */
    @Excel(name = "到达时间", width = 30, dateFormat = "yyyy-MM-dd")
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime arrivalTime;

    /** 中转次数 */
    @Excel(name = "中转次数")
    private Integer transferTimes;

    /** 中转机场 */
    @Excel(name = "中转机场")
    private String transferAirports;

    /** 舱位等级 */
    @Excel(name = "舱位等级")
    private String cabins;

    /** 创建者ID */
    @Excel(name = "创建者ID")
    private Long createUserId;

    /** 创建者 */
    @Excel(name = "创建者")
    private String createBy;

    /** 创建时间 */
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("flightKey", getFlightKey())
            .append("carriers", getCarriers())
            .append("departureAirport", getDepartureAirport())
            .append("arrivalAirport", getArrivalAirport())
            .append("departureTime", getDepartureTime())
            .append("arrivalTime", getArrivalTime())
            .append("transferTimes", getTransferTimes())
            .append("transferAirports", getTransferAirports())
            .append("cabins", getCabins())
            .append("createTime", getCreateTime())
            .append("delFlag", isDelFlag())
            .toString();
    }
}
