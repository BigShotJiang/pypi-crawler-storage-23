package com.ruoyi.gds.module.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * PNR预定价格对象 flight_pnr_fare
 * 
 * @author ruoyi
 * @date 2025-09-30
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightPnrFare implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 预约记录ID */
    @Excel(name = "预约记录ID")
    private Long reservationId;

    /** 价格类型 */
    @Excel(name = "价格类型")
    private String priceType;

    /** PNR */
    @Excel(name = "PNR")
    private String pnr;

    /** 币种 */
    @Excel(name = "币种")
    private String currencyCode;

    /** 总价 */
    @Excel(name = "总价")
    private BigDecimal totalPrice;

    /** 基础运价 */
    @Excel(name = "基础运价")
    private BigDecimal basePrice;

    /** 总税费 */
    @Excel(name = "总税费")
    private BigDecimal taxes;

    /** 各人员类型报价 */
    @Excel(name = "各人员类型报价")
    private String passengerPrices;

    /** 各航段舱位 */
    @Excel(name = "各航段舱位")
    private String cabins;

    /** 创建者 */
    private Long createBy;

    /** 创建时间 */
    private LocalDateTime createTime;

    /** 是否已删除（false：未删除，true：已删除） */
    private boolean delFlag;

}
