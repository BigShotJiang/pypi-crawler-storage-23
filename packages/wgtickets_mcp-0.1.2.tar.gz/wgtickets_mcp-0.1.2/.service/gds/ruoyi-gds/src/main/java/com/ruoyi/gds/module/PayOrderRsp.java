package com.ruoyi.gds.module;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PayOrderRsp implements Serializable {

    private static final long serialVersionUID = 1L;

    private ReturnDetail ResponseBody;

    // 是否成功
    private boolean Status;

    // 错误信息
    private String Msg;

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ReturnDetail implements Serializable {
        /**
         * 生成的订单号
         */
        private String OrderId;
        /**
         * 采购的支付总价
         */
        private BigDecimal TotalPrice;

        /**
         * 交易号
         */
        private String TransactionNo;
        /**授权Office号*/
        private String OfficeNo;

        /**
         * 钱包减免金额
         */
        private String WalletReduce;
    }
}
