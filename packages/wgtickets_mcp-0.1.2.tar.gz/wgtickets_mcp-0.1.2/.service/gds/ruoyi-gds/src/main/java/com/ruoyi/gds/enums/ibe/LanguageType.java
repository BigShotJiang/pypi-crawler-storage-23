package com.ruoyi.gds.enums.ibe;

public enum LanguageType {

    ZH, EN

}
