package com.ruoyi.gds.common;

public class IBEConstant {

    public static final String POS_DEFAULT = "SHA";

    public static final String OTHER_SERVICE_INFORMATION_TYPE = "OTHS";

    public static final String MODIFICATION_TYPE_PNR_CANCEL = "PNR_CANCEL";

    public static final String MODIFICATION_TYPE_SEGMENT_CONFIRM = "SEGMENT_CONFIRM";

    public static final String MODIFICATION_INFO_IK = "IK";

    public static final String ID_CONTEXT_PNR = "PNR";

    public static final String ID_CONTEXT_ORDER = "ORDER";

    public static final String ENVELOP_TYPE_KI = "KI";

    public static final String CERTIFICATE_TYPE_PP = "PP";

    // 表示可售舱位数大于等于9
    public static final String CABIN_MAX_QUANTITY_CODE = "A";

    public static final String PRINTER_NUMBER_BSP = "1";

    public static final String PRINTER_NUMBER_BOP = "-1";

    public static final String PAYMENT_TYPE_CASH = "CASH";

    public static final String RATE_AIRPORT_CODE = "PKX";

    public static final String RATE_TEMPLATE_AMOUNT = "100.0";

    public static final String RATE_EXCHANGE_TYPE = "BankersSellingRate";

    public static final String FARE_TYPE_CODE_ALL = "ALLF";
    public static final String FARE_TYPE_CODE_LOW = "ALLB";

    public static final String FARE_TYPE_CODE_CONTEXT = "SITA";

    public static final String PRICING_SOURCE = "Both";

    public static final String FLIGHT_SEGMENT_STATUS = "26";

    public static final String POS_REQUESTORID_TYPE_7 = "7";

    public static final String POS_REQUESTORID_TYPE_13 = "13";

    public static final String POS_REQUESTORID_IDCONTEXT_AIRFARE = "Airfare";

    public static final String POS_REQUESTORID_IDCONTEXT_CRSCODE = "CRSCode";

    public static final String POS_REQUESTORID_IDCONTEXT_IATA_NUMBER = "IATA_Number";

    public static final String ERROR_MSG_CREATE_PNR_1 = "IBE服务异常";
    public static final String ERROR_MSG_CREATE_PNR_2 = "[IBE]指定的航班在指定的日期不执行或指定的舱位已经无法订取";

}
