package com.ruoyi.gds.module;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;
import java.math.BigDecimal;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class RateRsp<T> extends CommonRsp<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 税率
     */
    private BigDecimal rate;


}
