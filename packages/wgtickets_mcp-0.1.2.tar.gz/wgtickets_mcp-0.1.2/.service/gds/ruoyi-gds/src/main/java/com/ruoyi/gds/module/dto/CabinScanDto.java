package com.ruoyi.gds.module.dto;

import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.enums.PassengerType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CabinScanDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * GDS代码
     */
    private GDSType gds;

    /**
     * 航段信息
     */
    @Valid
    @NotEmpty(message = "航段信息为空")
    private List<CabinScanSegementDto> segments;

    /**
     * 乘客信息
     */
    @NotEmpty(message = "乘客信息为空")
    private List<PassengerType> passengers;

    /**
     * 舱位等级列表
     */
    private List<String> cabins;

    /**
     * 扫舱订单号
     *
     * 非GDS扫舱接口需要的入参，此字段值GDS扫仓接口会原样返回
     */
    private String orderSerialNo;

    /**
     * 扫舱规则ID
     *
     * 非GDS扫舱接口需要的入参，此字段值GDS扫仓接口会原样返回
     */
    private Long ruleId;

    /**
     * 扫舱任务ID
     *
     * 非GDS扫舱接口需要的入参，此字段值GDS扫仓接口会原样返回
     */
    private Long taskId;

}
