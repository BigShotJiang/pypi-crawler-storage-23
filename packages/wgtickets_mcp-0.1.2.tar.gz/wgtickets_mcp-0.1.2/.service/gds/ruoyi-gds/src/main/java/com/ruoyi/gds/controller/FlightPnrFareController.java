package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.gds.module.domain.FlightPnrFare;
import com.ruoyi.gds.service.IFlightPnrFareService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * PNR预定价格Controller
 * 
 * @author ruoyi
 * @date 2025-09-30
 */
@RestController
@RequestMapping("/system/fare")
public class FlightPnrFareController extends BaseController
{
    @Autowired
    private IFlightPnrFareService flightPnrFareService;

    /**
     * 查询PNR预定价格列表
     */
    @PreAuthorize("@ss.hasPermi('system:fare:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightPnrFare flightPnrFare)
    {
        startPage();
        List<FlightPnrFare> list = flightPnrFareService.selectFlightPnrFareList(flightPnrFare);
        return getDataTable(list);
    }

    /**
     * 导出PNR预定价格列表
     */
    @PreAuthorize("@ss.hasPermi('system:fare:export')")
    @Log(title = "PNR预定价格", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightPnrFare flightPnrFare)
    {
        List<FlightPnrFare> list = flightPnrFareService.selectFlightPnrFareList(flightPnrFare);
        ExcelUtil<FlightPnrFare> util = new ExcelUtil<FlightPnrFare>(FlightPnrFare.class);
        util.exportExcel(response, list, "PNR预定价格数据");
    }

    /**
     * 获取PNR预定价格详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:fare:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(flightPnrFareService.selectFlightPnrFareById(id));
    }

    /**
     * 新增PNR预定价格
     */
    @PreAuthorize("@ss.hasPermi('system:fare:add')")
    @Log(title = "PNR预定价格", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightPnrFare flightPnrFare)
    {
        return toAjax(flightPnrFareService.insertFlightPnrFare(flightPnrFare));
    }

    /**
     * 修改PNR预定价格
     */
    @PreAuthorize("@ss.hasPermi('system:fare:edit')")
    @Log(title = "PNR预定价格", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightPnrFare flightPnrFare)
    {
        return toAjax(flightPnrFareService.updateFlightPnrFare(flightPnrFare));
    }

    /**
     * 删除PNR预定价格
     */
    @PreAuthorize("@ss.hasPermi('system:fare:remove')")
    @Log(title = "PNR预定价格", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(flightPnrFareService.deleteFlightPnrFareByIds(ids));
    }
}
