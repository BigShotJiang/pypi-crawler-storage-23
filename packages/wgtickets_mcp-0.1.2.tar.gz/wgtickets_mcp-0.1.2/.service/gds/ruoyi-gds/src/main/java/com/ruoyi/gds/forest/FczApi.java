package com.ruoyi.gds.forest;

import com.dtflys.forest.annotation.BaseRequest;
import com.dtflys.forest.annotation.Get;
import com.dtflys.forest.annotation.Query;
import com.ruoyi.gds.module.vo.FczAirchangeCustomResultVo;
import org.springframework.stereotype.Component;

@Component
@BaseRequest(baseURL = "${fcz_baseurl}")
public interface FczApi {

    /**
     * 定制航变
     *
     * @param appid
     * @param dep
     * @param arr
     * @param date
     * @param fnum
     * @param fid
     * @param token
     * @return
     */
    @Get(url = "/api/addflightpush", logEnabled = true)
    FczAirchangeCustomResultVo airchangeCustom(@Query("appid") String appid,
                                               @Query("dep") String dep,
                                               @Query("arr") String arr,
                                               @Query("date") String date,
                                               @Query("fnum") String fnum,
                                               @Query("fid") String fid,
                                               @Query("token") String token);

    /**
     * 查询航变
     *
     * @param appid
     * @param date
     * @param fnum
     * @param token
     * @return
     */
    @Get(url = "/api/flight", logEnabled = true)
    Object airchangeQuery(@Query("appid") String appid,
                          @Query("date") String date,
                          @Query("fnum") String fnum,
                          @Query("token") String token);

}
