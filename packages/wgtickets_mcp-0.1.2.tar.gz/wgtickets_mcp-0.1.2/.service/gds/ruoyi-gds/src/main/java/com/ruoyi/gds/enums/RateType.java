package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum RateType {

    CNY_TO_JPY("CNY_TO_JPY", "CNY", "JPY", "人民币兑日元汇率"),
    JPY_TO_CNY("JPY_TO_CNY", "JPY", "CNY", "日元兑人名币汇率");

    @JsonValue
    private final String code;
    private final String from;
    private final String to;
    private final String desc;

    RateType(String code, String from, String to, String desc) {
        this.code = code;
        this.from = from;
        this.to = to;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static RateType fromCode(String code) {
        return Arrays.stream(RateType.values()).filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
