package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.dto.AirportsDto;
import com.ruoyi.gds.module.vo.AirportsVo;
import com.ruoyi.gds.module.vo.CarrierVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 查询机场信息
 */
public interface AirportsMapper extends BaseMapper {

    List<AirportsVo> queryList(AirportsDto airportsDto);

    List<CarrierVo> carrierList(@Param("carriers") List<String> carriers);

}
