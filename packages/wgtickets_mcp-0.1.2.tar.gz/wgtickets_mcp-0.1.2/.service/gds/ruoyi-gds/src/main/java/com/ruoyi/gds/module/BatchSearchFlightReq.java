package com.ruoyi.gds.module;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.ruoyi.gds.enums.*;
import com.ruoyi.gds.module.vo.FlightDateVo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class BatchSearchFlightReq extends LoaclSearchFlightReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 业务场景（GDS、TICKET、FLY...）。默认：TICKET
     */
    private BusinessScene businessScene;

    /**
     * GDS平台
     */
    private GDSType gds;

    /**
     * 搜索方式
     */
    @NotNull(message = "搜索方式为空")
    private SearchType searchType;

    /**
     * 业务ID为空（问票ID...）
     */
    @NotBlank(message = "业务ID为空")
    private String businessId;

    /**
     * 行程类型
     */
    @NotNull(message = "行程类型为空")
    private TripType tripType;

    /**
     * 出发机场代码
     */
    @NotEmpty(message = "出发机场为空")
    private List<String> fromAirportCodes;

    /**
     * 出发机场代码
     */
    @NotEmpty(message = "出发机场为空")
    private List<String> toAirportCodes;

    /**
     * 行程日期
     */
    @Valid
    @NotEmpty(message = "行程日期为空")
    private List<FlightDateVo> flightDates;

    /**
     * 是否允许转机
     */
    // @NotNull(message = "是否允许转机为空")
    private Boolean transfer;

    /**
     * 乘客信息
     */
    @NotEmpty(message = "乘客信息为空")
    private List<PassengerType> passengers;

    /**
     * 航司搜索方式
     */
    private SearchMethod carriersType;

    /**
     * 指定航司
     */
    private List<String> carriers;

    /**
     * 舱位等级搜索方式
     * Permitted 只返回特定舱位
     * Prohibited 排除特定舱位
     */
    private SearchMethod cabinsType;

    /**
     * 指定舱位等级
     */
    private List<CabinCategoryType> cabins;


    public BusinessScene getBusinessScene() {
        return Optional.ofNullable(businessScene).orElse(BusinessScene.TICKET);
    }

}
