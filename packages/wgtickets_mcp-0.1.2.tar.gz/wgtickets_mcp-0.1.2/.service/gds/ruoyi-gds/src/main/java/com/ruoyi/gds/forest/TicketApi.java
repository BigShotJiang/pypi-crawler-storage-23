package com.ruoyi.gds.forest;

import com.dtflys.forest.annotation.*;
import com.dtflys.forest.http.ForestResponse;
import com.ruoyi.common.module.vo.ResultVo;
import com.ruoyi.gds.module.dto.BusinessFlightDto;
import com.ruoyi.gds.module.dto.QueryFareKeyScanDto;
import com.ruoyi.gds.module.vo.*;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;


@Component
@BaseRequest(baseURL = "${tickets_base_url}")
public interface TicketApi {

    /**
     * 查询最新汇率
     * @param param
     * @return
     */
    @Post(url = "/ticket/rate/getTodayRate", headers = {"Content-Type:application/json"})
    RateRsp todayRate(@JSONBody Map<String, Object> param);

    /**
     * 根据用户ID查询用户信息
     * @param userIds
     * @return
     */
    @Post(url = "/system/user/findByIds")
    List<SysUserBaseInfoVo> findByUserIds(@JSONBody List<Long> userIds);

    /**
     * 同步添加预约记录到票务
     * @param reservationSyncVo
     * @return
     */
    @Post(url = "/ticket/reservation/gdsAdd")
    String addTicketReservation(@JSONBody TicketFlightReservationSyncVo reservationSyncVo);

    /**
     * 同步更新预约记录到票务
     * @param reservationSyncVo
     * @return
     */
    @Post(url = "/ticket/reservation/gdsUpdate")
    ResultVo<Boolean> updateTicketReservation(@JSONBody TicketFlightReservationSyncVo reservationSyncVo);

    /**
     * 查询问票—保存的航班列表（仅行程ke、报价key）
     * @param businessId  业务ID（问票ID）
     * @return
     */
    @Get(url = "/enquiry/flight/car/savedFlight?enquiryId={businessId}")
    ResultVo<List<BusinessFlightSavedVo>> businessSavedFlight(@Var("businessId") String businessId);

    /**
     * 查询报价Key扫舱状态
     * @param queryFareKeyScanDto
     * @return
     */
    @Post(url = "/cabinScanEnquiry/queryFareKeyScan")
    ResultVo<List<QueryFareKeyScanVo>> queryFareKeyScan(@JSONBody QueryFareKeyScanDto queryFareKeyScanDto);

    /**
     * 更新业务对应的出发到达集合、出发日期集合
     * @param flightDto
     * @return
     */
    @Post(url = "/ticket/enquiry/updateFlight")
    ResultVo<Boolean> businessUpdateFlight(@JSONBody BusinessFlightDto flightDto);

    /**
     * 根据PNR查询票务预约记录
     * @param pnr
     * @return
     */
    @Get(url = "/ticket/reservation/queryByPnr?pnr={pnr}")
    ResultVo<BusinessFlightReservationVo> businessFlightReservation(@Var("pnr") String pnr);

    @Post(url = "/ticket/ticket/updateTicketNo")
    ResultVo<Boolean> updateTicketNo(@JSONBody List<FinTicket> ticketList);

    @Post(url = "/ticket/ticket/airChangeHandle", logEnabled = true)
    ForestResponse<ResultVo> airChangeHandle(@JSONBody List<FlightChangeResultVo> changeResultVos);

    @Post(url = "/ticket/ticket/issueTicketFail")
    void issueTicketFail(@JSONBody FinTicket ticket);
}
