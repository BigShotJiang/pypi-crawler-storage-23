package com.ruoyi.gds.module.dto.ibe;

import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.common.utils.ValidatorUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CancelPnrDto implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotBlank(message = "PNR为空")
    private String pnr;

    @NotBlank(message = "订单号为空")
    private String orderNo;


    public void check(){
        String errMsg = ValidatorUtil.validate(this);
        if (StringUtils.isNotBlank(errMsg)) {
            throw new InvalidParamException(errMsg);
        }
    }

}
