package com.ruoyi.gds.forest.interceptor;

import com.dtflys.forest.http.ForestRequest;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.service.SabreService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Slf4j
@Component
public class SabreInterceptor extends BaseInterceptor {

    @Autowired
    private SabreService sabreService;

    @Override
    public boolean beforeExecute(ForestRequest request) {
        super.beforeExecute(request);

        String accessToken = sabreService.getRestAccessToken();
        if (StringUtils.isBlank(accessToken)) {
            throw new ServiceException("获取塞班AccessToken失败", HttpStatus.ERROR);
        }

        request.addHeader("Authorization", "Bearer " + accessToken);

        return true;
    }

}
