package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

public enum CurrencyType {
    // 人名币
    CNY,
    // 日元
    JPY;

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static CurrencyType fromCode(String code) {
        return Arrays.stream(CurrencyType.values()).filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.name())).findFirst().orElse(null);
    }

}
