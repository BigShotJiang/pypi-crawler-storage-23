package com.ruoyi.gds.enums.sabre;

public enum SabreIssueType {

    CreditCard,

    Cash

}
