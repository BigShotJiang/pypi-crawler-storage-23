package com.ruoyi.gds.enums.ibe;

public enum IBELocationType {

    AIRPORT, CITY

}
