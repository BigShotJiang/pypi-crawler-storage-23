package com.ruoyi.gds.config;
import com.ruoyi.gds.mapper.SysRequestLogMapper;
import com.ruoyi.gds.module.domain.SysRequestLog;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@Component
public class DatabaseLogListener implements RequestLogListener {

    private static final Logger log = LoggerFactory.getLogger(DatabaseLogListener.class);

    private ExecutorService executor = Executors.newFixedThreadPool(10);

    @Resource
    private SysRequestLogMapper requestLogMapper;

    @Override
    public void onRequestComplete(SysRequestLog entry) {
        executor.submit(() -> saveToDatabase(entry));
    }

    private void saveToDatabase(SysRequestLog entry) {
        log.info("新增请求记录---------------------");
        requestLogMapper.insertSysRequestLog(entry);
    }

}
