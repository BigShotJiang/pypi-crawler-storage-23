package com.ruoyi.gds.controller;

import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.service.IbeForwardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Anonymous
@RestController
@RequestMapping("/air/ibe")
public class IBEForwardController {

    @Autowired
    private IbeForwardService ibeForwardService;

    /**
     * 根据 IBE PNR 查询对应的订单号
     * @param pnr
     * @return
     */
    @GetMapping(value = "/queryOrderNoByPnr")
    public AjaxResult queryOrderNoByPnr(@RequestParam String pnr) {
        if (StringUtils.isBlank(pnr) || pnr.length() != 6) throw new ServiceException("PNR格式错误");
        String pnrOrderNo = ibeForwardService.getOrderNoByPnr(pnr);
        return AjaxResult.success(null, pnrOrderNo);
    }

}
