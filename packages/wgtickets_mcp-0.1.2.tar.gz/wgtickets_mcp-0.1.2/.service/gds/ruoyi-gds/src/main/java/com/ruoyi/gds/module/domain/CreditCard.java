package com.ruoyi.gds.module.domain;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 自动开票——信用卡开卡记录对象 credit_card
 * 
 * @author ruoyi
 * @date 2025-11-28
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreditCard implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** PNR */
    @Excel(name = "PNR")
    private String pnr;

    /** 币种 */
    @Excel(name = "币种")
    private String currency;

    /** 金额 */
    @Excel(name = "金额")
    private BigDecimal amount;

    /** 开卡申请生效日期 */
    @Excel(name = "开卡申请生效日期", width = 30, dateFormat = DatePattern.NORM_DATE_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate activeDate;

    /** 开卡申请有效期 */
    @Excel(name = "开卡申请有效期", width = 30, dateFormat = DatePattern.NORM_DATE_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate inactiveDate;

    /** 发卡机构（AWE / TL） */
    @Excel(name = "发卡机构", readConverterExp = "AWE / TL")
    private String server;

    /** 持卡人姓名 */
    @Excel(name = "持卡人姓名")
    private String owner;

    /** 信用卡号 */
    @Excel(name = "信用卡号")
    private String creditNo;

    /** CVV号 */
    @Excel(name = "CVV号")
    private String cvv;

    /** 信用卡有效期 */
    @Excel(name = "信用卡有效期")
    private String expireDate;

    /** 卡状态（CREATE_FAIL: 开卡失败, UNUSED: 未使用, USED: 已使用） */
    @Excel(name = "卡状态", readConverterExp = "CREATE_FAIL:开卡失败,UNUSED:未使用,USED:已使用")
    private String status;

    /** 开卡返回的原始数据 */
    @Excel(name = "开卡返回的原始数据")
    private String originalInfo;

    /** 创建者 */
    @Excel(name = "创建者")
    private Long createBy;

    /** 创建时间 */
    @Excel(name = "创建时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTime;

    /** 是否已删除（false：未删除，true：已删除） */
    private boolean delFlag;

}
