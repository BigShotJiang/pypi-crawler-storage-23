package com.ruoyi.gds.module.dto;


import com.ruoyi.gds.enums.PassengerType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class PassengerBaggageDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 乘机人类型
     */
    @NotNull(message = "乘机人类型为空")
    private PassengerType passengerType;

    /**
     * 行李—件数
     */
    private Integer baggagePc;

    /**
     * 行李—每件公斤数
     */
    private Integer baggageKg;

}
