package com.ruoyi.gds.aspect;


import com.alibaba.fastjson2.JSONObject;
import com.ruoyi.gds.annotation.LogException;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.Arrays;

@Aspect
@Component
@Slf4j
public class LogExceptionAspect {

    /**
     * 切入点：拦截所有标记 @CheckParam 的方法
     */
    @Pointcut("@annotation(com.ruoyi.gds.annotation.LogException)")
    public void logExceptionPointcut() {
    }

    /**
     * 异常处理：捕获方法抛出的异常并记录日志
     */
    @AfterThrowing(pointcut = "logExceptionPointcut()", throwing = "ex")
    public void logException(JoinPoint joinPoint, Throwable ex) throws Throwable {
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Method method = signature.getMethod();
        LogException annotation = method.getAnnotation(LogException.class);

        // 检查抛出的异常是否在注解指定的捕获范围内
        if (matchedException(ex, annotation.value()) && ex.getStackTrace().length > 0) {
            // 打印日志（含方法名、入参、异常信息）
            log.error("[参数校验失败]\n- 方法: {}.{} \n- 入参: {} \n- 异常: {}",
                    method.getDeclaringClass().getName(),
                    method.getName(),
                    JSONObject.toJSONString(joinPoint.getArgs()),
                    ex.getMessage()
            );

            /*log.error("[参数校验失败]\n- 方法: {}.{} \n- 入参: {} \n- 异常: {} \n- 堆栈: {}",
                    method.getDeclaringClass().getName(),
                    method.getName(),
                    JSONObject.toJSONString(joinPoint.getArgs()),
                    ex.getMessage(),
                    ExceptionUtils.getStackTrace(ex)
            );*/
        }
    }

    /**
     * 判断异常是否匹配注解定义的类型
     */
    private boolean matchedException(Throwable ex, Class<? extends Throwable>[] allowedExceptions) {
        return Arrays.stream(allowedExceptions).anyMatch(clazz -> clazz.isAssignableFrom(ex.getClass()));
    }

}
