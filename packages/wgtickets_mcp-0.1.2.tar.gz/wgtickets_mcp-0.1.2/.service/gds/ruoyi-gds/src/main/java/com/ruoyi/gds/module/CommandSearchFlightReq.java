package com.ruoyi.gds.module;

import com.ruoyi.gds.enums.BusinessScene;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

/**
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CommandSearchFlightReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 业务场景（GDS、TICKET、FLY...）。默认：TICKET
     */
    private BusinessScene businessScene;

    /**
     * 业务ID（问票ID）
     */
    @NotBlank(message = "业务ID为空")
    private String businessId;

    /**
     * 去程集合
     */
    @NotEmpty(message = "去程信息为空")
    @Size(max = 3, min = 1, message = "仅支持1~3个去程")
    private List<String> outBounds;

    /**
     * 回程集合
     */
    @Size(max = 3, message = "仅支持1~3个回程")
    private List<String> inBounds;

    public BusinessScene getBusinessScene() {
        return Optional.ofNullable(businessScene).orElse(BusinessScene.TICKET);
    }

}
