package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.gds.module.domain.FlightSearchParamSolution;
import com.ruoyi.gds.service.IFlightSearchParamSolutionService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 搜索条件对应的行程方案Controller
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@RestController
@RequestMapping("/flight/searchParam/solution")
public class FlightSearchParamSolutionController extends BaseController {
    @Autowired
    private IFlightSearchParamSolutionService flightSearchParamSolutionService;

    /**
     * 查询搜索条件对应的行程方案列表
     */
    @PreAuthorize("@ss.hasPermi('system:solution:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightSearchParamSolution flightSearchParamSolution) {
        startPage();
        List<FlightSearchParamSolution> list = flightSearchParamSolutionService.selectFlightSearchParamSolutionList(flightSearchParamSolution);
        return getDataTable(list);
    }

    /**
     * 导出搜索条件对应的行程方案列表
     */
    @PreAuthorize("@ss.hasPermi('system:solution:export')")
    @Log(title = "搜索条件对应的行程方案", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightSearchParamSolution flightSearchParamSolution) {
        List<FlightSearchParamSolution> list = flightSearchParamSolutionService.selectFlightSearchParamSolutionList(flightSearchParamSolution);
        ExcelUtil<FlightSearchParamSolution> util = new ExcelUtil<FlightSearchParamSolution>(FlightSearchParamSolution.class);
        util.exportExcel(response, list, "搜索条件对应的行程方案数据");
    }

    /**
     * 获取搜索条件对应的行程方案详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:solution:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(flightSearchParamSolutionService.selectFlightSearchParamSolutionById(id));
    }

    /**
     * 新增搜索条件对应的行程方案
     */
    @PreAuthorize("@ss.hasPermi('system:solution:add')")
    @Log(title = "搜索条件对应的行程方案", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightSearchParamSolution flightSearchParamSolution) {
        return toAjax(flightSearchParamSolutionService.insertFlightSearchParamSolution(flightSearchParamSolution));
    }

    /**
     * 修改搜索条件对应的行程方案
     */
    @PreAuthorize("@ss.hasPermi('system:solution:edit')")
    @Log(title = "搜索条件对应的行程方案", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightSearchParamSolution flightSearchParamSolution) {
        return toAjax(flightSearchParamSolutionService.updateFlightSearchParamSolution(flightSearchParamSolution));
    }

    /**
     * 删除搜索条件对应的行程方案
     */
    @PreAuthorize("@ss.hasPermi('system:solution:remove')")
    @Log(title = "搜索条件对应的行程方案", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(flightSearchParamSolutionService.deleteFlightSearchParamSolutionByIds(ids));
    }
}
