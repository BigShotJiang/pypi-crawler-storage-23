package com.ruoyi.gds.controller;

import cn.hutool.core.date.DatePattern;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.module.vo.FczAirchangeFlightInfo;
import com.ruoyi.gds.service.IFczAirchangeNotifyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;

@Slf4j
@RestController
@RequestMapping("/airChange")
public class AirChangeController {

    @Autowired
    private IFczAirchangeNotifyService fczAirchangeNotifyService;

    /**
     * 飞常准航变通知接口
     *
     * @param data
     * @return
     */
    @PostMapping(value = "/notify")
    public AjaxResult notify(@RequestBody Object data) {
        log.info("飞常准航变通知: {}", JacksonUtil.toJsonString(data));
        List<FczAirchangeFlightInfo> fczAirchangeFlightInfos = JacksonUtil.toBeanList(JacksonUtil.toJsonString(data), FczAirchangeFlightInfo.class);
        fczAirchangeNotifyService.notify(fczAirchangeFlightInfos);
        return AjaxResult.success();
    }

    /**
     * 重推飞常准航班动态到票务
     * @param beginDate
     * @param endDate
     * @return
     */
    @GetMapping(value = "/repush")
    public AjaxResult repush(@RequestParam(required = false) String beginDate, @RequestParam(required = false) String endDate) {
        LocalDateTime beginTime = Optional.ofNullable(beginDate)
                .filter(StringUtils::isNotBlank)
                .map(date -> LocalDate.parse(date, DateTimeFormatter.ofPattern(DatePattern.NORM_DATE_PATTERN)))
                .map(date -> date.atTime(0, 0, 0))
                .orElse(LocalDate.now().atTime(0, 0, 0));
        LocalDateTime endTime = Optional.ofNullable(endDate)
                .filter(StringUtils::isNotBlank)
                .map(date -> LocalDate.parse(date, DateTimeFormatter.ofPattern(DatePattern.NORM_DATE_PATTERN)))
                .map(date -> date.atTime(23, 59, 59))
                .orElse(LocalDate.now().atTime(23, 59, 59));

        fczAirchangeNotifyService.repush(beginTime, endTime);
        return AjaxResult.success();
    }


}
