package com.ruoyi.gds.enums.ibe;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.enums.CabinCategoryType;
import com.ruoyi.gds.utils.StrUtil;
import lombok.Getter;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Getter
public enum IBECarbinType {

    ECONOMY(1, "ECONOMY", CabinCategoryType.ECONOMY, "经济舱"),
    PREMIUM_ECONOMY(2, "PREMIUM_ECONOMY", CabinCategoryType.PREMIUM_ECONOMY, "优选经济舱"),
    BUSINESS(3, "BUSINESS", CabinCategoryType.BUSINESS, "商务舱"),
    PREMIUM_BUSINESS(4, "PREMIUM_BUSINESS", CabinCategoryType.BUSINESS, "优选商务舱"),
    FIRST(5, "FIRST", CabinCategoryType.FIRST, "头等舱"),
    PREMIUM_FIRST(6, "PREMIUM_FIRST", CabinCategoryType.FIRST, "优选头等舱");

    private final Integer seq;

    @JsonValue
    private final String code;

    private final CabinCategoryType category;

    private final String desc;

    IBECarbinType(Integer seq, String code, CabinCategoryType category, String desc) {
        this.seq = seq;
        this.code = code;
        this.category = category;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static IBECarbinType fromCode(String code) {
        return Arrays.stream(IBECarbinType.values())
                .filter(item -> StringUtils.isNotBlank(code) && StrUtil.removeWhiteSpaces(code).equalsIgnoreCase(StrUtil.removeWhiteSpaces(item.code)))
                .findFirst()
                .orElse(null);
    }

    public static List<IBECarbinType> fromCategory(String category) {
        if (StringUtils.isBlank(category)) return Collections.emptyList();

        CabinCategoryType categoryType = CabinCategoryType.fromCode(category);
        if (Objects.isNull(categoryType)) return Collections.emptyList();

        return Arrays.stream(IBECarbinType.values())
                .filter(item -> categoryType.equals(item.category))
                .collect(Collectors.toList());
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
