package com.ruoyi.gds.enums;

public enum RuleType {

    // 名称后缀（称谓）
    NAME_SUFIX

}
