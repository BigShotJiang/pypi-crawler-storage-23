package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.gds.module.domain.FlightSegment;
import com.ruoyi.gds.service.IFlightSegmentService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 航段Controller
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@RestController
@RequestMapping("/flight/segment")
public class FlightSegmentController extends BaseController {
    @Autowired
    private IFlightSegmentService flightSegmentService;

    /**
     * 查询航段列表
     */
    @PreAuthorize("@ss.hasPermi('system:segment:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightSegment flightSegment) {
        startPage();
        List<FlightSegment> list = flightSegmentService.selectFlightSegmentList(flightSegment);
        return getDataTable(list);
    }

    /**
     * 导出航段列表
     */
    @PreAuthorize("@ss.hasPermi('system:segment:export')")
    @Log(title = "航段", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightSegment flightSegment) {
        List<FlightSegment> list = flightSegmentService.selectFlightSegmentList(flightSegment);
        ExcelUtil<FlightSegment> util = new ExcelUtil<FlightSegment>(FlightSegment.class);
        util.exportExcel(response, list, "航段数据");
    }

    /**
     * 获取航段详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:segment:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(flightSegmentService.selectFlightSegmentById(id));
    }

    /**
     * 新增航段
     */
    @PreAuthorize("@ss.hasPermi('system:segment:add')")
    @Log(title = "航段", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightSegment flightSegment) {
        return toAjax(flightSegmentService.insertFlightSegment(flightSegment));
    }

    /**
     * 修改航段
     */
    @PreAuthorize("@ss.hasPermi('system:segment:edit')")
    @Log(title = "航段", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightSegment flightSegment) {
        return toAjax(flightSegmentService.updateFlightSegment(flightSegment));
    }

    /**
     * 删除航段
     */
    @PreAuthorize("@ss.hasPermi('system:segment:remove')")
    @Log(title = "航段", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(flightSegmentService.deleteFlightSegmentByIds(ids));
    }
}
