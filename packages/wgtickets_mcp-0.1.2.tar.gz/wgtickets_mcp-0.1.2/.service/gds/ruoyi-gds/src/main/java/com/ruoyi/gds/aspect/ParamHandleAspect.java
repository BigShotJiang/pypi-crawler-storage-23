package com.ruoyi.gds.aspect;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.module.QueryPnrInfoReq;
import com.ruoyi.gds.module.domain.FlightReservation;
import com.ruoyi.gds.service.IFlightReservationService;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Objects;

@Aspect
@Component
public class ParamHandleAspect {

    @Autowired
    private IFlightReservationService flightReservationService;

    @Around("@annotation(com.ruoyi.gds.annotation.ParamHandle)")
    public Object paramHandlePointcut(ProceedingJoinPoint joinPoint) throws Throwable {
        Object[] args = joinPoint.getArgs();
        for (Object arg : args) {
            if (arg instanceof QueryPnrInfoReq) {
                QueryPnrInfoReq queryReq = (QueryPnrInfoReq) arg;
                if (StringUtils.isBlank(queryReq.getPnr()) || Objects.nonNull(queryReq.getGds())) {
                    continue;
                }

                LambdaQueryWrapper<FlightReservation> queryWrapper = Wrappers.lambdaQuery(FlightReservation.class)
                        .select(FlightReservation::getProviderCode)
                        .eq(FlightReservation::getPnr, queryReq.getPnr());
                FlightReservation flightReservation = flightReservationService.getOne(queryWrapper);
                if (Objects.nonNull(flightReservation)) {
                    GDSType gdsType = GDSType.fromCode(flightReservation.getProviderCode());
                    queryReq.setGds(gdsType);
                }
            }
        }

        return joinPoint.proceed();
    }

}
