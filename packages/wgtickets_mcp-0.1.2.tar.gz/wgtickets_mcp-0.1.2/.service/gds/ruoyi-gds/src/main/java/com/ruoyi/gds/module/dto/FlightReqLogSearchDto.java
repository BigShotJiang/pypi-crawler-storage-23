package com.ruoyi.gds.module.dto;

import cn.hutool.core.date.DatePattern;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.gds.enums.FlightReqType;
import com.ruoyi.gds.enums.FlightReservationStatus;
import com.ruoyi.gds.enums.GDSType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 机票预定使用记录对象 flight_req_log
 *
 * @author ruoyi
 * @date 2025-05-19
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightReqLogSearchDto implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 类型(1：搜索，2：查价，3：预定，4：取消预定)
     */
    private FlightReqType type;

    /**
     * GDS代码
     */
    private GDSType providerCode;

    /**
     * 状态（0：待预订，1：预定失败，2：预定成功，3：已取消）
     */
    private FlightReservationStatus status;

    /**
     * 起始时间
     */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime beginTime;

    /**
     * 截止时间
     */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime endTime;

}
