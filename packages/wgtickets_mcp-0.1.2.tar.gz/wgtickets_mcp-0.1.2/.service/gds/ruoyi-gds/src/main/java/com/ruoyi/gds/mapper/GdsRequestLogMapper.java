package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.GdsRequestLog;

import java.util.List;

/**
 * 请求gds记录Mapper接口
 * 
 * @author ruoyi
 * @date 2025-08-16
 */
public interface GdsRequestLogMapper extends BaseMapper<GdsRequestLog>
{
    /**
     * 查询请求gds记录
     * 
     * @param id 请求gds记录主键
     * @return 请求gds记录
     */
    public GdsRequestLog selectGdsRequestLogById(Long id);

    /**
     * 查询请求gds记录列表
     * 
     * @param gdsRequestLog 请求gds记录
     * @return 请求gds记录集合
     */
    public List<GdsRequestLog> selectGdsRequestLogList(GdsRequestLog gdsRequestLog);

    /**
     * 新增请求gds记录
     * 
     * @param gdsRequestLog 请求gds记录
     * @return 结果
     */
    public int insertGdsRequestLog(GdsRequestLog gdsRequestLog);

    /**
     * 修改请求gds记录
     * 
     * @param gdsRequestLog 请求gds记录
     * @return 结果
     */
    public int updateGdsRequestLog(GdsRequestLog gdsRequestLog);

    /**
     * 删除请求gds记录
     * 
     * @param id 请求gds记录主键
     * @return 结果
     */
    public int deleteGdsRequestLogById(Long id);

    /**
     * 批量删除请求gds记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteGdsRequestLogByIds(Long[] ids);

    /**
     * 删除 maxDay 天前的GDS请求日志
     * @param maxDay
     * @return
     */
    int removeGdsLog(int maxDay);
}
