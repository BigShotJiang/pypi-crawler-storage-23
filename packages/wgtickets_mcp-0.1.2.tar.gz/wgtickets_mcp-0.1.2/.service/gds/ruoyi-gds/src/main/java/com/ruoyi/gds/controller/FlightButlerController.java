package com.ruoyi.gds.controller;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.gds.module.QueryPnrInfoReq;
import com.ruoyi.gds.module.domain.FlightChange;
import com.ruoyi.gds.module.domain.FlightFare;
import com.ruoyi.gds.module.vo.FlightChangeQueryVo;
import com.ruoyi.gds.module.vo.galileo.BaseFlightVo;
import com.ruoyi.gds.service.IFlightButlerService;
import com.ruoyi.gds.service.IFlightFareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 航班管理
 */
@RestController
@RequestMapping("/flight/butler")
public class FlightButlerController extends BaseController {
    @Autowired
    private IFlightButlerService flightButlerService;

    /**
     * 获取航班变更信息
     * @param flightChange
     * @return
     */
    @GetMapping("/getFlightChangeQueryVo")
    public FlightChangeQueryVo getFlightChangeQueryVo(FlightChange flightChange) {
        return flightButlerService.getFlightChangeQueryVo(flightChange);
    }
    /**
     * 订阅航班变更信息
     * @return
     */
    @GetMapping(value = "/flightSubscribe")
    public AjaxResult flightSubscribe(@RequestBody @Validated FlightChange flightChange) {
        return flightButlerService.flightSubscribe(flightChange);
    }

    /**
     * 获取航班管家推送信息
     * @return
     */
    @PostMapping(value = "/getFlightPushInfo")
    public void getFlightPushInfo(@RequestBody String json) {
        flightButlerService.getFlightPushInfo(json);
    }
}
