package com.ruoyi.gds.module.dto.galileo;

import cn.hutool.core.date.DatePattern;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.gds.enums.CabinCategoryType;
import com.ruoyi.gds.enums.SearchMethod;
import com.ruoyi.gds.exception.InvalidParamException;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 出发机场代码
     */
    private String fromAirportCode;

    /**
     * 出发城市代码
     */
    private String fromCityCode;

    /**
     * 到达机场代码
     */
    private String toAirportCode;

    /**
     * 到达城市代码
     */
    private String toCityCode;

    /**
     * 出发点是否扩大范围到起飞机场所在城市
     */
    private Boolean preferCity;

    /**
     * 是否允许转机
     */
    private Boolean transfer;

    /**
     * 中转机场
     */
    private String transferAirportCode;

    /**
     * 中转城市
     */
    private String transferCityCode;

    /**
     * 航司搜索方式
     */
    private SearchMethod carriersType;

    /**
     * 指定航司
     */
    private List<String> carriers;

    /**
     * 舱位等级搜索方式
     * Permitted 只返回特定舱位
     * Prohibited 排除特定舱位
     */
    private SearchMethod cabinsType;

    /**
     * 指定舱位等级
     */
    protected List<CabinCategoryType> cabins;

    /**
     * 舱位
     */
    private String bookingCode;

    /**
     * 出发日期
     */
    @NotNull(message = "出发日期不能为空")
    @DateTimeFormat(pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate deptDate;

    /**
     * 指定出发时间。非必填
     */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime depSpecificTime;

    /**
     * 在此时间之后出发。非必填
     */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime depAfterTime;

    /**
     * 在此时间之前出发。非必填
     */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime depBeforeTime;

    /**
     * 指定到达时间。非必填
     */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime arrSpecificTime;

    /**
     * 在此时间之后到达。非必填
     */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime arrAfterTime;

    /**
     * 在此时间之前到达。非必填
     */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime arrBeforeTime;

    /**
     * 从指定日期之前的偏移量。如 3，表示指定日期前三天
     */
    private Integer flexBefore;

    /**
     * 从指定日期之后的偏移量。如 3，表示指定日期后三天
     */
    private Integer flexAfter;


    public Boolean getPreferCity() {
        return Optional.ofNullable(preferCity).orElse(true);
    }

    /*public Boolean getTransfer() {
        return Optional.ofNullable(transfer).orElse(false);
    }*/

    public SearchMethod getCarriersType() {
        return Optional.ofNullable(carriersType).orElse(SearchMethod.PERMITTED);
    }

    public List<String> getCarriers() {
        return Optional.ofNullable(carriers)
                .map(carrierList -> carrierList.stream().filter(StringUtils::isNotBlank).map(String::toUpperCase).distinct().collect(Collectors.toList()))
                .orElse(Lists.newArrayList());
    }

    public SearchMethod getCabinsType() {
        return Optional.ofNullable(cabinsType).orElse(SearchMethod.PERMITTED);
    }


    public void check() {
        if (Objects.isNull(getDeptDate()))
            throw new InvalidParamException("未指定出发日期");

        if (StringUtils.isBlank(getFromAirportCode()) && StringUtils.isBlank(getFromCityCode()))
            throw new InvalidParamException("未指定出发城市或机场");

        if (StringUtils.isBlank(getToAirportCode()) && StringUtils.isBlank(getToCityCode()))
            throw new InvalidParamException("未指定到达城市或机场");
    }

}
