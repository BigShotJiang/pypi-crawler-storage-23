package com.ruoyi.gds.module.dto.galileo;

import cn.hutool.core.collection.CollectionUtil;
import com.ruoyi.common.utils.UUIDUtil;
import com.ruoyi.common.utils.ValidatorUtil;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.enums.CabinCategoryType;
import com.ruoyi.gds.enums.PassengerType;
import com.ruoyi.gds.enums.SearchMethod;
import com.ruoyi.gds.exception.InvalidParamException;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchFlightDto implements Serializable {

    private static final long serialVersionUID = 1L;

    private String traceId;

    /**
     * true：根据价格点与航段分组；false：只根据价格点分组
     */
    private Boolean solutionResult;

    /**
     * 航司搜索方式
     * Permitted 只返回特定航空公司的航班 (max 99)
     * Preferred 不仅返回特定航空公司的航班，也可能根据最佳价格返回其他航司的航班(max 99)
     * Prohibited 排除特定航空公司的航班(max 99)
     * 注意：同一个请求中，只能使用三个modifiers中的一个
     */
    private SearchMethod carriersType;

    /**
     * 指定航班
     */
    private List<String> carriers;

    /**
     * 舱位等级搜索方式
     * Permitted 只返回特定舱位等级
     * Preferred 不仅返回特定舱位等级，也可能根据最佳价格返回其他舱位等级
     */
    private SearchMethod cabinsType;

    /**
     * 指定舱位等级
     */
    protected List<CabinCategoryType> cabins;

    /**
     * 允许不同航司三次转机
     */
    private Boolean tripleInterlineCon;

    /**
     * 允许不同航司二次转机
     */
    private Boolean doubleInterlineCon;

    /**
     * 允许不同航司一次转机
     */
    private Boolean singleInterlineCon;

    /**
     * 允许相同航司三次转机
     */
    private Boolean tripleOnlineCon;

    /**
     * 允许相同航司二次转机
     */
    private Boolean doubleOnlineCon;

    /**
     * 允许相同航司一次转机
     */
    private Boolean singleOnlineCon;

    /**
     * 允许停站直飞
     */
    private Boolean stopDirects;

    /**
     * 允许不停站直飞
     */
    private Boolean nonStopDirects;

    /**
     * 乘客信息
     */
    @NotEmpty(message = "乘客信息不能为空")
    private List<PassengerType> passengers;

    /**
     * 行程信息
     */
    @NotEmpty(message = "行程信息不能为空")
    private List<FlightDto> flights;

    /**
     * 最大返回条数
     */
    private Integer maxResponse;

    /**
     * 无业务作用。仅用在记录GDS请求日志时使用
     */
    private String batchCode;

    public String getTraceId() {
        return StringUtils.isNotBlank(traceId) ? traceId : UUIDUtil.getUUID();
    }

    public Boolean getSolutionResult() {
        return Optional.ofNullable(solutionResult).orElse(true);
    }

    public SearchMethod getCarriersType() {
        return Optional.ofNullable(carriersType).orElse(SearchMethod.PREFERRED);
    }

    public SearchMethod getCabinsType() {
        return Optional.ofNullable(cabinsType).orElse(SearchMethod.PREFERRED);
    }

    /*public Boolean getTripleInterlineCon() {
        return Optional.ofNullable(tripleInterlineCon).orElse(true);
    }

    public Boolean getDoubleInterlineCon() {
        return Optional.ofNullable(doubleInterlineCon).orElse(true);
    }

    public Boolean getSingleInterlineCon() {
        return Optional.ofNullable(singleInterlineCon).orElse(true);
    }

    public Boolean getTripleOnlineCon() {
        return Optional.ofNullable(tripleOnlineCon).orElse(true);
    }

    public Boolean getDoubleOnlineCon() {
        return Optional.ofNullable(doubleOnlineCon).orElse(true);
    }

    public Boolean getSingleOnlineCon() {
        return Optional.ofNullable(singleOnlineCon).orElse(true);
    }

    public Boolean getStopDirects() {
        return Optional.ofNullable(stopDirects).orElse(true);
    }

    public Boolean getNonStopDirects() {
        return Optional.ofNullable(nonStopDirects).orElse(true);
    }*/


    public void check(){
        String errMsg = ValidatorUtil.validate(this);
        if (StringUtils.isNotBlank(errMsg)) {
            throw new InvalidParamException(errMsg);
        }

        if (CollectionUtil.isNotEmpty(cabins)) {
            switch (cabinsType) {
                case PERMITTED:
                    break;
                case PREFERRED:
                    if (cabins.size() > 1) throw new InvalidParamException("舱位等级搜索方式为'Preferred'时，只能指定一个舱位等级");
                    break;
                default:
                    throw new InvalidParamException("舱位等级搜索方式错误");
            }
        }

        Optional.ofNullable(getFlights()).ifPresent(flightList -> flightList.forEach(FlightDto::check));
    }

}
