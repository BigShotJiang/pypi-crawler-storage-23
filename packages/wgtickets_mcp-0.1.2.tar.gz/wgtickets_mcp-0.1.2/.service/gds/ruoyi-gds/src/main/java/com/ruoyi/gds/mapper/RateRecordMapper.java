package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.enums.RateType;
import com.ruoyi.gds.module.RateRecord;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.util.List;

/**
 * 汇率Mapper接口
 * 
 * @author ruoyi
 * @date 2025-08-11
 */
public interface RateRecordMapper extends BaseMapper<RateRecord>
{
    /**
     * 查询汇率
     * 
     * @param id 汇率主键
     * @return 汇率
     */
    public RateRecord selectRateRecordById(Long id);

    /**
     * 查询汇率列表
     * 
     * @param rateRecord 汇率
     * @return 汇率集合
     */
    public List<RateRecord> selectRateRecordList(RateRecord rateRecord);

    /**
     * 查询指定日期的汇率
     *
     * @param rateDate 日期
     * @return 汇率集合
     */
    public RateRecord selectByDate(@Param("rateDate") LocalDate rateDate, @Param("rateType") RateType rateType);

    /**
     * 新增汇率
     * 
     * @param rateRecord 汇率
     * @return 结果
     */
    public int insertRateRecord(RateRecord rateRecord);

    /**
     * 修改汇率
     * 
     * @param rateRecord 汇率
     * @return 结果
     */
    public int updateRateRecord(RateRecord rateRecord);

    /**
     * 删除汇率
     * 
     * @param id 汇率主键
     * @return 结果
     */
    public int deleteRateRecordById(Long id);

    /**
     * 批量删除汇率
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteRateRecordByIds(Long[] ids);
}
