package com.ruoyi.gds.config;

import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.gds.module.vo.RequestContextVo;
import com.ruoyi.gds.utils.ContextUtil;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.TaskDecorator;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.ThreadPoolExecutor;

@Configuration
public class ThreadConfig {

    // 核心线程池大小
    private static final int corePoolSize = 50;
    // 最大可创建的线程数
    private static final int maxPoolSize = 200;
    // 队列最大长度
    private static final int queueCapacity = 1000;
    // 线程池维护线程所允许的空闲时间
    private static final int keepAliveSeconds = 300;

    @Bean(name = "taskExecutor")
    public ThreadPoolTaskExecutor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setMaxPoolSize(maxPoolSize);
        executor.setCorePoolSize(corePoolSize);
        executor.setQueueCapacity(queueCapacity);
        executor.setKeepAliveSeconds(keepAliveSeconds);
        // executor.setTaskDecorator(new CustomTaskDecorator());
        // 线程池对拒绝任务(无线程可用)的处理策略
        executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
        executor.initialize();
        return executor;
    }

    public static class CustomTaskDecorator implements TaskDecorator {
        @Override
        public Runnable decorate(Runnable runnable) {
            RequestContextVo context = ContextUtil.getContext();
            return () -> {
                try {
                    System.out.println("[" + this.getClass().getName() + "] [Set] [ThreadId] " + Thread.currentThread().getId() + ", [ThreadName] "+ Thread.currentThread().getName() + ", [Context] " + JacksonUtil.toJsonString(ContextUtil.getContext()));
                    ContextUtil.setContext(context);
                    runnable.run();
                } finally {
                    System.out.println("[" + this.getClass().getName() + "] [Clean] [ThreadId] " + Thread.currentThread().getId() + ", [ThreadName] "+ Thread.currentThread().getName() + ", [Context] " + JacksonUtil.toJsonString(ContextUtil.getContext()));
                    ContextUtil.clear();
                }
            };
        }
    }

}
