package com.ruoyi.gds.common;

import com.ruoyi.gds.enums.PhoneMatch;

import java.util.Arrays;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public class ParamValidRegex {
    // 匹配字符串开头的连续字母
    public static final String CONTINUOUS_CHAR_STARTING_WITH_LATTER = "^([a-zA-Z]+)";

    // 乘机人类型
    public static final String PASSENGER_TYPE = "^(?i)(ADT|CNN|INF)$";

    // 中文 & 允许为空、空格、制表符
    public static final String NAME_ZH = "^[\\u4e00-\\u9fa5\\s]*$";

    // 至少一个字母
    public static final String NAME_EN = "^[a-zA-Z]{2,}$";

    // 性别
    public static final String GENDER = "^(?i)(M|F)$";

    // 电话号码
    public static final String PHONE = "^[\\d-]+$";

    // 中国大陆手机号 + 日本手机号
    public static final String PHONE_WITH_ZONE;
    // 中国大陆手机号 + 日本手机号 删除国际区号、+、-、空格
    public static final String PHONE_WITH_ZONE_REPLACE;

    // 邮箱
    public static final String EMAIL = "^(?:[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,})?$";

    // 证件类型
    public static final String CERTIFICATE_TYPE = "^(?i)(NI|P)$";
    /*public static final String CERTIFICATE_TYPE = "^(?i)(NI|P|IP|G|F|C|A|M|I)$";*/

    // 证件匹配身份证或护照
    public static final String CERTIFICATE = "^(?:\\d{15}|\\d{17}[\\dXx]|[A-Za-z0-9]{6,10})$";

    // 正则1和正则2的效果是相同的
    // 指令搜索提取行程、航司、人员、舱位、中转信息正则1
//    public static final String COMMAND_SEARCH_FLIGHT_REGEX = "^A(\\d{2}[A-Z]{3})([A-Z]{6})(?:\\*([A-Z]{2}))?\\*?(?:\\*A(\\d+))?\\*?(?:\\*C(\\d+))?\\*?(?:\\*B(\\d+))?\\*?(?:\\*([EFP]))?\\*?(?:\\*([01]))?\\*?$";
    // 指令搜索提取行程、航司、人员、舱位、中转信息正则2
    public static final String COMMAND_SEARCH_FLIGHT_REGEX = "^A(\\d{2}[A-Z]{3})([A-Z]{6})(?:\\*([A-Z]{2})|\\*)?(?:\\*A(\\d+)|\\*)?(?:\\*C(\\d+)|\\*)?(?:\\*B(\\d+)|\\*)?(?:\\*([EFP])|\\*)?(?:\\*([01])|\\*)?$";


    static {
        PHONE_WITH_ZONE = Arrays.stream(PhoneMatch.values()).map(item -> String.format("(%s)", item.getRegex())).collect(Collectors.joining("|"));
        PHONE_WITH_ZONE_REPLACE = Arrays.stream(PhoneMatch.values()).map(item -> String.format("(%s)", item.getReplaceRegex())).collect(Collectors.joining("|"));
    }


    public static void main(String[] args) {
        Pattern pattern = Pattern.compile(PHONE);
        System.out.println(pattern.matcher("027-88888888").matches());
        System.out.println(pattern.matcher("13000000001").matches());
        System.out.println(pattern.matcher("1300000000").matches());
        System.out.println(pattern.matcher("1300000000#").matches());
        System.out.println(pattern.matcher("1300000000a").matches());
        System.out.println(pattern.matcher("027——88888888").matches());
        System.out.println(pattern.matcher("027—88888888").matches());
    }

}
