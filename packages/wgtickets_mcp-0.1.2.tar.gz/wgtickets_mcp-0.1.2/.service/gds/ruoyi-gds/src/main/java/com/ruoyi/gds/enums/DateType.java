package com.ruoyi.gds.enums;

public enum DateType {
    // 生日
    BIRTH_DAY,

    // 证件有效期
    CERTIFICATE_EXPIRE

}
