package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.gds.module.domain.FlightSolutionSegment;
import com.ruoyi.gds.service.IFlightSolutionSegmentService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 行程方案航段Controller
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@RestController
@RequestMapping("/flight/solution/segment")
public class FlightSolutionSegmentController extends BaseController {
    @Autowired
    private IFlightSolutionSegmentService flightSolutionSegmentService;

    /**
     * 查询行程方案航段列表
     */
    @PreAuthorize("@ss.hasPermi('system:segment:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightSolutionSegment flightSolutionSegment) {
        startPage();
        List<FlightSolutionSegment> list = flightSolutionSegmentService.selectFlightSolutionSegmentList(flightSolutionSegment);
        return getDataTable(list);
    }

    /**
     * 导出行程方案航段列表
     */
    @PreAuthorize("@ss.hasPermi('system:segment:export')")
    @Log(title = "行程方案航段", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightSolutionSegment flightSolutionSegment) {
        List<FlightSolutionSegment> list = flightSolutionSegmentService.selectFlightSolutionSegmentList(flightSolutionSegment);
        ExcelUtil<FlightSolutionSegment> util = new ExcelUtil<FlightSolutionSegment>(FlightSolutionSegment.class);
        util.exportExcel(response, list, "行程方案航段数据");
    }

    /**
     * 获取行程方案航段详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:segment:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(flightSolutionSegmentService.selectFlightSolutionSegmentById(id));
    }

    /**
     * 新增行程方案航段
     */
    @PreAuthorize("@ss.hasPermi('system:segment:add')")
    @Log(title = "行程方案航段", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightSolutionSegment flightSolutionSegment) {
        return toAjax(flightSolutionSegmentService.insertFlightSolutionSegment(flightSolutionSegment));
    }

    /**
     * 修改行程方案航段
     */
    @PreAuthorize("@ss.hasPermi('system:segment:edit')")
    @Log(title = "行程方案航段", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightSolutionSegment flightSolutionSegment) {
        return toAjax(flightSolutionSegmentService.updateFlightSolutionSegment(flightSolutionSegment));
    }

    /**
     * 删除行程方案航段
     */
    @PreAuthorize("@ss.hasPermi('system:segment:remove')")
    @Log(title = "行程方案航段", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(flightSolutionSegmentService.deleteFlightSolutionSegmentByIds(ids));
    }
}
