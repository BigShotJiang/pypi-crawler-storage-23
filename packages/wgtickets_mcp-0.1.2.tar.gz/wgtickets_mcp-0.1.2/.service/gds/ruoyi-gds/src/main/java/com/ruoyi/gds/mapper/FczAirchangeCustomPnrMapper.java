package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FczAirchangeCustomPnr;

import java.util.List;

/**
 * 飞常准—航变定制与PNR关联Mapper接口
 * 
 * @author ruoyi
 * @date 2025-11-21
 */
public interface FczAirchangeCustomPnrMapper extends BaseMapper<FczAirchangeCustomPnr>
{
    /**
     * 查询飞常准—航变定制与PNR关联
     * 
     * @param id 飞常准—航变定制与PNR关联主键
     * @return 飞常准—航变定制与PNR关联
     */
    public FczAirchangeCustomPnr selectFczAirchangeCustomPnrById(Long id);

    /**
     * 查询飞常准—航变定制与PNR关联列表
     * 
     * @param fczAirchangeCustomPnr 飞常准—航变定制与PNR关联
     * @return 飞常准—航变定制与PNR关联集合
     */
    public List<FczAirchangeCustomPnr> selectFczAirchangeCustomPnrList(FczAirchangeCustomPnr fczAirchangeCustomPnr);

    /**
     * 新增飞常准—航变定制与PNR关联
     * 
     * @param fczAirchangeCustomPnr 飞常准—航变定制与PNR关联
     * @return 结果
     */
    public int insertFczAirchangeCustomPnr(FczAirchangeCustomPnr fczAirchangeCustomPnr);

    /**
     * 修改飞常准—航变定制与PNR关联
     * 
     * @param fczAirchangeCustomPnr 飞常准—航变定制与PNR关联
     * @return 结果
     */
    public int updateFczAirchangeCustomPnr(FczAirchangeCustomPnr fczAirchangeCustomPnr);

    /**
     * 删除飞常准—航变定制与PNR关联
     * 
     * @param id 飞常准—航变定制与PNR关联主键
     * @return 结果
     */
    public int deleteFczAirchangeCustomPnrById(Long id);

    /**
     * 批量删除飞常准—航变定制与PNR关联
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFczAirchangeCustomPnrByIds(Long[] ids);
}
