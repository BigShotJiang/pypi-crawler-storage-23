package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum DayInWeek {

    MONDAY(1, "周一"),
    TUESDAY(2, "周二"),
    WEDNESDAY(3, "周三"),
    THURSDAY(4, "周四"),
    FRIDAY(5, "周五"),
    SATURDAY(6, "周六"),
    SUNDAY(7, "周日");

    @JsonValue
    private final Integer code;

    private final String desc;

    DayInWeek(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static DayInWeek fromCode(Integer code) {
        return Arrays.stream(DayInWeek.values()).filter(item -> Objects.nonNull(code) && Objects.equals(item.code, code)).findFirst().orElse(null);
    }

    public static DayInWeek fromName(String name) {
        return Arrays.stream(DayInWeek.values()).filter(item -> StringUtils.isNotBlank(name) && item.name().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
