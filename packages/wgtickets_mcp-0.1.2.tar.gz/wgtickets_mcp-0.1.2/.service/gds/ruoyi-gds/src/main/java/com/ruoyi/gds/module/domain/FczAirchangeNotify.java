package com.ruoyi.gds.module.domain;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 飞常准—航变通知记录对象 fcz_airchange_notify
 * 
 * @author ruoyi
 * @date 2025-11-18
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FczAirchangeNotify implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** FID（定制航变通知记录表ID） */
    @Excel(name = "FID", readConverterExp = "定=制航变通知记录表ID")
    private String fid;

    /** 出发机场三字码 */
    @Excel(name = "出发机场三字码")
    private String origin;

    /** 到达机场三字码 */
    @Excel(name = "到达机场三字码")
    private String destination;

    /** 航司 */
    @Excel(name = "航司")
    private String carrier;

    /** 航班号 */
    @Excel(name = "航班号")
    private Integer flightNumber;

    /** 航班状态 */
    @Excel(name = "航班状态")
    private String flightStatus;

    /** 飞常准提送的原始信息 */
    @Excel(name = "飞常准提送的原始信息")
    private String originalInfo;

    /** 创建时间 */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("fid", getFid())
            .append("origin", getOrigin())
            .append("destination", getDestination())
            .append("carrier", getCarrier())
            .append("flightNumber", getFlightNumber())
            .append("flightStatus", getFlightStatus())
            .append("originalInfo", getOriginalInfo())
            .append("createTime", getCreateTime())
            .append("delFlag", isDelFlag())
            .toString();
    }
}
