package com.ruoyi.gds.module.dto.galileo;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.UUIDUtil;
import com.ruoyi.common.utils.spring.SpringUtils;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.common.GalileoConstant;
import com.ruoyi.gds.config.GDSConfig;
import com.ruoyi.gds.enums.*;
import com.ruoyi.gds.enums.PassengerType;
import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.gds.module.CreatePnrReq;
import com.ruoyi.gds.module.QueryTicketNumberInfoReq;
import com.ruoyi.gds.module.SearchCabinQuantityReq;
import com.ruoyi.gds.module.SearchPriceReq;
import com.ruoyi.gds.module.vo.CreditCardVo;
import com.ruoyi.gds.schema.galileo.air_v50_0.*;
import com.ruoyi.gds.schema.galileo.common_v50_0.*;
import com.ruoyi.gds.schema.galileo.req.*;
import com.ruoyi.gds.schema.galileo.rsp.AirPriceRspSoap;
import com.ruoyi.gds.schema.galileo.universal_v50_0.*;
import com.ruoyi.gds.utils.DateUtil;
import com.ruoyi.gds.utils.GalileoDataUtil;
import com.ruoyi.gds.utils.StrUtil;
import com.ruoyi.gds.utils.XmlUtil;
import com.sun.org.apache.xerces.internal.jaxp.datatype.XMLGregorianCalendarImpl;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;

import javax.xml.datatype.XMLGregorianCalendar;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.Period;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
public class RequestBuilder {

    private static final GDSConfig gdsConfig = SpringUtils.getBean(GDSConfig.class);

    public static String buildAirRetrieveDocumentReqSoap(QueryTicketNumberInfoReq retrieveIssuedTicketDto) {
        AirRetrieveDocumentReq airRetrieveDocumentReq = new AirRetrieveDocumentReq();
        airRetrieveDocumentReq.setProviderCode(GDSType.GALELIO.getCode());
        airRetrieveDocumentReq.setReturnRestrictions(true);
        airRetrieveDocumentReq.setReturnPricing(true);
        /*airRetrieveDocumentReq.setRetrieveMCO(true);*/
        airRetrieveDocumentReq.setProviderLocatorCode(retrieveIssuedTicketDto.getPnr());
        airRetrieveDocumentReq.getTicketNumber().addAll(retrieveIssuedTicketDto.getTicketNumbers());

        AirRetrieveDocumentReqSoap airRetrieveDocumentReqSoap = AirRetrieveDocumentReqSoap.build(airRetrieveDocumentReq);
        return XmlUtil.beanToXmlByJAXB(airRetrieveDocumentReqSoap);
    }

    public static String buildUniversalRecordModifyReqSoapByDeleteTicketingModifiers(GalileoIssueTicketDto galileoIssueTicketDto, List<String> ticketingModifierKeys) {
        List<UniversalModifyCmd> universalModifyCmds = ticketingModifierKeys.stream().map(ticketingModifierKey -> {
            AirDelete airDelete = new AirDelete();
            airDelete.setReservationLocatorCode(galileoIssueTicketDto.getReservationCode());
            airDelete.setElement(TypeElement.TICKETING_MODIFIERS);
            airDelete.setKey(ticketingModifierKey);

            UniversalModifyCmd universalModifyCmd = new UniversalModifyCmd();
            universalModifyCmd.setKey(UUIDUtil.getUUID());
            universalModifyCmd.setAirDelete(airDelete);
            return universalModifyCmd;
        }).collect(Collectors.toList());

        RecordIdentifier recordIdentifier = new RecordIdentifier();
        recordIdentifier.setProviderCode(GDSType.GALELIO.getCode());
        recordIdentifier.setUniversalLocatorCode(galileoIssueTicketDto.getUniversalCode());
        recordIdentifier.setProviderLocatorCode(galileoIssueTicketDto.getPnr());

        UniversalRecordModifyReq universalRecordModifyReq = new UniversalRecordModifyReq();
        universalRecordModifyReq.setVersion(BigInteger.valueOf(galileoIssueTicketDto.getVersion()));
        universalRecordModifyReq.setReturnRecord(true);
        universalRecordModifyReq.setRecordIdentifier(recordIdentifier);
        universalRecordModifyReq.getUniversalModifyCmd().addAll(universalModifyCmds);

        UniversalRecordModifyReqSoap universalRecordModifyReqSoap = UniversalRecordModifyReqSoap.build(universalRecordModifyReq);
        return XmlUtil.beanToXmlByJAXB(universalRecordModifyReqSoap);
    }

    public static String buildUniversalRecordModifyReqSoapByAddCommission(GalileoIssueTicketDto galileoIssueTicketDto, List<String> airPricingInfoKeyList) {
        List<AirPricingInfoRef> airPricingInfoRefs = airPricingInfoKeyList.stream()
                .map(airPricingInfoKey -> {
                    AirPricingInfoRef airPricingInfoRef = new AirPricingInfoRef();
                    airPricingInfoRef.setKey(airPricingInfoKey);
                    return airPricingInfoRef;
                }).collect(Collectors.toList());

        Commission commission = new Commission();
        commission.setKey(UUIDUtil.getUUID());
        commission.setLevel(TypeCommissionLevel.FARE);
        commission.setType(TypeCommissionType.PERCENT_BASE);
        commission.setPercentage(galileoIssueTicketDto.getCommission().toPlainString());

        TicketingModifiers ticketingModifiers = new TicketingModifiers();
        ticketingModifiers.setCommission(commission);

        if (StringUtils.isNotBlank(galileoIssueTicketDto.getTourCode())) {
            TourCode tourCode = new TourCode();
            tourCode.setValue(galileoIssueTicketDto.getTourCode());
            ticketingModifiers.setTourCode(tourCode);
        }

        AirPricingTicketingModifiers airPricingTicketingModifiers = new AirPricingTicketingModifiers();
        airPricingTicketingModifiers.getAirPricingInfoRef().addAll(airPricingInfoRefs);
        airPricingTicketingModifiers.setTicketingModifiers(ticketingModifiers);

        AirAdd airAdd = new AirAdd();
        airAdd.setReservationLocatorCode(galileoIssueTicketDto.getReservationCode());
        airAdd.getAirPricingTicketingModifiers().add(airPricingTicketingModifiers);

        UniversalModifyCmd universalModifyCmd = new UniversalModifyCmd();
        universalModifyCmd.setKey(UUIDUtil.getUUID());
        universalModifyCmd.setAirAdd(airAdd);

        RecordIdentifier recordIdentifier = new RecordIdentifier();
        recordIdentifier.setProviderCode(GDSType.GALELIO.getCode());
        recordIdentifier.setUniversalLocatorCode(galileoIssueTicketDto.getUniversalCode());
        recordIdentifier.setProviderLocatorCode(galileoIssueTicketDto.getPnr());

        UniversalRecordModifyReq universalRecordModifyReq = new UniversalRecordModifyReq();
        universalRecordModifyReq.setVersion(BigInteger.valueOf(galileoIssueTicketDto.getVersion()));
        universalRecordModifyReq.setReturnRecord(true);
        universalRecordModifyReq.setRecordIdentifier(recordIdentifier);
        universalRecordModifyReq.getUniversalModifyCmd().add(universalModifyCmd);

        UniversalRecordModifyReqSoap universalRecordModifyReqSoap = UniversalRecordModifyReqSoap.build(universalRecordModifyReq);
        return XmlUtil.beanToXmlByJAXB(universalRecordModifyReqSoap);
    }

    public static String buildUniversalRecordModifyReqSoapByUpdateFOP(GalileoIssueTicketDto galileoIssueTicketDto, List<AirPricingInfo> airPricingInfos) {
        List<AirPricingInfoRef> airPricingInfoRefs = airPricingInfos.stream()
                .map(AirPricingInfo::getKey)
                .map(airPricingInfoKey -> {
                    AirPricingInfoRef airPricingInfoRef = new AirPricingInfoRef();
                    airPricingInfoRef.setKey(airPricingInfoKey);
                    return airPricingInfoRef;
                }).collect(Collectors.toList());

        FormOfPayment formOfPayment;
        switch (galileoIssueTicketDto.getIssueType()) {
            case CreditCard:
                formOfPayment = buildFormOfPayment(galileoIssueTicketDto.getCreditCard());
                break;
            case Cash:
                formOfPayment = buildFormOfPaymentWithCash();
                break;
            default:
                throw new ServiceException("出票支付方式错误", HttpStatus.BAD_REQUEST);
        }

        List<Payment> payments = airPricingInfos.stream().map(airPricingInfo -> {
            String currencyCode = StrUtil.removeNumber(airPricingInfo.getApproximateTotalPrice());
            int totalAmount = Integer.parseInt(StrUtil.removeChar(airPricingInfo.getApproximateTotalPrice())) * airPricingInfo.getPassengerType().size();
            Payment p = new Payment();
            p.setType("Itinerary");
            p.setFormOfPaymentRef(formOfPayment.getKey());
            p.setAmount(currencyCode + totalAmount);
            p.setApproximateAmount(currencyCode + totalAmount);
            p.setElStat(TypeElementStatus.A);
            return p;
        }).collect(Collectors.toList());


        AirPricingPayment airPricingPayment = new AirPricingPayment();
        airPricingPayment.getAirPricingInfoRef().addAll(airPricingInfoRefs);
        airPricingPayment.getFormOfPayment().add(formOfPayment);
        if (CollectionUtil.isNotEmpty(payments)) airPricingPayment.getPayment().addAll(payments);

        AirUpdate airUpdate = new AirUpdate();
        airUpdate.setReservationLocatorCode(galileoIssueTicketDto.getReservationCode());
        airUpdate.setAirPricingPayment(airPricingPayment);

        UniversalModifyCmd universalModifyCmd = new UniversalModifyCmd();
        universalModifyCmd.setKey(UUIDUtil.getUUID());
        universalModifyCmd.setAirUpdate(airUpdate);

        RecordIdentifier recordIdentifier = new RecordIdentifier();
        recordIdentifier.setProviderCode(GDSType.GALELIO.getCode());
        recordIdentifier.setUniversalLocatorCode(galileoIssueTicketDto.getUniversalCode());
        recordIdentifier.setProviderLocatorCode(galileoIssueTicketDto.getPnr());

        UniversalRecordModifyReq universalRecordModifyReq = new UniversalRecordModifyReq();
        universalRecordModifyReq.setVersion(BigInteger.valueOf(galileoIssueTicketDto.getVersion()));
        universalRecordModifyReq.setReturnRecord(true);
        universalRecordModifyReq.setRecordIdentifier(recordIdentifier);
        universalRecordModifyReq.getUniversalModifyCmd().add(universalModifyCmd);

        UniversalRecordModifyReqSoap universalRecordModifyReqSoap = UniversalRecordModifyReqSoap.build(universalRecordModifyReq);
        return XmlUtil.beanToXmlByJAXB(universalRecordModifyReqSoap);
    }

    public static String buildUniversalRecordModifyReqSoapByUpdateFOP(GalileoIssueTicketDto galileoIssueTicketDto, AirPricingInfo airPricingInfo) {
        List<String> airPricingInfoKeys = Lists.newArrayList(airPricingInfo.getKey());
        String currencyCode = StrUtil.removeNumber(airPricingInfo.getApproximateTotalPrice());
        Integer totalPrice = Integer.parseInt(StrUtil.removeChar(airPricingInfo.getApproximateTotalPrice()));

        List<AirPricingInfoRef> airPricingInfoRefs = airPricingInfoKeys.stream()
                .map(airPricingInfoKey -> {
                    AirPricingInfoRef airPricingInfoRef = new AirPricingInfoRef();
                    airPricingInfoRef.setKey(airPricingInfoKey);
                    return airPricingInfoRef;
                }).collect(Collectors.toList());

        FormOfPayment formOfPayment;
        switch (galileoIssueTicketDto.getIssueType()) {
            case CreditCard:
                formOfPayment = buildFormOfPayment(galileoIssueTicketDto.getCreditCard());
                break;
            case Cash:
                formOfPayment = buildFormOfPaymentWithCash();
                break;
            default:
                throw new ServiceException("出票支付方式错误", HttpStatus.BAD_REQUEST);
        }

        Payment payment = new Payment();
        payment.setType("Itinerary");
        payment.setFormOfPaymentRef(formOfPayment.getKey());
        payment.setAmount(currencyCode + totalPrice);
        payment.setApproximateAmount(currencyCode + totalPrice);
        payment.setElStat(TypeElementStatus.A);

        AirPricingPayment airPricingPayment = new AirPricingPayment();
        airPricingPayment.getAirPricingInfoRef().addAll(airPricingInfoRefs);
        airPricingPayment.getFormOfPayment().add(formOfPayment);
        airPricingPayment.getPayment().add(payment);

        AirUpdate airUpdate = new AirUpdate();
        airUpdate.setReservationLocatorCode(galileoIssueTicketDto.getReservationCode());
        airUpdate.setAirPricingPayment(airPricingPayment);

        UniversalModifyCmd universalModifyCmd = new UniversalModifyCmd();
        universalModifyCmd.setKey(UUIDUtil.getUUID());
        universalModifyCmd.setAirUpdate(airUpdate);

        RecordIdentifier recordIdentifier = new RecordIdentifier();
        recordIdentifier.setProviderCode(GDSType.GALELIO.getCode());
        recordIdentifier.setUniversalLocatorCode(galileoIssueTicketDto.getUniversalCode());
        recordIdentifier.setProviderLocatorCode(galileoIssueTicketDto.getPnr());

        UniversalRecordModifyReq universalRecordModifyReq = new UniversalRecordModifyReq();
        universalRecordModifyReq.setVersion(BigInteger.valueOf(galileoIssueTicketDto.getVersion()));
        universalRecordModifyReq.setReturnRecord(true);
        universalRecordModifyReq.setRecordIdentifier(recordIdentifier);
        universalRecordModifyReq.getUniversalModifyCmd().add(universalModifyCmd);

        UniversalRecordModifyReqSoap universalRecordModifyReqSoap = UniversalRecordModifyReqSoap.build(universalRecordModifyReq);
        return XmlUtil.beanToXmlByJAXB(universalRecordModifyReqSoap);
    }

    public static String buildUniversalRecordModifyReqSoapByAddPrice(GalileoIssueTicketDto galileoIssueTicketDto, List<AirPricingInfo> airPricingInfos) {
        if (CollectionUtil.isEmpty(airPricingInfos)) {
            throw new InvalidParamException("PNR需存储的报价为空");
        }

        airPricingInfos.forEach(airPricingInfo -> airPricingInfo.getBookingInfo().forEach(bookingInfo -> bookingInfo.setHostTokenRef(null)));

        AirAdd airAdd = new AirAdd();
        airAdd.setReservationLocatorCode(galileoIssueTicketDto.getReservationCode());
        airAdd.getAirPricingInfo().addAll(airPricingInfos);

        UniversalModifyCmd universalModifyCmd = new UniversalModifyCmd();
        universalModifyCmd.setKey(UUIDUtil.getUUID());
        universalModifyCmd.setAirAdd(airAdd);

        RecordIdentifier recordIdentifier = new RecordIdentifier();
        recordIdentifier.setProviderCode(GDSType.GALELIO.getCode());
        recordIdentifier.setUniversalLocatorCode(galileoIssueTicketDto.getUniversalCode());
        recordIdentifier.setProviderLocatorCode(galileoIssueTicketDto.getPnr());

        UniversalRecordModifyReq universalRecordModifyReq = new UniversalRecordModifyReq();
        universalRecordModifyReq.setVersion(BigInteger.valueOf(galileoIssueTicketDto.getVersion()));
        universalRecordModifyReq.setReturnRecord(true);
        universalRecordModifyReq.setRecordIdentifier(recordIdentifier);
        universalRecordModifyReq.getUniversalModifyCmd().add(universalModifyCmd);

        UniversalRecordModifyReqSoap universalRecordModifyReqSoap = UniversalRecordModifyReqSoap.build(universalRecordModifyReq);
        return XmlUtil.beanToXmlByJAXB(universalRecordModifyReqSoap);
    }

    public static String buildUniversalRecordModifyReqSoapByAddPrice(GalileoIssueTicketDto galileoIssueTicketDto, AirPricingInfo airPricingInfo) {
        if (Objects.isNull(airPricingInfo)) {
            throw new InvalidParamException("PNR需存储的报价为空");
        }

        AirAdd airAdd = new AirAdd();
        airAdd.setReservationLocatorCode(galileoIssueTicketDto.getReservationCode());
        airAdd.getAirPricingInfo().add(airPricingInfo);

        UniversalModifyCmd universalModifyCmd = new UniversalModifyCmd();
        universalModifyCmd.setKey(UUIDUtil.getUUID());
        universalModifyCmd.setAirAdd(airAdd);

        RecordIdentifier recordIdentifier = new RecordIdentifier();
        recordIdentifier.setProviderCode(GDSType.GALELIO.getCode());
        recordIdentifier.setUniversalLocatorCode(galileoIssueTicketDto.getUniversalCode());
        recordIdentifier.setProviderLocatorCode(galileoIssueTicketDto.getPnr());

        UniversalRecordModifyReq universalRecordModifyReq = new UniversalRecordModifyReq();
        universalRecordModifyReq.setVersion(BigInteger.valueOf(galileoIssueTicketDto.getVersion()));
        universalRecordModifyReq.setReturnRecord(true);
        universalRecordModifyReq.setRecordIdentifier(recordIdentifier);
        universalRecordModifyReq.getUniversalModifyCmd().add(universalModifyCmd);

        UniversalRecordModifyReqSoap universalRecordModifyReqSoap = UniversalRecordModifyReqSoap.build(universalRecordModifyReq);
        return XmlUtil.beanToXmlByJAXB(universalRecordModifyReqSoap);
    }

    public static String buildUniversalRecordModifyReqSoapByDeletePrice(GalileoIssueTicketDto galileoIssueTicketDto) {
        if (CollectionUtil.isEmpty(galileoIssueTicketDto.getAirPricingInfoKeys())) {
            /*throw new InvalidParamException("PNR已存储的报价Key为空");*/
            return "";
        }

        List<UniversalModifyCmd> universalModifyCmds = galileoIssueTicketDto.getAirPricingInfoKeys().stream().map(airPricingInfoKey -> {
            AirDelete airDelete = new AirDelete();
            airDelete.setKey(airPricingInfoKey);
            airDelete.setReservationLocatorCode(galileoIssueTicketDto.getReservationCode());
            airDelete.setElement(TypeElement.AIR_PRICING_INFO);

            UniversalModifyCmd universalModifyCmd = new UniversalModifyCmd();
            universalModifyCmd.setKey(String.valueOf(galileoIssueTicketDto.getAirPricingInfoKeys().indexOf(airPricingInfoKey) + 1));
            universalModifyCmd.setAirDelete(airDelete);
            return universalModifyCmd;
        }).collect(Collectors.toList());


        RecordIdentifier recordIdentifier = new RecordIdentifier();
        recordIdentifier.setProviderCode(GDSType.GALELIO.getCode());
        recordIdentifier.setUniversalLocatorCode(galileoIssueTicketDto.getUniversalCode());
        recordIdentifier.setProviderLocatorCode(galileoIssueTicketDto.getPnr());

        UniversalRecordModifyReq universalRecordModifyReq = new UniversalRecordModifyReq();
        universalRecordModifyReq.setVersion(BigInteger.valueOf(galileoIssueTicketDto.getVersion()));
        universalRecordModifyReq.setReturnRecord(true);
        universalRecordModifyReq.setRecordIdentifier(recordIdentifier);
        universalRecordModifyReq.getUniversalModifyCmd().addAll(universalModifyCmds);

        UniversalRecordModifyReqSoap universalRecordModifyReqSoap = UniversalRecordModifyReqSoap.build(universalRecordModifyReq);

        return XmlUtil.beanToXmlByJAXB(universalRecordModifyReqSoap);
    }

    public static String buildAirTicketingReqSoap(String airReservationCode, List<String> airPricingInfoKeys) {
        BillingPointOfSaleInfo billingPointOfSaleInfo = new BillingPointOfSaleInfo();
        billingPointOfSaleInfo.setOriginApplication(GalileoConstant.ORIGIN_APPLICATION);

        AirReservationLocatorCode airReservationLocatorCode = new AirReservationLocatorCode();
        airReservationLocatorCode.setValue(airReservationCode);

        List<AirTicketingReq.AirPricingInfoRef> airPricingInfoRefs = airPricingInfoKeys.stream().map(airPricingInfoKey -> {
            AirTicketingReq.AirPricingInfoRef airPricingInfoRef = new AirTicketingReq.AirPricingInfoRef();
            airPricingInfoRef.setKey(airPricingInfoKey);
            return airPricingInfoRef;
        }).collect(Collectors.toList());

        AirTicketingReq airTicketingReq = new AirTicketingReq();
        airTicketingReq.setBillingPointOfSaleInfo(billingPointOfSaleInfo);
        airTicketingReq.setAirReservationLocatorCode(airReservationLocatorCode);
        airTicketingReq.getAirPricingInfoRef().addAll(airPricingInfoRefs);

        AirTicketingReqSoap airTicketingReqSoap = AirTicketingReqSoap.build(airTicketingReq);
        return XmlUtil.beanToXmlByJAXB(airTicketingReqSoap);
    }

    public static String buildGdsQueuePlaceReqSoap(String pnr) {
        GdsQueuePlaceReqSoap gdsQueuePlaceReqSoap = GdsQueuePlaceReqSoap.build(pnr);
        return XmlUtil.beanToXmlByJAXB(gdsQueuePlaceReqSoap);
    }

    public static String buildLowFareSearchReqSoap(SearchFlightDto searchFlightDto) {
        // 航线筛选条件
        AirSearchModifiers airSearchModifiers = buildAirSearchModifiers(searchFlightDto);

        // 价格设置
        AirPricingModifiers airPricingModifiers = buildAirPricingModifiers();

        // 行程
        List<SearchAirLeg> searchAirLegs = buildSearchAirLegs(searchFlightDto.getFlights());

        // 出行人
        List<SearchPassenger> searchPassengers = buildPassengers(searchFlightDto.getPassengers());

        LowFareSearchReq lowFareSearchReq = new LowFareSearchReq();
        lowFareSearchReq.setSolutionResult(searchFlightDto.getSolutionResult());  // true：根据价格点与航段分组；false：只根据价格点分组
        lowFareSearchReq.setPreferCompleteItinerary(true);
        lowFareSearchReq.setTraceId(UUIDUtil.getUUID());
        lowFareSearchReq.setAuthorizedBy(gdsConfig.getGalileo().getAuthorized());
        lowFareSearchReq.setAirSearchModifiers(airSearchModifiers);     // 航线筛选条件
        lowFareSearchReq.setAirPricingModifiers(airPricingModifiers);   // 价格设置
        lowFareSearchReq.getSearchAirLeg().addAll(searchAirLegs);       // 行程
        lowFareSearchReq.getSearchPassenger().addAll(searchPassengers); // 出行人

        LowFareSearchReqSoap lowFareSearchReqSoap = LowFareSearchReqSoap.build(lowFareSearchReq);

        return XmlUtil.beanToXmlByJAXB(lowFareSearchReqSoap);
    }

    public static String buildAirPriceReqSoap(SearchPriceReq priceDto) {
        // 校验并设置航班舱位号
        priceDto.checkAndSetCabin();

        List<TypeBaseAirSegment> airSegments = Lists.newArrayList();
        List<AirSegmentPricingModifiers> airSegmentPricingModifiersList = Lists.newArrayList();
        priceDto.getSegements().forEach(segementDto -> {
            TypeBaseAirSegment airSegment = new TypeBaseAirSegment();
            airSegment.setKey(segementDto.getSegmentKey());
            airSegment.setProviderCode(segementDto.getProviderCode().getCode());
            airSegment.setGroup(segementDto.getGroup());
            airSegment.setCarrier(segementDto.getCarrier());
            airSegment.setFlightNumber(segementDto.getFlightNumber());
            airSegment.setOrigin(segementDto.getOrigin());
            airSegment.setDestination(segementDto.getDestination());
            airSegment.setDepartureTime(segementDto.getDepartureTime());
            airSegment.setArrivalTime(segementDto.getArrivalTime());
            airSegments.add(airSegment);

            AirSegmentPricingModifiers airSegmentPricingModifiers = buildAirSegmentPricingModifiers(segementDto, CollectionUtil.isNotEmpty(priceDto.getCabins()));
            if (Objects.nonNull(airSegmentPricingModifiers)) {
                airSegmentPricingModifiersList.add(airSegmentPricingModifiers);
            }
        });

        AirItinerary airItinerary = new AirItinerary();
        airItinerary.getAirSegment().addAll(initSegmentConnection(airSegments));


        AirPricingCommand airPricingCommand = new AirPricingCommand();
        airPricingCommand.getAirSegmentPricingModifiers().addAll(airSegmentPricingModifiersList);


        List<SearchPassenger> searchPassengers = buildPassengers(priceDto.getPassengers());


        BrandModifiers.BasicDetailsOnly basicDetailsOnly = new BrandModifiers.BasicDetailsOnly();
        basicDetailsOnly.setReturnBasicDetails(true);

        BrandModifiers brandModifiers = new BrandModifiers();
        brandModifiers.setBasicDetailsOnly(basicDetailsOnly);


        /*AirPricingModifiers.AccountCodes accountCodes = priceDto.getAccountPrice() ? GalileoDataUtil.getAccountCodes(priceDto.getSegements()) : null;*/
        AirPricingModifiers.AccountCodes accountCodes = GalileoDataUtil.getAccountCodes(priceDto.getAccountCode());

        AirPricingModifiers airPricingModifiers = new AirPricingModifiers();
        airPricingModifiers.setFaresIndicator(TypeFaresIndicator.ALL_FARES);
        airPricingModifiers.setReturnFailedSegments(true);
        airPricingModifiers.setReturnServices(false);  // ReturnServices=“false“: 不返回附加服务, 默认为false
        airPricingModifiers.setBrandModifiers(brandModifiers);  // ReturnBasicDetails=“true“: 只返回基本票价描述(Branding)资料(幷最多返回一个升舱内容)
        airPricingModifiers.setAccountCodes(accountCodes);  // 大客户开票

        AirPriceReq airPriceReq = new AirPriceReq();
        airPriceReq.setAuthorizedBy(gdsConfig.getGalileo().getAuthorized());
        airPriceReq.setAirItinerary(airItinerary);
        airPriceReq.getSearchPassenger().addAll(searchPassengers);
        airPriceReq.setAirPricingModifiers(airPricingModifiers);
        airPriceReq.getAirPricingCommand().add(airPricingCommand);  // 搜索指定舱位，不传时返回最便宜的票价
        // airPriceReq.setAirPricingModifiers(buildAirPricingModifiers(priceDto));  // 搜索指定舱位等级


        AirPriceReqSoap airPriceReqSoap = AirPriceReqSoap.build(airPriceReq);
        return XmlUtil.beanToXmlByJAXB(airPriceReqSoap);
    }

    public static String buildAvailabilitySearchReq(Boolean useOperating, SearchCabinQuantityReq searchReq) {
        Map<Integer, List<SegementDto>> groupMap = searchReq.getSegements().stream().collect(Collectors.groupingBy(SegementDto::getGroup));
        List<SearchSpecificAirSegment> searchSpecificAirSegments = Lists.newArrayList();
        for (List<SegementDto> segementDtos : groupMap.values()) {
            segementDtos.sort(Comparator.comparing(SegementDto::getSeq));
            for (SegementDto segementDto : segementDtos) {
                SearchSpecificAirSegment searchSpecificAirSegment = new SearchSpecificAirSegment();
                searchSpecificAirSegment.setOrigin(segementDto.getOrigin());
                searchSpecificAirSegment.setDestination(segementDto.getDestination());
                searchSpecificAirSegment.setCarrier(Objects.nonNull(useOperating) && useOperating ? segementDto.getOperatingCarrier() : segementDto.getCarrier());
                searchSpecificAirSegment.setFlightNumber(Objects.nonNull(useOperating) && useOperating ? segementDto.getOperatingFlightNumber() : segementDto.getFlightNumber());
                searchSpecificAirSegment.setDepartureTime(segementDto.getDepartureTime());

                int index = segementDtos.indexOf(segementDto);
                if (index > 0) {
                    Integer segmentIndex = segementDtos.get(index - 1).getSeq();
                    searchSpecificAirSegment.setSegmentIndex(segmentIndex);
                }

                searchSpecificAirSegments.add(searchSpecificAirSegment);
            }
        }

        /*List<SearchSpecificAirSegment> searchSpecificAirSegments = searchReq.getSegements().stream().map(segementDto -> {
            SearchSpecificAirSegment searchSpecificAirSegment = new SearchSpecificAirSegment();
            searchSpecificAirSegment.setOrigin(segementDto.getOrigin());
            searchSpecificAirSegment.setDestination(segementDto.getDestination());
            searchSpecificAirSegment.setCarrier(segementDto.getCarrier());
            searchSpecificAirSegment.setFlightNumber(segementDto.getFlightNumber());
            searchSpecificAirSegment.setDepartureTime(segementDto.getDepartureTime());
            return searchSpecificAirSegment;
        }).collect(Collectors.toList());*/

        AirSearchModifiers.PreferredProviders preferredProviders = buildPreferredProviders();

        AirSearchModifiers airSearchModifiers = new AirSearchModifiers();
        airSearchModifiers.setPreferredProviders(preferredProviders);

        List<SearchPassenger> searchPassengers = buildPassengers(searchReq.getPassengers());

        AvailabilitySearchReq availabilitySearchReq = new AvailabilitySearchReq();
        availabilitySearchReq.getSearchSpecificAirSegment().addAll(searchSpecificAirSegments);
        availabilitySearchReq.setAirSearchModifiers(airSearchModifiers);
        availabilitySearchReq.getSearchPassenger().addAll(searchPassengers);

        AvailabilitySearchReqSoap availabilitySearchReqSoap = AvailabilitySearchReqSoap.build(availabilitySearchReq);
        return XmlUtil.beanToXmlByJAXB(availabilitySearchReqSoap);
    }

    public static String buildAirCreateReservationReqSoap(CreatePnrReq createPnrReq) {
        List<TypeBaseAirSegment> airSegments = createPnrReq.getSegements().stream().map(segementDto -> {
            TypeBaseAirSegment airSegment = new TypeBaseAirSegment();
            airSegment.setKey(segementDto.getSegmentKey());
            airSegment.setProviderCode(segementDto.getProviderCode().getCode());
            airSegment.setGroup(segementDto.getGroup());
            airSegment.setCarrier(segementDto.getCarrier());
            airSegment.setFlightNumber(segementDto.getFlightNumber());
            airSegment.setOrigin(segementDto.getOrigin());
            airSegment.setDestination(segementDto.getDestination());
            airSegment.setDepartureTime(segementDto.getDepartureTime());
            airSegment.setArrivalTime(segementDto.getArrivalTime());
            airSegment.setClassOfService(segementDto.getClassOfService());
            return airSegment;
        }).collect(Collectors.toList());

        AirPricingSolution airPricingSolution = new AirPricingSolution();
        airPricingSolution.setKey(Optional.ofNullable(createPnrReq.getAirPricingSolutionKey()).filter(StringUtils::isNoneBlank).orElse(UUIDUtil.getUUID()));
        airPricingSolution.getAirSegment().addAll(airSegments);


        ActionStatus actionStatus = new ActionStatus();
        actionStatus.setType("ACTIVE");
        actionStatus.setProviderCode(createPnrReq.getSegements().get(0).getProviderCode().getCode());
        actionStatus.setTicketDate("T*");


        ContinuityCheckOverride continuityCheck = new ContinuityCheckOverride();
        continuityCheck.setValue("yes");


        List<String> departureTimes = createPnrReq.getSegements().stream().map(SegementDto::getDepartureTime).collect(Collectors.toList());
        List<BookingTraveler> bookingTravelers = buildBookingTravelers(departureTimes, createPnrReq.getTravelers());


        AgencyContactInfo agencyContactInfo = new AgencyContactInfo();
        /*AgencyContactInfo agencyContactInfo = buildAgencyContactInfo();*/  //todo hqq contactinfo


        AirCreateReservationReq airCreateReservationReq = new AirCreateReservationReq();
        airCreateReservationReq.getBookingTraveler().addAll(bookingTravelers);
        airCreateReservationReq.setContinuityCheckOverride(continuityCheck);
        airCreateReservationReq.getAirPricingSolution().add(airPricingSolution);
        airCreateReservationReq.setAgencyContactInfo(agencyContactInfo);
        airCreateReservationReq.getActionStatus().add(actionStatus);


//        initFormOfPayment(airPricingSolution, airCreateReservationReq, createPnrReq.getCreditCard());


        AirCreateReservationReqSoap airCreateReservationReqSoap = AirCreateReservationReqSoap.build(airCreateReservationReq, createPnrReq.getPcc());
        return XmlUtil.beanToXmlByJAXB(airCreateReservationReqSoap);
    }

    private static AgencyContactInfo buildAgencyContactInfo() {
        PhoneNumber phoneNumber = new PhoneNumber();
        phoneNumber.setNumber("03-62796-2365 AOYAMA-HQQ");

        AgencyContactInfo agencyContactInfo = new AgencyContactInfo();
        agencyContactInfo.getPhoneNumber().add(phoneNumber);

        return agencyContactInfo;
    }

    @Deprecated
    public static String buildAirCreateReservationReqSoapWithPrice(CreatePnrReq createPnrReq) {
        if (StringUtils.isBlank(createPnrReq.getSearchPriceRsp())) {
            throw new InvalidParamException("请先查询最新报价");
        }

        AirPriceRspSoap airPriceRspSoap = XmlUtil.xmlToBeanByJAXB(createPnrReq.getSearchPriceRsp(), AirPriceRspSoap.class);
        List<TypeBaseAirSegment> airSegments = Optional.ofNullable(airPriceRspSoap)
                .map(AirPriceRspSoap::getBody)
                .map(AirPriceRspSoap.SoapBody::getAirPriceRsp)
                .map(AirPriceRsp::getAirItinerary)
                .map(AirItinerary::getAirSegment)
                .orElse(Lists.newArrayList());
        if (CollectionUtil.isEmpty(airSegments)) {
            throw new InvalidParamException("GDS返回的原始报价信息—行程信息为空");
        }

        List<AirPriceResult> airPriceResults = Optional.ofNullable(airPriceRspSoap)
                .map(AirPriceRspSoap::getBody)
                .map(AirPriceRspSoap.SoapBody::getAirPriceRsp)
                .map(AirPriceRsp::getAirPriceResult)
                .orElse(Lists.newArrayList());
        if (CollectionUtil.isEmpty(airPriceResults)) {
            throw new InvalidParamException("GDS返回的原始报价信息—报价信息为空");
        }

        AirPricingSolution airPricingSolution = Optional.ofNullable(airPriceResults.get(0).getAirPricingSolution())
                .flatMap(airPricingSolutions -> airPricingSolutions.stream().min(Comparator.comparingDouble(o -> new BigDecimal(StrUtil.removeChar(o.getApproximateTotalPrice())).doubleValue())))
                .orElse(null);
        if (Objects.isNull(airPricingSolution)) {
            throw new InvalidParamException("GDS返回的原始报价信息—报价信息-报价方案为空");
        }

        Map<String, String> segmentMap = Optional.ofNullable(airPricingSolution.getAirPricingInfo())
                .flatMap(airPricingInfos -> airPricingInfos.stream().findFirst())
                .map(AirPricingInfo::getBookingInfo)
                .map(bookingInfos -> bookingInfos.stream().collect(Collectors.toMap(BookingInfo::getSegmentRef, BookingInfo::getBookingCode, (a, b) -> b)))
                .orElse(new HashMap<>());

        airSegments.forEach(airSegment -> airSegment.setClassOfService(segmentMap.getOrDefault(airSegment.getKey(), airSegment.getClassOfService())));

        airPricingSolution.getAirSegmentRef().clear();
        airPricingSolution.getAirSegment().addAll(initSegmentConnection(airSegments));


        List<String> departureTimes = airSegments.stream().map(TypeBaseAirSegment::getDepartureTime).collect(Collectors.toList());
        List<BookingTraveler> bookingTravelers = buildBookingTravelers(departureTimes, createPnrReq.getTravelers());
        Map<String, List<BookingTraveler>> travelerTypeMap = bookingTravelers.stream().collect(Collectors.groupingBy(bookingTraveler -> bookingTraveler.getTravelerType().toUpperCase()));


        for (AirPricingInfo airPricingInfo : airPricingSolution.getAirPricingInfo()) {
            List<com.ruoyi.gds.schema.galileo.air_v50_0.PassengerType> passengerTypes = airPricingInfo.getPassengerType();
            if (CollectionUtil.isEmpty(passengerTypes)) {
                throw new InvalidParamException("GDS返回的原始报价信息—报价信息-乘机人为空");
            }

            com.ruoyi.gds.schema.galileo.air_v50_0.PassengerType passengerType = passengerTypes.get(0);
            List<BookingTraveler> travelerTypes = travelerTypeMap.get(passengerType.getCode().toUpperCase());
            if (CollectionUtil.isEmpty(travelerTypes)) {
                throw new InvalidParamException("无" + passengerType.getCode() + "类乘机人");
            }
            if (CollectionUtil.isEmpty(travelerTypes)) {
                String errMsg = String.format("%s类乘机人数(%d)与查价时该类人数(%d)不相符", passengerType.getCode(), travelerTypes.size(), passengerTypes.size());
                throw new InvalidParamException(errMsg);
            }

            for (int i = 0; i < passengerTypes.size(); i++) {
                passengerTypes.get(i).setBookingTravelerRef(travelerTypes.get(i).getKey());
            }
        }


        ActionStatus actionStatus = new ActionStatus();
        actionStatus.setType("ACTIVE");
        actionStatus.setProviderCode(createPnrReq.getSegements().get(0).getProviderCode().getCode());
        actionStatus.setTicketDate("T*");


        ContinuityCheckOverride continuityCheck = new ContinuityCheckOverride();
        continuityCheck.setValue("yes");


        AirCreateReservationReq airCreateReservationReq = new AirCreateReservationReq();
        airCreateReservationReq.getBookingTraveler().addAll(bookingTravelers);
        airCreateReservationReq.setContinuityCheckOverride(continuityCheck);
        airCreateReservationReq.getAirPricingSolution().add(airPricingSolution);
        airCreateReservationReq.setAgencyContactInfo(new AgencyContactInfo());
        airCreateReservationReq.getActionStatus().add(actionStatus);


        initFormOfPayment(airPricingSolution, airCreateReservationReq, createPnrReq.getCreditCard());


        AirCreateReservationReqSoap airCreateReservationReqSoap = AirCreateReservationReqSoap.build(airCreateReservationReq, createPnrReq.getPcc());
        return XmlUtil.beanToXmlByJAXB(airCreateReservationReqSoap);
    }

    private static void initFormOfPayment(AirPricingSolution airPricingSolution, AirCreateReservationReq airCreateReservationReq, CreditCardVo creditCard) {
        if (Objects.isNull(airCreateReservationReq) || Objects.isNull(creditCard)) {
            return;
        }

        FormOfPayment formOfPayment = buildFormOfPayment(creditCard);
        if (Objects.isNull(formOfPayment)) {
            return;
        }

        airCreateReservationReq.getFormOfPayment().add(formOfPayment);

        if (Objects.isNull(airPricingSolution) || CollectionUtil.isEmpty(airPricingSolution.getAirPricingInfo())) {
            return;
        }

        List<Payment> payments = airPricingSolution.getAirPricingInfo().stream().map(airPricingInfo -> {
            Payment payment = new Payment();
            payment.setType("Itinerary");
            payment.setFormOfPaymentRef(formOfPayment.getKey());
            payment.setAmount(airPricingInfo.getTotalPrice());
            payment.setApproximateAmount(airPricingInfo.getTotalPrice());
            return payment;
        }).collect(Collectors.toList());
        airCreateReservationReq.getPayment().addAll(payments);

        List<AirPricingInfoRef> airPricingInfoRefs = airPricingSolution.getAirPricingInfo().stream().map(airPricingInfo -> {
            AirPricingInfoRef airPricingInfoRef = new AirPricingInfoRef();
            airPricingInfoRef.setKey(airPricingInfo.getKey());
            return airPricingInfoRef;
        }).collect(Collectors.toList());

        Commission commission = new Commission();
        commission.setLevel(TypeCommissionLevel.FARE);
        commission.setModifier(TypeCommissionModifier.FARE_PERCENT);
        commission.setType(TypeCommissionType.PERCENT_BASE);
        commission.setPercentage("3");

        TicketingModifiers ticketingModifiers = new TicketingModifiers();
        ticketingModifiers.setCommission(commission);

        AirPricingTicketingModifiers airPricingTicketingModifiers = new AirPricingTicketingModifiers();
        airPricingTicketingModifiers.getAirPricingInfoRef().addAll(airPricingInfoRefs);
        /*airPricingTicketingModifiers.setTicketingModifiers(ticketingModifiers);*/
        airCreateReservationReq.getAirPricingTicketingModifiers().add(airPricingTicketingModifiers);
    }

    private static YearMonth getYearMonth(Integer yearMonth) {
        if (Objects.isNull(yearMonth) || yearMonth < 1000) return null;

        try {
            String expStr = String.valueOf(yearMonth);
            String formattedDate = "20" + expStr.substring(0, 2) + "-" + expStr.substring(2);
            return YearMonth.parse(formattedDate);
        } catch (Exception e) {
            throw new InvalidParamException("无效的年月: " + yearMonth);
        }
    }

    private static FormOfPayment buildFormOfPayment(CreditCardVo creditCardVo) {
        LocalDate today = LocalDate.now();
        YearMonth yearMonth = getYearMonth(Optional.ofNullable(creditCardVo).map(CreditCardVo::getExp).orElse(null));
        if (Objects.isNull(creditCardVo)) {
            throw new ServiceException("信用卡信息为空", HttpStatus.BAD_REQUEST);
        }
        if (StringUtils.isBlank(creditCardVo.getNumber())) {
            throw new ServiceException("信用卡号为空", HttpStatus.BAD_REQUEST);
        }
        if (Objects.isNull(yearMonth)) {
            throw new ServiceException("信用卡有效期为空", HttpStatus.BAD_REQUEST);
        }
        if (today.getYear() > yearMonth.getYear()) {
            throw new ServiceException("有效期年份错误", HttpStatus.BAD_REQUEST);
        }

        int expDate = Integer.parseInt(yearMonth.getYear() + String.format("%02d", yearMonth.getMonthValue()));
        int todayMonth = Integer.parseInt(today.format(DateTimeFormatter.ofPattern("yyyyMM")));
        if (expDate < todayMonth) {
            throw new ServiceException("信用卡已过期", HttpStatus.BAD_REQUEST);
        }

        XMLGregorianCalendar xmlGregorianCalendar = new XMLGregorianCalendarImpl();
        xmlGregorianCalendar.setYear(yearMonth.getYear());
        xmlGregorianCalendar.setMonth(yearMonth.getMonthValue());

        CreditCard creditCard = new CreditCard();
        creditCard.setType("VI");
        creditCard.setNumber(creditCardVo.getNumber());
        creditCard.setCVV(creditCardVo.getCvv());
        creditCard.setExpDate(xmlGregorianCalendar);

        FormOfPayment formOfPayment = new FormOfPayment();
        formOfPayment.setKey(UUIDUtil.getUUID());
        formOfPayment.setType("Credit");
        formOfPayment.setCreditCard(creditCard);
        formOfPayment.setReusable(Boolean.FALSE);
        return formOfPayment;
    }

    private static FormOfPayment buildFormOfPaymentWithCash() {
        FormOfPayment formOfPayment = new FormOfPayment();
        formOfPayment.setKey(UUIDUtil.getUUID());
        formOfPayment.setType("Cash");
        formOfPayment.setReusable(Boolean.FALSE);
        return formOfPayment;
    }

    private static List<TypeBaseAirSegment> initSegmentConnection(List<TypeBaseAirSegment> airSegments) {
        Map<Integer, LinkedList<TypeBaseAirSegment>> groupMap = new HashMap<>();
        for (TypeBaseAirSegment airSegment : airSegments) {
            if (Objects.isNull(groupMap.get(airSegment.getGroup()))) {
                groupMap.put(airSegment.getGroup(), new LinkedList<>());
            }
            groupMap.get(airSegment.getGroup()).add(airSegment);
        }

        groupMap.entrySet().stream()
                .sorted(Map.Entry.comparingByKey())
                .forEach(entry -> {
                    LinkedList<TypeBaseAirSegment> segments = entry.getValue();
                    for (TypeBaseAirSegment typeBaseAirSegment : entry.getValue()) {
                        int segmentIndex = segments.indexOf(typeBaseAirSegment);
                        if (segmentIndex < segments.size() - 1) {
                            typeBaseAirSegment.setConnection(new Connection());
                        }
                    }
                });

        return airSegments;
    }

    public static String buildUniversalRecordSearchReq(String pnr) {
        UniversalRecordSearchReq universalRecordSearchReq = new UniversalRecordSearchReq();
        universalRecordSearchReq.setProviderCode(GDSType.GALELIO.getCode());
        universalRecordSearchReq.setProviderLocatorCode(pnr);

        UniversalRecordSearchReqSoap searchReqSoap = UniversalRecordSearchReqSoap.build(universalRecordSearchReq);
        return XmlUtil.beanToXmlByJAXB(searchReqSoap);
    }

    public static String buildUniversalRecordRetrieveReq(String pnr) {
        UniversalRecordRetrieveReq.ProviderReservationInfo providerReservationInfo = new UniversalRecordRetrieveReq.ProviderReservationInfo();
        providerReservationInfo.setProviderCode(GDSType.GALELIO.getCode());
        providerReservationInfo.setProviderLocatorCode(pnr);

        UniversalRecordRetrieveReq universalRecordRetrieveReq = new UniversalRecordRetrieveReq();
        universalRecordRetrieveReq.setProviderReservationInfo(providerReservationInfo);

        UniversalRecordRetrieveReqSoap universalRecordRetrieveReqSoap = UniversalRecordRetrieveReqSoap.build(universalRecordRetrieveReq);
        return XmlUtil.beanToXmlByJAXB(universalRecordRetrieveReqSoap);
    }

    public static AirPricingModifiers buildAirPricingModifiers(SearchPriceReq priceDto) {
        CabinClass economy = new CabinClass();
        economy.setType(CabinCategoryType.ECONOMY.getCode());

        CabinClass premiumEconomy = new CabinClass();
        premiumEconomy.setType(CabinCategoryType.PREMIUM_ECONOMY.getCode());

        CabinClass business = new CabinClass();
        business.setType(CabinCategoryType.BUSINESS.getCode());

        CabinClass first = new CabinClass();
        first.setType(CabinCategoryType.FIRST.getCode());

        PermittedCabins permittedCabins = new PermittedCabins();
        permittedCabins.getCabinClass().add(economy);
        permittedCabins.getCabinClass().add(premiumEconomy);
        permittedCabins.getCabinClass().add(business);
        permittedCabins.getCabinClass().add(first);

        AirPricingModifiers airPricingModifiers = new AirPricingModifiers();
        airPricingModifiers.setPermittedCabins(permittedCabins);

        return airPricingModifiers;
    }

    public static AirSegmentPricingModifiers buildAirSegmentPricingModifiers(SegementDto segementDto, Boolean specifyCabin) {
        AirSegmentPricingModifiers airSegmentPricingModifiers = new AirSegmentPricingModifiers();
        airSegmentPricingModifiers.setAirSegmentRef(segementDto.getSegmentKey());

        if (specifyCabin) {
            List<BookingCode> bookingCodes = Optional.ofNullable(segementDto.getClassOfService())
                    .map(classOfService -> Arrays.stream(classOfService.split(",")))
                    .map(classOfServiceList -> classOfServiceList.map(classOfService -> {
                        BookingCode bookingCode = new BookingCode();
                        bookingCode.setCode(classOfService);
                        return bookingCode;
                    }).collect(Collectors.toList()))
                    .orElse(Lists.newArrayList());
            if (CollectionUtil.isNotEmpty(bookingCodes)) {
                AirSegmentPricingModifiers.PermittedBookingCodes permittedBookingCodes = new AirSegmentPricingModifiers.PermittedBookingCodes();
                permittedBookingCodes.getBookingCode().addAll(bookingCodes);
                airSegmentPricingModifiers.setPermittedBookingCodes(permittedBookingCodes);
                return airSegmentPricingModifiers;
            }
        } else {
            String cabinClass = Optional.ofNullable(segementDto.getCabinType())
                    .map(CabinCategoryType::getCode)
                    .orElse(null);
            if (StringUtils.isNotBlank(cabinClass)) {
                airSegmentPricingModifiers.setCabinClass(cabinClass);
                return airSegmentPricingModifiers;
            }
        }

        return null;
    }

    public static String buildUniversalRecordCancelReqSoap(CancelPnrDto cancelPnrDto) {
        UniversalRecordCancelReq universalRecordCancelReq = new UniversalRecordCancelReq();
        universalRecordCancelReq.setVersion(BigInteger.valueOf(cancelPnrDto.getVersion()));
        universalRecordCancelReq.setUniversalRecordLocatorCode(cancelPnrDto.getLocatorCode());

        UniversalRecordCancelReqSoap universalRecordCancelReqSoap = UniversalRecordCancelReqSoap.build(universalRecordCancelReq);
        return XmlUtil.beanToXmlByJAXB(universalRecordCancelReqSoap);
    }

    private static List<BookingTraveler> buildBookingTravelers(List<String> departureTimes, List<TravelerDto> travelerDtos) {
        List<TravelerDto> adts = travelerDtos.stream().filter(travelerDto -> PassengerType.ADT.equals(travelerDto.getTravelerType())).collect(Collectors.toList());
        List<TravelerDto> infs = travelerDtos.stream().filter(travelerDto -> PassengerType.INF.equals(travelerDto.getTravelerType())).collect(Collectors.toList());
        if ((CollectionUtil.isEmpty(adts) && CollectionUtil.isNotEmpty(infs)) || adts.size() < infs.size()) {
            throw new ServiceException("成人数小于婴儿数", HttpStatus.BAD_REQUEST);
        }

        List<BookingTraveler> bookingTravelers = Optional.ofNullable(travelerDtos)
                .map(travelerDtoList -> travelerDtoList.stream().map(travelerDto -> buildBookingTraveler(departureTimes, travelerDto)).collect(Collectors.toList()))
                .orElse(Collections.emptyList());

        boolean flag = false;
        for (BookingTraveler bookingTraveler : bookingTravelers) {
            if (!flag && CollectionUtil.isNotEmpty(bookingTraveler.getPhoneNumber())) {
                flag = true;
                continue;
            }
            if (flag) bookingTraveler.getPhoneNumber().clear();
        }

        return bookingTravelers;
    }

    private static BookingTraveler buildBookingTraveler(List<String> departureTimes, TravelerDto travelerDto) {
        BookingTravelerName bookingTravelerName = buildBookingTravelerName(travelerDto.getTravelerFirstName(), travelerDto.getTravelerLastName(), travelerDto.getGender(), travelerDto.getBirthDay());
        PhoneNumber phoneNumber = buildPhoneNumber(gdsConfig.getGalileo().getAgencyPhone());
        Email mail = buildEmail(travelerDto.getEmail());
        SSR ctcm = buildSSRForCTCM(travelerDto.getPhone());
        SSR ctce = buildSSRForCTCE(travelerDto.getEmail());
        SSR foid = buildSSRForFOID(travelerDto.getCertificate());
        SSR docs = buildSSRForDOCS(travelerDto);
        Integer ageNum = Objects.nonNull(travelerDto.getBirthDay()) ? Period.between(travelerDto.getBirthDay(), LocalDate.now()).getYears() : null;

        BookingTraveler bookingTraveler = new BookingTraveler();
        bookingTraveler.setKey(travelerDto.getTravelerType().getCode() + travelerDto.getSeq());
        bookingTraveler.setGender(travelerDto.getGender().getGalelioCode());
        bookingTraveler.setTravelerType(travelerDto.getTravelerType().getCode());
        bookingTraveler.setBookingTravelerName(bookingTravelerName);
        bookingTraveler.setDOB(buildBirthDay(travelerDto.getBirthDay()));
        bookingTraveler.getSSR().add(docs);
        if (Objects.nonNull(ageNum)) bookingTraveler.setAge(BigInteger.valueOf(ageNum));
        if (Objects.nonNull(phoneNumber)) bookingTraveler.getPhoneNumber().add(phoneNumber);
        /*if (Objects.nonNull(mail)) bookingTraveler.getEmail().add(mail);*/
        if (Objects.nonNull(ctcm)) bookingTraveler.getSSR().add(ctcm);
        if (Objects.nonNull(ctce)) bookingTraveler.getSSR().add(ctce);
        /*if (Objects.nonNull(foid)) bookingTraveler.getSSR().add(foid);*/

        if (PassengerType.CNN.equals(travelerDto.getTravelerType())) {
            NameRemark nameRemark = buildNameRemark(departureTimes, travelerDto);
            bookingTraveler.getNameRemark().add(nameRemark);
        }


        return bookingTraveler;
    }

    private static NameRemark buildNameRemark(List<String> departureTimes, TravelerDto travelerDto) {
        int departureDateaAge = 0;
        for (String departureTime : departureTimes) {
            String departureDateStr = DateUtil.dateTimeFormat(departureTime, DatePattern.NORM_DATE_PATTERN);
            LocalDate departureDate = LocalDate.parse(departureDateStr, DateTimeFormatter.ofPattern(DatePattern.NORM_DATE_PATTERN));
            // 计算登记年龄
            departureDateaAge = Period.between(travelerDto.getBirthDay(), departureDate).getYears();
            if (PassengerType.CNN == travelerDto.getTravelerType() && departureDateaAge >= 12) {
                throw new ServiceException("部分航段儿童登机年龄已满12岁，请手动预定", HttpStatus.BAD_REQUEST);
            }
            if (PassengerType.INF == travelerDto.getTravelerType() && departureDateaAge >= 2) {
                throw new ServiceException("部分航段婴儿登机年龄已满2岁，请手动预定", HttpStatus.BAD_REQUEST);
            }
        }

        NameRemark nameRemark = new NameRemark();
        nameRemark.setKey(travelerDto.getTravelerType().getCode() + travelerDto.getSeq());
        if (PassengerType.CNN == travelerDto.getTravelerType()) {
            nameRemark.setRemarkData(String.format("P-C%s DOB%s", String.format("%02d", departureDateaAge), DateUtil.formatUSDate(travelerDto.getBirthDay())).toUpperCase(Locale.ROOT));
        }
        if (PassengerType.INF == travelerDto.getTravelerType()) {
            nameRemark.setRemarkData(String.format("P-C%s", String.format("%02d", departureDateaAge)).toUpperCase(Locale.ROOT));
        }

        return nameRemark;
    }

    private static List<SearchPassenger> buildPassengers(List<PassengerType> passengers) {
        List<SearchPassenger> searchPassengers = new ArrayList<>();
        for (int i = 0; i < passengers.size(); i++) {
            PassengerType passengerType = passengers.get(i);
            Integer age = null;
            if (PassengerType.CNN == passengerType) {
                age = CommonConstant.CNN_AGE;
            }
            if (PassengerType.INF == passengerType) {
                age = CommonConstant.INF_AGE;
            }
            SearchPassenger searchPassenger = buildPassenger(passengerType.getCode() + (i + 1), passengerType.getCode(), age);
            searchPassengers.add(searchPassenger);
        }
        return searchPassengers;
    }

    private static SearchPassenger buildPassenger(String key, String code, Integer age) {
        SearchPassenger searchPassenger = new SearchPassenger();
        searchPassenger.setKey(key);
        searchPassenger.setCode(code);
        if (Objects.nonNull(age)) searchPassenger.setAge(BigInteger.valueOf(age));

        return searchPassenger;
    }

    private static BookingTravelerName buildBookingTravelerName(String firstName, String lastName, GenderType gender, LocalDate birthDay) {
        String prefix = getNameSufix(gender, birthDay);
        BookingTravelerName bookingTravelerName = new BookingTravelerName();
        if (StringUtils.isNotBlank(firstName)) {
            bookingTravelerName.setPrefix(prefix);
            bookingTravelerName.setFirst(lastName);
            bookingTravelerName.setLast(firstName);
        } else {
            bookingTravelerName.setFirst(prefix);
            bookingTravelerName.setLast(lastName);
        }
        return bookingTravelerName;
    }

    private static String getNameSufix(GenderType gender, LocalDate birthDay) {
        String prefix;
        int age = Objects.nonNull(birthDay) ? Period.between(birthDay, LocalDate.now()).getYears() : 0;
        switch (gender) {
            case M:
                if (age >= 12) {
                    prefix = CommonConstant.GENDER_PREFIX_MR;
                } else {
                    prefix = CommonConstant.GENDER_PREFIX_MSTR;
                }
                break;
            case F:
                if (age >= 12) {
                    prefix = CommonConstant.GENDER_PREFIX_MS;
                } else {
                    prefix = CommonConstant.GENDER_PREFIX_MISS;
                }
                break;
            default:
                prefix = "";
                break;
        }

        return prefix;
    }

    private static PhoneNumber buildPhoneNumber(String number) {
        if (StringUtils.isBlank(number)) return null;

        PhoneNumber phoneNumber = new PhoneNumber();
        phoneNumber.setNumber(number);
        return phoneNumber;
    }

    private static Email buildEmail(String email) {
        if (StringUtils.isBlank(email)) return null;

        Email mail = new Email();
        mail.setEmailID(email);
        return mail;
    }

    private static SSR buildSSRForCTCM(String mobile) {
        if (StringUtils.isBlank(mobile)) return null;

        PhoneMatch macth = PhoneMatch.macth(mobile);
        if (Objects.isNull(macth)) throw new InvalidParamException("仅支持中国大陆和日本手机号");

        SSR ssr = new SSR();
        ssr.setType(GalileoConstant.EMERGENCY_TYPE_PHONE);
        ssr.setFreeText(macth.getPrefix() + macth.replace(mobile) + "/" + macth.getNationality());
        return ssr;
    }

    private static SSR buildSSRForCTCE(String email) {
        if (StringUtils.isBlank(email)) return null;

        SSR ssr = new SSR();
        ssr.setType(GalileoConstant.EMERGENCY_TYPE_EMAIL);
        ssr.setFreeText(email);
        return ssr;
    }

    private static SSR buildSSRForFOID(String certificate) {
        if (StringUtils.isBlank(certificate)) return null;

        SSR ssr = new SSR();
        ssr.setType(GalileoConstant.EMERGENCY_SSR_FOID);
        ssr.setFreeText(certificate);
        return ssr;
    }

    private static SSR buildSSRForDOCS(TravelerDto travelerDto) {
        String prefix = getNameSufix(travelerDto.getGender(), travelerDto.getBirthDay());
        String freeRext = new StringBuilder()
                .append(travelerDto.getCertificateType().name()).append("/")
                .append(travelerDto.getCertificateCountry()).append("/")
                .append(travelerDto.getCertificate()).append("/")
                .append(travelerDto.getCertificateOwnerCountry()).append("/")
                .append(DateUtil.formatUSDate(travelerDto.getBirthDay())).append("/")
                .append(travelerDto.getGender().getGalelioCode()).append("/")
                .append(DateUtil.formatUSDate(travelerDto.getExpireDate())).append("/")
                .append(StringUtils.isNotBlank(travelerDto.getTravelerFirstName()) ? travelerDto.getTravelerFirstName() : travelerDto.getTravelerLastName()).append("/")
                .append(StringUtils.isNotBlank(travelerDto.getTravelerFirstName()) ? travelerDto.getTravelerLastName() : prefix)
                .toString().toUpperCase(Locale.ROOT);
        SSR ssr = new SSR();
        ssr.setType(GalileoConstant.EMERGENCY_SSR_DOCS);
        ssr.setFreeText(freeRext);
        // ssr.setCarrier("YY");  // 所有航司通用
        return ssr;
    }

    private static XMLGregorianCalendarImpl buildBirthDay(LocalDate birthDay) {
        if (Objects.isNull(birthDay)) return null;

        XMLGregorianCalendarImpl xmlGregorianCalendar = new XMLGregorianCalendarImpl();
        xmlGregorianCalendar.setYear(birthDay.getYear());
        xmlGregorianCalendar.setMonth(birthDay.getMonthValue());
        xmlGregorianCalendar.setDay(birthDay.getDayOfMonth());
        return xmlGregorianCalendar;
    }

    private static List<Carrier> buildCarriers(List<String> carrierCodes) {
        if (CollectionUtil.isEmpty(carrierCodes)) return Collections.emptyList();

        return carrierCodes.stream().map(carrierCode -> {
            Carrier carrier = new Carrier();
            carrier.setCode(carrierCode);
            return carrier;
        }).collect(Collectors.toList());
    }

    private static List<CabinClass> buildCabins(List<CabinCategoryType> cabins) {
        if (CollectionUtil.isEmpty(cabins)) return Collections.emptyList();

        return cabins.stream().map(cabin -> {
            CabinClass cabinClass = new CabinClass();
            cabinClass.setType(cabin.getCode());
            return cabinClass;
        }).collect(Collectors.toList());
    }

    private static TypeSearchLocation buildCity(String cityCode) {
        if (StringUtils.isBlank(cityCode)) return null;

        City city = new City();
        city.setCode(cityCode);

        TypeSearchLocation location = new TypeSearchLocation();
        location.setCity(city);
        return location;
    }

    private static TypeSearchLocation buildAirport(String airportCode) {
        if (StringUtils.isBlank(airportCode)) return null;

        Airport airport = new Airport();
        airport.setCode(airportCode);

        TypeSearchLocation location = new TypeSearchLocation();
        location.setAirport(airport);
        return location;
    }

    private static TypeSearchLocation buildCityOrAirport(String airportCode, Boolean preferCity) {
        if (StringUtils.isBlank(airportCode)) return null;

        CityOrAirport cityOrAirport = new CityOrAirport();
        cityOrAirport.setCode(airportCode);
        cityOrAirport.setPreferCity(preferCity);

        TypeSearchLocation location = new TypeSearchLocation();
        location.setCityOrAirport(cityOrAirport);
        return location;
    }

    private static List<SearchAirLeg> buildSearchAirLegs(List<FlightDto> flightDtos) {
        List<SearchAirLeg> searchAirLegs = new ArrayList<>();
        LocalDate today = LocalDate.now();
        for (FlightDto flightDto : flightDtos) {
            if (Objects.isNull(flightDto.getDeptDate())) throw new RuntimeException("未指定出发日期");
            if (flightDto.getDeptDate().isBefore(today)) throw new RuntimeException("出发日期早于今天");

            TypeSearchLocation from;
            if (StringUtils.isNotBlank(flightDto.getFromAirportCode())) {
                if (Objects.nonNull(flightDto.getPreferCity()) && flightDto.getPreferCity()) {
                    from = buildCityOrAirport(flightDto.getFromAirportCode(), flightDto.getPreferCity());
                } else {
                    from = buildAirport(flightDto.getFromAirportCode());
                }
            } else {
                if (StringUtils.isNotBlank(flightDto.getFromCityCode())) {
                    from = buildCity(flightDto.getFromCityCode());
                } else {
                    throw new RuntimeException("未指定出发城市或机场");
                }
            }

            TypeSearchLocation to;
            if (StringUtils.isNotBlank(flightDto.getToAirportCode())) {
                if (Objects.nonNull(flightDto.getPreferCity()) && flightDto.getPreferCity()) {
                    to = buildCityOrAirport(flightDto.getToAirportCode(), flightDto.getPreferCity());
                } else {
                    to = buildAirport(flightDto.getToAirportCode());
                }
            } else {
                if (StringUtils.isNotBlank(flightDto.getToCityCode())) {
                    to = buildCity(flightDto.getToCityCode());
                } else {
                    throw new RuntimeException("未指定到达城市或机场");
                }
            }

            TypeFlexibleTimeSpec deptTime = new TypeFlexibleTimeSpec();
            String depDate = flightDto.getDeptDate().format(DateTimeFormatter.ofPattern(DatePattern.NORM_DATE_PATTERN));
            if (Objects.nonNull(flightDto.getDepSpecificTime())) {
                TypeSpecificTime typeSpecificTime = new TypeSpecificTime();
                typeSpecificTime.setTime(flightDto.getDepSpecificTime().format(DateTimeFormatter.ofPattern(CommonConstant.DATETIME_PATTERN_WITH_T)));
                deptTime.setSpecificTime(typeSpecificTime);
            } else if (Objects.isNull(flightDto.getDepAfterTime()) || Objects.isNull(flightDto.getDepBeforeTime())) {
                deptTime.setPreferredTime(depDate);
            } else {
                TypeTimeRange typeTimeRange = new TypeTimeRange();
                typeTimeRange.setEarliestTime(flightDto.getDepAfterTime().format(DateTimeFormatter.ofPattern(CommonConstant.DATETIME_PATTERN_WITH_T)));
                typeTimeRange.setLatestTime(flightDto.getDepBeforeTime().format(DateTimeFormatter.ofPattern(CommonConstant.DATETIME_PATTERN_WITH_T)));
                deptTime.setTimeRange(typeTimeRange);
            }

            if (Objects.nonNull(flightDto.getFlexBefore()) || Objects.nonNull(flightDto.getFlexAfter())) {
                TypeFlexibleTimeSpec.SearchExtraDays searchExtraDays = new TypeFlexibleTimeSpec.SearchExtraDays();
                if (Objects.nonNull(flightDto.getFlexBefore())) {
                    searchExtraDays.setDaysBefore(flightDto.getFlexBefore());
                }
                if (Objects.nonNull(flightDto.getFlexAfter())) {
                    searchExtraDays.setDaysAfter(flightDto.getFlexAfter());
                }
                deptTime.setSearchExtraDays(searchExtraDays);
            }

            TypeFlexibleTimeSpec arrTime = new TypeFlexibleTimeSpec();
            if (Objects.nonNull(flightDto.getArrSpecificTime())) {
                TypeSpecificTime typeSpecificTime = new TypeSpecificTime();
                typeSpecificTime.setTime(flightDto.getArrSpecificTime().format(DateTimeFormatter.ofPattern(CommonConstant.DATETIME_PATTERN_WITH_T)));
                arrTime.setSpecificTime(typeSpecificTime);
            } else if (Objects.nonNull(flightDto.getArrAfterTime()) && Objects.nonNull(flightDto.getArrBeforeTime())) {
                TypeTimeRange typeTimeRange = new TypeTimeRange();
                typeTimeRange.setEarliestTime(flightDto.getArrAfterTime().format(DateTimeFormatter.ofPattern(CommonConstant.DATETIME_PATTERN_WITH_T)));
                typeTimeRange.setLatestTime(flightDto.getArrBeforeTime().format(DateTimeFormatter.ofPattern(CommonConstant.DATETIME_PATTERN_WITH_T)));
                arrTime.setTimeRange(typeTimeRange);
            } else if (Objects.nonNull(flightDto.getArrAfterTime())) {
                arrTime.setPreferredTime(flightDto.getArrAfterTime().format(DateTimeFormatter.ofPattern(CommonConstant.DATETIME_PATTERN_WITH_T)));
            } else if (Objects.nonNull(flightDto.getArrBeforeTime())) {
                arrTime.setPreferredTime(flightDto.getArrBeforeTime().format(DateTimeFormatter.ofPattern(CommonConstant.DATETIME_PATTERN_WITH_T)));
            } else {
                arrTime = null;
            }

            // 设置中转点
            AirLegModifiers airLegModifiers = getAirLegModifiers(flightDto);

            SearchAirLeg searchAirLeg = new SearchAirLeg();
            searchAirLeg.getSearchOrigin().add(from);
            searchAirLeg.getSearchDestination().add(to);
            searchAirLeg.getSearchDepTime().add(deptTime);
            searchAirLeg.getSearchArvTime().add(arrTime);
            searchAirLeg.setAirLegModifiers(airLegModifiers);
            searchAirLegs.add(searchAirLeg);
        }

        return searchAirLegs;
    }

    private static AirLegModifiers getAirLegModifiers(FlightDto flightDto) {
        AirLegModifiers airLegModifiers = new AirLegModifiers();
        if (!(StringUtils.isBlank(flightDto.getTransferAirportCode()) && StringUtils.isBlank(flightDto.getTransferCityCode()))) {
            TypeLocation typeLocation = new TypeLocation();
            if (StringUtils.isNotBlank(flightDto.getTransferAirportCode())) {
                if (Objects.nonNull(flightDto.getPreferCity()) && flightDto.getPreferCity()) {
                    CityOrAirport cityOrAirport = new CityOrAirport();
                    cityOrAirport.setCode(flightDto.getTransferAirportCode());
                    cityOrAirport.setPreferCity(flightDto.getPreferCity());
                    typeLocation.setCityOrAirport(cityOrAirport);
                } else {
                    Airport airport = new Airport();
                    airport.setCode(flightDto.getTransferAirportCode());
                    typeLocation.setAirport(airport);
                }
            } else {
                City city = new City();
                city.setCode(flightDto.getTransferCityCode());
                typeLocation.setCity(city);
            }

            AirLegModifiers.PermittedConnectionPoints permittedConnectionPoints = new AirLegModifiers.PermittedConnectionPoints();
            permittedConnectionPoints.getConnectionPoint().add(typeLocation);

            airLegModifiers.setPermittedConnectionPoints(permittedConnectionPoints);
        }

        if (StringUtils.isNotBlank(flightDto.getBookingCode())) {
            BookingCode bookingCode = new BookingCode();
            bookingCode.setCode(flightDto.getBookingCode());

            AirLegModifiers.PermittedBookingCodes permittedBookingCodes = new AirLegModifiers.PermittedBookingCodes();
            permittedBookingCodes.getBookingCode().add(bookingCode);

            airLegModifiers.setPermittedBookingCodes(permittedBookingCodes);
        }

        // 航司
        List<Carrier> carriers = buildCarriers(flightDto.getCarriers());

        // 舱位等级
        List<CabinClass> cabins = buildCabins(flightDto.getCabins());

        // Permitted 只返回特定航空公司的航班 (max 99)
        // Preferred 不仅返回特定航空公司的航班，也可能根据最佳价格返回其他航司的航班(max 99)
        // Prohibited 排除特定航空公司的航班(max 99)
        // 注意：同一个请求中，只能使用三个modifiers中的一个
        if (CollectionUtil.isNotEmpty(carriers)) {
            switch (flightDto.getCarriersType()) {
                case PERMITTED:
                    PermittedCarriers permittedCarriers = new PermittedCarriers();
                    permittedCarriers.getCarrier().addAll(carriers);
                    airLegModifiers.setPermittedCarriers(permittedCarriers);
                    break;
                case PREFERRED:
                    PreferredCarriers preferredCarriers = new PreferredCarriers();
                    preferredCarriers.getCarrier().addAll(carriers);
                    airLegModifiers.setPreferredCarriers(preferredCarriers);
                    break;
                case PROHIBITED:
                    ProhibitedCarriers prohibitedCarriers = new ProhibitedCarriers();
                    prohibitedCarriers.getCarrier().addAll(carriers);
                    airLegModifiers.setProhibitedCarriers(prohibitedCarriers);
                    break;
                default:
                    throw new InvalidParamException("航司搜索方式错误");
            }
        }

        // Permitted:只返回特定舱位等级
        // Preferred:不仅返回特定舱位等级，也可能根据最佳价格返回其他舱位等级
        if (CollectionUtil.isNotEmpty(cabins)) {
            switch (flightDto.getCabinsType()) {
                case PERMITTED:
                    PermittedCabins permittedCabins = new PermittedCabins();
                    permittedCabins.getCabinClass().addAll(cabins);
                    airLegModifiers.setPermittedCabins(permittedCabins);
                    break;
                case PREFERRED:
                    PreferredCabins preferredCabins = new PreferredCabins();
                    preferredCabins.setCabinClass(cabins.get(0));
                    airLegModifiers.setPreferredCabins(preferredCabins);
                    break;
                default:
                    throw new InvalidParamException("舱位等级搜索方式错误");
            }
        }

        if (Objects.nonNull(flightDto.getTransfer())) {
            airLegModifiers.setPreferNonStop(!flightDto.getTransfer());
        }

        return airLegModifiers;
    }

    private static AirPricingModifiers buildAirPricingModifiers() {
        /*AccountCode accountCode = new AccountCode();
        accountCode.setCode("38CT");
        AccountCode accountCode2 = new AccountCode();
        accountCode2.setCode("82HG");
        AirPricingModifiers.AccountCodes accountCodes = new AirPricingModifiers.AccountCodes();
        accountCodes.getAccountCode().add(accountCode);
        accountCodes.getAccountCode().add(accountCode2);*/

        AirPricingModifiers airPricingModifiers = new AirPricingModifiers();
        airPricingModifiers.setETicketability(TypeEticketability.REQUIRED);
        airPricingModifiers.setFaresIndicator(TypeFaresIndicator.ALL_FARES);
        airPricingModifiers.setAccountCodeFaresOnly(false);
        /*airPricingModifiers.setAccountCodes(accountCodes);*/

        return airPricingModifiers;
    }

    private static AirSearchModifiers buildAirSearchModifiers(SearchFlightDto searchFlightDto) {
        // 航线类型
        FlightType flightType = new FlightType();
        flightType.setTripleInterlineCon(searchFlightDto.getTripleInterlineCon());
        flightType.setDoubleInterlineCon(searchFlightDto.getDoubleInterlineCon());
        flightType.setSingleInterlineCon(searchFlightDto.getSingleInterlineCon());
        flightType.setTripleOnlineCon(searchFlightDto.getTripleOnlineCon());
        flightType.setDoubleOnlineCon(searchFlightDto.getDoubleOnlineCon());
        flightType.setSingleOnlineCon(searchFlightDto.getSingleOnlineCon());
        flightType.setStopDirects(searchFlightDto.getStopDirects());
        flightType.setNonStopDirects(searchFlightDto.getNonStopDirects());

        // 航司
        List<Carrier> carriers = buildCarriers(searchFlightDto.getCarriers());

        // 舱位等级
        List<CabinClass> cabins = buildCabins(searchFlightDto.getCabins());

        AirSearchModifiers.PreferredProviders preferredProviders = buildPreferredProviders();

        AirSearchModifiers airSearchModifiers = new AirSearchModifiers();
        airSearchModifiers.setPreferredProviders(preferredProviders);
        airSearchModifiers.setFlightType(flightType);
        airSearchModifiers.setMaxSolutions(BigInteger.valueOf(searchFlightDto.getMaxResponse()));

        // Permitted 只返回特定航空公司的航班 (max 99)
        // Preferred 不仅返回特定航空公司的航班，也可能根据最佳价格返回其他航司的航班(max 99)
        // Prohibited 排除特定航空公司的航班(max 99)
        // 注意：同一个请求中，只能使用三个modifiers中的一个
        if (CollectionUtil.isNotEmpty(carriers)) {
            switch (searchFlightDto.getCarriersType()) {
                case PERMITTED:
                    PermittedCarriers permittedCarriers = new PermittedCarriers();
                    permittedCarriers.getCarrier().addAll(carriers);
                    airSearchModifiers.setPermittedCarriers(permittedCarriers);
                    break;
                case PREFERRED:
                    PreferredCarriers preferredCarriers = new PreferredCarriers();
                    preferredCarriers.getCarrier().addAll(carriers);
                    airSearchModifiers.setPreferredCarriers(preferredCarriers);
                    break;
                case PROHIBITED:
                    ProhibitedCarriers prohibitedCarriers = new ProhibitedCarriers();
                    prohibitedCarriers.getCarrier().addAll(carriers);
                    airSearchModifiers.setProhibitedCarriers(prohibitedCarriers);
                    break;
                default:
                    throw new InvalidParamException("航司搜索方式错误");
            }
        }

        // Permitted:只返回特定舱位等级
        // Preferred:不仅返回特定舱位等级，也可能根据最佳价格返回其他舱位等级
        if (CollectionUtil.isNotEmpty(cabins)) {
            switch (searchFlightDto.getCabinsType()) {
                case PERMITTED:
                    PermittedCabins permittedCabins = new PermittedCabins();
                    permittedCabins.getCabinClass().addAll(cabins);
                    airSearchModifiers.setPermittedCabins(permittedCabins);
                    break;
                case PREFERRED:
                    PreferredCabins preferredCabins = new PreferredCabins();
                    preferredCabins.setCabinClass(cabins.get(0));
                    airSearchModifiers.setPreferredCabins(preferredCabins);
                    break;
                default:
                    throw new InvalidParamException("舱位等级搜索方式错误");
            }
        }

        return airSearchModifiers;
    }

    private static AirSearchModifiers.PreferredProviders buildPreferredProviders() {
        Provider provider = new Provider();
        provider.setCode(GDSType.GALELIO.getCode());

        AirSearchModifiers.PreferredProviders preferredProviders = new AirSearchModifiers.PreferredProviders();
        preferredProviders.getProvider().add(provider);

        return preferredProviders;
    }

}
