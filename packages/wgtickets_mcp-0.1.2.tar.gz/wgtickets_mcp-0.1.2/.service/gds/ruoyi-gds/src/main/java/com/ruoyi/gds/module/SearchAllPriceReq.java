package com.ruoyi.gds.module;

import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.enums.PassengerType;
import com.ruoyi.gds.module.dto.FlightNumberCabinDto;
import com.ruoyi.gds.module.dto.FlightNumberPassengerBaggageDto;
import com.ruoyi.gds.module.dto.PassengerBaggageDto;
import com.ruoyi.gds.module.dto.galileo.SegementDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.assertj.core.util.Lists;

import javax.validation.Valid;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchAllPriceReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * GDS类型
     */
    private GDSType providerCode;

    /**
     * 预约号
     */
    private String pnr;

    /**
     * 航班信息
     */
    private List<SegementDto> segements;

    /**
     * 乘客信息
     */
    private List<PassengerType> passengers;

    /**
     * 指定航班舱位号
     */
    private List<@Valid FlightNumberCabinDto> cabins;

    /**
     * 指定各类乘机人行李额
     */
    private List<@Valid PassengerBaggageDto> passengerBaggages;

    /**
     * 乘机人各航段行李额
     */
    private List<@Valid FlightNumberPassengerBaggageDto> flightNumberPassengerBaggages;


    public List<SegementDto> getSegements() {
        return Optional.ofNullable(segements)
                .map(segementDtos -> segementDtos.stream().peek(segementDto -> {
                    segementDto.setSeq(segements.indexOf(segementDto) + 1);
                    segementDto.setProviderCode(providerCode);
                }).collect(Collectors.toList()))
                .orElse(Lists.newArrayList());
    }

}
