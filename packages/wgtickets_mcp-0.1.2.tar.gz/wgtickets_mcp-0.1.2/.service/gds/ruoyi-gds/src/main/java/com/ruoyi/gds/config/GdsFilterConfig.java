package com.ruoyi.gds.config;

import com.ruoyi.gds.http.filter.GzipDecompressFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GdsFilterConfig {

    @Bean
    public FilterRegistrationBean<GzipDecompressFilter> gzipDecompressFilter() {
        FilterRegistrationBean<GzipDecompressFilter> registration = new FilterRegistrationBean<>();

        registration.setFilter(new GzipDecompressFilter());
        registration.addUrlPatterns("/air/ibe/forward");
        registration.addUrlPatterns("/air/ibe/forward/am");
        registration.addUrlPatterns("/air/ibe/forward/eightYi");
        registration.addUrlPatterns("/air/ibe/forward/huanYu");
        registration.addUrlPatterns("/air/ibe/forward/xiecheng");
        registration.addUrlPatterns("/air/ibe/forward/feizhu");
        registration.setOrder(1);

        return registration;
    }

}
