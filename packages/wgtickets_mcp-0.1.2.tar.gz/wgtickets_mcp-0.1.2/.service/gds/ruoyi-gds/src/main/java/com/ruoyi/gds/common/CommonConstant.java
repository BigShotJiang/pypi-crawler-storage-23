package com.ruoyi.gds.common;

public class CommonConstant {

    public static final String ENV_DEV = "dev";

    public static final Integer FOREST_HTTP_CODE_CONNECT_TIME_OUT = -1;
    public static final String FOREST_HEADER_BUSINESS_TYPE = "BUSINESS_TYPE";
    public static final String FOREST_HEADER_BUSINESS_CODE = "BUSINESS_CODE";

    public static final String HEADER_USER_ID = "Userid";
    public static final String HEADER_BUSINESS_SCENE = "business_scene";
    public static final String HEADER_BUSINESS_ID = "business_id";

    // 人员性别前缀（称谓）—— 男士
    public static final String GENDER_PREFIX_MR = "MR";

    // 人员性别前缀（称谓）—— 男童
    public static final String GENDER_PREFIX_MSTR = "MSTR";

    // 人员性别前缀（称谓）—— 女士
    public static final String GENDER_PREFIX_MS = "MS";

    // 人员性别前缀（称谓）—— 女童
    public static final String GENDER_PREFIX_MISS = "MISS";

    // 去除姓名后缀
    public static final String REMOVE_NAME_SUFIX_REGEX = "\\s*" + GENDER_PREFIX_MR + "$|\\s*" + GENDER_PREFIX_MS + "$|\\s*" + GENDER_PREFIX_MSTR + "$|\\s*" + GENDER_PREFIX_MISS + "$";

    // 信用卡开卡默认金额倍率
    public static final double CREDIT_CARD_AMOUNT_MULTIPLIER = 1.2;
    // 信用卡开卡默认模式
    public static final String CREDIT_CARD_MODE_DEFAUL = "free";
    // 信用卡开卡默认发卡商
    public static final String CREDIT_CARD_SERVER_DEFAUL = "AWE";
    // 信用卡开卡默认持卡人
    public static final String CREDIT_CARD_OWNER_DEFAUL = "abc";

    public static final Integer INF_AGE = 1;

    public static final Integer CNN_AGE = 6;

    public static final String BAGGAGE_WEIGHT_UNIT_KG = "Kg";

    // 婴儿年龄不得超过2岁
    public static final Integer INF_AGE_LESS_THAN = 2;

    // 儿童年龄不得超过12岁
    public static final Integer CNN_AGE_LESS_THAN = 12;

    // 数据字典key
    public static final String CREATE_PNR_ERROR_MSG = "create_pnr_error_msg";

    // 系统参数key——扫舱是否使用mock数据
    public static final String CABIN_SCAN_USE_MOCK = "cabin_scan_use_mock";

    // 表示无可售舱位
    public static final String CABIN_NOT_QUANTITY_CODE = "L";

    // PNR报文中标识PNR有效期的特殊字符
    public static final String PNR_EXPIRE_TIME_LABEL = "ADTK";

    // PNR报文中标识证件信息的特殊字符
    public static final String SSR_DOCS = "DOCS";

    // 时间格式化格式
    public static final String DATETIME_PATTERN_WITH_T = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String DATE_TIME_PATTERN_WITH_TIMEZONE = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX";

    // PNR成功标识字符(占座成功标识)
    public static final String PNR_SUCCESS_CHAR = "K";

    // PNR成功标识字符(可出票的航段状态)
    public static final String PNR_SEGMENT_STATUS_HK = "HK";

    // PNR警告信息模板(占座失败警告信息)
    public static final String PNR_FAILURE_WARNING = "警告：占座失败，请在预约列表检查预约状态。始发地：%s，目的地：%s，航司：%s，航班号：%s，舱位：%s；";

    // 搜索行程参数顶级ID
    public static final Long FLIGHT_SEARCH_PARAM_PARENT_ID_ROOT = 0L;

    // 创建PNR前的校验——乘机人数
    public static final Integer CREATE_PNR_CHECK_MAX_TRAVLER = 5;

    // 创建PNR前的校验——航段数
    public static final Integer CREATE_PNR_CHECK_MAX_SEGMENT = 5;

    // 创建PNR前的校验——取消相同航段次数
    public static final Integer CREATE_PNR_CHECK_CREATED_CANCELLED_SAME_SEGMENT_TIMES = 2;

    // 国家代码——日本
    public static final String COUNTRY_CODE_JP = "JP";

    // 搜索GDS行程返回的报价时间基于当前时间前推30分钟(即表示为30分钟前的报价)
    public static final Integer GDS_SOLUTION_FARE_TIME_BEFORE = 30;

    // 生效中的政策本地缓存Key
    public static final String RELEASE_POLICY_LOCALCACHE_EFFECTIVE_KEY = "release_policy:effective:%s";

}
