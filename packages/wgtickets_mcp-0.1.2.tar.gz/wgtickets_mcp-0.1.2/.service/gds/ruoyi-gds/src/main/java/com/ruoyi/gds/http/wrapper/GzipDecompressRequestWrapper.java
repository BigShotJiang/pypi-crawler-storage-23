package com.ruoyi.gds.http.wrapper;

import javax.servlet.ReadListener;
import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.zip.GZIPInputStream;

public class GzipDecompressRequestWrapper extends HttpServletRequestWrapper {

    private byte[] decompressedBytes = null; // 缓存解压后的数据

    public GzipDecompressRequestWrapper(HttpServletRequest request) throws IOException {
        super(request);
        // 检查 Content-Encoding 头部
        String contentEncoding = request.getHeader("Content-Encoding");
        if (contentEncoding != null && contentEncoding.toLowerCase().contains("gzip")) {
            // 如果是 gzip，则进行解压缩
            try (InputStream originalInputStream = request.getInputStream();
                 GZIPInputStream gzipInputStream = new GZIPInputStream(originalInputStream);
                 ByteArrayOutputStream decompressedOutput = new ByteArrayOutputStream()) {

                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = gzipInputStream.read(buffer)) != -1) {
                    decompressedOutput.write(buffer, 0, bytesRead);
                }
                this.decompressedBytes = decompressedOutput.toByteArray();
                // System.out.println("Request body successfully decompressed from GZIP. Original size: ?, Decompressed size: " + this.decompressedBytes.length); // Optional: Log sizes
            } catch (IOException e) {
                // 可以在这里记录错误或抛出异常，通常代表请求体数据有问题
                System.err.println("Failed to decompress GZIP request body: " + e.getMessage());
                throw new IOException("Failed to decompress GZIP request body", e);
            }
        } else {
            // 如果不是 gzip，则直接读取原始数据并缓存，以便getInputStream()可以多次调用 (Servlet Spec allows reading once, but caching makes wrapper robust)
            try (InputStream originalInputStream = request.getInputStream();
                 ByteArrayOutputStream originalOutput = new ByteArrayOutputStream()) {

                byte[] buffer = new byte[4096];
                int bytesRead;
                while ((bytesRead = originalInputStream.read(buffer)) != -1) {
                    originalOutput.write(buffer, 0, bytesRead);
                }
                this.decompressedBytes = originalOutput.toByteArray();
                // System.out.println("Request body read and cached. Size: " + this.decompressedBytes.length); // Optional: Log sizes
            } catch (IOException e) {
                System.err.println("Failed to read original request body: " + e.getMessage());
                throw new IOException("Failed to read original request body", e);
            }
        }
    }

    @Override
    public ServletInputStream getInputStream() throws IOException {
        // 返回一个基于解压后（或原始缓存）字节数组的 ServletInputStream
        if (this.decompressedBytes == null) {
            // Should not happen if constructor completed successfully
            throw new IOException("Decompressed bytes are not available.");
        }

        final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(this.decompressedBytes);

        return new ServletInputStream() {
            @Override
            public boolean isFinished() {
                return byteArrayInputStream.available() == 0;
            }

            @Override
            public boolean isReady() {
                return true; // Always ready for ByteArrayInputStream
            }

            @Override
            public void setReadListener(ReadListener readListener) {
                // Asynchronous reading is not supported for ByteArrayInputStream
                throw new UnsupportedOperationException("Asynchronous reading not supported");
            }

            @Override
            public int read() throws IOException {
                return byteArrayInputStream.read();
            }

            @Override
            public int read(byte[] b, int off, int len) throws IOException {
                return byteArrayInputStream.read(b, off, len);
            }
            @Override
            public int read(byte[] b) throws IOException {
                return byteArrayInputStream.read(b);
            }

            // You might need to override other read methods depending on how the consumer reads the stream
        };
    }

    // 注意：如果你的 Controller 可能会使用 request.getReader() (例如 @RequestBody String)，
    // 你还需要重写 getReader() 方法，并确保它使用正确的字符编码从解压后的字节数组创建 Reader。
    // 示例 (假设 UTF-8):
    @Override
    public java.io.BufferedReader getReader() throws IOException {
        if (this.decompressedBytes == null) {
            throw new IOException("Decompressed bytes are not available.");
        }
        // Assuming UTF-8 encoding for text body
        return new java.io.BufferedReader(new java.io.InputStreamReader(new ByteArrayInputStream(this.decompressedBytes), "UTF-8"));
    }

    // 如果需要，也可以重写 getContentLength() 和 getContentLengthLong()
    // 返回解压后的数据长度 (虽然不总是必须，但更精确)
    @Override
    public int getContentLength() {
        return decompressedBytes == null ? 0 : decompressedBytes.length;
    }

    @Override
    public long getContentLengthLong() {
        return decompressedBytes == null ? 0 : decompressedBytes.length;
    }

}
