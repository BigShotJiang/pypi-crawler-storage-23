package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightTraveler;
import com.ruoyi.gds.module.vo.CarrierVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 乘机人Mapper接口
 * 
 * @author ruoyi
 * @date 2025-04-18
 */
public interface FlightTravelerMapper extends BaseMapper<FlightTraveler>
{
    /**
     * 查询乘机人
     * 
     * @param id 乘机人主键
     * @return 乘机人
     */
    public FlightTraveler selectFlightTravelerById(Long id);

    /**
     * 查询乘机人列表
     * 
     * @param flightTraveler 乘机人
     * @return 乘机人集合
     */
    public List<FlightTraveler> selectFlightTravelerList(FlightTraveler flightTraveler);

    /**
     * 新增乘机人
     * 
     * @param flightTraveler 乘机人
     * @return 结果
     */
    public int insertFlightTraveler(FlightTraveler flightTraveler);

    /**
     * 修改乘机人
     * 
     * @param flightTraveler 乘机人
     * @return 结果
     */
    public int updateFlightTraveler(FlightTraveler flightTraveler);

    /**
     * 删除乘机人
     * 
     * @param id 乘机人主键
     * @return 结果
     */
    public int deleteFlightTravelerById(Long id);

    /**
     * 批量删除乘机人
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightTravelerByIds(Long[] ids);


    List<FlightTraveler> selectFlightTravelerByCertificate(@Param("certificates") List<String> certificates);
}
