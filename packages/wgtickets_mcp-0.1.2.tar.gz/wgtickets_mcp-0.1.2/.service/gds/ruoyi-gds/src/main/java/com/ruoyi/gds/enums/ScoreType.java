package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

@Getter
public enum ScoreType {

    QUERY(10000, 30),
    DATE(366, 70);

    @JsonValue
    private final long maxRange;

    private final long weight;

    ScoreType(long maxRange, long weight) {
        this.maxRange = maxRange;
        this.weight = weight;
    }
}
