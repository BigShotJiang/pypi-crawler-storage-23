package com.ruoyi.gds.forest.interceptor;

import cn.hutool.core.date.DatePattern;
import com.dtflys.forest.http.ForestHeader;
import com.dtflys.forest.http.ForestRequest;
import com.ruoyi.framework.manager.AsyncManager;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.config.GDSConfig;
import com.ruoyi.gds.config.ThirdApiRateLimiter;
import com.ruoyi.gds.enums.BusinessType;
import com.ruoyi.gds.enums.ContentType;
import com.ruoyi.gds.enums.ThirdApiRateLimit;
import com.ruoyi.gds.module.domain.GdsRequestLog;
import com.ruoyi.gds.utils.ContextUtil;
import com.ruoyi.gds.utils.StrUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Slf4j
@Component
public class IBEInterceptor extends BaseInterceptor {

    @Autowired
    private GDSConfig gdsConfig;

    @Autowired
    private ThirdApiRateLimiter thirdApiRateLimiter;

    @Value("${forest.log-enabled:false}")
    private Boolean forestLogEnabled;
    @Value("${forest.log-request:false}")
    private Boolean forestLogRequest;

    @Override
    public boolean beforeExecute(ForestRequest request) {
        // 限流检查（阻塞等待令牌，确保严格限流）
        String path = request.getURI().getPath();
        ThirdApiRateLimit thirdApiRateLimit = ThirdApiRateLimit.fromUrl(path);
        thirdApiRateLimiter.acquire(thirdApiRateLimit);  // 阻塞等待，确保严格限流
        // System.out.println(">>>>>>>>>>>>>>>>> 【" + thirdApiRateLimit.name() + "】" + LocalDateTime.now().format(DateTimeFormatter.ofPattern(DatePattern.NORM_DATETIME_PATTERN)) + ". URL: " + path);

        String authHeader = gdsConfig.getIbe().getUsername() + ":" + gdsConfig.getIbe().getPassword();
        byte[] authHeaderBytes = authHeader.getBytes();
        byte[] encodedAuthHeaderBytes = java.util.Base64.getEncoder().encode(authHeaderBytes);
        String encodedAuthHeader = new String(encodedAuthHeaderBytes);

        request.addHeader("Authorization", "Basic " + encodedAuthHeader);
        request.addHeader("EchoToken", UUID.randomUUID().toString().replace("-", ""));
        request.addHeader("Content-Encoding", "gzip");
        request.addHeader("Accept-Encoding", "gzip");
        request.addHeader("AID", gdsConfig.getIbe().getAid());

        try {
            String businessType = Optional.ofNullable(request.getHeader(CommonConstant.FOREST_HEADER_BUSINESS_TYPE)).map(ForestHeader::getValue).orElse(null);
            String businessCode = Optional.ofNullable(request.getHeader(CommonConstant.FOREST_HEADER_BUSINESS_CODE)).map(ForestHeader::getValue).orElse(null);
            String requestContent = request.getBody().stream()
                    .map(item -> StrUtil.unZip(item.getByteArray()))
                    .collect(Collectors.joining("\n\n\n"));
            if (forestLogEnabled && forestLogRequest) {
                log.info(" [Forest] Request (okhttp3). [Body]: {}", requestContent);
            }

            String traceId = ContextUtil.getTraceId();
            BusinessType type = BusinessType.fromCode(businessType);
            if (Objects.nonNull(type) && type.isSaveRequest()) {
                AsyncManager.me().execute(() -> {
                    GdsRequestLog gdsRequestLog = GdsRequestLog.builder()
                            .traceId(traceId)
                            .businessType(businessType)
                            .businessCode(businessCode)
                            .contentType(ContentType.REQUEST.name())
                            .content(requestContent)
                            .build();
                    gdsRequestLogService.add(gdsRequestLog);
                });
            }
        } catch (Exception e) {
            log.error("[1E]记录请求日志异常. url: {}", request.getUrl(), e);
        }

        return true;
    }

}
