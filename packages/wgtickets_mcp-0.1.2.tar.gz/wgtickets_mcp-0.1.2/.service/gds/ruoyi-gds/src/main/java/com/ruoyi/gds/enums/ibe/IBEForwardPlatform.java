package com.ruoyi.gds.enums.ibe;

public enum IBEForwardPlatform {

    // 同程
    TONG_CHENG,

    // 航班管家
    AIR_MANAGER,

    // 8000翼
    EIGHT_YI,

    // 寰宇
    HUAN_YU,

    // 携程
    XIE_CEHNG,

    // 飞猪
    FEI_ZHU,

}
