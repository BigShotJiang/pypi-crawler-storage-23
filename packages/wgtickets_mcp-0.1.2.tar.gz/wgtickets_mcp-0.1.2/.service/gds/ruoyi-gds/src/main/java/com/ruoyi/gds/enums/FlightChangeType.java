package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum FlightChangeType {

    UN("UN", "航班本身取消"),
    TK("TK", "航班时间发生了变动"),
    HX("HX", "机票座位取消"),
    NO("NO", "机票座位取消"),
    HL("HL", "候补");

    @JsonValue
    private final String code;

    private final String desc;

    FlightChangeType(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static FlightChangeType fromCode(String code) {
        return Arrays.stream(FlightChangeType.values()).filter(item -> StringUtils.isNotBlank(code) && String.valueOf(item.code).equalsIgnoreCase(code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
