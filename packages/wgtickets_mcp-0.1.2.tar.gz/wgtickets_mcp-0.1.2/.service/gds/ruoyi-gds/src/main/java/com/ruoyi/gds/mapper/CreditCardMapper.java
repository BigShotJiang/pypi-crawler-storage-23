package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.CreditCard;

import java.util.List;

/**
 * 自动开票——信用卡开卡记录Mapper接口
 * 
 * @author ruoyi
 * @date 2025-11-28
 */
public interface CreditCardMapper extends BaseMapper<CreditCard>
{
    /**
     * 查询自动开票——信用卡开卡记录
     * 
     * @param id 自动开票——信用卡开卡记录主键
     * @return 自动开票——信用卡开卡记录
     */
    public CreditCard selectCreditCardById(Long id);

    /**
     * 查询自动开票——信用卡开卡记录列表
     * 
     * @param creditCard 自动开票——信用卡开卡记录
     * @return 自动开票——信用卡开卡记录集合
     */
    public List<CreditCard> selectCreditCardList(CreditCard creditCard);

    /**
     * 新增自动开票——信用卡开卡记录
     * 
     * @param creditCard 自动开票——信用卡开卡记录
     * @return 结果
     */
    public int insertCreditCard(CreditCard creditCard);

    /**
     * 修改自动开票——信用卡开卡记录
     * 
     * @param creditCard 自动开票——信用卡开卡记录
     * @return 结果
     */
    public int updateCreditCard(CreditCard creditCard);

    /**
     * 删除自动开票——信用卡开卡记录
     * 
     * @param id 自动开票——信用卡开卡记录主键
     * @return 结果
     */
    public int deleteCreditCardById(Long id);

    /**
     * 批量删除自动开票——信用卡开卡记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteCreditCardByIds(Long[] ids);
}
