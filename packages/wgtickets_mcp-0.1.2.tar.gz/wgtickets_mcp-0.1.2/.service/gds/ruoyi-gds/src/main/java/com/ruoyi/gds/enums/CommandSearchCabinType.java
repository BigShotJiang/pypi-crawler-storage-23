package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Getter
public enum CommandSearchCabinType {

    ECONOMY(1, "E", "经济舱"),
    BUSINESS(3, "P", "商务舱"),
    FIRST(4, "F", "头等舱");

    private final Integer num;

    @JsonValue
    private final String code;

    private final String desc;

    CommandSearchCabinType(Integer num, String code, String desc) {
        this.num = num;
        this.code = code;
        this.desc = desc;
    }

    public static CommandSearchCabinType fromNum(Integer num) {
        if (Objects.isNull(num)) return null;
        return Arrays.stream(CommandSearchCabinType.values()).filter(item -> num.equals(item.num)).findFirst().orElse(null);
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static CommandSearchCabinType fromCode(String code) {
        return Arrays.stream(CommandSearchCabinType.values())
                .filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.code))
                .findFirst()
                .orElse(null);
    }

    public static List<CommandSearchCabinType> valuesWithoutEconomy() {
        return Arrays.stream(CommandSearchCabinType.values()).filter(item -> !ECONOMY.equals(item)).collect(Collectors.toList());
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }
    
}
