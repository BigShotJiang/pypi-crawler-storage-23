package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.gds.utils.StrUtil;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

@Getter
public enum PenaltyType {

    ANY_TIME(0, "Anytime", "ANYTIME", "任何时间"),
    BEFORE_DEPARTURE(1, "BeforeDeparture", "BEFORE_DEPARTURE", "起飞前"),
    AFTER_DEPARTURE(2, "AfterDeparture", "AFTER_DEPARTURE", "起飞后");

    private final int num;

    @JsonValue
    private final String code;

    private final String sabreCode;

    private final String desc;

    PenaltyType(int num, String code, String sabreCode, String desc) {
        this.num = num;
        this.code = code;
        this.sabreCode = sabreCode;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static PenaltyType fromCode(String code) {
        return Arrays.stream(PenaltyType.values())
                .filter(item -> StringUtils.isNotBlank(code) && StrUtil.removeWhiteSpaces(code).equalsIgnoreCase(StrUtil.removeWhiteSpaces(item.code)))
                .findFirst()
                .orElse(null);
    }

    public static PenaltyType fromSabreCode(String sabreCode) {
        return Arrays.stream(PenaltyType.values())
                .filter(item -> StringUtils.isNotBlank(sabreCode) && StrUtil.removeWhiteSpaces(sabreCode).equalsIgnoreCase(StrUtil.removeWhiteSpaces(item.sabreCode)))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
