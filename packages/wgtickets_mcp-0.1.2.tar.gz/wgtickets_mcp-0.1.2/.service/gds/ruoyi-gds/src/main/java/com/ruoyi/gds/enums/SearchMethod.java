package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum SearchMethod {

    PERMITTED(1, "Permitted", "只返回特定航空公司的航班 | 只返回特定舱位等级"),
    PREFERRED(2, "Preferred", "不仅返回特定航空公司的航班，也可能根据最佳价格返回其他航司的航班 | 不仅返回特定舱位等级，也可能根据最佳价格返回其他舱位等级"),
    PROHIBITED(3, "Prohibited", "排除特定航空公司的航班");

    private final Integer num;

    @JsonValue
    private final String code;

    private final String description;

    SearchMethod(Integer num, String code, String description) {
        this.num = num;
        this.code = code;
        this.description = description;
    }

    public static SearchMethod fromNum(Integer num) {
        if (Objects.isNull(num)) return null;
        return Arrays.stream(SearchMethod.values()).filter(item -> num.equals(item.num)).findFirst().orElse(null);
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static SearchMethod fromCode(String code) {
        if (StringUtils.isBlank(code)) return null;
        return Arrays.stream(SearchMethod.values()).filter(item -> code.equals(item.code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + description;
    }

}
