package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightFare;

import java.util.List;

/**
 * 搜索航班结果Mapper接口
 * 
 * @author ruoyi
 * @date 2025-04-14
 */
public interface FlightFareMapper extends BaseMapper<FlightFare>
{
    /**
     * 查询搜索航班结果
     * 
     * @param id 搜索航班结果主键
     * @return 搜索航班结果
     */
    public FlightFare selectFlightFareById(Long id);

    /**
     * 查询搜索航班结果列表
     * 
     * @param flightFare 搜索航班结果
     * @return 搜索航班结果集合
     */
    public List<FlightFare> selectFlightFareList(FlightFare flightFare);

    /**
     * 新增搜索航班结果
     * 
     * @param flightFare 搜索航班结果
     * @return 结果
     */
    public int insertFlightFare(FlightFare flightFare);

    /**
     * 修改搜索航班结果
     * 
     * @param flightFare 搜索航班结果
     * @return 结果
     */
    public int updateFlightFare(FlightFare flightFare);

    /**
     * 删除搜索航班结果
     * 
     * @param id 搜索航班结果主键
     * @return 结果
     */
    public int deleteFlightFareById(Long id);

    /**
     * 批量删除搜索航班结果
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightFareByIds(Long[] ids);
}
