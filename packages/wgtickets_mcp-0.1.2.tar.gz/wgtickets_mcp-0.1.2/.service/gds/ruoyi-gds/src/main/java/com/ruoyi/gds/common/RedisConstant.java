package com.ruoyi.gds.common;

public class RedisConstant {

    // 最新汇率缓存key
    public static final String NEWEST_RATE_KEY = "newest_rate";

    // 最新汇率缓存有效期。单位：分钟
    public static final Integer NEWEST_RATE_EXPIRE = 2 * 60;

    // pnr缓存key
    public static final String PNR_SEGMENT_KEY = "pnr_segment:%s";

    // pnr缓存有效期。单位：分钟
    public static final Integer PNR_SEGMENT_EXPIRE = 2 * 60;

    // 塞班rest accss_token缓存key
    public static final String SABRE_REST_ACCESS_TOKEN_KEY = "sabre_rest_access_token";

    // 塞班websvc token缓存key
    public static final String SABRE_WEBSVC_TOKEN_KEY = "sabre_websvc_token";

    // 塞班websvc session缓存key
    public static final String SABRE_WEBSVC_SESSION_KEY = "sabre_websvc_session";

    // 塞班accss_token默认有效期。单位：秒。Sabre返回：604800
    public static final Integer SABRE_ACCESS_TOKEN_EXPAIR_TIME_DEFAUL = 600000;

    // 塞班 websvc token 默认有效期。单位：分钟
    public static final Integer SABRE_WEBSVC_TOKEN_EXPAIR_TIME_DEFAUL = 90;

    // 塞班 websvc session 默认有效期。单位：分钟
    public static final Integer SABRE_WEBSVC_SESSION_EXPAIR_TIME_DEFAUL = 30;

    // 航班搜索次数缓存key
    public static final String SOLUTION_QUERY_COUNT = "solution_query_count:%s";

    // 航班分值缓存key
    public static final String ZSET_SOLUTION_SCROE_KEY = "solution_scroe";

    // 航班分值过期时间缓存key
    public static final String HASH_SOLUTION_SCROE_EXPIRE_KEY = "solution_scroe_expire";

    // 航班正在刷新报价缓存key
    public static final String SOLUTION_REFRESHING_KEY = "solution_refreshing:%s";

    // 最低报价缓存key
    public static final String LOW_PRICE_KEY = "low_price:%s";

}
