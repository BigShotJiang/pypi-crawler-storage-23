//package com.ruoyi.gds.module.dto.galileo;
//
//import cn.hutool.core.date.DatePattern;
//import com.fasterxml.jackson.annotation.JsonFormat;
//import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
//import com.fasterxml.jackson.databind.annotation.JsonSerialize;
//import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
//import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
//import com.ruoyi.gds.enums.PassengerType;
//import lombok.AllArgsConstructor;
//import lombok.Builder;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//import org.springframework.format.annotation.DateTimeFormat;
//
//import javax.validation.constraints.NotNull;
//import java.io.Serializable;
//import java.time.LocalDate;
//import java.util.Objects;
//
//@Data
//@Builder
//@NoArgsConstructor
//@AllArgsConstructor
//public class PassengerDto implements Serializable {
//
//    private static final long serialVersionUID = 1L;
//
//    /**
//     * 乘客类型
//     */
//    @NotNull(message = "乘客类型不能为空")
//    private PassengerType type;
//
//    /**
//     * 生日
//     */
//    @DateTimeFormat(pattern = DatePattern.NORM_DATE_PATTERN)
//    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATE_PATTERN)
//    @JsonSerialize(using = LocalDateSerializer.class)
//    @JsonDeserialize(using = LocalDateDeserializer.class)
//    private LocalDate birthDay;
//
//
//
//    public void check(){
//        /*if (!(PassengerType.ADT == getType()) && Objects.isNull(getBirthDay()))
//            throw new IllegalArgumentException("儿童或婴儿需指定生日");*/
//    }
//
//}
