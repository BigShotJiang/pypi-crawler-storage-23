package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.common.CommonConstant;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum CreatePnrPreCheckType {

    CREATED_CANCELLED_SAME_SEGMENT_TIMES(1, "已经预订和取消相同航段次数超过" + CommonConstant.CREATE_PNR_CHECK_CREATED_CANCELLED_SAME_SEGMENT_TIMES + "次, 继续预订会面临罚款"),
    BOOKING_SAME_FLIGHT_ON_SAME_DAY(2, "行程同一天有相同航段的预定记录, 重复预订可能面临罚款"),
    TRAVLER_NUMBER(3, "乘客数量数超过" + CommonConstant.CREATE_PNR_CHECK_MAX_TRAVLER + "个, 可能面临罚款"),
    SEGMENT_NUMBER(4, "行程航段数超过" + CommonConstant.CREATE_PNR_CHECK_MAX_SEGMENT + "个, 可能面临罚款");

    @JsonValue
    private final Integer code;

    private final String desc;

    CreatePnrPreCheckType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static CreatePnrPreCheckType fromCode(Integer code) {
        return Arrays.stream(CreatePnrPreCheckType.values()).filter(item -> Objects.nonNull(code) && Objects.equals(item.code, code)).findFirst().orElse(null);
    }

    public static CreatePnrPreCheckType fromName(String name) {
        return Arrays.stream(CreatePnrPreCheckType.values()).filter(item -> StringUtils.isNotBlank(name) && item.name().equalsIgnoreCase(name)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
