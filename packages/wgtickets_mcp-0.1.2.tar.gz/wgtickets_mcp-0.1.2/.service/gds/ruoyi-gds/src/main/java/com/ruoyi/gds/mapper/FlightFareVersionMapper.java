package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightFareVersion;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 行程报价版本Mapper接口
 * 
 * @author ruoyi
 * @date 2025-06-25
 */
public interface FlightFareVersionMapper extends BaseMapper<FlightFareVersion>
{
    /**
     * 查询行程报价版本
     * 
     * @param id 行程报价版本主键
     * @return 行程报价版本
     */
    public FlightFareVersion selectFlightFareVersionById(Long id);

    /**
     * 查询行程报价版本列表
     * 
     * @param flightFareVersion 行程报价版本
     * @return 行程报价版本集合
     */
    public List<FlightFareVersion> selectFlightFareVersionList(FlightFareVersion flightFareVersion);

    /**
     * 新增行程报价版本
     * 
     * @param flightFareVersion 行程报价版本
     * @return 结果
     */
    public int insertFlightFareVersion(FlightFareVersion flightFareVersion);

    /**
     * 修改行程报价版本
     * 
     * @param flightFareVersion 行程报价版本
     * @return 结果
     */
    public int updateFlightFareVersion(FlightFareVersion flightFareVersion);

    /**
     * 删除行程报价版本
     * 
     * @param id 行程报价版本主键
     * @return 结果
     */
    public int deleteFlightFareVersionById(Long id);

    /**
     * 批量删除行程报价版本
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightFareVersionByIds(Long[] ids);

    /**
     * 查询各行程最新的报价版本
     * @param flightFareVersion
     * @return
     */
    List<FlightFareVersion> getNewstVersionForFlightFare(FlightFareVersion flightFareVersion);

    Integer selectMaxVersion(@Param("flightFareKey") String flightFareKey);

}
