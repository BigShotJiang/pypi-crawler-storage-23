package com.ruoyi.gds.module.dto;

import com.ruoyi.gds.enums.CurrencyType;
import com.ruoyi.gds.enums.PassengerType;
import com.ruoyi.gds.module.vo.galileo.PenaltyVo;
import com.ruoyi.gds.utils.HuanYuDataUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;

import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreatePnrPriceVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 币种
     */
    private CurrencyType currencyCode;

    /**
     * 总价
     */
    private BigDecimal totalPrice;

    /**
     * 票面价
     */
    private BigDecimal basePrice;

    /**
     * 税费
     */
    private BigDecimal taxes;

    /**
     * 优惠金额
     */
    private BigDecimal discountAmount;

    /**
     * 各类乘机人报价
     */
    private List<@Valid PassengerPriceVo> passengerPrices;


    public CurrencyType getCurrencyCode() {
        return Optional.ofNullable(currencyCode).orElse(CurrencyType.CNY);
    }


    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class PassengerPriceVo implements Serializable {

        private static final long serialVersionUID = 1L;

        /**
         * 乘机人类型
         */
        @NotNull(message = "乘机人类型为空")
        private PassengerType passengerType;

        /**
         * 乘机人数量
         */
        @NotNull(message = "乘机人数为空")
        @Min(value = 1, message = "乘机人数错误")
        private Integer passengerNum;

        /**
         * 币种
         */
        private CurrencyType currencyCode;

        /**
         * 总价
         */
        @NotNull(message = "总价为空")
        private BigDecimal totalPrice;

        /**
         * 票面价
         */
        @NotNull(message = "票面价为空")
        private BigDecimal basePrice;

        /**
         * 税费
         */
        @NotNull(message = "税费为空")
        private BigDecimal taxes;

        /**
         * 优惠金额
         */
        private BigDecimal discountAmount;

        /**
         * 退改费用
         */
        private String penalty;

        /**
         * 行李信息
         */
        private String baggage;


        public CurrencyType getCurrencyCode() {
            return Optional.ofNullable(currencyCode).orElse(CurrencyType.CNY);
        }

        public List<PenaltyVo> getCancelPenalties() {
            if (StringUtils.isBlank(getPenalty())) return Lists.newArrayList();
            return HuanYuDataUtil.parsePenaltyFromAdminFare(getPenalty(), HuanYuDataUtil.REFUND);
        }

        public List<PenaltyVo> getChangePenalties() {
            if (StringUtils.isBlank(getPenalty())) return Lists.newArrayList();
            return HuanYuDataUtil.parsePenaltyFromAdminFare(getPenalty(), HuanYuDataUtil.CHANGE);
        }

    }

}
