package com.ruoyi.gds.module;

import com.ruoyi.gds.enums.GDSType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PayOrderReq implements Serializable {

    private static final long serialVersionUID = 1L;


    @NotBlank(message = "orderId不能为空")
    private String orderId;


    private BigDecimal totalPrice;

    /**
     * GDS类型
     */
    @NotNull(message = "GDS为空")
    private GDSType gds;
}
