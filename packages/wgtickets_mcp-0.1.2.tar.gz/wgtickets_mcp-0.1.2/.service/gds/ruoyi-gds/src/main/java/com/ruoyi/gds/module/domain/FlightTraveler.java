package com.ruoyi.gds.module.domain;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.gds.common.ParamValidRegex;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * 乘机人对象 flight_traveler
 * 
 * @author ruoyi
 * @date 2025-04-18
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightTraveler implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 出行人类型。ADT:成人, CNN:儿童, INF:婴儿 */
    @Excel(name = "出行人类型。ADT:成人, CNN:儿童, INF:婴儿")
    @NotBlank(message = "出行人类型为空")
    @Pattern(regexp = ParamValidRegex.PASSENGER_TYPE, message = "出行人类型仅允许 ADT、CNN、INF")
    private String travelerType;

    /** 出行人姓名 */
    @Excel(name = "出行人姓名")
    @Pattern(regexp = ParamValidRegex.NAME_ZH, message = "中文姓名仅允许中文")
    private String name;

    /** 出行人姓名——姓 */
    @Excel(name = "出行人姓名——姓")
    /*@NotBlank(message = "拼音姓为空")*/
    @Pattern(regexp = ParamValidRegex.NAME_EN, message = "拼音姓仅允许英文，且不少于2个字符")
    private String travelerFirstName;

    /** 出行人姓名——名 */
    @Excel(name = "出行人姓名——名")
    @NotBlank(message = "拼音名为空")
    @Pattern(regexp = ParamValidRegex.NAME_EN, message = "拼音名仅允许英文，且不少于2个字符")
    private String travelerLastName;

    /** 证件类型 */
    @Excel(name = "证件类型")
    @NotBlank(message = "证件类型为空")
    @Pattern(regexp = ParamValidRegex.CERTIFICATE_TYPE, message = "证件类型仅允许 NI、P")
    private String certificateType;

    /** 证件号 */
    @Excel(name = "证件号")
    @NotBlank(message = "证件号为空")
    @Pattern(regexp = ParamValidRegex.CERTIFICATE, message = "证件号不合法")
    private String certificate;

    /** 发证国家或地区代码 */
    @Excel(name = "发证国家或地区代码")
    @NotBlank(message = "发证国家或地区代码为空")
    private String certificateCountry;

    /** 持证人国家或地区代码 */
    @Excel(name = "持证人国家或地区代码")
    // @NotBlank(message = "持证人国家或地区代码为空")
    private String certificateOwnerCountry;

    /** 证件有效期截止日期 */
    @NotNull(message = "证件有效期截止日期为空")
    @DateTimeFormat(pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate expireDate;

    /** 出行人手机号 */
    @Excel(name = "出行人手机号")
    private String phone;

    /** 出行人邮箱 */
    @Excel(name = "出行人邮箱")
    @Pattern(regexp = ParamValidRegex.EMAIL, message = "邮箱格式不合法")
    private String email;

    /** 出行人性别 */
    @Excel(name = "出行人性别")
    @NotBlank(message = "性别为空")
    @Pattern(regexp = ParamValidRegex.GENDER, message = "性别仅允许 男性、女性")
    private String gender;

    /** 出行人生日 / 持证人生日 */
    @NotNull(message = "出行人生日为空")
    @DateTimeFormat(pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate birthDay;

    /** 紧急联系人手机号 */
    @Excel(name = "紧急联系人手机号")
    private String emergencyPhone;

    /** 紧急联系人邮箱 */
    @Excel(name = "紧急联系人邮箱")
    @Pattern(regexp = ParamValidRegex.EMAIL, message = "紧急联系人邮箱格式不合法")
    private String emergencyEmail;

    /** 创建者ID */
    @Excel(name = "创建者ID")
    private Long createUserId;

    /** 创建者 */
    @Excel(name = "创建者")
    private String createBy;

    /** 创建时间 */
    @Excel(name = "创建时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTime;

    /** 更新者ID */
    @Excel(name = "更新者ID")
    private Long updateUserId;

    /** 更新者 */
    @Excel(name = "更新者")
    private String updateBy;

    /** 更新时间 */
    @Excel(name = "更新时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime updateTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("travelerType", getTravelerType())
            .append("name", getName())
            .append("travelerFirstName", getTravelerFirstName())
            .append("travelerLastName", getTravelerLastName())
            .append("certificateType", getCertificateType())
            .append("certificate", getCertificate())
            .append("certificateCountry", getCertificateCountry())
            .append("certificateOwnerCountry", getCertificateOwnerCountry())
            .append("expireDate", getExpireDate())
            .append("phone", getPhone())
            .append("email", getEmail())
            .append("gender", getGender())
            .append("birthDay", getBirthDay())
            .append("emergencyPhone", getEmergencyPhone())
            .append("emergencyEmail", getEmergencyEmail())
            .append("createUserId", getCreateUserId())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateUserId", getUpdateUserId())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("delFlag", isDelFlag())
            .toString();
    }
}
