package com.ruoyi.gds.enums.ibe;

import com.fasterxml.jackson.annotation.JsonCreator;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum MealServiceType {

    B("B", "早餐"),
    C("C", "免费酒精饮料"),
    D("D", "正餐"),
    F("F", "供采购的食物"),
    G("G", "供采购的食物和饮料"),
    H("H", "热的膳食"),
    K("K", "轻快早餐"),
    L("L", "午餐"),
    M("M", "膳食"),
    N("N", "没有饭食供应"),
    O("O", "冷的膳食"),
    P("P", "供采购的酒精饮料"),
    R("R", "茶点"),
    S("S", "快餐"),
    V("V", "供采购的茶点");

    private final String code;

    private final String desc;

    MealServiceType(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static MealServiceType fromCode(String code) {
        return Arrays.stream(MealServiceType.values()).filter(item -> Objects.equals(code, item.code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
