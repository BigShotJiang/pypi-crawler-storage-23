package com.ruoyi.gds.enums.ibe;

public enum IBEFareType {

    PRIVATE, PUBLIC, PAPER

}
