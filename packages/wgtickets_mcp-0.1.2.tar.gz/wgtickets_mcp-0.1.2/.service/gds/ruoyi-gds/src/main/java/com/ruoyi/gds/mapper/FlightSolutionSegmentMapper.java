package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.Flight;
import com.ruoyi.gds.module.domain.FlightSolutionSegment;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 行程方案航段Mapper接口
 *
 * @author ruoyi
 * @date 2025-09-24
 */
public interface FlightSolutionSegmentMapper extends BaseMapper<FlightSolutionSegment> {
    /**
     * 查询行程方案航段
     *
     * @param id 行程方案航段主键
     * @return 行程方案航段
     */
    public FlightSolutionSegment selectFlightSolutionSegmentById(Long id);

    /**
     * 查询行程方案航段列表
     *
     * @param flightSolutionSegment 行程方案航段
     * @return 行程方案航段集合
     */
    public List<FlightSolutionSegment> selectFlightSolutionSegmentList(FlightSolutionSegment flightSolutionSegment);

    /**
     * 新增行程方案航段
     *
     * @param flightSolutionSegment 行程方案航段
     * @return 结果
     */
    public int insertFlightSolutionSegment(FlightSolutionSegment flightSolutionSegment);

    /**
     * 修改行程方案航段
     *
     * @param flightSolutionSegment 行程方案航段
     * @return 结果
     */
    public int updateFlightSolutionSegment(FlightSolutionSegment flightSolutionSegment);

    /**
     * 删除行程方案航段
     *
     * @param id 行程方案航段主键
     * @return 结果
     */
    public int deleteFlightSolutionSegmentById(Long id);

    /**
     * 批量删除行程方案航段
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightSolutionSegmentByIds(Long[] ids);

    /**
     * 批量写入，重复时跳过
     * @param flightSolutionSegments
     * @return
     */
    int batchInsert(@Param("flightSolutionSegments") List<FlightSolutionSegment> flightSolutionSegments);

    List<Flight> queryFlights(@Param("flightSolutionKey") String flightSolutionKey);

}
