package com.ruoyi.gds.forest.interceptor;

import com.dtflys.forest.http.ForestBody;
import com.dtflys.forest.http.ForestHeader;
import com.dtflys.forest.http.ForestRequest;
import com.dtflys.forest.http.ForestResponse;
import com.dtflys.forest.http.body.StringRequestBody;
import com.dtflys.forest.interceptor.Interceptor;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.framework.manager.AsyncManager;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.enums.BusinessType;
import com.ruoyi.gds.enums.ContentType;
import com.ruoyi.gds.module.domain.GdsRequestLog;
import com.ruoyi.gds.service.IGdsRequestLogService;
import com.ruoyi.common.utils.spring.SpringUtils;
import com.ruoyi.gds.utils.ContextUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@Component
public class BaseInterceptor<T> implements Interceptor<T> {

    protected final IGdsRequestLogService gdsRequestLogService = SpringUtils.getBean(IGdsRequestLogService.class);

    @Override
    public boolean beforeExecute(ForestRequest request) {
        try {
            String businessType = Optional.ofNullable(request.getHeader(CommonConstant.FOREST_HEADER_BUSINESS_TYPE)).map(ForestHeader::getValue).orElse(null);
            String businessCode = Optional.ofNullable(request.getHeader(CommonConstant.FOREST_HEADER_BUSINESS_CODE)).map(ForestHeader::getValue).orElse(null);
            String requestContent = Optional.ofNullable(request.getBody())
                    .map(ForestBody::getStringItems)
                    .map(items -> items.stream().map(StringRequestBody::getContent).filter(StringUtils::isNotBlank).collect(Collectors.joining("\n\n\n")))
                    .orElse(null);
            if (StringUtils.isBlank(requestContent)) {
                requestContent = Optional.ofNullable(request.getBody())
                        .map(items -> items.stream().map(item -> new String(item.getByteArray())).filter(StringUtils::isNotBlank).collect(Collectors.joining("\n\n\n")))
                        .orElse(null);
            }

            String traceId = ContextUtil.getTraceId();
            BusinessType type = BusinessType.fromCode(businessType);
            if (Objects.nonNull(type) && type.isSaveRequest()) {
                String finalRequestContent = requestContent;
                AsyncManager.me().execute(() -> {
                    GdsRequestLog gdsRequestLog = GdsRequestLog.builder()
                            .traceId(traceId)
                            .businessType(businessType)
                            .businessCode(StringUtils.isNotBlank(businessCode) ? businessCode : traceId)
                            .contentType(ContentType.REQUEST.name())
                            .content(finalRequestContent)
                            .build();
                   gdsRequestLogService.add(gdsRequestLog);
                });
            }
        } catch (Exception e) {
            log.error("记录请求日志异常. url: {}", request.getUrl(), e);
        }

        return true;
    }

    @Override
    public void afterExecute(ForestRequest request, ForestResponse response) {
        if (response.isSuccess()) {
            try {
                String businessType = Optional.ofNullable(request.getHeader(CommonConstant.FOREST_HEADER_BUSINESS_TYPE)).map(ForestHeader::getValue).orElse(null);
                String businessCode = Optional.ofNullable(request.getHeader(CommonConstant.FOREST_HEADER_BUSINESS_CODE)).map(ForestHeader::getValue).orElse(null);
                String responseContent = StringUtils.isNotBlank(response.getContent()) && !"null".equalsIgnoreCase(response.getContent()) ? response.getContent() : null;

                String traceId = ContextUtil.getTraceId();
                BusinessType type = BusinessType.fromCode(businessType);
                if (Objects.nonNull(type) && type.isSaveResponse()) {
                    AsyncManager.me().execute(() -> {
                        GdsRequestLog gdsRequestLog = GdsRequestLog.builder()
                                .traceId(traceId)
                                .businessType(businessType)
                                .businessCode(StringUtils.isNotBlank(businessCode) ? businessCode : traceId)
                                .contentType(ContentType.RESPONSE.name())
                                .content(responseContent)
                                .build();
                        gdsRequestLogService.add(gdsRequestLog);
                    });
                }
            } catch (Exception e) {
                log.error("记录响应日志异常. url: {}", request.getUrl(), e);
            }
        } else {
            log.error("请求失败. {}", request.getUrl(), response.getException());
            String errMsg = Optional.ofNullable(response.getException()).map(Throwable::toString).map(msg -> msg.contains("java.net.SocketTimeoutException") ? "请求三方超时" : msg).orElse("请求三方失败");
            throw new ServiceException(errMsg, HttpStatus.ERROR);
        }

        Interceptor.super.afterExecute(request, response);
    }

}
