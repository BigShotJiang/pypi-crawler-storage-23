package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.IbeForward;

import java.util.List;

/**
 * IBE预定记录（转发IBE请求用）Mapper接口
 * 
 * @author ruoyi
 * @date 2025-04-22
 */
public interface IbeForwardMapper extends BaseMapper<IbeForward>
{
    /**
     * 查询IBE预定记录（转发IBE请求用）
     * 
     * @param id IBE预定记录（转发IBE请求用）主键
     * @return IBE预定记录（转发IBE请求用）
     */
    public IbeForward selectIbeForwardById(Long id);

    /**
     * 查询IBE预定记录（转发IBE请求用）列表
     * 
     * @param ibeForward IBE预定记录（转发IBE请求用）
     * @return IBE预定记录（转发IBE请求用）集合
     */
    public List<IbeForward> selectIbeForwardList(IbeForward ibeForward);

    /**
     * 新增IBE预定记录（转发IBE请求用）
     * 
     * @param ibeForward IBE预定记录（转发IBE请求用）
     * @return 结果
     */
    public int insertIbeForward(IbeForward ibeForward);

    /**
     * 修改IBE预定记录（转发IBE请求用）
     * 
     * @param ibeForward IBE预定记录（转发IBE请求用）
     * @return 结果
     */
    public int updateIbeForward(IbeForward ibeForward);

    /**
     * 删除IBE预定记录（转发IBE请求用）
     * 
     * @param id IBE预定记录（转发IBE请求用）主键
     * @return 结果
     */
    public int deleteIbeForwardById(Long id);

    /**
     * 批量删除IBE预定记录（转发IBE请求用）
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteIbeForwardByIds(Long[] ids);
}
