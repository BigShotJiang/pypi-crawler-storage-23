package com.ruoyi.gds.module;

import cn.hutool.core.collection.CollectionUtil;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.enums.PassengerType;
import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.gds.module.dto.galileo.SegementDto;
import com.ruoyi.gds.module.dto.validation.AIR;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.assertj.core.util.Lists;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchCabinQuantityReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 行程Key。 flightKey & flightFareKey 为 segements 赋值
     */
    @NotBlank(message = "行程Key为空", groups = {AIR.class})
    private String flightKey;

    /**
     * 行程方案报价Key。 flightKey & flightFareKey 为 segements 赋值
     */
    @NotBlank(message = "行程方案报价Key为空", groups = {AIR.class})
    private String flightFareKey;




    /**
     * GDS类型。前端未传值时，根据 flightKey & flightFareKey 未此字段设置值
     */
    private GDSType providerCode;

    /**
     * 航班信息。前端未传值时，根据 flightKey & flightFareKey 未此字段设置值
     */
    private List<SegementDto> segements;



    /**
     * 是否使用 承运方(主飞) 航班查询。默认：false
     */
    private Boolean useOperating;

    /**
     * 乘客信息
     */
    @NotEmpty(message = "乘客信息为空", groups = {AIR.class})
    private List<PassengerType> passengers;


    public List<SegementDto> getSegements() {
        return Optional.ofNullable(segements)
                .map(segementDtos -> segementDtos.stream().peek(segementDto -> {
                    segementDto.setSeq(segements.indexOf(segementDto));
                }).collect(Collectors.toList()))
                .orElse(Lists.newArrayList());
    }

    public Boolean getUseOperating() {
        return Optional.ofNullable(useOperating).orElse(false);
    }

    public void check() {
        check(providerCode);
    }

    public void check(GDSType gdsType) {
        if (CollectionUtil.isEmpty(segements)) {
            throw new InvalidParamException("航段信息为空");
        }

        for (SegementDto segement : segements) {
            if (StringUtils.isBlank(segement.getOrigin())) {
                throw new InvalidParamException("出发地为空");
            }
            if (StringUtils.isBlank(segement.getDestination())) {
                throw new InvalidParamException("目的地为空");
            }
            if (StringUtils.isBlank(segement.getCarrier())) {
                throw new InvalidParamException("市场方航司二字码为空");
            }
            if (StringUtils.isBlank(segement.getFlightNumber())) {
                throw new InvalidParamException("市场方航班号为空");
            }
            if (StringUtils.isBlank(segement.getDepartureTime())) {
                throw new InvalidParamException("出发时间为空");
            }
        }

        switch (gdsType) {
            case IBE:
                for (SegementDto segement : segements) {
                    if (StringUtils.isBlank(segement.getOperatingCarrier())) {
                        throw new InvalidParamException("承运方航司二字码为空");
                    }
                    if (StringUtils.isBlank(segement.getOperatingFlightNumber())) {
                        throw new InvalidParamException("承运方航班号为空");
                    }
                }
                break;
            case GALELIO:
                if (CollectionUtil.isEmpty(passengers)) {
                    throw new InvalidParamException("乘客信息为空");
                }
                break;
            default:
                throw new InvalidParamException("GDS类型错误");
        }
    }

}
