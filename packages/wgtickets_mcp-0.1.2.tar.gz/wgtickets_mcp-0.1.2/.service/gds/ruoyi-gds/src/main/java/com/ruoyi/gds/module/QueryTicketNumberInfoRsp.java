package com.ruoyi.gds.module;

import com.ruoyi.gds.module.vo.FlightTravelerVo;
import com.ruoyi.gds.module.vo.TicketNumberVo;
import com.ruoyi.gds.module.vo.galileo.BaseFlightVo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class QueryTicketNumberInfoRsp<T> extends CommonRsp<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PNR航段信息
     */
    private List<BaseFlightVo> pnrSegments;

    /**
     * PNR乘机人信息
     */
    private List<FlightTravelerVo> pnrTravelers;

    /**
     * 票号的航段信息
     */
    private List<TicketNumberVo> ticketNumbers;

}
