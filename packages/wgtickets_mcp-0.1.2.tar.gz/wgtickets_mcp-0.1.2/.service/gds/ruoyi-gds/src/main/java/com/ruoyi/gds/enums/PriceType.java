package com.ruoyi.gds.enums;

import lombok.Getter;

@Getter
public enum PriceType {

    // 预订价
    RESERVATION_PRICE,

    // 出票价
    ISSUE_PRICE
    
}
