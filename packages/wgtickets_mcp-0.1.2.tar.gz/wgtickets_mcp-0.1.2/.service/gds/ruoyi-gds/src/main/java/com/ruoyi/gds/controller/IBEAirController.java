package com.ruoyi.gds.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.enums.PassengerType;
import com.ruoyi.gds.enums.ibe.IBEForwardPlatform;
import com.ruoyi.gds.module.*;
import com.ruoyi.gds.module.dto.ibe.*;
import com.ruoyi.gds.module.dto.validation.IBE;
import com.ruoyi.gds.module.vo.galileo.FlightPlantVo;
import com.ruoyi.gds.module.vo.ibe.QueryPnrPassengerPriceVo;
import com.ruoyi.gds.schema.ibe.OTAAirBookRS;
import com.ruoyi.gds.schema.ibe.OTAAirResRetRS;
import com.ruoyi.gds.schema.ibe.TESAirfareAutoTicketRS;
import com.ruoyi.gds.service.IBEService;
import com.ruoyi.gds.service.IbeForwardService;
import lombok.extern.slf4j.Slf4j;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Slf4j
@RestController
@RequestMapping("/air/ibe")
public class IBEAirController {

    @Autowired
    private IBEService ibeService;
    @Autowired
    private IbeForwardService ibeForwardService;


    /**
     * 搜索航班
     *
     * @param searchFlightDto
     * @return
     */
    @PostMapping(value = "/searchFlight")
    public AjaxResult searchFlight(@RequestBody @Validated IBESearchFlightDto searchFlightDto) throws JsonProcessingException {
        List<IBEPassengerDto> passengerDtos = Optional.ofNullable(searchFlightDto.getPassengerList())
                .map(passengerTypeList -> passengerTypeList.stream().map(passengerType ->
                        IBEPassengerDto.builder()
                                .ptc(Lists.newArrayList(passengerType))
                                .birthDay(PassengerType.CNN == passengerType
                                        ? LocalDate.now().minusYears(CommonConstant.CNN_AGE)
                                        : PassengerType.INF == passengerType ? LocalDate.now().minusYears(CommonConstant.INF_AGE) : null)
                                .build()
                ).collect(Collectors.toList()))
                .orElse(Lists.newArrayList());
        searchFlightDto.setPassengers(passengerDtos);

        List<FlightPlantVo> flightPlantVos = ibeService.searchFlight(searchFlightDto);
        return AjaxResult.success(flightPlantVos);
    }

    /**
     * 查询航班价格
     *
     * @param searchPriceReq
     * @return
     */
    @PostMapping(value = "/searchFlightPrice")
    public AjaxResult searchFlightPrice(@RequestBody @Validated(value = IBE.class) SearchPriceReq searchPriceReq) {
        SearchPriceRsp searchPriceRsp = ibeService.searchLowPrice(searchPriceReq);
        return AjaxResult.success(searchPriceRsp);
    }

    /**
     * 查询舱位数
     *
     * @param searchReq
     * @return
     */
    @PostMapping(value = "/searchCabinQuantity")
    public AjaxResult searchCabinQuantity(@RequestBody SearchCabinQuantityReq searchReq) {
        SearchCabinQuantityRsp searchCabinQuantityRsp = ibeService.searchCabinQuantity(searchReq);
        return AjaxResult.success(searchCabinQuantityRsp);
    }

    /**
     * 预定机票
     *
     * @param createPnrReq
     * @return
     */
    @PostMapping(value = "/createPnr")
    public AjaxResult createPnr(@RequestBody @Validated(value = IBE.class) CreatePnrReq createPnrReq) {
        // 入参校验
        createPnrReq.check();

        CreatePnrRsp<OTAAirBookRS> result = ibeService.createPnr(createPnrReq);

        return AjaxResult.success(result.getErrMsg(), result.getCancelPnrDto());
    }

    /**
     * 查询PNR
     *
     * @param pnr
     * @return
     */
    @GetMapping(value = "/queryPnr")
    public AjaxResult queryPnr(@RequestParam String pnr) {
        if (StringUtils.isBlank(pnr)) {
            throw new ServiceException("PNR为空", HttpStatus.BAD_REQUEST);
        }
        if (pnr.length() != 6) {
            throw new ServiceException("PNR格式错误", HttpStatus.BAD_REQUEST);
        }

        QueryPnrRsp<OTAAirResRetRS> pnrRsp = ibeService.queryPnr(pnr);
        Optional.ofNullable(pnrRsp).ifPresent(rsp -> rsp.setOrignalInfo(null));

        return AjaxResult.success(pnrRsp);
    }

    /**
     * 取消PNR
     *
     * @param cancelPnrDto
     * @return
     */
    @PostMapping(value = "/cancelPnr")
    public AjaxResult cancelPnr(@RequestBody @Validated CancelPnrDto cancelPnrDto) {
        CommonRsp<OTAAirBookRS> cancelPnrRsp = ibeService.cancelPnr(cancelPnrDto);
        return AjaxResult.success(cancelPnrRsp);
    }

    /**
     * 出票时查询PNR最新报价
     * @param pnrPriceDto
     * @return
     */
    @PostMapping(value = "/queryPnrPrice")
    public AjaxResult queryPnrPrice(@RequestBody @Validated({IBE.class}) QueryPnrPriceDto pnrPriceDto) {
        CommonRsp<List<QueryPnrPassengerPriceVo>> issuePriceByC43 = ibeService.queryIssuePriceByC43(pnrPriceDto);
        return AjaxResult.success(issuePriceByC43.getConvertInfo());
    }

    /**
     * 出票
     * @param IBEIssueTicketDto
     * @return
     */
    @PostMapping(value = "/issueTicket")
    public AjaxResult issueTicketAuto(@RequestBody @Validated({IBE.class}) IBEIssueTicketDto IBEIssueTicketDto) {
        CommonRsp<TESAirfareAutoTicketRS> issueTicketRsp = ibeService.issueTicket(IBEIssueTicketDto);
        return AjaxResult.success(issueTicketRsp);
    }


    /**
     * 转发同程请求
     *
     * @param request
     * @param response
     * @return
     */
    @Anonymous
    @PostMapping(value = "/forward")
    public String forwardByTongCheng(HttpServletRequest request, HttpServletResponse response, @RequestParam String path) {
        return ibeForwardService.forward(request, response, IBEForwardPlatform.TONG_CHENG, path);
    }

    /**
     * 转发航班管家请求
     *
     * @param request
     * @param response
     * @return
     */
    @Anonymous
    @PostMapping(value = "/forward/am")
    public String forwardByAirManager(HttpServletRequest request, HttpServletResponse response, @RequestParam String path) {
        return ibeForwardService.forward(request, response, IBEForwardPlatform.AIR_MANAGER, path);
    }

    /**
     * 转发8000翼请求
     *
     * @param request
     * @param response
     * @return
     */
    @Anonymous
    @PostMapping(value = "/forward/eightYi")
    public String forwardByEightYi(HttpServletRequest request, HttpServletResponse response, @RequestParam String path) {
        return ibeForwardService.forward(request, response, IBEForwardPlatform.EIGHT_YI, path);
    }

    /**
     * 转发寰宇请求
     *
     * @param request
     * @param response
     * @return
     */
    @Anonymous
    @PostMapping(value = "/forward/huanYu")
    public String forwardByHuanYu(HttpServletRequest request, HttpServletResponse response, @RequestParam String path) {
        return ibeForwardService.forward(request, response, IBEForwardPlatform.HUAN_YU, path);
    }

    /**
     * 转发写携程请求
     *
     * @param request
     * @param response
     * @return
     */
    @Anonymous
    @PostMapping(value = "/forward/xiecheng")
    public String forwardByXiecheng(HttpServletRequest request, HttpServletResponse response, @RequestParam String path) {
        return ibeForwardService.forward(request, response, IBEForwardPlatform.XIE_CEHNG, path);
    }

    /**
     * 转发写携程请求
     *
     * @param request
     * @param response
     * @return
     */
    @Anonymous
    @PostMapping(value = "/forward/feizhu")
    public String forwardByFeizhu(HttpServletRequest request, HttpServletResponse response, @RequestParam String path) {
        return ibeForwardService.forward(request, response, IBEForwardPlatform.FEI_ZHU, path);
    }

//    /**
//     * 订单完成接口
//     * @return
//     */
//    @PostMapping("/completeOrder")
//    public AjaxResult completeOrder(@RequestBody String json) {
//        return AjaxResult.success(ibeForwardService.completeOrder(json));
//    }
}
