package com.ruoyi.gds.enums;

public enum GalileoKeyType {
    // 报价Key
    AIR_PRICING_SOLUTION_KEY,

    // 航段Key
    SEGMENT_KEY

}
