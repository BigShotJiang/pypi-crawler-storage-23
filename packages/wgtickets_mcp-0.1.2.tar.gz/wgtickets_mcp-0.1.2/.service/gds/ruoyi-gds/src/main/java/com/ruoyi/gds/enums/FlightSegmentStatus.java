package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum FlightSegmentStatus {

    NN("NN", "申请", "HN 申请"),
    DR("DR", "再确认", "RR 再确认"),
    DK("DK", "直接占座", "HK 确认"),
    DW("DW", "候补", "HL 候补"),
    KK("KK", "确认", "HK 确认"),
    KL("KL", "从候补状态确认", "HK 确认"),
    SS("SS", "销售", "HK 确认"),
    TK("TK", "确认，提示旅客航班时刻已更改", "HK 确认"),
    TL("TL", "候补，提示旅客航班时刻已更改", "HL 候补"),
    TN("TN", "申请，提示旅客航班时刻已更改", "HN 申请"),
    NO("NO", "航空公司不允许销售", "该航段被移入 PNR 的历史部分"),
    UC("UC", "不接受候补或订座，航班已关闭（不接受申请）", "该航段被移入 PNR 的历史部分"),
    UN("UN", "航班取消", "该航段被移入 PNR 的历史部分"),
    US("US", "不接受订座（航班已关闭，可以候补）", "HL 候补"),
    UU("UU", "不接受订座（可以候补）", "HL 候补"),
    XL("XL", "取消候补", "该航段被移入 PNR 的历史部分"),
    XX("XX", "取消确认或申请", "该航段被移入 PNR 的历史部分"),
    PK("PK", "无缘航段 HK 状态", "相当于 HK"),
    PU("PU", "无缘航段 PK 状态的 UPDATE", "相当于 HK");

    // 行动代码
    @JsonValue
    private final String code;

    // 描述
    private final String desc;

    // 封口（@）后状态及含义
    private final String remark;

    FlightSegmentStatus(String code, String desc, String remark) {
        this.code = code;
        this.desc = desc;
        this.remark = remark;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static FlightSegmentStatus fromCode(String code) {
        return Arrays.stream(FlightSegmentStatus.values()).filter(item -> Objects.equals(code, item.code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
