package com.ruoyi.gds.module;

import com.ruoyi.gds.module.domain.FlightPnrFare;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreatePnrRsp<T> extends CommonRsp<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 警告信息
     */
    private String warning;

    /**
     * 请求GDS的信息
     */
    private String requestInfo;

    /**
     * 预约记录ID
     */
    private Long reservationId;

    /**
     * PNR
     */
    private String pnr;

    /**
     * 大编码
     */
    private String bigPnr;

    /**
     * 取消PNR预定时的传参
     */
    private Object cancelPnrDto;

    /**
     * PNR预订价
     */
    private FlightPnrFare pnrFare;

}
