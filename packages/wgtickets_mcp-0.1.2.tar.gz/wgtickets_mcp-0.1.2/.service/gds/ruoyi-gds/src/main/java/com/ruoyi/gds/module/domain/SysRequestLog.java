package com.ruoyi.gds.module.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.util.Date;

/**
 * 请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息对象 sys_request_log
 * 
 * @author ruoyi
 * @date 2025-02-07
 */
public class SysRequestLog extends BaseEntity
{
    private static final long serialVersionUID = 1L;

    /** $column.columnComment */
    private Long id;

    /** 请求的 URL */
    @Excel(name = "请求的 URL")
    private String requestUrl;

    /** 请求参数，JSON 格式 */
    @Excel(name = "请求参数，JSON 格式")
    private String requestParams;

    /** 响应内容，JSON 格式 */
    @Excel(name = "响应内容，JSON 格式")
    private String response;

    /** 响应状态（例如：成功、失败等） */
    @Excel(name = "响应状态", readConverterExp = "例=如：成功、失败等")
    private String status;

    /** 请求发起的时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "请求发起的时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date requestTime;

    /** 响应返回的时间 */
    @JsonFormat(pattern = "yyyy-MM-dd")
    @Excel(name = "响应返回的时间", width = 30, dateFormat = "yyyy-MM-dd")
    private Date responseTime;

    /** 请求的执行时长，单位：毫秒 */
    @Excel(name = "请求的执行时长，单位：毫秒")
    private Long executionTime;

    /** 请求类型（GET、POST等） */
    @Excel(name = "请求类型", readConverterExp = "G=ET、POST等")
    private String requestType;

    /** 错误信息，当请求失败时记录 */
    @Excel(name = "错误信息，当请求失败时记录")
    private String errorMessage;

    /** 请求头信息，JSON 格式 */
    @Excel(name = "请求头信息，JSON 格式")
    private String requestHeaders;

    public void setId(Long id) 
    {
        this.id = id;
    }

    public Long getId() 
    {
        return id;
    }
    public void setRequestUrl(String requestUrl) 
    {
        this.requestUrl = requestUrl;
    }

    public String getRequestUrl() 
    {
        return requestUrl;
    }
    public void setRequestParams(String requestParams) 
    {
        this.requestParams = requestParams;
    }

    public String getRequestParams() 
    {
        return requestParams;
    }
    public void setResponse(String response) 
    {
        this.response = response;
    }

    public String getResponse() 
    {
        return response;
    }
    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getStatus() 
    {
        return status;
    }
    public void setRequestTime(Date requestTime) 
    {
        this.requestTime = requestTime;
    }

    public Date getRequestTime() 
    {
        return requestTime;
    }
    public void setResponseTime(Date responseTime) 
    {
        this.responseTime = responseTime;
    }

    public Date getResponseTime() 
    {
        return responseTime;
    }
    public void setExecutionTime(Long executionTime) 
    {
        this.executionTime = executionTime;
    }

    public Long getExecutionTime() 
    {
        return executionTime;
    }
    public void setRequestType(String requestType) 
    {
        this.requestType = requestType;
    }

    public String getRequestType() 
    {
        return requestType;
    }
    public void setErrorMessage(String errorMessage) 
    {
        this.errorMessage = errorMessage;
    }

    public String getErrorMessage() 
    {
        return errorMessage;
    }
    public void setRequestHeaders(String requestHeaders) 
    {
        this.requestHeaders = requestHeaders;
    }

    public String getRequestHeaders() 
    {
        return requestHeaders;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("requestUrl", getRequestUrl())
            .append("requestParams", getRequestParams())
            .append("response", getResponse())
            .append("status", getStatus())
            .append("requestTime", getRequestTime())
            .append("responseTime", getResponseTime())
            .append("executionTime", getExecutionTime())
            .append("requestType", getRequestType())
            .append("errorMessage", getErrorMessage())
            .append("requestHeaders", getRequestHeaders())
            .toString();
    }
}
