package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.gds.module.domain.FczAirchangeCustom;
import com.ruoyi.gds.service.IFczAirchangeCustomService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 飞常准—定制航变通知记录Controller
 * 
 * @author ruoyi
 * @date 2025-11-18
 */
@RestController
@RequestMapping("/airChange/fcz/custom")
public class FczAirchangeCustomController extends BaseController
{
    @Autowired
    private IFczAirchangeCustomService fczAirchangeCustomService;

    /**
     * 查询飞常准—定制航变通知记录列表
     */
    @PreAuthorize("@ss.hasPermi('system:custom:list')")
    @GetMapping("/list")
    public TableDataInfo list(FczAirchangeCustom fczAirchangeCustom)
    {
        startPage();
        List<FczAirchangeCustom> list = fczAirchangeCustomService.selectFczAirchangeCustomList(fczAirchangeCustom);
        return getDataTable(list);
    }

    /**
     * 导出飞常准—定制航变通知记录列表
     */
    @PreAuthorize("@ss.hasPermi('system:custom:export')")
    @Log(title = "飞常准—定制航变通知记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FczAirchangeCustom fczAirchangeCustom)
    {
        List<FczAirchangeCustom> list = fczAirchangeCustomService.selectFczAirchangeCustomList(fczAirchangeCustom);
        ExcelUtil<FczAirchangeCustom> util = new ExcelUtil<FczAirchangeCustom>(FczAirchangeCustom.class);
        util.exportExcel(response, list, "飞常准—定制航变通知记录数据");
    }

    /**
     * 获取飞常准—定制航变通知记录详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:custom:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(fczAirchangeCustomService.selectFczAirchangeCustomById(id));
    }

    /**
     * 新增飞常准—定制航变通知记录
     */
    @PreAuthorize("@ss.hasPermi('system:custom:add')")
    @Log(title = "飞常准—定制航变通知记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FczAirchangeCustom fczAirchangeCustom)
    {
        return toAjax(fczAirchangeCustomService.insertFczAirchangeCustom(fczAirchangeCustom));
    }

    /**
     * 修改飞常准—定制航变通知记录
     */
    @PreAuthorize("@ss.hasPermi('system:custom:edit')")
    @Log(title = "飞常准—定制航变通知记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FczAirchangeCustom fczAirchangeCustom)
    {
        return toAjax(fczAirchangeCustomService.updateFczAirchangeCustom(fczAirchangeCustom));
    }

    /**
     * 删除飞常准—定制航变通知记录
     */
    @PreAuthorize("@ss.hasPermi('system:custom:remove')")
    @Log(title = "飞常准—定制航变通知记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(fczAirchangeCustomService.deleteFczAirchangeCustomByIds(ids));
    }
}
