//package com.ruoyi.gds.module;
//
//import lombok.AllArgsConstructor;
//import lombok.Builder;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//import java.io.Serializable;
//
//@Data
//@Builder
//@NoArgsConstructor
//@AllArgsConstructor
//public class IssueTicketRsp<T> implements Serializable {
//
//    private static final long serialVersionUID = 1L;
//
//    /**
//     * 原始信息
//     */
//    private String orignalInfo;
//
//    /**
//     * 转换后信息
//     */
//    private T convertInfo;
//
//    /**
//     * 出票失败时的错误信息
//     */
//    private String errMsg;
//
//}
