package com.ruoyi.gds.module;

import cn.hutool.core.collection.CollectionUtil;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.ValidatorUtil;
import com.ruoyi.gds.annotation.IncludeField;
import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.enums.PassengerType;
import com.ruoyi.gds.enums.ibe.SearchPriceCallerType;
import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.gds.module.dto.FlightNumberCabinDto;
import com.ruoyi.gds.module.dto.FlightNumberPassengerBaggageDto;
import com.ruoyi.gds.module.dto.PassengerBaggageDto;
import com.ruoyi.gds.module.dto.galileo.SegementDto;
import com.ruoyi.gds.module.dto.validation.AIR;
import com.ruoyi.gds.module.dto.validation.AIRBatchSearciPrice;
import com.ruoyi.gds.module.dto.validation.Galelio;
import com.ruoyi.gds.module.dto.validation.IBE;
import com.ruoyi.gds.utils.StrUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.assertj.core.util.Lists;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.*;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchPriceReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 批次号
     */
    @NotBlank(message = "批次号为空", groups = {AIRBatchSearciPrice.class})
    private String batchCode;

    /**
     * 行程Key。 flightKey & flightFareKey 为 providerCode、currencyCode、segements 赋值
     */
    @NotBlank(message = "行程Key为空", groups = {AIR.class, AIRBatchSearciPrice.class})
    private String flightKey;

    /**
     * 行程方案报价Key。 flightKey & flightFareKey 为 providerCode、currencyCode、segements 赋值
     */
    @NotBlank(message = "行程方案报价Key为空", groups = {AIR.class, AIRBatchSearciPrice.class})
    private String flightFareKey;




    /**
     * GDS类型。前端未传值时，根据 flightKey & flightFareKey 未此字段设置值
     */
    @IncludeField
    @NotNull(message = "GDS类型为空", groups = {Galelio.class, IBE.class})
    private GDSType providerCode;

    /**
     * 币种。前端未传值时，根据 flightKey & flightFareKey 未此字段设置值
     */
    @NotBlank(message = "币种为空", groups = {Galelio.class, IBE.class})
    private String currencyCode;

    /**
     * 航班信息。前端未传值时，根据 flightKey & flightFareKey 未此字段设置值
     */
    @IncludeField
    @Valid
    @NotEmpty(message = "航班信息为空", groups = {Galelio.class, IBE.class})
    private List<SegementDto> segements;

    /**
     * 乘客信息
     */
    @IncludeField
    @NotEmpty(message = "乘客信息为空", groups = {Galelio.class, IBE.class, AIR.class})
    private List<PassengerType> passengers;

//    /**
//     * 是否按指定舱位搜索。默认：false
//     */
//    private Boolean specifyCabin;

//    /**
//     * IBE查价方式。默认：C9
//     */
//    private SearchPriceType searchPriceType;

//    /**
//     * 是否查询大客户报价。默认false
//     */
//    private Boolean accountPrice;

    /**
     * 大客户编码
     */
    private String accountCode;

    /**
     * 预约号
     */
    private String pnr;

    /**
     * 非必传。用于标记调用方
     */
    private SearchPriceCallerType caller;

    /**
     * 指定航班舱位号
     */
    @IncludeField
    private List<@Valid FlightNumberCabinDto> cabins;

    /**
     * 指定各类乘机人行李额（与报价的最低行李额作对比）
     */
    private List<@Valid PassengerBaggageDto> passengerBaggages;

    /**
     * 指定各类乘机人行李额（与报价的各航段行李额作对比）
     */
    private List<@Valid FlightNumberPassengerBaggageDto> flightNumberPassengerBaggages;

    /**
     * 是否使用 承运方(主飞) 航班查询。默认：false
     */
    private Boolean useOperating;

    /**
     * 查询指定GDS的报价
     */
    private List<GDSType> priceGdss;


//    public Boolean getSpecifyCabin() {
//        if (Objects.nonNull(specifyCabin)) return specifyCabin;
//        return CollectionUtil.isNotEmpty(cabins);
//    }

    /*public SearchPriceType getSearchPriceType() {
        return Optional.ofNullable(searchPriceType).orElse(SearchPriceType.C9);
    }*/

//    public Boolean getAccountPrice() {
//        return Optional.ofNullable(accountPrice).orElse(false);
//    }

    public List<SegementDto> getSegements() {
        return Optional.ofNullable(segements)
                .map(segementDtos -> segementDtos.stream().peek(segementDto -> {
                    segementDto.setSeq(segements.indexOf(segementDto) + 1);
                    segementDto.setProviderCode(providerCode);
                }).collect(Collectors.toList()))
                .orElse(Lists.newArrayList());
    }

    public SearchPriceCallerType getCaller() {
        return Optional.ofNullable(caller).orElse(SearchPriceCallerType.SYSTEM);
    }

    public Boolean getUseOperating() {
        return Optional.ofNullable(useOperating).orElse(false);
    }

    public void check() {
        check(providerCode);
    }

    public void check(GDSType gdsType) {
        String errMsg = ValidatorUtil.validate(this, gdsType.getCheckGroup());
        if (StringUtils.isNotBlank(errMsg)) {
            throw new InvalidParamException(errMsg);
        }
    }

    public void checkAndSetCabin() {
        Map<String, String> fligntNumberCabinsMap = Optional.ofNullable(getCabins())
                .map(cabins -> cabins.stream().collect(Collectors.groupingBy(o -> o.getCarrier() + o.getFlightNo())))
                .map(map -> map.entrySet().stream().collect(
                        Collectors.toMap(Map.Entry::getKey,
                                entry -> entry.getValue().stream().map(FlightNumberCabinDto::getCabin).collect(Collectors.joining(","))
                        )))
                .orElse(new HashMap<>());

        if (CollectionUtil.isEmpty(fligntNumberCabinsMap)) return;

        String noCabinFlightNumbers = getSegements().stream()
                .filter(segementDto -> {
                    String flightNumber = Objects.nonNull(getUseOperating()) && getUseOperating()
                            ? segementDto.getOperatingCarrier() + StrUtil.parseInt(segementDto.getOperatingFlightNumber())
                            : segementDto.getCarrier() + StrUtil.parseInt(segementDto.getFlightNumber());
                    String cabins = fligntNumberCabinsMap.get(flightNumber);
                    return StringUtils.isBlank(cabins);
                })
                .map(segementDto -> segementDto.getCarrier() + StrUtil.parseInt(segementDto.getFlightNumber()))
                .collect(Collectors.joining(","));
        if (StringUtils.isNotBlank(noCabinFlightNumbers)) {
            throw new ServiceException("未指定[" + noCabinFlightNumbers + "]舱位号", HttpStatus.BAD_REQUEST);
        }

        for (SegementDto segementDto : getSegements()) {
            String flightNumber = Objects.nonNull(getUseOperating()) && getUseOperating()
                    ? segementDto.getOperatingCarrier() + StrUtil.parseInt(segementDto.getOperatingFlightNumber())
                    : segementDto.getCarrier() + StrUtil.parseInt(segementDto.getFlightNumber());
            segementDto.setClassOfService(fligntNumberCabinsMap.get(flightNumber));
        }
    }

}
