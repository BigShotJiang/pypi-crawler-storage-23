package com.ruoyi.gds.interceptor;

import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.UUIDUtil;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.module.vo.RequestContextVo;
import com.ruoyi.gds.utils.ContextUtil;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Component
public class UserInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        String userId = request.getHeader(CommonConstant.HEADER_USER_ID);
        if (StringUtils.isBlank(userId)) {
            String msg = StringUtils.format("[GDS认证] 请求访问：{}，认证失败，无法访问系统资源", request.getRequestURI());
            throw new ServiceException(msg, HttpStatus.UNAUTHORIZED.value());
            /*response.setStatus(HttpStatus.UNAUTHORIZED.value());
            return false;*/
        }

        RequestContextVo contextVo = buildContext(Long.valueOf(userId));
        ContextUtil.setContext(contextVo);

        return true;
    }

    @Override
    public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
        ContextUtil.clear();
    }

    private RequestContextVo buildContext(Long userId) {
        return RequestContextVo.builder()
                .userId(userId)
                .traceId(UUIDUtil.getUUID())
                .build();
    }

}
