package com.ruoyi.gds.module;

import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.ValidatorUtil;
import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.enums.GalileoIssueType;
import com.ruoyi.gds.enums.ibe.IBEIssueType;
import com.ruoyi.gds.enums.sabre.SabreIssueType;
import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.gds.module.dto.FlightNumberPassengerBaggageDto;
import com.ruoyi.gds.module.dto.PassengerBaggageDto;
import com.ruoyi.gds.module.vo.CreditCardVo;
import com.ruoyi.gds.module.vo.Passenger;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IssueTicketReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * GDS类型
     */
    @NotNull(message = "GDS为空")
    private GDSType gds;

    /**
     * PNR
     */
    @NotBlank(message = "PNR为空")
    private String pnr;

    /**
     * 币种
     */
    private String currencyCode;

    /**
     * 出票总价
     */
    private BigDecimal issueAmount;

    /**
     * 前返
     */
    private BigDecimal commission;

    /**
     * IBE 订单号。出票时，本GDS预订的可不传，否则必传
     */
    private String orderNo;

    /**
     * IBE出票方式。默认：BOP
     */
    private IBEIssueType ibeIssueType;

    /**
     * 伽利略出票方式。默认：Cash
     */
    private GalileoIssueType galileoIssueType;

    /**
     * 塞班出票方式。默认：Cash
     */
    private SabreIssueType sabreIssueType;

    /**
     * 信用卡信息。伽利略
     */
    private CreditCardVo creditCard;

//    /**
//     * 是否查询大客户报价。伽利略。默认：true（票务默认true）
//     */
//    private Boolean accountPrice;

    /**
     * 大客户编码
     */
    private String accountCode;

    /**
     * TC编码
     */
    private String tourCode;

    /**
     * 乘机人行李额
     */
    private List<@Valid PassengerBaggageDto> passengerBaggages;

    /**
     * 乘机人各航段行李额
     */
    private List<@Valid FlightNumberPassengerBaggageDto> flightNumberPassengerBaggages;


    /**--------8000YI------------*/
    /**
     * 导入编码后返回的唯一标识
     * 必填
     */
    private String  rawId;
    /**
     * 从政策列表中选择其中一个政策的ID
     * 必填
     */
    private String policyId;

    /**
     * 选中的政策校验码(为避免与报文校验码sign混淆，原该参数名为sign, 现已修改为policySign)
     * 必填
     */
    private String policySign;

    /**
     * 订单联系人
     * 必填
     */
    private String contacter;
    /**
     * 联系人手机
     * 必填
     */
    private String mobile;

    /**
     * 订单联系人邮箱
     * 非必填
     */
    private String mail;


    /**
     * 支付方式，1：支付宝，2：财付通。目前暂不支持，3：钱包
     * 必填
     */
    private String payWay="3";

    /**
     * 支付类别，1：跳转链接支付， 2：无密接口支付, 立即绑定无密支付（钱包无需绑定）
     * 必填
     */
    private String payType="2";
    /**--------8000YI------------*/

    /**
     * 工单号
     */
    private String workOrderSerialNum;

    private String orderId;

    private List<Passenger> passengerList;


    public IBEIssueType getIbeIssueType() {
        return Optional.ofNullable(ibeIssueType).orElse(IBEIssueType.BSP);
    }

    public GalileoIssueType getGalileoIssueType() {
        return Optional.ofNullable(galileoIssueType).orElse(GalileoIssueType.Cash);
    }

    public SabreIssueType getSabreIssueType() {
        return Optional.ofNullable(sabreIssueType).orElse(SabreIssueType.Cash);
    }

//    public Boolean getAccountPrice() {
//        return Optional.ofNullable(accountPrice).orElse(Boolean.TRUE);
//    }

    public void check(Class<?> clazz) {
        String errMsg = ValidatorUtil.validate(this, clazz);
        if (StringUtils.isNotBlank(errMsg)) {
            throw new InvalidParamException(errMsg);
        }
    }

}
