package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.gds.module.domain.FczAirchangeCustomPnr;
import com.ruoyi.gds.service.IFczAirchangeCustomPnrService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 飞常准—航变定制与PNR关联Controller
 * 
 * @author ruoyi
 * @date 2025-11-21
 */
@RestController
@RequestMapping("/airChange/fcz/custom/pnr")
public class FczAirchangeCustomPnrController extends BaseController
{
    @Autowired
    private IFczAirchangeCustomPnrService fczAirchangeCustomPnrService;

    /**
     * 查询飞常准—航变定制与PNR关联列表
     */
    @PreAuthorize("@ss.hasPermi('system:pnr:list')")
    @GetMapping("/list")
    public TableDataInfo list(FczAirchangeCustomPnr fczAirchangeCustomPnr)
    {
        startPage();
        List<FczAirchangeCustomPnr> list = fczAirchangeCustomPnrService.selectFczAirchangeCustomPnrList(fczAirchangeCustomPnr);
        return getDataTable(list);
    }

    /**
     * 导出飞常准—航变定制与PNR关联列表
     */
    @PreAuthorize("@ss.hasPermi('system:pnr:export')")
    @Log(title = "飞常准—航变定制与PNR关联", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FczAirchangeCustomPnr fczAirchangeCustomPnr)
    {
        List<FczAirchangeCustomPnr> list = fczAirchangeCustomPnrService.selectFczAirchangeCustomPnrList(fczAirchangeCustomPnr);
        ExcelUtil<FczAirchangeCustomPnr> util = new ExcelUtil<FczAirchangeCustomPnr>(FczAirchangeCustomPnr.class);
        util.exportExcel(response, list, "飞常准—航变定制与PNR关联数据");
    }

    /**
     * 获取飞常准—航变定制与PNR关联详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:pnr:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(fczAirchangeCustomPnrService.selectFczAirchangeCustomPnrById(id));
    }

    /**
     * 新增飞常准—航变定制与PNR关联
     */
    @PreAuthorize("@ss.hasPermi('system:pnr:add')")
    @Log(title = "飞常准—航变定制与PNR关联", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FczAirchangeCustomPnr fczAirchangeCustomPnr)
    {
        return toAjax(fczAirchangeCustomPnrService.insertFczAirchangeCustomPnr(fczAirchangeCustomPnr));
    }

    /**
     * 修改飞常准—航变定制与PNR关联
     */
    @PreAuthorize("@ss.hasPermi('system:pnr:edit')")
    @Log(title = "飞常准—航变定制与PNR关联", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FczAirchangeCustomPnr fczAirchangeCustomPnr)
    {
        return toAjax(fczAirchangeCustomPnrService.updateFczAirchangeCustomPnr(fczAirchangeCustomPnr));
    }

    /**
     * 删除飞常准—航变定制与PNR关联
     */
    @PreAuthorize("@ss.hasPermi('system:pnr:remove')")
    @Log(title = "飞常准—航变定制与PNR关联", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(fczAirchangeCustomPnrService.deleteFczAirchangeCustomPnrByIds(ids));
    }

    /**
     * 解绑飞常准定制与票ID的关联关系
     */
    @GetMapping("/unbind")
    public AjaxResult unbind(@RequestParam Long ticketId)
    {
        return toAjax(fczAirchangeCustomPnrService.unbind(ticketId));
    }

}
