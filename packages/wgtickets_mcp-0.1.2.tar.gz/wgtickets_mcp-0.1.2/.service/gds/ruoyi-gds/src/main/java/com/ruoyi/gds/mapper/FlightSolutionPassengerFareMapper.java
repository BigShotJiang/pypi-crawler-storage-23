package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightSolutionPassengerFare;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 各类乘机人报价Mapper接口
 *
 * @author ruoyi
 * @date 2025-09-24
 */
public interface FlightSolutionPassengerFareMapper extends BaseMapper<FlightSolutionPassengerFare> {
    /**
     * 查询各类乘机人报价
     *
     * @param id 各类乘机人报价主键
     * @return 各类乘机人报价
     */
    public FlightSolutionPassengerFare selectFlightSolutionPassengerFareById(Long id);

    /**
     * 查询各类乘机人报价列表
     *
     * @param flightSolutionPassengerFare 各类乘机人报价
     * @return 各类乘机人报价集合
     */
    public List<FlightSolutionPassengerFare> selectFlightSolutionPassengerFareList(FlightSolutionPassengerFare flightSolutionPassengerFare);

    /**
     * 新增各类乘机人报价
     *
     * @param flightSolutionPassengerFare 各类乘机人报价
     * @return 结果
     */
    public int insertFlightSolutionPassengerFare(FlightSolutionPassengerFare flightSolutionPassengerFare);

    /**
     * 修改各类乘机人报价
     *
     * @param flightSolutionPassengerFare 各类乘机人报价
     * @return 结果
     */
    public int updateFlightSolutionPassengerFare(FlightSolutionPassengerFare flightSolutionPassengerFare);

    /**
     * 删除各类乘机人报价
     *
     * @param id 各类乘机人报价主键
     * @return 结果
     */
    public int deleteFlightSolutionPassengerFareById(Long id);

    /**
     * 批量删除各类乘机人报价
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightSolutionPassengerFareByIds(Long[] ids);

    /**
     * 批量写入，重复时跳过
     * @param flightSolutionPassengerFares
     * @return
     */
    int batchInsert(@Param("flightSolutionPassengerFares") List<FlightSolutionPassengerFare> flightSolutionPassengerFares);

    /**
     * 批量更新
     * @param flightSolutionPassengerFares
     * @return
     */
    int batchUpdate(@Param("flightSolutionPassengerFares") List<FlightSolutionPassengerFare> flightSolutionPassengerFares);

}
