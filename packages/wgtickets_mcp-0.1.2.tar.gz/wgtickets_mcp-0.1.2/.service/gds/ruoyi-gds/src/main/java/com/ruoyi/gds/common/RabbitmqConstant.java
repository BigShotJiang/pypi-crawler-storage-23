package com.ruoyi.gds.common;

public class RabbitmqConstant {

    public static final String DEFAUL_EXCHANGE = "default_direct_exchange";

    public static final String TICKET_AIR_CHANGE_QUERY_PNR_REQ_ROUTING = "ticket.airchange.querypnr.req";

    public static final String TICKET_AIR_CHANGE_QUERY_PNR_REQ_QUEUE = "ticket_airchange_querypnr_req";

    public static final String TICKET_AIR_CHANGE_FCZ_REQ_ROUTING = "ticket.airchange.fcz.req";

    public static final String TICKET_AIR_CHANGE_FCZ_REQ_QUEUE = "ticket_airchange_fcz_req";

    public static final String TICKET_AIR_CHANGE_QUERY_PNR_RSP_ROUTING = "ticket.airchange.querypnr.rsp";

    public static final String TICKET_AIR_CHANGE_QUERY_PNR_RSP_QUEUE = "ticket_airchange_querypnr_rsp";

    public static final String TICKET_FIRST_CABIN_SCAN_REQ_ROUTING = "ticket.cabinscan.first.req";

    public static final String TICKET_FIRST_CABIN_SCAN_REQ_QUEUE = "ticket_cabinscan_first_req";

    public static final String TICKET_FIRST_CABIN_SCAN_RSP_ROUTING = "ticket.cabinscan.first.rsp";

    public static final String TICKET_FIRST_CABIN_SCAN_RSP_QUEUE = "ticket_cabinscan_first_rsp";

    public static final String OTA_CABIN_SCAN_REQ_ROUTING = "ota.cabinscan.req";

    public static final String OTA_CABIN_SCAN_REQ_QUEUE = "ota_cabinscan_req";

    public static final String OTA_CABIN_SCAN_RSP_ROUTING = "ota.cabinscan.rsp";

    public static final String OTA_CABIN_SCAN_RSP_QUEUE = "ota_cabinscan_rsp";

    public static final String GDS_REFRESH_SOLUTIONFARE_IBE_ROUTING = "gds.refresh.solutionfare.ibe";

    public static final String GDS_REFRESH_SOLUTIONFARE_IBE_QUEUE = "gds_refresh_solutionfare_ibe";

    public static final String GDS_REFRESH_SOLUTIONFARE_NOTIBE_ROUTING = "gds.refresh.solutionfare.notibe";

    public static final String GDS_REFRESH_SOLUTIONFARE_NOTIBE_QUEUE = "gds_refresh_solutionfare_notibe";

}
