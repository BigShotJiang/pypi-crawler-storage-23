package com.ruoyi.gds.module.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CabinScanSegementDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 行程编号
     */
    @NotNull(message = "行程编号为空")
    private Integer group;

    /**
     * 航司二字码（市场方）
     */
    @NotBlank(message = "市场方航司二字码为空")
    private String carrier;

    /**
     * 航班号（市场方）
     */
    @NotBlank(message = "市场方航班号为空")
    private String flightNumber;

    /**
     * 航司二字码（承运方）
     */
    @NotBlank(message = "承运方航司二字码为空")
    private String operatingCarrier;

    /**
     * 航班号（承运方）
     */
    @NotBlank(message = "承运方航班号为空")
    private String operatingFlightNumber;

    /**
     * 出发地
     */
    @NotBlank(message = "出发地为空")
    private String origin;

    /**
     * 目的地
     */
    @NotBlank(message = "目的地为空")
    private String destination;

    /**
     * 出发时间
     */
    @NotBlank(message = "出发时间为空")
    private String departureTime;

    /**
     * 到达时间
     */
    @NotBlank(message = "到达时间为空")
    private String arrivalTime;

}
