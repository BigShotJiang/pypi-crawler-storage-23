package com.ruoyi.gds.enums.sabre;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.enums.CabinCategoryType;
import com.ruoyi.gds.utils.StrUtil;
import lombok.Getter;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * 舱位等级 / 服务等级
 */
@Getter
public enum SabreCabinType {

    Y(1,"Y", CabinCategoryType.ECONOMY,"经济舱"),
    S(2,"S", CabinCategoryType.PREMIUM_ECONOMY,"高级经济舱"),
    C(3,"C", CabinCategoryType.BUSINESS, "商务舱"),
    D(4,"J", CabinCategoryType.BUSINESS, "高级商务舱"),
    F(5,"F", CabinCategoryType.FIRST, "头等舱"),
    P(6,"P", CabinCategoryType.FIRST, "高级头等舱");

    private final int num;

    @JsonValue
    private final String code;

    private final CabinCategoryType category;

    private final String desc;

    SabreCabinType(int num, String code, CabinCategoryType category, String desc) {
        this.num = num;
        this.code = code;
        this.category = category;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static SabreCabinType fromCode(String code) {
        return Arrays.stream(SabreCabinType.values())
                .filter(item -> StringUtils.isNotBlank(code) && StrUtil.removeWhiteSpaces(code).equalsIgnoreCase(StrUtil.removeWhiteSpaces(item.code)))
                .findFirst()
                .orElse(null);
    }

    public static SabreCabinType getLowstByCabinCategory(CabinCategoryType cabinCategory) {
        return Arrays.stream(SabreCabinType.values())
                .filter(item -> Objects.nonNull(cabinCategory) && cabinCategory == item.category)
                .min(Comparator.comparingInt(SabreCabinType::getNum))
                .orElse(null);
    }

    public static List<SabreCabinType> getByCabinCategory(CabinCategoryType cabinCategory) {
        return Arrays.stream(SabreCabinType.values())
                .filter(item -> Objects.nonNull(cabinCategory) && cabinCategory == item.category)
                .collect(Collectors.toList());
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
