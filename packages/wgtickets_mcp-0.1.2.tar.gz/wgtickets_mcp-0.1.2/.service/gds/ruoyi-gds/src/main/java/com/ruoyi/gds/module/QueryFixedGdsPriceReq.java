package com.ruoyi.gds.module;

import com.ruoyi.common.enums.SystemType;
import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.module.dto.FlightNumberPassengerBaggageDto;
import com.ruoyi.gds.module.dto.PassengerBaggageDto;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class QueryFixedGdsPriceReq extends QueryPnrInfoReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 查价GDS
     */
    private List<GDSType> gdss;

    /**
     * 客户端系统
     */
    @NotNull(message = "客户端系统为空")
    private SystemType systemType;

    /**
     * 乘机人行李额
     */
    private List<@Valid PassengerBaggageDto> passengerBaggages;

    /**
     * 乘机人各航段行李额
     */
    private List<@Valid FlightNumberPassengerBaggageDto> flightNumberPassengerBaggages;


    @Override
    public String toString() {
        return JacksonUtil.toJsonString(this);
    }

}
