package com.ruoyi.gds.annotation;

import com.ruoyi.gds.enums.FlightReqType;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface FlightLog {

    FlightReqType type();

}
