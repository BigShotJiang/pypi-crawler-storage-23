package com.ruoyi.gds.controller;

import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.gds.service.DicService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@Anonymous
@RestController
@RequestMapping("/dic")
public class DicController {

    @Autowired
    private DicService dicService;

    /**
     * 获取字典值
     * @param type
     * @param label
     * @return
     */
    @GetMapping(value = "/dicValue")
    public AjaxResult searchFlight(@RequestParam String type, @RequestParam String label) {
        String dictValue = dicService.getDictValue(type, label);
        return AjaxResult.success(null, dictValue);
    }

}
