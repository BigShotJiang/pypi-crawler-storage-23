package com.ruoyi.gds.module.dto.galileo;

import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.common.utils.ValidatorUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GalileoIssueTicketPassengerDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 乘机人类型
     */
    @NotNull(message = "乘机人类型为空")
    private String passengerType;

    /**
     * 乘机人Key
     */
    @NotBlank(message = "乘机人Key为空")
    private String key;


    public void check() {
        String errMsg = ValidatorUtil.validate(this);
        if (StringUtils.isNotBlank(errMsg)) {
            throw new InvalidParamException(errMsg);
        }
    }

}
