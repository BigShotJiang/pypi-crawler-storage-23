package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FczAirchangeCustom;

import java.util.List;

/**
 * 飞常准—定制航变通知记录Mapper接口
 * 
 * @author ruoyi
 * @date 2025-11-18
 */
public interface FczAirchangeCustomMapper extends BaseMapper<FczAirchangeCustom>
{
    /**
     * 查询飞常准—定制航变通知记录
     * 
     * @param id 飞常准—定制航变通知记录主键
     * @return 飞常准—定制航变通知记录
     */
    public FczAirchangeCustom selectFczAirchangeCustomById(Long id);

    /**
     * 查询飞常准—定制航变通知记录列表
     * 
     * @param fczAirchangeCustom 飞常准—定制航变通知记录
     * @return 飞常准—定制航变通知记录集合
     */
    public List<FczAirchangeCustom> selectFczAirchangeCustomList(FczAirchangeCustom fczAirchangeCustom);

    /**
     * 新增飞常准—定制航变通知记录
     * 
     * @param fczAirchangeCustom 飞常准—定制航变通知记录
     * @return 结果
     */
    public int insertFczAirchangeCustom(FczAirchangeCustom fczAirchangeCustom);

    /**
     * 修改飞常准—定制航变通知记录
     * 
     * @param fczAirchangeCustom 飞常准—定制航变通知记录
     * @return 结果
     */
    public int updateFczAirchangeCustom(FczAirchangeCustom fczAirchangeCustom);

    /**
     * 删除飞常准—定制航变通知记录
     * 
     * @param id 飞常准—定制航变通知记录主键
     * @return 结果
     */
    public int deleteFczAirchangeCustomById(Long id);

    /**
     * 批量删除飞常准—定制航变通知记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFczAirchangeCustomByIds(Long[] ids);
}
