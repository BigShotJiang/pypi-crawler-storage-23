package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightReservationTraveler;

import java.util.List;

/**
 * 航班预定关联乘机人Mapper接口
 * 
 * @author ruoyi
 * @date 2025-04-18
 */
public interface FlightReservationTravelerMapper extends BaseMapper<FlightReservationTraveler>
{
    /**
     * 查询航班预定关联乘机人
     * 
     * @param id 航班预定关联乘机人主键
     * @return 航班预定关联乘机人
     */
    public FlightReservationTraveler selectFlightReservationTravelerById(Long id);

    /**
     * 查询航班预定关联乘机人列表
     * 
     * @param flightReservationTraveler 航班预定关联乘机人
     * @return 航班预定关联乘机人集合
     */
    public List<FlightReservationTraveler> selectFlightReservationTravelerList(FlightReservationTraveler flightReservationTraveler);

    /**
     * 新增航班预定关联乘机人
     * 
     * @param flightReservationTraveler 航班预定关联乘机人
     * @return 结果
     */
    public int insertFlightReservationTraveler(FlightReservationTraveler flightReservationTraveler);

    /**
     * 修改航班预定关联乘机人
     * 
     * @param flightReservationTraveler 航班预定关联乘机人
     * @return 结果
     */
    public int updateFlightReservationTraveler(FlightReservationTraveler flightReservationTraveler);

    /**
     * 删除航班预定关联乘机人
     * 
     * @param id 航班预定关联乘机人主键
     * @return 结果
     */
    public int deleteFlightReservationTravelerById(Long id);

    /**
     * 批量删除航班预定关联乘机人
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightReservationTravelerByIds(Long[] ids);
}
