package com.ruoyi.gds.module;

import com.ruoyi.gds.enums.GDSType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.hibernate.validator.constraints.Length;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class QueryPnrInfoReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PNR所属GDS
     */
    private GDSType gds;

    @Length(min = 6, max = 6, message = "PNR仅限6位字符")
    private String pnr;

    /**
     * rt信息
     */
    private String rt;

}
