package com.ruoyi.gds.module.dto;

import com.ruoyi.gds.annotation.IncludeField;
import com.ruoyi.gds.module.dto.galileo.SegementDto;
import com.ruoyi.gds.utils.StrUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.assertj.core.util.Lists;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightNumberCabinDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 航班号。eg：CA910
     */
    @IncludeField
    @NotBlank(message = "航班号为空")
    private String flightNumber;

    /**
     * 舱位号。eg：Y
     */
    @IncludeField
    @NotBlank(message = "舱位号为空")
    private String cabin;

    public String getCarrier() {
        return Optional.ofNullable(flightNumber).map(s -> s.substring(0, 2)).map(String::trim).orElse("");
    }

    public Integer getFlightNo() {
        return Optional.ofNullable(flightNumber).map(s -> s.substring(2)).map(String::trim).map(StrUtil::parseInt).orElse(0);
    }

    public static List<FlightNumberCabinDto> buildBySegementDtos(List<SegementDto> segementDtos) {
        return Optional.ofNullable(segementDtos)
                .map(segementDtoList -> segementDtoList.stream().map(segementDto ->
                                FlightNumberCabinDto.builder()
                                        .flightNumber(segementDto.getCarrier() + StrUtil.parseInt(segementDto.getFlightNumber()))
                                        .cabin(segementDto.getClassOfService())
                                        .build())
                        .collect(Collectors.toList()))
                .orElse(Lists.newArrayList());
    }

}
