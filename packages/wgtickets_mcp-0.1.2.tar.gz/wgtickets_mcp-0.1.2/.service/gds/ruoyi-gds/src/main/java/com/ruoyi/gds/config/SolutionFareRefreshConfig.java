package com.ruoyi.gds.config;

import com.ruoyi.gds.enums.TimeUnitType;
import lombok.Data;
import org.assertj.core.util.Lists;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@ConfigurationProperties(prefix = "solution")
@Data
public class SolutionFareRefreshConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    private Integer fareExpire;

    private List<RefreshRule> refreshRules;

    @Data
    public static class RefreshRule implements Serializable {

        private int score;

        private int frequency;

        private TimeUnitType timeUnit;

    }

    public RefreshRule match(int score) {
        List<RefreshRule> rules = Optional.ofNullable(getRefreshRules())
                .map(refreshRuleList -> refreshRuleList.stream().sorted((o1, o2) -> o2.getScore() - o1.getScore()).collect(Collectors.toList()))
                .orElse(Lists.newArrayList());

        for (RefreshRule refreshRule : rules) {
            if (score >= refreshRule.getScore()) return refreshRule;
        }

        return null;
    }
}
