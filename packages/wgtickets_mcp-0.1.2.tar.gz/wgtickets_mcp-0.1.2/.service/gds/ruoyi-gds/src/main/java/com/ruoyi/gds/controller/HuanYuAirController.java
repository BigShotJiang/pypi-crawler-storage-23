package com.ruoyi.gds.controller;

import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.gds.module.vo.eightyi.*;
import com.ruoyi.gds.service.HuanYuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@Anonymous
@RestController
@RequestMapping("/air/huanYu")
public class HuanYuAirController {

    @Autowired
    private HuanYuService huanYuService;

    /**
     * 订单完成接口
     *
     * @return
     */
    @PostMapping("/completeOrder")
    public AjaxResult completeOrder(@RequestBody String json) {
        return AjaxResult.success(huanYuService.completeOrder(json));
    }

    /**
     * 出票失败回调
     */
    @GetMapping("/issueTicketFail")
    public AjaxResult issueTicketFail(@RequestBody String json) {
        huanYuService.issueTicketFail(json);
        return AjaxResult.success();
    }
}
