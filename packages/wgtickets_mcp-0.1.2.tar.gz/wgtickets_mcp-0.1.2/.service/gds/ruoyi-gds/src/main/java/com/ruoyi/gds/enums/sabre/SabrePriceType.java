package com.ruoyi.gds.enums.sabre;

public enum SabrePriceType {

    L,  // 最低舱位价格

    M,  // 指定舱位价格

    B   // 两者最低价
}
