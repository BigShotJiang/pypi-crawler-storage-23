package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.utils.StrUtil;
import lombok.Getter;

import java.util.Arrays;

/**
 * 票航段状态
 */
@Getter
public enum GalileoTicketSegmentStatus {

    OPEN("O", TicketSegmentStatus.OPEN,"正常"),
    VOID("V", TicketSegmentStatus.VOID, "已废票"),
    CKIN("C", TicketSegmentStatus.OPEN, "已值机"),
    ARPT("A", TicketSegmentStatus.OPEN, "机场控制"),
    LFTD("L", TicketSegmentStatus.OPEN, "飞行中"),
    USED("F", TicketSegmentStatus.USED, "已使用"),
    EXCHANGED("E", TicketSegmentStatus.EXCHANGED, "已改签"),
    REFUNDED("R", TicketSegmentStatus.REFUNDED, "已退票");

    private final String code;

    @JsonValue
    private final TicketSegmentStatus ticketSegmentStatus;

    private final String desc;

    GalileoTicketSegmentStatus(String code, TicketSegmentStatus ticketSegmentStatus, String desc) {
        this.code = code;
        this.ticketSegmentStatus = ticketSegmentStatus;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static GalileoTicketSegmentStatus fromCode(String code) {
        if (StringUtils.isBlank(code)) return null;
        return Arrays.stream(GalileoTicketSegmentStatus.values())
                .filter(item -> StringUtils.isNotBlank(code) && StrUtil.removeWhiteSpaces(code).equalsIgnoreCase(StrUtil.removeWhiteSpaces(item.code)))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
