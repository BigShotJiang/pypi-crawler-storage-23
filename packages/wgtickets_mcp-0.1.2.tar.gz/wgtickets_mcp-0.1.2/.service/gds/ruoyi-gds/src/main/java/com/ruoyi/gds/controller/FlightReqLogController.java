package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.gds.module.domain.FlightReqLog;
import com.ruoyi.gds.module.dto.FlightReqLogSearchDto;
import com.ruoyi.gds.module.vo.FlightReqLogStatistic;
import com.ruoyi.gds.service.IFlightReqLogService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 机票预定使用记录Controller
 * 
 * @author ruoyi
 * @date 2025-05-19
 */
@RestController
@RequestMapping("/flight/log")
public class FlightReqLogController extends BaseController
{
    @Autowired
    private IFlightReqLogService flightReqLogService;

    /**
     * 查询机票预定使用记录列表
     */
    @PreAuthorize("@ss.hasPermi('system:log:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightReqLog flightReqLog)
    {
        startPage();
        List<FlightReqLog> list = flightReqLogService.selectFlightReqLogList(flightReqLog);
        return getDataTable(list);
    }

    /**
     * 导出机票预定使用记录列表
     */
    @PreAuthorize("@ss.hasPermi('system:log:export')")
    @Log(title = "机票预定使用记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightReqLog flightReqLog)
    {
        List<FlightReqLog> list = flightReqLogService.selectFlightReqLogList(flightReqLog);
        ExcelUtil<FlightReqLog> util = new ExcelUtil<FlightReqLog>(FlightReqLog.class);
        util.exportExcel(response, list, "机票预定使用记录数据");
    }

    /**
     * 获取机票预定使用记录详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:log:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(flightReqLogService.selectFlightReqLogById(id));
    }

    /**
     * 新增机票预定使用记录
     */
    @PreAuthorize("@ss.hasPermi('system:log:add')")
    @Log(title = "机票预定使用记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightReqLog flightReqLog)
    {
        return toAjax(flightReqLogService.insertFlightReqLog(flightReqLog));
    }

    /**
     * 修改机票预定使用记录
     */
    @PreAuthorize("@ss.hasPermi('system:log:edit')")
    @Log(title = "机票预定使用记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightReqLog flightReqLog)
    {
        return toAjax(flightReqLogService.updateFlightReqLog(flightReqLog));
    }

    /**
     * 删除机票预定使用记录
     */
    @PreAuthorize("@ss.hasPermi('system:log:remove')")
    @Log(title = "机票预定使用记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(flightReqLogService.deleteFlightReqLogByIds(ids));
    }

    /**
     * 导出操作记录统计数据
     */
    @PostMapping("/statisticExport")
    public void statisticExport(HttpServletResponse response, @RequestBody FlightReqLogSearchDto searchDto)
    {
        List<FlightReqLogStatistic> list = flightReqLogService.statistic(searchDto);
        ExcelUtil<FlightReqLogStatistic> util = new ExcelUtil<>(FlightReqLogStatistic.class);
        util.exportExcel(response, list, "机票预定操作统计");
    }

    /**
     * 查询操作记录统计数据
     */
    @PostMapping("/statistic")
    public AjaxResult statistic(@RequestBody FlightReqLogSearchDto searchDto)
    {
        List<FlightReqLogStatistic> list = flightReqLogService.statistic(searchDto);
        return AjaxResult.success(list);
    }

}
