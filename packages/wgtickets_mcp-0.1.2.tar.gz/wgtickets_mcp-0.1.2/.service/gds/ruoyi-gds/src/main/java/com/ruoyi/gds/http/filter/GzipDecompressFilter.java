package com.ruoyi.gds.http.filter;

import com.ruoyi.gds.http.wrapper.GzipDecompressRequestWrapper;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;

public class GzipDecompressFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;

        // 检查是否需要包装，只对 POST, PUT 等有请求体的方法进行处理
        // 并且只在 Content-Encoding 头部存在时才考虑
        String method = httpRequest.getMethod();
        String contentEncoding = httpRequest.getHeader("Content-Encoding");

        if (("POST".equalsIgnoreCase(method) || "PUT".equalsIgnoreCase(method) || "PATCH".equalsIgnoreCase(method))
                && contentEncoding != null && contentEncoding.toLowerCase().contains("gzip")) {
            try {
                // 创建并应用 Wrapper
                GzipDecompressRequestWrapper wrappedRequest = new GzipDecompressRequestWrapper(httpRequest);
                chain.doFilter(wrappedRequest, response);
            } catch (IOException e) {
                // 处理解压失败的错误，例如返回一个 Bad Request (400) 响应
                // response.setContentType("text/plain");
                // ((HttpServletResponse) response).setStatus(HttpServletResponse.SC_BAD_REQUEST);
                // response.getWriter().write("Failed to decompress request body: " + e.getMessage());
                // 或者直接抛出异常让 Spring 的异常处理器处理
                throw new ServletException("Failed to process gzipped request", e);
            }

        } else {
            // 对于不需要解压的请求，直接放行
            chain.doFilter(request, response);
        }
    }

    // 实现 init 和 destroy 方法 (通常无需特殊处理)
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization logic if needed
    }

    @Override
    public void destroy() {
        // Cleanup logic if needed
    }

}
