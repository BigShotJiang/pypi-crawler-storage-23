package com.ruoyi.gds.controller;

import cn.hutool.core.collection.CollectionUtil;
import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.ServletUtils;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.enums.BusinessScene;
import com.ruoyi.gds.enums.TripType;
import com.ruoyi.gds.module.domain.FlightReservation;
import com.ruoyi.gds.module.vo.FlightReservationPageBaseVo;
import com.ruoyi.gds.module.vo.FlightReservationPageVo;
import com.ruoyi.gds.service.IFlightReservationService;
import com.ruoyi.gds.utils.ContextUtil;
import com.ruoyi.gds.utils.IntConvertUtil;
import org.assertj.core.util.Lists;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * 航班预定Controller
 *
 * @author ruoyi
 * @date 2025-04-17
 */
@Anonymous
@RestController
@RequestMapping("/flight/reservation")
public class FlightReservationController extends BaseController {
    @Autowired
    private IFlightReservationService flightReservationService;

    /**
     * 查询航班预定列表
     */
    /*@GetMapping("/list")
    public TableDataInfo list(FlightReservation flightReservation) {
        if (Objects.nonNull(flightReservation.getTripType()) && Objects.isNull(TripType.fromCode(flightReservation.getTripType()))) {
            throw new ServiceException("行程类型错误", HttpStatus.BAD_REQUEST);
        }

        flightReservation.setCreateUserId(UserUtil.getUserId());

        startPage();
        List<FlightReservationPageVo> list = flightReservationService.queryList(flightReservation);
        TableDataInfo dataTable = getDataTable(list);

        Set<String> airportSet = new HashSet<>();
        Set<Long> userIdSet = new HashSet<>();
        Optional.ofNullable(dataTable.getRows()).ifPresent(rows -> rows.forEach(row -> {
            FlightReservationPageVo flightReservationPageVo = (FlightReservationPageVo) row;
            if (StringUtils.isNotBlank(flightReservationPageVo.getOrigin())) airportSet.add(flightReservationPageVo.getOrigin());
            if (StringUtils.isNotBlank(flightReservationPageVo.getDestination())) airportSet.add(flightReservationPageVo.getDestination());

            if (Objects.nonNull(flightReservationPageVo.getCreateUserId()) && flightReservationPageVo.getCreateUserId() > 0L) {
                userIdSet.add(flightReservationPageVo.getCreateUserId());
            }
            if (Objects.nonNull(flightReservationPageVo.getUpdateUserId()) && flightReservationPageVo.getUpdateUserId() > 0L) {
                userIdSet.add(flightReservationPageVo.getUpdateUserId());
            }
            if (Objects.nonNull(flightReservationPageVo.getCreatePnrUserId()) && flightReservationPageVo.getCreatePnrUserId() > 0L) {
                userIdSet.add(flightReservationPageVo.getCreatePnrUserId());
            }
            if (Objects.nonNull(flightReservationPageVo.getCancelPnrUserId()) && flightReservationPageVo.getCancelPnrUserId() > 0L) {
                userIdSet.add(flightReservationPageVo.getCancelPnrUserId());
            }
        }));

        Map<String, AirportsVo> airportMap = new HashMap<>();
        if (CollectionUtil.isNotEmpty(airportSet)) {
            List<AirportsVo> airportsVos = airportsService.query(new ArrayList<>(airportSet));
            Optional.ofNullable(airportsVos)
                    .ifPresent(airportsVoList -> airportsVoList.forEach(airportsVo -> airportMap.put(airportsVo.getAirportCode(), airportsVo)));
        }

        List<SysUserBaseInfoVo> userBaseInfoVos = ticketApi.findByUserIds(Lists.newArrayList(userIdSet));
        Map<Long, String> userMap = Optional.ofNullable(userBaseInfoVos)
                .map(userBaseInfoVoList -> userBaseInfoVoList.stream().collect(Collectors.toMap(SysUserBaseInfoVo::getUserId, SysUserBaseInfoVo::getUserName, (a, b) -> b)))
                .orElse(new HashMap<>());

        Optional.ofNullable(dataTable.getRows()).ifPresent(rows -> rows.forEach(row -> {
            FlightReservationPageVo flightReservationPageVo = (FlightReservationPageVo) row;

            AirportsVo originAirportsVo = airportMap.get(flightReservationPageVo.getOrigin());
            if (Objects.nonNull(originAirportsVo)) {
                flightReservationPageVo.setOrigin(originAirportsVo.getCity() + originAirportsVo.getAirport());
            }

            AirportsVo destinationAirportsVo = airportMap.get(flightReservationPageVo.getDestination());
            if (Objects.nonNull(destinationAirportsVo)) {
                flightReservationPageVo.setDestination(destinationAirportsVo.getCity() + destinationAirportsVo.getAirport());
            }

            flightReservationPageVo.setDepartureTime(DateUtil.dateTimeFormat(flightReservationPageVo.getDepartureTime(), DatePattern.NORM_DATETIME_PATTERN));
            flightReservationPageVo.setArrivalTime(DateUtil.dateTimeFormat(flightReservationPageVo.getArrivalTime(), DatePattern.NORM_DATETIME_PATTERN));
            flightReservationPageVo.setReservationTime(flightReservationPageVo.getCreatePnrTime());
            flightReservationPageVo.setLatestTicketingTime(DateUtil.dateTimeFormat(flightReservationPageVo.getLatestTicketingTime(), DatePattern.NORM_DATETIME_PATTERN));
            flightReservationPageVo.setCreateBy(userMap.get(flightReservationPageVo.getCreateUserId()));
            flightReservationPageVo.setUpdateBy(userMap.get(flightReservationPageVo.getUpdateUserId()));
            flightReservationPageVo.setCreatePnrBy(userMap.get(flightReservationPageVo.getCreatePnrUserId()));
            flightReservationPageVo.setCancelPnrBy(userMap.get(flightReservationPageVo.getCancelPnrUserId()));
        }));

        return dataTable;
    }*/

    /**
     * 查询航班预定列表
     */
    @GetMapping("/list")
    public TableDataInfo list(FlightReservation flightReservation) {
        if (Objects.nonNull(flightReservation.getTripType()) && Objects.isNull(TripType.fromCode(flightReservation.getTripType()))) {
            throw new ServiceException("行程类型错误", HttpStatus.BAD_REQUEST);
        }

        flightReservation.setCreateUserId(ContextUtil.getUserId());

        startPage();
        List<FlightReservation> flightReservations = flightReservationService.selectFlightReservationList(flightReservation);
        TableDataInfo dataTable = getDataTable(flightReservations);

        List<FlightReservationPageVo> flightReservationPageVos = flightReservationService.convert(flightReservations);
        dataTable.setRows(flightReservationPageVos);

        return dataTable;
    }

    /**
     * 查询航班预定列表
     */
    @PostMapping("/page")
    public TableDataInfo reservations(@RequestBody FlightReservation flightReservation) {
        if (Objects.nonNull(flightReservation.getTripType()) && Objects.isNull(TripType.fromCode(flightReservation.getTripType()))) {
            throw new ServiceException("行程类型错误", HttpStatus.BAD_REQUEST);
        }

        flightReservation.setCreateUserId(ContextUtil.getUserId());

        startPage();
        /*List<FlightReservationPageVo> list = flightReservationService.queryReservations(flightReservation);*/
        List<FlightReservationPageVo> list = flightReservationService.queryReservationsNew(flightReservation);
        TableDataInfo dataTable = getDataTable(list);

        if (CollectionUtil.isEmpty(list)) {
            return dataTable;
        }

        /*List<FlightReservationPageBaseVo> flightReservationPageBaseVos = flightReservationService.convertReservations(list);*/
        List<FlightReservationPageBaseVo> flightReservationPageBaseVos = flightReservationService.convertReservationsNew(list);
        dataTable.setRows(flightReservationPageBaseVos);

        return dataTable;
    }

    /**
     * 查询指定的PNR信息
     */
    @PostMapping("/pnrs")
    public AjaxResult pnrs(@RequestBody List<String> pnrs) {
        if (CollectionUtil.isEmpty(pnrs)) {
            return AjaxResult.success();
        }

        FlightReservation flightReservation = FlightReservation.builder().pnrs(pnrs).build();
        List<FlightReservationPageVo> flightReservationPageVosOld = flightReservationService.queryReservations(flightReservation);
        List<FlightReservationPageVo> flightReservationPageVosNew = flightReservationService.queryReservationsNew(flightReservation);

        List<FlightReservationPageVo> flightReservationPageVos = Lists.newArrayList();
        flightReservationPageVosOld.stream().filter(item -> !IntConvertUtil.isNumber(item.getFlightFareKey())).forEach(flightReservationPageVos::add);
        flightReservationPageVosNew.stream().filter(item -> IntConvertUtil.isNumber(item.getFlightFareKey())).forEach(flightReservationPageVos::add);
        if (CollectionUtil.isEmpty(flightReservationPageVos)) {
            return AjaxResult.success();
        }

        if (CollectionUtil.isEmpty(flightReservationPageVos)) {
            return AjaxResult.success();
        }

        /*List<FlightReservationPageBaseVo> flightReservationPageBaseVos = flightReservationService.convertReservations(flightReservationPageVos);*/
        List<FlightReservationPageBaseVo> flightReservationPageBaseVos = flightReservationService.convertReservationsNew(flightReservationPageVos);
        return AjaxResult.success(flightReservationPageBaseVos);
    }

    /**
     * 查询指定的预约记录信息
     */
    @PostMapping("/queryByIds")
    public AjaxResult queryByIds(@RequestBody List<Long> reservationIds) {
        if (CollectionUtil.isEmpty(reservationIds)) {
            return AjaxResult.success();
        }

        FlightReservation flightReservation = FlightReservation.builder().reservationIds(reservationIds).build();
        List<FlightReservationPageVo> flightReservationPageVosOld = flightReservationService.queryReservations(flightReservation);
        List<FlightReservationPageVo> flightReservationPageVosNew = flightReservationService.queryReservationsNew(flightReservation);

        List<FlightReservationPageVo> flightReservationPageVos = Lists.newArrayList();
        flightReservationPageVosOld.stream().filter(item -> !IntConvertUtil.isNumber(item.getFlightFareKey())).forEach(flightReservationPageVos::add);
        flightReservationPageVosNew.stream().filter(item -> IntConvertUtil.isNumber(item.getFlightFareKey())).forEach(flightReservationPageVos::add);
        if (CollectionUtil.isEmpty(flightReservationPageVos)) {
            return AjaxResult.success();
        }

        /*List<FlightReservationPageBaseVo> flightReservationPageBaseVos = flightReservationService.convertReservations(flightReservationPageVos);*/
        List<FlightReservationPageBaseVo> flightReservationPageBaseVos = flightReservationService.convertReservationsNew(flightReservationPageVos);
        return AjaxResult.success(flightReservationPageBaseVos);
    }

    /**
     * 导出航班预定列表
     */
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightReservation flightReservation) {
        List<FlightReservation> list = flightReservationService.selectFlightReservationList(flightReservation);
        ExcelUtil<FlightReservation> util = new ExcelUtil<FlightReservation>(FlightReservation.class);
        util.exportExcel(response, list, "航班预定数据");
    }

    /**
     * 获取航班预定详细信息
     */
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(flightReservationService.selectFlightReservationById(id));
    }

    /**
     * 获取航班预定详细信息
     */
    @GetMapping(value = "/detail")
    public AjaxResult detail(@RequestParam(value = "id",required = false) Long id,
                             @RequestParam(value = "pnr",required = false) String pnr) {
        if (Objects.isNull(id) && StringUtils.isBlank(pnr)) {
            throw new ServiceException("预约记录ID和PNR必传一个", HttpStatus.BAD_REQUEST);
        }
        return success(flightReservationService.detail(id, pnr));
    }

    /**
     * 新增航班预定
     */
    @PostMapping
    public AjaxResult add(@RequestBody FlightReservation flightReservation) {
        if (StringUtils.isBlank(flightReservation.getFlightFareKey()))
            throw new ServiceException("报价ID为空", HttpStatus.BAD_REQUEST);

        if (CollectionUtil.isEmpty(flightReservation.getTravelerIds()))
            throw new ServiceException("乘机人为空", HttpStatus.BAD_REQUEST);

        /*if (StringUtils.isBlank(flightReservation.getBusinessScene())) {
            Optional.ofNullable(ServletUtils.getHeader(CommonConstant.HEADER_BUSINESS_SCENE))
                    .map(BusinessScene::fromCode)
                    .map(BusinessScene::getCode)
                    .ifPresent(flightReservation::setBusinessScene);
        }
        if (StringUtils.isBlank(flightReservation.getBusinessId())) {
            Optional.ofNullable(ServletUtils.getHeader(CommonConstant.HEADER_BUSINESS_ID))
                    .filter(StringUtils::isNotBlank)
                    .ifPresent(flightReservation::setBusinessId);
        }*/

        return toAjax(flightReservationService.insertFlightReservation(flightReservation));
    }

    /**
     * 修改航班预定
     */
    @PutMapping
    public AjaxResult edit(@RequestBody FlightReservation flightReservation) {
        return toAjax(flightReservationService.updateFlightReservation(flightReservation));
    }

    /**
     * 逻辑删除航班预定
     */
    @DeleteMapping("/{id}")
    public AjaxResult remove(@PathVariable Long id) {
        return toAjax(flightReservationService.deleteFlightReservationById(id));
    }
}
