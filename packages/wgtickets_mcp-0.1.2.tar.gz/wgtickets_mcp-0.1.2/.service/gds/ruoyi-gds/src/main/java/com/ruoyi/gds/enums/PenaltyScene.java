package com.ruoyi.gds.enums;

import lombok.Getter;

@Getter
public enum PenaltyScene {

    CHANGE,

    CANCEL,

    NOSHOW

}
