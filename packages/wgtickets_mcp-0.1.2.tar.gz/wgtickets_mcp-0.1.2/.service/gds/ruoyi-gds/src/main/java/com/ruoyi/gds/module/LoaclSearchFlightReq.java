package com.ruoyi.gds.module;

import cn.hutool.core.collection.CollectionUtil;
import com.ruoyi.gds.enums.CabinCategoryType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;
import java.time.LocalTime;
import java.util.List;
import java.util.Objects;

/**
 * 二次精细化查询本地数据
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class LoaclSearchFlightReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 查询批次号（搜索条件key）
     */
    private String batchCode;

    /**
     * 行程类型
     */
    private Integer group;

    /**
     * 出发机场
     */
    private List<String> departureAirports;

    /**
     * 到达机场
     */
     private List<String> arrivalAirports;

    /**
     * 转机机场
     */
    private List<String> transferAirports;

     /**
     * 出发时间范围
     */
    private List<TimeRange> departureTimeRanges;

    /**
     * 到达时间范围
     */
    private List<TimeRange> arrivalTimeRanges;

    /**
     * 转机次数
     */
    private Integer transferTimes;

    /**
     * 指定航司
     */
    private List<String> carrierList;

    /**
     * 舱等信息
     */
    private List<CabinCategoryType> cabinsList;

    /**
     * 报价版本
     */
    private List<FareVersion> fareVersions;



    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TimeRange implements Serializable {
        /**
         * 时间范围——开始时间
         */
        private LocalTime beginTime;

        /**
         * 时间范围——截止时间
         */
        private LocalTime endTime;
    }

    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class FareVersion implements Serializable {
        /**
         * 报价key
         */
        private String flightFareKey;

        /**
         * 报价版本
         */
        private Integer flightFareVersion;
    }

    public boolean hasLocalCondition() {
        return Objects.nonNull(this.getGroup())
                || CollectionUtil.isNotEmpty(this.getDepartureAirports())
                || CollectionUtil.isNotEmpty(this.getArrivalAirports())
                || CollectionUtil.isNotEmpty(this.getTransferAirports())
                || CollectionUtil.isNotEmpty(this.getDepartureTimeRanges())
                || CollectionUtil.isNotEmpty(this.getArrivalTimeRanges())
                || Objects.nonNull(this.getTransferTimes())
                || CollectionUtil.isNotEmpty(this.getCarrierList());

    }

}
