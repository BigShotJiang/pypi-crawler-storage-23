package com.ruoyi.gds.enums.sabre;

public enum SabrePartyIdType {

    Agency,

    Sabre_API

}
