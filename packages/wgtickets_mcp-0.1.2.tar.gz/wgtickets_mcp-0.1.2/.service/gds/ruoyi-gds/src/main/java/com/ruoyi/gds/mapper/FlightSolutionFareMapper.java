package com.ruoyi.gds.mapper;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightSolutionFare;
import org.apache.ibatis.annotations.Param;

/**
 * 各GDS报价Mapper接口
 *
 * @author ruoyi
 * @date 2025-09-24
 */
public interface FlightSolutionFareMapper extends BaseMapper<FlightSolutionFare> {
    /**
     * 查询各GDS报价
     *
     * @param id 各GDS报价主键
     * @return 各GDS报价
     */
    public FlightSolutionFare selectFlightSolutionFareById(Long id);

    /**
     * 查询各GDS报价
     *
     * @param fareId 各GDS报价ID
     * @return 各GDS报价
     */
    public FlightSolutionFare selectByFareId(Long fareId);

    /**
     * 查询各GDS报价列表
     *
     * @param flightSolutionFare 各GDS报价
     * @return 各GDS报价集合
     */
    public List<FlightSolutionFare> selectFlightSolutionFareList(FlightSolutionFare flightSolutionFare);

    /**
     * 新增各GDS报价
     *
     * @param flightSolutionFare 各GDS报价
     * @return 结果
     */
    public int insertFlightSolutionFare(FlightSolutionFare flightSolutionFare);

    /**
     * 修改各GDS报价
     *
     * @param flightSolutionFare 各GDS报价
     * @return 结果
     */
    public int updateFlightSolutionFare(FlightSolutionFare flightSolutionFare);

    /**
     * 删除各GDS报价
     *
     * @param id 各GDS报价主键
     * @return 结果
     */
    public int deleteFlightSolutionFareById(Long id);

    /**
     * 批量删除各GDS报价
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightSolutionFareByIds(Long[] ids);

    /**
     * 批量写入，重复时跳过
     * @param flightSolutionFares
     * @return
     */
    int batchInsert(@Param("flightSolutionFares") List<FlightSolutionFare> flightSolutionFares);

    /**
     * 批量更新
     * @param flightSolutionFares
     * @return
     */
    int batchUpdate(@Param("flightSolutionFares") List<FlightSolutionFare> flightSolutionFares);

}
