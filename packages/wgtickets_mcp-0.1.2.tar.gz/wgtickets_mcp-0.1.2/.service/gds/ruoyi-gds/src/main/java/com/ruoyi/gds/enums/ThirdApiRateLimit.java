package com.ruoyi.gds.enums;

import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

@Getter
public enum ThirdApiRateLimit {

    DEV_A1("A5", "/develop/xml/AirFareSearchOne/I", 1, "IBE. 搜索行程"),
    DEV_B7("B7", "/develop/xml/AirAvail/RealTime", 1, "IBE. 指定航班实时验舱"),
    DEV_C3("C3", "/develop/xml/AirFarePrice/I", 1, "IBE QTE. 查指定舱位报价"),
    DEV_C9("C9", "/develop/xml/AirFareBestBuy/I", 1, "IBE QTB. 查最低价，不限制舱位"),
    DEV_C13("C13", "/develop/xml/AirFareCalculateCurrency/I", 1, "IBE. 国际汇率计算"),
    DEV_C43("C43", "/develop/xml/AirFarePriceByPNROrder/I", 1, "IBE. 国际按PNR运价计算（订单）"),
    DEV_D3("D3", "/develop/xml/AirResRet", 1, "IBE. PNR现行记录提取"),
    DEV_D5("D5", "/develop/xml/AirBookOrder", 1, "IBE. PNR预订（订单）"),
    DEV_D6("D6", "/develop/xml/AirBookModifyOrder", 1, "IBE. PNR修改和取消（订单）"),
    DEV_E8("E8", "/develop/xml/AirTicketRet", 1, "IBE. 电子客票提取"),
    DEV_E25("E25", "/develop/xml/AirFareAutoTicketPlusOrder/I", 1, "IBE. 国际自动出票（订单）（新版）"),
    DEV_E26("E26", "/develop/xml/AirTicketDeviceRemain", 1, "IBE. 查询打票机剩余票号"),
    DEV_E30("E30", "/develop/xml/AirFareAutoBOPTicketOrder/I", 1, "IBE. 国际BOP自动出票带订单"),

    PROD_A1("A5", "/ota/xml/AirFareSearchOne/I", 5, "IBE. 搜索行程"),
    PROD_B7("B7", "/ota/xml/AirAvail/RealTime", 10, "IBE. 指定航班实时验舱"),
    PROD_C3("C3", "/ota/xml/AirFarePrice/I", 10, "IBE QTE. 查指定舱位报价"),
    PROD_C9("C9", "/ota/xml/AirFareBestBuy/I", 10, "IBE QTB. 查最低价，不限制舱位"),
    PROD_C13("C13", "/ota/xml/AirFareCalculateCurrency/I", 1, "IBE. 国际汇率计算"),
    PROD_C43("C43", "/ota/xml/AirFarePriceByPNROrder/I", 10, "IBE. 国际按PNR运价计算（订单）"),
    PROD_D3("D3", "/ota/xml/AirResRet", 15, "IBE. PNR现行记录提取"),
    PROD_D5("D5", "/ota/xml/AirBookOrder", 1, "IBE. PNR预订（订单）"),
    PROD_D6("D6", "/ota/xml/AirBookModifyOrder", 1, "IBE. PNR修改和取消（订单）"),
    PROD_E8("E8", "/ota/xml/AirTicketRet", 1, "IBE. 电子客票提取"),
    PROD_E25("E25", "/ota/xml/AirFareAutoTicketPlusOrder/I", 1, "IBE. 国际自动出票（订单）（新版）"),
    PROD_E26("E26", "/ota/xml/AirTicketDeviceRemain", 1, "IBE. 查询打票机剩余票号"),
    PROD_E30("E30", "/ota/xml/AirFareAutoBOPTicketOrder/I", 1, "IBE. 国际BOP自动出票带订单"),

    DEFAULT_LIMIT("DEFAULT", "AAAAAAAAA", 1, "默认频率");

    private final String code;

    private final String url;

    private final Integer limit;

    private final String desc;

    ThirdApiRateLimit(String code, String url, Integer limit, String desc) {
        this.code = code;
        this.url = url;
        this.limit = limit;
        this.desc = desc;
    }

    public static ThirdApiRateLimit fromCode(String code) {
        return Arrays.stream(ThirdApiRateLimit.values())
                .filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.code))
                .findFirst()
                .orElse(DEFAULT_LIMIT);
    }

    public static ThirdApiRateLimit fromUrl(String url) {
        return Arrays.stream(ThirdApiRateLimit.values())
                .filter(item -> StringUtils.isNotBlank(url) && url.equals(item.url))
                .findFirst()
                .orElse(DEFAULT_LIMIT);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }
    
}
