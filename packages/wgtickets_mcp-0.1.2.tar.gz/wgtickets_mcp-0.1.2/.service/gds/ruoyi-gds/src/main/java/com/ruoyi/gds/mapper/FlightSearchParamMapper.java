package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightSearchParam;
import com.ruoyi.gds.module.dto.QueryBusinessSearchParamDto;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 航班搜索条件Mapper接口
 * 
 * @author ruoyi
 * @date 2025-06-24
 */
public interface FlightSearchParamMapper extends BaseMapper<FlightSearchParam>
{
    /**
     * 查询航班搜索条件
     * 
     * @param id 航班搜索条件主键
     * @return 航班搜索条件
     */
    public FlightSearchParam selectFlightSearchParamById(Long id);

    /**
     * 查询航班搜索条件列表
     * 
     * @param flightSearchParam 航班搜索条件
     * @return 航班搜索条件集合
     */
    public List<FlightSearchParam> selectFlightSearchParamList(FlightSearchParam flightSearchParam);

    /**
     * 新增航班搜索条件
     * 
     * @param flightSearchParam 航班搜索条件
     * @return 结果
     */
    public int insertFlightSearchParam(FlightSearchParam flightSearchParam);

    /**
     * 修改航班搜索条件
     * 
     * @param flightSearchParam 航班搜索条件
     * @return 结果
     */
    public int updateFlightSearchParam(FlightSearchParam flightSearchParam);

    /**
     * 删除航班搜索条件
     * 
     * @param id 航班搜索条件主键
     * @return 结果
     */
    public int deleteFlightSearchParamById(Long id);

    /**
     * 批量删除航班搜索条件
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightSearchParamByIds(Long[] ids);

    List<FlightSearchParam> getRootSearchParams(@Param("queryDto") QueryBusinessSearchParamDto queryDto);
}
