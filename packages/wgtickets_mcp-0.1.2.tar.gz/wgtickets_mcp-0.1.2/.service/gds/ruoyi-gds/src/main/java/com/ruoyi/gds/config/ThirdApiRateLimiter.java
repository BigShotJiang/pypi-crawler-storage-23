package com.ruoyi.gds.config;

import com.ruoyi.gds.enums.ThirdApiRateLimit;
import org.redisson.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.EnumMap;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.TimeUnit;

@Component
public class ThirdApiRateLimiter {

    @Autowired
    private RedissonClient redissonClient;

    private final Map<ThirdApiRateLimit, RRateLimiter> rateLimiterMap = new EnumMap<>(ThirdApiRateLimit.class);

    /**
     * 每次访问最短间隔系数
     */
    private static final BigDecimal COEFFICIENT = new BigDecimal("1.3");

    /**
     * 初始化所有场景的限流器
     */
    @PostConstruct
    public void initRateLimiters() {
        for (ThirdApiRateLimit thirdApi : ThirdApiRateLimit.values()) {
            String limiterName = "rate_limiter:" + thirdApi.name();

            // 先删除限流器 key，确保旧配置被清除
            redissonClient.getKeys().delete(limiterName);

            RRateLimiter rateLimiter = redissonClient.getRateLimiter(limiterName);

            // 设置速率：使用枚举中配置的 limit 值
            // RateType.OVERALL 表示所有客户端共享限制
            // 每秒允许 thirdApi.getLimit() 次请求
            // 注意：Redisson 的令牌桶特性：rate 表示每 interval 期间允许的请求数
            // 为了实现 3次/秒，使用 (1, 333, MILLISECONDS) 表示每 333ms 允许 1 次请求
            int intervalMs = new BigDecimal(String.valueOf(1000 / thirdApi.getLimit() + 1000 % thirdApi.getLimit())).multiply(COEFFICIENT).setScale(0, RoundingMode.HALF_UP).intValue();
            boolean success = rateLimiter.trySetRate(RateType.OVERALL, 1, intervalMs, RateIntervalUnit.MILLISECONDS);

            if (!success) {
                // 如果设置失败，说明限流器已存在，再次删除后重试
                redissonClient.getKeys().delete(limiterName);
                success = rateLimiter.trySetRate(RateType.OVERALL, 1, intervalMs, RateIntervalUnit.MILLISECONDS);
            }

            if (success) {
                System.out.println("限流器初始化成功: " + thirdApi.name() + " - " + thirdApi.getLimit() + "次/秒");
            } else {
                System.err.println("限流器初始化失败: " + thirdApi.getCode());
            }

            rateLimiterMap.put(thirdApi, rateLimiter);
        }
    }

    public static void batchDeleteWithRBatch(RedissonClient redissonClient, String pattern) {
        RKeys keys = redissonClient.getKeys();
        RBatch batch = redissonClient.createBatch();
        for (String s : keys.getKeysByPattern(pattern)) batch.getBucket(s).deleteAsync();
        batch.execute();
    }

    /**
     * 尝试获取令牌（非阻塞）
     */
    public boolean tryAcquire(ThirdApiRateLimit scene) {
        RRateLimiter rateLimiter = rateLimiterMap.get(scene);
        return Objects.nonNull(rateLimiter) && rateLimiter.tryAcquire();
    }

    /**
     * 尝试获取令牌（带超时）
     */
    public boolean tryAcquire(ThirdApiRateLimit scene, long timeout, TimeUnit unit) {
        RRateLimiter rateLimiter = rateLimiterMap.get(scene);
        if (Objects.isNull(rateLimiter)) return false;
        return rateLimiter.tryAcquire(timeout, unit);
    }

    /**
     * 获取指定数量的令牌
     */
    public boolean tryAcquire(ThirdApiRateLimit scene, long permits) {
        RRateLimiter rateLimiter = rateLimiterMap.get(scene);
        return Objects.nonNull(rateLimiter) && rateLimiter.tryAcquire(permits);
    }

    /**
     * 获取令牌（阻塞）
     */
    public void acquire(ThirdApiRateLimit scene) {
        RRateLimiter rateLimiter = rateLimiterMap.get(scene);
        if (Objects.nonNull(rateLimiter)) {
            rateLimiter.acquire();

            /*long availablePermits = rateLimiter.availablePermits();
            rateLimiter.acquire();
            long availablePermitsAfter = rateLimiter.availablePermits();
            System.out.println("[" + scene.getCode() + "] 获取令牌 - 前: " + availablePermits + ", 后: " + availablePermitsAfter);*/
        }
    }

    /**
     * 获取可用的令牌数
     */
    public long getAvailablePermits(ThirdApiRateLimit scene) {
        RRateLimiter rateLimiter = rateLimiterMap.get(scene);
        return Objects.nonNull(rateLimiter) ? rateLimiter.availablePermits() : 0;
    }

    /**
     * 获取当前速率配置
     */
    public Map<String, Object> getRateConfig(ThirdApiRateLimit scene) {
        RRateLimiter rateLimiter = rateLimiterMap.get(scene);
        if (Objects.isNull(rateLimiter)) return null;

        Map<String, Object> config = new java.util.HashMap<>();
        config.put("rate", rateLimiter.getConfig().getRate());
        config.put("rateInterval", rateLimiter.getConfig().getRateInterval());
        config.put("rateType", rateLimiter.getConfig().getRateType());
        return config;
    }

    /**
     * 动态更新限流配置
     */
    public boolean updateRateLimit(ThirdApiRateLimit thirdApiRateLimit, int newLimit) {
        RRateLimiter rateLimiter = rateLimiterMap.get(thirdApiRateLimit);
        if (Objects.isNull(rateLimiter)) return false;
        return rateLimiter.trySetRate(RateType.OVERALL, newLimit, 1, RateIntervalUnit.SECONDS);
    }
}
