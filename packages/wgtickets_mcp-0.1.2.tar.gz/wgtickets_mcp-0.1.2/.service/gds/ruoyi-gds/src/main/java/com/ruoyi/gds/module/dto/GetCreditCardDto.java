package com.ruoyi.gds.module.dto;

import cn.hutool.core.date.DatePattern;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GetCreditCardDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 预约号
     */
    @NotBlank(message = "PNR为空")
    private String pnr;

    /**
     * 币种（CNY / JPY ...）
     */
    @NotBlank(message = "币种为空")
    private String currency;

    /**
     * 金额
     */
    @NotNull(message = "金额为空")
    private BigDecimal totalAmount;

    /**
     * 信用卡有效期
     */
    @NotNull(message = "信用卡有效期为空")
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime inactiveDate;

    /**
     * 发卡机构（AWE / TL）
     */
    private String server;

    /**
     * 持卡人名称（乘机人姓名）
     */
    private String userName;

}
