package com.ruoyi.gds.common;

import com.ruoyi.gds.schema.galileo.common_v50_0.TypeTicketStatus;
import org.assertj.core.util.Lists;

import java.util.List;
import java.util.regex.Pattern;

public class GalileoConstant {

    public static final String ORIGIN_APPLICATION = "UAPI";

    public static final String BRAND_TITLE_TYPE_SHORT = "Short";

    // 紧急联系方式类型——手机号
    public static final String EMERGENCY_TYPE_PHONE = "CTCM";

    // 紧急联系方式类型——邮箱
    public static final String EMERGENCY_TYPE_EMAIL = "CTCE";

    // SSR类型
    public static final String EMERGENCY_SSR_FOID = "FOID";

    // SSR类型
    public static final String EMERGENCY_SSR_DOCS = "DOCS";

    // 儿童年龄前缀
    public static final String CHILD_AGE_PREFIX = "P-C";

    // 票状态——有效状态
    public static final List<TypeTicketStatus> EFFECTIVE_TICKETNO_STATUS = Lists.newArrayList(TypeTicketStatus.T, TypeTicketStatus.Z, TypeTicketStatus.N, TypeTicketStatus.S);

    // GDS通过缓存返回数据
    public static final String POLLED_AVAILABILITY_OPTION_CACHE = "Cached status used. Polled avail exists";

    // GDS通过实时查询返回数据
    public static final String POLLED_AVAILABILITY_OPTION_REALTIME = "Polled avail exists";

    // 伽利略生成PNR失败返回信息
    public static final String GALILEO_ERROR_MSG_1 = "General air service Error.";
    // 伽利略生成PNR失败返回信息翻译
    public static final String GALILEO_ERROR_MSG_1_TRANSLATE = "所有航段均无法预订，PNR不会被生成";


    public static final Pattern BAGGAGE_PATTERN = Pattern.compile("(K|KG|KILOGRAMS|P|PC)$");
    public static final Pattern BAGGAGE_PIECES_PATTERN = Pattern.compile("(P|PC)$");


}
