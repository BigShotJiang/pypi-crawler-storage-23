package com.ruoyi.gds.forest;

import com.dtflys.forest.annotation.BaseRequest;
import com.dtflys.forest.annotation.Body;
import com.dtflys.forest.annotation.Header;
import com.dtflys.forest.annotation.Post;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.enums.BusinessType;
import com.ruoyi.gds.forest.interceptor.GalileoInterceptor;
import org.springframework.stereotype.Component;

@Component
@BaseRequest(
        baseURL = "${galileo_baseurl}",
        headers = {"Content-Type: application/json"},
        interceptor = GalileoInterceptor.class
)
public interface GalileoApi {

    // PNR服务
    @Post(url = "/UniversalRecordService")
    String universalRecordService(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                                  @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                                  @Body String xml);

    //
    @Post(url = "/ScheduleChangeService")
    String scheduleChangeService(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                                 @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                                 @Body String xml);

    // 航班服务
    @Post(url = "/AirService")
    String airService(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                      @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                      @Body String xml);

    // PNR队列服务
    @Post(url = "/GdsQueueService")
    String gdsQueueService(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                           @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                           @Body String xml);

    // 币种转换服务
    @Post(url = "/CurrencyConversionService")
    String currencyConversionService(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                                     @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                                     @Body String xml);

}
