package com.ruoyi.gds.forest.interceptor;

import com.dtflys.forest.http.ForestRequest;
import com.ruoyi.gds.config.GDSConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Base64;

@Slf4j
@Component
public class GalileoInterceptor extends BaseInterceptor {

    @Autowired
    private GDSConfig gdsConfig;

    @Override
    public boolean beforeExecute(ForestRequest request) {
        super.beforeExecute(request);

        String credentials = "Universal API/" + gdsConfig.getGalileo().getUsername() + ":" + gdsConfig.getGalileo().getPassword();
        String auth = Base64.getEncoder().encodeToString(credentials.getBytes());
        request.addHeader("Authorization", "Basic " + auth);
        return true;
    }

}
