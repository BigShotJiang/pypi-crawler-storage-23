package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.gds.module.domain.GdsRequestLog;
import com.ruoyi.gds.service.IGdsRequestLogService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 请求gds记录Controller
 * 
 * @author ruoyi
 * @date 2025-08-16
 */
@RestController
@RequestMapping("/system/log")
public class GdsRequestLogController extends BaseController
{
    @Autowired
    private IGdsRequestLogService gdsRequestLogService;

    /**
     * 查询请求gds记录列表
     */
    @PreAuthorize("@ss.hasPermi('system:log:list')")
    @GetMapping("/list")
    public TableDataInfo list(GdsRequestLog gdsRequestLog)
    {
        startPage();
        List<GdsRequestLog> list = gdsRequestLogService.selectGdsRequestLogList(gdsRequestLog);
        return getDataTable(list);
    }

    /**
     * 导出请求gds记录列表
     */
    @PreAuthorize("@ss.hasPermi('system:log:export')")
    @Log(title = "请求gds记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, GdsRequestLog gdsRequestLog)
    {
        List<GdsRequestLog> list = gdsRequestLogService.selectGdsRequestLogList(gdsRequestLog);
        ExcelUtil<GdsRequestLog> util = new ExcelUtil<GdsRequestLog>(GdsRequestLog.class);
        util.exportExcel(response, list, "请求gds记录数据");
    }

    /**
     * 获取请求gds记录详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:log:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(gdsRequestLogService.selectGdsRequestLogById(id));
    }

    /**
     * 新增请求gds记录
     */
    @PreAuthorize("@ss.hasPermi('system:log:add')")
    @Log(title = "请求gds记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody GdsRequestLog gdsRequestLog)
    {
        return toAjax(gdsRequestLogService.insertGdsRequestLog(gdsRequestLog));
    }

    /**
     * 修改请求gds记录
     */
    @PreAuthorize("@ss.hasPermi('system:log:edit')")
    @Log(title = "请求gds记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody GdsRequestLog gdsRequestLog)
    {
        return toAjax(gdsRequestLogService.updateGdsRequestLog(gdsRequestLog));
    }

    /**
     * 删除请求gds记录
     */
    @PreAuthorize("@ss.hasPermi('system:log:remove')")
    @Log(title = "请求gds记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(gdsRequestLogService.deleteGdsRequestLogByIds(ids));
    }
}
