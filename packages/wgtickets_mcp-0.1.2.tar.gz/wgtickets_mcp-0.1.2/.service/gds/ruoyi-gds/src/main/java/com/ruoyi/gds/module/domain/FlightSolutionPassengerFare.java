package com.ruoyi.gds.module.domain;

import cn.hutool.crypto.digest.DigestUtil;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 各类乘机人报价对象 flight_solution_passenger_fare
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightSolutionPassengerFare implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 搜索条件Key
     */
    @Excel(name = "搜索条件Key")
    private String searchParamKey;

    /**
     * 行程方案Key
     */
    @Excel(name = "行程方案Key")
    private String solutionKey;

    /**
     * GDS代码
     */
    @Excel(name = "GDS代码")
    private String providerCode;

    /**
     * 乘机人类型（ADT: 成人, CNN: 儿童, INF: 婴儿）
     */
    @Excel(name = "乘机人类型", readConverterExp = "A=DT:,成=人,,C=NN:,儿=童,,I=NF:,婴=儿")
    private String passengerType;

    /**
     * 乘机人数
     */
    @Excel(name = "乘机人数")
    private Integer passengerNum;

    /**
     * 运价代码
     */
    @Excel(name = "运价代码")
    private String fareBasis;

    /**
     * 币种
     */
    @Excel(name = "币种")
    private String currencyCode;

    /**
     * 总价
     */
    @Excel(name = "总价")
    private BigDecimal totalPrice;

    /**
     * 基础运价
     */
    @Excel(name = "基础运价")
    private BigDecimal basePrice;

    /**
     * 总税费
     */
    @Excel(name = "总税费")
    private BigDecimal taxes;

    /**
     * 税费明细
     */
    @Excel(name = "税费明细")
    private String taxesDetail;

    /**
     * 行李
     */
    @Excel(name = "行李")
    private String baggage;

    /**
     * 退票手续费
     */
    @Excel(name = "退票手续费")
    private String cancelPenalties;

    /**
     * 改签手续费
     */
    @Excel(name = "改签手续费")
    private String changePenalties;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 是否已删除（false：未删除，true：已删除）
     */
    private boolean delFlag;

    public String getMd5Hex() {
        String str = getSearchParamKey() + getSolutionKey() + getProviderCode() + getPassengerType();
        return DigestUtil.md5Hex(str);
    }

}
