package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.SysRequestLog;

import java.util.List;

/**
 * 请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息Mapper接口
 * 
 * @author ruoyi
 * @date 2025-02-07
 */
public interface SysRequestLogMapper extends BaseMapper<SysRequestLog>
{
    /**
     * 查询请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息
     * 
     * @param id 请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息主键
     * @return 请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息
     */
    public SysRequestLog selectSysRequestLogById(Long id);

    /**
     * 查询请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息列表
     * 
     * @param sysRequestLog 请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息
     * @return 请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息集合
     */
    public List<SysRequestLog> selectSysRequestLogList(SysRequestLog sysRequestLog);

    /**
     * 新增请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息
     * 
     * @param sysRequestLog 请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息
     * @return 结果
     */
    public int insertSysRequestLog(SysRequestLog sysRequestLog);

    /**
     * 修改请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息
     * 
     * @param sysRequestLog 请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息
     * @return 结果
     */
    public int updateSysRequestLog(SysRequestLog sysRequestLog);

    /**
     * 删除请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息
     * 
     * @param id 请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息主键
     * @return 结果
     */
    public int deleteSysRequestLogById(Long id);

    /**
     * 删除近30天的请求接口日志
     *
     * @return 结果
     */
    public int deleteLogsOlderThan30Days();

    /**
     * 批量删除请求接口日志，用于记录请求的 URL、参数、响应、执行时长等信息
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteSysRequestLogByIds(Long[] ids);
}
