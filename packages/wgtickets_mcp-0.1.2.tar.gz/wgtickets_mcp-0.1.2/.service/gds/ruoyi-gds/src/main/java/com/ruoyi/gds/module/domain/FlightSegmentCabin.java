package com.ruoyi.gds.module.domain;

import cn.hutool.crypto.digest.DigestUtil;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * 航段舱位对象 flight_segment_cabin
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightSegmentCabin implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 航段Key
     */
    @Excel(name = "航段Key")
    private String segmentKey;

    /**
     * 舱位等级（Economy：经济舱，PremiumEconomy：优选经济舱，Business：商务舱，First：头等舱）
     */
    @Excel(name = "舱位等级", readConverterExp = "E=conomy：经济舱，PremiumEconomy：优选经济舱，Business：商务舱，First：头等舱")
    private String cabinType;

    /**
     * 舱位号
     */
    @Excel(name = "舱位号")
    private String cabin;

    /**
     * 舱位剩余数量
     */
    @Excel(name = "舱位剩余数量")
    private Integer quantity;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 是否已删除（false：未删除，true：已删除）
     */
    private boolean delFlag;

    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        FlightSegmentCabin that = (FlightSegmentCabin) o;
        return Objects.equals(segmentKey, that.segmentKey) && Objects.equals(cabin, that.cabin);
    }

    @Override
    public int hashCode() {
        return Objects.hash(segmentKey, cabin);
    }

    public String getMd5Hex() {
        String str = getSegmentKey() + getCabin();
        return DigestUtil.md5Hex(str);
    }

}
