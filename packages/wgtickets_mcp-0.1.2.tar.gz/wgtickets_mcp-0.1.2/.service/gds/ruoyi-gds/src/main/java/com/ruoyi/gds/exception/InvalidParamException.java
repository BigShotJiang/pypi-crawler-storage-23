package com.ruoyi.gds.exception;

import com.ruoyi.common.constant.HttpStatus;
import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class InvalidParamException extends RuntimeException {
    private Integer errorCode;
    private String errorMsg;

    public InvalidParamException(Integer errorCode, String errorMsg) {
        super(errorMsg);
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public InvalidParamException(String errorMsg) {
        super(errorMsg);
        this.errorCode = HttpStatus.BAD_REQUEST;
        this.errorMsg = errorMsg;
    }

}
