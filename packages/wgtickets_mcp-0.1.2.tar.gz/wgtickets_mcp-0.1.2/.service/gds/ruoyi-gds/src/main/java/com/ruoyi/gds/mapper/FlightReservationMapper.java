package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightReservation;
import com.ruoyi.gds.module.vo.FlightReservationPageVo;
import com.ruoyi.gds.module.vo.TravlerFlightVo;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 航班预定Mapper接口
 * 
 * @author ruoyi
 * @date 2025-04-17
 */
public interface FlightReservationMapper extends BaseMapper<FlightReservation>
{
    /**
     * 查询航班预定
     * 
     * @param id 航班预定主键
     * @return 航班预定
     */
    public FlightReservation selectFlightReservationById(Long id);

    /**
     * 查询航班预定列表
     * 
     * @param flightReservation 航班预定
     * @return 航班预定集合
     */
    public List<FlightReservation> selectFlightReservationList(FlightReservation flightReservation);

    List<FlightReservationPageVo> queryList(FlightReservation flightReservation);

    List<FlightReservationPageVo> queryReservations(FlightReservation flightReservation);

    List<FlightReservationPageVo> queryReservationsNew(FlightReservation flightReservation);

    /**
     * 新增航班预定
     * 
     * @param flightReservation 航班预定
     * @return 结果
     */
    public int insertFlightReservation(FlightReservation flightReservation);

    /**
     * 修改航班预定
     * 
     * @param flightReservation 航班预定
     * @return 结果
     */
    public int updateFlightReservation(FlightReservation flightReservation);

    /**
     * 删除航班预定
     * 
     * @param id 航班预定主键
     * @return 结果
     */
    public int deleteFlightReservationById(@Param("id") Long id, @Param("userId") Long userId);

    /**
     * 批量删除航班预定
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightReservationByIds(Long[] ids);

    /**
     * 查询取消的航段
     * @param travlerId
     * @param statusList
     * @param formatPattern
     * @return
     */
    List<TravlerFlightVo> travlerFlight(@Param("travlerId") Long travlerId, @Param("statusList") List<Integer> statusList, @Param("formatPattern") String formatPattern);

    /**
     * 查询取消的航段
     * @param travlerId
     * @param statusList
     * @param formatPattern
     * @return
     */
    List<TravlerFlightVo> travlerFlightOld(@Param("travlerId") Long travlerId, @Param("statusList") List<Integer> statusList, @Param("formatPattern") String formatPattern);

    /**
     * 查询取消的航段
     * @param travlerId
     * @param statusList
     * @param formatPattern
     * @return
     */
    List<TravlerFlightVo> travlerFlightNew(@Param("travlerId") Long travlerId, @Param("statusList") List<Integer> statusList, @Param("formatPattern") String formatPattern);

}
