package com.ruoyi.gds.module.domain;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 飞常准—航变定制与PNR关联对象 fcz_airchange_custom_pnr
 * 
 * @author ruoyi
 * @date 2025-11-21
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FczAirchangeCustomPnr implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 定制航变通知记录表ID */
    @Excel(name = "定制航变通知记录表ID")
    private Long customId;

    /** 业务ID（票务的票ID、PNR） */
    @Excel(name = "业务ID（票务的票ID、PNR）")
    private String businessId;

    /** 创建时间 */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;

}
