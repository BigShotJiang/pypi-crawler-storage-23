package com.ruoyi.gds.common;

public class SabreConstant {

    public static final String CONVERSATION_ID = "2021.01.DevStudio";

    public static final String PASSENGER_TYPE_CNN = "C06";

    public static final String PASSENGER_TYPE_CNN_PREFIX = "C";

    public static final String PENALTY_CHANGE = "Exchange";

    public static final String PENALTY_CANCEL = "Refund";

    public static final String REQUESTOR_TYPE = "1";

    public static final String REQUESTOR_ID = "1";

    public static final String COMPANYNAME_CODE = "TN";

    public static final String SEARCH_FLIGHT_VERSION = "5";

    public static final String SEARCH_PRICE_VERSION = "5";

    public static final String SEARCH_FLIGHT_LOCATION_TYPE_CITY = "C";

    public static final String SEARCH_FLIGHT_LOCATION_TYPE_AIRPORT = "A";

    public static final String SEARCH_FLIGHT_PREFER_LEVEL_ONLY = "Only";

    public static final String SEARCH_FLIGHT_PREFER_LEVEL_PREFERRED = "Preferred";

    public static final String SEARCH_FLIGHT_CARRIER_TYPE_MARKETING = "Marketing";

    public static final String SEARCH_FLIGHT_CARRIER_TYPE_OPERATING = "Operating";

    public static final String COMPANY_INFO = "TYO%s/AOYAMA-A";

    // 证件类型——护照
    public static final String IDENTITY_DOCUMENT_TYPE = "PASSPORT";

    public static final String PASSPORT_GENDER_MI = "INFANT_MALE";

    public static final String PASSPORT_GENDER_FI = "INFANT_FEMALE";

    public static final String CREATE_PNR_RECEIVED_FROM = "CreateBooking";

    public static final String ISSUE_TICKET_CARD_TYPE = "VI";

    public static final String UPDATE_RESERVATION_VIEWNAME = "Full";

    public static final String UPDATE_RESERVATION_RECEIVED_FROM = "API Sender Demo";

    public static final String UPDATE_RESERVATION_ALL_SEGMENT = "CONFIRM-ALL";

    public static final String CREDIT_CARD_EXPIRE_DATE_FORMAT = "yyyy-MM";

}
