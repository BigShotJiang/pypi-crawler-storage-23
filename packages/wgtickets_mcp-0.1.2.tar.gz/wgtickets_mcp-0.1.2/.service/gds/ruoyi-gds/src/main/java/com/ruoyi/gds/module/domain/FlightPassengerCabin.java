package com.ruoyi.gds.module.domain;

import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 乘机人舱位对象 flight_passenger_cabin
 * 
 * @author ruoyi
 * @date 2025-09-24
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightPassengerCabin implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    private Long id;

    /** 乘机人类型报价Key */
    @Excel(name = "乘机人类型报价Key")
    private String passengerFareKey;

    /** 航段舱位Key */
    @Excel(name = "航段舱位Key")
    private String segmentCabinKey;

    /** 创建者 */
    private String createBy;

    /** 创建时间 */
    private LocalDateTime createTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;

}
