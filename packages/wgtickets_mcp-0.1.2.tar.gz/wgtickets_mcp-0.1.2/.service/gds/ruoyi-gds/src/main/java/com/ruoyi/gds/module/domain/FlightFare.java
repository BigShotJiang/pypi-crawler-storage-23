package com.ruoyi.gds.module.domain;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 搜索航班结果对象 flight_fare
 * 
 * @author ruoyi
 * @date 2025-04-14
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightFare implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 批次号 */
    @Excel(name = "批次号")
    private String batchCode;

    /** 总行程编号 */
    @Excel(name = "总行程编号")
    private String flightKey;

    /** 总行程报价编号 */
    @Excel(name = "总行程报价编号")
    private String flightFareKey;

    /** GDS代码 */
    @Excel(name = "GDS代码")
    private String providerCode;

    /** 币种 */
    @Excel(name = "币种")
    private String currencyCode;

    /** 总价 */
    @Excel(name = "总价")
    private Long totalPrice;

    /** 基础运价 */
    @Excel(name = "基础运价")
    private Long basePrice;

    /** 总税费 */
    @Excel(name = "总税费")
    private Long taxes;

    /** 各人员类型报价 */
    @Excel(name = "各人员类型报价")
    private String passengerPrices;

    /** 各航段舱位等级 */
    @Excel(name = "各航段舱位等级")
    private String carbins;

    /** 查价时GDS返回的原始信息 */
    private String searchPriceRsp;

    /** 价格有效期 */
    private String latestTicketingTime;

    /** 创建者ID */
    @Excel(name = "创建者ID")
    private Long createUserId;

    /** 创建者 */
    @Excel(name = "创建者")
    private String createBy;

    /** 创建时间 */
    @Excel(name = "创建时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTime;

    /** 修改时间 */
    @Excel(name = "修改时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime updateTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("flightKey", getFlightKey())
            .append("flightFareKey", getFlightFareKey())
            .append("providerCode", getProviderCode())
            .append("currencyCode", getCurrencyCode())
            .append("totalPrice", getTotalPrice())
            .append("basePrice", getBasePrice())
            .append("taxes", getTaxes())
            .append("passengerPrices", getPassengerPrices())
            .append("carbins", getCarbins())
            .append("createTime", getCreateTime())
            .append("updateTime", getUpdateTime())
            .append("delFlag", isDelFlag())
            .toString();
    }
}
