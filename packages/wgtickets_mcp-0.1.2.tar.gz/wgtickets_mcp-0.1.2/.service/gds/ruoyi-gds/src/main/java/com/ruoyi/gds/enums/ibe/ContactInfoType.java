package com.ruoyi.gds.enums.ibe;

public enum ContactInfoType {

    CTCT, CTCM

}
