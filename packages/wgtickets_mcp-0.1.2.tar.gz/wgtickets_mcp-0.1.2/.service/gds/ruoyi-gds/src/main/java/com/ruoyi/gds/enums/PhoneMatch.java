package com.ruoyi.gds.enums;

import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;
import java.util.regex.Pattern;

@Getter
public enum PhoneMatch {

    CHINESE_MAINLAND(1, "中国大陆手机号", "CN", "86", "^(?:\\+?86)?1[3-9]\\d{9}$", "(^\\+?86|[\\s-])"),
    JAPAN(2, "日本手机号", "JP", "81", "^(?:\\+?81)?0[789]0\\d{8}$", "(^\\+?81|[\\s-])"),
    ;

    private final Integer num;

    private final String desc;

    private final String nationality;

    private final String prefix;

    private final String regex;

    private final String replaceRegex;

    PhoneMatch(Integer num, String desc, String nationality, String prefix, String regex, String replaceRegex) {
        this.num = num;
        this.regex = regex;
        this.replaceRegex = replaceRegex;
        this.prefix = prefix;
        this.nationality = nationality;
        this.desc = desc;
    }

    public static PhoneMatch fromNum(Integer num) {
        if (Objects.isNull(num)) return null;
        return Arrays.stream(PhoneMatch.values()).filter(item -> num.equals(item.num)).findFirst().orElse(null);
    }

    public static PhoneMatch macth(String phone) {
        return Arrays.stream(values()).filter(item -> Pattern.matches(item.regex, phone)).findFirst().orElse(null);
    }

    public String replace(String phone) {
        return phone.replaceAll(replaceRegex, "");
    }

    public static void main(String[] args) {
        System.out.println(Pattern.matches("(^(?:\\+?86)?1[3-9]\\d{9}$)|(^(?:\\+?81)?0[789]0\\d{8}$)", "+8613912345678"));
        System.out.println(Pattern.matches("(^(?:\\+?86)?1[3-9]\\d{9}$)|(^(?:\\+?81)?0[789]0\\d{8}$)", "8613912345678"));
        System.out.println(Pattern.matches("(^(?:\\+?86)?1[3-9]\\d{9}$)|(^(?:\\+?81)?0[789]0\\d{8}$)", "13912345678"));
        System.out.println(Pattern.matches("(^(?:\\+?86)?1[3-9]\\d{9}$)|(^(?:\\+?81)?0[789]0\\d{8}$)", "+8108012345678"));
        System.out.println(Pattern.matches("(^(?:\\+?86)?1[3-9]\\d{9}$)|(^(?:\\+?81)?0[789]0\\d{8}$)", "8108012345678"));
        System.out.println(Pattern.matches("(^(?:\\+?86)?1[3-9]\\d{9}$)|(^(?:\\+?81)?0[789]0\\d{8}$)", "08012345678"));


        System.out.println(macth("+8613912345678").replace("+8613912345678"));
        System.out.println(macth("8613912345678").replace("8613912345678"));
        System.out.println(macth("13912345678").replace("13912345678"));

        System.out.println(macth("+8108012345678").replace("+8108012345678"));
        System.out.println(macth("8108012345678").replace("8108012345678"));
        System.out.println(macth("08012345678").replace("08012345678"));
    }

}
