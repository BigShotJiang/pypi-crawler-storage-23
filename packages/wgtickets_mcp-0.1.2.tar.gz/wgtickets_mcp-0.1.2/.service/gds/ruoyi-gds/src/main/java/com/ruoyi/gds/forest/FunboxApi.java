package com.ruoyi.gds.forest;

import com.dtflys.forest.annotation.BaseRequest;
import com.dtflys.forest.annotation.Get;
import com.dtflys.forest.annotation.Query;
import com.dtflys.forest.http.ForestResponse;
import com.ruoyi.common.module.vo.ResultVo;
import com.ruoyi.gds.module.vo.FunboxRateVo;
import org.springframework.stereotype.Component;

@Component
@BaseRequest(baseURL = "${funbox_baseurl}")
public interface FunboxApi {

    /**
     * 查询银行汇率
     *
     * @param date
     * @return
     */
    @Get(url = "/fun/rate_quot?bankno=CCB", logEnabled = true)
    ForestResponse<ResultVo<FunboxRateVo>> bankRate(@Query("date") String date);

}
