package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.module.dto.validation.*;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum GDSType {

    GALELIO("1G", "伽利略", Galelio.class),
    IBE("1E", "中国白屏", IBE.class),
    SABRE("1S", "塞班", Sabre.class),
    EIGHT_YI("EIGHT_YI", "八千翼", EightYi.class),
    HUAN_YU("HUAN_YU", "寰宇", HuanYu.class);

    @JsonValue
    private final String code;

    private final String desc;

    private final Class<?> checkGroup;

    GDSType(String code, String desc, Class<?> checkGroup) {
        this.code = code;
        this.desc = desc;
        this.checkGroup = checkGroup;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static GDSType fromCode(String code) {
        return Arrays.stream(GDSType.values()).filter(item -> StringUtils.isNotBlank(code) && item.code.equalsIgnoreCase(code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
