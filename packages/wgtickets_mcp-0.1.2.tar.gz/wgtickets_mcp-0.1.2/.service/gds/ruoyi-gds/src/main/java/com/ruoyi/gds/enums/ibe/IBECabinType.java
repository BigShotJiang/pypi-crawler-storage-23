package com.ruoyi.gds.enums.ibe;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.enums.CabinCategoryType;
import com.ruoyi.gds.utils.StrUtil;
import lombok.Getter;

import java.util.Arrays;

/**
 * 舱位等级 / 服务等级
 */
@Getter
public enum IBECabinType {

    Y("Y", CabinCategoryType.ECONOMY,"最基本的舱位，通常票价最低"),
    B("B", CabinCategoryType.ECONOMY, "通常是比 Y 舱位更灵活的经济舱，可能允许免费改签或退票"),
    H("H", CabinCategoryType.ECONOMY, "一种经济舱类型，具体规则因航空公司而异"),
    M("M", CabinCategoryType.ECONOMY, "一种经济舱类型，规则可能不同"),
    W("W", CabinCategoryType.PREMIUM_ECONOMY, "比经济舱更舒适，座位空间更大，服务更好"),
    S("S", CabinCategoryType.PREMIUM_ECONOMY, "一种优选经济舱代码"),
    C("C", CabinCategoryType.BUSINESS, "提供更舒适的座位、更好的餐饮服务和额外的地面服务（如贵宾休息室）"),
    D("D", CabinCategoryType.BUSINESS, "一种公务舱代码"),
    J("J", CabinCategoryType.BUSINESS, "一种公务舱代码"),
    F("F", CabinCategoryType.FIRST, "最高级的舱位，提供最舒适的座位、最优质的服务和最全面的地面服务"),
    P("P", CabinCategoryType.FIRST, "一种头等舱代码"),
    A("A", CabinCategoryType.FIRST, "一种头等舱代码");

    @JsonValue
    private final String code;

    private final CabinCategoryType category;

    private final String desc;

    IBECabinType(String code, CabinCategoryType category, String desc) {
        this.code = code;
        this.category = category;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static IBECabinType fromCode(String code) {
        if (StringUtils.isBlank(code)) return null;
        return Arrays.stream(IBECabinType.values())
                .filter(item -> StringUtils.isNotBlank(code) && StrUtil.removeWhiteSpaces(code).equalsIgnoreCase(StrUtil.removeWhiteSpaces(item.code)))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
