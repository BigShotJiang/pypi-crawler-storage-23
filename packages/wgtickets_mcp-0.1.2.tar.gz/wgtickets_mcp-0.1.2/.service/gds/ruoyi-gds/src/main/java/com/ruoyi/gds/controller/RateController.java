package com.ruoyi.gds.controller;

import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.gds.module.dto.RateExchangeDto;
import com.ruoyi.gds.service.RateService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
@RequestMapping("/air/rate")
public class RateController {

    @Autowired
    private RateService rateService;

    /**
     * 金额转换
     * @param exchangeDto
     * @return
     */
    @PostMapping(value = "/exchange")
    public AjaxResult exchange(@RequestBody @Validated RateExchangeDto exchangeDto) {
        String sourceAmount = exchangeDto.getSourceCurrency() + exchangeDto.getSourceAmount().toPlainString();
        Integer targetAmount = rateService.getPrice(sourceAmount, exchangeDto.getTargetCurrency());
        return AjaxResult.success(targetAmount);
    }


}
