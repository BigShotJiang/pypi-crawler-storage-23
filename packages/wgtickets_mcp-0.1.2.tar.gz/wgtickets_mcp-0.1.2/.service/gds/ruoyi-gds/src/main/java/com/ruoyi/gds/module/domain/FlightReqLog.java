package com.ruoyi.gds.module.domain;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 机票预定使用记录对象 flight_req_log
 * 
 * @author ruoyi
 * @date 2025-05-19
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightReqLog implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    private Long id;

    /** 用户ID */
    @Excel(name = "用户ID")
    private Long userId;

    /** 类型(1：搜索，2：查价，3：预定，4：取消预定) */
    @Excel(name = "类型(1：搜索，2：查价，3：预定，4：取消预定)")
    private Integer type;

    /** 创建时间 */
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private LocalDateTime createTime;

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("userId", getUserId())
            .append("type", getType())
            .append("createTime", getCreateTime())
            .toString();
    }
}
