package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

@Getter
public enum MonthEnum {

    JANUARY(1, "January", "jan", "一月"),
    FEBRUARY(2, "February", "Feb", "二月"),
    MARCH(3, "March", "Mar", "三月"),
    APRIL(4, "April", "Apr", "四月"),
    MAY(5, "May", "May", "五月"),
    JUNE(6, "June", "Jun", "六月"),
    JULY(7, "July", "Jul", "七月"),
    AUGUST(8, "August", "Aug", "八月"),
    SEPTEMBER(9, "September", "Sep", "九月"),
    OCTOBER(10, "October", "Oct", "十月"),
    NOVEMBER(11, "November", "Nov", "十一月"),
    DECEMBER(12, "December", "Dec", "十二月");

    @JsonValue
    private final int val;

    private final String code;

    private final String symbol;

    private final String desc;

    MonthEnum(int val, String code, String symbol, String desc) {
        this.val = val;
        this.code = code;
        this.symbol = symbol;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static MonthEnum fromVal(int val) {
        return Arrays.stream(MonthEnum.values()).filter(item -> val == item.val).findFirst().orElse(null);
    }

    public static MonthEnum fromCode(String code) {
        return Arrays.stream(MonthEnum.values())
                .filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.code))
                .findFirst()
                .orElse(null);
    }

    public static MonthEnum fromSymbol(String symbol) {
        return Arrays.stream(MonthEnum.values())
                .filter(item -> StringUtils.isNotBlank(symbol) && symbol.equalsIgnoreCase(item.symbol))
                .findFirst()
                .orElse(null);
    }

}
