package com.ruoyi.gds.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

import java.io.Serializable;

@ConfigurationProperties(prefix = "ticket")
@Data
public class TicketConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    private String newestRateUri;

    private String findUserByIdsUri;

}
