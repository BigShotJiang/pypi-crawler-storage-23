package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

@Getter
public enum BusinessScene {

    GDS("GDS", "GDS"),
    TICKET("TICKET", "票务"),
    OTA("OTA", "OTA"),
    FLY("FLY", "自建站");

    @JsonValue
    private final String code;

    private final String desc;

    BusinessScene(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static BusinessScene fromCode(String code) {
        return Arrays.stream(BusinessScene.values())
                .filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.code))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }
    
}
