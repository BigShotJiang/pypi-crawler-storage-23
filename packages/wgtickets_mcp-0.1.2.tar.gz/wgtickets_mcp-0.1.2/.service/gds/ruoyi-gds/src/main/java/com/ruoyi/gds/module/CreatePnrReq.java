package com.ruoyi.gds.module;

import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.ValidatorUtil;
import com.ruoyi.gds.enums.BusinessScene;
import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.enums.PccType;
import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.gds.module.dto.FlightNumberCabinDto;
import com.ruoyi.gds.module.dto.galileo.SegementDto;
import com.ruoyi.gds.module.dto.galileo.TravelerDto;
import com.ruoyi.gds.module.dto.validation.AIR;
import com.ruoyi.gds.module.dto.validation.Galelio;
import com.ruoyi.gds.module.dto.validation.IBE;
import com.ruoyi.gds.module.vo.CreatePnrPreCheckResultVo;
import com.ruoyi.gds.module.vo.CreditCardVo;
import com.ruoyi.gds.module.vo.PolicyPriceVo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.assertj.core.util.Lists;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreatePnrReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 业务场景（GDS、TICKET、FLY...）。默认：TICKET
     */
    private BusinessScene businessScene;

    /**
     * 业务ID
     */
    private String businessId;

    /**
     * 预约记录ID
     */
    private Long reservationId;

    /**
     * 行程Key。 flightKey & flightFareKey 为 providerCode、segements 赋值
     */
    @NotBlank(message = "行程Key为空", groups = {AIR.class})
    private String flightKey;

    /**
     * 行程方案报价Key。 flightKey & flightFareKey 为 providerCode、segements 赋值
     */
    @NotBlank(message = "行程方案报价Key为空", groups = {AIR.class})
    private String flightFareKey;

    /**
     * 乘机人ID集合非空时，为 travelers 赋值
     */
    // @NotEmpty(message = "乘机人为空", groups = {AIR.class})
    private List<Long> travelerIds;


    /**
     * 伽利略使用。伽利略报价key
     */
    private String airPricingSolutionKey;

    /**
     * GDS类型。前端未传值时，根据 flightKey & flightFareKey 未此字段设置值
     */
    @NotNull(message = "GDS类型为空", groups = {Galelio.class, IBE.class})
    private GDSType providerCode;

    /**
     * 行程集合。前端未传值时，根据 flightKey & flightFareKey 未此字段设置值
     */
    @Valid
    @NotEmpty(message = "行程为空", groups = {IBE.class})
    private List<SegementDto> segements;

    /**
     * 出行人集合
     */
    @Valid
    @NotEmpty(message = "出行人为空", groups = {Galelio.class, IBE.class})
    private List<TravelerDto> travelers;

    /**
     * 预订预校验结果
     */
    private List<CreatePnrPreCheckResultVo> preCheckResults;

    /**
     * 预订预校验结果
     */
    @Deprecated
    private CreditCardVo creditCard;

    /**
     * GDS返回的原始报价信息
     */
    @Deprecated
    private String searchPriceRsp;

    /**
     * 预约PNR的PCC
     */
    private PccType pcc;

    /**
     * 指定航班舱位号
     */
    private List<@Valid FlightNumberCabinDto> cabins;

    /**
     * 成本价信息
     */
    private PolicyPriceVo policyPrice;

    /**
     * 是否使用 承运方(主飞) 航班查询。默认：false
     */
    private Boolean useOperating;

    public BusinessScene getBusinessScene() {
        return Optional.ofNullable(businessScene).orElse(BusinessScene.TICKET);
    }

    public List<SegementDto> getSegements() {
        return Optional.ofNullable(segements)
                .map(segementDtos -> segementDtos.stream().peek(segementDto -> {
                    segementDto.setSeq(segements.indexOf(segementDto) + 1);
                    segementDto.setProviderCode(providerCode);
                }).collect(Collectors.toList()))
                .orElse(Lists.newArrayList());
    }

    public List<TravelerDto> getTravelers() {
        return Optional.ofNullable(travelers)
                .map(travelerDtos -> travelerDtos.stream().peek(travelerDto -> travelerDto.setSeq(travelers.indexOf(travelerDto) + 1)).collect(Collectors.toList()))
                .orElse(Lists.newArrayList());
    }

    public Boolean getUseOperating() {
        return Optional.ofNullable(useOperating).orElse(false);
    }

    public void check() {
        check(providerCode);
    }

    public void check(GDSType gdsType) {
        String errMsg = ValidatorUtil.validate(this, gdsType.getCheckGroup());
        if (StringUtils.isNotBlank(errMsg)) {
            throw new InvalidParamException(errMsg);
        }

        Optional.ofNullable(getTravelers()).ifPresent(travelerList -> travelerList.forEach(travelerDto -> travelerDto.check(gdsType)));
    }

}
