package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum FlightTransferType {

    ORIGIN_TRANSFER(1, "出发地中转"),
    DESTINATION_TRANSFER(2, "目的地中转");

    @JsonValue
    private final Integer code;

    private final String desc;

    FlightTransferType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static FlightTransferType fromCode(Integer code) {
        return Arrays.stream(FlightTransferType.values()).filter(item -> Objects.nonNull(code) && Objects.equals(item.code, code)).findFirst().orElse(null);
    }

    public static FlightTransferType fromCode(String code) {
        return Arrays.stream(FlightTransferType.values()).filter(item -> StringUtils.isNotBlank(code) && String.valueOf(item.code).equalsIgnoreCase(code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
