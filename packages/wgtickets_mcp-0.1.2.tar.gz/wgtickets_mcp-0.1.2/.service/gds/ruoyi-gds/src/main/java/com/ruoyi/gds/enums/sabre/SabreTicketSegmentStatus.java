package com.ruoyi.gds.enums.sabre;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.enums.TicketSegmentStatus;
import com.ruoyi.gds.utils.StrUtil;
import lombok.Getter;

import java.util.Arrays;

/**
 * 票航段状态
 */
@Getter
public enum SabreTicketSegmentStatus {

    AIRPORT_CONTROL("AL", null,""),
    LIFTED("BD", null, ""),
    CHECKED_IN("CK", null, ""),
    EXCHANGED("E", TicketSegmentStatus.EXCHANGED, ""),
    FLOWN("B", null, ""),
    NOT_FLOWN("I", TicketSegmentStatus.OPEN, ""),
    REFUNDED("RF", TicketSegmentStatus.REFUNDED, ""),
    VOIDED("V", TicketSegmentStatus.VOID, ""),
    PRINTED("PR", null, ""),
    OKAY("O", TicketSegmentStatus.OPEN, ""),
    REACTIVATED("P", null, ""),
    IRREGULAR_OPERATIONS("IO", null, ""),
    PRINT_EXCHANGE("PE", null, ""),
    PAPER_TICKET("T", null, ""),
    SUSPENDED("S", null, ""),
    LOCKED("XX", null, "");

    private final String code;

    @JsonValue
    private final TicketSegmentStatus ticketSegmentStatus;

    private final String desc;

    SabreTicketSegmentStatus(String code, TicketSegmentStatus ticketSegmentStatus, String desc) {
        this.code = code;
        this.ticketSegmentStatus = ticketSegmentStatus;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static SabreTicketSegmentStatus fromCode(String code) {
        if (StringUtils.isBlank(code)) return null;
        return Arrays.stream(SabreTicketSegmentStatus.values())
                .filter(item -> StringUtils.isNotBlank(code) && StrUtil.removeWhiteSpaces(code).equalsIgnoreCase(StrUtil.removeWhiteSpaces(item.code)))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
