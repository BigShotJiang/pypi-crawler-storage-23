package com.ruoyi.gds.aspect;


import com.ruoyi.framework.manager.AsyncManager;
import com.ruoyi.gds.annotation.FlightLog;
import com.ruoyi.gds.module.domain.FlightReqLog;
import com.ruoyi.gds.service.IFlightReqLogService;
import com.ruoyi.gds.utils.ContextUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

@Aspect
@Component
@Slf4j
public class FlightLogAspect {

    @Autowired
    private IFlightReqLogService flightReqLogService;

    @Before("@annotation(flightLog)")
    public void beforeAdvice(FlightLog flightLog) {
        FlightReqLog flightReqLog = FlightReqLog.builder()
                .userId(ContextUtil.getUserId())
                .type(flightLog.type().getCode())
                .createTime(LocalDateTime.now())
                .build();
        AsyncManager.me().execute(() -> flightReqLogService.insertFlightReqLog(flightReqLog));
    }

}
