package com.ruoyi.gds.config;

import com.ruoyi.gds.interceptor.UserInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    private UserInterceptor userInterceptor;

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(userInterceptor)
                .addPathPatterns("/air/**", "/flight/**", "/rate/**")
                .excludePathPatterns("/air/ibe/forward/**")
                .excludePathPatterns("/air/score/**", "/airChange/**", "/dataRepair/**")
                .excludePathPatterns("/air/eightYi/**","/air/huanYu/**")
                .excludePathPatterns("/system/**");
    }

}
