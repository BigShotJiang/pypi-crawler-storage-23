package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

@Getter
public enum FczAirchangeCustomErrorCode {
    FAIL("-1", "定制失败"),  // 此项为自定义，非飞常准代码
    USER_NOT_EXIST("0", "用户不存在"),
    WAIT_AUDIT_USER("1", "待审核用户"),
    NOT_IN_IP_WHITELIST("2", "当前访问ip尚未加入白名单"),
    PARAM_VALID_FAIL("3", "缺少参数或参数验证失败"),
    NO_PERMISSION_OR_NO_LINK("4", "暂无数据权限 或 推送链接不存在"),
    NO_FLIGHT("5", "没有满足条件的航班"),
    CUSTOMIZED("6", "不能重复定制"),
    PUSH_CUSTOM_FAIL("7", "推送定制失败"),
    SUCCESS("8", "定制成功"),
    NO_DATA("10", "暂无数据"),
    UNKNOW("11", "未知错误");

    @JsonValue
    private final String errorCode;

    private final String desc;

    FczAirchangeCustomErrorCode(String errorCode, String desc) {
        this.errorCode = errorCode;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static FczAirchangeCustomErrorCode fromErrorCode(String errorCode) {
        return Arrays.stream(FczAirchangeCustomErrorCode.values())
                .filter(item -> StringUtils.isNotBlank(errorCode) && errorCode.equalsIgnoreCase(item.errorCode))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return errorCode + ": " + desc;
    }
    
}
