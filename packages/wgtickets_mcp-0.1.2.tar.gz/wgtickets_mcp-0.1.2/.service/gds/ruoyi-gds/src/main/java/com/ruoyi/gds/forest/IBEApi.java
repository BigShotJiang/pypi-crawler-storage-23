package com.ruoyi.gds.forest;

import com.dtflys.forest.annotation.*;
import com.dtflys.forest.http.ForestResponse;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.enums.BusinessType;
import com.ruoyi.gds.forest.interceptor.IBEInterceptor;
import org.springframework.stereotype.Component;

@Component
@BaseRequest(baseURL = "${ibe_baseurl}", interceptor = IBEInterceptor.class)
public interface IBEApi {

//    /**
//     * 发送请求
//     *
//     * @param url
//     * @param compressedBody
//     * @return
//     */
//    @Post(url = "${url}")
//    String send(@Var("url") String url, @Body byte[] compressedBody);

    /**
     * 发送请求
     *
     * @param url
     * @param compressedBody
     * @return
     */
    @Post(url = "${url}")
    String send(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                @Var("url") String url,
                @Body byte[] compressedBody);


    /**
     * 发送请求
     *
     * @param url
     * @param compressedBody
     * @return
     */
    @Post(url = "${url}")
    ForestResponse<String> send2(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                                 @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                                 @Var("url") String url,
                                 @Body byte[] compressedBody);

}
