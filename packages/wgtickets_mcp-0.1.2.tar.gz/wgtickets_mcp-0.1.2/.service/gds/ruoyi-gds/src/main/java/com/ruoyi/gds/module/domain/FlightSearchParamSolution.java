package com.ruoyi.gds.module.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 搜索条件对应的行程方案对象 flight_search_param_solution
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightSearchParamSolution implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 搜索条件Key。MD5值
     */
    @Excel(name = "搜索条件Key。MD5值")
    private String searchParamKey;

    /**
     * 行程方案Key
     */
    @Excel(name = "行程方案Key")
    private String solutionKey;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 是否已删除（false：未删除，true：已删除）
     */
    private boolean delFlag;

}
