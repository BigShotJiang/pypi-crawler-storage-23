package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.WgGalileoKey;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 歪裹Key与伽利略Key对照Mapper接口
 * 
 * @author ruoyi
 * @date 2025-10-29
 */
public interface WgGalileoKeyMapper extends BaseMapper<WgGalileoKey>
{
    /**
     * 查询歪裹Key与伽利略Key对照
     * 
     * @param id 歪裹Key与伽利略Key对照主键
     * @return 歪裹Key与伽利略Key对照
     */
    public WgGalileoKey selectWgGalileoKeyById(Long id);

    /**
     * 查询歪裹Key与伽利略Key对照列表
     * 
     * @param wgGalileoKey 歪裹Key与伽利略Key对照
     * @return 歪裹Key与伽利略Key对照集合
     */
    public List<WgGalileoKey> selectWgGalileoKeyList(WgGalileoKey wgGalileoKey);

    /**
     * 新增歪裹Key与伽利略Key对照
     * 
     * @param wgGalileoKey 歪裹Key与伽利略Key对照
     * @return 结果
     */
    public int insertWgGalileoKey(WgGalileoKey wgGalileoKey);

    /**
     * 修改歪裹Key与伽利略Key对照
     * 
     * @param wgGalileoKey 歪裹Key与伽利略Key对照
     * @return 结果
     */
    public int updateWgGalileoKey(WgGalileoKey wgGalileoKey);

    /**
     * 删除歪裹Key与伽利略Key对照
     * 
     * @param id 歪裹Key与伽利略Key对照主键
     * @return 结果
     */
    public int deleteWgGalileoKeyById(Long id);

    /**
     * 批量删除歪裹Key与伽利略Key对照
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteWgGalileoKeyByIds(Long[] ids);

    /**
     * 批量写入，重复时跳过
     * @param wgGalileoKeys
     * @return
     */
    int batchInsert(@Param("wgGalileoKeys") List<WgGalileoKey> wgGalileoKeys);

    /**
     * 批量更新
     * @param wgGalileoKeys
     * @return
     */
    int batchUpdate(@Param("wgGalileoKeys") List<WgGalileoKey> wgGalileoKeys);

}
