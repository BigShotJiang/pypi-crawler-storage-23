package com.ruoyi.gds.module.domain;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigInteger;
import java.time.LocalDateTime;

/**
 * 搜索航班结果对象 flight
 * 
 * @author ruoyi
 * @date 2025-04-14
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Flight implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 批次号 */
    @Excel(name = "批次号")
    private String batchCode;

    /** 行程类型 */
    @Excel(name = "行程类型", readConverterExp = "0=：单程，1：往返，2：多程")
    private Integer tripType;

    /** 总行程编号（同一行程(包含去程、回程等)中的所有航段的flight_key相同） */
    @Excel(name = "总行程编号", readConverterExp = "同=一行程(包含去程、回程等)中的所有航段的flight_key相同")
    private String flightKey;

    /** 三方行程Key */
    @Excel(name = "三方行程Key")
    private String segmentKey;

    /** 行程类型（0：去程，1：回程） */
    @Excel(name = "行程类型", readConverterExp = "0=：去程，1：回程")
    @TableField("`group`")
    private Integer group;

    /** 航段顺序 */
    @Excel(name = "航段顺序")
    private Integer seq;

    /** 市场方航司 */
    @Excel(name = "市场方航司")
    private String carrier;

    /** 市场方航班号 */
    @Excel(name = "市场方航班号")
    private String flightNumber;

    /** 承运方航司 */
    @Excel(name = "承运方航司")
    private String operatingCarrier;

    /** 承运方航班号 */
    @Excel(name = "承运方航班号")
    private String operatingFlightNumber;

    /** 出发机场三字码 */
    @Excel(name = "出发机场三字码")
    private String origin;

    /** 到达机场三字码 */
    @Excel(name = "到达机场三字码")
    private String destination;

    /** 出发时间 */
    @Excel(name = "出发时间")
    private String departureTime;

    /** 到达时间 */
    @Excel(name = "到达时间")
    private String arrivalTime;

    /** 飞行时长。单位分钟 */
    @Excel(name = "飞行时长。单位分钟")
    private Integer flightTime;

    /** 距离 */
    @Excel(name = "距离")
    private BigInteger distance;

    /** 机型 */
    @Excel(name = "机型")
    private String equipment;

    /**  */
    @Excel(name = "")
    private Boolean changeOfPlane;

    /** 服务等级（舱位等级） */
    @Excel(name = "服务等级", readConverterExp = "舱位等级")
    private String classOfService;

    /** 创建者ID */
    @Excel(name = "创建者ID")
    private Long createUserId;

    /** 创建者 */
    @Excel(name = "创建者")
    private String createBy;

    /** 创建时间 */
    @Excel(name = "创建时间", width = 30, dateFormat = "yyyy-MM-dd")
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("batchCode", getBatchCode())
            .append("flightKey", getFlightKey())
            .append("segmentKey", getSegmentKey())
            .append("group", getGroup())
            .append("seq", getSeq())
            .append("carrier", getCarrier())
            .append("flightNumber", getFlightNumber())
            .append("operatingCarrier", getOperatingCarrier())
            .append("operatingFlightNumber", getOperatingFlightNumber())
            .append("origin", getOrigin())
            .append("destination", getDestination())
            .append("departureTime", getDepartureTime())
            .append("arrivalTime", getArrivalTime())
            .append("flightTime", getFlightTime())
            .append("distance", getDistance())
            .append("equipment", getEquipment())
            .append("changeOfPlane", getChangeOfPlane())
            .append("classOfService", getClassOfService())
            .append("createTime", getCreateTime())
            .append("delFlag", isDelFlag())
            .toString();
    }
}
