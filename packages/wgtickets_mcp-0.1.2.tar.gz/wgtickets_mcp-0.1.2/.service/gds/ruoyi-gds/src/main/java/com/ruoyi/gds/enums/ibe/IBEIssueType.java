package com.ruoyi.gds.enums.ibe;

public enum IBEIssueType {

    BSP,

    BOP

}
