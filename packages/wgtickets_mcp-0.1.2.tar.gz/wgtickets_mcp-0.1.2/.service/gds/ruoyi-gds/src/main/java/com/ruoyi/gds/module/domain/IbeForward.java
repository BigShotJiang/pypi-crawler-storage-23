package com.ruoyi.gds.module.domain;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * IBE预定记录（转发IBE请求用）对象 ibe_forward
 * 
 * @author ruoyi
 * @date 2025-04-22
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IbeForward implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 转发平台 */
    @Excel(name = "转发平台")
    private String platform;

    /** IBE预订成功后返回的pnr */
    @Excel(name = "IBE预订成功后返回的pnr")
    private String pnr;

    /** IBE预订成功后返回的orderNo */
    @Excel(name = "IBE预订成功后返回的orderNo")
    private String orderNo;

    /** 创建时间 */
    @Excel(name = "创建时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;

    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("platform", getPlatform())
            .append("pnr", getPnr())
            .append("orderNo", getOrderNo())
            .append("createTime", getCreateTime())
            .append("delFlag", isDelFlag())
            .toString();
    }
}
