package com.ruoyi.gds.module.dto.galileo;

import com.ruoyi.common.utils.ValidatorUtil;
import com.ruoyi.gds.exception.InvalidParamException;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CancelPnrDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PNR码
     */
    @NotBlank(message = "PNR为空")
    private String pnr;

    /**
     * Universal Record 预定码
     */
    private String locatorCode;

    /**
     * Universal Record 预定码版本
     */
    private Integer version;


    public void check(){
        String errMsg = ValidatorUtil.validate(this);
        if (StringUtils.isNotBlank(errMsg)) {
            throw new InvalidParamException(errMsg);
        }
    }
    
}
