package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum PassengerType {

    ADT(1, "ADT", "成人. 12岁及以上的乘客"),
    CNN(2, "CNN", "儿童. 2岁至11岁的乘客. IBE & 伽利略"),
    CHD(3, "CHD", "儿童. 2岁至11岁的乘客. IBE"),
    INF(4, "INF", "婴儿. 2岁以下的乘客");

    private final Integer num;

    @JsonValue
    private final String code;

    private final String description;

    PassengerType(Integer num, String code, String description) {
        this.num = num;
        this.code = code;
        this.description = description;
    }

    public static PassengerType fromNum(Integer num) {
        return Arrays.stream(PassengerType.values()).filter(item -> Objects.nonNull(num) && num.equals(item.num)).findFirst().orElse(null);
    }

    /**
     * 根据八千翼乘客类型编码获取乘客类型
     * 八千翼编码：1=成人，2=儿童，3=婴儿
     */
    public static PassengerType fromEightYiCode(String code) {
        if ("1".equals(code)) {
            return ADT;
        } else if ("2".equals(code)) {
            return CNN; // 八千翼的儿童对应CHD
        } else if ("3".equals(code)) {
            return INF;
        }
        return ADT; // 默认成人
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static PassengerType fromCode(String code) {
        return Arrays.stream(PassengerType.values()).filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + description;
    }

}
