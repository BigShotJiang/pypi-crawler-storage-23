package com.ruoyi.gds.module;

import cn.hutool.core.collection.CollectionUtil;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.ValidatorUtil;
import com.ruoyi.gds.enums.BusinessScene;
import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.enums.PccType;
import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.gds.module.dto.CreatePnrPriceVo;
import com.ruoyi.gds.module.dto.galileo.SegementDto;
import com.ruoyi.gds.module.dto.galileo.TravelerDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CreateNewPnrByFlightReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 业务场景
     */
    private BusinessScene businessScene;

    /**
     * 业务ID
     */
    private String businessId;

    /**
     * 新PNR所属PCC
     */
    @NotNull(message = "预定PCC为空")
    private PccType newPnrPcc;

    /**
     * 行程集合
     */
    @Valid
    @NotEmpty(message = "行程为空")
    private List<SegementDto> segements;

    /**
     * 出行人集合
     */
    @Valid
    private List<TravelerDto> travelers;

    /**
     * 出行人ID集合
     */
    private List<Long> travelerIds;

    /**
     * 价格信息
     */
    @Valid
    private CreatePnrPriceVo price;


    public void check() {
        check(newPnrPcc.getGds());
    }

    public void check(GDSType gdsType) {
        String errMsg = ValidatorUtil.validate(this, gdsType.getCheckGroup());
        if (StringUtils.isNotBlank(errMsg)) {
            throw new InvalidParamException(errMsg);
        }

        Optional.ofNullable(getTravelers()).ifPresent(travelerList -> travelerList.forEach(travelerDto -> travelerDto.check(gdsType)));

        if (CollectionUtil.isEmpty(getTravelers()) && CollectionUtil.isEmpty(getTravelerIds())) throw new InvalidParamException("乘机人为空");
    }

}
