package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum FlightSearchOptionType {

    DEPARTURE_AIRPORT(1, "出发机场", "departure_airport"),
    ARRIVAL_AIRPORT(2, "到达机场", "arrival_airport"),
    TRANSFER_CITY(3, "中转城市", "transfer_airports"),
    CARBIN(4, "舱位等级", "cabins"),
    CARRIER(5, "航空公司", "carriers");

    @JsonValue
    private final Integer code;

    private final String desc;

    private final String colum;

    FlightSearchOptionType(Integer code, String desc, String colum) {
        this.code = code;
        this.desc = desc;
        this.colum = colum;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static FlightSearchOptionType fromCode(Integer code) {
        return Arrays.stream(FlightSearchOptionType.values()).filter(item -> Objects.nonNull(code) && Objects.equals(item.code, code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
