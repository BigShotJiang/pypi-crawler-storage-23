package com.ruoyi.gds.mapper;

import com.ruoyi.gds.module.domain.CallbackRecord;

import java.util.List;

/**
 * 回调记录Mapper接口
 *
 * @author ruoyi
 * @date 2025-12-12
 */
public interface CallbackRecordMapper
{
    /**
     * 查询回调记录
     *
     * @param orderSn 回调记录主键
     * @return 回调记录
     */
    public CallbackRecord selectCallbackRecordByOrderSn(String orderSn);

    /**
     * 查询回调记录列表
     *
     * @param callbackRecord 回调记录
     * @return 回调记录集合
     */
    public List<CallbackRecord> selectCallbackRecordList(CallbackRecord callbackRecord);

    /**
     * 新增回调记录
     *
     * @param callbackRecord 回调记录
     * @return 结果
     */
    public int insertCallbackRecord(CallbackRecord callbackRecord);

    /**
     * 修改回调记录
     *
     * @param callbackRecord 回调记录
     * @return 结果
     */
    public int updateCallbackRecord(CallbackRecord callbackRecord);

    /**
     * 删除回调记录
     *
     * @param id 回调记录主键
     * @return 结果
     */
    public int deleteCallbackRecordById(Long id);

    /**
     * 批量删除回调记录
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteCallbackRecordByIds(Long[] ids);
}
