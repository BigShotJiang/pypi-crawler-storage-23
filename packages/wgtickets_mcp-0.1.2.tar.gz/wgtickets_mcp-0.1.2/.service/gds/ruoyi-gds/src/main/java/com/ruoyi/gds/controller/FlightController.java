package com.ruoyi.gds.controller;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.gds.module.domain.Flight;
import com.ruoyi.gds.service.IFlightService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 搜索航班结果Controller
 * 
 * @author ruoyi
 * @date 2025-04-14
 */
@RestController
@RequestMapping("/flight")
public class FlightController extends BaseController
{
    @Autowired
    private IFlightService flightService;

    /**
     * 查询搜索航班结果列表
     */
    @GetMapping("/list")
    public TableDataInfo list(Flight flight)
    {
        startPage();
        List<Flight> list = flightService.selectFlightList(flight);
        return getDataTable(list);
    }

    /**
     * 导出搜索航班结果列表
     */
    @PostMapping("/export")
    public void export(HttpServletResponse response, Flight flight)
    {
        List<Flight> list = flightService.selectFlightList(flight);
        ExcelUtil<Flight> util = new ExcelUtil<Flight>(Flight.class);
        util.exportExcel(response, list, "搜索航班结果数据");
    }

    /**
     * 获取搜索航班结果详细信息
     */
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(flightService.selectFlightById(id));
    }

    /**
     * 新增搜索航班结果
     */
    @PostMapping
    public AjaxResult add(@RequestBody Flight flight)
    {
        return toAjax(flightService.insertFlight(flight));
    }

    /**
     * 修改搜索航班结果
     */
    @PutMapping
    public AjaxResult edit(@RequestBody Flight flight)
    {
        return toAjax(flightService.updateFlight(flight));
    }

    /**
     * 删除搜索航班结果
     */
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(flightService.deleteFlightByIds(ids));
    }
}
