package com.ruoyi.gds.module.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 行程方案对象 flight_solution
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightSolution implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 行程方案Key（所有航段的 市场方航司+市场方航班号+承运官方航司+承运方航班号+出发机场三字码+到达机场三字码+出发时间+到达时间 的MD5值）
     */
    @Excel(name = "行程方案Key", readConverterExp = "所=有航段的,市=场方航司+市场方航班号+承运官方航司+承运方航班号+出发机场三字码+到达机场三字码+出发时间+到达时间,的=MD5值")
    private String solutionKey;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 是否已删除（false：未删除，true：已删除）
     */
    private boolean delFlag;
}
