package com.ruoyi.gds.forest;

import com.dtflys.forest.annotation.*;
import com.ruoyi.gds.module.vo.*;
import org.springframework.stereotype.Component;

import java.util.List;


@Component
@BaseRequest(baseURL = "${ota_base_url}")
public interface OtaApi {

    /**
     *票号回填
     */
    @Post(url = "/notice/orders/gdsUpdateTicketNo")
    String gdsUpdateTicketNo(@JSONBody List<FinTicket> tickets);
}
