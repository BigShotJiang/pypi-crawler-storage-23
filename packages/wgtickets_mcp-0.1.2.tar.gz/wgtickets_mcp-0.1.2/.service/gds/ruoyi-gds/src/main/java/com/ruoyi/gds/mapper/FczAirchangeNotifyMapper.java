package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FczAirchangeNotify;

import java.util.List;

/**
 * 飞常准—航变通知记录Mapper接口
 * 
 * @author ruoyi
 * @date 2025-11-18
 */
public interface FczAirchangeNotifyMapper extends BaseMapper<FczAirchangeNotify>
{
    /**
     * 查询飞常准—航变通知记录
     * 
     * @param id 飞常准—航变通知记录主键
     * @return 飞常准—航变通知记录
     */
    public FczAirchangeNotify selectFczAirchangeNotifyById(Long id);

    /**
     * 查询飞常准—航变通知记录列表
     * 
     * @param fczAirchangeNotify 飞常准—航变通知记录
     * @return 飞常准—航变通知记录集合
     */
    public List<FczAirchangeNotify> selectFczAirchangeNotifyList(FczAirchangeNotify fczAirchangeNotify);

    /**
     * 新增飞常准—航变通知记录
     * 
     * @param fczAirchangeNotify 飞常准—航变通知记录
     * @return 结果
     */
    public int insertFczAirchangeNotify(FczAirchangeNotify fczAirchangeNotify);

    /**
     * 修改飞常准—航变通知记录
     * 
     * @param fczAirchangeNotify 飞常准—航变通知记录
     * @return 结果
     */
    public int updateFczAirchangeNotify(FczAirchangeNotify fczAirchangeNotify);

    /**
     * 删除飞常准—航变通知记录
     * 
     * @param id 飞常准—航变通知记录主键
     * @return 结果
     */
    public int deleteFczAirchangeNotifyById(Long id);

    /**
     * 批量删除飞常准—航变通知记录
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFczAirchangeNotifyByIds(Long[] ids);
}
