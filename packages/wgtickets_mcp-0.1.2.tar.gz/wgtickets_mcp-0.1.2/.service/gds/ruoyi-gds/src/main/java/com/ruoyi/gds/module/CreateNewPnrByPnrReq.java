package com.ruoyi.gds.module;

import com.ruoyi.gds.enums.BusinessScene;
import com.ruoyi.gds.enums.PccType;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class CreateNewPnrByPnrReq extends QueryPnrInfoReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 业务场景
     */
    private BusinessScene businessScene;

    /**
     * 业务ID
     */
    private String businessId;

    /**
     * 新PNR所属PCC
     */
    @NotNull(message = "重新预定PCC为空")
    private PccType newPnrPcc;

}
