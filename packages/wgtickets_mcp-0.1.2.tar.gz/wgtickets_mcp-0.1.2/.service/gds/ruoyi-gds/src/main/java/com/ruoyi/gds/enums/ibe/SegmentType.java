package com.ruoyi.gds.enums.ibe;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum SegmentType {

    NORMAL("NORMAL", "普通航段"),
    OPEN("OPEN", "不定期航段"),
    ARRIVAL_UNKOWN_ARNK("ARRIVAL_UNKOWN-ARNK", "信息航段");

    @JsonValue
    private final String code;

    private final String description;

    SegmentType(String code, String description) {
        this.code = code;
        this.description = description;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static SegmentType fromCode(String code) {
        return Arrays.stream(SegmentType.values()).filter(item -> StringUtils.isNotBlank(code) && item.code.equalsIgnoreCase(code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + description;
    }

}
