package com.ruoyi.gds.module.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * 行程方案航段对象 flight_solution_segment
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightSolutionSegment implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 行程方案Key
     */
    @Excel(name = "行程方案Key")
    private String solutionKey;

    /**
     * 航段Key
     */
    @Excel(name = "航段Key")
    private String segmentKey;

    /**
     * 行程序号
     */
    @Excel(name = "行程序号")
    private Integer group;

    /**
     * 航段序号
     */
    @Excel(name = "航段序号")
    private Integer seq;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 是否已删除（false：未删除，true：已删除）
     */
    private boolean delFlag;

}
