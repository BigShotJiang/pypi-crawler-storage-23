package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.enums.FlightSearchOptionType;
import com.ruoyi.gds.module.SearchFlightReq;
import com.ruoyi.gds.module.domain.FlightStatistic;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 航班统计Mapper接口
 * 
 * @author ruoyi
 * @date 2025-04-14
 */
public interface FlightStatisticMapper extends BaseMapper<FlightStatistic>
{
    /**
     * 查询航班统计
     * 
     * @param id 航班统计主键
     * @return 航班统计
     */
    public FlightStatistic selectFlightStatisticById(Long id);

    /**
     * 查询航班统计列表
     * 
     * @param flightStatistic 航班统计
     * @return 航班统计集合
     */
    public List<FlightStatistic> selectFlightStatisticList(FlightStatistic flightStatistic);

    /**
     * 新增航班统计
     * 
     * @param flightStatistic 航班统计
     * @return 结果
     */
    public int insertFlightStatistic(FlightStatistic flightStatistic);

    /**
     * 修改航班统计
     * 
     * @param flightStatistic 航班统计
     * @return 结果
     */
    public int updateFlightStatistic(FlightStatistic flightStatistic);

    /**
     * 删除航班统计
     * 
     * @param id 航班统计主键
     * @return 结果
     */
    public int deleteFlightStatisticById(Long id);

    /**
     * 批量删除航班统计
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightStatisticByIds(Long[] ids);

    /**
     * 多条件搜索航班号
     * @param searchFlightReq
     * @return
     */
    List<String> searchFlight(SearchFlightReq searchFlightReq);

    /**
     * 搜索条件选项
     * @param batchCode
     * @param searchOptionType
     * @return
     */
    List<String> options(@Param("batchCode") String batchCode, @Param("searchOptionType") FlightSearchOptionType searchOptionType);

}
