package com.ruoyi.gds.enums;

import lombok.Getter;

@Getter
public enum TimeUnitType {

    SECOND,

    MINUTE,

    HOUR,

    DAY,

    MONTH,

    YEAR

}
