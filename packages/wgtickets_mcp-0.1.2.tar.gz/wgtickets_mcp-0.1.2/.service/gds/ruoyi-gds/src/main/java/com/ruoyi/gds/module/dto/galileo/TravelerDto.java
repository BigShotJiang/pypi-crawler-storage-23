package com.ruoyi.gds.module.dto.galileo;

import cn.hutool.core.date.DatePattern;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.common.ParamValidRegex;
import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.enums.GenderType;
import com.ruoyi.gds.enums.PassengerType;
import com.ruoyi.gds.enums.ibe.CertificateType;
import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.gds.module.dto.validation.Galelio;
import com.ruoyi.gds.module.dto.validation.IBE;
import com.ruoyi.common.utils.ValidatorUtil;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.Objects;
import java.util.regex.Pattern;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TravelerDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 出行人序号。非前端传参，后端设置值
     */
    private Integer seq;

    /**
     * 出行人类型
     */
    @NotNull(message = "出行人类型为空", groups = {Galelio.class, IBE.class})
    private PassengerType travelerType;

    /**
     * 出行人姓名——姓
     */
    /*@NotBlank(message = "出行人姓氏为空", groups = {Galelio.class, IBE.class})*/
    private String travelerFirstName;

    /**
     * 出行人姓名——名
     */
    @NotBlank(message = "出行人名字为空", groups = {Galelio.class, IBE.class})
    private String travelerLastName;

    /**
     * 出行人——证件类型
     */
    @NotNull(message = "出行人证件类型为空", groups = {Galelio.class, IBE.class})
    private CertificateType certificateType;

    /**
     * 出行人——证件号
     */
    @NotBlank(message = "出行人证件号为空", groups = {Galelio.class, IBE.class})
    private String certificate;

    /**
     * 出行人——发证国家
     */
    private String certificateCountry;

    /**
     * 出行人——持证人国籍
     */
    private String certificateOwnerCountry;

    /**
     * 出行人——证件有效期截止日期
     */
    private LocalDate expireDate;

    /**
     * 出行人手机号
     */
    @NotBlank(message = "出行人手机号为空", groups = {Galelio.class, IBE.class})
    private String phone;

    /**
     * 出行人邮箱
     */
    private String email;

    /**
     * 出行人性别
     */
    @NotNull(message = "出行人性别为空", groups = {Galelio.class, IBE.class})
    private GenderType gender;

    /**
     * 出行人生日 / 持证人生日
     */
    @NotNull(message = "出行人生日为空")
    @DateTimeFormat(pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATE_PATTERN)
    @JsonSerialize(using = LocalDateSerializer.class)
    @JsonDeserialize(using = LocalDateDeserializer.class)
    private LocalDate birthDay;

    /**
     * 紧急联系人手机号
     */
    private String emergencyPhone;

    /**
     * 紧急联系人邮箱
     */
    private String emergencyEmail;


    public void check(GDSType gdsType) {
        String errMsg = ValidatorUtil.validate(this, gdsType.getCheckGroup());
        if (StringUtils.isNotBlank(errMsg)) {
            throw new InvalidParamException(errMsg);
        }

        /*if (StringUtils.isBlank(getEmergencyPhone()) && StringUtils.isBlank(getEmergencyEmail())) {
            throw new InvalidParamException("请指定紧急联系人电话或邮箱");
        }*/

        if (StringUtils.isNotBlank(getPhone()) && !Pattern.matches(ParamValidRegex.PHONE_WITH_ZONE, getPhone())) {
            throw new InvalidParamException("出行人手机号仅支持中国大陆和日本手机号");
        }

        if (StringUtils.isNotBlank(getEmergencyPhone()) && !Pattern.matches(ParamValidRegex.PHONE_WITH_ZONE, getEmergencyPhone())) {
            throw new InvalidParamException("紧急联系人手机号仅支持中国大陆和日本手机号");
        }

        if (CertificateType.P == getCertificateType()) {
            if (StringUtils.isBlank(getCertificateCountry())) {
                throw new InvalidParamException("发证国家为空");
            }
            if (StringUtils.isBlank(getCertificateOwnerCountry())) {
                throw new InvalidParamException("持证人国籍为空");
            }
            if (Objects.isNull(getExpireDate())) {
                throw new InvalidParamException("证件有效期为空");
            }
            if (Objects.isNull(getBirthDay())) {
                throw new InvalidParamException("持证人出生日期为空");
            }
        }
    }

}
