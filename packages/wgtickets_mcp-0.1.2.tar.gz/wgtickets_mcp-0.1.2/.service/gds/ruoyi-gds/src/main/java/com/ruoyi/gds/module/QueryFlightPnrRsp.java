package com.ruoyi.gds.module;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class QueryFlightPnrRsp implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 票面价
     */
    private String baseFare;

    /**
     * 税项
     */
    private String rateItem;

    /**
     * 总价
     */
    private String  totalPrice;


    private String fareCalculation;

    /**
     * 行李额
     */
    private String carryOn;

    /**
     * 运价类型
     */
    private String passengerTypeCode;

    /**
     * EI项
     */
    private String eiItem;

    /**
     * 支付方式
     */
    private String paymentType;

    /**
     * 运价保存时间
     */
    private String fareSaveTime;

    /**
     * 运价代码
     */
    private String fareCode;

}
