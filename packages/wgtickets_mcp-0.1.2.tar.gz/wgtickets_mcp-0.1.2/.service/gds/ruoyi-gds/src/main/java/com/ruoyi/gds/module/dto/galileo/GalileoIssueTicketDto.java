package com.ruoyi.gds.module.dto.galileo;

import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.ValidatorUtil;
import com.ruoyi.gds.enums.GalileoIssueType;
import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.gds.module.vo.CreditCardVo;
import com.ruoyi.gds.schema.galileo.air_v50_0.AirPricingInfo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.compress.utils.Lists;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GalileoIssueTicketDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PNR（又称：Host预订代码）
     *
     * ProviderReservationInfo.LocatorCode
     */
    @NotBlank(message = "PNR为空")
    private String pnr;

    /**
     * Universal Record 预订代码
     *
     * UniversalRecord.LocatorCode
     */
    @NotBlank(message = "Universal Record 预订代码为空")
    private String universalCode;

    /**
     * Air预定代码
     *
     * AirReservation.LocatorCode
     */
    @NotBlank(message = "Air预定代码为空")
    private String reservationCode;

    /**
     * PNR版本
     *
     * UniversalRecord.Version
     */
    @NotNull(message = "PNR版本为空")
    @Min(value = 0, message = "PNR版本错误")
    private Integer version;

    /**
     * 前返
     */
    private BigDecimal commission;

    /**
     * TC代码
     */
    private String tourCode;

    /**
     * 出票支付方式
     */
    private GalileoIssueType issueType;

    /**
     * 信用卡信息
     */
    private CreditCardVo creditCard;

    /**
     * 是否更新PNR保存的报价
     */
    private Boolean needUpdatePnrPrice;

    /**
     * PNR已保存的报价信息KEY集合。删除报价时传值
     */
    private List<String> airPricingInfoKeys;

    /**
     * 需要保存到PNR的报价信息集合。添加报价时传值
     */
    private List<AirPricingInfo> airPricingInfos;

    /**
     * 行程航司及舱位
     */
    private List<CarrierCabin> carrierCabins;


    public GalileoIssueType getIssueType() {
        return Optional.ofNullable(issueType).orElse(GalileoIssueType.Cash);
    }

    public void check() {
        String errMsg = ValidatorUtil.validate(this);
        if (StringUtils.isNotBlank(errMsg)) {
            throw new InvalidParamException(errMsg);
        }
    }

    public List<CarrierCabin> getCarrierCabins() {
        return Optional.ofNullable(carrierCabins).orElse(Lists.newArrayList());
    }



    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CarrierCabin implements Serializable {

        private String carrier;

        private List<String> cabins;

    }

}
