package com.ruoyi.gds.module.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QueryFareKeyScanDto implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotEmpty(message = "报价Key为空")
    private List<String> flightFareKeys;

}
