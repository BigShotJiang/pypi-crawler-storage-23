package com.ruoyi.gds.module;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class QueryTicketNumberInfoReq extends QueryPnrInfoReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 票号
     */
    private List<String> ticketNumbers;

}
