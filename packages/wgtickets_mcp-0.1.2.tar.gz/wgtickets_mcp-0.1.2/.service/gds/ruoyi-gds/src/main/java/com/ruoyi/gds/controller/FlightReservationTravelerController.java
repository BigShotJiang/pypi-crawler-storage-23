package com.ruoyi.gds.controller;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.gds.module.domain.FlightReservationTraveler;
import com.ruoyi.gds.service.IFlightReservationTravelerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 航班预定关联乘机人Controller
 * 
 * @author ruoyi
 * @date 2025-04-18
 */
@RestController
@RequestMapping("/flight/reservation/traveler")
public class FlightReservationTravelerController extends BaseController
{
    @Autowired
    private IFlightReservationTravelerService flightReservationTravelerService;

    /**
     * 查询航班预定关联乘机人列表
     */
    @GetMapping("/list")
    public TableDataInfo list(FlightReservationTraveler flightReservationTraveler)
    {
        startPage();
        List<FlightReservationTraveler> list = flightReservationTravelerService.selectFlightReservationTravelerList(flightReservationTraveler);
        return getDataTable(list);
    }

    /**
     * 导出航班预定关联乘机人列表
     */
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightReservationTraveler flightReservationTraveler)
    {
        List<FlightReservationTraveler> list = flightReservationTravelerService.selectFlightReservationTravelerList(flightReservationTraveler);
        ExcelUtil<FlightReservationTraveler> util = new ExcelUtil<FlightReservationTraveler>(FlightReservationTraveler.class);
        util.exportExcel(response, list, "航班预定关联乘机人数据");
    }

    /**
     * 获取航班预定关联乘机人详细信息
     */
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(flightReservationTravelerService.selectFlightReservationTravelerById(id));
    }

    /**
     * 新增航班预定关联乘机人
     */
    @PostMapping
    public AjaxResult add(@RequestBody FlightReservationTraveler flightReservationTraveler)
    {
        return toAjax(flightReservationTravelerService.insertFlightReservationTraveler(flightReservationTraveler));
    }

    /**
     * 修改航班预定关联乘机人
     */
    @PutMapping
    public AjaxResult edit(@RequestBody FlightReservationTraveler flightReservationTraveler)
    {
        return toAjax(flightReservationTravelerService.updateFlightReservationTraveler(flightReservationTraveler));
    }

    /**
     * 删除航班预定关联乘机人
     */
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(flightReservationTravelerService.deleteFlightReservationTravelerByIds(ids));
    }
}
