package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.gds.module.domain.FlightSegmentCabin;
import com.ruoyi.gds.service.IFlightSegmentCabinService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 航段舱位Controller
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@RestController
@RequestMapping("/flight/segment/cabin")
public class FlightSegmentCabinController extends BaseController {
    @Autowired
    private IFlightSegmentCabinService flightSegmentCabinService;

    /**
     * 查询航段舱位列表
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightSegmentCabin flightSegmentCabin) {
        startPage();
        List<FlightSegmentCabin> list = flightSegmentCabinService.selectFlightSegmentCabinList(flightSegmentCabin);
        return getDataTable(list);
    }

    /**
     * 导出航段舱位列表
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:export')")
    @Log(title = "航段舱位", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightSegmentCabin flightSegmentCabin) {
        List<FlightSegmentCabin> list = flightSegmentCabinService.selectFlightSegmentCabinList(flightSegmentCabin);
        ExcelUtil<FlightSegmentCabin> util = new ExcelUtil<FlightSegmentCabin>(FlightSegmentCabin.class);
        util.exportExcel(response, list, "航段舱位数据");
    }

    /**
     * 获取航段舱位详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(flightSegmentCabinService.selectFlightSegmentCabinById(id));
    }

    /**
     * 新增航段舱位
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:add')")
    @Log(title = "航段舱位", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightSegmentCabin flightSegmentCabin) {
        return toAjax(flightSegmentCabinService.insertFlightSegmentCabin(flightSegmentCabin));
    }

    /**
     * 修改航段舱位
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:edit')")
    @Log(title = "航段舱位", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightSegmentCabin flightSegmentCabin) {
        return toAjax(flightSegmentCabinService.updateFlightSegmentCabin(flightSegmentCabin));
    }

    /**
     * 删除航段舱位
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:remove')")
    @Log(title = "航段舱位", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(flightSegmentCabinService.deleteFlightSegmentCabinByIds(ids));
    }
}
