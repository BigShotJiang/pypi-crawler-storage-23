package com.ruoyi.gds.enums.ibe;

public enum SearchPriceCallerType {

    // 系统
    SYSTEM,

    // 用户
    USER,

}
