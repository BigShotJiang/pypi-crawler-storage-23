package com.ruoyi.gds.module;

import com.ruoyi.gds.module.vo.Passenger;
import com.ruoyi.gds.module.vo.PolicyPrice;
import com.ruoyi.gds.module.vo.PolicyPriceVo;
import com.ruoyi.gds.module.vo.Voyage;
import com.ruoyi.gds.module.vo.galileo.BasePriceVo;
import com.ruoyi.gds.module.vo.galileo.FlightPriceVo;
import com.ruoyi.gds.module.vo.galileo.PassengerTicketVo;
import com.ruoyi.gds.module.vo.galileo.PriceSegmentVo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;
import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SearchPriceRsp<T> extends CommonRsp<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    private String pcc;

    /**
     * PNR
     */
    private String pnr;

    /**
     * 大编码
     */
    private String bigPnr;

    /**
     * 批次号
     */
    private String batchCode;

    /**
     * 行程key
     */
    private String flightKey;

    /**
     * 报价key
     */
    private String flightFareKey;

    /**
     * 报价版本
     */
    private Integer flightFareVersion;

    /**
     * 行程信息
     */
    private List<PriceSegmentVo> flights;

    /**
     * 总报价
     */
    private List<BasePriceVo> prices;

    /**
     * 各类人员报价
     */
    private List<FlightPriceVo> passengerPrices;

    /**
     * 乘机人票号
     */
    private List<PassengerTicketVo> passengerTickets;

    /**
     * 政策价格
     */
    private PolicyPriceVo policyPrice;

    /**
     * 是否已添加到购物车
     */
    private Boolean saved;

    /**
     * 扫舱任务ID
     */
    private String taskId;

    /**
     * 扫舱状态
     */
    private String cabinScanStatus;

    /**
     * 导入编码后返回的唯一标识
     */
    private String rawId;
    //政策价格信息集合
    private List<PolicyPrice> policyList;

    // 订单的航程信息集合
    private List<Voyage> voyageList;

    //乘机人信息
    private List<Passenger> passengerList;

    private String orderId;

}
