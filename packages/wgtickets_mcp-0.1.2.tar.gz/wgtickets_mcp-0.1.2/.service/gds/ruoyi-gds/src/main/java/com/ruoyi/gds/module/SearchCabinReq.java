package com.ruoyi.gds.module;

import com.ruoyi.gds.enums.PassengerType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.List;
import java.util.Optional;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SearchCabinReq implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotEmpty(message = "行程方案报价Key为空")
    private List<String> flightFareKeys;

    @NotEmpty(message = "乘机人类型为空")
    private List<PassengerType> passengers;

    /**
     * 是否使用 承运方(主飞) 航班查询。默认：false
     */
    private Boolean useOperating;

    public Boolean getUseOperating() {
        return Optional.ofNullable(useOperating).orElse(false);
    }

}
