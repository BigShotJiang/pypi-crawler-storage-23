package com.ruoyi.gds.controller;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.gds.module.domain.WgGalileoKey;
import com.ruoyi.gds.service.IWgGalileoKeyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 歪裹Key与伽利略Key对照Controller
 * 
 * @author ruoyi
 * @date 2025-10-29
 */
@RestController
@RequestMapping("/system/key")
public class WgGalileoKeyController extends BaseController
{
    @Autowired
    private IWgGalileoKeyService wgGalileoKeyService;

    /**
     * 查询歪裹Key与伽利略Key对照列表
     */
    @PreAuthorize("@ss.hasPermi('system:key:list')")
    @GetMapping("/list")
    public TableDataInfo list(WgGalileoKey wgGalileoKey)
    {
        startPage();
        List<WgGalileoKey> list = wgGalileoKeyService.selectWgGalileoKeyList(wgGalileoKey);
        return getDataTable(list);
    }

    /**
     * 导出歪裹Key与伽利略Key对照列表
     */
    @PreAuthorize("@ss.hasPermi('system:key:export')")
    @Log(title = "歪裹Key与伽利略Key对照", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, WgGalileoKey wgGalileoKey)
    {
        List<WgGalileoKey> list = wgGalileoKeyService.selectWgGalileoKeyList(wgGalileoKey);
        ExcelUtil<WgGalileoKey> util = new ExcelUtil<WgGalileoKey>(WgGalileoKey.class);
        util.exportExcel(response, list, "歪裹Key与伽利略Key对照数据");
    }

    /**
     * 获取歪裹Key与伽利略Key对照详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:key:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(wgGalileoKeyService.selectWgGalileoKeyById(id));
    }

    /**
     * 新增歪裹Key与伽利略Key对照
     */
    @PreAuthorize("@ss.hasPermi('system:key:add')")
    @Log(title = "歪裹Key与伽利略Key对照", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody WgGalileoKey wgGalileoKey)
    {
        return toAjax(wgGalileoKeyService.insertWgGalileoKey(wgGalileoKey));
    }

    /**
     * 修改歪裹Key与伽利略Key对照
     */
    @PreAuthorize("@ss.hasPermi('system:key:edit')")
    @Log(title = "歪裹Key与伽利略Key对照", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody WgGalileoKey wgGalileoKey)
    {
        return toAjax(wgGalileoKeyService.updateWgGalileoKey(wgGalileoKey));
    }

    /**
     * 删除歪裹Key与伽利略Key对照
     */
    @PreAuthorize("@ss.hasPermi('system:key:remove')")
    @Log(title = "歪裹Key与伽利略Key对照", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(wgGalileoKeyService.deleteWgGalileoKeyByIds(ids));
    }
}
