package com.ruoyi.gds.controller;

import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.gds.module.domain.FlightFare;
import com.ruoyi.gds.service.IFlightFareService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 搜索航班结果Controller
 * 
 * @author ruoyi
 * @date 2025-04-14
 */
@RestController
@RequestMapping("/flight/fare")
public class FlightFareController extends BaseController
{
    @Autowired
    private IFlightFareService flightFareService;

    /**
     * 查询搜索航班结果列表
     */
    @GetMapping("/list")
    public TableDataInfo list(FlightFare flightFare)
    {
        startPage();
        List<FlightFare> list = flightFareService.selectFlightFareList(flightFare);
        return getDataTable(list);
    }

    /**
     * 导出搜索航班结果列表
     */
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightFare flightFare)
    {
        List<FlightFare> list = flightFareService.selectFlightFareList(flightFare);
        ExcelUtil<FlightFare> util = new ExcelUtil<FlightFare>(FlightFare.class);
        util.exportExcel(response, list, "搜索航班结果数据");
    }

    /**
     * 获取搜索航班结果详细信息
     */
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(flightFareService.selectFlightFareById(id));
    }

    /**
     * 新增搜索航班结果
     */
    @PostMapping
    public AjaxResult add(@RequestBody FlightFare flightFare)
    {
        return toAjax(flightFareService.insertFlightFare(flightFare));
    }

    /**
     * 修改搜索航班结果
     */
    @PutMapping
    public AjaxResult edit(@RequestBody FlightFare flightFare)
    {
        return toAjax(flightFareService.updateFlightFare(flightFare));
    }

    /**
     * 删除搜索航班结果
     */
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(flightFareService.deleteFlightFareByIds(ids));
    }
}
