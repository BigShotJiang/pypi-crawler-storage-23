package com.ruoyi.gds.controller;

import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.module.*;
import com.ruoyi.gds.module.dto.galileo.CancelPnrDto;
import com.ruoyi.gds.module.dto.galileo.SearchFlightDto;
import com.ruoyi.gds.module.dto.validation.Galelio;
import com.ruoyi.gds.module.vo.galileo.CancelReservationVo;
import com.ruoyi.gds.module.vo.galileo.FlightPlantVo;
import com.ruoyi.gds.module.vo.galileo.UniversalRecordVo;
import com.ruoyi.gds.schema.galileo.rsp.UniversalRecordRetrieveRspSoap;
import com.ruoyi.gds.service.GalileoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/air/galileo")
public class GalileoAirController {

    @Autowired
    private GalileoService galileoService;

    /**
     * 搜索航班
     *
     * @param searchFlightDto
     * @return
     */
    @PostMapping(value = "/searchFlight")
    public AjaxResult searchFlight(@RequestBody @Validated SearchFlightDto searchFlightDto) {
        // 入参校验
        searchFlightDto.check();

        List<FlightPlantVo> flightPlantVos = galileoService.searchFlight(searchFlightDto);

        return AjaxResult.success(flightPlantVos);
    }

    /**
     * 查询航班价格
     *
     * @param searchPriceReq
     * @return
     */
    @PostMapping(value = "/searchFlightPrice")
    public AjaxResult searchFlightPrice(@RequestBody @Validated(value = Galelio.class) SearchPriceReq searchPriceReq) {
        SearchPriceRsp searchPriceRsp = galileoService.searchLowPrice(searchPriceReq);
        return AjaxResult.success(searchPriceRsp);
    }

    /**
     * 查询舱位数
     *
     * @param searchReq
     * @return
     */
    @PostMapping(value = "/searchCabinQuantity")
    public AjaxResult searchCabinQuantity(@RequestBody SearchCabinQuantityReq searchReq) {
        SearchCabinQuantityRsp searchCabinQuantityRsp = galileoService.searchCabinQuantity(searchReq);
        return AjaxResult.success(searchCabinQuantityRsp);
    }

    /**
     * 创建PNR
     *
     * @param createPnrReq
     * @return
     */
    @PostMapping(value = "/createPnr")
    public AjaxResult createPnr(@RequestBody @Validated(value = Galelio.class) CreatePnrReq createPnrReq) {
        // 入参校验
        createPnrReq.check();

        CreatePnrRsp<UniversalRecordVo> createPnrRsp = galileoService.createPnr(createPnrReq);

        return AjaxResult.success(createPnrRsp.getErrMsg(), createPnrRsp.getCancelPnrDto());
    }

    /**
     * 创建PNR
     *
     * @param pnr
     * @return
     */
    @GetMapping(value = "/queryPnr")
    public AjaxResult queryPnr(@RequestParam String pnr) {
        if (StringUtils.isBlank(pnr)) {
            throw new ServiceException("PNR为空", HttpStatus.BAD_REQUEST);
        }
        if (pnr.length() != 6) {
            throw new ServiceException("PNR格式错误", HttpStatus.BAD_REQUEST);
        }

        QueryPnrRsp<UniversalRecordRetrieveRspSoap> pnrRsp = galileoService.queryPnr(pnr);
        Optional.ofNullable(pnrRsp).ifPresent(rsp -> rsp.setOrignalInfo(null));

        return AjaxResult.success(pnrRsp);
    }

    /**
     * 取消PNR
     *
     * @param cancelPnrDto
     * @return
     */
    @PostMapping(value = "/cancelPnr")
    public AjaxResult cancelPnr(@RequestBody @Validated CancelPnrDto cancelPnrDto) {
        CommonRsp<List<CancelReservationVo>> cancelPnrRsp = galileoService.cancelPnr(cancelPnrDto);
        return AjaxResult.success(cancelPnrRsp);
    }

}
