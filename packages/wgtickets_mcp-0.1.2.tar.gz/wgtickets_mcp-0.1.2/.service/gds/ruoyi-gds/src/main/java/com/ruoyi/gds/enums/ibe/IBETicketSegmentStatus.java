package com.ruoyi.gds.enums.ibe;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.enums.TicketSegmentStatus;
import com.ruoyi.gds.utils.StrUtil;
import lombok.Getter;

import java.util.Arrays;

/**
 * 票航段状态
 */
@Getter
public enum IBETicketSegmentStatus {

    OPEN("OPEN FOR USE", TicketSegmentStatus.OPEN,"正常"),
    VOID("VOID", TicketSegmentStatus.VOID, "已废票"),
    CHECKED_IN("CHECKED IN", TicketSegmentStatus.OPEN,"已值机"),
    AIRPORT_CNTL("AIRPORT CNTL", TicketSegmentStatus.OPEN,"机场控制"),
    USED("USED/FLOWN", TicketSegmentStatus.USED, "已使用"),
    EXCHANGED("EXCHANGED", TicketSegmentStatus.EXCHANGED, "已改签"),
    REFUNDED("REFUNDED", TicketSegmentStatus.REFUNDED, "已退票");

    private final String code;

    @JsonValue
    private final TicketSegmentStatus ticketSegmentStatus;

    private final String desc;

    IBETicketSegmentStatus(String code, TicketSegmentStatus ticketSegmentStatus, String desc) {
        this.code = code;
        this.ticketSegmentStatus = ticketSegmentStatus;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static IBETicketSegmentStatus fromCode(String code) {
        if (StringUtils.isBlank(code)) return null;
        return Arrays.stream(IBETicketSegmentStatus.values())
                .filter(item -> StringUtils.isNotBlank(code) && StrUtil.removeWhiteSpaces(code).equalsIgnoreCase(StrUtil.removeWhiteSpaces(item.code)))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
