package com.ruoyi.gds.config;


import com.ruoyi.gds.module.domain.SysRequestLog;

public interface RequestLogListener {

    void onRequestComplete(SysRequestLog entry);

}
