package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightSegmentCabin;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 航段舱位Mapper接口
 *
 * @author ruoyi
 * @date 2025-09-24
 */
public interface FlightSegmentCabinMapper extends BaseMapper<FlightSegmentCabin> {
    /**
     * 查询航段舱位
     *
     * @param id 航段舱位主键
     * @return 航段舱位
     */
    public FlightSegmentCabin selectFlightSegmentCabinById(Long id);

    /**
     * 查询航段舱位列表
     *
     * @param flightSegmentCabin 航段舱位
     * @return 航段舱位集合
     */
    public List<FlightSegmentCabin> selectFlightSegmentCabinList(FlightSegmentCabin flightSegmentCabin);

    /**
     * 新增航段舱位
     *
     * @param flightSegmentCabin 航段舱位
     * @return 结果
     */
    public int insertFlightSegmentCabin(FlightSegmentCabin flightSegmentCabin);

    /**
     * 修改航段舱位
     *
     * @param flightSegmentCabin 航段舱位
     * @return 结果
     */
    public int updateFlightSegmentCabin(FlightSegmentCabin flightSegmentCabin);

    /**
     * 删除航段舱位
     *
     * @param id 航段舱位主键
     * @return 结果
     */
    public int deleteFlightSegmentCabinById(Long id);

    /**
     * 批量删除航段舱位
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightSegmentCabinByIds(Long[] ids);

    /**
     * 批量写入，重复时跳过
     * @param flightSegmentCabins
     * @return
     */
    int batchInsert(@Param("flightSegmentCabins") List<FlightSegmentCabin> flightSegmentCabins);

    List<FlightSegmentCabin> queryBySolutionKey(@Param("solutionKeys") List<String> solutionKeys);

    /**
     * 获取舱位号类型(经济舱、商务舱、头等舱)
     * @param carrier
     * @param flightNumber
     * @param cabin
     * @return
     */
    String queryCabinType(@Param("carrier") String carrier, @Param("flightNumber") String flightNumber, @Param("cabin") String cabin);

}
