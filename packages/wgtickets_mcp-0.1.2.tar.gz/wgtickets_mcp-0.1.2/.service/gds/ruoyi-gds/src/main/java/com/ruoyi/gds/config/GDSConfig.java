package com.ruoyi.gds.config;

import cn.hutool.core.date.DatePattern;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalTimeSerializer;
import com.ruoyi.gds.enums.CabinCategoryType;
import com.ruoyi.gds.enums.GalileoIssueType;
import com.ruoyi.gds.enums.RuleType;
import com.ruoyi.gds.utils.ContextUtil;
import lombok.Data;
import org.assertj.core.util.Lists;
import org.assertj.core.util.Sets;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@ConfigurationProperties(prefix = "gds")
@Data
public class GDSConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    private GalileoConfig galileo;

    private IBEConfig ibe;

    private SabreConfig sabre;

    private Integer maxResponse = 50;

    private Integer lowPriceExpireTime = 5;

    private List<Set<String>> carrierGroupForIssues;

    private EightYiConfig eightYi;

    private HuanYuConfig huanYu;

    private FlightConfig flight;

    @Data
    public static class GalileoConfig implements Serializable {

        private String agencyPhone;

        private String emergencyPhone;

        private String username;

        private String password;

        private String branch;

        private String authorized;

        private String issueBranch;

        private String issuePcc;

        private String issueQueue;

        private String airChangeQueue;

        private String segmentStatusQueue;

        private String apiBaseUri;

        private List<TourCode> tourCodes;

        private List<NoCommissionCarrier> noCommissionCarriers;

        private List<Account> accounts;

        private List<GalileoPayMethod> payMethods;

        public String getAuthorized() {
            return String.valueOf(ContextUtil.getUserId());
        }
    }

    @Data
    public static class IBEConfig implements Serializable {

        private String agencyPhone;

        private String emergencyPhone;

        private String username;

        private String password;

        private String office;

        private String iata;

        private String aid;

        private String payPassword;

        private TskAirFarePrice tskAirFarePrice;

        private OtaAirPriceRq otaAirPriceRq;

        private List<Rule> rules;

        private String apiBaseUri;

        private String searchFlightUri;

        private String searchFlightPriceC3Uri;

        private String searchFlightPriceC9Uri;

        private String searchCabinQuantityUri;

        private String createPnrUri;

        private String queryPnrUri;

        private String queryIssuedPnrUri;

        private String modifyPnrUri;

        private String queryPnrPriceUri;

        private String bspQuotaUri;

        private String bopIssueTicketUri;

        private String bspIssueTicketUri;

        private String queryRateUri;

    }

    @Data
    public static class SabreConfig implements Serializable {

        private String agencyPhone;

        private String emergencyPhone;

        private String clientId;

        private String clientSecret;

        private String username;

        private String password;

        private String iata;

        private String pcc;

        private String domain;

        private String issuePcc;

        private String lniata;

        private List<TourCode> tourCodes;

        private List<NoCommissionCarrier> noCommissionCarriers;

        private List<Account> accounts;

    }

    @Data
    public static class NoCommissionCarrier implements Serializable {

        private String carrier;

        private List<String> cabins;

        public List<String> getCabins() {
            return Optional.ofNullable(cabins).orElse(Lists.newArrayList());
        }
    }


    @Data
    public static class FlightConfig implements Serializable {
        private String appid;
        private String appsecurity;
        private String flightUri;
        private String flightSubscribeUri;

    }
    @Data
    public static class EightYiConfig implements Serializable {

        private String account;

        private String orderSource;

        private String pid;

        private String key;

        private String apiUrlCommon;

        private String queryVoyagePolicyPrice;

        private String queryInfoPolicyPrice;

        private String voyageCreateOrder;

        private String getOrderDetails;

        private String payVerifyOrder;

        private String payOrder;

        private String notifyOrderEdtz;

        private String queryPnrPolicyPrice;

        private String createOrder;
    }

    @Data
    public static class HuanYuConfig implements Serializable {


        private String orderSource;

        private String pid;

        private String pidKey;

        private String queryPnr;

        private String  createOrder;

        private String verifyPrice;

        private String payOrder;
    }

    @Data
    public static class Rule implements Serializable {

        private RuleType type;

        private String val;

    }

    @Data
    public static class TskAirFarePrice implements Serializable {

        private String version;

    }

    @Data
    public static class OtaAirPriceRq implements Serializable {

        private String target;

        private String version;

    }

    @Data
    public static class TourCode implements Serializable {

        private String carrier;

        private List<CabinTourCode> cabinTourCodes;

    }

    @Data
    public static class CabinTourCode implements Serializable {

        private CabinCategoryType cabinType;

        private List<String> cabins;

        private String tourCode;

        private List<DateRange> ticketDateRanges;

        private List<DateRange> travelDateRanges;

    }

    @Data
    public static class Account implements Serializable {

        private Set<String> carriers;

        private Set<String> cabins;

        private List<GalileoSabreCommand> commands;

        public Set<String> getCarriers() {
            return Optional.ofNullable(carriers).orElse(Sets.newHashSet());
        }

        public Set<String> getCabins() {
            return Optional.ofNullable(cabins).orElse(Sets.newHashSet());
        }

        public List<GalileoSabreCommand> getCommands() {
            return Optional.ofNullable(commands).orElse(Lists.newArrayList());
        }
    }

    @Data
    public static class GalileoPayMethod implements Serializable {

        private List<String> carriers;

        private GalileoIssueType payMethod;

    }

    @Data
    public static class GalileoSabreCommand implements Serializable {

        @DateTimeFormat(pattern = DatePattern.NORM_TIME_PATTERN)
        @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_TIME_PATTERN)
        @JsonSerialize(using = LocalTimeSerializer.class)
        @JsonDeserialize(using = LocalTimeDeserializer.class)
        private LocalTime beginTime;

        @DateTimeFormat(pattern = DatePattern.NORM_TIME_PATTERN)
        @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_TIME_PATTERN)
        @JsonSerialize(using = LocalTimeSerializer.class)
        @JsonDeserialize(using = LocalTimeDeserializer.class)
        private LocalTime endTime;

        private String command;

    }

    @Data
    public static class DateRange implements Serializable {

        @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
        @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class)
        private LocalDateTime begin;

        @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
        @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
        @JsonSerialize(using = LocalDateTimeSerializer.class)
        @JsonDeserialize(using = LocalDateTimeDeserializer.class)
        private LocalDateTime end;

    }

}
