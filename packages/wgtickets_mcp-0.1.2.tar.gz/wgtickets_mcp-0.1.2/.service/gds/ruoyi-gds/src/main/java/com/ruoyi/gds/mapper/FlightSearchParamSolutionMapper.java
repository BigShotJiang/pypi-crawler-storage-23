package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.Flight;
import com.ruoyi.gds.module.domain.FlightSearchParamSolution;
import com.ruoyi.gds.module.vo.RefreshSolutionFareVo;
import org.apache.ibatis.annotations.Param;

import java.time.LocalDate;
import java.util.List;

/**
 * 搜索条件对应的行程方案Mapper接口
 *
 * @author ruoyi
 * @date 2025-09-24
 */
public interface FlightSearchParamSolutionMapper extends BaseMapper<FlightSearchParamSolution> {
    /**
     * 查询搜索条件对应的行程方案
     *
     * @param id 搜索条件对应的行程方案主键
     * @return 搜索条件对应的行程方案
     */
    public FlightSearchParamSolution selectFlightSearchParamSolutionById(Long id);

    /**
     * 查询搜索条件对应的行程方案列表
     *
     * @param flightSearchParamSolution 搜索条件对应的行程方案
     * @return 搜索条件对应的行程方案集合
     */
    public List<FlightSearchParamSolution> selectFlightSearchParamSolutionList(FlightSearchParamSolution flightSearchParamSolution);

    /**
     * 新增搜索条件对应的行程方案
     *
     * @param flightSearchParamSolution 搜索条件对应的行程方案
     * @return 结果
     */
    public int insertFlightSearchParamSolution(FlightSearchParamSolution flightSearchParamSolution);

    /**
     * 修改搜索条件对应的行程方案
     *
     * @param flightSearchParamSolution 搜索条件对应的行程方案
     * @return 结果
     */
    public int updateFlightSearchParamSolution(FlightSearchParamSolution flightSearchParamSolution);

    /**
     * 删除搜索条件对应的行程方案
     *
     * @param id 搜索条件对应的行程方案主键
     * @return 结果
     */
    public int deleteFlightSearchParamSolutionById(Long id);

    /**
     * 批量删除搜索条件对应的行程方案
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightSearchParamSolutionByIds(Long[] ids);

    /**
     * 批量写入，重复时跳过
     * @param flightSearchParamSolutions
     * @return
     */
    int batchInsert(@Param("flightSearchParamSolutions") List<FlightSearchParamSolution> flightSearchParamSolutions);

    /**
     * 根据查询条件key（批次号batchCode）查询行程
     * @param searchParamKeys
     * @return
     */
    List<Flight> queryFlights(@Param("searchParamKeys") List<String> searchParamKeys, @Param("flightKeys") List<String> flightKeys);

    List<RefreshSolutionFareVo> querySolutionInfo(@Param("beginDate") LocalDate beginDate, @Param("endDate") LocalDate endDate);

}
