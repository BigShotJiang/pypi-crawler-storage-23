package com.ruoyi.gds.enums.ibe;

public enum SearchPriceType {

    // 查指定舱位价格
    C3,

    // 查行程最低价
    C9

}
