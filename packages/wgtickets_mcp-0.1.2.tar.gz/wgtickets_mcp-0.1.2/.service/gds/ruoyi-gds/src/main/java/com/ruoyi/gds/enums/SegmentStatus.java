package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.gds.utils.StrUtil;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

@Getter
public enum SegmentStatus {

    KK("KK", ""),
    KL("KL", ""),
    TK("TK", ""),
    US("US", ""),
    UU("UU", ""),
    TL("TL", ""),
    HN("HN", ""),
    TN("TN", ""),
    RR("RR", ""),
    UC("UC", ""),
    UN("UN", ""),
    NO("NO", ""),
    HX("HX", "");

    @JsonValue
    private final String code;

    private final String desc;

    SegmentStatus(String code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static SegmentStatus fromCode(String code) {
        return Arrays.stream(SegmentStatus.values())
                .filter(item -> StringUtils.isNotBlank(code) && StrUtil.removeWhiteSpaces(code).equalsIgnoreCase(StrUtil.removeWhiteSpaces(item.code)))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }
    
}
