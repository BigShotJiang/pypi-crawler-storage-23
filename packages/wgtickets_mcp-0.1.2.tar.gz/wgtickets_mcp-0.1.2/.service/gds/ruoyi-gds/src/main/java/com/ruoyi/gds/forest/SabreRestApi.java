package com.ruoyi.gds.forest;

import com.dtflys.forest.annotation.*;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.enums.BusinessType;
import com.ruoyi.gds.forest.interceptor.SabreAccessTokenInterceptor;
import com.ruoyi.gds.forest.interceptor.SabreInterceptor;
import com.ruoyi.gds.module.dto.sabre.GetAccessTokenDto;
import com.ruoyi.gds.module.dto.sabre.SabreSearchReq;
import com.ruoyi.gds.module.vo.sabre.*;
import org.springframework.stereotype.Component;

@Component
@BaseRequest(baseURL = "${sabre_rest_baseurl}")
public interface SabreRestApi {

    /**
     * 获取asscee_token
     * @param businessType
     * @param businessCode
     * @param accessTokenDto
     * @return
     */
    @Post(url = "/v3/auth/token", interceptor = SabreAccessTokenInterceptor.class)
    GetAccessTokenVo getAccessToken(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                                    @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                                    @FormBody GetAccessTokenDto accessTokenDto);

    /**
     * 获取 Soap token
     * @param businessType
     * @param businessCode
     * @param requestXml
     * @return
     */
    @Post(url = "/v3/auth/token", interceptor = SabreAccessTokenInterceptor.class)
    GetAccessTokenVo getSoapToken(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                                  @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                                  @Body String requestXml);

    /**
     * 搜索航班
     * @param businessType
     * @param businessCode
     * @param searchReq
     * @return
     */
    @Post(url = "/v5/offers/shop", interceptor = SabreInterceptor.class)
    String searchFlight(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                        @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                        @JSONBody SabreSearchReq searchReq);

    /**
     * NDC 查价
     * @param businessType
     * @param businessCode
     * @param request
     * @return
     */
    @Post(url = "/v1/offers/price", interceptor = SabreInterceptor.class)
    String searchPriceByNDC(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                            @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                            @JSONBody OfferPriceRequestV1 request);

    /**
     * ATPCO 验价
     * @param businessType
     * @param businessCode
     * @param request
     * @return
     */
    @Post(url = "/v5/shop/flights/revalidate", interceptor = SabreInterceptor.class)
    String revalidate(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                      @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                      @JSONBody SabreSearchReq request);

    /**
     * ATPCO 创建PNR
     * @param businessType
     * @param businessCode
     * @param request
     * @return
     */
    @Post(url = "/v1/trip/orders/createBooking", interceptor = SabreInterceptor.class)
    String createPnr(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                     @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                     @JSONBody CreateBookingRequest request);

    /**
     * ATPCO 查询PNR
     * @param businessType
     * @param businessCode
     * @param request
     * @return
     */
    @Post(url = "/v1/trip/orders/getBooking", interceptor = SabreInterceptor.class)
    String queryPnr(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                    @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                    @JSONBody GetBookingRequest request);

    /**
     * ATPCO 取消PNR
     * @param businessType
     * @param businessCode
     * @param request
     * @return
     */
    @Post(url = "/v1/trip/orders/cancelBooking", interceptor = SabreInterceptor.class)
    String cancelPnr(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                     @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                     @JSONBody CancelBookingRequest request);

    /**
     * ATPCO 更新PNR
     * @param businessType
     * @param businessCode
     * @param request
     * @return
     */
    @Post(url = "/v1/trip/orders/modifyBooking", interceptor = SabreInterceptor.class)
    String updatePnr(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                     @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                     @JSONBody ModifyBookingRequest request);

    /**
     * ATPCO 出票
     * @param businessType
     * @param businessCode
     * @param request
     * @return
     */
    @Post(url = "/v1/trip/orders/fulfillFlightTickets", interceptor = SabreInterceptor.class)
    String issueTicket(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                       @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                       @JSONBody FulfillTicketsRequest request);

}
