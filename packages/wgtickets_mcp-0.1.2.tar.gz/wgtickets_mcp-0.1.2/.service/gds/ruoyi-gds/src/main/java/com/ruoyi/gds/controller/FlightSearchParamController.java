package com.ruoyi.gds.controller;

import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.gds.module.domain.FlightSearchParam;
import com.ruoyi.gds.module.dto.QueryBusinessSearchParamDto;
import com.ruoyi.gds.module.vo.BusinessSearchParamVo;
import com.ruoyi.gds.service.IFlightSearchParamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;

/**
 * 航班搜索条件Controller
 * 
 * @author ruoyi
 * @date 2025-06-24
 */
@RestController
@RequestMapping("/flight/searchParam")
public class FlightSearchParamController extends BaseController
{
    @Autowired
    private IFlightSearchParamService flightSearchParamService;

    /**
     * 查询航班搜索条件列表
     */
    @PreAuthorize("@ss.hasPermi('system:param:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightSearchParam flightSearchParam)
    {
        startPage();
        List<FlightSearchParam> list = flightSearchParamService.selectFlightSearchParamList(flightSearchParam);
        return getDataTable(list);
    }

    /**
     * 导出航班搜索条件列表
     */
    @PreAuthorize("@ss.hasPermi('system:param:export')")
    @Log(title = "航班搜索条件", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightSearchParam flightSearchParam)
    {
        List<FlightSearchParam> list = flightSearchParamService.selectFlightSearchParamList(flightSearchParam);
        ExcelUtil<FlightSearchParam> util = new ExcelUtil<FlightSearchParam>(FlightSearchParam.class);
        util.exportExcel(response, list, "航班搜索条件数据");
    }

    /**
     * 获取航班搜索条件详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:param:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(flightSearchParamService.selectFlightSearchParamById(id));
    }

    /**
     * 新增航班搜索条件
     */
    @PreAuthorize("@ss.hasPermi('system:param:add')")
    @Log(title = "航班搜索条件", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightSearchParam flightSearchParam)
    {
        return toAjax(flightSearchParamService.insertFlightSearchParam(flightSearchParam));
    }

    /**
     * 修改航班搜索条件
     */
    @PreAuthorize("@ss.hasPermi('system:param:edit')")
    @Log(title = "航班搜索条件", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightSearchParam flightSearchParam)
    {
        return toAjax(flightSearchParamService.updateFlightSearchParam(flightSearchParam));
    }

    /**
     * 删除航班搜索条件
     */
    @PreAuthorize("@ss.hasPermi('system:param:remove')")
    @Log(title = "航班搜索条件", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(flightSearchParamService.deleteFlightSearchParamByIds(ids));
    }

    /**
     * 查询批次号或业务ID对应的最新搜索条件或最后一次历史搜索条件
     *
     * @param queryDto
     * @return
     */
    @PostMapping(value = "/getRootSearchParam")
    public AjaxResult getRootSearchParam(@RequestBody QueryBusinessSearchParamDto queryDto) {
        List<BusinessSearchParamVo> businessSearchParamVos = flightSearchParamService.getRootSearchParams(queryDto);
        return AjaxResult.success(businessSearchParamVos);
    }

}
