package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.gds.module.domain.FlightSolution;
import com.ruoyi.gds.service.IFlightSolutionService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 行程方案Controller
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@RestController
@RequestMapping("/flight/solution")
public class FlightSolutionController extends BaseController {
    @Autowired
    private IFlightSolutionService flightSolutionService;

    /**
     * 查询行程方案列表
     */
    @PreAuthorize("@ss.hasPermi('system:solution:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightSolution flightSolution) {
        startPage();
        List<FlightSolution> list = flightSolutionService.selectFlightSolutionList(flightSolution);
        return getDataTable(list);
    }

    /**
     * 导出行程方案列表
     */
    @PreAuthorize("@ss.hasPermi('system:solution:export')")
    @Log(title = "行程方案", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightSolution flightSolution) {
        List<FlightSolution> list = flightSolutionService.selectFlightSolutionList(flightSolution);
        ExcelUtil<FlightSolution> util = new ExcelUtil<FlightSolution>(FlightSolution.class);
        util.exportExcel(response, list, "行程方案数据");
    }

    /**
     * 获取行程方案详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:solution:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(flightSolutionService.selectFlightSolutionById(id));
    }

    /**
     * 新增行程方案
     */
    @PreAuthorize("@ss.hasPermi('system:solution:add')")
    @Log(title = "行程方案", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightSolution flightSolution) {
        return toAjax(flightSolutionService.insertFlightSolution(flightSolution));
    }

    /**
     * 修改行程方案
     */
    @PreAuthorize("@ss.hasPermi('system:solution:edit')")
    @Log(title = "行程方案", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightSolution flightSolution) {
        return toAjax(flightSolutionService.updateFlightSolution(flightSolution));
    }

    /**
     * 删除行程方案
     */
    @PreAuthorize("@ss.hasPermi('system:solution:remove')")
    @Log(title = "行程方案", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(flightSolutionService.deleteFlightSolutionByIds(ids));
    }
}
