package com.ruoyi.gds.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.io.Serializable;

@Data
@Component
@ConfigurationProperties(prefix = "snowflake")
public class SnowflakeConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long dataCenterId;

    private Long workerId;

}
