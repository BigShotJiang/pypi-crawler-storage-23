package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.gds.utils.StrUtil;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

@Getter
public enum CabinCategoryType {

    ECONOMY(1, "Economy", "经济舱"),
    PREMIUM_ECONOMY(2, "PremiumEconomy", "优选经济舱"),
    BUSINESS(3, "Business", "商务舱"),
    FIRST(4, "First", "头等舱");

    private final Integer num;

    @JsonValue
    private final String code;

    private final String desc;

    CabinCategoryType(Integer num, String code, String desc) {
        this.num = num;
        this.code = code;
        this.desc = desc;
    }

    public static CabinCategoryType fromNum(Integer num) {
        if (Objects.isNull(num)) return null;
        return Arrays.stream(CabinCategoryType.values()).filter(item -> num.equals(item.num)).findFirst().orElse(null);
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static CabinCategoryType fromCode(String code) {
        return Arrays.stream(CabinCategoryType.values())
                .filter(item -> StringUtils.isNotBlank(code) && StrUtil.removeWhiteSpaces(code).equalsIgnoreCase(StrUtil.removeWhiteSpaces(item.code)))
                .findFirst()
                .orElse(null);
    }

    public static List<CabinCategoryType> valuesWithoutEconomy() {
        return Arrays.stream(CabinCategoryType.values()).filter(item -> !ECONOMY.equals(item)).collect(Collectors.toList());
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }
    
}
