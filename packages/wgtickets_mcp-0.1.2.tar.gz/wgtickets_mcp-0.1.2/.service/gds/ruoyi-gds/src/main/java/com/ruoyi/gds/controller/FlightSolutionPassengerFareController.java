package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.gds.module.domain.FlightSolutionPassengerFare;
import com.ruoyi.gds.service.IFlightSolutionPassengerFareService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 各类乘机人报价Controller
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@RestController
@RequestMapping("/flight/solution/passengerFare")
public class FlightSolutionPassengerFareController extends BaseController {
    @Autowired
    private IFlightSolutionPassengerFareService flightSolutionPassengerFareService;

    /**
     * 查询各类乘机人报价列表
     */
    @PreAuthorize("@ss.hasPermi('system:fare:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightSolutionPassengerFare flightSolutionPassengerFare) {
        startPage();
        List<FlightSolutionPassengerFare> list = flightSolutionPassengerFareService.selectFlightSolutionPassengerFareList(flightSolutionPassengerFare);
        return getDataTable(list);
    }

    /**
     * 导出各类乘机人报价列表
     */
    @PreAuthorize("@ss.hasPermi('system:fare:export')")
    @Log(title = "各类乘机人报价", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightSolutionPassengerFare flightSolutionPassengerFare) {
        List<FlightSolutionPassengerFare> list = flightSolutionPassengerFareService.selectFlightSolutionPassengerFareList(flightSolutionPassengerFare);
        ExcelUtil<FlightSolutionPassengerFare> util = new ExcelUtil<FlightSolutionPassengerFare>(FlightSolutionPassengerFare.class);
        util.exportExcel(response, list, "各类乘机人报价数据");
    }

    /**
     * 获取各类乘机人报价详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:fare:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(flightSolutionPassengerFareService.selectFlightSolutionPassengerFareById(id));
    }

    /**
     * 新增各类乘机人报价
     */
    @PreAuthorize("@ss.hasPermi('system:fare:add')")
    @Log(title = "各类乘机人报价", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightSolutionPassengerFare flightSolutionPassengerFare) {
        return toAjax(flightSolutionPassengerFareService.insertFlightSolutionPassengerFare(flightSolutionPassengerFare));
    }

    /**
     * 修改各类乘机人报价
     */
    @PreAuthorize("@ss.hasPermi('system:fare:edit')")
    @Log(title = "各类乘机人报价", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightSolutionPassengerFare flightSolutionPassengerFare) {
        return toAjax(flightSolutionPassengerFareService.updateFlightSolutionPassengerFare(flightSolutionPassengerFare));
    }

    /**
     * 删除各类乘机人报价
     */
    @PreAuthorize("@ss.hasPermi('system:fare:remove')")
    @Log(title = "各类乘机人报价", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(flightSolutionPassengerFareService.deleteFlightSolutionPassengerFareByIds(ids));
    }
}
