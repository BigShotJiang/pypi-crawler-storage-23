package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import lombok.Getter;

import java.util.Arrays;

@Getter
public enum PccType {

    GALILEO_Z1H("伽利略", GDSType.GALELIO, "Z1H", "P4754044"),
    GALILEO_38CT("伽利略", GDSType.GALELIO, "38CT", "P4796591"),
    IBE_WUH161("中国白屏", GDSType.IBE, "WUH161", "WUH161"),
    SABRE_L0AL("塞班", GDSType.SABRE, "L0AL", "L0AL"),
    HUAN_YU("寰宇", GDSType.HUAN_YU, "HUAN_YU", "HUAN_YU"),
    EIGHT_YI("八千翼", GDSType.EIGHT_YI, "EIGHT_YI", "EIGHT_YI");

    private final String name;

    private final GDSType gds;

    @JsonValue
    private final String pcc;

    private final String reservationCode;

    PccType(String name, GDSType gds, String pcc, String reservationCode) {
        this.name = name;
        this.gds = gds;
        this.pcc = pcc;
        this.reservationCode = reservationCode;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static PccType fromPcc(String pcc) {
        return Arrays.stream(PccType.values()).filter(item -> StringUtils.isNotBlank(pcc) && pcc.equalsIgnoreCase(item.pcc)).findFirst().orElse(null);
    }

    public static PccType fromBranch(String branch) {
        return Arrays.stream(PccType.values()).filter(item -> StringUtils.isNotBlank(branch) && branch.equalsIgnoreCase(item.reservationCode)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return pcc + ": " + name;
    }

}
