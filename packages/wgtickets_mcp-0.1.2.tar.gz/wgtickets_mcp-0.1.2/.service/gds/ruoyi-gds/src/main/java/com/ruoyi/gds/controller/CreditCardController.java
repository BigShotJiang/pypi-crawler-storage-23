package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import com.ruoyi.gds.module.domain.CreditCard;
import com.ruoyi.gds.module.dto.GetCreditCardDto;
import com.ruoyi.gds.module.vo.CreateCreditCardResultVo;
import com.ruoyi.gds.service.ICreditCardService;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 自动开票——信用卡开卡记录Controller
 * 
 * @author ruoyi
 * @date 2025-11-28
 */
@RestController
@RequestMapping("/creditCard")
public class CreditCardController extends BaseController
{
    @Autowired
    private ICreditCardService creditCardService;

    /**
     * 查询自动开票——信用卡开卡记录列表
     */
    @PreAuthorize("@ss.hasPermi('system:card:list')")
    @GetMapping("/list")
    public TableDataInfo list(CreditCard creditCard)
    {
        startPage();
        List<CreditCard> list = creditCardService.selectCreditCardList(creditCard);
        return getDataTable(list);
    }

    /**
     * 导出自动开票——信用卡开卡记录列表
     */
    @PreAuthorize("@ss.hasPermi('system:card:export')")
    @Log(title = "自动开票——信用卡开卡记录", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, CreditCard creditCard)
    {
        List<CreditCard> list = creditCardService.selectCreditCardList(creditCard);
        ExcelUtil<CreditCard> util = new ExcelUtil<CreditCard>(CreditCard.class);
        util.exportExcel(response, list, "自动开票——信用卡开卡记录数据");
    }

    /**
     * 获取自动开票——信用卡开卡记录详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:card:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(creditCardService.selectCreditCardById(id));
    }

    /**
     * 新增自动开票——信用卡开卡记录
     */
    @PreAuthorize("@ss.hasPermi('system:card:add')")
    @Log(title = "自动开票——信用卡开卡记录", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody CreditCard creditCard)
    {
        return toAjax(creditCardService.insertCreditCard(creditCard));
    }

    /**
     * 修改自动开票——信用卡开卡记录
     */
    @PreAuthorize("@ss.hasPermi('system:card:edit')")
    @Log(title = "自动开票——信用卡开卡记录", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody CreditCard creditCard)
    {
        return toAjax(creditCardService.updateCreditCard(creditCard));
    }

    /**
     * 删除自动开票——信用卡开卡记录
     */
    @PreAuthorize("@ss.hasPermi('system:card:remove')")
    @Log(title = "自动开票——信用卡开卡记录", businessType = BusinessType.DELETE)
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(creditCardService.deleteCreditCardByIds(ids));
    }

    /**
     * 开卡
     * @param creditCardDto
     * @return
     */
    @PostMapping("/create")
    public AjaxResult createCreditCard(@RequestBody @Validated GetCreditCardDto creditCardDto)
    {
        CreateCreditCardResultVo creditCardResultVo = creditCardService.createCreditCard(creditCardDto);
        return AjaxResult.success(creditCardResultVo);
    }

}
