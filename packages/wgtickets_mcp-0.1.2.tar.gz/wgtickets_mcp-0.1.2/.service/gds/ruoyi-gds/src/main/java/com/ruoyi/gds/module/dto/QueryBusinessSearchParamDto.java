package com.ruoyi.gds.module.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QueryBusinessSearchParamDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 业务ID集合
     */
    private List<String> businessIds;

    /**
     * 批次号【集合
     */
    private List<String> bachCodes;

}
