package com.ruoyi.gds.controller;

import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.forest.TicketApi;
import com.ruoyi.gds.module.*;
import com.ruoyi.gds.module.domain.CallbackRecord;
import com.ruoyi.gds.module.vo.FinTicket;
import com.ruoyi.gds.module.vo.eightyi.*;
import com.ruoyi.gds.service.EightYiService;
import com.ruoyi.gds.service.ICallbackRecordService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.Objects;
@Anonymous
@RestController
@RequestMapping("/air/eightYi")
@Slf4j
public class EightYiAirController {

    @Autowired
    private EightYiService eightYiService;

    @Autowired
    private TicketApi ticketApi;

    @Autowired
    private ICallbackRecordService callbackRecordService;

    /**
     * 获取订单详情
     *
     * @param orderId
     * @return
     */
    @GetMapping("/getOrderDetail/{orderId}")
    public AjaxResult getOrderDetail(@PathVariable String orderId) {
        if (StringUtils.isBlank(orderId)) {
            throw new ServiceException("订单ID为空", HttpStatus.BAD_REQUEST);
        }
        EightYiOrderDetailVo orderDetail = eightYiService.getOrderDetail(orderId);
        if (Objects.isNull(orderDetail)) {
            return AjaxResult.error("订单详情为空");
        }
        if (StringUtils.isNotBlank(orderDetail.getItem().getRefuseReason())){
            String failOrderId = orderDetail.getItem().getOrderId();
            FinTicket ticket = new FinTicket();
            ticket.setCancelReason(orderDetail.getItem().getRefuseReason());
            ticket.setPlatOrderId(failOrderId);
            //更新票务失败状态
            ticketApi.issueTicketFail(ticket);

            // 保存callback记录
            String json = JacksonUtil.toJsonString(orderDetail);
            CallbackRecord callbackRecord = callbackRecordService.selectCallbackRecordByOrderSn(failOrderId);
            if (null != callbackRecord) {
                callbackRecordService.updateCallbackRecord(
                        CallbackRecord.builder()
                                .orderSn(failOrderId)
                                .content(json)
                                .updateStatus("出票失败")
                                .updateTime(new Date())
                                .build()
                );
            } else {
                callbackRecordService.insertCallbackRecord(
                        CallbackRecord.builder()
                                .gds("EIGHT_YI")
                                .orderSn(failOrderId)
                                .content(json)
                                .build()
                );
            }
            return AjaxResult.success(orderDetail.getItem().getOrderState());
        }
        return AjaxResult.success(orderDetail);
    }

    /**
     * 获取航程信息询价接口
     *
     * @param voyagePolicyPriceReq
     * @return
     */
    @PostMapping("/getVoyagePolicyPrice")
    public AjaxResult getVoyagePolicyPrice(@RequestBody @Validated VoyagePolicyPriceReq voyagePolicyPriceReq) {
        VoyagePolicyPriceDetailVo voyagePolicyPrice = eightYiService.getVoyagePolicyPrice(voyagePolicyPriceReq);
        return AjaxResult.success(voyagePolicyPrice);
    }

    /**
     * 航程信息生单接口
     *
     * @param voyageCreateOrderReq
     * @return
     */
    @PostMapping("/getVoyageCreateOrder")
    public AjaxResult getVoyageCreateOrder(@RequestBody @Validated VoyageCreateOrderReq voyageCreateOrderReq) {
        VoyageCreateOrderResp voyageCreateOrder = eightYiService.voyageCreateOrder(voyageCreateOrderReq);
        return AjaxResult.success(voyageCreateOrder);
    }

    /**
     * 订单完成接口
     *
     * @return
     */
    @PostMapping("/completeOrder")
    public AjaxResult completeOrder(@RequestBody String json) {
        return AjaxResult.success(eightYiService.completeOrder(json));
    }
}
