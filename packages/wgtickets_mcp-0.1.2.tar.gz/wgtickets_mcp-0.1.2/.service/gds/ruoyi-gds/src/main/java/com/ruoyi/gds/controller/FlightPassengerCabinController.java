package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.gds.module.domain.FlightPassengerCabin;
import com.ruoyi.gds.service.IFlightPassengerCabinService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 乘机人舱位Controller
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@RestController
@RequestMapping("/system/cabin")
public class FlightPassengerCabinController extends BaseController {
    @Autowired
    private IFlightPassengerCabinService flightPassengerCabinService;

    /**
     * 查询乘机人舱位列表
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightPassengerCabin flightPassengerCabin) {
        startPage();
        List<FlightPassengerCabin> list = flightPassengerCabinService.selectFlightPassengerCabinList(flightPassengerCabin);
        return getDataTable(list);
    }

    /**
     * 导出乘机人舱位列表
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:export')")
    @Log(title = "乘机人舱位", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightPassengerCabin flightPassengerCabin) {
        List<FlightPassengerCabin> list = flightPassengerCabinService.selectFlightPassengerCabinList(flightPassengerCabin);
        ExcelUtil<FlightPassengerCabin> util = new ExcelUtil<FlightPassengerCabin>(FlightPassengerCabin.class);
        util.exportExcel(response, list, "乘机人舱位数据");
    }

    /**
     * 获取乘机人舱位详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(flightPassengerCabinService.selectFlightPassengerCabinById(id));
    }

    /**
     * 新增乘机人舱位
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:add')")
    @Log(title = "乘机人舱位", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightPassengerCabin flightPassengerCabin) {
        return toAjax(flightPassengerCabinService.insertFlightPassengerCabin(flightPassengerCabin));
    }

    /**
     * 修改乘机人舱位
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:edit')")
    @Log(title = "乘机人舱位", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightPassengerCabin flightPassengerCabin) {
        return toAjax(flightPassengerCabinService.updateFlightPassengerCabin(flightPassengerCabin));
    }

    /**
     * 删除乘机人舱位
     */
    @PreAuthorize("@ss.hasPermi('system:cabin:remove')")
    @Log(title = "乘机人舱位", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(flightPassengerCabinService.deleteFlightPassengerCabinByIds(ids));
    }
}
