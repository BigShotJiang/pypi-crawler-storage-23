package com.ruoyi.gds.module;

import com.ruoyi.gds.module.vo.FlightTravelerVo;
import com.ruoyi.gds.module.vo.galileo.BaseFlightVo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QueryPnrBaseRsp implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 行程信息
     */
    private List<BaseFlightVo> flights;

    /**
     * 乘客信息
     */
    private List<FlightTravelerVo> travelers;

}
