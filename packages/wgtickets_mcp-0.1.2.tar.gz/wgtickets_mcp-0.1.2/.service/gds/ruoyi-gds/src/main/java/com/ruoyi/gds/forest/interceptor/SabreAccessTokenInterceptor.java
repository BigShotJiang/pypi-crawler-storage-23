package com.ruoyi.gds.forest.interceptor;

import com.dtflys.forest.http.ForestRequest;
import com.ruoyi.gds.config.GDSConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Slf4j
@Component
public class SabreAccessTokenInterceptor extends BaseInterceptor {

    @Autowired
    private GDSConfig gdsConfig;

    @Override
    public boolean beforeExecute(ForestRequest request) {
        super.beforeExecute(request);
        String client = gdsConfig.getSabre().getClientId() + ":" + gdsConfig.getSabre().getClientSecret();
        request.addHeader("Authorization", "Basic " + Base64.getEncoder().encodeToString(client.getBytes(StandardCharsets.UTF_8)));
        return true;
    }

}
