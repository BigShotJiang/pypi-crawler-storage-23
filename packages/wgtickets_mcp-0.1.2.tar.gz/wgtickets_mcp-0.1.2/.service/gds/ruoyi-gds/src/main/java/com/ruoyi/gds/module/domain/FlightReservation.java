package com.ruoyi.gds.module.domain;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.gds.module.vo.PolicyPriceVo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import org.assertj.core.util.Lists;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 航班预定对象 flight_reservation
 * 
 * @author ruoyi
 * @date 2025-04-17
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightReservation implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 业务场景(TICKET、OTA、GDS、FLY...) */
    @Excel(name = "业务场景")
    private String businessScene;

    /** 业务ID */
    @Excel(name = "业务ID")
    private String businessId;

    /** 批次号 */
    @Excel(name = "批次号")
    private String batchCode;

    /** 总行程编号 */
    @Excel(name = "总行程编号")
    private String flightKey;

    /** 行程报价编号 */
    @Excel(name = "行程报价编号")
    private String flightFareKey;

    /** GDS代码 */
    @Excel(name = "GDS代码")
    private String providerCode;

    /** PNR */
    @Excel(name = "PNR")
    private String pnr;

    /** PNR过期时间 */
    @Excel(name = "PNR过期时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime pnrExpireTime;

    /** 累计更新PNR过期时间次数 */
    @Excel(name = "累计更新PNR过期时间次数")
    private Integer updatePnrExpireTimeCount;

    /** GDS创建PNR时需要的入参 */
    private String createPnrReq;

    /** GDS创建PNR时的返回数据 */
    private String createPnrRsp;

    /** GDS查询PNR时的返回数据 */
    private String searchPnrRsp;

    /** GDS取消PNR时需要的入参 */
    private String cancelPnrReq;

    /** GDS取消PNR时的返回数据 */
    private String cancelPnrRsp;

    /** 成本价 */
    private String policyPrice;

    /** 状态（0：待预订，1：预定失败，2：预定成功，3：已取消） */
    @Excel(name = "状态", readConverterExp = "0=：待预订，1：预定失败，2：预定成功，3：已取消")
    private Integer status;

    /** 备注 */
    @Excel(name = "备注")
    private String remark;

    /** 警告信息 */
    @Excel(name = "警告信息")
    private String warnings;

    /** 三方平台行程航段(寰宇,八千翼等) */
    @Excel(name = "三方平台行程航段")
    private String thirdPlatformSegments;

    /** 预定人ID */
    @Excel(name = "预定人ID")
    private Long createPnrUserId;

    /** 预定人 */
    @Excel(name = "预定人")
    private String createPnrBy;

    /** 预定时间 */
    @Excel(name = "预定时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createPnrTime;

    /** 取消预定人ID */
    @Excel(name = "取消预定人ID")
    private Long cancelPnrUserId;

    /** 取消预定人 */
    @Excel(name = "取消预定人")
    private String cancelPnrBy;

    /** 取消预定时间 */
    @Excel(name = "取消预定时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime cancelPnrTime;

    /** 创建者ID */
    @Excel(name = "创建者ID")
    private Long createUserId;

    /** 创建者 */
    @Excel(name = "创建者")
    private String createBy;

    /** 创建时间 */
    @Excel(name = "创建时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTime;

    /** 更新者ID */
    @Excel(name = "更新者ID")
    private Long updateUserId;

    /** 更新者 */
    @Excel(name = "更新者")
    private String updateBy;

    /** 更新时间 */
    @Excel(name = "更新时间", width = 30, dateFormat = DatePattern.NORM_DATETIME_PATTERN)
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime updateTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;

    /** 预约记录ID集合 */
    @TableField(exist = false)
    private List<Long> reservationIds;

    /** PNR集合 */
    @TableField(exist = false)
    private List<String> pnrs;

    /** 乘机人ID */
    @TableField(exist = false)
    private List<Long> travelerIds;

    /** 逗号拼接的乘机人ID */
    @TableField(exist = false)
    private String travelerIdList;

    /** 行程类型 */
    @TableField(exist = false)
    private Integer tripType;

    /** 成本价 */
    @TableField(exist = false)
    private PolicyPriceVo policyPriceInfo;

    public String getPolicyPrice() {
        if (Objects.nonNull(policyPrice)) return policyPrice;
        return Optional.ofNullable(getPolicyPriceInfo()).map(JacksonUtil::toJsonString).orElse(null);
    }

    public List<Long> getTravelerIds() {
        return Optional.ofNullable(travelerIds)
                .filter(CollectionUtil::isNotEmpty)
                .orElse(Optional.ofNullable(travelerIdList)
                        .filter(StringUtils::isNotBlank)
                        .map(travelerIdListStr -> Arrays.stream(travelerIdListStr.split(","))
                                .filter(StringUtils::isNotBlank)
                                .map(travelerIdStr -> {
                                    try {
                                        return Long.parseLong(travelerIdStr);
                                    } catch (Exception e) {
                                        return null;
                                    }
                                })
                                .filter(Objects::nonNull)
                                .distinct()
                                .collect(Collectors.toList()))
                        .orElse(Lists.newArrayList())
                );
    }


    @Override
    public String toString() {
        return new ToStringBuilder(this,ToStringStyle.MULTI_LINE_STYLE)
            .append("id", getId())
            .append("batchCode", getBatchCode())
            .append("flightKey", getFlightKey())
            .append("flightFareKey", getFlightFareKey())
            .append("providerCode", getProviderCode())
            .append("pnr", getPnr())
            .append("createPnrRsp", getCreatePnrRsp())
            .append("cancelPnrReq", getCancelPnrReq())
            .append("orignalInfo", getCreatePnrRsp())
            .append("cancelPnrReq", getCancelPnrReq())
            .append("cancelPnrRsp", getCancelPnrRsp())
            .append("status", getStatus())
            .append("createUserId", getCreateUserId())
            .append("createBy", getCreateBy())
            .append("createTime", getCreateTime())
            .append("updateUserId", getUpdateUserId())
            .append("updateBy", getUpdateBy())
            .append("updateTime", getUpdateTime())
            .append("delFlag", isDelFlag())
            .toString();
    }
}
