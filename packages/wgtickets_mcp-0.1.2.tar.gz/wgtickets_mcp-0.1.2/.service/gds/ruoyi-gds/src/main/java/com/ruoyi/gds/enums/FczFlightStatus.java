package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;
import org.assertj.core.util.Lists;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;

@Getter
public enum FczFlightStatus {

    PLAN(10, "计划"),
    DELAY(20, "延误"),
    CANCEL(30, "取消"),
    PRE_CANCEL(31, "提前取消"),
    DIVERSION(40, "备降"),
    RETURN_VOYAGE(50, "返航"),
    TAKE_OFF(60, "起飞"),
    ARRIVE(70, "到达"),
    DIVERSION_TAKEOFF(80, "备降起飞"),
    DIVERSION_CANCEL(90, "备降取消"),
    DIVERSION_ARRIVE(100, "备降到达"),
    BACK_TACKOFF(110, "返航起飞"),
    BACK_CANCEL(120, "返航取消"),
    BACK_ARRIVE(130, "返航到达"),
    HOVERING(140, "正在盘旋"),
    HAS_HOVERING(150, "盘旋过"),
    RISING(160, "正在上升"),
    CRUISING(170, "开始巡航"),
    DECLINING(180, "开始下降"),
    APPROACHING(190, "即将到达"),
    CRASH(200, "失事"),
    LOST_CONTACT(210, "失联");

    @JsonValue
    private final Integer code;

    private final String desc;

    FczFlightStatus(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public static FczFlightStatus fromCode(Integer code) {
        if (Objects.isNull(code)) return null;
        return Arrays.stream(FczFlightStatus.values())
                .filter(item -> code.equals(item.code))
                .findFirst()
                .orElse(null);
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static FczFlightStatus fromDesc(String desc) {
        if (StringUtils.isBlank(desc)) return null;
        return Arrays.stream(FczFlightStatus.values())
                .filter(item -> desc.equalsIgnoreCase(item.desc))
                .findFirst()
                .orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

    public static List<FczFlightStatus> airchangedStatus() {
        return Lists.newArrayList(FczFlightStatus.PLAN, FczFlightStatus.DELAY, FczFlightStatus.CANCEL, FczFlightStatus.PRE_CANCEL);
    }
    
}
