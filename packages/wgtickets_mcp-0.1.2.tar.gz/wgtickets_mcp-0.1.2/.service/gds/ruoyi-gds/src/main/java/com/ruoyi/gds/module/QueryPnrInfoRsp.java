package com.ruoyi.gds.module;

import com.ruoyi.gds.module.vo.FlightTravelerVo;
import com.ruoyi.gds.module.vo.galileo.BaseFlightVo;
import com.ruoyi.gds.module.vo.galileo.FlightPriceVo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class QueryPnrInfoRsp implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 行程信息
     */
    private BaseFlightVo flight;

    /**
     * 报价信息
     */
    private FlightPriceVo price;

    /**
     * 乘客信息
     */
    private List<FlightTravelerVo> travelers;

}
