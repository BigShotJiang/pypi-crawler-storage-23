package com.ruoyi.gds.module.domain;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Optional;

/**
 * 航班搜索条件对象 flight_search_param
 * 
 * @author ruoyi
 * @date 2025-06-24
 */
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class FlightSearchParam implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /** 父级ID */
    @Excel(name = "父级ID")
    private Long parentId;

    /** 搜索方式（1：航线查询，2：批量查询，3：指令查询） */
    @Excel(name = "搜索方式", readConverterExp = "1=：航线查询，2：批量查询，3：指令查询")
    private Integer searchType;

    /** 搜索类型（0：单程，1：往返，2：多程） */
    @Excel(name = "搜索类型", readConverterExp = "0=：单程，1：往返，2：多程")
    private Integer tripType;

    /** 业务ID */
    @Excel(name = "业务ID")
    private String businessId;

    /** 是否中转（true：中转，false：直飞） */
    @Excel(name = "是否中转", readConverterExp = "true=：中转，false：直飞")
    private Boolean transfer;

    /** 舱位等级（Economy：经济舱，PremiumEconomy：优选经济舱，Business：商务舱，First：头等舱） */
    @Excel(name = "舱位等级", readConverterExp = "Economy=：经济舱，PremiumEconomy：优选经济舱，Business：商务舱，First：头等舱")
    private String cabinType;

    /** 出发机场三字码，多个时用逗号拼接 */
    @Excel(name = "出发机场三字码，多个时用逗号拼接")
    private String origin;

    /** 到达机场三字码，多个时用逗号拼接 */
    @Excel(name = "到达机场三字码，多个时用逗号拼接")
    private String destination;

    /** 行程日期 */
    @Excel(name = "行程日期")
    private String flightDate;

    /** 多程搜索条件 */
    @Excel(name = "多程搜索")
    private String multipleFlight;

    /** 指令搜索条件 */
    @Excel(name = "指令搜索条件")
    private String commandSearch;

    /** 成人数 */
    @Excel(name = "成人数")
    private Integer adtNum;

    /** 儿童数 */
    @Excel(name = "儿童数")
    private Integer cnnNum;

    /** 婴儿数 */
    @Excel(name = "婴儿数")
    private Integer infNum;

    /** 结果集批次号 */
    @Excel(name = "结果集批次号")
    private String batchCodes;

    /** 是否历史搜索条件（true：是，false：否） */
    @Excel(name = "是否历史搜索条件", readConverterExp = "true=：是，false：否")
    private boolean history;

    /** 创建者 */
    private Long createBy;

    /** 创建时间 */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime createTime;

    /** 是否已删除（0：未删除，1：已删除） */
    private boolean delFlag;


    public Integer getAdtNum() {
        return Optional.ofNullable(adtNum).orElse(0);
    }

    public Integer getCnnNum() {
        return Optional.ofNullable(cnnNum).orElse(0);
    }

    public Integer getInfNum() {
        return Optional.ofNullable(infNum).orElse(0);
    }

}
