package com.ruoyi.gds.forest;

import com.dtflys.forest.annotation.BaseRequest;
import com.dtflys.forest.annotation.Body;
import com.dtflys.forest.annotation.Header;
import com.dtflys.forest.annotation.Post;
import com.dtflys.forest.http.ForestResponse;
import com.ruoyi.gds.common.CommonConstant;
import com.ruoyi.gds.enums.BusinessType;
import com.ruoyi.gds.forest.interceptor.BaseInterceptor;
import org.springframework.stereotype.Component;

@Component
@BaseRequest(baseURL = "${sabre_websvc_baseurl}", interceptor = BaseInterceptor.class)
public interface SabreWebSvcApi {

    /**
     * 获取 Soap token
     *
     * @param businessType
     * @param businessCode
     * @param requestXml
     * @return
     */
    @Post(headers = {"Content-Type:text/xml"})
    ForestResponse<String> getSoapToken(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                                        @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                                        @Body String requestXml);

    /**
     * 获取 Soap session
     *
     * @param businessType
     * @param businessCode
     * @param requestXml
     * @return
     */
    @Post(headers = {"Content-Type:text/xml"})
    ForestResponse<String> getSoapSession(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                                          @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                                          @Body String requestXml);


    /**
     * 请求WebSvc接口
     *
     * @param businessType
     * @param businessCode
     * @param requestXml
     * @return
     */
    @Post(headers = {"Content-Type:text/xml"})
    ForestResponse<String> requestWebSvc(@Header(CommonConstant.FOREST_HEADER_BUSINESS_TYPE) BusinessType businessType,
                                         @Header(CommonConstant.FOREST_HEADER_BUSINESS_CODE) String businessCode,
                                         @Body String requestXml);

}
