package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import lombok.Getter;
import org.apache.commons.lang3.StringUtils;

import java.util.Arrays;

@Getter
public enum BusinessType {

    REQUEST_FORWARD("REQUEST_FORWARD", true, false),

    SEARCH_FLIGHT("SEARCH_FLIGHT", true, false),

    QUERY_PRICE("QUERY_PRICE", true, true),

    ISSUE_QUERY_PRICE("ISSUE_QUERY_PRICE", true, true),

    CREATE_PNR("CREATE_PNR", true, true),

    QUERY_PNR("QUERY_PNR", false, false),

    CANCEL_PNR("CANCEL_PNR", true, true),

    CHANGE_SEGMENT_STATUS("CHANGE_SEGMENT_STATUS", true, true),

    DELETE_SEGMENT("DELETE_SEGMENT", true, true),

    DEL_PRICE("DEL_PRICE", true, true),

    ADD_PRICE("ADD_PRICE", true, true),

    ADD_COMMISSION("ADD_COMMISSION", true, true),

    ADD_FOP("ADD_FOP", true, true),

    BSP_QUOTA("BSP_QUOTA", false, false),

    ISSUE_TICKET("ISSUE_TICKET", true, true),

    RETRIEVE_ISSUE_TICKET("RETRIEVE_ISSUE_TICKET", true, true),

    MODIFY_TRAVELER_PHONE("MODIFY_TRAVELER_PHONE", false, true),

    QUERY_RATE("QUERY_RATE", false, false),

    CABIN_QUANTITY("CABIN_QUANTITY", true, true),

    QUERY_SABRE_REST_ACCESS_TOKEN("QUERY_SABRE_REST_ACCESS_TOKEN", true, true),

    QUERY_SABRE_WEBSVC_TOKEN("QUERY_SABRE_WEBSVC_TOKEN", true, true),

    QUERY_SABRE_WEBSVC_SESSION("QUERY_SABRE_WEBSVC_SESSION", true, true),

    QUEUE_ENTER("QUEUE_ENTER", true, true),

    QUEUE_EXIT("QUEUE_EXIT", true, true),

    QUEUE_NEXT_ONE("QUEUE_NEXT_ONE", true, true)

    ;

    @JsonValue
    private final String code;

    private final boolean saveRequest;

    private final boolean saveResponse;

    BusinessType(String code, boolean saveRequest, boolean saveResponse) {
        this.code = code;
        this.saveRequest = saveRequest;
        this.saveResponse = saveResponse;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static BusinessType fromCode(String code) {
        return Arrays.stream(BusinessType.values()).filter(item -> StringUtils.isNotBlank(code) && code.equalsIgnoreCase(item.code)).findFirst().orElse(null);
    }

}
