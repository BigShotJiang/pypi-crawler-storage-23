package com.ruoyi.gds.enums.sabre;

import lombok.Getter;

@Getter
public enum SabreDataSourceStatus {

    Enable,

    Disable

}
