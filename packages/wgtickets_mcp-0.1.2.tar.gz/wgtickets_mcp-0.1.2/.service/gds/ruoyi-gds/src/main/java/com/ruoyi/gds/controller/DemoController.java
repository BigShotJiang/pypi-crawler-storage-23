package com.ruoyi.gds.controller;

import cn.hutool.core.collection.CollectionUtil;
import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.toolkit.Wrappers;
import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.JacksonUtil;
import com.ruoyi.gds.common.RedisConstant;
import com.ruoyi.gds.config.SolutionFareRefreshConfig;
import com.ruoyi.gds.enums.PassengerType;
import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.gds.module.SearchPriceReq;
import com.ruoyi.gds.module.domain.FlightFare;
import com.ruoyi.gds.module.domain.FlightSolutionFare;
import com.ruoyi.gds.module.domain.FlightSolutionPassengerFare;
import com.ruoyi.gds.module.vo.galileo.FlightPriceVo;
import com.ruoyi.gds.service.IFlightFareService;
import com.ruoyi.gds.service.IFlightSolutionFareService;
import com.ruoyi.gds.service.IFlightSolutionPassengerFareService;
import com.ruoyi.gds.utils.DateUtil;
import com.ruoyi.gds.utils.IntConvertUtil;
import com.ruoyi.gds.utils.RedisUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Anonymous
@RestController
@RequestMapping("/air")
public class DemoController {

    @Autowired
    private IFlightSolutionFareService flightSolutionFareService;
    @Autowired
    private IFlightSolutionPassengerFareService flightSolutionPassengerFareService;
    @Autowired
    private IFlightFareService flightFareService;
    @Autowired
    private SolutionFareRefreshConfig solutionFareRefreshConfig;
    @Autowired
    private RedisUtil redisUtil;

    /**
     * 获取报价分值
     *
     * @param flightFareKey
     * @return
     */
    @GetMapping(value = "/score/{flightFareKey}")
    public AjaxResult searchFlight(@PathVariable String flightFareKey) {
        boolean isNumber = IntConvertUtil.isNumber(flightFareKey);
        SearchPriceReq searchPriceReq;
        LocalDateTime lastRefreshTime, nextRefreshTime;
        if (isNumber) {
            FlightSolutionFare flightSolutionFare = flightSolutionFareService.selectByFareId(Long.parseLong(flightFareKey));
            if (Objects.isNull(flightSolutionFare)) throw new InvalidParamException("报价ID错误");

            LambdaQueryWrapper<FlightSolutionPassengerFare> queryWrapper = Wrappers.lambdaQuery(FlightSolutionPassengerFare.class)
                    .eq(FlightSolutionPassengerFare::getSearchParamKey, flightSolutionFare.getSearchParamKey())
                    .eq(FlightSolutionPassengerFare::getSolutionKey, flightSolutionFare.getSolutionKey())
                    .eq(FlightSolutionPassengerFare::getProviderCode, flightSolutionFare.getProviderCode());
            List<FlightSolutionPassengerFare> flightSolutionPassengerFares = flightSolutionPassengerFareService.list(queryWrapper);
            if (CollectionUtil.isEmpty(flightSolutionPassengerFares)) throw new InvalidParamException("乘机人为空");

            List<PassengerType> passengerTypes = flightSolutionPassengerFares.stream().map(passengerFare ->
                            Stream.generate(() -> PassengerType.fromCode(passengerFare.getPassengerType())).limit(passengerFare.getPassengerNum()).collect(Collectors.<PassengerType>toList()))
                    .collect(ArrayList::new, List::addAll, List::addAll);
            searchPriceReq = SearchPriceReq.builder()
                    .batchCode(flightSolutionFare.getSearchParamKey())
                    .flightKey(flightSolutionFare.getSolutionKey())
                    .flightFareKey(flightSolutionFare.getSolutionFareId())
                    .passengers(passengerTypes)
                    .build();
            lastRefreshTime = flightSolutionFare.getUpdateTime();
        } else {
            FlightFare flightFare = flightFareService.getByFlightFareKey(flightFareKey);
            if (Objects.isNull(flightFare)) throw new InvalidParamException("报价Key错误");

            List<FlightPriceVo> passengerFares = JacksonUtil.toBeanList(flightFare.getPassengerPrices(), FlightPriceVo.class);
            if (CollectionUtil.isEmpty(passengerFares)) throw new InvalidParamException("乘机人为空");

            List<PassengerType> passengerTypes = passengerFares.stream()
                    .map(FlightPriceVo::getPassengerTypes)
                    .collect(ArrayList::new, List::addAll, List::addAll);

            searchPriceReq = SearchPriceReq.builder()
                    .batchCode(flightFare.getBatchCode())
                    .flightKey(flightFare.getFlightKey())
                    .flightFareKey(flightFare.getFlightFareKey())
                    .passengers(passengerTypes)
                    .build();
            lastRefreshTime = flightFare.getUpdateTime();
        }

        Double score = redisUtil.getScore(RedisConstant.ZSET_SOLUTION_SCROE_KEY, searchPriceReq);
        if (Objects.isNull(score)) throw new ServiceException("无分值");

        SolutionFareRefreshConfig.RefreshRule refreshRule = solutionFareRefreshConfig.match(score.intValue());
        if (Objects.isNull(refreshRule)) throw new ServiceException("分值(" + score.intValue() + ")无刷新策略");

        nextRefreshTime = DateUtil.getNextRefreshTime(lastRefreshTime, refreshRule.getFrequency(), refreshRule.getTimeUnit());

        Map<String, Object> map = new HashMap<>();
        map.put("分值", score.intValue());
        map.put("刷新策略", refreshRule);
        map.put("上次刷新时间", Optional.ofNullable(lastRefreshTime).map(time -> time.format(DateTimeFormatter.ofPattern(DatePattern.NORM_DATETIME_PATTERN))).orElse(null));
        map.put("下次刷新时间", Optional.ofNullable(nextRefreshTime).map(time -> time.format(DateTimeFormatter.ofPattern(DatePattern.NORM_DATETIME_PATTERN))).orElse(null));

        return AjaxResult.success(map);
    }


}
