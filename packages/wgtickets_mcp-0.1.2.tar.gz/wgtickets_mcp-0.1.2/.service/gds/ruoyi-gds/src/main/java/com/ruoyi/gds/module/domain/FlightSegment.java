package com.ruoyi.gds.module.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Objects;

/**
 * 航段对象 flight_segment
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightSegment implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 航段Key（航段的 市场方航司+市场方航班号+承运官方航司+承运方航班号+出发机场三字码+到达机场三字码+出发时间+到达时间 的MD5值）
     */
    @Excel(name = "航段Key", readConverterExp = "航=段的,市=场方航司+市场方航班号+承运官方航司+承运方航班号+出发机场三字码+到达机场三字码+出发时间+到达时间,的=MD5值")
    private String segmentKey;

    /**
     * 市场方航司
     */
    @Excel(name = "市场方航司")
    private String carrier;

    /**
     * 市场方航班号
     */
    @Excel(name = "市场方航班号")
    private String flightNumber;

    /**
     * 承运方航司
     */
    @Excel(name = "承运方航司")
    private String operatingCarrier;

    /**
     * 承运方航班号
     */
    @Excel(name = "承运方航班号")
    private String operatingFlightNumber;

    /**
     * 出发机场三字码
     */
    @Excel(name = "出发机场三字码")
    private String origin;

    /**
     * 到达机场三字码
     */
    @Excel(name = "到达机场三字码")
    private String destination;

    /**
     * 出发时间
     */
    @Excel(name = "出发时间")
    private String departureTime;

    /**
     * 到达时间
     */
    @Excel(name = "到达时间")
    private String arrivalTime;

    /**
     * 飞行时长。单位分钟
     */
    @Excel(name = "飞行时长。单位分钟")
    private Integer flightTime;

    /**
     * 距离
     */
    @Excel(name = "距离")
    private Integer distance;

    /**
     * 机型
     */
    @Excel(name = "机型")
    private String equipment;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 是否已删除（false：未删除，true：已删除）
     */
    private boolean delFlag;



    /**
     * 伽利略SegmentKey
     */
    @TableField(exist = false)
    private String gdsSegmentKey;


    @Override
    public boolean equals(Object o) {
        if (o == null || getClass() != o.getClass()) return false;
        FlightSegment that = (FlightSegment) o;
        return Objects.equals(segmentKey, that.segmentKey);
    }

    @Override
    public int hashCode() {
        return Objects.hashCode(segmentKey);
    }

}
