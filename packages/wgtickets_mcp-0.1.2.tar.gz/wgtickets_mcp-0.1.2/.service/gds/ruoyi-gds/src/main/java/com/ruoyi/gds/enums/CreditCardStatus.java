package com.ruoyi.gds.enums;

public enum CreditCardStatus {
    // 开卡中
    CREATEING,
    // 开卡失败
    CREATE_FAIL,
    // 未使用
    UNUSED,
    // 已使用
    USED
}
