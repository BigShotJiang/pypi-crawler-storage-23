package com.ruoyi.gds.enums;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonValue;
import com.ruoyi.common.utils.StringUtils;
import lombok.Getter;

import java.util.Arrays;
import java.util.Objects;

@Getter
public enum FlightReqType {

    SEARCH_FLIGHT(1, "搜索"),
    SEARCH_PRICE(2, "查价"),
    CREATE_PNR(3, "预定"),
    CANCEL_PNR(4, "取消预定"),
    ISSUE_TICKET(5, "出票"),
    BATCH_SEARCH_FLIGHT(6, "批量搜索"),
    COMMAND_SEARCH_FLIGHT(7, "指令搜索"),
    BATCH_SEARCH_PRICE(8, "批量查价");

    @JsonValue
    private final Integer code;

    private final String desc;

    FlightReqType(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    @JsonCreator(mode = JsonCreator.Mode.DELEGATING)
    public static FlightReqType fromCode(Integer code) {
        return Arrays.stream(FlightReqType.values()).filter(item -> Objects.nonNull(code) && Objects.equals(item.code, code)).findFirst().orElse(null);
    }

    public static FlightReqType fromCode(String code) {
        return Arrays.stream(FlightReqType.values()).filter(item -> StringUtils.isNotBlank(code) && String.valueOf(item.code).equalsIgnoreCase(code)).findFirst().orElse(null);
    }

    @Override
    public String toString() {
        return code + ": " + desc;
    }

}
