package com.ruoyi.gds.module.domain;

import cn.hutool.core.date.DatePattern;
import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ruoyi.common.annotation.Excel;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

/**
 * 各GDS报价对象 flight_solution_fare
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightSolutionFare implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 主键ID
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 报价ID
     */
    @Excel(name = "行程方案报价ID")
    private Long fareId;

    /**
     * 搜索条件Key
     */
    @Excel(name = "搜索条件Key")
    private String searchParamKey;

    /**
     * 行程方案Key
     */
    @Excel(name = "行程方案Key")
    private String solutionKey;

    /**
     * GDS代码
     */
    @Excel(name = "GDS代码")
    private String providerCode;

    /**
     * 币种
     */
    @Excel(name = "币种")
    private String currencyCode;

    /**
     * 总价
     */
    @Excel(name = "总价")
    private BigDecimal totalPrice;

    /**
     * 基础运价
     */
    @Excel(name = "基础运价")
    private BigDecimal basePrice;

    /**
     * 总税费
     */
    @Excel(name = "总税费")
    private BigDecimal taxes;

    /**
     * 各航段舱位号。PriceCarbinVo.class
     */
    @Excel(name = "各航段舱位号")
    private String cabins;

    /**
     * 价格有效期
     */
    @Excel(name = "价格有效期")
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime latestTicketingTime;

    /**
     * 创建者
     */
    private String createBy;

    /**
     * 创建时间
     */
    private LocalDateTime createTime;

    /**
     * 更新时间
     */
    private LocalDateTime updateTime;

    /**
     * 是否已删除（false：未删除，true：已删除）
     */
    private boolean delFlag;


    @TableField(exist = false)
    private String solutionFareId;

    public String getSolutionFareId() {
        return Optional.ofNullable(solutionFareId).filter(StringUtils::isNotBlank).orElse(Optional.ofNullable(fareId).map(String::valueOf).orElse(null));
    }

}
