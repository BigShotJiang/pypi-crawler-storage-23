package com.ruoyi.gds.module;

import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.module.dto.validation.Galelio;
import com.ruoyi.gds.module.dto.validation.IBE;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CancelPnrReq<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * GDS类型为空
     */
    @NotNull(message = "GDS类型为空", groups = {Galelio.class, IBE.class})
    private GDSType providerCode;

    /**
     * PNR
     */
    @NotNull(message = "PNR为空", groups = {Galelio.class, IBE.class})
    private String pnr;

    /**
     * GDS返回的原始信息
     */
    private T orignalInfo;

}
