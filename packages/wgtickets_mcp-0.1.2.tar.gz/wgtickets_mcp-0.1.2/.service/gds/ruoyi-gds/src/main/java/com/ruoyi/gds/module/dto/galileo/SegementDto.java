package com.ruoyi.gds.module.dto.galileo;

import com.ruoyi.gds.annotation.IncludeField;
import com.ruoyi.gds.enums.CabinCategoryType;
import com.ruoyi.gds.enums.GDSType;
import com.ruoyi.gds.module.dto.validation.Galelio;
import com.ruoyi.gds.module.dto.validation.IBE;
import com.ruoyi.gds.module.vo.SegmentHexVo;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SegementDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 行程序号。非前端传参，后端设置值
     */
    private Integer seq;

    /**
     * GDS类型。非前端传参，后端设置值
     */
    private GDSType providerCode;

    /**
     * 伽利略时必填
     */
    @NotBlank(message = "行程Key为空", groups = {Galelio.class})
    private String segmentKey;

    /**
     * 行程编号
     */
    @NotNull(message = "行程编号为空", groups = {Galelio.class})
    private Integer group;

    /**
     * 航司二字码（市场方）
     */
    @IncludeField
    @NotBlank(message = "市场方航司二字码为空", groups = {Galelio.class, IBE.class})
    private String carrier;

    /**
     * 航班号（市场方）
     */
    @IncludeField
    @NotBlank(message = "市场方航班号为空", groups = {Galelio.class, IBE.class})
    private String flightNumber;

    /**
     * 航司二字码（承运方）
     */
    @IncludeField
    @NotBlank(message = "承运方航司二字码为空", groups = {IBE.class})
    private String operatingCarrier;

    /**
     * 航班号（承运方）
     */
    @IncludeField
    @NotBlank(message = "承运方航班号为空", groups = {IBE.class})
    private String operatingFlightNumber;

    /**
     * 出发地
     */
    @IncludeField
    @NotBlank(message = "出发地为空", groups = {Galelio.class, IBE.class})
    private String origin;

    /**
     * 目的地
     */
    @IncludeField
    @NotBlank(message = "目的地为空", groups = {Galelio.class, IBE.class})
    private String destination;

    /**
     * 出发时间
     */
    @IncludeField
    @NotBlank(message = "出发时间为空", groups = {Galelio.class, IBE.class})
    private String departureTime;

    /**
     * 到达时间。IBE时必填
     */
    @IncludeField
    @NotBlank(message = "到达时间为空", groups = {IBE.class})
    private String arrivalTime;

    /**
     * 舱位等级
     */
    @IncludeField
    private String classOfService;

    /**
     * 大舱位等级。仅查询报价时做判断用
     */
    private CabinCategoryType cabinType;


    public SegmentHexVo toSegmentHexVo() {
        return SegmentHexVo.builder()
                .carrier(getCarrier())
                .flightNumber(getFlightNumber())
                .operatingCarrier(getOperatingCarrier())
                .operatingFlightNumber(getOperatingFlightNumber())
                .origin(getOrigin())
                .destination(getDestination())
                .departureTime(getDepartureTime())
                .arrivalTime(getArrivalTime())
                .build();
    }

}
