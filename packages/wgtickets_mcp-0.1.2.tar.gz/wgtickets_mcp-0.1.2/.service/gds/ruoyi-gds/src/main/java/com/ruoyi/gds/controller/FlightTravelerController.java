package com.ruoyi.gds.controller;

import com.ruoyi.common.annotation.Anonymous;
import com.ruoyi.common.constant.HttpStatus;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.core.page.TableDataInfo;
import com.ruoyi.common.exception.ServiceException;
import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.gds.common.ParamValidRegex;
import com.ruoyi.gds.exception.InvalidParamException;
import com.ruoyi.gds.module.domain.FlightTraveler;
import com.ruoyi.gds.service.IFlightTravelerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.Objects;
import java.util.regex.Pattern;

/**
 * 乘机人Controller
 * 
 * @author ruoyi
 * @date 2025-04-18
 */
@RestController
@RequestMapping("/flight/traveler")
public class FlightTravelerController extends BaseController
{
    @Autowired
    private IFlightTravelerService flightTravelerService;

    /**
     * 查询乘机人列表
     */
    @GetMapping("/list")
    public TableDataInfo list(FlightTraveler flightTraveler)
    {
        startPage();
        List<FlightTraveler> list = flightTravelerService.selectFlightTravelerList(flightTraveler);
        return getDataTable(list);
    }

    /**
     * 导出乘机人列表
     */
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightTraveler flightTraveler)
    {
        List<FlightTraveler> list = flightTravelerService.selectFlightTravelerList(flightTraveler);
        ExcelUtil<FlightTraveler> util = new ExcelUtil<FlightTraveler>(FlightTraveler.class);
        util.exportExcel(response, list, "乘机人数据");
    }

    /**
     * 获取乘机人详细信息
     */
    @Anonymous
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id)
    {
        return success(flightTravelerService.selectFlightTravelerById(id));
    }

    /**
     * 新增乘机人
     */
    @Anonymous
    @PostMapping
    public AjaxResult add(@RequestBody @Validated FlightTraveler flightTraveler)
    {
        if (StringUtils.isBlank(flightTraveler.getPhone()) && StringUtils.isBlank(flightTraveler.getEmail())) {
            throw new ServiceException("手机号和邮箱不能都为空", HttpStatus.BAD_REQUEST);
        }

        /*if (StringUtils.isBlank(flightTraveler.getEmergencyPhone()) && StringUtils.isBlank(flightTraveler.getEmergencyEmail())) {
            throw new ServiceException("紧急联系人手机号和邮箱不能都为空", HttpStatus.BAD_REQUEST);
        }*/

        if (StringUtils.isNotBlank(flightTraveler.getPhone()) && !Pattern.matches(ParamValidRegex.PHONE_WITH_ZONE, flightTraveler.getPhone())) {
            throw new InvalidParamException("出行人手机号仅支持中国大陆和日本手机号");
        }

        if (StringUtils.isNotBlank(flightTraveler.getEmergencyPhone()) && !Pattern.matches(ParamValidRegex.PHONE_WITH_ZONE, flightTraveler.getEmergencyPhone())) {
            throw new InvalidParamException("紧急联系人手机号仅支持中国大陆和日本手机号");
        }

        return AjaxResult.success(flightTravelerService.insertFlightTraveler(flightTraveler));
    }

    /**
     * 修改乘机人
     */
    @Anonymous
    @PutMapping
    public AjaxResult edit(@RequestBody @Validated FlightTraveler flightTraveler)
    {
        if (Objects.isNull(flightTraveler.getId())) throw new ServiceException("主键ID为空", HttpStatus.BAD_REQUEST);
        if (flightTraveler.getId() < 1) throw new ServiceException("无效的主键ID", HttpStatus.BAD_REQUEST);

        if (StringUtils.isBlank(flightTraveler.getPhone()) && StringUtils.isBlank(flightTraveler.getEmail())) {
            throw new ServiceException("手机号和邮箱不能都为空", HttpStatus.BAD_REQUEST);
        }

        /*if (StringUtils.isBlank(flightTraveler.getEmergencyPhone()) && StringUtils.isBlank(flightTraveler.getEmergencyEmail())) {
            throw new ServiceException("紧急联系人手机号和邮箱不能都为空", HttpStatus.BAD_REQUEST);
        }*/

        if (StringUtils.isNotBlank(flightTraveler.getPhone()) && !Pattern.matches(ParamValidRegex.PHONE_WITH_ZONE, flightTraveler.getPhone())) {
            throw new InvalidParamException("出行人手机号仅支持中国大陆和日本手机号");
        }

        if (StringUtils.isNotBlank(flightTraveler.getEmergencyPhone()) && !Pattern.matches(ParamValidRegex.PHONE_WITH_ZONE, flightTraveler.getEmergencyPhone())) {
            throw new InvalidParamException("紧急联系人手机号仅支持中国大陆和日本手机号");
        }

        return AjaxResult.success(flightTravelerService.updateFlightTraveler(flightTraveler));
    }

    /**
     * 证件号查询乘机人
     */
    @Anonymous
    @GetMapping("/queryByCertificate")
    public AjaxResult queryByCertificate(@RequestParam String certificate)
    {
        FlightTraveler flightTraveler = flightTravelerService.queryByCertificate(certificate);
        return AjaxResult.success(flightTraveler);
    }

    /**
     * 删除乘机人
     */
	@DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids)
    {
        return toAjax(flightTravelerService.deleteFlightTravelerByIds(ids));
    }
}
