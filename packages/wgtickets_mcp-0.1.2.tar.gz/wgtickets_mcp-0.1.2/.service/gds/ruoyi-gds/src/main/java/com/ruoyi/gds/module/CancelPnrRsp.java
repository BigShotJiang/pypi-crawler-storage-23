//package com.ruoyi.gds.module;
//
//import lombok.*;
//import lombok.experimental.SuperBuilder;
//
//import java.io.Serializable;
//
//@EqualsAndHashCode(callSuper = true)
//@Data
//@SuperBuilder
//@NoArgsConstructor
//@AllArgsConstructor
//public class CancelPnrRsp<T> extends CommonRsp<T> implements Serializable {
//
//    private static final long serialVersionUID = 1L;
//
//}
