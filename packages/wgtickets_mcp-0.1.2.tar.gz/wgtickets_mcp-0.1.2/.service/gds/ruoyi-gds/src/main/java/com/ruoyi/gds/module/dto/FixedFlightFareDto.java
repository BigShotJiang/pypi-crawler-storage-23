package com.ruoyi.gds.module.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 *
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FixedFlightFareDto implements Serializable {
    private static final long serialVersionUID = 1L;

    /**
     * 批次号
     */
    private String batchCode;

    /**
     * 行程key
     */
    private String flightKey;

    /**
     * 行程报价key
     */
    private String flightFareKey;

    /**
     * 行程报价版本
     */
    private Integer flightFareVersion;

}
