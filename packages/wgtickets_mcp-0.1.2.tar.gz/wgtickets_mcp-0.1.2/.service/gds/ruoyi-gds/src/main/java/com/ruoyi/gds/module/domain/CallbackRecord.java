package com.ruoyi.gds.module.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;
import com.ruoyi.common.annotation.Excel;
import com.ruoyi.common.core.domain.BaseEntity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 回调记录对象 callback_record
 *
 * @author ruoyi
 * @date 2025-12-12
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CallbackRecord implements Serializable
{
    private static final long serialVersionUID = 1L;

    /** 主键ID */
    private Long id;

    /** 平台 */
    @Excel(name = "平台")
    private String platform;

    /** 第三方平台订单号 */
    @Excel(name = "第三方平台订单号")
    private String orderSn;

    /** 订单金额 */
    @Excel(name = "订单金额")
    private BigDecimal price;

    /** 内容 */
    @Excel(name = "内容")
    private String content;

    /** 是否已删除（0：未删除，1：已删除） */
    private Integer delFlag;

    private String gds;

    private Date createTime;

    private Date updateTime;

    /**
     * 更新状态
     */
    private String updateStatus;
}
