package com.ruoyi.gds.mapper;

import java.util.List;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.FlightSegment;
import org.apache.ibatis.annotations.Param;

/**
 * 航段Mapper接口
 *
 * @author ruoyi
 * @date 2025-09-24
 */
public interface FlightSegmentMapper extends BaseMapper<FlightSegment> {
    /**
     * 查询航段
     *
     * @param id 航段主键
     * @return 航段
     */
    public FlightSegment selectFlightSegmentById(Long id);

    /**
     * 查询航段列表
     *
     * @param flightSegment 航段
     * @return 航段集合
     */
    public List<FlightSegment> selectFlightSegmentList(FlightSegment flightSegment);

    /**
     * 新增航段
     *
     * @param flightSegment 航段
     * @return 结果
     */
    public int insertFlightSegment(FlightSegment flightSegment);

    /**
     * 修改航段
     *
     * @param flightSegment 航段
     * @return 结果
     */
    public int updateFlightSegment(FlightSegment flightSegment);

    /**
     * 删除航段
     *
     * @param id 航段主键
     * @return 结果
     */
    public int deleteFlightSegmentById(Long id);

    /**
     * 批量删除航段
     *
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightSegmentByIds(Long[] ids);

    /**
     * 批量写入，重复时跳过
     * @param flightSegments
     * @return
     */
    int batchInsert(@Param("flightSegments") List<FlightSegment> flightSegments);

}
