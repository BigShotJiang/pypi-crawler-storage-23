package com.ruoyi.gds.config;

import com.ruoyi.gds.module.IdWorker;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.Serializable;

@Configuration
public class IdWorkerConfig implements Serializable {

    private static final long serialVersionUID = 1L;

    @Autowired
    private SnowflakeConfig snowflakeConfig;

    @Bean
    public IdWorker idWorker(){
        return new IdWorker(snowflakeConfig.getWorkerId(), snowflakeConfig.getDataCenterId());
    }

}
