package com.ruoyi.gds.module.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FlightChange {

    /**
     * 航班号
     * 1、3查询方式必传
     */
    @Valid
    @NotBlank(message = "航班号为空")
    private String fnum;
    /**
     * 出发机场三字码
     * 2、3查询方式必传
     */
    @Valid
    @NotBlank(message = "出发机场三字码为空")
    private String depCode;
    /**
     * 到达机场三字码
     * 2、3查询方式必传
     */
    @Valid
    @NotBlank(message = "到达机场三字码为空")
    private String arrCode;

    /**
     * 航班出发日期（yyyy-mm-dd格式
     */
    @Valid
    @NotBlank(message = "航班出发日期为空")
    private String depTime;
}
