package com.ruoyi.gds.module.dto;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class FlightNumberPassengerBaggageDto extends PassengerBaggageDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 航班号。eg：MU730
     */
    @NotBlank(message = "航班号为空. 例如: MU730")
    private String flightNumber;

}
