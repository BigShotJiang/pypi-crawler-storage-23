package com.ruoyi.gds.enums.ibe;

public enum IBEAvailabilityType {

    CACHE_PLUS

}
