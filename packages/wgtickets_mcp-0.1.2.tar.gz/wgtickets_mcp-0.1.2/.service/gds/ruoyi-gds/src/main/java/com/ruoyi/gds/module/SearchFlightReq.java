package com.ruoyi.gds.module;

import com.ruoyi.common.utils.StringUtils;
import com.ruoyi.gds.annotation.IncludeField;
import com.ruoyi.gds.enums.*;
import com.ruoyi.gds.module.dto.galileo.FlightDto;
import com.ruoyi.gds.utils.AnnotationFieldUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;
import org.assertj.core.util.Lists;

import java.io.Serializable;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class SearchFlightReq extends LoaclSearchFlightReq implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 业务场景（GDS、TICKET、FLY...）。默认：TICKET
     */
    private BusinessScene businessScene;

    /**
     * GDS平台
     */
    private GDSType gds;

    /**
     * 搜索方式
     */
    private SearchType searchType;

    /**
     * 业务ID（问票ID）
     */
    private String businessId;

    /**
     * 行程类型
     */
    @IncludeField
    private TripType tripType;

    /**
     * 行程信息
     */
    @IncludeField
    private List<FlightDto> flights;

    /**
     * 乘客信息
     */
    @IncludeField
    private List<PassengerType> passengers;

    /**
     * 航司搜索方式
     */
    @IncludeField
    private SearchMethod carriersType;

    /**
     * 指定航司
     */
    @IncludeField
    private List<String> carriers;

    /**
     * 舱位等级搜索方式
     * Permitted 只返回特定舱位
     * Prohibited 排除特定舱位
     */
    @IncludeField
    private SearchMethod cabinsType;

    /**
     * 指定舱位等级
     */
    @IncludeField
    protected List<CabinCategoryType> cabins;

    /**
     * 是否允许转机
     */
    @IncludeField
    private Boolean transfer;

    /**
     * 最大条数
     */
    private Integer maxResponse;



    /*public Boolean getTransfer() {
        return Optional.ofNullable(transfer).orElse(false);
    }*/

    public BusinessScene getBusinessScene() {
        return Optional.ofNullable(businessScene).orElse(BusinessScene.TICKET);
    }

    public SearchMethod getCarriersType() {
        return Optional.ofNullable(carriersType).orElse(SearchMethod.PERMITTED);
    }

    public List<String> getCarriers() {
        return Optional.ofNullable(carriers)
                .map(carrierList -> carrierList.stream().filter(StringUtils::isNotBlank).map(String::toUpperCase).distinct().collect(Collectors.toList()))
                .orElse(Lists.newArrayList());
    }

    public SearchMethod getCabinsType() {
        return Optional.ofNullable(cabinsType).orElse(SearchMethod.PERMITTED);
    }

    public String getSearchFlightParamKey() {
        return AnnotationFieldUtil.getAnnotatedFieldMd5Hex(this);
    }

}
