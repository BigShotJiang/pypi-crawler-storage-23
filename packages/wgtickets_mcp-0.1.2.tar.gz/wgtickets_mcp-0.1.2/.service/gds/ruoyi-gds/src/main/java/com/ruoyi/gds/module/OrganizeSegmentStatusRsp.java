package com.ruoyi.gds.module;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.experimental.SuperBuilder;

import java.io.Serializable;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
@NoArgsConstructor
@AllArgsConstructor
public class OrganizeSegmentStatusRsp<T> extends CommonRsp<T> implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * PNR
     */
    private String pnr;

}
