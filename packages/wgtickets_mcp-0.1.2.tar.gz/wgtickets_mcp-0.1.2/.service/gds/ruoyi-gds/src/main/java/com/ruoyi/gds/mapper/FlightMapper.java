package com.ruoyi.gds.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.ruoyi.gds.module.domain.Flight;

import java.util.List;

/**
 * 搜索航班结果Mapper接口
 * 
 * @author ruoyi
 * @date 2025-04-14
 */
public interface FlightMapper extends BaseMapper<Flight>
{
    /**
     * 查询搜索航班结果
     * 
     * @param id 搜索航班结果主键
     * @return 搜索航班结果
     */
    public Flight selectFlightById(Long id);

    /**
     * 查询搜索航班结果列表
     * 
     * @param flight 搜索航班结果
     * @return 搜索航班结果集合
     */
    public List<Flight> selectFlightList(Flight flight);

    /**
     * 新增搜索航班结果
     * 
     * @param flight 搜索航班结果
     * @return 结果
     */
    public int insertFlight(Flight flight);

    /**
     * 修改搜索航班结果
     * 
     * @param flight 搜索航班结果
     * @return 结果
     */
    public int updateFlight(Flight flight);

    /**
     * 删除搜索航班结果
     * 
     * @param id 搜索航班结果主键
     * @return 结果
     */
    public int deleteFlightById(Long id);

    /**
     * 批量删除搜索航班结果
     * 
     * @param ids 需要删除的数据主键集合
     * @return 结果
     */
    public int deleteFlightByIds(Long[] ids);
}
