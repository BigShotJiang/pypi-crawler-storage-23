package com.ruoyi.gds.forest;

import com.dtflys.forest.annotation.Get;
import com.dtflys.forest.annotation.Query;
import com.ruoyi.common.module.vo.ResultVo;
import com.ruoyi.gds.module.vo.CreateCreditCardResultVo;
import org.springframework.stereotype.Component;

@Component
public interface PayApi {

    /**
     * 信用卡开卡
     *
     * @param mode
     * @param currency
     * @param totalAmount
     * @param inactiveDate
     * @param server
     * @param userName
     * @return
     */
    @Get(url = "${create_card_url}", logEnabled = true)
    ResultVo<CreateCreditCardResultVo> getCreditCard(@Query("mode") String mode,
                                                     @Query("currency") String currency,
                                                     @Query("total_amount") String totalAmount,
                                                     @Query("active_date") String activeDate,
                                                     @Query("inactive_date") String inactiveDate,
                                                     @Query("server") String server,
                                                     @Query("user_name") String userName,
                                                     @Query("orderNum") String orderNum);

}
