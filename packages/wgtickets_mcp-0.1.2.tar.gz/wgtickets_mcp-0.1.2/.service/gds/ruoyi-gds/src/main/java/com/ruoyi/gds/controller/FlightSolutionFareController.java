package com.ruoyi.gds.controller;

import java.util.List;
import javax.servlet.http.HttpServletResponse;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.ruoyi.common.annotation.Log;
import com.ruoyi.common.core.controller.BaseController;
import com.ruoyi.common.core.domain.AjaxResult;
import com.ruoyi.common.enums.BusinessType;
import com.ruoyi.gds.module.domain.FlightSolutionFare;
import com.ruoyi.gds.service.IFlightSolutionFareService;
import com.ruoyi.common.utils.poi.ExcelUtil;
import com.ruoyi.common.core.page.TableDataInfo;

/**
 * 各GDS报价Controller
 *
 * @author ruoyi
 * @date 2025-09-24
 */
@RestController
@RequestMapping("/flight/solution/fare")
public class FlightSolutionFareController extends BaseController {
    @Autowired
    private IFlightSolutionFareService flightSolutionFareService;

    /**
     * 查询各GDS报价列表
     */
    @PreAuthorize("@ss.hasPermi('system:fare:list')")
    @GetMapping("/list")
    public TableDataInfo list(FlightSolutionFare flightSolutionFare) {
        startPage();
        List<FlightSolutionFare> list = flightSolutionFareService.selectFlightSolutionFareList(flightSolutionFare);
        return getDataTable(list);
    }

    /**
     * 导出各GDS报价列表
     */
    @PreAuthorize("@ss.hasPermi('system:fare:export')")
    @Log(title = "各GDS报价", businessType = BusinessType.EXPORT)
    @PostMapping("/export")
    public void export(HttpServletResponse response, FlightSolutionFare flightSolutionFare) {
        List<FlightSolutionFare> list = flightSolutionFareService.selectFlightSolutionFareList(flightSolutionFare);
        ExcelUtil<FlightSolutionFare> util = new ExcelUtil<FlightSolutionFare>(FlightSolutionFare.class);
        util.exportExcel(response, list, "各GDS报价数据");
    }

    /**
     * 获取各GDS报价详细信息
     */
    @PreAuthorize("@ss.hasPermi('system:fare:query')")
    @GetMapping(value = "/{id}")
    public AjaxResult getInfo(@PathVariable("id") Long id) {
        return success(flightSolutionFareService.selectFlightSolutionFareById(id));
    }

    /**
     * 新增各GDS报价
     */
    @PreAuthorize("@ss.hasPermi('system:fare:add')")
    @Log(title = "各GDS报价", businessType = BusinessType.INSERT)
    @PostMapping
    public AjaxResult add(@RequestBody FlightSolutionFare flightSolutionFare) {
        return toAjax(flightSolutionFareService.insertFlightSolutionFare(flightSolutionFare));
    }

    /**
     * 修改各GDS报价
     */
    @PreAuthorize("@ss.hasPermi('system:fare:edit')")
    @Log(title = "各GDS报价", businessType = BusinessType.UPDATE)
    @PutMapping
    public AjaxResult edit(@RequestBody FlightSolutionFare flightSolutionFare) {
        return toAjax(flightSolutionFareService.updateFlightSolutionFare(flightSolutionFare));
    }

    /**
     * 删除各GDS报价
     */
    @PreAuthorize("@ss.hasPermi('system:fare:remove')")
    @Log(title = "各GDS报价", businessType = BusinessType.DELETE)
    @DeleteMapping("/{ids}")
    public AjaxResult remove(@PathVariable Long[] ids) {
        return toAjax(flightSolutionFareService.deleteFlightSolutionFareByIds(ids));
    }
}
