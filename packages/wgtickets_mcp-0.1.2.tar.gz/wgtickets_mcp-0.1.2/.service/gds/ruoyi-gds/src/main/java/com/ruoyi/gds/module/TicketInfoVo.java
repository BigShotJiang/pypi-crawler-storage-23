package com.ruoyi.gds.module;

import cn.hutool.core.date.DatePattern;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TicketInfoVo implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 乘机人姓名
     */
    private String travelerName;

    /**
     * 乘机人—姓氏
     */
    private String travelerFirstName;

    /**
     * 乘机人—名字
     */
    private String travelerLastName;

    /**
     * 证件信息
     */
    private String docs;

    /**
     * 票号
     */
    private String ticketNo;

    /**
     * 运价信息
     */
    private String remark;

    /**
     * 出票时间
     */
    @DateTimeFormat(pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonFormat(timezone = "GMT+8", pattern = DatePattern.NORM_DATETIME_PATTERN)
    @JsonSerialize(using = LocalDateTimeSerializer.class)
    @JsonDeserialize(using = LocalDateTimeDeserializer.class)
    private LocalDateTime issueTicketTime;

}
