"""测试GDS航班搜索API - 东京到武汉"""

import asyncio
import httpx
import json
from datetime import datetime, timedelta

# 配置
GDS_BASE_URL = "https://oapi.wiguo.cn/g"
GDS_DEFAULT_USERID = "127"

# 计算日期 - 搜索两周后的日期
today = datetime.now()
search_date = today + timedelta(days=14)
date_str = search_date.strftime("%Y-%m-%d")


async def search_flight(client, from_airport, to_airport, allow_transfer=True):
    """搜索单个航线"""
    headers = {
        "Content-Type": "application/json",
        "Userid": GDS_DEFAULT_USERID
    }

    body = {
        "tripType": 0,  # 0=单程, 1=往返
        "flights": [
            {
                "fromAirportCode": from_airport,
                "toAirportCode": to_airport,
                "deptDate": date_str
            }
        ],
        "passengers": ["ADT"],  # 成人
        "transfer": allow_transfer
    }

    try:
        response = await client.post(
            f"{GDS_BASE_URL}/air/searchFlight",
            json=body,
            headers=headers
        )
        response.raise_for_status()
        return response.json()
    except Exception as e:
        return {"error": str(e)}


def parse_duration(duration_str):
    """解析时间间隔字符串"""
    # P0DT14H5M0S -> 14小时5分钟
    if not duration_str:
        return ""
    import re
    hours = re.search(r'(\d+)H', duration_str)
    mins = re.search(r'(\d+)M', duration_str)
    h = int(hours.group(1)) if hours else 0
    m = int(mins.group(1)) if mins else 0
    if h > 0 and m > 0:
        return f"{h}小时{m}分钟"
    elif h > 0:
        return f"{h}小时"
    elif m > 0:
        return f"{m}分钟"
    return ""


def display_flight(flight_data, max_display=5):
    """显示航班信息"""
    if not flight_data:
        print("未找到航班")
        return

    print(f"找到 {len(flight_data)} 个航班选项\n")

    for i, item in enumerate(flight_data[:max_display], 1):
        print(f"【选项 {i}】")

        # 航班基本信息
        bounds = item.get("bounds", [])
        for bound in bounds:
            segments = bound.get("segments", [])
            travel_time = parse_duration(bound.get("travelTime", ""))

            for seg_idx, seg in enumerate(segments):
                carrier = seg.get("carrier", "")
                flight_no = seg.get("flightNumber", "")

                # origin可能是字符串或字典
                origin = seg.get("origin", {})
                if isinstance(origin, dict):
                    dep_airport = origin.get("code", "")
                else:
                    dep_airport = str(origin)

                destination = seg.get("destination", {})
                if isinstance(destination, dict):
                    arr_airport = destination.get("code", "")
                else:
                    arr_airport = str(destination)

                # departure可能是字符串或字典
                departure = seg.get("departure", {})
                if isinstance(departure, dict):
                    dep_time = departure.get("time", "")
                else:
                    dep_time = str(departure)

                arrival = seg.get("arrival", {})
                if isinstance(arrival, dict):
                    arr_time = arrival.get("time", "")
                else:
                    arr_time = str(arrival)

                cabin = seg.get("cabin", "")

                # 处理转机
                if seg_idx > 0:
                    print(f"  ↓ 转机")

                print(f"  {carrier}{flight_no}: {dep_airport} -> {arr_airport}")
                print(f"    出发: {dep_time}")
                print(f"    到达: {arr_time}")
                if cabin:
                    print(f"    舱位: {cabin}")

            if travel_time:
                print(f"  总飞行时间: {travel_time}")

        # 价格信息
        price_info = item.get("priceInfo", {})
        if price_info:
            total = price_info.get("totalPrice")
            currency = price_info.get("currency", "CNY")
            if total:
                print(f"  票价: {total} {currency}")

        # 其他信息
        batch_code = item.get("batchCode", "")
        flight_key = item.get("flightKey", "")
        print(f"  批次号: {batch_code[:16]}...")
        print()


async def main():
    print(f"搜索日期: {date_str}")
    print("=" * 60)

    routes = [
        ("NRT", "WUH", "东京成田 -> 武汉", True),
    ]

    async with httpx.AsyncClient(timeout=120.0) as client:
        for from_code, to_code, desc, transfer in routes:
            print(f"\n航线: {desc}")
            print("-" * 60)

            result = await search_flight(client, from_code, to_code, transfer)

            if "error" in result:
                print(f"错误: {result['error']}")
                continue

            code = result.get("code")
            msg = result.get("msg", "")
            data = result.get("data", [])

            print(f"状态: {code} - {msg}")

            if code == 200 and data:
                display_flight(data, max_display=10)
            else:
                print("未找到航班")


if __name__ == "__main__":
    asyncio.run(main())
