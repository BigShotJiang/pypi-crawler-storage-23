# Mandatory Agent Skills and Usage Order

This file defines required skill usage for Section 13 execution.

## Mandatory Skills (Current Workspace)

- `token-efficient-coding`
- `python-code-style`
- `python-pro`
- `pytest-runner`
- `playwright` (when implementing/testing web install UX)

## Phase-to-Skill Mapping

### Design + Scope Lock

Required:

- `token-efficient-coding`
- `python-pro`

### Implementation

Required:

- `token-efficient-coding`
- `python-code-style`
- `python-pro`

### Test and Validation

Required:

- `pytest-runner`
- `playwright` (if UI flows are changed)

### Pre-Release Readiness

Required:

- `production-hardening-gate`

## Enforcement Rules

1. No task may be marked `Ready for Gate` without validation checks.
2. No install/docs claim may ship without linked artifact evidence.
3. No rollout task may be marked complete without rollback notes.
4. If a required skill is unavailable, document fallback in task record.
