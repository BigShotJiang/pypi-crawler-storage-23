# Section 13 Gate Run Summary

Date: 2026-02-21

## Commands

- `pytest tests/docs/test_installation_spec_contract.py -q`
- `pytest tests/docs/test_docs_exist.py -q`
- `pytest tests/docs/test_installation_spec_contract.py tests/docs/test_docs_exist.py tests/docs/test_explainer_provider_migration.py -q`
- `pytest tests/unit/test_quality/test_release_manifest.py -q`
- `ruff check scripts/quality/generate_release_manifest.py scripts/quality/verify_release_manifest.py`
- `mypy --strict scripts/quality/generate_release_manifest.py scripts/quality/verify_release_manifest.py`
- `python scripts/quality/generate_release_manifest.py --release-version 1.0.0 --artifact docs/install-spec.json --artifact docs/INSTALLATION-GUIDE.md --key-dir /tmp/section13-release-keys --output docs/section-13-installation-ux/artifacts/release-manifest.json`
- `python scripts/quality/verify_release_manifest.py --manifest docs/section-13-installation-ux/artifacts/release-manifest.json --output docs/section-13-installation-ux/artifacts/release-manifest-verification.json`
- `pytest tests/docs/test_installation_tracks.py tests/unit/test_quality/test_install_docs_freshness.py tests/docs/test_installation_spec_contract.py tests/docs/test_docs_exist.py -q`
- `ruff check scripts/quality/check_install_docs_freshness.py tests/docs/test_installation_tracks.py tests/unit/test_quality/test_install_docs_freshness.py`
- `mypy --strict scripts/quality/check_install_docs_freshness.py`
- `python scripts/quality/check_install_docs_freshness.py --output docs/section-13-installation-ux/artifacts/docs-version-drift-check.json`
- `./venv/bin/pytest tests/unit/test_cli/test_doctor_command.py tests/unit/test_cli/test_command_tree.py tests/e2e/test_cli_scan.py tests/docs/test_installation_org_enterprise_contract.py tests/docs/test_installation_tracks.py tests/unit/test_quality/test_install_docs_freshness.py -q`
- `./venv/bin/ruff check skillgate/cli/commands/doctor.py tests/unit/test_cli/test_doctor_command.py tests/docs/test_installation_org_enterprise_contract.py`
- `./venv/bin/mypy --strict skillgate/cli/commands/doctor.py`
- `npm run lint` (in `web-ui/`)
- `npm run type-check` (in `web-ui/`)
- `npm run test -- src/components/docs/InstallWizard.test.tsx src/__tests__/analytics.test.ts` (in `web-ui/`)
- `./venv/bin/pytest tests/docs/test_npm_shim_contract.py tests/docs/test_installation_spec_contract.py tests/docs/test_installation_tracks.py tests/docs/test_installation_org_enterprise_contract.py -q`
- `./venv/bin/pytest -m slow tests/e2e/test_npm_shim_wrapper.py -q`
- `NPM_CONFIG_CACHE=/tmp/.npm-cache npm pack --json` (in `npm-shim/`)
- `NPM_CONFIG_CACHE=/tmp/.npm-cache npm publish --access public --provenance --dry-run` (in `npm-shim/`)
- `SKILLGATE_PYTHON=./venv/bin/python node npm-shim/bin/skillgate.js version`

## Results

- `tests/docs/test_installation_spec_contract.py`: passed (4 tests)
- `tests/docs/test_docs_exist.py`: passed (55 tests)
- Combined docs suite subset: passed (61 tests)
- `tests/unit/test_quality/test_release_manifest.py`: passed (3 tests)
- Release manifest verification result: `ok=true`
- Docs/install + freshness suite: passed (66 tests)
- Install docs freshness validation: passed (`ok=true`)
- CLI doctor + docs contract suite: passed (26 tests)
- `doctor` mypy/ruff checks: passed
- Web UI lint/type-check: passed
- Web install wizard + analytics tests: passed (12 tests)
- npm shim + install docs contract suite: passed (14 tests)
- npm shim runtime e2e contracts: passed (2 tests)
- npm shim tarball integrity metadata check: passed (`filename`, `integrity`, `shasum` present)
- npm shim provenance publish dry-run: passed
- npm shim runtime delegation smoke test: passed (exit code 0)

## Scope Covered

- `17.138` canonical install strategy matrix
- `17.139` install-spec source-of-truth
- `17.140` install lifecycle docs (run/verify/uninstall)
- `17.141` deterministic version target contract
- `17.142` upgrade/rollback contract
- `17.143` signed release manifest + offline verification
- `17.145` individuals vs teams/org installation tracks
- `17.150` docs freshness drift guard (script + CI integration)
- `17.151` installer/docs launch checklist governance
- `17.144` `skillgate doctor` diagnostics command
- `17.146` org-managed settings bootstrap docs/templates
- `17.147` enterprise private/offline deployment guide
- `17.148` interactive web install wizard
- `17.149` install funnel analytics (no PII)
- Optional npm shim distribution path (`@skillgate-io/cli`) with fail-closed Python runtime delegation contract
- npm shim release governance path with provenance dry-run and attestable publish workflow
