# Sprint 7.3 Hybrid Enforcement Runbook

## Purpose

Operational migration guide for moving from local entitlement enforcement to hybrid enforcement (`saas`, `private_relay`, `airgap`) with deterministic rollback.

## Prerequisites

- API deploy includes `/api/v1/entitlements/consume-scan`, `/api/v1/entitlements/reconcile-usage`, and `/api/v1/entitlements/decision-logs`.
- Admin key is configured: `SKILLGATE_ADMIN_KEY`.
- Entitlement signing keys are provisioned and distributed to verifiers.

## Migration Steps

1. Enable signed entitlement tokens in staging.
2. Validate token claims: signature, issuer, audience, expiry, nonce replay rejection.
3. Switch staging runners from `local` to `saas`.
4. Verify local quota tampering no longer bypasses server decisions.
5. For private networks, move runners to `private_relay` and set internal authority URL.
6. For disconnected environments, generate and distribute air-gap packs.
7. Run reconciliation for representative users and verify drift is zero.
8. Export decision logs and confirm sensitive fields are redacted.

## Air-Gap Pack Operations

- Pack path: `SKILLGATE_AIRGAP_PACK_PATH`.
- Pack must include: `token`, `public_key`, `expires_at`, `fail_policy`, `usage`.
- `fail_policy=closed`: scans stop when pack expires.
- `fail_policy=open`: scans continue only through `grace_expires_at` if provided.
- Rotate pack before `expires_at`; do not rely on grace for normal operations.

## Seat and Contract Enforcement

- Team/Enterprise seat checks are enforced in:
- API team management routes.
- CLI scans when contract seat counters are provided.
- CI runs through the same CLI entitlement checks.
- Contract seat source:
- Signed entitlement limits (`max_seats`) when available.
- Runtime seat usage (`SKILLGATE_TEAM_ACTIVE_SEATS`) for CLI/CI checks.

## Dry-Run Checklist

- [ ] `saas` mode enabled in staging and successful scans recorded.
- [ ] `private_relay` mode points to internal-only endpoint (`.internal`, `.local`, private IP, or localhost).
- [ ] `airgap` pack validated with expiry and grace behavior.
- [ ] Replay protection verified by reusing a signed token nonce.
- [ ] Reconciliation endpoint reports expected drift values.
- [ ] Decision logs export includes provenance and redacts secrets.
- [ ] Team seat over-capacity attempts are blocked in API and CLI paths.
- [ ] Rollback to previous mode is documented and tested.

## Rollback

1. Set `SKILLGATE_ENTITLEMENT_MODE=local` in affected environment.
2. Remove authority URL/token configuration.
3. Keep decision logs and reconciliation outputs for incident review.
4. Re-run smoke scan and policy enforcement checks.
