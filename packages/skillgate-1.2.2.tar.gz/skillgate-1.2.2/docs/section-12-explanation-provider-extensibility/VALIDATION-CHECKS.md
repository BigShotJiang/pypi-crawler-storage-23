# Validation Checks (Mandatory)

Run from repo root unless noted.

## 1) Baseline Quality Gates

```bash
./venv/bin/ruff check .
./venv/bin/mypy --strict skillgate/
./venv/bin/pytest -q
```

## 2) Section 12 Contract Checks (As Implemented)

- CLI parsing/backward-compat/help snapshot tests (`17.133`).
- Provider resolution/adapter contract tests (`17.134`).
- Adapter integration tests for Azure/Groq/Ollama with timeout/failure paths (`17.135`).
- Allowlist/deny matrix/config validation tests (`17.136`).
- Docs lint/link/command example validation (`17.137`).

## 3) Required Evidence Per Task

- Test/check summary.
- Artifact links (logs, fixtures, snapshots).
- Compatibility note.
- Rollback/recovery note.
- Security/policy validation result.
