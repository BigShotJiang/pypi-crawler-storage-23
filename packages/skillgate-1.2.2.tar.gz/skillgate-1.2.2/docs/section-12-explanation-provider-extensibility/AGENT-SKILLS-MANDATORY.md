# Mandatory Agent Skills and Usage Order

## Mandatory Skills (Current Workspace)

- `token-efficient-coding`
- `python-code-style`
- `python-pro`
- `pytest-runner`
- `skillgate-agent-tool`
- `production-hardening-gate`

## Phase-to-Skill Mapping

### Design + Scope Lock

- `token-efficient-coding`
- `python-pro`

### Implementation

- `token-efficient-coding`
- `python-code-style`
- `python-pro`

### Test and Validation

- `pytest-runner`

### Pre-Release Readiness

Required:

- `production-hardening-gate`

## Enforcement Rules

1. No task reaches `Ready for Gate` without required validation runs.
2. No contract-breaking CLI/provider change without migration note.
3. No provider security claim without evidence.
4. strictly following the specs: skillgate/docs/section-14-governed-pipeline

## Evidence Rule

PRs must include:

- Skills applied
- Commands executed
- Gate outcomes
- Linked artifacts