# Boundaries (Fail-Closed)

## Must-Ship Scope (Now)

- New intent-first explanation flags (`17.133`).
- Provider abstraction and adapter registry (`17.134`).
- Built-in custom adapters for Azure OpenAI, Groq, Ollama (`17.135`).
- Endpoint allowlist and network policy controls (`17.136`).
- Migration and operator docs (`17.137`).

## Non-Negotiable Constraints

- User-facing help must avoid backend jargon.
- `--explain-backend` remains supported as deprecated alias for one major release.
- Provider failures must fail safe to template explanations.
- Provider egress must be explicit, restricted, and auditable.
- No secret leakage in logs or artifacts.

## Freeze Rule

If any Section 12 task is `Blocked` for >24h:

1. Stop additive provider scope.
2. Resolve blocker or descoped alternative.
3. Record mitigation in `TASKS.md` before resuming.
