# Implementation Specs (Section 12)

## 1) CLI Contract - `17.133`

Primary flags:

- `--explain`
- `--explain-mode technical|executive`
- `--explain-source auto|offline|ai`
- `--llm-provider openai|anthropic|custom`

Compatibility:

- `--explain-backend` remains as deprecated alias with warning.

## 2) Provider Abstraction - `17.134`

Provider resolution must be deterministic from flags/config and route through one adapter contract.

## 3) Built-In Custom Adapters - `17.135`

Required adapters:

- Azure OpenAI
- Groq
- Ollama

Each must honor timeout/retry limits and return common explanation payloads.

## 4) Network Policy Controls - `17.136`

- Default deny outbound provider egress unless enabled.
- Endpoint allowlist enforcement for hosted/custom providers.
- Redaction-safe logging and auditable deny/allow events.

## 5) Migration + Operator Guidance - `17.137`

- Clear migration path from `--explain-backend`.
- Enterprise operator guidance for provider policy and endpoint controls.

## 6) Reliability Rule

Any provider timeout/error/degraded dependency path must fall back to template explanations without scan failure.
