# Ralph Loop (Fail-Closed Execution)

1. Read task scope from `SPECS.md`; set status `In Progress`.
2. Implement smallest valid slice with tests.
3. Run `VALIDATION-CHECKS.md` commands.
4. Record outputs/artifacts in `PER-TASK-RECORDS.md`.
5. If any check fails, set `Blocked`, fix root cause, re-run checks.
6. Set `Ready for Gate` only when all DoD items are satisfied.
7. Set `Complete` only after gate verification.
