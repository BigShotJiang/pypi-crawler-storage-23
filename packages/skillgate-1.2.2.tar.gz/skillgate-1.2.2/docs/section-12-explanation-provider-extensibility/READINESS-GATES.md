# Readiness Gates (Section 12)

## Gate A: CLI Contract Integrity

- Intent-first help surface (`source/provider`) is active.
- Deprecated alias remains compatible and warning-gated.

## Gate B: Provider Contract

- Provider abstraction resolves deterministically.
- Azure/Groq/Ollama adapters satisfy common contract.
- Provider failures degrade safely to template explanations.

## Gate C: Security + Network Governance

- Endpoint allowlist and default-deny egress behavior are enforced.
- Deny/allow events are auditable and redaction-safe.

## Gate D: Docs + Operator Readiness

- Migration docs are complete and tested.
- Enterprise operator guide is complete and actionable.

## Release Decision

- `GO`: all gates A-D green.
- `NO-GO`: any gate red.
