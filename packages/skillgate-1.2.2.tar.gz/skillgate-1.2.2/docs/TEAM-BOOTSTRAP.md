# Team Bootstrap And Org-Managed Defaults

This guide defines a deterministic baseline for team and organization rollouts.

## Goals

- Keep policy defaults consistent across repositories.
- Lock install/update channel behavior for predictable upgrades.
- Make CI enforcement reproducible across all teams.

## Source Files

- Baseline policy template: `docs/templates/team/skillgate.team-baseline.yml`
- Bootstrap env template: `docs/templates/team/bootstrap.env.example`
- Install source of truth: `docs/install-spec.json`

## Bootstrap Steps

1. Copy `docs/templates/team/skillgate.team-baseline.yml` to repo root as `skillgate.yml`.
2. Copy `docs/templates/team/bootstrap.env.example` into CI secret/env management.
3. Pin install version in CI (`pipx install skillgate=={version}`).
4. Validate with:

```bash
skillgate version
skillgate scan . --enforce --policy production --sign --report-file skillgate-report.json
```

## Defaults Contract

- Policy preset: `production`
- Minimum confidence: `medium`
- Enforcement in CI: enabled
- Update channel: pinned version (promoted by release owner)

## Rollout Model

- Stage 1: sandbox repos
- Stage 2: low-risk production repos
- Stage 3: business-critical repos

Rollback uses the pinned previous version and last known-good policy baseline.
