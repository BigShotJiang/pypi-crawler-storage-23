# Supabase RPC Contract (Task 17.189)

Version: `v1`
Date: 2026-02-22

This document defines server-side transactional RPC functions required for
hosted auth/session compatibility flows.

## Contract Rules

1. Function names are versioned suffix `_v1`.
2. Input/output contracts are explicit and stable.
3. Error semantics are deterministic (`SQLSTATE`, explicit raises).
4. Retry-safe paths are idempotent (`ON CONFLICT`, immutable operation IDs).
5. Service-role execution only; client role direct execution is denied.

## Function Catalog

### `sg_upsert_user_session_v1`

- Purpose: Upsert domain `user_sessions` row from Supabase session context.
- Inputs:
  - `p_session_id text`
  - `p_user_id text`
  - `p_refresh_token_hash text`
  - `p_expires_at timestamptz`
  - `p_user_agent text`
  - `p_ip_address text`
- Output:
  - `jsonb` with `{status, session_id, user_id}`
- Idempotency: `INSERT ... ON CONFLICT (id) DO UPDATE`.
- Errors:
  - `22023` invalid input
  - `42501` permission denied (non service-role)

### `sg_revoke_user_sessions_v1`

- Purpose: Revoke all active sessions for user in a single transaction.
- Inputs:
  - `p_user_id text`
  - `p_reason text default 'manual_revoke'`
- Output:
  - `jsonb` with `{status, revoked_count, user_id}`
- Idempotency: repeated calls return `revoked_count=0` after first successful revoke.
- Errors:
  - `22023` invalid input
  - `42501` permission denied (non service-role)

### `sg_upsert_oauth_identity_v1`

- Purpose: Transactionally upsert OAuth identity mapping.
- Inputs:
  - `p_provider text`
  - `p_provider_user_id text`
  - `p_user_id text`
  - `p_email text`
- Output:
  - `jsonb` with `{status, identity_id, user_id}`
- Idempotency: unique key `(provider, provider_user_id)` with upsert semantics.
- Errors:
  - `22023` invalid input
  - `23505` unique conflict under invalid caller race assumptions
  - `42501` permission denied

## SQL Source of Truth

See `skillgate/api/migrations/supabase/001_rpc_contract_v1.sql`.
