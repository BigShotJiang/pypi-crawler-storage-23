# Agent Skills Mandatory: Supabase Migration

Use these skills in this order while implementing Section 16 tasks:

1. `token-efficient-coding`
2. `python-pro`
3. `python-code-style`
4. `pytest-runner` (whenever running tests)
5. `production-hardening-gate`

### Test and Validation

Required:

- `pytest-runner`
- `skillgate-agent-tool`

### Pre-Release Readiness

Required:

- `production-hardening-gate`

## Execution Rules

1. Keep changes minimal and scoped to active task IDs.
2. Do not merge implementation without matching evidence updates.
3. Run targeted tests first, then broader suite.
4. Preserve security invariants from defense tests.
5. Record rollback notes for every completed task.
6. No hardcoded or fallback logic.
7. All env variables must be defined in .env.example for backend and web-ui

## Mandatory Output Artifacts Per Task

- Test command list and results.
- Security impact notes.
- Backward-compatibility note.
- Rollback/recovery procedure.
- Links to generated evidence under `artifacts/`.
