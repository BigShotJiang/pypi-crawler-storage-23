# Cutover and Rollback Runbook (Task 17.188)

- Last updated: 2026-02-22
- Scope: Hosted auth provider cutover from `local` to `supabase`
- Applies to: dev -> staging -> production sequence only

## Preconditions

All must be true before any stage cutover:

1. `17.173`–`17.187` status is `Complete`.
2. Latest auth/security regression gate is green:
   - `tests/unit/test_api/test_auth_api_keys.py`
   - `tests/unit/test_api/test_auth_edges.py`
   - `tests/unit/test_api/test_security_utils.py`
   - `tests/unit/test_api/test_rate_limit.py`
   - `tests/defense/test_security_fixes_16_29_35.py`
3. Database migration `20260222_0006_supabase_ownership_split.py` is applied.
4. Supabase env contract validated in target environment:
   - `SKILLGATE_AUTH_PROVIDER=supabase`
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - (`SUPABASE_JWT_SECRET` or `SUPABASE_JWKS_URL`)
5. Compatibility migration preflight has executed in dry-run mode:
   - `./venv/bin/python scripts/migration/supabase_compat_migration.py --mapping-file <mapping.json> --dry-run`

## Stage 1 - Development Cutover

1. Set provider flag to `supabase` in dev environment.
2. Run smoke pack:
   - signup (new user)
   - login (verified user)
   - refresh
   - logout
   - oauth callback (provider simulation)
3. Verify no auth token/secret values appear in logs.
4. Archive artifacts under `docs/section-17-supabase-auth-migration/artifacts/`:
   - smoke output
   - compatibility summary JSON
   - rollback payload JSON

Go/No-Go to Stage 2:
- GO if all smoke checks pass and no rollback trigger is breached.

## Stage 2 - Staging Cutover

1. Execute compatibility migration apply:
   - `./venv/bin/python scripts/migration/supabase_compat_migration.py --mapping-file <mapping.json>`
2. Run full target regression pack (auth + billing + defense).
3. Perform 30-minute canary validation window with synthetic traffic.
4. Verify observability counters/logs for provider path:
   - `auth_provider_decisions_total`
   - `auth_provider_failures_total`

Go/No-Go to Stage 3:
- GO if canary window remains within rollback thresholds.

## Stage 3 - Production Cutover

1. Announce maintenance window and rollback owner.
2. Snapshot configuration and store current env var set.
3. Apply compatibility migration and preserve generated rollback payload.
4. Flip provider to `supabase`.
5. Execute production smoke checks (same as dev + profile fetch).
6. Monitor for 60 minutes before declaring stable.

## Objective Rollback Triggers

Rollback immediately if any threshold is crossed in cutover window:

- Auth 5xx rate > 1% over 5 minutes.
- Auth 401/403 combined rate > 10% over 5 minutes (excluding known bad credential tests).
- Login p95 latency > 1.5s sustained for 10 minutes.
- Refresh failure rate > 5% over 5 minutes.
- Any confirmed sensitive token leakage in logs.

## Rollback Procedure

1. Set `SKILLGATE_AUTH_PROVIDER=local`.
2. Restart API deployment.
3. Execute rollback payload from migration apply:
   - `./venv/bin/python scripts/migration/supabase_compat_migration.py --rollback --rollback-file <rollback.json>`
4. Re-run auth smoke checks in local mode.
5. Confirm user session issuance and refresh behavior restored.
6. Publish incident summary and timeline.

## Post-Cutover Verification Artifacts

Required artifacts to declare stage complete:

- `supabase-compat-summary.json`
- `supabase-compat-rollback.json`
- test output logs for staged regression pack
- smoke check transcript
- rollback rehearsal transcript (staging only)
- release decision update in `RELEASE-DECISION.md`

## Ownership Matrix

- Cutover commander: Engineering
- Rollback authority: Engineering + Operations
- Security sign-off: Security
- Final GO/NO-GO: Engineering + Product + Security
