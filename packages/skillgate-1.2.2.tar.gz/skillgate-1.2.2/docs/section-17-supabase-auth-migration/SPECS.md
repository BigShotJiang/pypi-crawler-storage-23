# Technical Specs: Tasks 17.173–17.188

## 17.173 Auth Provider Abstraction

- Add explicit hosted auth provider selector (`local`, `supabase`).
- Default behavior must be explicit by environment and fail closed on invalid values.
- Endpoint code must depend on provider interface, not concrete backend logic.

## 17.174 Supabase JWT Verifier (Python)

- Verify Supabase tokens via JWKS with bounded cache TTL.
- Enforce algorithm allowlist and reject unknown/weak algorithms.
- Enforce `iss`, `aud`, `exp`, and subject claims.
- Provide deterministic error mapping (`401` auth error, no sensitive leakage).

## 17.175 Supabase Auth Client Service

- Add service layer for signup/login/refresh/logout/reset/verify integration.
- Include timeout, retry policy, and explicit error translation.
- Preserve route-level response envelope compatibility.

## 17.176 Profile Mapping Layer

- Define canonical mapping from Supabase identity/profile fields to existing `UserResponse`.
- Preserve tier/subscription fields from SkillGate domain data.
- Reject partial identity states that cannot satisfy required contract fields.

## 17.177 Resend Verification Dual Path

- Support two verification modes during migration:
  1) Supabase Auth email path (SMTP/provider-configured)
  2) Existing app-managed verification path via Resend
- Add deterministic fallback behavior and explicit observability events.

## 17.178 Session Semantics Bridge

- Define compatibility policy for access and refresh behavior under Supabase.
- Preserve logout/revocation guarantees and replay resistance.
- Ensure current security tests for session revocation semantics remain enforceable.

## 17.179 OAuth Migration

- Replace demo-only non-dev callback behavior with real provider validation via Supabase.
- Enforce anti-forgery controls (state/nonce and provider proof).
- Keep development-only shortcuts isolated and explicitly blocked in production/staging.

## 17.180 Data Ownership Split

- Supabase-owned: auth identities/credential/session authority.
- SkillGate-owned: subscriptions, teams, scan records, entitlement ledgers/logs, audit artifacts.
- Publish explicit owner matrix with write-path authority and API surface mapping.

## 17.181 Migration Posture (Alembic)

- Keep Alembic ownership for SkillGate domain tables only.
- Remove forward dependencies on local auth-specific tables.
- Add migration guard checks for schema drift and downgrade safety.

## 17.182 RLS + Service Role Model

- Define RLS policies for user-scoped and service-role paths.
- Ensure service-role keys are never client-exposed.
- Add deny-by-default behavior for unscoped data access.

## 17.183 Hosted Env Contract

- Define required and optional env vars for Supabase auth mode.
- Add startup validation for staging/production.
- Define key rotation and secret management expectations.

## 17.184 Compatibility Migration Scripts

- Provide idempotent user/profile/session migration with checkpointing.
- Include dry-run output and integrity summary.
- Include rollback and retry/recovery behavior.

## 17.185 Provider-Agnostic Test Harness

- Refactor test fixtures to run same assertions under provider matrix where applicable.
- Keep `local` suite green while adding `supabase-mocked` mode.
- Snapshot contract output for key auth endpoints.

## 17.186 Security Hardening Pass

- Re-run and preserve defense suite for auth, OAuth, device flow, rate limiting, billing authz.
- Explicitly verify no regression on previously fixed critical items.

## 17.187 Observability Contract

- Emit provider-path metrics and structured logs for auth decisions and failures.
- Redact secrets/tokens from logs and telemetry payloads.
- Add operator triage mapping for top failure classes.

## 17.188 Cutover + Rollback Runbook

- Define staged rollout plan (dev -> staging -> production).
- Define objective rollback triggers and procedures.
- Require smoke checks and post-cutover verification artifacts.

## 17.189 Supabase SQL Functions + RPC Contract

- Define required SQL functions (RPC) for high-value operations where server-side transactionality is required.
- Version all functions with explicit input/output contracts and error semantics.
- Ensure functions are idempotent where retries are expected.

## 17.190 RLS Policy Catalog + Enforcement

- Publish row-level security policy catalog per table (read/write/update/delete rules).
- Enforce deny-by-default and explicit allow policies tied to authenticated subject.
- Add admin/service-role exceptions with audited scope and justification.

## 17.191 Supabase Egress Controls

- Define outbound egress policy for hosted API interactions with Supabase and related dependencies.
- Add timeout budgets, retry/backoff policy, and circuit-breaker expectations.
- Define allowed destination inventory and fail-closed behavior for unexpected endpoints.

## 17.192 Performance and Capacity Plan

- Define p50/p95/p99 latency budgets for auth-critical endpoints.
- Define connection, pool, and concurrency strategy for hosted workload.
- Add benchmark scenarios for login burst, token verification, and profile read paths.

## 17.193 Cache Strategy (Auth + Profile + JWKS)

- Define cache layers (in-memory/Redis) and authoritative source rules.
- Specify TTL, invalidation triggers, and stale-read behavior per object type.
- Ensure cache never bypasses revocation, lockout, or entitlement safety controls.

## 17.194 Frontend React Query Hook Contract

- Define frontend API/query key contract for auth/profile/session states.
- Define mutation behaviors for signup/login/logout/reset/verify flows with deterministic invalidation.
- Define error state mapping and retry policy for auth-sensitive hooks.

## 17.195 Frontend-Backend Auth Contract Tests

- Add cross-surface contract tests for token lifecycle, session state hydration, and logout invalidation.
- Ensure frontend hooks and backend envelopes remain schema-compatible.
- Include migration-mode tests (`local` vs `supabase`) where UI behavior must remain stable.
