# RLS Policy Catalog (Task 17.190)

Version: `v1`
Date: 2026-02-22

## Enforcement Principles

1. Deny by default.
2. Explicit subject-scoped allow policies.
3. Service-role bypass only where justified and audited.
4. No client direct writes for privileged tables.

## Protected Tables

### `users`

- Read: authenticated subject can read own row only.
- Update: authenticated subject can update allowed profile fields for own row.
- Delete: denied for authenticated users.
- Service-role: full access for migration/admin workflows.

### `user_sessions`

- Read: authenticated subject can read own session rows.
- Update: authenticated subject can revoke own sessions only.
- Delete: denied.
- Service-role: full access for backend revocation bridges.

### `oauth_identities`

- Read: authenticated subject can read own linked identities.
- Update: denied to authenticated users.
- Delete: denied to authenticated users.
- Service-role: full access for callback upsert flows.

### `subscriptions`

- Read: authenticated subject can read own subscription rows.
- Write: denied to authenticated users.
- Service-role: allowed (webhook / billing sync).

## Audited Service-Role Exceptions

- `sg_upsert_user_session_v1`: required for auth/session bridge consistency.
- `sg_revoke_user_sessions_v1`: required for logout-all and abuse response.
- `sg_upsert_oauth_identity_v1`: required for OAuth callback mapping.

## SQL Source of Truth

See `skillgate/api/migrations/supabase/002_rls_policies_v1.sql`.
