# Task Registry, DoD, and Delivery Order

## Status Board (Section 17)

| Task | Name | Priority | Status | Owner | Notes |
|---|---|---|---|---|---|
| 17.173 | Auth provider abstraction | P0 | Complete | TBD | `local` + `supabase` provider contract |
| 17.174 | Supabase JWT verifier | P0 | Complete | TBD | JWKS, alg allowlist, claim validation |
| 17.175 | Supabase auth client service | P0 | Complete | TBD | Auth endpoint integration layer |
| 17.176 | Profile mapping parity | P0 | Complete | TBD | Preserve `UserResponse` contract |
| 17.177 | Resend verification dual path | P1 | Complete | TBD | App-managed + Supabase-compatible path |
| 17.178 | Session semantics bridge | P0 | Complete | TBD | Refresh/logout/revocation compatibility |
| 17.179 | OAuth production migration | P0 | Complete | TBD | Replace non-dev demo path |
| 17.180 | Data ownership split | P0 | Complete | TBD | Auth vs domain table ownership matrix |
| 17.181 | Alembic ownership refactor | P0 | Complete | TBD | Domain-only forward migrations |
| 17.182 | RLS and service-role model | P0 | Complete | TBD | Least-privilege policy surface |
| 17.183 | Hosted env contract | P0 | Complete | TBD | Startup fail-closed config validation |
| 17.184 | Compatibility migration scripts | P0 | Complete | TBD | Script + checkpoint + rollback + dry-run summary |
| 17.185 | Provider-agnostic test harness | P0 | Complete | TBD | 65 new tests passing, zero regressions |
| 17.186 | Security hardening pass | P0 | Complete | TBD | Regression suite green for auth/rate-limit/billing/defense |
| 17.187 | Observability and triage contract | P1 | Complete | TBD | Provider metrics + structured redacted failure logs |
| 17.188 | Cutover and rollback runbook | P0 | Complete | TBD | Staged rollout + objective rollback thresholds documented |
| 17.189 | Supabase SQL functions + RPC contract | P1 | Complete | Copilot | Versioned RPC SQL contracts in backend migration path |
| 17.190 | RLS policy catalog and enforcement | P0 | Complete | Copilot | Deny-by-default policy map and service-role exceptions |
| 17.191 | Supabase egress controls | P0 | Complete | Copilot | Allowlist, timeout/retry policy, circuit breaker guardrails |
| 17.192 | Performance and capacity plan | P1 | Complete | Copilot | Auth/profile SLO budgets and benchmark methodology documented |
| 17.193 | Cache strategy (JWKS/profile/auth metadata) | P1 | Complete | Copilot | TTL/invalidation safety rules documented and validated |
| 17.194 | Frontend React Query hook contract | P1 | Complete | Copilot | Query keys, invalidation, and auth mutation contract added |
| 17.195 | Frontend-backend auth contract tests | P1 | Complete | Copilot | Frontend/backend envelope compatibility validated across modes |

## Definition of Done (Per Task)

A task can be marked `Complete` only if all are true:

1. Scope implemented exactly as `SPECS.md`.
2. Required tests pass in CI and local reproduction.
3. Evidence artifacts generated and linked.
4. Backward compatibility impact documented.
5. Rollback/recovery path documented.
6. Security and policy invariants validated.

## Execution Order

1. `17.173`, `17.174`, `17.183`
2. `17.175`, `17.176`, `17.177`, `17.178`, `17.179`
3. `17.180`, `17.181`, `17.182`, `17.184`
4. `17.185`, `17.186`, `17.187`, `17.188`
5. `17.189`, `17.190`, `17.191`, `17.192`, `17.193`, `17.194`, `17.195`

## Per-Task Completion Ledger (Mandatory Before `Complete`)

Legend: `Y` = satisfied and linked, `N` = not yet satisfied.

| Task | Spec match | CI + local tests | Evidence links | Backward compatibility note | Rollback/recovery note | Security/policy invariant validation | Status |
|---|---|---|---|---|---|---|---|
| 17.173 | Y | Y | commit cf83439+ | local mode unchanged | revert commit | fail-closed on invalid provider | Complete |
| 17.174 | Y | Y | 13 tests pass | N/A new module | revert commit | alg allowlist enforced | Complete |
| 17.175 | Y | Y | 13 tests pass | N/A new module | revert commit | key never logged | Complete |
| 17.176 | Y | Y | 4 tests pass | UserResponse contract preserved | revert commit | no PII in logs | Complete |
| 17.177 | Y | Y | signup tests pass | dual-path; local unchanged | revert commit | N/A | Complete |
| 17.178 | Y | Y | logout tests pass | session revocation compatible | revert commit | SHA256 fingerprint only | Complete |
| 17.179 | Y | Y | oauth tests pass | demo codes always rejected | revert commit | PKCE only; demo blocked | Complete |
| 17.180 | Y | Y | migration 0006 | additive column; nullable | revert migration | N/A | Complete |
| 17.181 | Y | Y | migration 0006 | partial unique index | downgrade() provided | N/A | Complete |
| 17.182 | Y | Y | model + migration | supabase_user_id nullable | downgrade() provided | RLS SQL deferred to 17.190 | Complete |
| 17.183 | Y | Y | 19 settings tests | local mode unchanged | revert settings | fail-closed in production | Complete |
| 17.184 | Y | Y | script + tests (2026-02-22) | additive user/session migration, local auth rows preserved | rollback payload + checkpoint resume | fail-closed on conflicts/email mismatch | Complete |
| 17.185 | Y | Y | 65/65 new tests; 1884 existing pass | zero regressions verified | revert commit | N/A | Complete |
| 17.186 | Y | Y | 96-test regression pack green (2026-02-22) | local + supabase paths preserved | rollback via provider switch + prior commits | 16.29–16.35 defense suite remains green | Complete |
| 17.187 | Y | Y | auth_observability module + route instrumentation (2026-02-22) | additive telemetry only | remove module/hooks to rollback | secrets/tokens redacted in context logs | Complete |
| 17.188 | Y | Y | CUTOVER-ROLLBACK-RUNBOOK.md (2026-02-22) | staged rollout keeps local fallback path | explicit rollback command and triggers | secret leakage trigger is fail-fast rollback criterion | Complete |
| 17.189 | Y | Y | Y | Y | Y | Y | Complete |
| 17.190 | Y | Y | Y | Y | Y | Y | Complete |
| 17.191 | Y | Y | Y | Y | Y | Y | Complete |
| 17.192 | Y | Y | Y | Y | Y | Y | Complete |
| 17.193 | Y | Y | Y | Y | Y | Y | Complete |
| 17.194 | Y | Y | Y | Y | Y | Y | Complete |
| 17.195 | Y | Y | Y | Y | Y | Y | Complete |
