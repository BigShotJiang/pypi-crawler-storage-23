# RPC Function Contract Report

Date: 2026-02-22

## Artifacts

- SQL source: `skillgate/api/migrations/supabase/001_rpc_contract_v1.sql`
- Contract doc: `SUPABASE-RPC-CONTRACT.md`

## Validation

- `./venv/bin/pytest -q tests/unit/test_quality/test_supabase_sql_contracts.py`

## Result

- Versioned function names (`*_v1`) present.
- Idempotent clauses (`ON CONFLICT`) present.
- Security definer and function grant revocations present.
