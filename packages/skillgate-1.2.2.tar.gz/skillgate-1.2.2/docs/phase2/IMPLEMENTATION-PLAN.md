# SkillGate — Phase 2 Implementation Plan

**Product:** SkillGate
**Version:** 2.0.0
**Phase:** 2 — Agent Capability Firewall (Runtime + Integrations + Intelligence)
**Status:** Planning — Ready for Sprint 8 execution
**Last Updated:** 2026-02-25
**Classification:** Internal — Confidential
**Prerequisite:** Phase 1 Sprints 1–7.3 complete (1245 unit tests, core engine, policy, CI/CD, attestations, universal language governance, multi-artifact scanning, cross-artifact correlation, per-origin policy, Unicode hardening, performance SLO guards)

---

## Table of Contents

1. [Plan Overview](#1-plan-overview)
2. [Sprint 8: Runtime Enforcement Core (Days 71–88)](#2-sprint-8-runtime-enforcement-core-days-7188)
3. [Sprint 9: Session License Token + Auth Architecture (Days 89–101)](#3-sprint-9-session-license-token--auth-architecture-days-89101)
4. [Sprint 10: MCP Gateway — Claude Code Integration (Days 102–120)](#4-sprint-10-mcp-gateway--claude-code-integration-days-102120)
4.5. [Sprint 10.5: Claude Code Ecosystem Depth — Hooks, Instruction Files, Sub-agents + Plugin Registry (Days 117–132)](#45-sprint-105-claude-code-ecosystem-depth--hooks-instruction-files-sub-agents--plugin-registry-days-117132)
4.6. [Sprint 10.6: Claude Code Plugin Delivery — skillgate-agents (Days 130–140)](#46-sprint-106-claude-code-plugin-delivery--skillgate-agents-days-130140)
5. [Sprint 11: Codex CLI Bridge + AGENTS.md Governance (Days 141–153)](#5-sprint-11-codex-cli-bridge-days-141153)
6. [Sprint 12: VS Code Extension — Shift-Left Moat (Days 146–162)](#6-sprint-12-vs-code-extension--shift-left-moat-days-146162)
7. [Sprint 13: Observability, Telemetry + SIEM Exports (Days 163–175)](#7-sprint-13-observability-telemetry--siem-exports-days-163175)
8. [Sprint 14: Agent Framework SDKs — Embedded Middleware Moat (Days 176–192)](#8-sprint-14-agent-framework-sdks--embedded-middleware-moat-days-176192)
9. [Sprint 15: Intelligence + SaaS Control Plane (Days 193–216)](#9-sprint-15-intelligence--saas-control-plane-days-193216)
10. [Definition of Done](#10-definition-of-done)
11. [Revenue Milestones](#11-revenue-milestones)
12. [Risk Mitigation Timeline](#12-risk-mitigation-timeline)
13. [Addendum A: Integration Registry + Community Policy Packs](#13-addendum-a-integration-registry--community-policy-packs)
14. [Addendum B: Enterprise Compliance Layer (NIST / EU AI Act Mapping)](#14-addendum-b-enterprise-compliance-layer-nist--eu-ai-act-mapping)
15. [Addendum C: Open-Core Split + Ecosystem Governance](#15-addendum-c-open-core-split--ecosystem-governance)
16. [Addendum D: Claude Code + Codex Community Dominance Strategy](#16-addendum-d-claude-code--codex-community-dominance-strategy)

---

## 1. Plan Overview

### 1.1 Phase 2 Mandate

Phase 1 produced a production-grade static analysis + policy enforcement CLI. Phase 2 transforms SkillGate into the **Agent Capability Firewall** — a runtime-embedded, ecosystem-integrated control plane that governs what AI agents *do* (tool invocations), not only what they *say*.

**Phase 2 is the moat phase.** Every sprint produces a component that, once adopted, creates removal friction:
- **Runtime enforcement library/sidecar** → embedded in production services
- **MCP Gateway** → becomes a required hop for Claude Code tool execution
- **Codex CLI Bridge** → becomes required wrapper for CI pipelines
- **VS Code Extension** → lives in developer workflow
- **Agent Framework SDKs** → wrapped into tool definitions (removing = refactoring)
- **SaaS Control Plane** → stores org-wide audit trails and policies (switching = data migration)

### 1.2 Timeline Summary

```
Sprint 8   (Days  71– 88)  ██████████░░░░░░░░░░░░░░░░░░░░░░  Runtime Enforcement Core
Sprint 9   (Days  89–101)  ░░░░░░░░░░░░████████░░░░░░░░░░░░  SLT + Auth Architecture
Sprint 10  (Days 102–120)  ░░░░░░░░░░░░░░░░░░░█████████░░░░  MCP Gateway (Claude Code)
Sprint 11  (Days 121–133)  ░░░░░░░░░░░░░░░░░░░░░░░░░░██████  Codex CLI Bridge
Sprint 12  (Days 134–148)  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  VS Code Extension
Sprint 13  (Days 149–161)  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Observability + SIEM
Sprint 14  (Days 162–178)  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Agent Framework SDKs
Sprint 15  (Days 179–202)  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  Intelligence + SaaS CP
```

### 1.3 Guiding Constraints

- **No feature without tests.** Every task includes its test implementation. Coverage ≥90% on all new core modules.
- **No merge without green CI.** `ruff check` + `mypy --strict` + `pytest` must pass.
- **Data plane must work offline.** Enforcement must never block because your SaaS is down.
- **Fail-closed defaults everywhere.** When in doubt, DENY and surface a clear remediation code.
- **Performance is not optional.** P95 ≤20ms sidecar latency; P99 ≤50ms worst-case. Latency regressions are bugs.
- **Two deep integrations over ten shallow.** MCP + Codex are mandatory Phase 2 moats; agent frameworks come in Sprint 14 but only after the core is stable.
- **No model execution.** SkillGate never runs agent code; analysis is static or intercept-based.

### 1.4 Strategic Positioning Lock

- **Category statement (locked):** SkillGate is the control plane for AI agent execution — the capability firewall, not a scanner clone.
- **Phase 2 market statement:** "The default runtime policy layer for Claude/MCP, Codex, and agent frameworks."
- **Moat priority order:** Agent Capability Firewall core → Claude/MCP embed → Codex/CLI embed → VS Code shift-left → Agent Framework SDKs → Telemetry flywheel → SaaS control plane.
- **Enterprise rule:** Never position as "Team plus add-ons." Enterprise = governance infrastructure (runtime, lineage, trust, compliance, API control).

### 1.5 Phase 2 Decision Codes (New in Phase 2)

All existing Phase 1 codes (`SG_ALLOW`, `SG_DENY_*`, etc.) are preserved. Phase 2 adds:

| Code | Meaning |
|---|---|
| `SG_DENY_CAPABILITY_NOT_ALLOWED` | Tool capability not in allowlist for this trust tier |
| `SG_DENY_BUDGET_EXCEEDED` | Token bucket budget exhausted for capability |
| `SG_DENY_POLICY_VIOLATION_PATTERN` | Command/path/domain matches deny pattern |
| `SG_APPROVAL_REQUIRED` | Capability requires explicit approval before execution |
| `SG_FAIL_CIRCUIT_OPEN` | External dependency failing; enforcement halted safely |
| `SG_FAIL_POLICY_UNAVAILABLE` | No valid cached policy snapshot available |
| `SG_ALLOW_DEGRADED_AUDIT_ASYNC` | Allowed in degraded mode; audit event buffered locally |
| `SG_FAIL_LICENSE_EXPIRED_LIMITED_MODE` | SLT expired; limited mode enforced (reads allowed, writes denied) |
| `SG_FAIL_LICENSE_MISSING` | No valid SLT; enforcement blocked until auth |
| `SG_DENY_UNTRUSTED_TOOL_PROVIDER` | Tool provider not in approved registry |
| `SG_DENY_CONFIG_POISONING_DETECTED` | Repo-local config attempts to load untrusted tool provider |
| `SG_DENY_TOOL_DESCRIPTION_INJECTION` | MCP tool name/description/parameter contains prompt injection pattern |
| `SG_DENY_HOOK_COMMAND_UNSAFE` | Claude Code PreToolUse/PostToolUse hook command violates capability policy |
| `SG_DENY_INSTRUCTION_FILE_INJECTION` | CLAUDE.md/AGENTS.md/memory file contains prompt injection or capability override |
| `SG_DENY_SLASH_COMMAND_INJECTION` | Slash command definition contains injection or unsafe tool invocation pattern |
| `SG_DENY_SETTINGS_PERMISSION_EXPANSION` | Settings file expands allowedTools/permissions without approved policy change |
| `SG_DENY_SUBAGENT_BUDGET_EXCEEDED` | Sub-agent invocation would exceed budget inherited from parent agent |
| `SG_DENY_PLUGIN_NOT_ATTESTED` | Claude Code plugin/skill has no valid SkillGate attestation |

---

## 2. Sprint 8: Runtime Enforcement Core (Days 71–88)

**Goal:** `skillgate-enforcer` library and `skillgate-enforcer-sidecar` HTTP API are production-grade. Capability budgets, deterministic decisions, circuit breakers, and signed decision records all work. P95 ≤20ms under 10k/min load.

### Day 71–74: Canonical Data Model + Policy Schema v2

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 18.1 | `ToolInvocation` Pydantic model: `invocation_id`, `timestamp`, `actor` (type/id/workspace_id/session_id), `agent` (name/version/framework/trust_tier), `tool` (name/provider/capabilities/risk_class), `request` (params/resource_refs), `context` (repo/environment/data_classification/network_zone) | `tests/unit/test_runtime/test_tool_invocation.py` — model validation, serialization round-trip, unknown fields rejected | Model validates all fields; canonical JSON is stable |
| 18.2 | `PolicyV2` Pydantic model: trust tiers, capability budgets (per-minute token bucket configs), allow/deny rules with glob patterns, approval requirements with CEL-lite conditions, exceptions with expiry | `tests/unit/test_runtime/test_policy_v2.py` — valid/invalid schemas, budget ranges, expiry validation | Schema validates; v1/v2 policy coexists (v1 not broken) |
| 18.3 | `DecisionRecord` model: `invocation_id`, `decision`, `decision_code`, `reason_codes[]`, `policy_version`, `budgets` (remaining/limit per capability), `evidence` (hash/signature/key_id), `degraded`, `entitlement_version`, `license_mode` | `tests/unit/test_runtime/test_decision_record.py` — all decision codes, serialization, evidence fields | Model covers all Phase 2 decision codes |
| 18.4 | Capability enum registry: `fs.read`, `fs.write`, `net.outbound`, `shell.exec`, `git.diff`, `git.write`, `secrets.read`, `process.spawn`, `config.load` with risk_class mapping (low/med/high/critical) | `tests/unit/test_runtime/test_capabilities.py` — all capabilities have risk class, unknown capabilities classified `critical` | All 9 capabilities registered; unknown → critical |
| 18.5 | Policy schema v2 loader: YAML parse, version detection, field validation, strict unknown-field rejection | `tests/unit/test_runtime/test_policy_loader.py` — valid v2 YAML, invalid fields, missing required fields, version mismatch | Loader rejects invalid; loads valid in <10ms |

**Ship gate:** `ToolInvocation`, `PolicyV2`, `DecisionRecord` models instantiate, serialize, and deserialize correctly across all test vectors.

---

### Day 75–78: Enforcement Pipeline + Token Buckets

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 19.1 | `EnforcementPipeline` class: 7-stage pipeline (Normalize → Enrich → Authorize → Evaluate → Decide → Record → Emit) with stage hook points | `tests/unit/test_runtime/test_pipeline.py` — each stage processes correctly, stage failure short-circuits correctly, pipeline is deterministic | All stages execute in correct order; same input = same output |
| 19.2 | Normalize stage: canonicalize tool metadata, infer missing capabilities from tool name/provider pattern, path normalization (anti-traversal), strip null/empty fields | `tests/unit/test_runtime/test_normalize.py` — path traversal inputs rejected, capability inference from known providers, null fields stripped | Traversal attacks normalized out; no `../` survives |
| 19.3 | Enrich stage: repo path normalization (symlink resolution with safe abort), command parsing classification for shell/git (banned patterns pre-scan), data classification inference from path patterns | `tests/unit/test_runtime/test_enrich.py` — symlink escape tests, shell command parsing (rm/curl-pipe/powershell-enc/dd), data classification | Symlink escapes abort with `SG_DENY_POLICY_VIOLATION_PATTERN`; shell patterns classified correctly |
| 19.4 | Authorize stage: actor/workspace RBAC lookup (stub for now — resolved from policy snapshot), tool provider trust verification (allowlist check) | `tests/unit/test_runtime/test_authorize.py` — known/unknown workspaces, trusted/untrusted providers, RBAC deny matrix | Untrusted provider → `SG_DENY_UNTRUSTED_TOOL_PROVIDER` |
| 19.5 | Evaluate stage: allow/deny rule evaluation (deterministic glob pattern matching), capability budget check (token bucket read), approval requirement lookup | `tests/unit/test_runtime/test_evaluate.py` — allow rules pass, deny rules block, budget exhaustion blocks, approval triggers | Rule evaluation is deterministic; same policy + same input = same output across 1000 runs |
| 19.6 | Token bucket implementation: per-(workspace, agent, capability) buckets; in-memory default with pluggable backend; configurable refill rate and burst; atomic decrement | `tests/unit/test_runtime/test_token_bucket.py` — single decrement, burst up to limit, refill after window, concurrent decrements (thread-safe), burst over limit denied | Buckets are thread-safe; no race conditions under concurrent load |
| 19.7 | Record stage: sync evidence generation (SHA-256 over canonical JSON, Ed25519 sign with local key); async mode (buffers to encrypted spool file, flushes in background); degraded mode tagging | `tests/unit/test_runtime/test_record.py` — sync sign+verify round-trip, async buffer+flush, degraded mode tag | Sync evidence ≤2ms added latency; async ≤0.1ms |
| 19.8 | Emit stage: async telemetry event emission (fire-and-forget; no blocking); pluggable emitter interface (console/webhook/OTEL); structured event schema | `tests/unit/test_runtime/test_emit.py` — emitter called async, emitter failure does not fail enforcement decision, event schema matches spec | Emitter failure never blocks a decision |
| 19.9 | Shell enforcement specifics: command parser (argv array split, never shell-string), banned pattern registry (`rm -rf`, `curl \| sh`, `powershell -enc`, `dd if=`, `mkfs`), `--config` git flag denial when policy disallows, `command_risk_score` mapper | `tests/unit/test_runtime/test_shell_enforcement.py` — all banned patterns, argument injection attempts, git --config bypass attempts, argv injection via env vars | 15+ shell attack patterns blocked; argument injection impossible via enforcer |
| 19.10 | Network enforcement specifics: DNS allowlist/denylist evaluation, IP range block (RFC1918 configurable), port/protocol/destination classification (internal/external), rate limit per agent+workspace+tool | `tests/unit/test_runtime/test_network_enforcement.py` — DNS allow/deny, RFC1918 block/allow, port blocking, per-agent rate limits | Network enforcement matches policy; RFC1918 is configurable |

**Ship gate:** Full enforcement pipeline processes a `ToolInvocation` and returns a `DecisionRecord` deterministically with correct decision codes. Shell, network, filesystem enforcement all produce correct denials on adversarial inputs.

---

### Day 79–82: Sidecar HTTP API + Circuit Breakers

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 20.1 | `skillgate-enforcer-sidecar`: lightweight HTTP server (FastAPI or httpx-based); endpoints: `POST /v1/decide`, `POST /v1/audit` (async collector), `GET /v1/health`, `GET /v1/policy/{name}`, `GET /v1/entitlements`, `POST /v1/refresh-license` | `tests/integration/test_sidecar_api.py` — all endpoints, schema validation, auth header required, malformed inputs rejected | All endpoints return correct schema; startup <200ms |
| 20.2 | `POST /v1/decide` implementation: deserializes `ToolInvocation`, runs enforcement pipeline, returns `DecisionRecord`; request timeout 100ms (configurable); rejects requests >64KB | `tests/integration/test_sidecar_decide.py` — valid invocations, malformed JSON, oversized requests, concurrent requests (10 simultaneous) | P95 ≤20ms under 10k/min; oversized request → 413 |
| 20.3 | Policy snapshot cache: in-memory store with TTL (default 24h); versioned snapshots; atomic swap on update; `GET /v1/policy/{name}` returns cached version + metadata | `tests/unit/test_runtime/test_policy_cache.py` — cache hit/miss, TTL expiry, concurrent reads safe, atomic update | Cache hits ≤1ms; TTL expiry transitions to degraded mode |
| 20.4 | Circuit breaker implementation: CLOSED/OPEN/HALF_OPEN state machine; per-dependency (control plane, audit store); exponential backoff with jitter on open; configurable failure threshold; stores `last_successful_contact_at` | `tests/unit/test_runtime/test_circuit_breaker.py` — state transitions, backoff schedule, half-open probe, failure accumulation, jitter | Backoff never spams dependency; half-open probe on correct schedule |
| 20.5 | Degraded mode behavior: when control plane unreachable → use cached policy snapshot; when audit store unavailable → buffer to local spool (encrypted, AES-256-GCM); when SLT expired → limited mode (configurable: balanced or strict); decision code reflects mode | `tests/unit/test_runtime/test_degraded_modes.py` — all 3 degraded scenarios, correct decision codes, spool created and encrypted, limited mode capability restrictions | All degraded modes produce correct codes; no cleartext secrets in spool |
| 20.6 | Performance test harness: load test fixture that sends N ToolInvocations/min to sidecar and measures P50/P95/P99 latency; gates in CI at P95 ≤20ms, P99 ≤50ms under 10k/min | `tests/perf/test_sidecar_latency.py` — 10k/min steady, 50k/min burst (30s), regression gate (fail if >20% worse than baseline) | P95 ≤20ms at 10k/min; CI fails on regression |
| 20.7 | Filesystem enforcement specifics: path canonicalization (resolve symlinks before allow/deny check), chroot-like virtual root (path allowlist + denylist), forbidden path patterns (`~/.ssh/**`, `/etc/**`, `/`, `**/.env`), write-byte budget per minute | `tests/unit/test_runtime/test_fs_enforcement.py` — symlink escapes (5 patterns), forbidden paths, byte budget exhaustion, path traversal via encoded characters | All 5 symlink escape patterns blocked; forbidden paths denied |

**Sprint 8 Ship Gate:**
- [ ] `ToolInvocation` + `PolicyV2` + `DecisionRecord` models complete and tested
- [ ] 7-stage enforcement pipeline deterministic and tested with 100+ vectors
- [ ] Token bucket per-(workspace, agent, capability) thread-safe and correct
- [ ] Shell/network/filesystem enforcement blocks adversarial inputs
- [ ] Sidecar HTTP API all 6 endpoints return correct schema
- [ ] `POST /v1/decide` P95 ≤20ms under 10k/min in CI perf test
- [ ] Circuit breaker transitions CLOSED→OPEN→HALF_OPEN correctly
- [ ] All degraded modes produce correct decision codes
- [ ] Local spool is encrypted (AES-256-GCM)
- [ ] All unit + integration + perf tests pass; coverage ≥90% on `skillgate/runtime/`
- [ ] `ruff` + `mypy --strict` clean

**At this point, SkillGate enforces runtime capability boundaries with production-grade reliability.**

---

## 3. Sprint 9: Session License Token + Auth Architecture (Days 89–101)

**Goal:** Replace hard-per-command API key validation with a cached Session License Token (SLT) model. Enforcement continues offline. Anonymous trial tokens enable zero-friction evaluation. Rate limits are enforced client-side from SLT entitlements.

### Day 89–92: SLT Specification + Backend Exchange

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 21.1 | SLT specification: JWT (RS256) with claims: `sub` (org_id), `jti` (token_id), `iat`/`exp` (12–24h default), `tier` (free/pro/team/enterprise), `entitlements` (capability budgets per tier), `rate_limits` (client-side enforcement policy), `anonymous` (bool), `device_id` | `tests/unit/test_auth/test_slt_spec.py` — valid/invalid/expired tokens, claim extraction, alg allowlist (RS256 only), none-alg rejected | None-alg attack rejected; expired token rejected; all claims extractable |
| 21.2 | Backend `/auth/exchange` endpoint: accepts `{api_key, device_id, session_info}`; validates key format + tier lookup; issues signed SLT; returns `{slt, entitlements, rate_limit_policy, expires_at}` | `tests/unit/test_auth/test_exchange_endpoint.py` — valid key → SLT issued, invalid key → 401, missing key → 400, malformed → 400, free-tier key → free entitlements | SLT is issued in <200ms; invalid keys never get a token |
| 21.3 | Anonymous trial SLT: `POST /auth/anonymous` (no API key required); issues 24h SLT with tight limits (5 scans/day, low capability budgets); converts to full SLT on signup; stored with `anonymous: true` claim | `tests/unit/test_auth/test_anonymous_slt.py` — anonymous token issued, limits enforced, conversion to full SLT works, no second anonymous token within 24h per device | Anonymous users can trial with zero friction; cannot bypass limits |
| 21.4 | SLT signing key infrastructure: RSA-2048 key pair; key rotation support (new key issued; old key verifiable during grace period); JWKS endpoint (`GET /auth/.well-known/jwks.json`) for client verification | `tests/unit/test_auth/test_slt_keys.py` — sign+verify, rotation (both keys valid in grace window), JWKS endpoint format, old key rejected after rotation + grace expiry | Key rotation does not invalidate active SLTs during grace window |

**Ship gate:** Backend issues valid SLTs; invalid/expired/anonymous-limit-exceeded requests all rejected with correct error codes.

---

### Day 93–96: CLI Auth Command + SLT Cache

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 22.1 | `skillgate auth` CLI command: calls `/auth/exchange` with API key from env/config; stores SLT in OS keychain (macOS Security, Windows Credential Manager, Linux Secret Service via secretstorage); falls back to encrypted file (`~/.skillgate/slt.enc`) | `tests/unit/test_cli/test_auth_command.py` — keychain write/read, encrypted file fallback, key not stored in plaintext, `--api-key` flag works | API key never stored; SLT stored only in keychain or encrypted file |
| 22.2 | SLT renewal logic: background check on startup; if SLT expires in <4h, silently renew in background thread; if renewal fails (network unavailable), continue with current SLT until actual expiry; exponential backoff on renewal failures; stores `last_renewal_attempt_at` | `tests/unit/test_cli/test_slt_renewal.py` — renewal triggered at <4h, renewal failure does not block enforcement, backoff schedule correct, jitter applied | Renewal never blocks the CLI; never spams the auth endpoint |
| 22.3 | License-related error messages: standardized error model `{code, message, remediation}` for all SLT failure paths; codes: `AUTH_KEY_MISSING`, `AUTH_KEY_INVALID`, `AUTH_SLT_EXPIRED`, `AUTH_SLT_EXPIRED_LIMITED`, `AUTH_SERVICE_UNAVAILABLE`; all errors include exact CLI remediation command | `tests/unit/test_cli/test_auth_errors.py` — all 5 error codes, remediation string includes correct command, no stack traces in user-facing output | Users always see a clear remediation step; no raw exceptions leaked |
| 22.4 | Offline grace modes: **Mode A** (online — normal), **Mode B** (offline — use cached SLT, buffer telemetry, pause policy updates), **Mode C** (SLT expired + offline — balanced: allow read-only/low-risk for 24–72h grace window; block shell/net/fs-write; return `SG_FAIL_LICENSE_EXPIRED_LIMITED_MODE`); configurable `offline_grace_policy` (balanced or strict) | `tests/unit/test_cli/test_offline_modes.py` — mode transition A→B→C, grace window enforcement (low-risk allowed, high-risk denied in Mode C), strict mode denies all in Mode C | Grace modes documented and enforced; high-risk capabilities always blocked in expired mode |
| 22.5 | Client-side rate limiting from SLT: enforcement runtime reads `rate_limits` claim from SLT to configure local token buckets (per-minute budgets for shell/fs/net); no server round-trip required; client quota checked first, then server | `tests/unit/test_auth/test_slt_rate_limits.py` — client limits enforced without network, limits correctly loaded from SLT claim, limits more restrictive than server limits | Client-side limits work fully offline; server limits cannot be bypassed by spoofed SLT (server re-validates) |

**Ship gate:** `skillgate auth` completes login, stores SLT securely, renews silently, operates correctly in all three offline modes.

---

### Day 97–101: Sidecar SLT Verification + Entitlement API

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 23.1 | Sidecar SLT verification middleware: validates SLT on every request (`Authorization: Bearer <slt>`); verifies signature, exp, aud, iss, alg (RS256 only, never none); extracts entitlements; caches JWKS with TTL; rejects requests without valid SLT (unless `local_mode: true` configured) | `tests/unit/test_runtime/test_slt_middleware.py` — expired SLT rejected, none-alg rejected, JWKS cache hit/miss, missing token rejected, local_mode bypass | None-alg and expired tokens never pass; JWKS cache reduces auth overhead to <0.5ms per request |
| 23.2 | `GET /v1/entitlements` endpoint: returns current entitlement view from cached SLT (tier, capability budgets, feature flags, license_mode); no network call | `tests/integration/test_entitlements_api.py` — correct tier reflected, budget remaining correct, feature flags mapped | Response reflects SLT state accurately; no false entitlements |
| 23.3 | `POST /v1/refresh-license` endpoint: triggers background SLT renewal attempt; returns `{status: "renewal_requested" \| "already_valid" \| "renewal_failed", next_attempt_at}`; does not block caller | `tests/integration/test_refresh_license.py` — renewal triggered, already-valid returns immediately, failure path responds correctly | Caller never blocked; background renewal decoupled from response |
| 23.4 | VS Code extension SLT flow: extension communicates with local `skillgate` binary only; binary manages SLT; extension shows clear UI state (licensed/limited/needs-login) based on entitlement API response; no secrets stored in extension | `tests/unit/test_vscode/test_slt_integration.py` — extension reads mode from binary, mode changes reflected in UI state, no API key in extension storage | Extension never stores API key; license state visible to user |

**Sprint 9 Ship Gate:**
- [ ] SLT issued correctly by backend; none-alg + expired + invalid key all rejected
- [ ] Anonymous trial SLT works with correct limits
- [ ] CLI `skillgate auth` stores SLT in OS keychain (not plaintext)
- [ ] All three offline modes (A/B/C) transition correctly and enforce correct capabilities
- [ ] Client-side rate limits loaded from SLT; work fully offline
- [ ] Sidecar verifies SLT on every request; JWKS cached
- [ ] `GET /v1/entitlements` returns accurate tier/budget view
- [ ] Extension never stores API key
- [ ] All auth unit + integration tests pass; coverage ≥90% on `skillgate/auth/`
- [ ] `ruff` + `mypy --strict` clean

**At this point, SkillGate operates securely offline with cached entitlements and survives service interruptions gracefully.**

---

## 4. Sprint 10: MCP Gateway — Claude Code Integration (Days 102–120)

**Goal:** `skillgate-mcp-gateway` sits between Claude Code and MCP servers. Every tool call is intercepted, policy-evaluated, and signed. Gateway adds ≤25ms P95. AI-BOM is maintained for each MCP server/tool. This is the primary strategic moat.

### Day 102–106: MCP Gateway Core + Transport

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 24.1 | `skillgate-mcp-gateway`: standalone service (Go or Python) that proxies between Claude Code (client) and MCP servers; supports HTTP transport first; startup with config file specifying upstream MCP server addresses and enforcement policy | `tests/integration/test_mcp_gateway/test_startup.py` — gateway starts, config loads, upstream discovered, health endpoint | Gateway starts in <500ms; health endpoint returns OK within 1s |
| 24.2 | Tool schema discovery: gateway connects to each configured MCP server, fetches tool schema (names, descriptions, parameter schemas); maintains local registry; exposes filtered tool list to Claude Code (only tools passing policy allowlist) | `tests/integration/test_mcp_gateway/test_tool_discovery.py` — fake MCP server, schemas fetched, denied tools not exposed, schema caching | Denied tools invisible to Claude Code; schema fetch <100ms per server |
| 24.3 | MCP tool call intercept: every `tool.call` from Claude Code intercepted; converted to `ToolInvocation` canonical model; enforcement pipeline invoked; if `ALLOW` → forward to upstream MCP server; if `DENY` → return error to Claude Code with decision_code; if `REQUIRE_APPROVAL` → return pending state | `tests/integration/test_mcp_gateway/test_intercept.py` — allow path, deny path, approval path, MCP server down (fail gracefully), concurrent calls (10) | Intercept overhead P95 ≤25ms; MCP server errors return structured errors to client |
| 24.4 | Response capture: after upstream MCP server responds, gateway captures response metadata (tool name, success/failure, response size, duration); enriches audit record; emits signed record to audit spool | `tests/integration/test_mcp_gateway/test_response_capture.py` — metadata captured, audit record enriched, response passed to client unchanged | Response metadata captured; client never sees modified response content |
| 24.5 | Stdio transport support: gateway also supports stdio MCP transport (pipe-based); required for local MCP servers started by Claude Code; stdio <→ HTTP bridge internal | `tests/integration/test_mcp_gateway/test_stdio.py` — stdio mode starts, tool calls intercepted, responses returned via stdio | Stdio transport works end-to-end; no buffering issues |

**Ship gate:** Gateway intercepts tool calls from Claude Code, evaluates policy, forwards or blocks, and records signed audit events. P95 ≤25ms on local hardware.

---

### Day 107–111: AI-BOM + Tool Registry Allowlisting

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 25.1 | AI-BOM (AI Bill of Materials) model: per-MCP-server inventory record with `name`, `version`, `publisher`, `checksum` (content hash of server binary/code), `permissions_requested` (capabilities), `verified_at`, `trust_level` (unverified/community/verified/official) | `tests/unit/test_mcp_gateway/test_aibom.py` — model validation, checksum computation, trust level assignment | AI-BOM model complete; checksum is deterministic and reproducible |
| 25.2 | Tool registry: persisted allowlist mapping `(tool_name, provider_id)` to AI-BOM entry + capability permissions; policy evaluation checks registry first; CI rule: if permissions increase → require approval gate | `tests/unit/test_mcp_gateway/test_tool_registry.py` — allowed tool passes, unknown tool blocks, permission increase detected, approval gate triggered | Unknown tools blocked by default; permission increase requires approval |
| 25.3 | Manifest validation: MCP server manifests (their config files) validated against schema; `auto-loading from untrusted repo-local configs` denied by default; new tool providers require explicit `skillgate mcp allow <server>` command | `tests/unit/test_mcp_gateway/test_manifest_validation.py` — valid manifest passes, invalid manifest rejected, repo-local auto-load blocked, explicit allow works | Repo-local auto-load fails closed; explicit allow command creates registry entry |
| 25.4 | Permission drift detection: compares current MCP server's declared permissions against registered AI-BOM; if new capabilities added → log `SG_DENY_UNTRUSTED_TOOL_PROVIDER`, emit alert, require re-approval; backward-compatible (removed permissions allowed silently) | `tests/unit/test_mcp_gateway/test_permission_drift.py` — no drift passes, added capability detected + blocked, removed capability allowed, multi-capability drift | Permission additions always require re-approval; no silent privilege escalation |
| 25.5 | `skillgate mcp` CLI subcommands: `mcp list` (show all registered MCP servers + AI-BOM), `mcp allow <server>` (add to registry), `mcp deny <server>` (block), `mcp inspect <server>` (show AI-BOM + permissions), `mcp audit` (show recent decisions for MCP tools) | `tests/unit/test_cli/test_mcp_commands.py` — all 5 subcommands work, output formats correct | All MCP management commands functional |

**Ship gate:** AI-BOM populated for all configured MCP servers; unknown/drifted tools blocked; `skillgate mcp` commands functional.

---

### Day 112–116: Security Hardening + Claude Code Integration

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 26.1 | MCP server sandboxing: untrusted servers launched in separate process with constrained OS permissions (seccomp profile on Linux, restricted entitlements on macOS); communication via controlled IPC only; no direct filesystem access beyond declared paths | `tests/integration/test_mcp_gateway/test_sandbox.py` — sandboxed server cannot write outside declared path, seccomp violation returns EPERM, communication works correctly | Sandboxed MCP server cannot escalate outside declared boundaries |
| 26.2 | Gateway mTLS (local): local certificate authority for localhost communication between Claude Code → gateway → MCP servers; certificates issued per session; prevents localhost MITM | `tests/integration/test_mcp_gateway/test_mtls.py` — mTLS connection succeeds with cert, fails without, cert per session | No unencrypted localhost traffic for MCP decisions |
| 26.3 | `filesystem + git server combined escalation` defense: detect and block combined capability pattern (a single tool call attempting fs.write + git.write + shell.exec simultaneously); block by default; configurable exception with approval | `tests/integration/test_mcp_gateway/test_combo_escalation.py` — single-capability allowed, multi-capability combo blocked, exception + approval works | Escalation combos blocked without approval |
| 26.4 | Claude Code integration guide: `claude_code_skillgate_integration.md` — step-by-step for adding gateway to Claude Code MCP config; example config snippet; verification steps (`skillgate mcp verify`); troubleshooting section | Documentation review + `e2e/test_claude_code_integration.py` (simulated flow) | Integration guide complete; verification command works |
| 26.5 | "Secure Claude Agents" blueprint repo: reference repository template with: gateway config, policy file, AI-BOM manifest template, GitHub Action for policy check, README with security guarantees; published as `skillgate-io/secure-claude-agents` | Documentation review + template validation tests | Blueprint repo published and functional |
| 26.6 | Gateway performance validation: end-to-end test with fake Claude Code → gateway → fake MCP server; measure gateway-added overhead only (subtract upstream latency); assert P95 ≤25ms added overhead; test at 1k/min, 5k/min, 10k/min | `tests/perf/test_mcp_gateway_latency.py` — three load levels, overhead isolation, regression gate | P95 ≤25ms gateway overhead at 10k/min; CI regression gate active |
| 26.7 | **Tool description poisoning detection:** before exposing any MCP tool to Claude Code, scan tool `name`, `description`, `inputSchema` property descriptions for prompt injection patterns (jailbreak templates, `ignore previous instructions`, `you are now`, capability override phrases, data exfiltration triggers); block tool entirely on detection; return `SG_DENY_TOOL_DESCRIPTION_INJECTION` | `tests/unit/test_mcp_gateway/test_tool_poisoning.py` — 20+ injection pattern variants in name/description/params, clean descriptions pass, partial match blocked, case-insensitive scan | No poisoned tool description ever reaches Claude Code; 0 false positives on legitimate tool descriptions from known MCP servers |
| 26.8 | **Claude Code `settings.json` governance:** monitor `.claude/settings.json` (project) and `~/.claude/settings.json` (global) for `allowedTools` additions and `permissions` expansions; compare against approved baseline stored in `.skillgate/settings-baseline.json`; any deviation → `SG_DENY_SETTINGS_PERMISSION_EXPANSION` + prompt for approval; CI mode: fail closed immediately | `tests/unit/test_mcp_gateway/test_settings_governance.py` — new tool in allowedTools blocked, permission expansion blocked, removal allowed silently, baseline creation on first run, CI fail-closed | Settings drift detection runs on every SkillGate session start; no silent tool additions |
| 26.9 | **Plugin/skill attestation enforcement:** when Claude Code activates a plugin or skill, verify it carries a valid SkillGate Ed25519 attestation (from Phase 1 `skillgate sign`); unattested plugins → `SG_DENY_PLUGIN_NOT_ATTESTED`; configurable `plugin_policy: strict \| warn \| off`; strict is default in CI mode; `skillgate mcp attest <plugin>` signs a plugin and registers attestation | `tests/unit/test_mcp_gateway/test_plugin_attestation.py` — attested plugin allowed, unattested blocked in strict mode, warn mode logs only, off disables, CI always strict | Unattested plugins blocked in CI; developers can attest plugins with `skillgate mcp attest` |

**Sprint 10 Ship Gate:**
- [ ] Gateway intercepts Claude Code tool calls over HTTP + stdio transports
- [ ] AI-BOM populated; permission drift detected and blocked
- [ ] Unknown and repo-local auto-loading MCP servers blocked by default
- [ ] Sandboxed untrusted servers cannot escalate outside declared paths
- [ ] Combined capability escalation combos blocked
- [ ] **Tool description poisoning: 20+ injection patterns blocked; 0 false positives on legitimate tools**
- [ ] **Settings drift detection fires on new `allowedTools` or `permissions` expansion**
- [ ] **Plugin attestation enforcement active in CI mode**
- [ ] P95 ≤25ms gateway-added overhead at 10k/min (CI perf gate)
- [ ] `skillgate mcp` commands all functional
- [ ] Integration guide + "Secure Claude Agents" blueprint repo published
- [ ] All tests pass; coverage ≥90% on `skillgate/mcp_gateway/`
- [ ] `ruff` + `mypy --strict` clean

**At this point, SkillGate is the default policy layer between Claude Code and any MCP server — including protection against tool poisoning, settings drift, and unatttested plugins.**

---

## 4.5. Sprint 10.5: Claude Code Ecosystem Depth — Hooks, Instruction Files, Sub-agents + Plugin Registry (Days 117–132)

**Goal:** Govern every artifact that shapes Claude Code's runtime behaviour beyond MCP tool calls: execution hooks, instruction files, slash commands, memory, sub-agent chains, and the Claude plugin registry. This sprint closes the gap between "gateway for tool calls" and "complete control plane for Claude Code" — the most defensible positioning in the Anthropic ecosystem.

**Why this sprint exists:** Claude Code is not just MCP. Attackers and supply-chain threats target hooks (shell commands run before/after every tool call), CLAUDE.md files (injected directly into the model context), slash commands (markdown files turned into prompts), memory files (persisted context that shapes future sessions), and sub-agent spawning (Task tool that creates child agents). None of these surfaces are governed by the MCP gateway alone. Every one of them is a real attack vector with documented incidents.

### Day 117–120: Claude Code Hooks Governance

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 43.1 | **PreToolUse/PostToolUse hook scanner:** scan every `.claude/hooks/*.json` and `.claude/hooks/*.sh` file against capability policy; hooks are shell commands that execute before/after every tool call — treat them as `shell.exec` capability requests; apply same enforcement as direct shell execution; classify risk (network call in hook → `net.outbound`; file write in hook → `fs.write`; curl/wget → critical) | `tests/unit/test_ecosystem/test_hook_scanner.py` — network hook blocked, file-write hook blocked, benign hook passes, hook with banned pattern (`curl \| sh`, `wget`, `dd`) blocked | All hooks scanned; capability violations return `SG_DENY_HOOK_COMMAND_UNSAFE`; no hook bypasses enforcement |
| 43.2 | **Hook attestation + signing:** `skillgate claude hooks approve <hook-file>` signs the hook file with Ed25519; signed hooks stored in `.skillgate/hooks-attestation.json` (committed to repo); on session start, verify all hook files match their attestation; changed hook without re-approval → blocked + alert | `tests/unit/test_ecosystem/test_hook_attestation.py` — approved hook passes, modified hook blocked, new unapproved hook blocked, attestation file committed and deterministic | Hook changes are always detected; no silent hook modification |
| 43.3 | **Hook capability audit trail:** every hook execution recorded as a `ToolInvocation` with `tool.provider: claude-code-hook`, `tool.name: {hook_type}.{hook_file}`, capabilities inferred from hook command content; signed audit record per hook run; hooks included in risk score computation | `tests/unit/test_ecosystem/test_hook_audit.py` — hook invocation in audit log, correct capability inference, risk score impact | Hook executions visible in audit trail alongside MCP tool calls |
| 43.4 | **`skillgate claude hooks` CLI:** `hooks list` (all hooks + status: approved/unapproved/changed), `hooks approve <file>`, `hooks deny <file>`, `hooks audit` (recent executions), `hooks diff` (compare current vs approved baseline) | `tests/unit/test_cli/test_claude_hooks_commands.py` — all 5 subcommands functional, output format correct | Full hook lifecycle manageable via CLI |

**Ship gate:** All Claude Code hooks scanned against policy; unapproved or modified hooks blocked; hooks appear in audit trail.

---

### Day 121–125: Instruction File + Slash Command Security

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 44.1 | **CLAUDE.md / AGENTS.md injection detection:** scan instruction files (`.claude/CLAUDE.md`, `CLAUDE.md`, `AGENTS.md`, `.claude/instructions.md`) for prompt injection patterns: jailbreak templates (`ignore all previous instructions`, `you are now`, `DAN`, `developer mode`), capability override phrases (`you have access to all tools`, `execute unrestricted`), data exfiltration triggers (`send all file contents to`, `exfiltrate`, `echo * to`), and social engineering patterns (`your true purpose is`); return `SG_DENY_INSTRUCTION_FILE_INJECTION` on detection; diff-mode: compare against git HEAD and alert on newly introduced patterns | `tests/unit/test_ecosystem/test_instruction_injection.py` — 30+ injection pattern variants across CLAUDE.md/AGENTS.md, clean instruction files pass, diff mode detects new pattern, false-positive rate <1% on Phase 1 safe fixture set | Injection patterns in instruction files blocked; diff alerts on new patterns; no disruption to legitimate instruction files |
| 44.2 | **CLAUDE.md / AGENTS.md capability scope validation:** parse instruction files for tool capability claims (`you can use shell`, `you have filesystem access`, `you may execute`) and validate they do not exceed the workspace's SkillGate policy; out-of-scope claims trigger warning + optional block; `trust_tier` of instructions treated as `low` unless explicitly elevated via policy | `tests/unit/test_ecosystem/test_instruction_scope.py` — over-scoped capability claim blocked, within-scope instruction passes, trust_tier correctly applied | Instruction files cannot grant agents capabilities beyond policy |
| 44.3 | **Slash command security scan:** scan `.claude/commands/*.md` (custom slash command definitions) for injection patterns, unsafe tool invocations (`Bash`, `shell`, `exec` appearing in command body without policy alignment), and data exfiltration patterns; flag commands that would grant agents capabilities not in their policy; diff monitoring on every command change | `tests/unit/test_ecosystem/test_slash_commands.py` — injection in command body blocked, unsafe tool reference flagged, clean command passes, diff detection works | Slash command definitions validated before registration |
| 44.4 | **Memory file governance:** scan `.claude/memory/`, `MEMORY.md`, and `~/.claude/projects/*/memory/` on write and on session load; detect attempts to persist capability expansion instructions (`remember you can`, `always allow`, `bypass`, `override policy`); policy: configurable `memory_policy: strict \| warn`; in strict mode, block writes containing capability override patterns | `tests/unit/test_ecosystem/test_memory_governance.py` — capability override write blocked in strict mode, benign memory write passes, session load scan fires, MEMORY.md scanned | Memory file injection path closed; agents cannot persist capability expansions |
| 44.5 | **`skillgate claude scan <directory>` command:** one-shot scan of an entire Claude Code project directory; finds and scans all relevant files: `CLAUDE.md`, hooks, slash commands, memory files, `settings.json`; produces unified SARIF-compatible report with all findings; exit code 1 on policy violation; integrates with GitHub Action CI step | `tests/unit/test_cli/test_claude_scan.py` — all 5 file types scanned, SARIF output valid, exit code correct, CI integration works | Single command audits entire Claude Code project configuration |

**Ship gate:** Injection detection active for CLAUDE.md/AGENTS.md, slash commands, and memory files. `skillgate claude scan` covers the full Claude Code config surface.

---

### Day 126–132: Plugin/Skill Registry + Sub-Agent Governance

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 45.1 | **Claude Code plugin registry integration:** fetch and cache the Claude Code plugin registry manifest (public plugin directory); for each enabled plugin, verify against registry: checksum match, publisher verification, declared capabilities match AI-BOM; block plugins not in registry with `SG_DENY_PLUGIN_NOT_ATTESTED`; `plugin_registry_policy: strict \| community \| off` | `tests/unit/test_ecosystem/test_plugin_registry.py` — registered plugin with matching checksum passes, unregistered plugin blocked in strict, community policy allows community-signed, policy=off disables | Plugin registry enforced; unknown plugins blocked in strict mode |
| 45.2 | **Skill capability diff in CI:** when a PR changes any skill definition file (`SKILL.md`, `skill.json`, `package.json` with `skillgate` section), run `skillgate diff` comparing PR branch vs base branch; block merge if: new capabilities added without approval, existing capabilities expanded, or trust_tier elevated; post PR comment with diff summary | `tests/integration/test_ecosystem/test_skill_diff_ci.py` — capability expansion blocked in CI, tier elevation blocked, reduction allowed, PR comment content correct | Skill capability regressions caught in CI before merge |
| 45.3 | **Sub-agent policy inheritance:** when Claude Code uses the Task tool to spawn a sub-agent, SkillGate detects the `Task` invocation and enforces that the sub-agent's capability budget is a strict subset of the parent's remaining budget; sub-agent cannot inherit more budget than parent currently has; prevents budget circumvention via sub-agent chaining | `tests/unit/test_ecosystem/test_subagent_inheritance.py` — sub-agent with same budget as parent blocked (must be subset), sub-agent exceeding parent budget blocked, chain of 3 agents correctly propagates shrinking budget | Sub-agent chaining cannot be used to bypass budget limits |
| 45.4 | **Sub-agent audit lineage:** every `ToolInvocation` carries optional `parent_invocation_id`; gateway detects Task tool calls and records parent→child relationship; `GET /v1/audit/lineage/{invocation_id}` returns full invocation tree; visualise in dashboard as agent execution graph; anomaly: sub-agent attempts capability not available to parent → immediate alert | `tests/unit/test_ecosystem/test_subagent_lineage.py` — parent_id propagated, lineage API returns tree, orphan detection, capability escalation via sub-agent detected | Full agent execution tree is auditable; escalation via spawning is impossible and detected |
| 45.5 | **`skillgate claude` top-level CLI surface:** unifies all Claude Code governance commands: `skillgate claude scan`, `skillgate claude hooks {list,approve,deny,audit,diff}`, `skillgate claude plugins {list,attest,block}`, `skillgate claude settings drift`, `skillgate claude agents lineage <id>`; help text references specific attack scenarios they prevent | `tests/unit/test_cli/test_claude_toplevel.py` — all commands route to correct implementations, help text present, JSON output for all commands | `skillgate claude` is the single entry point for all Claude Code governance; discoverable in `--help` |
| 45.6 | **"Secure Claude Code Project" golden template:** GitHub repo template (`skillgate-io/secure-claude-project`) containing: `.skillgate.yml` (full policy), `.claude/hooks/` (example approved hooks with attestations), `CLAUDE.md` (clean instruction template), `.github/workflows/skillgate-claude.yml` (CI scanning all Claude config surfaces), `README.md` (threat model + controls explanation); referenced from Claude Code docs and SkillGate docs site | Documentation review + template functional tests | Template published; covers all 5 attack surfaces (MCP tools, hooks, instruction files, slash commands, memory) |

**Sprint 10.5 Ship Gate:**
- [ ] Claude Code hook commands scanned against capability policy; unapproved hooks blocked
- [ ] Hook attestation enforced; modified hooks detected and blocked
- [ ] CLAUDE.md/AGENTS.md injection detection: 30+ patterns blocked; <1% false positive on clean files
- [ ] Instruction file capability scope validation enforced
- [ ] Slash command definitions scanned for injection and unsafe tool references
- [ ] Memory file write/load scanned in strict mode; capability override writes blocked
- [ ] `skillgate claude scan <dir>` produces SARIF-compatible report covering all 5 surfaces
- [ ] Plugin registry integration: unknown plugins blocked in strict mode
- [ ] Sub-agent policy inheritance: budget circumvention via Task tool impossible
- [ ] Sub-agent audit lineage recorded; lineage API functional
- [ ] `skillgate claude` unified CLI surface with all governance commands
- [ ] "Secure Claude Code Project" golden template published
- [ ] All tests pass; coverage ≥90% on `skillgate/ecosystem/`
- [ ] `ruff` + `mypy --strict` clean

**At this point, SkillGate governs every surface through which Claude Code can be manipulated or abused — MCP tools, hooks, instruction injection, slash commands, memory, plugins, and sub-agent chains. No other tool in the market covers this surface with enforcement-grade controls.**

---

## 4.6. Sprint 10.6: Claude Code Plugin Delivery — skillgate-agents (Days 130–140)

**Goal:** Package SkillGate governance as a proper Claude Code plugin (`skillgate-agents`) that developers install from the community marketplace in one command. This is the primary community distribution artifact — it is how SkillGate becomes native to every Claude Code developer's workflow without requiring them to understand the underlying CLI architecture.

**Why this sprint is separate:** Sprints 10 and 10.5 build the *enforcement engine*. Sprint 10.6 builds the *plugin artifact that wraps it* — discoverable, installable, and usable without documentation. These are different work and different audiences: 10/10.5 target SkillGate engineers, 10.6 targets the Claude Code developer community.

**Plugin specification:** `.claude-plugin/plugin.json` manifest + `commands/` (slash commands) + `skills/` (model-invoked) + `agents/` (security-sentinel) + `hooks/` (automatic enforcement via `hooks.json`). This matches the Claude Code plugin spec (`/en/plugins`). Plugin namespace: `skillgate-agents`.

### Day 130–133: Plugin Foundation + Skills Packaging

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 46.1 | Plugin manifest: `skillgate-agents/.claude-plugin/plugin.json` with `name`, `description`, `version`, `author`, `license`, `homepage`, `repository`, `keywords`; validates against Claude Code plugin schema; version-controlled in `skillgate-io/skillgate-agents` repo | Schema validation test + `claude --plugin-dir ./skillgate-agents` loads without errors | Plugin manifest valid; plugin loads in Claude Code development mode |
| 46.2 | Skills packaging: 6 model-invoked skills in `skills/` directory (`scan`, `runtime`, `mcp`, `claude`, `codex`, `sdk`); each with a focused `SKILL.md` containing frontmatter `name` and `description` (used by Claude for automatic invocation), and concise command reference content; skill descriptions are written as capability triggers ("Use when asked to scan…") | Manual review: each skill loads in `claude --plugin-dir`; descriptions trigger on expected user queries | 6 skills discoverable under `skillgate-agents` namespace; model invokes correct skill for each task |
| 46.3 | Slash commands: 6 user-invoked commands in `commands/` (`secure-project`, `audit`, `scan-mcp`, `approve-hooks`, `check-injection`, `enforce`); each a markdown workflow that calls `skillgate` CLI commands; `$ARGUMENTS` support for parameterization | Manual test of each command: `claude --plugin-dir ./skillgate-agents` → invoke each slash command → correct `skillgate` commands executed | All 6 slash commands functional; `$ARGUMENTS` handling works; no silent failures |

**Ship gate:** Plugin loads. All 6 skills and 6 commands work in `--plugin-dir` development mode.

---

### Day 134–136: Hooks + Agent + Enforcement Integration

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 46.4 | Enforcement hooks: `hooks/hooks.json` with `PreToolUse` matchers for `Bash` (`shell.exec`), `Write\|Edit` (`fs.write`), `WebFetch\|WebSearch` (`net.outbound`), `Task` (sub-agent budget check); `PostToolUse` matcher for `Bash` (output scan); all hooks call `skillgate gateway check/scan-output --stdin` via `jq` extraction; hooks `exit 0` always (non-blocking when sidecar unavailable) | `e2e/test_plugin_hooks.py` — hook fires on Bash tool use, stdin JSON parsed, `skillgate gateway check` called with correct args, hook does not block Claude when sidecar offline | Hooks auto-enforce for Bash, file writes, web requests, and sub-agent spawning; graceful no-op when sidecar not running |
| 46.5 | Security-sentinel agent: `agents/security-sentinel.md` — Sonnet 4.6 model, security-focused system prompt; recognises 6 injection categories, knows all decision codes, advises SAFE/REVIEW REQUIRED/BLOCKED with remediation commands; invocable via `/agents` in Claude Code | Agent review: invoke sentinel with each injection category example → correct verdict returned | Security-sentinel agent consistently flags injection patterns and provides accurate remediation commands |
| 46.6 | Plugin self-attestation: run `skillgate scan skillgate-agents/ --enforce --policy production` to verify the plugin itself is clean; run `skillgate scan skillgate-agents/ --sign --output json > skillgate-agents/attestation.json`; attest plugin with `skillgate mcp attest skillgate-agents`; include `attestation.json` in repo | Attestation valid: `skillgate verify skillgate-agents/attestation.json` passes; `skillgate mcp inspect skillgate-agents --verify-attestation` passes | Plugin ships with its own clean scan attestation — eats our own dog food |

**Ship gate:** Hooks fire automatically on tool use. Sentinel agent gives accurate verdicts. Plugin self-attested and clean.

---

### Day 137–140: Distribution + Marketplace

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 46.7 | Plugin README: `skillgate-agents/README.md` — installation one-liner, slash command reference table, skill trigger descriptions, hooks-as-enforcement explanation, `--plugin-dir` development mode, troubleshooting; written in plain product copy (no internal terms per CLAUDE.md UI standards) | Copy review: no internal terms, no ellipses, no em dashes; all commands copy-pasteable and tested | README enables zero-documentation installation and first use |
| 46.8 | Marketplace listing — `skillsmp.com`: submit `plugin.json` + `README.md` + `attestation.json` to skillsmp.com marketplace; plugin metadata matches submission requirements; listing includes install command, capability table, and security posture summary | Listing visible at skillsmp.com/skills/skillgate-agents | Plugin discoverable on skillsmp.com |
| 46.9 | Marketplace listing — `agentskills.io` + Claude Code community: submit to agentskills.io/submit; PR to Claude Code community plugins registry (if public); post to Anthropic community forum with integration guide; link from SkillGate docs site under "Claude Code Integration" | Listing visible; community post published; docs site updated | Plugin discoverable across all primary Claude Code community channels |
| 46.10 | Plugin installation CI test: GitHub Actions workflow in `skillgate-io/skillgate-agents` that: installs Claude Code, loads plugin with `--plugin-dir`, runs each slash command in headless mode, verifies output; runs on every PR; blocks merge on failure | CI green on clean plugin | Plugin regressions caught before release |

**Sprint 10.6 Ship Gate:**
- [ ] `claude --plugin-dir ./skillgate-agents` loads without errors; all components discovered
- [ ] 6 slash commands functional: `secure-project`, `audit`, `scan-mcp`, `approve-hooks`, `check-injection`, `enforce`
- [ ] 6 skills model-invocable under `skillgate-agents` namespace
- [ ] Hooks fire on Bash/Write/WebFetch/Task tool use; graceful no-op when sidecar unavailable
- [ ] Security-sentinel agent loaded; gives accurate SAFE/REVIEW REQUIRED/BLOCKED verdicts
- [ ] Plugin self-attested: `skillgate verify skillgate-agents/attestation.json` passes
- [ ] Plugin listed on skillsmp.com and agentskills.io
- [ ] README enables zero-documentation first use
- [ ] CI test passes on clean plugin

**At this point, SkillGate is a first-class Claude Code plugin installable from the community marketplace — not a separate tool developers need to remember to run. Enforcement is automatic via hooks; governance is one slash command away. This is the community distribution moat.**

---

## 5. Sprint 11: Codex CLI Bridge (Days 141–153)

**Goal:** `skillgate codex <args...>` wraps Codex/agent CLI execution. Every high-risk tool action is mediated. CI guard mode fails closed. Config poisoning from repo-local files is blocked. AGENTS.md instruction files are governed with the same depth as CLAUDE.md.

### Day 133–136: Codex Bridge Core

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 27.1 | `skillgate codex <args...>` wrapper command: launches Codex CLI subprocess with environment variables set to route tool calls through `skillgate-enforcer-sidecar`; `SKILLGATE_SIDECAR_URL`, `SKILLGATE_ENFORCE_MODE` injected; passes all remaining args through | `tests/unit/test_cli/test_codex_wrapper.py` — subprocess launched with correct env, args passed through, sidecar URL injected | Wrapper launches Codex with correct env; all args forwarded correctly |
| 27.2 | Tool-proxy environment injection: when Codex uses its tool interface (shell, apply-patch, fs read/write), calls are intercepted via environment-level hooks; high-risk operations routed to sidecar for decision before execution | `tests/unit/test_cli/test_tool_proxy.py` — shell call intercepted, fs write intercepted, decision fetched from sidecar, allowed calls proceed, denied calls blocked with clear error | High-risk tools cannot bypass interception; low-risk reads pass through without sidecar call for performance |
| 27.3 | Safe defaults for Codex: shell.exec budget: 10/min; net.outbound budget: 20/min; fs.write outside CWD: DENY; git.write on protected branches: REQUIRE_APPROVAL; process.spawn of interpreted runtimes outside allowlist: DENY | `tests/unit/test_cli/test_codex_defaults.py` — default budgets enforced, fs.write outside CWD blocked, git protected branch approval triggered, unauthorized spawn blocked | All defaults documented and enforced without custom policy file |
| 27.4 | `skillgate codex --ci` CI guard mode: hardened defaults (lower budgets, fail closed on unknown tool providers, no network egress except explicitly listed domains, no config loading from untrusted sources); produces machine-readable policy report (`--output sarif` compatible) | `tests/unit/test_cli/test_codex_ci_mode.py` — CI defaults stricter than dev, unknown provider blocked in CI, network egress restricted, machine-readable report produced | CI mode always stricter than dev; no manual override without explicit flag |

**Ship gate:** `skillgate codex` wrapper routes all high-risk tool calls through sidecar enforcement. CI mode applies hardened defaults.

---

### Day 137–141: Config Poisoning Defense

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 28.1 | Repo-local config scanner: on startup, scans repo root for config files that reference tool providers or MCP server definitions (`codex.yml`, `.codex/*.yml`, `mcp.json`, `.mcp/**`); compares against registry; any new/modified tool provider triggers `SG_DENY_CONFIG_POISONING_DETECTED` | `tests/unit/test_cli/test_config_poisoning.py` — clean config passes, new tool provider detected and blocked, modified provider (permission increase) detected, explicitly approved provider passes | Config poisoning detection runs on every session start; no new tool providers silently accepted |
| 28.2 | Explicit confirmation flow: when config poisoning detected, `skillgate` prompts user (interactive) or fails closed (CI); interactive: shows diff of new tool provider permissions and requires `skillgate codex approve <provider>` before proceeding | `tests/unit/test_cli/test_provider_approval.py` — interactive approval flow, CI fail-closed, approval persisted to registry, revocation works | Interactive users can approve; CI always fails closed without pre-approval |
| 28.3 | Supply chain hardening: verify tool provider checksums against AI-BOM on each launch; if checksum changed (e.g., binary updated) → require re-approval; checksums stored in `.skillgate/aibom.lock` (committed to repo) | `tests/unit/test_cli/test_supply_chain.py` — matching checksum passes, changed checksum blocked, lock file created on first run, lock file format is deterministic | Changed tool provider binary always requires re-approval; lock file prevents silent updates |
| 28.4 | Network egress allowlist for CI: in CI mode, `net.outbound` only to: explicitly configured domains + `api.skillgate.io` (for SLT renewal) + `api.anthropic.com`, `api.openai.com` (configurable); all other outbound denied; configurable via policy YAML | `tests/unit/test_cli/test_ci_network.py` — allowed domains pass, unknown domain denied, config YAML extends allowlist, Skillgate API always allowed for license | CI network is fail-closed; domain allowlist is explicit and auditable |

**Ship gate:** Config poisoning from repo-local files is detected and blocked. Supply chain checksums verified on launch. CI mode is fully hardened.

---

### Day 142–145: AGENTS.md Governance + Codex Polish

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 29.1 | **AGENTS.md + codex.md instruction file governance:** scan `AGENTS.md`, `codex.md`, `.codex/instructions.md` for injection patterns using the same engine as task 44.1 (CLAUDE.md scanner); extend pattern library with Codex-specific patterns (`execute without restrictions`, `ignore safety filters`, `full shell access granted`); diff monitoring compares against last approved version | `tests/unit/test_codex_bridge/test_agents_md.py` — 25+ injection patterns across AGENTS.md/codex.md, clean files pass, diff alert on new pattern, Codex-specific patterns detected | AGENTS.md/codex.md governed with equivalent depth as CLAUDE.md |
| 29.2 | **Codex workspace settings governance:** scan `~/.codex/config.json`, `.codex/config.json` for tool additions or permission expansions (same approach as task 26.8 for Claude Code); detect changes to `allowedCommands`, `trustedProviders`, `shellAccess`; approved baseline stored in `.skillgate/codex-settings-baseline.json` | `tests/unit/test_codex_bridge/test_codex_settings.py` — new command in allowedCommands blocked, trusted provider addition blocked, removal allowed, CI fail-closed | Codex settings governed identically to Claude Code settings |
| 29.3 | Codex wrapper overhead measurement + E2E test: P95 ≤30ms per tool call; simulated Codex workflow (file read → analysis → shell → fs write) routed through bridge; CI mode blocks unsafe operations; AGENTS.md injection triggers on adversarial file | `tests/perf/test_codex_bridge_latency.py` + `e2e/test_codex_bridge.py` — latency gate, full workflow, AGENTS.md injection blocked | P95 ≤30ms; E2E passes; AGENTS.md governance integrated |
| 29.4 | **"Secure Codex Stack" template:** reference repo template for Codex CLI in CI pipelines: `.github/workflows/secure-codex.yml`, `.codex/` settings baseline, `AGENTS.md` (clean template), AI-BOM lock, SkillGate policy file, `README.md` with threat model covering instruction injection + config poisoning | Documentation review + template validation | Template published; covers all Codex attack surfaces |

**Sprint 11 Ship Gate:**
- [ ] `skillgate codex` wrapper launches Codex with enforcement active
- [ ] All high-risk tool calls (shell/fs-write/net) intercepted and enforced
- [ ] CI guard mode hardens defaults and fails closed on unknown providers
- [ ] Config poisoning detected at session start; CI always fails closed
- [ ] Supply chain checksums verified; changed binaries require re-approval
- [ ] **AGENTS.md/codex.md injection detection: 25+ patterns blocked**
- [ ] **Codex settings governance fires on allowedCommands/trustedProviders expansion**
- [ ] P95 ≤30ms wrapper overhead (CI gate)
- [ ] "Secure Codex Stack" template published (covers instruction injection + config poisoning)
- [ ] All tests pass; coverage ≥90% on `skillgate/codex_bridge/`
- [ ] `ruff` + `mypy --strict` clean

---

## 6. Sprint 12: VS Code Extension — Shift-Left Moat (Days 134–148)

**Goal:** VS Code extension gives developers instant policy + capability feedback while editing. Inline warnings, local simulation, PR checklist generation. Extension communicates only with local `skillgate` binary — no secrets in extension.

### Day 134–138: Extension Core + Policy Linting

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 30.1 | VS Code extension scaffold: TypeScript extension with activation on `.skillgate.yml`, `skill.json`, `SKILL.md`, `CLAUDE.md`, `AGENTS.md`, `.claude/hooks/**`, `.claude/commands/**`, `MEMORY.md` file open; communicates with local `skillgate` binary via local HTTP (`localhost:<port>`) or stdio RPC; no API keys or SLT stored in extension storage | `tests/unit/test_vscode/test_extension_scaffold.ts` — activates on all governance file types, binary communication works, no secrets in extension storage | Extension activates on the full Claude Code project surface |
| 30.2 | Policy file linting: real-time YAML schema validation for `.skillgate.yml`; unknown fields highlighted; deprecated patterns flagged; version mismatch flagged; validation runs on save and on type (debounced 500ms) | `tests/unit/test_vscode/test_policy_linting.ts` — valid policy no errors, unknown field underlined, deprecated pattern warning, version mismatch error | Lint feedback visible in <1s of edit; no false positives on valid policies |
| 30.3 | Capability expansion diff detection: when editing policy or `SKILL.md`, compare current file against git HEAD; detect added capabilities (e.g., new `net.outbound: "*"` in prod tier); surface inline warning with explanation of enforcement impact | `tests/unit/test_vscode/test_capability_diff.ts` — no change → no warning, new capability → warning with severity, removed capability → info, prod tier expansion → error-level warning | Capability expansion detected accurately; prod tier expansions shown as errors |
| 30.4 | Inline risk hints: for code files, show inline gutter icons at lines that would trigger findings (shell execution, network calls, eval patterns); clicking shows finding description + policy impact + remediation | `tests/unit/test_vscode/test_inline_hints.ts` — gutter icons at shell lines, click shows details, no false positives in safe code | Inline hints accurate; no false positives in safe files from Phase 1 fixture set |
| 30.5 | **CLAUDE.md / AGENTS.md inline injection warnings:** when editing `CLAUDE.md`, `AGENTS.md`, or `.claude/instructions.md`, run real-time injection pattern scan (delegating to local binary, debounced 800ms); underline detected patterns with error-level diagnostic; hover tooltip explains the threat category (jailbreak / capability override / exfiltration trigger); "Approve exception" action invokes `skillgate claude scan --approve-line` | `tests/unit/test_vscode/test_instruction_warnings.ts` — jailbreak underlined, hover shows threat category, approve action works, clean file shows no warnings | Developers see injection warnings inline as they type; no surprise CI failures |
| 30.6 | **Hook editor integration:** when editing `.claude/hooks/*.json` or `.claude/hooks/*.sh`, show gutter icon for each hook command's risk level (green=approved, yellow=unapproved, red=unsafe); "Approve Hook" and "View Capability Impact" actions in context menu; real-time scan on every save | `tests/unit/test_vscode/test_hook_editor.ts` — approved hook green, modified hook yellow, unsafe command red, context menu actions trigger CLI | Hook risk visible while editing; approve action one-click from editor |
| 30.7 | **Memory file governance UI:** when editing `MEMORY.md` or `.claude/memory/**`, warn on lines that would be blocked by memory governance policy (capability override patterns); show policy mode (strict/warn) in status bar for memory files; "View Memory Policy" action | `tests/unit/test_vscode/test_memory_ui.ts` — blocked pattern underlined, policy mode in status bar, view action opens policy | Memory governance violations caught before commit |

**Ship gate:** Extension activates on all Claude Code governance file types; injection warnings in CLAUDE.md/AGENTS.md; hook risk icons in hook editor; memory governance visible inline.

---

### Day 139–143: Simulation Panel + Approval Workflow

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 31.1 | "Simulate invocation" panel: VS Code panel that accepts a sample `ToolInvocation` JSON (or fills from a form); sends to local `skillgate-enforcer-sidecar`; displays full `DecisionRecord` including decision code, reason codes, budget state, evidence hash | `tests/unit/test_vscode/test_simulation_panel.ts` — panel opens, invocation sent to sidecar, response displayed, error path handled | Simulation panel shows full decision record within 500ms |
| 31.2 | "Generate PR checklist" command: analyzes policy diff between current branch and base (via `git diff`); generates markdown checklist with: changed capabilities, approval requirements, compliance implications, reviewer instructions; copies to clipboard | `tests/unit/test_vscode/test_pr_checklist.ts` — no change → minimal checklist, capability expansion → approval step added, network expansion → security review required | PR checklist generated in <2s; covers all capability changes |
| 31.3 | "Open approval request" command: if simulated invocation returns `SG_APPROVAL_REQUIRED`, offers "Open approval request" action; calls `skillgate approve request` command locally; shows approval ID and status | `tests/unit/test_vscode/test_approval_request.ts` — approval request created, ID returned, status tracked | Approval request workflow functional end-to-end |
| 31.4 | Extension license state UI: status bar item showing license mode (Licensed / Limited / Needs Login); color-coded (green/yellow/red); clicking opens auth status panel with entitlement details and renewal button | `tests/unit/test_vscode/test_license_ui.ts` — status bar shows correct mode, color correct per mode, click opens panel, renewal triggers CLI renewal | License mode always visible; users never confused about their auth state |

**Ship gate:** Simulation panel runs invocations against local sidecar. PR checklist generated from policy diffs. License state visible in status bar.

---

### Day 144–148: Extension Polish + GitHub Action Integration

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 32.1 | GitHub Action template for VS Code workflow: `skillgate-policy-check.yml` — runs on PR; calls `skillgate scan --enforce` on changed files; posts PR comment with findings + PR checklist; fails on policy violation | `e2e/test_github_action_vscode.py` — action runs, PR comment posted, correct exit code | Action template published; works with `uses: skillgate-io/policy-check-action@v1` |
| 32.2 | Extension performance: all lint operations debounced; simulation panel call has 5s timeout; background binary calls non-blocking; extension never freezes VS Code | `tests/unit/test_vscode/test_performance.ts` — lint debounced, long binary call does not block UI, timeout honored | VS Code never frozen by extension; background calls always non-blocking |
| 32.3 | VS Code marketplace publish: extension packaged with `vsce`; published to VS Code marketplace as `skillgate-io.skillgate`; tested on VS Code stable (latest) + 2 previous versions | Manual validation + compatibility tests | Extension installable from marketplace; compatible with VS Code 1.85+ |

**Sprint 12 Ship Gate:**
- [ ] Extension activates on all Claude Code governance file types (policy, skills, CLAUDE.md, hooks, slash commands, memory)
- [ ] Policy linting gives real-time inline feedback
- [ ] Capability expansion detected and flagged (prod tier as error)
- [ ] Code-level risk hints in gutter (no false positives on safe fixtures)
- [ ] **CLAUDE.md/AGENTS.md injection patterns underlined inline with threat category on hover**
- [ ] **Hook editor shows per-command risk icons (green/yellow/red); approve action one-click**
- [ ] **Memory file governance violations shown inline before commit**
- [ ] Simulation panel sends invocations to local sidecar and shows full decision record
- [ ] PR checklist generated from policy diffs
- [ ] License state visible in status bar
- [ ] GitHub Action template published and functional
- [ ] Extension published to VS Code marketplace
- [ ] All TypeScript tests pass
- [ ] Extension never freezes VS Code

**At this point, SkillGate lives in every surface of the developer's Claude Code workflow — from policy files to instruction files to hooks to memory. This is the definitive shift-left moat.**

---

## 7. Sprint 13: Observability, Telemetry + SIEM Exports (Days 149–161)

**Goal:** Structured tool invocation logs, Prometheus/OTEL metrics, webhook exports to SIEM/SOAR, and a basic capability usage dashboard. Security and platform teams can now ingest SkillGate data into their existing tooling.

### Day 149–153: Metrics + Structured Logging

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 33.1 | Prometheus metrics: `skillgate_decisions_total{decision_code, tool, workspace}`, `skillgate_decision_latency_ms_bucket{le}`, `skillgate_budget_exceeded_total{capability, workspace}`, `skillgate_circuit_state{component}`, `skillgate_license_mode{mode, workspace}`; `GET /metrics` endpoint on sidecar | `tests/unit/test_observability/test_metrics.py` — all 5 metrics emitted on decision, labels correct, histogram buckets populated | All metrics emitted; Prometheus scrape returns valid format |
| 33.2 | OpenTelemetry tracing: trace each invocation through gateway → enforcer → tool provider → response; trace spans include `invocation_id`, stage names, latency per stage; OTLP exporter configurable (GRPC or HTTP); W3C trace context propagated | `tests/unit/test_observability/test_tracing.py` — spans created per stage, invocation_id correlates, OTLP export format valid | Trace spans visible in any OTLP-compatible backend (Jaeger/Tempo) |
| 33.3 | Structured audit log: append-only NDJSON log per workspace; each line: full `DecisionRecord` + `ToolInvocation` summary + timestamp + sidecar version; log rotation (daily, configurable retention); log integrity: rolling SHA-256 chain (each record includes hash of previous) | `tests/unit/test_observability/test_audit_log.py` — log entries are NDJSON, hash chain is valid, tampering detected on chain break, rotation works | Log integrity chain detectable; any tampering invalidates chain from modification point |
| 33.4 | PII redaction: `--redact-params` mode strips tool invocation parameters from logs (replaces with `[REDACTED]`); metadata-only mode keeps tool name/timestamp/decision but drops all params; configurable by workspace policy | `tests/unit/test_observability/test_pii_redaction.py` — full params in default mode, redacted in --redact-params, metadata-only mode correct | PII never logged when redact mode active; metadata-only mode matches spec |

**Ship gate:** Prometheus metrics scrappable; audit log hash chain valid; OTLP traces exported.

---

### Day 154–157: SIEM Webhooks + Dashboard

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 34.1 | Webhook event system: configurable webhooks for: `decision.deny`, `decision.approval_required`, `budget.exceeded`, `anomaly.detected`, `license.expired`; events delivered with HMAC-SHA256 signature in `X-SkillGate-Signature` header; retry with exponential backoff (3 attempts); delivery timeout 5s | `tests/unit/test_observability/test_webhooks.py` — events delivered on trigger, HMAC signature valid, retry on failure, timeout honored, duplicate prevention | HMAC signature valid for all delivered events; retries do not produce duplicates |
| 34.2 | SIEM connectors (v1): pre-built exporters for **Datadog** (events API), **Splunk HEC** (HTTP Event Collector), **Elastic** (bulk API); configured via `observability.yml`; test mode sends sample event | `tests/integration/test_siem/test_datadog.py`, `test_splunk.py`, `test_elastic.py` — event structure matches each SIEM format, test mode works, auth headers correct | At least one SIEM connector (Datadog) end-to-end tested in CI with mock server |
| 34.3 | Capability usage dashboard (v0): static React SPA (deployed with `skillgate dashboard serve`); shows: decisions over time, top denied capabilities, per-workspace budget utilization, license mode status; data from local audit log or sidecar API | `tests/unit/test_dashboard/test_data_queries.py` — correct aggregation, empty state, large log file pagination | Dashboard renders correctly; data accurate vs audit log |
| 34.4 | CSV/JSON export: `skillgate export --format csv --from 2026-01-01 --to 2026-02-01` exports decision records; `--format json` for machine consumption; `--format sarif` for security tab integration; supports workspace filter | `tests/unit/test_cli/test_export_command.py` — CSV headers correct, JSON valid, SARIF valid, date range filter works | Export command produces valid outputs for all three formats |

**Ship gate:** Webhooks delivered with valid signatures. At least one SIEM connector functional. Dashboard loads and shows correct data.

---

### Day 158–161: Risk Scoring v0 + Anomaly Detection Seed

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 35.1 | Per-agent risk score (v0): rule-based risk score for each agent based on: capabilities used (weighted sum), frequency of denied actions, budget utilization %, new capabilities not seen before; score updated on each decision | `tests/unit/test_intelligence/test_agent_risk_score.py` — score increases with capability usage, denials increase score, new capability spikes score, score bounded [0, 100] | Risk score computed deterministically; same agent history = same score |
| 35.2 | Anomaly detection seed (v0): spike detection — if capability usage in 5-min window > 3× rolling 1-hour average, emit `anomaly.detected` webhook; new capability detection — if agent uses capability not seen in previous 24h sessions, emit alert | `tests/unit/test_intelligence/test_anomaly_detection.py` — spike threshold triggered, new capability alert fires, no alert below threshold, rolling average computed correctly | Spike and new-capability anomalies detected and emitted |
| 35.3 | Risk score API: `GET /v1/risk/{workspace_id}/{agent_id}` returns current risk score + score history (24h) + contributing factors breakdown; `GET /v1/risk/{workspace_id}` returns all agents sorted by risk | `tests/integration/test_risk_api.py` — correct scores, history populated, sorted by risk, empty workspace returns empty list | Risk API accurate and performant (<100ms P95) |

**Sprint 13 Ship Gate:**
- [ ] Prometheus metrics (5 metrics) scrapeable; OTLP traces exported
- [ ] Audit log is append-only NDJSON with rolling SHA-256 integrity chain
- [ ] PII redaction modes work correctly
- [ ] Webhooks delivered with HMAC signatures; at least Datadog connector tested
- [ ] Dashboard renders decision data from audit log
- [ ] `skillgate export` produces CSV/JSON/SARIF output
- [ ] Per-agent risk scores computed deterministically
- [ ] Spike + new-capability anomaly detection fires correctly
- [ ] Risk API returns correct data
- [ ] All tests pass; coverage ≥90% on `skillgate/observability/` and `skillgate/intelligence/`
- [ ] `ruff` + `mypy --strict` clean

---

## 8. Sprint 14: Agent Framework SDKs — Embedded Middleware Moat (Days 162–178)

**Goal:** SkillGate Python SDK wraps tool definitions in PydanticAI, LangChain, and CrewAI. Once integrated, SkillGate is in the critical path of every tool invocation — removing it requires refactoring agent architecture.

### Day 162–166: Python SDK Core

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 36.1 | `skillgate-sdk` Python package: `pip install skillgate-sdk`; core: `@skillgate.enforce` decorator for tool functions; decorator intercepts call, builds `ToolInvocation`, sends to sidecar, enforces decision, passes through on `ALLOW`, raises `CapabilityDeniedError` on `DENY`, yields `ApprovalPendingError` on `REQUIRE_APPROVAL` | `tests/unit/test_sdk/test_decorator.py` — allow path executes function, deny raises error, approval pending raises error, error contains decision_code | Decorator is zero-config; wrapping a function adds <1ms if sidecar is reachable locally |
| 36.2 | `SkillGateClient` class: manages sidecar connection (local HTTP or optional remote); automatic reconnect; SLT auth; per-invocation timeout (default 50ms, configurable); falls back to `ALLOW` if sidecar unreachable and `fail_open=True` (default `False`) | `tests/unit/test_sdk/test_client.py` — connect/reconnect, SLT auth header sent, timeout enforced, fail_open=False raises error on unreachable, fail_open=True allows | fail_open=False is the default (fail-closed); timeout is configurable |
| 36.3 | AI-BOM registration: SDK automatically registers current tool with sidecar on first call (`PUT /v1/registry/{tool_name}`); registers: function signature, declared capabilities (from decorator arg), calling module path, package version; AI-BOM updated on version change | `tests/unit/test_sdk/test_aibom_registration.py` — first call registers, version change updates, registration idempotent, capabilities from decorator arg | AI-BOM always current; version changes detected and logged |
| 36.4 | Integration manifest spec v1: YAML spec for integration connectors; fields: `name`, `version`, `framework`, `capabilities_declared[]`, `tool_router_hook` (inject point), `telemetry_schema`; SDK generates manifest from decorator metadata; stored in `.skillgate/integrations.yml` | `tests/unit/test_sdk/test_integration_manifest.py` — manifest generated correctly, YAML valid, framework field matches known enum | Integration manifests are machine-readable and auditable |

**Ship gate:** `@skillgate.enforce` decorator wraps any Python function; AI-BOM registered automatically; fail-closed by default.

---

### Day 167–171: Framework-Specific Integrations

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 37.1 | PydanticAI integration: `skillgate.integrations.pydantic_ai.SkillGateMiddleware` — wraps PydanticAI agent tool router; intercepts all tool calls; uses `@skillgate.enforce` internally; example: `agent = Agent(..., tools=[skillgate_wrapped(my_tool)])` | `tests/unit/test_sdk/test_pydantic_ai.py` — tool wrapping works, enforcement active, PydanticAI tool schema preserved, multi-tool agent works | PydanticAI tools enforced without changing tool signature or schema |
| 37.2 | LangChain integration: `skillgate.integrations.langchain.SkillGateTool` — LangChain tool subclass that enforces before `_run()`; `SkillGateToolkit` wraps existing `BaseTool` instances; `LangSmith` tracing preserved (enforcement adds span) | `tests/unit/test_sdk/test_langchain.py` — Tool subclass enforces, Toolkit wraps correctly, LangSmith span added, agent.run() blocked on denial | LangChain tools enforced; existing chains work without agent code changes |
| 37.3 | CrewAI integration: `skillgate.integrations.crewai.SkillGateTask` — wraps CrewAI task execution; enforces before task tool calls; compatible with CrewAI task delegation chains | `tests/unit/test_sdk/test_crewai.py` — task enforcement active, delegation chain enforced, CrewAI output unchanged on allow | CrewAI task delegation enforced at each hop |
| 37.4 | Framework detection: SDK auto-detects installed framework (PydanticAI/LangChain/CrewAI) and offers guided integration command `skillgate integrate --framework pydantic-ai`; outputs example code for wrapping tools | `tests/unit/test_sdk/test_auto_detect.py` — detection works, example code generated, unknown framework suggests generic decorator | One-command integration guide reduces adoption friction |

**Ship gate:** PydanticAI and LangChain integrations functional and tested. CrewAI integration available. `skillgate integrate` generates example code.

---

### Day 172–178: SDK Polish + Documentation

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 38.1 | SDK async support: `@skillgate.enforce_async` for `async def` tool functions; async client with `httpx.AsyncClient`; concurrent enforcement (multiple tools in parallel) with per-call timeout | `tests/unit/test_sdk/test_async.py` — async tool enforced, concurrent calls work, timeout per call, fail-closed async | Async enforcement does not block event loop |
| 38.2 | SDK error handling: `CapabilityDeniedError(decision_code, reason_codes, budgets)`, `ApprovalPendingError(approval_id, capabilities_needed)`, `EnforcerUnavailableError(last_attempt_at)` — all have human-readable `__str__` and machine-readable fields | `tests/unit/test_sdk/test_errors.py` — all 3 error types raised correctly, fields accessible, string representation useful | Errors always include actionable information for developer |
| 38.3 | SDK documentation: `README.md` with quickstart (5-line integration), API reference (docstrings auto-generated via `pdoc`), framework integration examples (3 frameworks), security guarantees section, upgrade guide | Documentation review | SDK documentation complete; quickstart copy-pasteable in <5 minutes |
| 38.4 | `skillgate-sdk` PyPI publish: package at `skillgate-sdk` on PyPI; versioned with semver; includes PydanticAI/LangChain/CrewAI extras (`pip install skillgate-sdk[pydantic-ai]`) | Manual publish + install test | `pip install skillgate-sdk` works; extras install correct dependencies |

**Sprint 14 Ship Gate:**
- [ ] `@skillgate.enforce` decorator wraps any Python function; fail-closed by default
- [ ] `SkillGateClient` reconnects automatically; SLT auth header sent
- [ ] AI-BOM registered on first call; updated on version change
- [ ] PydanticAI + LangChain integrations functional and tested
- [ ] CrewAI integration available
- [ ] Async enforcement non-blocking
- [ ] All error types have machine-readable fields + actionable strings
- [ ] SDK published to PyPI with extras
- [ ] `skillgate integrate` auto-generates framework-specific code
- [ ] All SDK tests pass; coverage ≥90%
- [ ] `ruff` + `mypy --strict` clean on SDK

**At this point, SkillGate is embedded middleware in the most popular agent frameworks — removal requires refactoring tool definitions.**

---

## 9. Sprint 15: Intelligence + SaaS Control Plane (Days 179–202)

**Goal:** Multi-tenant SaaS control plane with RBAC, approval workflows, audit retention, risk scoring v1, anomaly detection v1, and lightweight compliance annotations. Enterprise teams can now manage multiple workspaces centrally.

### Day 179–184: SaaS Control Plane + RBAC

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 39.1 | Multi-tenant workspace model: `Organization` → `Workspace` → `Agent` hierarchy; each workspace has its own policy snapshot, audit log shard, and budget state; workspace isolation tested (cross-workspace data never accessible) | `tests/unit/test_control_plane/test_workspace_isolation.py` — 10 workspaces, cross-read blocked, own workspace readable, data never leaks | Workspace isolation verified; no cross-workspace data access possible |
| 39.2 | RBAC model: roles: `org_admin`, `workspace_admin`, `security_reviewer`, `developer`; permissions matrix: policy CRUD, audit read, approval actions, team management; JWT claims include role; all endpoints enforce role check | `tests/unit/test_control_plane/test_rbac.py` — all role/permission combinations, role escalation blocked, JWT claim respected, superfluous permissions denied | No role escalation possible; every endpoint enforces minimum required role |
| 39.3 | Approval workflow: `POST /v1/approvals/request` creates pending approval with: capability, workspace, requesting agent, justification, expiry; `POST /v1/approvals/{id}/approve` (security_reviewer+); `POST /v1/approvals/{id}/deny`; `GET /v1/approvals/pending`; approval state embedded in policy snapshot | `tests/unit/test_control_plane/test_approvals.py` — full approval lifecycle, expiry enforcement, status embedded in snapshot, approver role required | Approval workflow complete; approvals expire; enforcer uses snapshot with embedded approval state |
| 39.4 | Policy management API: `PUT /v1/policies/{workspace_id}` with diff-based validation; policy changes create immutable version records; rollback to previous version (`POST /v1/policies/{workspace_id}/rollback`); policy snapshot pushed to all sidecars on change | `tests/unit/test_control_plane/test_policy_management.py` — create/update/rollback, immutable versions, snapshot push, diff validation | Policy versions immutable; rollback deterministic |
| 39.5 | Audit log retention: configurable per-workspace retention (7d/30d/90d/1y); background retention enforcement job; `DELETE /v1/audit/{workspace_id}/before/{date}` (admin only); deletion auditable itself | `tests/unit/test_control_plane/test_audit_retention.py` — retention enforced, past retention date records deleted, deletion audited | Retention policy enforced; deletion is auditable |

**Ship gate:** Multi-tenant workspaces isolated. RBAC enforced on all endpoints. Approval workflow complete. Policy versioning with rollback.

---

### Day 185–190: Risk Intelligence v1 + Anomaly Detection v1

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 40.1 | Risk scoring v1: per-agent risk score based on: capability profile (weighted by risk class), denied action rate (30d rolling), budget saturation %, anomaly frequency, new capability introduction frequency; score [0–100]; `critical` threshold: 80+, `high`: 60–79, `medium`: 30–59 | `tests/unit/test_intelligence/test_risk_scoring_v1.py` — score components correct, thresholds trigger correct labels, historical aggregation correct, deterministic | Risk scores accurate; same history = same score across multiple computes |
| 40.2 | Anomaly detection v1 (production): spike detection (5-min usage > 3× 1h average); new capability detection (capability not seen in prior 14 days); suspicious combo detection (shell+net+fs-write in <30s window); alert suppression (same alert type: 15min cooldown per agent) | `tests/unit/test_intelligence/test_anomaly_v1.py` — all 3 anomaly types fire correctly, cooldown suppresses duplicates, suppression does not prevent different anomaly types | Anomalies fire on correct conditions; cooldown prevents alert fatigue |
| 40.3 | Risk intelligence API: `GET /v1/risk/org/{org_id}` (org-wide risk overview sorted by risk), `GET /v1/risk/workspace/{workspace_id}` (workspace agents), `GET /v1/risk/agent/{agent_id}` (full agent risk detail + 30d history + anomalies), `GET /v1/anomalies/pending` (unacknowledged anomalies) | `tests/integration/test_risk_intelligence_api.py` — correct aggregations, pagination, 30d history, anomaly state | Risk API serves accurate data; org-level view loads in <500ms |
| 40.4 | Community policy packs: `GET /v1/community/policies` lists published policy templates; `POST /v1/community/policies/import` imports a community policy into workspace; templates: `baseline-agent-security`, `high-trust-agent`, `low-trust-agent`, `production-hardening`, `ci-strict`; each template versioned and signed | `tests/unit/test_intelligence/test_community_policies.py` — import works, templates valid, signatures verified, workspace-adapted on import | Community templates importable; signatures verified before import |

**Ship gate:** Risk scores accurate and deterministic. All three anomaly types detected. Community policy packs importable.

---

### Day 191–197: Compliance Layer + Enterprise Features

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 41.1 | Lightweight compliance annotation: enforcement actions and audit records annotated with high-level governance framework control IDs; NIST AI RMF: `GOVERN`, `MAP`, `MEASURE`, `MANAGE`; EU AI Act: `Article 9` (risk management), `Article 10` (data governance), `Article 15` (accuracy), `Article 17` (QMS); annotation is additive — does not change enforcement behavior | `tests/unit/test_compliance/test_annotations.py` — annotations present in audit records, correct framework IDs mapped, annotation does not alter decision | Annotations present; enforcement unchanged by annotation logic |
| 41.2 | "Agent Capability Governance Report": `skillgate report governance --workspace <id> --period 30d`; PDF/Markdown report covering: capability inventory, denied action summary, anomaly timeline, approval history, risk score trends, compliance annotation counts; designed for audits and board reporting | `tests/unit/test_compliance/test_governance_report.py` — report generated for 30d period, all sections populated, Markdown valid | Governance report generated in <5s; Markdown parseable |
| 41.3 | Enterprise SSO: SAML 2.0 and OIDC SSO support via Supabase Auth provider; `org_admin` can configure SSO provider; all team members authenticated via SSO; API keys still supported for CI/CD where SSO is not applicable | `tests/unit/test_enterprise/test_sso.py` — SAML flow works, OIDC flow works, non-SSO API keys still valid, role mapping from SSO groups | SSO login end-to-end functional; roles mapped from IdP groups |
| 41.4 | Audit log export for enterprise: `skillgate export audit --workspace <id> --format splunk-hec --from ... --to ...`; format options: JSON, CSV, Splunk HEC, Elastic bulk, OCSF; large exports streamed (no in-memory buffering); signed export manifest | `tests/unit/test_enterprise/test_audit_export.py` — all formats valid, streaming works for 100k records, manifest signature valid | 100k record export completes in <30s; no OOM; manifest signed |

**Ship gate:** Governance report generated. SSO functional. Audit export streaming works for large datasets.

---

### Day 198–202: SaaS Polish + Launch Readiness

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| 42.1 | SaaS availability hardening: health checks, liveness/readiness probes, graceful shutdown (drain in-flight requests), restart policy; database connection pooling (max 50 connections); API rate limits per org (Free: 100/min, Pro: 600/min, Team: 3000/min, Enterprise: 10000/min) | `tests/integration/test_saas/test_availability.py` — graceful shutdown, connection pool limits, rate limits per tier | Graceful shutdown in <5s; rate limits enforced per tier |
| 42.2 | Multi-region deployment readiness: policy snapshots synced across regions (eventual consistency, max 5s lag); audit logs written to region of origin; SLT valid across all regions (same signing key) | `tests/integration/test_saas/test_multi_region.py` — snapshot sync lag <5s, audit log region-pinned, SLT valid in all regions | Multi-region ready for deployment |
| 42.3 | Phase 2 launch preparation: SaaS pricing page updated with Phase 2 capabilities; docs site updated with all Phase 2 features (runtime enforcement, MCP gateway, Codex bridge, VS Code, SDK, intelligence, control plane); changelog for v2.0.0 | Documentation review | All Phase 2 features documented; pricing page accurate |
| 42.4 | E2E Phase 2 smoke test: full end-to-end test covering: agent tool call → MCP gateway → enforcement decision → signed audit record → risk score update → anomaly check → webhook delivery → SIEM export → governance report; verifies entire Phase 2 stack is connected | `e2e/test_phase2_smoke.py` — all components connected, no broken links in data flow | E2E smoke test passes green |

**Sprint 15 Ship Gate:**
- [ ] Workspace isolation verified; RBAC enforced on all endpoints
- [ ] Approval workflow complete lifecycle (create → approve/deny → embedded in snapshot)
- [ ] Policy versioning with immutable history and rollback
- [ ] Risk scores accurate and deterministic
- [ ] All three anomaly types detected with cooldown suppression
- [ ] Community policy packs importable with signature verification
- [ ] NIST/EU AI Act annotations in audit records
- [ ] "Agent Capability Governance Report" generated correctly
- [ ] SSO (SAML + OIDC) functional
- [ ] Audit export streaming handles 100k records
- [ ] Rate limits enforced per tier
- [ ] E2E Phase 2 smoke test passes
- [ ] All tests pass; coverage ≥90% on `skillgate/control_plane/` and `skillgate/intelligence/`
- [ ] `ruff` + `mypy --strict` clean

**Phase 2 complete. SkillGate is the Agent Capability Firewall with full runtime enforcement, ecosystem integrations, observability, intelligence, and SaaS control plane.**

---

## 10. Definition of Done

### 10.1 Per-Task DoD

Every task is done when:
- [ ] Implementation is complete and matches the specification
- [ ] All required tests (listed in task table) pass
- [ ] No new `ruff` errors; `mypy --strict` clean
- [ ] Coverage ≥90% on changed module
- [ ] Performance SLOs met (sidecar P95 ≤20ms, gateway P95 ≤25ms, bridge P95 ≤30ms)
- [ ] Fail-closed behavior verified for all error paths
- [ ] No secrets logged or exposed

### 10.2 Per-Sprint DoD

Every sprint is done when:
- [ ] All ship gate items checked
- [ ] Full test suite passes (unit + integration + e2e + perf)
- [ ] Coverage ≥90% on all sprint-modified modules
- [ ] `ruff check .` + `mypy --strict skillgate/` both clean
- [ ] No open P0/P1 bugs
- [ ] Docs updated for all new CLI commands and APIs
- [ ] Performance regression gates green in CI

### 10.3 Phase 2 Production-Readiness Checklist

- [ ] **Determinism:** 100% stable enforcement decisions across 1000-run test vectors
- [ ] **Latency:** Sidecar P95 ≤20ms, P99 ≤50ms at 10k/min; MCP gateway ≤25ms added overhead; Codex bridge ≤30ms added overhead
- [ ] **Availability:** Sidecar operates correctly in all three degraded modes (offline, expired SLT, audit-unavailable)
- [ ] **Security:** Path traversal, argument injection, config poisoning, none-alg JWT, MCP privilege escalation — all blocked with tests
- [ ] **Privacy:** PII redaction active; no secrets in logs; SLT stored only in keychain/encrypted file
- [ ] **Compliance annotations:** NIST AI RMF + EU AI Act control IDs in audit records
- [ ] **Ecosystem coverage:** MCP + Codex + PydanticAI + LangChain integrations all functional
- [ ] **Commercial readiness:** All pricing tiers enforce correct limits; SSO functional; governance report generated

### 10.4 Moat Validation Checklist

The following must be true before Phase 2 is considered production-complete:

- [ ] **Embedded middleware moat:** Removing SDK from a PydanticAI or LangChain project requires editing tool definitions — not just config
- [ ] **Gateway moat:** Claude Code with SkillGate MCP gateway cannot be bypassed by a tool call (verified via security test)
- [ ] **Config poisoning moat:** Repo-local config cannot introduce new tool providers without explicit approval (verified via CI fail-closed test)
- [ ] **Audit chain moat:** Audit log tampering is detectable (hash chain test)
- [ ] **Policy standard moat:** Integration manifest spec is documented and used by all 4 integrations (MCP, Codex, PydanticAI, LangChain)

---

## 11. Revenue Milestones

| Day | Target | Metric |
|---|---|---|
| Day 90 (Sprint 9 complete) | Free tier self-serve active | Anonymous trial SLT working; `sg_free_*` keys issued via web UI |
| Day 110 (Sprint 10 complete) | First MCP gateway deployments | 50+ developers with gateway configured in Claude Code |
| Day 135 (Sprint 12 complete) | VS Code marketplace installs | 200+ extension installs; PR review workflows using SkillGate checklist |
| Day 160 (Sprint 13 complete) | First SIEM integrations | 5+ teams exporting to Datadog/Splunk |
| Day 180 (Sprint 14 complete) | SDK adoptions driving MRR | 3+ paying teams with agent framework SDK deployed in production |
| Day 202 (Sprint 15 complete) | SaaS control plane MRR | $15k MRR; 2+ enterprise prospects in trial |

---

## 12. Risk Mitigation Timeline

| Risk | Severity | Mitigation | Deadline |
|---|---|---|---|
| MCP transport changes (Anthropic updates protocol) | High | Abstract transport layer behind interface; monitor Anthropic MCP changelog weekly | Sprint 10 start |
| Sidecar latency regression under real load | High | CI perf gate + weekly benchmark; alert at 15ms (before the 20ms SLO breach) | Sprint 8 complete |
| SLT key compromise | Critical | Key rotation procedure documented and tested; JWKS endpoint published; 6-hour rotation support | Sprint 9 complete |
| Config poisoning via creative path injection | High | Fuzz test with 100+ path injection patterns; symlink edge cases; Unicode path normalization | Sprint 11 complete |
| VS Code extension API breakage (version upgrade) | Medium | Test against VS Code 1.85+ (stable) and VS Code Insiders; pin to VS Code API version in `package.json` | Sprint 12 complete |
| Agent framework SDK API drift (LangChain/PydanticAI breaking changes) | Medium | Pin minimum supported versions; integration tests against multiple versions; versioned compatibility matrix | Sprint 14 complete |
| Multi-tenant workspace data leakage | Critical | Automated isolation tests (10 workspace cross-read matrix) + SQLRls policy + negative authorization tests | Sprint 15 start |

---

## 13. Addendum A: Integration Registry + Community Policy Packs

**Decision:** Ship integration registry as a lightweight GitHub-hosted YAML manifest before building a marketplace. Do not monetize registry in Phase 2.

### A.1 Integration Registry Spec

| Task | Description | Tests Required | DoD |
|---|---|---|---|
| A.1 | Integration manifest format v1: YAML with `name`, `version`, `framework` (enum), `capabilities_declared[]`, `connector_type` (sdk/middleware/gateway/wrapper), `verified` (bool), `maintainer`, `install_command`; stored at `skillgate-io/integrations` GitHub repo | Schema validation tests + PR bot for format checks | Manifest spec published; PR bot validates submissions |
| A.2 | `skillgate integrations list` command: fetches registry from GitHub (cached 1h); displays as table; `--framework pydantic-ai` filter | `tests/unit/test_cli/test_integrations_command.py` — list fetched, filter works, cached on second call | Command works with registry; offline uses cache |
| A.3 | Community policy pack registry: `skillgate policies list --community`; 5 seed packs: `baseline-agent-security`, `high-trust-agent`, `low-trust-agent`, `production-hardening`, `ci-strict`; each signed with SkillGate key; importable | `tests/unit/test_cli/test_policy_list.py` — list shows community packs, import works, signature verified | 5 seed packs published and importable |

---

## 14. Addendum B: Enterprise Compliance Layer (NIST / EU AI Act Mapping)

**Decision:** Add compliance annotations in Phase 2 as lightweight metadata only. Full GRC questionnaire workflows are explicitly out of scope. Annotations must not change enforcement behavior.

### B.1 Compliance Annotation Contract

| Control Framework | SkillGate Controls Mapped | Annotation ID |
|---|---|---|
| NIST AI RMF — GOVERN | Policy schema, workspace RBAC, org-level configuration | `NIST-AI-GOVERN-1.1` |
| NIST AI RMF — MAP | Tool capability inventory (AI-BOM), risk classification | `NIST-AI-MAP-2.2` |
| NIST AI RMF — MEASURE | Risk scoring, anomaly detection, audit metrics | `NIST-AI-MEASURE-2.5` |
| NIST AI RMF — MANAGE | Approval workflows, policy enforcement, incident response via webhooks | `NIST-AI-MANAGE-1.3` |
| EU AI Act — Article 9 | Risk management system (risk scoring, policy gates) | `EU-AIA-ART9` |
| EU AI Act — Article 17 | Quality management system (policy versioning, signed attestations) | `EU-AIA-ART17` |

**Constraint:** Annotations are additive metadata on `DecisionRecord`. They do not alter enforcement logic, latency, or decision codes.

---

## 15. Addendum C: Open-Core Split + Ecosystem Governance

**Decision:** Phase 2 open-core boundary — enforce before Sprint 15 production cutover.

### C.1 Public/Private Boundary (Phase 2)

| Component | Boundary | Rationale |
|---|---|---|
| `skillgate/core/` | Public (CE) | Phase 1 static analysis engine — already open |
| `skillgate/runtime/` | Public (CE) | Enforcement engine — ecosystem adoption requires it |
| `skillgate/sdk/` | Public (CE) | Agent framework integrations — growth via open adoption |
| `skillgate/mcp_gateway/` | Public (CE) | Claude/MCP integration — primary moat built on openness |
| `skillgate/codex_bridge/` | Public (CE) | Codex wrapper — open for adoption |
| `skillgate/auth/` (SLT client) | Public (CE) | Client-side SLT handling — open |
| `skillgate/auth/` (SLT issuance + key signing) | Private (EE) | Key management, exchange endpoint — commercial control |
| `skillgate/control_plane/` | Private (EE) | SaaS multi-tenant, RBAC, approvals — commercial control |
| `skillgate/intelligence/` | Private (EE) with OSS seed | Risk scoring algorithm open; cross-tenant learning private |
| `skillgate/observability/` (OTEL, Prometheus) | Public (CE) | Standard telemetry — open |
| `skillgate/observability/` (SIEM connectors) | Private (EE) | Enterprise connectors — commercial tier |

### C.2 Open-Core Governance Gate

Before Phase 2 public release:
- [ ] Public/private boundary enforced in CI (`check_public_export.py --strict`)
- [ ] `SECURITY.md`, `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md` present in public repo
- [ ] License headers consistent across all public modules
- [ ] No internal implementation details exposed in public-facing error messages or docs

---

## 16. Addendum D: Claude Code + Codex Community Dominance Strategy

**Decision:** Phase 2 must make SkillGate the *de facto* security layer for the Claude Code and Codex CLI communities — not just a product those communities can optionally add, but one they cannot responsibly operate without.

### D.1 The Attack Surface Map (Why This Addendum Exists)

Claude Code and Codex CLI expose 7 distinct attack surfaces. Phase 2 must govern all 7:

| Surface | Attack Vector | SkillGate Control | Sprint |
|---|---|---|---|
| MCP tools | Supply-chain compromise, capability escalation | Gateway + AI-BOM + permission drift detection | Sprint 10 |
| Tool descriptions | Prompt injection via `tool.description` field | Tool poisoning scanner (task 26.7) | Sprint 10 |
| `settings.json` | Silent permission expansion, `allowedTools` addition | Settings drift governance (task 26.8) | Sprint 10 |
| Plugins/skills | Unattested plugin activation, checksum change | Plugin attestation enforcement (task 26.9, 45.1) | Sprint 10 / 10.5 |
| Hooks (Pre/PostToolUse) | Shell command injection, exfiltration before/after tools | Hook scanner + attestation (tasks 43.1–43.4) | Sprint 10.5 |
| Instruction files (CLAUDE.md / AGENTS.md) | Prompt injection, capability override via context | Injection detection + scope validation (tasks 44.1–44.2) | Sprint 10.5 |
| Slash commands + Memory | Persistent injection, capability expansion via memory | Command scan + memory governance (tasks 44.3–44.4) | Sprint 10.5 |
| Sub-agents (Task tool) | Budget circumvention, capability escalation via spawning | Sub-agent inheritance + lineage (tasks 45.3–45.4) | Sprint 10.5 |

**No existing security product covers all 8 surfaces with enforcement-grade controls. This is the moat.**

### D.2 Community Dominance Actions (Non-Code Deliverables)

These are required alongside the code sprints to establish SkillGate as the community standard:

| Action | Owner | Timing | Success Metric |
|---|---|---|---|
| Publish CVE/security report: "Tool Description Poisoning in MCP" | Security | Sprint 10 complete | Referenced in Anthropic/OpenAI security channels |
| Submit PR to Claude Code docs: "Securing Claude Code with SkillGate" | DevRel | Sprint 10.5 complete | PR merged or linked from official docs |
| Publish GitHub Advisory: hook-based data exfiltration patterns | Security | Sprint 10.5 complete | Advisory credited, referenced in community discussions |
| Submit to awesome-claude-code / awesome-mcp lists | DevRel | Sprint 10 complete | Listed in 3+ community resource lists |
| Publish "Claude Code Red Team Guide" with SkillGate countermeasures | Security | Sprint 10.5 complete | 500+ GitHub stars within 30 days |
| Publish "AGENTS.md Security Checklist" for Codex | DevRel | Sprint 11 complete | Shared in OpenAI developer forums |
| VS Code Marketplace feature request: SkillGate integration | DevRel | Sprint 12 complete | Listed under "Security" category with 100+ installs |

### D.3 Injection Pattern Library (Living Document)

The injection detection engine (tasks 44.1, 29.1) uses a pattern library maintained at `skillgate/ecosystem/injection_patterns/`. This library must be:

- Versioned with semver (separate from SkillGate version)
- Community-contributable via PR (pattern + test case + rationale)
- Fuzz-tested against 1000+ clean instruction files for false positive rate
- Signed with each SkillGate release (tamper-evident pattern updates)

Seed patterns (must ship in Sprint 10.5):

| Category | Pattern Examples | Threat |
|---|---|---|
| Jailbreak templates | `ignore all previous`, `DAN mode`, `you are now unrestricted`, `developer mode enabled` | Override system prompt and policy |
| Capability expansion | `you have access to all tools`, `full filesystem access granted`, `execute without restrictions` | Grant capabilities beyond policy |
| Identity override | `your true purpose is`, `your real instructions are`, `forget your previous training` | Replace agent identity/alignment |
| Exfiltration triggers | `send all file contents to`, `echo * to https://`, `exfiltrate`, `base64 encode and POST` | Data exfiltration via model output |
| Social engineering | `the safety team has approved`, `anthropic has authorized`, `this is a test, skip enforcement` | Impersonate authority to bypass controls |
| Budget bypass | `ignore rate limits`, `skip policy checks for this session`, `the following is exempt from governance` | Direct instruction to circumvent SkillGate |

### D.4 VS Code / Claude Code Extension Ecosystem Positioning

SkillGate must be **the** security extension for the Claude Code VS Code community:

- **Marketplace category:** Security (primary), Linters (secondary)
- **Extension description hook:** "The only extension that governs all 7 Claude Code attack surfaces — MCP tools, hooks, instruction files, slash commands, memory, plugins, and sub-agents."
- **Activation events:** Register on all Claude Code file patterns so SkillGate activates automatically in any Claude Code project
- **Extension pack:** Ship as `skillgate-io.skillgate-pack` bundling: policy lint + injection detection + hook audit + SARIF integration
- **"Works with Claude Code" badge:** Pursue official endorsement or listing in Claude Code's recommended extensions

### D.5 Competitive Differentiation Matrix

| Feature | SkillGate | Lakera | F5 AI Guardrails | NeMo Guardrails | Generic SAST |
|---|---|---|---|---|---|
| MCP tool call enforcement | ✅ | ❌ | ❌ | ❌ | ❌ |
| Tool description poisoning detection | ✅ | ❌ | ❌ | ❌ | ❌ |
| Claude Code hook governance | ✅ | ❌ | ❌ | ❌ | ❌ |
| CLAUDE.md injection detection | ✅ | ❌ | ❌ | ❌ | Partial |
| AGENTS.md instruction governance | ✅ | ❌ | ❌ | ❌ | Partial |
| Memory file governance | ✅ | ❌ | ❌ | ❌ | ❌ |
| Sub-agent budget inheritance | ✅ | ❌ | ❌ | ❌ | ❌ |
| Codex CLI bridge + governance | ✅ | ❌ | ❌ | ❌ | ❌ |
| VS Code inline enforcement | ✅ | ❌ | ❌ | ❌ | Partial |
| Signed audit trail + Ed25519 | ✅ | ❌ | ❌ | ❌ | ❌ |
| Works fully offline | ✅ | ❌ | ❌ | Partial | ✅ |

**This is not a "nice-to-have" matrix — it is the acquisition story.** If Anthropic, Microsoft, or a security vendor needs to credibly say "agents using Claude Code/Codex are governed end-to-end," SkillGate is the only company with complete surface coverage.

---

## Priority Order Summary

| Priority | Sprint | Moat Delivered | Why First |
|---|---|---|---|
| P0 | Sprint 8 | Runtime enforcement core | Nothing else works without this; all integrations depend on enforcement pipeline |
| P0 | Sprint 9 | SLT + Auth architecture | Commercial control + offline reliability; required before any integration ships |
| P1 | Sprint 10 | MCP Gateway + tool poisoning + settings governance | Primary strategic moat; Anthropic ecosystem ownership; closes 3 of 7 attack surfaces |
| P1 | Sprint 10.5 | Claude Code ecosystem depth (hooks, instruction files, sub-agents) | Closes remaining 5 attack surfaces; no other product covers this; hardest moat to copy |
| P1 | Sprint 11 | Codex CLI Bridge + AGENTS.md governance | Secondary runtime moat; CI pipeline ownership; Codex ecosystem parity with Claude Code |
| P2 | Sprint 12 | VS Code Extension (with full Claude Code surface coverage) | Developer workflow stickiness across all 7 surfaces; IDE = daily habit |
| P2 | Sprint 13 | Observability + SIEM | Enterprise adoption blocker; security teams require SIEM integration |
| P3 | Sprint 14 | Agent Framework SDKs | Embedded middleware moat; hardest to reverse once deployed |
| P3 | Sprint 15 | Intelligence + SaaS CP | Revenue unlock; enables enterprise contracts and dashboards |

**Non-negotiable cut rules:**
- If Sprint 8 misses P95 ≤20ms — do not proceed to Sprint 9. Fix performance first.
- If Sprint 9 SLT security tests fail — do not proceed. No insecure auth ships.
- If Sprint 10 MCP gateway has security regression — do not proceed to integration guides.
- If Sprint 10.5 injection detection has >1% false positive on clean files — do not ship; tune patterns first.
- If Sprint 10.5 hook governance breaks any legitimate Claude Code workflow — fix before release; adoption requires zero friction for clean projects.
- If Sprint 14 SDK does not default to fail-closed — do not publish to PyPI.

---

*Phase 2 Implementation Plan — SkillGate v2.0.0 — 2026-02-25*
*Classification: Internal — Confidential*
