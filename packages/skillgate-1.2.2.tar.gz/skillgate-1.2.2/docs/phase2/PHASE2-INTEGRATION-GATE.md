# Phase 2 Integration Gate

Use this audit to convert Sprint 10.5, 10.6, 11, 12, and 14 ship gates into CI-verifiable evidence.

## Command

```bash
./venv/bin/python scripts/quality/check_phase_ship_gates.py --phase phase2
```

## Outputs

- `docs/phase2/artifacts/phase2-ship-gate-audit-<YYYY-MM-DD>.json`
- `docs/phase2/artifacts/phase2-ship-gate-audit-<YYYY-MM-DD>.md`

## What it validates

- Runtime suites for each sprint gate.
- Integration artifacts for published templates and plugin/extension packaging metadata.
- Sprint 10.5 explicit false-positive KPI test (`<1%`) for instruction injection scanning.

## Useful flags

- `--sprint 10.5 --sprint 11` to scope a run.
- `--skip-runtime` for evidence-only validation.
- `--phase <name>` to run future phase contracts once added to `docs/quality/ship-gate-contract.json`.
