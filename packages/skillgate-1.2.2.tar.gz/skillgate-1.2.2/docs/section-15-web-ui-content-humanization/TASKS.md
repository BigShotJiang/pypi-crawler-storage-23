# Section 15 Tasks

| Task | Name | Priority | Status | Notes |
|---|---|---|---|---|
| 15.1 | Humanize pricing copy and FAQ | P0 | Complete | `web-ui/src/app/pricing/page.tsx`, `web-ui/src/components/sections/PricingSection.tsx`, `web-ui/src/lib/pricing.ts` |
| 15.2 | Rewrite docs hub and docs top summaries | P0 | Complete | `web-ui/src/app/docs/**/page.tsx`, `web-ui/src/lib/docs-nav.ts` |
| 15.3 | Improve core marketing section tone | P0 | Complete | `Hero`, `Features`, `CTA`, `SocialProof`, footer tagline |
| 15.4 | Conversion-copy QA (CTA + claim-to-proof) | P0 | Complete | Artifact recorded in Section 15 artifacts folder |
