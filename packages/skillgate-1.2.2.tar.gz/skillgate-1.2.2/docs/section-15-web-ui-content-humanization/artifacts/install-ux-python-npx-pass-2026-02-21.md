# Install UX Humanization Pass (Python + NPX)

Date: 2026-02-21

## Scope

- Modernized docs install UX to clearly support both:
  - Python canonical runtime (`pipx` / `pip`)
  - NPX/npm wrapper path (`@skillgate-io/cli`)
- Reduced ambiguity between install, verify, upgrade, uninstall, and first enforced run commands.

## Updated Files

- `web-ui/src/components/docs/InstallWizard.tsx`
- `web-ui/src/components/docs/InstallWizard.test.tsx`
- `web-ui/src/app/docs/get-started/page.tsx`
- `web-ui/src/app/docs/page.tsx`

## Before -> After Highlights

1. Install wizard now surfaces explicit path choice:
- Before: Generic platform/channel selector without strategic framing.
- After: Clear dual-path cards (Python recommended vs NPX wrapper), channel context, and path safety notes.

2. Command coverage became lifecycle-complete:
- Before: Install + verify only.
- After: Install + verify + upgrade + uninstall + first enforced run command.

3. NPX onboarding is now explicit:
- Before: npm wrapper existed but was not clearly positioned in docs UX.
- After: NPX-first run command and wrapper guidance are visible in wizard and docs.

4. Docs hub and get-started copy aligned to moat positioning:
- Before: Python-centric quick-start copy.
- After: Dual-path onboarding with governance-first language and clearer conversion flow.

## Validation

- `cd web-ui && npm run test -- src/components/docs/InstallWizard.test.tsx`
- `cd web-ui && npm run type-check`
- `cd web-ui && npm run lint`

All passed.
