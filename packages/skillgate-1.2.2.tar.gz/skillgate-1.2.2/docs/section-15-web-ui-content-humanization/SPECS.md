# Section 15 Specs

## Objectives

1. Humanized copy:
- Remove inflated or generic AI-marketing language.
- Prefer direct statements and concrete outcomes.

2. Conversion clarity:
- CTAs should map to a real next action (`start`, `scan`, `docs`, `contact`).
- Avoid vague CTA labels where intent is ambiguous.

3. Moat clarity:
- Keep positioning tied to enforceable controls.
- Keep evidence claims tied to signed artifacts and deterministic outcomes.

## Non-goals

- No pricing model changes.
- No information architecture changes.
- No visual redesign.
