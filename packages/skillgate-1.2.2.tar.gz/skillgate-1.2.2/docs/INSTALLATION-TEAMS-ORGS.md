# SkillGate Installation For Teams And Organizations

## Goal

Deploy a deterministic, policy-governed install and upgrade path across developer and CI environments.

## Standardization Contract

1. Choose one primary channel per environment (`pipx` recommended).
2. Pin rollout versions for CI and critical repositories.
3. Validate installation with `skillgate version` in bootstrap scripts.
4. Enforce policy and signed-report generation in CI entry workflows.

## Team Bootstrap (Recommended)

```bash
pipx install skillgate=={version}
skillgate version
skillgate scan . --enforce --policy production --sign --report-file skillgate-report.json
```

## Governance Controls

- Keep `docs/install-spec.json` as install command source-of-truth.
- Run freshness checks in CI (`python scripts/quality/check_install_docs_freshness.py`).
- Require launch checklist sign-off before installer/docs rollout.

## Upgrade Strategy

- Promote versions in stages: sandbox -> non-critical repos -> critical repos.
- Keep rollback command prepared for each channel.

## Rollback Strategy

- `pipx`: `pipx install skillgate=={version}`
- `pypi`: `python -m pip install --upgrade skillgate=={version}`
- `homebrew`: `brew install skillgate@{version}`
- `winget`: `winget install SkillGate.SkillGate --version {version}`
- `npm_shim`: `npm install -g @skillgate-io/cli@{version}`
- `npm_shim` source package: `npm-shim/` (wrapper-only, Python runtime required)

## Security Notes

- Keep API/signing keys in secure env/secret stores.
- Keep outbound egress scoped by policy and environment.
- Prefer offline modes in no-egress compliance environments.
