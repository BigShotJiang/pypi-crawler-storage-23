# Explainer Provider Migration and Operator Guide

## Purpose

This guide defines migration from the legacy explanation backend flag to the new
intent-first contract and documents enterprise-safe provider controls.

## CLI Migration

### New flags (primary)

- `--explain`
- `--explain-mode technical|executive`
- `--explain-source auto|offline|ai`
- `--llm-provider openai|anthropic|custom`

### Deprecated flag (compatibility)

- `--explain-backend` remains supported as a deprecated alias for one major release.
- The alias emits a warning and should be replaced by `--explain-source` and
  `--llm-provider`.
- Do not combine `--explain-backend` with `--explain-source` or `--llm-provider`.

### Migration mapping

| Old usage | New usage |
|---|---|
| `--explain --explain-backend template` | `--explain --explain-source offline` |
| `--explain --explain-backend openai` | `--explain --explain-source ai --llm-provider openai` |
| `--explain --explain-backend anthropic` | `--explain --explain-source ai --llm-provider anthropic` |

## Provider Configuration (Enterprise)

### Egress policy contract

- Egress is default-deny for explanation providers.
- Enable provider egress explicitly with `SKILLGATE_EXPLAIN_EGRESS=1`.
- Restrict outbound hosts with `SKILLGATE_EXPLAIN_ENDPOINT_ALLOWLIST`.
- If egress or endpoint checks fail, explanations fall back to deterministic
  templates without failing scan execution.

### Provider env configuration

#### OpenAI (hosted)

- `OPENAI_API_KEY`
- Optional endpoint override: `OPENAI_BASE_URL`

#### Anthropic (hosted)

- `ANTHROPIC_API_KEY`
- Optional endpoint override: `ANTHROPIC_BASE_URL`

#### Custom providers

Common:

- `SKILLGATE_EXPLAIN_CUSTOM_PROVIDER=azure-openai|groq|ollama`
- `SKILLGATE_EXPLAIN_CUSTOM_BASE_URL=<provider-endpoint>`
- Optional timeout control: `SKILLGATE_EXPLAIN_PROVIDER_TIMEOUT_S`
- Optional retry control: `SKILLGATE_EXPLAIN_PROVIDER_RETRIES`

Azure OpenAI:

- `AZURE_OPENAI_API_KEY`
- `SKILLGATE_EXPLAIN_CUSTOM_DEPLOYMENT`
- Optional `SKILLGATE_EXPLAIN_AZURE_API_VERSION`

Groq:

- `GROQ_API_KEY`
- Optional `SKILLGATE_EXPLAIN_CUSTOM_MODEL`

Ollama:

- Optional `SKILLGATE_EXPLAIN_CUSTOM_MODEL`

## Operator Rollout Sequence

1. Migrate automation/scripts from `--explain-backend` to new flags.
2. Keep alias support enabled during one major-release migration window.
3. Turn on controlled egress with explicit allowlist hosts only.
4. Validate template fallback behavior under denied-egress and timeout scenarios.
5. Remove alias usage in repos before alias removal release.

## Example Commands

Offline deterministic explanations:

```bash
skillgate scan ./skill --explain --explain-source offline
```

Hosted provider (OpenAI):

```bash
SKILLGATE_EXPLAIN_EGRESS=1 \
SKILLGATE_EXPLAIN_ENDPOINT_ALLOWLIST=api.openai.com \
OPENAI_API_KEY=... \
skillgate scan ./skill --explain --explain-source ai --llm-provider openai
```

Custom provider (Groq):

```bash
SKILLGATE_EXPLAIN_EGRESS=1 \
SKILLGATE_EXPLAIN_ENDPOINT_ALLOWLIST=api.groq.com \
SKILLGATE_EXPLAIN_CUSTOM_PROVIDER=groq \
SKILLGATE_EXPLAIN_CUSTOM_BASE_URL=https://api.groq.com \
GROQ_API_KEY=... \
skillgate scan ./skill --explain --explain-source ai --llm-provider custom
```

## Rollback

If migration causes runtime issues:

1. Switch to `--explain-source offline` for deterministic template output.
2. Temporarily disable provider egress by unsetting `SKILLGATE_EXPLAIN_EGRESS`.
3. Remove custom provider env vars and return to hosted provider defaults.
4. As a compatibility fallback during migration window, use `--explain-backend`.

## Security Notes

- Keep API keys in secure env storage; never commit secrets.
- Keep allowlist scope minimal per environment.
- Prefer `offline` mode in strict/no-egress CI pipelines.
