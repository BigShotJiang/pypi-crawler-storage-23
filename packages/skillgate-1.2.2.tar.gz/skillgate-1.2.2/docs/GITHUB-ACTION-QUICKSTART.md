# GitHub Action Quickstart (Proof-Pack First)

## Goal

Get to a first governed proof in one workflow run:

`scan -> policy decision -> signed proof artifact`

## 1) Add workflow

```yaml
name: skillgate
on:
  pull_request:

jobs:
  gate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with:
          python-version: "3.12"
      - run: pip install skillgate
      - run: skillgate scan . --output json --enforce --policy production --sign --report-file skillgate-report.json
      - uses: actions/upload-artifact@v4
        with:
          name: skillgate-proof-pack
          path: skillgate-report.json
```

## 2) Verify artifact

Download `skillgate-report.json` and verify locally:

```bash
skillgate verify skillgate-report.json
```

## 3) Deterministic fallback mode

For strict/no-egress environments, keep explanations offline:

```bash
skillgate scan . --explain --explain-source offline --output json --report-file skillgate-report.json
```

## 4) Adoption KPI hook

Track these weekly for adoption health:

- workflow runs
- proof-pack artifact uploads
- enforce-mode pass/fail ratio
