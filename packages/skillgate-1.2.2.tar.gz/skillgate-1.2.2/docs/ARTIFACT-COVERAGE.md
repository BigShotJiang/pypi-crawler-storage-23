# SkillGate Artifact Coverage

**Version:** 1.0.0  
**Last Updated:** 2026-02-18

## Overview

This guide documents SkillGate coverage for non-source artifacts and how provenance is enforced in policy and reports.

## Coverage Matrix

| Artifact Origin | Examples | Current Support |
|---|---|---|
| `code` | `.py`, `.ts`, `.sh` | Full |
| `markdown_prose` | `README.md` narrative text | Full |
| `markdown_codeblock` | fenced snippets in markdown | Full |
| `config` | `.json`, `.yaml`, `.toml`, `.env` | Full |
| `document_text` | `.pdf`, `.docx` extracted text | Full |
| `archive_member` | files inside `.zip` | Full (bounded traversal) |

## Provenance Contract

All findings carry provenance fields:

- `origin_type`
- source location (`file`, `line`)
- optional section/page metadata for document extraction

This provenance is included in JSON and SARIF outputs and part of the signing scope.

## Policy by Origin

Use `artifact_origins` in `skillgate.yml` to control enforcement:

```yaml
version: "1"
preset: production
artifact_origins:
  document_text:
    enabled: true
    severity_floor: medium
  archive_member:
    enabled: true
    severity_floor: high
```

## Operational Limits

- Extraction budget and archive depth are bounded.
- Files above configured size limits are skipped with warnings.
- Unicode normalization and confusable folding are applied before scanning.

## References

- `docs/sprint-7.2-runbook.md`
- `docs/POLICY-REFERENCE.md`
- `docs/RULE-CATALOG.md`
