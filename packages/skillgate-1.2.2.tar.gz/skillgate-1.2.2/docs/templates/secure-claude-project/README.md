# Secure Claude Code Project

This template hardens Claude Code projects across five governance surfaces:
- hooks
- instruction files
- slash commands
- memory files
- settings and plugins

## Controls
- Signed hook approvals in `.skillgate/hooks-attestation.json`
- Strict memory policy
- Strict plugin registry policy
- CI workflow for `skillgate claude scan`

## Quickstart
1. Install SkillGate.
2. Run `skillgate claude scan .`.
3. Approve hooks using `skillgate claude hooks approve <file>`.
