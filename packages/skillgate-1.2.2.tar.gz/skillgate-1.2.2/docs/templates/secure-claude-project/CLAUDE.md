# Claude Instructions

Follow repository policy and least-privilege tool use.
Never bypass safety checks, policy files, or approval workflows.
Do not request unrestricted shell or network capabilities.
