# Task Registry, DoD, and Delivery Order

## Status Board (Section 16)

| Task | Name | Priority | Status | Owner | Notes |
|---|---|---|---|---|---|
| 17.165 | Freeze public/private boundary matrix | P0 | Complete | TBD | Boundary matrix + policy lock updated (`docs/open-core/PUBLIC_PRIVATE_MATRIX_v1.md`, `docs/open-core/public-export-policy.json`) |
| 17.166 | Enforce public export CI gate | P0 | Complete | TBD | CI job wired + strict pass + negative fixture proof artifacts |
| 17.167 | Dual-repo release contract | P0 | Complete | TBD | Release contract JSON + validator + CI gate + rollback sequence checks shipped |
| 17.168 | Netlify + Railway cutover contract | P0 | Complete | TBD | Env-contract, smoke rehearsal, rollback rehearsal artifacts captured |
| 17.169 | CI parity matrix post-split | P0 | Complete | TBD | Parity matrix + validator + CI job evidence captured |
| 17.170 | Legal and policy hardening | P0 | Complete | TBD | Terms/privacy/security/DPA anti-abuse and enforcement language shipped |
| 17.171 | Deployment profile lock | P1 | Complete | TBD | Domain/callback/CORS profile lock JSON + validator shipped |
| 17.172 | Split readiness report and GO artifact | P0 | Complete | TBD | Signed split readiness manifest + verification + GO decision recorded |

## Definition of Done (Per Task)

A task can be marked `Complete` only if all are true:

1. Scope implemented exactly as `SPECS.md`.
2. Required tests pass in CI and local reproduction.
3. Evidence artifacts generated and linked.
4. Backward compatibility impact documented.
5. Rollback/recovery path documented.
6. Security and policy invariants validated.

## Execution Order

1. `17.165`, `17.166`, `17.170` (boundary + enforcement + legal baseline)
2. `17.168`, `17.171` (deployment cutover + profile lock)
3. `17.167`, `17.169` (release ordering + CI parity)
4. `17.172` (final GO/NO-GO adjudication)

## Per-Task Completion Ledger (Mandatory Before `Complete`)

Legend: `Y` = satisfied and linked, `N` = not yet satisfied.

| Task | Spec match | CI + local tests | Evidence links | Backward compatibility note | Rollback/recovery note | Security/policy invariant validation | Status |
|---|---|---|---|---|---|---|---|
| 17.165 | Y | Y | Y | Y | Y | Y | Complete |
| 17.166 | Y | Y | Y | Y | Y | Y | Complete |
| 17.167 | Y | Y | Y | Y | Y | Y | Complete |
| 17.168 | Y | Y | Y | Y | Y | Y | Complete |
| 17.169 | Y | Y | Y | Y | Y | Y | Complete |
| 17.170 | Y | Y | Y | Y | Y | Y | Complete |
| 17.171 | Y | Y | Y | Y | Y | Y | Complete |
| 17.172 | Y | Y | Y | Y | Y | Y | Complete |
