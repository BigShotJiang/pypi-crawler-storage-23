# Section 16 Execution Pack: Open-Core Split + Deployment Cutover Governance

## Purpose

This folder is the mandatory execution contract for Section 15 in
`/Users/spy/Documents/PY/AI/skillgate/docs/IMPLEMENTATION-PLAN.md`.

It exists to make repo-split and deployment cutover decisions test-enforced,
reversible, and enterprise-auditable.

## Scope

- Defines public/private boundaries for code, docs, workflows, and artifacts.
- Defines strict CI export enforcement for public release paths.
- Defines deterministic release and rollback contract across CE/EE/web-ui/npm shim.
- Defines cutover governance for Railway (api/worker) and Netlify (web-ui).
- Defines legal posture hardening requirements for anti-abuse/anti-circumvention.

## Completion Promise (Mandatory)

No task is `Complete` unless:

1. Scope is implemented as specified.
2. Required tests and gates pass in CI and local reproduction.
3. Evidence artifacts exist and are linked in task records.
4. Backward-compatibility, rollback, and incident-response notes are recorded.

Any missing item means status cannot exceed `Ready for Gate`.

## Document Map

- `BOUNDARIES.md` - public/private scope, non-goals, and fail-closed constraints.
- `SPECS.md` - technical implementation specs for 17.165-17.172.
- `TASKS.md` - task board, DoD, and evidence ledger.
- `READINESS-GATES.md` - hard GO/NO-GO production criteria.
- `VALIDATION-CHECKS.md` - exact commands and artifact checks.
- `PER-TASK-RECORDS.md` - execution evidence per task.
- `RELEASE-DECISION.md` - signed GO/NO-GO decision record.
- `AGENT-SKILLS-MANDATORY.md` - required skills and sequencing.

## Status Model

- `Not Started`
- `In Progress`
- `Blocked`
- `Ready for Gate`
- `Complete`

`Complete` is allowed only when all checks in `READINESS-GATES.md` pass.
