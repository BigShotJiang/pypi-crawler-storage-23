API smoke passed
Web smoke passed
Smoke checks passed for profile=staging
