# Physical Extraction Run (2026-02-21)

## Scope

- Workflow: `scripts/release/run_physical_extraction.py`
- Public output dir: `/tmp/skillgate-public-ce-2026-02-21`
- Policy: `docs/open-core/public-export-policy.json`

## Result

- Public CE files exported: **208**
- Private EE inventory files detected: **36**
- Denied files in public export scope: **0** (fail-closed check passed)

## Artifacts

- `public-ce-manifest-2026-02-21.json`
- `private-ee-manifest-2026-02-21.json`

## Next (Section 16 continuation)

1. Initialize dedicated CE repo from `/tmp/skillgate-public-ce-2026-02-21`.
2. Initialize dedicated EE repo and backfill private inventory paths.
3. Apply dual-repo release contract sequencing (`17.167`).
