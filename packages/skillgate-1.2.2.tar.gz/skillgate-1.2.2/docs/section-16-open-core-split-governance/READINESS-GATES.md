# Readiness Gates (Hard GO/NO-GO)

## Feature Gates

1. Boundary gate: no ambiguous path ownership in public/private matrix.
2. Export gate: strict public export check passes in CI and local reproduction.
3. Legal gate: required anti-abuse and anti-circumvention clauses are present.
4. Cutover gate: Railway/Netlify cutover checklist has passing rehearsal evidence.

## Release Gates

1. CI parity matrix proves no critical gate loss after split.
2. Deployment profile lock verifies production domain/callback/CORS controls.
3. Split readiness report is complete with owner sign-off and rollback ownership.

## Fail-Closed Rule

If any gate fails, release status is `NO-GO` and feature expansion is frozen.
