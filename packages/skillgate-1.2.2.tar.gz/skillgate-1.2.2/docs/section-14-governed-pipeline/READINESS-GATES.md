# Readiness Gates (Production)

## Gate A: Contract Integrity

- `FindingV1` schema enforced across all producers.
- `risk_model_version` present in scoring outputs.
- JSON and SARIF outputs remain contract-stable.

## Gate B: Governance Enforcement

- Policy checks run at all required boundaries.
- Approval-required actions fail closed without valid signatures.
- No write-path bypass exists for guarded operations.

## Gate C: Evidence and Auditability

- Proof pack export verifies offline.
- Tampering any artifact fails verification.
- Audit records include who/what/when/outcome and hashes.

## Gate D: Reliability and Determinism

- FN/FP/performance evidence generated per release build.
- Deterministic replay of score + decision path is reproducible.
- Existing reliability CI gates remain green.

## Gate E: Scope Control

- Scope-freeze gate blocks deferred P2 features.
- Deferred tasks remain out of release branch.

## Gate F: Claim Validity

- Public claims map to enforceable implementation.
- Claim ledger and tests stay green.

## Release Decision

- `GO`: all gates A–F are green.
- `NO-GO`: any gate red.

No partial GO for Section 14 production claims.
