# Ralph Loop (Mandatory Execution Loop)

## Purpose

Ralph Loop is the required fail-closed loop for every Section 14 task.
No shortcut path is allowed.

## Loop Stages

1. **R0: Requirement Lock**
- Confirm exact task scope and non-goals.
- Link to spec section and acceptance criteria.

2. **R1: Attack Surface + Invariants**
- Identify security invariants and bypass risks.
- Define what must never regress.

3. **R2: Lean Implementation**
- Implement minimum code to satisfy the task.
- No optional features.

4. **R3: Local Validation**
- Run required unit/integration checks.
- Fix deterministic failures immediately.

5. **R4: Adversarial Validation**
- Run negative-path/security tests.
- Attempt bypass scenarios for policy/approval gates.

6. **R5: Evidence Assembly**
- Produce artifacts: test results, proof pack samples, decision logs.
- Record reproducibility metadata.

7. **R6: Readiness Gate Review**
- Apply `READINESS-GATES.md`.
- If any gate fails, status returns to R1 or R2.

8. **R7: Ship Decision**
- Mark `Complete` only when all gates are green.
- Otherwise mark `Blocked` or `In Progress` with reasons.

## Exit Rule

No task exits Ralph Loop at R7 without evidence links and passing gates.

## Escalation Rule

If a task fails R6 twice:

1. Freeze downstream tasks.
2. Open defect root-cause note.
3. Re-scope to smaller safe increment.
