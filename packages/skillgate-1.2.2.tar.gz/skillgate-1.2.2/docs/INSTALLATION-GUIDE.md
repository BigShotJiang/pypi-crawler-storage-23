# SkillGate Installation Guide

**Version:** 1.0.0  
**Last Updated:** 2026-02-21  
**Install Source of Truth:** `docs/install-spec.json`

## Install Strategy Matrix

| Channel | Tier | Platforms | Notes |
|---|---|---|---|
| `pipx` | GA (canonical) | macOS, Linux, Windows, WSL | Preferred for most users |
| `pypi` | GA | macOS, Linux, Windows, WSL | Direct Python package install |
| `homebrew` | Beta | macOS | Native macOS package manager path |
| `winget` | Beta | Windows | Native Windows package manager path |
| `npm_shim` | Experimental | macOS, Linux, Windows, WSL | Wrapper only, not canonical runtime |

## For Individuals

### pipx (canonical)

Install:

```bash
pipx install skillgate
```

Verify:

```bash
skillgate version
```

Minimum runtime config:

```bash
export SKILLGATE_API_KEY="sg_free_or_paid_key_here"
```

Uninstall:

```bash
pipx uninstall skillgate
```

### pypi

Install:

```bash
python -m pip install --upgrade skillgate
```

Verify:

```bash
skillgate version
```

Minimum runtime config:

```bash
export SKILLGATE_API_KEY="sg_free_or_paid_key_here"
```

Uninstall:

```bash
python -m pip uninstall -y skillgate
```

### homebrew (macOS)

Install:

```bash
brew install skillgate
```

Verify:

```bash
skillgate version
```

Uninstall:

```bash
brew uninstall skillgate
```

### winget (Windows)

Install:

```powershell
winget install SkillGate.SkillGate
```

Verify:

```powershell
skillgate version
```

Uninstall:

```powershell
winget uninstall SkillGate.SkillGate
```

### npm shim (experimental)

Install:

```bash
npm install -g @skillgate-io/cli
```

Prerequisite (required): install Python `skillgate` runtime first:

```bash
pipx install skillgate
# or: python -m pip install --upgrade skillgate
```

Quick run without global install:

```bash
npx @skillgate-io/cli version
```

Verify:

```bash
skillgate version
```

Uninstall:

```bash
npm uninstall -g @skillgate-io/cli
```

Implementation note:
- Wrapper package lives in `npm-shim/` and delegates to Python runtime (`python -m skillgate`).

Minimum runtime config:

```bash
export SKILLGATE_API_KEY="sg_free_or_paid_key_here"
```

## For Teams and Organizations

1. Standardize one install channel per environment (`pipx` recommended).
2. Pin versions in CI for reproducibility.
3. Validate installs with `skillgate version` in bootstrap scripts.
4. Keep rollback commands documented per channel:

- `pipx`: `pipx install skillgate=={version}`
- `pypi`: `python -m pip install --upgrade skillgate=={version}`
- `homebrew`: `brew install skillgate@{version}`
- `winget`: `winget install SkillGate.SkillGate --version {version}`
- `npm_shim`: `npm install -g @skillgate-io/cli@{version}`

## Version Targets

- `latest`: newest available release from channel.
- `stable`: current stable release from channel (falls back to `latest` if a
  separate stable channel version is not published).
- `pinned`: explicit version (`{version}`) for deterministic rollout.

## Upgrade and Rollback Quick Commands

Upgrade:

- `pipx upgrade skillgate`
- `python -m pip install --upgrade skillgate`
- `brew upgrade skillgate`
- `winget upgrade SkillGate.SkillGate`
- `npm install -g @skillgate-io/cli@latest`

Rollback (pin a known-good version):

- `pipx install skillgate=={version}`
- `python -m pip install --upgrade skillgate=={version}`
- `brew install skillgate@{version}`
- `winget install SkillGate.SkillGate --version {version}`
- `npm install -g @skillgate-io/cli@{version}`

## Rollback Safety Notes

- `pipx`: verify pinned version is still available on package index before rollout.
- `pypi`: use internal wheel cache or mirror for deterministic rollback in CI.
- `homebrew`: ensure formula/tag exists for pinned target before switching.
- `winget`: validate package version availability in repository before change window.
- `npm_shim`: confirm wrapper version still resolves to compatible Python runtime.
