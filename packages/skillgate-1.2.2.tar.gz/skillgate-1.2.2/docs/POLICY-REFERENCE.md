# SkillGate Policy Reference

**Version:** 1.1.0  
**Last Updated:** 2026-02-18

Complete reference for SkillGate policy configuration, presets, evaluation rules, and enforcement modes.

---

## Table of Contents

1. [Overview](#overview)
2. [Policy Schema](#policy-schema)
3. [Built-in Presets](#built-in-presets)
4. [Thresholds Configuration](#thresholds-configuration)
5. [Permissions Configuration](#permissions-configuration)
6. [Rule Configuration](#rule-configuration)
7. [Enforcement Configuration](#enforcement-configuration)
8. [Confidence Configuration](#confidence-configuration)
9. [Policy Resolution Order](#policy-resolution-order)
10. [Policy Evaluation Logic](#policy-evaluation-logic)
11. [Creating Custom Policies](#creating-custom-policies)
12. [Examples](#examples)

---

## Overview

SkillGate policies define security gates for agent skills. Each policy specifies:

- **Risk thresholds** — maximum acceptable risk score and finding counts
- **Permissions** — which behaviors are allowed (shell, eval, network, filesystem)
- **Rule overrides** — severity/weight customization and rule disabling
- **Enforcement mode** — enforce (block) or warn (report only)
- **Confidence filtering** — downgrade low-confidence findings to warnings

All policies follow a YAML schema (version `"1"`). Policies are evaluated deterministically — no probabilistic components.

---

## Policy Schema

### Top-Level Fields

```yaml
version: "1"                     # Required — schema version
name: "production"               # Required — policy name
description: "..."               # Optional — human-readable description
thresholds: {...}                # Risk score and finding count limits
permissions: {...}               # Allowed behaviors
rules: {...}                     # Rule overrides and disabling
enforcement: {...}               # Enforcement mode (enforce/warn)
confidence: {...}                # Confidence-aware filtering
```

**Field Validation:**
- `version` must be exactly `"1"`
- `name` must be non-empty, max 64 characters
- All nested objects use default values if omitted

---

## Built-in Presets

SkillGate provides 5 built-in presets optimized for different environments:

### 1. `development` — Permissive, Warn-Only

**Use case:** Local development with maximum flexibility.

```yaml
version: "1"
name: "development"
description: "Permissive policy for development — warnings only."
thresholds:
  max_score: 100
  max_critical_findings: 5
  max_high_findings: 10
  max_medium_findings: 50
permissions:
  allow_shell: true
  allow_eval: true
  allow_network: true
  allow_filesystem_write: true
  allow_credential_access: true
enforcement:
  mode: "warn"
  fail_on_error: false
```

**Exit behavior:** Always exits 0, even with violations.

---

### 2. `staging` — Moderate Enforcement

**Use case:** Pre-production testing with balanced restrictions.

```yaml
thresholds:
  max_score: 70
  max_critical_findings: 0
  max_high_findings: 5
  max_medium_findings: 20
permissions:
  allow_shell: false
  allow_eval: false
  allow_network: true
  allow_filesystem_write: false
  allow_credential_access: true
enforcement:
  mode: "enforce"
```

**Exit behavior:** Exits 1 on policy violation.

---

### 3. `production` — Strict Enforcement (Default)

**Use case:** Production deployments with strong security gates.

```yaml
thresholds:
  max_score: 50
  max_critical_findings: 0
  max_high_findings: 2
  max_medium_findings: 10
permissions:
  allow_shell: false
  allow_eval: false
  allow_network: true
  allow_filesystem_write: false
  allow_credential_access: true
enforcement:
  mode: "enforce"
```

**Exit behavior:** Exits 1 on policy violation.

---

### 4. `strict` — Maximum Restriction

**Use case:** High-security environments, zero-tolerance for risk.

```yaml
thresholds:
  max_score: 30
  max_critical_findings: 0
  max_high_findings: 0
  max_medium_findings: 5
permissions:
  allow_shell: false
  allow_eval: false
  allow_network: false              # No network access
  allow_filesystem_write: false
  allow_credential_access: true
enforcement:
  mode: "enforce"
```

---

### 5. `agent-output` — AI-Generated Code Gating

**Use case:** Scanning output from Claude, Codex, Copilot, Devin, and other AI agents.

```yaml
thresholds:
  max_score: 20
  max_critical_findings: 0
  max_high_findings: 0
  max_medium_findings: 3
permissions:
  allow_shell: false
  allow_eval: false
  allow_network: false
  allow_filesystem_write: false
  allow_credential_access: false    # Zero credential access
enforcement:
  mode: "enforce"
```

**Key difference:** Blocks **all** risky patterns — tuned for AI code review.

---

## Thresholds Configuration

Defines maximum acceptable risk levels.

```yaml
thresholds:
  max_score: 60                    # Total risk score ceiling (0-200)
  max_critical_findings: 0         # Number of critical-severity findings
  max_high_findings: 2             # Number of high-severity findings
  max_medium_findings: 10          # Number of medium-severity findings
```

**Validation:**
- All values must be `>= 0`
- `max_score` capped at 200
- Low-severity findings have no threshold (unlimited)

**Evaluation:**
- If any threshold is exceeded, policy fails
- Multiple violations reported simultaneously

---

## Permissions Configuration

Controls which categories of behavior are allowed.

```yaml
permissions:
  allow_shell: false                 # Shell command execution
  allow_eval: false                  # Dynamic code evaluation
  allow_network: true                # HTTP/socket network access
  allow_filesystem_write: false      # File write/delete operations
  allow_credential_access: true      # Environment variable/secret access
  
  # Domain restrictions (optional)
  allowed_domains:                   # Whitelist mode (if non-empty)
    - "api.openai.com"
    - "*.anthropic.com"
  blocked_domains:                   # Blacklist (always checked)
    - "evil.com"
    - "*.sketchy.net"
  
  # Path restrictions (optional)
  allowed_paths:                     # Filesystem path whitelist
    - "/tmp/skillgate/*"
    - "./output/*"
```

**Permission-to-Category Mapping:**

| Permission | Blocks Category | Example Rules |
|------------|----------------|---------------|
| `allow_shell` | `SHELL` | SG-SHELL-001 (subprocess), SG-SHELL-004 (shell=True) |
| `allow_eval` | `EVAL` | SG-EVAL-001 (eval), SG-EVAL-003 (exec) |
| `allow_network` | `NETWORK` | SG-NET-001 (HTTP), SG-NET-002 (sockets) |
| `allow_filesystem_write` | `FILESYSTEM` | SG-FS-001 (file write) |
| `allow_credential_access` | `CREDENTIAL` | SG-CRED-001 (env vars), SG-CRED-002 (secrets) |

**Domain Matching:**
- Uses `fnmatch` patterns: `*` = wildcard, `?` = single char
- Extracts domains from HTTP URLs in code snippets
- Whitelist (`allowed_domains`) = only listed domains allowed (if non-empty)
- Blacklist (`blocked_domains`) = listed domains rejected (always checked)

**Path Matching:**
- Currently reserved for future filesystem path validation
- Not enforced in v1.1.0

---

## Rule Configuration

Override rule behavior or disable rules entirely.

```yaml
rules:
  disabled:                          # Rules to skip entirely
    - "SG-SHELL-001"
    - "SG-EVAL-002"
  
  severity_overrides:                # Custom severity levels
    "SG-NET-001": "high"             # Upgrade HTTP requests to high
    "SG-CRED-001": "low"             # Downgrade env var access to low
  
  weight_overrides:                  # Custom risk weights (0-100)
    "SG-SHELL-004": 60               # Increase shell=True weight
    "SG-OBF-001": 10                 # Decrease obfuscation weight
  
  custom_paths: []                   # Reserved for custom rule directories
```

**Validation:**
- `disabled`: List of rule IDs
- `severity_overrides`: Dict of `{rule_id: "low|medium|high|critical"}`
- `weight_overrides`: Dict of `{rule_id: integer}`
- Severity values are case-insensitive

**Effect:**
- Disabled rules are **excluded** from findings before policy evaluation
- Overrides apply **before** scoring and policy checks
- Use overrides to tune policies without forking presets

---

## Enforcement Configuration

Controls how violations are handled.

```yaml
enforcement:
  mode: "enforce"                    # "enforce" or "warn"
  fail_on_error: true                # Exit 2 on internal errors
```

**Modes:**

| Mode | Behavior | Exit Code on Violation |
|------|----------|------------------------|
| `enforce` | Block on violations | 1 |
| `warn` | Report violations but pass | 0 |

**`fail_on_error`:**
- `true` → Internal errors (parse failures, I/O errors) exit with code 2
- `false` → Internal errors logged but exit 0

**Use Cases:**
- `enforce` + `fail_on_error=true` → Production CI (default)
- `warn` + `fail_on_error=false` → Development feedback loops

---

## Confidence Configuration

**Added in Sprint 7.0** — Filter findings based on detection confidence.

```yaml
confidence:
  min_confidence_to_block: 0.7       # Global minimum (0.0-1.0)
  critical_min_confidence: 0.9       # Critical-severity minimum
  high_min_confidence: 0.8           # High-severity minimum
  medium_min_confidence: 0.6         # Medium-severity minimum
  low_min_confidence: 0.0            # Low-severity minimum (disabled)
```

**Defaults:** All values default to `0.0` (disabled) for backward compatibility.

**Behavior:**
- Findings with `confidence < threshold` are **downgraded** to warnings
- Warnings do not fail the policy (logged only)
- Per-severity thresholds override the global minimum
- If per-severity is `0.0`, uses `min_confidence_to_block`

**Example:**
```yaml
confidence:
  min_confidence_to_block: 0.7
  critical_min_confidence: 0.95      # Critical findings need 95% confidence
```

**Finding with confidence 0.85:**
- Severity: `CRITICAL`
- Threshold: `0.95`
- Result: Downgraded to **warning** (0.85 < 0.95), does not block

---

## Policy Resolution Order

Policies are resolved in this order (later overrides earlier):

1. **Built-in defaults** — `production` preset
2. **Preset** — if `--policy` matches a preset name
3. **Project file** — if `--policy` is a file path (e.g., `./skillgate.yml`)
4. **CLI flags** — highest priority (handled by CLI)

**Examples:**

```bash
# Uses production preset (default)
skillgate scan ./skill

# Uses staging preset
skillgate scan --policy staging ./skill

# Uses custom file
skillgate scan --policy ./custom-policy.yml ./skill

# Preset + CLI overrides
skillgate scan --policy strict --enforce ./skill
```

**CLI Flag Overrides:**
- `--enforce` → Sets `enforcement.mode = "enforce"`
- `--no-enforce` → Sets `enforcement.mode = "warn"`

---

## Policy Evaluation Logic

SkillGate evaluates policies in this order:

### 1. Score Threshold Check

```python
if risk_score.total > policy.thresholds.max_score:
    violation = "Risk score {total} exceeds maximum {max_score}"
```

### 2. Finding Count Checks

```python
for severity in [CRITICAL, HIGH, MEDIUM]:
    if count(findings, severity) > policy.thresholds.max_{severity}_findings:
        violation = "{severity} findings: {count} exceeds maximum {max}"
```

### 3. Permission Checks

```python
if not allow_shell and has_findings(SHELL):
    violation = "Shell execution is not permitted"

if not allow_eval and has_findings(EVAL):
    violation = "Dynamic code evaluation is not permitted"

if not allow_network and has_findings(NETWORK):
    violation = "Network access is not permitted"

if not allow_filesystem_write and has_findings(FILESYSTEM, rule="SG-FS-001"):
    violation = "Filesystem write operations are not permitted"

if not allow_credential_access and has_findings(CREDENTIAL):
    violation = "Credential access is not permitted"
```

### 4. Domain Whitelist/Blacklist

```python
for domain in extract_domains(finding.snippet):
    if domain in blocked_domains:
        violation = "Domain {domain} matches blocked pattern"
    
    if allowed_domains and domain not in allowed_domains:
        violation = "Domain {domain} is not in the allowed domains list"
```

### 5. Confidence Filtering

```python
for violation in violations:
    if violation.confidence < min_confidence_for_severity:
        downgrade to warning
```

**Pass Conditions:**
- No violations **OR** `enforcement.mode == "warn"`
- Warnings do not block

---

## Creating Custom Policies

### Step 1: Generate a Template

```bash
skillgate init --preset production
```

Creates `skillgate.yml`:

```yaml
version: "1"
name: "production"
thresholds:
  max_score: 50
  max_critical_findings: 0
  max_high_findings: 2
  max_medium_findings: 10
permissions:
  allow_shell: false
  allow_eval: false
  allow_network: true
  allow_filesystem_write: false
  allow_credential_access: true
enforcement:
  mode: "enforce"
  fail_on_error: true
```

### Step 2: Customize

Edit `skillgate.yml`:

```yaml
name: "my-custom-policy"
description: "Custom policy for microservice skills"
thresholds:
  max_score: 40
  max_critical_findings: 0
  max_high_findings: 1
  max_medium_findings: 5
permissions:
  allow_network: true
  allowed_domains:
    - "api.internal.company.com"
    - "*.amazonaws.com"
  blocked_domains:
    - "*.public-cloud.net"
rules:
  disabled:
    - "SG-NET-003"  # Disable DNS lookup warnings
  severity_overrides:
    "SG-NET-001": "high"  # Upgrade HTTP requests to high
```

### Step 3: Test

```bash
skillgate scan --policy ./skillgate.yml --enforce ./skill
```

---

## Examples

### Example 1: API Gateway Skill

Allow only specific API domains:

```yaml
version: "1"
name: "api-gateway"
thresholds:
  max_score: 40
permissions:
  allow_network: true
  allowed_domains:
    - "api.stripe.com"
    - "api.openai.com"
  allow_shell: false
  allow_eval: false
```

### Example 2: Read-Only Analytics

Allow network but block filesystem writes:

```yaml
version: "1"
name: "analytics"
permissions:
  allow_network: true
  allow_filesystem_write: false
  allow_credential_access: true  # Allow reading API keys from env
```

### Example 3: High-Confidence Gating

Require 90% confidence for critical findings:

```yaml
version: "1"
name: "high-confidence"
confidence:
  critical_min_confidence: 0.9
  high_min_confidence: 0.8
  medium_min_confidence: 0.6
```

### Example 4: Development with Feedback

Warn-only mode for local development:

```yaml
version: "1"
name: "dev-feedback"
enforcement:
  mode: "warn"
  fail_on_error: false
```

---

## See Also

- [Rule Catalog](RULE-CATALOG.md) — Complete list of detection rules
- [Entitlement Guide](ENTITLEMENT-GUIDE.md) — Tier-based feature access
- [CLI API Spec](CLI-API-SPEC.md) — Command-line interface reference
