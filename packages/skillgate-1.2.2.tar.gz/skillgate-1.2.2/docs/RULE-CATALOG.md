# SkillGate Detection Rule Catalog

**Version:** 1.1.0  
**Last Updated:** 2026-02-18  
**Total Rules:** 119

Complete catalog of all detection rules across 7 languages (Python, JavaScript, TypeScript, Shell, Go, Rust, Ruby) and multi-artifact analyzers.

---

## Table of Contents

1. [Overview](#overview)
2. [Rule Metadata](#rule-metadata)
3. [Shell Execution Rules (SG-SHELL-*)](#shell-execution-rules)
4. [Network Access Rules (SG-NET-*)](#network-access-rules)
5. [Filesystem Rules (SG-FS-*)](#filesystem-rules)
6. [Dynamic Evaluation Rules (SG-EVAL-*)](#dynamic-evaluation-rules)
7. [Credential Access Rules (SG-CRED-*)](#credential-access-rules)
8. [Injection Rules (SG-INJ-*)](#injection-rules)
9. [Obfuscation Rules (SG-OBF-*)](#obfuscation-rules)
10. [Language Coverage Matrix](#language-coverage-matrix)
11. [Rule Customization](#rule-customization)

---

## Overview

SkillGate detection rules are **deterministic static analysis patterns** — no machine learning, no probabilistic behavior. Each rule targets a specific risky pattern across one or more languages.

**Rule Design Principles:**
- **Zero false negatives** on canonical patterns
- **Low false positives** via context-aware filtering (comments, strings, test files)
- **Language-scoped** — rules only fire on appropriate file extensions
- **Pluggable** — all rules extend `RegexRule` or `AstRule` base classes

**Coverage:**
- **7 languages:** Python, JavaScript, TypeScript, Shell, Go, Rust, Ruby
- **10 categories:** Shell, Network, Filesystem, Eval, Credential, Injection, Obfuscation, Prompt, Command, Config
- **119 total rules** (live registry count)

---

## Rule Metadata

Each rule has the following metadata:

| Field | Description | Example |
|-------|-------------|---------|
| `id` | Unique rule identifier | `SG-SHELL-001` |
| `name` | Internal name | `subprocess_call` |
| `description` | Human-readable summary | `Direct subprocess execution detected` |
| `severity` | Severity level | `LOW`, `MEDIUM`, `HIGH`, `CRITICAL` |
| `weight` | Risk score contribution (0-100) | `40` |
| `category` | Category | `SHELL`, `NETWORK`, `FILESYSTEM`, `EVAL`, `CREDENTIAL`, `INJECTION`, `OBFUSCATION` |

**Severity Multipliers:**
- `LOW`: 0.5×
- `MEDIUM`: 1.0×
- `HIGH`: 1.5×
- `CRITICAL`: 2.0×

**Risk Score Formula:**
```
score = Σ(finding.weight × severity_multiplier)
```

---

## Shell Execution Rules

Rules that detect shell command execution, subprocess spawning, and destructive operations.

### Python / Universal (SG-SHELL-001–007)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-SHELL-001 | subprocess_call | Direct subprocess execution detected | HIGH | 40 | `subprocess.(run\|Popen\|call\|check_call\|check_output)` |
| SG-SHELL-002 | os_system | OS-level command execution detected | HIGH | 40 | `os.system(` |
| SG-SHELL-003 | os_popen | OS pipe command execution detected | HIGH | 40 | `os.popen(` |
| SG-SHELL-004 | shell_true | Shell injection vector: shell=True parameter | CRITICAL | 50 | `shell\s*=\s*True` |
| SG-SHELL-005 | backtick_exec | Backtick command execution (JS/Shell) | HIGH | 40 | <code>exec(`</code>, `$(...)` |
| SG-SHELL-006 | child_process | Node.js child process execution | HIGH | 40 | `child_process.(exec\|spawn\|execFile\|fork)` |
| SG-SHELL-007 | shutil_operations | Destructive file operations via shutil | MEDIUM | 25 | `shutil.(rmtree\|move\|copytree)` |

### Go (SG-SHELL-010–011)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-SHELL-010 | go_exec_command | Go exec.Command() detected | HIGH | 40 | `exec.Command(` |
| SG-SHELL-011 | go_command_execution | Go command execution methods | HIGH | 40 | `.Run()\|.Output()\|.CombinedOutput()` |

### Rust (SG-SHELL-020–021)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-SHELL-020 | rust_command_new | Rust Command::new() detected | HIGH | 40 | `Command::new(` |
| SG-SHELL-021 | rust_command_execution | Rust command execution methods | HIGH | 40 | `.output()\|.spawn()\|.status()` |

### Ruby (SG-SHELL-030–034)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-SHELL-030 | ruby_system | Ruby system() call detected | HIGH | 40 | `system(\|Kernel.system` |
| SG-SHELL-031 | ruby_exec | Ruby exec() detected | HIGH | 40 | `\bexec(` |
| SG-SHELL-032 | ruby_backtick | Ruby backtick command execution | HIGH | 40 | <code>`...`</code> |
| SG-SHELL-033 | ruby_popen | Ruby IO.popen/Open3 detected | HIGH | 40 | `IO.popen\|Open3` |
| SG-SHELL-034 | ruby_spawn | Ruby Process.spawn() detected | HIGH | 40 | `Process.spawn\|spawn(` |

### AST Rules (SG-SHELL-040, SG-SHELL-050)

| Rule ID | Name | Description | Severity | Weight | Detection Method |
|---------|------|-------------|----------|--------|------------------|
| SG-SHELL-040 | js_child_process_ast | JavaScript child_process via AST | HIGH | 40 | Tree-sitter AST query |
| SG-SHELL-050 | shell_curl_wget_ast | Shell curl/wget via AST | MEDIUM | 25 | Tree-sitter AST query |

**Recommendation:** Use `shell=False` with argument lists (Python), `execFile()` (Node.js), or direct syscalls (Go/Rust) to avoid injection.

---

## Network Access Rules

Rules that detect HTTP requests, raw sockets, DNS lookups, and hardcoded IPs.

### Python / Universal (SG-NET-001–006)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-NET-001 | http_request | Outbound HTTP request detected | MEDIUM | 25 | `requests.(get\|post)\|urllib.request.urlopen\|httpx\|fetch(` |
| SG-NET-002 | socket_connection | Raw socket connection detected | HIGH | 35 | `socket.(connect\|socket\|create_connection)` |
| SG-NET-003 | dns_lookup | DNS lookup operation detected | LOW | 15 | `socket.gethostbyname` |
| SG-NET-004 | webhook_post | Webhook/external POST detected | MEDIUM | 30 | HTTP POST patterns |
| SG-NET-005 | hardcoded_ip | Hardcoded IP address detected | MEDIUM | 20 | IPv4/IPv6 regex |
| SG-NET-006 | ftp_connection | FTP/SFTP connection detected | MEDIUM | 30 | `ftplib\|paramiko.SFTPClient` |

### Go (SG-NET-010–012)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-NET-010 | go_http_client | Go HTTP client usage | MEDIUM | 25 | `http.(Get\|Post\|Head\|NewRequest)` |
| SG-NET-011 | go_net_dial | Go net.Dial() detected | HIGH | 35 | `net.Dial\|net.DialTimeout` |
| SG-NET-012 | go_http_server | Go HTTP server listener | MEDIUM | 25 | `http.ListenAndServe` |

### Rust (SG-NET-020–022)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-NET-020 | rust_http_client | Rust HTTP client (reqwest/hyper/ureq) | MEDIUM | 25 | HTTP client libraries |
| SG-NET-021 | rust_tcp_connect | Rust TcpStream::connect() | HIGH | 35 | `TcpStream::connect` |
| SG-NET-022 | rust_tcp_server | Rust TcpListener::bind() | MEDIUM | 25 | `TcpListener::bind` |

### Ruby (SG-NET-030–031)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-NET-030 | ruby_http_client | Ruby HTTP clients (Net::HTTP/HTTParty/Faraday/RestClient) | MEDIUM | 25 | HTTP libraries |
| SG-NET-031 | ruby_socket | Ruby raw sockets (TCPSocket/UDPSocket) | HIGH | 35 | Socket classes |

### AST Rules (SG-NET-040, SG-NET-050)

| Rule ID | Name | Description | Severity | Weight | Detection Method |
|---------|------|-------------|----------|--------|------------------|
| SG-NET-040 | js_fetch_ast | JavaScript fetch() via AST | MEDIUM | 25 | Tree-sitter AST query |
| SG-NET-050 | shell_network_ast | Shell wget/curl via AST | MEDIUM | 25 | Tree-sitter AST query |

**Recommendation:** Use domain whitelisting via `allowed_domains` in policy to restrict network access.

---

## Filesystem Rules

Rules that detect file writes, deletions, path traversal, sensitive file reads, and symlink creation.

### Python / Universal (SG-FS-001–006)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-FS-001 | file_write | File write operation detected | MEDIUM | 25 | `open(..., 'w'\|'a'\|'wb'\|'ab')\|Path(...).write_` |
| SG-FS-002 | path_traversal | Path traversal pattern detected | HIGH | 40 | `\.\./\|\.\.\\\|%2e%2e` |
| SG-FS-003 | sensitive_read | Sensitive file read detected | MEDIUM | 30 | `/etc/passwd\|/etc/shadow\|.ssh/id_rsa\|.aws/credentials` |
| SG-FS-004 | tmp_execution | Temporary file execution risk | MEDIUM | 30 | `/tmp/.*\.(sh\|py\|js\|rb)` |
| SG-FS-005 | glob_expansion | Unsafe glob expansion detected | LOW | 15 | `glob.glob` with `**` |
| SG-FS-006 | symlink_creation | Symlink creation detected | MEDIUM | 25 | `os.symlink\|Path(...).symlink_to` |

### Go (SG-FS-010–012)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-FS-010 | go_file_write | Go file write operations | MEDIUM | 25 | `os.Create\|os.OpenFile\|os.WriteFile` |
| SG-FS-011 | go_file_delete | Go file deletion operations | MEDIUM | 30 | `os.Remove\|os.RemoveAll` |
| SG-FS-012 | go_path_traversal | Go path traversal patterns | HIGH | 40 | `filepath.Join(.*"\.\./")` |

### Rust (SG-FS-020–022)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-FS-020 | rust_file_write | Rust file write operations | MEDIUM | 25 | `File::create\|fs::write` |
| SG-FS-021 | rust_file_delete | Rust file deletion operations | MEDIUM | 30 | `fs::remove_file\|fs::remove_dir_all` |
| SG-FS-022 | rust_path_traversal | Rust path traversal patterns | HIGH | 40 | `Path::new("..")` |

### Ruby (SG-FS-030–032)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-FS-030 | ruby_file_write | Ruby file write operations | MEDIUM | 25 | `File.write\|File.open(..., 'w')` |
| SG-FS-031 | ruby_file_delete | Ruby file deletion operations | MEDIUM | 30 | `FileUtils.rm\|File.delete` |
| SG-FS-032 | ruby_path_traversal | Ruby path traversal patterns | HIGH | 40 | Path traversal detection |

### AST Rules (SG-FS-040, SG-FS-050–051)

| Rule ID | Name | Description | Severity | Weight | Detection Method |
|---------|------|-------------|----------|--------|------------------|
| SG-FS-040 | js_fs_ast | JavaScript fs module via AST | MEDIUM | 25 | Tree-sitter AST query |
| SG-FS-050 | shell_rm_ast | Shell rm command via AST | MEDIUM | 30 | Tree-sitter AST query |
| SG-FS-051 | shell_write_redirect_ast | Shell output redirection via AST | MEDIUM | 25 | Tree-sitter AST query |

**Recommendation:** Use `allow_filesystem_write: false` in production policies. Whitelist specific paths via `allowed_paths`.

---

## Dynamic Evaluation Rules

Rules that detect `eval()`, `exec()`, dynamic imports, and runtime code generation.

### Python / Universal (SG-EVAL-001–006)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-EVAL-001 | eval_usage | eval() usage detected | CRITICAL | 50 | `\beval(` |
| SG-EVAL-002 | exec_usage | exec() usage detected | CRITICAL | 50 | `\bexec(` |
| SG-EVAL-003 | compile_usage | compile() usage detected | HIGH | 40 | `\bcompile(` |
| SG-EVAL-004 | import_lib | Dynamic import via importlib | MEDIUM | 30 | `importlib.import_module` |
| SG-EVAL-005 | getattr_dynamic | Dynamic attribute access | LOW | 15 | `getattr(.*,.*,` |
| SG-EVAL-006 | type_dynamic | Dynamic type creation | MEDIUM | 25 | `type(.*,.*,` |

### Go (SG-EVAL-010–011)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-EVAL-010 | go_reflect_call | Go reflection calls | MEDIUM | 30 | `reflect.Value.Call` |
| SG-EVAL-011 | go_plugin_open | Go dynamic plugin loading | HIGH | 40 | `plugin.Open` |

### Rust (SG-EVAL-020–021)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-EVAL-020 | rust_unsafe | Rust unsafe{} blocks | HIGH | 40 | `unsafe\s*{` |
| SG-EVAL-021 | rust_dynamic_loading | Rust dynamic library loading | HIGH | 40 | `libloading::Library\|dlopen` |

### Ruby (SG-EVAL-030–032)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-EVAL-030 | ruby_eval | Ruby eval/instance_eval/class_eval | CRITICAL | 50 | `eval\|instance_eval\|class_eval` |
| SG-EVAL-031 | ruby_send | Ruby send/public_send dynamic dispatch | MEDIUM | 30 | `send\|public_send` |
| SG-EVAL-032 | ruby_const_get | Ruby const_get() dynamic constants | MEDIUM | 25 | `const_get` |

### AST Rules (SG-EVAL-040–041, SG-EVAL-050)

| Rule ID | Name | Description | Severity | Weight | Detection Method |
|---------|------|-------------|----------|--------|------------------|
| SG-EVAL-040 | js_eval_ast | JavaScript eval() via AST | CRITICAL | 50 | Tree-sitter AST query |
| SG-EVAL-041 | js_new_function_ast | JavaScript new Function() via AST | HIGH | 40 | Tree-sitter AST query |
| SG-EVAL-050 | shell_eval_ast | Shell eval command via AST | CRITICAL | 50 | Tree-sitter AST query |

**Recommendation:** Use `allow_eval: false` in all production policies. No legitimate agent skill requires eval.

---

## Credential Access Rules

Rules that detect environment variable access, hardcoded secrets, AWS/GCP credentials, and SSH keys.

### Python / Universal (SG-CRED-001–006)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-CRED-001 | env_var_access | Environment variable access detected | LOW | 15 | `os.environ\|os.getenv` |
| SG-CRED-002 | hardcoded_secret | Hardcoded API key/token detected | HIGH | 40 | `(api_key\|token\|secret)\s*=\s*["'].*["']` |
| SG-CRED-003 | aws_credentials | AWS credential access detected | MEDIUM | 30 | `.aws/credentials\|AWS_ACCESS_KEY_ID` |
| SG-CRED-004 | gcp_credentials | GCP credential access detected | MEDIUM | 30 | `GOOGLE_APPLICATION_CREDENTIALS` |
| SG-CRED-005 | ssh_key_access | SSH key access detected | MEDIUM | 30 | `.ssh/id_rsa\|.ssh/id_ed25519` |
| SG-CRED-006 | password_in_code | Password variable in code | HIGH | 35 | `password\s*=\s*["']` |

### Go (SG-CRED-010–011)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-CRED-010 | go_env_var | Go environment variable access | LOW | 15 | `os.Getenv\|os.LookupEnv\|os.Setenv` |
| SG-CRED-011 | go_hardcoded_secret | Go hardcoded API keys | HIGH | 40 | Secret patterns in Go |

### Rust (SG-CRED-020–021)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-CRED-020 | rust_env_var | Rust environment variable access | LOW | 15 | `env::var\|env::set_var` |
| SG-CRED-021 | rust_hardcoded_secret | Rust hardcoded API keys | HIGH | 40 | Secret patterns in Rust |

### Ruby (SG-CRED-030)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-CRED-030 | ruby_env_access | Ruby ENV[] access | LOW | 15 | `ENV\[` |

**Recommendation:** Use `allow_credential_access: false` for AI-generated code review (`agent-output` preset). Never hardcode secrets.

---

## Injection Rules

Rules that detect SQL injection, command injection, LDAP injection, and XSS vectors.

### Python / Universal (SG-INJ-001–004)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-INJ-001 | sql_injection | SQL injection vector detected | HIGH | 40 | String concatenation in SQL queries |
| SG-INJ-002 | command_injection | Command injection vector detected | HIGH | 40 | String interpolation in shell commands |
| SG-INJ-003 | ldap_injection | LDAP injection vector detected | MEDIUM | 30 | Unsafe LDAP queries |
| SG-INJ-004 | xss_pattern | XSS/HTML injection pattern detected | MEDIUM | 25 | Unescaped HTML output |

### Go (SG-INJ-010)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-INJ-010 | go_sql_injection | Go SQL injection via fmt.Sprintf() | HIGH | 40 | SQL string formatting |

### Rust (SG-INJ-020)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-INJ-020 | rust_sql_injection | Rust SQL injection via format!() | HIGH | 40 | SQL string formatting |

### Ruby (SG-INJ-030)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-INJ-030 | ruby_sql_injection | Ruby SQL injection via string interpolation | HIGH | 40 | SQL string interpolation |

**Recommendation:** Use parameterized queries (prepared statements) for all database access.

---

## Obfuscation Rules

Rules that detect Base64 payloads, hex encoding, char code concatenation, and string reversal.

### Universal (SG-OBF-001–005)

| Rule ID | Name | Description | Severity | Weight | Pattern |
|---------|------|-------------|----------|--------|---------|
| SG-OBF-001 | base64_payload | Large Base64-encoded payload detected | MEDIUM | 30 | Base64 strings >100 chars |
| SG-OBF-002 | charcode_concat | Character code concatenation (obfuscation) | MEDIUM | 25 | `String.fromCharCode\|chr(` |
| SG-OBF-003 | hex_encoding | Hex-encoded strings detected | LOW | 20 | `\x[0-9a-f]{2}` patterns |
| SG-OBF-004 | string_reversal | String reversal obfuscation | LOW | 20 | `[::-1]\|.reverse()` |
| SG-OBF-005 | unicode_escape | Unicode escape obfuscation | LOW | 15 | `\u0000`-style escapes |

**Recommendation:** Enable all obfuscation rules. Legitimate skills rarely use heavy encoding.

---

## Language Coverage Matrix

| Category | Python | JavaScript/TS | Shell | Go | Rust | Ruby | Total |
|----------|--------|---------------|-------|----|----|------|-------|
| **SHELL** | 7 | 2 (AST) | 2 (AST) | 2 | 2 | 5 | **20** |
| **NETWORK** | 6 | 1 (AST) | 1 (AST) | 3 | 3 | 2 | **16** |
| **FILESYSTEM** | 6 | 1 (AST) | 2 (AST) | 3 | 3 | 3 | **18** |
| **EVAL** | 6 | 2 (AST) | 1 (AST) | 2 | 2 | 3 | **16** |
| **CREDENTIAL** | 6 | — | — | 2 | 2 | 1 | **11** |
| **INJECTION** | 4 | — | — | 1 | 1 | 1 | **7** |
| **OBFUSCATION** | 5 | — | — | — | — | — | **5** |
| **Total** | **40** | **6** | **6** | **13** | **13** | **15** | **91** |

**AST Rules:** Require optional `[ast]` dependency (`pip install skillgate[ast]`). Gracefully degrade to regex-only if tree-sitter unavailable.

---

## Rule Customization

### Disabling Rules

```yaml
rules:
  disabled:
    - "SG-SHELL-001"  # Allow subprocess.run() in this project
    - "SG-NET-003"    # Disable DNS lookup warnings
```

### Overriding Severity

```yaml
rules:
  severity_overrides:
    "SG-NET-001": "high"     # Upgrade HTTP requests to HIGH
    "SG-CRED-001": "low"     # Downgrade env var access to LOW
```

### Overriding Weights

```yaml
rules:
  weight_overrides:
    "SG-SHELL-004": 60       # Increase shell=True to 60 points
    "SG-OBF-001": 10         # Decrease Base64 to 10 points
```

**Use Cases:**
- **Disable false positives** — e.g., SG-NET-003 (DNS lookup) for legitimate network tools
- **Tune strictness** — upgrade/downgrade severity for project-specific risk tolerance
- **Custom scoring** — adjust weights to match organizational policies

---

## See Also

- [Policy Reference](POLICY-REFERENCE.md) — Policy schema and presets
- [Entitlement Guide](ENTITLEMENT-GUIDE.md) — Tier-based rule access
- [CLI API Spec](CLI-API-SPEC.md) — `skillgate rules` command reference
