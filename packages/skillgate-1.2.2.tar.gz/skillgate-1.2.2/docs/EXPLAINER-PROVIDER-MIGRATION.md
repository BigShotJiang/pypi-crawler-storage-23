# Explainer Provider Migration

This compatibility guide preserves the legacy top-level location for explainer migration guidance.
The full operational runbook lives at `docs/phase1/EXPLAINER-PROVIDER-MIGRATION.md`.

## Required CLI Flags

- `--explain-source`
- `--llm-provider`
- `--explain-backend`

## Required Environment Controls

- `SKILLGATE_EXPLAIN_EGRESS`
- `SKILLGATE_EXPLAIN_ENDPOINT_ALLOWLIST`

## Supported Provider Examples

- `azure-openai`
- `groq`
- `ollama`

## Rollback

If provider migration degrades reliability, roll back to the previous known-good explainer provider configuration and rerun policy validation.
