# RFC: SkillGate Agent Gateway Mode (`skillgate run -- <agent-cli>`)

**Status:** Implemented (Phase B baseline) + P2/P3 roadmap
**Owner:** SkillGate
**Date:** 2026-02-18
**Revision:** 3 (post-implementation production-readiness alignment)

---

## 1) Objective

Extend SkillGate from scan-time policy enforcement to **runtime execution governance** by introducing a
universal wrapper command:

```bash
skillgate run -- codex ...
skillgate run -- claude ...
skillgate run -- cursor-agent ...
```

SkillGate becomes the **policy enforcement plane** between any agent CLI and its skill/tool execution,
closing the enforcement gap that no current tool addresses: every existing solution is either
scan-time-only (Promptfoo, Semgrep), observability-only (LangSmith, Arize), or
LLM-API-embedded (Guardrails AI, NeMo) — none wraps the execution CLI layer universally [R1].

### 1.0 Dual Invocation Requirement (Updated)

To support both CI and non-CI Pro/Team workflows, gateway delivery requires **two invocation modes**:

1. **Wrapper mode (baseline):** user/CI runs `skillgate run -- <agent-cli ...>`.
2. **Native hook mode (required for local agent UX):**
   - `skillgate gateway check --command "<planned tool call>"`
   - `skillgate gateway scan-output --output-text "<tool output>"`

Both modes must use the same deterministic policy semantics, TOP logic, and signed artifact model.

### 1.1 Runtime Control Flow (Corrected)

**Without gateway controls (risk increases):**

`Agent -> AI CLI Tool (OpenClaw/Claude/Codex/etc.) -> Runs external code or dependencies -> No runtime security checks -> Untrusted code can run -> Supply chain risk increases`

**With gateway baseline controls (risk reduced vs. uncontrolled path):**

`Agent -> skillgate run -- <agent-cli> -> Allowlist + signatures + sandbox/policy checks -> Signed allow/deny decision -> Constrained execution or block -> Supply chain risk reduced (residual risk remains)`

This clarifies that baseline controls are a risk-reduction layer, not a risk amplifier.

### 1.2 Implementation Delta (2026-02-18)

**Implemented in codebase (baseline):**
- `skillgate run -- <agent-cli ...>` runtime wrapper with deterministic pre-check enforcement.
- Native hook commands for non-CI integrations:
  - `skillgate gateway check`
  - `skillgate gateway scan-output`
- Tool Output Poisoning guard (`SG-TOP-001`) with outcomes `PASS|ANNOTATE|SANITIZE|BLOCK`.
- AI-BOM runtime controls via `skillgate bom import` and `skillgate bom validate`.
- Runtime session artifacts + signature verification via `skillgate dag show` and `skillgate dag verify`.
- Scope-token propagation (`SKILLGATE_SCOPE_TOKEN`) with Ed25519 signature and TTL validation.
- Runtime policy schema block (`runtime:`) and environment-aware preset defaults.
- Acceptance coverage:
  - `tests/integration/test_top_guard.py`
  - `tests/integration/test_bom_gate.py`

**Not yet implemented (roadmap):**
- `skillgate bom generate` (CycloneDX + EU AI Act export mode).
- Native tool-schema adapter / MCP interception API.
- Continuous policy reconciliation service.
- Policy GitOps commands (`skillgate policy diff`) and signed merge attestations.
- Semantic intent classifier (ONNX local model).

---

## 2) Threat Model

### 2.1 In-Scope Threats

**Original threats:**
- Malicious or compromised skills invoking unsafe shell/network/file operations at runtime.
- Prompt-induced tool abuse (exfiltration, destructive commands, credential access).
- Entitlement bypass attempts (running restricted features/volumes beyond tier/contract).
- Missing accountability (no signed trace of who ran what and why allowed/blocked).

**New threats (gaps unaddressed by existing tools):**
- **Tool Output Poisoning (T-TOP):** Agent reads tool output containing adversarial instructions
  that manipulate subsequent tool calls (secondary prompt injection at the tool-call boundary).
  _No broadly adopted runtime tool identified in [R1] detects this._
- **Shadow Agent Invocation (T-SAI):** A skill spawns a sub-agent or child process to bypass
  the parent gateway's policy context. Trust context must propagate transitively.
- **Policy Drift Under Continuous Deployment (T-PD):** Skill updates silently introduce new
  tool calls or network egress that weren't present at scan time. Static scan artifacts go stale.
- **AI Supply Chain Compromise (T-SC):** Malicious skills published to public catalogs (e.g.,
  OpenClaw marketplace) with 200K+ installs before detection — observed in the wild (Dec 2025).
- **Unsigned Execution Artifacts (T-UA):** CI pipelines that do not require SkillGate decision
  artifacts can be silently bypassed; no cryptographic proof of policy review exists.
- **Multi-Agent Trust Escalation (T-MTE):** Agent B spawned by Agent A inherits no scoped trust
  boundary — it can acquire capabilities beyond A's own entitlements.

### 2.2 Out-of-Scope (Phase 1)

- Kernel-level process isolation/sandboxing.
- Full prevention against local root/admin users intentionally disabling controls.
- Behavioral ML anomaly detection.

---

## 3) Interception Points

### P0 (MVP, Wrapper-First)

- `skillgate run -- <agent-cli>` process wrapper:
  - Captures command invocation metadata (actor, agent version, skill set, timestamp).
  - Applies entitlement + policy checks before execution.
  - Enforces allow/deny/rate-limits on risky operation classes.
  - Emits signed decision records (Ed25519) per tool invocation.

### P1 — Tool Output Poisoning Layer _(new, addresses T-TOP)_

- Inline post-execution hook on the **output re-injection path** — distinct from the upstream
  tool allow/deny path. This hook runs synchronously before the output enters LLM context;
  it does not touch the original allow/deny decision for the tool call itself.
- Pattern-match and semantic scan for embedded instruction overrides.
- Flag tool outputs containing imperative directives (`ignore previous`, `now do`, `override`
  + action verbs targeting privileged operations).
- **Mode-sensitive behavior:**
  - `strict` / `ci` / `prod`: inline blocking — suspicious output is held; agent receives
    `SG-TOP-001: output quarantined` error and does not proceed.
  - `dev` / permissive modes: annotation-only pass-through — output proceeds with
    `TOP_DETECTED` signal; no blocking.
- Configurable outcome (within the mode's allowed set): `sanitize` | `block` | `annotate`.
- Decision latency target: **p95 < 10ms** (local, regex + trie — no LLM call).

### P1 — Subprocess / Sub-Agent Interception _(addresses T-SAI)_

- Track child process tree spawned by the wrapped agent.
- Propagate policy scope as environment variable (`SKILLGATE_SCOPE_TOKEN`) signed with the session
  Ed25519 keypair (ephemeral keypair generated per `skillgate run` invocation, public key recorded
  in the session artifact).
- Sub-agents without a valid scope token are blocked or demoted to `report-only`.
- Shell commands, network egress intents, sensitive filesystem writes/reads.

### P2 — Native Integration API

- Plugin/hook model for agent CLIs to call SkillGate policy API directly.
- CLI-native hook bridge (implemented baseline):
  - `skillgate gateway check` for pre-exec decisions and scope token issuance.
  - `skillgate gateway scan-output` for TOP guard on re-injection path.
- OpenAPI schema published for first-party integrations (Claude Code hooks, Codex hooks).

### P2 — Continuous Policy Reconciliation _(addresses T-PD)_

- Background reconciliation between scan-time attestation artifacts and runtime observations.
- Delta alerts when runtime tool calls diverge from scan-time approved set.

---

## 4) Latency Budget

### Targets

| Decision Path                    | p95     | p99    | Timeout |
|----------------------------------|---------|--------|---------|
| Local pre-check (deterministic)  | < 5ms   | < 15ms | —       |
| Wrapper total overhead           | < 20ms  | < 50ms | —       |
| Tool output poisoning scan (P1)  | < 10ms  | < 25ms | —       |
| Authority-backed (`saas`)        | < 150ms | < 400ms| 3s      |
| Authority-backed (`private_relay`)| < 250ms| < 600ms| 5s      |
| Cold-start overhead above CLI SLO | < 200ms| —      | —       |

### Strategy

- Fast local pre-checks first (deterministic rules, cached entitlements).
- **Two distinct blocking paths — never conflate:**
  - _Allow/deny path_ (upstream): decides whether a tool call may execute. Async/logging pipelines
    must never block this path.
  - _Output re-injection path_ (downstream): the Tool Output Poisoning guard runs inline here,
    after the tool executes but before output enters LLM context. Blocking on this path is
    intentional in strict modes.
- Explicit fail-open/fail-closed per mode/environment (see §10 open questions resolved).

---

## 5) Bypass Resistance

### Controls

- Organization-standard invocation path in CI: only `skillgate run -- ...` allowed.
- **Signed decision logs** per allow/deny event (actor, command class, policy hash, outcome)
  using Ed25519 — same signing infra as existing SkillGate attestation pipeline.
- Policy hash + binary version recorded for reproducibility.
- Private relay / air-gap modes for no-public-egress enterprise environments.
- **Scope tokens** (`SKILLGATE_SCOPE_TOKEN`) propagated to sub-processes to prevent T-SAI.

### Known Bypass Vectors

- Direct invocation of agent CLI without wrapper.
- Local environment variable tampering on unmanaged endpoints.
- Sub-agent spawning to escape gateway scope.

### Mitigations

- CI enforcement gates reject runs without SkillGate decision artifact.
- Managed shell aliases + pre-commit + runner templates.
- Optional periodic reconciliation: observed executions vs SkillGate logs.
- Sub-agent scope tokens verified cryptographically; invalid = blocked.

---

## 6) Competitive Landscape & Moat Analysis

### 6.1 What Exists Today

| Tool             | Category              | What it does                              | Critical Gap                              |
|------------------|-----------------------|-------------------------------------------|-------------------------------------------|
| Guardrails AI    | LLM I/O guardrails    | Input/output validation via SDK wrapper   | SDK-embedded; not CLI-universal; needs LLM calls for semantic checks |
| NeMo Guardrails  | Conversational AI     | Colang-based flow enforcement             | Framework-specific; Colang 2.0 not production-ready; no CLI wrapping |
| LangSmith        | Observability         | Tracing, monitoring, alerting             | Observe-only — no enforcement, no blocking |
| Arize / Phoenix  | LLM observability     | Drift detection, tracing                  | Post-hoc analysis only                    |
| Portkey          | LLM gateway/proxy     | Routing, caching, load balancing          | API proxy only; no agent CLI integration  |
| Promptfoo        | Red team / testing    | Pre-deployment vulnerability scanning     | Static/scan-time only; no runtime enforcement |
| Semgrep / CodeQL | Static analysis       | Code pattern detection                    | No runtime, no agent CLI concept          |
| AgentOps         | Agent observability   | Agent run tracking, replay                | Observability-only; no enforcement        |
| Pangea           | AI security APIs      | PII redaction, prompt injection APIs      | Requires code-level integration; not CLI-level |

**Verified market gaps [R2][R3]:** 87% of enterprises lack comprehensive AI security frameworks [R2].
39% reported agents accessing unintended systems; 32% saw agents allowing inappropriate data
downloads [R2]. Malicious agent skills with 200K+ installs observed before detection [R3].

### 6.2 Genuine Moat Capabilities — What Nobody Builds

The following capabilities are **not delivered by any existing tool** and represent the defensible moat:

1. **Universal CLI wrapper** — One enforcement layer across Claude Code, Codex, Cursor,
   Copilot, and any future agent CLI. No broadly adopted tool identified in [R1] does this.

2. **Cryptographic signed decision artifacts** — Every allow/deny decision is Ed25519-signed
   with policy hash, actor identity, and timestamp. CI pipelines can reject runs without this
   artifact. No broadly adopted tool in [R1] produces this.

3. **Tool Output Poisoning Detection** — Scanning tool call _outputs_ (not just inputs) before
   re-entry into LLM context. Addresses secondary/indirect prompt injection at the execution
   boundary. No broadly adopted tool in [R1] addresses this attack vector.

4. **AI-BOM Runtime Enforcement with Cryptographic Provenance** — Runtime enforcement of an
   AI Bill of Materials at the execution gate, not just inventory. Existing tools (e.g.,
   ai-bom/Trusera [R6]) generate CycloneDX-format inventories but provide no enforcement gate.
   SkillGate's AI-BOM artifact extends CycloneDX 1.6 with `skillgate:attestation-sig`,
   `skillgate:policy-hash`, and `skillgate:scan-verdict` — the only AI-BOM output with
   cryptographic provenance. Satisfies EU AI Act Article 53 inventory mandate [R6] with
   an enforcement proof, not just a report.

5. **Agent Execution DAG / Lineage Tracking** — Full provenance graph of which agent spawned
   which sub-agent, what tools each invoked, and the decision chain. No broadly adopted tool
   in [R1] produces this as a first-class signed artifact.

6. **Multi-Agent Trust Propagation** — When Agent A spawns Agent B, Agent B inherits a scoped
   subset of A's entitlements (never equal or greater). No broadly adopted framework in [R1]
   handles this at the CLI layer.

7. **Offline / Air-Gap Enforcement Mode** — Full policy enforcement with zero network calls.
   LangSmith requires cloud; Guardrails AI requires LLM API calls; NeMo requires framework
   integration. SkillGate enforces deterministically, offline, with signed local artifacts [R1].

8. **Policy-as-Code (GitOps)** — Agent execution policies as versioned YAML through PR review,
   git history, and signed merge attestation. Policy drift is a `git diff`. No broadly adopted
   tool in [R1] models agent execution policy this way.

9. **Blast Radius Pre-Scoring** — Deterministic pre-execution impact score based on operation
   class, target scope, and data sensitivity. No broadly adopted tool in [R1] provides this
   signal before execution.

---

## 7) Enhancement Roadmap (Post-Baseline)

### 7.1 Tool Output Poisoning Detection (Priority: P1)

**Problem:** Attackers embed instructions in tool outputs (file reads, web fetches, API responses)
that manipulate the agent's subsequent actions. This is the #1 unsolved runtime attack vector.

**Implementation:**
```python
# Intercept point: between tool execution and context re-injection
class ToolOutputGuard:
    INJECTION_PATTERNS = [
        r"ignore (previous|above|prior) instructions?",
        r"(now|instead|actually)\s+(do|execute|run|send|delete|access)",
        r"system:\s*you (must|shall|will|should)",
        r"<\|?(system|assistant|user)\|?>",  # token boundary injection
    ]
    SEVERITY_ESCALATORS = ["credentials", "ssh", "token", "secret", "exfil", "wget", "curl"]
```

**Decision outcomes:** `PASS` | `ANNOTATE` | `SANITIZE` | `BLOCK`
**Latency:** p95 < 10ms (deterministic regex + trie; no LLM call)

### 7.2 AI-BOM Runtime Gate (Priority: P1)

**Problem:** Teams inventory their skills (SBOM/AI-BOM) but have no enforcement gate at execution.
Existing AI-BOM tools generate inventories; SkillGate's gate is the missing enforcement layer.

**Ecosystem position:** SkillGate is downstream of inventory tools (e.g., ai-bom/Trusera).
Feed their CycloneDX output into `skillgate bom import` to seed the approved BOM from an
existing discovery run. SkillGate adds attestation + enforcement on top.

**Implementation:**
- `skillgate bom generate` _(planned, not yet shipped)_ — produces AI-BOM from installed skill set (skill id, version, hash,
  origin, scan attestation). Output: **CycloneDX 1.6** with SkillGate extensions:
  - `skillgate:attestation-sig` — Ed25519 signature over the component entry
  - `skillgate:policy-hash` — hash of the policy applied during scan
  - `skillgate:scan-verdict` — `PASS | WARN | BLOCK` from scan-time analysis
- `skillgate bom import <cyclonedx.json>` — ingest a CycloneDX BOM from any upstream tool
  (ai-bom, Trivy, Syft) and mark imported entries as `UNATTESTED` (warn in permissive, block
  in strict until a SkillGate scan attestation is added).
- `skillgate run` — validates runtime skill invocations against approved AI-BOM.
- Unknown skills → blocked (strict) or warned (permissive) per policy.
- **EU AI Act Article 53 compliance mode:** `skillgate bom generate --format eu-ai-act` emits
  the inventory report format required for Article 53 AI component disclosure [R6].

### 7.3 Agent Lineage & Execution DAG (Priority: P1)

**Problem:** Multi-agent pipelines have no end-to-end provenance. Security teams cannot answer
"what did Agent B do, and which Agent A task triggered it?"

**Implementation:**
- Each `skillgate run` session generates a signed `session_id` (Ed25519, recorded in the session
  artifact). Sub-agent scope token propagation is specified in §3 P1; `parent_session_id` is
  embedded in the token payload — no separate propagation mechanism.
- Decision log entries form a DAG: `(parent_session, child_session, tool, decision, timestamp)`.
- Export: signed JSON artifact per pipeline run; inspectable via
  `skillgate dag show <artifact_path>`.

### 7.4 Blast Radius Pre-Scoring (Priority: P2)

**Problem:** Users and CI pipelines have no signal about the potential impact of a pending
tool call before it executes.

**Implementation:**
- Before execution: classify tool call by `(operation_class, target_scope, data_sensitivity)`.
- Score = `Σ(class_weight × scope_multiplier × sensitivity_multiplier)`, same deterministic
  formula as existing SkillGate scoring.
- Thresholds: `GREEN < 30` | `YELLOW 30–70` | `RED > 70` — maps to auto-allow / warn / block.
- Output in `--format human`: colored inline indicator before tool runs.

### 7.5 Policy-as-Code (GitOps Model) (Priority: P2)

**Problem:** Agent execution policies are applied ad-hoc; changes aren't reviewed, versioned,
or attested. Policy drift is invisible.

**Implementation:**
- `skillgate.yml` extended with `runtime:` block governing gateway behavior.
- Policy changes require signed commit (GPG or Ed25519 SSH) to take effect in `ci` mode.
- `skillgate policy diff` — shows effective policy delta between two refs.
- Policy merge creates a signed attestation artifact (same Ed25519 pipeline).
- **GitOps invariant:** running policy in CI is always derivable from git history.

### 7.6 Multi-Agent Trust Propagation (Priority: P2)

**Problem:** Agent A spawning Agent B with no trust boundary means B can exceed A's permissions.

**Implementation:**
- Scope token encodes: `{parent_session, max_entitlement_tier, allowed_tool_classes, ttl}`.
- Child inherits `min(parent_entitlements, child_requested_entitlements)` — never escalates.
- Token is Ed25519-signed with the session ephemeral keypair (same trust root as decision logs
  and scan attestations); tampered tokens are rejected with `SG-TRUST-001` error. One primitive,
  one revocation model: invalidating the session keypair invalidates all derived scope tokens.
- Configurable: `trust_propagation: inherit | restrict | isolate` per policy.

### 7.7 Semantic Intent Classification (Priority: P3)

**Problem:** Pattern matching catches known-bad patterns but misses novel attack variants.
Teams want policy based on "what is the agent trying to do" not just "what string did it emit."

**Implementation:**
- Optional (never blocks local enforcement): lightweight local classifier (<50MB ONNX model)
  classifies tool calls into intent categories: `DATA_EXFIL | DESTRUCTIVE_WRITE | CREDENTIAL_ACCESS |
  NETWORK_EGRESS | BENIGN`.
- Local-only; model runs in-process; never sends data off-device.
- Policy can reference intent class: `deny: [DATA_EXFIL, CREDENTIAL_ACCESS]`.
- Fallback: if model unavailable, deterministic rules still enforce.

---

## 8) Rollout Plan

### Phase A: Developer Preview

**Status:** Completed (baseline)

- Ship `skillgate run` with permissive developer mode (`--env dev`) for non-blocking rollout.
- Collect false-positive/false-block telemetry.
- Publish policy templates for common agent workflows.
- Launch Tool Output Poisoning Detection (P1.1) as experimental flag `--enable-top-guard`.

### Phase B: CI Enforcement

**Status:** Baseline implemented (remaining hardening in progress)

- Require wrapper in pipeline templates.
- Enable fail-closed for critical operation classes (shell exec, network egress to untrusted domains).
- Export signed decision artifacts as build outputs.
- **Require AI-BOM validation** (`skillgate bom validate`) as pipeline gate.
- Release Agent Lineage DAG artifact format.

### Phase C: Enterprise Modes

**Status:** Planned

- Support `saas`, `private_relay`, and `airgap` runtime decision paths.
- Enforce seat/contract limits at runtime and per-team scopes.
- Add reconciliation and audit export workflows for Security/Compliance teams.
- Publish **Policy-as-Code GitOps** model; signed policy attestation in CI.
- Multi-agent Trust Propagation GA with scope token protocol.

### Phase D: Ecosystem & Marketplace Trust

**Status:** Planned

- Partner with OpenClaw skill marketplace to embed SkillGate attestation in skill listings.
- `skillgate run` validates skill origin hash against marketplace attestation before load.
- Community-maintained policy packs (analogous to Guardrails AI's community validators)
  distributed as versioned, signed packages.

---

## 9) Success Criteria

- 95%+ of CI agent runs include SkillGate signed decision artifacts.
- Runtime policy violations blocked with deterministic reason codes (SG-RT-* namespace).
- No significant developer productivity regression (wrapper overhead within latency budget).
- Enterprise no-egress deployments pass private relay/air-gap acceptance tests.
- **Tool output poisoning detection:** < 0.5% FP rate on benign tool outputs; ≥ 99% detection
  rate on the versioned injection corpus (`tests/fixtures/injection_corpus_v1.jsonl`, min 500
  labeled samples). Acceptance test: `pytest tests/integration/test_top_guard.py`.
  Corpus is versioned and pinned in CI; new corpus version requires RFC amendment or ADR.
- **AI-BOM gate:** unknown skill invocations blocked in `strict` mode with 0 false negatives,
  validated against `tests/fixtures/bom_unknown_skills.jsonl`. Acceptance test:
  `pytest tests/integration/test_bom_gate.py`. "0 false negatives" means: for every unknown skill
  in the fixture set, a block event is emitted before any tool call executes.
- **Agent lineage DAG:** full provenance reconstructable for any session from signed JSON artifact.
  Verified by `skillgate dag verify <artifact_path>` returning exit 0 against CI session fixtures.

### 9.1 Production Readiness Remaining Work

The baseline implementation is functional and test-covered, but the following items remain before
declaring full GA completion for all RFC scope:

- Enforce wrapper-only execution in all CI templates by default (org rollout policy).
- Add `skillgate bom generate` and EU AI Act export format support.
- Add runtime replay fixture set for `dag verify` across multiple parent/child agent chains.
- Add enterprise decision-path integration tests (`saas`, `private_relay`, `airgap`) with timeout/fail-policy assertions.
- Publish SLO dashboards for wrapper overhead and TOP scan latency in production telemetry.

---

## 10) Open Questions — Resolved

| Question (original) | Resolution |
|---------------------|------------|
| Minimum viable cross-agent abstraction: shell-only first or tool-schema adapter from day one? | **Shell-only P0; tool-schema adapter P1.** Ship fast with process-level interception; add schema-aware adapter once Claude Code / Codex hook APIs stabilize. |
| Should runtime allowlists be repo-local, org-global, or both with merge precedence? | **Both, with merge precedence:** repo-local overrides org-global for explicit entries; org-global fills gaps. Precedence: CLI flags > repo `skillgate.yml` > org policy > built-in defaults. |
| What is the default fail policy by environment? | **Resolved — see fail policy matrix below.** |

**Fail policy matrix (deterministic):**

| Environment | CRITICAL  | HIGH      | MEDIUM    | LOW       | Decision timeout | Detector error |
|-------------|-----------|-----------|-----------|-----------|------------------|----------------|
| `dev`       | warn+log  | warn+log  | log       | log       | fail-open        | fail-open      |
| `ci`        | block     | block     | warn+log  | log       | fail-closed      | fail-closed    |
| `prod`      | block     | block     | block     | warn+log  | fail-closed      | fail-closed    |
| `strict`    | block     | block     | block     | block     | fail-closed      | fail-closed    |

**Mixed-signal precedence rule (deterministic, highest severity wins):**

When multiple detectors fire on the same tool call: `outcome = max_severity(all_detector_results)`.
Example: blast-radius scores MEDIUM + pattern-match scores HIGH in `ci` → effective HIGH → **block**.

**Timeout behavior:**

Decision timeout = policy authority did not respond within the configured window (§4).
- Fail-open: allow + emit `SG-RT-TIMEOUT` warning log.
- Fail-closed: deny + emit `SG-RT-TIMEOUT` blocking event.

TTL-expired scope tokens are treated as a decision timeout under the applicable environment's
fail policy. Configurable via `skillgate.yml runtime.fail_policy` (environment-level override
only; individual rule severity cannot be overridden below the environment default).

## 11) Open Questions — New

- **Tool schema adapter protocol:** Adopt MCP (Model Context Protocol) as the canonical
  intermediate representation for tool-call interception. Convergent evidence: ai-bom/Trusera
  [R6] independently added MCP server scanning as a first-class target (Feb 2026). MCP is
  becoming the de facto tool-call standard; defining our own schema would fragment the ecosystem.
  Recommended resolution: MCP adapter in P1, custom schema as last resort only if MCP is
  insufficient for a specific interception point.
- **Scope token revocation:** Should compromised session keys trigger real-time revocation
  (requires network in air-gap mode) or is TTL-based expiry sufficient?
- **Semantic classifier distribution:** ONNX model distribution via PyPI or separate channel?
  What is the update cadence and signing model for model artifacts themselves?
- **Marketplace attestation partnership:** Is the OpenClaw attestation integration a
  contractual partnership or a unilateral hash-matching scheme?

---

## 12) Namespace Registry

Canonical mapping of threat IDs, error codes, and rule namespaces introduced in this RFC.
All additions require a PR updating this table; the table is the single source of truth.

### Threat IDs (`T-*`)

| ID      | Name                              | Section |
|---------|-----------------------------------|---------|
| T-TOP   | Tool Output Poisoning             | §2.1    |
| T-SAI   | Shadow Agent Invocation           | §2.1    |
| T-PD    | Policy Drift                      | §2.1    |
| T-SC    | AI Supply Chain Compromise        | §2.1    |
| T-UA    | Unsigned Execution Artifacts      | §2.1    |
| T-MTE   | Multi-Agent Trust Escalation      | §2.1    |

### Runtime Error Codes (`SG-RT-*`)

| Code             | Meaning                                      | Section |
|------------------|----------------------------------------------|---------|
| SG-RT-TIMEOUT    | Policy authority did not respond in time     | §10     |
| SG-TOP-001       | Tool output quarantined (injection detected) | §3, §7.1|
| SG-TRUST-001     | Scope token invalid or tampered              | §7.6    |

### Existing rule namespace (`SG-{CATEGORY}-*`)

Governed by `docs/IMPLEMENTATION-PLAN.md`. Runtime rules use the `SG-RT-*` sub-namespace;
trust rules use `SG-TRUST-*`. No overlap with static analysis rule IDs (SG-SHELL-*, SG-NET-*,
SG-FS-*, SG-EVAL-*, SG-CRED-*, SG-INJ-*, SG-OBF-*).

---

## References

| ID  | Source                                                                              |
|-----|-------------------------------------------------------------------------------------|
| R1  | Internal competitive analysis, Feb 2026 — tool survey across Guardrails AI, NeMo, LangSmith, Portkey, Promptfoo, AgentOps, Pangea public documentation |
| R2  | Gartner AI Security Survey 2025 — "State of AI Agent Governance in Enterprise"      |
| R3  | Mitiga Security, "AI Agent Supply Chain Risk: Silent Codebase Exfiltration via Skills," Jan 2026 — https://www.mitiga.io/blog/ai-agent-supply-chain-risk-silent-codebase-exfiltration-via-skills |
| R4  | OWASP GenAI Security Project — AI SBOM Initiative — https://genai.owasp.org/ai-sbom-initiative/ |
| R5  | SD Times, "From SBOM to AI BOM: Rethinking supply chain security for AI native software," 2025 |
| R6  | Trusera ai-bom — AI Bill of Materials scanner (CycloneDX 1.6, EU AI Act Article 53 compliance, MCP server detection) — https://github.com/Trusera/ai-bom |
