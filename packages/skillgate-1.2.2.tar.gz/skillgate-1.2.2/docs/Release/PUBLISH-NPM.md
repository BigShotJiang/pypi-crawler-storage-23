# Publish Runbook - npm Shim (`@skillgate-io/cli`)

## Scope

Publishes the Node entrypoint wrapper for SkillGate CLI.

- Package: `@skillgate-io/cli`
- Registry: [https://www.npmjs.com/package/@skillgate-io/cli](https://www.npmjs.com/package/@skillgate-io/cli)
- Note: this package delegates to Python `skillgate` runtime.

## Preconditions

- npm token available (`NPM_TOKEN` / logged-in npm session)
- Version bumped in `npm-shim/package.json`
- Python package version for same release prepared/published

## Commands

```bash
cd npm-shim

# 1) Verify package contents
NPM_CONFIG_CACHE=../.npm-cache npm pack

# 2) Dry-run publish
NPM_CONFIG_CACHE=../.npm-cache npm publish --dry-run

# 3) Publish
NPM_CONFIG_CACHE=../.npm-cache npm publish --access public
```

## Post-publish validation

```bash
mkdir -p /tmp/sg-npm-check && cd /tmp/sg-npm-check
npm init -y
npm install @skillgate-io/cli@1.2.0
npx skillgate --help
```

If Python runtime is not present, `npx skillgate` should emit the install guidance message.
