# SkillGate Release Checklist - vX.Y.Z

- Release date (UTC):
- Release owner:
- Release branch/tag:
- Change window:

## 1. Pre-flight

- [ ] `git status` is clean on intended release branch.
- [ ] Version bump merged for all targeted packages.
- [ ] Changelog/release notes updated.
- [ ] Rollback plan confirmed.

## 2. Quality Gates

- [ ] `./venv/bin/ruff check .`
- [ ] `./venv/bin/mypy --strict skillgate`
- [ ] `./venv/bin/pytest -q`
- [ ] `npm --prefix web-ui test`
- [ ] `npm --prefix web-ui run build`
- [ ] `npm --prefix vscode-extension test`

## 3. Package Build + Verify

- [ ] Python build: `./venv/bin/python -m build --no-isolation`
- [ ] Python artifact check: `./venv/bin/twine check dist/skillgate-X.Y.Z*`
- [ ] npm shim pack: `cd npm-shim && NPM_CONFIG_CACHE=../.npm-cache npm pack`
- [ ] .NET pack: `cd dotnet-shim && dotnet pack SkillGate.Client/SkillGate.Client.csproj -c Release`

## 4. Runtime Smoke

- [ ] CLI help and command tree renders.
- [ ] Sidecar health + decision path verified in runtime environment.
- [ ] Web UI core pages render.
- [ ] Docs search + Ask Docs flow verified.

## 5. Publish

- [ ] Python: publish to PyPI.
- [ ] npm: publish `@skillgate-io/cli`.
- [ ] .NET: publish `SkillGate.Client` to NuGet.
- [ ] VS Code extension publish decision logged (publish/defer).

## 6. Deploy

- [ ] API deploy complete.
- [ ] Worker deploy complete.
- [ ] Web UI deploy complete.
- [ ] Docs deploy complete.

## 7. Post-release

- [ ] Smoke production endpoints.
- [ ] Verify install paths from public docs.
- [ ] Confirm telemetry/alerts healthy.
- [ ] Tag release and publish notes.
