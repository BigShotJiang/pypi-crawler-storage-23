# Publish Runbook - Python CLI (`skillgate`)

## Scope

Publishes the canonical SkillGate runtime package to PyPI.

- Package: `skillgate`
- Registry: [https://pypi.org/project/skillgate/](https://pypi.org/project/skillgate/)

## Preconditions

- PyPI token exported as `TWINE_PASSWORD`
- `TWINE_USERNAME=__token__`
- Version already bumped in `skillgate/version.py`
- All release gates green

## Commands

```bash
# 1) Build artifacts
./venv/bin/python -m build --no-isolation

# 2) Verify metadata
./venv/bin/twine check dist/skillgate-*.whl dist/skillgate-*.tar.gz

# 3) (Optional) publish to TestPyPI first
TWINE_USERNAME=__token__ \
TWINE_PASSWORD="$TEST_PYPI_TOKEN" \
./venv/bin/twine upload --repository testpypi dist/skillgate-*.whl dist/skillgate-*.tar.gz

# 4) Publish to PyPI
TWINE_USERNAME=__token__ \
TWINE_PASSWORD="$PYPI_TOKEN" \
./venv/bin/twine upload dist/skillgate-*.whl dist/skillgate-*.tar.gz
```

## Post-publish validation

```bash
python3 -m venv /tmp/sg-pypi-check
/tmp/sg-pypi-check/bin/pip install -U skillgate==1.2.0
/tmp/sg-pypi-check/bin/skillgate --help
```

If install is blocked by offline network policy, run this validation from a network-enabled machine.
