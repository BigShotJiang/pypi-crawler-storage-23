# Mandatory Agent Skills and Usage Order

## Mandatory Skills (Current Workspace)

- `token-efficient-coding`
- `python-pro`
- `pytest-runner`
- `skillgate-agent-tool`
- `production-hardening-gate`

### Pre-Release Readiness

Required:

- `production-hardening-gate`

## Enforcement Rules

1. No risk marked `Mitigated` without evidence links.
2. No risk control claim without validation outputs.
3. P0 risk regressions require immediate escalation and scope freeze.
