# Delegation Matrix

Date: 2026-02-21

| Stream | Owner | Scope |
|---|---|---|
| Product-core governance | Product/Gate Owner | Section 11 governance, release decision gates, policy proof integrity |
| Docs/growth adoption | DX/Growth Owner | Section 13 install/docs funnel, quickstart conversion path |
| Reliability and CI gates | Reliability/Gate Owner | FN/FP/perf signal quality and gate enforcement |
| Enterprise proof and sales | Product + Sales Owner | Procurement evidence packaging and sales-control artifacts |

## Execution Rule

At most one implementation-heavy section may be active at a time; governance tracking can run in parallel.
