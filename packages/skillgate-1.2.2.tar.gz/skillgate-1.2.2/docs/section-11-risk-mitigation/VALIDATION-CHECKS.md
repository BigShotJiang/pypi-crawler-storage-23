# Validation Checks (Mandatory)

Run from repo root unless noted.

## 1) Baseline Quality Evidence

```bash
./venv/bin/ruff check .
./venv/bin/mypy --strict skillgate/
./venv/bin/pytest -q
```

## 2) Risk Control Evidence (As Applicable)

- Claim-proof consistency: `python scripts/quality/check_claim_ledger.py`
- Governance scope gate: `python scripts/quality/check_governance_scope_gate.py`
- Reliability evidence: `python scripts/quality/generate_reliability_scorecard.py`

## 3) Required Evidence Per Risk

- Mitigation action record.
- Validation/check output links.
- Residual risk statement.
- Fallback/rollback plan.

## 4) Local Consolidated CI Gate Pack

Run the local CI-equivalent gate pack (lint, typecheck, tests, SLO, reliability evidence, packaging smoke/rehearsal, API matrix, API migrations, security, decision gates):

```bash
./venv/bin/python scripts/quality/run_local_ci_gate.py --offline-safe
```

Outputs:
- `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-<YYYY-MM-DD>.log`
- `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-<YYYY-MM-DD>.json`
- `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-<YYYY-MM-DD>.md`

Notes:
- `api-migrations` uses `SKILLGATE_DATABASE_URL` if set, otherwise defaults to `postgresql+asyncpg://skillgate:skillgate@localhost:5432/skillgate`.
- Use `--skip-web-ui` only for backend-only local validation; keep full pack for production-go decisions.
