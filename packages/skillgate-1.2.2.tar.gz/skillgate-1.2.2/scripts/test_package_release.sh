#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DIST_DIR="${ROOT_DIR}/.tmp_dist"

if ! python - <<'PY'
import importlib
import sys
try:
    importlib.import_module("setuptools.build_meta")
except ModuleNotFoundError:
    sys.exit(1)
sys.exit(0)
PY
then
  echo "[skillgate] ERROR: setuptools.build_meta is not available in this Python environment"
  echo "[skillgate] Install build prerequisites first (setuptools>=68)"
  exit 1
fi

echo "[skillgate] Building wheel into ${DIST_DIR}"
rm -rf "${DIST_DIR}"
mkdir -p "${DIST_DIR}"

python -m pip wheel "${ROOT_DIR}" --no-deps --no-build-isolation -w "${DIST_DIR}"

WHEEL_PATH="$(ls -1 "${DIST_DIR}"/skillgate-*.whl | head -n 1)"
if [[ -z "${WHEEL_PATH}" ]]; then
  echo "[skillgate] ERROR: wheel build produced no skillgate wheel"
  exit 1
fi

echo "[skillgate] Built wheel: ${WHEEL_PATH}"
echo "[skillgate] Verifying entrypoint metadata"
python - "${WHEEL_PATH}" <<'PY'
import sys
import zipfile
from pathlib import Path

wheel = Path(sys.argv[1])
with zipfile.ZipFile(wheel, "r") as zf:
    names = zf.namelist()
    entry = [n for n in names if n.endswith(".dist-info/entry_points.txt")]
    meta = [n for n in names if n.endswith(".dist-info/METADATA")]
    if not entry or not meta:
        raise SystemExit("Missing entry_points.txt or METADATA in wheel")
    entry_text = zf.read(entry[0]).decode("utf-8")
    metadata_text = zf.read(meta[0]).decode("utf-8")
    if "skillgate = skillgate.cli.app:main" not in entry_text:
        raise SystemExit("Console script entrypoint missing from wheel metadata")
    if "Name: skillgate" not in metadata_text:
        raise SystemExit("Package metadata missing Name: skillgate")
print("ok")
PY

echo "[skillgate] Package release smoke checks passed"
