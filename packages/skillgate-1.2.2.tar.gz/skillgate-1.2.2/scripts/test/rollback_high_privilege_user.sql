begin;

-- Roll back fixture rows created by scripts/test/seed_high_privilege_user.sql.
do $$
declare
    v_user_uuid uuid := '11111111-1111-1111-1111-111111111111'::uuid;
    v_user_id text := v_user_uuid::text;
    v_email text := 'sg.high.privilege+test@skillgate.dev';
begin
    delete from entitlement_decision_logs
    where id = '88888888-8888-8888-8888-888888888888'
       or subject_key = 'user:' || v_user_id;

    delete from entitlement_usage_ledger
    where id = '77777777-7777-7777-7777-777777777777'
       or subject_key = 'user:' || v_user_id;

    delete from scan_records
    where id = '66666666-6666-6666-6666-666666666666'
       or user_id = v_user_id;

    delete from api_keys
    where id = '55555555-5555-5555-5555-555555555555'
       or user_id = v_user_id
       or key_prefix = 'sg_test_hp_01';

    delete from subscriptions
    where id = '22222222-2222-2222-2222-222222222222'
       or user_id = v_user_id
       or stripe_subscription_id = 'sub_skillgate_test_high_privilege';

    delete from oauth_identities
    where id = 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa'
       or user_id = v_user_id
       or (provider = 'email' and provider_user_id = v_user_id);

    delete from user_sessions
    where id = '99999999-9999-9999-9999-999999999999'
       or user_id = v_user_id;

    delete from email_verification_tokens
    where user_id = v_user_id;

    delete from password_reset_tokens
    where user_id = v_user_id;

    delete from team_members
    where id = '44444444-4444-4444-4444-444444444444'
       or user_id = v_user_id
       or team_id = '33333333-3333-3333-3333-333333333333'
       or email = v_email;

    delete from teams
    where id = '33333333-3333-3333-3333-333333333333'
       or owner_user_id = v_user_id;

    delete from users
    where id = v_user_id
       or email = v_email;

    delete from auth.users
    where id = v_user_uuid
       or email = v_email;
end $$;

commit;
