begin;

create extension if not exists pgcrypto;

-- Deterministic fixture values for repeatable test runs.
-- Highest privilege in-app posture:
-- - Verified active user
-- - Enterprise active subscription
-- - Team owner + owner membership
-- - Broad API key scopes
-- - Seeded entitlement ledger and decision log

do $$
declare
    v_user_uuid uuid := '11111111-1111-1111-1111-111111111111'::uuid;
    v_user_id text := v_user_uuid::text;
    v_now timestamp := timezone('utc', now());
begin
    -- Supabase auth identity (for login/auth flow tests).
    insert into auth.users (
        id,
        instance_id,
        aud,
        role,
        email,
        encrypted_password,
        email_confirmed_at,
        raw_app_meta_data,
        raw_user_meta_data,
        created_at,
        updated_at
    )
    values (
        v_user_uuid,
        '00000000-0000-0000-0000-000000000000'::uuid,
        'authenticated',
        'authenticated',
        'sg.high.privilege+test@skillgate.dev',
        crypt('SkillGate#Admin123', gen_salt('bf')),
        v_now,
        jsonb_build_object('provider', 'email', 'providers', jsonb_build_array('email'), 'role', 'admin'),
        jsonb_build_object('full_name', 'SkillGate High Privilege Test User', 'fixture', 'seed_high_privilege_user.sql'),
        v_now,
        v_now
    )
    on conflict (id) do update
        set email = excluded.email,
            encrypted_password = excluded.encrypted_password,
            email_confirmed_at = excluded.email_confirmed_at,
            raw_app_meta_data = excluded.raw_app_meta_data,
            raw_user_meta_data = excluded.raw_user_meta_data,
            updated_at = excluded.updated_at;

    insert into users (
        id,
        email,
        password_hash,
        full_name,
        is_active,
        email_verified,
        stripe_customer_id,
        failed_login_attempts,
        lockout_until,
        supabase_user_id,
        created_at,
        updated_at
    )
    values (
        v_user_id,
        'sg.high.privilege+test@skillgate.dev',
        'supabase-managed',
        'SkillGate High Privilege Test User',
        true,
        true,
        'cus_skillgate_test_high_privilege',
        0,
        null,
        v_user_id,
        v_now,
        v_now
    )
    on conflict (id) do update
        set email = excluded.email,
            full_name = excluded.full_name,
            is_active = excluded.is_active,
            email_verified = excluded.email_verified,
            stripe_customer_id = excluded.stripe_customer_id,
            failed_login_attempts = excluded.failed_login_attempts,
            lockout_until = excluded.lockout_until,
            supabase_user_id = excluded.supabase_user_id,
            updated_at = excluded.updated_at;

    insert into subscriptions (
        id,
        user_id,
        stripe_subscription_id,
        stripe_customer_id,
        tier,
        status,
        billing_interval,
        current_period_end,
        cancel_at_period_end,
        last_stripe_event_created_at,
        last_stripe_event_id,
        created_at,
        updated_at
    )
    values (
        '22222222-2222-2222-2222-222222222222',
        v_user_id,
        'sub_skillgate_test_high_privilege',
        'cus_skillgate_test_high_privilege',
        'enterprise',
        'active',
        'monthly',
        v_now + interval '30 days',
        false,
        null,
        null,
        v_now,
        v_now
    )
    on conflict (id) do update
        set tier = excluded.tier,
            status = excluded.status,
            billing_interval = excluded.billing_interval,
            current_period_end = excluded.current_period_end,
            cancel_at_period_end = excluded.cancel_at_period_end,
            updated_at = excluded.updated_at;

    insert into teams (
        id,
        owner_user_id,
        name,
        max_seats,
        created_at
    )
    values (
        '33333333-3333-3333-3333-333333333333',
        v_user_id,
        'SkillGate Test Owner Team',
        50,
        v_now
    )
    on conflict (id) do update
        set owner_user_id = excluded.owner_user_id,
            name = excluded.name,
            max_seats = excluded.max_seats;

    insert into team_members (
        id,
        team_id,
        user_id,
        email,
        role,
        status,
        invited_at,
        joined_at
    )
    values (
        '44444444-4444-4444-4444-444444444444',
        '33333333-3333-3333-3333-333333333333',
        v_user_id,
        'sg.high.privilege+test@skillgate.dev',
        'owner',
        'active',
        v_now,
        v_now
    )
    on conflict (id) do update
        set role = excluded.role,
            status = excluded.status,
            joined_at = excluded.joined_at;

    insert into api_keys (
        id,
        user_id,
        name,
        key_prefix,
        key_hash,
        scopes,
        revoked,
        created_at,
        last_used_at,
        revoked_at
    )
    values (
        '55555555-5555-5555-5555-555555555555',
        v_user_id,
        'high-privilege-fixture-key',
        'sg_test_hp_01',
        'sha256:skillgate-high-privilege-fixture-key-hash',
        'scan:read,scan:write,api_keys:manage,teams:manage,billing:manage,admin:*',
        false,
        v_now,
        v_now,
        null
    )
    on conflict (id) do update
        set name = excluded.name,
            key_prefix = excluded.key_prefix,
            key_hash = excluded.key_hash,
            scopes = excluded.scopes,
            revoked = excluded.revoked,
            last_used_at = excluded.last_used_at,
            revoked_at = excluded.revoked_at;

    insert into scan_records (
        id,
        user_id,
        report_json,
        created_at
    )
    values (
        '66666666-6666-6666-6666-666666666666',
        v_user_id,
        '{"fixture":true,"profile":"high_privilege","status":"pass"}',
        v_now
    )
    on conflict (id) do update
        set report_json = excluded.report_json;

    insert into entitlement_usage_ledger (
        id,
        subject_key,
        mode,
        usage_date,
        tier,
        used_scans,
        scan_limit,
        updated_at
    )
    values (
        '77777777-7777-7777-7777-777777777777',
        'user:' || v_user_id,
        'saas',
        to_char(v_now::date, 'YYYY-MM-DD'),
        'enterprise',
        42,
        10000,
        v_now
    )
    on conflict (id) do update
        set used_scans = excluded.used_scans,
            scan_limit = excluded.scan_limit,
            updated_at = excluded.updated_at;

    insert into entitlement_decision_logs (
        id,
        subject_key,
        mode,
        tier,
        allowed,
        reason,
        used_scans,
        scan_limit,
        drift,
        provenance,
        created_at
    )
    values (
        '88888888-8888-8888-8888-888888888888',
        'user:' || v_user_id,
        'saas',
        'enterprise',
        true,
        'fixture_seed',
        42,
        10000,
        0,
        jsonb_build_object('fixture', true, 'source', 'seed_high_privilege_user.sql'),
        v_now
    )
    on conflict (id) do update
        set allowed = excluded.allowed,
            reason = excluded.reason,
            used_scans = excluded.used_scans,
            scan_limit = excluded.scan_limit,
            drift = excluded.drift,
            provenance = excluded.provenance,
            created_at = excluded.created_at;

    -- Optional Supabase-owned tables for end-to-end auth/session checks.
    insert into user_sessions (
        id,
        user_id,
        refresh_token_hash,
        user_agent,
        ip_address,
        parent_session_id,
        rotated_to_session_id,
        revoked,
        expires_at,
        revoked_at,
        created_at
    )
    values (
        '99999999-9999-9999-9999-999999999999',
        v_user_id,
        'sha256:skillgate-high-privilege-refresh-token-hash',
        'skillgate-fixture',
        '127.0.0.1',
        null,
        null,
        false,
        v_now + interval '30 days',
        null,
        v_now
    )
    on conflict (id) do update
        set refresh_token_hash = excluded.refresh_token_hash,
            revoked = excluded.revoked,
            expires_at = excluded.expires_at,
            revoked_at = excluded.revoked_at;

    insert into oauth_identities (
        id,
        user_id,
        provider,
        provider_user_id,
        email,
        created_at,
        updated_at
    )
    values (
        'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa',
        v_user_id,
        'email',
        v_user_id,
        'sg.high.privilege+test@skillgate.dev',
        v_now,
        v_now
    )
    on conflict (provider, provider_user_id) do update
        set user_id = excluded.user_id,
            email = excluded.email,
            updated_at = excluded.updated_at;
end $$;

commit;
