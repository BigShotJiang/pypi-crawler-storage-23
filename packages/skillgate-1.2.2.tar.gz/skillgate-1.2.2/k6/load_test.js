/**
 * SkillGate k6 Load Test Suite
 *
 * Usage:
 *   k6 run k6/load_test.js
 *   k6 run --env BASE_URL=https://api.skillgate.io k6/load_test.js
 *
 * Scenarios: auth flow, checkout, webhook ingestion, health probe
 */

import http from "k6/http";
import { check, sleep, group } from "k6";
import { Rate, Trend } from "k6/metrics";

const BASE_URL = __ENV.BASE_URL || "http://localhost:8000";
const API = `${BASE_URL}/api/v1`;

// Custom metrics
const authSuccess = new Rate("auth_success");
const checkoutLatency = new Trend("checkout_latency", true);
const webhookLatency = new Trend("webhook_latency", true);

// Thresholds
export const options = {
  scenarios: {
    // Ramp-up auth traffic
    auth_flow: {
      executor: "ramping-vus",
      startVUs: 0,
      stages: [
        { duration: "30s", target: 50 },
        { duration: "1m", target: 100 },
        { duration: "30s", target: 0 },
      ],
      exec: "authFlow",
    },
    // Constant checkout load
    checkout_flow: {
      executor: "constant-arrival-rate",
      rate: 20,
      timeUnit: "1s",
      duration: "2m",
      preAllocatedVUs: 50,
      maxVUs: 100,
      exec: "checkoutFlow",
    },
    // Webhook burst
    webhook_burst: {
      executor: "ramping-arrival-rate",
      startRate: 10,
      timeUnit: "1s",
      stages: [
        { duration: "30s", target: 100 },
        { duration: "1m", target: 200 },
        { duration: "30s", target: 0 },
      ],
      preAllocatedVUs: 200,
      maxVUs: 400,
      exec: "webhookIngestion",
    },
    // Health probe (always running)
    health_probe: {
      executor: "constant-vus",
      vus: 5,
      duration: "2m",
      exec: "healthProbe",
    },
  },
  thresholds: {
    http_req_duration: ["p(95)<500", "p(99)<1000"],
    http_req_failed: ["rate<0.01"],
    auth_success: ["rate>0.95"],
    checkout_latency: ["p(95)<800"],
    webhook_latency: ["p(95)<300"],
  },
};

// --- Scenario functions ---

export function authFlow() {
  group("auth", () => {
    const uniqueEmail = `loadtest+${__VU}-${__ITER}@example.com`;

    // Register
    const registerRes = http.post(
      `${API}/auth/register`,
      JSON.stringify({
        email: uniqueEmail,
        password: "LoadTest123!@#",
        full_name: "Load Tester",
      }),
      { headers: { "Content-Type": "application/json" } }
    );

    const registered = check(registerRes, {
      "register 200|409": (r) => r.status === 200 || r.status === 409,
    });
    authSuccess.add(registered);

    // Login
    const loginRes = http.post(
      `${API}/auth/login`,
      JSON.stringify({
        email: uniqueEmail,
        password: "LoadTest123!@#",
      }),
      { headers: { "Content-Type": "application/json" } }
    );

    const loggedIn = check(loginRes, {
      "login 200|401|429": (r) =>
        r.status === 200 || r.status === 401 || r.status === 429,
    });
    authSuccess.add(loggedIn);

    if (loginRes.status === 200) {
      const body = JSON.parse(loginRes.body);
      const token = body.access_token;

      // Profile fetch
      const profileRes = http.get(`${API}/auth/me`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      check(profileRes, {
        "profile 200": (r) => r.status === 200,
      });
    }

    sleep(0.5);
  });
}

export function checkoutFlow() {
  group("checkout", () => {
    const start = Date.now();
    const res = http.post(
      `${API}/payments/checkout`,
      JSON.stringify({
        tier: "pro",
        customer_email: `checkout+${__VU}-${__ITER}@example.com`,
        success_url: "https://skillgate.io/success",
        cancel_url: "https://skillgate.io/cancel",
      }),
      { headers: { "Content-Type": "application/json" } }
    );
    checkoutLatency.add(Date.now() - start);

    check(res, {
      "checkout 200|429|503": (r) =>
        r.status === 200 || r.status === 429 || r.status === 503,
    });

    sleep(0.1);
  });
}

export function webhookIngestion() {
  group("webhook", () => {
    const eventId = `evt_k6_${__VU}_${__ITER}_${Date.now()}`;
    const payload = JSON.stringify({
      id: eventId,
      type: "checkout.session.completed",
      created: Math.floor(Date.now() / 1000),
      data: {
        object: {
          id: `cs_k6_${__VU}`,
          customer: `cus_k6_${__VU}`,
          subscription: `sub_k6_${__VU}`,
          customer_email: `k6+${__VU}@example.com`,
          metadata: { price_id: "price_pro_monthly" },
        },
      },
    });

    const start = Date.now();
    const res = http.post(`${API}/payments/webhook`, payload, {
      headers: {
        "Content-Type": "application/json",
        "Stripe-Signature": "valid",
      },
    });
    webhookLatency.add(Date.now() - start);

    check(res, {
      "webhook 200|400": (r) => r.status === 200 || r.status === 400,
    });
  });
}

export function healthProbe() {
  const res = http.get(`${API}/health`);
  check(res, {
    "health 200": (r) => r.status === 200,
  });
  sleep(1);
}
