---
name: local-ci-gate-pack
description: Run local production-go gate validation for SkillGate with consolidated artifacts (lint, typecheck, tests, packaging, migrations, security, and governance decision gates) in fail-closed mode.
---

# Local CI Gate Pack

Use this skill when asked to validate production readiness locally or reproduce CI-equivalent checks end-to-end.

## Command

From repo root:

```bash
./venv/bin/python scripts/quality/run_local_ci_gate.py --offline-safe
```

## What It Validates

1. Lint + formatting + quality script gates
2. Strict typing (`mypy --strict`)
3. Test suite
4. SLO gates
5. Reliability scorecard generation
6. Packaging smoke + build + twine metadata check (`--no-isolation`)
7. API command matrix
8. Web UI check/build
9. Alembic upgrade/downgrade/upgrade against local DB URL
10. Security checks (`pip-audit`, `detect-secrets`)
11. Governance decision-gate checks

## Artifacts

- `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-<YYYY-MM-DD>.log`
- `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-<YYYY-MM-DD>.json`
- `docs/section-11-risk-mitigation/artifacts/consolidated-release-audit-<YYYY-MM-DD>.md`

## Fail-Closed Rules

- Do not skip a failing step and continue.
- Do not install missing tools inside the gate command.
- If offline/tooling constraints block `pip-audit` or `detect-secrets`, treat as gate failure and resolve prerequisites first.
- Use `--skip-web-ui` only for scoped backend iteration, not production-go adjudication.
