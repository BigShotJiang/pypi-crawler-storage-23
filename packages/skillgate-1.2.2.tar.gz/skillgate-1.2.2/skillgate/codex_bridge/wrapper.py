"""Codex CLI wrapper orchestration with preflight governance checks."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path
from typing import Any

from skillgate.codex_bridge.config_poisoning import (
    discover_provider_definitions,
    scan_config_poisoning,
)
from skillgate.codex_bridge.injection import scan_instruction_files
from skillgate.codex_bridge.models import CodexFinding, CodexScanSummary
from skillgate.codex_bridge.providers import ProviderRegistry
from skillgate.codex_bridge.report import render_report
from skillgate.codex_bridge.settings import CodexSettingsGovernance
from skillgate.codex_bridge.supply_chain import verify_provider_checksums


def build_codex_env(base_env: dict[str, str], sidecar_url: str, ci_mode: bool) -> dict[str, str]:
    """Build subprocess environment for Codex with SkillGate bridge flags."""
    merged = dict(base_env)
    merged["SKILLGATE_SIDECAR_URL"] = sidecar_url
    merged["SKILLGATE_ENFORCE_MODE"] = "ci" if ci_mode else "enforce"
    merged["SKILLGATE_CODEX_BRIDGE"] = "1"
    if ci_mode:
        merged["SKILLGATE_CI_GUARD"] = "1"
    return merged


def run_codex_wrapper(
    *,
    args: list[str],
    sidecar_url: str,
    ci_mode: bool,
    output: str,
    project_root: Path,
    codex_bin: str,
    env: dict[str, str],
    registry_path: Path,
    instruction_baseline_path: Path,
    settings_baseline_path: Path,
    aibom_lock_path: Path,
) -> int:
    """Run preflight checks and launch Codex subprocess if policy allows."""
    findings = _run_preflight(
        project_root=project_root,
        ci_mode=ci_mode,
        registry_path=registry_path,
        instruction_baseline_path=instruction_baseline_path,
        settings_baseline_path=settings_baseline_path,
        aibom_lock_path=aibom_lock_path,
    )

    summary = CodexScanSummary(project_root=project_root, findings=tuple(findings))
    if findings:
        print(render_report(summary, output))

    if summary.blocked:
        return 1

    command = [codex_bin, *args]
    run_env = build_codex_env(env, sidecar_url, ci_mode)
    completed = subprocess.run(command, env=run_env, check=False)
    return int(completed.returncode)


def _run_preflight(
    *,
    project_root: Path,
    ci_mode: bool,
    registry_path: Path,
    instruction_baseline_path: Path,
    settings_baseline_path: Path,
    aibom_lock_path: Path,
) -> list[CodexFinding]:
    findings: list[CodexFinding] = []

    findings.extend(scan_instruction_files(project_root, baseline_path=instruction_baseline_path))

    registry = ProviderRegistry(registry_path)
    findings.extend(scan_config_poisoning(project_root, registry))

    settings_check = CodexSettingsGovernance(settings_baseline_path, ci_mode=ci_mode).check(
        project_root / ".codex" / "config.json",
        Path.home() / ".codex" / "config.json",
    )
    if not settings_check.allowed:
        findings.append(
            CodexFinding(
                decision_code=settings_check.decision_code,
                message=settings_check.reason,
                file_path=".codex/config.json",
                surface="settings",
                severity="high",
                pattern=json.dumps(
                    {
                        "addedAllowedCommands": list(settings_check.added_allowed_commands),
                        "addedTrustedProviders": list(settings_check.added_trusted_providers),
                        "shellAccessExpanded": settings_check.shell_access_expanded,
                    },
                    sort_keys=True,
                ),
            )
        )

    provider_binaries = _provider_binary_map(project_root)
    if provider_binaries:
        supply_chain = verify_provider_checksums(aibom_lock_path, provider_binaries)
        if not supply_chain.allowed:
            findings.append(
                CodexFinding(
                    decision_code=supply_chain.decision_code,
                    message=supply_chain.reason,
                    file_path=str(aibom_lock_path.relative_to(project_root)),
                    surface="supply-chain",
                    severity="critical",
                    pattern=",".join(supply_chain.changed_providers),
                )
            )

    return findings


def _provider_binary_map(project_root: Path) -> dict[str, Path]:
    providers: dict[str, Path] = {}
    for item in discover_provider_definitions(project_root):
        candidate = _resolve_binary_candidate(project_root, item.source_file, item.provider_id)
        if candidate is None:
            continue
        providers[item.provider_id] = candidate
    return providers


def _resolve_binary_candidate(
    project_root: Path, source_file: str, provider_id: str
) -> Path | None:
    source = project_root / source_file
    payload: Any
    if not source.exists():
        return None
    text = source.read_text(encoding="utf-8")
    if source.suffix.lower() == ".json":
        payload = json.loads(text)
    else:
        try:
            import yaml
        except ImportError:
            return None
        payload = yaml.safe_load(text)

    if not isinstance(payload, dict):
        return None

    providers = payload.get("providers")
    if not isinstance(providers, list):
        return None

    for entry in providers:
        if not isinstance(entry, dict):
            continue
        entry_id = entry.get("id") or entry.get("name") or entry.get("provider")
        if not isinstance(entry_id, str) or entry_id != provider_id:
            continue
        binary = entry.get("binary")
        if isinstance(binary, str) and binary:
            path = (
                (project_root / binary).resolve()
                if not Path(binary).is_absolute()
                else Path(binary)
            )
            if path.exists() and path.is_file():
                return path
    return None
