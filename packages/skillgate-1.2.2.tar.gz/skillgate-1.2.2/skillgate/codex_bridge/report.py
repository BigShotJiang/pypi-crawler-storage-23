"""Reporting helpers for Codex bridge preflight findings."""

from __future__ import annotations

import json
from typing import Any

from skillgate.codex_bridge.models import CodexScanSummary


def render_report(summary: CodexScanSummary, output: str) -> str:
    """Render summary in JSON or SARIF formats."""
    if output == "sarif":
        return format_scan_summary_sarif(summary)
    return json.dumps(summary.to_dict(), sort_keys=True, separators=(",", ":"))


def format_scan_summary_sarif(summary: CodexScanSummary) -> str:
    """Render Codex bridge findings as SARIF 2.1.0."""
    results: list[dict[str, Any]] = []
    for finding in summary.findings:
        results.append(
            {
                "ruleId": finding.decision_code,
                "level": _severity_to_level(finding.severity),
                "message": {"text": finding.message},
                "locations": [
                    {
                        "physicalLocation": {
                            "artifactLocation": {
                                "uri": finding.file_path,
                                "uriBaseId": "%SRCROOT%",
                            },
                            "region": {"startLine": 1},
                        }
                    }
                ],
                "properties": {
                    "surface": finding.surface,
                    "pattern": finding.pattern or "",
                },
            }
        )

    payload = {
        "$schema": "https://json.schemastore.org/sarif-2.1.0.json",
        "version": "2.1.0",
        "runs": [
            {
                "tool": {
                    "driver": {
                        "name": "SkillGate Codex Bridge",
                        "informationUri": "https://skillgate.io",
                    }
                },
                "results": results,
                "properties": {
                    "projectRoot": str(summary.project_root),
                    "blocked": summary.blocked,
                    "findingsCount": len(summary.findings),
                },
            }
        ],
    }
    return json.dumps(payload, sort_keys=True)


def _severity_to_level(severity: str) -> str:
    if severity in {"critical", "high"}:
        return "error"
    if severity == "medium":
        return "warning"
    return "note"
