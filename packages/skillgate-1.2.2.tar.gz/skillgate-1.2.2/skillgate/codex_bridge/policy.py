"""Default and CI policy controls for Codex tool-call enforcement."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse

from skillgate.codex_bridge.models import ToolProxyDecision


@dataclass(slots=True)
class CodexPolicy:
    """In-memory policy defaults used by the Codex bridge proxy."""

    ci_mode: bool
    shell_budget_per_minute: int
    net_budget_per_minute: int
    allowlisted_spawn_bins: tuple[str, ...] = ("python", "python3", "node", "bash", "sh")
    protected_branches: tuple[str, ...] = ("main", "master", "production")
    ci_allowlisted_domains: tuple[str, ...] = (
        "api.skillgate.io",
        "api.openai.com",
        "api.anthropic.com",
    )
    usage: dict[str, int] = field(default_factory=lambda: defaultdict(int))


def default_policy(ci_mode: bool, allowed_domains: tuple[str, ...] = ()) -> CodexPolicy:
    """Return bridge policy defaults for dev or CI modes."""
    if ci_mode:
        domains = tuple(
            sorted({*allowed_domains, "api.skillgate.io", "api.openai.com", "api.anthropic.com"})
        )
        return CodexPolicy(
            ci_mode=True,
            shell_budget_per_minute=5,
            net_budget_per_minute=10,
            ci_allowlisted_domains=domains,
        )
    return CodexPolicy(
        ci_mode=False,
        shell_budget_per_minute=10,
        net_budget_per_minute=20,
    )


def apply_default_guards(
    policy: CodexPolicy, request: dict[str, object], cwd: Path
) -> ToolProxyDecision:
    """Apply deterministic local guards before sidecar decision checks."""
    capability = str(request.get("capability", ""))
    command = str(request.get("command", ""))

    if capability == "fs.write":
        raw_path = str(request.get("path", ""))
        if raw_path:
            candidate = Path(raw_path).expanduser().resolve()
            cwd_resolved = cwd.resolve()
            if not _is_within(candidate, cwd_resolved):
                return ToolProxyDecision(
                    allowed=False,
                    decision_code="SG_DENY_CAPABILITY_NOT_ALLOWED",
                    reason="fs.write outside current workspace is denied by default.",
                )

    if capability == "git.write":
        for branch in policy.protected_branches:
            if f" {branch}" in f" {command}":
                return ToolProxyDecision(
                    allowed=False,
                    decision_code="SG_APPROVAL_REQUIRED",
                    reason=f"git.write to protected branch '{branch}' requires approval.",
                )

    if capability == "process.spawn":
        binary = command.split(" ", 1)[0].strip().lower()
        if binary and binary not in {item.lower() for item in policy.allowlisted_spawn_bins}:
            return ToolProxyDecision(
                allowed=False,
                decision_code="SG_DENY_CAPABILITY_NOT_ALLOWED",
                reason="process.spawn of non-allowlisted interpreter is denied by default.",
            )

    if capability == "shell.exec":
        key = "shell.exec"
        policy.usage[key] += 1
        if policy.usage[key] > policy.shell_budget_per_minute:
            return ToolProxyDecision(
                allowed=False,
                decision_code="SG_DENY_BUDGET_EXCEEDED",
                reason="shell.exec budget exceeded.",
            )

    if capability == "net.outbound":
        key = "net.outbound"
        policy.usage[key] += 1
        if policy.usage[key] > policy.net_budget_per_minute:
            return ToolProxyDecision(
                allowed=False,
                decision_code="SG_DENY_BUDGET_EXCEEDED",
                reason="net.outbound budget exceeded.",
            )

        if policy.ci_mode:
            target = str(request.get("target", ""))
            domain = _extract_domain(target)
            if domain and domain not in set(policy.ci_allowlisted_domains):
                return ToolProxyDecision(
                    allowed=False,
                    decision_code="SG_DENY_POLICY_VIOLATION_PATTERN",
                    reason=f"CI mode blocks outbound domain '{domain}'.",
                )

    return ToolProxyDecision(allowed=True, decision_code="SG_ALLOW", reason="Allowed by defaults.")


def _extract_domain(target: str) -> str:
    if not target:
        return ""
    parsed = urlparse(target)
    return (parsed.hostname or "").lower()


def _is_within(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False
