"""Compliance annotations for audit/enforcement records."""

from __future__ import annotations

from copy import deepcopy
from typing import Any

_NIST_MAP: dict[str, list[str]] = {
    "ALLOW": ["GOVERN", "MEASURE"],
    "DENY": ["MANAGE", "MEASURE"],
    "REQUIRE_APPROVAL": ["GOVERN", "MAP"],
    "FAIL": ["MANAGE"],
}

_EU_AI_ACT_MAP: dict[str, list[str]] = {
    "ALLOW": ["Article 15"],
    "DENY": ["Article 9", "Article 15"],
    "REQUIRE_APPROVAL": ["Article 9", "Article 10", "Article 17"],
    "FAIL": ["Article 17"],
}


def annotate_record(record: dict[str, Any]) -> dict[str, Any]:
    """Add NIST/EU annotation metadata without changing decision payload."""
    enriched = deepcopy(record)
    decision = str(enriched.get("decision", "ALLOW"))
    enriched["compliance_annotations"] = {
        "nist_ai_rmf": _NIST_MAP.get(decision, ["GOVERN"]),
        "eu_ai_act": _EU_AI_ACT_MAP.get(decision, ["Article 9"]),
    }
    return enriched
