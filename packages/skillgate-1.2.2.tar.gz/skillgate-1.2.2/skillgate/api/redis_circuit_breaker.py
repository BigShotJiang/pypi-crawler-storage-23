"""Redis-backed distributed circuit breaker for multi-instance deployments."""

from __future__ import annotations

import asyncio
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, TypeVar, cast

try:
    from redis.asyncio import Redis
except ImportError:  # pragma: no cover
    Redis = None  # type: ignore[assignment,misc]

T = TypeVar("T")

# Lua script: atomic circuit breaker state check + failure recording
# Keys[1] = breaker key
# ARGV[1] = failure_threshold, ARGV[2] = recovery_seconds
# ARGV[3] = action ("check"|"fail"|"success")
_CIRCUIT_BREAKER_LUA = """
local key = KEYS[1]
local threshold = tonumber(ARGV[1])
local recovery = tonumber(ARGV[2])
local action = ARGV[3]

local fail_key = key .. ":failures"
local open_key = key .. ":open"

if action == "check" then
    local is_open = redis.call("EXISTS", open_key)
    if is_open == 1 then
        return {0, tonumber(redis.call("GET", fail_key) or 0)}
    end
    return {1, tonumber(redis.call("GET", fail_key) or 0)}
end

if action == "success" then
    redis.call("DEL", fail_key)
    redis.call("DEL", open_key)
    return {1, 0}
end

if action == "fail" then
    local failures = redis.call("INCR", fail_key)
    redis.call("EXPIRE", fail_key, recovery * 2)
    if failures >= threshold then
        redis.call("SET", open_key, "1", "EX", recovery)
    end
    return {failures >= threshold and 0 or 1, failures}
end

return {1, 0}
"""


@dataclass(slots=True)
class RedisCircuitBreakerSnapshot:
    """Read-only distributed circuit breaker state."""

    state: str
    failures: int


class RedisCircuitBreaker:
    """Distributed circuit breaker backed by Redis for multi-instance deployments."""

    def __init__(
        self,
        *,
        redis: Redis,
        name: str,
        failure_threshold: int = 5,
        recovery_seconds: int = 30,
    ) -> None:
        self._redis = redis
        self._key = f"cb:{name}"
        self._failure_threshold = failure_threshold
        self._recovery_seconds = recovery_seconds

    async def allow(self) -> bool:
        result = await cast(Any, self._redis.eval)(
            _CIRCUIT_BREAKER_LUA,
            1,
            [self._key],
            [str(self._failure_threshold), str(self._recovery_seconds), "check"],
        )
        return bool(result[0])

    async def record_success(self) -> None:
        await cast(Any, self._redis.eval)(
            _CIRCUIT_BREAKER_LUA,
            1,
            [self._key],
            [str(self._failure_threshold), str(self._recovery_seconds), "success"],
        )

    async def record_failure(self) -> None:
        await cast(Any, self._redis.eval)(
            _CIRCUIT_BREAKER_LUA,
            1,
            [self._key],
            [str(self._failure_threshold), str(self._recovery_seconds), "fail"],
        )

    async def snapshot(self) -> RedisCircuitBreakerSnapshot:
        result = await cast(Any, self._redis.eval)(
            _CIRCUIT_BREAKER_LUA,
            1,
            [self._key],
            [str(self._failure_threshold), str(self._recovery_seconds), "check"],
        )
        allowed, failures = result
        return RedisCircuitBreakerSnapshot(
            state="closed" if allowed else "open",
            failures=failures,
        )


async def run_with_redis_resilience(
    *,
    breaker: RedisCircuitBreaker,
    timeout_seconds: float,
    fn: Callable[[], T],
) -> T:
    """Execute blocking call with timeout and distributed circuit-breaker controls."""
    if not await breaker.allow():
        raise RuntimeError("External dependency circuit is open")

    try:
        result = await asyncio.wait_for(asyncio.to_thread(fn), timeout=timeout_seconds)
    except Exception:
        await breaker.record_failure()
        raise

    await breaker.record_success()
    return result
