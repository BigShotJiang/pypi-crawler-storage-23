"""Security helpers for auth tokens, password hashing, and API keys."""

from __future__ import annotations

import base64
import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any

import jwt
from jwt import InvalidTokenError

ALGORITHM = "HS256"
ACCESS_TOKEN_TTL_MIN = 60
REFRESH_TOKEN_TTL_DAYS = 30


def _jwt_secret() -> str:
    secret = os.environ.get("SKILLGATE_JWT_SECRET")
    if not secret:
        raise RuntimeError("SKILLGATE_JWT_SECRET must be configured.")
    return secret


def _api_key_pepper() -> str:
    pepper = os.environ.get("SKILLGATE_API_KEY_PEPPER")
    if not pepper:
        raise RuntimeError("SKILLGATE_API_KEY_PEPPER must be configured.")
    return pepper


def _refresh_token_pepper() -> str:
    pepper = os.environ.get("SKILLGATE_REFRESH_TOKEN_PEPPER")
    if not pepper:
        raise RuntimeError("SKILLGATE_REFRESH_TOKEN_PEPPER must be configured.")
    return pepper


def hash_password(password: str, *, salt: bytes | None = None) -> str:
    """Hash password with PBKDF2-HMAC-SHA256 and encode as salt$hash."""
    used_salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), used_salt, 210_000)
    return f"{base64.b64encode(used_salt).decode()}${base64.b64encode(digest).decode()}"


def verify_password(password: str, encoded_hash: str) -> bool:
    """Verify password against encoded PBKDF2 hash."""
    try:
        salt_b64, digest_b64 = encoded_hash.split("$", maxsplit=1)
        salt = base64.b64decode(salt_b64.encode("utf-8"))
        expected = base64.b64decode(digest_b64.encode("utf-8"))
    except ValueError:
        return False

    computed = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, 210_000)
    return hmac.compare_digest(computed, expected)


def create_access_token(
    *,
    subject: str,
    session_id: str | None = None,
    ttl_minutes: int = ACCESS_TOKEN_TTL_MIN,
) -> str:
    """Create signed JWT access token for user subject."""
    now = datetime.now(timezone.utc)
    payload: dict[str, Any] = {
        "sub": subject,
        "typ": "access",
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(minutes=ttl_minutes)).timestamp()),
    }
    if session_id:
        payload["sid"] = session_id
    return jwt.encode(payload, _jwt_secret(), algorithm=ALGORITHM)


def decode_access_token(token: str) -> dict[str, str]:
    """Decode access JWT and return normalized token claims."""
    try:
        payload = jwt.decode(token, _jwt_secret(), algorithms=[ALGORITHM])
    except InvalidTokenError as exc:
        raise ValueError("Invalid token") from exc
    token_type = payload.get("typ")
    if token_type != "access":
        raise ValueError("Invalid token type")
    subject = payload.get("sub")
    if not isinstance(subject, str) or not subject:
        raise ValueError("Invalid token subject")
    session_id = payload.get("sid")
    if session_id is not None and not isinstance(session_id, str):
        raise ValueError("Invalid token session")
    claims = {"sub": subject}
    if isinstance(session_id, str):
        claims["sid"] = session_id
    return claims


def generate_refresh_token() -> str:
    """Generate opaque refresh token string."""
    return "sg_refresh_" + secrets.token_urlsafe(32)


def hash_refresh_token(refresh_token: str) -> str:
    """One-way hash for refresh-token storage."""
    return hashlib.sha256(f"{_refresh_token_pepper()}:{refresh_token}".encode()).hexdigest()


def refresh_token_expiry() -> datetime:
    """Calculate refresh token expiry timestamp."""
    return datetime.now(timezone.utc) + timedelta(days=REFRESH_TOKEN_TTL_DAYS)


def generate_api_key() -> str:
    """Generate opaque API key string."""
    return "sg_live_" + secrets.token_urlsafe(28)


def generate_tier_api_key(tier: str) -> str:
    """Generate local entitlement-compatible API key string.

    Format: ``sg_{tier}_{32 hex chars}``, where ``tier`` is one of
    ``free | pro | team | enterprise``.
    """
    normalized_tier = tier.strip().lower()
    prefix_by_tier = {
        "free": "sg_free_",
        "pro": "sg_pro_",
        "team": "sg_team_",
        "enterprise": "sg_ent_",
    }
    prefix = prefix_by_tier.get(normalized_tier)
    if prefix is None:
        prefix = "sg_free_"
    return prefix + secrets.token_hex(16)


def api_key_prefix(api_key: str) -> str:
    """Return non-sensitive prefix for display/audit."""
    return api_key[:14]


def hash_api_key(api_key: str) -> str:
    """One-way hash for API key storage."""
    digest = hashlib.sha256(f"{_api_key_pepper()}:{api_key}".encode()).hexdigest()
    return digest
