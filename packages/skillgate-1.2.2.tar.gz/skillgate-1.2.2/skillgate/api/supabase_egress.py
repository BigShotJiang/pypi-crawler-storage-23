"""Supabase egress policy enforcement (Task 17.191)."""

from __future__ import annotations

import random
import time
from dataclasses import dataclass
from urllib.parse import urlparse


@dataclass(frozen=True)
class EgressPolicy:
    """Runtime egress policy for Supabase-bound outbound calls."""

    allowed_hosts: frozenset[str]
    max_retries: int = 2
    initial_backoff_seconds: float = 0.1
    circuit_breaker_failures: int = 5
    circuit_breaker_window_seconds: float = 30.0


class CircuitBreakerOpenError(RuntimeError):
    """Raised when egress circuit breaker is open."""


class CircuitBreaker:
    """Very small in-memory circuit breaker for a client instance."""

    def __init__(self, *, failure_threshold: int, open_window_seconds: float) -> None:
        self._failure_threshold = failure_threshold
        self._open_window_seconds = open_window_seconds
        self._consecutive_failures = 0
        self._open_until_monotonic = 0.0

    def assert_allow(self) -> None:
        now = time.monotonic()
        if now < self._open_until_monotonic:
            raise CircuitBreakerOpenError("Supabase egress circuit is open")

    def record_success(self) -> None:
        self._consecutive_failures = 0
        self._open_until_monotonic = 0.0

    def record_failure(self) -> None:
        self._consecutive_failures += 1
        if self._consecutive_failures >= self._failure_threshold:
            self._open_until_monotonic = time.monotonic() + self._open_window_seconds


def host_from_url(url: str) -> str:
    """Extract lower-cased host from URL; empty string means invalid."""

    try:
        parsed = urlparse(url)
    except Exception:
        return ""
    return (parsed.hostname or "").strip().lower()


def is_host_allowed(*, url: str, policy: EgressPolicy) -> bool:
    """Return True when URL host is allowed by policy allowlist."""

    host = host_from_url(url)
    if not host:
        return False
    return host in policy.allowed_hosts


def retry_backoff_seconds(*, attempt: int, initial_backoff_seconds: float) -> float:
    """Exponential backoff with jitter for egress retries."""

    base = initial_backoff_seconds * (2**attempt)
    jitter = base * 0.2 * random.random()
    return float(base + jitter)
