"""Backend-managed marketing roadmap catalog for web UI consumption."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, Field

RoadmapStatus = Literal["live", "removed_from_ui", "planned", "in_progress"]


class RoadmapItem(BaseModel):
    """Single roadmap line item."""

    id: str = Field(min_length=1, max_length=64)
    title: str = Field(min_length=1, max_length=200)
    status: RoadmapStatus
    reason: str = Field(min_length=1, max_length=280)
    target_tier: Literal["free", "pro", "team", "enterprise", "multi-tier"]
    proof_surface: str = Field(min_length=1, max_length=120)
    implementation_task: str | None = Field(default=None, max_length=32)


class MarketingRoadmap(BaseModel):
    """Roadmap payload for marketing roadmap UI."""

    version: str
    updated_at: str
    category: str
    posture: str
    items: list[RoadmapItem]


def marketing_roadmap_payload() -> MarketingRoadmap:
    """Return the canonical marketing roadmap payload."""
    return MarketingRoadmap(
        version="2026-02-19",
        updated_at=datetime.now(timezone.utc).isoformat(),
        category="AI Agent Control Plane",
        posture=("You can track live features and near-term roadmap milestones by plan."),
        items=[
            RoadmapItem(
                id="TEAM-SEATS-15",
                title="Team plan supports up to 15 seats",
                status="live",
                reason="Designed for shared engineering workflows and larger teams.",
                target_tier="team",
                proof_surface="entitlement.max_seats",
                implementation_task="17.92",
            ),
            RoadmapItem(
                id="TEAM-CI-BLOCKING",
                title="CI blocking is Team+ in CI context",
                status="live",
                reason="Built for release confidence across pull requests and pipelines.",
                target_tier="team",
                proof_surface="cli.scan --enforce (CI mode)",
                implementation_task="17.92",
            ),
            RoadmapItem(
                id="TEAM-FLEET",
                title="Fleet scanning (--fleet) is Team+",
                status="live",
                reason="Supports governance across many skills and repositories.",
                target_tier="team",
                proof_surface="cli.scan --fleet",
                implementation_task="17.89",
            ),
            RoadmapItem(
                id="ENTERPRISE-AIRGAP",
                title="Private relay and air-gap deployment are Enterprise-only",
                status="live",
                reason="For organizations with strict deployment and network controls.",
                target_tier="enterprise",
                proof_surface="entitlement mode resolver",
                implementation_task="17.92",
            ),
            RoadmapItem(
                id="ENTERPRISE-COMPLIANCE-MODES",
                title=(
                    "Compliance phrasing uses evidence/control mappings (not certification claims)"
                ),
                status="live",
                reason="Clear language for security and procurement teams.",
                target_tier="enterprise",
                proof_surface="pricing copy policy",
                implementation_task="17.97",
            ),
            RoadmapItem(
                id="ENTERPRISE-SSO-SAML",
                title="SSO/SAML integration",
                status="planned",
                reason="Planned for enterprise identity and access workflows.",
                target_tier="enterprise",
                proof_surface="api auth/provider contracts",
                implementation_task="17.93",
            ),
            RoadmapItem(
                id="PRO-CUSTOM-PACKS-LIMIT",
                title="Negative limit claims for custom policy packs",
                status="removed_from_ui",
                reason=("Planned as part of the next policy-pack expansion."),
                target_tier="multi-tier",
                proof_surface="policy pack command/API gating",
                implementation_task="17.92",
            ),
            RoadmapItem(
                id="ENTERPRISE-RUNTIME-BUDGETS",
                title="Enterprise runtime capability budgets",
                status="live",
                reason=("Available in runtime gateway enforcement with org-scoped controls."),
                target_tier="enterprise",
                proof_surface="runtime gateway enforcement",
                implementation_task="17.93",
            ),
            RoadmapItem(
                id="ENTERPRISE-TRUST-GRAPH",
                title="Transitive risk and trust propagation graph",
                status="planned",
                reason="Planned to improve cross-skill risk visibility at enterprise scale.",
                target_tier="enterprise",
                proof_surface="intelligence graph API",
                implementation_task="17.93",
            ),
            RoadmapItem(
                id="CLAIM-LEDGER-CI",
                title="CI-gated claim ledger anti-drift control",
                status="in_progress",
                reason="In progress to keep roadmap and release notes consistent over time.",
                target_tier="multi-tier",
                proof_surface="claim-ledger CI check",
                implementation_task="17.92",
            ),
        ],
    )
