"""Database engine and session management for hosted API routes."""

from __future__ import annotations

import os
from collections.abc import AsyncGenerator

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from sqlalchemy.pool import NullPool

from skillgate.api.models import Base


def _database_url() -> str:
    """Resolve database URL from environment."""
    value = os.environ.get("SKILLGATE_DATABASE_URL")
    if value is None or not value.strip():
        raise RuntimeError("SKILLGATE_DATABASE_URL must be set.")
    return value


def _read_replica_url() -> str | None:
    """Optional read-replica URL for SELECT-heavy routes."""
    return os.environ.get("SKILLGATE_READ_REPLICA_URL")


def _parse_bool(value: str | None, default: bool) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def _pool_size() -> int:
    return int(os.environ.get("SKILLGATE_DB_POOL_SIZE", "20"))


def _max_overflow() -> int:
    return int(os.environ.get("SKILLGATE_DB_MAX_OVERFLOW", "10"))


def _is_postgres(url: str) -> bool:
    return url.startswith("postgresql")


def database_url() -> str:
    """Expose the configured runtime database URL."""
    return _database_url()


def alembic_database_url() -> str:
    """Return sync-driver database URL for Alembic migration engine."""
    url = _database_url()
    if url.startswith("postgresql+asyncpg://"):
        return url.replace("postgresql+asyncpg://", "postgresql+psycopg://", 1)
    if url.startswith("sqlite+aiosqlite:///"):
        return url.replace("sqlite+aiosqlite:///", "sqlite:///", 1)
    return url


def _engine_kwargs(url: str) -> dict[str, object]:
    """Build engine kwargs with connection pooling for PostgreSQL."""
    kwargs: dict[str, object] = {"future": True, "pool_pre_ping": True}
    if _parse_bool(os.environ.get("SKILLGATE_DISABLE_DB_POOL"), False):
        kwargs["poolclass"] = NullPool
        return kwargs
    if _is_postgres(url):
        kwargs["pool_size"] = _pool_size()
        kwargs["max_overflow"] = _max_overflow()
        kwargs["pool_recycle"] = 300
        kwargs["pool_timeout"] = 30
    return kwargs


_primary_url = _database_url()
engine = create_async_engine(_primary_url, **_engine_kwargs(_primary_url))

# Read-replica engine (falls back to primary if not configured)
_replica_url = _read_replica_url()
read_engine = (
    create_async_engine(_replica_url, **_engine_kwargs(_replica_url)) if _replica_url else engine
)

SessionLocal = async_sessionmaker(
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)

ReadOnlySession = async_sessionmaker(
    bind=read_engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


async def init_db() -> None:
    """Create database tables for local/dev workflows only.

    Production deployments must use Alembic migrations.
    """
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


def should_auto_init_db() -> bool:
    """Control schema auto-initialize behavior for local SQLite-only startup."""
    default = _database_url().startswith("sqlite+")
    return _parse_bool(os.environ.get("SKILLGATE_AUTO_INIT_DB"), default)


async def verify_database_connectivity() -> None:
    """Fail fast if the configured database is unreachable."""
    async with engine.connect() as conn:
        await conn.execute(text("SELECT 1"))


async def get_session() -> AsyncGenerator[AsyncSession, None]:
    """Yield a transaction-capable async database session."""
    async with SessionLocal() as session:
        yield session


async def get_read_session() -> AsyncGenerator[AsyncSession, None]:
    """Yield a read-only session routed to the replica (or primary fallback)."""
    async with ReadOnlySession() as session:
        yield session
