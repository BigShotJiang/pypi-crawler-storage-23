"""Authoritative entitlement usage and reconciliation endpoints."""

from __future__ import annotations

import base64
import hashlib
import json
import logging
import os
from datetime import datetime, timezone
from uuid import uuid4

import httpx
from fastapi import APIRouter, Depends, Header, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.api.db import get_session
from skillgate.api.models import EntitlementDecisionLog, EntitlementUsageLedger
from skillgate.config.license import Tier
from skillgate.core.entitlement.mode import EntitlementEnforcementMode
from skillgate.core.entitlement.resolver import resolve_from_signed_payload
from skillgate.core.errors import EntitlementError

router = APIRouter(prefix="/entitlements", tags=["entitlements"])
logger = logging.getLogger(__name__)


def _utc_day() -> str:
    return datetime.now(timezone.utc).date().isoformat()


def _hash_subject(subject_id: str) -> str:
    raw = subject_id.encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def _admin_key() -> str:
    return os.environ.get("SKILLGATE_ADMIN_KEY", "")


def _require_admin(access_key: str) -> None:
    required = _admin_key()
    if not required or access_key != required:
        raise HTTPException(status_code=403, detail="Invalid admin key")


def _is_non_local_mode(mode: str) -> bool:
    normalized = mode.strip().lower()
    return normalized in {
        EntitlementEnforcementMode.SAAS.value,
        EntitlementEnforcementMode.PRIVATE_RELAY.value,
        EntitlementEnforcementMode.AIRGAP.value,
    }


def _decode_signed_payload(token: str) -> dict[str, object]:
    payload_b64 = token.split(".", 1)[0]
    padding = 4 - len(payload_b64) % 4
    payload_bytes = base64.urlsafe_b64decode(payload_b64 + "=" * (padding % 4))
    payload_obj = json.loads(payload_bytes.decode("utf-8"))
    return payload_obj if isinstance(payload_obj, dict) else {}


def _nonce_hash(payload: dict[str, object]) -> str | None:
    nonce_obj = payload.get("nonce")
    if not isinstance(nonce_obj, str) or not nonce_obj.strip():
        return None
    return hashlib.sha256(nonce_obj.strip().encode("utf-8")).hexdigest()


def _tier_from_token(payload: dict[str, object]) -> str:
    tier_obj = payload.get("tier", "")
    try:
        return Tier(str(tier_obj)).value
    except ValueError:
        return "unknown"


def _emit_incident(
    *,
    code: str,
    mode: str,
    subject_id: str,
    detail: str,
    claim_issuer: str | None = None,
    claim_audience: str | None = None,
    claim_nonce_hash: str | None = None,
) -> None:
    event = {
        "event": "entitlement_incident",
        "incident_code": code,
        "mode": mode,
        "subject_hash": _hash_subject(subject_id),
        "detail": detail,
        "issuer": claim_issuer,
        "audience": claim_audience,
        "nonce_hash": claim_nonce_hash,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }
    logger.warning(
        "entitlement_incident %s", json.dumps(event, sort_keys=True, separators=(",", ":"))
    )
    alert_url = os.environ.get("SKILLGATE_ENTITLEMENT_INCIDENT_WEBHOOK_URL", "").strip()
    if not alert_url:
        return
    try:
        httpx.post(alert_url, json=event, timeout=2.0)
    except Exception:  # noqa: BLE001
        logger.exception("Failed to send entitlement incident alert")


def _redact_provenance(provenance: dict[str, object]) -> dict[str, object]:
    redacted: dict[str, object] = {}
    sensitive = {"api_key", "authorization", "token", "secret", "password"}
    for key, value in provenance.items():
        if key.lower() in sensitive:
            redacted[key] = "[REDACTED]"
            continue
        redacted[key] = value
    return redacted


class ConsumeScanRequest(BaseModel):
    """Authoritative usage-consume request from CLI or relay."""

    mode: str = Field(min_length=1, max_length=32)
    tier: str = Field(min_length=1, max_length=32)
    scans_per_day_limit: int = Field(ge=0)
    subject_id: str = Field(min_length=1, max_length=128)
    api_key: str | None = None
    client_observed_used: int | None = Field(default=None, ge=0)
    provenance: dict[str, object] = Field(default_factory=dict)


class ConsumeScanResponse(BaseModel):
    """Usage decision response."""

    allowed: bool
    used: int
    limit: int
    reason: str | None = None
    drift: int | None = None
    decision_id: str


class ReconcileUsageRequest(BaseModel):
    """Client-vs-authority usage drift report request."""

    mode: str = Field(min_length=1, max_length=32)
    subject_id: str = Field(min_length=1, max_length=128)
    usage_date: str | None = None
    client_used: int = Field(ge=0)


class ReconcileUsageResponse(BaseModel):
    """Reconciliation response payload."""

    mode: str
    usage_date: str
    server_used: int
    client_used: int
    drift: int
    status: str


class DecisionLogResponse(BaseModel):
    """Paginated decision-log payload."""

    decisions: list[dict[str, object]]
    total: int


@router.post("/consume-scan", response_model=ConsumeScanResponse)
async def consume_scan(
    req: ConsumeScanRequest,
    authorization: str = Header(default="", alias="Authorization"),
    entitlement_token: str = Header(default="", alias="X-SkillGate-Entitlement-Token"),
    entitlement_public_key: str = Header(default="", alias="X-SkillGate-Entitlement-Public-Key"),
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> ConsumeScanResponse:
    """Consume one scan from authoritative ledger and emit an audit decision."""
    expected_token = os.environ.get("SKILLGATE_ENTITLEMENT_AUTHORITY_TOKEN", "").strip()
    if expected_token and authorization != f"Bearer {expected_token}":
        raise HTTPException(status_code=403, detail="Invalid entitlement authority token")

    claim_payload: dict[str, object] = {}
    claim_nonce_h: str | None = None
    claim_issuer: str | None = None
    claim_audience: str | None = None
    effective_tier = req.tier
    effective_limit = req.scans_per_day_limit
    if _is_non_local_mode(req.mode):
        if not entitlement_token:
            _emit_incident(
                code="missing_signed_token",
                mode=req.mode,
                subject_id=req.subject_id,
                detail="Missing signed entitlement token header in non-local mode.",
            )
            raise HTTPException(status_code=403, detail="Signed entitlement token is required")

        configured_key = os.environ.get("SKILLGATE_ENTITLEMENT_PUBLIC_KEY", "").strip()
        env_name = os.environ.get("SKILLGATE_ENV", "development").strip().lower()
        effective_public_key = configured_key
        if not effective_public_key and env_name not in {"production", "staging"}:
            effective_public_key = entitlement_public_key.strip()
        if not effective_public_key:
            raise HTTPException(
                status_code=503,
                detail="Entitlement authority public key is not configured",
            )

        try:
            entitlement = resolve_from_signed_payload(entitlement_token, effective_public_key)
            claim_payload = _decode_signed_payload(entitlement_token)
        except (EntitlementError, ValueError, json.JSONDecodeError) as exc:
            _emit_incident(
                code="invalid_signed_token",
                mode=req.mode,
                subject_id=req.subject_id,
                detail=str(exc),
            )
            raise HTTPException(status_code=403, detail="Invalid signed entitlement token") from exc

        claim_subject = entitlement.subject_id or ""
        if claim_subject != req.subject_id:
            _emit_incident(
                code="subject_mismatch",
                mode=req.mode,
                subject_id=req.subject_id,
                detail="Request subject does not match signed token subject.",
            )
            raise HTTPException(status_code=403, detail="Entitlement subject mismatch")

        claim_issuer_obj = claim_payload.get("iss")
        claim_audience_obj = claim_payload.get("aud")
        claim_issuer = str(claim_issuer_obj) if claim_issuer_obj is not None else None
        claim_audience = str(claim_audience_obj) if claim_audience_obj is not None else None
        claim_nonce_h = _nonce_hash(claim_payload)
        effective_tier = entitlement.tier.value
        effective_limit = entitlement.limits.scans_per_day

    usage_date = _utc_day()
    subject_key = _hash_subject(req.subject_id)

    ledger = await session.scalar(
        select(EntitlementUsageLedger).where(
            EntitlementUsageLedger.subject_key == subject_key,
            EntitlementUsageLedger.mode == req.mode,
            EntitlementUsageLedger.usage_date == usage_date,
        )
    )
    if ledger is None:
        ledger = EntitlementUsageLedger(
            id=str(uuid4()),
            subject_key=subject_key,
            mode=req.mode,
            usage_date=usage_date,
            tier=effective_tier,
            used_scans=0,
            scan_limit=effective_limit,
        )
        session.add(ledger)

    limit = effective_limit
    ledger.scan_limit = limit
    ledger.tier = effective_tier

    allowed = limit <= 0 or ledger.used_scans < limit
    reason: str | None = None
    if allowed and limit > 0:
        ledger.used_scans += 1
    elif not allowed:
        reason = "quota_reached"

    used = ledger.used_scans
    drift = None
    if req.client_observed_used is not None:
        drift = req.client_observed_used - used

    decision_id = str(uuid4())
    session.add(
        EntitlementDecisionLog(
            id=decision_id,
            subject_key=subject_key,
            mode=req.mode,
            tier=effective_tier,
            allowed=allowed,
            reason=reason,
            used_scans=used,
            scan_limit=limit,
            drift=drift,
            provenance=_redact_provenance(
                {
                    **req.provenance,
                    "claim_issuer": claim_issuer,
                    "claim_audience": claim_audience,
                    "claim_nonce_hash": claim_nonce_h,
                    "claim_tier": _tier_from_token(claim_payload) if claim_payload else None,
                }
            ),
        )
    )
    await session.commit()

    return ConsumeScanResponse(
        allowed=allowed,
        used=used,
        limit=limit,
        reason=reason,
        drift=drift,
        decision_id=decision_id,
    )


@router.post("/reconcile-usage", response_model=ReconcileUsageResponse)
async def reconcile_usage(
    req: ReconcileUsageRequest,
    admin_key: str = Header(default="", alias="X-Admin-Key"),
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> ReconcileUsageResponse:
    """Report usage drift between client-observed and authoritative counts."""
    _require_admin(admin_key)
    usage_date = req.usage_date or _utc_day()
    subject_key = _hash_subject(req.subject_id)
    ledger = await session.scalar(
        select(EntitlementUsageLedger).where(
            EntitlementUsageLedger.subject_key == subject_key,
            EntitlementUsageLedger.mode == req.mode,
            EntitlementUsageLedger.usage_date == usage_date,
        )
    )
    server_used = ledger.used_scans if ledger is not None else 0
    drift = req.client_used - server_used
    status = "in_sync" if drift == 0 else "drift_detected"
    return ReconcileUsageResponse(
        mode=req.mode,
        usage_date=usage_date,
        server_used=server_used,
        client_used=req.client_used,
        drift=drift,
        status=status,
    )


@router.get("/decision-logs", response_model=DecisionLogResponse)
async def list_decision_logs(
    limit: int = 100,
    offset: int = 0,
    admin_key: str = Header(default="", alias="X-Admin-Key"),
    session: AsyncSession = Depends(get_session),  # noqa: B008
) -> DecisionLogResponse:
    """List entitlement decision logs for audit export."""
    _require_admin(admin_key)
    effective_limit = min(max(limit, 1), 500)
    rows = await session.scalars(
        select(EntitlementDecisionLog)
        .order_by(EntitlementDecisionLog.created_at.desc())
        .offset(offset)
        .limit(effective_limit)
    )
    decisions: list[dict[str, object]] = []
    for row in rows.all():
        decisions.append(
            {
                "id": row.id,
                "subject_key": row.subject_key,
                "mode": row.mode,
                "tier": row.tier,
                "allowed": row.allowed,
                "reason": row.reason,
                "used_scans": row.used_scans,
                "scan_limit": row.scan_limit,
                "drift": row.drift,
                "provenance": row.provenance,
                "created_at": row.created_at.replace(tzinfo=timezone.utc).isoformat(),
            }
        )
    return DecisionLogResponse(total=len(decisions), decisions=decisions)
