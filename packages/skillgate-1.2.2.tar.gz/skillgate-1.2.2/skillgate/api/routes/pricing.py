"""Public pricing catalog endpoint for backend-managed web UI pricing."""

from __future__ import annotations

from fastapi import APIRouter

from skillgate.api.pricing_catalog import PricingCatalog, pricing_catalog_payload

router = APIRouter(prefix="/pricing", tags=["pricing"])


@router.get("/catalog", response_model=PricingCatalog)
async def get_pricing_catalog() -> PricingCatalog:
    """Return canonical pricing catalog for web UI rendering."""
    return pricing_catalog_payload()
