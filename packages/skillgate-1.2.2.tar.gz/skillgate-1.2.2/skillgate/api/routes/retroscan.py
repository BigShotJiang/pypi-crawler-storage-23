"""Retro-scan API endpoints — trigger, poll, and list retro-scan jobs."""

from __future__ import annotations

import json
import logging
import uuid

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from skillgate.api.db import get_session
from skillgate.api.entitlement import resolve_user_entitlement
from skillgate.api.models import ScanRecord, User
from skillgate.api.routes.auth import get_current_user
from skillgate.core.entitlement.models import Capability
from skillgate.core.retroscan.engine import retroscan
from skillgate.core.retroscan.models import (
    RetroDiff,
    RetroJob,
    RetroJobStatus,
    RetroJobTrigger,
)
from skillgate.core.retroscan.store import RetroJobStore

router = APIRouter(prefix="/retroscan", tags=["retroscan"])
logger = logging.getLogger(__name__)

# Module-level store instance (swappable for testing)
_store = RetroJobStore()


def get_store() -> RetroJobStore:
    """Return the retro-scan job store."""
    return _store


class RetroTriggerRequest(BaseModel):
    """Request body for triggering a retro-scan."""

    trigger: RetroJobTrigger = Field(default=RetroJobTrigger.MANUAL)
    rule_ids: list[str] = Field(
        default_factory=list,
        description="Rule IDs that were updated (context for the retro-scan).",
    )


class RetroTriggerResponse(BaseModel):
    """Response after triggering a retro-scan."""

    job: RetroJob
    already_exists: bool = False


class RetroStatusResponse(BaseModel):
    """Response for job status polling."""

    job: RetroJob
    diffs: list[RetroDiff] = Field(default_factory=list)


class RetroListResponse(BaseModel):
    """Response for listing retro-scan jobs."""

    jobs: list[RetroJob]
    total: int


@router.post("")
async def trigger_retroscan(
    req: RetroTriggerRequest,
    user: User = Depends(get_current_user),  # noqa: B008
    session: AsyncSession = Depends(get_session),  # noqa: B008
    store: RetroJobStore = Depends(get_store),  # noqa: B008
) -> RetroTriggerResponse:
    """Trigger a retro-scan job.

    Idempotent: if a job with the same trigger+rule_ids already exists
    and is still pending/running, returns that job.
    """
    entitlement = await resolve_user_entitlement(user, session)
    if not entitlement.has_capability(Capability.RETROSCAN):
        raise HTTPException(
            status_code=403,
            detail="Retroscan requires Team or Enterprise tier.",
        )

    # Dedup check
    existing = store.find_duplicate(req.trigger, req.rule_ids)
    if existing is not None and existing.status in {
        RetroJobStatus.PENDING,
        RetroJobStatus.RUNNING,
    }:
        return RetroTriggerResponse(job=existing, already_exists=True)

    job_id = str(uuid.uuid4())
    job = store.create_job(
        job_id=job_id,
        trigger=req.trigger,
        rule_ids=req.rule_ids,
    )

    # Load user's scan reports
    scan_reports = await _load_user_reports(user, session)

    # Simple re-analysis: re-extract findings from stored reports
    # (In production, this would re-run the full analysis pipeline)
    def analyze_fn(report: dict[str, object]) -> list[dict[str, object]]:
        findings = report.get("findings")
        if isinstance(findings, list):
            return [f for f in findings if isinstance(f, dict)]
        return []

    try:
        result = retroscan(job, scan_reports, analyze_fn)
        store.store_result(result)
    except Exception as exc:
        store.mark_failed(job_id, str(exc))
        logger.exception("Retro-scan job %s failed", job_id)
        raise HTTPException(
            status_code=500,
            detail=f"Retro-scan failed: {exc}",
        ) from exc

    return RetroTriggerResponse(job=result.job)


@router.get("/{job_id}")
async def get_retroscan_status(
    job_id: str,
    user: User = Depends(get_current_user),  # noqa: B008
    store: RetroJobStore = Depends(get_store),  # noqa: B008
) -> RetroStatusResponse:
    """Get the status and results of a retro-scan job."""
    job = store.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail="Job not found")

    result = store.get_result(job_id)
    diffs = result.diffs if result is not None else []

    return RetroStatusResponse(job=job, diffs=diffs)


@router.get("")
async def list_retroscans(
    status: RetroJobStatus | None = None,
    limit: int = 50,
    user: User = Depends(get_current_user),  # noqa: B008
    store: RetroJobStore = Depends(get_store),  # noqa: B008
) -> RetroListResponse:
    """List retro-scan jobs, optionally filtered by status."""
    jobs = store.list_jobs(status=status, limit=limit)
    return RetroListResponse(jobs=jobs, total=len(jobs))


async def _load_user_reports(
    user: User,
    session: AsyncSession,
) -> list[dict[str, object]]:
    """Load scan reports for a user from the database."""
    rows = await session.scalars(
        select(ScanRecord)
        .where(ScanRecord.user_id == user.id)
        .order_by(ScanRecord.created_at.desc())
        .limit(1000)
    )
    reports: list[dict[str, object]] = []
    for row in rows.all():
        try:
            report = json.loads(row.report_json)
            if isinstance(report, dict):
                report["scan_id"] = row.id
                reports.append(report)
        except (json.JSONDecodeError, AttributeError):
            logger.warning("Skipping malformed scan record %s", row.id)
    return reports
