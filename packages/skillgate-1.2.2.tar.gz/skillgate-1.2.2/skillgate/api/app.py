"""FastAPI application factory and configuration."""

from __future__ import annotations

import inspect
import logging
import time
import uuid
from collections.abc import AsyncGenerator, Awaitable, Callable
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from starlette.exceptions import HTTPException as StarletteHTTPException
from starlette.responses import Response

from skillgate.api.db import init_db, should_auto_init_db, verify_database_connectivity
from skillgate.api.errors import error_code_for_status, error_response
from skillgate.api.middleware import BotMitigationMiddleware
from skillgate.api.redis_circuit_breaker import RedisCircuitBreaker
from skillgate.api.routes.alerts import router as alerts_router
from skillgate.api.routes.api_keys import router as api_keys_router
from skillgate.api.routes.audit import router as audit_router
from skillgate.api.routes.auth import router as auth_router
from skillgate.api.routes.entitlements import router as entitlements_router
from skillgate.api.routes.health import router as health_router
from skillgate.api.routes.hunt import router as hunt_router
from skillgate.api.routes.license import router as license_router
from skillgate.api.routes.payments import router as payments_router
from skillgate.api.routes.pricing import router as pricing_router
from skillgate.api.routes.retroscan import router as retroscan_router
from skillgate.api.routes.roadmap import router as roadmap_router
from skillgate.api.routes.scans import router as scans_router
from skillgate.api.routes.teams import router as teams_router
from skillgate.api.routes.usage import router as usage_router
from skillgate.api.routes.verify import router as verify_router
from skillgate.api.settings import get_settings
from skillgate.api.telemetry import instrument_app
from skillgate.version import __version__

Redis: Any | None = None
try:
    from redis.asyncio import Redis as _Redis
except ImportError:  # pragma: no cover
    pass
else:
    Redis = _Redis

API_VERSION = "v1"
logger = logging.getLogger(__name__)

# Global circuit breaker for Stripe API calls (shared across routes)
stripe_circuit_breaker: RedisCircuitBreaker | None = None


def get_stripe_circuit_breaker() -> RedisCircuitBreaker | None:
    """Get global Stripe circuit breaker instance (None if Redis unavailable)."""
    return stripe_circuit_breaker


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None, None]:
    """Application lifespan — startup and shutdown hooks."""
    global stripe_circuit_breaker
    settings = get_settings()

    # Suppress verbose library logging in production
    if settings.environment in {"production", "staging"}:
        logging.getLogger("sqlalchemy").setLevel(logging.WARNING)
        logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
        logging.getLogger("asyncpg").setLevel(logging.WARNING)
        logging.getLogger("uvicorn.access").setLevel(logging.WARNING)

    settings.validate_startup()
    await verify_database_connectivity()
    if should_auto_init_db():
        logger.warning(
            "SKILLGATE_AUTO_INIT_DB enabled; using SQLAlchemy create_all for local/dev startup."
        )
        await init_db()

    # Initialize Redis circuit breaker for Stripe calls
    if Redis is not None:
        try:
            redis_client = Redis.from_url(settings.redis_url, decode_responses=False)
            ping_result = redis_client.ping()
            if inspect.isawaitable(ping_result):
                await ping_result
            stripe_circuit_breaker = RedisCircuitBreaker(
                redis=redis_client,
                name="stripe",
                failure_threshold=5,
                recovery_seconds=45,
            )
            logger.info("Redis circuit breaker initialized for Stripe API calls")
        except Exception as e:
            logger.warning(f"Redis init failed, circuit breaker disabled: {e}")
            stripe_circuit_breaker = None

    yield

    # Shutdown: cleanup redis connection
    if stripe_circuit_breaker is not None and hasattr(stripe_circuit_breaker._redis, "close"):
        await stripe_circuit_breaker._redis.close()


def create_app() -> FastAPI:
    """Create and configure the FastAPI application.

    Returns:
        Configured FastAPI instance.
    """
    app = FastAPI(
        title="SkillGate API",
        description="Hosted API for SkillGate — agent skill security governance.",
        version=__version__,
        docs_url=f"/api/{API_VERSION}/docs",
        openapi_url=f"/api/{API_VERSION}/openapi.json",
        lifespan=lifespan,
    )

    settings = get_settings()

    # Bot mitigation — inner middleware (CORS must be outermost to wrap all responses)
    app.add_middleware(BotMitigationMiddleware)

    # CORS — outermost middleware so Access-Control-Allow-Origin is present on every
    # response, including 403s from bot mitigation and 5xx error paths.
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=settings.cors_allow_credentials,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    @app.middleware("http")
    async def request_context_middleware(
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        request_id = request.headers.get("X-Request-ID") or str(uuid.uuid4())
        request.state.request_id = request_id
        start = time.perf_counter()
        try:
            response = await call_next(request)
        except Exception:  # noqa: BLE001
            duration_ms = (time.perf_counter() - start) * 1000
            logger.exception(
                "request.failed method=%s path=%s duration_ms=%.2f request_id=%s",
                request.method,
                request.url.path,
                duration_ms,
                request_id,
            )
            error = error_response(
                status_code=500,
                message="Internal server error",
                request_id=request_id,
                code="INTERNAL_ERROR",
            )
            error.headers["X-Request-ID"] = request_id
            return error

        duration_ms = (time.perf_counter() - start) * 1000
        response.headers["X-Request-ID"] = request_id

        # Security headers (OWASP recommended)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Permissions-Policy"] = (
            "camera=(), microphone=(), geolocation=(), payment=()"
        )
        response.headers["X-XSS-Protection"] = "0"  # Disabled; CSP preferred
        response.headers["Content-Security-Policy"] = "default-src 'none'; frame-ancestors 'none'"
        if settings.enable_hsts:
            response.headers["Strict-Transport-Security"] = (
                "max-age=63072000; includeSubDomains; preload"
            )

        logger.info(
            "request.completed method=%s path=%s status=%s duration_ms=%.2f request_id=%s",
            request.method,
            request.url.path,
            response.status_code,
            duration_ms,
            request_id,
        )
        return response

    @app.exception_handler(StarletteHTTPException)
    async def http_exception_handler(
        request: Request,
        exc: StarletteHTTPException,
    ) -> Response:
        request_id = getattr(request.state, "request_id", str(uuid.uuid4()))
        message = str(exc.detail) if exc.detail else "Request failed"
        return error_response(
            status_code=exc.status_code,
            message=message,
            request_id=request_id,
            code=error_code_for_status(exc.status_code),
            headers=exc.headers,
        )

    @app.exception_handler(RequestValidationError)
    async def validation_exception_handler(
        request: Request,
        exc: RequestValidationError,
    ) -> Response:
        request_id = getattr(request.state, "request_id", str(uuid.uuid4()))
        message = "Validation failed"
        logger.warning(
            "request.validation_failed errors=%s request_id=%s",
            exc.errors(),
            request_id,
        )
        return error_response(
            status_code=422,
            message=message,
            request_id=request_id,
            code="VALIDATION_ERROR",
            retryable=False,
        )

    # Optional OpenTelemetry instrumentation
    instrument_app(app)

    # Register route groups
    app.include_router(audit_router, prefix=f"/api/{API_VERSION}")
    app.include_router(alerts_router, prefix=f"/api/{API_VERSION}")
    app.include_router(auth_router, prefix=f"/api/{API_VERSION}")
    app.include_router(entitlements_router, prefix=f"/api/{API_VERSION}")
    app.include_router(api_keys_router, prefix=f"/api/{API_VERSION}")
    app.include_router(health_router, prefix=f"/api/{API_VERSION}")
    app.include_router(hunt_router, prefix=f"/api/{API_VERSION}")
    app.include_router(license_router, prefix=f"/api/{API_VERSION}")
    app.include_router(retroscan_router, prefix=f"/api/{API_VERSION}")
    app.include_router(roadmap_router, prefix=f"/api/{API_VERSION}")
    app.include_router(payments_router, prefix=f"/api/{API_VERSION}")
    app.include_router(pricing_router, prefix=f"/api/{API_VERSION}")
    app.include_router(scans_router, prefix=f"/api/{API_VERSION}")
    app.include_router(teams_router, prefix=f"/api/{API_VERSION}")
    app.include_router(usage_router, prefix=f"/api/{API_VERSION}")
    app.include_router(verify_router, prefix=f"/api/{API_VERSION}")

    return app
