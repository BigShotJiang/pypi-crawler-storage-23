"""Supabase Auth REST client service.

Wraps the Supabase Auth v1 API endpoints used by SkillGate's backend.
All external HTTP calls use the service-role key so they bypass RLS and
execute with full authority — callers must validate inputs before calling.

Error translation contract:
  - 401 / invalid credentials → AuthError
  - 422 / validation failures  → ValueError with safe message
  - 429 / rate-limited         → raises with retryable=True metadata
  - 5xx / network errors       → SupabaseClientError (retriable)

No raw upstream error bodies are propagated; messages are normalised before
surfacing to route handlers.
"""

from __future__ import annotations

import asyncio
import logging
import os
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from typing import Any, cast

import httpx

from skillgate.api.errors import AuthError
from skillgate.api.supabase_egress import (
    CircuitBreaker,
    CircuitBreakerOpenError,
    EgressPolicy,
    is_host_allowed,
    retry_backoff_seconds,
)

logger = logging.getLogger(__name__)

# Per-request timeout budget (seconds): connect + read.
_CONNECT_TIMEOUT = 3.0
_READ_TIMEOUT = 8.0
_TIMEOUT = httpx.Timeout(connect=_CONNECT_TIMEOUT, read=_READ_TIMEOUT, write=5.0, pool=2.0)

# Max retries for transient 5xx / connection errors.
_MAX_RETRIES = 2


class SupabaseClientError(Exception):
    """Retriable upstream error from Supabase Auth API."""

    def __init__(self, message: str, *, retryable: bool = True, status_code: int = 0) -> None:
        super().__init__(message)
        self.retryable = retryable
        self.status_code = status_code


def _supabase_auth_url(base_url: str, path: str) -> str:
    return f"{base_url.rstrip('/')}/auth/v1{path}"


def _normalize_error(resp: httpx.Response) -> str:
    """Extract a safe, non-leaking error description from an upstream response."""
    try:
        body = resp.json()
        # Supabase returns {"error": "...", "error_description": "..."}
        msg = body.get("error_description") or body.get("msg") or body.get("error") or ""
        if isinstance(msg, str) and msg:
            return msg[:200]
    except Exception:
        pass
    return f"Upstream error {resp.status_code}"


class SupabaseAuthClient:
    """Thin async client for Supabase Auth v1 REST API operations.

    Intended to be instantiated once per request (or per test) and
    closed when done — use as an async context manager or call ``aclose()``.
    """

    def __init__(self, *, base_url: str, service_role_key: str) -> None:
        """Initialise with the Supabase project URL and service-role key."""
        self._base_url = base_url.rstrip("/")
        self._service_role_key = service_role_key
        base_host = httpx.URL(self._base_url).host or ""
        extra_allowlist = {
            item.strip().lower()
            for item in os.environ.get("SKILLGATE_SUPABASE_EGRESS_ALLOWLIST", "").split(",")
            if item.strip()
        }
        allowed_hosts = frozenset({base_host.lower(), *extra_allowlist} - {""})
        self._egress_policy = EgressPolicy(
            allowed_hosts=allowed_hosts,
            max_retries=_MAX_RETRIES,
        )
        self._breaker = CircuitBreaker(
            failure_threshold=self._egress_policy.circuit_breaker_failures,
            open_window_seconds=self._egress_policy.circuit_breaker_window_seconds,
        )
        self._client = httpx.AsyncClient(
            timeout=_TIMEOUT,
            headers={
                "apikey": service_role_key,
                "Authorization": f"Bearer {service_role_key}",
                "Content-Type": "application/json",
            },
        )

    async def aclose(self) -> None:
        """Release underlying HTTP connections."""
        await self._client.aclose()

    async def _request(
        self,
        method: str,
        path: str,
        *,
        json: dict[str, Any] | None = None,
        params: dict[str, str] | None = None,
    ) -> dict[str, Any]:
        """Execute a request with simple retry on transient errors."""
        url = _supabase_auth_url(self._base_url, path)
        if not is_host_allowed(url=url, policy=self._egress_policy):
            raise SupabaseClientError("Blocked Supabase egress destination", retryable=False)

        last_exc: Exception | None = None
        for attempt in range(self._egress_policy.max_retries + 1):
            try:
                self._breaker.assert_allow()
            except CircuitBreakerOpenError as exc:
                raise SupabaseClientError(str(exc), retryable=False) from exc

            try:
                resp = await self._client.request(method, url, json=json, params=params)
            except httpx.TransportError as exc:
                self._breaker.record_failure()
                last_exc = exc
                logger.warning(
                    "supabase_client.transport_error attempt=%d path=%s error=%s",
                    attempt,
                    path,
                    type(exc).__name__,
                )
                if attempt < self._egress_policy.max_retries:
                    await asyncio.sleep(
                        retry_backoff_seconds(
                            attempt=attempt,
                            initial_backoff_seconds=self._egress_policy.initial_backoff_seconds,
                        )
                    )
                continue

            if resp.status_code in {400, 401, 403}:
                raise AuthError(_normalize_error(resp))
            if resp.status_code == 422:
                raise ValueError(_normalize_error(resp))
            if resp.status_code == 429:
                self._breaker.record_failure()
                raise SupabaseClientError(
                    "Supabase rate limit exceeded",
                    retryable=True,
                    status_code=429,
                )
            if resp.status_code >= 500:
                self._breaker.record_failure()
                last_exc = SupabaseClientError(
                    f"Supabase upstream error {resp.status_code}", retryable=True
                )
                if attempt < self._egress_policy.max_retries:
                    logger.warning(
                        "supabase_client.server_error attempt=%d path=%s status=%d",
                        attempt,
                        path,
                        resp.status_code,
                    )
                    await asyncio.sleep(
                        retry_backoff_seconds(
                            attempt=attempt,
                            initial_backoff_seconds=self._egress_policy.initial_backoff_seconds,
                        )
                    )
                    continue
                raise last_exc

            try:
                self._breaker.record_success()
                return cast(dict[str, Any], resp.json())
            except Exception as exc:
                self._breaker.record_failure()
                raise SupabaseClientError("Invalid JSON from Supabase") from exc

        raise SupabaseClientError("Supabase request failed after retries") from last_exc

    # ------------------------------------------------------------------
    # Auth operations
    # ------------------------------------------------------------------

    async def sign_up(
        self, *, email: str, password: str, full_name: str | None = None
    ) -> dict[str, Any]:
        """Register a new user via Supabase Auth signUp endpoint."""
        payload: dict[str, Any] = {"email": email, "password": password}
        if full_name:
            payload["data"] = {"full_name": full_name}
        logger.info("supabase_client.sign_up email=%s", email)
        return await self._request("POST", "/signup", json=payload)

    async def sign_in_with_password(self, *, email: str, password: str) -> dict[str, Any]:
        """Authenticate with email + password and return session tokens."""
        logger.info("supabase_client.sign_in email=%s", email)
        return await self._request(
            "POST",
            "/token?grant_type=password",
            json={"email": email, "password": password},
        )

    async def refresh_session(self, *, refresh_token: str) -> dict[str, Any]:
        """Exchange a refresh token for a new access + refresh token pair."""
        return await self._request(
            "POST",
            "/token?grant_type=refresh_token",
            json={"refresh_token": refresh_token},
        )

    async def sign_out(self, *, access_token: str) -> None:
        """Invalidate user session (revoke access + refresh tokens)."""
        # Use user-scoped token for sign-out so only the caller's session is revoked.
        url = _supabase_auth_url(self._base_url, "/logout")
        headers = {
            "apikey": self._service_role_key,
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }
        try:
            resp = await self._client.post(url, headers=headers)
        except httpx.TransportError as exc:
            raise SupabaseClientError("Sign-out request failed") from exc
        if resp.status_code not in {200, 204}:
            logger.warning("supabase_client.sign_out_error status=%d", resp.status_code)

    async def request_password_reset(self, *, email: str, redirect_to: str | None = None) -> None:
        """Trigger Supabase password-reset email flow."""
        payload: dict[str, Any] = {"email": email}
        if redirect_to:
            payload["redirect_to"] = redirect_to
        logger.info("supabase_client.password_reset email=%s", email)
        await self._request("POST", "/recover", json=payload)

    async def update_user(self, *, access_token: str, data: dict[str, Any]) -> dict[str, Any]:
        """Update user metadata (full_name, email, password, custom data).

        Uses the user's own access token so RLS policies apply.
        """
        url = _supabase_auth_url(self._base_url, "/user")
        headers = {
            "apikey": self._service_role_key,
            "Authorization": f"Bearer {access_token}",
            "Content-Type": "application/json",
        }
        try:
            resp = await self._client.put(url, json=data, headers=headers)
        except httpx.TransportError as exc:
            raise SupabaseClientError("User update request failed") from exc
        if resp.status_code in {401, 403}:
            raise AuthError(_normalize_error(resp))
        if resp.status_code >= 400:
            raise SupabaseClientError(f"Update user failed: {resp.status_code}", retryable=False)
        return cast(dict[str, Any], resp.json())

    async def admin_get_user(self, *, user_id: str) -> dict[str, Any]:
        """Fetch full user record via admin API (service-role scoped)."""
        return await self._request("GET", f"/admin/users/{user_id}")

    async def admin_delete_user(self, *, user_id: str) -> None:
        """Hard-delete a user via admin API (service-role scoped)."""
        await self._request("DELETE", f"/admin/users/{user_id}")

    async def exchange_code_for_session(self, *, code: str) -> dict[str, Any]:
        """Exchange an OAuth authorisation code for a Supabase session."""
        return await self._request(
            "POST",
            "/token?grant_type=pkce",
            json={"auth_code": code},
        )


@asynccontextmanager
async def supabase_auth_client(
    *, base_url: str, service_role_key: str
) -> AsyncGenerator[SupabaseAuthClient, None]:
    """Async context manager that yields a ``SupabaseAuthClient`` and cleans up."""
    client = SupabaseAuthClient(base_url=base_url, service_role_key=service_role_key)
    try:
        yield client
    finally:
        await client.aclose()
