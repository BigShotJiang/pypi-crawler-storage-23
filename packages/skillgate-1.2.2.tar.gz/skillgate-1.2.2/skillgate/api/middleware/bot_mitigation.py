"""Bot detection and mitigation middleware."""

from __future__ import annotations

import logging
from collections.abc import Awaitable, Callable

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

logger = logging.getLogger(__name__)

# Blocked User-Agent patterns (case-insensitive substring match)
BLOCKED_USER_AGENTS = [
    "scrapy",
    "crawler",
    "bot",
    "spider",
    "scraper",
    "curl",
    "wget",
    "python-requests",
    "postman",
    "insomnia",
    "masscan",
    "nikto",
    "nmap",
    "sqlmap",
    "gobuster",
    "dirbuster",
]

# Allowlist patterns (bypass bot detection)
ALLOWED_USER_AGENTS = [
    "skillgate-cli/",
    "skillgate-sdk/",
    "github-actions",
    "gitlab-runner",
    "circleci",
]


class BotMitigationMiddleware(BaseHTTPMiddleware):
    """Reject requests with suspicious User-Agent headers."""

    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        """Check User-Agent and block suspicious patterns."""
        user_agent = request.headers.get("user-agent", "").lower()

        # Allow explicitly trusted agents
        for allowed in ALLOWED_USER_AGENTS:
            if allowed.lower() in user_agent:
                return await call_next(request)

        # Block suspicious agents
        for blocked in BLOCKED_USER_AGENTS:
            if blocked in user_agent:
                logger.warning(f"Blocked request from suspicious User-Agent: {user_agent}")
                return JSONResponse(
                    status_code=403,
                    content={
                        "error": {
                            "message": "Forbidden",
                            "code": "BOT_DETECTED",
                            "retryable": False,
                        }
                    },
                )

        return await call_next(request)
