"""Enterprise-specific entitlement features."""

from __future__ import annotations

import csv
import io
import json
from typing import Any

from skillgate.core.entitlement.models import Capability, Entitlement
from skillgate.core.errors import EntitlementError


def validate_custom_policy_pack(policy: dict[str, Any], entitlement: Entitlement) -> None:
    """Validate that user can use custom policy packs.

    Args:
        policy: Custom policy configuration
        entitlement: User's current entitlement

    Raises:
        EntitlementError: If not ENTERPRISE tier
    """
    if not entitlement.has_capability(Capability.CUSTOM_POLICY):
        raise EntitlementError(
            "Custom policy packs require Enterprise tier. "
            "Contact sales at https://skillgate.io/enterprise",
            tier=entitlement.tier.value.upper(),
            capability="custom_policy",
        )


def get_key_namespace(entitlement: Entitlement, team_id: str | None = None) -> str:
    """Get signing key namespace for entitlement.

    Args:
        entitlement: User's entitlement
        team_id: Optional team ID for team-scoped keys

    Returns:
        Namespace string for key isolation
    """
    if not entitlement.has_capability(Capability.KEY_NAMESPACES):
        return "default"

    if team_id:
        return f"team-{team_id}"
    return f"tier-{entitlement.tier.value}"


class AuditExporter:
    """Export audit data in various formats."""

    def __init__(self, records: list[dict[str, Any]]) -> None:
        self._records = records

    def export_jsonl(self) -> str:
        """Export records as JSONL (one JSON object per line)."""
        lines = [json.dumps(r, separators=(",", ":")) for r in self._records]
        return "\n".join(lines)

    def export_csv(self) -> str:
        """Export records as CSV."""
        if not self._records:
            return ""

        output = io.StringIO()
        fieldnames = list(self._records[0].keys())
        writer = csv.DictWriter(output, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(self._records)
        return output.getvalue()
