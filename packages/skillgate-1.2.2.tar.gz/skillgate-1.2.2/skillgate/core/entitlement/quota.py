"""Scan quota tracking for free tier limits."""

from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from skillgate.core.errors import EntitlementError


class ScanQuotaTracker:
    """Track daily scan quota with file persistence."""

    def __init__(self, quota_file: Path | None = None) -> None:
        self._quota_file = quota_file or self._default_quota_file()
        try:
            self._quota_file.parent.mkdir(parents=True, exist_ok=True)
            probe = self._quota_file.parent / ".sg_quota_probe"
            probe.write_text("ok")
            probe.unlink(missing_ok=True)
        except OSError:
            # Sandbox/home can be read-only; fall back to temp dir.
            self._quota_file = Path(tempfile.gettempdir()) / "skillgate" / "quota.json"
            self._quota_file.parent.mkdir(parents=True, exist_ok=True)

    def _default_quota_file(self) -> Path:
        env_path = os.environ.get("SKILLGATE_QUOTA_FILE")
        if env_path:
            return Path(env_path)
        return Path.home() / ".skillgate" / "quota.json"

    def _today_utc(self) -> str:
        """Return today's date in UTC as ISO date string."""
        return datetime.now(timezone.utc).date().isoformat()

    def _read_quota(self) -> dict[str, str | int]:
        """Read quota file, return default on error."""
        try:
            if self._quota_file.exists():
                data = json.loads(self._quota_file.read_text())
                if isinstance(data, dict):
                    return {"date": data.get("date", ""), "count": data.get("count", 0)}
        except (json.JSONDecodeError, OSError):
            pass
        return {"date": "", "count": 0}

    def _write_quota(self, date: str, count: int) -> None:
        """Write quota file atomically."""
        temp_file = self._quota_file.with_suffix(".tmp")
        try:
            temp_file.write_text(json.dumps({"date": date, "count": count}))
            temp_file.replace(self._quota_file)
        finally:
            if temp_file.exists():
                temp_file.unlink()

    def get_count(self) -> int:
        """Get current scan count for today (resets at midnight UTC)."""
        data = self._read_quota()
        today = self._today_utc()
        if data.get("date") != today:
            return 0
        return int(data.get("count", 0))

    def increment(self) -> int:
        """Increment scan count and return new value."""
        today = self._today_utc()
        data = self._read_quota()
        count = 1 if data.get("date") != today else int(data.get("count", 0)) + 1
        self._write_quota(today, count)
        return count

    def check_quota(self, daily_limit: int) -> None:
        """Check if quota allows a scan.

        Args:
            daily_limit: Maximum scans per day (>0 to enforce)

        Raises:
            EntitlementError: If quota exceeded
        """
        if daily_limit <= 0:
            return  # Unlimited

        current = self.get_count()
        if current >= daily_limit:
            raise EntitlementError(
                f"Daily scan quota exceeded ({current}/{daily_limit}). "
                f"Upgrade to Pro for unlimited scans at https://skillgate.io/pricing",
                tier="FREE",
            )

    def record_scan(self) -> int:
        """Record a scan and return the new count."""
        return self.increment()

    def reset(self) -> None:
        """Force reset quota (for testing)."""
        self._write_quota("", 0)
