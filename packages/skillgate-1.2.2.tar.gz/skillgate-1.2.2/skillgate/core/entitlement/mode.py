"""Entitlement enforcement mode contracts.

Modes control where entitlement and usage authority comes from:
- local: local API-key tier + local quota cache
- saas: hosted authority endpoint
- private_relay: enterprise internal authority endpoint (no direct internet from CI)
- airgap: signed/offline entitlement packs
"""

from __future__ import annotations

import os
from enum import Enum

from skillgate.core.errors import ConfigError


class EntitlementEnforcementMode(str, Enum):
    """Supported entitlement enforcement modes."""

    LOCAL = "local"
    SAAS = "saas"
    PRIVATE_RELAY = "private_relay"
    AIRGAP = "airgap"


def _deployment_env() -> str:
    return os.environ.get("SKILLGATE_ENV", "development").strip().lower()


def _default_mode_for_env(env: str) -> EntitlementEnforcementMode:
    if env in {"production", "staging"}:
        return EntitlementEnforcementMode.SAAS
    return EntitlementEnforcementMode.LOCAL


def _locked_mode() -> EntitlementEnforcementMode | None:
    raw = os.environ.get("SKILLGATE_ENTITLEMENT_MODE_LOCK", "").strip().lower()
    if not raw:
        return None
    try:
        mode = EntitlementEnforcementMode(raw)
    except ValueError as exc:
        raise ConfigError(
            "Invalid SKILLGATE_ENTITLEMENT_MODE_LOCK. Use one of: saas, private_relay, airgap."
        ) from exc
    if mode == EntitlementEnforcementMode.LOCAL:
        raise ConfigError("SKILLGATE_ENTITLEMENT_MODE_LOCK cannot be 'local'.")
    return mode


def get_enforcement_mode() -> EntitlementEnforcementMode:
    """Resolve enforcement mode from environment.

    Contract:
    - development/test defaults to local
    - production/staging defaults to saas
    - production/staging ignore SKILLGATE_ENTITLEMENT_MODE overrides
    - optional lock can enforce saas/private_relay/airgap only
    """
    env = _deployment_env()
    locked = _locked_mode()

    if env in {"production", "staging"}:
        if locked is not None:
            return locked
        return _default_mode_for_env(env)

    default_mode = _default_mode_for_env(env)
    raw = os.environ.get("SKILLGATE_ENTITLEMENT_MODE", default_mode.value)
    value = raw.strip().lower()
    try:
        mode = EntitlementEnforcementMode(value)
    except ValueError as exc:
        raise ConfigError(
            "Invalid SKILLGATE_ENTITLEMENT_MODE. Use one of: local, saas, private_relay, airgap."
        ) from exc

    if locked is not None and mode != locked:
        raise ConfigError(
            f"Entitlement mode locked to '{locked.value}' via SKILLGATE_ENTITLEMENT_MODE_LOCK."
        )
    return mode
