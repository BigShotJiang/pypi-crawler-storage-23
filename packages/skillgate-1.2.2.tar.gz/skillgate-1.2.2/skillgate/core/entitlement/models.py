"""Entitlement models for tier-based capability gating."""

from __future__ import annotations

from collections.abc import Callable
from datetime import datetime
from enum import Enum

from pydantic import BaseModel, Field

from skillgate.config.license import Tier


class EntitlementSource(str, Enum):
    """Source of entitlement data."""

    API_KEY = "api_key"
    SIGNED_PAYLOAD = "signed_payload"
    LOCAL_CACHE = "local_cache"
    DEFAULT = "default"


class Capability(str, Enum):
    """Feature capabilities gated by tier."""

    SCAN = "scan"
    ENFORCE = "enforce"
    SIGN = "sign"
    EXPLAIN = "explain"
    CI_ANNOTATIONS = "ci_annotations"
    CI_BLOCKING = "ci_blocking"
    FLEET_SCAN = "fleet_scan"
    CUSTOM_POLICY = "custom_policy"
    AUDIT_EXPORT = "audit_export"
    KEY_NAMESPACES = "key_namespaces"
    RETROSCAN = "retroscan"
    HUNT = "hunt"
    RUNTIME_BUDGETS = "runtime_budgets"
    TRUST_GRAPH = "trust_graph"


class EntitlementLimits(BaseModel):
    """Usage limits for an entitlement."""

    scans_per_day: int = Field(default=0, ge=0, description="0 = unlimited")
    max_findings_returned: int = Field(default=0, ge=0, description="0 = unlimited")
    max_seats: int = Field(default=0, ge=0, description="0 = unlimited; Team default = 15")

    model_config = {"frozen": True}


class Entitlement(BaseModel):
    """Complete entitlement for a user/team."""

    tier: Tier
    capabilities: frozenset[Capability] = Field(default_factory=frozenset)
    limits: EntitlementLimits = Field(default_factory=EntitlementLimits)
    source: EntitlementSource = EntitlementSource.DEFAULT
    expires_at: datetime | None = Field(default=None)
    on_prem_validation_url: str | None = Field(default=None)
    subject_id: str | None = Field(
        default=None,
        description="Stable account/org subject identifier issued by entitlement authority.",
    )

    model_config = {"frozen": True}

    def has_capability(self, capability: Capability) -> bool:
        """Check if this entitlement includes a capability."""
        return capability in self.capabilities


# Tier capability mappings
_FREE_CAPABILITIES: frozenset[Capability] = frozenset({Capability.SCAN})
_PRO_CAPABILITIES: frozenset[Capability] = _FREE_CAPABILITIES | frozenset(
    {Capability.ENFORCE, Capability.SIGN, Capability.EXPLAIN}
)
_TEAM_CAPABILITIES: frozenset[Capability] = _PRO_CAPABILITIES | frozenset(
    {
        Capability.CI_ANNOTATIONS,
        Capability.CI_BLOCKING,
        Capability.FLEET_SCAN,
        Capability.RETROSCAN,
        Capability.HUNT,
    }
)
_ENTERPRISE_CAPABILITIES: frozenset[Capability] = _TEAM_CAPABILITIES | frozenset(
    {
        Capability.CUSTOM_POLICY,
        Capability.AUDIT_EXPORT,
        Capability.KEY_NAMESPACES,
        Capability.RUNTIME_BUDGETS,
        Capability.TRUST_GRAPH,
    }
)


def _free_entitlement() -> Entitlement:
    return Entitlement(
        tier=Tier.FREE,
        capabilities=_FREE_CAPABILITIES,
        limits=EntitlementLimits(scans_per_day=3, max_findings_returned=5),
        source=EntitlementSource.DEFAULT,
    )


def _pro_entitlement() -> Entitlement:
    return Entitlement(
        tier=Tier.PRO,
        capabilities=_PRO_CAPABILITIES,
        limits=EntitlementLimits(),
        source=EntitlementSource.DEFAULT,
    )


def _team_entitlement() -> Entitlement:
    return Entitlement(
        tier=Tier.TEAM,
        capabilities=_TEAM_CAPABILITIES,
        limits=EntitlementLimits(max_seats=15),
        source=EntitlementSource.DEFAULT,
    )


def _enterprise_entitlement() -> Entitlement:
    return Entitlement(
        tier=Tier.ENTERPRISE,
        capabilities=_ENTERPRISE_CAPABILITIES,
        limits=EntitlementLimits(),
        source=EntitlementSource.DEFAULT,
    )


TIER_ENTITLEMENTS: dict[Tier, Callable[[], Entitlement]] = {
    Tier.FREE: _free_entitlement,
    Tier.PRO: _pro_entitlement,
    Tier.TEAM: _team_entitlement,
    Tier.ENTERPRISE: _enterprise_entitlement,
}
