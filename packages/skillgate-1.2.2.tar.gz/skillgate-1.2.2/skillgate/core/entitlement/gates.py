"""Tier capability gates and finding caps."""

from __future__ import annotations

from typing import Any

from skillgate.core.entitlement.models import Capability, Entitlement
from skillgate.core.errors import EntitlementError


def check_capability(entitlement: Entitlement, capability: Capability) -> None:
    """Raise EntitlementError if capability is not available for tier.

    Args:
        entitlement: Current user entitlement
        capability: Required capability

    Raises:
        EntitlementError: If capability not available
    """
    if not entitlement.has_capability(capability):
        tier_name = entitlement.tier.value.upper()
        raise EntitlementError(
            f"'{capability.value}' requires a higher tier. "
            f"Current tier: {tier_name}. Upgrade at https://skillgate.io/pricing",
            tier=tier_name,
            capability=capability.value,
        )


def check_seat_limit(entitlement: Entitlement, current_seat_count: int) -> None:
    """Raise EntitlementError if team seat limit is exceeded.

    Args:
        entitlement: Current team entitlement.
        current_seat_count: Number of active seats in use.

    Raises:
        EntitlementError: If seat limit is exceeded.
    """
    max_seats = entitlement.limits.max_seats
    if max_seats > 0 and current_seat_count > max_seats:
        raise EntitlementError(
            f"Team seat limit exceeded: {current_seat_count}/{max_seats} seats in use. "
            "Upgrade to Enterprise or reduce active members.",
            tier=entitlement.tier.value.upper(),
        )


def cap_findings(findings: list[Any], max_count: int) -> tuple[list[Any], int]:
    """Cap findings to max_count with deterministic ordering.

    Sort order: severity desc, weight desc, rule_id asc.

    Args:
        findings: List of Finding objects
        max_count: Maximum findings to return (0 = unlimited)

    Returns:
        Tuple of (capped_findings, total_count)
    """
    if max_count <= 0 or not findings:
        return findings, len(findings)

    # Sort by: severity desc, weight desc, rule_id asc
    def sort_key(f: Any) -> tuple[int, int, str]:
        severity_order = {"critical": 0, "high": 1, "medium": 2, "low": 3, "info": 4}
        severity = getattr(f, "severity", "medium").lower()
        weight = getattr(f, "weight", 1.0)
        rule_id = getattr(f, "rule_id", "")
        return (severity_order.get(severity, 5), -int(weight * 10), rule_id)

    sorted_findings = sorted(findings, key=sort_key)
    capped = sorted_findings[:max_count]
    return capped, len(findings)
