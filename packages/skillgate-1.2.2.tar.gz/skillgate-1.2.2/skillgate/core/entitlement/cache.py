"""Thread-safe entitlement cache with TTL."""

from __future__ import annotations

import threading
import time

from skillgate.core.entitlement.models import Entitlement


class EntitlementCache:
    """Thread-safe TTL cache for entitlements."""

    def __init__(self, default_ttl_seconds: float = 300.0) -> None:
        self._cache: dict[str, tuple[Entitlement, float]] = {}
        self._lock = threading.RLock()
        self._default_ttl = default_ttl_seconds

    def get(self, key: str) -> Entitlement | None:
        """Get cached entitlement if not expired."""
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None
            entitlement, expires_at = entry
            if time.time() > expires_at:
                del self._cache[key]
                return None
            return entitlement

    def put(self, key: str, entitlement: Entitlement, ttl_seconds: float | None = None) -> None:
        """Store entitlement with TTL."""
        ttl = ttl_seconds if ttl_seconds is not None else self._default_ttl
        expires_at = time.time() + ttl
        with self._lock:
            self._cache[key] = (entitlement, expires_at)

    def invalidate(self, key: str) -> bool:
        """Remove a cached entitlement. Returns True if key existed."""
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
            return False

    def clear(self) -> None:
        """Clear all cached entries."""
        with self._lock:
            self._cache.clear()

    def size(self) -> int:
        """Return current cache size (including expired entries)."""
        with self._lock:
            return len(self._cache)


# Global cache instance
_global_cache: EntitlementCache = EntitlementCache()


def get_entitlement_cache() -> EntitlementCache:
    """Get the global entitlement cache."""
    return _global_cache
