"""Dangerous command chain and pattern detection rules."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import RegexRule
from skillgate.core.models.enums import Category, Severity


class CommandCurlPipeBash(RegexRule):
    """SG-CMD-001: curl piped to bash/sh execution."""

    id = "SG-CMD-001"
    name = "Curl Pipe to Shell"
    description = "curl output piped directly to shell (dangerous download-and-execute pattern)"
    severity = Severity.CRITICAL
    weight = 20
    category = Category.COMMAND
    patterns = [
        (
            re.compile(
                r"curl\s+.*\|\s*(bash|sh|zsh)",
                re.IGNORECASE,
            ),
            "curl | bash pattern detected: '{match}'",
            "Download scripts to disk, inspect them, then execute explicitly.",
        ),
        (
            re.compile(
                r"curl\s+.*\|\s*sudo\s+(bash|sh|zsh)",
                re.IGNORECASE,
            ),
            "curl | sudo bash pattern (elevated risk): '{match}'",
            "Never pipe remote content to sudo shell; download and review first.",
        ),
    ]


class CommandWgetPipeShell(RegexRule):
    """SG-CMD-002: wget piped to shell execution."""

    id = "SG-CMD-002"
    name = "Wget Pipe to Shell"
    description = "wget output piped directly to shell (dangerous download-and-execute pattern)"
    severity = Severity.CRITICAL
    weight = 20
    category = Category.COMMAND
    patterns = [
        (
            re.compile(
                r"wget\s+.*\|\s*(bash|sh|zsh)",
                re.IGNORECASE,
            ),
            "wget | bash pattern detected: '{match}'",
            "Download scripts to disk, inspect them, then execute explicitly.",
        ),
        (
            re.compile(
                r"wget\s+.*-O\s*-\s*.*\|\s*(bash|sh|zsh)",
                re.IGNORECASE,
            ),
            "wget -O- | bash pattern detected: '{match}'",
            "Avoid piping downloaded content directly to shell.",
        ),
    ]


class CommandInlinePythonExec(RegexRule):
    """SG-CMD-003: Inline python -c with dynamic code."""

    id = "SG-CMD-003"
    name = "Inline Python Code Execution"
    description = "python -c with dynamic code execution (potential code injection vector)"
    severity = Severity.HIGH
    weight = 15
    category = Category.COMMAND
    patterns = [
        (
            re.compile(
                r"python[23]?\s+-c\s+['\"].*(__import__|exec|eval)",
                re.IGNORECASE,
            ),
            "python -c with exec/eval: '{match}'",
            "Avoid dynamic exec/eval in inline python; write scripts explicitly.",
        ),
        (
            re.compile(
                r"python[23]?\s+-c\s+['\"].*base64",
                re.IGNORECASE,
            ),
            "python -c with base64 (possible obfuscation): '{match}'",
            "Inline base64 decode+exec is suspicious; use explicit scripts.",
        ),
    ]


class CommandPowershellDownloadExec(RegexRule):
    """SG-CMD-004: PowerShell download-and-execute patterns."""

    id = "SG-CMD-004"
    name = "PowerShell Download and Execute"
    description = "PowerShell Invoke-Expression with remote content (download-exec pattern)"
    severity = Severity.CRITICAL
    weight = 20
    category = Category.COMMAND
    patterns = [
        (
            re.compile(
                r"(Invoke-WebRequest|iwr|wget).*\|\s*I(nvoke-)?E(xpression|X)",
                re.IGNORECASE,
            ),
            "PowerShell download-exec (IEX): '{match}'",
            "Download scripts to disk, review, then execute explicitly.",
        ),
        (
            re.compile(
                r"(New-Object.*Net\.WebClient).*DownloadString.*\|\s*I(nvoke-)?E(xpression|X)",
                re.IGNORECASE,
            ),
            "PowerShell WebClient DownloadString | IEX: '{match}'",
            "Avoid piping remote PowerShell content to Invoke-Expression.",
        ),
    ]


class CommandBase64Decode(RegexRule):
    """SG-CMD-005: Base64 decode piped to shell (obfuscation)."""

    id = "SG-CMD-005"
    name = "Base64 Decode to Shell"
    description = "Base64 decode piped to shell execution (obfuscation pattern)"
    severity = Severity.HIGH
    weight = 15
    category = Category.COMMAND
    patterns = [
        (
            re.compile(
                r"(echo|base64)\s+.*\|\s*base64\s+(-d|--decode).*\|\s*(bash|sh|zsh)",
                re.IGNORECASE,
            ),
            "Base64 decode | bash (obfuscated exec): '{match}'",
            "Inline base64 decode+exec is obfuscation; avoid this pattern.",
        ),
        (
            re.compile(
                r"base64\s+(-d|--decode).*\|\s*(bash|sh|python)",
                re.IGNORECASE,
            ),
            "Base64 decode to executable: '{match}'",
            "Decode payloads to disk for review before execution.",
        ),
    ]


class CommandChainedDangerousOps(RegexRule):
    """SG-CMD-006: Chained dangerous operations (rm -rf, dd, mkfs)."""

    id = "SG-CMD-006"
    name = "Chained Dangerous Operations"
    description = "Destructive commands chained with && or ; (potential data loss)"
    severity = Severity.CRITICAL
    weight = 18
    category = Category.COMMAND
    patterns = [
        (
            re.compile(
                r"(&&|;)\s*rm\s+-rf\s+(/|~|\.\.)",
                re.IGNORECASE,
            ),
            "Chained rm -rf with dangerous path: '{match}'",
            "Avoid chaining destructive rm commands; isolate and validate paths.",
        ),
        (
            re.compile(
                r"(&&|;)\s*dd\s+.*of=/dev/",
                re.IGNORECASE,
            ),
            "Chained dd to device (data loss risk): '{match}'",
            "dd commands should never be chained; isolate and confirm targets.",
        ),
        (
            re.compile(
                r"(&&|;)\s*mkfs",
                re.IGNORECASE,
            ),
            "Chained filesystem format (mkfs): '{match}'",
            "mkfs commands must be isolated and manually confirmed.",
        ),
    ]


class CommandSudoNoPassword(RegexRule):
    """SG-CMD-007: sudo -S or NOPASSWD patterns (privilege escalation)."""

    id = "SG-CMD-007"
    name = "Sudo Password Bypass"
    description = "sudo with password bypass or NOPASSWD (privilege escalation vector)"
    severity = Severity.HIGH
    weight = 15
    category = Category.COMMAND
    patterns = [
        (
            re.compile(
                r"sudo\s+-S",
                re.IGNORECASE,
            ),
            "sudo -S (stdin password): '{match}'",
            "Avoid sudo -S with piped passwords; use explicit authentication.",
        ),
        (
            re.compile(
                r"NOPASSWD:\s*ALL",
                re.IGNORECASE,
            ),
            "NOPASSWD: ALL in sudoers-like config: '{match}'",
            "NOPASSWD grants unrestricted sudo; scope privileges tightly.",
        ),
    ]


class CommandShellHistoryDisable(RegexRule):
    """SG-CMD-008: Shell history disabling (anti-forensics)."""

    id = "SG-CMD-008"
    name = "Shell History Disabled"
    description = "Command to disable shell history (anti-forensics pattern)"
    severity = Severity.MEDIUM
    weight = 10
    category = Category.COMMAND
    patterns = [
        (
            re.compile(
                r"(unset\s+HISTFILE|HISTFILE=/dev/null|set\s+\+o\s+history)",
                re.IGNORECASE,
            ),
            "Shell history disabled: '{match}'",
            "Disabling shell history is an anti-forensics tactic; avoid in production skills.",
        )
    ]


class CommandEvalWithVariable(RegexRule):
    """SG-CMD-009: eval with variable substitution (code injection risk)."""

    id = "SG-CMD-009"
    name = "Eval with Variable Substitution"
    description = "eval command with variable interpolation (code injection vector)"
    severity = Severity.HIGH
    weight = 14
    category = Category.COMMAND
    patterns = [
        (
            re.compile(
                r"eval\s+['\"]?\$",
                re.IGNORECASE,
            ),
            "eval with variable expansion: '{match}'",
            "eval with user input or variables is dangerous; avoid or sanitize rigorously.",
        )
    ]


class CommandNetcatReverseShell(RegexRule):
    """SG-CMD-010: netcat reverse shell patterns."""

    id = "SG-CMD-010"
    name = "Netcat Reverse Shell"
    description = "netcat reverse shell command (backdoor pattern)"
    severity = Severity.CRITICAL
    weight = 20
    category = Category.COMMAND
    patterns = [
        (
            re.compile(
                r"(nc|ncat|netcat)\s+.*-e\s+(bash|sh|/bin/sh|/bin/bash)",
                re.IGNORECASE,
            ),
            "netcat reverse shell (-e flag): '{match}'",
            "netcat -e creates a backdoor shell; this is a malicious pattern.",
        ),
        (
            re.compile(
                r"(rm\s+/tmp/f;\s*mkfifo\s+/tmp/f|mkfifo\s+/tmp/f).*\|\s*/bin/sh.*nc",
                re.IGNORECASE,
            ),
            "netcat FIFO reverse shell: '{match}'",
            "FIFO-based netcat reverse shells are backdoors; remove this pattern.",
        ),
    ]


# Export all command rules
ALL_COMMAND_RULES = [
    CommandCurlPipeBash,
    CommandWgetPipeShell,
    CommandInlinePythonExec,
    CommandPowershellDownloadExec,
    CommandBase64Decode,
    CommandChainedDangerousOps,
    CommandSudoNoPassword,
    CommandShellHistoryDisable,
    CommandEvalWithVariable,
    CommandNetcatReverseShell,
]
