"""Network access detection rules (SG-NET-001 through SG-NET-006)."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import RegexRule
from skillgate.core.models.enums import Category, Severity


class HttpRequestRule(RegexRule):
    """SG-NET-001: Detect outbound HTTP requests."""

    id = "SG-NET-001"
    name = "http_request"
    description = "Outbound HTTP request detected"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.NETWORK
    patterns = [
        (
            re.compile(
                r"\b(requests\.(get|post|put|delete|patch|head)|"
                r"urllib\.request\.urlopen|"
                r"httpx\.(get|post|put|delete|patch|AsyncClient|Client)|"
                r"fetch\s*\()"
            ),
            "Outbound HTTP request detected: {match}",
            "Ensure HTTP requests target only approved domains. Use domain whitelisting.",
        ),
    ]


class SocketConnectionRule(RegexRule):
    """SG-NET-002: Detect raw socket connections."""

    id = "SG-NET-002"
    name = "socket_connection"
    description = "Raw socket connection detected"
    severity = Severity.HIGH
    weight = 35
    category = Category.NETWORK
    patterns = [
        (
            re.compile(r"\bsocket\.(connect|socket|create_connection)\s*\("),
            "Raw socket connection detected: {match}",
            "Avoid raw sockets. Use higher-level HTTP libraries with domain whitelisting.",
        ),
    ]


class DnsLookupRule(RegexRule):
    """SG-NET-003: Detect DNS lookup operations."""

    id = "SG-NET-003"
    name = "dns_lookup"
    description = "DNS lookup operation detected"
    severity = Severity.LOW
    weight = 15
    category = Category.NETWORK
    patterns = [
        (
            re.compile(r"\bsocket\.gethostbyname\s*\("),
            "DNS lookup detected: {match}",
            "Review DNS lookups to ensure they resolve only expected hostnames.",
        ),
        (
            re.compile(r"\bsocket\.getaddrinfo\s*\("),
            "DNS lookup detected: {match}",
            "Review DNS lookups to ensure they resolve only expected hostnames.",
        ),
    ]


class WebhookPostRule(RegexRule):
    """SG-NET-004: Detect data exfiltration via HTTP POST."""

    id = "SG-NET-004"
    name = "webhook_post"
    description = "Data exfiltration vector: HTTP POST with payload"
    severity = Severity.HIGH
    weight = 35
    category = Category.NETWORK
    patterns = [
        (
            re.compile(r"\b(requests\.post|httpx\.post|fetch)\s*\("),
            "Potential data exfiltration via HTTP POST detected: {match}",
            "Remove or restrict outbound HTTP POST calls. Use domain whitelisting.",
        ),
    ]


class HardcodedIpRule(RegexRule):
    """SG-NET-005: Detect hardcoded IP addresses."""

    id = "SG-NET-005"
    name = "hardcoded_ip"
    description = "Hardcoded IP address detected"
    severity = Severity.MEDIUM
    weight = 20
    category = Category.NETWORK
    patterns = [
        (
            re.compile(r"""(?:['"])(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(?:['"])"""),
            "Hardcoded IP address detected: {match}",
            "Avoid hardcoded IP addresses. Use configuration or domain names.",
        ),
    ]


class FtpConnectionRule(RegexRule):
    """SG-NET-006: Detect FTP/SFTP connections."""

    id = "SG-NET-006"
    name = "ftp_connection"
    description = "FTP/SFTP connection detected"
    severity = Severity.HIGH
    weight = 35
    category = Category.NETWORK
    patterns = [
        (
            re.compile(r"\b(ftplib\.FTP|paramiko\.SFTPClient|pysftp\.Connection)\s*\("),
            "FTP/SFTP connection detected: {match}",
            "Avoid FTP/SFTP connections. Use HTTPS-based file transfer if needed.",
        ),
        (
            re.compile(r"""ftp://\S+"""),
            "FTP URL detected: {match}",
            "Avoid FTP URLs. Use HTTPS for secure file transfer.",
        ),
    ]


NETWORK_RULES: list[type[RegexRule]] = [
    HttpRequestRule,
    SocketConnectionRule,
    DnsLookupRule,
    WebhookPostRule,
    HardcodedIpRule,
    FtpConnectionRule,
]
