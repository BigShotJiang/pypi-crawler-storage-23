"""AST-based rules for JavaScript/TypeScript (SG-*-040 series).

These rules use tree-sitter S-expression queries for more precise detection
than regex. They gracefully degrade when tree-sitter is not installed.
"""

from __future__ import annotations

from skillgate.core.analyzer.rules.base import AstRule
from skillgate.core.models.enums import Category, Language, Severity

_JS_TS = frozenset({Language.JAVASCRIPT, Language.TYPESCRIPT})


class JsChildProcessAstRule(AstRule):
    """SG-SHELL-040: Detect child_process usage via AST."""

    id = "SG-SHELL-040"
    name = "js_child_process_ast"
    description = "child_process module usage detected"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    languages = _JS_TS
    query = (
        '(call_expression function: (identifier) @fn (#match? @fn "^(exec|execSync|spawn|fork)$"))'
    )


class JsEvalAstRule(AstRule):
    """SG-EVAL-040: Detect eval() usage via AST."""

    id = "SG-EVAL-040"
    name = "js_eval_ast"
    description = "eval() usage detected"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.EVAL
    languages = _JS_TS
    query = '(call_expression function: (identifier) @fn (#eq? @fn "eval"))'


class JsFetchAstRule(AstRule):
    """SG-NET-040: Detect fetch() and HTTP client usage via AST."""

    id = "SG-NET-040"
    name = "js_fetch_ast"
    description = "HTTP request detected"
    severity = Severity.MEDIUM
    weight = 20
    category = Category.NETWORK
    languages = _JS_TS
    query = '(call_expression function: (identifier) @fn (#match? @fn "^fetch$"))'


class JsFsAstRule(AstRule):
    """SG-FS-040: Detect filesystem operations via AST."""

    id = "SG-FS-040"
    name = "js_fs_ast"
    description = "Filesystem operation detected"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.FILESYSTEM
    languages = _JS_TS
    query = (
        "(call_expression "
        "function: (member_expression object: (identifier) @obj "
        '(#match? @obj "^fs$")))'
    )


class JsNewFunctionAstRule(AstRule):
    """SG-EVAL-041: Detect new Function() constructor via AST."""

    id = "SG-EVAL-041"
    name = "js_new_function_ast"
    description = "new Function() constructor detected"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.EVAL
    languages = _JS_TS
    query = '(new_expression constructor: (identifier) @ctor (#eq? @ctor "Function"))'


JS_AST_RULES: list[type[AstRule]] = [
    JsChildProcessAstRule,
    JsEvalAstRule,
    JsFetchAstRule,
    JsFsAstRule,
    JsNewFunctionAstRule,
]
