"""Rust detection rules (SG-*-020 through SG-*-029)."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import LanguageRegexRule
from skillgate.core.models.enums import Category, Language, Severity

_RUST = frozenset({Language.RUST})


class RustCommandNewRule(LanguageRegexRule):
    """SG-SHELL-020: Detect Command::new() in Rust."""

    id = "SG-SHELL-020"
    name = "rust_command_new"
    description = "Rust Command::new() process execution"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    languages = _RUST
    patterns = [
        (
            re.compile(r"\bCommand::new\s*\("),
            "Rust process execution detected: {match}",
            "Validate and sanitize all arguments passed to Command::new(). "
            "Avoid constructing commands from user input.",
        ),
    ]


class RustCommandOutputRule(LanguageRegexRule):
    """SG-SHELL-021: Detect .output()/.spawn()/.status() on Commands."""

    id = "SG-SHELL-021"
    name = "rust_command_output"
    description = "Rust command output capture"
    severity = Severity.HIGH
    weight = 40
    category = Category.SHELL
    languages = _RUST
    patterns = [
        (
            re.compile(r"\.\s*(output|spawn|status)\s*\(\s*\)"),
            "Rust command execution with output capture: {match}",
            "Ensure command arguments are not user-controlled.",
        ),
    ]


class RustHttpClientRule(LanguageRegexRule):
    """SG-NET-020: Detect HTTP client usage in Rust."""

    id = "SG-NET-020"
    name = "rust_http_client"
    description = "Rust outbound HTTP request"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.NETWORK
    languages = _RUST
    patterns = [
        (
            re.compile(r"\b(?:reqwest|hyper|ureq)::"),
            "Rust HTTP client usage detected: {match}",
            "Verify outbound HTTP requests target allowed domains only.",
        ),
    ]


class RustTcpConnectRule(LanguageRegexRule):
    """SG-NET-021: Detect TcpStream::connect() in Rust."""

    id = "SG-NET-021"
    name = "rust_tcp_connect"
    description = "Rust raw TCP connection"
    severity = Severity.HIGH
    weight = 35
    category = Category.NETWORK
    languages = _RUST
    patterns = [
        (
            re.compile(r"\bTcpStream::connect\s*\("),
            "Rust raw TCP connection detected: {match}",
            "Avoid raw socket connections. Use higher-level HTTP clients with TLS.",
        ),
    ]


class RustTcpListenerRule(LanguageRegexRule):
    """SG-NET-022: Detect TcpListener::bind() in Rust."""

    id = "SG-NET-022"
    name = "rust_tcp_listener"
    description = "Rust TCP server listener"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.NETWORK
    languages = _RUST
    patterns = [
        (
            re.compile(r"\bTcpListener::bind\s*\("),
            "Rust TCP server detected: {match}",
            "Skills should not start TCP servers. "
            "Remove server functionality from the skill bundle.",
        ),
    ]


class RustFileWriteRule(LanguageRegexRule):
    """SG-FS-020: Detect file write operations in Rust."""

    id = "SG-FS-020"
    name = "rust_file_write"
    description = "Rust file write operation"
    severity = Severity.MEDIUM
    weight = 15
    category = Category.FILESYSTEM
    languages = _RUST
    patterns = [
        (
            re.compile(r"\b(?:File::create|fs::write)\s*\("),
            "Rust file write operation detected: {match}",
            "Verify file writes target only expected paths within the skill bundle.",
        ),
    ]


class RustFileDeleteRule(LanguageRegexRule):
    """SG-FS-021: Detect file/directory deletion in Rust."""

    id = "SG-FS-021"
    name = "rust_file_delete"
    description = "Rust file/directory deletion"
    severity = Severity.HIGH
    weight = 40
    category = Category.FILESYSTEM
    languages = _RUST
    patterns = [
        (
            re.compile(r"\b(?:fs::remove_file|fs::remove_dir_all|remove_dir_all)\s*\("),
            "Rust file deletion detected: {match}",
            "Avoid deleting files outside the skill bundle directory.",
        ),
    ]


class RustPathTraversalRule(LanguageRegexRule):
    """SG-FS-022: Detect path traversal in Rust."""

    id = "SG-FS-022"
    name = "rust_path_traversal"
    description = "Rust path traversal attempt"
    severity = Severity.CRITICAL
    weight = 50
    category = Category.FILESYSTEM
    languages = _RUST
    patterns = [
        (
            re.compile(r"""Path::new\s*\(\s*["'][^"']*\.\."""),
            "Rust path traversal detected: {match}",
            "Never use '..' in Path::new(). Validate and canonicalize all paths.",
        ),
    ]


class RustUnsafeBlockRule(LanguageRegexRule):
    """SG-EVAL-020: Detect unsafe blocks in Rust."""

    id = "SG-EVAL-020"
    name = "rust_unsafe"
    description = "Rust unsafe block"
    severity = Severity.HIGH
    weight = 35
    category = Category.EVAL
    languages = _RUST
    patterns = [
        (
            re.compile(r"\bunsafe\s*\{"),
            "Rust unsafe block detected: {match}",
            "Avoid unsafe blocks. Use safe Rust abstractions instead.",
        ),
    ]


class RustDynamicLoadRule(LanguageRegexRule):
    """SG-EVAL-021: Detect dynamic library loading in Rust."""

    id = "SG-EVAL-021"
    name = "rust_dynamic_load"
    description = "Rust dynamic library loading"
    severity = Severity.HIGH
    weight = 35
    category = Category.EVAL
    languages = _RUST
    patterns = [
        (
            re.compile(r"\b(?:libloading::Library|dlopen)\b"),
            "Rust dynamic library loading detected: {match}",
            "Avoid loading dynamic libraries. Use compiled dependencies instead.",
        ),
    ]


class RustEnvAccessRule(LanguageRegexRule):
    """SG-CRED-020: Detect environment variable access in Rust."""

    id = "SG-CRED-020"
    name = "rust_env_access"
    description = "Rust environment variable access"
    severity = Severity.MEDIUM
    weight = 20
    category = Category.CREDENTIAL
    languages = _RUST
    patterns = [
        (
            re.compile(r"\benv::(var|set_var|remove_var)\s*\("),
            "Rust environment variable access detected: {match}",
            "Declare required environment variables in the skill manifest.",
        ),
    ]


class RustHardcodedKeyRule(LanguageRegexRule):
    """SG-CRED-021: Detect hardcoded API keys in Rust strings."""

    id = "SG-CRED-021"
    name = "rust_hardcoded_key"
    description = "Hardcoded API key in Rust code"
    severity = Severity.MEDIUM
    weight = 25
    category = Category.CREDENTIAL
    languages = _RUST
    patterns = [
        (
            re.compile(
                r"""(?:api[_-]?key|token|secret|password)\s*[:=]\s*["'][A-Za-z0-9]{20,}["']"""
            ),
            "Possible hardcoded credential detected: {match}",
            "Move credentials to environment variables or a secrets manager.",
        ),
    ]


class RustSqlInjectionRule(LanguageRegexRule):
    """SG-INJ-020: Detect SQL injection via format!() macro in Rust."""

    id = "SG-INJ-020"
    name = "rust_sql_injection"
    description = "SQL injection via string formatting in Rust"
    severity = Severity.HIGH
    weight = 35
    category = Category.INJECTION
    languages = _RUST
    patterns = [
        (
            re.compile(r"""format!\s*\(\s*["'][^"']*(?:SELECT|INSERT|UPDATE|DELETE|DROP)"""),
            "Possible SQL injection via format!: {match}",
            "Use parameterized queries instead of format! for SQL.",
        ),
    ]


RUST_RULES: list[type[LanguageRegexRule]] = [
    RustCommandNewRule,
    RustCommandOutputRule,
    RustHttpClientRule,
    RustTcpConnectRule,
    RustTcpListenerRule,
    RustFileWriteRule,
    RustFileDeleteRule,
    RustPathTraversalRule,
    RustUnsafeBlockRule,
    RustDynamicLoadRule,
    RustEnvAccessRule,
    RustHardcodedKeyRule,
    RustSqlInjectionRule,
]
