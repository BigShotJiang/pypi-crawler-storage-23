"""Prompt injection and jailbreak detection rules."""

from __future__ import annotations

import re

from skillgate.core.analyzer.rules.base import RegexRule
from skillgate.core.models.enums import Category, Severity


class PromptInjectionDanPattern(RegexRule):
    """SG-PROMPT-001: DAN (Do Anything Now) jailbreak pattern."""

    id = "SG-PROMPT-001"
    name = "DAN Jailbreak Pattern"
    description = "DAN (Do Anything Now) jailbreak instruction"
    severity = Severity.CRITICAL
    weight = 20
    category = Category.PROMPT
    patterns = [
        (
            re.compile(
                r"\b(DAN|Do Anything Now|act as DAN|pretend you are DAN)\b",
                re.IGNORECASE,
            ),
            "DAN jailbreak keyword detected: '{match}'",
            "Remove jailbreak instructions; they violate LLM usage policies.",
        )
    ]


class PromptInjectionIgnorePrevious(RegexRule):
    """SG-PROMPT-002: Ignore previous instructions pattern."""

    id = "SG-PROMPT-002"
    name = "Ignore Previous Instructions"
    description = "Instruction to ignore previous prompts or constraints"
    severity = Severity.HIGH
    weight = 15
    category = Category.PROMPT
    patterns = [
        (
            re.compile(
                r"\b(ignore (previous|prior|earlier|above) (instructions?|prompts?|rules?)|"
                r"disregard (previous|prior|earlier|above) (instructions?|prompts?|rules?))\b",
                re.IGNORECASE,
            ),
            "Ignore-previous-instructions pattern: '{match}'",
            "Remove instruction override attempts.",
        )
    ]


class PromptInjectionSystemOverride(RegexRule):
    """SG-PROMPT-003: System prompt override attempts."""

    id = "SG-PROMPT-003"
    name = "System Prompt Override"
    description = "Attempt to override system prompts or developer mode"
    severity = Severity.HIGH
    weight = 15
    category = Category.PROMPT
    patterns = [
        (
            re.compile(
                r"\b(developer mode|sudo mode|admin mode|privileged mode|"
                r"enable (developer|sudo|admin|privileged) mode)\b",
                re.IGNORECASE,
            ),
            "System override mode request: '{match}'",
            "Remove privilege escalation attempts in prompts.",
        ),
        (
            re.compile(
                r"\[system\]|\<system\>|system:.*override|override system (prompt|instructions?)",
                re.IGNORECASE,
            ),
            "System directive override: '{match}'",
            "Remove system-level override instructions.",
        ),
    ]


class PromptInjectionRoleplay(RegexRule):
    """SG-PROMPT-004: Unrestricted roleplay jailbreak."""

    id = "SG-PROMPT-004"
    name = "Unrestricted Roleplay Jailbreak"
    description = "Instruction to roleplay as unrestricted character"
    severity = Severity.HIGH
    weight = 12
    category = Category.PROMPT
    patterns = [
        (
            re.compile(
                r"\b(pretend (to be|you are)|act as|roleplay as) .*(unrestricted|uncensored|"
                r"no (rules|limits|restrictions|constraints|filters))",
                re.IGNORECASE,
            ),
            "Unrestricted roleplay jailbreak: '{match}'",
            "Remove unbounded roleplay instructions.",
        )
    ]


class PromptInjectionTokenLeakage(RegexRule):
    """SG-PROMPT-005: Token or instruction leakage requests."""

    id = "SG-PROMPT-005"
    name = "Prompt Token Leakage"
    description = "Request to reveal system prompts, tokens, or internal instructions"
    severity = Severity.MEDIUM
    weight = 10
    category = Category.PROMPT
    patterns = [
        (
            re.compile(
                r"\b(reveal|show|print|display|output|tell)\s+(me\s+)?(your\s+)?(system\s+prompt|"
                r"instructions?|tokens?|internal\s+(rules|prompts?|directives?))",
                re.IGNORECASE,
            ),
            "Prompt leakage request: '{match}'",
            "Remove requests to reveal internal prompts.",
        )
    ]


class PromptInjectionGuardrailBypass(RegexRule):
    """SG-PROMPT-006: Guardrail or safety bypass patterns."""

    id = "SG-PROMPT-006"
    name = "Guardrail Bypass Attempt"
    description = "Attempt to bypass safety guardrails or content filters"
    severity = Severity.HIGH
    weight = 15
    category = Category.PROMPT
    patterns = [
        (
            re.compile(
                r"\b(bypass|disable|turn off|ignore|circumvent) .*(guardrail|safety|"
                r"filter|censor|content policy|moderation)\b",
                re.IGNORECASE,
            ),
            "Guardrail bypass attempt: '{match}'",
            "Remove instructions to bypass safety controls.",
        )
    ]


class PromptInjectionEmbeddedCommand(RegexRule):
    """SG-PROMPT-007: Embedded shell/code execution in prose."""

    id = "SG-PROMPT-007"
    name = "Embedded Command Injection"
    description = "Suspicious command embedded in natural language"
    severity = Severity.HIGH
    weight = 14
    category = Category.PROMPT
    patterns = [
        (
            re.compile(
                r"(execute|run|eval) (the following|this) (command|code|script):\s*[`'\"]",
                re.IGNORECASE,
            ),
            "Embedded command execution directive: '{match}'",
            "Avoid embedding executable commands in instructions.",
        ),
        (
            re.compile(
                r"\$\((curl|wget|bash|sh|python|powershell)",
                re.IGNORECASE,
            ),
            "Command substitution in prose: '{match}'",
            "Remove inline shell command substitutions.",
        ),
    ]


class PromptInjectionObfuscated(RegexRule):
    """SG-PROMPT-008: Obfuscated or encoded jailbreak attempts."""

    id = "SG-PROMPT-008"
    name = "Obfuscated Jailbreak"
    description = "Base64 or ROT13 encoded jailbreak pattern"
    severity = Severity.MEDIUM
    weight = 10
    category = Category.PROMPT
    patterns = [
        # Detect common base64 patterns followed by "decode" or "base64"
        (
            re.compile(
                r"(base64|decode):\s*[A-Za-z0-9+/]{20,}={0,2}",
                re.IGNORECASE,
            ),
            "Possible encoded jailbreak: '{match}'",
            "Avoid encoded instructions; suspicious patterns detected.",
        ),
        # ROT13 or similar cipher instructions
        (
            re.compile(
                r"\b(rot13|caesar)\s+(decode|decipher)\s+(this|the\s+following)",
                re.IGNORECASE,
            ),
            "Cipher-based obfuscation: '{match}'",
            "Remove encoded/obfuscated directives.",
        ),
    ]


# Export all prompt rules
ALL_PROMPT_RULES = [
    PromptInjectionDanPattern,
    PromptInjectionIgnorePrevious,
    PromptInjectionSystemOverride,
    PromptInjectionRoleplay,
    PromptInjectionTokenLeakage,
    PromptInjectionGuardrailBypass,
    PromptInjectionEmbeddedCommand,
    PromptInjectionObfuscated,
]
