"""Threat intelligence enrichment data models."""

from __future__ import annotations

from pydantic import BaseModel, Field


class FindingEnrichment(BaseModel):
    """Threat intelligence enrichment for a single finding."""

    rule_id: str = Field(description="Cross-reference to finding rule_id")
    confidence: float = Field(ge=0.0, le=1.0, description="Detection confidence score")
    first_seen: str = Field(description="ISO date when rule was added")
    tags: list[str] = Field(default_factory=list, description="Behavioral tags")
    risk_factors: list[str] = Field(
        default_factory=list, description="Human-readable risk descriptions"
    )
    mitre_attack: list[str] = Field(default_factory=list, description="MITRE ATT&CK technique IDs")
    # Future fields — default None, omitted from output with exclude_none
    reputation: float | None = Field(default=None)
    actor_tags: list[str] | None = Field(default=None)
    campaign_tags: list[str] | None = Field(default=None)
    last_seen: str | None = Field(default=None)
