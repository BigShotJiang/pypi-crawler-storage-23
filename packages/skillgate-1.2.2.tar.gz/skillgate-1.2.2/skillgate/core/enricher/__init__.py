"""Threat intelligence enrichment module for scan findings."""

from skillgate.core.enricher.engine import enrich_findings
from skillgate.core.enricher.models import FindingEnrichment

__all__ = [
    "FindingEnrichment",
    "enrich_findings",
]
