"""Threat intelligence enrichment engine.

Pure function that maps findings to enrichment metadata using the static catalog.
"""

from __future__ import annotations

from skillgate.core.enricher.catalog import (
    ENRICHMENT_CATALOG,
    SEVERITY_DEFAULTS,
    RuleEnrichmentMeta,
)
from skillgate.core.enricher.models import FindingEnrichment
from skillgate.core.models.finding import Finding


def enrich_findings(findings: list[Finding]) -> list[FindingEnrichment]:
    """Enrich findings with threat intelligence metadata.

    Pure function — O(n) dict lookups, deterministic, no I/O.
    Falls back to severity-based defaults for unknown rule IDs.
    Returns enrichments in same order as input findings.
    """
    result: list[FindingEnrichment] = []
    for finding in findings:
        meta = ENRICHMENT_CATALOG.get(finding.rule_id)
        if meta is None:
            meta = SEVERITY_DEFAULTS.get(
                finding.severity.value,
                SEVERITY_DEFAULTS["medium"],
            )
        result.append(_meta_to_enrichment(finding.rule_id, meta))
    return result


def _meta_to_enrichment(rule_id: str, meta: RuleEnrichmentMeta) -> FindingEnrichment:
    """Convert a frozen catalog entry to a Pydantic enrichment model."""
    return FindingEnrichment(
        rule_id=rule_id,
        confidence=meta.confidence,
        first_seen=meta.first_seen,
        tags=list(meta.tags),
        risk_factors=list(meta.risk_factors),
        mitre_attack=list(meta.mitre_attack),
    )
