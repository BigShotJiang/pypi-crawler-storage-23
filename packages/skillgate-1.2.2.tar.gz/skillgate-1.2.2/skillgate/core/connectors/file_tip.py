"""File-based Threat Intelligence Platform connector.

Reads enrichment data from a local JSON file. This serves as:
1. A reference implementation of the connector protocol.
2. A practical connector for air-gapped / offline environments.
3. A test harness for integration tests.

Expected JSON format::

    {
        "version": "1.0",
        "entries": {
            "SG-SHELL-001": {
                "confidence": 0.95,
                "tags": ["shell", "command-injection"],
                "risk_factors": ["Executes arbitrary commands"]
            },
            ...
        }
    }
"""

from __future__ import annotations

import json
import logging
import time
from pathlib import Path

from skillgate.core.connectors.base import BaseConnector
from skillgate.core.connectors.models import ConnectorResult, ConnectorStatus
from skillgate.core.connectors.registry import register_connector

logger = logging.getLogger(__name__)


class FileTIPConnector(BaseConnector):
    """Read-only connector that loads enrichment from a local JSON file."""

    def validate_config(self) -> list[str]:
        """Validate that ``params.path`` exists and is readable JSON."""
        errors: list[str] = []
        path_str = self._config.params.get("path", "")
        if not path_str:
            errors.append("Missing required param 'path'")
            return errors

        path = Path(path_str)
        if not path.exists():
            errors.append(f"File not found: {path}")
            return errors

        if not path.is_file():
            errors.append(f"Not a file: {path}")
            return errors

        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError) as exc:
            errors.append(f"Cannot read JSON from {path}: {exc}")
            return errors

        if not isinstance(data.get("entries"), dict):
            errors.append("JSON must contain an 'entries' dict at top level")
        return errors

    def fetch(self, rule_ids: list[str]) -> ConnectorResult:
        """Load enrichment for requested rule IDs from the JSON file.

        Args:
            rule_ids: Rule IDs to look up.

        Returns:
            ConnectorResult with matching enrichments.

        Raises:
            FileNotFoundError: If file does not exist.
            json.JSONDecodeError: If file is not valid JSON.
        """
        start = time.monotonic()
        path = Path(self._config.params["path"])

        data = json.loads(path.read_text(encoding="utf-8"))
        entries: dict[str, dict[str, object]] = data.get("entries", {})

        # Filter to requested rule_ids only
        enrichments: dict[str, dict[str, object]] = {}
        for rule_id in rule_ids:
            if rule_id in entries:
                entry = entries[rule_id]
                if isinstance(entry, dict):
                    enrichments[rule_id] = entry

        elapsed = time.monotonic() - start
        logger.debug(
            "FileTIPConnector loaded %d/%d enrichments from %s in %.3fs",
            len(enrichments),
            len(rule_ids),
            path,
            elapsed,
        )
        return ConnectorResult(
            connector_name=self.name,
            status=ConnectorStatus.SUCCESS,
            enrichments=enrichments,
            elapsed_seconds=round(elapsed, 4),
        )


# Auto-register on import
register_connector("file_tip", FileTIPConnector)
