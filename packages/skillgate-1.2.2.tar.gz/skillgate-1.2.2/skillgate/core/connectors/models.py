"""Data models for private intel connector framework."""

from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class ConnectorStatus(str, Enum):
    """Status of a connector fetch operation."""

    SUCCESS = "success"
    TIMEOUT = "timeout"
    ERROR = "error"
    AUTH_FAILED = "auth_failed"
    DISABLED = "disabled"


class ConnectorConfig(BaseModel):
    """Configuration for a single intel connector.

    All connectors share these base settings.  Connector-specific
    settings go in ``params``.
    """

    name: str = Field(description="Unique connector name")
    connector_type: str = Field(description="Connector type identifier")
    enabled: bool = Field(default=True)
    timeout_seconds: float = Field(
        default=5.0,
        gt=0.0,
        le=30.0,
        description="Maximum seconds before fail-open timeout",
    )
    fail_open: bool = Field(
        default=True,
        description="If True, connector failures produce empty results instead of errors",
    )
    params: dict[str, str] = Field(
        default_factory=dict,
        description="Connector-specific parameters (paths, URLs, API keys)",
    )


class ConnectorResult(BaseModel):
    """Result from a single connector fetch.

    On success, ``enrichments`` contains enrichment dicts keyed by rule_id.
    On failure with fail_open, ``enrichments`` is empty and ``status``
    indicates what went wrong.
    """

    connector_name: str
    status: ConnectorStatus
    enrichments: dict[str, dict[str, object]] = Field(default_factory=dict)
    error_message: str = ""
    elapsed_seconds: float = Field(default=0.0, ge=0.0)


class AggregatedConnectorResult(BaseModel):
    """Merged result from all connectors."""

    results: list[ConnectorResult] = Field(default_factory=list)
    enrichments: dict[str, dict[str, object]] = Field(default_factory=dict)
    total_elapsed_seconds: float = Field(default=0.0, ge=0.0)
