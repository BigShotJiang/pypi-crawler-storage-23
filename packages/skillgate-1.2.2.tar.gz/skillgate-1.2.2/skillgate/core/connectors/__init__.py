"""Private intel connector framework.

Provides read-only enrichment adapters for SIEM/TIP sources
with strict timeout and fail-open semantics.
"""

from __future__ import annotations

# Import built-in connectors to trigger auto-registration
import skillgate.core.connectors.file_tip as _file_tip  # noqa: F401
from skillgate.core.connectors.base import BaseConnector
from skillgate.core.connectors.manager import fetch_all
from skillgate.core.connectors.models import (
    AggregatedConnectorResult,
    ConnectorConfig,
    ConnectorResult,
    ConnectorStatus,
)
from skillgate.core.connectors.registry import (
    get_connector,
    register_connector,
    registered_types,
)

__all__ = [
    "AggregatedConnectorResult",
    "BaseConnector",
    "ConnectorConfig",
    "ConnectorResult",
    "ConnectorStatus",
    "fetch_all",
    "get_connector",
    "register_connector",
    "registered_types",
]
