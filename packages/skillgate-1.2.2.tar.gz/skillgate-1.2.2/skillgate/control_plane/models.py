"""Control-plane models for Sprint 15 SaaS governance."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Literal
from uuid import uuid4

Role = Literal["org_admin", "workspace_admin", "security_reviewer", "developer"]
ApprovalStatus = Literal["pending", "approved", "denied", "expired"]
RetentionPolicy = Literal["7d", "30d", "90d", "1y"]


def utc_now() -> datetime:
    """Return timezone-aware UTC timestamp."""
    return datetime.now(tz=timezone.utc)


@dataclass(frozen=True)
class Organization:
    """Organization root in the multi-tenant hierarchy."""

    id: str
    name: str
    created_at: datetime = field(default_factory=utc_now)


@dataclass(frozen=True)
class Workspace:
    """Workspace owned by an organization."""

    id: str
    org_id: str
    name: str
    retention: RetentionPolicy = "30d"
    created_at: datetime = field(default_factory=utc_now)


@dataclass(frozen=True)
class Agent:
    """Agent identity bound to one workspace."""

    id: str
    workspace_id: str
    display_name: str
    created_at: datetime = field(default_factory=utc_now)


@dataclass(frozen=True)
class ApprovalRequest:
    """Pending/terminal approval request."""

    id: str
    capability: str
    workspace_id: str
    agent_id: str
    justification: str
    created_at: datetime
    expires_at: datetime
    status: ApprovalStatus = "pending"
    approver_id: str | None = None
    reviewed_at: datetime | None = None


@dataclass(frozen=True)
class PolicyVersion:
    """Immutable policy version record."""

    id: str
    workspace_id: str
    version: int
    policy: dict[str, object]
    changed_by: str
    changed_at: datetime
    diff_keys: tuple[str, ...]


@dataclass(frozen=True)
class AuditEvent:
    """Simple auditable control-plane event."""

    id: str
    workspace_id: str
    event_type: str
    actor_id: str
    created_at: datetime
    payload: dict[str, object]


def make_id(prefix: str) -> str:
    """Create stable prefixed identifiers."""
    return f"{prefix}_{uuid4().hex}"
