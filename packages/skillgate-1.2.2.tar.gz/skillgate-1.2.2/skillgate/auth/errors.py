"""Authentication and license error helpers."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class AuthErrorDetail:
    """Structured auth error shown to users and API callers."""

    code: str
    message: str
    remediation: str


AUTH_ERRORS: dict[str, AuthErrorDetail] = {
    "AUTH_KEY_MISSING": AuthErrorDetail(
        code="AUTH_KEY_MISSING",
        message="API key is missing.",
        remediation="Set SKILLGATE_API_KEY or run: skillgate auth login",
    ),
    "AUTH_KEY_INVALID": AuthErrorDetail(
        code="AUTH_KEY_INVALID",
        message="API key is invalid.",
        remediation="Regenerate a valid key in the dashboard and run: skillgate auth login",
    ),
    "AUTH_SLT_EXPIRED": AuthErrorDetail(
        code="AUTH_SLT_EXPIRED",
        message="Session License Token has expired.",
        remediation="Run: skillgate auth login",
    ),
    "AUTH_SLT_EXPIRED_LIMITED": AuthErrorDetail(
        code="AUTH_SLT_EXPIRED_LIMITED",
        message="Session License Token expired while offline. Limited mode is enforced.",
        remediation="Reconnect and run: skillgate auth login",
    ),
    "AUTH_SERVICE_UNAVAILABLE": AuthErrorDetail(
        code="AUTH_SERVICE_UNAVAILABLE",
        message="Authentication service is unavailable.",
        remediation="Retry shortly or run: skillgate auth login when connectivity is restored",
    ),
}


def get_auth_error(code: str) -> AuthErrorDetail:
    """Return known auth error details or a generic fallback."""
    return AUTH_ERRORS.get(
        code,
        AuthErrorDetail(
            code=code,
            message="Authentication error.",
            remediation="Run: skillgate auth login",
        ),
    )
