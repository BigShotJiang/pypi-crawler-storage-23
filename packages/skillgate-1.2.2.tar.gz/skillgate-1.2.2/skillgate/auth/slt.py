"""Session License Token (SLT) models and JWT helpers."""

from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Literal, cast

import jwt
from pydantic import BaseModel, ConfigDict, Field, ValidationError

_ALLOWED_ALGORITHMS: frozenset[str] = frozenset({"RS256"})


class RateLimitClaim(BaseModel):
    """Client-side rate-limit policy for a capability."""

    model_config = ConfigDict(extra="forbid")

    per_minute: int = Field(ge=1, le=1_000_000)
    burst: int = Field(ge=1, le=1_000_000)


class SLTClaims(BaseModel):
    """Canonical SLT claims payload."""

    model_config = ConfigDict(extra="forbid")

    sub: str = Field(min_length=1)
    jti: str = Field(min_length=1)
    iat: int
    exp: int
    iss: str = Field(min_length=1)
    aud: str = Field(min_length=1)
    tier: Literal["free", "pro", "team", "enterprise"]
    entitlements: dict[str, int] = Field(default_factory=dict)
    rate_limits: dict[str, RateLimitClaim] = Field(default_factory=dict)
    anonymous: bool = False
    device_id: str = Field(min_length=1)


@dataclass(frozen=True)
class VerifyResult:
    """Verified SLT envelope."""

    claims: SLTClaims
    header: dict[str, Any]


class TokenVerificationError(ValueError):
    """Raised when SLT verification fails."""


def _decode_header(token: str) -> dict[str, Any]:
    try:
        header_segment = token.split(".", maxsplit=2)[0]
        padding = "=" * ((4 - (len(header_segment) % 4)) % 4)
        decoded = base64.urlsafe_b64decode((header_segment + padding).encode("utf-8")).decode(
            "utf-8"
        )
    except Exception as exc:  # noqa: BLE001
        raise TokenVerificationError("Malformed JWT header") from exc
    parsed = cast(dict[str, Any], json.loads(decoded))
    return parsed


def validate_alg_allowlist(token: str) -> dict[str, Any]:
    """Validate that token algorithm is RS256 and never none."""
    header = _decode_header(token)
    alg = str(header.get("alg", "")).upper()
    if alg == "NONE" or alg not in _ALLOWED_ALGORITHMS:
        raise TokenVerificationError("Unsupported JWT algorithm")
    return header


def issue_slt(
    *,
    private_key_pem: str,
    kid: str,
    org_id: str,
    device_id: str,
    tier: Literal["free", "pro", "team", "enterprise"],
    entitlements: dict[str, int],
    rate_limits: dict[str, dict[str, int]],
    anonymous: bool = False,
    issuer: str = "skillgate-api",
    audience: str = "skillgate-sidecar",
    token_id: str,
    now: datetime | None = None,
    ttl_hours: int = 12,
) -> str:
    """Issue a signed RS256 SLT."""
    now_utc = now or datetime.now(tz=timezone.utc)
    exp_utc = now_utc + timedelta(hours=ttl_hours)
    payload = {
        "sub": org_id,
        "jti": token_id,
        "iat": int(now_utc.timestamp()),
        "exp": int(exp_utc.timestamp()),
        "iss": issuer,
        "aud": audience,
        "tier": tier,
        "entitlements": entitlements,
        "rate_limits": rate_limits,
        "anonymous": anonymous,
        "device_id": device_id,
    }
    return jwt.encode(payload=payload, key=private_key_pem, algorithm="RS256", headers={"kid": kid})


def verify_slt(
    *,
    token: str,
    public_key_pem: str,
    issuer: str,
    audience: str,
    now: datetime | None = None,
) -> VerifyResult:
    """Verify RS256 signature and validate claims."""
    header = validate_alg_allowlist(token)
    try:
        payload = jwt.decode(
            token,
            key=public_key_pem,
            algorithms=["RS256"],
            audience=audience,
            issuer=issuer,
            options={"require": ["sub", "jti", "iat", "exp", "tier", "device_id"]},
        )
    except jwt.ExpiredSignatureError as exc:
        raise TokenVerificationError("Token expired") from exc
    except jwt.InvalidTokenError as exc:
        raise TokenVerificationError("Invalid token") from exc

    if now is not None and int(now.replace(tzinfo=timezone.utc).timestamp()) >= int(payload["exp"]):
        raise TokenVerificationError("Token expired")

    try:
        claims = SLTClaims.model_validate(payload)
    except ValidationError as exc:
        raise TokenVerificationError("Invalid claims") from exc

    return VerifyResult(claims=claims, header=header)
