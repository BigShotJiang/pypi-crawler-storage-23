"""SLT renewal scheduling helpers."""

from __future__ import annotations

import random
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone


@dataclass(frozen=True)
class RenewalDecision:
    """Result of renewal scheduling decision."""

    should_renew: bool
    next_attempt_at: datetime


def should_renew_slt(
    *,
    expires_at: datetime,
    now: datetime | None = None,
    threshold_hours: int = 4,
) -> bool:
    """Return true when token should be renewed in background."""
    current = now or datetime.now(tz=timezone.utc)
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    return expires_at - current <= timedelta(hours=threshold_hours)


def next_backoff_attempt(
    *,
    failures: int,
    now: datetime | None = None,
    base_seconds: int = 15,
    cap_seconds: int = 900,
) -> datetime:
    """Compute exponential backoff with bounded jitter."""
    current = now or datetime.now(tz=timezone.utc)
    exp_delay = min(cap_seconds, base_seconds * (2 ** max(0, failures - 1)))
    jitter = random.randint(0, max(1, exp_delay // 5))
    return current + timedelta(seconds=exp_delay + jitter)
