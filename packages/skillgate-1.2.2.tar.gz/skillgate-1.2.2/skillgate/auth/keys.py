"""SLT signing key management and JWKS export."""

from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa


@dataclass(frozen=True)
class SigningKey:
    """Signing key record with rotation metadata."""

    kid: str
    private_pem: str
    public_pem: str
    created_at: datetime
    grace_until: datetime


class KeySet:
    """In-memory RSA keyset with active key + grace keys."""

    def __init__(
        self,
        *,
        issuer: str = "skillgate-api",
        audience: str = "skillgate-sidecar",
        grace_hours: int = 24,
    ) -> None:
        self.issuer = issuer
        self.audience = audience
        self._grace_hours = grace_hours
        self._keys: list[SigningKey] = [self._new_key()]

    @staticmethod
    def _new_rsa_pair() -> tuple[str, str]:
        private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
        private_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        ).decode("utf-8")
        public_pem = (
            private_key.public_key()
            .public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo,
            )
            .decode("utf-8")
        )
        return private_pem, public_pem

    def _new_key(self) -> SigningKey:
        now = datetime.now(tz=timezone.utc)
        private_pem, public_pem = self._new_rsa_pair()
        kid = hashlib.sha256(public_pem.encode("utf-8")).hexdigest()[:16]
        return SigningKey(
            kid=kid,
            private_pem=private_pem,
            public_pem=public_pem,
            created_at=now,
            grace_until=now + timedelta(hours=self._grace_hours),
        )

    def rotate(self, now: datetime | None = None) -> SigningKey:
        """Rotate active key while retaining grace verification keys."""
        moment = now or datetime.now(tz=timezone.utc)
        active = self._keys[0]
        preserved = SigningKey(
            kid=active.kid,
            private_pem=active.private_pem,
            public_pem=active.public_pem,
            created_at=active.created_at,
            grace_until=moment + timedelta(hours=self._grace_hours),
        )
        fresh = self._new_key()
        self._keys = [fresh, preserved, *self._keys[1:]]
        self._keys = [key for key in self._keys if key.grace_until > moment or key.kid == fresh.kid]
        return fresh

    @property
    def active(self) -> SigningKey:
        return self._keys[0]

    def verification_keys(self, now: datetime | None = None) -> list[SigningKey]:
        """Return active and grace keys valid at ``now``."""
        moment = now or datetime.now(tz=timezone.utc)
        return [key for key in self._keys if key.kid == self.active.kid or key.grace_until > moment]

    def jwks(self, now: datetime | None = None) -> dict[str, Any]:
        """Return JWKS document for active+grace keys."""
        keys: list[dict[str, str]] = []
        for key in self.verification_keys(now=now):
            keys.append(_jwk_from_public_pem(kid=key.kid, public_pem=key.public_pem))
        return {"keys": keys}

    def key_by_kid(self, kid: str, now: datetime | None = None) -> SigningKey | None:
        """Lookup key for verification by ``kid`` within grace window."""
        for key in self.verification_keys(now=now):
            if key.kid == kid:
                return key
        return None


def _urlsafe_no_pad(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _int_to_bytes(value: int) -> bytes:
    length = (value.bit_length() + 7) // 8
    return value.to_bytes(length, "big")


def _jwk_from_public_pem(*, kid: str, public_pem: str) -> dict[str, str]:
    public_key = serialization.load_pem_public_key(public_pem.encode("utf-8"))
    if not isinstance(public_key, rsa.RSAPublicKey):
        msg = "Only RSA public keys are supported"
        raise ValueError(msg)
    numbers = public_key.public_numbers()
    return {
        "kty": "RSA",
        "kid": kid,
        "alg": "RS256",
        "use": "sig",
        "n": _urlsafe_no_pad(_int_to_bytes(numbers.n)),
        "e": _urlsafe_no_pad(_int_to_bytes(numbers.e)),
    }


def public_key_pem_from_jwk(jwk: dict[str, str]) -> str:
    """Convert RSA JWK to PEM public key."""
    n = int.from_bytes(base64.urlsafe_b64decode(jwk["n"] + "=="), "big")
    e = int.from_bytes(base64.urlsafe_b64decode(jwk["e"] + "=="), "big")
    public_numbers = rsa.RSAPublicNumbers(e=e, n=n)
    key = public_numbers.public_key()
    return key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")


def choose_pem_for_token(*, token_header: dict[str, Any], jwks_payload: dict[str, Any]) -> str:
    """Select PEM key from JWKS using token kid."""
    kid = str(token_header.get("kid", ""))
    for key in jwks_payload.get("keys", []):
        if isinstance(key, dict) and str(key.get("kid", "")) == kid:
            return public_key_pem_from_jwk({str(k): str(v) for k, v in key.items()})
    msg = "Token signing key not found in JWKS"
    raise ValueError(msg)


def jwks_json(jwks_payload: dict[str, Any]) -> str:
    """Deterministic JWKS JSON string."""
    return json.dumps(jwks_payload, sort_keys=True, separators=(",", ":"))
