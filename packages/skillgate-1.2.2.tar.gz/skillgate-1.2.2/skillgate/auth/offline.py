"""Offline mode transitions for SLT-based enforcement."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Literal

OfflineMode = Literal["A", "B", "C"]
OfflineGracePolicy = Literal["balanced", "strict"]


@dataclass(frozen=True)
class OfflineState:
    """Computed offline enforcement mode."""

    mode: OfflineMode
    allow_capabilities: frozenset[str]


_BALANCED_ALLOWED = frozenset({"tool.info", "fs.read", "git.read", "net.http.read"})


def determine_offline_mode(
    *,
    online: bool,
    token_expires_at: datetime,
    now: datetime | None = None,
    grace_window_hours: int = 48,
    policy: OfflineGracePolicy = "balanced",
) -> OfflineState:
    """Determine mode A/B/C from connectivity and token validity."""
    current = now or datetime.now(tz=timezone.utc)
    if token_expires_at.tzinfo is None:
        token_expires_at = token_expires_at.replace(tzinfo=timezone.utc)

    if online and current < token_expires_at:
        return OfflineState(mode="A", allow_capabilities=frozenset())

    if (not online) and current < token_expires_at:
        return OfflineState(mode="B", allow_capabilities=frozenset())

    in_grace = current <= token_expires_at + timedelta(hours=grace_window_hours)
    if not online and in_grace and policy == "balanced":
        return OfflineState(mode="C", allow_capabilities=_BALANCED_ALLOWED)

    return OfflineState(mode="C", allow_capabilities=frozenset())


def capability_allowed_in_mode(*, capability: str, state: OfflineState) -> bool:
    """Return whether capability can be used in current offline mode."""
    if state.mode in {"A", "B"}:
        return True
    return capability in state.allow_capabilities
