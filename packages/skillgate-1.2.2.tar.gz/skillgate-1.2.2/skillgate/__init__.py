"""SkillGate — CLI-first CI/CD policy enforcement for agent skills."""

from skillgate.version import __version__

__all__ = ["__version__"]
