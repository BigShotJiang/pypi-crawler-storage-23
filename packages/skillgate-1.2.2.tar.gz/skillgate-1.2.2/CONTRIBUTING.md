# Contributing to SkillGate

**Version:** 1.1.0  
**Last Updated:** 2026-02-18

Thank you for your interest in contributing to SkillGate! This guide will help you get started.

---

## Table of Contents

1. [Code of Conduct](#code-of-conduct)
2. [Getting Started](#getting-started)
3. [Development Environment](#development-environment)
4. [Project Architecture](#project-architecture)
5. [Coding Standards](#coding-standards)
6. [Testing Requirements](#testing-requirements)
7. [Pull Request Process](#pull-request-process)
8. [Issue Guidelines](#issue-guidelines)
9. [Performance Requirements](#performance-requirements)
10. [Security Guidelines](#security-guidelines)
11. [Contribution License Terms](#contribution-license-terms)

---

## Code of Conduct

We are committed to providing a welcoming and inclusive environment. By participating, you agree to:

- Be respectful and considerate
- Focus on constructive feedback
- Accept responsibility for mistakes
- Prioritize community well-being

**Unacceptable behavior:**
- Harassment, discrimination, or personal attacks
- Publishing others' private information
- Off-topic or spammy contributions

**Enforcement:** Violations will result in temporary or permanent ban from the project.

---

## Getting Started

### Prerequisites

- **Python 3.10+** (3.10, 3.11, 3.12, or 3.13)
- **Git** for version control
- **macOS, Linux, or Windows** (all supported)

### Fork and Clone

```bash
# Fork the repository on GitHub
# Then clone your fork:
git clone https://github.com/YOUR_USERNAME/skillgate.git
cd skillgate

# Add upstream remote
git remote add upstream https://github.com/skillgate/skillgate.git
```

### Install Dependencies

```bash
# Create virtual environment
python -m venv venv

# Activate (macOS/Linux)
source venv/bin/activate

# Activate (Windows)
venv\Scripts\activate

# Install in development mode
pip install -e ".[dev,ast,api,otel]"
```

### Verify Installation

```bash
# Run linter
ruff check .

# Run type checker
mypy --strict skillgate/

# Run tests
pytest --cov=skillgate --cov-fail-under=90

# Run full CI check
ruff check . && mypy --strict skillgate/ && pytest --cov=skillgate --cov-fail-under=90
```

**All checks must pass before any contribution.**

---

## Development Environment

### Directory Structure

```
skillgate/
├── skillgate/           # Main package
│   ├── cli/            # CLI commands (Typer + Rich)
│   ├── core/           # Core library (zero I/O dependencies)
│   │   ├── analyzer/   # Static analysis engine
│   │   ├── parser/     # Bundle discovery + manifest parsing
│   │   ├── policy/     # Policy enforcement
│   │   ├── scorer/     # Risk scoring
│   │   ├── signer/     # Ed25519 signing
│   │   └── models/     # Pydantic data models
│   ├── api/            # Hosted API (FastAPI)
│   ├── ci/             # CI/CD adapters (GitHub Action, GitLab)
│   └── config/         # Configuration + license validation
├── tests/              # Test suite (unit/integration/e2e)
│   ├── unit/          # Unit tests (~65% coverage)
│   ├── integration/   # Integration tests (~25% coverage)
│   ├── e2e/           # End-to-end tests (~10% coverage)
│   ├── fixtures/      # Test data (safe/malicious skills, policies)
│   ├── defense/       # False-negative corpus (security hardening)
│   └── slo/           # Performance + reliability SLO tests (slow)
├── docs/              # Documentation (Markdown)
└── web-ui/            # Marketing website (Next.js)
```

**Key Constraint:** `core/` has **zero dependencies** on `cli/`, `api/`, or `ci/`. It is a pure library.

### Development Workflow

```bash
# Create feature branch
git checkout -b feature/my-feature

# Make changes
vim skillgate/core/analyzer/rules/my_rule.py

# Run incremental tests
pytest tests/unit/test_rules/test_my_rule.py -v

# Run full CI locally (required before push)
ruff check . && mypy --strict skillgate/ && pytest --cov=skillgate --cov-fail-under=90

# Commit with conventional commit message
git commit -m "feat(rules): add SG-CUSTOM-001 detection for X"

# Push to your fork
git push origin feature/my-feature

# Open PR on GitHub
```

---

## Project Architecture

### Modular Monolith

SkillGate uses a **pipeline architecture** with clear phase separation:

```
Parse → Analyze → Score → Enforce → Report
```

**Data Flow:**
1. **Parser** — Discover bundles, parse manifests, extract source files
2. **Analyzer** — Run rules (AST + regex), generate findings
3. **Scorer** — Calculate weighted risk score
4. **Policy Engine** — Evaluate against policy, check violations
5. **Output** — Format results (human/JSON/SARIF), sign attestation

### Tech Stack

- **Python 3.10+** — Type-annotated, strict mypy
- **Typer + Rich** — CLI framework with beautiful output
- **Pydantic** — Data models with validation
- **PyNaCl** — Ed25519 signing
- **httpx** — Async HTTP client
- **PyYAML** — Policy file parsing
- **tree-sitter** (optional) — AST parsing for JS/TS/Go/Rust/Ruby/Shell
- **pytest + pytest-cov** — Testing + coverage
- **ruff** — Linting + formatting
- **mypy** — Static type checking

---

## Coding Standards

### Python Style

**Follow PEP 8 with these additions:**

- **Line length:** 100 characters (configured in `pyproject.toml`)
- **Type hints:** Required on all public functions (strict mypy)
- **Docstrings:** Required on all public functions (Google style)
- **Imports:** Sorted by `ruff` (isort rules)
- **Naming:**
  - `snake_case` for functions, variables, modules
  - `PascalCase` for classes
  - `UPPER_SNAKE_CASE` for constants
  - `_private` for internal functions

**Example:**

```python
"""Module docstring."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from skillgate.core.models.finding import Finding


def analyze_file(file_path: Path, rules: list[Rule]) -> list[Finding]:
    """Analyze a single file with the given rules.
    
    Args:
        file_path: Path to the source file to analyze.
        rules: List of detection rules to apply.
    
    Returns:
        List of findings detected in the file.
    
    Raises:
        FileNotFoundError: If the file does not exist.
    """
    if not file_path.exists():
        msg = f"File not found: {file_path}"
        raise FileNotFoundError(msg)
    
    findings: list[Finding] = []
    content = file_path.read_text(encoding="utf-8")
    
    for rule in rules:
        findings.extend(rule.analyze(content, str(file_path)))
    
    return findings
```

### Linting

**All code must pass `ruff check` with zero errors:**

```bash
# Check for issues
ruff check .

# Auto-fix safe issues
ruff check --fix .

# Format code
ruff format .
```

**Enabled rules:** E, F, W, I, N, UP, B, A, SIM (configured in `pyproject.toml`)

### Type Checking

**All code must pass `mypy --strict` with zero errors:**

```bash
mypy --strict skillgate/
```

**Strict mode includes:**
- `disallow_untyped_defs` — All functions must have type annotations
- `disallow_incomplete_defs` — Partial annotations not allowed
- `no_implicit_optional` — Explicit `Optional[T]` required
- `warn_redundant_casts` — No unnecessary casts
- `warn_unused_ignores` — No stale `type: ignore` comments

**Type stubs:** Missing third-party stubs are ignored (see `pyproject.toml`).

### Documentation

**Docstrings required for:**
- All public functions, classes, methods
- All modules (file-level docstring)

**Docstring format (Google style):**

```python
def my_function(param1: str, param2: int) -> bool:
    """Short summary (one line).
    
    Longer description if needed (optional).
    
    Args:
        param1: Description of param1.
        param2: Description of param2.
    
    Returns:
        Description of return value.
    
    Raises:
        ValueError: When param2 is negative.
    """
```

**Comments:**
- Use comments sparingly — prefer self-documenting code
- Explain **why**, not **what**
- Keep comments synchronized with code

---

## Testing Requirements

### Test Pyramid

```
E2E Tests (10%)       ▲
Integration (25%)    ███
Unit Tests (65%)   ███████
```

**Unit Tests:**
- Test individual functions, classes in isolation
- Mock external dependencies (filesystem, network, API)
- Fast execution (<5s for full unit suite)

**Integration Tests:**
- Test component interactions (parser + analyzer, analyzer + scorer)
- Use real fixtures (test skill bundles, policies)
- Moderate execution time (<30s for full integration suite)

**E2E Tests:**
- Test full CLI commands end-to-end
- Execute real `skillgate` CLI
- Verify exit codes, output formats
- Slowest execution (<60s for full E2E suite)

### Test Organization

```
tests/
├── unit/
│   ├── test_analyzer/
│   │   ├── test_engine.py
│   │   ├── test_rules/
│   │   │   ├── test_shell.py
│   │   │   ├── test_network.py
│   │   │   └── ...
│   ├── test_parser/
│   ├── test_policy/
│   └── ...
├── integration/
│   ├── test_scan_pipeline.py
│   ├── test_policy_enforcement.py
│   └── ...
├── e2e/
│   ├── test_cli_scan.py
│   ├── test_cli_verify.py
│   └── ...
└── fixtures/
    ├── skills/
    │   ├── safe/
    │   └── malicious/
    └── policies/
```

### Writing Tests

**Use pytest with descriptive test names:**

```python
"""Tests for shell execution detection rules."""

import pytest

from skillgate.core.analyzer.rules.shell import SubprocessCallRule


class TestSubprocessCallRule:
    """Test suite for SG-SHELL-001."""
    
    def test_subprocess_run_detected(self) -> None:
        """subprocess.run() should be detected."""
        code = 'subprocess.run(["ls", "-la"])'
        rule = SubprocessCallRule()
        findings = rule.analyze(code, "test.py")
        
        assert len(findings) == 1
        assert findings[0].rule_id == "SG-SHELL-001"
        assert findings[0].severity.value == "high"
    
    def test_subprocess_in_comment_ignored(self) -> None:
        """subprocess in comments should be ignored."""
        code = '# subprocess.run() is used for shell commands'
        rule = SubprocessCallRule()
        findings = rule.analyze(code, "test.py")
        
        assert len(findings) == 0
    
    @pytest.mark.parametrize("func", ["run", "Popen", "call", "check_call"])
    def test_all_subprocess_variants_detected(self, func: str) -> None:
        """All subprocess.* variants should be detected."""
        code = f'subprocess.{func}(["ls"])'
        rule = SubprocessCallRule()
        findings = rule.analyze(code, "test.py")
        
        assert len(findings) == 1
```

### Coverage Requirements

**Minimum coverage: 90% on all `skillgate/` modules**

```bash
# Check coverage
pytest --cov=skillgate --cov-report=term --cov-fail-under=90

# Generate HTML report
pytest --cov=skillgate --cov-report=html
open htmlcov/index.html
```

**Excluded from coverage:**
- `__main__.py` — CLI entry point
- Test files (`tests/`)
- Example scripts

### Running Tests

```bash
# All tests
pytest

# Unit tests only
pytest tests/unit/

# Specific test file
pytest tests/unit/test_rules/test_shell.py

# Specific test by name
pytest -k "test_subprocess_detection"

# Parallel execution (faster)
pytest -n auto

# With coverage
pytest --cov=skillgate --cov-fail-under=90

# Exclude slow tests (default)
pytest -m "not slow"

# Include slow tests (SLO tests)
pytest -m "slow"
```

---

## Pull Request Process

### 1. Create Issue First

**Before starting work, create an issue:**
- Bug: Describe expected vs. actual behavior, reproduction steps
- Feature: Describe use case, proposed solution, alternatives
- Refactor: Explain motivation, performance impact

**Wait for maintainer approval** before starting implementation.

### 2. Branch Naming

```
feature/SG-123-add-ruby-rules
bugfix/SG-456-fix-parser-crash
docs/SG-789-update-policy-reference
```

### 3. Commit Messages

**Use Conventional Commits:**

```
feat(rules): add SG-RUBY-030 for Ruby eval detection
fix(parser): handle UTF-8 BOM in skill manifests
docs(policy): clarify confidence filtering behavior
test(e2e): add E2E test for signed attestations
chore(deps): upgrade pydantic to 2.6.0
```

**Format:**
```
<type>(<scope>): <subject>

<body>

<footer>
```

**Types:** `feat`, `fix`, `docs`, `test`, `refactor`, `perf`, `chore`

### 4. Pre-PR Checklist

**Before opening PR:**

- [ ] All tests pass: `pytest --cov=skillgate --cov-fail-under=90`
- [ ] Linter passes: `ruff check .`
- [ ] Type checker passes: `mypy --strict skillgate/`
- [ ] Coverage ≥90% on changed modules
- [ ] Docstrings added for all public functions
- [ ] No `TODO` or `FIXME` without tracking issue
- [ ] CHANGELOG.md updated (if user-facing change)
- [ ] Documentation updated (if API change)

### 5. PR Template

```markdown
## Summary
Brief description of changes.

## Related Issue
Closes #123

## Changes
- Add SG-RUBY-030 detection rule
- Update RULE-CATALOG.md with Ruby rules
- Add 15 unit tests for Ruby detection

## Testing
- [ ] Unit tests added
- [ ] Integration tests added
- [ ] E2E tests added (if applicable)
- [ ] Manual testing performed

## Checklist
- [ ] CI passes (ruff + mypy + pytest)
- [ ] Coverage ≥90%
- [ ] Docstrings added
- [ ] CHANGELOG.md updated
```

### 6. Review Process

**Maintainers will review for:**
- Code quality and style compliance
- Test coverage and quality
- Performance impact
- Security implications
- Documentation completeness

**Review timeline:**
- First review within 3 business days
- Feedback addressed within 7 days

**Merge criteria:**
- All CI checks pass
- At least 1 maintainer approval
- No unresolved comments
- Branch is up-to-date with `main`

---

## Issue Guidelines

### Bug Reports

**Include:**
- SkillGate version: `skillgate --version`
- Python version: `python --version`
- OS: macOS/Linux/Windows
- Reproduction steps (minimal example)
- Expected vs. actual behavior
- Relevant logs/stack traces

**Template:**

```markdown
**Version:** 1.1.0
**Python:** 3.12.1
**OS:** macOS 14.2

**Bug Description:**
`skillgate scan` crashes when scanning a skill with non-UTF-8 files.

**Reproduction:**
1. Create a skill with `file.txt` containing Latin-1 encoding
2. Run `skillgate scan ./skill`
3. Observe crash

**Expected:** Skip file with warning
**Actual:** UnicodeDecodeError

**Stack Trace:**
```
UnicodeDecodeError: 'utf-8' codec can't decode byte 0xe9
  at skillgate/core/parser/source.py:42
```
```

### Feature Requests

**Include:**
- Use case (why is this needed?)
- Proposed solution
- Alternatives considered
- Breaking changes (if any)

**Example:**

```markdown
**Use Case:**
Teams need to scan Golang skills for goroutine leaks.

**Proposed Solution:**
Add SG-GO-020 rule to detect `go` keyword without `defer`.

**Alternatives:**
- Use existing AST rules (insufficient coverage)
- Manual code review (not scalable)

**Breaking Changes:** None
```

---

## Performance Requirements

### Latency Budgets

**Hard requirements (must pass SLO tests):**
- Cold start: <2s (from CLI invocation to first output)
- 10-file scan: <3s (typical skill bundle)
- 100-file scan: <10s (large monorepo)
- Memory: <256MB (peak RSS)

**Testing:**

```bash
# Run SLO tests (marked as slow)
pytest tests/slo/ -m slow
```

### Best Practices

- **Lazy evaluation** — Only parse files that match pre-filter regex
- **Parallel processing** — Rules evaluated per file in parallel
- **Skip large files** — Warn and skip files >100KB
- **No network calls** — Local scan must be zero-latency

---

## Security Guidelines

### Secure Coding

**Critical rules:**
- **Never execute skill code** — Analysis is purely static
- **No skill code leaves machine** — Unless user explicitly opts in (`--explain`)
- **Private keys never leave disk** — Ed25519 keys in `~/.skillgate/keys/`
- **API keys never in reports** — Redacted in all output

### Security Review

**All PRs touching these areas require security review:**
- `skillgate/core/signer/` — Cryptographic code
- `skillgate/api/security.py` — Auth/validation
- `skillgate/config/secrets.py` — Secret storage
- Any regex parsing user input

**Report vulnerabilities to:** support@skillgate.io (not public GitHub issues)

---

## Contribution License Terms

SkillGate is a proprietary project. By submitting a pull request, patch, issue attachment, or other contribution to this repository, you agree that:

- You have the legal right to submit the contribution.
- The contribution is provided without expectation of compensation.
- You grant SkillGate and its affiliates a perpetual, irrevocable, worldwide, royalty-free, fully paid-up, sublicensable, and transferable license to use, reproduce, modify, create derivative works of, distribute, publicly perform, publicly display, and otherwise exploit the contribution for any purpose.

If these terms do not work for your organization, contact support@skillgate.io before contributing.

---

## Questions?

- **Documentation:** https://skillgate.io/docs
- **GitHub Discussions:** https://github.com/skillgate/skillgate/discussions
- **Discord:** https://discord.gg/skillgate
- **Email:** support@skillgate.io

**Thank you for contributing to SkillGate! 🎉**
