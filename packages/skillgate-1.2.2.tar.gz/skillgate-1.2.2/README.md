<h1 align="center">SkillGate</h1>
<p align="center">
  <img src="web-ui/public/images/hero-shield.svg" alt="SkillGate shield logo" width="88" />
</p>
<p align="center"><strong>Secure Every AI Tool Before It Executes.</strong></p>
<p align="center">Runtime Policy Firewall for OpenClaw, Claude Code, Codex CLI and MCP.</p>

<p align="center">
  <a href="https://skillgate.io">Website</a> •
  <a href="https://docs.skillgate.io">Docs</a> •
  <a href="https://pypi.org/project/skillgate/">PyPI</a> •
  <a href="https://www.npmjs.com/package/@skillgate-io/cli">npm</a>
</p>

## Why SkillGate

- Runtime policy firewall for shell, network, filesystem, and tool capabilities.
- Deterministic allow/deny outcomes, not advisory-only warnings.
- Signed audit trail for enterprise compliance and incident response.
- Fast setup for local developer workflows and CI/CD gates.

## Install

### Python CLI (canonical runtime)

```bash
pipx install skillgate
skillgate --help
```

### npm entrypoint (delegates to Python runtime)

```bash
npm install -g @skillgate-io/cli
skillgate --help
```

## Release Operations

Release checklists and publish runbooks live in [docs/Release](docs/Release/README.md):

- Python publish: [PUBLISH-PYTHON.md](docs/Release/PUBLISH-PYTHON.md)
- npm publish: [PUBLISH-NPM.md](docs/Release/PUBLISH-NPM.md)
- .NET publish: [PUBLISH-DOTNET.md](docs/Release/PUBLISH-DOTNET.md)
- Checklist template: [RELEASE-CHECKLIST-TEMPLATE.md](docs/Release/RELEASE-CHECKLIST-TEMPLATE.md)

## Repo Structure

- `skillgate/` - Python CLI, API, worker, runtime engine.
- `web-ui/` - website and dashboard.
- `skillgate-docs/` - docs site.
- `npm-shim/`, `dotnet-shim/`, `go-shim/`, `ruby-shim/`, `rust-shim/`, `java-shim/` - language shims.

## SEO Keywords

`AI agent security`, `runtime policy firewall`, `Claude Code security`, `Codex CLI governance`, `MCP security gateway`, `AI tool execution control`.
