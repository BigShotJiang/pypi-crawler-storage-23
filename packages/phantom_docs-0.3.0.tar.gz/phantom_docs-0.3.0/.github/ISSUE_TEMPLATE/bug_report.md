---
name: Bug Report
about: Report a bug in Phantom
title: ""
labels: bug
assignees: ""
---

## Environment

- **Phantom version**: `phantom --version`
- **OS**: (e.g., macOS 15.2, Ubuntu 24.04)
- **Python version**: `python --version`
- **Runner type**: (web, tui, docker-compose)

## Manifest excerpt

```yaml
# Relevant parts of your .phantom.yml
```

## Expected behavior

What you expected to happen.

## Actual behavior

What actually happened. Include the full error message if applicable.

## Steps to reproduce

1. ...
2. ...
3. ...

## `phantom doctor` output

```
# Paste output of: phantom doctor --verbose
```

## Additional context

Any other information that might help diagnose the issue.
