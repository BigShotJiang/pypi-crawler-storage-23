"""
CFDocuments Resource

CASE Framework Documents — curriculum frameworks and standards documents.
"""

from __future__ import annotations

from typing import TYPE_CHECKING
from urllib.parse import quote

from timeback_common import validate_non_empty_string

from ..types.responses import CFDocument

if TYPE_CHECKING:
    from ..lib.transport import Transport


class DocumentsResource:
    """CASE Framework Documents resource."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    @property
    def _base_path(self) -> str:
        return f"{self._transport.paths.base}/CFDocuments"

    async def list(self, params: dict[str, str | int] | None = None) -> dict[str, list[CFDocument]]:
        """
        List all CASE documents.

        Args:
            params: Optional query parameters (offset, limit, filter, sort, orderBy)

        Returns:
            Dict with CFDocuments key containing list of documents
        """
        result = await self._transport.get(self._base_path, params=params)
        documents = [CFDocument.model_validate(d) for d in result.get("CFDocuments", [])]
        return {"CFDocuments": documents}

    async def get(self, sourced_id: str) -> dict[str, CFDocument]:
        """
        Get a CASE document by sourcedId.

        Args:
            sourced_id: The document's sourcedId

        Returns:
            Dict with CFDocument key containing the document
        """
        validate_non_empty_string(sourced_id, "sourcedId")
        result = await self._transport.get(f"{self._base_path}/{quote(sourced_id, safe='')}")
        return {"CFDocument": CFDocument.model_validate(result.get("CFDocument", result))}
