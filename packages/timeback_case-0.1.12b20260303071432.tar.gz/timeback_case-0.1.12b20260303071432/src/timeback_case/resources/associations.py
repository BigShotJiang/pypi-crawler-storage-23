"""
CFAssociations Resource

CASE Framework Associations — relationships between CASE entities.
"""

from __future__ import annotations

from typing import TYPE_CHECKING
from urllib.parse import quote

from timeback_common import validate_non_empty_string

from ..types.responses import CFAssociation

if TYPE_CHECKING:
    from ..lib.transport import Transport


class AssociationsResource:
    """CASE Framework Associations resource."""

    def __init__(self, transport: Transport) -> None:
        self._transport = transport

    @property
    def _base_path(self) -> str:
        return f"{self._transport.paths.base}/CFAssociations"

    async def get(self, sourced_id: str) -> dict[str, CFAssociation]:
        """
        Get a CASE association by sourcedId.

        Args:
            sourced_id: The association's sourcedId

        Returns:
            Dict with CFAssociation key containing the association
        """
        validate_non_empty_string(sourced_id, "sourcedId")
        result = await self._transport.get(f"{self._base_path}/{quote(sourced_id, safe='')}")
        return {"CFAssociation": CFAssociation.model_validate(result.get("CFAssociation", result))}
