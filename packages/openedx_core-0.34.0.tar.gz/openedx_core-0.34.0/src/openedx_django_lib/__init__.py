"""
Utilities, to be used within this repository only. These are *not* public APIs.

If any of these need to be used outside the repository, they can be factored into something
like edx-django-utils.
"""
