"""IEC 60870-5 message encodings"""
