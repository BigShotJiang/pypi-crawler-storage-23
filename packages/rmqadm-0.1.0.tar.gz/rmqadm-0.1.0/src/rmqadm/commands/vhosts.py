"""Virtual host 管理命令: rmqadm vhosts <subcommand>"""

from rmqadm.client import RabbitMQClient
from rmqadm.formatter import print_table, print_json


class VhostsCommands:
    """管理 RabbitMQ Virtual Hosts"""

    _LIST_COLUMNS = ["name", "description", "tags", "tracing", "default_queue_type"]

    def __init__(self, client: RabbitMQClient):
        self._client = client

    def list(self, format: str = "table"):
        """列出所有 vhost

        Args:
            format: 输出格式，table 或 json（默认 table）
        """
        data = self._client.get("/vhosts")
        if format == "json":
            print_json(data)
        else:
            print_table(data, columns=self._LIST_COLUMNS)

    def show(self, name: str, format: str = "table"):
        """显示指定 vhost 的详情

        Args:
            name:   vhost 名称
            format: 输出格式，table 或 json（默认 table）
        """
        data = self._client.get(f"/vhosts/{self._client.encode_name(name)}")
        if format == "json":
            print_json(data)
        else:
            print_table([data], columns=self._LIST_COLUMNS)

    def create(self, name: str, description: str = "", tags: str = "", tracing: bool = False,
               default_queue_type: str = "classic"):
        """创建 vhost

        Args:
            name:               vhost 名称
            description:        描述
            tags:               标签，逗号分隔
            tracing:            是否开启消息追踪
            default_queue_type: 默认队列类型，classic/quorum/stream
        """
        body = {
            "description": description,
            "tags": tags,
            "tracing": tracing,
            "default_queue_type": default_queue_type,
        }
        self._client.put(f"/vhosts/{self._client.encode_name(name)}", body)
        print(f"VHost '{name}' created.")

    def delete(self, name: str):
        """删除 vhost

        Args:
            name: vhost 名称
        """
        self._client.delete(f"/vhosts/{self._client.encode_name(name)}")
        print(f"VHost '{name}' deleted.")
