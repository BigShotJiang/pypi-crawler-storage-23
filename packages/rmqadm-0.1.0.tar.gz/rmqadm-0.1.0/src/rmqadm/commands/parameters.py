"""运行时参数管理命令: rmqadm parameters <subcommand>"""

import json as _json

from rmqadm.client import RabbitMQClient
from rmqadm.formatter import print_table, print_json


class ParametersCommands:
    """管理 RabbitMQ 运行时参数（Runtime Parameters）"""

    _LIST_COLUMNS = ["vhost", "component", "name", "value"]

    def __init__(self, client: RabbitMQClient, default_vhost: str = "/"):
        self._client = client
        self._default_vhost = default_vhost

    def list(self, vhost: str = None, component: str = None, format: str = "table"):
        """列出运行时参数

        Args:
            vhost:     指定 vhost，不填则列出所有
            component: 过滤组件（如 federation-upstream）
            format:    输出格式，table 或 json（默认 table）
        """
        if component and vhost:
            path = f"/parameters/{self._client.encode_name(component)}/{self._client.encode_name(vhost)}"
        elif component:
            path = f"/parameters/{self._client.encode_name(component)}"
        else:
            path = "/parameters"
        data = self._client.get(path)
        if format == "json":
            print_json(data)
        else:
            print_table(data, columns=self._LIST_COLUMNS)

    def set(self, name: str, component: str, value: str,
            vhost: str = None):
        """设置运行时参数

        Args:
            name:      参数名称
            component: 组件名称（如 federation-upstream）
            value:     参数值（JSON 字符串或普通字符串）
            vhost:     vhost 名称（默认 /）
        """
        vhost = vhost or self._default_vhost
        # 尝试解析为 JSON，否则作为字符串
        try:
            value_obj = _json.loads(value)
        except _json.JSONDecodeError:
            value_obj = value

        body = {"value": value_obj}
        path = (f"/parameters/{self._client.encode_name(component)}"
                f"/{self._client.encode_name(vhost)}"
                f"/{self._client.encode_name(name)}")
        self._client.put(path, body)
        print(f"Parameter '{name}' (component: {component}) in vhost '{vhost}' set.")

    def clear(self, name: str, component: str, vhost: str = None):
        """清除运行时参数

        Args:
            name:      参数名称
            component: 组件名称
            vhost:     vhost 名称（默认 /）
        """
        vhost = vhost or self._default_vhost
        path = (f"/parameters/{self._client.encode_name(component)}"
                f"/{self._client.encode_name(vhost)}"
                f"/{self._client.encode_name(name)}")
        self._client.delete(path)
        print(f"Parameter '{name}' (component: {component}) in vhost '{vhost}' cleared.")


class GlobalParametersCommands:
    """管理 RabbitMQ 全局参数（Global Parameters）"""

    _LIST_COLUMNS = ["name", "value"]

    def __init__(self, client: RabbitMQClient):
        self._client = client

    def list(self, format: str = "table"):
        """列出全局参数

        Args:
            format: 输出格式，table 或 json（默认 table）
        """
        data = self._client.get("/global-parameters")
        if format == "json":
            print_json(data)
        else:
            print_table(data, columns=self._LIST_COLUMNS)

    def set(self, name: str, value: str):
        """设置全局参数

        Args:
            name:  参数名称
            value: 参数值（JSON 字符串或普通字符串）
        """
        try:
            value_obj = _json.loads(value)
        except _json.JSONDecodeError:
            value_obj = value

        body = {"value": value_obj}
        self._client.put(f"/global-parameters/{self._client.encode_name(name)}", body)
        print(f"Global parameter '{name}' set.")

    def clear(self, name: str):
        """清除全局参数

        Args:
            name: 参数名称
        """
        self._client.delete(f"/global-parameters/{self._client.encode_name(name)}")
        print(f"Global parameter '{name}' cleared.")
