"""队列 leader 重平衡命令: rmqadm rebalance <subcommand>"""

from rmqadm.client import RabbitMQClient
from rich.console import Console

console = Console()


class RebalanceCommands:
    """RabbitMQ 队列 Leader 副本重平衡"""

    def __init__(self, client: RabbitMQClient):
        self._client = client

    def queues(self, vhost: str = None):
        """重平衡所有队列的 leader 副本分布

        Args:
            vhost: 仅重平衡指定 vhost 的队列（不填则全集群）
        """
        if vhost:
            path = f"/rebalance/queues?vhost={self._client.encode_name(vhost)}"
        else:
            path = "/rebalance/queues"
        self._client.post(path)
        console.print("[green]Queue leader rebalancing triggered.[/green]")
