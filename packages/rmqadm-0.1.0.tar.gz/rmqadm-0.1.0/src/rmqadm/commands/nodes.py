"""节点查看命令: rmqadm nodes <subcommand>"""

from rmqadm.client import RabbitMQClient
from rmqadm.formatter import print_table, print_json


class NodesCommands:
    """查看 RabbitMQ 集群节点信息"""

    _LIST_COLUMNS = ["name", "type", "running", "os_pid", "mem_used", "disk_free", "fd_used", "fd_total"]

    def __init__(self, client: RabbitMQClient):
        self._client = client

    def list(self, format: str = "table"):
        """列出所有节点

        Args:
            format: 输出格式，table 或 json（默认 table）
        """
        data = self._client.get("/nodes")
        if format == "json":
            print_json(data)
        else:
            print_table(data, columns=self._LIST_COLUMNS)

    def show(self, name: str, format: str = "table"):
        """显示节点详情

        Args:
            name:   节点名称（如 rabbit@hostname）
            format: 输出格式，table 或 json（默认 table）
        """
        data = self._client.get(f"/nodes/{self._client.encode_name(name)}")
        if format == "json":
            print_json(data)
        else:
            print_table([data], columns=self._LIST_COLUMNS)
