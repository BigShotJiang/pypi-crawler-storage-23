"""Channel 查看命令: rmqadm channels <subcommand>"""

from rmqadm.client import RabbitMQClient
from rmqadm.formatter import print_table, print_json


class ChannelsCommands:
    """查看 RabbitMQ Channel 信息"""

    _LIST_COLUMNS = ["name", "vhost", "user", "number", "state", "prefetch_count", "consumer_count"]

    def __init__(self, client: RabbitMQClient):
        self._client = client

    def list(self, format: str = "table"):
        """列出所有 channel

        Args:
            format: 输出格式，table 或 json（默认 table）
        """
        data = self._client.get("/channels")
        if format == "json":
            print_json(data)
        else:
            print_table(data, columns=self._LIST_COLUMNS)

    def show(self, name: str, format: str = "table"):
        """显示 channel 详情

        Args:
            name:   channel 名称
            format: 输出格式，table 或 json（默认 table）
        """
        data = self._client.get(f"/channels/{self._client.encode_name(name)}")
        if format == "json":
            print_json(data)
        else:
            print_table([data], columns=self._LIST_COLUMNS)
