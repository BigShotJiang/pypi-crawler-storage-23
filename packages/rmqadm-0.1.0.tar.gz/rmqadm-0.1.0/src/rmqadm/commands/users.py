"""用户管理命令: rmqadm users <subcommand>"""

from rmqadm.client import RabbitMQClient
from rmqadm.formatter import print_table, print_json


class UsersCommands:
    """管理 RabbitMQ 用户"""

    # 列表显示的默认列
    _LIST_COLUMNS = ["name", "tags", "password_hash", "hashing_algorithm"]

    def __init__(self, client: RabbitMQClient):
        self._client = client

    def list(self, format: str = "table"):
        """列出所有用户

        Args:
            format: 输出格式，table 或 json（默认 table）
        """
        data = self._client.get("/users")
        if format == "json":
            print_json(data)
        else:
            print_table(data, columns=self._LIST_COLUMNS)

    def show(self, name: str, format: str = "table"):
        """显示指定用户的详情

        Args:
            name: 用户名
            format: 输出格式，table 或 json（默认 table）
        """
        data = self._client.get(f"/users/{self._client.encode_name(name)}")
        if format == "json":
            print_json(data)
        else:
            print_table([data], columns=self._LIST_COLUMNS)

    def create(self, name: str, password: str = "", tags: str = ""):
        """创建或更新用户

        Args:
            name:     用户名
            password: 密码（明文，由服务端哈希）
            tags:     角色标签，逗号分隔，如 administrator,management
        """
        body = {"password": password, "tags": tags}
        self._client.put(f"/users/{self._client.encode_name(name)}", body)
        print(f"User '{name}' created.")

    def delete(self, name: str):
        """删除用户

        Args:
            name: 用户名
        """
        self._client.delete(f"/users/{self._client.encode_name(name)}")
        print(f"User '{name}' deleted.")

    def whoami(self, format: str = "table"):
        """显示当前登录用户信息

        Args:
            format: 输出格式，table 或 json（默认 table）
        """
        data = self._client.get("/whoami")
        if format == "json":
            print_json(data)
        else:
            print_table([data])
