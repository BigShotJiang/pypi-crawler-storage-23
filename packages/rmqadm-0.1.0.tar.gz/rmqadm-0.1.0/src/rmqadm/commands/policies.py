"""策略管理命令: rmqadm policies <subcommand>"""

import json as _json

from rmqadm.client import RabbitMQClient
from rmqadm.formatter import print_table, print_json


class PoliciesCommands:
    """管理 RabbitMQ 策略（Policies）"""

    _LIST_COLUMNS = ["vhost", "name", "pattern", "apply-to", "priority", "definition"]

    def __init__(self, client: RabbitMQClient, default_vhost: str = "/"):
        self._client = client
        self._default_vhost = default_vhost

    def list(self, vhost: str = None, format: str = "table"):
        """列出策略

        Args:
            vhost:  指定 vhost，不填则列出所有 vhost 的策略
            format: 输出格式，table 或 json（默认 table）
        """
        if vhost:
            path = f"/policies/{self._client.encode_name(vhost)}"
        else:
            path = "/policies"
        data = self._client.get(path)
        if format == "json":
            print_json(data)
        else:
            print_table(data, columns=self._LIST_COLUMNS)

    def show(self, name: str, vhost: str = None, format: str = "table"):
        """显示策略详情

        Args:
            name:   策略名称
            vhost:  vhost 名称（默认 /）
            format: 输出格式，table 或 json（默认 table）
        """
        vhost = vhost or self._default_vhost
        path = f"/policies/{self._client.encode_name(vhost)}/{self._client.encode_name(name)}"
        data = self._client.get(path)
        if format == "json":
            print_json(data)
        else:
            print_table([data], columns=self._LIST_COLUMNS)

    def declare(self, name: str, pattern: str, definition: str,
                apply_to: str = "all", priority: int = 0, vhost: str = None):
        """创建或更新策略

        Args:
            name:       策略名称
            pattern:    匹配实体名称的正则表达式
            definition: 策略定义（JSON 字符串），如 '{"ha-mode":"all"}'
            apply_to:   应用对象：all/queues/classic_queues/quorum_queues/streams/exchanges（默认 all）
            priority:   优先级，数字越大优先级越高（默认 0）
            vhost:      vhost 名称（默认 /）
        """
        vhost = vhost or self._default_vhost
        try:
            definition_dict = _json.loads(definition)
        except _json.JSONDecodeError as e:
            raise ValueError(f"definition 必须是合法的 JSON 字符串: {e}") from e

        body = {
            "pattern": pattern,
            "definition": definition_dict,
            "apply-to": apply_to,
            "priority": priority,
        }
        path = f"/policies/{self._client.encode_name(vhost)}/{self._client.encode_name(name)}"
        self._client.put(path, body)
        print(f"Policy '{name}' in vhost '{vhost}' declared.")

    def delete(self, name: str, vhost: str = None):
        """删除策略

        Args:
            name:  策略名称
            vhost: vhost 名称（默认 /）
        """
        vhost = vhost or self._default_vhost
        path = f"/policies/{self._client.encode_name(vhost)}/{self._client.encode_name(name)}"
        self._client.delete(path)
        print(f"Policy '{name}' in vhost '{vhost}' deleted.")
