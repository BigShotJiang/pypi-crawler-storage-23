"""rmqadm - RabbitMQ 管理命令行工具"""
