# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

rmqadm 是一个 RabbitMQ 管理命令行工具，用于简化 RabbitMQ 的日常管理操作。

- **技术栈**: Python 3.12+, fire (CLI框架), requests (HTTP客户端)
- **包管理**: uv
- **Python 解释器**: `./.venv/bin/python`

## 常用命令

### 环境设置

```bash
# 安装依赖
uv sync

# 激活虚拟环境
source .venv/bin/activate
```

### 开发与测试

```bash
# 运行CLI工具（开发模式）
uv run rmqadm

# 安装到本地（可编辑模式）
uv pip install -e .

# 运行已安装的命令
rmqadm
```

## 项目结构

```
rmqadm/
├── src/rmqadm/          # 主要源代码目录
│   ├── cli.py           # CLI 入口点，main() 函数所在
│   └── ...              # 其他模块
├── pyproject.toml       # 项目配置和依赖
└── uv.lock             # 依赖锁文件
```

## 架构说明

### CLI 框架

项目使用 Google Fire 作为 CLI 框架，入口点位于 `src/rmqadm/cli.py` 的 `main()` 函数。Fire 自动将 Python 类和函数转换为 CLI 命令。

### RabbitMQ 交互

工具通过 RabbitMQ Management HTTP API 进行交互，使用 requests 库发送 HTTP 请求。需要处理：
- 连接配置（host, port, username, password）
- API 认证
- 错误处理和重试逻辑

## 开发注意事项

- 所有源代码放在 `src/rmqadm/` 目录下
- 使用 uv 管理所有依赖，不要使用 pip 直接安装
- Python 版本最低要求 3.12
- CLI 命令设计应简洁直观，遵循 Unix 哲学
