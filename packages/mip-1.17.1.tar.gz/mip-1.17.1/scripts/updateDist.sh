rm dist/*
python -m pip install build
python -m build
