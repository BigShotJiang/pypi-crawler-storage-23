Python MIP Documentation
============================================================

.. toctree::
   :maxdepth: 3
   :caption: Contents:
    
   intro
   install
   quickstart
   examples
   sos
   custom
   bench
   extern
   classes
   bibliography



