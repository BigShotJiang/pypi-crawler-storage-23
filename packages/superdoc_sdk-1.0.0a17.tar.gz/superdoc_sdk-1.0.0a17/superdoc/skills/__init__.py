# Skill prompt templates.
