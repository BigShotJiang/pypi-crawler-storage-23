# Web API

For testing the Foundation Models SDK integrated with a web API (e.g., FastAPI, Flask, Django).
