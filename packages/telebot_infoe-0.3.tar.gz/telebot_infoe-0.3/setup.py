from setuptools import setup, find_packages

setup(
    name="telebot_infoe",
    version="0.3",
    packages=find_packages(),
    author="fuckkkkk you 2 3 4",
    description="Simple Scopper Library",
    classifiers=[
        "Programming Language :: Python :: 3",
    ],
    python_requires='>=3.6',
)
