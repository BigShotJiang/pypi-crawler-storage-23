# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing_extensions import Literal, TypeAlias

__all__ = ["DisputeAlertType"]

DisputeAlertType: TypeAlias = Literal["dispute", "dispute_rdr", "fraud"]
