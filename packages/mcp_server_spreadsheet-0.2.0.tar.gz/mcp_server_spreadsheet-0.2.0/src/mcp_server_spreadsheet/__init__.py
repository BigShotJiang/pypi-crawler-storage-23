"""MCP server for reading and writing spreadsheet files."""

__version__ = "0.2.0"
