"""Local dev entry point — delegates to the installed package."""

from mcp_server_spreadsheet.server import main

if __name__ == "__main__":
    main()
