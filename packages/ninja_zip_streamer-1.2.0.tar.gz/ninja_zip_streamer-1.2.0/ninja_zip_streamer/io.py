"""Module dedicated to IOs."""

import os
import mmap
from pathlib import Path


def write(chunks, out_file: str):
    """Provides an iterator to write a file in O_DIRECT mode from chunks (iterable)."""
    Path(os.path.dirname(out_file)).mkdir(parents=True, exist_ok=True)
    f = os.open(out_file, os.O_RDWR | os.O_CREAT | os.O_DIRECT)
    out_buf = None
    for chunk in chunks:
        out_buf = out_buf + chunk if out_buf else chunk
        # Write contiguous buffer aligned to 512 bytes
        bsz = 512 * (len(out_buf) // 512)
        if bsz > 0:
            m = mmap.mmap(-1, bsz)
            m.write(out_buf[:bsz])
            os.write(f, m)
        # Keep remaining bytes (i.e. not written)
        out_buf = out_buf[bsz:]

    # Write remaining bytes, if any
    if out_buf and len(out_buf) > 0:
        n = mmap.mmap(-1, 512)
        n.write(out_buf)
        os.write(f, n)

        # Removing extra bits of the file
        pos = os.fstat(f).st_size - 512 + len(out_buf)
        os.truncate(f, length=pos)

    os.close(f)


def read(
    local_file_path: str,
    chunk_size: int,
    offset: int = 0,
    length: int = 0,
):
    """Generates chunks from a local file."""
    disk_fd = os.open(os.path.join(local_file_path), os.O_RDONLY | os.O_DIRECT)
    with os.fdopen(disk_fd, "rb+", 0) as f:
        offset_512 = 512 * (offset // 512)  # nearest smaller multiple of 512
        f.seek(offset_512)  # must be a multiple of 512
        while True:
            start_pos = f.tell()
            m = mmap.mmap(-1, chunk_size)
            if not f.readinto(m):
                break
            bytes_read = f.tell() - start_pos
            extra_bits = max(0, f.tell() - offset - length) if length else 0
            buf = m.read(bytes_read)
            if start_pos == offset_512:
                # First chunk needs extra starting bits removal
                buf = buf[offset - offset_512:]
            if extra_bits:
                # Last chunk needs extra ending bits removal
                buf = buf[:-extra_bits]
            yield buf
            if extra_bits:
                break
