"""Core functions and classes."""

import os
import hashlib
from functools import partial
import zipfile
import zlib
import requests
from stream_unzip import stream_unzip, NotStreamUnzippable
from ninja_zip_streamer.utils import get_session, get_logger_for
from ninja_zip_streamer.io import write, read

log = get_logger_for(__name__)
DEFAULT_CHUNK_SIZE = 1024 * 32


class WrongChecksum(Exception):
    """The computed checksum is not what's expected."""


def from_local_file(local_file_path: str, chunk_size: int = DEFAULT_CHUNK_SIZE):
    """Generates chunks from a local file."""
    log.debug(
        "Generating chunks of size %s from local file %s", chunk_size, local_file_path
    )
    return read(local_file_path=local_file_path, chunk_size=DEFAULT_CHUNK_SIZE)


def from_remote_file(
    url: str,
    chunk_size: int = DEFAULT_CHUNK_SIZE,
    verify: bool = True,
    headers: dict[str, str] | None = None,
    timeout: int = 30,
    session: requests.Session | None = None,
    expected_md5sum: str = "",
):
    """Stream chunks from a remote file."""
    log.debug("Generating chunks of size %s from remote file %s", chunk_size, url)
    sess = session or get_session()
    sess.headers.update(headers or {})
    sig = hashlib.md5()
    with sess.get(url, verify=verify, stream=True, timeout=timeout) as r:
        r.raise_for_status()
        for chunk in r.iter_content(chunk_size=chunk_size):
            sig.update(chunk)
            yield chunk

    # Check the checksum
    md5sum = str(sig.hexdigest())
    if expected_md5sum and md5sum != expected_md5sum:
        raise WrongChecksum(
            f"Expected checksum is {expected_md5sum} but I got {md5sum}"
        )


def download(out_file: str, **kwargs):
    """Download a single file."""
    write(chunks=from_remote_file(**kwargs), out_file=out_file)


def stream_extract(  # pylint: disable=too-many-locals
    pth_or_url: str, out_dir: str, only_suffixes: list[str] | None = None, **kwargs
) -> list[str]:
    """Extract files from a streamed archive (remote or local file)."""
    if only_suffixes:
        log.info("Extracting only files with this suffixes: %s", only_suffixes)

    # Decompress chunks and write files in O_DIRECT mode
    out_local_files = []
    chunks_func = (
        partial(from_remote_file, url=pth_or_url)
        if pth_or_url.lower().startswith(("https://", "http://"))
        else partial(from_local_file, local_file_path=pth_or_url)
    )
    for file_name, file_size, unzipped_chunks in stream_unzip(chunks_func(**kwargs)):
        name = file_name.decode("utf-8")
        if only_suffixes and not name.endswith(tuple(only_suffixes)):
            log.debug("The file %s does not match the provided suffix list", name)
            # This is required to continue
            for _ in unzipped_chunks:
                pass
            continue
        out = os.path.join(out_dir, name)
        if file_size == 0:
            log.info("Directory %s", out)
        else:
            log.info("Writing file %s (size is %s)", out, file_size)
            write(chunks=unzipped_chunks, out_file=out)
            out_local_files.append(out)
    return out_local_files


def extract(
    pth_or_url: str, out_dir: str, only_suffixes: list[str] | None = None, **kwargs
) -> list[str]:
    """Try to extract files from a stream, and falls back to classic zipFile approach."""
    try:
        return stream_extract(
            pth_or_url=pth_or_url,
            out_dir=out_dir,
            only_suffixes=only_suffixes,
            **kwargs,
        )
    except NotStreamUnzippable:
        # This is discussed here:
        # https://github.com/uktrade/stream-unzip/issues/152
        # In short stream-unzip does not cover particular cases.
        log.warning("File is not stream-unzipable. Falling back to zipFile.")

    # Download the remote archive locally
    is_url = pth_or_url.lower().startswith(("https://", "http://"))
    if is_url:
        local_archive_file = os.path.join(out_dir, os.path.basename(pth_or_url))
        log.info("Downloading %s to %s", pth_or_url, local_archive_file)
        download(out_file=local_archive_file, url=pth_or_url, **kwargs)
    else:
        local_archive_file = pth_or_url

    # Use zipfile + direct write to extract files (not builtin methods of zipfile)
    out_local_files = []
    with open(local_archive_file, "rb") as src:
        with zipfile.ZipFile(src) as zf:
            for m in zf.infolist():
                out_file = os.path.join(out_dir, m.filename)
                log.info(f"writing {out_file}")
                write(
                    out_file=out_file,
                    chunks=map(
                        lambda x: x
                        if m.compress_type == 0  # pylint: disable=cell-var-from-loop
                        else zlib.decompressobj(-15),
                        read(
                            local_file_path=local_archive_file,
                            chunk_size=DEFAULT_CHUNK_SIZE,
                            offset=m.header_offset + len(m.FileHeader()),
                            length=m.file_size,
                        ),
                    ),
                )
                out_local_files.append(out_file)

    # Delete the archive
    if is_url:
        os.remove(local_archive_file)

    return out_local_files
