"""Testing `download()`."""

from helpers import URL, MD5SUM, BL_ZIP, diff, download_and_extract_baseline
from ninja_zip_streamer import download
from ninja_zip_streamer.core import WrongChecksum


def test_download_file():
    """Test to download a single remote file."""
    out = "/tmp/local2/file.raw"
    download_and_extract_baseline()
    download(url=URL, out_file=out)
    diff(out_file=out, bl_file=BL_ZIP)


def test_md5sum():
    """Check that the archive md5sum is correct."""
    out = "/tmp/remote3"
    download(url=URL, out_file=out, expected_md5sum=MD5SUM)
    download_and_extract_baseline()
    diff(out_file=out, bl_file=BL_ZIP)

    out = "/tmp/remote4"
    try:
        download(url=URL, out_file=out, expected_md5sum="purposely-wrong-checksum")
        assert False  # pragma: no-cover
    except WrongChecksum:
        print("Failing as expected")
