"""Helpers for tests."""

import os
import subprocess
import zipfile
import requests


URL = "https://nextcloud.inrae.fr/s/LSmCRfWDNz7fXTB/download"
MD5SUM = "ccd11b91411d78f4771bb07188206093"
# URL = "https://nextcloud.inrae.fr/s/ryNw4Gi8TGaassa/download"  # smaller file
BL_ZIP = "/tmp/archive.zip"
BL_UNZIPPED = "/tmp/bl_unzipped"

LARGE_UNSTREAMABLE_ZIP_URL = "https://nextcloud.inrae.fr/s/KXdjy8cgpG4xMMo/download"
LARGE_ZIP = "/tmp/bl_large_archive.zip"
LARGE_UNZIPPED = "/tmp/bl_large_unzipped"


def diff(out_file: str, bl_file: str):
    """Compare the baseline with the extracted directory."""
    cmd = ["diff", out_file, bl_file]
    print(f"Command: {cmd}")
    proc = subprocess.run(cmd, check=True)
    assert proc.returncode == 0, "Wrong return code of diff command"


def download_and_extract_baseline():
    """Download and extract the baseline."""
    if os.path.isdir(BL_UNZIPPED):
        return
    with open(BL_ZIP, "wb") as file:
        file.write(requests.get(URL, timeout=10).content)
    with zipfile.ZipFile(BL_ZIP, "r") as zip_ref:
        zip_ref.extractall(BL_UNZIPPED)


def download_and_extract_unstreamable_baseline():
    """Download and extract the "large unstreamable" baseline."""
    if os.path.isdir(LARGE_UNZIPPED):
        return
    with open(LARGE_ZIP, "wb") as file:
        file.write(requests.get(LARGE_UNSTREAMABLE_ZIP_URL, timeout=10).content)
    with zipfile.ZipFile(LARGE_ZIP, "r") as zip_ref:
        zip_ref.extractall(LARGE_UNZIPPED)
