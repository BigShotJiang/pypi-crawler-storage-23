"""Testing `extract()`."""

import os
import glob
from helpers import (
    URL,
    MD5SUM,
    BL_ZIP,
    BL_UNZIPPED,
    LARGE_UNSTREAMABLE_ZIP_URL,
    LARGE_UNZIPPED,
    diff,
    download_and_extract_baseline,
    download_and_extract_unstreamable_baseline,
)
from ninja_zip_streamer import extract
from ninja_zip_streamer.core import WrongChecksum


def test_remote_archive():
    """Test to grab/decompress a remote archive."""
    out = "/tmp/remote"
    extract(URL, out)
    download_and_extract_baseline()
    diff(out_file=out, bl_file=BL_UNZIPPED)


def test_remote_unstreamable_archive():
    """Test to grab/decompress the unstreamable remote archive."""
    out = "/tmp/remote_large"
    extract(LARGE_UNSTREAMABLE_ZIP_URL, out)
    download_and_extract_unstreamable_baseline()
    diff(out_file=out, bl_file=LARGE_UNZIPPED)


def test_local_archive():
    """Test to grab/decompress a local archive."""
    out = "/tmp/local"
    download_and_extract_baseline()
    extract(BL_ZIP, out)
    diff(out_file=out, bl_file=BL_UNZIPPED)


def test_extract_only_suffixes():
    """ "Test the extraction of subset of suffixes."""
    out = "/tmp/local_suffixes"
    extract(BL_ZIP, out, only_suffixes=".xml")
    for file in glob.glob(os.path.join(out, "**/*")):
        if os.path.isfile(file):
            assert file.endswith(".xml")


def test_md5sum():
    """Check that the archive md5sum is correct."""
    out = "/tmp/remote1"
    extract(URL, out, expected_md5sum=MD5SUM)
    download_and_extract_baseline()
    diff(out_file=out, bl_file=BL_UNZIPPED)

    out = "/tmp/remote2"
    try:
        extract(URL, out, expected_md5sum="purposely-wrong-checksum")
        assert False  # pragma: no-cover
    except WrongChecksum:
        print("Failing as expected")
