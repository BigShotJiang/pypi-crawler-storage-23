```shell
uv python list
uv venv --python 3.12
uv pip install xxx
uv pip freeze > requirements.txt

uv run python main.py
```