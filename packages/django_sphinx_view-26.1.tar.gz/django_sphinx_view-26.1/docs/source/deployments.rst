===================
Deploying your docs
===================

Getting your docs online has two essential steps:

1. Build your docs, using the `make json` command.
2. Make sure the files are in the right place on your webserver.

Build Locally
=============

Perhaps the simplest way to get started is to build your docs locally, and then upload them to your webserver from
there.

You'll be building your docs locally anyway for development and testing, so the extra upload step is a natural
progression.


Assuming you set ``TARGET_HOST`` and ``TARGET_PATH`` environment variables, you can use ``rsync`` to upload your built
docs:

.. code-block:: bash

    rsync -a ./build/json/ $TARGET_HOST:$TARGET_PATH

This will copy the contents of the ``./build/json/`` directory to the ``$TARGET_PATH`` directory on the ``$TARGET_HOST``.

Build from CI
=============

Do the same but in your CI system.

You'll need to give access to the webserver, so you can use secrets to add sensitive information, like your SSH key,
and even the host and path.

Another option is to allow fetching the built docs from the server's end. GitHub Actions, for example, allow you to
upload an artifact, that you can then fetch from the server.
