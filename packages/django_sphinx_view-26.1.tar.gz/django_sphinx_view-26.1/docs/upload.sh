#!/bin/bash
# This script uploads the file to the server
TARGET_HOST=apr22
TARGET_PATH=/home/ubuntu/doc_builds/sphinx-view-docs
rsync -a build/json/ $TARGET_HOST:$TARGET_PATH
