# django-sphinx-view

> Django Powered Dynamic Sphinx Docs.

Serve your Sphinx docs with Django. Add any dynamic elements that you need. 

![sphinx-meets-htmx](https://github.com/carltongibson/django-sphinx-view/assets/64686/e16b72ee-e3f3-4a8c-b9ba-0ded6c0a0636)

Please see [the project homepage for docs][homepage].

[homepage]: https://noumenal.es/django-sphinx-view/


## Contributing

All input welcome! ⛵️

* Check out [the issues](https://github.com/carltongibson/django-sphinx-view/issues)
* Start a [Discussion with your idea](https://github.com/carltongibson/django-sphinx-view/discussions).
