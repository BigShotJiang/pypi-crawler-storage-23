# plugin-youtube

OMUAPPSにYoutubeのサポートを追加するプラグインです。
