from typing import TypedDict


class TrackingParams(TypedDict):
    trackingParams: str


class ClickTrackingParams(TypedDict):
    clickTrackingParams: str
