"""Optional module wrappers for framework integration."""

from .torch_module import TorchSeparatorModule

__all__ = ["TorchSeparatorModule"]
