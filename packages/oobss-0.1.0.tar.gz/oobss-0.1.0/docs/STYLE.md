# Docs Style Guide

- Use 4 spaces for Markdown indentation in lists and nested blocks.
- Keep all documentation and comments in English.
