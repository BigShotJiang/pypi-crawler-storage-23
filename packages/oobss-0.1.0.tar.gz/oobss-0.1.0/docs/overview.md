# Overview

oobss provides online and batch blind source separation algorithms with a small,
consistent Python API and command-line entrypoint.
