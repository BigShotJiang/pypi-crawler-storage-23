"""MCP tools for domain management."""

from porkbun_domain_mcp.tools.domain_tools import register_domain_tools

__all__ = ["register_domain_tools"]
