"""Assemble and write the JSON benchmark report."""

from __future__ import annotations

import json
from pathlib import Path

from .models import BenchmarkReport


def write_report(report: BenchmarkReport, output_path: str | Path) -> None:
    """Serialize *report* and write it to *output_path*."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(report.model_dump(), indent=2),
        encoding="utf-8",
    )
