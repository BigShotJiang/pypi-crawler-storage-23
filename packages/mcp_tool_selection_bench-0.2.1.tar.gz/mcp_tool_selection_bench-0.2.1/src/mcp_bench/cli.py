"""CLI entry point — wire together query generation, evaluation, scoring, and reporting."""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

from .models import BenchmarkReport, RunMetadata, TestCase, Tool
from .report import write_report

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Argument parsing
# ---------------------------------------------------------------------------

def _parse_args(argv: list[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="mcp-bench",
        description="Benchmark LLM tool-selection accuracy for MCP tools.",
    )
    subparsers = parser.add_subparsers(dest="command")

    # --- `run` subcommand (default) ----------------------------------------
    run_parser = subparsers.add_parser("run", help="Run a benchmark.")
    run_parser.add_argument(
        "--tools", required=True,
        help="Path to tools.json (tool registry).",
    )
    run_parser.add_argument(
        "--test-suite", required=True,
        help="Path to test_suite.json (ground-truth instructions).",
    )
    run_parser.add_argument(
        "--models", required=True, nargs="+",
        help="Model names to benchmark (e.g. gpt-5 claude-sonnet-4).",
    )
    run_parser.add_argument(
        "--output", default="results.json",
        help="Output path for the JSON report (default: results.json).",
    )
    run_parser.add_argument(
        "--variations", type=int, default=5,
        help="Number of query variations per instruction (default: 5).",
    )
    run_parser.add_argument(
        "--generator-model", default=None,
        help="Model used to generate query variations. Defaults to the first model in --models.",
    )
    run_parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Enable verbose (DEBUG) logging.",
    )
    run_parser.add_argument(
        "--html", default=None,
        help="Output path for an HTML report with confusion-matrix heatmaps.",
    )
    run_parser.add_argument(
        "--suggest", action="store_true",
        help="Generate tool-description improvement suggestions (extra API calls).",
    )
    run_parser.add_argument(
        "--suggest-threshold", type=float, default=0.7,
        help="Accuracy threshold below which to suggest description improvements (default: 0.7).",
    )
    run_parser.add_argument(
        "--fail-under", type=float, default=None,
        help="Exit with code 1 if any model's exact-match accuracy is below this threshold (e.g. 0.7).",
    )

    # --- `diff` subcommand -------------------------------------------------
    diff_parser = subparsers.add_parser(
        "diff", help="Compare two benchmark result files.",
    )
    diff_parser.add_argument(
        "baseline", help="Path to the baseline results JSON.",
    )
    diff_parser.add_argument(
        "current", help="Path to the current results JSON.",
    )
    diff_parser.add_argument(
        "--html", default=None,
        help="Output path for an HTML diff report.",
    )
    diff_parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Enable verbose (DEBUG) logging.",
    )
    diff_parser.add_argument(
        "--fail-under", type=float, default=None,
        help="Exit with code 1 if any model regressed by more than this amount (e.g. 0.05).",
    )

    # --- `generate` subcommand ---------------------------------------------
    gen_parser = subparsers.add_parser(
        "generate", help="Auto-generate a test suite from tool definitions.",
    )
    gen_parser.add_argument(
        "--tools", required=True,
        help="Path to tools.json (tool registry).",
    )
    gen_parser.add_argument(
        "--output", default="test_suite.json",
        help="Output path for the generated test suite (default: test_suite.json).",
    )
    gen_parser.add_argument(
        "--per-tool", type=int, default=4,
        help="Number of test cases to generate per tool (default: 4).",
    )
    gen_parser.add_argument(
        "--model", default=None,
        help="Model to use for generation.",
    )
    gen_parser.add_argument(
        "-v", "--verbose", action="store_true",
        help="Enable verbose (DEBUG) logging.",
    )

    args = parser.parse_args(argv)

    # Default to "run" when no subcommand given but --tools is present
    if args.command is None:
        # Re-parse as "run" for backward compatibility
        args = run_parser.parse_args(argv)
        args.command = "run"

    return args


# ---------------------------------------------------------------------------
# Loaders
# ---------------------------------------------------------------------------

def _load_tools(path: str) -> list[Tool]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return [Tool(**item) for item in data]


def _load_test_suite(path: str) -> list[TestCase]:
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return [TestCase(**item) for item in data]


# ---------------------------------------------------------------------------
# `run` command
# ---------------------------------------------------------------------------

async def _run(args: argparse.Namespace) -> None:
    import os

    from copilot import CopilotClient

    from .evaluator import evaluate_model
    from .query_generator import generate_variations
    from .scorer import (
        build_confusion_matrix,
        build_instruction_result,
        build_model_result,
        build_summary,
        score_variations,
    )
    from .visualize import write_html_report

    tools = _load_tools(args.tools)
    test_suite = _load_test_suite(args.test_suite)
    models: list[str] = args.models
    num_variations: int = args.variations
    generator_model: str = args.generator_model or models[0]

    total_queries = len(test_suite) * num_variations * len(models)
    print(
        f"⚠  This run will make ~{total_queries + len(test_suite)} API requests "
        f"({len(test_suite)} instructions × {num_variations} variations × "
        f"{len(models)} models + {len(test_suite)} generation calls)."
    )

    # Authenticate: explicit token from env var, or fall back to logged-in user
    github_token = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")
    client_opts: dict = {}
    if github_token:
        client_opts["github_token"] = github_token
    client = CopilotClient(client_opts)
    await client.start()

    try:
        # --- Step 1: Generate query variations ---------------------------------
        print(f"\n🔄 Generating {num_variations} variations per instruction "
              f"using model '{generator_model}' …")
        all_variations: dict[str, list] = {}
        for i, tc in enumerate(test_suite, 1):
            print(f"  [{i}/{len(test_suite)}] {tc.instruction[:60]}…")
            variations = await generate_variations(
                client, tc, tools, num_variations, model=generator_model,
            )
            all_variations[tc.instruction] = variations

        # --- Step 2: Evaluate each model ---------------------------------------
        per_model_results = {}
        for model in models:
            print(f"\n🧪 Evaluating model '{model}' …")
            instruction_results = []
            for j, tc in enumerate(test_suite, 1):
                print(f"  [{j}/{len(test_suite)}] {tc.instruction[:60]}…")
                variations = all_variations[tc.instruction]
                evaluated = await evaluate_model(client, model, tools, variations)
                scored = score_variations(evaluated, tc.expected_tools)
                ir = build_instruction_result(tc.instruction, tc.expected_tools, scored)
                instruction_results.append(ir)

            per_model_results[model] = build_model_result(instruction_results)

        # --- Step 3: Build confusion matrices ---------------------------------
        confusion_matrices = {}
        for model in models:
            confusion_matrices[model] = build_confusion_matrix(
                per_model_results[model],
            )

        # --- Step 4: Build report ---------------------------------------------
        summary = build_summary(per_model_results)
        report = BenchmarkReport(
            run_metadata=RunMetadata(
                timestamp=datetime.now(timezone.utc).isoformat(),
                models_tested=models,
                num_instructions=len(test_suite),
                variations_per_instruction=num_variations,
                total_queries=len(test_suite) * num_variations * len(models),
            ),
            per_model_results=per_model_results,
            summary=summary,
            confusion_matrices=confusion_matrices,
        )

        # --- Step 5: Generate description suggestions (optional) ---------------
        if args.suggest:
            from .advisor import generate_suggestions

            print("\n📝 Generating description improvement suggestions …")
            suggestions = await generate_suggestions(
                client,
                report,
                tools,
                threshold=args.suggest_threshold,
                model=generator_model,
            )
            report.suggestions = suggestions
            if suggestions:
                print(f"   {len(suggestions)} suggestion(s) generated.")
            else:
                print("   All tools above threshold — no suggestions needed.")

        write_report(report, args.output)
        print(f"\n✅ Report written to {args.output}")
        print(f"   Best model: {summary.best_model} "
              f"(exact: {summary.best_exact_accuracy:.2%}, "
              f"partial: {summary.best_partial_accuracy:.2%})")

        if args.html:
            write_html_report(report, args.html)
            print(f"   HTML report written to {args.html}")

        # --- Step 6: Fail-under gate ------------------------------------------
        if args.fail_under is not None:
            for model, mr in per_model_results.items():
                if mr.exact_match_accuracy < args.fail_under:
                    print(
                        f"\n❌ FAIL: {model} exact-match accuracy "
                        f"{mr.exact_match_accuracy:.2%} < {args.fail_under:.2%}"
                    )
                    sys.exit(1)
    finally:
        await client.stop()


# ---------------------------------------------------------------------------
# `generate` command
# ---------------------------------------------------------------------------

async def _generate(args: argparse.Namespace) -> None:
    import os

    from copilot import CopilotClient

    from .generator import generate_test_suite

    tools = _load_tools(args.tools)

    print(f"🔧 Generating test suite for {len(tools)} tools "
          f"({args.per_tool} cases each) …")

    github_token = os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN")
    client_opts: dict = {}
    if github_token:
        client_opts["github_token"] = github_token
    client = CopilotClient(client_opts)
    await client.start()

    try:
        cases = await generate_test_suite(
            client, tools, per_tool=args.per_tool, model=args.model,
        )

        # Write output
        output = Path(args.output)
        output.parent.mkdir(parents=True, exist_ok=True)
        data = [tc.model_dump(exclude_defaults=True) for tc in cases]
        output.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")

        single = sum(1 for c in cases if len(c.expected_tools) == 1)
        multi = len(cases) - single
        print(f"\n✅ Generated {len(cases)} test cases "
              f"({single} single-tool, {multi} multi-tool)")
        print(f"   Written to {args.output}")
        print("   Review and edit before running: "
              f"mcp-bench run --tools {args.tools} --test-suite {args.output} --models <models>")
    finally:
        await client.stop()


# ---------------------------------------------------------------------------
# `diff` command
# ---------------------------------------------------------------------------

def _diff(args: argparse.Namespace) -> None:
    from .diff import diff_reports, format_diff_table, load_report
    from .visualize import write_diff_html

    baseline = load_report(args.baseline)
    current = load_report(args.current)
    diff = diff_reports(baseline, current)

    print(format_diff_table(diff))

    if args.html:
        write_diff_html(diff, args.html)
        print(f"\n📄 HTML diff report written to {args.html}")

    # Fail-under gate: exit 1 if any model regressed beyond threshold
    if args.fail_under is not None:
        for md in diff.model_deltas:
            if md.delta_exact < -abs(args.fail_under):
                print(
                    f"\n❌ FAIL: {md.model} regressed by "
                    f"{md.delta_exact:+.2%} (threshold: -{abs(args.fail_under):.2%})"
                )
                sys.exit(1)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main(argv: list[str] | None = None) -> None:
    args = _parse_args(argv)

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(levelname)s %(name)s: %(message)s",
    )

    try:
        if args.command == "diff":
            _diff(args)
        elif args.command == "generate":
            asyncio.run(_generate(args))
        else:
            asyncio.run(_run(args))
    except KeyboardInterrupt:
        print("\nAborted.")
        sys.exit(130)


if __name__ == "__main__":
    main()
