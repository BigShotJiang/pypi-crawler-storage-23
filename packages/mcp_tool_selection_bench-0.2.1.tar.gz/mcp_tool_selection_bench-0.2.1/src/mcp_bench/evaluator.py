"""Evaluate tool selection by sending queries to models via the Copilot SDK."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from copilot import CopilotClient, PermissionHandler
from copilot.types import Tool as SdkTool

from .models import QueryVariation
from .prompts import TOOL_SELECTION_PROMPT

if TYPE_CHECKING:
    from .models import Tool

logger = logging.getLogger(__name__)


def _build_sdk_tools(
    tools: list["Tool"],
    invoked: list[str],
) -> list[SdkTool]:
    """Convert our Tool models into SDK Tool objects.

    Each handler appends its tool name to *invoked* when called,
    so we can capture exactly which tools the model selected.
    """
    sdk_tools = []
    for t in tools:
        async def _handler(invocation, _tool_name=t.name):  # noqa: E501
            invoked.append(_tool_name)
            return {"result": _tool_name}

        sdk_tool = SdkTool(
            name=t.name,
            description=t.description,
            handler=_handler,
            parameters=t.parameters or {
                "type": "object",
                "properties": {},
            },
        )
        sdk_tools.append(sdk_tool)
    return sdk_tools


async def evaluate_model(
    client: CopilotClient,
    model: str,
    tools: list["Tool"],
    variations: list[QueryVariation],
) -> list[QueryVariation]:
    """Send each *variation* to *model* and record which tool it selects.

    Returns a **new** list of QueryVariation with ``selected_tools`` populated.
    """
    results: list[QueryVariation] = []

    for var in variations:
        selected = await _evaluate_single(client, model, tools, var)
        results.append(selected)

    return results


async def _evaluate_single(
    client: CopilotClient,
    model: str,
    tools: list["Tool"],
    variation: QueryVariation,
) -> QueryVariation:
    """Evaluate a single query variation and return an updated copy."""
    prompt = TOOL_SELECTION_PROMPT.format(query=variation.query)

    # Shared list where tool handlers record invocations
    invoked: list[str] = []
    sdk_tools = _build_sdk_tools(tools, invoked)

    try:
        session = await client.create_session({
            "model": model,
            "tools": sdk_tools,
            "on_permission_request": PermissionHandler.approve_all,
        })
        response = await session.send_and_wait({"prompt": prompt})
    except Exception:
        logger.exception("Error evaluating query: %s", variation.query)
        return variation.model_copy(update={"selected_tools": []})

    # Primary: tools captured via handler invocations during send_and_wait
    selected_tools = _dedupe(invoked)

    # Fallback: parse plain-text response if model didn't invoke any tools
    if not selected_tools:
        selected_tools = _extract_from_text(response, tools)

    if not selected_tools:
        text = ""
        if response and response.data:
            text = (response.data.content or "")[:200]
        logger.warning(
            "No tools selected for query: %s | invoked=%s | response_text=%s",
            variation.query[:80], invoked, text,
        )

    return variation.model_copy(update={
        "selected_tools": selected_tools,
    })


def _dedupe(names: list[str]) -> list[str]:
    """Remove duplicates while preserving order."""
    seen: set[str] = set()
    result: list[str] = []
    for name in names:
        if name not in seen:
            result.append(name)
            seen.add(name)
    return result


def _normalize_tool_name(raw: str) -> str:
    """Strip common prefixes/wrappers models add around tool names."""
    name = raw.strip().strip("-").strip("•").strip()
    # Strip prefixes like "functions.", "tools.", "function_call."
    for prefix in ("functions.", "tools.", "function_call."):
        if name.lower().startswith(prefix):
            name = name[len(prefix):]
    # Strip wrapping quotes or backticks
    name = name.strip("`").strip("'").strip('"')
    return name


def _extract_from_text(response, tools: list["Tool"]) -> list[str]:
    """Fallback: parse tool names from the assistant's plain-text response."""
    tool_names_lower = {t.name.lower(): t.name for t in tools}
    selected: list[str] = []
    seen: set[str] = set()

    if not (response and response.data):
        return selected

    text = (response.data.content or "").strip()
    candidates = []
    for line in text.splitlines():
        for part in line.split(","):
            normalized = _normalize_tool_name(part)
            if normalized:
                candidates.append(normalized)

    for candidate in candidates:
        lower = candidate.lower()
        if lower in tool_names_lower:
            name = tool_names_lower[lower]
            if name not in seen:
                selected.append(name)
                seen.add(name)

    return selected
