"""Auto-generate a test suite from tool definitions using the Copilot SDK."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from copilot import PermissionHandler

from .models import TestCase
from .prompts import TEST_SUITE_GENERATION_PROMPT

if TYPE_CHECKING:
    from copilot import CopilotClient

    from .models import Tool

logger = logging.getLogger(__name__)


def build_tools_block(tools: list[Tool]) -> str:
    """Format tool definitions into a readable block for the prompt."""
    lines: list[str] = []
    for t in tools:
        lines.append(f"- **{t.name}**: {t.description}")
        if t.parameters.get("properties"):
            params = ", ".join(
                f"`{k}` ({v.get('type', '?')})"
                for k, v in t.parameters["properties"].items()
            )
            lines.append(f"  Parameters: {params}")
    return "\n".join(lines)


def build_prompt(tools: list[Tool], per_tool: int = 4) -> str:
    """Build the test-suite generation prompt."""
    tools_block = build_tools_block(tools)
    total = len(tools) * per_tool
    multi_count = max(2, len(tools) // 2)
    return TEST_SUITE_GENERATION_PROMPT.format(
        per_tool=per_tool,
        total=total,
        multi_count=multi_count,
        tools_block=tools_block,
    )


def parse_test_cases(raw_text: str, tool_names: set[str]) -> list[TestCase]:
    """Parse LLM response into validated TestCase objects."""
    text = raw_text.strip()

    # Extract JSON array
    start = text.find("[")
    end = text.rfind("]")
    if start == -1 or end == -1:
        logger.error("Could not find JSON array in response: %s", text[:200])
        return []

    json_str = text[start : end + 1]
    try:
        items = json.loads(json_str)
    except json.JSONDecodeError as exc:
        logger.error("Failed to parse JSON: %s — raw: %s", exc, json_str[:200])
        return []

    cases: list[TestCase] = []
    for item in items:
        if not isinstance(item, dict):
            continue

        instruction = item.get("instruction", "").strip()
        if not instruction:
            continue

        # Accept both expected_tools (list) and expected_tool (string)
        expected_tools = item.get("expected_tools", [])
        if not expected_tools:
            expected_tool = item.get("expected_tool", "")
            if expected_tool:
                expected_tools = [expected_tool]

        if not expected_tools:
            logger.warning("Skipping case with no expected tools: %s", instruction[:60])
            continue

        # Validate tool names
        invalid = [t for t in expected_tools if t not in tool_names]
        if invalid:
            logger.warning(
                "Skipping case with unknown tools %s: %s",
                invalid, instruction[:60],
            )
            continue

        cases.append(TestCase(
            instruction=instruction,
            expected_tools=expected_tools,
        ))

    return cases


async def generate_test_suite(
    client: CopilotClient,
    tools: list[Tool],
    per_tool: int = 4,
    model: str | None = None,
) -> list[TestCase]:
    """Generate a test suite from tool definitions via LLM."""
    prompt = build_prompt(tools, per_tool)
    tool_names = {t.name for t in tools}

    session_opts: dict = {
        "on_permission_request": PermissionHandler.approve_all,
    }
    if model:
        session_opts["model"] = model

    session = await client.create_session(session_opts)
    response = await session.send_and_wait({"prompt": prompt})

    raw_text = response.data.content if response and response.data else ""
    cases = parse_test_cases(raw_text, tool_names)

    logger.info("Generated %d test cases from %d tools", len(cases), len(tools))
    return cases
