"""Allow running the package with ``python -m mcp_bench``."""

from .cli import main

main()
