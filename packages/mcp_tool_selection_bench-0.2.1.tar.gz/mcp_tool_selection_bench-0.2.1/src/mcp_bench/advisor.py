"""Analyze results and suggest tool-description improvements."""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from copilot import CopilotClient, PermissionHandler

from .models import ConfusionMatrix, DescriptionSuggestion
from .prompts import DESCRIPTION_ADVISOR_PROMPT

if TYPE_CHECKING:
    from .models import BenchmarkReport, Tool

logger = logging.getLogger(__name__)


def identify_weak_tools(
    report: "BenchmarkReport",
    tools: list["Tool"],
    threshold: float = 0.7,
) -> list[dict]:
    """Find tools that fall below *threshold* accuracy in any model.

    Returns a list of dicts with keys: tool_name, accuracy, confused_with,
    model.
    """
    tool_map = {t.name: t for t in tools}
    weak: list[dict] = []

    for model_name, mr in report.per_model_results.items():
        for ir in mr.per_instruction:
            if ir.exact_match_accuracy < threshold:
                expected_list = ir.expected_tools
                cm = report.confusion_matrices.get(model_name)
                for exp_tool in expected_list:
                    confused_with = _top_confusion(cm, exp_tool)
                    if confused_with and confused_with in tool_map:
                        weak.append({
                            "tool_name": exp_tool,
                            "accuracy": ir.exact_match_accuracy,
                            "confused_with": confused_with,
                            "model": model_name,
                        })

    # Deduplicate by (tool_name, confused_with) — keep worst accuracy
    seen: dict[tuple[str, str], dict] = {}
    for w in weak:
        key = (w["tool_name"], w["confused_with"])
        if key not in seen or w["accuracy"] < seen[key]["accuracy"]:
            seen[key] = w
    return list(seen.values())


def _top_confusion(cm: ConfusionMatrix | None, expected: str) -> str | None:
    """Return the tool most often confused with *expected* (excluding itself)."""
    if not cm or expected not in cm.matrix:
        return None
    row = cm.matrix[expected]
    best_name, best_count = None, 0
    for selected, count in row.items():
        if selected != expected and count > best_count:
            best_name, best_count = selected, count
    return best_name


async def generate_suggestions(
    client: CopilotClient,
    report: "BenchmarkReport",
    tools: list["Tool"],
    threshold: float = 0.7,
    model: str | None = None,
) -> list[DescriptionSuggestion]:
    """Generate description-improvement suggestions for weak tools."""
    tool_map = {t.name: t for t in tools}
    weak = identify_weak_tools(report, tools, threshold)

    if not weak:
        return []

    suggestions: list[DescriptionSuggestion] = []
    session_opts: dict = {
        "on_permission_request": PermissionHandler.approve_all,
    }
    if model:
        session_opts["model"] = model

    for entry in weak:
        tool_name = entry["tool_name"]
        confused_with = entry["confused_with"]
        tool = tool_map.get(tool_name)
        confused_tool = tool_map.get(confused_with)
        if not tool or not confused_tool:
            continue

        prompt = DESCRIPTION_ADVISOR_PROMPT.format(
            tool_name=tool_name,
            confused_with=confused_with,
            current_description=tool.description,
            confused_description=confused_tool.description,
        )

        try:
            session = await client.create_session(session_opts)
            response = await session.send_and_wait({"prompt": prompt})
            suggested = (
                response.data.content.strip()
                if response and response.data and response.data.content
                else ""
            )
        except Exception:
            logger.exception("Error generating suggestion for %s", tool_name)
            suggested = ""

        if suggested:
            suggestions.append(DescriptionSuggestion(
                tool_name=tool_name,
                current_description=tool.description,
                suggested_description=suggested,
                confused_with=confused_with,
                accuracy=entry["accuracy"],
                reason=f"Confused with '{confused_with}' in model '{entry['model']}'",
            ))

    return suggestions
