"""Compare two benchmark reports and produce a regression diff."""

from __future__ import annotations

import json
from pathlib import Path

from .models import (
    BenchmarkReport,
    DiffReport,
    InstructionDelta,
    ModelDelta,
)

REGRESSION_THRESHOLD = 0.05  # 5 %


def _status(delta: float) -> str:
    if delta > REGRESSION_THRESHOLD:
        return "improved"
    elif delta < -REGRESSION_THRESHOLD:
        return "regressed"
    return "unchanged"


def diff_reports(baseline: BenchmarkReport, current: BenchmarkReport) -> DiffReport:
    """Compute deltas between *baseline* and *current* benchmark reports."""
    baseline_models = set(baseline.per_model_results)
    current_models = set(current.per_model_results)

    models_added = sorted(current_models - baseline_models)
    models_removed = sorted(baseline_models - current_models)
    common_models = sorted(baseline_models & current_models)

    model_deltas: list[ModelDelta] = []
    for model in common_models:
        b = baseline.per_model_results[model]
        c = current.per_model_results[model]

        delta_acc = c.exact_match_accuracy - b.exact_match_accuracy
        delta_exact = delta_acc
        delta_partial = c.partial_credit_accuracy - b.partial_credit_accuracy

        # Per-instruction deltas
        b_instr = {ir.instruction: ir for ir in b.per_instruction}
        c_instr = {ir.instruction: ir for ir in c.per_instruction}
        instruction_deltas: list[InstructionDelta] = []

        for instr in sorted(set(b_instr) | set(c_instr)):
            b_acc = b_instr[instr].exact_match_accuracy if instr in b_instr else 0.0
            c_acc = c_instr[instr].exact_match_accuracy if instr in c_instr else 0.0
            d = c_acc - b_acc
            instruction_deltas.append(InstructionDelta(
                instruction=instr,
                baseline_accuracy=b_acc,
                current_accuracy=c_acc,
                delta=d,
                status=_status(d),
            ))

        model_deltas.append(ModelDelta(
            model=model,
            baseline_exact=b.exact_match_accuracy,
            current_exact=c.exact_match_accuracy,
            delta_exact=delta_exact,
            baseline_partial=b.partial_credit_accuracy,
            current_partial=c.partial_credit_accuracy,
            delta_partial=delta_partial,
            status=_status(delta_acc),
            per_instruction=instruction_deltas,
        ))

    return DiffReport(
        baseline_timestamp=baseline.run_metadata.timestamp,
        current_timestamp=current.run_metadata.timestamp,
        model_deltas=model_deltas,
        models_added=models_added,
        models_removed=models_removed,
    )


def load_report(path: str | Path) -> BenchmarkReport:
    """Load a BenchmarkReport from a JSON file."""
    data = json.loads(Path(path).read_text(encoding="utf-8"))
    return BenchmarkReport(**data)


def _arrow(delta: float) -> str:
    if delta > REGRESSION_THRESHOLD:
        return "↑"
    elif delta < -REGRESSION_THRESHOLD:
        return "↓"
    return "="


def format_diff_table(diff: DiffReport) -> str:
    """Format the diff as a readable console table."""
    lines: list[str] = []
    lines.append(f"Baseline: {diff.baseline_timestamp}")
    lines.append(f"Current:  {diff.current_timestamp}")
    lines.append("")

    if diff.models_added:
        lines.append(f"Models added:   {', '.join(diff.models_added)}")
    if diff.models_removed:
        lines.append(f"Models removed: {', '.join(diff.models_removed)}")
    if diff.models_added or diff.models_removed:
        lines.append("")

    # Model summary table
    lines.append(f"{'Model':<25} {'Baseline':>10} {'Current':>10} {'Delta':>10}  ")
    lines.append("-" * 60)
    for md in diff.model_deltas:
        arrow = _arrow(md.delta_exact)
        lines.append(
            f"{md.model:<25} {md.baseline_exact:>9.2%} {md.current_exact:>9.2%} "
            f"{md.delta_exact:>+9.2%} {arrow}"
        )

    # Per-instruction details for models with regressions
    for md in diff.model_deltas:
        regressions = [d for d in md.per_instruction if d.status == "regressed"]
        improvements = [d for d in md.per_instruction if d.status == "improved"]
        if regressions or improvements:
            lines.append(f"\n  [{md.model}]")
            for d in sorted(regressions, key=lambda x: x.delta):
                lines.append(
                    f"    ↓ {d.delta:>+7.2%}  {d.instruction[:60]}"
                )
            for d in sorted(improvements, key=lambda x: x.delta, reverse=True):
                lines.append(
                    f"    ↑ {d.delta:>+7.2%}  {d.instruction[:60]}"
                )

    return "\n".join(lines)
