"""All prompt templates used across the benchmark.

Centralised here so they are easy to find, edit, and tune.
"""

# ---------------------------------------------------------------------------
# Evaluator — tool selection
# ---------------------------------------------------------------------------

TOOL_SELECTION_PROMPT = """\
You are given a specific set of tools registered for this session. Based on \
the user query below, decide which of these registered tools are needed to \
fulfil the request. You MUST only select from the tools provided to you in \
this session — do NOT use or reference any other tools.

If multiple tools are needed, list them in the order they should be executed.

Respond with ONLY the tool name(s) — one per line, nothing else.

User query:
\"{query}\"
"""

# ---------------------------------------------------------------------------
# Query generator — variation generation
# ---------------------------------------------------------------------------

VARIATION_PROMPT_TEMPLATE = """\
You are a benchmark assistant. Given the following natural-language instruction \
and a set of available tools, generate exactly {num_variations} rephrased queries \
that a user might type to accomplish the same goal. Each query should have a \
different level of ambiguity.

Ambiguity levels (one query per level):
{levels}

Original instruction:
\"{instruction}\"

Available tools (for context only — do NOT call any tool):
{tool_names}

Respond with ONLY a JSON array of objects, each with "query" and \
"ambiguity_level" keys. Example:
[
  {{"query": "...", "ambiguity_level": "explicit"}},
  {{"query": "...", "ambiguity_level": "moderate"}}
]
"""

# ---------------------------------------------------------------------------
# Advisor — description improvement suggestions
# ---------------------------------------------------------------------------

DESCRIPTION_ADVISOR_PROMPT = """\
You are an MCP tool-description expert. A benchmark found that the tool \
"{tool_name}" is frequently confused with "{confused_with}".

Current description of "{tool_name}":
\"{current_description}\"

Current description of "{confused_with}":
\"{confused_description}\"

Suggest an improved description for "{tool_name}" that clearly \
distinguishes it from "{confused_with}". Keep it concise (1-2 sentences). \
Respond with ONLY the improved description text — nothing else.
"""

# ---------------------------------------------------------------------------
# Generator — test-suite generation from tool definitions
# ---------------------------------------------------------------------------

TEST_SUITE_GENERATION_PROMPT = """\
You are a benchmark-test-suite generator for MCP (Model Context Protocol) tools.

Below is a registry of available tools with their descriptions and parameters. \
Your job is to generate realistic natural-language instructions that a user \
might type, along with the correct tool(s) needed to fulfil each instruction.

## Requirements

1. Generate exactly {per_tool} test cases for EACH tool listed below \
(total: {total} single-tool cases).
2. Additionally, generate {multi_count} multi-tool test cases that require \
2-3 tools to be called in sequence.
3. Each test case must have varying ambiguity:
   - Some should name the tool's function explicitly (e.g. "search for issues")
   - Some should be moderately ambiguous (e.g. "find bugs in the repo")
   - Some should be vague or indirect (e.g. "what's broken?")
4. Multi-tool cases must list expected_tools in execution order.
5. Every tool name in expected_tools MUST exactly match a \
tool name from the registry below.

## Available Tools

{tools_block}

## Output Format

Respond with ONLY a JSON array — no explanation, no markdown fences.
Each element must be an object with these fields:
- "instruction": the natural-language user query (string)
- "expected_tools": list of tool name(s) needed, in order (array of strings)

Example:
[
  {{"instruction": "Find all open bugs in the react repo", "expected_tools": ["search_issues"]}},
  {{"instruction": "Find bugs in react and check CI logs", "expected_tools": ["search_issues", "get_job_logs"]}}
]
"""
