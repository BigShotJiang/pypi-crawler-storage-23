"""Pydantic data models for inputs, outputs, and intermediate structures."""

from __future__ import annotations

from typing import Any, Optional

from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# Input models
# ---------------------------------------------------------------------------

class Tool(BaseModel):
    """A single MCP tool definition."""

    name: str
    description: str
    parameters: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class TestCase(BaseModel):
    """A ground-truth test case mapping an instruction to the expected tool(s)."""

    instruction: str
    expected_tool: str = ""
    expected_tools: list[str] = Field(default_factory=list)

    def model_post_init(self, __context: Any) -> None:
        """Backward compat: populate expected_tools from expected_tool if needed."""
        if self.expected_tool and not self.expected_tools:
            self.expected_tools = [self.expected_tool]


# ---------------------------------------------------------------------------
# Intermediate / evaluation models
# ---------------------------------------------------------------------------

AMBIGUITY_LEVELS: list[str] = [
    "explicit",
    "moderate",
    "vague",
    "indirect",
    "misleading",
]


class QueryVariation(BaseModel):
    """A single rephrased query and its evaluation result."""

    query: str
    ambiguity_level: str
    selected_tools: list[str] = Field(default_factory=list)
    exact_match: Optional[bool] = None
    partial_score: Optional[float] = None


class InstructionResult(BaseModel):
    """Evaluation results for one original instruction across all its variations."""

    instruction: str
    expected_tools: list[str] = Field(default_factory=list)
    variations: list[QueryVariation] = Field(default_factory=list)
    exact_match_accuracy: float = 0.0
    partial_credit_accuracy: float = 0.0


# ---------------------------------------------------------------------------
# Per-model and overall report models
# ---------------------------------------------------------------------------

class ModelResult(BaseModel):
    """Aggregate results for a single model."""

    exact_match_accuracy: float = 0.0
    partial_credit_accuracy: float = 0.0
    exact_match_count: int = 0
    total: int = 0
    per_instruction: list[InstructionResult] = Field(default_factory=list)


class ModelRanking(BaseModel):
    model: str
    exact_match_accuracy: float


class RunMetadata(BaseModel):
    timestamp: str
    models_tested: list[str]
    num_instructions: int
    variations_per_instruction: int
    total_queries: int


class Summary(BaseModel):
    best_model: str = ""
    best_exact_accuracy: float = 0.0
    best_partial_accuracy: float = 0.0
    model_ranking: list[ModelRanking] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Confusion matrix
# ---------------------------------------------------------------------------

class ConfusionMatrix(BaseModel):
    """Confusion matrix: matrix[expected][selected] = count."""

    labels: list[str] = Field(default_factory=list)
    matrix: dict[str, dict[str, int]] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Description quality suggestions
# ---------------------------------------------------------------------------

class DescriptionSuggestion(BaseModel):
    """A suggestion to improve a tool's description."""

    tool_name: str
    current_description: str
    suggested_description: str
    confused_with: str
    accuracy: float
    reason: str = ""


class BenchmarkReport(BaseModel):
    """Top-level output report."""

    run_metadata: RunMetadata
    per_model_results: dict[str, ModelResult] = Field(default_factory=dict)
    summary: Summary = Field(default_factory=Summary)
    confusion_matrices: dict[str, ConfusionMatrix] = Field(default_factory=dict)
    suggestions: list[DescriptionSuggestion] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Diff / regression tracking models
# ---------------------------------------------------------------------------

class InstructionDelta(BaseModel):
    """Accuracy change for a single instruction between two runs."""

    instruction: str
    baseline_accuracy: float
    current_accuracy: float
    delta: float
    status: str = ""  # "improved", "regressed", "unchanged"


class ModelDelta(BaseModel):
    """Accuracy change for a single model between two runs."""

    model: str
    baseline_exact: float = 0.0
    current_exact: float = 0.0
    delta_exact: float = 0.0
    baseline_partial: float = 0.0
    current_partial: float = 0.0
    delta_partial: float = 0.0
    status: str = ""
    per_instruction: list[InstructionDelta] = Field(default_factory=list)


class DiffReport(BaseModel):
    """Result of comparing two benchmark reports."""

    baseline_timestamp: str = ""
    current_timestamp: str = ""
    model_deltas: list[ModelDelta] = Field(default_factory=list)
    models_added: list[str] = Field(default_factory=list)
    models_removed: list[str] = Field(default_factory=list)
