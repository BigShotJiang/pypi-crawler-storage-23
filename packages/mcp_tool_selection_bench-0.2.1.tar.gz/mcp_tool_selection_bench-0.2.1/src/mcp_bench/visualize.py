"""Generate a standalone HTML report with confusion-matrix heatmaps."""

from __future__ import annotations

import html
import json
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import BenchmarkReport


def _heatmap_html(model_name: str, labels: list[str], matrix: dict[str, dict[str, int]]) -> str:
    """Render one confusion-matrix heatmap as an HTML table."""
    if not labels:
        return f"<h3>{html.escape(model_name)}</h3><p>No data.</p>"

    # Find max value for colour scaling
    max_val = max(
        (matrix.get(r, {}).get(c, 0) for r in labels for c in labels), default=1,
    ) or 1

    rows: list[str] = []
    # Header row
    header_cells = "".join(
        f'<th class="label">{html.escape(l)}</th>' for l in labels
    )
    rows.append(f'<tr><th></th>{header_cells}</tr>')

    for expected in labels:
        cells: list[str] = [f'<th class="label">{html.escape(expected)}</th>']
        for selected in labels:
            count = matrix.get(expected, {}).get(selected, 0)
            intensity = count / max_val
            if expected == selected:
                bg = f"rgba(34,139,34,{0.15 + 0.85 * intensity})"
            else:
                bg = f"rgba(220,20,60,{0.1 + 0.9 * intensity})" if count > 0 else "#f9f9f9"
            cells.append(
                f'<td style="background:{bg};text-align:center;">{count}</td>'
            )
        rows.append(f'<tr>{"".join(cells)}</tr>')

    table = "\n".join(rows)
    return f"""
    <h3>{html.escape(model_name)}</h3>
    <p class="axis-hint">Rows = expected tool &nbsp;|&nbsp; Columns = selected tool</p>
    <table>{table}</table>
    """


def render_html_report(report: "BenchmarkReport") -> str:
    """Render the full benchmark report as a standalone HTML page."""
    heatmaps = ""
    for model_name, cm in report.confusion_matrices.items():
        heatmaps += _heatmap_html(model_name, cm.labels, cm.matrix)

    # Summary table
    summary_rows = ""
    for r in report.summary.model_ranking:
        summary_rows += (
            f"<tr><td>{html.escape(r.model)}</td>"
            f"<td>{r.exact_match_accuracy:.2%}</td></tr>\n"
        )

    # Suggestions
    suggestions_html = ""
    if report.suggestions:
        suggestion_rows = ""
        for s in report.suggestions:
            suggestion_rows += (
                f"<tr><td>{html.escape(s.tool_name)}</td>"
                f"<td>{s.accuracy:.2%}</td>"
                f"<td>{html.escape(s.confused_with)}</td>"
                f"<td>{html.escape(s.current_description)}</td>"
                f"<td><strong>{html.escape(s.suggested_description)}</strong></td></tr>\n"
            )
        suggestions_html = f"""
        <h2>📝 Description Improvement Suggestions</h2>
        <table>
            <tr><th>Tool</th><th>Accuracy</th><th>Confused With</th>
                <th>Current Description</th><th>Suggested Description</th></tr>
            {suggestion_rows}
        </table>
        """

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>MCP Tool Selection Benchmark Report</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
         max-width: 1200px; margin: 2rem auto; padding: 0 1rem; color: #1a1a1a; }}
  h1 {{ border-bottom: 2px solid #333; padding-bottom: 0.5rem; }}
  h2 {{ margin-top: 2rem; }}
  table {{ border-collapse: collapse; margin: 1rem 0; }}
  th, td {{ border: 1px solid #ddd; padding: 6px 10px; font-size: 0.85rem; }}
  th {{ background: #f0f0f0; }}
  .label {{ font-weight: 600; white-space: nowrap; }}
  .axis-hint {{ color: #666; font-size: 0.8rem; margin: 0.25rem 0; }}
  .meta {{ color: #555; font-size: 0.9rem; }}
</style>
</head>
<body>
<h1>MCP Tool Selection Benchmark Report</h1>
<p class="meta">
  Models tested: {html.escape(', '.join(report.run_metadata.models_tested))} &nbsp;|&nbsp;
  Instructions: {report.run_metadata.num_instructions} &nbsp;|&nbsp;
  Variations: {report.run_metadata.variations_per_instruction} &nbsp;|&nbsp;
  Total queries: {report.run_metadata.total_queries}
</p>

<h2>🏆 Model Ranking</h2>
<table>
  <tr><th>Model</th><th>Accuracy</th></tr>
  {summary_rows}
</table>

<h2>🔀 Confusion Matrices</h2>
{heatmaps}

{suggestions_html}

</body>
</html>"""


def write_html_report(report: "BenchmarkReport", output_path: str | Path) -> None:
    """Write the HTML report to disk."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_html_report(report), encoding="utf-8")


# ---------------------------------------------------------------------------
# Diff HTML report
# ---------------------------------------------------------------------------

def render_diff_html(diff) -> str:
    """Render a DiffReport as a standalone HTML page."""
    from .diff import REGRESSION_THRESHOLD

    # Model summary rows
    model_rows = ""
    for md in diff.model_deltas:
        color = ""
        if md.delta_exact > REGRESSION_THRESHOLD:
            color = "style='background:#d4edda;'"
        elif md.delta_exact < -REGRESSION_THRESHOLD:
            color = "style='background:#f8d7da;'"
        model_rows += (
            f"<tr {color}>"
            f"<td>{html.escape(md.model)}</td>"
            f"<td>{md.baseline_exact:.2%}</td>"
            f"<td>{md.current_exact:.2%}</td>"
            f"<td>{md.delta_exact:+.2%}</td>"
            f"<td>{html.escape(md.status)}</td></tr>\n"
        )

    # Per-instruction detail rows (only changed)
    detail_rows = ""
    for md in diff.model_deltas:
        changed = [d for d in md.per_instruction if d.status != "unchanged"]
        for d in sorted(changed, key=lambda x: x.delta):
            color = ""
            if d.status == "improved":
                color = "style='background:#d4edda;'"
            elif d.status == "regressed":
                color = "style='background:#f8d7da;'"
            detail_rows += (
                f"<tr {color}>"
                f"<td>{html.escape(md.model)}</td>"
                f"<td>{html.escape(d.instruction[:80])}</td>"
                f"<td>{d.baseline_accuracy:.2%}</td>"
                f"<td>{d.current_accuracy:.2%}</td>"
                f"<td>{d.delta:+.2%}</td></tr>\n"
            )

    added_html = ""
    if diff.models_added:
        added_html = f"<p>Models added: <strong>{html.escape(', '.join(diff.models_added))}</strong></p>"
    removed_html = ""
    if diff.models_removed:
        removed_html = f"<p>Models removed: <strong>{html.escape(', '.join(diff.models_removed))}</strong></p>"

    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>Benchmark Diff Report</title>
<style>
  body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
         max-width: 1200px; margin: 2rem auto; padding: 0 1rem; color: #1a1a1a; }}
  h1 {{ border-bottom: 2px solid #333; padding-bottom: 0.5rem; }}
  table {{ border-collapse: collapse; margin: 1rem 0; width: 100%; }}
  th, td {{ border: 1px solid #ddd; padding: 6px 10px; font-size: 0.85rem; }}
  th {{ background: #f0f0f0; }}
  .meta {{ color: #555; font-size: 0.9rem; }}
</style>
</head>
<body>
<h1>Benchmark Diff Report</h1>
<p class="meta">
  Baseline: {html.escape(diff.baseline_timestamp)} &nbsp;→&nbsp;
  Current: {html.escape(diff.current_timestamp)}
</p>
{added_html}{removed_html}

<h2>📊 Model Comparison</h2>
<table>
  <tr><th>Model</th><th>Baseline</th><th>Current</th><th>Delta</th><th>Status</th></tr>
  {model_rows}
</table>

<h2>📋 Changed Instructions</h2>
<table>
  <tr><th>Model</th><th>Instruction</th><th>Baseline</th><th>Current</th><th>Delta</th></tr>
  {detail_rows}
</table>

</body>
</html>"""


def write_diff_html(diff, output_path: str | Path) -> None:
    """Write the diff HTML report to disk."""
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_diff_html(diff), encoding="utf-8")
