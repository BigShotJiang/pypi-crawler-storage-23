"""Generate query variations with varying ambiguity using the Copilot SDK."""

from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

from copilot import CopilotClient, PermissionHandler

from .models import AMBIGUITY_LEVELS, QueryVariation
from .prompts import VARIATION_PROMPT_TEMPLATE

if TYPE_CHECKING:
    from .models import TestCase, Tool

logger = logging.getLogger(__name__)


async def generate_variations(
    client: CopilotClient,
    test_case: "TestCase",
    tools: list["Tool"],
    num_variations: int = 5,
    model: str | None = None,
) -> list[QueryVariation]:
    """Return *num_variations* rephrased queries for *test_case*.

    Uses the Copilot SDK to ask a model to rephrase the instruction at
    different ambiguity levels.
    """
    levels = AMBIGUITY_LEVELS[:num_variations]
    level_desc = "\n".join(f"- {lvl}" for lvl in levels)
    tool_names = ", ".join(t.name for t in tools)

    prompt = VARIATION_PROMPT_TEMPLATE.format(
        num_variations=num_variations,
        levels=level_desc,
        instruction=test_case.instruction,
        tool_names=tool_names,
    )

    session_opts: dict = {
        "on_permission_request": PermissionHandler.approve_all,
    }
    if model:
        session_opts["model"] = model

    session = await client.create_session(session_opts)
    response = await session.send_and_wait({"prompt": prompt})

    raw_text = response.data.content if response and response.data else ""
    variations = _parse_variations(raw_text, levels)

    if len(variations) < num_variations:
        logger.warning(
            "Expected %d variations but parsed %d for instruction: %s",
            num_variations,
            len(variations),
            test_case.instruction,
        )
        # Pad with the original instruction for missing levels
        existing_levels = {v.ambiguity_level for v in variations}
        for lvl in levels:
            if lvl not in existing_levels:
                variations.append(
                    QueryVariation(
                        query=test_case.instruction,
                        ambiguity_level=lvl,
                    )
                )

    return variations[:num_variations]


def _parse_variations(raw_text: str, levels: list[str]) -> list[QueryVariation]:
    """Best-effort parse of model JSON response into QueryVariation list."""
    # Try to extract JSON array from the response
    text = raw_text.strip()

    # Find the first '[' and last ']'
    start = text.find("[")
    end = text.rfind("]")
    if start == -1 or end == -1:
        logger.error("Could not find JSON array in response: %s", text[:200])
        return []

    json_str = text[start : end + 1]
    try:
        items = json.loads(json_str)
    except json.JSONDecodeError as exc:
        logger.error("Failed to parse JSON: %s — raw: %s", exc, json_str[:200])
        return []

    variations: list[QueryVariation] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        query = item.get("query", "")
        level = item.get("ambiguity_level", "")
        if query and level in levels:
            variations.append(QueryVariation(query=query, ambiguity_level=level))

    return variations
