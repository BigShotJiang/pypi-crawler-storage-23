"""MCP Tool Selection Benchmark — measure LLM tool selection accuracy via GitHub Copilot SDK."""

__version__ = "0.1.0"
