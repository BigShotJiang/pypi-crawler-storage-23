"""Score tool-selection results against ground truth."""

from __future__ import annotations

from .models import (
    ConfusionMatrix,
    InstructionResult,
    ModelRanking,
    ModelResult,
    QueryVariation,
    Summary,
)


def _compute_partial_score(
    selected: list[str], expected: list[str],
) -> float:
    """Ordered prefix match: count sequential matches / max(len(expected), len(selected))."""
    if not expected:
        return 1.0 if not selected else 0.0
    if not selected:
        return 0.0
    matches = 0
    for sel, exp in zip(selected, expected):
        if sel.lower() == exp.lower():
            matches += 1
        else:
            break
    return matches / max(len(expected), len(selected))


def score_variations(
    variations: list[QueryVariation],
    expected_tools: list[str],
) -> list[QueryVariation]:
    """Set ``correct``, ``partial_score`` on each variation."""
    scored: list[QueryVariation] = []
    for v in variations:
        selected = v.selected_tools
        # Exact match: ordered full-sequence match
        is_correct = (
            len(selected) == len(expected_tools)
            and all(
                s.lower() == e.lower()
                for s, e in zip(selected, expected_tools)
            )
        )
        partial = _compute_partial_score(selected, expected_tools)
        scored.append(v.model_copy(update={
            "exact_match": is_correct,
            "partial_score": partial,
        }))
    return scored


def build_instruction_result(
    instruction: str,
    expected_tools: list[str],
    scored_variations: list[QueryVariation],
) -> InstructionResult:
    """Build an ``InstructionResult`` from scored variations."""
    total = len(scored_variations)
    exact_correct = sum(1 for v in scored_variations if v.exact_match)
    exact_acc = exact_correct / total if total else 0.0
    partial_acc = (
        sum(v.partial_score or 0.0 for v in scored_variations) / total
        if total else 0.0
    )

    return InstructionResult(
        instruction=instruction,
        expected_tools=expected_tools,
        variations=scored_variations,
        exact_match_accuracy=exact_acc,
        partial_credit_accuracy=partial_acc,
    )


def build_model_result(
    instruction_results: list[InstructionResult],
) -> ModelResult:
    """Aggregate instruction-level results into a single ``ModelResult``."""
    total = 0
    correct = 0
    partial_sum = 0.0
    for ir in instruction_results:
        for v in ir.variations:
            total += 1
            if v.exact_match:
                correct += 1
            partial_sum += v.partial_score or 0.0

    accuracy = correct / total if total else 0.0
    partial_acc = partial_sum / total if total else 0.0
    return ModelResult(
        exact_match_accuracy=accuracy,
        partial_credit_accuracy=partial_acc,
        exact_match_count=correct,
        total=total,
        per_instruction=instruction_results,
    )


def build_summary(per_model: dict[str, ModelResult]) -> Summary:
    """Rank models and pick the best one."""
    ranking = sorted(
        [ModelRanking(model=m, exact_match_accuracy=r.exact_match_accuracy) for m, r in per_model.items()],
        key=lambda x: x.exact_match_accuracy,
        reverse=True,
    )
    best = ranking[0] if ranking else ModelRanking(model="", exact_match_accuracy=0.0)

    # Find best by each metric
    best_exact = max(
        (r.exact_match_accuracy for r in per_model.values()), default=0.0,
    )
    best_partial = max(
        (r.partial_credit_accuracy for r in per_model.values()), default=0.0,
    )

    return Summary(
        best_model=best.model,
        best_exact_accuracy=best_exact,
        best_partial_accuracy=best_partial,
        model_ranking=ranking,
    )


def build_confusion_matrix(model_result: ModelResult) -> ConfusionMatrix:
    """Build a confusion matrix from a single model's results.

    For multi-tool cases, each position in the expected/selected sequence
    contributes a separate entry. E.g., expected=[A, B] selected=[A, C]
    adds A→A and B→C.
    """
    label_set: set[str] = set()
    for ir in model_result.per_instruction:
        label_set.update(ir.expected_tools)
        for v in ir.variations:
            label_set.update(t for t in v.selected_tools if t)

    labels = sorted(label_set)
    matrix: dict[str, dict[str, int]] = {l: {l2: 0 for l2 in labels} for l in labels}

    def _ensure_label(name: str) -> None:
        if name not in matrix:
            labels.append(name)
            for row in matrix:
                matrix[row][name] = 0
            matrix[name] = {l: 0 for l in labels}

    for ir in model_result.per_instruction:
        expected_list = ir.expected_tools
        for v in ir.variations:
            selected_list = v.selected_tools
            # Compare position-by-position
            for i, exp in enumerate(expected_list):
                sel = selected_list[i] if i < len(selected_list) else "(none)"
                _ensure_label(sel)
                matrix[exp][sel] = matrix[exp].get(sel, 0) + 1

    return ConfusionMatrix(labels=labels, matrix=matrix)
