"""Tests for the report writer."""

import json
import tempfile
from pathlib import Path

from mcp_bench.models import (
    BenchmarkReport,
    ModelRanking,
    ModelResult,
    RunMetadata,
    Summary,
)
from mcp_bench.report import write_report


def _make_report() -> BenchmarkReport:
    return BenchmarkReport(
        run_metadata=RunMetadata(
            timestamp="2026-01-01T00:00:00Z",
            models_tested=["gpt-5"],
            num_instructions=1,
            variations_per_instruction=5,
            total_queries=5,
        ),
        per_model_results={
            "gpt-5": ModelResult(exact_match_accuracy=0.8, exact_match_count=4, total=5),
        },
        summary=Summary(
            best_model="gpt-5",
            best_exact_accuracy=0.8,
            model_ranking=[ModelRanking(model="gpt-5", exact_match_accuracy=0.8)],
        ),
    )


def test_write_report_creates_file():
    report = _make_report()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "out.json"
        write_report(report, out)
        assert out.exists()
        data = json.loads(out.read_text(encoding="utf-8"))
        assert data["summary"]["best_model"] == "gpt-5"


def test_write_report_creates_parent_dirs():
    report = _make_report()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "sub" / "dir" / "report.json"
        write_report(report, out)
        assert out.exists()


def test_write_report_valid_json():
    report = _make_report()
    with tempfile.TemporaryDirectory() as tmp:
        out = Path(tmp) / "r.json"
        write_report(report, out)
        data = json.loads(out.read_text(encoding="utf-8"))
        assert data["run_metadata"]["total_queries"] == 5
        assert data["per_model_results"]["gpt-5"]["exact_match_accuracy"] == 0.8
