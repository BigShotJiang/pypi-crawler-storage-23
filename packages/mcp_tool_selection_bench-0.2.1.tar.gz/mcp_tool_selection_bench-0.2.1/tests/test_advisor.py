"""Tests for the advisor module (identification logic only, no LLM calls)."""

from mcp_bench.advisor import identify_weak_tools, _top_confusion
from mcp_bench.models import (
    BenchmarkReport,
    ConfusionMatrix,
    InstructionResult,
    ModelResult,
    QueryVariation,
    RunMetadata,
    Summary,
    Tool,
)


def _make_report(accuracy: float, confused_with: str) -> BenchmarkReport:
    """Helper: one model, one instruction, one confusion pair."""
    cm = ConfusionMatrix(
        labels=["search_issues", confused_with],
        matrix={
            "search_issues": {"search_issues": 1, confused_with: 3},
            confused_with: {confused_with: 2, "search_issues": 0},
        },
    )
    return BenchmarkReport(
        run_metadata=RunMetadata(
            timestamp="t", models_tested=["gpt-5"],
            num_instructions=1, variations_per_instruction=4, total_queries=4,
        ),
        per_model_results={
            "gpt-5": ModelResult(
                exact_match_accuracy=accuracy, exact_match_count=1, total=4,
                per_instruction=[
                    InstructionResult(
                        instruction="test",
                        expected_tools=["search_issues"],
                        exact_match_accuracy=accuracy,
                        variations=[],
                    ),
                ],
            ),
        },
        summary=Summary(best_model="gpt-5", best_exact_accuracy=accuracy),
        confusion_matrices={"gpt-5": cm},
    )


TOOLS = [
    Tool(name="search_issues", description="Search for issues"),
    Tool(name="search_code", description="Search for code"),
]


class TestIdentifyWeakTools:
    def test_below_threshold(self):
        report = _make_report(0.25, "search_code")
        weak = identify_weak_tools(report, TOOLS, threshold=0.7)
        assert len(weak) == 1
        assert weak[0]["tool_name"] == "search_issues"
        assert weak[0]["confused_with"] == "search_code"

    def test_above_threshold(self):
        report = _make_report(0.9, "search_code")
        weak = identify_weak_tools(report, TOOLS, threshold=0.7)
        assert len(weak) == 0

    def test_at_threshold(self):
        report = _make_report(0.7, "search_code")
        weak = identify_weak_tools(report, TOOLS, threshold=0.7)
        assert len(weak) == 0

    def test_multi_tool_expected(self):
        """Multi-tool: both expected tools should be checked for confusion."""
        tools = [
            Tool(name="search_issues", description="Search for issues"),
            Tool(name="get_job_logs", description="Get CI logs"),
            Tool(name="search_code", description="Search for code"),
        ]
        cm = ConfusionMatrix(
            labels=["search_issues", "get_job_logs", "search_code"],
            matrix={
                "search_issues": {"search_issues": 3, "get_job_logs": 0, "search_code": 1},
                "get_job_logs": {"search_issues": 0, "get_job_logs": 0, "search_code": 4},
                "search_code": {"search_issues": 0, "get_job_logs": 0, "search_code": 2},
            },
        )
        report = BenchmarkReport(
            run_metadata=RunMetadata(
                timestamp="t", models_tested=["gpt-5"],
                num_instructions=1, variations_per_instruction=4, total_queries=4,
            ),
            per_model_results={
                "gpt-5": ModelResult(
                    exact_match_accuracy=0.0, exact_match_count=0, total=4,
                    per_instruction=[
                        InstructionResult(
                            instruction="test",
                            expected_tools=["search_issues", "get_job_logs"],
                            exact_match_accuracy=0.0,
                            variations=[],
                        ),
                    ],
                ),
            },
            summary=Summary(best_model="gpt-5", best_exact_accuracy=0.0),
            confusion_matrices={"gpt-5": cm},
        )
        weak = identify_weak_tools(report, tools, threshold=0.7)
        tool_names = {w["tool_name"] for w in weak}
        assert "search_issues" in tool_names
        assert "get_job_logs" in tool_names


class TestTopConfusion:
    def test_finds_top(self):
        cm = ConfusionMatrix(
            labels=["a", "b", "c"],
            matrix={
                "a": {"a": 5, "b": 3, "c": 1},
                "b": {"a": 0, "b": 4, "c": 0},
                "c": {"a": 0, "b": 0, "c": 3},
            },
        )
        assert _top_confusion(cm, "a") == "b"

    def test_no_confusion(self):
        cm = ConfusionMatrix(
            labels=["a"],
            matrix={"a": {"a": 5}},
        )
        assert _top_confusion(cm, "a") is None

    def test_missing_tool(self):
        cm = ConfusionMatrix(labels=["a"], matrix={"a": {"a": 1}})
        assert _top_confusion(cm, "missing") is None

    def test_none_cm(self):
        assert _top_confusion(None, "a") is None
