"""Tests for Pydantic data models."""

from mcp_bench.models import (
    AMBIGUITY_LEVELS,
    BenchmarkReport,
    InstructionResult,
    ModelRanking,
    ModelResult,
    QueryVariation,
    RunMetadata,
    Summary,
    TestCase,
    Tool,
)


def test_tool_minimal():
    t = Tool(name="foo", description="bar")
    assert t.name == "foo"
    assert t.parameters == {}
    assert t.metadata == {}


def test_tool_full():
    t = Tool(
        name="search",
        description="Search things",
        parameters={"type": "object", "properties": {}},
        metadata={"category": "util"},
    )
    assert t.metadata["category"] == "util"


def test_test_case():
    tc = TestCase(instruction="do something", expected_tool="some_tool")
    assert tc.instruction == "do something"
    assert tc.expected_tools == ["some_tool"]


def test_test_case_multi_tool():
    tc = TestCase(instruction="do two things", expected_tools=["tool_a", "tool_b"])
    assert tc.expected_tools == ["tool_a", "tool_b"]


def test_test_case_backward_compat():
    tc = TestCase(instruction="x", expected_tool="foo")
    assert tc.expected_tools == ["foo"]


def test_test_case_both_fields_conflict():
    """When both fields provided, expected_tool populates expected_tools only if expected_tools is empty."""
    tc = TestCase(
        instruction="x",
        expected_tool="wrong",
        expected_tools=["tool_b", "tool_c"],
    )
    assert tc.expected_tools == ["tool_b", "tool_c"]


def test_query_variation_defaults():
    qv = QueryVariation(query="hello", ambiguity_level="explicit")
    assert qv.selected_tools == []
    assert qv.exact_match is None
    assert qv.partial_score is None


def test_instruction_result():
    ir = InstructionResult(
        instruction="test",
        expected_tools=["foo"],
        variations=[
            QueryVariation(query="q1", ambiguity_level="explicit", exact_match=True),
            QueryVariation(query="q2", ambiguity_level="vague", exact_match=False),
        ],
        exact_match_accuracy=0.5,
    )
    assert len(ir.variations) == 2
    assert ir.exact_match_accuracy == 0.5


def test_model_result():
    mr = ModelResult(exact_match_accuracy=0.8, exact_match_count=4, total=5, per_instruction=[])
    assert mr.exact_match_accuracy == 0.8


def test_benchmark_report_roundtrip():
    report = BenchmarkReport(
        run_metadata=RunMetadata(
            timestamp="2026-01-01T00:00:00Z",
            models_tested=["gpt-5"],
            num_instructions=1,
            variations_per_instruction=5,
            total_queries=5,
        ),
        per_model_results={
            "gpt-5": ModelResult(exact_match_accuracy=1.0, exact_match_count=5, total=5),
        },
        summary=Summary(
            best_model="gpt-5",
            best_exact_accuracy=1.0,
            model_ranking=[ModelRanking(model="gpt-5", exact_match_accuracy=1.0)],
        ),
    )
    data = report.model_dump()
    restored = BenchmarkReport(**data)
    assert restored.summary.best_model == "gpt-5"


def test_ambiguity_levels_count():
    assert len(AMBIGUITY_LEVELS) == 5
