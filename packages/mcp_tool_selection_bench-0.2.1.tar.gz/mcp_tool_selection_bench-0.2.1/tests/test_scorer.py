"""Tests for the scorer module."""

from mcp_bench.models import InstructionResult, ModelResult, QueryVariation
from mcp_bench.scorer import (
    _compute_partial_score,
    build_confusion_matrix,
    build_instruction_result,
    build_model_result,
    build_summary,
    score_variations,
)


def _make_variation(
    selected: str | None,
    level: str = "explicit",
    selected_tools: list[str] | None = None,
) -> QueryVariation:
    return QueryVariation(
        query="q",
        ambiguity_level=level,
        selected_tools=selected_tools or ([selected] if selected else []),
    )


# ---------------------------------------------------------------------------
# Single-tool scoring (backward compat)
# ---------------------------------------------------------------------------

class TestScoreVariations:
    def test_exact_match(self):
        variations = [_make_variation("search_issues")]
        scored = score_variations(variations, ["search_issues"])
        assert scored[0].exact_match is True

    def test_case_insensitive(self):
        scored = score_variations(
            [_make_variation("Search_Issues")], ["search_issues"]
        )
        assert scored[0].exact_match is True

    def test_mismatch(self):
        scored = score_variations(
            [_make_variation("list_commits")], ["search_issues"]
        )
        assert scored[0].exact_match is False

    def test_none_selected(self):
        scored = score_variations([_make_variation(None)], ["search_issues"])
        assert scored[0].exact_match is False

    def test_multiple(self):
        variations = [
            _make_variation("search_issues", "explicit"),
            _make_variation("list_commits", "vague"),
            _make_variation("search_issues", "indirect"),
        ]
        scored = score_variations(variations, ["search_issues"])
        assert [v.exact_match for v in scored] == [True, False, True]


# ---------------------------------------------------------------------------
# Multi-tool scoring
# ---------------------------------------------------------------------------

class TestMultiToolScoring:
    def test_exact_match_multi(self):
        v = _make_variation(
            "search_issues",
            selected_tools=["search_issues", "get_job_logs"],
        )
        scored = score_variations([v], ["search_issues", "get_job_logs"])
        assert scored[0].exact_match is True
        assert scored[0].partial_score == 1.0

    def test_partial_credit(self):
        v = _make_variation(
            "search_issues",
            selected_tools=["search_issues"],
        )
        scored = score_variations([v], ["search_issues", "get_job_logs"])
        assert scored[0].exact_match is False
        assert scored[0].partial_score == 0.5

    def test_wrong_order(self):
        v = _make_variation(
            "get_job_logs",
            selected_tools=["get_job_logs", "search_issues"],
        )
        scored = score_variations([v], ["search_issues", "get_job_logs"])
        assert scored[0].exact_match is False
        assert scored[0].partial_score == 0.0

    def test_partial_prefix_match(self):
        v = _make_variation(
            "search_issues",
            selected_tools=["search_issues", "wrong_tool"],
        )
        scored = score_variations([v], ["search_issues", "get_job_logs"])
        assert scored[0].exact_match is False
        assert scored[0].partial_score == 0.5

    def test_three_tools(self):
        v = _make_variation(
            "a",
            selected_tools=["a", "b", "wrong"],
        )
        scored = score_variations([v], ["a", "b", "c"])
        assert scored[0].exact_match is False
        assert abs(scored[0].partial_score - 2 / 3) < 1e-9


class TestComputePartialScore:
    def test_empty_expected(self):
        assert _compute_partial_score([], []) == 1.0

    def test_empty_expected_with_selected(self):
        assert _compute_partial_score(["a"], []) == 0.0

    def test_full_match(self):
        assert _compute_partial_score(["a", "b"], ["a", "b"]) == 1.0

    def test_prefix_break(self):
        assert _compute_partial_score(["a", "x", "c"], ["a", "b", "c"]) == 1 / 3

    def test_extra_selections_penalized(self):
        """Bug fix: selecting more tools than expected should not get 1.0."""
        score = _compute_partial_score(["a", "b", "c"], ["a", "b"])
        assert score == 2 / 3  # 2 matches / max(3, 2)

    def test_fewer_selections(self):
        score = _compute_partial_score(["a"], ["a", "b"])
        assert score == 1 / 2  # 1 match / max(1, 2)


# ---------------------------------------------------------------------------
# build_instruction_result / build_model_result / build_summary
# ---------------------------------------------------------------------------

class TestBuildInstructionResult:
    def test_accuracy(self):
        scored = [
            QueryVariation(
                query="q1", ambiguity_level="explicit",
                selected_tools=["a"],
                exact_match=True, partial_score=1.0,
            ),
            QueryVariation(
                query="q2", ambiguity_level="vague",
                selected_tools=["b"],
                exact_match=False, partial_score=0.0,
            ),
        ]
        ir = build_instruction_result("inst", ["a"], scored)
        assert ir.exact_match_accuracy == 0.5
        assert ir.exact_match_accuracy == 0.5
        assert ir.partial_credit_accuracy == 0.5

    def test_empty(self):
        ir = build_instruction_result("inst", ["a"], [])
        assert ir.exact_match_accuracy == 0.0


class TestBuildModelResult:
    def test_aggregate(self):
        ir1 = InstructionResult(
            instruction="i1",
            expected_tools=["a"],
            variations=[
                QueryVariation(
                    query="q", ambiguity_level="explicit",
                    exact_match=True, partial_score=1.0,
                ),
                QueryVariation(
                    query="q", ambiguity_level="vague",
                    exact_match=False, partial_score=0.0,
                ),
            ],
            exact_match_accuracy=0.5,
        )
        ir2 = InstructionResult(
            instruction="i2",
            expected_tools=["b"],
            variations=[
                QueryVariation(
                    query="q", ambiguity_level="explicit",
                    exact_match=True, partial_score=1.0,
                ),
            ],
            exact_match_accuracy=1.0,
        )
        mr = build_model_result([ir1, ir2])
        assert mr.exact_match_count == 2
        assert mr.total == 3
        assert abs(mr.exact_match_accuracy - 2 / 3) < 1e-9
        assert abs(mr.partial_credit_accuracy - 2 / 3) < 1e-9


class TestBuildSummary:
    def test_ranking(self):
        per_model = {
            "model_a": ModelResult(exact_match_accuracy=0.6,
                                   partial_credit_accuracy=0.7, exact_match_count=3, total=5),
            "model_b": ModelResult(exact_match_accuracy=0.9,
                                   partial_credit_accuracy=0.95, exact_match_count=9, total=10),
        }
        summary = build_summary(per_model)
        assert summary.best_model == "model_b"
        assert summary.best_exact_accuracy == 0.9
        assert summary.best_partial_accuracy == 0.95
        assert summary.model_ranking[0].model == "model_b"

    def test_empty(self):
        summary = build_summary({})
        assert summary.best_model == ""


# ---------------------------------------------------------------------------
# Confusion matrix
# ---------------------------------------------------------------------------

class TestBuildConfusionMatrix:
    def test_basic(self):
        mr = ModelResult(
            exact_match_accuracy=0.5, exact_match_count=1, total=2,
            per_instruction=[
                InstructionResult(
                    instruction="i1",
                    expected_tools=["search_issues"],
                    variations=[
                        QueryVariation(
                            query="q1", ambiguity_level="explicit",
                            selected_tools=["search_issues"],
                            exact_match=True, partial_score=1.0,
                        ),
                        QueryVariation(
                            query="q2", ambiguity_level="vague",
                            selected_tools=["search_code"],
                            exact_match=False, partial_score=0.0,
                        ),
                    ],
                ),
            ],
        )
        cm = build_confusion_matrix(mr)
        assert "search_issues" in cm.labels
        assert "search_code" in cm.labels
        assert cm.matrix["search_issues"]["search_issues"] == 1
        assert cm.matrix["search_issues"]["search_code"] == 1

    def test_empty(self):
        mr = ModelResult(exact_match_accuracy=0.0, exact_match_count=0, total=0, per_instruction=[])
        cm = build_confusion_matrix(mr)
        assert cm.labels == []
        assert cm.matrix == {}

    def test_none_selected(self):
        mr = ModelResult(
            exact_match_accuracy=0.0, exact_match_count=0, total=1,
            per_instruction=[
                InstructionResult(
                    instruction="i1",
                    expected_tools=["search_issues"],
                    variations=[
                        QueryVariation(
                            query="q1", ambiguity_level="explicit",
                            selected_tools=[],
                            exact_match=False, partial_score=0.0,
                        ),
                    ],
                ),
            ],
        )
        cm = build_confusion_matrix(mr)
        assert cm.matrix["search_issues"]["(none)"] == 1

    def test_multi_tool(self):
        """Multi-tool: expected=[A, B], selected=[A, C] → A→A and B→C."""
        mr = ModelResult(
            exact_match_accuracy=0.0, exact_match_count=0, total=1,
            per_instruction=[
                InstructionResult(
                    instruction="i1",
                    expected_tools=["search_issues", "get_job_logs"],
                    variations=[
                        QueryVariation(
                            query="q1", ambiguity_level="explicit",
                            selected_tools=["search_issues", "search_code"],
                            exact_match=False, partial_score=0.5,
                        ),
                    ],
                ),
            ],
        )
        cm = build_confusion_matrix(mr)
        assert cm.matrix["search_issues"]["search_issues"] == 1
        assert cm.matrix["get_job_logs"]["search_code"] == 1

    def test_multi_tool_short_selection(self):
        """Model selected fewer tools than expected → missing positions are (none)."""
        mr = ModelResult(
            exact_match_accuracy=0.0, exact_match_count=0, total=1,
            per_instruction=[
                InstructionResult(
                    instruction="i1",
                    expected_tools=["search_issues", "get_job_logs"],
                    variations=[
                        QueryVariation(
                            query="q1", ambiguity_level="explicit",
                            selected_tools=["search_issues"],
                            exact_match=False, partial_score=0.5,
                        ),
                    ],
                ),
            ],
        )
        cm = build_confusion_matrix(mr)
        assert cm.matrix["search_issues"]["search_issues"] == 1
        assert cm.matrix["get_job_logs"]["(none)"] == 1
