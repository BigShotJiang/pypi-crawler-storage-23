"""Tests for the test-suite generator module."""

from mcp_bench.generator import build_prompt, build_tools_block, parse_test_cases
from mcp_bench.models import Tool


SAMPLE_TOOLS = [
    Tool(
        name="search_issues",
        description="Search for issues in GitHub repositories",
        parameters={
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search query"},
            },
            "required": ["query"],
        },
    ),
    Tool(
        name="list_pull_requests",
        description="List pull requests in a GitHub repository",
        parameters={
            "type": "object",
            "properties": {
                "owner": {"type": "string"},
                "repo": {"type": "string"},
            },
            "required": ["owner", "repo"],
        },
    ),
]

TOOL_NAMES = {t.name for t in SAMPLE_TOOLS}


class TestBuildToolsBlock:
    def test_contains_tool_names(self):
        block = build_tools_block(SAMPLE_TOOLS)
        assert "search_issues" in block
        assert "list_pull_requests" in block

    def test_contains_descriptions(self):
        block = build_tools_block(SAMPLE_TOOLS)
        assert "Search for issues" in block
        assert "List pull requests" in block

    def test_contains_parameters(self):
        block = build_tools_block(SAMPLE_TOOLS)
        assert "`query`" in block
        assert "`owner`" in block


class TestBuildPrompt:
    def test_contains_per_tool_count(self):
        prompt = build_prompt(SAMPLE_TOOLS, per_tool=3)
        assert "3 test cases" in prompt

    def test_contains_total(self):
        prompt = build_prompt(SAMPLE_TOOLS, per_tool=4)
        assert "8 single-tool" in prompt

    def test_contains_tool_info(self):
        prompt = build_prompt(SAMPLE_TOOLS)
        assert "search_issues" in prompt


class TestParseTestCases:
    def test_valid_json(self):
        raw = """[
            {"instruction": "Find open bugs", "expected_tools": ["search_issues"]},
            {"instruction": "Show PRs", "expected_tools": ["list_pull_requests"]}
        ]"""
        cases = parse_test_cases(raw, TOOL_NAMES)
        assert len(cases) == 2
        assert cases[0].instruction == "Find open bugs"
        assert cases[0].expected_tools == ["search_issues"]

    def test_multi_tool(self):
        raw = """[
            {"instruction": "Find bugs and list PRs",
             "expected_tools": ["search_issues", "list_pull_requests"]}
        ]"""
        cases = parse_test_cases(raw, TOOL_NAMES)
        assert len(cases) == 1
        assert len(cases[0].expected_tools) == 2

    def test_accepts_expected_tool_string(self):
        raw = """[
            {"instruction": "Find bugs", "expected_tool": "search_issues"}
        ]"""
        cases = parse_test_cases(raw, TOOL_NAMES)
        assert len(cases) == 1
        assert cases[0].expected_tools == ["search_issues"]

    def test_filters_unknown_tools(self):
        raw = """[
            {"instruction": "Do magic", "expected_tools": ["nonexistent_tool"]}
        ]"""
        cases = parse_test_cases(raw, TOOL_NAMES)
        assert len(cases) == 0

    def test_skips_empty_instruction(self):
        raw = """[
            {"instruction": "", "expected_tools": ["search_issues"]}
        ]"""
        cases = parse_test_cases(raw, TOOL_NAMES)
        assert len(cases) == 0

    def test_skips_no_tools(self):
        raw = """[
            {"instruction": "Find bugs", "expected_tools": []}
        ]"""
        cases = parse_test_cases(raw, TOOL_NAMES)
        assert len(cases) == 0

    def test_handles_markdown_fences(self):
        raw = """```json
        [{"instruction": "Find bugs", "expected_tools": ["search_issues"]}]
        ```"""
        cases = parse_test_cases(raw, TOOL_NAMES)
        assert len(cases) == 1

    def test_invalid_json(self):
        cases = parse_test_cases("not json at all", TOOL_NAMES)
        assert len(cases) == 0

    def test_no_array(self):
        cases = parse_test_cases('{"key": "value"}', TOOL_NAMES)
        assert len(cases) == 0


class TestParseCliArgs:
    def test_generate_subcommand(self):
        from mcp_bench.cli import _parse_args

        args = _parse_args(["generate", "--tools", "t.json"])
        assert args.command == "generate"
        assert args.tools == "t.json"
        assert args.output == "test_suite.json"
        assert args.per_tool == 4

    def test_generate_custom_args(self):
        from mcp_bench.cli import _parse_args

        args = _parse_args([
            "generate", "--tools", "t.json",
            "--output", "my_suite.json",
            "--per-tool", "6",
            "--model", "gpt-5",
        ])
        assert args.output == "my_suite.json"
        assert args.per_tool == 6
        assert args.model == "gpt-5"
