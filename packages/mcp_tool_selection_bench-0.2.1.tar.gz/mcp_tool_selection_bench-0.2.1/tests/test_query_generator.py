"""Tests for query_generator parsing logic (no SDK calls needed)."""

from mcp_bench.query_generator import _parse_variations


class TestParseVariations:
    LEVELS = ["explicit", "moderate", "vague", "indirect", "misleading"]

    def test_valid_json(self):
        raw = """
        [
            {"query": "Find open bugs", "ambiguity_level": "explicit"},
            {"query": "Any bug issues?", "ambiguity_level": "moderate"},
            {"query": "bugs?", "ambiguity_level": "vague"},
            {"query": "problems in the repo", "ambiguity_level": "indirect"},
            {"query": "show me features", "ambiguity_level": "misleading"}
        ]
        """
        result = _parse_variations(raw, self.LEVELS)
        assert len(result) == 5
        assert result[0].ambiguity_level == "explicit"

    def test_json_with_surrounding_text(self):
        raw = """Here are the variations:
        [{"query": "hello", "ambiguity_level": "explicit"}]
        Hope that helps!"""
        result = _parse_variations(raw, self.LEVELS)
        assert len(result) == 1
        assert result[0].query == "hello"

    def test_no_json_array(self):
        result = _parse_variations("no json here", self.LEVELS)
        assert result == []

    def test_invalid_json(self):
        result = _parse_variations("[{bad json}]", self.LEVELS)
        assert result == []

    def test_filters_unknown_levels(self):
        raw = '[{"query": "q", "ambiguity_level": "unknown_level"}]'
        result = _parse_variations(raw, self.LEVELS)
        assert result == []

    def test_skips_non_dict_items(self):
        raw = '["not a dict", {"query": "q", "ambiguity_level": "explicit"}]'
        result = _parse_variations(raw, self.LEVELS)
        assert len(result) == 1
