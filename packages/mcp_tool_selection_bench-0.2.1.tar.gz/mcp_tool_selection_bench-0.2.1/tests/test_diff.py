"""Tests for the diff module."""

from mcp_bench.diff import diff_reports, format_diff_table, _status
from mcp_bench.models import (
    BenchmarkReport,
    InstructionResult,
    ModelResult,
    QueryVariation,
    RunMetadata,
    Summary,
)


def _make_report(
    timestamp: str,
    model_accuracy: dict[str, float],
    instruction_accuracies: dict[str, dict[str, float]] | None = None,
) -> BenchmarkReport:
    """Helper: create a minimal report with given model accuracies."""
    per_model = {}
    for model, acc in model_accuracy.items():
        instr_results = []
        if instruction_accuracies and model in instruction_accuracies:
            for instr, iacc in instruction_accuracies[model].items():
                instr_results.append(InstructionResult(
                    instruction=instr,
                    expected_tools=["tool"],
                    exact_match_accuracy=iacc,
                    variations=[],
                ))
        per_model[model] = ModelResult(
            exact_match_accuracy=acc,
            partial_credit_accuracy=acc,
            exact_match_count=int(acc * 10),
            total=10,
            per_instruction=instr_results,
        )
    return BenchmarkReport(
        run_metadata=RunMetadata(
            timestamp=timestamp,
            models_tested=list(model_accuracy),
            num_instructions=1,
            variations_per_instruction=5,
            total_queries=5,
        ),
        per_model_results=per_model,
        summary=Summary(best_model=max(model_accuracy, key=model_accuracy.get)),
    )


class TestDiffReports:
    def test_same_results(self):
        r = _make_report("t1", {"gpt-5": 0.8})
        diff = diff_reports(r, r)
        assert len(diff.model_deltas) == 1
        assert diff.model_deltas[0].delta_exact == 0.0
        assert diff.model_deltas[0].status == "unchanged"

    def test_improvement(self):
        baseline = _make_report("t1", {"gpt-5": 0.6})
        current = _make_report("t2", {"gpt-5": 0.9})
        diff = diff_reports(baseline, current)
        md = diff.model_deltas[0]
        assert abs(md.delta_exact - 0.3) < 1e-9
        assert md.status == "improved"

    def test_regression(self):
        baseline = _make_report("t1", {"gpt-5": 0.9})
        current = _make_report("t2", {"gpt-5": 0.5})
        diff = diff_reports(baseline, current)
        md = diff.model_deltas[0]
        assert md.delta_exact == -0.4
        assert md.status == "regressed"

    def test_model_added(self):
        baseline = _make_report("t1", {"gpt-5": 0.8})
        current = _make_report("t2", {"gpt-5": 0.8, "claude": 0.7})
        diff = diff_reports(baseline, current)
        assert "claude" in diff.models_added
        assert len(diff.model_deltas) == 1  # only common models

    def test_model_removed(self):
        baseline = _make_report("t1", {"gpt-5": 0.8, "claude": 0.7})
        current = _make_report("t2", {"gpt-5": 0.8})
        diff = diff_reports(baseline, current)
        assert "claude" in diff.models_removed

    def test_instruction_deltas(self):
        baseline = _make_report(
            "t1", {"gpt-5": 0.5},
            {"gpt-5": {"Find bugs": 0.8, "List PRs": 0.2}},
        )
        current = _make_report(
            "t2", {"gpt-5": 0.7},
            {"gpt-5": {"Find bugs": 0.4, "List PRs": 0.9}},
        )
        diff = diff_reports(baseline, current)
        md = diff.model_deltas[0]
        by_instr = {d.instruction: d for d in md.per_instruction}
        assert by_instr["Find bugs"].status == "regressed"
        assert by_instr["Find bugs"].delta == -0.4
        assert by_instr["List PRs"].status == "improved"
        assert by_instr["List PRs"].delta == 0.7


class TestStatus:
    def test_improved(self):
        assert _status(0.1) == "improved"

    def test_regressed(self):
        assert _status(-0.1) == "regressed"

    def test_unchanged(self):
        assert _status(0.03) == "unchanged"
        assert _status(-0.03) == "unchanged"
        assert _status(0.0) == "unchanged"


class TestFormatDiffTable:
    def test_produces_output(self):
        baseline = _make_report("2026-01-01", {"gpt-5": 0.8})
        current = _make_report("2026-02-01", {"gpt-5": 0.9})
        diff = diff_reports(baseline, current)
        table = format_diff_table(diff)
        assert "gpt-5" in table
        assert "2026-01-01" in table
        assert "2026-02-01" in table


# ---------------------------------------------------------------------------
# CLI --fail-under tests
# ---------------------------------------------------------------------------

import json
import tempfile
from pathlib import Path

from mcp_bench.cli import _parse_args, _diff


def _write_report(path: Path, report: BenchmarkReport) -> None:
    path.write_text(report.model_dump_json(indent=2), encoding="utf-8")


class TestFailUnderRun:
    def test_parse_fail_under_run(self):
        args = _parse_args([
            "run", "--tools", "t.json", "--test-suite", "ts.json",
            "--models", "m1", "--fail-under", "0.8",
        ])
        assert args.fail_under == 0.8

    def test_parse_no_fail_under(self):
        args = _parse_args([
            "run", "--tools", "t.json", "--test-suite", "ts.json",
            "--models", "m1",
        ])
        assert args.fail_under is None


class TestFailUnderDiff:
    def test_diff_passes_above_threshold(self):
        """No regression → exit code 0."""
        baseline = _make_report("t1", {"gpt-5": 0.8})
        current = _make_report("t2", {"gpt-5": 0.85})
        with tempfile.TemporaryDirectory() as tmp:
            b_path = Path(tmp) / "baseline.json"
            c_path = Path(tmp) / "current.json"
            _write_report(b_path, baseline)
            _write_report(c_path, current)
            args = _parse_args(["diff", str(b_path), str(c_path), "--fail-under", "0.1"])
            # Should not raise / exit
            _diff(args)

    def test_diff_fails_on_regression(self):
        """Large regression → exit code 1."""
        baseline = _make_report("t1", {"gpt-5": 0.9})
        current = _make_report("t2", {"gpt-5": 0.5})
        with tempfile.TemporaryDirectory() as tmp:
            b_path = Path(tmp) / "baseline.json"
            c_path = Path(tmp) / "current.json"
            _write_report(b_path, baseline)
            _write_report(c_path, current)
            args = _parse_args(["diff", str(b_path), str(c_path), "--fail-under", "0.05"])
            import pytest
            with pytest.raises(SystemExit) as exc_info:
                _diff(args)
            assert exc_info.value.code == 1

    def test_diff_no_fail_under(self):
        """Without --fail-under, regression does not exit."""
        baseline = _make_report("t1", {"gpt-5": 0.9})
        current = _make_report("t2", {"gpt-5": 0.5})
        with tempfile.TemporaryDirectory() as tmp:
            b_path = Path(tmp) / "baseline.json"
            c_path = Path(tmp) / "current.json"
            _write_report(b_path, baseline)
            _write_report(c_path, current)
            args = _parse_args(["diff", str(b_path), str(c_path)])
            _diff(args)  # Should not raise
