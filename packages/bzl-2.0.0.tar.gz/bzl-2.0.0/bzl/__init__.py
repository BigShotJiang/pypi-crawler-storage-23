"""bzl — Terminal UI for browsing and executing Bazel genrule targets."""
