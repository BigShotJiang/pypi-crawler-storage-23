Getting started
---------------

.. include:: basic-example.rst
