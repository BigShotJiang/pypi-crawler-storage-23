"""Flask server for the mock Vuforia web service."""
