"""An interface to the mock Vuforia which uses ``responses``."""
