# Changelog

All notable changes to `nimoh-be-django-base` will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

_No unreleased changes._

---

## [0.7.0] — 2025-07-19

### Added

- **GDPR Art. 16 — right to rectification (§3.7)**
  - `GDPRService.rectify_data()` — applies allowed field updates (`first_name`, `last_name`, `email`) with full audit trail.
  - `DataRectificationSerializer` — validates field map and optional reason.
  - `PATCH /privacy/gdpr/rectification/` endpoint (`GDPRDataRectificationView`).

- **GDPR Art. 18 — right to restriction of processing (§3.7)**
  - `processing_restricted` and `processing_restricted_at` fields on `PrivacyProfile` (migration `nimoh_privacy.0003`).
  - `PrivacyProfile.restrict_processing()` / `lift_processing_restriction()` instance helpers.
  - `GDPRService.restrict_processing()` and `GDPRService.lift_restriction()` service methods with audit logging.
  - `ProcessingRestrictionSerializer` — validates `reason` and context-dependent `action`.
  - `POST /privacy/gdpr/restriction/` (restrict) and `DELETE /privacy/gdpr/restriction/` (lift) endpoints.

- **Scaffold template improvements (§8)**
  - `project_slug/views.py.j2` — example `ExampleView(APIView)` stub for new scaffolded projects.
  - `docker-compose.prod.yml.j2` — conditional nginx service with ports 80/443, static/media volumes; `web` port 8000 exposed only when `use_nginx` is False.
  - `PROFILE_MODEL` key documented in `conf/defaults.py` with lazy import usage notes.

- **Test coverage (§6) — 137 new tests, 320 total (was 183)**
  - `test_core_utils.py` — `get_client_ip()` and `_is_trusted_proxy()` (16 tests).
  - `test_core_health.py` — `check_database()` and `check_cache()` (9 tests).
  - `test_core_permissions.py` — `IsVerifiedUser`, `IsOwnerOrReadOnly`, `IsAdminOrReadOnly`, `CanManageDevices` (17 tests).
  - `test_core_throttling.py` — scope strings and DRF inheritance for all 13 throttle classes (20 tests).
  - `test_core_middleware.py` — `CorrelationIdMiddleware`, `ErrorHandlingMiddleware`, `HTTPSRedirectMiddleware` (14 tests).
  - `test_conf.py` — `nimoh_setting()` helper (10 tests).
  - `test_monitoring_views.py` — health and readiness endpoints (9 tests).
  - `test_auth_services.py` — `SessionService` and `PasswordService` (≥20 tests).
  - `test_auth_views_extended.py` — password change, session listing/termination (≥10 tests).
  - `test_privacy_services.py` — `GDPRService` (≥12 tests).

### Changed

- Testproject URL conf updated: `api/v1/privacy/` and `api/v1/monitoring/` now registered.

### Fixed

- All pre-existing ruff PT009/PT027 (unittest-style assertions) in `test_core_security.py` converted to pure pytest style.
- B017/PT011 broad `pytest.raises(Exception)` in `test_privacy_models.py` and `test_auth_models.py` replaced with `IntegrityError`.
- PT012 multi-statement `pytest.raises` blocks in `test_core_security.py` and `test_auth_models.py` restructured to single-statement form.

---

## [0.6.0] — 2025-07-18

### Added

- **Social/OAuth2 scaffold support (§3.2)**
  - `is_social_account` and `social_provider` fields on `AbstractNimohUser` (migration `0003`).
  - `nimoh_base.conf.social` — helpers `get_social_installed_apps()`, `get_social_auth_pipeline()`, `get_social_context_processors()`, and `_pipeline_mark_social_account()` pipeline step.
  - `nimoh_base.auth.url_modules.social` — thin URL wrapper around `social_django.urls`.
  - New `[social]` optional extra: `"social-auth-app-django>=5.4"`.
  - `SOCIAL_AUTH_ENABLED` setting in `NIMOH_BASE` (default `False`).
  - System check `W006` — warns when `SOCIAL_AUTH_ENABLED=True` but `social-auth-app-django` is not installed.

- **Email-change flow (§3.3)**
  - `EmailChangeToken` model — UUID PK, stores `new_email`, `token`, `expires_at`, `used_at`, `is_used`, `ip_address`.
  - `EmailChangeService.request_change()` — validates uniqueness, cancels any prior pending token, creates a new token, renders & sends `emails/email_change_confirm.txt`.
  - `EmailChangeService.confirm_change()` — validates token, atomically updates `user.email`, marks token used, writes `AuditLog`.
  - `EmailChangeRequestSerializer` / `EmailChangeConfirmSerializer`.
  - `POST /auth/email/change/` and `POST /auth/email/change/confirm/` endpoints (namespace `email_change`).
  - `EmailChangeTokenAdmin` in Django admin (read-only, no add permission).
  - Plain-text email template `templates/emails/email_change_confirm.txt`.
  - `EMAIL_CHANGE_EXPIRY_HOURS` setting in `NIMOH_BASE` (default `24`).

- **Prometheus metrics endpoint (§3.4)**
  - `GET /monitoring/prometheus/` view — emits `nimoh_info`, `nimoh_active_user_sessions`, `nimoh_http_requests_total`, `nimoh_http_response_time_seconds` gauges/counters/histograms.
  - Feature-gated by `METRICS_ENABLED` (default `False`) and `METRICS_AUTH_REQUIRED` (default `True`).
  - `prometheus-client>=0.20` added to `[monitoring]` extra.
  - System check `W005` — warns when `METRICS_ENABLED=True` but `prometheus-client` is not installed.

- **`BinaryDatabaseStorage` (§4.8)** — new `Storage` subclass in `core/storage.py`:
  - Stores raw bytes as `mime\x00raw_bytes` blobs instead of base64-encoded data URIs (~33% smaller).
  - Transparent backward-compat decoding for existing `data:<mime>;base64,...` values.
  - 1 MB warning threshold; 10 MB hard `ValueError` limit.

- **Problem+JSON URIs (§5.3)** — `core/exceptions.py`:
  - `ERROR_TYPE_MAP` dict with dedicated URI slugs for all 4xx/5xx status codes and named error types (`validation-error`, `authentication-failed`, `account-locked`, `email-not-verified`, `two-factor-required`, `token-invalid`, `permission-denied`).
  - `get_problem_type(status_code)` helper wired into `ProblemDetailException` and `problem_exception_handler`; replaces all `"about:blank"` defaults.

- **CLI improvements (§5.5–§5.12)**
  - `nimoh-base init --no-git` — skip `git init` after scaffolding.
  - `nimoh-base init --dry-run` — list files without writing; prints a `[dry-run]` preview.
  - `nimoh-base upgrade` — new command; compares project `NIMOH_BASE` keys against current package schema and reports missing / unknown keys.
  - Post-scaffold secret reminder — prints a Rich warning panel when `db_password == "changeme"` or `SECRET_KEY` is too short.
  - `mysql` and `mariadb` database engine options in `nimoh-base init` prompts; correct default port (3306); `mysqlclient>=2.2` added to generated `requirements.txt`.
  - Social auth toggle prompt added to `nimoh-base init`.
  - New project template files: `.pre-commit-config.yaml.j2`, `.github/workflows/ci.yml.j2`, `pyproject.toml.j2`.
  - Generated `requirements.txt` now conditionally includes `mysqlclient`, `nimoh-base[monitoring]`, `nimoh-base[social]` based on scaffold choices.

### Changed

- `monitoring` extra: `psutil>=5.9` → `psutil>=5.9, prometheus-client>=0.20`.
- Test project settings now include `TEMPLATES` configuration pointing at the bundled `src/nimoh_base/templates/` directory.

### Migration

Run `python manage.py migrate` to apply migration `0003_email_change_social`:
- Adds `is_social_account` (BooleanField) and `social_provider` (CharField) to the user table.
- Creates `nimoh_auth_email_change_token` table.

---

## [0.5.0] — 2026-03-04

### Added

- **TOTP Two-Factor Authentication (§3.1)** — complete TOTP 2FA subsystem implemented with pure stdlib (no `django-otp` runtime dependency):

  **Models** (`auth/models.py`)
  - `AbstractNimohUser.two_factor_enabled` — `BooleanField(default=False)` flag on the base user model.
  - `TOTPDevice` — one TOTP authenticator per user; stores a 160-bit base32 secret and a `confirmed` flag. Includes `verify(code)` instance method.
  - `BackupCode` — HMAC-SHA256 hashed emergency codes (`XXXX-XXXX` format). Class methods: `generate_for_user(user, count=8)` and `consume(user, code)` (single-use enforced via `select_for_update`).
  - `AuditLog.log_from_request()` — new convenience classmethod that extracts `ip_address` / `user_agent` from an `HttpRequest` and delegates to `log_event()`.
  - Pure-stdlib TOTP helpers at module level: `_generate_totp_secret()`, `_hotp()`, `verify_totp_code()`.

  **Migration** `0002_totp` — adds `two_factor_enabled` field, creates `TOTPDevice` and `BackupCode` tables, adds composite index on `(user, used)` for backup-code lookups.

  **Services** (`auth/services.py`)
  - `TwoFactorService` — orchestrates the full lifecycle:
    - `begin_setup(user)` — provisions an unconfirmed `TOTPDevice`, returns `{secret, otpauth_uri, device_id}`.
    - `confirm_setup(user, code)` — verifies first TOTP code, confirms device, enables 2FA, issues 8 backup codes.
    - `create_challenge(user) → str` — stores a signed challenge in the cache (300 s TTL).
    - `resolve_challenge(token) → User` — single-use; deletes key after resolution.
    - `verify(user, code)` — tries TOTP first, falls back to backup code.
    - `regenerate_backup_codes(user)` — replaces all existing backup codes.
    - `disable(user, code)` — verifies code, deletes `TOTPDevice` + backup codes, clears flag.
  - `AuthenticationService.authenticate_user()` — intercepted to return `{two_factor_required: True, challenge_token, expires_in}` (without issuing JWT/session) when `TWO_FACTOR_ENABLED` is `True` and the user has 2FA active.
  - `AuthenticationService.complete_two_factor_login()` — resolves challenge, verifies TOTP/backup code, creates a verified session (`is_verified=True`), and returns the full JWT payload.

  **Views** (`auth/view_modules/totp.py`)
  - `POST /auth/2fa/setup/` — begin TOTP setup (authenticated users).
  - `POST /auth/2fa/confirm/` — confirm setup with first code (authenticated users).
  - `POST /auth/2fa/verify/` — complete 2FA login from a challenge token (unauthenticated, throttled).
  - `POST /auth/2fa/backup-codes/regenerate/` — regenerate backup codes (authenticated + 2FA enabled).
  - `DELETE /auth/2fa/disable/` — disable 2FA (authenticated + 2FA enabled).

  **Serializers** (`auth/serializers.py`) — `TOTPSetupResponseSerializer`, `TOTPConfirmSerializer`, `BackupCodesResponseSerializer`, `TOTPVerifySerializer`, `TOTPDisableSerializer`.

  **URLs** — `auth/url_modules/totp.py` (namespace `totp`) wired into `auth/urls.py` under `2fa/`.

  **Settings** (`conf/defaults.py`) — new `NIMOH_BASE["TWO_FACTOR_ENABLED"]` setting (`bool`, default `False`). When `False`, all logins complete immediately regardless of per-user `two_factor_enabled` flag.

  **System Check** (`core/checks.py`) — `W004`: warns when `TWO_FACTOR_ENABLED=True` but `django-otp` is not installed (install the `[2fa]` extra).

  **Admin** (`auth/admin.py`) — `TOTPDeviceAdmin` and `BackupCodeAdmin`; secret fields are read-only and devices cannot be added manually.

  **Tests** (`tests/test_totp.py`) — 31 test cases covering pure TOTP helpers, `BackupCode` lifecycle, `TwoFactorService` full flow, the `202 challenge` login intercept, and all 5 API endpoints.

---

## [0.4.2] — 2026-03-04

### Added

- **`./manage.py nimoh_check`** (item 5.4) — new management command that runs all `nimoh_base`-tagged Django system checks and reports results in colour-coded, CI-friendly output:
  - Errors, warnings, and hints are printed in distinct colours via `self.style`.
  - Summary line: `nimoh_check summary: N error(s), M warning(s)`.
  - Exits with code `1` when any message meets or exceeds `--fail-level` (default `ERROR`; use `--fail-level WARNING` for strict mode).
  - `--deploy` flag additionally runs Django's built-in security/deployment checks.
  - Equivalent to `./manage.py check --tag nimoh_base` but with nicer output and full exit-code control.

- **`NIMOH_BASE["SHOW_BANNER"]`** (item 5.2) — new optional setting that controls `print_banner()` in `core/startup.py`:
  - `None` (default) — **auto**: banner is shown when `DEBUG=True`, suppressed otherwise. This prevents the ASCII art from polluting structured JSON logs in production.
  - `True` — always shown regardless of `DEBUG`.
  - `False` — never shown.

### Changed

- `print_banner()` in `core/startup.py` now checks `NIMOH_BASE['SHOW_BANNER']` before printing. Existing projects that relied on the banner always appearing should set `NIMOH_BASE['SHOW_BANNER'] = True` explicitly, or leave it as `None` and ensure `DEBUG=True` in environments where the banner is desired.

---

## [0.4.1] — 2026-03-04

### Performance

- **4.1 — `readiness_check` HealthCheck upsert** — `readiness_check()` now calls `HealthCheck.objects.update_or_create(check_type=..., defaults={...})` instead of `create()`. Kubernetes readiness probes (which fire every few seconds) no longer cause unbounded row growth; the `health_check` table holds exactly one row per check type.

- **4.2 — GDPR export uses `.values()`** — `GDPRDataExporter._export_activity_data()` now calls `.values("event_type", "timestamp", ...)` instead of loading full ORM model instances, eliminating the overhead of instantiating up to 1 000 `AuditLog` objects per export. Row limit is now configurable via the new `NIMOH_BASE["GDPR_EXPORT_MAX_ROWS"]` setting (default `1000`).

- **4.3 — `enforce_session_limit` dispatched as Celery task** — The three `UserSession.enforce_session_limit(user)` calls in `auth/services.py` (login, exchange-token, and mobile session flows) are replaced with `transaction.on_commit(lambda: enforce_session_limit_task.delay(user_pk))`. Session-limit enforcement now runs in a background worker after the login transaction commits, so it no longer adds DB latency to the login request. The synchronous `enforce_session_limit()` classmethod is preserved for direct use.

- **4.4 — `performance_metrics` view cached 60 s** — The `GET /monitoring/performance/` admin endpoint caches its aggregated results in Redis for 60 seconds (cache key: `nimoh_base:perf_metrics:<hours>`). Repeated hits to the dashboard no longer re-aggregate large `PerformanceMetric` / `HealthCheck` querysets on every request.

- **4.5 — `check_celery()` result cached 5 s** — `core/health.py` `check_celery()` now caches its result under `nimoh_base:health:celery` with a 5-second TTL. Back-to-back health probes reuse the last known broker status instead of opening a new Celery connection on every request.

- **4.6 — `SoftDeleteModel` partial index** — `SoftDeleteModel.Meta` now declares a partial index `Index(fields=["is_deleted"], condition=Q(is_deleted=False), name="%(app_label)s_%(class)s_active_idx")`. Queries filtered on `is_deleted=False` (the default manager's filter) use a smaller, faster index that covers only live rows. Consumer projects should run `manage.py makemigrations` after upgrading.

### Added

- **`NIMOH_BASE["GDPR_EXPORT_MAX_ROWS"]`** (default `1000`) — controls the maximum number of `AuditLog` rows included in a user's GDPR data export. Raise for compliance-heavy audits; lower on high-traffic sites with dense audit logs.
- **`enforce_session_limit_task`** (`nimoh_base.auth.tasks`) — new `@shared_task` that wraps `UserSession.enforce_session_limit()` for asynchronous dispatch.

---

## [0.4.0] — 2026-03-04

### Added

- **`HTTPSRedirectMiddleware`** (`nimoh_base.core.middleware.https_redirect`) — issues a permanent 301 redirect for all plain-HTTP requests in production (`DEBUG=False`). Controlled by `NIMOH_BASE["FORCE_HTTPS"]` (default `True`); has no effect when `DEBUG=True`. Added as the first entry in `get_base_middleware()` so the redirect fires before session/CSRF middleware processes unsecured requests.
- **`NIMOH_BASE["FORCE_HTTPS"]`** (default `True`) — toggle for `HTTPSRedirectMiddleware`. Set to `False` when HTTPS is terminated upstream (load-balancer, Nginx).
- **`NIMOH_BASE["BREACH_CHECK_FAIL_OPEN"]`** (default `True`) — controls `BreachedPasswordValidator` behaviour when the HaveIBeenPwned API is unreachable. `True` (default) passes silently so registration is never blocked by external downtime. Set to `False` for high-security environments that must reject passwords when the breach check cannot complete.
- **`{% csp_nonce %}` template tag** (`{% load nimoh_security %}`) — returns the per-request CSP nonce set by `SecurityHeadersMiddleware`. Allows inline `<script>` and `<style>` elements to carry the correct nonce attribute for CSP compliance.
- **`nimoh_base.core.context_processors.security_context`** — Django context processor that exposes `{{ csp_nonce }}` to every template. Add to `TEMPLATES[0]['OPTIONS']['context_processors']` as an alternative to the template tag.
- **`TokenBlacklist` ↔ simplejwt compatibility layer** — `is_blacklisted()` now also checks `rest_framework_simplejwt.token_blacklist.models.BlacklistedToken` when the app is installed; `blacklist_token()` mirrors each revocation to simplejwt's `OutstandingToken` / `BlacklistedToken` tables. Both methods degrade gracefully (no-op) when simplejwt's blacklist app is absent.

### Changed

- **`NIMOH_BASE["SECURITY_SCRUB_PII"]` default changed from `False` to `True`** — `SecurityHeadersMiddleware` now scrubs PII (emails, phone numbers, SSNs) from JSON/XML API response bodies by default. **If your API intentionally returns PII to authenticated callers** (e.g. `GET /me/` returns the user's email address) **you must set `SECURITY_SCRUB_PII = False`** in your `NIMOH_BASE` dict, otherwise those responses will be broken. Log-level scrubbing via `SensitiveDataFilter` is always active and unaffected by this setting.
- `SecurityHeadersMiddleware._load_security_config()` now reads `SECURITY_SCRUB_PII` via `nimoh_setting()` (from `NIMOH_BASE`) instead of `getattr(settings, "SECURITY_SCRUB_PII", False)`.

### Fixed

- **2.7 — `BreachedPasswordValidator` fails open with no toggle** — the fail-open behaviour is now explicit and configurable via `NIMOH_BASE["BREACH_CHECK_FAIL_OPEN"]`.
- **2.8 — No HSTS on first HTTP visit** — `HTTPSRedirectMiddleware` ensures the browser is redirected to HTTPS before `SecurityHeadersMiddleware` sets the HSTS header, closing the gap on the first visit.
- **2.9 — CSP nonce generated but never injectable** — `{% csp_nonce %}` template tag and `security_context` processor make the nonce available in all templates.
- **2.10 — Custom `TokenBlacklist` not linked to simplejwt** — compatibility layer bridges the two blacklists so teams using both systems don't experience gaps in token revocation.

---

## [0.3.0] — 2026-03-05

### Added

- **`CorrelationIdMiddleware`** (`nimoh_base.core.middleware.correlation`) — reads `X-Request-ID` or `X-Correlation-ID` from the incoming request, falls back to a UUID4, stores it on `request.correlation_id`, and echoes it in the `X-Correlation-ID` response header. Wired automatically via `get_base_middleware()` before `SecurityHeadersMiddleware`.
- **Django system checks** (`nimoh_base.core.checks`, tag `nimoh_base`) — five checks run on `./manage.py check --tag nimoh_base`:
  - `E001` — `NIMOH_BASE` dict absent from settings.
  - `E002` — one or more required `NIMOH_BASE` keys missing.
  - `W001` — `AUTH_USER_MODEL` does not sub-class `AbstractNimohUser`.
  - `W002` — core `nimoh_base` apps missing from `INSTALLED_APPS`.
  - `W003` — default throttle-rate keys missing from `REST_FRAMEWORK`.
  Checks are registered automatically via `CoreConfig.ready()`.
- **`monitoring/tasks.py` `cleanup_monitoring_metrics`** — Celery task pruning `PerformanceMetric`, `HealthCheck`, and `EndpointMetrics` rows older than `NIMOH_BASE["MONITORING_RETENTION_DAYS"]` (default 30). Scheduled weekly (Sunday 03:00 UTC) via `get_base_celery_beat()`.
- **`privacy/tasks.py` `enforce_data_retention`** — Celery task enforcing GDPR automatic deletion for users with `PrivacyProfile.auto_delete_inactive_data = True` whose last activity (`max(last_login, date_joined)`) exceeds `NIMOH_BASE["DATA_RETENTION_INACTIVE_DAYS"]` (default 730). Uses `GDPRDataEraser.initiate_erasure(retain_audit=True)`. Scheduled weekly (Sunday 04:00 UTC) via `get_base_celery_beat()`.
- **HTML email support** — `send_email_task` accepts two new keyword arguments: `html_template` (template path) and `template_context` (dict). When `html_template` is supplied the task renders the template via `render_to_string()` and passes the result to `django.core.mail.send_mail()` as `html_message`, producing a multipart MIME email with both plain-text and HTML parts.
- **`NIMOH_BASE["AUDIT_LOG_RETENTION_DAYS"]`** (default `365`) — configures how many days of audit log rows to retain; previously hardcoded.
- **`NIMOH_BASE["MONITORING_RETENTION_DAYS"]`** (default `30`) — configures monitoring metrics retention window.
- **`NIMOH_BASE["DATA_RETENTION_INACTIVE_DAYS"]`** (default `730`) — configures the inactivity window for automatic GDPR data erasure.

### Fixed

- **`get_base_celery_beat()` wrong task names** — the schedule referenced `cleanup_expired_sessions` and `cleanup_old_tokens`, which do not exist; corrected to `cleanup_inactive_sessions` and `cleanup_expired_tokens`.
- **`get_base_celery_beat()` incomplete schedule** — five tasks (`cleanup_old_audit_logs`, `cleanup_monitoring_metrics`, `process_scheduled_deletions`, `cleanup_stale_export_requests`, `enforce_data_retention`) had no beat entries; all are now scheduled.
- **Email template domain-specific content** — `email_verification_email.txt` contained hardcoded reference to a specific organisation ("Vineyard Group Fellowship") and domain-specific URLs; replaced with generic `{{ site_name }}`, `{{ support_email }}`, and `{{ current_year }}` template variables.

---

## [0.2.9] — 2026-03-04

### Security

- **2.2 · `auth/tasks.py` + `auth/view_modules/authentication.py` — SHA-1 hash exposed in Celery broker** — the full uppercase hex SHA-1 of the user's password was serialised into the Redis broker message, making it recoverable via rainbow tables for weak passwords. The view now computes `HMAC-SHA256(SECRET_KEY, sha1_hash[5:])` of the HIBP suffix before enqueuing, and the task compares HMAC digests of each suffix returned by the HaveIBeenPwned API using `hmac.compare_digest()` — the raw SHA-1 suffix never leaves the registering process. The `check_password_breach_by_hash()` helper is no longer called from the task.
- **2.3 · `core/middleware/media.py` — private uploads served as `Cache-Control: public`** — `MediaSecurityMiddleware` unconditionally set `Cache-Control: public, max-age=31536000, immutable` on every 200 media response, allowing ISP proxies, shared CDNs, and corporate gateways to cache private user uploads and serve them to other users. The default is now `Cache-Control: private, no-store`. Opt-in to the old public-cache behaviour by setting `NIMOH_BASE["PUBLIC_MEDIA_CACHE"] = True` (only safe when every file under `MEDIA_URL` is publicly accessible).
- **2.4 · `core/security/views.py` `CSPReportView` — no rate limiting** — the CSRF-exempt POST endpoint had no rate limiting, allowing any client to flood server logs and the database with bogus CSP violation reports. A cache-based counter limits each IP to 60 reports per 60 seconds; requests exceeding the limit receive `HTTP 429`.
- **2.5 · `core/security/headers.py` `SECURITY_SCRUB_PII` undiscoverable** — the `SECURITY_SCRUB_PII` setting controlled response-body PII scrubbing but was absent from both `NIMOH_BASE_SCHEMA` and `OPTIONAL_NIMOH_BASE_DEFAULTS`, so `nimoh-base check` warned it was an unknown key and the 5-second Django startup validation missed misconfigured values. Both are now updated. The default remains `False` because `True` also scrubs PII from intentional API responses (e.g. `GET /me/` → `{"email": "[REDACTED]"}`), which breaks frontends; log-level scrubbing via `SensitiveDataFilter` remains always active.
- **7 · `pyproject.toml` — `django-otp`, `Pillow`, `django-fernet-fields`, `cryptography` as mandatory deps** — all four were listed as mandatory package dependencies even though none are required for the core functionality, forcing them onto every deployer regardless of feature use. They are now optional extras: `[2fa]` (`django-otp>=1.5`), `[image]` (`Pillow>=9.0`), `[encryption]` (`django-fernet-fields>=0.6`, `cryptography>=44.0`). Install everything with `nimoh-be-django-base[all]`. `OptimizedImageStorage` raises `ImproperlyConfigured` at initialisation when Pillow is absent. `get_base_apps(include_otp=True)` silently skips OTP apps when `django-otp` is not installed.

### Added

- `NIMOH_BASE["PUBLIC_MEDIA_CACHE"]` (default `False`) — opt-in to long-lived public caching for media files; see `docs/SETTINGS.md`.
- `NIMOH_BASE["SECURITY_SCRUB_PII"]` (default `False`) — now formally documented in schema and defaults; see `docs/SETTINGS.md`.

---

## [0.2.8] — 2026-03-03

### Fixed

- **1.1 · `auth/LoginSerializer` — account enumeration + missing lock check** — the `"Account is not verified"` error was a different message from `"Invalid credentials provided"`, leaking whether an email address was registered. All failure paths now return the same generic message. Additionally, `record_failed_login()` is now called for _every_ failed authentication (including correct-password-but-inactive accounts), so account lockout is enforced unconditionally. A new early-exit check also prevents login on already-locked accounts before the password is even evaluated.
- **1.2 · `conf/defaults.py` — `NIMOH_BASE_SCHEMA` out of sync** — three keys (`HEALTH_CHECK_CELERY`, `MAX_LOGIN_ATTEMPTS`, `ACCOUNT_LOCK_DURATION_MINUTES`) existed in `OPTIONAL_NIMOH_BASE_DEFAULTS` but were absent from `NIMOH_BASE_SCHEMA`, causing `nimoh-base check` to give false-positive "unknown key" warnings. All three are now documented schema entries with types and descriptions.
- **1.3 · `core/middleware/performance.py` — query count always 0 in production** — `connection.queries` is only populated when `DEBUG=True`, so the logged and persisted query count was `0` for every production request. The middleware now calls `django.db.reset_queries()` and sets `connection.force_debug_cursor = True` at the start of each request (and restores it in `process_response`), giving accurate per-request query counts regardless of the `DEBUG` setting. `QueryCountWarningMiddleware` receives the same fix.
- **1.4 · `privacy/views.py` + `privacy/services.py` — CSV export returned `501 Not Implemented`** — the `GDPRDataExportSerializer` accepted `"csv"` as a valid choice but the service short-circuited with `return None`, causing the view to raise a 501 error. CSV export is now fully implemented: `GDPRService._create_csv_export()` flattens the account, session, and privacy data into a three-column `(section, field, value)` CSV, and returns it as a `text/csv` `HttpResponse` download.
- **1.5 · `auth/services.py` `ExchangeTokenService` — TOCTOU race on token exchange** — two concurrent requests could both read `used=False` before either marked the token used, allowing a single exchange token to be redeemed twice. The race is closed by using `cache.add()` (atomic set-if-not-exists, supported by all Django cache backends) to claim the token before reading its data.
- **1.6 · `core/models.py` `SoftDeleteModel.delete()` — hard-deletes instead of soft-deletes** — `BaseModelViewSet.perform_destroy()` calls `instance.delete()`, but `SoftDeleteModel` did not override `delete()`, so the row was permanently removed from the database. `SoftDeleteModel` now overrides `delete()` to perform a soft-delete (sets `is_deleted=True` / `deleted_at`). A `hard_delete()` method is provided for explicit permanent removal. `soft_delete()` is kept as an alias.
- **1.7 · `core/models.py` `SoftDeleteQuerySet.delete()` — signals not fired** — bulk soft-delete via `.delete()` used `QuerySet.update()`, which does not send Django `pre_delete` / `post_delete` signals, silently breaking audit hooks, cache invalidation, and signal-based cascades. The queryset `delete()` now iterates over the instances, sends both signals per object, then performs the bulk `UPDATE`.
- **1.8 · `privacy/utils/gdpr.py` `_export_profile_data()` — `AttributeError` on projects without `basic_profile`** — the method accessed `self.user.basic_profile` directly, which raises `AttributeError` (not `ObjectDoesNotExist`) on any project that does not define that reverse relation. Access is now via `getattr(self.user, "basic_profile", None)` with per-field `getattr` fallbacks, returning `{}` safely when the attribute does not exist.
- **1.9 · `privacy/services.py` — `settings.TESTING` anti-pattern removed** — the service short-circuited to a hard-coded test payload when `getattr(settings, "TESTING", False)` was truthy, diverging production and test code paths. The special case is removed; tests that need to avoid ZIP file I/O should mock `GDPRDataExporter` via `unittest.mock.patch`.
- **1.10 · `core/storage.py` `Base64DatabaseStorage._get_content_type()` — non-image files got `image/jpeg` MIME type** — PDF, CSV, TXT, JSON, ZIP, and SVG files all fell through to the `image/jpeg` default. The method now uses an explicit extension → MIME map and falls back to the safe `application/octet-stream` instead of `image/jpeg`.
- **1.11 · `privacy/models.py` — removed domain-specific `recovery_info_visibility` field** — "who can see recovery information" is specific to addiction-recovery apps and has no place in a generic reusable package. The field has been removed from `PrivacyProfile`, its serializer reference dropped from `PrivacyProfileSerializer`, and a new migration `0002_remove_recovery_info_visibility` drops the column from the database.

### Migration required

Run `./manage.py migrate nimoh_privacy` to apply migration `0002_remove_recovery_info_visibility`.

---

## [0.2.7] — 2026-03-03

### Fixed

- **`cli/generators.py` ruff formatting** — applied `ruff format` to resolve CI lint failure introduced in 0.2.6.

---

## [0.2.6] — 2026-03-03

### Added

- **Auto-copy `.env.example` → `.env` during scaffolding** — `render_project()` now copies `.env.example` to `.env` immediately after generating all files. The copy is skipped if a `.env` already exists so re-running the generator inside an existing project is safe.

---

## [0.2.5] — 2026-03-03

### Fixed

- **`cli/generators.py` regression — empty `__init__.py` files not written** — the "skip empty rendered files" guard introduced in 0.2.3 incorrectly discarded intentionally empty `__init__.py` package markers (e.g. `config/__init__.py`, `config/settings/__init__.py`). The check now exempts any file named `__init__.py`.

---

## [0.2.4] — 2026-03-03

### Changed

- **`docker-compose.yml.j2` (dev)** — the `web` service now explicitly sets `ALLOWED_HOSTS` (includes `backend` so the FE nginx container can resolve the BE by its Docker service name without 400 Bad Request) and `CORS_ALLOWED_ORIGINS` (defaults to both `http://localhost:3000` and `http://localhost:8080`, covering Vite dev and FE prod-nginx ports out of the box).
- **`.env.example.j2`** — `CORS_ALLOWED_ORIGINS` now shows both `:3000` and `:8080` as defaults; `ALLOWED_HOSTS` default includes `backend`; each entry carries an inline comment explaining the purpose.
- **`docker-compose.prod.yml.j2`** — added a prominent warning comment that `config.settings.production` enables `SECURE_SSL_REDIRECT=True`, which causes 301 → HTTPS loops on plain HTTP localhost. Instructs developers to switch to `config.settings.development` when embedding the BE in the FE’s compose for local testing.

---

## [0.2.3] — 2026-03-03

### Added

- **`project_slug/urls.py.j2`** — scaffold now generates a starter DRF `DefaultRouter` URL file for every project. The matching `path('api/v1/', include(...))` in `config/urls.py.j2` is active by default (was commented out).
- **`project_slug/consumers.py.j2` + `project_slug/routing.py.j2`** (channels projects only) — when `use_channels=True`, the scaffold produces a working `ExampleConsumer` and a `websocket_urlpatterns` routing file. `config/asgi.py.j2` is updated to import and wire them into `ProtocolTypeRouter` immediately, replacing the dead commented-out placeholder.
- **`docker-compose.prod.yml.j2`** — new production Docker Compose template (web + redis, optional celery/celery-beat) covering all required env vars. Includes a commented shared-network block for FE↔BE container wiring.
- **`Makefile.j2` `prod` / `prod-build` / `prod-down` targets** — drive the new `docker-compose.prod.yml` from `make`.
- **`Makefile.j2` `network-create` target** — creates the `{{ project_slug }}-network` Docker network with one command, the prerequisite for linking BE and FE containers.
- **`Makefile.j2` `dev` output** — health endpoint (`/api/v1/health/`) is now printed alongside the existing Application / Admin / API Docs URLs after a successful `make dev`.
- **`.env.example.j2` production section** — commented-out block showing `ALLOWED_HOSTS`, `CORS_ALLOWED_ORIGINS`, `FRONTEND_URL`, `TRUSTED_PROXY_IPS`, and `APP_VERSION` for production deployments.

### Changed

- **`cli/generators.py`** — rendered files whose content is entirely whitespace are now silently skipped rather than written as empty files (important for the channels-only templates above when `use_channels=False`).

---

## [0.2.2] — 2026-03-03

### Fixed

- **`requirements.txt.j2` missing `channels` extra** — when a project was generated with `use_channels=True`, the template emitted only a comment instead of `nimoh-be-django-base[channels]>=...`, causing `ModuleNotFoundError: No module named 'channels'` at Docker build time. The line now correctly renders the pip extra.

---

## [0.2.1] — 2026-02-22

### Fixed

- **`sessions.py` still imported `django_ratelimit`** — `list_sessions_view`, `terminate_session_view`, and `terminate_all_sessions_view` still used `@ratelimit` decorators after M6 was applied only to `password.py`. Replaced with `DeviceManagementRateThrottle` inline checks.

### Added

- **`docs/DEPLOYMENT.md`** — new guide covering nginx reverse-proxy config, `SECURE_PROXY_SSL_HEADER`, trusted proxy IP considerations, Let's Encrypt TLS cert setup, Gunicorn systemd unit, and a pre-launch checklist.
- **`_get_package_version()` fallback in `monitoring/views.py`** — `/api/v1/health/` now resolves the version via `importlib.metadata` when `APP_VERSION` is not set in Django settings, eliminating the `"unknown"` default.

### Changed

- **`register_view` / `login_view` docstrings merged** — each view had two separate docstrings (the second one after the throttle check was a dead string literal). Merged into a single canonical docstring; throttle imports moved to module level.
- **`CELERY_WORKER_PREFETCH_MULTIPLIER`** — added explanatory comment documenting why 1 is the safer default for variable-cost tasks.
- **`get_base_simple_jwt()` docstring** — documents when to switch to `RS256` with a ready-to-use override snippet.
- **`get_base_middleware()` comment** — clarifies why `SessionMiddleware` is retained even for JWT-only projects (`UserSession.session_key` tracking).
- **`PerformanceMonitoringMiddleware` health skip-list** — added `/api/v1/health/` alongside `/health/`, `/healthz/`, `/ready/` so the canonical endpoint is excluded from performance metrics.

### Removed / Fixed

- **`self.nonce_cache = {}`** removed from `SecurityHeadersMiddleware.__init__` — the dict was initialised but never written to (CSP nonces live on `request.csp_nonce` per-request).

---

## [0.2.0] — 2026-05-29

### Added

- **Auth view test suite** (`tests/test_auth_views.py`) — 11 integration tests covering register, login, token refresh, logout, and password reset endpoints using `pytest-django` and `APIClient`.
- **`ChangePasswordRateThrottle`** — new DRF throttle class in `core/throttling.py` with scope `change_password`, completing the unified throttle system for all auth endpoints.
- **`include_channels` / `include_otp` params on `get_base_apps()`** — callers can now exclude `channels` / `channels-redis` or `django_otp` / OTP plugins from `INSTALLED_APPS` by passing `include_channels=False` / `include_otp=False`.
- **Optional extras in `pyproject.toml`** — `[channels]`, `[sentry]`, `[monitoring]`, `[csp]`, `[cli]`, `[dev]`, `[all]` extras give consumers fine-grained control over installed dependencies.
- **Beta classifier** — `Development Status :: 4 - Beta`.

### Changed

- **`get_base_celery()` default `result_backend`** changed from `'django-db'` to `'redis://localhost:6379/2'`. Pass `result_backend='django-db'` explicitly to restore the old behaviour.
- **Password views** (`change_password_view`, `password_reset_request_view`, `PasswordResetConfirmView`) now use DRF throttle classes instead of `@ratelimit` decorators — eliminates the `django-ratelimit` dependency and provides a unified rate-limiting interface.
- **Response-level PII scrubbing disabled by default** — `SECURITY_SCRUB_PII` now defaults to `False`. The previous default of `True` caused `/api/v1/me/` to return `{"email": "[REDACTED]"}`. Log-level redaction via `SensitiveDataFilter` covers the primary threat model. Opt in with `SECURITY_SCRUB_PII=True`.

### Removed

- `django-csp`, `channels`, `channels-redis`, `sentry-sdk`, `structlog`, `psutil`, `django-ratelimit` removed from hard dependencies. Use the new optional extras where needed.

---

## [0.1.21] — 2026-02-22

### Added / Changed

- **Phase 2 — H1–H5 security hardening** — account lockout (`MAX_LOGIN_ATTEMPTS`, `ACCOUNT_LOCK_DURATION_MINUTES`), `PrivacyConsentRecord`, `PrivacySerializer`, `AuditLog` improvements, JWT `BLACKLIST_AFTER_ROTATION=True`, and `SensitiveDataFilter` integrated into `LOGGING`.

---

## [0.1.20] — 2026-02-22

### Fixed

- **Phase 1 — C1–C5 production-readiness fixes** — template bugs: corrected `get_base_apps()` channel/OTP app names, fixed scaffolded `CELERY_BROKER_URL` env var reference, fixed `CorsMiddleware` ordering, removed non-existent `nimoh_base.search` app reference, ensured `nimoh_base_urlpatterns()` is called in generated `urls.py`.

---

## [0.1.19] — 2026-02-21

### Fixed

- Added `HEALTH_CHECK_CELERY=false` to the `.env.example` template so new projects can immediately opt out of the Celery worker check during local development.

---

## [0.1.18] — 2026-02-21

### Fixed

- **Celery health check fast-fail** — `check_celery()` now returns `{"status": "degraded"}` (instead of raising an exception) when the broker is unreachable, preventing the health endpoint from returning `500`.
- **`HEALTH_CHECK_CELERY` opt-out flag** — set `NIMOH_BASE["HEALTH_CHECK_CELERY"] = False` to skip the Celery worker check in `/api/v1/health/`. Useful in environments where Celery is not deployed.

---

## [0.1.17] — 2026-02-20

### Style

- Formatted `conf/__init__.py` and `core/logging.py` with `ruff format` — no logic changes.

---

## [0.1.16] — 2026-02-20

### Fixed

- Resolved ruff lint errors in `core/logging.py`: `RUF002` (ambiguous unicode in docstring), `I001` (unsorted imports), `RUF100` (unused `# noqa`), `UP017` (`datetime.timezone.utc` → `datetime.UTC`).

---

## [0.1.15] — 2026-02-20

### Added

- **Structured logging** — three new log formatters in `core/logging.py`:
  - `DevConsoleFormatter` — coloured, human-readable output for local development.
  - `JsonFormatter` — structured JSON output for production log aggregators.
  - `SensitiveDataFilter` — `logging.Filter` that redacts email addresses, passwords, tokens, and credit card numbers from log records before they are emitted.
- `get_base_logging()` in `NimohBaseSettings` wires these formatters into the standard Django `LOGGING` dict.

---

## [0.1.14] — 2026-02-20

### Fixed

- Removed the `db` postgres service from the `docker-compose.yml` template — the database is expected to run on the host. Replaced all `db` hostname references in `DATABASE_URL` env vars with `host.docker.internal`.

---

## [0.1.13] — 2026-02-20

### Changed

- Version bump only.

---

## [0.1.12] — 2026-02-20

### Changed

- Version bump only.

---

## [0.1.11] — 2026-02-20

### Fixed

- **Docs URL alias renamed** — `api/v1/docs/` alias renamed to `api/v1/schema/docs/` for consistency with the `schema/` URL namespace.
- **COEP + font-src on docs pages** — resolved `Cross-Origin-Embedder-Policy` conflict with Swagger / ReDoc assets; added `https://fonts.googleapis.com` and `https://fonts.gstatic.com` to `font-src`.

---

## [0.1.10] — 2026-02-20

### Fixed

- Added `https://cdn.redoc.ly` to CSP `img-src` (ReDoc logo).
- Added `blob:` to `worker-src` for ReDoc's web worker.
- Added Google Fonts sources (`fonts.googleapis.com`, `fonts.gstatic.com`) to `font-src` for docs pages.

---

## [0.1.9] — 2026-02-20

### Fixed

- Removed dead `anonymize_recovery_data` field from `PrivacyProfileSerializer` (field had been removed from the model but the serializer still referenced it, causing a `FieldDoesNotExist` error on read).
- Fixed report-only CSP policy for API documentation pages.

---

## [0.1.8] — 2026-02-20

### Fixed

- **CSP `_is_api_documentation` versioned paths** — replaced hardcoded path list (`/api/docs`, `/api/schema`) with segment-based matching so `/api/v1/docs/`, `/api/v1/schema/swagger-ui/` etc. are correctly identified as documentation pages.
- Registered `csp-report` endpoint in `nimoh_base_urlpatterns()`.

---

## [0.1.7] — 2026-02-20

### Added

- **`api/v1/docs/` shortcut URL** — `nimoh_base_urlpatterns()` now registers a
  `api/v1/docs/` path (named `docs`) as a short, memorable alias for the
  Swagger UI. Previously the only way to reach the interactive API docs was
  via the verbose `api/v1/schema/swagger-ui/` URL.
- **Root `/` redirect in generated projects** — the scaffolded `config/urls.py`
  now includes a `DEBUG`-gated `RedirectView` that sends `GET /` →
  `/api/v1/docs/`, so opening the bare root URL in a browser during
  development lands directly on the API docs instead of a 404.

---

## [0.1.6] — 2026-02-20

### Fixed

- **`EnhancedUserAdmin` 500 error on `/admin/nimoh_auth/user/`** —
  `get_queryset()` called `.select_related("basic_profile")` but no such
  reverse relation exists on `User`. The only OneToOne relation is
  `privacy_profile` (from `PrivacyProfile`). Six more references to the
  non-existent `basic_profile` were scattered across `display_name_from_profile`,
  `profile_completion_status`, and `profile_info_summary` methods, all of which
  used it to access `display_name`, `bio`, and `timezone` fields that don't
  exist anywhere. Fixed by:
  - `get_queryset`: `select_related("basic_profile")` → `select_related("privacy_profile")`
  - `display_name_from_profile`: replaced with `obj.get_full_name() or obj.username`
  - `profile_completion_status`: now shows privacy consent percentages from `privacy_profile`
  - `profile_info_summary`: now shows consent + visibility info from `privacy_profile`
  - `search_fields`: replaced `basic_profile__display_name` / `basic_profile__bio` with
    `first_name` / `last_name` (fields that actually exist on `User`)
  - All broken `RelatedObjectDoesNotExist` exception handlers replaced with plain `AttributeError`

---

## [0.1.5] — 2026-02-20

### Fixed

- **CSRF 403 on every admin/form POST — two separate root causes:**
  1. `SecurityHeadersMiddleware._compile_pii_patterns()` contained a catch-all
     pattern (`[A-Za-z0-9]{20,}`) intended to redact session tokens from JSON
     API responses. Because `_scrub_response_pii()` also processed `text/html`
     responses, this pattern matched and replaced the 64-char CSRF token inside
     every rendered Django form with `[REDACTED]` (9 chars). Django's CSRF
     middleware then rejected the POST with *"CSRF token from POST has incorrect
     length"*. Fixed by:
     - Removing the over-broad long-alphanumeric and IP-address patterns from
       `_compile_pii_patterns()`.
     - Restricting `_scrub_response_pii()` to `application/json` and
       `application/xml` content types only (was also matching `text/*`).
  2. `set_response_cookies()` in `auth/utils/cookies.py` called
     `set_csrf_cookie()`, which unconditionally overwrote the `csrftoken`
     cookie with an empty string (`""`). This happened on every login response,
     clearing the valid token that `CsrfViewMiddleware` had just written.
     Fixed by removing the `set_csrf_cookie()` call — Django's middleware
     already manages that cookie correctly.

---

## [0.1.4] — 2026-02-20

### Fixed

- **`project_slug` empty in `--no-input` mode** — `load_config()` in `cli/config.py` now
  auto-derives `project_slug` from `project_name` when the field is absent or blank in the
  YAML config file. Previously, omitting `project_slug` from `init.yml` caused
  `INSTALLED_APPS` to contain an empty string (`''`), resulting in
  `ValueError: Empty module name` on `manage.py migrate`.
- **Celery Redis URL double path in `.env.example.j2`** — `CELERY_BROKER_URL` and
  `CELERY_RESULT_BACKEND` templates previously appended `/1` and `/2` directly to
  `{{ redis_url }}` (which already ends in a database index, e.g. `/0`), producing invalid
  URLs like `redis://localhost:6379/0/1`. Fixed to strip the trailing index before appending
  the correct one (e.g. `redis://localhost:6379/1`).

### Added

- **`docs/GETTING_STARTED.md`** — comprehensive step-by-step guide for creating a new
  project from scratch: prerequisites, install, scaffold, `.env` configuration, database
  setup, migrations, running the server, verifying endpoints, Celery setup, Docker Compose
  usage, and troubleshooting.

---

## [0.1.3] — 2026-02-20

### Fixed

- **`get_base_apps()`** — renamed kwargs `monitoring=` / `privacy=` / `channels=` to
  `include_monitoring=` / `include_privacy=` (dropped non-existent `channels=` parameter).
  Template `config/settings/base.py.j2` updated to match.
- **`get_base_spectacular_settings()`** — added `title`, `description`, and `version` parameters
  (template was already passing them; method now accepts and uses them).
- **`get_base_logging()`** — added `log_level` parameter; returned dict now includes a `loggers`
  section with `nimoh_base` and `django` sub-loggers (required by generated `development.py`).
- **`nimoh_base_urlpatterns()`** — renamed kwargs `monitoring=` / `privacy=` / `api_docs=` to
  `include_monitoring=` / `include_privacy=` / `include_schema=`.
  Template `config/urls.py.j2` updated to match.
- **`conf/urls.py`** — fixed import of health check view: was
  `from nimoh_base.core.health import health_check_view` (non-existent); corrected to
  `from nimoh_base.monitoring.views import health_check`.
- **Jinja2 boolean rendering** — replaced `{{ var | lower }}` (renders Python `True` as JSON
  `true`) with `{{ 'True' if var else 'False' }}` in `base.py.j2` and `urls.py.j2`.
- **`AUTH_USER_MODEL` in template** — was `'{{ project_slug }}.User'`; corrected to
  `'nimoh_auth.User'` (custom User model lives in the package, not the consumer project).
- **`read_env()` path** — template now resolves the project root via
  `pathlib.Path(__file__).resolve().parent.parent.parent` and passes it explicitly to
  `environ.Env.read_env()`. Fixes `django-environ ≥0.9` behaviour where `read_env()` without
  arguments looks in the caller's directory (`config/settings/`) instead of the project root.
- **Default `DATABASE_URL` in template** — replaced invalid `django.db.backends.postgresql://…`
  scheme with the correct `postgresql://…` scheme.
- **Celery broker / result-backend URLs** — template default was `env('REDIS_URL') + '/N'`,
  producing a double-path URL (`redis://localhost:6379/0/1`). Replaced with
  `_REDIS_BASE = env('REDIS_URL').rsplit('/', 1)[0]` to obtain the base URL, then appended `/1`
  and `/2` separately.
- **`SecurityHeadersMiddleware._apply_core_headers()`** — replaced `response.pop("Server", None)`
  (dict method, not available on `HttpResponse`) with a `del response["Server"]` guarded by
  `try / except KeyError`. Fixes `AttributeError: 'JsonResponse' object has no attribute 'pop'`
  on every request through the middleware.

---

## [0.1.2] — 2026-02-20

### Fixed

- **`auth.admin`** — replaced module-level `from apps.profiles.models import UserProfileBasic`
  and `from apps.profiles.admin import UserProfileBasicAdminForm` with a `_get_configured_profile_model()`
  helper using `NIMOH_BASE['PROFILE_MODEL']`. The `UserProfileBasicInline` is only registered if
  a profile model is configured; otherwise it is skipped gracefully.
- **`auth.admin.create_missing_profiles`** — replaced hardcoded `UserProfileBasic.objects` with
  the configured `ProfileModel` resolved at call time.
- **`privacy.utils.gdpr`** — removed module-level `from apps.profiles.models import UserProfileBasic`;
  both `except UserProfileBasic.DoesNotExist` clauses replaced with the portable
  `except ObjectDoesNotExist` from `django.core.exceptions`.

---

## [0.1.1] — 2026-02-20

### Fixed

- **`privacy.services`** — replaced hardcoded `from apps.profiles.models import UserProfileBasic`
  with a configurable lookup via `NIMOH_BASE['PROFILE_MODEL']` (e.g. `'profiles.UserProfileBasic'`).
  Raises `ImproperlyConfigured` with a clear message if the setting is absent.
- **`privacy.tasks`** — corrected indentation inside `try:` block that caused
  `IndentationError` at import time in the 0.1.0 sdist.
- **Missing base dependencies** — added `Pillow>=9.0` and `user-agents>=2.2` to the
  package's required dependencies (both were hard imports but omitted from `pyproject.toml`).

---

## [0.1.0] — 2025-02-19

Initial alpha release.  Extracted from the `tast-be-app` internal backend over
seven phases of debranding, decoupling, scaffolding, testing, and documentation.

### Added

#### Core (`nimoh_base.core`)
- `TimeStampedModel` and `SoftDeleteModel` abstract base models
- `SecurityHeadersMiddleware` — configurable `Server:` header, HSTS, frame-options
- `PerformanceMonitoringMiddleware` — per-request HTTP/DB metrics with optional DB persistence
- SQL injection guard middleware
- Custom DRF throttle classes (burst + sustained)
- Standardised DRF exception handler returning consistent JSON error envelopes
- `NimohBaseSettings` — composable helpers for `INSTALLED_APPS`, `MIDDLEWARE`,
  `REST_FRAMEWORK`, `SIMPLE_JWT`, `CACHES`, `LOGGING`
- `validate_nimoh_base_settings()` — asserts required `NIMOH_BASE` keys at startup
- `nimoh_setting(key, default=…)` — safe accessor for `NIMOH_BASE` values

#### Auth (`nimoh_base.auth`)
- `AbstractNimohUser` — email-primary swappable user model with fields:
  `email`, `username`, `email_verified`, `email_verified_at`,
  `failed_login_attempts`, `locked_until`
- Account-lock helpers: `lock_account()`, `unlock_account()`,
  `record_failed_login()`, `record_successful_login()`, `is_account_locked()`
- JWT authentication (access + rotating refresh) via `djangorestframework-simplejwt`
- Device-session tracking with `User-Agent` parsing and mobile-client detection
- MFA (TOTP) registration, verify, and disable endpoints
- Email verification flow (send, confirm, resend)
- Password-reset flow (request, confirm)
- HIBP Pwned Passwords validator on registration and password change
- Audit log for login/logout/password-change events
- Registration, login, refresh, logout, user-detail REST endpoints

#### Monitoring (`nimoh_base.monitoring`)
- HTTP performance metrics model and API endpoint
- DB query-count per-request tracking
- Liveness (`/health/`) and readiness (`/health/ready/`) health-check endpoints
- K8s / Docker-compatible JSON health responses

#### Privacy (`nimoh_base.privacy`)
- `PrivacyProfile` model (one-per-user) with consent and visibility fields
- Consent records and data-processing log endpoints
- GDPR data-export endpoint (async, emailed to user)
- Data-deletion confirmation flow

#### Config (`nimoh_base.conf`)
- `nimoh_base_urlpatterns(api_prefix, *, include_auth, include_monitoring,
  include_privacy, include_schema, include_health)` — one-call URL registration
- `make_celery(settings_module=None)` — Celery app factory
- `NIMOH_BASE_SCHEMA`, `NIMOH_BASE_DEFAULTS`, `NIMOH_BASE_REQUIRED_KEYS`

#### CLI (`nimoh_base.cli`) — requires `[cli]` extra
- `nimoh-base init` — interactive project scaffolding with Jinja2 templates
- `nimoh-base check` — pre-flight `NIMOH_BASE` validation
- `nimoh-base config-template` — prints a ready-to-edit `NIMOH_BASE` snippet

#### Testing utilities
- `pytest-django` integration; `conftest.py` with session-scoped DB fixtures
- `UserFactory` and `create_user_with_profile` helpers
- Full test suite: 119 tests across Python 3.12 + 3.13 / Django 5.1 matrix
- `tox.ini` + GitHub Actions CI workflow

#### Documentation
- Comprehensive `README.md` with Quick Start, CLI walkthrough, URL reference
- `docs/SETTINGS.md` — full `NIMOH_BASE` key reference
- `docs/EXTENDING.md` — user-model subclassing, template/view/middleware overrides
- `docs/MIGRATION_GUIDE.md` — step-by-step for new and existing projects

### App label changes (from internal tast-be-app)

| Old label | New label |
|-----------|-----------|
| `core` (`apps.core`) | `nimoh_core` |
| `authentication` (`apps.authentication`) | `nimoh_auth` |
| `monitoring` (`apps.monitoring`) | `nimoh_monitoring` |
| `privacy` (`apps.privacy`) | `nimoh_privacy` |

> See [docs/MIGRATION_GUIDE.md](docs/MIGRATION_GUIDE.md) for full migration instructions.

---

[Unreleased]: https://github.com/ThriledLokki983/nimoh-be-django-base/compare/v0.1.0...HEAD
[0.1.0]: https://github.com/ThriledLokki983/nimoh-be-django-base/releases/tag/v0.1.0
