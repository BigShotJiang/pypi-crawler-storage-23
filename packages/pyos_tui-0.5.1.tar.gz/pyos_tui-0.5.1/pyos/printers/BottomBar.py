# printers/BottomBar.py

from loguru import logger
from ..Attrs import BOLD
from .printers import print_empty_line

class BottomBar:
    @staticmethod
    def layout():
        return {"height": 2}

    @staticmethod
    def display_state(items=None):
        if items is None:
            items = {}
        return {
            "items": items,
            "layout": BottomBar.layout(),
            "line_generator": BottomBar.make_bottom_bar
        }

    @staticmethod
    def make_bottom_bar(context, remaining_height):
        def _print_bar(screen, y):
            _, num_cols = screen.getmaxyx()
            parts = [str(v) for _, v in context.get("items", {}).items()]
            text = " | ".join(parts)
            clipped = text[: max(0, num_cols - 1)]
            screen.addstr(y, 0, clipped, BOLD)
        return [print_empty_line, _print_bar]

    @staticmethod
    def log_bottom_bar(display_state: dict, message: str, key: str = "message"):
        logger.info(f"Bottom Bar Log: {message}")

        bottom_bar_context = display_state.get("bottom_bar", None)

        if bottom_bar_context:
            bottom_bar_context["items"][key] = message
