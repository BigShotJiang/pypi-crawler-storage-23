# printers/MultilineText.py

from .printers import make_multiline_text

class MultilineText:
    @staticmethod
    def layout(min_height=1, flex=1, max_height=None):
        cfg = {"flex": flex, "min_height": min_height}
        if max_height is not None:
            cfg["max_height"] = max_height
        return cfg

    @staticmethod
    def display_state(lines=None, min_height=1, flex=1, max_height=None):
        return {
            "lines": list(lines or []),
            "layout": MultilineText.layout(min_height, flex, max_height),
            "line_generator": make_multiline_text
        }
