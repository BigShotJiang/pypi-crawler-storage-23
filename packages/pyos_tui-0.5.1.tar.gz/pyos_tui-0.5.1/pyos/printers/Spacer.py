# printers/Spacer.py

from .printers import print_empty_line

class Spacer:
    @staticmethod
    def layout(flex=1, min_height=0, max_height=None):
        cfg = {"flex": flex, "min_height": min_height}
        if max_height is not None:
            cfg["max_height"] = max_height
        return cfg

    @staticmethod
    def display_state(flex=1, min_height=0, max_height=None):
        def make_spacer(context, remaining_height):
            count = max(0, remaining_height)
            return [print_empty_line] * count
        return {
            "layout": Spacer.layout(flex, min_height, max_height),
            "line_generator": make_spacer
        }
