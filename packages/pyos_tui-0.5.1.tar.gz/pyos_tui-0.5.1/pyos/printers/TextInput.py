# printers/TextInput.py

from .printers import make_text_input

class TextInput:
    @staticmethod
    def layout():
        return {"height": 1}

    @staticmethod
    def display_state(label="", text="", focused=False, input_handler=None, mouse_handler=None):
        ctx = {
            "label": label,
            "text": text,
            "focused": bool(focused),
            "layout": TextInput.layout(),
            "line_generator": make_text_input
        }
        if input_handler:
            ctx["input_handler"] = input_handler
        if mouse_handler:
            ctx["mouse_handler"] = mouse_handler
        return ctx
