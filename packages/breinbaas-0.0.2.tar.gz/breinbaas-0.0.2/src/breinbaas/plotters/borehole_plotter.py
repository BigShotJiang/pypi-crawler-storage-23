from typing import Optional
import matplotlib.pyplot as plt

from ..objects.borehole import Borehole
from ..objects.soil_collection import SoilCollection


class BoreholePlotter:
    def __init__(self, borehole: Borehole):
        self.borehole = borehole

    def plot(
        self, soil_collection: SoilCollection = None, to_file: Optional[str] = None
    ):
        if soil_collection is None:
            soil_collection = SoilCollection.default()

        fig, ax = plt.subplots(1, 1, figsize=(4, 9))

        for soil_layer in self.borehole.soil_profile.soil_layers:
            if soil_layer.soil_code not in soil_collection.color_dict:
                color = "gray"
            else:
                color = soil_collection.color_dict[soil_layer.soil_code]

            ax.plot([0, 1], [soil_layer.top, soil_layer.top], color="black")
            ax.plot([0, 1], [soil_layer.bottom, soil_layer.bottom], color="black")

            ax.fill_between(
                x=[0, 1],
                y1=soil_layer.top,
                y2=soil_layer.bottom,
                color=color,
                alpha=0.7,
            )
            ax.text(
                0.5,
                (soil_layer.top + soil_layer.bottom) / 2,
                soil_layer.soil_code,
                horizontalalignment="center",
                verticalalignment="center",
                color="black",
            )

        ax.text(
            0.5,
            self.borehole.z,
            f"{self.borehole.z}",
            horizontalalignment="center",
            verticalalignment="bottom",
            color="black",
        )

        plt.title(f"{self.borehole.name}\nx={self.borehole.x}\ny={self.borehole.y}")
        plt.ylabel("Diepte [m]")
        ax.grid(visible=True, which="both", color="gray", linestyle="-", axis="y")

        if to_file is not None:
            plt.savefig(to_file)

        return fig
