#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>
#include <vector>
#include <cmath>
#include <map>
#include <algorithm>
#include <Eigen/Dense>
#include "nanoflann.hpp" 

namespace py = pybind11;
using namespace Eigen;
using namespace std;

// --- Data Structures ---

struct Point {
    double x, y, z;
    int code;
};

// Wrapper for nanoflann
struct PointCloud {
    std::vector<Point> pts;
    inline size_t kdtree_get_point_count() const { return pts.size(); }
    inline double kdtree_get_pt(const size_t idx, const size_t dim) const {
        if (dim == 0) return pts[idx].x;
        if (dim == 1) return pts[idx].y;
        return pts[idx].z;
    }
    template <class BBOX> bool kdtree_get_bbox(BBOX& /*bb*/) const { return false; }
};

typedef nanoflann::KDTreeSingleIndexAdaptor<
    nanoflann::L2_Simple_Adaptor<double, PointCloud>,
    PointCloud, 3
> my_kd_tree_t;

// --- The Core Class ---

class VoxelModeler {
    PointCloud cloud;
    my_kd_tree_t* index = nullptr;
    double anisotropy_ratio = 50.0; // Default: Vert changes 50x faster than Horiz
    
    // Variogram params (hardcoded for demo, usually setters)
    double range = 200.0; 
    double sill = 1.0;
    double nugget = 0.1;

public:
    VoxelModeler() {}
    ~VoxelModeler() { delete index; }

    void set_anisotropy(double ratio) { anisotropy_ratio = ratio; }

    // 1. Ingest Data: Discretize layers into points
    void add_profiles(py::list profiles, double step_size) {
        for (auto item : profiles) {
            // Access Python object attributes
            double x = item.attr("x").cast<double>();
            double y = item.attr("y").cast<double>();
            py::list layers = item.attr("soil_layers"); // Adjusted to match SoilProfile.soil_layers

            for (auto l : layers) {
                double top = l.attr("top").cast<double>();
                double bot = l.attr("bottom").cast<double>();
                int code = l.attr("soil_code").cast<int>();

                // Create a point every 'step_size' meters (e.g. 0.5m)
                // Ensure we add at least one point if the layer is thin
                double thickness = top - bot;
                int num_steps = std::max(1, (int)(thickness / step_size));
                
                for (int i = 0; i < num_steps; ++i) {
                     double z = bot + (i + 0.5) * (thickness / num_steps);
                     cloud.pts.push_back({x, y, z * anisotropy_ratio, code});
                }
            }
        }
    }

    // 2. Build Tree
    void build() {
        if (cloud.pts.empty()) throw std::runtime_error("No data added!");
        index = new my_kd_tree_t(3, cloud, nanoflann::KDTreeSingleIndexAdaptorParams(10));
        index->buildIndex();
    }

    // 3. Helper: Variogram
    double variogram(double h) {
        if (h == 0) return 0.0;
        if (h > range) return sill;
        return nugget + (sill - nugget) * (1.5 * (h/range) - 0.5 * pow(h/range, 3));
    }

    // 4. Generate Grid (Returns a flattened 1D array of soil codes)
    py::array_t<int> generate(
        double x_min, double x_max, 
        double y_min, double y_max, 
        double z_min, double z_max, 
        double dx, double dy, double dz
    ) {
        // Calculate grid dimensions
        int nx = (int)((x_max - x_min) / dx);
        int ny = (int)((y_max - y_min) / dy);
        int nz = (int)((z_max - z_min) / dz);
        
        if (nx <= 0 || ny <= 0 || nz <= 0) {
             throw std::runtime_error("Invalid grid dimensions");
        }
        
        int total_voxels = nx * ny * nz;

        // Allocate NumPy array
        auto result = py::array_t<int>(total_voxels);
        auto ptr = result.mutable_unchecked<1>();

        // Parallelize Loop
        #pragma omp parallel for
        for (int idx = 0; idx < total_voxels; idx++) {
            // Convert index to x,y,z
            int iz = idx % nz;
            int iy = (idx / nz) % ny;
            int ix = idx / (ny * nz);

            double cx = x_min + ix * dx + dx/2.0;
            double cy = y_min + iy * dy + dy/2.0;
            double cz = z_min + iz * dz + dz/2.0;

            // Search Neighbors
            double query_pt[3] = {cx, cy, cz * anisotropy_ratio};
            const size_t num_neighbors = 10;
            my_kd_tree_t::IndexType ret_index[num_neighbors];
            double out_dist_sqr[num_neighbors];

            // Finding neighbors
            index->knnSearch(&query_pt[0], num_neighbors, &ret_index[0], &out_dist_sqr[0]);

            // Ordinary Kriging System
            // Solve [ C  1 ] [ w ] = [ c0 ]
            //       [ 1  0 ] [ mu]   [ 1  ]
            
            size_t n = num_neighbors;
            MatrixXd A(n + 1, n + 1);
            VectorXd b(n + 1);
            
            // Build Matrix A (Left-hand side: Neighbor-Neighbor covariances)
            for (size_t i = 0; i < n; ++i) {
                const auto& p1 = cloud.pts[ret_index[i]];
                for (size_t j = 0; j <= i; ++j) {
                    const auto& p2 = cloud.pts[ret_index[j]];
                    double dist = std::sqrt(
                        std::pow(p1.x - p2.x, 2) +
                        std::pow(p1.y - p2.y, 2) +
                        std::pow(p1.z - p2.z, 2)
                    );
                    double cov = sill - variogram(dist);
                    A(i, j) = cov;
                    A(j, i) = cov;
                }
                A(i, n) = 1.0;
                A(n, i) = 1.0;
            }
            A(n, n) = 0.0;
            
            // Build Vector b (Right-hand side: Target-Neighbor covariances)
            for (size_t i = 0; i < n; ++i) {
                double dist = std::sqrt(out_dist_sqr[i]);
                b(i) = sill - variogram(dist);
            }
            b(n) = 1.0;
            
            // Solve System
            // Use PartialPivLU for stability with indefinite matrices (OK matrix is indefinite)
            VectorXd x = A.partialPivLu().solve(b);
            
            // Estimate probabilities for each soil code
            std::map<int, double> probabilities;
            
            // Identify unique codes
            std::vector<int> unique_codes;
            for(size_t i=0; i<n; i++) {
                int code = cloud.pts[ret_index[i]].code;
                if(std::find(unique_codes.begin(), unique_codes.end(), code) == unique_codes.end()) {
                    unique_codes.push_back(code);
                }
            }
            
            int best_code = -1;
            double max_prob = -999.0; // Probabilities can be slightly negative due to screening effect
            
            for (int code : unique_codes) {
                double prob = 0.0;
                for (size_t i = 0; i < n; ++i) {
                    // Indicator: 1 if soil type matches, 0 otherwise
                    double indicator = (cloud.pts[ret_index[i]].code == code) ? 1.0 : 0.0;
                    prob += x(i) * indicator;
                }
                
                if (prob > max_prob) {
                    max_prob = prob;
                    best_code = code;
                }
            }
            
            ptr[idx] = best_code;
        }

        return result;
    }
};

// --- PyBind11 Module Definition ---
PYBIND11_MODULE(_voxels, m) {
    py::class_<VoxelModeler>(m, "VoxelModeler")
        .def(py::init<>())
        .def("set_anisotropy", &VoxelModeler::set_anisotropy)
        .def("add_profiles", &VoxelModeler::add_profiles)
        .def("build", &VoxelModeler::build)
        .def("generate", &VoxelModeler::generate);
}
