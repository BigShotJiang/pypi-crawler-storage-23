from breinbaas.helpers.coordinate_conversion import xy_to_lat_lon
from typing import Tuple
from pydantic import BaseModel
import math
import numpy as np
from shapely.geometry import LineString, Polygon


class ReferenceLine(BaseModel):
    name: str = ""
    xy_points: list[tuple[float, float]] = []
    cxy_points: list[tuple[float, float]] = []

    @property
    def length(self):
        return max([cxy_point[0] for cxy_point in self.cxy_points])

    @property
    def mid_point(self):
        if len(self.cxy_points) == 0:
            raise ValueError("Reference line has no points")
        xs = [p[1] for p in self.cxy_points]
        ys = [p[2] for p in self.cxy_points]
        return (sum(xs) / len(xs), sum(ys) / len(ys))

    @classmethod
    def from_xy_points(
        cls,
        name: str,
        xy_points: list[tuple[float, float]],
        grid_distance: float = 10.0,
    ):
        result = ReferenceLine(name=name, xy_points=xy_points)
        result.cxy_points = result.to_cxy_points(grid_distance)
        return result

    def to_cxy_points(self, grid_distance: float = 10.0):
        cxy_points, current_chainage = [], 0
        for i in range(1, len(self.xy_points)):
            p1 = self.xy_points[i - 1]
            p2 = self.xy_points[i]
            current_chainage += math.sqrt((p2[0] - p1[0]) ** 2 + (p2[1] - p1[1]) ** 2)

            if i == 1:
                cxy_points.append((0, p1[0], p1[1]))
            cxy_points.append((current_chainage, p2[0], p2[1]))

        final_cxy_points = []
        for c in np.arange(0, current_chainage + grid_distance / 2, grid_distance):
            for i in range(1, len(cxy_points)):
                c1, x1, y1 = cxy_points[i - 1]
                c2, x2, y2 = cxy_points[i]
                if c1 <= c <= c2:
                    x = x1 + (x2 - x1) * (c - c1) / (c2 - c1)
                    y = y1 + (y2 - y1) * (c - c1) / (c2 - c1)
                    final_cxy_points.append((float(c), float(x), float(y)))
                    break

        return final_cxy_points

    def closest_point_to_xy(
        self, x: float, y: float, max_distance: float = 1e9
    ) -> Tuple[float, float, float]:
        min_distance = float("inf")
        closest_point = None
        for c1, x1, y1 in self.cxy_points:
            distance = math.sqrt((x - x1) ** 2 + (y - y1) ** 2)
            if distance < min_distance and distance <= max_distance:
                min_distance = distance
                closest_point = (c1, x1, y1)
        return closest_point

    def to_shapely_linestring(self) -> LineString:
        return LineString(self.xy_points)

    def buffer(self, distance: float) -> Polygon:
        return self.to_shapely_linestring().buffer(distance)

    def limits(self, margin: float = 0.0):
        """Return the limits of the reference line in X and Y coordinates as xmin, xmax, ymin, ymax."""
        return (
            min(self.xy_points, key=lambda x: x[0])[0] - margin,
            max(self.xy_points, key=lambda x: x[0])[0] + margin,
            min(self.xy_points, key=lambda x: x[1])[1] - margin,
            max(self.xy_points, key=lambda x: x[1])[1] + margin,
        )
