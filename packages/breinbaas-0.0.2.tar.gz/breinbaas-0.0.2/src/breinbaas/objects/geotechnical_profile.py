from shapely import Point
from typing import List, Optional
import math
from pydantic import BaseModel
import folium

from .reference_line import ReferenceLine
from .cpt import Cpt
from ..databases.cpt_database import CptDatabase
from ..helpers.coordinate_conversion import xy_to_lat_lon


class GeotechnicalProfileCpt(BaseModel):
    cpt: Cpt
    distance: float
    chainage: float

    @classmethod
    def from_cpt(cls, cpt: Cpt, distance: float, chainage: float):
        return cls(
            cpt=cpt,
            distance=distance,
            chainage=chainage,
        )


class GeotechnicalProfile(BaseModel):
    name: str = ""
    reference_line: ReferenceLine = None
    profile_cpts: List[GeotechnicalProfileCpt] = []

    @classmethod
    def from_reference_line(
        cls,
        name: str,
        reference_line: ReferenceLine,
        cpt_database: Optional[CptDatabase] = None,
        cpt_files: Optional[List[str]] = None,
        cpts: Optional[List[Cpt]] = None,
        max_cpt_distance: float = 100,
    ):
        filtered_cpts = []
        geotechnical_profile = cls(name=name, reference_line=reference_line)

        polygon = reference_line.buffer(max_cpt_distance)

        if cpt_database:
            filtered_cpts = cpt_database.get_cpts_in_polygon(polygon)
        elif cpt_files:
            for cpt_file in cpt_files:
                cpt = Cpt.from_xml(cpt_file)
                if polygon.contains(Point(cpt.x, cpt.y)):
                    filtered_cpts.append(cpt)
        elif cpts:
            for cpt in cpts:
                if polygon.contains(Point(cpt.x, cpt.y)):
                    filtered_cpts.append(cpt)

        for cpt in filtered_cpts:
            closest_point = reference_line.closest_point_to_xy(cpt.x, cpt.y)

            if closest_point:
                closest_chainage, closest_x, closest_y = closest_point
                distance = math.sqrt(
                    (cpt.x - closest_x) ** 2 + (cpt.y - closest_y) ** 2
                )

                geotechnical_profile.profile_cpts.append(
                    GeotechnicalProfileCpt.from_cpt(
                        cpt, distance=distance, chainage=closest_chainage
                    )
                )

        geotechnical_profile.profile_cpts.sort(key=lambda x: x.chainage)

        return geotechnical_profile

    @property
    def metadata(self):
        return {
            "length": self.reference_line.length,
            "cpt_zmax": max([profile_cpt.cpt.top for profile_cpt in self.profile_cpts]),
            "cpt_zmin": min(
                [profile_cpt.cpt.bottom for profile_cpt in self.profile_cpts]
            ),
        }

    @property
    def length(self):
        return self.reference_line.length

    def to_folium(self, to_html_file: str = None):
        xmin, xmax, ymin, ymax = self.reference_line.limits(margin=50)
        p1, p2 = xy_to_lat_lon([(xmin, ymax), (xmax, ymin)])

        lat_mid = (p1[0] + p2[0]) / 2.0
        lon_mid = (p1[1] + p2[1]) / 2.0

        m = folium.Map(location=(lat_mid, lon_mid))
        m.fit_bounds([[p1[0], p1[1]], [p2[0], p2[1]]])

        for profile_cpt in self.profile_cpts:
            lat, lon = xy_to_lat_lon([(profile_cpt.cpt.x, profile_cpt.cpt.y)])[0]
            folium.CircleMarker(
                location=(lat, lon),
                radius=5,
                color="red",
                fill=True,
                fill_color="red",
                tooltip=profile_cpt.cpt.name,
            ).add_to(m)

        latlon_reference_line = xy_to_lat_lon(self.reference_line.xy_points)
        folium.PolyLine(
            latlon_reference_line,
            color="blue",
            weight=2,
            opacity=1,
        ).add_to(m)

        if to_html_file:
            m.save(to_html_file)
