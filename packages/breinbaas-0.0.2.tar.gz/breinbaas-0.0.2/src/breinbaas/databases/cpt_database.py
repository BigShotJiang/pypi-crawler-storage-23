from typing import Tuple, List
import csv
from shapely.geometry import Polygon, Point
from typing import Optional
import sqlite3
import glob
import os
from pathlib import Path
import brodata
from tqdm import tqdm

from ..objects.cpt import Cpt

CPT_FILES_LOCATION = "/home/breinbaas/Documents/Breinbaas/Algemeen/sonderingen/data"
CPT_DATABASE = (
    "/home/breinbaas/Documents/Breinbaas/Algemeen/sonderingen/cpt_database.db"
)
CPT_DATABASE_CSV = (
    "/home/breinbaas/Documents/Breinbaas/Algemeen/sonderingen/cpt_database.csv"
)
DEFAULT_MAX_CPT_DISTANCE = 100  # m


class NoCptFoundError(Exception):
    pass


class CptDatabase:

    def __init__(self, db_path=CPT_DATABASE):
        self.db_path = db_path
        self.conn = sqlite3.connect(self.db_path)
        self.cursor = self.conn.cursor()
        self._create_table()

    def _create_table(self):
        self.cursor.execute(
            """
            CREATE TABLE IF NOT EXISTS cpt_files (
                id TEXT PRIMARY KEY,
                x REAL,
                y REAL,
                z REAL,
                date TEXT,
                length REAL,
                file_path TEXT UNIQUE
            )
        """
        )
        self.conn.commit()

    def add_from_directory(self, directory: str, new_database: bool = False):
        """
        Finds all xml files in the given directory using glob and adds them to the database.
        """
        # Finds all xml files in the directory
        xml_files = glob.glob(os.path.join(directory, "*.xml"))

        if Path(self.db_path).exists() and new_database:
            os.remove(self.db_path)
            self.conn = sqlite3.connect(self.db_path)
            self.cursor = self.conn.cursor()
            self._create_table()

        for xml_file in tqdm(xml_files):
            # Add to database if not check is handled here
            if not self._file_exists(xml_file):
                try:
                    # User to implement extraction logic here
                    file_id, x, y, z, date, cpt_length = self._extract_info(xml_file)

                    self._insert_record(
                        file_id, x, y, float(z), date, float(cpt_length), xml_file
                    )
                    # print(f"Added {xml_file} to database.")
                except Exception as e:
                    print(f"Error processing {xml_file}: {e}")
            else:
                # print(f"File {xml_file} already exists in database.")
                pass

    def _file_exists(self, xml_path):
        self.cursor.execute("SELECT 1 FROM cpt_files WHERE file_path = ?", (xml_path,))
        return self.cursor.fetchone() is not None

    def _insert_record(self, file_id, x, y, z, date, cpt_length, xml_path):
        self.cursor.execute(
            """
            INSERT INTO cpt_files (id, x, y, z, date, length, file_path)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """,
            (file_id, x, y, z, date, cpt_length, xml_path),
        )
        self.conn.commit()

    def _extract_info(self, xml_path):
        """
        Extracts id, x, and y, z, date and length from the xml file.
        """
        bro_cpt = brodata.cpt.ConePenetrationTest(xml_path)

        dt = bro_cpt.conePenetrationTest_phenomenonTime
        date_string = dt.strftime("%Y-%m-%d")
        return (
            bro_cpt.broId,
            bro_cpt.deliveredLocation.x,
            bro_cpt.deliveredLocation.y,
            bro_cpt.offset,
            date_string,
            bro_cpt.finalDepth,
        )

    def close(self):
        self.conn.close()

    def get_by_id(self, id: str) -> Cpt:
        self.cursor.execute("SELECT file_path FROM cpt_files WHERE id = ?", (id,))
        result = self.cursor.fetchone()

        if result is None:
            raise NoCptFoundError(f"No CPT found with id {id}")

        xml_path = result[0]
        if Path(xml_path).exists():
            return Cpt.from_xml(xml_path)
        else:
            raise NoCptFoundError(f"File {xml_path} does not exist.")

    def get_closest_cpt(
        self, x: float, y: float, max_distance: float = DEFAULT_MAX_CPT_DISTANCE
    ) -> Tuple[Cpt, float]:
        # create a selection within a box of max_distance around x, y
        x_min = x - max_distance
        x_max = x + max_distance
        y_min = y - max_distance
        y_max = y + max_distance

        self.cursor.execute(
            """
            SELECT * FROM cpt_files 
            WHERE x BETWEEN ? AND ? AND y BETWEEN ? AND ? 
            ORDER BY (x - ?) * (x - ?) + (y - ?) * (y - ?) ASC 
            LIMIT 1
            """,
            (x_min, x_max, y_min, y_max, x, x, y, y),
        )
        result = self.cursor.fetchone()

        if result is None:
            raise NoCptFoundError(
                f"No CPT found closest to x={x} and y={y} and max_distance={max_distance}"
            )

        x_cpt = result[1]
        y_cpt = result[2]
        distance = ((x - x_cpt) ** 2 + (y - y_cpt) ** 2) ** 0.5
        xml_path = result[6]
        if Path(xml_path).exists():
            return Cpt.from_xml(xml_path), distance
        else:
            raise FileNotFoundError(f"File {xml_path} does not exist.")

    def to_csv(self, file_path: str):
        self.cursor.execute("SELECT id, x, y, z, date, length FROM cpt_files")
        results = self.cursor.fetchall()
        with open(file_path, "w") as f:
            writer = csv.writer(f)
            writer.writerow(["id", "x", "y", "z", "date", "length"])
            writer.writerows(results)

    def get_cpts_in_polygon(self, polygon: Polygon) -> List[Cpt]:
        x_min, y_min, x_max, y_max = polygon.bounds
        self.cursor.execute(
            """
            SELECT * FROM cpt_files 
            WHERE x BETWEEN ? AND ? AND y BETWEEN ? AND ?
            """,
            (x_min, x_max, y_min, y_max),
        )
        results = self.cursor.fetchall()

        cpts = []
        for result in results:
            x_cpt = result[1]
            y_cpt = result[2]
            if polygon.contains(Point(x_cpt, y_cpt)):
                xml_path = result[6]
                if Path(xml_path).exists():
                    cpts.append(Cpt.from_xml(xml_path))
                else:
                    # Log or handle missing file
                    pass
        return cpts

    def get_cpts_ids_in_polygon(self, polygon: Polygon) -> List[str]:
        x_min, y_min, x_max, y_max = polygon.bounds
        self.cursor.execute(
            """
            SELECT id, x, y FROM cpt_files 
            WHERE x >= ? AND x <= ? AND y >= ? AND y <= ?
            """,
            (x_min, x_max, y_min, y_max),
        )
        results = self.cursor.fetchall()

        ids = []
        for result in results:
            if polygon.contains(Point(result[1], result[2])):
                ids.append(result[0])

        return ids
