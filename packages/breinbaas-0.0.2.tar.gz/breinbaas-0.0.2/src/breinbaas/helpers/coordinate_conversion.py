from typing import List, Tuple
from pyproj import Transformer


def xy_to_lat_lon(xys: List[Tuple[float, float]]) -> List[Tuple[float, float]]:
    transformer = Transformer.from_crs("epsg:28992", "epsg:4326", always_xy=True)
    xs = [p[0] for p in xys]
    ys = [p[1] for p in xys]
    lons, lats = transformer.transform(xs, ys)
    return list(zip(lats, lons))
