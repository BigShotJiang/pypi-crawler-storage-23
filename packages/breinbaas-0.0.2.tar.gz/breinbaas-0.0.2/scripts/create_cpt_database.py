from breinbaas.databases.cpt_database import (
    CptDatabase,
    CPT_FILES_LOCATION,
    CPT_DATABASE_CSV,
)

cpt_database = CptDatabase()
cpt_database.add_from_directory(CPT_FILES_LOCATION, new_database=False)
cpt_database.to_csv(CPT_DATABASE_CSV)
cpt_database.close()
