## Werkwijze nieuwe tag

* git tag v0.1.0 && git push origin v0.1.0

## Werkwijze bestaande tag

* git tag -f v0.1.0 && git push origin v0.1.0 -f
