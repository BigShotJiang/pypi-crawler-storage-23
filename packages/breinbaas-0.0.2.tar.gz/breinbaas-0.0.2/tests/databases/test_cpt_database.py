from shapely import Polygon
import pytest
import os

from breinbaas.databases.cpt_database import CptDatabase, NoCptFoundError


@pytest.mark.skipif(
    os.environ.get("GITHUB_ACTIONS") == "true",
    reason="Local database not available in CI",
)
class TestCptDatabase:
    def test_get_by_invalid_id(self):
        cpt_database = CptDatabase()
        with pytest.raises(NoCptFoundError):
            cpt_database.get_by_id("NO_CPT_WITH_THIS_ID")
        cpt_database.close()

    def test_get_by_valid_id(self):
        cpt_database = CptDatabase()
        cpt = cpt_database.get_by_id("CPT000000109922")
        cpt_database.close()
        assert cpt.name == "CPT000000109922"

    def test_get_closest_cpt(self):
        cpt_database = CptDatabase()
        cpt, distance = cpt_database.get_closest_cpt(114963, 482087)
        cpt_database.close()
        assert cpt.name == "CPT000000076079"
        assert distance == pytest.approx(0.08944271909218221)

    def test_get_closest_cpt_with_max_distance(self):
        cpt_database = CptDatabase()
        with pytest.raises(NoCptFoundError):
            cpt_database.get_closest_cpt(114962, 482086, max_distance=1.0)
        cpt_database.close()

    def test_get_cpts_ids_in_polygon(self):
        cpt_database = CptDatabase()
        polygon = Polygon(
            [(140572, 490789), (140618, 490789), (140618, 490734), (140572, 490734)]
        )
        ids = cpt_database.get_cpts_ids_in_polygon(polygon)
        cpt_database.close()
        assert "CPT000000106468" in ids
        assert "CPT000000106464" in ids

    def test_to_csv(self):
        cpt_database = CptDatabase()
        cpt_database.to_csv("tests/testdata/output/database/cpt_database.csv")
        cpt_database.close()
        assert os.path.exists("tests/testdata/output/database/cpt_database.csv")
