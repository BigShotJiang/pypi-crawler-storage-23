import pytest
from breinbaas.objects.soil_profile import SoilProfile
from breinbaas.objects.soil_layer import SoilLayer
from breinbaas.voxels.kriging import generate_voxel_model


def test_generate_voxel_model():
    # Create simple profiles
    p1 = SoilProfile(
        x=0,
        y=0,
        soil_layers=[
            SoilLayer(top=0, bottom=-5, soil_code="SAND"),
            SoilLayer(top=-5, bottom=-10, soil_code="CLAY"),
        ],
    )
    p2 = SoilProfile(
        x=10,
        y=0,
        soil_layers=[
            SoilLayer(top=0, bottom=-5, soil_code="SAND"),
            SoilLayer(top=-5, bottom=-10, soil_code="CLAY"),
        ],
    )

    profiles = [p1, p2]

    # Generate model for a point in between
    voxels = generate_voxel_model(
        profiles,
        x_min=0,
        x_max=10,
        dx=5.0,
        y_min=0,
        y_max=1,
        dy=1.0,
        z_min=-10,
        z_max=0,
        dz=1.0,
        range_=20.0,
    )

    assert len(voxels) > 0

    # Check a voxel at the top (should be SAND)
    top_voxels = [v for v in voxels if v["z"] > -5]
    for v in top_voxels:
        assert v["soil_code"] == "SAND"

    # Check a voxel at the bottom (should be CLAY)
    bottom_voxels = [v for v in voxels if v["z"] < -5]
    for v in bottom_voxels:
        assert v["soil_code"] == "CLAY"
