from breinbaas.objects.geotechnical_profile import GeotechnicalProfile
from breinbaas.objects.reference_line import ReferenceLine
from breinbaas.databases.cpt_database import CptDatabase
from breinbaas.objects.cpt import Cpt


import pytest
import os


@pytest.mark.skipif(
    os.environ.get("GITHUB_ACTIONS") == "true",
    reason="Tests using local CptDatabase skipped in CI",
)
class TestGeotechnicalProfile:
    def setup_method(self):
        self.reference_line = ReferenceLine.from_xy_points(
            name="test",
            xy_points=[
                [113202, 471163],
                [113236, 471224],
                [113294, 471250],
                [113364, 471264],
            ],
            grid_distance=10,
        )
        self.cpt_database = CptDatabase()
        self.geotechnical_profile = GeotechnicalProfile.from_reference_line(
            name="test",
            reference_line=self.reference_line,
            max_cpt_distance=10.0,
            cpt_database=self.cpt_database,
        )

    def test_from_reference_line(self):
        assert self.geotechnical_profile.reference_line == self.reference_line
        assert len(self.geotechnical_profile.profile_cpts) == 3

    @pytest.mark.skipif(
        os.environ.get("GITHUB_ACTIONS") == "true",
        reason="Output writing tests skipped in CI",
    )
    def test_to_folium(self):
        self.geotechnical_profile.to_folium(
            to_html_file="tests/testdata/output/plots/profile.html"
        )

    def test_metadata(self):
        assert self.geotechnical_profile.metadata["length"] == 200.0
        assert self.geotechnical_profile.metadata["cpt_zmax"] == -1.198
        assert self.geotechnical_profile.metadata["cpt_zmin"] == -17.936

    def test_from_cpt_files(self):
        geotechnical_profile = GeotechnicalProfile.from_reference_line(
            name="test",
            reference_line=self.reference_line,
            max_cpt_distance=10.0,
            cpt_files=[
                "tests/testdata/cpts/CPT000000078395.xml",
                "tests/testdata/cpts/CPT000000078397.xml",
                "tests/testdata/cpts/CPT000000078419.xml",
            ],
        )
        assert len(geotechnical_profile.profile_cpts) == 3

    def test_from_cpts(self):
        cpts = []
        for cpt_file in [
            "tests/testdata/cpts/CPT000000078395.xml",
            "tests/testdata/cpts/CPT000000078397.xml",
            "tests/testdata/cpts/CPT000000078419.xml",
        ]:
            cpts.append(Cpt.from_xml(cpt_file))

        geotechnical_profile = GeotechnicalProfile.from_reference_line(
            name="test",
            reference_line=self.reference_line,
            max_cpt_distance=10.0,
            cpts=cpts,
        )
        assert len(geotechnical_profile.profile_cpts) == 3

    def teardown_method(self):
        self.cpt_database.close()
