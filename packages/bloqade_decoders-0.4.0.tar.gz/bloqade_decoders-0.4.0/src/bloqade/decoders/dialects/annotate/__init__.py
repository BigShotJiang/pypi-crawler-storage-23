from . import stmts as stmts, types as types
from ._dialect import dialect as dialect
from ._interface import set_detector as set_detector, set_observable as set_observable
