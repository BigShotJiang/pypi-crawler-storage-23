"""Code Reviewer - AI-powered code review for GitHub and GitLab.

This package provides automated code review using a multi-agent pipeline
with tool-augmented codebase exploration for verification.
"""

import os as _os

# Prevent litellm (or any dep) from silently loading .env files when running
# as an installed binary.  The dev path (uv run python main.py) sets
# _REVIEWATE_DOTENV_OK=1 and calls load_dotenv() explicitly before this runs.
if not _os.environ.get("_REVIEWATE_DOTENV_OK"):
    import dotenv as _dotenv

    _dotenv.load_dotenv = lambda *a, **kw: False  # type: ignore[assignment]

from importlib.metadata import PackageNotFoundError as _PNF
from importlib.metadata import version as _version

try:
    __version__ = _version("reviewate")
except _PNF:
    __version__ = "0.0.0-dev"
