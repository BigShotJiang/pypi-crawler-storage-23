"""GitLab-specific repository schemas."""

from typing import Annotated, Any

from pydantic import BaseModel, ConfigDict, Field


class GitLabMergeRequest(BaseModel):
    """GitLab Merge Request model (raw API response)."""

    iid: Annotated[int, Field(description="Internal merge request ID")]
    project_id: Annotated[int, Field(description="Project ID")]
    title: Annotated[str, Field(description="Merge request title")]
    description: Annotated[str | None, Field(description="Merge request description")] = None
    state: Annotated[str, Field(description="Merge request state (opened, closed, merged)")]
    source_branch: Annotated[str, Field(description="Source branch name")]
    target_branch: Annotated[str, Field(description="Target branch name")]
    sha: Annotated[str, Field(description="HEAD commit SHA")]
    author: Annotated[dict[str, Any], Field(description="Author information")]


class GitLabReviewComment(BaseModel):
    """GitLab review comment format for LLM output.

    This schema is used by agents to generate structured review comments.
    The adaptor will add SHAs and other metadata when posting.
    """

    model_config = ConfigDict(extra="forbid")

    body: Annotated[str, Field(description="The review comment body (supports markdown)")]
    new_path: Annotated[
        str | None,
        Field(
            description="Relative file path from the diff header (e.g. 'src/main.rs'). Required for inline comments on added/modified lines."
        ),
    ] = None
    new_line: Annotated[
        int | None,
        Field(
            description="Line number in the new file. Read directly from the diff: added lines show '      N   :+' (use N). Required for inline comments on new code — never leave as null."
        ),
    ] = None
    old_path: Annotated[
        str | None,
        Field(
            description="Old file path (for renamed/deleted files). Only needed when commenting on deleted lines."
        ),
    ] = None
    old_line: Annotated[
        int | None,
        Field(
            description="Line number in the old file. Read directly from the diff: deleted lines show 'N         :-' (use N). Only needed when commenting on deleted code."
        ),
    ] = None
