from faststream.kafka.opentelemetry.middleware import KafkaTelemetryMiddleware

__all__ = ("KafkaTelemetryMiddleware",)
