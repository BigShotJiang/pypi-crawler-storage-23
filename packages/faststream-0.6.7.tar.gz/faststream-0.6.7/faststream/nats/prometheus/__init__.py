from faststream.nats.prometheus.middleware import NatsPrometheusMiddleware

__all__ = ("NatsPrometheusMiddleware",)
