from faststream.confluent.schemas.partition import TopicPartition

__all__ = ("TopicPartition",)
