from faststream.confluent.prometheus.middleware import KafkaPrometheusMiddleware

__all__ = ("KafkaPrometheusMiddleware",)
