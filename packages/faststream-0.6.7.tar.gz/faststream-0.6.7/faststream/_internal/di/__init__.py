from .config import FastDependsConfig

__all__ = ("FastDependsConfig",)
