from faststream.specification.asyncapi.v2_6_0.schema import Contact

__all__ = ("Contact",)
