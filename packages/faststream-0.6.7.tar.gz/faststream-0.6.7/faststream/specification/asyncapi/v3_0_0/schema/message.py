from faststream.specification.asyncapi.v2_6_0.schema.message import (
    CorrelationId,
    Message,
)

__all__ = ("CorrelationId", "Message")
