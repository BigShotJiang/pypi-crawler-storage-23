from .generate import get_app_schema

__all__ = ("get_app_schema",)
