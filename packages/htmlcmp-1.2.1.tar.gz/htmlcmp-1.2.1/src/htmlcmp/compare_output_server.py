#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import io
import sys
import shutil
import argparse
import logging
import threading
import functools
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

from flask import Flask, send_from_directory, send_file
import watchdog.observers
import watchdog.events

from htmlcmp.compare_output import comparable_file, compare_files
from htmlcmp.html_render_diff import get_browser, html_render_diff

logger = logging.getLogger(__name__)


class Config:
    path_a: Path = None
    path_b: Path = None
    driver: str = None
    observer = None
    comparator = None
    browser = None
    thread_local = threading.local()
    log_file: Path = None


def result_symbol(result: str) -> str | None:
    if not isinstance(result, str):
        raise TypeError("Result must be of type str")

    if result == "pending":
        return "🔄"
    if result == "same":
        return "✔"
    if result == "different":
        return "❌"
    return None


def result_css(result: str) -> str | None:
    if not isinstance(result, str):
        raise TypeError("Result must be of type str")

    if result == "pending":
        return "color:blue;"
    if result == "same":
        return "color:green;"
    if result == "different":
        return "color:red;"
    return None


class Observer:
    def __init__(self):
        class Handler(watchdog.events.FileSystemEventHandler):
            def __init__(self, path):
                self._path = path

            def dispatch(self, event):
                event_type = event.event_type
                src_path = Path(event.src_path)

                logger.debug(f"Watchdog event: {event_type} {src_path}")

                if event_type not in ["moved", "deleted", "created", "modified"]:
                    return

                if src_path.is_file():
                    logger.debug(
                        f"Submit watchdog file change: {event_type} {src_path}"
                    )
                    Config.comparator.submit(src_path.relative_to(self._path))

        logger.info("Create watchdog for paths:")
        logger.info(f"  A: {Config.path_a}")
        logger.info(f"  B: {Config.path_b}")

        self._observer = watchdog.observers.Observer()
        self._observer.schedule(Handler(Config.path_a), Config.path_a, recursive=True)
        self._observer.schedule(Handler(Config.path_b), Config.path_b, recursive=True)

    def start(self) -> None:
        logger.info("Starting watchdog observer")
        self._observer.start()

        def init_compare(a: Path, b: Path):
            logger.debug(f"Initial compare: {a} vs {b}")

            if not isinstance(a, Path) or not isinstance(b, Path):
                raise TypeError("Paths must be of type Path")
            if not a.is_dir() or not b.is_dir():
                raise ValueError("Both paths must be directories")

            common_path = a.relative_to(Config.path_a)

            left = sorted(p.name for p in a.iterdir())
            right = sorted(p.name for p in b.iterdir())

            common = [name for name in left if name in right]

            for name in common:
                if (a / name).is_file() and comparable_file(a / name):
                    logger.debug(
                        f"Submit initial file comparison: {common_path / name}"
                    )
                    Config.comparator.submit(common_path / name)
                elif (a / name).is_dir():
                    init_compare(a / name, b / name)

        logger.info("Kick off initial comparison of all files")
        init_compare(Config.path_a, Config.path_b)
        logger.info("Initial comparison submitted")

    def stop(self) -> None:
        logger.info("Stopping watchdog observer")
        self._observer.stop()

    def join(self) -> None:
        logger.info("Joining watchdog observer")
        self._observer.join()


class Comparator:
    def __init__(self, max_workers: int):
        def initializer():
            if Config.driver is not None:
                browser = getattr(Config.thread_local, "browser", None)
                if browser is None:
                    browser = get_browser(driver=Config.driver)
                    Config.thread_local.browser = browser

        logger.info(f"Creating comparator with {max_workers} workers")

        self._executor = ThreadPoolExecutor(
            max_workers=max_workers, initializer=initializer
        )
        self._result = {}
        self._future = {}

    def submit(self, path: Path) -> None:
        logger.debug(f"Submitting comparison for path: {path}")

        if not isinstance(path, Path):
            raise TypeError("Path must be of type Path")

        if path.suffix.lower() in [".html", ".htm"] and Config.driver is None:
            logger.debug(f"Skipping submission of HTML file without browser: {path}")
            return

        if path in self._future:
            try:
                self._future[path].cancel()
                self._future[path].result()
                self._future.pop(path)
            except Exception:
                pass

        self._result[path] = "pending"
        self._future[path] = self._executor.submit(self.compare, path)

    def compare(self, path: Path) -> None:
        logger.debug(f"Comparing files for path: {path}")

        if not isinstance(path, Path):
            raise TypeError("Path must be of type Path")
        if path not in self._future:
            raise RuntimeError("Path not submitted for comparison")

        browser = getattr(Config.thread_local, "browser", None)
        result = compare_files(
            Config.path_a / path,
            Config.path_b / path,
            browser=browser,
        )
        self._result[path] = "same" if result else "different"
        self._future.pop(path)

    def result(self, path: Path) -> str | None:
        logger.debug(f"Getting comparison result for path: {path}")

        if not isinstance(path, Path):
            raise TypeError("Path must be of type Path")

        if path in self._result:
            return self._result[path]

        if (Config.path_a / path).is_dir():
            a = Config.path_a / path
            b = Config.path_b / path

            left = sorted(p.name for p in a.iterdir())
            right = sorted(p.name for p in b.iterdir())

            left_relevant = sorted(
                [
                    name
                    for name in left
                    if (a / name).is_dir()
                    or ((a / name).is_file() and comparable_file(a / name))
                ]
            )
            right_relevant = sorted(
                [
                    name
                    for name in right
                    if (b / name).is_dir()
                    or ((b / name).is_file() and comparable_file(b / name))
                ]
            )

            common = [name for name in left_relevant if name in right_relevant]
            left_missing = [
                name for name in right_relevant if name not in left_relevant
            ]
            right_missing = [
                name for name in left_relevant if name not in right_relevant
            ]

            return functools.reduce(
                lambda a, b: (
                    None
                    if None in (a, b)
                    else (
                        "pending"
                        if "pending" in (a, b)
                        else "different" if "different" in (a, b) else "same"
                    )
                ),
                [self.result(path / name) for name in common]
                + [
                    (
                        "different"
                        if len(left_missing) + len(right_missing) > 0
                        else "same"
                    )
                ],
                "same",
            )

        logger.debug(f"No comparison result for path: {path}")
        return None


app = Flask("compare")


@app.route("/script.js")
def script_js():
    logger.debug("Serving script.js")

    return """
function updateRef(path) {
  fetch(`/update_ref/${path}`)
    .then(response => {
      if (response.ok) {
        alert(`Reference updated for ${path}`);
        location.reload();
      } else {
        alert(`Failed to update reference for ${path}: ${response.statusText}`);
      }
    })
    .catch(error => {
      alert(`Error updating reference for ${path}: ${error}`);
    });
}
"""


@app.route("/")
def root():
    logger.debug("Generating root directory listing")

    current_entry_id = 0

    def next_entry_id() -> int:
        nonlocal current_entry_id
        entry_id = current_entry_id
        current_entry_id += 1
        return entry_id

    def generate_entry(
        entry_id: int,
        parrent_id: int | None,
        depth: int,
        is_directory: bool,
        is_comparable: bool,
        path: Path,
        name: str,
        message: str = "",
        cmp_result: str = None,
    ) -> str:
        result = ""

        if cmp_result is None and Config.comparator is not None:
            cmp_result = Config.comparator.result(path)
        is_hidden = (
            Config.comparator is not None
            and Config.comparator.result(path.parent) == "same"
        )
        is_collapsed = cmp_result == "same"

        hidden_str = "hidden" if is_hidden else ""
        result += f'<tr data-entry-id="{entry_id}" data-parent-id="{"" if parrent_id is None else parrent_id}" data-depth="{depth}" {hidden_str}>'

        if is_directory:
            result += f'<td><button class="toggle">{"▶" if is_collapsed else "▼"}</button></td>'
        else:
            result += "<td></td>"

        if is_comparable:
            main = f'<a href="/compare/{path}" target="_blank">{name}</a>'
        else:
            main = f"{name}"
        if cmp_result is not None:
            status = result_symbol(cmp_result)
            style = result_css(cmp_result)
            result += f'<td style="{style}">{status}</td>'
        else:
            style = ""
            result += f"<td></td>"
        result += f'<td class="main" style="{style}">{main}</td>'
        result += f"<td>{message}</td>"

        result += (
            f"<td><button onclick=\"updateRef('{path}')\">update ref</button></td>"
        )

        result += "</tr>"

        return result

    def generate_tree(
        a: Path, b: Path, name: str, parrent_id: int | None, depth: int
    ) -> str:
        result = ""

        if not isinstance(a, Path) or not isinstance(b, Path):
            raise TypeError("Paths must be of type Path")
        if not a.is_dir() or not b.is_dir():
            raise ValueError("Both paths must be directories")

        common_path = a.relative_to(Config.path_a)

        directory_id = next_entry_id()
        result += generate_entry(
            directory_id,
            parrent_id,
            depth,
            True,
            False,
            common_path,
            name + "/",
        )

        left = sorted(p.name for p in a.iterdir())
        right = sorted(p.name for p in b.iterdir())

        left_files = sorted(
            [
                name
                for name in left
                if (a / name).is_file() and comparable_file(a / name)
            ]
        )
        right_files = sorted(
            [
                name
                for name in right
                if (b / name).is_file() and comparable_file(b / name)
            ]
        )

        left_dirs = sorted([name for name in left if (a / name).is_dir()])
        right_dirs = sorted([name for name in right if (b / name).is_dir()])

        common_files = [name for name in left_files if name in right_files]
        common_dirs = [name for name in left_dirs if name in right_dirs]

        left_files_missing = [name for name in right_files if name not in left_files]
        right_files_missing = [name for name in left_files if name not in right_files]
        left_dirs_missing = [name for name in right_dirs if name not in left_dirs]
        right_dirs_missing = [name for name in left_dirs if name not in right_dirs]
        for name in left_files_missing:
            result += generate_entry(
                next_entry_id(),
                directory_id,
                depth + 1,
                False,
                False,
                common_path / name,
                name,
                "file missing in A",
                cmp_result="different",
            )
        for name in right_files_missing:
            result += generate_entry(
                next_entry_id(),
                directory_id,
                depth + 1,
                False,
                False,
                common_path / name,
                name,
                "file missing in B",
                cmp_result="different",
            )
        for name in left_dirs_missing:
            result += generate_entry(
                next_entry_id(),
                directory_id,
                depth + 1,
                False,
                False,
                common_path / name,
                name + "/",
                "dir missing in A",
                cmp_result="different",
            )
        for name in right_dirs_missing:
            result += generate_entry(
                next_entry_id(),
                directory_id,
                depth + 1,
                False,
                False,
                common_path / name,
                name + "/",
                "dir missing in B",
                cmp_result="different",
            )

        for name in common_files:
            result += generate_entry(
                next_entry_id(),
                directory_id,
                depth + 1,
                False,
                True,
                common_path / name,
                name,
                "",
            )

        for name in common_dirs:
            result += generate_tree(a / name, b / name, name, directory_id, depth + 1)

        return result

    result = """<!DOCTYPE html>
<html>
<head>
<style>
tr {
  --depth: attr(data-depth number);
}
.main {
  padding-left: calc(1.0rem * var(--depth));
}
</style>
<script src="/script.js"></script>
</head>
<body>
"""

    result += "<p>"
    result += "comparing<br>"
    result += f"Reference: {Config.path_a}<br>"
    result += f"Monitored: {Config.path_b}"
    result += "</p>"

    if Config.log_file is not None:
        result += "<p>"
        result += (
            f'<a href="/logfile" target="_blank">View log file: {Config.log_file}</a>'
        )
        result += "</p>"

    result += "<p>"
    result += '<button onclick="toggleAll(true)">Expand All</button>'
    result += '<button onclick="toggleAll(false)">Collapse All</button>'
    result += "</p>"

    result += "<table>"
    result += "<thead>"
    result += "<tr><td></td><td></td><td>Name</td><td>Message</td><td>Actions</td></tr>"
    result += "</thead>"
    result += "<tbody>"
    result += generate_tree(Config.path_a, Config.path_b, "", None, 0)
    result += "</tbody>"
    result += "</table>"

    result += """
<script>
document.addEventListener("click", e => {
  if (!e.target.classList.contains("toggle")) return;

  const row = e.target.closest("tr");
  const id = row.dataset.entryId;
  const expanded = e.target.textContent === "▼";

  e.target.textContent = expanded ? "▶" : "▼";

  toggleChildren(id, !expanded);
});

function toggleChildren(parentId, show) {
  document.querySelectorAll(`tr[data-parent-id="${parentId}"]`)
    .forEach(child => {
      child.hidden = !show;
      if (!show) {
        toggleChildren(child.dataset.entryId, false);
        const toggle = child.querySelector(".toggle");
        if (toggle) toggle.textContent = "▶";
      }
    });
}

function toggleAll(show) {
  document.querySelectorAll("tr")
    .forEach(row => {
      const isRoot = !row.dataset.parentId;
      row.hidden = !isRoot && !show;
      const toggle = row.querySelector(".toggle");
      if (toggle) {
        toggle.textContent = show ? "▼" : "▶";
      }
    });
}
</script>
</body>
</html>
"""

    return result


@app.route("/logfile")
def logfile():
    logger.debug("Serving log file")

    if Config.log_file is None:
        return "No log file configured", 404

    return send_from_directory(Config.log_file.parent, Config.log_file.name)


@app.route("/compare/<path:path>")
def compare(path: str):
    logger.debug(f"Generating comparison page for path: {path}")

    if not isinstance(path, str):
        raise TypeError("Path must be a string")

    return f"""<!DOCTYPE html>
<html>
<head>
<style>
html,body {{height:100%;margin:0;}}
</style>
<script src="/script.js"></script>
</head>
<body style="display:flex;flex-flow:row;">
<div style="display:flex;flex:1;flex-flow:column;margin:5px;">
  <a href="/file/a/{path}" target="_blank">{Config.path_a / path}</a>
  <iframe id="a" src="/file/a/{path}" title="a" frameborder="0" align="left" style="flex:1;"></iframe>
</div>
<div style="display:flex;flex:0 0 50px;flex-flow:column;">
  <a href="/image_diff/{path}" target="_blank">diff</a>
  <button onclick="updateRef('{path}')">▶</button>
  <img src="/image_diff/{path}" width="50" height="0" style="flex:1;">
</div>
<div style="display:flex;flex:1;flex-flow:column;margin:5px;">
  <a href="/file/b/{path}" target="_blank">{Config.path_b / path}</a>
  <iframe id="b" src="/file/b/{path}" title="b" frameborder="0" align="right" style="flex:1;"></iframe>
</div>
<script>
var iframe_a = document.getElementById('a');
var iframe_b = document.getElementById('b');
iframe_a.contentWindow.addEventListener('scroll', function(event) {{
  iframe_b.contentWindow.scrollTo(iframe_a.contentWindow.scrollX, iframe_a.contentWindow.scrollY);
}});
iframe_b.contentWindow.addEventListener('scroll', function(event) {{
  iframe_a.contentWindow.scrollTo(iframe_b.contentWindow.scrollX, iframe_b.contentWindow.scrollY);
}});
</script>
</body>
</html>
"""


@app.route("/image_diff/<path:path>")
def image_diff(path: str):
    logger.debug(f"Generating image diff for path: {path}")

    if not isinstance(path, str):
        raise TypeError("Path must be a string")

    if Config.driver is None:
        return "Image diff not available without browser driver", 404

    diff, _ = html_render_diff(
        Config.path_a / path,
        Config.path_b / path,
        Config.browser,
    )
    tmp = io.BytesIO()
    diff.save(tmp, "JPEG", quality=70)
    tmp.seek(0)
    return send_file(tmp, mimetype="image/jpeg")


@app.route("/file/<variant>/<path:path>")
def file(variant: str, path: str):
    logger.debug(f"Serving file for variant: {variant}, path: {path}")

    if not isinstance(variant, str) or not isinstance(path, str):
        raise TypeError("Variant and path must be strings")
    if variant not in ["a", "b"]:
        raise ValueError("Variant must be 'a' or 'b'")

    variant_root = Config.path_a if variant == "a" else Config.path_b
    return send_from_directory(variant_root, path)


@app.route("/update_ref/<path:path>")
def update_ref(path: str):
    logger.debug(f"Updating reference for path: {path}")

    if not isinstance(path, str):
        raise TypeError("Path must be a string")

    src = Config.path_b / path
    dst = Config.path_a / path

    if not src.exists():
        return f"Source file does not exist: {src}", 404

    if src.is_file():
        shutil.copy2(src, dst)
    else:
        shutil.copytree(src, dst, dirs_exist_ok=True)

    return "Reference updated", 200


def verbosity_to_level(verbosity: int) -> int:
    if verbosity >= 3:
        return logging.DEBUG
    elif verbosity == 2:
        return logging.INFO
    elif verbosity == 1:
        return logging.WARNING
    else:
        return logging.ERROR


def setup_logging(
    verbosity: int, log_file: Path = None, log_file_verbosity: int = None
) -> None:
    level = verbosity_to_level(verbosity)

    root_logger = logging.getLogger()
    root_logger.setLevel(level)
    root_logger.handlers.clear()

    formatter = logging.Formatter(
        fmt="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
    )

    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setLevel(level)
    console_handler.setFormatter(formatter)
    root_logger.addHandler(console_handler)

    if log_file is not None:
        file_level = (
            verbosity_to_level(log_file_verbosity)
            if log_file_verbosity is not None
            else level
        )

        file_handler = logging.FileHandler(log_file, mode="a", encoding="utf-8")
        file_handler.setLevel(file_level)
        file_handler.setFormatter(formatter)
        root_logger.addHandler(file_handler)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("ref", type=Path, help="Path to the reference directory")
    parser.add_argument("mon", type=Path, help="Path to the monitored directory")
    parser.add_argument("--driver", choices=["chrome", "firefox"])
    parser.add_argument("--max-workers", type=int, default=1)
    parser.add_argument("--compare", action="store_true")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument(
        "-v",
        "--verbose",
        action="count",
        default=0,
        help="Increase verbosity (-v, -vv, -vvv)",
    )
    parser.add_argument(
        "--log-file",
        type=Path,
        help="Path to log file",
    )
    parser.add_argument(
        "--log-file-verbosity", type=int, help="Log file verbosity level"
    )
    args = parser.parse_args()

    setup_logging(args.verbose, args.log_file, args.log_file_verbosity)

    Config.path_a = args.ref
    Config.path_b = args.mon
    Config.driver = args.driver
    Config.browser = (
        get_browser(driver=args.driver) if args.driver is not None else None
    )
    Config.log_file = args.log_file

    if args.compare:
        Config.comparator = Comparator(max_workers=args.max_workers)

        Config.observer = Observer()
        Config.observer.start()

    app.run(host="0.0.0.0", port=args.port)

    if args.compare:
        Config.observer.stop()
        Config.observer.join()

    return 0


if __name__ == "__main__":
    sys.exit(main())
