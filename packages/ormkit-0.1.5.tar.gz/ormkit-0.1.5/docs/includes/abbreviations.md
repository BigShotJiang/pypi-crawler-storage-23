*[ORM]: Object-Relational Mapping
*[SQL]: Structured Query Language
*[API]: Application Programming Interface
*[CRUD]: Create, Read, Update, Delete
*[PyO3]: Rust bindings for Python
*[sqlx]: Rust SQL toolkit
*[GIL]: Global Interpreter Lock
*[JIT]: Just-In-Time compilation
