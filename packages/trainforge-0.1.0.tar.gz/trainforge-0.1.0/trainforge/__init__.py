from .core import Trainer

__version__ = "0.1.0"
__all__ = ["Trainer"]
