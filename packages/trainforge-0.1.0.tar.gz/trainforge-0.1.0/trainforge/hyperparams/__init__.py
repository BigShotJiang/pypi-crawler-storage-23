from .auto import AutoConfig

__all__ = ["AutoConfig"]
