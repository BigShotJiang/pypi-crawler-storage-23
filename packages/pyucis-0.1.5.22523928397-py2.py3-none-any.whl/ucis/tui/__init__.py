"""
PyUCIS Terminal User Interface (TUI)

An interactive terminal-based UI for exploring UCIS coverage databases.
"""

__version__ = "0.1.0"
