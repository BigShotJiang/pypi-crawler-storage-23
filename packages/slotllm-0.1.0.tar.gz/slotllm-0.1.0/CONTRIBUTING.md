# Contributing to slotllm

Thanks for your interest in contributing to slotllm!

## Development Setup

```bash
# Clone the repo
git clone https://github.com/datamachineworks/slotllm.git
cd slotllm

# Create a virtual environment and install dev dependencies
uv venv
uv pip install -e ".[all]"
```

## Running Tests

```bash
# Unit tests (default — excludes integration and postgres tests)
pytest

# Include integration tests
pytest -m 'not postgres'

# All tests (requires SLOTLLM_TEST_PG_DSN for postgres)
export SLOTLLM_TEST_PG_DSN="postgresql://user:pass@localhost:5432/slotllm_test"
pytest -m ''
```

## Code Quality

```bash
# Linting
ruff check .

# Formatting
ruff format .

# Type checking
mypy slotllm
```

## Pull Requests

1. Fork the repo and create a feature branch from `main`.
2. Add tests for any new functionality.
3. Ensure `pytest`, `ruff check .`, and `ruff format --check .` all pass.
4. Open a pull request with a clear description of the change.
