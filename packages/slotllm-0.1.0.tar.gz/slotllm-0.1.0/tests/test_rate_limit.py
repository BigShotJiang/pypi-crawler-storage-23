from __future__ import annotations

import datetime

import pytest
import time_machine

from slotllm.rate_limit import (
    RateLimitConfig,
    SlotBudget,
    compute_budget,
    get_daily_reset_boundary,
)


class TestRateLimitConfig:
    def test_valid_with_rpm_only(self) -> None:
        cfg = RateLimitConfig(model_id="gpt-4o-mini", rpm=100)
        assert cfg.rpm == 100
        assert cfg.rpd is None

    def test_valid_with_all_limits(self) -> None:
        cfg = RateLimitConfig(model_id="gpt-4o-mini", rpm=100, rpd=10000, tpm=200000, tpd=5000000)
        assert cfg.rpm == 100
        assert cfg.tpd == 5000000

    def test_no_limits_raises(self) -> None:
        with pytest.raises(ValueError, match="At least one of"):
            RateLimitConfig(model_id="gpt-4o-mini")

    def test_defaults(self) -> None:
        cfg = RateLimitConfig(model_id="gpt-4o-mini", rpm=100)
        assert cfg.avg_tokens_per_request == 4000
        assert cfg.daily_reset_tz == "US/Pacific"
        assert cfg.priority == 0


class TestComputeBudget:
    def test_all_four_limits(self) -> None:
        cfg = RateLimitConfig(
            model_id="gpt-4o-mini",
            rpm=100,
            rpd=10000,
            tpm=200000,
            tpd=5000000,
            avg_tokens_per_request=4000,
        )
        budget = compute_budget(cfg, used_rpm=30, used_rpd=1000, used_tpm=40000, used_tpd=100000)
        # rpm headroom: 100 - 30 = 70
        # rpd headroom: 10000 - 1000 = 9000
        # tpm headroom: (200000 - 40000) // 4000 = 40
        # tpd headroom: (5000000 - 100000) // 4000 = 1225
        assert budget.available_slots == 40
        assert budget.model_id == "gpt-4o-mini"

    def test_rpm_only(self) -> None:
        cfg = RateLimitConfig(model_id="claude-sonnet-4-20250514", rpm=50)
        budget = compute_budget(cfg, used_rpm=10)
        assert budget.available_slots == 40

    def test_zero_headroom(self) -> None:
        cfg = RateLimitConfig(model_id="gpt-4o-mini", rpm=100)
        budget = compute_budget(cfg, used_rpm=100)
        assert budget.available_slots == 0

    def test_over_limit_clamps_to_zero(self) -> None:
        cfg = RateLimitConfig(model_id="gpt-4o-mini", rpm=100)
        budget = compute_budget(cfg, used_rpm=150)
        assert budget.available_slots == 0

    def test_avg_tokens_per_request_scaling(self) -> None:
        cfg = RateLimitConfig(model_id="gpt-4o-mini", tpm=100000, avg_tokens_per_request=1000)
        budget = compute_budget(cfg, used_tpm=0)
        assert budget.available_slots == 100

        cfg2 = RateLimitConfig(model_id="gpt-4o-mini", tpm=100000, avg_tokens_per_request=5000)
        budget2 = compute_budget(cfg2, used_tpm=0)
        assert budget2.available_slots == 20

    def test_budget_is_frozen(self) -> None:
        cfg = RateLimitConfig(model_id="gpt-4o-mini", rpm=100)
        budget = compute_budget(cfg)
        with pytest.raises(Exception):
            budget.available_slots = 999  # type: ignore[misc]

    def test_computed_at_is_utc(self) -> None:
        cfg = RateLimitConfig(model_id="gpt-4o-mini", rpm=100)
        budget = compute_budget(cfg)
        assert budget.computed_at.tzinfo is not None
        assert budget.computed_at.tzinfo == datetime.timezone.utc

    def test_slot_budget_type(self) -> None:
        cfg = RateLimitConfig(model_id="gpt-4o-mini", rpm=100)
        budget = compute_budget(cfg)
        assert isinstance(budget, SlotBudget)


class TestGetDailyResetBoundary:
    @time_machine.travel("2026-02-23 10:30:00-08:00", tick=False)
    def test_us_pacific(self) -> None:
        boundary = get_daily_reset_boundary("US/Pacific")
        expected = datetime.datetime(2026, 2, 23, 8, 0, 0, tzinfo=datetime.timezone.utc)
        assert boundary == expected

    @time_machine.travel("2026-02-23 15:00:00+00:00", tick=False)
    def test_utc(self) -> None:
        boundary = get_daily_reset_boundary("UTC")
        expected = datetime.datetime(2026, 2, 23, 0, 0, 0, tzinfo=datetime.timezone.utc)
        assert boundary == expected

    @time_machine.travel("2026-02-23 14:00:00+00:00", tick=False)
    def test_europe_london(self) -> None:
        boundary = get_daily_reset_boundary("Europe/London")
        # Feb in London is GMT (UTC+0), so start-of-day is midnight UTC
        expected = datetime.datetime(2026, 2, 23, 0, 0, 0, tzinfo=datetime.timezone.utc)
        assert boundary == expected

    @time_machine.travel("2026-07-15 14:00:00+00:00", tick=False)
    def test_europe_london_bst(self) -> None:
        boundary = get_daily_reset_boundary("Europe/London")
        # July in London is BST (UTC+1), so midnight local = 23:00 UTC previous day
        expected = datetime.datetime(2026, 7, 14, 23, 0, 0, tzinfo=datetime.timezone.utc)
        assert boundary == expected

    def test_boundary_is_utc(self) -> None:
        boundary = get_daily_reset_boundary("US/Pacific")
        assert boundary.tzinfo is not None
        assert boundary.tzinfo == datetime.timezone.utc
