"""Tests for the LiteLLMCaller adapter (mocked)."""

from __future__ import annotations

from types import SimpleNamespace
from typing import Any
from unittest.mock import AsyncMock, patch

import pytest

from slotllm.adapters.litellm import LiteLLMCaller
from slotllm.caller import Caller, Response


def _mock_response(
    content: str = "Hello!",
    prompt_tokens: int = 10,
    completion_tokens: int = 5,
) -> SimpleNamespace:
    return SimpleNamespace(
        choices=[SimpleNamespace(message=SimpleNamespace(content=content))],
        usage=SimpleNamespace(
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
        ),
    )


class TestLiteLLMCallerProtocol:
    def test_satisfies_caller_protocol(self) -> None:
        caller = LiteLLMCaller()
        assert isinstance(caller, Caller)


class TestCompletion:
    @patch("slotllm.adapters.litellm.litellm")
    async def test_basic_completion(self, mock_litellm: Any) -> None:
        mock_litellm.acompletion = AsyncMock(return_value=_mock_response())
        caller = LiteLLMCaller()

        resp = await caller.call(
            "gpt-4o-mini",
            [{"role": "user", "content": "Hi"}],
        )

        assert isinstance(resp, Response)
        assert resp.content == "Hello!"
        assert resp.input_tokens == 10
        assert resp.output_tokens == 5
        assert resp.model_id == "gpt-4o-mini"
        assert resp.raw is not None
        assert resp.latency_ms is not None and resp.latency_ms >= 0

    @patch("slotllm.adapters.litellm.litellm")
    async def test_token_extraction(self, mock_litellm: Any) -> None:
        mock_litellm.acompletion = AsyncMock(
            return_value=_mock_response(prompt_tokens=100, completion_tokens=200)
        )
        caller = LiteLLMCaller()

        resp = await caller.call("gpt-4o-mini", [{"role": "user", "content": "Hi"}])
        assert resp.input_tokens == 100
        assert resp.output_tokens == 200

    @patch("slotllm.adapters.litellm.litellm")
    async def test_no_usage_data_defaults_to_zero(self, mock_litellm: Any) -> None:
        response = _mock_response()
        response.usage = None
        mock_litellm.acompletion = AsyncMock(return_value=response)
        caller = LiteLLMCaller()

        resp = await caller.call("gpt-4o-mini", [{"role": "user", "content": "Hi"}])
        assert resp.input_tokens == 0
        assert resp.output_tokens == 0


class TestKwargsMerge:
    @patch("slotllm.adapters.litellm.litellm")
    async def test_default_kwargs_passed(self, mock_litellm: Any) -> None:
        mock_litellm.acompletion = AsyncMock(return_value=_mock_response())
        caller = LiteLLMCaller(temperature=0.5)

        await caller.call("gpt-4o-mini", [{"role": "user", "content": "Hi"}])

        call_kwargs = mock_litellm.acompletion.call_args
        assert call_kwargs.kwargs["temperature"] == 0.5

    @patch("slotllm.adapters.litellm.litellm")
    async def test_per_call_kwargs_override(self, mock_litellm: Any) -> None:
        mock_litellm.acompletion = AsyncMock(return_value=_mock_response())
        caller = LiteLLMCaller(temperature=0.5)

        await caller.call(
            "gpt-4o-mini",
            [{"role": "user", "content": "Hi"}],
            temperature=0.9,
        )

        call_kwargs = mock_litellm.acompletion.call_args
        assert call_kwargs.kwargs["temperature"] == 0.9


class TestRetry:
    @patch("slotllm.adapters.litellm.litellm")
    async def test_retries_on_rate_limit(self, mock_litellm: Any) -> None:
        from litellm.exceptions import RateLimitError

        mock_litellm.acompletion = AsyncMock(
            side_effect=[
                RateLimitError("rate limited", "provider", "model"),
                _mock_response(),
            ]
        )
        caller = LiteLLMCaller(max_retries=3)

        resp = await caller.call("gpt-4o-mini", [{"role": "user", "content": "Hi"}])
        assert resp.content == "Hello!"
        assert mock_litellm.acompletion.call_count == 2

    @patch("slotllm.adapters.litellm.litellm")
    async def test_no_retry_on_auth_error(self, mock_litellm: Any) -> None:
        from litellm.exceptions import AuthenticationError

        mock_litellm.acompletion = AsyncMock(
            side_effect=AuthenticationError("bad key", "provider", "model")
        )
        caller = LiteLLMCaller(max_retries=3)

        with pytest.raises(AuthenticationError):
            await caller.call("gpt-4o-mini", [{"role": "user", "content": "Hi"}])
        assert mock_litellm.acompletion.call_count == 1


class TestInstructor:
    @patch("slotllm.adapters.litellm.litellm")
    async def test_instructor_missing_raises(self, mock_litellm: Any) -> None:
        caller = LiteLLMCaller()

        with patch.dict("sys.modules", {"instructor": None}):
            with pytest.raises(ImportError, match="instructor"):
                await caller.call(
                    "gpt-4o-mini",
                    [{"role": "user", "content": "Hi"}],
                    response_model=dict,
                )
