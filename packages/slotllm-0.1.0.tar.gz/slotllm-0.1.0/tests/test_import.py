"""Smoke test: verify the package is importable."""


def test_import_slotllm() -> None:
    import slotllm

    assert hasattr(slotllm, "BatchRunner")
    assert hasattr(slotllm, "Caller")
    assert hasattr(slotllm, "CostTracker")
    assert hasattr(slotllm, "MemoryBackend")
    assert hasattr(slotllm, "RateLimitConfig")
    assert hasattr(slotllm, "Response")
    assert hasattr(slotllm, "SlotBackend")
