"""Tests for the Caller protocol and Response model."""

from __future__ import annotations

from typing import Any

from slotllm.caller import Caller, Response


class TestResponse:
    def test_defaults(self) -> None:
        r = Response()
        assert r.content is None
        assert r.input_tokens == 0
        assert r.output_tokens == 0
        assert r.model_id == ""
        assert r.raw is None
        assert r.latency_ms is None

    def test_construction(self) -> None:
        r = Response(
            content="Hello, world!",
            input_tokens=10,
            output_tokens=5,
            model_id="gpt-4o-mini",
            raw={"id": "chatcmpl-123"},
            latency_ms=150.5,
        )
        assert r.content == "Hello, world!"
        assert r.input_tokens == 10
        assert r.output_tokens == 5
        assert r.model_id == "gpt-4o-mini"
        assert r.raw == {"id": "chatcmpl-123"}
        assert r.latency_ms == 150.5

    def test_any_content_type(self) -> None:
        r1 = Response(content="plain text")
        assert r1.content == "plain text"

        r2 = Response(content={"key": "value"})
        assert r2.content == {"key": "value"}

        r3 = Response(content=42)
        assert r3.content == 42


class ValidCaller:
    async def call(
        self,
        model_id: str,
        messages: list[dict[str, str]],
        **kwargs: Any,
    ) -> Response:
        return Response(
            content="test",
            input_tokens=1,
            output_tokens=1,
            model_id=model_id,
        )


class MissingCallMethod:
    pass


class WrongSignature:
    async def call(self) -> str:
        return "nope"


class TestCallerProtocol:
    def test_valid_caller_is_instance(self) -> None:
        caller = ValidCaller()
        assert isinstance(caller, Caller)

    def test_missing_method_is_not_instance(self) -> None:
        obj = MissingCallMethod()
        assert not isinstance(obj, Caller)

    def test_wrong_signature_still_passes_runtime_check(self) -> None:
        # runtime_checkable only checks method existence, not signature
        obj = WrongSignature()
        assert isinstance(obj, Caller)

    async def test_valid_caller_can_be_called(self) -> None:
        caller = ValidCaller()
        resp = await caller.call(
            "gpt-4o-mini",
            [{"role": "user", "content": "hi"}],
        )
        assert isinstance(resp, Response)
        assert resp.content == "test"
        assert resp.model_id == "gpt-4o-mini"
