"""Tests for the SlotBackend abstract interface and Usage model."""

from __future__ import annotations

import pytest

from slotllm.backends.base import SlotBackend, Usage
from slotllm.rate_limit import RateLimitConfig, SlotBudget


class TestUsage:
    def test_defaults(self) -> None:
        usage = Usage()
        assert usage.requests_this_minute == 0
        assert usage.requests_today == 0
        assert usage.tokens_this_minute == 0
        assert usage.tokens_today == 0

    def test_custom_values(self) -> None:
        usage = Usage(
            requests_this_minute=5,
            requests_today=100,
            tokens_this_minute=20000,
            tokens_today=500000,
        )
        assert usage.requests_this_minute == 5
        assert usage.tokens_today == 500000

    def test_frozen(self) -> None:
        usage = Usage()
        with pytest.raises(Exception):
            usage.requests_this_minute = 10  # type: ignore[misc]


class TestSlotBackendInterface:
    def test_cannot_instantiate(self) -> None:
        with pytest.raises(TypeError):
            SlotBackend()  # type: ignore[abstract]

    def test_has_required_methods(self) -> None:
        assert hasattr(SlotBackend, "register")
        assert hasattr(SlotBackend, "acquire")
        assert hasattr(SlotBackend, "release")
        assert hasattr(SlotBackend, "record_usage")
        assert hasattr(SlotBackend, "get_usage")
        assert hasattr(SlotBackend, "refresh")
        assert hasattr(SlotBackend, "teardown")

    def test_has_context_manager(self) -> None:
        assert hasattr(SlotBackend, "__aenter__")
        assert hasattr(SlotBackend, "__aexit__")


class ConcreteBackend(SlotBackend):
    """Minimal concrete implementation for testing the context manager."""

    def __init__(self) -> None:
        self.torn_down = False

    async def register(self, configs: list[RateLimitConfig]) -> None:
        pass

    async def acquire(self, model_id: str, count: int) -> list[str]:
        return []

    async def release(self, slot_ids: list[str]) -> None:
        pass

    async def record_usage(self, slot_id: str, input_tokens: int, output_tokens: int) -> None:
        pass

    async def get_usage(self, model_id: str) -> Usage:
        return Usage()

    async def refresh(self) -> dict[str, SlotBudget]:
        return {}

    async def teardown(self) -> None:
        self.torn_down = True


class TestContextManager:
    async def test_async_context_manager_calls_teardown(self) -> None:
        backend = ConcreteBackend()
        assert not backend.torn_down
        async with backend as b:
            assert b is backend
        assert backend.torn_down
