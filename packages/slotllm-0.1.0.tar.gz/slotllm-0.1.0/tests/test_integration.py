"""End-to-end integration tests using mock callers + MemoryBackend.

No API keys or external services required.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any

import pytest

from slotllm.backends.memory import MemoryBackend
from slotllm.caller import Response
from slotllm.cost import CostTracker
from slotllm.rate_limit import RateLimitConfig
from slotllm.runner import BatchRunner, RequestItem

pytestmark = pytest.mark.integration


class _MockCaller:
    def __init__(self, input_tokens: int = 50, output_tokens: int = 25) -> None:
        self.call_count = 0
        self.calls: list[tuple[str, list[dict[str, str]]]] = []
        self._input_tokens = input_tokens
        self._output_tokens = output_tokens

    async def call(self, model_id: str, messages: list[dict[str, str]], **kwargs: Any) -> Response:
        self.call_count += 1
        self.calls.append((model_id, messages))
        content = messages[-1].get("content", "")
        return Response(
            content=f"reply to: {content}",
            input_tokens=self._input_tokens,
            output_tokens=self._output_tokens,
            model_id=model_id,
        )


class _FailingCaller:
    def __init__(self, fail_at: set[int]) -> None:
        self.call_count = 0
        self._fail_at = fail_at

    async def call(self, model_id: str, messages: list[dict[str, str]], **kwargs: Any) -> Response:
        idx = self.call_count
        self.call_count += 1
        if idx in self._fail_at:
            raise RuntimeError(f"Failure at {idx}")
        return Response(
            content="ok",
            input_tokens=10,
            output_tokens=5,
            model_id=model_id,
        )


def _items(n: int, model_id: str | None = None) -> list[RequestItem]:
    return [
        RequestItem(
            messages=[{"role": "user", "content": f"prompt {i}"}],
            model_id=model_id,
            metadata=i,
        )
        for i in range(n)
    ]


class TestFullPipeline:
    async def test_20_items_with_rpm_budget(self) -> None:
        """Process 20 items through the full pipeline."""
        caller = _MockCaller()
        backend = MemoryBackend()
        tracker = CostTracker()
        tracker.register_price(
            "gpt-4o-mini",
            input_price_per_token=Decimal("0.0001"),
            output_price_per_token=Decimal("0.0002"),
        )
        configs = [RateLimitConfig(model_id="gpt-4o-mini", rpd=100)]

        async with BatchRunner(
            caller, backend, configs, cost_tracker=tracker, chunk_size=5
        ) as runner:
            results = await runner.run(_items(20, model_id="gpt-4o-mini"))

        assert len(results) == 20
        assert caller.call_count == 20
        assert all(r.response is not None for r in results)
        assert all(r.error is None for r in results)
        assert all(r.cost_usd > 0 for r in results)

        summary = tracker.summary()
        assert summary["total_requests"] == 20
        assert summary["total_input_tokens"] == 20 * 50
        assert summary["total_output_tokens"] == 20 * 25
        assert summary["total_cost_usd"] > 0


class TestMultiModelPriorityRouting:
    async def test_priority_routing(self) -> None:
        """Items without model_id are routed to lowest-priority model."""
        caller = _MockCaller()
        backend = MemoryBackend()
        configs = [
            RateLimitConfig(model_id="expensive", rpd=100, priority=10),
            RateLimitConfig(model_id="cheap", rpd=100, priority=1),
            RateLimitConfig(model_id="cheapest", rpd=100, priority=0),
        ]

        runner = BatchRunner(caller, backend, configs)
        results = await runner.run(_items(5))

        assert len(results) == 5
        for r in results:
            assert r.response is not None
            assert r.response.model_id == "cheapest"

    async def test_fallback_when_primary_exhausted(self) -> None:
        """When preferred model budget exhausts, falls back to next."""
        caller = _MockCaller()
        backend = MemoryBackend()
        configs = [
            RateLimitConfig(model_id="primary", rpd=3, priority=0),
            RateLimitConfig(model_id="secondary", rpd=100, priority=1),
        ]

        runner = BatchRunner(caller, backend, configs, poll_interval=0.01)
        results = await runner.run(_items(7))

        assert len(results) == 7
        model_ids = [r.response.model_id for r in results]
        assert model_ids.count("primary") == 3
        assert model_ids.count("secondary") == 4


class TestCostSummaryAccuracy:
    async def test_cost_summary(self) -> None:
        caller = _MockCaller(input_tokens=100, output_tokens=50)
        backend = MemoryBackend()
        tracker = CostTracker()
        tracker.register_price(
            "model-a",
            input_price_per_token=Decimal("0.001"),
            output_price_per_token=Decimal("0.002"),
        )
        configs = [RateLimitConfig(model_id="model-a", rpd=100)]

        runner = BatchRunner(caller, backend, configs, cost_tracker=tracker)
        results = await runner.run(_items(5, model_id="model-a"))

        # Per request: 100 * 0.001 + 50 * 0.002 = 0.1 + 0.1 = 0.2
        expected_per = Decimal("0.2")
        for r in results:
            assert r.cost_usd == expected_per

        summary = tracker.summary()
        assert summary["total_cost_usd"] == expected_per * 5
        assert summary["by_model"]["model-a"] == expected_per * 5
        assert summary["total_requests"] == 5


class TestErrorIsolation:
    async def test_failures_dont_abort_batch(self) -> None:
        """Individual failures are captured; other items still succeed."""
        caller = _FailingCaller(fail_at={1, 3})
        backend = MemoryBackend()
        configs = [RateLimitConfig(model_id="test", rpd=100)]

        runner = BatchRunner(caller, backend, configs)
        results = await runner.run(_items(5, model_id="test"))

        assert len(results) == 5

        successes = [r for r in results if r.error is None]
        failures = [r for r in results if r.error is not None]

        assert len(successes) == 3
        assert len(failures) == 2

        for r in successes:
            assert r.response is not None

        for r in failures:
            assert r.response is None
            assert "Failure" in str(r.error)

    async def test_error_preserves_metadata(self) -> None:
        caller = _FailingCaller(fail_at={0})
        backend = MemoryBackend()
        configs = [RateLimitConfig(model_id="test", rpd=100)]

        runner = BatchRunner(caller, backend, configs)
        results = await runner.run(_items(2, model_id="test"))

        assert results[0].error is not None
        assert results[0].metadata == 0
        assert results[1].response is not None
        assert results[1].metadata == 1


class TestRunSimpleEndToEnd:
    async def test_run_simple(self) -> None:
        caller = _MockCaller()
        backend = MemoryBackend()
        configs = [RateLimitConfig(model_id="gpt-4o-mini", rpd=100)]

        runner = BatchRunner(caller, backend, configs)
        results = await runner.run_simple(
            ["Hello", "How are you?", "Goodbye"],
            model_id="gpt-4o-mini",
        )

        assert len(results) == 3
        assert all(r.response is not None for r in results)
        assert results[0].response.content == "reply to: Hello"
        assert results[1].response.content == "reply to: How are you?"
        assert results[2].response.content == "reply to: Goodbye"


class TestSQLiteMultiProcess:
    async def test_sqlite_two_runners_coordinate(self) -> None:
        """Two runners sharing a SQLite backend do not over-allocate."""
        import tempfile

        from slotllm.backends.sqlite import SQLiteBackend

        db = tempfile.mktemp(suffix=".db")
        configs = [RateLimitConfig(model_id="test", rpd=10)]

        caller1 = _MockCaller()
        caller2 = _MockCaller()

        async with SQLiteBackend(db_path=db) as b1, SQLiteBackend(db_path=db) as b2:
            r1 = BatchRunner(caller1, b1, configs)
            r2 = BatchRunner(
                caller2, b2, configs, max_wait=0.1, poll_interval=0.01
            )

            # First runner takes 7
            results1 = await r1.run(_items(7, model_id="test"))
            assert len(results1) == 7
            assert all(r.response is not None for r in results1)

            # Second runner requests 5 but only 3 remain in the day budget.
            # The first 3 succeed; remaining 2 cause SlotTimeoutError.
            from slotllm.runner import SlotTimeoutError

            with pytest.raises(SlotTimeoutError):
                await r2.run(_items(5, model_id="test"))

            # Verify total across both backends: exactly 10
            usage1 = await b1.get_usage("test")
            assert usage1.requests_today == 10
