"""Integration tests for the PostgreSQL slot backend.

Skipped unless the SLOTLLM_TEST_PG_DSN environment variable is set to a valid
PostgreSQL connection string. Example:

    export SLOTLLM_TEST_PG_DSN="postgresql://user:pass@localhost:5432/slotllm_test"
    pytest tests/test_postgres_backend.py -v
"""

from __future__ import annotations

import asyncio
import os

import pytest

pytestmark = [
    pytest.mark.postgres,
    pytest.mark.skipif(
        not os.environ.get("SLOTLLM_TEST_PG_DSN"),
        reason="SLOTLLM_TEST_PG_DSN not set",
    ),
]

DSN = os.environ.get("SLOTLLM_TEST_PG_DSN", "")


def _cfg(
    model_id: str = "gpt-4o-mini",
    rpm: int | None = 10,
    rpd: int | None = None,
    tpm: int | None = None,
    tpd: int | None = None,
    avg_tokens_per_request: int = 4000,
):  # type: ignore[no-untyped-def]
    from slotllm.rate_limit import RateLimitConfig

    return RateLimitConfig(
        model_id=model_id,
        rpm=rpm,
        rpd=rpd,
        tpm=tpm,
        tpd=tpd,
        avg_tokens_per_request=avg_tokens_per_request,
    )


async def _clean_tables() -> None:
    """Drop slotllm tables to ensure a clean state."""
    from slotllm.backends.postgres import PostgresBackend

    async with PostgresBackend(dsn=DSN) as backend:
        assert backend._pool is not None
        async with backend._pool.connection() as conn:
            await conn.execute("DROP TABLE IF EXISTS slotllm_slots")
            await conn.execute("DROP TABLE IF EXISTS slotllm_configs")


@pytest.fixture(autouse=True)
async def clean_db():  # type: ignore[no-untyped-def]
    await _clean_tables()
    yield
    await _clean_tables()


class TestLifecycle:
    async def test_basic_acquire_and_usage(self) -> None:
        from slotllm.backends.postgres import PostgresBackend

        async with PostgresBackend(dsn=DSN) as backend:
            await backend.register([_cfg(rpm=5)])
            ids = await backend.acquire("gpt-4o-mini", 3)
            assert len(ids) == 3
            assert len(set(ids)) == 3

            usage = await backend.get_usage("gpt-4o-mini")
            assert usage.requests_this_minute == 3
            assert usage.requests_today == 3

    async def test_record_usage(self) -> None:
        from slotllm.backends.postgres import PostgresBackend

        async with PostgresBackend(dsn=DSN) as backend:
            await backend.register([_cfg(rpm=10)])
            ids = await backend.acquire("gpt-4o-mini", 1)
            await backend.record_usage(ids[0], input_tokens=200, output_tokens=100)

            usage = await backend.get_usage("gpt-4o-mini")
            assert usage.tokens_this_minute == 300

    async def test_release_frees_slots(self) -> None:
        from slotllm.backends.postgres import PostgresBackend

        async with PostgresBackend(dsn=DSN) as backend:
            await backend.register([_cfg(rpm=3)])
            ids = await backend.acquire("gpt-4o-mini", 3)
            assert len(await backend.acquire("gpt-4o-mini", 1)) == 0

            await backend.release(ids[:2])
            ids2 = await backend.acquire("gpt-4o-mini", 5)
            assert len(ids2) == 2


class TestBudgetLimiting:
    async def test_partial_acquisition(self) -> None:
        from slotllm.backends.postgres import PostgresBackend

        async with PostgresBackend(dsn=DSN) as backend:
            await backend.register([_cfg(rpm=3)])
            ids = await backend.acquire("gpt-4o-mini", 10)
            assert len(ids) == 3

    async def test_zero_budget(self) -> None:
        from slotllm.backends.postgres import PostgresBackend

        async with PostgresBackend(dsn=DSN) as backend:
            await backend.register([_cfg(rpm=0)])
            ids = await backend.acquire("gpt-4o-mini", 5)
            assert len(ids) == 0

    async def test_unregistered_model(self) -> None:
        from slotllm.backends.postgres import PostgresBackend

        async with PostgresBackend(dsn=DSN) as backend:
            ids = await backend.acquire("unknown", 5)
            assert len(ids) == 0


class TestConcurrency:
    async def test_concurrent_acquire_no_over_allocation(self) -> None:
        from slotllm.backends.postgres import PostgresBackend

        async with PostgresBackend(dsn=DSN) as backend:
            await backend.register([_cfg(rpm=10)])
            results = await asyncio.gather(*[backend.acquire("gpt-4o-mini", 3) for _ in range(5)])
            total = sum(len(r) for r in results)
            assert total == 10


class TestRefresh:
    async def test_refresh_returns_budgets(self) -> None:
        from slotllm.backends.postgres import PostgresBackend

        async with PostgresBackend(dsn=DSN) as backend:
            await backend.register(
                [
                    _cfg(model_id="model-a", rpm=10),
                    _cfg(model_id="model-b", rpm=20),
                ]
            )
            budgets = await backend.refresh()
            assert budgets["model-a"].available_slots == 10
            assert budgets["model-b"].available_slots == 20


class TestMultiInstance:
    async def test_two_instances_coordinate(self) -> None:
        from slotllm.backends.postgres import PostgresBackend

        async with (
            PostgresBackend(dsn=DSN) as b1,
            PostgresBackend(dsn=DSN) as b2,
        ):
            await b1.register([_cfg(rpm=5)])
            ids1 = await b1.acquire("gpt-4o-mini", 3)
            assert len(ids1) == 3

            ids2 = await b2.acquire("gpt-4o-mini", 5)
            assert len(ids2) == 2
