"""Tests for BatchRunner using mock caller + MemoryBackend."""

from __future__ import annotations

from decimal import Decimal
from typing import Any

import pytest

from slotllm.backends.memory import MemoryBackend
from slotllm.caller import Response
from slotllm.cost import CostTracker
from slotllm.rate_limit import RateLimitConfig
from slotllm.runner import BatchResult, BatchRunner, RequestItem, SlotTimeoutError


class MockCaller:
    """Mock caller that returns canned responses."""

    def __init__(
        self,
        *,
        fail_on: set[int] | None = None,
        input_tokens: int = 10,
        output_tokens: int = 5,
    ) -> None:
        self.call_count = 0
        self._fail_on = fail_on or set()
        self._input_tokens = input_tokens
        self._output_tokens = output_tokens

    async def call(
        self,
        model_id: str,
        messages: list[dict[str, str]],
        **kwargs: Any,
    ) -> Response:
        idx = self.call_count
        self.call_count += 1
        if idx in self._fail_on:
            raise ValueError(f"Simulated failure at call {idx}")
        content = messages[-1].get("content", "")
        return Response(
            content=f"echo: {content}",
            input_tokens=self._input_tokens,
            output_tokens=self._output_tokens,
            model_id=model_id,
        )


def _cfg(
    model_id: str = "gpt-4o-mini",
    rpm: int | None = None,
    rpd: int | None = None,
    priority: int = 0,
) -> RateLimitConfig:
    return RateLimitConfig(model_id=model_id, rpm=rpm, rpd=rpd, priority=priority)


def _items(n: int, model_id: str | None = "gpt-4o-mini") -> list[RequestItem]:
    return [
        RequestItem(
            messages=[{"role": "user", "content": f"prompt {i}"}],
            model_id=model_id,
            metadata={"index": i},
        )
        for i in range(n)
    ]


class TestBasicBatch:
    async def test_batch_of_5_with_budget_5(self) -> None:
        caller = MockCaller()
        backend = MemoryBackend()
        runner = BatchRunner(caller, backend, [_cfg(rpd=5)], chunk_size=10)

        results = await runner.run(_items(5))

        assert len(results) == 5
        assert caller.call_count == 5
        for r in results:
            assert r.response is not None
            assert r.error is None
            assert r.response.content.startswith("echo: prompt")

    async def test_batch_of_20_with_budget_5_per_minute(self) -> None:
        """RPD budget allows multi-round processing within the same minute."""
        caller = MockCaller()
        backend = MemoryBackend()
        # RPM=5 limits per-minute, RPD=20 allows all 20 in a day.
        # Each round acquires up to 5 (rpm), processes them, then the
        # minute-window slots still count, so we use rpd=20 as the
        # effective limit with high rpm.
        runner = BatchRunner(
            caller,
            backend,
            [_cfg(rpd=20)],
            chunk_size=10,
            poll_interval=0.01,
        )

        results = await runner.run(_items(20))

        assert len(results) == 20
        assert caller.call_count == 20
        for r in results:
            assert r.response is not None

    async def test_multi_round_with_limited_budget(self) -> None:
        """With rpd=5, 10 items require waiting for slots (timeout expected)."""
        caller = MockCaller()
        backend = MemoryBackend()
        # Only 5 per day, so 10 items will exhaust budget after first 5
        runner = BatchRunner(
            caller,
            backend,
            [_cfg(rpd=5)],
            chunk_size=10,
            poll_interval=0.01,
            max_wait=0.05,
        )

        # First 5 succeed, then budget exhausted → timeout
        with pytest.raises(SlotTimeoutError):
            await runner.run(_items(10))


class TestResultOrder:
    async def test_results_in_input_order(self) -> None:
        caller = MockCaller()
        backend = MemoryBackend()
        runner = BatchRunner(caller, backend, [_cfg(rpd=100)], poll_interval=0.01)

        items = _items(9)
        results = await runner.run(items)

        for i, r in enumerate(results):
            assert r.metadata == {"index": i}
            assert r.response is not None
            assert r.response.content == f"echo: prompt {i}"


class TestFailedRequest:
    async def test_failure_captured_in_result(self) -> None:
        caller = MockCaller(fail_on={1, 3})
        backend = MemoryBackend()
        runner = BatchRunner(caller, backend, [_cfg(rpd=100)])

        results = await runner.run(_items(5))

        assert len(results) == 5
        # Successful ones
        assert results[0].response is not None
        assert results[0].error is None
        assert results[2].response is not None
        assert results[4].response is not None
        # Failed ones
        assert results[1].error is not None
        assert results[1].response is None
        assert "Simulated failure" in str(results[1].error)
        assert results[3].error is not None


class TestTimeout:
    async def test_max_wait_timeout(self) -> None:
        caller = MockCaller()
        backend = MemoryBackend()
        runner = BatchRunner(
            caller,
            backend,
            [_cfg(rpd=0)],
            max_wait=0.1,
            poll_interval=0.05,
        )

        with pytest.raises(SlotTimeoutError):
            await runner.run(_items(1))


class TestRunSimple:
    async def test_run_simple(self) -> None:
        caller = MockCaller()
        backend = MemoryBackend()
        runner = BatchRunner(caller, backend, [_cfg(rpd=100)])

        results = await runner.run_simple(["Hello", "World"], model_id="gpt-4o-mini")

        assert len(results) == 2
        assert results[0].response is not None
        assert results[0].response.content == "echo: Hello"
        assert results[1].response.content == "echo: World"


class TestPrioritySelection:
    async def test_selects_higher_priority_model(self) -> None:
        caller = MockCaller()
        backend = MemoryBackend()
        configs = [
            _cfg(model_id="expensive", rpd=100, priority=10),
            _cfg(model_id="cheap", rpd=100, priority=1),
        ]
        runner = BatchRunner(caller, backend, configs)

        items = _items(3, model_id=None)
        results = await runner.run(items)

        for r in results:
            assert r.response is not None
            assert r.response.model_id == "cheap"

    async def test_falls_back_to_second_model(self) -> None:
        caller = MockCaller()
        backend = MemoryBackend()
        configs = [
            _cfg(model_id="primary", rpd=2, priority=0),
            _cfg(model_id="secondary", rpd=100, priority=1),
        ]
        runner = BatchRunner(caller, backend, configs, poll_interval=0.01)

        items = _items(5, model_id=None)
        results = await runner.run(items)

        model_ids = [r.response.model_id for r in results]
        assert "primary" in model_ids
        assert "secondary" in model_ids


class TestProgressCallback:
    async def test_on_progress_called(self) -> None:
        progress_calls: list[tuple[int, int]] = []

        def on_progress(completed: int, total: int) -> None:
            progress_calls.append((completed, total))

        caller = MockCaller()
        backend = MemoryBackend()
        runner = BatchRunner(
            caller,
            backend,
            [_cfg(rpd=100)],
            on_progress=on_progress,
        )

        await runner.run(_items(3))

        assert len(progress_calls) == 3
        assert progress_calls[-1] == (3, 3)
        for i in range(len(progress_calls)):
            assert progress_calls[i][0] == i + 1
            assert progress_calls[i][1] == 3


class TestCostTracking:
    async def test_cost_recorded(self) -> None:
        caller = MockCaller(input_tokens=100, output_tokens=50)
        backend = MemoryBackend()
        tracker = CostTracker()
        tracker.register_price(
            "gpt-4o-mini",
            input_price_per_token=Decimal("0.001"),
            output_price_per_token=Decimal("0.002"),
        )
        runner = BatchRunner(
            caller,
            backend,
            [_cfg(rpd=100)],
            cost_tracker=tracker,
        )

        results = await runner.run(_items(2))

        for r in results:
            assert r.cost_usd > 0
        assert tracker.total_cost > 0
        assert tracker.summary()["total_requests"] == 2


class TestOnResultCallback:
    async def test_sync_on_result_called_per_item(self) -> None:
        collected: list[BatchResult] = []

        def on_result(result: BatchResult) -> None:
            collected.append(result)

        caller = MockCaller()
        backend = MemoryBackend()
        runner = BatchRunner(
            caller, backend, [_cfg(rpd=100)], on_result=on_result
        )

        items = _items(3)
        results = await runner.run(items)

        assert len(collected) == 3
        for i, r in enumerate(collected):
            assert r.response is not None
            assert r.slot_id != ""
            assert r.metadata == {"index": i}
        # Collected results should match returned results
        for c, r in zip(collected, results):
            assert c is r

    async def test_async_on_result_called_per_item(self) -> None:
        collected: list[BatchResult] = []

        async def on_result(result: BatchResult) -> None:
            collected.append(result)

        caller = MockCaller()
        backend = MemoryBackend()
        runner = BatchRunner(
            caller, backend, [_cfg(rpd=100)], on_result=on_result
        )

        items = _items(3)
        results = await runner.run(items)

        assert len(collected) == 3
        for c, r in zip(collected, results):
            assert c is r

    async def test_on_result_called_on_error(self) -> None:
        collected: list[BatchResult] = []

        def on_result(result: BatchResult) -> None:
            collected.append(result)

        caller = MockCaller(fail_on={1})
        backend = MemoryBackend()
        runner = BatchRunner(
            caller, backend, [_cfg(rpd=100)], on_result=on_result
        )

        results = await runner.run(_items(3))

        assert len(collected) == 3
        # The error item should have error set
        error_results = [r for r in collected if r.error is not None]
        assert len(error_results) == 1
        assert "Simulated failure" in str(error_results[0].error)
        assert error_results[0].response is None


class TestContextManager:
    async def test_context_manager_teardown(self) -> None:
        caller = MockCaller()
        backend = MemoryBackend()
        async with BatchRunner(caller, backend, [_cfg(rpd=100)]) as runner:
            results = await runner.run(_items(2))
            assert len(results) == 2
        assert len(backend._configs) == 0
