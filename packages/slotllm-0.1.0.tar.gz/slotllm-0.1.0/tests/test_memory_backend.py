"""Tests for the in-memory slot backend."""

from __future__ import annotations

import asyncio
import datetime

import time_machine

from slotllm.backends.memory import MemoryBackend
from slotllm.rate_limit import RateLimitConfig

_UTC = datetime.timezone.utc


def _cfg(
    model_id: str = "gpt-4o-mini",
    rpm: int | None = 10,
    rpd: int | None = None,
    tpm: int | None = None,
    tpd: int | None = None,
    avg_tokens_per_request: int = 4000,
) -> RateLimitConfig:
    return RateLimitConfig(
        model_id=model_id,
        rpm=rpm,
        rpd=rpd,
        tpm=tpm,
        tpd=tpd,
        avg_tokens_per_request=avg_tokens_per_request,
    )


class TestAcquire:
    async def test_acquire_up_to_budget(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=5)])
        ids = await backend.acquire("gpt-4o-mini", 5)
        assert len(ids) == 5
        assert len(set(ids)) == 5  # all unique

    async def test_partial_acquisition(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=3)])
        ids = await backend.acquire("gpt-4o-mini", 10)
        assert len(ids) == 3

    async def test_zero_budget(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=0)])
        ids = await backend.acquire("gpt-4o-mini", 5)
        assert len(ids) == 0

    async def test_acquire_unregistered_model(self) -> None:
        backend = MemoryBackend()
        ids = await backend.acquire("unknown-model", 5)
        assert len(ids) == 0

    async def test_sequential_acquire_respects_budget(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=5)])
        ids1 = await backend.acquire("gpt-4o-mini", 3)
        ids2 = await backend.acquire("gpt-4o-mini", 3)
        assert len(ids1) == 3
        assert len(ids2) == 2  # only 2 remaining


class TestRecordUsage:
    async def test_record_updates_tokens(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=10)])
        ids = await backend.acquire("gpt-4o-mini", 1)
        await backend.record_usage(ids[0], input_tokens=100, output_tokens=50)

        usage = await backend.get_usage("gpt-4o-mini")
        assert usage.tokens_this_minute == 150
        assert usage.tokens_today == 150

    async def test_record_unknown_slot_is_noop(self) -> None:
        backend = MemoryBackend()
        await backend.record_usage("nonexistent", input_tokens=100, output_tokens=50)


class TestRelease:
    async def test_release_frees_slots(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=3)])
        ids = await backend.acquire("gpt-4o-mini", 3)
        assert len(ids) == 3

        # Budget exhausted
        ids2 = await backend.acquire("gpt-4o-mini", 1)
        assert len(ids2) == 0

        # Release and re-acquire
        await backend.release(ids[:2])
        ids3 = await backend.acquire("gpt-4o-mini", 5)
        assert len(ids3) == 2

    async def test_release_idempotent(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=5)])
        ids = await backend.acquire("gpt-4o-mini", 1)
        await backend.release(ids)
        await backend.release(ids)  # second release is a no-op

    async def test_release_unknown_is_noop(self) -> None:
        backend = MemoryBackend()
        await backend.release(["nonexistent-id"])


class TestGetUsage:
    async def test_usage_unregistered_model(self) -> None:
        backend = MemoryBackend()
        usage = await backend.get_usage("unknown")
        assert usage.requests_this_minute == 0

    async def test_usage_counts_requests(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=10)])
        await backend.acquire("gpt-4o-mini", 3)
        usage = await backend.get_usage("gpt-4o-mini")
        assert usage.requests_this_minute == 3
        assert usage.requests_today == 3


class TestTimeWindows:
    @time_machine.travel("2026-02-24 12:00:00+00:00", tick=False)
    async def test_minute_window_expiry(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=5)])

        # Acquire 5 slots at 12:00:00
        ids = await backend.acquire("gpt-4o-mini", 5)
        assert len(ids) == 5

        # No more available
        ids2 = await backend.acquire("gpt-4o-mini", 1)
        assert len(ids2) == 0

    async def test_minute_window_expires_after_60s(self) -> None:
        with time_machine.travel("2026-02-24 12:00:00+00:00", tick=False) as t:
            backend = MemoryBackend()
            await backend.register([_cfg(rpm=5)])

            ids = await backend.acquire("gpt-4o-mini", 5)
            assert len(ids) == 5
            # Mark as used so they can be pruned
            for sid in ids:
                await backend.record_usage(sid, input_tokens=10, output_tokens=10)

            # Move forward 61 seconds — minute window expires
            t.shift(datetime.timedelta(seconds=61))

            # Slots should no longer count toward minute usage
            usage = await backend.get_usage("gpt-4o-mini")
            assert usage.requests_this_minute == 0
            # But still count toward day
            assert usage.requests_today == 5

            # Can acquire again
            ids2 = await backend.acquire("gpt-4o-mini", 5)
            assert len(ids2) == 5

    async def test_day_window_reset(self) -> None:
        # Start at 11pm Pacific (7am UTC next day)
        with time_machine.travel("2026-02-24 23:00:00-08:00", tick=False) as t:
            backend = MemoryBackend()
            await backend.register([_cfg(rpd=5, rpm=None)])

            ids = await backend.acquire("gpt-4o-mini", 5)
            assert len(ids) == 5
            for sid in ids:
                await backend.record_usage(sid, input_tokens=10, output_tokens=10)

            # Move past midnight Pacific (2 hours)
            t.shift(datetime.timedelta(hours=2))
            await backend.refresh()

            # Day counter should reset
            usage = await backend.get_usage("gpt-4o-mini")
            assert usage.requests_today == 0


class TestRefresh:
    async def test_refresh_returns_budgets(self) -> None:
        backend = MemoryBackend()
        await backend.register(
            [
                _cfg(model_id="model-a", rpm=10),
                _cfg(model_id="model-b", rpm=20),
            ]
        )
        budgets = await backend.refresh()
        assert "model-a" in budgets
        assert "model-b" in budgets
        assert budgets["model-a"].available_slots == 10
        assert budgets["model-b"].available_slots == 20

    async def test_refresh_prunes_stale_slots(self) -> None:
        with time_machine.travel("2026-02-24 12:00:00+00:00", tick=False) as t:
            backend = MemoryBackend()
            await backend.register([_cfg(rpm=5)])

            ids = await backend.acquire("gpt-4o-mini", 3)
            for sid in ids:
                await backend.record_usage(sid, input_tokens=10, output_tokens=10)

            t.shift(datetime.timedelta(hours=25))
            await backend.refresh()

            # Stale records should be pruned (past both minute and day windows)
            assert len(backend._slots) == 0


class TestConcurrency:
    async def test_concurrent_acquire_no_double_allocation(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=10)])

        results = await asyncio.gather(*[backend.acquire("gpt-4o-mini", 3) for _ in range(5)])
        total = sum(len(r) for r in results)
        assert total == 10  # exactly the budget, no over-allocation


class TestTeardown:
    async def test_teardown_clears_state(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=10)])
        await backend.acquire("gpt-4o-mini", 5)
        await backend.teardown()

        assert len(backend._configs) == 0
        assert len(backend._slots) == 0

    async def test_context_manager(self) -> None:
        async with MemoryBackend() as backend:
            await backend.register([_cfg(rpm=10)])
            ids = await backend.acquire("gpt-4o-mini", 3)
            assert len(ids) == 3
        # After exit, state is cleared
        assert len(backend._configs) == 0
        assert len(backend._slots) == 0


class TestTokenBudget:
    async def test_token_limit_constrains_acquire(self) -> None:
        backend = MemoryBackend()
        # tpm=8000 with avg_tokens_per_request=4000 → 2 requests max
        await backend.register([_cfg(rpm=100, tpm=8000, avg_tokens_per_request=4000)])
        ids = await backend.acquire("gpt-4o-mini", 10)
        assert len(ids) == 2

    async def test_token_usage_reduces_budget(self) -> None:
        backend = MemoryBackend()
        await backend.register([_cfg(rpm=100, tpm=10000, avg_tokens_per_request=1000)])
        ids = await backend.acquire("gpt-4o-mini", 2)
        # Record 4000 tokens total on each slot
        for sid in ids:
            await backend.record_usage(sid, input_tokens=3000, output_tokens=1000)

        # 10000 tpm - 8000 used = 2000 remaining → 2 more requests
        usage = await backend.get_usage("gpt-4o-mini")
        assert usage.tokens_this_minute == 8000
        ids2 = await backend.acquire("gpt-4o-mini", 10)
        assert len(ids2) == 2
