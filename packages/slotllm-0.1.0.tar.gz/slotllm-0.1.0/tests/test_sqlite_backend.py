"""Tests for the SQLite slot backend."""

from __future__ import annotations

import asyncio
import datetime
import tempfile

import time_machine

from slotllm.backends.sqlite import SQLiteBackend
from slotllm.rate_limit import RateLimitConfig


def _cfg(
    model_id: str = "gpt-4o-mini",
    rpm: int | None = 10,
    rpd: int | None = None,
    tpm: int | None = None,
    tpd: int | None = None,
    avg_tokens_per_request: int = 4000,
) -> RateLimitConfig:
    return RateLimitConfig(
        model_id=model_id,
        rpm=rpm,
        rpd=rpd,
        tpm=tpm,
        tpd=tpd,
        avg_tokens_per_request=avg_tokens_per_request,
    )


def _tmp_db() -> str:
    return tempfile.mktemp(suffix=".db")


class TestLifecycle:
    async def test_basic_acquire_and_usage(self) -> None:
        async with SQLiteBackend(db_path=_tmp_db()) as backend:
            await backend.register([_cfg(rpm=5)])
            ids = await backend.acquire("gpt-4o-mini", 3)
            assert len(ids) == 3
            assert len(set(ids)) == 3

            usage = await backend.get_usage("gpt-4o-mini")
            assert usage.requests_this_minute == 3
            assert usage.requests_today == 3

    async def test_record_usage(self) -> None:
        async with SQLiteBackend(db_path=_tmp_db()) as backend:
            await backend.register([_cfg(rpm=10)])
            ids = await backend.acquire("gpt-4o-mini", 1)
            await backend.record_usage(ids[0], input_tokens=200, output_tokens=100)

            usage = await backend.get_usage("gpt-4o-mini")
            assert usage.tokens_this_minute == 300
            assert usage.tokens_today == 300

    async def test_release_frees_slots(self) -> None:
        async with SQLiteBackend(db_path=_tmp_db()) as backend:
            await backend.register([_cfg(rpm=3)])
            ids = await backend.acquire("gpt-4o-mini", 3)
            assert len(await backend.acquire("gpt-4o-mini", 1)) == 0

            await backend.release(ids[:2])
            ids2 = await backend.acquire("gpt-4o-mini", 5)
            assert len(ids2) == 2

    async def test_release_idempotent(self) -> None:
        async with SQLiteBackend(db_path=_tmp_db()) as backend:
            await backend.register([_cfg(rpm=5)])
            ids = await backend.acquire("gpt-4o-mini", 1)
            await backend.release(ids)
            await backend.release(ids)  # no error


class TestBudgetLimiting:
    async def test_partial_acquisition(self) -> None:
        async with SQLiteBackend(db_path=_tmp_db()) as backend:
            await backend.register([_cfg(rpm=3)])
            ids = await backend.acquire("gpt-4o-mini", 10)
            assert len(ids) == 3

    async def test_zero_budget(self) -> None:
        async with SQLiteBackend(db_path=_tmp_db()) as backend:
            await backend.register([_cfg(rpm=0)])
            ids = await backend.acquire("gpt-4o-mini", 5)
            assert len(ids) == 0

    async def test_unregistered_model(self) -> None:
        async with SQLiteBackend(db_path=_tmp_db()) as backend:
            ids = await backend.acquire("unknown", 5)
            assert len(ids) == 0

    async def test_token_limit_constrains(self) -> None:
        async with SQLiteBackend(db_path=_tmp_db()) as backend:
            await backend.register([_cfg(rpm=100, tpm=8000, avg_tokens_per_request=4000)])
            ids = await backend.acquire("gpt-4o-mini", 10)
            assert len(ids) == 2

    async def test_sequential_acquire_respects_budget(self) -> None:
        async with SQLiteBackend(db_path=_tmp_db()) as backend:
            await backend.register([_cfg(rpm=5)])
            ids1 = await backend.acquire("gpt-4o-mini", 3)
            ids2 = await backend.acquire("gpt-4o-mini", 3)
            assert len(ids1) == 3
            assert len(ids2) == 2


class TestTimeWindows:
    async def test_minute_window_expires(self) -> None:
        with time_machine.travel("2026-02-24 12:00:00+00:00", tick=False) as t:
            async with SQLiteBackend(db_path=_tmp_db()) as backend:
                await backend.register([_cfg(rpm=5)])
                ids = await backend.acquire("gpt-4o-mini", 5)
                for sid in ids:
                    await backend.record_usage(sid, input_tokens=10, output_tokens=10)

                t.shift(datetime.timedelta(seconds=61))

                usage = await backend.get_usage("gpt-4o-mini")
                assert usage.requests_this_minute == 0
                assert usage.requests_today == 5

                ids2 = await backend.acquire("gpt-4o-mini", 5)
                assert len(ids2) == 5

    async def test_day_window_reset(self) -> None:
        with time_machine.travel("2026-02-24 23:00:00-08:00", tick=False) as t:
            async with SQLiteBackend(db_path=_tmp_db()) as backend:
                await backend.register([_cfg(rpd=5, rpm=None)])
                ids = await backend.acquire("gpt-4o-mini", 5)
                for sid in ids:
                    await backend.record_usage(sid, input_tokens=10, output_tokens=10)

                t.shift(datetime.timedelta(hours=2))
                await backend.refresh()

                usage = await backend.get_usage("gpt-4o-mini")
                assert usage.requests_today == 0


class TestRefresh:
    async def test_refresh_returns_budgets(self) -> None:
        async with SQLiteBackend(db_path=_tmp_db()) as backend:
            await backend.register(
                [
                    _cfg(model_id="model-a", rpm=10),
                    _cfg(model_id="model-b", rpm=20),
                ]
            )
            budgets = await backend.refresh()
            assert budgets["model-a"].available_slots == 10
            assert budgets["model-b"].available_slots == 20

    async def test_refresh_prunes_stale(self) -> None:
        with time_machine.travel("2026-02-24 12:00:00+00:00", tick=False) as t:
            db = _tmp_db()
            async with SQLiteBackend(db_path=db) as backend:
                await backend.register([_cfg(rpm=5)])
                ids = await backend.acquire("gpt-4o-mini", 3)
                for sid in ids:
                    await backend.record_usage(sid, input_tokens=10, output_tokens=10)

                t.shift(datetime.timedelta(hours=25))
                await backend.refresh()

                usage = await backend.get_usage("gpt-4o-mini")
                assert usage.requests_today == 0
                assert usage.requests_this_minute == 0


class TestMultiInstance:
    async def test_two_instances_coordinate(self) -> None:
        """Two SQLiteBackend instances on the same file share the budget."""
        db = _tmp_db()
        async with SQLiteBackend(db_path=db) as b1, SQLiteBackend(db_path=db) as b2:
            await b1.register([_cfg(rpm=5)])
            ids1 = await b1.acquire("gpt-4o-mini", 3)
            assert len(ids1) == 3

            # Second instance sees the slots from the first
            ids2 = await b2.acquire("gpt-4o-mini", 5)
            assert len(ids2) == 2


class TestConcurrency:
    async def test_concurrent_acquire_no_over_allocation(self) -> None:
        async with SQLiteBackend(db_path=_tmp_db()) as backend:
            await backend.register([_cfg(rpm=10)])
            results = await asyncio.gather(*[backend.acquire("gpt-4o-mini", 3) for _ in range(5)])
            total = sum(len(r) for r in results)
            assert total == 10


class TestPersistence:
    async def test_config_persists_across_restarts(self) -> None:
        db = _tmp_db()
        async with SQLiteBackend(db_path=db) as backend:
            await backend.register([_cfg(rpm=5)])
            await backend.acquire("gpt-4o-mini", 2)

        # Reopen — config and slots should still be there
        async with SQLiteBackend(db_path=db) as backend:
            usage = await backend.get_usage("gpt-4o-mini")
            assert usage.requests_this_minute == 2


class TestContextManager:
    async def test_context_manager_initializes_and_tears_down(self) -> None:
        db = _tmp_db()
        async with SQLiteBackend(db_path=db) as backend:
            assert backend._conn is not None
        assert backend._conn is None


class TestImportGuard:
    def test_helpful_error_message(self) -> None:
        # We can't truly test a missing import without mocking, but we can
        # verify the module-level guard by checking the class is importable
        # when aiosqlite IS installed.
        from slotllm.backends.sqlite import SQLiteBackend as _  # noqa: F401
