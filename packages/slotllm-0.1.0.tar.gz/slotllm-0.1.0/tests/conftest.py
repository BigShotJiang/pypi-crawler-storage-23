"""Shared test fixtures for slotllm."""

from __future__ import annotations

import tempfile
from decimal import Decimal
from typing import Any

import pytest

from slotllm.backends.memory import MemoryBackend
from slotllm.caller import Response
from slotllm.cost import CostTracker
from slotllm.rate_limit import RateLimitConfig


class MockCaller:
    """Returns canned Responses with configurable delay and token counts."""

    def __init__(
        self,
        *,
        input_tokens: int = 10,
        output_tokens: int = 5,
        content: str = "mock response",
    ) -> None:
        self.call_count = 0
        self._input_tokens = input_tokens
        self._output_tokens = output_tokens
        self._content = content

    async def call(
        self,
        model_id: str,
        messages: list[dict[str, str]],
        **kwargs: Any,
    ) -> Response:
        self.call_count += 1
        return Response(
            content=self._content,
            input_tokens=self._input_tokens,
            output_tokens=self._output_tokens,
            model_id=model_id,
        )


class FailingCaller:
    """Raises exceptions at configurable call indices."""

    def __init__(self, *, fail_at: set[int] | None = None) -> None:
        self.call_count = 0
        self._fail_at = fail_at  # None means fail always

    async def call(
        self,
        model_id: str,
        messages: list[dict[str, str]],
        **kwargs: Any,
    ) -> Response:
        idx = self.call_count
        self.call_count += 1
        if self._fail_at is None or idx in self._fail_at:
            raise RuntimeError(f"Simulated failure at call {idx}")
        return Response(
            content="ok",
            input_tokens=10,
            output_tokens=5,
            model_id=model_id,
        )


@pytest.fixture
def mock_caller() -> MockCaller:
    return MockCaller()


@pytest.fixture
def failing_caller() -> FailingCaller:
    return FailingCaller()


@pytest.fixture
def sample_configs() -> list[RateLimitConfig]:
    return [
        RateLimitConfig(model_id="model-a", rpm=10, rpd=1000, priority=0),
        RateLimitConfig(model_id="model-b", rpm=20, rpd=5000, priority=1),
        RateLimitConfig(model_id="model-c", rpm=5, rpd=500, tpm=100000, priority=2),
    ]


@pytest.fixture
async def memory_backend() -> MemoryBackend:
    backend = MemoryBackend()
    yield backend  # type: ignore[misc]
    await backend.teardown()


@pytest.fixture
def tmp_db_path() -> str:
    return tempfile.mktemp(suffix=".db")


@pytest.fixture
async def sqlite_backend(tmp_db_path: str):  # type: ignore[no-untyped-def]
    from slotllm.backends.sqlite import SQLiteBackend

    backend = SQLiteBackend(db_path=tmp_db_path)
    await backend.initialize()
    yield backend
    await backend.teardown()


@pytest.fixture
def cost_tracker() -> CostTracker:
    tracker = CostTracker()
    tracker.register_price(
        "model-a",
        input_price_per_token=Decimal("0.0001"),
        output_price_per_token=Decimal("0.0002"),
    )
    tracker.register_price(
        "model-b",
        input_price_per_token=Decimal("0.0005"),
        output_price_per_token=Decimal("0.001"),
    )
    return tracker
