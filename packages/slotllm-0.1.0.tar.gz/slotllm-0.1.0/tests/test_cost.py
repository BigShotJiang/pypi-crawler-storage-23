"""Tests for the CostTracker."""

from __future__ import annotations

import logging
from decimal import Decimal

from slotllm.cost import CostTracker


class TestCalculate:
    def test_known_model_returns_nonzero(self) -> None:
        tracker = CostTracker()
        cost = tracker.calculate("gpt-4o-mini", input_tokens=1000, output_tokens=500)
        assert isinstance(cost, Decimal)
        assert cost > 0

    def test_unknown_model_returns_zero_with_warning(
        self, caplog: logging.LogCaptureFixture
    ) -> None:
        tracker = CostTracker()
        with caplog.at_level(logging.WARNING):
            cost = tracker.calculate(
                "totally-fake-model-xyz", input_tokens=1000, output_tokens=500
            )
        assert cost == Decimal("0")
        assert "Unknown model" in caplog.text

    def test_custom_price_override(self) -> None:
        tracker = CostTracker()
        tracker.register_price(
            "my-custom-model",
            input_price_per_token=Decimal("0.001"),
            output_price_per_token=Decimal("0.002"),
        )
        cost = tracker.calculate("my-custom-model", input_tokens=100, output_tokens=50)
        # 100 * 0.001 + 50 * 0.002 = 0.1 + 0.1 = 0.2
        assert cost == Decimal("0.2")

    def test_custom_price_overrides_tokencost(self) -> None:
        tracker = CostTracker()
        original_cost = tracker.calculate("gpt-4o-mini", input_tokens=1000, output_tokens=500)

        tracker.register_price(
            "gpt-4o-mini",
            input_price_per_token=Decimal("0"),
            output_price_per_token=Decimal("0"),
        )
        overridden_cost = tracker.calculate("gpt-4o-mini", input_tokens=1000, output_tokens=500)
        assert overridden_cost == Decimal("0")
        assert original_cost > overridden_cost


class TestRecord:
    def test_record_returns_cost(self) -> None:
        tracker = CostTracker()
        cost = tracker.record("gpt-4o-mini", input_tokens=1000, output_tokens=500)
        assert isinstance(cost, Decimal)
        assert cost > 0

    def test_accumulation(self) -> None:
        tracker = CostTracker()
        cost1 = tracker.record("gpt-4o-mini", input_tokens=1000, output_tokens=500)
        cost2 = tracker.record("gpt-4o-mini", input_tokens=2000, output_tokens=1000)
        assert tracker.total_cost == cost1 + cost2

    def test_per_model_breakdown(self) -> None:
        tracker = CostTracker()
        tracker.register_price(
            "model-a",
            input_price_per_token=Decimal("0.001"),
            output_price_per_token=Decimal("0.002"),
        )
        tracker.register_price(
            "model-b",
            input_price_per_token=Decimal("0.01"),
            output_price_per_token=Decimal("0.02"),
        )
        tracker.record("model-a", input_tokens=100, output_tokens=50)
        tracker.record("model-b", input_tokens=100, output_tokens=50)

        by_model = tracker.cost_by_model
        assert "model-a" in by_model
        assert "model-b" in by_model
        assert by_model["model-a"] == Decimal("0.2")  # 0.1 + 0.1
        assert by_model["model-b"] == Decimal("2.0")  # 1.0 + 1.0
        assert tracker.total_cost == Decimal("2.2")


class TestSummary:
    def test_summary_structure(self) -> None:
        tracker = CostTracker()
        tracker.register_price(
            "test-model",
            input_price_per_token=Decimal("0.001"),
            output_price_per_token=Decimal("0.002"),
        )
        tracker.record("test-model", input_tokens=100, output_tokens=50)
        tracker.record("test-model", input_tokens=200, output_tokens=100)

        s = tracker.summary()
        assert "total_cost_usd" in s
        assert "by_model" in s
        assert "total_requests" in s
        assert "total_input_tokens" in s
        assert "total_output_tokens" in s
        assert s["total_requests"] == 2
        assert s["total_input_tokens"] == 300
        assert s["total_output_tokens"] == 150

    def test_summary_empty(self) -> None:
        tracker = CostTracker()
        s = tracker.summary()
        assert s["total_cost_usd"] == Decimal("0")
        assert s["total_requests"] == 0


class TestReset:
    def test_reset_clears_all(self) -> None:
        tracker = CostTracker()
        tracker.record("gpt-4o-mini", input_tokens=1000, output_tokens=500)
        assert tracker.total_cost > 0

        tracker.reset()
        assert tracker.total_cost == Decimal("0")
        assert tracker.cost_by_model == {}
        s = tracker.summary()
        assert s["total_requests"] == 0
        assert s["total_input_tokens"] == 0
        assert s["total_output_tokens"] == 0
