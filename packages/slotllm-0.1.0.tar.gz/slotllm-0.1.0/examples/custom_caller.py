"""Bring Your Own Caller — use slotllm with any LLM client.

This example shows how to write a custom caller that wraps the
OpenAI Python client directly (without LiteLLM).

Usage:
    pip install slotllm openai
    export OPENAI_API_KEY="sk-..."
    python examples/custom_caller.py
"""

import asyncio
from typing import Any

from openai import AsyncOpenAI

from slotllm import BatchRunner, RateLimitConfig
from slotllm.backends.memory import MemoryBackend
from slotllm.caller import Response


class OpenAICaller:
    """A minimal Caller implementation wrapping openai.AsyncOpenAI."""

    def __init__(self) -> None:
        self.client = AsyncOpenAI()

    async def call(
        self,
        model_id: str,
        messages: list[dict[str, str]],
        **kwargs: Any,
    ) -> Response:
        resp = await self.client.chat.completions.create(
            model=model_id,
            messages=messages,
            **kwargs,
        )
        choice = resp.choices[0]
        return Response(
            content=choice.message.content,
            input_tokens=resp.usage.prompt_tokens if resp.usage else 0,
            output_tokens=resp.usage.completion_tokens if resp.usage else 0,
            model_id=model_id,
            raw=resp,
        )


async def main() -> None:
    caller = OpenAICaller()
    backend = MemoryBackend()
    configs = [RateLimitConfig(model_id="gpt-4o-mini", rpm=50, rpd=5000)]

    runner = BatchRunner(caller, backend, configs)
    results = await runner.run_simple(
        ["What is 2+2?", "Name three colors."],
        model_id="gpt-4o-mini",
    )

    for r in results:
        print(r.response.content)


if __name__ == "__main__":
    asyncio.run(main())
