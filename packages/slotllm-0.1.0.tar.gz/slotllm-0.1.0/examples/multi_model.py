"""Multi-model routing — automatic fallback from cheap to expensive model.

When the cheap model's budget runs out, slotllm routes remaining
items to the next available model automatically.

Usage:
    pip install "slotllm[litellm]"
    export OPENAI_API_KEY="sk-..."
    python examples/multi_model.py
"""

import asyncio

from slotllm import BatchRunner, RateLimitConfig, RequestItem
from slotllm.adapters.litellm import LiteLLMCaller
from slotllm.backends.memory import MemoryBackend


async def main() -> None:
    caller = LiteLLMCaller()
    backend = MemoryBackend()
    configs = [
        RateLimitConfig(model_id="gpt-4o-mini", rpm=100, rpd=5, priority=0),
        RateLimitConfig(model_id="gpt-4o", rpm=20, rpd=100, priority=1),
    ]

    # No model_id on items → auto-routed by priority
    items = [
        RequestItem(
            messages=[{"role": "user", "content": f"What is {i} + {i}?"}],
            metadata={"index": i},
        )
        for i in range(10)
    ]

    runner = BatchRunner(caller, backend, configs, poll_interval=0.5)
    results = await runner.run(items)

    for r in results:
        model = r.response.model_id
        print(f"[{model}] {r.response.content}")


if __name__ == "__main__":
    asyncio.run(main())
