"""Multi-worker coordination via SQLite backend.

Two workers share the same SQLite database so their combined request
count never exceeds the configured rate limits.

Usage:
    pip install "slotllm[litellm,sqlite]"
    export OPENAI_API_KEY="sk-..."
    python examples/sqlite_multi_worker.py
"""

import asyncio

from slotllm import BatchRunner, RateLimitConfig, RequestItem
from slotllm.adapters.litellm import LiteLLMCaller
from slotllm.backends.sqlite import SQLiteBackend

DB_PATH = "slots.db"
CONFIGS = [RateLimitConfig(model_id="gpt-4o-mini", rpm=10, rpd=100)]


def _items(worker_id: int, n: int) -> list[RequestItem]:
    return [
        RequestItem(
            messages=[{"role": "user", "content": f"Worker {worker_id}, item {i}"}],
            model_id="gpt-4o-mini",
            metadata={"worker": worker_id, "item": i},
        )
        for i in range(n)
    ]


async def worker(worker_id: int, n: int) -> None:
    caller = LiteLLMCaller()
    async with SQLiteBackend(db_path=DB_PATH) as backend:
        runner = BatchRunner(caller, backend, CONFIGS, poll_interval=1.0)
        results = await runner.run(_items(worker_id, n))
        ok = sum(1 for r in results if r.response is not None)
        print(f"Worker {worker_id}: {ok}/{n} succeeded")


async def main() -> None:
    # Run two workers concurrently — they coordinate via the shared DB
    await asyncio.gather(
        worker(1, 8),
        worker(2, 8),
    )


if __name__ == "__main__":
    asyncio.run(main())
