"""Minimal slotllm example — process a batch of prompts with rate limiting.

Usage:
    pip install "slotllm[litellm]"
    export OPENAI_API_KEY="sk-..."
    python examples/quickstart.py
"""

import asyncio

from slotllm import BatchRunner, RateLimitConfig
from slotllm.adapters.litellm import LiteLLMCaller
from slotllm.backends.memory import MemoryBackend


async def main() -> None:
    caller = LiteLLMCaller()
    backend = MemoryBackend()
    configs = [RateLimitConfig(model_id="gpt-4o-mini", rpm=50, rpd=5000)]

    async with BatchRunner(caller, backend, configs) as runner:
        results = await runner.run_simple(
            [
                "Summarize quantum computing in one sentence.",
                "What is the capital of France?",
                "Explain recursion to a 5-year-old.",
            ],
            model_id="gpt-4o-mini",
        )

    for i, r in enumerate(results):
        print(f"[{i}] {r.response.content}\n")


if __name__ == "__main__":
    asyncio.run(main())
