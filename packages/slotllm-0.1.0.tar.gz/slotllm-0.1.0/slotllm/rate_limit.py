from __future__ import annotations

import datetime
from zoneinfo import ZoneInfo

from pydantic import BaseModel, model_validator


class RateLimitConfig(BaseModel):
    """Configuration for a model's rate limits.

    At least one of rpm, rpd, tpm, or tpd must be set.
    """

    model_id: str
    rpm: int | None = None
    rpd: int | None = None
    tpm: int | None = None
    tpd: int | None = None
    avg_tokens_per_request: int = 4000
    daily_reset_tz: str = "US/Pacific"
    priority: int = 0

    @model_validator(mode="after")
    def _at_least_one_limit(self) -> RateLimitConfig:
        if self.rpm is None and self.rpd is None and self.tpm is None and self.tpd is None:
            raise ValueError("At least one of rpm, rpd, tpm, or tpd must be set")
        return self


class SlotBudget(BaseModel, frozen=True):
    """Result of a slot budget computation."""

    model_id: str
    available_slots: int
    computed_at: datetime.datetime


def compute_budget(
    config: RateLimitConfig,
    used_rpm: int = 0,
    used_rpd: int = 0,
    used_tpm: int = 0,
    used_tpd: int = 0,
) -> SlotBudget:
    """Compute how many requests can safely fire without exceeding any rate limit.

    For each dimension where a limit is set, calculates ``max(0, limit - used)``.
    Token headroom is converted to request headroom by dividing by
    ``avg_tokens_per_request``. The final budget is the minimum across all active
    dimensions.
    """
    headrooms: list[int] = []

    if config.rpm is not None:
        headrooms.append(max(0, config.rpm - used_rpm))
    if config.rpd is not None:
        headrooms.append(max(0, config.rpd - used_rpd))
    if config.tpm is not None:
        token_headroom = max(0, config.tpm - used_tpm)
        headrooms.append(token_headroom // config.avg_tokens_per_request)
    if config.tpd is not None:
        token_headroom = max(0, config.tpd - used_tpd)
        headrooms.append(token_headroom // config.avg_tokens_per_request)

    available = min(headrooms) if headrooms else 0

    return SlotBudget(
        model_id=config.model_id,
        available_slots=available,
        computed_at=datetime.datetime.now(datetime.timezone.utc),
    )


def get_daily_reset_boundary(tz_name: str) -> datetime.datetime:
    """Return the start-of-day in the given timezone as a UTC datetime.

    This is the boundary after which daily usage counters should reset.
    """
    tz = ZoneInfo(tz_name)
    now_in_tz = datetime.datetime.now(tz)
    start_of_day_local = now_in_tz.replace(hour=0, minute=0, second=0, microsecond=0)
    return start_of_day_local.astimezone(datetime.timezone.utc)
