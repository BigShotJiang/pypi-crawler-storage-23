"""Caller protocol and Response model.

The ``Caller`` protocol defines the interface that any LLM client must satisfy
to be used with slotllm's ``BatchRunner``. It uses structural typing
(``typing.Protocol``) so callers do **not** need to inherit from anything.

Example implementation wrapping ``openai.AsyncOpenAI``::

    from openai import AsyncOpenAI
    from slotllm.caller import Caller, Response

    class OpenAICaller:
        def __init__(self) -> None:
            self.client = AsyncOpenAI()

        async def call(
            self,
            model_id: str,
            messages: list[dict[str, str]],
            **kwargs,
        ) -> Response:
            resp = await self.client.chat.completions.create(
                model=model_id, messages=messages, **kwargs,
            )
            choice = resp.choices[0]
            return Response(
                content=choice.message.content,
                input_tokens=resp.usage.prompt_tokens,
                output_tokens=resp.usage.completion_tokens,
                model_id=model_id,
                raw=resp,
            )
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel


class Response(BaseModel):
    """Standardised response from an LLM call.

    Attributes:
        content: The LLM response — a string, Pydantic model, dict, or any
            other type depending on the caller implementation.
        input_tokens: Number of input (prompt) tokens consumed.
        output_tokens: Number of output (completion) tokens consumed.
        model_id: The model identifier used for this request.
        raw: The raw provider response object, if available.
        latency_ms: Wall-clock latency of the call in milliseconds.
    """

    content: Any = None
    input_tokens: int = 0
    output_tokens: int = 0
    model_id: str = ""
    raw: Any = None
    latency_ms: float | None = None


@runtime_checkable
class Caller(Protocol):
    """Protocol for an async LLM caller.

    Any object with a matching ``call`` method satisfies this protocol —
    no inheritance required.
    """

    async def call(
        self,
        model_id: str,
        messages: list[dict[str, str]],
        **kwargs: Any,
    ) -> Response: ...
