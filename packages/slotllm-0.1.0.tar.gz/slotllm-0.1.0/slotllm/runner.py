"""BatchRunner — the main entry point for slot-aware batch LLM processing."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass
from decimal import Decimal
from typing import Any, Callable

from slotllm.backends.base import SlotBackend
from slotllm.caller import Caller, Response
from slotllm.cost import CostTracker
from slotllm.rate_limit import RateLimitConfig

logger = logging.getLogger("slotllm")


class SlotTimeoutError(TimeoutError):
    """Raised when no slots become available within ``max_wait``."""


@dataclass
class RequestItem:
    """A single work item to be processed by the BatchRunner."""

    messages: list[dict[str, str]]
    model_id: str | None = None
    kwargs: dict[str, Any] | None = None
    metadata: Any = None


@dataclass
class BatchResult:
    """Result of a single request within a batch."""

    response: Response | None = None
    error: Exception | None = None
    cost_usd: Decimal = Decimal("0")
    slot_id: str = ""
    metadata: Any = None


@dataclass
class _PendingItem:
    """Internal tracking for an item being processed."""

    index: int
    item: RequestItem
    model_id: str = ""
    slot_id: str = ""


class BatchRunner:
    """Orchestrates batched LLM calls with rate-limit-aware concurrency.

    Ties together a :class:`SlotBackend` (for slot management), a
    :class:`Caller` (for LLM calls), and an optional :class:`CostTracker`.
    """

    def __init__(
        self,
        caller: Caller,
        backend: SlotBackend,
        configs: list[RateLimitConfig],
        *,
        cost_tracker: CostTracker | None = None,
        chunk_size: int = 10,
        poll_interval: float = 1.0,
        max_wait: float = 300.0,
        on_progress: Callable[[int, int], None] | None = None,
        on_result: Callable[[BatchResult], Any] | None = None,
    ) -> None:
        self._caller = caller
        self._backend = backend
        self._configs = configs
        self._cost_tracker = cost_tracker
        self._chunk_size = chunk_size
        self._poll_interval = poll_interval
        self._max_wait = max_wait
        self._on_progress = on_progress
        self._on_result = on_result
        self._on_result_is_async = asyncio.iscoroutinefunction(on_result)
        self._configs_by_id = {c.model_id: c for c in configs}

    async def __aenter__(self) -> BatchRunner:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self._backend.teardown()

    async def run(self, items: list[RequestItem]) -> list[BatchResult]:
        """Process all items and return results in input order."""
        await self._backend.register(self._configs)

        results: list[BatchResult | None] = [None] * len(items)
        pending = [_PendingItem(index=i, item=item) for i, item in enumerate(items)]
        completed = 0
        total = len(items)

        while pending:
            budgets = await self._backend.refresh()

            # Build assignment: map pending items to models with slots
            assigned, remaining = await self._assign_slots(pending, budgets)

            if not assigned:
                # No slots available — wait and retry
                waited = 0.0
                while not assigned and waited < self._max_wait:
                    logger.debug("No slots available, waiting %.1fs", self._poll_interval)
                    await asyncio.sleep(self._poll_interval)
                    waited += self._poll_interval
                    budgets = await self._backend.refresh()
                    assigned, remaining = await self._assign_slots(pending, budgets)

                if not assigned:
                    raise SlotTimeoutError(f"No slots available after waiting {self._max_wait}s")

            # Process assigned items in chunks
            for chunk_start in range(0, len(assigned), self._chunk_size):
                chunk = assigned[chunk_start : chunk_start + self._chunk_size]
                tasks = [self._process_one(p) for p in chunk]
                chunk_results = await asyncio.gather(*tasks, return_exceptions=True)

                for p_item, result in zip(chunk, chunk_results):
                    if isinstance(result, BaseException):
                        error_result = BatchResult(
                            error=result
                            if isinstance(result, Exception)
                            else Exception(str(result)),
                            slot_id=p_item.slot_id,
                            metadata=p_item.item.metadata,
                        )
                        await self._invoke_on_result(error_result)
                        results[p_item.index] = error_result
                        await self._backend.release([p_item.slot_id])
                    else:
                        results[p_item.index] = result

                    completed += 1
                    if self._on_progress:
                        self._on_progress(completed, total)

            pending = remaining

        return [r if r is not None else BatchResult() for r in results]

    async def run_simple(
        self, prompts: list[str], model_id: str, **kwargs: Any
    ) -> list[BatchResult]:
        """Convenience wrapper: turn a list of prompt strings into RequestItems."""
        items = [
            RequestItem(
                messages=[{"role": "user", "content": prompt}],
                model_id=model_id,
                kwargs=kwargs if kwargs else None,
            )
            for prompt in prompts
        ]
        return await self.run(items)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _invoke_on_result(self, result: BatchResult) -> None:
        """Invoke the on_result callback if set."""
        if self._on_result is not None:
            if self._on_result_is_async:
                await self._on_result(result)
            else:
                self._on_result(result)

    async def _assign_slots(
        self,
        pending: list[_PendingItem],
        budgets: dict[str, Any],
    ) -> tuple[list[_PendingItem], list[_PendingItem]]:
        """Assign models and acquire slots for pending items.

        Returns (assigned, remaining).
        """
        # Sort configs by priority (ascending)
        sorted_configs = sorted(self._configs, key=lambda c: c.priority)

        assigned: list[_PendingItem] = []
        remaining: list[_PendingItem] = []

        # Group items: those with explicit model_id vs auto-select
        for p in pending:
            model_id = p.item.model_id
            if model_id is not None:
                # Explicit model
                slot_ids = await self._backend.acquire(model_id, 1)
                if slot_ids:
                    p.model_id = model_id
                    p.slot_id = slot_ids[0]
                    assigned.append(p)
                else:
                    remaining.append(p)
            else:
                # Auto-select by priority
                acquired = False
                for cfg in sorted_configs:
                    slot_ids = await self._backend.acquire(cfg.model_id, 1)
                    if slot_ids:
                        p.model_id = cfg.model_id
                        p.slot_id = slot_ids[0]
                        assigned.append(p)
                        acquired = True
                        break
                if not acquired:
                    remaining.append(p)

        return assigned, remaining

    async def _process_one(self, p: _PendingItem) -> BatchResult:
        """Process a single item: call the LLM, record usage and cost."""
        call_kwargs = p.item.kwargs or {}
        resp = await self._caller.call(p.model_id, p.item.messages, **call_kwargs)

        await self._backend.record_usage(p.slot_id, resp.input_tokens, resp.output_tokens)

        cost = Decimal("0")
        if self._cost_tracker:
            cost = self._cost_tracker.record(p.model_id, resp.input_tokens, resp.output_tokens)

        result = BatchResult(
            response=resp,
            cost_usd=cost,
            slot_id=p.slot_id,
            metadata=p.item.metadata,
        )
        await self._invoke_on_result(result)
        return result
