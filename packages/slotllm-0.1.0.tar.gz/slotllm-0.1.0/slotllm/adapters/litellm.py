"""LiteLLM-based caller adapter with optional Instructor support."""

from __future__ import annotations

import logging
import time
from typing import Any

try:
    import litellm
    from litellm.exceptions import (
        AuthenticationError,
        BadRequestError,
        RateLimitError,
        ServiceUnavailableError,
    )
except ImportError as exc:
    raise ImportError(
        "The litellm adapter requires litellm. Install it with: pip install slotllm[litellm]"
    ) from exc

from tenacity import (
    retry,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from slotllm.caller import Response

logger = logging.getLogger(__name__)

_RETRYABLE = (RateLimitError, ServiceUnavailableError)
_NOT_RETRYABLE = (AuthenticationError, BadRequestError)


class LiteLLMCaller:
    """A :class:`~slotllm.caller.Caller` implementation backed by LiteLLM.

    Supports 100+ LLM providers through a single interface. Optionally
    integrates with `instructor` for validated Pydantic structured outputs.

    This caller does **not** manage rate limits — that is the backend's job.
    """

    def __init__(
        self,
        *,
        timeout: float = 60.0,
        max_retries: int = 3,
        **default_kwargs: Any,
    ) -> None:
        self._timeout = timeout
        self._max_retries = max_retries
        self._default_kwargs = default_kwargs

        # Build the retrying wrapper
        self._call_with_retry = retry(
            retry=retry_if_exception_type(_RETRYABLE),
            stop=stop_after_attempt(max_retries),
            wait=wait_exponential(min=1, max=30),
            reraise=True,
        )(self._raw_call)

    async def call(
        self,
        model_id: str,
        messages: list[dict[str, str]],
        **kwargs: Any,
    ) -> Response:
        """Make an LLM call via LiteLLM.

        If ``response_model`` is passed in *kwargs* and ``instructor`` is
        installed, the call uses Instructor's ``create`` method and the
        ``content`` field of the returned :class:`Response` will be a
        validated Pydantic model instance.
        """
        merged = {**self._default_kwargs, **kwargs}
        response_model = merged.pop("response_model", None)

        t0 = time.monotonic()

        if response_model is not None:
            result = await self._instructor_call(model_id, messages, response_model, merged)
        else:
            result = await self._call_with_retry(model_id, messages, merged)

        latency_ms = (time.monotonic() - t0) * 1000
        return Response(
            content=result["content"],
            input_tokens=result["input_tokens"],
            output_tokens=result["output_tokens"],
            model_id=model_id,
            raw=result["raw"],
            latency_ms=latency_ms,
        )

    async def _raw_call(
        self,
        model_id: str,
        messages: list[dict[str, str]],
        merged_kwargs: dict[str, Any],
    ) -> dict[str, Any]:
        response = await litellm.acompletion(
            model=model_id,
            messages=messages,
            timeout=self._timeout,
            num_retries=0,  # we handle retries ourselves
            **merged_kwargs,
        )

        input_tokens = 0
        output_tokens = 0
        if response.usage is not None:
            input_tokens = response.usage.prompt_tokens or 0
            output_tokens = response.usage.completion_tokens or 0
        else:
            logger.warning("No usage data in response for model %r", model_id)

        content = response.choices[0].message.content

        return {
            "content": content,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "raw": response,
        }

    async def _instructor_call(
        self,
        model_id: str,
        messages: list[dict[str, str]],
        response_model: type,
        merged_kwargs: dict[str, Any],
    ) -> dict[str, Any]:
        try:
            import instructor
        except ImportError as exc:
            raise ImportError(
                "Structured output with response_model requires instructor. "
                "Install it with: pip install slotllm[instructor]"
            ) from exc

        client = instructor.from_litellm(litellm.acompletion)

        response, completion = await client.chat.completions.create_with_completion(
            model=model_id,
            messages=messages,
            response_model=response_model,
            timeout=self._timeout,
            **merged_kwargs,
        )

        input_tokens = 0
        output_tokens = 0
        if completion.usage is not None:
            input_tokens = completion.usage.prompt_tokens or 0
            output_tokens = completion.usage.completion_tokens or 0

        return {
            "content": response,
            "input_tokens": input_tokens,
            "output_tokens": output_tokens,
            "raw": completion,
        }
