"""slotllm — rate-limit-aware concurrency for batch LLM workloads."""

from __future__ import annotations

from slotllm.backends.base import SlotBackend, Usage
from slotllm.backends.memory import MemoryBackend
from slotllm.caller import Caller, Response
from slotllm.cost import CostTracker
from slotllm.rate_limit import (
    RateLimitConfig,
    SlotBudget,
    compute_budget,
    get_daily_reset_boundary,
)
from slotllm.runner import BatchResult, BatchRunner, RequestItem, SlotTimeoutError

__all__ = [
    "BatchRunner",
    "Caller",
    "CostTracker",
    "MemoryBackend",
    "RateLimitConfig",
    "Response",
    "SlotBackend",
    "BatchResult",
    "RequestItem",
    "SlotBudget",
    "SlotTimeoutError",
    "Usage",
    "compute_budget",
    "get_daily_reset_boundary",
]
