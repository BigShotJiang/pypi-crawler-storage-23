from __future__ import annotations

import logging
import threading
from decimal import Decimal

from tokencost import calculate_cost_by_tokens

logger = logging.getLogger(__name__)


class CostTracker:
    """Tracks per-request costs using token counts and model pricing.

    Uses ``tokencost`` for price lookups. Custom prices can be registered
    via :meth:`register_price` for models not covered by tokencost.

    All monetary values use :class:`~decimal.Decimal` for financial precision.
    Thread-safe via :class:`threading.Lock`.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._cost_by_model: dict[str, Decimal] = {}
        self._requests_by_model: dict[str, int] = {}
        self._input_tokens_total: int = 0
        self._output_tokens_total: int = 0
        self._custom_prices: dict[str, tuple[Decimal, Decimal]] = {}

    def register_price(
        self,
        model_id: str,
        input_price_per_token: Decimal,
        output_price_per_token: Decimal,
    ) -> None:
        """Register a custom per-token price for a model.

        Overrides tokencost lookups for this model.
        """
        with self._lock:
            self._custom_prices[model_id] = (
                input_price_per_token,
                output_price_per_token,
            )

    def calculate(self, model_id: str, input_tokens: int, output_tokens: int) -> Decimal:
        """Calculate the cost of a single request without recording it."""
        custom = self._custom_prices.get(model_id)
        if custom is not None:
            input_price, output_price = custom
            return input_price * input_tokens + output_price * output_tokens

        try:
            input_cost = calculate_cost_by_tokens(input_tokens, model_id, "input")
            output_cost = calculate_cost_by_tokens(output_tokens, model_id, "output")
            return input_cost + output_cost
        except KeyError:
            logger.warning(
                "Unknown model %r for cost calculation; returning $0",
                model_id,
            )
            return Decimal("0")

    def record(self, model_id: str, input_tokens: int, output_tokens: int) -> Decimal:
        """Calculate cost and add it to running totals. Returns the cost."""
        cost = self.calculate(model_id, input_tokens, output_tokens)
        with self._lock:
            self._cost_by_model[model_id] = self._cost_by_model.get(model_id, Decimal("0")) + cost
            self._requests_by_model[model_id] = self._requests_by_model.get(model_id, 0) + 1
            self._input_tokens_total += input_tokens
            self._output_tokens_total += output_tokens
        return cost

    @property
    def total_cost(self) -> Decimal:
        """Total accumulated cost across all models."""
        with self._lock:
            return sum(self._cost_by_model.values(), Decimal("0"))

    @property
    def cost_by_model(self) -> dict[str, Decimal]:
        """Cost breakdown by model."""
        with self._lock:
            return dict(self._cost_by_model)

    def summary(self) -> dict[str, object]:
        """Return a summary of all tracked costs and usage."""
        with self._lock:
            return {
                "total_cost_usd": sum(self._cost_by_model.values(), Decimal("0")),
                "by_model": dict(self._cost_by_model),
                "total_requests": sum(self._requests_by_model.values()),
                "total_input_tokens": self._input_tokens_total,
                "total_output_tokens": self._output_tokens_total,
            }

    def reset(self) -> None:
        """Reset all tracked costs and usage counters."""
        with self._lock:
            self._cost_by_model.clear()
            self._requests_by_model.clear()
            self._input_tokens_total = 0
            self._output_tokens_total = 0
