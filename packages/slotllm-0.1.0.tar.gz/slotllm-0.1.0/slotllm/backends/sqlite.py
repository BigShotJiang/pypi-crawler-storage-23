from __future__ import annotations

import asyncio
import datetime
import uuid
from pathlib import Path

try:
    import aiosqlite
except ImportError as exc:
    raise ImportError(
        "The sqlite backend requires aiosqlite. Install it with: pip install slotllm[sqlite]"
    ) from exc

from slotllm.backends.base import SlotBackend, Usage
from slotllm.rate_limit import (
    RateLimitConfig,
    SlotBudget,
    compute_budget,
    get_daily_reset_boundary,
)

_UTC = datetime.timezone.utc

_CREATE_TABLES = """
CREATE TABLE IF NOT EXISTS slot_configs (
    model_id TEXT PRIMARY KEY,
    config_json TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS slots (
    slot_id TEXT PRIMARY KEY,
    model_id TEXT NOT NULL,
    acquired_at TEXT NOT NULL,
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    used INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS ix_slots_model_acquired
    ON slots (model_id, acquired_at);
"""


class SQLiteBackend(SlotBackend):
    """SQLite-backed slot backend for multi-process coordination.

    Uses WAL journal mode and an asyncio.Lock to serialize all writes,
    avoiding "database is locked" errors within a single process.
    Cross-process coordination is handled by SQLite's ``BEGIN IMMEDIATE``
    transaction locking.
    """

    def __init__(self, db_path: str | Path = "slotllm.db") -> None:
        self._db_path = str(db_path)
        self._conn: aiosqlite.Connection | None = None
        self._lock = asyncio.Lock()

    async def initialize(self) -> None:
        """Open the database connection, enable WAL mode, and create tables."""
        self._conn = await aiosqlite.connect(self._db_path, isolation_level=None)
        await self._conn.execute("PRAGMA journal_mode=WAL")
        await self._conn.execute("PRAGMA busy_timeout=5000")
        await self._conn.executescript(_CREATE_TABLES)

    async def __aenter__(self) -> SQLiteBackend:
        await self.initialize()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.teardown()

    # ------------------------------------------------------------------
    # SlotBackend implementation
    # ------------------------------------------------------------------

    async def register(self, configs: list[RateLimitConfig]) -> None:
        assert self._conn is not None
        async with self._lock:
            await self._conn.execute("BEGIN IMMEDIATE")
            try:
                for cfg in configs:
                    await self._conn.execute(
                        "INSERT OR REPLACE INTO slot_configs"
                        " (model_id, config_json) VALUES (?, ?)",
                        (cfg.model_id, cfg.model_dump_json()),
                    )
                await self._conn.execute("COMMIT")
            except Exception:
                await self._conn.execute("ROLLBACK")
                raise

    async def acquire(self, model_id: str, count: int) -> list[str]:
        assert self._conn is not None
        async with self._lock:
            cfg = await self._load_config(model_id)
            if cfg is None:
                return []

            await self._conn.execute("BEGIN IMMEDIATE")
            try:
                usage = await self._get_usage_from_db(model_id, cfg)
                budget = compute_budget(
                    cfg,
                    used_rpm=usage.requests_this_minute,
                    used_rpd=usage.requests_today,
                    used_tpm=usage.tokens_this_minute,
                    used_tpd=usage.tokens_today,
                )
                to_allocate = min(count, budget.available_slots)
                now = datetime.datetime.now(_UTC).isoformat()
                ids: list[str] = []
                for _ in range(to_allocate):
                    slot_id = str(uuid.uuid4())
                    await self._conn.execute(
                        "INSERT INTO slots (slot_id, model_id, acquired_at) VALUES (?, ?, ?)",
                        (slot_id, model_id, now),
                    )
                    ids.append(slot_id)
                await self._conn.execute("COMMIT")
                return ids
            except Exception:
                await self._conn.execute("ROLLBACK")
                raise

    async def release(self, slot_ids: list[str]) -> None:
        assert self._conn is not None
        async with self._lock:
            await self._conn.execute("BEGIN IMMEDIATE")
            try:
                for sid in slot_ids:
                    await self._conn.execute("DELETE FROM slots WHERE slot_id = ?", (sid,))
                await self._conn.execute("COMMIT")
            except Exception:
                await self._conn.execute("ROLLBACK")
                raise

    async def record_usage(self, slot_id: str, input_tokens: int, output_tokens: int) -> None:
        assert self._conn is not None
        async with self._lock:
            await self._conn.execute("BEGIN IMMEDIATE")
            try:
                await self._conn.execute(
                    "UPDATE slots SET input_tokens = ?, output_tokens = ?,"
                    " used = 1 WHERE slot_id = ?",
                    (input_tokens, output_tokens, slot_id),
                )
                await self._conn.execute("COMMIT")
            except Exception:
                await self._conn.execute("ROLLBACK")
                raise

    async def get_usage(self, model_id: str) -> Usage:
        assert self._conn is not None
        cfg = await self._load_config(model_id)
        if cfg is None:
            return Usage()
        return await self._get_usage_from_db(model_id, cfg)

    async def refresh(self) -> dict[str, SlotBudget]:
        assert self._conn is not None
        configs = await self._load_all_configs()
        budgets: dict[str, SlotBudget] = {}
        for cfg in configs.values():
            await self._prune_stale(cfg)
            usage = await self._get_usage_from_db(cfg.model_id, cfg)
            budgets[cfg.model_id] = compute_budget(
                cfg,
                used_rpm=usage.requests_this_minute,
                used_rpd=usage.requests_today,
                used_tpm=usage.tokens_this_minute,
                used_tpd=usage.tokens_today,
            )
        return budgets

    async def teardown(self) -> None:
        if self._conn is not None:
            await self._conn.close()
            self._conn = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _load_config(self, model_id: str) -> RateLimitConfig | None:
        assert self._conn is not None
        async with self._conn.execute(
            "SELECT config_json FROM slot_configs WHERE model_id = ?",
            (model_id,),
        ) as cursor:
            row = await cursor.fetchone()
        if row is None:
            return None
        return RateLimitConfig.model_validate_json(row[0])

    async def _load_all_configs(self) -> dict[str, RateLimitConfig]:
        assert self._conn is not None
        async with self._conn.execute("SELECT model_id, config_json FROM slot_configs") as cursor:
            rows = await cursor.fetchall()
        return {row[0]: RateLimitConfig.model_validate_json(row[1]) for row in rows}

    async def _get_usage_from_db(self, model_id: str, cfg: RateLimitConfig) -> Usage:
        assert self._conn is not None
        now = datetime.datetime.now(_UTC)
        minute_ago = (now - datetime.timedelta(seconds=60)).isoformat()
        day_boundary = get_daily_reset_boundary(cfg.daily_reset_tz).isoformat()

        tok = "input_tokens + output_tokens"
        async with self._conn.execute(
            f"""
            SELECT
                COUNT(*) FILTER (WHERE acquired_at >= ?),
                COUNT(*) FILTER (WHERE acquired_at >= ?),
                COALESCE(SUM(CASE WHEN acquired_at >= ?
                    THEN {tok} ELSE 0 END), 0),
                COALESCE(SUM(CASE WHEN acquired_at >= ?
                    THEN {tok} ELSE 0 END), 0)
            FROM slots WHERE model_id = ?
            """,
            (minute_ago, day_boundary, minute_ago, day_boundary, model_id),
        ) as cursor:
            row = await cursor.fetchone()

        if row is None:
            return Usage()
        return Usage(
            requests_this_minute=row[0],
            requests_today=row[1],
            tokens_this_minute=row[2],
            tokens_today=row[3],
        )

    async def _prune_stale(self, cfg: RateLimitConfig) -> None:
        """Remove completed slots outside the day window."""
        assert self._conn is not None
        day_boundary = get_daily_reset_boundary(cfg.daily_reset_tz).isoformat()
        async with self._lock:
            await self._conn.execute("BEGIN IMMEDIATE")
            try:
                await self._conn.execute(
                    "DELETE FROM slots WHERE model_id = ? AND used = 1 AND acquired_at < ?",
                    (cfg.model_id, day_boundary),
                )
                await self._conn.execute("COMMIT")
            except Exception:
                await self._conn.execute("ROLLBACK")
                raise
