"""Abstract base class for slot storage backends.

Contract
--------
- **register**: Stores rate-limit configurations. May be called multiple times;
  later calls update existing entries for the same ``model_id``.
- **acquire**: Claims up to ``count`` slots for a model. Returns slot IDs (UUIDs).
  Returns fewer than requested if fewer are available. Never blocks.
- **release**: Releases previously acquired slots. Idempotent — releasing an
  already-released or unknown slot ID is a no-op.
- **record_usage**: Records actual token usage for a completed request tied to a
  slot. Must be called after the LLM response is received.
- **get_usage**: Returns current usage counters for a model within the active
  time windows (current minute, current day).
- **refresh**: Recalculates available budgets for all registered models using
  current usage and rate-limit configs.
- **teardown**: Releases all resources held by the backend.

All mutating methods must be safe for concurrent use within a single event loop.
Backends backed by a database should use appropriate locking or transactions to
ensure atomicity across processes.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING

from pydantic import BaseModel

if TYPE_CHECKING:
    from slotllm.rate_limit import RateLimitConfig, SlotBudget


class Usage(BaseModel, frozen=True):
    """Snapshot of current usage counters for a single model."""

    requests_this_minute: int = 0
    requests_today: int = 0
    tokens_this_minute: int = 0
    tokens_today: int = 0


class SlotBackend(ABC):
    """Abstract base class that all slot storage backends must implement."""

    @abstractmethod
    async def register(self, configs: list[RateLimitConfig]) -> None:
        """Store rate-limit configurations for one or more models."""
        ...

    @abstractmethod
    async def acquire(self, model_id: str, count: int) -> list[str]:
        """Claim up to *count* slots for *model_id*.

        Returns a list of slot ID strings (UUIDs). The list may be shorter than
        *count* if fewer slots are available. Never blocks.
        """
        ...

    @abstractmethod
    async def release(self, slot_ids: list[str]) -> None:
        """Release previously acquired slots. Idempotent."""
        ...

    @abstractmethod
    async def record_usage(self, slot_id: str, input_tokens: int, output_tokens: int) -> None:
        """Record actual token usage for a completed request."""
        ...

    @abstractmethod
    async def get_usage(self, model_id: str) -> Usage:
        """Return current usage counters for *model_id*."""
        ...

    @abstractmethod
    async def refresh(self) -> dict[str, SlotBudget]:
        """Recalculate available budgets for all registered models."""
        ...

    @abstractmethod
    async def teardown(self) -> None:
        """Clean up all resources held by this backend."""
        ...

    async def __aenter__(self) -> SlotBackend:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.teardown()
