from __future__ import annotations

import asyncio
import datetime
import uuid
from dataclasses import dataclass, field

from slotllm.backends.base import SlotBackend, Usage
from slotllm.rate_limit import (
    RateLimitConfig,
    SlotBudget,
    compute_budget,
    get_daily_reset_boundary,
)

_UTC = datetime.timezone.utc


@dataclass
class SlotRecord:
    """Internal record for an acquired slot."""

    model_id: str
    acquired_at: datetime.datetime = field(default_factory=lambda: datetime.datetime.now(_UTC))
    input_tokens: int = 0
    output_tokens: int = 0
    used: bool = False


class MemoryBackend(SlotBackend):
    """In-memory slot backend for single-process use.

    All state lives in Python dicts protected by an ``asyncio.Lock``.
    Suitable for single-process, single-event-loop workloads with no
    infrastructure requirements.
    """

    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._configs: dict[str, RateLimitConfig] = {}
        self._slots: dict[str, SlotRecord] = {}

    async def register(self, configs: list[RateLimitConfig]) -> None:
        async with self._lock:
            for cfg in configs:
                self._configs[cfg.model_id] = cfg

    async def acquire(self, model_id: str, count: int) -> list[str]:
        async with self._lock:
            cfg = self._configs.get(model_id)
            if cfg is None:
                return []

            usage = self._get_usage_unlocked(model_id, cfg)
            budget = compute_budget(
                cfg,
                used_rpm=usage.requests_this_minute,
                used_rpd=usage.requests_today,
                used_tpm=usage.tokens_this_minute,
                used_tpd=usage.tokens_today,
            )

            to_allocate = min(count, budget.available_slots)
            ids: list[str] = []
            for _ in range(to_allocate):
                slot_id = str(uuid.uuid4())
                self._slots[slot_id] = SlotRecord(model_id=model_id)
                ids.append(slot_id)
            return ids

    async def release(self, slot_ids: list[str]) -> None:
        async with self._lock:
            for sid in slot_ids:
                self._slots.pop(sid, None)

    async def record_usage(self, slot_id: str, input_tokens: int, output_tokens: int) -> None:
        async with self._lock:
            record = self._slots.get(slot_id)
            if record is None:
                return
            record.input_tokens = input_tokens
            record.output_tokens = output_tokens
            record.used = True

    async def get_usage(self, model_id: str) -> Usage:
        async with self._lock:
            cfg = self._configs.get(model_id)
            if cfg is None:
                return Usage()
            return self._get_usage_unlocked(model_id, cfg)

    async def refresh(self) -> dict[str, SlotBudget]:
        async with self._lock:
            self._prune_stale()
            budgets: dict[str, SlotBudget] = {}
            for model_id, cfg in self._configs.items():
                usage = self._get_usage_unlocked(model_id, cfg)
                budgets[model_id] = compute_budget(
                    cfg,
                    used_rpm=usage.requests_this_minute,
                    used_rpd=usage.requests_today,
                    used_tpm=usage.tokens_this_minute,
                    used_tpd=usage.tokens_today,
                )
            return budgets

    async def teardown(self) -> None:
        async with self._lock:
            self._configs.clear()
            self._slots.clear()

    # ------------------------------------------------------------------
    # Internal helpers (must be called while holding self._lock)
    # ------------------------------------------------------------------

    def _get_usage_unlocked(self, model_id: str, cfg: RateLimitConfig) -> Usage:
        now = datetime.datetime.now(_UTC)
        minute_ago = now - datetime.timedelta(seconds=60)
        day_boundary = get_daily_reset_boundary(cfg.daily_reset_tz)

        rpm_count = 0
        rpd_count = 0
        tpm = 0
        tpd = 0

        for rec in self._slots.values():
            if rec.model_id != model_id:
                continue
            if rec.acquired_at >= minute_ago:
                rpm_count += 1
                tpm += rec.input_tokens + rec.output_tokens
            if rec.acquired_at >= day_boundary:
                rpd_count += 1
                tpd += rec.input_tokens + rec.output_tokens

        return Usage(
            requests_this_minute=rpm_count,
            requests_today=rpd_count,
            tokens_this_minute=tpm,
            tokens_today=tpd,
        )

    def _prune_stale(self) -> None:
        """Remove completed slots that have fallen outside the minute window.

        Day-window records are retained until the daily reset boundary.
        """
        now = datetime.datetime.now(_UTC)
        minute_ago = now - datetime.timedelta(seconds=60)

        stale_ids: list[str] = []
        for slot_id, rec in self._slots.items():
            if not rec.used:
                continue
            if rec.acquired_at < minute_ago:
                cfg = self._configs.get(rec.model_id)
                if cfg is None:
                    stale_ids.append(slot_id)
                    continue
                day_boundary = get_daily_reset_boundary(cfg.daily_reset_tz)
                if rec.acquired_at < day_boundary:
                    stale_ids.append(slot_id)

        for slot_id in stale_ids:
            del self._slots[slot_id]
