from __future__ import annotations

import datetime
import uuid

try:
    import psycopg
    from psycopg.rows import tuple_row
    from psycopg_pool import AsyncConnectionPool
except ImportError as exc:
    raise ImportError(
        "The postgres backend requires psycopg and psycopg_pool. "
        "Install them with: pip install slotllm[postgres]"
    ) from exc

from slotllm.backends.base import SlotBackend, Usage
from slotllm.rate_limit import (
    RateLimitConfig,
    SlotBudget,
    compute_budget,
    get_daily_reset_boundary,
)

_UTC = datetime.timezone.utc

_CREATE_TABLES = """
CREATE TABLE IF NOT EXISTS slotllm_configs (
    model_id TEXT PRIMARY KEY,
    config_json JSONB NOT NULL
);
CREATE TABLE IF NOT EXISTS slotllm_slots (
    slot_id UUID PRIMARY KEY,
    model_id TEXT NOT NULL,
    acquired_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    used BOOLEAN DEFAULT FALSE
);
CREATE INDEX IF NOT EXISTS ix_slotllm_slots_model_acquired
    ON slotllm_slots (model_id, acquired_at);
"""


class PostgresBackend(SlotBackend):
    """PostgreSQL-backed slot backend for distributed coordination.

    Uses ``psycopg_pool.AsyncConnectionPool`` for connection management and
    atomic transactions with ``SELECT ... FOR UPDATE`` semantics to prevent
    concurrent over-allocation across multiple processes and machines.
    """

    def __init__(
        self,
        dsn: str,
        min_pool_size: int = 2,
        max_pool_size: int = 10,
    ) -> None:
        self._dsn = dsn
        self._min_pool_size = min_pool_size
        self._max_pool_size = max_pool_size
        self._pool: AsyncConnectionPool | None = None

    async def initialize(self) -> None:
        """Open the connection pool and create tables if they don't exist."""
        self._pool = AsyncConnectionPool(
            self._dsn,
            min_size=self._min_pool_size,
            max_size=self._max_pool_size,
            open=False,
        )
        await self._pool.open()
        async with self._pool.connection() as conn:
            await conn.execute(_CREATE_TABLES)  # type: ignore[arg-type]

    async def __aenter__(self) -> PostgresBackend:
        await self.initialize()
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.teardown()

    # ------------------------------------------------------------------
    # SlotBackend implementation
    # ------------------------------------------------------------------

    async def register(self, configs: list[RateLimitConfig]) -> None:
        assert self._pool is not None
        async with self._pool.connection() as conn:
            for cfg in configs:
                await conn.execute(
                    """
                    INSERT INTO slotllm_configs (model_id, config_json)
                    VALUES (%s, %s::jsonb)
                    ON CONFLICT (model_id)
                    DO UPDATE SET config_json = EXCLUDED.config_json
                    """,
                    (cfg.model_id, cfg.model_dump_json()),
                )

    async def acquire(self, model_id: str, count: int) -> list[str]:
        assert self._pool is not None
        async with self._pool.connection() as conn:
            async with conn.transaction():
                cfg = await self._load_config_with_conn(conn, model_id)
                if cfg is None:
                    return []

                usage = await self._get_usage_with_conn(conn, model_id, cfg)
                budget = compute_budget(
                    cfg,
                    used_rpm=usage.requests_this_minute,
                    used_rpd=usage.requests_today,
                    used_tpm=usage.tokens_this_minute,
                    used_tpd=usage.tokens_today,
                )
                to_allocate = min(count, budget.available_slots)
                if to_allocate <= 0:
                    return []

                now = datetime.datetime.now(_UTC)
                ids: list[str] = []
                for _ in range(to_allocate):
                    slot_id = str(uuid.uuid4())
                    await conn.execute(
                        """
                        INSERT INTO slotllm_slots
                            (slot_id, model_id, acquired_at)
                        VALUES (%s, %s, %s)
                        """,
                        (slot_id, model_id, now),
                    )
                    ids.append(slot_id)
                return ids

    async def release(self, slot_ids: list[str]) -> None:
        assert self._pool is not None
        if not slot_ids:
            return
        async with self._pool.connection() as conn:
            for sid in slot_ids:
                await conn.execute(
                    "DELETE FROM slotllm_slots WHERE slot_id = %s",
                    (sid,),
                )

    async def record_usage(self, slot_id: str, input_tokens: int, output_tokens: int) -> None:
        assert self._pool is not None
        async with self._pool.connection() as conn:
            await conn.execute(
                """
                UPDATE slotllm_slots
                SET input_tokens = %s, output_tokens = %s, used = TRUE
                WHERE slot_id = %s
                """,
                (input_tokens, output_tokens, slot_id),
            )

    async def get_usage(self, model_id: str) -> Usage:
        assert self._pool is not None
        async with self._pool.connection() as conn:
            cfg = await self._load_config_with_conn(conn, model_id)
            if cfg is None:
                return Usage()
            return await self._get_usage_with_conn(conn, model_id, cfg)

    async def refresh(self) -> dict[str, SlotBudget]:
        assert self._pool is not None
        async with self._pool.connection() as conn:
            configs = await self._load_all_configs_with_conn(conn)
            budgets: dict[str, SlotBudget] = {}
            for cfg in configs.values():
                await self._prune_stale_with_conn(conn, cfg)
                usage = await self._get_usage_with_conn(conn, cfg.model_id, cfg)
                budgets[cfg.model_id] = compute_budget(
                    cfg,
                    used_rpm=usage.requests_this_minute,
                    used_rpd=usage.requests_today,
                    used_tpm=usage.tokens_this_minute,
                    used_tpd=usage.tokens_today,
                )
            return budgets

    async def teardown(self) -> None:
        if self._pool is not None:
            await self._pool.close()
            self._pool = None

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _load_config_with_conn(
        self,
        conn: psycopg.AsyncConnection[tuple_row],
        model_id: str,
    ) -> RateLimitConfig | None:
        cur = await conn.execute(
            "SELECT config_json::text FROM slotllm_configs WHERE model_id = %s",
            (model_id,),
        )
        row = await cur.fetchone()
        if row is None:
            return None
        return RateLimitConfig.model_validate_json(row[0])

    async def _load_all_configs_with_conn(
        self,
        conn: psycopg.AsyncConnection[tuple_row],
    ) -> dict[str, RateLimitConfig]:
        cur = await conn.execute("SELECT model_id, config_json::text FROM slotllm_configs")
        rows = await cur.fetchall()
        return {row[0]: RateLimitConfig.model_validate_json(row[1]) for row in rows}

    async def _get_usage_with_conn(
        self,
        conn: psycopg.AsyncConnection[tuple_row],
        model_id: str,
        cfg: RateLimitConfig,
    ) -> Usage:
        now = datetime.datetime.now(_UTC)
        minute_ago = now - datetime.timedelta(seconds=60)
        day_boundary = get_daily_reset_boundary(cfg.daily_reset_tz)

        cur = await conn.execute(
            """
            SELECT
                COUNT(*) FILTER (WHERE acquired_at >= %s),
                COUNT(*) FILTER (WHERE acquired_at >= %s),
                COALESCE(SUM(input_tokens + output_tokens)
                    FILTER (WHERE acquired_at >= %s), 0),
                COALESCE(SUM(input_tokens + output_tokens)
                    FILTER (WHERE acquired_at >= %s), 0)
            FROM slotllm_slots
            WHERE model_id = %s
            """,
            (minute_ago, day_boundary, minute_ago, day_boundary, model_id),
        )
        row = await cur.fetchone()
        if row is None:
            return Usage()
        return Usage(
            requests_this_minute=row[0],
            requests_today=row[1],
            tokens_this_minute=row[2],
            tokens_today=row[3],
        )

    async def _prune_stale_with_conn(
        self,
        conn: psycopg.AsyncConnection[tuple_row],
        cfg: RateLimitConfig,
    ) -> None:
        """Remove completed slots outside the day window."""
        day_boundary = get_daily_reset_boundary(cfg.daily_reset_tz)
        await conn.execute(
            """
            DELETE FROM slotllm_slots
            WHERE model_id = %s AND used = TRUE AND acquired_at < %s
            """,
            (cfg.model_id, day_boundary),
        )
