"""Cloud Agent — run a coding agent on a repo and create a PR.

This is the core orchestrator. It:
1. Validates the repo and creates a branch
2. Runs the wafer rollouts agent with LocalFilesystemEnvironment
3. Commits, pushes, and creates a PR via GitHub REST API
4. Streams progress events throughout
"""
from __future__ import annotations

import json
import shutil
import sys
import time
from collections.abc import Awaitable, Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import trio

from wafer.core.rollouts.dtypes import (
    Endpoint,
)
from wafer.core.rollouts.environments.localfs import LocalFilesystemEnvironment
from wafer.core.rollouts.frontends import NoneFrontend

from .git_ops import (
    commit_changes,
    create_branch,
    generate_branch_name,
    get_diff_summary,
    is_remote_url,
    push_branch,
    resolve_repo,
    restore_branch,
    validate_repo,
)
from .github_api import create_pull_request


@dataclass(frozen=True)
class CloudAgentConfig:
    """Configuration for a cloud agent run."""

    repo_path: Path | str  # local path or remote URL (https://..., git@...)
    prompt: str
    branch_name: str | None = None  # auto-generated if None
    base_branch: str | None = None  # defaults to current branch
    max_turns: int = 50
    model: str | None = None
    no_pr: bool = False


@dataclass(frozen=True)
class CloudAgentResult:
    """Result from a cloud agent run."""

    pr_url: str | None = None
    branch_name: str = ""
    commit_count: int = 0
    error: str | None = None
    session_id: str | None = None
    local_path: str | None = None  # path to cloned repo if cleanup was skipped


@dataclass(frozen=True)
class CloudAgentEvent:
    """Progress event emitted during cloud agent execution."""

    type: str  # "status" | "agent_event" | "git_progress" | "pr_created" | "error"
    message: str
    data: dict[str, Any] | None = None

    def to_json(self) -> str:
        d: dict[str, Any] = {"type": self.type, "message": self.message}
        if self.data:
            d["data"] = self.data
        return json.dumps(d, ensure_ascii=False)


CLOUD_AGENT_SYSTEM_PROMPT = """\
You are a coding agent working on a git repository.
Your task is to make the requested changes carefully and completely.
When you are done, stop. Do not ask for confirmation or further input.

Guidelines:
- Read relevant files first to understand context before making changes
- Make precise, focused edits
- Actually execute and verify your work — do not just write scripts for later
- Run tests or linting if appropriate
- Prefer small, targeted changes over large rewrites
- Do NOT run git add, git commit, git push, or create PRs — the system handles that automatically after you finish
- Do NOT write README files, summaries, or documentation unless explicitly asked

You have the `wafer` CLI available. Load the wafer-guide skill for detailed usage.
Key commands:
- `wafer target list` — list available GPU workspaces
- `wafer target sync --name <ws>` — sync repo to a workspace
- `wafer target run --name <ws> -- "<cmd>"` — run a command on a workspace
- `wafer tool roofline` — run roofline analysis
- `wafer agent ask-docs "<question>"` — query wafer documentation

Task: {prompt}

Repository: {repo_path}
Branch: {branch_name}
"""


async def _emit(
    on_event: Callable[[CloudAgentEvent], Awaitable[None]] | None,
    event: CloudAgentEvent,
) -> None:
    """Emit an event if callback is provided."""
    if on_event:
        await on_event(event)


async def run_cloud_agent(
    config: CloudAgentConfig,
    endpoint: Endpoint,
    on_event: Callable[[CloudAgentEvent], Awaitable[None]] | None = None,
    frontend: object | None = None,
) -> CloudAgentResult:
    """Run a coding agent on a repo and create a PR with the changes.

    Args:
        config: Cloud agent configuration (repo, prompt, etc.)
        endpoint: LLM endpoint configuration.
        on_event: Optional async callback for progress events.
        frontend: Optional frontend for agent output. If None, uses NoneFrontend.

    Returns:
        CloudAgentResult with PR URL on success, or error details on failure.
    """
    original_branch: str | None = None
    branch_name = ""
    cloned = False
    repo_path: Path | None = None

    try:
        # ── Step 0: Resolve repo (clone if remote URL) ───────────────────
        repo_str = str(config.repo_path)
        if is_remote_url(repo_str):
            await _emit(on_event, CloudAgentEvent("status", f"Cloning {repo_str}..."))
            repo_path, cloned = await resolve_repo(repo_str)
            await _emit(on_event, CloudAgentEvent("git_progress", f"Cloned to {repo_path}"))
        else:
            repo_path = Path(repo_str).resolve()

        # ── Step 1: Validate repo ────────────────────────────────────────
        await _emit(on_event, CloudAgentEvent("status", "Validating repository..."))
        remote_url, current_branch = await validate_repo(repo_path)
        original_branch = current_branch
        base_branch = config.base_branch or current_branch
        await _emit(
            on_event,
            CloudAgentEvent(
                "status",
                f"Repository validated: remote={remote_url}, branch={current_branch}",
            ),
        )

        # ── Step 2: Create branch ────────────────────────────────────────
        branch_name = config.branch_name or generate_branch_name(config.prompt)
        await _emit(on_event, CloudAgentEvent("status", f"Creating branch {branch_name}..."))
        await create_branch(repo_path, branch_name, base_branch)
        await _emit(
            on_event,
            CloudAgentEvent("git_progress", f"Created branch {branch_name}"),
        )

        # ── Step 3: Set up environment and run agent ─────────────────────
        await _emit(on_event, CloudAgentEvent("status", "Starting coding agent..."))

        environment = LocalFilesystemEnvironment(
            working_dir=repo_path,
            tools="full",
        )

        system_prompt = CLOUD_AGENT_SYSTEM_PROMPT.format(
            prompt=config.prompt,
            repo_path=repo_path,
            branch_name=branch_name,
        )

        agent_frontend = frontend or NoneFrontend(show_tool_calls=True, show_thinking=False)

        from wafer.core.rollouts.agent_session import AgentSessionConfig, run_agent_session

        session_config = AgentSessionConfig(
            prompt=config.prompt,
            system_prompt=system_prompt,
            endpoint=endpoint,
            environment=environment,
            frontend=agent_frontend,
            single_turn=True,
            max_turns=config.max_turns,
        )

        result = await run_agent_session(session_config)

        session_id = result.session_id
        await _emit(on_event, CloudAgentEvent("status", "Agent completed"))

        # ── Step 4: Commit changes ───────────────────────────────────────
        await _emit(on_event, CloudAgentEvent("status", "Committing changes..."))
        prompt_summary = config.prompt[:97] + "..." if len(config.prompt) > 100 else config.prompt
        commit_msg = f"cloud-agent: {prompt_summary}"
        commit_hash = await commit_changes(repo_path, commit_msg)

        if not commit_hash:
            await _emit(
                on_event,
                CloudAgentEvent("error", "Agent made no changes to commit"),
            )
            # Restore original branch (local repos only)
            if original_branch and not cloned:
                await restore_branch(repo_path, original_branch)
            # Clean up cloned repos on no-changes (nothing to preserve)
            if cloned and repo_path and repo_path.exists():
                shutil.rmtree(repo_path, ignore_errors=True)
            return CloudAgentResult(
                branch_name=branch_name,
                error="Agent made no changes to commit",
                session_id=session_id,
            )

        await _emit(
            on_event,
            CloudAgentEvent("git_progress", f"Committed: {commit_hash[:8]}"),
        )

        # ── Step 5: Push branch ──────────────────────────────────────────
        await _emit(on_event, CloudAgentEvent("status", "Pushing branch..."))
        await push_branch(repo_path, branch_name)
        await _emit(
            on_event,
            CloudAgentEvent("git_progress", f"Pushed {branch_name} to origin"),
        )

        # ── Step 6: Create PR (unless --no-pr) ────────────────────────────
        if config.no_pr:
            await _emit(
                on_event,
                CloudAgentEvent("status", "Skipping PR creation (--no-pr)"),
            )
            # Push succeeded — safe to clean up cloned repo
            if cloned and repo_path and repo_path.exists():
                shutil.rmtree(repo_path, ignore_errors=True)
            return CloudAgentResult(
                branch_name=branch_name,
                commit_count=1,
                session_id=session_id,
            )

        await _emit(on_event, CloudAgentEvent("status", "Creating pull request..."))

        diff_summary = await get_diff_summary(repo_path, base_branch)
        pr_title = config.prompt[:70]
        pr_body = (
            f"## Changes\n\n"
            f"**Prompt:** {config.prompt}\n\n"
            f"**Branch:** `{branch_name}`\n\n"
            f"```\n{diff_summary}\n```\n\n"
            f"---\n"
            f"*Created by cloud-agent*"
        )

        try:
            pr_url = await create_pull_request(
                remote_url=remote_url,
                branch=branch_name,
                base=base_branch,
                title=pr_title,
                body=pr_body,
            )
            await _emit(
                on_event,
                CloudAgentEvent("pr_created", pr_url, {"pr_url": pr_url}),
            )
            # Success — safe to clean up cloned repo
            if cloned and repo_path and repo_path.exists():
                shutil.rmtree(repo_path, ignore_errors=True)
            return CloudAgentResult(
                pr_url=pr_url,
                branch_name=branch_name,
                commit_count=1,
                session_id=session_id,
            )
        except (ValueError, RuntimeError) as e:
            # PR creation failed, but changes are pushed — safe to clean up
            error_msg = f"PR creation failed ({e}), but branch {branch_name} was pushed"
            await _emit(on_event, CloudAgentEvent("error", error_msg))
            if cloned and repo_path and repo_path.exists():
                shutil.rmtree(repo_path, ignore_errors=True)
            return CloudAgentResult(
                branch_name=branch_name,
                commit_count=1,
                error=error_msg,
                session_id=session_id,
            )

    except Exception as e:
        error_msg = f"{type(e).__name__}: {e}"
        await _emit(on_event, CloudAgentEvent("error", error_msg))

        # Try to restore original branch on failure (only for local repos)
        if original_branch and branch_name and repo_path and not cloned:
            try:
                await restore_branch(repo_path, original_branch)
            except Exception:
                pass

        # Preserve cloned repo so work isn't lost
        local_path = str(repo_path) if cloned and repo_path and repo_path.exists() else None
        if local_path:
            await _emit(
                on_event,
                CloudAgentEvent(
                    "status",
                    f"Changes preserved at {local_path}",
                    {"local_path": local_path},
                ),
            )

        return CloudAgentResult(
            branch_name=branch_name,
            error=error_msg,
            local_path=local_path,
        )
