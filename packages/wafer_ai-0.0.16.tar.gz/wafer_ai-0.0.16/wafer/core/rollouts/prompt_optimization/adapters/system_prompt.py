"""System prompt optimization adapter.
Optimizes the system prompt while keeping the user template fixed.
Uses CLI agent spawning (wafer-cli subprocess) for evaluation.
"""
import logging
import tempfile
from collections.abc import Awaitable, Callable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import trio

from ...cli_agents import CLIAgentConfig, evaluate_cli_agent_sample
from ...dtypes import (
    Endpoint,
    Message,
    Sample,
    Score,
)
from ..types import Candidate, EvaluationBatch

logger = logging.getLogger(__name__)
ScoreFn = Callable[[Sample], Score] | Callable[[Sample], Awaitable[Score]]


@dataclass(frozen=True)
class SystemPromptConfig:
    """Configuration for system prompt optimization.
    The user_template is fixed; only the system prompt is optimized.
    """
    endpoint: Endpoint
    user_template: str
    score_fn: ScoreFn
    prepare_working_dir: Callable[[dict[str, Any], Path], None] | None = None
    tools: list[str] | None = None
    max_concurrent: int = 10
    max_turns: int | None = None
    timeout_sec: float = 600.0


def extract_output(sample: Sample) -> str:
    """Extract output text from Sample's trajectory."""
    if not sample.trajectory or not sample.trajectory.messages:
        return ""
    for msg in reversed(sample.trajectory.messages):
        if msg.role == "assistant":
            if isinstance(msg.content, str):
                return msg.content
            if isinstance(msg.content, list):
                parts = []
                for block in msg.content:
                    if hasattr(block, "text"):
                        parts.append(block.text)
                return "".join(parts)
    return ""


def format_trajectory(messages: list[Message]) -> str:
    """Format a multi-turn trajectory for reflection."""
    parts = []
    for msg in messages:
        if msg.role == "system":
            continue
        if msg.role == "user":
            content = msg.content if isinstance(msg.content, str) else str(msg.content)
            parts.append(f"User: {content}")
        elif msg.role == "assistant":
            if isinstance(msg.content, str):
                parts.append(f"Assistant: {msg.content}")
            elif isinstance(msg.content, list):
                for block in msg.content:
                    if hasattr(block, "text") and block.text:
                        parts.append(f"Assistant: {block.text}")
                    elif hasattr(block, "type") and block.type == "tool_use":
                        tool_name = getattr(block, "name", "unknown")
                        tool_input = getattr(block, "input", {})
                        parts.append(f"Assistant [tool_call]: {tool_name}({tool_input})")
        elif msg.role == "tool_result":
            content = msg.content if isinstance(msg.content, str) else str(msg.content)
            if len(content) > 500:
                content = content[:500] + "... [truncated]"
            parts.append(f"Tool Result: {content}")
    return "\n".join(parts)


def _write_temp_agent_config(
    config: SystemPromptConfig,
    system_prompt: str,
) -> Path:
    """Write a temporary agent config TOML for this prompt candidate."""
    from wafer.cli.agent_config import write_agent_config_toml

    config_file = Path(tempfile.mktemp(suffix=".toml", prefix="gepa_"))
    model_str = f"{config.endpoint.provider}/{config.endpoint.model}"
    write_agent_config_toml(
        config_file,
        model=model_str,
        temperature=getattr(config.endpoint, "temperature", 1.0),
        max_turns=config.max_turns or 1,
        single_turn=config.max_turns is None,
        system_prompt=system_prompt,
        tools=config.tools or ["read", "glob", "grep", "bash"],
    )
    return config_file


async def evaluate_system_prompt(
    config: SystemPromptConfig,
    batch: Sequence[dict],
    candidate: Candidate,
    capture_traces: bool = False,
) -> EvaluationBatch:
    """Evaluate single-prompt candidate on batch via CLI agent spawning."""
    system_prompt = candidate["system"]

    config_file = _write_temp_agent_config(config, system_prompt)

    try:
        cli_config = CLIAgentConfig(
            agent="wafer",
            model=None,
            timeout_sec=config.timeout_sec,
            extra_args=["--config", str(config_file)],
        )

        def build_instruction(sample_data: dict[str, Any]) -> str:
            return config.user_template.format(**sample_data)

        limiter = trio.CapacityLimiter(config.max_concurrent)
        results: list[Sample | None] = [None] * len(batch)

        async def run_one(idx: int, sample_data: dict) -> None:
            async with limiter:
                sample_dir = Path(tempfile.mkdtemp(prefix=f"gepa_{idx}_"))
                if config.prepare_working_dir:
                    config.prepare_working_dir(sample_data, sample_dir)
                results[idx] = await evaluate_cli_agent_sample(
                    config=cli_config,
                    sample_data=sample_data,
                    sample_id=f"gepa_{idx}",
                    working_dir=sample_dir,
                    build_instruction=build_instruction,
                    score_fn=config.score_fn,
                )

        async with trio.open_nursery() as nursery:
            for idx, sample_data in enumerate(batch):
                nursery.start_soon(run_one, idx, sample_data)

        samples = [r for r in results if r is not None]
        outputs = tuple(extract_output(s) for s in samples)
        scores = tuple(s.score.reward if s.score else 0.0 for s in samples)
        trajectories = None
        if capture_traces:
            trajectories = tuple(
                {
                    "sample": s.input,
                    "messages": s.trajectory.messages if s.trajectory else [],
                    "output": extract_output(s),
                    "score": s.score.reward if s.score else 0.0,
                    "ground_truth": s.ground_truth,
                }
                for s in samples
            )
        return EvaluationBatch(
            outputs=outputs,
            scores=scores,
            trajectories=trajectories,
        )
    finally:
        config_file.unlink(missing_ok=True)


def make_system_prompt_reflective(
    candidate: Candidate,
    eval_batch: EvaluationBatch,
    components_to_update: list[str],
) -> dict[str, list[dict]]:
    """Extract feedback for system prompt from traces."""
    if "system" not in components_to_update:
        return {}
    if eval_batch.trajectories is None:
        logger.warning("No trajectories in eval_batch, cannot make reflective dataset")
        return {"system": []}
    items = []
    for trace in eval_batch.trajectories:
        score = trace["score"]
        ground_truth = trace.get("ground_truth")
        if score >= 0.9:
            feedback = "Excellent response. This is correct."
        elif score >= 0.5:
            feedback = f"Partially correct. Expected: {ground_truth}"
        else:
            feedback = f"Incorrect. Expected: {ground_truth}"
        input_text = ""
        for msg in trace["messages"]:
            if msg.role == "user":
                input_text = msg.content if isinstance(msg.content, str) else str(msg.content)
                break

        assistant_msgs = [m for m in trace["messages"] if m.role == "assistant"]
        is_multi_turn = len(assistant_msgs) > 1
        if is_multi_turn:
            trajectory_text = format_trajectory(trace["messages"])
            items.append({
                "Inputs": input_text,
                "Trajectory": trajectory_text,
                "Final Output": trace["output"],
                "Feedback": feedback,
            })
        else:
            items.append({
                "Inputs": input_text,
                "Generated Outputs": trace["output"],
                "Feedback": feedback,
            })
    return {"system": items}
