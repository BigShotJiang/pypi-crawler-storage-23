"""Template loader utilities.

TOML-only: loads templates from bundled TOML files in wafer/cli/templates/toml/.
Template name (e.g. ask-docs) maps to ask_docs.toml.
"""
from __future__ import annotations

from pathlib import Path

from .base import TemplateConfig


def _agent_config_to_template_config(cfg: object, name: str) -> TemplateConfig:
    """Convert AgentFileConfig to TemplateConfig."""
    from wafer.cli.agent_config import AgentFileConfig

    assert isinstance(cfg, AgentFileConfig), f"Expected AgentFileConfig, got {type(cfg)}"
    return TemplateConfig(
        name=name,
        description=cfg.description or "",
        system_prompt=cfg.system_prompt or "",
        tools=cfg.tools or ["read", "glob", "grep", "bash"],
        bash_allowlist=cfg.bash_allowlist,
        model=cfg.model or "anthropic/claude-sonnet-4-5-20250929",
        max_tokens=cfg.max_tokens or 8192,
        thinking=cfg.thinking_enabled or False,
        thinking_budget=cfg.thinking_budget_tokens or 10000,
        single_turn=cfg.single_turn or False,
        defaults=cfg.defaults or {},
        include_skills=False,
        allow_network=cfg.allow_network or False,
        direct_endpoint=cfg.direct_endpoint,
        user_prompt_template=cfg.user_prompt_template or "",
    )


def load_template(
    template_name: str,
    search_paths: list[Path] | None = None,
) -> TemplateConfig:
    """Load a template by name from bundled TOML.

    Args:
        template_name: Template name (e.g. "ask-docs", "optimize-kernelbench")
        search_paths: Ignored. Kept for API compatibility.

    Returns:
        TemplateConfig instance

    Raises:
        FileNotFoundError: If template not found
    """
    from wafer.cli.agent_config import get_bundled_template_path, load_agent_config

    path = get_bundled_template_path(template_name)
    if path is None:
        available = list_templates()
        raise FileNotFoundError(
            f"Template '{template_name}' not found. "
            f"Available: {', '.join(available) if available else '(none)'}"
        )
    file_config = load_agent_config(path)
    display_name = path.stem.replace("_", "-")
    return _agent_config_to_template_config(file_config, display_name)


def list_templates(search_paths: list[Path] | None = None) -> list[str]:
    """List available bundled TOML template names."""
    from wafer.cli.agent_config import list_bundled_templates

    return list_bundled_templates()


def load_all_templates(
    search_paths: list[Path] | None = None,
) -> list[tuple[str, TemplateConfig | None, str | None]]:
    """Load all available templates with error handling."""
    names = list_templates(search_paths)
    results: list[tuple[str, TemplateConfig | None, str | None]] = []
    for name in names:
        try:
            config = load_template(name, search_paths)
            results.append((name, config, None))
        except Exception as e:
            results.append((name, None, str(e)))
    return results
