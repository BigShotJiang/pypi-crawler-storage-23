"""GPU target specifications for occupancy and resource calculations.

Provides hardware-specific constants for AMD GPU architectures.
"""

from wafer.core.lib.kernel_scope.targets.specs import (
    SUPPORTED_TARGETS,
    TargetSpecs,
    get_target_specs,
)

__all__ = [
    "TargetSpecs",
    "get_target_specs",
    "SUPPORTED_TARGETS",
]
