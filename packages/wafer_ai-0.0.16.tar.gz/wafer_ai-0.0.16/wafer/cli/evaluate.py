"""Universal eval primitive for Wafer CLI.

One command, two modes:
    wafer tool eval --task kernelbench --after ./optimized
    wafer tool eval --task kernelbench --before ./original --after ./optimized

The task owns everything: what to run, how to parse output, how to score.
The eval tool is target-agnostic. GPU access is composed via 'wafer target run'.

For kernelbench: use 'wafer problems download kernelbench' first, then pass
--after with a directory containing your solution (or use wafer target run).
"""
from __future__ import annotations

import asyncio
import json
from pathlib import Path

import typer

from wafer.eval import list_tasks, load_task

app = typer.Typer(
    help="Evaluate kernel correctness and performance",
    invoke_without_command=True,
)


@app.callback(invoke_without_command=True)
def eval_main(
    ctx: typer.Context,
    task: str | None = typer.Option(
        None,
        "--task",
        "-t",
        help="Task name (built-in) or path to .py file (required unless --list-tasks)",
    ),
    after: Path = typer.Option(
        ".",
        "--after",
        "-a",
        help="Directory to evaluate (default: current directory)",
    ),
    before: Path | None = typer.Option(
        None,
        "--before",
        "-b",
        help="Baseline directory for comparison (optional)",
    ),
    list_tasks_flag: bool = typer.Option(
        False,
        "--list-tasks",
        help="List available built-in tasks and exit",
    ),
    task_args: list[str] | None = typer.Argument(
        None,
        help="Extra arguments passed to the task (after '--')",
    ),
) -> None:
    """Evaluate kernel correctness and performance.

    Examples:
        wafer tool eval --list-tasks
        wafer tool eval --task kernelbench --after ./optimized
        wafer tool eval --before ./original --after ./optimized --task kernelbench
    """
    if list_tasks_flag:
        available = list_tasks()
        typer.echo("Available tasks:")
        for name in available:
            typer.echo(f"  {name}")
        raise typer.Exit(0)

    if ctx.invoked_subcommand is not None:
        return

    if not task:
        typer.echo("Error: --task is required. Use --list-tasks to see available tasks.", err=True)
        raise typer.Exit(1)

    task_obj = load_task(task)
    extra_args = list(task_args) if task_args else []

    after_dir = after.resolve()
    assert after_dir.is_dir(), f"--after is not a directory: {after_dir}"

    task_args_after = [str(after_dir)] + extra_args
    typer.echo(f"[wafer eval] Running task {task!r} in {after_dir}", err=True)
    after_output = asyncio.run(task_obj.produce(task_args_after))

    before_output: str | None = None
    if before is not None:
        before_dir = before.resolve()
        assert before_dir.is_dir(), f"--before is not a directory: {before_dir}"
        task_args_before = [str(before_dir)] + extra_args
        typer.echo(f"[wafer eval] Running baseline in {before_dir}", err=True)
        before_output = asyncio.run(task_obj.produce(task_args_before))

    score = task_obj.score(after_output, before_output)
    print(json.dumps(score.to_dict(), indent=2))
