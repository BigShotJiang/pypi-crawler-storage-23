"""Wafer CLI package exports."""

from wafer.cli.app import app, main

__all__ = ["app", "main"]
