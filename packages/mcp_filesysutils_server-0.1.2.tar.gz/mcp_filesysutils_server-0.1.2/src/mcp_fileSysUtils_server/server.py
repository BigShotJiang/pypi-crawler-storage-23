# pip install  fastmcp<3
import shutil
from pathlib import Path
from fastmcp import FastMCP
from datetime import datetime
from utils import format_size, get_installed_programs
import os
import subprocess
app = FastMCP("文件整理+软件卸载")


@app.tool(description="列出指定目录下的所有文件名，文件类型和文件大小")
async def list_files_in_directory(path: str):
    """列出指定路径下的所有文件信息"""
    out_list=[]
    try:
        target_path = Path(path).resolve()
        if not target_path.exists():
            return f"错误：路径不存在 - {target_path}"
        if not target_path.is_dir():
            return (f"错误：路径不是目录 - {target_path}")
        files = [f for f in target_path.iterdir() if f.is_file()]
        if not files:
            return f"目录 '{target_path}' 中没有文件。"
        out_list.append(f"\n目录: {target_path}\n")
        out_list.append(f"{'文件名':<50} {'类型':<10} {'大小 (字节)':<15} {'大小 (可读)'}\n")
        out_list.append("-" * 100+'\n')


        for file in sorted(files):
            name = file.name
            suffix = file.suffix[1:] if file.suffix else "无"
            size_bytes = file.stat().st_size
            size_readable = format_size(size_bytes)
            out_list.append(f"{name:<50} {suffix:<10} {size_bytes:<15} {size_readable}\n")
        return ''.join(out_list)
    except PermissionError:
        print(f"权限不足，无法访问路径: {path}")
        return f"权限不足，无法访问路径: {path}"
    except Exception as e:
        print(f"发生错误: {e}")
        return f"发生错误: {e}"



@app.tool(description="按扩文件类型自动整理文件到新的文件夹",)
async def organize_files_by_type(target_dir: str):
    """
    整理指定目录下的文件：
    - 按扩展名分组
    - 创建 YYYYMMDD_ext 文件夹
    - 移动文件到对应文件夹
    """
    target_path = Path(target_dir).resolve()
    # 验证路径
    if not target_path.exists():
        return f"错误：路径不存在 - {target_path}"
    if not target_path.is_dir():
        return f"错误：路径不是目录 - {target_path}"

    # 获取当前日期（用于文件夹命名）
    today_str = datetime.now().strftime("%Y%m%d")

    # 收集所有文件（仅顶层，不递归子目录）
    files = [f for f in target_path.iterdir() if f.is_file()]

    if not files:
        return f"目录 '{target_path}' 中没有文件需要整理。"

    print(f"扫描到 {len(files)} 个文件，开始整理...\n")
    # 按扩展名分组
    ext_groups = {}
    for file in files:
        ext = file.suffix.lower()[1:] or "no_ext"  # 去掉点，空扩展名为 no_ext
        if ext not in ext_groups:
            ext_groups[ext] = []
        ext_groups[ext].append(file)

    # 处理每组文件
    total_moved = 0
    for ext, file_list in ext_groups.items():
        folder_name = f"{today_str}_{ext}"
        dest_folder = target_path / folder_name
        # 创建目标文件夹（如果不存在）
        dest_folder.mkdir(exist_ok=True)
        print(f"创建文件夹: {folder_name} ({len(file_list)} 个文件)")
        for src_file in file_list:
            dest_file = dest_folder / src_file.name
            # 避免覆盖已有文件
            if dest_file.exists():
                print(f"跳过（目标已存在）: {src_file.name}")
                continue
            try:
                shutil.move(str(src_file), str(dest_file))
                print(f"移动: {src_file.name}")
                total_moved += 1
            except Exception as e:
                return f"移动失败 {src_file.name}: {e}"
    return f"整理完成！共移动 {total_moved} 个文件。"

@app.tool(description="列出电脑上所有软件",)
async def list_all_software():
    """列出所有已安装软件"""
    out_list = []
    if os.name == 'nt':
        programs = get_installed_programs()
        if not programs:
            return "未找到任何已安装软件。"
        out_list.append(f"共找到 {len(programs)} 个已安装软件:")
        for i, (name, _) in enumerate(sorted(programs), 1):
            out_list.append(f"{i:3}. {name}")
        out_list.append(f"总计: {len(programs)} 个程序")
        return '\n'.join(out_list)

    else:
        return '仅支持windows平台'

@app.tool(description="根据软件名字，卸载软件",)
async def uninstall_by_exact_name(software_name: str):
    """通过精确名称卸载软件"""
    if not software_name:
        return "软件名称不能为空。"

    print(f"正在查找软件: '{software_name}'精确匹配...")
    programs = get_installed_programs()
    # 精确匹配（统一转小写）
    target = None
    for name, cmd in programs:
        if name.lower() == software_name.lower():
            target = (name, cmd)
            break

    name, raw_cmd = target
    # 格式化命令
    cmd = raw_cmd.strip()
    if not cmd.startswith('"'):
        # 尝试拆分 exe 和参数
        parts = cmd.split(' ', 1)
        exe_path = parts[0]
        args = parts[1] if len(parts) > 1 else ""
        if os.path.exists(exe_path):
            cmd = f'"{exe_path}" {args}' if args else f'"{exe_path}"'
        else:
            cmd = f'"{cmd}"'
    print(f"找到软件: {name}")
    print(f"卸载命令: {cmd}")
    try:
        print("正在启动卸载程序...")
        result = subprocess.run(cmd, shell=True, check=True)
        print(f"成功启动卸载流程: {name}")
        return "请按卸载向导完成操作。"
    except subprocess.CalledProcessError as e:
        return f"卸载启动失败: {e}"
    except Exception as e:
        return f"发生错误: {e}"


if __name__ == "__main__":
    app.run(transport='stdio')