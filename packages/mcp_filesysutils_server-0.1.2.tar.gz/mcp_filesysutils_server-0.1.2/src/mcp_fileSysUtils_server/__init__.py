from .server import app

def main():
    app.run(transport='stdio')