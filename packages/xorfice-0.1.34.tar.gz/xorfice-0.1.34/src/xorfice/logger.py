import os
import json
import uuid
import datetime
from typing import Dict, Any, List, Optional
from xorfice.config.special_tokens import SPECIAL_TOKENS

class DatasetConverter:
    """
    SOTA Dataset Converter that transforms raw interactions into
    training-ready samples using model-specific special tokens.
    """
    @staticmethod
    def to_training_format(user_id: str, prompt: str, response: str) -> Dict[str, str]:
        """Wraps a turn into a formatted training sample."""
        user_start = SPECIAL_TOKENS.get("user_start", "<|user|>")
        user_end = SPECIAL_TOKENS.get("user_end", "<|/user|>")
        assistant_start = SPECIAL_TOKENS.get("assistant_start", "<|assistant|>")
        assistant_end = SPECIAL_TOKENS.get("assistant_end", "<|/assistant|>")
        
        # SOT/EOT tokens if available
        bos = SPECIAL_TOKENS.get("bos", "<|bos|>")
        eos = SPECIAL_TOKENS.get("eos", "<|eos|>")
        
        text = (
            f"{bos}{user_start}{prompt}{user_end}"
            f"{assistant_start}{response}{assistant_end}{eos}"
        )
        
        return {
            "user_id": user_id,
            "text": text,
            "timestamp": datetime.datetime.utcnow().isoformat() + "Z"
        }

class JSONLLogger:
    """
    SOTA Logger for API interactions and automated dataset building.
    """
    def __init__(self, log_dir: str = "logs", dataset_dir: str = "dataset", max_lines: int = 2000):
        self.log_dir = log_dir
        self.dataset_dir = dataset_dir
        self.max_lines = max_lines
        
        self.current_log_file: Optional[Any] = None
        self.current_dataset_file: Optional[Any] = None
        self.current_lines = 0
        
        os.makedirs(self.log_dir, exist_ok=True)
        os.makedirs(self.dataset_dir, exist_ok=True)
        
        self._rotate_files()

    def _rotate_files(self):
        """Creates new JSONL files when the line limit is reached."""
        if hasattr(self, 'current_log_file') and self.current_log_file: 
            self.current_log_file.close()
        if hasattr(self, 'current_dataset_file') and self.current_dataset_file: 
            self.current_dataset_file.close()
        
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        file_id = str(uuid.uuid4().hex)[:8]
        
        log_path = os.path.join(self.log_dir, f"xoron_api_{timestamp}_{file_id}.jsonl")
        dataset_path = os.path.join(self.dataset_dir, f"xoron_train_{timestamp}_{file_id}.jsonl")
        
        self.current_log_file = open(log_path, "a")
        self.current_dataset_file = open(dataset_path, "a")
        self.current_lines = 0
        print(f"[Logger] Started interaction log: {log_path}")
        print(f"[Logger] Started training dataset: {dataset_path}")

    def log_interaction(self, user_id: str, endpoint: str, request_data: Dict[str, Any], response_data: Dict[str, Any]):
        """Logs an interaction and automatically adds to the training dataset."""
        # 1. Standard API Logging
        log_entry = {
            "timestamp": datetime.datetime.utcnow().isoformat() + "Z",
            "user_id": user_id,
            "endpoint": endpoint,
            "request": request_data,
            "response": response_data,
        }
        self.current_log_file.write(json.dumps(log_entry) + "\n")
        
        # 2. Automated Dataset Conversion (SOTA On-the-fly Dataset Building)
        prompt = request_data.get("prompt") or request_data.get("messages", [{}])[-1].get("content")
        response = response_data.get("text") or response_data.get("choices", [{}])[0].get("message", {}).get("content")
        
        if prompt and response:
            train_sample = DatasetConverter.to_training_format(user_id, prompt, response)
            self.current_dataset_file.write(json.dumps(train_sample) + "\n")
        
        self.current_log_file.flush()
        self.current_dataset_file.flush()
        self.current_lines += 1
        
        if self.current_lines >= self.max_lines:
            self._rotate_files()

    def __del__(self):
        if hasattr(self, 'current_log_file') and self.current_log_file: 
            self.current_log_file.close()
        if hasattr(self, 'current_dataset_file') and self.current_dataset_file: 
            self.current_dataset_file.close()
