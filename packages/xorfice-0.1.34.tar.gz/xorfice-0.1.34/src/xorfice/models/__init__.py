"""Models module for Xoron-Dev multimodal model."""

from xorfice.models.xoron import XoronMultimodalModel, COMPONENT_GROUPS

__all__ = ['XoronMultimodalModel', 'COMPONENT_GROUPS']
