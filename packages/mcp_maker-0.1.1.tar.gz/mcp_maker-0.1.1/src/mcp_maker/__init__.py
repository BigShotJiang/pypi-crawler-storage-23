"""
MCP-Maker — Auto-generate MCP servers from any data source.

Point MCP-Maker at a database, API, or file directory and get a
fully functional MCP server — zero Python code required.
"""

__version__ = "0.1.1"
