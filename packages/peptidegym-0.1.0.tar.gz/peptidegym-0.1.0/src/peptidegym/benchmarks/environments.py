"""Benchmark environment configurations."""
from __future__ import annotations

BENCHMARK_CONFIGS: list[dict[str, str]] = [
    {"env_id": "PeptideGym/AMP-Easy-v0", "name": "AMP-Easy"},
    {"env_id": "PeptideGym/AMP-v0", "name": "AMP-Medium"},
    {"env_id": "PeptideGym/AMP-Hard-v0", "name": "AMP-Hard"},
    {"env_id": "PeptideGym/CyclicPeptide-Easy-v0", "name": "Cyclic-Easy"},
    {"env_id": "PeptideGym/CyclicPeptide-v0", "name": "Cyclic-Medium"},
    {"env_id": "PeptideGym/CyclicPeptide-Hard-v0", "name": "Cyclic-Hard"},
    {"env_id": "PeptideGym/Epitope-Easy-v0", "name": "Epitope-Easy"},
    {"env_id": "PeptideGym/Epitope-v0", "name": "Epitope-Medium"},
    {"env_id": "PeptideGym/Epitope-Hard-v0", "name": "Epitope-Hard"},
]
