"""PeptideGym environments — Gymnasium-compatible RL envs for therapeutic peptide design."""
from __future__ import annotations

import gymnasium

_REGISTERED = False


def register_envs() -> None:
    """Register all PeptideGym environments with Gymnasium.

    Guards against double-registration so this can be called multiple times
    safely (e.g. both from peptidegym.__init__ and from user code).
    """
    global _REGISTERED
    if _REGISTERED:
        return
    _REGISTERED = True

    # ── AMP environments ──────────────────────────────────────────────
    gymnasium.register(
        id="PeptideGym/AMP-v0",
        entry_point="peptidegym.envs.amp:AMPEnv",
        kwargs={"max_length": 35, "difficulty": "medium"},
    )
    gymnasium.register(
        id="PeptideGym/AMP-Easy-v0",
        entry_point="peptidegym.envs.amp:AMPEnv",
        kwargs={"max_length": 20, "difficulty": "easy"},
    )
    gymnasium.register(
        id="PeptideGym/AMP-Hard-v0",
        entry_point="peptidegym.envs.amp:AMPEnv",
        kwargs={"max_length": 50, "difficulty": "hard"},
    )

    # ── Cyclic peptide environments ───────────────────────────────────
    gymnasium.register(
        id="PeptideGym/CyclicPeptide-v0",
        entry_point="peptidegym.envs.cyclic:CyclicPeptideEnv",
        kwargs={"max_length": 20, "difficulty": "medium"},
    )
    gymnasium.register(
        id="PeptideGym/CyclicPeptide-Easy-v0",
        entry_point="peptidegym.envs.cyclic:CyclicPeptideEnv",
        kwargs={"max_length": 12, "difficulty": "easy"},
    )
    gymnasium.register(
        id="PeptideGym/CyclicPeptide-Hard-v0",
        entry_point="peptidegym.envs.cyclic:CyclicPeptideEnv",
        kwargs={"max_length": 30, "difficulty": "hard"},
    )

    # ── Epitope environments ──────────────────────────────────────────
    gymnasium.register(
        id="PeptideGym/Epitope-v0",
        entry_point="peptidegym.envs.epitope:EpitopeEnv",
        kwargs={"difficulty": "medium"},
    )
    gymnasium.register(
        id="PeptideGym/Epitope-Easy-v0",
        entry_point="peptidegym.envs.epitope:EpitopeEnv",
        kwargs={"difficulty": "easy"},
    )
    gymnasium.register(
        id="PeptideGym/Epitope-Hard-v0",
        entry_point="peptidegym.envs.epitope:EpitopeEnv",
        kwargs={"difficulty": "hard"},
    )
