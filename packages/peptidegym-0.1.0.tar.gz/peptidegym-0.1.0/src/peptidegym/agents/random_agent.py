"""Random baseline agent with SB3-compatible interface."""
from __future__ import annotations

from typing import Any

import numpy as np


class RandomAgent:
    """Uniformly random action selection — serves as the weakest baseline.

    Follows the Stable-Baselines3 ``predict`` / ``learn`` interface so it can be
    evaluated with the same harness as trained models.
    """

    def __init__(self, env: Any, seed: int | None = None) -> None:
        self.env = env
        self.action_space = env.action_space
        self._rng = np.random.RandomState(seed)

    def predict(
        self, obs: Any, deterministic: bool = False
    ) -> tuple[int, None]:
        """Return a random action from the environment's action space."""
        action = int(self._rng.randint(self.action_space.n))
        return action, None

    def learn(self, total_timesteps: int) -> None:
        """No-op — random agent does not learn."""
        pass
