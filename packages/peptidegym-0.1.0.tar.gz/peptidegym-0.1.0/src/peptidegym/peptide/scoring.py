"""Scoring protocol for peptide reward backends."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class RewardBackend(Protocol):
    """Protocol that all peptide scoring backends must implement."""

    def score(self, sequence: str, **kwargs) -> dict[str, float]:
        """Return a dict of named score components for the given amino acid sequence.

        Each value should be a float, typically in [0, 1] for normalized scores.
        """
        ...
