"""Amino acid properties and sequence-level descriptors. Zero external deps beyond numpy."""

from __future__ import annotations

import math
import numpy as np

# ── Alphabet ──────────────────────────────────────────────────────────────────

AMINO_ACIDS = "ARNDCEQGHILKMFPSTWYV"
AA_TO_INDEX: dict[str, int] = {aa: i for i, aa in enumerate(AMINO_ACIDS)}
INDEX_TO_AA: dict[int, str] = {i: aa for i, aa in enumerate(AMINO_ACIDS)}

# ── Per-residue lookup tables ─────────────────────────────────────────────────

HYDROPHOBICITY: dict[str, float] = {
    "A":  1.8, "R": -4.5, "N": -3.5, "D": -3.5, "C":  2.5,
    "E": -3.5, "Q": -3.5, "G": -0.4, "H": -3.2, "I":  4.5,
    "L":  3.8, "K": -3.9, "M":  1.9, "F":  2.8, "P": -1.6,
    "S": -0.8, "T": -0.7, "W": -0.9, "Y": -1.3, "V":  4.2,
}

MOLECULAR_WEIGHT: dict[str, float] = {
    "A":  89.09, "R": 174.20, "N": 132.12, "D": 133.10, "C": 121.16,
    "E": 147.13, "Q": 146.15, "G":  75.03, "H": 155.16, "I": 131.17,
    "L": 131.17, "K": 146.19, "M": 149.21, "F": 165.19, "P": 115.13,
    "S": 105.09, "T": 119.12, "W": 204.23, "Y": 181.19, "V": 117.15,
}

CHARGE_PH74: dict[str, float] = {aa: 0.0 for aa in AMINO_ACIDS}
CHARGE_PH74.update({"R": 1.0, "K": 1.0, "H": 0.1, "D": -1.0, "E": -1.0})

# ── DIWV table (Guruprasad et al. 1990) ──────────────────────────────────────
# 20x20 dipeptide instability weight values.
# Rows = first residue, Cols = second residue, order = AMINO_ACIDS string.

_DIWV_RAW: dict[str, dict[str, float]] = {
    "A": {"A": 1.0, "R": 1.0, "N": 1.0, "D": -7.49, "C": 1.0, "E": 1.0, "Q": 1.0, "G": 1.0, "H": -7.49, "I": 1.0,
          "L": 1.0, "K": 1.0, "M": 1.0, "F": 1.0, "P": 20.26, "S": 1.0, "T": 1.0, "W": 1.0, "Y": 1.0, "V": 1.0},
    "R": {"A": 1.0, "R": 58.28, "N": 1.0, "D": 1.0, "C": 1.0, "E": 1.0, "Q": 20.26, "G": -7.49, "H": 1.0, "I": 1.0,
          "L": 1.0, "K": 1.0, "M": 1.0, "F": 1.0, "P": 20.26, "S": 1.0, "T": 1.0, "W": 58.28, "Y": 1.0, "V": 1.0},
    "N": {"A": 1.0, "R": 1.0, "N": 1.0, "D": 1.0, "C": -1.88, "E": 1.0, "Q": -6.54, "G": -14.03, "H": 1.0, "I": 24.68,
          "L": 1.0, "K": 24.68, "M": 1.0, "F": -14.03, "P": -1.88, "S": 1.0, "T": -7.49, "W": -9.37, "Y": 1.0, "V": 1.0},
    "D": {"A": 1.0, "R": -6.54, "N": 1.0, "D": 1.0, "C": 1.0, "E": 1.0, "Q": 1.0, "G": 1.0, "H": 1.0, "I": 1.0,
          "L": 1.0, "K": -7.49, "M": 1.0, "F": -6.54, "P": 1.0, "S": 20.26, "T": -14.03, "W": 1.0, "Y": 1.0, "V": 1.0},
    "C": {"A": 1.0, "R": 1.0, "N": 1.0, "D": 20.26, "C": 1.0, "E": 1.0, "Q": -6.54, "G": 1.0, "H": 1.0, "I": 1.0,
          "L": 20.26, "K": 1.0, "M": 33.60, "F": 1.0, "P": 20.26, "S": 1.0, "T": 33.60, "W": 24.68, "Y": 1.0, "V": -6.54},
    "E": {"A": 1.0, "R": 1.0, "N": 1.0, "D": 20.26, "C": 1.0, "E": 33.60, "Q": 20.26, "G": 1.0, "H": -6.54, "I": 20.26,
          "L": 1.0, "K": 1.0, "M": 1.0, "F": 1.0, "P": 20.26, "S": 20.26, "T": 1.0, "W": -14.03, "Y": 1.0, "V": 1.0},
    "Q": {"A": 1.0, "R": 1.0, "N": 1.0, "D": 20.26, "C": -6.54, "E": 20.26, "Q": 20.26, "G": 1.0, "H": 1.0, "I": 1.0,
          "L": 1.0, "K": 1.0, "M": 1.0, "F": -6.54, "P": 20.26, "S": 1.0, "T": 1.0, "W": 1.0, "Y": -6.54, "V": -6.54},
    "G": {"A": -7.49, "R": 1.0, "N": -7.49, "D": 1.0, "C": 1.0, "E": -6.54, "Q": 1.0, "G": 13.34, "H": 1.0, "I": -7.49,
          "L": 1.0, "K": -7.49, "M": 1.0, "F": 1.0, "P": 1.0, "S": 1.0, "T": -7.49, "W": 13.34, "Y": 1.0, "V": 1.0},
    "H": {"A": 1.0, "R": -6.54, "N": 24.68, "D": 1.0, "C": 1.0, "E": 1.0, "Q": 1.0, "G": -9.37, "H": 1.0, "I": 44.94,
          "L": 1.0, "K": 24.68, "M": 1.0, "F": -9.37, "P": -1.88, "S": 1.0, "T": -6.54, "W": -1.88, "Y": 44.94, "V": 1.0},
    "I": {"A": 1.0, "R": 1.0, "N": 1.0, "D": 1.0, "C": 1.0, "E": 44.94, "Q": 1.0, "G": 1.0, "H": 13.34, "I": 1.0,
          "L": 20.26, "K": -7.49, "M": 1.0, "F": 1.0, "P": -1.88, "S": 1.0, "T": 1.0, "W": 1.0, "Y": 1.0, "V": -7.49},
    "L": {"A": 1.0, "R": 20.26, "N": 1.0, "D": 1.0, "C": 1.0, "E": 1.0, "Q": 33.60, "G": 20.26, "H": 1.0, "I": 1.0,
          "L": 1.0, "K": -7.49, "M": 1.0, "F": 1.0, "P": 20.26, "S": 1.0, "T": 1.0, "W": 24.68, "Y": 1.0, "V": 1.0},
    "K": {"A": 1.0, "R": 33.60, "N": 1.0, "D": -7.49, "C": 1.0, "E": 1.0, "Q": 24.68, "G": -7.49, "H": 1.0, "I": -7.49,
          "L": -7.49, "K": 1.0, "M": 33.60, "F": 1.0, "P": -6.54, "S": 1.0, "T": 1.0, "W": 1.0, "Y": 1.0, "V": -7.49},
    "M": {"A": 13.34, "R": -6.54, "N": 1.0, "D": 1.0, "C": 1.0, "E": 1.0, "Q": -6.54, "G": 1.0, "H": 58.28, "I": 1.0,
          "L": 1.0, "K": 1.0, "M": -1.88, "F": 1.0, "P": 44.94, "S": 44.94, "T": -1.88, "W": 1.0, "Y": 24.68, "V": 1.0},
    "F": {"A": 1.0, "R": 1.0, "N": 1.0, "D": 13.34, "C": 1.0, "E": 1.0, "Q": 1.0, "G": 1.0, "H": 1.0, "I": 1.0,
          "L": 1.0, "K": -14.03, "M": 1.0, "F": 1.0, "P": 20.26, "S": 1.0, "T": 1.0, "W": 1.0, "Y": 33.60, "V": 1.0},
    "P": {"A": 20.26, "R": -6.54, "N": 1.0, "D": -6.54, "C": -6.54, "E": 18.38, "Q": 20.26, "G": 1.0, "H": 1.0, "I": 1.0,
          "L": 1.0, "K": 1.0, "M": -6.54, "F": 20.26, "P": 20.26, "S": 20.26, "T": 1.0, "W": -1.88, "Y": 1.0, "V": 20.26},
    "S": {"A": 1.0, "R": 20.26, "N": 1.0, "D": 1.0, "C": 33.60, "E": 20.26, "Q": 20.26, "G": 1.0, "H": 1.0, "I": 1.0,
          "L": 1.0, "K": 1.0, "M": 1.0, "F": 1.0, "P": 44.94, "S": 20.26, "T": 1.0, "W": 1.0, "Y": 1.0, "V": 1.0},
    "T": {"A": 1.0, "R": 1.0, "N": -14.03, "D": 1.0, "C": 1.0, "E": 20.26, "Q": -6.54, "G": -7.49, "H": 33.60, "I": 1.0,
          "L": 1.0, "K": 1.0, "M": 1.0, "F": 13.34, "P": 1.0, "S": 1.0, "T": 1.0, "W": -14.03, "Y": 1.0, "V": 1.0},
    "W": {"A": -14.03, "R": 1.0, "N": 13.34, "D": 1.0, "C": 1.0, "E": 1.0, "Q": 1.0, "G": -9.37, "H": 24.68, "I": 1.0,
          "L": 13.34, "K": 1.0, "M": 24.68, "F": 1.0, "P": 1.0, "S": 1.0, "T": -14.03, "W": 1.0, "Y": 1.0, "V": -7.49},
    "Y": {"A": 24.68, "R": -15.91, "N": 1.0, "D": 24.68, "C": 1.0, "E": -6.54, "Q": 1.0, "G": -7.49, "H": 13.34, "I": 1.0,
          "L": 1.0, "K": 1.0, "M": 44.94, "F": 1.0, "P": 13.34, "S": 1.0, "T": -7.49, "W": -9.37, "Y": 13.34, "V": 1.0},
    "V": {"A": 1.0, "R": 1.0, "N": 1.0, "D": -14.03, "C": 1.0, "E": 1.0, "Q": 1.0, "G": -7.49, "H": 1.0, "I": 1.0,
          "L": 1.0, "K": -1.88, "M": 1.0, "F": 1.0, "P": 20.26, "S": 1.0, "T": -7.49, "W": 1.0, "Y": -6.54, "V": 1.0},
}

# ── Functions ─────────────────────────────────────────────────────────────────

def net_charge(sequence: str) -> float:
    return sum(CHARGE_PH74[aa] for aa in sequence)


def mean_hydrophobicity(sequence: str) -> float:
    if not sequence:
        return 0.0
    return sum(HYDROPHOBICITY[aa] for aa in sequence) / len(sequence)


def aromaticity_fraction(sequence: str) -> float:
    if not sequence:
        return 0.0
    aromatic = sum(1 for aa in sequence if aa in "FWYH")
    return aromatic / len(sequence)


def instability_index(sequence: str) -> float:
    if len(sequence) < 2:
        return 0.0
    total = 0.0
    for i in range(len(sequence) - 1):
        total += _DIWV_RAW[sequence[i]][sequence[i + 1]]
    return (10.0 / len(sequence)) * total


def molecular_weight(sequence: str) -> float:
    if not sequence:
        return 0.0
    mw = sum(MOLECULAR_WEIGHT[aa] for aa in sequence)
    # Each peptide bond loses one water molecule; for n residues there are (n-1) bonds
    mw -= 18.02 * (len(sequence) - 1)
    return mw


def amphipathicity_score(sequence: str) -> float:
    if not sequence:
        return 0.0
    angle_per_residue = 100.0 * math.pi / 180.0  # 100 degrees in radians
    sin_sum = 0.0
    cos_sum = 0.0
    for i, aa in enumerate(sequence):
        h = HYDROPHOBICITY[aa]
        theta = i * angle_per_residue
        sin_sum += h * math.sin(theta)
        cos_sum += h * math.cos(theta)
    magnitude = math.sqrt(sin_sum ** 2 + cos_sum ** 2)
    return magnitude / len(sequence)


def one_hot_encode(sequence: str, max_length: int) -> np.ndarray:
    arr = np.zeros((max_length, 20), dtype=np.float32)
    for i, aa in enumerate(sequence[:max_length]):
        if aa in AA_TO_INDEX:
            arr[i, AA_TO_INDEX[aa]] = 1.0
    return arr
