"""PeptideGym: Gymnasium-compatible RL environments for therapeutic peptide design."""
__version__ = "0.1.0"

from peptidegym.envs import register_envs
register_envs()
