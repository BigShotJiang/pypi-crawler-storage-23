"""Shared fixtures for PeptideGym test suite."""
import pytest
import gymnasium as gym
import peptidegym  # noqa: F401 — triggers env registration


@pytest.fixture
def amp_env():
    env = gym.make("PeptideGym/AMP-v0")
    yield env
    env.close()


@pytest.fixture
def amp_easy_env():
    env = gym.make("PeptideGym/AMP-Easy-v0")
    yield env
    env.close()


@pytest.fixture
def cyclic_env():
    env = gym.make("PeptideGym/CyclicPeptide-v0")
    yield env
    env.close()


@pytest.fixture
def cyclic_easy_env():
    env = gym.make("PeptideGym/CyclicPeptide-Easy-v0")
    yield env
    env.close()


@pytest.fixture
def epitope_env():
    env = gym.make("PeptideGym/Epitope-v0")
    yield env
    env.close()


@pytest.fixture
def epitope_easy_env():
    env = gym.make("PeptideGym/Epitope-Easy-v0")
    yield env
    env.close()


@pytest.fixture
def epitope_hard_env():
    env = gym.make("PeptideGym/Epitope-Hard-v0")
    yield env
    env.close()
