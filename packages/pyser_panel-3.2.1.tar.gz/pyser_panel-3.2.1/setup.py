from setuptools import setup, find_packages

setup(
    name="pyser-panel",
    version="3.2.1",
    author="gtsivam",
    description="A premium XAMPP-like control panel for Python developers.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/gtsivam/pyser",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        "customtkinter",
        "pyftpdlib",
    ],
    entry_points={
        "console_scripts": [
            "pyser=pyser.main:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
