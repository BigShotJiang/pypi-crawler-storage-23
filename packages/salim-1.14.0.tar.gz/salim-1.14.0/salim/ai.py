"""
Salim AI — Multi-provider natural language engine.

Provider chain (fallback order):
  1. NVIDIA NIM  (primary)
  2. Groq        (fallback 1)
  3. Z.AI        (fallback 2)

If NVIDIA fails → Groq tried → if Groq fails → Z.AI tried.
Each provider is optional — configured during `salim setup`.
"""

from __future__ import annotations

import json
import logging
import platform
import re

import httpx

from salim.config import Config

logger = logging.getLogger("salim.ai")

# ═══════════════════════════════════════════════════════════════════════════════
#  MODEL CATALOGS
# ═══════════════════════════════════════════════════════════════════════════════

NVIDIA_MODELS: dict[str, dict] = {
    "meta/llama-4-maverick-17b-128e-instruct": {
        "label": "Llama 4 Maverick 17B (Meta)",
        "short": "Llama 4 Maverick",
        "description": "Meta's latest multimodal MoE — great all-rounder, 1M context",
        "tier": "S",
        "best_for": "General use, fast responses",
        "context": "1M tokens",
        "speed": "⚡⚡⚡",
    },
    "deepseek-ai/deepseek-v3-1": {
        "label": "DeepSeek V3.1 (DeepSeek)",
        "short": "DeepSeek V3.1",
        "description": "Hybrid LLM with Think/Non-Think modes, top reasoning",
        "tier": "S",
        "best_for": "Complex instructions, coding, reasoning",
        "context": "128K tokens",
        "speed": "⚡⚡",
    },
    "moonshotai/kimi-k2-instruct": {
        "label": "Kimi K2 (Moonshot)",
        "short": "Kimi K2",
        "description": "1T MoE — HumanEval 99.0, top coding & agents",
        "tier": "S",
        "best_for": "Code generation, agentic tasks",
        "context": "128K tokens",
        "speed": "⚡⚡",
    },
    "qwen/qwen3-235b-a22b-instruct": {
        "label": "Qwen3 235B (Alibaba)",
        "short": "Qwen3 235B",
        "description": "Top IFEval score, scientific reasoning, 22B active params (MoE)",
        "tier": "S",
        "best_for": "Instruction following, science, multilingual",
        "context": "128K tokens",
        "speed": "⚡⚡",
    },
    "nvidia/llama-3.3-nemotron-super-49b-v1": {
        "label": "Nemotron Super 49B (NVIDIA)",
        "short": "Nemotron Super 49B",
        "description": "NVIDIA flagship — MATH-500 97.4%, reasoning powerhouse",
        "tier": "A",
        "best_for": "Math, reasoning",
        "context": "128K tokens",
        "speed": "⚡⚡",
    },
}

# Top 5 Groq free-tier models (Feb 2026)
GROQ_MODELS: dict[str, dict] = {
    "openai/gpt-oss-120b": {
        "label": "GPT-OSS 120B (OpenAI on Groq)",
        "short": "GPT-OSS 120B",
        "description": "OpenAI's flagship open-weight, 120B params, reasoning — ~500 tok/s",
        "tier": "S",
        "best_for": "Best quality on Groq, reasoning, code",
        "context": "131K tokens",
        "speed": "~500 t/s",
    },
    "openai/gpt-oss-20b": {
        "label": "GPT-OSS 20B (OpenAI on Groq) ⚡ Fastest",
        "short": "GPT-OSS 20B",
        "description": "Fastest OpenAI open model on Groq — ~1000 tok/s",
        "tier": "S",
        "best_for": "Ultra-fast responses, real-time tasks",
        "context": "131K tokens",
        "speed": "~1000 t/s",
    },
    "llama-3.3-70b-versatile": {
        "label": "Llama 3.3 70B Versatile (Meta on Groq)",
        "short": "Llama 3.3 70B",
        "description": "Meta's best open 70B — balanced quality and speed, ~280 tok/s",
        "tier": "A",
        "best_for": "General use, great all-rounder",
        "context": "131K tokens",
        "speed": "~280 t/s",
    },
    "llama-3.1-8b-instant": {
        "label": "Llama 3.1 8B Instant (Meta on Groq)",
        "short": "Llama 3.1 8B",
        "description": "Incredibly fast 8B — ~560 tok/s, minimal latency",
        "tier": "A",
        "best_for": "Simple tasks, maximum speed",
        "context": "131K tokens",
        "speed": "~560 t/s",
    },
    "deepseek-r1-distill-llama-70b": {
        "label": "DeepSeek R1 Distill 70B (on Groq)",
        "short": "DeepSeek R1 Distill 70B",
        "description": "DeepSeek R1 reasoning distilled — chain-of-thought on Groq",
        "tier": "A",
        "best_for": "Complex reasoning, math, step-by-step",
        "context": "131K tokens",
        "speed": "~200 t/s",
    },
}

# Z.AI (Zhipu) GLM models — confirmed free from docs.z.ai/guides/overview/pricing
ZAI_MODELS: dict[str, dict] = {
    "glm-4.7-flash": {
        "label": "GLM-4.7-Flash (Zhipu Z.AI) — FREE",
        "short": "GLM-4.7-Flash",
        "description": "30B-A3B MoE, 128K ctx, strongest 30B class. Completely free.",
        "tier": "S",
        "best_for": "Best free model, coding, agents, reasoning",
        "context": "128K tokens",
        "free": True,
    },
    "glm-4.5-flash": {
        "label": "GLM-4.5-Flash (Zhipu Z.AI) — FREE",
        "short": "GLM-4.5-Flash",
        "description": "Previous-gen flash model — reliable, fast. Completely free.",
        "tier": "A",
        "best_for": "General tasks, speed, reliability",
        "context": "128K tokens",
        "free": True,
    },
    "glm-4-flash": {
        "label": "GLM-4-Flash (Zhipu Z.AI) — FREE",
        "short": "GLM-4-Flash",
        "description": "GLM-4 flash variant — lightweight and consistently fast. Free.",
        "tier": "A",
        "best_for": "Lightweight tasks, high throughput",
        "context": "128K tokens",
        "free": True,
    },
}

# ═══════════════════════════════════════════════════════════════════════════════
#  INTENT SYSTEM PROMPT
# ═══════════════════════════════════════════════════════════════════════════════

INTENT_SYSTEM_PROMPT = """You are Salim AI — the brain of a Telegram bot that lets users control their laptop remotely in plain English. Your ONLY job is to understand what the user wants and return a JSON action object.

AVAILABLE SALIM COMMANDS:
FILE: /ls [path], /cd <path>, /pwd, /cat <file>, /find <pattern>, /grep <pattern>, /mkdir <n>, /rm [-r] <path>, /mv <src> <dst>, /cp <src> <dst>, /write <file> <text>, /download <path>, /upload, /zip <path>, /unzip <file>
SYSTEM: /info, /cpu, /mem, /disk, /battery, /network, /uptime, /top, /ps [name], /kill <pid>
SHELL: /run <cmd>, /sh <cmd>, /runbg <cmd>, /env, /which <prog>
SCREEN: /screenshot [delay], /ss, /type <text>, /key <shortcut>, /click <x> <y>, /scroll <n>, /move <x> <y>, /mousepos, /open <app|url>
CLIPBOARD: /copy <text>, /paste
POWER: /shutdown, /restart, /sleep, /hibernate, /lock, /logout, /screensaver
MEDIA: /notify <title> | <msg>, /volume [0-100|up|down|mute], /brightness <0-100>

DECISION RULES (check in order):
1. Vague file request (no exact path known) → "search_files"
2. Create/write file with topic/content → "generate_and_write"
3. Destructive (delete, shutdown, restart, kill process, logout, hibernate) → "confirm"
4. Clear system query or non-destructive command → "execute"
5. Unknown → "clarify"

CRITICAL MAPPINGS:
"download X" without a path → search_files (never assume a path)
"find X file" / "search for X" → search_files
"create a [format] about [topic]" → generate_and_write
"write a file on [topic]" → generate_and_write
"take screenshot" → execute /screenshot
"screen" → execute /screenshot
"how's my laptop" → execute /info
"status" → execute /info
"check memory/ram" → execute /mem
"check cpu" → execute /cpu
"battery" → execute /battery
"network/ip/wifi" → execute /network
"disk/storage" → execute /disk
"processes/what's running" → execute /ps
"lock" → execute /lock (NOT destructive)
"sleep" → execute /sleep (NOT destructive — no confirm needed)
"mute/volume X/volume up/down" → execute /volume
"brightness X" → execute /brightness
"copy [text]" → execute /copy
"paste/clipboard" → execute /paste
"type [text]" → execute /type
"press [key]" → execute /key
"open/launch/start/run [app]" → execute /open <natural_app_name> (the handler resolves OS-specific executables automatically)
"open chrome/browser/google chrome" → execute /open chrome
"open firefox" → execute /open firefox
"open safari" → execute /open safari
"open code/vscode/vs code/visual studio code" → execute /open vscode
"open visual studio" → execute /open visual studio
"open spotify" → execute /open spotify
"open terminal/bash/console/cmd/powershell" → execute /open terminal
"open files/file manager/explorer/finder/nautilus" → execute /open explorer
"open discord" → execute /open discord
"open slack" → execute /open slack
"open zoom" → execute /open zoom
"open telegram" → execute /open telegram
"open teams/microsoft teams" → execute /open teams
"open whatsapp" → execute /open whatsapp
"open youtube" → execute /open https://youtube.com
"open gmail" → execute /open https://gmail.com
"open github" → execute /open https://github.com
"open calculator" → execute /open calculator
"open settings/system settings/preferences" → execute /open settings
"open vlc/media player" → execute /open vlc
"open gimp/photoshop" → execute /open gimp
"open obs/obs studio" → execute /open obs
"open word/microsoft word" → execute /open word
"open excel/microsoft excel" → execute /open excel
"open powerpoint" → execute /open powerpoint
"open outlook" → execute /open outlook
"open notepad" → execute /open notepad
"open paint" → execute /open paint
"open task manager" → execute /open task manager
"open control panel" → execute /open control panel
"open steam" → execute /open steam
"open docker" → execute /open docker
"open postman" → execute /open postman
"open any URL (http/https)" → execute /open <url>
"open any file path" → execute /open <path>
"run [command]" → execute /run
"shutdown/turn off/power off" → confirm /shutdown
"restart/reboot" → confirm /restart
"kill/close [app name]" → confirm /kill (search ps first for pid? No — just confirm with process name as arg)
"delete/remove [file]" → confirm /rm
"logout" → confirm /logout

RESPOND WITH ONLY ONE of these JSON shapes:

search_files:
{"action":"search_files","keywords":["keyword1","keyword2"],"file_types":[".mp3",".mp4"],"message":"🔍 Searching your laptop for 'keyword1'..."}

execute:
{"action":"execute","command":"/volume","args":"mute","message":"🔇 Muting volume..."}

generate_and_write:
{"action":"generate_and_write","topic":"GDC Game Developers Conference","format":"txt","filename":"GDC.txt","save_path":"~/Desktop","content_instructions":"Write a comprehensive text covering: history of GDC since 1988, major game announcements, notable talks, impact on gaming industry, famous reveals like Half-Life 2 and No Man's Sky","message":"✍️ Writing a detailed GDC file for you..."}

confirm:
{"action":"confirm","command":"/shutdown","args":"","message":"⚠️ Shut down your laptop?"}

clarify:
{"action":"clarify","message":"🤔 Could you be more specific? Try: 'find my project files', 'check CPU', 'screenshot', 'create a csv about [topic]'"}

No markdown. No explanation. Output ONLY the JSON object.

CONVERSATION HISTORY: You may receive previous messages as context. Use them to understand pronouns like "it", "that file", "same place", or follow-up questions. Always answer the LAST user message."""

CONTENT_SYSTEM_PROMPT = """You write file content for a user saving files to their laptop. Output ONLY the file content — no preamble, no "Here is", no explanation.
- TXT: Clean paragraphs with clear section headings (no markdown). Rich, detailed content.
- CSV: Header row + realistic data rows. Valid comma-separated format only.
- MD: Well-structured markdown with headers, bullet points, code blocks where relevant.
- JSON: Valid, indented JSON with logical structure for the topic."""


# ═══════════════════════════════════════════════════════════════════════════════
#  PROVIDER INFRASTRUCTURE
# ═══════════════════════════════════════════════════════════════════════════════

class ProviderError(Exception):
    """Raised when a provider call fails, triggering fallback to next provider."""
    pass


async def _call_openai_compat(
    base_url: str,
    api_key: str,
    model: str,
    messages: list[dict],
    max_tokens: int = 1024,
    temperature: float = 0.3,
    timeout: float = 30.0,
) -> str:
    """Generic async OpenAI-compatible chat completion. Works for NVIDIA, Groq, Z.AI."""
    try:
        async with httpx.AsyncClient(timeout=timeout) as client:
            resp = await client.post(
                f"{base_url}/chat/completions",
                headers={
                    "Authorization": f"Bearer {api_key}",
                    "Content-Type": "application/json",
                },
                json={
                    "model": model,
                    "messages": messages,
                    "max_tokens": max_tokens,
                    "temperature": temperature,
                },
            )
            if resp.status_code == 429:
                raise ProviderError(f"Rate limited — {base_url}")
            if resp.status_code >= 500:
                raise ProviderError(f"Server error {resp.status_code} — {base_url}")
            resp.raise_for_status()
            data = resp.json()
            return (data["choices"][0]["message"]["content"] or "").strip()
    except httpx.TimeoutException:
        raise ProviderError(f"Timeout — {base_url}")
    except httpx.HTTPStatusError as e:
        raise ProviderError(f"HTTP {e.response.status_code} — {base_url}: {e.response.text[:150]}")
    except ProviderError:
        raise
    except Exception as e:
        raise ProviderError(f"Error — {base_url}: {e}")


# ═══════════════════════════════════════════════════════════════════════════════
#  MAIN AI CLASS
# ═══════════════════════════════════════════════════════════════════════════════

class SalimAI:
    """
    Multi-provider AI brain for Salim.

    Fallback chain: NVIDIA → Groq → Z.AI
    Each provider is optional. If a key isn't set, that provider is skipped.
    """

    def __init__(self, config: Config):
        self.config = config

    # ── Config properties ─────────────────────────────────────────────────────

    @property
    def nvidia_key(self) -> str:
        return self.config.get("SALIM_NVIDIA_API_KEY", "")

    @property
    def nvidia_model(self) -> str:
        return self.config.get("SALIM_NVIDIA_MODEL", "meta/llama-4-maverick-17b-128e-instruct")

    @property
    def groq_key(self) -> str:
        return self.config.get("SALIM_GROQ_API_KEY", "")

    @property
    def groq_model(self) -> str:
        return self.config.get("SALIM_GROQ_MODEL", "openai/gpt-oss-120b")

    @property
    def zai_key(self) -> str:
        return self.config.get("SALIM_ZAI_API_KEY", "")

    @property
    def zai_model(self) -> str:
        return self.config.get("SALIM_ZAI_MODEL", "glm-4.7-flash")

    def is_configured(self) -> bool:
        return bool(self.nvidia_key or self.groq_key or self.zai_key)

    def active_providers(self) -> list[str]:
        result = []
        if self.nvidia_key:
            result.append(f"NVIDIA ({self.nvidia_model.split('/')[-1]})")
        if self.groq_key:
            result.append(f"Groq ({self.groq_model})")
        if self.zai_key:
            result.append(f"Z.AI ({self.zai_model})")
        return result

    def status_line(self) -> str:
        providers = self.active_providers()
        if not providers:
            return "🤖 AI: ❌ not configured (run `salim setup`)"
        chain = " → ".join(providers)
        return f"🤖 AI: ✅ {chain}"

    # ── Core fallback engine ──────────────────────────────────────────────────

    async def _call_with_fallback(
        self,
        messages: list[dict],
        system: str,
        max_tokens: int = 1024,
        temperature: float = 0.3,
    ) -> tuple[str, str]:
        """
        Call providers in order: NVIDIA → Groq → Z.AI.
        Returns (response_text, provider_name_used).
        Raises RuntimeError if all configured providers fail.
        """
        full_messages = [{"role": "system", "content": system}] + messages
        errors: list[str] = []

        if self.nvidia_key:
            try:
                logger.debug(f"Trying NVIDIA/{self.nvidia_model}...")
                text = await _call_openai_compat(
                    "https://integrate.api.nvidia.com/v1",
                    self.nvidia_key, self.nvidia_model, full_messages,
                    max_tokens=max_tokens, temperature=temperature,
                )
                return text, "NVIDIA"
            except ProviderError as e:
                logger.warning(f"NVIDIA failed ({e}) → trying Groq")
                errors.append(f"NVIDIA: {e}")

        if self.groq_key:
            try:
                logger.debug(f"Trying Groq/{self.groq_model}...")
                text = await _call_openai_compat(
                    "https://api.groq.com/openai/v1",
                    self.groq_key, self.groq_model, full_messages,
                    max_tokens=max_tokens, temperature=temperature,
                )
                return text, "Groq"
            except ProviderError as e:
                logger.warning(f"Groq failed ({e}) → trying Z.AI")
                errors.append(f"Groq: {e}")

        if self.zai_key:
            try:
                logger.debug(f"Trying Z.AI/{self.zai_model}...")
                text = await _call_openai_compat(
                    "https://open.bigmodel.cn/api/paas/v4",
                    self.zai_key, self.zai_model, full_messages,
                    max_tokens=max_tokens, temperature=temperature,
                )
                return text, "Z.AI"
            except ProviderError as e:
                errors.append(f"Z.AI: {e}")

        if not self.is_configured():
            raise RuntimeError("No AI providers configured. Run `salim setup` to add API keys.")

        raise RuntimeError(
            "All AI providers failed:\n" + "\n".join(f"  • {e}" for e in errors)
        )

    # ── Public interface ──────────────────────────────────────────────────────

    async def parse_intent(self, user_message: str) -> dict:
        """
        Parse a plain-English user message into a Salim action dict.
        Always returns a dict with at least 'action' and 'message' keys.
        """
        os_info = platform.system()
        messages = [
            {"role": "user", "content": f"[OS: {os_info}]\nUser: {user_message}"}
        ]
        try:
            raw, provider = await self._call_with_fallback(
                messages, INTENT_SYSTEM_PROMPT, max_tokens=512, temperature=0.1
            )
            raw = re.sub(r"```(?:json)?|```", "", raw).strip()
            result = json.loads(raw)
            result["_provider"] = provider
            return result
        except json.JSONDecodeError:
            logger.warning("AI returned non-JSON — falling back to clarify")
            return {
                "action": "clarify",
                "message": "🤔 I didn't understand that. Try rephrasing, or use a /command.",
            }
        except RuntimeError as e:
            return {"action": "error", "message": f"⚠️ {e}"}
        except Exception as e:
            logger.error(f"parse_intent unexpected error: {e}")
            return {"action": "error", "message": f"⚠️ AI error: {e}"}

    async def parse_intent_with_history(
        self, user_message: str, history: list[dict]
    ) -> dict:
        """
        Parse intent with full conversation history injected for context.
        history = list of {role, content} dicts (from ConversationHistoryHandlers).
        """
        os_info = platform.system()
        # Build messages: history first, then current message
        messages = list(history)
        messages.append({"role": "user", "content": f"[OS: {os_info}]\nUser: {user_message}"})
        try:
            raw, provider = await self._call_with_fallback(
                messages, INTENT_SYSTEM_PROMPT, max_tokens=512, temperature=0.1
            )
            raw = re.sub(r"```(?:json)?|```", "", raw).strip()
            result = json.loads(raw)
            result["_provider"] = provider
            return result
        except json.JSONDecodeError:
            logger.warning("AI returned non-JSON — falling back to clarify")
            return {
                "action": "clarify",
                "message": "🤔 I didn't understand that. Try rephrasing, or use a /command.",
            }
        except RuntimeError as e:
            return {"action": "error", "message": f"⚠️ {e}"}
        except Exception as e:
            logger.error(f"parse_intent_with_history error: {e}")
            return {"action": "error", "message": f"⚠️ AI error: {e}"}

    async def generate_content(
        self,
        topic: str,
        format: str,
        instructions: str,
        max_tokens: int = 2048,
    ) -> tuple[str, str]:
        """
        Generate file content. Returns (content, provider_used).
        """
        format_hints = {
            "csv":  "Output ONLY valid CSV. First row must be headers. No explanation.",
            "txt":  "Output ONLY plain text. No markdown symbols.",
            "md":   "Output ONLY well-formatted markdown.",
            "json": "Output ONLY valid, pretty-printed JSON.",
        }
        hint = format_hints.get(format.lower(), "Output ONLY the file content.")
        messages = [
            {
                "role": "user",
                "content": (
                    f"Topic: {topic}\n"
                    f"Format: {format.upper()}\n"
                    f"Instructions: {instructions}\n\n{hint}"
                ),
            }
        ]
        return await self._call_with_fallback(
            messages, CONTENT_SYSTEM_PROMPT, max_tokens=max_tokens, temperature=0.7
        )

    # ── Static catalog helpers ────────────────────────────────────────────────

    @staticmethod
    def nvidia_choices() -> list[str]:
        return [
            f"[{v['tier']}] {v['label']} | {v['best_for']} | {v['context']}"
            for v in NVIDIA_MODELS.values()
        ]

    @staticmethod
    def groq_choices() -> list[str]:
        return [
            f"[{v['tier']}] {v['label']} | {v['speed']}"
            for v in GROQ_MODELS.values()
        ]

    @staticmethod
    def zai_choices() -> list[str]:
        return [
            f"[{v['tier']}] {v['label']} | {v['best_for']}"
            for v in ZAI_MODELS.values()
        ]

    @staticmethod
    def _match_id(choice: str, catalog: dict) -> str:
        for mid, info in catalog.items():
            if info["label"] in choice:
                return mid
        return next(iter(catalog))

    @staticmethod
    def nvidia_id(choice: str) -> str:
        return SalimAI._match_id(choice, NVIDIA_MODELS)

    @staticmethod
    def groq_id(choice: str) -> str:
        return SalimAI._match_id(choice, GROQ_MODELS)

    @staticmethod
    def zai_id(choice: str) -> str:
        return SalimAI._match_id(choice, ZAI_MODELS)
