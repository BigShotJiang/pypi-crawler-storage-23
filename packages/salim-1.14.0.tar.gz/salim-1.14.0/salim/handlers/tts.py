"""
Salim TTS (Text-to-Speech) — send voice note replies from Salim.

Commands:
  /tts <text>          — convert text to speech, send as Telegram voice note
  /say <text>          — alias for /tts
  /tts_voice           — show available voices + current config
  /tts_lang <code>     — set language (en, ar, fr, es, de, zh, ...)
  /tts_speed <0.5-2.0> — set speech speed multiplier
  /tts_engine <gtts|pyttsx3|espeak>  — switch TTS engine

Engines (in priority order, all free & open source):
  1. gTTS   — Google Text-to-Speech (needs internet, best quality, many languages)
  2. pyttsx3 — offline TTS using system voices (no internet, works on all OS)
  3. espeak  — lightweight offline engine (Linux/Mac, install via apt/brew)

Auto-installs: gTTS, pyttsx3, pydub (for audio processing)

Audio pipeline:
  text  →  TTS engine  →  MP3/WAV  →  convert to OGG Opus (Telegram voice format)  →  send
  (Telegram voice notes require OGG Opus codec — ffmpeg handles conversion)
"""
from __future__ import annotations

import asyncio
import html
import io
import json
import logging
import os
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import is_mac, is_linux, is_windows

logger = logging.getLogger("salim.tts")

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

# Config storage file
TTS_CONFIG_FILE = Path.home() / ".salim" / "tts_config.json"


# ── Config ────────────────────────────────────────────────────────────────────

def _load_tts_config() -> dict:
    """Load TTS preferences from ~/.salim/tts_config.json."""
    defaults = {
        "engine": "gtts",    # gtts | pyttsx3 | espeak
        "lang": "en",        # language code
        "speed": 1.0,        # speed multiplier
        "voice_id": None,    # pyttsx3 voice ID
    }
    try:
        if TTS_CONFIG_FILE.exists():
            data = json.loads(TTS_CONFIG_FILE.read_text())
            defaults.update(data)
    except Exception:
        pass
    return defaults


def _save_tts_config(cfg: dict):
    TTS_CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    TTS_CONFIG_FILE.write_text(json.dumps(cfg, indent=2))


# ── Dependency helpers ────────────────────────────────────────────────────────

def _ensure_gtts() -> bool:
    try:
        import gtts  # noqa
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "gTTS", "--quiet"],
            check=True, timeout=60
        )
        return True
    except Exception as e:
        logger.error(f"Failed to install gTTS: {e}")
        return False


def _ensure_pyttsx3() -> bool:
    try:
        import pyttsx3  # noqa
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "pyttsx3", "--quiet"],
            check=True, timeout=60
        )
        # Linux: also need espeak-ng as backend
        if is_linux():
            subprocess.run(
                ["sudo", "apt-get", "install", "-y", "espeak-ng", "libespeak-ng1"],
                capture_output=True, timeout=60
            )
        return True
    except Exception as e:
        logger.error(f"Failed to install pyttsx3: {e}")
        return False


def _ensure_ffmpeg() -> bool:
    return bool(shutil.which("ffmpeg"))


def _ensure_pydub() -> bool:
    try:
        import pydub  # noqa
        return True
    except ImportError:
        pass
    try:
        subprocess.run(
            [sys.executable, "-m", "pip", "install", "pydub", "--quiet"],
            check=True, timeout=60
        )
        return True
    except Exception:
        return False


# ── TTS engines ───────────────────────────────────────────────────────────────

def _tts_gtts(text: str, lang: str = "en", speed: float = 1.0) -> bytes:
    """
    Generate speech using gTTS (Google Text-to-Speech).
    Returns MP3 bytes. Requires internet connection.
    Speed control via pydub (slow/fast).
    """
    from gtts import gTTS
    tts = gTTS(text=text, lang=lang, slow=(speed < 0.8))
    mp3_buf = io.BytesIO()
    tts.write_to_fp(mp3_buf)
    mp3_buf.seek(0)
    mp3_bytes = mp3_buf.read()

    # Adjust speed if needed and pydub is available
    if abs(speed - 1.0) > 0.1:
        try:
            from pydub import AudioSegment
            sound = AudioSegment.from_mp3(io.BytesIO(mp3_bytes))
            # Speed change: frame_rate trick
            new_rate = int(sound.frame_rate * speed)
            faster = sound._spawn(sound.raw_data, overrides={"frame_rate": new_rate})
            faster = faster.set_frame_rate(sound.frame_rate)
            out = io.BytesIO()
            faster.export(out, format="mp3")
            return out.getvalue()
        except Exception as e:
            logger.debug(f"Speed adjustment failed: {e}")

    return mp3_bytes


def _tts_pyttsx3(text: str, lang: str = "en", speed: float = 1.0, voice_id: Optional[str] = None) -> bytes:
    """
    Generate speech using pyttsx3 (fully offline, uses system voices).
    Returns WAV bytes.
    """
    import pyttsx3

    engine = pyttsx3.init()

    # Set speech rate (default is ~200 wpm)
    base_rate = engine.getProperty("rate")
    engine.setProperty("rate", int(base_rate * speed))

    # Set voice if specified
    if voice_id:
        try:
            engine.setProperty("voice", voice_id)
        except Exception:
            pass
    else:
        # Try to find a voice matching the language
        voices = engine.getProperty("voices")
        for v in voices:
            if v.languages and any(
                l.lower().startswith(lang.lower())
                for l in (v.languages if isinstance(v.languages, list) else [v.languages])
            ):
                engine.setProperty("voice", v.id)
                break
            if lang.lower() in (v.id or "").lower():
                engine.setProperty("voice", v.id)
                break

    # Save to temp WAV
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        tmp_path = f.name

    try:
        engine.save_to_file(text, tmp_path)
        engine.runAndWait()
        engine.stop()
        wav_bytes = Path(tmp_path).read_bytes()
        return wav_bytes
    finally:
        Path(tmp_path).unlink(missing_ok=True)


def _tts_espeak(text: str, lang: str = "en", speed: float = 1.0) -> bytes:
    """
    Generate speech using espeak/espeak-ng (lightweight, offline).
    Returns WAV bytes.
    """
    espeak = shutil.which("espeak-ng") or shutil.which("espeak")
    if not espeak:
        raise RuntimeError("espeak not found. Install: sudo apt install espeak-ng")

    wpm = int(160 * speed)  # default ~160 wpm, scale by speed

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        tmp_path = f.name

    try:
        result = subprocess.run(
            [espeak, "-v", lang, "-s", str(wpm), "-w", tmp_path, text],
            capture_output=True, timeout=30
        )
        if result.returncode != 0:
            raise RuntimeError(result.stderr.decode(errors="replace")[:200])
        return Path(tmp_path).read_bytes()
    finally:
        Path(tmp_path).unlink(missing_ok=True)


async def _convert_to_ogg_opus(audio_bytes: bytes, input_format: str = "mp3") -> bytes:
    """
    Convert audio bytes (MP3 or WAV) to OGG Opus format.
    Telegram voice notes require OGG Opus.
    Uses ffmpeg.
    """
    with tempfile.TemporaryDirectory() as tmp:
        in_path  = os.path.join(tmp, f"input.{input_format}")
        out_path = os.path.join(tmp, "output.ogg")

        Path(in_path).write_bytes(audio_bytes)

        proc = await asyncio.create_subprocess_exec(
            "ffmpeg", "-y",
            "-i", in_path,
            "-c:a", "libopus",
            "-b:a", "64k",      # 64kbps — good quality for voice
            "-vbr", "on",
            "-application", "voip",   # optimize for voice
            out_path,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr = await asyncio.wait_for(proc.communicate(), timeout=30)

        if not Path(out_path).exists() or Path(out_path).stat().st_size == 0:
            # Try alternative: fallback to simple ogg vorbis
            proc2 = await asyncio.create_subprocess_exec(
                "ffmpeg", "-y",
                "-i", in_path,
                "-codec:a", "libvorbis",
                "-q:a", "4",
                out_path,
                stdout=asyncio.subprocess.DEVNULL,
                stderr=asyncio.subprocess.DEVNULL,
            )
            await asyncio.wait_for(proc2.communicate(), timeout=30)

        if Path(out_path).exists():
            return Path(out_path).read_bytes()

        # Last resort: return original audio (Telegram may still accept MP3 as audio)
        raise RuntimeError(f"OGG conversion failed: {stderr.decode(errors='replace')[:200]}")


async def generate_tts_voice(
    text: str,
    engine: str = "gtts",
    lang: str = "en",
    speed: float = 1.0,
    voice_id: Optional[str] = None,
) -> tuple[bytes, str]:
    """
    Generate speech and return OGG Opus bytes + engine name used.
    Tries engines in order, falls back on failure.
    """
    loop = asyncio.get_event_loop()
    errors = []

    # Try primary engine
    engines_to_try = [engine, "pyttsx3", "gtts"]  # fallback chain
    # Remove duplicates while preserving order
    seen = set()
    engines_ordered = []
    for e in engines_to_try:
        if e not in seen:
            seen.add(e)
            engines_ordered.append(e)

    for eng in engines_ordered:
        try:
            if eng == "gtts":
                if not _ensure_gtts():
                    errors.append("gtts: install failed")
                    continue
                audio_bytes = await loop.run_in_executor(
                    None, lambda: _tts_gtts(text, lang, speed)
                )
                input_fmt = "mp3"

            elif eng == "pyttsx3":
                if not _ensure_pyttsx3():
                    errors.append("pyttsx3: install failed")
                    continue
                audio_bytes = await loop.run_in_executor(
                    None, lambda: _tts_pyttsx3(text, lang, speed, voice_id)
                )
                input_fmt = "wav"

            elif eng == "espeak":
                audio_bytes = await loop.run_in_executor(
                    None, lambda: _tts_espeak(text, lang, speed)
                )
                input_fmt = "wav"

            else:
                continue

            # Convert to OGG Opus for Telegram
            ogg_bytes = await _convert_to_ogg_opus(audio_bytes, input_fmt)
            return ogg_bytes, eng

        except Exception as e:
            logger.warning(f"TTS engine {eng} failed: {e}")
            errors.append(f"{eng}: {str(e)[:100]}")
            continue

    raise RuntimeError(f"All TTS engines failed:\n" + "\n".join(errors))


# ── Handler class ─────────────────────────────────────────────────────────────

class TTSHandlers:
    """Mixin for Text-to-Speech voice reply commands."""

    def _get_tts_config(self) -> dict:
        return _load_tts_config()

    @require_auth
    async def cmd_tts(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /tts <text>   — Convert text to speech, send as voice note.
        /say <text>   — Same as /tts.
        """
        msg = update.effective_message

        if not ctx.args:
            cfg = self._get_tts_config()
            await msg.reply_text(
                "🗣️ <b>Text-to-Speech</b>\n\n"
                "Usage: <code>/tts &lt;text to speak&gt;</code>\n\n"
                "Examples:\n"
                "<code>/tts Hello, this is Salim speaking</code>\n"
                "<code>/tts CPU usage is high, please check</code>\n\n"
                f"⚙️ Current: engine=<b>{cfg['engine']}</b> · "
                f"lang=<b>{cfg['lang']}</b> · speed=<b>{cfg['speed']}x</b>\n\n"
                "Configure:\n"
                "<code>/tts_lang ar</code> — Arabic\n"
                "<code>/tts_lang en</code> — English\n"
                "<code>/tts_speed 1.5</code> — faster\n"
                "<code>/tts_engine pyttsx3</code> — offline engine",
                parse_mode=H
            )
            return

        if not _ensure_ffmpeg():
            await msg.reply_text(
                "❌ ffmpeg required for voice conversion.\n"
                "Install: <code>sudo apt install ffmpeg</code>",
                parse_mode=H
            )
            return

        text = " ".join(ctx.args)
        if len(text) > 1000:
            await msg.reply_text(
                f"❌ Text too long ({len(text)} chars). Max 1000 chars for TTS.",
                parse_mode=H
            )
            return

        cfg = self._get_tts_config()
        status = await msg.reply_text(
            f"🗣️ <i>Generating speech ({cfg['engine']})...</i>", parse_mode=H
        )

        try:
            ogg_bytes, engine_used = await generate_tts_voice(
                text=text,
                engine=cfg["engine"],
                lang=cfg["lang"],
                speed=cfg["speed"],
                voice_id=cfg.get("voice_id"),
            )

            duration_estimate = max(1, len(text.split()) * 60 // 150)  # ~150 wpm estimate
            size_kb = len(ogg_bytes) // 1024

            await status.delete()

            buf = io.BytesIO(ogg_bytes)
            buf.name = "salim_voice.ogg"

            await msg.reply_voice(
                voice=buf,
                duration=duration_estimate,
                caption=(
                    f"🗣️ <b>Salim Voice</b> [{esc(engine_used)}]\n"
                    f"📝 {len(text)} chars · 💾 {size_kb}KB\n"
                    f"🌐 Lang: {cfg['lang']} · ⚡ Speed: {cfg['speed']}x"
                ),
                parse_mode=H,
            )

        except Exception as e:
            logger.error(f"TTS error: {e}", exc_info=True)
            await status.edit_text(
                f"❌ <b>TTS failed</b>\n<code>{esc(str(e)[:400])}</code>",
                parse_mode=H
            )

    # Alias
    async def cmd_say(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Alias for /tts."""
        await self.cmd_tts(update, ctx)

    @require_auth
    async def cmd_tts_lang(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /tts_lang <code>  — Set TTS language.
        Examples: /tts_lang ar  /tts_lang en  /tts_lang fr  /tts_lang zh
        """
        msg = update.effective_message
        if not ctx.args:
            await msg.reply_text(
                "Usage: <code>/tts_lang &lt;language_code&gt;</code>\n\n"
                "Common codes:\n"
                "en=English, ar=Arabic, fr=French, es=Spanish,\n"
                "de=German, zh=Chinese, ja=Japanese, ru=Russian,\n"
                "it=Italian, pt=Portuguese, hi=Hindi, tr=Turkish",
                parse_mode=H
            )
            return

        lang = ctx.args[0].lower().strip()
        cfg = self._get_tts_config()
        cfg["lang"] = lang
        _save_tts_config(cfg)

        await msg.reply_text(
            f"✅ TTS language set to: <b>{esc(lang)}</b>\n"
            f"<i>Test it: <code>/tts Hello in {esc(lang)}</code></i>",
            parse_mode=H
        )

    @require_auth
    async def cmd_tts_speed(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /tts_speed <0.5-2.0>  — Set speech speed multiplier.
        1.0 = normal, 0.7 = slower, 1.5 = faster
        """
        msg = update.effective_message
        if not ctx.args:
            cfg = self._get_tts_config()
            await msg.reply_text(
                f"Current speed: <b>{cfg['speed']}x</b>\n"
                "Usage: <code>/tts_speed &lt;0.5 to 2.0&gt;</code>\n"
                "Examples: <code>/tts_speed 0.8</code>  <code>/tts_speed 1.5</code>",
                parse_mode=H
            )
            return

        try:
            speed = float(ctx.args[0])
            speed = max(0.5, min(2.0, speed))
        except ValueError:
            await msg.reply_text("❌ Speed must be a number (0.5 to 2.0)", parse_mode=H)
            return

        cfg = self._get_tts_config()
        cfg["speed"] = round(speed, 2)
        _save_tts_config(cfg)

        await msg.reply_text(
            f"✅ TTS speed set to: <b>{speed}x</b>", parse_mode=H
        )

    @require_auth
    async def cmd_tts_engine(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /tts_engine <gtts|pyttsx3|espeak>  — Switch TTS engine.
        gtts    = Google TTS (best quality, needs internet)
        pyttsx3 = Offline system voices (no internet needed)
        espeak  = Lightweight offline (Linux/Mac)
        """
        msg = update.effective_message
        valid_engines = ["gtts", "pyttsx3", "espeak"]

        if not ctx.args or ctx.args[0] not in valid_engines:
            cfg = self._get_tts_config()
            await msg.reply_text(
                f"Current engine: <b>{cfg['engine']}</b>\n\n"
                "Usage: <code>/tts_engine &lt;gtts|pyttsx3|espeak&gt;</code>\n\n"
                "🌐 <b>gtts</b> — Google TTS, best quality, 30+ languages, needs internet\n"
                "💻 <b>pyttsx3</b> — Fully offline, uses system voices, all OS\n"
                "🐧 <b>espeak</b> — Lightweight offline, Linux/Mac, many languages",
                parse_mode=H
            )
            return

        engine = ctx.args[0]
        cfg = self._get_tts_config()
        cfg["engine"] = engine
        _save_tts_config(cfg)

        await msg.reply_text(
            f"✅ TTS engine set to: <b>{esc(engine)}</b>", parse_mode=H
        )

    @require_auth
    async def cmd_tts_voice(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /tts_voice  — List available voices for the current engine.
        """
        msg = update.effective_message
        cfg = self._get_tts_config()
        engine = cfg["engine"]

        if engine == "pyttsx3":
            if not _ensure_pyttsx3():
                await msg.reply_text("❌ pyttsx3 not installed.", parse_mode=H)
                return
            try:
                import pyttsx3
                tts_engine = pyttsx3.init()
                voices = tts_engine.getProperty("voices")
                tts_engine.stop()

                if not voices:
                    await msg.reply_text(
                        "No system voices found.\n"
                        "On Linux, install: <code>sudo apt install espeak-ng</code>",
                        parse_mode=H
                    )
                    return

                lines = []
                for i, v in enumerate(voices[:20]):  # limit to 20
                    langs = v.languages[:2] if v.languages else ["?"]
                    lines.append(
                        f"<b>{i}</b>. <code>{esc(v.id.split('.')[-1][:30])}</code> "
                        f"— {esc(str(langs[0])[:10])}"
                    )

                await msg.reply_text(
                    f"🗣️ <b>Available pyttsx3 Voices ({len(voices)} found)</b>\n\n"
                    + "\n".join(lines)
                    + "\n\nSet: <code>/config set tts_voice &lt;voice_id&gt;</code>",
                    parse_mode=H
                )

            except Exception as e:
                await msg.reply_text(f"❌ Error listing voices: {esc(str(e))}", parse_mode=H)

        elif engine == "gtts":
            await msg.reply_text(
                "🌐 <b>gTTS Voices (Google TTS)</b>\n\n"
                "Language-based (no individual voice selection).\n\n"
                "Supported languages include:\n"
                "en, ar, fr, es, de, it, pt, ru, zh-CN, zh-TW,\n"
                "ja, ko, hi, tr, pl, nl, sv, da, fi, nb, uk\n\n"
                "Set: <code>/tts_lang &lt;code&gt;</code>",
                parse_mode=H
            )

        elif engine == "espeak":
            try:
                espeak = shutil.which("espeak-ng") or shutil.which("espeak")
                if not espeak:
                    await msg.reply_text(
                        "❌ espeak not installed.\n"
                        "Install: <code>sudo apt install espeak-ng</code>",
                        parse_mode=H
                    )
                    return

                result = subprocess.run(
                    [espeak, "--voices"],
                    capture_output=True, text=True, timeout=5
                )
                voices_text = result.stdout[:2000]
                await msg.reply_text(
                    f"🗣️ <b>espeak Voices</b>\n<pre>{esc(voices_text)}</pre>",
                    parse_mode=H
                )
            except Exception as e:
                await msg.reply_text(f"❌ Error: {esc(str(e))}", parse_mode=H)
