"""
Salim Alert System — threshold-based background monitoring.

Commands:
  /alert add cpu > 80          — alert when CPU usage exceeds 80%
  /alert add ram > 90          — alert when RAM exceeds 90%
  /alert add disk < 10         — alert when disk free < 10GB
  /alert add battery < 20      — alert when battery below 20%
  /alert add temp > 85         — alert when CPU temp exceeds 85°C
  /alert add net_up > 10       — alert when upload > 10 MB/s
  /alert add process python    — alert when process named 'python' starts/stops
  /alert list                  — show all active alerts
  /alert del <id>              — remove an alert
  /alert clear                 — remove all alerts
  /alert test                  — trigger a test alert immediately

Each alert fires once when triggered, then re-arms after the condition clears.
All alerts persist in ~/.salim/alerts.json across restarts.
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Any

import psutil
from telegram import Update, Bot
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import bytes_to_human

logger = logging.getLogger("salim.alerts")

ALERTS_FILE = Path.home() / ".salim" / "alerts.json"

# Metrics that can be monitored
METRIC_HELP = {
    "cpu":       ("CPU usage %",           "cpu > 80"),
    "ram":       ("RAM usage %",           "ram > 90"),
    "disk":      ("Disk free GB",          "disk < 5"),
    "battery":   ("Battery %",             "battery < 20"),
    "temp":      ("CPU temperature °C",    "temp > 85"),
    "net_up":    ("Network upload MB/s",   "net_up > 10"),
    "net_down":  ("Network download MB/s", "net_down > 50"),
    "swap":      ("Swap usage %",          "swap > 80"),
    "process":   ("Process running",       "process chrome"),
}


def _read_alerts() -> dict:
    try:
        if ALERTS_FILE.exists():
            return json.loads(ALERTS_FILE.read_text())
    except Exception:
        pass
    return {}


def _write_alerts(alerts: dict):
    ALERTS_FILE.parent.mkdir(parents=True, exist_ok=True)
    ALERTS_FILE.write_text(json.dumps(alerts, indent=2))


def _get_metric(metric: str) -> float | None:
    """Read the current value of a metric. Returns None if unavailable."""
    try:
        if metric == "cpu":
            return psutil.cpu_percent(interval=0.5)
        elif metric == "ram":
            return psutil.virtual_memory().percent
        elif metric == "disk":
            usage = psutil.disk_usage("/")
            return usage.free / (1024 ** 3)  # GB free
        elif metric == "battery":
            bat = psutil.sensors_battery()
            return bat.percent if bat else None
        elif metric == "temp":
            temps = psutil.sensors_temperatures()
            if not temps:
                return None
            all_temps = [t.current for sensors in temps.values() for t in sensors]
            return max(all_temps) if all_temps else None
        elif metric in ("net_up", "net_down"):
            n1 = psutil.net_io_counters()
            time.sleep(1)
            n2 = psutil.net_io_counters()
            if metric == "net_up":
                return (n2.bytes_sent - n1.bytes_sent) / (1024 * 1024)  # MB/s
            else:
                return (n2.bytes_recv - n1.bytes_recv) / (1024 * 1024)
        elif metric == "swap":
            return psutil.swap_memory().percent
    except Exception as e:
        logger.debug(f"Metric {metric} error: {e}")
    return None


def _check_process_alert(process_name: str, expected_running: bool) -> tuple[bool, str]:
    """Returns (triggered, message)."""
    running_names = {p.name().lower() for p in psutil.process_iter(["name"])}
    is_running = process_name.lower() in running_names
    if expected_running and not is_running:
        return True, f"❌ Process <b>{process_name}</b> has stopped!"
    if not expected_running and is_running:
        return True, f"⚠️ Process <b>{process_name}</b> has started!"
    return False, ""


def _check_threshold(value: float, op: str, threshold: float) -> bool:
    if op == ">":
        return value > threshold
    elif op == "<":
        return value < threshold
    elif op == ">=":
        return value >= threshold
    elif op == "<=":
        return value <= threshold
    elif op == "==":
        return abs(value - threshold) < 0.01
    return False


def _format_metric_value(metric: str, value: float) -> str:
    if metric == "disk":
        return f"{value:.1f} GB free"
    elif metric in ("net_up", "net_down"):
        return f"{value:.2f} MB/s"
    elif metric == "temp":
        return f"{value:.0f}°C"
    else:
        return f"{value:.1f}%"


ALERT_ICONS = {
    "cpu": "🔥", "ram": "🧠", "disk": "💿", "battery": "🔋",
    "temp": "🌡️", "net_up": "📤", "net_down": "📥",
    "swap": "💾", "process": "⚙️",
}


class AlertMonitor:
    """
    Background monitor. Created once per bot instance.
    Runs a poll loop every 30 seconds checking all registered alerts.
    """

    def __init__(self, bot: Bot, allowed_ids: list[int]):
        self.bot = bot
        self.allowed_ids = allowed_ids
        self._task: asyncio.Task | None = None
        self._fired: dict[str, bool] = {}   # alert_id → currently triggered

    def start(self):
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._loop())
            logger.info("Alert monitor started")

    def stop(self):
        if self._task:
            self._task.cancel()

    async def _loop(self):
        while True:
            try:
                await self._check_all()
            except Exception as e:
                logger.error(f"Alert loop error: {e}")
            await asyncio.sleep(30)

    async def _check_all(self):
        alerts = _read_alerts()
        if not alerts:
            return

        for aid, alert in list(alerts.items()):
            try:
                triggered, message = await asyncio.get_event_loop().run_in_executor(
                    None, self._evaluate, aid, alert
                )

                already_fired = self._fired.get(aid, False)

                if triggered and not already_fired:
                    self._fired[aid] = True
                    # Notify all allowed users
                    for uid in self.allowed_ids:
                        try:
                            await self.bot.send_message(
                                chat_id=uid,
                                text=f"🚨 <b>SALIM ALERT</b>\n\n{message}\n\n"
                                     f"<i>Alert ID: {aid} · {datetime.now().strftime('%H:%M:%S')}</i>",
                                parse_mode="HTML"
                            )
                        except Exception as e:
                            logger.warning(f"Failed to notify {uid}: {e}")

                elif not triggered and already_fired:
                    # Condition cleared — re-arm alert
                    self._fired[aid] = False

            except Exception as e:
                logger.debug(f"Alert {aid} check error: {e}")

    def _evaluate(self, aid: str, alert: dict) -> tuple[bool, str]:
        metric = alert.get("metric", "")
        icon = ALERT_ICONS.get(metric, "⚠️")

        if metric == "process":
            process_name = alert.get("process_name", "")
            expected = alert.get("expected_running", True)
            return _check_process_alert(process_name, expected)

        op = alert.get("op", ">")
        threshold = float(alert.get("threshold", 0))
        value = _get_metric(metric)

        if value is None:
            return False, ""

        triggered = _check_threshold(value, op, threshold)
        if triggered:
            val_str = _format_metric_value(metric, value)
            thr_str = _format_metric_value(metric, threshold)
            message = (
                f"{icon} <b>{metric.upper()}</b> threshold crossed!\n"
                f"Current: <b>{val_str}</b>\n"
                f"Threshold: {op} {thr_str}"
            )
            return True, message
        return False, ""


# Global monitor instance
_monitor: AlertMonitor | None = None


def get_monitor() -> AlertMonitor | None:
    return _monitor


def start_monitor(bot: Bot, allowed_ids: list[int]):
    global _monitor
    if _monitor is None:
        _monitor = AlertMonitor(bot, allowed_ids)
    _monitor.start()


class AlertHandlers:

    @require_auth
    async def cmd_alert(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /alert add cpu > 80
        /alert add battery < 20
        /alert add process chrome
        /alert list
        /alert del <id>
        /alert clear
        /alert test
        """
        args = ctx.args or []
        msg = update.effective_message

        if not args or args[0] == "list":
            await self._alert_list(msg)
            return

        sub = args[0].lower()

        if sub == "test":
            await self._alert_test(msg)
            return

        if sub == "clear":
            _write_alerts({})
            await msg.reply_text("🗑️ All alerts cleared.")
            return

        if sub in ("del", "delete", "remove") and len(args) >= 2:
            alerts = _read_alerts()
            aid = args[1]
            if aid in alerts:
                del alerts[aid]
                _write_alerts(alerts)
                await msg.reply_text(f"✅ Alert <code>{aid}</code> removed.", parse_mode="HTML")
            else:
                await msg.reply_text(f"❌ Alert <code>{aid}</code> not found.", parse_mode="HTML")
            return

        if sub == "add":
            await self._alert_add(msg, args[1:])
            return

        # No subcommand — show help
        metric_lines = "\n".join(
            f"  <code>/alert add {example}</code>  — {desc}"
            for metric, (desc, example) in METRIC_HELP.items()
        )
        await msg.reply_text(
            "🚨 <b>Alert System</b>\n\n"
            "<b>Commands:</b>\n"
            "  <code>/alert add &lt;metric&gt; &lt;op&gt; &lt;value&gt;</code>\n"
            "  <code>/alert list</code>\n"
            "  <code>/alert del &lt;id&gt;</code>\n"
            "  <code>/alert clear</code>\n"
            "  <code>/alert test</code>\n\n"
            "<b>Examples:</b>\n" + metric_lines +
            "\n\nFor process alerts: <code>/alert add process chrome</code>",
            parse_mode="HTML"
        )

    async def _alert_add(self, msg, args: list[str]):
        if not args:
            await msg.reply_text("Usage: <code>/alert add cpu > 80</code>", parse_mode="HTML")
            return

        metric = args[0].lower()

        # Process alert (special syntax)
        if metric == "process":
            if len(args) < 2:
                await msg.reply_text("Usage: <code>/alert add process &lt;name&gt;</code>", parse_mode="HTML")
                return
            process_name = args[1]
            aid = f"proc_{process_name}_{int(time.time())}"
            alerts = _read_alerts()
            alerts[aid] = {
                "metric": "process",
                "process_name": process_name,
                "expected_running": True,
                "created": datetime.now().isoformat(),
            }
            _write_alerts(alerts)
            await msg.reply_text(
                f"✅ Alert <code>{aid}</code> added:\n"
                f"⚙️ Notify when process <b>{process_name}</b> stops/starts",
                parse_mode="HTML"
            )
            return

        if metric not in METRIC_HELP:
            await msg.reply_text(
                f"❌ Unknown metric: <code>{metric}</code>\n"
                f"Valid: {', '.join(METRIC_HELP.keys())}",
                parse_mode="HTML"
            )
            return

        if len(args) < 3:
            await msg.reply_text(
                f"Usage: <code>/alert add {metric} &gt; 80</code>",
                parse_mode="HTML"
            )
            return

        op = args[1]
        if op not in (">", "<", ">=", "<=", "=="):
            await msg.reply_text("❌ Operator must be: > < >= <= ==")
            return

        try:
            threshold = float(args[2])
        except ValueError:
            await msg.reply_text("❌ Threshold must be a number.")
            return

        aid = f"{metric}_{op.replace('>','gt').replace('<','lt')}_{int(threshold)}_{int(time.time())}"
        alerts = _read_alerts()
        alerts[aid] = {
            "metric": metric,
            "op": op,
            "threshold": threshold,
            "created": datetime.now().isoformat(),
        }
        _write_alerts(alerts)

        icon = ALERT_ICONS.get(metric, "⚠️")
        desc, _ = METRIC_HELP.get(metric, ("", ""))
        await msg.reply_text(
            f"✅ Alert <code>{aid}</code> added:\n"
            f"{icon} <b>{desc}</b> {op} {threshold}\n\n"
            f"<i>Checks every 30s. Fires once, re-arms when condition clears.</i>",
            parse_mode="HTML"
        )

        # Start monitor if not already running
        if hasattr(self, "_app") and self._app:
            start_monitor(self._app.bot, self.config.allowed_ids)

    async def _alert_list(self, msg):
        alerts = _read_alerts()
        if not alerts:
            await msg.reply_text(
                "📋 No alerts configured.\n\n"
                "Add one: <code>/alert add cpu > 80</code>",
                parse_mode="HTML"
            )
            return

        monitor = get_monitor()
        lines = []
        for aid, alert in alerts.items():
            metric = alert.get("metric", "")
            icon = ALERT_ICONS.get(metric, "⚠️")
            firing = monitor and monitor._fired.get(aid, False)
            status = "🔴 FIRING" if firing else "🟢 armed"

            if metric == "process":
                lines.append(
                    f"{icon} <code>{aid}</code>\n"
                    f"   Process: {alert.get('process_name','?')} · {status}"
                )
            else:
                op = alert.get("op", ">")
                thr = alert.get("threshold", 0)
                lines.append(
                    f"{icon} <code>{aid}</code>\n"
                    f"   {metric} {op} {thr} · {status}"
                )

        await msg.reply_text(
            f"🚨 <b>Active Alerts ({len(alerts)})</b>\n\n" + "\n\n".join(lines) +
            "\n\n<code>/alert del &lt;id&gt;</code> to remove",
            parse_mode="HTML"
        )

    async def _alert_test(self, msg):
        """Fire a test alert immediately to verify Telegram delivery."""
        await msg.reply_text(
            "🚨 <b>SALIM ALERT — TEST</b>\n\n"
            "✅ Alert delivery is working!\n"
            "CPU: 99% · RAM: 95% · DISK: 2GB\n\n"
            "<i>This was a test. Real alerts fire when your thresholds are crossed.</i>",
            parse_mode="HTML"
        )

    def _start_alert_monitor(self, app):
        """Called from bot startup to begin monitoring."""
        self._app = app
        alerts = _read_alerts()
        if alerts:
            start_monitor(app.bot, self.config.allowed_ids)
            logger.info(f"Alert monitor started with {len(alerts)} alerts")
