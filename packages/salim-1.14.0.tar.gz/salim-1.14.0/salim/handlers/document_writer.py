"""
Salim Document Writer — AI-powered professional document generator.

Supported document types (auto-detected from natural language):
  Word (.docx): Resume, Cover Letter, Job Application, Business Letter,
                Meeting Minutes, Business Report, Internship Application,
                Resignation Letter, NOC (No Objection Certificate), Memo
  Excel (.xlsx): Invoice, Budget Tracker, Expense Report, Project Plan,
                 Attendance Sheet, Salary Sheet, Inventory List

Usage (from Telegram):
  "write me a resume for Ahmed, software engineer with 5 years experience"
  "create a cover letter for a marketing manager position at Google"
  "make an invoice for client Acme Corp, 3 items"
  "generate a monthly budget tracker for June"
  "write a resignation letter, last day July 15"
"""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
import sys
import tempfile
from datetime import datetime
from pathlib import Path

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.document_writer")

# ─────────────────────────────────────────────────────────────────────────────
#  DOCUMENT TYPE DETECTION
# ─────────────────────────────────────────────────────────────────────────────

WORD_TYPES = {
    "resume": ["resume", "cv", "curriculum vitae"],
    "cover_letter": ["cover letter", "covering letter"],
    "job_application": ["job application", "application letter", "application for"],
    "business_letter": ["business letter", "formal letter", "official letter"],
    "resignation": ["resignation", "resign", "leaving letter", "quit letter"],
    "internship": ["internship", "intern application", "internship letter"],
    "noc": ["noc", "no objection", "no-objection certificate"],
    "memo": ["memo", "memorandum", "internal note"],
    "meeting_minutes": ["meeting minutes", "minutes of meeting", "mom"],
    "report": ["report", "business report", "project report"],
}

EXCEL_TYPES = {
    "invoice": ["invoice", "bill", "receipt"],
    "budget": ["budget", "budget tracker", "monthly budget"],
    "expense": ["expense", "expense report", "expenses"],
    "project_plan": ["project plan", "gantt", "task tracker", "timeline"],
    "attendance": ["attendance", "attendance sheet", "staff attendance"],
    "salary": ["salary", "payroll", "payslip", "wage sheet"],
    "inventory": ["inventory", "stock list", "product list", "items list"],
}


def detect_doc_type(text: str):
    """Returns (category, doc_type) or (None, None)."""
    t = text.lower()
    for dtype, keywords in WORD_TYPES.items():
        if any(k in t for k in keywords):
            return "word", dtype
    for dtype, keywords in EXCEL_TYPES.items():
        if any(k in t for k in keywords):
            return "excel", dtype
    return None, None


# ─────────────────────────────────────────────────────────────────────────────
#  AI CONTENT GENERATOR  (uses Salim's existing AI providers)
# ─────────────────────────────────────────────────────────────────────────────

SYSTEM_PROMPT = """You are a professional document content generator.
Return ONLY valid JSON — no markdown, no explanation, no code fences.
Follow the exact schema requested. Use professional formal language."""


def _build_prompt(doc_type: str, user_request: str) -> str:
    schemas = {
        "resume": '''{"name":"Full Name","job_title":"Job Title","phone":"+1-234-567-8900","email":"email@example.com","location":"City, Country","summary":"2-3 sentence professional summary","experience":[{"title":"Job Title","company":"Company Name","period":"Jan 2020 – Present","bullets":["Achievement 1","Achievement 2","Achievement 3"]}],"education":[{"degree":"Degree Name","institution":"University","year":"2018"}],"skills":["Skill 1","Skill 2","Skill 3","Skill 4","Skill 5"],"certifications":["Cert 1"]}''',
        "cover_letter": '''{"sender_name":"Full Name","sender_address":"City, Country","sender_email":"email@example.com","date":"February 27, 2026","hiring_manager":"Hiring Manager","company":"Company Name","position":"Position Applied For","opening_paragraph":"Strong opening paragraph","body_paragraph1":"Why you are qualified","body_paragraph2":"What you bring to the company","closing_paragraph":"Call to action closing","sign_off":"Sincerely"}''',
        "job_application": '''{"applicant_name":"Full Name","date":"February 27, 2026","position":"Job Title","department":"Department","company":"Company Name","intro":"Opening paragraph","qualifications":"Qualifications paragraph","motivation":"Why this company","closing":"Closing paragraph"}''',
        "business_letter": '''{"sender_name":"Full Name","sender_title":"Title","company":"Company Name","address":"Address","date":"February 27, 2026","recipient_name":"Recipient Name","recipient_title":"Title","recipient_company":"Company","subject":"RE: Subject","body":["Paragraph 1","Paragraph 2","Paragraph 3"],"closing":"Yours sincerely"}''',
        "resignation": '''{"employee_name":"Full Name","position":"Current Job Title","company":"Company Name","manager_name":"Manager Name","date":"February 27, 2026","last_day":"March 27, 2026","reason":"brief reason (optional, can be empty)","gratitude":"gratitude statement","transition":"transition offer"}''',
        "internship": '''{"applicant_name":"Full Name","date":"February 27, 2026","company":"Company Name","department":"Department","manager_name":"Hiring Manager","program":"Internship Program Name","intro":"Opening","academic_background":"Education paragraph","skills":"Skills paragraph","closing":"Closing paragraph"}''',
        "noc": '''{"issuer_name":"Issuing Authority Name","issuer_title":"Title","company":"Organization","date":"February 27, 2026","beneficiary_name":"Person Name","purpose":"Purpose of NOC","details":"Details paragraph","validity":"Valid until: [date]"}''',
        "memo": '''{"to":"Recipients","from":"Sender Name","date":"February 27, 2026","subject":"Memo Subject","body":["Point 1","Point 2","Point 3"],"action_required":"Action required statement"}''',
        "meeting_minutes": '''{"meeting_title":"Meeting Title","date":"February 27, 2026","time":"10:00 AM","location":"Conference Room / Online","attendees":["Person 1","Person 2"],"agenda":["Item 1","Item 2"],"discussion":[{"topic":"Topic 1","notes":"Discussion notes","action":"Action item"}],"next_meeting":"Date TBD"}''',
        "report": '''{"title":"Report Title","author":"Author Name","date":"February 27, 2026","department":"Department","executive_summary":"2-3 sentence summary","sections":[{"heading":"Section 1","content":"Section content paragraph"},{"heading":"Section 2","content":"Section content paragraph"}],"conclusion":"Conclusion paragraph","recommendations":["Recommendation 1","Recommendation 2"]}''',
        "invoice": '''{"invoice_number":"INV-001","date":"2026-02-27","due_date":"2026-03-27","from_name":"Your Company","from_address":"Your Address","from_email":"email@company.com","to_name":"Client Name","to_address":"Client Address","items":[{"description":"Service/Product","qty":1,"unit_price":100.00}],"notes":"Payment terms: Net 30","tax_rate":0.1}''',
        "budget": '''{"title":"Monthly Budget – February 2026","person":"Name","income":[{"source":"Salary","amount":5000},{"source":"Freelance","amount":500}],"expenses":[{"category":"Rent","planned":1200,"actual":1200},{"category":"Food","planned":400,"actual":350},{"category":"Transport","planned":150,"actual":180},{"category":"Utilities","planned":100,"actual":95},{"category":"Entertainment","planned":200,"actual":250},{"category":"Savings","planned":500,"actual":500}]}''',
        "expense": '''{"title":"Expense Report","employee":"Employee Name","department":"Department","period":"February 2026","manager":"Manager Name","expenses":[{"date":"2026-02-01","category":"Travel","description":"Taxi to client meeting","amount":45.00},{"date":"2026-02-05","category":"Meals","description":"Team lunch","amount":120.00}]}''',
        "project_plan": '''{"project":"Project Name","manager":"Project Manager","start_date":"2026-03-01","end_date":"2026-06-30","tasks":[{"task":"Task 1","owner":"Name","start":"2026-03-01","end":"2026-03-15","status":"Not Started"},{"task":"Task 2","owner":"Name","start":"2026-03-10","end":"2026-04-01","status":"Not Started"}]}''',
        "attendance": '''{"title":"Attendance Sheet","department":"Department","month":"February 2026","employees":[{"id":"001","name":"Employee 1","designation":"Role"},{"id":"002","name":"Employee 2","designation":"Role"}],"working_days":22}''',
        "salary": '''{"title":"Salary Sheet","company":"Company Name","month":"February 2026","employees":[{"id":"001","name":"Employee Name","designation":"Job Title","basic":3000,"hra":500,"transport":200,"deductions":200}]}''',
        "inventory": '''{"title":"Inventory List","company":"Company Name","date":"2026-02-27","items":[{"sku":"SKU001","name":"Product Name","category":"Category","quantity":50,"unit_price":25.00,"reorder_level":10}]}''',
    }

    schema = schemas.get(doc_type, "{}")
    return f"""The user wants: "{user_request}"

Generate realistic, professional content for a {doc_type.replace("_", " ")} document.
Return ONLY this JSON structure (fill all fields with real content based on the request):
{schema}

Rules:
- Infer missing details intelligently (name, company, etc.) from context
- Use today's date: {datetime.now().strftime("%B %d, %Y")}
- Write in formal professional English
- Make content specific and realistic, not generic placeholders"""


async def generate_content_via_ai(salim_bot, doc_type: str, user_request: str) -> dict | None:
    """Use Salim's existing AI engine to generate document content as JSON."""
    try:
        prompt = _build_prompt(doc_type, user_request)
        # Access Salim's AI module
        ai = salim_bot.ai if hasattr(salim_bot, "ai") else None
        if ai and hasattr(ai, "ask"):
            raw = await ai.ask(prompt, system=SYSTEM_PROMPT)
        elif ai and hasattr(ai, "complete"):
            raw = await ai.complete(prompt)
        else:
            # Fallback: try direct HTTP to any configured provider
            raw = await _fallback_ai_call(salim_bot, prompt)

        if not raw:
            return None

        # Strip markdown fences if present
        raw = re.sub(r"```json\s*|\s*```", "", raw.strip())
        return json.loads(raw)
    except Exception as e:
        logger.warning(f"AI content generation failed: {e}")
        return None


async def _fallback_ai_call(salim_bot, prompt: str) -> str | None:
    """Direct call to Salim's configured AI providers."""
    try:
        from salim.ai import SalimAI
        cfg = salim_bot.config if hasattr(salim_bot, "config") else None
        if cfg is None:
            return None
        ai = SalimAI(cfg)
        result = await ai.ask(prompt, system=SYSTEM_PROMPT)
        return result
    except Exception as e:
        logger.warning(f"Fallback AI call failed: {e}")
        return None


# ─────────────────────────────────────────────────────────────────────────────
#  WORD DOCUMENT BUILDERS  (via docx npm library)
# ─────────────────────────────────────────────────────────────────────────────

def build_word_js(doc_type: str, data: dict) -> str:
    """Return Node.js script that creates a properly formatted .docx file."""

    builders = {
        "resume": _resume_js,
        "cover_letter": _cover_letter_js,
        "job_application": _job_application_js,
        "business_letter": _business_letter_js,
        "resignation": _resignation_js,
        "internship": _internship_js,
        "noc": _noc_js,
        "memo": _memo_js,
        "meeting_minutes": _meeting_minutes_js,
        "report": _report_js,
    }
    builder = builders.get(doc_type, _generic_word_js)
    return builder(data)


def _js_header():
    return """
const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
        AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType,
        VerticalAlign, LevelFormat, TabStopType, TabStopPosition } = require('docx');
const fs = require('fs');

const PAGE = { width: 12240, height: 15840 };
const MARGIN = { top: 1440, right: 1440, bottom: 1440, left: 1440 };
const CONTENT_WIDTH = 9360;

function hr(color = '2E74B5') {
  return new Paragraph({
    border: { bottom: { style: BorderStyle.SINGLE, size: 6, color, space: 1 } },
    spacing: { after: 120 }
  });
}

function spacer(after = 160) {
  return new Paragraph({ spacing: { after } });
}

function heading1(text, color = '1F3864') {
  return new Paragraph({
    children: [new TextRun({ text, bold: true, size: 36, color, font: 'Calibri' })],
    spacing: { before: 240, after: 120 }
  });
}

function heading2(text, color = '2E74B5') {
  return new Paragraph({
    children: [new TextRun({ text: text.toUpperCase(), bold: true, size: 24, color, font: 'Calibri', characterSpacing: 20 })],
    spacing: { before: 200, after: 60 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: '2E74B5', space: 1 } }
  });
}

function bodyText(text, opts = {}) {
  return new Paragraph({
    children: [new TextRun({ text, size: 22, font: 'Calibri', ...opts })],
    spacing: { after: 120 },
    alignment: opts.justify ? AlignmentType.JUSTIFIED : AlignmentType.LEFT
  });
}

function boldLabel(label, value) {
  return new Paragraph({
    children: [
      new TextRun({ text: label + ': ', bold: true, size: 22, font: 'Calibri' }),
      new TextRun({ text: value, size: 22, font: 'Calibri' })
    ],
    spacing: { after: 80 }
  });
}
"""


def _resume_js(d: dict) -> str:
    data_json = json.dumps(d, ensure_ascii=False)
    return _js_header() + f"""
const d = {data_json};

const experienceItems = (d.experience || []).flatMap(exp => [
  new Paragraph({{
    children: [
      new TextRun({{ text: exp.title, bold: true, size: 22, font: 'Calibri' }}),
      new TextRun({{ text: '  |  ', size: 22, font: 'Calibri', color: '888888' }}),
      new TextRun({{ text: exp.company, size: 22, font: 'Calibri', italics: true }}),
    ],
    spacing: {{ before: 120, after: 40 }}
  }}),
  new Paragraph({{
    children: [new TextRun({{ text: exp.period, size: 20, font: 'Calibri', color: '666666' }})],
    spacing: {{ after: 60 }}
  }}),
  ...(exp.bullets || []).map(b => new Paragraph({{
    numbering: {{ reference: 'bullets', level: 0 }},
    children: [new TextRun({{ text: b, size: 22, font: 'Calibri' }})]
  }})),
  spacer(80)
]);

const doc = new Document({{
  numbering: {{ config: [{{ reference: 'bullets', levels: [{{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: {{ paragraph: {{ indent: {{ left: 360, hanging: 180 }} }} }} }}] }}] }},
  styles: {{ default: {{ document: {{ run: {{ font: 'Calibri', size: 22 }} }} }} }},
  sections: [{{
    properties: {{ page: {{ size: PAGE, margin: MARGIN }} }},
    children: [
      // NAME & CONTACT HEADER
      new Paragraph({{
        children: [new TextRun({{ text: d.name, bold: true, size: 52, color: '1F3864', font: 'Calibri Light' }})],
        spacing: {{ after: 60 }}
      }}),
      new Paragraph({{
        children: [new TextRun({{ text: d.job_title, size: 26, color: '2E74B5', font: 'Calibri', italics: true }})],
        spacing: {{ after: 80 }}
      }}),
      new Paragraph({{
        children: [
          new TextRun({{ text: '📧 ' + d.email, size: 20, font: 'Calibri', color: '444444' }}),
          new TextRun({{ text: '   📞 ' + d.phone, size: 20, font: 'Calibri', color: '444444' }}),
          new TextRun({{ text: '   📍 ' + d.location, size: 20, font: 'Calibri', color: '444444' }})
        ],
        spacing: {{ after: 160 }}
      }}),
      hr('2E74B5'),
      spacer(80),

      // PROFESSIONAL SUMMARY
      heading2('Professional Summary'),
      bodyText(d.summary, {{ justify: true }}),
      spacer(80),

      // EXPERIENCE
      heading2('Work Experience'),
      ...experienceItems,
      spacer(80),

      // EDUCATION
      heading2('Education'),
      ...(d.education || []).flatMap(e => [
        new Paragraph({{
          children: [
            new TextRun({{ text: e.degree, bold: true, size: 22, font: 'Calibri' }}),
            new TextRun({{ text: '  —  ' + e.institution + '  (' + e.year + ')', size: 22, font: 'Calibri', italics: true }})
          ],
          spacing: {{ after: 80 }}
        }})
      ]),
      spacer(80),

      // SKILLS
      heading2('Core Skills'),
      new Paragraph({{
        children: (d.skills || []).flatMap((s, i) => [
          new TextRun({{ text: s, size: 22, font: 'Calibri' }}),
          i < d.skills.length - 1 ? new TextRun({{ text: '   •   ', size: 22, font: 'Calibri', color: '2E74B5' }}) : new TextRun('')
        ]),
        spacing: {{ after: 80 }}
      }}),

      // CERTIFICATIONS
      ...(d.certifications && d.certifications.length ? [
        spacer(80),
        heading2('Certifications'),
        ...(d.certifications || []).map(c => new Paragraph({{
          numbering: {{ reference: 'bullets', level: 0 }},
          children: [new TextRun({{ text: c, size: 22, font: 'Calibri' }})]
        }}))
      ] : [])
    ]
  }}]
}});

Packer.toBuffer(doc).then(buf => fs.writeFileSync(process.argv[2], buf));
console.log('OK');
"""


def _cover_letter_js(d: dict) -> str:
    data_json = json.dumps(d, ensure_ascii=False)
    return _js_header() + f"""
const d = {data_json};

const doc = new Document({{
  styles: {{ default: {{ document: {{ run: {{ font: 'Calibri', size: 24 }} }} }} }},
  sections: [{{
    properties: {{ page: {{ size: PAGE, margin: MARGIN }} }},
    children: [
      new Paragraph({{ children: [new TextRun({{ text: d.sender_name, bold: true, size: 28, font: 'Calibri' }})], spacing: {{ after: 60 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.sender_address, size: 22, font: 'Calibri', color: '555555' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.sender_email, size: 22, font: 'Calibri', color: '555555' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.date, size: 22, font: 'Calibri' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.hiring_manager, bold: true, size: 22, font: 'Calibri' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.company, size: 22, font: 'Calibri' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'RE: Application for ' + d.position, bold: true, size: 22, font: 'Calibri', color: '1F3864' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'Dear ' + d.hiring_manager + ',', size: 22, font: 'Calibri' }})], spacing: {{ after: 160 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.opening_paragraph, size: 22, font: 'Calibri' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.body_paragraph1, size: 22, font: 'Calibri' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.body_paragraph2, size: 22, font: 'Calibri' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.closing_paragraph, size: 22, font: 'Calibri' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 240 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.sign_off + ',', size: 22, font: 'Calibri' }})], spacing: {{ after: 480 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.sender_name, bold: true, size: 22, font: 'Calibri' }})], spacing: {{ after: 40 }} }}),
    ]
  }}]
}});
Packer.toBuffer(doc).then(buf => fs.writeFileSync(process.argv[2], buf));
console.log('OK');
"""


def _job_application_js(d: dict) -> str:
    data_json = json.dumps(d, ensure_ascii=False)
    return _js_header() + f"""
const d = {data_json};
const doc = new Document({{
  styles: {{ default: {{ document: {{ run: {{ font: 'Times New Roman', size: 24 }} }} }} }},
  sections: [{{
    properties: {{ page: {{ size: PAGE, margin: MARGIN }} }},
    children: [
      new Paragraph({{ children: [new TextRun({{ text: 'APPLICATION FOR EMPLOYMENT', bold: true, size: 32, font: 'Times New Roman', color: '1F3864' }})], alignment: AlignmentType.CENTER, spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.position + ' — ' + d.department, size: 24, font: 'Times New Roman', italics: true, color: '444444' }})], alignment: AlignmentType.CENTER, spacing: {{ after: 400 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.date, size: 22, font: 'Times New Roman' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'To', bold: true, size: 22, font: 'Times New Roman' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'The Hiring Manager', size: 22, font: 'Times New Roman' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.company, size: 22, font: 'Times New Roman' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'Subject: Application for the Post of ' + d.position, bold: true, size: 22, font: 'Times New Roman', color: '1F3864' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'Respected Sir/Madam,', size: 22, font: 'Times New Roman' }})], spacing: {{ after: 160 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.intro, size: 22, font: 'Times New Roman' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.qualifications, size: 22, font: 'Times New Roman' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.motivation, size: 22, font: 'Times New Roman' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.closing, size: 22, font: 'Times New Roman' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 320 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'Yours faithfully,', size: 22, font: 'Times New Roman' }})], spacing: {{ after: 480 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.applicant_name, bold: true, size: 22, font: 'Times New Roman' }})], spacing: {{ after: 40 }} }}),
    ]
  }}]
}});
Packer.toBuffer(doc).then(buf => fs.writeFileSync(process.argv[2], buf));
console.log('OK');
"""


def _resignation_js(d: dict) -> str:
    data_json = json.dumps(d, ensure_ascii=False)
    return _js_header() + f"""
const d = {data_json};
const doc = new Document({{
  styles: {{ default: {{ document: {{ run: {{ font: 'Calibri', size: 24 }} }} }} }},
  sections: [{{
    properties: {{ page: {{ size: PAGE, margin: MARGIN }} }},
    children: [
      new Paragraph({{ children: [new TextRun({{ text: d.employee_name, bold: true, size: 28, font: 'Calibri' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.position, size: 22, font: 'Calibri', italics: true, color: '555555' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.company, size: 22, font: 'Calibri', color: '555555' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.date, size: 22, font: 'Calibri' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.manager_name, bold: true, size: 22, font: 'Calibri' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.company, size: 22, font: 'Calibri' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'Subject: Formal Resignation — ' + d.position, bold: true, size: 22, font: 'Calibri', color: '1F3864' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'Dear ' + d.manager_name + ',', size: 22, font: 'Calibri' }})], spacing: {{ after: 160 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'I am writing to formally notify you of my resignation from the position of ' + d.position + ' at ' + d.company + ', effective ' + d.last_day + '.', size: 22, font: 'Calibri' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
      ...(d.reason ? [new Paragraph({{ children: [new TextRun({{ text: d.reason, size: 22, font: 'Calibri' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }})] : []),
      new Paragraph({{ children: [new TextRun({{ text: d.gratitude, size: 22, font: 'Calibri' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.transition, size: 22, font: 'Calibri' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 320 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'Sincerely,', size: 22, font: 'Calibri' }})], spacing: {{ after: 480 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.employee_name, bold: true, size: 22, font: 'Calibri' }})], spacing: {{ after: 40 }} }}),
    ]
  }}]
}});
Packer.toBuffer(doc).then(buf => fs.writeFileSync(process.argv[2], buf));
console.log('OK');
"""


def _noc_js(d: dict) -> str:
    data_json = json.dumps(d, ensure_ascii=False)
    return _js_header() + f"""
const d = {data_json};
const doc = new Document({{
  styles: {{ default: {{ document: {{ run: {{ font: 'Times New Roman', size: 24 }} }} }} }},
  sections: [{{
    properties: {{ page: {{ size: PAGE, margin: MARGIN }} }},
    children: [
      new Paragraph({{ children: [new TextRun({{ text: d.company.toUpperCase(), bold: true, size: 30, font: 'Times New Roman' }})], alignment: AlignmentType.CENTER, spacing: {{ after: 40 }} }}),
      hr('333333'),
      spacer(200),
      new Paragraph({{ children: [new TextRun({{ text: 'NO OBJECTION CERTIFICATE', bold: true, size: 36, font: 'Times New Roman', color: '1F3864' }})], alignment: AlignmentType.CENTER, spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'This is to Certify That', size: 24, font: 'Times New Roman', italics: true }})], alignment: AlignmentType.CENTER, spacing: {{ after: 320 }} }}),
      boldLabel('Name', d.beneficiary_name),
      boldLabel('Date Issued', d.date),
      boldLabel('Purpose', d.purpose),
      spacer(160),
      new Paragraph({{ children: [new TextRun({{ text: d.details, size: 22, font: 'Times New Roman' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.validity, size: 22, font: 'Times New Roman', italics: true, color: '555555' }})], spacing: {{ after: 400 }} }}),
      spacer(400),
      new Paragraph({{ children: [new TextRun({{ text: '________________________________', size: 22, font: 'Times New Roman' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.issuer_name, bold: true, size: 22, font: 'Times New Roman' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.issuer_title, size: 22, font: 'Times New Roman', italics: true }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.company, size: 22, font: 'Times New Roman' }})], spacing: {{ after: 40 }} }}),
    ]
  }}]
}});
Packer.toBuffer(doc).then(buf => fs.writeFileSync(process.argv[2], buf));
console.log('OK');
"""


def _memo_js(d: dict) -> str:
    data_json = json.dumps(d, ensure_ascii=False)
    return _js_header() + f"""
const d = {data_json};
const doc = new Document({{
  numbering: {{ config: [{{ reference: 'numbers', levels: [{{ level: 0, format: LevelFormat.DECIMAL, text: '%1.', alignment: AlignmentType.LEFT, style: {{ paragraph: {{ indent: {{ left: 720, hanging: 360 }} }} }} }}] }}] }},
  styles: {{ default: {{ document: {{ run: {{ font: 'Calibri', size: 22 }} }} }} }},
  sections: [{{
    properties: {{ page: {{ size: PAGE, margin: MARGIN }} }},
    children: [
      new Paragraph({{ children: [new TextRun({{ text: 'MEMORANDUM', bold: true, size: 36, font: 'Calibri', color: '1F3864' }})], alignment: AlignmentType.CENTER, spacing: {{ after: 40 }} }}),
      hr('1F3864'),
      spacer(160),
      boldLabel('TO', d.to),
      boldLabel('FROM', d.from),
      boldLabel('DATE', d.date),
      boldLabel('SUBJECT', d.subject),
      hr('CCCCCC'),
      spacer(160),
      ...(d.body || []).map((point, i) => new Paragraph({{ numbering: {{ reference: 'numbers', level: 0 }}, children: [new TextRun({{ text: point, size: 22, font: 'Calibri' }})], spacing: {{ after: 120 }} }})),
      spacer(160),
      new Paragraph({{ children: [new TextRun({{ text: 'Action Required: ', bold: true, size: 22, font: 'Calibri' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.action_required, size: 22, font: 'Calibri' }})], spacing: {{ after: 40 }} }}),
    ]
  }}]
}});
Packer.toBuffer(doc).then(buf => fs.writeFileSync(process.argv[2], buf));
console.log('OK');
"""


def _meeting_minutes_js(d: dict) -> str:
    data_json = json.dumps(d, ensure_ascii=False)
    return _js_header() + f"""
const d = {data_json};
const discussionItems = (d.discussion || []).flatMap(item => [
  new Paragraph({{ children: [new TextRun({{ text: item.topic, bold: true, size: 22, font: 'Calibri' }})], spacing: {{ before: 120, after: 40 }} }}),
  new Paragraph({{ children: [new TextRun({{ text: item.notes, size: 22, font: 'Calibri' }})], spacing: {{ after: 60 }} }}),
  new Paragraph({{ children: [new TextRun({{ text: 'Action: ', bold: true, size: 22, font: 'Calibri', color: 'C00000' }}), new TextRun({{ text: item.action, size: 22, font: 'Calibri' }})], spacing: {{ after: 120 }} }}),
]);
const doc = new Document({{
  numbering: {{ config: [{{ reference: 'bullets', levels: [{{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: {{ paragraph: {{ indent: {{ left: 360, hanging: 180 }} }} }} }}] }}] }},
  styles: {{ default: {{ document: {{ run: {{ font: 'Calibri', size: 22 }} }} }} }},
  sections: [{{
    properties: {{ page: {{ size: PAGE, margin: MARGIN }} }},
    children: [
      new Paragraph({{ children: [new TextRun({{ text: 'MINUTES OF MEETING', bold: true, size: 36, font: 'Calibri', color: '1F3864' }})], alignment: AlignmentType.CENTER, spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.meeting_title, size: 26, font: 'Calibri', italics: true, color: '444444' }})], alignment: AlignmentType.CENTER, spacing: {{ after: 40 }} }}),
      hr('1F3864'),
      spacer(120),
      boldLabel('Date', d.date), boldLabel('Time', d.time), boldLabel('Venue', d.location),
      boldLabel('Attendees', (d.attendees || []).join(', ')),
      spacer(160),
      heading2('Agenda'),
      ...(d.agenda || []).map(a => new Paragraph({{ numbering: {{ reference: 'bullets', level: 0 }}, children: [new TextRun({{ text: a, size: 22, font: 'Calibri' }})] }})),
      spacer(160),
      heading2('Discussion'),
      ...discussionItems,
      spacer(160),
      heading2('Next Meeting'),
      new Paragraph({{ children: [new TextRun({{ text: d.next_meeting, size: 22, font: 'Calibri' }})], spacing: {{ after: 40 }} }}),
    ]
  }}]
}});
Packer.toBuffer(doc).then(buf => fs.writeFileSync(process.argv[2], buf));
console.log('OK');
"""


def _report_js(d: dict) -> str:
    data_json = json.dumps(d, ensure_ascii=False)
    return _js_header() + f"""
const d = {data_json};
const sections_content = (d.sections || []).flatMap(s => [
  heading2(s.heading),
  new Paragraph({{ children: [new TextRun({{ text: s.content, size: 22, font: 'Calibri' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
  spacer(80),
]);
const doc = new Document({{
  numbering: {{ config: [{{ reference: 'bullets', levels: [{{ level: 0, format: LevelFormat.BULLET, text: '•', alignment: AlignmentType.LEFT, style: {{ paragraph: {{ indent: {{ left: 360, hanging: 180 }} }} }} }}] }}] }},
  styles: {{ default: {{ document: {{ run: {{ font: 'Calibri', size: 22 }} }} }} }},
  sections: [{{
    properties: {{ page: {{ size: PAGE, margin: MARGIN }} }},
    children: [
      new Paragraph({{ children: [new TextRun({{ text: d.title, bold: true, size: 40, font: 'Calibri Light', color: '1F3864' }})], alignment: AlignmentType.CENTER, spacing: {{ after: 80 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'Prepared by: ' + d.author + '  |  ' + d.department, size: 20, font: 'Calibri', color: '666666' }})], alignment: AlignmentType.CENTER, spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.date, size: 20, font: 'Calibri', color: '666666' }})], alignment: AlignmentType.CENTER, spacing: {{ after: 400 }} }}),
      hr('1F3864'),
      spacer(120),
      heading2('Executive Summary'),
      new Paragraph({{ children: [new TextRun({{ text: d.executive_summary, size: 22, font: 'Calibri' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
      spacer(80),
      ...sections_content,
      heading2('Conclusion'),
      new Paragraph({{ children: [new TextRun({{ text: d.conclusion, size: 22, font: 'Calibri' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }}),
      spacer(80),
      heading2('Recommendations'),
      ...(d.recommendations || []).map(r => new Paragraph({{ numbering: {{ reference: 'bullets', level: 0 }}, children: [new TextRun({{ text: r, size: 22, font: 'Calibri' }})] }})),
    ]
  }}]
}});
Packer.toBuffer(doc).then(buf => fs.writeFileSync(process.argv[2], buf));
console.log('OK');
"""


def _internship_js(d: dict) -> str:
    return _job_application_js(d)  # Same structure


def _business_letter_js(d: dict) -> str:
    data_json = json.dumps(d, ensure_ascii=False)
    return _js_header() + f"""
const d = {data_json};
const doc = new Document({{
  styles: {{ default: {{ document: {{ run: {{ font: 'Times New Roman', size: 24 }} }} }} }},
  sections: [{{
    properties: {{ page: {{ size: PAGE, margin: MARGIN }} }},
    children: [
      new Paragraph({{ children: [new TextRun({{ text: d.company, bold: true, size: 28, font: 'Times New Roman' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.address, size: 22, font: 'Times New Roman', color: '555555' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.date, size: 22, font: 'Times New Roman' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.recipient_name, bold: true, size: 22, font: 'Times New Roman' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.recipient_title, size: 22, font: 'Times New Roman' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.recipient_company, size: 22, font: 'Times New Roman' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.subject, bold: true, size: 22, font: 'Times New Roman', color: '1F3864' }})], spacing: {{ after: 200 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: 'Dear ' + d.recipient_name + ',', size: 22, font: 'Times New Roman' }})], spacing: {{ after: 160 }} }}),
      ...(d.body || []).map(p => new Paragraph({{ children: [new TextRun({{ text: p, size: 22, font: 'Times New Roman' }})], alignment: AlignmentType.JUSTIFIED, spacing: {{ after: 160 }} }})),
      new Paragraph({{ children: [new TextRun({{ text: d.closing + ',', size: 22, font: 'Times New Roman' }})], spacing: {{ after: 480 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.sender_name, bold: true, size: 22, font: 'Times New Roman' }})], spacing: {{ after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: d.sender_title, size: 22, font: 'Times New Roman', italics: true }})], spacing: {{ after: 40 }} }}),
    ]
  }}]
}});
Packer.toBuffer(doc).then(buf => fs.writeFileSync(process.argv[2], buf));
console.log('OK');
"""


def _generic_word_js(d: dict) -> str:
    data_json = json.dumps(d, ensure_ascii=False)
    return _js_header() + f"""
const d = {data_json};
const doc = new Document({{
  styles: {{ default: {{ document: {{ run: {{ font: 'Calibri', size: 22 }} }} }} }},
  sections: [{{
    properties: {{ page: {{ size: PAGE, margin: MARGIN }} }},
    children: Object.entries(d).flatMap(([k, v]) => [
      new Paragraph({{ children: [new TextRun({{ text: k.replace(/_/g,' ').toUpperCase(), bold: true, size: 22, font: 'Calibri' }})], spacing: {{ before: 160, after: 40 }} }}),
      new Paragraph({{ children: [new TextRun({{ text: JSON.stringify(v), size: 22, font: 'Calibri' }})], spacing: {{ after: 80 }} }}),
    ])
  }}]
}});
Packer.toBuffer(doc).then(buf => fs.writeFileSync(process.argv[2], buf));
console.log('OK');
"""


# ─────────────────────────────────────────────────────────────────────────────
#  EXCEL DOCUMENT BUILDERS  (via openpyxl)
# ─────────────────────────────────────────────────────────────────────────────

def build_excel(doc_type: str, data: dict, out_path: str) -> bool:
    """Build and save an Excel file. Returns True on success."""
    builders = {
        "invoice": _build_invoice,
        "budget": _build_budget,
        "expense": _build_expense,
        "project_plan": _build_project_plan,
        "attendance": _build_attendance,
        "salary": _build_salary,
        "inventory": _build_inventory,
    }
    builder = builders.get(doc_type, _build_generic_excel)
    return builder(data, out_path)


def _build_invoice(d: dict, path: str) -> bool:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, numbers
    from openpyxl.utils import get_column_letter

    wb = Workbook()
    ws = wb.active
    ws.title = "Invoice"

    BLUE = "1F3864"
    LIGHT_BLUE = "D6E4F0"
    GRAY = "F5F5F5"

    def style(cell, bold=False, size=11, color="000000", bg=None, align="left", num_fmt=None):
        cell.font = Font(name="Calibri", bold=bold, size=size, color=color)
        cell.alignment = Alignment(horizontal=align, vertical="center")
        if bg:
            cell.fill = PatternFill("solid", fgColor=bg)
        if num_fmt:
            cell.number_format = num_fmt

    def border_cell(cell):
        thin = Side(style="thin", color="CCCCCC")
        cell.border = Border(top=thin, left=thin, right=thin, bottom=thin)

    ws.column_dimensions["A"].width = 8
    ws.column_dimensions["B"].width = 40
    ws.column_dimensions["C"].width = 12
    ws.column_dimensions["D"].width = 16
    ws.column_dimensions["E"].width = 16

    # Header
    ws.row_dimensions[1].height = 50
    ws["A1"] = "INVOICE"
    ws["A1"].font = Font(name="Calibri Light", bold=True, size=28, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor=BLUE)
    ws["A1"].alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells("A1:E1")

    ws.row_dimensions[2].height = 20
    ws["A2"] = d.get("from_name", "Your Company")
    ws["A2"].font = Font(name="Calibri", size=12, bold=True)
    ws.merge_cells("A2:C2")
    ws["D2"] = f"Invoice #: {d.get('invoice_number', 'INV-001')}"
    style(ws["D2"], bold=True, align="right")
    ws.merge_cells("D2:E2")

    ws["A3"] = d.get("from_email", "")
    ws["A3"].font = Font(name="Calibri", size=10, color="555555")
    ws.merge_cells("A3:C3")
    ws["D3"] = f"Date: {d.get('date', '')}"
    ws["D3"].font = Font(name="Calibri", size=10, align="right")
    ws.merge_cells("D3:E3")

    ws["D4"] = f"Due: {d.get('due_date', '')}"
    ws["D4"].font = Font(name="Calibri", size=10)
    ws.merge_cells("D4:E4")

    ws.row_dimensions[5].height = 15
    ws["A6"] = "BILL TO:"
    ws["A6"].font = Font(name="Calibri", bold=True, size=10, color="FFFFFF")
    ws["A6"].fill = PatternFill("solid", fgColor=BLUE)
    ws.merge_cells("A6:E6")

    ws["A7"] = d.get("to_name", "")
    ws["A7"].font = Font(name="Calibri", bold=True, size=11)
    ws["A8"] = d.get("to_address", "")
    ws["A8"].font = Font(name="Calibri", size=10, color="555555")
    ws.merge_cells("A7:E7")
    ws.merge_cells("A8:E8")

    ws.row_dimensions[9].height = 15

    # Items header
    ws.row_dimensions[10].height = 24
    for col, (lbl, align) in enumerate([("#","center"),("Description","left"),("Qty","center"),("Unit Price","right"),("Amount","right")], 1):
        c = ws.cell(row=10, column=col, value=lbl)
        c.font = Font(name="Calibri", bold=True, size=11, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=BLUE)
        c.alignment = Alignment(horizontal=align, vertical="center")

    # Items
    items = d.get("items", [])
    row = 11
    for i, item in enumerate(items, 1):
        qty = float(item.get("qty", 1))
        price = float(item.get("unit_price", 0))
        bg = LIGHT_BLUE if i % 2 == 0 else "FFFFFF"
        ws.row_dimensions[row].height = 20
        ws.cell(row=row, column=1, value=i).alignment = Alignment(horizontal="center")
        ws.cell(row=row, column=2, value=item.get("description", "")).font = Font(name="Calibri", size=11)
        ws.cell(row=row, column=3, value=qty).alignment = Alignment(horizontal="center")
        ws.cell(row=row, column=4, value=price).number_format = '"$"#,##0.00'
        amt_cell = ws.cell(row=row, column=5)
        amt_cell.value = f"=C{row}*D{row}"
        amt_cell.number_format = '"$"#,##0.00'
        amt_cell.alignment = Alignment(horizontal="right")
        for col in range(1, 6):
            c = ws.cell(row=row, column=col)
            c.fill = PatternFill("solid", fgColor=bg)
            border_cell(c)
        row += 1

    # Totals
    subtotal_row = row + 1
    tax_row = subtotal_row + 1
    total_row = tax_row + 1
    tax_rate = float(d.get("tax_rate", 0.1))

    ws.cell(row=subtotal_row, column=4, value="Subtotal:").font = Font(name="Calibri", bold=True, size=11)
    ws.cell(row=subtotal_row, column=4).alignment = Alignment(horizontal="right")
    sub_cell = ws.cell(row=subtotal_row, column=5)
    sub_cell.value = f"=SUM(E11:E{row-1})"
    sub_cell.number_format = '"$"#,##0.00'
    sub_cell.alignment = Alignment(horizontal="right")

    ws.cell(row=tax_row, column=4, value=f"Tax ({int(tax_rate*100)}%):").font = Font(name="Calibri", size=11)
    ws.cell(row=tax_row, column=4).alignment = Alignment(horizontal="right")
    tax_cell = ws.cell(row=tax_row, column=5)
    tax_cell.value = f"=E{subtotal_row}*{tax_rate}"
    tax_cell.number_format = '"$"#,##0.00'
    tax_cell.alignment = Alignment(horizontal="right")

    ws.row_dimensions[total_row].height = 26
    ws.cell(row=total_row, column=4, value="TOTAL DUE:").font = Font(name="Calibri", bold=True, size=13, color="FFFFFF")
    ws.cell(row=total_row, column=4).fill = PatternFill("solid", fgColor=BLUE)
    ws.cell(row=total_row, column=4).alignment = Alignment(horizontal="right", vertical="center")
    tot_cell = ws.cell(row=total_row, column=5)
    tot_cell.value = f"=E{subtotal_row}+E{tax_row}"
    tot_cell.number_format = '"$"#,##0.00'
    tot_cell.font = Font(name="Calibri", bold=True, size=13, color="FFFFFF")
    tot_cell.fill = PatternFill("solid", fgColor=BLUE)
    tot_cell.alignment = Alignment(horizontal="right", vertical="center")

    # Notes
    notes_row = total_row + 2
    ws.cell(row=notes_row, column=1, value="Notes:").font = Font(name="Calibri", bold=True, size=10)
    ws.cell(row=notes_row+1, column=1, value=d.get("notes", "Payment terms: Net 30")).font = Font(name="Calibri", size=10, color="666666")
    ws.merge_cells(f"A{notes_row}:E{notes_row}")
    ws.merge_cells(f"A{notes_row+1}:E{notes_row+1}")

    wb.save(path)
    return True


def _build_budget(d: dict, path: str) -> bool:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    wb = Workbook()
    ws = wb.active
    ws.title = "Budget"

    DARK = "1F3864"
    INCOME_COLOR = "1E8449"
    EXPENSE_COLOR = "C0392B"

    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 16
    ws.column_dimensions["D"].width = 16
    ws.column_dimensions["E"].width = 16

    ws.row_dimensions[1].height = 40
    ws["A1"] = d.get("title", "Monthly Budget")
    ws["A1"].font = Font(name="Calibri Light", bold=True, size=22, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor=DARK)
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.merge_cells("A1:E1")

    ws["A2"] = d.get("person", "")
    ws["A2"].font = Font(name="Calibri", size=11, color="555555")
    ws["A2"].alignment = Alignment(horizontal="center")
    ws.merge_cells("A2:E2")

    # INCOME section
    row = 4
    ws.cell(row=row, column=1, value="INCOME").font = Font(name="Calibri", bold=True, size=12, color="FFFFFF")
    ws.cell(row=row, column=1).fill = PatternFill("solid", fgColor=INCOME_COLOR)
    ws.merge_cells(f"A{row}:E{row}")

    income_start = row + 1
    for item in d.get("income", []):
        row += 1
        ws.cell(row=row, column=1, value=item.get("source", "")).font = Font(name="Calibri", size=11)
        ws.cell(row=row, column=2, value=float(item.get("amount", 0))).number_format = '"$"#,##0.00'
        ws.cell(row=row, column=2).alignment = Alignment(horizontal="right")

    income_end = row
    row += 1
    ws.cell(row=row, column=1, value="Total Income").font = Font(name="Calibri", bold=True, size=11)
    inc_total = ws.cell(row=row, column=2)
    inc_total.value = f"=SUM(B{income_start}:B{income_end})"
    inc_total.number_format = '"$"#,##0.00'
    inc_total.font = Font(name="Calibri", bold=True, size=11, color=INCOME_COLOR)
    inc_total.alignment = Alignment(horizontal="right")
    income_total_row = row

    # EXPENSES section
    row += 2
    ws.cell(row=row, column=1, value="EXPENSES").font = Font(name="Calibri", bold=True, size=12, color="FFFFFF")
    ws.cell(row=row, column=1).fill = PatternFill("solid", fgColor=EXPENSE_COLOR)
    for c in range(1, 6):
        ws.cell(row=row, column=c).fill = PatternFill("solid", fgColor=EXPENSE_COLOR)
    # Headers
    row += 1
    for col, hdr in [(1,"Category"),(2,"Planned"),(3,"Actual"),(4,"Variance"),(5,"% Variance")]:
        c = ws.cell(row=row, column=col, value=hdr)
        c.font = Font(name="Calibri", bold=True, size=10, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="C0392B")
        c.alignment = Alignment(horizontal="center")
    exp_header_row = row

    exp_start = row + 1
    for item in d.get("expenses", []):
        row += 1
        bg = "FDF2F2" if row % 2 == 0 else "FFFFFF"
        ws.cell(row=row, column=1, value=item.get("category","")).font = Font(name="Calibri", size=11)
        planned = ws.cell(row=row, column=2)
        planned.value = float(item.get("planned", 0))
        planned.number_format = '"$"#,##0.00'
        planned.alignment = Alignment(horizontal="right")
        actual = ws.cell(row=row, column=3)
        actual.value = float(item.get("actual", 0))
        actual.number_format = '"$"#,##0.00'
        actual.alignment = Alignment(horizontal="right")
        var = ws.cell(row=row, column=4)
        var.value = f"=B{row}-C{row}"
        var.number_format = '"$"#,##0.00;[Red]"$"(#,##0.00)'
        var.alignment = Alignment(horizontal="right")
        pct = ws.cell(row=row, column=5)
        pct.value = f"=IF(B{row}=0,0,(B{row}-C{row})/B{row})"
        pct.number_format = "0.0%"
        pct.alignment = Alignment(horizontal="right")

    exp_end = row
    row += 1
    ws.cell(row=row, column=1, value="Total Expenses").font = Font(name="Calibri", bold=True, size=11)
    for col in range(2, 4):
        c = ws.cell(row=row, column=col)
        c.value = f"=SUM({chr(64+col)}{exp_start}:{chr(64+col)}{exp_end})"
        c.number_format = '"$"#,##0.00'
        c.font = Font(name="Calibri", bold=True, size=11, color=EXPENSE_COLOR)
        c.alignment = Alignment(horizontal="right")
    exp_total_row = row

    # Summary
    row += 2
    ws.cell(row=row, column=1, value="NET SAVINGS").font = Font(name="Calibri", bold=True, size=13, color="FFFFFF")
    ws.cell(row=row, column=1).fill = PatternFill("solid", fgColor=DARK)
    ws.merge_cells(f"A{row}:D{row}")
    net = ws.cell(row=row, column=5)
    net.value = f"=B{income_total_row}-B{exp_total_row}"
    net.number_format = '"$"#,##0.00'
    net.font = Font(name="Calibri", bold=True, size=13, color="FFFFFF")
    net.fill = PatternFill("solid", fgColor=DARK)
    net.alignment = Alignment(horizontal="right")

    wb.save(path)
    return True


def _build_expense(d: dict, path: str) -> bool:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Expense Report"

    DARK = "1F3864"
    ws.column_dimensions["A"].width = 14
    ws.column_dimensions["B"].width = 20
    ws.column_dimensions["C"].width = 36
    ws.column_dimensions["D"].width = 14

    ws.row_dimensions[1].height = 40
    ws["A1"] = d.get("title", "Expense Report")
    ws["A1"].font = Font(name="Calibri Light", bold=True, size=22, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor=DARK)
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.merge_cells("A1:D1")

    for row, (lbl, val) in enumerate([(d.get("employee",""),"Employee"),(d.get("department",""),"Department"),(d.get("period",""),"Period"),(d.get("manager",""),"Approved By")], 2):
        ws.cell(row=row, column=1, value=val+":").font = Font(name="Calibri", bold=True, size=10)
        ws.cell(row=row, column=2, value=row).font = Font(name="Calibri", size=10)

    row = 2
    for lbl, val in [("Employee:", d.get("employee","")),("Department:", d.get("department","")),("Period:", d.get("period","")),("Approved By:", d.get("manager",""))]:
        ws.cell(row=row, column=1, value=lbl).font = Font(name="Calibri", bold=True, size=10)
        ws.cell(row=row, column=2, value=val).font = Font(name="Calibri", size=10)
        row += 1

    row += 1
    for col, hdr in [(1,"Date"),(2,"Category"),(3,"Description"),(4,"Amount")]:
        c = ws.cell(row=row, column=col, value=hdr)
        c.font = Font(name="Calibri", bold=True, size=11, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=DARK)
        c.alignment = Alignment(horizontal="center")

    exp_start = row + 1
    for item in d.get("expenses", []):
        row += 1
        ws.cell(row=row, column=1, value=item.get("date","")).font = Font(name="Calibri", size=10)
        ws.cell(row=row, column=2, value=item.get("category","")).font = Font(name="Calibri", size=10)
        ws.cell(row=row, column=3, value=item.get("description","")).font = Font(name="Calibri", size=10)
        amt = ws.cell(row=row, column=4)
        amt.value = float(item.get("amount", 0))
        amt.number_format = '"$"#,##0.00'
        amt.alignment = Alignment(horizontal="right")

    row += 1
    ws.cell(row=row, column=3, value="TOTAL:").font = Font(name="Calibri", bold=True, size=12)
    ws.cell(row=row, column=3).alignment = Alignment(horizontal="right")
    tot = ws.cell(row=row, column=4)
    tot.value = f"=SUM(D{exp_start}:D{row-1})"
    tot.number_format = '"$"#,##0.00'
    tot.font = Font(name="Calibri", bold=True, size=12)
    tot.fill = PatternFill("solid", fgColor="D6E4F0")
    tot.alignment = Alignment(horizontal="right")

    wb.save(path)
    return True


def _build_project_plan(d: dict, path: str) -> bool:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Project Plan"

    DARK = "1F3864"
    ws.column_dimensions["A"].width = 30
    ws.column_dimensions["B"].width = 20
    ws.column_dimensions["C"].width = 14
    ws.column_dimensions["D"].width = 14
    ws.column_dimensions["E"].width = 16

    ws.row_dimensions[1].height = 36
    ws["A1"] = d.get("project", "Project Plan")
    ws["A1"].font = Font(name="Calibri Light", bold=True, size=20, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor=DARK)
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.merge_cells("A1:E1")

    for r, (lbl, val) in enumerate([("Project Manager:", d.get("manager","")),("Start:", d.get("start_date","")),("End:", d.get("end_date",""))], 2):
        ws.cell(row=r, column=1, value=lbl).font = Font(name="Calibri", bold=True, size=10)
        ws.cell(row=r, column=2, value=val).font = Font(name="Calibri", size=10)

    row = 6
    for col, hdr in [(1,"Task"),(2,"Owner"),(3,"Start"),(4,"End"),(5,"Status")]:
        c = ws.cell(row=row, column=col, value=hdr)
        c.font = Font(name="Calibri", bold=True, size=11, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=DARK)
        c.alignment = Alignment(horizontal="center")

    STATUS_COLORS = {"Not Started": "F0F0F0", "In Progress": "FFF2CC", "Complete": "D5F5E3", "Blocked": "FADBD8"}
    for item in d.get("tasks", []):
        row += 1
        status = item.get("status", "Not Started")
        bg = STATUS_COLORS.get(status, "FFFFFF")
        ws.cell(row=row, column=1, value=item.get("task","")).font = Font(name="Calibri", size=11)
        ws.cell(row=row, column=2, value=item.get("owner","")).font = Font(name="Calibri", size=10)
        ws.cell(row=row, column=3, value=item.get("start","")).font = Font(name="Calibri", size=10)
        ws.cell(row=row, column=4, value=item.get("end","")).font = Font(name="Calibri", size=10)
        stat_cell = ws.cell(row=row, column=5, value=status)
        stat_cell.font = Font(name="Calibri", size=10, bold=True)
        stat_cell.fill = PatternFill("solid", fgColor=bg)
        stat_cell.alignment = Alignment(horizontal="center")

    wb.save(path)
    return True


def _build_attendance(d: dict, path: str) -> bool:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Attendance"

    DARK = "1F3864"
    ws.row_dimensions[1].height = 36
    ws["A1"] = d.get("title", "Attendance Sheet")
    ws["A1"].font = Font(name="Calibri Light", bold=True, size=20, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor=DARK)
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")

    ws["A2"] = d.get("department","")
    ws["B2"] = d.get("month","")
    working_days = int(d.get("working_days", 22))

    ws.column_dimensions["A"].width = 8
    ws.column_dimensions["B"].width = 28
    ws.column_dimensions["C"].width = 20

    day_cols = min(working_days, 31)
    for i in range(1, day_cols + 1):
        col_letter = chr(67 + i - 1) if i <= 26 else chr(64 + i - 26)
        ws.column_dimensions[col_letter] = 5

    # Headers
    row = 4
    headers = ["ID", "Name", "Designation"] + [str(i) for i in range(1, working_days + 1)] + ["Present", "Absent"]
    for col, hdr in enumerate(headers, 1):
        c = ws.cell(row=row, column=col, value=hdr)
        c.font = Font(name="Calibri", bold=True, size=10, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=DARK)
        c.alignment = Alignment(horizontal="center")

    for emp in d.get("employees", []):
        row += 1
        ws.cell(row=row, column=1, value=emp.get("id","")).font = Font(name="Calibri", size=10)
        ws.cell(row=row, column=2, value=emp.get("name","")).font = Font(name="Calibri", size=10)
        ws.cell(row=row, column=3, value=emp.get("designation","")).font = Font(name="Calibri", size=10)
        # Day columns left blank for manual entry
        pres_col = 4 + working_days
        abs_col = pres_col + 1
        pres_cell = ws.cell(row=row, column=pres_col)
        pres_cell.value = f"=COUNTIF(D{row}:{chr(67+working_days)}{row},\"P\")"
        pres_cell.font = Font(name="Calibri", bold=True, size=10, color="1E8449")
        abs_cell = ws.cell(row=row, column=abs_col)
        abs_cell.value = f"=COUNTIF(D{row}:{chr(67+working_days)}{row},\"A\")"
        abs_cell.font = Font(name="Calibri", bold=True, size=10, color="C0392B")

    wb.save(path)
    return True


def _build_salary(d: dict, path: str) -> bool:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Salary Sheet"

    DARK = "1F3864"
    ws.column_dimensions["A"].width = 8
    ws.column_dimensions["B"].width = 24
    ws.column_dimensions["C"].width = 20
    ws.column_dimensions["D"].width = 12
    ws.column_dimensions["E"].width = 12
    ws.column_dimensions["F"].width = 12
    ws.column_dimensions["G"].width = 12
    ws.column_dimensions["H"].width = 14

    ws.row_dimensions[1].height = 36
    ws["A1"] = d.get("title","Salary Sheet")
    ws["A1"].font = Font(name="Calibri Light", bold=True, size=20, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor=DARK)
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.merge_cells("A1:H1")

    ws["A2"] = d.get("company","")
    ws["D2"] = d.get("month","")
    ws.merge_cells("A2:C2")

    row = 4
    for col, hdr in [(1,"ID"),(2,"Name"),(3,"Designation"),(4,"Basic"),(5,"HRA"),(6,"Transport"),(7,"Deductions"),(8,"Net Salary")]:
        c = ws.cell(row=row, column=col, value=hdr)
        c.font = Font(name="Calibri", bold=True, size=11, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=DARK)
        c.alignment = Alignment(horizontal="center")

    for emp in d.get("employees", []):
        row += 1
        bg = "F0F4FF" if row % 2 == 0 else "FFFFFF"
        ws.cell(row=row, column=1, value=emp.get("id","")).font = Font(name="Calibri", size=10)
        ws.cell(row=row, column=2, value=emp.get("name","")).font = Font(name="Calibri", size=10)
        ws.cell(row=row, column=3, value=emp.get("designation","")).font = Font(name="Calibri", size=10)
        for col, key in [(4,"basic"),(5,"hra"),(6,"transport"),(7,"deductions")]:
            c = ws.cell(row=row, column=col, value=float(emp.get(key,0)))
            c.number_format = '"$"#,##0.00'
            c.alignment = Alignment(horizontal="right")
            c.fill = PatternFill("solid", fgColor=bg)
        net = ws.cell(row=row, column=8)
        net.value = f"=D{row}+E{row}+F{row}-G{row}"
        net.number_format = '"$"#,##0.00'
        net.font = Font(name="Calibri", bold=True, size=11)
        net.alignment = Alignment(horizontal="right")
        net.fill = PatternFill("solid", fgColor="D6E4F0")

    wb.save(path)
    return True


def _build_inventory(d: dict, path: str) -> bool:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Inventory"

    DARK = "1F3864"
    cols = {"A":12,"B":28,"C":20,"D":12,"E":14,"F":14,"G":14}
    for col, w in cols.items():
        ws.column_dimensions[col].width = w

    ws.row_dimensions[1].height = 36
    ws["A1"] = d.get("title","Inventory List")
    ws["A1"].font = Font(name="Calibri Light", bold=True, size=20, color="FFFFFF")
    ws["A1"].fill = PatternFill("solid", fgColor=DARK)
    ws["A1"].alignment = Alignment(horizontal="center", vertical="center")
    ws.merge_cells("A1:G1")
    ws["A2"] = d.get("company","")
    ws["E2"] = f"Date: {d.get('date','')}"

    row = 4
    for col, hdr in [(1,"SKU"),(2,"Product Name"),(3,"Category"),(4,"Qty"),(5,"Unit Price"),(6,"Total Value"),(7,"Reorder Level")]:
        c = ws.cell(row=row, column=col, value=hdr)
        c.font = Font(name="Calibri", bold=True, size=11, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor=DARK)
        c.alignment = Alignment(horizontal="center")

    for item in d.get("items",[]):
        row += 1
        ws.cell(row=row, column=1, value=item.get("sku","")).font = Font(name="Calibri", size=10)
        ws.cell(row=row, column=2, value=item.get("name","")).font = Font(name="Calibri", size=10)
        ws.cell(row=row, column=3, value=item.get("category","")).font = Font(name="Calibri", size=10)
        qty = ws.cell(row=row, column=4, value=int(item.get("quantity",0)))
        qty.alignment = Alignment(horizontal="center")
        price = ws.cell(row=row, column=5, value=float(item.get("unit_price",0)))
        price.number_format = '"$"#,##0.00'
        price.alignment = Alignment(horizontal="right")
        total = ws.cell(row=row, column=6)
        total.value = f"=D{row}*E{row}"
        total.number_format = '"$"#,##0.00'
        total.alignment = Alignment(horizontal="right")
        reorder = int(item.get("reorder_level",10))
        reorder_cell = ws.cell(row=row, column=7, value=reorder)
        reorder_cell.alignment = Alignment(horizontal="center")
        if int(item.get("quantity",0)) <= reorder:
            reorder_cell.font = Font(name="Calibri", size=10, bold=True, color="C0392B")
            qty.font = Font(name="Calibri", size=10, bold=True, color="C0392B")

    wb.save(path)
    return True


def _build_generic_excel(d: dict, path: str) -> bool:
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    row = 1
    for k, v in d.items():
        ws.cell(row=row, column=1, value=k).font = Font(name="Calibri", bold=True)
        ws.cell(row=row, column=2, value=str(v))
        row += 1
    wb.save(path)
    return True


# ─────────────────────────────────────────────────────────────────────────────
#  FILE GENERATION ORCHESTRATOR
# ─────────────────────────────────────────────────────────────────────────────

async def create_document(salim_bot, doc_type: str, category: str,
                           user_request: str, save_dir: str) -> tuple[str | None, str]:
    """
    Orchestrate: generate content → build file → return (filepath, filename).
    Returns (None, error_message) on failure.
    """
    await _send_status(salim_bot, f"🤖 Generating {doc_type.replace('_',' ')} content...")

    data = await generate_content_via_ai(salim_bot, doc_type, user_request)
    if not data:
        return None, "❌ AI content generation failed. Check your AI keys in config."

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{doc_type}_{timestamp}"
    save_path = Path(save_dir).expanduser()
    save_path.mkdir(parents=True, exist_ok=True)

    if category == "word":
        out_path = str(save_path / f"{filename}.docx")
        await _send_status(salim_bot, "📝 Building Word document...")
        js_code = build_word_js(doc_type, data)

        with tempfile.NamedTemporaryFile(suffix=".js", mode="w", delete=False) as f:
            f.write(js_code)
            js_file = f.name

        try:
            result = subprocess.run(
                ["node", js_file, out_path],
                capture_output=True, text=True, timeout=30,
                env={**os.environ, "NODE_PATH": "/home/claude/.npm-global/lib/node_modules"}
            )
            if result.returncode != 0:
                logger.error(f"Node error: {result.stderr}")
                return None, f"❌ Document build failed: {result.stderr[:200]}"
        finally:
            os.unlink(js_file)

    else:  # excel
        out_path = str(save_path / f"{filename}.xlsx")
        await _send_status(salim_bot, "📊 Building Excel spreadsheet...")
        try:
            build_excel(doc_type, data, out_path)
        except Exception as e:
            logger.error(f"Excel build error: {e}")
            return None, f"❌ Spreadsheet build failed: {str(e)[:200]}"

    if not Path(out_path).exists():
        return None, "❌ File was not created."

    return out_path, f"{doc_type.replace('_',' ').title()}"


async def _send_status(salim_bot, text: str):
    """Best-effort status message to the current user session."""
    try:
        if hasattr(salim_bot, "_last_update") and salim_bot._last_update:
            await salim_bot._last_update.effective_message.reply_text(text)
    except Exception:
        pass


# ─────────────────────────────────────────────────────────────────────────────
#  TELEGRAM HANDLER
# ─────────────────────────────────────────────────────────────────────────────

class DocumentHandlers:
    """Mixin for the Salim bot class. Adds document creation capability."""

    @require_auth
    async def cmd_doc(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /doc <description>
        Example: /doc write a resume for Ahmed, software engineer
        """
        if not ctx.args:
            await update.effective_message.reply_text(
                "📄 <b>Document Writer</b>\n\n"
                "Usage: <code>/doc &lt;describe what you want&gt;</code>\n\n"
                "<b>Word Documents:</b>\n"
                "  • resume / CV\n"
                "  • cover letter\n"
                "  • job application\n"
                "  • business letter\n"
                "  • resignation letter\n"
                "  • internship application\n"
                "  • NOC certificate\n"
                "  • memo / memorandum\n"
                "  • meeting minutes\n"
                "  • business report\n\n"
                "<b>Excel Spreadsheets:</b>\n"
                "  • invoice\n"
                "  • budget tracker\n"
                "  • expense report\n"
                "  • project plan\n"
                "  • attendance sheet\n"
                "  • salary sheet\n"
                "  • inventory list\n\n"
                "<i>Examples:</i>\n"
                "<code>/doc resume for Sarah Khan, data scientist</code>\n"
                "<code>/doc invoice for client TechCorp, 3 services</code>\n"
                "<code>/doc resignation letter, last day March 15</code>",
                parse_mode="HTML"
            )
            return

        user_request = " ".join(ctx.args)
        category, doc_type = detect_doc_type(user_request)

        if not doc_type:
            await update.effective_message.reply_text(
                "❓ I couldn't identify the document type. Please mention one of:\n"
                "<i>resume, cover letter, invoice, budget, report, memo, NOC, resignation, etc.</i>",
                parse_mode="HTML"
            )
            return

        ext = ".docx" if category == "word" else ".xlsx"
        await update.effective_message.reply_text(
            f"✍️ Creating your <b>{doc_type.replace('_',' ').title()}</b> ({ext})...",
            parse_mode="HTML"
        )

        # Store update for status messages
        self._last_update = update

        save_dir = getattr(self.config, "upload_dir", str(Path.home() / "Desktop"))
        out_path, label = await create_document(self, doc_type, category, user_request, save_dir)

        if not out_path:
            await update.effective_message.reply_text(label)
            return

        # Send file to Telegram
        import io
        with open(out_path, "rb") as f:
            file_bytes = f.read()

        buf = io.BytesIO(file_bytes)
        buf.name = Path(out_path).name

        size_kb = len(file_bytes) / 1024
        await update.effective_message.reply_document(
            document=buf,
            filename=Path(out_path).name,
            caption=(
                f"✅ <b>{label}</b>\n"
                f"📁 Saved to: <code>{out_path}</code>\n"
                f"📦 Size: {size_kb:.1f} KB"
            ),
            parse_mode="HTML"
        )

    async def handle_natural_doc(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE, text: str) -> bool:
        """
        Called from AI handler when natural language triggers document creation.
        Returns True if a document was created (so AI handler skips normal reply).
        """
        category, doc_type = detect_doc_type(text)
        if not doc_type:
            return False

        creation_keywords = ["write", "create", "make", "generate", "draft", "prepare", "build"]
        if not any(kw in text.lower() for kw in creation_keywords):
            return False

        await update.effective_message.reply_text(
            f"✍️ Creating your <b>{doc_type.replace('_',' ').title()}</b>...",
            parse_mode="HTML"
        )

        self._last_update = update
        save_dir = getattr(self.config, "upload_dir", str(Path.home() / "Desktop"))
        out_path, label = await create_document(self, doc_type, category, text, save_dir)

        if not out_path:
            await update.effective_message.reply_text(label)
            return True

        import io
        with open(out_path, "rb") as f:
            file_bytes = f.read()

        buf = io.BytesIO(file_bytes)
        buf.name = Path(out_path).name
        size_kb = len(file_bytes) / 1024

        await update.effective_message.reply_document(
            document=buf,
            filename=Path(out_path).name,
            caption=(
                f"✅ <b>{label}</b>\n"
                f"📁 Saved to: <code>{out_path}</code>\n"
                f"📦 Size: {size_kb:.1f} KB"
            ),
            parse_mode="HTML"
        )
        return True
