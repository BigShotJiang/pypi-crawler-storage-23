"""
Power management handlers — shutdown, restart, sleep, lock, hibernate.
Uses HTML parse_mode.
"""
from __future__ import annotations

import html
import platform

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

from salim.auth import require_auth
from salim.utils import run_shell_async, is_mac, is_linux, is_windows

H = "HTML"
def esc(v) -> str: return html.escape(str(v), quote=False)

OS = platform.system()


class PowerHandlers:

    async def _power_confirm(self, update, action: str, cmd: str):
        keyboard = [[
            InlineKeyboardButton(f"✅ {action} now", callback_data=f"power:{cmd}"),
            InlineKeyboardButton("❌ Cancel",         callback_data="power:cancel"),
        ]]
        await update.effective_message.reply_text(
            f"⚠️ <b>{esc(action)}</b>\n\nThis will {esc(action.lower())} your laptop. Confirm?",
            parse_mode=H, reply_markup=InlineKeyboardMarkup(keyboard)
        )

    async def cb_power(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        query = update.callback_query
        await query.answer()
        cmd = query.data.replace("power:", "")
        if cmd == "cancel":
            await query.edit_message_text("❌ Cancelled.")
            return
        await query.edit_message_text(f"⚡ Executing: <code>{esc(cmd)}</code>...", parse_mode=H)
        out, rc = await run_shell_async(cmd)
        if rc != 0:
            await query.edit_message_text(f"❌ Failed:\n<pre>{esc(out)}</pre>", parse_mode=H)

    @require_auth
    async def cmd_shutdown(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        delay = int(ctx.args[0]) if ctx.args else 0
        if is_mac():    cmd = "osascript -e 'tell app \"System Events\" to shut down'"
        elif is_windows(): cmd = f"shutdown /s /t {delay}"
        else:           cmd = f"sudo shutdown -h +{delay//60 or 1}"
        await self._power_confirm(update, "Shutdown", cmd)

    @require_auth
    async def cmd_restart(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if is_mac():    cmd = "osascript -e 'tell app \"System Events\" to restart'"
        elif is_windows(): cmd = "shutdown /r /t 5"
        else:           cmd = "sudo shutdown -r now"
        await self._power_confirm(update, "Restart", cmd)

    @require_auth
    async def cmd_sleep(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if is_mac():    cmd = "pmset sleepnow"
        elif is_windows(): cmd = "rundll32.exe powrprof.dll,SetSuspendState 0,1,0"
        else:           cmd = "systemctl suspend"
        await self._power_confirm(update, "Sleep", cmd)

    @require_auth
    async def cmd_lock(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if is_mac():
            out, rc = await run_shell_async(
                'osascript -e \'tell application "System Events" to keystroke "q" using {command down, control down}\''
            )
        elif is_windows():
            out, rc = await run_shell_async("rundll32.exe user32.dll,LockWorkStation")
        else:
            out, rc = await run_shell_async(
                "loginctl lock-session 2>/dev/null || xdg-screensaver lock 2>/dev/null || gnome-screensaver-command -l"
            )
        await update.effective_message.reply_text("🔒 Screen locked." if rc == 0 else f"❌ {esc(out)}", parse_mode=H)

    @require_auth
    async def cmd_logout(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if is_mac():    cmd = "osascript -e 'tell application \"System Events\" to log out'"
        elif is_windows(): cmd = "shutdown /l"
        else:           cmd = "pkill -SIGKILL -u $USER"
        await self._power_confirm(update, "Log Out", cmd)

    @require_auth
    async def cmd_hibernate(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if is_mac():    cmd = "pmset -a hibernatemode 25 && pmset sleepnow"
        elif is_windows(): cmd = "shutdown /h"
        else:           cmd = "systemctl hibernate"
        await self._power_confirm(update, "Hibernate", cmd)

    @require_auth
    async def cmd_screensaver(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if is_mac():    cmd = "open -a ScreenSaverEngine"
        elif is_linux(): cmd = "xdg-screensaver activate"
        else:           cmd = "powershell -command \"(New-Object -ComObject wscript.shell).SendKeys(' ')\""
        out, rc = await run_shell_async(cmd)
        await update.effective_message.reply_text("🌙 Screensaver activated." if rc == 0 else f"❌ {esc(out)}", parse_mode=H)

    @require_auth
    async def cmd_displays(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        if is_mac():
            out, _ = await run_shell_async("system_profiler SPDisplaysDataType | grep -E 'Resolution|Display Type|VRAM'")
        elif is_linux():
            out, _ = await run_shell_async("xrandr --query 2>/dev/null || echo 'xrandr not available'")
        else:
            out, _ = await run_shell_async(
                'powershell -c "Get-WmiObject Win32_VideoController | Select Name,CurrentHorizontalResolution,CurrentVerticalResolution | Format-List"'
            )
        await update.effective_message.reply_text(
            f"🖥️ <b>Displays</b>\n\n<pre>{esc(out[:1500])}</pre>", parse_mode=H
        )
