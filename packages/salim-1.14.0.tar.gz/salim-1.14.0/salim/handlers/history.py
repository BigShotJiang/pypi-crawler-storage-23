"""
Salim Conversation History — persistent per-user multi-turn AI chat memory.

Every AI exchange is stored in ~/.salim/history/<user_id>.jsonl
The last N messages are injected into every AI call so the AI "remembers" context.

Commands:
  /history          — show recent conversation
  /history clear    — wipe history for this user
  /history export   — export history as text file

The history is injected transparently — no change to existing AI usage.
Users can reference past context: "what did I ask earlier?", "summarize our chat"
"""
from __future__ import annotations

import asyncio
import io
import json
import logging
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.history")

HISTORY_DIR = Path.home() / ".salim" / "history"
MAX_HISTORY_MESSAGES = 40     # messages kept per user in memory
MAX_INJECT_MESSAGES = 10      # messages injected into each AI call
MAX_HISTORY_FILE_MB = 5       # rotate history file when > 5MB


def _history_file(user_id: int) -> Path:
    HISTORY_DIR.mkdir(parents=True, exist_ok=True)
    return HISTORY_DIR / f"{user_id}.jsonl"


def load_history(user_id: int, limit: int = MAX_HISTORY_MESSAGES) -> list[dict]:
    """Load the last `limit` messages for a user. Returns list of {role, content, ts}."""
    path = _history_file(user_id)
    if not path.exists():
        return []
    try:
        lines = path.read_text(encoding="utf-8").strip().splitlines()
        entries = []
        for line in lines[-limit:]:
            try:
                entries.append(json.loads(line))
            except Exception:
                pass
        return entries
    except Exception:
        return []


def save_message(user_id: int, role: str, content: str):
    """Append a message to the user's history file."""
    if not content or not content.strip():
        return
    path = _history_file(user_id)
    # Rotate if too large
    try:
        if path.exists() and path.stat().st_size > MAX_HISTORY_FILE_MB * 1024 * 1024:
            # Keep only last half
            lines = path.read_text().strip().splitlines()
            path.write_text("\n".join(lines[len(lines)//2:]) + "\n")
    except Exception:
        pass

    entry = {
        "role": role,
        "content": content[:4000],   # cap per-message length
        "ts": datetime.now().isoformat(),
    }
    try:
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
    except Exception as e:
        logger.warning(f"Failed to save history: {e}")


def get_ai_context(user_id: int) -> list[dict]:
    """
    Return the last N messages formatted as OpenAI-compat messages list.
    Injects into AI calls so the model has conversation context.
    """
    history = load_history(user_id, MAX_INJECT_MESSAGES * 2)
    # Convert to AI message format, alternating user/assistant
    messages = []
    for entry in history[-MAX_INJECT_MESSAGES:]:
        role = entry.get("role", "user")
        content = entry.get("content", "")
        if role in ("user", "assistant") and content:
            messages.append({"role": role, "content": content})
    return messages


def clear_history(user_id: int):
    path = _history_file(user_id)
    if path.exists():
        path.unlink()


class ConversationHistoryHandlers:

    @require_auth
    async def cmd_history(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /history          — show last 10 exchanges
        /history clear    — wipe memory
        /history export   — download as text file
        /history <n>      — show last N messages
        """
        user_id = update.effective_user.id
        args = ctx.args or []
        msg = update.effective_message

        if args and args[0].lower() == "clear":
            clear_history(user_id)
            await msg.reply_text(
                "🗑️ Conversation history cleared.\n"
                "<i>Fresh start — AI no longer remembers past sessions.</i>",
                parse_mode="HTML"
            )
            return

        if args and args[0].lower() == "export":
            history = load_history(user_id, 500)
            if not history:
                await msg.reply_text("📭 No conversation history yet.")
                return

            lines = []
            for entry in history:
                role = entry.get("role", "?").upper()
                ts = entry.get("ts", "")[:16]
                content = entry.get("content", "")
                lines.append(f"[{ts}] {role}:\n{content}\n")

            text = "\n" + ("=" * 60) + "\n"
            text = text.join(lines)
            buf = io.BytesIO(text.encode("utf-8"))
            buf.name = f"salim_history_{user_id}_{int(time.time())}.txt"

            await msg.reply_document(
                document=buf,
                filename=buf.name,
                caption=f"📝 Conversation history — {len(history)} messages"
            )
            return

        # Show history
        limit = 10
        if args:
            try:
                limit = int(args[0])
            except ValueError:
                pass

        history = load_history(user_id, limit * 2)
        if not history:
            await msg.reply_text(
                "📭 No conversation history yet.\n\n"
                "<i>Start chatting with the AI and your conversation will be remembered!</i>",
                parse_mode="HTML"
            )
            return

        # Format nicely
        lines = [f"💬 <b>Last {min(len(history), limit)} messages:</b>\n"]
        import html
        for entry in history[-limit:]:
            role = entry.get("role", "?")
            ts = entry.get("ts", "")
            content = entry.get("content", "")
            ts_short = ts[11:16] if len(ts) >= 16 else ""
            icon = "👤" if role == "user" else "🤖"
            preview = html.escape(content[:200]) + ("..." if len(content) > 200 else "")
            lines.append(f"{icon} <b>{role.title()}</b> <i>{ts_short}</i>\n{preview}\n")

        path = _history_file(user_id)
        total = 0
        try:
            raw = path.read_text().strip().splitlines()
            total = len(raw)
        except Exception:
            pass

        lines.append(f"\n<i>{total} total messages stored · /history clear to reset</i>")
        await msg.reply_text("\n".join(lines), parse_mode="HTML")
