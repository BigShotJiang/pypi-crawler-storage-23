"""ELM Web scraping. """

from .search.google import PlaywrightGoogleLinkSearch
