"""ELM ordinance document content and source validation. """
