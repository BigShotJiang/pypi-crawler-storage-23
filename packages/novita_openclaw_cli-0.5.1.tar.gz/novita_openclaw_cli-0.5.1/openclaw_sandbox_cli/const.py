"""Brand constants for Novita OpenClaw CLI (Novita variant).

This is the ONLY file that differs between brand variants.
All other source files import from here instead of hardcoding brand strings.
"""

# --- Display names ---
BRAND_NAME = "Novita OpenClaw CLI"                       # Panel titles, table headers
PROVIDER_NAME = "Novita"                      # Help text, error messages
CLI_NAME = "novita-openclaw-cli"                     # CLI command name
CONFIG_DIR_NAME = ".novita-openclaw-cli"             # ~/.novita-openclaw-cli/

# --- Environment / config ---
ENV_VAR_API_KEY = "NOVITA_API_KEY"            # Environment variable name
CONFIG_SECTION = "novita"                     # YAML config section name
API_KEY_URL = "https://novita.ai/docs/guides/quickstart#2-manage-api-key"

# --- Sandbox ---
TEMPLATE_ID = "openclaw"
SANDBOX_APP_LABEL = "novita-openclaw"                # metadata.app value
SANDBOX_PROXY = None    # None = no proxy
SDK_PACKAGE = "novita_sandbox"                # SDK package name

# --- OpenClaw config ---
API_KEY_PLACEHOLDER = "NOVITA_API_KEY"        # Placeholder in openclaw.example.json
