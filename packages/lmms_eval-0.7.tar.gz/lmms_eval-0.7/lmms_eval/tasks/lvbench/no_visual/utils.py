# LVBench No Visual Setting Utils


def lvbench_doc_to_visual_empty(doc):
    """Return empty visual for no_visual setting."""
    return []
