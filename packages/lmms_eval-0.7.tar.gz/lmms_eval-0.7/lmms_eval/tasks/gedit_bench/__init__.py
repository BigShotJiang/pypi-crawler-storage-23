"""
GEdit-Bench task package initializer.
Ensures relative imports (e.g. from .viescore import VIEScore) work correctly.
"""
