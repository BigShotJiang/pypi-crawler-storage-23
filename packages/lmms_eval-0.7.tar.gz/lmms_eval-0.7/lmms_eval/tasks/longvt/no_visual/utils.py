# LongVT No Visual Setting Utils


def longvt_doc_to_visual_empty(doc):
    """Return empty visual for no_visual setting."""
    return []
