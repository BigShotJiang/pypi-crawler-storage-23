# AuxSolidMath task for lmms-eval
