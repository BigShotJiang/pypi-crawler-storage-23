"""
BabyVision - Visual Reasoning Beyond Language
MLLM evaluation task using LLM-as-Judge API
"""
