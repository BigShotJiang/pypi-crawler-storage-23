"""
BabyVision Gen task package initializer.
Image generation evaluation task using LLM-based evaluation.
"""
