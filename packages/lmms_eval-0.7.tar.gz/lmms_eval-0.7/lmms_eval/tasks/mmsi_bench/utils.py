import io
import logging
import re
from collections import defaultdict

from PIL import Image

eval_logger = logging.getLogger("lmms-eval")


CATEGORY_ALIASES = {
    "Positional Relationship (Obj.-Obj.)": "Positional Relationship (Obj.–Obj.)",
    "Positional Relationship (Cam.-Obj.)": "Positional Relationship (Cam.–Obj.)",
    "Positional Relationship (Cam.-Cam.)": "Positional Relationship (Cam.–Cam.)",
    "Positional Relationship (Obj.-Reg.)": "Positional Relationship (Obj.–Reg.)",
    "Positional Relationship (Cam.-Reg.)": "Positional Relationship (Cam.–Reg.)",
    "Positional Relationship (Reg.-Reg.)": "Positional Relationship (Reg.–Reg.)",
}


def msr_doc_to_text(doc, lmms_eval_specific_kwargs=None):
    if not isinstance(lmms_eval_specific_kwargs, dict):
        lmms_eval_specific_kwargs = {}

    pre_prompt = lmms_eval_specific_kwargs.get("pre_prompt", "")
    post_prompt = lmms_eval_specific_kwargs.get("post_prompt", "")

    question = doc["question"].strip()
    if pre_prompt != "":
        question = f"{pre_prompt}{question}"
    if post_prompt != "":
        question = f"{question}{post_prompt}"
    return question


def msr_doc_to_visual(doc):
    image_list = []
    for img_data in doc["images"]:
        if isinstance(img_data, Image.Image):
            image = img_data.convert("RGB")
        else:
            image = Image.open(io.BytesIO(img_data)).convert("RGB")
        image_list.append(image)
    return image_list


def extract_single_choice_with_word_boundary(pred, gt):
    if pred is None:
        return None

    pred = str(pred)

    pattern_1 = r"``([^`]*)``"
    match = re.search(pattern_1, pred)
    if match:
        pred = match.group(1)

    pattern_2 = r"`([^`]*)`"
    match = re.search(pattern_2, pred)
    if match:
        pred = match.group(1)

    pattern_add = r"\{([^}]*)\}"
    match = re.search(pattern_add, pred)
    if match:
        pred = match.group(1)

    pattern_3 = r"\b[A-F]\b(?!\s[a-zA-Z])"
    match = re.search(pattern_3, pred, flags=re.IGNORECASE)
    if match:
        pred = match.group().upper()
    else:
        return None

    answer = gt.lower().replace("\n", " ").strip()
    predict = pred.lower().replace("\n", " ").strip()
    try:
        if answer == predict[0]:
            return 1.0
        elif predict[0] == "(" and answer == predict[1]:
            return 1.0
        elif predict[0:7] == "option " and answer == predict[7]:
            return 1.0
        elif predict[0:14] == "the answer is " and answer == predict[14]:
            return 1.0
    except Exception:
        return 0.0
    return 0.0


def msr_process_results(doc, results):
    """
    Args:
        doc: a instance of the eval dataset
        results: [pred]
    Returns:
        a dictionary with key: metric name, value: metric value
    """
    pred = results[0]
    gt = doc["answer"]

    score = extract_single_choice_with_word_boundary(pred, gt)
    category = CATEGORY_ALIASES.get(doc["question_type"], doc["question_type"])
    l2_category = category
    if score is None:
        return {category: {"question_id": doc["id"], "l2_category": l2_category, "score": 0, "note": "cannot find answer"}, "average": {"question_id": doc["id"], "l2_category": l2_category, "score": 0, "note": "cannot find answer"}}
    return {category: {"question_id": doc["id"], "l2_category": l2_category, "score": score}, "average": {"question_id": doc["id"], "l2_category": l2_category, "score": score}}


def msr_aggregate_results(results):
    """
    Args:
        results: a list of values returned by process_results
    Returns:
        A score
    """
    l2_category_scores = defaultdict(list)
    for result in results:
        score = result["score"]
        l2_category = result["l2_category"]
        l2_category_scores[l2_category].append(score)

    l2_category_avg_score = {}
    for l2_category, scores in l2_category_scores.items():
        avg_score = sum(scores) / len(scores)
        l2_category_avg_score[l2_category] = avg_score
        eval_logger.info(f"{l2_category}: {avg_score:.2f}")

    all_scores = [score for scores in l2_category_scores.values() for score in scores]
    avg_score = sum(all_scores) / len(all_scores) if all_scores else 0.0
    return avg_score
