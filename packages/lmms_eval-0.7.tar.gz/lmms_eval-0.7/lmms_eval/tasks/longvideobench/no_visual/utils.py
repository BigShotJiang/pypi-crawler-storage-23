# LongVideoBench No Visual Setting Utils


def longvideobench_doc_to_visual_empty(doc):
    """Return empty visual for no_visual setting."""
    return []
