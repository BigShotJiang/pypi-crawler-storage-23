# ImgEdit Benchmark Task
# Paper: ImgEdit: A Unified Image Editing Benchmark
# https://github.com/sysuyy/ImgEdit
