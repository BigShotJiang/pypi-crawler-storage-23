"""Unified CLI subcommand dispatch for lmms-eval."""

from lmms_eval.cli.dispatch import main

__all__ = ["main"]
