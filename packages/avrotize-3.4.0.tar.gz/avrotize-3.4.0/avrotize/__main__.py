# __main__.py 

from . import avrotize

if __name__ == '__main__':
      avrotize.main()