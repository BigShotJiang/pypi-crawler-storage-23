"""YAML-based configuration for PA Client."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from importlib import resources
from pathlib import Path
from typing import Any, ClassVar

import yaml

logger = logging.getLogger(__name__)


@dataclass
class SearchConfig:
    """Search-related configuration."""
    max_queries_per_market: int = 1
    max_results_per_query: int = 3
    mock: bool = False
    connect_timeout: int = 10
    total_timeout: int = 30
    fetch_timeout: int = 15
    max_concurrent: int = 3
    max_html_bytes: int = 512 * 1024   # Cap per-page HTML download (bytes)
    max_extract_chars: int = 5_000     # Truncate extracted article text (chars)


@dataclass
class PipelineConfig:
    """Pipeline-related configuration."""
    max_markets: int = 5
    min_size_usd: float = 1.0


@dataclass
class LLMConfig:
    """LLM-related configuration."""
    temperature: float = 0.7
    max_tokens: int = 4096
    max_retries: int = 3
    retry_delay: float = 1.0
    http_timeout: float = 600.0
    verbose_truncate_chars: int = 3000


@dataclass
class ServerConfig:
    """Server/API configuration."""
    timeout: int = 30
    max_retries: int = 3
    retry_backoff: float = 1.0
    poll_interval: float = 60.0
    max_polls: int = 60   # Max polling iterations (60 * 60s = 1 hour)


@dataclass
class BenchmarkConfig:
    """Benchmark execution configuration."""
    initial_cash: float = 10000.0
    deadline_buffer_seconds: int = 180  # Skip tick if deadline < this
    result_timeout_seconds: int = 300  # Wait for agent results
    process_join_timeout: int = 10  # Wait for process cleanup


@dataclass
class MemoryConfig:
    """Memory/context configuration."""
    recent_ticks_limit: int = 5
    market_history_limit: int = 3


@dataclass
class ClientConfig:
    """Full client configuration."""
    search: SearchConfig = field(default_factory=SearchConfig)
    pipeline: PipelineConfig = field(default_factory=PipelineConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    server: ServerConfig = field(default_factory=ServerConfig)
    memory: MemoryConfig = field(default_factory=MemoryConfig)
    benchmark: BenchmarkConfig = field(default_factory=BenchmarkConfig)

    # Singleton instance (class-level, not per-instance)
    _instance: ClassVar[ClientConfig | None] = None

    @classmethod
    def load(cls, config_path: Path | str | None = None) -> ClientConfig:
        """Load configuration from YAML file.

        Looks for config files in this order:
        1. Explicit path if provided
        2. config.yaml (defaults)
        3. config.local.yaml (gitignored, local overrides)

        Args:
            config_path: Optional explicit path to config file

        Returns:
            Loaded configuration (cached as singleton)
        """
        # Return cached instance if available and no explicit path
        if cls._instance is not None and config_path is None:
            return cls._instance

        # Determine config file path
        if config_path:
            config_data: dict[str, Any] = {}
            path = Path(config_path)
            if path.exists():
                logger.info(f"Loading config from {path}")
                with open(path) as f:
                    config_data = yaml.safe_load(f) or {}
            else:
                logger.info("No config file found at explicit path, using defaults")
        else:
            # Load bundled config.yaml from package data
            config_data = {}
            try:
                pkg_files = resources.files("ai_prophet")
                config_text = (pkg_files / "config.yaml").read_text(encoding="utf-8")
                config_data = yaml.safe_load(config_text) or {}
                logger.info("Loaded bundled config.yaml defaults")
            except (FileNotFoundError, TypeError):
                logger.info("No bundled config.yaml found, using defaults")

            # Check for local overrides in current directory
            local_path = Path("config.local.yaml")
            if local_path.exists():
                logger.info(f"Loading local config overrides from {local_path}")
                with open(local_path) as f:
                    local_data = yaml.safe_load(f) or {}
                config_data = _deep_merge(config_data, local_data)

        # Build config objects
        instance = cls(
            search=SearchConfig(**config_data.get("search", {})),
            pipeline=PipelineConfig(**config_data.get("pipeline", {})),
            llm=LLMConfig(**config_data.get("llm", {})),
            server=ServerConfig(**config_data.get("server", {})),
            memory=MemoryConfig(**config_data.get("memory", {})),
            benchmark=BenchmarkConfig(**config_data.get("benchmark", {})),
        )

        # Cache as singleton
        if config_path is None:
            cls._instance = instance

        return instance

    @classmethod
    def get(cls) -> ClientConfig:
        """Get the current config instance (loads if not already loaded)."""
        if cls._instance is None:
            return cls.load()
        return cls._instance

    @classmethod
    def reset(cls) -> None:
        """Reset the singleton instance (useful for testing)."""
        cls._instance = None

    def __repr__(self) -> str:
        return (
            f"ClientConfig(\n"
            f"  search: queries={self.search.max_queries_per_market}, results={self.search.max_results_per_query}\n"
            f"  pipeline: markets={self.pipeline.max_markets}, min_size=${self.pipeline.min_size_usd}\n"
            f"  llm: temp={self.llm.temperature}, max_tokens={self.llm.max_tokens}\n"
            f"  server: timeout={self.server.timeout}s, retries={self.server.max_retries}\n"
            f"  benchmark: cash=${self.benchmark.initial_cash}\n"
            f")"
        )


def _deep_merge(base: dict, override: dict) -> dict:
    """Deep merge two dicts, with override taking precedence."""
    result = base.copy()
    for key, value in override.items():
        if key in result and isinstance(result[key], dict) and isinstance(value, dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result
