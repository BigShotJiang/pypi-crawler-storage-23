"""Prophet Arena Client - LLM trading benchmark framework.

Usage:
    from ai_prophet.runner import ExperimentRunner

    runner = ExperimentRunner(
        experiment_slug="prod_run_001",
        models=[{"model": "openai:gpt-5", "rep": 0}],
    )
    runner.run()
"""

__version__ = "0.1.0"

from .runner import ExperimentRunner

__all__ = ["ExperimentRunner", "__version__"]
