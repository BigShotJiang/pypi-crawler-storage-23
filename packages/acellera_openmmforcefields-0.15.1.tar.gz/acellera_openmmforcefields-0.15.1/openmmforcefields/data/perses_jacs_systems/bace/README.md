### Bace setup

TLA spectator molecule was saved as an `.sdf` from `*merged.pdb` file, and manually edited to add bonds and charges for the two carboxylic acid groups.
