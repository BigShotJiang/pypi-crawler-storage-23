CDK protein has been set up differently to the others in this directory


using pymol:

> sele protein, `*merged.pdb` and polymer


protein was then saved as a pdb, with the CONECT lines retained.
These are needed as there is a non-native amino acid in the structure
