# [MiniDrugBank](https://github.com/openforcefield/MiniDrugBank) retrieved 15 Mar 2019.

## Manifest

* `MiniDrugBank.sdf` - original file
* `MiniDrugBank-without-unspecifie-stereochemistry.sdf` - molecules without specified stereochemistry filtered out
