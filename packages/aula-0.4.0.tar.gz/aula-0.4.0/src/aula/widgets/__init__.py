from .client import AulaWidgetsClient

__all__ = ["AulaWidgetsClient"]
