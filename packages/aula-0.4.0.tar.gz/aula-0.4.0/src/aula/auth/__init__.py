"""MitID authentication module for Aula."""
