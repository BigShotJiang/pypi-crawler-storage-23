from .catalog import COURSE

__all__ = ["COURSE"]
