"""SDV lite package that contains model presets."""

from sdv.lite.single_table import SingleTablePreset

__all__ = ('SingleTablePreset',)
