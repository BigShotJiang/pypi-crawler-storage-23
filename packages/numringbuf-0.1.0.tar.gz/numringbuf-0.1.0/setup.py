import os
import sys
from setuptools import setup, Extension, find_packages
from Cython.Build import cythonize
import numpy as np

annotate_cython = os.environ.get("CYTHON_ANNOTATE", "0") == "1"

if sys.platform == "win32":
    extra_compile_args = ["/O2"]  # MSVC optimization
else:
    extra_compile_args = ["-O3"]  # GCC/Clang optimization

extensions = [
    Extension(
        "numringbuf.core",
        sources=["src/numringbuf/core.pyx"],
        include_dirs=[np.get_include()],  # NumPy C-API
        extra_compile_args=extra_compile_args,
    )
]

setup(
    name="NumRingBuf",
    version="0.1.0",
    description="High-performance numerical ring buffers with O(1) accumulators",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Syed Basim Ali",
    author_email="basim.ali.contact@gmail.com",
    url="https://github.com/basimali-ai/NumRingBuf",
    project_urls={
        "Source Code": "https://github.com/basimali-ai/NumRingBuf",
    },
    python_requires=">=3.9",
    install_requires=[
        "numpy>=2.0.0,<3.0.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.2",
            "cython>=3.0",
            "build>=0.10",
        ],
        "docs": [
            "sphinx>=6.0",
            "sphinx-rtd-theme>=1.3",
        ],
    },
    packages=find_packages(),
    package_data={
        "numringbuf": ["*.pyi", "*.pxd", "*.pyx", "*.c"],
    },
    include_package_data=True,
    ext_modules=cythonize(
        extensions,
        include_path=[np.get_include()],
        annotate=annotate_cython,  # html
    ),
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Intended Audience :: Developers",
        "Intended Audience :: Science/Research",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Programming Language :: Cython",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Typing :: Typed",
    ],
    keywords=[
        "ring-buffer",
        "circular-buffer",
        "audio-processing",
        "signal-processing",
        "real-time",
        "performance",
        "numpy",
        "cython",
        "numerical",
        "high-performance",
    ],
    license="Apache-2.0",
    zip_safe=False,
)
