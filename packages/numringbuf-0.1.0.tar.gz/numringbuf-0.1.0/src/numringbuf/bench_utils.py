# Copyright 2026 Syed Basim Ali
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations
import logging
from typing import Optional, Callable, Any
from time import perf_counter_ns
import sys
from datetime import datetime
import gc
import psutil
import os
from contextlib import contextmanager
from typing import Literal
import re
import subprocess
import platform

import numpy as np

from .utils import classproperty
from .system_info import (
    PAGESIZE,
    get_cache_line_size,
    get_cpu_l3_cache_mib,
)

logger = logging.getLogger(__name__)
if not logger.handlers:
    logger.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    formatter = logging.Formatter("%(message)s")
    ch.setFormatter(formatter)
    logger.addHandler(ch)

RS = 25
ss = np.random.SeedSequence(RS)
child_ss = ss.spawn(5)
rngs = tuple(np.random.default_rng(s) for s in child_ss)

_cache_line_size: int | None = None


class EvictArrConfig:
    _DTYPE: type | None = None
    _MIB: int | None = None

    @classproperty
    def DTYPE(cls):
        if cls._DTYPE is None:
            cls._DTYPE = np.float64
        return cls._DTYPE

    @classproperty
    def MIB(cls):
        if cls._MIB is None:
            cls._MIB = get_cpu_l3_cache_mib()
        return cls._MIB

    @classmethod
    def set_MIB(cls, value: int):
        cls._MIB = value

    @classmethod
    def set_DTYPE(cls, dtype: type):
        cls._DTYPE = dtype

    @classproperty
    def bytes(cls):
        return cls.MIB * (1024**2)

    @classproperty
    def shape(cls):
        return (cls.bytes // np.dtype(cls.DTYPE).itemsize,)


def get_cpu_name():
    try:
        out = subprocess.check_output(
            ["wmic", "cpu", "get", "name"], stderr=subprocess.DEVNULL
        ).decode(errors="ignore")
        name = out.split("\n")[1].strip()
    except Exception:
        name = platform.processor()

    name = name.lower()
    name = re.sub(r"\(r\)|\(tm\)|cpu|processor", "", name)
    name = re.sub(r"@.*", "", name)
    name = re.sub(r"[^\w]+", "_", name)
    name = re.sub(r"_+", "_", name).strip("_")
    return name


def touch_pages(
    arr: np.ndarray,
    *,
    warm_cache: bool = False,
    page_size: int = PAGESIZE,
    cache_line_bytes: int | None = None,
) -> None:
    if warm_cache:
        if cache_line_bytes is None:
            global _cache_line_size
            if _cache_line_size is None:
                _cache_line_size = get_cache_line_size()
            cache_line_bytes = _cache_line_size
        np.add.reduce(arr[:: cache_line_bytes // arr.itemsize])
        return
    np.add.reduce(arr[:: page_size // arr.itemsize])


def set_process_priority(priority: Literal["high", "normal"] = "high"):
    p = psutil.Process(os.getpid())
    if priority == "high":
        p.nice(psutil.HIGH_PRIORITY_CLASS)
    elif priority == "normal":
        p.nice(psutil.NORMAL_PRIORITY_CLASS)


@contextmanager
def no_gc():
    gc.collect()
    gc.disable()
    try:
        yield
    finally:
        gc.enable()


def trimmed_mean_times(arr: np.ndarray):
    arr_size = arr.size
    if arr_size == 0:
        return 0
    drop = max(1, round(arr_size / 10))
    if drop >= arr_size:
        return int(arr.mean())
    return int(arr[drop:].mean())


def determine_num_runs(
    *,
    elem_bytes: int,
    total_byte_limit: int,
    maxlen_byte_limit: int | None = None,
    block_byte_limit: int | None = None,
    maxlen: int | None = None,
    block_size: int | None = None,
    with_fill: bool,
):
    max_elems = total_byte_limit // elem_bytes

    if block_size is None:
        if block_byte_limit is None:
            raise ValueError(
                "neither block_byte_limit nor block_size provided"
            )
        block_size = block_byte_limit // elem_bytes

    if maxlen is None:
        if maxlen_byte_limit is None:
            raise ValueError("neither maxlen_byte_limit nor maxlen provided")
        maxlen = maxlen_byte_limit // elem_bytes

    if block_size <= 0:
        raise ValueError("block_size cannot be <= 0")

    if maxlen <= 2:
        raise ValueError("maxlen cannot be <= 2")

    if maxlen < block_size:
        raise ValueError("maxlen cannot be < block_size")

    warmup_block_size = maxlen
    fixed = maxlen + warmup_block_size

    fill_size = maxlen if with_fill else 0
    offset_size = maxlen - max(1, block_size // 2)
    elems_per_pair_run = (block_size * 2) + offset_size + (fill_size * 2)

    if fixed + elems_per_pair_run > max_elems:
        raise ValueError("total_byte_limit too low")

    k = (max_elems - fixed) // elems_per_pair_run
    n_runs = k * 2
    offset_num_blocks = n_runs // 2

    total_elems = (
        fixed
        + (n_runs * block_size)
        + (offset_num_blocks * offset_size)
        + (n_runs * fill_size)
    )

    if total_elems + (block_size + fill_size + offset_size) <= max_elems:
        n_runs += 1

    return n_runs, block_size, maxlen


def generate_rand_memmap_arr(
    dtype: type,
    shape: tuple[int, int] | tuple[int],
    path: str,
    rng: np.random.Generator,
    *,
    multiply_by: np.generic | float | int | None = None,
    subtract: np.generic | float | int | None = None,
) -> np.memmap:

    data = np.memmap(path, dtype=dtype, mode="w+", shape=shape)

    if multiply_by is None:
        multiply_needed = False
    else:
        multiply_needed = True

    if subtract is None:
        subtraction_needed = False
    else:
        subtraction_needed = True

    if np.issubdtype(dtype, np.integer):
        info = np.iinfo(dtype)

        if subtraction_needed:
            if not float(subtract).is_integer():  # type: ignore
                raise ValueError(
                    "subtract must be an integer for integer dtype"
                )
            sub = int(subtract)  # type: ignore
        else:
            sub = 0

        if multiply_needed:
            if not float(multiply_by).is_integer():  # type: ignore
                raise ValueError(
                    "multiply_by must be an integer for integer dtype"
                )
            mul = int(multiply_by)  # type: ignore
        else:
            mul = 1

        if mul == 0:
            value = -sub
            if not (info.min <= value <= info.max):
                raise ValueError("Resulting constant out of dtype bounds")
            data.fill(value)
            return data

        if mul > 0:
            low = -(-(int(info.min) + sub) // mul)
            high = (int(info.max) + sub) // mul
        else:
            low = -(-(int(info.max) + sub) // mul)
            high = (int(info.min) + sub) // mul

        data[:] = rng.integers(
            low=low,
            high=high,
            size=shape,
            dtype=dtype,
            endpoint=True,
        )

    elif np.issubdtype(dtype, np.floating):
        rng.random(shape, dtype=dtype, out=data)  # type: ignore

    else:
        raise TypeError(f"Unsupported dtype: {dtype}")

    if multiply_needed:
        data *= multiply_by  # type: ignore
    if subtraction_needed:
        data -= subtract  # type: ignore

    return data


def generate_bench_memmaps(
    dtype: type,
    maxlen: int,
    block_size: int,
    num_blocks: int,
    *,
    create_offset_data: bool,
    create_fill_data: bool,
    create_evict_arr: bool,
    data_path: str = "temp_bench_data.dat",
    warmup_path: str = "temp_bench_warmup.dat",
    offset_path: str = "temp_bench_offset.dat",
    fill_path: str = "temp_bench_fill.dat",
    evict_path: str = "temp_bench_evict.dat",
):
    if num_blocks <= 1:
        raise ValueError("num_blocks must be > 1")

    multiply_by = dtype(2)
    subtract = dtype(1)

    data = generate_rand_memmap_arr(
        dtype,
        (num_blocks, block_size),
        data_path,
        rngs[0],
        multiply_by=multiply_by,
        subtract=subtract,
    )

    warmup_data = generate_rand_memmap_arr(
        dtype,
        (maxlen,),
        warmup_path,
        rngs[1],
        multiply_by=multiply_by,
        subtract=subtract,
    )

    if create_offset_data:
        offset_data = generate_rand_memmap_arr(
            dtype,
            (num_blocks // 2, maxlen - (block_size // 2)),
            offset_path,
            rngs[2],
            multiply_by=multiply_by,
            subtract=subtract,
        )
    else:
        offset_path, offset_data = "", None

    if create_fill_data:
        fill_data = generate_rand_memmap_arr(
            dtype,
            (num_blocks, maxlen),
            fill_path,
            rngs[3],
            multiply_by=multiply_by,
            subtract=subtract,
        )
    else:
        fill_path, fill_data = "", None

    if create_evict_arr:
        evict_arr = generate_rand_memmap_arr(
            EvictArrConfig.DTYPE,
            EvictArrConfig.shape,
            evict_path,
            rngs[4],
        )
    else:
        evict_path, evict_arr = "", None

    return (
        data_path,
        data,
        warmup_path,
        warmup_data,
        offset_path,
        offset_data,
        fill_path,
        fill_data,
        evict_path,
        evict_arr,
    )


@contextmanager
def temporary_benchmark_data(
    dtype,
    buffer_maxlen,
    block_size,
    n_runs,
    *,
    create_offset_data: bool,
    create_fill_data: bool,
    create_evict_arr: bool,
    data_path: str = "temp_bench_data.dat",
    warmup_path: str = "temp_bench_warmup.dat",
    offset_path: str = "temp_bench_offset.dat",
    fill_path: str = "temp_bench_fill.dat",
    evict_path: str = "temp_bench_evict.dat",
):
    _data_path = _warmup_path = _offset_path = _fill_path = _evict_path = None
    data = warmup_data = offset_data = fill_data = evict_arr = None

    try:
        (
            _data_path,
            data,
            _warmup_path,
            warmup_data,
            _offset_path,
            offset_data,
            _fill_path,
            fill_data,
            _evict_path,
            evict_arr,
        ) = generate_bench_memmaps(
            dtype,
            buffer_maxlen,
            block_size,
            n_runs,
            create_offset_data=create_offset_data,
            create_fill_data=create_fill_data,
            create_evict_arr=create_evict_arr,
            data_path=data_path,
            warmup_path=warmup_path,
            offset_path=offset_path,
            fill_path=fill_path,
            evict_path=evict_path,
        )
        yield data, warmup_data, offset_data, fill_data, evict_arr, _data_path, _warmup_path, _offset_path, _fill_path, _evict_path

    finally:
        for var in (data, warmup_data, offset_data, fill_data, evict_arr):
            try:
                mmap_obj = getattr(var, "_mmap", None)
                if mmap_obj is not None:
                    mmap_obj.close()
            except Exception:
                continue

        for path in (
            _data_path,
            _warmup_path,
            _offset_path,
            _fill_path,
            _evict_path,
        ):
            try:
                if path and os.path.exists(path):
                    os.remove(path)
            except Exception:
                print(
                    "--- Could not delete temp file. Delete manually. ---\n"
                    f"Path: {path}"
                )
                continue


def prepare_blocks(
    block_size: int,
    maxlen: int,
    dtype: type,
    n_runs: int,
    data_path: str,
    data_shape: tuple[int, int],
    warmup_path: str,
    warmup_data_shape: tuple[int, int],
    *,
    single_offset: bool,
    offset_path: str = "",
    offset_data_shape: tuple[int, int] = (0, 0),
    prepare_fill: bool,
    fill_path: str = "",
    fill_data_shape: tuple[int, int] = (0, 0),
    prepare_evict: bool,
    evict_path: str = "",
):
    blocks_full = np.memmap(data_path, dtype=dtype, mode="r", shape=data_shape)
    blocks = blocks_full[:n_runs, :block_size]

    warmup_data = np.memmap(
        warmup_path,
        dtype=dtype,
        mode="r",
        shape=warmup_data_shape,
    )
    warmup_block = warmup_data[:maxlen]

    if single_offset:
        offset = warmup_block[: maxlen - (block_size // 2)]
    elif offset_path and offset_data_shape != (0, 0):
        offset_blocks_full = np.memmap(
            offset_path,
            dtype=dtype,
            mode="r",
            shape=offset_data_shape,
        )
        offset = offset_blocks_full[: n_runs // 2, :block_size]
    else:
        raise ValueError(
            "Multiple offset blocks requested but the "
            "offset path and/or shape was not provided or is invalid."
        )

    if prepare_fill:
        if fill_path and fill_data_shape != (0, 0):
            fill_blocks_full = np.memmap(
                fill_path,
                dtype=dtype,
                mode="r",
                shape=fill_data_shape,
            )
            fill = fill_blocks_full[:n_runs, :maxlen]
        else:
            raise ValueError(
                "Fill blocks preparation requested but the "
                "fill path and/or shape was not provided or is invalid."
            )
    else:
        fill = None

    if prepare_evict:
        if evict_path:
            evict_arr = np.memmap(
                evict_path,
                dtype=EvictArrConfig.DTYPE,
                mode="r",
                shape=EvictArrConfig.shape,
            )
        else:
            raise ValueError(
                "Evict array preparation requested but the "
                "evict path was not provided or is invalid."
            )
    else:
        evict_arr = None

    return blocks, warmup_block, offset, fill, evict_arr


def _append_timed_with_calc(buffer, block, func):
    val = block.item()
    t0 = perf_counter_ns()
    buffer.append(val)
    func()
    return perf_counter_ns() - t0


def _append_timed(buffer, block):
    val = block.item()
    t0 = perf_counter_ns()
    buffer.append(val)
    return perf_counter_ns() - t0


def _extend_timed_with_calc(buffer, block, func):
    t0 = perf_counter_ns()
    buffer.extend_unchecked(block)
    func()
    return perf_counter_ns() - t0


def _extend_timed(buffer, block):
    t0 = perf_counter_ns()
    buffer.extend_unchecked(block)
    return perf_counter_ns() - t0


def _read_timed(buffer, _):
    t0 = perf_counter_ns()
    buffer.read()
    return perf_counter_ns() - t0


def _read_into_timed(buffer, read_into_arr):
    t0 = perf_counter_ns()
    buffer.read_into(read_into_arr)
    return perf_counter_ns() - t0


def _write_extend_timed(buffer, block):
    t0 = perf_counter_ns()
    buffer.write_extend_unchecked(block)
    return perf_counter_ns() - t0


def raw_bench_with_calc(
    buffer: Any,
    func: Callable[[], Any],
    fill_blocks: np.ndarray,
    offset_blocks: np.ndarray,
    warmup_block: np.ndarray,
    blocks: np.ndarray,
    calc_every: int,
    n_runs: int,
    evict_arr: np.ndarray | None,
    warm_cache: bool = False,
):
    n_wrap_runs = n_runs // 2
    n_nowrap_runs = n_runs - n_wrap_runs

    if blocks.shape[0] != n_runs:
        raise ValueError()
    if fill_blocks.shape[0] != n_runs:
        raise ValueError()
    if offset_blocks.shape[0] != n_wrap_runs:
        raise ValueError()

    if blocks.shape[1] == 1:
        bench_func = _append_timed
        bench_func_calc = _append_timed_with_calc
    else:
        bench_func = _extend_timed
        bench_func_calc = _extend_timed_with_calc

    set_process_priority()
    with no_gc():
        if evict_arr is not None:
            touch_pages(evict_arr, warm_cache=True)

        wrap_times = np.empty(n_wrap_runs, dtype=np.uint64)
        nowrap_times = np.empty(n_nowrap_runs, dtype=np.uint64)

        wrap_blocks = blocks[:n_wrap_runs]
        nowrap_blocks = blocks[n_wrap_runs:]

        wrap_fill = fill_blocks[:n_wrap_runs]
        nowrap_fill = fill_blocks[n_wrap_runs:]

        def make_calc_mask(length, calc_every):
            mask = np.zeros(length, dtype=bool)
            mask[calc_every - 1 :: calc_every] = True
            return mask

        wrap_calc_mask = make_calc_mask(n_wrap_runs, calc_every)
        nowrap_calc_mask = make_calc_mask(n_nowrap_runs, calc_every)

        buffer.extend_unchecked(warmup_block)
        for i, block in enumerate(wrap_blocks):
            buffer.clear()
            buffer.extend_unchecked(wrap_fill[i])
            buffer.extend_unchecked(offset_blocks[i])
            touch_pages(block, warm_cache=warm_cache)
            if wrap_calc_mask[i]:
                wrap_times[i] = bench_func_calc(buffer, block, func)
            else:
                wrap_times[i] = bench_func(buffer, block)
        for i, block in enumerate(nowrap_blocks):
            buffer.clear()
            buffer.extend_unchecked(nowrap_fill[i])
            touch_pages(block, warm_cache=warm_cache)
            if nowrap_calc_mask[i]:
                nowrap_times[i] = bench_func_calc(buffer, block, func)
            else:
                nowrap_times[i] = bench_func(buffer, block)
    return (
        trimmed_mean_times(wrap_times) + trimmed_mean_times(nowrap_times)
    ) // 2


def raw_bench(
    buffer: Any,
    offset_blocks: np.ndarray,
    warmup_block: np.ndarray,
    blocks: np.ndarray,
    n_runs: int,
    evict_arr: np.ndarray | None,
    warm_cache: bool = False,
):
    n_wrap_runs = n_runs // 2
    n_nowrap_runs = n_runs - n_wrap_runs

    if blocks.shape[0] != n_runs:
        raise ValueError()
    if offset_blocks.shape[0] != n_wrap_runs:
        raise ValueError()

    if blocks.shape[1] == 1:
        bench_func = _append_timed
    else:
        bench_func = _extend_timed

    set_process_priority()
    with no_gc():
        if evict_arr is not None:
            touch_pages(evict_arr, warm_cache=True)

        wrap_times = np.empty(n_wrap_runs, dtype=np.uint64)
        nowrap_times = np.empty(n_nowrap_runs, dtype=np.uint64)

        wrap_blocks = blocks[:n_wrap_runs]
        nowrap_blocks = blocks[n_wrap_runs:]

        buffer.extend_unchecked(warmup_block)
        for i, block in enumerate(wrap_blocks):
            buffer.clear()
            buffer.extend_unchecked(offset_blocks[i])
            touch_pages(block, warm_cache=warm_cache)
            wrap_times[i] = bench_func(buffer, block)
        for i, block in enumerate(nowrap_blocks):
            buffer.clear()
            touch_pages(block, warm_cache=warm_cache)
            nowrap_times[i] = bench_func(buffer, block)

    return (
        trimmed_mean_times(wrap_times) + trimmed_mean_times(nowrap_times)
    ) // 2


def raw_bench_write_read(
    buffer: Any,
    offset_blocks: np.ndarray,
    warmup_block: np.ndarray,
    blocks: np.ndarray,
    n_runs: int,
    evict_arr: np.ndarray | None,
    warm_cache: bool = False,
    read_into_arr: np.ndarray | None = None,
):

    n_wrap_runs = n_runs // 2
    n_nowrap_runs = n_runs - n_wrap_runs

    if blocks.shape[0] != n_runs:
        raise ValueError()
    if offset_blocks.shape[0] != n_wrap_runs:
        raise ValueError()

    if blocks.shape[1] == 1:
        write_bench_func = _append_timed
    else:
        write_bench_func = _write_extend_timed

    if read_into_arr is None:
        read_bench_func = _read_timed
    else:
        read_bench_func = _read_into_timed

    set_process_priority()
    with no_gc():
        if evict_arr is not None:
            touch_pages(evict_arr, warm_cache=True)

        wrap_write_times = np.empty(n_wrap_runs, dtype=np.uint64)
        wrap_read_times = np.empty(n_wrap_runs, dtype=np.uint64)

        nowrap_write_times = np.empty(n_nowrap_runs, dtype=np.uint64)
        nowrap_read_times = np.empty(n_nowrap_runs, dtype=np.uint64)

        wrap_blocks = blocks[:n_wrap_runs]
        nowrap_blocks = blocks[n_wrap_runs:]

        buffer.clear()
        buffer.write_extend_unchecked(warmup_block)

        for i, block in enumerate(wrap_blocks):
            buffer.clear()
            buffer.write_extend_unchecked(offset_blocks[i])
            buffer.read()
            touch_pages(block, warm_cache=warm_cache)
            wrap_write_times[i] = write_bench_func(buffer, block)
            wrap_read_times[i] = read_bench_func(buffer, read_into_arr)
        for i, block in enumerate(nowrap_blocks):
            buffer.clear()
            touch_pages(block, warm_cache=warm_cache)
            nowrap_write_times[i] = write_bench_func(buffer, block)
            nowrap_read_times[i] = read_bench_func(buffer, read_into_arr)

    return (
        trimmed_mean_times(wrap_write_times)
        + trimmed_mean_times(nowrap_write_times)
    ) // 2, (
        trimmed_mean_times(wrap_read_times)
        + trimmed_mean_times(nowrap_read_times)
    ) // 2


class BenchLogger:
    def __init__(self, file_name: str):
        self.file_name = file_name
        os.makedirs(os.path.dirname(file_name), exist_ok=True)
        with open(file_name, "w") as f:
            f.write(f"Logging started at {datetime.now()}\n")
            f.write("=" * 80 + "\n")
            f.flush()
            os.fsync(f.fileno())

    def log(self, msg: str, to_console: bool = False):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        line = f"[{timestamp}] {msg}\n"

        with open(self.file_name, "a") as f:
            f.write(line)
            f.flush()
            os.fsync(f.fileno())

        if to_console:
            print(line.strip(), flush=True)
            sys.stdout.flush()


class RefPythonNumPyRingBuffer:
    __slots__ = ["buffer", "write_head", "size", "maxlen", "_raw"]

    def __init__(
        self,
        maxlen: int,
        return_overwritten_policy: Optional[str] = None,
        dtype: type = np.float32,
        *,
        cache_line_size: int | None = None,
    ):
        if cache_line_size is None:
            global _cache_line_size
            if _cache_line_size is None:
                _cache_line_size = get_cache_line_size()
            cache_line_size = _cache_line_size

        itemsize = np.dtype(dtype).itemsize
        offset = (cache_line_size * 2) // itemsize
        padding = offset + (cache_line_size // itemsize)

        self._raw: np.ndarray = np.zeros(maxlen + padding, dtype=dtype)
        self.buffer = self._raw[offset : offset + maxlen]

        self.write_head = 0
        self.size = 0
        self.maxlen = maxlen

    def append(self, value: float | int):
        write_head = self.write_head
        maxlen = self.maxlen

        if self.size < maxlen:
            self.size += 1

        self.buffer[write_head] = value

        write_head += 1
        if write_head >= maxlen:
            write_head = 0
        self.write_head = write_head

    def extend_unchecked(self, block_np: np.ndarray):
        write_head = self.write_head
        maxlen = self.maxlen
        n = len(block_np)

        if not n:
            return

        if write_head + n <= maxlen:
            self.buffer[write_head : write_head + n] = block_np
        else:
            buffer = self.buffer
            first_part = maxlen - write_head
            buffer[write_head : write_head + first_part] = block_np[
                :first_part
            ]
            buffer[: n - first_part] = block_np[first_part:]

        write_head += n
        if write_head >= maxlen:
            write_head -= maxlen
        self.write_head = write_head

        if self.size + n < maxlen:
            self.size += n

    def clear(self):
        self.write_head = 0
        self.size = 0
