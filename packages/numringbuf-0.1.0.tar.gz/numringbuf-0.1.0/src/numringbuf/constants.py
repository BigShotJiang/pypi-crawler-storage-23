# Copyright 2026 Syed Basim Ali
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from enum import IntEnum, Enum
import ctypes
import sys

import numpy as np

TYPICAL_CACHE_LINE = 64
TYPICAL_PAGESIZE = 4096


class SupportedDtypesFP(Enum):
    FLOAT64 = np.float64
    FLOAT32 = np.float32


class SupportedDtypesINT(Enum):
    INT64 = np.int64
    INT32 = np.int32


class SupportedDtypesUINT(Enum):
    UINT64 = np.uint64
    UINT32 = np.uint32


class SupportedDtypesAll(Enum):
    FLOAT64 = np.float64
    FLOAT32 = np.float32
    INT64 = np.int64
    INT32 = np.int32
    UINT64 = np.uint64
    UINT32 = np.uint32


class NpyTypenum(IntEnum):
    TIMEDELTA64 = np.dtype(np.timedelta64).num
    DATETIME64 = np.dtype(np.datetime64).num

    OBJECT = np.dtype(np.object_).num
    STR = np.dtype(np.str_).num
    BOOL = np.dtype(np.bool_).num

    UINT8 = np.dtype(np.uint8).num
    UINT16 = np.dtype(np.uint16).num
    UINT32 = np.dtype(np.uint32).num
    UINT64 = np.dtype(np.uint64).num

    INT8 = np.dtype(np.int8).num
    INT16 = np.dtype(np.int16).num
    INT32 = np.dtype(np.int32).num
    INT64 = np.dtype(np.int64).num

    FLOAT16 = np.dtype(np.float16).num
    FLOAT32 = np.dtype(np.float32).num
    FLOAT64 = np.dtype(np.float64).num

    COMPLEX64 = np.dtype(np.complex64).num
    COMPLEX128 = np.dtype(np.complex128).num


class Limits(IntEnum):
    PY_SSIZE_T_MAX = sys.maxsize
    SIZE_MAX = (1 << (ctypes.sizeof(ctypes.c_size_t) * 8)) - 1

    INT64_MIN = -(1 << ((ctypes.sizeof(ctypes.c_int64) * 8) - 1))
    INT64_MAX = (1 << ((ctypes.sizeof(ctypes.c_int64) * 8) - 1)) - 1

    INT32_MIN = -(1 << ((ctypes.sizeof(ctypes.c_int32) * 8) - 1))
    INT32_MAX = (1 << ((ctypes.sizeof(ctypes.c_int32) * 8) - 1)) - 1

    UINT32_MAX = (1 << (ctypes.sizeof(ctypes.c_uint32) * 8)) - 1
    UINT64_MAX = (1 << (ctypes.sizeof(ctypes.c_uint64) * 8)) - 1
