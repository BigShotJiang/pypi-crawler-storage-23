# Copyright 2026 Syed Basim Ali
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations
import logging
import time
from typing import Callable, Type, Literal, TYPE_CHECKING

if TYPE_CHECKING:
    import numpy as np
    from .core import RunningMeanBuffer, RunningMeanSqBuffer


logger = logging.getLogger(__name__)

if not logger.handlers:
    logger.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    formatter = logging.Formatter("%(message)s")
    ch.setFormatter(formatter)
    logger.addHandler(ch)


class classproperty:
    def __init__(self, f: Callable):
        self.f = f

    def __get__(self, obj, cls):
        return self.f(cls)


def determine_operation_focus(
    buffer_type: "Type[RunningMeanSqBuffer] | Type[RunningMeanBuffer]",
    dtype: "Type[np.float32] | Type[np.float64]",
    buffer_maxlen: int,
    block_size: int,
    calc_every: int,
    test_blocks: int = 128,
    verbose: bool = False,
) -> Literal["calculation", "extend/append"]:
    from .core import RunningMeanBuffer, RunningMeanSqBuffer
    from .bench_utils import (
        temporary_benchmark_data,
        raw_bench_with_calc,
    )

    start_time = time.time()
    with temporary_benchmark_data(
        dtype,
        buffer_maxlen,
        block_size,
        test_blocks,
        create_offset_data=True,
        create_fill_data=True,
        create_evict_arr=True,
    ) as (
        data,
        warmup_data,
        offset_data,
        fill_data,
        evict_arr,
        _,
        _,
        _,
        _,
        _,
    ):
        times = {}
        if issubclass(buffer_type, RunningMeanBuffer):
            func_str = "mean"
        elif issubclass(buffer_type, RunningMeanSqBuffer):
            func_str = "mean_square"
        else:
            raise TypeError(buffer_type)

        for operation_focus in ("calculation", "extend/append"):
            buffer = buffer_type(
                maxlen=buffer_maxlen,
                operation_focus=operation_focus,
                dtype=dtype,
            )
            times[operation_focus] = raw_bench_with_calc(
                buffer,
                getattr(buffer, func_str),
                fill_data,
                offset_data,
                warmup_data,
                data,
                calc_every,
                test_blocks,
                evict_arr,
            )

        calculation_speedup = times["extend/append"] / times["calculation"]
        extend_speedup = times["calculation"] / times["extend/append"]

        if verbose:
            end_time = time.time() - start_time
            logger.info(
                "\nSpeed Comparison ('calculation' vs 'extend/append'):"
                f"\n  'calculation' speedup = {calculation_speedup:.2f}×"
                f"\n  'extend/append' speedup = {extend_speedup:.2f}×"
                f"\nTotal time taken for data generation + benchmark: {end_time} s\n"
            )

        if calculation_speedup > extend_speedup:
            return "calculation"
        else:
            return "extend/append"
