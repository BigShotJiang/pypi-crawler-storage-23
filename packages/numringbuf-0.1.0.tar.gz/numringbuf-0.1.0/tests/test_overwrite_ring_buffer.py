"""
Tests for OverwriteRingBuffer
"""

import pytest
import numpy as np
from numringbuf import OverwriteRingBuffer
from numringbuf.constants import SupportedDtypesFP, SupportedDtypesAll
from numringbuf.exceptions import (
    IndexOutOfBounds,
    ConfigurationError,
    BufferCapacityError,
    DataTypeError,
)


MODES = (
    "never",
    "always",
    "conditional",
)
CAPACITIES = (1, 10, 100)
SUPPORTED_DTYPES_FP = tuple(a.value for a in SupportedDtypesFP)
SUPPORTED_DTYPES_ALL = tuple(a.value for a in SupportedDtypesAll)


@pytest.mark.parametrize("mode", MODES)
@pytest.mark.parametrize("dtype", SUPPORTED_DTYPES_ALL)
@pytest.mark.parametrize("capacity", CAPACITIES)
def test_initialization(mode, dtype, capacity):
    """Test CircularBuffer initialization/properties."""
    buffer = OverwriteRingBuffer(capacity, mode, dtype)
    assert buffer.maxlen == capacity
    assert len(buffer) == 0


@pytest.mark.parametrize("capacity", [-1, 0, 1.5, None, "abc"])
def test_invalid_capacity(capacity):
    with pytest.raises(BufferCapacityError):
        OverwriteRingBuffer(capacity, MODES[0], SUPPORTED_DTYPES_ALL[0])


@pytest.mark.parametrize("mode", [-1, 0, 1.5, None, "abc"])
def test_invalid_mode(mode):
    with pytest.raises(ConfigurationError):
        OverwriteRingBuffer(CAPACITIES[0], mode, SUPPORTED_DTYPES_ALL[0])


@pytest.mark.parametrize(
    "dtype",
    [np.float16, np.int16, np.uint16, np.bool, -1, 0, 1.5, None, "abc"],
)
def test_invalid_dtype(dtype):
    with pytest.raises(DataTypeError):
        OverwriteRingBuffer(CAPACITIES[0], MODES[0], dtype)


@pytest.mark.parametrize("mode", MODES)
@pytest.mark.parametrize("dtype", SUPPORTED_DTYPES_ALL)
@pytest.mark.parametrize("capacity", CAPACITIES)
def test_append_extend(mode, dtype, capacity):
    """Test basic append and extend operations."""
    buffer = OverwriteRingBuffer(capacity, mode, dtype)

    # Test append
    for i in range(capacity):
        buffer.append(i)
        assert len(buffer) == i + 1
    assert len(buffer) == capacity

    buffer.clear()

    # Test extend
    quarter_capacity = capacity // 4
    buffer.extend(list(range(quarter_capacity)))
    assert len(buffer) == quarter_capacity
    buffer.extend(np.zeros(quarter_capacity, dtype=np.int16))
    assert len(buffer) == 2 * quarter_capacity
    buffer.extend_unchecked(np.zeros(capacity, dtype=dtype))
    assert len(buffer) == capacity


@pytest.mark.parametrize("mode", MODES)
@pytest.mark.parametrize("dtype", SUPPORTED_DTYPES_ALL)
def test_indexing(mode, dtype):
    """Test indexing operations."""
    buffer = OverwriteRingBuffer(5, mode, dtype)

    # Add some data
    for i in range(5):
        buffer.append(i * 10)

    view = buffer.view()

    # Test positive indexing
    assert view[0] == 0
    assert view[1] == 10
    assert view[2] == 20
    assert view[3] == 30
    assert view[4] == 40

    # Test negative indexing
    assert view[-1] == 40
    assert view[-2] == 30
    assert view[-5] == 0

    # Test Iteration
    for i, x in enumerate(view):
        assert x == i * 10

    # Test out of bounds
    with pytest.raises(IndexOutOfBounds):
        _ = view[5]

    with pytest.raises(IndexOutOfBounds):
        _ = view[-6]


@pytest.mark.parametrize("dtype", SUPPORTED_DTYPES_ALL)
def test_overwrite_returns(dtype):
    """Test overwrite returns."""
    empty_expected = np.array([], dtype)

    # Test "never" policy

    buffer = OverwriteRingBuffer(5, "never", dtype)

    assert buffer.append(10) is None

    result = buffer.extend([20, 30, 40])
    expected = empty_expected
    assert np.array_equal(result, expected)

    result = buffer.extend([50, 60, 70])
    expected = empty_expected
    assert np.array_equal(result, expected)

    assert buffer.append(80) is None

    # Test "always" policy

    buffer = OverwriteRingBuffer(5, "always", dtype)

    assert buffer.append(10) is None

    result = buffer.extend([20, 30, 40])
    expected = empty_expected
    assert np.array_equal(result, expected)

    result = buffer.extend([50, 60, 70])
    expected = np.array([10, 20], dtype)
    assert np.array_equal(result, expected)

    assert buffer.append(70) == 30

    # Test "conditional" policy

    buffer = OverwriteRingBuffer(5, "conditional", dtype)

    assert buffer.append(10) is None

    result = buffer.extend([20, 30, 40])
    expected = empty_expected
    assert np.array_equal(result, expected)

    result = buffer.extend([50, 60, 70])
    expected = empty_expected
    assert np.array_equal(result, expected)

    result = buffer.extend([80, 90, 100], True)
    expected = np.array([30, 40, 50], dtype)
    assert np.array_equal(result, expected)

    assert buffer.append(110) is None
    assert buffer.append(120, True) == 70


@pytest.mark.parametrize("mode", MODES)
@pytest.mark.parametrize("fp_dtype", SUPPORTED_DTYPES_FP)
def test_clears(mode, fp_dtype):

    buf = OverwriteRingBuffer(7, mode, fp_dtype)
    buf.extend([10, float("inf"), 30, float("nan")])
    buf.append(float("inf"))
    buf.append(float("nan"))
    buf.append(70)

    # Test clear_nans

    result = buf.view()[:]
    expected = np.array(
        [10, float("inf"), 30, float("nan"), float("inf"), float("nan"), 70],
        fp_dtype,
    )
    assert np.array_equal(result, expected, equal_nan=True)

    buf.clear_nans()
    result = buf.view()[:]
    expected = np.array([10, float("inf"), 30, float("inf"), 70], fp_dtype)
    assert np.array_equal(result, expected)

    # Test clear

    buf.clear()
    assert len(buf) == 0
    result = buf.view()[:]
    expected = np.array([], fp_dtype)
    assert np.array_equal(result, expected)

    # Test clear_infs

    buf.extend(
        [10, float("inf"), 30, float("nan"), float("inf"), float("nan"), 70]
    )
    buf.clear_infs()
    result = buf.view()[:]
    expected = np.array([10, 30, float("nan"), float("nan"), 70], fp_dtype)
    assert np.array_equal(result, expected, equal_nan=True)


@pytest.mark.parametrize("mode", MODES)
@pytest.mark.parametrize("dtype", SUPPORTED_DTYPES_ALL)
def test_edge_cases(mode, dtype):
    """Test edge cases."""

    buffer = OverwriteRingBuffer(1, mode, dtype)

    with pytest.raises((ValueError, TypeError)):
        buffer.append("abc")

    with pytest.raises((ValueError, TypeError)):
        buffer.extend(["a", "b", "c"])

    with pytest.raises((ValueError, TypeError)):
        buffer.extend("abc")


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
