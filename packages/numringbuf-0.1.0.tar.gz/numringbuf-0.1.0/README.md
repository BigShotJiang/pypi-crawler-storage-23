# NumRingBuf: High-Performance Numerical Ring Buffers with O(1) Accumulators

[![PyPI version](https://badge.fury.io/py/NumRingBuf.svg)](https://badge.fury.io/py/NumRingBuf)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)
[![Python Version](https://img.shields.io/pypi/pyversions/NumRingBuf.svg)](https://pypi.org/project/NumRingBuf/)
[![Build Status](https://img.shields.io/github/actions/workflow/status/basimali-ai/NumRingBuf/build_wheels.yml)](https://github.com/basimali-ai/NumRingBuf/actions)

## Table of Contents

- [Overview](#overview)
- [Features](#features)
- [Installation](#installation)
- [Buffer Views](#buffer-views)
  - [1. RingView](#1-ringview)
- [Main Buffers](#main-buffers)
  - [1. OverwriteRingBuffer](#1-overwriteringbuffer)
  - [2. BlockingRingBuffer](#2-blockingringbuffer)
- [Utility Buffers](#utility-buffers)
  - [1. RunningMeanSqBuffer](#1-runningmeansqbuffer)
  - [2. RunningMeanBuffer](#2-runningmeanbuffer)
  - [3. IntegratedGatedBuffer](#3-integratedgatedbuffer)
- [Exception Handling](#exception-handling)
- [Performance](#performance)
- [Documentation](#documentation)
- [Changelog](#changelog)
- [License](#license)
- [Support](#support)
- [Citation](#citation)
- [Acknowledgements](#acknowledgements)

## Overview

NumRingBuf is a high-performance Python library for numerical ring buffers with extra utility buffers that support O(1) accumulator operations.
Built with Cython for a balance between performance and maintainability, it provides efficient data structures for real-time signal processing, time-series analysis, and other performance-critical applications.

## Features

- **Multiple Buffer Types** – includes specialized buffers for different needs:
  - **BlockingRingBuffer** – blocking producer/consumer ring buffer for multi-threaded applications.
  - **OverwriteRingBuffer** – optimized for high-throughput writes
  - **RunningMeanBuffer** – O(1) running mean calculations
  - **RunningMeanSqBuffer** – O(1) mean-square calculations (RMS, energy)
  - **IntegratedGatedBuffer** – O(1) calculations specialized for gated loudness/energy statistics
- **O(1) Accumulators**: Constant-time operations for mean, mean-square, and other accumulators.
- **NumPy Integration**: Seamless integration with NumPy arrays.
- **Type Safety**: supports fp32, fp64, int32, int64, uint32, uint64.
- **Comprehensive Documentation**: Detailed documentation and performance benchmarks.

## Installation

```bash
pip install numringbuf
```

Or install from source:

```bash
git clone https://github.com/basimali-ai/NumRingBuf.git
cd NumRingBuf
pip install .
```

For development installation with all dependencies (from source):

```bash
git clone https://github.com/basimali-ai/NumRingBuf.git
cd NumRingBuf
pip install -e .[dev]
```

### Quick Test

```bash
python -c "from numringbuf import OverwriteRingBuffer, RunningMeanBuffer; print(OverwriteRingBuffer(10, 'never')); print(RunningMeanBuffer(10, 'calculation'))"
```

## Buffer Views

### 1. RingView

Provides a zero-copy, read-only snapshot view of a ring buffer.
Behaves like a 1D NumPy array in logical order.
Has a `to_numpy()` function which provides a copy of the buffer in logical order.
**Note:** `RingView` is read-only. Any slicing produces a copy. Indexing or iteration preserves logical order but yields new Python objects for each element, not references to the underlying buffer.

#### Constructor

```python
def __init__(
    self,
    buffer: np.ndarray, # NumPy Array being used as the ring buffer.
    write_head: int, # The current position of the write head of the buffer.
    size: int, # Current size/len of the buffer.
    maxlen: int, # Maximum capacity / maxlen of the buffer.
    npy_typenum: int = -1, # NumPy C-API dtype integer (typenum),
                           # a helpful enum is provided with common typenums.
                           # If left as default, it will be automatically determined.
    buffer_ptr: int = 0, # Unsigned Integer Pointer of the buffer.
                         # If left as default, it will be automatically determined.
) -> None:
```

#### Usage Example

```python
import numpy as np
from numringbuf import RingView, constants

# Mock custom RingBuffer
maxlen = 10
dtype = np.float32
buffer = np.zeros(maxlen, dtype=dtype)
write_head = 0
size = 0
npy_typenum = constants.NpyTypenum.FLOAT32.value
buffer_ptr = buffer.ctypes.data

# Mock adding data
data = [1, 2, 3, 4]
n = len(data)
buffer[write_head:n] = [1, 2, 3, 4]
write_head += n
size += n

# Create a RingView
view = RingView(
    buffer=buffer,
    write_head=write_head,
    size=size,
    maxlen=maxlen,
    dtype=dtype,
    npy_typenum=npy_typenum,
    buffer_ptr=buffer_ptr,
)

print("All elements:", view[:])  # [1.0, 2.0, 3.0, 4.0]
print("Single element:", view[3])  # 4.0
print("Number of elements:", len(view))  # 4
print("Max capacity:", view.maxlen)  # 10
print("Dtype:", view.dtype)  # <class 'numpy.float32'>
print("Iterating over view:")
for value in view:
    print(value)  # 1.0
                  # 2.0
                  # 3.0
                  # 4.0

arr = view.to_numpy()
arr *= 2.0  # mock an operation
print(arr)  # [2.0, 4.0, 6.0, 8.0]
```

## Common Buffer API

All buffer types expose the following methods:

- `clear()`: Clears the buffer.
- `clear_nan()`: Removes NaN values.
- `clear_infs()`: Removes Inf values.
- `__len__()`: Current buffer size.
- `maxlen`: Maximum buffer capacity.
- `view()`: Returns a snapshot `RingView` object of the buffer.

All bulk `extend` methods have a `warn_size` boolean argument which enables or disables warnings when block size
exceeds buffer maxlen. It is enabled by default.

**Note**: In all buffers nan/inf values are allowed to be appended/extended with, as they are valuable data points.

## Main Buffers

### 1. OverwriteRingBuffer

Write-optimized circular buffer with auto-overwrite and non-destructive snapshot reads using RingView.

#### Constructor

```python
def __init__(
    self,
    maxlen: int,
    return_overwritten_policy: Literal["never", "always", "conditional"],
    dtype: (
        Type[np.float32]
        | Type[np.float64]
        | Type[np.int32]
        | Type[np.int64]
        | Type[np.uint32]
        | Type[np.uint64]
    ) = np.float32,
) -> None:
```

##### Overwrite Return Policy

Controls whether overwritten elements are returned when the buffer wraps.

`return_overwritten_policy: Literal["always", "never", "conditional"]`

_The returned values depend on the `return_overwritten_policy` and whether the buffer wraps._

- ###### `"never"`

  ```python
  from numringbuf import OverwriteRingBuffer
  buf = OverwriteRingBuffer(maxlen=3, return_overwritten_policy="never")
  print(buf.extend([1, 2]))  # Empty NumPy array []
  print(buf.extend([3, 4]))  # Empty NumPy array []
  print(buf.append(5))  # None
  ```

- ###### `"always"`

  ```python
  from numringbuf import OverwriteRingBuffer
  buf = OverwriteRingBuffer(maxlen=3, return_overwritten_policy="always")
  print(buf.extend([1, 2]))  # Empty NumPy array []
  print(buf.extend([3, 4]))  # NumPy array [1.0]
  print(buf.append(5))  # float 2.0
  ```

- ###### `"conditional"`

  > The returned values depend on the `return_overwritten` flag, it defaults to `False`.

  ```python
  from numringbuf import OverwriteRingBuffer
  buf = OverwriteRingBuffer(maxlen=3, return_overwritten_policy="conditional")
  print(buf.extend([1, 2]))  # Empty NumPy array []
  print(buf.extend([3, 4]))  # Empty NumPy array []
  print(buf.extend([5, 6], return_overwritten=True))  # NumPy array [2.0, 3.0]
  print(buf.append(7))  # None
  print(buf.append(8, return_overwritten=True))  # float 5.0
  ```

#### Supported input types

- ##### `.append(float | int)`
  - Accepts a single numeric value: `float` or `int`.
  - Value is stored internally as the buffer’s `dtype`.
- ##### `.extend(Iterable[float|int])`
  - Accepts any `Iterable` of numeric values (`float` or `int`).
  - The iterable is converted to a contiguous NumPy array of the buffer’s `dtype`.
  - If you pass a `np.ndarray`, it is only copied if its `dtype` does not match the buffer’s `dtype`, or if it is not C-contiguous.
- ##### `.extend_unchecked(np.ndarray[np.float32] | np.ndarray[np.float64])`
  - Expects only a C-contiguous 1-D `np.ndarray` with the same `dtype` as the buffer.
  - This method skips `dtype`, contiguous array and dimension conversions/checks.

  **Note**: Using this yields the best performance, but if the array's `dtype` is different or if it is not contiguous, it will cause silent data corruption or crashes.

#### Mathematical Metrics

These metrics are computed on all elements.

- `.mean()`: Mean of all elements.
- `.sum()`: Sum of all elements.
- `.sum_squares()`: Sum of squares.
- `.mean_squares()`: Mean of squares.
- `.sum_and_count_gt(threshold: float | int)`: Returns a sum and count of elements above a threshold.

### 2. BlockingRingBuffer

Blocking producer/consumer ring buffer, suitable for multi-threaded applications.

This buffer blocks under these conditions:

- The writer will wait if the buffer is full.
- The reader will wait if the buffer is empty.

#### Constructor

```python
def __init__(
    self,
    maxlen: int,
    dtype: (
        Type[np.float32]
        | Type[np.float64]
        | Type[np.int32]
        | Type[np.int64]
        | Type[np.uint32]
        | Type[np.uint64]
    ) = np.float32,
) -> None:
```

#### Writing to the buffer

- ##### `.write_append(value: float | int, timeout: float = -1.0)`
  - Accepts a single numeric value: `float` or `int`.
  - Value is stored internally as the buffer’s `dtype` (`np.float32` or `np.float64`).
  - `timeout`: Time in seconds to wait if the buffer is full.
    - Default `-1.0`, waits indefinitely. To make it non-blocking, use `0.0`.
- ##### `.write_extend(data: Iterable[float|int], timeout: float = -1.0, warn_size: bool = True)`
  - `data`: Data block to write.
    - Accepts any `Iterable` of numeric values (`float` or `int`).
    - The iterable is converted to a contiguous NumPy array of the buffer’s `dtype`.
    - If you pass a `np.ndarray`, it is only copied if its `dtype` does not match the buffer’s `dtype`, or if it is not C-contiguous.
  - `timeout`: Same as `.write_append`
  - `warn_size`: If you want to receive warnings when block size exceeds buffer maxlen.
- ##### `.write_extend_unchecked(block_np: np.ndarray, timeout: float = -1.0, warn_size: bool = True)`
  - `block_np`: `np.ndarray` to write.
    - Expects only a C-contiguous 1-D `np.ndarray` with the same `dtype` as the buffer.
    - This method skips `dtype`, contiguous array and dimension conversions/checks.
  - `timeout`: Same as `.write_append`
  - `warn_size`: Same as `.write_extend`

  **Note**: Using this yields the best performance, but if the array's `dtype` is different or if it is not contiguous, it will cause silent data corruption or crashes.

#### Reading from the buffer

- ##### `.read(max_items: int = sys.maxsize, timeout: float = -1.0) -> np.ndarray`

  Reads items from the buffer.
  - `max_items`: Maximum number of items to read.
    - Defaults to the `sys.maxsize`, effectively reading all items currently in the buffer.
  - `timeout`: Time in seconds to wait if the buffer is empty.
    - Default `-1.0`, waits indefinitely. To make it non-blocking, use `0.0`.

- ##### `.read_into(out_array_np: np.ndarray, timeout: float = -1.0) -> int`

  Reads directly into a pre-allocated `np.ndarray` of the same `dtype` as the buffer.
  - Returns the number of items actually read.
  - Reads up to `len(out_array_np)` items.
  - Supports the `timeout` parameter just like `.read()`.

- ##### `.read_into_unchecked(out_array_np: np.ndarray, timeout: float = -1.0) -> int`

  Similar to `.read_into`
  - This method skips `dtype`, contiguous array and dimension conversions/checks.

  **Note**: Using this yields the best performance, but if the array's `dtype` is different or if it is not contiguous, it will cause silent data corruption or crashes.

#### Usage Example

```python
import threading
import numpy as np
from numringbuf import BlockingRingBuffer

buf = BlockingRingBuffer(maxlen=1000, dtype=np.float32)
data = np.random.randn(1000).astype(np.float32)

# Pre-allocate a NumPy array with zeros for read_into.
# We use zeros instead of np.empty so that any unwritten elements are clearly visible
# — useful when inspecting random data.
read_into_arr = np.zeros(100, dtype=np.float32)


def producer():
    # Write all data into the buffer
    buf.write_extend_unchecked(data)


def consumer():
    print(f"\n- Initial items in buffer: {len(buf)}\n")  # 1000

    # Read up to 200 items
    received = buf.read(max_items=200)
    print(f"1A. Read items: {len(received)}")  # 200
    print(f"1B. Current items in buffer: {len(buf)}\n")  # 800

    # Read directly into the pre-allocated array
    received_count = buf.read_into_unchecked(out_array_np=read_into_arr)
    received = read_into_arr[:received_count]
    print(f"2A. Read items: {len(received)}")  # 100
    print(f"2B. Current items in buffer: {len(buf)}\n")  # 700

    # Read remaining items
    received = buf.read()
    print(f"3A. Read items: {len(received)}")  # 700
    print(f"3B. Current items in buffer: {len(buf)}\n")  # 0

    # Non-blocking read: buffer is empty, returns immediately
    received = buf.read(timeout=0)
    print(f"4A. Read items: {len(received)}")  # 0
    print(f"4B. Current items in buffer: {len(buf)}\n")  # 0

    # Non-blocking read_into: buffer is empty, returns immediately
    received_count = buf.read_into_unchecked(
        out_array_np=read_into_arr, timeout=0
    )
    received = read_into_arr[:received_count]
    print(f"5A. Read items: {len(received)}")  # 0
    print(f"5B. Current items in buffer: {len(buf)}")  # 0


# Start producer and consumer threads
producer_thread = threading.Thread(target=producer)
consumer_thread = threading.Thread(target=consumer)

producer_thread.start()
consumer_thread.start()

producer_thread.join()
consumer_thread.join()
```

## Utility Buffers

### Common Utility Buffer API

All utility buffer types expose the methods defined in [Common Buffer API](#common-buffer-api), and the following:

- `clear_cache()`: Clears the cached metric.

### 1. RunningMeanSqBuffer

Optimized for mean-square calculations (useful for RMS/energy calculations).

Caches the mean-square value every .mean_square and, Automatically clears cached value when doing extend/append.

#### Constructor

```python
def __init__(
    self,
    maxlen: int,
    operation_focus: Literal["extend/append", "calculation"],
    recalc_threshold: int | None = 0,
    dtype: Type[np.float32] | Type[np.float64] = np.float32,
) -> None:
```

##### Operation Focus

`operation_focus: Literal["calculation", "extend/append"]`

- **`"calculation"`: O(1) statistics, higher per-write cost.**

- **`"extend/append"`: O(n) statistics, lower write cost.**

Use the provided utility `determine_operation_focus` function if possible,
this runs a small benchmark at runtime to determine which `operation_focus` to use:

```python
def determine_operation_focus(
    buffer_type: Type[RunningMeanSqBuffer] | Type[RunningMeanBuffer],
    dtype: Type[np.float32] | Type[np.float64],
    buffer_maxlen: int,
    block_size: int, # Use 1 if you will be appending a single element only.
    calc_every: int, # Calculate every n blocks.
    test_blocks: int = 128, # How many blocks to run the benchmark for,
                            # more = (higher memory usage)
                            # + (potentially more accurate results).
    verbose: bool = False, # Logs the exact relative multipliers,
                           # as well as total time spent in the function.
) -> Literal["calculation", "extend/append"]: # Outputs the best operation focus
                                              # for this (use case) + (system),
                                              # This can be directly passed to
                                              # the buffer init
```

Actual performance depends on buffer size, block size, overwrite rate,
and statistics frequency. See [PERFORMANCE.md](docs/PERFORMANCE.md) for relative benchmarks.

##### Recalculation Threshold

`recalc_threshold: int`: Recalculate the sum square from scratch every N operations to prevent float precision drift. 0 or None means no threshold/off.

#### Usage Example

```python
import numpy as np
from numringbuf import RunningMeanSqBuffer, determine_operation_focus

DTYPE = np.float32
CALC_EVERY = 2
BUFFER_MAXLEN = 1000
BLOCK_SIZE = 100

buffer = RunningMeanSqBuffer(
    maxlen=BUFFER_MAXLEN,
    operation_focus=determine_operation_focus(
        buffer_type=RunningMeanSqBuffer,
        dtype=DTYPE,
        buffer_maxlen=BUFFER_MAXLEN,
        block_size=BLOCK_SIZE,
        calc_every=CALC_EVERY,
        verbose=True,
    ),
    dtype=DTYPE,
)

# Add arrays/blocks
rng = np.random.default_rng(25)  # For random number generation
for i in range(10):  # Simulate time
    block = rng.random(BLOCK_SIZE, dtype=DTYPE)  # Mock block arriving
    buffer.extend(block)  # Extend with the block
    if i % CALC_EVERY:  # Calc every n
        print("-" * 10)
        print(buffer.mean_square())  # Get mean-square
        print(buffer.mean_square())  # Uses cached value
```

### 2. RunningMeanBuffer

Optimized for calculating running means.

Caches the mean value every .mean and, Automatically clears cached value when doing extend/append.

#### Constructor

```python
def __init__(
    self,
    maxlen: int,
    operation_focus: Literal["extend/append", "calculation"],
    dtype: Type[np.float32] | Type[np.float64] = np.float32,
) -> None:
```

`operation_focus` works the same as in [RunningMeanSqBuffer](#operation-focus).

#### Usage Example

Works identically to [RunningMeanSqBuffer](#usage-example-2) — use `.mean()` instead of `.mean_square()`

### 3. IntegratedGatedBuffer

Specialized buffer for gated loudness calculations. Expects to receive squared values.

#### Flexibility Note:

IntegratedGatedBuffer operates on numeric inputs in the linear domain.
While it’s typically used with pre-squared (mean-square) values for
gated loudness/energy calculations, the buffer can accept any numeric
values.

- When feeding pre-squared inputs, `gated_mean_square()` computes the
  standard gated mean-square.
- When feeding raw (unsquared) values, the same thresholds (`abs_gate_lin_sq`
  and `rel_gate_lin_sq_factor`) are applied, effectively producing a
  gated mean. The thresholds are applied exactly as provided; no internal
  squaring or manipulation is performed.

This allows the buffer to work with both standard mean-square calculations and custom statistics.

#### Constructor

```python
def __init__(
    self,
    maxlen: int,
    abs_gate_lin_sq: float,
    rel_gate_lin_sq_factor: float,
    recalc_threshold: int | None = 0,
    dtype: Type[np.float32] | Type[np.float64] = np.float32,
) -> None:
```

`recalc_threshold` works the same as in [RunningMeanSqBuffer](#recalculation-threshold).

##### Linear Square Parameters

- **`abs_gate_lin_sq: float`**
  `10**((ABS_GATE_LUFS - REFERENCE_OFFSET) / 10.0)`
- **`rel_gate_lin_sq_factor: float`**
  `10**(REL_GATE_LU / 10.0)`

#### Usage Example

```python
import numpy as np
from numringbuf import IntegratedGatedBuffer

# Parameters for gated loudness calculation
ABS_GATE_LUFS = -70.0
REL_GATE_LU = -10.0
REFERENCE_OFFSET = 0.691  # Example reference

# Calculate Linear Square Parameters
abs_gate_lin_sq = 10**((ABS_GATE_LUFS - REFERENCE_OFFSET) / 10.0)
rel_gate_lin_sq_factor = 10**(REL_GATE_LU / 10.0)

buffer = IntegratedGatedBuffer(
    maxlen=3000,
    abs_gate_lin_sq=abs_gate_lin_sq,
    rel_gate_lin_sq_factor=rel_gate_lin_sq_factor
)

# Add linear mean-square values
sq_values = np.random.uniform(0.0001, 0.1, 1000)  # Mock pre-squared inputs
buffer.extend(sq_values)

# Get gated mean square
gated_mean_sq = buffer.gated_mean_square()
print(f"Gated mean square: {gated_mean_sq}")
```

## Exception Handling

### Exceptions

```text
NumRingBufError(Exception)
├── NumRingBufValueError(NumRingBufError, ValueError) ────────────────────────────┬─────┐
├── NumRingBufTypeError(NumRingBufError, TypeError) ─────────────┬─────────────┬─ │ ─┐  │
│   └── InvalidModification(NumRingBufTypeError)                 │             │  │  │  │
├── NumRingBufIndexError(NumRingBufError, IndexError)            │             │  │  │  │
│   └── IndexOutOfBounds(NumRingBufIndexError)                   │             │  │  │  │
├── NumRingBufArithmeticError(NumRingBufError, ArithmeticError)  │             │  │  │  │
│   └── UnsupportedOperation(NumRingBufArithmeticError)          │             │  │  │  │
└── NumRingBufInitError(NumRingBufError)                         │             │  │  │  │
    ├── DataTypeError(NumRingBufInitError, NumRingBufTypeError) ─┘             │  │  │  │
    ├── BufferCapacityError(NumRingBufInitError)                               │  │  │  │
    │   ├── BufferCapacityTypeError(BufferCapacityError, NumRingBufTypeError) ─┘  │  │  │
    │   └── BufferCapacityValueError(BufferCapacityError, NumRingBufValueError) ──┘  │  │
    └── ConfigurationError(NumRingBufInitError)                                      │  │
        ├── ConfigurationTypeError(ConfigurationError, NumRingBufTypeError) ─────────┘  │
        └── ConfigurationValueError(ConfigurationError, NumRingBufValueError) ──────────┘
```

> NumRingBuf exceptions are comprehensive and include context (e.g., the object/class that caused the error):
>
> - `class_obj` – the class where the exception occurred (always present).
> - `obj` – the instance that caused the error (may be `None` if instantiation failed).
> - Various different attributes available based on the exception type.
>
> **Performance note:**
> Some low-level Cython/NumPy errors may still propagate as native Python exceptions (`ValueError`, `TypeError`, etc.) to avoid redundant checks in performance-critical code.

#### Usage Example

```python
try:
    buf.extend(data)
except exceptions.NumRingBufError as e:
    # Structured library errors; you can access `e.class_obj` and `e.obj`
    handle_numringbuf_error(e)
except Exception as e:
    # Low-level errors from NumPy/Cython
    handle_low_level_error(e)
```

### Warnings

```text
NumRingBufWarning(Warning)
├── NumRingBufDeprecationWarning(NumRingBufWarning, DeprecationWarning)
├── NumRingBufFutureWarning(NumRingBufWarning, FutureWarning)
└── NumRingBufRuntimeWarning(NumRingBufWarning, RuntimeWarning)
    └── DataSizeWarning(NumRingBufRuntimeWarning)
```

> All NumRingBuf warnings include `class_obj` and `obj` attributes (like exceptions).

#### Usage Example

```python
import warnings
from numringbuf import OverwriteRingBuffer, exceptions

buffer = OverwriteRingBuffer(5, "never")


# Example function that catches a NumRingBufWarning
def extend_and_catch(buffer, data):
    with warnings.catch_warnings(record=True) as caught_warnings:
        warnings.simplefilter("always")  # Capture all warnings
        buffer.extend(data)
        for w in caught_warnings:
            if isinstance(w.message, exceptions.NumRingBufWarning):
                print("Warning type:", type(w.message))
                print("Class of buffer:", w.message.class_obj)
                print("Buffer instance:", w.message.obj)
                print("Full message:", w.message)


# Trigger a warning
extend_and_catch(buffer, range(10))
```

## Performance

NumRingBuf is optimized for speed and efficiency:

- **Cython + raw C pointers** – for near-C performance
- **Minimal Python object creation** – slices/views reused, caching reduces repeated calculations
- **BLAS-backed NumPy operations** – for efficient array math (dot products, sum-of-squares)
- **O(1) accumulator operations** – for real-time applications
- **Handles high-throughput buffers** – for streaming data like audio or sensor signals

### Benchmark Results

For detailed performance benchmarks, see our [PERFORMANCE.md](docs/PERFORMANCE.md) document which includes comprehensive testing results across different buffer types and use cases.

**Key Performance Highlights:**

- **Throughput** (extending 64 KiB of data to `OverwriteRingBuffer`):
  - **Cold cache (data)**:
    - AMD R7700x (DDR5): ~50 GB/s
    - AMD R5600 (DDR4): ~30 GB/s

  - **Warm cache (data)**:
    - AMD R7700x (DDR5): ~73 GB/s
    - AMD R5600 (DDR4): ~50 GB/s

- **Memory efficiency and consistency**: ~4 bytes per element (32-bit) and ~8 bytes per element (64-bit)

## Documentation

Comprehensive documentation is available:

- **[Performance Benchmarks](docs/PERFORMANCE.md)**: Comprehensive performance testing results and optimization guide.
- **[Versioning Strategy](docs/VERSIONING.md)**: Versioning policy, release process, and compatibility guarantees.

## Changelog

See [CHANGELOG.md](docs/CHANGELOG.md) for a detailed history of changes, including new features, bug fixes, and performance improvements.

## License

This project is licensed under the Apache License 2.0 - see the [LICENSE](LICENSE) file for details.

## Support

For issues, questions, or feature requests:

- **GitHub Issues**: Open an issue on our [GitHub repository](https://github.com/basimali-ai/NumRingBuf/issues)
- **GitHub Discussions**: Join the conversation in our [Discussions forum](https://github.com/basimali-ai/NumRingBuf/discussions)

## Citation

If you use NumRingBuf in your research or projects, please cite it as:

```bibtex
@software{numringbuf,
  author = {Syed Basim Ali},
  title = {NumRingBuf: High-Performance Numerical Ring Buffers},
  year = {2026},
  url = {https://github.com/basimali-ai/NumRingBuf},
  version = {0.1.0}
}
```

## Acknowledgements

NumRingBuf is built on top of these technologies:

- **[Cython](https://cython.org/)** for performance optimization
- **[NumPy](https://numpy.org/)** for numerical computing and integration
