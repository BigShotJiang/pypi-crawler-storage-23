Show elaborations information and filters in the weighing assistant.
