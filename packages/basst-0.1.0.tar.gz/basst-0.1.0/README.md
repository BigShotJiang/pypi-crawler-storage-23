# Hypex (working name)

Pydantic-first HTTP testing client for Python. Fluent request builder, one-step model binding, native Python assertions.

## Install

```bash
pip install hypex
```

## Quick Start

```python
from hypex import Client, matchers
from pydantic import BaseModel


class Address(BaseModel):
    city: str
    zip: str


class User(BaseModel):
    id: int
    name: str
    email: str
    age: int | None
    roles: list[str]
    address: Address


api = Client("https://api.example.com")

user = (
    api.get(f"/users/{user_id}")
    .header("X-Token", "secret")
    .expect()
    .status(200)
    .header("content-type", matchers.contains("json"))
    .model(User)
)

assert user.name == "Ada"
assert "@" in user.email
assert "admin" in user.roles
assert user.address.city == "Paris"
```

## Request Building

```python
api = Client(
    "https://api.example.com",
    headers={"X-Token": "secret"},
    auth=("user", "pass"),
    timeout=5.0,
)

# Builder methods are chainable
resp = (
    api.post("/users")
    .json({"name": "Ada", "email": "ada@example.com"})
    .header("X-Request-Id", "abc123")
    .timeout(10.0)
    .expect()
)

user = resp.status(201).model(User)
assert user.name == "Ada"
```

## Collections

```python
users = (
    api.get("/users")
    .query(page=1, limit=10)
    .expect()
    .status(200)
    .model_list(User)
)

assert len(users) > 0
assert users[0].name == "Ada"
```

## Response Assertions

Assertion methods are chainable and raise on failure:

```python
from hypex import matchers

resp = api.get(f"/users/{user_id}").expect()

# Chain status and header assertions, then bind model
user = (
    resp
    .status(200)
    .header("content-type", matchers.contains("json"))
    .header("x-request-id")  # no matcher — just asserts the header exists
    .model(User)
)
```

## Matchers

The `matchers` module provides built-in assertion functions for header values:

```python
from hypex import matchers

matchers.equals("application/json")
matchers.contains("json")
matchers.starts_with("application/")
matchers.ends_with("+json")
matchers.matches(r"^application/(json|.+\+json)$")  # regex
```

A matcher is any callable `(str) -> None` that raises `AssertionError` on failure.
Write your own for reusable, domain-specific checks:

```python
import uuid

def is_uuid(value: str) -> None:
    try:
        uuid.UUID(value)
    except ValueError:
        raise AssertionError(f"Expected UUID, got: {value}")

resp.header("x-request-id", is_uuid)
```

## Raw Response Access

Accessor methods return values for use in plain Python:

```python
resp = api.get("/health").expect()

# Raw values
code = resp.status_code
content_type = resp.get_header("content-type")
all_headers = resp.get_headers()
data = resp.json()
text = resp.text
```

## Content-Type Validation

Model binding validates the response content-type before parsing. By default,
`application/json` and any `+json` suffix are accepted.

```python
# Default: accepts application/json, application/problem+json,
# application/vnd.api+json, etc.
user = resp.model(User)

# Prefix match: assert it's specifically application/problem+json
problem = resp.model(ProblemDetail, content_type="problem")

# Exact match: full MIME type
data = resp.model(MyModel, content_type="application/vnd.api+json")

# Skip content-type validation entirely
data = resp.model(MyModel, content_type=None)
```

## Async

```python
from hypex import AsyncClient

aapi = AsyncClient("https://api.example.com")

# await at .expect() — everything after is synchronous
resp = await aapi.get(f"/users/{user_id}").expect()
user = resp.status(200).model(User)
assert user.name == "Ada"
```

## Context Managers

```python
# Sync
with Client("https://api.example.com") as api:
    user = api.get(f"/users/{user_id}").expect().status(200).model(User)

# Async
async with AsyncClient("https://api.example.com") as api:
    resp = await api.get(f"/users/{user_id}").expect()
    user = resp.status(200).model(User)
```

## Error Messages

When things fail, hypex provides context about the request and response:

```
hypex.StatusError: Expected status 200, got 404
  GET https://api.example.com/users/999
  Response body: {"detail": "Not found"}

hypex.HeaderError: Header "x-cache" expected to equal "HIT", got "MISS"
  GET https://api.example.com/users/1

hypex.ContentTypeError: Expected JSON-compatible content-type, got text/html
  GET https://api.example.com/users/1
  Response body: <html>...

hypex.ModelError: Failed to validate response as User
  GET https://api.example.com/users/1
  Response body: {"id": "not-an-int", "name": "Ada", ...}
  Validation errors:
    id: Input should be a valid integer [type=int_parsing]
```

## Design Principles

- Pydantic models are the primary response surface.
- `model()` and `model_list()` return real model instances, not proxies.
- Use native Python assertions on model fields.
- No custom assertion DSL, no JSONPath, no string selectors.
- The async boundary is only at `.expect()` — everything after is synchronous.
- Client is reusable — each verb call creates a fresh request builder.
