"""Request builder for constructing and firing HTTP requests."""

from __future__ import annotations

from enum import Enum, StrEnum
from typing import Any, Self

import httpx

from basst._sentinel import _Unset, _UNSET
from basst.response import Response

HeaderTypes = httpx.Headers | dict[str, str] | list[tuple[str, str]]
"""Type alias for accepted header input formats.

Mirrors httpx's internal ``HeaderTypes``. Accepts ``httpx.Headers``,
a ``dict[str, str]``, or a ``list[tuple[str, str]]`` (for multi-value
headers).
"""


class Method(StrEnum):
    """HTTP methods supported by the request builder.

    Inherits from ``str`` so values pass directly to httpx without
    conversion.
    """

    GET = "GET"
    POST = "POST"
    PUT = "PUT"
    PATCH = "PATCH"
    DELETE = "DELETE"
    HEAD = "HEAD"
    OPTIONS = "OPTIONS"


class RequestBuilder:
    """Fluent builder for a single HTTP request.

    Created by Client verb methods. All builder methods return ``self``
    for chaining. Call :meth:`expect` to fire the request and get a
    :class:`~basst.response.Response`.

    The builder only tracks per-request overrides. The underlying
    ``httpx.Client`` holds base configuration (base_url, headers, auth,
    timeout) and httpx merges them automatically.

    Args:
        client: The httpx.Client to send the request through.
        method: The HTTP method.
        path: The URL path (relative to the client's base_url).
    """

    def __init__(
        self,
        *,
        client: httpx.Client,
        method: Method,
        path: str,
    ) -> None:
        self._client = client
        self._method = method
        self._path = path
        self._headers = httpx.Headers()
        self._params: dict[str, str | int | float | bool] = {}
        self._cookies: dict[str, str] = {}
        self._json: Any = None
        self._data: dict[str, Any] | None = None
        self._auth: tuple[str, str] | httpx.Auth | None | _Unset = _UNSET
        self._timeout: float | None | _Unset = _UNSET

    # -- Builder methods (all return self for chaining) --

    def header(self, name: str, value: str) -> Self:
        """Add a single header to the request.

        Args:
            name: Header name (case-insensitive).
            value: Header value.

        Returns:
            self, for chaining.
        """
        self._headers[name] = value
        return self

    def headers(self, headers: HeaderTypes) -> Self:
        """Add multiple headers to the request.

        Args:
            headers: Headers as ``httpx.Headers``, a ``dict``, or a
                list of ``(name, value)`` tuples (for multi-value
                headers).

        Returns:
            self, for chaining.
        """
        self._headers.update(headers)
        return self

    def query(self, **params: str | int | float | bool) -> Self:
        """Add query parameters to the request URL.

        Args:
            **params: Query parameter names and values.

        Returns:
            self, for chaining.
        """
        self._params.update(params)
        return self

    def cookie(self, name: str, value: str) -> Self:
        """Add a cookie to the request.

        Cookies are sent via the ``Cookie`` header.

        Args:
            name: Cookie name.
            value: Cookie value.

        Returns:
            self, for chaining.
        """
        self._cookies[name] = value
        return self

    def json(self, data: Any) -> Self:
        """Set the JSON request body.

        Args:
            data: Any JSON-serialisable value. Must not be ``None``
                (use a different body method or omit the call instead).

        Returns:
            self, for chaining.
        """
        self._json = data
        return self

    def data(self, data: dict[str, Any]) -> Self:
        """Set form-encoded request body.

        Args:
            data: Form field names and values.

        Returns:
            self, for chaining.
        """
        self._data = data
        return self

    def auth(self, auth: tuple[str, str] | httpx.Auth | None) -> Self:
        """Set authentication for this request.

        Overrides any client-level auth. Pass ``None`` to explicitly
        disable authentication for this request.

        Args:
            auth: A ``(username, password)`` tuple, an ``httpx.Auth``
                instance, or ``None`` to disable.

        Returns:
            self, for chaining.
        """
        self._auth = auth
        return self

    def timeout(self, seconds: float | None) -> Self:
        """Set timeout for this request.

        Overrides any client-level timeout. Pass ``None`` to disable
        the timeout entirely (wait forever).

        Args:
            seconds: Timeout in seconds, or ``None`` to disable.

        Returns:
            self, for chaining.
        """
        self._timeout = seconds
        return self

    # -- Terminal method --

    def expect(self) -> Response:
        """Fire the HTTP request and return a Response.

        Passes only the builder's accumulated overrides to
        ``httpx.Client.request()``. httpx merges them with any
        client-level defaults (base_url, headers, auth, timeout).

        Returns:
            A :class:`~basst.response.Response` wrapping the
            httpx response.
        """
        kwargs: dict[str, Any] = {}

        # Merge cookies into headers (per-request cookies= is deprecated
        # in httpx 0.28+).
        if self._cookies:
            cookie_str = "; ".join(
                f"{name}={value}" for name, value in self._cookies.items()
            )
            self._headers["cookie"] = cookie_str

        if self._headers:
            kwargs["headers"] = self._headers
        if self._params:
            kwargs["params"] = self._params
        if self._json is not None:
            kwargs["json"] = self._json
        if self._data is not None:
            kwargs["data"] = self._data
        if self._auth is not _UNSET:
            kwargs["auth"] = self._auth
        if self._timeout is not _UNSET:
            kwargs["timeout"] = self._timeout

        raw_response = self._client.request(
            self._method,
            self._path,
            **kwargs,
        )
        return Response(raw_response)
