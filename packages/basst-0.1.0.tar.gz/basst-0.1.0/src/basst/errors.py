"""Error classes for basst."""


def _truncate(body: str, max_len: int = 200) -> str:
    """Truncate a body string, appending '...' if it exceeds max_len."""
    if len(body) <= max_len:
        return body
    return body[:max_len] + "..."


class BasstError(Exception):
    """Base error for all basst errors."""


class StatusError(BasstError):
    """Raised when the response status code does not match the expected value."""

    def __init__(
        self,
        *,
        expected: int,
        actual: int,
        method: str,
        url: str,
        body: str,
    ) -> None:
        self.expected = expected
        self.actual = actual
        self.method = method
        self.url = url
        self.body = body
        super().__init__(str(self))

    def __str__(self) -> str:
        return (
            f"Expected status {self.expected}, got {self.actual}\n"
            f"  {self.method} {self.url}\n"
            f"  Response body: {_truncate(self.body)}"
        )


class HeaderError(BasstError):
    """Raised when a header assertion fails."""

    def __init__(
        self,
        *,
        name: str,
        method: str,
        url: str,
        message: str | None = None,
    ) -> None:
        self.name = name
        self.method = method
        self.url = url
        self.message = message
        super().__init__(str(self))

    def __str__(self) -> str:
        if self.message is None:
            headline = f'Header "{self.name}" not found'
        else:
            headline = f'Header "{self.name}" {self.message}'
        return f"{headline}\n  {self.method} {self.url}"


class ContentTypeError(BasstError):
    """Raised when the response content-type does not match the expected value."""

    def __init__(
        self,
        *,
        expected: str,
        actual: str,
        method: str,
        url: str,
        body: str,
    ) -> None:
        self.expected = expected
        self.actual = actual
        self.method = method
        self.url = url
        self.body = body
        super().__init__(str(self))

    def __str__(self) -> str:
        return (
            f"Expected content-type {self.expected}, got {self.actual}\n"
            f"  {self.method} {self.url}\n"
            f"  Response body: {_truncate(self.body)}"
        )


class ModelError(BasstError):
    """Raised when pydantic model validation fails."""

    def __init__(
        self,
        *,
        model_name: str,
        errors: str,
        method: str,
        url: str,
        body: str,
    ) -> None:
        self.model_name = model_name
        self.errors = errors
        self.method = method
        self.url = url
        self.body = body
        super().__init__(str(self))

    def __str__(self) -> str:
        return (
            f"Failed to validate response as {self.model_name}\n"
            f"  {self.method} {self.url}\n"
            f"  Validation errors:\n"
            f"    {self.errors}\n"
            f"  Response body: {_truncate(self.body)}"
        )


class JsonError(BasstError):
    """Raised when the response body cannot be parsed as JSON."""

    def __init__(
        self,
        *,
        method: str,
        url: str,
        body: str,
        detail: str,
    ) -> None:
        self.method = method
        self.url = url
        self.body = body
        self.detail = detail
        super().__init__(str(self))

    def __str__(self) -> str:
        return (
            f"Failed to parse response body as JSON\n"
            f"  {self.method} {self.url}\n"
            f"  Parse error: {self.detail}\n"
            f"  Response body: {_truncate(self.body)}"
        )
