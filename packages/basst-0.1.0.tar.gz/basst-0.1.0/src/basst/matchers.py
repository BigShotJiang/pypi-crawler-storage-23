"""Matchers for header value assertions.

Matchers are callables with the signature ``(str) -> None``. They raise
``AssertionError`` on failure and return ``None`` on success.
"""

import re
from collections.abc import Callable

Matcher = Callable[[str], None]
"""A callable that validates a string value.

Takes a single string argument and returns ``None`` on success.
Raises ``AssertionError`` with a descriptive message on failure.
"""


def equals(expected: str) -> Matcher:
    """Create a matcher that asserts exact string equality.

    Args:
        expected: The expected string value.

    Returns:
        A matcher that raises ``AssertionError`` if the value does not
        equal ``expected``.
    """

    def _check(value: str) -> None:
        if value != expected:
            raise AssertionError(f'expected "{value}" to equal "{expected}"')

    return _check


def contains(substring: str) -> Matcher:
    """Create a matcher that asserts a substring is present.

    Args:
        substring: The substring to search for.

    Returns:
        A matcher that raises ``AssertionError`` if ``substring`` is
        not found in the value.
    """

    def _check(value: str) -> None:
        if substring not in value:
            raise AssertionError(f'expected "{value}" to contain "{substring}"')

    return _check


def starts_with(prefix: str) -> Matcher:
    """Create a matcher that asserts a string prefix.

    Args:
        prefix: The expected prefix.

    Returns:
        A matcher that raises ``AssertionError`` if the value does not
        start with ``prefix``.
    """

    def _check(value: str) -> None:
        if not value.startswith(prefix):
            raise AssertionError(f'expected "{value}" to start with "{prefix}"')

    return _check


def ends_with(suffix: str) -> Matcher:
    """Create a matcher that asserts a string suffix.

    Args:
        suffix: The expected suffix.

    Returns:
        A matcher that raises ``AssertionError`` if the value does not
        end with ``suffix``.
    """

    def _check(value: str) -> None:
        if not value.endswith(suffix):
            raise AssertionError(f'expected "{value}" to end with "{suffix}"')

    return _check


def matches(pattern: str) -> Matcher:
    """Create a matcher that asserts a regex pattern match.

    Uses ``re.search``, so the pattern can match anywhere in the value.
    Anchor with ``^`` and ``$`` for a full match.

    Args:
        pattern: A regular expression pattern.

    Returns:
        A matcher that raises ``AssertionError`` if the pattern is not
        found in the value.
    """
    compiled = re.compile(pattern)

    def _check(value: str) -> None:
        if not compiled.search(value):
            raise AssertionError(f'expected "{value}" to match pattern "{pattern}"')

    return _check
