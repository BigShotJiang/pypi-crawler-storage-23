"""Sentinel value to distinguish 'not provided' from ``None``."""

from __future__ import annotations

from enum import Enum


class _Unset(Enum):
    """Sentinel to distinguish 'not set' from ``None``."""

    token = 0


_UNSET = _Unset.token
