"""Response wrapper with accessor methods and assertions."""

from __future__ import annotations

from typing import Any, TypeVar

import httpx
from pydantic import BaseModel, TypeAdapter, ValidationError

from basst._sentinel import _Unset, _UNSET
from basst.errors import (
    ContentTypeError,
    HeaderError,
    JsonError,
    ModelError,
    StatusError,
)
from basst.matchers import Matcher

T = TypeVar("T", bound=BaseModel)


class Response:
    """Wraps an httpx.Response with accessor methods and assertions.

    Assertion methods are chainable (return self) and raise on failure.
    Accessor methods return values.

    Args:
        response: The underlying httpx.Response to wrap.
    """

    def __init__(self, response: httpx.Response) -> None:
        self._response = response

    @property
    def _method(self) -> str:
        """HTTP method from the original request."""
        return self._response.request.method

    @property
    def _url(self) -> str:
        """URL from the original request."""
        return str(self._response.request.url)

    # -- Assertion methods (chainable) --

    def status(self, code: int) -> Response:
        """Assert that the response status code matches the expected value.

        Args:
            code: The expected HTTP status code.

        Returns:
            self, for chaining.

        Raises:
            StatusError: If the actual status code does not match.
        """
        if self._response.status_code != code:
            raise StatusError(
                expected=code,
                actual=self._response.status_code,
                method=self._method,
                url=self._url,
                body=self.text,
            )
        return self

    def header(self, name: str, matcher: Matcher | None = None) -> Response:
        """Assert that a response header exists and optionally matches a value.

        When called with just a name, asserts the header is present. When a
        matcher is also provided, asserts the header exists **and** the matcher
        passes against the header value.

        Args:
            name: The header name (case-insensitive).
            matcher: Optional matcher to validate the header value.

        Returns:
            self, for chaining.

        Raises:
            HeaderError: If the header is missing or the matcher fails.
        """
        value = self._response.headers.get(name)
        if value is None:
            raise HeaderError(
                name=name,
                method=self._method,
                url=self._url,
            )
        if matcher is None:
            return self
        try:
            matcher(value)
        except AssertionError as exc:
            raise HeaderError(
                name=name,
                method=self._method,
                url=self._url,
                message=str(exc),
            ) from None
        return self

    # -- Model binding --

    def model(
        self, model_type: type[T], *, content_type: str | None | _Unset = _UNSET
    ) -> T:
        """Validate the response body against a Pydantic model.

        Validates the response content-type, parses the JSON body, and
        returns a model instance. Content-type parameters in the response
        (e.g. ``charset=utf-8``) are always ignored during comparison.

        Args:
            model_type: The Pydantic model class to validate against.
            content_type: Controls content-type validation. Must not
                contain parameters (no ``;``). Not provided (default):
                accepts ``application/json`` or any ``+json`` suffix.
                ``None``: skips validation. Contains ``/``: exact media
                type match. Otherwise: treated as a prefix matching
                ``application/{value}+json``.

        Returns:
            An instance of ``model_type``.

        Raises:
            ValueError: If ``content_type`` contains parameters.
            ContentTypeError: If the response content-type does not match.
            ModelError: If the response body fails Pydantic validation.
        """
        self._validate_content_type(content_type)
        data = self.json()
        try:
            return model_type.model_validate(data)
        except ValidationError as exc:
            raise ModelError(
                model_name=model_type.__name__,
                errors=str(exc),
                method=self._method,
                url=self._url,
                body=self.text,
            ) from None

    def model_list(
        self, model_type: type[T], *, content_type: str | None | _Unset = _UNSET
    ) -> list[T]:
        """Validate the response body as a list of Pydantic models.

        Validates the response content-type, parses the JSON body as a
        list, and returns a list of model instances. Content-type
        parameters in the response (e.g. ``charset=utf-8``) are always
        ignored during comparison.

        Args:
            model_type: The Pydantic model class for each list element.
            content_type: Controls content-type validation. Same rules as
                :meth:`model`.

        Returns:
            A list of ``model_type`` instances.

        Raises:
            ValueError: If ``content_type`` contains parameters.
            ContentTypeError: If the response content-type does not match.
            ModelError: If any element fails Pydantic validation.
        """
        self._validate_content_type(content_type)
        data = self.json()
        try:
            # NOTE: mypy and ty flag list[model_type] as an invalid type
            # expression because model_type is a variable, not a static type.
            # Pyright accepts it because TypeAdapter is designed for runtime
            # type expressions. We use pyright as our type checker.
            adapter = TypeAdapter(list[model_type])
            return adapter.validate_python(data)
        except ValidationError as exc:
            raise ModelError(
                model_name=model_type.__name__,
                errors=str(exc),
                method=self._method,
                url=self._url,
                body=self.text,
            ) from None

    def _validate_content_type(self, content_type: str | None | _Unset) -> None:
        """Validate the response content-type header.

        Content-type parameters (e.g. ``charset=utf-8``) in the response
        are always stripped before comparison — only the media type is
        matched. Passing a ``content_type`` string that itself contains
        parameters (a ``;``) is not supported and raises ``ValueError``.

        Args:
            content_type: The expected content-type constraint. See
                :meth:`model` for the full rules.

        Raises:
            ValueError: If ``content_type`` contains a ``;`` (parameters).
            ContentTypeError: If the response content-type does not match.
        """
        if content_type is None:
            return

        if isinstance(content_type, str) and ";" in content_type:
            raise ValueError(
                f"content_type must not contain parameters (got {content_type!r}). "
                "Response content-type parameters (e.g. charset) are always "
                "ignored during comparison."
            )

        raw_ct = self._response.headers.get("content-type", "")
        # Strip parameters (e.g. "; charset=utf-8") and normalise case.
        media_type = raw_ct.split(";")[0].strip().lower()

        if content_type is _UNSET:
            if media_type != "application/json" and not media_type.endswith("+json"):
                raise ContentTypeError(
                    expected="application/json or *+json",
                    actual=raw_ct,
                    method=self._method,
                    url=self._url,
                    body=self.text,
                )
            return

        if "/" in content_type:
            # Exact match.
            if media_type != content_type.lower():
                raise ContentTypeError(
                    expected=content_type,
                    actual=raw_ct,
                    method=self._method,
                    url=self._url,
                    body=self.text,
                )
        else:
            # Prefix mode: matches application/{value}+json.
            expected_media = f"application/{content_type.lower()}+json"
            if media_type != expected_media:
                raise ContentTypeError(
                    expected=expected_media,
                    actual=raw_ct,
                    method=self._method,
                    url=self._url,
                    body=self.text,
                )

    # -- Accessor methods --

    @property
    def status_code(self) -> int:
        """The raw HTTP status code."""
        return self._response.status_code

    def get_header(self, name: str) -> str:
        """Return the value of a response header.

        Args:
            name: The header name (case-insensitive).

        Returns:
            The header value as a string.

        Raises:
            HeaderError: If the header is not present in the response.
        """
        try:
            return self._response.headers[name]
        except KeyError:
            raise HeaderError(
                name=name,
                method=self._method,
                url=self._url,
            ) from None

    def get_headers(self) -> httpx.Headers:
        """Return all response headers.

        Returns:
            The response headers as an ``httpx.Headers`` object. Supports
            dict-like access for single-value lookups and ``.multi_items()``
            or ``.get_list(name)`` for multi-value headers.
        """
        return self._response.headers

    def json(self) -> Any:
        """Parse the response body as JSON.

        Returns:
            The parsed JSON value.

        Raises:
            JsonError: If the response body is not valid JSON.
        """
        try:
            return self._response.json()
        except Exception as exc:
            raise JsonError(
                method=self._method,
                url=self._url,
                body=self.text,
                detail=str(exc),
            ) from None

    @property
    def raw(self) -> httpx.Response:
        """The underlying httpx.Response object.

        Use this as an escape hatch when you need access to httpx features
        that basst does not wrap directly.
        """
        return self._response

    @property
    def text(self) -> str:
        """The raw response body as a string."""
        return self._response.text
