def chunk_text(text: str, chunk_size: int = 3000):
    """
    Splits text into manageable chunks.
    """
    if not text:
        return []

    return [
        text[i:i + chunk_size]
        for i in range(0, len(text), chunk_size)
    ]