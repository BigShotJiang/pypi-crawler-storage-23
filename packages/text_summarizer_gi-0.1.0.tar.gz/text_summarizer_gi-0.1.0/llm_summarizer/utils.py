import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("llm_summarizer")


def validate_input(text: str):
    if not text or not text.strip():
        raise ValueError("Input text cannot be empty.")

    if len(text) < 50:
        logger.info("Text too short to summarize. Returning original.")
        return False

    return True


def length_mapper(length_type: str):
    mapping = {
        "short": "3-4 sentences. Be extremely concise.",
        "medium": "1 concise paragraph (5-7 sentences max).",
        "detailed": "Multiple paragraphs with key insights, but no longer than necessary."
    }
    return mapping.get(length_type, mapping["medium"])


def max_tokens_mapper(length_type: str) -> int:
    """Return a hard token cap for the API call based on summary type."""
    mapping = {
        "short": 120,
        "medium": 300,
        "detailed": 700,
    }
    return mapping.get(length_type, 300)


def format_mapper(output_format: str):
    formats = {
        "text": "Return plain paragraph text.",
        "bullets": "Return bullet points.",
        "json": """Return JSON format:
{
    "summary": "",
    "key_points": []
}"""
    }
    return formats.get(output_format, formats["text"])