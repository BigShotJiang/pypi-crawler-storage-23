import unittest


class TestExample(unittest.TestCase):

    def test_example(self) -> None:
        self.assertEqual(2 + 2, 4)
