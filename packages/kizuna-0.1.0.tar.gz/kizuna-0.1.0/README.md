# Kizuna Project

Kizuna is a flexible game development framework for Python based on the
[Pyglet](https://pyglet.readthedocs.io/en/latest/index.html) library.

Check out the [documentation](https://kizuna.readthedocs.io/) for more information.
