from kizuna.management.settings import Settings


settings = Settings()
