from kizuna.rendering.drawables import Drawable


class Scene:
    drawables: list[Drawable] = []
