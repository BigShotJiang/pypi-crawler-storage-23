"""Profiling public API."""

from django_o11y.profiling.setup import setup_profiling

__all__ = ["setup_profiling"]
