# Runlayer CLI

The Runlayer CLI enables secure execution of trusted MCP servers with enterprise-grade security, auditing, and permission management. Run Model Context Protocol servers through an authenticated proxy that enforces access controls, maintains audit logs, and manages permissions - allowing AI agents to safely connect to internal systems without exposing credentials or running unvetted code locally.

The CLI also provides deployment capabilities to build and deploy Docker-based services to your Runlayer infrastructure, and scanning capabilities to discover MCP server configurations across devices.

## Quick Start

The easiest way to get started is to **copy the complete command from the server overview page in your Runlayer app** - it includes all the required parameters pre-filled for your server.

Alternatively, you can construct the command manually:

```bash
uvx runlayer run <server_uuid> --secret <your_api_key> --host <runlayer_url>
```

## Commands

### `run` - Run an MCP Server

Run an MCP server through the Runlayer proxy.

#### Command Arguments

- `server_uuid`: UUID of your MCP server (found in your Runlayer deployment)

#### Command Options

- `--secret`, `-s`: Your Runlayer API key (found under your user settings)
- `--host`: Your Runlayer instance URL (e.g., https://runlayer.example.com)

### Global Options

These options can be passed to any command:

- `--secret`, `-s`: API key for authentication (user or org key)
- `--host`, `-H`: Runlayer host URL
- `--org-api-key`: Name of a stored org API key to use (see `org-api-key` command)

#### Example

```bash
uvx runlayer run abc123-def456 --secret my_api_key --host https://runlayer.example.com
```

### `deploy` - Deploy a Service

Deploy a Docker-based service to your Runlayer infrastructure based on a `runlayer.yaml` configuration file.

#### Command Options

- `--config`, `-c`: Path to runlayer.yaml config file (default: `runlayer.yaml`)
- `--secret`, `-s`: Your Runlayer API key (required, must have admin permissions)
- `--host`, `-H`: Your Runlayer instance URL (default: `http://localhost:3000`)
- `--env-file`, `-e`: Path to .env file for environment variable substitution (optional, defaults to `.env` in config file directory or current directory)

#### Example

```bash
uvx runlayer deploy --config runlayer.yaml --secret my_admin_key --host https://runlayer.example.com
```

#### Configuration File (`runlayer.yaml`)

The deploy command reads from a `runlayer.yaml` file that defines your service configuration:

```yaml
name: my-awesome-service
runtime: docker

build:
  dockerfile: Dockerfile
  context: .
  platform: x86  # or "arm"

service:
  port: 8000
  path: /api

infrastructure:
  cpu: 512
  memory: 1024

env:
  DATABASE_URL: postgres://...
  API_KEY: secret123
```

#### Environment Variable Substitution

The CLI supports standard Docker Compose / shell-style environment variable substitution in your `runlayer.yaml` file. This allows you to reference local environment variables or values from a `.env` file without hardcoding sensitive values.

**Variable Syntax:**

- `${VAR}` - Required variable (error if not set)
- `${VAR:-default}` - Use default value if variable is unset or empty
- `${VAR-default}` - Use default value only if variable is unset (not if empty)
- `$$DEPLOYMENT_URL`, `$$RUNLAYER_URL`, `$$RUNLAYER_OAUTH_CALLBACK_URL` - Reserved system variables (backend replaces at deploy time)

**Example Configuration:**

```yaml
name: my-service
env:
  API_KEY: ${MY_API_KEY}                      # Required - error if not set
  DATABASE_URL: ${DATABASE_URL}               # Required
  LOG_LEVEL: ${LOG_LEVEL:-info}               # Default to 'info' if not set
  DEBUG: ${DEBUG:-false}                      # Default to 'false'
  WEBHOOK_URL: $$DEPLOYMENT_URL/webhook    # Backend replaces (double $$)
```

**Usage:**

```bash
# Using environment variables
export MY_API_KEY=secret123
export DATABASE_URL=postgres://localhost/db
uvx runlayer deploy --secret my_admin_key --host https://runlayer.example.com

# Using a .env file (auto-discovered from config file directory or current directory)
# Place .env file next to runlayer.yaml or in current directory
uvx runlayer deploy --secret my_admin_key --host https://runlayer.example.com

# Using a specific .env file
uvx runlayer deploy --secret my_admin_key --host https://runlayer.example.com --env-file .env.prod
```

**Auto-discovery:** The CLI automatically looks for a `.env` file in:
1. The same directory as your `runlayer.yaml` config file
2. The current working directory (if config file is elsewhere)

If you specify `--env-file`, it will use that file instead of auto-discovery.

**Standard .env file format:**

```
MY_API_KEY=secret123
DATABASE_URL=postgres://localhost/db
LOG_LEVEL=debug
```

**Note:** Variables from `.env` files override values from `os.environ`. The `$$VAR` syntax (double dollar sign) is reserved for backend variable substitution and will not be replaced by the CLI.

### `deploy init` - Initialize a New Deployment

Create a new deployment and generate a `runlayer.yaml` configuration file.

#### Example

```bash
uvx runlayer deploy init --config runlayer.yaml --secret my_admin_key --host https://runlayer.example.com
```

### `org-api-key` - Manage Organization API Keys

Store, list, and remove named organization API keys in the CLI config. Org API keys are scoped keys created in the Runlayer web app (Settings > API Keys) for specific roles like MCP Watch scanning or Security Scan API access.

#### `org-api-key add` - Store a Named Key

```bash
uvx runlayer org-api-key add <name> --secret <key>
```

- `name`: A short name to reference this key by (e.g., `mcp-watch`, `security-scan`)
- `--secret`, `-s`: The org API key value (`rl_org_...`). Prompted securely if omitted.
- `--host`, `-H`: Host to store the key for (defaults to current host)

#### `org-api-key remove` - Remove a Named Key

```bash
uvx runlayer org-api-key remove <name>
```

#### `org-api-key list` - List Stored Keys

```bash
uvx runlayer org-api-key list
```

Shows key names and truncated prefixes for the current host.

#### Using Stored Org API Keys

Once stored, reference a key by name with the `--org-api-key` flag on any command:

```bash
# Use a stored org key for scanning
uvx runlayer scan --org-api-key mcp-watch

# The --org-api-key flag also works as a global option
uvx runlayer --org-api-key mcp-watch scan

# Or via environment variable (scan command only)
RUNLAYER_ORG_API_KEY_NAME=mcp-watch uvx runlayer scan
```

The `--secret` flag still accepts any raw API key (user or org) directly and takes priority over `--org-api-key`.

### `scan` - Scan MCP Client Configurations

Scan for MCP server configurations across supported clients (Cursor, Claude Desktop, Claude Code, VS Code, Windsurf) and submit results to Runlayer for classification.

#### Command Options

- `--secret`, `-s`: Your Runlayer API key (required unless `--dry-run`)
- `--host`, `-H`: Your Runlayer instance URL (default: `http://localhost:3000`)
- `--org-api-key`: Name of a stored org API key to use for authentication
- `--dry-run`, `-n`: Print scan results as JSON without submitting to API
- `--verbose`, `-v`: Enable verbose output
- `--quiet`, `-q`: Suppress all output except errors
- `--org-device-id`: Organization-provided device ID (e.g., MDM asset tag)
- `--no-projects`: Skip scanning for project-level configurations

#### Example

```bash
# With a stored org API key
uvx runlayer scan --org-api-key mcp-watch

# With a direct secret
uvx runlayer scan --secret $RUNLAYER_API_KEY --host https://runlayer.example.com
```

### `setup install` - Install MCP Servers and Plugins

Install MCP servers and plugins directly to your client configuration files.

#### Supported Clients

- `cursor` - Cursor IDE
- `claude_desktop` - Claude Desktop
- `claude_code` - Claude Code (supports plugins)
- `vscode` - VS Code
- `windsurf` - Windsurf
- `goose` - Goose
- `zed` - Zed

**Note:** Plugins are only supported for Claude Code.

#### Command Options

- `--client`, `-c`: Target client (required for non-interactive mode)
- `--server-id`, `-S`: Server ID(s) to install (can be repeated)
- `--plugin-id`, `-P`: Plugin ID(s) to install (Claude Code only, can be repeated)
- `--interactive`, `-i`: Interactive mode - browse and select servers/plugins
- `--secret`, `-s`: Your Runlayer API key (optional if logged in)
- `--host`, `-H`: Your Runlayer instance URL (optional if logged in)
- `--header`: HTTP header for remote servers (format: `Key: Value`, can be repeated)
- `--yes`, `-y`: Skip confirmation prompts

#### Authentication for Remote Servers

For remote MCP servers requiring authentication, use the `--header` option:

```bash
# Add authorization header
uvx runlayer setup install --client vscode --server-id abc123 --header "Authorization: Bearer your-token"

# Add custom API key header
uvx runlayer setup install --client cursor --server-id abc123 --header "X-Api-Key: your-key"

# Multiple headers
uvx runlayer setup install --client vscode --server-id abc123 \
  --header "Authorization: Bearer token" \
  --header "X-Custom-Header: value"
```

#### Config File Handling

The CLI safely handles JSONC files (JSON with comments and trailing commas), which are used by VS Code, Zed, and other editors. Existing comments and formatting are preserved when installing servers.

**Note for VS Code users:** VS Code supports user-level and profile-specific MCP configurations. The CLI installs to the default user settings location. If you use VS Code profiles, you may need to manually copy configurations between profiles.

#### Non-Interactive Mode

Install specific servers or plugins by ID:

```bash
# Install a single server to Cursor
uvx runlayer setup install --client cursor --server-id abc123

# Install multiple servers
uvx runlayer setup install --client cursor --server-id abc123 --server-id def456

# Install servers and plugins to Claude Code
uvx runlayer setup install --client claude_code --server-id abc123 --plugin-id xyz789
```

#### Interactive Mode

Browse available servers and plugins, then select which to install:

```bash
# Interactive mode with client selection
uvx runlayer setup install --interactive

# Interactive mode with pre-selected client
uvx runlayer setup install --interactive --client cursor
```

#### Examples

```bash
# First, log in to your Runlayer instance
uvx runlayer login --host https://runlayer.example.com

# Interactive installation
uvx runlayer setup install --interactive

# Non-interactive installation with explicit credentials
uvx runlayer setup install --client cursor --server-id abc123 --secret $API_KEY --host https://runlayer.example.com

# Skip confirmation prompts
uvx runlayer setup install --client cursor --server-id abc123 --yes
```

### `setup hooks` - Install Client Hooks

Install or uninstall Runlayer hooks that validate MCP tool calls and block access to sensitive files (`.env`, MCP configs).

#### Command Options

- `--client`, `-c`: Client to configure (`cursor`). All clients if omitted.
- `--install`, `-i`: Install hooks
- `--uninstall`, `-u`: Uninstall hooks
- `--mdm`: Install to enterprise location (requires elevated permissions)
- `--host`, `-H`: Validate this host exists in config before install
- `--yes`, `-y`: Skip confirmation prompt

#### Example

```bash
# Install hooks for all clients
uvx runlayer setup hooks --install

# Install to enterprise (MDM) location
sudo uvx runlayer setup hooks --install --mdm

# Uninstall
uvx runlayer setup hooks --uninstall
```

### `setup sync` - Sync Auto-Synced Servers

Install all auto-synced servers to client configs. Auto-detects installed clients or use `--client` to target a specific one.

#### Command Options

- `--client`, `-c`: Target client (auto-detects if omitted)
- `--header`: HTTP header for remote servers (format: `Key: Value`, can be repeated)
- `--secret`, `-s`: Your Runlayer API key (optional if logged in)
- `--host`, `-H`: Your Runlayer instance URL (optional if logged in)
- `--yes`, `-y`: Skip confirmation prompts

#### Example

```bash
# Sync to all detected clients
uvx runlayer setup sync

# Sync to a specific client
uvx runlayer setup sync --client cursor --yes
```

### `verified-local` - Run a Verified Local MCP Server Proxy

Secure proxy for verified local MCP servers. Verifies code signatures before forwarding MCP traffic to local applications, ensuring the target application hasn't been tampered with.

#### Command Arguments

- `server_id`: Server identifier (e.g., `com.figma/desktop-mcp`)

#### Command Options

- `--list`, `-l`: List available server IDs and exit
- `--verbose`, `-v`: Enable verbose output

#### Example

```bash
# List available servers
uvx runlayer verified-local --list

# Run a verified proxy
uvx runlayer verified-local com.figma/desktop-mcp
```

## Logs

Logs are written to `~/.runlayer/logs/`. Set `LOG_LEVEL` environment variable to control verbosity (DEBUG, INFO, WARNING, ERROR).
