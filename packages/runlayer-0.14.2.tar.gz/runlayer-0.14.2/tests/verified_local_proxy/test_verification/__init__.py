"""Tests for verification module."""
