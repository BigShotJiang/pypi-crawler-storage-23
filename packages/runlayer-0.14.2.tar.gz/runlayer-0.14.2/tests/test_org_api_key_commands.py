"""Tests for org-api-key CLI commands and Config org key methods."""

from unittest.mock import patch

import pytest
from typer.testing import CliRunner

from runlayer_cli.config import Config
from runlayer_cli.main import app

runner = CliRunner()


def _config_with_org_keys() -> Config:
    return Config(
        default_host="https://app.runlayer.com",
        hosts={
            "app.runlayer.com": {
                "url": "https://app.runlayer.com",
                "secret": "rl_user_key",
                "org_api_keys": {
                    "mcp-watch": "rl_org_aaaaaa",
                    "security": "rl_org_bbbbbb",
                },
            }
        },
    )


# ── Config model unit tests ──────────────────────────────────────────


class TestConfigOrgApiKeys:
    def test_get_org_api_key(self):
        config = _config_with_org_keys()
        assert (
            config.get_org_api_key("https://app.runlayer.com", "mcp-watch")
            == "rl_org_aaaaaa"
        )

    def test_get_org_api_key_missing_name(self):
        config = _config_with_org_keys()
        assert config.get_org_api_key("https://app.runlayer.com", "nonexistent") is None

    def test_get_org_api_key_missing_host(self):
        config = _config_with_org_keys()
        assert config.get_org_api_key("https://other.com", "mcp-watch") is None

    def test_get_org_api_key_no_org_keys_section(self):
        config = Config(
            default_host="https://app.runlayer.com",
            hosts={
                "app.runlayer.com": {
                    "url": "https://app.runlayer.com",
                    "secret": "rl_user_key",
                }
            },
        )
        assert config.get_org_api_key("https://app.runlayer.com", "any") is None

    def test_set_org_api_key_existing_host(self):
        config = _config_with_org_keys()
        config.set_org_api_key("https://app.runlayer.com", "new-key", "rl_org_cccccc")
        assert (
            config.get_org_api_key("https://app.runlayer.com", "new-key")
            == "rl_org_cccccc"
        )
        # existing keys preserved
        assert (
            config.get_org_api_key("https://app.runlayer.com", "mcp-watch")
            == "rl_org_aaaaaa"
        )

    def test_set_org_api_key_creates_host_entry(self):
        config = Config()
        config.set_org_api_key("https://new.host.com", "scan", "rl_org_dddddd")
        assert config.get_org_api_key("https://new.host.com", "scan") == "rl_org_dddddd"

    def test_set_org_api_key_scheme_mismatch_rejects(self):
        """set with http:// when config stores https:// must not silently write
        into the wrong host entry, making the key invisible to get/remove/list."""
        config = _config_with_org_keys()
        with pytest.raises(ValueError, match="scheme mismatch"):
            config.set_org_api_key(
                "http://app.runlayer.com", "bad-key", "rl_org_zzzzzz"
            )
        # Original https keys unaffected
        assert (
            config.get_org_api_key("https://app.runlayer.com", "mcp-watch")
            == "rl_org_aaaaaa"
        )

    def test_remove_org_api_key(self):
        config = _config_with_org_keys()
        assert (
            config.remove_org_api_key("https://app.runlayer.com", "mcp-watch") is True
        )
        assert config.get_org_api_key("https://app.runlayer.com", "mcp-watch") is None
        # other key still there
        assert (
            config.get_org_api_key("https://app.runlayer.com", "security")
            == "rl_org_bbbbbb"
        )

    def test_remove_org_api_key_not_found(self):
        config = _config_with_org_keys()
        assert config.remove_org_api_key("https://app.runlayer.com", "nope") is False

    def test_remove_last_org_api_key_cleans_section(self):
        config = Config(
            default_host="https://app.runlayer.com",
            hosts={
                "app.runlayer.com": {
                    "url": "https://app.runlayer.com",
                    "secret": "rl_user",
                    "org_api_keys": {"only": "rl_org_only"},
                }
            },
        )
        config.remove_org_api_key("https://app.runlayer.com", "only")
        assert "org_api_keys" not in config.hosts["app.runlayer.com"]

    def test_list_org_api_keys(self):
        config = _config_with_org_keys()
        keys = config.list_org_api_keys("https://app.runlayer.com")
        assert set(keys.keys()) == {"mcp-watch", "security"}
        # values are truncated prefixes
        for prefix in keys.values():
            assert prefix.endswith("...")

    def test_list_org_api_keys_empty(self):
        config = Config(
            default_host="https://app.runlayer.com",
            hosts={
                "app.runlayer.com": {
                    "url": "https://app.runlayer.com",
                    "secret": "rl_user",
                }
            },
        )
        assert config.list_org_api_keys("https://app.runlayer.com") == {}

    def test_set_host_credentials_preserves_org_keys(self):
        config = _config_with_org_keys()
        config.set_host_credentials("https://app.runlayer.com", "rl_new_user_key")
        assert (
            config.get_secret_for_host("https://app.runlayer.com") == "rl_new_user_key"
        )
        assert (
            config.get_org_api_key("https://app.runlayer.com", "mcp-watch")
            == "rl_org_aaaaaa"
        )

    def test_to_dict_includes_org_api_keys(self):
        config = _config_with_org_keys()
        d = config.to_dict()
        host_data = d["hosts"]["app.runlayer.com"]
        assert host_data["org_api_keys"]["mcp-watch"] == "rl_org_aaaaaa"


# ── CLI command tests ────────────────────────────────────────────────


class TestOrgApiKeyAddCommand:
    def test_add_saves_key(self):
        config = Config(
            default_host="https://app.runlayer.com",
            hosts={
                "app.runlayer.com": {
                    "url": "https://app.runlayer.com",
                    "secret": "rl_user",
                }
            },
        )
        with patch(
            "runlayer_cli.commands.org_api_key.load_config", return_value=config
        ):
            with patch("runlayer_cli.commands.org_api_key.save_config") as mock_save:
                result = runner.invoke(
                    app,
                    ["org-api-key", "add", "my-key", "--secret", "rl_org_test123"],
                )
                assert result.exit_code == 0
                assert "saved" in result.output
                mock_save.assert_called_once()
                saved = mock_save.call_args[0][0]
                assert (
                    saved.get_org_api_key("https://app.runlayer.com", "my-key")
                    == "rl_org_test123"
                )

    def test_add_requires_host(self):
        config = Config()
        with patch(
            "runlayer_cli.commands.org_api_key.load_config", return_value=config
        ):
            result = runner.invoke(
                app,
                ["org-api-key", "add", "my-key", "--secret", "rl_org_x"],
            )
            assert result.exit_code == 1
            assert "No host configured" in result.output

    def test_add_scheme_mismatch_errors(self):
        config = _config_with_org_keys()
        with patch(
            "runlayer_cli.commands.org_api_key.load_config", return_value=config
        ):
            result = runner.invoke(
                app,
                [
                    "org-api-key",
                    "add",
                    "bad",
                    "--secret",
                    "rl_org_x",
                    "--host",
                    "http://app.runlayer.com",
                ],
            )
            assert result.exit_code == 1
            assert "scheme mismatch" in result.output.lower()


class TestOrgApiKeyRemoveCommand:
    def test_remove_existing(self):
        config = _config_with_org_keys()
        with patch(
            "runlayer_cli.commands.org_api_key.load_config", return_value=config
        ):
            with patch("runlayer_cli.commands.org_api_key.save_config") as mock_save:
                result = runner.invoke(app, ["org-api-key", "remove", "mcp-watch"])
                assert result.exit_code == 0
                assert "removed" in result.output
                mock_save.assert_called_once()

    def test_remove_nonexistent(self):
        config = _config_with_org_keys()
        with patch(
            "runlayer_cli.commands.org_api_key.load_config", return_value=config
        ):
            result = runner.invoke(app, ["org-api-key", "remove", "nope"])
            assert result.exit_code == 0
            assert "No org API key 'nope'" in result.output


class TestOrgApiKeyListCommand:
    def test_list_shows_keys(self):
        config = _config_with_org_keys()
        with patch(
            "runlayer_cli.commands.org_api_key.load_config", return_value=config
        ):
            result = runner.invoke(app, ["org-api-key", "list"])
            assert result.exit_code == 0
            assert "mcp-watch" in result.output
            assert "security" in result.output

    def test_list_uses_global_host_flag(self):
        """Global --host flag should override config.default_host."""
        config = Config(
            default_host="https://default.runlayer.com",
            hosts={
                "default.runlayer.com": {
                    "url": "https://default.runlayer.com",
                    "secret": "rl_user",
                },
                "custom.runlayer.com": {
                    "url": "https://custom.runlayer.com",
                    "secret": "rl_user2",
                    "org_api_keys": {"custom-key": "rl_org_custom"},
                },
            },
        )
        with patch(
            "runlayer_cli.commands.org_api_key.load_config", return_value=config
        ):
            result = runner.invoke(
                app, ["--host", "https://custom.runlayer.com", "org-api-key", "list"]
            )
            assert result.exit_code == 0
            assert "custom-key" in result.output
            assert "custom.runlayer.com" in result.output

    def test_list_empty(self):
        config = Config(
            default_host="https://app.runlayer.com",
            hosts={
                "app.runlayer.com": {
                    "url": "https://app.runlayer.com",
                    "secret": "rl_user",
                }
            },
        )
        with patch(
            "runlayer_cli.commands.org_api_key.load_config", return_value=config
        ):
            result = runner.invoke(app, ["org-api-key", "list"])
            assert result.exit_code == 0
            assert "No org API keys" in result.output


# ── Credential resolution with --org-api-key ─────────────────────────


class TestOrgApiKeyResolution:
    def test_global_org_api_key_flag_resolves(self):
        """--org-api-key on root command resolves named key."""
        config = _config_with_org_keys()
        with patch("runlayer_cli.config.load_config", return_value=config):
            from runlayer_cli.config import resolve_credentials
            import typer

            # Simulate context chain: main sets org_api_key_name
            ctx = typer.Context(typer.main.get_command(app))
            ctx.ensure_object(dict)
            ctx.obj["org_api_key_name"] = "mcp-watch"
            ctx.obj["secret"] = None
            ctx.obj["host"] = None

            creds = resolve_credentials(ctx, require_auth=False)
            assert creds["secret"] == "rl_org_aaaaaa"
            assert creds["host"] == "https://app.runlayer.com"

    def test_secret_flag_takes_priority_over_org_api_key(self):
        """--secret overrides --org-api-key."""
        config = _config_with_org_keys()
        with patch("runlayer_cli.config.load_config", return_value=config):
            from runlayer_cli.config import resolve_credentials
            import typer

            ctx = typer.Context(typer.main.get_command(app))
            ctx.ensure_object(dict)
            ctx.obj["secret"] = "rl_direct_secret"
            ctx.obj["org_api_key_name"] = "mcp-watch"
            ctx.obj["host"] = None

            creds = resolve_credentials(ctx, require_auth=False)
            assert creds["secret"] == "rl_direct_secret"

    def test_org_api_key_not_found_exits(self):
        """--org-api-key with unknown name exits with error."""
        config = _config_with_org_keys()
        with patch("runlayer_cli.config.load_config", return_value=config):
            from runlayer_cli.config import resolve_credentials
            import typer
            import pytest
            from click.exceptions import Exit

            ctx = typer.Context(typer.main.get_command(app))
            ctx.ensure_object(dict)
            ctx.obj["secret"] = None
            ctx.obj["org_api_key_name"] = "nonexistent"
            ctx.obj["host"] = None

            with pytest.raises(Exit):
                resolve_credentials(ctx, require_auth=False)
