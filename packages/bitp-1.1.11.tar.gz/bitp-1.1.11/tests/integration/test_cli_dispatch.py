#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Integration tests for CLI command dispatch."""

import subprocess
import sys

import pytest

from bitbake_project.cli import main


class TestMainHelp:
    """Tests for --help and help command."""

    def test_main_help_flag(self, capsys):
        """main --help shows help and exits 0."""
        with pytest.raises(SystemExit) as exc_info:
            main(["--help"])
        assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "BitBake" in captured.out or "bitbake" in captured.out.lower()
        assert "usage" in captured.out.lower()

    def test_update_help(self, capsys):
        """update --help shows update-specific help."""
        with pytest.raises(SystemExit) as exc_info:
            main(["update", "--help"])
        assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "update" in captured.out.lower()
        assert "--dry-run" in captured.out

    def test_explore_help(self, capsys):
        """explore --help shows explore-specific help."""
        with pytest.raises(SystemExit) as exc_info:
            main(["explore", "--help"])
        assert exc_info.value.code == 0

        captured = capsys.readouterr()
        assert "explore" in captured.out.lower()


class TestMainCompletion:
    """Tests for --completion flag."""

    def test_completion_shows_setup(self, capsys):
        """--completion shows completion setup instructions."""
        result = main(["--completion"])

        assert result == 0

        captured = capsys.readouterr()
        assert "completion" in captured.out.lower()
        assert "argcomplete" in captured.out


class TestMainNoArgs:
    """Tests for main without arguments."""

    def test_no_args_no_bblayers_shows_projects(self, clean_environment, mocker, capsys):
        """Without bblayers.conf, offers to use projects."""
        # Mock fzf as unavailable to get text output
        mocker.patch("shutil.which", return_value=None)
        mocker.patch("bitbake_project.cli.fzf_available", return_value=False)
        mocker.patch("bitbake_project.commands.fzf_available", return_value=False)

        result = main([])

        captured = capsys.readouterr()
        # Should mention bblayers.conf not found or projects
        assert "bblayers.conf" in captured.out.lower() or "project" in captured.out.lower()


class TestCommandAliases:
    """Tests that command aliases work correctly."""

    def test_u_alias_for_update(self):
        """'u' is alias for 'update'."""
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()

        args_update = parser.parse_args(["update", "--dry-run"])
        args_u = parser.parse_args(["u", "--dry-run"])

        assert args_u.dry_run == args_update.dry_run

    def test_x_alias_for_explore(self):
        """'x' is alias for 'explore'."""
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()

        args_explore = parser.parse_args(["explore", "--status"])
        args_x = parser.parse_args(["x", "--status"])

        assert args_x.status == args_explore.status

    def test_c_alias_for_config(self):
        """'c' is alias for 'config'."""
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()

        args_config = parser.parse_args(["config", "1"])
        args_c = parser.parse_args(["c", "1"])

        assert args_c.repo == args_config.repo

    def test_b_alias_for_branch(self):
        """'b' is alias for 'branch'."""
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()

        args_branch = parser.parse_args(["branch"])
        args_b = parser.parse_args(["b"])

        assert args_b.command == "b"

    def test_d_alias_for_deps(self):
        """'d' is alias for 'deps'."""
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()

        args_deps = parser.parse_args(["deps"])
        args_d = parser.parse_args(["d"])

        assert args_d.command == "d"

    def test_p_alias_for_projects(self):
        """'p' is alias for 'projects'."""
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()

        args_projects = parser.parse_args(["projects"])
        args_p = parser.parse_args(["p"])

        assert args_p.command == "p"

    def test_r_alias_for_recipes(self):
        """'r' is alias for 'recipes'."""
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()

        args_recipes = parser.parse_args(["recipes"])
        args_r = parser.parse_args(["r"])

        assert args_r.command == "r"

    def test_f_alias_for_fragments(self):
        """'f' is alias for 'fragments'."""
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()

        args = parser.parse_args(["f"])
        assert args.command == "f"

    def test_h_alias_for_help(self):
        """'h' is alias for 'help'."""
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()

        args = parser.parse_args(["h"])
        assert args.command == "h"


class TestInvalidCommands:
    """Tests for invalid command handling."""

    def test_unknown_command_fails(self, capsys):
        """Unknown command causes error."""
        with pytest.raises(SystemExit) as exc_info:
            main(["unknown_command"])
        assert exc_info.value.code != 0

    def test_invalid_option(self, capsys):
        """Invalid option causes error."""
        with pytest.raises(SystemExit):
            main(["update", "--invalid-option"])
