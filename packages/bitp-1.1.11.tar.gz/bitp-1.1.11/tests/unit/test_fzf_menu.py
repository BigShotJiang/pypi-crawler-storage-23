#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for FzfMenu class."""

import subprocess
from unittest.mock import MagicMock, patch

import pytest

from bitbake_project.core import FzfMenu, fzf_available


class TestFzfAvailable:
    """Tests for fzf_available function."""

    def test_returns_true_when_fzf_installed(self, mocker):
        """fzf_available returns True when fzf is found."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        assert fzf_available() is True

    def test_returns_false_when_fzf_not_installed(self, mocker):
        """fzf_available returns False when fzf is not found."""
        mocker.patch("shutil.which", return_value=None)
        assert fzf_available() is False


class TestFzfMenuInit:
    """Tests for FzfMenu initialization."""

    def test_default_values(self):
        """FzfMenu initializes with sensible defaults."""
        menu = FzfMenu()

        assert menu.header == ""
        assert menu.prompt == "> "
        assert menu.multi is False
        assert menu.height == "~50%"
        assert menu.ansi is True
        assert menu.no_sort is False

    def test_custom_values(self):
        """FzfMenu accepts custom initialization values."""
        menu = FzfMenu(
            header="Select item",
            prompt="Choice: ",
            multi=True,
            height="20",
            ansi=False,
            no_sort=True,
        )

        assert menu.header == "Select item"
        assert menu.prompt == "Choice: "
        assert menu.multi is True
        assert menu.height == "20"
        assert menu.ansi is False
        assert menu.no_sort is True


class TestFzfMenuAddOption:
    """Tests for FzfMenu.add_option method."""

    def test_add_simple_option(self):
        """add_option adds a simple option."""
        menu = FzfMenu()
        menu.add_option("opt1")

        assert len(menu.options) == 1
        assert menu.options[0] == ("opt1", "opt1")

    def test_add_option_with_display(self):
        """add_option with display text."""
        menu = FzfMenu()
        menu.add_option("opt1", "Option One")

        assert menu.options[0] == ("opt1", "opt1\tOption One")

    def test_add_option_with_description(self):
        """add_option with display and description."""
        menu = FzfMenu()
        menu.add_option("opt1", "Option One", "First option")

        assert menu.options[0] == ("opt1", "opt1\tOption One\tFirst option")

    def test_add_option_chaining(self):
        """add_option returns self for chaining."""
        menu = FzfMenu()
        result = menu.add_option("opt1").add_option("opt2")

        assert result is menu
        assert len(menu.options) == 2


class TestFzfMenuAddLine:
    """Tests for FzfMenu.add_line method."""

    def test_add_separator_line(self):
        """add_line adds a raw line."""
        menu = FzfMenu()
        menu.add_line("─" * 20)

        assert len(menu.options) == 1
        assert menu.options[0] == ("", "─" * 20)


class TestFzfMenuAddBind:
    """Tests for FzfMenu.add_bind method."""

    def test_add_key_binding(self):
        """add_bind adds a key binding."""
        menu = FzfMenu()
        menu.add_bind("ctrl-a", "select-all")

        assert len(menu.binds) == 1
        assert menu.binds[0] == ("ctrl-a", "select-all")

    def test_add_multiple_bindings(self):
        """Multiple bindings can be added."""
        menu = FzfMenu()
        menu.add_bind("ctrl-a", "select-all")
        menu.add_bind("ctrl-d", "deselect-all")

        assert len(menu.binds) == 2


class TestFzfMenuAddArg:
    """Tests for FzfMenu.add_arg method."""

    def test_add_extra_args(self):
        """add_arg adds extra fzf arguments."""
        menu = FzfMenu()
        menu.add_arg("--reverse", "--border")

        assert "--reverse" in menu.extra_args
        assert "--border" in menu.extra_args

    def test_add_arg_chaining(self):
        """add_arg returns self for chaining."""
        menu = FzfMenu()
        result = menu.add_arg("--reverse")

        assert result is menu


class TestFzfMenuShow:
    """Tests for FzfMenu.show method."""

    def test_show_returns_none_when_fzf_unavailable(self, mocker):
        """show returns None when fzf is not installed."""
        mocker.patch("shutil.which", return_value=None)

        menu = FzfMenu()
        menu.add_option("opt1")
        result = menu.show()

        assert result is None

    def test_show_returns_none_on_cancel(self, mocker):
        """show returns None when user cancels."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        mock_run = mocker.patch("subprocess.run")
        mock_run.return_value = MagicMock(returncode=130, stdout="")

        menu = FzfMenu()
        menu.add_option("opt1")
        result = menu.show()

        assert result is None

    def test_show_returns_selection(self, mocker):
        """show returns selected value."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        mock_run = mocker.patch("subprocess.run")
        mock_run.return_value = MagicMock(returncode=0, stdout="opt1\tOption One")

        menu = FzfMenu()
        menu.add_option("opt1", "Option One")
        result = menu.show()

        assert result == "opt1"

    def test_show_multi_returns_list(self, mocker):
        """show with multi=True returns list of selections."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        mock_run = mocker.patch("subprocess.run")
        mock_run.return_value = MagicMock(
            returncode=0,
            stdout="opt1\tOption One\nopt2\tOption Two"
        )

        menu = FzfMenu(multi=True)
        menu.add_option("opt1", "Option One")
        menu.add_option("opt2", "Option Two")
        result = menu.show()

        assert result == ["opt1", "opt2"]

    def test_show_includes_header(self, mocker):
        """show includes --header when set."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        mock_run = mocker.patch("subprocess.run")
        mock_run.return_value = MagicMock(returncode=130, stdout="")

        menu = FzfMenu(header="Test Header")
        menu.add_option("opt1")
        menu.show()

        # Check that --header was passed
        call_args = mock_run.call_args[0][0]
        assert "--header" in call_args
        header_idx = call_args.index("--header")
        assert call_args[header_idx + 1] == "Test Header"

    def test_show_includes_prompt(self, mocker):
        """show includes --prompt when set."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        mock_run = mocker.patch("subprocess.run")
        mock_run.return_value = MagicMock(returncode=130, stdout="")

        menu = FzfMenu(prompt="Select: ")
        menu.add_option("opt1")
        menu.show()

        call_args = mock_run.call_args[0][0]
        assert "--prompt" in call_args

    def test_show_includes_bindings(self, mocker):
        """show includes key bindings."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        mock_run = mocker.patch("subprocess.run")
        mock_run.return_value = MagicMock(returncode=130, stdout="")

        menu = FzfMenu()
        menu.add_option("opt1")
        menu.add_bind("ctrl-a", "select-all")
        menu.show()

        call_args = mock_run.call_args[0][0]
        assert "--bind" in call_args
        bind_idx = call_args.index("--bind")
        assert call_args[bind_idx + 1] == "ctrl-a:select-all"

    def test_show_no_sort_option(self, mocker):
        """show includes --no-sort when set."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        mock_run = mocker.patch("subprocess.run")
        mock_run.return_value = MagicMock(returncode=130, stdout="")

        menu = FzfMenu(no_sort=True)
        menu.add_option("opt1")
        menu.show()

        call_args = mock_run.call_args[0][0]
        assert "--no-sort" in call_args


class TestFzfMenuBuildCommand:
    """Tests for FzfMenu command construction."""

    def test_multi_mode_adds_flag(self, mocker):
        """Multi mode adds --multi flag."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        mock_run = mocker.patch("subprocess.run")
        mock_run.return_value = MagicMock(returncode=130, stdout="")

        menu = FzfMenu(multi=True)
        menu.add_option("opt1")
        menu.show()

        call_args = mock_run.call_args[0][0]
        assert "--multi" in call_args

    def test_non_multi_mode_adds_no_multi_flag(self, mocker):
        """Non-multi mode adds --no-multi flag."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        mock_run = mocker.patch("subprocess.run")
        mock_run.return_value = MagicMock(returncode=130, stdout="")

        menu = FzfMenu(multi=False)
        menu.add_option("opt1")
        menu.show()

        call_args = mock_run.call_args[0][0]
        assert "--no-multi" in call_args

    def test_ansi_mode_adds_flag(self, mocker):
        """ANSI mode adds --ansi flag."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        mock_run = mocker.patch("subprocess.run")
        mock_run.return_value = MagicMock(returncode=130, stdout="")

        menu = FzfMenu(ansi=True)
        menu.add_option("opt1")
        menu.show()

        call_args = mock_run.call_args[0][0]
        assert "--ansi" in call_args

    def test_uses_tab_delimiter(self, mocker):
        """Menu uses tab as field delimiter."""
        mocker.patch("shutil.which", return_value="/usr/bin/fzf")
        mock_run = mocker.patch("subprocess.run")
        mock_run.return_value = MagicMock(returncode=130, stdout="")

        menu = FzfMenu()
        menu.add_option("opt1", "display")
        menu.show()

        call_args = mock_run.call_args[0][0]
        assert "--delimiter" in call_args
        delim_idx = call_args.index("--delimiter")
        assert call_args[delim_idx + 1] == "\t"
