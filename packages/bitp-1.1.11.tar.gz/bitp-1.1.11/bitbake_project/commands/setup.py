#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Setup and create commands - OE/Yocto build environment and project creation."""

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from typing import Dict, List, Optional, Tuple

from ..core import Colors, fzf_available, get_fzf_color_args, get_fzf_preview_resize_bindings, load_defaults, save_defaults, terminal_color
from ..fzf_bindings import get_position_binding, get_preview_header_suffix, get_preview_scroll_bindings, get_preview_toggle_binding
from .common import add_extra_repo, add_layer_to_bblayers, build_inline_dialog_lines, build_layer_collection_map, extract_layer_paths, resolve_bblayers_path, write_ignore_file
from .confjson import (
    ConfConfig,
    ConfJson,
    ConfOneOfCategory,
    ConfSource,
    discover_registry,
    find_registry_dirs,
    parse_conf_json,
)

def run_init(args) -> int:
    """Show OE/Yocto build environment setup command."""
    layers_dir = args.layers_dir

    # Hint if there's an unapplied config
    defaults_file = getattr(args, "defaults_file", ".bit.defaults")
    if os.path.isfile(defaults_file):
        try:
            _defaults = load_defaults(defaults_file)
            _conf_meta = _defaults.get("__conf_json__", {})
            if _conf_meta and not _conf_meta.get("applied", True):
                selected = _conf_meta.get("selected", "")
                print(f"{Colors.yellow('Note:')} Configuration {Colors.bold(selected) + ' ' if selected else ''}has not been applied yet.")
                print(f"  Run {Colors.cyan('bit setup apply')} to initialize the build environment and apply layers/fragments.")
                print()
        except (json.JSONDecodeError, OSError):
            pass

    # Find oe-init-build-env script
    init_scripts = []
    if os.path.isdir(layers_dir):
        for root, dirs, files in os.walk(layers_dir):
            # Don't descend too deep
            depth = root[len(layers_dir):].count(os.sep)
            if depth >= 3:
                dirs[:] = []
                continue
            if "oe-init-build-env" in files:
                init_scripts.append(os.path.join(root, "oe-init-build-env"))

    if not init_scripts:
        # Try current directory
        if os.path.isfile("oe-init-build-env"):
            init_scripts.append("./oe-init-build-env")

    if not init_scripts:
        print(f"Could not find oe-init-build-env in {layers_dir}/")
        print("Try running from your OE/Yocto project root, or use --layers-dir")
        return 1

    init_script = init_scripts[0]  # Use first found

    # Find template directories (conf/templates/default pattern)
    templates = []
    if os.path.isdir(layers_dir):
        for root, dirs, files in os.walk(layers_dir):
            depth = root[len(layers_dir):].count(os.sep)
            if depth >= 6:
                dirs[:] = []
                continue
            # Check if this directory contains conf/templates/default
            template_path = os.path.join(root, "conf", "templates", "default")
            if os.path.isdir(template_path):
                templates.append(template_path)

    # Let user pick template if multiple
    selected_template = None
    if templates:
        # Prefer meta-poky template if available
        poky_templates = [t for t in templates if "meta-poky" in t]
        if len(templates) == 1:
            selected_template = templates[0]
        elif poky_templates:
            selected_template = poky_templates[0]
            if len(templates) > 1:
                print(f"Found {len(templates)} templates, using: {selected_template}")
                print(f"Others: {', '.join(t for t in templates if t != selected_template)}")
        else:
            # Use fzf if available and we have a tty
            if shutil.which("fzf") and sys.stdin.isatty():
                try:
                    result = subprocess.run(
                        ["fzf", "--height", "~10", "--header", "Select template (or Esc for none):"] + get_fzf_color_args(),
                        input="\n".join(templates),
                        stdout=subprocess.PIPE,
                        text=True,
                    )
                    if result.returncode == 0 and result.stdout.strip():
                        selected_template = result.stdout.strip()
                except Exception:
                    pass

            if not selected_template:
                # Fall back to numbered selection or first one
                if sys.stdin.isatty():
                    print("Multiple templates found:")
                    for i, t in enumerate(templates, 1):
                        print(f"  {i}. {t}")
                    print("  0. (none)")
                    try:
                        choice = input("Select template number: ").strip()
                        if choice and choice != "0":
                            idx = int(choice) - 1
                            if 0 <= idx < len(templates):
                                selected_template = templates[idx]
                    except (ValueError, EOFError):
                        selected_template = templates[0]
                else:
                    selected_template = templates[0]

    # Build the command
    print()
    print(Colors.bold("Run this command to set up the build environment:"))
    print()

    if selected_template:
        # Make paths relative to current dir
        template_rel = os.path.relpath(selected_template)
        init_rel = os.path.relpath(init_script)
        cmd = f"TEMPLATECONF=$PWD/{template_rel} source ./{init_rel}"
    else:
        init_rel = os.path.relpath(init_script)
        cmd = f"source ./{init_rel}"

    print(f"  {Colors.cyan(cmd)}")
    print()

    # Copy to clipboard if possible
    try:
        if shutil.which("xclip"):
            subprocess.run(["xclip", "-selection", "clipboard"], input=cmd.encode(), check=True)
            print(Colors.dim("(copied to clipboard)"))
        elif shutil.which("xsel"):
            subprocess.run(["xsel", "--clipboard", "--input"], input=cmd.encode(), check=True)
            print(Colors.dim("(copied to clipboard)"))
    except Exception:
        pass

    return 0


def run_init_shell(args) -> int:
    """Start a new shell with OE/Yocto build environment sourced."""
    import tempfile

    layers_dir = args.layers_dir

    # Find oe-init-build-env script (same logic as run_init)
    init_scripts = []
    if os.path.isdir(layers_dir):
        for root, dirs, files in os.walk(layers_dir):
            depth = root[len(layers_dir):].count(os.sep)
            if depth >= 3:
                dirs[:] = []
                continue
            if "oe-init-build-env" in files:
                init_scripts.append(os.path.join(root, "oe-init-build-env"))

    if not init_scripts:
        if os.path.isfile("oe-init-build-env"):
            init_scripts.append("./oe-init-build-env")

    if not init_scripts:
        # No OE infrastructure found — fall back to a plain shell in the
        # project directory so the user still gets a usable environment.
        shell = os.environ.get("SHELL", "/bin/bash")
        cwd = os.getcwd()
        print(f"No oe-init-build-env found in {layers_dir}/")
        print(Colors.bold(f"Starting shell in {cwd}"))
        print()
        result = subprocess.run([shell], cwd=cwd)
        return result.returncode

    init_script = os.path.abspath(init_scripts[0])

    # Find template directories
    templates = []
    if os.path.isdir(layers_dir):
        for root, dirs, files in os.walk(layers_dir):
            depth = root[len(layers_dir):].count(os.sep)
            if depth >= 6:
                dirs[:] = []
                continue
            template_path = os.path.join(root, "conf", "templates", "default")
            if os.path.isdir(template_path):
                templates.append(template_path)

    # Select template (prefer meta-poky)
    selected_template = None
    if templates:
        poky_templates = [t for t in templates if "meta-poky" in t]
        if len(templates) == 1:
            selected_template = templates[0]
        elif poky_templates:
            selected_template = poky_templates[0]
        elif shutil.which("fzf") and sys.stdin.isatty():
            try:
                result = subprocess.run(
                    ["fzf", "--height", "~10", "--header", "Select template (or Esc for none):"] + get_fzf_color_args(),
                    input="\n".join(templates),
                    stdout=subprocess.PIPE,
                    text=True,
                )
                if result.returncode == 0 and result.stdout.strip():
                    selected_template = result.stdout.strip()
            except Exception:
                pass
        if not selected_template and templates:
            selected_template = templates[0]

    if selected_template:
        selected_template = os.path.abspath(selected_template)

    # Determine which shell to use
    shell = os.environ.get("SHELL", "/bin/bash")
    shell_name = os.path.basename(shell)

    # Build the source command
    cwd = os.getcwd()
    if selected_template:
        source_cmd = f'export TEMPLATECONF="{selected_template}" && source "{init_script}"'
    else:
        source_cmd = f'source "{init_script}"'

    print(Colors.bold("Starting shell with OE/Yocto build environment..."))
    print(f"  Init script: {Colors.cyan(init_script)}")
    if selected_template:
        print(f"  Template: {Colors.cyan(selected_template)}")
    print()

    # Create a temporary rcfile that sources the init script
    # This ensures the environment is set up when the shell starts
    if shell_name in ("bash", "sh"):
        # For bash, create an rcfile that sources user's bashrc then the init script
        with tempfile.NamedTemporaryFile(mode="w", suffix=".bashrc", delete=False) as f:
            f.write("# Temporary rcfile for bit init shell\n")
            # Source user's bashrc first for their customizations
            bashrc = os.path.expanduser("~/.bashrc")
            if os.path.isfile(bashrc):
                f.write(f'[ -f "{bashrc}" ] && source "{bashrc}"\n')
            # Change to original directory (sourcing init script changes cwd)
            f.write(f'cd "{cwd}"\n')
            # Source the OE init script
            f.write(f'{source_cmd}\n')
            # Set a custom prompt to indicate we're in a bit shell
            f.write('export PS1="(oe) $PS1"\n')
            rcfile = f.name

        try:
            # Start bash with our custom rcfile
            result = subprocess.run([shell, "--rcfile", rcfile])
            return result.returncode
        finally:
            # Clean up temp file
            try:
                os.unlink(rcfile)
            except Exception:
                pass

    elif shell_name == "zsh":
        # For zsh, use ZDOTDIR to point to a temp directory with our .zshrc
        with tempfile.TemporaryDirectory() as tmpdir:
            zshrc = os.path.join(tmpdir, ".zshrc")
            with open(zshrc, "w") as f:
                f.write("# Temporary zshrc for bit init shell\n")
                # Source user's zshrc first
                user_zshrc = os.path.expanduser("~/.zshrc")
                if os.path.isfile(user_zshrc):
                    f.write(f'[ -f "{user_zshrc}" ] && source "{user_zshrc}"\n')
                f.write(f'cd "{cwd}"\n')
                f.write(f'{source_cmd}\n')
                f.write('export PS1="(oe) $PS1"\n')

            env = os.environ.copy()
            env["ZDOTDIR"] = tmpdir
            result = subprocess.run([shell], env=env)
            return result.returncode

    else:
        # Fallback: use bash -c to source and exec
        print(f"Note: Using bash instead of {shell_name}")
        bash_cmd = f'{source_cmd} && exec bash'
        result = subprocess.run(["bash", "-c", bash_cmd])
        return result.returncode


def _fzf_pick_config(configs: List[ConfConfig], header: str = "") -> Optional[ConfConfig]:
    """Use fzf to pick one configuration from a list. Returns None on cancel."""
    if not configs:
        return None

    if len(configs) == 1:
        return configs[0]

    if not fzf_available():
        # Text fallback
        print("Available configurations:")
        for i, cfg in enumerate(configs, 1):
            print(f"  {i}. {cfg.name}  {Colors.dim(cfg.description)}")
        try:
            choice = input("Select configuration number: ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(configs):
                return configs[idx]
        except (ValueError, EOFError, KeyboardInterrupt):
            pass
        return None

    # Build fzf input: name\tdisplay
    lines = []
    max_name = max(len(c.name) for c in configs)
    for cfg in configs:
        lines.append(f"{cfg.name}\t{cfg.name:<{max_name}}  {cfg.description}")

    fzf_header = header or "Select a configuration:"
    fzf_args = [
        "fzf",
        "--ansi",
        "--height", "~20",
        "--layout=reverse-list",
        "--header", fzf_header,
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]
    fzf_args.extend(get_fzf_color_args())

    result = subprocess.run(
        fzf_args,
        input="\n".join(lines),
        stdout=subprocess.PIPE,
        text=True,
    )
    if result.returncode != 0 or not result.stdout.strip():
        return None

    selected_name = result.stdout.strip().split("\t")[0]
    return next((c for c in configs if c.name == selected_name), None)


def _fzf_registry_pick(registry_entries: List[Tuple[str, str, str, ConfJson, str]]) -> Optional[Tuple[str, ConfJson, ConfConfig]]:
    """
    One-shot config picker from registry entries.

    Returns (file_path, parsed_conf, selected_config) or None on cancel.
    Used by bootstrap --config and dashboard create (which do their own clone flow).
    """
    if not registry_entries:
        print("No .conf.json files found in registry directories.")
        return None

    items: List[Tuple[str, str, str, ConfJson, ConfConfig, str]] = []
    for fname, full_path, rel_path, conf, source_label in registry_entries:
        for cfg in conf.configurations:
            items.append((fname, full_path, rel_path, conf, cfg, source_label))

    if not items:
        print("No configurations found in registry files.")
        return None

    if not fzf_available():
        for i, (fname, full_path, rel_path, conf, cfg, source_label) in enumerate(items, 1):
            label_str = f" [{source_label}]" if source_label else ""
            print(f"  {i}.{label_str} {cfg.name}  {Colors.dim(cfg.description)}  ({fname})")
        try:
            choice = input("Select configuration number: ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(items):
                _, full_path, _, conf, cfg, _ = items[idx]
                return (full_path, conf, cfg)
        except (ValueError, EOFError, KeyboardInterrupt):
            pass
        return None

    lines = []
    max_name = max(len(item[4].name) for item in items)
    max_fname = max(len(item[0].replace(".conf.json", "")) for item in items)
    all_labels = [item[5] for item in items] + ["Basic"]
    max_label = max(len(f'[{lb}]') for lb in all_labels if lb)
    for fname, full_path, rel_path, conf, cfg, source_label in items:
        key = f"{rel_path}:{cfg.name}"
        if source_label == "User":
            padded = f'[{source_label}]'.ljust(max_label)
            label_str = Colors.green(padded) + " "
        elif source_label:
            padded = f'[{source_label}]'.ljust(max_label)
            label_str = Colors.dim(padded) + " "
        else:
            label_str = ""
        short_fname = fname.replace(".conf.json", "")
        lines.append(f"{key}\t{label_str}{Colors.cyan(f'{short_fname:<{max_fname}}')}  {cfg.name:<{max_name}}  {cfg.description}")

    # Add "Basic clone" entry at the end (appears at top in reverse-list)
    basic_padded = "[Basic]".ljust(max_label)
    basic_label = Colors.dim(basic_padded) + " "
    basic_desc = "Clone bitbake + oe-core + meta-yocto (no .conf.json)"
    lines.append(f"{BASIC_CLONE_SENTINEL}\t{basic_label}{Colors.cyan(f'{'---':<{max_fname}}')}  {'basic':<{max_name}}  {basic_desc}")

    fzf_args = [
        "fzf",
        "--ansi",
        "--height", "~40%",
        "--layout=reverse-list",
        "--header", "Select a configuration (Enter=select, Esc=cancel):",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]
    fzf_args.extend(get_fzf_color_args())

    result = subprocess.run(
        fzf_args,
        input="\n".join(lines),
        stdout=subprocess.PIPE,
        text=True,
    )

    if result.returncode != 0 or not result.stdout.strip():
        return None

    selected_key = result.stdout.strip().split("\t")[0]

    if selected_key == BASIC_CLONE_SENTINEL:
        return (BASIC_CLONE_SENTINEL, None, None)

    for fname, full_path, rel_path, conf, cfg, source_label in items:
        key = f"{rel_path}:{cfg.name}"
        if key == selected_key:
            return (full_path, conf, cfg)

    return None


_ACTION_PREFIX = "ACT:"
BASIC_CLONE_SENTINEL = "__basic_clone__"

_REGISTRY_ACTIONS_BASE = [
    ("clone", "Clone", "Clone repos from this configuration"),
    ("apply", "Apply", "Apply layers and fragments to current build"),
    ("copy", "Copy", "Copy to user registry"),
]

_REGISTRY_ACTIONS_USER = [
    ("clone", "Clone", "Clone repos from this configuration"),
    ("apply", "Apply", "Apply layers and fragments to current build"),
    ("copy", "Copy", "Duplicate in user registry"),
    ("describe", "Describe", "Set description text"),
    ("edit", "Edit", "Open in editor"),
    ("rename", "Rename", "Rename file in registry"),
    ("delete", "Delete", "Remove from registry"),
]

_REFRESH_SENTINEL = -2


def _build_registry_action_lines(config_name: str, source_label: str = "") -> List[str]:
    """Build inline action dialog lines for the registry browser."""
    actions = _REGISTRY_ACTIONS_USER if source_label == "User" else _REGISTRY_ACTIONS_BASE
    items = [
        (f"{_ACTION_PREFIX}{key}", f"{label:<8} {desc}")
        for key, label, desc in actions
    ]
    return build_inline_dialog_lines(config_name, items, reverse_list=True)


def _fzf_registry_browser(registry_entries: List[Tuple[str, str, str, ConfJson, str]],
                           args=None) -> int:
    """
    Browse registry .conf.json files with fzf (inline dialog pattern).

    Uses a while-True loop. Selecting a config shows an inline action dialog;
    Esc from the dialog returns to the browser; Esc from the browser exits.

    Args:
        registry_entries: List of (filename, full_path, relative_path, parsed_config, source_label)
        args: CLI args namespace (for layers_dir, defaults_file, bblayers)

    Returns exit code (0 = ok).
    """
    if not registry_entries:
        print("No .conf.json files found in registry directories.")
        return 0

    # Flatten: for each conf.json, list all leaf configs
    items: List[Tuple[str, str, str, ConfJson, ConfConfig, str]] = []
    for fname, full_path, rel_path, conf, source_label in registry_entries:
        for cfg in conf.configurations:
            items.append((fname, full_path, rel_path, conf, cfg, source_label))

    if not items:
        print("No configurations found in registry files.")
        return 0

    if not fzf_available():
        # Text fallback — one-shot pick
        for i, (fname, full_path, rel_path, conf, cfg, source_label) in enumerate(items, 1):
            label_str = f" [{source_label}]" if source_label else ""
            print(f"  {i}.{label_str} {cfg.name}  {Colors.dim(cfg.description)}  ({fname})")
        try:
            choice = input("Select configuration number: ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(items):
                _, full_path, _, conf, cfg, _ = items[idx]
                if args is not None:
                    return _dispatch_registry_action(cfg, conf, full_path, args)
        except (ValueError, EOFError, KeyboardInterrupt):
            pass
        return 0

    # Build config lines (stable across iterations)
    config_lines = []
    max_name = max(len(item[4].name) for item in items)
    max_fname = max(len(item[0].replace(".conf.json", "")) for item in items)
    all_labels = [item[5] for item in items]
    max_label = max((len(f'[{lb}]') for lb in all_labels if lb), default=0)
    for fname, full_path, rel_path, conf, cfg, source_label in items:
        key = f"{rel_path}:{cfg.name}"
        if source_label == "User":
            padded = f'[{source_label}]'.ljust(max_label)
            label_str = Colors.green(padded) + " "
        elif source_label:
            padded = f'[{source_label}]'.ljust(max_label)
            label_str = Colors.dim(padded) + " "
        else:
            label_str = ""
        short_fname = fname.replace(".conf.json", "")
        config_lines.append(f"{key}\t{label_str}{Colors.cyan(f'{short_fname:<{max_fname}}')}  {cfg.name:<{max_name}}  {cfg.description}")

    # Build preview data
    preview_data: Dict[str, dict] = {}
    for fname, full_path, rel_path, conf, cfg, source_label in items:
        key = f"{rel_path}:{cfg.name}"
        preview_data[key] = {
            "name": cfg.name,
            "description": cfg.description,
            "sources": [{"name": s.name, "url": s.git_url or s.local_path, "rev": s.rev} for s in conf.sources],
            "bb_layers": cfg.bb_layers,
            "oe_fragments": cfg.oe_fragments,
            "one_of": {k: {"description": v.description, "options": [o.name for o in v.options]}
                       for k, v in cfg.oe_fragments_one_of.items()},
        }

    preview_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
    json.dump(preview_data, preview_file)
    preview_file.close()

    preview_script = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
    preview_script.write(f'''#!/usr/bin/env python3
import json, sys
key = sys.argv[1].strip("'\\"") if len(sys.argv) > 1 else ""
with open("{preview_file.name}") as f:
    data = json.load(f)
cfg = data.get(key, {{}})
if not cfg:
    print(f"No data for: {{key}}")
    sys.exit(0)
print(f"\\033[1m{{cfg.get('name', '')}}\\033[0m")
if cfg.get('description'):
    print(f"  {{cfg['description']}}")
print()
print("\\033[36mSources:\\033[0m")
for s in cfg.get('sources', []):
    print(f"  {{s['name']:<25}} {{s.get('url','')}} ({{s.get('rev','')}})")
print()
if cfg.get('bb_layers'):
    print("\\033[36mLayers:\\033[0m")
    for l in cfg['bb_layers']:
        print(f"  {{l}}")
    print()
if cfg.get('oe_fragments'):
    print("\\033[36mFragments:\\033[0m")
    for f in cfg['oe_fragments']:
        print(f"  {{f}}")
    print()
if cfg.get('one_of'):
    print("\\033[36mChoose one-of:\\033[0m")
    for cat, info in cfg['one_of'].items():
        print(f"  {{cat}}: {{info.get('description','')}}")
        for opt in info.get('options', []):
            print(f"    - {{opt}}")
''')
    preview_script.close()

    preview_cmd = f'python3 "{preview_script.name}" {{1}}'

    # Loop state
    show_actions = False
    selected_config_key = ""
    selected_source_label = ""
    # Name input mode: used for rename, copy, and describe
    name_input_action = ""   # "rename", "copy", or "describe", empty = inactive
    name_input_file = ""     # source file path
    name_input_description = ""  # current description (for describe action)

    try:
        while True:
            # Build fzf input for this iteration
            menu_lines = list(config_lines)
            if show_actions:
                # Find config name for dialog header
                config_name = ""
                for fname, full_path, rel_path, conf, cfg, source_label in items:
                    if f"{rel_path}:{cfg.name}" == selected_config_key:
                        config_name = cfg.name
                        break
                action_lines = _build_registry_action_lines(config_name, selected_source_label)
                # reverse-list: APPEND to put actions at visual bottom (near prompt)
                menu_lines = menu_lines + action_lines

            fzf_args = [
                "fzf",
                "--no-sort",
                "--ansi",
                "--height", "100%",
                "--layout=reverse-list",
                "--with-nth", "2..",
                "--delimiter", "\t",
                "--preview", preview_cmd,
                "--preview-window", "right,60%,wrap",
            ] + get_preview_toggle_binding() \
              + get_preview_scroll_bindings() \
              + get_fzf_preview_resize_bindings()

            if name_input_action:
                if name_input_action == "describe":
                    header = "Type description, Enter=confirm  (Esc=cancel)"
                    fzf_args.extend([
                        "--print-query",
                        "--disabled",
                        "--query", name_input_description,
                        "--header", header,
                        "--prompt", "Desc: ",
                    ])
                else:
                    # Text input mode for rename or copy
                    current_name = os.path.basename(name_input_file)
                    if current_name.endswith(".conf.json"):
                        current_name = current_name[:-len(".conf.json")]
                    if name_input_action == "rename":
                        header = "Type new name, Enter=confirm  (Esc=cancel)"
                    else:
                        header = "Name for registry copy, Enter=confirm  (Esc=cancel)"
                    fzf_args.extend([
                        "--print-query",
                        "--disabled",
                        "--query", current_name,
                        "--header", header,
                        "--prompt", "Name: ",
                    ])
            elif show_actions:
                # Position cursor on first action (Clone), which is right after
                # the separator header appended after config_lines
                first_action_pos = len(config_lines) + 2  # +1 for header, +1 for 1-indexed
                fzf_args.extend([
                    "--disabled",
                    "--header", f"Select action for {config_name}  Esc=back",
                    "--prompt", "Action: ",
                ])
                fzf_args.extend(get_position_binding(first_action_pos))
                # Pin preview to the selected config (last-wins overrides earlier --preview)
                fzf_args.extend(["--preview", f'python3 "{preview_script.name}" \'{selected_config_key}\''])
            else:
                fzf_args.extend([
                    "--header", f"Enter=select  Esc=quit\n{get_preview_header_suffix()}",
                    "--prompt", "Config: ",
                ])

            fzf_args.extend(get_fzf_color_args())

            result = subprocess.run(
                fzf_args,
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )

            # Handle name input mode result (rename, copy, or describe)
            if name_input_action:
                action = name_input_action
                source = name_input_file
                name_input_action = ""
                name_input_file = ""
                name_input_description = ""
                lines = result.stdout.splitlines()
                query = lines[0].strip() if lines else ""
                if not query or result.returncode != 0:
                    continue  # cancelled
                if action == "describe":
                    try:
                        with open(source, "r", encoding="utf-8") as f:
                            data = json.load(f)
                        data["description"] = query
                        for cfg_entry in data.get("bitbake-setup", {}).get("configurations", []):
                            cfg_entry["description"] = query
                        with open(source, "w", encoding="utf-8") as f:
                            json.dump(data, f, indent=2)
                            f.write("\n")
                    except (json.JSONDecodeError, OSError):
                        pass
                else:
                    new_name = query
                    if not new_name.endswith(".conf.json"):
                        new_name += ".conf.json"
                    if action == "rename":
                        old_dir = os.path.dirname(source)
                        new_path = os.path.join(old_dir, new_name)
                        if new_path != source:
                            if os.path.exists(new_path):
                                continue  # target exists, skip
                            os.rename(source, new_path)
                    else:  # copy
                        registry_dir = os.path.expanduser("~/.config/bit/registry")
                        os.makedirs(registry_dir, exist_ok=True)
                        target = os.path.join(registry_dir, new_name)
                        if os.path.exists(target) and target != source:
                            continue  # target exists, skip
                        shutil.copy2(source, target)
                return _REFRESH_SENTINEL

            # Esc / cancel
            if result.returncode != 0 or not result.stdout.strip():
                if show_actions:
                    show_actions = False
                    continue
                return 0

            output_key = result.stdout.strip().split("\t")[0]

            if show_actions:
                show_actions = False
                if output_key.startswith(_ACTION_PREFIX):
                    action = output_key[len(_ACTION_PREFIX):]
                    # Find the selected config
                    for fname, full_path, rel_path, conf, cfg, source_label in items:
                        if f"{rel_path}:{cfg.name}" == selected_config_key:
                            if action in ("rename", "copy", "describe"):
                                name_input_action = action
                                name_input_file = full_path
                                if action == "describe":
                                    name_input_description = cfg.description
                                break
                            if args is not None:
                                rc = _execute_registry_action(action, cfg, conf, full_path, args)
                                if rc == _REFRESH_SENTINEL:
                                    return _REFRESH_SENTINEL
                                if rc != 0:
                                    return rc
                            break
                continue

            # Config selected → show action dialog
            if output_key in ("---", ""):
                continue
            selected_config_key = output_key
            # Track which registry source this config came from
            for fname, full_path, rel_path, conf, cfg, source_label in items:
                if f"{rel_path}:{cfg.name}" == output_key:
                    selected_source_label = source_label
                    break
            show_actions = True

    finally:
        for f in [preview_file.name, preview_script.name]:
            try:
                os.unlink(f)
            except OSError:
                pass


def _execute_registry_action(action: str, selected_config: ConfConfig,
                             conf: ConfJson, conf_file_path: str, args) -> int:
    """Execute an action from the registry browser inline dialog. Returns exit code."""
    layers_dir = getattr(args, "layers_dir", "layers")
    defaults_file = getattr(args, "defaults_file", ".bit.defaults")

    if action == "clone":
        rc = _clone_from_config(conf, selected_config, layers_dir, do_clone=True,
                                defaults_file=defaults_file, fallback_branch="")
        if rc == 0:
            defaults = load_defaults(defaults_file)
            conf_meta = defaults.get("__conf_json__", {})
            conf_meta["file"] = conf_file_path
            defaults["__conf_json__"] = conf_meta
            save_defaults(defaults_file, defaults)

            register_dir = os.path.abspath(os.getcwd())
            from .projects import add_project
            name = os.path.basename(register_dir)
            add_project(register_dir, name)
        return rc

    elif action == "apply":
        import argparse as _ap
        apply_args = _ap.Namespace(
            config=conf_file_path,
            defaults_file=defaults_file,
            layers_dir=layers_dir,
            bblayers=getattr(args, "bblayers", None),
        )
        return run_setup_apply(apply_args)

    elif action == "edit":
        from .projects import resolve_editor
        editor = resolve_editor()
        subprocess.run([editor, conf_file_path])
        return _REFRESH_SENTINEL

    elif action == "delete":
        os.unlink(conf_file_path)
        return _REFRESH_SENTINEL

    return 0


def _dispatch_registry_action(selected_config: ConfConfig, conf: ConfJson,
                               conf_file_path: str, args) -> int:
    """Text fallback: show numbered action menu after config selection."""
    actions = _REGISTRY_ACTIONS_BASE
    print(f"\nAction for: {Colors.bold(selected_config.name)}")
    for i, (key, label, desc) in enumerate(actions, 1):
        print(f"  {i}. {label} - {desc}")
    try:
        choice = input("Select action: ").strip()
        idx = int(choice) - 1
        if 0 <= idx < len(actions):
            return _execute_registry_action(actions[idx][0], selected_config, conf, conf_file_path, args)
    except (ValueError, EOFError, KeyboardInterrupt):
        pass
    return 0


def _fzf_pick_one_of(category_name: str, category: ConfOneOfCategory) -> Optional[str]:
    """
    Use fzf to pick one fragment from a one-of category.

    Returns selected fragment name or None on cancel.
    """
    if not category.options:
        return None

    if not fzf_available():
        # Text fallback
        print(f"\n{category_name}: {category.description}")
        for i, opt in enumerate(category.options, 1):
            desc = f"  {opt.description}" if opt.description else ""
            print(f"  {i}. {opt.name}{desc}")
        try:
            choice = input("Select: ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(category.options):
                return category.options[idx].name
        except (ValueError, EOFError, KeyboardInterrupt):
            pass
        return None

    # Build fzf input
    lines = []
    max_name = max(len(o.name) for o in category.options)
    for opt in category.options:
        desc = opt.description or ""
        lines.append(f"{opt.name}\t{opt.name:<{max_name}}  {desc}")

    header = f"{category_name}: {category.description}"
    fzf_args = [
        "fzf",
        "--ansi",
        "--height", "~15",
        "--layout=reverse-list",
        "--header", header,
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]
    fzf_args.extend(get_fzf_color_args())

    result = subprocess.run(
        fzf_args,
        input="\n".join(lines),
        stdout=subprocess.PIPE,
        text=True,
    )
    if result.returncode != 0 or not result.stdout.strip():
        return None

    return result.stdout.strip().split("\t")[0]


def _clone_from_config(
    conf: ConfJson,
    selected_config: ConfConfig,
    layers_dir: str,
    do_clone: bool,
    defaults_file: str,
    fallback_branch: str = "",
) -> int:
    """Clone repos from a parsed .conf.json config, or show dry-run commands."""
    sources = conf.sources

    print()
    print(Colors.bold(f"Configuration: {selected_config.name}"))
    if selected_config.description:
        print(f"  {selected_config.description}")
    print()

    print(Colors.bold(f"Sources to clone ({len(sources)} repos):"))
    print()

    clone_cmds = []
    for src in sources:
        if src.is_local:
            target = os.path.join(layers_dir, src.path)
            print(f"  {Colors.cyan(src.name)}: local symlink")
            print(f"    {Colors.dim(f'ln -s {src.local_path} {target}')}")
            clone_cmds.append(("symlink", src, target))
        else:
            branch = src.branch or src.rev or fallback_branch or "master"
            target = os.path.join(layers_dir, src.path)
            url = src.git_url
            cmd_str = f"git clone -b {branch} {url} {target}"
            print(f"  {Colors.cyan(src.name)}: {Colors.dim(url)}")
            print(f"    {Colors.dim(cmd_str)}")
            clone_cmds.append(("clone", src, target))
        print()

    if selected_config.bb_layers:
        print(Colors.bold("Layers:"))
        for layer in selected_config.bb_layers:
            print(f"  {layer}")
        print()

    if selected_config.oe_fragments:
        print(Colors.bold("Fragments:"))
        for frag in selected_config.oe_fragments:
            print(f"  {frag}")
        print()

    if selected_config.oe_fragments_one_of:
        print(Colors.bold("Choose one-of (applied during 'bit setup apply'):"))
        for cat_name, cat in selected_config.oe_fragments_one_of.items():
            options_str = ", ".join(o.name for o in cat.options)
            print(f"  {cat_name}: {options_str}")
        print()

    if not do_clone:
        print(Colors.dim("Add --doit to clone, or copy/paste the commands manually."))
        return 0

    # Execute cloning
    os.makedirs(layers_dir, exist_ok=True)

    print(Colors.bold("Cloning repositories..."))
    print()

    non_layer_repos = []
    for action, src, target in clone_cmds:
        if action == "symlink":
            if os.path.exists(target):
                print(f"  {Colors.yellow('skip')} {src.name} (already exists)")
                continue
            os.symlink(src.local_path, target)
            print(f"  {Colors.green('link')} {src.name} -> {src.local_path}")
        else:
            if os.path.isdir(target):
                print(f"  {Colors.yellow('skip')} {src.name} (already exists)")
                continue

            branch = src.branch or src.rev or fallback_branch or "master"
            print(f"  {Colors.cyan('clone')} {src.name}...")
            result = subprocess.run(
                ["git", "clone", "-b", branch, src.git_url, target],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                print(f"    {Colors.red('failed')}: {result.stderr.strip()}")
                return 1
            print(f"    {Colors.green('done')}")

            # Add additional remotes if specified
            if len(src.remotes) > 1:
                for remote_name, remote_uri in src.remotes.items():
                    if remote_name == "origin":
                        continue
                    subprocess.run(
                        ["git", "-C", target, "remote", "add", remote_name, remote_uri],
                        capture_output=True,
                        text=True,
                    )
                    print(f"    {Colors.dim(f'added remote: {remote_name}')}")

        # Track repos that aren't layers (no conf/layer.conf)
        abs_target = os.path.abspath(target)
        layer_conf = os.path.join(abs_target, "conf", "layer.conf")
        if not os.path.isfile(layer_conf):
            non_layer_repos.append(abs_target)

    # Write .ignore
    if write_ignore_file(os.getcwd()):
        print(f"  {Colors.green('wrote')} .ignore (excludes build*/ from searches)")

    # Track non-layer repos in defaults
    defaults = load_defaults(defaults_file)
    for repo_path in non_layer_repos:
        add_extra_repo(defaults_file, defaults, repo_path)

    # Save conf_json metadata
    defaults = load_defaults(defaults_file)
    defaults["__conf_json__"] = {
        "file": "",  # Will be set by caller with the original path
        "selected": selected_config.name,
        "applied": False,
    }
    save_defaults(defaults_file, defaults)

    print()
    print(Colors.green("Clone complete!"))
    print()
    print("Next step:")
    print(f"  {Colors.cyan('bit setup apply')}  (initialize build env + apply layers and fragments)")

    return 0


def run_bootstrap(args) -> int:
    """Clone core Yocto/OE repositories for a new project."""
    config_path = getattr(args, "config", None)

    # --config mode: clone from .conf.json
    if config_path is not None:
        return _run_bootstrap_config(args, config_path)

    # Default mode: hardcoded 3 repos
    branch = args.branch
    layers_dir = args.layers_dir
    do_clone = args.clone

    # Core repos for Yocto/OE setup
    # See: https://docs.yoctoproject.org/dev-manual/poky-manual-setup.html
    repos = [
        {
            "name": "bitbake",
            "url": "https://git.openembedded.org/bitbake",
            "desc": "Build engine",
        },
        {
            "name": "openembedded-core",
            "url": "https://git.openembedded.org/openembedded-core",
            "desc": "Core metadata and recipes",
        },
        {
            "name": "meta-yocto",
            "url": "https://git.yoctoproject.org/meta-yocto",
            "desc": "Yocto Project reference distribution (poky)",
        },
    ]

    # Check if layers_dir already exists and has content
    if os.path.isdir(layers_dir) and os.listdir(layers_dir):
        existing = os.listdir(layers_dir)
        print(f"Warning: {layers_dir}/ already exists with: {', '.join(existing[:5])}")
        if len(existing) > 5:
            print(f"  ... and {len(existing) - 5} more")
        if do_clone:
            try:
                resp = input("Continue anyway? [y/N] ").strip().lower()
                if resp != "y":
                    return 1
            except (EOFError, KeyboardInterrupt):
                return 1

    print()
    print(Colors.bold(f"Core Yocto/OE repositories (branch: {branch}):"))
    print()

    clone_cmds = []
    for repo in repos:
        target = os.path.join(layers_dir, repo["name"])
        cmd = f"git clone -b {branch} {repo['url']} {target}"
        clone_cmds.append(cmd)
        print(f"  {Colors.cyan(repo['name'])}: {repo['desc']}")
        print(f"    {Colors.dim(cmd)}")
        print()

    if do_clone:
        # Create layers dir if needed
        os.makedirs(layers_dir, exist_ok=True)

        print(Colors.bold("Cloning repositories..."))
        print()

        for i, (repo, cmd) in enumerate(zip(repos, clone_cmds)):
            target = os.path.join(layers_dir, repo["name"])
            if os.path.isdir(target):
                print(f"  {Colors.yellow('skip')} {repo['name']} (already exists)")
                continue

            print(f"  {Colors.cyan('clone')} {repo['name']}...")
            result = subprocess.run(
                ["git", "clone", "-b", branch, repo["url"], target],
                capture_output=True,
                text=True,
            )
            if result.returncode != 0:
                print(f"    {Colors.red('failed')}: {result.stderr.strip()}")
                return 1
            print(f"    {Colors.green('done')}")

        # Write .ignore so ripgrep/fd/etc skip build directories
        if write_ignore_file(os.getcwd()):
            print(f"  {Colors.green('wrote')} .ignore (excludes build*/ from searches)")

        # Add bitbake to tracked repos (it's not a layer, so won't be auto-discovered)
        bitbake_path = os.path.abspath(os.path.join(layers_dir, "bitbake"))
        if os.path.isdir(bitbake_path):
            defaults_file = args.defaults_file
            defaults = load_defaults(defaults_file)
            add_extra_repo(defaults_file, defaults, bitbake_path)

        print()
        print(Colors.green("Bootstrap complete!"))
        print()
        print("Next steps:")
        print(f"  1. Run: {Colors.cyan(f'bit setup --layers-dir {layers_dir}')}")
        print("  2. Source the environment setup command shown")
        print("  3. Run: bitbake core-image-minimal")
    else:
        print(Colors.dim("Add --doit to clone, or copy/paste the commands manually."))

    return 0


def _run_bootstrap_config(args, config_path: str) -> int:
    """Bootstrap from a .conf.json file or registry browser."""
    layers_dir = args.layers_dir
    do_clone = args.clone
    defaults_file = args.defaults_file
    fallback_branch = getattr(args, "branch", "")

    if config_path == "":
        # --config with no path: registry browser
        registry_dirs = find_registry_dirs()
        if not registry_dirs:
            print("No registry directories found.")
            print(f"  Expected: layers/bitbake/default-registry/")
            print(f"  Or:       ~/.config/bit/registry/")
            return 1

        all_entries: List[Tuple[str, str, str, ConfJson, str]] = []
        for d, label in registry_dirs:
            entries = discover_registry(d, source_label=label)
            all_entries.extend(entries)

        result = _fzf_registry_pick(all_entries)
        if result is None:
            return 0  # Cancelled

        conf_file_path, conf, selected_config = result
        rc = _clone_from_config(conf, selected_config, layers_dir, do_clone, defaults_file, fallback_branch)

        # Save the config file path so 'bit setup apply' can find it later
        if rc == 0 and do_clone:
            defaults = load_defaults(defaults_file)
            conf_meta = defaults.get("__conf_json__", {})
            conf_meta["file"] = conf_file_path
            defaults["__conf_json__"] = conf_meta
            save_defaults(defaults_file, defaults)

        return rc

    # --config <path>: parse specific file
    if not os.path.isfile(config_path):
        print(f"File not found: {config_path}")
        return 1

    try:
        conf = parse_conf_json(config_path)
    except (json.JSONDecodeError, KeyError, OSError) as e:
        print(f"Error parsing {config_path}: {e}")
        return 1

    if not conf.configurations:
        print(f"No configurations found in {config_path}")
        return 1

    # If multiple configs, let user pick
    selected_config = _fzf_pick_config(
        conf.configurations,
        header=f"Configurations in {os.path.basename(config_path)}:",
    )
    if selected_config is None:
        return 0  # Cancelled

    rc = _clone_from_config(conf, selected_config, layers_dir, do_clone, defaults_file, fallback_branch)

    # Save the config file path in defaults
    if rc == 0 and do_clone:
        defaults = load_defaults(defaults_file)
        conf_meta = defaults.get("__conf_json__", {})
        conf_meta["file"] = config_path
        defaults["__conf_json__"] = conf_meta
        save_defaults(defaults_file, defaults)

    return rc


def run_setup_clone(args) -> int:
    """Clone core repos and register as a tracked project."""
    project_dir = getattr(args, "project_dir", None)
    if project_dir:
        project_dir = os.path.abspath(project_dir)
        if not os.path.isdir(project_dir):
            os.makedirs(project_dir, exist_ok=True)
            print(f"Created project directory: {terminal_color('project_active', project_dir)}")
        os.chdir(project_dir)

    result = run_bootstrap(args)
    if result != 0:
        return result

    # Auto-register as tracked project if cloning was executed
    if getattr(args, "clone", False):
        register_dir = project_dir or os.getcwd()
        register_dir = os.path.abspath(register_dir)
        from .projects import add_project
        name = getattr(args, "name", None) or os.path.basename(register_dir)
        add_project(register_dir, name)

    return 0


def _find_bitbake_setup(layers_dir: str = "layers") -> Optional[str]:
    """Find bitbake-setup in the project's layers/bitbake/bin/."""
    candidate = os.path.join(layers_dir, "bitbake", "bin", "bitbake-setup")
    if os.path.isfile(candidate) and os.access(candidate, os.X_OK):
        return os.path.abspath(candidate)
    return None


def _validate_setup(bblayers_path: str, config: "ConfConfig", layers_dir: str) -> List[str]:
    """Check that setup actually completed. Returns list of issues (empty = OK)."""
    issues = []

    # bblayers.conf must exist
    if not os.path.isfile(bblayers_path):
        issues.append("bblayers.conf not found")
        return issues

    # Check that expected layers are present
    try:
        existing = extract_layer_paths(bblayers_path)
    except SystemExit:
        existing = []

    existing_abs = {os.path.abspath(p) for p in existing}
    for layer_rel in config.bb_layers:
        layer_abs = os.path.abspath(os.path.join(layers_dir, layer_rel))
        if os.path.isdir(layer_abs) and layer_abs not in existing_abs:
            issues.append(f"layer not in bblayers.conf: {layer_rel}")

    # local.conf should exist
    conf_dir = os.path.dirname(bblayers_path)
    if not os.path.isfile(os.path.join(conf_dir, "local.conf")):
        issues.append("local.conf not found")

    return issues


def run_setup_apply(args) -> int:
    """Apply layers and fragments from a saved .conf.json configuration."""
    defaults_file = args.defaults_file
    config_path = getattr(args, "config", None)
    layers_dir = getattr(args, "layers_dir", "layers")
    use_bitbake_setup = getattr(args, "bitbake_setup", False)

    # Load config metadata
    if config_path:
        # Explicit --config path
        try:
            conf = parse_conf_json(config_path)
        except (json.JSONDecodeError, KeyError, OSError) as e:
            print(f"Error parsing {config_path}: {e}")
            return 1

        if not conf.configurations:
            print(f"No configurations found in {config_path}")
            return 1

        selected_config = _fzf_pick_config(conf.configurations)
        if selected_config is None:
            return 0
    else:
        # Load from saved defaults
        defaults = load_defaults(defaults_file)
        conf_meta = defaults.get("__conf_json__", {})
        if not conf_meta:
            print("No saved configuration found.")
            print(f"Run '{Colors.cyan('bit setup clone --config <file>')}' first.")
            return 1

        conf_file = conf_meta.get("file", "")
        selected_name = conf_meta.get("selected", "")

        if not conf_file or not os.path.isfile(conf_file):
            print(f"Configuration file not found: {conf_file}")
            return 1

        try:
            conf = parse_conf_json(conf_file)
        except (json.JSONDecodeError, KeyError, OSError) as e:
            print(f"Error parsing {conf_file}: {e}")
            return 1

        selected_config = next(
            (c for c in conf.configurations if c.name == selected_name), None
        )
        if selected_config is None:
            print(f"Configuration '{selected_name}' not found in {conf_file}")
            return 1

    # Find bblayers.conf
    bblayers_path = resolve_bblayers_path(getattr(args, "bblayers", None))
    if not bblayers_path:
        # Delegate to bitbake-setup if requested
        if use_bitbake_setup:
            bs = _find_bitbake_setup(layers_dir)
            if bs:
                print("Initializing build environment via bitbake-setup...")
                result = subprocess.run([bs, "init", selected_config.name])
                if result.returncode != 0:
                    return result.returncode
                bblayers_path = resolve_bblayers_path(None)
                if not bblayers_path:
                    return 1
                issues = _validate_setup(bblayers_path, selected_config, layers_dir)
                if issues:
                    print(Colors.yellow("Setup incomplete:"))
                    for issue in issues:
                        print(f"  {Colors.yellow('!')} {issue}")
                    return 1
                defaults = load_defaults(defaults_file)
                conf_meta = defaults.get("__conf_json__", {})
                conf_meta["applied"] = True
                defaults["__conf_json__"] = conf_meta
                save_defaults(defaults_file, defaults)
                print(Colors.green("Configuration applied!"))
                return 0

        # Auto-initialize build directory
        print("Build environment not initialized.")
        print(f"  Configuration: {Colors.bold(selected_config.name)}")
        if selected_config.description:
            print(f"  {selected_config.description}")
        print(f"  Build dir:     build/conf/")
        if selected_config.bb_layers:
            print(f"  Layers:        {', '.join(selected_config.bb_layers)}")
        print()
        try:
            resp = input("Create build directory and apply? [Y/n] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return 1
        if resp not in ("", "y", "yes"):
            return 1

        print()
        build_conf = os.path.join("build", "conf")
        os.makedirs(build_conf, exist_ok=True)

        # Write minimal bblayers.conf with openembedded-core/meta as base
        oe_meta = os.path.abspath(os.path.join(layers_dir, "openembedded-core", "meta"))
        bblayers_path = os.path.join(build_conf, "bblayers.conf")
        with open(bblayers_path, "w") as f:
            f.write(f'BBLAYERS ?= " \\\n  {oe_meta} \\\n  "\n')

        # Write minimal local.conf
        local_conf_path = os.path.join(build_conf, "local.conf")
        if not os.path.exists(local_conf_path):
            with open(local_conf_path, "w") as f:
                f.write("# Local configuration - created by bit setup apply\n")

        print(f"  {Colors.green('created')} {bblayers_path}")
        print()
        # Fall through to the normal apply logic (add layers, pick fragments)

    print()
    print(Colors.bold(f"Applying configuration: {selected_config.name}"))
    if selected_config.description:
        print(f"  {selected_config.description}")
    print()

    # Apply bb-layers
    if selected_config.bb_layers:
        # Build collection map for dependency resolution
        try:
            existing_layer_paths = extract_layer_paths(bblayers_path)
        except SystemExit:
            existing_layer_paths = []

        # Also scan the layers dir for all available layers
        all_layer_paths = list(existing_layer_paths)
        if os.path.isdir(layers_dir):
            for root, dirs, files in os.walk(layers_dir):
                if "conf" in dirs:
                    layer_conf = os.path.join(root, "conf", "layer.conf")
                    if os.path.isfile(layer_conf) and root not in all_layer_paths:
                        all_layer_paths.append(root)
                depth = root[len(layers_dir):].count(os.sep)
                if depth >= 3:
                    dirs[:] = []

        collection_map = build_layer_collection_map(all_layer_paths)

        print(Colors.bold("Adding layers:"))
        for layer_rel in selected_config.bb_layers:
            layer_path = os.path.abspath(os.path.join(layers_dir, layer_rel))
            if not os.path.isdir(layer_path):
                print(f"  {Colors.yellow('skip')} {layer_rel} (not found: {layer_path})")
                continue

            success, msg, layers_added = add_layer_to_bblayers(
                layer_path, bblayers_path, collection_map,
            )
            if success:
                print(f"  {Colors.green('added')} {layer_rel}")
                # Update collection map with newly added layers
                for lp in layers_added:
                    new_map = build_layer_collection_map([lp])
                    collection_map.update(new_map)
            else:
                print(f"  {Colors.yellow('skip')} {layer_rel} ({msg})")
        print()

    # Apply oe-fragments
    fragments_to_add = list(selected_config.oe_fragments)

    # Handle oe-fragments-one-of: fzf picker per category
    if selected_config.oe_fragments_one_of:
        print(Colors.bold("Select fragment options:"))
        # Present categories in a defined order: machine first, then distro, then others
        ordered_cats = []
        for priority_cat in ("machine", "distro"):
            if priority_cat in selected_config.oe_fragments_one_of:
                ordered_cats.append(priority_cat)
        for cat_name in sorted(selected_config.oe_fragments_one_of.keys()):
            if cat_name not in ordered_cats:
                ordered_cats.append(cat_name)

        for cat_name in ordered_cats:
            category = selected_config.oe_fragments_one_of[cat_name]
            selected = _fzf_pick_one_of(cat_name, category)
            if selected:
                fragments_to_add.append(selected)
                print(f"  {Colors.green('selected')} {cat_name}: {selected}")
            else:
                print(f"  {Colors.dim('skipped')} {cat_name}")
        print()

    if fragments_to_add:
        from .fragment import _update_oe_fragments, _get_toolcfg_path, DEFAULT_BUILTIN_PREFIXES

        toolcfg_path = _get_toolcfg_path(bblayers_path)
        modified = _update_oe_fragments(
            toolcfg_path, fragments_to_add, [], DEFAULT_BUILTIN_PREFIXES,
        )
        if modified:
            print(Colors.bold("Applied fragments:"))
            for frag in fragments_to_add:
                print(f"  {Colors.green('enabled')} {frag}")
        else:
            print(Colors.dim("Fragments already applied."))
        print()

    # Validate setup before marking applied
    issues = _validate_setup(bblayers_path, selected_config, layers_dir)
    if issues:
        print(Colors.yellow("Setup incomplete:"))
        for issue in issues:
            print(f"  {Colors.yellow('!')} {issue}")
        print()
        print(f"Run {Colors.cyan('bit setup apply')} to retry.")
        return 1

    # Mark as applied in defaults
    defaults = load_defaults(defaults_file)
    conf_meta = defaults.get("__conf_json__", {})
    conf_meta["applied"] = True
    defaults["__conf_json__"] = conf_meta
    save_defaults(defaults_file, defaults)

    print(Colors.green("Configuration applied!"))
    return 0


def run_setup_registry_copy(args) -> int:
    """Copy a .conf.json file to the user registry (~/.config/bit/registry/)."""
    file_path = args.file
    force = getattr(args, "force", False)
    alias = getattr(args, "as_name", None)

    if not os.path.isfile(file_path):
        print(f"File not found: {file_path}")
        return 1

    # Validate content
    try:
        parse_conf_json(file_path)
    except (json.JSONDecodeError, KeyError, OSError) as e:
        print(f"Invalid .conf.json file: {e}")
        return 1

    # Determine target name
    if alias:
        basename = alias
        if not basename.endswith(".conf.json"):
            basename += ".conf.json"
    else:
        basename = os.path.basename(file_path)
        if not basename.endswith(".conf.json"):
            basename += ".conf.json"

    registry_dir = os.path.expanduser("~/.config/bit/registry")
    os.makedirs(registry_dir, exist_ok=True)

    target = os.path.join(registry_dir, basename)

    if os.path.exists(target) and not force:
        print(f"File already exists: {target}")
        try:
            resp = input("Overwrite? [y/N] ").strip().lower()
            if resp != "y":
                print("Cancelled.")
                return 0
        except (EOFError, KeyboardInterrupt):
            print()
            return 0

    shutil.copy2(file_path, target)

    print(f"{Colors.green('Copied')} {basename} -> {target}")
    print()
    print("Next steps:")
    print(f"  {Colors.cyan('bit setup configs')}  (browse and manage configurations)")
    return 0


def _gather_export_sources(layer_paths: List[str], layers_dir: str,
                           extra_repos: Optional[List[str]] = None) -> Tuple[Dict[str, dict], Dict[str, str]]:
    """Gather git sources from layer paths and extra repos (e.g. bitbake).

    Returns (sources_dict, git_roots) where sources_dict maps repo name
    to source entry and git_roots maps git root path to first layer path.
    """
    git_roots: Dict[str, str] = {}
    # Include extra repos (non-layer repos like bitbake)
    all_paths = list(layer_paths)
    if extra_repos:
        all_paths.extend(extra_repos)
    for lp in all_paths:
        try:
            result = subprocess.run(
                ["git", "-C", lp, "rev-parse", "--show-toplevel"],
                capture_output=True, text=True,
            )
            if result.returncode == 0:
                root = result.stdout.strip()
                if root not in git_roots:
                    git_roots[root] = lp
        except OSError:
            pass

    sources: Dict[str, dict] = {}
    for root in sorted(git_roots.keys()):
        repo_name = os.path.basename(root)

        remotes: Dict[str, dict] = {}
        try:
            result = subprocess.run(
                ["git", "-C", root, "remote", "-v"],
                capture_output=True, text=True,
            )
            if result.returncode == 0:
                for line in result.stdout.strip().splitlines():
                    parts = line.split()
                    if len(parts) >= 2 and "(fetch)" in line:
                        remotes[parts[0]] = {"uri": parts[1]}
        except OSError:
            pass

        branch = ""
        try:
            result = subprocess.run(
                ["git", "-C", root, "rev-parse", "--abbrev-ref", "HEAD"],
                capture_output=True, text=True,
            )
            if result.returncode == 0:
                branch = result.stdout.strip()
        except OSError:
            pass

        try:
            rel_path = os.path.relpath(root, os.path.abspath(layers_dir))
        except ValueError:
            rel_path = repo_name

        source_entry: dict = {}
        if remotes:
            source_entry["git-remote"] = {
                "remotes": remotes,
                "rev": branch or "master",
            }
        source_entry["path"] = rel_path

        sources[repo_name] = source_entry

    return sources, git_roots


def _write_export(project_name: str, sources: Dict[str, dict],
                  relative_layers: List[str], fragments: List[str],
                  output_path: str, to_registry: bool = False,
                  description: str = "") -> None:
    """Write .conf.json export file and optionally copy to registry."""
    file_desc = description or f"Exported from {project_name}"
    config_desc = description or "Exported build configuration"
    conf_data = {
        "version": "1.0.0",
        "description": file_desc,
        "sources": sources,
        "bitbake-setup": {
            "configurations": [
                {
                    "name": project_name,
                    "description": config_desc,
                    "bb-layers": relative_layers,
                    "oe-fragments": fragments,
                }
            ]
        },
    }

    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(conf_data, f, indent=2)
        f.write("\n")

    print(f"{Colors.green('Exported')} to {output_path}")
    print(f"  Sources: {len(sources)} | Layers: {len(relative_layers)} | Fragments: {len(fragments)}")

    if to_registry:
        registry_dir = os.path.expanduser("~/.config/bit/registry")
        os.makedirs(registry_dir, exist_ok=True)
        basename = os.path.basename(output_path)
        if not basename.endswith(".conf.json"):
            basename += ".conf.json"
        target = os.path.join(registry_dir, basename)
        shutil.copy2(output_path, target)
        print(f"{Colors.green('Copied')} to registry: {target}")


def gather_export_data(layers_dir: str = "layers", bblayers: str = None) -> Optional[dict]:
    """Gather export data for the current project.

    Returns a dict with project_name, sources, relative_layers, fragments,
    or None if the project state cannot be resolved.
    """
    from .fragment import _get_toolcfg_path, _parse_enabled_fragments

    bblayers_path = resolve_bblayers_path(bblayers)
    if not bblayers_path:
        return None

    try:
        layer_paths = extract_layer_paths(bblayers_path)
    except SystemExit:
        return None

    if not layer_paths:
        return None

    extra_repos = load_defaults(".bit.defaults").get("__extra_repos__", [])
    sources, git_roots = _gather_export_sources(layer_paths, layers_dir,
                                                extra_repos=extra_repos)
    if not git_roots:
        return None

    all_fragments: List[str] = []
    try:
        toolcfg_path = _get_toolcfg_path(bblayers_path)
        all_fragments = _parse_enabled_fragments(toolcfg_path)
    except (ImportError, OSError):
        pass

    abs_layers_dir = os.path.abspath(layers_dir)
    relative_layers: List[str] = []
    for lp in layer_paths:
        try:
            relative_layers.append(os.path.relpath(lp, abs_layers_dir))
        except ValueError:
            relative_layers.append(lp)

    project_name = os.path.basename(os.path.abspath(os.getcwd()))

    return {
        "project_name": project_name,
        "sources": sources,
        "relative_layers": relative_layers,
        "fragments": all_fragments,
    }


def _resolve_project_dir(project_arg: Optional[str]) -> Optional[str]:
    """Resolve --project to a directory path.

    Accepts a direct path or a registered project name.
    Returns the resolved path, or None if not found.
    """
    if not project_arg:
        return None

    # Direct path
    if os.path.isdir(project_arg):
        return os.path.abspath(project_arg)

    # Try registered project name
    try:
        from .projects import load_projects
        projects = load_projects()
        for path, info in projects.items():
            name = info.get("name", os.path.basename(path))
            if name == project_arg or path == project_arg:
                if os.path.isdir(path):
                    return path
    except (ImportError, OSError):
        pass

    return None


def run_setup_export(args) -> int:
    """Export current build state as a .conf.json file."""
    output_path = getattr(args, "output", None)
    save_to_registry = getattr(args, "registry", False)
    layers_dir = getattr(args, "layers_dir", "layers")

    # Resolve --project if given
    project_dir = _resolve_project_dir(getattr(args, "project", None))
    saved_cwd = None
    if project_dir:
        saved_cwd = os.getcwd()
        os.chdir(project_dir)
    elif getattr(args, "project", None):
        print(f"Project not found: {args.project}")
        return 1

    try:
        return _run_setup_export(output_path, save_to_registry, layers_dir,
                                 getattr(args, "bblayers", None))
    finally:
        if saved_cwd:
            try:
                os.chdir(saved_cwd)
            except OSError:
                pass


def _run_setup_export(output_path, save_to_registry, layers_dir, bblayers) -> int:
    """Core export logic."""
    # 1. Find bblayers.conf
    bblayers_path = resolve_bblayers_path(bblayers)
    if not bblayers_path:
        print("No bblayers.conf found. Run 'bit setup' first to initialize the build environment.")
        return 1

    # 2. Extract layer paths
    try:
        layer_paths = extract_layer_paths(bblayers_path)
    except SystemExit:
        print(f"Error reading {bblayers_path}")
        return 1

    if not layer_paths:
        print("No layers found in bblayers.conf.")
        return 1

    # 3. Gather git sources (including non-layer repos like bitbake)
    extra_repos = load_defaults(".bit.defaults").get("__extra_repos__", [])
    sources, git_roots = _gather_export_sources(layer_paths, layers_dir,
                                                extra_repos=extra_repos)

    if not git_roots:
        print("No git repositories found for the configured layers.")
        return 1

    # 4. Get enabled fragments
    fragments: List[str] = []
    try:
        from .fragment import _get_toolcfg_path, _parse_enabled_fragments
        toolcfg_path = _get_toolcfg_path(bblayers_path)
        fragments = _parse_enabled_fragments(toolcfg_path)
    except (ImportError, OSError):
        pass

    # 5. Make layer paths relative to layers dir
    abs_layers_dir = os.path.abspath(layers_dir)
    relative_layers: List[str] = []
    for lp in layer_paths:
        try:
            rel = os.path.relpath(lp, abs_layers_dir)
            relative_layers.append(rel)
        except ValueError:
            relative_layers.append(lp)

    # 6. Write export
    project_name = os.path.basename(os.path.abspath(os.getcwd()))
    if not output_path:
        output_path = f"{project_name}.conf.json"

    _write_export(project_name, sources, relative_layers, fragments,
                  output_path, to_registry=save_to_registry)

    return 0


def run_setup_configs(args) -> int:
    """Browse and manage saved .conf.json configurations."""
    layers_dir = getattr(args, "layers_dir", "layers")

    # Two-stage bootstrap: check if built-in registry is available
    builtin_registry = os.path.join("layers", "bitbake", "default-registry")
    has_builtin = os.path.isdir(builtin_registry)

    if not has_builtin and os.path.isdir("layers") and not os.path.isdir(os.path.join("layers", "bitbake")):
        # layers/ exists but no bitbake — offer to clone for official configs
        print("The built-in config registry requires layers/bitbake to be cloned.")
        print(f"Run '{Colors.cyan('bit setup clone --doit')}' to clone core repos.")
        print()
        print("Checking user registry only...")
        print()

    while True:
        # Scan both registries
        registry_dirs = find_registry_dirs()

        all_entries: List[Tuple[str, str, str, ConfJson, str]] = []
        for d, label in registry_dirs:
            entries = discover_registry(d, source_label=label)
            all_entries.extend(entries)

        if not all_entries:
            print("No .conf.json configurations found.")
            print()
            print("To add configurations:")
            print(f"  {Colors.cyan('bit setup registry-copy <file.conf.json>')}  (copy to user registry)")
            print(f"  {Colors.cyan('bit setup clone --doit')}         (clone bitbake for built-in configs)")
            return 0

        rc = _fzf_registry_browser(all_entries, args=args)
        if rc == _REFRESH_SENTINEL:
            continue
        return rc


def _get_layer_index_cache_path() -> str:
    """Get path to layer index cache file."""
    cache_dir = os.path.expanduser("~/.cache/bit")
    os.makedirs(cache_dir, exist_ok=True)
    return os.path.join(cache_dir, "layer-index.json")


def _fetch_layer_index(force: bool = False) -> Optional[list]:
    """Fetch layer index from API or cache. Returns None on error."""
    import urllib.request
    import urllib.error

    cache_path = _get_layer_index_cache_path()
    cache_max_age = 2 * 60 * 60  # 2 hours in seconds

    # Check cache
    if not force and os.path.isfile(cache_path):
        try:
            cache_age = time.time() - os.path.getmtime(cache_path)
            if cache_age < cache_max_age:
                with open(cache_path, "r") as f:
                    cache_data = json.load(f)
                    if cache_data.get("data"):
                        return cache_data["data"]
        except (json.JSONDecodeError, OSError, KeyError):
            pass  # Cache invalid, fetch fresh

    # Fetch from API
    api_url = "https://layers.openembedded.org/layerindex/api/layers/?format=json"
    try:
        print(Colors.dim("Fetching layer index..."), end=" ", flush=True)
        with urllib.request.urlopen(api_url, timeout=30) as resp:
            data = json.loads(resp.read().decode())
        print(Colors.dim("done"))

        # Save to cache
        try:
            with open(cache_path, "w") as f:
                json.dump({"timestamp": time.time(), "data": data}, f)
        except OSError:
            pass  # Cache write failed, continue anyway

        return data
    except urllib.error.URLError as e:
        print(Colors.dim("failed"))
        # Try to use stale cache
        if os.path.isfile(cache_path):
            try:
                with open(cache_path, "r") as f:
                    cache_data = json.load(f)
                    if cache_data.get("data"):
                        print(Colors.yellow(f"Using cached data (network error: {e})"))
                        return cache_data["data"]
            except (json.JSONDecodeError, OSError, KeyError):
                pass
        print(f"Error fetching layer index: {e}")
        return None
    except json.JSONDecodeError as e:
        print(Colors.dim("failed"))
        print(f"Error parsing response: {e}")
        return None


def _fetch_layer_dependencies(layer_name: str, branch: str) -> List[dict]:
    """Fetch dependencies for a layer from the API. Returns list of {name, required} dicts."""
    import urllib.request
    import urllib.error

    # First get the layerbranch ID for this layer+branch
    try:
        # Get all layerbranches for this layer
        url = f"https://layers.openembedded.org/layerindex/api/layerBranches/?filter=layer__name:{layer_name}"
        with urllib.request.urlopen(url, timeout=10) as resp:
            layerbranches = json.loads(resp.read().decode())
        if not layerbranches:
            return []

        # Get branch ID mapping
        branch_url = "https://layers.openembedded.org/layerindex/api/branches/"
        with urllib.request.urlopen(branch_url, timeout=10) as resp:
            branches = json.loads(resp.read().decode())
        branch_id = next((b["id"] for b in branches if b["name"] == branch), None)
        if not branch_id:
            return []

        # Find layerbranch for the target branch
        layerbranch_id = next((lb["id"] for lb in layerbranches if lb.get("branch") == branch_id), None)
        if not layerbranch_id:
            return []
    except (urllib.error.URLError, json.JSONDecodeError, KeyError, IndexError, StopIteration):
        return []

    # Get dependencies for this layerbranch
    try:
        url = f"https://layers.openembedded.org/layerindex/api/layerDependencies/?filter=layerbranch:{layerbranch_id}"
        with urllib.request.urlopen(url, timeout=10) as resp:
            deps = json.loads(resp.read().decode())
    except (urllib.error.URLError, json.JSONDecodeError):
        return []

    if not deps:
        return []

    # Get layer info for each dependency ID
    dep_ids = [d.get("dependency") for d in deps if d.get("dependency")]
    if not dep_ids:
        return []

    # Build lookup from cached layer data
    layer_data = _fetch_layer_index(force=False)
    if not layer_data:
        return []

    # Map layer IDs to names (layer ID is in layer.id)
    id_to_name = {}
    for entry in layer_data:
        layer_info = entry.get("layer", {})
        lid = layer_info.get("id")
        name = layer_info.get("name")
        if lid and name:
            id_to_name[lid] = name

    # Resolve dependency names
    result = []
    for d in deps:
        dep_id = d.get("dependency")
        required = d.get("required", True)
        name = id_to_name.get(dep_id)
        if name:
            # Skip openembedded-core (always present)
            if name == "openembedded-core":
                continue
            result.append({"name": name, "required": required})

    # Dedupe and sort (required first)
    seen = set()
    unique = []
    for d in result:
        if d["name"] not in seen:
            seen.add(d["name"])
            unique.append(d)
    return sorted(unique, key=lambda x: (not x["required"], x["name"]))


def _fetch_layer_deps_bulk(branch: str, layer_data: list) -> dict:
    """Fetch all layer dependencies for a branch. Returns {layer_name: [{name, required}]}.

    Uses 1 API call (cached) + already-fetched layer_data for ID mapping.
    """
    import urllib.request
    import urllib.error

    cache_dir = os.path.expanduser("~/.cache/bit")
    os.makedirs(cache_dir, exist_ok=True)
    cache_path = os.path.join(cache_dir, "layer-deps.json")
    cache_max_age = 2 * 60 * 60  # 2 hours

    # Try loading cached raw API response
    raw_deps = None
    if os.path.isfile(cache_path):
        try:
            cache_age = time.time() - os.path.getmtime(cache_path)
            if cache_age < cache_max_age:
                with open(cache_path, "r") as f:
                    raw_deps = json.load(f)
        except (json.JSONDecodeError, OSError):
            pass

    # Fetch from API if not cached
    if raw_deps is None:
        try:
            url = "https://layers.openembedded.org/layerindex/api/layerDependencies/?format=json"
            with urllib.request.urlopen(url, timeout=30) as resp:
                raw_deps = json.loads(resp.read().decode())
            # Cache the raw response
            try:
                with open(cache_path, "w") as f:
                    json.dump(raw_deps, f)
            except OSError:
                pass
        except (urllib.error.URLError, json.JSONDecodeError):
            return {}

    if not raw_deps:
        return {}

    # Build ID maps from layer_data (already fetched, filtered to target branch)
    # Find the branch ID for the target branch name
    branch_id = None
    layerbranch_to_layer_name = {}  # layerbranch_id -> layer_name
    layer_id_to_name = {}  # layer_id -> layer_name

    for entry in layer_data:
        entry_branch = entry.get("branch", {})
        layer_info = entry.get("layer", {})
        lid = layer_info.get("id")
        name = layer_info.get("name")
        if lid and name:
            layer_id_to_name[lid] = name
        if entry_branch.get("name") == branch:
            if branch_id is None:
                branch_id = entry_branch.get("id")
            lb_id = entry.get("id")  # layerbranch ID
            if lb_id and name:
                layerbranch_to_layer_name[lb_id] = name

    if not branch_id or not layerbranch_to_layer_name:
        return {}

    # Build deps map: for each dependency record whose layerbranch is in our branch
    deps_map = {}  # layer_name -> list of {name, required}
    for dep in raw_deps:
        lb_id = dep.get("layerbranch")
        dep_layer_id = dep.get("dependency")
        required = dep.get("required", True)

        src_name = layerbranch_to_layer_name.get(lb_id)
        if not src_name:
            continue

        dep_name = layer_id_to_name.get(dep_layer_id)
        if not dep_name or dep_name == "openembedded-core":
            continue

        deps_map.setdefault(src_name, []).append({"name": dep_name, "required": required})

    # Dedupe and sort each layer's deps (required first, then alphabetical)
    for layer_name, deps_list in deps_map.items():
        seen = set()
        unique = []
        for d in deps_list:
            if d["name"] not in seen:
                seen.add(d["name"])
                unique.append(d)
        deps_map[layer_name] = sorted(unique, key=lambda x: (not x["required"], x["name"]))

    return deps_map


