#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Patches command - explore, search, filter, and manage patches across Yocto/OE layers."""

import glob
import json
import os
import re
import shutil
import subprocess
import tempfile
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

from ..core import Colors, fzf_available, get_fzf_color_args
from ..fzf_bindings import get_preview_header_suffix
from .common import resolve_bblayers_path, extract_layer_paths, layer_display_name
from .projects import get_fzf_preview_args, get_preview_window_arg
from ..tui import (
    InlineOptionsState,
    build_patches_search_menu,
    build_patches_filter_menu,
)


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class Patch:
    """Represents a patch file in a Yocto/OE layer."""
    name: str              # Filename (e.g., "0001-fix-build.patch")
    path: str              # Full filesystem path to .patch file
    recipe_name: str       # Associated recipe name (e.g., "linux-yocto")
    recipe_path: str       # Path to the recipe file
    layer_path: str        # Path to the layer containing this patch
    layer_name: str        # Layer name (e.g., "meta-oe")
    repo_path: str         # Git repository path containing the layer
    repo_name: str         # Repository display name
    upstream_status: str   # Upstream-Status value (e.g., "Pending", "Submitted")
    upstream_detail: str   # Detail after status (e.g., "[poky]" for Submitted)
    status_line_num: int   # Line number where Upstream-Status appears (0 if not found)
    subject: str           # Subject line from patch


# =============================================================================
# Constants
# =============================================================================

# Valid Upstream-Status values per Yocto documentation
# Format: (status, requires_detail, detail_description)
UPSTREAM_STATUS_VALUES = {
    "Pending": (False, "No determination made yet"),
    "Submitted": (False, "Submitted to upstream (optionally specify where)"),
    "Backport": (True, "Backported from newer upstream version"),
    "Accepted": (True, "Accepted upstream in specified version"),
    "Denied": (True, "Upstream rejected - provide reason"),
    "Inactive-Upstream": (True, "Project defunct - specify lastcommit/lastrelease"),
    "Inappropriate": (True, "Not appropriate for upstream - specify reason"),
}

# Valid reasons for Inappropriate status
INAPPROPRIATE_REASONS = [
    "oe-specific",
    "native",
    "licensing",
    "configuration",
    "enable-feature",
    "disable-feature",
    "bugfix",
    "embedded-specific",
    "other",
]


# =============================================================================
# Upstream-Status Parsing
# =============================================================================

def _parse_upstream_status(patch_path: str) -> Tuple[str, str, int, str]:
    """
    Parse Upstream-Status from patch header.

    Returns (status, detail, line_number, subject).
    - status: The status value (e.g., "Pending", "Submitted")
    - detail: Any additional info (e.g., "[poky]", "lastcommit=abc123")
    - line_number: Line number where status was found (0 if not found)
    - subject: The Subject line from the patch
    """
    status = ""
    detail = ""
    line_num = 0
    subject = ""

    try:
        with open(patch_path, "r", encoding="utf-8", errors="ignore") as f:
            for idx, line in enumerate(f, 1):
                # Stop at first diff line (end of header)
                if line.startswith("diff ") or line.startswith("---"):
                    break

                # Parse Subject line
                if line.startswith("Subject:"):
                    subject = line[8:].strip()
                    # Handle multi-line subjects (continuation lines start with space)
                    continue

                # Parse Upstream-Status line
                # Format: Upstream-Status: <status> [<detail>]
                match = re.match(r'^Upstream-Status:\s*(\S+)\s*(.*)?$', line, re.IGNORECASE)
                if match:
                    status = match.group(1)
                    detail = match.group(2).strip() if match.group(2) else ""
                    line_num = idx
                    # Don't break - continue to get subject if it comes after

    except (OSError, IOError):
        pass

    return status, detail, line_num, subject


def _normalize_status(status: str) -> str:
    """
    Normalize an Upstream-Status value to canonical form.

    Handles common variations like case differences.
    """
    status_lower = status.lower()
    for canonical in UPSTREAM_STATUS_VALUES.keys():
        if status_lower == canonical.lower():
            return canonical
    return status  # Return as-is if not recognized


# =============================================================================
# Patch Discovery
# =============================================================================

def _get_repo_info(layer_path: str) -> Tuple[str, str]:
    """
    Get git repository path and display name for a layer.

    Returns (repo_path, repo_name).
    """
    try:
        repo_path = subprocess.check_output(
            ["git", "-C", layer_path, "rev-parse", "--show-toplevel"],
            stderr=subprocess.DEVNULL,
            text=True,
        ).strip()

        # Try to get custom display name
        try:
            repo_name = subprocess.check_output(
                ["git", "-C", repo_path, "config", "--get", "bit.display-name"],
                stderr=subprocess.DEVNULL,
                text=True,
            ).strip()
        except subprocess.CalledProcessError:
            # Fall back to deriving from origin URL or basename
            try:
                url = subprocess.check_output(
                    ["git", "-C", repo_path, "config", "--get", "remote.origin.url"],
                    stderr=subprocess.DEVNULL,
                    text=True,
                ).strip()
                repo_name = os.path.basename(url.rstrip('/'))
                if repo_name.endswith('.git'):
                    repo_name = repo_name[:-4]
            except subprocess.CalledProcessError:
                repo_name = os.path.basename(repo_path)

        return repo_path, repo_name
    except subprocess.CalledProcessError:
        return layer_path, os.path.basename(layer_path)


def _find_recipe_for_patch(patch_path: str, layer_path: str) -> Tuple[str, str]:
    """
    Find the recipe associated with a patch.

    Returns (recipe_name, recipe_path).
    """
    # Patch is typically in recipes-*/<recipe>/<recipe>/ or recipes-*/<recipe>/files/
    patch_dir = os.path.dirname(patch_path)
    rel_path = os.path.relpath(patch_path, layer_path)
    parts = rel_path.split(os.sep)

    # Expected structure: recipes-<category>/<recipe-dir>/<files-or-recipe>/patch.patch
    if len(parts) >= 3 and parts[0].startswith("recipes-"):
        recipe_dir = parts[1]  # This is typically the recipe name

        # Look for .bb file in the recipe directory
        recipe_base_dir = os.path.join(layer_path, parts[0], recipe_dir)
        bb_files = glob.glob(os.path.join(recipe_base_dir, "*.bb"))
        if bb_files:
            # Use the first .bb file found
            recipe_path = bb_files[0]
            recipe_name = os.path.basename(recipe_path)
            # Remove version and extension: linux-yocto_5.15.bb -> linux-yocto
            if "_" in recipe_name:
                recipe_name = recipe_name.rsplit("_", 1)[0]
            else:
                recipe_name = recipe_name[:-3]  # Remove .bb
            return recipe_name, recipe_path

        # Also check for .bbappend files
        bbappend_files = glob.glob(os.path.join(recipe_base_dir, "*.bbappend"))
        if bbappend_files:
            recipe_path = bbappend_files[0]
            recipe_name = os.path.basename(recipe_path)
            if "_" in recipe_name:
                recipe_name = recipe_name.rsplit("_", 1)[0]
            elif "%" in recipe_name:
                recipe_name = recipe_name.split("%")[0]
            else:
                recipe_name = recipe_name[:-9]  # Remove .bbappend
            return recipe_name, recipe_path

    return "", ""


def _scan_patches_from_layers(
    layer_paths: List[str],
    progress: bool = True,
) -> List[Patch]:
    """
    Scan layers for .patch files.

    Returns list of Patch objects.
    """
    patches = []

    if progress:
        print(Colors.dim("Scanning patches..."), end=" ", flush=True)

    for layer_path in layer_paths:
        layer_name = layer_display_name(layer_path)
        repo_path, repo_name = _get_repo_info(layer_path)

        # Glob for patches: recipes-*/**/*.patch
        pattern = os.path.join(layer_path, "recipes-*", "**", "*.patch")
        patch_files = glob.glob(pattern, recursive=True)

        for patch_path in patch_files:
            name = os.path.basename(patch_path)
            recipe_name, recipe_path = _find_recipe_for_patch(patch_path, layer_path)
            status, detail, line_num, subject = _parse_upstream_status(patch_path)

            patches.append(Patch(
                name=name,
                path=patch_path,
                recipe_name=recipe_name,
                recipe_path=recipe_path,
                layer_path=layer_path,
                layer_name=layer_name,
                repo_path=repo_path,
                repo_name=repo_name,
                upstream_status=status,
                upstream_detail=detail,
                status_line_num=line_num,
                subject=subject or name,
            ))

    if progress:
        print(Colors.dim(f"{len(patches)} patches found"))

    return patches


# =============================================================================
# Patch Searching and Filtering
# =============================================================================

def _search_patches_by_name(patches: List[Patch], query: str) -> List[Patch]:
    """Filter patches by name (supports regex)."""
    try:
        pattern = re.compile(query, re.IGNORECASE)
        return [p for p in patches if pattern.search(p.name)]
    except re.error:
        # Fall back to literal match
        query_lower = query.lower()
        return [p for p in patches if query_lower in p.name.lower()]


def _search_patches_by_body(patches: List[Patch], query: str) -> List[Patch]:
    """Filter patches by content (grep patch body)."""
    matching = []
    try:
        pattern = re.compile(query, re.IGNORECASE)
    except re.error:
        pattern = None

    for patch in patches:
        try:
            with open(patch.path, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()
            if pattern:
                if pattern.search(content):
                    matching.append(patch)
            else:
                if query.lower() in content.lower():
                    matching.append(patch)
        except (OSError, IOError):
            pass

    return matching


def _filter_by_status(patches: List[Patch], status: str) -> List[Patch]:
    """Filter patches by Upstream-Status."""
    status_lower = status.lower()

    # Handle "none" or "missing" to find patches without status
    if status_lower in ("none", "missing", ""):
        return [p for p in patches if not p.upstream_status]

    return [p for p in patches if p.upstream_status.lower() == status_lower]


# =============================================================================
# Upstream-Status Update
# =============================================================================

def _update_upstream_status(patch_path: str, new_status: str, new_detail: str = "") -> bool:
    """
    Update or add Upstream-Status in a patch file.

    Returns True if file was modified.
    """
    try:
        with open(patch_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except (OSError, IOError):
        return False

    # Build the new status line
    if new_detail:
        new_line = f"Upstream-Status: {new_status} {new_detail}\n"
    else:
        new_line = f"Upstream-Status: {new_status}\n"

    # Find existing Upstream-Status line
    status_idx = -1
    for idx, line in enumerate(lines):
        if line.lower().startswith("upstream-status:"):
            status_idx = idx
            break

    if status_idx >= 0:
        # Replace existing line
        lines[status_idx] = new_line
    else:
        # Insert before Signed-off-by or at end of header
        insert_idx = len(lines)
        for idx, line in enumerate(lines):
            if line.startswith("Signed-off-by:"):
                insert_idx = idx
                break
            if line.startswith("diff ") or line.startswith("---"):
                insert_idx = idx
                break
        lines.insert(insert_idx, new_line)

    try:
        with open(patch_path, "w", encoding="utf-8") as f:
            f.writelines(lines)
        return True
    except (OSError, IOError):
        return False


def _pick_upstream_status() -> Optional[Tuple[str, str]]:
    """
    Show fzf menu to pick a compliant Upstream-Status value.

    Returns (status, detail) or None if cancelled.
    """
    if not fzf_available():
        # Text-based fallback
        print("\nAvailable Upstream-Status values:")
        for idx, (status, (requires_detail, desc)) in enumerate(UPSTREAM_STATUS_VALUES.items(), 1):
            marker = "*" if requires_detail else " "
            print(f"  {idx}. {status:<20} {marker} {desc}")
        print("\n* = requires detail")

        try:
            choice = input("Select status (number or name): ").strip()
            if choice.isdigit():
                idx = int(choice) - 1
                if 0 <= idx < len(UPSTREAM_STATUS_VALUES):
                    status = list(UPSTREAM_STATUS_VALUES.keys())[idx]
                else:
                    return None
            else:
                status = _normalize_status(choice)
                if status not in UPSTREAM_STATUS_VALUES:
                    print(f"Unknown status: {choice}")
                    return None

            requires_detail, _ = UPSTREAM_STATUS_VALUES[status]
            detail = ""
            if requires_detail:
                if status == "Inappropriate":
                    print(f"Valid reasons: {', '.join(INAPPROPRIATE_REASONS)}")
                detail = input(f"Enter detail for {status}: ").strip()

            return status, detail
        except (EOFError, KeyboardInterrupt):
            return None

    # Build fzf menu
    menu_lines = []
    for status, (requires_detail, desc) in UPSTREAM_STATUS_VALUES.items():
        marker = Colors.yellow("*") if requires_detail else " "
        line = f"{status}\t{status:<20} {marker} {desc}"
        menu_lines.append(line)

    menu_input = "\n".join(menu_lines)

    fzf_args = [
        "fzf",
        "--no-multi",
        "--ansi",
        "--height", "~15",
        "--header", "Select Upstream-Status (* = requires detail)",
        "--prompt", "Status: ",
        "--with-nth", "2..",
        "--delimiter", "\t",
    ]
    fzf_args.extend(get_fzf_color_args())

    try:
        result = subprocess.run(
            fzf_args,
            input=menu_input,
            stdout=subprocess.PIPE,
            text=True,
        )
    except FileNotFoundError:
        return None

    if result.returncode != 0 or not result.stdout.strip():
        return None

    status = result.stdout.split("\t")[0].strip()
    requires_detail, _ = UPSTREAM_STATUS_VALUES.get(status, (False, ""))

    detail = ""
    if requires_detail:
        if status == "Inappropriate":
            # Show reason picker
            reason_lines = [f"{r}\t{r}" for r in INAPPROPRIATE_REASONS]
            reason_result = subprocess.run(
                ["fzf", "--no-multi", "--ansi", "--height", "~12",
                 "--header", "Select reason for Inappropriate",
                 "--prompt", "Reason: ", "--with-nth", "2..",
                 "--delimiter", "\t"] + get_fzf_color_args(),
                input="\n".join(reason_lines),
                stdout=subprocess.PIPE,
                text=True,
            )
            if reason_result.returncode == 0 and reason_result.stdout.strip():
                detail = f"[{reason_result.stdout.split()[0].strip()}]"
        else:
            try:
                detail = input(f"Enter detail for {status}: ").strip()
                if detail and not detail.startswith("["):
                    detail = f"[{detail}]"
            except (EOFError, KeyboardInterrupt):
                pass

    return status, detail


# =============================================================================
# Menu Building
# =============================================================================

# Fixed column widths for consistent alignment
COL_RECIPE = 16    # Recipe name
COL_LAYER = 16     # Layer name
COL_STATUS = 15    # [status] with brackets (longest: Inappropriate = 13)


def _format_status(status: str) -> str:
    """Format status with color, preserving alignment.

    Pads the status text FIRST, then applies color so ANSI codes don't
    affect column width calculations.
    """
    status_display = status if status else "none"
    # Pad inside brackets: [Pending      ]
    padded = f"[{status_display:<{COL_STATUS - 2}}]"
    # Now apply color to the already-padded string
    status_color = _get_status_color(status)
    return status_color(padded)


def _build_patches_menu_by_repo(
    patches: List[Patch],
    collapsed: set = None,
) -> str:
    """Build fzf menu input with patches grouped by repository.

    Args:
        patches: List of patches to display
        collapsed: Set of group names that are collapsed (show only header)
    """
    lines = []
    collapsed = collapsed or set()

    # Group by repo
    by_repo: Dict[str, List[Patch]] = {}
    for p in patches:
        by_repo.setdefault(p.repo_name, []).append(p)

    for repo_name in sorted(by_repo.keys()):
        repo_patches = by_repo[repo_name]
        is_collapsed = repo_name in collapsed

        # Prefix: + for collapsed (expandable), - for expanded
        prefix = "+" if is_collapsed else "-"

        # Use display name from config if available
        display_name = layer_display_name(repo_name)

        # Group header line - use GROUP: prefix so we can identify it
        # Store original repo_name as the key, but show display_name
        header_text = f"{prefix} {display_name} ({len(repo_patches)})"
        lines.append(f"GROUP:{repo_name}\t{Colors.cyan(header_text)}")

        # Only show patches if group is expanded
        if not is_collapsed:
            for p in sorted(repo_patches, key=lambda x: x.name):
                # Show: recipe, status, subject (subject fills remaining width)
                recipe = p.recipe_name[:COL_RECIPE].ljust(COL_RECIPE)
                status = _format_status(p.upstream_status)
                subject = p.subject or p.name

                line = f"{p.path}\t  {recipe} {status} {subject}"
                lines.append(line)

    return "\n".join(lines)


def _build_patches_menu_by_recipe(
    patches: List[Patch],
    collapsed: set = None,
) -> str:
    """Build fzf menu input with patches grouped by recipe.

    Args:
        patches: List of patches to display
        collapsed: Set of group names that are collapsed (show only header)
    """
    lines = []
    collapsed = collapsed or set()

    # Group by recipe
    by_recipe: Dict[str, List[Patch]] = {}
    for p in patches:
        key = p.recipe_name or "(unknown)"
        by_recipe.setdefault(key, []).append(p)

    for recipe_name in sorted(by_recipe.keys()):
        recipe_patches = by_recipe[recipe_name]
        is_collapsed = recipe_name in collapsed

        # Prefix: + for collapsed (expandable), - for expanded
        prefix = "+" if is_collapsed else "-"

        # Group header line - use GROUP: prefix so we can identify it
        header_text = f"{prefix} {recipe_name} ({len(recipe_patches)})"
        lines.append(f"GROUP:{recipe_name}\t{Colors.cyan(header_text)}")

        # Only show patches if group is expanded
        if not is_collapsed:
            for p in sorted(recipe_patches, key=lambda x: x.name):
                # Show: layer, status, subject (subject fills remaining width)
                layer = p.layer_name[:COL_LAYER].ljust(COL_LAYER)
                status = _format_status(p.upstream_status)
                subject = p.subject or p.name

                line = f"{p.path}\t  {layer} {status} {subject}"
                lines.append(line)

    return "\n".join(lines)


def _build_patches_menu_by_layer_recipe(
    patches: List[Patch],
    collapsed: set = None,
) -> str:
    """Build fzf menu input with patches grouped by layer, then recipe within layer.

    Args:
        patches: List of patches to display
        collapsed: Set of group names that are collapsed (show only header)
    """
    lines = []
    collapsed = collapsed or set()

    # Group by layer first
    by_layer: Dict[str, Dict[str, List[Patch]]] = {}
    for p in patches:
        layer = p.layer_name
        recipe = p.recipe_name or "(unknown)"
        if layer not in by_layer:
            by_layer[layer] = {}
        by_layer[layer].setdefault(recipe, []).append(p)

    for layer_name in sorted(by_layer.keys()):
        layer_recipes = by_layer[layer_name]
        layer_patch_count = sum(len(patches) for patches in layer_recipes.values())
        layer_key = f"layer:{layer_name}"
        is_layer_collapsed = layer_key in collapsed

        # Use display name from config if available
        display_name = layer_display_name(layer_name)

        # Layer header
        prefix = "+" if is_layer_collapsed else "-"
        header_text = f"{prefix} {display_name} ({layer_patch_count})"
        lines.append(f"GROUP:{layer_key}\t{Colors.cyan(header_text)}")

        if not is_layer_collapsed:
            for recipe_name in sorted(layer_recipes.keys()):
                recipe_patches = layer_recipes[recipe_name]
                recipe_key = f"recipe:{layer_name}/{recipe_name}"
                is_recipe_collapsed = recipe_key in collapsed

                # Recipe sub-header (indented)
                prefix = "+" if is_recipe_collapsed else "-"
                recipe_header = f"  {prefix} {recipe_name} ({len(recipe_patches)})"
                lines.append(f"GROUP:{recipe_key}\t{Colors.yellow(recipe_header)}")

                if not is_recipe_collapsed:
                    for p in sorted(recipe_patches, key=lambda x: x.name):
                        status = _format_status(p.upstream_status)
                        subject = p.subject or p.name
                        line = f"{p.path}\t    {status} {subject}"
                        lines.append(line)

    return "\n".join(lines)


def _get_status_color(status: str):
    """Get color function for a status value."""
    status_lower = status.lower() if status else ""
    if status_lower == "pending":
        return Colors.yellow
    elif status_lower in ("submitted", "accepted", "backport"):
        return Colors.green
    elif status_lower in ("denied", "inappropriate"):
        return Colors.red
    elif status_lower == "inactive-upstream":
        return Colors.magenta
    elif not status:
        return Colors.dim
    return lambda x: x  # No color


# =============================================================================
# Clipboard
# =============================================================================

def _copy_to_clipboard(text: str) -> bool:
    """Copy text to clipboard."""
    clipboard_cmds = [
        ["xclip", "-selection", "clipboard"],
        ["xsel", "--clipboard", "--input"],
        ["pbcopy"],
    ]

    for cmd in clipboard_cmds:
        if shutil.which(cmd[0]):
            try:
                subprocess.run(cmd, input=text, text=True, check=True)
                return True
            except subprocess.CalledProcessError:
                continue
    return False


# =============================================================================
# FZF Browser
# =============================================================================

def _patches_fzf_browser(
    patches: List[Patch],
    group_by: str = "repo",
    search_mode: str = "name",
    status_filter: str = "",
) -> int:
    """
    Interactive fzf browser for patches.

    Key bindings (use alt- so typing to filter works):
    - Enter: View patch in $PAGER
    - alt-e: Edit patch in $EDITOR
    - alt-u: Update Upstream-Status
    - alt-s: Search (prompts for query)
    - alt-g: Toggle grouping (repo vs recipe)
    - alt-f: Filter by Upstream-Status
    - alt-c: Copy path to clipboard
    - ?: Toggle preview
    - esc: Quit
    """
    if not patches:
        print("No patches found.")
        return 1

    if not fzf_available():
        # Fall back to text list
        _list_patches_text(patches, verbose=False)
        return 0

    # Build preview script
    preview_data = {p.path: {
        "name": p.name,
        "path": p.path,
        "recipe_name": p.recipe_name,
        "recipe_path": p.recipe_path,
        "layer_name": p.layer_name,
        "repo_name": p.repo_name,
        "upstream_status": p.upstream_status,
        "upstream_detail": p.upstream_detail,
        "status_line_num": p.status_line_num,
        "subject": p.subject,
    } for p in patches}

    preview_data_file = tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False)
    json.dump(preview_data, preview_data_file)
    preview_data_file.close()

    # Create preview script
    preview_script = tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False)
    preview_script.write(f'''#!/usr/bin/env python3
import json
import sys
import os

key = sys.argv[1] if len(sys.argv) > 1 else ""
key = key.strip("'\\"")

with open("{preview_data_file.name}", "r") as f:
    data = json.load(f)

patch = data.get(key, {{}})
if not patch:
    print(f"No data for: {{key}}")
    sys.exit(0)

# Header info
print(f"\\033[1m{{patch.get('name', '')}}\\033[0m")
print()
print(f"\\033[36mSubject:\\033[0m {{patch.get('subject', '')}}")
print(f"\\033[36mRecipe:\\033[0m {{patch.get('recipe_name', '')}}")
print(f"\\033[36mLayer:\\033[0m {{patch.get('layer_name', '')}}")
print(f"\\033[36mRepo:\\033[0m {{patch.get('repo_name', '')}}")
print(f"\\033[36mPath:\\033[0m {{patch.get('path', '')}}")
print()

# Upstream-Status with highlighting
status = patch.get('upstream_status', '')
detail = patch.get('upstream_detail', '')
if status:
    status_lower = status.lower()
    if status_lower == 'pending':
        color = '\\033[33m'  # Yellow
    elif status_lower in ('submitted', 'accepted', 'backport'):
        color = '\\033[32m'  # Green
    elif status_lower in ('denied', 'inappropriate'):
        color = '\\033[31m'  # Red
    elif status_lower == 'inactive-upstream':
        color = '\\033[35m'  # Magenta
    else:
        color = ''
    print(f"\\033[36mUpstream-Status:\\033[0m {{color}}{{status}}\\033[0m {{detail}}")
else:
    print("\\033[36mUpstream-Status:\\033[0m \\033[2m(none)\\033[0m")
print()

# Show first ~50 lines of diff
path = patch.get('path', '')
if path and os.path.isfile(path):
    print("\\033[36mPatch Content:\\033[0m")
    print("-" * 40)
    with open(path, 'r', errors='ignore') as f:
        for i, line in enumerate(f):
            if i >= 50:
                print("\\033[2m... (truncated)\\033[0m")
                break
            # Color diff lines
            if line.startswith('+') and not line.startswith('+++'):
                print(f"\\033[32m{{line.rstrip()}}\\033[0m")
            elif line.startswith('-') and not line.startswith('---'):
                print(f"\\033[31m{{line.rstrip()}}\\033[0m")
            elif line.startswith('@@'):
                print(f"\\033[36m{{line.rstrip()}}\\033[0m")
            else:
                print(line.rstrip())
''')
    preview_script.close()

    preview_cmd = f'python3 "{preview_script.name}" {{1}}'

    # Helper to get all group names for current grouping mode
    def _get_all_groups(patch_list: List[Patch], by: str) -> set:
        if by == "recipe":
            return {p.recipe_name or "(unknown)" for p in patch_list}
        elif by == "layer-recipe":
            # Both layer and recipe groups start collapsed
            groups = set()
            for p in patch_list:
                layer_key = f"layer:{p.layer_name}"
                recipe_key = f"recipe:{p.layer_name}/{p.recipe_name or '(unknown)'}"
                groups.add(layer_key)
                groups.add(recipe_key)
            return groups
        else:
            return {p.repo_name for p in patch_list}

    # Current state
    current_group_by = group_by
    current_search_mode = search_mode
    current_filter = status_filter
    filtered_patches = patches
    original_patches = patches  # Keep original for reset
    # Start with all groups collapsed by default
    collapsed_groups: set = _get_all_groups(patches, current_group_by)

    # Inline options menu state - separate dialogs for search and filter
    show_search_options = False
    show_filter_options = False
    search_menu = build_patches_search_menu()
    filter_menu = build_patches_filter_menu()
    search_state = InlineOptionsState(search_menu)
    filter_state = InlineOptionsState(filter_menu)

    try:
        while True:
            # Apply status filter if set
            if current_filter:
                filtered_patches = _filter_by_status(patches, current_filter)
            else:
                filtered_patches = patches

            if not filtered_patches:
                print(f"No patches match filter: {current_filter}")
                current_filter = ""
                continue

            # Build menu based on grouping
            if current_group_by == "recipe":
                base_menu_input = _build_patches_menu_by_recipe(filtered_patches, collapsed_groups)
            elif current_group_by == "layer-recipe":
                base_menu_input = _build_patches_menu_by_layer_recipe(filtered_patches, collapsed_groups)
            else:
                base_menu_input = _build_patches_menu_by_repo(filtered_patches, collapsed_groups)

            # Build patch-to-group mapping for toggling group when patch selected
            patch_to_group = {}
            for p in filtered_patches:
                if current_group_by == "recipe":
                    patch_to_group[p.path] = p.recipe_name or "(unknown)"
                elif current_group_by == "layer-recipe":
                    # For layer-recipe, map to the recipe key within the layer
                    patch_to_group[p.path] = f"recipe:{p.layer_name}/{p.recipe_name or '(unknown)'}"
                else:  # repo
                    patch_to_group[p.path] = p.repo_name

            # Add separator lines at top and bottom
            sep_line = "─" * 60
            top_sep = f"TOGGLE_ALL\t{Colors.dim(sep_line)}"
            bottom_sep = f"TOGGLE_ALL\t{Colors.dim(sep_line)}"
            menu_input = top_sep + "\n" + base_menu_input + "\n" + bottom_sep

            # Add inline options menu if active - expands up from bottom
            if show_search_options:
                options_lines = search_state.build_menu_lines()
                menu_input = menu_input + "\n" + "\n".join(options_lines)
            elif show_filter_options:
                options_lines = filter_state.build_menu_lines()
                menu_input = menu_input + "\n" + "\n".join(options_lines)

            # Build header
            if show_search_options:
                header = search_menu.header
                current_prompt = "Search: "
            elif show_filter_options:
                header = filter_menu.header
                current_prompt = "Filter: "
            else:
                group_indicator = f"group:{current_group_by}"
                filter_indicator = f"filter:{current_filter}" if current_filter else ""
                header_line1 = f"[{group_indicator}]" + (f" [{filter_indicator}]" if filter_indicator else "")
                header_line2 = "Enter/←/→/\\=fold | ctrl-g=group | ctrl-s=search | ctrl-t=filter | ctrl-r=reset"
                header_line3 = "ctrl-e=edit | ctrl-y=status | ctrl-o=copy | s=search lore | ?=preview"
                header_line4 = get_preview_header_suffix()
                header = f"{header_line1}\n{header_line2}\n{header_line3}\n{header_line4}"
                current_prompt = "Patch: "

            # Pad to fill terminal height so list top-aligns with preview top
            try:
                term_lines = os.get_terminal_size().lines
            except OSError:
                term_lines = 40
            header_line_count = header.count('\n') + 1
            chrome_lines = header_line_count + 2  # header + prompt + info line
            preview_arg = get_preview_window_arg("50%")
            if preview_arg.startswith("right"):
                available = term_lines - chrome_lines
            else:
                available = (term_lines // 2) - chrome_lines
            menu_line_count = menu_input.count('\n') + 1
            if menu_line_count < available:
                menu_input += "\n" + "\n".join("---\t" for _ in range(available - menu_line_count))

            fzf_args = [
                "fzf",
                "--no-multi",
                "--ansi",
                "--height", "100%",
                "--layout=reverse-list",
                "--header", header,
                "--prompt", current_prompt,
                "--with-nth", "2..",
                "--delimiter", "\t",
            ]

            if show_search_options:
                # Search options mode - add args including load:last for cursor positioning
                fzf_args.extend(search_state.get_fzf_args())
            elif show_filter_options:
                # Filter options mode - add args including load:last for cursor positioning
                fzf_args.extend(filter_state.get_fzf_args())
            else:
                fzf_args.extend([
                    "--bind", "esc:abort",
                    "--expect", "right,left,\\,ctrl-e,ctrl-y,ctrl-s,ctrl-g,ctrl-t,ctrl-o,ctrl-r,s",
                ])

            # Add preview with standard bindings (resize, color, toggle, scroll)
            fzf_args.extend(get_fzf_preview_args(preview_cmd, size="50%"))

            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )

            if result.returncode != 0 or not result.stdout.strip():
                if show_search_options:
                    show_search_options = False
                    continue
                if show_filter_options:
                    show_filter_options = False
                    continue
                break

            # Helper to apply status filters based on toggle states
            def apply_status_filters(patch_list: List[Patch], states: dict) -> List[Patch]:
                """Filter patches by enabled status toggles."""
                status_map = {
                    "filter_pending": "pending",
                    "filter_submitted": "submitted",
                    "filter_backport": "backport",
                    "filter_accepted": "accepted",
                    "filter_denied": "denied",
                    "filter_inactive": "inactive-upstream",
                    "filter_inappropriate": "inappropriate",
                    "filter_missing": "",
                }
                enabled_statuses = [
                    status_map[key] for key, enabled in states.items()
                    if key.startswith("filter_") and enabled
                ]
                if not enabled_statuses:
                    return patch_list
                result_list = []
                for p in patch_list:
                    patch_status = (p.upstream_status or "").lower()
                    for status in enabled_statuses:
                        if status == "" and not p.upstream_status:
                            result_list.append(p)
                            break
                        elif status and patch_status == status:
                            result_list.append(p)
                            break
                return result_list

            # Parse search options dialog
            if show_search_options:
                opt_result = search_state.parse_selection(result.stdout, result.returncode)

                if opt_result.cancelled:
                    show_search_options = False
                    continue

                if opt_result.toggled:
                    continue

                if opt_result.action == "search":
                    show_search_options = False
                    if opt_result.query.strip():
                        search_term = opt_result.query.strip()
                        states = search_state.get_all_states()
                        if states.get("body"):
                            filtered_patches = _search_patches_by_body(original_patches, search_term)
                        else:
                            filtered_patches = _search_patches_by_name(original_patches, search_term)
                        patches = filtered_patches
                        # Expand groups by default after search
                        collapsed_groups = set()
                    continue

                continue

            # Parse filter options dialog
            if show_filter_options:
                opt_result = filter_state.parse_selection(result.stdout, result.returncode)

                if opt_result.cancelled:
                    show_filter_options = False
                    continue

                if opt_result.toggled:
                    continue

                if opt_result.action == "reset":
                    show_filter_options = False
                    filtered_patches = original_patches
                    patches = original_patches
                    current_filter = ""
                    for key in filter_state.get_all_states():
                        if key.startswith("filter_"):
                            filter_state.set_state(key, False)
                    collapsed_groups = _get_all_groups(filtered_patches, current_group_by)
                    continue

                if opt_result.action == "apply":
                    show_filter_options = False
                    states = filter_state.get_all_states()
                    filtered_patches = apply_status_filters(original_patches, states)
                    patches = filtered_patches
                    # Expand groups by default after filter
                    collapsed_groups = set()
                    continue

                continue

            # Parse output - split BEFORE stripping to preserve empty key line
            # fzf with --expect outputs: <key>\n<selected>\n
            # When Enter is pressed (not in expect list), key line is empty
            lines = result.stdout.split("\n")
            key = lines[0].strip() if lines else ""
            selected = lines[1].split("\t")[0].strip() if len(lines) > 1 else ""

            # Handle toggle operations FIRST - these work regardless of selection
            if key == "\\":
                # Toggle expand/collapse
                if selected.startswith("GROUP:"):
                    # Toggle single group
                    group_name = selected[6:]  # Remove "GROUP:" prefix
                    if group_name in collapsed_groups:
                        collapsed_groups.discard(group_name)
                    else:
                        collapsed_groups.add(group_name)
                else:
                    # Toggle all groups - expand if any collapsed, collapse if all expanded
                    all_groups = _get_all_groups(filtered_patches, current_group_by)
                    if collapsed_groups:
                        collapsed_groups = set()  # Expand all
                    else:
                        collapsed_groups = all_groups  # Collapse all
                continue

            if key == "right":
                # Right arrow: expand group if collapsed, otherwise no-op (stay in menu)
                if selected.startswith("GROUP:"):
                    group_name = selected[6:]
                    if group_name in collapsed_groups:
                        collapsed_groups.discard(group_name)
                continue

            if key == "left":
                # Left arrow: collapse group if expanded, exit otherwise
                if selected.startswith("GROUP:"):
                    group_name = selected[6:]
                    if group_name not in collapsed_groups:
                        collapsed_groups.add(group_name)
                        continue
                # Not on an expanded group - exit
                break

            if key == "ctrl-g":
                # Cycle grouping: repo -> recipe -> layer-recipe -> repo
                if current_group_by == "repo":
                    current_group_by = "recipe"
                elif current_group_by == "recipe":
                    current_group_by = "layer-recipe"
                else:
                    current_group_by = "repo"
                collapsed_groups = _get_all_groups(filtered_patches, current_group_by)
                continue

            if key == "ctrl-r":
                # Reset - clear filter and show all patches
                filtered_patches = original_patches
                patches = original_patches
                current_filter = ""
                collapsed_groups = _get_all_groups(filtered_patches, current_group_by)
                continue

            if key == "ctrl-s":
                # Show search options dialog
                show_search_options = True
                continue

            if key == "ctrl-t":
                # Show filter options dialog
                show_filter_options = True
                continue

            # For remaining operations, we need a valid selection
            if not selected:
                break

            # Handle TOGGLE_ALL separator - Enter on separator toggles all groups
            if not key and selected == "TOGGLE_ALL":
                all_groups = _get_all_groups(filtered_patches, current_group_by)
                if collapsed_groups:
                    collapsed_groups = set()  # Expand all
                else:
                    collapsed_groups = all_groups  # Collapse all
                continue

            # Enter on GROUP: header toggles that group (just like \)
            if not key and selected.startswith("GROUP:"):
                group_name = selected[6:]
                if group_name in collapsed_groups:
                    collapsed_groups.discard(group_name)
                else:
                    collapsed_groups.add(group_name)
                continue

            # Skip separator lines for patch-specific operations
            if selected.startswith("GROUP:") or selected == "---" or selected.startswith("──"):
                continue

            # Find selected patch
            patch = next((p for p in filtered_patches if p.path == selected), None)

            # In grouped mode, Enter on a patch toggles its group
            if not key and patch and selected in patch_to_group:
                group_name = patch_to_group[selected]
                if group_name in collapsed_groups:
                    collapsed_groups.discard(group_name)
                else:
                    collapsed_groups.add(group_name)
                continue

            if key == "ctrl-o" and patch:
                # Copy path to clipboard
                if _copy_to_clipboard(patch.path):
                    print(f"Copied: {patch.path}")
                else:
                    print(f"Path: {patch.path}")
                input("Press Enter to continue...")
                continue

            if key == "ctrl-e" and patch:
                # Edit in $EDITOR
                from .projects import resolve_editor
                editor = resolve_editor()
                subprocess.run([editor, patch.path])
                # Refresh patch data after edit
                status, detail, line_num, subject = _parse_upstream_status(patch.path)
                patch.upstream_status = status
                patch.upstream_detail = detail
                patch.status_line_num = line_num
                patch.subject = subject or patch.name
                continue

            if key == "ctrl-y" and patch:
                # Update Upstream-Status
                pick_result = _pick_upstream_status()
                if pick_result:
                    new_status, new_detail = pick_result
                    if _update_upstream_status(patch.path, new_status, new_detail):
                        print(f"Updated: {patch.name} -> {new_status} {new_detail}")
                        patch.upstream_status = new_status
                        patch.upstream_detail = new_detail
                    else:
                        print(f"Failed to update: {patch.name}")
                    input("Press Enter to continue...")
                continue

            if key == "s":
                if not patch:
                    continue
                # Search lore.kernel.org for this patch
                from .b4 import (LoreSearchContext, _search_with_context,
                                 fzf_lore_browser, _get_list_for_repo)
                query = patch.subject or patch.name
                list_name = _get_list_for_repo(patch.repo_path)
                ctx = LoreSearchContext(query=query, list_name=list_name)
                print(f"\nSearching lore for: {query}")
                results = _search_with_context(ctx)
                if results:
                    fzf_lore_browser(results, patch.repo_path, search_context=ctx)
                else:
                    print(f"\nNo results found on lore.kernel.org for:")
                    print(f"  {query}")
                    input("\nPress Enter to continue...")
                continue


    finally:
        # Clean up temp files
        for f in [preview_data_file.name, preview_script.name]:
            try:
                os.unlink(f)
            except OSError:
                pass

    return 0


# =============================================================================
# Text Output
# =============================================================================

def _list_patches_text(
    patches: List[Patch],
    verbose: bool = False,
    group_by: str = "repo",
) -> None:
    """Print patches as formatted text output, grouped by repo, recipe, or layer-recipe.

    Format: [status] [field] patch-name  subject
    All columns are aligned for readability.
    """
    if not patches:
        print("No patches found.")
        return

    # Calculate column widths for alignment
    max_status = max((len(p.upstream_status or "none") for p in patches), default=7)
    max_status = max(max_status, 7)  # minimum "Pending" width
    max_recipe = max((len(p.recipe_name or "") for p in patches), default=10)
    max_layer = max((len(p.layer_name or "") for p in patches), default=10)
    max_name = max((len(p.name) for p in patches), default=20)
    # Cap widths to reasonable limits
    max_recipe = min(max_recipe, 20)
    max_layer = min(max_layer, 18)
    max_name = min(max_name, 45)

    def _print_patch(p: Patch, field: str, field_width: int) -> None:
        """Print a single patch line: field: [status] patch-name  subject"""
        status = p.upstream_status or "none"
        name = p.name
        subject = p.subject or ""

        # Truncate if needed
        if len(name) > max_name:
            name = name[:max_name-2] + ".."
        if len(field) > field_width:
            field = field[:field_width-2] + ".."

        if verbose:
            print(f"  {field:<{field_width}} : [{status:<{max_status}}] {name}")
            print(f"      Path: {p.path}")
            if p.upstream_detail:
                print(f"      Detail: {p.upstream_detail}")
            if subject:
                print(f"      Subject: {subject}")
            print()
        else:
            # Compact: single line with subject
            # Format: recipe/layer: [status] patch-name  subject
            if subject and subject != name:
                # Remove [PATCH ...] prefix from subject if present
                subj_clean = re.sub(r'^\[PATCH[^\]]*\]\s*', '', subject)
                print(f"  {field:<{field_width}} : [{status:<{max_status}}] {name:<{max_name}}  {subj_clean}")
            else:
                print(f"  {field:<{field_width}} : [{status:<{max_status}}] {name}")

    if group_by == "layer-recipe":
        # Hierarchical: layer -> recipe -> patches
        by_layer: Dict[str, Dict[str, List[Patch]]] = {}
        for p in patches:
            layer = p.layer_name
            recipe = p.recipe_name or "(unknown)"
            if layer not in by_layer:
                by_layer[layer] = {}
            by_layer[layer].setdefault(recipe, []).append(p)

        for layer_name in sorted(by_layer.keys()):
            layer_recipes = by_layer[layer_name]
            layer_count = sum(len(rp) for rp in layer_recipes.values())
            print(f"\nLayer: {layer_name} ({layer_count} patches)")
            print("=" * 60)

            for recipe_name in sorted(layer_recipes.keys()):
                recipe_patches = layer_recipes[recipe_name]
                print(f"\n  Recipe: {recipe_name} ({len(recipe_patches)})")
                print("  " + "-" * 50)

                for p in sorted(recipe_patches, key=lambda x: x.name):
                    # No field needed - layer and recipe are in headers
                    status = p.upstream_status or "none"
                    name = p.name if len(p.name) <= max_name else p.name[:max_name-2] + ".."
                    subject = p.subject or ""

                    if verbose:
                        print(f"    [{status:<{max_status}}] {name}")
                        print(f"        Path: {p.path}")
                        if p.upstream_detail:
                            print(f"        Detail: {p.upstream_detail}")
                        if subject:
                            print(f"        Subject: {subject}")
                        print()
                    else:
                        if subject and subject != name:
                            subj_clean = re.sub(r'^\[PATCH[^\]]*\]\s*', '', subject)
                            print(f"    [{status:<{max_status}}] {name:<{max_name}}  {subj_clean}")
                        else:
                            print(f"    [{status:<{max_status}}] {name}")

    elif group_by == "recipe":
        by_group: Dict[str, List[Patch]] = {}
        for p in patches:
            key = p.recipe_name or "(unknown)"
            by_group.setdefault(key, []).append(p)

        for group_name in sorted(by_group.keys()):
            group_patches = by_group[group_name]
            print(f"\nRecipe: {group_name} ({len(group_patches)} patches)")
            print("-" * 60)

            for p in sorted(group_patches, key=lambda x: x.name):
                _print_patch(p, p.layer_name or "", max_layer)

    else:  # repo (default)
        by_group: Dict[str, List[Patch]] = {}
        for p in patches:
            by_group.setdefault(p.repo_name, []).append(p)

        for group_name in sorted(by_group.keys()):
            group_patches = by_group[group_name]
            print(f"\nRepo: {group_name} ({len(group_patches)} patches)")
            print("-" * 60)

            for p in sorted(group_patches, key=lambda x: x.name):
                _print_patch(p, p.recipe_name or "", max_recipe)


def _output_paths(patches: List[Patch]) -> None:
    """Output just patch paths, one per line (for piping to other tools)."""
    for p in sorted(patches, key=lambda x: x.path):
        print(p.path)


def _output_json(patches: List[Patch]) -> None:
    """Output patches as JSON array."""
    data = []
    for p in patches:
        data.append({
            "name": p.name,
            "path": p.path,
            "recipe": p.recipe_name,
            "layer": p.layer_name,
            "repo": p.repo_name,
            "upstream_status": p.upstream_status,
            "upstream_detail": p.upstream_detail,
            "subject": p.subject,
        })
    print(json.dumps(data, indent=2))


def _output_tsv(patches: List[Patch]) -> None:
    """Output patches as tab-separated values (path, recipe, layer, status, subject)."""
    # Header
    print("path\trecipe\tlayer\tstatus\tsubject")
    for p in sorted(patches, key=lambda x: x.path):
        status = p.upstream_status or "none"
        subject = p.subject.replace("\t", " ") if p.subject else ""
        print(f"{p.path}\t{p.recipe_name}\t{p.layer_name}\t{status}\t{subject}")


# =============================================================================
# Main Entry Point
# =============================================================================

def run_patches(args) -> int:
    """
    Main entry point for patches command.

    Args:
        args: Parsed command line arguments with:
            - by_recipe: Group by recipe instead of repo
            - status: Filter by Upstream-Status
            - search: Search term
            - body: Search patch content instead of name
            - list: Text output (no fzf)
            - verbose: Verbose text output
            - paths: Output just paths (for piping)
            - json: Output as JSON
            - tsv: Output as tab-separated values
            - count: Output just the count
    """
    bblayers = getattr(args, "bblayers", None)
    by_recipe = getattr(args, "by_recipe", False)
    by_layer_recipe = getattr(args, "by_layer_recipe", False)
    status_filter = getattr(args, "status", None) or ""
    search_query = getattr(args, "search", None) or ""
    search_body = getattr(args, "body", False)
    list_mode = getattr(args, "list", False)
    verbose = getattr(args, "verbose", False)
    paths_mode = getattr(args, "paths", False)
    json_mode = getattr(args, "json", False)
    tsv_mode = getattr(args, "tsv", False)
    count_mode = getattr(args, "count", False)

    # Resolve bblayers.conf
    bblayers_path = resolve_bblayers_path(bblayers)
    if not bblayers_path:
        print("No bblayers.conf found. Run from a Yocto/OE project directory.")
        return 1

    # Get layer paths
    try:
        layer_paths = extract_layer_paths(bblayers_path)
    except SystemExit:
        return 1

    # Suppress progress output for scripting modes
    quiet = paths_mode or json_mode or tsv_mode or count_mode

    # Discover patches
    patches = _scan_patches_from_layers(layer_paths, progress=not quiet)

    # Apply search filter
    if search_query:
        if search_body:
            patches = _search_patches_by_body(patches, search_query)
        else:
            patches = _search_patches_by_name(patches, search_query)
        if not quiet:
            print(f"Found {len(patches)} patches matching '{search_query}'")

    # Apply status filter
    if status_filter:
        patches = _filter_by_status(patches, status_filter)

    # Output modes for scripting
    if count_mode:
        print(len(patches))
        return 0

    if paths_mode:
        _output_paths(patches)
        return 0

    if json_mode:
        _output_json(patches)
        return 0

    if tsv_mode:
        _output_tsv(patches)
        return 0

    # Determine grouping mode
    if by_layer_recipe:
        group_by = "layer-recipe"
    elif by_recipe:
        group_by = "recipe"
    else:
        group_by = "repo"

    if list_mode:
        _list_patches_text(patches, verbose=verbose, group_by=group_by)
        return 0

    # Interactive browser
    search_mode = "body" if search_body else "name"
    return _patches_fzf_browser(patches, group_by=group_by, search_mode=search_mode, status_filter=status_filter)
