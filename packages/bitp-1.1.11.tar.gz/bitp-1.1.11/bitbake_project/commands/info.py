#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Info command - display build configuration and layer status."""

import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
from typing import Dict, List, Optional, Tuple

from ..core import (
    Colors,
    current_head,
    fzf_available,
    get_fzf_color_args,
    get_fzf_preview_resize_bindings,
)
from ..fzf_bindings import (
    get_exit_bindings,
    get_accept_binding,
    get_preview_header_suffix,
    get_preview_scroll_bindings,
    get_refresh_binding,
)
from .common import (
    resolve_bblayers_path,
    resolve_base_and_layers,
    repo_display_name,
    layer_display_name,
    get_repo_commit_info,
    get_project_header_prefix,
)
from .projects import get_preview_window_arg


# Key BitBake variables to display in info summary
# Format: (variable_name, description, category)
INFO_VARIABLES = [
    ("MACHINE", "Target machine", "Build"),
    ("DISTRO", "Distribution", "Build"),
    ("DISTRO_VERSION", "Distribution version", "Build"),
    ("BB_VERSION", "BitBake version", "Core"),
    ("BUILD_SYS", "Build system", "Core"),
    ("NATIVELSBSTRING", "Native LSB string", "Core"),
    ("TARGET_SYS", "Target system", "Target"),
    ("TUNE_FEATURES", "Tune features", "Target"),
    ("TARGET_FPU", "Target FPU", "Target"),
]

# Cache directory for bitbake-getvar results
CACHE_DIR = os.path.join(tempfile.gettempdir(), "bit-info-cache")


def _get_conf_checksum(bblayers_path: Optional[str] = None) -> str:
    """
    Compute checksum of conf files to detect when cache should be invalidated.
    Uses local.conf and bblayers.conf modification times and sizes.
    """
    bblayers_conf = resolve_bblayers_path(bblayers_path)
    if not bblayers_conf:
        return ""

    conf_dir = os.path.dirname(bblayers_conf)
    local_conf = os.path.join(conf_dir, "local.conf")

    parts = []
    for conf_file in [bblayers_conf, local_conf]:
        if os.path.isfile(conf_file):
            try:
                stat = os.stat(conf_file)
                parts.append(f"{conf_file}:{stat.st_mtime}:{stat.st_size}")
            except OSError:
                pass

    if not parts:
        return ""

    return hashlib.md5("|".join(parts).encode()).hexdigest()[:16]


def _get_cache_path(bblayers_path: Optional[str] = None) -> str:
    """Get cache file path for this build directory."""
    bblayers_conf = resolve_bblayers_path(bblayers_path)
    if not bblayers_conf:
        return ""

    # Use hash of bblayers.conf path as cache key
    path_hash = hashlib.md5(bblayers_conf.encode()).hexdigest()[:12]
    return os.path.join(CACHE_DIR, f"info-{path_hash}.json")


def _load_cache(bblayers_path: Optional[str] = None) -> Optional[Dict]:
    """Load cached variables if checksum matches."""
    cache_path = _get_cache_path(bblayers_path)
    if not cache_path or not os.path.isfile(cache_path):
        return None

    try:
        with open(cache_path, "r") as f:
            cached = json.load(f)

        # Verify checksum matches
        current_checksum = _get_conf_checksum(bblayers_path)
        if cached.get("checksum") == current_checksum and current_checksum:
            return cached.get("variables", {})
    except (json.JSONDecodeError, IOError, KeyError):
        pass

    return None


def _save_cache(variables: Dict[str, str], bblayers_path: Optional[str] = None) -> None:
    """Save variables to cache."""
    cache_path = _get_cache_path(bblayers_path)
    if not cache_path:
        return

    checksum = _get_conf_checksum(bblayers_path)
    if not checksum:
        return

    try:
        os.makedirs(CACHE_DIR, exist_ok=True)
        with open(cache_path, "w") as f:
            json.dump({"checksum": checksum, "variables": variables}, f)
    except (IOError, OSError):
        pass


def get_bitbake_version() -> Optional[str]:
    """Get BitBake version from bitbake --version."""
    if not shutil.which("bitbake"):
        return None
    try:
        output = subprocess.check_output(
            ["bitbake", "--version"],
            text=True,
            stderr=subprocess.DEVNULL,
        ).strip()
        # Output format: "BitBake Build Tool Core version 2.16.0"
        # Extract just the version number
        for line in output.splitlines():
            if "version" in line.lower():
                parts = line.split()
                if parts:
                    return parts[-1]  # Last word is version
        return output.splitlines()[0] if output else None
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def _parse_getvar_output(output: str, var_name: str) -> Optional[str]:
    """
    Parse bitbake-getvar output to extract just the value.
    The output format includes verbose info, but ends with: VARNAME="value"
    """
    # Look for line like: VARNAME="value" or VARNAME='value'
    pattern = rf'^{re.escape(var_name)}=(["\'])(.*)(\1)\s*$'
    for line in output.splitlines():
        match = re.match(pattern, line)
        if match:
            return match.group(2)

    # Fallback: try unquoted value
    pattern = rf'^{re.escape(var_name)}=(.+)$'
    for line in output.splitlines():
        match = re.match(pattern, line)
        if match:
            return match.group(1).strip()

    return None


def get_variable_value(var_name: str) -> Optional[str]:
    """Get a variable value using bitbake-getvar."""
    if not shutil.which("bitbake-getvar"):
        return None
    try:
        output = subprocess.check_output(
            ["bitbake-getvar", var_name],
            text=True,
            stderr=subprocess.DEVNULL,
            timeout=30,  # Timeout in case bitbake is slow
        )
        return _parse_getvar_output(output, var_name)
    except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
        return None


def get_all_variables_cached(bblayers_path: Optional[str] = None) -> Dict[str, str]:
    """
    Get all info variables, using cache when available.
    This avoids calling bitbake-getvar multiple times.
    """
    # Try cache first
    cached = _load_cache(bblayers_path)
    if cached:
        return cached

    # No cache - fetch from bitbake-getvar
    variables = {}

    # Get BB_VERSION specially (fast, doesn't need bitbake-getvar)
    bb_version = get_bitbake_version()
    if bb_version:
        variables["BB_VERSION"] = bb_version

    # Check if bitbake-getvar is available
    if not shutil.which("bitbake-getvar"):
        # Fall back to local.conf parsing
        bblayers_conf = resolve_bblayers_path(bblayers_path)
        if bblayers_conf:
            conf_dir = os.path.dirname(bblayers_conf)
            fallback = parse_local_conf_variables(conf_dir)
            variables.update(fallback)
        return variables

    # Fetch each variable
    for var_name, desc, category in INFO_VARIABLES:
        if var_name == "BB_VERSION":
            continue  # Already got this
        value = get_variable_value(var_name)
        if value is not None:
            variables[var_name] = value

    # Save to cache
    _save_cache(variables, bblayers_path)

    return variables


def parse_local_conf_variables(conf_dir: str) -> Dict[str, str]:
    """Parse key variables from local.conf as fallback when bitbake-getvar unavailable."""
    local_conf = os.path.join(conf_dir, "local.conf")
    if not os.path.isfile(local_conf):
        return {}

    variables = {}
    target_vars = {"MACHINE", "DISTRO", "DISTRO_VERSION"}

    try:
        with open(local_conf, "r") as f:
            for line in f:
                line = line.strip()
                if line.startswith("#"):
                    continue
                # Match simple assignments: VAR = "value" or VAR = 'value'
                for var in target_vars:
                    if line.startswith(var) and "=" in line:
                        # Extract value after =
                        eq_pos = line.find("=")
                        value = line[eq_pos + 1:].strip()
                        # Handle quoted values with possible inline comments
                        if value.startswith('"'):
                            # Find closing quote
                            end_quote = value.find('"', 1)
                            if end_quote > 0:
                                value = value[1:end_quote]
                        elif value.startswith("'"):
                            # Find closing quote
                            end_quote = value.find("'", 1)
                            if end_quote > 0:
                                value = value[1:end_quote]
                        else:
                            # Unquoted - remove inline comments
                            if "#" in value:
                                value = value[:value.find("#")]
                        # Final strip to remove any extra whitespace
                        value = value.strip()
                        if value:
                            variables[var] = value
    except (IOError, OSError):
        pass

    return variables


def get_layer_info(bblayers_path: Optional[str] = None) -> List[Tuple[str, str, str, str]]:
    """
    Get layer info with branch and commit hash.
    Returns: [(layer_name, branch, commit_hash, repo_path), ...]
    """
    pairs, _repo_sets = resolve_base_and_layers(bblayers_path)
    if not pairs:
        return []

    layer_info = []
    seen_repos = set()

    for layer_path, repo_path in pairs:
        # Get layer name
        layer_name = layer_display_name(layer_path)

        # Get repo info (only once per repo for efficiency)
        if repo_path not in seen_repos:
            seen_repos.add(repo_path)

        # Get branch and commit
        branch, remote_exists, remote_ref, count, range_spec, desc = get_repo_commit_info(repo_path)
        commit_hash = current_head(repo_path) or ""

        if branch:
            layer_info.append((layer_name, branch, commit_hash[:40], repo_path))
        else:
            # Detached HEAD
            layer_info.append((layer_name, "(detached)", commit_hash[:40], repo_path))

    return layer_info


def get_build_info(bblayers_path: Optional[str] = None) -> Dict[str, any]:
    """
    Gather all build info into a dictionary.
    Returns dict with 'variables', 'layers', and metadata.
    """
    info = {
        "variables": {},
        "layers": [],
        "bitbake_available": False,
        "getvar_available": False,
    }

    # Check tool availability
    info["bitbake_available"] = shutil.which("bitbake") is not None
    info["getvar_available"] = shutil.which("bitbake-getvar") is not None

    # Get variables (uses cache)
    info["variables"] = get_all_variables_cached(bblayers_path)

    # Get layer info
    info["layers"] = get_layer_info(bblayers_path)

    return info


def format_info_text(info: Dict, show_layers: bool = True, show_vars: bool = True) -> str:
    """Format build info as text output similar to BitBake's build summary."""
    lines = []

    if show_vars:
        lines.append("Build Configuration:")

        # Find max variable name length for alignment
        var_names = list(info["variables"].keys())
        if var_names:
            max_len = max(len(name) for name in var_names)
        else:
            max_len = 20

        # Output variables in order defined in INFO_VARIABLES
        for var_name, desc, category in INFO_VARIABLES:
            value = info["variables"].get(var_name, "")
            if value:
                lines.append(f"  {var_name:<{max_len}} = {value}")

        # Check if bitbake tools not available
        if not info["getvar_available"] and not info["bitbake_available"]:
            lines.append("")
            lines.append("  (Note: bitbake-getvar not available - showing local.conf values only)")
            lines.append("  (Source oe-init-build-env for full variable resolution)")

    if show_layers and info["layers"]:
        if show_vars:
            lines.append("")
        lines.append("Layers:")

        # Find max layer name length for alignment
        layer_names = [layer[0] for layer in info["layers"]]
        if layer_names:
            max_len = max(len(name) for name in layer_names)
        else:
            max_len = 20

        # Group layers by repo to show combined entries like BitBake does
        # meta-poky and meta-yocto-bsp might share same branch:commit
        seen_combos = {}  # (branch, commit) -> [layer_names]
        repo_order = []  # Track order by first seen repo

        for layer_name, branch, commit, repo_path in info["layers"]:
            key = (branch, commit, repo_path)
            if key not in seen_combos:
                seen_combos[key] = []
                repo_order.append(key)
            seen_combos[key].append(layer_name)

        for branch, commit, repo_path in repo_order:
            layers = seen_combos[(branch, commit, repo_path)]
            if len(layers) == 1:
                layer_display = layers[0]
            else:
                # Multiple layers in same repo - show first then indent rest
                layer_display = layers[0]

            commit_short = commit[:40] if commit else ""
            lines.append(f"  {layer_display:<{max_len}} = \"{branch}:{commit_short}\"")

            # Show additional layers from same repo on following lines
            for extra_layer in layers[1:]:
                lines.append(f"  {extra_layer:<{max_len}}")

    return "\n".join(lines)


def run_info(args) -> int:
    """Run the info command."""
    info = get_build_info(args.bblayers)

    if hasattr(args, "info_command"):
        if args.info_command == "layers":
            print(format_info_text(info, show_layers=True, show_vars=False))
        elif args.info_command == "vars":
            print(format_info_text(info, show_layers=False, show_vars=True))
        else:
            # Default: show all
            print(format_info_text(info))
    else:
        # No subcommand - show all
        print(format_info_text(info))

    return 0


def fzf_info_browser(bblayers_path: Optional[str] = None) -> None:
    """Interactive fzf browser for build info."""
    if not fzf_available():
        print("fzf not available")
        return

    info = get_build_info(bblayers_path)

    # Build menu lines
    menu_lines = []

    # Header for variables section
    menu_lines.append(f"SECTION:vars\t{Colors.cyan('Build Configuration')}")

    # Add variables
    var_names = list(info["variables"].keys())
    max_var_len = max(len(name) for name in var_names) if var_names else 20

    for var_name, desc, category in INFO_VARIABLES:
        value = info["variables"].get(var_name, "")
        if value:
            padded = f"{var_name:<{max_var_len}}"
            menu_lines.append(f"VAR:{var_name}\t  {Colors.green(padded)} = {value}")

    # Separator
    menu_lines.append(f"SEPARATOR\t")

    # Header for layers section
    menu_lines.append(f"SECTION:layers\t{Colors.cyan('Layers')}")

    # Add layers
    layer_names = [layer[0] for layer in info["layers"]]
    max_layer_len = max(len(name) for name in layer_names) if layer_names else 20

    for layer_name, branch, commit, repo_path in info["layers"]:
        padded = f"{layer_name:<{max_layer_len}}"
        commit_short = commit[:12] if commit else ""
        menu_lines.append(f"LAYER:{repo_path}\t  {Colors.yellow(padded)} = {branch}:{commit_short}")

    # Build preview command
    bblayers_conf = resolve_bblayers_path(bblayers_path)
    conf_dir = os.path.dirname(bblayers_conf) if bblayers_conf else "/tmp"

    preview_script = f'''
item="$1"
if [[ "$item" == VAR:* ]]; then
    var_name="${{item#VAR:}}"
    if command -v bitbake-getvar &>/dev/null; then
        echo "Variable: $var_name"
        echo
        bitbake-getvar "$var_name" 2>/dev/null || echo "(Could not resolve)"
    else
        echo "Variable: $var_name"
        echo
        echo "(bitbake-getvar not available)"
        echo "Source oe-init-build-env first"
    fi
elif [[ "$item" == LAYER:* ]]; then
    repo_path="${{item#LAYER:}}"
    echo "Layer repository: $repo_path"
    echo
    git -C "$repo_path" log --oneline -20 2>/dev/null || echo "(Could not read git log)"
elif [[ "$item" == SECTION:* ]]; then
    section="${{item#SECTION:}}"
    if [ "$section" = "vars" ]; then
        echo "Build Variables"
        echo
        echo "Key BitBake variables for this build configuration."
        echo "Press Enter on a variable to see its full resolved value."
    else
        echo "Layers"
        echo
        echo "Layers configured in bblayers.conf."
        echo "Format: layer_name = branch:commit_hash"
        echo
        echo "Press Enter on a layer to see its repository details."
    fi
else
    echo "Build Information"
fi
'''

    preview_script_file = os.path.join(tempfile.gettempdir(), f"bit-info-preview-{os.getpid()}.sh")
    with open(preview_script_file, "w") as f:
        f.write(preview_script)
    os.chmod(preview_script_file, 0o755)

    preview_cmd = f"{preview_script_file} {{1}}"
    preview_arg = get_preview_window_arg("60%")

    try:
        while True:
            header = f"{get_project_header_prefix()}Build Info | Enter=details | r=refresh | {get_preview_header_suffix()}"
            fzf_cmd = [
                "fzf",
                "--ansi",
                "--no-multi",
                "--no-sort",
                "--layout=reverse-list",
                "--height", "80%",
                "--header", header,
                "--prompt", "Info: ",
                "--with-nth", "2..",
                "--delimiter", "\t",
                "--preview", preview_cmd,
                "--preview-window", preview_arg,
            ] + get_exit_bindings(mode="back") \
              + get_accept_binding() \
              + get_preview_scroll_bindings() \
              + get_refresh_binding() \
              + get_fzf_preview_resize_bindings() \
              + get_fzf_color_args()

            result = subprocess.run(
                fzf_cmd,
                input="\n".join(menu_lines),
                stdout=subprocess.PIPE,
                text=True,
            )

            if result.returncode != 0 or not result.stdout.strip():
                break

            output = result.stdout.strip()

            if output == "BACK":
                break
            elif output == "REFRESH":
                # Refresh info (invalidate cache)
                cache_path = _get_cache_path(bblayers_path)
                if cache_path and os.path.exists(cache_path):
                    try:
                        os.unlink(cache_path)
                    except OSError:
                        pass
                info = get_build_info(bblayers_path)
                # Rebuild menu lines
                menu_lines = []
                menu_lines.append(f"SECTION:vars\t{Colors.cyan('Build Configuration')}")
                for var_name, desc, category in INFO_VARIABLES:
                    value = info["variables"].get(var_name, "")
                    if value:
                        padded = f"{var_name:<{max_var_len}}"
                        menu_lines.append(f"VAR:{var_name}\t  {Colors.green(padded)} = {value}")
                menu_lines.append(f"SEPARATOR\t")
                menu_lines.append(f"SECTION:layers\t{Colors.cyan('Layers')}")
                for layer_name, branch, commit, repo_path in info["layers"]:
                    padded = f"{layer_name:<{max_layer_len}}"
                    commit_short = commit[:12] if commit else ""
                    menu_lines.append(f"LAYER:{repo_path}\t  {Colors.yellow(padded)} = {branch}:{commit_short}")
                continue
            elif output.startswith("VAR:"):
                # Show variable details
                var_name = output.split("\t")[0][4:]
                if shutil.which("bitbake-getvar"):
                    print(f"\nResolving {var_name}...")
                    subprocess.run(["bitbake-getvar", var_name])
                    input("\nPress Enter to continue...")
                else:
                    print(f"\nbitbake-getvar not available")
                    print("Source oe-init-build-env to enable variable resolution")
                    input("\nPress Enter to continue...")
            elif output.startswith("LAYER:"):
                # Show layer/repo details
                repo_path = output.split("\t")[0][6:]
                print(f"\nRepository: {repo_path}")
                print("-" * 60)
                subprocess.run(["git", "-C", repo_path, "log", "--oneline", "-30"])
                input("\nPress Enter to continue...")
    finally:
        if os.path.exists(preview_script_file):
            try:
                os.unlink(preview_script_file)
            except OSError:
                pass
