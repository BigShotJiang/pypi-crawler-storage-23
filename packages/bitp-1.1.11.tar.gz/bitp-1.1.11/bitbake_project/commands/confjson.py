#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Parser for bitbake-setup .conf.json configuration files.

Parses Configuration Template files used by bitbake-setup to describe
which repos to clone, which layers to enable, and which OE fragments to apply.
"""

import json
import logging
import os
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class ConfSource:
    """A source repository from a .conf.json file."""
    name: str                            # e.g., "openembedded-core"
    path: str                            # relative dest in layers/ dir
    git_url: str                         # primary URI (first remote or "uri" field)
    remotes: Dict[str, str] = field(default_factory=dict)  # name -> URI
    branch: str = ""                     # branch name
    rev: str = ""                        # branch name or commit hash
    is_local: bool = False               # local path source (symlink)
    local_path: str = ""                 # expanded local path


@dataclass
class ConfOneOfOption:
    """A single option in an oe-fragments-one-of category."""
    name: str                            # fragment path, e.g., "machine/qemux86-64"
    description: str = ""


@dataclass
class ConfOneOfCategory:
    """A category of one-of fragment options (e.g., machine, distro)."""
    description: str
    options: List[ConfOneOfOption] = field(default_factory=list)


@dataclass
class ConfConfig:
    """A flattened leaf configuration from the configurations tree."""
    name: str                            # e.g., "qemux86-64-poky"
    description: str = ""
    bb_layers: List[str] = field(default_factory=list)        # paths relative to layers/
    oe_fragments: List[str] = field(default_factory=list)     # e.g., ["core/yocto/sstate-mirror-cdn"]
    oe_fragments_one_of: Dict[str, ConfOneOfCategory] = field(default_factory=dict)


@dataclass
class ConfJson:
    """Parsed representation of a .conf.json file."""
    version: str = ""
    description: str = ""
    sources: List[ConfSource] = field(default_factory=list)
    configurations: List[ConfConfig] = field(default_factory=list)


# =============================================================================
# Parsing
# =============================================================================

def _parse_source(name: str, src: dict) -> ConfSource:
    """Parse a single source entry from the sources dict."""
    # Check for local source
    local = src.get("local")
    if local:
        local_path = os.path.expanduser(local.get("path", ""))
        return ConfSource(
            name=name,
            path=src.get("path", name),
            git_url="",
            is_local=True,
            local_path=local_path,
        )

    # Git remote source
    git_remote = src.get("git-remote", {})
    git_url = ""
    remotes: Dict[str, str] = {}

    # Two formats: direct "uri" or nested "remotes"
    if "uri" in git_remote:
        git_url = git_remote["uri"]
    elif "remotes" in git_remote:
        for remote_name, remote_info in git_remote["remotes"].items():
            uri = remote_info.get("uri", "")
            remotes[remote_name] = uri
            if not git_url:
                git_url = uri  # Use first remote as primary URL

    branch = git_remote.get("branch", "")
    rev = git_remote.get("rev", "")

    return ConfSource(
        name=name,
        path=src.get("path", name),
        git_url=git_url,
        remotes=remotes,
        branch=branch,
        rev=rev,
    )


def _parse_one_of(raw: dict) -> Dict[str, ConfOneOfCategory]:
    """Parse oe-fragments-one-of into category dict."""
    result: Dict[str, ConfOneOfCategory] = {}
    for cat_name, cat_data in raw.items():
        desc = cat_data.get("description", "")
        options = []
        for opt in cat_data.get("options", []):
            if isinstance(opt, str):
                # Simple string format: "machine/qemux86-64"
                options.append(ConfOneOfOption(name=opt))
            elif isinstance(opt, dict):
                # Named format: {"name": "machine/qemux86-64", "description": "..."}
                options.append(ConfOneOfOption(
                    name=opt.get("name", ""),
                    description=opt.get("description", ""),
                ))
        result[cat_name] = ConfOneOfCategory(description=desc, options=options)
    return result


def flatten_configurations(
    configs: list,
    parent_layers: Optional[List[str]] = None,
    parent_fragments: Optional[List[str]] = None,
    parent_one_of: Optional[Dict[str, ConfOneOfCategory]] = None,
) -> List[ConfConfig]:
    """
    Recursively flatten the configurations tree.

    Child configurations inherit parent's bb-layers, oe-fragments (concatenated),
    and oe-fragments-one-of (merged). Only leaf configs (those with a name and
    no further nested children, or named children) become entries in the flat list.

    If a config has name AND nested configurations, it's treated as a non-leaf parent
    unless none of the children have names (in which case it IS the leaf).
    """
    if parent_layers is None:
        parent_layers = []
    if parent_fragments is None:
        parent_fragments = []
    if parent_one_of is None:
        parent_one_of = {}

    result: List[ConfConfig] = []

    for cfg in configs:
        # Accumulate layers, fragments, one-of from this level
        current_layers = parent_layers + cfg.get("bb-layers", [])
        current_fragments = parent_fragments + cfg.get("oe-fragments", [])

        # Merge one-of: parent categories + this level's categories
        current_one_of = dict(parent_one_of)
        raw_one_of = cfg.get("oe-fragments-one-of", {})
        if raw_one_of:
            parsed = _parse_one_of(raw_one_of)
            current_one_of.update(parsed)

        children = cfg.get("configurations", [])
        name = cfg.get("name", "")
        description = cfg.get("description", "")

        if children:
            # Has children - always recurse to find leaf nodes
            result.extend(flatten_configurations(
                children, current_layers, current_fragments, current_one_of,
            ))

            # If this node has a name but none of the children do, treat this as a leaf too
            named_children = [c for c in children if c.get("name")]
            if name and not named_children:
                result.append(ConfConfig(
                    name=name,
                    description=description,
                    bb_layers=current_layers,
                    oe_fragments=current_fragments,
                    oe_fragments_one_of=current_one_of,
                ))
        elif name:
            # Leaf node with a name
            result.append(ConfConfig(
                name=name,
                description=description,
                bb_layers=current_layers,
                oe_fragments=current_fragments,
                oe_fragments_one_of=current_one_of,
            ))

    return result


def parse_conf_json_data(data: dict) -> ConfJson:
    """
    Parse a .conf.json dict into a ConfJson object.

    Args:
        data: Parsed JSON dict from a .conf.json file.

    Returns:
        Parsed ConfJson with sources and flattened configurations.

    Raises:
        KeyError: If required fields are missing.
    """
    version = data.get("version", "")
    description = data.get("description", "")

    sources = []
    raw_sources = data.get("sources", {})
    for name, src in raw_sources.items():
        sources.append(_parse_source(name, src))

    bitbake_setup = data.get("bitbake-setup", {})
    raw_configs = bitbake_setup.get("configurations", [])
    configurations = flatten_configurations(raw_configs)

    return ConfJson(
        version=version,
        description=description,
        sources=sources,
        configurations=configurations,
    )


def parse_conf_json(path: str) -> ConfJson:
    """
    Parse a .conf.json file into a ConfJson object.

    Args:
        path: Path to the .conf.json file.

    Returns:
        Parsed ConfJson with sources and flattened configurations.

    Raises:
        FileNotFoundError: If file doesn't exist.
        json.JSONDecodeError: If file is not valid JSON.
        KeyError: If required fields are missing.
    """
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return parse_conf_json_data(data)


# =============================================================================
# Registry Discovery
# =============================================================================

def find_registry_dirs() -> List[Tuple[str, str]]:
    """
    Return list of (directory_path, source_label) tuples for registry scanning.

    Priority order:
      1. layers/bitbake/default-registry/ (bitbake-setup's built-in)
      2. ~/.config/bit/registry/ (user-configured)
    """
    dirs: List[Tuple[str, str]] = []

    # bitbake-setup's built-in registry
    builtin = os.path.join("layers", "bitbake", "default-registry")
    if os.path.isdir(builtin):
        dirs.append((builtin, "Built-in"))

    # User-configured registry
    user_registry = os.path.expanduser(os.path.join("~", ".config", "bit", "registry"))
    if os.path.isdir(user_registry):
        dirs.append((user_registry, "User"))

    return dirs


def discover_registry(registry_dir: str, source_label: str = "") -> List[Tuple[str, str, str, ConfJson, str]]:
    """
    Recursively find all .conf.json files in a directory.

    Args:
        registry_dir: Directory to scan.
        source_label: Label indicating the source (e.g. "Built-in", "User").

    Returns:
        List of (filename, full_path, relative_path, parsed_config, source_label) tuples.
        Files that fail to parse are skipped with a warning.
    """
    results: List[Tuple[str, str, str, ConfJson, str]] = []

    if not os.path.isdir(registry_dir):
        return results

    for root, _dirs, files in os.walk(registry_dir):
        for fname in sorted(files):
            if not fname.endswith(".conf.json"):
                continue

            full_path = os.path.join(root, fname)
            rel_path = os.path.relpath(full_path, registry_dir)

            try:
                parsed = parse_conf_json(full_path)
                results.append((fname, full_path, rel_path, parsed, source_label))
            except (json.JSONDecodeError, KeyError, OSError) as e:
                logger.warning("Failed to parse %s: %s", full_path, e)

    return results
