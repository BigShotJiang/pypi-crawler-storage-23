#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Inline options menu abstraction for fzf-based browsers.

Provides a reusable pattern for showing options/settings menus inline
at the bottom of an fzf browser, with:
- Toggle options (checkboxes)
- Grouped sections
- Action buttons
- Query capture for search

Usage:
    from bitbake_project.tui import InlineOptionsMenu, InlineOptionsState

    # Define the menu structure
    menu = InlineOptionsMenu(
        sections=[
            OptionsSection("Search In", [
                ToggleOption("name", "Name", default=True),
                ToggleOption("summary", "Summary"),
            ]),
            OptionsSection("Sources", [
                ToggleOption("local", "Local", default=True),
                ToggleOption("index", "Index"),
            ]),
        ],
        actions=[
            OptionAction("search", "Search", "type query below, Enter"),
            OptionAction("browse", "Browse", "show all, filter in browser"),
        ],
    )

    # Track state
    state = InlineOptionsState(menu)

    # Build fzf menu lines (append to your main menu)
    options_lines = state.build_menu_lines()

    # Get fzf args for options mode
    fzf_args = state.get_fzf_args()

    # Parse selection
    result = state.parse_selection(selected_value, typed_query)
"""

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple


@dataclass
class ToggleOption:
    """A toggleable option (checkbox)."""
    key: str           # Internal key for tracking state
    label: str         # Display label
    description: str = ""  # Optional description
    default: bool = False  # Default state


@dataclass
class OptionAction:
    """An action button in the options menu."""
    key: str           # Internal key
    label: str         # Display label
    description: str = ""  # Optional description shown in parentheses


@dataclass
class OptionsSection:
    """A section in the options menu with a header."""
    title: str
    items: List[ToggleOption] = field(default_factory=list)


@dataclass
class InlineOptionsMenu:
    """
    Definition of an inline options menu.

    The menu is rendered at the bottom of the fzf list (closest to prompt)
    with sections in this visual order (top to bottom):
    - sections[0] (furthest from prompt)
    - sections[1]
    - ...
    - actions (closest to prompt)
    """
    sections: List[OptionsSection] = field(default_factory=list)
    actions: List[OptionAction] = field(default_factory=list)
    header: str = "Space=toggle | Enter=select | Type query for Search | Esc=close"


@dataclass
class OptionsResult:
    """Result from options menu interaction."""
    action: Optional[str] = None  # Action key if an action was selected
    toggled: Optional[str] = None  # Toggle key if a toggle was toggled
    query: str = ""  # Typed query text
    cancelled: bool = False  # True if Esc was pressed


class InlineOptionsState:
    """
    Manages state for an inline options menu.

    Tracks toggle states and provides methods to:
    - Build menu lines for fzf
    - Get fzf command args for options mode
    - Parse fzf output
    """

    PREFIX = "OPT:"
    SEPARATOR = "---"

    def __init__(
        self,
        menu: InlineOptionsMenu,
        colors: Optional[Dict[str, Callable[[str], str]]] = None,
    ):
        """
        Initialize options state.

        Args:
            menu: The menu definition
            colors: Optional color functions dict with 'dim', 'cyan', etc.
        """
        self.menu = menu
        self._toggle_states: Dict[str, bool] = {}

        # Initialize toggle states from defaults
        for section in menu.sections:
            for item in section.items:
                self._toggle_states[item.key] = item.default

        # Setup colors
        if colors:
            self.dim = colors.get('dim', lambda x: x)
            self.cyan = colors.get('cyan', lambda x: x)
        else:
            self.dim = lambda x: f"\033[2m{x}\033[0m"
            self.cyan = lambda x: f"\033[36m{x}\033[0m"

    def get_state(self, key: str) -> bool:
        """Get current state of a toggle."""
        return self._toggle_states.get(key, False)

    def set_state(self, key: str, value: bool) -> None:
        """Set state of a toggle."""
        self._toggle_states[key] = value

    def toggle(self, key: str) -> bool:
        """Toggle a state and return new value."""
        new_val = not self._toggle_states.get(key, False)
        self._toggle_states[key] = new_val
        return new_val

    def get_all_states(self) -> Dict[str, bool]:
        """Get all toggle states."""
        return dict(self._toggle_states)

    def set_states(self, states: Dict[str, bool]) -> None:
        """Set multiple toggle states at once."""
        self._toggle_states.update(states)

    def _chk(self, key: str) -> str:
        """Get checkbox display for a key."""
        return "[x]" if self._toggle_states.get(key) else "[ ]"

    def build_menu_lines(self) -> List[str]:
        """
        Build fzf menu lines for the options menu.

        Returns lines in the order they should be APPENDED to the main menu.
        With --layout=reverse-list, the LAST item appears closest to the prompt.

        Visual order (top to bottom):
        - Section headers and toggles (sections[0] first)
        - Actions section (last, closest to prompt)
        """
        lines = []

        # Build sections in display order (first section = top = first in list)
        for section in self.menu.sections:
            # Section header
            lines.append(f"{self.PREFIX}{self.SEPARATOR}\t  ── {section.title} {'─' * (40 - len(section.title))}")

            # Toggle items in section
            for item in section.items:
                label = f"  {self._chk(item.key)} {item.label}"
                if item.description:
                    label += f"   ({item.description})"
                lines.append(f"{self.PREFIX}{item.key}\t{label}")

        # Actions section (last = closest to prompt)
        if self.menu.actions:
            lines.append(f"{self.PREFIX}{self.SEPARATOR}\t  ── Actions {'─' * 28}")
            for action in self.menu.actions:
                label = f"  > {action.label}"
                if action.description:
                    label += f"            ({action.description})"
                lines.append(f"{self.PREFIX}{action.key}\t{label}")

        return lines

    def get_fzf_args(self) -> List[str]:
        """
        Get fzf command arguments for options mode.

        Returns args to extend onto fzf command:
        - --disabled: don't filter, capture query as text
        - --no-sort: keep items in order (options at bottom)
        - --print-query: output typed query
        - --bind load:last: position cursor at bottom (actions)
        - --expect space: capture space key for toggling
        """
        return [
            "--disabled",
            "--no-sort",
            "--print-query",
            "--bind", "load:last",
            "--bind", "esc:abort",
            "--expect", "space",
        ]

    def parse_selection(
        self,
        fzf_output: str,
        return_code: int,
    ) -> OptionsResult:
        """
        Parse fzf output from options mode.

        Args:
            fzf_output: Raw stdout from fzf
            return_code: fzf return code

        Returns:
            OptionsResult with action, toggled key, query, or cancelled flag
        """
        if return_code != 0:
            return OptionsResult(cancelled=True)

        lines = fzf_output.split("\n")
        query = lines[0].strip() if lines else ""
        key_pressed = lines[1].strip() if len(lines) > 1 else ""
        selected = lines[2].split("\t")[0].strip() if len(lines) > 2 else ""

        # Handle separator (ignore)
        if selected == f"{self.PREFIX}{self.SEPARATOR}":
            return OptionsResult(query=query)

        # Check if it's an options item
        if not selected.startswith(self.PREFIX):
            return OptionsResult(query=query)

        item_key = selected[len(self.PREFIX):]

        # Check if it's a toggle
        if item_key in self._toggle_states:
            # Space key or Enter on toggle item
            if key_pressed == "space" or not key_pressed:
                self.toggle(item_key)
                return OptionsResult(toggled=item_key, query=query)

        # Check if it's an action
        for action in self.menu.actions:
            if item_key == action.key and not key_pressed:
                return OptionsResult(action=action.key, query=query)

        return OptionsResult(query=query)

    def is_options_item(self, value: str) -> bool:
        """Check if a value is from the options menu."""
        return value.startswith(self.PREFIX)


def build_recipe_options_menu(
    available_sources: List[str],
    has_local: bool = True,
) -> InlineOptionsMenu:
    """
    Build the standard recipe browser options menu.

    Args:
        available_sources: List of available source names
        has_local: Whether local sources are available
    """
    sections = []

    # Search In section
    search_in = OptionsSection("Search In", [
        ToggleOption("name", "Name", default=True),
        ToggleOption("summary", "Summary"),
        ToggleOption("description", "Description"),
    ])
    sections.append(search_in)

    # Sources section
    source_items = []
    if "configured" in available_sources:
        source_items.append(ToggleOption("configured", "Config", "layers in bblayers.conf", default=has_local))
    if "local" in available_sources:
        source_items.append(ToggleOption("local", "Local", "configured + discovered", default=has_local))
    if "index" in available_sources:
        source_items.append(ToggleOption("index", "Index", "remote API", default=not has_local))

    if source_items:
        sources = OptionsSection("Sources", source_items)
        sections.append(sources)

    # Options section (sort, etc)
    options = OptionsSection("Options", [
        ToggleOption("sort_layer", "Sort by layer", default=False),
    ])
    sections.append(options)

    # Actions
    actions = [
        OptionAction("browse", "Browse", "show all, filter in browser"),
        OptionAction("search", "Search", "type query below, Enter"),
    ]

    return InlineOptionsMenu(sections=sections, actions=actions)


def build_patches_search_menu() -> InlineOptionsMenu:
    """Build the patches search dialog (ctrl-s)."""
    sections = [
        OptionsSection("Search In", [
            ToggleOption("name", "Name", "patch filename", default=True),
            ToggleOption("body", "Body", "patch content"),
        ]),
    ]

    actions = [
        OptionAction("search", "Search", "type query below, Enter"),
    ]

    return InlineOptionsMenu(
        sections=sections,
        actions=actions,
        header="Space=toggle | Enter=search | Type query | Esc=close",
    )


def build_patches_filter_menu() -> InlineOptionsMenu:
    """Build the patches filter dialog (ctrl-t)."""
    sections = [
        OptionsSection("Filter by Status", [
            ToggleOption("filter_pending", "Pending", "no determination yet"),
            ToggleOption("filter_submitted", "Submitted", "sent upstream"),
            ToggleOption("filter_backport", "Backport", "from newer upstream"),
            ToggleOption("filter_accepted", "Accepted", "accepted upstream"),
            ToggleOption("filter_denied", "Denied", "rejected by upstream"),
            ToggleOption("filter_inactive", "Inactive-Upstream", "project defunct"),
            ToggleOption("filter_inappropriate", "Inappropriate", "not for upstream"),
            ToggleOption("filter_missing", "Missing", "no status tag"),
        ]),
    ]

    actions = [
        OptionAction("reset", "Reset", "clear all filters"),
        OptionAction("apply", "Apply", "filter patches"),
    ]

    return InlineOptionsMenu(
        sections=sections,
        actions=actions,
        header="Space=toggle | Enter=apply | Esc=close",
    )


def build_lore_search_menu() -> InlineOptionsMenu:
    """Build the lore search options menu for b4."""
    sections = [
        OptionsSection("Search In", [
            ToggleOption("search_any", "Any field", default=True),
            ToggleOption("search_subject", "Subject"),
            ToggleOption("search_body", "Body"),
        ]),
        OptionsSection("Time Range", [
            ToggleOption("time_2y", "Last 2 years", default=True),
            ToggleOption("time_5y", "Last 5 years"),
            ToggleOption("time_all", "All time"),
        ]),
        OptionsSection("Options", [
            ToggleOption("threads", "Include threads"),
        ]),
    ]
    actions = [
        OptionAction("search", "Search", "type query below, Enter"),
    ]
    return InlineOptionsMenu(
        sections=sections,
        actions=actions,
        header="Space=toggle | Enter=search | Type query | Esc=close",
    )


def build_dashboard_search_menu() -> InlineOptionsMenu:
    """Build the dashboard search/filter dialog (/ key)."""
    sections = [
        OptionsSection("Search In", [
            ToggleOption("name", "Name", default=True),
            ToggleOption("description", "Description"),
            ToggleOption("branch", "Branch"),
            ToggleOption("path", "Path"),
            ToggleOption("host", "Host", "remote hostname"),
        ]),
        OptionsSection("Status Filter", [
            ToggleOption("dirty", "Dirty", "uncommitted changes"),
            ToggleOption("ahead", "Ahead", "unpushed commits"),
            ToggleOption("behind", "Behind", "behind upstream"),
            ToggleOption("needs_setup", "Needs setup"),
        ]),
    ]
    actions = [
        OptionAction("search", "Search", "type query below, Enter"),
        OptionAction("reset", "Reset", "clear search and filters"),
    ]
    return InlineOptionsMenu(
        sections=sections,
        actions=actions,
        header="Space=toggle | Enter=select | Type query for Search | Esc=close",
    )


@dataclass
class InlineSelectorItem:
    """An item in an inline selector."""
    key: str           # Value returned on selection
    label: str         # Display label
    marker: str = ""   # e.g., "\u2022" for current selection


class InlineSelector:
    """
    Inline selector for picking one item from a list.

    Lighter-weight than InlineOptionsMenu — for simple "pick one" use cases.
    Renders items at the bottom of an fzf list, closest to the prompt,
    using the same inline expansion pattern.

    Usage:
        selector = InlineSelector("Pick a fruit", [
            InlineSelectorItem("ALL", "all fruits         (12 total)"),
            InlineSelectorItem("apple", "apple              3"),
            InlineSelectorItem("banana", "banana             5", marker="\u2022"),
        ])

        # Append to menu
        menu_input += "\\n" + "\\n".join(selector.build_menu_lines())

        # Extend fzf args
        fzf_cmd.extend(selector.get_fzf_args())

        # Parse result
        selected_key = selector.parse_selection(result.stdout, result.returncode)
    """

    PREFIX = "SEL:"
    SEPARATOR = "---"

    def __init__(
        self,
        title: str,
        items: List[InlineSelectorItem],
        header: str = "Enter=select | Esc=close",
    ):
        self.title = title
        self.items = items
        self.header = header

    def build_menu_lines(self) -> List[str]:
        """Build fzf menu lines to append to main menu."""
        lines = []
        pad = max(1, 40 - len(self.title))
        lines.append(f"{self.PREFIX}{self.SEPARATOR}\t  \u2500\u2500 {self.title} {'\u2500' * pad}")
        for item in self.items:
            marker = f" {item.marker}" if item.marker else ""
            lines.append(f"{self.PREFIX}{item.key}\t  {item.label}{marker}")
        return lines

    def get_fzf_args(self) -> List[str]:
        """Get fzf args for selector mode."""
        return [
            "--disabled",
            "--no-sort",
            "--bind", "load:last",
            "--bind", "esc:abort",
        ]

    def parse_selection(self, fzf_output: str, return_code: int) -> Optional[str]:
        """Parse fzf output. Returns item key or None if cancelled."""
        if return_code != 0 or not fzf_output.strip():
            return None
        selected = fzf_output.strip().split("\t")[0]
        if selected.startswith(self.PREFIX) and not selected.endswith(self.SEPARATOR):
            return selected[len(self.PREFIX):]
        return None
