#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Factory for TUI backends.

Selects and instantiates the appropriate backend based on:
1. User preference (via config or environment)
2. Availability of dependencies
"""

import os
from typing import Dict, List, Optional, Type

from .base import MenuBackend

# Global preference
_preferred_backend: Optional[str] = None

# Registry of available backends
_backends: Dict[str, Type[MenuBackend]] = {}


def _register_backends() -> None:
    """Register available backends."""
    global _backends

    # Always register fzf (minimal dependency)
    from .fzf_backend import FzfBackend
    _backends["fzf"] = FzfBackend

    # Try to register textual if available
    try:
        from .textual_backend import TextualBackend
        _backends["textual"] = TextualBackend
    except ImportError:
        pass  # textual not installed


def available_backends() -> List[str]:
    """Get list of available backend names."""
    if not _backends:
        _register_backends()

    available = []
    for name, backend_class in _backends.items():
        try:
            backend = backend_class()
            if backend.available():
                available.append(name)
        except Exception:
            pass

    return available


def set_preferred_backend(name: Optional[str]) -> None:
    """Set the preferred backend by name.

    Args:
        name: Backend name ("fzf", "textual") or None to auto-select
    """
    global _preferred_backend
    _preferred_backend = name


def get_backend(name: Optional[str] = None) -> MenuBackend:
    """Get a TUI backend instance.

    Args:
        name: Specific backend name, or None to use preference/auto-select

    Returns:
        MenuBackend instance

    Raises:
        RuntimeError: If no backend is available
    """
    if not _backends:
        _register_backends()

    # Determine which backend to use
    backend_name = name or _preferred_backend or os.environ.get("BIT_TUI_BACKEND")

    if backend_name:
        # Specific backend requested
        if backend_name not in _backends:
            raise RuntimeError(f"Unknown backend: {backend_name}")

        backend = _backends[backend_name]()
        if not backend.available():
            raise RuntimeError(f"Backend '{backend_name}' is not available")
        return backend

    # Auto-select: prefer fzf for minimal dependencies
    for name in ["fzf", "textual"]:
        if name in _backends:
            backend = _backends[name]()
            if backend.available():
                return backend

    raise RuntimeError("No TUI backend available. Install fzf or textual.")


def get_fzf_backend() -> "FzfBackend":
    """Get specifically the fzf backend.

    Convenience function for code that needs fzf-specific features.
    """
    from .fzf_backend import FzfBackend
    backend = FzfBackend()
    if not backend.available():
        raise RuntimeError("fzf is not available")
    return backend
