#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
Abstracted dialog system for TUI menus.

Provides inline dialogs (prompts, confirmations, selections) that can be
rendered by different backends (fzf, textual) while keeping the menu visible.

The key abstraction is the Dialog class which describes what to show,
and DialogRenderer implementations that know how to display it.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from enum import Enum, auto
from typing import Any, Callable, Dict, List, Optional, Tuple


class DialogType(Enum):
    """Types of inline dialogs."""
    TEXT_PROMPT = auto()    # Free text input
    CONFIRM = auto()        # Yes/No confirmation
    SELECT_ONE = auto()     # Select from options
    SELECT_MANY = auto()    # Multi-select from options


@dataclass
class DialogOption:
    """An option in a selection dialog."""
    value: Any
    label: str
    description: str = ""
    selected: bool = False  # For pre-selection in multi-select


@dataclass
class Dialog:
    """A dialog to display inline within a menu.

    This is the abstract description of what to show - backends
    decide how to render it.
    """
    dialog_type: DialogType
    title: str
    message: str = ""
    default: str = ""
    placeholder: str = ""
    options: List[DialogOption] = field(default_factory=list)

    # Callbacks
    on_confirm: Optional[Callable[[Any], None]] = None
    on_cancel: Optional[Callable[[], None]] = None

    # Validation
    validator: Optional[Callable[[str], Tuple[bool, str]]] = None  # (valid, error_msg)


@dataclass
class DialogResult:
    """Result from a dialog interaction."""
    confirmed: bool
    value: Any = None
    error: str = ""

    @property
    def cancelled(self) -> bool:
        return not self.confirmed


class DialogRenderer(ABC):
    """Abstract base for dialog renderers.

    Each backend (fzf, textual) implements this to render dialogs
    in its native way.
    """

    @abstractmethod
    def render_to_menu_items(
        self,
        dialog: Dialog,
    ) -> List[Tuple[str, str]]:
        """Render dialog as menu items (value, display) to prepend to menu.

        For fzf: These get added to the top of the menu.
        For textual: Could be rendered as an overlay instead.
        """
        pass

    @abstractmethod
    def get_prompt_text(self, dialog: Dialog) -> str:
        """Get the prompt text to show when dialog is active."""
        pass

    @abstractmethod
    def parse_result(
        self,
        dialog: Dialog,
        selected_value: str,
        query: str,
    ) -> DialogResult:
        """Parse user selection into a DialogResult."""
        pass

    @abstractmethod
    def is_dialog_item(self, value: str) -> bool:
        """Check if a selected value is from the dialog (vs regular menu)."""
        pass


# --- fzf Implementation ---

class FzfDialogRenderer(DialogRenderer):
    """Render dialogs as fzf menu items."""

    # Prefixes for dialog items
    PREFIX = "__DLG_"
    CONFIRM_VALUE = f"{PREFIX}CONFIRM__"
    CANCEL_VALUE = f"{PREFIX}CANCEL__"
    OPTION_PREFIX = f"{PREFIX}OPT_"

    def __init__(self, colors: Optional[Dict[str, Callable[[str], str]]] = None):
        """Initialize with optional color functions.

        Args:
            colors: Dict with keys 'cyan', 'green', 'yellow', 'dim', 'reset'
                   Each value is a function that wraps text in that color.
        """
        if colors:
            self.cyan = colors.get('cyan', lambda x: x)
            self.green = colors.get('green', lambda x: x)
            self.yellow = colors.get('yellow', lambda x: x)
            self.dim = colors.get('dim', lambda x: x)
        else:
            # ANSI defaults
            self.cyan = lambda x: f"\033[36m{x}\033[0m"
            self.green = lambda x: f"\033[32m{x}\033[0m"
            self.yellow = lambda x: f"\033[33m{x}\033[0m"
            self.dim = lambda x: f"\033[2m{x}\033[0m"

    def render_to_menu_items(
        self,
        dialog: Dialog,
    ) -> List[Tuple[str, str]]:
        """Render dialog as fzf menu items."""
        items = []

        # Header line with title
        items.append((
            f"{self.PREFIX}HEADER__",
            self.cyan(f"┌─ {dialog.title} ─")
        ))

        # Message/help text
        if dialog.message:
            items.append((
                f"{self.PREFIX}MSG__",
                self.dim(f"│  {dialog.message}")
            ))

        # Type-specific content
        if dialog.dialog_type == DialogType.TEXT_PROMPT:
            help_text = "Type value below, Enter=confirm, Esc=cancel"
            if dialog.default:
                help_text += f" (default: {dialog.default})"
            items.append((
                f"{self.PREFIX}HELP__",
                self.dim(f"│  {help_text}")
            ))
            items.append((
                self.CONFIRM_VALUE,
                self.green("│  [ ✓ Confirm ]")
            ))
            items.append((
                self.CANCEL_VALUE,
                self.yellow("│  [ ✗ Cancel ]")
            ))

        elif dialog.dialog_type == DialogType.CONFIRM:
            items.append((
                self.CONFIRM_VALUE,
                self.green("│  [ ✓ Yes ]")
            ))
            items.append((
                self.CANCEL_VALUE,
                self.yellow("│  [ ✗ No ]")
            ))

        elif dialog.dialog_type in (DialogType.SELECT_ONE, DialogType.SELECT_MANY):
            items.append((
                f"{self.PREFIX}HELP__",
                self.dim("│  Select an option:")
            ))
            for i, opt in enumerate(dialog.options):
                marker = "●" if opt.selected else "○"
                label = f"│  {marker} {opt.label}"
                if opt.description:
                    label += f" - {self.dim(opt.description)}"
                items.append((
                    f"{self.OPTION_PREFIX}{i}__",
                    label
                ))
            items.append((
                self.CANCEL_VALUE,
                self.yellow("│  [ ✗ Cancel ]")
            ))

        # Footer
        items.append((
            f"{self.PREFIX}SEP__",
            self.cyan("└" + "─" * 45)
        ))

        return items

    def get_prompt_text(self, dialog: Dialog) -> str:
        """Get prompt text for dialog."""
        if dialog.dialog_type == DialogType.TEXT_PROMPT:
            return f"{dialog.placeholder or dialog.title}: "
        elif dialog.dialog_type == DialogType.CONFIRM:
            return "Confirm (y/n): "
        else:
            return "Select: "

    def parse_result(
        self,
        dialog: Dialog,
        selected_value: str,
        query: str,
    ) -> DialogResult:
        """Parse fzf selection into DialogResult."""

        if selected_value == self.CANCEL_VALUE:
            return DialogResult(confirmed=False)

        if dialog.dialog_type == DialogType.TEXT_PROMPT:
            if selected_value == self.CONFIRM_VALUE:
                value = query.strip() or dialog.default
                # Validate if validator provided
                if dialog.validator:
                    valid, error = dialog.validator(value)
                    if not valid:
                        return DialogResult(confirmed=False, error=error)
                return DialogResult(confirmed=True, value=value)

        elif dialog.dialog_type == DialogType.CONFIRM:
            if selected_value == self.CONFIRM_VALUE:
                return DialogResult(confirmed=True, value=True)
            return DialogResult(confirmed=False, value=False)

        elif dialog.dialog_type in (DialogType.SELECT_ONE, DialogType.SELECT_MANY):
            if selected_value.startswith(self.OPTION_PREFIX):
                # Extract option index
                idx_str = selected_value[len(self.OPTION_PREFIX):-2]  # Remove prefix and __
                try:
                    idx = int(idx_str)
                    if 0 <= idx < len(dialog.options):
                        return DialogResult(
                            confirmed=True,
                            value=dialog.options[idx].value
                        )
                except ValueError:
                    pass

        return DialogResult(confirmed=False)

    def is_dialog_item(self, value: str) -> bool:
        """Check if value is from dialog."""
        return value.startswith(self.PREFIX)


# --- Dialog Builder (fluent API) ---

class DialogBuilder:
    """Fluent builder for creating dialogs."""

    def __init__(self):
        self._type = DialogType.TEXT_PROMPT
        self._title = ""
        self._message = ""
        self._default = ""
        self._placeholder = ""
        self._options: List[DialogOption] = []
        self._on_confirm = None
        self._on_cancel = None
        self._validator = None

    def text_prompt(self, title: str) -> "DialogBuilder":
        """Create a text input dialog."""
        self._type = DialogType.TEXT_PROMPT
        self._title = title
        return self

    def confirm(self, title: str) -> "DialogBuilder":
        """Create a confirmation dialog."""
        self._type = DialogType.CONFIRM
        self._title = title
        return self

    def select_one(self, title: str) -> "DialogBuilder":
        """Create a single-select dialog."""
        self._type = DialogType.SELECT_ONE
        self._title = title
        return self

    def select_many(self, title: str) -> "DialogBuilder":
        """Create a multi-select dialog."""
        self._type = DialogType.SELECT_MANY
        self._title = title
        return self

    def message(self, msg: str) -> "DialogBuilder":
        """Add a message/description."""
        self._message = msg
        return self

    def default(self, value: str) -> "DialogBuilder":
        """Set default value."""
        self._default = value
        return self

    def placeholder(self, text: str) -> "DialogBuilder":
        """Set placeholder text for prompt."""
        self._placeholder = text
        return self

    def option(
        self,
        value: Any,
        label: str,
        description: str = "",
        selected: bool = False,
    ) -> "DialogBuilder":
        """Add an option for selection dialogs."""
        self._options.append(DialogOption(value, label, description, selected))
        return self

    def on_confirm(self, callback: Callable[[Any], None]) -> "DialogBuilder":
        """Set confirmation callback."""
        self._on_confirm = callback
        return self

    def on_cancel(self, callback: Callable[[], None]) -> "DialogBuilder":
        """Set cancellation callback."""
        self._on_cancel = callback
        return self

    def validate(
        self,
        validator: Callable[[str], Tuple[bool, str]],
    ) -> "DialogBuilder":
        """Set validator function."""
        self._validator = validator
        return self

    def build(self) -> Dialog:
        """Build the dialog."""
        return Dialog(
            dialog_type=self._type,
            title=self._title,
            message=self._message,
            default=self._default,
            placeholder=self._placeholder,
            options=self._options,
            on_confirm=self._on_confirm,
            on_cancel=self._on_cancel,
            validator=self._validator,
        )


# Convenience function
def dialog() -> DialogBuilder:
    """Start building a dialog."""
    return DialogBuilder()
