#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""
fzf backend for TUI abstraction layer.

Uses fzf subprocess for menu selection with support for:
- Preview panes
- Custom key bindings
- Multi-select
- In-menu prompts (experimental)
"""

import json
import os
import shutil
import subprocess
import tempfile
from typing import List, Optional

from .base import (
    Action,
    KeyBinding,
    MenuBackend,
    MenuConfig,
    MenuItem,
    MenuResult,
    PromptResult,
)


class FzfBackend(MenuBackend):
    """fzf-based TUI backend."""

    # Special item prefixes for internal use
    PROMPT_PREFIX = "__PROMPT__:"
    CONFIRM_PREFIX = "__CONFIRM__:"
    CANCEL_PREFIX = "__CANCEL__:"

    def __init__(self):
        self._fzf_path = shutil.which("fzf")

    def available(self) -> bool:
        return self._fzf_path is not None

    def name(self) -> str:
        return "fzf"

    def select_one(
        self,
        items: List[MenuItem],
        config: Optional[MenuConfig] = None,
    ) -> MenuResult:
        config = config or MenuConfig()
        return self._run_fzf(items, config, multi=False)

    def select_many(
        self,
        items: List[MenuItem],
        config: Optional[MenuConfig] = None,
    ) -> MenuResult:
        config = config or MenuConfig()
        return self._run_fzf(items, config, multi=True)

    def prompt(
        self,
        message: str,
        default: str = "",
        placeholder: str = "",
    ) -> PromptResult:
        """Show a prompt using fzf's query feature.

        Creates a menu with confirm/cancel options and uses the query
        as the input value.
        """
        items = [
            MenuItem(
                value="__CONFIRM__",
                display=f"[ Press Enter to confirm ]",
                selectable=True,
            ),
            MenuItem(
                value="__CANCEL__",
                display="[ Press Esc to cancel ]",
                selectable=True,
            ),
        ]

        config = MenuConfig(
            header=message,
            prompt=f"{placeholder}: " if placeholder else "Enter value: ",
            initial_query=default,
            height="~10",
            no_sort=True,
        )

        # Custom fzf call to capture query
        result = self._run_fzf_with_query(items, config)

        if result.action == Action.CANCEL or result.value == "__CANCEL__":
            return PromptResult(value=None, confirmed=False)

        return PromptResult(value=result.query or default, confirmed=True)

    def confirm(
        self,
        message: str,
        default: bool = False,
    ) -> bool:
        """Show a yes/no confirmation."""
        items = [
            MenuItem(value=True, display="Yes"),
            MenuItem(value=False, display="No"),
        ]

        config = MenuConfig(
            header=message,
            prompt="Confirm: ",
            height="~6",
            no_sort=True,
        )

        result = self._run_fzf(items, config, multi=False)

        if result.cancelled:
            return default

        return result.value is True

    def notify(
        self,
        message: str,
        title: Optional[str] = None,
        wait: bool = False,
    ) -> None:
        """Show a notification (just prints for fzf backend)."""
        if title:
            print(f"{title}: {message}")
        else:
            print(message)

        if wait:
            input("Press Enter to continue...")

    def _build_menu_input(self, items: List[MenuItem]) -> str:
        """Build fzf input string from menu items.

        Format: value<TAB>display
        The value is hidden via --with-nth=2..
        """
        lines = []
        for item in items:
            # Encode item as JSON in first field for complex values
            if isinstance(item.value, (str, int, float, bool)) and item.value is not None:
                value_str = str(item.value)
            else:
                value_str = json.dumps({"__menuitem__": True, "value": item.value})

            # Build display with indentation
            indent = "  " * item.indent
            display = f"{indent}{item.display}"

            lines.append(f"{value_str}\t{display}")

        return "\n".join(lines)

    def _build_header(self, config: MenuConfig) -> str:
        """Build header text including key binding help."""
        lines = []

        if config.header:
            lines.append(config.header)

        if config.show_help and config.bindings:
            help_parts = []
            for binding in config.bindings:
                if binding.show_in_header:
                    help_parts.append(f"{binding.key}={binding.description}")
            if help_parts:
                lines.append(" | ".join(help_parts))

        return "\n".join(lines) if lines else ""

    def _build_fzf_args(
        self,
        config: MenuConfig,
        multi: bool,
        preview_script: Optional[str] = None,
    ) -> List[str]:
        """Build fzf command arguments."""
        args = [
            "fzf",
            "--ansi",
            "--height", config.height,
            "--prompt", config.prompt,
            "--with-nth", "2..",  # Hide value field
            "--delimiter", "\t",
        ]

        if multi:
            args.append("--multi")
        else:
            args.append("--no-multi")

        if config.no_sort:
            args.append("--no-sort")

        header = self._build_header(config)
        if header:
            args.extend(["--header", header])

        if config.initial_query:
            args.extend(["--query", config.initial_query])

        # Preview
        if preview_script:
            args.extend([
                "--preview", preview_script,
                "--preview-window", config.preview_size,
                "--bind", "?:toggle-preview",
            ])

        # Key bindings - collect expect keys
        expect_keys = []
        for binding in config.bindings:
            expect_keys.append(binding.key)

        if expect_keys:
            args.extend(["--expect", ",".join(expect_keys)])

        # Standard bindings
        args.extend([
            "--bind", "esc:abort",
        ])

        return args

    def _run_fzf(
        self,
        items: List[MenuItem],
        config: MenuConfig,
        multi: bool,
    ) -> MenuResult:
        """Run fzf and return result."""
        if not self.available():
            raise RuntimeError("fzf is not available")

        menu_input = self._build_menu_input(items)

        # Create preview script if needed
        preview_script = None
        if config.preview_cmd:
            preview_script = config.preview_cmd

        fzf_args = self._build_fzf_args(config, multi, preview_script)

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            raise RuntimeError("fzf not found")

        if result.returncode != 0 or not result.stdout.strip():
            return MenuResult(action=Action.CANCEL)

        return self._parse_fzf_output(result.stdout, items, config, multi)

    def _run_fzf_with_query(
        self,
        items: List[MenuItem],
        config: MenuConfig,
    ) -> MenuResult:
        """Run fzf capturing the query (for prompt mode)."""
        if not self.available():
            raise RuntimeError("fzf is not available")

        menu_input = self._build_menu_input(items)
        fzf_args = self._build_fzf_args(config, multi=False, preview_script=None)
        fzf_args.append("--print-query")

        try:
            result = subprocess.run(
                fzf_args,
                input=menu_input,
                stdout=subprocess.PIPE,
                text=True,
            )
        except FileNotFoundError:
            raise RuntimeError("fzf not found")

        if result.returncode != 0:
            return MenuResult(action=Action.CANCEL)

        lines = result.stdout.split("\n")
        query = lines[0] if lines else ""
        selected_line = lines[1] if len(lines) > 1 else ""

        # Parse selected value
        selected = None
        if selected_line:
            value_str = selected_line.split("\t")[0]
            selected = self._find_item_by_value(items, value_str)

        return MenuResult(
            action=Action.SELECT,
            selected=selected,
            query=query,
        )

    def _parse_fzf_output(
        self,
        output: str,
        items: List[MenuItem],
        config: MenuConfig,
        multi: bool,
    ) -> MenuResult:
        """Parse fzf output into MenuResult."""
        lines = output.split("\n")

        # If we have --expect, first line is the key pressed
        action_key = None
        if config.bindings:
            action_key = lines[0].strip() if lines else ""
            lines = lines[1:]

        selected_lines = [l for l in lines if l.strip()]

        if not selected_lines:
            if action_key:
                # Custom action with no selection
                return MenuResult(
                    action=Action.CUSTOM,
                    action_key=action_key,
                )
            return MenuResult(action=Action.CANCEL)

        # Parse selected items
        selected_items = []
        for line in selected_lines:
            value_str = line.split("\t")[0]
            item = self._find_item_by_value(items, value_str)
            if item:
                selected_items.append(item)

        if not selected_items:
            return MenuResult(action=Action.CANCEL)

        # Determine action
        if action_key:
            action = Action.CUSTOM
        else:
            action = Action.SELECT

        return MenuResult(
            action=action,
            selected=selected_items if multi else selected_items[0],
            action_key=action_key,
        )

    def _find_item_by_value(
        self,
        items: List[MenuItem],
        value_str: str,
    ) -> Optional[MenuItem]:
        """Find menu item by its encoded value string."""
        for item in items:
            # Check simple value match
            if str(item.value) == value_str:
                return item

            # Check JSON-encoded complex value
            try:
                decoded = json.loads(value_str)
                if isinstance(decoded, dict) and decoded.get("__menuitem__"):
                    if decoded.get("value") == item.value:
                        return item
            except (json.JSONDecodeError, TypeError):
                pass

        return None


# --- Experimental: In-menu prompts ---

class FzfInMenuPrompt:
    """Experimental: Handle prompts within fzf menu without exiting.

    Instead of exiting fzf to show a prompt, we:
    1. Add prompt items to the menu (instruction, confirm, cancel)
    2. Change the prompt text
    3. Use the query as input
    4. Handle confirmation via selection

    Usage:
        prompt_handler = FzfInMenuPrompt(backend)
        result = prompt_handler.prompt_in_menu(
            existing_items,
            "Enter branch name:",
            on_confirm=lambda value, items: handle_branch(value),
        )
    """

    def __init__(self, backend: FzfBackend):
        self.backend = backend

    def create_prompt_items(
        self,
        message: str,
        default: str = "",
    ) -> List[MenuItem]:
        """Create menu items for an in-menu prompt."""
        return [
            MenuItem(
                value="__PROMPT_HEADER__",
                display=f"─── {message} ───",
                selectable=False,
                indent=0,
            ),
            MenuItem(
                value="__PROMPT_CONFIRM__",
                display="[ Enter to confirm ]",
                selectable=True,
            ),
            MenuItem(
                value="__PROMPT_CANCEL__",
                display="[ Esc to cancel ]",
                selectable=True,
            ),
            MenuItem(
                value="__PROMPT_SEP__",
                display="─" * 40,
                selectable=False,
            ),
        ]

    def is_prompt_action(self, result: MenuResult) -> bool:
        """Check if result is from a prompt item."""
        if result.selected is None:
            return False
        value = result.value
        return isinstance(value, str) and value.startswith("__PROMPT_")
