#!/usr/bin/env python3
#
# Demo: Abstracted dialog system with fzf backend
#
# Run: python -m bitbake_project.tui.demo_dialogs
#
# Shows how the Dialog abstraction integrates with an fzf menu loop,
# similar to how `bit tui` works.
#

import os
import shlex
import subprocess
import sys
import tempfile
from typing import List, Optional, Tuple

from .dialogs import (
    Dialog,
    DialogResult,
    DialogType,
    FzfDialogRenderer,
    dialog,
)


class MenuState:
    """Manages menu state including active dialogs."""

    def __init__(self):
        self.active_dialog: Optional[Dialog] = None
        self.dialog_renderer = FzfDialogRenderer()
        self.last_message: str = ""

    def show_dialog(self, dlg: Dialog) -> None:
        """Activate a dialog."""
        self.active_dialog = dlg

    def clear_dialog(self) -> None:
        """Clear active dialog."""
        self.active_dialog = None

    def has_dialog(self) -> bool:
        """Check if dialog is active."""
        return self.active_dialog is not None


def run_fzf(
    items: List[Tuple[str, str]],
    header: str,
    prompt: str,
    expect_keys: List[str] = None,
) -> Tuple[int, str, str, str]:
    """Run fzf and return (returncode, query, key, selected_value)."""

    menu_input = "\n".join(f"{v}\t{d}" for v, d in items)

    fzf_args = [
        "fzf",
        "--ansi",
        "--height", "~70%",
        "--layout=reverse",
        "--header", header,
        "--prompt", prompt,
        "--with-nth", "2..",
        "--delimiter", "\t",
        "--print-query",
        "--no-sort",
    ]

    if expect_keys:
        fzf_args.extend(["--expect", ",".join(expect_keys)])

    with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False) as f:
        f.write(menu_input)
        temp_file = f.name

    try:
        shell_cmd = f"cat {shlex.quote(temp_file)} | {' '.join(shlex.quote(a) for a in fzf_args)}"
        result = subprocess.run(
            shell_cmd,
            shell=True,
            stdout=subprocess.PIPE,
            text=True,
        )
    finally:
        os.unlink(temp_file)

    lines = result.stdout.split("\n")
    query = lines[0] if lines else ""

    if expect_keys:
        key = lines[1] if len(lines) > 1 else ""
        selected = lines[2].split("\t")[0] if len(lines) > 2 else ""
    else:
        key = ""
        selected = lines[1].split("\t")[0] if len(lines) > 1 else ""

    return result.returncode, query, key, selected


def demo_menu():
    """Demo menu with inline dialogs - similar to bit tui structure."""

    # ANSI colors
    GREEN = "\033[32m"
    YELLOW = "\033[33m"
    CYAN = "\033[36m"
    DIM = "\033[2m"
    RESET = "\033[0m"

    # Sample data (like repos in bit tui)
    repos = [
        {"path": "poky", "name": "OE-core", "branch": "master", "status": "clean", "commits": 5},
        {"path": "meta-oe", "name": "meta-openembedded", "branch": "master", "status": "clean", "commits": 0},
        {"path": "meta-virt", "name": "meta-virtualization", "branch": "kirkstone", "status": "dirty", "commits": 3},
    ]

    state = MenuState()

    while True:
        # Build menu items
        menu_items: List[Tuple[str, str]] = []

        # If dialog active, prepend dialog items
        if state.has_dialog():
            dialog_items = state.dialog_renderer.render_to_menu_items(state.active_dialog)
            menu_items.extend(dialog_items)

        # Regular repo items
        for repo in repos:
            status_color = GREEN if repo["status"] == "clean" else YELLOW
            commits_str = f"{repo['commits']} local" if repo["commits"] > 0 else "up-to-date"
            line = f"  {repo['name']:<22} {repo['branch']:<12} {commits_str:<12} [{status_color}{repo['status']}{RESET}]"
            menu_items.append((repo["path"], line))

        # Determine header and prompt based on dialog state
        if state.has_dialog():
            header = f"{DIM}Complete the dialog above, or Esc to cancel{RESET}"
            prompt = state.dialog_renderer.get_prompt_text(state.active_dialog)
            expect_keys = []  # No hotkeys while dialog active
        else:
            header = "b=branch | c=checkout | d=delete branch | f=fetch | Enter=select | q=quit"
            prompt = "Select repo: "
            expect_keys = ["b", "c", "d", "f", "q"]

        # Show any status message
        if state.last_message:
            header = f"{state.last_message}\n{header}"
            state.last_message = ""

        # Run fzf
        returncode, query, key, selected = run_fzf(
            menu_items, header, prompt, expect_keys
        )

        # Handle cancellation
        if returncode != 0:
            if state.has_dialog():
                # Cancel dialog, return to menu
                if state.active_dialog.on_cancel:
                    state.active_dialog.on_cancel()
                state.clear_dialog()
                continue
            else:
                # Quit
                break

        # Handle dialog selection
        if state.has_dialog() and state.dialog_renderer.is_dialog_item(selected):
            result = state.dialog_renderer.parse_result(
                state.active_dialog, selected, query
            )

            if result.confirmed:
                if state.active_dialog.on_confirm:
                    state.active_dialog.on_confirm(result.value)
                state.last_message = f"{GREEN}✓ {state.active_dialog.title}: {result.value}{RESET}"
            elif result.error:
                state.last_message = f"{YELLOW}Error: {result.error}{RESET}"
            else:
                state.last_message = f"{YELLOW}Cancelled{RESET}"

            state.clear_dialog()
            continue

        # Handle normal selection (even while dialog is shown)
        if state.has_dialog() and not state.dialog_renderer.is_dialog_item(selected):
            # User selected a repo while dialog was shown - could confirm with context
            # or just cancel dialog and select repo
            state.clear_dialog()
            state.last_message = f"{CYAN}Selected: {selected}{RESET}"
            continue

        # Handle hotkeys
        if key == "q":
            break

        if key == "b":
            # Show branch dialog
            state.show_dialog(
                dialog()
                .text_prompt("Switch all repos to branch")
                .message("Enter the branch name to switch all repositories")
                .placeholder("Branch name")
                .default("master")
                .on_confirm(lambda v: None)  # Would call git checkout
                .build()
            )
            continue

        if key == "c":
            # Show checkout dialog with options
            state.show_dialog(
                dialog()
                .select_one("Checkout branch")
                .message("Select a branch to checkout")
                .option("master", "master", "Main development branch")
                .option("kirkstone", "kirkstone", "LTS release branch")
                .option("scarthgap", "scarthgap", "Latest release")
                .option("__new__", "[ Create new branch... ]", "")
                .build()
            )
            continue

        if key == "d":
            # Show delete confirmation
            state.show_dialog(
                dialog()
                .confirm("Delete local branch?")
                .message("This will delete the branch from all repos")
                .build()
            )
            continue

        if key == "f":
            # Direct action (no dialog needed)
            state.last_message = f"{GREEN}Fetching all repos...{RESET}"
            continue

        # Regular selection
        if selected:
            state.last_message = f"{CYAN}Selected repo: {selected}{RESET}"

    print("Done.")


if __name__ == "__main__":
    demo_menu()
