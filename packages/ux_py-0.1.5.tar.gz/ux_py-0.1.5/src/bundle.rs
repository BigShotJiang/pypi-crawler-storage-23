use anyhow::{Context, Result, anyhow};
use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};

use crate::cli::BundleFormat;
use crate::config::Config;
use crate::download::{download_uv, download_ux_stub, get_stub_cache_dir, get_uv_cache_dir};
use crate::embed::{BundleMetadata, create_archive, create_bundle};
use crate::offline;
use crate::platform::Platform;

#[cfg(target_os = "macos")]
use crate::codesign;
#[cfg(target_os = "macos")]
use crate::dmg;
#[cfg(target_os = "macos")]
use crate::macos;
#[cfg(target_os = "macos")]
use crate::notarize;

/// Create a single-file bundled executable
#[allow(clippy::too_many_arguments)]
pub async fn create_bundled_binary(
    project_dir: &Path,
    output_path: &Path,
    target_platform: Option<&Platform>,
    format: &BundleFormat,
    offline_flag: bool,
    python_version_flag: Option<&str>,
    do_codesign: bool,
    do_notarize: bool,
    do_dmg: bool,
) -> Result<PathBuf> {
    let mut config = Config::load(project_dir)?;

    // CLI flags override config-file values
    if offline_flag {
        config.offline = true;
    }
    if let Some(ver) = python_version_flag {
        config.python_version = ver.to_string();
    }

    // Use target platform or current platform
    let platform = match target_platform {
        Some(p) => p.clone(),
        None => Platform::current()?,
    };

    // Check format compatibility and handle .app bundle
    if matches!(format, BundleFormat::App) {
        #[cfg(target_os = "macos")]
        {
            if platform.os != crate::platform::Os::Darwin {
                return Err(anyhow!("--format app is only supported on macOS (Darwin)"));
            }
            return create_app_bundle(
                project_dir,
                output_path,
                &config,
                do_codesign,
                do_notarize,
                do_dmg,
            )
            .await;
        }
        #[cfg(not(target_os = "macos"))]
        {
            return Err(anyhow!(
                "--format app is only supported when running on macOS"
            ));
        }
    }

    // Validate macOS-only options
    if do_codesign || do_notarize || do_dmg {
        return Err(anyhow!(
            "--codesign, --notarize, and --dmg options require --format app"
        ));
    }

    // Determine output file path.
    // Treat as a directory when it exists as one, or when the path string ends
    // with a separator (trailing slash) — Rust's Path strips trailing slashes
    // before file_name(), so we check the raw string.
    let looks_like_dir = output_path.is_dir()
        || output_path
            .to_str()
            .map(|s| s.ends_with('/') || s.ends_with('\\'))
            .unwrap_or(false);
    let output_file = if looks_like_dir {
        let binary_name = if platform.os == crate::platform::Os::Windows {
            format!("{}.exe", config.project_name)
        } else {
            config.project_name.clone()
        };
        output_path.join(binary_name)
    } else {
        output_path.to_path_buf()
    };

    // Create output directory if needed
    if let Some(parent) = output_file.parent() {
        fs::create_dir_all(parent)?;
    }

    println!("Creating bundled binary: {}", output_file.display());

    // 1. Download uv binary for target platform
    println!("Downloading uv for {} ...", platform.to_target_string());
    let uv_cache_dir = get_uv_cache_dir()?;
    let uv_path = download_uv(&platform, &config.uv_version, &uv_cache_dir).await?;

    // 2. Get stub binary (ux itself or downloaded for cross-compilation)
    let stub_binary = get_stub_binary(&platform).await?;

    // 3. Create metadata
    let metadata = BundleMetadata {
        project_name: config.project_name.clone(),
        entry_point: config.entry_point.clone(),
        uv_version: config.uv_version.clone(),
        offline: config.offline,
        python_version: config.python_version.clone(),
        entry_module: config.entry_module.clone().unwrap_or_default(),
    };

    // 4. Optionally download Python + wheels for offline mode.
    //    Python is cached persistently in ~/.cache/ux/python/{platform}/{version}/.
    //    Wheels go to a temp dir; they are expanded into site-packages at archive time.
    let tmp_offline_dir = tempfile::tempdir().ok();
    let (python_dir_opt, site_packages_wheels_opt) = if config.offline {
        let python_cache = offline::python_cache_dir(&platform, &config.python_version)?;
        offline::ensure_python_for_platform(&python_cache, &config.python_version, &platform)
            .await?;

        if let Some(ref tmp) = tmp_offline_dir {
            let whl_dir = tmp.path().join("wheels");
            let sp_path = site_packages_relative_path(&platform, &config.python_version, &python_cache);
            offline::download_wheels(
                project_dir,
                &whl_dir,
                &platform,
                &config.python_version,
                &uv_path,
                &python_cache,
            )?;
            (Some(python_cache), Some((whl_dir, sp_path)))
        } else {
            return Err(anyhow!(
                "Could not create temporary directory for offline wheels"
            ));
        }
    } else {
        (None, None)
    };

    // 5. Create archive with project files
    println!("Creating archive...");
    let archive_data = create_archive(
        project_dir,
        &uv_path,
        &metadata,
        &config.include,
        python_dir_opt.as_deref(),
        site_packages_wheels_opt
            .as_ref()
            .map(|(d, s)| (d.as_path(), s.as_str())),
    )?;

    println!("Archive size: {} bytes", archive_data.len());

    // 5. Create bundled binary
    println!("Creating bundled binary...");
    create_bundle(&stub_binary, &archive_data, &output_file)?;

    let final_size = fs::metadata(&output_file)?.len();
    println!(
        "\nBundle created successfully: {} ({:.2} MB)",
        output_file.display(),
        final_size as f64 / 1024.0 / 1024.0
    );
    println!("\nTo run:");
    println!("  ./{}", output_file.file_name().unwrap().to_string_lossy());

    Ok(output_file)
}

/// Get the stub binary for the target platform
async fn get_stub_binary(platform: &Platform) -> Result<PathBuf> {
    let current_platform = Platform::current()?;

    // Optimization: use current exe if platforms match
    if current_platform.to_target_string() == platform.to_target_string() {
        return std::env::current_exe().with_context(|| "Failed to get current executable path");
    }

    // Cross-compilation: download stub for target platform
    println!(
        "Cross-compiling for {} (current: {})",
        platform.to_target_string(),
        current_platform.to_target_string()
    );
    let stub_cache_dir = get_stub_cache_dir()?;
    download_ux_stub(platform, &stub_cache_dir).await
}

/// Initialize ux configuration in pyproject.toml
pub fn init_config(project_dir: &Path) -> Result<()> {
    let pyproject_path = project_dir.join("pyproject.toml");

    if !pyproject_path.exists() {
        return Err(anyhow!(
            "pyproject.toml not found in {}. Create one first with 'uv init'",
            project_dir.display()
        ));
    }

    // Read existing content
    let content = fs::read_to_string(&pyproject_path)?;

    // Check if [tool.ux] already exists
    if content.contains("[tool.ux]") {
        println!("[tool.ux] section already exists in pyproject.toml");
        return Ok(());
    }

    // Append [tool.ux] section
    let mut file = fs::OpenOptions::new().append(true).open(&pyproject_path)?;

    writeln!(file)?;
    writeln!(file, "[tool.ux]")?;
    writeln!(
        file,
        "# entry = \"myapp\"  # Entry point command (auto-detected from [project.scripts])"
    )?;
    writeln!(file, "# uv_version = \"latest\"  # uv version to bundle")?;
    writeln!(file)?;

    println!("Added [tool.ux] section to pyproject.toml");
    println!("Edit the configuration as needed.");

    Ok(())
}

/// Create macOS .app bundle
#[cfg(target_os = "macos")]
async fn create_app_bundle(
    project_dir: &Path,
    output_path: &Path,
    config: &Config,
    do_codesign: bool,
    do_notarize: bool,
    do_dmg: bool,
) -> Result<PathBuf> {
    let platform = Platform::current()?;

    // Determine .app path
    let app_name = format!("{}.app", config.project_name);
    let app_path = if output_path.is_dir() {
        output_path.join(&app_name)
    } else if output_path.extension().map(|e| e == "app").unwrap_or(false) {
        output_path.to_path_buf()
    } else {
        output_path.join(&app_name)
    };

    // Create output directory if needed
    if let Some(parent) = app_path.parent() {
        fs::create_dir_all(parent)?;
    }

    println!("Creating macOS app bundle: {}", app_path.display());

    // Create .app structure
    let (executable_path, info_plist_path, resources_dir) =
        macos::create_app_structure(&app_path, &config.project_name)?;

    // Download uv binary
    println!("Downloading uv for {} ...", platform.to_target_string());
    let uv_cache_dir = get_uv_cache_dir()?;
    let uv_path = download_uv(&platform, &config.uv_version, &uv_cache_dir).await?;

    // Get stub binary
    let stub_binary = get_stub_binary(&platform).await?;

    // Create metadata
    let metadata = BundleMetadata {
        project_name: config.project_name.clone(),
        entry_point: config.entry_point.clone(),
        uv_version: config.uv_version.clone(),
        offline: config.offline,
        python_version: config.python_version.clone(),
        entry_module: config.entry_module.clone().unwrap_or_default(),
    };

    // Create archive (app bundle does not support offline mode in v1)
    println!("Creating archive...");
    let archive_data = create_archive(
        project_dir,
        &uv_path,
        &metadata,
        &config.include,
        None,
        None,
    )?;

    println!("Archive size: {} bytes", archive_data.len());

    // Create bundled executable in MacOS directory
    println!("Creating bundled executable...");
    create_bundle(&stub_binary, &archive_data, &executable_path)?;

    // Generate and write Info.plist
    let info_plist = macos::generate_info_plist(
        &config.project_name,
        &config.project_name,
        config.macos.as_ref(),
    );
    fs::write(&info_plist_path, info_plist)?;

    // Copy icon if specified
    if let Some(ref macos_config) = config.macos
        && let Some(ref icon_path) = macos_config.icon
    {
        println!("Processing icon...");
        macos::copy_icon(project_dir, icon_path, &resources_dir)?;
    }

    println!("\nApp bundle created successfully: {}", app_path.display());

    // Code signing (required for notarization)
    if do_codesign || do_notarize {
        let identity = get_codesign_identity(config)?;
        codesign::sign_app_bundle(&app_path, &identity)?;
    }

    // Notarization
    if do_notarize {
        let macos_config = config.macos.as_ref();
        let (apple_id, team_id, password) = notarize::get_credentials(
            macos_config.and_then(|c| c.apple_id.as_deref()),
            macos_config.and_then(|c| c.team_id.as_deref()),
        )?;
        notarize::notarize_app(&app_path, &apple_id, &team_id, &password)?;
    }

    // DMG creation
    let final_path = if do_dmg {
        let output_dir = app_path.parent().unwrap_or(output_path);
        dmg::create_dmg(&app_path, output_dir, &config.project_name)?
    } else {
        app_path.clone()
    };

    println!("\nTo run:");
    if do_dmg {
        println!("  Mount the DMG and drag the app to Applications");
    } else {
        println!("  open {}", app_path.display());
    }

    Ok(final_path)
}

/// Return the site-packages path relative to the embedded `python/` directory.
///
/// - Windows:  `Lib/site-packages`
/// - Unix:     `lib/python3.12/site-packages`  (major.minor derived from `python_version`)
///
/// python-build-standalone 3.13+ ships a free-threaded binary as `bin/python3`, whose
/// stdlib lives under `lib/python3.13t/` rather than `lib/python3.13/`.  We detect this
/// by checking whether the free-threaded directory exists in the extracted `python_dir`.
fn site_packages_relative_path(
    platform: &Platform,
    python_version: &str,
    python_dir: &std::path::Path,
) -> String {
    match platform.os {
        crate::platform::Os::Windows => "Lib/site-packages".to_string(),
        _ => {
            let major_minor = python_version
                .splitn(3, '.')
                .take(2)
                .collect::<Vec<_>>()
                .join(".");
            // python-build-standalone 3.13 may use python3.13t (free-threaded) as the
            // default interpreter; its site-packages live under lib/python3.13t/.
            let ft_lib = python_dir.join("lib").join(format!("python{}t", major_minor));
            if ft_lib.exists() {
                format!("lib/python{}t/site-packages", major_minor)
            } else {
                format!("lib/python{}/site-packages", major_minor)
            }
        }
    }
}

/// Get code signing identity from config or auto-detect
#[cfg(target_os = "macos")]
fn get_codesign_identity(config: &Config) -> Result<String> {
    // Check config first
    if let Some(ref macos_config) = config.macos
        && let Some(ref identity) = macos_config.codesign_identity
    {
        return Ok(identity.clone());
    }

    // Try to auto-detect
    codesign::get_default_identity()
}
