"""Tests for log11."""
