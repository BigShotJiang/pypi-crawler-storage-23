"""Allow running ccmux as a module: python -m ccmux"""

from ccmux.cli import main

if __name__ == "__main__":
    main()
