"""RepoHeader — non-clickable section header for a repository group."""

from textual.widgets import Static


class RepoHeader(Static):
    """Non-clickable section header for a repository group."""
