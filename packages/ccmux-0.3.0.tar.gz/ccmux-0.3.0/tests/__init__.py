"""Tests for ccmux."""
