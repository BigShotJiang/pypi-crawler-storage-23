from skilark_cli.answer_checker import check_answer


def test_exact_match():
    assert check_answer("1 2", "1 2") is True


def test_whitespace_normalization():
    assert check_answer("  1  2  ", "1 2") is True


def test_case_insensitive():
    assert check_answer("True", "true") is True


def test_trailing_newline():
    assert check_answer("hello\n", "hello") is True


def test_punctuation_stripped():
    assert check_answer("(1, 2)", "1 2") is True
    assert check_answer("[1, 2, 3]", "1 2 3") is True


def test_wrong_answer():
    assert check_answer("3", "1 2") is False


def test_empty_input():
    assert check_answer("", "1 2") is False


def test_numeric_equivalence():
    assert check_answer("1.0", "1.0") is True
    assert check_answer("1", "1.0") is False  # don't be too clever
