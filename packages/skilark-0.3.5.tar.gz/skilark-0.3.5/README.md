# skilark

Your career intelligence companion. Skilark delivers daily coding challenges based on what employers actually look for — so you stay sharp on the skills that matter.

Available on the command line and [Telegram](https://t.me/MySkilarkBot).

## Install

```bash
pip install skilark
```

Requires Python 3.11+.

## Quick start

```bash
skilark              # interactive menu — pick what to do
skilark today        # jump straight into a challenge
skilark fit "backend engineer python"  # find matching jobs
skilark signals      # this week's market intelligence
skilark status       # see your streak and progress
skilark config       # change your topics
skilark link         # link to your Telegram account
```

On first run, pick the topics you want to sharpen — Python, Go, Kubernetes, System Design, and 30+ more. After that, just run `skilark` and choose from the menu.

## What you can do

**Practice challenges** — Each challenge shows a short code snippet and asks: *What is the output?* Get instant feedback with explanations and links to deep-dive pages on [skilark.com](https://skilark.com).

```
Day 1 · python · Generator Send

  def gen():
      x = yield 1
      yield x + 10

  g = gen()
  print(next(g))
  print(g.send(5))

  [h] hint  [s] skip  [q] quit

  Your answer: _
```

**Find your fit** — Describe your ideal role or upload a resume to see matching positions, salary ranges, and skill gaps.

**Market signals** — Weekly hiring surges and salary insights so you know where the market is moving.

## Cross-platform

Use `skilark link` to connect your CLI and Telegram accounts. Your streak and progress sync across both.

## Changelog

### 0.3.4

- Running `skilark` with no arguments now shows an interactive menu
- All commands discoverable without reading docs

### 0.3.3

- Improved `skilark fit` output — shows title, company, and location for each match
- Results sorted by relevance

### 0.3.2

- Security hardening for config file handling and API communication

### 0.3.1

- Added `skilark fit` command — find matching jobs by description or resume upload
- Compact and detailed output modes (`--detail`)

### 0.3.0

- Added `skilark signals` command — weekly market intelligence (hiring surges, salary insights)
- Use `--all` to see every signal

### 0.2.1

- Added `--help` flag

### 0.2.0

- Added Telegram bot integration
- New `skilark link` command to connect CLI and Telegram accounts
- Synced streaks and progress across platforms

### 0.1.2

- Show source language in challenge header
- Improved question clarity and deep-dive links

### 0.1.1

- Fixed challenge delivery after onboarding
- Expanded to 34 selectable topics

### 0.1.0

- Initial release — interactive challenges, streaks, adaptive difficulty
