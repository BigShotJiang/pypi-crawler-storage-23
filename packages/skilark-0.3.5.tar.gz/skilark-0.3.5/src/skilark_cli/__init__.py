from importlib.metadata import version as _v

__version__ = _v("skilark")
