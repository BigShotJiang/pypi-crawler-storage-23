"""
`skilark status` command.

Fetches and displays the user's learning statistics (streak, weekly
progress, per-topic breakdown, last session) from the Skilark API.
Exits early with a friendly message if the user has not yet run setup.
"""

from rich.console import Console

from skilark_cli.client import SkilarkClient
from skilark_cli.config_store import ConfigStore
from skilark_cli.display import render_stats

console = Console()


def run() -> None:
    """Display the current user's learning statistics."""
    config_store = ConfigStore()

    if config_store.is_first_run():
        console.print("[dim]Run 'skilark today' first to get started.[/dim]")
        return

    config = config_store.load()
    client = SkilarkClient(base_url=config["api_url"], user_id=config["user_id"])
    stats = client.get_stats()
    render_stats(console, stats)
