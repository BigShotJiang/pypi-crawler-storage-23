"""Entry point for the skilark CLI."""

import sys

from skilark_cli import __version__


USAGE = """\
Usage: skilark [command]

Commands:
  today           Show today's coding challenge (default)
  status          Show your progress and streaks
  signals [--all] Show this week's market intelligence signals
  fit <query>     Find matching jobs by description or resume
  config          Configure API key and preferences
  link [code]     Link accounts across channels (generate or redeem a code)

Options:
  --help, -h  Print this help message and exit
  --version   Print version and exit
"""

MENU_CHOICES = [
    {"name": "Today's challenge", "value": "today"},
    {"name": "My status", "value": "status"},
    {"name": "Market signals", "value": "signals"},
    {"name": "Find my fit", "value": "fit"},
    {"name": "Configure topics", "value": "config"},
    {"name": "Link accounts", "value": "link"},
]


def _show_menu() -> str:
    """Show interactive menu and return the chosen command value."""
    from InquirerPy import inquirer

    return inquirer.select(
        message="What would you like to do?",
        choices=MENU_CHOICES,
    ).execute()


def _prompt_fit_query() -> str | None:
    """Prompt user for a fit query. Returns None if empty."""
    from rich.prompt import Prompt

    query = Prompt.ask("Describe your ideal role").strip()
    return query or None


def _dispatch(command: str, rest: list[str]) -> None:
    """Route a command + remaining args to the appropriate handler."""
    if command == "today":
        from skilark_cli.commands import today
        today.run()
    elif command == "status":
        from skilark_cli.commands import status
        status.run()
    elif command == "config":
        from skilark_cli.commands import config
        config.run()
    elif command == "signals":
        from skilark_cli.commands import signals
        signals.dispatch(rest)
    elif command == "fit":
        from skilark_cli.commands import fit
        fit.dispatch(rest)
    elif command == "link":
        from skilark_cli.commands import link
        link.dispatch(rest)
    else:
        print(f"Unknown command: {command!r}\n", file=sys.stderr)
        print(USAGE, file=sys.stderr)
        sys.exit(1)


def main() -> None:
    args = sys.argv[1:]

    if not args:
        from skilark_cli.config_store import ConfigStore

        if ConfigStore().is_first_run():
            from skilark_cli.commands import today
            today.run()
            return

        choice = _show_menu()

        # "fit" needs a query — prompt interactively
        if choice == "fit":
            query = _prompt_fit_query()
            if not query:
                print("No query entered.")
                return
            _dispatch("fit", [query])
            return

        _dispatch(choice, [])
        return

    command = args[0]

    if command in ("--help", "-h", "help"):
        print(USAGE)
        return

    if command == "--version":
        print(f"skilark {__version__}")
        return

    _dispatch(command, args[1:])


if __name__ == "__main__":
    main()
