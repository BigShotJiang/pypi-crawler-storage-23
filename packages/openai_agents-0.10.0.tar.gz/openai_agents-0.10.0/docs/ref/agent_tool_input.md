# `Agent Tool Input`

::: agents.agent_tool_input
