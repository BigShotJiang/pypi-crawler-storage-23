# `OpenAI Chat Completions model`

::: agents.models.openai_chatcompletions
