# `Manager`

::: agents.mcp.manager
