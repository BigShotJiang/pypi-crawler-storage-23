# `Output Schema File`

::: agents.extensions.experimental.codex.output_schema_file
