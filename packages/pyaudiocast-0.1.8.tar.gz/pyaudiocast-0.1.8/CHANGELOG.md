# Changelog

## [0.1.8](https://github.com/nicokim/PyAudioCast/compare/pyaudiocast-v0.1.7...pyaudiocast-v0.1.8) (2026-02-24)


### Features

* auto-negotiate device config with resample and upmix ([#19](https://github.com/nicokim/PyAudioCast/issues/19)) ([8f0d5e4](https://github.com/nicokim/PyAudioCast/commit/8f0d5e41dc1bb18f4623856bb39eb81ad4a59163))

## [0.1.7](https://github.com/nicokim/PyAudioCast/compare/pyaudiocast-v0.1.6...pyaudiocast-v0.1.7) (2026-02-24)


### Bug Fixes

* update type stubs and dynamic version ([#17](https://github.com/nicokim/PyAudioCast/issues/17)) ([e0fad87](https://github.com/nicokim/PyAudioCast/commit/e0fad87d0f5c4e9da2507b41d853c16ac78a01fb))

## [0.1.6](https://github.com/nicokim/PyAudioCast/compare/pyaudiocast-v0.1.5...pyaudiocast-v0.1.6) (2026-02-23)


### Features

* add CI/CD workflows and PyPI publishing ([#1](https://github.com/nicokim/PyAudioCast/issues/1)) ([2bebcf7](https://github.com/nicokim/PyAudioCast/commit/2bebcf7af2c602999f8350ec2abcdb5518863d92))
* initial release of pyaudiocast ([dc4ccfc](https://github.com/nicokim/PyAudioCast/commit/dc4ccfc0bbaf6f1892c54940be8de0fe9ab93909))


### Bug Fixes

* remove invalid extra-files from release-please config ([#2](https://github.com/nicokim/PyAudioCast/issues/2)) ([42c2c62](https://github.com/nicokim/PyAudioCast/commit/42c2c626cd81ad9cc9027f789a627914892edaa8))
* remove Linux aarch64 build (ALSA cross-compilation unsupported) ([#11](https://github.com/nicokim/PyAudioCast/issues/11)) ([d942291](https://github.com/nicokim/PyAudioCast/commit/d9422915a4f8e5fbdd203bc73d28f8eda44be81a))
* trigger release workflow on tag push instead of release event ([#4](https://github.com/nicokim/PyAudioCast/issues/4)) ([4d7364a](https://github.com/nicokim/PyAudioCast/commit/4d7364ad19ef515ecee79fb8e9e18e77ad0a971f))
* update play_sine example to use unified write() ([#10](https://github.com/nicokim/PyAudioCast/issues/10)) ([3c66fc1](https://github.com/nicokim/PyAudioCast/commit/3c66fc17e3ce9f78199d91199f8c2a69dc578d86))
* use --find-interpreter for Linux manylinux wheel builds ([#8](https://github.com/nicokim/PyAudioCast/issues/8)) ([bd7b56e](https://github.com/nicokim/PyAudioCast/commit/bd7b56edd018c95b6674eddee01090fe467fbe50))
* use PAT for release-please to trigger release workflow ([#6](https://github.com/nicokim/PyAudioCast/issues/6)) ([672c5ae](https://github.com/nicokim/PyAudioCast/commit/672c5ae1b2b12e4fc3cf121f7aec37717ac9d314))

## [0.1.5](https://github.com/nicokim/PyAudioCast/compare/pyaudiocast-v0.1.4...pyaudiocast-v0.1.5) (2026-02-23)


### Bug Fixes

* remove Linux aarch64 build (ALSA cross-compilation unsupported) ([#11](https://github.com/nicokim/PyAudioCast/issues/11)) ([d942291](https://github.com/nicokim/PyAudioCast/commit/d9422915a4f8e5fbdd203bc73d28f8eda44be81a))

## [0.1.4](https://github.com/nicokim/PyAudioCast/compare/pyaudiocast-v0.1.3...pyaudiocast-v0.1.4) (2026-02-23)


### Features

* add CI/CD workflows and PyPI publishing ([#1](https://github.com/nicokim/PyAudioCast/issues/1)) ([2bebcf7](https://github.com/nicokim/PyAudioCast/commit/2bebcf7af2c602999f8350ec2abcdb5518863d92))
* initial release of pyaudiocast ([dc4ccfc](https://github.com/nicokim/PyAudioCast/commit/dc4ccfc0bbaf6f1892c54940be8de0fe9ab93909))


### Bug Fixes

* remove invalid extra-files from release-please config ([#2](https://github.com/nicokim/PyAudioCast/issues/2)) ([42c2c62](https://github.com/nicokim/PyAudioCast/commit/42c2c626cd81ad9cc9027f789a627914892edaa8))
* trigger release workflow on tag push instead of release event ([#4](https://github.com/nicokim/PyAudioCast/issues/4)) ([4d7364a](https://github.com/nicokim/PyAudioCast/commit/4d7364ad19ef515ecee79fb8e9e18e77ad0a971f))
* update play_sine example to use unified write() ([#10](https://github.com/nicokim/PyAudioCast/issues/10)) ([3c66fc1](https://github.com/nicokim/PyAudioCast/commit/3c66fc17e3ce9f78199d91199f8c2a69dc578d86))
* use --find-interpreter for Linux manylinux wheel builds ([#8](https://github.com/nicokim/PyAudioCast/issues/8)) ([bd7b56e](https://github.com/nicokim/PyAudioCast/commit/bd7b56edd018c95b6674eddee01090fe467fbe50))
* use PAT for release-please to trigger release workflow ([#6](https://github.com/nicokim/PyAudioCast/issues/6)) ([672c5ae](https://github.com/nicokim/PyAudioCast/commit/672c5ae1b2b12e4fc3cf121f7aec37717ac9d314))

## [0.1.3](https://github.com/nicokim/PyAudioCast/compare/pyaudiocast-v0.1.2...pyaudiocast-v0.1.3) (2026-02-23)


### Bug Fixes

* use PAT for release-please to trigger release workflow ([#6](https://github.com/nicokim/PyAudioCast/issues/6)) ([672c5ae](https://github.com/nicokim/PyAudioCast/commit/672c5ae1b2b12e4fc3cf121f7aec37717ac9d314))

## [0.1.2](https://github.com/nicokim/PyAudioCast/compare/pyaudiocast-v0.1.1...pyaudiocast-v0.1.2) (2026-02-23)


### Bug Fixes

* trigger release workflow on tag push instead of release event ([#4](https://github.com/nicokim/PyAudioCast/issues/4)) ([4d7364a](https://github.com/nicokim/PyAudioCast/commit/4d7364ad19ef515ecee79fb8e9e18e77ad0a971f))

## [0.1.1](https://github.com/nicokim/PyAudioCast/compare/pyaudiocast-v0.1.0...pyaudiocast-v0.1.1) (2026-02-23)


### Features

* add CI/CD workflows and PyPI publishing ([#1](https://github.com/nicokim/PyAudioCast/issues/1)) ([2bebcf7](https://github.com/nicokim/PyAudioCast/commit/2bebcf7af2c602999f8350ec2abcdb5518863d92))
* initial release of pyaudiocast ([dc4ccfc](https://github.com/nicokim/PyAudioCast/commit/dc4ccfc0bbaf6f1892c54940be8de0fe9ab93909))


### Bug Fixes

* remove invalid extra-files from release-please config ([#2](https://github.com/nicokim/PyAudioCast/issues/2)) ([42c2c62](https://github.com/nicokim/PyAudioCast/commit/42c2c626cd81ad9cc9027f789a627914892edaa8))
