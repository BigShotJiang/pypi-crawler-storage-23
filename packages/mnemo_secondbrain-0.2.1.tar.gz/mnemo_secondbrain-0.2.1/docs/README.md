# MAISECONDBRAIN Docs

문서 명명 규칙:
- `A000` — 분석 (Analysis)
- `D000` — 설계 (Design)
- `I000` — 구현 (Implementation)
- `T000` — 테스트 (Test)
