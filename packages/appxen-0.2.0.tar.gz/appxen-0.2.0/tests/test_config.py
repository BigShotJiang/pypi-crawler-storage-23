"""Tests for config module."""

from pathlib import Path

from appxen_cli.config import Profile, load_profile, save_profile


class TestConfig:

    def test_load_profile_from_env(self, monkeypatch, tmp_path):
        """Env vars override config file."""
        monkeypatch.setenv("APPXEN_API_KEY", "axgw_test_env_key")
        monkeypatch.setenv("APPXEN_ENDPOINT", "http://localhost:8000")

        prof = load_profile()
        assert prof is not None
        assert prof.api_key == "axgw_test_env_key"
        assert prof.endpoint == "http://localhost:8000"

    def test_load_profile_missing_returns_none(self, monkeypatch, tmp_path):
        """Missing config returns None."""
        monkeypatch.delenv("APPXEN_API_KEY", raising=False)
        monkeypatch.delenv("APPXEN_ENDPOINT", raising=False)
        monkeypatch.delenv("APPXEN_PROFILE", raising=False)
        import appxen_cli.config as cfg
        monkeypatch.setattr(cfg, "CONFIG_FILE", tmp_path / "nonexistent.toml")

        prof = load_profile()
        assert prof is None

    def test_save_and_load_profile(self, monkeypatch, tmp_path):
        """Save then load roundtrips correctly."""
        monkeypatch.delenv("APPXEN_API_KEY", raising=False)
        monkeypatch.delenv("APPXEN_ENDPOINT", raising=False)
        monkeypatch.delenv("APPXEN_PROFILE", raising=False)

        import appxen_cli.config as cfg
        config_dir = tmp_path / "config"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr(cfg, "CONFIG_DIR", config_dir)
        monkeypatch.setattr(cfg, "CONFIG_FILE", config_file)

        save_profile(api_key="axgw_test_123", endpoint="https://api.test.com")
        prof = load_profile()
        assert prof is not None
        assert prof.api_key == "axgw_test_123"
        assert prof.endpoint == "https://api.test.com"

        # Check file permissions
        assert oct(config_file.stat().st_mode)[-3:] == "600"

    def test_multiple_profiles(self, monkeypatch, tmp_path):
        """Multiple profiles can coexist."""
        monkeypatch.delenv("APPXEN_API_KEY", raising=False)
        monkeypatch.delenv("APPXEN_ENDPOINT", raising=False)
        monkeypatch.delenv("APPXEN_PROFILE", raising=False)

        import appxen_cli.config as cfg
        config_dir = tmp_path / "config"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr(cfg, "CONFIG_DIR", config_dir)
        monkeypatch.setattr(cfg, "CONFIG_FILE", config_file)

        save_profile(api_key="axgw_prod", profile="default")
        save_profile(api_key="axgw_staging", endpoint="http://localhost:8000", profile="staging")

        prod = load_profile("default")
        staging = load_profile("staging")

        assert prod is not None
        assert prod.api_key == "axgw_prod"
        assert staging is not None
        assert staging.api_key == "axgw_staging"
        assert staging.endpoint == "http://localhost:8000"

    def test_orchestrator_fields_roundtrip(self, monkeypatch, tmp_path):
        """Orchestrator URL and tenant_id persist correctly."""
        monkeypatch.delenv("APPXEN_API_KEY", raising=False)
        monkeypatch.delenv("APPXEN_ENDPOINT", raising=False)
        monkeypatch.delenv("APPXEN_PROFILE", raising=False)
        monkeypatch.delenv("APPXEN_ORCHESTRATOR_URL", raising=False)
        monkeypatch.delenv("APPXEN_TENANT_ID", raising=False)

        import appxen_cli.config as cfg
        config_dir = tmp_path / "config"
        config_file = config_dir / "config.toml"
        monkeypatch.setattr(cfg, "CONFIG_DIR", config_dir)
        monkeypatch.setattr(cfg, "CONFIG_FILE", config_file)

        save_profile(
            api_key="axgw_test",
            orchestrator_url="https://orchestrator.test.com",
            tenant_id="tenant-abc",
        )
        prof = load_profile()
        assert prof is not None
        assert prof.orchestrator_url == "https://orchestrator.test.com"
        assert prof.tenant_id == "tenant-abc"

    def test_orchestrator_env_vars(self, monkeypatch):
        """Orchestrator env vars are loaded."""
        monkeypatch.setenv("APPXEN_API_KEY", "axgw_test")
        monkeypatch.setenv("APPXEN_ORCHESTRATOR_URL", "http://localhost:8080")
        monkeypatch.setenv("APPXEN_TENANT_ID", "t-env")

        prof = load_profile()
        assert prof is not None
        assert prof.orchestrator_url == "http://localhost:8080"
        assert prof.tenant_id == "t-env"

    def test_orchestrator_defaults(self, monkeypatch):
        """Orchestrator fields default when not set."""
        monkeypatch.setenv("APPXEN_API_KEY", "axgw_test")
        monkeypatch.delenv("APPXEN_ORCHESTRATOR_URL", raising=False)
        monkeypatch.delenv("APPXEN_TENANT_ID", raising=False)

        prof = load_profile()
        assert prof is not None
        from appxen_cli.config import DEFAULT_ORCHESTRATOR_ENDPOINT
        assert prof.orchestrator_url == DEFAULT_ORCHESTRATOR_ENDPOINT
        assert prof.tenant_id == ""
