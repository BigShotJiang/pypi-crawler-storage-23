"""Tests for appxen sources command."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from appxen_cli.main import app


class TestSources:

    @patch("appxen_cli.main.get_client")
    def test_list_sources(self, mock_get_client):
        """List sources displays table."""
        mock_client = MagicMock()
        mock_client.list_sources.return_value = {
            "sources": [
                {"source_id": "s1", "filename": "test.md", "status": "ready", "chunk_count": 5, "created_at": "2026-01-01T00:00:00"},
            ],
            "total": 1,
            "offset": 0,
            "limit": 20,
        }
        mock_get_client.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(app, ["sources"])
        assert result.exit_code == 0
        assert "test.md" in result.output

    @patch("appxen_cli.main.get_client")
    def test_list_sources_json(self, mock_get_client):
        """List sources with --json outputs raw JSON."""
        mock_client = MagicMock()
        mock_client.list_sources.return_value = {"sources": [], "total": 0}
        mock_get_client.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(app, ["sources", "--json"])
        assert result.exit_code == 0
        assert '"total"' in result.output

    @patch("appxen_cli.main.get_client")
    def test_delete_source_confirmed(self, mock_get_client):
        """Delete source with --yes skips confirmation."""
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(app, ["sources", "delete", "src123", "--yes"])
        assert result.exit_code == 0
        mock_client.delete_source.assert_called_once_with("src123")
