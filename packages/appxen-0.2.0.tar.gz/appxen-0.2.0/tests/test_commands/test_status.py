"""Tests for appxen status command."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from appxen_cli.main import app


class TestStatus:

    def test_not_logged_in(self, monkeypatch, tmp_path):
        """Status fails when not logged in."""
        monkeypatch.delenv("APPXEN_API_KEY", raising=False)
        import appxen_cli.config as cfg
        monkeypatch.setattr(cfg, "CONFIG_FILE", tmp_path / "nonexistent.toml")

        runner = CliRunner()
        result = runner.invoke(app, ["status"])
        assert result.exit_code == 1
        assert "Not logged in" in result.output

    @patch("appxen_cli.main.get_client")
    def test_status_connected(self, mock_get_client):
        """Status shows connected when gateway responds."""
        mock_client = MagicMock()
        mock_client.health.return_value = {"status": "healthy", "service": "mcp-gateway-pro", "version": "0.1.0"}
        mock_client.stats.return_value = {"source_count": 5, "chunk_count": 100}
        mock_client._client.base_url = "https://api.appxen.ai"
        mock_get_client.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(app, ["status"])
        assert result.exit_code == 0
        assert "Connected" in result.output
        assert "5 sources" in result.output
