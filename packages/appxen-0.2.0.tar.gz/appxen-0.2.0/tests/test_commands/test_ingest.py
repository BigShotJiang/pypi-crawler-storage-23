"""Tests for appxen ingest command."""

from pathlib import Path
from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from appxen_cli.main import app
from appxen_cli.commands.ingest import _collect_files, SUPPORTED_EXTENSIONS


class TestCollectFiles:

    def test_single_file(self, tmp_path):
        """Single supported file is collected."""
        f = tmp_path / "test.md"
        f.write_text("hello")
        files = _collect_files(f, "*", recursive=True)
        assert len(files) == 1
        assert files[0] == f

    def test_unsupported_extension(self, tmp_path):
        """Unsupported file type is skipped."""
        f = tmp_path / "test.exe"
        f.write_text("binary")
        files = _collect_files(f, "*", recursive=True)
        assert len(files) == 0

    def test_directory_recursive(self, tmp_path):
        """Recursively collects supported files from directory."""
        (tmp_path / "a.md").write_text("doc a")
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "b.txt").write_text("doc b")
        (sub / "c.exe").write_text("skip")

        files = _collect_files(tmp_path, "*", recursive=True)
        names = {f.name for f in files}
        assert "a.md" in names
        assert "b.txt" in names
        assert "c.exe" not in names

    def test_directory_non_recursive(self, tmp_path):
        """Non-recursive only collects top-level files."""
        (tmp_path / "a.md").write_text("doc a")
        sub = tmp_path / "sub"
        sub.mkdir()
        (sub / "b.txt").write_text("doc b")

        files = _collect_files(tmp_path, "*", recursive=False)
        names = {f.name for f in files}
        assert "a.md" in names
        assert "b.txt" not in names

    def test_glob_pattern(self, tmp_path):
        """Glob pattern filters files."""
        (tmp_path / "a.md").write_text("doc a")
        (tmp_path / "b.txt").write_text("doc b")

        files = _collect_files(tmp_path, "*.md", recursive=False)
        assert len(files) == 1
        assert files[0].name == "a.md"


class TestIngestCommand:

    @patch("appxen_cli.main.get_client")
    def test_ingest_single_file(self, mock_get_client, tmp_path):
        """Ingest a single file."""
        f = tmp_path / "test.md"
        f.write_text("test content")

        mock_client = MagicMock()
        mock_client.upload_file.return_value = {"source_id": "s1", "status": "ready"}
        mock_get_client.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(app, ["ingest", str(f), "--no-poll"])
        assert result.exit_code == 0
        assert "1 file(s) ingested" in result.output

    @patch("appxen_cli.main.get_client")
    def test_ingest_no_files(self, mock_get_client, tmp_path):
        """Ingest with no matching files exits with error."""
        runner = CliRunner()
        result = runner.invoke(app, ["ingest", str(tmp_path), "--no-poll"])
        assert result.exit_code == 1
        assert "No supported files" in result.output
