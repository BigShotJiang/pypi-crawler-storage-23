"""Tests for appxen search command."""

from unittest.mock import MagicMock, patch

from typer.testing import CliRunner

from appxen_cli.main import app


class TestSearch:

    @patch("appxen_cli.main.get_client")
    def test_search_displays_results(self, mock_get_client):
        """Search shows results as panels."""
        mock_client = MagicMock()
        mock_client.search.return_value = {
            "results": [
                {"chunk_id": "c1", "content": "Deploy with ECS", "filename": "deploy.md", "score": 0.95},
            ]
        }
        mock_get_client.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(app, ["search", "how to deploy"])
        assert result.exit_code == 0
        assert "deploy.md" in result.output

    @patch("appxen_cli.main.get_client")
    def test_search_no_results(self, mock_get_client):
        """Search with no results shows message."""
        mock_client = MagicMock()
        mock_client.search.return_value = {"results": []}
        mock_get_client.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(app, ["search", "nonexistent"])
        assert result.exit_code == 0
        assert "No results" in result.output

    @patch("appxen_cli.main.get_client")
    def test_search_json(self, mock_get_client):
        """Search with --json outputs raw JSON."""
        mock_client = MagicMock()
        mock_client.search.return_value = {"results": []}
        mock_get_client.return_value = mock_client

        runner = CliRunner()
        result = runner.invoke(app, ["search", "test", "--json"])
        assert result.exit_code == 0
        assert '"results"' in result.output
