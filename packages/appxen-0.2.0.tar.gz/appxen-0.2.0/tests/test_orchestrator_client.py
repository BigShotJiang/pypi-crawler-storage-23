"""Tests for the OrchestratorClient."""

from unittest.mock import MagicMock, patch

import httpx
import pytest

from appxen_cli.client import OrchestratorClient


class TestOrchestratorClient:

    def test_tenant_id_header_set(self):
        """Client sets X-Tenant-Id header."""
        client = OrchestratorClient("http://localhost:8080", "tenant-123")
        assert client._client.headers["x-tenant-id"] == "tenant-123"
        client.close()

    def test_user_agent_set(self):
        """Client sets User-Agent header."""
        client = OrchestratorClient("http://localhost:8080", "t1")
        assert "appxen-cli" in client._client.headers["user-agent"]
        client.close()

    def test_properties(self):
        """Properties return expected values."""
        client = OrchestratorClient("http://localhost:8080", "t1")
        assert client.endpoint == "http://localhost:8080"
        assert client.tenant_id == "t1"
        client.close()

    def test_context_manager(self):
        """Client works as context manager."""
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            assert client._client is not None

    def _mock_response(self, json_data, status_code=200):
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = status_code
        mock_resp.json.return_value = json_data
        mock_resp.raise_for_status = MagicMock()
        return mock_resp

    @patch("httpx.Client.request")
    def test_health(self, mock_request):
        """Health endpoint returns parsed JSON."""
        mock_request.return_value = self._mock_response(
            {"status": "ok", "service": "agent-orchestrator"}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            result = client.health()
            assert result["status"] == "ok"

    @patch("httpx.Client.request")
    def test_compile_workflow(self, mock_request):
        """Compile sends markdown and returns plan."""
        mock_request.return_value = self._mock_response(
            {"plan": {"name": "Test"}, "notes": [], "usage": {}}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            result = client.compile_workflow("# Test\n")
            assert result["plan"]["name"] == "Test"

        call_kwargs = mock_request.call_args
        json_body = call_kwargs.kwargs.get("json", {})
        assert json_body["markdown"] == "# Test\n"

    @patch("httpx.Client.request")
    def test_create_workflow(self, mock_request):
        """Create sends name + markdown."""
        mock_request.return_value = self._mock_response(
            {"workflow_id": "wf_123", "plan": {}, "notes": []}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            result = client.create_workflow("my-wf", "# Test\n")
            assert result["workflow_id"] == "wf_123"

        call_kwargs = mock_request.call_args
        json_body = call_kwargs.kwargs.get("json", {})
        assert json_body["name"] == "my-wf"
        assert json_body["markdown"] == "# Test\n"

    @patch("httpx.Client.request")
    def test_list_workflows(self, mock_request):
        """List returns workflows array."""
        mock_request.return_value = self._mock_response(
            {"workflows": [{"workflow_id": "wf_1", "name": "Test"}]}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            result = client.list_workflows()
            assert len(result["workflows"]) == 1

    @patch("httpx.Client.request")
    def test_get_workflow(self, mock_request):
        """Get returns workflow details."""
        mock_request.return_value = self._mock_response(
            {"workflow_id": "wf_1", "name": "Test", "plan": {}}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            result = client.get_workflow("wf_1")
            assert result["workflow_id"] == "wf_1"

    @patch("httpx.Client.request")
    def test_update_workflow(self, mock_request):
        """Update sends markdown to PUT endpoint."""
        mock_request.return_value = self._mock_response(
            {"workflow_id": "wf_1", "plan": {}, "notes": []}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            result = client.update_workflow("wf_1", "# Updated\n")
            assert result["workflow_id"] == "wf_1"

        call_kwargs = mock_request.call_args
        # httpx.Client.request(method, path, ...) — method is first positional arg
        assert call_kwargs.args[0] == "PUT"
        json_body = call_kwargs.kwargs.get("json", {})
        assert json_body["markdown"] == "# Updated\n"

    @patch("httpx.Client.request")
    def test_delete_workflow(self, mock_request):
        """Delete calls DELETE endpoint."""
        mock_resp = MagicMock(spec=httpx.Response)
        mock_resp.status_code = 204
        mock_resp.raise_for_status = MagicMock()
        mock_request.return_value = mock_resp

        with OrchestratorClient("http://localhost:8080", "t1") as client:
            client.delete_workflow("wf_1")

        call_kwargs = mock_request.call_args
        assert call_kwargs.args[0] == "DELETE"
        assert "/workflows/wf_1" in call_kwargs.args[1]

    @patch("httpx.Client.request")
    def test_run_workflow(self, mock_request):
        """Run sends inputs and returns execution_id."""
        mock_request.return_value = self._mock_response(
            {"execution_id": "exec_abc", "status": "running"}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            result = client.run_workflow("wf_1", {"key": "val"})
            assert result["execution_id"] == "exec_abc"

        call_kwargs = mock_request.call_args
        json_body = call_kwargs.kwargs.get("json", {})
        assert json_body["inputs"] == {"key": "val"}

    @patch("httpx.Client.request")
    def test_run_workflow_no_inputs(self, mock_request):
        """Run with no inputs sends empty dict."""
        mock_request.return_value = self._mock_response(
            {"execution_id": "exec_abc"}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            client.run_workflow("wf_1")

        call_kwargs = mock_request.call_args
        json_body = call_kwargs.kwargs.get("json", {})
        assert json_body["inputs"] == {}

    @patch("httpx.Client.request")
    def test_get_execution(self, mock_request):
        """Get execution returns status."""
        mock_request.return_value = self._mock_response(
            {"execution_id": "exec_1", "status": "completed"}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            result = client.get_execution("exec_1")
            assert result["status"] == "completed"

    @patch("httpx.Client.request")
    def test_get_steps(self, mock_request):
        """Get steps returns step array."""
        mock_request.return_value = self._mock_response(
            {"steps": [{"step_id": "s1", "status": "completed"}]}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            result = client.get_steps("exec_1")
            assert len(result["steps"]) == 1

    @patch("httpx.Client.request")
    def test_stop_execution(self, mock_request):
        """Stop returns updated status."""
        mock_request.return_value = self._mock_response(
            {"execution_id": "exec_1", "status": "aborted"}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            result = client.stop_execution("exec_1")
            assert result["status"] == "aborted"

    @patch("httpx.Client.request")
    def test_approve_step(self, mock_request):
        """Approve sends approved flag and reason."""
        mock_request.return_value = self._mock_response(
            {"status": "approved"}
        )
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            result = client.approve_step("exec_1", "s1", True, "looks good")
            assert result["status"] == "approved"

        call_kwargs = mock_request.call_args
        json_body = call_kwargs.kwargs.get("json", {})
        assert json_body["approved"] is True
        assert json_body["reason"] == "looks good"

    @patch("httpx.Client.request")
    def test_approve_step_no_reason(self, mock_request):
        """Approve without reason omits reason field."""
        mock_request.return_value = self._mock_response({"status": "approved"})
        with OrchestratorClient("http://localhost:8080", "t1") as client:
            client.approve_step("exec_1", "s1", False)

        call_kwargs = mock_request.call_args
        json_body = call_kwargs.kwargs.get("json", {})
        assert json_body["approved"] is False
        assert "reason" not in json_body
