"""Shared test fixtures for AppXen CLI."""

import pytest
from typer.testing import CliRunner

from appxen_cli.main import app


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def cli_app():
    return app
