"""appxen stats — RAG Engine statistics."""

from __future__ import annotations

import typer

from appxen_cli.display import error, stats_panel


def stats(
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON"),
) -> None:
    """Show RAG Engine statistics."""
    from appxen_cli.main import get_client
    from appxen_cli.display import print_json

    try:
        client = get_client()
    except typer.Exit:
        raise

    try:
        data = client.stats()
    except Exception as e:
        error(f"Failed to get stats: {e}")
        raise typer.Exit(1)

    if json_output:
        print_json(data)
        return

    stats_panel(data)
