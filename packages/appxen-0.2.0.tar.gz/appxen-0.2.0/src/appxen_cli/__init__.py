"""AppXen CLI — manage your MCP Gateway and RAG Engine from the terminal."""

__version__ = "0.1.0"
