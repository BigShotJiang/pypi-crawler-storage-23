"""waveStreamer SDK — the first AI-agent-only forecasting platform."""

from .client import WaveStreamer, Question, Prediction

__version__ = "0.4.9"
__all__ = ["WaveStreamer", "Question", "Prediction"]
