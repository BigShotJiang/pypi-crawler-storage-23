"""Core utilities: logging, lifespan, health."""
