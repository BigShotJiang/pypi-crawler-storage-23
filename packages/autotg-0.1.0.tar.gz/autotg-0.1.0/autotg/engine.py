import pandas as pd
import numpy as np
from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer


def find_best_target(path_or_df):
    """
    Automatically detects the most predictable column
    using adaptive sampling and lightweight ML models.
    """

    # Load dataset
    if isinstance(path_or_df, str):
        df = pd.read_csv(path_or_df)
    else:
        df = path_or_df.copy()

    df = df.dropna(axis=1, how="all")
    df = df.dropna()

    if len(df) < 10:
        return [("Dataset too small for analysis", 0)]

    # 🔥 Adaptive sampling logic
    total_rows = len(df)

    if total_rows < 1000:
        sample_df = df
    elif total_rows < 10000:
        sample_df = df.sample(n=1000, random_state=42)
    else:
        sample_df = df.sample(n=2000, random_state=42)

    results = []

    for target in sample_df.columns:

        X = sample_df.drop(columns=[target])
        y = sample_df[target]

        if y.nunique() < 2:
            continue

        numeric_cols = X.select_dtypes(include=np.number).columns
        categorical_cols = X.select_dtypes(exclude=np.number).columns

        preprocessor = ColumnTransformer(
            transformers=[
                ('num', SimpleImputer(strategy='mean'), numeric_cols),
                ('cat', Pipeline([
                    ('impute', SimpleImputer(strategy='most_frequent')),
                    ('encode', OneHotEncoder(handle_unknown='ignore'))
                ]), categorical_cols)
            ]
        )

        # Decide problem type automatically
        if y.dtype == 'object' or y.nunique() <= 10:
            model = RandomForestClassifier(
                n_estimators=25,
                max_depth=5,
                random_state=42
            )
            scoring = 'accuracy'
        else:
            model = RandomForestRegressor(
                n_estimators=25,
                max_depth=5,
                random_state=42
            )
            scoring = 'r2'

        pipe = Pipeline([
            ('prep', preprocessor),
            ('model', model)
        ])

        try:
            scores = cross_val_score(pipe, X, y, cv=3, scoring=scoring)
            mean_score = scores.mean()
            results.append((target, round(mean_score, 4)))
        except:
            continue

    if not results:
        return [("No suitable prediction column found", 0)]
    results = sorted(results, key=lambda x: x[1], reverse=True)
    return results

