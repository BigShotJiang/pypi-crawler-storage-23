"""
yarbo.mqtt — Async MQTT transport layer for the Yarbo local protocol.

Wraps ``paho-mqtt`` in an asyncio-friendly interface. The Yarbo robot
exposes a plaintext EMQX broker on port 1883; all payloads are
zlib-compressed JSON (see ``yarbo._codec``).

Protocol notes (from hardware testing and community documentation):
- Topics follow ``snowbot/{SN}/app/{cmd}`` (publish) and
  ``snowbot/{SN}/device/{feedback}`` (subscribe).
- A ``get_controller`` handshake MUST be sent before action commands.
- Commands are fire-and-forget; responses arrive on ``data_feedback``.
- All payloads are encoded with :func:`yarbo._codec.encode`.
- ``heart_beat`` is plain JSON (NOT zlib); the codec fallback handles this.
- ``DeviceMSG`` is the primary telemetry topic (~1-2 Hz, zlib JSON).

References:
  Protocol documentation (command catalogue and MQTT protocol reference)
"""

from __future__ import annotations

import asyncio
import collections
import copy
import json
import logging
from pathlib import Path
import sys
import threading
import time
from typing import TYPE_CHECKING, Any, cast

if TYPE_CHECKING:
    from collections.abc import AsyncIterator, Callable

    import paho.mqtt.client as _paho

import contextlib

from ._codec import decode, encode
from .const import (
    ALL_FEEDBACK_LEAVES,
    DEFAULT_CMD_TIMEOUT,
    DEFAULT_CONNECT_TIMEOUT,
    MQTT_KEEPALIVE,
    TOPIC_APP_TMPL,
    TOPIC_DEVICE_TMPL,
    TOPIC_LEAF_DATA_FEEDBACK,
    TOPIC_LEAF_HEART_BEAT,
    Topic,
)
from .exceptions import YarboConnectionError, YarboTimeoutError
from .models import TelemetryEnvelope

logger = logging.getLogger(__name__)


class MqttTransport:
    """
    Asyncio-compatible MQTT transport for the Yarbo local broker.

    Uses paho-mqtt v2 (``CallbackAPIVersion.VERSION2``) in its callback-based
    API, bridged to asyncio via ``loop.call_soon_threadsafe``. All public
    methods are coroutines.

    Message routing
    ~~~~~~~~~~~~~~~
    All received messages are pushed into the shared ``_message_queues`` list
    as envelope dicts: ``{"topic": full_topic, "payload": decoded_dict}``.
    :meth:`wait_for_message` filters by topic leaf; :meth:`telemetry_stream`
    yields all messages as :class:`~yarbo.models.TelemetryEnvelope` objects.

    Example::

        transport = MqttTransport(broker="<rover-ip>", sn="YOUR_SERIAL")
        await transport.connect()
        await transport.publish("get_controller", {})
        await transport.publish("light_ctrl", {"led_head": 255, "led_left_w": 255})
        async for envelope in transport.telemetry_stream():
            if envelope.is_telemetry:
                t = envelope.to_telemetry()
                print(t.battery)
        await transport.disconnect()

    Debug / capture (constructor): ``debug`` / ``debug_raw`` print every message to stderr;
    ``mqtt_capture_max`` > 0 keeps the last N messages; use :meth:`get_captured_mqtt` to
    retrieve them (e.g. for ``report_mqtt_dump_to_glitchtip``).
    """

    def __init__(
        self,
        broker: str,
        sn: str,
        port: int = 1883,
        username: str = "",
        password: str = "",
        connect_timeout: float = DEFAULT_CONNECT_TIMEOUT,
        qos: int = 0,
        tls: bool = False,
        tls_ca_certs: str | None = None,
        mqtt_log_path: str | None = None,
        debug: bool = False,
        debug_raw: bool = False,
        mqtt_capture_max: int = 0,
    ) -> None:
        self._broker = broker
        self._sn = sn
        self._port = port
        self._username = username
        self._password = password
        self._connect_timeout = connect_timeout
        self._qos = qos
        self._tls = tls
        self._tls_ca_certs = tls_ca_certs
        self._mqtt_log_path: str | None = mqtt_log_path
        self._mqtt_log_lock: threading.Lock = threading.Lock()
        self._debug = debug
        self._debug_raw = debug_raw
        self._mqtt_capture_max = mqtt_capture_max
        self._mqtt_capture: collections.deque[dict[str, Any]] = collections.deque(
            maxlen=mqtt_capture_max if mqtt_capture_max > 0 else None
        )

        # paho Client — typed via TYPE_CHECKING import to avoid hard dependency
        self._client: _paho.Client | None = None
        self._loop: asyncio.AbstractEventLoop | None = None
        self._connected = asyncio.Event()
        # Each entry is a queue of envelope dicts: {"topic": str, "payload": dict}
        self._message_queues: list[asyncio.Queue[dict[str, Any]]] = []
        # Reconnect tracking: True after the first successful disconnect
        self._was_connected: bool = False
        # Callbacks invoked (on the asyncio loop) when the transport reconnects
        self._reconnect_callbacks: list[Callable[[], None]] = []
        # Epoch timestamp of the last received heart_beat message (None = none received yet).
        # Updated directly in _on_message (paho thread) — a float write is atomic in CPython.
        self._last_heartbeat: float | None = None

    @property
    def sn(self) -> str:
        """Robot serial number."""
        return self._sn

    @property
    def is_connected(self) -> bool:
        """True if the MQTT connection is established."""
        return self._connected.is_set()

    @property
    def last_heartbeat(self) -> float | None:
        """Unix epoch timestamp of the last received ``heart_beat`` message, or ``None``."""
        return self._last_heartbeat

    def add_reconnect_callback(self, callback: Callable[[], None]) -> None:
        """Register a callback to be invoked on the asyncio loop after a reconnect.

        A *reconnect* is any successful ``_on_connect`` that happens after the
        transport has previously been disconnected (i.e. not the initial connect).
        Duplicate callbacks are silently ignored.
        """
        if callback not in self._reconnect_callbacks:
            self._reconnect_callbacks.append(callback)

    # ------------------------------------------------------------------
    # Connection lifecycle
    # ------------------------------------------------------------------

    def _create_and_connect_paho(self) -> Any:
        """Blocking helper: import paho, create and configure client, TCP-connect to broker.

        Runs in a thread-pool executor so that blocking I/O — package imports
        via ``importlib.metadata`` (idna, see #104), DNS resolution, and the
        TCP/TLS handshake — never stalls the asyncio event loop.

        Returns the configured paho ``Client`` *before* ``loop_start()``.
        Callbacks and the asyncio loop reference are attached by the caller on
        the asyncio event loop, ensuring they are bound to the correct loop.
        """
        import paho.mqtt.client as mqtt  # noqa: PLC0415

        client_id = f"python-yarbo-{self._sn}-{int(time.time())}"
        client = mqtt.Client(
            client_id=client_id,
            protocol=mqtt.MQTTv311,
            callback_api_version=mqtt.CallbackAPIVersion.VERSION2,  # type: ignore[attr-defined, unused-ignore]
        )
        if self._username:
            client.username_pw_set(self._username, self._password)

        if self._tls:
            import ssl  # noqa: PLC0415

            if self._tls_ca_certs:
                client.tls_set(
                    ca_certs=self._tls_ca_certs,
                    cert_reqs=ssl.CERT_REQUIRED,
                )
            else:
                client.tls_set_context(ssl.create_default_context())

        # Blocking: DNS resolution + TCP connect (+ optional TLS handshake).
        client.connect(self._broker, self._port, keepalive=MQTT_KEEPALIVE)
        return client

    async def connect(self) -> None:
        """
        Connect to the MQTT broker and subscribe to all feedback topics.

        Raises:
            YarboConnectionError: If paho-mqtt is not installed.
            YarboTimeoutError:    If the broker does not respond within timeout.
        """
        loop = asyncio.get_running_loop()
        try:
            client = await loop.run_in_executor(None, self._create_and_connect_paho)
        except ImportError as exc:
            raise YarboConnectionError(
                "paho-mqtt is required: pip install 'python-yarbo[mqtt]'"
            ) from exc
        except OSError as exc:
            raise YarboConnectionError(
                f"Cannot connect to MQTT broker {self._broker}:{self._port}: {exc}"
            ) from exc

        self._client = client
        # Back on the asyncio event loop: capture the loop reference *now* so
        # that paho callbacks (_on_connect, _on_disconnect, _on_message) bridge
        # back via call_soon_threadsafe on the correct, live loop — not a dead
        # throwaway loop that was closed after an executor run.
        self._loop = loop
        self._connected.clear()
        client.on_connect = self._on_connect
        client.on_disconnect = self._on_disconnect
        client.on_message = self._on_message
        client.loop_start()

        try:
            await asyncio.wait_for(self._connected.wait(), timeout=self._connect_timeout)
        except TimeoutError as exc:
            # Run loop_stop in executor — it joins the paho thread and must not block the loop.
            await loop.run_in_executor(None, client.loop_stop)
            raise YarboTimeoutError(
                f"Timed out waiting for MQTT connection to {self._broker}:{self._port}"
            ) from exc

        logger.info("MQTT connected to %s:%d (sn=%s)", self._broker, self._port, self._sn)

    async def disconnect(self) -> None:
        """
        Cleanly disconnect from the MQTT broker.

        Calls ``disconnect()`` first to send a clean MQTT DISCONNECT packet,
        then ``loop_stop()`` (run in a thread-pool executor so it does not
        block the asyncio event loop while joining the paho network thread).
        """
        if self._client:
            self._client.disconnect()
            # paho.loop_stop() joins the network thread — run off-loop to avoid blocking.
            await asyncio.get_running_loop().run_in_executor(None, self._client.loop_stop)
            self._connected.clear()
            logger.info("MQTT disconnected from %s", self._broker)

    # ------------------------------------------------------------------
    # Publish
    # ------------------------------------------------------------------

    async def publish(self, cmd: str, payload: dict[str, Any], qos: int | None = None) -> None:
        """
        Publish a zlib-compressed command to the robot.

        Args:
            cmd:     Topic leaf name (e.g. ``"light_ctrl"``, ``"get_controller"``).
            payload: Dict to encode and publish.
            qos:     QoS level (0, 1, or 2). Defaults to the transport's
                     configured QoS (typically 0 for Yarbo).

        Raises:
            YarboConnectionError: If not connected.
        """
        if not self.is_connected:
            raise YarboConnectionError("Not connected to MQTT broker. Call connect() first.")
        effective_qos = qos if qos is not None else self._qos
        topic = TOPIC_APP_TMPL.format(sn=self._sn, cmd=cmd)
        encoded = encode(payload)
        self._client.publish(topic, encoded, qos=effective_qos)  # type: ignore[union-attr]
        logger.debug("→ MQTT [%s] %s", topic, str(payload)[:160])
        envelope = {"direction": "sent", "topic": topic, "payload": payload}
        self._maybe_capture(envelope)
        if self._debug:
            self._debug_print(envelope, "→")

    # ------------------------------------------------------------------
    # Receive
    # ------------------------------------------------------------------

    def _maybe_capture(self, envelope: dict[str, Any]) -> None:
        """Append to capture buffer if enabled; trim to max size."""
        if self._mqtt_capture_max <= 0:
            return
        with self._mqtt_log_lock:
            self._mqtt_capture.append(copy.deepcopy(envelope))

    def get_captured_mqtt(self) -> list[dict[str, Any]]:
        """Return a copy of captured MQTT messages (for GlitchTip report)."""
        with self._mqtt_log_lock:
            return copy.deepcopy(list(self._mqtt_capture))

    def _debug_print(self, envelope: dict[str, Any], prefix: str) -> None:
        """Print one MQTT envelope to stderr (human-readable or raw)."""
        topic = envelope.get("topic", "")
        payload = envelope.get("payload", {})
        with self._mqtt_log_lock:
            if self._debug_raw:
                line = (
                    json.dumps(
                        {
                            "direction": envelope.get("direction", "?"),
                            "topic": topic,
                            "payload": payload,
                        },
                        ensure_ascii=False,
                    )
                    + "\n"
                )
                sys.stderr.write(line)
            else:
                sys.stderr.write(f"\n--- MQTT {prefix} ---\ntopic: {topic}\npayload:\n")
                sys.stderr.write(json.dumps(payload, indent=2, ensure_ascii=False) + "\n")

    def release_queue(self, queue: asyncio.Queue[dict[str, Any]]) -> None:
        """
        Remove a pre-registered wait queue from the message queue list.

        Call this if a publish fails after :meth:`create_wait_queue` but before
        :meth:`wait_for_message` — otherwise the queue leaks and accumulates
        copies of every future incoming message indefinitely.
        """
        with contextlib.suppress(ValueError):
            self._message_queues.remove(queue)

    def create_wait_queue(self) -> asyncio.Queue[dict[str, Any]]:
        """
        Pre-register a bounded message queue **before** publishing a command.

        Call this immediately before :meth:`publish` to eliminate the
        publish/subscribe race: if the robot's response arrives between the
        publish and the first ``await`` in :meth:`wait_for_message`, it is
        already captured in the returned queue.

        The returned queue must be passed back to :meth:`wait_for_message`
        via the ``_queue`` parameter.  It is automatically deregistered when
        :meth:`wait_for_message` returns.

        Returns:
            A pre-registered :class:`asyncio.Queue` (maxsize=1000).
        """
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=1000)
        self._message_queues.append(queue)
        return queue

    async def wait_for_message(
        self,
        timeout: float = DEFAULT_CMD_TIMEOUT,
        feedback_leaf: str = TOPIC_LEAF_DATA_FEEDBACK,
        command_name: str | None = None,
        _queue: asyncio.Queue[dict[str, Any]] | None = None,
        _return_envelope: bool = False,
    ) -> dict[str, Any] | None:
        """
        Wait for the next message matching a specific feedback topic leaf.

        If ``_queue`` is provided it must have been obtained via
        :meth:`create_wait_queue` **before** the publish call so that no
        response can be missed.  Otherwise a new queue is created here
        (subject to the usual publish/subscribe race).

        Args:
            timeout:       Maximum wait time in seconds.
            feedback_leaf: Feedback topic leaf to match (default: ``data_feedback``).
                           Use ``TOPIC_LEAF_DEVICE_MSG`` for telemetry data.
            command_name:  When set, only accept payloads whose ``topic`` field
                           equals this value.  Prevents misrouting when multiple
                           commands are in-flight on the same ``data_feedback``
                           topic.
            _queue:        Pre-registered queue from :meth:`create_wait_queue`.
                           When supplied the queue is NOT created here and will
                           be deregistered on return.
            _return_envelope: If ``True``, return the full envelope dict instead
                           of just the payload.

        Returns:
            Decoded message payload dict (or envelope dict if ``_return_envelope``
            is ``True``), or ``None`` on timeout.
        """
        if _queue is not None:
            queue = _queue
        else:
            queue = asyncio.Queue(maxsize=1000)
            self._message_queues.append(queue)
        loop = asyncio.get_running_loop()
        deadline = loop.time() + timeout
        try:
            while True:
                remaining = deadline - loop.time()
                if remaining <= 0:
                    return None
                try:
                    envelope = await asyncio.wait_for(queue.get(), timeout=remaining)
                except TimeoutError:
                    return None
                if Topic.leaf(envelope.get("topic", "")) != feedback_leaf:
                    continue
                payload_topic = envelope.get("payload", {}).get("topic")
                if command_name is not None and payload_topic != command_name:
                    continue
                if _return_envelope:
                    return envelope
                return cast("dict[str, Any]", envelope["payload"])
        finally:
            with contextlib.suppress(ValueError):
                self._message_queues.remove(queue)

    async def telemetry_stream(self) -> AsyncIterator[TelemetryEnvelope]:
        """
        Async generator that yields :class:`~yarbo.models.TelemetryEnvelope` objects.

        Streams ALL incoming MQTT messages (``DeviceMSG``, ``heart_beat``,
        ``data_feedback``, etc.) as typed envelopes. Callers can inspect
        ``envelope.kind`` to route messages.

        Runs indefinitely until the transport is disconnected or the caller
        breaks the loop.

        Example::

            async for envelope in transport.telemetry_stream():
                if envelope.is_telemetry:         # DeviceMSG
                    t = envelope.to_telemetry()
                    print(f"Battery: {t.battery}%")
                elif envelope.is_heartbeat:        # heart_beat
                    print("Working:", envelope.payload.get("working_state"))
                if some_condition:
                    break

        Yields:
            :class:`~yarbo.models.TelemetryEnvelope` for each received message.
        """
        queue: asyncio.Queue[dict[str, Any]] = asyncio.Queue(maxsize=1000)
        self._message_queues.append(queue)
        try:
            while self.is_connected:
                try:
                    envelope_dict = await asyncio.wait_for(queue.get(), timeout=5.0)
                    topic: str = envelope_dict.get("topic", "")
                    payload: dict[str, Any] = envelope_dict.get("payload", {})
                    kind = Topic.leaf(topic)
                    yield TelemetryEnvelope(kind=kind, payload=payload, topic=topic)
                except TimeoutError:
                    continue
        finally:
            with contextlib.suppress(ValueError):
                self._message_queues.remove(queue)

    # ------------------------------------------------------------------
    # paho-mqtt callbacks (called from paho thread → bridge to asyncio)
    # ------------------------------------------------------------------

    def _on_connect(
        self,
        client: Any,
        userdata: Any,
        flags: Any,
        reason_code: Any,
        props: Any,
    ) -> None:
        """
        paho-mqtt v2 on_connect callback.

        ``reason_code`` is a ``ReasonCode`` object under paho v2.
        ``getattr(..., "value", ...)`` normalises it to an ``int``
        so the ``rc == 0`` check works for both object and int forms.
        """
        rc = getattr(reason_code, "value", reason_code)
        if rc == 0:
            is_reconnect = self._was_connected
            # Always re-subscribe to all feedback topics (covers both initial connect
            # and automatic broker reconnections initiated by paho).
            if self._sn:
                for leaf in ALL_FEEDBACK_LEAVES:
                    topic = TOPIC_DEVICE_TMPL.format(sn=self._sn, feedback=leaf)
                    client.subscribe(topic, qos=self._qos)
                    logger.debug("Subscribed: %s", topic)
            else:
                # Discovery mode: no serial number known — use wildcards
                for leaf in ALL_FEEDBACK_LEAVES:
                    topic = f"snowbot/+/device/{leaf}"
                    client.subscribe(topic, qos=self._qos)
                    logger.debug("Subscribed (discovery): %s", topic)
            if self._loop and not self._loop.is_closed():
                self._loop.call_soon_threadsafe(self._connected.set)
                if is_reconnect:
                    logger.info("MQTT reconnected — re-subscribed (sn=%s)", self._sn)
                    for cb in list(self._reconnect_callbacks):
                        self._loop.call_soon_threadsafe(cb)
        else:
            logger.error("MQTT connect failed rc=%s", rc)

    def _on_disconnect(
        self,
        client: Any,
        userdata: Any,
        disconnect_flags: Any,
        reason_code: Any,
        props: Any,
    ) -> None:
        """paho-mqtt v2 on_disconnect callback."""
        rc = getattr(reason_code, "value", reason_code)
        self._was_connected = True  # next _on_connect is a reconnect
        if self._loop and not self._loop.is_closed():
            self._loop.call_soon_threadsafe(self._connected.clear)
        if rc == 0:
            logger.debug("MQTT disconnected rc=%s (normal)", rc)
        else:
            logger.warning("MQTT disconnected rc=%s", rc)

    def _enqueue_safe(self, q: asyncio.Queue[dict[str, Any]], envelope: dict[str, Any]) -> None:
        """
        Enqueue *envelope* into *q*, dropping the oldest item if the queue is full.

        Must be called **on the asyncio event loop** (via
        ``loop.call_soon_threadsafe``).  Bounded queues (maxsize=1000) prevent
        unbounded memory growth for slow consumers while preserving the newest
        real-time data.
        """
        if q.full():
            with contextlib.suppress(asyncio.QueueEmpty):
                q.get_nowait()  # discard oldest
        with contextlib.suppress(asyncio.QueueFull):
            q.put_nowait(envelope)

    def _on_message(self, client: Any, userdata: Any, msg: Any) -> None:
        """
        paho-mqtt on_message callback.

        Pushes an envelope dict ``{"topic": str, "payload": dict}`` into
        every registered queue so that :meth:`wait_for_message` can filter
        by topic leaf and :meth:`telemetry_stream` can expose the kind.

        Also tracks the timestamp of ``heart_beat`` messages for
        :attr:`last_heartbeat`.
        """
        try:
            payload = decode(msg.payload)
            logger.debug(
                "← MQTT [%s] %s",
                msg.topic,
                str(payload)[:160],
            )
            capture_envelope = {
                "direction": "received",
                "topic": getattr(msg, "topic", ""),
                "payload": payload,
            }
            self._maybe_capture(capture_envelope)
            if self._debug:
                self._debug_print(capture_envelope, "←")
            # Optional: log every raw MQTT message (topic + payload) for comparison with CLI output.
            if self._mqtt_log_path:
                with self._mqtt_log_lock:
                    try:
                        with Path(self._mqtt_log_path).open("a", encoding="utf-8") as f:
                            f.write(
                                json.dumps(
                                    {"topic": getattr(msg, "topic", ""), "payload": payload},
                                    ensure_ascii=False,
                                )
                                + "\n"
                            )
                    except OSError as e:
                        logger.warning("Failed to write MQTT log: %s", e)
            # Track heartbeat reception time (float write is atomic in CPython).
            if Topic.leaf(msg.topic) == TOPIC_LEAF_HEART_BEAT:
                self._last_heartbeat = time.time()
            # Auto-discover serial number from wildcard subscription
            if not self._sn:
                parts = msg.topic.split("/")
                if len(parts) >= 2 and parts[0] == "snowbot" and parts[1]:
                    self._sn = parts[1]
                    logger.info("Discovered robot serial number: %s", self._sn)
            if self._loop and not self._loop.is_closed() and self._message_queues:
                for q in list(self._message_queues):
                    # Each consumer gets its own deep copy so that no two consumers
                    # can accidentally mutate each other's view of the envelope.
                    envelope: dict[str, Any] = {
                        "topic": msg.topic,
                        "payload": copy.deepcopy(payload),
                    }
                    # _enqueue_safe runs on the event loop: drops the oldest item
                    # when the bounded queue is full so slow consumers never stall
                    # real-time telemetry delivery.
                    self._loop.call_soon_threadsafe(self._enqueue_safe, q, envelope)
        except Exception as exc:  # noqa: BLE001
            logger.error("Error handling MQTT message on %s: %s", getattr(msg, "topic", "?"), exc)
