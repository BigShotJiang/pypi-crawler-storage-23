from abc import ABC, abstractmethod

from foodeo_core.shared.services.audit.core_event import DomainEvent


class EventPublisher(ABC):
    @abstractmethod
    def publish(self, event: DomainEvent) -> None:
        pass

    @abstractmethod
    def pull(self) -> list[DomainEvent]:
        pass


class CollectingEventPublisher(EventPublisher):
    """
    Publisher in-memory para que el core sea independiente:
    Django u otro consumidor decide qué hace con los eventos.
    """

    def __init__(self) -> None:
        self._events: list[DomainEvent] = []

    def publish(self, event: DomainEvent) -> None:
        self._events.append(event)

    def pull(self) -> list[DomainEvent]:
        events = list(self._events)
        self._events.clear()
        return events

    @property
    def events(self) -> list[DomainEvent]:
        # útil para inspección, no mutar desde afuera
        return list(self._events)
