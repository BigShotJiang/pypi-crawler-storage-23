from datetime import datetime

from pydantic import BaseModel

from foodeo_core.shared.services.audit.context import AuditContext


class DomainEvent(BaseModel):
    event_type: str
    occurred_at: datetime
    context: AuditContext
