from abc import ABC, abstractmethod


class ITranslator(ABC):
    @abstractmethod
    def gettext(self, message: str):
        pass

    @abstractmethod
    def format(self, message: str, **kwargs):
        pass
