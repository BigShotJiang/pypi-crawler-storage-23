from typing import Optional

from pydantic import Field, ConfigDict, BaseModel

from foodeo_core.shared.entities import LocalRequest


class ModifierInCorrections(BaseModel):
    id: Optional[int] = None
    modifiers_id: Optional[int] = None
    modifiers_name: Optional[str] = None
    options_id: Optional[int] = None
    options_name: Optional[str] = None
    modifiers_child_id: Optional[int] = None
    modifiers_child_name: Optional[str] = None
    options_child_id: Optional[int] = None
    options_child_name: Optional[str] = None
    qty: Optional[int] = None
    qty_child: Optional[int] = None


class ProductsInCorrections(BaseModel):
    model_config = ConfigDict(use_enum_values=True, arbitrary_types_allowed=True)
    name: str = Field(...)
    qty: int = Field(...)
    id: Optional[int] = None
    modifiers: Optional[list[ModifierInCorrections]] = []


class CorrectionLocalRequest(LocalRequest):
    products: list[ProductsInCorrections]
