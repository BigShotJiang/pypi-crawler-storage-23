from abc import ABC, abstractmethod

from foodeo_core.commands.entities.corrections.corrections_dto import RequestsTableDTOForCorrections


class IRequestsTableRepository(ABC):
    @abstractmethod
    def get_requests_tables_by_command(self, command_id: int) -> list[
        RequestsTableDTOForCorrections]:
        pass
