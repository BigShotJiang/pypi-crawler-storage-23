from foodeo_core.shared.entities import LocalRequest, ProductInRequest
from foodeo_core.shared.entities.commands import LocalCommand
from foodeo_core.shared.entities.irequests import IModifierRequest
from foodeo_core.shared.enums import RequestEnum, FromClientEnum


class FromCommandToRequestsService:
    def get_request(self, command_model: LocalCommand) -> LocalRequest:
        assert command_model.id is not None
        products = command_model.products
        list_products: list[ProductInRequest] = []
        for product in products:
            modifiers: list[IModifierRequest] = product.modifiers
            product_in_request: ProductInRequest = ProductInRequest(name=product.name, qty=product.qty,
                                                                    price=product.price, details=product.details,
                                                                    unit_name=product.unit_name,
                                                                    unit_value=product.unit_value,
                                                                    amount=product.amount,
                                                                    total_price=product.total_price,
                                                                    unit_price=product.unit_price, norm=product.norm,
                                                                    modifiers=modifiers,
                                                                    purchase_price=product.purchase_price,
                                                                    id=product.id)
            list_products.append(
                product_in_request)
        local_request: LocalRequest = LocalRequest(qr=command_model.qr, command_guests=command_model.command_guests,
                                                   type=RequestEnum.local,
                                                   command_id=command_model.id, from_client=FromClientEnum.web,
                                                   details=command_model.details,
                                                   products=list_products)
        return local_request
