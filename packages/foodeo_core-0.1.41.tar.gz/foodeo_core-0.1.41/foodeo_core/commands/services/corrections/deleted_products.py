from foodeo_core.commands.entities.corrections.corrections_dto import RequestsTableDTOForCorrections
from foodeo_core.commands.services.corrections.utils import _map_modifier_flat
from foodeo_core.shared.entities.corrections import ProductsInCorrections, ModifierInCorrections


class DeletedProductsNegativeDeltaService:
    def build(self, db_rows: list[
        RequestsTableDTOForCorrections]) -> list[ProductsInCorrections]:
        out: list[ProductsInCorrections] = []
        for row in db_rows:
            list_modifiers: list[ModifierInCorrections] = []
            for mod in (row.modifiers or []):
                list_modifiers.extend(_map_modifier_flat(mod))
            out.append(
                ProductsInCorrections(
                    qty=-row.qty,
                    name=row.product_name,
                    id=row.product_id,
                    modifiers=list_modifiers,
                )
            )
        return out
