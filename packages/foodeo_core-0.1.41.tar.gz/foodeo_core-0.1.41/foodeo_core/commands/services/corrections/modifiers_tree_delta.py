from dataclasses import dataclass

from foodeo_core.commands.entities.corrections.corrections_dto import ModifiersDTOForCorrections
from foodeo_core.shared.entities.corrections import ModifierInCorrections
from foodeo_core.shared.entities.irequests import ModifiersRequest


@dataclass(frozen=True)
class ModifierDeltaService:
    def diff(
            self,
            db: list[ModifiersDTOForCorrections] | None,
            cmd: list[ModifiersRequest] | None,
    ) -> list[ModifierInCorrections]:
        option_qty_by_key, child_qty_by_key = _index_command_modifiers(cmd)
        db_option_qty_by_key: dict[tuple[int, int], int] = {}
        for db_item in db or []:
            if db_item.modifiers_id is None or db_item.options_id is None:
                continue
            if db_item.qty is None:
                continue
            db_option_qty_by_key[(db_item.modifiers_id, db_item.options_id)] = db_item.qty
        out: list[ModifierInCorrections] = []

        for db_item in db or []:
            modifiers_id = db_item.modifiers_id
            options_id = db_item.options_id
            if modifiers_id is None or options_id is None:
                continue

            is_child = db_item.options_child_id is not None or db_item.modifiers_child_id is not None
            if is_child:
                if db_item.modifiers_child_id is None or db_item.options_child_id is None:
                    continue
                db_qty = db_item.qty_child
                if db_qty is None:
                    continue
                key = (modifiers_id, options_id, db_item.modifiers_child_id, db_item.options_child_id)
                cmd_qty = child_qty_by_key.get(key)
                if cmd_qty is None:
                    qty_diff = db_qty
                elif cmd_qty < db_qty:
                    qty_diff = db_qty - cmd_qty
                else:
                    continue
                key_parent = (modifiers_id, options_id)
                cmd_parent_qty = option_qty_by_key.get(key_parent, 0)
                db_parent_qty = db_option_qty_by_key.get(key_parent, 0)
                parent_qty = cmd_parent_qty - db_parent_qty
                if parent_qty > 0:
                    parent_qty = 0
                out.append(
                    ModifierInCorrections(
                        id=db_item.id,
                        modifiers_id=db_item.modifiers_id,
                        modifiers_name=db_item.modifiers_name,
                        options_id=db_item.options_id,
                        options_name=db_item.options_name,
                        modifiers_child_id=db_item.modifiers_child_id,
                        modifiers_child_name=db_item.modifiers_child_name,
                        options_child_id=db_item.options_child_id,
                        options_child_name=db_item.options_child_name,
                        qty=parent_qty,
                        qty_child=-qty_diff,
                    )
                )
            else:
                db_qty = db_item.qty
                if db_qty is None:
                    continue
                key = (modifiers_id, options_id)
                cmd_qty = option_qty_by_key.get(key)
                if cmd_qty is None:
                    qty_diff = db_qty
                elif cmd_qty < db_qty:
                    qty_diff = db_qty - cmd_qty
                else:
                    continue
                out.append(
                    ModifierInCorrections(
                        id=db_item.id,
                        modifiers_id=db_item.modifiers_id,
                        modifiers_name=db_item.modifiers_name,
                        options_id=db_item.options_id,
                        options_name=db_item.options_name,
                        modifiers_child_id=db_item.modifiers_child_id,
                        modifiers_child_name=db_item.modifiers_child_name,
                        options_child_id=db_item.options_child_id,
                        options_child_name=db_item.options_child_name,
                        qty=-qty_diff,
                    )
                )

        return out


def _index_command_modifiers(
        modifiers: list[ModifiersRequest] | None,
) -> tuple[dict[tuple[int, int], int], dict[tuple[int, int, int, int], int]]:
    option_qty_by_key: dict[tuple[int, int], int] = {}
    child_qty_by_key: dict[tuple[int, int, int, int], int] = {}
    for modifier in modifiers or []:
        modifiers_id = modifier.modifiers_id
        if modifiers_id is None:
            continue
        options = modifier.options or []
        if options:
            for option in options:
                if option.id is None:
                    continue
                option_qty_by_key[(modifiers_id, option.id)] = option.qty
                for modifier_child in option.modifiers or []:
                    if modifier_child.id is None:
                        continue
                    for option_child in modifier_child.options or []:
                        if option_child.id is None:
                            continue
                        child_qty_by_key[
                            (modifiers_id, option.id, modifier_child.id, option_child.id)] = option_child.qty
            continue

        # Flat modifier payloads: options_id/qty live at modifier level.
        if modifier.options_id is not None and modifier.qty is not None:
            option_qty_by_key[(modifiers_id, modifier.options_id)] = modifier.qty

        if (
            modifier.options_id is not None
            and modifier.modifiers_child_id is not None
            and modifier.options_child_id is not None
            and modifier.qty_child is not None
        ):
            child_qty_by_key[
                (modifiers_id, modifier.options_id, modifier.modifiers_child_id, modifier.options_child_id)
            ] = modifier.qty_child
    return option_qty_by_key, child_qty_by_key


def build_modifiers_tree_negative_delta_service() -> ModifierDeltaService:
    return ModifierDeltaService()
