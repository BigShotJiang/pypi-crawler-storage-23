from abc import ABC, abstractmethod

from foodeo_core.dataclasses.result import ResultWithValue
from foodeo_core.shared.entities import LocalRequest
from foodeo_core.shared.entities.commands import LocalCommand
from foodeo_core.shared.entities.corrections import CorrectionLocalRequest


class ICreateCorrectionsFromCommandService(ABC):
    @abstractmethod
    def create_corrections(self, command_model: LocalCommand) -> ResultWithValue[CorrectionLocalRequest | None]:
        pass


class ICreateRequestForCorrectionsFromCommandService(ABC):
    @abstractmethod
    def create_request(self, command_model: LocalCommand) -> ResultWithValue[LocalRequest | None]:
        pass
