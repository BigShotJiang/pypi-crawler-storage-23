from typing import Optional

from foodeo_core.commands.entities.corrections.corrections_dto import RequestsTableDTOForCorrections
from foodeo_core.commands.services.corrections.utils import _map_modifier_flat
from foodeo_core.shared.entities.commands import ProductInCommand
from foodeo_core.shared.entities.corrections import ProductsInCorrections, ModifierInCorrections


class ProductQtyNegativeDeltaService:
    """
    Crea una línea de corrección cuando BAJA el qty del producto.
    - qty: delta negativo
    - modifiers: snapshot de DB (como estaba)
    """

    def build_delta(
            self,
            db_row: RequestsTableDTOForCorrections,
            cmd_product: ProductInCommand,
    ) -> Optional[ProductsInCorrections]:
        if db_row.qty <= cmd_product.qty:
            return None
        diff = db_row.qty - cmd_product.qty  # positivo
        list_modifiers: list[ModifierInCorrections] = []
        for row in db_row.modifiers:
            list_modifiers.extend(_map_modifier_flat(row))
        return ProductsInCorrections(
            qty=-diff,
            name=cmd_product.name,
            id=db_row.product_id,
            modifiers=list_modifiers,  # <- snapshot DB
        )
