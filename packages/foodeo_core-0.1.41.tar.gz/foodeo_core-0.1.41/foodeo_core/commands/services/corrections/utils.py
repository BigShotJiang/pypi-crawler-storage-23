from foodeo_core.commands.entities.corrections.corrections_dto import ModifiersDTOForCorrections
from foodeo_core.shared.entities.corrections import ModifierInCorrections

def _map_modifier(modifier: ModifiersDTOForCorrections) -> ModifierInCorrections:
    return ModifierInCorrections(
        id=modifier.id,
        modifiers_id=modifier.modifiers_id,
        modifiers_name=modifier.modifiers_name,
        options_id=modifier.options_id,
        options_name=modifier.options_name,
        modifiers_child_id=modifier.modifiers_child_id,
        modifiers_child_name=modifier.modifiers_child_name,
        options_child_id=modifier.options_child_id,
        options_child_name=modifier.options_child_name,
    )


def _map_modifier_flat(modifier: ModifiersDTOForCorrections) -> list[ModifierInCorrections]:
    return [_map_modifier(modifier)]
