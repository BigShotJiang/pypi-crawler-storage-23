from dataclasses import dataclass
from typing import Optional

from foodeo_core.commands.repositories.interfaces import IRequestsTableRepository
from foodeo_core.dataclasses.result import ResultWithValue
from foodeo_core.shared.entities import ProductInCommand
from foodeo_core.shared.entities.commands import LocalCommand
from foodeo_core.shared.entities.corrections import CorrectionLocalRequest, ProductsInCorrections, ModifierInCorrections
from foodeo_core.shared.enums import RequestEnum, FromClientEnum
from .deleted_products import DeletedProductsNegativeDeltaService
from .interfaces import ICreateCorrectionsFromCommandService
from .modifiers_tree_delta import build_modifiers_tree_negative_delta_service, ModifierDeltaService
from .product_qty_delta import ProductQtyNegativeDeltaService
from ...entities.corrections.corrections_dto import RequestsTableDTOForCorrections


@dataclass(frozen=True)
class CreateCorrectionsFromCommandOrchestrator(ICreateCorrectionsFromCommandService):
    repository: IRequestsTableRepository
    product_qty_service: ProductQtyNegativeDeltaService
    modifiers_tree_service: ModifierDeltaService
    deleted_products_service: DeletedProductsNegativeDeltaService

    def create_corrections(self, command_model: LocalCommand) -> ResultWithValue[CorrectionLocalRequest | None]:
        existing_request_tables_in_database: list[
            RequestsTableDTOForCorrections] = self.repository.get_requests_tables_by_command(command_model.id)
        corrections: CorrectionLocalRequest | None = self._build(command_model, existing_request_tables_in_database)
        return ResultWithValue.success_value(corrections)

    def _build(self, command_model: LocalCommand, existing_request_tables_in_database: list[
        RequestsTableDTOForCorrections]) -> CorrectionLocalRequest | None:
        products_sent: list[ProductInCommand] = command_model.products

        sent_by_row_id: dict[int, ProductInCommand] = {
            p.request_table: p for p in products_sent if p.request_table is not None
        }

        out: list[ProductsInCorrections] = []
        not_found: list[RequestsTableDTOForCorrections] = []

        for db_row in existing_request_tables_in_database:
            cmd_product: ProductInCommand = sent_by_row_id.get(db_row.id)
            if cmd_product is None:
                not_found.append(db_row)
                continue

            # A) delta negativo del qty del producto (snapshot DB modifiers)
            # B) delta negativo del árbol de modifiers/options
            modifiers_delta: list[ModifierInCorrections] = self.modifiers_tree_service.diff(
                db=db_row.modifiers,
                cmd=cmd_product.modifiers,
            )
            prod_delta: Optional[ProductsInCorrections] = self.product_qty_service.build_delta(db_row, cmd_product)

            if prod_delta and modifiers_delta:
                out.append(
                    ProductsInCorrections(
                        qty=prod_delta.qty,
                        name=prod_delta.name,
                        id=prod_delta.id,
                        modifiers=modifiers_delta,
                    )
                )
            elif prod_delta:
                out.append(prod_delta)
            elif modifiers_delta:
                # contrato: para changes de modifiers, el producto va con qty vigente (cmd)
                out.append(
                    ProductsInCorrections(
                        qty=cmd_product.qty,
                        name=cmd_product.name,
                        id=db_row.product_id,
                        modifiers=modifiers_delta,
                    )
                )

        # C) eliminados
        out.extend(self.deleted_products_service.build(not_found))

        if not out:
            return None

        return CorrectionLocalRequest(
            qr=command_model.qr,
            command_guests=command_model.command_guests,
            type=RequestEnum.local,
            command_id=command_model.id,
            from_client=FromClientEnum.web,
            details=command_model.details,
            products=out,
        )


def build_create_corrections_orchestrator(
        repository: IRequestsTableRepository) -> ICreateCorrectionsFromCommandService:
    return CreateCorrectionsFromCommandOrchestrator(
        repository=repository,
        product_qty_service=ProductQtyNegativeDeltaService(),
        modifiers_tree_service=build_modifiers_tree_negative_delta_service(),
        deleted_products_service=DeletedProductsNegativeDeltaService(),
    )
