from typing import Optional

from pydantic import BaseModel, Field


class ModifiersDTOForCorrections(BaseModel):
    modifiers_id: int
    id: Optional[int] = None
    modifiers_name: Optional[str] = None
    options_id: Optional[int] = None
    options_name: Optional[str] = None
    modifiers_child_id: Optional[int] = None
    modifiers_child_name: Optional[str] = None
    options_child_id: Optional[int] = None
    options_child_name: Optional[str] = None
    qty: Optional[int] = None
    qty_child: Optional[int] = None


class RequestsTableDTOForCorrections(BaseModel):
    qty: int
    product_id: Optional[int] = None
    id: int
    modifiers: list[ModifiersDTOForCorrections] = Field(default_factory=list)
    product_name: str
