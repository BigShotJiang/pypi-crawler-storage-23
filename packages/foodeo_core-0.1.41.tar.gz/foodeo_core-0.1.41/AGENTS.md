Para correr los test:
-  source ~/venv/foodeo-core/bin/activate
-  python3 -m unittest

- Este proyecto es la capa de dominio del proyecto Foodeo, por lo tanto, tiene que ser agnóstico de tecnología y no conocer
- detalles ni de base de datos ni nada.
- Tiene que tener una cobertura de test +90% en los servicios
- Es una aproximación a una arquitectura DDD.

Para acceder a Foodeo:
- cd .. & cd foodeo-backend/