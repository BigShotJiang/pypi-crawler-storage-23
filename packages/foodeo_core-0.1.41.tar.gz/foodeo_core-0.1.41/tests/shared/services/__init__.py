# Marks shared services tests as a package for discovery.
