import unittest
from datetime import datetime, timezone

from foodeo_core.shared.enums import FromClient
from foodeo_core.shared.services.audit.context import AuditContext
from foodeo_core.shared.services.audit.core_event import DomainEvent
from foodeo_core.shared.services.audit.event_publisher import CollectingEventPublisher


class TestAuditContext(unittest.TestCase):
    def test_defaults(self) -> None:
        context = AuditContext()

        self.assertIsNone(context.actor_id)
        self.assertIsNone(context.correlation_id)
        self.assertEqual(context.from_client, "web")
        self.assertEqual(context.occurred_at.tzinfo, timezone.utc)
        self.assertEqual(context.metadata, {})

    def test_default_metadata_is_not_shared(self) -> None:
        first = AuditContext()
        second = AuditContext()

        self.assertIsNot(first.metadata, second.metadata)


class TestDomainEvent(unittest.TestCase):
    def test_builds_event_with_audit_context(self) -> None:
        occurred_at = datetime(2026, 2, 16, 12, 0, tzinfo=timezone.utc)
        context = AuditContext(actor_id=10, correlation_id="cid-1", from_client=FromClient.web)

        event = DomainEvent(event_type="request.created", occurred_at=occurred_at, context=context)

        self.assertEqual(event.event_type, "request.created")
        self.assertEqual(event.occurred_at, occurred_at)
        self.assertEqual(event.context, context)

    def test_parses_context_from_dict(self) -> None:
        occurred_at = datetime(2026, 2, 16, 12, 0, tzinfo=timezone.utc)

        event = DomainEvent(
            event_type="request.created",
            occurred_at=occurred_at,
            context={"from_client": FromClient.web, "metadata": {"origin": "test"}},
        )

        self.assertIsInstance(event.context, AuditContext)
        self.assertEqual(event.context.from_client, FromClient.web)
        self.assertEqual(event.context.metadata, {"origin": "test"})


class TestCollectingEventPublisher(unittest.TestCase):
    @staticmethod
    def _build_event(event_type: str, actor_id: int) -> DomainEvent:
        occurred_at = datetime(2026, 2, 16, 12, 0, tzinfo=timezone.utc)
        context = AuditContext(actor_id=actor_id, from_client=FromClient.web)
        return DomainEvent(event_type=event_type, occurred_at=occurred_at, context=context)

    def test_publish_and_pull_keeps_order_and_clears_queue(self) -> None:
        publisher = CollectingEventPublisher()
        first = self._build_event("request.created", actor_id=1)
        second = self._build_event("request.updated", actor_id=2)

        publisher.publish(first)
        publisher.publish(second)

        self.assertEqual(publisher.events, [first, second])
        self.assertEqual(publisher.pull(), [first, second])
        self.assertEqual(publisher.events, [])
        self.assertEqual(publisher.pull(), [])

    def test_events_property_returns_copy(self) -> None:
        publisher = CollectingEventPublisher()
        event = self._build_event("request.created", actor_id=1)
        publisher.publish(event)

        snapshot = publisher.events
        snapshot.clear()

        self.assertEqual(publisher.events, [event])
