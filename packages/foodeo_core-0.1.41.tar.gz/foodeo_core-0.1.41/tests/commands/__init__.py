# Marks commands tests as a package for discovery.
