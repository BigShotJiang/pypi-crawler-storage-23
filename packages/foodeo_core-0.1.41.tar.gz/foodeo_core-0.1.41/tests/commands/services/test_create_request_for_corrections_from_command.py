import unittest
from dataclasses import dataclass
from decimal import Decimal
from typing import Optional

from foodeo_core.commands.entities.corrections.corrections_dto import (
    RequestsTableDTOForCorrections,
    ModifiersDTOForCorrections,
)
from foodeo_core.commands.repositories.interfaces import IRequestsTableRepository
from foodeo_core.commands.services.corrections import build_create_request_for_corrections_service
from foodeo_core.shared.entities import ProductInCommand
from foodeo_core.shared.entities import ProductInRequest
from foodeo_core.shared.entities.irequests import (
    ModifiersRequest,
    IOptionRequest,
    IModifierChildRequest,
    IOptionChildRequest,
)
from foodeo_core.shared.enums import RequestEnum, FromClientEnum


# ---------
# Fakes mínimos para test unitario
# ---------
@dataclass
class FakeLocalCommand:
    id: int
    qr: str
    command_guests: Optional[int]
    details: str
    products: list[ProductInCommand]


class FakeRequestsTableRepository(IRequestsTableRepository):
    def __init__(self, rows: list[
        RequestsTableDTOForCorrections]):
        self._rows = rows

    def get_requests_tables_by_command(self, command_id: int) -> list[
        RequestsTableDTOForCorrections]:
        # En unit tests no usamos command_id, pero lo dejamos por firma.
        return list(self._rows)


# Helpers
def make_request_table_row(
        *,
        row_id: int,
        product_id: int | None,
        qty: int,
        product_name: str = "A",
        modifiers: Optional[list[object]] = None,
) -> RequestsTableDTOForCorrections:
    if modifiers is None:
        return RequestsTableDTOForCorrections(
            id=row_id,
            product_id=product_id,
            qty=qty,
            product_name=product_name,
        )
    return RequestsTableDTOForCorrections(
        id=row_id,
        product_id=product_id,
        qty=qty,
        product_name=product_name,
        modifiers=modifiers,
    )


def make_product_in_command(
        *,
        request_table: Optional[int],
        qty: int,
        name: str = "Prod",
        product_id: Optional[int] = None,
        modifiers: Optional[list[ModifiersRequest]] = None,
) -> ProductInCommand:
    # Nota: ProductInCommand hereda de IProductsRequest, exige varios campos.
    # Completa los mínimos exigidos por tu modelo.
    return ProductInCommand(
        request_table=request_table,
        qty=qty,
        name=name,
        price=Decimal("10"),
        amount=Decimal("10"),
        total_price=Decimal("10"),
        unit_price=Decimal("10"),
        modifiers=modifiers or [],
        id=product_id,  # en tu servicio usas product_id desde RequestTablesModifiersDTOForCorrections, no este id
    )


def make_option_child(option_id: int, qty: int) -> IOptionChildRequest:
    return IOptionChildRequest.model_construct(id=option_id, qty=qty)


def make_modifier_child(child_id: int, options: list[IOptionChildRequest]) -> IModifierChildRequest:
    return IModifierChildRequest.model_construct(id=child_id, options=options)


def make_option(
        option_id: int,
        qty: int,
        modifiers_child: Optional[list[IModifierChildRequest]] = None,
) -> IOptionRequest:
    return IOptionRequest.model_construct(id=option_id, qty=qty, modifiers=modifiers_child or [])


def make_modifier(modifiers_id: int, options: list[IOptionRequest]) -> ModifiersRequest:
    return ModifiersRequest.model_construct(modifiers_id=modifiers_id, options=options)


# ---------
# Tests
# ---------
class TestCreateCorrections(unittest.TestCase):
    def assert_product_in_request(self, p: ProductInRequest, *, qty: int, product_id: int) -> None:
        self.assertEqual(p.qty, qty)
        self.assertEqual(p.id, product_id)

    def test_returns_none_when_no_corrections_needed(self):
        # DB tiene qty=2, command manda qty=2 => no hay diff
        repo = FakeRequestsTableRepository(
            rows=[make_request_table_row(row_id=1, product_id=100, qty=2, product_name="A")]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[make_product_in_command(request_table=1, qty=2, name="A")],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        self.assertIsNone(result.value)

    def test_creates_request_with_qty_diff_when_command_qty_greater(self):
        # DB qty=1, command qty=3 => diff 2
        repo = FakeRequestsTableRepository(
            rows=[make_request_table_row(row_id=1, product_id=100, qty=1, product_name="A")]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="detalle",
            products=[make_product_in_command(request_table=1, qty=3, name="A")],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)

        # Metadata base
        self.assertEqual(req.qr, "qr-1")
        self.assertEqual(req.command_id, 10)
        self.assertEqual(req.type, RequestEnum.local)
        self.assertEqual(req.from_client, FromClientEnum.web)

        # Productos
        self.assertEqual(len(req.products), 1)
        p = req.products[0]
        self.assert_product_in_request(p, qty=2, product_id=100)

    def test_creates_request_with_qty_diff_when_db_product_id_missing(self):
        repo = FakeRequestsTableRepository(
            rows=[make_request_table_row(row_id=1, product_id=None, qty=1, product_name="Especial")]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[make_product_in_command(request_table=1, qty=3, name="Especial")],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.name, "Especial")
        self.assertIsNone(p.id)

    def test_adds_new_product_when_request_table_not_in_db(self):
        repo = FakeRequestsTableRepository(
            rows=[make_request_table_row(row_id=999, product_id=200, qty=1, product_name="A")]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=3,
                    name="Nuevo",
                    product_id=101,
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 3)
        self.assertEqual(p.name, "Nuevo")
        self.assertEqual(p.id, 101)

    def test_ignores_db_rows_not_present_in_command(self):
        # DB tiene una row id=999 que no viene en command => se ignora sin explotar
        repo = FakeRequestsTableRepository(
            rows=[make_request_table_row(row_id=999, product_id=200, qty=1, product_name="A")]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=None,
            details="",
            products=[],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        self.assertIsNone(result.value)

    def test_does_not_create_negative_or_zero_diff_when_command_qty_lower(self):
        # DB qty=5, command qty=3 => no corrección (tu servicio solo agrega)
        repo = FakeRequestsTableRepository(
            rows=[make_request_table_row(row_id=1, product_id=100, qty=5, product_name="A")]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[make_product_in_command(request_table=1, qty=3, name="A")],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        self.assertIsNone(result.value)

    def test_multiple_rows_creates_multiple_corrections(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(row_id=1, product_id=100, qty=1, product_name="A"),
                make_request_table_row(row_id=2, product_id=101, qty=2, product_name="B"),
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=4,
            details="",
            products=[
                make_product_in_command(request_table=1, qty=2, name="A"),  # diff 1
                make_product_in_command(request_table=2, qty=5, name="B"),  # diff 3
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 2)

        # orden no garantizado, comparamos por product_id
        by_id = {p.id: p for p in req.products}
        self.assert_product_in_request(by_id[100], qty=1, product_id=100)
        self.assert_product_in_request(by_id[101], qty=3, product_id=101)

    def test_creates_request_when_only_modifier_option_qty_increases(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            qty=1,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[make_modifier(7, [make_option(70, 3)])],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.id, 100)
        self.assertEqual(p.qty, 2)
        self.assertTrue(p.modifiers)
        self.assertEqual(p.modifiers[0].modifiers_id, 7)
        self.assertEqual(p.modifiers[0].options_id, 70)
        self.assertEqual(p.modifiers[0].qty, 2)

    def test_creates_request_when_new_option_is_added(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            qty=1,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[
                        make_modifier(
                            7,
                            [
                                make_option(70, 1),
                                make_option(71, 2),
                            ],
                        )
                    ],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.id, 100)
        self.assertEqual(len(p.modifiers), 1)
        mod = p.modifiers[0]
        self.assertEqual(mod.modifiers_id, 7)
        self.assertEqual(mod.modifiers_name, "M")
        self.assertEqual(mod.options_id, 71)
        self.assertIsNone(mod.options_name)
        self.assertEqual(mod.qty, 2)

    def test_sums_duplicate_options_in_command(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            qty=1,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[
                        make_modifier(
                            7,
                            [
                                make_option(70, 1),
                                make_option(70, 1),
                            ],
                        )
                    ],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(len(p.modifiers), 1)
        self.assertEqual(p.modifiers[0].options_id, 70)
        self.assertEqual(p.modifiers[0].qty, 1)

    def test_creates_request_when_only_modifier_child_qty_increases(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            modifiers_child_id=700,
                            modifiers_child_name="Child",
                            options_child_id=701,
                            options_child_name="OptChild",
                            qty_child=1,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[
                        make_modifier(
                            7,
                            [
                                make_option(
                                    70,
                                    2,
                                    modifiers_child=[
                                        make_modifier_child(
                                            700,
                                            [make_option_child(701, 4)],
                                        )
                                    ],
                                )
                            ],
                        )
                    ],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.id, 100)
        self.assertEqual(p.qty, 2)
        self.assertTrue(p.modifiers)
        self.assertEqual(p.modifiers[0].modifiers_id, 7)
        self.assertEqual(p.modifiers[0].options_id, 70)
        self.assertEqual(p.modifiers[0].modifiers_child_id, 700)
        self.assertEqual(p.modifiers[0].options_child_id, 701)
        self.assertEqual(p.modifiers[0].qty_child, 3)
        self.assertEqual(p.modifiers[0].qty, 2)

    def test_child_qty_increase_keeps_parent_qty_when_parent_unchanged(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            qty=2,
                        ),
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            modifiers_child_id=700,
                            modifiers_child_name="Child",
                            options_child_id=701,
                            options_child_name="OptChild",
                            qty_child=1,
                        ),
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[
                        make_modifier(
                            7,
                            [
                                make_option(
                                    70,
                                    2,
                                    modifiers_child=[
                                        make_modifier_child(
                                            700,
                                            [make_option_child(701, 3)],
                                        )
                                    ],
                                )
                            ],
                        )
                    ],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.id, 100)
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.modifiers[0].qty_child, 2)
        self.assertEqual(p.modifiers[0].qty, 2)

    def test_creates_request_when_new_child_option_is_added(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            modifiers_child_id=700,
                            modifiers_child_name="Child",
                            options_child_id=701,
                            options_child_name="OptChild",
                            qty_child=1,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[
                        make_modifier(
                            7,
                            [
                                make_option(
                                    70,
                                    1,
                                    modifiers_child=[
                                        make_modifier_child(
                                            700,
                                            [
                                                make_option_child(701, 1),
                                                make_option_child(702, 2),
                                            ],
                                        )
                                    ],
                                )
                            ],
                        )
                    ],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.id, 100)
        self.assertEqual(len(p.modifiers), 1)
        mod = p.modifiers[0]
        self.assertEqual(mod.modifiers_id, 7)
        self.assertEqual(mod.options_id, 70)
        self.assertEqual(mod.modifiers_child_id, 700)
        self.assertEqual(mod.options_child_id, 702)
        self.assertEqual(mod.qty_child, 2)
        self.assertEqual(mod.qty, 1)

    def test_new_child_option_keeps_parent_qty_when_parent_unchanged(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            qty=2,
                        ),
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            modifiers_child_id=700,
                            modifiers_child_name="Child",
                            options_child_id=701,
                            options_child_name="OptChild",
                            qty_child=1,
                        ),
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[
                        make_modifier(
                            7,
                            [
                                make_option(
                                    70,
                                    2,
                                    modifiers_child=[
                                        make_modifier_child(
                                            700,
                                            [
                                                make_option_child(701, 1),
                                                make_option_child(702, 2),
                                            ],
                                        )
                                    ],
                                )
                            ],
                        )
                    ],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.id, 100)
        self.assertEqual(len(p.modifiers), 1)
        mod = p.modifiers[0]
        self.assertEqual(mod.modifiers_id, 7)
        self.assertEqual(mod.options_id, 70)
        self.assertEqual(mod.modifiers_child_id, 700)
        self.assertEqual(mod.options_child_id, 702)
        self.assertEqual(mod.qty_child, 2)
        self.assertEqual(mod.qty, 2)

    def test_creates_request_when_flat_modifier_option_is_added(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        flat_modifier = ModifiersRequest.model_construct(
            modifiers_id=7,
            modifiers_name="M",
            options_id=70,
            options_name="Opt",
            qty=2,
        )

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[flat_modifier],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.id, 100)
        self.assertEqual(len(p.modifiers), 1)
        mod = p.modifiers[0]
        self.assertEqual(mod.modifiers_id, 7)
        self.assertEqual(mod.modifiers_name, "M")
        self.assertEqual(mod.options_id, 70)
        self.assertEqual(mod.options_name, "Opt")
        self.assertEqual(mod.qty, 2)

    def test_creates_request_when_flat_modifier_child_is_added_with_names(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            qty=1,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        flat_modifier = ModifiersRequest.model_construct(
            modifiers_id=7,
            modifiers_name="M",
            options_id=70,
            options_name="Opt",
            modifiers_child_id=700,
            modifiers_child_name="Child",
            options_child_id=702,
            options_child_name="OptChild",
            qty=1,
            qty_child=2,
        )

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[flat_modifier],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.id, 100)
        self.assertEqual(len(p.modifiers), 1)
        mod = p.modifiers[0]
        self.assertEqual(mod.modifiers_id, 7)
        self.assertEqual(mod.modifiers_name, "M")
        self.assertEqual(mod.options_id, 70)
        self.assertEqual(mod.options_name, "Opt")
        self.assertEqual(mod.modifiers_child_id, 700)
        self.assertEqual(mod.modifiers_child_name, "Child")
        self.assertEqual(mod.options_child_id, 702)
        self.assertEqual(mod.options_child_name, "OptChild")
        self.assertEqual(mod.qty, 1)
        self.assertEqual(mod.qty_child, 2)

    def test_creates_request_when_option_and_child_qty_increase(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            qty=1,
                        ),
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            modifiers_child_id=700,
                            modifiers_child_name="Child",
                            options_child_id=701,
                            options_child_name="OptChild",
                            qty_child=1,
                        ),
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[
                        make_modifier(
                            7,
                            [
                                make_option(
                                    70,
                                    3,
                                    modifiers_child=[
                                        make_modifier_child(
                                            700,
                                            [make_option_child(701, 4)],
                                        )
                                    ],
                                )
                            ],
                        )
                    ],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.id, 100)
        self.assertEqual(p.qty, 2)
        self.assertEqual(len(p.modifiers), 2)
        opt = next(m for m in p.modifiers if m.modifiers_id == 7 and m.options_id == 70 and m.options_child_id is None)
        self.assertEqual(opt.qty, 2)
        child = next(
            m for m in p.modifiers
            if m.modifiers_id == 7 and m.options_id == 70 and m.modifiers_child_id == 700 and m.options_child_id == 701
        )
        self.assertEqual(child.qty_child, 3)
        self.assertEqual(child.qty, 2)

    def test_creates_single_line_when_product_qty_and_child_qty_increase(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            modifiers_child_id=700,
                            modifiers_child_name="Child",
                            options_child_id=701,
                            options_child_name="OptChild",
                            qty_child=1,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=4,
                    name="A",
                    modifiers=[
                        make_modifier(
                            7,
                            [
                                make_option(
                                    70,
                                    1,
                                    modifiers_child=[
                                        make_modifier_child(
                                            700,
                                            [make_option_child(701, 3)],
                                        )
                                    ],
                                )
                            ],
                        )
                    ],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.id, 100)
        self.assertEqual(len(p.modifiers), 1)
        self.assertEqual(p.modifiers[0].qty_child, 2)
        self.assertEqual(p.modifiers[0].qty, 1)

    def test_only_increased_child_option_is_included(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            modifiers_child_id=700,
                            modifiers_child_name="Child",
                            options_child_id=701,
                            options_child_name="OptChild",
                            qty_child=1,
                        ),
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            modifiers_child_id=700,
                            modifiers_child_name="Child",
                            options_child_id=702,
                            options_child_name="OptChild2",
                            qty_child=2,
                        ),
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[
                        make_modifier(
                            7,
                            [
                                make_option(
                                    70,
                                    1,
                                    modifiers_child=[
                                        make_modifier_child(
                                            700,
                                            [
                                                make_option_child(701, 3),
                                                make_option_child(702, 2),
                                            ],
                                        )
                                    ],
                                )
                            ],
                        )
                    ],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(len(p.modifiers), 1)
        child = p.modifiers[0]
        self.assertEqual(child.options_child_id, 701)
        self.assertEqual(child.qty_child, 2)
        self.assertEqual(child.qty, 1)

    def test_child_qty_decrease_does_not_create_request(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            modifiers_child_id=700,
                            modifiers_child_name="Child",
                            options_child_id=701,
                            options_child_name="OptChild",
                            qty_child=5,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[
                        make_modifier(
                            7,
                            [
                                make_option(
                                    70,
                                    1,
                                    modifiers_child=[
                                        make_modifier_child(
                                            700,
                                            [make_option_child(701, 3)],
                                        )
                                    ],
                                )
                            ],
                        )
                    ],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        self.assertIsNone(result.value)

    def test_modifier_child_increase_with_product_id_missing(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=None,
                    qty=2,
                    product_name="Especial DB",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            modifiers_child_id=700,
                            modifiers_child_name="Child",
                            options_child_id=701,
                            options_child_name="OptChild",
                            qty_child=1,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="Especial CMD",
                    modifiers=[
                        make_modifier(
                            7,
                            [
                                make_option(
                                    70,
                                    1,
                                    modifiers_child=[
                                        make_modifier_child(
                                            700,
                                            [make_option_child(701, 3)],
                                        )
                                    ],
                                )
                            ],
                        )
                    ],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.name, "Especial CMD")
        self.assertIsNone(p.id)
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.modifiers[0].qty_child, 2)
        self.assertEqual(p.modifiers[0].qty, 1)

    def test_creates_single_line_when_product_and_modifier_option_diff(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=1,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            qty=1,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=3,
                    name="A",
                    modifiers=[make_modifier(7, [make_option(70, 4)])],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.id, 100)
        self.assertEqual(len(p.modifiers), 1)
        self.assertEqual(p.modifiers[0].modifiers_id, 7)
        self.assertEqual(p.modifiers[0].options_id, 70)
        self.assertEqual(p.modifiers[0].qty, 3)

    def test_merges_product_and_modifier_increase_for_same_row(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="Pizza",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="Jamon",
                            options_id=70,
                            options_name="Jamon A",
                            qty=2,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=4,
                    name="Pizza",
                    modifiers=[make_modifier(7, [make_option(70, 4)])],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.name, "Pizza")
        self.assertEqual(p.id, 100)
        self.assertEqual(len(p.modifiers), 1)
        self.assertEqual(p.modifiers[0].modifiers_id, 7)
        self.assertEqual(p.modifiers[0].options_id, 70)
        self.assertEqual(p.modifiers[0].qty, 2)

    def test_creates_request_when_modifier_not_present_in_db(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=9,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            qty=1,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[make_modifier(7, [make_option(70, 3)])],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.id, 100)
        self.assertEqual(len(p.modifiers), 1)
        self.assertEqual(p.modifiers[0].modifiers_id, 7)
        self.assertEqual(p.modifiers[0].options_id, 70)
        self.assertEqual(p.modifiers[0].qty, 3)

    def test_ignores_modifier_option_with_missing_qty_in_db(self):
        repo = FakeRequestsTableRepository(
            rows=[
                make_request_table_row(
                    row_id=1,
                    product_id=100,
                    qty=2,
                    product_name="A",
                    modifiers=[
                        ModifiersDTOForCorrections(
                            modifiers_id=7,
                            modifiers_name="M",
                            options_id=70,
                            options_name="Opt",
                            qty=None,
                        )
                    ],
                )
            ]
        )
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=1,
                    qty=2,
                    name="A",
                    modifiers=[make_modifier(7, [make_option(70, 3)])],
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        self.assertIsNone(result.value)

    def test_adds_new_product_from_frontend_when_no_request_table(self):
        repo = FakeRequestsTableRepository(rows=[])
        service = build_create_request_for_corrections_service(repository=repo)

        cmd = FakeLocalCommand(
            id=10,
            qr="qr-1",
            command_guests=2,
            details="",
            products=[
                make_product_in_command(
                    request_table=None,
                    qty=2,
                    name="Especial",
                    product_id=None,
                )
            ],
        )

        result = service.create_request(cmd)
        self.assertTrue(result.is_success)
        req = result.value
        self.assertIsNotNone(req)
        self.assertEqual(len(req.products), 1)

        p = req.products[0]
        self.assertEqual(p.qty, 2)
        self.assertEqual(p.name, "Especial")
        self.assertIsNone(p.id)
