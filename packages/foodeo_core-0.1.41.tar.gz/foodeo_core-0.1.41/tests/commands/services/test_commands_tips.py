import unittest
from decimal import Decimal

from foodeo_core.commands.entities.modifiers import COMMANDS_TYPES
from foodeo_core.commands.services.commands_tips import CommandTipCalculator
from foodeo_core.shared.entities.commands import TipCalculation
from foodeo_core.shared.enums import TipOptionsEnum


class TestCommandTipCalculator(unittest.TestCase):
    def setUp(self) -> None:
        self.calculator = CommandTipCalculator()

    def test_five_percent_tip(self) -> None:
        tip_model = TipCalculation(
            price=Decimal("10.00"),
            type="local",
            tip_option=TipOptionsEnum.five_percent,
            tip_amount=Decimal("0"),
        )
        tip = self.calculator.calculate_tip(tip_model)
        self.assertEqual(tip, Decimal("0.50"))

    def test_ten_percent_tip_includes_domicile_price(self) -> None:
        tip_model = TipCalculation(
            price=Decimal("10.00"),
            domicile_price=Decimal("2.50"),
            type=COMMANDS_TYPES.DOMICILE,
            tip_option=TipOptionsEnum.ten_percent,
            tip_amount=Decimal("0"),
        )
        tip = self.calculator.calculate_tip(tip_model)
        self.assertEqual(tip, Decimal("1.25"))

    def test_domicile_price_is_ignored_for_non_domicile(self) -> None:
        tip_model = TipCalculation(
            price=Decimal("10.00"),
            domicile_price=Decimal("5.00"),
            type=COMMANDS_TYPES.LOCAL,
            tip_option=TipOptionsEnum.ten_percent,
            tip_amount=Decimal("0"),
        )
        tip = self.calculator.calculate_tip(tip_model)
        self.assertEqual(tip, Decimal("1.00"))

    def test_other_tip_uses_tip_amount_and_rounds(self) -> None:
        tip_model = TipCalculation(
            price=Decimal("10.00"),
            type="local",
            tip_option=TipOptionsEnum.other,
            tip_amount=Decimal("1.235"),
        )
        tip = self.calculator.calculate_tip(tip_model)
        self.assertEqual(tip, Decimal("1.24"))

    def test_no_tip_returns_zero(self) -> None:
        tip_model = TipCalculation(
            price=Decimal("10.00"),
            type="local",
            tip_option=TipOptionsEnum.no_tip,
            tip_amount=Decimal("3.00"),
        )
        tip = self.calculator.calculate_tip(tip_model)
        self.assertEqual(tip, Decimal("0.00"))
