# Marks services tests as a package for discovery.
