# Marks tests as a package so `python -m tests` works.
