"""Shared test fixtures for Colnade test suite."""
