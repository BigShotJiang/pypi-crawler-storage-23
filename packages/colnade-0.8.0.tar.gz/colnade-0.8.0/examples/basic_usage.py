"""Basic usage: schema definition, filter, select, aggregate.

Demonstrates the core Colnade workflow with the Polars backend.
"""

from __future__ import annotations

import tempfile

from colnade import Column, Float64, Schema, UInt64, Utf8
from colnade_polars import from_rows, read_parquet, write_parquet

# ---------------------------------------------------------------------------
# 1. Define schemas — typed column references, verified by the type checker
# ---------------------------------------------------------------------------


class Users(Schema):
    id: Column[UInt64]
    name: Column[Utf8]
    age: Column[UInt64]
    score: Column[Float64]


class UserSummary(Schema):
    name: Column[Utf8]
    score: Column[Float64]


# ---------------------------------------------------------------------------
# 2. Create sample data and write to Parquet
# ---------------------------------------------------------------------------

df = from_rows(
    Users,
    [
        Users.Row(id=1, name="Alice", age=30, score=85.0),
        Users.Row(id=2, name="Bob", age=25, score=92.5),
        Users.Row(id=3, name="Charlie", age=35, score=78.0),
        Users.Row(id=4, name="Diana", age=28, score=95.0),
        Users.Row(id=5, name="Eve", age=40, score=88.0),
    ],
)

with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
    write_parquet(df, f.name)
    parquet_path = f.name

# ---------------------------------------------------------------------------
# 3. Read typed data — the type checker knows df is DataFrame[Users]
# ---------------------------------------------------------------------------

df = read_parquet(parquet_path, Users)
print(f"Read {len(df)} users")
print(f"Schema: {df!r}")
print()

# ---------------------------------------------------------------------------
# 4. Filter — column references are attributes, not strings
# ---------------------------------------------------------------------------

# Users.age is a Column[UInt64] descriptor — misspelling it is a type error
adults = df.filter(Users.age >= 30)
print("Users aged 30+:")
print(adults)
print()

# ---------------------------------------------------------------------------
# 5. Sort with typed sort expressions
# ---------------------------------------------------------------------------

by_score = df.sort(Users.score.desc())
print("Users by score (descending):")
print(by_score)
print()

# ---------------------------------------------------------------------------
# 6. with_columns — compute new values from typed expressions
# ---------------------------------------------------------------------------

doubled = df.with_columns((Users.score * 2).alias(Users.score))
print("Doubled scores:")
print(doubled)
print()

# ---------------------------------------------------------------------------
# 7. Select + cast_schema — bind to an output schema
# ---------------------------------------------------------------------------

summary = df.select(Users.name, Users.score).cast_schema(UserSummary)
print(f"Summary: {summary!r}")
print(summary)
print()

# ---------------------------------------------------------------------------
# 8. Write result
# ---------------------------------------------------------------------------

with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as f:
    write_parquet(summary, f.name)
    print(f"Wrote summary to {f.name}")

print("\nDone!")
