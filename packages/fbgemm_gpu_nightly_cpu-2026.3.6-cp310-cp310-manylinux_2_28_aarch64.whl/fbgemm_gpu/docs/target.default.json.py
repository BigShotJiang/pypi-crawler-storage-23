
{
    "version": "2026.3.6",
    "target": "default",
    "variant": "cpu"
}
