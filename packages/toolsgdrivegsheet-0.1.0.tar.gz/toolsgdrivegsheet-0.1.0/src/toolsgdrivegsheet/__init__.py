"""
toolsgdrivegsheet — Google Drive + Sheets helpers with unified credential resolution.

Usage:
    from toolsgdrivegsheet import gdrive_get_service, list_files
    from toolsgdrivegsheet import gsheet_get_service, read_sheet
    from toolsgdrivegsheet import get_services  # convenience: both at once
    from toolsgdrivegsheet import get_credentials  # resolve creds for external use
"""

from __future__ import annotations

from typing import Any

# Auth (public)
from ._auth import get_credentials

# Drive
from .drive import (
    gdrive_get_service,
    list_files,
    download_file,
    download_file_to_disk,
    download_file_to_csv,
)

# Sheets
from .sheets import (
    gsheet_get_service,
    list_sheet_names,
    read_sheet,
    read_sheet_as_dicts,
    read_all_sheets,
)

__all__ = [
    # Auth
    "get_credentials",
    # Drive
    "gdrive_get_service",
    "list_files",
    "download_file",
    "download_file_to_disk",
    "download_file_to_csv",
    # Sheets
    "gsheet_get_service",
    "list_sheet_names",
    "read_sheet",
    "read_sheet_as_dicts",
    "read_all_sheets",
    # Convenience
    "get_services",
]


def get_services(
    *,
    path_keyfile: str | None = None,
    keyfile_json: dict | None = None,
    credentials: Any | None = None,
    sheets_readonly: bool = True,
) -> tuple:
    """
    Convenience: resolve credentials once, return both service objects.

    Args:
        path_keyfile:     Path to a service account JSON key file.
        keyfile_json:     Parsed service account JSON as dict.
        credentials:      Pre-resolved google credentials object.
        sheets_readonly:  If True (default), Sheets service uses read-only scope.

    Returns:
        (drive_service, sheets_service) tuple.

    Example:
        drive, sheets = get_services(path_keyfile="~/key.json")
    """
    from .drive import SCOPES as DRIVE_SCOPES
    from .sheets import SCOPES_READONLY, SCOPES_READWRITE

    sheets_scopes = SCOPES_READONLY if sheets_readonly else SCOPES_READWRITE
    combined_scopes = list(set(DRIVE_SCOPES + sheets_scopes))

    creds = get_credentials(
        path_keyfile=path_keyfile,
        keyfile_json=keyfile_json,
        credentials=credentials,
        scopes=combined_scopes,
    )

    drive_service = gdrive_get_service(credentials=creds)
    sheets_service = gsheet_get_service(credentials=creds, readonly=sheets_readonly)

    return drive_service, sheets_service
