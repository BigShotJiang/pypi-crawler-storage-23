from __future__ import annotations 

import re
import sys
from datetime import (
    date,
    datetime,
    time
)
from decimal import Decimal 
from enum import Enum 
from typing import (
    Any,
    ClassVar,
    Dict,
    List,
    Literal,
    Optional,
    Union
)

from pydantic import (
    BaseModel,
    ConfigDict,
    Field,
    RootModel,
    field_validator
)


metamodel_version = "None"
version = "None"


class ConfiguredBaseModel(BaseModel):
    model_config = ConfigDict(
        validate_assignment = True,
        validate_default = True,
        extra = "forbid",
        arbitrary_types_allowed = True,
        use_enum_values = True,
        strict = False,
    )
    pass




class LinkMLMeta(RootModel):
    root: Dict[str, Any] = {}
    model_config = ConfigDict(frozen=True)

    def __getattr__(self, key:str):
        return getattr(self.root, key)

    def __getitem__(self, key:str):
        return self.root[key]

    def __setitem__(self, key:str, value):
        self.root[key] = value

    def __contains__(self, key:str) -> bool:
        return key in self.root


linkml_meta = LinkMLMeta({'default_prefix': 'lara',
     'default_range': 'string',
     'id': 'https://w3id.org/lara/lara_django_organisms_store',
     'imports': ['linkml:types'],
     'name': 'lara_django_organisms_store',
     'prefixes': {'lara': {'prefix_prefix': 'lara',
                           'prefix_reference': 'http://w3id.org/lara/'},
                  'linkml': {'prefix_prefix': 'linkml',
                             'prefix_reference': 'https://w3id.org/linkml/'},
                  'oso': {'prefix_prefix': 'oso',
                          'prefix_reference': 'http://w3id.org/oso/'}},
     'source_file': 'lara_django_organisms_store_schema.yaml'} )


class Entity(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Entity'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    pass


class Organism(ConfiguredBaseModel):
    """
    <class 'lara_django_organisms.models.Organism'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    pass


class Location(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Location'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    pass


class Tag(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Tag'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    pass


class ExternalResource(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.ExternalResource'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    pass


class DataType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.DataType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    pass


class Namespace(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Namespace'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    pass


class Currency(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.Currency'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    pass


class MediaType(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.MediaType'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    pass


class ItemStatus(ConfiguredBaseModel):
    """
    <class 'lara_django_base.models.ItemStatus'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    pass


class Group(ConfiguredBaseModel):
    """
    <class 'lara_django_people.models.Group'>
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    pass


class ExtraData(ConfiguredBaseModel):
    """
    \" This class can be used to extend data, by extra information,
        e.g. more telephone numbers, customer numbers, ...
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:lara_django_organisms_store/extradata',
         'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    extradata_id: Optional[str] = Field(None, description="""ExtraData - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'extradata_id',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:extradata/extradata_id'} })
    data_type: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'data_type',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:extradata/data_type'} })
    namespace: str = Field(..., description="""namespace of data""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:extradata/namespace'} })
    name_display: Optional[str] = Field(None, description="""Human readable display name or title of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:extradata/name_display'} })
    name: Optional[str] = Field(None, description="""name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:extradata/name'} })
    name_full: Optional[str] = Field(None, description="""full name of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'name_full',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:extradata/name_full'} })
    version: Optional[str] = Field(None, description="""version of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'version',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:extradata/version'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of all data (JSON and XML)""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['ExtraData', 'OrganismInstance'],
         'slot_uri': 'lara:extradata/hash_sha256'} })
    data_json: Optional[str] = Field(None, description="""generic JSON field""", json_schema_extra = { "linkml_meta": {'alias': 'data_json',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:extradata/data_json'} })
    media_type: Optional[str] = Field(None, description="""IANA media type of extra data file""", json_schema_extra = { "linkml_meta": {'alias': 'media_type',
         'domain_of': ['ExtraData'],
         'slot_uri': 'lara:extradata/media_type'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'OrganismInstance', 'OrganismOrder'],
         'slot_uri': 'lara:extradata/iri'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - this can be used to link the data to external locations""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData', 'OrganismInstance'],
         'slot_uri': 'lara:extradata/url'} })
    datetime_created: Optional[str] = Field(None, description="""date and time when data was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:extradata/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:extradata/datetime_last_modified'} })
    description: Optional[str] = Field(None, description="""description of extra data""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData', 'OrganismInstance', 'OrganismInstancesSubset'],
         'slot_uri': 'lara:extradata/description'} })
    file: Optional[str] = Field(None, description="""rel. path/filename""", json_schema_extra = { "linkml_meta": {'alias': 'file', 'domain_of': ['ExtraData'], 'slot_uri': 'lara:extradata/file'} })


class OrganismInstance(ConfiguredBaseModel):
    """
    \" Organism Instance Model, e.g. a specific plant, animal, fungus, bacteria / strain,  ...
        it can also be used to model a set of organisms instances of similar kind, e.g. a population, a colony, a group, ...
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:lara_django_organisms_store/organisminstance',
         'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    namespace: Optional[str] = Field(None, description="""namespace of item""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organisminstance/namespace'} })
    name_display: Optional[str] = Field(None, description="""Human readable name of item, can contain spaces""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organisminstance/name_display'} })
    name: Optional[str] = Field(None, description="""short item name for accessing the item, spaces are replaced by _""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organisminstance/name'} })
    barcode: Optional[str] = Field(None, description="""text representation of a barcode of the item.""", json_schema_extra = { "linkml_meta": {'alias': 'barcode',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/barcode'} })
    barcode_json: Optional[str] = Field(None, description="""Advanced barcodes in JSON for multiple barcode representations, like QR codes etc.""", json_schema_extra = { "linkml_meta": {'alias': 'barcode_json',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/barcode_json'} })
    url: Optional[str] = Field(None, description="""Universal Resource Locator - URL""", json_schema_extra = { "linkml_meta": {'alias': 'url',
         'domain_of': ['ExtraData', 'OrganismInstance'],
         'slot_uri': 'lara:organisminstance/url'} })
    pid: Optional[str] = Field(None, description="""Persistent Identifier URI""", json_schema_extra = { "linkml_meta": {'alias': 'pid',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/pid'} })
    pac_id: Optional[str] = Field(None, description="""Publicly Addressable Content IDentifier is a globally unique identifier that operates independently of a central registry.""", json_schema_extra = { "linkml_meta": {'alias': 'pac_id',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/pac_id'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation.""", json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'OrganismInstance', 'OrganismOrder'],
         'slot_uri': 'lara:organisminstance/iri'} })
    registration_no: Optional[str] = Field(None, description="""can be used for internal registrations in a labstore""", json_schema_extra = { "linkml_meta": {'alias': 'registration_no',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/registration_no'} })
    vendor: Optional[str] = Field(None, description="""vendor of the device""", json_schema_extra = { "linkml_meta": {'alias': 'vendor',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/vendor'} })
    product_id: Optional[str] = Field(None, description="""vendor product id""", json_schema_extra = { "linkml_meta": {'alias': 'product_id',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/product_id'} })
    serial_no: Optional[str] = Field(None, description="""part/devices serial number""", json_schema_extra = { "linkml_meta": {'alias': 'serial_no',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/serial_no'} })
    service_no: Optional[str] = Field(None, description="""service number or tag""", json_schema_extra = { "linkml_meta": {'alias': 'service_no',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/service_no'} })
    datetime_manufacturing: Optional[str] = Field(None, description="""date of manufaction""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_manufacturing',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/datetime_manufacturing'} })
    price: Optional[float] = Field(None, description="""price of the part in default currency/EURO""", json_schema_extra = { "linkml_meta": {'alias': 'price',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/price'} })
    currency: Optional[str] = Field(None, description="""currency of the item price""", json_schema_extra = { "linkml_meta": {'alias': 'currency',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/currency'} })
    charges: Optional[str] = Field(None, description="""charges for the item, like toll, but also discounts ...""", json_schema_extra = { "linkml_meta": {'alias': 'charges',
         'domain_of': ['OrganismInstance', 'OrganismOrderItem', 'OrganismOrder'],
         'slot_uri': 'lara:organisminstance/charges'} })
    datetime_purchase: Optional[str] = Field(None, description="""Date of item purchase""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_purchase',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/datetime_purchase'} })
    datetime_delivery: Optional[str] = Field(None, description="""Date of Item delivery = inventarisation date""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_delivery',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/datetime_delivery'} })
    datetime_end_of_warranty: Optional[str] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'datetime_end_of_warranty',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/datetime_end_of_warranty'} })
    amount: Optional[int] = Field(None, description="""amount of items""", json_schema_extra = { "linkml_meta": {'alias': 'amount',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/amount'} })
    location: Optional[str] = Field(None, description="""location of container""", json_schema_extra = { "linkml_meta": {'alias': 'location',
         'domain_of': ['OrganismInstance', 'OrganismsLocalStore'],
         'slot_uri': 'lara:organisminstance/location'} })
    storage_info: Optional[str] = Field(None, description="""storage information, like temperature, humidity, light,  date opened, date_best_before  ...""", json_schema_extra = { "linkml_meta": {'alias': 'storage_info',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/storage_info'} })
    safety_info: Optional[str] = Field(None, description="""safety information, like hazard classes, statements, ...""", json_schema_extra = { "linkml_meta": {'alias': 'safety_info',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/safety_info'} })
    legal_info: Optional[str] = Field(None, description="""legal information, like restrictions, licenses, origins of organisms,  ...""", json_schema_extra = { "linkml_meta": {'alias': 'legal_info',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/legal_info'} })
    status: Optional[str] = Field(None, description="""status of item""", json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['OrganismInstance', 'OrganismOrderItem'],
         'slot_uri': 'lara:organisminstance/status'} })
    hash_sha256: Optional[str] = Field(None, description="""SHA256 hash of item for identity/duplicate checking""", json_schema_extra = { "linkml_meta": {'alias': 'hash_sha256',
         'domain_of': ['ExtraData', 'OrganismInstance'],
         'slot_uri': 'lara:organisminstance/hash_sha256'} })
    color: Optional[str] = Field(None, description="""GUI colour representation of the item""", json_schema_extra = { "linkml_meta": {'alias': 'color',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/color'} })
    description: Optional[str] = Field(None, description="""description of part instance""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData', 'OrganismInstance', 'OrganismInstancesSubset'],
         'slot_uri': 'lara:organisminstance/description'} })
    hardware_config: Optional[str] = Field(None, description="""Configuration of the item hardware setup, like connection schemata, wiring, tubing, ...""", json_schema_extra = { "linkml_meta": {'alias': 'hardware_config',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/hardware_config'} })
    software_config: Optional[str] = Field(None, description="""(Internal) Software/Firmware configuration of the item, like interface setup,ports, DNS, IP, MAC, initialisation parameters, SiLA, OPC-UA configuration, ... """, json_schema_extra = { "linkml_meta": {'alias': 'software_config',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/software_config'} })
    datetime_last_modified: Optional[str] = Field(None, description="""date and time when data was last modified""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organisminstance/datetime_last_modified'} })
    organisminstance_id: Optional[str] = Field(None, description="""OrganismInstance - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'organisminstance_id',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/organisminstance_id'} })
    organism: str = Field(..., description="""organism instance is of this organism""", json_schema_extra = { "linkml_meta": {'alias': 'organism',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/organism'} })
    sex: Optional[str] = Field(None, description="""most common (if multiple) sex of organism instance""", json_schema_extra = { "linkml_meta": {'alias': 'sex',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/sex'} })
    hybrid: Optional[bool] = Field(None, description="""is this organism instance a hybrid?""", json_schema_extra = { "linkml_meta": {'alias': 'hybrid',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/hybrid'} })
    chimeric: Optional[bool] = Field(None, description="""is this organism instance a chimera?""", json_schema_extra = { "linkml_meta": {'alias': 'chimeric',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/chimeric'} })
    traits: Optional[str] = Field(None, description="""individual traits or features of this organism instance""", json_schema_extra = { "linkml_meta": {'alias': 'traits',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/traits'} })
    genome: Optional[str] = Field(None, description="""URL to genome of this organism instance""", json_schema_extra = { "linkml_meta": {'alias': 'genome',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/genome'} })
    habitat: Optional[str] = Field(None, description="""habitat of this organism instance""", json_schema_extra = { "linkml_meta": {'alias': 'habitat',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/habitat'} })
    image: Optional[str] = Field(None, description="""rel. path/filename to image""", json_schema_extra = { "linkml_meta": {'alias': 'image',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/image'} })
    users: Optional[List[str]] = Field(None, description="""people, who are using and taking care of this item""", json_schema_extra = { "linkml_meta": {'alias': 'users',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/users'} })
    entities_responsible: Optional[List[str]] = Field(None, description="""entities who are mainly responsible for this item""", json_schema_extra = { "linkml_meta": {'alias': 'entities_responsible',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/entities_responsible'} })
    entities_own: Optional[List[str]] = Field(None, description="""entities, who are owning this item""", json_schema_extra = { "linkml_meta": {'alias': 'entities_own',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/entities_own'} })
    groups: Optional[List[str]] = Field(None, description="""groups of users/entities who can access / and or use this item""", json_schema_extra = { "linkml_meta": {'alias': 'groups',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/groups'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['OrganismInstance', 'OrganismInstancesSubset'],
         'slot_uri': 'lara:organisminstance/tags'} })
    resources_external: Optional[List[str]] = Field(None, description="""external resources, like literature, websites, manuals, ...""", json_schema_extra = { "linkml_meta": {'alias': 'resources_external',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/resources_external'} })
    organism_instances: Optional[List[str]] = Field(None, description="""parent or compound organism instances of this organism instance, e.g. hybrid, chimera, a colony, a (small) population """, json_schema_extra = { "linkml_meta": {'alias': 'organism_instances',
         'domain_of': ['OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organisminstance/organism_instances'} })
    genomes: Optional[List[str]] = Field(None, description="""genomes of this organism instance""", json_schema_extra = { "linkml_meta": {'alias': 'genomes',
         'domain_of': ['OrganismInstance'],
         'slot_uri': 'lara:organisminstance/genomes'} })
    data_extra: Optional[List[str]] = Field(None, description="""extra data""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['OrganismInstance', 'OrganismOrderItem', 'OrganismOrder'],
         'slot_uri': 'lara:organisminstance/data_extra'} })


class OrganismInstancesSubset(ConfiguredBaseModel):
    """
    \" User or group defined subset of organisms \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:lara_django_organisms_store/organisminstancessubset',
         'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    namespace: Optional[str] = Field(None, description="""namespace of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organisminstancessubset/namespace'} })
    name_display: Optional[str] = Field(None, description="""display name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organisminstancessubset/name_display'} })
    name: Optional[str] = Field(None, description="""name of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organisminstancessubset/name'} })
    user: Optional[str] = Field(None, description="""user who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'user',
         'domain_of': ['OrganismInstancesSubset'],
         'slot_uri': 'lara:organisminstancessubset/user'} })
    group: Optional[str] = Field(None, description="""group who created the subset""", json_schema_extra = { "linkml_meta": {'alias': 'group',
         'domain_of': ['OrganismInstancesSubset'],
         'slot_uri': 'lara:organisminstancessubset/group'} })
    description: Optional[str] = Field(None, description="""description of the subset""", json_schema_extra = { "linkml_meta": {'alias': 'description',
         'domain_of': ['ExtraData', 'OrganismInstance', 'OrganismInstancesSubset'],
         'slot_uri': 'lara:organisminstancessubset/description'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last modification of the selection""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organisminstancessubset/datetime_last_modified'} })
    organisminstancessubset_id: Optional[str] = Field(None, description="""OrganismInstancesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'organisminstancessubset_id',
         'domain_of': ['OrganismInstancesSubset'],
         'slot_uri': 'lara:organisminstancessubset/organisminstancessubset_id'} })
    tags: Optional[List[str]] = Field(None, description="""tags""", json_schema_extra = { "linkml_meta": {'alias': 'tags',
         'domain_of': ['OrganismInstance', 'OrganismInstancesSubset'],
         'slot_uri': 'lara:organisminstancessubset/tags'} })
    organism_instances: Optional[List[str]] = Field(None, description="""organisms in subset""", json_schema_extra = { "linkml_meta": {'alias': 'organism_instances',
         'domain_of': ['OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organisminstancessubset/organism_instances'} })


class OrderedOrganismsInstanceOrganismsInstancesSubset(ConfiguredBaseModel):
    """
    \" Through model for the many-to-many relationship between OrganismsInstancesSubset and OrganismInstance.
        This class can be used to store the order of organisms in a subset
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:lara_django_organisms_store/orderedorganismsinstanceorganismsinstancessubset',
         'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    orderedorganismsinstanceorganisminstancessubset_id: Optional[str] = Field(None, description="""OrderedOrganismsInstanceOrganismsInstancesSubset - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'orderedorganismsinstanceorganisminstancessubset_id',
         'domain_of': ['OrderedOrganismsInstanceOrganismsInstancesSubset'],
         'slot_uri': 'lara:orderedorganismsinstanceorganismsinstancessubset/orderedorganismsinstanceorganisminstancessubset_id'} })
    organism_instance: str = Field(..., description="""organism instance in the subset""", json_schema_extra = { "linkml_meta": {'alias': 'organism_instance',
         'domain_of': ['OrderedOrganismsInstanceOrganismsInstancesSubset',
                       'OrganismOrderItem'],
         'slot_uri': 'lara:orderedorganismsinstanceorganismsinstancessubset/organism_instance'} })
    organism_instances_subset: str = Field(..., description="""subset of organism instances""", json_schema_extra = { "linkml_meta": {'alias': 'organism_instances_subset',
         'domain_of': ['OrderedOrganismsInstanceOrganismsInstancesSubset'],
         'slot_uri': 'lara:orderedorganismsinstanceorganismsinstancessubset/organism_instances_subset'} })
    order: int = Field(..., description="""order of organism instance in subset""", json_schema_extra = { "linkml_meta": {'alias': 'order',
         'domain_of': ['OrderedOrganismsInstanceOrganismsInstancesSubset'],
         'slot_uri': 'lara:orderedorganismsinstanceorganismsinstancessubset/order'} })


class OrganismOrderItem(ConfiguredBaseModel):
    """
    \" Organism Order Item Model for storing device-order-items, \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:lara_django_organisms_store/organismorderitem',
         'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    position: Optional[int] = Field(None, description="""position/order of this item in basket / order""", json_schema_extra = { "linkml_meta": {'alias': 'position',
         'domain_of': ['OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/position'} })
    quantity: int = Field(..., json_schema_extra = { "linkml_meta": {'alias': 'quantity',
         'domain_of': ['OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/quantity'} })
    item_price_net: float = Field(..., description="""net price for this item""", json_schema_extra = { "linkml_meta": {'alias': 'item_price_net',
         'domain_of': ['OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/item_price_net'} })
    item_price_gross: Optional[float] = Field(None, description="""gross price for this item""", json_schema_extra = { "linkml_meta": {'alias': 'item_price_gross',
         'domain_of': ['OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/item_price_gross'} })
    item_transport_price: Optional[float] = Field(None, description="""transport / shipping price for this item""", json_schema_extra = { "linkml_meta": {'alias': 'item_transport_price',
         'domain_of': ['OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/item_transport_price'} })
    item_price_tax: Optional[float] = Field(None, description="""tax rate for this item""", json_schema_extra = { "linkml_meta": {'alias': 'item_price_tax',
         'domain_of': ['OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/item_price_tax'} })
    item_toll: Optional[float] = Field(None, description="""toll for this item""", json_schema_extra = { "linkml_meta": {'alias': 'item_toll',
         'domain_of': ['OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/item_toll'} })
    toll_number: Optional[str] = Field(None, description="""description of data type""", json_schema_extra = { "linkml_meta": {'alias': 'toll_number',
         'domain_of': ['OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/toll_number'} })
    item_discount: Optional[float] = Field(None, description="""discount for this item""", json_schema_extra = { "linkml_meta": {'alias': 'item_discount',
         'domain_of': ['OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/item_discount'} })
    charges: Optional[str] = Field(None, description="""charges for the item, like toll, but also discounts ...""", json_schema_extra = { "linkml_meta": {'alias': 'charges',
         'domain_of': ['OrganismInstance', 'OrganismOrderItem', 'OrganismOrder'],
         'slot_uri': 'lara:organismorderitem/charges'} })
    total_price_net: float = Field(..., description="""total price for this item""", json_schema_extra = { "linkml_meta": {'alias': 'total_price_net',
         'domain_of': ['OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/total_price_net'} })
    provider: Optional[str] = Field(None, description="""provider / company the item was ordered at""", json_schema_extra = { "linkml_meta": {'alias': 'provider',
         'domain_of': ['OrganismOrderItem', 'OrganismOrder'],
         'slot_uri': 'lara:organismorderitem/provider'} })
    status: Optional[str] = Field(None, description="""status of the order item - can be used to mark the item as ordered, requested, quote, arrived delivered, invoiced, paid, ...""", json_schema_extra = { "linkml_meta": {'alias': 'status',
         'domain_of': ['OrganismInstance', 'OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/status'} })
    organismorderitem_id: Optional[str] = Field(None, description="""OrganismOrderItem - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'organismorderitem_id',
         'domain_of': ['OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/organismorderitem_id'} })
    organism_instance: str = Field(..., json_schema_extra = { "linkml_meta": {'alias': 'organism_instance',
         'domain_of': ['OrderedOrganismsInstanceOrganismsInstancesSubset',
                       'OrganismOrderItem'],
         'slot_uri': 'lara:organismorderitem/organism_instance'} })
    data_extra: Optional[List[str]] = Field(None, description="""additional data for this order item""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['OrganismInstance', 'OrganismOrderItem', 'OrganismOrder'],
         'slot_uri': 'lara:organismorderitem/data_extra'} })


class OrganismWishlist(ConfiguredBaseModel):
    """
    \" Organism Wishlist Model for storing device-wishlists, \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:lara_django_organisms_store/organismwishlist',
         'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    namespace: Optional[str] = Field(None, description="""namespace of the basket""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismwishlist/namespace'} })
    name_display: Optional[str] = Field(None, description="""Human readable name of basket, can contain spaces""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismwishlist/name_display'} })
    name: Optional[str] = Field(None, description="""Name of the basket without spaces and special characters, for accessing the basket""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismwishlist/name'} })
    entity: Optional[str] = Field(None, description="""entity owning the basket""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['OrganismWishlist', 'OrganismBasket', 'OrganismsLocalStore'],
         'slot_uri': 'lara:organismwishlist/entity'} })
    datetime_created: Optional[str] = Field(None, description="""datetime when the basket was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismwishlist/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last changes of the basket""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismwishlist/datetime_last_modified'} })
    organismwishlist_id: Optional[str] = Field(None, description="""OrganismWishlist - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'organismwishlist_id',
         'domain_of': ['OrganismWishlist'],
         'slot_uri': 'lara:organismwishlist/organismwishlist_id'} })
    organisms_wish: Optional[List[str]] = Field(None, description="""organisms in wishlist""", json_schema_extra = { "linkml_meta": {'alias': 'organisms_wish',
         'domain_of': ['OrganismWishlist'],
         'slot_uri': 'lara:organismwishlist/organisms_wish'} })


class OrganismBasket(ConfiguredBaseModel):
    """
    \" Organism Basket Model for storing organism-baskets, \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:lara_django_organisms_store/organismbasket',
         'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    namespace: Optional[str] = Field(None, description="""namespace of the basket""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismbasket/namespace'} })
    name_display: Optional[str] = Field(None, description="""Human readable name of basket, can contain spaces""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismbasket/name_display'} })
    name: Optional[str] = Field(None, description="""Name of the basket without spaces and special characters, for accessing the basket""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismbasket/name'} })
    entity: Optional[str] = Field(None, description="""entity owning the basket""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['OrganismWishlist', 'OrganismBasket', 'OrganismsLocalStore'],
         'slot_uri': 'lara:organismbasket/entity'} })
    datetime_created: Optional[str] = Field(None, description="""datetime when the basket was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismbasket/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last changes of the basket""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismbasket/datetime_last_modified'} })
    organismbasket_id: Optional[str] = Field(None, description="""OrganismBasket - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'organismbasket_id',
         'domain_of': ['OrganismBasket'],
         'slot_uri': 'lara:organismbasket/organismbasket_id'} })
    organism_order_items: Optional[List[str]] = Field(None, description="""organism in basket""", json_schema_extra = { "linkml_meta": {'alias': 'organism_order_items',
         'domain_of': ['OrganismBasket', 'OrganismOrder'],
         'slot_uri': 'lara:organismbasket/organism_order_items'} })


class OrganismOrder(ConfiguredBaseModel):
    """
    \" Organism Order Model for storing organism-orders, \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:lara_django_organisms_store/organismorder',
         'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    namespace: Optional[str] = Field(None, description="""namespace of order """, json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismorder/namespace'} })
    name_display: Optional[str] = Field(None, description="""short, human readable title of order, can contain whitespaces""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismorder/name_display'} })
    name: Optional[str] = Field(None, description="""short name of order without whitespaces and special characters""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismorder/name'} })
    order_id_internal: Optional[str] = Field(None, description="""internal id / number of order""", json_schema_extra = { "linkml_meta": {'alias': 'order_id_internal',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_id_internal'} })
    order_id_external: Optional[str] = Field(None, description="""external id / number of order""", json_schema_extra = { "linkml_meta": {'alias': 'order_id_external',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_id_external'} })
    order_barcode: Optional[str] = Field(None, description="""barcode of order, can be, e.g., used for tracking or in-house delivery.""", json_schema_extra = { "linkml_meta": {'alias': 'order_barcode',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_barcode'} })
    order_barcode_json: Optional[str] = Field(None, description="""Advanced barcodes in JSON for multiple barcode representations, like QR codes etc.""", json_schema_extra = { "linkml_meta": {'alias': 'order_barcode_json',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_barcode_json'} })
    iri: Optional[str] = Field(None, description="""International Resource Identifier - IRI: is used for semantic representation """, json_schema_extra = { "linkml_meta": {'alias': 'iri',
         'domain_of': ['ExtraData', 'OrganismInstance', 'OrganismOrder'],
         'slot_uri': 'lara:organismorder/iri'} })
    datetime_order: Optional[str] = Field(None, description="""date of order""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_order',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/datetime_order'} })
    entity_ordered: Optional[str] = Field(None, description="""entity who ordered the item""", json_schema_extra = { "linkml_meta": {'alias': 'entity_ordered',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/entity_ordered'} })
    group_ordered: Optional[str] = Field(None, description="""group who ordered the item""", json_schema_extra = { "linkml_meta": {'alias': 'group_ordered',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/group_ordered'} })
    entity_ordering: Optional[str] = Field(None, description="""entity who is ordering the item (from an external resource like a company)""", json_schema_extra = { "linkml_meta": {'alias': 'entity_ordering',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/entity_ordering'} })
    group_ordering: Optional[str] = Field(None, description="""group who is ordering the item (from an external resource like a company)""", json_schema_extra = { "linkml_meta": {'alias': 'group_ordering',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/group_ordering'} })
    provider: Optional[str] = Field(None, description="""provider / company providing the order.""", json_schema_extra = { "linkml_meta": {'alias': 'provider',
         'domain_of': ['OrganismOrderItem', 'OrganismOrder'],
         'slot_uri': 'lara:organismorder/provider'} })
    order_quote_id: Optional[str] = Field(None, description="""quote id of order""", json_schema_extra = { "linkml_meta": {'alias': 'order_quote_id',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_quote_id'} })
    datetime_order_quote: Optional[str] = Field(None, description="""date of latest quote""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_order_quote',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/datetime_order_quote'} })
    order_invoice_id: Optional[str] = Field(None, description="""invoice id of order""", json_schema_extra = { "linkml_meta": {'alias': 'order_invoice_id',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_invoice_id'} })
    datetime_order_invoice: Optional[str] = Field(None, description="""date of latest invoice""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_order_invoice',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/datetime_order_invoice'} })
    transport_company: Optional[str] = Field(None, description="""company transport the item""", json_schema_extra = { "linkml_meta": {'alias': 'transport_company',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/transport_company'} })
    transport_tracking_id: Optional[str] = Field(None, description="""tracking ID of transport.""", json_schema_extra = { "linkml_meta": {'alias': 'transport_tracking_id',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/transport_tracking_id'} })
    transport_price: Optional[float] = Field(None, description="""price of transport / shipping""", json_schema_extra = { "linkml_meta": {'alias': 'transport_price',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/transport_price'} })
    budget_url: Optional[str] = Field(None, description="""Link to budget""", json_schema_extra = { "linkml_meta": {'alias': 'budget_url',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/budget_url'} })
    datetime_order_pay: Optional[str] = Field(None, description="""date of order payment""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_order_pay',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/datetime_order_pay'} })
    order_total_price_net: Optional[float] = Field(None, description="""total price of order net""", json_schema_extra = { "linkml_meta": {'alias': 'order_total_price_net',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_total_price_net'} })
    order_total_price_gross: Optional[float] = Field(None, description="""total price of order gross""", json_schema_extra = { "linkml_meta": {'alias': 'order_total_price_gross',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_total_price_gross'} })
    order_total_price_tax: Optional[float] = Field(None, description="""total price of order TAX/VAT""", json_schema_extra = { "linkml_meta": {'alias': 'order_total_price_tax',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_total_price_tax'} })
    order_total_price_toll: Optional[float] = Field(None, description="""total price of order toll""", json_schema_extra = { "linkml_meta": {'alias': 'order_total_price_toll',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_total_price_toll'} })
    order_currency: Optional[str] = Field(None, description="""currency of order total price""", json_schema_extra = { "linkml_meta": {'alias': 'order_currency',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_currency'} })
    order_status: Optional[str] = Field(None, description="""state of the order, like ordered, requested, quote, arrived delivered, invoiced, paid, ...""", json_schema_extra = { "linkml_meta": {'alias': 'order_status',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_status'} })
    charges: Optional[str] = Field(None, description="""charges for the order, like toll, but also discounts ...""", json_schema_extra = { "linkml_meta": {'alias': 'charges',
         'domain_of': ['OrganismInstance', 'OrganismOrderItem', 'OrganismOrder'],
         'slot_uri': 'lara:organismorder/charges'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last changes of the order""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismorder/datetime_last_modified'} })
    organismorder_id: Optional[str] = Field(None, description="""OrganismOrder - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'organismorder_id',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/organismorder_id'} })
    organism_order_items: Optional[List[str]] = Field(None, description="""organisms in order""", json_schema_extra = { "linkml_meta": {'alias': 'organism_order_items',
         'domain_of': ['OrganismBasket', 'OrganismOrder'],
         'slot_uri': 'lara:organismorder/organism_order_items'} })
    order_quotes: Optional[List[str]] = Field(None, description="""Information about quotes for this order, like PDFs, Images, URLs, ...""", json_schema_extra = { "linkml_meta": {'alias': 'order_quotes',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_quotes'} })
    order_invoices: Optional[List[str]] = Field(None, description="""Information about invoices for this order, like PDFs, Images, URLs, ...""", json_schema_extra = { "linkml_meta": {'alias': 'order_invoices',
         'domain_of': ['OrganismOrder'],
         'slot_uri': 'lara:organismorder/order_invoices'} })
    data_extra: Optional[List[str]] = Field(None, description="""additional data for this order""", json_schema_extra = { "linkml_meta": {'alias': 'data_extra',
         'domain_of': ['OrganismInstance', 'OrganismOrderItem', 'OrganismOrder'],
         'slot_uri': 'lara:organismorder/data_extra'} })


class OrganismsLocalStore(ConfiguredBaseModel):
    """
    \" Organism LocalStore Model for storing organism-local-stores,
        e.g. a local store of a lab, a company, a university, etc.
    \"
    """
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'class_uri': 'lara:lara_django_organisms_store/organismslocalstore',
         'from_schema': 'https://w3id.org/lara/lara_django_organisms_store'})

    namespace: Optional[str] = Field(None, description="""namespace of the basket""", json_schema_extra = { "linkml_meta": {'alias': 'namespace',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismslocalstore/namespace'} })
    name_display: Optional[str] = Field(None, description="""Human readable name of basket, can contain spaces""", json_schema_extra = { "linkml_meta": {'alias': 'name_display',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismslocalstore/name_display'} })
    name: Optional[str] = Field(None, description="""Name of the basket without spaces and special characters, for accessing the basket""", json_schema_extra = { "linkml_meta": {'alias': 'name',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismslocalstore/name'} })
    entity: Optional[str] = Field(None, description="""entity owning the basket""", json_schema_extra = { "linkml_meta": {'alias': 'entity',
         'domain_of': ['OrganismWishlist', 'OrganismBasket', 'OrganismsLocalStore'],
         'slot_uri': 'lara:organismslocalstore/entity'} })
    datetime_created: Optional[str] = Field(None, description="""datetime when the basket was created""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_created',
         'domain_of': ['ExtraData',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismslocalstore/datetime_created'} })
    datetime_last_modified: Optional[str] = Field(None, description="""datetime of last changes of the basket""", json_schema_extra = { "linkml_meta": {'alias': 'datetime_last_modified',
         'domain_of': ['ExtraData',
                       'OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismWishlist',
                       'OrganismBasket',
                       'OrganismOrder',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismslocalstore/datetime_last_modified'} })
    organismlocalstore_id: Optional[str] = Field(None, description="""OrganismsLocalStore - primary key (UUID)""", json_schema_extra = { "linkml_meta": {'alias': 'organismlocalstore_id',
         'domain_of': ['OrganismsLocalStore'],
         'slot_uri': 'lara:organismslocalstore/organismlocalstore_id'} })
    location: str = Field(..., json_schema_extra = { "linkml_meta": {'alias': 'location',
         'domain_of': ['OrganismInstance', 'OrganismsLocalStore'],
         'slot_uri': 'lara:organismslocalstore/location'} })
    organism_instances: Optional[List[str]] = Field(None, description="""parts in local store""", json_schema_extra = { "linkml_meta": {'alias': 'organism_instances',
         'domain_of': ['OrganismInstance',
                       'OrganismInstancesSubset',
                       'OrganismsLocalStore'],
         'slot_uri': 'lara:organismslocalstore/organism_instances'} })


class Container(ConfiguredBaseModel):
    linkml_meta: ClassVar[LinkMLMeta] = LinkMLMeta({'from_schema': 'https://w3id.org/lara/lara_django_organisms_store',
         'tree_root': True})

    extradatas: Optional[List[ExtraData]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'extradatas', 'domain_of': ['Container']} })
    organisminstances: Optional[List[OrganismInstance]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'organisminstances', 'domain_of': ['Container']} })
    organisminstancessubsets: Optional[List[OrganismInstancesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'organisminstancessubsets', 'domain_of': ['Container']} })
    orderedorganismsinstanceorganismsinstancessubsets: Optional[List[OrderedOrganismsInstanceOrganismsInstancesSubset]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'orderedorganismsinstanceorganismsinstancessubsets',
         'domain_of': ['Container']} })
    organismorderitems: Optional[List[OrganismOrderItem]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'organismorderitems', 'domain_of': ['Container']} })
    organismwishlists: Optional[List[OrganismWishlist]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'organismwishlists', 'domain_of': ['Container']} })
    organismbaskets: Optional[List[OrganismBasket]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'organismbaskets', 'domain_of': ['Container']} })
    organismorders: Optional[List[OrganismOrder]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'organismorders', 'domain_of': ['Container']} })
    organismslocalstores: Optional[List[OrganismsLocalStore]] = Field(None, json_schema_extra = { "linkml_meta": {'alias': 'organismslocalstores', 'domain_of': ['Container']} })


# Model rebuild
# see https://pydantic-docs.helpmanual.io/usage/models/#rebuilding-a-model
Entity.model_rebuild()
Organism.model_rebuild()
Location.model_rebuild()
Tag.model_rebuild()
ExternalResource.model_rebuild()
DataType.model_rebuild()
Namespace.model_rebuild()
Currency.model_rebuild()
MediaType.model_rebuild()
ItemStatus.model_rebuild()
Group.model_rebuild()
ExtraData.model_rebuild()
OrganismInstance.model_rebuild()
OrganismInstancesSubset.model_rebuild()
OrderedOrganismsInstanceOrganismsInstancesSubset.model_rebuild()
OrganismOrderItem.model_rebuild()
OrganismWishlist.model_rebuild()
OrganismBasket.model_rebuild()
OrganismOrder.model_rebuild()
OrganismsLocalStore.model_rebuild()
Container.model_rebuild()

