"""_____________________________________________________________________

:PROJECT: LARAsuite

*lara_django_organisms_store high_level_interface *

:details: lara_django_organisms_store high_level_interface.
         - generated with 'lara-django-dev generate_high_level_interface lara_django_organisms_store
:authors: mark doerr <mark.doerr@uni-greifswald.de>

.. note:: -
.. todo:: -
________________________________________________________________________
"""

import json
import asyncio
import logging
import grpc
from typing import Union

from google.protobuf.struct_pb2 import Struct
from google.protobuf.json_format import MessageToDict

import lara_django_base_grpc.v1.lara_django_base_pb2 as lara_django_base_pb2
import lara_django_base_grpc.v1.lara_django_base_pb2_grpc as lara_django_base_pb2_grpc

import lara_django_organisms_store_grpc.v1.lara_django_organisms_store_pb2 as lara_django_organisms_store_pb2
import lara_django_organisms_store_grpc.v1.lara_django_organisms_store_pb2_grpc as lara_django_organisms_store_pb2_grpc

import  lara_django_base_grpc.lara_django_base_data_model as base_dm
import  lara_django_base_grpc.lara_django_base_interface as base_if
from  lara_django_base_grpc.abstract_interface import LARAInterface, GRPCChannelSingleton, import_model_instance_from_file, export_model_instance_to_file, upload_file, download_file, update_file, upload_image, update_image, download_image, id_cache

import  lara_django_organisms_store_grpc.lara_django_organisms_store_data_model as organisms_store_dm

logger = logging.getLogger(__name__)



#_________________  ExtraData  ______________________


class ExtraDataInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.extradata_class_client = (
        #     lara_django_organisms_store_pb2_grpc.ExtraDataclassByIRIControllerStub(channel)
        # )

        self.extradata_client = lara_django_organisms_store_pb2_grpc.ExtraDataControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "extradata_id"
        self.stub = self.extradata_client

        self.file_download_info = lara_django_organisms_store_pb2.FileDownloadInfo
        self.file_upload_chunk = lara_django_organisms_store_pb2.FileUploadChunk


        # self.extradata_full_client = lara_django_organisms_store_pb2_grpc.ExtraDataFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_file  # needed for file upload
    async def create(self,  extradata:  list[organisms_store_dm.ExtraData] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.ExtraData]]:
        """ create a list of extradata instances,
               returns a list of extradata data model objects or ids_only

        :param extradata: list of extradata data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of extradata data model objects or ids_only
        """
        extradataclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if extradata_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.extradata_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.ExtraDataclassRetrieveRequest(iri=extradata_class_iri)
        #     )
        #     extradataclass_id = res.extradataclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving extradataclass_id: {e}")
        for extradata in extradata:
            if extradata.namespace == "" or extradata.namespace == "default":
                    extradata.namespace = namespace_id
            # extradata.extradata_class = extradataclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.extradata_client.Create(lara_django_organisms_store_pb2.ExtraDataRequest(**extradata.model_dump())) for extradata in extradata )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("extradata_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating extradata: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        extradata_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.ExtraData]:
        """ retrieve a list of extradata instances by extradata_id, name or filter_dict,
               returns a list of extradata data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  extradata_id is not None:
            try:
                res =  await self.extradata_client.Retrieve(
                    lara_django_organisms_store_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving extradata_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.extradata_client.List(
                    lara_django_organisms_store_pb2.ExtraDataListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the extradata_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].extradata_id
        else:
            raise ValueError(f"Error retrieving extradata_id - no or too many results found.")
    
    @download_file  # needed for file download
    async def get_by_id(self, extradata_id: str = None, id_only: bool = False) -> organisms_store_dm.ExtraData:
        """ retrieve a extradata data model by extradata_id """
        try:
            res = await self.extradata_client.Retrieve(
                lara_django_organisms_store_pb2.ExtraDataRetrieveRequest(extradata_id=extradata_id)
            )
            item = organisms_store_dm.ExtraData(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.extradata_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving extradata_id: {e}")
    
    @download_file  # needed for file download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> organisms_store_dm.ExtraData | str:
        """ retrieve a extradata data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.extradata_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.ExtraDataRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["extradata_id"]
            if id_only:
                return self.item_id
            else:
                return organisms_store_dm.ExtraData(**item)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
   
    
    @download_file  # needed for file download
    async def get_file(self, extradata_id : str = None, id_only : bool = True ) -> bytes | None:
        """ retrieve a file by data_id """
        self.item_id = extradata_id
        
    
    async def get_file_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                filename_target : str = None,
                                as_byte_str : bool = None ) -> bytes | None:
        """ retrieve a file by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            # logger.warning(f"no namespace_uri provided, using default namespace: {namespace_uri}")
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            extradata_id = await self.get_by_name(name=name, namespace_uri=namespace_uri, id_only=True)
            return await self.get_file(extradata_id=extradata_id, filename_target=filename_target, as_byte_str=as_byte_str, get_file=True)
        except Exception as e:
            logger.error(f"Error retrieving extradata name: {e}")
        
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all extradatas """
        if filter_dict is None:
            res = await self.extradata_client.List(lara_django_organisms_store_pb2.ExtraDataListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.extradata_client.List(
                lara_django_organisms_store_pb2.ExtraDataListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.extradata_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all extradatas """
        if self.extradata_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.extradata_full_client.List(
                lara_django_organisms_store_pb2.ExtraDataFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.extradata_full_client.List(
                lara_django_organisms_store_pb2.ExtraDataFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_file  # needed for file update
    async def update(self, extradata : organisms_store_dm.ExtraData = None) -> None:
        """ update a extradata model instance """
        try:
            res = await self.extradata_client.Update(
                lara_django_organisms_store_pb2.ExtraDataRequest(**extradata.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating extradata_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a extradata by extradata_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.extradata_client.Destroy(lara_django_organisms_store_pb2.ExtraDataDestroyRequest(extradata_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting extradata_id: {e}")

#_________________  OrganismInstance  ______________________


class OrganismInstanceInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.organisminstance_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismInstanceclassByIRIControllerStub(channel)
        # )

        self.organisminstance_client = lara_django_organisms_store_pb2_grpc.OrganismInstanceControllerStub(channel)
        
        self.item_id = None
        self.update_item_id = "organisminstance_id"
        self.stub = self.organisminstance_client

        self.image_upload_chunk = lara_django_organisms_store_pb2.ImageUploadChunk


        # self.organisminstance_full_client = lara_django_organisms_store_pb2_grpc.OrganismInstanceFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    @upload_image  # needed for image upload
    async def create(self,  organisminstances:  list[organisms_store_dm.OrganismInstance] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismInstance]]:
        """ create a list of organisminstance instances,
               returns a list of organisminstance data model objects or ids_only

        :param organisminstances: list of organisminstance data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organisminstance data model objects or ids_only
        """
        organisminstanceclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organisminstance_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organisminstance_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismInstanceclassRetrieveRequest(iri=organisminstance_class_iri)
        #     )
        #     organisminstanceclass_id = res.organisminstanceclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organisminstanceclass_id: {e}")
        for organisminstance in organisminstances:
            if organisminstance.namespace == "" or organisminstance.namespace == "default":
                    organisminstance.namespace = namespace_id
            # organisminstance.organisminstance_class = organisminstanceclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organisminstance_client.Create(lara_django_organisms_store_pb2.OrganismInstanceRequest(**organisminstance.model_dump())) for organisminstance in organisminstances )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("organisminstance_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organisminstance: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organisminstance_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismInstance]:
        """ retrieve a list of organisminstance instances by organisminstance_id, name or filter_dict,
               returns a list of organisminstance data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  organisminstance_id is not None:
            try:
                res =  await self.organisminstance_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismInstanceRetrieveRequest(organisminstance_id=organisminstance_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismInstance(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organisminstance_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organisminstance_client.List(
                    lara_django_organisms_store_pb2.OrganismInstanceListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_store_dm.OrganismInstance(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving organisminstance name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the organisminstance_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].organisminstance_id
        else:
            raise ValueError(f"Error retrieving organisminstance_id - no or too many results found.")
    
    @download_image  # needed for image download
    async def get_by_id(self, organisminstance_id: str = None, id_only: bool = False) -> organisms_store_dm.OrganismInstance:
        """ retrieve a organisminstance data model by organisminstance_id """
        try:
            res = await self.organisminstance_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismInstanceRetrieveRequest(organisminstance_id=organisminstance_id)
            )
            item = organisms_store_dm.OrganismInstance(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.organisminstance_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving organisminstance_id: {e}")
    
    @download_image  # needed for image download
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> organisms_store_dm.OrganismInstance | str:
        """ retrieve a organisminstance data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organisminstance_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismInstanceRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["organisminstance_id"]
            if id_only:
                return self.item_id
            else:
                return organisms_store_dm.OrganismInstance(**item)
        except Exception as e:
            logger.error(f"Error retrieving organisminstance name: {e}")
   
    
    
    
    @download_image  # needed for image download
    async def get_image(self, organisminstance_id : str = None, id_only : bool = True) -> bytes | None:
        """ retrieve an image by data_id """
        self.item_id = organisminstance_id
        
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organisminstances """
        if filter_dict is None:
            res = await self.organisminstance_client.List(lara_django_organisms_store_pb2.OrganismInstanceListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organisminstance_client.List(
                lara_django_organisms_store_pb2.OrganismInstanceListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organisminstance_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organisminstances """
        if self.organisminstance_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organisminstance_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstanceFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organisminstance_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstanceFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    @update_image  # needed for image update
    async def update(self, organisminstance : organisms_store_dm.OrganismInstance = None) -> None:
        """ update a organisminstance model instance """
        try:
            res = await self.organisminstance_client.Update(
                lara_django_organisms_store_pb2.OrganismInstanceRequest(**organisminstance.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organisminstance_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organisminstance by organisminstance_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organisminstance_client.Destroy(lara_django_organisms_store_pb2.OrganismInstanceDestroyRequest(organisminstance_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organisminstance_id: {e}")

#_________________  OrganismInstancesSubset  ______________________


class OrganismInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.organisminstancessubset_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismInstancesSubsetclassByIRIControllerStub(channel)
        # )

        self.organisminstancessubset_client = lara_django_organisms_store_pb2_grpc.OrganismInstancesSubsetControllerStub(channel)
        

        # self.organisminstancessubset_full_client = lara_django_organisms_store_pb2_grpc.OrganismInstancesSubsetFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  organisminstancessubsets:  list[organisms_store_dm.OrganismInstancesSubset] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismInstancesSubset]]:
        """ create a list of organisminstancessubset instances,
               returns a list of organisminstancessubset data model objects or ids_only

        :param organisminstancessubsets: list of organisminstancessubset data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organisminstancessubset data model objects or ids_only
        """
        organisminstancessubsetclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organisminstancessubset_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organisminstancessubset_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismInstancesSubsetclassRetrieveRequest(iri=organisminstancessubset_class_iri)
        #     )
        #     organisminstancessubsetclass_id = res.organisminstancessubsetclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organisminstancessubsetclass_id: {e}")
        for organisminstancessubset in organisminstancessubsets:
            if organisminstancessubset.namespace == "" or organisminstancessubset.namespace == "default":
                    organisminstancessubset.namespace = namespace_id
            # organisminstancessubset.organisminstancessubset_class = organisminstancessubsetclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organisminstancessubset_client.Create(lara_django_organisms_store_pb2.OrganismInstancesSubsetRequest(**organisminstancessubset.model_dump())) for organisminstancessubset in organisminstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("organisminstancessubset_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organisminstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organisminstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismInstancesSubset]:
        """ retrieve a list of organisminstancessubset instances by organisminstancessubset_id, name or filter_dict,
               returns a list of organisminstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  organisminstancessubset_id is not None:
            try:
                res =  await self.organisminstancessubset_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismInstancesSubsetRetrieveRequest(organisminstancessubset_id=organisminstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organisminstancessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organisminstancessubset_client.List(
                    lara_django_organisms_store_pb2.OrganismInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_store_dm.OrganismInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving organisminstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the organisminstancessubset_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].organisminstancessubset_id
        else:
            raise ValueError(f"Error retrieving organisminstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, organisminstancessubset_id: str = None, id_only: bool = False) -> organisms_store_dm.OrganismInstancesSubset:
        """ retrieve a organisminstancessubset data model by organisminstancessubset_id """
        try:
            res = await self.organisminstancessubset_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetRetrieveRequest(organisminstancessubset_id=organisminstancessubset_id)
            )
            item = organisms_store_dm.OrganismInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.organisminstancessubset_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving organisminstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> organisms_store_dm.OrganismInstancesSubset | str:
        """ retrieve a organisminstancessubset data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organisminstancessubset_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["organisminstancessubset_id"]
            if id_only:
                return self.item_id
            else:
                return organisms_store_dm.OrganismInstancesSubset(**item)
        except Exception as e:
            logger.error(f"Error retrieving organisminstancessubset name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organisminstancessubsets """
        if filter_dict is None:
            res = await self.organisminstancessubset_client.List(lara_django_organisms_store_pb2.OrganismInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organisminstancessubset_client.List(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organisminstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organisminstancessubsets """
        if self.organisminstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organisminstancessubset_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organisminstancessubset_full_client.List(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, organisminstancessubset : organisms_store_dm.OrganismInstancesSubset = None) -> None:
        """ update a organisminstancessubset model instance """
        try:
            res = await self.organisminstancessubset_client.Update(
                lara_django_organisms_store_pb2.OrganismInstancesSubsetRequest(**organisminstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organisminstancessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organisminstancessubset by organisminstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organisminstancessubset_client.Destroy(lara_django_organisms_store_pb2.OrganismInstancesSubsetDestroyRequest(organisminstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organisminstancessubset_id: {e}")

#_________________  OrderedOrganismsInstanceOrganismsInstancesSubset  ______________________


class OrderedOrganismsInstanceOrganismsInstancesSubsetInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.orderedorganismsinstanceorganismsinstancessubset_client = lara_django_organisms_store_pb2_grpc.OrderedOrganismsInstanceOrganismsInstancesSubsetControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  orderedorganismsinstanceorganismsinstancessubsets:  list[organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset]]:
        try:
            create_coroutines = ( self.orderedorganismsinstanceorganismsinstancessubset_client.Create(lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetRequest(**orderedorganismsinstanceorganismsinstancessubset.model_dump())) for orderedorganismsinstanceorganismsinstancessubset in orderedorganismsinstanceorganismsinstancessubsets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.orderedorganismsinstanceorganismsinstancessubset_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating orderedorganismsinstanceorganismsinstancessubset: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        orderedorganismsinstanceorganismsinstancessubset_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset]:
        """ retrieve a list of orderedorganismsinstanceorganismsinstancessubset instances by orderedorganismsinstanceorganismsinstancessubset_id, name or filter_dict,
               returns a list of orderedorganismsinstanceorganismsinstancessubset data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  orderedorganismsinstanceorganismsinstancessubset_id is not None:
            try:
                res =  await self.orderedorganismsinstanceorganismsinstancessubset_client.Retrieve(
                    lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetRetrieveRequest(orderedorganismsinstanceorganismsinstancessubset_id=orderedorganismsinstanceorganismsinstancessubset_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving orderedorganismsinstanceorganismsinstancessubset_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.orderedorganismsinstanceorganismsinstancessubset_client.List(
                    lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving orderedorganismsinstanceorganismsinstancessubset name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the orderedorganismsinstanceorganismsinstancessubset_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].orderedorganismsinstanceorganismsinstancessubset_id
        else:
            raise ValueError(f"Error retrieving orderedorganismsinstanceorganismsinstancessubset_id - no or too many results found.")
    
    async def get_by_id(self, orderedorganismsinstanceorganismsinstancessubset_id: str = None) -> organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset:
        """ retrieve a orderedorganismsinstanceorganismsinstancessubset data model by orderedorganismsinstanceorganismsinstancessubset_id """
        try:
            res = await self.orderedorganismsinstanceorganismsinstancessubset_client.Retrieve(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetRetrieveRequest(orderedorganismsinstanceorganismsinstancessubset_id=orderedorganismsinstanceorganismsinstancessubset_id)
            )
            return organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedorganismsinstanceorganismsinstancessubset_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset | str:
        """ retrieve a orderedorganismsinstanceorganismsinstancessubset data model by name """
        try:
            res = await self.orderedorganismsinstanceorganismsinstancessubset_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["orderedorganismsinstanceorganismsinstancessubset_id"]
            else:
                return organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving orderedorganismsinstanceorganismsinstancessubset name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all orderedorganismsinstanceorganismsinstancessubsets """
        if filter_dict is None:
            res = await self.orderedorganismsinstanceorganismsinstancessubset_client.List(lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.orderedorganismsinstanceorganismsinstancessubset_client.List(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.orderedorganismsinstanceorganismsinstancessubset_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all orderedorganismsinstanceorganismsinstancessubsets """
        if self.orderedorganismsinstanceorganismsinstancessubset_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.orderedorganismsinstanceorganismsinstancessubset_full_client.List(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.orderedorganismsinstanceorganismsinstancessubset_full_client.List(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, orderedorganismsinstanceorganismsinstancessubset : organisms_store_dm.OrderedOrganismsInstanceOrganismsInstancesSubset = None) -> None:
        """ update a orderedorganismsinstanceorganismsinstancessubset model instance """
        try:
            res = await self.orderedorganismsinstanceorganismsinstancessubset_client.Update(
                lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetRequest(**orderedorganismsinstanceorganismsinstancessubset.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating orderedorganismsinstanceorganismsinstancessubset_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a orderedorganismsinstanceorganismsinstancessubset by orderedorganismsinstanceorganismsinstancessubset_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.orderedorganismsinstanceorganismsinstancessubset_client.Destroy(lara_django_organisms_store_pb2.OrderedOrganismsInstanceOrganismsInstancesSubsetDestroyRequest(orderedorganismsinstanceorganismsinstancessubset_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting orderedorganismsinstanceorganismsinstancessubset_id: {e}")

#_________________  OrganismOrderItem  ______________________


class OrganismOrderItemInterface:
    def __init__(self, channel: grpc.Channel = None) -> None:
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.organismorderitem_client = lara_django_organisms_store_pb2_grpc.OrganismOrderItemControllerStub(channel)
        
    
    @import_model_instance_from_file()
    async def create(self,  organismorderitems:  list[organisms_store_dm.OrganismOrderItem] = None,  ids_only: bool = False) -> Union[list[str], list[organisms_store_dm.OrganismOrderItem]]:
        try:
            create_coroutines = ( self.organismorderitem_client.Create(lara_django_organisms_store_pb2.OrganismOrderItemRequest(**organismorderitem.model_dump())) for organismorderitem in organismorderitems )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [item.organismorderitem_id for item in res]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organismorderitem: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        organismorderitem_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismOrderItem]:
        """ retrieve a list of organismorderitem instances by organismorderitem_id, name or filter_dict,
               returns a list of organismorderitem data model objects,
               if raw is True, the raw protobuf objects are returned
        """
        results_list = []
        if  organismorderitem_id is not None:
            try:
                res =  await self.organismorderitem_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismOrderItemRetrieveRequest(organismorderitem_id=organismorderitem_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organismorderitem_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organismorderitem_client.List(
                    lara_django_organisms_store_pb2.OrganismOrderItemListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_store_dm.OrganismOrderItem(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving organismorderitem name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the organismorderitem_id for a given name,
               (name_display) or iri
        """
        
        results_list = await self.retrieve(name=name, filter_dict=filter_dict, raw=True)
        if len(results_list) == 1 :
            return results_list[0].organismorderitem_id
        else:
            raise ValueError(f"Error retrieving organismorderitem_id - no or too many results found.")
    
    async def get_by_id(self, organismorderitem_id: str = None) -> organisms_store_dm.OrganismOrderItem:
        """ retrieve a organismorderitem data model by organismorderitem_id """
        try:
            res = await self.organismorderitem_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismOrderItemRetrieveRequest(organismorderitem_id=organismorderitem_id)
            )
            return organisms_store_dm.OrganismOrderItem(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismorderitem_id: {e}")
    
    async def get_by_name(self, name: str = None, id_only: bool = False) -> organisms_store_dm.OrganismOrderItem | str:
        """ retrieve a organismorderitem data model by name """
        try:
            res = await self.organismorderitem_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismOrderItemRetrieveByNameNSRequest(name=name, namespace_uri="")
            )
            if id_only:
                return MessageToDict(res, preserving_proto_field_name=True)["organismorderitem_id"]
            else:
                return organisms_store_dm.OrganismOrderItem(**MessageToDict(res, preserving_proto_field_name=True))
        except Exception as e:
            logger.error(f"Error retrieving organismorderitem name: {e}")
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organismorderitems """
        if filter_dict is None:
            res = await self.organismorderitem_client.List(lara_django_organisms_store_pb2.OrganismOrderItemListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismorderitem_client.List(
                lara_django_organisms_store_pb2.OrganismOrderItemListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismorderitem_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organismorderitems """
        if self.organismorderitem_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismorderitem_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderItemFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismorderitem_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderItemFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, organismorderitem : organisms_store_dm.OrganismOrderItem = None) -> None:
        """ update a organismorderitem model instance """
        try:
            res = await self.organismorderitem_client.Update(
                lara_django_organisms_store_pb2.OrganismOrderItemRequest(**organismorderitem.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organismorderitem_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organismorderitem by organismorderitem_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organismorderitem_client.Destroy(lara_django_organisms_store_pb2.OrganismOrderItemDestroyRequest(organismorderitem_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organismorderitem_id: {e}")

#_________________  OrganismWishlist  ______________________


class OrganismWishlistInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.organismwishlist_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismWishlistclassByIRIControllerStub(channel)
        # )

        self.organismwishlist_client = lara_django_organisms_store_pb2_grpc.OrganismWishlistControllerStub(channel)
        

        # self.organismwishlist_full_client = lara_django_organisms_store_pb2_grpc.OrganismWishlistFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  organismwishlists:  list[organisms_store_dm.OrganismWishlist] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismWishlist]]:
        """ create a list of organismwishlist instances,
               returns a list of organismwishlist data model objects or ids_only

        :param organismwishlists: list of organismwishlist data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organismwishlist data model objects or ids_only
        """
        organismwishlistclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismwishlist_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismwishlist_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismWishlistclassRetrieveRequest(iri=organismwishlist_class_iri)
        #     )
        #     organismwishlistclass_id = res.organismwishlistclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organismwishlistclass_id: {e}")
        for organismwishlist in organismwishlists:
            if organismwishlist.namespace == "" or organismwishlist.namespace == "default":
                    organismwishlist.namespace = namespace_id
            # organismwishlist.organismwishlist_class = organismwishlistclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organismwishlist_client.Create(lara_django_organisms_store_pb2.OrganismWishlistRequest(**organismwishlist.model_dump())) for organismwishlist in organismwishlists )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("organismwishlist_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organismwishlist: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organismwishlist_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismWishlist]:
        """ retrieve a list of organismwishlist instances by organismwishlist_id, name or filter_dict,
               returns a list of organismwishlist data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  organismwishlist_id is not None:
            try:
                res =  await self.organismwishlist_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismWishlistRetrieveRequest(organismwishlist_id=organismwishlist_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismWishlist(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organismwishlist_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organismwishlist_client.List(
                    lara_django_organisms_store_pb2.OrganismWishlistListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_store_dm.OrganismWishlist(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving organismwishlist name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the organismwishlist_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].organismwishlist_id
        else:
            raise ValueError(f"Error retrieving organismwishlist_id - no or too many results found.")
    
    async def get_by_id(self, organismwishlist_id: str = None, id_only: bool = False) -> organisms_store_dm.OrganismWishlist:
        """ retrieve a organismwishlist data model by organismwishlist_id """
        try:
            res = await self.organismwishlist_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismWishlistRetrieveRequest(organismwishlist_id=organismwishlist_id)
            )
            item = organisms_store_dm.OrganismWishlist(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.organismwishlist_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving organismwishlist_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> organisms_store_dm.OrganismWishlist | str:
        """ retrieve a organismwishlist data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organismwishlist_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismWishlistRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["organismwishlist_id"]
            if id_only:
                return self.item_id
            else:
                return organisms_store_dm.OrganismWishlist(**item)
        except Exception as e:
            logger.error(f"Error retrieving organismwishlist name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organismwishlists """
        if filter_dict is None:
            res = await self.organismwishlist_client.List(lara_django_organisms_store_pb2.OrganismWishlistListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismwishlist_client.List(
                lara_django_organisms_store_pb2.OrganismWishlistListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismwishlist_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organismwishlists """
        if self.organismwishlist_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismwishlist_full_client.List(
                lara_django_organisms_store_pb2.OrganismWishlistFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismwishlist_full_client.List(
                lara_django_organisms_store_pb2.OrganismWishlistFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, organismwishlist : organisms_store_dm.OrganismWishlist = None) -> None:
        """ update a organismwishlist model instance """
        try:
            res = await self.organismwishlist_client.Update(
                lara_django_organisms_store_pb2.OrganismWishlistRequest(**organismwishlist.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organismwishlist_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organismwishlist by organismwishlist_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organismwishlist_client.Destroy(lara_django_organisms_store_pb2.OrganismWishlistDestroyRequest(organismwishlist_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organismwishlist_id: {e}")

#_________________  OrganismBasket  ______________________


class OrganismBasketInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.organismbasket_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismBasketclassByIRIControllerStub(channel)
        # )

        self.organismbasket_client = lara_django_organisms_store_pb2_grpc.OrganismBasketControllerStub(channel)
        

        # self.organismbasket_full_client = lara_django_organisms_store_pb2_grpc.OrganismBasketFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  organismbaskets:  list[organisms_store_dm.OrganismBasket] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismBasket]]:
        """ create a list of organismbasket instances,
               returns a list of organismbasket data model objects or ids_only

        :param organismbaskets: list of organismbasket data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organismbasket data model objects or ids_only
        """
        organismbasketclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismbasket_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismbasket_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismBasketclassRetrieveRequest(iri=organismbasket_class_iri)
        #     )
        #     organismbasketclass_id = res.organismbasketclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organismbasketclass_id: {e}")
        for organismbasket in organismbaskets:
            if organismbasket.namespace == "" or organismbasket.namespace == "default":
                    organismbasket.namespace = namespace_id
            # organismbasket.organismbasket_class = organismbasketclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organismbasket_client.Create(lara_django_organisms_store_pb2.OrganismBasketRequest(**organismbasket.model_dump())) for organismbasket in organismbaskets )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("organismbasket_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organismbasket: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organismbasket_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismBasket]:
        """ retrieve a list of organismbasket instances by organismbasket_id, name or filter_dict,
               returns a list of organismbasket data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  organismbasket_id is not None:
            try:
                res =  await self.organismbasket_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismBasketRetrieveRequest(organismbasket_id=organismbasket_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismBasket(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organismbasket_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organismbasket_client.List(
                    lara_django_organisms_store_pb2.OrganismBasketListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_store_dm.OrganismBasket(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving organismbasket name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the organismbasket_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].organismbasket_id
        else:
            raise ValueError(f"Error retrieving organismbasket_id - no or too many results found.")
    
    async def get_by_id(self, organismbasket_id: str = None, id_only: bool = False) -> organisms_store_dm.OrganismBasket:
        """ retrieve a organismbasket data model by organismbasket_id """
        try:
            res = await self.organismbasket_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismBasketRetrieveRequest(organismbasket_id=organismbasket_id)
            )
            item = organisms_store_dm.OrganismBasket(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.organismbasket_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving organismbasket_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> organisms_store_dm.OrganismBasket | str:
        """ retrieve a organismbasket data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organismbasket_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismBasketRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["organismbasket_id"]
            if id_only:
                return self.item_id
            else:
                return organisms_store_dm.OrganismBasket(**item)
        except Exception as e:
            logger.error(f"Error retrieving organismbasket name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organismbaskets """
        if filter_dict is None:
            res = await self.organismbasket_client.List(lara_django_organisms_store_pb2.OrganismBasketListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismbasket_client.List(
                lara_django_organisms_store_pb2.OrganismBasketListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismbasket_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organismbaskets """
        if self.organismbasket_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismbasket_full_client.List(
                lara_django_organisms_store_pb2.OrganismBasketFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismbasket_full_client.List(
                lara_django_organisms_store_pb2.OrganismBasketFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, organismbasket : organisms_store_dm.OrganismBasket = None) -> None:
        """ update a organismbasket model instance """
        try:
            res = await self.organismbasket_client.Update(
                lara_django_organisms_store_pb2.OrganismBasketRequest(**organismbasket.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organismbasket_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organismbasket by organismbasket_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organismbasket_client.Destroy(lara_django_organisms_store_pb2.OrganismBasketDestroyRequest(organismbasket_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organismbasket_id: {e}")

#_________________  OrganismOrder  ______________________


class OrganismOrderInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.organismorder_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismOrderclassByIRIControllerStub(channel)
        # )

        self.organismorder_client = lara_django_organisms_store_pb2_grpc.OrganismOrderControllerStub(channel)
        

        # self.organismorder_full_client = lara_django_organisms_store_pb2_grpc.OrganismOrderFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  organismorders:  list[organisms_store_dm.OrganismOrder] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismOrder]]:
        """ create a list of organismorder instances,
               returns a list of organismorder data model objects or ids_only

        :param organismorders: list of organismorder data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organismorder data model objects or ids_only
        """
        organismorderclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismorder_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismorder_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismOrderclassRetrieveRequest(iri=organismorder_class_iri)
        #     )
        #     organismorderclass_id = res.organismorderclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organismorderclass_id: {e}")
        for organismorder in organismorders:
            if organismorder.namespace == "" or organismorder.namespace == "default":
                    organismorder.namespace = namespace_id
            # organismorder.organismorder_class = organismorderclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organismorder_client.Create(lara_django_organisms_store_pb2.OrganismOrderRequest(**organismorder.model_dump())) for organismorder in organismorders )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("organismorder_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organismorder: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organismorder_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismOrder]:
        """ retrieve a list of organismorder instances by organismorder_id, name or filter_dict,
               returns a list of organismorder data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  organismorder_id is not None:
            try:
                res =  await self.organismorder_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismOrderRetrieveRequest(organismorder_id=organismorder_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismOrder(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organismorder_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organismorder_client.List(
                    lara_django_organisms_store_pb2.OrganismOrderListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_store_dm.OrganismOrder(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving organismorder name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the organismorder_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].organismorder_id
        else:
            raise ValueError(f"Error retrieving organismorder_id - no or too many results found.")
    
    async def get_by_id(self, organismorder_id: str = None, id_only: bool = False) -> organisms_store_dm.OrganismOrder:
        """ retrieve a organismorder data model by organismorder_id """
        try:
            res = await self.organismorder_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismOrderRetrieveRequest(organismorder_id=organismorder_id)
            )
            item = organisms_store_dm.OrganismOrder(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.organismorder_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving organismorder_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> organisms_store_dm.OrganismOrder | str:
        """ retrieve a organismorder data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organismorder_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismOrderRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["organismorder_id"]
            if id_only:
                return self.item_id
            else:
                return organisms_store_dm.OrganismOrder(**item)
        except Exception as e:
            logger.error(f"Error retrieving organismorder name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organismorders """
        if filter_dict is None:
            res = await self.organismorder_client.List(lara_django_organisms_store_pb2.OrganismOrderListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismorder_client.List(
                lara_django_organisms_store_pb2.OrganismOrderListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismorder_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organismorders """
        if self.organismorder_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismorder_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismorder_full_client.List(
                lara_django_organisms_store_pb2.OrganismOrderFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, organismorder : organisms_store_dm.OrganismOrder = None) -> None:
        """ update a organismorder model instance """
        try:
            res = await self.organismorder_client.Update(
                lara_django_organisms_store_pb2.OrganismOrderRequest(**organismorder.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organismorder_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organismorder by organismorder_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organismorder_client.Destroy(lara_django_organisms_store_pb2.OrganismOrderDestroyRequest(organismorder_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organismorder_id: {e}")

#_________________  OrganismsLocalStore  ______________________


class OrganismsLocalStoreInterface:
    def __init__(self, channel: grpc.Channel = None, 
                       default_namespace_uri : str = None,
                       default_namespace_id : str = None,
                       namespace_if = None ) -> None:
        self._default_namespace_uri = default_namespace_uri
        self._default_namespace_id = default_namespace_id

        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel

        self.namespace_if = namespace_if if namespace_if is not None else base_if.NamespaceInterface(channel)

        # self.organismslocalstore_class_client = (
        #     lara_django_organisms_store_pb2_grpc.OrganismsLocalStoreclassByIRIControllerStub(channel)
        # )

        self.organismslocalstore_client = lara_django_organisms_store_pb2_grpc.OrganismsLocalStoreControllerStub(channel)
        

        # self.organismslocalstore_full_client = lara_django_organisms_store_pb2_grpc.OrganismsLocalStoreFullControllerStub(
        #     channel
        # )

    @property
    def default_namespace_uri(self):
        return self._default_namespace_uri

    @property
    def default_namespace_id(self):
        return self._default_namespace_id

    @classmethod
    async def build_if(cls, channel: grpc.Channel = None, default_namespace_uri: str = None):
    
        if channel is None:
            cs = GRPCChannelSingleton()
            channel = cs.channel
    
        namespace_if = base_if.NamespaceInterface(channel)
        try:
            default_namespace_id = await namespace_if.retrieve_id(namespace_uri=default_namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
        
        return cls(channel=channel, default_namespace_uri=default_namespace_uri,  
                   default_namespace_id=default_namespace_id, namespace_if=namespace_if)
    
    async def set_default_namespace_uri(self, namespace_uri: str = None):
        if namespace_uri is not None:
            self._default_namespace_uri = namespace_uri.strip()
        try:
            self._default_namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
        except Exception as e:
            logger.error(f"Error retrieving namespace_id: {e}")
    
    @import_model_instance_from_file()
    async def create(self,  organismslocalstores:  list[organisms_store_dm.OrganismsLocalStore] = None,  
                            ids_only: bool = False,
                            namespace_uri: str = None) -> Union[list[str], list[organisms_store_dm.OrganismsLocalStore]]:
        """ create a list of organismslocalstore instances,
               returns a list of organismslocalstore data model objects or ids_only

        :param organismslocalstores: list of organismslocalstore data model objects
        :param ids_only: return only the ids of the created instances
        :return: list of organismslocalstore data model objects or ids_only
        """
        organismslocalstoreclass_id = None

        namespace_id = None
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
            namespace_id = self._default_namespace_id
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        if namespace_id is None:
            try:
                namespace_id = await self.namespace_if.retrieve_id(namespace_uri=namespace_uri)
            except Exception as e:
                logger.error(f"Error retrieving namespace_id: {e}")

        # some sample code for retrieving a class IRI and adding namespace and class to the model
        # if organismslocalstore_class_iri is None:
        #     raise ValueError("No sample class IRI is given.")
        # try:
        #     res = await self.organismslocalstore_class_client.Retrieve(
        #         lara_django_organisms_store_pb2.OrganismsLocalStoreclassRetrieveRequest(iri=organismslocalstore_class_iri)
        #     )
        #     organismslocalstoreclass_id = res.organismslocalstoreclass_id
        # except Exception as e:
        #     logger.error(f"Error retrieving organismslocalstoreclass_id: {e}")
        for organismslocalstore in organismslocalstores:
            if organismslocalstore.namespace == "" or organismslocalstore.namespace == "default":
                    organismslocalstore.namespace = namespace_id
            # organismslocalstore.organismslocalstore_class = organismslocalstoreclass_id # uncomment if a model class is used

        try:
            create_coroutines = ( self.organismslocalstore_client.Create(lara_django_organisms_store_pb2.OrganismsLocalStoreRequest(**organismslocalstore.model_dump())) for organismslocalstore in organismslocalstores )
            res = await asyncio.gather(*create_coroutines)
            if ids_only:
                return [ MessageToDict(item, preserving_proto_field_name=True).get("organismslocalstore_id") for item in res ]
            else:
                return res

        except Exception as e:
            logger.error(f"Error creating organismslocalstore: {e}")
        
    @export_model_instance_to_file
    async def retrieve(
        self,
        namespace_uri: str = None,
        organismslocalstore_id: str = None,
        name: str = None,
        # name_display: str = None,
        filter_dict: dict = None,
        raw : bool = False
        ) -> list[organisms_store_dm.OrganismsLocalStore]:
        """ retrieve a list of organismslocalstore instances by organismslocalstore_id, name or filter_dict,
               returns a list of organismslocalstore data model objects,
               if raw is True, the raw protobuf objects are returned.
               If namespace_uri is "default", the default namespace_uri is used.
        """
        if namespace_uri == "default":
            if self._default_namespace_uri is not None:
                namespace_uri = self._default_namespace_uri
            else:
                raise ValueError("No default namespace URI is given.")
        
        results_list = []
        if  organismslocalstore_id is not None:
            try:
                res =  await self.organismslocalstore_client.Retrieve(
                    lara_django_organisms_store_pb2.OrganismsLocalStoreRetrieveRequest(organismslocalstore_id=organismslocalstore_id) )
                if raw:
                    results_list.append(res)
                else:
                    results_list.append( organisms_store_dm.OrganismsLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) )
            except Exception as e:
                logger.error(f"Error retrieving organismslocalstore_id: {e}")

        if filter_dict is None:
            filter_dict = {}

        if name is not None:
            filter_dict["name"] = name
        if namespace_uri is not None:
            filter_dict["namespace__uri"] = namespace_uri
        # if name_display is not None:
        #    filter_dict["name_display"] = name_display

        metadata = (("filters", (json.dumps(filter_dict))),)
        try:
            res = await self.organismslocalstore_client.List(
                    lara_django_organisms_store_pb2.OrganismsLocalStoreListRequest(), metadata=metadata
                    )
            if raw:
                    results_list += res.results
            else:
                # :TODO: a queue could be used here to speed up the retrieval
                results = res.results
                results_list += [ organisms_store_dm.OrganismsLocalStore(**MessageToDict(res, preserving_proto_field_name=True)) for res in results ]
        except Exception as e:
            logger.error(f"Error retrieving organismslocalstore name: {e}")

        return results_list

    #@id_cache
    async def retrieve_id(self,
                          name: str = None,
                          # name_display: str = None,
                          namespace_uri : str = None,
                          filter_dict : dict = None,
                          iri: str = None,) -> str:
        """ retrieve the organismslocalstore_id for a given name,
               name_display or iri
        """

        results_list = await self.retrieve(name=name, 
                        namespace_uri=namespace_uri, filter_dict=filter_dict, raw=True)

        if len(results_list) == 1 :
            return results_list[0].organismslocalstore_id
        else:
            raise ValueError(f"Error retrieving organismslocalstore_id - no or too many results found.")
    
    async def get_by_id(self, organismslocalstore_id: str = None, id_only: bool = False) -> organisms_store_dm.OrganismsLocalStore:
        """ retrieve a organismslocalstore data model by organismslocalstore_id """
        try:
            res = await self.organismslocalstore_client.Retrieve(
                lara_django_organisms_store_pb2.OrganismsLocalStoreRetrieveRequest(organismslocalstore_id=organismslocalstore_id)
            )
            item = organisms_store_dm.OrganismsLocalStore(**MessageToDict(res, preserving_proto_field_name=True))
            self.item_id = item.organismslocalstore_id
            return item
        except Exception as e:
            logger.error(f"Error retrieving organismslocalstore_id: {e}")
    
    async def get_by_name(self, name: str = None,
                                namespace_uri : str = None,
                                id_only: bool = False) -> organisms_store_dm.OrganismsLocalStore | str:
        """ retrieve a organismslocalstore data model by name """
        if namespace_uri is None and self._default_namespace_uri is not None:
            namespace_uri = self._default_namespace_uri
        if namespace_uri is None:
            raise ValueError("No namespace URI is given.")
        try:
            res = await self.organismslocalstore_client.RetrieveByNameNamespace(
                lara_django_organisms_store_pb2.OrganismsLocalStoreRetrieveByNameNSRequest(name=name, namespace_uri=namespace_uri)
            )
            item = MessageToDict(res, preserving_proto_field_name=True)
            self.item_id = item["organismslocalstore_id"]
            if id_only:
                return self.item_id
            else:
                return organisms_store_dm.OrganismsLocalStore(**item)
        except Exception as e:
            logger.error(f"Error retrieving organismslocalstore name: {e}")
   
    
    
    
    
    async def list_items(self, filter_dict: dict = None, ids_only: bool = False) -> list[str]:
        """ list all organismslocalstores """
        if filter_dict is None:
            res = await self.organismslocalstore_client.List(lara_django_organisms_store_pb2.OrganismsLocalStoreListRequest())
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            res = await self.organismslocalstore_client.List(
                lara_django_organisms_store_pb2.OrganismsLocalStoreListRequest(), metadata=metadata
            )
        if res is not None and ids_only:
            return [item.organismslocalstore_id for item in res.results]
        else:
            return res.results

    async def list_full(self, filter_dict: dict = None) -> list:
        """ list all organismslocalstores """
        if self.organismslocalstore_full_client is None:
            raise ValueError("No full client available.")
        if filter_dict is None:
            return await self.organismslocalstore_full_client.List(
                lara_django_organisms_store_pb2.OrganismsLocalStoreFullListRequest()
            )
        else:
            metadata = (("filters", (json.dumps(filter_dict))),)
            return await self.organismslocalstore_full_client.List(
                lara_django_organisms_store_pb2.OrganismsLocalStoreFullListRequest(), metadata=metadata
            )
    
    @import_model_instance_from_file()
    async def update(self, organismslocalstore : organisms_store_dm.OrganismsLocalStore = None) -> None:
        """ update a organismslocalstore model instance """
        try:
            res = await self.organismslocalstore_client.Update(
                lara_django_organisms_store_pb2.OrganismsLocalStoreRequest(**organismslocalstore.model_dump()
            ))
        except Exception as e:
            logger.error(f"Error updating organismslocalstore_id: {e}")
        else:
            return res
    
    async def delete(self, id_list: list[str] = None, filter_dict: dict = None) -> None:
        """ delete a organismslocalstore by organismslocalstore_id or filter_dict """
        if filter_dict is not None:
            id_list = await self.list_items(filter_dict=filter_dict, ids_only=True)

        try:
            delete_coroutines = ( self.organismslocalstore_client.Destroy(lara_django_organisms_store_pb2.OrganismsLocalStoreDestroyRequest(organismslocalstore_id=id)) for id in id_list )
            await asyncio.gather(*delete_coroutines)

        except Exception as e:
            logger.error(f"Error deleting organismslocalstore_id: {e}")

