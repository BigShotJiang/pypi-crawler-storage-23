## Semantic
- [2b63eda02ec4] The user prefers beach destinations in Southeast Asia.
- [23a0a0649a52] The user's budget is around $2000.
- [fde2a4a9e7ba] SkyWay offers a flight departing at 08:00, arriving at 11:30, priced at $320.
- [9ed51b99ab4d] AeroConnect offers a flight departing at 14:15, arriving at 17:45, priced at $275.
- [167eaa570899] GlobalJet offers a flight departing at 19:00, arriving at 22:30, priced at $410.
- [f84947b0583a] Grand Plaza Hotel is a 4-star hotel costing $150 per night.
- [c3a42fb75298] Budget Inn Express is a 2-star hotel costing $65 per night.
- [67c0dfc6cc6e] Riverside Boutique is a 5-star hotel costing $280 per night.
- [5e3be7e9f732] A city walking tour in Thailand takes 3 hours and costs $25.
- [6907856ab881] Visiting the Museum of Art in Thailand takes 2 hours and costs $15.
- [7bb268855734] A river cruise in Thailand takes 1.5 hours and costs $40.
- [3846d6a5ab93] A local food tasting in Thailand takes 2.5 hours and costs $55.

## Episodic
- [1123af39111d] The user is traveling to Thailand tomorrow and returning in two weeks.
