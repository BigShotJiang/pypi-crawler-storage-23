---
name: data-visualization
description: Chart generation tools for visualizing data
tools:
  - bar-chart
  - line-chart
  - pie-chart
---

# Data Visualization

Tools for generating charts and visual representations of data:

- **bar-chart**: Compare categories side by side (e.g., top names, language counts)
- **line-chart**: Show trends over time with one or more series (e.g., name popularity over decades)
- **pie-chart**: Show proportions and percentages (e.g., gender split, market share)

Each tool returns a markdown image link that renders inline in the chat.
