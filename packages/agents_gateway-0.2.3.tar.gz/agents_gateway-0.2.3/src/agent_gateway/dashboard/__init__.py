"""Agent Gateway dashboard — server-rendered UI via Jinja2 + HTMX."""
