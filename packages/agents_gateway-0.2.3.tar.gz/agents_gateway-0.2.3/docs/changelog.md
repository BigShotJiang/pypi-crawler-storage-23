# Changelog

All notable changes to Agent Gateway will be documented here.

This project follows [Semantic Versioning](https://semver.org/) and uses [Conventional Commits](https://www.conventionalcommits.org/).

## Unreleased

### Added

- **Sub-app mounting** — `Gateway.mount_to(parent, path)` lets you mount the gateway into an existing FastAPI application with full feature parity (dashboard, auth, OAuth2, static assets, scheduling, MCP, and chat streaming). See the [Sub-App Mounting guide](guides/mounting.md).

See the [GitHub Releases](https://github.com/vince-nyanga/agents-gateway/releases) page for the latest changes.
