# Historical integration report (archived)

This document previously described an earlier pre-draft session experiment
(`session/*` and `_meta["mcp/session"]`).

That design is fully superseded.

For the current implementation, use:

- `README.md`
- `session_server.py`
- `_session_base.py`
- `demo_fast_agent_sessions.py`
- `demo_all_sessions.py`
