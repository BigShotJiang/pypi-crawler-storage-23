---
type: agent
model: $system.demo
skills: []
servers:
  - mcp_sessions_notebook
---

Per-session notebook demo.

Try:

- "Append a notebook note with text alpha."
- "Append another notebook note with text beta."
- "Read the notebook."
- "Check notebook_status."
- "Clear the notebook."
