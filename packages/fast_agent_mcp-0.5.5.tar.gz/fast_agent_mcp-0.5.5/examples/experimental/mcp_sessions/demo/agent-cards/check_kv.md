---
type: agent
model: $system.demo
skills: []
servers:
  - mcp_sessions_hashcheck
---

Per-session hash set demo.

Try:

- "Store hash for text hello."
- "Verify hash for text hello."
- "List stored hashes."
- "Delete hash for text hello."
