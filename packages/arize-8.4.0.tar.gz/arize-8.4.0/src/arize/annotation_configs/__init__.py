"""Annotation config management and validation utilities for the Arize SDK."""
