"""PyArrow-related constants for data processing."""

MAX_CHUNKSIZE = 100_000
