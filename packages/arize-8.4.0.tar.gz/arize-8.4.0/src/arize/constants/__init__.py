"""Constants and configuration values used across the Arize SDK."""
