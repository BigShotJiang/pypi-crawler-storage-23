"""Version information for the Arize SDK."""

__version__ = "8.4.0"
