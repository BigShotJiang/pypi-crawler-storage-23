"""LLM tracing spans functionality for the Arize SDK."""
