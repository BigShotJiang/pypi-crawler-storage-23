"""Annotation validation for LLM tracing spans."""
