"""Common validation utilities shared across spans validation."""
