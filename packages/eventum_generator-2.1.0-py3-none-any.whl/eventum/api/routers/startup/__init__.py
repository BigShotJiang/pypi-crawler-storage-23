"""Startup router package."""

from eventum.api.routers.startup.routes import router

__all__ = ['router']
