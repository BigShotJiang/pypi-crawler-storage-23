"""Docs router package."""

from eventum.api.routers.docs.routes import router

__all__ = ['router']
