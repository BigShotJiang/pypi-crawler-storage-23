"""Preview router package."""

from eventum.api.routers.preview.routes import router

__all__ = ['router']
