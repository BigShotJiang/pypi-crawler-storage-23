"""Auth router package."""

from eventum.api.routers.auth.routes import router

__all__ = ['router']
