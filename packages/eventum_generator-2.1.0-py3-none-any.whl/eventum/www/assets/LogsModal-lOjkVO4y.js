import{g as c,an as k,r,j as o,S as M,G as l,J as i}from"./index-DfMK0oAU.js";import{R as u,E as n,F as v,M as f,O as y}from"./index-jqdhb9hV.js";/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const w=[["path",{d:"M4 20l16 0",key:"svg-0"}],["path",{d:"M12 14l0 -10",key:"svg-1"}],["path",{d:"M12 14l4 -4",key:"svg-2"}],["path",{d:"M12 14l-4 -4",key:"svg-3"}]],x=c("outline","arrow-bar-to-down","ArrowBarToDown",w);/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=[["path",{d:"M12 10l0 10",key:"svg-0"}],["path",{d:"M12 10l4 4",key:"svg-1"}],["path",{d:"M12 10l-4 4",key:"svg-2"}],["path",{d:"M4 4l16 0",key:"svg-3"}]],j=c("outline","arrow-bar-to-up","ArrowBarToUp",m);/**
 * @license @tabler/icons-react v3.34.1 - MIT
 *
 * This source code is licensed under the MIT license.
 * See the LICENSE file in the root directory of this source tree.
 */const S=[["path",{d:"M4 12h.01",key:"svg-0"}],["path",{d:"M4 6h.01",key:"svg-1"}],["path",{d:"M4 18h.01",key:"svg-2"}],["path",{d:"M8 18h2",key:"svg-3"}],["path",{d:"M8 12h2",key:"svg-4"}],["path",{d:"M8 6h2",key:"svg-5"}],["path",{d:"M14 6h6",key:"svg-6"}],["path",{d:"M14 12h6",key:"svg-7"}],["path",{d:"M14 18h6",key:"svg-8"}]],C=c("outline","logs","Logs",S),A=({getWebSocket:d})=>{const{colorScheme:h}=k(),[e,p]=r.useState(),s=r.useCallback(t=>{e&&e.dispatch({changes:{from:e.state.doc.length,insert:t},scrollIntoView:!1})},[e]),g=r.useRef(null);return r.useEffect(()=>{if(!e)return;const t=d();return g.current=t,t.onmessage=a=>{s(String(a.data))},t.onerror=()=>{s(`
[Socket error]
`)},t.onclose=a=>{s(`
[Socket has closed with code: ${a.code}]
`)},()=>{t.close(1e3)}},[e,s]),o.jsxs(M,{children:[o.jsx(u,{height:"75vh",theme:h==="dark"?f:y,editable:!1,extensions:[n.lineWrapping,v.readOnly.of(!0),n.editable.of(!1),n.contentAttributes.of({tabindex:"0"})],onCreateEditor:p}),o.jsx(l,{justify:"end",children:o.jsxs(l,{gap:"xs",children:[o.jsx(i,{title:"Go to top",variant:"default",size:"lg",onClick:()=>{e&&e.scrollDOM.scrollTo({top:0})},children:o.jsx(j,{size:"20"})}),o.jsx(i,{title:"Go to bottom",variant:"default",size:"lg",onClick:()=>{e&&e.scrollDOM.scrollTo({top:e.scrollDOM.scrollHeight})},children:o.jsx(x,{size:"20"})})]})})]})};export{C as I,A as L};
