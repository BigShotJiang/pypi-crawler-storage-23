"""Package with definition of base plugin."""
