"""Package with opensearch output plugin implementation."""
