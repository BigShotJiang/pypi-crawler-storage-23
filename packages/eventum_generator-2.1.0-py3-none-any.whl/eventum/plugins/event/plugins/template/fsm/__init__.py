"""Package containing FSM picking mode implementation."""
