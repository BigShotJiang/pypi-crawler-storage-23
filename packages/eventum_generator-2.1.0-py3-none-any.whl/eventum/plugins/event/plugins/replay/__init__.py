"""Package with replay event plugin implementation."""
