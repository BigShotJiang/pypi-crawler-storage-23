"""Package with script event plugin implementation."""
