"""Package with cron input plugin implementation."""
