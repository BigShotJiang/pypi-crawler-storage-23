"""Input plugins definition package."""
