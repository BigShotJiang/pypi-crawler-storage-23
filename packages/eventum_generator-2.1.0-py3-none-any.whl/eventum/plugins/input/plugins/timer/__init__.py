"""Package with timer input plugin implementation."""
