"""Package with timestamps input plugin implementation."""
