"""Command line interface for the application."""
