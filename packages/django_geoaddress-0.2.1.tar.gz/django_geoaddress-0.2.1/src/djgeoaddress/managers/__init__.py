"""Managers for djgeoaddress."""

from .suggest import AddressManager

__all__ = ["AddressManager", "ProviderManager"]
