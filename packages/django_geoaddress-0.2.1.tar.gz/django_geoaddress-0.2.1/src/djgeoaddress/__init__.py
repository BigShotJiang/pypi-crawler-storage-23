"""Django GeoAddress - Address verification and geocoding for Django."""

from __future__ import annotations

from django.db import models

__version__ = "0.2.1"

default_app_config = "djgeoaddress.apps.DjGeoAddressConfig"
