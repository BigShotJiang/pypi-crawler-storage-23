# UAICP Adapter AutoGen

UAICP v0.3 Reliability Protocol Adapter for Microsoft AutoGen

Version: 0.3.0
