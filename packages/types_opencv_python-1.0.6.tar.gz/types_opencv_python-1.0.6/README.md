## types-opencv
This is an OpenCV stubs project.
Generated based on the OpenCV documentation and my local Python environment with my patch.
