"""Runner prompt templates."""
