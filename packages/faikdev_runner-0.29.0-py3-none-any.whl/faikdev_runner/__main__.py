from __future__ import annotations

import sys

from faikdev_runner.main import console_main


if __name__ == "__main__":
    raise SystemExit(console_main())
