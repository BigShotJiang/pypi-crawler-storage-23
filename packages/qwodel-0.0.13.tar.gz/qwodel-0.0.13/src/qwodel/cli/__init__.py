"""Qwodel CLI Package"""

from qwodel.cli.main import cli

__all__ = ["cli"]
