# CHANGELOG

<!-- version list -->

## v1.0.0 (2026-02-20)

- Initial Release
