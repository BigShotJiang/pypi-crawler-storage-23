"""Quick access to non-critical secrets from the terminal."""
