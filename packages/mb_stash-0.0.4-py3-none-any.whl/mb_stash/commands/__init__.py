"""CLI commands for mb-stash."""
