# Import the HybridGP
try:
    from csrk._csrk_rust import HybridGP
    from csrk._csrk_rust import HybridGP as GP
#except ImportError:
#    print("Ouch!")
#    pass
except Exception as exc:
    import traceback
    traceback.print_exc()
    raise exc
# Other imports 
from csrk.utils import fit_compact_nd
