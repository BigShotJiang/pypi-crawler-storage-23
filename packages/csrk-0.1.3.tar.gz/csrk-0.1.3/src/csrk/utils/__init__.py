from csrk.utils.fit_compact import fit_compact_nd
