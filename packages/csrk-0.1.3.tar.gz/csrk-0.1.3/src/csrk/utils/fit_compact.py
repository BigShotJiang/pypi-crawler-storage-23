"""Utilities for the compact kernel"""
__author__ = "Vera Delfavero"

######## Fit using a known method to determine scale ########
def fit_compact_nd(
    x_train,
    y_train,
    y_err = None,
    scale = None,
    whitenoise = 0.0,
    order = 1,
    method = "scott",
    ):
    """Fit data using a Gaussian Process Hybrid GP

    Parameters
    ----------
    x_train: numpy.ndarray, shape = (npts, ndim)
        Training data locations
    y_train: numpy.ndarray, shape = (npts,)
        Training data values
    y_err: numpy.ndarray, shape = (npts,)
        Training error values
    scale: numpy.ndarray, shape = (ndim,)
        Scale for determining sparsity
    whitenoise: float
        whitenosie for fit
    order: int
        Mean square differentiable order of the fit
    method: str
        Indicaes how to determine sparsity ocefficients 
    """
    import numpy as np
    from csrk import HybridGP
    # Extract dimensions from data
    if len(x_train.shape) != 2:
        raise ValueError("X training data has the wrong shape")
    npts, ndim = x_train.shape
    if y_train.size != npts:
        raise ValueError("Y training data has the wrong shape")
    # Check y_err
    if y_err is None:
        y_err = np.zeros_like(y_train)
    elif (len(y_err.shape) != 2) or (y_err.size != y_train.size):
        raise ValueError("Y training error has the wrong shape")
    # Determine scale
    if method == "scott":
        scale = npts**(-1./(ndim + 4.)) * \
            (np.max(x_train,axis=0)-np.min(x_train,axis=0))
    else:
        raise NotImplementedError(
            f"method {method} is not implemented for fit_compact")
    # Fit the GP
    return HybridGP(x_train, y_train, y_err, scale, whitenoise, order)
