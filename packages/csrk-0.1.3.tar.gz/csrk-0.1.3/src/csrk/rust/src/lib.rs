use pyo3::prelude::*;

mod gp;
//mod realization;

#[pymodule]
fn _csrk_rust(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<gp::HybridGP>()?;
    //m.add_class::<realization::GPRealization>()?;
    Ok(())
}
