# Changelog
## 0.1.3
- Added `fit_compact_nd` utility
## 0.1.2
- Support __call__ as wrapper for `predict_mean`
## 0.1.1
- Requires updated version of csrk to overcome bugs with Fortran-contiguous arrays
## 0.1.0
- Initial version

