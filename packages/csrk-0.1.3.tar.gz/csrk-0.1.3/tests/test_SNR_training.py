######## Setup ########
FNAME_SNR_TRAINING = "originals/SNR_training.csv"
NDIM = 2
ORDER = 1
WHITENOISE = 0.
SCALE_K = 2.

######## Tests ########
def test_SNR_training():
    import time
    import numpy as np
    from csrk import HybridGP, fit_compact_nd
    
    ## load training data
    alldata = np.loadtxt(FNAME_SNR_TRAINING, delimiter=",")
    assert alldata.shape[1] == NDIM + 1
    print(alldata.strides)
    X = alldata[:,:-1]
    print(X.strides)
    print(X.dtype)
    Y = alldata[:,-1]
    Y_err = np.zeros_like(Y)
    msq_order = ORDER
    whitenoise = WHITENOISE

    ## Determine scale
    # Look at the first point
    x0 = alldata[0,:-1]
    # Find the distances between the first point and all other points
    dists = np.abs(X - x0)
    for dim in range(NDIM):
        mask = ~np.isclose(dists[:,dim], 0)
        dists = dists[mask]
    scale_1 = np.min(dists, axis=0)
    scale = scale_1 * SCALE_K

    print(f"Training SNR GP ({Y.size} pts)!")
    tic = time.perf_counter()
    gp = HybridGP(
        X,
        Y,
        Y_err,
        scale,
        whitenoise,
        msq_order,
    )
    toc = time.perf_counter()
    print(f"time: {toc-tic:.6f} s")
    print(gp(X))

    print(f"Training SNR GP ({Y.size} pts) with fit_compact!")
    tic = time.perf_counter()
    gp = fit_compact_nd(X,Y,order=ORDER,whitenoise=WHITENOISE)
    toc = time.perf_counter()
    print(f"time: {toc-tic:.6f} s")
    print(gp(X))
    return

if __name__ == "__main__":
    test_SNR_training()
