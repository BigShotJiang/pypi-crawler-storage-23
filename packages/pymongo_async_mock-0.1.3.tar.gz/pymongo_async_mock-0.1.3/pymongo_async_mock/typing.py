from typing import Any, Mapping, TypedDict

DocumentType = Mapping[str, Any]


class BuildInfo(TypedDict):
    ok: float
    version: str
    versionArray: list[int]
