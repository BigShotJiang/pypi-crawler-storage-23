# Introduction
This is a pymongo async version of mongomock-motor library created by [Michael Kryukov](https://github.com/michaelkryukov) that can be found [here](https://github.com/michaelkryukov/mongomock_motor)
