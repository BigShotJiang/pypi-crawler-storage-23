# Freshdesk changelog

## [0.1.1] - 2026-02-19
- Updated connector definition (YAML version 1.0.1)
- Source commit: 3f4da97b
- SDK version: 0.1.0

## [0.1.0] - 2026-02-19
- Updated connector definition (YAML version 1.0.1)
- Source commit: dfd45cc7
- SDK version: 0.1.0
