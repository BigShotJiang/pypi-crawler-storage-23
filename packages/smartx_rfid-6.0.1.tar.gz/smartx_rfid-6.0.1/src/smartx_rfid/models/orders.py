"""
RFID models for SMARTX Connector.

Defines the Tag and Event models for storing RFID reader data
with proper indexing and relationships.
"""

from sqlalchemy import Boolean, Column, Integer, String, Text, DateTime

from .mixin import Base, BaseMixin


class ReadersType(Base, BaseMixin):
    __tablename__ = "readers_type"

    # Primary key
    id = Column(Integer, primary_key=True, autoincrement=True)

    name = Column(String(100), nullable=False, index=True, unique=True)
    description = Column(Text, nullable=True)


class Readers(Base, BaseMixin):
    __tablename__ = "readers"

    # Primary key
    id = Column(Integer, primary_key=True, autoincrement=True)
    reader_type_id = Column(Integer, nullable=False, index=True)
    serial_number = Column(String(100), nullable=False, index=True, unique=True)
    hostname = Column(String(255), nullable=True, index=True)
    available = Column(Boolean, nullable=False, default=True, index=True)


class Orders(Base, BaseMixin):
    __tablename__ = "orders"

    # Primary key
    id = Column(Integer, primary_key=True, autoincrement=True)

    order_number = Column(Integer, nullable=False, index=True)
    client_name = Column(String(255), nullable=False, index=True)
    client_cnpj = Column(String(25), nullable=True, index=True)
    product_code = Column(String(100), nullable=False, index=True)
    product_description = Column(String(255), nullable=True, index=False)
    product_family = Column(String(255), nullable=True, index=False)

    reader_id = Column(Integer, nullable=True, index=True)

    mounted_at = Column(DateTime(timezone=True), nullable=True, index=True)
    tested_at = Column(DateTime(timezone=True), nullable=True, index=True)
    shipped_at = Column(DateTime(timezone=True), nullable=True, index=True)
    activated_at = Column(DateTime(timezone=True), nullable=True, index=True)

    created_by = Column(Integer, nullable=False, index=False)
    mounted_by = Column(Integer, nullable=True, index=False)
    tested_by = Column(Integer, nullable=True, index=False)
    shipped_by = Column(Integer, nullable=True, index=False)
    activated_by = Column(Integer, nullable=True, index=False)

    comments = Column(Text, nullable=True)
