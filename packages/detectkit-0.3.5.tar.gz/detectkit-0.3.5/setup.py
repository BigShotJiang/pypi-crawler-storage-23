"""Setup script for detectkit."""

from setuptools import setup

# All configuration is in pyproject.toml
setup()
