import os

def clear():
    os.system("cls" if os.name == "nt" else "clear")

def printloop(a, i):
    for _ in range(i):
        print(a)
