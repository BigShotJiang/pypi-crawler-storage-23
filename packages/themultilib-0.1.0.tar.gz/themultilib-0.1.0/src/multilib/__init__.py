from importlib.metadata import version, PackageNotFoundError

from .other import clear, printloop
from .calc import add, sub, multi, per, ctof
from .owner import newowner, showowner

try:
    __version__ = version("multilib")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = [
    "clear",
    "printloop",
    "add",
    "sub",
    "multi",
    "per",
    "ctof",
    "newowner",
    "showowner",
]