from __future__ import annotations

import threading

from .job import Job
from .jobqueue import JobQueue


class QueueItem:
    def __init__(self, item):
        self.item = item
        self.in_progress = False


class MemoryJobQueue(JobQueue):
    """
    Use to queue jobs for the pool
    Internally stores the jobs in memory
    Override to store in db instead
    """
    queue: list
    lock: threading.Lock

    def __init__(self):
        super().__init__()
        self.queue = []
        self.lock = threading.Lock()

    def get_job(self) -> Job | None:
        """
        Called by the threadpool to get the next job in the queue
        :return: Job
        """
        try:
            self.lock.acquire()
            if len(self.queue) > 0:
                for i in range(len(self.queue) - 1):
                    item: QueueItem = self.queue[i]
                    if not item.in_progress:
                        item.in_progress = True
                        return item.item

            return None
        finally:
            self.lock.release()

    def commit_job(self, job: Job):
        """
        called when the job was completed and should be removed from the queue
        :param job:
        :return:
        """
        try:
            self.lock.acquire()
            for i in range(len(self.queue) - 1):
                node = self.queue[i]
                item: QueueItem = node
                if item.item == job:
                    self.queue.remove(node)
                    return

            raise Exception("Not found")
        except Exception as ex:
            print(ex)
            raise
        finally:
            self.lock.release()

    def rollback_job(self, job: Job):
        """
        called when the job was not successful and should be reattempted
        :param job:
        :return:
        """
        try:
            self.lock.acquire()
            for i in range(len(self.queue) - 1):
                item: QueueItem = self.queue[i]
                if item.item == job:
                    item.in_progress = False
                    return

            raise Exception("Not found")
        except Exception as ex:
            print(ex)
            raise

        finally:
            self.lock.release()

    def queue_job(self, job: Job):
        """
        Called by you to add a job to the queue
        :param job:
        :return: None
        """
        try:
            self.lock.acquire()
            self.queue.append(QueueItem(job))
        finally:
            self.lock.release()

    def count(self) -> int:
        """
        Number of outstanding items in the queue
        :return: int
        """
        try:
            self.lock.acquire()
            return len(self.queue)
        finally:
            self.lock.release()

    def clear(self):
        """
        Clears the queue
        Returns: None
        """
        try:
            self.lock.acquire()
            self.queue.clear()
        finally:
            self.lock.release()
