# Installation

## From PyPI

```bash
pip install brinkhaustools
```

## From Source

```bash
git clone https://gitlab.com/brinkhaus/brinkhaustools.git
cd brinkhaustools
pip install -e .
```

## Optional Extras

| Extra  | What it adds                                    |
|--------|-------------------------------------------------|
| `rest` | Flask, Waitress, bcrypt -- needed for RestServer |
| `dev`  | pytest, mypy -- development tools                |
| `docs` | MkDocs, mkdocs-material -- documentation build   |

```bash
# Install with REST support
pip install -e ".[rest]"

# Install with all development tools
pip install -e ".[dev,rest,docs]"
```

## Requirements

- Python >= 3.10
- No external dependencies (stdlib only). Optional extras add Flask, pytest, etc.
