# brinkhaustools

Common infrastructure toolkit for Brinkhaus industrial applications.

## What is brinkhaustools?

`brinkhaustools` is a Python package providing reusable components with reusable components for industrial monitoring and control applications. It bundles software
aspects which https://www.brinkhaus-gmbh.de needed again and again for setting
up reliable, configurable small and bug applications, like configuring
logging, giving a central mechanism for app shutdown, app self disgnosis services,
connection to the brinkhaus software fleet management, giving software modules a
possibility to report their status, etc. .

It bundles:

- **App** -- central wiring object that connects all components
- **ShutdownHandler** -- graceful shutdown with signal handling and cleanup hooks
- **LoggingHelper** -- rotating file logs with an in-memory ring buffer
- **Settings** -- thread-safe JSON settings with hierarchical key access
- **SelfDiagnosisEngine** -- error/warning tracking with numeric codes and timeouts
- **StatusEngine** -- periodic status collection from pluggable sources
- **HeartbeatEngine** -- watchdog for detecting hung threads
- **VersionInformation** -- CI-generated version metadata
- **Fleet management** -- HTTPS-based reporting to BrinkhausFleetManager
- **RestServer** -- Flask + Waitress HTTP server with standard endpoints

## Quick Example

```python
from brinkhaustools.common import App

app = App(
    name="my-service",
    settings_path="data/settings/settings_main.json",
    fleet_config_path="fleetManagementData/config.json",
    version_file="helper/version.json",
)
app.start()
app.wait()  # blocks until shutdown
```

## Project Status

Version **0.2.1** -- Add full status snapshot reporting to fleet management.

License: MIT
