__version__ = "0.2.0"


class McpdxError(Exception):
    """Base exception for all mcpdx errors."""


__all__ = ["McpdxError", "__version__"]