from dataclasses import dataclass

from mcpdx.utils.naming import server_name_to_package, server_name_to_prefix


@dataclass
class ScaffoldContext:
    server_name: str           # e.g., "weather-mcp"
    service_name: str          # e.g., "weather" (derived from server_name)
    language: str              # "python" | "typescript"
    transport: str             # "stdio" | "http"
    template: str              # "api-wrapper" | "database" | "file-ops" | "minimal"
    description: str           # One-line description
    python_package: str        # e.g., "weather_mcp" (derived)
    tool_prefix: str           # e.g., "weather" (for tool naming convention)
    author: str                # From git config or prompt
    include_tests: bool = True
    include_docker: bool = False

    @classmethod
    def from_user_input(
        cls,
        server_name: str,
        language: str,
        transport: str,
        template: str,
        description: str,
        author: str = "",
    ) -> "ScaffoldContext":
        return cls(
            server_name=server_name,
            service_name=server_name_to_prefix(server_name),
            language=language,
            transport=transport,
            template=template,
            description=description,
            python_package=server_name_to_package(server_name),
            tool_prefix=server_name_to_prefix(server_name),
            author=author,
        )
