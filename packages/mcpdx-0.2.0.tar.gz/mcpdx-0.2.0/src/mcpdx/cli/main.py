import click
from mcpdx import __version__
from mcpdx.cli.init_cmd import init_cmd
from mcpdx.cli.test_cmd import test_cmd
from mcpdx.cli.dev_cmd import dev_cmd
from mcpdx.cli.sandbox_cmd import sandbox_cmd
from mcpdx.cli.validate_cmd import validate_cmd
from mcpdx.cli.eval_cmd import eval_cmd


@click.group()
@click.version_option(version=__version__, prog_name="mcpdx")
def cli():
    """Developer tools for MCP servers."""


cli.add_command(init_cmd)
cli.add_command(test_cmd)
cli.add_command(dev_cmd)
cli.add_command(sandbox_cmd)
cli.add_command(validate_cmd)
cli.add_command(eval_cmd)