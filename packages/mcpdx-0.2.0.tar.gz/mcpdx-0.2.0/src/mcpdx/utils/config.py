"""Load MCP Kit project configuration from pyproject.toml."""

from __future__ import annotations

import tomllib
from dataclasses import dataclass
from pathlib import Path

from mcpdx import McpdxError


class ConfigError(McpdxError):
    """Raised when project configuration is missing or invalid."""


@dataclass
class ProjectConfig:
    """Parsed [tool.mcpdx] configuration."""

    server_command: str
    fixtures_dir: str
    server_name: str
    container_runtime: str | None = None

    @property
    def fixtures_path(self) -> Path:
        return Path(self.fixtures_dir)


def _load_from_pyproject(root: Path) -> ProjectConfig | None:
    """Try loading config from pyproject.toml [tool.mcpdx] section."""
    pyproject = root / "pyproject.toml"
    if not pyproject.is_file():
        return None

    try:
        with open(pyproject, "rb") as f:
            data = tomllib.load(f)
    except tomllib.TOMLDecodeError as e:
        raise ConfigError(f"Invalid TOML in pyproject.toml: {e}")
    except (PermissionError, OSError) as e:
        raise ConfigError(f"Cannot read pyproject.toml: {e}")

    mcpdx_config = data.get("tool", {}).get("mcpdx")
    if mcpdx_config is None:
        return None

    server_command = mcpdx_config.get("server_command", "").strip()
    if not server_command:
        raise ConfigError(
            "Empty server_command in [tool.mcpdx].\n\n"
            "Provide a command to start your server:\n"
            '  [tool.mcpdx]\n'
            '  server_command = "python -m your_package.server"'
        )

    server_name = data.get("project", {}).get("name", "mcp-server")

    return ProjectConfig(
        server_command=server_command,
        fixtures_dir=mcpdx_config.get("fixtures_dir", "tests/fixtures"),
        server_name=server_name,
        container_runtime=mcpdx_config.get("container_runtime"),
    )


def _load_from_mcpdx_toml(root: Path) -> ProjectConfig | None:
    """Try loading config from standalone mcpdx.toml."""
    toml_file = root / "mcpdx.toml"
    if not toml_file.is_file():
        return None

    try:
        with open(toml_file, "rb") as f:
            data = tomllib.load(f)
    except tomllib.TOMLDecodeError as e:
        raise ConfigError(f"Invalid TOML in mcpdx.toml: {e}")
    except (PermissionError, OSError) as e:
        raise ConfigError(f"Cannot read mcpdx.toml: {e}")

    server_config = data.get("server", {})
    server_command = server_config.get("command", "").strip()
    if not server_command:
        return None

    server_name = server_config.get("name", "mcp-server")
    testing_config = data.get("testing", {})
    sandbox_config = data.get("sandbox", {})

    return ProjectConfig(
        server_command=server_command,
        fixtures_dir=testing_config.get("fixtures_dir", "tests/fixtures"),
        server_name=server_name,
        container_runtime=sandbox_config.get("runtime"),
    )


def load_config(project_dir: Path | None = None) -> ProjectConfig:
    """Load MCP Kit config from pyproject.toml or mcpdx.toml (defaults to CWD).

    Tries pyproject.toml [tool.mcpdx] first, then falls back to mcpdx.toml.
    Raises ConfigError with actionable messages on failure.
    """
    root = Path(project_dir) if project_dir else Path.cwd()

    config = _load_from_pyproject(root) or _load_from_mcpdx_toml(root)
    if config is not None:
        return config

    has_pyproject = (root / "pyproject.toml").is_file()
    has_mcpdx_toml = (root / "mcpdx.toml").is_file()

    if not has_pyproject and not has_mcpdx_toml:
        raise ConfigError(
            "No pyproject.toml or mcpdx.toml found in current directory.\n\n"
            "Are you in an MCP server project? Run this command from your project root,\n"
            "or create a new project with: mcpdx init"
        )

    if has_pyproject:
        raise ConfigError(
            "No [tool.mcpdx] section found in pyproject.toml.\n\n"
            "Add the following to your pyproject.toml:\n"
            '  [tool.mcpdx]\n'
            '  server_command = "python -m your_package.server"\n'
            '  fixtures_dir = "tests/fixtures"'
        )

    raise ConfigError(
        "mcpdx.toml is missing [server] section with 'command'.\n\n"
        "Add the following to your mcpdx.toml:\n"
        '  [server]\n'
        '  name = "my-server"\n'
        '  command = "node dist/server.js"\n\n'
        "  [testing]\n"
        '  fixtures_dir = "tests/fixtures"'
    )
