library flet_video;

export "src/extension.dart" show Extension;
