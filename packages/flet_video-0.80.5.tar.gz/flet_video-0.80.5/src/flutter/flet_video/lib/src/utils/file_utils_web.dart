/// On web, local‐path reading isn’t supported. Always returns null.
String? readFileAsStringIfExists(String path) {
  return null;
}
