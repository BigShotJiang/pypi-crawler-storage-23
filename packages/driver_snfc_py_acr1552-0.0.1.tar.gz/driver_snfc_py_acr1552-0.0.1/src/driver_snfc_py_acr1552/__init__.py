# SPDX-FileCopyrightText: 2026-present EnautFer <enautfernandezs@gmail.com>
#
# SPDX-License-Identifier: MIT
