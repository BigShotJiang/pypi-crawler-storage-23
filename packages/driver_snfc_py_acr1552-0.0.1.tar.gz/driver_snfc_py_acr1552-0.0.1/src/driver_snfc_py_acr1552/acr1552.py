import logging
import sys
from time import sleep

from smartcard.scard import (
    SCARD_CTL_CODE, SCARD_SHARE_DIRECT, SCARD_RESET_CARD,
    SCARD_SHARE_SHARED, SCARD_PROTOCOL_T1, SCARD_PROTOCOL_T0
)
from smartcard.System import readers

logger = logging.getLogger(__name__)


class Acr1552:

    def __init__(self):
        self.conn = None
        self.power_status = False

    def connect(self):
        r = readers()
        if not r:
            logger.warning("No card readers found.")
            return False
        self.conn = r[0].createConnection()
        try:
            self.conn.connect(mode=SCARD_SHARE_DIRECT, disposition=SCARD_RESET_CARD)
        except Exception:
            self.conn.connect(mode=SCARD_SHARE_SHARED, protocol=SCARD_PROTOCOL_T1 | SCARD_PROTOCOL_T0)
            self.conn.reconnect(mode=SCARD_SHARE_DIRECT, disposition=SCARD_RESET_CARD)
        return True

    def disconnect(self):
        self.conn.disconnect()

    def get_uid(self):
        try:
            if not self.power_status:
                self.set_power(True)
            apdu = [0xFF, 0xCA, 0x00, 0x00, 0x00]
            data, sw1, sw2 = self.conn.transmit(apdu)
            if sw1 == 0x90 and sw2 == 0x00:
                uid = data[0:9]
                return uid
            else:
                logger.debug(f"Error reading UID: SW1={hex(sw1)}, SW2={hex(sw2)}")
                return None
        except Exception as e:
            logger.debug(f"Error: {e}")
            return None

    def read_data(self, start_block, n_blocks):
        try:
            length = n_blocks * 4
            apdu = [0xFF, 0xB0, 0x00, start_block, length]
            data, sw1, sw2 = self.conn.transmit(apdu)
            if sw1 == 0x90 and sw2 == 0x00:
                return data
            else:
                logger.debug(f"Error reading memory: SW1={hex(sw1)}, SW2={hex(sw2)}")
                return None
        except Exception as e:
            logger.debug(f"Error: {e}")
            return None

    def write_data(self, start_block, wdata):
        try:
            if len(wdata) % 4:
                logger.warning('wdata length is not a multiple of 4')
                return False
            apdu = [0xFF, 0xD6, 0x00, start_block, len(wdata)] + wdata
            data, sw1, sw2 = self.conn.transmit(apdu)
            if sw1 == 0x90 and sw2 == 0x00:
                return True
            else:
                logger.debug(f"Error writing memory: SW1={hex(sw1)}, SW2={hex(sw2)}")
                return False
        except Exception as e:
            logger.debug(f"Error: {e}")
            return False

    def change_fw_mode(self, mode: bool):
        try:
            if mode:
                return self.write_data(51, [0xAA, 0, 0, 0])
            else:
                return self.write_data(51, [0, 0, 0, 0])
        except Exception as e:
            logger.debug(f"Error: {e}")
            return False

    def set_power(self, status: bool):
        try:
            control_code = SCARD_CTL_CODE(3500) if sys.platform == 'win32' else 0x42000000 + 3500
            val = 0x01 if status else 0x00
            command = [0xE0, 0x00, 0x00, 0x25, 0x01, val]
            self.conn.control(control_code, command)
            logger.debug(f"RF field {'on' if status else 'off'}.")
            if status:
                sleep(0.2)
                self.conn.reconnect(mode=SCARD_SHARE_DIRECT, disposition=SCARD_RESET_CARD)
                self.power_status = True
            else:
                self.power_status = False
            return True
        except Exception as e:
            logger.debug(f"Error in set_power: {e}")
            return False
