"""
Script de test para ACR1552.
Ejecuta las funciones principales del lector y muestra los resultados por consola.
No requiere threads, GUI ni main loop infinito.
"""

import logging
import struct
from time import sleep

from driver_snfc_py_acr1552.acr1552 import Acr1552

# Configurar logging para ver mensajes de debug
logging.basicConfig(level=logging.DEBUG, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Helpers (extraídos/simplificados de app.py)
# ---------------------------------------------------------------------------

def convert_to_uint(raw_bytes, size=2, big_endian=False):
    """Convierte lista de bytes a lista de enteros (uint16 o uint32)."""
    if raw_bytes is None:
        return None
    fmt_char = "H" if size == 2 else "I"
    endian = ">" if big_endian else "<"
    result = []
    for i in range(0, len(raw_bytes) - size + 1, size):
        value = struct.unpack(f"{endian}{fmt_char}", bytes(raw_bytes[i:i + size]))[0]
        result.append(value)
    return result


def parse_ndef_message(raw_bytes):
    """Parseo básico de un mensaje NDEF (simplificado)."""
    if raw_bytes is None or len(raw_bytes) < 8:
        return None
    try:
        # Buscar inicio de NDEF (byte 0x03 = TLV NDEF Message)
        start = None
        for i, b in enumerate(raw_bytes):
            if b == 0x03:
                start = i
                break
        if start is None:
            return {"type": "RAW", "content": bytes(raw_bytes).hex()}

        length = raw_bytes[start + 1]
        ndef_payload = raw_bytes[start + 2 : start + 2 + length]

        # Intentar extraer texto/URL del payload
        if len(ndef_payload) > 3:
            tnf = ndef_payload[0] & 0x07
            type_len = ndef_payload[1]
            payload_len = ndef_payload[2]
            rec_type = bytes(ndef_payload[3 : 3 + type_len])

            payload_start = 3 + type_len
            payload = ndef_payload[payload_start : payload_start + payload_len]

            if rec_type == b"U":  # URI
                uri_prefix = {
                    0x00: "", 0x01: "http://www.", 0x02: "https://www.",
                    0x03: "http://", 0x04: "https://",
                }
                prefix = uri_prefix.get(payload[0], "") if payload else ""
                uri = prefix + bytes(payload[1:]).decode("utf-8", errors="replace")
                return {"type": "URL", "content": uri}
            elif rec_type == b"T":  # Text
                lang_len = payload[0] & 0x3F
                text = bytes(payload[1 + lang_len:]).decode("utf-8", errors="replace")
                return {"type": "TEXT", "content": text}
            else:
                return {"type": rec_type.decode(errors="replace"), "content": bytes(payload).hex()}

        return {"type": "RAW", "content": bytes(ndef_payload).hex()}
    except Exception as e:
        logger.warning(f"Error parseando NDEF: {e}")
        return {"type": "RAW", "content": bytes(raw_bytes).hex()}


def bytes_to_hex(data):
    """Formatea lista de bytes como string hexadecimal legible."""
    if data is None:
        return "None"
    return " ".join(f"{b:02X}" for b in data)


# ---------------------------------------------------------------------------
# Bloques de test
# ---------------------------------------------------------------------------

def test_connect(reader):
    print("\n" + "=" * 60)
    print("TEST: connect()")
    print("=" * 60)
    ok = reader.connect()
    print(f"  Resultado: {'OK' if ok else 'FALLO'}")
    return ok


def test_set_power(reader, on=True):
    label = "ON" if on else "OFF"
    print(f"\n--- set_power({label}) ---")
    ok = reader.set_power(on)
    print(f"  Resultado: {'OK' if ok else 'FALLO'}")
    return ok


def test_get_uid(reader):
    print("\n--- get_uid() ---")
    uid = reader.get_uid()
    if uid:
        print(f"  UID: {bytes_to_hex(uid)}")
    else:
        print("  No se detectó tag (UID = None)")
    return uid


def test_read_data(reader, start_block, n_blocks, label=""):
    print(f"\n--- read_data(start={start_block}, blocks={n_blocks}) {label} ---")
    data = reader.read_data(start_block, n_blocks)
    if data:
        print(f"  Raw ({len(data)} bytes): {bytes_to_hex(data)}")
        # Mostrar como uint16 little-endian
        as_uint16 = convert_to_uint(data, size=2, big_endian=False)
        if as_uint16:
            print(f"  uint16 LE: {as_uint16}")
    else:
        print("  Sin datos (None)")
    return data


def test_read_ndef(reader):
    """Lee los bloques NDEF y parsea el mensaje."""
    NDEF_BASE = 0
    NDEF_NBLOCKS = 12
    print(f"\n--- Lectura NDEF (bloques {NDEF_BASE}-{NDEF_BASE + NDEF_NBLOCKS - 1}) ---")
    data = reader.read_data(NDEF_BASE, NDEF_NBLOCKS)
    if data:
        print(f"  Raw ({len(data)} bytes): {bytes_to_hex(data)}")
        msg = parse_ndef_message(data)
        if msg:
            print(f"  Tipo:      {msg['type']}")
            print(f"  Contenido: {msg['content']}")
        else:
            print("  No se pudo parsear mensaje NDEF")
    else:
        print("  Sin datos NDEF")
    return data


def test_read_bulk_index(reader):
    """Lee el bloque de índice (bloque 50) usado en modo BULK."""
    IDX_BLOCK = 50
    print(f"\n--- Índice BULK (bloque {IDX_BLOCK}) ---")
    data = reader.read_data(IDX_BLOCK, 1)
    if data:
        idx = convert_to_uint(data, size=4, big_endian=False)
        print(f"  Raw: {bytes_to_hex(data)}")
        print(f"  Índice (uint32 LE): {idx}")
    else:
        print("  No se pudo leer índice")
    return data


def test_read_bulk_data(reader):
    """Lee los 50 bloques de datos BULK y muestra como uint16."""
    DATA_BASE = 0
    DATA_NBLOCKS = 50
    print(f"\n--- Datos BULK (bloques {DATA_BASE}-{DATA_BASE + DATA_NBLOCKS - 1}) ---")
    data = reader.read_data(DATA_BASE, DATA_NBLOCKS)
    if data:
        values = convert_to_uint(data, size=2, big_endian=False)
        if values:
            # Separar canales intercalados: temp(par), hum(impar)
            temp_raw = values[0::2]
            hum_raw = values[1::2]
            # Interpretar como int16 con signo y escalar
            import numpy as np
            temp_c = np.array(temp_raw, dtype=np.int16).astype(np.float32) / 100.0
            hum_pct = np.array(hum_raw, dtype=np.int16).astype(np.float32) / 100.0
            print(f"  Total valores uint16: {len(values)}")
            print(f"  Temperatura (°C) - primeros 10: {temp_c[:10].tolist()}")
            print(f"  Humedad (%RH)    - primeros 10: {hum_pct[:10].tolist()}")
        else:
            print(f"  Raw ({len(data)} bytes): {bytes_to_hex(data[:64])} ...")
    else:
        print("  No se pudieron leer datos BULK")
    return data


def test_change_fw_mode(reader, bulk=True):
    label = "BULK" if bulk else "NDEF"
    print(f"\n--- change_fw_mode({bulk}) -> modo {label} ---")
    ok = reader.change_fw_mode(bulk)
    print(f"  Resultado: {'OK' if ok else 'FALLO'}")
    return ok


def test_write_read_back(reader, block=48):
    """Escribe 4 bytes de prueba y los lee de vuelta."""
    test_data = [0xDE, 0xAD, 0xBE, 0xEF]
    print(f"\n--- write_data(bloque={block}, data={bytes_to_hex(test_data)}) ---")
    ok = reader.write_data(block, test_data)
    print(f"  Escritura: {'OK' if ok else 'FALLO'}")
    if ok:
        readback = reader.read_data(block, 1)
        print(f"  Lectura de verificación: {bytes_to_hex(readback)}")
        if readback and readback[:4] == test_data:
            print("  ✓ Verificación correcta")
        else:
            print("  ✗ Los datos no coinciden")
    return ok


# ---------------------------------------------------------------------------
# Menú principal
# ---------------------------------------------------------------------------

def print_menu():
    print("\n" + "=" * 60)
    print("  TEST ACR1552 - Menú")
    print("=" * 60)
    print("  1. Encender RF (set_power ON)")
    print("  2. Apagar RF (set_power OFF)")
    print("  3. Leer UID del tag")
    print("  4. Leer bloque(s) arbitrario(s)")
    print("  5. Leer mensaje NDEF")
    print("  6. Leer índice BULK (bloque 50)")
    print("  7. Leer datos BULK (bloques 0-49)")
    print("  8. Cambiar a modo BULK")
    print("  9. Cambiar a modo NDEF")
    print(" 10. Escribir y verificar bloque de prueba")
    print(" 11. Test completo (ejecuta todo en secuencia)")
    print("  0. Salir")
    print("-" * 60)


def run_interactive(reader):
    while True:
        print_menu()
        try:
            choice = input("Selecciona opción: ").strip()
        except (EOFError, KeyboardInterrupt):
            break

        if choice == "1":
            test_set_power(reader, True)
        elif choice == "2":
            test_set_power(reader, False)
        elif choice == "3":
            test_get_uid(reader)
        elif choice == "4":
            try:
                sb = int(input("  Bloque inicial: "))
                nb = int(input("  Número de bloques: "))
                test_read_data(reader, sb, nb)
            except ValueError:
                print("  Entrada inválida")
        elif choice == "5":
            test_read_ndef(reader)
        elif choice == "6":
            test_read_bulk_index(reader)
        elif choice == "7":
            test_read_bulk_data(reader)
        elif choice == "8":
            test_change_fw_mode(reader, bulk=True)
        elif choice == "9":
            test_change_fw_mode(reader, bulk=False)
        elif choice == "10":
            test_write_read_back(reader)
        elif choice == "11":
            run_full_test(reader)
        elif choice == "0":
            break
        else:
            print("  Opción no válida")


def run_full_test(reader):
    """Ejecuta una secuencia completa de tests."""
    print("\n" + "=" * 60)
    print("  EJECUTANDO TEST COMPLETO")
    print("=" * 60)

    # 1. RF ON
    test_set_power(reader, True)
    sleep(0.3)

    # 2. UID
    uid = test_get_uid(reader)
    if uid is None:
        print("\n⚠ No hay tag presente. Coloca un tag y vuelve a intentar.")
        return

    # 3. Modo NDEF - leer mensaje
    test_change_fw_mode(reader, bulk=False)
    sleep(0.3)
    test_set_power(reader, True)
    sleep(0.3)
    test_read_ndef(reader)

    # 4. Modo BULK - leer índice y datos
    test_change_fw_mode(reader, bulk=True)
    sleep(0.3)
    test_set_power(reader, True)
    sleep(0.3)
    test_read_bulk_index(reader)
    test_read_bulk_data(reader)

    # 5. Write/read test
    test_write_read_back(reader, block=48)

    # 6. Volver a NDEF y apagar
    test_change_fw_mode(reader, bulk=False)

    print("\n" + "=" * 60)
    print("  TEST COMPLETO FINALIZADO")
    print("=" * 60)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    reader = Acr1552()

    print("Conectando al lector ACR1552...")
    if not test_connect(reader):
        print("No se pudo conectar al lector. ¿Está conectado?")
        exit(1)

    try:
        run_interactive(reader)
    except Exception as e:
        logger.exception(f"Error inesperado: {e}")
    finally:
        print("\nDesconectando...")
        try:
            reader.set_power(True)  # Dejar RF encendido (como en app.py disconnect)
            reader.disconnect()
        except Exception:
            pass
        print("Hecho.")