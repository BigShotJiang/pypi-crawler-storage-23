"""Database layer for scan history, feedback, and audit logging."""
