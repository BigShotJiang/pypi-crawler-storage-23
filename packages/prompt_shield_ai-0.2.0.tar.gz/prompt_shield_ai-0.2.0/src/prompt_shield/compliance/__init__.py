"""OWASP compliance mapping for prompt-shield."""
