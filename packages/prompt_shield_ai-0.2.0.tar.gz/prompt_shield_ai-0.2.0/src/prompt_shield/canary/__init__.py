"""Canary token generation and leak detection."""
