"""Attack intelligence vault — self-learning vector similarity storage."""
