"""User feedback and auto-tuning for detector thresholds."""
