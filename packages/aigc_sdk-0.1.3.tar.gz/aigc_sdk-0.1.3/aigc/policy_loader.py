from aigc._internal.policy_loader import load_policy

__all__ = ["load_policy"]
