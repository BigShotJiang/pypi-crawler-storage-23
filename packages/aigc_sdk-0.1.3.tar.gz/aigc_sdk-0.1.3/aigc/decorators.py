"""Public API wrapper for the @governed decorator."""

from aigc._internal.decorators import governed

__all__ = ["governed"]
