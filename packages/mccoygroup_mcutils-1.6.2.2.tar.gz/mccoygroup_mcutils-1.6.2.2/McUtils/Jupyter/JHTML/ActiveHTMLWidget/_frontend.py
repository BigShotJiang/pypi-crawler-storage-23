#!/usr/bin/env python
# coding: utf-8

# Copyright (c) b3m2a1.
# Distributed under the terms of the Modified BSD License.

"""
Information about the frontend package of the widgets.
"""

module_name = "ActiveHTMLWidget"
module_version = "^0.1.0"
