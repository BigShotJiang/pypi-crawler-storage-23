"""Tests for remote_config init_config() behavior."""

import json
import os

import pytest

from greatsky_internal_metaflow import config as gsm_config
from metaflow_extensions.greatsky import remote_config

FAKE_REMOTE_CONFIG = {
    "METAFLOW_DEFAULT_DATASTORE": "s3",
    "METAFLOW_DATASTORE_SYSROOT_S3": "s3://bucket/metaflow",
    "METAFLOW_DEFAULT_METADATA": "service",
    "METAFLOW_SERVICE_URL": "https://metaflow-api.example.com/",
    "METAFLOW_SERVICE_INTERNAL_URL": "http://internal:8080/",
    "METAFLOW_KUBERNETES_NAMESPACE": "metaflow-jobs",
    "METAFLOW_KUBERNETES_SERVICE_ACCOUNT": "metaflow-worker",
    "METAFLOW_KUBERNETES_CONTAINER_IMAGE": "ecr/ml-worker:latest",
    "METAFLOW_KUBERNETES_NODE_SELECTOR": "compute=cpu",
}

FAKE_API_RESPONSE = {
    "domain": "example.com",
    "github_org": "test-org",
    "github_client_id": "test123",
    "auth_url": "https://auth.example.com",
    "metaflow_config": FAKE_REMOTE_CONFIG,
}


@pytest.fixture(autouse=True)
def clean_env():
    """Remove env cache before each test."""
    os.environ.pop(remote_config.ENV_CACHE_KEY, None)
    yield
    os.environ.pop(remote_config.ENV_CACHE_KEY, None)


def _make_gsm_dir(tmp_path, config_data, creds_data=None):
    """Create a GSM dir with config.json and optionally credentials.json."""
    gsm_dir = tmp_path / ".greatsky_gsm"
    gsm_dir.mkdir()
    (gsm_dir / "config.json").write_text(json.dumps(config_data))
    if creds_data:
        (gsm_dir / "credentials.json").write_text(json.dumps(creds_data))
    return gsm_dir


# ---- Test 1: Cache hit returns cached config + re-reads key from disk ----


def test_cache_hit_returns_cached(tmp_path, monkeypatch):
    gsm_dir = _make_gsm_dir(
        tmp_path,
        {"GSM_AUTH_API": "https://auth.example.com", "METAFLOW_SERVICE_AUTH_KEY": "gsk_disk_key"},
    )
    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)

    cached = {"METAFLOW_SERVICE_URL": "https://cached.example.com/", "METAFLOW_USER": "cached-user"}
    os.environ[remote_config.ENV_CACHE_KEY] = json.dumps(cached)

    result = remote_config.init_config()
    assert result["METAFLOW_SERVICE_URL"] == "https://cached.example.com/"
    assert result["METAFLOW_USER"] == "cached-user"
    assert result["METAFLOW_SERVICE_AUTH_KEY"] == "gsk_disk_key"


# ---- Test 2: Cache miss fetches from API and merges ----


def test_cache_miss_fetches_and_merges(tmp_path, monkeypatch):
    gsm_dir = _make_gsm_dir(
        tmp_path,
        {"GSM_AUTH_API": "https://auth.example.com", "METAFLOW_SERVICE_AUTH_KEY": "gsk_test123"},
        {"github_user": "alice", "expires_at": "2099-01-01T00:00:00Z"},
    )
    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)

    class FakeResponse:
        status_code = 200

        def raise_for_status(self):
            pass

        def json(self):
            return FAKE_API_RESPONSE

    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, **kw: FakeResponse())

    result = remote_config.init_config()

    assert result["METAFLOW_SERVICE_URL"] == "https://metaflow-api.example.com/"
    assert result["METAFLOW_SERVICE_AUTH_KEY"] == "gsk_test123"
    assert result["METAFLOW_USER"] == "alice"
    assert result["METAFLOW_KUBERNETES_NAMESPACE"] == "metaflow-jobs"

    assert remote_config.ENV_CACHE_KEY in os.environ
    env_cached = json.loads(os.environ[remote_config.ENV_CACHE_KEY])
    assert "METAFLOW_SERVICE_AUTH_KEY" not in env_cached, "API key must not be in env cache"
    assert (gsm_dir / "config_cache.json").exists()


# ---- Test 3: METAFLOW_USER set from credentials ----


def test_user_set_from_credentials(tmp_path, monkeypatch):
    gsm_dir = _make_gsm_dir(
        tmp_path,
        {"GSM_AUTH_API": "https://auth.example.com", "METAFLOW_SERVICE_AUTH_KEY": "gsk_test"},
        {"github_user": "bob", "expires_at": "2099-01-01T00:00:00Z"},
    )
    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.delenv("METAFLOW_USER", raising=False)

    class FakeResponse:
        status_code = 200

        def raise_for_status(self):
            pass

        def json(self):
            return FAKE_API_RESPONSE

    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, **kw: FakeResponse())

    result = remote_config.init_config()
    assert result["METAFLOW_USER"] == "bob"


# ---- Test 4: Env var override beats credentials for USER ----


def test_env_var_overrides_user(tmp_path, monkeypatch):
    gsm_dir = _make_gsm_dir(
        tmp_path,
        {"GSM_AUTH_API": "https://auth.example.com", "METAFLOW_SERVICE_AUTH_KEY": "gsk_test"},
        {"github_user": "bob", "expires_at": "2099-01-01T00:00:00Z"},
    )
    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.setenv("METAFLOW_USER", "service-account")

    class FakeResponse:
        status_code = 200

        def raise_for_status(self):
            pass

        def json(self):
            return FAKE_API_RESPONSE

    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, **kw: FakeResponse())

    result = remote_config.init_config()
    assert "METAFLOW_USER" not in result


# ---- Test 5: Expiry warning when key expires within 24h ----


def test_expiry_warning(tmp_path, monkeypatch, capsys):
    from datetime import datetime, timedelta, timezone

    expires_soon = (datetime.now(timezone.utc) + timedelta(hours=6)).strftime("%Y-%m-%dT%H:%M:%SZ")

    gsm_dir = _make_gsm_dir(
        tmp_path,
        {"GSM_AUTH_API": "https://auth.example.com", "METAFLOW_SERVICE_AUTH_KEY": "gsk_test"},
        {"github_user": "alice", "expires_at": expires_soon},
    )
    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.delenv("METAFLOW_USER", raising=False)

    class FakeResponse:
        status_code = 200

        def raise_for_status(self):
            pass

        def json(self):
            return FAKE_API_RESPONSE

    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, **kw: FakeResponse())

    remote_config.init_config()

    captured = capsys.readouterr()
    assert "expires in" in captured.err
    assert "gsm login" in captured.err


# ---- Test 6: Graceful fallback to local cache if API unreachable ----


def test_fallback_to_cache_file(tmp_path, monkeypatch):
    gsm_dir = _make_gsm_dir(
        tmp_path,
        {"GSM_AUTH_API": "https://auth.example.com", "METAFLOW_SERVICE_AUTH_KEY": "gsk_test"},
        {"github_user": "alice", "expires_at": "2099-01-01T00:00:00Z"},
    )
    (gsm_dir / "config_cache.json").write_text(json.dumps(FAKE_REMOTE_CONFIG))

    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.delenv("METAFLOW_USER", raising=False)

    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, **kw: (_ for _ in ()).throw(httpx.ConnectError("offline")))

    result = remote_config.init_config()

    assert result["METAFLOW_SERVICE_URL"] == "https://metaflow-api.example.com/"
    assert result["METAFLOW_SERVICE_AUTH_KEY"] == "gsk_test"
    assert result["METAFLOW_USER"] == "alice"


# ---- Test 7: Fresh file cache avoids HTTP call entirely ----


def test_fresh_cache_skips_fetch(tmp_path, monkeypatch):
    """When config_cache.json is newer than CACHE_TTL_SECONDS, no HTTP call is made."""
    gsm_dir = _make_gsm_dir(
        tmp_path,
        {"GSM_AUTH_API": "https://auth.example.com", "METAFLOW_SERVICE_AUTH_KEY": "gsk_test"},
        {"github_user": "carol", "expires_at": "2099-01-01T00:00:00Z"},
    )
    (gsm_dir / "config_cache.json").write_text(json.dumps(FAKE_REMOTE_CONFIG))

    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.delenv("METAFLOW_USER", raising=False)

    fetch_called = []
    import httpx

    def _bad_fetch(url, **kw):
        fetch_called.append(url)
        raise httpx.ConnectError("should not be called")

    monkeypatch.setattr(httpx, "get", _bad_fetch)

    result = remote_config.init_config()

    assert result["METAFLOW_SERVICE_URL"] == "https://metaflow-api.example.com/"
    assert result["METAFLOW_USER"] == "carol"
    assert fetch_called == [], "HTTP call should have been skipped for fresh cache"


# ---- Test 8: Stale cache triggers fresh fetch ----


def test_stale_cache_triggers_fetch(tmp_path, monkeypatch):
    """When config_cache.json is older than CACHE_TTL_SECONDS, fetch is attempted."""
    import time as _time

    gsm_dir = _make_gsm_dir(
        tmp_path,
        {"GSM_AUTH_API": "https://auth.example.com", "METAFLOW_SERVICE_AUTH_KEY": "gsk_test"},
        {"github_user": "carol", "expires_at": "2099-01-01T00:00:00Z"},
    )
    cache_path = gsm_dir / "config_cache.json"
    cache_path.write_text(json.dumps(FAKE_REMOTE_CONFIG))

    old_mtime = _time.time() - remote_config.CACHE_TTL_SECONDS - 100
    os.utime(cache_path, (old_mtime, old_mtime))

    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.delenv("METAFLOW_USER", raising=False)

    class FakeResponse:
        status_code = 200

        def raise_for_status(self):
            pass

        def json(self):
            return FAKE_API_RESPONSE

    fetch_called = []
    import httpx

    def _track_fetch(url, **kw):
        fetch_called.append(url)
        return FakeResponse()

    monkeypatch.setattr(httpx, "get", _track_fetch)

    result = remote_config.init_config()

    assert result["METAFLOW_SERVICE_URL"] == "https://metaflow-api.example.com/"
    assert len(fetch_called) == 1, "Stale cache should trigger one HTTP fetch"


# ---- Test 9: Env cache never contains the API key ----


def test_env_cache_excludes_api_key(tmp_path, monkeypatch):
    """The API key must not be stored in the env-var cache."""
    gsm_dir = _make_gsm_dir(
        tmp_path,
        {"GSM_AUTH_API": "https://auth.example.com", "METAFLOW_SERVICE_AUTH_KEY": "gsk_secret"},
        {"github_user": "dave", "expires_at": "2099-01-01T00:00:00Z"},
    )
    (gsm_dir / "config_cache.json").write_text(json.dumps(FAKE_REMOTE_CONFIG))
    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.delenv("METAFLOW_USER", raising=False)

    result = remote_config.init_config()

    assert result["METAFLOW_SERVICE_AUTH_KEY"] == "gsk_secret"

    env_cached = json.loads(os.environ[remote_config.ENV_CACHE_KEY])
    assert "METAFLOW_SERVICE_AUTH_KEY" not in env_cached


# ---- Test 10: Fetch passes API key as X-Api-Key header ----


def test_fetch_sends_api_key_header(tmp_path, monkeypatch):
    """The remote config fetch must send the API key in X-Api-Key header."""
    import time as _time

    gsm_dir = _make_gsm_dir(
        tmp_path,
        {"GSM_AUTH_API": "https://auth.example.com", "METAFLOW_SERVICE_AUTH_KEY": "gsk_mykey"},
        {"github_user": "eve", "expires_at": "2099-01-01T00:00:00Z"},
    )
    cache_path = gsm_dir / "config_cache.json"
    cache_path.write_text(json.dumps(FAKE_REMOTE_CONFIG))
    old_mtime = _time.time() - remote_config.CACHE_TTL_SECONDS - 100
    os.utime(cache_path, (old_mtime, old_mtime))

    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.delenv("METAFLOW_USER", raising=False)

    captured_headers = []

    class FakeResponse:
        status_code = 200

        def raise_for_status(self):
            pass

        def json(self):
            return FAKE_API_RESPONSE

    import httpx

    def _capture_fetch(url, **kw):
        captured_headers.append(kw.get("headers", {}))
        return FakeResponse()

    monkeypatch.setattr(httpx, "get", _capture_fetch)

    remote_config.init_config()

    assert len(captured_headers) == 1
    assert captured_headers[0].get("X-Api-Key") == "gsk_mykey"
