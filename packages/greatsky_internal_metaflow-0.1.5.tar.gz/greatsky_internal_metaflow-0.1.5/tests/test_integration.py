"""Integration test: full init_config flow with mocked HTTP."""

import json
import os

from greatsky_internal_metaflow import config as gsm_config
from metaflow_extensions.greatsky import remote_config

FAKE_REMOTE_CONFIG = {
    "METAFLOW_DEFAULT_DATASTORE": "s3",
    "METAFLOW_DATASTORE_SYSROOT_S3": "s3://bucket/metaflow",
    "METAFLOW_DEFAULT_METADATA": "service",
    "METAFLOW_SERVICE_URL": "https://metaflow-api.gr8sky.dev/",
    "METAFLOW_SERVICE_INTERNAL_URL": "http://internal:8080/",
    "METAFLOW_KUBERNETES_NAMESPACE": "metaflow-jobs",
    "METAFLOW_KUBERNETES_SERVICE_ACCOUNT": "metaflow-worker",
    "METAFLOW_KUBERNETES_CONTAINER_IMAGE": "ecr/ml-worker:latest",
    "METAFLOW_KUBERNETES_NODE_SELECTOR": "compute=cpu",
}


def test_full_init_config_flow(tmp_path, monkeypatch):
    """Simulate the full flow: minimal config + credentials -> init_config -> full config."""
    os.environ.pop(remote_config.ENV_CACHE_KEY, None)

    gsm_dir = tmp_path / ".greatsky_gsm"
    gsm_dir.mkdir()
    (gsm_dir / "config.json").write_text(
        json.dumps(
            {
                "GSM_AUTH_API": "https://auth.gr8sky.dev",
                "METAFLOW_SERVICE_AUTH_KEY": "gsk_integration_test",
            }
        )
    )
    (gsm_dir / "credentials.json").write_text(
        json.dumps(
            {
                "api_key": "gsk_integration_test",
                "github_user": "wade",
                "name": "Wade",
                "access_type": "org_member",
                "expires_at": "2099-12-31T00:00:00Z",
            }
        )
    )

    monkeypatch.setattr(gsm_config, "resolve_gsm_dir", lambda: gsm_dir)
    monkeypatch.delenv("METAFLOW_USER", raising=False)

    class FakeResponse:
        status_code = 200

        def raise_for_status(self):
            pass

        def json(self):
            return {"metaflow_config": FAKE_REMOTE_CONFIG}

    import httpx

    monkeypatch.setattr(httpx, "get", lambda url, **kw: FakeResponse())

    result = remote_config.init_config()

    assert result["METAFLOW_SERVICE_URL"] == "https://metaflow-api.gr8sky.dev/"
    assert result["METAFLOW_DATASTORE_SYSROOT_S3"] == "s3://bucket/metaflow"
    assert result["METAFLOW_DEFAULT_DATASTORE"] == "s3"
    assert result["METAFLOW_DEFAULT_METADATA"] == "service"
    assert result["METAFLOW_SERVICE_AUTH_KEY"] == "gsk_integration_test"
    assert result["METAFLOW_USER"] == "wade"

    assert remote_config.ENV_CACHE_KEY in os.environ
    assert (gsm_dir / "config_cache.json").exists()

    # Second call should hit env cache
    monkeypatch.setattr(httpx, "get", lambda url, **kw: (_ for _ in ()).throw(Exception("should not be called")))
    result2 = remote_config.init_config()
    assert result2 == result

    os.environ.pop(remote_config.ENV_CACHE_KEY, None)
