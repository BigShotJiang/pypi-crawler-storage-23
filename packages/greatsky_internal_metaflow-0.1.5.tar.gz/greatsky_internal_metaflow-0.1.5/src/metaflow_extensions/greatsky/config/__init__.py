"""GreatSky config extension — injects remote platform config into metaflow_config.

Metaflow's config extension point runs at the END of metaflow_config.py, after all
from_conf() calls have already evaluated. The extension processing copies non-dunder,
non-module globals from this module into metaflow_config's namespace (line 659-660).
We exploit this by resolving the full platform config here and exposing each value
as a module-level global with the METAFLOW_ prefix stripped, matching the names
that from_conf() would have produced.
"""


def _apply():
    import metaflow.metaflow_config_funcs as mf_funcs

    from metaflow_extensions.greatsky.remote_config import init_config

    config = init_config()

    # Populate METAFLOW_CONFIG so any future from_conf() calls use it
    mf_funcs.METAFLOW_CONFIG = config
    mf_funcs.init_config = init_config

    # Inject each METAFLOW_* value as a module global (prefix stripped) so that
    # metaflow_config.py's extension processing overwrites the from_conf() results.
    for key, value in config.items():
        if key.startswith("METAFLOW_") and value is not None:
            globals()[key[9:]] = value


_apply()
del _apply
