"""GitHub Device Flow authentication and platform token exchange."""

from __future__ import annotations

import time
from dataclasses import dataclass

import httpx

from greatsky_internal_metaflow import settings


@dataclass
class DeviceCode:
    device_code: str
    user_code: str
    verification_uri: str
    expires_in: int
    interval: int


@dataclass
class PlatformCredentials:
    api_key: str
    expires_at: str
    github_user: str
    name: str
    access_type: str
    metaflow_config: dict
    invited_by: str | None = None
    guest_expires: str | None = None


def fetch_bootstrap_config() -> dict:
    """Fetch minimal bootstrap config (client_id, domain) from the public endpoint."""
    resp = httpx.get(settings.BOOTSTRAP_ENDPOINT, timeout=10)
    resp.raise_for_status()
    return resp.json()


def fetch_client_config() -> dict:
    """Fetch platform config from the discovery endpoint (public, legacy compat)."""
    resp = httpx.get(settings.CONFIG_ENDPOINT, timeout=10)
    resp.raise_for_status()
    return resp.json()


def request_device_code(client_id: str) -> DeviceCode:
    """Start the GitHub Device Flow — returns a user code for the browser."""
    resp = httpx.post(
        settings.GITHUB_DEVICE_CODE_URL,
        data={"client_id": client_id, "scope": "read:org"},
        headers={"Accept": "application/json"},
        timeout=10,
    )
    resp.raise_for_status()
    data = resp.json()
    return DeviceCode(
        device_code=data["device_code"],
        user_code=data["user_code"],
        verification_uri=data["verification_uri"],
        expires_in=data["expires_in"],
        interval=data.get("interval", 5),
    )


def poll_for_token(client_id: str, device_code: DeviceCode) -> str:
    """Poll GitHub until the user authorises, then return the access token.

    Raises RuntimeError on timeout or denial.
    """
    deadline = time.monotonic() + device_code.expires_in
    interval = device_code.interval

    while time.monotonic() < deadline:
        time.sleep(interval)
        resp = httpx.post(
            settings.GITHUB_DEVICE_POLL_URL,
            data={
                "client_id": client_id,
                "device_code": device_code.device_code,
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
            },
            headers={"Accept": "application/json"},
            timeout=10,
        )
        data = resp.json()

        if "access_token" in data:
            return data["access_token"]

        error = data.get("error", "")
        if error == "authorization_pending":
            continue
        if error == "slow_down":
            interval = data.get("interval", interval + 5)
            continue
        if error in ("expired_token", "access_denied"):
            raise RuntimeError(f"Device flow failed: {error}")

        raise RuntimeError(f"Unexpected response from GitHub: {data}")

    raise RuntimeError("Device flow timed out waiting for authorization")


def exchange_token(github_token: str) -> PlatformCredentials:
    """Exchange a GitHub access token for a platform API key + config."""
    resp = httpx.post(
        settings.TOKEN_EXCHANGE_ENDPOINT,
        json={"github_token": github_token},
        timeout=15,
    )

    if resp.status_code == 403:
        detail = resp.json().get("error", "Access denied")
        raise PermissionError(detail)
    resp.raise_for_status()

    data = resp.json()
    user_info = data["user_info"]

    return PlatformCredentials(
        api_key=data["api_key"],
        expires_at=data["expires_at"],
        github_user=user_info["github_user"],
        name=user_info.get("name", user_info["github_user"]),
        access_type=user_info["access_type"],
        metaflow_config=data["metaflow_config"],
        invited_by=user_info.get("invited_by"),
        guest_expires=user_info.get("guest_expires"),
    )
