"""Titan CLI - Modular development tools orchestrator."""

from importlib.metadata import version

__version__ = version("titan-cli")
