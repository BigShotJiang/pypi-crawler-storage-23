To use this module :

1.  Go to Product View \> Inventory
2.  Edit Dimensional UoM and the three dimensions

If the product has got more than one variant, the dimensions (and the
volume) are visible only in the variants.
