"""Command model for simplecli"""

from diona.project.command import CommandModel, CommandParameter
from diona.ai.client.simplecli.main import interactive_chat


class SimpleCLICommand(CommandModel):
    """Simple CLI command"""
    name = "simplecli"
    description = "Start the simple AI CLI client for interactive chat or single prompt execution"
    parameters = [
        CommandParameter(
            name="model",
            type="str",
            description="AI model to use",
            required=False
        ),
        CommandParameter(
            name="prompt",
            type="str",
            description="Single prompt to run",
            required=False
        ),
        CommandParameter(
            name="agent_mode",
            type="bool",
            description="Enable or disable agent mode",
            required=False,
            default=True
        )
    ]
    
    @staticmethod
    def implementation(*args):
        """Command implementation"""
        return interactive_chat(*args)
