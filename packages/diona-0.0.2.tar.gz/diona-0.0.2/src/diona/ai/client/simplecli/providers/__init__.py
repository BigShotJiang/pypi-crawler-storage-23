"""AI providers module"""
