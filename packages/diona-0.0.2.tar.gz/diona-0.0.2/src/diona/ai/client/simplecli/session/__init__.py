"""Session management module"""
