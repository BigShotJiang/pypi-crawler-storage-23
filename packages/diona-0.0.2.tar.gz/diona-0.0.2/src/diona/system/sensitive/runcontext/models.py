"""
数据模型模块
"""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class UserGroup:
    """用户组信息模型"""
    name: str
    domain: str
    sid: str


@dataclass
class ContextInfo:
    """上下文信息模型"""
    context_type: str
    username: str
    sid: Optional[str]
    profile_path: Optional[str]
    appdata_path: Optional[str]
    localappdata_path: Optional[str]
    groups: List[UserGroup]
    session_type: Optional[str]


@dataclass
class CommandResult:
    """命令执行结果模型"""
    success: bool
    output: str
    error: Optional[str] = None