"""
Network Configuration Information Retrieval Interface
"""

from abc import ABC, abstractmethod
from diona.system.sensitive.info.models.NetworkConfigInfo import NetworkConfigInfo


class NetworkConfigInfoInterface(ABC):
    """Network Configuration Information Retrieval Interface"""
    
    @abstractmethod
    def get_network_config_info(self) -> NetworkConfigInfo:
        """
        Get network configuration information
        
        Returns:
            NetworkConfigInfo: Network configuration information object
        """
        pass
    
    @abstractmethod
    def can_execute(self) -> bool:
        """
        Check if network configuration information retrieval can be executed
        
        Returns:
            bool: Whether execution is possible
        """
        pass