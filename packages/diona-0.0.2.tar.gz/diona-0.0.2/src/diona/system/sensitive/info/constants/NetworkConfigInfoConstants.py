"""
Network Configuration Information Constants
"""

class NetworkConfigInfoConstants:
    """Network Configuration Information Related Constants"""
    
    # Network configuration retrieval commands
    IPCONFIG_ALL_COMMAND = ['ipconfig', '/all']
    NETSTAT_ANO_COMMAND = ['netstat', '-ano']
    IPCONFIG_DISPLAYDNS_COMMAND = ['ipconfig', '/displaydns']
    
    # Network configuration output parsing patterns
    ADAPTER_PATTERN = '适配器 '
    DESCRIPTION_PATTERN = '   描述. . . . . . . . . . . . . . . : '
    PHYSICAL_ADDRESS_PATTERN = '   物理地址. . . . . . . . . . . . : '
    DHCP_ENABLED_PATTERN = '   DHCP 已启用 . . . . . . . . . . . : '
    AUTOCONFIGURATION_ENABLED_PATTERN = '   自动配置已启用. . . . . . . . . . : '
    LINK_LOCAL_IPV6_ADDRESS_PATTERN = '   本地链接 IPv6 地址. . . . . . . . : '
    IPV4_ADDRESS_PATTERN = '   IPv4 地址 . . . . . . . . . . . . : '
    SUBNET_MASK_PATTERN = '   子网掩码  . . . . . . . . . . . . : '
    DEFAULT_GATEWAY_PATTERN = '   默认网关. . . . . . . . . . . . . : '
    DHCP_SERVER_PATTERN = '   DHCP 服务器 . . . . . . . . . . . : '
    DNS_SERVERS_PATTERN = '   DNS 服务器  . . . . . . . . . . . : '
    LEASE_OBTAINED_PATTERN = '   获得租约的时间  . . . . . . . . . : '
    LEASE_EXPIRES_PATTERN = '   租约过期的时间  . . . . . . . . . : '
    
    # netstat command parsing patterns
    TCP_PATTERN = 'TCP'
    UDP_PATTERN = 'UDP'
    LISTENING_PATTERN = 'LISTENING'
    ESTABLISHED_PATTERN = 'ESTABLISHED'
    
    # DNS cache parsing patterns
    RECORD_NAME_PATTERN = '  记录名称. . . . . . . . . . . . . : '
    RECORD_TYPE_PATTERN = '  记录类型. . . . . . . . . . . . . : '
    TIME_TO_LIVE_PATTERN = '  生存时间. . . . . . . . . . . . . : '
    DATA_LENGTH_PATTERN = '  数据长度. . . . . . . . . . . . . : '
    SECTION_PATTERN = '  部分. . . . . . . . . . . . . . . : '
    ANSWER_SECTION_PATTERN = '    答案部分: '
    NAME_PATTERN = '      名称. . . . . . . . . . . . . : '
    TYPE_PATTERN = '      类型. . . . . . . . . . . . . : '
    DATA_PATTERN = '      数据. . . . . . . . . . . . . : '
    
    # Error messages
    ERROR_EXECUTING_IPCONFIG = "Error executing ipconfig command"
    ERROR_EXECUTING_NETSTAT = "Error executing netstat command"
    ERROR_EXECUTING_DISPLAYDNS = "Error executing ipconfig /displaydns command"
    ERROR_PARSING_OUTPUT = "Error parsing network config output"
    
    # 权限相关
    MINIMUM_PERMISSION_LEVEL = "standard_user"
    
    # 编码设置
    DEFAULT_ENCODING = "gbk"