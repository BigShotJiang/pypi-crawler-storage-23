"""
Wireless Network Information Constants
"""

import os

class WirelessNetworkInfoConstants:
    """Wireless Network Information Related Constants"""
    
    # Wireless network information retrieval commands
    NETSH_WLAN_SHOW_PROFILES_COMMAND = ['netsh', 'wlan', 'show', 'profiles']
    NETSH_WLAN_SHOW_PROFILE_COMMAND = ['netsh', 'wlan', 'show', 'profile', '{ssid}', 'key=clear']
    
    # Wireless network profile directory
    WLAN_PROFILES_DIR = os.path.join('C:', 'ProgramData', 'Microsoft', 'Wlansvc', 'Profiles', 'Interfaces')
    
    # Command output parsing patterns
    PROFILE_NAME_PATTERN = '所有用户配置文件 : '
    SSID_NAME_PATTERN = '    SSID 名称            : '
    AUTHENTICATION_PATTERN = '    身份验证            : '
    ENCRYPTION_PATTERN = '    加密            : '
    KEY_CONTENT_PATTERN = '    密钥内容            : '
    
    # Error messages
    ERROR_EXECUTING_NETSH = "Error executing netsh wlan command"
    ERROR_READING_PROFILES = "Error reading WLAN profiles"
    ERROR_PARSING_OUTPUT = "Error parsing wireless network output"
    
    # Permission related
    MINIMUM_PERMISSION_LEVEL = "standard_user"
    
    # Encoding settings
    DEFAULT_ENCODING = "gbk"