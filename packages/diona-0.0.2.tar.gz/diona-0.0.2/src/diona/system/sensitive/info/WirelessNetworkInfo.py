"""
Wireless Network Information Retrieval Interface
"""

from abc import ABC, abstractmethod
from diona.system.sensitive.info.models.WirelessNetworkInfo import WirelessNetworkInfo


class WirelessNetworkInfoInterface(ABC):
    """Wireless Network Information Retrieval Interface"""
    
    @abstractmethod
    def get_wireless_network_info(self) -> WirelessNetworkInfo:
        """
        Get wireless network information
        
        Returns:
            WirelessNetworkInfo: Wireless network information object
        """
        pass
    
    @abstractmethod
    def can_execute(self) -> bool:
        """
        Check if wireless network information retrieval can be executed
        
        Returns:
            bool: Whether execution is possible
        """
        pass