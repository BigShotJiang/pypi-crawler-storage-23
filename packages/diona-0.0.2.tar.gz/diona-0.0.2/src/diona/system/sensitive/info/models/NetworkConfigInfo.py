"""
Network Configuration Information Model
"""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class NetworkAdapterInfo:
    """Network Adapter Information Model"""
    name: Optional[str] = None
    description: Optional[str] = None
    physical_address: Optional[str] = None
    dhcp_enabled: Optional[str] = None
    autoconfiguration_enabled: Optional[str] = None
    link_local_ipv6_address: Optional[str] = None
    ipv4_address: Optional[str] = None
    subnet_mask: Optional[str] = None
    default_gateway: Optional[str] = None
    dhcp_server: Optional[str] = None
    dns_servers: Optional[List[str]] = None
    lease_obtained: Optional[str] = None
    lease_expires: Optional[str] = None


@dataclass
class NetworkConnectionInfo:
    """Network Connection Information Model"""
    protocol: Optional[str] = None
    local_address: Optional[str] = None
    foreign_address: Optional[str] = None
    state: Optional[str] = None
    process_id: Optional[str] = None


@dataclass
class DnsCacheEntry:
    """DNS Cache Entry Model"""
    record_name: Optional[str] = None
    record_type: Optional[str] = None
    time_to_live: Optional[str] = None
    data_length: Optional[str] = None
    section: Optional[str] = None
    answers: Optional[List[dict]] = None


@dataclass
class NetworkConfigInfo:
    """Network Configuration Information Model"""
    adapters: Optional[List[NetworkAdapterInfo]] = None
    connections: Optional[List[NetworkConnectionInfo]] = None
    dns_cache: Optional[List[DnsCacheEntry]] = None
    error_message: Optional[str] = None