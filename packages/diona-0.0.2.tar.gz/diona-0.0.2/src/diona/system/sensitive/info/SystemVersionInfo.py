"""
System Version Information Retrieval Interface
"""

from abc import ABC, abstractmethod
from typing import Optional
from diona.system.sensitive.info.models.SystemVersionInfo import SystemVersionInfo


class SystemVersionInfoInterface(ABC):
    """System Version Information Retrieval Interface"""
    
    @abstractmethod
    def get_system_version_info(self) -> SystemVersionInfo:
        """
        Get system version information
        
        Returns:
            SystemVersionInfo: System version information object
        """
        pass
    
    @abstractmethod
    def can_execute(self) -> bool:
        """
        Check if system version information retrieval can be executed
        
        Returns:
            bool: Whether execution is possible
        """
        pass