"""
System Version Information Model
"""

from dataclasses import dataclass
from typing import List, Optional


@dataclass
class SystemVersionInfo:
    """System Version Information Model"""
    # Operating system information
    os_name: Optional[str] = None
    os_version: Optional[str] = None
    os_manufacturer: Optional[str] = None
    os_configuration: Optional[str] = None
    os_build_type: Optional[str] = None
    
    # Registration information
    registered_owner: Optional[str] = None
    registered_organization: Optional[str] = None
    product_id: Optional[str] = None
    
    # Date and time information
    original_install_date: Optional[str] = None
    system_boot_time: Optional[str] = None
    
    # Hardware information
    system_manufacturer: Optional[str] = None
    system_model: Optional[str] = None
    system_type: Optional[str] = None
    processors: Optional[str] = None
    bios_version: Optional[str] = None
    
    # System paths
    windows_directory: Optional[str] = None
    system_directory: Optional[str] = None
    boot_device: Optional[str] = None
    
    # Locale settings
    system_locale: Optional[str] = None
    input_locale: Optional[str] = None
    time_zone: Optional[str] = None
    
    # Memory information
    total_physical_memory: Optional[str] = None
    available_physical_memory: Optional[str] = None
    virtual_memory_max_size: Optional[str] = None
    virtual_memory_available: Optional[str] = None
    virtual_memory_in_use: Optional[str] = None
    
    # 其他信息
    page_file_locations: Optional[str] = None
    domain: Optional[str] = None
    logon_server: Optional[str] = None
    hotfixes: Optional[List[str]] = None
    network_cards: Optional[List[str]] = None
    
    # 错误信息
    error_message: Optional[str] = None


@dataclass
class HotfixInfo:
    """系统补丁信息模型"""
    hotfix_id: Optional[str] = None
    description: Optional[str] = None
    installed_on: Optional[str] = None


@dataclass
class NetworkCardInfo:
    """网络卡信息模型"""
    name: Optional[str] = None
    description: Optional[str] = None
    physical_address: Optional[str] = None
    dhcp_enabled: Optional[str] = None
    ip_address: Optional[str] = None