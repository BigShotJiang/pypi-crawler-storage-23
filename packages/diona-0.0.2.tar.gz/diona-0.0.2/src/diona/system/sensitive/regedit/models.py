"""
Data models for registry analysis functionality.
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import List, Optional, Dict, Any
from enum import Enum


class RegistryAnalysisStatus(Enum):
    """Status of registry analysis operation."""
    SUCCESS = "success"
    PERMISSION_DENIED = "permission_denied"
    KEY_NOT_FOUND = "key_not_found"
    ERROR = "error"


@dataclass
class RecentDocsEntry:
    """Single entry in RecentDocs registry key."""
    file_name: str
    value_name: str
    timestamp: Optional[datetime] = None
    file_extension: Optional[str] = None
    registry_key_name: Optional[str] = None  # The original registry key name (e.g., "3", ".txt")
    actual_file_path: Optional[str] = None  # Actual file path for shortcuts (.lnk files)


@dataclass
class RecentDocsData:
    """Collection of RecentDocs analysis results."""
    extension_groups: Dict[str, List[RecentDocsEntry]] = field(default_factory=dict)
    applications: List[RecentDocsEntry] = field(default_factory=list)
    status: RegistryAnalysisStatus = RegistryAnalysisStatus.SUCCESS
    error_message: Optional[str] = None


@dataclass
class ShellBagEntry:
    """Single entry in ShellBags registry structure."""
    path: str
    slot_index: Optional[int] = None
    view_mode: Optional[int] = None
    timestamp: Optional[datetime] = None
    item_data: Optional[Dict[str, Any]] = None


@dataclass
class ShellBagsData:
    """Collection of ShellBags analysis results."""
    bag_locations: Dict[str, List[ShellBagEntry]] = field(default_factory=dict)
    status: RegistryAnalysisStatus = RegistryAnalysisStatus.SUCCESS
    error_message: Optional[str] = None


@dataclass
class RegistryAnalysisResult:
    """Complete registry analysis result."""
    recent_docs: RecentDocsData
    shellbags: ShellBagsData
    analysis_timestamp: datetime = field(default_factory=datetime.now)
    context_info: Optional[Any] = None