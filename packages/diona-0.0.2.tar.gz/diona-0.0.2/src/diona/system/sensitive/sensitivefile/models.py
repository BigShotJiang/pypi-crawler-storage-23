"""
Sensitive file data models
"""

from dataclasses import dataclass
from typing import Optional, List
from datetime import datetime


@dataclass
class SensitiveFinding:
    """Sensitive finding data model"""
    file_path: str
    line_number: int
    column: int
    keyword: str
    key_part: str
    value_length: int
    password_type: str
    file_type: str
    sanitized_line: str


@dataclass
class FileAnalysisResult:
    """File analysis result data model"""
    file_path: str
    findings: List[SensitiveFinding]
    success: bool
    error_message: Optional[str] = None
    timestamp: Optional[datetime] = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()


@dataclass
class BatchAnalysisResult:
    """Batch analysis result data model"""
    results: List[FileAnalysisResult]
    total_files: int
    timestamp: Optional[datetime] = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()