"""
Windows Credential Manager Module
"""

from .credential_collector import CredentialCollector
from .models import CredentialEntry, CredentialCollectionResult

__all__ = ["CredentialCollector", "CredentialEntry", "CredentialCollectionResult"]