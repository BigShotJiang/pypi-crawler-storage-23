"""
Clipboard data models
"""

from dataclasses import dataclass
from typing import Optional, List
from datetime import datetime


@dataclass
class ClipboardContent:
    """Clipboard content data model"""
    timestamp: datetime
    text: Optional[str] = None
    has_text: bool = False
    has_image: bool = False
    has_files: bool = False
    file_count: Optional[int] = None
    image_size: Optional[int] = None


@dataclass
class SensitiveDataMatch:
    """Sensitive data match data model"""
    match_type: str
    count: int
    sample: str


@dataclass
class ClipboardEntry:
    """Clipboard entry with sensitive data detection"""
    content: ClipboardContent
    sensitive_data: List[SensitiveDataMatch]
    has_sensitive_data: bool = False


@dataclass
class ClipboardMonitoringResult:
    """Clipboard monitoring result data model"""
    success: bool
    entries: List[ClipboardEntry]
    duration: int
    interval: float
    error_message: Optional[str] = None
    timestamp: Optional[datetime] = None

    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()