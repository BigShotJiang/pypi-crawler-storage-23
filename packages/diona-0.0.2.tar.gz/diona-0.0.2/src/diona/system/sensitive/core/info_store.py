"""
Information Storage Center Module
"""

from typing import Optional
from diona.system.sensitive.runcontext.models import ContextInfo
from diona.system.sensitive.runcontext.context import RunContext


class InfoStore:
    """
    Information Storage Center
    Global singleton for storing and retrieving ContextInfo
    """
    _instance = None
    _context_info: Optional[ContextInfo] = None
    _initialized = False
    
    def __new__(cls):
        """
        Implement singleton pattern
        """
        if cls._instance is None:
            cls._instance = super(InfoStore, cls).__new__(cls)
        return cls._instance
    def initialize(self) -> None:
        """
        Initialize loading function
        Creates RunContext on first load and retrieves ContextInfo from RunContext
        """
        if not self._initialized:
            try:
                # Create RunContext instance
                run_context = RunContext()
                # Get ContextInfo
                context_info = run_context.get_context_info()
                # Set ContextInfo
                self.set_context_info(context_info)
                self._initialized = True
            except Exception as e:
                print(f"Error initializing InfoStore: {e}")
    
    def set_context_info(self, context_info: ContextInfo) -> None:
        """
        Set context information
        
        Args:
            context_info: Context information object
        """
        self._context_info = context_info
        self._initialized = True
    
    def get_context_info(self) -> Optional[ContextInfo]:
        """
        Get context information
        
        Returns:
            Context information object, returns None if not set
        """
        if not self._initialized:
            self.initialize()

        return self._context_info
    
    def clear_context_info(self) -> None:
        """
        Clear context information
        """
        self._context_info = None


# Singleton factory function
def get_info_store_instance():
    """Get the singleton InfoStore instance."""
    return InfoStore()