"""
Progressive search functionality for sensitive file scanning.

This module provides incremental file scanning capabilities with persistent state
management for sensitive document and credential file detection.
"""

from .models import SearchConfig, SearchResult, SearchState
from .progressive_search import ProgressiveSearch
from .file_rules import FileSelectionRules

__all__ = [
    "SearchConfig",
    "SearchResult", 
    "SearchState",
    "ProgressiveSearch",
    "FileSelectionRules"
]