"""
Edge 浏览器登录数据采集
"""

import os
import sqlite3
import tempfile
from typing import List
from datetime import datetime
from diona.system.sensitive.browser.logindata.base import LoginDataCollector
from diona.system.sensitive.browser.models.logindata import LoginDataRecord


class EdgeLoginDataCollector(LoginDataCollector):
    """
    Edge 浏览器登录数据采集器
    """
    
    def __init__(self):
        """
        初始化 Edge 登录数据采集器
        """
        self.login_data_path = os.path.join(
            os.environ.get('LOCALAPPDATA', ''),
            'Microsoft', 'Edge', 'User Data', 'Default', 'Login Data'
        )
    
    def collect(self, limit: int = 100) -> List[LoginDataRecord]:
        """
        采集 Edge 登录数据
        
        Args:
            limit: 采集的记录数量限制
            
        Returns:
            登录数据列表，包含原始加密状态的密码
        """
        
        if not os.path.exists(self.login_data_path):
            return []
        
        try:
            # 创建临时文件，因为 Login Data 文件可能被 Edge 锁定
            with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as temp_file:
                temp_path = temp_file.name
            
            # 复制文件内容
            with open(self.login_data_path, 'rb') as src, open(temp_path, 'wb') as dst:
                dst.write(src.read())
            
            # 连接数据库
            conn = sqlite3.connect(temp_path)
            cursor = conn.cursor()
            
            # 查询登录数据（包括黑名单状态）
            query = """
                SELECT origin_url, action_url, username_value, password_value, 
                       date_created, date_last_used, blacklisted_by_user
                FROM logins
                ORDER BY date_last_used DESC
                LIMIT ?
            """
            cursor.execute(query, (limit,))
            
            # 解析结果
            login_data = []
            for row in cursor.fetchall():
                origin_url, action_url, username_value, password_value, date_created, date_last_used, blacklisted = row
                
                # 转换时间戳
                date_created = self._webkit_timestamp_to_datetime(date_created)
                date_last_used = self._webkit_timestamp_to_datetime(date_last_used)
                
                # 处理密码值（BLOB 数据）
                if password_value:
                    if isinstance(password_value, bytes):
                        password_hex = password_value.hex()
                    else:
                        password_hex = str(password_value)
                else:
                    password_hex = ''
                
                login_data.append(LoginDataRecord(
                    origin_url=origin_url,
                    action_url=action_url,
                    username_value=username_value if username_value else '',
                    password_value=password_hex,  # 以十六进制形式存储原始加密密码
                    date_created=date_created,
                    date_last_used=date_last_used,
                    blacklisted=bool(blacklisted)  # 是否被用户列入黑名单
                ))
            
            # 关闭连接
            cursor.close()
            conn.close()
            
            # 删除临时文件
            os.unlink(temp_path)
            
            return login_data
            
        except Exception as e:
            print(f"Error collecting Edge login data: {e}")
            if 'temp_path' in locals() and os.path.exists(temp_path):
                try:
                    os.unlink(temp_path)
                except:
                    pass
            return []
    
    def get_browser_name(self) -> str:
        """
        获取浏览器名称
        
        Returns:
            浏览器名称
        """
        return "Microsoft Edge"
    
    def _webkit_timestamp_to_datetime(self, timestamp: int) -> str:
        """
        将 WebKit 时间戳转换为可读的日期时间字符串
        
        Args:
            timestamp: WebKit 时间戳（微秒）
            
        Returns:
            日期时间字符串
        """
        # 检查时间戳是否有效
        if timestamp is None or timestamp == 0:
            return ""
        
        try:
            # WebKit 时间戳是自 1601 年 1 月 1 日以来的微秒数
            # 转换为 Unix 时间戳（自 1970 年 1 月 1 日以来的秒数）
            unix_timestamp = (timestamp - 11644473600000000) / 1000000
            return datetime.utcfromtimestamp(unix_timestamp).strftime('%Y-%m-%d %H:%M:%S')
        except (OSError, ValueError):
            # 如果时间戳无效，返回空字符串
            return ""