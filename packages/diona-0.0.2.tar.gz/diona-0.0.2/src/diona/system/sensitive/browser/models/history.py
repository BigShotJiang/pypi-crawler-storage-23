"""
历史记录数据模型
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class HistoryRecord:
    """
    浏览器历史记录数据模型
    """
    
    url: str
    """访问的URL地址"""
    
    title: str
    """页面标题"""
    
    visit_count: int
    """访问次数"""
    
    last_visit_time: str
    """最后访问时间（格式：YYYY-MM-DD HH:MM:SS）"""
    
    def to_dict(self) -> dict:
        """
        将模型转换为字典
        
        Returns:
            字典形式的数据
        """
        return {
            'url': self.url,
            'title': self.title,
            'visit_count': self.visit_count,
            'last_visit_time': self.last_visit_time
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> 'HistoryRecord':
        """
        从字典创建模型实例
        
        Args:
            data: 字典数据
            
        Returns:
            HistoryRecord 实例
        """
        return cls(
            url=data.get('url', ''),
            title=data.get('title', ''),
            visit_count=data.get('visit_count', 0),
            last_visit_time=data.get('last_visit_time', '')
        )