"""Run CLI"""

from .core.core import run_cli


def run():
    """Run CLI"""
    run_cli()
