"""List commands command"""

from .base import BuiltinCommand
from diona.project.command import CommandRegistry


class ListCommandsCommand(BuiltinCommand):
    """List commands command"""
    name = "list-commands"
    description = "List all registered commands"
    
    def execute(self, args):
        """Execute list-commands command"""
        registry = CommandRegistry()
        command_manager = registry.get_command_manager()
        commands = command_manager.list_commands()
        
        if not commands:
            print('No commands registered.')
            return False
        
        print('Registered commands:')
        print('-' * 60)
        for name, command in commands.items():
            print(f'{name:<20} {command.description}')
        print('-' * 60)
        return False


# Global instance
list_commands_command = ListCommandsCommand()
