"""Diona command module"""

from .main import main

__all__ = ['main']
