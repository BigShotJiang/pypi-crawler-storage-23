"""Main entry point for the diona command"""

import os
from rich.console import Console
from rich.text import Text

# Initialize console
console = Console()

# Get banner path
banner_path = os.path.join(os.path.dirname(__file__), 'banner.txt')

# Print banner
def print_banner():
    """Print the banner"""
    if os.path.exists(banner_path):
        with open(banner_path, 'r', encoding='utf-8') as f:
            banner = f.read()
        # Create a gradient pink text for the banner
        banner_text = Text()
        # Define gradient colors from light white-pink to slightly deeper pink
        colors = ["#fffbfe", "#fce7f3", "#fbcfe8", "#f9a8d4", "#f472b6"]
        # Apply gradient to each character
        for i, char in enumerate(banner):
            color_index = i % len(colors)
            banner_text.append(char, style=f"bold {colors[color_index]}")
        console.print(banner_text)
        console.print()

def main():
    """Main function for the diona command"""
    # Print banner at the beginning
    print_banner()
    
    # Start CLI directly
    from diona.project.cli import run
    run()
    return


if __name__ == '__main__':
    main()
