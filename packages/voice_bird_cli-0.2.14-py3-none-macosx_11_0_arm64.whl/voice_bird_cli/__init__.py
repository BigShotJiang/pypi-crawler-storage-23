"""Voice Bird CLI - Terminal audio streaming for voice transcription."""
