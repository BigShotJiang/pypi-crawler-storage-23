---
name: Ocr Test
cron: "0 * * * *"
active: true
provider: claude
---

Summarize recent changes in this directory.
Focus on key architectural decisions and potential security risks.
Output as a concise report.
