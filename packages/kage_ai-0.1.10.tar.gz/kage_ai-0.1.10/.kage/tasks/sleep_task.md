---
name: Sleep Task
cron: "0 0 * * *"
active: true
command: "sleep 2"
---
