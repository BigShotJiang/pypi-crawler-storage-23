---
name: Daily Audit
cron: "0 9 * * *"
active: false
---

# Task: Project Health Audit
Please review the codebase for any obvious architectural drifts or missing tests.
Focus on the 'src/' directory.
On the first run, create a Todo list of areas to investigate.
In subsequent runs, pick one area, audit it, and update the memory.
