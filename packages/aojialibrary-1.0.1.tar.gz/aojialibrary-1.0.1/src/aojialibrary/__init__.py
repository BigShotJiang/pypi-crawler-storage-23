r"""
AoJia Library - Python wrapper for AoJia automation library

A Pythonic interface to the AoJia Windows automation library,
providing screen capture, color/image finding, keyboard/mouse simulation,
memory operations, and more.

Basic Usage:
    from aojialibrary import AoJia
    
    # Simple usage
    aj = AoJia()
    aj.initialize()
    
    # Find a window
    hwnd = aj.find_window(0, "notepad", 0, "", "", 1, 0)
    
    # Move and click
    aj.move_to(100, 100)
    aj.left_click()
    
    # Clean up
    aj.release()
    
    # Or use as context manager
    with AoJia() as aj:
        aj.move_to(100, 100)
        aj.left_click()

Advanced Usage:
    from aojialibrary import AoJia, register, set_dll_path
    
    # Use custom DLL path
    set_dll_path(r"C:\path\to\AoJia64.dll")
    
    aj = AoJia()
    aj.initialize()

Features:
    - Window operations (find, move, resize, close)
    - Keyboard simulation (key press, text input)
    - Mouse simulation (move, click, drag)
    - Screen capture and color finding
    - Image matching
    - OCR text recognition
    - Memory read/write
    - Process management
    - File operations
    - Background mode (send input to background windows)

Requirements:
    - Windows OS (64-bit)
    - pywin32 (for COM support)

Installation:
    pip install aojialibrary
"""

__version__ = "1.0.1"
__author__ = "AoJia Library Contributors"
__all__ = [
    # Main class
    'AoJia',
    # Exceptions
    'AoJiaError',
    'AoJiaNotInitializedError',
    'AoJiaCOMError',
    # Registration functions
    'set_dll_path',
    'register_com',
    'unregister_com',
    'get_dll_path',
    # Constants
    'AOJIA_CLSID',
    'COMPREG_CLSID',
    # Singleton access
    'get_aojia',
]

# Import main components
from .aojia import AoJia, get_aojia
from .core import AoJiaError, AoJiaNotInitializedError, AoJiaCOMError
from .register import set_dll_path, register_com, unregister_com, get_dll_path
from .constants import AOJIA_CLSID, COMPREG_CLSID
