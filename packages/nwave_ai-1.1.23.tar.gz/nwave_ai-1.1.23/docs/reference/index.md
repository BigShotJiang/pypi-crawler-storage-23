# nWave Reference

Auto-generated documentation for 22 agents, 21 commands, 68 skills, and 9 templates.

## Contents

- [Agents](agents/index.md) (22)
- [Commands](commands/index.md) (21)
- [Skills](skills/index.md) (68)
- [Templates](templates/index.md) (9)
