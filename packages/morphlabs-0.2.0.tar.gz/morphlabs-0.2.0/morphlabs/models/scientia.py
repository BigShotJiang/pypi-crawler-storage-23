import requests
import numpy as np
import os
import logging
from typing import Optional
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type

from morphlabs.io.loading import EEGData
from morphlabs.io.preprocessing import denormalize

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

API_ERROR_MESSAGES = {
    400: "Bad request: The data sent to the API was invalid. Please check your input data format.",
    401: "Authentication failed: Invalid API key. Please check your SCIENTIA_API_KEY.",
    403: "Access denied: Your API key does not have permission for this operation. Please contact support.",
    404: "API endpoint not found: Please check the base_url configuration.",
    429: "Rate limit exceeded: Too many requests. Please wait a moment and try again.",
    500: "Server error: The Scientia API encountered an internal error. Please try again later.",
    502: "Bad gateway: The Scientia API is temporarily unavailable. Please try again later.",
    503: "Service unavailable: The Scientia API is temporarily down for maintenance. Please try again later.",
    504: "Gateway timeout: The request took too long. Please try again with smaller data segments.",
}

RETRYABLE_STATUS_CODES = [429, 500, 502, 503, 504]

RUNPOD_API_KEY = "rpa_FFBJYB2SODF8Z3MCXWY5W78L8KI0A4BGQ999JLUZcqkk9u"

OPTIMAL_BATCH_SIZE = 32  # Segments per request


def _chunk_segments(segments, batch_size):
    """Yield batches of segments along with their starting index."""
    for i in range(0, len(segments), batch_size):
        yield segments[i:i + batch_size], i


class RetryableAPIError(Exception):
    pass

class Scientia:
    def __init__(self, api_key: Optional[str] = None, base_url: Optional[str] = None):
        api_key = api_key if api_key is not None else os.getenv("SCIENTIA_API_KEY")

        if api_key is not None and not api_key.strip():
            raise ValueError("API key cannot be empty or whitespace. Please provide a valid API key.")
        self.api_key = api_key

        if base_url is not None:
            if not base_url.startswith(("http://", "https://")):
                raise ValueError(f"Invalid base_url: '{base_url}'. URL must start with http:// or https://")
            self.base_url = base_url.rstrip("/")
        else:
            self.base_url = "https://api.runpod.ai/v2/9ni9hifywn9z73/runsync"

    def clean_data(
        self,
        data_path: str,
        sfreq: Optional[float] = 250.0,
        powerline_freq: float = 60.0
    ) -> np.ndarray:
        """
        Clean EEG data using the Scientia API.

        Args:
            data_path: Path to the EEG data file (.csv, .edf, or .bdf)
            sfreq: Sampling frequency in Hz. For CSV files, defaults to 250 Hz.
                   For EDF/BDF files, this is auto-detected from the file metadata.
            powerline_freq: Power line frequency for notch filter (default 60.0 Hz for US,
                           use 50.0 for EU)

        Returns:
            Cleaned EEG data as numpy array of shape (n_channels, n_samples)
        """
        if self.api_key is None:
            raise ValueError("API key not found. Please pass the API key as an argument or set the SCIENTIA_API_KEY environment variable.")

        data_obj = EEGData(data_path, sfreq=sfreq, powerline_freq=powerline_freq)

        data_samples = data_obj.get_data()
        pad_amount = data_obj.get_pad_amount()
        normalization_params = data_obj.get_normalization_params()

        cleaned_samples = []
        total_segments = len(data_samples)
        total_samples = total_segments * 1000 - pad_amount

        logger.info(f"Cleaning {total_samples} samples ({total_segments} segments)")

        for batch, start_idx in _chunk_segments(data_samples, OPTIMAL_BATCH_SIZE):
            # Build batched payload
            batched_data = [sample.tolist() for sample in batch]
            batch_num = start_idx // OPTIMAL_BATCH_SIZE + 1
            total_batches = (total_segments + OPTIMAL_BATCH_SIZE - 1) // OPTIMAL_BATCH_SIZE

            logger.info(f"Processing batch {batch_num}/{total_batches}, segments {start_idx + 1}-{start_idx + len(batch)} of {total_segments}")

            response = self._make_api_request(
                url=self.base_url,
                json={"input": {"api_key": self.api_key, "data": batched_data}},
                timeout=120
            )

            # Validate response structure
            try:
                response_data = response.json()
            except requests.exceptions.JSONDecodeError:
                raise ValueError("Invalid response from API: Expected JSON but received invalid data.")

            # Handle RunPod wrapper if present
            if "status" in response_data:
                status = response_data.get("status")
                if status != "COMPLETED":
                    if status in ("IN_QUEUE", "IN_PROGRESS"):
                        raise ValueError(f"Scientia API request is still processing (status: {status}). Please try again.")
                    elif status == "FAILED":
                        error_msg = response_data.get("error", "Unknown error")
                        raise ValueError(f"Scientia API request failed: {error_msg}")
                    elif status == "CANCELLED":
                        raise ValueError("Scientia API request was cancelled.")
                    else:
                        raise ValueError(f"Unexpected response status from Scientia API: {status}")
                output = response_data.get("output", {})
            else:
                output = response_data

            if output is None or "reconstructed" not in output:
                raise ValueError("Invalid response from API: Missing 'reconstructed' field in response.")

            reconstructed = output["reconstructed"]

            # Denormalize each segment in batch
            for j, cleaned_data in enumerate(reconstructed):
                global_idx = start_idx + j
                cleaned_sample = np.array(cleaned_data)
                cleaned_sample = denormalize(cleaned_sample, normalization_params[global_idx])

                # Handle padding for last segment
                if global_idx == total_segments - 1 and pad_amount > 0:
                    cleaned_sample = cleaned_sample[:, :-pad_amount]

                cleaned_samples.append(cleaned_sample)

        return self._reconstruct_data(cleaned_samples)

    def _reconstruct_data(self, cleaned_samples: list[np.ndarray]) -> np.ndarray:
        return np.concatenate(cleaned_samples, axis=1)

    @retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, min=4, max=15), retry=retry_if_exception_type(RetryableAPIError))
    def _make_api_request(self, url: str, json: dict, timeout: int) -> requests.Response:
        headers = {"Authorization": f"Bearer {RUNPOD_API_KEY}"}
        try:
            response = requests.post(url, headers=headers, json=json, timeout=timeout)
        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
            raise RetryableAPIError(f"Network error: {e}")

        if response.status_code in RETRYABLE_STATUS_CODES:
            raise RetryableAPIError(f"API request failed with status {response.status_code}: {response.text}")

        if not response.ok:
            error_msg = API_ERROR_MESSAGES.get(response.status_code, f"API request failed with status {response.status_code}: {response.text}")
            raise ValueError(error_msg)

        return response
