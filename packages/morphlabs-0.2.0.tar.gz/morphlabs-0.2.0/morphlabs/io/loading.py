import numpy as np
import pandas as pd
import mne
from pathlib import Path
from typing import Optional, List

from morphlabs.io.preprocessing import (
    highpass_filter,
    notch_filter,
    normalize,
    NormalizationParams
)


class EEGData:
    def __init__(
        self,
        file_path: str,
        sfreq: Optional[float] = 250.0,
        powerline_freq: float = 60.0
    ):
        """
        Load and preprocess EEG data from a file.

        Args:
            file_path: Path to the EEG data file (.csv, .edf, or .bdf)
            sfreq: Sampling frequency in Hz. For CSV files, defaults to 250 Hz.
                   For EDF/BDF files, this is auto-detected from the file metadata.
            powerline_freq: Power line frequency for notch filter (default 60.0 Hz for US,
                           use 50.0 for EU)
        """
        self.file_path = file_path
        self._data = None
        self._channels = None
        self._pad_amount = None
        self._sfreq = sfreq
        self._powerline_freq = powerline_freq
        self._normalization_params: List[NormalizationParams] = []

        if file_path is not None:
            if not self.load_data():
                raise ValueError(f"Failed to load data from {file_path}")

    def get_data(self) -> Optional[List[np.ndarray]]:
        return self._data

    def get_channels(self) -> Optional[int]:
        return self._channels

    def get_pad_amount(self) -> Optional[int]:
        return self._pad_amount

    def get_sfreq(self) -> Optional[float]:
        return self._sfreq

    def get_normalization_params(self) -> List[NormalizationParams]:
        return self._normalization_params

    def load_data(self) -> bool:
        self._validate_file_path(self.file_path)
        match Path(self.file_path).suffix:
            case '.csv':
                self.load_data_from_csv(self.file_path)
                return True
            case '.edf':
                self.load_data_from_edf(self.file_path)
                return True
            case '.bdf':
                self.load_data_from_bdf(self.file_path)
                return True
            case _:
                raise ValueError(f"Unsupported file type: {str(self.file_path).split('.')[-1]}, please use .csv, .edf, or .bdf files.")

    def load_data_from_csv(self, file_path: str):
        try:
            data = pd.read_csv(file_path)
            if data.empty:
                raise ValueError(f"File is empty: '{file_path}'. Please provide a file with EEG data.")
            self._channels = len(data.columns)
            raw_data = data.values.T.astype(np.float32)
            # Apply filtering before segmentation
            filtered_data = self._apply_filters(raw_data)
            self._data, self._pad_amount = self.segment_data(filtered_data)
            self.verify_montage()
        except UnicodeDecodeError as e:
            raise ValueError(f"Failed to load CSV file '{file_path}': File contains invalid characters. Details: {e}")
        except pd.errors.ParserError as e:
            raise ValueError(f"Failed to parse CSV file '{file_path}': File may be corrupted or incorrectly formatted. Details: {e}")
        except pd.errors.EmptyDataError:
            raise ValueError(f"File is empty: '{file_path}'. Please provide a file with EEG data.")
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(f"Failed to load CSV file '{file_path}': {type(e).__name__}: {e}")

    def load_data_from_edf(self, file_path: str):
        try:
            raw = mne.io.read_raw_edf(file_path, preload=True, verbose=False)
            self._channels = len(raw.ch_names)
            # Auto-detect sampling frequency from EDF metadata
            self._sfreq = raw.info['sfreq']
            raw_data = raw.get_data().astype(np.float32)
            # Apply filtering before segmentation
            filtered_data = self._apply_filters(raw_data)
            self._data, self._pad_amount = self.segment_data(filtered_data)
            self.verify_montage()
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(f"Failed to load EDF file '{file_path}': File may be corrupted or not a valid EDF format. Details: {type(e).__name__}: {e}")

    def load_data_from_bdf(self, file_path: str):
        try:
            raw = mne.io.read_raw_bdf(file_path, preload=True, verbose=False)
            self._channels = len(raw.ch_names)
            # Auto-detect sampling frequency from BDF metadata
            self._sfreq = raw.info['sfreq']
            raw_data = raw.get_data().astype(np.float32)
            # Apply filtering before segmentation
            filtered_data = self._apply_filters(raw_data)
            self._data, self._pad_amount = self.segment_data(filtered_data)
            self.verify_montage()
        except ValueError:
            raise
        except Exception as e:
            raise ValueError(f"Failed to load BDF file '{file_path}': File may be corrupted or not a valid BDF format. Details: {type(e).__name__}: {e}")

    def _apply_filters(self, data: np.ndarray) -> np.ndarray:
        """
        Apply high-pass and notch filters to remove artifacts.

        Args:
            data: Raw EEG data of shape (n_channels, n_samples)

        Returns:
            Filtered data of shape (n_channels, n_samples)
        """
        # Apply 1Hz high-pass filter to remove DC drift
        data = highpass_filter(data, self._sfreq, cutoff=1.0)
        # Apply notch filter to remove power line interference
        data = notch_filter(data, self._sfreq, freq=self._powerline_freq)
        return data

    def _validate_file_path(self, file_path: str) -> None:
        path = Path(file_path)

        if not path.exists():
            raise ValueError(f"File not found: '{file_path}'. Please check the file path exists.")
        if not path.is_file():
            raise ValueError(f"Path is not a file: '{file_path}'. Please provide a path to a file, not a directory.")
        if path.stat().st_size == 0:
            raise ValueError(f"File is empty: '{file_path}'. Please provide a file with EEG data.")

    def segment_data(self, data: np.ndarray) -> tuple[List[np.ndarray], int]:
        """
        Segment data into fixed-size windows and normalize each segment.

        Args:
            data: Filtered EEG data of shape (n_channels, n_samples)

        Returns:
            Tuple of (segments, pad_amount)
            - segments: List of normalized data segments
            - pad_amount: Number of samples padded in the last segment
        """
        n_samples = data.shape[1]
        window_size = 1000
        segments = []
        pad_amount = 0
        self._normalization_params = []

        for i in range(0, n_samples, window_size):
            segment = data[:, i:i+window_size]
            if segment.shape[1] != window_size:
                pad_amount = window_size - segment.shape[1]
                pad_width = ((0, 0), (0, pad_amount))
                segment = np.pad(segment, pad_width, 'constant')

            # Normalize each segment independently
            normalized_segment, params = normalize(segment)
            segments.append(normalized_segment)
            self._normalization_params.append(params)

        return segments, pad_amount


    def verify_montage(self) -> None:
        if self._channels != 19:
            raise ValueError(f"Unsupported number of channels: {self._channels}, Scientia currently only supports the 19 channels in the 10-20 system.")
