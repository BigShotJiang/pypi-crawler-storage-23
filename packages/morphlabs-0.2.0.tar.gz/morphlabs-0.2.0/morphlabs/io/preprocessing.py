import numpy as np
from scipy.signal import butter, iirnotch, sosfiltfilt, filtfilt
from dataclasses import dataclass
from typing import Tuple


@dataclass
class NormalizationParams:
    """Parameters for reversing z-score normalization."""
    mean: np.ndarray  # (n_channels,)
    std: np.ndarray   # (n_channels,)


def highpass_filter(data: np.ndarray, sfreq: float, cutoff: float = 1.0, order: int = 4) -> np.ndarray:
    """
    Apply a high-pass Butterworth filter to remove DC drift and low-frequency noise.

    Args:
        data: EEG data array of shape (n_channels, n_samples)
        sfreq: Sampling frequency in Hz
        cutoff: Cutoff frequency in Hz (default 1.0 Hz)
        order: Filter order (default 4)

    Returns:
        Filtered data array of shape (n_channels, n_samples)
    """
    nyquist = sfreq / 2.0
    normalized_cutoff = cutoff / nyquist

    # Use second-order sections for numerical stability
    sos = butter(order, normalized_cutoff, btype='high', output='sos')

    # Apply zero-phase filtering
    return sosfiltfilt(sos, data, axis=1).astype(np.float32)


def notch_filter(data: np.ndarray, sfreq: float, freq: float = 60.0, quality: float = 30.0) -> np.ndarray:
    """
    Apply a notch filter to remove power line interference.

    Args:
        data: EEG data array of shape (n_channels, n_samples)
        sfreq: Sampling frequency in Hz
        freq: Frequency to remove in Hz (default 60.0 Hz for US, use 50.0 for EU)
        quality: Quality factor (default 30.0)

    Returns:
        Filtered data array of shape (n_channels, n_samples)
    """
    # Design notch filter
    b, a = iirnotch(freq, quality, sfreq)

    # Apply zero-phase filtering
    return filtfilt(b, a, data, axis=1).astype(np.float32)


def normalize(data: np.ndarray) -> Tuple[np.ndarray, NormalizationParams]:
    """
    Apply per-channel z-score normalization.

    Args:
        data: EEG data array of shape (n_channels, n_samples)

    Returns:
        Tuple of (normalized_data, normalization_params)
        - normalized_data: Array with mean~0 and std~1 per channel
        - normalization_params: Parameters needed to reverse the normalization
    """
    # Compute per-channel statistics
    mean = np.mean(data, axis=1, keepdims=True)
    std = np.std(data, axis=1, keepdims=True)

    # Avoid division by zero
    std = np.where(std == 0, 1.0, std)

    # Apply z-score normalization
    normalized_data = ((data - mean) / std).astype(np.float32)

    # Store params as 1D arrays
    params = NormalizationParams(
        mean=mean.squeeze(),
        std=std.squeeze()
    )

    return normalized_data, params


def denormalize(data: np.ndarray, params: NormalizationParams) -> np.ndarray:
    """
    Reverse z-score normalization using stored parameters.

    Args:
        data: Normalized EEG data array of shape (n_channels, n_samples)
        params: NormalizationParams containing mean and std

    Returns:
        Denormalized data array in original scale
    """
    mean = params.mean.reshape(-1, 1)
    std = params.std.reshape(-1, 1)

    return (data * std + mean).astype(np.float32)
