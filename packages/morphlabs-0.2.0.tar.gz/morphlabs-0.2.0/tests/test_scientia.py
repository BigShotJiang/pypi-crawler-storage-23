import pytest
from unittest.mock import patch, MagicMock
from pathlib import Path
import requests

from morphlabs.models import Scientia


@pytest.fixture
def test_data_path():
    return Path(__file__).parent / "test_data"


@pytest.fixture
def api_key(monkeypatch):
    monkeypatch.setenv("SCIENTIA_API_KEY", "test_api_key")
    return "test_api_key"


@pytest.fixture
def no_api_key(monkeypatch):
    monkeypatch.delenv("SCIENTIA_API_KEY", raising=False)



def mock_success_response(url, json, **kwargs):
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.ok = True
    # New batched response format - data is now a list of segments
    mock_response.json.return_value = {
        "status": "COMPLETED",
        "output": {
            "reconstructed": json["input"]["data"],  # Return batched data as-is
            "meta": {"model_version": "v1"}
        }
    }
    return mock_response


def mock_missing_data_response(url, json, **kwargs):
    mock_response = MagicMock()
    mock_response.status_code = 200
    mock_response.ok = True
    mock_response.json.return_value = {"status": "COMPLETED", "output": {}}
    return mock_response


def test_init_defaults(no_api_key):
    scientia = Scientia()
    assert scientia.api_key is None
    assert scientia.base_url == "https://api.runpod.ai/v2/9ni9hifywn9z73/runsync"


def test_init_with_api_key(no_api_key):
    scientia = Scientia(api_key="test_api_key1")
    assert scientia.api_key == "test_api_key1"
    assert scientia.base_url == "https://api.runpod.ai/v2/9ni9hifywn9z73/runsync"


def test_init_from_env(api_key):
    scientia = Scientia(base_url="https://test.scientia.ai")
    assert scientia.api_key == "test_api_key"
    assert scientia.base_url == "https://test.scientia.ai"


@pytest.mark.parametrize("base_url,expected", [
    ("https://api.scientia.ai/", "https://api.scientia.ai"),
    ("https://api.scientia.ai/v1", "https://api.scientia.ai/v1"),
    ("https://api.scientia.ai/v1/", "https://api.scientia.ai/v1"),
])
def test_init_strips_trailing_slash(base_url, expected):
    scientia = Scientia(api_key="test_api_key", base_url=base_url)
    assert scientia.base_url == expected


# =============================================================================
# Validation Tests
# =============================================================================

def test_missing_api_key_error(no_api_key, test_data_path):
    scientia = Scientia()
    with pytest.raises(ValueError) as e:
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "API key not found" in str(e.value)


def test_empty_api_key_error(monkeypatch, test_data_path):
    monkeypatch.setenv("SCIENTIA_API_KEY", "")
    with pytest.raises(ValueError) as e:
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "API key cannot be empty or whitespace" in str(e.value)


def test_whitespace_api_key_error(monkeypatch, test_data_path):
    monkeypatch.setenv("SCIENTIA_API_KEY", " ")
    with pytest.raises(ValueError) as e:
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "API key cannot be empty or whitespace" in str(e.value)


def test_invalid_base_url_error(test_data_path):
    with pytest.raises(ValueError) as e:
        scientia = Scientia(api_key="test_api_key", base_url="invalid_url")
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "Invalid base_url" in str(e.value)


def test_invalid_base_url_protocol_error(test_data_path):
    with pytest.raises(ValueError) as e:
        scientia = Scientia(api_key="test_api_key", base_url="ftp://invalid_url")
        scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
    assert "URL must start with http:// or https://" in str(e.value)


def test_clean_data_success(api_key, test_data_path):
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_success_response):
        scientia = Scientia()
        data = scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
        assert data is not None
        assert data.shape == (19, 2500)


def test_clean_data_removes_padding(api_key, test_data_path):
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_success_response):
        scientia = Scientia()

        data_padded = scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
        assert data_padded.shape == (19, 2500)

        data_no_pad = scientia.clean_data(test_data_path / "valid_19ch_2000samples.csv")
        assert data_no_pad.shape == (19, 2000)


def test_json_missing_reconstructed_field(api_key, test_data_path):
    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_missing_data_response):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_2500samples.csv")
        assert "Invalid response from API: Missing 'reconstructed' field in response." in str(e.value)


def test_json_decode_error(api_key, test_data_path):
    def mock_invalid_json(url, json, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.side_effect = requests.exceptions.JSONDecodeError("", "", 0)
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_invalid_json):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "Expected JSON but received invalid data" in str(e.value)


@pytest.mark.parametrize("status_code", [429, 500, 502, 503, 504])
def test_retryable_status_codes(api_key, test_data_path, status_code):
    def mock_retryable_error(url, json, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = status_code
        mock_response.ok = False
        mock_response.text = f"Error {status_code}"
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_retryable_error):
        scientia = Scientia()
        with pytest.raises(Exception) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        last_exception = e.value.last_attempt.exception()
        assert f"API request failed with status {status_code}" in str(last_exception)


@pytest.mark.parametrize("status_code,expected_msg", [
    (400, "Bad request"),
    (401, "Authentication failed"),
    (403, "Access denied"),
    (404, "API endpoint not found"),
])
def test_non_retryable_status_codes(api_key, test_data_path, status_code, expected_msg):
    def mock_non_retryable_error(url, json, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = status_code
        mock_response.ok = False
        mock_response.text = f"Error {status_code}"
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_non_retryable_error):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert expected_msg in str(e.value)


def test_retry_attempts_count(api_key, test_data_path):
    call_count = 0

    def mock_always_fails(url, json, **kwargs):
        nonlocal call_count
        call_count += 1
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_response.ok = False
        mock_response.text = "Server error"
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_always_fails):
        scientia = Scientia()
        with pytest.raises(Exception):
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    assert call_count == 3


def test_network_timeout(api_key, test_data_path):
    with patch("morphlabs.models.scientia.requests.post", side_effect=requests.exceptions.Timeout("Connection timed out")):
        scientia = Scientia()
        with pytest.raises(Exception) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        last_exception = e.value.last_attempt.exception()
        assert "Network error" in str(last_exception)


def test_network_connection_error(api_key, test_data_path):
    with patch("morphlabs.models.scientia.requests.post", side_effect=requests.exceptions.ConnectionError("Connection refused")):
        scientia = Scientia()
        with pytest.raises(Exception) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        last_exception = e.value.last_attempt.exception()
        assert "Network error" in str(last_exception)


# =============================================================================
# RunPod-specific Status Tests
# =============================================================================

@pytest.mark.parametrize("status", ["IN_QUEUE", "IN_PROGRESS"])
def test_runpod_processing_status(api_key, test_data_path, status):
    def mock_processing_response(url, json, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.return_value = {"status": status}
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_processing_response):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "still processing" in str(e.value)
        assert status in str(e.value)


def test_runpod_failed_status(api_key, test_data_path):
    def mock_failed_response(url, json, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.return_value = {"status": "FAILED", "error": "GPU out of memory"}
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_failed_response):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "Scientia API request failed" in str(e.value)
        assert "GPU out of memory" in str(e.value)


def test_runpod_cancelled_status(api_key, test_data_path):
    def mock_cancelled_response(url, json, **kwargs):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.return_value = {"status": "CANCELLED"}
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_cancelled_response):
        scientia = Scientia()
        with pytest.raises(ValueError) as e:
            scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")
        assert "was cancelled" in str(e.value)


def test_api_key_in_payload(api_key, test_data_path):
    captured_payload = None

    def mock_capture_payload(url, json, **kwargs):
        nonlocal captured_payload
        captured_payload = json
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.return_value = {
            "status": "COMPLETED",
            "output": {
                "reconstructed": json["input"]["data"],
                "meta": {"model_version": "v1"}
            }
        }
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_capture_payload):
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    assert captured_payload is not None
    assert "input" in captured_payload
    assert "api_key" in captured_payload["input"]
    assert captured_payload["input"]["api_key"] == "test_api_key"
    assert "data" in captured_payload["input"]
    # Verify batched format - data should be a list of segments
    assert isinstance(captured_payload["input"]["data"], list)


def test_runpod_api_key_in_header(api_key, test_data_path):
    captured_headers = None

    def mock_capture_headers(url, headers=None, json=None, **kwargs):
        nonlocal captured_headers
        captured_headers = headers
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.ok = True
        mock_response.json.return_value = {
            "status": "COMPLETED",
            "output": {
                "reconstructed": json["input"]["data"],
                "meta": {"model_version": "v1"}
            }
        }
        return mock_response

    with patch("morphlabs.models.scientia.requests.post", side_effect=mock_capture_headers):
        scientia = Scientia()
        scientia.clean_data(test_data_path / "valid_19ch_1000samples.csv")

    assert captured_headers is not None
    assert "Authorization" in captured_headers
    assert captured_headers["Authorization"].startswith("Bearer ")
    assert "rpa_" in captured_headers["Authorization"]
