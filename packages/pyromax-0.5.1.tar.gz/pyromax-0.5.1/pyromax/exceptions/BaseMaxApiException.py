class BaseMaxApiException(Exception):
    """Base class for exceptions in this library."""