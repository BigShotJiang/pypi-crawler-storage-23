|project|
=========

Installation
------------

.. code-block:: shell

   pip install vws-web-tools

This is tested on Python |minimum-python-version|\+.

Usage
-----

.. click:: vws_web_tools:vws_web_tools_group
  :prog: vws-web-tools
  :show-nested:


Reference
---------

.. toctree::
   :maxdepth: 3

   python-api
   contributing
   release-process
   changelog
