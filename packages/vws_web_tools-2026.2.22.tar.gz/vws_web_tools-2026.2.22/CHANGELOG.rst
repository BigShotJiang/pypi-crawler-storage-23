Changelog
=========

Next
----

2026.02.22
----------


2026.02.20
----------


2026.02.17.1
------------


2026.02.17
----------


2026.02.16.1
------------


2026.02.16
----------


- Renamed the ``create-vws-database`` CLI command to ``create-vws-cloud-database``.
