from matrx_utils import vcprint, clear_terminal

clear_terminal()

vcprint("Hello, World!", color="yellow")