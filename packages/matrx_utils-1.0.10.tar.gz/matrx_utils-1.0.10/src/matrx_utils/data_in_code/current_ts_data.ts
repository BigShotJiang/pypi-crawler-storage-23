
// all_active_registered_functions_with_args added on 2025-06-03 18:25:49
export const all_active_registered_functions_with_args = [
  {
    id: "90b0bfd0-37fd-4c39-9ad8-bde3eb175263",
    func_name: "run_one_recipe_twice",
    return_broker: "2ce1afd9-0fc0-40d2-b589-b856a53e9182",
    args: [
      {
        id: "a354c87a-17f0-44a3-a681-76d83fae0bbf",
        name: "recipe_id",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "90b0bfd0-37fd-4c39-9ad8-bde3eb175263",
        default_value: {
          value: null
        }
      },
      {
        id: "2ca2fd63-e985-4325-9854-0c73df28ed3a",
        name: "version",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "90b0bfd0-37fd-4c39-9ad8-bde3eb175263",
        default_value: {
          value: null
        }
      },
      {
        id: "7d8695b2-3df2-42ea-9173-67fe47324f74",
        name: "brokers_with_values_1",
        required: false,
        data_type: "dict",
        ready: false,
        registered_function: "90b0bfd0-37fd-4c39-9ad8-bde3eb175263",
        default_value: {
          value: null
        }
      },
      {
        id: "b4847267-88b0-4b49-8de7-468d498c2db5",
        name: "brokers_with_values_2",
        required: false,
        data_type: "dict",
        ready: false,
        registered_function: "90b0bfd0-37fd-4c39-9ad8-bde3eb175263",
        default_value: {
          value: null
        }
      }
    ]
  },
  {
    id: "00567d93-beb0-4b66-a026-cae40a2acbe2",
    func_name: "run_recipe_with_session_brokers",
    return_broker: "784f9b61-81cc-44af-8d24-a1cc3d9eac56",
    args: [
      {
        id: "68d7e5ef-426f-46a0-af93-663be16ffd2f",
        name: "recipe_id",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "00567d93-beb0-4b66-a026-cae40a2acbe2",
        default_value: {
          value: null
        }
      },
      {
        id: "fbd485db-0db7-43ae-94a4-83f203ae9599",
        name: "latest_version",
        required: false,
        data_type: "bool",
        ready: false,
        registered_function: "00567d93-beb0-4b66-a026-cae40a2acbe2",
        default_value: {
          value: true
        }
      },
      {
        id: "a41d9e75-b85e-477c-96ed-335fb530bddb",
        name: "version",
        required: false,
        data_type: "str",
        ready: false,
        registered_function: "00567d93-beb0-4b66-a026-cae40a2acbe2",
        default_value: {
          value: null
        }
      },
      {
        id: "694cec25-1036-49e0-932e-b67273024c3d",
        name: "model_override",
        required: false,
        data_type: "str",
        ready: false,
        registered_function: "00567d93-beb0-4b66-a026-cae40a2acbe2",
        default_value: {
          value: null
        }
      },
      {
        id: "bb0fe7fa-36ae-4031-8caf-bdc5c603dbc0",
        name: "tools_override",
        required: false,
        data_type: "list",
        ready: false,
        registered_function: "00567d93-beb0-4b66-a026-cae40a2acbe2",
        default_value: {
          value: null
        }
      }
    ]
  },
  {
    id: "0710eb09-ea6d-40c4-ad16-6245a3655ec6",
    func_name: "get_full_schema_object",
    return_broker: "7ed8807a-b5cb-4475-b75c-686383f31125",
    args: [
      {
        id: "51032e26-541e-410f-bedf-9138b86293ca",
        name: "database_project",
        required: true,
        data_type: "str",
        ready: true,
        registered_function: "0710eb09-ea6d-40c4-ad16-6245a3655ec6",
        default_value: {
          value: null
        }
      },
      {
        id: "ecbcf5ba-dd6b-4a98-a770-439a44ccefe0",
        name: "schema",
        required: true,
        data_type: "str",
        ready: true,
        registered_function: "0710eb09-ea6d-40c4-ad16-6245a3655ec6",
        default_value: {
          value: null
        }
      }
    ]
  },
  {
    id: "4646f50f-3150-442b-a87d-527c99a80652",
    func_name: "process_youtube_video",
    return_broker: "7ed8807a-b5cb-4475-b75c-686383f31125",
    args: [
      {
        id: "1013ec63-9e6f-419d-8666-1589bc14613b",
        name: "video_url",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "4646f50f-3150-442b-a87d-527c99a80652",
        default_value: {
          value: null
        }
      },
      {
        id: "7c0579b7-45de-4992-9082-bbe9e406e4e2",
        name: "return_params",
        required: false,
        data_type: "dict",
        ready: false,
        registered_function: "4646f50f-3150-442b-a87d-527c99a80652",
        default_value: {
          value: null
        }
      }
    ]
  },
  {
    id: "f543544d-cf09-4db3-b7d1-b83dd0ce344d",
    func_name: "pdf_processing_orchestrator",
    return_broker: "7ed8807a-b5cb-4475-b75c-686383f31125",
    args: [
      {
        id: "9bc8981b-7898-4d72-9cd0-be298b316253",
        name: "pdf_path",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "f543544d-cf09-4db3-b7d1-b83dd0ce344d",
        default_value: {
          value: null
        }
      },
      {
        id: "b438d03c-4caa-48d8-b32d-1aa753c3a4bc",
        name: "chunk_size",
        required: false,
        data_type: "int",
        ready: false,
        registered_function: "f543544d-cf09-4db3-b7d1-b83dd0ce344d",
        default_value: {
          value: 5000
        }
      },
      {
        id: "601cde15-3551-4293-abfb-1b68b7bfc518",
        name: "chunk_and_save",
        required: false,
        data_type: "bool",
        ready: false,
        registered_function: "f543544d-cf09-4db3-b7d1-b83dd0ce344d",
        default_value: {
          value: false
        }
      },
      {
        id: "d2c6b79f-776b-45a2-84dd-5e97302c5976",
        name: "process_with_ai",
        required: false,
        data_type: "bool",
        ready: false,
        registered_function: "f543544d-cf09-4db3-b7d1-b83dd0ce344d",
        default_value: {
          value: false
        }
      },
      {
        id: "a1534516-6c96-479e-aada-40eaf0f2ba3d",
        name: "overlap_size",
        required: false,
        data_type: "int",
        ready: false,
        registered_function: "f543544d-cf09-4db3-b7d1-b83dd0ce344d",
        default_value: {
          value: 500
        }
      }
    ]
  },
  {
    id: "b42d270b-0627-453c-a4bb-920eb1da6c51",
    func_name: "orchestrate_text_operations",
    return_broker: "2c5e85c9-a81a-472c-a7bc-d060766244ec",
    args: [
      {
        id: "c350d165-6c61-4589-a6f0-a634b30835b1",
        name: "content",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "b42d270b-0627-453c-a4bb-920eb1da6c51",
        default_value: {
          value: null
        }
      },
      {
        id: "7368eacf-057a-4811-b68b-be2065233278",
        name: "instructions",
        required: true,
        data_type: "list",
        ready: false,
        registered_function: "b42d270b-0627-453c-a4bb-920eb1da6c51",
        default_value: {
          value: null
        }
      }
    ]
  },
  {
    id: "b870cda8-8789-4189-8ce1-95db7ce09290",
    func_name: "process_markdown_make_flat",
    return_broker: "30f69de4-13c9-40f2-9806-ddf4a63776bc",
    args: [
      {
        id: "3359edf1-28a6-49dd-a247-b303daf9c6c6",
        name: "markdown_content",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "b870cda8-8789-4189-8ce1-95db7ce09290",
        default_value: {
          value: null
        }
      },
      {
        id: "7cf33358-3475-434b-a55e-0a57e5efbae9",
        name: "method",
        required: false,
        data_type: "str",
        ready: true,
        registered_function: "b870cda8-8789-4189-8ce1-95db7ce09290",
        default_value: {
          value: "dict_structured"
        }
      }
    ]
  },
  {
    id: "d03ae789-3cde-4263-aea9-79a3eaad2dc6",
    func_name: "process_markdown",
    return_broker: "8c221702-cc7a-4d5a-a940-305454f3d6df",
    args: [
      {
        id: "d4accc89-f151-45d0-befd-06a4befd0b48",
        name: "markdown_content",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "d03ae789-3cde-4263-aea9-79a3eaad2dc6",
        default_value: {
          value: null
        }
      },
      {
        id: "91ad6fa3-1b9e-4b69-b80b-9d5bf8c04a5d",
        name: "clean_markdown",
        required: false,
        data_type: "str",
        ready: true,
        registered_function: "d03ae789-3cde-4263-aea9-79a3eaad2dc6",
        default_value: {
          value: true
        }
      },
      {
        id: "c6ff4be5-55ab-4a2b-a2bf-92ce14f135bb",
        name: "extract_jsons",
        required: false,
        data_type: "str",
        ready: false,
        registered_function: "d03ae789-3cde-4263-aea9-79a3eaad2dc6",
        default_value: {
          value: true
        }
      },
      {
        id: "b13a0b5c-cb11-47e9-858b-140cff75973d",
        name: "ignore_line_breaks",
        required: false,
        data_type: "str",
        ready: false,
        registered_function: "d03ae789-3cde-4263-aea9-79a3eaad2dc6",
        default_value: {
          value: true
        }
      }
    ]
  },
  {
    id: "88324112-a108-4a27-94bd-671fef2c184d",
    func_name: "process_markdown_extract_with_multiple_configs",
    return_broker: "2ca25554-0db3-47e6-81c1-80b3d792b1c6",
    args: [
      {
        id: "ec0d6037-90dc-417c-8c65-e9e1c5413c58",
        name: "configs",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "88324112-a108-4a27-94bd-671fef2c184d",
        default_value: {
          value: null
        }
      },
      {
        id: "c373d905-281d-40a9-8340-00c47e19c425",
        name: "markdown_content",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "88324112-a108-4a27-94bd-671fef2c184d",
        default_value: {
          value: null
        }
      },
      {
        id: "52f69cad-30ec-48c5-abfd-ae9e69444cd2",
        name: "method",
        required: false,
        data_type: "str",
        ready: true,
        registered_function: "88324112-a108-4a27-94bd-671fef2c184d",
        default_value: {
          value: "dict_structured"
        }
      }
    ]
  },
  {
    id: "7d3da03f-dde5-4444-81cd-cf5e60defc8e",
    func_name: "process_markdown_extract_with_config",
    return_broker: "37c0abef-4788-4dee-9709-929a193d36d0",
    args: [
      {
        id: "2fba6339-aa18-45cd-a0aa-f7ce95564405",
        name: "config",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "7d3da03f-dde5-4444-81cd-cf5e60defc8e",
        default_value: {
          value: null
        }
      },
      {
        id: "7db7ee96-97bd-4f8e-9d8c-bd3bd70b4c46",
        name: "markdown_content",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "7d3da03f-dde5-4444-81cd-cf5e60defc8e",
        default_value: {
          value: null
        }
      },
      {
        id: "1d39ffd0-e4f2-4a2f-ae31-7cd6f2e95e7e",
        name: "method",
        required: false,
        data_type: "str",
        ready: true,
        registered_function: "7d3da03f-dde5-4444-81cd-cf5e60defc8e",
        default_value: {
          value: "dict_structured"
        }
      }
    ]
  },
  {
    id: "2ac5576b-d1ab-45b1-ab48-4e196629fdd8",
    func_name: "orchestrate_run_recipe",
    return_broker: "784f9b61-81cc-44af-8d24-a1cc3d9eac56",
    args: [
      {
        id: "d19b67a0-8f81-4694-bd16-287ddc66718b",
        name: "recipe_id",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "2ac5576b-d1ab-45b1-ab48-4e196629fdd8",
        default_value: {
          value: null
        }
      },
      {
        id: "7469afcc-4fcd-4c72-8c20-65d1579a588e",
        name: "version",
        required: false,
        data_type: "int",
        ready: false,
        registered_function: "2ac5576b-d1ab-45b1-ab48-4e196629fdd8",
        default_value: {
          value: null
        }
      },
      {
        id: "ecfc4cad-e93b-4b53-895d-5da863182ff2",
        name: "model_override",
        required: false,
        data_type: "str",
        ready: false,
        registered_function: "2ac5576b-d1ab-45b1-ab48-4e196629fdd8",
        default_value: {
          value: null
        }
      },
      {
        id: "ba6e52f3-5859-4090-ab75-a70c6610140c",
        name: "tools_override",
        required: false,
        data_type: "list",
        ready: false,
        registered_function: "2ac5576b-d1ab-45b1-ab48-4e196629fdd8",
        default_value: {
          value: null
        }
      },
      {
        id: "e5c2259e-1fb6-4963-9b51-07f8e323e0aa",
        name: "latest_version",
        required: false,
        data_type: "bool",
        ready: true,
        registered_function: "2ac5576b-d1ab-45b1-ab48-4e196629fdd8",
        default_value: {
          value: true
        }
      },
      {
        id: "02eea019-5ef2-4f59-be51-7ff648d95a1a",
        name: "recipe_brokers",
        required: true,
        data_type: "list",
        ready: false,
        registered_function: "2ac5576b-d1ab-45b1-ab48-4e196629fdd8",
        default_value: {
          value: null
        }
      }
    ]
  },
  {
    id: "cbdbbf0c-e963-4b5f-bea5-87aa743fcb74",
    func_name: "process_markdown_with_dynamic_extraction",
    return_broker: "9fb9b7e5-c0bd-4e85-b606-21d05550842c",
    args: [
      {
        id: "b98ee26e-cd75-49ce-9f95-4b5aa6f542fe",
        name: "extraction_function_str",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "cbdbbf0c-e963-4b5f-bea5-87aa743fcb74",
        default_value: {
          value: null
        }
      },
      {
        id: "b4398612-8773-4a23-8a07-d620bbc17bbf",
        name: "markdown_content",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "cbdbbf0c-e963-4b5f-bea5-87aa743fcb74",
        default_value: {
          value: null
        }
      },
      {
        id: "d4ab3dd1-ba2d-4771-b9a0-762f2bee3db8",
        name: "method",
        required: false,
        data_type: "str",
        ready: true,
        registered_function: "cbdbbf0c-e963-4b5f-bea5-87aa743fcb74",
        default_value: {
          value: "dict_structured"
        }
      }
    ]
  },
  {
    id: "06d788e1-906e-4601-b112-bda6d2152f26",
    func_name: "run_one_recipe_twice_concurrently",
    return_broker: "2ce1afd9-0fc0-40d2-b589-b856a53e9182",
    args: [
      {
        id: "c4188bc4-9cf2-417a-9410-0772b8fd91f1",
        name: "recipe_id",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "06d788e1-906e-4601-b112-bda6d2152f26",
        default_value: {
          value: null
        }
      },
      {
        id: "59167b65-34d5-4d46-a69d-9595ae477b51",
        name: "version",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "06d788e1-906e-4601-b112-bda6d2152f26",
        default_value: {
          value: null
        }
      },
      {
        id: "63f538a7-ea1b-4b8b-8e30-e140f4206a2e",
        name: "model_override",
        required: true,
        data_type: "dict",
        ready: false,
        registered_function: "06d788e1-906e-4601-b112-bda6d2152f26",
        default_value: {
          value: null
        }
      },
      {
        id: "0989b8b7-968e-4773-a6ec-08d50e5eed51",
        name: "brokers_with_values_1",
        required: false,
        data_type: "dict",
        ready: false,
        registered_function: "06d788e1-906e-4601-b112-bda6d2152f26",
        default_value: {
          value: null
        }
      },
      {
        id: "16f9ba37-40f3-4608-8dee-d84d43310819",
        name: "brokers_with_values_2",
        required: false,
        data_type: "dict",
        ready: false,
        registered_function: "06d788e1-906e-4601-b112-bda6d2152f26",
        default_value: {
          value: null
        }
      }
    ]
  },
  {
    id: "15faf218-1b31-4059-9ef4-a2f118601ab7",
    func_name: "add_two_numbers",
    return_broker: "c8cc4f94-11ee-444a-954d-58482664c384",
    args: [
      {
        id: "b30544d4-978e-4864-b86c-9fe721dda03c",
        name: "first_number",
        required: true,
        data_type: "int",
        ready: false,
        registered_function: "15faf218-1b31-4059-9ef4-a2f118601ab7",
        default_value: {
          value: null
        }
      },
      {
        id: "3f8c930f-1044-4b96-bf52-677862334874",
        name: "second_number",
        required: true,
        data_type: "int",
        ready: false,
        registered_function: "15faf218-1b31-4059-9ef4-a2f118601ab7",
        default_value: {
          value: null
        }
      }
    ]
  },
  {
    id: "828586a7-99bc-4402-9903-75e0a20eb6e8",
    func_name: "multiply_number_by_10",
    return_broker: "cab337cc-f8ac-4bad-8e4b-758279f18931",
    args: [
      {
        id: "f26638a0-cb4a-4e1c-8099-0aaf24d8fbc3",
        name: "number",
        required: true,
        data_type: "int",
        ready: false,
        registered_function: "828586a7-99bc-4402-9903-75e0a20eb6e8",
        default_value: {
          value: null
        }
      }
    ]
  },
  {
    id: "e5986426-b48e-4dcc-a4d0-d65f879b47ca",
    func_name: "validate_add_and_multiply_numbers_by_10",
    return_broker: "3137ecb2-0971-4bc4-b896-48e9bfd0eb40",
    args: [
      {
        id: "08e23daa-07be-4951-8aea-6bd40f54572d",
        name: "answer_to_test",
        required: true,
        data_type: "int",
        ready: false,
        registered_function: "e5986426-b48e-4dcc-a4d0-d65f879b47ca",
        default_value: {
          value: null
        }
      },
      {
        id: "a13065c4-519a-466a-9294-26f788fd74cc",
        name: "first_number",
        required: true,
        data_type: "int",
        ready: false,
        registered_function: "e5986426-b48e-4dcc-a4d0-d65f879b47ca",
        default_value: {
          value: null
        }
      },
      {
        id: "dff3b77b-491b-4610-bd68-1cb365922ec7",
        name: "second_number",
        required: true,
        data_type: "int",
        ready: false,
        registered_function: "e5986426-b48e-4dcc-a4d0-d65f879b47ca",
        default_value: {
          value: null
        }
      }
    ]
  },
  {
    id: "8ff3af1c-3975-4a2d-89d1-0f799c784302",
    func_name: "full_markdown_classifier",
    return_broker: "490abd8a-bb15-4ce3-b709-623906bc08de",
    args: [
      {
        id: "bc3bfd7a-d8c1-4589-b13d-5861b20a0972",
        name: "text_data",
        required: true,
        data_type: "str",
        ready: false,
        registered_function: "8ff3af1c-3975-4a2d-89d1-0f799c784302",
        default_value: {
          value: null
        }
      },
      {
        id: "3fce8471-3b1e-4664-a486-c258b1b7a4a1",
        name: "remove_line_breaks",
        required: false,
        data_type: "bool",
        ready: false,
        registered_function: "8ff3af1c-3975-4a2d-89d1-0f799c784302",
        default_value: {
          value: true
        }
      },
      {
        id: "fa9db855-1ac5-48d7-9934-f98415916659",
        name: "remove_thematic_breaks",
        required: false,
        data_type: "bool",
        ready: false,
        registered_function: "8ff3af1c-3975-4a2d-89d1-0f799c784302",
        default_value: {
          value: true
        }
      },
      {
        id: "2f024168-cdb3-48c3-8e2d-310f8b98377c",
        name: "rules_override",
        required: false,
        data_type: "dict",
        ready: false,
        registered_function: "8ff3af1c-3975-4a2d-89d1-0f799c784302",
        default_value: {
          value: null
        }
      },
      {
        id: "4ef3a3d3-98e9-44ec-92ab-1a39219bcbf3",
        name: "core_broker_id",
        required: false,
        data_type: "str",
        ready: false,
        registered_function: "8ff3af1c-3975-4a2d-89d1-0f799c784302",
        default_value: {
          value: null
        }
      },
      {
        id: "8dfaf865-a497-4183-863b-9e7b4290e8be",
        name: "session_manager",
        required: false,
        data_type: "str",
        ready: false,
        registered_function: "8ff3af1c-3975-4a2d-89d1-0f799c784302",
        default_value: {
          value: null
        }
      }
    ]
  }
];
