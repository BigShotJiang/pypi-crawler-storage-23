"""
code_context — unified code context builder for LLM prompts.

Primary entry point:
    from matrx_utils.code_context import CodeContextBuilder, OutputMode

    result = CodeContextBuilder(project_root="/path", output_mode="signatures").build()
"""

from .code_context import (
    ASTAnalyzer,
    ClassInfo,
    CodeContextBuilder,
    CodeContextConfig,
    CodeContextResult,
    CodeExtractor,
    DirectoryTree,
    FileDiscovery,
    FileNode,
    FunctionCallAnalyzer,
    FunctionCallGraph,
    FunctionCallInfo,
    FunctionInfo,
    ModuleAST,
    OutputMode,
    SignatureBlock,
    SignatureExtractor,
)

from .generate_module_readme import readme_orchestrator


__all__ = [
    "ASTAnalyzer",
    "ClassInfo",
    "CodeContextBuilder",
    "CodeContextConfig",
    "CodeContextResult",
    "CodeExtractor",
    "DirectoryTree",
    "FileDiscovery",
    "FileNode",
    "FunctionCallAnalyzer",
    "FunctionCallGraph",
    "FunctionCallInfo",
    "FunctionInfo",
    "ModuleAST",
    "OutputMode",
    "SignatureBlock",
    "SignatureExtractor",
    "readme_orchestrator",
]
