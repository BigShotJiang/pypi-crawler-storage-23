"""Local Knowledge Base - semantic search for personal documents."""

from importlib.metadata import version

__version__ = version("okb")
