"""claude-tg: Claude Code <-> Telegram bridge."""
__version__ = "0.5.1"
