
# agentify_icon = """
# [magenta] █████████████████[/magenta]    [yellow]agentify provider add <provider_name>[/yellow] [green]# e.g. openai, xai, anthropic[/green]
# [magenta]░███▒▒▒▒███▒▒▒▒███[/magenta]    [yellow]agentify agent new[/yellow] [green]# <-- Creates a new Agent[/green]
# [magenta]░███░░  ███░░  ███[/magenta]    [green]# Run Agent[/green]
# [magenta]░█████████████████[/magenta]    [yellow]agentify run agent.yaml[/yellow]
# [magenta]░█████░░░░░░░█████[/magenta]    [green]# Start MCP Server[/green]                
# [magenta]░█████████████████[/magenta]    [yellow]agentify mcp2 start[/yellow]    
# [magenta]░░░██░░██░░██░░██ [/magenta]    [green]# Start Agent Runtime → Deploy Agent[/green]
# [magenta]  ░██ ░██ ░██ ░██ [/magenta]    [yellow]agentify runtime start[/yellow] [green]→[/green] [yellow]agentify deploy agent.yaml[/yellow]
# """

# agentify_icon = """
# [green]              ██[/green]    [yellow]agentify provider add <provider_name>[/yellow] [green]# e.g. openai, xai, anthropic[/green]
# [green] █████████████████[/green]    [yellow]agentify provider add <provider_name>[/yellow] [green]# e.g. openai, xai, anthropic[/green]
# [green] █████████████████[/green]    [yellow]agentify provider add <provider_name>[/yellow] [green]# e.g. openai, xai, anthropic[/green]
# [green]░██   ░░███   ░░██[/green]    [yellow]agentify agent new[/yellow] [green]# <-- Creates a new Agent[/green]
# [green]░██     ███     ██[/green]    [green]# Run Agent[/green]
# [green]░█████████████████[/green]    [yellow]agentify run agent.yaml[/yellow]
# [green]░███████   ███████[/green]    [green]# Start MCP Server[/green]                
# [green]░█████████████████[/green]    [yellow]agentify mcp2 start[/yellow]    
# [green]░░░██░░██░░██░░██ [/green]    [green]# Start Agent Runtime → Deploy Agent[/green]
# [green]  ░██ ░██ ░██ ░██ [/green]    [yellow]agentify runtime start[/yellow] [green]→[/green] [yellow]agentify deploy agent.yaml[/yellow]
# [green]  ░██ ░██ ░██ ░██ [/green]    [yellow]agentify runtime start[/yellow] [green]→[/green] [yellow]agentify deploy agent.yaml[/yellow]
# """

# agentify_icon = """
# [gray] ██████████████████████████████████[/gray]
# [gray] ████████████████  ████████████████[/gray]
# [gray] ██                              ██[/gray]
# [gray] ██  [white]██████████████████████████[/white]  ██[/gray]
# [gray] ██  [white]███         ██         ███[/white]  ██[/gray]
# [gray] ██  [white]███     ░░  ██     ░░  ███[/white]  ██[/gray]
# [gray] ██  [white]███         ██         ███[/white]  ██[/gray]
# [gray] ██  [white]███         ██         ███[/white]  ██[/gray]
# [gray] ██  [white]██████████████████████████[/white]  ██[/gray]
# [gray] ██  [white]███████████    ███████████[/white]  ██[/gray]
# [gray] ██  [white]██████████████████████████[/white]  ██[/gray]
# [gray] ██                              ██[/gray]
# [gray] ████████  ███  ███  ███  █████████[/gray]
# [gray] ████████  ███  ███  ███  █████████[/gray]
# [gray] ████████  ███  ███  ███  █████████[/gray]
# [gray] ██████████████████████████████████[/gray]

# """