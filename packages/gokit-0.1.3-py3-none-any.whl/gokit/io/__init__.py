"""Input parsers for gokit."""
