"""CLI package for gokit."""
