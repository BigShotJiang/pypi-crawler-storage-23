"""Cache utilities for gokit."""
