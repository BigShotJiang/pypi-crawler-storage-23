# mioffice-pdf-utils

Lightweight PDF utilities for Python — merge, split, extract pages, rotate, compress, and get metadata.

Built by [JSVV SOLS LLC](https://www.mioffice.ai) — the team behind [MiOffice.ai](https://www.mioffice.ai), the AI Office Suite with 66+ browser-based tools.

## Installation

```bash
pip install mioffice-pdf-utils
```

## Usage

```python
from mioffice_pdf_utils import merge_pdfs, split_pdf, extract_pages, rotate_pdf, get_metadata, compress_pdf

# Merge multiple PDFs
merge_pdfs(["file1.pdf", "file2.pdf"], "merged.pdf")

# Split PDF into individual pages
pages = split_pdf("document.pdf", "./output/")

# Extract specific pages (1-based)
extract_pages("document.pdf", "extracted.pdf", pages=[1, 3, 5])

# Rotate all pages
rotate_pdf("document.pdf", "rotated.pdf", degrees=90)

# Compress PDF
compress_pdf("large.pdf", "compressed.pdf")

# Get metadata
meta = get_metadata("document.pdf")
print(f"Title: {meta['title']}, Pages: {meta['page_count']}")
```

## API

| Function | Description |
|----------|-------------|
| `merge_pdfs(paths, output)` | Merge multiple PDFs into one |
| `split_pdf(path, output_dir)` | Split PDF into individual pages |
| `extract_pages(path, output, pages)` | Extract specific pages |
| `rotate_pdf(path, output, degrees)` | Rotate all pages |
| `remove_pages(path, output, pages)` | Remove specific pages |
| `compress_pdf(path, output)` | Compress PDF streams |
| `get_metadata(path)` | Get title, author, page count |

## License

MIT — [JSVV SOLS LLC](https://www.mioffice.ai)
