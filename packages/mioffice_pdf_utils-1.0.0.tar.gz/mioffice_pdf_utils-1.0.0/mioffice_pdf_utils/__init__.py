"""
MiOffice PDF Utils — Lightweight PDF utilities for Python.

Merge, split, extract pages, rotate, and get metadata from PDFs.
Zero heavy dependencies — uses PyPDF2 only.

Homepage: https://www.mioffice.ai
"""

__version__ = "1.0.0"
__author__ = "JSVV SOLS LLC"
__homepage__ = "https://www.mioffice.ai"

from PyPDF2 import PdfReader, PdfWriter, PdfMerger


def merge_pdfs(input_paths: list[str], output_path: str) -> str:
    """Merge multiple PDF files into one.

    Args:
        input_paths: List of paths to PDF files to merge.
        output_path: Path for the merged output PDF.

    Returns:
        The output path.
    """
    merger = PdfMerger()
    for path in input_paths:
        merger.append(path)
    merger.write(output_path)
    merger.close()
    return output_path


def split_pdf(input_path: str, output_dir: str) -> list[str]:
    """Split a PDF into individual pages.

    Args:
        input_path: Path to the PDF file.
        output_dir: Directory to write individual page PDFs.

    Returns:
        List of output file paths.
    """
    import os
    reader = PdfReader(input_path)
    output_paths = []
    for i, page in enumerate(reader.pages):
        writer = PdfWriter()
        writer.add_page(page)
        out_path = os.path.join(output_dir, f"page_{i + 1}.pdf")
        with open(out_path, "wb") as f:
            writer.write(f)
        output_paths.append(out_path)
    return output_paths


def extract_pages(input_path: str, output_path: str, pages: list[int]) -> str:
    """Extract specific pages from a PDF.

    Args:
        input_path: Path to the source PDF.
        output_path: Path for the output PDF.
        pages: List of page numbers (1-based) to extract.

    Returns:
        The output path.
    """
    reader = PdfReader(input_path)
    writer = PdfWriter()
    for page_num in pages:
        if 1 <= page_num <= len(reader.pages):
            writer.add_page(reader.pages[page_num - 1])
    with open(output_path, "wb") as f:
        writer.write(f)
    return output_path


def rotate_pdf(input_path: str, output_path: str, degrees: int = 90) -> str:
    """Rotate all pages in a PDF.

    Args:
        input_path: Path to the source PDF.
        output_path: Path for the rotated PDF.
        degrees: Rotation angle (90, 180, or 270).

    Returns:
        The output path.
    """
    reader = PdfReader(input_path)
    writer = PdfWriter()
    for page in reader.pages:
        page.rotate(degrees)
        writer.add_page(page)
    with open(output_path, "wb") as f:
        writer.write(f)
    return output_path


def get_metadata(input_path: str) -> dict:
    """Get metadata from a PDF file.

    Args:
        input_path: Path to the PDF file.

    Returns:
        Dictionary with title, author, subject, creator, producer, page_count.
    """
    reader = PdfReader(input_path)
    meta = reader.metadata or {}
    return {
        "title": meta.get("/Title", ""),
        "author": meta.get("/Author", ""),
        "subject": meta.get("/Subject", ""),
        "creator": meta.get("/Creator", ""),
        "producer": meta.get("/Producer", ""),
        "page_count": len(reader.pages),
    }


def remove_pages(input_path: str, output_path: str, pages_to_remove: list[int]) -> str:
    """Remove specific pages from a PDF.

    Args:
        input_path: Path to the source PDF.
        output_path: Path for the output PDF.
        pages_to_remove: List of page numbers (1-based) to remove.

    Returns:
        The output path.
    """
    reader = PdfReader(input_path)
    writer = PdfWriter()
    remove_set = set(pages_to_remove)
    for i, page in enumerate(reader.pages):
        if (i + 1) not in remove_set:
            writer.add_page(page)
    with open(output_path, "wb") as f:
        writer.write(f)
    return output_path


def compress_pdf(input_path: str, output_path: str) -> str:
    """Compress a PDF by removing unused objects and compressing streams.

    Args:
        input_path: Path to the source PDF.
        output_path: Path for the compressed PDF.

    Returns:
        The output path.
    """
    reader = PdfReader(input_path)
    writer = PdfWriter()
    for page in reader.pages:
        page.compress_content_streams()
        writer.add_page(page)
    with open(output_path, "wb") as f:
        writer.write(f)
    return output_path
