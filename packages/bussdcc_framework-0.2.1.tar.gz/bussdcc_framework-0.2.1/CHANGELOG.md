# Changelog

## [0.2.1](https://github.com/jbussdieker/bussdcc-framework/compare/v0.2.0...v0.2.1) (2026-03-01)


### Bug Fixes

* **bussdcc_framework:** add py.typed file ([93501a4](https://github.com/jbussdieker/bussdcc-framework/commit/93501a40be3b83383036ef0606bf9f19586b12a9))

## [0.2.0](https://github.com/jbussdieker/bussdcc-framework/compare/v0.1.0...v0.2.0) (2026-03-01)


### Features

* **web:** enhance Flask app creation and remove templates ([c974721](https://github.com/jbussdieker/bussdcc-framework/commit/c974721c78d07f17247a25a0d23faad1cb2a566f))

## 0.1.0 (2026-03-01)


### Features

* initial commit ([0c837b7](https://github.com/jbussdieker/bussdcc-framework/commit/0c837b7021923a01c4782e17b28693d0133e6c96))
