"""Tests for synxis-pms-mcp."""
