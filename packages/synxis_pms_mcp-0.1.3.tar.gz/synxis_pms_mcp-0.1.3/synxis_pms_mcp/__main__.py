"""Run SynXis PMS MCP server as a module."""

from synxis_pms_mcp.cli import main

if __name__ == "__main__":
    main()
