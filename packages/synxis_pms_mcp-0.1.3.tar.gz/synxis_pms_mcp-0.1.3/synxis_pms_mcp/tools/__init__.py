"""MCP tools for SynXis PMS management."""

from synxis_pms_mcp.tools.pms_tools import register_pms_tools

__all__ = ["register_pms_tools"]
