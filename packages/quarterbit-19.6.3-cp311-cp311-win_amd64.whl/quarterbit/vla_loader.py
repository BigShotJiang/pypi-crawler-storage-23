"""
VLA Streaming Loader

Memory-efficient model loading.

Usage:
    from quarterbit.vla_loader import load_vla_model
    model = load_vla_model("model-name", device="cuda")

Clouthier Simulation Labs
"""

import gc
import json
import os
import time
from pathlib import Path
from typing import Optional, Dict, Any, Union

import torch
import torch.nn as nn

from .vla_trainable import VLATrainableLinear, VLATrainableEmbedding, VLAQuantizer

# Try to load CUDA kernel for fast GPU quantization
_HAS_CUDA_KERNEL = False
_vla_cuda = None

def _init_cuda_kernel():
    """Initialize CUDA kernel for GPU-side quantization."""
    global _HAS_CUDA_KERNEL, _vla_cuda
    if _HAS_CUDA_KERNEL or _vla_cuda is not None:
        return _HAS_CUDA_KERNEL
    try:
        from . import vla_cuda
        if vla_cuda.has_cuda_kernel():
            _vla_cuda = vla_cuda
            _HAS_CUDA_KERNEL = True
    except Exception:
        _HAS_CUDA_KERNEL = False
    return _HAS_CUDA_KERNEL


def quantize_on_gpu(weight: torch.Tensor, error_bits: int = 2) -> dict:
    """Quantize weight directly on GPU using CUDA kernel.

    Returns dict with: int4_packed, int4_scale, error_packed, error_scale
    """
    if not _HAS_CUDA_KERNEL:
        raise RuntimeError("CUDA kernel not available")

    # Move to GPU, ensure FP32
    weight_gpu = weight.cuda().float().contiguous()

    # Call CUDA kernel
    int4_packed, int4_scale, error_packed, error_scale = _vla_cuda.vla_quantize_gpu(weight_gpu)

    return {
        'int4_packed': int4_packed,
        'int4_scale': int4_scale.half(),
        'error_packed': error_packed,
        'error_scale': error_scale.half(),
    }


def load_vla_model(
    model_name_or_path: str,
    error_bits: int = 2,
    device: str = "cuda",
    torch_dtype: torch.dtype = torch.float16,
    trust_remote_code: bool = False,
    token: Optional[str] = None,
    verbose: bool = True,
) -> nn.Module:
    """Load model directly into VLA format without FP16 memory peak.

    This loads each layer individually, quantizes to VLA format, and moves
    to GPU before loading the next layer. Peak memory is just the final
    VLA model size.

    Args:
        model_name_or_path: HuggingFace model name or local path
        error_bits: VLA error precision (2=0.75 bytes, 4=1.0 bytes)
        device: Target device ("cuda", "cuda:0", etc.)
        torch_dtype: Dtype for loading (FP16 recommended)
        trust_remote_code: Allow custom model code
        token: HuggingFace token for gated models

    Returns:
        Model in VLA format, fully on GPU, 100% trainable

    Memory (70B example):
        error_bits=2: ~52 GB (0.75 bytes/param)
        error_bits=4: ~70 GB (1.0 bytes/param)
    """
    try:
        from transformers import AutoConfig, AutoModelForCausalLM
        from accelerate import init_empty_weights, infer_auto_device_map
        from safetensors import safe_open
        from safetensors.torch import load_file as load_safetensors
    except ImportError as e:
        raise ImportError(
            f"VLA loader requires: pip install transformers accelerate safetensors\n"
            f"Missing: {e}"
        )

    # Try to init CUDA kernel for GPU-side quantization
    use_gpu_quant = _init_cuda_kernel() and device != 'cpu'

    if verbose:
        print("=" * 60)
        print("VLA STREAMING LOADER")
        print("=" * 60)
        bytes_per_param = 0.5 + (error_bits / 8) * 0.5
        print(f"  Mode: INT4 + INT{error_bits} error = {bytes_per_param:.2f} bytes/param")
        print(f"  Device: {device}")
        print(f"  GPU quantization: {'YES (fast)' if use_gpu_quant else 'NO (CPU fallback)'}")
        print(f"  Loading: {model_name_or_path}")

    # 1. Load config
    config = AutoConfig.from_pretrained(
        model_name_or_path,
        trust_remote_code=trust_remote_code,
        token=token
    )

    if verbose:
        if hasattr(config, 'num_hidden_layers'):
            print(f"  Layers: {config.num_hidden_layers}")
        if hasattr(config, 'hidden_size'):
            print(f"  Hidden: {config.hidden_size}")

    # 2. Create empty model shell (zero memory)
    if verbose:
        print("\n1. Creating empty model structure...")

    with init_empty_weights():
        model = AutoModelForCausalLM.from_config(
            config,
            torch_dtype=torch_dtype,
            trust_remote_code=trust_remote_code
        )

    # 3. Get checkpoint location
    if os.path.isdir(model_name_or_path):
        checkpoint_dir = Path(model_name_or_path)
    else:
        from huggingface_hub import snapshot_download
        checkpoint_dir = Path(snapshot_download(
            model_name_or_path,
            token=token,
            allow_patterns=["*.safetensors", "*.json", "*.bin"]
        ))

    # 4. Find weight files
    index_file = checkpoint_dir / "model.safetensors.index.json"
    if index_file.exists():
        # Sharded model
        with open(index_file) as f:
            index = json.load(f)
        weight_map = index["weight_map"]
        shard_files = sorted(set(weight_map.values()))
        if verbose:
            print(f"  Shards: {len(shard_files)}")
    else:
        # Single file model
        safetensor_file = checkpoint_dir / "model.safetensors"
        if safetensor_file.exists():
            shard_files = ["model.safetensors"]
            weight_map = None
        else:
            # Try pytorch format
            bin_file = checkpoint_dir / "pytorch_model.bin"
            if bin_file.exists():
                shard_files = ["pytorch_model.bin"]
                weight_map = None
            else:
                raise FileNotFoundError(f"No model weights found in {checkpoint_dir}")

    # 5. Build layer name mapping
    if verbose:
        print("\n2. Mapping layers to VLA conversion...")

    layer_mapping = {}  # weight_name -> (module, attr_name)
    vla_layers = []

    # Try to import HuggingFace Conv1D for detection
    try:
        from transformers.pytorch_utils import Conv1D as HFConv1D
    except ImportError:
        HFConv1D = None

    def map_layers(module: nn.Module, prefix: str = ''):
        for name, child in module.named_children():
            full_name = f"{prefix}.{name}" if prefix else name

            if isinstance(child, nn.Linear):
                # Will convert to VLA
                weight_name = f"{full_name}.weight"
                layer_mapping[weight_name] = (module, name, 'linear', child)
                vla_layers.append(full_name)
            elif isinstance(child, nn.Embedding):
                weight_name = f"{full_name}.weight"
                layer_mapping[weight_name] = (module, name, 'embedding', child)
                vla_layers.append(full_name)
            elif HFConv1D is not None and isinstance(child, HFConv1D):
                # HuggingFace Conv1D (used by GPT-2) - transposed linear
                weight_name = f"{full_name}.weight"
                layer_mapping[weight_name] = (module, name, 'conv1d', child)
                vla_layers.append(full_name)
            else:
                map_layers(child, full_name)

    map_layers(model)

    # Build reverse mapping: normalized name -> original mapping key
    # This handles cases where safetensors uses different prefix than model structure
    # e.g., safetensors: "h.0.attn.weight" vs model: "transformer.h.0.attn.weight"
    def normalize_weight_name(name: str) -> str:
        """Remove common model prefixes to get core weight name."""
        prefixes = ['transformer.', 'model.', 'decoder.', 'encoder.', 'base_model.']
        for prefix in prefixes:
            if name.startswith(prefix):
                return name[len(prefix):]
        return name

    normalized_mapping = {}
    for key in layer_mapping:
        normalized = normalize_weight_name(key)
        normalized_mapping[normalized] = key

    def find_layer_mapping(weight_name: str):
        """Find layer mapping entry, handling prefix mismatches."""
        # Direct match
        if weight_name in layer_mapping:
            return layer_mapping[weight_name]
        # Try normalized match (safetensors name without model prefix)
        normalized = normalize_weight_name(weight_name)
        if normalized in normalized_mapping:
            return layer_mapping[normalized_mapping[normalized]]
        # Try adding common prefixes to safetensors name
        for prefix in ['transformer.', 'model.', 'decoder.']:
            prefixed = prefix + weight_name
            if prefixed in layer_mapping:
                return layer_mapping[prefixed]
        return None

    if verbose:
        print(f"  VLA layers: {len(vla_layers)}")

    # 6. Stream load and quantize
    if verbose:
        print("\n3. Loading and quantizing to VLA (streaming)...")

    device = torch.device(device)
    total_loaded = 0
    total_params = 0

    for shard_idx, shard_file in enumerate(shard_files):
        shard_path = checkpoint_dir / shard_file

        if verbose:
            print(f"  Shard {shard_idx + 1}/{len(shard_files)}: {shard_file}")

        # Load shard to CPU
        if shard_file.endswith('.safetensors'):
            shard_weights = load_safetensors(str(shard_path), device='cpu')
        else:
            shard_weights = torch.load(str(shard_path), map_location='cpu')

        # Process each weight in shard
        for weight_name, weight_tensor in shard_weights.items():
            total_params += weight_tensor.numel()

            mapping_entry = find_layer_mapping(weight_name)
            if mapping_entry is not None:
                parent, attr_name, layer_type, old_layer = mapping_entry

                # Create VLA layer with this weight
                if layer_type == 'linear':
                    in_f, out_f = weight_tensor.shape[1], weight_tensor.shape[0]
                    bias_name = weight_name.replace('.weight', '.bias')
                    has_bias = bias_name in shard_weights

                    vla_layer = VLATrainableLinear(
                        in_f, out_f,
                        bias=has_bias,
                        error_bits=error_bits,
                        device='cpu'
                    )

                    # Quantize - use GPU kernel if available
                    if use_gpu_quant:
                        # Fast GPU quantization
                        q = quantize_on_gpu(weight_tensor, error_bits)
                        # Must use register_buffer to properly replace buffers
                        vla_layer.register_buffer('weight_int4', q['int4_packed'])
                        vla_layer.register_buffer('weight_scale', q['int4_scale'])
                        vla_layer.register_buffer('error_packed', q['error_packed'])
                        vla_layer.register_buffer('error_scale', q['error_scale'])
                        vla_layer.register_buffer('outlier_values', None)
                        vla_layer.register_buffer('outlier_indices', None)
                    else:
                        # CPU fallback
                        vla_layer._quantize_and_store(weight_tensor.float())
                        vla_layer = vla_layer.to(device)

                    if has_bias:
                        vla_layer.bias.data = shard_weights[bias_name].to(device=device, dtype=torch.float32)

                    # GPU quantization already on device, CPU needs move
                    if not use_gpu_quant:
                        vla_layer = vla_layer.to(device)
                    setattr(parent, attr_name, vla_layer)

                elif layer_type == 'embedding':
                    num_emb, emb_dim = weight_tensor.shape

                    vla_layer = VLATrainableEmbedding(
                        num_emb, emb_dim,
                        padding_idx=getattr(old_layer, 'padding_idx', None),
                        error_bits=error_bits,
                        device='cpu'
                    )

                    # Quantize - use GPU kernel if available
                    if use_gpu_quant:
                        q = quantize_on_gpu(weight_tensor, error_bits)
                        # Must use register_buffer to properly replace buffers
                        vla_layer.register_buffer('weight_int4', q['int4_packed'])
                        vla_layer.register_buffer('weight_scale', q['int4_scale'])
                        vla_layer.register_buffer('error_packed', q['error_packed'])
                        vla_layer.register_buffer('error_scale', q['error_scale'])
                        vla_layer.register_buffer('outlier_values', None)
                        vla_layer.register_buffer('outlier_indices', None)
                    else:
                        vla_layer._quantize_and_store(weight_tensor.float())
                        vla_layer = vla_layer.to(device)

                    if not use_gpu_quant:
                        vla_layer = vla_layer.to(device)
                    setattr(parent, attr_name, vla_layer)

                elif layer_type == 'conv1d':
                    # HuggingFace Conv1D: weight shape is (nx, nf) = (in_features, out_features)
                    # We convert to VLATrainableLinear which expects (out_features, in_features)
                    in_f, out_f = weight_tensor.shape  # nx, nf
                    bias_name = weight_name.replace('.weight', '.bias')
                    has_bias = bias_name in shard_weights

                    vla_layer = VLATrainableLinear(
                        in_f, out_f,
                        bias=has_bias,
                        error_bits=error_bits,
                        device='cpu'
                    )

                    # Transpose weight from (in, out) to (out, in) for Linear format
                    weight_t = weight_tensor.t().contiguous()

                    # Quantize - use GPU kernel if available
                    if use_gpu_quant:
                        q = quantize_on_gpu(weight_t, error_bits)
                        # Must use register_buffer to properly replace buffers
                        vla_layer.register_buffer('weight_int4', q['int4_packed'])
                        vla_layer.register_buffer('weight_scale', q['int4_scale'])
                        vla_layer.register_buffer('error_packed', q['error_packed'])
                        vla_layer.register_buffer('error_scale', q['error_scale'])
                        vla_layer.register_buffer('outlier_values', None)
                        vla_layer.register_buffer('outlier_indices', None)
                    else:
                        vla_layer._quantize_and_store(weight_t.float())
                        vla_layer = vla_layer.to(device)

                    if has_bias:
                        vla_layer.bias.data = shard_weights[bias_name].to(device=device, dtype=torch.float32)

                    if not use_gpu_quant:
                        vla_layer = vla_layer.to(device)
                    setattr(parent, attr_name, vla_layer)

                total_loaded += 1

            else:
                # Non-VLA layer (LayerNorm, etc.) - load directly to GPU
                # Find and set the parameter using robust path resolution
                parts = weight_name.split('.')
                param_name = parts[-1]
                module_path = '.'.join(parts[:-1])

                # Try to find the module - handle cases where prefix doesn't match
                module = None
                paths_to_try = [module_path]
                # Also try with common prefixes added
                for prefix in ['transformer', 'model', 'decoder', 'encoder']:
                    paths_to_try.append(f"{prefix}.{module_path}" if module_path else prefix)

                for path in paths_to_try:
                    try:
                        if path:
                            module = model.get_submodule(path)
                        else:
                            module = model
                        break  # Found it
                    except (AttributeError, KeyError):
                        continue

                if module is not None and hasattr(module, param_name):
                    # Replace parameter entirely (handles meta tensors from init_empty_weights)
                    # Use float32 to match VLA layer outputs
                    new_param = nn.Parameter(weight_tensor.to(device=device, dtype=torch.float32))
                    setattr(module, param_name, new_param)

        # Free shard memory before loading next
        del shard_weights
        gc.collect()
        if torch.cuda.is_available():
            torch.cuda.empty_cache()

    # 6.5. Handle tied weights (e.g., lm_head tied to embedding)
    # Check for meta tensors that need to be tied/created
    for name, param in list(model.named_parameters()):
        if param.device.type == 'meta':
            # Common tied weight patterns
            if 'lm_head' in name:
                # Find the embedding layer to copy from
                embed_layer = None
                if hasattr(model, 'transformer') and hasattr(model.transformer, 'wte'):
                    embed_layer = model.transformer.wte
                elif hasattr(model, 'model') and hasattr(model.model, 'embed_tokens'):
                    embed_layer = model.model.embed_tokens

                if embed_layer is not None:
                    if verbose:
                        print(f"  Creating lm_head from embedding weights")
                    # Get embedding weights (dequantized if VLA)
                    if hasattr(embed_layer, '_dequantize'):
                        embed_weights = embed_layer._dequantize()  # (vocab, hidden)
                    elif hasattr(embed_layer, 'weight'):
                        embed_weights = embed_layer.weight
                    else:
                        continue  # Can't get weights, skip

                    # Create VLA linear for lm_head (transposed: hidden -> vocab)
                    vocab_size, hidden_size = embed_weights.shape
                    vla_lm_head = VLATrainableLinear(
                        hidden_size, vocab_size,
                        bias=False,
                        error_bits=error_bits,
                        device='cpu'
                    )
                    # lm_head weight should be (vocab, hidden) for F.linear
                    vla_lm_head._quantize_and_store(embed_weights.float())
                    vla_lm_head = vla_lm_head.to(device)
                    model.lm_head = vla_lm_head

    # 7. Verify all on GPU
    if verbose:
        print("\n4. Verifying GPU placement...")

        on_gpu = 0
        on_cpu = 0
        for name, param in model.named_parameters():
            if param.device.type == 'cuda':
                on_gpu += param.numel()
            else:
                on_cpu += param.numel()

        for name, buf in model.named_buffers():
            if buf.device.type == 'cuda':
                on_gpu += buf.numel()
            else:
                on_cpu += buf.numel()

        total = on_gpu + on_cpu
        print(f"  On GPU: {on_gpu:,} ({on_gpu/total*100:.1f}%)")
        if on_cpu > 0:
            print(f"  On CPU: {on_cpu:,} ({on_cpu/total*100:.1f}%) ⚠️")
        else:
            print(f"  CPU offload: NONE ✓")

    # 8. Memory summary
    if verbose and torch.cuda.is_available():
        mem_gb = torch.cuda.memory_allocated() / 1e9
        bytes_pp = 0.5 + (error_bits / 8) * 0.5
        print(f"\n" + "=" * 60)
        print(f"VLA LOADING COMPLETE")
        print(f"=" * 60)
        print(f"  Total params: {total_params:,}")
        print(f"  VLA layers: {total_loaded}")
        print(f"  GPU memory: {mem_gb:.2f} GB")
        print(f"  Bytes/param: ~{bytes_pp:.2f}")
        print(f"  Trainable: 100% (not LoRA/adapters)")

    return model


def estimate_vla_memory(model_name_or_path: str, error_bits: int = 2) -> Dict[str, float]:
    """Estimate memory for VLA model without loading.

    Returns:
        Dict with memory estimates in GB
    """
    try:
        from transformers import AutoConfig
    except ImportError:
        raise ImportError("Requires: pip install transformers")

    config = AutoConfig.from_pretrained(model_name_or_path)

    # Estimate params from config
    if hasattr(config, 'num_parameters'):
        total_params = config.num_parameters
    else:
        # Estimate for typical transformer
        hidden = getattr(config, 'hidden_size', 4096)
        layers = getattr(config, 'num_hidden_layers', 32)
        vocab = getattr(config, 'vocab_size', 32000)
        intermediate = getattr(config, 'intermediate_size', hidden * 4)

        # Rough estimate: embed + layers * (attn + ffn)
        embed_params = vocab * hidden
        attn_params = 4 * hidden * hidden  # Q, K, V, O
        ffn_params = 3 * hidden * intermediate  # gate, up, down
        layer_params = attn_params + ffn_params
        total_params = embed_params + layers * layer_params

    bytes_per_param = 0.5 + (error_bits / 8) * 0.5

    return {
        'total_params': total_params,
        'params_billions': total_params / 1e9,
        'vla_bytes_per_param': bytes_per_param,
        'vla_memory_gb': total_params * bytes_per_param / 1e9,
        'fp16_memory_gb': total_params * 2 / 1e9,
        'fp32_memory_gb': total_params * 4 / 1e9,
        'compression_vs_fp32': 4.0 / bytes_per_param,
        'compression_vs_fp16': 2.0 / bytes_per_param,
    }


if __name__ == "__main__":
    print("VLA Streaming Loader")
    print("=" * 40)
    print("\nUsage:")
    print("  from quarterbit.vla_loader import load_vla_model")
    print("  model = load_vla_model('meta-llama/Llama-2-70b-hf', error_bits=2)")
    print("\nMemory estimates:")

    for model in ["meta-llama/Llama-2-7b-hf", "meta-llama/Llama-2-70b-hf"]:
        try:
            est = estimate_vla_memory(model, error_bits=2)
            print(f"\n{model}:")
            print(f"  Params: {est['params_billions']:.1f}B")
            print(f"  FP16: {est['fp16_memory_gb']:.1f} GB")
            print(f"  VLA:  {est['vla_memory_gb']:.1f} GB ({est['compression_vs_fp16']:.1f}x smaller)")
        except Exception as e:
            print(f"\n{model}: {e}")
