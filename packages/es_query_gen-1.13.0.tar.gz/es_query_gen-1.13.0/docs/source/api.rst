API Reference
=============

Automatic documentation for the public API exported by the package.

.. automodule:: es_query_gen
   :members:
   :undoc-members:
   :show-inheritance:
