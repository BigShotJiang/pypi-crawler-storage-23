# Brink SDK

[![PyPI version](https://badge.fury.io/py/brink-sdk.svg)](https://pypi.org/project/brink-sdk/)
[![Python](https://img.shields.io/pypi/pyversions/brink-sdk)](https://pypi.org/project/brink-sdk/)
[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](https://opensource.org/licenses/Apache-2.0)

**The operations platform for AI agents — SRE primitives for agent reliability.**

Brink brings Site Reliability Engineering to AI agents: circuit breakers that trip on behavioral degradation (not just HTTP errors), SLOs and error budgets for agent-native quality metrics, and chaos testing designed for the failure modes unique to LLM-powered systems.

## Installation

```bash
pip install brink-sdk
```

## What It Does

Traditional monitoring tells you **whether your infrastructure is healthy**. Brink tells you **whether your agents are behaving correctly** — catching hallucination, infinite loops, cost runaway, goal drift, and cascading failures across multi-agent pipelines.

- 🔌 **Circuit Breakers** — Trip on quality degradation, cost spikes, and step count explosion
- 📊 **SLOs & Error Budgets** — Quantify reliability with agent-native metrics
- 💥 **Chaos Testing** — Inject semantic-layer faults to build confidence before production breaks
- 🔭 **Structured Observability** — Hierarchical tracing (Session → Task → Step → Interaction)
- 🛡️ **Budget Guards** — Hard limits on cost, tokens, steps, and time per agent run

## Quick Start

```python
from brink import monitor

@monitor
def my_agent(query: str) -> str:
    # Your agent code here
    ...
```

> ⚠️ **Pre-release:** This package is under active development. The API is not yet stable.

## License

Apache License 2.0 — see [LICENSE](LICENSE) for details.