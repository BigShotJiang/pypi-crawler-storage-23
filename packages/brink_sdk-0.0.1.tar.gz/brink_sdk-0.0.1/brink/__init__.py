"""Brink — The operations platform for AI agents.

SRE primitives (circuit breakers, SLOs, error budgets, chaos testing)
for AI agent reliability engineering.

Usage::

    from brink import monitor

    @monitor
    def my_agent(query: str) -> str:
        ...
"""

__version__ = "0.0.1"

__all__ = [
    "__version__",
    # Future public API — these will be importable as features are built:
    # "monitor",
    # "CircuitBreaker",
    # "SLO",
    # "Budget",
    # "ChaosMiddleware",
]
