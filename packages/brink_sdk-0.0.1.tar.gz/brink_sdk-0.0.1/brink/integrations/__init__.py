"""Framework-specific adapters (Layer 2 enrichment).

Optional integrations for LangChain, CrewAI, OpenAI Agents SDK, and Pydantic AI
that add semantic hierarchy (sessions, tasks, steps, handoffs) to traces.
"""
