"""Telemetry exporters.

Terminal output (rich formatting), local file storage (JSON, JSONL, SQLite),
HTTP export to the Brink backend, and OTLP export to any OTel-compatible backend.
"""
