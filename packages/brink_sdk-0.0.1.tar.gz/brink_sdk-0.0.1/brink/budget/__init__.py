"""Per-session budget guards.

Hard limits (cost, tokens, steps, time, retries) that terminate an agent run
when it exceeds predefined resource boundaries.
"""
