"""Chaos testing framework for AI agents.

Fault injection (latency, errors, response mutation, tool failures),
scenario definitions, baseline capture, and assertion-based reporting.
"""
