"""Core data models, configuration, and context propagation.

This module contains the foundational data structures (Session, Task, Step,
Interaction), the configuration system, and trace context management.
"""
