"""Command-line interface.

CLI commands for inspecting agent health, session traces, SLO status,
circuit breaker state, and running chaos tests.
"""
