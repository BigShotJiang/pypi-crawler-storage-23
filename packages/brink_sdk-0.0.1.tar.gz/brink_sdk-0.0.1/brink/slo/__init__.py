"""SLO engine and error budgets.

Service Level Objectives, error budget computation, burn rate alerting,
and budget enforcement for agent-native quality metrics.
"""
