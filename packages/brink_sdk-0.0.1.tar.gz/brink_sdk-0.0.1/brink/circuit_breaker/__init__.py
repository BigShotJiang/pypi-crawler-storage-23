"""Agent-workflow circuit breakers.

Behavioral circuit breakers that trip on quality degradation, cost accumulation,
step count inflation, and loop detection — not just HTTP errors.
"""
