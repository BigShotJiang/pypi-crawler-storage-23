# =====================================
# generator=datazen
# version=3.2.3
# hash=ecb505a5690c586251a5e89039925554
# =====================================

"""
Useful defaults and other package metadata.
"""

DESCRIPTION = "Read the sign."
PKG_NAME = "experimental-lowqa"
VERSION = "0.1.13"
