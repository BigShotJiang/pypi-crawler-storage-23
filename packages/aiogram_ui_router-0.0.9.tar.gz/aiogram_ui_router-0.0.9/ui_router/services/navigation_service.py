"""
Navigation service for managing scene transitions and state.

This service provides a thin wrapper around NavigationManager for convenient
access to navigation operations. It's used to extract navigation logic from
UIRouterExecutor as part of the service extraction refactoring.
"""

import logging

from ui_router.state.context import NavigationManager, NavigationState
from ui_router.schema import TransitionType


logger = logging.getLogger(__name__)


class NavigationService:
    """
    Service for managing navigation between scenes.

    Provides convenient methods for navigating between scenes, going back,
    and retrieving navigation state. Works with NavigationManager to handle
    scene transitions and maintain navigation history.

    Attributes:
        navigation_manager: The underlying NavigationManager instance.
    """

    def __init__(self, navigation_manager: NavigationManager) -> None:
        """
        Initialize NavigationService.

        Args:
            navigation_manager: NavigationManager instance to delegate to.
        """
        self.navigation_manager = navigation_manager

    async def initialize(
        self,
        bot_id: int | str,
        user_id: int,
        chat_id: int,
        initial_scene: str,
    ) -> NavigationState:
        """
        Initialize navigation for a new user.

        Creates initial navigation state with the specified scene as current.

        Args:
            bot_id: ID of the bot.
            user_id: ID of the user.
            chat_id: ID of the chat.
            initial_scene: ID of the initial scene to start with.

        Returns:
            The initialized NavigationState.
        """
        return await self.navigation_manager.initialize(
            bot_id=bot_id,
            user_id=user_id,
            chat_id=chat_id,
            initial_scene=initial_scene,
        )

    async def navigate_to(
        self,
        bot_id: int | str,
        user_id: int,
        chat_id: int,
        scene_id: str,
        save_to_history: bool = True,
        transition_type: TransitionType = TransitionType.SEND,
    ) -> NavigationState:
        """
        Navigate to a scene.

        Updates the current scene and optionally adds the previous scene to history.

        Args:
            bot_id: ID of the bot.
            user_id: ID of the user.
            chat_id: ID of the chat.
            scene_id: ID of the scene to navigate to.
            save_to_history: Whether to add the current scene to history.
            transition_type: Type of transition (SEND, EDIT_SMART, ANSWER).

        Returns:
            The updated NavigationState.
        """
        return await self.navigation_manager.navigate_to(
            bot_id=bot_id,
            user_id=user_id,
            chat_id=chat_id,
            scene_id=scene_id,
            add_to_history=save_to_history,
            transition=transition_type,
        )

    async def go_back(
        self,
        bot_id: int | str,
        user_id: int,
        chat_id: int,
    ) -> tuple[NavigationState, str | None, str]:
        """
        Go back to the previous scene.

        Returns the previous scene from history and restores it as the current scene.

        Args:
            bot_id: ID of the bot.
            user_id: ID of the user.
            chat_id: ID of the chat.

        Returns:
            Tuple of (updated_state, previous_scene_id, transition_type).
            If there is no history, previous_scene_id will be None.
        """
        return await self.navigation_manager.go_back(
            bot_id=bot_id,
            user_id=user_id,
            chat_id=chat_id,
        )

    async def get_current_state(
        self,
        bot_id: int | str,
        user_id: int,
        chat_id: int,
    ) -> NavigationState:
        """
        Get the current navigation state.

        Retrieves the current navigation state from storage.

        Args:
            bot_id: ID of the bot.
            user_id: ID of the user.
            chat_id: ID of the chat.

        Returns:
            The current NavigationState.
        """
        return await self.navigation_manager.get_state(
            bot_id=bot_id,
            user_id=user_id,
            chat_id=chat_id,
        )

    async def save_state(
        self,
        bot_id: int | str,
        user_id: int,
        chat_id: int,
        state: NavigationState,
    ) -> None:
        """
        Save navigation state to storage.

        Args:
            bot_id: ID of the bot.
            user_id: ID of the user.
            chat_id: ID of the chat.
            state: The NavigationState to save.
        """
        await self.navigation_manager.save_state(
            bot_id=bot_id,
            user_id=user_id,
            chat_id=chat_id,
            state=state,
        )
