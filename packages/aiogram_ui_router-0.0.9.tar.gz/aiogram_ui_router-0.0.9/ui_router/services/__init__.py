"""
Services package for UI Router.

Contains SharedServices and other service components used across the UI Router.
"""

from .shared import CacheStorageProtocol, SharedServices
from .navigation_service import NavigationService
from .content_service import ContentService
from .localization_service import LocalizationService
from .handler_service import HandlerService
from .scene_renderer import SceneRenderer

__all__ = [
    "CacheStorageProtocol",
    "ContentService",
    "HandlerService",
    "LocalizationService",
    "NavigationService",
    "SceneRenderer",
    "SharedServices",
]
