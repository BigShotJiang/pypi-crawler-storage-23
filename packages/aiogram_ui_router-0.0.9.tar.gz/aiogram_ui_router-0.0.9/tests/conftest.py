"""Shared pytest fixtures for all tests."""

import pytest

from ui_router.services import SharedServices
from ui_router.events import EventBus, InMemoryEventScheduler
from ui_router.state.storage import InMemoryNavigationStorage
from ui_router.state.variables import InMemoryVariableRepository


@pytest.fixture
def navigation_storage():
    """Create an in-memory navigation storage."""
    return InMemoryNavigationStorage()


@pytest.fixture
def variable_repository():
    """Create an in-memory variable repository."""
    return InMemoryVariableRepository()


@pytest.fixture
def event_bus():
    """Create an event bus."""
    return EventBus()


@pytest.fixture
def event_scheduler(event_bus):
    """Create an event scheduler."""
    return InMemoryEventScheduler(event_callback=event_bus.emit)


@pytest.fixture
def shared_services(navigation_storage, variable_repository, event_bus, event_scheduler):
    """Create SharedServices with all components."""
    return SharedServices(
        navigation_storage=navigation_storage,
        variable_repository=variable_repository,
        event_bus=event_bus,
        event_scheduler=event_scheduler,
    )
