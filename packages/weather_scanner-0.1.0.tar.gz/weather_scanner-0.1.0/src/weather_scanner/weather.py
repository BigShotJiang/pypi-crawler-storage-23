import requests


class InfoCuaca:
    def __init__(self):
        self.base_url = "https://api.open.meteo.com"

    def checkweather(self, city: str):
        location = {
            "jakarta": {"lat": -6.21, "lon": 106.84},
            "bandung": {"lat": -6.91, "lon": 107.60},
            "surabaya": {"lat": -7.25, "lon": 112.75},
        }

        city = city.lower()

        if city in location:
            lat = location[city]["lat"]
            lon = location[city]["lon"]
            params = {"latitude": lat, "longitude": lon, "current_weather": True}

            res = requests.get(self.base_url, params=params)

            data = res.json()
            suhu = data["current_weather"]["temperature"]

            return f"Suhu now at {city.capitalize()} is {suhu}C"
        else:
            return "Sorry, city not register"
