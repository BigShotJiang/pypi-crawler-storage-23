"""Version information for uma-api."""

__version__ = "1.6.0"
