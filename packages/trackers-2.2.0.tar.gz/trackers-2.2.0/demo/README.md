---
title: Roboflow Trackers
emoji: 🔥
colorFrom: purple
colorTo: green
sdk: gradio
sdk_version: 6.3.0
app_file: app.py
suggested_hardware: l4x1
license: apache-2.0
python_version: '3.11'
---
