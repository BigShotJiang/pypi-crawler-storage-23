# Trackers API

## SORT

::: trackers.core.sort.tracker.SORTTracker

## ByteTrack

::: trackers.core.bytetrack.tracker.ByteTrackTracker
