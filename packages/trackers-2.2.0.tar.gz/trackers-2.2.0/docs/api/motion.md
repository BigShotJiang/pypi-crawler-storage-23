# Motion API

## MotionEstimator

::: trackers.motion.estimator.MotionEstimator

## MotionAwareTraceAnnotator

::: trackers.annotators.trace.MotionAwareTraceAnnotator

## CoordinatesTransformation

::: trackers.motion.transformation.CoordinatesTransformation

## IdentityTransformation

::: trackers.motion.transformation.IdentityTransformation

## HomographyTransformation

::: trackers.motion.transformation.HomographyTransformation
