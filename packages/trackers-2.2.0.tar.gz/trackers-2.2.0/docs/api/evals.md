# Evals API

::: trackers.eval.evaluate.evaluate_mot_sequence

::: trackers.eval.evaluate.evaluate_mot_sequences

::: trackers.eval.results.SequenceResult

::: trackers.eval.results.BenchmarkResult

::: trackers.eval.results.CLEARMetrics

::: trackers.eval.results.HOTAMetrics

::: trackers.eval.results.IdentityMetrics
