"""Version information for sagellm."""

__version__ = "0.5.3.0"
__author__ = "IntelliStream Team"
