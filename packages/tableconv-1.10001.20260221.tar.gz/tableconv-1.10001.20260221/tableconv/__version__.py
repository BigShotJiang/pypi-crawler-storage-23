VERSION = (1, 10001, 20260221)

__version__ = ".".join(map(str, VERSION))
