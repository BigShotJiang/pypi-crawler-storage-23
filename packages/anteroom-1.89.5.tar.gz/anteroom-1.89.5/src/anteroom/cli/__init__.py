"""Anteroom CLI - interactive agentic chat mode."""
