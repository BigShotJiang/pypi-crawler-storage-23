from setuptools import setup, find_packages
# To use a consistent encoding
from codecs import open
from os import path

# workaround from https://github.com/pypa/setuptools/issues/308 to avoid "normalizing" version "2018.01.09" to "2018.1.9":
# 2019-03-08: got error
#    vk@sherri ~/src/filetags (git)-[master] % ./update_pip.sh
#    Traceback (most recent call last):
#      File "setup.py", line 11, in <module>
#        pkg_resources.extern.packaging.version.Version = pkg_resources.SetuptoolsLegacyVersion
#    AttributeError: module 'pkg_resources' has no attribute 'SetuptoolsLegacyVersion'
#    1 vk@sherri ~/src/filetags (git)-[master] %
#import pkg_resources
#pkg_resources.extern.packaging.version.Version = pkg_resources.SetuptoolsLegacyVersion

here = path.abspath(path.dirname(__file__))

# Get the long description from the README file
#with open(path.join(here, 'README.rst'), encoding='utf-8') as f:
#    long_description = f.read()

setup(
    name="move2archive",
    version="2023.07.15.1",
    description="Managing event-related files in a folder hierarchy like <ARCHIVE>/2013/2013-05-17 Event name/",
    author="Karl Voit",
    author_email="tools@Karl-Voit.at",
    url="https://github.com/novoid/move2archive",
    download_url="https://github.com/novoid/move2archive/zipball/master",
    keywords=["file managing", "file management", "files", "date", "time", "time-stamps"],
    install_requires=["pyreadline3"],
    packages=find_packages(), # Required
    #package_data={'move2archive': ['Register_move2archive_for_Windows_context_menu_TEMPLATE.reg']},
    classifiers=[
        "Programming Language :: Python :: 3 :: Only",
        "Development Status :: 5 - Production/Stable",
        "Environment :: Console",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: GNU General Public License (GPL)",
        "Operating System :: OS Independent",
        ],
    entry_points={  # Optional
        'console_scripts': [
            'move2archive=move2archive:main',
            'm2a=move2archive:main',
        ],
    },
#    long_description=long_description, # Optional
    long_description_content_type="text/markdown",
    long_description="""This script moves items (files or directories) containing ISO datestamps
like "YYYY-MM-DD" into a directory stucture for the corresponding year.

You define the base directory either in this script (or using the
command line argument "--archivedir"). The convention is e.g.:

- <archivepath>/2009
- <archivepath>/2010
- <archivepath>/2011

By default, this script extracts the year from the datestamp of
each file and moves it into the corresponding directory for its year:

     m2a 2010-01-01_Jan2010.txt 2011-02-02_Feb2011.txt
... moves "2010-01-01_Jan2010.txt" to "<archivepath>/2010/"
... moves "2011-02-02_Feb2011.txt" to "<archivepath>/2011/"

OPTIONALLY you can define a sub-directory name with option "-d DIR". If it
contains no datestamp by itself, a datestamp from the first file of the
argument list will be used. This datestamp will be put in front of the name:

     m2a  -d "2009-02-15 bar"  one two three
... moves all items to: "<archivepath>/2009/2009-02-15 bar/"

     m2a  -d bar  2011-10-10_one 2008-01-02_two 2011-10-12_three
... moves all items to: "<archivepath>/2011/2011-10-10 bar/"

If you feel uncomfortable you can simulate the behavior using the "--dryrun"
option. You see what would happen without changing anything at all.
"""
)
