void init() {}

int add_one(int n) {
    return n + 1;
}
