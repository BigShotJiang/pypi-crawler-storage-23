"""Usecli CLI package."""

from __future__ import annotations

from usecli.cli.services.command_service import CommandService

__all__ = ["CommandService"]
