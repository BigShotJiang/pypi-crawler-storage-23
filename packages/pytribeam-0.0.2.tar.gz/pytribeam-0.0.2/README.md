# pyTriBeam

![main_logo](https://raw.githubusercontent.com/sandialabs/pytribeam/refs/heads/gh-pages/docs/userguide/src/logo_color.png)

[![userguide][userguide_badge]](https://sandialabs.github.io/pytribeam/docs/userguide/book/index.html) [![api][api_badge]](https://sandialabs.github.io/pytribeam/docs/api/index.html) [![test-coverage][test-coverage_badge]](https://sandialabs.github.io/pytribeam/coverage_reports/combined/htmlcov/index.html) [![lint][lint_badge]](https://sandialabs.github.io/pytribeam/logs/lint.log) [![version][version_badge]](https://github.com/sandialabs/pytribeam) 

[userguide_badge]: https://sandialabs.github.io/pytribeam/badges/userguide.svg
[api_badge]: https://sandialabs.github.io/pytribeam/badges/api.svg
[test-coverage_badge]: https://sandialabs.github.io/pytribeam/badges/test-coverage.svg
[lint_badge]: https://sandialabs.github.io/pytribeam/badges/lint.svg
[version_badge]: https://sandialabs.github.io/pytribeam/badges/version.svg

## Getting Started

Installation instructions and more can be found in the [User Guide](https://sandialabs.github.io/pytribeam/docs/userguide/book/index.html).

## Citing ``pytribeam``

If ``pytribeam`` has been useful in your research, we invite you to cite the following paper on it's development and use:

Polonsky, A.T., Lamb, J.D., Hovey, C.B. et al. pyTriBeam: Open-Source Software for Enhanced 3D Data Collection in TriBeam Microscopes. Integr Mater Manuf Innov (2026). https://doi.org/10.1007/s40192-026-00449-2

Or using BibTeX:
```bibtex
@article{Polonsky2026,
  title = {pyTriBeam: Open-Source Software for Enhanced 3D Data Collection in TriBeam Microscopes},
  ISSN = {2193-9772},
  url = {http://dx.doi.org/10.1007/s40192-026-00449-2},
  DOI = {10.1007/s40192-026-00449-2},
  journal = {Integrating Materials and Manufacturing Innovation},
  publisher = {Springer Science and Business Media LLC},
  author = {Polonsky,  Andrew T. and Lamb,  James D. and Hovey,  Chad B. and Schroader,  Haydn and Echlin,  McLean P. and Pollock,  Tresa M.},
  year = {2026},
  month = feb 
}
```



