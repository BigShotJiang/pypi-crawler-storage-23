"""GUI submodule for PyTribeam."""
