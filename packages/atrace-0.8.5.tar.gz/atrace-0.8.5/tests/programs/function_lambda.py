import atrace  # noqa

add = lambda x, y: x + y  # noqa
print(add(5, 3))
