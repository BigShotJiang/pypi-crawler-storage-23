import atrace  # noqa

lst = ["a", "b"]
while lst:
    print(lst.pop(0))
