import atrace  # noqa

x = 1
print(x)
