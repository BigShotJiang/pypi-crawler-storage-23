import atrace  # noqa

print("hello")
