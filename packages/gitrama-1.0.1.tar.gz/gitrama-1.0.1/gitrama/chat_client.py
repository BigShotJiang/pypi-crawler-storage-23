"""
Gitrama AskGIT - Thin Chat Client
Ships in pip package. Contains zero IP.
All intelligence lives at api.gitrama.ai.

Copyright © 2026 Gitrama LLC. All Rights Reserved.
"""

import re
import subprocess
import platform
from typing import Optional, List

import typer
import requests
from rich.console import Console
from rich.panel import Panel
from rich.rule import Rule

from .config import get_value
from .streams import StreamManager

console = Console()

# ─── Server config ────────────────────────────────────────────────────────────
CHAT_SERVER_URL = "https://api.gitrama.ai"
REQUEST_TIMEOUT = 30

# ─── Runtime config — fetched from server, not hardcoded ─────────────────────
# These are populated by _load_server_config() at session start.
# Nothing valuable lives here in the shipped package.
SAFE_COMMANDS: dict = {}
BLOCKED_COMMANDS: list = []
INTENT_MAP: list = []

# ─── Minimal fallback config (used only if server is unreachable) ─────────────
# Intentionally sparse — just enough to not crash. No real logic exposed.
_FALLBACK_SAFE_COMMANDS = {
    "gtr status": {"args": False, "confirm": False, "category": "read"},
    "gtr log":    {"args": True,  "confirm": False, "category": "read"},
}
_FALLBACK_BLOCKED = ["git", "rm", "del", "format"]
_FALLBACK_INTENT  = []

def _load_server_config(token: str) -> bool:
    """
    Fetch INTENT_MAP, SAFE_COMMANDS, BLOCKED_COMMANDS from api.gitrama.ai/config.
    Populates module-level globals at session start.
    Returns True if loaded from server, False if using fallback.
    """
    global SAFE_COMMANDS, BLOCKED_COMMANDS, INTENT_MAP
    try:
        response = requests.get(
            f"{CHAT_SERVER_URL}/config",
            headers={"x-gitrama-token": token},
            timeout=10,
        )
        if response.status_code == 200:
            data           = response.json()
            # INTENT_MAP comes back as list of [triggers_list, command] pairs
            INTENT_MAP     = [
                (item[0], item[1]) for item in data.get("intent_map", [])
            ]
            SAFE_COMMANDS  = data.get("safe_commands", _FALLBACK_SAFE_COMMANDS)
            BLOCKED_COMMANDS = data.get("blocked_commands", _FALLBACK_BLOCKED)
            return True
        else:
            SAFE_COMMANDS    = _FALLBACK_SAFE_COMMANDS
            BLOCKED_COMMANDS = _FALLBACK_BLOCKED
            INTENT_MAP       = _FALLBACK_INTENT
            return False
    except Exception:
        SAFE_COMMANDS    = _FALLBACK_SAFE_COMMANDS
        BLOCKED_COMMANDS = _FALLBACK_BLOCKED
        INTENT_MAP       = _FALLBACK_INTENT
        return False

# ─── Git helpers (all run locally) ───────────────────────────────────────────
def _run(cmd: List[str]) -> str:
    try:
        result = subprocess.run(
            cmd, capture_output=True, text=True,
            timeout=10, encoding="utf-8", errors="replace"
        )
        return result.stdout.strip()
    except Exception:
        return ""


def _is_git_repo() -> bool:
    """Check if current directory is inside a git repo."""
    result = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        capture_output=True, text=True
    )
    return result.returncode == 0


def _get_repo_context() -> dict:
    ctx = {}
    ctx["branch"]       = _run(["git", "rev-parse", "--abbrev-ref", "HEAD"])
    ctx["remote"]       = _run(["git", "remote", "get-url", "origin"])
    ctx["commits"]      = _run(["git", "log", "--oneline", "-20"])
    ctx["status"]       = _run(["git", "status", "--porcelain"])
    ctx["stashes"]      = _run(["git", "stash", "list"])
    ctx["os"]           = platform.system()
    ctx["staged"]       = _run(["git", "diff", "--staged", "--name-only"]) or "none"
    ctx["modified"]     = _run(["git", "diff", "--name-only"]) or "none"
    ctx["contributors"] = _run(["git", "shortlog", "-sn", "--no-merges", "-10"])
    try:
        manager = StreamManager()
        ctx["stream"] = manager.data.get("current", "wip")
    except Exception:
        ctx["stream"] = "unknown"
    return ctx


def _get_repo_stats() -> str:
    total_commits    = _run(["git", "rev-list", "--count", "HEAD"])
    first_commit     = _run(["git", "log", "--reverse", "--pretty=format:%ad", "--date=short", "-1"])
    total_authors    = len(set(_run(["git", "log", "--pretty=format:%ae"]).splitlines()))
    file_count       = len(_run(["git", "ls-files"]).splitlines())
    branches         = _run(["git", "branch", "-a", "--format=%(refname:short)"])
    branch_count     = len([b for b in branches.splitlines() if b.strip()])
    return (
        f"Total commits: {total_commits} | First commit: {first_commit} | "
        f"Authors: {total_authors} | Files: {file_count} | Branches: {branch_count}"
    )


def _build_git_context_string(ctx: dict) -> str:
    """Format repo context into a string to send to server."""
    return f"""Branch: {ctx.get('branch', 'unknown')}
Remote: {ctx.get('remote', 'unknown')}
Stream: {ctx.get('stream', 'unknown')}

Recent commits (last 20):
{ctx.get('commits', 'No commits found')}

Status: {ctx.get('status', 'Clean')}
Staged: {ctx.get('staged', 'none')}
Modified: {ctx.get('modified', 'none')}
Stashes: {ctx.get('stashes', 'none')}
Top contributors:
{ctx.get('contributors', 'unknown')}"""


def _fetch_file_diff(filepath: str) -> str:
    result = _run(["git", "diff", "HEAD", "--", filepath])
    if not result:
        result = _run(["git", "diff", "--staged", "--", filepath])
    return result or f"No changes detected in {filepath}"


def _fetch_file_log(filepath: str, count: int = 10) -> str:
    return _run(["git", "log", "--oneline", f"-{count}", "--follow", "--", filepath])


def _fetch_file_content(filepath: str) -> str:
    try:
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
        if len(lines) > 200:
            return "".join(lines[:200]) + f"\n... (truncated, {len(lines)} total lines)"
        return "".join(lines)
    except FileNotFoundError:
        return f"File not found: {filepath}"
    except Exception as e:
        return f"Could not read file: {e}"


def _fetch_branch_diff(base: str, target: str = None) -> str:
    if target:
        return _run(["git", "diff", f"{base}...{target}"])
    return _run(["git", "diff", base])


def _fetch_full_history(limit: int = 500) -> str:
    return _run([
        "git", "log", "--pretty=format:%h|%an|%ae|%ad|%s",
        "--date=short", f"-{limit}"
    ])


def _fetch_author_history(author: str, limit: int = 100) -> str:
    return _run([
        "git", "log", f"--author={author}",
        "--pretty=format:%h|%ad|%s", "--date=short", f"-{limit}"
    ])


def _fetch_date_range_history(after: str, before: str = None) -> str:
    cmd = [
        "git", "log", "--pretty=format:%h|%an|%ad|%s",
        "--date=short", f"--after={after}",
    ]
    if before:
        cmd.append(f"--before={before}")
    return _run(cmd)


def _fetch_full_file_history(filepath: str) -> str:
    return _run([
        "git", "log", "--follow",
        "--pretty=format:%h|%an|%ad|%s",
        "--date=short", "--", filepath
    ])


# ─── Context enrichment (runs locally, appended to message) ──────────────────
def _enrich_prompt_with_context(user_input: str) -> str:
    extra = []
    lower = user_input.lower()
    file_pattern = re.compile(
        r'[\w/.-]+\.(?:py|js|ts|jsx|tsx|json|md|yaml|yml|txt|sh|env|toml|cfg|ini|html|css)'
    )
    full_files = file_pattern.findall(user_input)

    if any(w in lower for w in ["diff", "compare", "changed", "difference", "vs", "versus"]):
        for filepath in full_files:
            diff = _fetch_file_diff(filepath)
            if diff:
                extra.append(f"\n### Current diff for `{filepath}`:\n```\n{diff[:3000]}\n```")

    if any(w in lower for w in ["history", "log", "commits for", "who changed", "when was", "last modified"]):
        for filepath in full_files:
            log = _fetch_file_log(filepath)
            if log:
                extra.append(f"\n### Commit history for `{filepath}`:\n```\n{log}\n```")

    if any(w in lower for w in ["show me", "read", "content of", "what's in", "open", "display"]):
        for filepath in full_files:
            content = _fetch_file_content(filepath)
            extra.append(f"\n### Content of `{filepath}`:\n```\n{content}\n```")

    branch_diff_match = re.search(r'diff\s+(\S+)\s+(?:vs|versus|and|to)\s+(\S+)', lower)
    if branch_diff_match:
        base   = branch_diff_match.group(1)
        target = branch_diff_match.group(2)
        diff   = _fetch_branch_diff(base, target)
        if diff:
            extra.append(f"\n### Diff between `{base}` and `{target}`:\n```\n{diff[:3000]}\n```")

    if any(w in lower for w in ["staged", "about to commit", "what am i committing"]):
        staged_diff = _run(["git", "diff", "--staged"])
        if staged_diff:
            extra.append(f"\n### Currently staged changes:\n```\n{staged_diff[:3000]}\n```")

    if any(w in lower for w in ["full status", "detailed status", "what's changed"]):
        full_status = _run(["git", "status"])
        if full_status:
            extra.append(f"\n### Full git status:\n```\n{full_status}\n```")

    return "\n".join(extra)


def _deep_enrich_prompt(user_input: str) -> str:
    import datetime
    extra = []
    lower = user_input.lower()

    file_pattern = re.compile(
        r'[\w/.-]+\.(?:py|js|ts|jsx|tsx|json|md|yaml|yml|txt|sh|env|toml|cfg|ini|html|css)'
    )
    full_files = file_pattern.findall(user_input)

    if full_files and any(w in lower for w in [
        "history", "log", "changed", "touched", "modified",
        "evolution", "commits for", "who changed", "when was"
    ]):
        for filepath in full_files:
            log = _fetch_full_file_history(filepath)
            if log:
                extra.append(
                    f"\n### Full history of `{filepath}` (every commit ever):\n"
                    f"Format: hash|author|date|message\n```\n{log[:4000]}\n```"
                )

    author_patterns = [
        r"(?:by|from|author|commits? by|work by|what did|show me)\s+([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)",
        r"([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)'s\s+commits?",
    ]
    for pattern in author_patterns:
        match = re.search(pattern, user_input)
        if match:
            author = match.group(1)
            log = _fetch_author_history(author)
            if log:
                extra.append(
                    f"\n### All commits by `{author}`:\n"
                    f"Format: hash|date|message\n```\n{log[:4000]}\n```"
                )
            break

    month_map = {
        "january": "01", "february": "02", "march": "03", "april": "04",
        "may": "05", "june": "06", "july": "07", "august": "08",
        "september": "09", "october": "10", "november": "11", "december": "12",
        "jan": "01", "feb": "02", "mar": "03", "apr": "04",
        "jun": "06", "jul": "07", "aug": "08",
        "sep": "09", "oct": "10", "nov": "11", "dec": "12"
    }

    month_year = re.search(
        r'(january|february|march|april|may|june|july|august|september|october|november|december|'
        r'jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\s+(\d{4})', lower
    )
    if month_year:
        month = month_map[month_year.group(1)]
        year  = month_year.group(2)
        after = f"{year}-{month}-01"
        next_month = int(month) + 1
        next_year  = year
        if next_month > 12:
            next_month = 1
            next_year  = str(int(year) + 1)
        before = f"{next_year}-{next_month:02d}-01"
        log = _fetch_date_range_history(after, before)
        if log:
            extra.append(
                f"\n### Commits from {month_year.group(1).capitalize()} {year}:\n"
                f"```\n{log[:4000]}\n```"
            )

    quarter = re.search(r'q([1-4])\s*(\d{4})', lower)
    if quarter:
        q    = int(quarter.group(1))
        year = quarter.group(2)
        quarter_starts = {"1": "01", "2": "04", "3": "07", "4": "10"}
        quarter_ends   = {"1": "04", "2": "07", "3": "10", "4": "01"}
        after    = f"{year}-{quarter_starts[str(q)]}-01"
        end_year = str(int(year) + 1) if q == 4 else year
        before   = f"{end_year}-{quarter_ends[str(q)]}-01"
        log = _fetch_date_range_history(after, before)
        if log:
            extra.append(f"\n### Commits from Q{q} {year}:\n```\n{log[:4000]}\n```")

    if "last year" in lower or "previous year" in lower:
        year = datetime.datetime.now().year - 1
        log  = _fetch_date_range_history(f"{year}-01-01", f"{year+1}-01-01")
        if log:
            extra.append(f"\n### All commits from {year}:\n```\n{log[:4000]}\n```")

    if "this year" in lower:
        year = datetime.datetime.now().year
        log  = _fetch_date_range_history(f"{year}-01-01")
        if log:
            extra.append(f"\n### All commits so far in {year}:\n```\n{log[:4000]}\n```")

    since_date = re.search(r'(?:since|after|from)\s+(\d{4}-\d{2}-\d{2})', lower)
    if since_date:
        log = _fetch_date_range_history(since_date.group(1))
        if log:
            extra.append(f"\n### Commits since {since_date.group(1)}:\n```\n{log[:4000]}\n```")

    if any(w in lower for w in [
        "all commits", "full history", "entire history",
        "every commit", "show all", "whole history",
        "complete history", "all changes"
    ]):
        log = _fetch_full_history(200)
        if log:
            extra.append(
                f"\n### Full repo commit history (last 200):\n"
                f"Format: hash|author|email|date|message\n```\n{log[:5000]}\n```"
            )

    return "\n".join(extra)


# ─── Command execution (stays client-side — runs on their machine) ────────────
def _extract_commands_from_response(response: str) -> List[str]:
    commands = re.findall(r'\[EXECUTE:\s*(gtr[^\]]+)\]', response)
    code_cmds = re.findall(r'```(?:bash)?\s*\n?(gtr[^\n`]+)', response)
    commands.extend(code_cmds)
    return [cmd.strip() for cmd in commands]


def _is_command_safe(command: str) -> tuple:
    cmd_lower = command.lower().strip()
    for blocked in BLOCKED_COMMANDS:
        if cmd_lower.startswith(blocked):
            return False, False, f"'{blocked}' is not enabled for AskG.I.T. execution"
    for safe_cmd, meta in SAFE_COMMANDS.items():
        if cmd_lower == safe_cmd or (meta["args"] and cmd_lower.startswith(safe_cmd)):
            return True, meta["confirm"], meta["category"]
    return False, False, "Command not in AskG.I.T.'s approved execution list"


def _run_gtr_command(command: str) -> str:
    try:
        if "&&" in command:
            parts = [p.strip() for p in command.split("&&")]
            outputs = []
            for part in parts:
                result = subprocess.run(
                    part, shell=True, capture_output=True, text=True,
                    timeout=60, encoding="utf-8", errors="replace"
                )
                output = result.stdout.strip() or result.stderr.strip()
                outputs.append(f"$ {part}\n{output}")
            return "\n\n".join(outputs)
        result = subprocess.run(
            command, shell=True, capture_output=True, text=True,
            timeout=60, encoding="utf-8", errors="replace"
        )
        output = result.stdout.strip()
        error  = result.stderr.strip()
        return output if output else (error if error else "Command completed successfully")
    except subprocess.TimeoutExpired:
        return "Command timed out after 60 seconds"
    except Exception as e:
        return f"Execution error: {e}"


def _detect_intent(user_input: str) -> Optional[str]:
    lower = user_input.lower().strip()
    for triggers, command in INTENT_MAP:
        if any(trigger in lower for trigger in triggers):
            return command
    return None


def _handle_execution(command: str, user_name: str) -> Optional[str]:
    is_safe, needs_confirm, meta = _is_command_safe(command)
    if not is_safe:
        console.print(f"\n[yellow]AskG.I.T. cannot execute:[/yellow] [bold]{command}[/bold]")
        console.print(f"[dim]Reason: {meta}[/dim]\n")
        return None

    console.print(f"\n[bold yellow]AskG.I.T. wants to run:[/bold yellow]")
    console.print(Panel(
        f"[bold cyan]{command}[/bold cyan]",
        border_style="yellow", padding=(0, 2)
    ))

    try:
        console.print("[dim]Execute? ([bold]y[/bold]/n): [/dim]", end="")
        confirm = input().strip().lower()
    except (KeyboardInterrupt, EOFError):
        console.print("\n[dim]Cancelled.[/dim]")
        return None

    if confirm not in ("y", "yes", ""):
        console.print("[dim]Skipped.[/dim]\n")
        return None

    with console.status(f"Running {command}...", spinner="dots"):
        output = _run_gtr_command(command)

    console.print(Panel(
        output,
        title=f"[bold green]{command}[/bold green]",
        border_style="green", padding=(1, 2)
    ))
    console.print()
    return output


# ─── Server call ──────────────────────────────────────────────────────────────
def _call_server(
    messages: List[dict],
    git_context: str,
    os_name: str,
    stream_name: str,
    deep: bool,
    repo_stats: str,
    token: str,
    max_tokens: int = 500,
) -> str:
    headers = {
        "Content-Type": "application/json",
        "x-gitrama-token": token,
    }
    payload = {
        "messages": messages,
        "git_context": git_context,
        "os_name": os_name,
        "stream_name": stream_name,
        "deep": deep,
        "repo_stats": repo_stats,
        "max_tokens": max_tokens,
    }
    try:
        response = requests.post(
            f"{CHAT_SERVER_URL}/chat",
            headers=headers,
            json=payload,
            timeout=REQUEST_TIMEOUT,
        )
        if response.status_code == 401:
            console.print("[red]Authentication failed. Check your GITRAMA_TOKEN.[/red]")
            raise typer.Exit(1)
        if response.status_code != 200:
            console.print(f"[red]Server error ({response.status_code}). Try again.[/red]")
            raise typer.Exit(1)
        return response.json().get("reply", "")
    except requests.exceptions.ConnectionError:
        console.print("[red]Cannot reach api.gitrama.ai. Check your connection.[/red]")
        raise typer.Exit(1)
    except requests.exceptions.Timeout:
        console.print("[red]Request timed out. Try again.[/red]")
        raise typer.Exit(1)


# ─── Context summary panel ────────────────────────────────────────────────────
def _format_context_summary(ctx: dict, deep: bool = False) -> str:
    commit_count   = len([l for l in ctx.get("commits", "").splitlines() if l.strip()])
    staged_count   = len([l for l in ctx.get("staged", "").splitlines() if l.strip() and l != "none"])
    modified_count = len([l for l in ctx.get("modified", "").splitlines() if l.strip() and l != "none"])
    stash_count    = len([l for l in ctx.get("stashes", "").splitlines() if l.strip() and l != "none"])

    lines = [
        f"[cyan]Branch:[/cyan]     {ctx.get('branch', 'unknown')}",
        f"[cyan]Stream:[/cyan]     {ctx.get('stream', 'unknown')}",
        f"[cyan]OS:[/cyan]         {ctx.get('os', 'unknown')}",
    ]
    if deep:
        lines.append(f"[bold green]Mode:[/bold green]       Deep - Full History Access")
        lines.append(f"[cyan]Repo Stats:[/cyan] {ctx.get('repo_stats', 'loading...')}")
    else:
        lines.append(f"[cyan]Mode:[/cyan]       Free - Last {commit_count} commits")
    lines += [
        f"[cyan]Staged:[/cyan]     {staged_count} file(s)",
        f"[cyan]Modified:[/cyan]   {modified_count} file(s)",
        f"[cyan]Stashes:[/cyan]    {stash_count}",
    ]
    if ctx.get("remote"):
        lines.append(f"[cyan]Remote:[/cyan]     {ctx.get('remote')}")
    return "\n".join(lines)


# ─── Main chat command ─────────────────────────────────────────────────────────
def chat(
    stream: Optional[str] = typer.Option(
        None, "--stream", "-s",
        help="Override active stream context (wip | hotfix | review | experiment)"
    ),
    deep: bool = typer.Option(
        False, "--deep", "-d",
        help="Enable full repo history access"
    ),
):
    """Chat with AskG.I.T. - powered by Gitrama. Ask anything about your repo."""

    token = get_value("GITRAMA_TOKEN") or ""

    # Must be inside a git repo
    if not _is_git_repo():
        console.print("\n[bold red]Not a git repository.[/bold red]")
        console.print("[dim]Navigate to a git project folder and run [bold]gtr chat[/bold] again.[/dim]\n")
        raise typer.Exit(1)

    with console.status("Connecting to AskG.I.T....", spinner="dots"):
        config_loaded = _load_server_config(token)

    if not config_loaded:
        console.print("[dim yellow]Running in offline mode — some features limited.[/dim yellow]")

    status_msg = "Loading full repo history..." if deep else "Loading repo context..."
    with console.status(status_msg, spinner="dots"):
        ctx = _get_repo_context()
        if stream:
            ctx["stream"] = stream
        if deep:
            ctx["repo_stats"] = _get_repo_stats()
        git_context = _build_git_context_string(ctx)
        summary     = _format_context_summary(ctx, deep=deep)

    panel_title = "AskG.I.T. - powered by Gitrama  [Deep Mode]" if deep else "AskG.I.T. - powered by Gitrama"
    panel_color = "green" if deep else "cyan"

    console.print()
    console.print(Panel(summary, title=panel_title, border_style=panel_color, padding=(1, 2)))
    console.print(
        "\n[dim]Ask me anything about your repo, commits, branches, or workflow.[/dim]"
        "\n[dim]Type [bold]exit[/bold] or [bold]quit[/bold] to leave. Ctrl+C to exit.[/dim]\n"
    )

    if deep:
        console.print(
            "[bold green]Deep mode active - I have access to your full repo history.[/bold green]\n"
            "[dim]Try: 'show all commits by Alfonso', 'what changed in Q1 2025', "
            "'full history of ai_client.py'[/dim]\n"
        )
    else:
        console.print(
            "[dim yellow]Free tier: last 20 commits loaded. "
            "Run [bold]gtr chat --deep[/bold] for full repo history.[/dim yellow]\n"
        )

    history: List[dict] = []
    user_name = "You"

    while True:
        try:
            console.print(f"[bold cyan]{user_name} >[/bold cyan] ", end="")
            user_input = input().strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n\n[dim]Goodbye! - AskG.I.T.[/dim]")
            raise typer.Exit(0)

        if user_input.lower() in ("exit", "quit", "q", ":q", "bye"):
            console.print("\n[dim]Goodbye! - AskG.I.T.[/dim]")
            raise typer.Exit(0)

        if not user_input:
            continue

        # Intent detection shortcut
        intent_command = _detect_intent(user_input)
        if intent_command:
            output = _handle_execution(intent_command, user_name)
            if output:
                history.append({
                    "role": "user",
                    "content": f"I ran `{intent_command}`. Output:\n{output}\nPlease analyze and tell me what happened."
                })
                with console.status("AskG.I.T. analyzing...", spinner="dots"):
                    response = _call_server(
                        messages=history,
                        git_context=git_context,
                        os_name=ctx["os"],
                        stream_name=ctx["stream"],
                        deep=deep,
                        repo_stats=ctx.get("repo_stats", ""),
                        token=token,
                        max_tokens=400,
                    )
                history.append({"role": "assistant", "content": response})
                console.print()
                console.print(Panel(
                    response,
                    title="[bold green]AskG.I.T.[/bold green]",
                    border_style="green", padding=(1, 2)
                ))
                console.print()
            continue

        # Enrich with live git data
        with console.status("Fetching repo data...", spinner="dots"):
            extra_context = _deep_enrich_prompt(user_input) if deep else _enrich_prompt_with_context(user_input)

        enriched_input = user_input
        if extra_context:
            enriched_input = f"{user_input}\n\n[Live repo data fetched:]{extra_context}"

        history.append({"role": "user", "content": enriched_input})

        with console.status("AskG.I.T. thinking...", spinner="dots"):
            response = _call_server(
                messages=history,
                git_context=git_context,
                os_name=ctx["os"],
                stream_name=ctx["stream"],
                deep=deep,
                repo_stats=ctx.get("repo_stats", ""),
                token=token,
                max_tokens=800 if deep else 500,
            )

        history.append({"role": "assistant", "content": response})

        # Check for execute commands in response
        commands_to_run = _extract_commands_from_response(response)

        # Display clean response (strip [EXECUTE] tags)
        clean_response = re.sub(r'\[EXECUTE:[^\]]+\]', '', response).strip()
        if clean_response:
            console.print()
            console.print(Panel(
                clean_response,
                title="[bold green]AskG.I.T.[/bold green]",
                border_style="green", padding=(1, 2)
            ))
            console.print()

        # Run any commands the AI requested
        execution_outputs = []
        for command in commands_to_run:
            output = _handle_execution(command, user_name)
            if output:
                execution_outputs.append(f"$ {command}\n{output}")

        # Feed execution results back for analysis
        if execution_outputs:
            combined_output = "\n\n".join(execution_outputs)
            history.append({
                "role": "user",
                "content": f"Commands executed. Results:\n{combined_output}\nAnalyze and summarize what happened."
            })
            with console.status("AskG.I.T. analyzing results...", spinner="dots"):
                followup = _call_server(
                    messages=history,
                    git_context=git_context,
                    os_name=ctx["os"],
                    stream_name=ctx["stream"],
                    deep=deep,
                    repo_stats=ctx.get("repo_stats", ""),
                    token=token,
                    max_tokens=400,
                )
            history.append({"role": "assistant", "content": followup})
            console.print(Panel(
                followup,
                title="[bold green]AskG.I.T.[/bold green]",
                border_style="green", padding=(1, 2)
            ))
            console.print()

        # Keep history manageable
        if len(history) > 40:
            history = history[-40:]
