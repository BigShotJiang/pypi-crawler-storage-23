"""
Gitrama - AI-powered Git workflow automation

Copyright © 2026 Gitrama LLC. All Rights Reserved.

This software is proprietary and confidential.
Unauthorized copying, distribution, or use is strictly prohibited.

Gitrama LLC
South Carolina Limited Liability Company
"""
"""
AI Client for Gitrama
Supports multiple providers: Gitrama hosted, OpenAI, Anthropic, Ollama
"""

import requests
from typing import List, Optional

from .config import get_value

# ─── Provider Constants ────────────────────────────────────────────────────────
PROVIDER_GITRAMA   = "gitrama"    # Your hosted tunnel (default, free)
PROVIDER_OPENAI    = "openai"     # OpenAI API (BYOK)
PROVIDER_ANTHROPIC = "anthropic"  # Anthropic API (BYOK)
PROVIDER_OLLAMA    = "ollama"     # Local Ollama instance (BYOK, free)

GITRAMA_DEFAULT_URL = "https://vast-connector.gitrama.io"

# Default models per provider
DEFAULT_MODELS = {
    PROVIDER_GITRAMA:   None,                    # server decides
    PROVIDER_OPENAI:    "gpt-4o-mini",           # cost-effective default
    PROVIDER_ANTHROPIC: "claude-haiku-4-5-20251001",  # fast + affordable
    PROVIDER_OLLAMA:    "llama3",                # common local model
}


class AIClient:
    def __init__(self, api_url: Optional[str] = None):
        """
        Initialize AI client — auto-detects provider from config.
        Falls back to Gitrama hosted tunnel if nothing is configured.
        """
        self.provider = get_value("provider") or PROVIDER_GITRAMA
        self.api_key  = get_value("api_key")
        self.model    = get_value("model") or DEFAULT_MODELS.get(self.provider)

        # api_url is now always correct in config thanks to set_provider()
        # but we still allow an explicit override for testing
        self.api_url = (api_url or get_value("api_url") or GITRAMA_DEFAULT_URL).rstrip("/")

    # ─── Internal: build headers per provider ─────────────────────────────────

    def _headers(self) -> dict:
        headers = {"Content-Type": "application/json"}
        if self.provider == PROVIDER_OPENAI and self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        elif self.provider == PROVIDER_ANTHROPIC and self.api_key:
            headers["x-api-key"]         = self.api_key
            headers["anthropic-version"] = "2023-06-01"
        return headers

    # ─── Internal: call provider chat endpoint ────────────────────────────────
    def _chat_with_history(
        self,
        system: str,
        history: list,
        max_tokens: int = 500
    ) -> str:
        """
        Multi-turn chat with full conversation history.
        Used by gtr chat for persistent context across messages.

        Args:
            system:     System prompt with repo context
            history:    List of {"role": "user"|"assistant", "content": "..."} dicts
            max_tokens: Max tokens for response

        Returns:
            str: AI response text
        """
        headers = {
            "Content-Type": "application/json",
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
        }

        payload = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": history,
        }

        response = requests.post(
            f"{self.api_url}/messages",
            headers=headers,
            json=payload,
            timeout=30,
        )
        response.raise_for_status()

        data = response.json()
        return data["content"][0]["text"].strip()

    def _chat(self, system: str, user: str, max_tokens: int = 300) -> str:
        """
        Route a chat request to whichever provider is configured.
        Returns the assistant's reply as a plain string.
        """
        if self.provider == PROVIDER_GITRAMA:
            return self._chat_gitrama(system, user, max_tokens)
        elif self.provider == PROVIDER_OPENAI:
            return self._chat_openai(system, user, max_tokens)
        elif self.provider == PROVIDER_ANTHROPIC:
            return self._chat_anthropic(system, user, max_tokens)
        elif self.provider == PROVIDER_OLLAMA:
            return self._chat_ollama(system, user, max_tokens)
        else:
            raise Exception(f"Unknown provider '{self.provider}'. Run 'gtr setup' to configure.")

    def _chat_gitrama(self, system: str, user: str, max_tokens: int) -> str:
        """Call Gitrama hosted server (existing tunnel format)."""
        response = requests.post(
            f"{self.api_url}/api/ai/chat",
            json={"system": system, "user": user, "max_tokens": max_tokens},
            timeout=45
        )
        response.raise_for_status()
        return response.json().get("message", "")

    def _chat_openai(self, system: str, user: str, max_tokens: int) -> str:
        """Call OpenAI chat completions endpoint."""
        response = requests.post(
            f"{self.api_url}/chat/completions",
            headers=self._headers(),
            json={
                "model": self.model or "gpt-4o-mini",
                "max_tokens": max_tokens,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user",   "content": user}
                ]
            },
            timeout=45
        )
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"].strip()

    def _chat_anthropic(self, system: str, user: str, max_tokens: int) -> str:
        """Call Anthropic messages endpoint."""
        response = requests.post(
            f"{self.api_url}/messages",
            headers=self._headers(),
            json={
                "model":      self.model or "claude-haiku-4-5-20251001",
                "max_tokens": max_tokens,
                "system":     system,
                "messages":   [{"role": "user", "content": user}]
            },
            timeout=45
        )
        response.raise_for_status()
        return response.json()["content"][0]["text"].strip()

    def _chat_ollama(self, system: str, user: str, max_tokens: int) -> str:
        """Call local Ollama instance."""
        response = requests.post(
            f"{self.api_url}/api/chat",
            json={
                "model":  self.model or "llama3",
                "stream": False,
                "messages": [
                    {"role": "system", "content": system},
                    {"role": "user",   "content": user}
                ]
            },
            timeout=60
        )
        response.raise_for_status()
        return response.json()["message"]["content"].strip()

    # ─── Public: health check ─────────────────────────────────────────────────

    def health_check(self) -> dict:
        """
        Check connectivity for the configured provider.
        Returns a status dict so the CLI can report clearly.
        """
        try:
            if self.provider == PROVIDER_GITRAMA:
                response = requests.get(f"{self.api_url}/health", timeout=5)
                response.raise_for_status()
                return response.json()

            elif self.provider == PROVIDER_OPENAI:
                response = requests.get(
                    f"{self.api_url}/models",
                    headers=self._headers(),
                    timeout=5
                )
                response.raise_for_status()
                return {"status": "healthy", "provider": "openai", "model": self.model}

            elif self.provider == PROVIDER_ANTHROPIC:
                # Anthropic has no lightweight ping — send a minimal message
                result = self._chat("You are a health check.", "Reply OK.", max_tokens=5)
                return {"status": "healthy", "provider": "anthropic", "model": self.model}

            elif self.provider == PROVIDER_OLLAMA:
                response = requests.get(f"{self.api_url}/api/tags", timeout=5)
                response.raise_for_status()
                return {"status": "healthy", "provider": "ollama", "model": self.model}

        except Exception as e:
            raise Exception(f"Health check failed ({self.provider}): {e}")

    # ─── Public: generate commit message ─────────────────────────────────────

    def generate_commit_message(self, diff: str, files: List[str],
                                stream: Optional[str] = None) -> str:
        """
        Generate a stream-aware commit message from staged diff.

        Args:
            diff:   Git diff output
            files:  List of changed files
            stream: Active Gitrama stream (wip | hotfix | review | experiment)

        Returns:
            str: Conventional commit message
        """
        stream_context = _stream_instruction(stream)

        system = (
            "You are an expert Git assistant that writes conventional commit messages. "
            "Format: <type>(<scope>): <subject>. "
            "Types: feat, fix, docs, style, refactor, test, chore. "
            "Keep subject under 72 characters. Return ONLY the commit message, nothing else."
        )
        user = (
            f"{stream_context}\n\n"
            f"Changed files: {', '.join(files)}\n\n"
            f"Diff:\n{diff[:3000]}"
        )

        try:
            if self.provider == PROVIDER_GITRAMA:
                # Legacy endpoint — keep backward compat
                response = requests.post(
                    f"{self.api_url}/api/ai/generate-commit-message",
                    json={"diff": diff, "files": files},
                    timeout=30
                )
                response.raise_for_status()
                return response.json().get("message", "")
            return self._chat(system, user, max_tokens=100)
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to generate commit message: {e}")

    # ─── Public: generate branch name ────────────────────────────────────────

    def generate_branch_name(self, description: str,
                             stream: Optional[str] = None) -> str:
        """
        Generate a branch name from a plain-English description.

        Args:
            description: What the branch is for
            stream:      Active Gitrama stream

        Returns:
            str: kebab-case branch name with stream-appropriate prefix
        """
        prefix_hint = _stream_prefix(stream)

        system = (
            "You are an expert Git assistant that generates clean branch names. "
            "Rules: lowercase, hyphens only, no spaces, max 50 chars. "
            f"{prefix_hint}"
            "Return ONLY the branch name, nothing else."
        )
        user = f"Generate a branch name for: {description}"

        try:
            if self.provider == PROVIDER_GITRAMA:
                response = requests.post(
                    f"{self.api_url}/api/ai/generate-branch-name",
                    json={"description": description},
                    timeout=15
                )
                response.raise_for_status()
                return response.json().get("branch_name", "")
            return self._chat(system, user, max_tokens=30)
        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to generate branch name: {e}")

    # ─── Public: generate PR description ─────────────────────────────────────

    def generate_pr_description(self, commits: list, total_diff: str,
                                branch_name: str,
                                stream: Optional[str] = None) -> dict:
        """
        Generate a full PR description from branch history.

        Returns:
            dict: {'title': str, 'description': str}
        """
        stream_context = _stream_instruction(stream)
        commit_lines   = "\n".join(f"- {c['message']}" for c in commits[:20])

        system = (
            "You are an expert Git assistant that writes professional pull request descriptions. "
            "Include: title, summary, changelog bullets, and a risk/notes section. "
            "Be concise and developer-focused."
        )
        user = (
            f"{stream_context}\n\n"
            f"Branch: {branch_name}\n"
            f"Commits:\n{commit_lines}\n\n"
            f"Diff summary:\n{total_diff[:2000]}\n\n"
            "Return JSON: {\"title\": \"...\", \"description\": \"...\"}"
        )

        try:
            if self.provider == PROVIDER_GITRAMA:
                response = requests.post(
                    f"{self.api_url}/api/ai/generate-pr-description",
                    json={
                        "commits":    commits,
                        "total_diff": total_diff,
                        "branch_name": branch_name
                    },
                    timeout=45
                )
                response.raise_for_status()
                data = response.json()
                return {"title": data.get("title", ""), "description": data.get("description", "")}

            raw = self._chat(system, user, max_tokens=600)
            return _parse_pr_json(raw)

        except requests.exceptions.RequestException as e:
            raise Exception(f"Failed to generate PR description: {e}")

    # ─── Public: summarize changes ────────────────────────────────────────────

    def summarize_changes(self, diff: str, files: List[str],
                          commits: List[dict] = None,
                          stream: Optional[str] = None) -> dict:
        """
        Summarize changes in a branch or staged diff.

        Returns:
            dict: {files_changed, additions, deletions, summary, commits_count}
        """
        additions    = diff.count("\n+")
        deletions    = diff.count("\n-")
        commits_text = ""
        if commits:
            commits_text = "\nCommits:\n" + "\n".join(
                f"- {c['message']}" for c in commits[:10]
            )

        stream_context = _stream_instruction(stream)
        system = "You are a senior engineer summarizing code changes concisely."
        user = (
            f"{stream_context}\n\n"
            f"Files changed: {len(files)}\n"
            f"Lines added: +{additions}\n"
            f"Lines deleted: -{deletions}\n"
            f"{commits_text}\n\n"
            f"Diff sample:\n{diff[:1500]}\n\n"
            "Provide: one-sentence summary, key changes as bullets, one-sentence impact."
        )

        try:
            summary = self._chat(system, user, max_tokens=200)
            return {
                "files_changed":  len(files),
                "additions":      additions,
                "deletions":      deletions,
                "summary":        summary,
                "commits_count":  len(commits) if commits else 0,
            }
        except Exception as e:
            raise Exception(f"Failed to summarize changes: {e}")


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _stream_instruction(stream: Optional[str]) -> str:
    """Return a prompt instruction based on the active stream."""
    instructions = {
        "hotfix":     "CONTEXT: This is a HOTFIX. Be terse and scoped. Flag anything touching >10 files.",
        "wip":        "CONTEXT: This is work-in-progress. Be helpful and permissive.",
        "review":     "CONTEXT: This is a review/cleanup pass. Be detailed and precise.",
        "experiment": "CONTEXT: This is an experimental spike. Be creative and non-judgmental.",
    }
    return instructions.get(stream or "", "")


def _stream_prefix(stream: Optional[str]) -> str:
    """Return branch prefix hint based on stream."""
    prefixes = {
        "hotfix":     "Prefix with 'hotfix/'. ",
        "experiment": "Prefix with 'exp/'. ",
        "review":     "Prefix with 'review/'. ",
        "wip":        "Prefix with 'feat/' or 'fix/' as appropriate. ",
    }
    return prefixes.get(stream or "", "Use feat/, fix/, docs/, chore/ as appropriate. ")


def _parse_pr_json(raw: str) -> dict:
    """Safely parse JSON from AI PR response, with fallback."""
    import json, re
    try:
        # Strip markdown code fences if present
        clean = re.sub(r"```(?:json)?|```", "", raw).strip()
        data  = json.loads(clean)
        return {
            "title":       data.get("title", ""),
            "description": data.get("description", ""),
        }
    except Exception:
        # Fallback: return raw as description
        return {"title": "PR Description", "description": raw}
