from __future__ import annotations
import numpy as np
import math
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from autoarray.inversion.linear_obj.linear_obj import LinearObj

from autoarray.inversion.regularization.abstract import AbstractRegularization


def kv_xp(v, z, xp=np):
    """
    XP-compatible modified Bessel K_v(v, z).

    NumPy backend:
        -> scipy.special.kv

    JAX backend:
        -> jax.scipy.special.kv if available
        -> else tfp.substrates.jax.math.bessel_kve * exp(-|z|)
    """

    # -------------------------
    # NumPy backend
    # -------------------------
    if xp is np:
        import scipy.special as sc

        return sc.kv(v, z)

    # -------------------------
    # JAX backend
    # -------------------------
    else:
        try:
            import tensorflow_probability.substrates.jax as tfp

            return tfp.math.bessel_kve(v, z) * xp.exp(-xp.abs(z))
        except ImportError:
            raise ImportError(
                "To use the JAX backend with the Matérn kernel, "
                "please install tensorflow-probability via `pip install tensorflow-probability==0.25.0`."
            )


def gamma_xp(x, xp=np):
    """
    XP-compatible Gamma(x).
    """
    if xp is np:
        import scipy.special as sc

        return sc.gamma(x)
    else:
        import jax.scipy.special as jsp

        return jsp.gamma(x)


def matern_kernel(r, l: float = 1.0, v: float = 0.5, xp=np):
    """
    XP-compatible Matérn kernel.
    Works with NumPy or JAX.
    """

    # Avoid r = 0 singularity (JAX-safe)
    r = xp.maximum(xp.abs(r), 1e-8)

    z = xp.sqrt(2.0 * v) * r / l

    part1 = 2.0 ** (1.0 - v) / gamma_xp(v, xp)  # scalar constant
    part2 = z**v
    part3 = kv_xp(v, z, xp)

    return part1 * part2 * part3


def matern_cov_matrix_from(
    scale: float,
    nu: float,
    pixel_points,
    weights=None,
    xp=np,
):
    """
    Construct the regularization covariance matrix (N x N) using a Matérn kernel,
    optionally modulated by per-pixel weights.

    If `weights` is provided (shape [N]), the covariance is:
        C_ij = K(d_ij; scale, nu) * w_i * w_j
    with a small diagonal jitter added for numerical stability.

    Parameters
    ----------
    scale
        Typical correlation length of the Matérn kernel.
    nu
        Smoothness parameter of the Matérn kernel.
    pixel_points
        Array-like of shape [N, 2] with (y, x) coordinates (or any 2D coords; only distances matter).
    weights
        Optional array-like of shape [N]. If None, treated as all ones.
    xp
        Backend (numpy or jax.numpy).

    Returns
    -------
    covariance_matrix
        Array of shape [N, N].
    """

    # --------------------------------
    # Pairwise distances WITHOUT (N,N,2) diff
    # --------------------------------
    pts = xp.asarray(pixel_points)

    # ||x - y||^2 = ||x||^2 + ||y||^2 - 2 x·y
    x2 = xp.sum(pts * pts, axis=1, keepdims=True)  # (N, 1)
    dist_sq = x2 + x2.T - 2.0 * (pts @ pts.T)  # (N, N)
    dist_sq = xp.maximum(dist_sq, 0.0)  # numerical safety

    d_ij = xp.sqrt(dist_sq + 1e-20)  # (N, N)

    # --------------------------------
    # Base Matérn covariance
    # --------------------------------
    covariance_matrix = matern_kernel(d_ij, l=scale, v=nu, xp=xp)  # (N, N)

    # --------------------------------
    # Apply weights: C_ij *= w_i * w_j
    # --------------------------------
    if weights is not None:
        w = xp.asarray(weights)
        covariance_matrix = covariance_matrix * (w[:, None] * w[None, :])

    # --------------------------------
    # Add diagonal jitter (JAX-safe)
    # --------------------------------
    pixels = pts.shape[0]
    covariance_matrix = covariance_matrix + 1e-8 * xp.eye(
        pixels, dtype=covariance_matrix.dtype
    )

    return covariance_matrix


def inv_via_cholesky(C, xp=np):
    # NumPy
    if xp is np:
        import scipy.linalg as la

        cho = la.cho_factor(C, lower=True, check_finite=False)
        I = np.eye(C.shape[0], dtype=C.dtype)
        return la.cho_solve(cho, I, check_finite=False)

    # JAX
    import jax.scipy.linalg as jla

    L = xp.linalg.cholesky(C)
    I = xp.eye(C.shape[0], dtype=C.dtype)
    return jla.cho_solve((L, True), I)


class MaternKernel(AbstractRegularization):
    def __init__(self, coefficient: float = 1.0, scale: float = 1.0, nu: float = 0.5):
        """
        Regularization which uses a Matern smoothing kernel to regularize the solution.

        For this regularization scheme, every pixel is regularized with every other pixel. This contrasts many other
        schemes, where regularization is based on neighboring (e.g. do the pixels share a Delaunay edge?) or computing
        derivates around the center of the pixel (where nearby pixels are regularization locally in similar ways).

        This makes the regularization matrix fully dense and therefore maybe change the run times of the solution.
        It also leads to more overall smoothing which can lead to more stable linear inversions.

        This scheme is not used by Vernardos et al. (2022): https://arxiv.org/abs/2202.09378, but it follows
        a similar approach.

        A full description of regularization and this matrix can be found in the parent `AbstractRegularization` class.

        Parameters
        ----------
        coefficient
            The regularization coefficient which controls the degree of smooth of the inversion reconstruction.
        scale
            The typical scale of the exponential regularization pattern.
        nu
            Controls the derivative of the regularization pattern (`nu=0.5` is a Gaussian).
        """

        self.coefficient = coefficient
        self.scale = scale
        self.nu = nu
        super().__init__()

    def regularization_weights_from(self, linear_obj: LinearObj, xp=np) -> np.ndarray:
        """
        Returns the regularization weights of this regularization scheme.

        The regularization weights define the level of regularization applied to each parameter in the linear object
        (e.g. the ``pixels`` in a ``Mapper``).

        For standard regularization (e.g. ``Constant``) are weights are equal, however for adaptive schemes
        (e.g. ``Adapt``) they vary to adapt to the data being reconstructed.

        Parameters
        ----------
        linear_obj
            The linear object (e.g. a ``Mapper``) which uses these weights when performing regularization.

        Returns
        -------
        The regularization weights.
        """
        return self.coefficient * xp.ones(linear_obj.params)

    def regularization_matrix_from(self, linear_obj: LinearObj, xp=np) -> np.ndarray:
        """
        Returns the regularization matrix with shape [pixels, pixels].

        Parameters
        ----------
        linear_obj
            The linear object (e.g. a ``Mapper``) which uses this matrix to perform regularization.

        Returns
        -------
        The regularization matrix.
        """
        covariance_matrix = matern_cov_matrix_from(
            scale=self.scale,
            pixel_points=linear_obj.source_plane_mesh_grid.array,
            nu=self.nu,
            xp=xp,
        )

        return self.coefficient * inv_via_cholesky(covariance_matrix, xp=xp)
