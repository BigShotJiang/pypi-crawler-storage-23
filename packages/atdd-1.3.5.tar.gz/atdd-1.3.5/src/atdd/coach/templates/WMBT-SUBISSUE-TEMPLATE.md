## wmbt:{wagon}:{wmbt_id}

**Step:** {step_name} | **URN:** `wmbt:{wagon}:{wmbt_id}`
**Statement:** {statement}

### ATDD Cycle

- [ ] RED: failing test written
- [ ] GREEN: implementation passes test
- [ ] REFACTOR: architecture compliance verified

### Acceptance Criteria

{acceptance_criteria}

### Test File

`{test_file_path}`
