"""Unit tests for scratch module."""
