"""Configuration schema and helpers for erk."""
