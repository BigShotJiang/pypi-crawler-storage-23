"""BranchManager - Dual-mode interface for branch operations."""
