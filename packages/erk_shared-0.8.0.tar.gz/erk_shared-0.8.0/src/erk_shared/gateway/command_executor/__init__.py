"""Command execution interface for TUI operations.

Import from submodules:
- abc: CommandExecutor
- real: RealCommandExecutor
- fake: FakeCommandExecutor
"""
