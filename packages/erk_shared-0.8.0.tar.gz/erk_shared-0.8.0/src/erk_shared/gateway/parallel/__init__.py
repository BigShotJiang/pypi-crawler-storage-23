"""Parallel task runner integration.

Import from submodules:
- abc: ParallelTaskRunner
- real: RealParallelTaskRunner
"""
