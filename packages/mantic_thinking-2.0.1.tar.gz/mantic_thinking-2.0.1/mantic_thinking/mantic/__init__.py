"""
Mantic Framework (lightweight package root).
"""

__all__ = ["introspection"]
