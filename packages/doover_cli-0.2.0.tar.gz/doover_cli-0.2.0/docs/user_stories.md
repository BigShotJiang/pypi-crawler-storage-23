## User Stories

As an Application Developer I want to be able to create an application based on a template, so that basic setup can be done for me and I can have something basic working for me from the get go.

As an Application Developer I want to be easily able to run a command to run my application on a docker device that I have access to so that I can test against the hardware I want it to work with.

As an Application Developer I want to be able to easily run a simulator on my computer so that I can test my application even when I don’t have access to hardware

As an Application Developer I want to be able to run a basic command to compile and upload my application version and config information so I don’t have to worry about running commands that I might not know

As an Application Developer I want to be able to setup CI/CD to deploy my application and config swell as run the integration tests that I wrote for my application so that i don't need to worry about how to ship code.

As an Application Developer I want to be able to open channel viewer connected to my simulation dda so I can easily test aspects of my code without having to worry about connecting everything properly
