"""idmtools comps utils.

Copyright 2025, Gates Foundation. All rights reserved.
"""
