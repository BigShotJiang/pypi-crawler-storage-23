API Reference
=============

.. automodule:: mrcz
   :members: readMRC, writeMRC, asyncReadMRC, asyncWriteMRC, setAsyncWorkers, readDM4, test

.. py:attribute:: __version__

    The version of Python MRCZ.     
                  
    