.. python-mrcz documentation master file, created by
   sphinx-quickstart 

Python MRCZ Documentation Reference
===================================

Contents:

.. toctree::
   :maxdepth: 2

   intro
   specification
   faq
   api
   release_notes

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

