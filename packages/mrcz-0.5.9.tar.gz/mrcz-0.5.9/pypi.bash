#!/bin/bash

# SDIST
python setup.py sdist upload -r pypi
