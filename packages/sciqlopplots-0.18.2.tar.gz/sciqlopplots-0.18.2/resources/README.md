# Note about adding new icons:

Take icons from [here](https://material.io/resources/icons/?style=baseline) and add them to the `icons` folder. Then add the icon to the `resources.qrc` file.
