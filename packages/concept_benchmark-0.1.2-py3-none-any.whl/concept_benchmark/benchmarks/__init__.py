"""Benchmark pipelines for concept-based models."""
from concept_benchmark.benchmarks import robot, robot_text, sudoku

__all__ = ["robot", "robot_text", "sudoku"]
