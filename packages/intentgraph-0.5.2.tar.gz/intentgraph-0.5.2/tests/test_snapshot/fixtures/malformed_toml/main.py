"""File with malformed config."""


def main():
    """Entry point."""
    pass
