"""Bundled installer scripts, hooks, and settings templates for Claude Code integration."""
