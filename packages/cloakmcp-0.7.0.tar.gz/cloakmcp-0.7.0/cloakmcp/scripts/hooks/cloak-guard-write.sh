#!/bin/bash
exec cloak hook guard-write
