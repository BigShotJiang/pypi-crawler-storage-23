"""
Tests for SchemaX Python SDK

This package contains unit tests, integration tests, and test utilities.
"""
