"""Cortex — Knowledge graph engine for chatbot-memory-skills."""

__version__ = "1.0.0"
