"""CaaS Dashboard — web UI served from the CaaS server."""

from pathlib import Path

DASHBOARD_DIR = Path(__file__).parent
