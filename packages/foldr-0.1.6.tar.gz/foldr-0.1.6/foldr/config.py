CATEGORIES_TEMPLATE = {
    "Documents": {
        "folder": "Documents",
        "ext": {
            ".pdf", ".doc", ".docx", ".odt", ".rtf",
            ".tex", ".bib", ".md", ".pages"
        },
    },
    "Text & Data": {
        "folder": "Text_Data",
        "ext": {
            ".txt", ".md", ".csv", ".tsv", ".json",
            ".ndjson", ".xml", ".yaml", ".yml", ".toml",
            ".log", ".ini", ".cfg", ".conf", ".env", ".properties"
        },
    },
    "Images": {
        "folder": "Images",
        "ext": {
            ".png", ".jpg", ".jpeg", ".gif",
            ".bmp", ".tiff", ".tif", ".ico", ".webp",
            ".heic", ".heif", ".raw", ".cr2", ".orf", ".nef"
        },
    },
    "Vector Graphics": {
        "folder": "Vector_Graphics",
        "ext": {
            ".svg", ".eps", ".ai", ".ps", ".pdf"  # pdf sometimes used for vector art
        },
    },
    "Videos": {
        "folder": "Videos",
        "ext": {
            ".mp4", ".mkv", ".mov", ".avi", ".wmv",
            ".flv", ".webm", ".m4v", ".mpeg", ".mpg"
        },
    },
    "Audio": {
        "folder": "Audio",
        "ext": {
            ".mp3", ".wav", ".aac", ".flac", ".ogg",
            ".m4a", ".wma", ".opus"
        },
    },
    "Subtitles": {
        "folder": "Subtitles",
        "ext": {
            ".srt", ".vtt", ".ass", ".ssa", ".sub"
        },
    },
    "Archives": {
        "folder": "Archives",
        "ext": {
            ".zip", ".rar", ".7z", ".tar", ".gz",
            ".bz2", ".xz", ".zst", ".tar.gz", ".tar.bz2",
            ".tar.xz", ".tgz", ".tbz2"
        },
    },
    "Disk Images": {
        "folder": "Disk_Images",
        "ext": {
            ".iso", ".img", ".dmg", ".vhd", ".vhdx", ".vmdk", ".bin", ".cue"
        },
    },
    "Virtualization": {
        "folder": "Virtualization",
        "ext": {
            ".ova", ".ovf"
        },
    },
    "Executables": {
        "folder": "Executables",
        "ext": {
            ".exe", ".msi", ".msix", ".app", ".deb", ".rpm",
            ".apk", ".bin", ".run", ".jar", ".class"
        },
    },
    "Packages": {
        "folder": "Packages",
        "ext": {
            ".deb", ".rpm", ".apk", ".pkg", ".msi", ".msix",
            ".whl", ".egg", ".gem", ".npm", ".tgz"
        },
    },
    "Code": {
        "folder": "Code",
        "ext": {
            ".py", ".pyc", ".ipynb", ".java", ".class", ".jar",
            ".cpp", ".cc", ".c", ".h", ".hpp", ".cs",
            ".js", ".mjs", ".cjs", ".ts", ".tsx", ".jsx",
            ".html", ".htm", ".css", ".scss", ".less",
            ".go", ".rs", ".php", ".pl", ".pm", ".rb", ".swift",
            ".kt", ".kts", ".lua", ".r", ".sql", ".erl", ".ex", ".exs"
        },
    },
    "Notebooks": {
        "folder": "Notebooks",
        "ext": {
            ".ipynb", ".rmd", ".nb", ".sage"
        },
    },
    "Scripts": {
        "folder": "Scripts",
        "ext": {
            ".sh", ".bash", ".zsh", ".ksh", ".csh",
            ".ps1", ".psm1", ".fish", ".awk", ".sed",
            ".pl", ".rb", ".groovy", ".ps1xml"
        },
    },
    "Machine_Learning": {
        "folder": "Machine_Learning",
        "ext": {
            ".h5", ".hdf5", ".pt", ".pth", ".onnx", ".pb",
            ".pkl", ".joblib", ".npz", ".mat", ".sav"
        },
    },
    "Databases": {
        "folder": "Databases",
        "ext": {
            ".sql", ".db", ".sqlite", ".sqlite3", ".mdb", ".accdb",
            ".bak", ".dump"
        },
    },
    "Spreadsheets": {
        "folder": "Spreadsheets",
        "ext": {
            ".xls", ".xlsx", ".xlsm", ".xlsb", ".ods", ".csv", ".tsv"
        },
    },
    "Presentations": {
        "folder": "Presentations",
        "ext": {
            ".ppt", ".pptx", ".key", ".odp"
        },
    },
    "Fonts": {
        "folder": "Fonts",
        "ext": {
            ".ttf", ".otf", ".woff", ".woff2", ".eot", ".pfb", ".pfa"
        },
    },
    "3D_Models": {
        "folder": "3D_Models",
        "ext": {
            ".stl", ".obj", ".fbx", ".3ds", ".ply", ".blend", ".gltf", ".glb"
        },
    },
    "CAD": {
        "folder": "CAD",
        "ext": {
            ".dwg", ".dxf", ".step", ".stp", ".iges", ".igs"
        },
    },
    "GIS": {
        "folder": "GIS",
        "ext": {
            ".shp", ".shx", ".dbf", ".geojson", ".kml", ".kmz", ".gpx"
        },
    },
    "Ebooks": {
        "folder": "Ebooks",
        "ext": {
            ".epub", ".mobi", ".azw3", ".azw", ".fb2"
        },
    },
    "Web": {
        "folder": "Web",
        "ext": {
            ".html", ".htm", ".xhtml", ".css", ".js", ".json",
            ".map", ".wasm"
        },
    },
    "Config_and_System": {
        "folder": "Config_System",
        "ext": {
            ".conf", ".cfg", ".ini", ".plist", ".reg", ".sys",
            ".service", ".socket"
        },
    },
    "Certificates": {
        "folder": "Certificates",
        "ext": {
            ".crt", ".cer", ".pem", ".key", ".pfx", ".p12", ".der"
        },
    },
    "Logs": {
        "folder": "Logs",
        "ext": {
            ".log", ".trace", ".out", ".err"
        },
    },
    "Licenses": {
        "folder": "Licenses",
        "ext": {
            "LICENSE", "LICENSE.txt", "LICENCE", "COPYING"
        },
    },
    "Subprojects": {
        "folder": "Subprojects",
        "ext": {
            "README", "README.md", "CHANGELOG", "CHANGELOG.md"
        },
    },
    "Misc": {
        "folder": "Misc",
        "ext": {
            ".isoinfo", ".part", ".crdownload", ".tmp", ".bak"
        },
    }
}