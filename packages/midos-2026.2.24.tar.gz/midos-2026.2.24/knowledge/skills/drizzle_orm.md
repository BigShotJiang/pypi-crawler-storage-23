---
name: "drizzle-orm-typescript-native"
version: "1.0.0"
stack: "drizzle"
drizzle_version: "0.31.0+"
tags: ["drizzle", "orm", "typescript", "sql", "edge-runtime", "performance", "prisma-alternative", "validated", "2026"]
confidence: 0.95
created: "2026-02-10"
sources:
  - url: "https://orm.drizzle.team/docs/overview"
    type: "official"
    confidence: 1.0

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
