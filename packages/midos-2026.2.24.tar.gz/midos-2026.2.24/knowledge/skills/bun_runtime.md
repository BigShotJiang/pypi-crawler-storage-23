---
name: bun-runtime
version: "1.0.0"
stack: bun
tags: [bun, runtime, bundler, test-runner, sqlite, http-server, package-manager, nodejs-compat]
confidence: 0.93
last_updated: "2026-02-18"
languages: [javascript, typescript]
frameworks: [elysia, hono]
globs: ["**/bunfig.toml", "**/bun.lockb"]
description: "Bun runtime patterns -- bundler, test runner, SQLite, HTTP server, Node.js migration"
---


> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
