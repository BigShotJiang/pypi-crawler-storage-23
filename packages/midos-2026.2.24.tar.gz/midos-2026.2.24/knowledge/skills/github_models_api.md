---
name: github_models_api
version: 1.0.0
description: GitHub Models API reference - free access to GLM, Llama, Phi, and more
model: any
created: 2026-02-18
tags: [github-models, free-tier, api, llm, deployment]
source: https://github.com/marketplace/models
---

# GitHub Models API Reference

> Free access to production LLMs via GitHub.

## Overview


> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
