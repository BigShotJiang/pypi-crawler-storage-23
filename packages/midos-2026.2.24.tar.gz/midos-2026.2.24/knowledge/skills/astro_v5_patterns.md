# Astro v5 — Content-First Islands Framework

> **Stack**: Astro
> **Version**: 5.x (stable), 6.x (latest)
> **Released**: 2024-12-03 (v5.0), 2025-07 (v6.0)
> **Status**: stable
> **Promoted**: 2026-02-20
> **Sources**: docs.astro.build, astro.build/blog/astro-5, Context7, Strapi guide

---

## WHY (Motivation)

**What changed from v4?**

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
