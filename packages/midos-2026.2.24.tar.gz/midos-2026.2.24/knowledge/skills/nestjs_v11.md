---
name: "nestjs-v11-enterprise-framework"
version: "2.0.0"
stack: "nestjs"
nestjs_version: "11.x"
node_version: "16+, 18+ recommended"
tags: ["nestjs", "typescript", "enterprise", "microservices", "dependency-injection", "fastify", "graphql", "validated", "2026"]
confidence: 0.95
created: "2026-02-10"
updated: "2026-02-11"
sources:
  - url: "https://nestjs.com"
    type: "official"

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
