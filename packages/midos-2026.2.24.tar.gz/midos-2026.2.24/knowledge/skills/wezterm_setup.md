---
name: "wezterm-setup"
version: "1.0.0"
stack: "developer-tools"
tags: ["wezterm", "terminal", "gpu-terminal", "lua", "productivity", "nerd-font", "validated", "2026"]
confidence: 0.95
created: "2026-02-20"
sources:
  - url: "https://wezfurlong.org/wezterm/config/files.html"
    type: "official"
    confidence: 1.0
  - url: "https://wezfurlong.org/wezterm/config/lua/general.html"

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
