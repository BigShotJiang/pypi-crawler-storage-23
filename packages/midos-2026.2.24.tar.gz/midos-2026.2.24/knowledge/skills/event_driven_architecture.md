---
name: Event-Driven Architecture Patterns
version: "1.0"
date: 2026-02-13
tags: [event-driven, kafka, rabbitmq, messaging, async, cqrs, event-sourcing, nats, pulsar]
source: WebSearch + Production Patterns Research
confidence: 0.92
---

# Skill: Event-Driven Architecture Patterns

## Quick Reference

### Decision Matrix

| Requirement | Best Choice | Alternative | Avoid If |

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
