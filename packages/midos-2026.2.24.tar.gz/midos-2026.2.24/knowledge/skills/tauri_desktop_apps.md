# Tauri v2 — Cross-Platform Desktop Apps

> **Stack**: Tauri
> **Version**: 2.x (stable since Oct 2024)
> **Released**: 2024-10-02
> **Status**: stable
> **Promoted**: 2026-02-20
> **Sources**: 4 validation sources (see SOURCES)

---

## WHY (Motivation)

**What changed from v1 to v2?**
- Mobile support (iOS + Android) alongside desktop (Windows, macOS, Linux)

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
