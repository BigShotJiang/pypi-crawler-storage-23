---
name: "powershell7-terminal-setup"
version: "1.0.0"
stack: "developer-tools"
tags: ["powershell", "windows-terminal", "oh-my-posh", "productivity", "terminal", "nerd-font", "validated", "2026"]
confidence: 0.95
created: "2026-02-14"
sources:
  - url: "https://ohmyposh.dev/docs"
    type: "official"
    confidence: 1.0
  - url: "https://learn.microsoft.com/en-us/powershell/"

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
