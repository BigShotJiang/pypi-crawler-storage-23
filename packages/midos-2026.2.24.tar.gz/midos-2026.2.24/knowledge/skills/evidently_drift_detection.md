---
name: "evidently-drift-detection"
version: "1.0.0"
stack: "ml"
tags: ["evidently", "drift-detection", "monitoring", "mlops", "validated", "2026"]
confidence: 0.94
created: "2026-02-11"
sources:
  - url: "https://github.com/evidentlyai/evidently"
    type: "official"
    confidence: 1.0
  - url: "https://docs.evidentlyai.com/metrics/explainer_drift"
    type: "official"
    confidence: 1.0

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
