---
name: visual-molds-v3
description: High-density industrial mold counting and inventory tracking using YOLOv8/v11.
trigger: vision:molds | count:molds
scope: industrial | manufacturing
source: MIDOS_CENTRAL
---

# 👁️ SKILL: VISUAL MOLDS V3

This skill enables the agent to process industrial imagery from the Terrazos Factory and extract inventory facts.

## 🏗️ Architecture

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
