---
skill_id: spec-driven-development
title: "Spec-Driven Development Workflow"
category: methodology
stack: [any]
verified: true
confidence: 0.90
created: "2026-02-12"
sources:
  - url: "https://github.com/github/spec-kit"
    type: "official"
    confidence: 1.0
  - url: "https://martinfowler.com/articles/exploring-gen-ai/sdd-3-tools.html"
    type: "authoritative"
    confidence: 0.95

> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
