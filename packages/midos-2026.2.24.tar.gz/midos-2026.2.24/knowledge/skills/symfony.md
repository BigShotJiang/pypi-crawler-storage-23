---
tags: symfony, php, backend, enterprise, framework
version: 8.1 (stable), 7.4 LTS
truth_validated: true
sources:
  - https://symfony.com/releases
  - https://symfony.com/doc/current/best_practices.html
  - https://endoflife.date/symfony
  - https://proxify.io/articles/symfony-vs-laravel
  - https://symfony.com/stats/downloads
---

# Symfony — Skill Reference

## Version Landscape


> **Note**: Full content available to MidOS PRO subscribers. See https://midos.dev/pricing
