---
tier: public
title: Content Collections v2 Advanced Patterns — Astro 4
source: staging/astro4_content_collections_advanced.md
date: 2026-02-10

[...content truncated — free tier preview]
