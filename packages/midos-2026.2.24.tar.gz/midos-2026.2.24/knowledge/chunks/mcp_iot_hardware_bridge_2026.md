---
tier: public
title: "MCP + IoT/Hardware Bridge — Arduino, ESP32, Serial, MQTT"
source: "Web research (10+ sources) + MidOS knowledge base"
category: "architecture/iot"
date: "2026-02-15"

[...content truncated — free tier preview]
