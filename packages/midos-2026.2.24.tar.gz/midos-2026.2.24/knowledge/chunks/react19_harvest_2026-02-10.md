---
tier: public
title: React 19 — Comprehensive Breaking Changes & Migration Guide
source: staging/react19_harvest.md
date: 2026-02-10
tags: [react, version-19, breaking-changes, migration, hooks, server-components, frontend, validated]

[...content truncated — free tier preview]
