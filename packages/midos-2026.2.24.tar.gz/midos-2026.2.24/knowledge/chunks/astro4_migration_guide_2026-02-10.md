---
tier: public
title: Astro 4 Migration Guide — Real World Scenarios
source: staging/astro4_migration_guide.md
date: 2026-02-10
tags: [astro, astro4, migration, content-collections, view-transitions, image-optimization, zod, typescript]

[...content truncated — free tier preview]
