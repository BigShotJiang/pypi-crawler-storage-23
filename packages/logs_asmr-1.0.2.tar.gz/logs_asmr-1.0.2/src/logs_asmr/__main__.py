"""Allow running with: python -m logs_asmr"""

from logs_asmr.app import main

main()
