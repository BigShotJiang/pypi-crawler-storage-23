Version 0.6 Updates
/////////////////////////

Version 0.6.0
===============

New features
++++++++++++++++

- added experimental support to use :ref:`grib fieldlists <grib>` in earthkit-regrid's `interpolate() <https://earthkit-regrid.readthedocs.io/en/latest/interpolate.html>`_ method (requires :xref:`earthkit-regrid` >= 0.3.0).
