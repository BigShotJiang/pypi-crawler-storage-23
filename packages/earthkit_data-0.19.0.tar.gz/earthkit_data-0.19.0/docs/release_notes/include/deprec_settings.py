from earthkit.data import settings

v = settings.get("number-of-download-threads")

settings.auto_save_settings = False
