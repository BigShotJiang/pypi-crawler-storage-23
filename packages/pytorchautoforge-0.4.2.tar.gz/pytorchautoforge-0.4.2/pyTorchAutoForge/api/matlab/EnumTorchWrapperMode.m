classdef EnumTorchWrapperMode
    enumeration
        TCP
        PYENV
    end
end
