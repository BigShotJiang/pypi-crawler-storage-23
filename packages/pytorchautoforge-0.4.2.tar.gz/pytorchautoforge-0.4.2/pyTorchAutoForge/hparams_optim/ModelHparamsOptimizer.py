import optuna

class ModelHparamsOptimizer():
    def __init__(self) -> None:
        raise NotImplementedError("ModelHparamsOptimizer class not implemented yet!")
        pass
