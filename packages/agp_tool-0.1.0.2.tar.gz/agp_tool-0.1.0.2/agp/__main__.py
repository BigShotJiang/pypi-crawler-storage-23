from agp.main import main

main()
