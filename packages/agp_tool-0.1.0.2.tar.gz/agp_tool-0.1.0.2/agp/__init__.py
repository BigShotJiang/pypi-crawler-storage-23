__version__ = "1.0.0"

from .api import generate_report  # noqa: F401

__all__ = ["generate_report", "__version__"]
