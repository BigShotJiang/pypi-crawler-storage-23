"""Module cli.py providing core functionalities."""

import os
import sys

import typer

from .constraints.foreign_key import ForeignKeyConstraint
from .constraints.format import FormatConstraint
from .constraints.unique import UniqueConstraint
from .core.data_source import DataSource
from .core.engine import DataEngine
from .core.registry import registry
from .loaders.csv_loader import CsvLoader
from .loaders.json_loader import JsonLoader
from .reporters.console_reporter import ConsoleReporter
from .reporters.json_reporter import JsonReporter
from .reporters.markdown_reporter import MarkdownReporter
from .utils.config_loader import load_config
from .utils.logger import logger

registry.register("format", FormatConstraint)
registry.register("unique", UniqueConstraint)
registry.register("foreign-key", ForeignKeyConstraint)

app = typer.Typer(
    name="data-constraints",
    help="Validate data against configurable constraints",
    add_completion=False,
    no_args_is_help=True,
)


@app.callback()
def callback():
    """
    Validate data against configurable constraints
    """
    pass


@app.command("validate")
def validate(
    config: str = typer.Option(
        ..., "-c", "--config", help="Path to configuration file"
    ),
    data: str = typer.Option(
        None, "-d", "--data", help="Directory containing data files"
    ),
    format_opt: str = typer.Option(
        "console", "-f", "--format", help="Output format (console, json, markdown)"
    ),
    output: str = typer.Option(None, "-o", "--output", help="Output file path"),
    debug: bool = typer.Option(False, "--debug", help="Enable debug logging"),
    silent: bool = typer.Option(False, "--silent", help="Disable all logging"),
):
    """Run validation"""
    try:
        if silent:
            logger.setLevel("CRITICAL")
        elif debug:
            logger.setLevel("DEBUG")
        else:
            logger.setLevel("INFO")

        config_data = load_config(config)
        engine = DataEngine(config_data)
        config_dir = os.path.dirname(os.path.abspath(config))

        sources = config_data.get("sources", [])
        if isinstance(sources, dict):
            sources_list = []
            for k, v in sources.items():
                v["service"] = k
                sources_list.append(v)
            sources = sources_list

        for source in sources:
            source_path = os.path.abspath(
                os.path.join(config_dir, source.get("path", ""))
            )
            loader = None
            loader_options = {}

            if source.get("type") in ("json", "file") and source.get("format") != "csv":
                if "csv" in source.get("format", "") or source_path.endswith(".csv"):
                    loader = CsvLoader
                    loader_options = source.get("options", {})
                else:
                    loader = JsonLoader
                    loader_options = {
                        "array_path": source.get("arrayPath")
                        or config_data.get("arrayPath")
                    }
            elif source.get("type") == "csv" or source.get("format") == "csv":
                loader = CsvLoader
                loader_options = source.get("options", {})

            if loader:
                engine.add_source(
                    source.get("service"),
                    DataSource.file(source_path),
                    loader,
                    loader_options,
                )

        if data:
            data_dir = os.path.abspath(data)
            if os.path.exists(data_dir) and os.path.isdir(data_dir):
                for file_name in os.listdir(data_dir):
                    full_path = os.path.join(data_dir, file_name)
                    if os.path.isfile(full_path):
                        name, ext = os.path.splitext(file_name)
                        ext = ext.lower()
                        if ext == ".json":
                            engine.add_source(
                                name,
                                DataSource.file(full_path),
                                JsonLoader,
                                {"array_path": config_data.get("arrayPath")},
                            )
                        elif ext == ".csv":
                            engine.add_source(
                                name, DataSource.file(full_path), CsvLoader, {}
                            )

        constraints = config_data.get("constraints", [])

        if isinstance(constraints, str):
            constraints_path = os.path.abspath(os.path.join(config_dir, constraints))
            loaded = load_config(constraints_path)
            constraints = loaded.get("constraints", loaded)

        if isinstance(constraints, list):
            for c in constraints:
                engine.add_constraint(registry.create(c))
        elif isinstance(constraints, dict):
            for type_name, c_list in constraints.items():
                if isinstance(c_list, list):
                    for c in c_list:
                        if "type" not in c:
                            c["type"] = type_name
                        engine.add_constraint(registry.create(c))

        reporter = None
        if format_opt == "json":
            reporter = JsonReporter(output)
        elif format_opt == "markdown":
            reporter = MarkdownReporter(output)
        else:
            reporter = ConsoleReporter()

        engine.run(reporter)

    except Exception as err:
        logger.error(f"Error: {err}")
        sys.exit(1)


if __name__ == "__main__":
    app()
