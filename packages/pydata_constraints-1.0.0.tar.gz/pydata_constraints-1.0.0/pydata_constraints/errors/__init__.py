"""Module __init__.py providing core functionalities."""

from .validation_error import ValidationError

__all__ = ["ValidationError"]
