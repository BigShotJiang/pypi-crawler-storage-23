"""Module validation_error.py providing core functionalities."""


class ValidationError(Exception):
    """
    Custom error thrown when an ExceptionReporter is used and validation fails.
    """

    def __init__(self, message, results=None):
        """Initialize the instance."""
        super().__init__(message)
        self.results = results or []
