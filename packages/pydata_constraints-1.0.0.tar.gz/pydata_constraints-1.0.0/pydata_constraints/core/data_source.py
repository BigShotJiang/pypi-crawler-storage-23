"""Module data_source.py providing core functionalities."""


class DataSource:
    """
    Class representing a source of data.
    Can be a file path (for streaming) or an in-memory object/array.
    """

    def __init__(self, source_type, source):
        """Initialize the instance."""
        self.type = source_type
        self.source = source

    @classmethod
    def file(cls, file_path):
        """Execute file operation."""
        return cls("file", file_path)

    @classmethod
    def memory(cls, data):
        """Execute memory operation."""
        return cls("memory", data)

    def get_stream_or_data(self, mode="r", newline=None):
        """Get the stream_or_data attribute."""
        if self.type == "file":
            encoding = "utf-8" if "b" not in mode else None
            return open(self.source, mode, encoding=encoding, newline=newline)
        return self.source
