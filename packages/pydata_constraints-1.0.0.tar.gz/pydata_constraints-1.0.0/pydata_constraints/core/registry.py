"""Module registry.py providing core functionalities."""

import re


class ConstraintRegistry:
    """
    Registry mapping constraint type names to their implementation classes.
    """

    def __init__(self):
        """Initialize the instance."""
        self.types = {}

    def register(self, type_name, constraint_class):
        """
        Register a new constraint class under a specific type name.
        """
        self.types[type_name] = constraint_class

    def create(self, config):
        """
        Instantiate a constraint directly from a configuration dictionary.
        Requires the dictionary to have a 'type' key matching a registered constraint.
        """
        normalized_type = re.sub(
            r"([A-Z])", lambda m: "-" + m.group(1).lower(), config.get("type", "")
        )

        type_class = self.types.get(normalized_type) or self.types.get(
            config.get("type")
        )

        if not type_class:
            raise ValueError(f"Unknown constraint type: {config.get('type')}")

        return type_class.from_json(config)


registry = ConstraintRegistry()
