"""Module engine.py providing core functionalities."""

from ..utils.logger import logger


class DataEngine:
    """
    The core engine responsible for managing data sources, constraints,
    and orchestrating the validation process.
    """

    def __init__(self, config=None):
        """
        Initialize the DataEngine with an optional configuration.
        """
        self.config = config or {}
        self.constraints = []
        self.sources = {}

    def add_source(self, name, data_source, loader_class, loader_options=None):
        """
        Register a new data source to be validated.
        """
        self.sources[name] = {
            "data_source": data_source,
            "loader_class": loader_class,
            "loader_options": loader_options or {},
        }

    def add_constraint(self, constraint):
        """
        Add a constraint rule to the engine.
        """
        self.constraints.append(constraint)

    def run(self, reporter=None):
        """
        Execute the validation process across all configured sources and constraints.
        If no reporter is provided, an ExceptionReporter is used by default.
        """
        if reporter is None:
            from ..reporters.exception_reporter import ExceptionReporter

            reporter = ExceptionReporter()

        logger.info("Building indexes...")
        for constraint in self.constraints:
            if getattr(constraint, "type", None) == "foreign-key" and not getattr(
                constraint, "is_index_built", False
            ):
                ref_source_config = self.sources.get(constraint.reference_service)
                if not ref_source_config:
                    raise ValueError(
                        f'Reference source "{constraint.reference_service}" not found for FK constraint "{constraint.id}"'
                    )

                loader_class = ref_source_config["loader_class"]
                loader = loader_class(
                    ref_source_config["data_source"],
                    **ref_source_config["loader_options"],
                )
                constraint.build_index(loader.load())

        logger.info("Validating data...")
        constraints_by_source = {}
        for constraint in self.constraints:
            service = constraint.service
            if service not in constraints_by_source:
                constraints_by_source[service] = []
            constraints_by_source[service].append(constraint)

        for source_name, source_constraints in constraints_by_source.items():
            source_config = self.sources.get(source_name)
            if not source_config:
                logger.warning(
                    f'Source "{source_name}" not found for constraints. Skipping.'
                )
                continue

            loader_class = source_config["loader_class"]
            loader = loader_class(
                source_config["data_source"], **source_config["loader_options"]
            )

            logger.info(f"Processing source: {source_name}")
            index = 0
            for record in loader.load():
                context = loader.create_context(record, index)
                index += 1

                for constraint in source_constraints:
                    try:
                        result = constraint.validate(context)
                        if result:
                            reporter.report(result)
                    except Exception as err:
                        reporter.error(err, context)

        reporter.finish()
