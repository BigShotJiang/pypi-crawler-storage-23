"""Module base.py providing core functionalities."""

import sys


class BaseReporter:
    """
    Base abstract reporter.
    """

    def __init__(self):
        """Initialize the instance."""
        self.issues = []

    def report(self, issue):
        """
        Records an issue.
        """
        self.issues.append(issue)

    def error(self, error, _context=None):
        """
        Records an error (system error, not validation error).
        """
        print(error, file=sys.stderr)

    def finish(self):
        """
        Finalizes the report (e.g. writes to file).
        """
        pass
