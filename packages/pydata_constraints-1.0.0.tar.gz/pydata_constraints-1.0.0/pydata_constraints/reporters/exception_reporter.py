"""Module exception_reporter.py providing core functionalities."""

from ..errors.validation_error import ValidationError
from .base import BaseReporter


class ExceptionReporter(BaseReporter):
    """
    Reporter that collects violations and throws a ValidationError at the end if any exist.
    """

    def __init__(self):
        """Initialize the instance."""
        super().__init__()
        self.violations = []

    def report(self, result):
        """Report a validation issue to the output format."""
        self.violations.append(result)
        super().report(result)

    def finish(self):
        """Finish the reporting process and finalize output."""
        super().finish()
        if self.violations:
            raise ValidationError(
                f"Data validation failed with {len(self.violations)} issues.",
                self.violations,
            )
