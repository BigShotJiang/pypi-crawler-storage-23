"""Module markdown_reporter.py providing core functionalities."""

import json
from collections import defaultdict

from ..utils.logger import logger
from .base import BaseReporter


class MarkdownReporter(BaseReporter):
    """
    Reporter that outputs validation issues in Markdown format.
    """

    def __init__(self, output_path=None):
        """Initialize the instance."""
        super().__init__()
        self.output_path = output_path

    def finish(self):
        """Finish the reporting process and finalize output."""
        md = "# Data Validation Report\n\n"

        if not self.issues:
            md += ":white_check_mark: No issues found.\n"
        else:
            md += f"Found {len(self.issues)} issues.\n\n"

            grouped = defaultdict(list)
            for issue in self.issues:
                grouped[issue.get("id", "unknown")].append(issue)

            for issue_id, issues in grouped.items():
                md += f"## Constraint: `{issue_id}`\n\n"
                for issue in issues:
                    md += f"- **{issue.get('type', 'unknown')}**: {issue.get('message', '')}\n"
                    if "record" in issue:
                        md += f"  - Record: `{json.dumps(issue['record'])}`\n"
                md += "\n"

        if self.output_path:
            with open(self.output_path, "w", encoding="utf-8") as f:
                f.write(md)
            logger.info(f"Markdown report written to {self.output_path}")
        else:
            print(md)
