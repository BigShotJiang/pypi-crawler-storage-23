"""Module console_reporter.py providing core functionalities."""

from ..utils.logger import logger
from .base import BaseReporter


class ConsoleReporter(BaseReporter):
    """
    Reporter that logs output to the console.
    """

    def report(self, issue):
        """Report a validation issue to the output format."""
        super().report(issue)
        r = "\033[91m"
        y = "\033[93m"
        x = "\033[0m"
        print(
            f"{r}[{issue.get('id', 'unknown')}]{x} {y}({issue.get('type', 'unknown')}){x} {issue.get('message', '')}"
        )

    def finish(self):
        """Finish the reporting process and finalize output."""
        logger.info(f"\nValidation finished. Found {len(self.issues)} issues.")
