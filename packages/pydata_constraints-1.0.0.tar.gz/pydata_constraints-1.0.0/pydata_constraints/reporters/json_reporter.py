"""Module json_reporter.py providing core functionalities."""

import datetime
import json

from ..utils.logger import logger
from .base import BaseReporter


class JsonReporter(BaseReporter):
    """
    Reporter that outputs validation issues in JSON format.
    """

    def __init__(self, output_path=None):
        """Initialize the instance."""
        super().__init__()
        self.output_path = output_path

    def finish(self):
        """Finish the reporting process and finalize output."""
        output = {
            "timestamp": datetime.datetime.now(datetime.timezone.utc)
            .isoformat()
            .replace("+00:00", "Z"),
            "issues": self.issues,
        }

        if self.output_path:
            with open(self.output_path, "w", encoding="utf-8") as f:
                json.dump(output, f, indent=2)
            logger.info(f"Report written to {self.output_path}")
        else:
            print(json.dumps(output, indent=2))
