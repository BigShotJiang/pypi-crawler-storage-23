"""Module logger.py providing core functionalities."""

import logging
import os

LOG_LEVEL = os.environ.get("LOG_LEVEL", "INFO").upper()

logging.basicConfig(
    level=getattr(logging, LOG_LEVEL, logging.INFO),
    format="%(levelname)s - %(message)s",
)
logger = logging.getLogger("data-constraints")
