"""Module property_accessor.py providing core functionalities."""

import re


def get_values(obj, path):
    """
    Retrieves values from an object using a path.
    Supports traversing lists: if a property in the path is a list,
    the rest of the path is applied to each element, and results are flattened.
    """
    if not obj:
        return None
    if not path:
        return obj

    parts = [p.strip() for p in path.split(".") if p.strip()]
    if not parts:
        return obj

    current = [obj]

    for i, key in enumerate(parts):
        next_items = []
        is_next_index = False
        if i + 1 < len(parts):
            next_part = parts[i + 1]
            if re.match(r"^\d+$", next_part):
                is_next_index = True

        for item in current:
            if item is None:
                continue

            if isinstance(item, dict):
                val = item.get(key)
            elif isinstance(item, list) and re.match(r"^\d+$", key):
                idx = int(key)
                if 0 <= idx < len(item):
                    val = item[idx]
                else:
                    val = None
            else:
                continue

            if val is None:
                continue

            if isinstance(val, list):
                if not is_next_index:
                    next_items.extend(val)
                else:
                    next_items.append(val)
            else:
                next_items.append(val)

        current = next_items
        if not current:
            return None

    if not current:
        return None
    if len(current) == 1:
        return current[0]
    return current
