"""Module scenario_generator.py providing core functionalities."""

import re


def generate_scenarios(root_object, paths):
    """
    Generates all possible data scenarios by unfolding arrays at specified keys.
    """

    def recursive_unfold(current_obj, path):
        """Execute recursive unfold operation."""
        segments = path.split(".")
        head = segments[0]
        tail = segments[1:]

        if (
            current_obj is None
            or not isinstance(current_obj, dict)
            or head not in current_obj
        ):
            return [current_obj]

        value = current_obj[head]

        if not tail:
            if isinstance(value, list):
                return [{**current_obj, head: [item]} for item in value]
            return [current_obj]
        else:
            tail_path = ".".join(tail)
            if isinstance(value, list):
                unfolded_array = []
                for item in value:
                    unfolded_array.extend(recursive_unfold(item, tail_path))
                return [
                    {**current_obj, head: [unfolded_item]}
                    for unfolded_item in unfolded_array
                ]
            elif isinstance(value, dict):
                unfolded_items = recursive_unfold(value, tail_path)
                return [{**current_obj, head: item} for item in unfolded_items]
            else:
                return [current_obj]

    accumulator = [root_object]
    for path in paths:
        new_acc = []
        for item in accumulator:
            new_acc.extend(recursive_unfold(item, path))
        accumulator = new_acc

    return accumulator


def interpolate_template(template_str, context_map):
    """Execute interpolate template operation."""
    import json

    exact_match = re.match(r"^{{([a-zA-Z0-9_.]+)}}$", template_str)
    if exact_match:
        key = exact_match.group(1)
        if key in context_map:
            val = context_map[key]
            return val if val is not None else None

    result = template_str
    for key, val in context_map.items():
        if val is None:
            replacement = "null"
        elif isinstance(val, (dict, list)):
            replacement = json.dumps(val)
        else:
            replacement = str(val)

        result = re.sub(f"{{{{{key}}}}}", replacement, result)

    return result


def interpolate_query(query_obj, context_map):
    """Execute interpolate query operation."""
    if isinstance(query_obj, list):
        return [interpolate_query(item, context_map) for item in query_obj]
    elif isinstance(query_obj, dict):
        new_obj = {}
        for k, v in query_obj.items():
            new_obj[k] = interpolate_query(v, context_map)
        return new_obj
    elif isinstance(query_obj, str):
        return interpolate_template(query_obj, context_map)
    return query_obj
