"""Module stream_loader.py providing core functionalities."""


class StreamLoader:
    """
    Abstract base class for streaming loaders.
    """

    def __init__(self, data_source):
        """Initialize the instance."""
        self.data_source = data_source

    def load(self):
        """
        Loads the data as an iterator or generator yielding individual records.
        Override in subclasses.
        """
        raise NotImplementedError("Subclasses must implement load()")

    def create_context(self, record, stream_index):
        """
        Creates a validation context for a specific record.
        """
        return {
            "record": record,
            "stream_index": stream_index,
            "source": self.data_source.source,
        }
