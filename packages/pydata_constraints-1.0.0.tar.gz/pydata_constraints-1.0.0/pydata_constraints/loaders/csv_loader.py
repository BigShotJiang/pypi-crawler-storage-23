"""Module csv_loader.py providing core functionalities."""

import csv

from ..utils.logger import logger
from .stream_loader import StreamLoader


class CsvLoader(StreamLoader):
    """
    Loader class that streams items from a CSV file.
    """

    def __init__(self, data_source, delimiter=",", **kwargs):
        """Initialize the instance."""
        super().__init__(data_source)
        self.delimiter = delimiter
        logger.debug(f"CsvLoader created for source: {data_source.source}")

    def load(self):
        """Load data records from the respective source."""
        logger.debug("CsvLoader.load() started")
        if self.data_source.type == "memory":
            raise ValueError("CsvLoader does not support in-memory sources.")

        file_stream = self.data_source.get_stream_or_data()
        try:
            reader = csv.DictReader(file_stream, delimiter=self.delimiter)
            for row in reader:
                yield row
        except Exception as err:
            logger.error(f"CsvLoader iteration error: {err}")
            raise err
        finally:
            file_stream.close()

        logger.debug("CsvLoader.load() finished")
