"""Module json_loader.py providing core functionalities."""

import ijson

from ..utils.logger import logger
from .stream_loader import StreamLoader


class JsonLoader(StreamLoader):
    """
    Loader class that streams items from a JSON file or in-memory array.
    Supports plucking nested arrays using an array_path filtering.
    """

    def __init__(self, data_source, array_path=None):
        """Initialize the instance."""
        super().__init__(data_source)
        self.array_path = array_path
        logger.debug(f"JsonLoader created for source: {data_source.source}")

    def load(self):
        """Load data records from the respective source."""
        logger.debug("JsonLoader.load() started")
        if self.data_source.type == "memory":
            data = self.data_source.source
            if isinstance(data, list):
                for item in data:
                    yield item
            else:
                yield data
            return

        file_stream = self.data_source.get_stream_or_data(mode="rb")
        prefix = f"{self.array_path}.item" if self.array_path else "item"

        try:
            items = ijson.items(file_stream, prefix)
            for item in items:
                yield item
        except Exception as err:
            logger.error(f"JsonLoader iteration error: {err}")
            raise err
        finally:
            file_stream.close()

        logger.debug("JsonLoader.load() finished")
