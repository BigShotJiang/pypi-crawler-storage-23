"""Module unique.py providing core functionalities."""

from ..utils.property_accessor import get_values
from ..utils.scenario_generator import interpolate_template
from .base import ConstraintBase


class UniqueConstraint(ConstraintBase):
    """
    Constraint that ensures a specific field's value is not repeated
    """

    def __init__(self, id):
        """Initialize the instance."""
        super().__init__("unique", id)
        self.field = None
        self.seen_values = set()

    def set_field(self, field):
        """Set the field attribute."""
        self.field = field
        return self

    def validate(self, context):
        """Validate the given context record against the constraint."""
        record = context.get("record")
        value = get_values(record, self.field)

        if value is None:
            return None

        def get_message(invalid_val):
            """Get the message attribute."""
            if self.message:
                parts = self.field.split(".")
                key = parts[-1]
                return interpolate_template(
                    self.message, {key: invalid_val, self.field: invalid_val}
                )
            return f'Duplicate value "{invalid_val}" found in field "{self.field}"'

        if isinstance(value, list):
            for item in value:
                item_str = str(item)
                if item_str in self.seen_values:
                    msg = (
                        get_message(item)
                        if self.message
                        else f'Duplicate value "{item}" found in array field "{self.field}"'
                    )
                    return {
                        "type": self.type,
                        "id": self.id,
                        "message": msg,
                        "record": record,
                    }
                self.seen_values.add(item_str)
            return None

        value_str = str(value)
        if value_str in self.seen_values:
            return {
                "type": self.type,
                "id": self.id,
                "message": get_message(value),
                "record": record,
            }

        self.seen_values.add(value_str)
        return None

    def to_json(self):
        """Convert the instance to a JSON-compatible dictionary."""
        data = super().to_json()
        data.update({"field": self.field})
        return data

    @classmethod
    def from_json(cls, json_data):
        """Create an instance from a JSON dictionary."""
        constraint = cls(json_data.get("id"))
        constraint.set_message(json_data.get("message"))
        constraint.set_service(json_data.get("service"))
        constraint.set_field(json_data.get("field"))
        return constraint
