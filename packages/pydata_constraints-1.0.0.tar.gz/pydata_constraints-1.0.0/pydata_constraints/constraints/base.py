"""Module base.py providing core functionalities."""


class ConstraintBase:
    """
    Base class for all data constraints.
    """

    def __init__(self, type_name, id):
        """Initialize the instance."""
        self.type = type_name
        self.id = id
        self.message = None
        self.service = None

    def set_message(self, message):
        """Set the message attribute."""
        self.message = message
        return self

    def set_service(self, service):
        """Set the service attribute."""
        self.service = service
        return self

    def to_json(self):
        """Convert the instance to a JSON-compatible dictionary."""
        return {
            "type": self.type,
            "id": self.id,
            "message": self.message,
            "service": self.service,
        }

    def validate(self, context):
        """Validate the given context record against the constraint."""
        raise NotImplementedError("Method validate() must be implemented")

    @classmethod
    def from_json(cls, json_data):
        """Create an instance from a JSON dictionary."""
        raise NotImplementedError(
            "Method from_json() must be implemented by concrete classes"
        )
