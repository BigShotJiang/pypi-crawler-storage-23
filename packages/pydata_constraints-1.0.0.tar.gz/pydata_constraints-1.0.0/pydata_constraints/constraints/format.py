"""Module format.py providing core functionalities."""

import re

from ..utils.property_accessor import get_values
from ..utils.scenario_generator import interpolate_template
from .base import ConstraintBase


class FormatConstraint(ConstraintBase):
    """
    Constraint that validates a string field matches a specified regular expression.
    """

    def __init__(self, id):
        """Initialize the instance."""
        super().__init__("format", id)
        self.field = None
        self.regex = None
        self.regex_pattern = None

    def set_field(self, field):
        """Set the field attribute."""
        self.field = field
        return self

    def set_regex(self, regex_pattern):
        """Set the regex attribute."""
        self.regex = re.compile(regex_pattern)
        self.regex_pattern = regex_pattern
        return self

    def validate(self, context):
        """Validate the given context record against the constraint."""
        record = context.get("record")
        value = get_values(record, self.field)

        if value is None:
            return None

        def check(val):
            """Execute check operation."""
            return bool(self.regex.search(str(val))) if val is not None else False

        def get_message(invalid_val):
            """Get the message attribute."""
            if self.message:
                parts = self.field.split(".")
                key = parts[-1]
                return interpolate_template(
                    self.message, {key: invalid_val, self.field: invalid_val}
                )
            return f'Value "{invalid_val}" in field "{self.field}" does not match format "{self.regex_pattern}"'

        if isinstance(value, list):
            for item in value:
                if not check(item):
                    return {
                        "type": self.type,
                        "id": self.id,
                        "message": get_message(item),
                        "record": record,
                    }
        else:
            if not check(value):
                return {
                    "type": self.type,
                    "id": self.id,
                    "message": get_message(value),
                    "record": record,
                }

        return None

    def to_json(self):
        """Convert the instance to a JSON-compatible dictionary."""
        data = super().to_json()
        data.update({"field": self.field, "regex": self.regex_pattern})
        return data

    @classmethod
    def from_json(cls, json_data):
        """Create an instance from a JSON dictionary."""
        constraint = cls(json_data.get("id"))
        constraint.set_message(json_data.get("message"))
        constraint.set_service(json_data.get("service"))
        constraint.set_field(json_data.get("field"))
        constraint.set_regex(json_data.get("regex"))
        return constraint
