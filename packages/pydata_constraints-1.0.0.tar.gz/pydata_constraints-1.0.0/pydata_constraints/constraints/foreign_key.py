"""Module foreign_key.py providing core functionalities."""

import json

from ..utils.property_accessor import get_values
from ..utils.scenario_generator import (
    generate_scenarios,
    interpolate_query,
    interpolate_template,
)
from .base import ConstraintBase


def match_query(record, query):
    """Simple recursive matcher for our basic query engine replacing lokijs"""
    if isinstance(query, dict):
        if "$eq" in query and len(query) == 1:
            return record == query["$eq"]

        if "$and" in query and len(query) == 1:
            for subq in query["$and"]:
                if not match_query(record, subq):
                    return False
            return True

        for key, val in query.items():
            try:
                actual_val = get_values(record, key)
                if isinstance(actual_val, list) and not isinstance(val, list):
                    if not any(match_query(item, val) for item in actual_val):
                        return False
                else:
                    if not match_query(actual_val, val):
                        return False
            except KeyError:
                return False
        return True
    return record == query


class ForeignKeyConstraint(ConstraintBase):
    """
    Constraint that validates foreign key relationships between datasets.
    """

    def __init__(self, id, options=None):
        """Initialize the instance."""
        super().__init__("foreign-key", id)
        options = options or {}
        self.reference_service = options.get("referenceService")
        self.reference_field = options.get("referenceField")
        self.variables = options.get("variables", {})
        self.target = options.get("target", {})
        self.field = None

        self.collection = []
        self.index = {} if self.reference_field else None
        self.is_index_built = False

    def set_reference_service(self, service):
        """Set the reference_service attribute."""
        self.reference_service = service
        return self

    def set_reference_field(self, field):
        """Set the reference_field attribute."""
        self.reference_field = field
        if field:
            self.index = {}
        return self

    def set_variables(self, variables):
        """Set the variables attribute."""
        self.variables = variables
        return self

    def set_target(self, target):
        """Set the target attribute."""
        self.target = target
        return self

    def set_field(self, field):
        """Set the field attribute."""
        self.field = field
        return self

    def to_json(self):
        """Convert the instance to a JSON-compatible dictionary."""
        data = super().to_json()
        data.update(
            {
                "referenceService": self.reference_service,
                "referenceField": self.reference_field,
                "variables": self.variables,
                "target": self.target,
            }
        )
        return data

    @classmethod
    def from_json(cls, json_data):
        """Create an instance from a JSON dictionary."""
        constraint = cls(
            json_data.get("id"),
            {
                "referenceService": json_data.get("referenceService"),
                "referenceField": json_data.get("referenceField"),
                "variables": json_data.get("variables", {}),
                "target": json_data.get("target", {}),
            },
        )
        constraint.set_service(json_data.get("service"))
        constraint.set_field(json_data.get("field"))
        constraint.set_message(json_data.get("message"))
        return constraint

    def build_index(self, reference_data):
        """Execute build index operation."""
        for record in reference_data:
            self.collection.append(record)
            if self.reference_field:
                val = get_values(record, self.reference_field)
                if val is not None:
                    if isinstance(val, list):
                        for v in val:
                            self.index[v] = record
                    else:
                        self.index[val] = record
        self.is_index_built = True

    def find_one(self, query):
        """Execute find one operation."""
        for record in self.collection:
            if match_query(record, query):
                return record
        return None

    def validate(self, context):
        """Validate the given context record against the constraint."""
        if not self.is_index_built:
            raise RuntimeError(f'Index for FK constraint "{self.id}" not built.')

        record = context.get("record")
        is_advanced = len(self.variables) > 0

        if not is_advanced:
            value = get_values(record, self.field)
            if value is None:
                return None

            values_to_check = value if isinstance(value, list) else [value]

            for val in values_to_check:
                if self.index is not None and val in self.index:
                    result = self.index[val]
                else:
                    query = {self.reference_field: {"$eq": val}}
                    result = self.find_one(query)

                if not result:
                    msg = self.message
                    if msg:
                        parts = self.field.split(".")
                        key = parts[-1]
                        msg = interpolate_template(msg, {key: val, self.field: val})
                    else:
                        msg = f'Foreign key violation: Value "{val}" not found in {self.reference_service}.{self.reference_field}'

                    return {
                        "type": "foreign-key",
                        "id": self.id,
                        "message": msg,
                        "record": record,
                        "context": {"service": self.service},
                    }
            return None

        paths_to_expand = list(self.variables.values())
        scenarios = generate_scenarios(record, paths_to_expand)

        for scenario in scenarios:
            query_vars = {}

            for var_name, var_path in self.variables.items():
                val = get_values(scenario, var_path)

                if isinstance(val, list):
                    if len(val) == 1:
                        val = val[0]
                    elif len(val) == 0:
                        val = None

                query_vars[var_name] = val

            query = interpolate_query(self.target, query_vars)
            result = self.find_one(query)

            if not result:
                msg = self.message
                if not msg:
                    msg = f"Foreign key violation: {json.dumps(query_vars)} not found in {self.reference_service}"
                else:
                    msg = interpolate_template(msg, query_vars)

                return {
                    "type": "foreign-key",
                    "id": self.id,
                    "message": msg,
                    "record": record,
                    "context": {"service": self.service, "variables": query_vars},
                }

        return None
