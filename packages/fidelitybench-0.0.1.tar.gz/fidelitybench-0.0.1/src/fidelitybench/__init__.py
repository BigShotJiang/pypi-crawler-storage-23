"""FidelityBench — A communication fidelity benchmark for multi-agent AI systems."""
__version__ = "0.0.1"
__author__ = "Varun Pratap Bhardwaj"
