# FidelityBench
A communication fidelity benchmark for multi-agent AI systems.
Part of [Qualixar](https://qualixar.com) | Author: Varun Pratap Bhardwaj
**Coming soon.** Follow [github.com/qualixar/fidelitybench](https://github.com/qualixar/fidelitybench) for updates.
## License
MIT
