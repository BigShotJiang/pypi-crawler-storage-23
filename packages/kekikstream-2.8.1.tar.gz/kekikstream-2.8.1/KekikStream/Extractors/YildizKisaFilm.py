# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import SecuredLinkExtractor

class YildizKisaFilm(SecuredLinkExtractor):
    name     = "YildizKisaFilm"
    main_url = "https://yildizkisafilm.org"
