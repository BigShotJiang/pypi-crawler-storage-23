# Bu araç @keyiflerolsun tarafından | @KekikAkademi için yazılmıştır.

from KekikStream.Core import BePlayerExtractor

class HotStream(BePlayerExtractor):
    name     = "HotStream"
    main_url = "https://hotstream.club"
