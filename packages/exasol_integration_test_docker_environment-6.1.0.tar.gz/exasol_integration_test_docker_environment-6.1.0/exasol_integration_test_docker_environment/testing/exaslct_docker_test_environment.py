import contextlib
import ssl
import subprocess
from collections.abc import Iterator

import pyexasol
from pyexasol import ExaConnection

from exasol_integration_test_docker_environment.cli.options.test_environment_options import (
    LATEST_DB_VERSION,
)
from exasol_integration_test_docker_environment.lib.models.data.environment_info import (
    EnvironmentInfo,
)
from exasol_integration_test_docker_environment.lib.test_environment.ports import Ports
from exasol_integration_test_docker_environment.testing.utils import (
    check_db_version_from_env,
)


class ExaslctDockerTestEnvironment:
    def __init__(
        self,
        name: str,
        database_host: str,
        db_username: str,
        db_password: str,
        bucketfs_username: str,
        bucketfs_password: str,
        ports: Ports,
        environment_info: EnvironmentInfo | None = None,
        completed_process: subprocess.CompletedProcess | None = None,
    ) -> None:
        self.db_password = db_password
        self.db_username = db_username
        self.ports = ports
        self.bucketfs_username = bucketfs_username
        self.bucketfs_password = bucketfs_password
        self.database_host = database_host
        self.name = name
        self.environment_info = environment_info
        self.completed_process = completed_process
        self.clean_up = None
        self.docker_db_image_version = check_db_version_from_env() or LATEST_DB_VERSION

    def close(self):
        if self.clean_up is not None:
            self.clean_up()

    @contextlib.contextmanager
    def create_connection(self) -> Iterator[ExaConnection]:
        host_name = self.database_host
        port = self.ports.database
        dsn = f"{host_name}:{port}"
        connection = pyexasol.connect(
            dsn=dsn,
            user="sys",
            password="exasol",
            websocket_sslopt={"cert_reqs": ssl.CERT_NONE},
        )
        yield connection
        connection.close()
