# SPDX-License-Identifier: Apache-2.0
from .plugins import get_registry, CommandRegistry
