# SPDX-License-Identifier: Apache-2.0
from jcapy.utils.updates import VERSION as __version__
