"""LangGraph agent package."""

from .haystack import HaystackAgent

__all__ = [
    "HaystackAgent",
]
