"""ASCII art banner for the ph-worker CLI."""

from rich.console import Console
from rich.text import Text

_BANNER_ART = r"""
 ____  _   _  __        __         _
|  _ \| | | | \ \      / /__  _ __| | _____ _ __
| |_) | |_| |  \ \ /\ / / _ \| '__| |/ / _ \ '__|
|  __/|  _  |   \ V  V / (_) | |  |   <  __/ |
|_|   |_| |_|    \_/\_/ \___/|_|  |_|\_\___|_|

  Poly Hammer  ·  Self-Hosted Inference Agent
"""

GOLD = "color(178)"  # 256-color gold / yellow-gold


def print_banner(console: Console) -> None:
    """Print the ph-worker banner in gold."""
    text = Text(_BANNER_ART, style=GOLD)
    console.print(text)
