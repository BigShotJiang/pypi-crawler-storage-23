"""
Docker image discovery for Poly Hammer Portal compatible images.

Scans local Docker images for ``ai.poly-hammer.*`` OCI labels and returns
structured metadata for each compatible image. Each image may contain
multiple models with independent hardware requirements, parsed from
per-model labels (``ai.poly-hammer.model.<id>.*``).

Required labels (image is skipped if any are missing):
  - ai.poly-hammer.portal-compatible = "true"
  - ai.poly-hammer.service-id
  - ai.poly-hammer.model-ids       (comma-separated model IDs)
  - ai.poly-hammer.cuda-version

Per-model labels (optional, looked up for each model ID):
  - ai.poly-hammer.model.<id>.name
  - ai.poly-hammer.model.<id>.min-vram-gb
  - ai.poly-hammer.model.<id>.min-ram-gb
"""

import logging
from typing import Any

import docker

logger = logging.getLogger(__name__)

_PREFIX = "ai.poly-hammer."

_REQUIRED_LABELS = frozenset(
    {
        "portal-compatible",
        "service-id",
        "model-ids",
        "cuda-version",
    }
)


def discover_local_images(client: docker.DockerClient) -> list[dict[str, Any]]:
    """Scan local Docker images for portal-compatible OCI labels.

    Returns a list of dicts matching the ``WorkerImageInfo`` schema — one
    entry per Docker image. Each entry contains a ``models`` list with
    per-model metadata (name, hardware requirements).
    """
    results: list[dict[str, Any]] = []

    try:
        images = client.images.list()
    except docker.errors.DockerException:
        logger.exception("Failed to list Docker images")
        return results

    for image in images:
        labels = image.labels or {}

        # Quick check: skip images without the portal-compatible flag
        if labels.get(f"{_PREFIX}portal-compatible") != "true":
            continue

        # Extract all ai.poly-hammer.* labels (strip prefix)
        ph_labels: dict[str, str] = {}
        for key, value in labels.items():
            if key.startswith(_PREFIX):
                ph_labels[key[len(_PREFIX) :]] = value

        # Validate required labels
        missing = _REQUIRED_LABELS - ph_labels.keys()
        if missing:
            tag = _best_tag(image)
            logger.warning(
                "Image %s has portal-compatible flag but missing required labels: %s",
                tag,
                ", ".join(sorted(missing)),
            )
            continue

        image_ref = _best_tag(image)
        service_id = ph_labels["service-id"]
        cuda_version = ph_labels["cuda-version"]

        # Image size in GB (Docker reports bytes)
        image_size_gb = round(image.attrs.get("Size", 0) / (1024**3), 2)

        # Parse comma-separated model IDs
        model_ids = [m.strip() for m in ph_labels["model-ids"].split(",") if m.strip()]

        # Build per-model metadata from ai.poly-hammer.model.<id>.* labels
        models: list[dict[str, Any]] = []
        for model_id in model_ids:
            model_prefix = f"model.{model_id}."
            model_name = ph_labels.get(f"{model_prefix}name")
            min_vram_gb = _parse_int(ph_labels.get(f"{model_prefix}min-vram-gb", "0"))
            min_ram_gb = _parse_int(ph_labels.get(f"{model_prefix}min-ram-gb", "0"))
            models.append(
                {
                    "model_id": model_id,
                    "model_name": model_name,
                    "min_vram_gb": min_vram_gb,
                    "min_ram_gb": min_ram_gb,
                }
            )

        results.append(
            {
                "image_ref": image_ref,
                "service_id": service_id,
                "cuda_version": cuda_version,
                "image_size_gb": image_size_gb,
                "models": models,
            }
        )

    total_models = sum(len(img["models"]) for img in results)
    logger.info(
        "Discovered %d portal-compatible image(s) with %d model(s)",
        len(results),
        total_models,
    )
    return results


def _best_tag(image: Any) -> str:
    """Return the most useful tag for an image, or fall back to short ID."""
    tags = image.tags
    if tags:
        return tags[0]
    short_id = image.short_id
    return short_id.replace("sha256:", "") if short_id else "<untagged>"


def _parse_int(value: str) -> int:
    """Parse an integer from a label value, defaulting to 0."""
    try:
        return int(value)
    except (ValueError, TypeError):
        return 0
