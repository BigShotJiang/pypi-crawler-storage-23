from . import conf

settings = conf.Settings()

__all__ = ['settings']
