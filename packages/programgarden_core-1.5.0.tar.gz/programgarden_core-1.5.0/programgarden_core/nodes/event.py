"""
ProgramGarden Core - Event Nodes

Note: AlertNode, EventHandlerNode, ErrorHandlerNode are removed.
- Notification: Use community nodes (TelegramNode, SlackNode, etc.)
- Event/Error handling: Handled by executor internally
"""

# 이벤트 노드는 커뮤니티 노드(TelegramNode 등)로 대체됨
# 에러 핸들링은 executor 레벨에서 기본 처리

__all__: list = []
