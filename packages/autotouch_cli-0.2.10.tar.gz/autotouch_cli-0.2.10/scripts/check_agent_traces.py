#!/usr/bin/env python3
"""
Check agent traces from enrichment runs
"""

import os
import sys
from pymongo import MongoClient
from bson import ObjectId
import json

# Add parent directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# MongoDB connection
MONGODB_URI = os.getenv('MONGODB_URI', 'mongodb://localhost:27017')
MONGODB_DB_NAME = os.getenv('MONGODB_DB_NAME', 'smart_table')


def check_agent_traces(table_id: str = None, column_id: str = None):
    """Check agent traces from recent enrichments"""
    client = MongoClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]
    
    print("\n=== Agent Mode Traces ===\n")
    
    # Build query
    query = {}
    if column_id:
        query['column_id'] = column_id
    
    # Find cells with agent traces
    cells_with_traces = list(db.cells.find(
        {**query, 'agent_trace': {'$exists': True, '$ne': None}},
        limit=10
    ).sort('_id', -1))
    
    print(f"Found {len(cells_with_traces)} cells with agent traces\n")
    
    for cell in cells_with_traces:
        # Get row info
        row = db.rows.find_one({'_id': ObjectId(cell['row_id'])})
        if not row:
            continue
            
        # Get table info if not provided
        if not table_id:
            table = db.tables.find_one({'_id': row['table_id']})
            table_name = table.get('name', 'Unknown') if table else 'Unknown'
        else:
            table = db.tables.find_one({'_id': ObjectId(table_id)})
            table_name = table.get('name', 'Unknown') if table else 'Unknown'
        
        print(f"Table: {table_name}")
        print(f"Row ID: {cell['row_id']}")
        print(f"Column ID: {cell['column_id']}")
        print(f"Value: {cell.get('value', 'No value')}")
        print(f"\nAgent Trace:")
        print("-" * 80)
        print(cell.get('agent_trace', 'No trace available'))
        print("-" * 80)
        print("\n")
    
    client.close()


def check_latest_enrichment_logs():
    """Check the latest enrichment logs to see what happened"""
    client = MongoClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]
    
    print("\n=== Latest Agent Enrichment Results ===\n")
    
    # Find the most recent enrichment column
    tables = list(db.tables.find())
    
    agent_columns = []
    for table in tables:
        for col in table.get('columns', []):
            if col.get('kind') == 'enrichment' and col.get('config', {}).get('mode') == 'agent':
                agent_columns.append({
                    'table_name': table.get('name'),
                    'table_id': str(table['_id']),
                    'column': col
                })
    
    if not agent_columns:
        print("No agent mode columns found!")
        return
    
    # Check the most recent one
    for col_info in agent_columns[:3]:  # Check up to 3 most recent
        print(f"\nTable: {col_info['table_name']}")
        print(f"Column: {col_info['column'].get('name', col_info['column'].get('label', 'Unnamed'))} (ID: {col_info['column']['id']})")
        print(f"Prompt: {col_info['column']['config']['prompt']}")
        print(f"Status: {col_info['column'].get('status', 'unknown')}")
        
        # Get sample results
        cells = list(db.cells.find({
            'column_id': col_info['column']['id']
        }).limit(5))
        
        print(f"\nResults ({len(cells)} cells):")
        for cell in cells:
            print(f"  - Value: {cell.get('value', 'No value')[:100]}...")
            if cell.get('status') == 'error':
                print(f"    Error: {cell.get('error_message', 'Unknown error')}")
    
    client.close()


if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Check agent mode traces")
    parser.add_argument("--table", help="Table ID to check")
    parser.add_argument("--column", help="Column ID to check")
    parser.add_argument("--latest", action="store_true", help="Check latest enrichment results")
    
    args = parser.parse_args()
    
    if args.latest:
        check_latest_enrichment_logs()
    else:
        check_agent_traces(args.table, args.column)