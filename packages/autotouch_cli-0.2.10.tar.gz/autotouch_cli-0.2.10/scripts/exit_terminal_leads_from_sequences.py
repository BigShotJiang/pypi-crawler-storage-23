#!/usr/bin/env python3
"""
Exit sequence enrollments for terminal leads (rejected/converted).

Usage:
  MONGODB_PROD_CONNECTION_STRING="mongodb+srv://..." MONGODB_DB_NAME="autotouch" \
    python scripts/exit_terminal_leads_from_sequences.py \
      --org-id 69306412024a06cd51c47c95 \
      --statuses rejected,converted \
      --dry-run

  # Limit to a specific sequence (org inferred from sequence)
  MONGODB_PROD_CONNECTION_STRING="mongodb+srv://..." \
    python scripts/exit_terminal_leads_from_sequences.py \
      --sequence-id 69306412024a06cd51c47c95

Options:
  --batch-size 500
  --sync-provider   # best-effort provider pause/resume (can be slow)
"""

from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime
from typing import Any, Iterable, List, Set

from bson import ObjectId
from pymongo import MongoClient, UpdateOne
import certifi


TERMINAL_LEAD_STATUSES = {"rejected", "converted"}
ACTIVE_ENROLLMENT_STATUSES = {"active", "paused", "error"}
OPEN_TASK_STATUSES = {"pending", "queued", "created"}
TERMINAL_TASK_STATUSES = {"completed", "failed", "skipped"}
TERMINAL_TASK_PREFIXES = ("completed_", "failed_", "ended_")


def _coerce_oid(value: Any):
    if isinstance(value, ObjectId):
        return value
    if isinstance(value, str):
        try:
            return ObjectId(value)
        except Exception:
            return None
    return None


def _expand_id_variants(values: Iterable[Any]) -> List[Any]:
    expanded: List[Any] = []
    seen: Set[str] = set()

    def _add(val: Any) -> None:
        key = f"{type(val).__name__}:{val}"
        if key in seen:
            return
        seen.add(key)
        expanded.append(val)

    for value in values:
        if value is None:
            continue
        _add(value)
        if isinstance(value, ObjectId):
            _add(str(value))
        elif isinstance(value, str):
            oid = _coerce_oid(value)
            if oid is not None:
                _add(oid)

    return expanded


def _parse_statuses(raw: str | None) -> Set[str]:
    if not raw:
        return set(TERMINAL_LEAD_STATUSES)
    return {s.strip().lower() for s in raw.split(",") if s.strip()}


def _batched(iterable: Iterable[Any], size: int) -> Iterable[List[Any]]:
    batch: List[Any] = []
    for item in iterable:
        batch.append(item)
        if len(batch) >= size:
            yield batch
            batch = []
    if batch:
        yield batch


def _get_db() -> MongoClient:
    mongo_uri = os.getenv("MONGODB_PROD_CONNECTION_STRING")
    if not mongo_uri:
        sys.exit("MONGODB_PROD_CONNECTION_STRING is required")
    db_name = os.getenv("MONGODB_DB_NAME", "autotouch")
    client = MongoClient(mongo_uri, tlsCAFile=certifi.where())
    return client[db_name]


def _organization_match_values(org_id: str) -> List[Any]:
    values: List[Any] = [org_id]
    oid = _coerce_oid(org_id)
    if oid is not None:
        values.append(oid)
    return values


def _refresh_next_activity_for_leads(
    db,
    *,
    organization_id: str,
    lead_variants: List[Any],
    lead_oids: List[ObjectId],
) -> None:
    if not lead_variants or not lead_oids:
        return

    org_values = _organization_match_values(organization_id)
    match_filter = {
        "organization_id": {"$in": org_values},
        "lead_id": {"$in": lead_variants},
        "due_date": {"$type": "date"},
        "is_automated": {"$ne": True},
        "task_status": {
            "$nin": list(TERMINAL_TASK_STATUSES),
            "$not": {"$regex": f"^({'|'.join(TERMINAL_TASK_PREFIXES)})"},
        },
    }
    pipeline = [
        {"$match": match_filter},
        {"$group": {"_id": "$lead_id", "next_activity_at": {"$min": "$due_date"}}},
    ]
    results = list(db.task_queue.aggregate(pipeline))
    next_by_lead: dict[ObjectId, Any] = {}
    for row in results:
        lead_val = row.get("_id")
        lead_oid = _coerce_oid(lead_val)
        if lead_oid is None:
            continue
        next_by_lead[lead_oid] = row.get("next_activity_at")

    ops: List[UpdateOne] = []
    for lead_oid in lead_oids:
        ops.append(
            UpdateOne(
                {"_id": lead_oid, "organization_id": {"$in": org_values}},
                {"$set": {"next_activity_at": next_by_lead.get(lead_oid)}},
            )
        )
    if ops:
        db.leads.bulk_write(ops, ordered=False)


async def _sync_provider_status(db_async, enrollment_ids: List[Any]) -> None:
    if not enrollment_ids:
        return
    from apps.api.services.workflow.sequences.provider_lead_control import (
        sync_provider_lead_status_for_enrollment,
    )

    for enrollment_id in enrollment_ids:
        try:
            await sync_provider_lead_status_for_enrollment(db_async, enrollment_id=enrollment_id)
        except Exception:
            # Best-effort; continue
            pass


def main() -> None:
    parser = argparse.ArgumentParser(description="Exit sequence enrollments for terminal leads")
    parser.add_argument("--org-id", help="Organization id (required unless --sequence-id provided)")
    parser.add_argument("--sequence-id", help="Limit to a single sequence id")
    parser.add_argument("--statuses", help="Comma-separated lead statuses to exit", default=None)
    parser.add_argument("--batch-size", type=int, default=500)
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--sync-provider", action="store_true", help="Pause/resume provider leads (slow)")
    args = parser.parse_args()

    db = _get_db()
    org_id = args.org_id
    sequence_id = args.sequence_id

    # If sequence_id provided, infer org_id from sequence doc
    seq_values: List[Any] | None = None
    if sequence_id:
        seq_oid = _coerce_oid(sequence_id)
        seq_query = {"$or": [{"_id": sequence_id}]}
        if seq_oid is not None:
            seq_query["$or"].append({"_id": seq_oid})
        sequence = db.sequences.find_one(seq_query, {"organization_id": 1})
        if not sequence:
            sys.exit("Sequence not found")
        org_id = org_id or sequence.get("organization_id")
        seq_values = _expand_id_variants([sequence_id])

    if not org_id:
        sys.exit("--org-id is required when --sequence-id is not provided")

    statuses = _parse_statuses(args.statuses)
    if not statuses:
        sys.exit("No statuses provided")

    now = datetime.utcnow()

    lead_query = {
        "organization_id": org_id,
        "lead_status": {"$in": list(statuses)},
    }
    lead_cursor = db.leads.find(lead_query, {"_id": 1})

    enrollments_total = 0
    tasks_total = 0
    batches = 0

    for batch in _batched((doc.get("_id") for doc in lead_cursor), args.batch_size):
        batches += 1
        lead_variants = _expand_id_variants(batch)
        lead_oids = [oid for oid in (_coerce_oid(val) for val in batch) if oid is not None]
        if not lead_variants:
            continue

        enrollment_filter: dict[str, Any] = {
            "organization_id": org_id,
            "lead_id": {"$in": lead_variants},
            "status": {"$in": list(ACTIVE_ENROLLMENT_STATUSES)},
        }
        if seq_values is not None:
            enrollment_filter["sequence_id"] = {"$in": seq_values}

        if args.dry_run:
            enrollments_matched = db.sequence_enrollments.count_documents(enrollment_filter)
        else:
            enrollments_matched = db.sequence_enrollments.update_many(
                enrollment_filter,
                {"$set": {"status": "exited", "next_run_at": None, "updated_at": now}},
            ).modified_count

        enrollments_total += int(enrollments_matched or 0)

        task_filter: dict[str, Any] = {
            "organization_id": org_id,
            "lead_id": {"$in": lead_variants},
            "task_status": {"$in": list(OPEN_TASK_STATUSES)},
            "sequence_id": {"$exists": True},
        }
        if seq_values is not None:
            task_filter["sequence_id"] = {"$in": seq_values}

        if args.dry_run:
            tasks_matched = db.task_queue.count_documents(task_filter)
        else:
            tasks_matched = db.task_queue.update_many(
                task_filter,
                {"$set": {"task_status": "skipped", "updated_at": now}},
            ).modified_count

        tasks_total += int(tasks_matched or 0)

        if not args.dry_run and lead_oids:
            _refresh_next_activity_for_leads(
                db,
                organization_id=org_id,
                lead_variants=lead_variants,
                lead_oids=lead_oids,
            )

        if args.sync_provider and not args.dry_run:
            # Collect enrollment ids we just updated, then sync provider status.
            updated_ids = list(
                db.sequence_enrollments.find(
                    {**enrollment_filter, "status": "exited"},
                    {"_id": 1},
                ).limit(5000)
            )
            enrollment_ids = [doc.get("_id") for doc in updated_ids if doc.get("_id") is not None]
            if enrollment_ids:
                try:
                    import asyncio
                    from motor.motor_asyncio import AsyncIOMotorClient

                    mongo_uri = os.getenv("MONGODB_PROD_CONNECTION_STRING")
                    db_name = os.getenv("MONGODB_DB_NAME", "autotouch")
                    client_async = AsyncIOMotorClient(mongo_uri, tlsCAFile=certifi.where())
                    db_async = client_async[db_name]
                    asyncio.run(_sync_provider_status(db_async, enrollment_ids))
                    client_async.close()
                except Exception:
                    # Best-effort; continue
                    pass

    print("Done.")
    print(f"  batches: {batches}")
    print(f"  enrollments updated: {enrollments_total}")
    print(f"  tasks updated: {tasks_total}")


if __name__ == "__main__":
    main()
