# CLI/script package marker for setuptools console entry points.
