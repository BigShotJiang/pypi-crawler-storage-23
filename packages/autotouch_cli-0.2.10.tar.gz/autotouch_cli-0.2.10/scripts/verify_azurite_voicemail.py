#!/usr/bin/env python3
"""
Verify Azurite (or Azure Blob) connection for voicemail upload.
Run from repo root:  python scripts/verify_azurite_voicemail.py

Requires: pip install python-dotenv azure-storage-blob
"""
from pathlib import Path
import os
import sys

# Ensure repo root is on path and load .env from repo root
REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

try:
    from dotenv import load_dotenv
    load_dotenv(REPO_ROOT / ".env")
except ImportError:
    pass  # no dotenv; use existing env

conn = (os.getenv("AZURE_STORAGE_CONNECTION_STRING") or "").strip().strip('"').strip("'")
container = (os.getenv("AZURE_STORAGE_CONTAINER") or "smarttableexports").strip().strip('"').strip("'")

if not conn:
    print("AZURE_STORAGE_CONNECTION_STRING is not set.")
    print("Add to .env (no quotes):")
    print('  AZURE_STORAGE_CONNECTION_STRING=DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1;')
    sys.exit(1)

def main():
    from azure.storage.blob import BlobServiceClient
    from azure.core.exceptions import ResourceExistsError, HttpResponseError

    print("Using container:", container)
    if "127.0.0.1" in conn or "localhost" in conn:
        print("Connection string points to Azurite. Ensure Azurite is running (e.g. docker run -p 10000:10000 mcr.microsoft.com/azure-storage/azurite)")
    print()

    try:
        client = BlobServiceClient.from_connection_string(conn)
        cc = client.get_container_client(container)
        cc.create_container()
        print("OK – Container created successfully.")
    except ResourceExistsError:
        print("OK – Container already exists.")
    except HttpResponseError as e:
        err = str(e).lower()
        if "authorization" in err or "authenticate" in err:
            print("Authentication failed. Check:")
            print("  1. Connection string has NO quotes in .env (use: KEY=value not KEY=\"value\")")
            print("  2. For Azurite, AccountKey must be exactly: Eby8vdM02xNOcqFlqUwJPLlmEtlCDXJ1OUzFT50uSRZ6IFsuFq2UVErCz4I6tq/K1SZFPTOtr/KBHBeksoGMGw==")
            print("  3. Azurite is running: docker run -p 10000:10000 mcr.microsoft.com/azure-storage/azurite")
            print("  4. BlobEndpoint is http://127.0.0.1:10000/devstoreaccount1")
        else:
            print("Error:", e)
        sys.exit(1)
    except Exception as e:
        print("Error:", e)
        sys.exit(1)

if __name__ == "__main__":
    main()
