#!/usr/bin/env python3
from __future__ import annotations

"""
Simulate a real user prompt through the Sidecar (chat) orchestrator without HTTP.

This runs SidecarOrchestrator directly, builds a lightweight context, and prints
the streamed frames (as the SSE route would) and the final aggregated text.

Usage examples:
  python3 scripts/run_sidecar_orchestrator_demo.py \
    --prompt "What's the latest on OpenAI?" \
    --lead-name "Unknown" \
    --company-name "OpenAI" \
    --model "openai/gpt-4o-mini"

  python3 scripts/run_sidecar_orchestrator_demo.py \
    --prompt "Write a follow-up email about yesterday's call" \
    --lead-name "Jane Smith" --company-name "Acme Corp"

Requires provider API keys to be set (e.g., OPENAI_API_KEY) and (optionally)
MCP_GATEWAY_URL if research spoke runs through MCP.
"""

import argparse
import asyncio
import os
from typing import Any, Dict, List


def _bootstrap_path() -> None:
    import sys
    root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    if root not in sys.path:
        sys.path.insert(0, root)


_bootstrap_path()


async def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--prompt", type=str, required=True, help="User prompt text")
    parser.add_argument("--model", type=str, default="openai/gpt-4o-mini", help="provider/model id")
    parser.add_argument("--lead-name", type=str, default="", help="Lead name")
    parser.add_argument("--company-name", type=str, default="", help="Company name")
    parser.add_argument("--company-domain", type=str, default="", help="Company domain")
    args = parser.parse_args()

    # Import orchestrator pieces
    from apps.api.services.workflow.assistant.sidecar_agent.orchestrator import SidecarOrchestrator, build_general_system_prompt
    from apps.api.services.workflow.assistant.sidecar_agent.context import SidecarContextHandle
    from apps.api.services.workflow.assistant.sidecar_agent.spokes import get_spoke_registry

    # Simulate current_user and context
    current_user: Dict[str, Any] = {"full_name": "Demo User", "organization_name": "Demo Org"}
    lead_payload: Dict[str, Any] = {
        "name": args.lead_name or "",
        "company_name": args.company_name or "",
        "company_domain": args.company_domain or "",
    }
    context = SidecarContextHandle(
        persistent={"user_name": current_user["full_name"]},
        lead=lead_payload,
        task=None,
        favorites=None,
    )

    system = build_general_system_prompt(current_user=current_user, context=context, spokes=get_spoke_registry())
    messages = [
        {"role": "system", "content": system},
        {"role": "user", "content": args.prompt},
    ]

    frames: List[Dict[str, Any]] = []
    stream_events: List[Dict[str, Any]] = []

    async def emit_frame(frame: Dict[str, Any]) -> None:
        frames.append(frame)
        et = frame.get("type")
        if et in {"text-start", "text-delta", "text-end", "finish", "error"}:
            print(f"FRAME: {et} -> {frame}")

    async def emit_stream_event(event: Dict[str, Any]) -> None:
        stream_events.append(event)
        if event.get("type") in {"tool-start", "tool-end", "tool-error", "start-step"}:
            print(f"EVENT: {event}")

    orch = SidecarOrchestrator()
    result = await orch.run(
        messages=messages,
        context=context,
        model_id=args.model,
        emit_frame=emit_frame,
        emit_stream_event=emit_stream_event,
    )

    print("\n=== ORCHESTRATOR RESULT ===")
    print(f"handled={result.handled}, has_text={result.has_text}")
    if result.has_text:
        print("\n--- Aggregated Text ---")
        print(result.text)


if __name__ == "__main__":
    asyncio.run(main())
