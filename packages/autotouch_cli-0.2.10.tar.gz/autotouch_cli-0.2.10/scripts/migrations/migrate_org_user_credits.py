"""
One-off migration to move credit balances to organizations and per-user allowances.

Usage:
    python3 scripts/migrations/migrate_org_user_credits.py --uri "<mongodb uri>" --db autotouch --apply

Defaults to dry-run; pass --apply to write changes.
"""

import argparse
from typing import Optional

from pymongo import MongoClient


def upsert_org_credits(db, apply: bool) -> int:
    """Ensure organizations have credits and credits_monthly_quota fields."""
    updates = 0
    cursor = db.organizations.find(
        {
            "$or": [
                {"credits": {"$exists": False}},
                {"credits_monthly_quota": {"$exists": False}},
                {"credits": None},
                {"credits_monthly_quota": None},
            ]
        },
        {"organization_id": 1, "credits": 1, "credits_monthly_quota": 1},
    )
    for org in cursor:
        set_fields = {}
        if org.get("credits") is None:
            set_fields["credits"] = 0
        if org.get("credits_monthly_quota") is None:
            set_fields["credits_monthly_quota"] = 0
        if not set_fields:
            continue
        updates += 1
        if apply:
            db.organizations.update_one({"_id": org["_id"]}, {"$set": set_fields})
    return updates


def migrate_users(db, apply: bool) -> dict:
    """
    Copy legacy user credits into user_allowance/user_monthly_quota,
    and zero out legacy credits fields.
    """
    stats = {"touched": 0, "set_allowance": 0, "zeroed_legacy": 0}
    cursor = db.users.find(
        {},
        {
            "credits": 1,
            "credits_monthly_quota": 1,
            "user_allowance": 1,
            "user_monthly_quota": 1,
        },
    )
    for user in cursor:
        legacy_credits = int(user.get("credits") or 0)
        legacy_quota = int(user.get("credits_monthly_quota") or 0)
        allowance = user.get("user_allowance")
        monthly_quota = user.get("user_monthly_quota")

        set_fields = {}

        # If allowance not set, inherit from legacy credits
        if allowance is None:
            set_fields["user_allowance"] = legacy_credits
            stats["set_allowance"] += 1

        # If monthly quota not set, mirror legacy monthly quota
        if monthly_quota is None:
            set_fields["user_monthly_quota"] = legacy_quota

        # Zero out legacy fields to avoid double-charging on old readers
        if user.get("credits") not in (0, None) or user.get("credits_monthly_quota") not in (0, None):
            set_fields["credits"] = 0
            set_fields["credits_monthly_quota"] = 0
            stats["zeroed_legacy"] += 1

        if not set_fields:
            continue

        stats["touched"] += 1
        if apply:
            db.users.update_one({"_id": user["_id"]}, {"$set": set_fields})

    return stats


def main(uri: str, db_name: str, apply: bool) -> None:
    client = MongoClient(uri)
    db = client[db_name]

    org_updates = upsert_org_credits(db, apply)
    user_stats = migrate_users(db, apply)

    print(f"[orgs] ensured credits fields on {org_updates} document(s)")
    print(
        f"[users] touched={user_stats['touched']} set_allowance={user_stats['set_allowance']} zeroed_legacy={user_stats['zeroed_legacy']}"
    )
    if not apply:
        print("Dry run only. Re-run with --apply to persist changes.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Migrate credits to org + user allowance model.")
    parser.add_argument("--uri", required=True, help="MongoDB connection string")
    parser.add_argument("--db", default="autotouch", help="Database name (default: autotouch)")
    parser.add_argument(
        "--apply",
        action="store_true",
        help="Apply changes (otherwise dry-run)",
    )
    args = parser.parse_args()
    main(args.uri, args.db, args.apply)
