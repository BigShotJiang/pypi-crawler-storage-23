#!/usr/bin/env python3
"""
Add a compound index on rows to optimize keyset pagination:
  { table_id: 1, position: 1, _id: 1 }

This improves queries that sort by (position, _id) and apply range
filters using position and _id for the cursor.
"""

import os
import asyncio
import logging
from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import ASCENDING

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGODB_DB_NAME = os.getenv("MONGODB_DB_NAME", "smart_table")


async def ensure_rows_position_id_index():
    client = AsyncIOMotorClient(MONGODB_URI)
    db = client[MONGODB_DB_NAME]
    try:
        logger.info("Creating compound index on rows (table_id, position, _id) if missing...")
        name = "rows_table_position_id_idx"
        await db.rows.create_index([
            ("table_id", ASCENDING),
            ("position", ASCENDING),
            ("_id", ASCENDING),
        ], name=name)
        logger.info("✅ Ensured index: %s", name)

        # Show current indexes for rows
        logger.info("Current rows indexes:")
        for idx in await db.rows.list_indexes().to_list(length=None):
            logger.info("  - %s: %s", idx.get("name"), idx.get("key"))
    finally:
        client.close()


if __name__ == "__main__":
    asyncio.run(ensure_rows_position_id_index())

