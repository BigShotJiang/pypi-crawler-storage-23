# Autotouch CLI Quickstart (`autotouch`)

This is the package-facing quickstart for agents and humans using the installable CLI.

## Install

```bash
pipx install autotouch-cli
# or
pip install autotouch-cli
```

## Bootstrap account + API key (optional, recommended for new agents)

If you already have a developer API key, skip this and go to Configure auth.

```bash
curl -X POST "https://app.autotouch.ai/api/auth/agent-bootstrap" \
  -H "Content-Type: application/json" \
  -d '{
    "first_name": "Ada",
    "last_name": "Lovelace",
    "email": "ada@yourcompany.com",
    "password": "use-a-strong-random-password",
    "organization_name": "Your Company",
    "key_name": "Agent bootstrap key"
  }'
```

Response includes:
- `apiKey` (returned once),
- `userData`,
- `key` metadata,
- `credits` snapshot.

Starter credits:
- New orgs created via signup/bootstrap start with `50` credits.

Identity linking:
- Human sign-in with the same normalized email lands in the same user/org account.

## Configure auth

```bash
autotouch auth set-key --api-key stk_... --base-url https://app.autotouch.ai
autotouch auth check
```

## Preflight (recommended before writes)

```bash
# 1) Verify target table exists and copy the exact id
autotouch tables list --view-mode org --output human

# 2) Parse CSV only (no write)
autotouch rows import-csv \
  --table-id <TABLE_ID> \
  --confirm-table-id <TABLE_ID> \
  --file contacts.csv \
  --dry-run \
  --output json
```

Why this matters:
- Prevents wrong-table imports.
- Shows parsed row count and keys before spend/write.

## Import CSV (default: optimized async)

```bash
autotouch rows import-csv \
  --table-id <TABLE_ID> \
  --confirm-table-id <TABLE_ID> \
  --file contacts.csv \
  --checkpoint-file .autotouch-import.json \
  --wait \
  --output json
```

Notes:
- `--transport optimized` is default (`/import-optimized`).
- `--wait` polls import status to terminal state.
- `--checkpoint-file` stores state and blocks accidental duplicate re-imports.
- Use `--allow-reimport` if you intentionally want to run the same file again.

## Import modes

1. `optimized` (default)
- Uses `/api/tables/{table_id}/import-optimized`.
- Best for larger files and resilient async handling.

2. `direct`
- Uses row + cell API loops.
- Useful for debugging/smaller imports.

```bash
autotouch rows import-csv \
  --table-id <TABLE_ID> \
  --confirm-table-id <TABLE_ID> \
  --file contacts.csv \
  --transport direct \
  --output json
```

## Auto-run trigger contract

Auto-run is configured per column (`autoRun`), not per table.

- `never`: no automatic runs.
- `onInsert`: runs on newly inserted rows (for example CSV import/webhook ingest).
- `onSourceUpdate`: runs only when source values are updated (for example cell patch/update).

Important:
- Insert events do not run `onSourceUpdate` columns.
- Imports may queue auto-run dispatch evaluation, but only columns whose `autoRun` policy matches the event are queued.

## Create a column

Recipe-first flow (recommended):

```bash
autotouch columns recipe --type add_to_crm --output human
```

Then create from the generated payload:

```bash
autotouch columns create \
  --table-id <TABLE_ID> \
  --data-file column.json \
  --output json
```

Notes:
- `add_to_crm` is optional and non-billable.
- Email/phone enrichment does not require creating/running `add_to_crm`.
- For `add_to_crm`, required mapping keys are `linkedinUrl` and `companyDomain`.

## Create basic/manual fields (text, number, date, etc.)

Use `kind=manual` for non-enrichment columns.

Supported `dataType` values:
- `text`
- `number`
- `date`
- `boolean`
- `email`
- `url`
- `json`

`manual-column.json`:

```json
{
  "key": "employee_count",
  "label": "Employee Count",
  "kind": "manual",
  "dataType": "number",
  "origin": "api",
  "autoRun": "never"
}
```

```bash
autotouch columns create \
  --table-id <TABLE_ID> \
  --data-file manual-column.json \
  --output json
```

To create rows with values in one step:

`rows.json`:

```json
{
  "records": [
    { "company": "Acme", "employee_count": 125, "founded_on": "2021-05-01" }
  ]
}
```

```bash
autotouch rows add \
  --table-id <TABLE_ID> \
  --records-file rows.json \
  --detect-types \
  --output json
```

To update existing rows/cells:

`updates.json`:

```json
{
  "updates": [
    { "rowId": "<ROW_ID>", "key": "employee_count", "value": 130 },
    { "rowId": "<ROW_ID>", "key": "founded_on", "value": "2021-05-01" }
  ]
}
```

```bash
autotouch cells patch \
  --table-id <TABLE_ID> \
  --updates-file updates.json \
  --detect-types \
  --output json
```

Note:
- If `updates[].key` does not exist, patch can auto-create a manual column (with `--detect-types`).

## Run exactly next N rows (recommended for agents)

```bash
autotouch columns run-next \
  --table-id <TABLE_ID> \
  --column-id <COLUMN_ID> \
  --count 5 \
  --show-estimate \
  --wait \
  --output json
```

Why `run-next`:
- Deterministic exact-count batching.
- Avoids ambiguous `firstN` increments in agent loops.

For `add_to_crm`, prefer bounded runs first:

```bash
autotouch columns run-next \
  --table-id <TABLE_ID> \
  --column-id <ADD_TO_CRM_COLUMN_ID> \
  --count 25 \
  --show-estimate \
  --wait
```

## Credit-safe filtering pattern

Filter out rows that are missing required upstream fields before billable runs.

`filters.json`:

```json
{
  "mode": "and",
  "filters": [
    { "columnKey": "linkedin_url", "operator": "isNotEmpty" },
    { "columnKey": "work_email_address", "operator": "isEmpty" }
  ]
}
```

Run:

```bash
autotouch columns run-next \
  --table-id <TABLE_ID> \
  --column-id <COLUMN_ID> \
  --count 5 \
  --filters-file filters.json \
  --show-estimate \
  --wait
```

## Job truth contract (agent-safe)

- Treat a run as started only when you receive `job_id`.
- Treat a run as done only when `jobs get/watch` returns terminal status.

```bash
autotouch jobs get --job-id <JOB_ID> --output json
autotouch jobs watch --job-id <JOB_ID> --interval 2 --output json
```

Terminal statuses:
- `completed`
- `partial`
- `error`
- `cancelled`

## Troubleshooting

1. Import appears to run but rows are missing:
- Verify `table_id` in output matches intended target.
- Use `--confirm-table-id` on all mutating CSV imports.

2. Duplicate imports:
- Use `--checkpoint-file`.
- Do not pass `--allow-reimport` unless intentional.

3. Async import interrupted:
- Re-run with same `--checkpoint-file` and `--wait`.
- CLI can resume/poll an in-flight task from checkpoint state.

4. Need to stop a running column job:

```bash
autotouch columns stop --table-id <TABLE_ID> --column-id <COLUMN_ID>
```

---

Full reference (all commands/payload recipes):
`docs/research-table/reference/autotouch-cli.md`
