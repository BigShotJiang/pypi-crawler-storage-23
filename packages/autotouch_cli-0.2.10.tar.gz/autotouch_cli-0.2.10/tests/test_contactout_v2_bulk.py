#!/usr/bin/env python3
"""
ContactOut API v2 Bulk Test - Phone Numbers & Emails
Test script for the new v2 bulk API with async job processing
"""

import os
import sys
import requests
import json
import time
from dotenv import load_dotenv

# Load environment variables
load_dotenv('/Users/nicnicolo/Projects/smart_table/.env')

class ContactOutV2BulkTester:
    def __init__(self):
        self.api_token = os.getenv('CONTACTOUT_API_KEY')
        if not self.api_token:
            print("❌ Error: CONTACTOUT_API_KEY not found in environment variables")
            sys.exit(1)

        self.base_url = "https://api.contactout.com/v2"
        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "token": self.api_token
        }
        print(f"✅ API token loaded: {self.api_token[:8]}...")

    def submit_bulk_job(self, linkedin_profiles, include_phone=True, callback_url=None):
        """Submit a bulk job for LinkedIn profile enrichment"""
        print(f"\n🚀 Submitting bulk job for {len(linkedin_profiles)} profiles")
        print("-" * 60)

        endpoint = f"{self.base_url}/people/linkedin/batch"

        payload = {
            "profiles": linkedin_profiles,
            "include_phone": include_phone
        }

        if callback_url:
            payload["callback_url"] = callback_url

        print(f"📤 Request payload:")
        print(f"  - Profiles: {len(linkedin_profiles)}")
        print(f"  - Include phone: {include_phone}")
        print(f"  - Callback URL: {callback_url if callback_url else 'None'}")

        try:
            response = requests.post(endpoint, headers=self.headers, json=payload)
            print(f"📊 Status Code: {response.status_code}")

            if response.status_code == 200:
                data = response.json()
                job_id = data.get('job_id')
                status = data.get('status')

                print(f"✅ Job submitted successfully!")
                print(f"🆔 Job ID: {job_id}")
                print(f"📋 Status: {status}")

                return job_id
            else:
                print(f"❌ Request failed: {response.text}")
                return None

        except Exception as e:
            print(f"❌ Exception: {str(e)}")
            return None

    def check_job_status(self, job_id, max_wait_time=300, check_interval=10):
        """Check the status of a bulk job and wait for completion"""
        print(f"\n⏳ Checking job status: {job_id}")
        print("-" * 60)

        endpoint = f"{self.base_url}/people/linkedin/batch/{job_id}"
        start_time = time.time()

        while time.time() - start_time < max_wait_time:
            try:
                response = requests.get(endpoint, headers=self.headers)
                print(f"📊 Status Code: {response.status_code}")

                if response.status_code == 200:
                    data = response.json()
                    job_status = data.get('data', {}).get('status', 'UNKNOWN')

                    elapsed = int(time.time() - start_time)
                    print(f"⏱️  Elapsed time: {elapsed}s - Status: {job_status}")

                    if job_status == 'SENT':
                        print("✅ Job completed successfully!")
                        return data
                    elif job_status in ['FAILED', 'ERROR']:
                        print(f"❌ Job failed with status: {job_status}")
                        return data
                    elif job_status == 'QUEUED':
                        print(f"⏳ Job still queued, waiting {check_interval}s...")
                    else:
                        print(f"🔄 Job in progress ({job_status}), waiting {check_interval}s...")

                    time.sleep(check_interval)

                else:
                    print(f"❌ Status check failed: {response.text}")
                    return None

            except Exception as e:
                print(f"❌ Exception checking status: {str(e)}")
                return None

        print(f"⏰ Timeout after {max_wait_time}s")
        return None

    def parse_results(self, job_data):
        """Parse and display the job results"""
        if not job_data or 'data' not in job_data:
            print("❌ No data to parse")
            return

        results = job_data.get('data', {}).get('result', {})

        print(f"\n📋 RESULTS ANALYSIS")
        print("=" * 60)

        total_profiles = len(results)
        profiles_with_phones = 0
        profiles_with_emails = 0
        profiles_with_work_emails = 0
        profiles_with_personal_emails = 0

        for linkedin_url, profile_data in results.items():
            print(f"\n🔍 Profile: {linkedin_url}")
            print("-" * 40)

            # Phone numbers
            phones = profile_data.get('phones', [])
            if phones:
                profiles_with_phones += 1
                print(f"📞 Phone Numbers ({len(phones)}):")
                for phone in phones:
                    print(f"  - {phone}")
            else:
                print("📞 Phone Numbers: None found")

            # All emails
            emails = profile_data.get('emails', [])
            if emails:
                profiles_with_emails += 1
                print(f"📧 All Emails ({len(emails)}):")
                for email in emails:
                    print(f"  - {email}")
            else:
                print("📧 All Emails: None found")

            # Work emails
            work_emails = profile_data.get('work_emails', [])
            if work_emails:
                profiles_with_work_emails += 1
                print(f"💼 Work Emails ({len(work_emails)}):")
                for email in work_emails:
                    print(f"  - {email}")
            else:
                print("💼 Work Emails: None found")

            # Personal emails
            personal_emails = profile_data.get('personal_emails', [])
            if personal_emails:
                profiles_with_personal_emails += 1
                print(f"👤 Personal Emails ({len(personal_emails)}):")
                for email in personal_emails:
                    print(f"  - {email}")
            else:
                print("👤 Personal Emails: None found")

        # Summary statistics
        print(f"\n📊 SUMMARY STATISTICS")
        print("=" * 60)
        print(f"Total Profiles Processed: {total_profiles}")
        print(f"Profiles with Phone Numbers: {profiles_with_phones}/{total_profiles} ({(profiles_with_phones/total_profiles)*100:.1f}%)")
        print(f"Profiles with Any Emails: {profiles_with_emails}/{total_profiles} ({(profiles_with_emails/total_profiles)*100:.1f}%)")
        print(f"Profiles with Work Emails: {profiles_with_work_emails}/{total_profiles} ({(profiles_with_work_emails/total_profiles)*100:.1f}%)")
        print(f"Profiles with Personal Emails: {profiles_with_personal_emails}/{total_profiles} ({(profiles_with_personal_emails/total_profiles)*100:.1f}%)")

    def test_bulk_processing(self, linkedin_profiles):
        """Test the complete bulk processing workflow"""
        print("🚀 ContactOut API v2 Bulk Test")
        print("="*60)

        # Step 1: Submit the job
        job_id = self.submit_bulk_job(linkedin_profiles, include_phone=True)

        if not job_id:
            print("❌ Failed to submit job")
            return False

        # Step 2: Wait for completion and get results
        job_data = self.check_job_status(job_id, max_wait_time=300, check_interval=15)

        if not job_data:
            print("❌ Failed to get job results")
            return False

        # Step 3: Parse and display results
        self.parse_results(job_data)

        return True

def main():
    """Run the bulk API test"""
    # Sample LinkedIn profiles for testing
    test_profiles = [
        "https://linkedin.com/in/williamhgates",  # Bill Gates
        "https://linkedin.com/in/reidhoffman",    # Reid Hoffman
        "https://linkedin.com/in/jeffweiner08"    # Jeff Weiner
    ]

    print("🧪 ContactOut v2 Bulk API Test")
    print(f"Testing with {len(test_profiles)} LinkedIn profiles...")
    print("This test will:")
    print("1. Submit a bulk job for phone and email enrichment")
    print("2. Monitor the job status until completion")
    print("3. Parse and display the results")
    print()

    tester = ContactOutV2BulkTester()
    success = tester.test_bulk_processing(test_profiles)

    if success:
        print("\n✅ Bulk API test completed successfully!")
        print("The ContactOut v2 API is working and can find phone numbers and emails.")
    else:
        print("\n❌ Bulk API test failed. Check your API key and network connection.")

def test_custom_profiles(profiles):
    """Test with custom LinkedIn profiles"""
    print(f"🧪 Testing with {len(profiles)} custom profiles...")

    tester = ContactOutV2BulkTester()
    success = tester.test_bulk_processing(profiles)

    return success

if __name__ == "__main__":
    main()