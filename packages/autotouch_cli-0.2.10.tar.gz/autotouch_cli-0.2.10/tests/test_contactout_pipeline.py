#!/usr/bin/env python3
"""
ContactOut Pipeline End-to-End Test
Test the complete integration: ContactOut API → Lead model → Phone arrays → Computed properties
"""

import os
import sys
import asyncio
import aiohttp
import json
from dotenv import load_dotenv

# Add project root to path
sys.path.insert(0, '/Users/nicnicolo/Projects/smart_table/apps/api')

# Set PYTHONPATH for imports
import sys
import os
os.environ['PYTHONPATH'] = '/Users/nicnicolo/Projects/smart_table/apps/api'

try:
    from models.lead import Lead
    from types.phone_number import PhoneNumber
    from types.email_address import EmailAddress
    from services.phone_providers.contactout import ContactOutPhoneFinder
    from services.phone_normalization_service import PhoneNormalizationService
except ImportError as e:
    print(f"❌ Import error: {e}")
    print("📄 Available modules:")
    print(f"  Current path: {os.getcwd()}")
    print(f"  PYTHONPATH: {sys.path}")
    sys.exit(1)

# Load environment variables
load_dotenv('/Users/nicnicolo/Projects/smart_table/.env')

class ContactOutPipelineTester:
    def __init__(self):
        print("🧪 ContactOut Pipeline End-to-End Test")
        print("=" * 60)

        # Check API key
        api_key = os.getenv('CONTACTOUT_API_KEY')
        if not api_key:
            print("❌ Error: CONTACTOUT_API_KEY not found in .env")
            sys.exit(1)

        print(f"✅ API key loaded: {api_key[:8]}...")

        # Test profiles
        self.test_profiles = [
            {
                "linkedin_url": "https://www.linkedin.com/in/franksondors/",
                "company_domain": "autotouch.ai",
                "first_name": "Frank",
                "last_name": "Sondors"
            },
            {
                "linkedin_url": "https://www.linkedin.com/in/nicholas-nicolo/",
                "company_domain": "autotouch.ai",
                "first_name": "Nicholas",
                "last_name": "Nicolo"
            }
        ]

    async def test_contactout_provider(self):
        """Test ContactOut provider directly"""
        print(f"\n📞 Testing ContactOut Provider")
        print("-" * 40)

        provider = ContactOutPhoneFinder()

        async with aiohttp.ClientSession() as session:
            for profile in self.test_profiles:
                print(f"\n👤 Testing: {profile['first_name']} {profile['last_name']}")
                print(f"🔗 LinkedIn: {profile['linkedin_url']}")

                result = await provider.find_phone(session, linkedin_url=profile['linkedin_url'])

                print(f"📊 Status: {result.status}")
                print(f"💰 Credits Used: {result.credits_used}")

                if result.phone:
                    print(f"📞 Primary Phone: {result.phone}")
                    print(f"📞 Formatted: {result.formatted_phone}")
                    print(f"🌍 Country: {result.country_code}")
                    print(f"📡 Carrier: {result.carrier}")
                    print(f"📱 Type: {result.line_type}")

                    if result.enrichment_data and 'phone_numbers' in result.enrichment_data:
                        phones = result.enrichment_data['phone_numbers']
                        print(f"📞 Total Phones Found: {len(phones)}")
                        for i, phone_data in enumerate(phones, 1):
                            print(f"  {i}. {phone_data['number']} ({phone_data['type']})")
                else:
                    print(f"❌ No phone found: {result.error}")

                # Store result for lead creation test
                profile['contactout_result'] = result

    def test_phone_normalization(self):
        """Test phone normalization service"""
        print(f"\n🔧 Testing Phone Normalization Service")
        print("-" * 40)

        test_phones = [
            "+1 (555) 123-4567",  # US format
            "555-123-4567",       # US without country code
            "+44 20 7946 0958",   # UK format
            "(555) 123 4567",     # US with spaces
            "555.123.4567"        # US with dots
        ]

        for phone in test_phones:
            print(f"\n📞 Input: {phone}")
            result = PhoneNormalizationService.normalize_phone(phone)

            if result['success']:
                print(f"✅ E164: {result['e164_format']}")
                print(f"🌍 International: {result.get('international_format', 'N/A')}")
                print(f"🏠 National: {result.get('national_format', 'N/A')}")
                print(f"🌍 Country: {result.get('region_code', 'N/A')}")
                print(f"📱 Type: {result.get('line_type', 'N/A')}")
            else:
                print(f"❌ Failed: {result.get('error', 'Unknown error')}")

    def test_phone_email_types(self):
        """Test PhoneNumber and EmailAddress types"""
        print(f"\n📋 Testing PhoneNumber and EmailAddress Types")
        print("-" * 40)

        # Test PhoneNumber creation
        phone = PhoneNumber.from_provider_result(
            number="+15551234567",
            provider="contactout",
            formatted="+1 555-123-4567",
            country_code="US",
            line_type="mobile",
            carrier="Verizon",
            verified=True
        )

        print(f"📞 PhoneNumber created:")
        print(f"  Number: {phone.number}")
        print(f"  Display: {phone.display_number}")
        print(f"  Country: {phone.country_code}")
        print(f"  Provider: {phone.provider}")
        print(f"  Mobile: {phone.is_mobile}")
        print(f"  Valid: {phone.is_valid}")

        # Test EmailAddress creation
        email = EmailAddress.from_provider_result(
            address="test@autotouch.ai",
            provider="contactout",
            email_type="work",
            verified=True
        )

        print(f"\n📧 EmailAddress created:")
        print(f"  Address: {email.address}")
        print(f"  Type: {email.email_type}")
        print(f"  Provider: {email.provider}")
        print(f"  Work Email: {email.is_work_email}")
        print(f"  Valid: {email.is_valid}")

    def test_lead_creation_with_arrays(self):
        """Test Lead creation with phone and email arrays"""
        print(f"\n👤 Testing Lead Creation with Arrays")
        print("-" * 40)

        # Create test phone numbers
        phone_numbers = [
            PhoneNumber.from_provider_result(
                number="+15551234567",
                provider="contactout",
                formatted="+1 555-123-4567",
                country_code="US",
                line_type="mobile"
            ),
            PhoneNumber.from_provider_result(
                number="+15559876543",
                provider="contactout",
                formatted="+1 555-987-6543",
                country_code="US",
                line_type="landline"
            )
        ]

        # Create test email addresses
        email_addresses = [
            EmailAddress.from_provider_result(
                address="test@autotouch.ai",
                provider="contactout",
                email_type="work"
            ),
            EmailAddress.from_provider_result(
                address="test.personal@gmail.com",
                provider="contactout",
                email_type="personal"
            )
        ]

        # Create lead with arrays
        lead_data = {
            "company_domain": "autotouch.ai",
            "linkedin_url": "https://www.linkedin.com/in/test-user/",
            "first_name": "Test",
            "last_name": "User",
            "phone_numbers": phone_numbers,
            "email_addresses": email_addresses,
            "company_name": "AutoTouch AI",
            "title": "Software Engineer",
            "created_by": "test_user_id",
            "organization_id": "test_org_id"
        }

        try:
            lead = Lead(**lead_data)
            print(f"✅ Lead created successfully!")
            print(f"👤 Name: {lead.full_name}")
            print(f"🏢 Company: {lead.company_name} ({lead.company_domain})")
            print(f"🔗 LinkedIn: {lead.linkedin_url}")

            # Test computed properties
            print(f"\n📞 Primary Phone: {lead.primary_phone}")
            print(f"📧 Business Email: {lead.business_email}")
            print(f"🌐 Domain from Email: {lead.domain_from_email}")

            # Test phone array access
            print(f"\n📞 All Phone Numbers ({len(lead.phone_numbers)}):")
            for i, phone in enumerate(lead.phone_numbers, 1):
                print(f"  {i}. {phone.display_number} ({phone.line_type}) - {phone.provider}")

            # Test email array access
            print(f"\n📧 All Email Addresses ({len(lead.email_addresses)}):")
            for i, email in enumerate(lead.email_addresses, 1):
                print(f"  {i}. {email.address} ({email.email_type}) - {email.provider}")

            # Test deduplication hash
            dedup_hash, dedup_info = Lead.generate_dedup_hash(
                lead.linkedin_url,
                lead.company_domain,
                lead.organization_id
            )
            print(f"\n🔒 Dedup Hash: {dedup_hash}")
            print(f"🔒 Dedup Strategy: {dedup_info['strategy'] if dedup_info else 'None'}")

            # Test serialization
            lead_dict = lead.to_dict()
            print(f"\n💾 Serialized to dict with {len(lead_dict)} fields")

            return lead

        except Exception as e:
            print(f"❌ Lead creation failed: {str(e)}")
            return None

    async def test_complete_pipeline(self):
        """Test the complete pipeline from ContactOut to Lead model"""
        print(f"\n🔄 Testing Complete Pipeline")
        print("-" * 40)

        provider = ContactOutPhoneFinder()

        async with aiohttp.ClientSession() as session:
            for profile_data in self.test_profiles:
                print(f"\n👤 Processing: {profile_data['first_name']} {profile_data['last_name']}")

                # Step 1: Get phone from ContactOut
                contactout_result = await provider.find_phone(
                    session,
                    linkedin_url=profile_data['linkedin_url']
                )

                if not contactout_result.phone:
                    print(f"❌ No phone found, skipping lead creation")
                    continue

                # Step 2: Convert ContactOut result to PhoneNumber objects
                phone_numbers = []
                if contactout_result.enrichment_data and 'phone_numbers' in contactout_result.enrichment_data:
                    for phone_data in contactout_result.enrichment_data['phone_numbers']:
                        phone_numbers.append(PhoneNumber(
                            number=phone_data['number'],
                            formatted=phone_data.get('formatted'),
                            country_code=phone_data.get('country'),
                            line_type=phone_data.get('type', 'mobile'),
                            carrier=phone_data.get('carrier'),
                            verified=phone_data.get('verified', True),
                            provider=phone_data['provider'],
                            found_at=phone_data.get('found_at'),
                            is_mobile=phone_data.get('type') == 'mobile'
                        ))
                else:
                    # Fallback - create from primary result
                    phone_numbers.append(PhoneNumber(
                        number=contactout_result.phone,
                        formatted=contactout_result.formatted_phone,
                        country_code=contactout_result.country_code,
                        line_type=contactout_result.line_type or 'mobile',
                        carrier=contactout_result.carrier,
                        verified=True,
                        provider=contactout_result.provider,
                        is_mobile=contactout_result.line_type == 'mobile'
                    ))

                # Step 3: Create lead with phone arrays
                try:
                    import_data = {
                        **profile_data,
                        'phone_numbers': phone_numbers,
                        'email_addresses': []  # Empty for this test
                    }

                    lead = Lead.from_import_data(
                        import_data=import_data,
                        created_by_user_id="test_user",
                        organization_id="test_org"
                    )

                    print(f"✅ Lead created from ContactOut data!")
                    print(f"📞 Primary Phone: {lead.primary_phone}")
                    print(f"📞 Total Phones: {len(lead.phone_numbers)}")
                    print(f"🔗 LinkedIn: {lead.linkedin_url}")
                    print(f"🏢 Company: {lead.company_domain}")

                    # Verify computed properties work
                    assert lead.primary_phone is not None, "Primary phone should not be None"
                    assert len(lead.phone_numbers) > 0, "Should have at least one phone number"

                    print(f"✅ All assertions passed!")

                except Exception as e:
                    print(f"❌ Lead creation from ContactOut failed: {str(e)}")

    async def run_all_tests(self):
        """Run all pipeline tests"""
        print("🚀 Starting ContactOut Pipeline Tests")
        print("=" * 60)

        try:
            # Test 1: Phone normalization
            self.test_phone_normalization()

            # Test 2: Phone/Email types
            self.test_phone_email_types()

            # Test 3: Lead creation with arrays
            lead = self.test_lead_creation_with_arrays()

            # Test 4: ContactOut provider
            await self.test_contactout_provider()

            # Test 5: Complete pipeline
            await self.test_complete_pipeline()

            print(f"\n🎉 ALL TESTS COMPLETED!")
            print("=" * 60)
            print("✅ Phone normalization working")
            print("✅ PhoneNumber/EmailAddress types working")
            print("✅ Lead model with arrays working")
            print("✅ ContactOut provider working")
            print("✅ Complete pipeline working")

        except Exception as e:
            print(f"\n❌ Test suite failed: {str(e)}")
            raise

async def main():
    """Run the complete test suite"""
    tester = ContactOutPipelineTester()
    await tester.run_all_tests()

if __name__ == "__main__":
    asyncio.run(main())