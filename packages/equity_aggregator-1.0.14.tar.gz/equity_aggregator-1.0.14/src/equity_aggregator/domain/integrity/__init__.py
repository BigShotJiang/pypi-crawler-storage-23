# integrity/__init__.py

from .analyse import analyse_canonical_equities

__all__ = [
    "analyse_canonical_equities",
]
