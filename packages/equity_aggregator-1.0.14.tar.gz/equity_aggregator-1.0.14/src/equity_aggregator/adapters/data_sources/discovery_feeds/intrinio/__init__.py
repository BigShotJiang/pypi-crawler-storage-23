# intrinio/__init__.py

from .intrinio import fetch_equity_records

__all__ = [
    "fetch_equity_records",
]
