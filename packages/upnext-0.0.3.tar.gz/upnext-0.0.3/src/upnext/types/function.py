"""Function identity types."""

from typing import Literal

FunctionKind = Literal["task", "cron", "event"]
