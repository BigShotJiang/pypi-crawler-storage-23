"""Task utilities for UpNext."""

from dataclasses import dataclass
from datetime import datetime
from typing import Any, cast

from shared.domain import FailureReason, JobStatus

from upnext.engine.queue.base import BaseQueue


@dataclass
class TaskResult[T]:
    """
    Result of a successful task execution.

    Example:
        result = await my_task.wait(order_id="123")
        print(result.value)
    """

    value: T
    """The return value from the task."""

    job_id: str
    """Unique identifier for this job execution."""

    function: str
    """Stable function key that was executed."""

    function_name: str
    """Human-readable function name."""

    status: JobStatus = JobStatus.COMPLETE
    """Final status of the job."""

    error: str | None = None
    """Error message if the task failed."""

    failure_reason: FailureReason | None = None
    """Structured failure reason (timeout, exception, cancelled, unknown)."""

    started_at: datetime | None = None
    """When the job started executing."""

    completed_at: datetime | None = None
    """When the job completed."""

    attempts: int = 1
    """Number of attempts (including retries) it took to complete."""

    parent_id: str | None = None
    """Parent job ID if this was spawned from another task."""

    root_id: str = ""
    """Root job ID for the execution lineage."""

    @property
    def ok(self) -> bool:
        """Whether the task completed successfully."""
        return self.status == JobStatus.COMPLETE


class Future[T]:
    """
    Represents a pending job result.

    Use `.result()` to wait for the job to complete and get the result.
    """

    def __init__(self, job_id: str, queue: "BaseQueue") -> None:
        self._job_id = job_id
        self._queue = queue

    @property
    def job_id(self) -> str:
        """Get the job ID."""
        return self._job_id

    async def result(self, timeout: float | None = None) -> TaskResult[T]:
        """
        Wait for the job to complete and return the result.

        Args:
            timeout: Maximum time to wait in seconds (None waits indefinitely)

        Returns:
            TaskResult containing the value, status, and execution metadata

        Raises:
            TimeoutError: If timeout reached before completion
            TaskTimeoutError: If the task failed due to a timeout during execution
            TaskExecutionError: If the task completed with failed/cancelled status
        """
        status = await self._queue.subscribe_job(self._job_id, timeout=timeout)
        job = await self._queue.get_job(self._job_id)
        if not job:
            raise RuntimeError(f"Job {self._job_id} not found after completion")

        task_result = TaskResult(
            value=cast(T, job.result),
            job_id=job.id,
            function=job.function,
            function_name=job.function_name,
            status=JobStatus(status),
            error=job.error,
            failure_reason=job.failure_reason,
            started_at=job.started_at,
            completed_at=job.completed_at,
            attempts=job.attempts,
            parent_id=job.parent_id,
            root_id=job.root_id,
        )
        if not task_result.ok:
            if task_result.failure_reason == FailureReason.TIMEOUT:
                raise TaskTimeoutError(task_result)
            raise TaskExecutionError(task_result)
        return task_result

    async def value(self, timeout: float | None = None) -> T:
        """
        Wait for completion and return only the task value.

        Args:
            timeout: Maximum time to wait in seconds (None waits indefinitely)

        Returns:
            The task return value, typed to the original task return type

        Raises:
            TimeoutError: If timeout reached before completion
            TaskTimeoutError: If the task failed due to a timeout during execution
            TaskExecutionError: If the task completed with failed/cancelled status
        """
        return _require_task_value(await self.result(timeout=timeout))

    async def cancel(self) -> bool:
        """
        Cancel the job.

        Returns:
            True if cancelled, False if already complete
        """
        return await self._queue.cancel(self._job_id)


class TaskExecutionError(RuntimeError):
    """Raised when a task finishes with failed/cancelled status."""

    def __init__(self, task_result: TaskResult[Any]) -> None:
        self.task_result = task_result
        self.job_id = task_result.job_id
        self.status = task_result.status
        self.error = task_result.error
        message = self.error or (
            f"Job {self.job_id} completed with non-success status '{self.status}'"
        )
        super().__init__(message)


class TaskTimeoutError(TaskExecutionError):
    """Raised when a task exceeds its configured timeout."""

    pass


def _require_task_value[T](task_result: TaskResult[T]) -> T:
    """Extract task value from a successful TaskResult."""
    return cast(T, task_result.value)
