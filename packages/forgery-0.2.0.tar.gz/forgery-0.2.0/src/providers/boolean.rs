//! Boolean generation provider.
//!
//! Generates random boolean values with configurable probability.

use crate::rng::ForgeryRng;
use std::fmt;

/// Error when probability value is outside the valid range [0.0, 1.0].
#[derive(Debug, Clone)]
pub struct ProbabilityError {
    /// The invalid probability value.
    pub value: f64,
}

impl fmt::Display for ProbabilityError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "probability must be between 0.0 and 1.0 (inclusive), got {}",
            self.value
        )
    }
}

impl std::error::Error for ProbabilityError {}

/// Generate a batch of random booleans with a given probability of `true`.
///
/// # Arguments
///
/// * `rng` - The random number generator to use
/// * `n` - Number of booleans to generate
/// * `probability` - Probability of `true` (0.0 = always false, 1.0 = always true)
///
/// # Errors
///
/// Returns `ProbabilityError` if probability is not in [0.0, 1.0] or is NaN.
pub fn generate_booleans(
    rng: &mut ForgeryRng,
    n: usize,
    probability: f64,
) -> Result<Vec<bool>, ProbabilityError> {
    validate_probability(probability)?;

    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_boolean_unchecked(rng, probability));
    }
    Ok(results)
}

/// Generate a single random boolean with a given probability of `true`.
///
/// # Errors
///
/// Returns `ProbabilityError` if probability is not in [0.0, 1.0] or is NaN.
#[inline]
pub fn generate_boolean(rng: &mut ForgeryRng, probability: f64) -> Result<bool, ProbabilityError> {
    validate_probability(probability)?;
    Ok(generate_boolean_unchecked(rng, probability))
}

/// Generate a random boolean with the default 50/50 probability.
///
/// This is a convenience function that cannot fail, used internally by the
/// records schema system where probability is always 0.5.
#[inline]
pub fn generate_boolean_default(rng: &mut ForgeryRng) -> bool {
    generate_boolean_unchecked(rng, 0.5)
}

/// Generate a boolean without validating probability (internal use after validation).
#[inline]
fn generate_boolean_unchecked(rng: &mut ForgeryRng, probability: f64) -> bool {
    if probability == 0.0 {
        return false;
    }
    if probability == 1.0 {
        return true;
    }
    rng.gen_range(0.0f64, 1.0f64) < probability
}

/// Validate that probability is in [0.0, 1.0] and is finite.
#[inline]
fn validate_probability(probability: f64) -> Result<(), ProbabilityError> {
    if !probability.is_finite() || !(0.0..=1.0).contains(&probability) {
        return Err(ProbabilityError { value: probability });
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_boolean_default_probability() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let results = generate_booleans(&mut rng, 10000, 0.5).unwrap();
        let true_count = results.iter().filter(|&&b| b).count();
        // Should be roughly 50% true (allow wide margin for randomness)
        assert!(true_count > 4000, "too few true values: {}", true_count);
        assert!(true_count < 6000, "too many true values: {}", true_count);
    }

    #[test]
    fn test_boolean_always_true() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let results = generate_booleans(&mut rng, 100, 1.0).unwrap();
        assert!(results.iter().all(|&b| b));
    }

    #[test]
    fn test_boolean_always_false() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let results = generate_booleans(&mut rng, 100, 0.0).unwrap();
        assert!(results.iter().all(|&b| !b));
    }

    #[test]
    fn test_boolean_high_probability() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let results = generate_booleans(&mut rng, 10000, 0.9).unwrap();
        let true_count = results.iter().filter(|&&b| b).count();
        assert!(true_count > 8500, "too few true values: {}", true_count);
    }

    #[test]
    fn test_boolean_low_probability() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let results = generate_booleans(&mut rng, 10000, 0.1).unwrap();
        let true_count = results.iter().filter(|&&b| b).count();
        assert!(true_count < 1500, "too many true values: {}", true_count);
    }

    #[test]
    fn test_invalid_probability_negative() {
        let mut rng = ForgeryRng::new();
        let result = generate_boolean(&mut rng, -0.1);
        assert!(result.is_err());
        assert!(result.unwrap_err().to_string().contains("-0.1"));
    }

    #[test]
    fn test_invalid_probability_over_one() {
        let mut rng = ForgeryRng::new();
        let result = generate_boolean(&mut rng, 1.1);
        assert!(result.is_err());
    }

    #[test]
    fn test_invalid_probability_nan() {
        let mut rng = ForgeryRng::new();
        let result = generate_boolean(&mut rng, f64::NAN);
        assert!(result.is_err());
    }

    #[test]
    fn test_invalid_probability_infinity() {
        let mut rng = ForgeryRng::new();
        let result = generate_boolean(&mut rng, f64::INFINITY);
        assert!(result.is_err());
    }

    #[test]
    fn test_batch_sizes() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        assert_eq!(generate_booleans(&mut rng, 0, 0.5).unwrap().len(), 0);
        assert_eq!(generate_booleans(&mut rng, 1, 0.5).unwrap().len(), 1);
        assert_eq!(generate_booleans(&mut rng, 100, 0.5).unwrap().len(), 100);
    }

    #[test]
    fn test_deterministic_with_seed() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        let results1 = generate_booleans(&mut rng1, 100, 0.5).unwrap();
        let results2 = generate_booleans(&mut rng2, 100, 0.5).unwrap();
        assert_eq!(results1, results2);
    }

    #[test]
    fn test_single_boolean() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        // Verify single boolean generation works without error
        let _val: bool = generate_boolean(&mut rng, 0.5).unwrap();
    }

    #[test]
    fn test_boundary_probabilities() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        // Exact boundaries should work
        assert!(generate_boolean(&mut rng, 0.0).is_ok());
        assert!(generate_boolean(&mut rng, 1.0).is_ok());
    }
}

#[cfg(test)]
mod proptest_tests {
    use super::*;
    use proptest::prelude::*;

    proptest! {
        #[test]
        fn prop_batch_size_respected(n in 0usize..1000) {
            let mut rng = ForgeryRng::new();
            rng.seed(42);

            let bools = generate_booleans(&mut rng, n, 0.5).unwrap();
            prop_assert_eq!(bools.len(), n);
        }

        #[test]
        fn prop_valid_probability_succeeds(p in 0.0f64..=1.0f64) {
            let mut rng = ForgeryRng::new();
            rng.seed(42);

            let result = generate_boolean(&mut rng, p);
            prop_assert!(result.is_ok());
        }

        #[test]
        fn prop_invalid_probability_over_one_fails(p in 1.001f64..1000.0f64) {
            let mut rng = ForgeryRng::new();
            let result = generate_boolean(&mut rng, p);
            prop_assert!(result.is_err());
        }

        #[test]
        fn prop_invalid_probability_negative_fails(p in -1000.0f64..-0.001f64) {
            let mut rng = ForgeryRng::new();
            let result = generate_boolean(&mut rng, p);
            prop_assert!(result.is_err());
        }

        #[test]
        fn prop_seed_determinism(seed_val in any::<u64>(), n in 1usize..100) {
            let mut rng1 = ForgeryRng::new();
            let mut rng2 = ForgeryRng::new();
            rng1.seed(seed_val);
            rng2.seed(seed_val);

            let bools1 = generate_booleans(&mut rng1, n, 0.5).unwrap();
            let bools2 = generate_booleans(&mut rng2, n, 0.5).unwrap();
            prop_assert_eq!(bools1, bools2);
        }
    }
}
