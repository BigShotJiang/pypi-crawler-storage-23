//! Vehicle/automotive data generation provider.
//!
//! Generates license plates (locale-specific), vehicle makes, models,
//! years, and VINs with valid check digits.

use crate::locale::Locale;
use crate::rng::ForgeryRng;
use crate::validate_batch_size;
use crate::BatchSizeError;

/// Vehicle makes and their associated models.
const VEHICLES: &[(&str, &[&str])] = &[
    (
        "Toyota",
        &["Camry", "Corolla", "RAV4", "Highlander", "Tacoma", "Prius"],
    ),
    (
        "Honda",
        &["Civic", "Accord", "CR-V", "Pilot", "Odyssey", "Fit"],
    ),
    (
        "Ford",
        &["F-150", "Mustang", "Explorer", "Escape", "Bronco", "Ranger"],
    ),
    (
        "Chevrolet",
        &[
            "Silverado",
            "Malibu",
            "Equinox",
            "Tahoe",
            "Camaro",
            "Corvette",
        ],
    ),
    (
        "BMW",
        &["3 Series", "5 Series", "X3", "X5", "7 Series", "X1"],
    ),
    (
        "Mercedes-Benz",
        &["C-Class", "E-Class", "S-Class", "GLC", "GLE", "A-Class"],
    ),
    ("Audi", &["A3", "A4", "A6", "Q5", "Q7", "e-tron"]),
    (
        "Volkswagen",
        &["Golf", "Jetta", "Tiguan", "Passat", "Atlas", "ID.4"],
    ),
    (
        "Nissan",
        &[
            "Altima",
            "Sentra",
            "Rogue",
            "Pathfinder",
            "Frontier",
            "Leaf",
        ],
    ),
    (
        "Hyundai",
        &["Elantra", "Sonata", "Tucson", "Santa Fe", "Kona", "Ioniq"],
    ),
    (
        "Kia",
        &["Forte", "K5", "Sportage", "Telluride", "Sorento", "EV6"],
    ),
    (
        "Subaru",
        &[
            "Outback",
            "Forester",
            "Crosstrek",
            "Impreza",
            "WRX",
            "Legacy",
        ],
    ),
    (
        "Tesla",
        &["Model 3", "Model Y", "Model S", "Model X", "Cybertruck"],
    ),
    (
        "Mazda",
        &["Mazda3", "CX-5", "CX-30", "MX-5", "CX-50", "CX-9"],
    ),
    (
        "Jeep",
        &[
            "Wrangler",
            "Grand Cherokee",
            "Cherokee",
            "Compass",
            "Gladiator",
        ],
    ),
    ("Lexus", &["ES", "RX", "NX", "IS", "UX", "GX"]),
    ("Volvo", &["XC60", "XC90", "S60", "V60", "XC40", "S90"]),
    (
        "Porsche",
        &["911", "Cayenne", "Macan", "Taycan", "Panamera", "718"],
    ),
    (
        "Land Rover",
        &["Range Rover", "Defender", "Discovery", "Evoque", "Velar"],
    ),
    ("Fiat", &["500", "Panda", "Tipo", "500X", "Ducato"]),
];

/// Valid characters for VIN (no I, O, Q).
const VIN_CHARS: &[u8] = b"ABCDEFGHJKLMNPRSTUVWXYZ0123456789";

/// VIN transliteration values for check digit computation.
fn vin_transliterate(c: char) -> u32 {
    match c {
        'A' | 'J' => 1,
        'B' | 'K' | 'S' => 2,
        'C' | 'L' | 'T' => 3,
        'D' | 'M' | 'U' => 4,
        'E' | 'N' | 'V' => 5,
        'F' | 'W' => 6,
        'G' | 'P' | 'X' => 7,
        'H' | 'Y' => 8,
        'R' | 'Z' => 9,
        d if d.is_ascii_digit() => d.to_digit(10).unwrap_or(0),
        _ => 0,
    }
}

/// VIN position weights (positions 1-17, but position 9 is the check digit).
const VIN_WEIGHTS: &[u32] = &[8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2];

/// Generate a single random vehicle make.
pub fn generate_vehicle_make(rng: &mut ForgeryRng) -> String {
    let (make, _) = rng.choose(VEHICLES);
    (*make).to_string()
}

/// Generate a batch of random vehicle makes.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_vehicle_makes(
    rng: &mut ForgeryRng,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_vehicle_make(rng));
    }
    Ok(results)
}

/// Generate a single random vehicle model.
pub fn generate_vehicle_model(rng: &mut ForgeryRng) -> String {
    let (_, models) = rng.choose(VEHICLES);
    rng.choose(models).to_string()
}

/// Generate a batch of random vehicle models.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_vehicle_models(
    rng: &mut ForgeryRng,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_vehicle_model(rng));
    }
    Ok(results)
}

/// Fixed reference year for deterministic vehicle year generation.
/// Model years go up to reference year + 1 (since manufacturers release
/// next year's models mid-year). Uses the same approach as `date_of_birth`
/// with its fixed reference date of 2024-01-01.
const REFERENCE_YEAR: i64 = 2024;

/// Generate a single random vehicle year (1990 to REFERENCE_YEAR + 1).
///
/// # Determinism Note
///
/// This function uses a fixed reference year of 2024 to ensure reproducible
/// output with the same seed. The upper bound is 2025 (reference year + 1)
/// since manufacturers release next year's models mid-year.
pub fn generate_vehicle_year(rng: &mut ForgeryRng) -> i64 {
    rng.gen_range(1990i64, REFERENCE_YEAR + 1)
}

/// Generate a batch of random vehicle years.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_vehicle_years(rng: &mut ForgeryRng, n: usize) -> Result<Vec<i64>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_vehicle_year(rng));
    }
    Ok(results)
}

/// Generate a single VIN (Vehicle Identification Number) with valid check digit.
///
/// VIN is 17 characters. Position 9 is a check digit (0-9 or X).
/// No I, O, or Q characters allowed.
pub fn generate_vin(rng: &mut ForgeryRng) -> String {
    let mut vin = Vec::with_capacity(17);

    // Generate 17 random characters (we'll fix position 9 later)
    for _ in 0..17 {
        let c = *rng.choose(VIN_CHARS);
        vin.push(c as char);
    }

    // Calculate check digit for position 9 (index 8)
    // Temporarily set position 9 to '0' for calculation
    vin[8] = '0';
    let mut sum: u32 = 0;
    for (i, &c) in vin.iter().enumerate() {
        if i == 8 {
            continue; // Skip check digit position
        }
        sum += vin_transliterate(c) * VIN_WEIGHTS[i];
    }
    let remainder = sum % 11;
    let check_char = if remainder == 10 {
        'X'
    } else {
        char::from_digit(remainder, 10).unwrap_or('0')
    };
    vin[8] = check_char;

    vin.into_iter().collect()
}

/// Generate a batch of VINs.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_vins(rng: &mut ForgeryRng, n: usize) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_vin(rng));
    }
    Ok(results)
}

/// Generate a single locale-specific license plate.
pub fn generate_license_plate(rng: &mut ForgeryRng, locale: Locale) -> String {
    match locale {
        Locale::EnUS => generate_us_plate(rng),
        Locale::EnGB => generate_uk_plate(rng),
        Locale::DeDE => generate_de_plate(rng),
        Locale::FrFR => generate_fr_plate(rng),
        Locale::EsES => generate_es_plate(rng),
        Locale::ItIT => generate_it_plate(rng),
        Locale::JaJP => generate_jp_plate(rng),
    }
}

/// Generate a batch of locale-specific license plates.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_license_plates(
    rng: &mut ForgeryRng,
    locale: Locale,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_license_plate(rng, locale));
    }
    Ok(results)
}

/// US: ABC-1234
fn generate_us_plate(rng: &mut ForgeryRng) -> String {
    let l1 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let l2 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let l3 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let num: u16 = rng.gen_range(1000, 9999);
    format!("{}{}{}-{}", l1, l2, l3, num)
}

/// UK: AB12 CDE
fn generate_uk_plate(rng: &mut ForgeryRng) -> String {
    let l1 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let l2 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let d1: u8 = rng.gen_range(0, 9);
    let d2: u8 = rng.gen_range(0, 9);
    let l3 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let l4 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let l5 = (b'A' + rng.gen_range(0u8, 25)) as char;
    format!("{}{}{}{} {}{}{}", l1, l2, d1, d2, l3, l4, l5)
}

/// Germany: B AB 1234
fn generate_de_plate(rng: &mut ForgeryRng) -> String {
    // 1-3 letter city code
    let city_len: usize = rng.gen_range(1usize, 3);
    let mut city = String::new();
    for _ in 0..city_len {
        city.push((b'A' + rng.gen_range(0u8, 25)) as char);
    }
    // 1-2 letter identifier
    let id_len: usize = rng.gen_range(1usize, 2);
    let mut id = String::new();
    for _ in 0..id_len {
        id.push((b'A' + rng.gen_range(0u8, 25)) as char);
    }
    // 1-4 digit number
    let num: u16 = rng.gen_range(1, 9999);
    format!("{} {} {}", city, id, num)
}

/// France: AA-123-AA
fn generate_fr_plate(rng: &mut ForgeryRng) -> String {
    let l1 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let l2 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let num: u16 = rng.gen_range(100, 999);
    let l3 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let l4 = (b'A' + rng.gen_range(0u8, 25)) as char;
    format!("{}{}-{}-{}{}", l1, l2, num, l3, l4)
}

/// Valid consonants for Spanish license plates (since 2000 system).
/// Excludes vowels (A, E, I, O, U), Ñ, and Q.
const ES_PLATE_LETTERS: &[u8] = b"BCDFGHJKLMNPRSTVWXYZ";

/// Spain: 1234 BCD
fn generate_es_plate(rng: &mut ForgeryRng) -> String {
    let num: u16 = rng.gen_range(0, 9999);
    let l1 = *rng.choose(ES_PLATE_LETTERS) as char;
    let l2 = *rng.choose(ES_PLATE_LETTERS) as char;
    let l3 = *rng.choose(ES_PLATE_LETTERS) as char;
    format!("{:04} {}{}{}", num, l1, l2, l3)
}

/// Italy: AB 123 CD
fn generate_it_plate(rng: &mut ForgeryRng) -> String {
    let l1 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let l2 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let num: u16 = rng.gen_range(100, 999);
    let l3 = (b'A' + rng.gen_range(0u8, 25)) as char;
    let l4 = (b'A' + rng.gen_range(0u8, 25)) as char;
    format!("{}{} {} {}{}", l1, l2, num, l3, l4)
}

/// Japan: 品川 300 あ 12-34
fn generate_jp_plate(rng: &mut ForgeryRng) -> String {
    let class: u16 = rng.gen_range(100, 999);
    let d1: u8 = rng.gen_range(0, 9);
    let d2: u8 = rng.gen_range(0, 9);
    let d3: u8 = rng.gen_range(0, 9);
    let d4: u8 = rng.gen_range(0, 9);
    // Use a simplified format with class number and 4-digit number
    format!("{} {}{}-{}{}", class, d1, d2, d3, d4)
}

/// Validate a VIN check digit.
#[allow(dead_code)]
pub fn validate_vin(vin: &str) -> bool {
    if vin.len() != 17 {
        return false;
    }
    let chars: Vec<char> = vin.chars().collect();

    // No I, O, Q
    if chars.iter().any(|&c| c == 'I' || c == 'O' || c == 'Q') {
        return false;
    }

    let mut sum: u32 = 0;
    for (i, &c) in chars.iter().enumerate() {
        if i == 8 {
            continue;
        }
        sum += vin_transliterate(c) * VIN_WEIGHTS[i];
    }
    let remainder = sum % 11;
    let expected = if remainder == 10 {
        'X'
    } else {
        char::from_digit(remainder, 10).unwrap_or('0')
    };
    chars[8] == expected
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_vehicle_make() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let make = generate_vehicle_make(&mut rng);
            assert!(
                VEHICLES.iter().any(|(m, _)| *m == make),
                "Unknown make: {}",
                make
            );
        }
    }

    #[test]
    fn test_vehicle_model() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let model = generate_vehicle_model(&mut rng);
            assert!(
                VEHICLES
                    .iter()
                    .any(|(_, models)| models.contains(&model.as_str())),
                "Unknown model: {}",
                model
            );
        }
    }

    #[test]
    fn test_vehicle_year() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let year = generate_vehicle_year(&mut rng);
            assert!((1990..=2025).contains(&year), "Out of range: {}", year);
        }
    }

    #[test]
    fn test_vin_format_and_check() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let vin = generate_vin(&mut rng);
            assert_eq!(vin.len(), 17, "Wrong VIN length: {}", vin);
            assert!(
                !vin.contains('I') && !vin.contains('O') && !vin.contains('Q'),
                "VIN contains I/O/Q: {}",
                vin
            );
            assert!(validate_vin(&vin), "Invalid VIN check: {}", vin);
        }
    }

    #[test]
    fn test_us_plate_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let plate = generate_license_plate(&mut rng, Locale::EnUS);
        // ABC-1234
        assert_eq!(plate.len(), 8);
        assert_eq!(plate.chars().nth(3).unwrap(), '-');
    }

    #[test]
    fn test_uk_plate_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let plate = generate_license_plate(&mut rng, Locale::EnGB);
        // AB12 CDE
        assert_eq!(plate.len(), 8);
        assert_eq!(plate.chars().nth(4).unwrap(), ' ');
    }

    #[test]
    fn test_batch_sizes() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        assert_eq!(generate_vehicle_makes(&mut rng, 0).unwrap().len(), 0);
        assert_eq!(generate_vehicle_makes(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_vehicle_models(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_vehicle_years(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_vins(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(
            generate_license_plates(&mut rng, Locale::EnUS, 50)
                .unwrap()
                .len(),
            50
        );
    }

    #[test]
    fn test_determinism() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        assert_eq!(generate_vin(&mut rng1), generate_vin(&mut rng2));
    }
}
