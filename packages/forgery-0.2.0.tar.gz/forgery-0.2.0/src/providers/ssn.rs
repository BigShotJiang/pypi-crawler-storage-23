//! SSN / National ID generation provider.
//!
//! Generates locale-specific national identification numbers.
//! Each locale has its own format and validation rules.

use crate::locale::Locale;
use crate::rng::ForgeryRng;
use crate::validate_batch_size;
use crate::BatchSizeError;

/// Generate a single national ID number for the given locale.
pub fn generate_ssn(rng: &mut ForgeryRng, locale: Locale) -> String {
    match locale {
        Locale::EnUS => generate_us_ssn(rng),
        Locale::EnGB => generate_uk_nino(rng),
        Locale::DeDE => generate_de_steuerid(rng),
        Locale::FrFR => generate_fr_nss(rng),
        Locale::EsES => generate_es_dni(rng),
        Locale::ItIT => generate_it_codice_fiscale(rng),
        Locale::JaJP => generate_jp_my_number(rng),
    }
}

/// Generate a batch of national ID numbers.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_ssns(
    rng: &mut ForgeryRng,
    locale: Locale,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_ssn(rng, locale));
    }
    Ok(results)
}

// === US SSN: XXX-XX-XXXX ===

/// Generate a US Social Security Number.
///
/// Area: 001-899 (excluding 666), Group: 01-99, Serial: 0001-9999.
fn generate_us_ssn(rng: &mut ForgeryRng) -> String {
    let mut area: u16 = rng.gen_range(1, 899);
    if area == 666 {
        area = 667;
    }
    let group: u8 = rng.gen_range(1, 99);
    let serial: u16 = rng.gen_range(1, 9999);
    format!("{:03}-{:02}-{:04}", area, group, serial)
}

// === UK National Insurance Number: AB 12 34 56 C ===

/// Valid NI number prefix pairs (first two letters).
const NI_PREFIXES: &[&str] = &[
    "AA", "AB", "AE", "AH", "AK", "AL", "AM", "AP", "AR", "AS", "AT", "AW", "AX", "AY", "AZ", "BA",
    "BB", "BE", "BH", "BK", "BL", "BM", "CA", "CB", "CE", "CH", "CK", "CL", "CR", "EA", "EB", "EE",
    "EH", "EK", "EL", "EM", "EP", "ER", "ES", "ET", "EW", "EX", "EY", "HA", "HB", "HE", "HH", "HK",
    "HL", "HM", "HP", "HR", "HS", "HT", "HW", "HX", "HY", "JA", "JB", "JC", "JE", "JG", "JH", "JK",
    "JL", "JM", "JN", "JP", "JR", "JS", "JT", "JW", "JX", "JY", "JZ", "KA", "KB", "KE", "KH", "KK",
    "KL", "KM", "LA", "LB", "LE", "LH", "LK", "LL", "LM", "LP", "LR", "LS", "LT", "LW", "LX", "LY",
    "MA", "MW", "MX", "NA", "NB", "NE", "NH", "NK", "NL", "NM", "NP", "NR", "NS", "NW", "NX", "NY",
    "NZ", "OA", "OB", "OE", "OH", "OK", "OL", "OM", "OP", "OR", "PA", "PB", "PC", "PE", "PG", "PH",
    "PK", "PL", "PM", "PN", "PP", "PR", "PS", "PT", "PW", "PX", "PY", "RA", "RB", "RE", "RH", "RK",
    "RM", "RP", "RR", "RS", "RT", "RW", "RX", "RY", "RZ", "SA", "SB", "SC", "SE", "SG", "SH", "SK",
    "SL", "SM", "SN", "SP", "SR", "SS", "ST", "SW", "SX", "SY", "SZ", "WA", "WB", "WE", "WK", "WL",
    "WM", "WP", "YA", "YB", "YE", "YH", "YK", "YL", "YM", "YP", "YR", "YS", "YT", "YW", "YX", "YY",
    "ZA", "ZB", "ZE", "ZH", "ZK", "ZL", "ZM", "ZP", "ZR", "ZS", "ZT", "ZW", "ZX", "ZY",
];

/// NI number suffix letters.
const NI_SUFFIXES: &[char] = &['A', 'B', 'C', 'D'];

/// Generate a UK National Insurance number.
fn generate_uk_nino(rng: &mut ForgeryRng) -> String {
    let prefix = rng.choose(NI_PREFIXES);
    let d1: u8 = rng.gen_range(0, 9);
    let d2: u8 = rng.gen_range(0, 9);
    let d3: u8 = rng.gen_range(0, 9);
    let d4: u8 = rng.gen_range(0, 9);
    let d5: u8 = rng.gen_range(0, 9);
    let d6: u8 = rng.gen_range(0, 9);
    let suffix = rng.choose(NI_SUFFIXES);
    format!(
        "{} {}{} {}{} {}{} {}",
        prefix, d1, d2, d3, d4, d5, d6, suffix
    )
}

// === Germany Steuer-ID: 11 digits with ISO 7064 Mod 11,10 check digit ===

/// Generate a German tax identification number (Steuerliche Identifikationsnummer).
///
/// 11 digits. The first 10 digits have specific rules:
/// - Exactly one digit appears twice, one digit is missing from 0-9.
/// - The first digit must not be 0.
/// - The 11th digit is an ISO 7064 Mod 11,10 check digit.
fn generate_de_steuerid(rng: &mut ForgeryRng) -> String {
    // Build 10 body digits satisfying the structural constraint:
    // exactly 9 of the 10 possible digits (0-9) appear, one appears twice.
    let mut available: Vec<u8> = (0..=9).collect();

    // Pick which digit is missing
    let missing_idx = rng.gen_range(0usize, 9);
    let missing = available.remove(missing_idx);

    // Pick which of the remaining 9 digits gets doubled
    let double_idx = rng.gen_range(0usize, 8);
    let doubled = available[double_idx];

    // Build the pool: the 9 unique digits + one extra copy of the doubled digit
    let mut pool = available;
    pool.push(doubled);

    // Shuffle using Fisher-Yates
    for i in (1..pool.len()).rev() {
        let j = rng.gen_range(0usize, i);
        pool.swap(i, j);
    }

    // Ensure first digit is not 0 (swap with a non-zero digit if needed)
    if pool[0] == 0 {
        // Find first non-zero digit to swap with
        if let Some(pos) = pool.iter().position(|&d| d > 0) {
            pool.swap(0, pos);
        }
    }

    // Also ensure the missing digit didn't sneak back in (it can't, but be safe)
    debug_assert!(!pool.contains(&missing) || missing == doubled);

    // Calculate ISO 7064 Mod 11,10 check digit
    let mut product = 10u32;
    for &digit in &pool {
        let sum = (digit as u32 + product) % 10;
        let sum = if sum == 0 { 10 } else { sum };
        product = (sum * 2) % 11;
    }
    let check = (11 - product) % 10;

    let mut result = String::with_capacity(11);
    for d in &pool {
        result.push(char::from_digit(*d as u32, 10).unwrap_or('0'));
    }
    result.push(char::from_digit(check, 10).unwrap_or('0'));
    result
}

// === France: Numéro de sécurité sociale (15 digits) ===

/// Generate a French social security number (numéro de sécurité sociale).
///
/// Format: S AA MM DDD CCC OOO KK
/// - S: Sex (1=male, 2=female)
/// - AA: Year of birth (00-99)
/// - MM: Month of birth (01-12)
/// - DDD: Department of birth (01-95 or 2A/2B for Corsica → 97/98)
/// - CCC: Commune (001-999)
/// - OOO: Order number (001-999)
/// - KK: Check key (97 - (first 13 digits mod 97))
fn generate_fr_nss(rng: &mut ForgeryRng) -> String {
    let sex: u8 = rng.gen_range(1, 2);
    let year: u8 = rng.gen_range(0, 99);
    let month: u8 = rng.gen_range(1, 12);
    let dept: u8 = rng.gen_range(1, 95);
    let commune: u16 = rng.gen_range(1, 999);
    let order: u16 = rng.gen_range(1, 999);

    let body = format!(
        "{}{:02}{:02}{:02}{:03}{:03}",
        sex, year, month, dept, commune, order
    );

    let body_num: u64 = body.parse().unwrap_or(0);
    let check = 97 - (body_num % 97);

    format!("{}{:02}", body, check)
}

// === Spain: DNI — 8 digits + check letter ===

/// DNI check letter table (mod-23 lookup).
const DNI_LETTERS: &[char] = &[
    'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H',
    'L', 'C', 'K', 'E',
];

/// Generate a Spanish DNI (Documento Nacional de Identidad).
fn generate_es_dni(rng: &mut ForgeryRng) -> String {
    let number: u32 = rng.gen_range(0, 99_999_999);
    let letter = DNI_LETTERS[(number % 23) as usize];
    format!("{:08}{}", number, letter)
}

// === Italy: Codice Fiscale — 16 characters ===

/// Consonants for Italian codice fiscale surname/name encoding.
const CF_CONSONANTS: &[u8] = b"BCDFGHJKLMNPQRSTVWXYZ";
/// Vowels for Italian codice fiscale surname/name encoding.
const CF_VOWELS: &[u8] = b"AEIOU";
/// Month codes for codice fiscale.
const CF_MONTH_CODES: &[char] = &['A', 'B', 'C', 'D', 'E', 'H', 'L', 'M', 'P', 'R', 'S', 'T'];
/// Odd-position character values for codice fiscale check digit.
const CF_ODD_VALUES: &[(char, u32)] = &[
    ('0', 1),
    ('1', 0),
    ('2', 5),
    ('3', 7),
    ('4', 9),
    ('5', 13),
    ('6', 15),
    ('7', 17),
    ('8', 19),
    ('9', 21),
    ('A', 1),
    ('B', 0),
    ('C', 5),
    ('D', 7),
    ('E', 9),
    ('F', 13),
    ('G', 15),
    ('H', 17),
    ('I', 19),
    ('J', 21),
    ('K', 2),
    ('L', 4),
    ('M', 18),
    ('N', 20),
    ('O', 11),
    ('P', 3),
    ('Q', 6),
    ('R', 8),
    ('S', 12),
    ('T', 14),
    ('U', 16),
    ('V', 10),
    ('W', 22),
    ('X', 25),
    ('Y', 24),
    ('Z', 23),
];

/// Generate an Italian codice fiscale.
fn generate_it_codice_fiscale(rng: &mut ForgeryRng) -> String {
    let mut code = String::with_capacity(16);

    // Surname: 3 characters (consonants, then vowels, padded with X)
    for _ in 0..3 {
        if rng.gen_range(0u8, 1) == 0 {
            code.push(*rng.choose(CF_CONSONANTS) as char);
        } else {
            code.push(*rng.choose(CF_VOWELS) as char);
        }
    }

    // Name: 3 characters
    for _ in 0..3 {
        if rng.gen_range(0u8, 1) == 0 {
            code.push(*rng.choose(CF_CONSONANTS) as char);
        } else {
            code.push(*rng.choose(CF_VOWELS) as char);
        }
    }

    // Year of birth: 2 digits
    let year: u8 = rng.gen_range(0, 99);
    code.push_str(&format!("{:02}", year));

    // Month: 1 letter
    let month_idx: usize = rng.gen_range(0usize, 11);
    code.push(CF_MONTH_CODES[month_idx]);

    // Day: 01-31 for males, 41-71 for females
    let is_female = rng.gen_range(0u8, 1) == 1;
    let day: u8 = rng.gen_range(1, 31);
    let day_code = if is_female { day + 40 } else { day };
    code.push_str(&format!("{:02}", day_code));

    // Municipality code: letter + 3 digits
    let muni_letter = (b'A' + rng.gen_range(0u8, 25)) as char;
    let muni_num: u16 = rng.gen_range(1, 999);
    code.push(muni_letter);
    code.push_str(&format!("{:03}", muni_num));

    // Check character (position 16)
    let check = compute_cf_check(&code);
    code.push(check);

    code
}

/// Compute the check character for an Italian codice fiscale.
fn compute_cf_check(code: &str) -> char {
    let mut sum: u32 = 0;
    for (i, c) in code.chars().enumerate() {
        let upper = c.to_ascii_uppercase();
        if i % 2 == 0 {
            // Odd position (1-indexed)
            let val = CF_ODD_VALUES
                .iter()
                .find(|(ch, _)| *ch == upper)
                .map(|(_, v)| *v)
                .unwrap_or(0);
            sum += val;
        } else {
            // Even position (1-indexed)
            let val = if upper.is_ascii_digit() {
                upper.to_digit(10).unwrap_or(0)
            } else {
                (upper as u32).saturating_sub('A' as u32)
            };
            sum += val;
        }
    }
    let remainder = (sum % 26) as u8;
    (b'A' + remainder) as char
}

// === Japan: My Number — 12 digits ===

/// Generate a Japanese My Number (individual number).
///
/// 12 digits where the 12th is a check digit computed as:
/// weighted sum of digits 1-11 (weights: 6,5,4,3,2,7,6,5,4,3,2), mod 11.
fn generate_jp_my_number(rng: &mut ForgeryRng) -> String {
    let mut digits = [0u8; 11];
    // First digit should be non-zero for realism
    digits[0] = rng.gen_range(1u8, 9);
    for d in &mut digits[1..] {
        *d = rng.gen_range(0u8, 9);
    }

    let weights = [6u32, 5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
    let sum: u32 = digits
        .iter()
        .zip(weights.iter())
        .map(|(&d, &w)| d as u32 * w)
        .sum();

    let remainder = sum % 11;
    let check = if remainder <= 1 { 0 } else { 11 - remainder };

    let mut result = String::with_capacity(12);
    for d in &digits {
        result.push(char::from_digit(*d as u32, 10).unwrap_or('0'));
    }
    result.push(char::from_digit(check, 10).unwrap_or('0'));
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_us_ssn_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let ssn = generate_us_ssn(&mut rng);
            assert_eq!(ssn.len(), 11, "Wrong length: {}", ssn);
            assert_eq!(ssn.chars().nth(3).unwrap(), '-');
            assert_eq!(ssn.chars().nth(6).unwrap(), '-');
            // Area should not be 000 or 666
            let area: u16 = ssn[..3].parse().unwrap();
            assert!((1..=899).contains(&area) && area != 666);
        }
    }

    #[test]
    fn test_uk_nino_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let nino = generate_uk_nino(&mut rng);
            // Format: "XX 99 99 99 X"
            assert_eq!(nino.len(), 13, "Wrong length: {}", nino);
            let last_char = nino.chars().last().unwrap();
            assert!(
                NI_SUFFIXES.contains(&last_char),
                "Invalid suffix: {}",
                last_char
            );
        }
    }

    #[test]
    fn test_de_steuerid_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let id = generate_de_steuerid(&mut rng);
            assert_eq!(id.len(), 11, "Wrong length: {}", id);
            assert!(id.chars().all(|c| c.is_ascii_digit()));
            assert_ne!(id.chars().next().unwrap(), '0', "First digit must not be 0");

            // Verify structural constraint: first 10 digits have exactly one
            // digit appearing twice and one digit from 0-9 missing.
            let body: Vec<u8> = id[..10]
                .chars()
                .map(|c| c.to_digit(10).unwrap() as u8)
                .collect();
            let mut counts = [0u8; 10];
            for &d in &body {
                counts[d as usize] += 1;
            }
            let zeros = counts.iter().filter(|&&c| c == 0).count();
            let twos = counts.iter().filter(|&&c| c == 2).count();
            assert_eq!(
                zeros, 1,
                "Should have exactly 1 missing digit: {:?} in {}",
                counts, id
            );
            assert_eq!(
                twos, 1,
                "Should have exactly 1 doubled digit: {:?} in {}",
                counts, id
            );
        }
    }

    #[test]
    fn test_fr_nss_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let nss = generate_fr_nss(&mut rng);
            assert_eq!(nss.len(), 15, "Wrong length: {}", nss);
            assert!(nss.chars().all(|c| c.is_ascii_digit()));
            let first = nss.chars().next().unwrap();
            assert!(first == '1' || first == '2', "Sex digit invalid: {}", first);
        }
    }

    #[test]
    fn test_es_dni_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let dni = generate_es_dni(&mut rng);
            assert_eq!(dni.len(), 9, "Wrong length: {}", dni);
            // First 8 chars are digits
            assert!(dni[..8].chars().all(|c| c.is_ascii_digit()));
            // Last char is a letter
            let letter = dni.chars().last().unwrap();
            assert!(letter.is_ascii_uppercase());
            // Verify check letter
            let number: u32 = dni[..8].parse().unwrap();
            let expected = DNI_LETTERS[(number % 23) as usize];
            assert_eq!(letter, expected, "Check letter mismatch for {}", dni);
        }
    }

    #[test]
    fn test_it_codice_fiscale_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let cf = generate_it_codice_fiscale(&mut rng);
            assert_eq!(cf.len(), 16, "Wrong length: {}", cf);
            // All characters should be alphanumeric
            assert!(
                cf.chars().all(|c| c.is_ascii_alphanumeric()),
                "Non-alphanumeric: {}",
                cf
            );
        }
    }

    #[test]
    fn test_jp_my_number_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let num = generate_jp_my_number(&mut rng);
            assert_eq!(num.len(), 12, "Wrong length: {}", num);
            assert!(num.chars().all(|c| c.is_ascii_digit()));

            // Verify check digit
            let digits: Vec<u8> = num.chars().map(|c| c.to_digit(10).unwrap() as u8).collect();
            let weights = [6u32, 5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
            let sum: u32 = digits[..11]
                .iter()
                .zip(weights.iter())
                .map(|(&d, &w)| d as u32 * w)
                .sum();
            let remainder = sum % 11;
            let expected = if remainder <= 1 { 0 } else { 11 - remainder };
            assert_eq!(
                digits[11] as u32, expected,
                "Check digit mismatch for {}",
                num
            );
        }
    }

    #[test]
    fn test_locale_dispatch() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let us = generate_ssn(&mut rng, Locale::EnUS);
        assert!(us.contains('-'), "US SSN should have dashes: {}", us);

        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let uk = generate_ssn(&mut rng, Locale::EnGB);
        assert!(
            uk.chars().last().unwrap().is_ascii_uppercase(),
            "UK NINO should end with letter: {}",
            uk
        );

        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let es = generate_ssn(&mut rng, Locale::EsES);
        assert_eq!(es.len(), 9, "Spanish DNI should be 9 chars: {}", es);
    }

    #[test]
    fn test_batch_sizes() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        assert_eq!(generate_ssns(&mut rng, Locale::EnUS, 0).unwrap().len(), 0);
        assert_eq!(generate_ssns(&mut rng, Locale::EnUS, 50).unwrap().len(), 50);
    }

    #[test]
    fn test_determinism() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        assert_eq!(
            generate_ssn(&mut rng1, Locale::EnUS),
            generate_ssn(&mut rng2, Locale::EnUS)
        );
    }
}
