//! ISBN generation provider.
//!
//! Generates ISBN-10 and ISBN-13 codes with valid check digits and hyphen formatting.

use crate::providers::barcode::ean_check_digit;
use crate::rng::ForgeryRng;
use crate::validate_batch_size;
use crate::BatchSizeError;

/// Generate a single ISBN-10 with hyphens.
///
/// Format: `X-XXX-XXXXX-C` where C is the check digit (0-9 or X).
pub fn generate_isbn10(rng: &mut ForgeryRng) -> String {
    let mut digits = [0u8; 9];
    for d in &mut digits {
        *d = rng.gen_range(0u8, 9);
    }

    // ISBN-10 check: sum of (digit * weight) where weights are 10, 9, 8, ..., 2.
    // Check digit (weight 1) makes total mod 11 == 0.
    let sum: u32 = digits
        .iter()
        .enumerate()
        .map(|(i, &d)| d as u32 * (10 - i as u32))
        .sum();
    let check = (11 - (sum % 11)) % 11;

    let check_char = if check == 10 {
        'X'
    } else {
        char::from_digit(check, 10).unwrap_or('0')
    };

    // Format: G-PPP-TTTTT-C (registration group - publisher - title - check)
    format!(
        "{}-{}{}{}-{}{}{}{}{}-{}",
        digits[0],
        digits[1],
        digits[2],
        digits[3],
        digits[4],
        digits[5],
        digits[6],
        digits[7],
        digits[8],
        check_char
    )
}

/// Generate a batch of ISBN-10 codes.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_isbn10s(rng: &mut ForgeryRng, n: usize) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_isbn10(rng));
    }
    Ok(results)
}

/// Generate a single ISBN-13 with hyphens.
///
/// Format: `978-X-XXX-XXXXX-C` or `979-X-XXX-XXXXX-C`.
pub fn generate_isbn13(rng: &mut ForgeryRng) -> String {
    // Prefix: 978 or 979
    let prefix: [u8; 3] = if rng.gen_range(0u8, 1) == 0 {
        [9, 7, 8]
    } else {
        [9, 7, 9]
    };

    let mut body = [0u8; 9];
    for d in &mut body {
        *d = rng.gen_range(0u8, 9);
    }

    // Combine prefix + body for check digit calculation
    let mut all_digits = [0u8; 12];
    all_digits[..3].copy_from_slice(&prefix);
    all_digits[3..12].copy_from_slice(&body);

    let check = ean_check_digit(&all_digits);

    // Format: PPP-G-RRR-TTTTT-C
    format!(
        "{}{}{}-{}-{}{}{}-{}{}{}{}{}-{}",
        prefix[0],
        prefix[1],
        prefix[2],
        body[0],
        body[1],
        body[2],
        body[3],
        body[4],
        body[5],
        body[6],
        body[7],
        body[8],
        check
    )
}

/// Generate a batch of ISBN-13 codes.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_isbn13s(rng: &mut ForgeryRng, n: usize) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_isbn13(rng));
    }
    Ok(results)
}

/// Validate an ISBN-10 check digit.
#[allow(dead_code)]
pub fn validate_isbn10(isbn: &str) -> bool {
    let chars: Vec<char> = isbn
        .chars()
        .filter(|c| c.is_ascii_digit() || *c == 'X')
        .collect();
    if chars.len() != 10 {
        return false;
    }

    let sum: u32 = chars
        .iter()
        .enumerate()
        .map(|(i, &c)| {
            let val = if c == 'X' {
                10
            } else {
                c.to_digit(10).unwrap_or(0)
            };
            val * (10 - i as u32)
        })
        .sum();

    sum.is_multiple_of(11)
}

/// Validate an ISBN-13 check digit.
#[allow(dead_code)]
pub fn validate_isbn13(isbn: &str) -> bool {
    let digits: Vec<u8> = isbn
        .chars()
        .filter_map(|c| c.to_digit(10).map(|d| d as u8))
        .collect();
    if digits.len() != 13 {
        return false;
    }

    let payload = &digits[..12];
    let expected = ean_check_digit(payload);
    expected == digits[12]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_isbn10_format_and_check() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let isbn = generate_isbn10(&mut rng);
            // Should have hyphens
            assert!(isbn.contains('-'), "Missing hyphens: {}", isbn);
            // Should have 10 digit/X characters
            let chars: Vec<char> = isbn
                .chars()
                .filter(|c| c.is_ascii_digit() || *c == 'X')
                .collect();
            assert_eq!(chars.len(), 10, "Wrong digit count: {}", isbn);
            assert!(validate_isbn10(&isbn), "Invalid ISBN-10: {}", isbn);
        }
    }

    #[test]
    fn test_isbn13_format_and_check() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let isbn = generate_isbn13(&mut rng);
            // Should have hyphens
            assert!(isbn.contains('-'), "Missing hyphens: {}", isbn);
            // Should start with 978 or 979
            assert!(
                isbn.starts_with("978") || isbn.starts_with("979"),
                "Invalid prefix: {}",
                isbn
            );
            // Should have 13 digits
            let digits: Vec<char> = isbn.chars().filter(|c| c.is_ascii_digit()).collect();
            assert_eq!(digits.len(), 13, "Wrong digit count: {}", isbn);
            assert!(validate_isbn13(&isbn), "Invalid ISBN-13: {}", isbn);
        }
    }

    #[test]
    fn test_batch_sizes() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        assert_eq!(generate_isbn10s(&mut rng, 0).unwrap().len(), 0);
        assert_eq!(generate_isbn10s(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_isbn13s(&mut rng, 50).unwrap().len(), 50);
    }

    #[test]
    fn test_determinism() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        assert_eq!(generate_isbn10(&mut rng1), generate_isbn10(&mut rng2));

        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        assert_eq!(generate_isbn13(&mut rng1), generate_isbn13(&mut rng2));
    }
}
