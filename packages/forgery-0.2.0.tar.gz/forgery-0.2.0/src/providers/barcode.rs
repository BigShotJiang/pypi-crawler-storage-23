//! Barcode generation provider.
//!
//! Generates EAN-13, EAN-8, UPC-A, and UPC-E barcodes with valid check digits.

use crate::rng::ForgeryRng;
use crate::validate_batch_size;
use crate::BatchSizeError;

/// Calculate EAN/UPC check digit using the GS1 standard weighted-sum algorithm.
///
/// Per GS1, the rightmost payload digit always gets weight 3, then alternating
/// 1 and 3 moving leftward. This works correctly for all payload lengths
/// (7 for EAN-8, 11 for UPC-A, 12 for EAN-13/ISBN-13).
/// Also used by the ISBN provider for ISBN-13 check digits.
pub fn ean_check_digit(digits: &[u8]) -> u8 {
    let len = digits.len();
    let sum: u32 = digits
        .iter()
        .enumerate()
        .map(|(i, &d)| {
            // Weight from the right: rightmost payload digit gets 3,
            // then alternating 1, 3, 1, 3, ...
            let weight = if (len - 1 - i).is_multiple_of(2) {
                3
            } else {
                1
            };
            d as u32 * weight
        })
        .sum();
    ((10 - (sum % 10)) % 10) as u8
}

/// Generate a single EAN-13 barcode.
pub fn generate_ean13(rng: &mut ForgeryRng) -> String {
    let mut digits = [0u8; 12];
    for d in &mut digits {
        *d = rng.gen_range(0u8, 9);
    }
    let check = ean_check_digit(&digits);
    let mut result = String::with_capacity(13);
    for d in &digits {
        result.push(char::from_digit(*d as u32, 10).unwrap_or('0'));
    }
    result.push(char::from_digit(check as u32, 10).unwrap_or('0'));
    result
}

/// Generate a batch of EAN-13 barcodes.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_ean13s(rng: &mut ForgeryRng, n: usize) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_ean13(rng));
    }
    Ok(results)
}

/// Generate a single EAN-8 barcode.
pub fn generate_ean8(rng: &mut ForgeryRng) -> String {
    let mut digits = [0u8; 7];
    for d in &mut digits {
        *d = rng.gen_range(0u8, 9);
    }
    let check = ean_check_digit(&digits);
    let mut result = String::with_capacity(8);
    for d in &digits {
        result.push(char::from_digit(*d as u32, 10).unwrap_or('0'));
    }
    result.push(char::from_digit(check as u32, 10).unwrap_or('0'));
    result
}

/// Generate a batch of EAN-8 barcodes.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_ean8s(rng: &mut ForgeryRng, n: usize) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_ean8(rng));
    }
    Ok(results)
}

/// Generate a single UPC-A barcode.
///
/// UPC-A is essentially an EAN-13 with a leading 0.
pub fn generate_upc_a(rng: &mut ForgeryRng) -> String {
    let mut digits = [0u8; 11];
    for d in &mut digits {
        *d = rng.gen_range(0u8, 9);
    }
    let check = ean_check_digit(&digits);
    let mut result = String::with_capacity(12);
    for d in &digits {
        result.push(char::from_digit(*d as u32, 10).unwrap_or('0'));
    }
    result.push(char::from_digit(check as u32, 10).unwrap_or('0'));
    result
}

/// Generate a batch of UPC-A barcodes.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_upc_as(rng: &mut ForgeryRng, n: usize) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_upc_a(rng));
    }
    Ok(results)
}

/// Generate a single UPC-E barcode (8 digits including check digit).
///
/// UPC-E is a compressed form of UPC-A. We generate a valid 8-digit code
/// with a check digit at position 8.
pub fn generate_upc_e(rng: &mut ForgeryRng) -> String {
    // UPC-E: number system (0) + 6 digits + check digit
    // Generate the 6 middle digits
    let mut middle = [0u8; 6];
    for d in &mut middle {
        *d = rng.gen_range(0u8, 9);
    }

    // Build the equivalent UPC-A to compute a valid check digit.
    // The UPC-E suppression scheme depends on the last digit of the 6 middle digits.
    let last = middle[5];
    let upc_a_body: [u8; 11] = match last {
        0..=2 => [
            0, middle[0], middle[1], last, 0, 0, 0, 0, middle[2], middle[3], middle[4],
        ],
        3 => [
            0, middle[0], middle[1], middle[2], 0, 0, 0, 0, 0, middle[3], middle[4],
        ],
        4 => [
            0, middle[0], middle[1], middle[2], middle[3], 0, 0, 0, 0, 0, middle[4],
        ],
        _ => [
            0, middle[0], middle[1], middle[2], middle[3], middle[4], 0, 0, 0, 0, last,
        ],
    };

    let check = ean_check_digit(&upc_a_body);

    let mut result = String::with_capacity(8);
    result.push('0');
    for d in &middle {
        result.push(char::from_digit(*d as u32, 10).unwrap_or('0'));
    }
    result.push(char::from_digit(check as u32, 10).unwrap_or('0'));
    result
}

/// Generate a batch of UPC-E barcodes.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_upc_es(rng: &mut ForgeryRng, n: usize) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_upc_e(rng));
    }
    Ok(results)
}

/// Validate an EAN/UPC barcode check digit.
#[allow(dead_code)]
pub fn validate_ean(barcode: &str) -> bool {
    let digits: Vec<u8> = barcode
        .chars()
        .filter_map(|c| c.to_digit(10).map(|d| d as u8))
        .collect();

    if digits.len() < 2 {
        return false;
    }

    let payload = &digits[..digits.len() - 1];
    let expected = ean_check_digit(payload);
    expected == digits[digits.len() - 1]
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ean13_length_and_check() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let code = generate_ean13(&mut rng);
            assert_eq!(code.len(), 13);
            assert!(code.chars().all(|c| c.is_ascii_digit()));
            assert!(validate_ean(&code), "Invalid EAN-13: {}", code);
        }
    }

    #[test]
    fn test_ean8_length_and_check() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let code = generate_ean8(&mut rng);
            assert_eq!(code.len(), 8);
            assert!(code.chars().all(|c| c.is_ascii_digit()));
            assert!(validate_ean(&code), "Invalid EAN-8: {}", code);
        }
    }

    #[test]
    fn test_upc_a_length_and_check() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let code = generate_upc_a(&mut rng);
            assert_eq!(code.len(), 12);
            assert!(code.chars().all(|c| c.is_ascii_digit()));
            assert!(validate_ean(&code), "Invalid UPC-A: {}", code);
        }
    }

    #[test]
    fn test_upc_e_length() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let code = generate_upc_e(&mut rng);
            assert_eq!(code.len(), 8);
            assert!(code.chars().all(|c| c.is_ascii_digit()));
            assert_eq!(code.chars().next().unwrap(), '0', "UPC-E must start with 0");
        }
    }

    #[test]
    fn test_batch_sizes() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        assert_eq!(generate_ean13s(&mut rng, 0).unwrap().len(), 0);
        assert_eq!(generate_ean13s(&mut rng, 1).unwrap().len(), 1);
        assert_eq!(generate_ean8s(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_upc_as(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_upc_es(&mut rng, 50).unwrap().len(), 50);
    }

    #[test]
    fn test_determinism() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        assert_eq!(generate_ean13(&mut rng1), generate_ean13(&mut rng2));
    }
}
