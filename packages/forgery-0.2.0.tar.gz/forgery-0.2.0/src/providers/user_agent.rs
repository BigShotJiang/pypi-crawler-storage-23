//! User agent string generation provider.
//!
//! Generates realistic browser user agent strings for Chrome, Firefox, and Safari.
//! UA strings are universal (no locale data needed).

use crate::rng::ForgeryRng;

/// Windows NT version token. Windows 11 still reports "10.0" in UA strings.
const WINDOWS_VERSIONS: &[&str] = &["10.0"];

/// macOS version strings (underscore-separated, as used in UA strings).
const MACOS_VERSIONS: &[&str] = &[
    "10_15_7", "11_0", "11_6", "12_0", "12_6", "13_0", "13_5", "14_0", "14_3", "14_5", "15_0",
];

/// Linux desktop strings.
const LINUX_PLATFORMS: &[&str] = &["X11; Linux x86_64", "X11; Linux aarch64"];

/// Chrome major version range (inclusive). Approximate as of January 2026.
const CHROME_MIN_VERSION: u16 = 110;
const CHROME_MAX_VERSION: u16 = 131;

/// Firefox major version range (inclusive). Approximate as of January 2026.
const FIREFOX_MIN_VERSION: u16 = 110;
const FIREFOX_MAX_VERSION: u16 = 133;

/// Safari major version range (inclusive). Approximate as of January 2026.
const SAFARI_MIN_VERSION: u16 = 15;
const SAFARI_MAX_VERSION: u16 = 17;

/// Safari minor version range (inclusive).
const SAFARI_MINOR_MIN: u16 = 0;
const SAFARI_MINOR_MAX: u16 = 6;

/// WebKit version used in Chrome/Safari UA strings.
const WEBKIT_VERSION: &str = "537.36";

/// Safari WebKit version.
const SAFARI_WEBKIT_VERSION: &str = "605.1.15";

/// Generate a batch of random user agent strings (any browser).
pub fn generate_user_agents(rng: &mut ForgeryRng, n: usize) -> Vec<String> {
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_user_agent(rng));
    }
    results
}

/// Generate a single random user agent string (any browser).
#[inline]
pub fn generate_user_agent(rng: &mut ForgeryRng) -> String {
    match rng.gen_range(0u8, 2) {
        0 => generate_chrome_ua(rng),
        1 => generate_firefox_ua(rng),
        _ => generate_safari_ua(rng),
    }
}

/// Generate a batch of Chrome user agent strings.
pub fn generate_chrome_uas(rng: &mut ForgeryRng, n: usize) -> Vec<String> {
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_chrome_ua(rng));
    }
    results
}

/// Generate a single Chrome user agent string.
#[inline]
pub fn generate_chrome_ua(rng: &mut ForgeryRng) -> String {
    let major = rng.gen_range(CHROME_MIN_VERSION, CHROME_MAX_VERSION);
    let build = rng.gen_range(0u16, 9999);
    let patch = rng.gen_range(0u16, 999);
    let platform = generate_platform(rng);

    format!(
        "Mozilla/5.0 ({platform}) AppleWebKit/{WEBKIT_VERSION} (KHTML, like Gecko) Chrome/{major}.0.{build}.{patch} Safari/{WEBKIT_VERSION}"
    )
}

/// Generate a batch of Firefox user agent strings.
pub fn generate_firefox_uas(rng: &mut ForgeryRng, n: usize) -> Vec<String> {
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_firefox_ua(rng));
    }
    results
}

/// Generate a single Firefox user agent string.
#[inline]
pub fn generate_firefox_ua(rng: &mut ForgeryRng) -> String {
    let major = rng.gen_range(FIREFOX_MIN_VERSION, FIREFOX_MAX_VERSION);
    let platform = generate_platform(rng);

    format!("Mozilla/5.0 ({platform}; rv:{major}.0) Gecko/20100101 Firefox/{major}.0")
}

/// Generate a batch of Safari user agent strings.
pub fn generate_safari_uas(rng: &mut ForgeryRng, n: usize) -> Vec<String> {
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_safari_ua(rng));
    }
    results
}

/// Generate a single Safari user agent string.
#[inline]
pub fn generate_safari_ua(rng: &mut ForgeryRng) -> String {
    let mac_version = rng.choose(MACOS_VERSIONS);
    let safari_major = rng.gen_range(SAFARI_MIN_VERSION, SAFARI_MAX_VERSION);
    let safari_minor = rng.gen_range(SAFARI_MINOR_MIN, SAFARI_MINOR_MAX);

    format!(
        "Mozilla/5.0 (Macintosh; Intel Mac OS X {mac_version}) AppleWebKit/{SAFARI_WEBKIT_VERSION} (KHTML, like Gecko) Version/{safari_major}.{safari_minor} Safari/{SAFARI_WEBKIT_VERSION}"
    )
}

/// Generate a random platform string for user agent strings.
fn generate_platform(rng: &mut ForgeryRng) -> String {
    match rng.gen_range(0u8, 2) {
        0 => {
            let version = rng.choose(WINDOWS_VERSIONS);
            format!("Windows NT {version}; Win64; x64")
        }
        1 => {
            let version = rng.choose(MACOS_VERSIONS);
            format!("Macintosh; Intel Mac OS X {version}")
        }
        _ => rng.choose(LINUX_PLATFORMS).to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_generate_user_agents_count() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let uas = generate_user_agents(&mut rng, 100);
        assert_eq!(uas.len(), 100);
    }

    #[test]
    fn test_user_agent_starts_with_mozilla() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        for _ in 0..100 {
            let ua = generate_user_agent(&mut rng);
            assert!(
                ua.starts_with("Mozilla/5.0"),
                "UA should start with Mozilla/5.0: {}",
                ua
            );
        }
    }

    #[test]
    fn test_chrome_ua_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        for _ in 0..100 {
            let ua = generate_chrome_ua(&mut rng);
            assert!(ua.starts_with("Mozilla/5.0"), "Chrome UA start: {}", ua);
            assert!(
                ua.contains("Chrome/"),
                "Chrome UA should contain Chrome/: {}",
                ua
            );
            assert!(
                ua.contains("AppleWebKit/537.36"),
                "Chrome UA should contain WebKit: {}",
                ua
            );
        }
    }

    #[test]
    fn test_chrome_uas_batch() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let uas = generate_chrome_uas(&mut rng, 50);
        assert_eq!(uas.len(), 50);
        for ua in &uas {
            assert!(ua.contains("Chrome/"));
        }
    }

    #[test]
    fn test_firefox_ua_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        for _ in 0..100 {
            let ua = generate_firefox_ua(&mut rng);
            assert!(ua.starts_with("Mozilla/5.0"), "Firefox UA start: {}", ua);
            assert!(
                ua.contains("Firefox/"),
                "Firefox UA should contain Firefox/: {}",
                ua
            );
            assert!(
                ua.contains("Gecko/20100101"),
                "Firefox UA should contain Gecko: {}",
                ua
            );
        }
    }

    #[test]
    fn test_firefox_uas_batch() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let uas = generate_firefox_uas(&mut rng, 50);
        assert_eq!(uas.len(), 50);
        for ua in &uas {
            assert!(ua.contains("Firefox/"));
        }
    }

    #[test]
    fn test_safari_ua_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        for _ in 0..100 {
            let ua = generate_safari_ua(&mut rng);
            assert!(ua.starts_with("Mozilla/5.0"), "Safari UA start: {}", ua);
            assert!(
                ua.contains("Version/"),
                "Safari UA should contain Version/: {}",
                ua
            );
            assert!(
                ua.contains("Safari/605.1.15"),
                "Safari UA should contain Safari WebKit: {}",
                ua
            );
            assert!(
                ua.contains("Macintosh"),
                "Safari UA should be macOS: {}",
                ua
            );
        }
    }

    #[test]
    fn test_safari_uas_batch() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let uas = generate_safari_uas(&mut rng, 50);
        assert_eq!(uas.len(), 50);
        for ua in &uas {
            assert!(ua.contains("Safari/605.1.15"));
        }
    }

    #[test]
    fn test_empty_batches() {
        let mut rng = ForgeryRng::new();
        assert!(generate_user_agents(&mut rng, 0).is_empty());
        assert!(generate_chrome_uas(&mut rng, 0).is_empty());
        assert!(generate_firefox_uas(&mut rng, 0).is_empty());
        assert!(generate_safari_uas(&mut rng, 0).is_empty());
    }

    #[test]
    fn test_deterministic() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(12345);
        rng2.seed(12345);

        let uas1 = generate_user_agents(&mut rng1, 50);
        let uas2 = generate_user_agents(&mut rng2, 50);
        assert_eq!(uas1, uas2);
    }

    #[test]
    fn test_different_seeds_different_results() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(1);
        rng2.seed(2);

        let uas1 = generate_user_agents(&mut rng1, 50);
        let uas2 = generate_user_agents(&mut rng2, 50);
        assert_ne!(uas1, uas2);
    }

    #[test]
    fn test_all_browser_types_reachable() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let mut has_chrome = false;
        let mut has_firefox = false;
        let mut has_safari = false;

        for _ in 0..500 {
            let ua = generate_user_agent(&mut rng);
            if ua.contains("Chrome/") && !ua.contains("Version/") {
                has_chrome = true;
            } else if ua.contains("Firefox/") {
                has_firefox = true;
            } else if ua.contains("Version/") && ua.contains("Safari/605") {
                has_safari = true;
            }
        }

        assert!(has_chrome, "Should produce Chrome UAs");
        assert!(has_firefox, "Should produce Firefox UAs");
        assert!(has_safari, "Should produce Safari UAs");
    }

    #[test]
    fn test_all_platforms_reachable() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let mut has_windows = false;
        let mut has_mac = false;
        let mut has_linux = false;

        for _ in 0..500 {
            let ua = generate_chrome_ua(&mut rng);
            if ua.contains("Windows NT") {
                has_windows = true;
            } else if ua.contains("Macintosh") {
                has_mac = true;
            } else if ua.contains("Linux") {
                has_linux = true;
            }
        }

        assert!(has_windows, "Should produce Windows UAs");
        assert!(has_mac, "Should produce macOS UAs");
        assert!(has_linux, "Should produce Linux UAs");
    }
}

#[cfg(test)]
mod proptest_tests {
    use super::*;
    use proptest::prelude::*;

    proptest! {
        /// Property: user agent batch size is always respected
        #[test]
        fn prop_user_agent_batch_size(n in 0usize..500) {
            let mut rng = ForgeryRng::new();
            rng.seed(42);
            let uas = generate_user_agents(&mut rng, n);
            prop_assert_eq!(uas.len(), n);
        }

        /// Property: all user agents start with Mozilla/5.0
        #[test]
        fn prop_user_agent_starts_with_mozilla(n in 1usize..100) {
            let mut rng = ForgeryRng::new();
            rng.seed(42);
            let uas = generate_user_agents(&mut rng, n);
            for ua in uas {
                prop_assert!(ua.starts_with("Mozilla/5.0"));
            }
        }

        /// Property: same seed produces same user agents
        #[test]
        fn prop_user_agent_determinism(seed_val in any::<u64>(), n in 1usize..50) {
            let mut rng1 = ForgeryRng::new();
            let mut rng2 = ForgeryRng::new();
            rng1.seed(seed_val);
            rng2.seed(seed_val);

            let uas1 = generate_user_agents(&mut rng1, n);
            let uas2 = generate_user_agents(&mut rng2, n);
            prop_assert_eq!(uas1, uas2);
        }
    }
}
