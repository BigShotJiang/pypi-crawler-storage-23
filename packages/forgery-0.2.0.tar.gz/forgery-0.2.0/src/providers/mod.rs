//! Data generation providers.
//!
//! Each provider module implements generation functions for a specific category
//! of fake data. All generators follow the batch-first pattern, returning `Vec<T>`.

pub mod address;
pub mod async_records;
pub mod barcode;
pub mod boolean;
pub mod colors;
pub mod commerce;
pub mod company;
pub mod currency;
pub mod custom;
pub mod datetime;
pub mod file;
pub mod finance;
pub mod geo;
pub mod identifiers;
pub mod internet;
pub mod isbn;
pub mod names;
pub mod network;
pub mod numbers;
pub mod password;
pub mod pattern;
pub mod phone;
pub mod profile;
pub mod records;
pub mod ssn;
pub mod text;
pub mod user_agent;
pub mod vehicle;
