//! Commerce/product data generation provider.
//!
//! Generates product names, categories, departments, and materials.

use crate::rng::ForgeryRng;
use crate::validate_batch_size;
use crate::BatchSizeError;

/// Product adjectives used in product name generation.
const ADJECTIVES: &[&str] = &[
    "Aerodynamic",
    "Durable",
    "Elegant",
    "Ergonomic",
    "Fantastic",
    "Generic",
    "Gorgeous",
    "Handcrafted",
    "Handmade",
    "Incredible",
    "Intelligent",
    "Licensed",
    "Luxurious",
    "Modern",
    "Organic",
    "Practical",
    "Recycled",
    "Refined",
    "Rustic",
    "Sleek",
    "Small",
    "Sturdy",
    "Tasty",
    "Ultra",
    "Unbranded",
    "Vintage",
    "Bespoke",
    "Electronic",
    "Premium",
    "Compact",
];

/// Product materials.
const MATERIALS: &[&str] = &[
    "Aluminum",
    "Bamboo",
    "Bronze",
    "Carbon Fiber",
    "Ceramic",
    "Concrete",
    "Copper",
    "Cotton",
    "Fabric",
    "Frozen",
    "Glass",
    "Granite",
    "Iron",
    "Leather",
    "Linen",
    "Metal",
    "Plastic",
    "Rubber",
    "Silk",
    "Steel",
    "Stone",
    "Wood",
    "Wool",
];

/// Product types.
const PRODUCTS: &[&str] = &[
    "Bacon", "Ball", "Bench", "Bike", "Car", "Chair", "Cheese", "Chicken", "Chips", "Clock",
    "Computer", "Fish", "Gloves", "Hat", "Keyboard", "Lamp", "Mouse", "Pants", "Pizza", "Salad",
    "Sausages", "Shirt", "Shoes", "Soap", "Table", "Towels", "Tuna", "Watch", "Wallet", "Bottle",
];

/// Product categories.
const CATEGORIES: &[&str] = &[
    "Automotive",
    "Baby",
    "Beauty",
    "Books",
    "Clothing",
    "Computers",
    "Electronics",
    "Food",
    "Games",
    "Garden",
    "Grocery",
    "Health",
    "Home",
    "Industrial",
    "Jewelry",
    "Kids",
    "Movies",
    "Music",
    "Outdoors",
    "Pets",
    "Shoes",
    "Sports",
    "Tools",
    "Toys",
];

/// Store departments.
const DEPARTMENTS: &[&str] = &[
    "Accessories",
    "Automotive",
    "Baby",
    "Beauty",
    "Books",
    "Clothing",
    "Computers",
    "Electronics",
    "Food",
    "Games",
    "Garden",
    "Grocery",
    "Health",
    "Home",
    "Industrial",
    "Jewelry",
    "Kids",
    "Movies",
    "Music",
    "Outdoors",
    "Pets",
    "Shoes",
    "Sports",
    "Tools",
    "Toys",
];

/// Generate a single random product name (e.g., "Ergonomic Steel Chair").
pub fn generate_product_name(rng: &mut ForgeryRng) -> String {
    let adj = rng.choose(ADJECTIVES);
    let mat = rng.choose(MATERIALS);
    let prod = rng.choose(PRODUCTS);
    format!("{} {} {}", adj, mat, prod)
}

/// Generate a batch of random product names.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_product_names(
    rng: &mut ForgeryRng,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_product_name(rng));
    }
    Ok(results)
}

/// Generate a single random product category.
pub fn generate_product_category(rng: &mut ForgeryRng) -> String {
    rng.choose(CATEGORIES).to_string()
}

/// Generate a batch of random product categories.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_product_categories(
    rng: &mut ForgeryRng,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_product_category(rng));
    }
    Ok(results)
}

/// Generate a single random department name.
pub fn generate_department(rng: &mut ForgeryRng) -> String {
    rng.choose(DEPARTMENTS).to_string()
}

/// Generate a batch of random department names.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_departments(rng: &mut ForgeryRng, n: usize) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_department(rng));
    }
    Ok(results)
}

/// Generate a single random product material.
pub fn generate_product_material(rng: &mut ForgeryRng) -> String {
    rng.choose(MATERIALS).to_string()
}

/// Generate a batch of random product materials.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_product_materials(
    rng: &mut ForgeryRng,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_product_material(rng));
    }
    Ok(results)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_product_name_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let name = generate_product_name(&mut rng);
            let parts: Vec<&str> = name.splitn(3, ' ').collect();
            assert!(parts.len() >= 3, "Product name too short: {}", name);
        }
    }

    #[test]
    fn test_product_category() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let cat = generate_product_category(&mut rng);
            assert!(
                CATEGORIES.contains(&cat.as_str()),
                "Unknown category: {}",
                cat
            );
        }
    }

    #[test]
    fn test_department() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let dept = generate_department(&mut rng);
            assert!(
                DEPARTMENTS.contains(&dept.as_str()),
                "Unknown department: {}",
                dept
            );
        }
    }

    #[test]
    fn test_product_material() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let mat = generate_product_material(&mut rng);
            assert!(
                MATERIALS.contains(&mat.as_str()),
                "Unknown material: {}",
                mat
            );
        }
    }

    #[test]
    fn test_batch_sizes() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        assert_eq!(generate_product_names(&mut rng, 0).unwrap().len(), 0);
        assert_eq!(generate_product_names(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_product_categories(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_departments(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_product_materials(&mut rng, 50).unwrap().len(), 50);
    }

    #[test]
    fn test_determinism() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        assert_eq!(
            generate_product_name(&mut rng1),
            generate_product_name(&mut rng2)
        );
    }
}
