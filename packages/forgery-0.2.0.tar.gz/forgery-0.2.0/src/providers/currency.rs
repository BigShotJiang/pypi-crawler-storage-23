//! Currency and commerce data generation provider.
//!
//! Generates ISO 4217 currency codes, currency names (in English), and prices.
//! No locale-specific data files are needed.

use crate::providers::numbers::{FloatRangeError, FloatRangeErrorReason};
use crate::rng::ForgeryRng;

/// Common currencies: (ISO 4217 code, full name).
const CURRENCIES: &[(&str, &str)] = &[
    ("AED", "United Arab Emirates Dirham"),
    ("ARS", "Argentine Peso"),
    ("AUD", "Australian Dollar"),
    ("BRL", "Brazilian Real"),
    ("CAD", "Canadian Dollar"),
    ("CHF", "Swiss Franc"),
    ("CLP", "Chilean Peso"),
    ("CNY", "Chinese Yuan"),
    ("COP", "Colombian Peso"),
    ("CZK", "Czech Koruna"),
    ("DKK", "Danish Krone"),
    ("EGP", "Egyptian Pound"),
    ("EUR", "Euro"),
    ("GBP", "British Pound"),
    ("HKD", "Hong Kong Dollar"),
    ("HUF", "Hungarian Forint"),
    ("IDR", "Indonesian Rupiah"),
    ("ILS", "Israeli New Shekel"),
    ("INR", "Indian Rupee"),
    ("JPY", "Japanese Yen"),
    ("KRW", "South Korean Won"),
    ("MXN", "Mexican Peso"),
    ("MYR", "Malaysian Ringgit"),
    ("NGN", "Nigerian Naira"),
    ("NOK", "Norwegian Krone"),
    ("NZD", "New Zealand Dollar"),
    ("PEN", "Peruvian Sol"),
    ("PHP", "Philippine Peso"),
    ("PLN", "Polish Zloty"),
    ("RON", "Romanian Leu"),
    ("RUB", "Russian Ruble"),
    ("SAR", "Saudi Riyal"),
    ("SEK", "Swedish Krona"),
    ("SGD", "Singapore Dollar"),
    ("THB", "Thai Baht"),
    ("TRY", "Turkish Lira"),
    ("TWD", "New Taiwan Dollar"),
    ("USD", "United States Dollar"),
    ("ZAR", "South African Rand"),
];

/// Generate a batch of random ISO 4217 currency codes.
pub fn generate_currency_codes(rng: &mut ForgeryRng, n: usize) -> Vec<String> {
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_currency_code(rng));
    }
    results
}

/// Generate a single random ISO 4217 currency code.
#[inline]
pub fn generate_currency_code(rng: &mut ForgeryRng) -> String {
    let (code, _) = rng.choose(CURRENCIES);
    (*code).to_string()
}

/// Generate a batch of random currency names.
pub fn generate_currency_names(rng: &mut ForgeryRng, n: usize) -> Vec<String> {
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_currency_name(rng));
    }
    results
}

/// Generate a single random currency name.
#[inline]
pub fn generate_currency_name(rng: &mut ForgeryRng) -> String {
    let (_, name) = rng.choose(CURRENCIES);
    (*name).to_string()
}

/// Generate a batch of random currency (code, name) pairs.
pub fn generate_currencies(rng: &mut ForgeryRng, n: usize) -> Vec<(String, String)> {
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_currency(rng));
    }
    results
}

/// Generate a single random currency (code, name) pair.
#[inline]
pub fn generate_currency(rng: &mut ForgeryRng) -> (String, String) {
    let (code, name) = rng.choose(CURRENCIES);
    ((*code).to_string(), (*name).to_string())
}

/// Generate a batch of random prices.
///
/// # Errors
///
/// Returns `FloatRangeError` if `min > max` or if either value is NaN or infinity.
pub fn generate_prices(
    rng: &mut ForgeryRng,
    n: usize,
    min: f64,
    max: f64,
) -> Result<Vec<f64>, FloatRangeError> {
    validate_price_range(min, max)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_price_inner(rng, min, max));
    }
    Ok(results)
}

/// Generate a single random price with 2 decimal places.
///
/// # Errors
///
/// Returns `FloatRangeError` if `min > max` or if either value is NaN or infinity.
#[inline]
pub fn generate_price(rng: &mut ForgeryRng, min: f64, max: f64) -> Result<f64, FloatRangeError> {
    validate_price_range(min, max)?;
    Ok(generate_price_inner(rng, min, max))
}

/// Generate a price without validation. Rounds to 2 decimal places and clamps to [min, max].
#[inline]
fn generate_price_inner(rng: &mut ForgeryRng, min: f64, max: f64) -> f64 {
    let amount = min + (rng.gen_range(0u32, 1_000_000) as f64 / 1_000_000.0) * (max - min);
    let rounded = (amount * 100.0).round() / 100.0;
    rounded.clamp(min, max)
}

/// Validate price range arguments.
fn validate_price_range(min: f64, max: f64) -> Result<(), FloatRangeError> {
    if !min.is_finite() || !max.is_finite() {
        return Err(FloatRangeError {
            min,
            max,
            reason: FloatRangeErrorReason::NonFiniteValue,
        });
    }
    if min > max {
        return Err(FloatRangeError {
            min,
            max,
            reason: FloatRangeErrorReason::MinGreaterThanMax,
        });
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_generate_currency_codes_count() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let codes = generate_currency_codes(&mut rng, 100);
        assert_eq!(codes.len(), 100);
    }

    #[test]
    fn test_currency_code_format() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        for _ in 0..100 {
            let code = generate_currency_code(&mut rng);
            assert_eq!(
                code.len(),
                3,
                "Currency code should be 3 characters: {}",
                code
            );
            assert!(
                code.chars().all(|c| c.is_ascii_uppercase()),
                "Currency code should be all uppercase: {}",
                code
            );
        }
    }

    #[test]
    fn test_currency_code_is_valid() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let valid_codes: Vec<&str> = CURRENCIES.iter().map(|(c, _)| *c).collect();
        for _ in 0..100 {
            let code = generate_currency_code(&mut rng);
            assert!(
                valid_codes.contains(&code.as_str()),
                "Currency code should be a known ISO 4217 code: {}",
                code
            );
        }
    }

    #[test]
    fn test_generate_currency_names_count() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let names = generate_currency_names(&mut rng, 100);
        assert_eq!(names.len(), 100);
    }

    #[test]
    fn test_currency_name_not_empty() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        for _ in 0..100 {
            let name = generate_currency_name(&mut rng);
            assert!(!name.is_empty(), "Currency name should not be empty");
        }
    }

    #[test]
    fn test_generate_currencies_count() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let currencies = generate_currencies(&mut rng, 100);
        assert_eq!(currencies.len(), 100);
    }

    #[test]
    fn test_currency_pair_consistency() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let lookup: std::collections::HashMap<&str, &str> =
            CURRENCIES.iter().map(|(c, n)| (*c, *n)).collect();

        for _ in 0..100 {
            let (code, name) = generate_currency(&mut rng);
            assert_eq!(
                lookup.get(code.as_str()),
                Some(&name.as_str()),
                "Code '{}' should map to name '{}'",
                code,
                name
            );
        }
    }

    #[test]
    fn test_generate_prices_count() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let prices = generate_prices(&mut rng, 100, 0.0, 100.0).unwrap();
        assert_eq!(prices.len(), 100);
    }

    #[test]
    fn test_price_range() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        for _ in 0..100 {
            let price = generate_price(&mut rng, 10.0, 50.0).unwrap();
            assert!(
                (10.0..=50.0).contains(&price),
                "Price should be in range: {}",
                price
            );
        }
    }

    #[test]
    fn test_price_two_decimal_places() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        for _ in 0..100 {
            let price = generate_price(&mut rng, 0.01, 999.99).unwrap();
            let rounded = (price * 100.0).round() / 100.0;
            assert!(
                (price - rounded).abs() < 0.001,
                "Price should have 2 decimal places: {}",
                price
            );
        }
    }

    #[test]
    fn test_price_invalid_range() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        assert!(generate_price(&mut rng, 100.0, 10.0).is_err());
        assert!(generate_prices(&mut rng, 10, 100.0, 10.0).is_err());
        assert!(generate_price(&mut rng, f64::NAN, 10.0).is_err());
        assert!(generate_price(&mut rng, 10.0, f64::INFINITY).is_err());
    }

    #[test]
    fn test_empty_batches() {
        let mut rng = ForgeryRng::new();
        assert!(generate_currency_codes(&mut rng, 0).is_empty());
        assert!(generate_currency_names(&mut rng, 0).is_empty());
        assert!(generate_currencies(&mut rng, 0).is_empty());
        assert!(generate_prices(&mut rng, 0, 0.0, 100.0).unwrap().is_empty());
    }

    #[test]
    fn test_deterministic() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(12345);
        rng2.seed(12345);

        let c1 = generate_currency_codes(&mut rng1, 50);
        let c2 = generate_currency_codes(&mut rng2, 50);
        assert_eq!(c1, c2);
    }

    #[test]
    fn test_different_seeds_different_results() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(1);
        rng2.seed(2);

        let c1 = generate_currency_codes(&mut rng1, 50);
        let c2 = generate_currency_codes(&mut rng2, 50);
        assert_ne!(c1, c2);
    }

    #[test]
    fn test_no_duplicate_currencies_in_data() {
        let mut seen = std::collections::HashSet::new();
        for (code, _) in CURRENCIES {
            assert!(
                seen.insert(*code),
                "Duplicate currency code in data: {}",
                code
            );
        }
    }
}

#[cfg(test)]
mod proptest_tests {
    use super::*;
    use proptest::prelude::*;

    proptest! {
        /// Property: currency code batch size is always respected
        #[test]
        fn prop_currency_code_batch_size(n in 0usize..500) {
            let mut rng = ForgeryRng::new();
            rng.seed(42);
            let codes = generate_currency_codes(&mut rng, n);
            prop_assert_eq!(codes.len(), n);
        }

        /// Property: all currency codes are 3 uppercase characters
        #[test]
        fn prop_currency_code_format(n in 1usize..100) {
            let mut rng = ForgeryRng::new();
            rng.seed(42);
            let codes = generate_currency_codes(&mut rng, n);
            for code in codes {
                prop_assert_eq!(code.len(), 3);
                prop_assert!(code.chars().all(|c| c.is_ascii_uppercase()));
            }
        }

        /// Property: prices are within range and have 2 decimal places
        #[test]
        fn prop_price_in_range(
            seed_val in any::<u64>(),
            min_cents in 0i64..100_000,
            range_cents in 1i64..100_000
        ) {
            let min = min_cents as f64 / 100.0;
            let max = min + (range_cents as f64 / 100.0);

            let mut rng = ForgeryRng::new();
            rng.seed(seed_val);

            let price = generate_price(&mut rng, min, max).unwrap();
            prop_assert!(price >= min && price <= max, "Price {} not in [{}, {}]", price, min, max);
            let rounded = (price * 100.0).round() / 100.0;
            prop_assert!((price - rounded).abs() < 0.001);
        }

        /// Property: same seed produces same currency codes
        #[test]
        fn prop_currency_determinism(seed_val in any::<u64>(), n in 1usize..50) {
            let mut rng1 = ForgeryRng::new();
            let mut rng2 = ForgeryRng::new();
            rng1.seed(seed_val);
            rng2.seed(seed_val);

            let c1 = generate_currency_codes(&mut rng1, n);
            let c2 = generate_currency_codes(&mut rng2, n);
            prop_assert_eq!(c1, c2);
        }
    }
}
