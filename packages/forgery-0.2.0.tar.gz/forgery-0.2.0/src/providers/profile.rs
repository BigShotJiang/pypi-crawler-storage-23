//! Profile composition provider.
//!
//! Generates complete user profiles by composing data from multiple providers.
//! Uses BTreeMap for deterministic key ordering, consistent with the records path.

use crate::locale::Locale;
use crate::rng::ForgeryRng;
use crate::validate_batch_size;
use crate::BatchSizeError;
use std::collections::BTreeMap;

use super::{address, company, datetime, internet, names, phone};

/// Generate a single user profile as a BTreeMap (sorted key order).
///
/// Contains: address, city, company, country, date_of_birth, email, first_name,
/// job, last_name, name, phone, state, zip_code.
pub fn generate_profile(rng: &mut ForgeryRng, locale: Locale) -> BTreeMap<String, String> {
    let first = names::generate_first_name(rng, locale);
    let last = names::generate_last_name(rng, locale);
    let full_name = format!("{} {}", first, last);

    let mut profile = BTreeMap::new();
    profile.insert("first_name".to_string(), first);
    profile.insert("last_name".to_string(), last);
    profile.insert("name".to_string(), full_name);
    profile.insert("email".to_string(), internet::generate_email(rng, locale));
    profile.insert(
        "phone".to_string(),
        phone::generate_phone_number(rng, locale),
    );
    profile.insert(
        "address".to_string(),
        address::generate_street_address(rng, locale),
    );
    profile.insert("city".to_string(), address::generate_city(rng, locale));
    profile.insert("state".to_string(), address::generate_state(rng, locale));
    profile.insert(
        "zip_code".to_string(),
        address::generate_zip_code(rng, locale),
    );
    profile.insert("country".to_string(), address::generate_country(rng));
    profile.insert(
        "company".to_string(),
        company::generate_company(rng, locale),
    );
    profile.insert("job".to_string(), company::generate_job(rng, locale));
    profile.insert(
        "date_of_birth".to_string(),
        datetime::generate_date_of_birth(rng, 18, 80).unwrap_or_default(),
    );

    profile
}

/// Generate a batch of user profiles.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_profiles(
    rng: &mut ForgeryRng,
    locale: Locale,
    n: usize,
) -> Result<Vec<BTreeMap<String, String>>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_profile(rng, locale));
    }
    Ok(results)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_profile_contains_all_fields() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let profile = generate_profile(&mut rng, Locale::EnUS);

        let expected_keys = [
            "first_name",
            "last_name",
            "name",
            "email",
            "phone",
            "address",
            "city",
            "state",
            "zip_code",
            "country",
            "company",
            "job",
            "date_of_birth",
        ];

        for key in &expected_keys {
            assert!(profile.contains_key(*key), "Missing key: {}", key);
            assert!(!profile[*key].is_empty(), "Empty value for: {}", key);
        }

        assert_eq!(profile.len(), 13);
    }

    #[test]
    fn test_profile_name_consistency() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let profile = generate_profile(&mut rng, Locale::EnUS);

        let full = &profile["name"];
        let first = &profile["first_name"];
        let last = &profile["last_name"];

        assert_eq!(*full, format!("{} {}", first, last));
    }

    #[test]
    fn test_key_order_is_deterministic() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let profile = generate_profile(&mut rng, Locale::EnUS);
        let keys: Vec<&String> = profile.keys().collect();

        // BTreeMap gives alphabetical order
        assert_eq!(keys[0], "address");
        assert_eq!(keys[1], "city");
        assert_eq!(keys[12], "zip_code");
    }

    #[test]
    fn test_batch_sizes() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        assert_eq!(
            generate_profiles(&mut rng, Locale::EnUS, 0).unwrap().len(),
            0
        );
        assert_eq!(
            generate_profiles(&mut rng, Locale::EnUS, 50).unwrap().len(),
            50
        );
    }

    #[test]
    fn test_determinism() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        let p1 = generate_profile(&mut rng1, Locale::EnUS);
        let p2 = generate_profile(&mut rng2, Locale::EnUS);

        assert_eq!(p1, p2);
    }

    #[test]
    fn test_different_locales() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);
        let profile = generate_profile(&mut rng, Locale::DeDE);
        assert!(profile.contains_key("name"));
        assert!(!profile["name"].is_empty());
    }
}
