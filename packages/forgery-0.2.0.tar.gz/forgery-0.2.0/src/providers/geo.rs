//! Geographic data generation provider.
//!
//! Generates latitudes, longitudes, and coordinate pairs.

use crate::rng::ForgeryRng;

/// Generate a batch of random latitudes.
///
/// Latitudes range from -90.0 (south pole) to 90.0 (north pole), inclusive.
pub fn generate_latitudes(rng: &mut ForgeryRng, n: usize) -> Vec<f64> {
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_latitude(rng));
    }
    results
}

/// Generate a single random latitude in [-90.0, 90.0].
#[inline]
pub fn generate_latitude(rng: &mut ForgeryRng) -> f64 {
    rng.gen_range(-90.0f64, 90.0f64)
}

/// Generate a batch of random longitudes.
///
/// Longitudes range from -180.0 (west) to 180.0 (east), inclusive.
pub fn generate_longitudes(rng: &mut ForgeryRng, n: usize) -> Vec<f64> {
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_longitude(rng));
    }
    results
}

/// Generate a single random longitude in [-180.0, 180.0].
#[inline]
pub fn generate_longitude(rng: &mut ForgeryRng) -> f64 {
    rng.gen_range(-180.0f64, 180.0f64)
}

/// Generate a batch of random coordinate pairs (latitude, longitude).
pub fn generate_coordinates(rng: &mut ForgeryRng, n: usize) -> Vec<(f64, f64)> {
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_coordinate(rng));
    }
    results
}

/// Generate a single random coordinate pair (latitude, longitude).
#[inline]
pub fn generate_coordinate(rng: &mut ForgeryRng) -> (f64, f64) {
    (generate_latitude(rng), generate_longitude(rng))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_latitude_range() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..1000 {
            let lat = generate_latitude(&mut rng);
            assert!(
                (-90.0..=90.0).contains(&lat),
                "latitude {} out of range",
                lat
            );
        }
    }

    #[test]
    fn test_longitude_range() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..1000 {
            let lng = generate_longitude(&mut rng);
            assert!(
                (-180.0..=180.0).contains(&lng),
                "longitude {} out of range",
                lng
            );
        }
    }

    #[test]
    fn test_coordinate_range() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..1000 {
            let (lat, lng) = generate_coordinate(&mut rng);
            assert!(
                (-90.0..=90.0).contains(&lat),
                "latitude {} out of range",
                lat
            );
            assert!(
                (-180.0..=180.0).contains(&lng),
                "longitude {} out of range",
                lng
            );
        }
    }

    #[test]
    fn test_batch_sizes() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        assert_eq!(generate_latitudes(&mut rng, 0).len(), 0);
        assert_eq!(generate_latitudes(&mut rng, 1).len(), 1);
        assert_eq!(generate_latitudes(&mut rng, 100).len(), 100);

        assert_eq!(generate_longitudes(&mut rng, 0).len(), 0);
        assert_eq!(generate_longitudes(&mut rng, 50).len(), 50);

        assert_eq!(generate_coordinates(&mut rng, 0).len(), 0);
        assert_eq!(generate_coordinates(&mut rng, 75).len(), 75);
    }

    #[test]
    fn test_deterministic_with_seed() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        let lats1 = generate_latitudes(&mut rng1, 50);
        let lats2 = generate_latitudes(&mut rng2, 50);
        assert_eq!(lats1, lats2);

        rng1.seed(42);
        rng2.seed(42);
        let coords1 = generate_coordinates(&mut rng1, 50);
        let coords2 = generate_coordinates(&mut rng2, 50);
        assert_eq!(coords1, coords2);
    }

    #[test]
    fn test_latitude_distribution() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let lats = generate_latitudes(&mut rng, 10000);
        let has_negative = lats.iter().any(|&l| l < 0.0);
        let has_positive = lats.iter().any(|&l| l > 0.0);
        assert!(has_negative, "should have negative latitudes");
        assert!(has_positive, "should have positive latitudes");
    }

    #[test]
    fn test_longitude_distribution() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let lngs = generate_longitudes(&mut rng, 10000);
        let has_negative = lngs.iter().any(|&l| l < 0.0);
        let has_positive = lngs.iter().any(|&l| l > 0.0);
        assert!(has_negative, "should have negative longitudes");
        assert!(has_positive, "should have positive longitudes");
    }
}

#[cfg(test)]
mod proptest_tests {
    use super::*;
    use proptest::prelude::*;

    proptest! {
        #[test]
        fn prop_latitude_batch_size_respected(n in 0usize..1000) {
            let mut rng = ForgeryRng::new();
            rng.seed(42);

            let lats = generate_latitudes(&mut rng, n);
            prop_assert_eq!(lats.len(), n);
        }

        #[test]
        fn prop_latitude_in_range(seed_val in any::<u64>()) {
            let mut rng = ForgeryRng::new();
            rng.seed(seed_val);

            let lat = generate_latitude(&mut rng);
            prop_assert!((-90.0..=90.0).contains(&lat), "latitude {} out of range", lat);
        }

        #[test]
        fn prop_longitude_batch_size_respected(n in 0usize..1000) {
            let mut rng = ForgeryRng::new();
            rng.seed(42);

            let lngs = generate_longitudes(&mut rng, n);
            prop_assert_eq!(lngs.len(), n);
        }

        #[test]
        fn prop_longitude_in_range(seed_val in any::<u64>()) {
            let mut rng = ForgeryRng::new();
            rng.seed(seed_val);

            let lng = generate_longitude(&mut rng);
            prop_assert!((-180.0..=180.0).contains(&lng), "longitude {} out of range", lng);
        }

        #[test]
        fn prop_coordinate_in_range(seed_val in any::<u64>()) {
            let mut rng = ForgeryRng::new();
            rng.seed(seed_val);

            let (lat, lng) = generate_coordinate(&mut rng);
            prop_assert!((-90.0..=90.0).contains(&lat), "latitude {} out of range", lat);
            prop_assert!((-180.0..=180.0).contains(&lng), "longitude {} out of range", lng);
        }

        #[test]
        fn prop_seed_determinism(seed_val in any::<u64>(), n in 1usize..100) {
            let mut rng1 = ForgeryRng::new();
            let mut rng2 = ForgeryRng::new();
            rng1.seed(seed_val);
            rng2.seed(seed_val);

            let lats1 = generate_latitudes(&mut rng1, n);
            let lats2 = generate_latitudes(&mut rng2, n);
            prop_assert_eq!(lats1, lats2);
        }
    }
}
