//! String pattern template provider.
//!
//! Provides `numerify`, `letterify`, `bothify`, and `lexify` for replacing
//! placeholder characters in pattern strings with random characters.

use crate::rng::ForgeryRng;
use crate::validate_batch_size;
use crate::BatchSizeError;

/// Replace every `#` in the pattern with a random digit (0-9).
pub fn numerify(rng: &mut ForgeryRng, pattern: &str) -> String {
    pattern
        .chars()
        .map(|c| {
            if c == '#' {
                char::from_digit(rng.gen_range(0u32, 9), 10).unwrap_or('0')
            } else {
                c
            }
        })
        .collect()
}

/// Generate a batch of numerified strings.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn numerify_batch(
    rng: &mut ForgeryRng,
    pattern: &str,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(numerify(rng, pattern));
    }
    Ok(results)
}

/// Replace every `?` in the pattern with a random lowercase letter (a-z).
pub fn letterify(rng: &mut ForgeryRng, pattern: &str) -> String {
    pattern
        .chars()
        .map(|c| {
            if c == '?' {
                (b'a' + rng.gen_range(0u8, 25)) as char
            } else {
                c
            }
        })
        .collect()
}

/// Generate a batch of letterified strings.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn letterify_batch(
    rng: &mut ForgeryRng,
    pattern: &str,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(letterify(rng, pattern));
    }
    Ok(results)
}

/// Replace `#` with digits and `?` with lowercase letters.
pub fn bothify(rng: &mut ForgeryRng, pattern: &str) -> String {
    pattern
        .chars()
        .map(|c| match c {
            '#' => char::from_digit(rng.gen_range(0u32, 9), 10).unwrap_or('0'),
            '?' => (b'a' + rng.gen_range(0u8, 25)) as char,
            _ => c,
        })
        .collect()
}

/// Generate a batch of bothified strings.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn bothify_batch(
    rng: &mut ForgeryRng,
    pattern: &str,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(bothify(rng, pattern));
    }
    Ok(results)
}

/// Replace every `?` in the pattern with a random uppercase letter (A-Z).
pub fn lexify(rng: &mut ForgeryRng, pattern: &str) -> String {
    pattern
        .chars()
        .map(|c| {
            if c == '?' {
                (b'A' + rng.gen_range(0u8, 25)) as char
            } else {
                c
            }
        })
        .collect()
}

/// Generate a batch of lexified strings.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn lexify_batch(
    rng: &mut ForgeryRng,
    pattern: &str,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(lexify(rng, pattern));
    }
    Ok(results)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_numerify_replaces_hashes() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let result = numerify(&mut rng, "###-###-####");
        assert_eq!(result.len(), "###-###-####".len());
        for (i, c) in result.chars().enumerate() {
            if "###-###-####".as_bytes()[i] == b'#' {
                assert!(c.is_ascii_digit(), "Expected digit at {}: {}", i, c);
            } else {
                assert_eq!(c, '-');
            }
        }
    }

    #[test]
    fn test_numerify_no_placeholders() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let result = numerify(&mut rng, "hello");
        assert_eq!(result, "hello");
    }

    #[test]
    fn test_letterify_replaces_questions() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let result = letterify(&mut rng, "??-??");
        assert_eq!(result.len(), 5);
        for (i, c) in result.chars().enumerate() {
            if i == 2 {
                assert_eq!(c, '-');
            } else {
                assert!(c.is_ascii_lowercase(), "Expected lowercase at {}: {}", i, c);
            }
        }
    }

    #[test]
    fn test_bothify_replaces_both() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let result = bothify(&mut rng, "??-##");
        assert_eq!(result.len(), 5);
        assert!(result.chars().next().unwrap().is_ascii_lowercase());
        assert!(result.chars().nth(1).unwrap().is_ascii_lowercase());
        assert_eq!(result.chars().nth(2).unwrap(), '-');
        assert!(result.chars().nth(3).unwrap().is_ascii_digit());
        assert!(result.chars().nth(4).unwrap().is_ascii_digit());
    }

    #[test]
    fn test_lexify_replaces_with_uppercase() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        let result = lexify(&mut rng, "??-##");
        assert!(result.chars().next().unwrap().is_ascii_uppercase());
        assert!(result.chars().nth(1).unwrap().is_ascii_uppercase());
        // # is not replaced by lexify
        assert_eq!(result.chars().nth(2).unwrap(), '-');
        assert_eq!(result.chars().nth(3).unwrap(), '#');
    }

    #[test]
    fn test_batch_sizes() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        assert_eq!(numerify_batch(&mut rng, "###", 0).unwrap().len(), 0);
        assert_eq!(numerify_batch(&mut rng, "###", 1).unwrap().len(), 1);
        assert_eq!(numerify_batch(&mut rng, "###", 100).unwrap().len(), 100);
    }

    #[test]
    fn test_determinism() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        let r1 = numerify(&mut rng1, "###-###");
        let r2 = numerify(&mut rng2, "###-###");
        assert_eq!(r1, r2);

        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        let r1 = bothify(&mut rng1, "??-##");
        let r2 = bothify(&mut rng2, "??-##");
        assert_eq!(r1, r2);
    }

    #[test]
    fn test_empty_pattern() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        assert_eq!(numerify(&mut rng, ""), "");
        assert_eq!(letterify(&mut rng, ""), "");
        assert_eq!(bothify(&mut rng, ""), "");
        assert_eq!(lexify(&mut rng, ""), "");
    }
}
