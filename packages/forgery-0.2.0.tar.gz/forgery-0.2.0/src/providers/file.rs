//! File/system data generation provider.
//!
//! Generates file names, extensions, MIME types, and file paths.

use crate::rng::ForgeryRng;
use crate::validate_batch_size;
use crate::BatchSizeError;

/// File extension and MIME type pairs.
const EXTENSION_MIME: &[(&str, &str)] = &[
    ("pdf", "application/pdf"),
    ("doc", "application/msword"),
    (
        "docx",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ),
    ("xls", "application/vnd.ms-excel"),
    (
        "xlsx",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    ),
    ("ppt", "application/vnd.ms-powerpoint"),
    ("csv", "text/csv"),
    ("txt", "text/plain"),
    ("html", "text/html"),
    ("css", "text/css"),
    ("js", "application/javascript"),
    ("json", "application/json"),
    ("xml", "application/xml"),
    ("zip", "application/zip"),
    ("gz", "application/gzip"),
    ("tar", "application/x-tar"),
    ("png", "image/png"),
    ("jpg", "image/jpeg"),
    ("gif", "image/gif"),
    ("svg", "image/svg+xml"),
    ("webp", "image/webp"),
    ("bmp", "image/bmp"),
    ("ico", "image/x-icon"),
    ("mp3", "audio/mpeg"),
    ("wav", "audio/wav"),
    ("ogg", "audio/ogg"),
    ("mp4", "video/mp4"),
    ("avi", "video/x-msvideo"),
    ("webm", "video/webm"),
    ("mkv", "video/x-matroska"),
    ("ttf", "font/ttf"),
    ("woff", "font/woff"),
    ("woff2", "font/woff2"),
    ("yaml", "application/x-yaml"),
    ("sql", "application/sql"),
    ("py", "text/x-python"),
    ("rs", "text/x-rust"),
    ("java", "text/x-java"),
    ("rb", "text/x-ruby"),
    ("md", "text/markdown"),
];

/// File name words used to build realistic file names.
const FILE_WORDS: &[&str] = &[
    "report",
    "summary",
    "data",
    "backup",
    "invoice",
    "receipt",
    "document",
    "presentation",
    "spreadsheet",
    "image",
    "photo",
    "video",
    "audio",
    "archive",
    "config",
    "readme",
    "notes",
    "draft",
    "final",
    "template",
    "budget",
    "schedule",
    "log",
    "output",
    "input",
    "export",
    "import",
    "results",
    "analysis",
    "chart",
];

/// Directory paths for constructing file paths.
const DIRECTORIES: &[&str] = &[
    "/home/user/documents",
    "/home/user/downloads",
    "/home/user/desktop",
    "/home/user/pictures",
    "/home/user/videos",
    "/home/user/music",
    "/var/log",
    "/var/data",
    "/tmp",
    "/opt/app/data",
    "/usr/local/share",
    "/etc/config",
    "C:\\Users\\User\\Documents",
    "C:\\Users\\User\\Downloads",
    "C:\\Users\\User\\Desktop",
    "/srv/www",
    "/home/user/projects",
    "/home/user/backups",
    "/data/exports",
    "/data/imports",
];

/// Generate a single random file extension.
pub fn generate_file_extension(rng: &mut ForgeryRng) -> String {
    let (ext, _) = rng.choose(EXTENSION_MIME);
    (*ext).to_string()
}

/// Generate a batch of random file extensions.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_file_extensions(
    rng: &mut ForgeryRng,
    n: usize,
) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_file_extension(rng));
    }
    Ok(results)
}

/// Generate a single random file name (e.g., "report.pdf").
pub fn generate_file_name(rng: &mut ForgeryRng) -> String {
    let word = rng.choose(FILE_WORDS);
    let (ext, _) = rng.choose(EXTENSION_MIME);
    format!("{}.{}", word, ext)
}

/// Generate a batch of random file names.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_file_names(rng: &mut ForgeryRng, n: usize) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_file_name(rng));
    }
    Ok(results)
}

/// Generate a single random MIME type (e.g., "application/pdf").
pub fn generate_mime_type(rng: &mut ForgeryRng) -> String {
    let (_, mime) = rng.choose(EXTENSION_MIME);
    (*mime).to_string()
}

/// Generate a batch of random MIME types.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_mime_types(rng: &mut ForgeryRng, n: usize) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_mime_type(rng));
    }
    Ok(results)
}

/// Generate a single random file path (e.g., "/home/user/documents/report.pdf").
pub fn generate_file_path(rng: &mut ForgeryRng) -> String {
    let dir = rng.choose(DIRECTORIES);
    let name = generate_file_name(rng);
    let sep = if dir.contains('\\') { '\\' } else { '/' };
    format!("{}{}{}", dir, sep, name)
}

/// Generate a batch of random file paths.
///
/// # Errors
///
/// Returns `BatchSizeError` if `n` exceeds the maximum batch size.
pub fn generate_file_paths(rng: &mut ForgeryRng, n: usize) -> Result<Vec<String>, BatchSizeError> {
    validate_batch_size(n)?;
    let mut results = Vec::with_capacity(n);
    for _ in 0..n {
        results.push(generate_file_path(rng));
    }
    Ok(results)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_file_extension() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let ext = generate_file_extension(&mut rng);
            assert!(!ext.is_empty());
            assert!(!ext.contains('.'));
            assert!(
                EXTENSION_MIME.iter().any(|(e, _)| *e == ext),
                "Unknown extension: {}",
                ext
            );
        }
    }

    #[test]
    fn test_file_name() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let name = generate_file_name(&mut rng);
            assert!(name.contains('.'), "Missing extension: {}", name);
            let parts: Vec<&str> = name.splitn(2, '.').collect();
            assert_eq!(parts.len(), 2);
            assert!(FILE_WORDS.contains(&parts[0]), "Unknown word: {}", parts[0]);
        }
    }

    #[test]
    fn test_mime_type() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let mime = generate_mime_type(&mut rng);
            assert!(mime.contains('/'), "Invalid MIME type: {}", mime);
        }
    }

    #[test]
    fn test_file_path() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        for _ in 0..100 {
            let path = generate_file_path(&mut rng);
            assert!(
                path.contains('/') || path.contains('\\'),
                "Missing separator: {}",
                path
            );
            // Should contain a file with extension
            assert!(path.contains('.'), "Missing extension in path: {}", path);
        }
    }

    #[test]
    fn test_batch_sizes() {
        let mut rng = ForgeryRng::new();
        rng.seed(42);

        assert_eq!(generate_file_names(&mut rng, 0).unwrap().len(), 0);
        assert_eq!(generate_file_names(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_file_extensions(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_mime_types(&mut rng, 50).unwrap().len(), 50);
        assert_eq!(generate_file_paths(&mut rng, 50).unwrap().len(), 50);
    }

    #[test]
    fn test_determinism() {
        let mut rng1 = ForgeryRng::new();
        let mut rng2 = ForgeryRng::new();
        rng1.seed(42);
        rng2.seed(42);

        assert_eq!(generate_file_name(&mut rng1), generate_file_name(&mut rng2));
    }
}
