"""Tests for forgery."""
