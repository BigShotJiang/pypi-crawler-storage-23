"""Tests for file/system data generation (file_name, file_extension, mime_type, file_path)."""

import re

from forgery import Faker


class TestFileName:
    """Tests for file name generation."""

    def test_single_returns_string(self) -> None:
        """file_name() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.file_name()
        assert isinstance(result, str)

    def test_has_extension(self) -> None:
        """File name should contain a dot separating name and extension."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.file_name()
            assert "." in result, f"Missing extension: {result}"

    def test_format(self) -> None:
        """File name should be word.extension format."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.file_name()
            parts = result.split(".", 1)
            assert len(parts) == 2, f"Invalid file name format: {result}"
            assert len(parts[0]) > 0, f"Empty base name: {result}"
            assert len(parts[1]) > 0, f"Empty extension: {result}"

    def test_batch(self) -> None:
        """file_names should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.file_names(100)
        assert len(results) == 100
        for r in results:
            assert "." in r

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.file_names(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.file_name() == f2.file_name()


class TestFileExtension:
    """Tests for file extension generation."""

    def test_single_returns_string(self) -> None:
        """file_extension() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.file_extension()
        assert isinstance(result, str)

    def test_no_dot(self) -> None:
        """Extension should not contain a dot."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.file_extension()
            assert "." not in result, f"Extension contains dot: {result}"

    def test_not_empty(self) -> None:
        """Extension should not be empty."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.file_extension()
            assert len(result) > 0

    def test_batch(self) -> None:
        """file_extensions should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.file_extensions(100)
        assert len(results) == 100
        for r in results:
            assert "." not in r
            assert len(r) > 0

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.file_extensions(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.file_extension() == f2.file_extension()


class TestMimeType:
    """Tests for MIME type generation."""

    MIME_PATTERN = re.compile(r"^[a-z]+/[\w.+\-]+$")

    def test_single_returns_string(self) -> None:
        """mime_type() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.mime_type()
        assert isinstance(result, str)

    def test_format(self) -> None:
        """MIME type should contain a slash (type/subtype)."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.mime_type()
            assert "/" in result, f"Invalid MIME type: {result}"

    def test_valid_mime_categories(self) -> None:
        """MIME type should have a known category prefix."""
        known_categories = {
            "application",
            "text",
            "image",
            "audio",
            "video",
            "font",
        }
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.mime_type()
            category = result.split("/")[0]
            assert category in known_categories, f"Unknown MIME category: {result}"

    def test_batch(self) -> None:
        """mime_types should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.mime_types(100)
        assert len(results) == 100
        for r in results:
            assert "/" in r

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.mime_types(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.mime_type() == f2.mime_type()


class TestFilePath:
    """Tests for file path generation."""

    def test_single_returns_string(self) -> None:
        """file_path() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.file_path()
        assert isinstance(result, str)

    def test_has_separator(self) -> None:
        """File path should contain a path separator."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.file_path()
            assert "/" in result or "\\" in result, f"Missing separator: {result}"

    def test_has_extension(self) -> None:
        """File path should contain a file with extension."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.file_path()
            assert "." in result, f"Missing extension in path: {result}"

    def test_batch(self) -> None:
        """file_paths should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.file_paths(100)
        assert len(results) == 100
        for r in results:
            assert "/" in r or "\\" in r
            assert "." in r

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.file_paths(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.file_path() == f2.file_path()


class TestFileRecordsSchema:
    """Tests for file types in records schema."""

    def test_file_name_in_schema(self) -> None:
        """'file_name' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"file": "file_name"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["file"], str)
            assert "." in row["file"]

    def test_file_extension_in_schema(self) -> None:
        """'file_extension' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"ext": "file_extension"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["ext"], str)
            assert len(row["ext"]) > 0

    def test_mime_type_in_schema(self) -> None:
        """'mime_type' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"mime": "mime_type"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["mime"], str)
            assert "/" in row["mime"]

    def test_file_path_in_schema(self) -> None:
        """'file_path' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"path": "file_path"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["path"], str)
            assert "." in row["path"]

    def test_mixed_file_schema(self) -> None:
        """All file types should work together in the same schema."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(
            10,
            {
                "name": "file_name",
                "ext": "file_extension",
                "mime": "mime_type",
                "path": "file_path",
            },
        )
        assert len(data) == 10
        for row in data:
            assert "." in row["name"]
            assert len(row["ext"]) > 0
            assert "/" in row["mime"]
            assert "." in row["path"]
