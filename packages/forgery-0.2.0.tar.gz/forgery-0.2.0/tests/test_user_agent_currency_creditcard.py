"""Tests for user agent, currency, and credit card extension providers."""

from typing import ClassVar

import pytest

from forgery import Faker


class TestUserAgent:
    """Tests for user agent generation."""

    def test_user_agent_returns_string(self) -> None:
        result = Faker().user_agent()
        assert isinstance(result, str)
        assert result.startswith("Mozilla/5.0")

    def test_user_agents_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        uas = fake.user_agents(100)
        assert len(uas) == 100
        for ua in uas:
            assert ua.startswith("Mozilla/5.0")

    def test_user_agents_empty(self) -> None:
        assert Faker().user_agents(0) == []

    def test_chrome_format(self) -> None:
        fake = Faker()
        fake.seed(42)
        ua = fake.chrome()
        assert "Chrome/" in ua
        assert "AppleWebKit/537.36" in ua

    def test_chromes_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        uas = fake.chromes(50)
        assert len(uas) == 50
        for ua in uas:
            assert "Chrome/" in ua

    def test_firefox_format(self) -> None:
        fake = Faker()
        fake.seed(42)
        ua = fake.firefox()
        assert "Firefox/" in ua
        assert "Gecko/20100101" in ua

    def test_firefoxes_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        uas = fake.firefoxes(50)
        assert len(uas) == 50
        for ua in uas:
            assert "Firefox/" in ua

    def test_safari_format(self) -> None:
        fake = Faker()
        fake.seed(42)
        ua = fake.safari()
        assert "Version/" in ua
        assert "Safari/605.1.15" in ua
        assert "Macintosh" in ua

    def test_safaris_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        uas = fake.safaris(50)
        assert len(uas) == 50
        for ua in uas:
            assert "Safari/605.1.15" in ua

    def test_deterministic(self) -> None:
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.user_agents(20) == f2.user_agents(20)

    def test_all_browser_types_reachable(self) -> None:
        fake = Faker()
        fake.seed(42)
        uas = fake.user_agents(500)
        has_chrome = any("Chrome/" in ua and "Version/" not in ua for ua in uas)
        has_firefox = any("Firefox/" in ua for ua in uas)
        has_safari = any("Version/" in ua and "Safari/605" in ua for ua in uas)
        assert has_chrome, "Should produce Chrome UAs"
        assert has_firefox, "Should produce Firefox UAs"
        assert has_safari, "Should produce Safari UAs"


class TestCurrency:
    """Tests for currency generation."""

    def test_currency_code_format(self) -> None:
        fake = Faker()
        fake.seed(42)
        code = fake.currency_code()
        assert isinstance(code, str)
        assert len(code) == 3
        assert code.isupper()

    def test_currency_codes_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        codes = fake.currency_codes(100)
        assert len(codes) == 100
        for code in codes:
            assert len(code) == 3
            assert code.isupper()

    def test_currency_codes_empty(self) -> None:
        assert Faker().currency_codes(0) == []

    def test_currency_name_not_empty(self) -> None:
        fake = Faker()
        fake.seed(42)
        name = fake.currency_name()
        assert isinstance(name, str)
        assert len(name) > 0

    def test_currency_names_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        names = fake.currency_names(100)
        assert len(names) == 100

    def test_currency_tuple(self) -> None:
        fake = Faker()
        fake.seed(42)
        result = fake.currency()
        assert isinstance(result, tuple)
        assert len(result) == 2
        code, name = result
        assert len(code) == 3
        assert code.isupper()
        assert len(name) > 0

    def test_currencies_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        results = fake.currencies(50)
        assert len(results) == 50
        for code, name in results:
            assert len(code) == 3
            assert len(name) > 0

    def test_price_range(self) -> None:
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            p = fake.price(10.0, 50.0)
            assert 10.0 <= p <= 50.0

    def test_price_two_decimals(self) -> None:
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            p = fake.price(0.01, 999.99)
            assert abs(p - round(p, 2)) < 0.001

    def test_prices_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        prices = fake.prices(100, 1.0, 100.0)
        assert len(prices) == 100
        for p in prices:
            assert 1.0 <= p <= 100.0

    def test_price_invalid_range(self) -> None:
        fake = Faker()
        with pytest.raises(ValueError):
            fake.price(100.0, 10.0)

    def test_deterministic(self) -> None:
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.currency_codes(20) == f2.currency_codes(20)


class TestCreditCardExtensions:
    """Tests for credit card extension methods."""

    VALID_PROVIDERS: ClassVar[set[str]] = {"Visa", "Mastercard", "American Express", "Discover"}

    def test_credit_card_provider_valid(self) -> None:
        fake = Faker()
        fake.seed(42)
        provider = fake.credit_card_provider()
        assert provider in self.VALID_PROVIDERS

    def test_credit_card_providers_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        providers = fake.credit_card_providers(100)
        assert len(providers) == 100
        for p in providers:
            assert p in self.VALID_PROVIDERS

    def test_credit_card_providers_empty(self) -> None:
        assert Faker().credit_card_providers(0) == []

    def test_credit_card_expire_format(self) -> None:
        fake = Faker()
        fake.seed(42)
        expire = fake.credit_card_expire()
        assert isinstance(expire, str)
        assert len(expire) == 5
        assert expire[2] == "/"
        month = int(expire[:2])
        assert 1 <= month <= 12

    def test_credit_card_expires_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        expires = fake.credit_card_expires(100)
        assert len(expires) == 100
        for expire in expires:
            assert len(expire) == 5
            assert expire[2] == "/"

    def test_credit_card_security_code_format(self) -> None:
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            code = fake.credit_card_security_code()
            assert len(code) in (3, 4), f"CVV should be 3 or 4 digits: {code}"
            assert code.isdigit(), f"CVV should be all digits: {code}"

    def test_credit_card_security_codes_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        codes = fake.credit_card_security_codes(100)
        assert len(codes) == 100

    def test_credit_card_full_structure(self) -> None:
        fake = Faker()
        fake.seed(42)
        card = fake.credit_card_full()
        assert isinstance(card, dict)
        assert "provider" in card
        assert "number" in card
        assert "expire" in card
        assert "security_code" in card
        assert "name" in card
        assert card["provider"] in self.VALID_PROVIDERS
        assert card["expire"][2] == "/"
        assert len(card["security_code"]) in (3, 4)
        assert len(card["name"]) > 0

    def test_credit_card_full_provider_consistency(self) -> None:
        """Amex cards should have 4-digit CVV and 15-digit number."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            card = fake.credit_card_full()
            if card["provider"] == "American Express":
                assert len(card["security_code"]) == 4
                assert len(card["number"]) == 15
            else:
                assert len(card["security_code"]) == 3
                assert len(card["number"]) == 16

    def test_credit_card_fulls_batch(self) -> None:
        fake = Faker()
        fake.seed(42)
        cards = fake.credit_card_fulls(50)
        assert len(cards) == 50
        for card in cards:
            assert "provider" in card
            assert "number" in card

    def test_credit_card_full_deterministic(self) -> None:
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.credit_card_fulls(10) == f2.credit_card_fulls(10)

    def test_all_providers_reachable(self) -> None:
        fake = Faker()
        fake.seed(42)
        providers = set(fake.credit_card_providers(500))
        assert providers == self.VALID_PROVIDERS


class TestConvenienceFunctions:
    """Tests for module-level convenience functions."""

    def test_user_agent_convenience(self) -> None:
        from forgery import user_agent, user_agents

        ua = user_agent()
        assert ua.startswith("Mozilla/5.0")
        uas = user_agents(10)
        assert len(uas) == 10

    def test_chrome_convenience(self) -> None:
        from forgery import chrome, chromes

        assert "Chrome/" in chrome()
        assert len(chromes(5)) == 5

    def test_firefox_convenience(self) -> None:
        from forgery import firefox, firefoxes

        assert "Firefox/" in firefox()
        assert len(firefoxes(5)) == 5

    def test_safari_convenience(self) -> None:
        from forgery import safari, safaris

        assert "Safari/605.1.15" in safari()
        assert len(safaris(5)) == 5

    def test_currency_code_convenience(self) -> None:
        from forgery import currency_code, currency_codes

        code = currency_code()
        assert len(code) == 3
        assert len(currency_codes(10)) == 10

    def test_currency_name_convenience(self) -> None:
        from forgery import currency_name, currency_names

        assert len(currency_name()) > 0
        assert len(currency_names(10)) == 10

    def test_currency_convenience(self) -> None:
        from forgery import currencies, currency

        code, _name = currency()
        assert len(code) == 3
        assert len(currencies(10)) == 10

    def test_price_convenience(self) -> None:
        from forgery import price, prices

        p = price(1.0, 100.0)
        assert 1.0 <= p <= 100.0
        assert len(prices(10, 1.0, 100.0)) == 10

    def test_credit_card_provider_convenience(self) -> None:
        from forgery import credit_card_provider, credit_card_providers

        assert credit_card_provider() in {
            "Visa",
            "Mastercard",
            "American Express",
            "Discover",
        }
        assert len(credit_card_providers(10)) == 10

    def test_credit_card_expire_convenience(self) -> None:
        from forgery import credit_card_expire, credit_card_expires

        assert len(credit_card_expire()) == 5
        assert len(credit_card_expires(10)) == 10

    def test_credit_card_security_code_convenience(self) -> None:
        from forgery import credit_card_security_code, credit_card_security_codes

        code = credit_card_security_code()
        assert len(code) in (3, 4)
        assert len(credit_card_security_codes(10)) == 10

    def test_credit_card_full_convenience(self) -> None:
        from forgery import credit_card_full, credit_card_fulls

        card = credit_card_full()
        assert "provider" in card
        assert len(credit_card_fulls(10)) == 10
