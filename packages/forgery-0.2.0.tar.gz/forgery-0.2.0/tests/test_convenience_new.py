"""Tests for new module-level convenience functions to ensure coverage."""

import forgery


class TestPatternConvenience:
    """Tests for pattern template convenience functions."""

    def test_numerify(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.numerify("###"), str)
        assert len(forgery.numerify("###")) == 3

    def test_numerify_batch(self) -> None:
        forgery.seed(42)
        assert len(forgery.numerify_batch("###", 5)) == 5

    def test_letterify(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.letterify("???"), str)

    def test_letterify_batch(self) -> None:
        forgery.seed(42)
        assert len(forgery.letterify_batch("???", 5)) == 5

    def test_bothify(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.bothify("?#?#"), str)

    def test_bothify_batch(self) -> None:
        forgery.seed(42)
        assert len(forgery.bothify_batch("?#", 5)) == 5

    def test_lexify(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.lexify("???"), str)

    def test_lexify_batch(self) -> None:
        forgery.seed(42)
        assert len(forgery.lexify_batch("???", 5)) == 5


class TestBarcodeConvenience:
    """Tests for barcode convenience functions."""

    def test_ean13(self) -> None:
        forgery.seed(42)
        assert len(forgery.ean13()) == 13

    def test_ean13s(self) -> None:
        forgery.seed(42)
        assert len(forgery.ean13s(5)) == 5

    def test_ean8(self) -> None:
        forgery.seed(42)
        assert len(forgery.ean8()) == 8

    def test_ean8s(self) -> None:
        forgery.seed(42)
        assert len(forgery.ean8s(5)) == 5

    def test_upc_a(self) -> None:
        forgery.seed(42)
        assert len(forgery.upc_a()) == 12

    def test_upc_as(self) -> None:
        forgery.seed(42)
        assert len(forgery.upc_as(5)) == 5

    def test_upc_e(self) -> None:
        forgery.seed(42)
        assert len(forgery.upc_e()) == 8

    def test_upc_es(self) -> None:
        forgery.seed(42)
        assert len(forgery.upc_es(5)) == 5


class TestIsbnConvenience:
    """Tests for ISBN convenience functions."""

    def test_isbn10(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.isbn10(), str)

    def test_isbn10s(self) -> None:
        forgery.seed(42)
        assert len(forgery.isbn10s(5)) == 5

    def test_isbn13(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.isbn13(), str)

    def test_isbn13s(self) -> None:
        forgery.seed(42)
        assert len(forgery.isbn13s(5)) == 5


class TestFileConvenience:
    """Tests for file/system convenience functions."""

    def test_file_name(self) -> None:
        forgery.seed(42)
        assert "." in forgery.file_name()

    def test_file_names(self) -> None:
        forgery.seed(42)
        assert len(forgery.file_names(5)) == 5

    def test_file_extension(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.file_extension(), str)

    def test_file_extensions(self) -> None:
        forgery.seed(42)
        assert len(forgery.file_extensions(5)) == 5

    def test_mime_type(self) -> None:
        forgery.seed(42)
        assert "/" in forgery.mime_type()

    def test_mime_types(self) -> None:
        forgery.seed(42)
        assert len(forgery.mime_types(5)) == 5

    def test_file_path_(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.file_path_(), str)

    def test_file_paths(self) -> None:
        forgery.seed(42)
        assert len(forgery.file_paths(5)) == 5


class TestCommerceConvenience:
    """Tests for commerce convenience functions."""

    def test_product_name(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.product_name(), str)

    def test_product_names(self) -> None:
        forgery.seed(42)
        assert len(forgery.product_names(5)) == 5

    def test_product_category(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.product_category(), str)

    def test_product_categories(self) -> None:
        forgery.seed(42)
        assert len(forgery.product_categories(5)) == 5

    def test_department(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.department(), str)

    def test_departments(self) -> None:
        forgery.seed(42)
        assert len(forgery.departments(5)) == 5

    def test_product_material(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.product_material(), str)

    def test_product_materials(self) -> None:
        forgery.seed(42)
        assert len(forgery.product_materials(5)) == 5


class TestSsnConvenience:
    """Tests for SSN convenience functions."""

    def test_ssn(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.ssn(), str)

    def test_ssns(self) -> None:
        forgery.seed(42)
        assert len(forgery.ssns(5)) == 5


class TestVehicleConvenience:
    """Tests for vehicle convenience functions."""

    def test_license_plate(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.license_plate(), str)

    def test_license_plates(self) -> None:
        forgery.seed(42)
        assert len(forgery.license_plates(5)) == 5

    def test_vehicle_make(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.vehicle_make(), str)

    def test_vehicle_makes(self) -> None:
        forgery.seed(42)
        assert len(forgery.vehicle_makes(5)) == 5

    def test_vehicle_model(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.vehicle_model(), str)

    def test_vehicle_models(self) -> None:
        forgery.seed(42)
        assert len(forgery.vehicle_models(5)) == 5

    def test_vehicle_year(self) -> None:
        forgery.seed(42)
        assert isinstance(forgery.vehicle_year(), int)

    def test_vehicle_years(self) -> None:
        forgery.seed(42)
        assert len(forgery.vehicle_years(5)) == 5

    def test_vin(self) -> None:
        forgery.seed(42)
        assert len(forgery.vin()) == 17

    def test_vins(self) -> None:
        forgery.seed(42)
        assert len(forgery.vins(5)) == 5


class TestProfileConvenience:
    """Tests for profile convenience functions."""

    def test_profile(self) -> None:
        forgery.seed(42)
        p = forgery.profile()
        assert isinstance(p, dict)
        assert "name" in p

    def test_profiles(self) -> None:
        forgery.seed(42)
        ps = forgery.profiles(5)
        assert len(ps) == 5
