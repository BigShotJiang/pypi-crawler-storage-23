"""Tests for commerce/product data generation."""

from forgery import Faker


class TestProductName:
    """Tests for product name generation."""

    def test_single_returns_string(self) -> None:
        """product_name() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.product_name()
        assert isinstance(result, str)

    def test_has_three_parts(self) -> None:
        """Product name should have adjective + material + product (3 words)."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.product_name()
            # "Carbon Fiber" is a 2-word material, so split on the first 2 spaces
            # to check we have at least 3 parts
            parts = result.split()
            assert len(parts) >= 3, f"Product name too short: {result}"

    def test_not_empty(self) -> None:
        """Product name should not be empty."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.product_name()
            assert len(result) > 0

    def test_batch(self) -> None:
        """product_names should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.product_names(100)
        assert len(results) == 100
        for r in results:
            assert isinstance(r, str)
            assert len(r) > 0

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.product_names(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.product_name() == f2.product_name()

    def test_batch_deterministic(self) -> None:
        """Same seed should produce same batch results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.product_names(50) == f2.product_names(50)


class TestProductCategory:
    """Tests for product category generation."""

    def test_single_returns_string(self) -> None:
        """product_category() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.product_category()
        assert isinstance(result, str)

    def test_not_empty(self) -> None:
        """Product category should not be empty."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.product_category()
            assert len(result) > 0

    def test_batch(self) -> None:
        """product_categories should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.product_categories(100)
        assert len(results) == 100
        for r in results:
            assert isinstance(r, str)
            assert len(r) > 0

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.product_categories(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.product_category() == f2.product_category()

    def test_variety(self) -> None:
        """Should produce a variety of categories."""
        fake = Faker()
        fake.seed(42)
        results = fake.product_categories(500)
        unique = set(results)
        assert len(unique) > 5, f"Too few unique categories: {len(unique)}"


class TestDepartment:
    """Tests for department name generation."""

    def test_single_returns_string(self) -> None:
        """department() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.department()
        assert isinstance(result, str)

    def test_not_empty(self) -> None:
        """Department name should not be empty."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.department()
            assert len(result) > 0

    def test_batch(self) -> None:
        """departments should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.departments(100)
        assert len(results) == 100
        for r in results:
            assert isinstance(r, str)
            assert len(r) > 0

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.departments(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.department() == f2.department()


class TestProductMaterial:
    """Tests for product material generation."""

    def test_single_returns_string(self) -> None:
        """product_material() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.product_material()
        assert isinstance(result, str)

    def test_not_empty(self) -> None:
        """Product material should not be empty."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.product_material()
            assert len(result) > 0

    def test_batch(self) -> None:
        """product_materials should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.product_materials(100)
        assert len(results) == 100
        for r in results:
            assert isinstance(r, str)
            assert len(r) > 0

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.product_materials(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.product_material() == f2.product_material()

    def test_variety(self) -> None:
        """Should produce a variety of materials."""
        fake = Faker()
        fake.seed(42)
        results = fake.product_materials(500)
        unique = set(results)
        assert len(unique) > 5, f"Too few unique materials: {len(unique)}"


class TestCommerceRecordsSchema:
    """Tests for commerce types in records schema."""

    def test_product_name_in_schema(self) -> None:
        """'product_name' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"product": "product_name"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["product"], str)
            assert len(row["product"]) > 0

    def test_product_category_in_schema(self) -> None:
        """'product_category' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"category": "product_category"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["category"], str)
            assert len(row["category"]) > 0

    def test_department_in_schema(self) -> None:
        """'department' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"dept": "department"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["dept"], str)
            assert len(row["dept"]) > 0

    def test_product_material_in_schema(self) -> None:
        """'product_material' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"material": "product_material"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["material"], str)
            assert len(row["material"]) > 0

    def test_mixed_commerce_schema(self) -> None:
        """All commerce types should work together in the same schema."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(
            10,
            {
                "product": "product_name",
                "category": "product_category",
                "department": "department",
                "material": "product_material",
            },
        )
        assert len(data) == 10
        for row in data:
            assert len(row["product"]) > 0
            assert len(row["category"]) > 0
            assert len(row["department"]) > 0
            assert len(row["material"]) > 0
