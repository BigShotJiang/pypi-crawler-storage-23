"""Tests for ISBN generation (ISBN-10 and ISBN-13)."""

import re

from forgery import Faker


def _validate_isbn10(isbn: str) -> bool:
    """Validate an ISBN-10 check digit."""
    chars = [c for c in isbn if c.isdigit() or c == "X"]
    if len(chars) != 10:
        return False
    total = sum((10 if c == "X" else int(c)) * (i + 1) for i, c in enumerate(chars))
    return total % 11 == 0


def _validate_isbn13(isbn: str) -> bool:
    """Validate an ISBN-13 check digit."""
    digits = [int(c) for c in isbn if c.isdigit()]
    if len(digits) != 13:
        return False
    payload = digits[:12]
    weighted_sum = sum(d * (1 if i % 2 == 0 else 3) for i, d in enumerate(payload))
    expected = (10 - (weighted_sum % 10)) % 10
    return expected == digits[12]


class TestIsbn10:
    """Tests for ISBN-10 generation."""

    # Format: X-XXX-XXXXX-C (with hyphens)
    ISBN10_PATTERN = re.compile(r"^\d-\d{3}-\d{5}-[\dX]$")

    def test_single_returns_string(self) -> None:
        """isbn10() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.isbn10()
        assert isinstance(result, str)

    def test_format(self) -> None:
        """ISBN-10 should have correct hyphenated format."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.isbn10()
            assert self.ISBN10_PATTERN.match(result), f"Invalid ISBN-10 format: {result}"

    def test_contains_hyphens(self) -> None:
        """ISBN-10 should contain hyphens."""
        fake = Faker()
        fake.seed(42)
        result = fake.isbn10()
        assert "-" in result

    def test_has_10_digit_chars(self) -> None:
        """ISBN-10 should have exactly 10 digit/X characters when hyphens removed."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.isbn10()
            chars = [c for c in result if c.isdigit() or c == "X"]
            assert len(chars) == 10, f"Wrong digit count in: {result}"

    def test_check_digit_valid(self) -> None:
        """ISBN-10 check digit should be valid."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.isbn10()
            assert _validate_isbn10(result), f"Invalid ISBN-10 check digit: {result}"

    def test_batch(self) -> None:
        """isbn10s should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.isbn10s(100)
        assert len(results) == 100
        for r in results:
            assert self.ISBN10_PATTERN.match(r)
            assert _validate_isbn10(r)

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.isbn10s(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.isbn10() == f2.isbn10()

    def test_batch_deterministic(self) -> None:
        """Same seed should produce same batch results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.isbn10s(50) == f2.isbn10s(50)


class TestIsbn13:
    """Tests for ISBN-13 generation."""

    # Format: PPP-X-XXX-XXXXX-C (with hyphens, prefix 978 or 979)
    ISBN13_PATTERN = re.compile(r"^97[89]-\d-\d{3}-\d{5}-\d$")

    def test_single_returns_string(self) -> None:
        """isbn13() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.isbn13()
        assert isinstance(result, str)

    def test_format(self) -> None:
        """ISBN-13 should have correct hyphenated format."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.isbn13()
            assert self.ISBN13_PATTERN.match(result), f"Invalid ISBN-13 format: {result}"

    def test_starts_with_978_or_979(self) -> None:
        """ISBN-13 should start with 978 or 979."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.isbn13()
            assert result.startswith("978") or result.startswith("979"), (
                f"Invalid ISBN-13 prefix: {result}"
            )

    def test_has_13_digits(self) -> None:
        """ISBN-13 should have exactly 13 digits when hyphens removed."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.isbn13()
            digits = [c for c in result if c.isdigit()]
            assert len(digits) == 13, f"Wrong digit count in: {result}"

    def test_check_digit_valid(self) -> None:
        """ISBN-13 check digit should be valid."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.isbn13()
            assert _validate_isbn13(result), f"Invalid ISBN-13 check digit: {result}"

    def test_batch(self) -> None:
        """isbn13s should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.isbn13s(100)
        assert len(results) == 100
        for r in results:
            assert self.ISBN13_PATTERN.match(r)
            assert _validate_isbn13(r)

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.isbn13s(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.isbn13() == f2.isbn13()

    def test_batch_deterministic(self) -> None:
        """Same seed should produce same batch results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.isbn13s(50) == f2.isbn13s(50)


class TestIsbnRecordsSchema:
    """Tests for ISBN types in records schema."""

    def test_isbn10_in_schema(self) -> None:
        """'isbn10' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"isbn": "isbn10"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["isbn"], str)
            assert "-" in row["isbn"]
            assert _validate_isbn10(row["isbn"])

    def test_isbn13_in_schema(self) -> None:
        """'isbn13' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"isbn": "isbn13"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["isbn"], str)
            assert row["isbn"].startswith("978") or row["isbn"].startswith("979")
            assert _validate_isbn13(row["isbn"])

    def test_mixed_isbn_schema(self) -> None:
        """Both ISBN types should work in the same schema."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"isbn10": "isbn10", "isbn13": "isbn13"})
        assert len(data) == 10
        for row in data:
            assert _validate_isbn10(row["isbn10"])
            assert _validate_isbn13(row["isbn13"])
