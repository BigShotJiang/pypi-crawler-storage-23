"""Tests for boolean generation."""

import pytest

from forgery import (
    Faker,
    boolean,
    booleans,
    records,
    records_arrow,
    seed,
)

# Check if pyarrow is available for arrow tests
try:
    import pyarrow as pa  # noqa: F401

    HAS_PYARROW = True
except ImportError:
    HAS_PYARROW = False


class TestBoolean:
    """Tests for single boolean generation."""

    def test_returns_bool_type(self) -> None:
        """boolean() should return a Python bool."""
        seed(42)
        result = boolean()
        assert isinstance(result, bool)

    def test_default_probability(self) -> None:
        """Default probability (0.5) should produce a mix of True/False."""
        seed(42)
        results = [boolean() for _ in range(1000)]
        true_count = sum(results)
        assert 300 < true_count < 700, f"unexpected true count: {true_count}"

    def test_probability_always_true(self) -> None:
        """probability=1.0 should always return True."""
        seed(42)
        for _ in range(100):
            assert boolean(1.0) is True

    def test_probability_always_false(self) -> None:
        """probability=0.0 should always return False."""
        seed(42)
        for _ in range(100):
            assert boolean(0.0) is False

    def test_invalid_probability_negative(self) -> None:
        """Negative probability should raise ValueError."""
        with pytest.raises(ValueError, match="probability"):
            boolean(-0.1)

    def test_invalid_probability_over_one(self) -> None:
        """Probability > 1.0 should raise ValueError."""
        with pytest.raises(ValueError):
            boolean(1.1)


class TestBooleans:
    """Tests for batch boolean generation."""

    def test_batch_size(self) -> None:
        """booleans(n) should return n items."""
        seed(42)
        result = booleans(100)
        assert len(result) == 100
        assert all(isinstance(b, bool) for b in result)

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        result = booleans(0)
        assert result == []

    def test_batch_always_true(self) -> None:
        """probability=1.0 should produce all True."""
        seed(42)
        result = booleans(100, probability=1.0)
        assert all(b is True for b in result)

    def test_batch_always_false(self) -> None:
        """probability=0.0 should produce all False."""
        seed(42)
        result = booleans(100, probability=0.0)
        assert all(b is False for b in result)

    def test_batch_high_probability(self) -> None:
        """probability=0.9 should produce mostly True."""
        seed(42)
        result = booleans(10000, probability=0.9)
        true_count = sum(result)
        assert true_count > 8500

    def test_batch_low_probability(self) -> None:
        """probability=0.1 should produce mostly False."""
        seed(42)
        result = booleans(10000, probability=0.1)
        true_count = sum(result)
        assert true_count < 1500

    def test_deterministic_with_seed(self) -> None:
        """Same seed should produce same booleans."""
        seed(42)
        result1 = booleans(100)
        seed(42)
        result2 = booleans(100)
        assert result1 == result2

    def test_invalid_probability_in_batch(self) -> None:
        """Invalid probability should raise ValueError for batch too."""
        with pytest.raises(ValueError):
            booleans(10, probability=-0.5)

        with pytest.raises(ValueError):
            booleans(10, probability=2.0)


class TestBatchSizeLimits:
    """Tests for batch size validation."""

    MAX_BATCH_SIZE = 10_000_000

    def test_booleans_exceeds_limit(self) -> None:
        """booleans(n > limit) should raise ValueError."""
        with pytest.raises(ValueError):
            booleans(self.MAX_BATCH_SIZE + 1)


class TestFakerClassMethods:
    """Tests for Faker class methods."""

    def test_faker_boolean(self) -> None:
        """Faker.boolean() should work."""
        fake = Faker()
        fake.seed(42)
        result = fake.boolean()
        assert isinstance(result, bool)

    def test_faker_boolean_with_probability(self) -> None:
        """Faker.boolean(probability) should work."""
        fake = Faker()
        fake.seed(42)
        assert fake.boolean(1.0) is True
        assert fake.boolean(0.0) is False

    def test_faker_booleans(self) -> None:
        """Faker.booleans() should work."""
        fake = Faker()
        fake.seed(42)
        result = fake.booleans(100)
        assert len(result) == 100
        assert all(isinstance(b, bool) for b in result)

    def test_faker_booleans_with_probability(self) -> None:
        """Faker.booleans(n, probability) should work."""
        fake = Faker()
        fake.seed(42)
        result = fake.booleans(100, 1.0)
        assert all(b is True for b in result)


class TestRecordsSchema:
    """Tests for boolean type in records schema."""

    def test_boolean_in_schema(self) -> None:
        """'boolean' should work as a records schema type."""
        seed(42)
        result = records(10, {"active": "boolean"})
        assert len(result) == 10
        for row in result:
            assert isinstance(row["active"], bool)

    def test_boolean_produces_both_values(self) -> None:
        """Boolean in schema should produce both True and False."""
        seed(42)
        result = records(1000, {"flag": "boolean"})
        values = {row["flag"] for row in result}
        assert True in values
        assert False in values


@pytest.mark.skipif(not HAS_PYARROW, reason="pyarrow not installed")
class TestRecordsArrow:
    """Tests for boolean type in Arrow output."""

    def test_boolean_in_arrow(self) -> None:
        """'boolean' should produce Boolean type in Arrow."""
        seed(42)
        batch = records_arrow(100, {"active": "boolean"})
        assert batch.num_rows == 100
        # Arrow boolean column
        col = batch.column("active")
        values = col.to_pylist()
        assert all(isinstance(v, bool) for v in values)
        # Should have both True and False in 100 values
        assert True in values
        assert False in values
