"""Tests for string pattern template providers (numerify, letterify, bothify, lexify)."""

import re

from forgery import Faker


class TestNumerify:
    """Tests for numerify (replace # with digits)."""

    def test_single_returns_string(self) -> None:
        """numerify() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.numerify("###-###-####")
        assert isinstance(result, str)

    def test_replaces_hashes_with_digits(self) -> None:
        """Every # should become a digit, other characters preserved."""
        fake = Faker()
        fake.seed(42)
        result = fake.numerify("###-###-####")
        pattern = re.compile(r"^\d{3}-\d{3}-\d{4}$")
        assert pattern.match(result), f"Unexpected format: {result}"

    def test_no_placeholders_unchanged(self) -> None:
        """Pattern without # should be returned unchanged."""
        fake = Faker()
        fake.seed(42)
        result = fake.numerify("hello")
        assert result == "hello"

    def test_empty_pattern(self) -> None:
        """Empty pattern should return empty string."""
        fake = Faker()
        fake.seed(42)
        result = fake.numerify("")
        assert result == ""

    def test_batch_returns_correct_count(self) -> None:
        """numerify_batch should return n items."""
        fake = Faker()
        fake.seed(42)
        results = fake.numerify_batch("###", 100)
        assert len(results) == 100
        for r in results:
            assert re.match(r"^\d{3}$", r), f"Unexpected format: {r}"

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        fake.seed(42)
        results = fake.numerify_batch("###", 0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.numerify("###-####") == f2.numerify("###-####")

    def test_batch_deterministic(self) -> None:
        """Same seed should produce same batch results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.numerify_batch("##", 50) == f2.numerify_batch("##", 50)


class TestLetterify:
    """Tests for letterify (replace ? with lowercase letters)."""

    def test_replaces_questions_with_lowercase(self) -> None:
        """Every ? should become a lowercase letter."""
        fake = Faker()
        fake.seed(42)
        result = fake.letterify("??-??")
        pattern = re.compile(r"^[a-z]{2}-[a-z]{2}$")
        assert pattern.match(result), f"Unexpected format: {result}"

    def test_no_placeholders_unchanged(self) -> None:
        """Pattern without ? should be returned unchanged."""
        fake = Faker()
        fake.seed(42)
        result = fake.letterify("hello")
        assert result == "hello"

    def test_empty_pattern(self) -> None:
        """Empty pattern should return empty string."""
        fake = Faker()
        fake.seed(42)
        assert fake.letterify("") == ""

    def test_batch(self) -> None:
        """letterify_batch should return correct count with valid format."""
        fake = Faker()
        fake.seed(42)
        results = fake.letterify_batch("???", 100)
        assert len(results) == 100
        for r in results:
            assert re.match(r"^[a-z]{3}$", r), f"Unexpected format: {r}"

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.letterify("??-??") == f2.letterify("??-??")


class TestBothify:
    """Tests for bothify (replace # with digits and ? with lowercase letters)."""

    def test_replaces_both_placeholders(self) -> None:
        """# should become digits, ? should become lowercase letters."""
        fake = Faker()
        fake.seed(42)
        result = fake.bothify("??-##")
        assert len(result) == 5
        assert result[0].islower()
        assert result[1].islower()
        assert result[2] == "-"
        assert result[3].isdigit()
        assert result[4].isdigit()

    def test_complex_pattern(self) -> None:
        """Complex pattern should be handled correctly."""
        fake = Faker()
        fake.seed(42)
        result = fake.bothify("?#?#-##??")
        pattern = re.compile(r"^[a-z]\d[a-z]\d-\d{2}[a-z]{2}$")
        assert pattern.match(result), f"Unexpected format: {result}"

    def test_empty_pattern(self) -> None:
        """Empty pattern should return empty string."""
        fake = Faker()
        fake.seed(42)
        assert fake.bothify("") == ""

    def test_batch(self) -> None:
        """bothify_batch should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.bothify_batch("??##", 100)
        assert len(results) == 100
        for r in results:
            assert re.match(r"^[a-z]{2}\d{2}$", r), f"Unexpected format: {r}"

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.bothify("??-##") == f2.bothify("??-##")


class TestLexify:
    """Tests for lexify (replace ? with uppercase letters)."""

    def test_replaces_questions_with_uppercase(self) -> None:
        """Every ? should become an uppercase letter."""
        fake = Faker()
        fake.seed(42)
        result = fake.lexify("??-??")
        pattern = re.compile(r"^[A-Z]{2}-[A-Z]{2}$")
        assert pattern.match(result), f"Unexpected format: {result}"

    def test_does_not_replace_hash(self) -> None:
        """lexify should not replace # characters."""
        fake = Faker()
        fake.seed(42)
        result = fake.lexify("??-##")
        assert result[2] == "-"
        assert result[3] == "#"
        assert result[4] == "#"

    def test_empty_pattern(self) -> None:
        """Empty pattern should return empty string."""
        fake = Faker()
        fake.seed(42)
        assert fake.lexify("") == ""

    def test_batch(self) -> None:
        """lexify_batch should return correct count with valid format."""
        fake = Faker()
        fake.seed(42)
        results = fake.lexify_batch("???", 100)
        assert len(results) == 100
        for r in results:
            assert re.match(r"^[A-Z]{3}$", r), f"Unexpected format: {r}"

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.lexify("???") == f2.lexify("???")


class TestPatternRecordsSchema:
    """Tests for pattern types in records schema.

    Note: pattern providers (numerify, letterify, etc.) require a pattern argument
    and are not available as simple records schema types. This class tests that
    the pattern methods work correctly on Faker instances used alongside records.
    """

    def test_pattern_with_records_workflow(self) -> None:
        """Pattern methods should work alongside records on the same Faker instance."""
        fake = Faker()
        fake.seed(42)
        # Generate some records
        data = fake.records(5, {"name": "name"})
        assert len(data) == 5
        # Then use pattern methods on the same instance
        code = fake.numerify("###-####")
        assert len(code) == 8
