"""Tests for profile composition provider."""

import pytest

from forgery import Faker

SUPPORTED_LOCALES = ["en_US", "en_GB", "de_DE", "fr_FR", "es_ES", "it_IT", "ja_JP"]

EXPECTED_KEYS = [
    "first_name",
    "last_name",
    "name",
    "email",
    "phone",
    "address",
    "city",
    "state",
    "zip_code",
    "country",
    "company",
    "job",
    "date_of_birth",
]


class TestProfile:
    """Tests for single profile generation."""

    def test_returns_dict(self) -> None:
        """profile() should return a dictionary."""
        fake = Faker()
        fake.seed(42)
        result = fake.profile()
        assert isinstance(result, dict)

    def test_has_all_expected_keys(self) -> None:
        """Profile should contain all 13 expected keys."""
        fake = Faker()
        fake.seed(42)
        result = fake.profile()
        for key in EXPECTED_KEYS:
            assert key in result, f"Missing key: {key}"
        assert len(result) == 13

    def test_all_values_non_empty(self) -> None:
        """All profile values should be non-empty strings."""
        fake = Faker()
        fake.seed(42)
        result = fake.profile()
        for key in EXPECTED_KEYS:
            assert isinstance(result[key], str), f"{key} is not a string"
            assert len(result[key]) > 0, f"{key} is empty"

    def test_name_consistency(self) -> None:
        """Full name should be first_name + last_name."""
        fake = Faker()
        fake.seed(42)
        result = fake.profile()
        expected_name = f"{result['first_name']} {result['last_name']}"
        assert result["name"] == expected_name

    def test_email_has_at_sign(self) -> None:
        """Profile email should contain @."""
        fake = Faker()
        fake.seed(42)
        result = fake.profile()
        assert "@" in result["email"]

    def test_deterministic(self) -> None:
        """Same seed should produce same profile."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.profile() == f2.profile()


class TestProfiles:
    """Tests for batch profile generation."""

    def test_batch_returns_list(self) -> None:
        """profiles() should return a list."""
        fake = Faker()
        fake.seed(42)
        results = fake.profiles(10)
        assert isinstance(results, list)
        assert len(results) == 10

    def test_batch_each_has_all_keys(self) -> None:
        """Each profile in a batch should have all expected keys."""
        fake = Faker()
        fake.seed(42)
        results = fake.profiles(50)
        for profile in results:
            assert isinstance(profile, dict)
            for key in EXPECTED_KEYS:
                assert key in profile, f"Missing key: {key}"

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.profiles(0)
        assert results == []

    def test_batch_deterministic(self) -> None:
        """Same seed should produce same batch results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.profiles(20) == f2.profiles(20)


class TestProfileLocales:
    """Tests for profile generation across different locales."""

    @pytest.mark.parametrize("locale", SUPPORTED_LOCALES)
    def test_returns_dict(self, locale: str) -> None:
        """profile() should return a dict for all locales."""
        fake = Faker(locale)
        fake.seed(42)
        result = fake.profile()
        assert isinstance(result, dict)

    @pytest.mark.parametrize("locale", SUPPORTED_LOCALES)
    def test_has_all_keys(self, locale: str) -> None:
        """Profile should have all expected keys for all locales."""
        fake = Faker(locale)
        fake.seed(42)
        result = fake.profile()
        for key in EXPECTED_KEYS:
            assert key in result, f"Missing key '{key}' for locale {locale}"
            assert len(result[key]) > 0, f"Empty '{key}' for locale {locale}"

    @pytest.mark.parametrize("locale", SUPPORTED_LOCALES)
    def test_batch(self, locale: str) -> None:
        """profiles() should return correct count for all locales."""
        fake = Faker(locale)
        fake.seed(42)
        results = fake.profiles(10)
        assert len(results) == 10

    @pytest.mark.parametrize("locale", SUPPORTED_LOCALES)
    def test_deterministic(self, locale: str) -> None:
        """Same seed should produce same profiles for all locales."""
        f1 = Faker(locale)
        f1.seed(42)
        f2 = Faker(locale)
        f2.seed(42)
        assert f1.profile() == f2.profile()

    def test_different_locales_different_output(self) -> None:
        """Different locales should produce different profiles."""
        f_us = Faker("en_US")
        f_us.seed(42)
        f_de = Faker("de_DE")
        f_de.seed(42)
        p_us = f_us.profile()
        p_de = f_de.profile()
        # At least the names/addresses should differ
        assert p_us["name"] != p_de["name"] or p_us["city"] != p_de["city"]


class TestProfileNameConsistency:
    """Tests for name consistency across locales."""

    @pytest.mark.parametrize("locale", SUPPORTED_LOCALES)
    def test_name_is_composed_of_parts(self, locale: str) -> None:
        """Full name should be first_name + last_name for all locales."""
        fake = Faker(locale)
        fake.seed(42)
        result = fake.profile()
        expected = f"{result['first_name']} {result['last_name']}"
        assert result["name"] == expected


class TestProfileInstanceIndependence:
    """Tests for independence between Faker instances."""

    def test_independent_instances(self) -> None:
        """Different Faker instances with same seed should produce same profiles."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)

        p1 = f1.profiles(5)
        p2 = f2.profiles(5)
        assert p1 == p2

    def test_different_seeds_different_output(self) -> None:
        """Different seeds should produce different profiles."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(99)

        p1 = f1.profile()
        p2 = f2.profile()
        assert p1 != p2
