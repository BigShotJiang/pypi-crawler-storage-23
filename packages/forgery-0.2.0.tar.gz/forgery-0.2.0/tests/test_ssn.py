"""Tests for SSN / national ID generation across locales."""

import re

import pytest

from forgery import Faker

SUPPORTED_LOCALES = ["en_US", "en_GB", "de_DE", "fr_FR", "es_ES", "it_IT", "ja_JP"]


class TestSsnUsFormat:
    """Tests for US Social Security Number (XXX-XX-XXXX)."""

    SSN_PATTERN = re.compile(r"^\d{3}-\d{2}-\d{4}$")

    def test_single_returns_string(self) -> None:
        """ssn() should return a string."""
        fake = Faker("en_US")
        fake.seed(42)
        result = fake.ssn()
        assert isinstance(result, str)

    def test_format(self) -> None:
        """US SSN should match XXX-XX-XXXX format."""
        fake = Faker("en_US")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            assert self.SSN_PATTERN.match(result), f"Invalid SSN format: {result}"

    def test_area_not_000_or_666(self) -> None:
        """Area number should not be 000 or 666."""
        fake = Faker("en_US")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            area = int(result[:3])
            assert area >= 1, f"Area is 000: {result}"
            assert area != 666, f"Area is 666: {result}"
            assert area <= 899, f"Area exceeds 899: {result}"

    def test_group_not_00(self) -> None:
        """Group number should not be 00."""
        fake = Faker("en_US")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            group = int(result[4:6])
            assert group >= 1, f"Group is 00: {result}"

    def test_serial_not_0000(self) -> None:
        """Serial number should not be 0000."""
        fake = Faker("en_US")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            serial = int(result[7:])
            assert serial >= 1, f"Serial is 0000: {result}"

    def test_batch(self) -> None:
        """ssns should return correct count."""
        fake = Faker("en_US")
        fake.seed(42)
        results = fake.ssns(100)
        assert len(results) == 100
        for r in results:
            assert self.SSN_PATTERN.match(r)

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker("en_US")
        results = fake.ssns(0)
        assert results == []


class TestSsnUkFormat:
    """Tests for UK National Insurance Number (AB 12 34 56 C)."""

    # Format: XX 99 99 99 X (2 letters, 6 digits in 3 pairs, 1 suffix letter)
    NINO_PATTERN = re.compile(r"^[A-Z]{2} \d{2} \d{2} \d{2} [A-D]$")

    def test_format(self) -> None:
        """UK NINO should match expected format."""
        fake = Faker("en_GB")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            assert self.NINO_PATTERN.match(result), f"Invalid NINO format: {result}"

    def test_length(self) -> None:
        """UK NINO should be 13 characters."""
        fake = Faker("en_GB")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            assert len(result) == 13, f"Wrong length: {result}"

    def test_suffix_is_valid(self) -> None:
        """UK NINO suffix should be A, B, C, or D."""
        fake = Faker("en_GB")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            suffix = result[-1]
            assert suffix in ("A", "B", "C", "D"), f"Invalid suffix: {result}"


class TestSsnDeFormat:
    """Tests for German Steuer-ID (11 digits)."""

    def test_format(self) -> None:
        """German Steuer-ID should be 11 digits."""
        fake = Faker("de_DE")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            assert len(result) == 11, f"Wrong length: {result}"
            assert result.isdigit(), f"Non-digit characters: {result}"

    def test_first_digit_not_zero(self) -> None:
        """First digit should not be 0."""
        fake = Faker("de_DE")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            assert result[0] != "0", f"First digit is 0: {result}"

    def test_structural_constraint(self) -> None:
        """First 10 digits: exactly one digit appears twice, one digit missing."""
        from collections import Counter

        fake = Faker("de_DE")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            body = result[:10]
            counts = Counter(body)
            digit_counts = sorted(counts.values(), reverse=True)
            # 9 unique digits: one appears 2x, eight appear 1x
            assert digit_counts[0] == 2, f"No doubled digit in: {result}"
            assert all(c == 1 for c in digit_counts[1:]), (
                f"More than one doubled digit in: {result}"
            )
            assert len(counts) == 9, f"Should use exactly 9 distinct digits: {result}"


class TestSsnFrFormat:
    """Tests for French social security number (15 digits)."""

    def test_format(self) -> None:
        """French NSS should be 15 digits."""
        fake = Faker("fr_FR")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            assert len(result) == 15, f"Wrong length: {result}"
            assert result.isdigit(), f"Non-digit characters: {result}"

    def test_sex_digit(self) -> None:
        """First digit should be 1 (male) or 2 (female)."""
        fake = Faker("fr_FR")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            assert result[0] in ("1", "2"), f"Invalid sex digit: {result}"

    def test_check_key(self) -> None:
        """Check key (last 2 digits) should validate correctly."""
        fake = Faker("fr_FR")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            body = int(result[:13])
            key = int(result[13:])
            expected = 97 - (body % 97)
            assert key == expected, f"Check key mismatch for {result}"


class TestSsnEsFormat:
    """Tests for Spanish DNI (8 digits + letter)."""

    DNI_LETTERS = "TRWAGMYFPDXBNJZSQVHLCKE"

    def test_format(self) -> None:
        """Spanish DNI should be 8 digits followed by a letter."""
        fake = Faker("es_ES")
        fake.seed(42)
        pattern = re.compile(r"^\d{8}[A-Z]$")
        for _ in range(100):
            result = fake.ssn()
            assert pattern.match(result), f"Invalid DNI format: {result}"

    def test_check_letter(self) -> None:
        """Check letter should be valid based on number mod 23."""
        fake = Faker("es_ES")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            number = int(result[:8])
            letter = result[-1]
            expected = self.DNI_LETTERS[number % 23]
            assert letter == expected, f"Check letter mismatch for {result}"


class TestSsnItFormat:
    """Tests for Italian codice fiscale (16 alphanumeric characters)."""

    def test_format(self) -> None:
        """Italian codice fiscale should be 16 alphanumeric characters."""
        fake = Faker("it_IT")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            assert len(result) == 16, f"Wrong length: {result}"
            assert result.isalnum(), f"Non-alphanumeric characters: {result}"

    def test_all_uppercase(self) -> None:
        """All letter characters should be uppercase."""
        fake = Faker("it_IT")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            for c in result:
                if c.isalpha():
                    assert c.isupper(), f"Lowercase letter in: {result}"


class TestSsnJpFormat:
    """Tests for Japanese My Number (12 digits)."""

    def test_format(self) -> None:
        """Japanese My Number should be 12 digits."""
        fake = Faker("ja_JP")
        fake.seed(42)
        for _ in range(100):
            result = fake.ssn()
            assert len(result) == 12, f"Wrong length: {result}"
            assert result.isdigit(), f"Non-digit characters: {result}"

    def test_check_digit(self) -> None:
        """Check digit (12th digit) should be valid."""
        fake = Faker("ja_JP")
        fake.seed(42)
        weights = [6, 5, 4, 3, 2, 7, 6, 5, 4, 3, 2]
        for _ in range(100):
            result = fake.ssn()
            digits = [int(c) for c in result]
            weighted_sum = sum(d * w for d, w in zip(digits[:11], weights, strict=True))
            remainder = weighted_sum % 11
            expected = 0 if remainder <= 1 else 11 - remainder
            assert digits[11] == expected, f"Check digit mismatch for {result}"


class TestSsnAllLocales:
    """Tests for SSN generation across all locales."""

    @pytest.mark.parametrize("locale", SUPPORTED_LOCALES)
    def test_returns_string(self, locale: str) -> None:
        """ssn() should return a non-empty string for all locales."""
        fake = Faker(locale)
        fake.seed(42)
        result = fake.ssn()
        assert isinstance(result, str)
        assert len(result) > 0

    @pytest.mark.parametrize("locale", SUPPORTED_LOCALES)
    def test_batch(self, locale: str) -> None:
        """ssns() should return correct count for all locales."""
        fake = Faker(locale)
        fake.seed(42)
        results = fake.ssns(50)
        assert len(results) == 50
        for r in results:
            assert isinstance(r, str)
            assert len(r) > 0

    @pytest.mark.parametrize("locale", SUPPORTED_LOCALES)
    def test_deterministic(self, locale: str) -> None:
        """Same seed should produce same results for all locales."""
        f1 = Faker(locale)
        f1.seed(42)
        f2 = Faker(locale)
        f2.seed(42)
        assert f1.ssn() == f2.ssn()

    @pytest.mark.parametrize("locale", SUPPORTED_LOCALES)
    def test_batch_deterministic(self, locale: str) -> None:
        """Same seed should produce same batch results for all locales."""
        f1 = Faker(locale)
        f1.seed(42)
        f2 = Faker(locale)
        f2.seed(42)
        assert f1.ssns(20) == f2.ssns(20)


class TestSsnRecordsSchema:
    """Tests for SSN type in records schema."""

    def test_ssn_in_schema(self) -> None:
        """'ssn' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"id_number": "ssn"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["id_number"], str)
            assert len(row["id_number"]) > 0

    def test_ssn_in_schema_locale(self) -> None:
        """SSN in schema should use the Faker instance's locale."""
        fake = Faker("de_DE")
        fake.seed(42)
        data = fake.records(10, {"tax_id": "ssn"})
        assert len(data) == 10
        for row in data:
            # German Steuer-ID: 11 digits
            assert len(row["tax_id"]) == 11
            assert row["tax_id"].isdigit()
