"""Tests for vehicle/automotive data generation."""

import re

import pytest

from forgery import Faker

SUPPORTED_LOCALES = ["en_US", "en_GB", "de_DE", "fr_FR", "es_ES", "it_IT", "ja_JP"]


def _validate_vin_check_digit(vin: str) -> bool:
    """Validate a VIN check digit at position 9."""
    if len(vin) != 17:
        return False
    # VIN must not contain I, O, Q
    if any(c in vin for c in "IOQ"):
        return False

    def transliterate(c: str) -> int:
        mapping = {
            "A": 1,
            "B": 2,
            "C": 3,
            "D": 4,
            "E": 5,
            "F": 6,
            "G": 7,
            "H": 8,
            "J": 1,
            "K": 2,
            "L": 3,
            "M": 4,
            "N": 5,
            "P": 7,
            "R": 9,
            "S": 2,
            "T": 3,
            "U": 4,
            "V": 5,
            "W": 6,
            "X": 7,
            "Y": 8,
            "Z": 9,
        }
        if c.isdigit():
            return int(c)
        return mapping.get(c, 0)

    weights = [8, 7, 6, 5, 4, 3, 2, 10, 0, 9, 8, 7, 6, 5, 4, 3, 2]
    total = sum(
        transliterate(c) * w for i, (c, w) in enumerate(zip(vin, weights, strict=True)) if i != 8
    )
    remainder = total % 11
    expected = "X" if remainder == 10 else str(remainder)
    return vin[8] == expected


class TestLicensePlate:
    """Tests for locale-specific license plate generation."""

    def test_us_format(self) -> None:
        """US plate should be ABC-1234 format."""
        fake = Faker("en_US")
        fake.seed(42)
        pattern = re.compile(r"^[A-Z]{3}-\d{4}$")
        for _ in range(100):
            result = fake.license_plate()
            assert pattern.match(result), f"Invalid US plate format: {result}"

    def test_uk_format(self) -> None:
        """UK plate should be AB12 CDE format."""
        fake = Faker("en_GB")
        fake.seed(42)
        pattern = re.compile(r"^[A-Z]{2}\d{2} [A-Z]{3}$")
        for _ in range(100):
            result = fake.license_plate()
            assert pattern.match(result), f"Invalid UK plate format: {result}"

    def test_de_format(self) -> None:
        """German plate should be CITY ID NUMBER format."""
        fake = Faker("de_DE")
        fake.seed(42)
        # City: 1-3 letters, ID: 1-2 letters, Number: 1-4 digits
        pattern = re.compile(r"^[A-Z]{1,3} [A-Z]{1,2} \d{1,4}$")
        for _ in range(100):
            result = fake.license_plate()
            assert pattern.match(result), f"Invalid DE plate format: {result}"

    def test_fr_format(self) -> None:
        """French plate should be AA-123-AA format."""
        fake = Faker("fr_FR")
        fake.seed(42)
        pattern = re.compile(r"^[A-Z]{2}-\d{3}-[A-Z]{2}$")
        for _ in range(100):
            result = fake.license_plate()
            assert pattern.match(result), f"Invalid FR plate format: {result}"

    def test_es_format(self) -> None:
        """Spanish plate should be 1234 BCD format with valid consonants only."""
        fake = Faker("es_ES")
        fake.seed(42)
        # Spanish plates use only consonants (no A, E, I, O, U, Ñ, Q)
        valid_letters = set("BCDFGHJKLMNPRSTVWXYZ")
        pattern = re.compile(r"^\d{4} [A-Z]{3}$")
        for _ in range(100):
            result = fake.license_plate()
            assert pattern.match(result), f"Invalid ES plate format: {result}"
            letters = result[5:]
            for ch in letters:
                assert ch in valid_letters, f"Invalid ES plate letter '{ch}' in: {result}"

    def test_it_format(self) -> None:
        """Italian plate should be AB 123 CD format."""
        fake = Faker("it_IT")
        fake.seed(42)
        pattern = re.compile(r"^[A-Z]{2} \d{3} [A-Z]{2}$")
        for _ in range(100):
            result = fake.license_plate()
            assert pattern.match(result), f"Invalid IT plate format: {result}"

    def test_jp_format(self) -> None:
        """Japanese plate should have class number and digits."""
        fake = Faker("ja_JP")
        fake.seed(42)
        # Format: NNN DD-DD
        pattern = re.compile(r"^\d{3} \d{2}-\d{2}$")
        for _ in range(100):
            result = fake.license_plate()
            assert pattern.match(result), f"Invalid JP plate format: {result}"

    @pytest.mark.parametrize("locale", SUPPORTED_LOCALES)
    def test_returns_string(self, locale: str) -> None:
        """license_plate() should return a non-empty string for all locales."""
        fake = Faker(locale)
        fake.seed(42)
        result = fake.license_plate()
        assert isinstance(result, str)
        assert len(result) > 0

    def test_batch(self) -> None:
        """license_plates should return correct count."""
        fake = Faker("en_US")
        fake.seed(42)
        results = fake.license_plates(100)
        assert len(results) == 100
        for r in results:
            assert isinstance(r, str)
            assert len(r) > 0

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.license_plates(0)
        assert results == []

    @pytest.mark.parametrize("locale", SUPPORTED_LOCALES)
    def test_deterministic(self, locale: str) -> None:
        """Same seed should produce same results for all locales."""
        f1 = Faker(locale)
        f1.seed(42)
        f2 = Faker(locale)
        f2.seed(42)
        assert f1.license_plate() == f2.license_plate()


class TestVehicleMake:
    """Tests for vehicle make generation."""

    def test_single_returns_string(self) -> None:
        """vehicle_make() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.vehicle_make()
        assert isinstance(result, str)

    def test_not_empty(self) -> None:
        """Vehicle make should not be empty."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.vehicle_make()
            assert len(result) > 0

    def test_batch(self) -> None:
        """vehicle_makes should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.vehicle_makes(100)
        assert len(results) == 100
        for r in results:
            assert isinstance(r, str)
            assert len(r) > 0

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.vehicle_makes(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.vehicle_make() == f2.vehicle_make()

    def test_variety(self) -> None:
        """Should produce a variety of makes."""
        fake = Faker()
        fake.seed(42)
        results = fake.vehicle_makes(500)
        unique = set(results)
        assert len(unique) > 5, f"Too few unique makes: {len(unique)}"


class TestVehicleModel:
    """Tests for vehicle model generation."""

    def test_single_returns_string(self) -> None:
        """vehicle_model() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.vehicle_model()
        assert isinstance(result, str)

    def test_not_empty(self) -> None:
        """Vehicle model should not be empty."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.vehicle_model()
            assert len(result) > 0

    def test_batch(self) -> None:
        """vehicle_models should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.vehicle_models(100)
        assert len(results) == 100
        for r in results:
            assert isinstance(r, str)
            assert len(r) > 0

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.vehicle_models(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.vehicle_model() == f2.vehicle_model()


class TestVehicleYear:
    """Tests for vehicle year generation."""

    def test_single_returns_int(self) -> None:
        """vehicle_year() should return an integer."""
        fake = Faker()
        fake.seed(42)
        result = fake.vehicle_year()
        assert isinstance(result, int)

    def test_range(self) -> None:
        """Vehicle year should be in 1990-2026 range."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.vehicle_year()
            assert 1990 <= result <= 2026, f"Year out of range: {result}"

    def test_batch(self) -> None:
        """vehicle_years should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.vehicle_years(100)
        assert len(results) == 100
        for r in results:
            assert isinstance(r, int)
            assert 1990 <= r <= 2026

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.vehicle_years(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.vehicle_year() == f2.vehicle_year()


class TestVin:
    """Tests for VIN (Vehicle Identification Number) generation."""

    VIN_PATTERN = re.compile(r"^[A-HJ-NPR-Z0-9]{17}$")

    def test_single_returns_string(self) -> None:
        """vin() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.vin()
        assert isinstance(result, str)

    def test_length(self) -> None:
        """VIN should be exactly 17 characters."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.vin()
            assert len(result) == 17, f"Wrong VIN length: {result}"

    def test_no_ioq(self) -> None:
        """VIN should not contain I, O, or Q."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.vin()
            assert "I" not in result, f"VIN contains I: {result}"
            assert "O" not in result, f"VIN contains O: {result}"
            assert "Q" not in result, f"VIN contains Q: {result}"

    def test_format(self) -> None:
        """VIN should match alphanumeric pattern (no I, O, Q)."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.vin()
            assert self.VIN_PATTERN.match(result), f"Invalid VIN format: {result}"

    def test_check_digit_valid(self) -> None:
        """VIN check digit (position 9) should be valid."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.vin()
            assert _validate_vin_check_digit(result), f"Invalid VIN check digit: {result}"

    def test_batch(self) -> None:
        """vins should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.vins(100)
        assert len(results) == 100
        for r in results:
            assert self.VIN_PATTERN.match(r)
            assert _validate_vin_check_digit(r)

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.vins(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.vin() == f2.vin()

    def test_batch_deterministic(self) -> None:
        """Same seed should produce same batch results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.vins(50) == f2.vins(50)


class TestVehicleRecordsSchema:
    """Tests for vehicle types in records schema."""

    def test_license_plate_in_schema(self) -> None:
        """'license_plate' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"plate": "license_plate"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["plate"], str)
            assert len(row["plate"]) > 0

    def test_vehicle_make_in_schema(self) -> None:
        """'vehicle_make' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"make": "vehicle_make"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["make"], str)
            assert len(row["make"]) > 0

    def test_vehicle_model_in_schema(self) -> None:
        """'vehicle_model' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"model": "vehicle_model"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["model"], str)
            assert len(row["model"]) > 0

    def test_vehicle_year_in_schema(self) -> None:
        """'vehicle_year' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"year": "vehicle_year"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["year"], int)
            assert 1990 <= row["year"] <= 2026

    def test_vin_in_schema(self) -> None:
        """'vin' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"vin": "vin"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["vin"], str)
            assert len(row["vin"]) == 17

    def test_mixed_vehicle_schema(self) -> None:
        """All vehicle types should work together in the same schema."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(
            10,
            {
                "plate": "license_plate",
                "make": "vehicle_make",
                "model": "vehicle_model",
                "year": "vehicle_year",
                "vin": "vin",
            },
        )
        assert len(data) == 10
        for row in data:
            assert len(row["plate"]) > 0
            assert len(row["make"]) > 0
            assert len(row["model"]) > 0
            assert 1990 <= row["year"] <= 2026
            assert len(row["vin"]) == 17
