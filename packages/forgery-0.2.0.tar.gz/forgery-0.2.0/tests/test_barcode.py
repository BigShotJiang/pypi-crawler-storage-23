"""Tests for barcode generation (EAN-13, EAN-8, UPC-A, UPC-E)."""

import re

from forgery import Faker


def _validate_ean_check_digit(barcode: str) -> bool:
    """Validate an EAN/UPC barcode check digit using the GS1 weighted-sum algorithm."""
    digits = [int(c) for c in barcode if c.isdigit()]
    if len(digits) < 2:
        return False
    payload = digits[:-1]
    n = len(payload)
    # GS1: rightmost payload digit gets weight 3, alternating 1,3 leftward
    weighted_sum = sum(d * (3 if (n - 1 - i) % 2 == 0 else 1) for i, d in enumerate(payload))
    expected = (10 - (weighted_sum % 10)) % 10
    return expected == digits[-1]


class TestEan13:
    """Tests for EAN-13 barcode generation."""

    EAN13_PATTERN = re.compile(r"^\d{13}$")

    def test_single_returns_string(self) -> None:
        """ean13() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.ean13()
        assert isinstance(result, str)

    def test_format(self) -> None:
        """EAN-13 should be exactly 13 digits."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.ean13()
            assert self.EAN13_PATTERN.match(result), f"Invalid EAN-13 format: {result}"

    def test_check_digit_valid(self) -> None:
        """EAN-13 check digit should be valid."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.ean13()
            assert _validate_ean_check_digit(result), f"Invalid check digit: {result}"

    def test_batch(self) -> None:
        """ean13s should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.ean13s(100)
        assert len(results) == 100
        for r in results:
            assert self.EAN13_PATTERN.match(r)
            assert _validate_ean_check_digit(r)

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.ean13s(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.ean13() == f2.ean13()

    def test_batch_deterministic(self) -> None:
        """Same seed should produce same batch results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.ean13s(50) == f2.ean13s(50)


class TestEan8:
    """Tests for EAN-8 barcode generation."""

    EAN8_PATTERN = re.compile(r"^\d{8}$")

    def test_single_returns_string(self) -> None:
        """ean8() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.ean8()
        assert isinstance(result, str)

    def test_format(self) -> None:
        """EAN-8 should be exactly 8 digits."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.ean8()
            assert self.EAN8_PATTERN.match(result), f"Invalid EAN-8 format: {result}"

    def test_check_digit_valid(self) -> None:
        """EAN-8 check digit should be valid."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.ean8()
            assert _validate_ean_check_digit(result), f"Invalid check digit: {result}"

    def test_batch(self) -> None:
        """ean8s should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.ean8s(100)
        assert len(results) == 100
        for r in results:
            assert self.EAN8_PATTERN.match(r)
            assert _validate_ean_check_digit(r)

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.ean8s(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.ean8() == f2.ean8()


class TestUpcA:
    """Tests for UPC-A barcode generation."""

    UPC_A_PATTERN = re.compile(r"^\d{12}$")

    def test_single_returns_string(self) -> None:
        """upc_a() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.upc_a()
        assert isinstance(result, str)

    def test_format(self) -> None:
        """UPC-A should be exactly 12 digits."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.upc_a()
            assert self.UPC_A_PATTERN.match(result), f"Invalid UPC-A format: {result}"

    def test_check_digit_valid(self) -> None:
        """UPC-A check digit should be valid."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.upc_a()
            assert _validate_ean_check_digit(result), f"Invalid check digit: {result}"

    def test_batch(self) -> None:
        """upc_as should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.upc_as(100)
        assert len(results) == 100
        for r in results:
            assert self.UPC_A_PATTERN.match(r)
            assert _validate_ean_check_digit(r)

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.upc_as(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.upc_a() == f2.upc_a()


class TestUpcE:
    """Tests for UPC-E barcode generation."""

    UPC_E_PATTERN = re.compile(r"^\d{8}$")

    def test_single_returns_string(self) -> None:
        """upc_e() should return a string."""
        fake = Faker()
        fake.seed(42)
        result = fake.upc_e()
        assert isinstance(result, str)

    def test_format(self) -> None:
        """UPC-E should be exactly 8 digits."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.upc_e()
            assert self.UPC_E_PATTERN.match(result), f"Invalid UPC-E format: {result}"

    def test_starts_with_zero(self) -> None:
        """UPC-E should start with 0."""
        fake = Faker()
        fake.seed(42)
        for _ in range(100):
            result = fake.upc_e()
            assert result[0] == "0", f"UPC-E should start with 0: {result}"

    def test_batch(self) -> None:
        """upc_es should return correct count."""
        fake = Faker()
        fake.seed(42)
        results = fake.upc_es(100)
        assert len(results) == 100
        for r in results:
            assert self.UPC_E_PATTERN.match(r)
            assert r[0] == "0"

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        fake = Faker()
        results = fake.upc_es(0)
        assert results == []

    def test_deterministic(self) -> None:
        """Same seed should produce same results."""
        f1 = Faker()
        f1.seed(42)
        f2 = Faker()
        f2.seed(42)
        assert f1.upc_e() == f2.upc_e()


class TestBarcodeRecordsSchema:
    """Tests for barcode types in records schema."""

    def test_ean13_in_schema(self) -> None:
        """'ean13' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"barcode": "ean13"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["barcode"], str)
            assert len(row["barcode"]) == 13
            assert _validate_ean_check_digit(row["barcode"])

    def test_ean8_in_schema(self) -> None:
        """'ean8' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"barcode": "ean8"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["barcode"], str)
            assert len(row["barcode"]) == 8
            assert _validate_ean_check_digit(row["barcode"])

    def test_upc_a_in_schema(self) -> None:
        """'upc_a' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"barcode": "upc_a"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["barcode"], str)
            assert len(row["barcode"]) == 12
            assert _validate_ean_check_digit(row["barcode"])

    def test_upc_e_in_schema(self) -> None:
        """'upc_e' should work as a records schema type."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(10, {"barcode": "upc_e"})
        assert len(data) == 10
        for row in data:
            assert isinstance(row["barcode"], str)
            assert len(row["barcode"]) == 8
            assert row["barcode"][0] == "0"

    def test_mixed_barcode_schema(self) -> None:
        """Multiple barcode types should work in the same schema."""
        fake = Faker()
        fake.seed(42)
        data = fake.records(
            10,
            {
                "ean13": "ean13",
                "ean8": "ean8",
                "upc_a": "upc_a",
                "upc_e": "upc_e",
            },
        )
        assert len(data) == 10
        for row in data:
            assert len(row["ean13"]) == 13
            assert len(row["ean8"]) == 8
            assert len(row["upc_a"]) == 12
            assert len(row["upc_e"]) == 8
