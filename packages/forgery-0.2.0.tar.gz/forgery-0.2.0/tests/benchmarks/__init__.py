"""Benchmark tests for forgery."""
