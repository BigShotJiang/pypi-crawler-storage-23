"""Tests for geographic data generation (latitude, longitude, coordinate)."""

import pytest

from forgery import (
    Faker,
    coordinate,
    coordinates,
    latitude,
    latitudes,
    longitude,
    longitudes,
    records,
    records_arrow,
    seed,
)

# Check if pyarrow is available for arrow tests
try:
    import pyarrow as pa  # noqa: F401

    HAS_PYARROW = True
except ImportError:
    HAS_PYARROW = False


class TestLatitude:
    """Tests for latitude generation."""

    def test_single_latitude_range(self) -> None:
        """Single latitude should be in [-90.0, 90.0]."""
        seed(42)
        for _ in range(100):
            lat = latitude()
            assert -90.0 <= lat <= 90.0, f"latitude {lat} out of range"

    def test_single_latitude_type(self) -> None:
        """Latitude should be a float."""
        seed(42)
        assert isinstance(latitude(), float)

    def test_batch_latitudes(self) -> None:
        """Batch latitudes should return correct count with valid range."""
        seed(42)
        result = latitudes(1000)
        assert len(result) == 1000
        for lat in result:
            assert -90.0 <= lat <= 90.0

    def test_batch_empty(self) -> None:
        """Empty batch should return empty list."""
        result = latitudes(0)
        assert result == []

    def test_deterministic_with_seed(self) -> None:
        """Same seed should produce same latitudes."""
        seed(42)
        result1 = latitudes(50)
        seed(42)
        result2 = latitudes(50)
        assert result1 == result2

    def test_distribution(self) -> None:
        """Latitudes should include both positive and negative values."""
        seed(42)
        result = latitudes(10000)
        assert any(lat < 0 for lat in result)
        assert any(lat > 0 for lat in result)


class TestLongitude:
    """Tests for longitude generation."""

    def test_single_longitude_range(self) -> None:
        """Single longitude should be in [-180.0, 180.0]."""
        seed(42)
        for _ in range(100):
            lng = longitude()
            assert -180.0 <= lng <= 180.0, f"longitude {lng} out of range"

    def test_single_longitude_type(self) -> None:
        """Longitude should be a float."""
        seed(42)
        assert isinstance(longitude(), float)

    def test_batch_longitudes(self) -> None:
        """Batch longitudes should return correct count with valid range."""
        seed(42)
        result = longitudes(1000)
        assert len(result) == 1000
        for lng in result:
            assert -180.0 <= lng <= 180.0

    def test_deterministic_with_seed(self) -> None:
        """Same seed should produce same longitudes."""
        seed(42)
        result1 = longitudes(50)
        seed(42)
        result2 = longitudes(50)
        assert result1 == result2


class TestCoordinate:
    """Tests for coordinate pair generation."""

    def test_single_coordinate(self) -> None:
        """Single coordinate should be a (lat, lng) tuple."""
        seed(42)
        coord = coordinate()
        assert isinstance(coord, tuple)
        assert len(coord) == 2
        lat, lng = coord
        assert -90.0 <= lat <= 90.0
        assert -180.0 <= lng <= 180.0

    def test_batch_coordinates(self) -> None:
        """Batch coordinates should return correct count with valid ranges."""
        seed(42)
        result = coordinates(500)
        assert len(result) == 500
        for lat, lng in result:
            assert -90.0 <= lat <= 90.0
            assert -180.0 <= lng <= 180.0

    def test_deterministic_with_seed(self) -> None:
        """Same seed should produce same coordinates."""
        seed(42)
        result1 = coordinates(50)
        seed(42)
        result2 = coordinates(50)
        assert result1 == result2


class TestFakerClassMethods:
    """Tests for Faker class methods."""

    def test_faker_latitude(self) -> None:
        """Faker.latitude() should work."""
        fake = Faker()
        fake.seed(42)
        lat = fake.latitude()
        assert isinstance(lat, float)
        assert -90.0 <= lat <= 90.0

    def test_faker_latitudes(self) -> None:
        """Faker.latitudes() should work."""
        fake = Faker()
        fake.seed(42)
        result = fake.latitudes(100)
        assert len(result) == 100
        assert all(-90.0 <= lat <= 90.0 for lat in result)

    def test_faker_longitude(self) -> None:
        """Faker.longitude() should work."""
        fake = Faker()
        fake.seed(42)
        lng = fake.longitude()
        assert isinstance(lng, float)
        assert -180.0 <= lng <= 180.0

    def test_faker_longitudes(self) -> None:
        """Faker.longitudes() should work."""
        fake = Faker()
        fake.seed(42)
        result = fake.longitudes(100)
        assert len(result) == 100
        assert all(-180.0 <= lng <= 180.0 for lng in result)

    def test_faker_coordinate(self) -> None:
        """Faker.coordinate() should work."""
        fake = Faker()
        fake.seed(42)
        coord = fake.coordinate()
        assert isinstance(coord, tuple)
        assert len(coord) == 2

    def test_faker_coordinates(self) -> None:
        """Faker.coordinates() should work."""
        fake = Faker()
        fake.seed(42)
        result = fake.coordinates(100)
        assert len(result) == 100


class TestBatchSizeLimits:
    """Tests for batch size validation."""

    MAX_BATCH_SIZE = 10_000_000

    def test_latitudes_exceeds_limit(self) -> None:
        """latitudes(n > limit) should raise ValueError."""
        with pytest.raises(ValueError):
            latitudes(self.MAX_BATCH_SIZE + 1)

    def test_longitudes_exceeds_limit(self) -> None:
        """longitudes(n > limit) should raise ValueError."""
        with pytest.raises(ValueError):
            longitudes(self.MAX_BATCH_SIZE + 1)

    def test_coordinates_exceeds_limit(self) -> None:
        """coordinates(n > limit) should raise ValueError."""
        with pytest.raises(ValueError):
            coordinates(self.MAX_BATCH_SIZE + 1)


class TestRecordsSchema:
    """Tests for geographic types in records schema."""

    def test_latitude_in_schema(self) -> None:
        """'latitude' should work as a records schema type."""
        seed(42)
        result = records(10, {"lat": "latitude"})
        assert len(result) == 10
        for row in result:
            assert isinstance(row["lat"], float)
            assert -90.0 <= row["lat"] <= 90.0

    def test_longitude_in_schema(self) -> None:
        """'longitude' should work as a records schema type."""
        seed(42)
        result = records(10, {"lng": "longitude"})
        assert len(result) == 10
        for row in result:
            assert isinstance(row["lng"], float)
            assert -180.0 <= row["lng"] <= 180.0

    def test_coordinate_in_schema(self) -> None:
        """'coordinate' should work as a records schema type."""
        seed(42)
        result = records(10, {"location": "coordinate"})
        assert len(result) == 10
        for row in result:
            assert isinstance(row["location"], tuple)
            lat, lng = row["location"]
            assert -90.0 <= lat <= 90.0
            assert -180.0 <= lng <= 180.0


@pytest.mark.skipif(not HAS_PYARROW, reason="pyarrow not installed")
class TestRecordsArrow:
    """Tests for geographic types in Arrow output."""

    def test_latitude_in_arrow(self) -> None:
        """'latitude' should produce Float64 in Arrow."""
        seed(42)
        batch = records_arrow(10, {"lat": "latitude"})
        assert batch.num_rows == 10
        lat_col = batch.column("lat")
        for val in lat_col:
            assert -90.0 <= val.as_py() <= 90.0

    def test_coordinate_in_arrow(self) -> None:
        """'coordinate' should produce Struct in Arrow."""
        seed(42)
        batch = records_arrow(10, {"location": "coordinate"})
        assert batch.num_rows == 10
        loc_col = batch.column("location")
        for val in loc_col:
            struct = val.as_py()
            assert -90.0 <= struct["lat"] <= 90.0
            assert -180.0 <= struct["lng"] <= 180.0
