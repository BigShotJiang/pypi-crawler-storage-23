"""forgery - Fake data at the speed of Rust.

A high-performance fake data generation library for Python, powered by Rust.
Designed to be 50-100x faster than Faker for batch operations.

Supported Locales:
    - en_US: English (United States) - default
    - en_GB: English (United Kingdom)
    - de_DE: German (Germany)
    - fr_FR: French (France)
    - es_ES: Spanish (Spain)
    - it_IT: Italian (Italy)
    - ja_JP: Japanese (Japan)

Thread Safety:
    Each Faker instance maintains its own RNG state and is NOT thread-safe.
    The module-level convenience functions (name(), email(), etc.) use a shared
    global Faker instance and should not be used concurrently from multiple threads.

    For multi-threaded applications, create a separate Faker instance per thread:

    >>> import threading
    >>> from forgery import Faker
    >>> thread_local = threading.local()
    >>> def get_faker():
    ...     if not hasattr(thread_local, 'faker'):
    ...         thread_local.faker = Faker()
    ...     return thread_local.faker

Example:
    >>> from forgery import fake
    >>> fake.seed(42)
    >>> names = fake.names(1000)  # Generate 1000 names in one call
    >>> email = fake.email()  # Single value convenience method

    >>> from forgery import Faker
    >>> my_fake = Faker()
    >>> my_fake.seed(123)
    >>> my_fake.emails(100)

    >>> # Using a different locale
    >>> german_fake = Faker("de_DE")
    >>> german_fake.names(10)  # German names
"""

from collections.abc import Coroutine
from typing import TYPE_CHECKING, Any

from forgery._forgery import Faker

if TYPE_CHECKING:
    import pyarrow

__all__ = [
    "Faker",
    "add_provider",
    "add_weighted_provider",
    "address",
    "addresses",
    "bank_account",
    "bank_accounts",
    "bank_name",
    "bank_names",
    "bic",
    "bics",
    "boolean",
    "booleans",
    "bothify",
    "bothify_batch",
    "catch_phrase",
    "catch_phrases",
    "chrome",
    "chromes",
    "cities",
    "city",
    "color",
    "colors",
    "companies",
    "company",
    "coordinate",
    "coordinates",
    "countries",
    "country",
    "credit_card",
    "credit_card_expire",
    "credit_card_expires",
    "credit_card_full",
    "credit_card_fulls",
    "credit_card_provider",
    "credit_card_providers",
    "credit_card_security_code",
    "credit_card_security_codes",
    "credit_cards",
    "currencies",
    "currency",
    "currency_code",
    "currency_codes",
    "currency_name",
    "currency_names",
    "date",
    "date_of_birth",
    "dates",
    "dates_of_birth",
    "datetime_",
    "datetimes",
    "department",
    "departments",
    "domain_name",
    "domain_names",
    "ean8",
    "ean8s",
    "ean13",
    "ean13s",
    "email",
    "emails",
    "fake",
    "file_extension",
    "file_extensions",
    "file_name",
    "file_names",
    "file_path_",
    "file_paths",
    "firefox",
    "firefoxes",
    "first_name",
    "first_names",
    "float_",
    "floats",
    "free_email",
    "free_emails",
    "generate",
    "generate_batch",
    "has_provider",
    "hex_color",
    "hex_colors",
    "iban",
    "ibans",
    "integer",
    "integers",
    "ipv4",
    "ipv4s",
    "ipv6",
    "ipv6s",
    "isbn10",
    "isbn10s",
    "isbn13",
    "isbn13s",
    "job",
    "jobs",
    "last_name",
    "last_names",
    "latitude",
    "latitudes",
    "letterify",
    "letterify_batch",
    "lexify",
    "lexify_batch",
    "license_plate",
    "license_plates",
    "list_providers",
    "longitude",
    "longitudes",
    "mac_address",
    "mac_addresses",
    "md5",
    "md5s",
    "mime_type",
    "mime_types",
    "name",
    "names",
    "numerify",
    "numerify_batch",
    "paragraph",
    "paragraphs",
    "password",
    "passwords",
    "phone_number",
    "phone_numbers",
    "price",
    "prices",
    "product_categories",
    "product_category",
    "product_material",
    "product_materials",
    "product_name",
    "product_names",
    "profile",
    "profiles",
    "records",
    "records_arrow",
    "records_arrow_async",
    "records_async",
    "records_tuples",
    "records_tuples_async",
    "remove_provider",
    "rgb_color",
    "rgb_colors",
    "safari",
    "safaris",
    "safe_email",
    "safe_emails",
    "seed",
    "sentence",
    "sentences",
    "sha256",
    "sha256s",
    "sort_code",
    "sort_codes",
    "ssn",
    "ssns",
    "state",
    "states",
    "street_address",
    "street_addresses",
    "text",
    "texts",
    "transaction_amount",
    "transaction_amounts",
    "transactions",
    "uk_account_number",
    "uk_account_numbers",
    "upc_a",
    "upc_as",
    "upc_e",
    "upc_es",
    "url",
    "urls",
    "user_agent",
    "user_agents",
    "uuid",
    "uuids",
    "vehicle_make",
    "vehicle_makes",
    "vehicle_model",
    "vehicle_models",
    "vehicle_year",
    "vehicle_years",
    "vin",
    "vins",
    "zip_code",
    "zip_codes",
]

__version__ = "0.1.0"

# Default Faker instance for convenient access.
# WARNING: Not thread-safe. For multi-threaded use, create separate Faker instances.
fake: Faker = Faker()


def seed(value: int) -> None:
    """Seed the default Faker instance for deterministic output.

    Args:
        value: The seed value.

    Example:
        >>> from forgery import seed, names
        >>> seed(42)
        >>> names1 = names(10)
        >>> seed(42)
        >>> names2 = names(10)
        >>> assert names1 == names2
    """
    fake.seed(value)


def name() -> str:
    """Generate a single random full name.

    Returns:
        A full name (first + last).

    Example:
        >>> from forgery import name
        >>> print(name())
        John Smith
    """
    return fake.name()


def names(n: int) -> list[str]:
    """Generate a batch of random full names.

    Args:
        n: Number of names to generate.

    Returns:
        A list of full names.

    Example:
        >>> from forgery import names
        >>> batch = names(1000)
        >>> len(batch)
        1000
    """
    return fake.names(n)


def first_name() -> str:
    """Generate a single random first name.

    Returns:
        A first name.
    """
    return fake.first_name()


def first_names(n: int) -> list[str]:
    """Generate a batch of random first names.

    Args:
        n: Number of first names to generate.

    Returns:
        A list of first names.
    """
    return fake.first_names(n)


def last_name() -> str:
    """Generate a single random last name.

    Returns:
        A last name.
    """
    return fake.last_name()


def last_names(n: int) -> list[str]:
    """Generate a batch of random last names.

    Args:
        n: Number of last names to generate.

    Returns:
        A list of last names.
    """
    return fake.last_names(n)


def email() -> str:
    """Generate a single random email address.

    Returns:
        An email address.

    Example:
        >>> from forgery import email
        >>> print(email())
        john123@gmail.com
    """
    return fake.email()


def emails(n: int) -> list[str]:
    """Generate a batch of random email addresses.

    Args:
        n: Number of emails to generate.

    Returns:
        A list of email addresses.
    """
    return fake.emails(n)


def integer(min: int = 0, max: int = 100) -> int:
    """Generate a single random integer within a range.

    Args:
        min: Minimum value (inclusive). Default: 0.
        max: Maximum value (inclusive). Default: 100.

    Returns:
        A random integer.

    Raises:
        ValueError: If min > max.
    """
    return fake.integer(min, max)


def integers(n: int, min: int = 0, max: int = 100) -> list[int]:
    """Generate a batch of random integers within a range.

    Args:
        n: Number of integers to generate.
        min: Minimum value (inclusive). Default: 0.
        max: Maximum value (inclusive). Default: 100.

    Returns:
        A list of random integers.

    Raises:
        ValueError: If min > max or n exceeds the maximum batch size (10 million).
    """
    return fake.integers(n, min, max)


def uuid() -> str:
    """Generate a single random UUID (version 4).

    Returns:
        A UUID string.

    Example:
        >>> from forgery import uuid
        >>> print(uuid())
        a1b2c3d4-e5f6-4a7b-8c9d-0e1f2a3b4c5d
    """
    return fake.uuid()


def uuids(n: int) -> list[str]:
    """Generate a batch of random UUIDs (version 4).

    Args:
        n: Number of UUIDs to generate.

    Returns:
        A list of UUID strings.
    """
    return fake.uuids(n)


# === Float Generation ===


def float_(min: float = 0.0, max: float = 1.0) -> float:
    """Generate a single random float within a range.

    Note: Named float_ to avoid shadowing builtin float.
    """
    return fake.float(min, max)


def floats(n: int, min: float = 0.0, max: float = 1.0) -> list[float]:
    """Generate a batch of random floats within a range."""
    return fake.floats(n, min, max)


# === Hash-like Identifier Generation ===


def md5() -> str:
    """Generate a single random MD5-like hex string.

    Note: This generates a random 32-character lowercase hex string that
    matches the format of an MD5 hash. It is NOT a cryptographic hash of
    any input data.
    """
    return fake.md5()


def md5s(n: int) -> list[str]:
    """Generate a batch of random MD5-like hex strings.

    Note: These are random 32-character hex strings, not cryptographic hashes.
    """
    return fake.md5s(n)


def sha256() -> str:
    """Generate a single random SHA256-like hex string.

    Note: This generates a random 64-character lowercase hex string that
    matches the format of a SHA256 hash. It is NOT a cryptographic hash of
    any input data.
    """
    return fake.sha256()


def sha256s(n: int) -> list[str]:
    """Generate a batch of random SHA256-like hex strings.

    Note: These are random 64-character hex strings, not cryptographic hashes.
    """
    return fake.sha256s(n)


# === Color Generation ===


def color() -> str:
    """Generate a single random color name."""
    return fake.color()


def colors(n: int) -> list[str]:
    """Generate a batch of random color names."""
    return fake.colors(n)


def hex_color() -> str:
    """Generate a single random hex color (#RRGGBB)."""
    return fake.hex_color()


def hex_colors(n: int) -> list[str]:
    """Generate a batch of random hex colors."""
    return fake.hex_colors(n)


def rgb_color() -> tuple[int, int, int]:
    """Generate a single random RGB color tuple."""
    return fake.rgb_color()


def rgb_colors(n: int) -> list[tuple[int, int, int]]:
    """Generate a batch of random RGB color tuples."""
    return fake.rgb_colors(n)


# === DateTime Generation ===


def date(start: str = "2000-01-01", end: str = "2030-12-31") -> str:
    """Generate a single random date (YYYY-MM-DD format)."""
    return fake.date(start, end)


def dates(n: int, start: str = "2000-01-01", end: str = "2030-12-31") -> list[str]:
    """Generate a batch of random dates."""
    return fake.dates(n, start, end)


def date_of_birth(min_age: int = 18, max_age: int = 80) -> str:
    """Generate a single random date of birth."""
    return fake.date_of_birth(min_age, max_age)


def dates_of_birth(n: int, min_age: int = 18, max_age: int = 80) -> list[str]:
    """Generate a batch of random dates of birth."""
    return fake.dates_of_birth(n, min_age, max_age)


def datetime_(start: str = "2000-01-01", end: str = "2030-12-31") -> str:
    """Generate a single random datetime (ISO 8601 format).

    Note: Named datetime_ to avoid shadowing the datetime module.
    """
    return fake.datetime(start, end)


def datetimes(n: int, start: str = "2000-01-01", end: str = "2030-12-31") -> list[str]:
    """Generate a batch of random datetimes."""
    return fake.datetimes(n, start, end)


# === Text Generation ===


def sentence(word_count: int = 10) -> str:
    """Generate a single random sentence."""
    return fake.sentence(word_count)


def sentences(n: int, word_count: int = 10) -> list[str]:
    """Generate a batch of random sentences."""
    return fake.sentences(n, word_count)


def paragraph(sentence_count: int = 5) -> str:
    """Generate a single random paragraph."""
    return fake.paragraph(sentence_count)


def paragraphs(n: int, sentence_count: int = 5) -> list[str]:
    """Generate a batch of random paragraphs."""
    return fake.paragraphs(n, sentence_count)


def text(min_chars: int = 50, max_chars: int = 200) -> str:
    """Generate a single random text block."""
    return fake.text(min_chars, max_chars)


def texts(n: int, min_chars: int = 50, max_chars: int = 200) -> list[str]:
    """Generate a batch of random text blocks."""
    return fake.texts(n, min_chars, max_chars)


# === Address Generation ===


def street_address() -> str:
    """Generate a single random street address."""
    return fake.street_address()


def street_addresses(n: int) -> list[str]:
    """Generate a batch of random street addresses."""
    return fake.street_addresses(n)


def city() -> str:
    """Generate a single random city name."""
    return fake.city()


def cities(n: int) -> list[str]:
    """Generate a batch of random city names."""
    return fake.cities(n)


def state() -> str:
    """Generate a single random state name."""
    return fake.state()


def states(n: int) -> list[str]:
    """Generate a batch of random state names."""
    return fake.states(n)


def country() -> str:
    """Generate a single random country name."""
    return fake.country()


def countries(n: int) -> list[str]:
    """Generate a batch of random country names."""
    return fake.countries(n)


def zip_code() -> str:
    """Generate a single random zip code."""
    return fake.zip_code()


def zip_codes(n: int) -> list[str]:
    """Generate a batch of random zip codes."""
    return fake.zip_codes(n)


def address() -> str:
    """Generate a single random full address."""
    return fake.address()


def addresses(n: int) -> list[str]:
    """Generate a batch of random full addresses."""
    return fake.addresses(n)


# === Phone Generation ===


def phone_number() -> str:
    """Generate a single random phone number."""
    return fake.phone_number()


def phone_numbers(n: int) -> list[str]:
    """Generate a batch of random phone numbers."""
    return fake.phone_numbers(n)


# === Company Generation ===


def company() -> str:
    """Generate a single random company name."""
    return fake.company()


def companies(n: int) -> list[str]:
    """Generate a batch of random company names."""
    return fake.companies(n)


def job() -> str:
    """Generate a single random job title."""
    return fake.job()


def jobs(n: int) -> list[str]:
    """Generate a batch of random job titles."""
    return fake.jobs(n)


def catch_phrase() -> str:
    """Generate a single random catch phrase."""
    return fake.catch_phrase()


def catch_phrases(n: int) -> list[str]:
    """Generate a batch of random catch phrases."""
    return fake.catch_phrases(n)


# === Network Generation ===


def url() -> str:
    """Generate a single random URL."""
    return fake.url()


def urls(n: int) -> list[str]:
    """Generate a batch of random URLs."""
    return fake.urls(n)


def domain_name() -> str:
    """Generate a single random domain name."""
    return fake.domain_name()


def domain_names(n: int) -> list[str]:
    """Generate a batch of random domain names."""
    return fake.domain_names(n)


def ipv4() -> str:
    """Generate a single random IPv4 address."""
    return fake.ipv4()


def ipv4s(n: int) -> list[str]:
    """Generate a batch of random IPv4 addresses."""
    return fake.ipv4s(n)


def ipv6() -> str:
    """Generate a single random IPv6 address."""
    return fake.ipv6()


def ipv6s(n: int) -> list[str]:
    """Generate a batch of random IPv6 addresses."""
    return fake.ipv6s(n)


def mac_address() -> str:
    """Generate a single random MAC address."""
    return fake.mac_address()


def mac_addresses(n: int) -> list[str]:
    """Generate a batch of random MAC addresses."""
    return fake.mac_addresses(n)


# === Email Variants ===


def safe_email() -> str:
    """Generate a single random safe email (example.com/org/net)."""
    return fake.safe_email()


def safe_emails(n: int) -> list[str]:
    """Generate a batch of random safe emails."""
    return fake.safe_emails(n)


def free_email() -> str:
    """Generate a single random free email (gmail.com, etc.)."""
    return fake.free_email()


def free_emails(n: int) -> list[str]:
    """Generate a batch of random free emails."""
    return fake.free_emails(n)


# === Finance Generation ===


def credit_card() -> str:
    """Generate a single random credit card number with valid Luhn checksum."""
    return fake.credit_card()


def credit_cards(n: int) -> list[str]:
    """Generate a batch of random credit card numbers."""
    return fake.credit_cards(n)


def iban() -> str:
    """Generate a single random IBAN with valid checksum."""
    return fake.iban()


def ibans(n: int) -> list[str]:
    """Generate a batch of random IBANs."""
    return fake.ibans(n)


def bic() -> str:
    """Generate a single random BIC/SWIFT code."""
    return fake.bic()


def bics(n: int) -> list[str]:
    """Generate a batch of random BIC/SWIFT codes."""
    return fake.bics(n)


def bank_account() -> str:
    """Generate a single random bank account number (8-17 digits)."""
    return fake.bank_account()


def bank_accounts(n: int) -> list[str]:
    """Generate a batch of random bank account numbers."""
    return fake.bank_accounts(n)


def bank_name() -> str:
    """Generate a single random bank name (locale-specific)."""
    return fake.bank_name()


def bank_names(n: int) -> list[str]:
    """Generate a batch of random bank names."""
    return fake.bank_names(n)


# === UK Banking Generation ===


def sort_code() -> str:
    """Generate a single UK sort code (format: XX-XX-XX)."""
    return fake.sort_code()


def sort_codes(n: int) -> list[str]:
    """Generate a batch of UK sort codes."""
    return fake.sort_codes(n)


def uk_account_number() -> str:
    """Generate a single UK bank account number (8 digits)."""
    return fake.uk_account_number()


def uk_account_numbers(n: int) -> list[str]:
    """Generate a batch of UK bank account numbers (8 digits each)."""
    return fake.uk_account_numbers(n)


# === Transaction Generation ===


def transactions(
    n: int,
    starting_balance: float,
    start_date: str,
    end_date: str,
) -> list[dict[str, str | float]]:
    """Generate a batch of financial transactions.

    Each transaction is a dictionary with keys:
    - reference: 8-character alphanumeric reference
    - date: Transaction date in YYYY-MM-DD format
    - amount: Transaction amount (negative for debits)
    - transaction_type: e.g., "Direct Debit", "Card Payment", etc.
    - description: Transaction description
    - balance: Running balance after transaction

    Args:
        n: Number of transactions to generate.
        starting_balance: Opening balance before first transaction.
        start_date: Start date in YYYY-MM-DD format.
        end_date: End date in YYYY-MM-DD format.

    Returns:
        List of transaction dictionaries, sorted chronologically.

    Example:
        >>> from forgery import transactions, seed
        >>> seed(42)
        >>> txns = transactions(5, 1000.0, "2024-01-01", "2024-01-31")
        >>> len(txns)
        5
        >>> all(k in txns[0] for k in ["reference", "date", "amount", "balance"])
        True
    """
    return fake.transactions(n, starting_balance, start_date, end_date)


def transaction_amount(min: float, max: float) -> float:
    """Generate a single transaction amount.

    Args:
        min: Minimum amount (inclusive).
        max: Maximum amount (inclusive).

    Returns:
        A transaction amount rounded to 2 decimal places.
    """
    return fake.transaction_amount(min, max)


def transaction_amounts(n: int, min: float, max: float) -> list[float]:
    """Generate a batch of transaction amounts.

    Args:
        n: Number of amounts to generate.
        min: Minimum amount (inclusive).
        max: Maximum amount (inclusive).

    Returns:
        List of amounts rounded to 2 decimal places.
    """
    return fake.transaction_amounts(n, min, max)


# === Credit Card Extensions ===


def credit_card_provider() -> str:
    """Generate a single credit card provider name (e.g., "Visa", "Mastercard")."""
    return fake.credit_card_provider()


def credit_card_providers(n: int) -> list[str]:
    """Generate a batch of credit card provider names."""
    return fake.credit_card_providers(n)


def credit_card_expire() -> str:
    """Generate a single credit card expiry date (MM/YY format)."""
    return fake.credit_card_expire()


def credit_card_expires(n: int) -> list[str]:
    """Generate a batch of credit card expiry dates."""
    return fake.credit_card_expires(n)


def credit_card_security_code() -> str:
    """Generate a single credit card security code (CVV/CVC)."""
    return fake.credit_card_security_code()


def credit_card_security_codes(n: int) -> list[str]:
    """Generate a batch of credit card security codes."""
    return fake.credit_card_security_codes(n)


def credit_card_full() -> dict[str, str]:
    """Generate a complete credit card record.

    Returns:
        A dictionary with keys: provider, number, expire, security_code, name.
    """
    return fake.credit_card_full()


def credit_card_fulls(n: int) -> list[dict[str, str]]:
    """Generate a batch of complete credit card records."""
    return fake.credit_card_fulls(n)


# === User Agent Generation ===


def user_agent() -> str:
    """Generate a single random browser user agent string."""
    return fake.user_agent()


def user_agents(n: int) -> list[str]:
    """Generate a batch of random browser user agent strings."""
    return fake.user_agents(n)


def chrome() -> str:
    """Generate a single Chrome user agent string."""
    return fake.chrome()


def chromes(n: int) -> list[str]:
    """Generate a batch of Chrome user agent strings."""
    return fake.chromes(n)


def firefox() -> str:
    """Generate a single Firefox user agent string."""
    return fake.firefox()


def firefoxes(n: int) -> list[str]:
    """Generate a batch of Firefox user agent strings."""
    return fake.firefoxes(n)


def safari() -> str:
    """Generate a single Safari user agent string."""
    return fake.safari()


def safaris(n: int) -> list[str]:
    """Generate a batch of Safari user agent strings."""
    return fake.safaris(n)


# === Currency Generation ===


def currency_code() -> str:
    """Generate a single random ISO 4217 currency code (e.g., "USD", "EUR")."""
    return fake.currency_code()


def currency_codes(n: int) -> list[str]:
    """Generate a batch of random ISO 4217 currency codes."""
    return fake.currency_codes(n)


def currency_name() -> str:
    """Generate a single random currency name (e.g., "United States Dollar")."""
    return fake.currency_name()


def currency_names(n: int) -> list[str]:
    """Generate a batch of random currency names."""
    return fake.currency_names(n)


def currency() -> tuple[str, str]:
    """Generate a single random currency (code, name) tuple."""
    return fake.currency()


def currencies(n: int) -> list[tuple[str, str]]:
    """Generate a batch of random currency (code, name) tuples."""
    return fake.currencies(n)


def price(min: float = 0.01, max: float = 999.99) -> float:
    """Generate a single random price with 2 decimal places.

    Args:
        min: Minimum price (inclusive). Default: 0.01.
        max: Maximum price (inclusive). Default: 999.99.

    Raises:
        ValueError: If min > max.
    """
    return fake.price(min, max)


def prices(n: int, min: float = 0.01, max: float = 999.99) -> list[float]:
    """Generate a batch of random prices with 2 decimal places.

    Args:
        n: Number of prices to generate.
        min: Minimum price (inclusive). Default: 0.01.
        max: Maximum price (inclusive). Default: 999.99.

    Raises:
        ValueError: If min > max or n exceeds batch limit.
    """
    return fake.prices(n, min, max)


# === Password Generation ===


def password(
    length: int = 12,
    uppercase: bool = True,
    lowercase: bool = True,
    digits: bool = True,
    symbols: bool = True,
) -> str:
    """Generate a single random password.

    Args:
        length: Length of the password (default: 12).
        uppercase: Include uppercase letters (default: True).
        lowercase: Include lowercase letters (default: True).
        digits: Include digits (default: True).
        symbols: Include symbols (default: True).

    Raises:
        ValueError: If no character sets are enabled.
    """
    return fake.password(length, uppercase, lowercase, digits, symbols)


def passwords(
    n: int,
    length: int = 12,
    uppercase: bool = True,
    lowercase: bool = True,
    digits: bool = True,
    symbols: bool = True,
) -> list[str]:
    """Generate a batch of random passwords.

    Args:
        n: Number of passwords to generate.
        length: Length of each password (default: 12).
        uppercase: Include uppercase letters (default: True).
        lowercase: Include lowercase letters (default: True).
        digits: Include digits (default: True).
        symbols: Include symbols (default: True).

    Raises:
        ValueError: If no character sets are enabled or n exceeds batch limit.
    """
    return fake.passwords(n, length, uppercase, lowercase, digits, symbols)


# === Geographic Generation ===


def latitude() -> float:
    """Generate a single random latitude in [-90.0, 90.0]."""
    return fake.latitude()


def latitudes(n: int) -> list[float]:
    """Generate a batch of random latitudes in [-90.0, 90.0].

    Args:
        n: Number of latitudes to generate.

    Raises:
        ValueError: If n exceeds the maximum batch size (10 million).
    """
    return fake.latitudes(n)


def longitude() -> float:
    """Generate a single random longitude in [-180.0, 180.0]."""
    return fake.longitude()


def longitudes(n: int) -> list[float]:
    """Generate a batch of random longitudes in [-180.0, 180.0].

    Args:
        n: Number of longitudes to generate.

    Raises:
        ValueError: If n exceeds the maximum batch size (10 million).
    """
    return fake.longitudes(n)


def coordinate() -> tuple[float, float]:
    """Generate a single random coordinate pair (latitude, longitude)."""
    return fake.coordinate()


def coordinates(n: int) -> list[tuple[float, float]]:
    """Generate a batch of random coordinate pairs (latitude, longitude).

    Args:
        n: Number of coordinates to generate.

    Raises:
        ValueError: If n exceeds the maximum batch size (10 million).
    """
    return fake.coordinates(n)


# === Boolean Generation ===


def boolean(probability: float = 0.5) -> bool:
    """Generate a single random boolean.

    Args:
        probability: Probability of True (0.0-1.0). Default: 0.5.

    Raises:
        ValueError: If probability is not in [0.0, 1.0].
    """
    return fake.boolean(probability)


def booleans(n: int, probability: float = 0.5) -> list[bool]:
    """Generate a batch of random booleans.

    Args:
        n: Number of booleans to generate.
        probability: Probability of True (0.0-1.0). Default: 0.5.

    Raises:
        ValueError: If n exceeds the maximum batch size (10 million)
                    or probability is not in [0.0, 1.0].
    """
    return fake.booleans(n, probability)


# === Records Generation ===

# Type alias for schema field specifications
FieldSpec = str | tuple[str, ...]
Schema = dict[str, FieldSpec]


def records(n: int, schema: Schema) -> list[dict[str, object]]:
    """Generate structured records based on a schema.

    The schema is a dictionary mapping field names to type specifications:
    - Simple types: "name", "email", "uuid", "int", "float", etc.
    - Integer range: ("int", min, max)
    - Float range: ("float", min, max)
    - Text with limits: ("text", min_chars, max_chars)
    - Date range: ("date", start, end)
    - Choice: ("choice", ["option1", "option2", ...])

    Args:
        n: Number of records to generate.
        schema: Dictionary mapping field names to type specifications.

    Returns:
        A list of dictionaries, each containing the generated fields.

    Example:
        >>> from forgery import records, seed
        >>> seed(42)
        >>> data = records(3, {
        ...     "id": "uuid",
        ...     "name": "name",
        ...     "age": ("int", 18, 65),
        ...     "status": ("choice", ["active", "inactive"]),
        ... })
        >>> len(data)
        3
        >>> "id" in data[0] and "name" in data[0]
        True
    """
    return fake.records(n, schema)


def records_tuples(n: int, schema: Schema) -> list[tuple[object, ...]]:
    """Generate structured records as tuples based on a schema.

    This is faster than records() since it avoids creating dictionaries.
    Values are returned in alphabetical order of the schema keys.

    The schema format is identical to records().

    Args:
        n: Number of records to generate.
        schema: Dictionary mapping field names to type specifications.

    Returns:
        A list of tuples, each containing values in alphabetical key order.

    Example:
        >>> from forgery import records_tuples, seed
        >>> seed(42)
        >>> data = records_tuples(3, {
        ...     "age": ("int", 18, 65),
        ...     "name": "name",
        ... })
        >>> len(data)
        3
        >>> len(data[0])  # (age, name) - alphabetical order
        2
    """
    return fake.records_tuples(n, schema)


def records_arrow(n: int, schema: Schema) -> "pyarrow.RecordBatch":
    """Generate structured records as a PyArrow RecordBatch.

    This is the high-performance path for generating structured data,
    suitable for use with PyArrow, Polars, and other Arrow-compatible tools.

    The data is generated in columnar format and returned as a PyArrow
    RecordBatch, which can be converted to pandas DataFrames, Polars
    DataFrames, or used directly with Arrow-based processing tools.

    The schema format is identical to records().

    Note:
        Requires pyarrow to be installed: pip install pyarrow

        Columns are ordered alphabetically by field name (not by Python dict
        insertion order), matching the behavior of records_tuples().

    Args:
        n: Number of records to generate.
        schema: Dictionary mapping field names to type specifications.

    Returns:
        A pyarrow.RecordBatch with the generated data.

    Example:
        >>> import pyarrow as pa
        >>> from forgery import records_arrow, seed
        >>> seed(42)
        >>> batch = records_arrow(1000, {
        ...     "id": "uuid",
        ...     "name": "name",
        ...     "age": ("int", 18, 65),
        ...     "salary": ("float", 30000.0, 150000.0),
        ... })
        >>> batch.num_rows
        1000
        >>> batch.num_columns
        4
        >>> # Convert to pandas
        >>> df = batch.to_pandas()
        >>> # Convert to polars
        >>> import polars as pl
        >>> df_polars = pl.from_arrow(batch)
    """
    return fake.records_arrow(n, schema)


# === Async Records Generation ===


def records_async(
    n: int, schema: Schema, chunk_size: int | None = None
) -> Coroutine[Any, Any, list[dict[str, object]]]:
    """Generate structured records asynchronously for non-blocking batch generation.

    This method generates records in chunks, yielding control between chunks
    to allow other async tasks to run. Ideal for generating millions of records
    without blocking the event loop.

    The schema format is identical to records().

    Note on RNG State:
        The async methods use a snapshot of the RNG state at call time. The main
        Faker instance's RNG is not advanced. For different results on each call,
        create separate Faker instances or re-seed between calls.

    Args:
        n: Number of records to generate.
        schema: Dictionary mapping field names to type specifications.
        chunk_size: Number of records per chunk (default: 10,000).
            Smaller chunks yield control more frequently.

    Returns:
        A coroutine that resolves to a list of dictionaries.

    Example:
        >>> import asyncio
        >>> from forgery import records_async, seed
        >>> async def main():
        ...     seed(42)
        ...     records = await records_async(1_000_000, {
        ...         "name": "name",
        ...         "email": "email",
        ...     })
        ...     return len(records)
        >>> asyncio.run(main())
        1000000
    """
    return fake.records_async(n, schema, chunk_size)


def records_tuples_async(
    n: int, schema: Schema, chunk_size: int | None = None
) -> Coroutine[Any, Any, list[tuple[object, ...]]]:
    """Generate structured records as tuples asynchronously.

    Similar to records_async() but returns tuples instead of dictionaries,
    which is faster for large datasets. Values are returned in alphabetical
    order of the schema keys.

    The schema format is identical to records().

    Args:
        n: Number of records to generate.
        schema: Dictionary mapping field names to type specifications.
        chunk_size: Number of records per chunk (default: 10,000).

    Returns:
        A coroutine that resolves to a list of tuples.

    Example:
        >>> import asyncio
        >>> from forgery import records_tuples_async, seed
        >>> async def main():
        ...     seed(42)
        ...     records = await records_tuples_async(100, {
        ...         "age": ("int", 18, 65),
        ...         "name": "name",
        ...     })
        ...     return len(records)
        >>> asyncio.run(main())
        100
    """
    return fake.records_tuples_async(n, schema, chunk_size)


def records_arrow_async(
    n: int, schema: Schema, chunk_size: int | None = None
) -> Coroutine[Any, Any, "pyarrow.RecordBatch"]:
    """Generate structured records as a PyArrow RecordBatch asynchronously.

    This is the high-performance async path for generating structured data.
    Generates data in chunks and concatenates them into a single RecordBatch.

    The schema format is identical to records().

    Important: Chunking Affects Output
        When n > chunk_size, the output differs from records_arrow() due to
        column-major RNG consumption within each chunk. For identical results
        to the sync version, set chunk_size >= n.

    Note:
        Requires pyarrow to be installed: pip install pyarrow

    Args:
        n: Number of records to generate.
        schema: Dictionary mapping field names to type specifications.
        chunk_size: Number of records per chunk (default: 10,000).

    Returns:
        A coroutine that resolves to a PyArrow RecordBatch.

    Example:
        >>> import asyncio
        >>> import pyarrow as pa
        >>> from forgery import records_arrow_async, seed
        >>> async def main():
        ...     seed(42)
        ...     batch = await records_arrow_async(100_000, {
        ...         "id": "uuid",
        ...         "name": "name",
        ...     })
        ...     return batch.num_rows
        >>> asyncio.run(main())
        100000
    """
    return fake.records_arrow_async(n, schema, chunk_size)


# === Pattern Template Generation ===


def numerify(pattern: str) -> str:
    """Replace `#` with random digits in a pattern string."""
    return fake.numerify(pattern)


def numerify_batch(pattern: str, n: int) -> list[str]:
    """Replace `#` with random digits in batch."""
    return fake.numerify_batch(pattern, n)


def letterify(pattern: str) -> str:
    """Replace `?` with random lowercase letters in a pattern string."""
    return fake.letterify(pattern)


def letterify_batch(pattern: str, n: int) -> list[str]:
    """Replace `?` with random lowercase letters in batch."""
    return fake.letterify_batch(pattern, n)


def bothify(pattern: str) -> str:
    """Replace `#` with digits and `?` with lowercase letters."""
    return fake.bothify(pattern)


def bothify_batch(pattern: str, n: int) -> list[str]:
    """Replace `#` with digits and `?` with lowercase letters in batch."""
    return fake.bothify_batch(pattern, n)


def lexify(pattern: str) -> str:
    """Replace `?` with random uppercase letters in a pattern string."""
    return fake.lexify(pattern)


def lexify_batch(pattern: str, n: int) -> list[str]:
    """Replace `?` with random uppercase letters in batch."""
    return fake.lexify_batch(pattern, n)


# === Barcode Generation ===


def ean13() -> str:
    """Generate a single EAN-13 barcode with valid check digit."""
    return fake.ean13()


def ean13s(n: int) -> list[str]:
    """Generate a batch of EAN-13 barcodes."""
    return fake.ean13s(n)


def ean8() -> str:
    """Generate a single EAN-8 barcode with valid check digit."""
    return fake.ean8()


def ean8s(n: int) -> list[str]:
    """Generate a batch of EAN-8 barcodes."""
    return fake.ean8s(n)


def upc_a() -> str:
    """Generate a single UPC-A barcode with valid check digit."""
    return fake.upc_a()


def upc_as(n: int) -> list[str]:
    """Generate a batch of UPC-A barcodes."""
    return fake.upc_as(n)


def upc_e() -> str:
    """Generate a single UPC-E barcode."""
    return fake.upc_e()


def upc_es(n: int) -> list[str]:
    """Generate a batch of UPC-E barcodes."""
    return fake.upc_es(n)


# === ISBN Generation ===


def isbn10() -> str:
    """Generate a single ISBN-10 with hyphens and valid check digit."""
    return fake.isbn10()


def isbn10s(n: int) -> list[str]:
    """Generate a batch of ISBN-10 codes."""
    return fake.isbn10s(n)


def isbn13() -> str:
    """Generate a single ISBN-13 with hyphens and valid check digit."""
    return fake.isbn13()


def isbn13s(n: int) -> list[str]:
    """Generate a batch of ISBN-13 codes."""
    return fake.isbn13s(n)


# === File/System Generation ===


def file_name() -> str:
    """Generate a single random file name."""
    return fake.file_name()


def file_names(n: int) -> list[str]:
    """Generate a batch of random file names."""
    return fake.file_names(n)


def file_extension() -> str:
    """Generate a single random file extension."""
    return fake.file_extension()


def file_extensions(n: int) -> list[str]:
    """Generate a batch of random file extensions."""
    return fake.file_extensions(n)


def mime_type() -> str:
    """Generate a single random MIME type."""
    return fake.mime_type()


def mime_types(n: int) -> list[str]:
    """Generate a batch of random MIME types."""
    return fake.mime_types(n)


def file_path_() -> str:
    """Generate a single random file path.

    Note: Named file_path_ to avoid shadowing os.path or similar.
    """
    return fake.file_path()


def file_paths(n: int) -> list[str]:
    """Generate a batch of random file paths."""
    return fake.file_paths(n)


# === Commerce/Product Generation ===


def product_name() -> str:
    """Generate a single random product name."""
    return fake.product_name()


def product_names(n: int) -> list[str]:
    """Generate a batch of random product names."""
    return fake.product_names(n)


def product_category() -> str:
    """Generate a single random product category."""
    return fake.product_category()


def product_categories(n: int) -> list[str]:
    """Generate a batch of random product categories."""
    return fake.product_categories(n)


def department() -> str:
    """Generate a single random department name."""
    return fake.department()


def departments(n: int) -> list[str]:
    """Generate a batch of random department names."""
    return fake.departments(n)


def product_material() -> str:
    """Generate a single random product material."""
    return fake.product_material()


def product_materials(n: int) -> list[str]:
    """Generate a batch of random product materials."""
    return fake.product_materials(n)


# === SSN/National ID Generation ===


def ssn() -> str:
    """Generate a single locale-specific national ID number."""
    return fake.ssn()


def ssns(n: int) -> list[str]:
    """Generate a batch of locale-specific national ID numbers."""
    return fake.ssns(n)


# === Vehicle/Automotive Generation ===


def license_plate() -> str:
    """Generate a single locale-specific license plate."""
    return fake.license_plate()


def license_plates(n: int) -> list[str]:
    """Generate a batch of locale-specific license plates."""
    return fake.license_plates(n)


def vehicle_make() -> str:
    """Generate a single random vehicle make."""
    return fake.vehicle_make()


def vehicle_makes(n: int) -> list[str]:
    """Generate a batch of random vehicle makes."""
    return fake.vehicle_makes(n)


def vehicle_model() -> str:
    """Generate a single random vehicle model."""
    return fake.vehicle_model()


def vehicle_models(n: int) -> list[str]:
    """Generate a batch of random vehicle models."""
    return fake.vehicle_models(n)


def vehicle_year() -> int:
    """Generate a single random vehicle year."""
    return fake.vehicle_year()


def vehicle_years(n: int) -> list[int]:
    """Generate a batch of random vehicle years."""
    return fake.vehicle_years(n)


def vin() -> str:
    """Generate a single VIN with valid check digit."""
    return fake.vin()


def vins(n: int) -> list[str]:
    """Generate a batch of VINs."""
    return fake.vins(n)


# === Profile Generation ===


def profile() -> dict[str, str]:
    """Generate a single user profile as a dictionary.

    Returns dict with keys: first_name, last_name, name, email, phone,
    address, city, state, zip_code, country, company, job, date_of_birth.
    """
    return fake.profile()


def profiles(n: int) -> list[dict[str, str]]:
    """Generate a batch of user profiles."""
    return fake.profiles(n)


# === Custom Providers ===


def add_provider(name: str, options: list[str]) -> None:
    """Register a custom provider on the default Faker instance.

    Each option has equal probability of being selected.

    Args:
        name: The provider name (must not conflict with built-in types)
        options: List of string options to choose from

    Raises:
        ValueError: If name conflicts with built-in type or options is empty

    Example:
        >>> from forgery import add_provider, generate, seed
        >>> add_provider("team", ["Engineering", "Sales", "HR", "Marketing"])
        >>> seed(42)
        >>> team = generate("team")
        >>> team in ["Engineering", "Sales", "HR", "Marketing"]
        True
    """
    fake.add_provider(name, options)


def add_weighted_provider(name: str, weighted_options: list[tuple[str, int]]) -> None:
    """Register a weighted custom provider on the default Faker instance.

    Options are selected based on their relative weights. Higher weights mean
    the option is more likely to be selected.

    Args:
        name: The provider name (must not conflict with built-in types)
        weighted_options: List of (value, weight) tuples (weights must be >= 0)

    Raises:
        ValueError: If name conflicts, options empty, weights negative, or weights invalid

    Example:
        >>> from forgery import add_weighted_provider, generate_batch, seed
        >>> add_weighted_provider("status", [("active", 80), ("inactive", 20)])
        >>> seed(42)
        >>> statuses = generate_batch("status", 1000)
        >>> # Expect ~800 "active", ~200 "inactive"
    """
    # Validate weights are non-negative before passing to Rust
    for value, weight in weighted_options:
        if weight < 0:
            raise ValueError(f"Weight for '{value}' must be non-negative, got {weight}")
    fake.add_weighted_provider(name, weighted_options)


def remove_provider(name: str) -> bool:
    """Remove a custom provider from the default Faker instance.

    Args:
        name: The provider name to remove

    Returns:
        True if provider was removed, False if it didn't exist
    """
    return fake.remove_provider(name)


def has_provider(name: str) -> bool:
    """Check if a custom provider exists on the default Faker instance.

    Args:
        name: The provider name to check

    Returns:
        True if provider exists, False otherwise
    """
    return fake.has_provider(name)


def list_providers() -> list[str]:
    """List all custom provider names on the default Faker instance.

    Returns:
        List of registered custom provider names
    """
    return fake.list_providers()


def generate(name: str) -> str:
    """Generate a single value from a custom provider.

    Args:
        name: The custom provider name

    Returns:
        A randomly selected string from the provider's options

    Raises:
        ValueError: If provider doesn't exist

    Example:
        >>> from forgery import add_provider, generate, seed
        >>> add_provider("color_code", ["red", "green", "blue"])
        >>> seed(42)
        >>> generate("color_code")
        'green'
    """
    return fake.generate(name)


def generate_batch(name: str, n: int) -> list[str]:
    """Generate a batch of values from a custom provider.

    Args:
        name: The custom provider name
        n: Number of values to generate

    Returns:
        A list of randomly selected strings

    Raises:
        ValueError: If provider doesn't exist or n exceeds batch limit

    Example:
        >>> from forgery import add_provider, generate_batch, seed
        >>> add_provider("size", ["small", "medium", "large"])
        >>> seed(42)
        >>> sizes = generate_batch("size", 100)
        >>> len(sizes)
        100
    """
    return fake.generate_batch(name, n)
