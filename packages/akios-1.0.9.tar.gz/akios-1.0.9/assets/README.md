# Add your logo files here:
# - logo.png (main logo)
# - logo.svg (vector version)
# - logo-dark.png (dark mode version)
# - icon.png (favicon size)
# - banner.png (social media banner)

# The release script will automatically include this assets/ directory
