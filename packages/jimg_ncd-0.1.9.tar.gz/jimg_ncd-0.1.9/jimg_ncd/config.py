# jimg_ncd/config.py
_DISPLAY_MODE = True
