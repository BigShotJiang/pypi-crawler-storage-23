AxisArray module
##################


.. automodule:: ezmsg.util.messages.axisarray
   :show-inheritance:
   :members:
