`ezmsg` Entry Point
========================

An ezmsg pipeline is instantiated through a call to ``ezmsg.core.run()``. 

.. note:: It is convention to ``import ezmsg.core as ez`` and then use this shorthand in your code.


.. autofunction:: ezmsg.core.run
