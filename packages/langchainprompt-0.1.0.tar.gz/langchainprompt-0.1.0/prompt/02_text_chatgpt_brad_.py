from langchain.chat_models import init_chat_model
from IPython.display import Markdown, display
import os

# Set API key (Better: use environment variable instead of hardcoding)
os.environ["GOOGLE_API_KEY"] = "AIzaSyCkHkRVlPDrqO6o7VulXplYZTc82hZ9RgE"

# Initialize model
model = init_chat_model("google_genai:gemini-2.5-flash-lite")

print("Type 'exit' to stop.\n")

while True:
    query = input("Enter Query: ")

    if query.lower() == "exit":
        print("Chat Ended.")
        break

    try:
        response = model.invoke(query)
        print(f"\nUser Query: {query}")
        print("AI Answer:\n")
        display(Markdown(response.content))

    except Exception as e:
        print("Error:", e)