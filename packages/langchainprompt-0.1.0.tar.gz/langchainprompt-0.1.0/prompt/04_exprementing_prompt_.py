import os
from langchain.chat_models import init_chat_model
from langchain_core.prompts import PromptTemplate
from IPython.display import display, Markdown

os.environ["GOOGLE_API_KEY"]="AIzaSyCkHkRVlPDrqO6o7VulXplYZTc82hZ9RgE"

p = PromptTemplate(
    input_variables=["pet","color"],
    template="Suggest one name for a cat. The cat is a {color} {pet}. Give only one name."
)

m = init_chat_model("google_genai:gemini-2.5-flash-lite")

inputs = {"pet":"dog","color":"black"}

r = (p | m).invoke(inputs)

display(Markdown(f"**User Input:** {p.format(**inputs)}"))
display(Markdown(f"**AI Response:** {r.content}"))