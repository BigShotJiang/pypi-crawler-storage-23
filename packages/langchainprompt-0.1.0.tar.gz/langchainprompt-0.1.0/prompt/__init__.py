import os

def run():
    print("\nAvailable Prompt Files:\n")

    current_dir = os.path.dirname(__file__)

    files = sorted(
        [f for f in os.listdir(current_dir)
         if f.endswith(".py") and f != "__init__.py"]
    )

    for index, file in enumerate(files, start=1):
        print(f"{index}. {file}")

    try:
        choice = int(input("\nEnter file number to display: "))
    except ValueError:
        print("Invalid input.")
        return

    if 1 <= choice <= len(files):
        selected_file = files[choice - 1]
        file_path = os.path.join(current_dir, selected_file)

        print(f"\n--- Showing content of {selected_file} ---\n")

        with open(file_path, "r", encoding="utf-8") as f:
            print(f.read())
    else:
        print("Invalid choice.")