import os
from langchain.chat_models import init_chat_model
from IPython.display import display, Markdown

os.environ["GOOGLE_API_KEY"]="AIzaSyCkHkRVlPDrqO6o7VulXplYZTc82hZ9RgE"

m=init_chat_model("google_genai:gemini-2.5-flash-lite")

prompt="generate a loop and print star"

r=m.invoke(prompt)

print("User Query:",prompt)
print("AI Answer:\n")
display(Markdown(r.content))