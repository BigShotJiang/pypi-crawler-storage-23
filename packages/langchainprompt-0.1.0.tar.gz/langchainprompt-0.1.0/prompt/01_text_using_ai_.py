from langchain.chat_models import init_chat_model
import os

# Set your Google API Key
os.environ["GOOGLE_API_KEY"] = "AIzaSyCkHkRVlPDrqO6o7VulXplYZTc82hZ9RgE"

# Initialize model
model = init_chat_model("google_genai:gemini-2.5-flash-lite")

print("Type 'quit' to exit.\n")

while True:
    query = input("Enter Query: ")

    if query.lower() == "quit":
        print("Exiting the program...")
        break

    try:
        response = model.invoke(query)
        print(f"\nUser Query: {query}")
        print(f"AI Answer: {response.content}\n")

    except Exception as e:
        print("Error:", e)