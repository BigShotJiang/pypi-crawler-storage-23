"""Workspace extensions: skills + tools, with quarantine + analysis + enablement gates."""

