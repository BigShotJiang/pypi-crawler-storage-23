# World Model

## Mission Hypotheses

- (capture evidence-backed hypotheses here)

## Signals To Watch

- (list stable external signals and why they matter)
