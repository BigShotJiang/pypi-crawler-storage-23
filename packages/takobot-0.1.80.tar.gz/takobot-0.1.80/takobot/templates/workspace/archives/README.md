# archives/ — Archives (PARA)

Archives hold completed or inactive items:

- finished projects
- old resources
- deprecated plans

Conventions:

- Prefer moving items here rather than deleting them.
- Keep paths stable when possible (move whole project files/folders as-is).

