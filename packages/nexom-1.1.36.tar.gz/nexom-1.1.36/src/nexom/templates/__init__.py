"""Template helpers provided by Nexom."""

from .auth import AuthPages

__all__ = [
    "AuthPages",
]
