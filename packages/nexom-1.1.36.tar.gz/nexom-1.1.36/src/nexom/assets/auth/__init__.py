"""Auth asset templates."""

