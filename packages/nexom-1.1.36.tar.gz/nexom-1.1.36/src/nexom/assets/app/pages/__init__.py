"""Default page handler templates."""

