irc
===

.. automodule:: wmflib.irc
   :exclude-members: _send_message, emit
