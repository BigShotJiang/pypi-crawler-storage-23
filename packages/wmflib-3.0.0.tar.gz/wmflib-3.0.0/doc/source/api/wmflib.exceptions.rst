exceptions
==========

.. automodule:: wmflib.exceptions
