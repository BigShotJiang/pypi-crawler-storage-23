constants
=========

.. automodule:: wmflib.constants