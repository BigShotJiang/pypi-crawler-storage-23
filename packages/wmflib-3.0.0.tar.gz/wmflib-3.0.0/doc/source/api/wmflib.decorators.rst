decorators
==========

.. automodule:: wmflib.decorators
   :exclude-members: _exception_message, ensure_wrap, get_backoff_sleep
