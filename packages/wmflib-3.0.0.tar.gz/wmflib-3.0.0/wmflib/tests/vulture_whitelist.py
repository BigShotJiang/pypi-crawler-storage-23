"""Vulture whitelist to avoid false positives."""


class Whitelist:
    """Helper class that allows mocking Python objects."""

    def __getattr__(self, _):
        """Mocking magic method __getattr__."""


whitelist_interactive = Whitelist()
whitelist_interactive.notify_logger.propagate
