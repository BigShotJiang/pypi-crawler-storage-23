Quick Start
===========

.. include:: ../../README.md
   :parser: myst_parser.sphinx_
   :start-after: ## Quick Start
   :end-before: ## Configuration

For configuration options, see :doc:`configuration`.
