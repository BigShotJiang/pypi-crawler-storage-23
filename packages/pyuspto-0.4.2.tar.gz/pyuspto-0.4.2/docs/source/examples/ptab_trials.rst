PTAB Trials Example
===================

.. literalinclude:: ../../../examples/ptab_trials_example.py
   :language: python
   :linenos:
