Configuration
=============

.. include:: ../../README.md
   :parser: myst_parser.sphinx_
   :start-after: ## Configuration
   :end-before: ## API Usage Examples
