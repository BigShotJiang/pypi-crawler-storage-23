PTAB
====

.. automodule:: pyUSPTO.models.ptab
   :members:
   :undoc-members:
   :show-inheritance:
