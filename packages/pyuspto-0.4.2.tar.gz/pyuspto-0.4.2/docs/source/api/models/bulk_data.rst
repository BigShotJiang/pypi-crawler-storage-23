Bulk Data
=========

.. automodule:: pyUSPTO.models.bulk_data
   :members:
   :undoc-members:
   :show-inheritance:
