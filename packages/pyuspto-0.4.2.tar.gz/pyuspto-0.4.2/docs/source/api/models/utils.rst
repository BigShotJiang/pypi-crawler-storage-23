Utils
=====

.. automodule:: pyUSPTO.models.utils
   :members:
   :undoc-members:
   :show-inheritance:
