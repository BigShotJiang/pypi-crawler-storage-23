Bulk Data Client
================

.. automodule:: pyUSPTO.clients.bulk_data
   :members:
   :undoc-members:
   :show-inheritance:
