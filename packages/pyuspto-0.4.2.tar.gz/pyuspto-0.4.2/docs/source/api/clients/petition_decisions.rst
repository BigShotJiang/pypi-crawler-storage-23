Petition Decisions Client
=========================

.. automodule:: pyUSPTO.clients.petition_decisions
   :members:
   :undoc-members:
   :show-inheritance:
