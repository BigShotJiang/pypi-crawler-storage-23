PTAB Appeals Client
===================

.. automodule:: pyUSPTO.clients.ptab_appeals
   :members:
   :undoc-members:
   :show-inheritance:
