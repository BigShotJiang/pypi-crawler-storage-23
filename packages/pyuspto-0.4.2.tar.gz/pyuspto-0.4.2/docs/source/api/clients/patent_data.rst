Patent Data Client
==================

.. automodule:: pyUSPTO.clients.patent_data
   :members:
   :undoc-members:
   :show-inheritance:
