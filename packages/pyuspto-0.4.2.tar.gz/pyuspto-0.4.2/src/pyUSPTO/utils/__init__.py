"""utils - Utility functions for USPTO API clients.

This package provides utility functions for USPTO API clients.
"""
