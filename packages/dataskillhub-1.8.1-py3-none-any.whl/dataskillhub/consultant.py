import os
import shutil
from pathlib import Path

from .cv import CV
from .extract import get_dcs
from .init_src import create_folder

consultants_path = "consultants"
config_path = "config"
template_path = "templates"


def make_cvs(dc_list, source_path, output_path, asset_path):
    create_folder(output_path)
    html_assets = os.path.relpath(asset_path, output_path)
    html_source = os.path.relpath(source_path, output_path)
    for dc in dc_list:
        cv = CV(
            dossier_competence=dc,
            cv_template_path=f"{template_path}/index.html",
            anonymous_doc_path=f"{config_path}/anonyme.json",
        )
        shutil.copyfile(
            f"{source_path}/export.yml",
            f"{output_path}/export.yml",
        )
        output_path_name = f"{output_path}/{dc.file_id}"
        if dc.anonyme is True:
            cv.make_html(
                output_path_name,
                html_assets,
                html_source,
                "anonyme",
                anonimize=True,
            )
            cv.make_pdf(
                output_path_name,
                asset_path,
                source_path,
                "anonyme",
                anonimize=True,
            )
        else:
            cv.make_html(
                output_path_name,
                html_assets,
                html_source,
                "normal",
                anonimize=False,
            )
            cv.make_pdf(
                output_path_name,
                asset_path,
                source_path,
                "normal",
                anonimize=False,
            )


def export_consultant(consultant, output_path, asset_path):
    consultant_path = f"{consultants_path}/{consultant}"
    output_consultant = f"{output_path}/{consultant}"

    if Path(f"{consultant_path}/export.yml").exists():
        dcs = get_dcs(consultant_path)
        make_cvs(dcs, consultant_path, output_consultant, asset_path)

    for version in os.listdir(consultant_path):
        version_path = f"{consultant_path}/{version}"
        output_consultant_version = f"{output_consultant}/{version}"
        if os.path.isdir(version_path):
            dcs = get_dcs(version_path)
            make_cvs(dcs, version_path, output_consultant_version, asset_path)


def get_consultants():
    consultant_list = []
    path = Path(consultants_path)
    for i in path.iterdir():
        consultant_list.append(i.name)
    return consultant_list


def add_consultant(consultant: str):
    folder_path = Path(f"{consultants_path}/{consultant}")
    folder_path.mkdir(parents=True, exist_ok=True)


def check_consultant(consultant: str):
    file_miss = False
    file_list = [
        "export.yml",
        "valeur_ajoutee.md",
        "competences_cles.md",
        "diplomes.md",
        "certifications_formations.md",
        "langues.md",
        "animateur.md",
        "missions_significatives.md",
    ]
    for f in file_list:
        path = Path(f"{consultants_path}/{consultant}/{f}")
        if not path.exists():
            file_miss = True
            print(f"{f} is missing.")
    if not file_miss:
        print("All files exist.")
