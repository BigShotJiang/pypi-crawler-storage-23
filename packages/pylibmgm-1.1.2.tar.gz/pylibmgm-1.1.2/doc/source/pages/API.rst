API Reference
======================
.. toctree::
    :maxdepth: 2
    
    api/pylibmgm
    api/io
    api/solver