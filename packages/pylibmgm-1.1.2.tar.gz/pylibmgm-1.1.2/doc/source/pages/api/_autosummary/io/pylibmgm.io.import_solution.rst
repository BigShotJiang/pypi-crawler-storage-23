﻿pylibmgm.io.import\_solution
============================

.. currentmodule:: pylibmgm.io




.. autofunction:: import_solution
