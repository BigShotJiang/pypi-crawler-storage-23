﻿pylibmgm.omp\_set\_num\_threads
===============================

.. currentmodule:: pylibmgm




.. autofunction:: omp_set_num_threads
