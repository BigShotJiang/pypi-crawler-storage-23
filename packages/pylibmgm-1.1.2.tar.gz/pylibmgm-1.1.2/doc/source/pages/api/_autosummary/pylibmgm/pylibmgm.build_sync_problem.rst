﻿pylibmgm.build\_sync\_problem
=============================

.. currentmodule:: pylibmgm




.. autofunction:: build_sync_problem
