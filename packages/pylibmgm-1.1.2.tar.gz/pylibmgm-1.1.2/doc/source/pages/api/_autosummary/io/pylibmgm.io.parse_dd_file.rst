﻿pylibmgm.io.parse\_dd\_file
===========================

.. currentmodule:: pylibmgm.io




.. autofunction:: parse_dd_file
