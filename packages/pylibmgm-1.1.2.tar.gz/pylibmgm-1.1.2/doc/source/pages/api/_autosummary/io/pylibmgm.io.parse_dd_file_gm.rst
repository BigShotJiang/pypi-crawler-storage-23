﻿pylibmgm.io.parse\_dd\_file\_gm
===============================

.. currentmodule:: pylibmgm.io




.. autofunction:: parse_dd_file_gm
