﻿pylibmgm.solver.solve\_mgm\_parallel
====================================

.. currentmodule:: pylibmgm.solver




.. autofunction:: solve_mgm_parallel
