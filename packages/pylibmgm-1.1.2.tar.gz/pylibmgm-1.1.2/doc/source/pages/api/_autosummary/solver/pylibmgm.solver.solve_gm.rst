﻿pylibmgm.solver.solve\_gm
=========================

.. currentmodule:: pylibmgm.solver




.. autofunction:: solve_gm
