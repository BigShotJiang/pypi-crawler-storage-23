﻿pylibmgm.solver.solve\_mgm\_pairwise
====================================

.. currentmodule:: pylibmgm.solver




.. autofunction:: solve_mgm_pairwise
