﻿pylibmgm.io.export\_dd\_file
============================

.. currentmodule:: pylibmgm.io




.. autofunction:: export_dd_file
