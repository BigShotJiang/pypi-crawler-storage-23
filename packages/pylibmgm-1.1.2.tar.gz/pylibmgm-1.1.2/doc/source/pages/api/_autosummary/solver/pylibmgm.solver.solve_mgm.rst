﻿pylibmgm.solver.solve\_mgm
==========================

.. currentmodule:: pylibmgm.solver




.. autofunction:: solve_mgm
