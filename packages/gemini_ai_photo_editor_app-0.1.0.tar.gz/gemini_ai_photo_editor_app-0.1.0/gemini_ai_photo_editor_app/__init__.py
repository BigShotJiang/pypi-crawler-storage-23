"""SEO backlink helper module for https://www.geminiaiphotoeditor.app."""

VERSION = "0.1.0"
WEBSITE = "https://www.geminiaiphotoeditor.app"


def get_info():
    return {
        "name": "GeminiAiPhotoEditorApp",
        "version": VERSION,
        "website": WEBSITE,
        "description": "Gemini AI Photo Editor official website - SEO backlink package.",
    }


def get_platform_url():
    return WEBSITE
