"""
Module from https://gitlab.pprriieeuurr.fr/guill_prieur/ascii-art-python
"""
__version__ = "0.1.1"
from . import new_school

if __name__ == "__main__":
    print(new_school.ImageAscii.from_string("ASCII Art", 15))
