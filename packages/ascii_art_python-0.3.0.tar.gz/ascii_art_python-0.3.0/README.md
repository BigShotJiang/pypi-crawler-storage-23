# ASCII Art Python 🎨 - Convert Images & Videos to Terminal Graphics

<div align="center">

[![PyPI version](https://img.shields.io/pypi/v/ascii-art-python.svg)](https://pypi.org/project/ascii-art-python/)
[![Python versions](https://img.shields.io/pypi/pyversions/ascii-art-python.svg)](https://pypi.org/project/ascii-art-python/)
[![PyPI Downloads](https://img.shields.io/pypi/dm/ascii-art-python.svg)](https://pypi.org/project/ascii-art-python/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

</div>

This module provides advanced tools for converting classic images and videos into ASCII Art. It allows exporting the results as text files, new images, or new videos (with or without audio), and even playing videos directly in your terminal.

## 👀 Examples

```
@@@@@@@@@@@@@@@@@@@@@@@@@@$&#{{{{{{{{{{{#&$@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@&{*********{{{{{{{{{{{{{*{#@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@#**********{{{{{{{{{{{{{{{{{{{{$@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@#***{$@@@${*{{{{{{{{{{{{{{{{{{{{{&@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@{***&@@@@@&*{{{{{{{{{{{{{{{{{{{{{{@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@{***{$@@@${{{{{{{{{{{{{{{{{{{{{{{{@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@{***{****{{{{{{{{{{{{{{{{{{{{{{{{{@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@{*************{{{{{{{{{{{{{{{{{{{{@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#{{{{{{{{{{{{{{{{@@@@@@@@@@@@@@@@@@
@@@@@@@@&#{{{{{{{{{{{{#############{{{{{{{{{{{{{{{{{@@;.:::.::=#@@@@@@
@@@@${********{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{@@;.::::::::.=@@@@
@@@{********{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{@@;.::::::::::.#@@
@$********{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{@@;.::::::::::::#@
@{******{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{@@;:::::::::::::;@
&*****{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{&@$:::::::::::::::{
{***{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{$@@=.::::::::::::::=
{*{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{{#$@@@=.::::::::::::::::
{{{{{{{{{{{{{{{{{{{{{#$@@@@@@@@@@@@@@@@@@@@@@@@@@$=.::::::::::::::::::
{{{{{{{{{{{{{{{{{{#@@@@&*=;;;;;;;;;;;;;;;;;;;;:..:::::::::::::::::::::
{{{{{{{{{{{{{{{{{$@@#:........:::::::::::::::::::::::::::::::::::::::;
#*{{{{{{{{{{{{{{$@@:........:::::::::::::::::::::::::::::::::::::::::(
${{{{{{{{{{{{{{{@@=.......:::::::::::::::::::::::::::::::::::::::::::&
@#*{{{{{{{{{{{{{@$:.....::::::::::::::::::::::::::::::::::::::::::::*@
@@{{{{{{{{{{{{{{@$:...:::::::::::::::::::::::::::::::::::::::::::::(@@
@@@#*{{{{{{{{{{{@$:..:::::::::::::::::::::::::::::::::::::::::::::&@@@
@@@@@#{{{{{{{{{{@$:.:::::::::::::::.:::::::::::::::::::::::::::($@@@@@
@@@@@@@@@$$$$$$@@$:.:::::::::::::.=@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@$:.:::::::::::::::================*@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@$:::::::::::::::::::::::::::::::::=@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@$:::::::::::::::::::::::::({(:::::=@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@$:::::::::::::::::::::::(@@@@@(:::=@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@;.:::::::::::::::::::::*@@@@@*:::=@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@$::::::::::::::::::::::::*#*:::::#@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@#:.::::::::::::::::::::::::::(@@@@@@@@@@@@@@@@@@@@
@@@@@@@@@@@@@@@@@@@@@@@$*;::::::::::::::::::;(#@@@@@@@@@@@@@@@@@@@@@@@
```

![Example with the Nyan Cat video played in a terminal.](https://media0.giphy.com/media/v1.Y2lkPTc5MGI3NjExczN5eXo0cHRyMnRzZjVxOHI4NXN1cjc2ZzIyNHQ5cTkyMW8weHVhYSZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9Zw/n0MEinoLqWEdHb129d/giphy.gif)

## 🔧 Features

- Image to ASCII conversion
- Video to ASCII animation with sound extraction
- Play video directly in the terminal
- Export to .txt, .png, .mp4, or .avi

## 📦 Installation

You can install the module via pip:

```bash
pip install ascii-art-python
```

## 🚀 Basic Usage

To use the module, import it as follows:

```python
import ascii_art_python as aap
```

## 📚 API Reference

### 1. Enumerations (Enums)

These enumerations are used to define the export format or quality.

`aap.new_school.ExportType` : Defines the file type when exporting an image or a video.

- `aap.new_school.ExportType.IMAGE_FILE` (0): Exports as classic media (PNG image or MP4/AVI video).

- `aap.new_school.ExportType.TEXT_FILE` (1): Exports as a plain text file (.txt or .vid.txt).

`aap.new_school.VideoAscii.ExportQuality` : Defines the video compression quality (and the codec used) during export.

- `aap.new_school.VideoAscii.ExportQuality.LOW` (0): Low quality (mp4v codec, .mp4 format).

- `aap.new_school.VideoAscii.ExportQuality.HIGH` (1): High quality (FFV1 codec, .avi format).

### 2. Class `ImageAscii`

Manages the conversion and manipulation of a still image into ASCII art.

#### Constructors

- `ImageAscii(image: PIL.Image.Image, max_size: int = 100_000, grid: list[str] = None)`
    - Description: Initializes an instance from an image object of the PIL/Pillow library.
    - Parameters:
        - `image`: The source image (Pillow).
        - `max_size`: The maximum size (number of pixels/characters) for the generated ASCII image.
        - `grid`: The list of characters to use (from darkest to lightest). If None, uses the default grid.
- `ImageAscii.from_path(path: str, max_size: int = 10_000, grid: list[str] = None) -> ImageAscii`
    - Description: Convenient class method to instantiate directly from a file path.
- `ImageAscii.from_string(content: str, font_size: int) -# ImageAscii`
    - Description: Convenient class method to instantiate directly from a character string.

#### Methods

- `to_list() -> list[str]`
    - Description: Converts the image into a list of strings (one string per line).
- `to_image() -> PIL.Image.Image`
    - Description: Generates and returns a new Pillow image where the ASCII has been drawn using a specific font (KreativeSquare.ttf by default).
- `export(filename: str = "mika_export", mode: ExportType = 0) -> None`
    - Description: Exports the generated image to the disk.
    - Parameters:
        - `filename`: The target file name (without extension).
        - `mode`: If ExportType.IMAGE_FILE, saves a .png. If `ExportType.TEXT_FILE`, saves a .txt.

### 3. Class VideoAscii

Manages the conversion of a complete video into an ASCII animation.

#### Constructor

- `VideoAscii(path: str, fps: int = 10, frame_size: int = 12_000)`
    - Description: Prepares a video for ASCII processing.
    - Parameters:
        - `path`: Path to the source video.
        - `fps`: Target frames per second for the ASCII render (maximum framerate).
        - `frame_size`: Maximum size of each processed frame.

#### Properties

- fps -> float: Retrieves the native FPS of the source video.
- size -> tuple[int, int]: Retrieves the dimensions (width, height) of the exported ASCII video.

#### Methods

- `export(filename: str = "mika_export", export_type: ExportType = 0, quality: ExportQuality = 0, sound: bool = False)`
    - Description: Exports the processed video.
    - Parameters:
        - `filename`: The target file name (without extension).
        - `export_type`: If `IMAGE_FILE`, generates a video. If `TEXT_FILE`, generates a custom animated text file (.vid.txt).
        - `quality`: Determines the generated video codec if the export is a video file.
        - `sound`: If True, extracts audio from the source and adds it to the final exported video.
- `print_in_terminal() -> None`
    - Description: Plays the source video as an ASCII animation directly in the terminal console, respecting the framerate limit (max_fps).

#### Static Methods

- `VideoAscii.print_from_txt(txt: str)`
    - Description: Reads and displays in the terminal the content of a .vid.txt file previously generated by the export(export_type=ExportType.TEXT_FILE) method.
- `VideoAscii.transfer_audio(source_video_path: str, target_video_path: str, output_path: str)`
    - Description: Extracts audio from `source_video_path` and applies it to `target_video_path` to generate `output_path`.

## 💡 Usage Examples

### Example 1: Convert and Export an Image

```python
import ascii_art_python as aap
# Create an object from a local file
my_image = aap.new_school.ImageAscii.from_path("my_image.jpg", max_size=50_000)

# Display ASCII in the console
print(my_image)

# Export the ASCII image in text format (.txt)
my_image.export("text_result", mode=aap.new_school.ExportType.TEXT_FILE)

# Export the ASCII image as a new readable image (.png)
my_image.export("image_result", mode=aap.new_school.ExportType.IMAGE_FILE)
```

### Example 2: Play a Video in the Terminal

```python
import ascii_art_python as aap

my_video = aap.new_school.VideoAscii("my_video.mp4", fps=15, frame_size=8_000)

# Play the animation live in the terminal
my_video.print_in_terminal()
```

### Example 3: Convert a Video with Sound

```python
import ascii_art_python as aap

my_video = aap.new_school.VideoAscii("my_video.mp4", fps=24, frame_size=15_000)

# Export the video with sound in MP4 format (Low Quality by default)
my_video.export(
    filename="final_ascii_video", 
    export_type=aap.new_school.ExportType.IMAGE_FILE, 
    sound=True
)
```

### Example 4: Convert a text and print it in the Terminal

```python
import ascii_art_python as aap

my_message = aap.new_school.ImageAscii.from_string(
    content = "Hello, World!",
    font_size = 15
)

print(my_message)
```
 
## ⚠️ Troubleshooting

### Important Note Regarding OpenCV Dependencies

This project uses **`opencv-python-headless`** for background image processing. 

Please be aware that installing both `opencv-python` (the standard version with GUI features) and `opencv-python-headless` in the **same Python environment** will cause conflicts. Doing so may break OpenCV's display capabilities (such as `cv2.imshow()`) in your other projects.

**To avoid any issues, it is highly recommended to:**
- **Use a Virtual Environment:** Always install this project inside an isolated virtual environment (using `venv`, `conda`, or Docker).
- **Check Existing Packages:** If you are installing globally and already have `opencv-python` installed, please remove it first (`pip uninstall opencv-python`) before installing this project's requirements.
