from typing import TYPE_CHECKING, Literal

from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.model.quantum_expressions.quantum_expression import (
    QuantumExpressionOperation,
)


class PhaseOperation(QuantumExpressionOperation):
    if TYPE_CHECKING:
        kind: Literal["PhaseOperation"] = "PhaseOperation"
    else:
        kind: Literal["PhaseOperation"]
    theta: Expression

    @property
    def expressions(self) -> list[Expression]:
        return super().expressions + [self.theta]
