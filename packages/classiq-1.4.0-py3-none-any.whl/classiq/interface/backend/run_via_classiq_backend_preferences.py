import warnings
from typing import Any

import pydantic

from classiq.interface.backend.backend_preferences import BackendPreferences
from classiq.interface.exceptions import ClassiqDeprecationWarning


class RunViaClassiqBackendPreferences(BackendPreferences):
    _DEPRECATED_RUN_THROUGH_CLASSIQ_MESSAGE = (
        "Parameter run_through_classiq has been renamed to run_via_classiq. Parameter run_through_classiq will no longer be supported starting on 2026-03-09 at the earliest"
        ".\nHint: Change run_through_classiq to run_via_classiq"
    )
    # TODO: Remove after deprecation period CLS-5991
    run_through_classiq: bool | None = pydantic.Field(
        default=None,
        description="Run through Classiq's credentials while using user's allocated budget.",
        deprecated=_DEPRECATED_RUN_THROUGH_CLASSIQ_MESSAGE,
    )
    run_via_classiq: bool | None = pydantic.Field(
        default=None,
        description="Run via Classiq's credentials while using user's allocated budget.",
    )

    @pydantic.model_validator(mode="before")
    @classmethod
    def _warn_if_run_through_classiq_is_set(
        cls, data: dict[str, Any]
    ) -> dict[str, Any]:
        if "run_through_classiq" in data and data["run_through_classiq"] is not None:
            warnings.warn(
                cls._DEPRECATED_RUN_THROUGH_CLASSIQ_MESSAGE,
                ClassiqDeprecationWarning,
                stacklevel=2,
            )
        return data

    @pydantic.model_validator(mode="before")
    @classmethod
    def _migrate_run_through_classiq_to_run_via_classiq(
        cls, data: dict[str, Any] | Any
    ) -> dict[str, Any] | Any:
        if not isinstance(data, dict):
            return data

        # If run_via_classiq is not set but run_through_classiq is, migrate the value
        if (
            data.get("run_via_classiq") is None
            and data.get("run_through_classiq") is not None
        ):
            data["run_via_classiq"] = data["run_through_classiq"]
            return data

        # Treat as should run via classiq if at least one of them is True
        if (
            data.get("run_via_classiq") is True
            or data.get("run_through_classiq") is True
        ):
            data["run_via_classiq"] = True

        return data
