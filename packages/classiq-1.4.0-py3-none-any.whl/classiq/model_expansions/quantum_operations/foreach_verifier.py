from typing import TYPE_CHECKING

from classiq.interface.exceptions import (
    ClassiqExpansionError,
    ClassiqInternalExpansionError,
)
from classiq.interface.generator.functions.classical_type import (
    ClassicalArray,
    ClassicalTuple,
    Integer,
    Real,
)
from classiq.interface.helpers.text_utils import s
from classiq.interface.model.power import Power

from classiq.evaluators.qmod_node_evaluators.utils import (
    QmodType,
    array_len,
    element_types,
)
from classiq.evaluators.qmod_type_inference.classical_type_inference import (
    infer_classical_type,
)
from classiq.model_expansions.quantum_operations.emitter import Emitter


def _is_foreach_array(values_type: QmodType, nested: bool) -> bool:
    return isinstance(values_type, (ClassicalArray, ClassicalTuple)) and all(
        (
            _is_foreach_array(element_type, False)
            if nested
            else isinstance(element_type, (Integer, Real))
        )
        for element_type in element_types(values_type)
    )


class ForeachVerifier(Emitter[Power]):
    """
    Verify that foreach values are CArray[CReal] without unpacking or
    CArray[CArray[CReal]] with unpacking.
    """

    def emit(self, power: Power, /) -> bool:
        if power.values is None and power.iter_vars is None:
            return False
        if power.values is None or power.iter_vars is None:
            raise ClassiqInternalExpansionError("Both foreach fields must be set")
        values = power.values.value.value

        # Verify values type
        values_type = infer_classical_type(values)
        if not _is_foreach_array(values_type, True) and not _is_foreach_array(
            values_type, False
        ):
            raise ClassiqExpansionError(
                f"Foreach values must be CArray[CReal] or CArray[CArray[CReal]], got "
                f"{str(values)!r} of type {values_type.qmod_type_name}"
            )
        if TYPE_CHECKING:
            assert isinstance(values_type, (ClassicalArray, ClassicalTuple))

        # Verify values lengths
        num_iter_vars = len(power.iter_vars)
        item_types = element_types(values_type)
        if len(item_types) == 0:
            return False
        if isinstance(item_types[0], (ClassicalArray, ClassicalTuple)):
            for item_type in item_types:
                if not isinstance(item_type, (ClassicalArray, ClassicalTuple)):
                    raise ClassiqInternalExpansionError("Heterogeneous array")
                item_len = array_len(item_type)
                if item_len is not None and item_len != num_iter_vars:
                    raise ClassiqExpansionError(
                        f"Cannot unpack {item_len} value{s(item_len)} into {num_iter_vars} variable{s(num_iter_vars)}"
                    )
        else:
            if num_iter_vars != 1:
                raise ClassiqExpansionError(
                    f"Cannot iterate over {values_type.qmod_type_name} with "
                    f"{num_iter_vars} iteration variable{s(num_iter_vars)}"
                )
        return False
