import ast


class BooleanExpressionFuncLibAdapter(ast.NodeTransformer):
    """
    The class assumes that the expression result is single-qubit.

    Due to limitations on the inplace arithmetic in our function library, this visitor checks whether
    the expression has one of the following forms:
    a. A single, simple boolean assignment (res ^= x).
    b. A bitwise-not operation on a boolean expression (res ^= ~(x > 5)).
    The former will be transformed into res ^= (x == 1). The latter to (res ^= x > 5) and then the Interpreter
    will append an X gate to the result variable.
    To understand the necessity of this transformation, see the _OPERATIONS_ALLOWING_TARGET variable
    which limits the possible inplace operations. Not is forbidden, and a simple assignment res ^= x
    is converted into an addition res ^= x + 0, which is also forbidden.

    """

    def __init__(self) -> None:
        self._to_invert: bool = False

    @property
    def to_invert(self) -> bool:
        return self._to_invert

    def visit_Expr(self, node: ast.Expr) -> ast.Expr:
        self.generic_visit(node)
        if isinstance(node.value, ast.Name):
            node.value = ast.Compare(
                left=node.value,
                ops=[ast.Eq()],
                comparators=[ast.Constant(value=1)],
            )
        if isinstance(node.value, ast.UnaryOp) and isinstance(
            node.value.op, (ast.Not, ast.Invert)
        ):
            self._to_invert = not self._to_invert
            node.value = node.value.operand
            return self.visit(node)

        return node

    def visit_UnaryOp(self, node: ast.UnaryOp) -> ast.UnaryOp:
        """Due to Sympy crap, we need to translate the Invert nodes to Not"""
        if not isinstance(node.op, ast.Invert):
            return node
        self.generic_visit(node)
        return ast.UnaryOp(op=ast.Not(), operand=node.operand)
