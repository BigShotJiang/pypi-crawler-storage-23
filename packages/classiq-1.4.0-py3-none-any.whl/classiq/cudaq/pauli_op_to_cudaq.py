from typing import TYPE_CHECKING, cast

from classiq.cudaq.cudaq_utils import require_cudaq
from classiq.qmod.builtins.structs import SparsePauliOp

if TYPE_CHECKING:
    import cudaq


def pauli_operator_to_cudaq_spin_op(operator: SparsePauliOp) -> "cudaq.SpinOperator":
    """
    Transforms Qmod's SparsePauliOp data structure to CUDA-Q's SpinOperator.

    Args:
        operator: The operator to be transformed

    Returns:
        SpinOperator: The equivalent operator in CUDA-Q's data structure
    """
    require_cudaq()

    import cudaq

    spin_operator = cudaq.SpinOperator()
    for pauli in operator.terms:
        spin_term = cudaq.SpinOperator()
        for indexed_pauli in cast(list, pauli.paulis):
            spin_term *= getattr(cudaq.spin, indexed_pauli.pauli.name.lower())(
                indexed_pauli.index
            )
        spin_operator += cast(float, pauli.coefficient) * spin_term
    return spin_operator
