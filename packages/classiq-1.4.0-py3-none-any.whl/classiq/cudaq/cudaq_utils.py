import importlib.util
from collections.abc import Sequence
from typing import TYPE_CHECKING, Union

from classiq.interface.exceptions import ClassiqError

if TYPE_CHECKING:
    import cudaq


def require_cudaq() -> None:
    missing = [m for m in ("cudaq", "openqasm3") if importlib.util.find_spec(m) is None]
    if missing:
        raise ClassiqError(
            "This feature needs the 'cudaq' extra. "
            "Install with: pip install classiq[cudaq] "
            f"(missing: {', '.join(missing)}).\n"
            f"Note: cudaq is only supported on Linux operating systems "
            f"https://nvidia.github.io/cuda-quantum/latest/using/quick_start.html\n"
            f"If you are using a different operating system, consider running on the "
            f"Classiq Studio https://docs.classiq.io/latest/user-guide/studio/Studio-Guide/ "
            f"or a Linux Docker container"
        )


CONVERSION_ERROR_PREFIX = "Cannot convert quantum program to cudaq: "
QubitOrQreg = Union["cudaq.QuakeValue", Sequence["cudaq.QuakeValue"]]
