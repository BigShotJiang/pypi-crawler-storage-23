from collections.abc import Callable
from math import pi
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import cudaq


def _u_implementation(
    kernel: "cudaq.PyKernel", theta: Any, phi: Any, lam: Any, q: "cudaq.QuakeValue"
) -> None:
    kernel.rz(lam, q)
    kernel.rx(pi / 2, q)
    kernel.rz(theta + pi, q)
    kernel.rx(pi / 2, q)
    kernel.rz(phi + 3 * pi, q)


QASM_CONSTANTS = {"pi": pi}
NATIVE_CUDAQ_STANDARD_GATES = {
    "x",
    "y",
    "z",
    "h",
    "s",
    "t",
    "sdg",
    "tdg",
    "rx",
    "ry",
    "rz",
    "cx",
    "cy",
    "cz",
    "ch",
    "cs",
    "ct",
    "crx",
    "cry",
    "crz",
    "swap",
    "cswap",
}
ATOMIC_GATE_IMPLEMENTATIONS: dict[str, Callable] = {
    "p": lambda kernel, theta, q: kernel.rz(theta, q),
    "cp": lambda kernel, theta, q1, q2: [
        kernel.rz(theta / 2, q1),
        kernel.cx(q1, q2),
        kernel.rz(-theta / 2, q2),
        kernel.cx(q1, q2),
        kernel.rz(theta / 2, q2),
    ],
    "U": _u_implementation,
    "u": _u_implementation,
    "u3": _u_implementation,
    "u2": lambda kernel, phi, lam, q: [
        kernel.rz(lam - pi / 2, q),
        kernel.rx(pi / 2, q),
        kernel.rz(phi + pi / 2, q),
    ],
    "u1": lambda kernel, lam, q: kernel.rz(lam, q),
    "cu": lambda kernel, theta, phi, lam, gamma, q1, q2: [
        kernel.rz(gamma, q1),
        kernel.rz(lam / 2 - phi / 2, q2),
        kernel.rz(lam / 2 + phi / 2, q1),
        kernel.cx(q1, q2),
        kernel.rz(-lam / 2 - phi / 2, q2),
        kernel.rx(pi / 2, q2),
        kernel.rz(pi - theta / 2, q2),
        kernel.rx(pi / 2, q2),
        kernel.rz(3 * pi, q2),
        kernel.cx(q1, q2),
        kernel.rx(pi / 2, q2),
        kernel.rz(theta / 2 + pi, q2),
        kernel.rx(pi / 2, q2),
        kernel.rz(phi + 3 * pi, q2),
    ],
    "ccx": lambda kernel, q1, q2, q3: [
        kernel.h(q3),
        kernel.cx(q2, q3),
        kernel.tdg(q3),
        kernel.cx(q1, q3),
        kernel.t(q3),
        kernel.cx(q2, q3),
        kernel.t(q2),
        kernel.tdg(q3),
        kernel.cx(q1, q3),
        kernel.cx(q1, q2),
        kernel.t(q3),
        kernel.t(q1),
        kernel.tdg(q2),
        kernel.h(q3),
        kernel.cx(q1, q2),
    ],
    "sx": lambda kernel, q: kernel.rx(pi / 2, q),
}
NON_USER_GENERATED_GATES = {"cu1"}
