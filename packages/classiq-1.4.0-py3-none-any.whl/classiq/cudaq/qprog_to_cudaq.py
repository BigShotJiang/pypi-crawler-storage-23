from collections.abc import Iterator
from contextlib import contextmanager
from itertools import chain
from typing import TYPE_CHECKING, Union

from classiq.interface.exceptions import ClassiqError, ClassiqInternalError
from classiq.interface.generator.quantum_program import QuantumProgram

from classiq.cudaq.cudaq_constants import (
    ATOMIC_GATE_IMPLEMENTATIONS,
    NATIVE_CUDAQ_STANDARD_GATES,
)
from classiq.cudaq.cudaq_expression_evaluation import (
    eval_expr,
    eval_var,
    get_angle_args,
)
from classiq.cudaq.cudaq_kernel_construction import KernelData, construct_kernel
from classiq.cudaq.cudaq_utils import (
    CONVERSION_ERROR_PREFIX,
    QubitOrQreg,
    require_cudaq,
)

if TYPE_CHECKING:
    import cudaq
    import openqasm3


def _get_qasm_ast(quantum_program: QuantumProgram) -> "openqasm3.ast.Program":
    import openqasm3

    if quantum_program.qasm is None:
        raise ClassiqError(CONVERSION_ERROR_PREFIX + "missing QASM output format")
    try:
        return openqasm3.parser.parse(quantum_program.qasm)
    except Exception as e:
        raise ClassiqError(
            CONVERSION_ERROR_PREFIX + "the provided QASM is not supported"
        ) from e


def qprog_to_cudaq_kernel(
    quantum_program: QuantumProgram, is_main_kernel: bool = True
) -> Union["cudaq.PyKernel", tuple]:
    """
    Translates a quantum program into a CUDA-Q kernel.

    The 'is_main_kernel' parameter controls the kind of the returned kernel.
    If 'is_main_kernel' is True, the returned kernel can be used with CUDA-Q functions
    such as 'cudaq.draw()' and 'cudaq.get_state()', but it cannot be added to another
    kernel via `apply_call()'.
    If 'is_main_kernel' is False, the reverse holds: The returned kernel cannot be used
    with CUDA-Q functions but can be added to another kernel.

    Args:
        quantum_program:
            The quantum program to translate into CUDA-Q kernel. This is the result of the function 'synthesize()'.
        is_main_kernel:
            Whether the kernel is compatible with CUDA-Q functions (`is_main_kernel=True`,
            the default behavior) or 'apply_call()' (`is_main_kernel=False`)

    Returns:
        A CUDA-Q kernel. If the quantum program includes foreach statements, a tuple
        containing a CUDA-Q kernel and its foreach arguments will be returned.

    Examples:
        Simulating a kernel with `is_main_kernel=True`:
        ```python
        @qfunc
        def main(x: CReal, q: Output[QBit]) -> None:
            allocate(q)
            RX(x, q)


        qprog = synthesize(main)
        kernel = qprog_to_cudaq_kernel(qprog, is_main_kernel=True)
        result = cudaq.get_state(kernel, math.pi / 2)
        ```

        Adding the kernel to another kernel with `is_main_kernel=False`:
        ```python
        @qfunc
        def main(x: CReal, q: Output[QBit]) -> None:
            allocate(q)
            RX(x, q)


        qprog = synthesize(main)
        kernel = qprog_to_cudaq_kernel(qprog, is_main_kernel=False)
        other_kernel = cudaq.make_kernel()
        reg = other_kernel.qalloc(1)
        other_kernel.apply_call(kernel, math.pi, reg[0])
        ```
    """
    require_cudaq()

    qasm_ast = _get_qasm_ast(quantum_program)
    kernel_data = construct_kernel(quantum_program, is_main_kernel, qasm_ast)
    converter = QasmToCudaqConverter(kernel_data)
    for statement in qasm_ast.statements:
        converter.process_main_statement(statement)
    converter.verify_all_foreach_expanded()
    if len(kernel_data.foreach_values) == 0:
        return kernel_data.kernel
    return kernel_data.kernel, *kernel_data.foreach_values


class QasmToCudaqConverter:
    def __init__(self, kernel_data: KernelData) -> None:
        self.kernel = kernel_data.kernel
        self.qubits = kernel_data.qubits
        self.params = kernel_data.parameters
        self.foreach_params = kernel_data.foreach_parameters
        self.foreach_lengths = kernel_data.foreach_lengths
        self._expanded_foreach_blocks: set[str] = set()
        self.gates: dict[str, "cudaq.PyKernel"] = {}
        self.gates_asts: dict[str, openqasm3.ast.QuantumGateDefinition] = {}

    @contextmanager
    def switch_kernel(
        self,
        kernel: "cudaq.PyKernel",
        qubits: dict[str, QubitOrQreg],
        params: dict[str, "cudaq.QuakeValue"],
    ) -> Iterator[None]:
        previous_kernel = self.kernel
        previous_qubits = self.qubits
        previous_params = self.params
        self.kernel = kernel
        self.qubits = qubits
        self.params = params
        yield
        self.kernel = previous_kernel
        self.qubits = previous_qubits
        self.params = previous_params

    def process_main_statement(
        self, statement: "openqasm3.ast.Statement | openqasm3.ast.Pragma"
    ) -> None:
        import cudaq
        import openqasm3

        if isinstance(
            statement,
            (
                openqasm3.ast.Include,
                openqasm3.ast.IODeclaration,
                openqasm3.ast.QubitDeclaration,
            ),
        ):
            pass
        elif isinstance(
            statement,
            (
                openqasm3.ast.ClassicalDeclaration,
                openqasm3.ast.BranchingStatement,
                openqasm3.ast.QuantumMeasurementStatement,
            ),
        ):
            raise ClassiqError(
                CONVERSION_ERROR_PREFIX + "mid-circuit measurements are not supported"
            )
        elif isinstance(statement, openqasm3.ast.QuantumReset):
            raise ClassiqError(
                CONVERSION_ERROR_PREFIX + "reset instructions are not supported"
            )
        elif isinstance(statement, openqasm3.ast.QuantumGateDefinition):
            gate_name = statement.name.name
            if len(self.foreach_params) > 0:
                self.gates_asts[gate_name] = statement
                return
            angle_names = [param.name for param in statement.arguments]
            qubit_names = [param.name for param in statement.qubits]
            kernel_and_params = cudaq.make_kernel(
                *((float,) * len(angle_names)), *((cudaq.qubit,) * len(qubit_names))
            )
            func_kernel = kernel_and_params[0]
            func_params = dict(
                zip(
                    angle_names,
                    kernel_and_params[1 : len(angle_names) + 1],
                    strict=True,
                )
            )
            func_qubits = dict(
                zip(qubit_names, kernel_and_params[len(angle_names) + 1 :], strict=True)
            )
            with self.switch_kernel(func_kernel, func_qubits, func_params):
                for gate_statement in statement.body:
                    self.process_statement(gate_statement)
            self.gates[gate_name] = func_kernel
        else:
            self.process_statement(statement)

    def process_statement(
        self,
        statement: "openqasm3.ast.Statement | openqasm3.ast.Pragma",
    ) -> None:
        import openqasm3

        if isinstance(statement, openqasm3.ast.QuantumGate):
            if len(statement.modifiers) != 0:
                raise ClassiqError(
                    CONVERSION_ERROR_PREFIX + "gate modifiers are not supported"
                )
            if statement.duration:
                raise ClassiqError(
                    CONVERSION_ERROR_PREFIX + "gate duration is not supported"
                )
            qubit_args = [eval_var(self.qubits, var) for var in statement.qubits]
            flattened_qubit_args = list(
                chain.from_iterable(
                    qubit_arg if isinstance(qubit_arg, list) else [qubit_arg]
                    for qubit_arg in qubit_args
                )
            )
            gate_name = statement.name.name
            if gate_name in self.gates:
                angle_args = get_angle_args(gate_name, statement, self.params)
                self.kernel.apply_call(
                    self.gates[gate_name], *angle_args, *flattened_qubit_args
                )
            elif gate_name in self.gates_asts:
                angle_args = get_angle_args(gate_name, statement, self.params)
                gate_ast = self.gates_asts[gate_name]
                angle_names = [param.name for param in gate_ast.arguments]
                qubit_names = [param.name for param in gate_ast.qubits]
                new_qubits = dict(zip(qubit_names, flattened_qubit_args, strict=True))
                new_params = dict(zip(angle_names, angle_args, strict=True))
                if gate_name not in self.foreach_params:
                    with self.switch_kernel(self.kernel, new_qubits, new_params):
                        for statement in gate_ast.body:
                            self.process_statement(statement)
                    return
                foreach_values = self.foreach_params[gate_name]
                num_iterations = self.foreach_lengths[gate_name]

                def _loop_body(idx: "cudaq.QuakeValue") -> None:
                    for foreach_var_name, foreach_param in foreach_values.items():
                        new_params[foreach_var_name] = foreach_param[idx]
                    with self.switch_kernel(self.kernel, new_qubits, new_params):
                        for statement in gate_ast.body:
                            self.process_statement(statement)

                self.kernel.for_loop(0, num_iterations, _loop_body)
                self._expanded_foreach_blocks.add(gate_name)
            elif gate_name in {"i", "id"}:
                pass
            elif gate_name in NATIVE_CUDAQ_STANDARD_GATES:
                angle_args = [
                    eval_expr(self.params, angle_expr)
                    for angle_expr in statement.arguments
                ]
                getattr(self.kernel, gate_name)(*angle_args, *flattened_qubit_args)
            elif gate_name in ATOMIC_GATE_IMPLEMENTATIONS:
                angle_args = [
                    eval_expr(self.params, angle_expr)
                    for angle_expr in statement.arguments
                ]
                ATOMIC_GATE_IMPLEMENTATIONS[gate_name](
                    self.kernel, *angle_args, *flattened_qubit_args
                )
            else:
                raise ClassiqError(
                    CONVERSION_ERROR_PREFIX + f"gate {gate_name!r} is not defined"
                )
        else:
            raise ClassiqError(
                CONVERSION_ERROR_PREFIX
                + f"QASM statement {type(statement).__name__} is not supported"
            )

    def verify_all_foreach_expanded(self) -> None:
        if self._expanded_foreach_blocks != set(self.foreach_params):
            raise ClassiqInternalError("Did not expand all foreach blocks")
