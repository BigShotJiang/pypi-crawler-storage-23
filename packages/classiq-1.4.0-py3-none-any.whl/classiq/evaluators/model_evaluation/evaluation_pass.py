from collections.abc import Iterator
from contextlib import contextmanager
from functools import singledispatchmethod
from typing import cast

from classiq.interface.exceptions import ClassiqInternalError
from classiq.interface.generator.expressions.evaluated_expression import (
    EvaluatedExpression,
)
from classiq.interface.generator.expressions.expression import Expression
from classiq.interface.generator.functions.type_name import TypeName
from classiq.interface.model.allocate import Allocate
from classiq.interface.model.bind_operation import BindOperation
from classiq.interface.model.classical_parameter_declaration import (
    ClassicalParameterDeclaration,
)
from classiq.interface.model.handle_binding import (
    HandleBinding,
    NestedHandleBinding,
)
from classiq.interface.model.model import Model
from classiq.interface.model.native_function_definition import NativeFunctionDefinition
from classiq.interface.model.port_declaration import PortDeclaration
from classiq.interface.model.quantum_statement import QuantumStatement
from classiq.interface.model.quantum_type import (
    QuantumBitvector,
    QuantumType,
)
from classiq.interface.model.variable_declaration_statement import (
    VariableDeclarationStatement,
)

from classiq.evaluators.model_evaluation.handle_utils import translate_handle
from classiq.evaluators.qmod_annotated_expression import qmod_val_to_str
from classiq.evaluators.qmod_expression_visitors.qmod_expression_evaluator import (
    evaluate_qmod_expression,
)
from classiq.evaluators.qmod_node_evaluators.utils import QmodType, is_classical_type
from classiq.evaluators.qmod_type_inference.quantum_type_inference import (
    inject_quantum_type_attributes_inplace,
)
from classiq.qmod.builtins.enums import BUILTIN_ENUM_DECLARATIONS
from classiq.qmod.builtins.structs import BUILTIN_STRUCT_DECLARATIONS


def is_pure_handle_binding(handle_binding: HandleBinding) -> bool:
    return not isinstance(handle_binding, NestedHandleBinding)


class EvaluationPass:
    def __init__(self) -> None:
        self._current_scope: dict[str, QmodType] = {}

    def set_current_model(self, model: Model) -> None:
        self._struct_decls = model.types
        self._enum_decls = model.enums
        self._machine_prec = model.preferences.machine_precision

    @contextmanager
    def set_current_scope(self, func: NativeFunctionDefinition) -> Iterator[None]:
        prev_scope = self._current_scope
        self._current_scope = {
            param.name: (  # type: ignore[misc]
                param.quantum_type
                if isinstance(param, PortDeclaration)
                else cast(ClassicalParameterDeclaration, param).classical_type
            )
            for param in func.positional_arg_declarations
        }
        yield
        self._current_scope = prev_scope

    def evaluate(self, expr: Expression) -> Expression:
        if expr.is_evaluated():
            return expr
        expr_val = evaluate_qmod_expression(
            expr.expr,
            machine_precision=self._machine_prec,
            classical_struct_declarations=self._struct_decls
            + list(BUILTIN_STRUCT_DECLARATIONS.values()),
            enum_declarations=self._enum_decls
            + list(BUILTIN_ENUM_DECLARATIONS.values()),
            scope=self._current_scope,
        )
        if expr_val.has_value(expr_val.root):
            value = expr_val.get_value(expr_val.root)
            evaluated_expr = Expression(expr=qmod_val_to_str(value))
        else:
            value = expr_val
            evaluated_expr = Expression(expr=str(expr_val))
        evaluated_expr._evaluated_expr = EvaluatedExpression(value=value)
        return evaluated_expr

    @singledispatchmethod
    def update_current_scope(self, statement: QuantumStatement) -> None:
        pass  # For other statements, do nothing.

    @update_current_scope.register
    def _(self, statement: Allocate) -> None:
        target_handle = statement.target

        if not is_pure_handle_binding(target_handle):
            raise ClassiqInternalError("Cannot allocate partial quantum variable")

        target_quantum_type = self._current_scope[target_handle.name]

        if is_classical_type(target_quantum_type):
            raise ClassiqInternalError("Cannot allocate classical variable")

        if statement.size is None:
            raise ClassiqInternalError("Cannot allocate without size")
        allocate_size = statement.size.to_int_value()

        # Assumption: EvaluationPass supports only models which were processed by the interpreter.
        # Therefore, only qstructs instances are not evaluated in this point.
        if (
            isinstance(target_quantum_type, TypeName)
            and not target_quantum_type.is_evaluated
        ):
            inject_quantum_type_attributes_inplace(
                QuantumBitvector(length=Expression(expr=str(allocate_size))),
                target_quantum_type,
            )

    @update_current_scope.register
    def _(self, statement: BindOperation) -> None:
        required_type_to_update_size: QuantumType | None = None
        out_size_in_bits: int = 0
        for out_handle in statement.out_handles:
            if not is_pure_handle_binding(out_handle):
                raise ClassiqInternalError("Cannot bind partial quantum variables")

            base_out_quantum_type = self._current_scope[out_handle.name]
            out_quantum_type, _, _ = translate_handle(
                cast(QuantumType, base_out_quantum_type), out_handle
            )

            if is_classical_type(base_out_quantum_type):
                raise ClassiqInternalError("Cannot bind classical variable")

            if not out_quantum_type.is_constant:
                if required_type_to_update_size is not None:
                    raise ClassiqInternalError(
                        "Multiple non-constant handles in the same bind - cannot infer sizes from bind"
                    )
                required_type_to_update_size = out_quantum_type
            else:
                out_size_in_bits += out_quantum_type.size_in_bits

        in_size_in_bits: int = sum(
            translate_handle(
                cast(QuantumType, self._current_scope[in_handle.name]), in_handle
            )[0].size_in_bits
            for in_handle in statement.in_handles
        )

        if required_type_to_update_size is not None:
            inject_quantum_type_attributes_inplace(
                QuantumBitvector(
                    length=Expression(expr=str(in_size_in_bits - out_size_in_bits))
                ),
                required_type_to_update_size,
            )

    @update_current_scope.register
    def _(self, statement: VariableDeclarationStatement) -> None:
        self._current_scope[statement.name] = statement.qmod_type
