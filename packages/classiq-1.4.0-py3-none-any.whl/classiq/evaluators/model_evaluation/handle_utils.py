from classiq.interface.exceptions import ClassiqInternalError
from classiq.interface.generator.functions.type_name import TypeName
from classiq.interface.model.handle_binding import (
    FieldHandleBinding,
    HandleBinding,
    SlicedHandleBinding,
    SubscriptHandleBinding,
)
from classiq.interface.model.quantum_type import QuantumBitvector, QuantumType


def translate_handle(
    type_: QuantumType, handle: HandleBinding
) -> tuple[QuantumType, int, int]:
    if isinstance(handle, SubscriptHandleBinding):
        nested_type, start, _ = translate_handle(type_, handle.base_handle)
        if not isinstance(nested_type, QuantumBitvector):
            raise ClassiqInternalError("Slicing but type is not array.")
        element_size = nested_type.element_type.size_in_bits
        index = handle.index.to_int_value()
        return (
            nested_type.element_type,
            start + index * element_size,
            start + (index + 1) * element_size,
        )

    if isinstance(handle, SlicedHandleBinding):
        nested_type, start, _ = translate_handle(type_, handle.base_handle)
        if not isinstance(nested_type, QuantumBitvector):
            raise ClassiqInternalError("Slicing but type is not array.")
        element_size = nested_type.element_type.size_in_bits
        next_start = handle.start.to_int_value()
        next_stop = handle.end.to_int_value()
        return (
            nested_type,
            start + next_start * element_size,
            start + next_stop * element_size,
        )

    if isinstance(handle, FieldHandleBinding):
        nested_type, start, _ = translate_handle(type_, handle.base_handle)
        if not isinstance(nested_type, TypeName):
            raise ClassiqInternalError("Accessing field but type is not struct.")
        for field_name, field_type in nested_type.fields.items():
            if field_name != handle.field:
                start += field_type.size_in_bits
                continue
            return field_type, start, start + field_type.size_in_bits
        raise ClassiqInternalError(
            f"Struct {nested_type.name} does not have field {handle.field!r}."
        )

    return type_, 0, type_.size_in_bits
