"""
MSTL (Multiple Seasonal-Trend decomposition using LOESS)

다중 계절성 분해 모델
E006 실험 결과: 57.8% 정확도 개선 달성
"""

from typing import Dict, List, Optional, Tuple

import numpy as np

from .arima import ARIMAModel
from .turbo import TurboCore


class MSTL:
    """
    다중 계절성 분해 모델

    여러 계절 주기(예: 주간 7, 연간 365)를 동시에 분해하고
    잔차에 ARIMA를 적용하여 예측

    E006 실험 결과:
    - 현재 방식 대비 57.8% MAPE 개선 (15.46% → 6.53%)
    - 다중 계절성 데이터에서 특히 효과적
    """

    def __init__(self, periods: Optional[List[int]] = None, autoDetect: bool = True):
        """
        Parameters
        ----------
        periods : List[int], optional
            계절 주기 리스트 (예: [7, 365])
            None이면 자동 감지
        autoDetect : bool
            True면 periods가 None일 때 자동으로 계절 주기 감지
        """
        self.periods = sorted(periods) if periods else None
        self.autoDetect = autoDetect

        self.seasonals: Dict[int, np.ndarray] = {}
        self.trend: Optional[np.ndarray] = None
        self.residual: Optional[np.ndarray] = None
        self.arimaModel: Optional['AutoARIMA'] = None
        self.fitted = False
        self.originalData: Optional[np.ndarray] = None

    def fit(self, y: np.ndarray) -> 'MSTL':
        """
        모델 학습

        Parameters
        ----------
        y : np.ndarray
            시계열 데이터

        Returns
        -------
        self
        """
        self.originalData = y.copy()
        n = len(y)

        if self.periods is None and self.autoDetect:
            self.periods = self._detectPeriods(y)

        if not self.periods:
            self.periods = [7]

        self._decompose(y)

        # 경량 AR(1) — 잔차에는 AutoARIMA 불필요 (10x 속도 향상)
        self.arimaModel = ARIMAModel(order=(1, 0, 0))
        self.arimaModel.fit(self.residual)

        self.fitted = True
        return self

    def predict(self, steps: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        예측

        Parameters
        ----------
        steps : int
            예측 스텝 수

        Returns
        -------
        Tuple[np.ndarray, np.ndarray, np.ndarray]
            (예측값, 하한, 상한)
        """
        if not self.fitted:
            raise ValueError("모델이 학습되지 않았습니다. fit()을 먼저 호출하세요.")

        residPred, residLower, residUpper = self.arimaModel.predict(steps)

        trendSlope = self._estimateTrendSlope()
        trendPred = self.trend[-1] + trendSlope * np.arange(1, steps + 1)

        finalPred = trendPred + residPred

        for period in self.periods:
            seasonalPattern = self.seasonals[period][-period:]
            seasonalPred = np.array([seasonalPattern[i % period] for i in range(steps)])
            finalPred += seasonalPred

        predStd = np.std(self.residual) if len(self.residual) > 0 else 1.0
        lower = finalPred - 1.96 * predStd
        upper = finalPred + 1.96 * predStd

        return finalPred, lower, upper

    def _detectPeriods(self, y: np.ndarray) -> List[int]:
        """
        ACF 기반 계절 주기 자동 감지

        Parameters
        ----------
        y : np.ndarray
            시계열 데이터

        Returns
        -------
        List[int]
            감지된 주기 리스트 (강도 순, 최대 2개)
        """
        n = len(y)
        candidatePeriods = [7, 14, 30, 90, 365]
        detectedPeriods = []

        for period in candidatePeriods:
            if n < period * 2:
                continue

            maxLag = min(period + 1, n // 2)
            acf = TurboCore.acf(y, maxLag)

            if len(acf) > period and abs(acf[period]) > 0.15:
                detectedPeriods.append((period, abs(acf[period])))

        detectedPeriods.sort(key=lambda x: -x[1])
        return [p[0] for p in detectedPeriods[:2]] if detectedPeriods else [7]

    def _decompose(self, y: np.ndarray):
        """
        다중 계절성 분해

        각 주기에 대해 순차적으로 계절 성분 추출
        """
        n = len(y)
        residual = y.copy()

        for period in self.periods:
            if n < period * 2:
                self.seasonals[period] = np.zeros(n)
                continue

            seasonal = self._extractSeasonal(residual, period)
            self.seasonals[period] = seasonal
            residual = residual - seasonal

        maxPeriod = max(self.periods) if self.periods else 7
        windowSize = min(maxPeriod, n // 2, 30)
        self.trend = self._movingAverage(residual, max(windowSize, 3))

        self.residual = residual - self.trend

    def _extractSeasonal(self, y: np.ndarray, period: int) -> np.ndarray:
        """
        계절 성분 추출

        Parameters
        ----------
        y : np.ndarray
            시계열 데이터
        period : int
            계절 주기

        Returns
        -------
        np.ndarray
            계절 성분
        """
        n = len(y)
        seasonal = np.zeros(n)

        periodMeans = np.zeros(period)
        for i in range(period):
            vals = y[i::period]
            periodMeans[i] = np.mean(vals)

        periodMeans -= np.mean(periodMeans)

        for i in range(n):
            seasonal[i] = periodMeans[i % period]

        return seasonal

    def _movingAverage(self, y: np.ndarray, window: int) -> np.ndarray:
        """이동 평균 — O(n) cumsum 방식"""
        n = len(y)
        result = np.zeros(n)
        halfWin = window // 2

        # cumsum 기반 O(n) 이동평균
        cumsum = np.concatenate(([0.0], np.cumsum(y)))

        for i in range(n):
            start = max(0, i - halfWin)
            end = min(n, i + halfWin + 1)
            result[i] = (cumsum[end] - cumsum[start]) / (end - start)

        return result

    def _estimateTrendSlope(self) -> float:
        """
        추세 기울기 추정

        Returns
        -------
        float
            추세 기울기
        """
        if self.trend is None or len(self.trend) < 10:
            return 0.0

        recentTrend = self.trend[-10:]
        slope = (recentTrend[-1] - recentTrend[0]) / (len(recentTrend) - 1)
        return slope


class AutoMSTL:
    """
    자동 MSTL 모델 선택

    데이터 특성을 분석하여 최적의 MSTL 설정 자동 선택
    """

    def __init__(self):
        self.model: Optional[MSTL] = None
        self.detectedPeriods: List[int] = []
        self.hasMultipleSeasonality: bool = False

    def fit(self, y: np.ndarray) -> MSTL:
        """
        자동으로 최적 MSTL 모델 학습

        Parameters
        ----------
        y : np.ndarray
            시계열 데이터

        Returns
        -------
        MSTL
            학습된 모델
        """
        self.detectedPeriods = self._analyzePeriods(y)
        self.hasMultipleSeasonality = len(self.detectedPeriods) > 1

        self.model = MSTL(periods=self.detectedPeriods, autoDetect=False)
        self.model.fit(y)

        return self.model

    def predict(self, steps: int) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """예측"""
        if self.model is None:
            raise ValueError("모델이 학습되지 않았습니다.")
        return self.model.predict(steps)

    def _analyzePeriods(self, y: np.ndarray) -> List[int]:
        """
        데이터 분석으로 계절 주기 감지

        Parameters
        ----------
        y : np.ndarray
            시계열 데이터

        Returns
        -------
        List[int]
            감지된 주기 리스트
        """
        n = len(y)
        candidatePeriods = [7, 14, 30, 60, 90, 180, 365]
        results = []

        for period in candidatePeriods:
            if n < period * 2:
                continue

            strength = self._measureSeasonalStrength(y, period)
            if strength > 0.15:
                results.append((period, strength))

        results.sort(key=lambda x: -x[1])
        selectedPeriods = [r[0] for r in results[:2]]

        return selectedPeriods if selectedPeriods else [7]

    def _measureSeasonalStrength(self, y: np.ndarray, period: int) -> float:
        """
        계절성 강도 측정

        Parameters
        ----------
        y : np.ndarray
            시계열 데이터
        period : int
            계절 주기

        Returns
        -------
        float
            계절성 강도 (0~1)
        """
        n = len(y)
        if n < period * 2:
            return 0.0

        maxLag = min(period + 1, n // 2)
        acf = TurboCore.acf(y, maxLag)

        if len(acf) > period:
            return abs(acf[period])

        return 0.0
