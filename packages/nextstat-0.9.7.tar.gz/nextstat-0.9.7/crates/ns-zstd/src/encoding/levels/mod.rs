mod default;
mod fastest;
pub use default::compress_default;
pub use fastest::compress_fastest;
