//! HistFactory Model representation
//!
//! Converts pyhf Workspace into an internal model suitable for inference.

use super::schema::*;
use ns_ad::scalar::Scalar;
use ns_core::Result;
use ns_core::traits::{FixedParamModel, LogDensityModel, PoiModel, PreparedNll};
use statrs::function::gamma::ln_gamma;
use std::collections::HashMap;

/// Minimum expected value floor for Poisson NLL computation.
///
/// Prevents `log(0)` divergence in the Poisson log-likelihood.
/// Must match the floor used in GPU kernels (`batch_nll_grad.cu` / `.metal`).
const EXPECTED_FLOOR: f64 = 1e-10;

/// HistFactory model
#[derive(Debug, Clone)]
pub struct HistFactoryModel {
    /// Model parameters
    parameters: Vec<Parameter>,
    /// Parameter of interest index
    poi_index: Option<usize>,
    /// Channels
    channels: Vec<ModelChannel>,
}

/// Model parameter
#[derive(Debug, Clone)]
pub struct Parameter {
    /// Parameter name
    pub name: String,
    /// Initial value
    pub init: f64,
    /// Bounds (min, max)
    pub bounds: (f64, f64),
    /// Is this a nuisance parameter with constraint?
    pub constrained: bool,
    /// Constraint center (for constrained NP)
    pub constraint_center: Option<f64>,
    /// Constraint width (for constrained NP)
    pub constraint_width: Option<f64>,
    /// Optional HistFactory constraint-term metadata (non-pyhf).
    ///
    /// When present, this can modify constraint penalties and/or interpolation semantics
    /// to match ROOT/HistFactory/TREx exports.
    pub constraint_term: Option<ConstraintTerm>,
}

/// HistFactory measurement-level constraint-term semantics (ROOT extension).
#[derive(Debug, Clone)]
pub enum ConstraintTerm {
    /// LogNormal constraint term: uses ROOT's `alphaOfBeta = (1/rel) * ((1+rel)^alpha - 1)`
    /// transformation for overall systematics, while keeping a Gaussian constraint on `alpha`.
    LogNormal { rel: f64 },
    /// Gamma constraint term (ROOT): applies a Gamma constraint to an overall-systematic parameter.
    ///
    /// We model this as a Gamma constraint on `beta = 1 + rel * alpha` (requiring beta > 0),
    /// using ROOT's canonical `tau = 1/rel^2` and `k = tau + 1`, `theta = 1/tau`.
    Gamma { rel: f64 },
    /// Uniform constraint term: removes the Gaussian penalty (flat prior within bounds).
    Uniform,
    /// NoConstraint/NoSyst: fixes the parameter at its nominal value (no effect).
    NoConstraint,
}

/// Per-sample expected yields for one channel.
#[derive(Debug, Clone)]
pub struct ExpectedChannelSampleYields {
    /// Channel name (as provided in the input workspace).
    pub channel_name: String,
    /// Per-sample expected yields (main bins only).
    pub samples: Vec<ExpectedSampleYields>,
    /// Total expected yields (sum of samples; main bins only).
    pub total: Vec<f64>,
}

/// Expected yields for one sample (main bins only).
#[derive(Debug, Clone)]
pub struct ExpectedSampleYields {
    /// Sample name (as provided in the input workspace).
    pub sample_name: String,
    /// Expected yields per bin (main bins only).
    pub y: Vec<f64>,
}

/// Observed main-bin data for one channel.
#[derive(Debug, Clone)]
pub struct ObservedChannelData {
    /// Channel name (as provided in the input workspace).
    pub channel_name: String,
    /// Observed counts per bin (main bins only).
    pub y: Vec<f64>,
}

/// Model channel
#[derive(Debug, Clone)]
pub(crate) struct ModelChannel {
    /// Channel name
    #[allow(dead_code)]
    pub(crate) name: String,
    /// Whether this channel contributes to the main-bin Poisson likelihood (fit regions vs validation regions).
    ///
    /// This does not affect expected-yield calculations used for reporting; it only affects NLL/grad evaluation.
    pub(crate) include_in_fit: bool,
    /// Samples in this channel
    pub(crate) samples: Vec<ModelSample>,
    /// Observed data (main bins only, auxiliary data added during NLL computation)
    pub(crate) observed: Vec<f64>,
    /// Auxiliary data for Barlow-Beeston constraints (per shapesys modifier)
    /// Each constraint corresponds to one ShapeSys modifier and stores both
    /// the fixed `tau` values and the observed auxiliary counts.
    #[allow(dead_code)]
    pub(crate) auxiliary_data: Vec<AuxiliaryPoissonConstraint>,
}

#[derive(Debug, Clone)]
pub(crate) struct AuxiliaryPoissonConstraint {
    pub(crate) sample_idx: usize,
    pub(crate) modifier_idx: usize,
    /// Barlow-Beeston scale (`tau_i = (nominal_i / sigma_i)^2`).
    pub(crate) tau: Vec<f64>,
    /// Observed auxiliary counts. For the nominal (observed) dataset this equals `tau`.
    /// For Asimov datasets this is set to the expected aux counts `gamma_hat * tau`.
    pub(crate) observed: Vec<f64>,
}

/// Model sample
#[derive(Debug, Clone)]
pub(crate) struct ModelSample {
    /// Sample name
    #[allow(dead_code)]
    pub(crate) name: String,
    /// Nominal expected counts
    pub(crate) nominal: Vec<f64>,
    /// Modifiers
    pub(crate) modifiers: Vec<ModelModifier>,
}

/// Interpolation code for HistoSys shape systematics.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HistoSysInterpCode {
    /// Piecewise linear (InterpCode=0). pyhf default for HistoSys.
    /// Kink at alpha=0 (discontinuous first derivative).
    Code0,
    /// Quadratic interpolation + linear extrapolation (InterpCode=2).
    /// Smooth at alpha=0, linear outside |alpha|>1.
    Code2,
    /// Polynomial + linear extrapolation (Code4p). Smooth at alpha=0.
    Code4p,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum NormSysInterpCode {
    /// Exponential (InterpCode=1). pyhf default for NormSys.
    /// factor = hi^alpha (alpha>=0) or lo^(-alpha) (alpha<0).
    Code1,
    /// Polynomial + exponential extrapolation (InterpCode=4). Smooth at alpha=0.
    Code4,
}

/// Model modifier (processed)
#[derive(Debug, Clone)]
pub(crate) enum ModelModifier {
    /// Normalization factor (unconstrained)
    NormFactor { param_idx: usize },
    /// Shape systematic - per-bin multiplicative (Barlow-Beeston)
    /// Stores parameter indices, uncertainties, and nominal values for constraint
    ShapeSys {
        param_indices: Vec<usize>,
        #[allow(dead_code)]
        uncertainties: Vec<f64>,
        #[allow(dead_code)]
        nominal_values: Vec<f64>,
    },
    /// Shape factor - free per-bin multiplicative factors (unconstrained)
    ShapeFactor { param_indices: Vec<usize> },
    /// Normalization systematic - log-normal constraint
    NormSys { param_idx: usize, hi_factor: f64, lo_factor: f64, interp_code: NormSysInterpCode },
    /// Histogram systematic - shape interpolation
    HistoSys {
        param_idx: usize,
        hi_template: Vec<f64>,
        lo_template: Vec<f64>,
        interp_code: HistoSysInterpCode,
    },
    /// Statistical error - per-bin multiplicative factors (constrained by normal)
    StatError {
        param_indices: Vec<usize>,
        #[allow(dead_code)]
        uncertainties: Vec<f64>,
    },
    /// Luminosity - normalization with constraint
    Lumi { param_idx: usize },
}

impl HistFactoryModel {
    fn normsys_alpha_effective<T: Scalar>(&self, param_idx: usize, alpha: T) -> T {
        let Some(p) = self.parameters.get(param_idx) else { return alpha };
        match &p.constraint_term {
            Some(ConstraintTerm::Gamma { rel }) if *rel > 0.0 => {
                // Parameter is interpreted as beta (positive). Map to alpha=(beta-1)/rel.
                let inv_rel = 1.0 / *rel;
                (alpha - T::from_f64(1.0)) * T::from_f64(inv_rel)
            }
            Some(ConstraintTerm::LogNormal { rel }) if *rel > 0.0 => {
                // ROOT/HistFactory: alphaOfBeta = (1/rel) * ((1+rel)^alpha - 1)
                // Implement as tau * (exp(alpha*ln(1+rel)) - 1).
                let tau = 1.0 / *rel;
                let kappa_ln = (1.0 + *rel).ln();
                T::from_f64(tau) * ((alpha * T::from_f64(kappa_ln)).exp() - T::from_f64(1.0))
            }
            _ => alpha,
        }
    }

    fn normsys_alpha_effective_on_tape(
        &self,
        tape: &mut ns_ad::tape::Tape,
        param_idx: usize,
        alpha: ns_ad::tape::Var,
    ) -> ns_ad::tape::Var {
        let Some(p) = self.parameters.get(param_idx) else { return alpha };
        match &p.constraint_term {
            Some(ConstraintTerm::Gamma { rel }) if *rel > 0.0 => {
                let inv_rel = 1.0 / *rel;
                let one = tape.constant(1.0);
                let inv = tape.constant(inv_rel);
                let diff = tape.sub(alpha, one);
                tape.mul(diff, inv)
            }
            Some(ConstraintTerm::LogNormal { rel }) if *rel > 0.0 => {
                let tau = 1.0 / *rel;
                let kappa_ln = (1.0 + *rel).ln();
                let tau_c = tape.constant(tau);
                let kln_c = tape.constant(kappa_ln);
                let one = tape.constant(1.0);
                let prod = tape.mul(alpha, kln_c);
                let exp = tape.exp(prod);
                let minus_one = tape.sub(exp, one);
                tape.mul(tau_c, minus_one)
            }
            _ => alpha,
        }
    }

    /// Construct a `HistFactoryModel` from pre-built parts.
    ///
    /// Used by `hs3::convert` to build models from resolved HS3 workspaces.
    /// Callers are responsible for ensuring internal consistency (parameter
    /// indices, channel bin counts, etc.).
    pub(crate) fn from_parts(
        parameters: Vec<Parameter>,
        poi_index: Option<usize>,
        channels: Vec<ModelChannel>,
    ) -> Self {
        Self { parameters, poi_index, channels }
    }

    /// Return per-parameter 1σ widths for parameters constrained by auxiliary Poisson terms
    /// (Barlow–Beeston `shapesys`).
    ///
    /// In pyhf's Barlow–Beeston, each gamma parameter is constrained by an auxiliary Poisson
    /// with `tau = (nominal / sigma_abs)^2`. Around the nominal point (gamma≈1),
    /// the approximate standard deviation is `sigma_gamma ≈ 1 / sqrt(tau)`.
    ///
    /// This map is intentionally *best-effort* and is primarily used by higher-level utilities
    /// (e.g. ranking) that need a "±1σ" notion for Poisson-constrained parameters.
    pub fn poisson_constraint_sigmas(&self) -> HashMap<usize, f64> {
        let mut sigmas: HashMap<usize, f64> = HashMap::new();

        for channel in &self.channels {
            for constraint in &channel.auxiliary_data {
                let Some(sample) = channel.samples.get(constraint.sample_idx) else { continue };
                let Some(modifier) = sample.modifiers.get(constraint.modifier_idx) else {
                    continue;
                };

                let ModelModifier::ShapeSys { param_indices, .. } = modifier else { continue };
                if param_indices.len() != constraint.tau.len() {
                    continue;
                }

                for (&pidx, &tau) in param_indices.iter().zip(constraint.tau.iter()) {
                    if tau.is_finite() && tau > 0.0 {
                        let sigma = 1.0 / tau.sqrt();
                        // If a param shows up multiple times (unexpected), keep the tightest sigma.
                        sigmas.entry(pidx).and_modify(|s| *s = s.min(sigma)).or_insert(sigma);
                    }
                }
            }
        }

        sigmas
    }

    fn validate_params_len(&self, got: usize) -> Result<()> {
        let expected = self.parameters.len();
        if got != expected {
            return Err(ns_core::Error::Validation(format!(
                "Parameter length mismatch: expected {}, got {}",
                expected, got
            )));
        }
        Ok(())
    }

    fn validate_internal_indices(&self) -> Result<()> {
        let n = self.parameters.len();
        for channel in &self.channels {
            for sample in &channel.samples {
                for m in &sample.modifiers {
                    match m {
                        ModelModifier::NormFactor { param_idx }
                        | ModelModifier::NormSys { param_idx, .. }
                        | ModelModifier::HistoSys { param_idx, .. }
                        | ModelModifier::Lumi { param_idx } => {
                            if *param_idx >= n {
                                return Err(ns_core::Error::Validation(format!(
                                    "Modifier param index out of range: idx={} len={}",
                                    param_idx, n
                                )));
                            }
                        }
                        ModelModifier::ShapeSys { param_indices, .. }
                        | ModelModifier::ShapeFactor { param_indices }
                        | ModelModifier::StatError { param_indices, .. } => {
                            for &idx in param_indices {
                                if idx >= n {
                                    return Err(ns_core::Error::Validation(format!(
                                        "Modifier param index out of range: idx={} len={}",
                                        idx, n
                                    )));
                                }
                            }
                        }
                    }
                }
            }

            for constraint in &channel.auxiliary_data {
                let sample = channel.samples.get(constraint.sample_idx).ok_or_else(|| {
                    ns_core::Error::Validation("Aux constraint sample_idx out of range".to_string())
                })?;
                let modifier = sample.modifiers.get(constraint.modifier_idx).ok_or_else(|| {
                    ns_core::Error::Validation(
                        "Aux constraint modifier_idx out of range".to_string(),
                    )
                })?;
                if let ModelModifier::ShapeSys { param_indices, .. } = modifier
                    && (constraint.tau.len() != param_indices.len()
                        || constraint.observed.len() != param_indices.len())
                {
                    return Err(ns_core::Error::Validation(
                        "Aux constraint length mismatch (tau/observed/param_indices)".to_string(),
                    ));
                }
            }
        }
        Ok(())
    }

    /// Compute `ln Γ(n+1)` (generalized factorial).
    fn ln_factorial(n: f64) -> f64 {
        ln_gamma(n + 1.0)
    }

    /// Number of channels in the model.
    pub fn n_channels(&self) -> usize {
        self.channels.len()
    }

    /// Channel names in workspace order.
    pub fn channel_names(&self) -> Vec<String> {
        self.channels.iter().map(|c| c.name.clone()).collect()
    }

    /// Sample names for a given channel.
    pub fn sample_names(&self, channel_idx: usize) -> Vec<String> {
        self.channels
            .get(channel_idx)
            .map(|c| c.samples.iter().map(|s| s.name.clone()).collect())
            .unwrap_or_default()
    }

    /// Borrow the modifiers of a given sample (for export).
    pub(crate) fn sample_modifiers(
        &self,
        channel_idx: usize,
        sample_idx: usize,
    ) -> &[ModelModifier] {
        self.channels
            .get(channel_idx)
            .and_then(|c| c.samples.get(sample_idx))
            .map(|s| s.modifiers.as_slice())
            .unwrap_or(&[])
    }

    /// Find a channel index by name.
    pub fn channel_index(&self, channel_name: &str) -> Option<usize> {
        self.channels.iter().position(|c| c.name == channel_name)
    }

    /// Find a sample index by name within a channel.
    pub fn sample_index(&self, channel_idx: usize, sample_name: &str) -> Option<usize> {
        self.channels.get(channel_idx)?.samples.iter().position(|s| s.name == sample_name)
    }

    /// Number of main bins in a channel.
    pub fn channel_bin_count(&self, channel_idx: usize) -> Result<usize> {
        let ch = self.channels.get(channel_idx).ok_or_else(|| {
            ns_core::Error::Validation(format!("Channel index out of range: {}", channel_idx))
        })?;
        Ok(ch.samples.first().map(|s| s.nominal.len()).unwrap_or(0))
    }

    /// Flat offset of a channel's main bins in `expected/observed` vectors (workspace order).
    pub fn channel_bin_offset(&self, channel_idx: usize) -> Result<usize> {
        if channel_idx >= self.channels.len() {
            return Err(ns_core::Error::Validation(format!(
                "Channel index out of range: {}",
                channel_idx
            )));
        }
        let mut offset = 0usize;
        for (i, ch) in self.channels.iter().enumerate() {
            if i == channel_idx {
                break;
            }
            let n_bins = ch.samples.first().map(|s| s.nominal.len()).unwrap_or(0);
            offset += n_bins;
        }
        Ok(offset)
    }

    /// Find a signal sample by name and return its flat GPU index + bin range.
    ///
    /// Searches all channels for a sample with the given name. Returns the
    /// flat sample index (in `serialize_for_gpu()` order), the first main-bin
    /// offset, and the number of bins. Used by the differentiable layer.
    ///
    /// **Limitation**: Returns the *first* match only. For multi-channel
    /// workspaces where the same sample name appears in multiple channels,
    /// only the first channel's signal sample will be differentiable. This is
    /// sufficient for single-channel physics analyses but may need extension
    /// for multi-channel signal injection.
    pub fn signal_sample_gpu_info(&self, sample_name: &str) -> Result<(u32, u32, u32)> {
        let mut flat_sample_idx: u32 = 0;
        let mut main_bin_offset: u32 = 0;

        for channel in &self.channels {
            let channel_n_bins =
                channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0) as u32;

            for sample in &channel.samples {
                if sample.name == sample_name {
                    let n_bins = sample.nominal.len() as u32;
                    return Ok((flat_sample_idx, main_bin_offset, n_bins));
                }
                flat_sample_idx += 1;
            }

            main_bin_offset += channel_n_bins;
        }

        Err(ns_core::Error::Validation(format!(
            "Signal sample '{}' not found in any channel",
            sample_name
        )))
    }

    /// Return GPU indexing info for ALL occurrences of a signal sample across channels.
    ///
    /// For multi-channel models where the same sample name appears in multiple channels,
    /// this returns one `(flat_sample_idx, main_bin_offset, n_bins)` tuple per channel.
    /// For single-channel models, this returns a `Vec` with one element (identical to
    /// `signal_sample_gpu_info`).
    pub fn signal_sample_gpu_info_all(&self, sample_name: &str) -> Result<Vec<(u32, u32, u32)>> {
        let mut flat_sample_idx: u32 = 0;
        let mut main_bin_offset: u32 = 0;
        let mut entries = Vec::new();

        for channel in &self.channels {
            let channel_n_bins =
                channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0) as u32;

            for sample in &channel.samples {
                if sample.name == sample_name {
                    let n_bins = sample.nominal.len() as u32;
                    entries.push((flat_sample_idx, main_bin_offset, n_bins));
                }
                flat_sample_idx += 1;
            }

            main_bin_offset += channel_n_bins;
        }

        if entries.is_empty() {
            return Err(ns_core::Error::Validation(format!(
                "Signal sample '{}' not found in any channel",
                sample_name
            )));
        }

        Ok(entries)
    }

    /// Borrow the nominal main-bin yields for a given channel/sample.
    pub fn sample_nominal(&self, channel_idx: usize, sample_idx: usize) -> Result<&[f64]> {
        let ch = self.channels.get(channel_idx).ok_or_else(|| {
            ns_core::Error::Validation(format!("Channel index out of range: {}", channel_idx))
        })?;
        let s = ch.samples.get(sample_idx).ok_or_else(|| {
            ns_core::Error::Validation(format!(
                "Sample index out of range: {} (channel={})",
                sample_idx, channel_idx
            ))
        })?;
        Ok(s.nominal.as_slice())
    }

    /// Override the nominal main-bin yields for a given channel/sample (in place).
    pub fn set_sample_nominal(
        &mut self,
        channel_idx: usize,
        sample_idx: usize,
        nominal: &[f64],
    ) -> Result<()> {
        let expected_len = self.channel_bin_count(channel_idx)?;
        if nominal.len() != expected_len {
            return Err(ns_core::Error::Validation(format!(
                "Nominal length mismatch: expected {}, got {}",
                expected_len,
                nominal.len()
            )));
        }
        let ch = self.channels.get_mut(channel_idx).ok_or_else(|| {
            ns_core::Error::Validation(format!("Channel index out of range: {}", channel_idx))
        })?;
        let s = ch.samples.get_mut(sample_idx).ok_or_else(|| {
            ns_core::Error::Validation(format!(
                "Sample index out of range: {} (channel={})",
                sample_idx, channel_idx
            ))
        })?;
        s.nominal.clear();
        s.nominal.extend_from_slice(nominal);
        Ok(())
    }

    /// Resolve channel+sample by name and override nominal yields (in place).
    ///
    /// Returns the resolved `(channel_idx, sample_idx)` on success.
    pub fn set_sample_nominal_by_name(
        &mut self,
        channel_name: &str,
        sample_name: &str,
        nominal: &[f64],
    ) -> Result<(usize, usize)> {
        let ch_idx = self.channel_index(channel_name).ok_or_else(|| {
            ns_core::Error::Validation(format!("Unknown channel: {}", channel_name))
        })?;
        let s_idx = self.sample_index(ch_idx, sample_name).ok_or_else(|| {
            ns_core::Error::Validation(format!(
                "Unknown sample: {} (channel={})",
                sample_name, channel_name
            ))
        })?;
        self.set_sample_nominal(ch_idx, s_idx, nominal)?;
        Ok((ch_idx, s_idx))
    }

    /// Validate that overriding the nominal vector for this sample is "linear-safe".
    ///
    /// We currently only support nominal overrides for samples whose modifiers are purely
    /// multiplicative and do not reference the nominal vector:
    /// - NormFactor
    /// - NormSys
    /// - Lumi
    /// - ShapeFactor
    pub fn validate_sample_nominal_override_linear_safe(
        &self,
        channel_idx: usize,
        sample_idx: usize,
    ) -> Result<()> {
        let ch = self.channels.get(channel_idx).ok_or_else(|| {
            ns_core::Error::Validation(format!("Channel index out of range: {}", channel_idx))
        })?;
        let s = ch.samples.get(sample_idx).ok_or_else(|| {
            ns_core::Error::Validation(format!(
                "Sample index out of range: {} (channel={})",
                sample_idx, channel_idx
            ))
        })?;

        for m in &s.modifiers {
            match m {
                ModelModifier::NormFactor { .. }
                | ModelModifier::NormSys { .. }
                | ModelModifier::Lumi { .. }
                | ModelModifier::ShapeFactor { .. } => {}
                _ => {
                    return Err(ns_core::Error::Validation(format!(
                        "Nominal override is not supported for samples with shape/aux modifiers (channel_idx={}, sample_idx={})",
                        channel_idx, sample_idx
                    )));
                }
            }
        }
        Ok(())
    }

    /// Fill per-bin multiplicative factors for a given channel/sample (main bins only).
    ///
    /// `out` must have length equal to `channel_bin_count(channel_idx)`.
    pub fn fill_sample_multiplicative_factors_main(
        &self,
        params: &[f64],
        channel_idx: usize,
        sample_idx: usize,
        out: &mut [f64],
    ) -> Result<()> {
        use ns_compute::simd::vec_scale;

        self.validate_params_len(params.len())?;
        self.validate_sample_nominal_override_linear_safe(channel_idx, sample_idx)?;

        let n_bins = self.channel_bin_count(channel_idx)?;
        if out.len() != n_bins {
            return Err(ns_core::Error::Validation(format!(
                "out length mismatch: expected {}, got {}",
                n_bins,
                out.len()
            )));
        }

        out.fill(1.0);

        let ch = self.channels.get(channel_idx).ok_or_else(|| {
            ns_core::Error::Validation(format!("Channel index out of range: {}", channel_idx))
        })?;
        let s = ch.samples.get(sample_idx).ok_or_else(|| {
            ns_core::Error::Validation(format!(
                "Sample index out of range: {} (channel={})",
                sample_idx, channel_idx
            ))
        })?;

        for modifier in &s.modifiers {
            match modifier {
                ModelModifier::NormFactor { param_idx } => {
                    let norm = *params.get(*param_idx).ok_or_else(|| {
                        ns_core::Error::Validation(format!(
                            "NormFactor param index out of range: idx={} len={}",
                            param_idx,
                            params.len()
                        ))
                    })?;
                    vec_scale(out, norm);
                }
                ModelModifier::NormSys { param_idx, hi_factor, lo_factor, interp_code } => {
                    let alpha_raw = *params.get(*param_idx).ok_or_else(|| {
                        ns_core::Error::Validation(format!(
                            "NormSys param index out of range: idx={} len={}",
                            param_idx,
                            params.len()
                        ))
                    })?;
                    let alpha = self.normsys_alpha_effective(*param_idx, alpha_raw);
                    let factor = match interp_code {
                        NormSysInterpCode::Code1 => normsys_code1(alpha, *hi_factor, *lo_factor),
                        NormSysInterpCode::Code4 => normsys_code4(alpha, *hi_factor, *lo_factor),
                    };
                    vec_scale(out, factor);
                }
                ModelModifier::Lumi { param_idx } => {
                    let lumi = *params.get(*param_idx).ok_or_else(|| {
                        ns_core::Error::Validation(format!(
                            "Lumi param index out of range: idx={} len={}",
                            param_idx,
                            params.len()
                        ))
                    })?;
                    vec_scale(out, lumi);
                }
                ModelModifier::ShapeFactor { param_indices } => {
                    for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                        if bin_idx < out.len() {
                            let gamma_val = *params.get(gamma_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "ShapeFactor gamma index out of range: idx={} len={}",
                                    gamma_idx,
                                    params.len()
                                ))
                            })?;
                            out[bin_idx] *= gamma_val;
                        }
                    }
                }
                _ => unreachable!("validate_sample_nominal_override_linear_safe enforced"),
            }
        }

        Ok(())
    }

    /// Create model from pyhf workspace with explicit modifier interpolation settings.
    ///
    /// `normsys_interp`: interpolation code for NormSys (code1 = pyhf default, code4 = polynomial).
    /// `histosys_interp`: interpolation code for HistoSys (code0 = pyhf default, code4p = polynomial).
    pub fn from_workspace_with_settings(
        ws: &Workspace,
        normsys_interp: NormSysInterpCode,
        histosys_interp: HistoSysInterpCode,
    ) -> Result<Self> {
        Self::from_workspace_impl(ws, normsys_interp, histosys_interp)
    }

    /// Create model from pyhf workspace using parity harness defaults:
    /// normsys=code4, histosys=code4p.
    pub fn from_workspace(ws: &Workspace) -> Result<Self> {
        Self::from_workspace_impl(ws, NormSysInterpCode::Code4, HistoSysInterpCode::Code4p)
    }

    fn from_workspace_impl(
        ws: &Workspace,
        normsys_interp: NormSysInterpCode,
        histosys_interp: HistoSysInterpCode,
    ) -> Result<Self> {
        let mut parameters = Vec::new();
        let mut param_map: HashMap<String, usize> = HashMap::new();

        const POS_LO: f64 = 1e-10;
        const POS_HI: f64 = 10.0;

        // Accumulate nominal/uncertainty sums for staterror sigmas (pyhf behavior).
        #[derive(Debug, Clone)]
        struct StatErrorAccum {
            sum_nominal: Vec<f64>,
            sum_uncert_sq: Vec<f64>,
        }
        let mut staterror_accum: HashMap<String, StatErrorAccum> = HashMap::new();

        // Get POI name from first measurement
        let poi_name = ws.measurements.first().map(|m| m.config.poi.as_str()).unwrap_or("mu");

        // Add POI as first parameter
        param_map.insert(poi_name.to_string(), 0);
        parameters.push(Parameter {
            name: poi_name.to_string(),
            init: 1.0,
            bounds: (0.0, 10.0),
            constrained: false,
            constraint_center: None,
            constraint_width: None,
            constraint_term: None,
        });
        let poi_index = Some(0);

        // Collect all unique parameters from modifiers
        // First pass: identify all parameters
        for channel in &ws.channels {
            for sample in &channel.samples {
                for modifier in &sample.modifiers {
                    match modifier {
                        Modifier::NormFactor { name, .. } => {
                            // Free-floating normalization (POI or nuisance).
                            if !param_map.contains_key(name) {
                                param_map.insert(name.clone(), parameters.len());
                                parameters.push(Parameter {
                                    name: name.clone(),
                                    init: 1.0,
                                    bounds: (0.0, POS_HI),
                                    constrained: false,
                                    constraint_center: None,
                                    constraint_width: None,
                                    constraint_term: None,
                                });
                            }
                        }
                        Modifier::ShapeSys { name, data } => {
                            // ShapeSys uses Barlow-Beeston approach with Poisson constraints
                            // Create one gamma parameter per bin
                            for (bin_idx, _uncertainty) in data.iter().enumerate() {
                                let param_name = format!("{}[{}]", name, bin_idx);
                                if !param_map.contains_key(&param_name) {
                                    param_map.insert(param_name.clone(), parameters.len());
                                    parameters.push(Parameter {
                                        name: param_name,
                                        init: 1.0,
                                        bounds: (POS_LO, POS_HI),
                                        // ShapeSys has Poisson constraint (Barlow-Beeston) handled in `nll()`.
                                        constrained: false,
                                        constraint_center: None,
                                        constraint_width: None,
                                        constraint_term: None,
                                    });
                                }
                            }
                        }
                        Modifier::NormSys { name, .. } => {
                            if !param_map.contains_key(name) {
                                param_map.insert(name.clone(), parameters.len());
                                parameters.push(Parameter {
                                    name: name.clone(),
                                    init: 0.0, // log-normal: 0 = nominal
                                    bounds: (-5.0, 5.0),
                                    constrained: true,
                                    constraint_center: Some(0.0),
                                    constraint_width: Some(1.0),
                                    constraint_term: None,
                                });
                            }
                        }
                        Modifier::HistoSys { name, .. } => {
                            if !param_map.contains_key(name) {
                                param_map.insert(name.clone(), parameters.len());
                                parameters.push(Parameter {
                                    name: name.clone(),
                                    init: 0.0, // 0 = nominal, +1/-1 = variations
                                    bounds: (-5.0, 5.0),
                                    constrained: true,
                                    constraint_center: Some(0.0),
                                    constraint_width: Some(1.0),
                                    constraint_term: None,
                                });
                            }
                        }
                        Modifier::StatError { name, data } => {
                            // One parameter per bin
                            for (bin_idx, _) in data.iter().enumerate() {
                                let param_name = format!("{}[{}]", name, bin_idx);
                                if !param_map.contains_key(&param_name) {
                                    param_map.insert(param_name.clone(), parameters.len());
                                    parameters.push(Parameter {
                                        name: param_name,
                                        init: 1.0,
                                        bounds: (POS_LO, POS_HI),
                                        constrained: true,
                                        constraint_center: Some(1.0),
                                        constraint_width: Some(1.0), // Placeholder; computed below.
                                        constraint_term: None,
                                    });
                                }
                            }

                            let entry = staterror_accum.entry(name.clone()).or_insert_with(|| {
                                StatErrorAccum {
                                    sum_nominal: vec![0.0; data.len()],
                                    sum_uncert_sq: vec![0.0; data.len()],
                                }
                            });
                            if entry.sum_nominal.len() != data.len() {
                                return Err(ns_core::Error::Validation(format!(
                                    "StatError modifier '{}' bin length mismatch: {} != {}",
                                    name,
                                    entry.sum_nominal.len(),
                                    data.len()
                                )));
                            }

                            for (bin_idx, (sigma_abs, nominal)) in
                                data.iter().zip(&sample.data).enumerate()
                            {
                                entry.sum_nominal[bin_idx] += *nominal;
                                entry.sum_uncert_sq[bin_idx] += sigma_abs * sigma_abs;
                            }
                        }
                        Modifier::Lumi { name, .. } => {
                            if !param_map.contains_key(name) {
                                param_map.insert(name.clone(), parameters.len());
                                parameters.push(Parameter {
                                    name: name.clone(),
                                    init: 1.0,
                                    bounds: (0.0, POS_HI),
                                    constrained: true,
                                    constraint_center: Some(1.0),
                                    constraint_width: Some(0.02), // typical lumi uncertainty
                                    constraint_term: None,
                                });
                            }
                        }
                        Modifier::ShapeFactor { name, .. } => {
                            // Free-floating shape: one parameter per bin (unconstrained).
                            for bin_idx in 0..sample.data.len() {
                                let param_name = format!("{}[{}]", name, bin_idx);
                                if !param_map.contains_key(&param_name) {
                                    param_map.insert(param_name.clone(), parameters.len());
                                    parameters.push(Parameter {
                                        name: param_name,
                                        init: 1.0,
                                        bounds: (0.0, POS_HI),
                                        constrained: false,
                                        constraint_center: None,
                                        constraint_width: None,
                                        constraint_term: None,
                                    });
                                }
                            }
                        }
                        Modifier::Unknown(val) => {
                            let ty = val.get("type").and_then(|t| t.as_str()).unwrap_or("?");
                            log::warn!(
                                "Unknown modifier type '{}' in sample '{}' — skipped",
                                ty,
                                sample.name,
                            );
                        }
                    }
                }
            }
        }

        // Compute StatError sigmas (relative uncertainties) and attach constraints to parameters.
        // Sort keys for deterministic iteration order (HashMap is non-deterministic).
        let mut staterror_names: Vec<String> = staterror_accum.keys().cloned().collect();
        staterror_names.sort();
        for name in staterror_names {
            let accum = &staterror_accum[&name];
            for bin_idx in 0..accum.sum_nominal.len() {
                let denom = accum.sum_nominal[bin_idx];
                let sigma_rel =
                    if denom > 0.0 { accum.sum_uncert_sq[bin_idx].sqrt() / denom } else { 0.0 };

                let param_name = format!("{}[{}]", name, bin_idx);
                if let Some(&pidx) = param_map.get(&param_name) {
                    let p = &mut parameters[pidx];
                    if sigma_rel > 0.0 {
                        p.constrained = true;
                        p.constraint_center = Some(1.0);
                        p.constraint_width = Some(sigma_rel);
                    } else {
                        // If sigma==0, pyhf effectively fixes this parameter at 1.0.
                        p.constrained = false;
                        p.constraint_center = None;
                        p.constraint_width = None;
                        p.init = 1.0;
                        p.bounds = (1.0, 1.0);
                    }
                }
            }
        }

        // Apply measurement parameter overrides (bounds/inits/auxdata/sigmas) if present.
        if let Some(measurement) = ws.measurements.first() {
            for cfg in &measurement.config.parameters {
                for param in &mut parameters {
                    // Match scalar name or vector-like "<base>[<i>]" names.
                    let elem_idx = if param.name == cfg.name {
                        Some(0usize)
                    } else if let Some(rest) = param.name.strip_prefix(&cfg.name) {
                        rest.strip_prefix('[')
                            .and_then(|s| s.strip_suffix(']'))
                            .and_then(|s| s.parse::<usize>().ok())
                    } else {
                        None
                    };

                    let Some(elem_idx) = elem_idx else { continue };

                    if !cfg.inits.is_empty() {
                        let init = if cfg.inits.len() == 1 {
                            cfg.inits[0]
                        } else {
                            *cfg.inits.get(elem_idx).unwrap_or(&param.init)
                        };
                        param.init = init;
                    }

                    if !cfg.bounds.is_empty() {
                        let b = if cfg.bounds.len() == 1 {
                            cfg.bounds[0]
                        } else if let Some(b) = cfg.bounds.get(elem_idx) {
                            *b
                        } else {
                            [param.bounds.0, param.bounds.1]
                        };
                        param.bounds = (b[0], b[1]);
                    }

                    if !cfg.auxdata.is_empty() && !cfg.sigmas.is_empty() {
                        let center = if cfg.auxdata.len() == 1 {
                            cfg.auxdata[0]
                        } else if let Some(v) = cfg.auxdata.get(elem_idx) {
                            *v
                        } else {
                            param.constraint_center.unwrap_or(param.init)
                        };
                        let sigma = if cfg.sigmas.len() == 1 {
                            cfg.sigmas[0]
                        } else if let Some(v) = cfg.sigmas.get(elem_idx) {
                            *v
                        } else {
                            param.constraint_width.unwrap_or(1.0)
                        };
                        param.constrained = true;
                        param.constraint_center = Some(center);
                        param.constraint_width = Some(sigma);
                    }

                    // pyhf workspace parameter configs can freeze parameters via `fixed: true`.
                    // We implement this by clamping bounds to a single value (the configured init).
                    if cfg.fixed {
                        param.bounds = (param.init, param.init);
                    }

                    // Non-standard extension: HistFactory `<ConstraintTerm>` metadata.
                    //
                    // ROOT/HistFactory defines alternative constraint terms for named nuisance parameters.
                    // We preserve the semantics as follows:
                    // - `Uniform`: remove the Gaussian penalty (flat prior within bounds).
                    // - `NoConstraint`/`NoSyst`: fix the parameter at nominal (no effect).
                    // - `LogNormal`: keep Gaussian penalty but apply ROOT's alpha-transform in normsys evaluation.
                    // - `Gamma`: replace the Gaussian penalty by a Gamma constraint on beta=1+rel*alpha.
                    //
                    // Note: we only apply the constraint term to the scalar parameter itself (`param.name == cfg.name`).
                    if elem_idx == 0
                        && param.name == cfg.name
                        && let Some(spec) = &cfg.constraint
                    {
                        let typ = spec.constraint_type.trim().to_ascii_lowercase();
                        let rel = spec.rel_uncertainty.unwrap_or(0.0);

                        match typ.as_str() {
                            "uniform" => {
                                param.constraint_term = Some(ConstraintTerm::Uniform);
                                param.constrained = false;
                                param.constraint_center = None;
                                param.constraint_width = None;
                            }
                            "noconstraint" | "nosyst" | "nosys" => {
                                param.constraint_term = Some(ConstraintTerm::NoConstraint);
                                let center = param.constraint_center.unwrap_or(param.init);
                                param.init = center;
                                param.bounds = (center, center);
                                param.constrained = false;
                                param.constraint_center = None;
                                param.constraint_width = None;
                            }
                            "lognormal" => {
                                if rel > 0.0 {
                                    param.constraint_term = Some(ConstraintTerm::LogNormal { rel });
                                }
                            }
                            "gamma" => {
                                if rel > 0.0 {
                                    param.constraint_term = Some(ConstraintTerm::Gamma { rel });
                                    // Match ROOT convention: Gamma constraints are applied to a positive
                                    // parameter `beta` (nominal ~ 1). In this mode we interpret the
                                    // parameter value as `beta` and map it into the interpolation-space
                                    // `alpha = (beta - 1)/rel`.
                                    param.init = if param.init == 0.0 { 1.0 } else { param.init };
                                    let lo = param.bounds.0.max(1e-10);
                                    let hi = param.bounds.1.max(lo);
                                    param.bounds = (lo, hi);

                                    // Reporting/diagnostics: store a simple Gaussian-equivalent width in beta-space.
                                    param.constrained = true;
                                    param.constraint_center = Some(1.0);
                                    param.constraint_width = Some(rel);
                                }
                            }
                            _ => {
                                // Unknown constraint type: preserve no behavior change.
                            }
                        }
                    }
                }
            }
        }

        // Build channels
        let mut channels = Vec::new();
        for ws_channel in &ws.channels {
            let observed = ws
                .observations
                .iter()
                .find(|o| o.name == ws_channel.name)
                .ok_or_else(|| {
                    ns_core::Error::Validation(format!(
                        "Workspace missing observations for channel '{}'",
                        ws_channel.name
                    ))
                })?
                .data
                .clone();

            // Validate binning consistency within the channel before building the internal model.
            let n_bins = ws_channel.samples.first().map(|s| s.data.len()).unwrap_or(0);
            if n_bins == 0 {
                return Err(ns_core::Error::Validation(format!(
                    "Channel '{}' has no bins (empty sample data)",
                    ws_channel.name
                )));
            }
            if observed.len() != n_bins {
                return Err(ns_core::Error::Validation(format!(
                    "Channel '{}' observations length mismatch: expected {}, got {}",
                    ws_channel.name,
                    n_bins,
                    observed.len()
                )));
            }

            let mut samples = Vec::new();
            let mut auxiliary_data = Vec::new();

            for (sample_idx, ws_sample) in ws_channel.samples.iter().enumerate() {
                if ws_sample.data.len() != n_bins {
                    return Err(ns_core::Error::Validation(format!(
                        "Channel '{}' sample '{}' bin length mismatch: expected {}, got {}",
                        ws_channel.name,
                        ws_sample.name,
                        n_bins,
                        ws_sample.data.len()
                    )));
                }

                let mut modifiers = Vec::new();

                for ws_modifier in &ws_sample.modifiers {
                    match ws_modifier {
                        Modifier::NormFactor { name, .. } => {
                            if let Some(&idx) = param_map.get(name) {
                                modifiers.push(ModelModifier::NormFactor { param_idx: idx });
                            }
                        }
                        Modifier::ShapeSys { name, data } => {
                            if data.len() != n_bins {
                                return Err(ns_core::Error::Validation(format!(
                                    "Channel '{}' sample '{}' ShapeSys '{}' bin length mismatch: expected {}, got {}",
                                    ws_channel.name,
                                    ws_sample.name,
                                    name,
                                    n_bins,
                                    data.len()
                                )));
                            }

                            let mut param_indices = Vec::new();
                            for (bin_idx, _) in data.iter().enumerate() {
                                let param_name = format!("{}[{}]", name, bin_idx);
                                if let Some(&idx) = param_map.get(&param_name) {
                                    param_indices.push(idx);
                                }
                            }

                            // Compute auxiliary data: tau_i = (nominal_i / sigma_i)^2
                            let tau_values: Vec<f64> = data
                                .iter()
                                .zip(&ws_sample.data)
                                .map(|(sigma, nominal)| {
                                    if *sigma > 0.0 && *nominal > 0.0 {
                                        (nominal / sigma).powi(2)
                                    } else {
                                        1.0
                                    }
                                })
                                .collect();

                            // Store auxiliary constraint for this modifier.
                            // For the observed dataset, the aux observation equals tau (pyhf auxdata convention).
                            auxiliary_data.push(AuxiliaryPoissonConstraint {
                                sample_idx,
                                modifier_idx: modifiers.len(),
                                tau: tau_values.clone(),
                                observed: tau_values.clone(),
                            });

                            modifiers.push(ModelModifier::ShapeSys {
                                param_indices,
                                uncertainties: data.clone(),
                                nominal_values: ws_sample.data.clone(),
                            });
                        }
                        Modifier::NormSys { name, data } => {
                            if let Some(&idx) = param_map.get(name) {
                                if data.hi <= 0.0 || data.lo <= 0.0 {
                                    log::warn!(
                                        "NormSys '{}': non-positive factor (hi={}, lo={}), will use linear fallback",
                                        name,
                                        data.hi,
                                        data.lo
                                    );
                                }
                                modifiers.push(ModelModifier::NormSys {
                                    param_idx: idx,
                                    hi_factor: data.hi,
                                    lo_factor: data.lo,
                                    interp_code: normsys_interp,
                                });
                            }
                        }
                        Modifier::HistoSys { name, data } => {
                            if data.hi_data.len() != n_bins || data.lo_data.len() != n_bins {
                                return Err(ns_core::Error::Validation(format!(
                                    "Channel '{}' sample '{}' HistoSys '{}' template length mismatch: expected {}, got hi={}, lo={}",
                                    ws_channel.name,
                                    ws_sample.name,
                                    name,
                                    n_bins,
                                    data.hi_data.len(),
                                    data.lo_data.len()
                                )));
                            }

                            if let Some(&idx) = param_map.get(name) {
                                modifiers.push(ModelModifier::HistoSys {
                                    param_idx: idx,
                                    hi_template: data.hi_data.clone(),
                                    lo_template: data.lo_data.clone(),
                                    interp_code: histosys_interp,
                                });
                            }
                        }
                        Modifier::StatError { name, data } => {
                            if data.len() != n_bins {
                                return Err(ns_core::Error::Validation(format!(
                                    "Channel '{}' sample '{}' StatError '{}' bin length mismatch: expected {}, got {}",
                                    ws_channel.name,
                                    ws_sample.name,
                                    name,
                                    n_bins,
                                    data.len()
                                )));
                            }

                            let mut param_indices = Vec::new();
                            for (bin_idx, _) in data.iter().enumerate() {
                                let param_name = format!("{}[{}]", name, bin_idx);
                                if let Some(&idx) = param_map.get(&param_name) {
                                    param_indices.push(idx);
                                }
                            }
                            modifiers.push(ModelModifier::StatError {
                                param_indices,
                                uncertainties: data.clone(),
                            });
                        }
                        Modifier::ShapeFactor { name, .. } => {
                            let mut param_indices = Vec::new();
                            for bin_idx in 0..ws_sample.data.len() {
                                let param_name = format!("{}[{}]", name, bin_idx);
                                if let Some(&idx) = param_map.get(&param_name) {
                                    param_indices.push(idx);
                                }
                            }
                            modifiers.push(ModelModifier::ShapeFactor { param_indices });
                        }
                        Modifier::Lumi { name, .. } => {
                            if let Some(&idx) = param_map.get(name) {
                                modifiers.push(ModelModifier::Lumi { param_idx: idx });
                            }
                        }
                        Modifier::Unknown(_) => {
                            // Already warned in first pass — skip silently here.
                        }
                    }
                }

                samples.push(ModelSample {
                    name: ws_sample.name.clone(),
                    nominal: ws_sample.data.clone(),
                    modifiers,
                });
            }

            channels.push(ModelChannel {
                name: ws_channel.name.clone(),
                include_in_fit: true,
                samples,
                observed,
                auxiliary_data,
            });
        }

        // pyhf orders channels lexicographically (see `model.config.channels`), and the flattened
        // main-data vector follows that order. Sort here so `with_observed_main(...)` can accept
        // pyhf-ordered observations without requiring callers to permute.
        channels.sort_by(|a, b| a.name.cmp(&b.name));

        let model = Self { parameters, poi_index, channels };
        model.validate_internal_indices()?;
        Ok(model)
    }

    /// Create a copy of the model with a fit/validation channel selection applied.
    ///
    /// - If `fit_channels` is provided and non-empty, only those channels contribute to the fit.
    /// - If `validation_channels` is provided and non-empty, those channels are excluded from the fit.
    /// - If both are provided, they must be disjoint.
    ///
    /// Channel names refer to workspace channel names (regions).
    pub fn with_fit_channel_selection(
        &self,
        fit_channels: Option<&[String]>,
        validation_channels: Option<&[String]>,
    ) -> Result<Self> {
        use std::collections::HashSet;

        let fit_set: HashSet<&str> = fit_channels
            .unwrap_or(&[])
            .iter()
            .map(|s| s.as_str())
            .filter(|s| !s.trim().is_empty())
            .collect();
        let val_set: HashSet<&str> = validation_channels
            .unwrap_or(&[])
            .iter()
            .map(|s| s.as_str())
            .filter(|s| !s.trim().is_empty())
            .collect();

        if !fit_set.is_empty() {
            for &v in &val_set {
                if fit_set.contains(v) {
                    return Err(ns_core::Error::Validation(format!(
                        "channel cannot be both fit and validation: {v}"
                    )));
                }
            }
        }

        if fit_set.is_empty() && val_set.is_empty() {
            return Ok(self.clone());
        }

        // Validate channel names.
        let known: HashSet<&str> = self.channels.iter().map(|c| c.name.as_str()).collect();
        let mut unknown: Vec<&str> = Vec::new();
        for &c in fit_set.iter().chain(val_set.iter()) {
            if !known.contains(c) {
                unknown.push(c);
            }
        }
        if !unknown.is_empty() {
            unknown.sort();
            unknown.dedup();
            return Err(ns_core::Error::Validation(format!(
                "unknown channel(s) in fit/validation selection: {}",
                unknown.join(", ")
            )));
        }

        let mut out = self.clone();
        for ch in &mut out.channels {
            let name = ch.name.as_str();
            let include = if !fit_set.is_empty() { fit_set.contains(name) } else { true };
            let include = include && !val_set.contains(name);
            ch.include_in_fit = include;
        }
        Ok(out)
    }

    /// Number of parameters
    pub fn n_params(&self) -> usize {
        self.parameters.len()
    }

    /// Create a copy of the model with overridden observed (main) data.
    ///
    /// `observed_main` must be a flat vector of length equal to the total number of
    /// main bins across all channels (no auxdata). Auxiliary constraints remain fixed.
    pub fn with_observed_main(&self, observed_main: &[f64]) -> Result<Self> {
        let expected_len: usize = self
            .channels
            .iter()
            .map(|channel| channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0))
            .sum();

        if observed_main.len() != expected_len {
            return Err(ns_core::Error::Validation(format!(
                "Observed main data length mismatch: expected {}, got {}",
                expected_len,
                observed_main.len()
            )));
        }

        let mut out = self.clone();
        let mut offset = 0;
        for channel in &mut out.channels {
            let n_bins = channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0);
            channel.observed.clear();
            channel.observed.extend_from_slice(&observed_main[offset..offset + n_bins]);
            offset += n_bins;
        }

        Ok(out)
    }

    /// Get POI index
    pub fn poi_index(&self) -> Option<usize> {
        self.poi_index
    }

    /// Get parameters
    pub fn parameters(&self) -> &[Parameter] {
        &self.parameters
    }

    /// Observed main-bin data per channel (channels are ordered lexicographically by name).
    pub fn observed_main_by_channel(&self) -> Vec<ObservedChannelData> {
        let mut out: Vec<ObservedChannelData> = Vec::with_capacity(self.channels.len());
        for channel in &self.channels {
            out.push(ObservedChannelData {
                channel_name: channel.name.clone(),
                y: channel.observed.clone(),
            });
        }
        out
    }

    /// Create a copy with one parameter fixed at a given value.
    ///
    /// The parameter bounds are clamped to that value so the optimizer
    /// cannot move it.
    pub fn with_fixed_param(&self, param_idx: usize, value: f64) -> Self {
        let mut out = self.clone();
        if let Some(p) = out.parameters.get_mut(param_idx) {
            p.init = value;
            p.bounds = (value, value);
        }
        out
    }

    /// Create a copy with updated constraint centers for constrained parameters.
    ///
    /// This is primarily used for building Asimov datasets compatible with pyhf:
    /// for `constrained_by_normal` terms, pyhf treats the auxiliary measurement as
    /// part of the data vector and the expected aux value is the nuisance parameter
    /// itself. In the Asimov dataset this means the auxiliary "observations" equal
    /// the fitted nuisance values, effectively removing pulls while keeping widths.
    pub fn with_constraint_centers(&self, centers: &[f64]) -> Result<Self> {
        if centers.len() != self.parameters.len() {
            return Err(ns_core::Error::Validation(format!(
                "Constraint centers length mismatch: expected {}, got {}",
                self.parameters.len(),
                centers.len()
            )));
        }

        let mut out = self.clone();
        for (i, p) in out.parameters.iter_mut().enumerate() {
            if !p.constrained {
                continue;
            }
            if p.constraint_center.is_some() {
                p.constraint_center = Some(centers[i]);
            }
        }
        Ok(out)
    }

    /// Create a copy with updated **ShapeSys auxiliary observations** derived from parameter values.
    ///
    /// For the Barlow-Beeston (ShapeSys) constraints, pyhf includes auxiliary Poisson terms
    /// as part of the data vector. When building an Asimov dataset, those auxiliary
    /// observations are set to their expected values `gamma_hat * tau`.
    ///
    /// This helper updates the stored auxiliary observations accordingly while keeping `tau`
    /// fixed.
    pub fn with_shapesys_aux_observed_from_params(&self, params: &[f64]) -> Result<Self> {
        self.validate_params_len(params.len())?;

        let mut out = self.clone();
        for channel in &mut out.channels {
            for constraint in &mut channel.auxiliary_data {
                if let Some(sample) = channel.samples.get(constraint.sample_idx)
                    && let Some(ModelModifier::ShapeSys { param_indices, .. }) =
                        sample.modifiers.get(constraint.modifier_idx)
                {
                    if constraint.tau.len() != param_indices.len() {
                        return Err(ns_core::Error::Validation(format!(
                            "Aux constraint length mismatch: tau={} param_indices={}",
                            constraint.tau.len(),
                            param_indices.len()
                        )));
                    }
                    let mut obs = Vec::with_capacity(constraint.tau.len());
                    for (&tau, &gamma_idx) in constraint.tau.iter().zip(param_indices.iter()) {
                        let gamma = params.get(gamma_idx).copied().ok_or_else(|| {
                            ns_core::Error::Validation(format!(
                                "ShapeSys gamma index out of range: idx={} len={}",
                                gamma_idx,
                                params.len()
                            ))
                        })?;
                        obs.push(gamma * tau);
                    }
                    constraint.observed = obs;
                }
            }
        }
        Ok(out)
    }

    /// Compute negative log-likelihood (f64 specialisation).
    pub fn nll(&self, params: &[f64]) -> Result<f64> {
        self.validate_params_len(params.len())?;
        self.nll_generic(params)
    }

    /// Compute expected data at given parameter values (f64 specialisation).
    pub fn expected_data(&self, params: &[f64]) -> Result<Vec<f64>> {
        self.validate_params_len(params.len())?;
        self.expected_data_f64_fast(params)
    }

    /// Fast f64 expected-data evaluation.
    ///
    /// This specializes the generic expected-data implementation to:
    /// - avoid `T::from_f64` conversions
    /// - hoist `alpha`-only `code4p` polynomial terms out of the bin loop
    /// - use SIMD kernels for the `histosys` `code4p` hot-path and scalar factor scaling
    fn expected_data_f64_fast(&self, params: &[f64]) -> Result<Vec<f64>> {
        use ns_compute::simd::{
            histosys_code0_delta_accumulate, histosys_code2_delta_accumulate,
            histosys_code4p_delta_accumulate, vec_scale,
        };

        let mut result = Vec::new();

        for channel in &self.channels {
            let n_bins = channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0);
            let mut channel_expected: Vec<f64> = vec![0.0; n_bins];

            for sample in &channel.samples {
                let sample_nominal = sample.nominal.as_slice();
                let sample_len = sample_nominal.len();

                let mut sample_deltas: Vec<f64> = vec![0.0; sample_len];
                let mut sample_factors: Vec<f64> = vec![1.0; sample_len];

                for modifier in &sample.modifiers {
                    match modifier {
                        ModelModifier::NormFactor { param_idx } => {
                            let norm = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "NormFactor param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            vec_scale(&mut sample_factors, norm);
                        }
                        ModelModifier::ShapeSys { param_indices, .. } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma_val = *params.get(gamma_idx).ok_or_else(|| {
                                        ns_core::Error::Validation(format!(
                                            "ShapeSys gamma index out of range: idx={} len={}",
                                            gamma_idx,
                                            params.len()
                                        ))
                                    })?;
                                    sample_factors[bin_idx] *= gamma_val;
                                }
                            }
                        }
                        ModelModifier::NormSys { param_idx, hi_factor, lo_factor, interp_code } => {
                            let alpha_raw = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "NormSys param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            let alpha = self.normsys_alpha_effective(*param_idx, alpha_raw);
                            let factor = match interp_code {
                                NormSysInterpCode::Code1 => {
                                    normsys_code1(alpha, *hi_factor, *lo_factor)
                                }
                                NormSysInterpCode::Code4 => {
                                    normsys_code4(alpha, *hi_factor, *lo_factor)
                                }
                            };
                            vec_scale(&mut sample_factors, factor);
                        }
                        ModelModifier::HistoSys {
                            param_idx,
                            hi_template,
                            lo_template,
                            interp_code,
                        } => {
                            let alpha = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "HistoSys param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;

                            // Fast path: fully-dense histosys templates (common case).
                            if hi_template.len() == sample_len && lo_template.len() == sample_len {
                                match interp_code {
                                    HistoSysInterpCode::Code0 => histosys_code0_delta_accumulate(
                                        &mut sample_deltas,
                                        alpha,
                                        lo_template,
                                        sample_nominal,
                                        hi_template,
                                    ),
                                    HistoSysInterpCode::Code2 => histosys_code2_delta_accumulate(
                                        &mut sample_deltas,
                                        alpha,
                                        lo_template,
                                        sample_nominal,
                                        hi_template,
                                    ),
                                    HistoSysInterpCode::Code4p => histosys_code4p_delta_accumulate(
                                        &mut sample_deltas,
                                        alpha,
                                        lo_template,
                                        sample_nominal,
                                        hi_template,
                                    ),
                                }
                            } else {
                                // Fallback: tolerate length mismatches.
                                for (bin_idx, delta_slot) in sample_deltas.iter_mut().enumerate() {
                                    let nom_val =
                                        sample_nominal.get(bin_idx).copied().unwrap_or(0.0);
                                    let hi = hi_template.get(bin_idx).copied().unwrap_or(nom_val);
                                    let lo = lo_template.get(bin_idx).copied().unwrap_or(nom_val);
                                    let delta = match interp_code {
                                        HistoSysInterpCode::Code0 => {
                                            histosys_code0_delta(alpha, lo, nom_val, hi)
                                        }
                                        HistoSysInterpCode::Code2 => {
                                            histosys_code2_delta(alpha, lo, nom_val, hi)
                                        }
                                        HistoSysInterpCode::Code4p => {
                                            histosys_code4p_delta(alpha, lo, nom_val, hi)
                                        }
                                    };
                                    *delta_slot += delta;
                                }
                            }
                        }
                        ModelModifier::StatError { param_indices, .. } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma_val = *params.get(gamma_idx).ok_or_else(|| {
                                        ns_core::Error::Validation(format!(
                                            "StatError gamma index out of range: idx={} len={}",
                                            gamma_idx,
                                            params.len()
                                        ))
                                    })?;
                                    sample_factors[bin_idx] *= gamma_val;
                                }
                            }
                        }
                        ModelModifier::ShapeFactor { param_indices } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma_val = *params.get(gamma_idx).ok_or_else(|| {
                                        ns_core::Error::Validation(format!(
                                            "ShapeFactor gamma index out of range: idx={} len={}",
                                            gamma_idx,
                                            params.len()
                                        ))
                                    })?;
                                    sample_factors[bin_idx] *= gamma_val;
                                }
                            }
                        }
                        ModelModifier::Lumi { param_idx } => {
                            let lumi = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "Lumi param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            vec_scale(&mut sample_factors, lumi);
                        }
                    }
                }

                if sample_len == n_bins {
                    for bin_idx in 0..n_bins {
                        channel_expected[bin_idx] += (sample_nominal[bin_idx]
                            + sample_deltas[bin_idx])
                            * sample_factors[bin_idx];
                    }
                } else {
                    for (bin_idx, ch_val) in channel_expected.iter_mut().enumerate() {
                        let nom = sample_nominal.get(bin_idx).copied().unwrap_or(0.0);
                        let delta = sample_deltas.get(bin_idx).copied().unwrap_or(0.0);
                        let fac = sample_factors.get(bin_idx).copied().unwrap_or(1.0);
                        *ch_val += (nom + delta) * fac;
                    }
                }
            }

            result.extend(channel_expected);
        }

        Ok(result)
    }

    /// Zero-allocation expected-data evaluation, writing into pre-allocated scratch buffers.
    ///
    /// Equivalent to [`expected_data_f64_fast`] but avoids all heap allocation by reusing
    /// the buffers in `scratch`. The result is written to `scratch.expected[..n_main_bins]`.
    fn expected_data_f64_fast_into(&self, params: &[f64], scratch: &mut NllScratch) -> Result<()> {
        use ns_compute::simd::{
            histosys_code0_delta_accumulate, histosys_code2_delta_accumulate,
            histosys_code4p_delta_accumulate, vec_scale,
        };

        let mut offset = 0usize;

        for channel in &self.channels {
            let n_bins = channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0);

            // Reset channel_expected (reuse buffer, no alloc)
            scratch.channel_expected[..n_bins].fill(0.0);

            for sample in &channel.samples {
                let sample_nominal = sample.nominal.as_slice();
                let sample_len = sample_nominal.len();

                // Reset per-sample scratch (reuse buffers, no alloc)
                scratch.sample_deltas[..sample_len].fill(0.0);
                scratch.sample_factors[..sample_len].fill(1.0);

                let sd = &mut scratch.sample_deltas[..sample_len];
                let sf = &mut scratch.sample_factors[..sample_len];

                for modifier in &sample.modifiers {
                    match modifier {
                        ModelModifier::NormFactor { param_idx } => {
                            let norm = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "NormFactor param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            vec_scale(sf, norm);
                        }
                        ModelModifier::ShapeSys { param_indices, .. } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sf.len() {
                                    let gamma_val = *params.get(gamma_idx).ok_or_else(|| {
                                        ns_core::Error::Validation(format!(
                                            "ShapeSys gamma index out of range: idx={} len={}",
                                            gamma_idx,
                                            params.len()
                                        ))
                                    })?;
                                    sf[bin_idx] *= gamma_val;
                                }
                            }
                        }
                        ModelModifier::NormSys { param_idx, hi_factor, lo_factor, interp_code } => {
                            let alpha_raw = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "NormSys param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            let alpha = self.normsys_alpha_effective(*param_idx, alpha_raw);
                            let factor = match interp_code {
                                NormSysInterpCode::Code1 => {
                                    normsys_code1(alpha, *hi_factor, *lo_factor)
                                }
                                NormSysInterpCode::Code4 => {
                                    normsys_code4(alpha, *hi_factor, *lo_factor)
                                }
                            };
                            vec_scale(sf, factor);
                        }
                        ModelModifier::HistoSys {
                            param_idx,
                            hi_template,
                            lo_template,
                            interp_code,
                        } => {
                            let alpha = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "HistoSys param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;

                            if hi_template.len() == sample_len && lo_template.len() == sample_len {
                                match interp_code {
                                    HistoSysInterpCode::Code0 => histosys_code0_delta_accumulate(
                                        sd,
                                        alpha,
                                        lo_template,
                                        sample_nominal,
                                        hi_template,
                                    ),
                                    HistoSysInterpCode::Code2 => histosys_code2_delta_accumulate(
                                        sd,
                                        alpha,
                                        lo_template,
                                        sample_nominal,
                                        hi_template,
                                    ),
                                    HistoSysInterpCode::Code4p => histosys_code4p_delta_accumulate(
                                        sd,
                                        alpha,
                                        lo_template,
                                        sample_nominal,
                                        hi_template,
                                    ),
                                }
                            } else {
                                for (bin_idx, delta_slot) in sd.iter_mut().enumerate() {
                                    let nom_val =
                                        sample_nominal.get(bin_idx).copied().unwrap_or(0.0);
                                    let hi = hi_template.get(bin_idx).copied().unwrap_or(nom_val);
                                    let lo = lo_template.get(bin_idx).copied().unwrap_or(nom_val);
                                    let delta = match interp_code {
                                        HistoSysInterpCode::Code0 => {
                                            histosys_code0_delta(alpha, lo, nom_val, hi)
                                        }
                                        HistoSysInterpCode::Code2 => {
                                            histosys_code2_delta(alpha, lo, nom_val, hi)
                                        }
                                        HistoSysInterpCode::Code4p => {
                                            histosys_code4p_delta(alpha, lo, nom_val, hi)
                                        }
                                    };
                                    *delta_slot += delta;
                                }
                            }
                        }
                        ModelModifier::StatError { param_indices, .. } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sf.len() {
                                    let gamma_val = *params.get(gamma_idx).ok_or_else(|| {
                                        ns_core::Error::Validation(format!(
                                            "StatError gamma index out of range: idx={} len={}",
                                            gamma_idx,
                                            params.len()
                                        ))
                                    })?;
                                    sf[bin_idx] *= gamma_val;
                                }
                            }
                        }
                        ModelModifier::ShapeFactor { param_indices } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sf.len() {
                                    let gamma_val = *params.get(gamma_idx).ok_or_else(|| {
                                        ns_core::Error::Validation(format!(
                                            "ShapeFactor gamma index out of range: idx={} len={}",
                                            gamma_idx,
                                            params.len()
                                        ))
                                    })?;
                                    sf[bin_idx] *= gamma_val;
                                }
                            }
                        }
                        ModelModifier::Lumi { param_idx } => {
                            let lumi = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "Lumi param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            vec_scale(sf, lumi);
                        }
                    }
                }

                // Combine sample contribution into channel_expected
                if sample_len == n_bins {
                    for bin_idx in 0..n_bins {
                        scratch.channel_expected[bin_idx] +=
                            (sample_nominal[bin_idx] + sd[bin_idx]) * sf[bin_idx];
                    }
                } else {
                    for bin_idx in 0..n_bins {
                        let nom = sample_nominal.get(bin_idx).copied().unwrap_or(0.0);
                        let delta = sd.get(bin_idx).copied().unwrap_or(0.0);
                        let fac = sf.get(bin_idx).copied().unwrap_or(1.0);
                        scratch.channel_expected[bin_idx] += (nom + delta) * fac;
                    }
                }
            }

            // Copy channel result into the flat expected buffer (no alloc)
            scratch.expected[offset..offset + n_bins]
                .copy_from_slice(&scratch.channel_expected[..n_bins]);
            offset += n_bins;
        }

        Ok(())
    }

    /// Expected **main** yields per channel and per sample (workspace order), without auxdata.
    ///
    /// This is the “numbers-first” surface used for TREx-like stacked distributions:
    /// we need the decomposition into samples, not only the total.
    pub fn expected_main_by_channel_sample(
        &self,
        params: &[f64],
    ) -> Result<Vec<ExpectedChannelSampleYields>> {
        use ns_compute::simd::{
            histosys_code0_delta_accumulate, histosys_code2_delta_accumulate,
            histosys_code4p_delta_accumulate, vec_scale,
        };

        self.validate_params_len(params.len())?;

        let mut out: Vec<ExpectedChannelSampleYields> = Vec::with_capacity(self.channels.len());

        for channel in &self.channels {
            let n_bins = channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0);
            let mut total: Vec<f64> = vec![0.0; n_bins];
            let mut samples_out: Vec<ExpectedSampleYields> =
                Vec::with_capacity(channel.samples.len());

            for sample in &channel.samples {
                // Same semantics as expected_data_generic, but we keep the per-sample vector.
                let sample_nominal: &[f64] = sample.nominal.as_slice();
                let sample_len = sample_nominal.len();
                let mut sample_deltas: Vec<f64> = vec![0.0; sample_len];
                let mut sample_factors: Vec<f64> = vec![1.0; sample_len];

                for modifier in &sample.modifiers {
                    match modifier {
                        ModelModifier::NormFactor { param_idx } => {
                            let norm = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "NormFactor param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            vec_scale(&mut sample_factors, norm);
                        }
                        ModelModifier::ShapeSys { param_indices, .. } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma_val = *params.get(gamma_idx).ok_or_else(|| {
                                        ns_core::Error::Validation(format!(
                                            "ShapeSys gamma index out of range: idx={} len={}",
                                            gamma_idx,
                                            params.len()
                                        ))
                                    })?;
                                    sample_factors[bin_idx] *= gamma_val;
                                }
                            }
                        }
                        ModelModifier::NormSys { param_idx, hi_factor, lo_factor, interp_code } => {
                            let alpha_raw = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "NormSys param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            let alpha = self.normsys_alpha_effective(*param_idx, alpha_raw);
                            let factor = match interp_code {
                                NormSysInterpCode::Code1 => {
                                    normsys_code1(alpha, *hi_factor, *lo_factor)
                                }
                                NormSysInterpCode::Code4 => {
                                    normsys_code4(alpha, *hi_factor, *lo_factor)
                                }
                            };
                            vec_scale(&mut sample_factors, factor);
                        }
                        ModelModifier::HistoSys {
                            param_idx,
                            hi_template,
                            lo_template,
                            interp_code,
                        } => {
                            let alpha = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "HistoSys param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;

                            if hi_template.len() == sample_len && lo_template.len() == sample_len {
                                match interp_code {
                                    HistoSysInterpCode::Code0 => histosys_code0_delta_accumulate(
                                        &mut sample_deltas,
                                        alpha,
                                        lo_template,
                                        sample_nominal,
                                        hi_template,
                                    ),
                                    HistoSysInterpCode::Code2 => histosys_code2_delta_accumulate(
                                        &mut sample_deltas,
                                        alpha,
                                        lo_template,
                                        sample_nominal,
                                        hi_template,
                                    ),
                                    HistoSysInterpCode::Code4p => histosys_code4p_delta_accumulate(
                                        &mut sample_deltas,
                                        alpha,
                                        lo_template,
                                        sample_nominal,
                                        hi_template,
                                    ),
                                }
                            } else {
                                for (bin_idx, delta_slot) in sample_deltas.iter_mut().enumerate() {
                                    let nom_val =
                                        sample_nominal.get(bin_idx).copied().unwrap_or(0.0);
                                    let hi = hi_template.get(bin_idx).copied().unwrap_or(nom_val);
                                    let lo = lo_template.get(bin_idx).copied().unwrap_or(nom_val);
                                    let delta = match interp_code {
                                        HistoSysInterpCode::Code0 => {
                                            histosys_code0_delta(alpha, lo, nom_val, hi)
                                        }
                                        HistoSysInterpCode::Code2 => {
                                            histosys_code2_delta(alpha, lo, nom_val, hi)
                                        }
                                        HistoSysInterpCode::Code4p => {
                                            histosys_code4p_delta(alpha, lo, nom_val, hi)
                                        }
                                    };
                                    *delta_slot += delta;
                                }
                            }
                        }
                        ModelModifier::StatError { param_indices, .. } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma_val = *params.get(gamma_idx).ok_or_else(|| {
                                        ns_core::Error::Validation(format!(
                                            "StatError gamma index out of range: idx={} len={}",
                                            gamma_idx,
                                            params.len()
                                        ))
                                    })?;
                                    sample_factors[bin_idx] *= gamma_val;
                                }
                            }
                        }
                        ModelModifier::ShapeFactor { param_indices } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma_val = *params.get(gamma_idx).ok_or_else(|| {
                                        ns_core::Error::Validation(format!(
                                            "ShapeFactor gamma index out of range: idx={} len={}",
                                            gamma_idx,
                                            params.len()
                                        ))
                                    })?;
                                    sample_factors[bin_idx] *= gamma_val;
                                }
                            }
                        }
                        ModelModifier::Lumi { param_idx } => {
                            let lumi = *params.get(*param_idx).ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "Lumi param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            vec_scale(&mut sample_factors, lumi);
                        }
                    }
                }

                let mut y: Vec<f64> = vec![0.0; n_bins];
                for bin_idx in 0..n_bins {
                    let nom = sample_nominal.get(bin_idx).copied().unwrap_or(0.0);
                    let delta = sample_deltas.get(bin_idx).copied().unwrap_or(0.0);
                    let fac = sample_factors.get(bin_idx).copied().unwrap_or(1.0);
                    let v = (nom + delta) * fac;
                    y[bin_idx] = v;
                    total[bin_idx] += v;
                }

                samples_out.push(ExpectedSampleYields { sample_name: sample.name.clone(), y });
            }

            out.push(ExpectedChannelSampleYields {
                channel_name: channel.name.clone(),
                samples: samples_out,
                total,
            });
        }

        Ok(out)
    }

    /// Expected **main** data in pyhf ordering (channels lexicographically), without auxdata.
    pub fn expected_data_pyhf_main(&self, params: &[f64]) -> Result<Vec<f64>> {
        self.validate_params_len(params.len())?;

        let expected_main_flat: Vec<f64> = self.expected_data(params)?;

        let mut per_channel: Vec<(&str, Vec<f64>)> = Vec::with_capacity(self.channels.len());
        let mut offset = 0usize;
        for channel in &self.channels {
            let n_bins = channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0);
            let slice = expected_main_flat
                .get(offset..offset + n_bins)
                .ok_or_else(|| {
                    ns_core::Error::Validation("expected_data length mismatch".to_string())
                })?
                .to_vec();
            offset += n_bins;
            per_channel.push((channel.name.as_str(), slice));
        }
        per_channel.sort_by(|a, b| a.0.cmp(b.0));

        let mut out: Vec<f64> = Vec::with_capacity(expected_main_flat.len());
        for (_name, bins) in per_channel {
            out.extend(bins);
        }
        Ok(out)
    }

    /// Expected data in pyhf ordering: `main_data + auxdata`.
    ///
    /// - Main data is ordered by channel name (lexicographically).
    /// - Auxdata is ordered according to pyhf's parameter-set construction:
    ///   modifier types are scanned in `histfactory_set` order and modifier names are sorted.
    /// - For `constrained_by_normal` parameter sets, the aux expectation is the parameter value.
    /// - For `shapesys` (Barlow-Beeston) Poisson constraints, the aux expectation is `gamma_i * tau_i`.
    pub fn expected_data_pyhf(&self, params: &[f64]) -> Result<Vec<f64>> {
        self.validate_params_len(params.len())?;

        let mut out = self.expected_data_pyhf_main(params)?;
        out.reserve(self.parameters.len());

        // Auxdata in pyhf parameter-set order:
        // - parameter sets are collected by modifier type in `histfactory_set` order
        //   (`histosys`, `lumi`, `normfactor`, `normsys`, `shapefactor`, `shapesys`, `staterror`)
        // - modifier names are sorted within each type
        // - only constrained parameter sets contribute auxdata
        //
        // For constrained_by_normal parameter sets, the aux expectation equals the parameter value.
        // For constrained_by_poisson (shapesys), the aux expectation equals `gamma_i * tau_i`.
        fn base_name(name: &str) -> &str {
            name.split_once('[').map(|(b, _)| b).unwrap_or(name)
        }

        let mut histosys: HashMap<String, usize> = HashMap::new();
        let mut lumi: HashMap<String, usize> = HashMap::new();
        let mut normsys: HashMap<String, usize> = HashMap::new();
        let mut staterror: HashMap<String, Vec<usize>> = HashMap::new();

        // shapesys needs tau values, which are stored in `auxiliary_data`.
        let mut shapesys: HashMap<String, (Vec<usize>, Vec<f64>)> = HashMap::new();

        // Collect parameter-set names and indices from modifiers.
        for channel in &self.channels {
            for sample in &channel.samples {
                for m in &sample.modifiers {
                    match m {
                        ModelModifier::HistoSys { param_idx, .. } => {
                            if let Some(p) = self.parameters.get(*param_idx) {
                                histosys.insert(p.name.clone(), *param_idx);
                            }
                        }
                        ModelModifier::Lumi { param_idx } => {
                            if let Some(p) = self.parameters.get(*param_idx) {
                                lumi.insert(p.name.clone(), *param_idx);
                            }
                        }
                        ModelModifier::NormSys { param_idx, .. } => {
                            if let Some(p) = self.parameters.get(*param_idx) {
                                normsys.insert(p.name.clone(), *param_idx);
                            }
                        }
                        ModelModifier::StatError { param_indices, .. } => {
                            let b = self
                                .parameters
                                .get(*param_indices.first().unwrap_or(&usize::MAX))
                                .map(|p| base_name(p.name.as_str()).to_string())
                                .unwrap_or_default();
                            if !b.is_empty() {
                                match staterror.get(&b) {
                                    None => {
                                        staterror.insert(b, param_indices.clone());
                                    }
                                    Some(prev) => {
                                        if prev != param_indices {
                                            return Err(ns_core::Error::Validation(format!(
                                                "Inconsistent StatError param indices for '{}'",
                                                b
                                            )));
                                        }
                                    }
                                }
                            }
                        }
                        _ => {}
                    }
                }
            }
        }

        // Build shapesys mapping from stored auxiliary constraints.
        for channel in &self.channels {
            for constraint in &channel.auxiliary_data {
                let Some(sample) = channel.samples.get(constraint.sample_idx) else { continue };
                let Some(ModelModifier::ShapeSys { param_indices, .. }) =
                    sample.modifiers.get(constraint.modifier_idx)
                else {
                    continue;
                };

                let b = self
                    .parameters
                    .get(*param_indices.first().unwrap_or(&usize::MAX))
                    .map(|p| base_name(p.name.as_str()).to_string())
                    .unwrap_or_default();
                if b.is_empty() {
                    continue;
                }

                match shapesys.get(&b) {
                    None => {
                        shapesys.insert(b, (param_indices.clone(), constraint.tau.clone()));
                    }
                    Some((prev_idx, prev_tau)) => {
                        if prev_idx != param_indices || prev_tau != &constraint.tau {
                            return Err(ns_core::Error::Validation(format!(
                                "Inconsistent ShapeSys definition for '{}'",
                                b
                            )));
                        }
                    }
                }
            }
        }

        fn sorted_keys<T>(m: &HashMap<String, T>) -> Vec<String> {
            let mut v: Vec<String> = m.keys().cloned().collect();
            v.sort();
            v
        }

        for name in sorted_keys(&histosys) {
            let idx = *histosys.get(&name).ok_or_else(|| {
                ns_core::Error::Validation(format!("Missing Histosys index for '{}'", name))
            })?;
            let val = params.get(idx).copied().ok_or_else(|| {
                ns_core::Error::Validation(format!(
                    "Histosys param index out of range for '{}': idx={} len={}",
                    name,
                    idx,
                    params.len()
                ))
            })?;
            out.push(val);
        }
        for name in sorted_keys(&lumi) {
            let idx = *lumi.get(&name).ok_or_else(|| {
                ns_core::Error::Validation(format!("Missing Lumi index for '{}'", name))
            })?;
            let val = params.get(idx).copied().ok_or_else(|| {
                ns_core::Error::Validation(format!(
                    "Lumi param index out of range for '{}': idx={} len={}",
                    name,
                    idx,
                    params.len()
                ))
            })?;
            out.push(val);
        }
        for name in sorted_keys(&normsys) {
            let idx = *normsys.get(&name).ok_or_else(|| {
                ns_core::Error::Validation(format!("Missing NormSys index for '{}'", name))
            })?;
            let val = params.get(idx).copied().ok_or_else(|| {
                ns_core::Error::Validation(format!(
                    "NormSys param index out of range for '{}': idx={} len={}",
                    name,
                    idx,
                    params.len()
                ))
            })?;
            out.push(val);
        }
        for name in sorted_keys(&shapesys) {
            let (param_indices, tau) = shapesys.get(&name).ok_or_else(|| {
                ns_core::Error::Validation(format!("Missing ShapeSys definition for '{}'", name))
            })?;
            if param_indices.len() != tau.len() {
                return Err(ns_core::Error::Validation(format!(
                    "ShapeSys aux length mismatch for '{}': params={} tau={}",
                    name,
                    param_indices.len(),
                    tau.len()
                )));
            }
            for (&pidx, &tau_i) in param_indices.iter().zip(tau.iter()) {
                let gamma = params.get(pidx).copied().ok_or_else(|| {
                    ns_core::Error::Validation(format!(
                        "ShapeSys param index out of range for '{}': idx={} len={}",
                        name,
                        pidx,
                        params.len()
                    ))
                })?;
                out.push((gamma * tau_i).max(EXPECTED_FLOOR));
            }
        }
        for name in sorted_keys(&staterror) {
            let idxs = staterror.get(&name).ok_or_else(|| {
                ns_core::Error::Validation(format!("Missing StatError indices for '{}'", name))
            })?;
            for &pidx in idxs {
                let gamma = params.get(pidx).copied().ok_or_else(|| {
                    ns_core::Error::Validation(format!(
                        "StatError param index out of range for '{}': idx={} len={}",
                        name,
                        pidx,
                        params.len()
                    ))
                })?;
                out.push(gamma);
            }
        }

        Ok(out)
    }

    /// Generic NLL that works with any [`Scalar`] type (f64 or Dual).
    pub fn nll_generic<T: Scalar>(&self, params: &[T]) -> Result<T> {
        self.validate_params_len(params.len())?;
        let expected = self.expected_data_generic(params)?;

        let mut nll = T::from_f64(0.0);

        // Poisson likelihood for main bins
        let mut bin_idx = 0;
        for channel in &self.channels {
            let n_bins = channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0);
            if !channel.include_in_fit {
                // Skip main-bin and auxdata terms for validation channels, but keep expected indexing aligned.
                bin_idx += n_bins;
                continue;
            }
            for i in 0..n_bins {
                let obs = channel.observed.get(i).copied().unwrap_or(0.0);
                let exp = expected.get(bin_idx).copied().unwrap_or(T::from_f64(EXPECTED_FLOOR));
                let exp = exp.max_s(T::from_f64(EXPECTED_FLOOR));

                if obs > 0.0 {
                    let ln_factorial = T::from_f64(Self::ln_factorial(obs));
                    nll = nll + exp - T::from_f64(obs) * exp.ln() + ln_factorial;
                } else {
                    nll = nll + exp;
                }

                bin_idx += 1;
            }

            // Barlow-Beeston auxiliary data (Poisson constraints)
            for constraint in &channel.auxiliary_data {
                if let Some(sample) = channel.samples.get(constraint.sample_idx)
                    && let Some(ModelModifier::ShapeSys { param_indices, .. }) =
                        sample.modifiers.get(constraint.modifier_idx)
                {
                    for ((&tau, &obs_aux), &gamma_idx) in constraint
                        .tau
                        .iter()
                        .zip(constraint.observed.iter())
                        .zip(param_indices.iter())
                    {
                        let gamma = params.get(gamma_idx).copied().ok_or_else(|| {
                            ns_core::Error::Validation(format!(
                                "ShapeSys gamma index out of range in aux constraint: idx={} len={}",
                                gamma_idx,
                                params.len()
                            ))
                        })?;
                        let exp_aux = (gamma * T::from_f64(tau)).max_s(T::from_f64(EXPECTED_FLOOR));

                        if obs_aux > 0.0 {
                            let ln_factorial = T::from_f64(Self::ln_factorial(obs_aux));
                            nll =
                                nll + exp_aux - T::from_f64(obs_aux) * exp_aux.ln() + ln_factorial;
                        } else {
                            nll = nll + exp_aux;
                        }
                    }
                }
            }
        }

        // Constraint terms
        for (param_idx, param) in self.parameters.iter().enumerate() {
            // Skip parameters without constraints.
            if !param.constrained {
                continue;
            }

            // Non-standard HistFactory constraint terms.
            match &param.constraint_term {
                Some(ConstraintTerm::Uniform) | Some(ConstraintTerm::NoConstraint) => {
                    continue;
                }
                Some(ConstraintTerm::Gamma { rel }) if *rel > 0.0 => {
                    // Gamma constraint on beta (parameter value), using ROOT/HistFactory convention:
                    // tau = 1/rel^2, k = tau + 1, theta = 1/tau (scale).
                    let beta = params.get(param_idx).copied().ok_or_else(|| {
                        ns_core::Error::Validation(format!(
                            "Constrained parameter index out of range: idx={} len={}",
                            param_idx,
                            params.len()
                        ))
                    })?;
                    let beta = beta.max_s(T::from_f64(EXPECTED_FLOOR));

                    let tau = 1.0 / (*rel * *rel);
                    let k = tau + 1.0;
                    let theta = 1.0 / tau;
                    let c = k * theta.ln() + ln_gamma(k);

                    // NLL = beta/theta - (k-1)*ln(beta) + k*ln(theta) + lnGamma(k)
                    let term = beta * T::from_f64(1.0 / theta) - T::from_f64(k - 1.0) * beta.ln()
                        + T::from_f64(c);
                    nll = nll + term;
                    continue;
                }
                _ => {}
            }

            // Gaussian constraints (pyhf `constrained_by_normal`)
            if let (Some(center), Some(width)) = (param.constraint_center, param.constraint_width)
                && width > 0.0
            {
                let value = params.get(param_idx).copied().ok_or_else(|| {
                    ns_core::Error::Validation(format!(
                        "Constrained parameter index out of range: idx={} len={}",
                        param_idx,
                        params.len()
                    ))
                })?;
                let pull = (value - T::from_f64(center)) * T::from_f64(1.0 / width);
                nll = nll
                    + T::from_f64(0.5) * pull * pull
                    + T::from_f64(width.ln() + 0.5 * (2.0 * std::f64::consts::PI).ln());
            }
        }

        Ok(nll)
    }

    /// Generic expected data computation.
    pub fn expected_data_generic<T: Scalar>(&self, params: &[T]) -> Result<Vec<T>> {
        self.validate_params_len(params.len())?;
        let mut result = Vec::new();

        for channel in &self.channels {
            let n_bins = channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0);
            let mut channel_expected: Vec<T> = vec![T::from_f64(0.0); n_bins];

            for sample in &channel.samples {
                // Match pyhf combination semantics:
                // - "addition" modifiers (e.g. histosys) produce deltas in nominal space
                // - "multiplication" modifiers produce factors (scalar or per-bin)
                // - expected = (nominal + sum(deltas)) * product(factors)
                let sample_nominal: Vec<T> =
                    sample.nominal.iter().map(|&v| T::from_f64(v)).collect();
                let mut sample_deltas: Vec<T> = vec![T::from_f64(0.0); sample_nominal.len()];
                let mut sample_factors: Vec<T> = vec![T::from_f64(1.0); sample_nominal.len()];

                for modifier in &sample.modifiers {
                    match modifier {
                        ModelModifier::NormFactor { param_idx } => {
                            let norm = params.get(*param_idx).copied().ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "NormFactor param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            for fac in &mut sample_factors {
                                *fac = *fac * norm;
                            }
                        }
                        ModelModifier::ShapeSys { param_indices, .. } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma_val =
                                        params.get(gamma_idx).copied().ok_or_else(|| {
                                            ns_core::Error::Validation(format!(
                                                "ShapeSys gamma index out of range: idx={} len={}",
                                                gamma_idx,
                                                params.len()
                                            ))
                                        })?;
                                    sample_factors[bin_idx] = sample_factors[bin_idx] * gamma_val;
                                }
                            }
                        }
                        ModelModifier::NormSys { param_idx, hi_factor, lo_factor, interp_code } => {
                            let alpha_raw = params.get(*param_idx).copied().ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "NormSys param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            let alpha = self.normsys_alpha_effective(*param_idx, alpha_raw);
                            let factor = match interp_code {
                                NormSysInterpCode::Code1 => {
                                    normsys_code1(alpha, *hi_factor, *lo_factor)
                                }
                                NormSysInterpCode::Code4 => {
                                    normsys_code4(alpha, *hi_factor, *lo_factor)
                                }
                            };
                            for fac in &mut sample_factors {
                                *fac = *fac * factor;
                            }
                        }
                        ModelModifier::HistoSys {
                            param_idx,
                            hi_template,
                            lo_template,
                            interp_code,
                        } => {
                            let alpha = params.get(*param_idx).copied().ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "HistoSys param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            let alpha_val = alpha.value();
                            match interp_code {
                                HistoSysInterpCode::Code0 => {
                                    // Piecewise linear: kink at alpha=0
                                    if alpha_val >= 0.0 {
                                        for (bin_idx, delta_slot) in
                                            sample_deltas.iter_mut().enumerate()
                                        {
                                            let nom = sample_nominal
                                                .get(bin_idx)
                                                .copied()
                                                .unwrap_or(T::from_f64(0.0));
                                            let hi = T::from_f64(
                                                hi_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom.value()),
                                            );
                                            *delta_slot = *delta_slot + (hi - nom) * alpha;
                                        }
                                    } else {
                                        for (bin_idx, delta_slot) in
                                            sample_deltas.iter_mut().enumerate()
                                        {
                                            let nom = sample_nominal
                                                .get(bin_idx)
                                                .copied()
                                                .unwrap_or(T::from_f64(0.0));
                                            let lo = T::from_f64(
                                                lo_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom.value()),
                                            );
                                            *delta_slot = *delta_slot + (nom - lo) * alpha;
                                        }
                                    }
                                }
                                HistoSysInterpCode::Code2 => {
                                    for (bin_idx, delta_slot) in
                                        sample_deltas.iter_mut().enumerate()
                                    {
                                        let nom = sample_nominal
                                            .get(bin_idx)
                                            .copied()
                                            .unwrap_or(T::from_f64(0.0));
                                        let hi = T::from_f64(
                                            hi_template
                                                .get(bin_idx)
                                                .copied()
                                                .unwrap_or(nom.value()),
                                        );
                                        let lo = T::from_f64(
                                            lo_template
                                                .get(bin_idx)
                                                .copied()
                                                .unwrap_or(nom.value()),
                                        );
                                        *delta_slot =
                                            *delta_slot + histosys_code2_delta(alpha, lo, nom, hi);
                                    }
                                }
                                HistoSysInterpCode::Code4p => {
                                    if alpha_val > 1.0 {
                                        for (bin_idx, delta_slot) in
                                            sample_deltas.iter_mut().enumerate()
                                        {
                                            let nom = sample_nominal
                                                .get(bin_idx)
                                                .copied()
                                                .unwrap_or(T::from_f64(0.0));
                                            let hi = T::from_f64(
                                                hi_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom.value()),
                                            );
                                            *delta_slot = *delta_slot + (hi - nom) * alpha;
                                        }
                                    } else if alpha_val < -1.0 {
                                        for (bin_idx, delta_slot) in
                                            sample_deltas.iter_mut().enumerate()
                                        {
                                            let nom = sample_nominal
                                                .get(bin_idx)
                                                .copied()
                                                .unwrap_or(T::from_f64(0.0));
                                            let lo = T::from_f64(
                                                lo_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom.value()),
                                            );
                                            *delta_slot = *delta_slot + (nom - lo) * alpha;
                                        }
                                    } else {
                                        let asq = alpha * alpha;
                                        let tmp1 = asq * T::from_f64(3.0) - T::from_f64(10.0);
                                        let tmp2 = asq * tmp1 + T::from_f64(15.0);
                                        let tmp3 = asq * tmp2;
                                        let half = T::from_f64(0.5);
                                        let a_const = T::from_f64(0.0625);

                                        for (bin_idx, delta_slot) in
                                            sample_deltas.iter_mut().enumerate()
                                        {
                                            let nom = sample_nominal
                                                .get(bin_idx)
                                                .copied()
                                                .unwrap_or(T::from_f64(0.0));
                                            let nom_val = nom.value();
                                            let hi = T::from_f64(
                                                hi_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom_val),
                                            );
                                            let lo = T::from_f64(
                                                lo_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom_val),
                                            );
                                            let delta_up = hi - nom;
                                            let delta_dn = nom - lo;
                                            let s = half * (delta_up + delta_dn);
                                            let a = a_const * (delta_up - delta_dn);
                                            *delta_slot = *delta_slot + alpha * s;
                                            *delta_slot = *delta_slot + tmp3 * a;
                                        }
                                    }
                                }
                            }
                        }
                        ModelModifier::StatError { param_indices, .. } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma_val =
                                        params.get(gamma_idx).copied().ok_or_else(|| {
                                            ns_core::Error::Validation(format!(
                                                "StatError gamma index out of range: idx={} len={}",
                                                gamma_idx,
                                                params.len()
                                            ))
                                        })?;
                                    sample_factors[bin_idx] = sample_factors[bin_idx] * gamma_val;
                                }
                            }
                        }
                        ModelModifier::ShapeFactor { param_indices } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma_val =
                                        params.get(gamma_idx).copied().ok_or_else(|| {
                                            ns_core::Error::Validation(format!(
                                                "ShapeFactor gamma index out of range: idx={} len={}",
                                                gamma_idx,
                                                params.len()
                                            ))
                                        })?;
                                    sample_factors[bin_idx] = sample_factors[bin_idx] * gamma_val;
                                }
                            }
                        }
                        ModelModifier::Lumi { param_idx } => {
                            let lumi = params.get(*param_idx).copied().ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "Lumi param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            for fac in &mut sample_factors {
                                *fac = *fac * lumi;
                            }
                        }
                    }
                }

                for (bin_idx, ch_val) in channel_expected.iter_mut().enumerate() {
                    let nom = sample_nominal.get(bin_idx).copied().unwrap_or(T::from_f64(0.0));
                    let delta = sample_deltas.get(bin_idx).copied().unwrap_or(T::from_f64(0.0));
                    let fac = sample_factors.get(bin_idx).copied().unwrap_or(T::from_f64(1.0));
                    *ch_val = *ch_val + (nom + delta) * fac;
                }
            }

            result.extend(channel_expected);
        }

        Ok(result)
    }

    /// Compute gradient of NLL using central finite differences (fallback).
    pub fn gradient(&self, params: &[f64]) -> Result<Vec<f64>> {
        use rayon::prelude::*;

        self.validate_params_len(params.len())?;
        let n = params.len();
        let mut grad = vec![0.0; n];

        let grad_vals: Vec<_> = (0..n)
            .into_par_iter()
            .map(|i| {
                let eps = 1e-8_f64.sqrt() * params[i].abs().max(1.0);

                let mut params_plus = params.to_vec();
                params_plus[i] += eps;
                let f_plus = self.nll(&params_plus)?;

                let mut params_minus = params.to_vec();
                params_minus[i] -= eps;
                let f_minus = self.nll(&params_minus)?;

                Ok((f_plus - f_minus) / (2.0 * eps))
            })
            .collect::<Result<Vec<f64>>>()?;

        grad.copy_from_slice(&grad_vals);
        Ok(grad)
    }

    /// Compute gradient of NLL using forward-mode automatic differentiation.
    ///
    /// More accurate than finite differences and avoids step-size sensitivity.
    /// Cost: N evaluations (one per parameter), same as numerical gradient.
    pub fn gradient_ad(&self, params: &[f64]) -> Result<Vec<f64>> {
        use ns_ad::dual::Dual;

        self.validate_params_len(params.len())?;
        let n = params.len();
        let mut grad = vec![0.0; n];

        for (i, g) in grad.iter_mut().enumerate() {
            let dual_params: Vec<Dual> = params
                .iter()
                .enumerate()
                .map(|(j, &v)| if j == i { Dual::var(v) } else { Dual::constant(v) })
                .collect();

            let nll_dual = self.nll_generic(&dual_params)?;
            *g = nll_dual.dot;
        }

        Ok(grad)
    }

    /// Compute gradient of NLL using reverse-mode automatic differentiation.
    ///
    /// Cost: **one** forward + backward pass for the **full** gradient,
    /// regardless of parameter count.  Preferred for N > ~10 parameters.
    pub fn gradient_reverse(&self, params: &[f64]) -> Result<Vec<f64>> {
        use ns_ad::tape::Tape;

        self.validate_params_len(params.len())?;
        let n = params.len();
        // Pre-allocate tape: rough estimate of nodes per NLL evaluation
        let mut tape = Tape::with_capacity(n * 20);

        // Record input variables
        let param_vars: Vec<_> = params.iter().map(|&v| tape.var(v)).collect();

        // Build NLL on tape
        let nll_var = self.nll_on_tape(&mut tape, &param_vars)?;

        // Single backward pass => all gradients
        tape.backward(nll_var);

        // Collect gradients
        let grad: Vec<f64> = param_vars.iter().map(|&v| tape.adjoint(v)).collect();
        Ok(grad)
    }

    /// Compute gradient reusing an existing tape (avoids re-allocation).
    ///
    /// The tape is cleared and reused on each call, keeping its heap capacity.
    /// This saves ~30K allocations in a 1000-toy batch fit.
    pub fn gradient_reverse_reuse(
        &self,
        params: &[f64],
        tape: &mut ns_ad::tape::Tape,
    ) -> Result<Vec<f64>> {
        self.validate_params_len(params.len())?;
        tape.clear();

        let param_vars: Vec<_> = params.iter().map(|&v| tape.var(v)).collect();
        let nll_var = self.nll_on_tape(tape, &param_vars)?;
        tape.backward(nll_var);

        let grad: Vec<f64> = param_vars.iter().map(|&v| tape.adjoint(v)).collect();
        Ok(grad)
    }

    /// Record the full NLL computation on a [`Tape`](ns_ad::tape::Tape).
    fn nll_on_tape(
        &self,
        tape: &mut ns_ad::tape::Tape,
        params: &[ns_ad::tape::Var],
    ) -> Result<ns_ad::tape::Var> {
        self.validate_params_len(params.len())?;
        let expected = self.expected_data_on_tape(tape, params)?;
        let mut nll = tape.constant(0.0);

        // Poisson likelihood for main bins
        let mut bin_idx = 0;
        for channel in &self.channels {
            let n_bins = channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0);
            if !channel.include_in_fit {
                bin_idx += n_bins;
                continue;
            }
            for i in 0..n_bins {
                let obs = channel.observed.get(i).copied().unwrap_or(0.0);
                let exp = expected.get(bin_idx).copied().ok_or_else(|| {
                    ns_core::Error::Validation(format!(
                        "expected_data length mismatch on tape: bin_idx={} len={}",
                        bin_idx,
                        expected.len()
                    ))
                })?;
                let floor = tape.constant(EXPECTED_FLOOR);
                let exp = tape.max(exp, floor);

                if obs > 0.0 {
                    let ln_fact = tape.constant(Self::ln_factorial(obs));
                    let ln_exp = tape.ln(exp);
                    let obs_c = tape.constant(obs);
                    let obs_ln_exp = tape.mul(obs_c, ln_exp);
                    let bin_nll = tape.sub(exp, obs_ln_exp);
                    let bin_nll = tape.add(bin_nll, ln_fact);
                    nll = tape.add(nll, bin_nll);
                } else {
                    nll = tape.add(nll, exp);
                }

                bin_idx += 1;
            }

            // Barlow-Beeston auxiliary data
            for constraint in &channel.auxiliary_data {
                if let Some(sample) = channel.samples.get(constraint.sample_idx)
                    && let Some(ModelModifier::ShapeSys { param_indices, .. }) =
                        sample.modifiers.get(constraint.modifier_idx)
                {
                    for ((&tau, &obs_aux), &gamma_idx) in constraint
                        .tau
                        .iter()
                        .zip(constraint.observed.iter())
                        .zip(param_indices.iter())
                    {
                        let gamma = params.get(gamma_idx).copied().ok_or_else(|| {
                            ns_core::Error::Validation(format!(
                                "ShapeSys gamma index out of range in aux constraint (tape): idx={} len={}",
                                gamma_idx,
                                params.len()
                            ))
                        })?;
                        let tau_c = tape.constant(tau);
                        let exp_aux = tape.mul(gamma, tau_c);
                        let floor = tape.constant(EXPECTED_FLOOR);
                        let exp_aux = tape.max(exp_aux, floor);

                        if obs_aux > 0.0 {
                            let ln_fact = tape.constant(Self::ln_factorial(obs_aux));
                            let ln_exp = tape.ln(exp_aux);
                            let obs_c = tape.constant(obs_aux);
                            let obs_ln = tape.mul(obs_c, ln_exp);
                            let bin_nll = tape.sub(exp_aux, obs_ln);
                            let bin_nll = tape.add(bin_nll, ln_fact);
                            nll = tape.add(nll, bin_nll);
                        } else {
                            nll = tape.add(nll, exp_aux);
                        }
                    }
                }
            }
        }

        // Constraint terms
        for (param_idx, param) in self.parameters.iter().enumerate() {
            if !param.constrained {
                continue;
            }

            match &param.constraint_term {
                Some(ConstraintTerm::Uniform) | Some(ConstraintTerm::NoConstraint) => {
                    continue;
                }
                Some(ConstraintTerm::Gamma { rel }) if *rel > 0.0 => {
                    let beta = params.get(param_idx).copied().ok_or_else(|| {
                        ns_core::Error::Validation(format!(
                            "Constrained parameter index out of range (tape): idx={} len={}",
                            param_idx,
                            params.len()
                        ))
                    })?;
                    let floor = tape.constant(EXPECTED_FLOOR);
                    let beta = tape.max(beta, floor);

                    let tau = 1.0 / (*rel * *rel);
                    let k = tau + 1.0;
                    let theta = 1.0 / tau;
                    let c = k * theta.ln() + ln_gamma(k);

                    // NLL = beta/theta - (k-1)*ln(beta) + k*ln(theta) + lnGamma(k)
                    let inv_theta = tape.constant(1.0 / theta);
                    let beta_over_theta = tape.mul(beta, inv_theta);
                    let ln_beta = tape.ln(beta);
                    let km1 = tape.constant(k - 1.0);
                    let km1_ln = tape.mul(km1, ln_beta);
                    let c_c = tape.constant(c);
                    let term = tape.sub(beta_over_theta, km1_ln);
                    let term = tape.add(term, c_c);
                    nll = tape.add(nll, term);
                    continue;
                }
                _ => {}
            }

            // Gaussian constraints (pyhf `constrained_by_normal`)
            if let (Some(center), Some(width)) = (param.constraint_center, param.constraint_width)
                && width > 0.0
            {
                let value = params.get(param_idx).copied().ok_or_else(|| {
                    ns_core::Error::Validation(format!(
                        "Constrained parameter index out of range (tape): idx={} len={}",
                        param_idx,
                        params.len()
                    ))
                })?;
                let center_c = tape.constant(center);
                let diff = tape.sub(value, center_c);
                let inv_width = tape.constant(1.0 / width);
                let pull = tape.mul(diff, inv_width);
                let pull2 = tape.mul(pull, pull);
                let half = tape.constant(0.5);
                let constraint = tape.mul(half, pull2);
                nll = tape.add(nll, constraint);

                // Normalization constant: ln(sigma) + 0.5*ln(2*pi)
                // pyhf includes this in the full Gaussian log-pdf.
                let norm_const =
                    tape.constant(width.ln() + 0.5 * (2.0 * std::f64::consts::PI).ln());
                nll = tape.add(nll, norm_const);
            }
        }

        Ok(nll)
    }

    /// Record expected data computation on a tape.
    fn expected_data_on_tape(
        &self,
        tape: &mut ns_ad::tape::Tape,
        params: &[ns_ad::tape::Var],
    ) -> Result<Vec<ns_ad::tape::Var>> {
        type Var = ns_ad::tape::Var;
        self.validate_params_len(params.len())?;
        let mut result = Vec::new();

        for channel in &self.channels {
            let n_bins = channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0);
            let mut channel_expected: Vec<Var> = (0..n_bins).map(|_| tape.constant(0.0)).collect();

            for sample in &channel.samples {
                // Match pyhf: (nominal + sum(deltas)) * product(factors).
                let sample_nominal: Vec<Var> =
                    sample.nominal.iter().map(|&v| tape.constant(v)).collect();
                let mut sample_deltas: Vec<Var> =
                    (0..sample_nominal.len()).map(|_| tape.constant(0.0)).collect();
                let mut sample_factors: Vec<Var> =
                    (0..sample_nominal.len()).map(|_| tape.constant(1.0)).collect();

                for modifier in &sample.modifiers {
                    match modifier {
                        ModelModifier::NormFactor { param_idx } => {
                            let norm = params.get(*param_idx).copied().ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "NormFactor param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            for fac in &mut sample_factors {
                                *fac = tape.mul(*fac, norm);
                            }
                        }
                        ModelModifier::ShapeSys { param_indices, .. } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma =
                                        params.get(gamma_idx).copied().ok_or_else(|| {
                                            ns_core::Error::Validation(format!(
                                                "ShapeSys gamma index out of range: idx={} len={}",
                                                gamma_idx,
                                                params.len()
                                            ))
                                        })?;
                                    sample_factors[bin_idx] =
                                        tape.mul(sample_factors[bin_idx], gamma);
                                }
                            }
                        }
                        ModelModifier::NormSys { param_idx, hi_factor, lo_factor, interp_code } => {
                            let alpha_raw = params.get(*param_idx).copied().ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "NormSys param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            let alpha =
                                self.normsys_alpha_effective_on_tape(tape, *param_idx, alpha_raw);
                            let factor = match interp_code {
                                NormSysInterpCode::Code1 => {
                                    normsys_code1_on_tape(tape, alpha, *hi_factor, *lo_factor)
                                }
                                NormSysInterpCode::Code4 => {
                                    normsys_code4_on_tape(tape, alpha, *hi_factor, *lo_factor)
                                }
                            };
                            for fac in &mut sample_factors {
                                *fac = tape.mul(*fac, factor);
                            }
                        }
                        ModelModifier::HistoSys {
                            param_idx,
                            hi_template,
                            lo_template,
                            interp_code,
                        } => {
                            let alpha = params.get(*param_idx).copied().ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "HistoSys param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            let alpha_val = tape.val(alpha);

                            match interp_code {
                                HistoSysInterpCode::Code0 => {
                                    if alpha_val >= 0.0 {
                                        for (bin_idx, delta_slot) in
                                            sample_deltas.iter_mut().enumerate()
                                        {
                                            let nom = sample_nominal[bin_idx];
                                            let nom_val = tape.val(nom);
                                            let hi = tape.constant(
                                                hi_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom_val),
                                            );
                                            let delta_up = tape.sub(hi, nom);
                                            let delta = tape.mul(alpha, delta_up);
                                            *delta_slot = tape.add(*delta_slot, delta);
                                        }
                                    } else {
                                        for (bin_idx, delta_slot) in
                                            sample_deltas.iter_mut().enumerate()
                                        {
                                            let nom = sample_nominal[bin_idx];
                                            let nom_val = tape.val(nom);
                                            let lo = tape.constant(
                                                lo_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom_val),
                                            );
                                            let delta_dn = tape.sub(nom, lo);
                                            let delta = tape.mul(alpha, delta_dn);
                                            *delta_slot = tape.add(*delta_slot, delta);
                                        }
                                    }
                                }
                                HistoSysInterpCode::Code2 => {
                                    // Quadratic interpolation + linear extrapolation
                                    let c_half = tape.constant(0.5);
                                    for (bin_idx, delta_slot) in
                                        sample_deltas.iter_mut().enumerate()
                                    {
                                        let nom = sample_nominal[bin_idx];
                                        let nom_val = tape.val(nom);
                                        let hi = tape.constant(
                                            hi_template.get(bin_idx).copied().unwrap_or(nom_val),
                                        );
                                        let lo = tape.constant(
                                            lo_template.get(bin_idx).copied().unwrap_or(nom_val),
                                        );
                                        // S = 0.5*(up - down), A = 0.5*(up + down) - nom
                                        let up_minus_down = tape.sub(hi, lo);
                                        let s = tape.mul(c_half, up_minus_down);
                                        let up_plus_down = tape.add(hi, lo);
                                        let half_upd = tape.mul(c_half, up_plus_down);
                                        let a = tape.sub(half_upd, nom);
                                        // δ = α·S + f(α)·A
                                        let alpha_s = tape.mul(alpha, s);
                                        if alpha_val.abs() <= 1.0 {
                                            // |α| ≤ 1: f(α) = α²
                                            let asq = tape.mul(alpha, alpha);
                                            let asq_a = tape.mul(asq, a);
                                            let delta = tape.add(alpha_s, asq_a);
                                            *delta_slot = tape.add(*delta_slot, delta);
                                        } else if alpha_val > 1.0 {
                                            // α > 1: f(α) = 2α − 1
                                            let two = tape.constant(2.0);
                                            let one = tape.constant(1.0);
                                            let two_alpha = tape.mul(two, alpha);
                                            let f = tape.sub(two_alpha, one);
                                            let f_a = tape.mul(f, a);
                                            let delta = tape.add(alpha_s, f_a);
                                            *delta_slot = tape.add(*delta_slot, delta);
                                        } else {
                                            // α < −1: f(α) = −2α − 1
                                            let neg_two = tape.constant(-2.0);
                                            let one = tape.constant(1.0);
                                            let neg_two_alpha = tape.mul(neg_two, alpha);
                                            let f = tape.sub(neg_two_alpha, one);
                                            let f_a = tape.mul(f, a);
                                            let delta = tape.add(alpha_s, f_a);
                                            *delta_slot = tape.add(*delta_slot, delta);
                                        }
                                    }
                                }
                                HistoSysInterpCode::Code4p => {
                                    if alpha_val > 1.0 {
                                        for (bin_idx, delta_slot) in
                                            sample_deltas.iter_mut().enumerate()
                                        {
                                            let nom = sample_nominal[bin_idx];
                                            let nom_val = tape.val(nom);
                                            let hi = tape.constant(
                                                hi_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom_val),
                                            );
                                            let delta_up = tape.sub(hi, nom);
                                            let delta = tape.mul(alpha, delta_up);
                                            *delta_slot = tape.add(*delta_slot, delta);
                                        }
                                    } else if alpha_val < -1.0 {
                                        for (bin_idx, delta_slot) in
                                            sample_deltas.iter_mut().enumerate()
                                        {
                                            let nom = sample_nominal[bin_idx];
                                            let nom_val = tape.val(nom);
                                            let lo = tape.constant(
                                                lo_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom_val),
                                            );
                                            let delta_dn = tape.sub(nom, lo);
                                            let delta = tape.mul(alpha, delta_dn);
                                            *delta_slot = tape.add(*delta_slot, delta);
                                        }
                                    } else {
                                        let c_half = tape.constant(0.5);
                                        let c_a = tape.constant(0.0625);
                                        let c_three = tape.constant(3.0);
                                        let c_ten = tape.constant(10.0);
                                        let c_fifteen = tape.constant(15.0);

                                        let asq = tape.mul(alpha, alpha);
                                        let asq_x3 = tape.mul(asq, c_three);
                                        let tmp1 = tape.sub(asq_x3, c_ten);
                                        let asq_tmp1 = tape.mul(asq, tmp1);
                                        let tmp2 = tape.add(asq_tmp1, c_fifteen);
                                        let tmp3 = tape.mul(asq, tmp2);

                                        for (bin_idx, delta_slot) in
                                            sample_deltas.iter_mut().enumerate()
                                        {
                                            let nom = sample_nominal[bin_idx];
                                            let nom_val = tape.val(nom);
                                            let hi = tape.constant(
                                                hi_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom_val),
                                            );
                                            let lo = tape.constant(
                                                lo_template
                                                    .get(bin_idx)
                                                    .copied()
                                                    .unwrap_or(nom_val),
                                            );
                                            let delta_up = tape.sub(hi, nom);
                                            let delta_dn = tape.sub(nom, lo);
                                            let sum = tape.add(delta_up, delta_dn);
                                            let s = tape.mul(sum, c_half);
                                            let diff = tape.sub(delta_up, delta_dn);
                                            let a = tape.mul(diff, c_a);
                                            let alpha_s = tape.mul(alpha, s);
                                            *delta_slot = tape.add(*delta_slot, alpha_s);
                                            let tmp3_a = tape.mul(tmp3, a);
                                            *delta_slot = tape.add(*delta_slot, tmp3_a);
                                        }
                                    }
                                }
                            }
                        }
                        ModelModifier::StatError { param_indices, .. } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma =
                                        params.get(gamma_idx).copied().ok_or_else(|| {
                                            ns_core::Error::Validation(format!(
                                                "StatError gamma index out of range: idx={} len={}",
                                                gamma_idx,
                                                params.len()
                                            ))
                                        })?;
                                    sample_factors[bin_idx] =
                                        tape.mul(sample_factors[bin_idx], gamma);
                                }
                            }
                        }
                        ModelModifier::ShapeFactor { param_indices } => {
                            for (bin_idx, &gamma_idx) in param_indices.iter().enumerate() {
                                if bin_idx < sample_factors.len() {
                                    let gamma = params.get(gamma_idx).copied().ok_or_else(|| {
                                        ns_core::Error::Validation(format!(
                                            "ShapeFactor gamma index out of range: idx={} len={}",
                                            gamma_idx,
                                            params.len()
                                        ))
                                    })?;
                                    sample_factors[bin_idx] =
                                        tape.mul(sample_factors[bin_idx], gamma);
                                }
                            }
                        }
                        ModelModifier::Lumi { param_idx } => {
                            let lumi = params.get(*param_idx).copied().ok_or_else(|| {
                                ns_core::Error::Validation(format!(
                                    "Lumi param index out of range: idx={} len={}",
                                    param_idx,
                                    params.len()
                                ))
                            })?;
                            for fac in &mut sample_factors {
                                *fac = tape.mul(*fac, lumi);
                            }
                        }
                    }
                }

                if sample_nominal.len() == n_bins {
                    for (bin_idx, ch_val) in channel_expected.iter_mut().enumerate() {
                        let nom = sample_nominal[bin_idx];
                        let delta = sample_deltas[bin_idx];
                        let fac = sample_factors[bin_idx];
                        let sum = tape.add(nom, delta);
                        let val = tape.mul(sum, fac);
                        *ch_val = tape.add(*ch_val, val);
                    }
                } else {
                    for (bin_idx, ch_val) in channel_expected.iter_mut().enumerate() {
                        let nom = sample_nominal
                            .get(bin_idx)
                            .copied()
                            .unwrap_or_else(|| tape.constant(0.0));
                        let delta = sample_deltas
                            .get(bin_idx)
                            .copied()
                            .unwrap_or_else(|| tape.constant(0.0));
                        let fac = sample_factors
                            .get(bin_idx)
                            .copied()
                            .unwrap_or_else(|| tape.constant(1.0));
                        let sum = tape.add(nom, delta);
                        let val = tape.mul(sum, fac);
                        *ch_val = tape.add(*ch_val, val);
                    }
                }
            }

            result.extend(channel_expected);
        }

        Ok(result)
    }

    /// Serialize the model into flat GPU buffers for CUDA batch evaluation.
    ///
    /// This is a one-time cost at accelerator initialization. The returned
    /// [`GpuModelData`] can be passed to `CudaBatchAccelerator::from_gpu_data()`.
    pub fn serialize_for_gpu(&self) -> ns_core::Result<ns_compute::cuda_types::GpuModelData> {
        use ns_compute::cuda_types::*;

        let n_params = self.parameters.len();

        // Accumulate flat buffers
        let mut nominal: Vec<f64> = Vec::new();
        let mut samples_info: Vec<GpuSampleInfo> = Vec::new();
        let mut modifier_descs: Vec<GpuModifierDesc> = Vec::new();
        let mut modifier_desc_offsets: Vec<u32> = Vec::new();
        let mut per_bin_param_indices: Vec<u32> = Vec::new();
        let mut modifier_data: Vec<f64> = Vec::new();
        let mut aux_poisson: Vec<GpuAuxPoissonEntry> = Vec::new();
        let mut gauss_constraints: Vec<GpuGaussConstraintEntry> = Vec::new();

        let mut n_main_bins: usize = 0;
        let mut sample_bin_offset: usize = 0;

        for channel in &self.channels {
            let channel_n_bins = channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0);
            if channel_n_bins == 0 {
                log::warn!(
                    "serialize_for_gpu: skipping channel with 0 bins (should not happen after validation)"
                );
                continue;
            }
            let main_bin_offset = n_main_bins;
            n_main_bins += channel_n_bins;

            for sample in &channel.samples {
                let s_n_bins = sample.nominal.len();
                let first_sample_bin = sample_bin_offset as u32;
                let mod_desc_start = modifier_descs.len() as u32;

                // Nominal values for this sample
                nominal.extend_from_slice(&sample.nominal);

                // Serialize each modifier
                for modifier in &sample.modifiers {
                    match modifier {
                        ModelModifier::NormFactor { param_idx } => {
                            modifier_descs.push(GpuModifierDesc {
                                param_idx: *param_idx as u32,
                                modifier_type: GpuModifierType::NormFactor as u8,
                                is_per_bin: 0,
                                _pad: 0,
                                data_offset: 0,
                                n_bins: 0,
                            });
                        }
                        ModelModifier::Lumi { param_idx } => {
                            modifier_descs.push(GpuModifierDesc {
                                param_idx: *param_idx as u32,
                                modifier_type: GpuModifierType::Lumi as u8,
                                is_per_bin: 0,
                                _pad: 0,
                                data_offset: 0,
                                n_bins: 0,
                            });
                        }
                        ModelModifier::NormSys { param_idx, hi_factor, lo_factor, interp_code } => {
                            if *interp_code != NormSysInterpCode::Code4 {
                                return Err(ns_core::Error::Validation(format!(
                                    "GPU serialization requires NormSys interpolation Code4 (smooth); got {:?}. \
                                     Use NextStat smooth defaults or rebuild the model with NormSys=Code4 (e.g. CLI: --interp-defaults root).",
                                    interp_code
                                )));
                            }
                            // GPU kernel currently only supports code4 polynomial coefficients.
                            let data_off = modifier_data.len() as u32;
                            let hi = *hi_factor;
                            let lo = *lo_factor;
                            if hi > 0.0 && lo > 0.0 {
                                let coeffs = normsys_code4_coeffs(hi, lo);
                                modifier_data.extend_from_slice(&coeffs);
                                modifier_data.push(hi.ln());
                                modifier_data.push(lo.ln());
                            } else {
                                return Err(ns_core::Error::Validation(format!(
                                    "NormSys param_idx={} has non-positive factor (hi={}, lo={}). \
                                     GPU serialization requires positive factors. \
                                     CPU path handles this via linear fallback, \
                                     but the GPU polynomial kernel cannot represent \
                                     piecewise-linear interpolation. \
                                     pyhf would produce NaN for this workspace.",
                                    param_idx, hi, lo
                                )));
                            }
                            modifier_descs.push(GpuModifierDesc {
                                param_idx: *param_idx as u32,
                                modifier_type: GpuModifierType::NormSys as u8,
                                is_per_bin: 0,
                                _pad: 0,
                                data_offset: data_off,
                                n_bins: 0,
                            });
                        }
                        ModelModifier::HistoSys {
                            param_idx,
                            hi_template,
                            lo_template,
                            interp_code,
                        } => {
                            if *interp_code != HistoSysInterpCode::Code4p {
                                return Err(ns_core::Error::Validation(format!(
                                    "GPU serialization requires HistoSys interpolation Code4p (smooth); got {:?}. \
                                     Use NextStat smooth defaults or rebuild the model with HistoSys=Code4p (e.g. CLI: --interp-defaults root).",
                                    interp_code
                                )));
                            }
                            let data_off = modifier_data.len() as u32;
                            // Store (delta_up, delta_dn) per bin
                            for bin_idx in 0..s_n_bins {
                                let nom = sample.nominal.get(bin_idx).copied().unwrap_or(0.0);
                                let hi = hi_template.get(bin_idx).copied().unwrap_or(nom);
                                let lo = lo_template.get(bin_idx).copied().unwrap_or(nom);
                                modifier_data.push(hi - nom); // delta_up
                                modifier_data.push(nom - lo); // delta_dn
                            }
                            modifier_descs.push(GpuModifierDesc {
                                param_idx: *param_idx as u32,
                                modifier_type: GpuModifierType::HistoSys as u8,
                                is_per_bin: 1,
                                _pad: 0,
                                data_offset: data_off,
                                n_bins: s_n_bins as u32,
                            });
                        }
                        ModelModifier::ShapeSys { param_indices, .. } => {
                            let data_off = per_bin_param_indices.len() as u32;
                            for &pidx in param_indices {
                                per_bin_param_indices.push(pidx as u32);
                            }
                            modifier_descs.push(GpuModifierDesc {
                                param_idx: 0,
                                modifier_type: GpuModifierType::ShapeSys as u8,
                                is_per_bin: 1,
                                _pad: 0,
                                data_offset: data_off,
                                n_bins: param_indices.len() as u32,
                            });
                        }
                        ModelModifier::StatError { param_indices, .. } => {
                            let data_off = per_bin_param_indices.len() as u32;
                            for &pidx in param_indices {
                                per_bin_param_indices.push(pidx as u32);
                            }
                            modifier_descs.push(GpuModifierDesc {
                                param_idx: 0,
                                modifier_type: GpuModifierType::StatError as u8,
                                is_per_bin: 1,
                                _pad: 0,
                                data_offset: data_off,
                                n_bins: param_indices.len() as u32,
                            });
                        }
                        ModelModifier::ShapeFactor { param_indices } => {
                            let data_off = per_bin_param_indices.len() as u32;
                            for &pidx in param_indices {
                                per_bin_param_indices.push(pidx as u32);
                            }
                            modifier_descs.push(GpuModifierDesc {
                                param_idx: 0,
                                modifier_type: GpuModifierType::ShapeFactor as u8,
                                is_per_bin: 1,
                                _pad: 0,
                                data_offset: data_off,
                                n_bins: param_indices.len() as u32,
                            });
                        }
                    }
                }

                let mod_desc_end = modifier_descs.len() as u32;
                modifier_desc_offsets.push(mod_desc_start);

                samples_info.push(GpuSampleInfo {
                    first_sample_bin,
                    n_bins: s_n_bins as u32,
                    main_bin_offset: main_bin_offset as u32,
                    n_modifiers: mod_desc_end - mod_desc_start,
                });

                sample_bin_offset += s_n_bins;
            }

            // Barlow-Beeston auxiliary Poisson constraints
            for constraint in &channel.auxiliary_data {
                if let Some(sample) = channel.samples.get(constraint.sample_idx)
                    && let Some(ModelModifier::ShapeSys { param_indices, .. }) =
                        sample.modifiers.get(constraint.modifier_idx)
                {
                    for (i, &gamma_idx) in param_indices.iter().enumerate() {
                        let tau = constraint.tau.get(i).copied().unwrap_or(0.0);
                        let obs_aux = constraint.observed.get(i).copied().unwrap_or(0.0);
                        if tau > 0.0 {
                            aux_poisson.push(GpuAuxPoissonEntry {
                                gamma_param_idx: gamma_idx as u16,
                                _pad: 0,
                                _pad2: 0.0,
                                tau,
                                observed_aux: obs_aux,
                            });
                        }
                    }
                }
            }
        }

        // Final modifier_desc_offsets sentinel
        modifier_desc_offsets.push(modifier_descs.len() as u32);

        // Gaussian constraints
        let mut constraint_const = 0.0f64;
        for (param_idx, param) in self.parameters.iter().enumerate() {
            if !param.constrained {
                continue;
            }
            if let (Some(center), Some(width)) = (param.constraint_center, param.constraint_width)
                && width > 0.0
            {
                gauss_constraints.push(GpuGaussConstraintEntry {
                    param_idx: param_idx as u16,
                    _pad: 0,
                    _pad2: 0.0,
                    center,
                    inv_width: 1.0 / width,
                });
                constraint_const += width.ln() + 0.5 * (2.0 * std::f64::consts::PI).ln();
            }
        }

        // Ensure per_bin_param_indices is non-empty (GPU needs valid pointer)
        if per_bin_param_indices.is_empty() {
            per_bin_param_indices.push(0);
        }
        if modifier_data.is_empty() {
            modifier_data.push(0.0);
        }
        if aux_poisson.is_empty() {
            aux_poisson.push(GpuAuxPoissonEntry {
                gamma_param_idx: 0,
                _pad: 0,
                _pad2: 0.0,
                tau: 0.0,
                observed_aux: 0.0,
            });
        }
        if gauss_constraints.is_empty() {
            gauss_constraints.push(GpuGaussConstraintEntry {
                param_idx: 0,
                _pad: 0,
                _pad2: 0.0,
                center: 0.0,
                inv_width: 0.0,
            });
        }

        Ok(GpuModelData {
            n_params,
            n_main_bins,
            n_sample_bins: sample_bin_offset,
            samples: samples_info,
            nominal,
            modifier_descs,
            modifier_desc_offsets,
            per_bin_param_indices,
            modifier_data,
            aux_poisson,
            gauss_constraints,
            constraint_const,
        })
    }
}

/// Pre-allocated scratch buffers for zero-allocation NLL evaluation.
///
/// Created once via [`NllScratch::for_model`] and reused across repeated
/// [`PreparedModel::nll_reuse`] calls to avoid heap allocation in the hot path.
pub struct NllScratch {
    /// Buffer for the full expected-data vector (capacity >= n_main_bins).
    pub(crate) expected: Vec<f64>,
    /// Buffer for per-channel expected yields (capacity >= max channel bins).
    pub(crate) channel_expected: Vec<f64>,
    /// Buffer for per-sample additive deltas (capacity >= max sample bins).
    pub(crate) sample_deltas: Vec<f64>,
    /// Buffer for per-sample multiplicative factors (capacity >= max sample bins).
    pub(crate) sample_factors: Vec<f64>,
}

impl NllScratch {
    /// Create an empty sentinel (zero-capacity buffers).
    ///
    /// Useful as a `std::mem::replace` target when transferring ownership
    /// into a `RefCell` and later swapping back.
    pub fn empty() -> Self {
        Self {
            expected: vec![],
            channel_expected: vec![],
            sample_deltas: vec![],
            sample_factors: vec![],
        }
    }

    /// Allocate scratch buffers sized for `model`.
    pub fn for_model(model: &HistFactoryModel) -> Self {
        let n_main_bins: usize = model
            .channels
            .iter()
            .map(|ch| ch.samples.first().map(|s| s.nominal.len()).unwrap_or(0))
            .sum();
        let max_bins: usize = model
            .channels
            .iter()
            .map(|ch| ch.samples.first().map(|s| s.nominal.len()).unwrap_or(0))
            .max()
            .unwrap_or(0);

        Self {
            expected: vec![0.0; n_main_bins],
            channel_expected: vec![0.0; max_bins],
            sample_deltas: vec![0.0; max_bins],
            sample_factors: vec![0.0; max_bins],
        }
    }
}

/// Pre-computed model data for fast f64 NLL evaluation.
///
/// Caches observed data, `lgamma(obs+1)`, observation masks, and Gaussian
/// constraint constants. Uses SIMD-accelerated Poisson NLL accumulation
/// via [`ns_compute::simd::poisson_nll_simd`], with a sparse scalar fast-path
/// that skips `ln(exp)` when `obs == 0`.
///
/// Created via [`HistFactoryModel::prepare`]. The generic AD path
/// ([`HistFactoryModel::nll_generic`]) is unchanged.
pub struct PreparedModel<'a> {
    model: &'a HistFactoryModel,
    /// Flat contiguous main-bin observed data (across all channels).
    observed_flat: Vec<f64>,
    /// `lgamma(obs + 1)` per main bin.
    ln_factorials: Vec<f64>,
    /// `1.0` if obs > 0, else `0.0` per main bin.
    obs_mask: Vec<f64>,
    /// Whether any main-bin observation is zero (enables sparse Poisson fast-path).
    has_zero_obs: bool,
    /// Number of main bins with `obs == 0`.
    n_zero_obs: usize,
    /// Sum of Gaussian constraint normalization constants:
    /// `Σ [ln(σ) + 0.5·ln(2π)]` over all constrained parameters.
    constraint_const: f64,
    /// Total number of main bins (sum across channels).
    n_main_bins: usize,
    /// Optional per-bin mask (1.0 = included in fit, 0.0 = excluded).
    ///
    /// When present, the prepared NLL zeros `expected[i]` for excluded bins to remove their contribution.
    fit_bin_mask: Option<Vec<f64>>,
}

impl HistFactoryModel {
    /// Create a [`PreparedModel`] that caches per-bin constants for fast NLL.
    pub fn prepare(&self) -> PreparedModel<'_> {
        let mut observed_flat = Vec::new();
        let mut ln_factorials = Vec::new();
        let mut obs_mask = Vec::new();
        let mut fit_bin_mask = Vec::new();
        let mut any_excluded = false;

        for channel in &self.channels {
            let n_bins = channel.samples.first().map(|s| s.nominal.len()).unwrap_or(0);
            if !channel.include_in_fit {
                any_excluded = true;
            }
            for i in 0..n_bins {
                let include = channel.include_in_fit;
                fit_bin_mask.push(if include { 1.0 } else { 0.0 });

                // For excluded bins, force a "safe" sparse Poisson evaluation:
                // - observed=0 => obs_mask=0, ln_factorial=0
                // - expected is later zeroed via fit_bin_mask, so nll_i becomes 0.
                let obs =
                    if include { channel.observed.get(i).copied().unwrap_or(0.0) } else { 0.0 };
                observed_flat.push(obs);
                ln_factorials.push(if obs == 0.0 { 0.0 } else { Self::ln_factorial(obs) });
                obs_mask.push(if obs > 0.0 { 1.0 } else { 0.0 });
            }
        }

        let n_main_bins = observed_flat.len();
        let n_zero_obs = obs_mask.iter().filter(|&&m| m == 0.0).count();
        let has_zero_obs = n_zero_obs > 0;

        // Pre-compute Gaussian constraint normalization constant
        let half_ln_2pi = 0.5 * (2.0 * std::f64::consts::PI).ln();
        let mut constraint_const = 0.0;
        for param in &self.parameters {
            if !param.constrained {
                continue;
            }
            // Gamma constraints have their own normalization term and are handled explicitly
            // in `PreparedModel::{nll,nll_reuse}` to match `nll_generic` semantics.
            if matches!(param.constraint_term, Some(ConstraintTerm::Gamma { .. })) {
                continue;
            }
            if let (Some(_center), Some(width)) = (param.constraint_center, param.constraint_width)
                && width > 0.0
            {
                constraint_const += width.ln() + half_ln_2pi;
            }
        }

        PreparedModel {
            model: self,
            observed_flat,
            ln_factorials,
            obs_mask,
            has_zero_obs,
            n_zero_obs,
            constraint_const,
            n_main_bins,
            fit_bin_mask: if any_excluded { Some(fit_bin_mask) } else { None },
        }
    }
}

impl PreparedModel<'_> {
    /// Compute NLL using pre-cached data and SIMD-accelerated Poisson accumulation.
    ///
    /// Equivalent to [`HistFactoryModel::nll`] but faster for f64 evaluation.
    pub fn nll(&self, params: &[f64]) -> Result<f64> {
        // 1. Compute expected data (scalar — modifier application is branchy)
        let mut expected = self.model.expected_data(params)?;

        // 1b. NaN/Inf guard — if modifiers produced non-finite values, bail early
        //     rather than letting NaN silently propagate through Poisson NLL.
        if expected.iter().any(|v| !v.is_finite()) {
            return Ok(f64::INFINITY);
        }

        // 2. Clamp expected >= EXPECTED_FLOOR
        #[cfg(feature = "accelerate")]
        if ns_compute::accelerate_enabled() {
            ns_compute::accelerate::clamp_expected_inplace(&mut expected, EXPECTED_FLOOR);
        } else {
            for val in &mut expected {
                if *val < EXPECTED_FLOOR {
                    *val = EXPECTED_FLOOR;
                }
            }
        }
        #[cfg(not(feature = "accelerate"))]
        for val in &mut expected {
            if *val < EXPECTED_FLOOR {
                *val = EXPECTED_FLOOR;
            }
        }

        // 2b. Apply fit/validation mask: excluded bins contribute 0.0 to the Poisson NLL.
        if let Some(mask) = self.fit_bin_mask.as_ref() {
            debug_assert_eq!(mask.len(), expected.len());
            for (e, &m) in expected.iter_mut().zip(mask.iter()) {
                if m == 0.0 {
                    *e = 0.0;
                }
            }
        }

        // expected_data returns exactly n_main_bins values
        debug_assert_eq!(expected.len(), self.n_main_bins);

        // 3. Poisson NLL for main bins
        //    Dispatch based on EvalMode (parity vs fast) and available backends.
        //    Parity mode: Kahan compensated summation, Accelerate disabled.
        //    Fast mode: SIMD/Accelerate, naive summation.
        let mut nll = Self::dispatch_poisson_nll(
            &expected,
            &self.observed_flat,
            &self.ln_factorials,
            &self.obs_mask,
            self.has_zero_obs,
            self.n_zero_obs,
            self.n_main_bins,
        );

        // 4. Barlow-Beeston auxiliary constraints (scalar — same as generic path)
        for channel in &self.model.channels {
            for constraint in &channel.auxiliary_data {
                if let Some(sample) = channel.samples.get(constraint.sample_idx)
                    && let Some(ModelModifier::ShapeSys { param_indices, .. }) =
                        sample.modifiers.get(constraint.modifier_idx)
                {
                    for ((&tau, &obs_aux), &gamma_idx) in constraint
                        .tau
                        .iter()
                        .zip(constraint.observed.iter())
                        .zip(param_indices.iter())
                    {
                        let gamma = params.get(gamma_idx).copied().ok_or_else(|| {
                            ns_core::Error::Validation(format!(
                                "ShapeSys gamma index out of range in aux constraint: idx={} len={}",
                                gamma_idx,
                                params.len()
                            ))
                        })?;
                        let exp_aux = (gamma * tau).max(EXPECTED_FLOOR);

                        if obs_aux > 0.0 {
                            let ln_factorial = Self::ln_factorial_static(obs_aux);
                            nll += exp_aux - obs_aux * exp_aux.ln() + ln_factorial;
                        } else {
                            nll += exp_aux;
                        }
                    }
                }
            }
        }

        // 5. Gaussian constraints: 0.5 * pull^2 only (constant part pre-computed)
        for (param_idx, param) in self.model.parameters.iter().enumerate() {
            // Match `nll_generic` constraint semantics.
            match &param.constraint_term {
                Some(ConstraintTerm::Uniform) | Some(ConstraintTerm::NoConstraint) => {
                    continue;
                }
                Some(ConstraintTerm::Gamma { rel }) if *rel > 0.0 => {
                    // Gamma constraint on beta (parameter value), using ROOT/HistFactory convention:
                    // tau = 1/rel^2, k = tau + 1, theta = 1/tau (scale).
                    let beta = params.get(param_idx).copied().ok_or_else(|| {
                        ns_core::Error::Validation(format!(
                            "Constrained parameter index out of range: idx={} len={}",
                            param_idx,
                            params.len()
                        ))
                    })?;
                    let beta = beta.max(EXPECTED_FLOOR);

                    let tau = 1.0 / (*rel * *rel);
                    let k = tau + 1.0;
                    let theta = 1.0 / tau;
                    let c = k * theta.ln() + ln_gamma(k);

                    // NLL = beta/theta - (k-1)*ln(beta) + k*ln(theta) + lnGamma(k)
                    let term = beta * (1.0 / theta) - (k - 1.0) * beta.ln() + c;
                    nll += term;
                    continue;
                }
                _ => {}
            }

            if !param.constrained {
                continue;
            }
            if let (Some(center), Some(width)) = (param.constraint_center, param.constraint_width)
                && width > 0.0
            {
                let value = params.get(param_idx).copied().ok_or_else(|| {
                    ns_core::Error::Validation(format!(
                        "Constrained parameter index out of range: idx={} len={}",
                        param_idx,
                        params.len()
                    ))
                })?;
                let pull = (value - center) / width;
                nll += 0.5 * pull * pull;
            }
        }

        // 6. Add pre-computed constraint normalization constant
        nll += self.constraint_const;

        Ok(nll)
    }

    /// Zero-allocation NLL: writes expected data into `scratch`, then computes Poisson NLL.
    ///
    /// Semantically identical to [`nll`] but avoids all heap allocation by reusing
    /// pre-allocated `scratch` buffers. Use this in tight optimization loops.
    pub fn nll_reuse(&self, params: &[f64], scratch: &mut NllScratch) -> Result<f64> {
        // 1. Compute expected data into scratch (zero-alloc)
        self.model.expected_data_f64_fast_into(params, scratch)?;
        let expected = &mut scratch.expected[..self.n_main_bins];

        // 1b. NaN/Inf guard
        if expected.iter().any(|v| !v.is_finite()) {
            return Ok(f64::INFINITY);
        }

        // 2. Clamp expected >= EXPECTED_FLOOR
        #[cfg(feature = "accelerate")]
        if ns_compute::accelerate_enabled() {
            ns_compute::accelerate::clamp_expected_inplace(expected, EXPECTED_FLOOR);
        } else {
            for val in expected.iter_mut() {
                if *val < EXPECTED_FLOOR {
                    *val = EXPECTED_FLOOR;
                }
            }
        }
        #[cfg(not(feature = "accelerate"))]
        for val in expected.iter_mut() {
            if *val < EXPECTED_FLOOR {
                *val = EXPECTED_FLOOR;
            }
        }

        // 2b. Apply fit/validation mask
        if let Some(mask) = self.fit_bin_mask.as_ref() {
            debug_assert_eq!(mask.len(), expected.len());
            for (e, &m) in expected.iter_mut().zip(mask.iter()) {
                if m == 0.0 {
                    *e = 0.0;
                }
            }
        }

        // 3. Poisson NLL for main bins
        let mut nll = Self::dispatch_poisson_nll(
            expected,
            &self.observed_flat,
            &self.ln_factorials,
            &self.obs_mask,
            self.has_zero_obs,
            self.n_zero_obs,
            self.n_main_bins,
        );

        // 4. Barlow-Beeston auxiliary constraints
        for channel in &self.model.channels {
            for constraint in &channel.auxiliary_data {
                if let Some(sample) = channel.samples.get(constraint.sample_idx)
                    && let Some(ModelModifier::ShapeSys { param_indices, .. }) =
                        sample.modifiers.get(constraint.modifier_idx)
                {
                    for ((&tau, &obs_aux), &gamma_idx) in constraint
                        .tau
                        .iter()
                        .zip(constraint.observed.iter())
                        .zip(param_indices.iter())
                    {
                        let gamma = params.get(gamma_idx).copied().ok_or_else(|| {
                            ns_core::Error::Validation(format!(
                                "ShapeSys gamma index out of range in aux constraint: idx={} len={}",
                                gamma_idx,
                                params.len()
                            ))
                        })?;
                        let exp_aux = (gamma * tau).max(EXPECTED_FLOOR);

                        if obs_aux > 0.0 {
                            let ln_factorial = Self::ln_factorial_static(obs_aux);
                            nll += exp_aux - obs_aux * exp_aux.ln() + ln_factorial;
                        } else {
                            nll += exp_aux;
                        }
                    }
                }
            }
        }

        // 5. Gaussian constraints
        for (param_idx, param) in self.model.parameters.iter().enumerate() {
            // Match `nll_generic` constraint semantics.
            match &param.constraint_term {
                Some(ConstraintTerm::Uniform) | Some(ConstraintTerm::NoConstraint) => {
                    continue;
                }
                Some(ConstraintTerm::Gamma { rel }) if *rel > 0.0 => {
                    let beta = params.get(param_idx).copied().ok_or_else(|| {
                        ns_core::Error::Validation(format!(
                            "Constrained parameter index out of range: idx={} len={}",
                            param_idx,
                            params.len()
                        ))
                    })?;
                    let beta = beta.max(EXPECTED_FLOOR);

                    let tau = 1.0 / (*rel * *rel);
                    let k = tau + 1.0;
                    let theta = 1.0 / tau;
                    let c = k * theta.ln() + ln_gamma(k);
                    let term = beta * (1.0 / theta) - (k - 1.0) * beta.ln() + c;
                    nll += term;
                    continue;
                }
                _ => {}
            }

            if !param.constrained {
                continue;
            }
            if let (Some(center), Some(width)) = (param.constraint_center, param.constraint_width)
                && width > 0.0
            {
                let value = params.get(param_idx).copied().ok_or_else(|| {
                    ns_core::Error::Validation(format!(
                        "Constrained parameter index out of range: idx={} len={}",
                        param_idx,
                        params.len()
                    ))
                })?;
                let pull = (value - center) / width;
                nll += 0.5 * pull * pull;
            }
        }

        // 6. Add pre-computed constraint normalization constant
        nll += self.constraint_const;

        Ok(nll)
    }

    /// Compute ∂NLL/∂nominal for a specific channel/sample (main bins), reusing scratch buffers.
    ///
    /// Intended for ML integrations where a network produces the nominal yields vector for one
    /// sample. The derivative is a partial derivative holding `params` fixed, which is the
    /// correct gradient for profiled objectives via the envelope theorem.
    ///
    /// See [`HistFactoryModel::validate_sample_nominal_override_linear_safe`] for supported
    /// modifier restrictions.
    pub fn grad_nll_wrt_sample_nominal_main_reuse(
        &self,
        params: &[f64],
        scratch: &mut NllScratch,
        channel_idx: usize,
        sample_idx: usize,
        out: &mut [f64],
    ) -> Result<f64> {
        let nll = self.nll_reuse(params, scratch)?;

        let n_bins = self.model.channel_bin_count(channel_idx)?;
        if out.len() != n_bins {
            return Err(ns_core::Error::Validation(format!(
                "out length mismatch: expected {}, got {}",
                n_bins,
                out.len()
            )));
        }

        let offset = self.model.channel_bin_offset(channel_idx)?;
        let expected = &scratch.expected[..self.n_main_bins];

        // Reuse scratch.sample_factors as a local factor buffer for the selected sample.
        self.model.fill_sample_multiplicative_factors_main(
            params,
            channel_idx,
            sample_idx,
            &mut scratch.sample_factors[..n_bins],
        )?;
        let factors = &scratch.sample_factors[..n_bins];

        for i in 0..n_bins {
            let flat = offset + i;

            if let Some(mask) = self.fit_bin_mask.as_ref()
                && mask.get(flat).copied().unwrap_or(0.0) == 0.0
            {
                out[i] = 0.0;
                continue;
            }

            let e = expected.get(flat).copied().unwrap_or(0.0);
            if e <= 0.0 {
                out[i] = 0.0;
                continue;
            }
            let n = self.observed_flat.get(flat).copied().unwrap_or(0.0);
            let d_nll_d_e = if n > 0.0 { 1.0 - n / e } else { 1.0 };
            out[i] = d_nll_d_e * factors[i];
        }

        Ok(nll)
    }

    /// Static version of ln_factorial for use in PreparedModel.
    #[inline]
    fn ln_factorial_static(n: f64) -> f64 {
        ln_gamma(n + 1.0)
    }

    /// Dispatch Poisson NLL to the appropriate backend based on EvalMode.
    ///
    /// - Parity: Kahan summation (SIMD or scalar), Accelerate disabled.
    /// - Fast: SIMD/Accelerate with naive summation (default).
    #[inline]
    fn dispatch_poisson_nll(
        expected: &[f64],
        observed: &[f64],
        ln_factorials: &[f64],
        obs_mask: &[f64],
        has_zero_obs: bool,
        n_zero_obs: usize,
        n_main_bins: usize,
    ) -> f64 {
        use ns_compute::EvalMode;

        match ns_compute::eval_mode() {
            EvalMode::Parity => {
                // Kahan compensated summation — deterministic, high precision
                use ns_compute::simd::{poisson_nll_simd_kahan, poisson_nll_simd_sparse_kahan};
                if has_zero_obs {
                    poisson_nll_simd_sparse_kahan(expected, observed, ln_factorials, obs_mask)
                } else {
                    poisson_nll_simd_kahan(expected, observed, ln_factorials, obs_mask)
                }
            }
            EvalMode::Fast => {
                // Fast path: dispatch to Accelerate or SIMD
                #[cfg(feature = "accelerate")]
                if ns_compute::accelerate_enabled() {
                    return ns_compute::accelerate::poisson_nll_accelerate(
                        expected,
                        observed,
                        ln_factorials,
                        obs_mask,
                    );
                }
                // SIMD/scalar fallback
                use ns_compute::simd::{
                    poisson_nll_scalar_sparse, poisson_nll_simd, poisson_nll_simd_sparse,
                };
                if has_zero_obs {
                    let zero_frac = (n_zero_obs as f64) / (n_main_bins as f64).max(1.0);
                    if zero_frac >= 0.50 {
                        poisson_nll_scalar_sparse(expected, observed, ln_factorials, obs_mask)
                    } else {
                        poisson_nll_simd_sparse(expected, observed, ln_factorials, obs_mask)
                    }
                } else {
                    poisson_nll_simd(expected, observed, ln_factorials, obs_mask)
                }
            }
        }
    }
}

impl PreparedNll for PreparedModel<'_> {
    fn nll(&self, params: &[f64]) -> Result<f64> {
        PreparedModel::nll(self, params)
    }
}

impl LogDensityModel for HistFactoryModel {
    type Prepared<'a>
        = PreparedModel<'a>
    where
        Self: 'a;

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn parameter_names(&self) -> Vec<String> {
        self.parameters().iter().map(|p| p.name.clone()).collect()
    }

    fn parameter_bounds(&self) -> Vec<(f64, f64)> {
        self.parameters().iter().map(|p| p.bounds).collect()
    }

    fn parameter_init(&self) -> Vec<f64> {
        self.parameters().iter().map(|p| p.init).collect()
    }

    fn nll(&self, params: &[f64]) -> Result<f64> {
        HistFactoryModel::nll(self, params)
    }

    fn grad_nll(&self, params: &[f64]) -> Result<Vec<f64>> {
        HistFactoryModel::gradient_reverse(self, params)
    }

    fn prepared(&self) -> Self::Prepared<'_> {
        self.prepare()
    }
}

impl PoiModel for HistFactoryModel {
    fn poi_index(&self) -> Option<usize> {
        HistFactoryModel::poi_index(self)
    }
}

impl FixedParamModel for HistFactoryModel {
    fn with_fixed_param(&self, param_idx: usize, value: f64) -> Self {
        HistFactoryModel::with_fixed_param(self, param_idx, value)
    }
}

fn normsys_code4_coeffs(hi: f64, lo: f64) -> [f64; 6] {
    // From pyhf.interpolators.code4 with alpha0=1.
    const A_INV: [[f64; 6]; 6] = [
        [15.0 / 16.0, -15.0 / 16.0, -7.0 / 16.0, -7.0 / 16.0, 1.0 / 16.0, -1.0 / 16.0],
        [3.0 / 2.0, 3.0 / 2.0, -9.0 / 16.0, 9.0 / 16.0, 1.0 / 16.0, 1.0 / 16.0],
        [-5.0 / 8.0, 5.0 / 8.0, 5.0 / 8.0, 5.0 / 8.0, -1.0 / 8.0, 1.0 / 8.0],
        [-3.0 / 2.0, -3.0 / 2.0, 7.0 / 8.0, -7.0 / 8.0, -1.0 / 8.0, -1.0 / 8.0],
        [3.0 / 16.0, -3.0 / 16.0, -3.0 / 16.0, -3.0 / 16.0, 1.0 / 16.0, -1.0 / 16.0],
        [1.0 / 2.0, 1.0 / 2.0, -5.0 / 16.0, 5.0 / 16.0, 1.0 / 16.0, 1.0 / 16.0],
    ];

    let b0 = hi - 1.0;
    let b1 = lo - 1.0;
    let b2 = hi * hi.ln();
    let b3 = -lo * lo.ln();
    let b4 = hi * hi.ln().powi(2);
    let b5 = lo * lo.ln().powi(2);
    let b = [b0, b1, b2, b3, b4, b5];

    let mut a = [0.0; 6];
    for r in 0..6 {
        let mut s = 0.0;
        for c in 0..6 {
            s += A_INV[r][c] * b[c];
        }
        a[r] = s;
    }
    a
}

/// pyhf interpolators: normsys `code1` (exponential). pyhf default for normsys.
///
/// factor = hi^alpha (alpha >= 0) or lo^(-alpha) (alpha < 0).
/// Equivalent to: exp(alpha * ln(hi)) or exp(-alpha * ln(lo)).
fn normsys_code1<T: Scalar>(alpha: T, hi: f64, lo: f64) -> T {
    // Guard against invalid factors (hi <= 0 or lo <= 0).
    if hi <= 0.0 || lo <= 0.0 {
        let alpha_val = alpha.value();
        return if alpha_val >= 0.0 {
            T::from_f64(1.0) + alpha * T::from_f64(hi - 1.0)
        } else {
            T::from_f64(1.0) - alpha * T::from_f64(1.0 - lo)
        };
    }

    let alpha_val = alpha.value();
    if alpha_val >= 0.0 {
        // hi^alpha = exp(alpha * ln(hi))
        (alpha * T::from_f64(hi.ln())).exp()
    } else {
        // lo^(-alpha) = exp(-alpha * ln(lo))
        let neg_alpha = T::from_f64(0.0) - alpha;
        (neg_alpha * T::from_f64(lo.ln())).exp()
    }
}

/// pyhf interpolators: normsys `code4` (alpha0=1), specialized for scalar factors.
fn normsys_code4<T: Scalar>(alpha: T, hi: f64, lo: f64) -> T {
    // Guard against invalid factors.
    if hi <= 0.0 || lo <= 0.0 {
        let alpha_val = alpha.value();
        return if alpha_val >= 0.0 {
            T::from_f64(1.0) + alpha * T::from_f64(hi - 1.0)
        } else {
            T::from_f64(1.0) - alpha * T::from_f64(1.0 - lo)
        };
    }

    let alpha_val = alpha.value();
    if alpha_val.abs() >= 1.0 {
        let base = if alpha_val >= 0.0 { hi } else { lo };
        // base^{|alpha|} = exp(|alpha| * ln(base))
        return (alpha.abs() * T::from_f64(base.ln())).exp();
    }

    let coeffs = normsys_code4_coeffs(hi, lo);
    let a1 = alpha;
    let a2 = alpha.powi(2);
    let a3 = alpha.powi(3);
    let a4 = alpha.powi(4);
    let a5 = alpha.powi(5);
    let a6 = alpha.powi(6);

    T::from_f64(1.0)
        + T::from_f64(coeffs[0]) * a1
        + T::from_f64(coeffs[1]) * a2
        + T::from_f64(coeffs[2]) * a3
        + T::from_f64(coeffs[3]) * a4
        + T::from_f64(coeffs[4]) * a5
        + T::from_f64(coeffs[5]) * a6
}

/// pyhf interpolators: histosys `code0` (piecewise linear) delta term (added to nominal).
fn histosys_code0_delta<T: Scalar>(alpha: T, down: T, nom: T, up: T) -> T {
    if alpha.value() >= 0.0 { (up - nom) * alpha } else { (nom - down) * alpha }
}

/// pyhf interpolators: histosys `code2` (quadratic interp + linear extrap) delta term.
///
/// S = (up - down) / 2, A = (up + down) / 2 - nom.
/// |α| ≤ 1: δ = α·S + α²·A (quadratic).
/// α > 1:  δ = α·S + (2α−1)·A (linear extrapolation).
/// α < −1: δ = α·S + (−2α−1)·A (linear extrapolation).
fn histosys_code2_delta<T: Scalar>(alpha: T, down: T, nom: T, up: T) -> T {
    let s = (up - down) * T::from_f64(0.5);
    let a = (up + down) * T::from_f64(0.5) - nom;
    let alpha_val = alpha.value();
    if alpha_val.abs() <= 1.0 {
        alpha * s + alpha * alpha * a
    } else if alpha_val > 1.0 {
        alpha * s + (alpha * T::from_f64(2.0) - T::from_f64(1.0)) * a
    } else {
        // alpha < -1
        alpha * s + (alpha * T::from_f64(-2.0) - T::from_f64(1.0)) * a
    }
}

/// pyhf interpolators: histosys `code4p` delta term (added to nominal).
fn histosys_code4p_delta<T: Scalar>(alpha: T, down: T, nom: T, up: T) -> T {
    let alpha_val = alpha.value();
    let delta_up = up - nom;
    let delta_dn = nom - down;

    if alpha_val > 1.0 {
        return delta_up * alpha;
    }
    if alpha_val < -1.0 {
        return delta_dn * alpha;
    }

    let half = T::from_f64(0.5);
    let a_const = T::from_f64(0.0625);
    let s = half * (delta_up + delta_dn);
    let a = a_const * (delta_up - delta_dn);

    let asq = alpha * alpha;
    let tmp1 = asq * T::from_f64(3.0) - T::from_f64(10.0);
    let tmp2 = asq * tmp1 + T::from_f64(15.0);
    let tmp3 = asq * tmp2;

    alpha * s + tmp3 * a
}

fn normsys_code4_on_tape(
    tape: &mut ns_ad::tape::Tape,
    alpha: ns_ad::tape::Var,
    hi: f64,
    lo: f64,
) -> ns_ad::tape::Var {
    type Var = ns_ad::tape::Var;

    if hi <= 0.0 || lo <= 0.0 {
        let alpha_val = tape.val(alpha);
        return if alpha_val >= 0.0 {
            let delta = tape.constant(hi - 1.0);
            let ad = tape.mul(alpha, delta);
            tape.add_f64(ad, 1.0)
        } else {
            let delta = tape.constant(1.0 - lo);
            let ad = tape.mul(alpha, delta);
            tape.f64_sub(1.0, ad)
        };
    }

    let alpha_val = tape.val(alpha);
    if alpha_val.abs() >= 1.0 {
        let base = if alpha_val >= 0.0 { hi } else { lo };
        let ln_base = tape.constant(base.ln());
        let neg_alpha = tape.neg(alpha);
        let abs_alpha = tape.max(alpha, neg_alpha);
        let prod = tape.mul(abs_alpha, ln_base);
        return tape.exp(prod);
    }

    let coeffs = normsys_code4_coeffs(hi, lo);
    let mut out: Var = tape.constant(1.0);

    let a1 = alpha;
    let a2 = tape.powi(alpha, 2);
    let a3 = tape.powi(alpha, 3);
    let a4 = tape.powi(alpha, 4);
    let a5 = tape.powi(alpha, 5);
    let a6 = tape.powi(alpha, 6);

    let t1 = tape.mul_f64(a1, coeffs[0]);
    out = tape.add(out, t1);
    let t2 = tape.mul_f64(a2, coeffs[1]);
    out = tape.add(out, t2);
    let t3 = tape.mul_f64(a3, coeffs[2]);
    out = tape.add(out, t3);
    let t4 = tape.mul_f64(a4, coeffs[3]);
    out = tape.add(out, t4);
    let t5 = tape.mul_f64(a5, coeffs[4]);
    out = tape.add(out, t5);
    let t6 = tape.mul_f64(a6, coeffs[5]);
    out = tape.add(out, t6);

    out
}

fn normsys_code1_on_tape(
    tape: &mut ns_ad::tape::Tape,
    alpha: ns_ad::tape::Var,
    hi: f64,
    lo: f64,
) -> ns_ad::tape::Var {
    if hi <= 0.0 || lo <= 0.0 {
        let alpha_val = tape.val(alpha);
        return if alpha_val >= 0.0 {
            let delta = tape.constant(hi - 1.0);
            let ad = tape.mul(alpha, delta);
            tape.add_f64(ad, 1.0)
        } else {
            let delta = tape.constant(1.0 - lo);
            let ad = tape.mul(alpha, delta);
            tape.f64_sub(1.0, ad)
        };
    }

    let alpha_val = tape.val(alpha);
    if alpha_val >= 0.0 {
        // hi^alpha = exp(alpha * ln(hi))
        let ln_hi = tape.constant(hi.ln());
        let prod = tape.mul(alpha, ln_hi);
        tape.exp(prod)
    } else {
        // lo^(-alpha) = exp(-alpha * ln(lo))
        let neg_alpha = tape.neg(alpha);
        let ln_lo = tape.constant(lo.ln());
        let prod = tape.mul(neg_alpha, ln_lo);
        tape.exp(prod)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use approx::assert_relative_eq;
    use proptest::prelude::*;

    #[test]
    fn test_model_from_simple_workspace() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();

        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        // mu + 2 shapesys gamma parameters (2 bins)
        assert_eq!(model.n_params(), 3);
        assert_eq!(model.poi_index(), Some(0));
    }

    #[test]
    fn test_model_validates_parameter_length_and_does_not_panic() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();
        let n = model.n_params();

        // Too short
        let short = vec![1.0; n.saturating_sub(1)];
        assert!(model.nll(&short).is_err());
        assert!(model.expected_data(&short).is_err());
        assert!(model.expected_data_pyhf_main(&short).is_err());
        assert!(model.expected_data_pyhf(&short).is_err());
        assert!(model.gradient(&short).is_err());
        assert!(model.gradient_ad(&short).is_err());
        assert!(model.gradient_reverse(&short).is_err());

        // Too long
        let long = vec![1.0; n + 1];
        assert!(model.nll(&long).is_err());
        assert!(model.expected_data(&long).is_err());
        assert!(model.expected_data_pyhf_main(&long).is_err());
        assert!(model.expected_data_pyhf(&long).is_err());
        assert!(model.gradient(&long).is_err());
        assert!(model.gradient_ad(&long).is_err());
        assert!(model.gradient_reverse(&long).is_err());
    }

    #[test]
    fn test_runtime_rejects_corrupted_internal_param_indices() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        // Deliberately corrupt an internal modifier index to ensure runtime paths return
        // a validation error (never panic, never silently fall back).
        let mut corrupted = model.clone();
        let bad = corrupted.n_params() + 10;

        let mut changed = false;
        for channel in &mut corrupted.channels {
            for sample in &mut channel.samples {
                for m in &mut sample.modifiers {
                    if let ModelModifier::ShapeSys { param_indices, .. } = m
                        && !param_indices.is_empty()
                    {
                        param_indices[0] = bad;
                        changed = true;
                        break;
                    }
                }
                if changed {
                    break;
                }
            }
            if changed {
                break;
            }
        }
        assert!(changed, "expected to find a ShapeSys modifier to corrupt");

        let params = vec![1.0; model.n_params()];
        assert!(corrupted.expected_data(&params).is_err());
        assert!(corrupted.nll(&params).is_err());
        assert!(corrupted.expected_data_pyhf(&params).is_err());
        assert!(corrupted.prepared().nll(&params).is_err());
    }

    #[test]
    fn test_model_parameter_names() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let names: Vec<_> = model.parameters().iter().map(|p| &p.name).collect();
        assert!(names.contains(&&"mu".to_string()));
    }

    #[test]
    fn test_expected_data_nominal() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        // At nominal values (mu=1, all gammas=1)
        let params = vec![1.0; model.n_params()];
        let expected = model.expected_data(&params).unwrap();

        // signal(mu=1) + background = 5+50, 10+60
        assert_eq!(expected.len(), 2);
        assert_relative_eq!(expected[0], 55.0, epsilon = 1e-6);
        assert_relative_eq!(expected[1], 70.0, epsilon = 1e-6);
    }

    #[test]
    fn test_expected_data_varied_poi() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        // mu=2.0, gammas=1.0
        let mut params = vec![1.0; model.n_params()];
        params[0] = 2.0; // POI

        let expected = model.expected_data(&params).unwrap();

        // signal(mu=2) + background = 10+50, 20+60
        assert_relative_eq!(expected[0], 60.0, epsilon = 1e-6);
        assert_relative_eq!(expected[1], 80.0, epsilon = 1e-6);
    }

    #[test]
    fn test_complex_workspace_parsing() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        // Should have: mu, lumi, ttbar_norm (normsys), bkg_shape (histosys),
        // shapefactor_CR (2 bins), staterror_SR (2 bins)
        assert_eq!(model.n_params(), 8);
        assert_eq!(model.poi_index(), Some(0));

        let names: Vec<_> = model.parameters().iter().map(|p| &p.name).collect();
        assert!(names.iter().any(|&n| n == "shapefactor_CR[0]"));
        assert!(names.iter().any(|&n| n == "shapefactor_CR[1]"));
        assert!(names.iter().any(|&n| n == "staterror_SR[0]"));
        assert!(names.iter().any(|&n| n == "staterror_SR[1]"));
    }

    #[test]
    fn test_complex_expected_data() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        // At nominal init values
        let params = model.parameters().iter().map(|p| p.init).collect::<Vec<_>>();
        let expected = model.expected_data(&params).unwrap();

        // Should have data for SR (2 bins) + CR (2 bins) = 4 bins
        assert_eq!(expected.len(), 4);

        // `HistFactoryModel` uses pyhf ordering for main bins: channels are sorted
        // lexicographically, so CR comes before SR for this fixture.
        assert_eq!(model.channels[0].name, "CR");
        assert_eq!(model.channels[1].name, "SR");

        // CR: background(500,510) at nominal with shapefactor
        assert!(expected[0] > 450.0 && expected[0] < 550.0, "CR bin 0: {}", expected[0]);
        assert!(expected[1] > 450.0 && expected[1] < 550.0, "CR bin 1: {}", expected[1]);

        // SR expected depends on modifiers applied; check reasonable values.
        assert!(expected[2] > 100.0 && expected[2] < 150.0, "SR bin 0: {}", expected[2]);
        assert!(expected[3] > 100.0 && expected[3] < 150.0, "SR bin 1: {}", expected[3]);
    }

    #[test]
    fn test_nominal_override_allows_shapefactor_and_factors_match() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let ch = model.channel_index("CR").expect("CR channel should exist");
        let s = model.sample_index(ch, "background").expect("CR/background sample should exist");

        model
            .validate_sample_nominal_override_linear_safe(ch, s)
            .expect("shapefactor + lumi should be allowed for nominal override");

        let mut params = model.parameters().iter().map(|p| p.init).collect::<Vec<_>>();

        let mut idx_lumi = None;
        let mut idx_sf0 = None;
        let mut idx_sf1 = None;
        for (i, p) in model.parameters().iter().enumerate() {
            match p.name.as_str() {
                "lumi" => idx_lumi = Some(i),
                "shapefactor_CR[0]" => idx_sf0 = Some(i),
                "shapefactor_CR[1]" => idx_sf1 = Some(i),
                _ => {}
            }
        }
        let idx_lumi = idx_lumi.expect("lumi param should exist");
        let idx_sf0 = idx_sf0.expect("shapefactor_CR[0] param should exist");
        let idx_sf1 = idx_sf1.expect("shapefactor_CR[1] param should exist");

        params[idx_lumi] = 1.1;
        params[idx_sf0] = 1.2;
        params[idx_sf1] = 0.8;

        let n_bins = model.channel_bin_count(ch).unwrap();
        assert_eq!(n_bins, 2);

        let mut out = vec![0.0; n_bins];
        model.fill_sample_multiplicative_factors_main(&params, ch, s, &mut out).unwrap();

        assert_relative_eq!(out[0], 1.1 * 1.2, epsilon = 1e-12);
        assert_relative_eq!(out[1], 1.1 * 0.8, epsilon = 1e-12);
    }

    #[test]
    fn test_complex_nll_matches_pyhf_nominal() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let params = model.parameters().iter().map(|p| p.init).collect::<Vec<_>>();
        let nll = model.nll(&params).unwrap();

        // Reference from `python tests/validate_pyhf_nll.py` (pyhf 0.7.6)
        let pyhf_nll = 10.806852096216474;
        let diff = (nll - pyhf_nll).abs();
        assert!(
            diff < 1e-10,
            "Complex NLL mismatch: NextStat={:.15}, pyhf={:.15}, diff={:.3e}",
            nll,
            pyhf_nll,
            diff
        );
    }

    #[test]
    fn test_complex_nll_matches_pyhf_mu2() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let mut params = model.parameters().iter().map(|p| p.init).collect::<Vec<_>>();
        params[0] = 2.0; // mu is the POI and stored first
        let nll = model.nll(&params).unwrap();

        // Reference from pyhf 0.7.6 with POI (mu) set to 2.0 (others at suggested_init).
        let pyhf_nll = 12.192112756616737;
        let diff = (nll - pyhf_nll).abs();
        assert!(
            diff < 1e-10,
            "Complex NLL mismatch (mu=2): NextStat={:.15}, pyhf={:.15}, diff={:.3e}",
            nll,
            pyhf_nll,
            diff
        );
    }

    #[test]
    fn test_nll_at_nominal() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        // At nominal parameters (mu=1, gammas=1)
        let params = vec![1.0; model.n_params()];
        let nll = model.nll(&params).unwrap();

        // NLL should be finite and positive (with factorial term)
        assert!(nll.is_finite(), "NLL should be finite: {}", nll);
        assert!(nll > 0.0, "NLL should be positive: {}", nll);

        // Validate against pyhf reference with strict tolerance
        let pyhf_nll = 12.577579332147025;
        let diff = (nll - pyhf_nll).abs();
        let tolerance = 1e-10;

        assert!(
            diff < tolerance,
            "NLL mismatch: NextStat={:.10}, pyhf={:.10}, diff={:.10} (tolerance={})",
            nll,
            pyhf_nll,
            diff,
            tolerance
        );
    }

    #[test]
    fn test_nll_varied_poi() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        // At mu=0 (no signal)
        let mut params = vec![1.0; model.n_params()];
        params[0] = 0.0;
        let nll_0 = model.nll(&params).unwrap();

        // At mu=1 (nominal signal)
        params[0] = 1.0;
        let nll_1 = model.nll(&params).unwrap();

        // At mu=2 (double signal)
        params[0] = 2.0;
        let nll_2 = model.nll(&params).unwrap();

        // NLL should change with POI
        assert_ne!(nll_0, nll_1);
        assert_ne!(nll_1, nll_2);

        // All should be finite
        assert!(nll_0.is_finite());
        assert!(nll_1.is_finite());
        assert!(nll_2.is_finite());
    }

    #[test]
    fn test_nll_with_constraints() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        // At nominal (all params at constraint center/init)
        let params_nominal = model
            .parameters()
            .iter()
            .map(|p| if p.constrained { p.constraint_center.unwrap_or(p.init) } else { p.init })
            .collect::<Vec<_>>();
        let nll_nominal = model.nll(&params_nominal).unwrap();

        // Pull one constrained parameter away from center
        let mut params_pulled = params_nominal.clone();
        // Find first constrained parameter
        if let Some(idx) = model.parameters().iter().position(|p| p.constrained) {
            params_pulled[idx] += 1.0; // +1 sigma pull
            let nll_pulled = model.nll(&params_pulled).unwrap();

            // NLL should increase when pulling constrained parameter
            // (includes both Gaussian constraint and Poisson likelihood change)
            assert!(
                nll_pulled > nll_nominal,
                "NLL should increase with constraint violation: {} > {}",
                nll_pulled,
                nll_nominal
            );

            // Difference should be positive (can be large due to Poisson term)
            let diff = nll_pulled - nll_nominal;
            assert!(diff > 0.0, "NLL difference should be positive: {}", diff);
        }
    }

    #[test]
    fn test_nll_deterministic() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let params = vec![1.5, 1.0, 1.0];

        // Compute NLL multiple times
        let nll1 = model.nll(&params).unwrap();
        let nll2 = model.nll(&params).unwrap();
        let nll3 = model.nll(&params).unwrap();

        // Should be exactly the same (deterministic)
        assert_eq!(nll1, nll2);
        assert_eq!(nll2, nll3);
    }

    #[test]
    fn test_with_observed_main_updates_nll() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let params = vec![1.0; model.n_params()];
        let nll_nominal = model.nll(&params).unwrap();

        // Bump observations by +1 per bin.
        let obs =
            ws.observations.first().unwrap().data.iter().map(|&x| x + 1.0).collect::<Vec<_>>();

        // The simple workspace has only main bins in observations.
        let bumped = model.with_observed_main(&obs).unwrap();
        let nll_bumped = bumped.nll(&params).unwrap();

        assert_ne!(nll_nominal, nll_bumped);

        // Original model remains unchanged.
        let nll_nominal_again = model.nll(&params).unwrap();
        assert_eq!(nll_nominal, nll_nominal_again);

        // Sanity: method is deterministic.
        let nll_bumped_again = bumped.nll(&params).unwrap();
        assert_eq!(nll_bumped, nll_bumped_again);
    }

    #[test]
    fn test_with_observed_main_length_mismatch() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let err = model.with_observed_main(&[1.0]).unwrap_err();
        let msg = err.to_string();
        assert!(msg.contains("length mismatch"), "unexpected error: {}", msg);
    }

    #[test]
    fn test_gradient_computation() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let params = vec![1.0; model.n_params()];
        let grad = model.gradient(&params).unwrap();

        println!("Gradient at nominal: {:?}", grad);

        // Gradient should have correct length
        assert_eq!(grad.len(), model.n_params());

        // All gradient components should be finite
        for (i, &g) in grad.iter().enumerate() {
            assert!(g.is_finite(), "Gradient[{}] is not finite: {}", i, g);
        }

        // Test gradient changes with parameters
        let params2 = vec![1.5, 1.0, 1.0];
        let grad2 = model.gradient(&params2).unwrap();

        // Gradient at different point should differ
        assert_ne!(grad[0], grad2[0], "Gradient should change with parameters");
    }

    #[test]
    fn test_gradient_vs_finite_difference() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let params = vec![1.2, 0.9, 1.1];
        let grad = model.gradient(&params).unwrap();

        // Manual finite difference for first parameter
        let eps = 1e-8_f64.sqrt();
        let mut params_plus = params.clone();
        params_plus[0] += eps;
        let f_plus = model.nll(&params_plus).unwrap();

        let mut params_minus = params.clone();
        params_minus[0] -= eps;
        let f_minus = model.nll(&params_minus).unwrap();

        let grad_manual = (f_plus - f_minus) / (2.0 * eps);

        println!("Gradient[0] computed: {}", grad[0]);
        println!("Gradient[0] manual:   {}", grad_manual);

        // Should match within numerical tolerance
        assert_relative_eq!(grad[0], grad_manual, epsilon = 1e-5);
    }

    #[test]
    fn test_gradient_ad_matches_numerical() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let params = vec![1.2, 0.9, 1.1];

        let grad_num = model.gradient(&params).unwrap();
        let grad_ad = model.gradient_ad(&params).unwrap();

        println!("Numerical gradient: {:?}", grad_num);
        println!("AD gradient:        {:?}", grad_ad);

        assert_eq!(grad_ad.len(), grad_num.len());
        for (i, (&ad, &num)) in grad_ad.iter().zip(grad_num.iter()).enumerate() {
            let diff = (ad - num).abs();
            println!("  param[{}]: AD={:.10}, num={:.10}, diff={:.2e}", i, ad, num, diff);
            // AD should be more accurate than finite diff, so compare against it loosely
            assert_relative_eq!(ad, num, epsilon = 1e-5,);
        }
    }

    #[test]
    fn test_gradient_reverse_matches_forward() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let params = vec![1.2, 0.9, 1.1];

        let grad_fwd = model.gradient_ad(&params).unwrap();
        let grad_rev = model.gradient_reverse(&params).unwrap();

        println!("Forward AD:  {:?}", grad_fwd);
        println!("Reverse AD:  {:?}", grad_rev);

        assert_eq!(grad_rev.len(), grad_fwd.len());
        for (i, (&rev, &fwd)) in grad_rev.iter().zip(grad_fwd.iter()).enumerate() {
            let diff = (rev - fwd).abs();
            println!("  param[{}]: rev={:.12}, fwd={:.12}, diff={:.2e}", i, rev, fwd, diff);
            assert_relative_eq!(rev, fwd, epsilon = 1e-10);
        }
    }

    #[test]
    fn test_gradient_reverse_complex_workspace() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        let params: Vec<f64> = model
            .parameters()
            .iter()
            .map(|p| {
                let base =
                    if p.constrained { p.constraint_center.unwrap_or(p.init) } else { p.init };
                base + 0.01
            })
            .collect();

        let grad_fwd = model.gradient_ad(&params).unwrap();
        let grad_rev = model.gradient_reverse(&params).unwrap();

        println!("Complex workspace - {} parameters", params.len());
        for (i, (&rev, &fwd)) in grad_rev.iter().zip(grad_fwd.iter()).enumerate() {
            let diff = (rev - fwd).abs();
            println!(
                "  {}: rev={:.10}, fwd={:.10}, diff={:.2e}",
                model.parameters()[i].name,
                rev,
                fwd,
                diff
            );
            assert_relative_eq!(rev, fwd, epsilon = 1e-10);
        }
    }

    #[test]
    fn test_gradient_ad_complex_workspace() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();

        // Slightly perturb from init to avoid non-smooth switching points
        // (NormSys has branch at alpha=0 where finite-diff fails but AD is correct)
        let params: Vec<f64> = model
            .parameters()
            .iter()
            .map(|p| {
                let base =
                    if p.constrained { p.constraint_center.unwrap_or(p.init) } else { p.init };
                base + 0.01 // small offset away from branch points
            })
            .collect();

        let grad_num = model.gradient(&params).unwrap();
        let grad_ad = model.gradient_ad(&params).unwrap();

        println!("Complex workspace - {} parameters", params.len());
        for (i, (&ad, &num)) in grad_ad.iter().zip(grad_num.iter()).enumerate() {
            let diff = (ad - num).abs();
            println!(
                "  {}: AD={:.8}, num={:.8}, diff={:.2e}",
                model.parameters()[i].name,
                ad,
                num,
                diff
            );
            assert_relative_eq!(ad, num, epsilon = 1e-4);
        }
    }

    // ===== PreparedModel tests =====

    #[test]
    fn test_prepared_model_simple_matches_generic() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();
        let prepared = model.prepare();

        let params = vec![1.0; model.n_params()];
        let nll_generic = model.nll(&params).unwrap();
        let nll_prepared = prepared.nll(&params).unwrap();

        let diff = (nll_generic - nll_prepared).abs();
        assert!(
            diff < 1e-12,
            "PreparedModel NLL mismatch: generic={:.15}, prepared={:.15}, diff={:.3e}",
            nll_generic,
            nll_prepared,
            diff
        );
    }

    #[test]
    fn test_prepared_model_complex_matches_generic() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();
        let prepared = model.prepare();

        let params = model.parameters().iter().map(|p| p.init).collect::<Vec<_>>();
        let nll_generic = model.nll(&params).unwrap();
        let nll_prepared = prepared.nll(&params).unwrap();

        let diff = (nll_generic - nll_prepared).abs();
        assert!(
            diff < 1e-12,
            "PreparedModel NLL mismatch (complex): generic={:.15}, prepared={:.15}, diff={:.3e}",
            nll_generic,
            nll_prepared,
            diff
        );
    }

    #[test]
    fn test_prepared_model_complex_mu2_matches_generic() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();
        let prepared = model.prepare();

        let mut params = model.parameters().iter().map(|p| p.init).collect::<Vec<_>>();
        params[0] = 2.0;
        let nll_generic = model.nll(&params).unwrap();
        let nll_prepared = prepared.nll(&params).unwrap();

        let diff = (nll_generic - nll_prepared).abs();
        assert!(
            diff < 1e-12,
            "PreparedModel NLL mismatch (mu=2): generic={:.15}, prepared={:.15}, diff={:.3e}",
            nll_generic,
            nll_prepared,
            diff
        );
    }

    #[test]
    fn test_prepared_model_varied_params_matches_generic() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();
        let prepared = model.prepare();

        // Test at multiple parameter points
        let param_sets: Vec<Vec<f64>> = vec![
            model.parameters().iter().map(|p| p.init + 0.1).collect(),
            model.parameters().iter().map(|p| p.init - 0.05).collect(),
            model
                .parameters()
                .iter()
                .map(|p| {
                    let base =
                        if p.constrained { p.constraint_center.unwrap_or(p.init) } else { p.init };
                    base + 0.5
                })
                .collect(),
        ];

        for (idx, params) in param_sets.iter().enumerate() {
            let nll_generic = model.nll(params).unwrap();
            let nll_prepared = prepared.nll(params).unwrap();
            let diff = (nll_generic - nll_prepared).abs();
            assert!(
                diff < 1e-12,
                "PreparedModel NLL mismatch at param set {}: generic={:.15}, prepared={:.15}, diff={:.3e}",
                idx,
                nll_generic,
                nll_prepared,
                diff
            );
        }
    }

    #[test]
    fn test_prepared_model_preserves_pyhf_parity() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();
        let prepared = model.prepare();

        let params = model.parameters().iter().map(|p| p.init).collect::<Vec<_>>();
        let nll = prepared.nll(&params).unwrap();

        let pyhf_nll = 10.806852096216474;
        let diff = (nll - pyhf_nll).abs();
        assert!(
            diff < 1e-10,
            "PreparedModel pyhf parity: NextStat={:.15}, pyhf={:.15}, diff={:.3e}",
            nll,
            pyhf_nll,
            diff
        );
    }

    #[test]
    fn test_nll_reuse_bitexact_vs_nll_simple() {
        let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();
        let prepared = model.prepare();
        let mut scratch = NllScratch::for_model(&model);

        let param_sets: Vec<Vec<f64>> = vec![
            model.parameters().iter().map(|p| p.init).collect(),
            model.parameters().iter().map(|p| p.init + 0.1).collect(),
            model.parameters().iter().map(|p| p.init - 0.05).collect(),
        ];

        for (idx, params) in param_sets.iter().enumerate() {
            let nll_alloc = prepared.nll(params).unwrap();
            let nll_reuse = prepared.nll_reuse(params, &mut scratch).unwrap();
            assert_eq!(
                nll_alloc.to_bits(),
                nll_reuse.to_bits(),
                "nll_reuse not bit-exact (simple) at set {}: alloc={:.15}, reuse={:.15}",
                idx,
                nll_alloc,
                nll_reuse,
            );
        }
    }

    #[test]
    fn test_nll_reuse_bitexact_vs_nll_complex() {
        let json = include_str!("../../../../tests/fixtures/complex_workspace.json");
        let ws: Workspace = serde_json::from_str(json).unwrap();
        let model = HistFactoryModel::from_workspace(&ws).unwrap();
        let prepared = model.prepare();
        let mut scratch = NllScratch::for_model(&model);

        let param_sets: Vec<Vec<f64>> = vec![
            model.parameters().iter().map(|p| p.init).collect(),
            model.parameters().iter().map(|p| p.init + 0.1).collect(),
            model
                .parameters()
                .iter()
                .map(|p| {
                    let base =
                        if p.constrained { p.constraint_center.unwrap_or(p.init) } else { p.init };
                    base + 0.5
                })
                .collect(),
        ];

        for (idx, params) in param_sets.iter().enumerate() {
            let nll_alloc = prepared.nll(params).unwrap();
            let nll_reuse = prepared.nll_reuse(params, &mut scratch).unwrap();
            assert_eq!(
                nll_alloc.to_bits(),
                nll_reuse.to_bits(),
                "nll_reuse not bit-exact (complex) at set {}: alloc={:.15}, reuse={:.15}",
                idx,
                nll_alloc,
                nll_reuse,
            );
        }
    }

    proptest! {
        #![proptest_config(ProptestConfig { cases: 32, .. ProptestConfig::default() })]

        #[test]
        fn prop_gradient_reverse_matches_forward_simple(
            mu in 0.0f64..5.0,
            gamma0 in 0.1f64..2.0,
            gamma1 in 0.1f64..2.0,
        ) {
            let json = include_str!("../../../../tests/fixtures/simple_workspace.json");
            let ws: Workspace = serde_json::from_str(json).unwrap();
            let model = HistFactoryModel::from_workspace(&ws).unwrap();

            // Simple fixture is: mu + 2 gamma params
            prop_assert_eq!(model.n_params(), 3);

            let params = vec![mu, gamma0, gamma1];
            let grad_fwd = model.gradient_ad(&params).unwrap();
            let grad_rev = model.gradient_reverse(&params).unwrap();

            prop_assert_eq!(grad_fwd.len(), 3);
            prop_assert_eq!(grad_rev.len(), 3);

            for (a, b) in grad_fwd.iter().zip(grad_rev.iter()) {
                prop_assert!((a - b).abs() < 1e-9);
                prop_assert!(a.is_finite());
                prop_assert!(b.is_finite());
            }
        }
    }
}
