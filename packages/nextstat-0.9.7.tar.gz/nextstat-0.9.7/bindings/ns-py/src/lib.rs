//! Python bindings for NextStat
#![allow(clippy::too_many_arguments)]
#![allow(clippy::type_complexity)]
#![allow(clippy::needless_range_loop)]
#![allow(clippy::large_enum_variant)]
#![allow(clippy::identity_op)]
#![allow(clippy::overly_complex_bool_expr)]
#![allow(clippy::needless_update)]
#![allow(unused_parens)]

use pyo3::IntoPyObjectExt;
use pyo3::buffer::PyBuffer;
use pyo3::exceptions::PyValueError;
use pyo3::prelude::*;
use pyo3::types::{PyDict, PyList};
use pyo3::wrap_pyfunction;

use nalgebra::{DMatrix, DVector};
use std::collections::HashMap;
use std::sync::{Arc, Mutex};

// Re-export types from core crates
use ns_ad::tape::Tape as AdTape;
use ns_core::traits::{FixedParamModel, LogDensityModel, PoiModel, PreparedNll};
use ns_core::{Error as NsError, Result as NsResult};
use ns_inference::OptimizerConfig;
use ns_inference::chain::{Chain as RustChain, SamplerResult as RustSamplerResult};
use ns_inference::chain_ladder::{
    ClaimsTriangle, chain_ladder as rust_chain_ladder, mack_chain_ladder as rust_mack_chain_ladder,
};
use ns_inference::competing_risks::{
    cumulative_incidence as rust_cumulative_incidence, fine_gray_fit as rust_fine_gray_fit,
    gray_test as rust_gray_test,
};
use ns_inference::diagnostics::{QualityGates, compute_diagnostics, quality_summary};
use ns_inference::eight_schools::EightSchoolsModel as RustEightSchoolsModel;
use ns_inference::evt::{GevModel as RustGevModel, GpdModel as RustGpdModel};
use ns_inference::hybrid::{HybridLikelihood, SharedParameterMap};
use ns_inference::lmm::{
    LmmMarginalModel as RustLmmMarginalModel, RandomEffects as RustLmmRandomEffects,
};
use ns_inference::mams::{MamsConfig, sample_mams_multichain};
use ns_inference::meta_analysis::{
    StudyEffect as RustStudyEffect, meta_fixed as rust_meta_fixed, meta_random as rust_meta_random,
};
use ns_inference::mle::{MaximumLikelihoodEstimator as RustMLE, RankingEntry};
use ns_inference::nuts::{InitStrategy, MetricType, NutsConfig, sample_nuts};
use ns_inference::ode_pk::{
    MichaelisMentenPkOde, OdePkSolver, OdeSolverOptions, OdeSolverType, ParameterizedTransitOde,
    TmddOde, ode_pk_nll as rust_ode_pk_nll,
};
use ns_inference::optimizer::OptimizationResult as RustOptimizationResult;
use ns_inference::pd::{
    EmaxModel as RustEmaxModel, IndirectResponseModel as RustIndirectResponseModel,
    IndirectResponseType as RustIndirectResponseType, SigmoidEmaxModel as RustSigmoidEmaxModel,
};
use ns_inference::regression::NegativeBinomialRegressionModel as RustNegativeBinomialRegressionModel;
use ns_inference::timeseries::em::{
    KalmanEmConfig as RustKalmanEmConfig, kalman_em as rust_kalman_em,
};
use ns_inference::timeseries::forecast::{
    kalman_forecast as rust_kalman_forecast,
    kalman_forecast_intervals as rust_kalman_forecast_intervals,
};
use ns_inference::timeseries::kalman::{
    KalmanModel as RustKalmanModel, kalman_filter as rust_kalman_filter,
    rts_smoother as rust_rts_smoother,
};
use ns_inference::timeseries::simulate::{
    kalman_simulate as rust_kalman_simulate,
    kalman_simulate_with_x0 as rust_kalman_simulate_with_x0,
};
use ns_inference::timeseries::volatility::{
    Egarch11Config as RustEgarch11Config, Garch11Config as RustGarch11Config,
    GjrGarch11Config as RustGjrGarch11Config, SvLogChi2Config as RustSvLogChi2Config,
    egarch11_fit as rust_egarch11_fit, garch11_fit as rust_garch11_fit,
    gjr_garch11_fit as rust_gjr_garch11_fit, sv_logchi2_fit as rust_sv_logchi2_fit,
};
use ns_inference::transforms::ParameterTransform;
use ns_inference::tweedie::{
    GammaRegressionModel as RustGammaRegressionModel,
    TweedieRegressionModel as RustTweedieRegressionModel,
};
use ns_inference::{
    BeConfig as RustBeConfig, BeData as RustBeData, BeDesign as RustBeDesign,
    BePowerConfig as RustBePowerConfig, BootstrapCiMethod as RustBootstrapCiMethod,
    BootstrapSaemResult as RustBootstrapSaemResult, CensoringType as RustCensoringType,
    ComposedGlmModel as RustComposedGlmModel, CovRelationship as RustCovRelationship,
    CovariateCandidate as RustCovariateCandidate,
    CovariateRelationship as RustCovariateRelationship, CovariateSpec as RustCovariateSpec,
    CoxPhModel as RustCoxPhModel, CoxTies as RustCoxTies, DoseEvent as RustDoseEvent,
    DoseRoute as RustDoseRoute, DosingRegimen as RustDosingRegimen, ErrorModel as RustErrorModel,
    ExponentialSurvivalModel as RustExponentialSurvivalModel, FoceConfig as RustFoceConfig,
    FoceEstimator as RustFoceEstimator, ImpConfig as RustImpConfig,
    IntervalCensoredExponentialModel as RustIntervalCensoredExponentialModel,
    IntervalCensoredLogNormalModel as RustIntervalCensoredLogNormalModel,
    IntervalCensoredWeibullAftModel as RustIntervalCensoredWeibullAftModel,
    IntervalCensoredWeibullModel as RustIntervalCensoredWeibullModel, IovSpec as RustIovSpec,
    ItsConfig as RustItsConfig, LinearRegressionModel as RustLinearRegressionModel,
    LloqPolicy as RustLloqPolicy, LogNormalAftModel as RustLogNormalAftModel,
    LogisticRegressionModel as RustLogisticRegressionModel, MapConfig as RustMapConfig,
    MapResult as RustMapResult, ModelBuilder as RustModelBuilder,
    NonmemDataset as RustNonmemDataset, NpdeConfig as RustNpdeConfig,
    OmegaMatrix as RustOmegaMatrix, OneCompartmentOralPkModel as RustOneCompartmentOralPkModel,
    OneCompartmentOralPkNlmeModel as RustOneCompartmentOralPkNlmeModel,
    OrderedLogitModel as RustOrderedLogitModel, OrderedProbitModel as RustOrderedProbitModel,
    PkModelKind as RustPkModelKind, PkModelType as RustPkModelType,
    PoissonRegressionModel as RustPoissonRegressionModel,
    PopulationPkParams as RustPopulationPkParams, Posterior as RustPosterior, Prior as RustPrior,
    RandomEffectTransform as RustRandomEffectTransform, SaemConfig as RustSaemConfig,
    SaemEstimator as RustSaemEstimator, ScmConfig as RustScmConfig,
    ScmEstimator as RustScmEstimator, ThreeCompartmentIvPkModel as RustThreeCompartmentIvPkModel,
    ThreeCompartmentOralPkModel as RustThreeCompartmentOralPkModel,
    TimeCovariateInterpolation as RustTimeCovariateInterpolation,
    TimeVaryingCovariatePoint as RustTimeVaryingCovariatePoint,
    TimeVaryingCovariateSpec as RustTimeVaryingCovariateSpec, TrialConfig as RustTrialConfig,
    TrialErrorModelType as RustTrialErrorModelType,
    TwoCompartmentIvPkModel as RustTwoCompartmentIvPkModel,
    TwoCompartmentOralPkModel as RustTwoCompartmentOralPkModel, VpcConfig as RustVpcConfig,
    WeibullSurvivalModel as RustWeibullSurvivalModel, XptDataset as RustXptDataset,
    XptValue as RustXptValue, XptVarType as RustXptVarType, XptVariable as RustXptVariable,
    average_be as rust_average_be, be_power as rust_be_power,
    be_sample_size as rust_be_sample_size, bootstrap_saem as rust_bootstrap_saem,
    conc_iv_3cpt_macro, conc_oral_3cpt_macro, gof_pk as rust_gof_pk,
    hypotest::AsymptoticCLsContext as RustCLsCtx, map_estimate as rust_map_estimate,
    npde_pk as rust_npde_pk, ols_fit as rust_ols_fit, profile_likelihood as pl,
    simulate_trial as rust_simulate_trial, vpc_pk as rust_vpc_pk,
};
use ns_root::RootFile;
use ns_translate::histfactory::from_xml as histfactory_from_xml;
use ns_translate::pyhf::{
    ExpectedChannelSampleYields, ExpectedSampleYields, HistFactoryModel as RustModel,
    ObservedChannelData, Workspace as RustWorkspace,
};
use ns_unbinned::UnbinnedModel as RustUnbinnedModel;
use ns_unbinned::spec as unbinned_spec;

type RustHybridModel = HybridLikelihood<RustModel, RustUnbinnedModel>;
use ns_viz::{ClsCurveArtifact, ProfileCurveArtifact};

fn extract_f64_vec(obj: &Bound<'_, PyAny>) -> PyResult<Vec<f64>> {
    // Fast-path: accept any object supporting the Python buffer protocol (e.g. array('d'),
    // memoryview, numpy.ndarray). This avoids per-element Python float extraction for large
    // parameter vectors (e.g. shapesys gamma parameters per bin).
    if let Ok(buf) = PyBuffer::<f64>::get(obj) {
        if buf.dimensions() > 1 {
            return Err(PyValueError::new_err(
                "params buffer must be 1D (or scalar), got ndim > 1",
            ));
        }
        let n = buf.item_count();
        let mut out = vec![0.0f64; n];
        buf.copy_to_slice(obj.py(), &mut out)?;
        return Ok(out);
    }

    // Fallback: accept any Python sequence of floats.
    obj.extract::<Vec<f64>>()
}

fn sample_nuts_multichain_with_seeds(
    model: &(impl LogDensityModel),
    n_warmup: usize,
    n_samples: usize,
    seeds: &[u64],
    config: NutsConfig,
) -> NsResult<RustSamplerResult> {
    use rayon::prelude::*;
    let chains: Vec<NsResult<RustChain>> = seeds
        .par_iter()
        .map(|&seed| sample_nuts(model, n_warmup, n_samples, seed, config.clone()))
        .collect();
    let chains: Vec<RustChain> = chains.into_iter().collect::<NsResult<Vec<_>>>()?;
    Ok(RustSamplerResult {
        chains,
        param_names: model.parameter_names(),
        n_warmup,
        n_samples,
        diagnostics: None,
    })
}

fn sampler_result_to_py<'py>(
    py: Python<'py>,
    result: &RustSamplerResult,
    n_chains: usize,
    n_warmup: usize,
    n_samples: usize,
) -> PyResult<Py<PyAny>> {
    sampler_result_to_py_gates(py, result, n_chains, n_warmup, n_samples, false)
}

fn sampler_result_to_py_gates<'py>(
    py: Python<'py>,
    result: &RustSamplerResult,
    n_chains: usize,
    n_warmup: usize,
    n_samples: usize,
    microcanonical: bool,
) -> PyResult<Py<PyAny>> {
    let diag = compute_diagnostics(result);
    let param_names = &result.param_names;
    let n_params = param_names.len();

    // Build "posterior" dict: {param_name: [[chain0_draws], [chain1_draws], ...]}
    let posterior = PyDict::new(py);
    for (p, name) in param_names.iter().enumerate() {
        let chains_draws: Vec<Vec<f64>> = result.param_draws(p);
        posterior.set_item(name, chains_draws)?;
    }

    // Build "sample_stats" dict
    let sample_stats = PyDict::new(py);
    let diverging: Vec<Vec<bool>> = result.chains.iter().map(|c| c.divergences.clone()).collect();
    let tree_depth: Vec<Vec<usize>> = result.chains.iter().map(|c| c.tree_depths.clone()).collect();
    let accept_prob: Vec<Vec<f64>> = result.chains.iter().map(|c| c.accept_probs.clone()).collect();
    let energy: Vec<Vec<f64>> = result.chains.iter().map(|c| c.energies.clone()).collect();
    let step_sizes: Vec<f64> = result.chains.iter().map(|c| c.step_size).collect();
    let n_leapfrog: Vec<Vec<usize>> = result.chains.iter().map(|c| c.n_leapfrog.clone()).collect();
    sample_stats.set_item("diverging", diverging)?;
    sample_stats.set_item("tree_depth", tree_depth)?;
    sample_stats.set_item("accept_prob", accept_prob)?;
    sample_stats.set_item("energy", energy)?;
    sample_stats.set_item("step_size", step_sizes)?;
    sample_stats.set_item("n_leapfrog", n_leapfrog)?;

    // Metric info (from first chain; all chains share the same metric type)
    if let Some(c0) = result.chains.first() {
        sample_stats.set_item("metric_type", &c0.metric_type_name)?;
        if let Some(ref inv_mass) = c0.inv_mass_matrix {
            sample_stats.set_item("inv_mass_matrix", inv_mass.clone())?;
        }
        sample_stats.set_item("mass_diag", c0.mass_diag.clone())?;
    }

    // Build "diagnostics" dict
    let diagnostics_dict = PyDict::new(py);

    let r_hat_dict = PyDict::new(py);
    let ess_bulk_dict = PyDict::new(py);
    let ess_tail_dict = PyDict::new(py);
    for p in 0..n_params {
        r_hat_dict.set_item(&param_names[p], diag.r_hat[p])?;
        ess_bulk_dict.set_item(&param_names[p], diag.ess_bulk[p])?;
        ess_tail_dict.set_item(&param_names[p], diag.ess_tail[p])?;
    }
    diagnostics_dict.set_item("r_hat", r_hat_dict)?;
    diagnostics_dict.set_item("ess_bulk", ess_bulk_dict)?;
    diagnostics_dict.set_item("ess_tail", ess_tail_dict)?;
    diagnostics_dict.set_item("divergence_rate", diag.divergence_rate)?;
    diagnostics_dict.set_item("max_treedepth_rate", diag.max_treedepth_rate)?;
    diagnostics_dict.set_item("ebfmi", diag.ebfmi.clone())?;

    // Non-slow quality summary. Microcanonical samplers (MAMS/LAPS) use relaxed
    // EBFMI gates since low E-BFMI is expected for Sundman leapfrog dynamics.
    let gates =
        if microcanonical { QualityGates::microcanonical() } else { QualityGates::default() };
    let qs = quality_summary(&diag, n_chains, n_samples, &gates);
    let quality = PyDict::new(py);
    quality.set_item("status", qs.status.to_string())?;
    quality.set_item("enabled", qs.enabled)?;
    quality.set_item("warnings", qs.warnings)?;
    quality.set_item("failures", qs.failures)?;
    quality.set_item("total_draws", qs.total_draws)?;
    quality.set_item("max_r_hat", qs.max_r_hat)?;
    quality.set_item("min_ess_bulk", qs.min_ess_bulk)?;
    quality.set_item("min_ess_tail", qs.min_ess_tail)?;
    quality.set_item("min_ebfmi", qs.min_ebfmi)?;
    diagnostics_dict.set_item("quality", quality)?;

    // Assemble top-level dict
    let out = PyDict::new(py);
    out.set_item("posterior", posterior)?;
    out.set_item("sample_stats", sample_stats)?;
    out.set_item("diagnostics", diagnostics_dict)?;
    out.set_item("param_names", param_names)?;
    out.set_item("n_chains", n_chains)?;
    out.set_item("n_warmup", n_warmup)?;
    out.set_item("n_samples", n_samples)?;

    Ok(out.into_any().unbind())
}

fn dmatrix_from_nested(name: &str, rows: Vec<Vec<f64>>) -> PyResult<DMatrix<f64>> {
    if rows.is_empty() {
        return Err(PyValueError::new_err(format!("{name} must be non-empty")));
    }
    let nrows = rows.len();
    let ncols = rows[0].len();
    if ncols == 0 {
        return Err(PyValueError::new_err(format!("{name} rows must be non-empty")));
    }
    for (i, r) in rows.iter().enumerate() {
        if r.len() != ncols {
            return Err(PyValueError::new_err(format!(
                "{name} must be rectangular: row {i} has len {}, expected {}",
                r.len(),
                ncols
            )));
        }
        if r.iter().any(|v| !v.is_finite()) {
            return Err(PyValueError::new_err(format!("{name} must contain only finite values")));
        }
    }
    let mut flat = Vec::with_capacity(nrows * ncols);
    for r in rows {
        flat.extend_from_slice(&r);
    }
    Ok(DMatrix::from_row_slice(nrows, ncols, &flat))
}

fn dvector_from_vec(name: &str, v: Vec<f64>) -> PyResult<DVector<f64>> {
    if v.is_empty() {
        return Err(PyValueError::new_err(format!("{name} must be non-empty")));
    }
    if v.iter().any(|x| !x.is_finite()) {
        return Err(PyValueError::new_err(format!("{name} must contain only finite values")));
    }
    Ok(DVector::from_vec(v))
}

fn dvector_from_opt_vec(name: &str, v: Vec<Option<f64>>) -> PyResult<DVector<f64>> {
    if v.is_empty() {
        return Err(PyValueError::new_err(format!("{name} must be non-empty")));
    }
    let mut out = Vec::with_capacity(v.len());
    for x in v {
        match x {
            Some(v) if v.is_finite() => out.push(v),
            Some(_) => {
                return Err(PyValueError::new_err(format!(
                    "{name} must contain only finite values or None"
                )));
            }
            None => out.push(f64::NAN),
        }
    }
    Ok(DVector::from_vec(out))
}

fn dvector_to_vec(v: &DVector<f64>) -> Vec<f64> {
    v.iter().copied().collect()
}

fn dmatrix_to_nested(m: &DMatrix<f64>) -> Vec<Vec<f64>> {
    let nrows = m.nrows();
    let ncols = m.ncols();
    let mut out = Vec::with_capacity(nrows);
    for i in 0..nrows {
        let mut row = Vec::with_capacity(ncols);
        for j in 0..ncols {
            row.push(m[(i, j)]);
        }
        out.push(row);
    }
    out
}

// ---------------------------------------------------------------------------
// Bayesian posterior surface (Phase 3/5 standards: explicit Posterior API).
// ---------------------------------------------------------------------------

#[derive(Clone)]
enum PosteriorModel {
    HistFactory(RustModel),
    Unbinned(RustUnbinnedModel),
    Hybrid(RustHybridModel),
    GaussianMean(GaussianMeanModel),
    Funnel(FunnelModel),
    FunnelNcp(FunnelNcpModel),
    StdNormal(StdNormalModel),
    LinearRegression(RustLinearRegressionModel),
    LogisticRegression(RustLogisticRegressionModel),
    OrderedLogit(RustOrderedLogitModel),
    OrderedProbit(RustOrderedProbitModel),
    PoissonRegression(RustPoissonRegressionModel),
    NegativeBinomialRegression(RustNegativeBinomialRegressionModel),
    ComposedGlm(RustComposedGlmModel),
    LmmMarginal(RustLmmMarginalModel),
    ExponentialSurvival(RustExponentialSurvivalModel),
    WeibullSurvival(RustWeibullSurvivalModel),
    LogNormalAft(RustLogNormalAftModel),
    CoxPh(RustCoxPhModel),
    IntervalCensoredWeibull(RustIntervalCensoredWeibullModel),
    IntervalCensoredWeibullAft(RustIntervalCensoredWeibullAftModel),
    IntervalCensoredExponential(RustIntervalCensoredExponentialModel),
    IntervalCensoredLogNormal(RustIntervalCensoredLogNormalModel),
    OneCompartmentOralPk(RustOneCompartmentOralPkModel),
    OneCompartmentOralPkNlme(RustOneCompartmentOralPkNlmeModel),
    TwoCompartmentIvPk(RustTwoCompartmentIvPkModel),
    TwoCompartmentOralPk(RustTwoCompartmentOralPkModel),
    ThreeCompartmentIvPk(RustThreeCompartmentIvPkModel),
    ThreeCompartmentOralPk(RustThreeCompartmentOralPkModel),
    GammaRegression(RustGammaRegressionModel),
    TweedieRegression(RustTweedieRegressionModel),
    Gev(RustGevModel),
    Gpd(RustGpdModel),
    EightSchools(RustEightSchoolsModel),
}

impl PosteriorModel {
    fn dim(&self) -> usize {
        match self {
            PosteriorModel::HistFactory(m) => m.dim(),
            PosteriorModel::Unbinned(m) => m.dim(),
            PosteriorModel::Hybrid(m) => m.dim(),
            PosteriorModel::GaussianMean(m) => m.dim(),
            PosteriorModel::Funnel(m) => m.dim(),
            PosteriorModel::FunnelNcp(m) => m.dim(),
            PosteriorModel::StdNormal(m) => m.dim(),
            PosteriorModel::LinearRegression(m) => m.dim(),
            PosteriorModel::LogisticRegression(m) => m.dim(),
            PosteriorModel::OrderedLogit(m) => m.dim(),
            PosteriorModel::OrderedProbit(m) => m.dim(),
            PosteriorModel::PoissonRegression(m) => m.dim(),
            PosteriorModel::NegativeBinomialRegression(m) => m.dim(),
            PosteriorModel::ComposedGlm(m) => m.dim(),
            PosteriorModel::LmmMarginal(m) => m.dim(),
            PosteriorModel::ExponentialSurvival(m) => m.dim(),
            PosteriorModel::WeibullSurvival(m) => m.dim(),
            PosteriorModel::LogNormalAft(m) => m.dim(),
            PosteriorModel::CoxPh(m) => m.dim(),
            PosteriorModel::OneCompartmentOralPk(m) => m.dim(),
            PosteriorModel::OneCompartmentOralPkNlme(m) => m.dim(),
            PosteriorModel::TwoCompartmentIvPk(m) => m.dim(),
            PosteriorModel::TwoCompartmentOralPk(m) => m.dim(),
            PosteriorModel::ThreeCompartmentIvPk(m) => m.dim(),
            PosteriorModel::ThreeCompartmentOralPk(m) => m.dim(),
            PosteriorModel::GammaRegression(m) => m.dim(),
            PosteriorModel::TweedieRegression(m) => m.dim(),
            PosteriorModel::Gev(m) => m.dim(),
            PosteriorModel::Gpd(m) => m.dim(),
            PosteriorModel::IntervalCensoredWeibull(m) => m.dim(),
            PosteriorModel::IntervalCensoredWeibullAft(m) => m.dim(),
            PosteriorModel::IntervalCensoredExponential(m) => m.dim(),
            PosteriorModel::IntervalCensoredLogNormal(m) => m.dim(),
            PosteriorModel::EightSchools(m) => m.dim(),
        }
    }

    fn parameter_names(&self) -> Vec<String> {
        match self {
            PosteriorModel::HistFactory(m) => m.parameter_names(),
            PosteriorModel::Unbinned(m) => m.parameter_names(),
            PosteriorModel::Hybrid(m) => m.parameter_names(),
            PosteriorModel::GaussianMean(m) => m.parameter_names(),
            PosteriorModel::Funnel(m) => m.parameter_names(),
            PosteriorModel::FunnelNcp(m) => m.parameter_names(),
            PosteriorModel::StdNormal(m) => m.parameter_names(),
            PosteriorModel::LinearRegression(m) => m.parameter_names(),
            PosteriorModel::LogisticRegression(m) => m.parameter_names(),
            PosteriorModel::OrderedLogit(m) => m.parameter_names(),
            PosteriorModel::OrderedProbit(m) => m.parameter_names(),
            PosteriorModel::PoissonRegression(m) => m.parameter_names(),
            PosteriorModel::NegativeBinomialRegression(m) => m.parameter_names(),
            PosteriorModel::ComposedGlm(m) => m.parameter_names(),
            PosteriorModel::LmmMarginal(m) => m.parameter_names(),
            PosteriorModel::ExponentialSurvival(m) => m.parameter_names(),
            PosteriorModel::WeibullSurvival(m) => m.parameter_names(),
            PosteriorModel::LogNormalAft(m) => m.parameter_names(),
            PosteriorModel::CoxPh(m) => m.parameter_names(),
            PosteriorModel::OneCompartmentOralPk(m) => m.parameter_names(),
            PosteriorModel::OneCompartmentOralPkNlme(m) => m.parameter_names(),
            PosteriorModel::TwoCompartmentIvPk(m) => m.parameter_names(),
            PosteriorModel::TwoCompartmentOralPk(m) => m.parameter_names(),
            PosteriorModel::ThreeCompartmentIvPk(m) => m.parameter_names(),
            PosteriorModel::ThreeCompartmentOralPk(m) => m.parameter_names(),
            PosteriorModel::GammaRegression(m) => m.parameter_names(),
            PosteriorModel::TweedieRegression(m) => m.parameter_names(),
            PosteriorModel::Gev(m) => m.parameter_names(),
            PosteriorModel::Gpd(m) => m.parameter_names(),
            PosteriorModel::IntervalCensoredWeibull(m) => m.parameter_names(),
            PosteriorModel::IntervalCensoredWeibullAft(m) => m.parameter_names(),
            PosteriorModel::IntervalCensoredExponential(m) => m.parameter_names(),
            PosteriorModel::IntervalCensoredLogNormal(m) => m.parameter_names(),
            PosteriorModel::EightSchools(m) => m.parameter_names(),
        }
    }

    fn parameter_bounds(&self) -> Vec<(f64, f64)> {
        match self {
            PosteriorModel::HistFactory(m) => m.parameter_bounds(),
            PosteriorModel::Unbinned(m) => m.parameter_bounds(),
            PosteriorModel::Hybrid(m) => m.parameter_bounds(),
            PosteriorModel::GaussianMean(m) => m.parameter_bounds(),
            PosteriorModel::Funnel(m) => m.parameter_bounds(),
            PosteriorModel::FunnelNcp(m) => m.parameter_bounds(),
            PosteriorModel::StdNormal(m) => m.parameter_bounds(),
            PosteriorModel::LinearRegression(m) => m.parameter_bounds(),
            PosteriorModel::LogisticRegression(m) => m.parameter_bounds(),
            PosteriorModel::OrderedLogit(m) => m.parameter_bounds(),
            PosteriorModel::OrderedProbit(m) => m.parameter_bounds(),
            PosteriorModel::PoissonRegression(m) => m.parameter_bounds(),
            PosteriorModel::NegativeBinomialRegression(m) => m.parameter_bounds(),
            PosteriorModel::ComposedGlm(m) => m.parameter_bounds(),
            PosteriorModel::LmmMarginal(m) => m.parameter_bounds(),
            PosteriorModel::ExponentialSurvival(m) => m.parameter_bounds(),
            PosteriorModel::WeibullSurvival(m) => m.parameter_bounds(),
            PosteriorModel::LogNormalAft(m) => m.parameter_bounds(),
            PosteriorModel::CoxPh(m) => m.parameter_bounds(),
            PosteriorModel::OneCompartmentOralPk(m) => m.parameter_bounds(),
            PosteriorModel::OneCompartmentOralPkNlme(m) => m.parameter_bounds(),
            PosteriorModel::TwoCompartmentIvPk(m) => m.parameter_bounds(),
            PosteriorModel::TwoCompartmentOralPk(m) => m.parameter_bounds(),
            PosteriorModel::ThreeCompartmentIvPk(m) => m.parameter_bounds(),
            PosteriorModel::ThreeCompartmentOralPk(m) => m.parameter_bounds(),
            PosteriorModel::GammaRegression(m) => m.parameter_bounds(),
            PosteriorModel::TweedieRegression(m) => m.parameter_bounds(),
            PosteriorModel::Gev(m) => m.parameter_bounds(),
            PosteriorModel::Gpd(m) => m.parameter_bounds(),
            PosteriorModel::IntervalCensoredWeibull(m) => m.parameter_bounds(),
            PosteriorModel::IntervalCensoredWeibullAft(m) => m.parameter_bounds(),
            PosteriorModel::IntervalCensoredExponential(m) => m.parameter_bounds(),
            PosteriorModel::IntervalCensoredLogNormal(m) => m.parameter_bounds(),
            PosteriorModel::EightSchools(m) => m.parameter_bounds(),
        }
    }

    fn parameter_init(&self) -> Vec<f64> {
        match self {
            PosteriorModel::HistFactory(m) => m.parameter_init(),
            PosteriorModel::Unbinned(m) => m.parameter_init(),
            PosteriorModel::Hybrid(m) => m.parameter_init(),
            PosteriorModel::GaussianMean(m) => m.parameter_init(),
            PosteriorModel::Funnel(m) => m.parameter_init(),
            PosteriorModel::FunnelNcp(m) => m.parameter_init(),
            PosteriorModel::StdNormal(m) => m.parameter_init(),
            PosteriorModel::LinearRegression(m) => m.parameter_init(),
            PosteriorModel::LogisticRegression(m) => m.parameter_init(),
            PosteriorModel::OrderedLogit(m) => m.parameter_init(),
            PosteriorModel::OrderedProbit(m) => m.parameter_init(),
            PosteriorModel::PoissonRegression(m) => m.parameter_init(),
            PosteriorModel::NegativeBinomialRegression(m) => m.parameter_init(),
            PosteriorModel::ComposedGlm(m) => m.parameter_init(),
            PosteriorModel::LmmMarginal(m) => m.parameter_init(),
            PosteriorModel::ExponentialSurvival(m) => m.parameter_init(),
            PosteriorModel::WeibullSurvival(m) => m.parameter_init(),
            PosteriorModel::LogNormalAft(m) => m.parameter_init(),
            PosteriorModel::CoxPh(m) => m.parameter_init(),
            PosteriorModel::OneCompartmentOralPk(m) => m.parameter_init(),
            PosteriorModel::OneCompartmentOralPkNlme(m) => m.parameter_init(),
            PosteriorModel::TwoCompartmentIvPk(m) => m.parameter_init(),
            PosteriorModel::TwoCompartmentOralPk(m) => m.parameter_init(),
            PosteriorModel::ThreeCompartmentIvPk(m) => m.parameter_init(),
            PosteriorModel::ThreeCompartmentOralPk(m) => m.parameter_init(),
            PosteriorModel::GammaRegression(m) => m.parameter_init(),
            PosteriorModel::TweedieRegression(m) => m.parameter_init(),
            PosteriorModel::Gev(m) => m.parameter_init(),
            PosteriorModel::Gpd(m) => m.parameter_init(),
            PosteriorModel::IntervalCensoredWeibull(m) => m.parameter_init(),
            PosteriorModel::IntervalCensoredWeibullAft(m) => m.parameter_init(),
            PosteriorModel::IntervalCensoredExponential(m) => m.parameter_init(),
            PosteriorModel::IntervalCensoredLogNormal(m) => m.parameter_init(),
            PosteriorModel::EightSchools(m) => m.parameter_init(),
        }
    }

    fn nll(&self, params: &[f64]) -> NsResult<f64> {
        match self {
            PosteriorModel::HistFactory(m) => m.nll(params),
            PosteriorModel::Unbinned(m) => m.nll(params),
            PosteriorModel::Hybrid(m) => m.nll(params),
            PosteriorModel::GaussianMean(m) => m.nll(params),
            PosteriorModel::Funnel(m) => m.nll(params),
            PosteriorModel::FunnelNcp(m) => m.nll(params),
            PosteriorModel::StdNormal(m) => m.nll(params),
            PosteriorModel::LinearRegression(m) => m.nll(params),
            PosteriorModel::LogisticRegression(m) => m.nll(params),
            PosteriorModel::OrderedLogit(m) => m.nll(params),
            PosteriorModel::OrderedProbit(m) => m.nll(params),
            PosteriorModel::PoissonRegression(m) => m.nll(params),
            PosteriorModel::NegativeBinomialRegression(m) => m.nll(params),
            PosteriorModel::ComposedGlm(m) => m.nll(params),
            PosteriorModel::LmmMarginal(m) => m.nll(params),
            PosteriorModel::ExponentialSurvival(m) => m.nll(params),
            PosteriorModel::WeibullSurvival(m) => m.nll(params),
            PosteriorModel::LogNormalAft(m) => m.nll(params),
            PosteriorModel::CoxPh(m) => m.nll(params),
            PosteriorModel::OneCompartmentOralPk(m) => m.nll(params),
            PosteriorModel::OneCompartmentOralPkNlme(m) => m.nll(params),
            PosteriorModel::TwoCompartmentIvPk(m) => m.nll(params),
            PosteriorModel::TwoCompartmentOralPk(m) => m.nll(params),
            PosteriorModel::ThreeCompartmentIvPk(m) => m.nll(params),
            PosteriorModel::ThreeCompartmentOralPk(m) => m.nll(params),
            PosteriorModel::GammaRegression(m) => m.nll(params),
            PosteriorModel::TweedieRegression(m) => m.nll(params),
            PosteriorModel::Gev(m) => m.nll(params),
            PosteriorModel::Gpd(m) => m.nll(params),
            PosteriorModel::IntervalCensoredWeibull(m) => m.nll(params),
            PosteriorModel::IntervalCensoredWeibullAft(m) => m.nll(params),
            PosteriorModel::IntervalCensoredExponential(m) => m.nll(params),
            PosteriorModel::IntervalCensoredLogNormal(m) => m.nll(params),
            PosteriorModel::EightSchools(m) => m.nll(params),
        }
    }

    fn grad_nll(&self, params: &[f64]) -> NsResult<Vec<f64>> {
        match self {
            PosteriorModel::HistFactory(m) => m.grad_nll(params),
            PosteriorModel::Unbinned(m) => m.grad_nll(params),
            PosteriorModel::Hybrid(m) => m.grad_nll(params),
            PosteriorModel::GaussianMean(m) => m.grad_nll(params),
            PosteriorModel::Funnel(m) => m.grad_nll(params),
            PosteriorModel::FunnelNcp(m) => m.grad_nll(params),
            PosteriorModel::StdNormal(m) => m.grad_nll(params),
            PosteriorModel::LinearRegression(m) => m.grad_nll(params),
            PosteriorModel::LogisticRegression(m) => m.grad_nll(params),
            PosteriorModel::OrderedLogit(m) => m.grad_nll(params),
            PosteriorModel::OrderedProbit(m) => m.grad_nll(params),
            PosteriorModel::PoissonRegression(m) => m.grad_nll(params),
            PosteriorModel::NegativeBinomialRegression(m) => m.grad_nll(params),
            PosteriorModel::ComposedGlm(m) => m.grad_nll(params),
            PosteriorModel::LmmMarginal(m) => m.grad_nll(params),
            PosteriorModel::ExponentialSurvival(m) => m.grad_nll(params),
            PosteriorModel::WeibullSurvival(m) => m.grad_nll(params),
            PosteriorModel::LogNormalAft(m) => m.grad_nll(params),
            PosteriorModel::CoxPh(m) => m.grad_nll(params),
            PosteriorModel::OneCompartmentOralPk(m) => m.grad_nll(params),
            PosteriorModel::OneCompartmentOralPkNlme(m) => m.grad_nll(params),
            PosteriorModel::TwoCompartmentIvPk(m) => m.grad_nll(params),
            PosteriorModel::TwoCompartmentOralPk(m) => m.grad_nll(params),
            PosteriorModel::ThreeCompartmentIvPk(m) => m.grad_nll(params),
            PosteriorModel::ThreeCompartmentOralPk(m) => m.grad_nll(params),
            PosteriorModel::GammaRegression(m) => m.grad_nll(params),
            PosteriorModel::TweedieRegression(m) => m.grad_nll(params),
            PosteriorModel::Gev(m) => m.grad_nll(params),
            PosteriorModel::Gpd(m) => m.grad_nll(params),
            PosteriorModel::IntervalCensoredWeibull(m) => m.grad_nll(params),
            PosteriorModel::IntervalCensoredWeibullAft(m) => m.grad_nll(params),
            PosteriorModel::IntervalCensoredExponential(m) => m.grad_nll(params),
            PosteriorModel::IntervalCensoredLogNormal(m) => m.grad_nll(params),
            PosteriorModel::EightSchools(m) => m.grad_nll(params),
        }
    }

    fn fit_mle(&self, mle: &RustMLE) -> NsResult<ns_core::FitResult> {
        match self {
            PosteriorModel::HistFactory(m) => mle.fit(m),
            PosteriorModel::Unbinned(m) => mle.fit(m),
            PosteriorModel::Hybrid(m) => mle.fit(m),
            PosteriorModel::GaussianMean(m) => mle.fit(m),
            PosteriorModel::Funnel(m) => mle.fit(m),
            PosteriorModel::FunnelNcp(m) => mle.fit(m),
            PosteriorModel::StdNormal(m) => mle.fit(m),
            PosteriorModel::LinearRegression(m) => mle.fit(m),
            PosteriorModel::LogisticRegression(m) => mle.fit(m),
            PosteriorModel::OrderedLogit(m) => mle.fit(m),
            PosteriorModel::OrderedProbit(m) => mle.fit(m),
            PosteriorModel::PoissonRegression(m) => mle.fit(m),
            PosteriorModel::NegativeBinomialRegression(m) => mle.fit(m),
            PosteriorModel::ComposedGlm(m) => mle.fit(m),
            PosteriorModel::LmmMarginal(m) => mle.fit(m),
            PosteriorModel::ExponentialSurvival(m) => mle.fit(m),
            PosteriorModel::WeibullSurvival(m) => mle.fit(m),
            PosteriorModel::LogNormalAft(m) => mle.fit(m),
            PosteriorModel::CoxPh(m) => mle.fit(m),
            PosteriorModel::OneCompartmentOralPk(m) => mle.fit(m),
            PosteriorModel::OneCompartmentOralPkNlme(m) => mle.fit(m),
            PosteriorModel::TwoCompartmentIvPk(m) => mle.fit(m),
            PosteriorModel::TwoCompartmentOralPk(m) => mle.fit(m),
            PosteriorModel::ThreeCompartmentIvPk(m) => mle.fit(m),
            PosteriorModel::ThreeCompartmentOralPk(m) => mle.fit(m),
            PosteriorModel::GammaRegression(m) => mle.fit(m),
            PosteriorModel::TweedieRegression(m) => mle.fit(m),
            PosteriorModel::Gev(m) => mle.fit(m),
            PosteriorModel::Gpd(m) => mle.fit(m),
            PosteriorModel::IntervalCensoredWeibull(m) => mle.fit(m),
            PosteriorModel::IntervalCensoredWeibullAft(m) => mle.fit(m),
            PosteriorModel::IntervalCensoredExponential(m) => mle.fit(m),
            PosteriorModel::IntervalCensoredLogNormal(m) => mle.fit(m),
            PosteriorModel::EightSchools(m) => mle.fit(m),
        }
    }

    fn fit_mle_from(&self, mle: &RustMLE, init_pars: &[f64]) -> NsResult<ns_core::FitResult> {
        match self {
            PosteriorModel::HistFactory(m) => mle.fit_from(m, init_pars),
            PosteriorModel::Unbinned(m) => mle.fit_from(m, init_pars),
            PosteriorModel::Hybrid(m) => mle.fit_from(m, init_pars),
            PosteriorModel::GaussianMean(m) => mle.fit_from(m, init_pars),
            PosteriorModel::Funnel(m) => mle.fit_from(m, init_pars),
            PosteriorModel::FunnelNcp(m) => mle.fit_from(m, init_pars),
            PosteriorModel::StdNormal(m) => mle.fit_from(m, init_pars),
            PosteriorModel::LinearRegression(m) => mle.fit_from(m, init_pars),
            PosteriorModel::LogisticRegression(m) => mle.fit_from(m, init_pars),
            PosteriorModel::OrderedLogit(m) => mle.fit_from(m, init_pars),
            PosteriorModel::OrderedProbit(m) => mle.fit_from(m, init_pars),
            PosteriorModel::PoissonRegression(m) => mle.fit_from(m, init_pars),
            PosteriorModel::NegativeBinomialRegression(m) => mle.fit_from(m, init_pars),
            PosteriorModel::ComposedGlm(m) => mle.fit_from(m, init_pars),
            PosteriorModel::LmmMarginal(m) => mle.fit_from(m, init_pars),
            PosteriorModel::ExponentialSurvival(m) => mle.fit_from(m, init_pars),
            PosteriorModel::WeibullSurvival(m) => mle.fit_from(m, init_pars),
            PosteriorModel::LogNormalAft(m) => mle.fit_from(m, init_pars),
            PosteriorModel::CoxPh(m) => mle.fit_from(m, init_pars),
            PosteriorModel::OneCompartmentOralPk(m) => mle.fit_from(m, init_pars),
            PosteriorModel::OneCompartmentOralPkNlme(m) => mle.fit_from(m, init_pars),
            PosteriorModel::TwoCompartmentIvPk(m) => mle.fit_from(m, init_pars),
            PosteriorModel::TwoCompartmentOralPk(m) => mle.fit_from(m, init_pars),
            PosteriorModel::ThreeCompartmentIvPk(m) => mle.fit_from(m, init_pars),
            PosteriorModel::ThreeCompartmentOralPk(m) => mle.fit_from(m, init_pars),
            PosteriorModel::GammaRegression(m) => mle.fit_from(m, init_pars),
            PosteriorModel::TweedieRegression(m) => mle.fit_from(m, init_pars),
            PosteriorModel::Gev(m) => mle.fit_from(m, init_pars),
            PosteriorModel::Gpd(m) => mle.fit_from(m, init_pars),
            PosteriorModel::IntervalCensoredWeibull(m) => mle.fit_from(m, init_pars),
            PosteriorModel::IntervalCensoredWeibullAft(m) => mle.fit_from(m, init_pars),
            PosteriorModel::IntervalCensoredExponential(m) => mle.fit_from(m, init_pars),
            PosteriorModel::IntervalCensoredLogNormal(m) => mle.fit_from(m, init_pars),
            PosteriorModel::EightSchools(m) => mle.fit_from(m, init_pars),
        }
    }

    fn sample_nuts_multichain(
        &self,
        n_chains: usize,
        n_warmup: usize,
        n_samples: usize,
        seed: u64,
        config: NutsConfig,
    ) -> NsResult<RustSamplerResult> {
        let seeds: Vec<u64> =
            (0..n_chains).map(|chain_id| seed.wrapping_add(chain_id as u64)).collect();
        match self {
            PosteriorModel::HistFactory(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::Unbinned(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::Hybrid(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::GaussianMean(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::Funnel(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::FunnelNcp(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::StdNormal(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::LinearRegression(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::LogisticRegression(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::OrderedLogit(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::OrderedProbit(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::PoissonRegression(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::NegativeBinomialRegression(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::ComposedGlm(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::LmmMarginal(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::ExponentialSurvival(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::WeibullSurvival(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::LogNormalAft(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::CoxPh(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::OneCompartmentOralPk(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::OneCompartmentOralPkNlme(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::TwoCompartmentIvPk(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::TwoCompartmentOralPk(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::ThreeCompartmentIvPk(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::ThreeCompartmentOralPk(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::GammaRegression(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::TweedieRegression(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::Gev(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::Gpd(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::IntervalCensoredWeibull(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::IntervalCensoredWeibullAft(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::IntervalCensoredExponential(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::IntervalCensoredLogNormal(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::EightSchools(m) => {
                sample_nuts_multichain_with_seeds(m, n_warmup, n_samples, &seeds, config)
            }
        }
    }

    fn sample_mams_mc(
        &self,
        n_chains: usize,
        seed: u64,
        config: MamsConfig,
    ) -> NsResult<RustSamplerResult> {
        match self {
            PosteriorModel::HistFactory(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::Unbinned(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::Hybrid(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::GaussianMean(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::Funnel(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::FunnelNcp(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::StdNormal(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::LinearRegression(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::LogisticRegression(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::OrderedLogit(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::OrderedProbit(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::PoissonRegression(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::NegativeBinomialRegression(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::ComposedGlm(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::LmmMarginal(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::ExponentialSurvival(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::WeibullSurvival(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::LogNormalAft(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::CoxPh(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::OneCompartmentOralPk(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::OneCompartmentOralPkNlme(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::TwoCompartmentIvPk(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::TwoCompartmentOralPk(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::ThreeCompartmentIvPk(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::ThreeCompartmentOralPk(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::GammaRegression(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::TweedieRegression(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::Gev(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::Gpd(m) => sample_mams_multichain(m, n_chains, seed, config),
            PosteriorModel::IntervalCensoredWeibull(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::IntervalCensoredWeibullAft(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::IntervalCensoredExponential(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::IntervalCensoredLogNormal(m) => {
                sample_mams_multichain(m, n_chains, seed, config)
            }
            PosteriorModel::EightSchools(m) => sample_mams_multichain(m, n_chains, seed, config),
        }
    }

    fn sample_mams_mc_map(
        &self,
        n_chains: usize,
        seed: u64,
        config: MamsConfig,
        priors: Vec<Prior>,
    ) -> NsResult<RustSamplerResult> {
        match self {
            PosteriorModel::HistFactory(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::Unbinned(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::Hybrid(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::GaussianMean(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::Funnel(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::FunnelNcp(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::StdNormal(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::LinearRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::LogisticRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::OrderedLogit(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::OrderedProbit(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::PoissonRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::NegativeBinomialRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::ComposedGlm(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::LmmMarginal(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::ExponentialSurvival(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::WeibullSurvival(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::LogNormalAft(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::CoxPh(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::OneCompartmentOralPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::OneCompartmentOralPkNlme(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::TwoCompartmentIvPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::TwoCompartmentOralPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::ThreeCompartmentIvPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::ThreeCompartmentOralPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::GammaRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::TweedieRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::Gev(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::Gpd(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::IntervalCensoredWeibull(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::IntervalCensoredWeibullAft(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::IntervalCensoredExponential(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::IntervalCensoredLogNormal(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
            PosteriorModel::EightSchools(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_mams_multichain(&w, n_chains, seed, config)
            }
        }
    }

    fn fit_map(&self, mle: &RustMLE, priors: Vec<Prior>) -> NsResult<ns_core::FitResult> {
        match self {
            PosteriorModel::HistFactory(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::Unbinned(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::Hybrid(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::GaussianMean(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::Funnel(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::FunnelNcp(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::StdNormal(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::LinearRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::LogisticRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::OrderedLogit(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::OrderedProbit(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::PoissonRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::NegativeBinomialRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::ComposedGlm(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::LmmMarginal(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::ExponentialSurvival(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::WeibullSurvival(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::LogNormalAft(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::CoxPh(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::OneCompartmentOralPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::OneCompartmentOralPkNlme(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::TwoCompartmentIvPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::TwoCompartmentOralPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::ThreeCompartmentIvPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::ThreeCompartmentOralPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::GammaRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::TweedieRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::Gev(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::Gpd(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::IntervalCensoredWeibull(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::IntervalCensoredWeibullAft(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::IntervalCensoredExponential(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::IntervalCensoredLogNormal(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
            PosteriorModel::EightSchools(m) => {
                let w = WithPriors { model: m.clone(), priors };
                mle.fit(&w)
            }
        }
    }

    fn run_map_estimate(
        &self,
        priors: Vec<RustPrior>,
        config: &RustMapConfig,
    ) -> NsResult<RustMapResult> {
        macro_rules! dispatch_map {
            ($m:expr) => {{
                let posterior = RustPosterior::new($m).with_priors(priors)?;
                rust_map_estimate(&posterior, config)
            }};
        }
        match self {
            PosteriorModel::HistFactory(m) => dispatch_map!(m),
            PosteriorModel::Unbinned(m) => dispatch_map!(m),
            PosteriorModel::Hybrid(m) => dispatch_map!(m),
            PosteriorModel::GaussianMean(m) => dispatch_map!(m),
            PosteriorModel::Funnel(m) => dispatch_map!(m),
            PosteriorModel::FunnelNcp(m) => dispatch_map!(m),
            PosteriorModel::StdNormal(m) => dispatch_map!(m),
            PosteriorModel::LinearRegression(m) => dispatch_map!(m),
            PosteriorModel::LogisticRegression(m) => dispatch_map!(m),
            PosteriorModel::OrderedLogit(m) => dispatch_map!(m),
            PosteriorModel::OrderedProbit(m) => dispatch_map!(m),
            PosteriorModel::PoissonRegression(m) => dispatch_map!(m),
            PosteriorModel::NegativeBinomialRegression(m) => dispatch_map!(m),
            PosteriorModel::ComposedGlm(m) => dispatch_map!(m),
            PosteriorModel::LmmMarginal(m) => dispatch_map!(m),
            PosteriorModel::ExponentialSurvival(m) => dispatch_map!(m),
            PosteriorModel::WeibullSurvival(m) => dispatch_map!(m),
            PosteriorModel::LogNormalAft(m) => dispatch_map!(m),
            PosteriorModel::CoxPh(m) => dispatch_map!(m),
            PosteriorModel::OneCompartmentOralPk(m) => dispatch_map!(m),
            PosteriorModel::OneCompartmentOralPkNlme(m) => dispatch_map!(m),
            PosteriorModel::TwoCompartmentIvPk(m) => dispatch_map!(m),
            PosteriorModel::TwoCompartmentOralPk(m) => dispatch_map!(m),
            PosteriorModel::ThreeCompartmentIvPk(m) => dispatch_map!(m),
            PosteriorModel::ThreeCompartmentOralPk(m) => dispatch_map!(m),
            PosteriorModel::GammaRegression(m) => dispatch_map!(m),
            PosteriorModel::TweedieRegression(m) => dispatch_map!(m),
            PosteriorModel::Gev(m) => dispatch_map!(m),
            PosteriorModel::Gpd(m) => dispatch_map!(m),
            PosteriorModel::IntervalCensoredWeibull(m) => dispatch_map!(m),
            PosteriorModel::IntervalCensoredWeibullAft(m) => dispatch_map!(m),
            PosteriorModel::IntervalCensoredExponential(m) => dispatch_map!(m),
            PosteriorModel::IntervalCensoredLogNormal(m) => dispatch_map!(m),
            PosteriorModel::EightSchools(m) => dispatch_map!(m),
        }
    }

    fn sample_nuts_multichain_map(
        &self,
        n_chains: usize,
        n_warmup: usize,
        n_samples: usize,
        seed: u64,
        config: NutsConfig,
        priors: Vec<Prior>,
    ) -> NsResult<RustSamplerResult> {
        let seeds: Vec<u64> =
            (0..n_chains).map(|chain_id| seed.wrapping_add(chain_id as u64)).collect();
        match self {
            PosteriorModel::HistFactory(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::Unbinned(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::Hybrid(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::GaussianMean(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::Funnel(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::FunnelNcp(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::StdNormal(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::LinearRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::LogisticRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::OrderedLogit(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::OrderedProbit(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::PoissonRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::NegativeBinomialRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::ComposedGlm(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::LmmMarginal(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::ExponentialSurvival(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::WeibullSurvival(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::LogNormalAft(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::CoxPh(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::OneCompartmentOralPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::OneCompartmentOralPkNlme(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::TwoCompartmentIvPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::TwoCompartmentOralPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::ThreeCompartmentIvPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::ThreeCompartmentOralPk(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::GammaRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::TweedieRegression(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::Gev(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::Gpd(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::IntervalCensoredWeibull(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::IntervalCensoredWeibullAft(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::IntervalCensoredExponential(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::IntervalCensoredLogNormal(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
            PosteriorModel::EightSchools(m) => {
                let w = WithPriors { model: m.clone(), priors };
                sample_nuts_multichain_with_seeds(&w, n_warmup, n_samples, &seeds, config)
            }
        }
    }

    fn profile_ci_one(
        &self,
        mle_params: &[f64],
        mle_nll: f64,
        param_idx: usize,
        bounds: (f64, f64),
        chi2_level: f64,
        tol: f64,
        config: &ns_inference::OptimizerConfig,
    ) -> NsResult<ns_inference::ProfileCiResult> {
        macro_rules! dispatch_ci {
            ($m:expr) => {
                ns_inference::profile_ci(
                    $m, mle_params, mle_nll, param_idx, bounds, chi2_level, tol, config,
                )
            };
        }
        match self {
            PosteriorModel::HistFactory(m) => dispatch_ci!(m),
            PosteriorModel::Unbinned(m) => dispatch_ci!(m),
            PosteriorModel::Hybrid(m) => dispatch_ci!(m),
            PosteriorModel::GaussianMean(m) => dispatch_ci!(m),
            PosteriorModel::Funnel(m) => dispatch_ci!(m),
            PosteriorModel::FunnelNcp(m) => dispatch_ci!(m),
            PosteriorModel::StdNormal(m) => dispatch_ci!(m),
            PosteriorModel::LinearRegression(m) => dispatch_ci!(m),
            PosteriorModel::LogisticRegression(m) => dispatch_ci!(m),
            PosteriorModel::OrderedLogit(m) => dispatch_ci!(m),
            PosteriorModel::OrderedProbit(m) => dispatch_ci!(m),
            PosteriorModel::PoissonRegression(m) => dispatch_ci!(m),
            PosteriorModel::NegativeBinomialRegression(m) => dispatch_ci!(m),
            PosteriorModel::ComposedGlm(m) => dispatch_ci!(m),
            PosteriorModel::LmmMarginal(m) => dispatch_ci!(m),
            PosteriorModel::ExponentialSurvival(m) => dispatch_ci!(m),
            PosteriorModel::WeibullSurvival(m) => dispatch_ci!(m),
            PosteriorModel::LogNormalAft(m) => dispatch_ci!(m),
            PosteriorModel::CoxPh(m) => dispatch_ci!(m),
            PosteriorModel::IntervalCensoredWeibull(m) => dispatch_ci!(m),
            PosteriorModel::IntervalCensoredWeibullAft(m) => dispatch_ci!(m),
            PosteriorModel::IntervalCensoredExponential(m) => dispatch_ci!(m),
            PosteriorModel::IntervalCensoredLogNormal(m) => dispatch_ci!(m),
            PosteriorModel::OneCompartmentOralPk(m) => dispatch_ci!(m),
            PosteriorModel::OneCompartmentOralPkNlme(m) => dispatch_ci!(m),
            PosteriorModel::TwoCompartmentIvPk(m) => dispatch_ci!(m),
            PosteriorModel::TwoCompartmentOralPk(m) => dispatch_ci!(m),
            PosteriorModel::ThreeCompartmentIvPk(m) => dispatch_ci!(m),
            PosteriorModel::ThreeCompartmentOralPk(m) => dispatch_ci!(m),
            PosteriorModel::GammaRegression(m) => dispatch_ci!(m),
            PosteriorModel::TweedieRegression(m) => dispatch_ci!(m),
            PosteriorModel::Gev(m) => dispatch_ci!(m),
            PosteriorModel::Gpd(m) => dispatch_ci!(m),
            PosteriorModel::EightSchools(m) => dispatch_ci!(m),
        }
    }
}

fn extract_posterior_model(model: &Bound<'_, PyAny>) -> PyResult<PosteriorModel> {
    if let Ok(hf) = model.extract::<PyRef<'_, PyHistFactoryModel>>() {
        Ok(PosteriorModel::HistFactory(hf.inner.clone()))
    } else if let Ok(ub) = model.extract::<PyRef<'_, PyUnbinnedModel>>() {
        Ok(PosteriorModel::Unbinned(ub.inner.clone()))
    } else if let Ok(hm) = model.extract::<PyRef<'_, PyHybridModel>>() {
        Ok(PosteriorModel::Hybrid(hm.inner.clone()))
    } else if let Ok(gm) = model.extract::<PyRef<'_, PyGaussianMeanModel>>() {
        Ok(PosteriorModel::GaussianMean(gm.inner.clone()))
    } else if let Ok(fm) = model.extract::<PyRef<'_, PyFunnelModel>>() {
        Ok(PosteriorModel::Funnel(fm.inner.clone()))
    } else if let Ok(fm) = model.extract::<PyRef<'_, PyFunnelNcpModel>>() {
        Ok(PosteriorModel::FunnelNcp(fm.inner.clone()))
    } else if let Ok(sm) = model.extract::<PyRef<'_, PyStdNormalModel>>() {
        Ok(PosteriorModel::StdNormal(sm.inner.clone()))
    } else if let Ok(lr) = model.extract::<PyRef<'_, PyLinearRegressionModel>>() {
        Ok(PosteriorModel::LinearRegression(lr.inner.clone()))
    } else if let Ok(logit) = model.extract::<PyRef<'_, PyLogisticRegressionModel>>() {
        Ok(PosteriorModel::LogisticRegression(logit.inner.clone()))
    } else if let Ok(ord) = model.extract::<PyRef<'_, PyOrderedLogitModel>>() {
        Ok(PosteriorModel::OrderedLogit(ord.inner.clone()))
    } else if let Ok(ord) = model.extract::<PyRef<'_, PyOrderedProbitModel>>() {
        Ok(PosteriorModel::OrderedProbit(ord.inner.clone()))
    } else if let Ok(pois) = model.extract::<PyRef<'_, PyPoissonRegressionModel>>() {
        Ok(PosteriorModel::PoissonRegression(pois.inner.clone()))
    } else if let Ok(nb) = model.extract::<PyRef<'_, PyNegativeBinomialRegressionModel>>() {
        Ok(PosteriorModel::NegativeBinomialRegression(nb.inner.clone()))
    } else if let Ok(glm) = model.extract::<PyRef<'_, PyComposedGlmModel>>() {
        Ok(PosteriorModel::ComposedGlm(glm.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyLmmMarginalModel>>() {
        Ok(PosteriorModel::LmmMarginal(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyExponentialSurvivalModel>>() {
        Ok(PosteriorModel::ExponentialSurvival(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyWeibullSurvivalModel>>() {
        Ok(PosteriorModel::WeibullSurvival(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyLogNormalAftModel>>() {
        Ok(PosteriorModel::LogNormalAft(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyCoxPhModel>>() {
        Ok(PosteriorModel::CoxPh(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyOneCompartmentOralPkModel>>() {
        Ok(PosteriorModel::OneCompartmentOralPk(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyOneCompartmentOralPkNlmeModel>>() {
        Ok(PosteriorModel::OneCompartmentOralPkNlme(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyTwoCompartmentIvPkModel>>() {
        Ok(PosteriorModel::TwoCompartmentIvPk(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyTwoCompartmentOralPkModel>>() {
        Ok(PosteriorModel::TwoCompartmentOralPk(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyThreeCompartmentIvPkModel>>() {
        Ok(PosteriorModel::ThreeCompartmentIvPk(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyThreeCompartmentOralPkModel>>() {
        Ok(PosteriorModel::ThreeCompartmentOralPk(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyGammaRegressionModel>>() {
        Ok(PosteriorModel::GammaRegression(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyTweedieRegressionModel>>() {
        Ok(PosteriorModel::TweedieRegression(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyGevModel>>() {
        Ok(PosteriorModel::Gev(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyGpdModel>>() {
        Ok(PosteriorModel::Gpd(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyIntervalCensoredWeibullModel>>() {
        Ok(PosteriorModel::IntervalCensoredWeibull(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyIntervalCensoredWeibullAftModel>>() {
        Ok(PosteriorModel::IntervalCensoredWeibullAft(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyIntervalCensoredExponentialModel>>() {
        Ok(PosteriorModel::IntervalCensoredExponential(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyIntervalCensoredLogNormalModel>>() {
        Ok(PosteriorModel::IntervalCensoredLogNormal(m.inner.clone()))
    } else if let Ok(m) = model.extract::<PyRef<'_, PyEightSchoolsModel>>() {
        Ok(PosteriorModel::EightSchools(m.inner.clone()))
    } else {
        Err(PyValueError::new_err(
            "Unsupported model type. Expected HistFactoryModel, UnbinnedModel, GaussianMeanModel, FunnelModel, FunnelNcpModel, StdNormalModel, a regression model, OrderedLogitModel, OrderedProbitModel, ComposedGlmModel, LmmMarginalModel, a survival model, an interval-censored model, a PK model, GammaRegressionModel, TweedieRegressionModel, GevModel, GpdModel, or EightSchoolsModel.",
        ))
    }
}

fn extract_posterior_model_with_data(
    model: &Bound<'_, PyAny>,
    data: Option<Vec<f64>>,
) -> PyResult<PosteriorModel> {
    if let Ok(hf) = model.extract::<PyRef<'_, PyHistFactoryModel>>() {
        let m = if let Some(obs_main) = data {
            hf.inner
                .with_observed_main(&obs_main)
                .map_err(|e| PyValueError::new_err(format!("Failed to set observed data: {}", e)))?
        } else {
            hf.inner.clone()
        };
        Ok(PosteriorModel::HistFactory(m))
    } else {
        if data.is_some() {
            return Err(PyValueError::new_err("data= is only supported for HistFactoryModel"));
        }
        extract_posterior_model(model)
    }
}

fn validate_f64_vec(name: &str, xs: &[f64], dim: usize) -> PyResult<()> {
    if xs.len() != dim {
        return Err(PyValueError::new_err(format!(
            "expected {name} length = model.dim() = {dim}, got {}",
            xs.len()
        )));
    }
    if xs.iter().any(|v| !v.is_finite()) {
        return Err(PyValueError::new_err(format!("{name} must contain only finite values")));
    }
    Ok(())
}

fn validate_bounds(name: &str, bounds: &[(f64, f64)], dim: usize) -> PyResult<()> {
    if bounds.len() != dim {
        return Err(PyValueError::new_err(format!(
            "expected {name} length = model.dim() = {dim}, got {}",
            bounds.len()
        )));
    }
    for (i, (lo, hi)) in bounds.iter().copied().enumerate() {
        if !lo.is_finite() || !hi.is_finite() {
            return Err(PyValueError::new_err(format!(
                "{name}[{i}] bounds must be finite, got ({lo}, {hi})"
            )));
        }
        if lo > hi {
            return Err(PyValueError::new_err(format!(
                "{name}[{i}] invalid bounds: lo > hi, got ({lo}, {hi})"
            )));
        }
    }
    Ok(())
}

fn validate_nuts_config(
    n_chains: usize,
    _n_warmup: usize,
    n_samples: usize,
    max_treedepth: usize,
    target_accept: f64,
    init_jitter: f64,
    init_jitter_rel: Option<f64>,
    init_overdispersed_rel: Option<f64>,
) -> PyResult<()> {
    if n_chains == 0 {
        return Err(PyValueError::new_err("n_chains must be >= 1"));
    }
    if n_samples == 0 {
        return Err(PyValueError::new_err("n_samples must be >= 1"));
    }
    if max_treedepth == 0 {
        return Err(PyValueError::new_err("max_treedepth must be >= 1"));
    }
    if !(target_accept.is_finite() && 0.0 < target_accept && target_accept < 1.0) {
        return Err(PyValueError::new_err("target_accept must be finite and in (0,1)"));
    }

    if !init_jitter.is_finite() || init_jitter < 0.0 {
        return Err(PyValueError::new_err("init_jitter must be finite and >= 0"));
    }
    if let Some(v) = init_jitter_rel
        && (!v.is_finite() || v <= 0.0)
    {
        return Err(PyValueError::new_err("init_jitter_rel must be finite and > 0"));
    }
    if let Some(v) = init_overdispersed_rel
        && (!v.is_finite() || v <= 0.0)
    {
        return Err(PyValueError::new_err("init_overdispersed_rel must be finite and > 0"));
    }

    let init_modes = (init_jitter > 0.0) as u8
        + init_jitter_rel.is_some() as u8
        + init_overdispersed_rel.is_some() as u8;
    if init_modes > 1 {
        return Err(PyValueError::new_err(
            "init_jitter, init_jitter_rel, init_overdispersed_rel are mutually exclusive",
        ));
    }
    Ok(())
}

/// Posterior wrapper: provides constrained and unconstrained log-density evaluation.
///
/// Notes:
/// - Uses the model's `nll`/`grad_nll`. For HistFactory, constraint terms are already included
///   in `nll` (pyhf parity baseline), and Posterior does not double-count them.
#[pyclass(name = "Posterior")]
struct PyPosterior {
    model: PosteriorModel,
    bounds: Vec<(f64, f64)>,
    transform: ParameterTransform,
    dim: usize,
    names: Vec<String>,
    name_to_idx: HashMap<String, usize>,
    priors: Vec<Prior>,
}

#[derive(Debug, Clone)]
enum Prior {
    Flat,
    Normal { center: f64, width: f64 },
}

impl Prior {
    fn logpdf(&self, theta: f64) -> PyResult<f64> {
        match self {
            Prior::Flat => Ok(0.0),
            Prior::Normal { center, width } => {
                if !width.is_finite() || *width <= 0.0 {
                    return Err(PyValueError::new_err(format!(
                        "Normal prior width must be finite and > 0, got {}",
                        width
                    )));
                }
                let pull = (theta - center) / width;
                Ok(-0.5 * pull * pull)
            }
        }
    }

    fn grad(&self, theta: f64) -> PyResult<f64> {
        match self {
            Prior::Flat => Ok(0.0),
            Prior::Normal { center, width } => {
                if !width.is_finite() || *width <= 0.0 {
                    return Err(PyValueError::new_err(format!(
                        "Normal prior width must be finite and > 0, got {}",
                        width
                    )));
                }
                Ok(-(theta - center) / (width * width))
            }
        }
    }
}

#[derive(Debug, Clone)]
struct WithPriors<M> {
    model: M,
    priors: Vec<Prior>,
}

impl<M: LogDensityModel> LogDensityModel for WithPriors<M> {
    type Prepared<'a>
        = ns_core::traits::PreparedModelRef<'a, Self>
    where
        Self: 'a;

    fn dim(&self) -> usize {
        self.model.dim()
    }

    fn parameter_names(&self) -> Vec<String> {
        self.model.parameter_names()
    }

    fn parameter_bounds(&self) -> Vec<(f64, f64)> {
        self.model.parameter_bounds()
    }

    fn parameter_init(&self) -> Vec<f64> {
        self.model.parameter_init()
    }

    fn nll(&self, params: &[f64]) -> NsResult<f64> {
        if self.priors.len() != params.len() {
            return Err(NsError::Validation(format!(
                "priors length must match params length: {} != {}",
                self.priors.len(),
                params.len()
            )));
        }
        let mut out = self.model.nll(params)?;
        for (i, pr) in self.priors.iter().enumerate() {
            match pr {
                Prior::Flat => {}
                Prior::Normal { center, width } => {
                    if !width.is_finite() || *width <= 0.0 {
                        return Err(NsError::Validation(format!(
                            "Normal prior width must be finite and > 0, got {}",
                            width
                        )));
                    }
                    let pull = (params[i] - center) / width;
                    out += 0.5 * pull * pull;
                }
            }
        }
        Ok(out)
    }

    fn grad_nll(&self, params: &[f64]) -> NsResult<Vec<f64>> {
        if self.priors.len() != params.len() {
            return Err(NsError::Validation(format!(
                "priors length must match params length: {} != {}",
                self.priors.len(),
                params.len()
            )));
        }
        let mut g = self.model.grad_nll(params)?;
        for (i, pr) in self.priors.iter().enumerate() {
            match pr {
                Prior::Flat => {}
                Prior::Normal { center, width } => {
                    if !width.is_finite() || *width <= 0.0 {
                        return Err(NsError::Validation(format!(
                            "Normal prior width must be finite and > 0, got {}",
                            width
                        )));
                    }
                    g[i] += (params[i] - center) / (width * width);
                }
            }
        }
        Ok(g)
    }

    fn prepared(&self) -> Self::Prepared<'_> {
        ns_core::traits::PreparedModelRef::new(self)
    }

    fn prefer_fused_eval_grad(&self) -> bool {
        self.model.prefer_fused_eval_grad()
    }

    fn nll_grad_prepared(
        &self,
        _prepared: &Self::Prepared<'_>,
        params: &[f64],
    ) -> NsResult<(f64, Vec<f64>)> {
        // Delegate to inner model's fused eval, then overlay prior terms in-place.
        let inner_prepared = self.model.prepared();
        let (mut nll, mut grad) = self.model.nll_grad_prepared(&inner_prepared, params)?;
        for (i, pr) in self.priors.iter().enumerate() {
            match pr {
                Prior::Flat => {}
                Prior::Normal { center, width } => {
                    let pull = (params[i] - center) / width;
                    nll += 0.5 * pull * pull;
                    grad[i] += (params[i] - center) / (width * width);
                }
            }
        }
        Ok((nll, grad))
    }
}

#[pymethods]
impl PyPosterior {
    #[new]
    fn new(model: &Bound<'_, PyAny>) -> PyResult<Self> {
        let model = extract_posterior_model(model)?;
        let dim = model.dim();

        // Defensive: keep Posterior well-defined even if bounds length != dim.
        let mut bounds: Vec<(f64, f64)> = model.parameter_bounds();
        if bounds.len() > dim {
            bounds.truncate(dim);
        } else if bounds.len() < dim {
            bounds.resize(dim, (f64::NEG_INFINITY, f64::INFINITY));
        }

        let transform = ParameterTransform::from_bounds(&bounds);
        let names = model.parameter_names();
        let mut name_to_idx = HashMap::with_capacity(names.len());
        for (i, n) in names.iter().enumerate() {
            name_to_idx.insert(n.clone(), i);
        }
        let priors = vec![Prior::Flat; dim];
        Ok(Self { model, bounds, transform, dim, names, name_to_idx, priors })
    }

    fn dim(&self) -> usize {
        self.dim
    }

    fn parameter_names(&self) -> Vec<String> {
        self.names.clone()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.bounds.clone()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.model.parameter_init()
    }

    fn clear_priors(&mut self) {
        self.priors.fill(Prior::Flat);
    }

    fn set_prior_flat(&mut self, name: String) -> PyResult<()> {
        let idx = self.param_idx(&name)?;
        self.priors[idx] = Prior::Flat;
        Ok(())
    }

    fn set_prior_normal(&mut self, name: String, center: f64, width: f64) -> PyResult<()> {
        let idx = self.param_idx(&name)?;
        if !center.is_finite() {
            return Err(PyValueError::new_err("Normal prior center must be finite"));
        }
        if !width.is_finite() || width <= 0.0 {
            return Err(PyValueError::new_err("Normal prior width must be finite and > 0"));
        }
        self.priors[idx] = Prior::Normal { center, width };
        Ok(())
    }

    fn priors<'py>(&self, py: Python<'py>) -> PyResult<Py<PyAny>> {
        let out = PyDict::new(py);
        for (i, name) in self.names.iter().enumerate() {
            let d = PyDict::new(py);
            match &self.priors[i] {
                Prior::Flat => {
                    d.set_item("type", "flat")?;
                }
                Prior::Normal { center, width } => {
                    d.set_item("type", "normal")?;
                    d.set_item("center", *center)?;
                    d.set_item("width", *width)?;
                }
            }
            out.set_item(name, d)?;
        }
        Ok(out.into_any().unbind())
    }

    fn logpdf(&self, theta: &Bound<'_, PyAny>) -> PyResult<f64> {
        let theta = extract_f64_vec(theta)?;
        validate_f64_vec("theta", &theta, self.dim)?;
        let nll = self
            .model
            .nll(&theta)
            .map_err(|e| PyValueError::new_err(format!("logpdf failed: {}", e)))?;
        let lp_prior = self.prior_logpdf(&theta)?;
        Ok(-nll + lp_prior)
    }

    fn grad(&self, theta: &Bound<'_, PyAny>) -> PyResult<Vec<f64>> {
        let theta = extract_f64_vec(theta)?;
        validate_f64_vec("theta", &theta, self.dim)?;
        let mut g = self
            .model
            .grad_nll(&theta)
            .map_err(|e| PyValueError::new_err(format!("grad failed: {}", e)))?;
        for gi in g.iter_mut() {
            *gi = -*gi;
        }
        self.add_prior_grad(&theta, &mut g)?;
        Ok(g)
    }

    fn to_unconstrained(&self, theta: &Bound<'_, PyAny>) -> PyResult<Vec<f64>> {
        let theta = extract_f64_vec(theta)?;
        validate_f64_vec("theta", &theta, self.dim)?;
        Ok(self.transform.inverse(&theta))
    }

    fn to_constrained(&self, z: &Bound<'_, PyAny>) -> PyResult<Vec<f64>> {
        let z = extract_f64_vec(z)?;
        validate_f64_vec("z", &z, self.dim)?;
        Ok(self.transform.forward(&z))
    }

    fn logpdf_unconstrained(&self, z: &Bound<'_, PyAny>) -> PyResult<f64> {
        let z = extract_f64_vec(z)?;
        validate_f64_vec("z", &z, self.dim)?;
        let theta = self.transform.forward(&z);
        let nll = self
            .model
            .nll(&theta)
            .map_err(|e| PyValueError::new_err(format!("logpdf_unconstrained failed: {}", e)))?;
        let lp_prior = self.prior_logpdf(&theta)?;
        let log_jac = self.transform.log_abs_det_jacobian(&z);
        Ok(-nll + lp_prior + log_jac)
    }

    fn grad_unconstrained(&self, z: &Bound<'_, PyAny>) -> PyResult<Vec<f64>> {
        let z = extract_f64_vec(z)?;
        validate_f64_vec("z", &z, self.dim)?;
        let theta = self.transform.forward(&z);

        // grad(logpdf) = -grad(nll)
        let mut grad_theta = self
            .model
            .grad_nll(&theta)
            .map_err(|e| PyValueError::new_err(format!("grad_unconstrained failed: {}", e)))?;
        for gi in grad_theta.iter_mut() {
            *gi = -*gi;
        }
        self.add_prior_grad(&theta, &mut grad_theta)?;

        let jac_diag = self.transform.jacobian_diag(&z);
        let grad_log_jac = self.transform.grad_log_abs_det_jacobian(&z);
        let grad_z: Vec<f64> = grad_theta
            .iter()
            .zip(jac_diag.iter())
            .zip(grad_log_jac.iter())
            .map(|((&gt, &jd), &glj)| gt * jd + glj)
            .collect();
        Ok(grad_z)
    }
}

impl PyPosterior {
    fn param_idx(&self, name: &str) -> PyResult<usize> {
        self.name_to_idx
            .get(name)
            .copied()
            .ok_or_else(|| PyValueError::new_err(format!("Unknown parameter name {name:?}")))
    }

    fn prior_logpdf(&self, theta: &[f64]) -> PyResult<f64> {
        let mut lp = 0.0;
        for (th, pr) in theta.iter().copied().zip(self.priors.iter()) {
            lp += pr.logpdf(th)?;
        }
        Ok(lp)
    }

    fn add_prior_grad(&self, theta: &[f64], grad_theta: &mut [f64]) -> PyResult<()> {
        debug_assert_eq!(theta.len(), grad_theta.len());
        for i in 0..theta.len() {
            grad_theta[i] += self.priors[i].grad(theta[i])?;
        }
        Ok(())
    }
}

/// Python wrapper for HistFactoryModel
#[pyclass(name = "HistFactoryModel")]
struct PyHistFactoryModel {
    inner: RustModel,
}

#[pymethods]
impl PyHistFactoryModel {
    /// Create model from workspace JSON string (auto-detects pyhf vs HS3 format).
    #[staticmethod]
    fn from_workspace(json_str: &str) -> PyResult<Self> {
        let format = ns_translate::hs3::detect::detect_format(json_str);
        match format {
            ns_translate::hs3::detect::WorkspaceFormat::Hs3 => Self::from_hs3(json_str, None, None),
            _ => {
                let workspace: RustWorkspace = serde_json::from_str(json_str).map_err(|e| {
                    PyValueError::new_err(format!("Failed to parse workspace: {}", e))
                })?;
                let model = RustModel::from_workspace(&workspace)
                    .map_err(|e| PyValueError::new_err(format!("Failed to create model: {}", e)))?;
                Ok(PyHistFactoryModel { inner: model })
            }
        }
    }

    /// Load model from HS3 JSON string.
    ///
    /// Args:
    ///     json_str: HS3 JSON string.
    ///     analysis: Optional analysis name (default: first analysis).
    ///     param_points: Optional parameter points set name (default: "default_values").
    #[staticmethod]
    #[pyo3(signature = (json_str, analysis=None, param_points=None))]
    fn from_hs3(
        json_str: &str,
        analysis: Option<&str>,
        param_points: Option<&str>,
    ) -> PyResult<Self> {
        let model = ns_translate::hs3::convert::from_hs3(
            json_str,
            analysis,
            param_points,
            ns_translate::pyhf::NormSysInterpCode::Code1,
            ns_translate::pyhf::HistoSysInterpCode::Code0,
        )
        .map_err(|e| PyValueError::new_err(format!("Failed to load HS3: {}", e)))?;
        Ok(PyHistFactoryModel { inner: model })
    }

    /// Create model from HistFactory XML (combination.xml + ROOT files)
    #[staticmethod]
    fn from_xml(xml_path: &str) -> PyResult<Self> {
        let path = std::path::Path::new(xml_path);
        let workspace = histfactory_from_xml(path).map_err(|e| {
            PyValueError::new_err(format!("Failed to parse HistFactory XML: {}", e))
        })?;

        let model = RustModel::from_workspace(&workspace)
            .map_err(|e| PyValueError::new_err(format!("Failed to create model: {}", e)))?;

        Ok(PyHistFactoryModel { inner: model })
    }

    /// Number of parameters.
    fn n_params(&self) -> usize {
        self.inner.n_params()
    }

    /// Alias: `dim()` matches the universal `LogDensityModel` naming.
    fn dim(&self) -> usize {
        self.n_params()
    }

    /// Compute negative log-likelihood
    fn nll(&self, params: &Bound<'_, PyAny>) -> PyResult<f64> {
        let params = extract_f64_vec(params)?;
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    /// Gradient of negative log-likelihood.
    fn grad_nll(&self, params: &Bound<'_, PyAny>) -> PyResult<Vec<f64>> {
        let params = extract_f64_vec(params)?;
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    /// Expected data matching `pyhf.Model.expected_data`.
    #[pyo3(signature = (params, *, include_auxdata=true))]
    fn expected_data(
        &self,
        params: &Bound<'_, PyAny>,
        include_auxdata: bool,
    ) -> PyResult<Vec<f64>> {
        let params = extract_f64_vec(params)?;
        let out = if include_auxdata {
            self.inner.expected_data_pyhf(&params)
        } else {
            self.inner.expected_data_pyhf_main(&params)
        };
        out.map_err(|e| PyValueError::new_err(format!("expected_data failed: {}", e)))
    }

    /// Return a copy of the model with overridden **main observations** (main bins only).
    ///
    /// Auxiliary constraints remain unchanged (consistent with Phase 1 toy smoke tests policy).
    fn with_observed_main(&self, observed_main: Vec<f64>) -> PyResult<Self> {
        let updated = self
            .inner
            .with_observed_main(&observed_main)
            .map_err(|e| PyValueError::new_err(format!("Failed to set observed data: {}", e)))?;
        Ok(PyHistFactoryModel { inner: updated })
    }

    /// Get parameter names in NextStat order.
    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameters().iter().map(|p| p.name.clone()).collect()
    }

    /// Get suggested initial values in NextStat order.
    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameters().iter().map(|p| p.init).collect()
    }

    /// Get suggested bounds in NextStat order.
    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameters().iter().map(|p| p.bounds).collect()
    }

    /// Get POI index in NextStat order.
    fn poi_index(&self) -> Option<usize> {
        self.inner.poi_index()
    }

    /// Observed main-bin counts per channel.
    ///
    /// Returns a list of dicts:
    /// - channel_name: str
    /// - y: list[float]  (main bins only)
    fn observed_main_by_channel<'py>(&self, py: Python<'py>) -> PyResult<Vec<Py<PyAny>>> {
        let rows: Vec<ObservedChannelData> = self.inner.observed_main_by_channel();
        rows.into_iter()
            .map(|row| {
                let d = PyDict::new(py);
                d.set_item("channel_name", row.channel_name)?;
                d.set_item("y", row.y)?;
                Ok(d.into_any().unbind())
            })
            .collect()
    }

    /// Expected main-bin yields per channel and per sample, without auxdata.
    ///
    /// Returns a list of dicts:
    /// - channel_name: str
    /// - samples: list[dict{sample_name: str, y: list[float]}]
    /// - total: list[float]
    fn expected_main_by_channel_sample<'py>(
        &self,
        py: Python<'py>,
        params: &Bound<'py, PyAny>,
    ) -> PyResult<Vec<Py<PyAny>>> {
        let params = extract_f64_vec(params)?;
        let rows: Vec<ExpectedChannelSampleYields> =
            self.inner.expected_main_by_channel_sample(&params).map_err(|e| {
                PyValueError::new_err(format!("expected_main_by_channel_sample failed: {}", e))
            })?;

        rows.into_iter()
            .map(|row| {
                let d = PyDict::new(py);
                d.set_item("channel_name", row.channel_name)?;
                let samples: Vec<Py<PyAny>> = row
                    .samples
                    .into_iter()
                    .map(|s: ExpectedSampleYields| {
                        let sd = PyDict::new(py);
                        sd.set_item("sample_name", s.sample_name)?;
                        sd.set_item("y", s.y)?;
                        Ok(sd.into_any().unbind())
                    })
                    .collect::<PyResult<Vec<_>>>()?;
                d.set_item("samples", samples)?;
                d.set_item("total", row.total)?;
                Ok(d.into_any().unbind())
            })
            .collect()
    }

    /// Override the **nominal yields** of a single sample (main bins only) in-place.
    ///
    /// This is intended for ML/RL loops where you want to repeatedly evaluate the model
    /// while varying a single sample's nominal histogram (e.g. signal yields from a NN).
    ///
    /// Notes:
    /// - The override is applied to main bins only (auxdata unchanged).
    /// - The sample must be override-safe (linear) as validated by the core model.
    #[pyo3(signature = (*, channel, sample, nominal))]
    fn set_sample_nominal(
        &mut self,
        channel: &str,
        sample: &str,
        nominal: &Bound<'_, PyAny>,
    ) -> PyResult<()> {
        let nominal = extract_f64_vec(nominal)?;
        if nominal.iter().any(|v| !v.is_finite()) {
            return Err(PyValueError::new_err("nominal must contain only finite values"));
        }
        self.inner
            .set_sample_nominal_by_name(channel, sample, &nominal)
            .map_err(|e| PyValueError::new_err(format!("Failed to set sample nominal: {}", e)))?;
        Ok(())
    }
}

// ---------------------------------------------------------------------------
// HEP / Unbinned (event-level) models (Phase 1+).
// ---------------------------------------------------------------------------

/// Python wrapper for `ns-unbinned::UnbinnedModel` (event-level likelihood).
#[pyclass(name = "UnbinnedModel")]
struct PyUnbinnedModel {
    inner: RustUnbinnedModel,
    schema_version: String,
}

#[pymethods]
impl PyUnbinnedModel {
    /// Compile an UnbinnedModel from a JSON/YAML spec file (`unbinned_spec_v0`).
    #[staticmethod]
    fn from_config(path: &str) -> PyResult<Self> {
        let path = std::path::Path::new(path);
        let spec = unbinned_spec::read_unbinned_spec(path)
            .map_err(|e| PyValueError::new_err(format!("Failed to read unbinned spec: {e}")))?;
        let model = unbinned_spec::compile_unbinned_model(&spec, path)
            .map_err(|e| PyValueError::new_err(format!("Failed to compile unbinned model: {e}")))?;
        Ok(Self { inner: model, schema_version: spec.schema_version })
    }

    /// Number of parameters.
    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    /// Alias: `dim()` matches the universal `LogDensityModel` naming.
    fn dim(&self) -> usize {
        self.n_params()
    }

    /// Spec `schema_version` used to construct this model.
    fn schema_version(&self) -> &str {
        &self.schema_version
    }

    /// Compute negative log-likelihood.
    fn nll(&self, params: &Bound<'_, PyAny>) -> PyResult<f64> {
        let params = extract_f64_vec(params)?;
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {e}")))
    }

    /// Gradient of negative log-likelihood.
    fn grad_nll(&self, params: &Bound<'_, PyAny>) -> PyResult<Vec<f64>> {
        let params = extract_f64_vec(params)?;
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {e}")))
    }

    /// Get parameter names in NextStat order.
    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    /// Get suggested initial values in NextStat order.
    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    /// Get suggested bounds in NextStat order.
    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }

    /// Get POI index in NextStat order (if defined in the spec).
    fn poi_index(&self) -> Option<usize> {
        self.inner.poi_index()
    }

    /// Return a copy of the model with a fixed parameter (bounds clamped to `(value, value)`).
    fn with_fixed_param(&self, param_idx: usize, value: f64) -> Self {
        Self {
            inner: self.inner.with_fixed_param(param_idx, value),
            schema_version: self.schema_version.clone(),
        }
    }
}

// ---------------------------------------------------------------------------
// Hybrid (binned+unbinned) likelihood (Phase 4).
// ---------------------------------------------------------------------------

/// Python wrapper for `HybridLikelihood<HistFactoryModel, UnbinnedModel>`.
///
/// Combines a binned (HistFactory) and an unbinned (event-level) model into a
/// single likelihood with shared parameters matched by name.
#[pyclass(name = "HybridModel")]
struct PyHybridModel {
    inner: RustHybridModel,
}

#[pymethods]
impl PyHybridModel {
    /// Build a hybrid model from a binned workspace and an unbinned spec.
    ///
    /// Args:
    ///     binned: `HistFactoryModel` (binned component).
    ///     unbinned: `UnbinnedModel` (unbinned component).
    ///     poi_from: Which model provides the POI: `"binned"` (default) or `"unbinned"`.
    #[staticmethod]
    #[pyo3(signature = (binned, unbinned, poi_from = "binned"))]
    fn from_models(
        binned: &PyHistFactoryModel,
        unbinned: &PyUnbinnedModel,
        poi_from: &str,
    ) -> PyResult<Self> {
        let map = SharedParameterMap::build(&binned.inner, &unbinned.inner)
            .map_err(|e| PyValueError::new_err(format!("SharedParameterMap build failed: {e}")))?;

        let map = match poi_from {
            "binned" => {
                if let Some(poi) = binned.inner.poi_index() {
                    map.with_poi_from_a(poi)
                } else {
                    map
                }
            }
            "unbinned" => {
                if let Some(poi) = unbinned.inner.poi_index() {
                    map.with_poi_from_b(poi)
                } else {
                    map
                }
            }
            other => {
                return Err(PyValueError::new_err(format!(
                    "poi_from must be 'binned' or 'unbinned', got '{other}'"
                )));
            }
        };

        let hybrid = HybridLikelihood::new(binned.inner.clone(), unbinned.inner.clone(), map);
        Ok(Self { inner: hybrid })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: &Bound<'_, PyAny>) -> PyResult<f64> {
        let params = extract_f64_vec(params)?;
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {e}")))
    }

    fn grad_nll(&self, params: &Bound<'_, PyAny>) -> PyResult<Vec<f64>> {
        let params = extract_f64_vec(params)?;
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {e}")))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }

    fn poi_index(&self) -> Option<usize> {
        self.inner.poi_index()
    }

    /// Number of shared parameters between binned and unbinned components.
    fn n_shared(&self) -> usize {
        self.inner.parameter_map().n_shared()
    }

    fn with_fixed_param(&self, param_idx: usize, value: f64) -> Self {
        Self { inner: self.inner.with_fixed_param(param_idx, value) }
    }
}

// ---------------------------------------------------------------------------
// Neural PDFs (Phase 3): FlowPdf + DcrSurrogate (feature-gated).
// ---------------------------------------------------------------------------

#[cfg(feature = "neural")]
use ns_unbinned::DcrSurrogate as RustDcrSurrogate;
#[cfg(feature = "neural")]
use ns_unbinned::FlowPdf as RustFlowPdf;
#[cfg(feature = "neural")]
use ns_unbinned::{EventStore, ObservableSpec};

/// Python wrapper for `ns-unbinned::FlowPdf` (ONNX normalizing flow).
///
/// Requires the `neural` feature.
#[cfg(feature = "neural")]
#[pyclass(name = "FlowPdf")]
struct PyFlowPdf {
    inner: RustFlowPdf,
}

#[cfg(feature = "neural")]
#[pymethods]
impl PyFlowPdf {
    /// Load a flow PDF from a manifest file.
    ///
    /// Args:
    ///     manifest_path: Path to `flow_manifest.json`.
    ///     context_param_indices: Maps each context feature to a global parameter index.
    ///         For unconditional flows, pass an empty list.
    #[staticmethod]
    fn from_manifest(manifest_path: &str, context_param_indices: Vec<usize>) -> PyResult<Self> {
        let path = std::path::Path::new(manifest_path);
        let flow = RustFlowPdf::from_manifest(path, &context_param_indices)
            .map_err(|e| PyValueError::new_err(format!("Failed to load FlowPdf: {e}")))?;
        Ok(Self { inner: flow })
    }

    /// Number of context (shape) parameters.
    fn n_context(&self) -> usize {
        ns_unbinned::UnbinnedPdf::n_params(&self.inner)
    }

    /// Whether this manifest contains a `sample` model.
    fn has_sample_model(&self) -> bool {
        self.inner.has_sample_model()
    }

    /// Whether this manifest contains an analytical `log_prob_grad` model.
    fn has_analytical_grad(&self) -> bool {
        self.inner.has_analytical_grad()
    }

    /// Whether GPU EP path for `log_prob` is currently available.
    fn has_gpu_logprob(&self) -> bool {
        #[cfg(any(feature = "neural-cuda", feature = "neural-tensorrt"))]
        {
            self.inner.has_gpu_logprob()
        }
        #[cfg(not(any(feature = "neural-cuda", feature = "neural-tensorrt")))]
        {
            false
        }
    }

    /// Whether GPU EP path for `log_prob_grad` is currently available.
    fn has_gpu_grad(&self) -> bool {
        #[cfg(any(feature = "neural-cuda", feature = "neural-tensorrt"))]
        {
            self.inner.has_gpu_grad()
        }
        #[cfg(not(any(feature = "neural-cuda", feature = "neural-tensorrt")))]
        {
            false
        }
    }

    /// Active GPU execution provider kind (`"cuda_ep"` or `"tensorrt_ep"`), if any.
    fn gpu_ep_kind(&self) -> Option<String> {
        #[cfg(any(feature = "neural-cuda", feature = "neural-tensorrt"))]
        {
            self.inner.gpu_ep_kind().map(|kind| match kind {
                ns_unbinned::FlowGpuEpKind::CudaEp => "cuda_ep".to_string(),
                ns_unbinned::FlowGpuEpKind::TensorRtEp => "tensorrt_ep".to_string(),
            })
        }
        #[cfg(not(any(feature = "neural-cuda", feature = "neural-tensorrt")))]
        {
            None
        }
    }

    /// Machine-readable capability flags for preflight checks in Python.
    fn capabilities(&self, py: Python<'_>) -> PyResult<Py<PyDict>> {
        let out = PyDict::new(py);
        out.set_item("has_sample_model", self.has_sample_model())?;
        out.set_item("has_analytical_grad", self.has_analytical_grad())?;
        out.set_item("has_gpu_logprob", self.has_gpu_logprob())?;
        out.set_item("has_gpu_grad", self.has_gpu_grad())?;
        out.set_item("gpu_ep_kind", self.gpu_ep_kind())?;
        Ok(out.unbind())
    }

    /// Observable names (length = features).
    fn observable_names(&self) -> Vec<String> {
        ns_unbinned::UnbinnedPdf::observables(&self.inner).to_vec()
    }

    /// Current log-normalization correction (approx 0 for well-trained flows).
    fn log_norm_correction(&self) -> f64 {
        self.inner.log_norm_correction()
    }

    /// Recompute the normalization correction for given parameters.
    fn update_normalization(&mut self, params: &Bound<'_, PyAny>) -> PyResult<()> {
        let params = extract_f64_vec(params)?;
        self.inner
            .update_normalization(&params)
            .map_err(|e| PyValueError::new_err(format!("update_normalization failed: {e}")))
    }

    /// Compute log-probabilities for a batch of events.
    ///
    /// Args:
    ///     events: dict mapping observable name -> list/array of float values.
    ///     bounds: dict mapping observable name -> (lo, hi) support bounds.
    ///     params: parameter vector (global model parameters).
    ///
    /// Returns:
    ///     List of log-probabilities (one per event).
    fn log_prob_batch(
        &self,
        events: &Bound<'_, PyDict>,
        bounds: &Bound<'_, PyDict>,
        params: &Bound<'_, PyAny>,
    ) -> PyResult<Vec<f64>> {
        let params = extract_f64_vec(params)?;

        let mut obs_specs = Vec::new();
        let mut columns = Vec::new();

        for (key, val) in events.iter() {
            let name: String = key.extract()?;
            let col: Vec<f64> = val.extract()?;

            let b: (f64, f64) = bounds
                .get_item(&name)?
                .ok_or_else(|| {
                    PyValueError::new_err(format!("missing bounds for observable '{name}'"))
                })?
                .extract()?;

            obs_specs.push(ObservableSpec::branch(name.clone(), b));
            columns.push((name, col));
        }

        let store = EventStore::from_columns(obs_specs, columns, None)
            .map_err(|e| PyValueError::new_err(format!("EventStore construction failed: {e}")))?;

        let n = store.n_events();
        let mut out = vec![0.0f64; n];

        ns_unbinned::UnbinnedPdf::log_prob_batch(&self.inner, &store, &params, &mut out)
            .map_err(|e| PyValueError::new_err(format!("log_prob_batch failed: {e}")))?;

        Ok(out)
    }
}

/// Python wrapper for `ns-unbinned::DcrSurrogate` (neural DCR surrogate).
///
/// Requires the `neural` feature.
#[cfg(feature = "neural")]
#[pyclass(name = "DcrSurrogate")]
struct PyDcrSurrogate {
    inner: RustDcrSurrogate,
}

#[cfg(feature = "neural")]
#[pymethods]
impl PyDcrSurrogate {
    /// Load a DCR surrogate from a flow manifest.
    ///
    /// Args:
    ///     manifest_path: Path to `flow_manifest.json`.
    ///     systematic_param_indices: Maps each systematic nuisance parameter to
    ///         its global parameter index.
    ///     systematic_names: Names of the systematic parameters.
    ///     process_name: Name of the process this surrogate replaces.
    #[staticmethod]
    fn from_manifest(
        manifest_path: &str,
        systematic_param_indices: Vec<usize>,
        systematic_names: Vec<String>,
        process_name: String,
    ) -> PyResult<Self> {
        let path = std::path::Path::new(manifest_path);
        let dcr = RustDcrSurrogate::from_manifest(
            path,
            &systematic_param_indices,
            systematic_names,
            process_name,
        )
        .map_err(|e| PyValueError::new_err(format!("Failed to load DcrSurrogate: {e}")))?;
        Ok(Self { inner: dcr })
    }

    /// Name of the process this surrogate replaces.
    fn process_name(&self) -> &str {
        self.inner.process_name()
    }

    /// Names of the systematic nuisance parameters.
    fn systematic_names(&self) -> Vec<String> {
        self.inner.systematic_names().to_vec()
    }

    /// Normalization tolerance.
    fn norm_tolerance(&self) -> f64 {
        self.inner.norm_tolerance()
    }

    /// Recompute normalization correction for current nuisance parameter values.
    fn update_normalization(&mut self, params: &Bound<'_, PyAny>) -> PyResult<()> {
        let params = extract_f64_vec(params)?;
        self.inner
            .update_normalization(&params)
            .map_err(|e| PyValueError::new_err(format!("update_normalization failed: {e}")))
    }

    /// Validate normalization at the nominal point (all systematics = 0).
    ///
    /// Returns:
    ///     Tuple (integral, deviation_from_1).
    fn validate_nominal_normalization(
        &mut self,
        params: &Bound<'_, PyAny>,
    ) -> PyResult<(f64, f64)> {
        let params = extract_f64_vec(params)?;
        self.inner.validate_nominal_normalization(&params).map_err(|e| {
            PyValueError::new_err(format!("validate_nominal_normalization failed: {e}"))
        })
    }

    /// Compute log-probabilities for a batch of events.
    ///
    /// Args:
    ///     events: dict mapping observable name -> list/array of float values.
    ///     bounds: dict mapping observable name -> (lo, hi) support bounds.
    ///     params: parameter vector (global model parameters).
    ///
    /// Returns:
    ///     List of log-probabilities (one per event).
    fn log_prob_batch(
        &self,
        events: &Bound<'_, PyDict>,
        bounds: &Bound<'_, PyDict>,
        params: &Bound<'_, PyAny>,
    ) -> PyResult<Vec<f64>> {
        let params = extract_f64_vec(params)?;

        let mut obs_specs = Vec::new();
        let mut columns = Vec::new();

        for (key, val) in events.iter() {
            let name: String = key.extract()?;
            let col: Vec<f64> = val.extract()?;

            let b: (f64, f64) = bounds
                .get_item(&name)?
                .ok_or_else(|| {
                    PyValueError::new_err(format!("missing bounds for observable '{name}'"))
                })?
                .extract()?;

            obs_specs.push(ObservableSpec::branch(name.clone(), b));
            columns.push((name, col));
        }

        let store = EventStore::from_columns(obs_specs, columns, None)
            .map_err(|e| PyValueError::new_err(format!("EventStore construction failed: {e}")))?;

        let n = store.n_events();
        let mut out = vec![0.0f64; n];

        ns_unbinned::UnbinnedPdf::log_prob_batch(&self.inner, &store, &params, &mut out)
            .map_err(|e| PyValueError::new_err(format!("log_prob_batch failed: {e}")))?;

        Ok(out)
    }
}

// ---------------------------------------------------------------------------
// Time series (Phase 8): Kalman filter / RTS smoother.
// ---------------------------------------------------------------------------

/// Python wrapper for `ns_inference::timeseries::kalman::KalmanModel`.
#[pyclass(name = "KalmanModel")]
struct PyKalmanModel {
    inner: RustKalmanModel,
}

#[pymethods]
impl PyKalmanModel {
    #[new]
    fn new(
        f: Vec<Vec<f64>>,
        q: Vec<Vec<f64>>,
        h: Vec<Vec<f64>>,
        r: Vec<Vec<f64>>,
        m0: Vec<f64>,
        p0: Vec<Vec<f64>>,
    ) -> PyResult<Self> {
        let f = dmatrix_from_nested("F", f)?;
        let q = dmatrix_from_nested("Q", q)?;
        let h = dmatrix_from_nested("H", h)?;
        let r = dmatrix_from_nested("R", r)?;
        let m0 = dvector_from_vec("m0", m0)?;
        let p0 = dmatrix_from_nested("P0", p0)?;

        let model = RustKalmanModel::new(f, q, h, r, m0, p0)
            .map_err(|e| PyValueError::new_err(format!("Failed to build KalmanModel: {}", e)))?;
        Ok(Self { inner: model })
    }

    fn n_state(&self) -> usize {
        self.inner.n_state()
    }

    fn n_obs(&self) -> usize {
        self.inner.n_obs()
    }
}

#[pyfunction]
fn kalman_filter(
    py: Python<'_>,
    model: &PyKalmanModel,
    ys: Vec<Vec<Option<f64>>>,
) -> PyResult<Py<PyAny>> {
    let ys: Vec<DVector<f64>> = ys
        .into_iter()
        .enumerate()
        .map(|(t, y)| dvector_from_opt_vec(&format!("y[{t}]"), y))
        .collect::<PyResult<Vec<_>>>()?;

    let fr = rust_kalman_filter(&model.inner, &ys)
        .map_err(|e| PyValueError::new_err(format!("kalman_filter failed: {}", e)))?;

    let out = PyDict::new(py);
    out.set_item("log_likelihood", fr.log_likelihood)?;
    out.set_item(
        "predicted_means",
        fr.predicted_means.iter().map(dvector_to_vec).collect::<Vec<_>>(),
    )?;
    out.set_item(
        "predicted_covs",
        fr.predicted_covs.iter().map(dmatrix_to_nested).collect::<Vec<_>>(),
    )?;
    out.set_item(
        "filtered_means",
        fr.filtered_means.iter().map(dvector_to_vec).collect::<Vec<_>>(),
    )?;
    out.set_item(
        "filtered_covs",
        fr.filtered_covs.iter().map(dmatrix_to_nested).collect::<Vec<_>>(),
    )?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
fn kalman_smooth(
    py: Python<'_>,
    model: &PyKalmanModel,
    ys: Vec<Vec<Option<f64>>>,
) -> PyResult<Py<PyAny>> {
    let ys: Vec<DVector<f64>> = ys
        .into_iter()
        .enumerate()
        .map(|(t, y)| dvector_from_opt_vec(&format!("y[{t}]"), y))
        .collect::<PyResult<Vec<_>>>()?;

    let fr = rust_kalman_filter(&model.inner, &ys)
        .map_err(|e| PyValueError::new_err(format!("kalman_filter failed: {}", e)))?;
    let sr = rust_rts_smoother(&model.inner, &fr)
        .map_err(|e| PyValueError::new_err(format!("rts_smoother failed: {}", e)))?;

    let out = PyDict::new(py);
    out.set_item("log_likelihood", fr.log_likelihood)?;
    out.set_item(
        "filtered_means",
        fr.filtered_means.iter().map(dvector_to_vec).collect::<Vec<_>>(),
    )?;
    out.set_item(
        "filtered_covs",
        fr.filtered_covs.iter().map(dmatrix_to_nested).collect::<Vec<_>>(),
    )?;
    out.set_item(
        "smoothed_means",
        sr.smoothed_means.iter().map(dvector_to_vec).collect::<Vec<_>>(),
    )?;
    out.set_item(
        "smoothed_covs",
        sr.smoothed_covs.iter().map(dmatrix_to_nested).collect::<Vec<_>>(),
    )?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (model, ys, *, max_iter=50, tol=1e-6, estimate_q=true, estimate_r=true, estimate_f=false, estimate_h=false, min_diag=1e-12))]
fn kalman_em(
    py: Python<'_>,
    model: &PyKalmanModel,
    ys: Vec<Vec<Option<f64>>>,
    max_iter: usize,
    tol: f64,
    estimate_q: bool,
    estimate_r: bool,
    estimate_f: bool,
    estimate_h: bool,
    min_diag: f64,
) -> PyResult<Py<PyAny>> {
    let ys: Vec<DVector<f64>> = ys
        .into_iter()
        .enumerate()
        .map(|(t, y)| dvector_from_opt_vec(&format!("y[{t}]"), y))
        .collect::<PyResult<Vec<_>>>()?;

    let cfg = RustKalmanEmConfig {
        max_iter,
        tol,
        estimate_q,
        estimate_r,
        estimate_f,
        estimate_h,
        min_diag,
    };

    let res = rust_kalman_em(&model.inner, &ys, cfg)
        .map_err(|e| PyValueError::new_err(format!("kalman_em failed: {}", e)))?;

    let out = PyDict::new(py);
    out.set_item("converged", res.converged)?;
    out.set_item("n_iter", res.n_iter)?;
    out.set_item("loglik_trace", res.loglik_trace)?;
    out.set_item("f", dmatrix_to_nested(&res.model.f))?;
    out.set_item("h", dmatrix_to_nested(&res.model.h))?;
    out.set_item("q", dmatrix_to_nested(&res.model.q))?;
    out.set_item("r", dmatrix_to_nested(&res.model.r))?;
    out.set_item("model", Py::new(py, PyKalmanModel { inner: res.model })?)?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (model, ys, *, steps=1, alpha=None))]
fn kalman_forecast(
    py: Python<'_>,
    model: &PyKalmanModel,
    ys: Vec<Vec<Option<f64>>>,
    steps: usize,
    alpha: Option<f64>,
) -> PyResult<Py<PyAny>> {
    let ys: Vec<DVector<f64>> = ys
        .into_iter()
        .enumerate()
        .map(|(t, y)| dvector_from_opt_vec(&format!("y[{t}]"), y))
        .collect::<PyResult<Vec<_>>>()?;

    let fr = rust_kalman_filter(&model.inner, &ys)
        .map_err(|e| PyValueError::new_err(format!("kalman_filter failed: {}", e)))?;
    let fc = rust_kalman_forecast(&model.inner, &fr, steps)
        .map_err(|e| PyValueError::new_err(format!("kalman_forecast failed: {}", e)))?;

    let out = PyDict::new(py);
    out.set_item("state_means", fc.state_means.iter().map(dvector_to_vec).collect::<Vec<_>>())?;
    out.set_item("state_covs", fc.state_covs.iter().map(dmatrix_to_nested).collect::<Vec<_>>())?;
    out.set_item("obs_means", fc.obs_means.iter().map(dvector_to_vec).collect::<Vec<_>>())?;
    out.set_item("obs_covs", fc.obs_covs.iter().map(dmatrix_to_nested).collect::<Vec<_>>())?;
    if let Some(alpha) = alpha {
        let iv = rust_kalman_forecast_intervals(&fc, alpha).map_err(|e| {
            PyValueError::new_err(format!("kalman_forecast_intervals failed: {}", e))
        })?;
        out.set_item("alpha", iv.alpha)?;
        out.set_item("z", iv.z)?;
        out.set_item("obs_lower", iv.obs_lower.iter().map(dvector_to_vec).collect::<Vec<_>>())?;
        out.set_item("obs_upper", iv.obs_upper.iter().map(dvector_to_vec).collect::<Vec<_>>())?;
    }

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (model, *, t_max, seed=42, init="sample", x0=None))]
fn kalman_simulate(
    py: Python<'_>,
    model: &PyKalmanModel,
    t_max: usize,
    seed: u64,
    init: &str,
    x0: Option<Vec<f64>>,
) -> PyResult<Py<PyAny>> {
    let x0 = if let Some(x0) = x0 {
        Some(dvector_from_vec("x0", x0)?)
    } else {
        match init {
            "sample" => None,
            "mean" => Some(model.inner.m0.clone()),
            _ => {
                return Err(PyValueError::new_err(
                    "init must be one of {'sample','mean'} (or pass x0=...)",
                ));
            }
        }
    };

    let sim = if let Some(x0) = x0 {
        rust_kalman_simulate_with_x0(&model.inner, t_max, seed, Some(x0))
    } else {
        rust_kalman_simulate(&model.inner, t_max, seed)
    }
    .map_err(|e| PyValueError::new_err(format!("kalman_simulate failed: {}", e)))?;

    let out = PyDict::new(py);
    out.set_item("xs", sim.xs.iter().map(dvector_to_vec).collect::<Vec<_>>())?;
    out.set_item("ys", sim.ys.iter().map(dvector_to_vec).collect::<Vec<_>>())?;
    Ok(out.into_any().unbind())
}

// ---------------------------------------------------------------------------
// Volatility (Econometrics): GARCH(1,1) + approximate SV (log-chi2 + Kalman).
// ---------------------------------------------------------------------------

#[pyfunction]
#[pyo3(signature = (ys, *, max_iter=1000, tol=1e-6, alpha_beta_max=0.999, min_var=1e-18))]
fn garch11_fit(
    py: Python<'_>,
    ys: Vec<f64>,
    max_iter: u64,
    tol: f64,
    alpha_beta_max: f64,
    min_var: f64,
) -> PyResult<Py<PyAny>> {
    let cfg = RustGarch11Config {
        alpha_beta_max,
        min_var,
        optimizer: ns_inference::optimizer::OptimizerConfig { max_iter, tol, ..Default::default() },
        ..Default::default()
    };

    let fit = rust_garch11_fit(&ys, cfg)
        .map_err(|e| PyValueError::new_err(format!("garch11_fit failed: {e}")))?;

    let params = PyDict::new(py);
    params.set_item("mu", fit.params.mu)?;
    params.set_item("omega", fit.params.omega)?;
    params.set_item("alpha", fit.params.alpha)?;
    params.set_item("beta", fit.params.beta)?;

    let out = PyDict::new(py);
    out.set_item("params", params)?;
    out.set_item("log_likelihood", fit.log_likelihood)?;
    out.set_item("conditional_variance", fit.conditional_variance.clone())?;
    out.set_item(
        "conditional_sigma",
        fit.conditional_variance.iter().map(|v| v.max(0.0).sqrt()).collect::<Vec<_>>(),
    )?;
    out.set_item("converged", fit.optimization.converged)?;
    out.set_item("n_iter", fit.optimization.n_iter)?;
    out.set_item("n_fev", fit.optimization.n_fev)?;
    out.set_item("n_gev", fit.optimization.n_gev)?;
    out.set_item("fval", fit.optimization.fval)?;
    out.set_item("message", fit.optimization.message)?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (ys, *, max_iter=1000, tol=1e-6, log_eps=1e-12))]
fn sv_logchi2_fit(
    py: Python<'_>,
    ys: Vec<f64>,
    max_iter: u64,
    tol: f64,
    log_eps: f64,
) -> PyResult<Py<PyAny>> {
    let cfg = RustSvLogChi2Config {
        log_eps,
        optimizer: ns_inference::optimizer::OptimizerConfig { max_iter, tol, ..Default::default() },
        ..Default::default()
    };

    let fit = rust_sv_logchi2_fit(&ys, cfg)
        .map_err(|e| PyValueError::new_err(format!("sv_logchi2_fit failed: {e}")))?;

    let params = PyDict::new(py);
    params.set_item("mu", fit.params.mu)?;
    params.set_item("phi", fit.params.phi)?;
    params.set_item("sigma", fit.params.sigma)?;

    let out = PyDict::new(py);
    out.set_item("params", params)?;
    out.set_item("log_likelihood", fit.log_likelihood)?;
    out.set_item("smoothed_h", fit.smoothed_h)?;
    out.set_item("smoothed_sigma", fit.smoothed_sigma)?;
    out.set_item("converged", fit.optimization.converged)?;
    out.set_item("n_iter", fit.optimization.n_iter)?;
    out.set_item("n_fev", fit.optimization.n_fev)?;
    out.set_item("n_gev", fit.optimization.n_gev)?;
    out.set_item("fval", fit.optimization.fval)?;
    out.set_item("message", fit.optimization.message)?;

    Ok(out.into_any().unbind())
}

// ---------------------------------------------------------------------------
// Volatility: EGARCH(1,1) + GJR-GARCH(1,1).
// ---------------------------------------------------------------------------

#[pyfunction]
#[pyo3(signature = (ys, *, max_iter=1000, tol=1e-6))]
fn egarch11_fit(py: Python<'_>, ys: Vec<f64>, max_iter: u64, tol: f64) -> PyResult<Py<PyAny>> {
    let cfg = RustEgarch11Config {
        optimizer: ns_inference::optimizer::OptimizerConfig { max_iter, tol, ..Default::default() },
        ..Default::default()
    };

    let fit = rust_egarch11_fit(&ys, cfg)
        .map_err(|e| PyValueError::new_err(format!("egarch11_fit failed: {e}")))?;

    let params = PyDict::new(py);
    params.set_item("mu", fit.params.mu)?;
    params.set_item("omega", fit.params.omega)?;
    params.set_item("alpha", fit.params.alpha)?;
    params.set_item("gamma", fit.params.gamma)?;
    params.set_item("beta", fit.params.beta)?;

    let out = PyDict::new(py);
    out.set_item("params", params)?;
    out.set_item("log_likelihood", fit.log_likelihood)?;
    out.set_item("conditional_variance", fit.conditional_variance.clone())?;
    out.set_item(
        "conditional_sigma",
        fit.conditional_variance.iter().map(|v| v.max(0.0).sqrt()).collect::<Vec<_>>(),
    )?;
    out.set_item("converged", fit.optimization.converged)?;
    out.set_item("n_iter", fit.optimization.n_iter)?;
    out.set_item("n_fev", fit.optimization.n_fev)?;
    out.set_item("n_gev", fit.optimization.n_gev)?;
    out.set_item("fval", fit.optimization.fval)?;
    out.set_item("message", fit.optimization.message)?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (ys, *, max_iter=1000, tol=1e-6, persistence_max=0.999, min_var=1e-18))]
fn gjr_garch11_fit(
    py: Python<'_>,
    ys: Vec<f64>,
    max_iter: u64,
    tol: f64,
    persistence_max: f64,
    min_var: f64,
) -> PyResult<Py<PyAny>> {
    let cfg = RustGjrGarch11Config {
        persistence_max,
        min_var,
        optimizer: ns_inference::optimizer::OptimizerConfig { max_iter, tol, ..Default::default() },
        ..Default::default()
    };

    let fit = rust_gjr_garch11_fit(&ys, cfg)
        .map_err(|e| PyValueError::new_err(format!("gjr_garch11_fit failed: {e}")))?;

    let params = PyDict::new(py);
    params.set_item("mu", fit.params.mu)?;
    params.set_item("omega", fit.params.omega)?;
    params.set_item("alpha", fit.params.alpha)?;
    params.set_item("gamma", fit.params.gamma)?;
    params.set_item("beta", fit.params.beta)?;

    let out = PyDict::new(py);
    out.set_item("params", params)?;
    out.set_item("log_likelihood", fit.log_likelihood)?;
    out.set_item("conditional_variance", fit.conditional_variance.clone())?;
    out.set_item(
        "conditional_sigma",
        fit.conditional_variance.iter().map(|v| v.max(0.0).sqrt()).collect::<Vec<_>>(),
    )?;
    out.set_item("converged", fit.optimization.converged)?;
    out.set_item("n_iter", fit.optimization.n_iter)?;
    out.set_item("n_fev", fit.optimization.n_fev)?;
    out.set_item("n_gev", fit.optimization.n_gev)?;
    out.set_item("fval", fit.optimization.fval)?;
    out.set_item("message", fit.optimization.message)?;

    Ok(out.into_any().unbind())
}

// ---------------------------------------------------------------------------
// Pharmacodynamic (PD) models: Emax, Sigmoid-Emax, IDR.
// ---------------------------------------------------------------------------

#[pyfunction]
#[pyo3(signature = (e0, emax, ec50, conc))]
fn emax_predict(
    py: Python<'_>,
    e0: f64,
    emax: f64,
    ec50: f64,
    conc: Vec<f64>,
) -> PyResult<Py<PyAny>> {
    let model = RustEmaxModel::new(e0, emax, ec50)
        .map_err(|e| PyValueError::new_err(format!("EmaxModel: {e}")))?;
    let predictions = model.predict_vec(&conc);

    let out = PyDict::new(py);
    out.set_item("predictions", predictions)?;
    out.set_item("e0", e0)?;
    out.set_item("emax", emax)?;
    out.set_item("ec50", ec50)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (e0, emax, ec50, conc, obs, *, error_model="additive", sigma=0.05, sigma_add=None))]
fn emax_nll(
    e0: f64,
    emax: f64,
    ec50: f64,
    conc: Vec<f64>,
    obs: Vec<f64>,
    error_model: &str,
    sigma: f64,
    sigma_add: Option<f64>,
) -> PyResult<f64> {
    let model = RustEmaxModel::new(e0, emax, ec50)
        .map_err(|e| PyValueError::new_err(format!("EmaxModel: {e}")))?;
    let em = parse_error_model(error_model, sigma, sigma_add)?;
    let nll =
        model.nll(&conc, &obs, &em).map_err(|e| PyValueError::new_err(format!("emax_nll: {e}")))?;
    Ok(nll)
}

#[pyfunction]
#[pyo3(signature = (e0, emax, ec50, gamma, conc))]
fn sigmoid_emax_predict(
    py: Python<'_>,
    e0: f64,
    emax: f64,
    ec50: f64,
    gamma: f64,
    conc: Vec<f64>,
) -> PyResult<Py<PyAny>> {
    let model = RustSigmoidEmaxModel::new(e0, emax, ec50, gamma)
        .map_err(|e| PyValueError::new_err(format!("SigmoidEmaxModel: {e}")))?;
    let predictions = model.predict_vec(&conc);

    let out = PyDict::new(py);
    out.set_item("predictions", predictions)?;
    out.set_item("e0", e0)?;
    out.set_item("emax", emax)?;
    out.set_item("ec50", ec50)?;
    out.set_item("gamma", gamma)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (e0, emax, ec50, gamma, conc, obs, *, error_model="additive", sigma=0.05, sigma_add=None))]
fn sigmoid_emax_nll(
    e0: f64,
    emax: f64,
    ec50: f64,
    gamma: f64,
    conc: Vec<f64>,
    obs: Vec<f64>,
    error_model: &str,
    sigma: f64,
    sigma_add: Option<f64>,
) -> PyResult<f64> {
    let model = RustSigmoidEmaxModel::new(e0, emax, ec50, gamma)
        .map_err(|e| PyValueError::new_err(format!("SigmoidEmaxModel: {e}")))?;
    let em = parse_error_model(error_model, sigma, sigma_add)?;
    let nll = model
        .nll(&conc, &obs, &em)
        .map_err(|e| PyValueError::new_err(format!("sigmoid_emax_nll: {e}")))?;
    Ok(nll)
}

fn parse_idr_type(s: &str) -> PyResult<RustIndirectResponseType> {
    match s.to_ascii_lowercase().replace('-', "_").as_str() {
        "inhibit_production" | "type_i" | "type1" => {
            Ok(RustIndirectResponseType::InhibitProduction)
        }
        "inhibit_loss" | "type_ii" | "type2" => Ok(RustIndirectResponseType::InhibitLoss),
        "stimulate_production" | "type_iii" | "type3" => {
            Ok(RustIndirectResponseType::StimulateProduction)
        }
        "stimulate_loss" | "type_iv" | "type4" => Ok(RustIndirectResponseType::StimulateLoss),
        _ => Err(PyValueError::new_err(
            "idr_type must be 'inhibit_production', 'inhibit_loss', 'stimulate_production', or 'stimulate_loss'",
        )),
    }
}

#[pyfunction]
#[pyo3(signature = (idr_type, kin, kout, max_effect, c50, conc_times, conc_values, output_times, *, r0=None))]
fn idr_simulate(
    py: Python<'_>,
    idr_type: &str,
    kin: f64,
    kout: f64,
    max_effect: f64,
    c50: f64,
    conc_times: Vec<f64>,
    conc_values: Vec<f64>,
    output_times: Vec<f64>,
    r0: Option<f64>,
) -> PyResult<Py<PyAny>> {
    let ty = parse_idr_type(idr_type)?;
    let model = RustIndirectResponseModel::new(ty, kin, kout, max_effect, c50)
        .map_err(|e| PyValueError::new_err(format!("IndirectResponseModel: {e}")))?;

    if conc_times.len() != conc_values.len() {
        return Err(PyValueError::new_err("conc_times and conc_values must have the same length"));
    }
    let conc_profile: Vec<(f64, f64)> = conc_times.into_iter().zip(conc_values).collect();

    let response = model
        .simulate(&conc_profile, &output_times, r0, None)
        .map_err(|e| PyValueError::new_err(format!("idr_simulate: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("times", output_times)?;
    out.set_item("response", response)?;
    out.set_item("baseline", model.baseline())?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (idr_type, kin, kout, max_effect, c50, conc_times, conc_values, obs_times, obs_values, *, error_model="additive", sigma=0.05, sigma_add=None, r0=None))]
fn idr_nll(
    idr_type: &str,
    kin: f64,
    kout: f64,
    max_effect: f64,
    c50: f64,
    conc_times: Vec<f64>,
    conc_values: Vec<f64>,
    obs_times: Vec<f64>,
    obs_values: Vec<f64>,
    error_model: &str,
    sigma: f64,
    sigma_add: Option<f64>,
    r0: Option<f64>,
) -> PyResult<f64> {
    let ty = parse_idr_type(idr_type)?;
    let model = RustIndirectResponseModel::new(ty, kin, kout, max_effect, c50)
        .map_err(|e| PyValueError::new_err(format!("IndirectResponseModel: {e}")))?;
    let em = parse_error_model(error_model, sigma, sigma_add)?;

    if conc_times.len() != conc_values.len() {
        return Err(PyValueError::new_err("conc_times and conc_values must have the same length"));
    }
    let conc_profile: Vec<(f64, f64)> = conc_times.into_iter().zip(conc_values).collect();

    let nll = model
        .nll(&conc_profile, &obs_times, &obs_values, &em, r0)
        .map_err(|e| PyValueError::new_err(format!("idr_nll: {e}")))?;
    Ok(nll)
}

// ---------------------------------------------------------------------------
// Competing Risks: CIF, Gray's test, Fine-Gray regression.
// ---------------------------------------------------------------------------

#[pyfunction]
#[pyo3(signature = (times, events, target_cause, *, conf_level=0.95))]
fn cumulative_incidence(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<u32>,
    target_cause: u32,
    conf_level: f64,
) -> PyResult<Py<PyAny>> {
    let est = rust_cumulative_incidence(&times, &events, target_cause, conf_level)
        .map_err(|e| PyValueError::new_err(format!("cumulative_incidence: {e}")))?;

    let step_times: Vec<f64> = est.steps.iter().map(|s| s.time).collect();
    let cif_values: Vec<f64> = est.steps.iter().map(|s| s.cif).collect();
    let se_values: Vec<f64> = est.steps.iter().map(|s| s.se).collect();
    let ci_lower: Vec<f64> = est.steps.iter().map(|s| s.ci_lower).collect();
    let ci_upper: Vec<f64> = est.steps.iter().map(|s| s.ci_upper).collect();

    let out = PyDict::new(py);
    out.set_item("cause", est.cause)?;
    out.set_item("times", step_times)?;
    out.set_item("cif", cif_values)?;
    out.set_item("se", se_values)?;
    out.set_item("ci_lower", ci_lower)?;
    out.set_item("ci_upper", ci_upper)?;
    out.set_item("n", est.n)?;
    out.set_item("n_events", est.n_events)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, groups, target_cause))]
fn gray_test(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<u32>,
    groups: Vec<usize>,
    target_cause: u32,
) -> PyResult<Py<PyAny>> {
    let result = rust_gray_test(&times, &events, &groups, target_cause)
        .map_err(|e| PyValueError::new_err(format!("gray_test: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("statistic", result.statistic)?;
    out.set_item("df", result.df)?;
    out.set_item("p_value", result.p_value)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, x, p, target_cause))]
fn fine_gray_fit(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<u32>,
    x: Vec<f64>,
    p: usize,
    target_cause: u32,
) -> PyResult<Py<PyAny>> {
    let n = times.len();
    if x.len() != n * p {
        return Err(PyValueError::new_err(format!(
            "x must have length n*p = {}*{} = {}, got {}",
            n,
            p,
            n * p,
            x.len()
        )));
    }
    let x_mat: Vec<Vec<f64>> = (0..n).map(|i| x[i * p..(i + 1) * p].to_vec()).collect();

    let result = rust_fine_gray_fit(&times, &events, &x_mat, target_cause)
        .map_err(|e| PyValueError::new_err(format!("fine_gray_fit: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("coefficients", result.coefficients)?;
    out.set_item("se", result.se)?;
    out.set_item("z", result.z)?;
    out.set_item("p_values", result.p_values)?;
    out.set_item("n", result.n)?;
    out.set_item("n_events", result.n_events)?;
    out.set_item("log_likelihood", result.log_likelihood)?;
    Ok(out.into_any().unbind())
}

// ---------------------------------------------------------------------------
// ODE PK models: Transit, Michaelis-Menten, TMDD.
// ---------------------------------------------------------------------------

fn parse_dose_route_ode(s: &str) -> PyResult<RustDoseRoute> {
    let s_lower = s.to_ascii_lowercase();
    if s_lower == "iv" || s_lower == "iv_bolus" {
        Ok(RustDoseRoute::IvBolus)
    } else if s_lower == "oral" {
        Ok(RustDoseRoute::Oral { bioavailability: 1.0 })
    } else if let Some(rest) = s_lower.strip_prefix("oral_f") {
        let f: f64 = rest
            .parse()
            .map_err(|_| PyValueError::new_err(format!("invalid oral bioavailability: {s}")))?;
        Ok(RustDoseRoute::Oral { bioavailability: f })
    } else if let Some(rest) = s_lower.strip_prefix("infusion_") {
        let dur_str = rest.trim_end_matches('h');
        let dur: f64 = dur_str
            .parse()
            .map_err(|_| PyValueError::new_err(format!("invalid infusion duration: {s}")))?;
        Ok(RustDoseRoute::Infusion { duration: dur })
    } else {
        Err(PyValueError::new_err(format!(
            "dose_route must be 'iv', 'oral', 'oral_f0.8', or 'infusion_1h', got '{s}'"
        )))
    }
}

fn build_ode_system(
    model_type: &str,
    params: &[f64],
) -> PyResult<(Box<dyn ns_inference::ode_adaptive::OdeSystem>, usize, usize)> {
    // Returns (system, dose_compartment_default, obs_compartment_default)
    match model_type {
        "transit_1cpt" => {
            if params.len() != 4 {
                return Err(PyValueError::new_err(
                    "transit_1cpt needs 4 params: [n_transit, ktr, cl, v1]",
                ));
            }
            let n_transit = params[0] as usize;
            let sys = ParameterizedTransitOde {
                n_transit,
                n_compartments: 1,
                ktr: params[1],
                cl: params[2],
                v1: params[3],
                q: 0.0,
                v2: 0.0,
            };
            Ok((Box::new(sys), 0, n_transit)) // dose to first transit, observe central
        }
        "transit_2cpt" => {
            if params.len() != 6 {
                return Err(PyValueError::new_err(
                    "transit_2cpt needs 6 params: [n_transit, ktr, cl, v1, q, v2]",
                ));
            }
            let n_transit = params[0] as usize;
            let sys = ParameterizedTransitOde {
                n_transit,
                n_compartments: 2,
                ktr: params[1],
                cl: params[2],
                v1: params[3],
                q: params[4],
                v2: params[5],
            };
            Ok((Box::new(sys), 0, n_transit))
        }
        "mm_1cpt" => {
            if params.len() != 3 {
                return Err(PyValueError::new_err("mm_1cpt needs 3 params: [vmax, km, v1]"));
            }
            let sys = MichaelisMentenPkOde::new_1cpt(params[0], params[1], params[2]);
            Ok((Box::new(sys), 0, 0))
        }
        "mm_2cpt" => {
            if params.len() != 5 {
                return Err(PyValueError::new_err("mm_2cpt needs 5 params: [vmax, km, v1, q, v2]"));
            }
            let sys = MichaelisMentenPkOde::new_2cpt(
                params[0], params[1], params[2], params[3], params[4],
            );
            Ok((Box::new(sys), 0, 0))
        }
        "tmdd" => {
            if params.len() != 7 {
                return Err(PyValueError::new_err(
                    "tmdd needs 7 params: [kon, koff, kel, ksyn, kdeg, kint, v]",
                ));
            }
            let sys = TmddOde::new(
                params[0], params[1], params[2], params[3], params[4], params[5], params[6],
            );
            Ok((Box::new(sys), 0, 0))
        }
        _ => Err(PyValueError::new_err(format!(
            "model_type must be 'transit_1cpt', 'transit_2cpt', 'mm_1cpt', 'mm_2cpt', or 'tmdd', got '{model_type}'"
        ))),
    }
}

fn parse_ode_solver_type(s: &str) -> PyResult<OdeSolverType> {
    match s.to_ascii_lowercase().as_str() {
        "rk45" => Ok(OdeSolverType::Rk45),
        "esdirk4" => Ok(OdeSolverType::Esdirk4),
        "lsoda" => Ok(OdeSolverType::Lsoda),
        _ => Err(PyValueError::new_err("solver must be 'rk45', 'esdirk4', or 'lsoda'")),
    }
}

#[pyfunction]
#[pyo3(signature = (model_type, params, dose_times, dose_amounts, dose_routes, obs_times, *, obs_compartment=None, dose_compartment=None, solver="rk45", rtol=1e-8, atol=1e-10))]
fn ode_pk_solve(
    py: Python<'_>,
    model_type: &str,
    params: Vec<f64>,
    dose_times: Vec<f64>,
    dose_amounts: Vec<f64>,
    dose_routes: Vec<String>,
    obs_times: Vec<f64>,
    obs_compartment: Option<usize>,
    dose_compartment: Option<usize>,
    solver: &str,
    rtol: f64,
    atol: f64,
) -> PyResult<Py<PyAny>> {
    let (system, default_dose_cpt, default_obs_cpt) = build_ode_system(model_type, &params)?;

    let n_doses = dose_times.len();
    if dose_amounts.len() != n_doses || dose_routes.len() != n_doses {
        return Err(PyValueError::new_err(
            "dose_times, dose_amounts, dose_routes must have the same length",
        ));
    }

    let doses: Vec<RustDoseEvent> = dose_times
        .into_iter()
        .zip(dose_amounts)
        .zip(dose_routes)
        .map(|((t, a), r)| {
            Ok(RustDoseEvent { time: t, amount: a, route: parse_dose_route_ode(&r)? })
        })
        .collect::<PyResult<Vec<_>>>()?;

    let solver_type = parse_ode_solver_type(solver)?;
    let opts = OdeSolverOptions { rtol, atol, ..Default::default() };
    let pk_solver = OdePkSolver::new(system, solver_type, opts);

    let dose_cpt = dose_compartment.unwrap_or(default_dose_cpt);
    let obs_cpt = obs_compartment.unwrap_or(default_obs_cpt);

    let result = pk_solver
        .solve(&doses, &obs_times, dose_cpt, obs_cpt)
        .map_err(|e| PyValueError::new_err(format!("ode_pk_solve: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("concentrations", result.concentrations)?;
    out.set_item("times", result.times)?;
    out.set_item("auc", result.auc)?;
    out.set_item("cmax", result.cmax)?;
    out.set_item("tmax", result.tmax)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (model_type, params, dose_times, dose_amounts, dose_routes, obs_times, obs_values, *, sigma=0.05, obs_compartment=None, dose_compartment=None, solver="rk45", rtol=1e-8, atol=1e-10))]
#[allow(clippy::too_many_arguments)]
fn ode_pk_nll_py(
    model_type: &str,
    params: Vec<f64>,
    dose_times: Vec<f64>,
    dose_amounts: Vec<f64>,
    dose_routes: Vec<String>,
    obs_times: Vec<f64>,
    obs_values: Vec<f64>,
    sigma: f64,
    obs_compartment: Option<usize>,
    dose_compartment: Option<usize>,
    solver: &str,
    rtol: f64,
    atol: f64,
) -> PyResult<f64> {
    let (system, default_dose_cpt, default_obs_cpt) = build_ode_system(model_type, &params)?;

    let n_doses = dose_times.len();
    if dose_amounts.len() != n_doses || dose_routes.len() != n_doses {
        return Err(PyValueError::new_err(
            "dose_times, dose_amounts, dose_routes must have the same length",
        ));
    }

    let doses: Vec<RustDoseEvent> = dose_times
        .into_iter()
        .zip(dose_amounts)
        .zip(dose_routes)
        .map(|((t, a), r)| {
            Ok(RustDoseEvent { time: t, amount: a, route: parse_dose_route_ode(&r)? })
        })
        .collect::<PyResult<Vec<_>>>()?;

    let solver_type = parse_ode_solver_type(solver)?;
    let opts = OdeSolverOptions { rtol, atol, ..Default::default() };
    let pk_solver = OdePkSolver::new(system, solver_type, opts);

    let dose_cpt = dose_compartment.unwrap_or(default_dose_cpt);
    let obs_cpt = obs_compartment.unwrap_or(default_obs_cpt);

    let nll =
        rust_ode_pk_nll(&pk_solver, &doses, &obs_times, &obs_values, dose_cpt, obs_cpt, sigma)
            .map_err(|e| PyValueError::new_err(format!("ode_pk_nll: {e}")))?;
    Ok(nll)
}

// ---------------------------------------------------------------------------
// Econometrics & Causal Inference (Phase 12).
// ---------------------------------------------------------------------------

#[pyfunction]
#[pyo3(signature = (y, x, entity_ids, p, *, time_ids=None, cluster_ids=None))]
fn panel_fe(
    py: Python<'_>,
    y: Vec<f64>,
    x: Vec<f64>,
    entity_ids: Vec<u64>,
    p: usize,
    time_ids: Option<Vec<u64>>,
    cluster_ids: Option<Vec<u64>>,
) -> PyResult<Py<PyAny>> {
    let res = ns_inference::econometrics::panel::panel_fe_fit(
        &entity_ids,
        time_ids.as_deref(),
        &x,
        &y,
        p,
        cluster_ids.as_deref(),
    )
    .map_err(|e| PyValueError::new_err(format!("panel_fe failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("coefficients", res.coefficients)?;
    out.set_item("se_ols", res.se_ols)?;
    out.set_item("se_cluster", res.se_cluster)?;
    out.set_item("r_squared_within", res.r_squared_within)?;
    out.set_item("n_obs", res.n_obs)?;
    out.set_item("n_entities", res.n_entities)?;
    out.set_item("n_time_periods", res.n_time_periods)?;
    out.set_item("n_regressors", res.n_regressors)?;
    out.set_item("df_absorbed", res.df_absorbed)?;
    out.set_item("rss", res.rss)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (y, treat, post, cluster_ids))]
fn did(
    py: Python<'_>,
    y: Vec<f64>,
    treat: Vec<u8>,
    post: Vec<u8>,
    cluster_ids: Vec<u64>,
) -> PyResult<Py<PyAny>> {
    let res = ns_inference::econometrics::did::did_canonical(&y, &treat, &post, &cluster_ids)
        .map_err(|e| PyValueError::new_err(format!("did failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("att", res.att)?;
    out.set_item("se", res.se)?;
    out.set_item("se_cluster", res.se_cluster)?;
    out.set_item("t_stat", res.t_stat)?;
    out.set_item("mean_treated_post", res.mean_treated_post)?;
    out.set_item("mean_treated_pre", res.mean_treated_pre)?;
    out.set_item("mean_control_post", res.mean_control_post)?;
    out.set_item("mean_control_pre", res.mean_control_pre)?;
    out.set_item("n_obs", res.n_obs)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (y, entity_ids, time_ids, relative_time, min_lag, max_lag, reference_period, cluster_ids))]
fn event_study(
    py: Python<'_>,
    y: Vec<f64>,
    entity_ids: Vec<u64>,
    time_ids: Vec<u64>,
    relative_time: Vec<i64>,
    min_lag: i64,
    max_lag: i64,
    reference_period: i64,
    cluster_ids: Vec<u64>,
) -> PyResult<Py<PyAny>> {
    let res = ns_inference::econometrics::did::event_study(
        &y,
        &entity_ids,
        &time_ids,
        &relative_time,
        min_lag,
        max_lag,
        reference_period,
        &cluster_ids,
    )
    .map_err(|e| PyValueError::new_err(format!("event_study failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("relative_times", res.relative_times)?;
    out.set_item("coefficients", res.coefficients)?;
    out.set_item("se_cluster", res.se_cluster)?;
    out.set_item("ci_lower", res.ci_lower)?;
    out.set_item("ci_upper", res.ci_upper)?;
    out.set_item("n_obs", res.n_obs)?;
    out.set_item("reference_period", res.reference_period)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (y, x_exog, k_exog, x_endog, k_endog, z, m, *, exog_names=None, endog_names=None, cluster_ids=None))]
fn iv_2sls(
    py: Python<'_>,
    y: Vec<f64>,
    x_exog: Vec<f64>,
    k_exog: usize,
    x_endog: Vec<f64>,
    k_endog: usize,
    z: Vec<f64>,
    m: usize,
    exog_names: Option<Vec<String>>,
    endog_names: Option<Vec<String>>,
    cluster_ids: Option<Vec<u64>>,
) -> PyResult<Py<PyAny>> {
    let exog_n = exog_names.unwrap_or_default();
    let endog_n = endog_names.unwrap_or_default();

    let res = ns_inference::econometrics::iv::iv_2sls(
        &y,
        &x_exog,
        k_exog,
        &x_endog,
        k_endog,
        &z,
        m,
        &exog_n,
        &endog_n,
        cluster_ids.as_deref(),
    )
    .map_err(|e| PyValueError::new_err(format!("iv_2sls failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("coefficients", res.coefficients)?;
    out.set_item("names", res.names)?;
    out.set_item("se", res.se)?;
    out.set_item("se_cluster", res.se_cluster)?;
    out.set_item("n_obs", res.n_obs)?;
    out.set_item("n_instruments", res.n_instruments)?;

    let first_stage_list = PyList::empty(py);
    for fs in &res.first_stage {
        let d = PyDict::new(py);
        d.set_item("f_stat", fs.f_stat)?;
        d.set_item("r_squared", fs.r_squared)?;
        d.set_item("partial_r_squared", fs.partial_r_squared)?;
        d.set_item("passes_stock_yogo_10", fs.passes_stock_yogo_10)?;
        first_stage_list.append(d)?;
    }
    out.set_item("first_stage", first_stage_list)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (y, treat, propensity, mu1, mu0, *, trim=0.01))]
fn aipw_ate(
    py: Python<'_>,
    y: Vec<f64>,
    treat: Vec<u8>,
    propensity: Vec<f64>,
    mu1: Vec<f64>,
    mu0: Vec<f64>,
    trim: f64,
) -> PyResult<Py<PyAny>> {
    let res = ns_inference::econometrics::aipw::aipw_ate(&y, &treat, &propensity, &mu1, &mu0, trim)
        .map_err(|e| PyValueError::new_err(format!("aipw_ate failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("ate", res.ate)?;
    out.set_item("se", res.se)?;
    out.set_item("ci_lower", res.ci_lower)?;
    out.set_item("ci_upper", res.ci_upper)?;
    out.set_item("n_treated", res.n_treated)?;
    out.set_item("n_control", res.n_control)?;
    out.set_item("mean_propensity", res.mean_propensity)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (y_treated, y_control, gammas))]
fn rosenbaum_bounds(
    py: Python<'_>,
    y_treated: Vec<f64>,
    y_control: Vec<f64>,
    gammas: Vec<f64>,
) -> PyResult<Py<PyAny>> {
    let res = ns_inference::econometrics::aipw::rosenbaum_bounds(&y_treated, &y_control, &gammas)
        .map_err(|e| PyValueError::new_err(format!("rosenbaum_bounds failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("gammas", res.gammas)?;
    out.set_item("p_upper", res.p_upper)?;
    out.set_item("p_lower", res.p_lower)?;
    out.set_item("gamma_critical", res.gamma_critical)?;
    Ok(out.into_any().unbind())
}

// ---------------------------------------------------------------------------
// Survival: Kaplan-Meier + Log-rank (non-parametric)
// ---------------------------------------------------------------------------

#[pyfunction]
#[pyo3(signature = (times, events, *, conf_level=0.95))]
fn kaplan_meier(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<bool>,
    conf_level: f64,
) -> PyResult<Py<PyAny>> {
    let est = ns_inference::kaplan_meier(&times, &events, conf_level)
        .map_err(|e| PyValueError::new_err(format!("kaplan_meier failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("n", est.n)?;
    out.set_item("n_events", est.n_events)?;
    out.set_item("conf_level", est.conf_level)?;
    out.set_item("median", est.median)?;

    let step_times = PyList::new(py, est.steps.iter().map(|s| s.time))?;
    let step_n_risk = PyList::new(py, est.steps.iter().map(|s| s.n_risk))?;
    let step_n_events = PyList::new(py, est.steps.iter().map(|s| s.n_events))?;
    let step_n_censored = PyList::new(py, est.steps.iter().map(|s| s.n_censored))?;
    let step_survival = PyList::new(py, est.steps.iter().map(|s| s.survival))?;
    let step_variance = PyList::new(py, est.steps.iter().map(|s| s.variance))?;
    let step_ci_lower = PyList::new(py, est.steps.iter().map(|s| s.ci_lower))?;
    let step_ci_upper = PyList::new(py, est.steps.iter().map(|s| s.ci_upper))?;

    out.set_item("time", step_times)?;
    out.set_item("n_risk", step_n_risk)?;
    out.set_item("n_event", step_n_events)?;
    out.set_item("n_censored", step_n_censored)?;
    out.set_item("survival", step_survival)?;
    out.set_item("variance", step_variance)?;
    out.set_item("ci_lower", step_ci_lower)?;
    out.set_item("ci_upper", step_ci_upper)?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, groups))]
fn log_rank_test(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<bool>,
    groups: Vec<i64>,
) -> PyResult<Py<PyAny>> {
    let res = ns_inference::log_rank_test(&times, &events, &groups)
        .map_err(|e| PyValueError::new_err(format!("log_rank_test failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("n", res.n)?;
    out.set_item("chi_squared", res.chi_squared)?;
    out.set_item("df", res.df)?;
    out.set_item("p_value", res.p_value)?;

    let grp_ids = PyList::new(py, res.group_summaries.iter().map(|(g, _, _)| *g))?;
    let grp_obs = PyList::new(py, res.group_summaries.iter().map(|(_, o, _)| *o))?;
    let grp_exp = PyList::new(py, res.group_summaries.iter().map(|(_, _, e)| *e))?;

    out.set_item("group_ids", grp_ids)?;
    out.set_item("observed", grp_obs)?;
    out.set_item("expected", grp_exp)?;

    Ok(out.into_any().unbind())
}

// ---------------------------------------------------------------------------
// Churn / Subscription vertical
// ---------------------------------------------------------------------------

#[pyfunction]
#[pyo3(signature = (*, n_customers=2000, n_cohorts=6, max_time=24.0, treatment_fraction=0.3, seed=42))]
fn churn_generate_data(
    py: Python<'_>,
    n_customers: usize,
    n_cohorts: usize,
    max_time: f64,
    treatment_fraction: f64,
    seed: u64,
) -> PyResult<Py<PyAny>> {
    let config = ns_inference::ChurnDataConfig {
        n_customers,
        n_cohorts,
        max_time,
        treatment_fraction,
        seed,
        ..Default::default()
    };
    let ds = ns_inference::generate_churn_dataset(&config)
        .map_err(|e| PyValueError::new_err(format!("churn_generate_data failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("n", ds.records.len())?;
    out.set_item("n_events", ds.events.iter().filter(|&&e| e).count())?;
    out.set_item("times", PyList::new(py, &ds.times)?)?;
    out.set_item("events", PyList::new(py, &ds.events)?)?;
    out.set_item("groups", PyList::new(py, &ds.groups)?)?;
    out.set_item("treated", PyList::new(py, ds.records.iter().map(|r| r.treated))?)?;
    out.set_item("covariates", &ds.covariates)?;
    out.set_item(
        "covariate_names",
        vec!["plan_basic", "plan_premium", "usage_score", "support_tickets"],
    )?;

    let plans = PyList::new(py, ds.records.iter().map(|r| r.plan))?;
    let regions = PyList::new(py, ds.records.iter().map(|r| r.region))?;
    let cohorts = PyList::new(py, ds.records.iter().map(|r| r.cohort))?;
    let usage = PyList::new(py, ds.records.iter().map(|r| r.usage_score))?;
    out.set_item("plan", plans)?;
    out.set_item("region", regions)?;
    out.set_item("cohort", cohorts)?;
    out.set_item("usage_score", usage)?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, groups, *, conf_level=0.95))]
fn churn_retention(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<bool>,
    groups: Vec<i64>,
    conf_level: f64,
) -> PyResult<Py<PyAny>> {
    let ra = ns_inference::retention_analysis(&times, &events, &groups, conf_level)
        .map_err(|e| PyValueError::new_err(format!("churn_retention failed: {e}")))?;

    let out = PyDict::new(py);

    // Overall KM summary.
    let overall = PyDict::new(py);
    overall.set_item("n", ra.overall.n)?;
    overall.set_item("n_events", ra.overall.n_events)?;
    overall.set_item("median", ra.overall.median)?;
    overall.set_item("time", PyList::new(py, ra.overall.steps.iter().map(|s| s.time))?)?;
    overall.set_item("survival", PyList::new(py, ra.overall.steps.iter().map(|s| s.survival))?)?;
    out.set_item("overall", overall)?;

    // Per-group.
    let by_group = PyList::empty(py);
    for (g, km) in &ra.by_group {
        let gd = PyDict::new(py);
        gd.set_item("group", *g)?;
        gd.set_item("n", km.n)?;
        gd.set_item("n_events", km.n_events)?;
        gd.set_item("median", km.median)?;
        gd.set_item("time", PyList::new(py, km.steps.iter().map(|s| s.time))?)?;
        gd.set_item("survival", PyList::new(py, km.steps.iter().map(|s| s.survival))?)?;
        by_group.append(gd)?;
    }
    out.set_item("by_group", by_group)?;

    // Log-rank.
    let lr = PyDict::new(py);
    lr.set_item("chi_squared", ra.log_rank.chi_squared)?;
    lr.set_item("df", ra.log_rank.df)?;
    lr.set_item("p_value", ra.log_rank.p_value)?;
    out.set_item("log_rank", lr)?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, covariates, names, *, conf_level=0.95))]
fn churn_risk_model(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<bool>,
    covariates: Vec<Vec<f64>>,
    names: Vec<String>,
    conf_level: f64,
) -> PyResult<Py<PyAny>> {
    let result = ns_inference::churn_risk_model(&times, &events, &covariates, &names, conf_level)
        .map_err(|e| PyValueError::new_err(format!("churn_risk_model failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("n", result.n)?;
    out.set_item("n_events", result.n_events)?;
    out.set_item("nll", result.nll)?;
    out.set_item("names", &result.names)?;
    out.set_item("coefficients", &result.coefficients)?;
    out.set_item("se", &result.se)?;
    out.set_item("hazard_ratios", &result.hazard_ratios)?;
    out.set_item("hr_ci_lower", &result.hr_ci_lower)?;
    out.set_item("hr_ci_upper", &result.hr_ci_upper)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, treated, covariates, *, horizon=12.0))]
fn churn_uplift(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<bool>,
    treated: Vec<u8>,
    covariates: Vec<Vec<f64>>,
    horizon: f64,
) -> PyResult<Py<PyAny>> {
    let result = ns_inference::churn_uplift(&times, &events, &treated, &covariates, horizon)
        .map_err(|e| PyValueError::new_err(format!("churn_uplift failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("ate", result.ate)?;
    out.set_item("se", result.se)?;
    out.set_item("ci_lower", result.ci_lower)?;
    out.set_item("ci_upper", result.ci_upper)?;
    out.set_item("n_treated", result.n_treated)?;
    out.set_item("n_control", result.n_control)?;
    out.set_item("gamma_critical", result.gamma_critical)?;
    out.set_item("horizon", horizon)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, groups, *, treated=vec![], covariates=vec![], covariate_names=vec![], trim=0.01))]
fn churn_diagnostics(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<bool>,
    groups: Vec<i64>,
    treated: Vec<u8>,
    covariates: Vec<Vec<f64>>,
    covariate_names: Vec<String>,
    trim: f64,
) -> PyResult<Py<PyAny>> {
    let r = ns_inference::churn_diagnostics_report(
        &times,
        &events,
        &groups,
        &treated,
        &covariates,
        &covariate_names,
        trim,
    )
    .map_err(|e| PyValueError::new_err(format!("churn_diagnostics failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("n", r.n)?;
    out.set_item("n_events", r.n_events)?;
    out.set_item("overall_censoring_frac", r.overall_censoring_frac)?;
    out.set_item("trust_gate_passed", r.trust_gate_passed)?;

    // Censoring by segment.
    let cens_list = PyList::empty(py);
    for seg in &r.censoring_by_segment {
        let d = PyDict::new(py);
        d.set_item("group", seg.group)?;
        d.set_item("n", seg.n)?;
        d.set_item("n_events", seg.n_events)?;
        d.set_item("n_censored", seg.n_censored)?;
        d.set_item("frac_censored", seg.frac_censored)?;
        cens_list.append(d)?;
    }
    out.set_item("censoring_by_segment", cens_list)?;

    // Covariate balance.
    let bal_list = PyList::empty(py);
    for b in &r.covariate_balance {
        let d = PyDict::new(py);
        d.set_item("name", &b.name)?;
        d.set_item("smd_raw", b.smd_raw)?;
        d.set_item("mean_treated", b.mean_treated)?;
        d.set_item("mean_control", b.mean_control)?;
        bal_list.append(d)?;
    }
    out.set_item("covariate_balance", bal_list)?;

    // Propensity overlap (optional).
    if let Some(ref po) = r.propensity_overlap {
        let pod = PyDict::new(py);
        pod.set_item("quantiles", po.quantiles.to_vec())?;
        pod.set_item("mean", po.mean)?;
        pod.set_item("n_trimmed_low", po.n_trimmed_low)?;
        pod.set_item("n_trimmed_high", po.n_trimmed_high)?;
        pod.set_item("trim", po.trim)?;
        out.set_item("propensity_overlap", pod)?;
    } else {
        out.set_item("propensity_overlap", py.None())?;
    }

    // Warnings.
    let warn_list = PyList::empty(py);
    for w in &r.warnings {
        let d = PyDict::new(py);
        d.set_item("category", &w.category)?;
        d.set_item("severity", &w.severity)?;
        d.set_item("message", &w.message)?;
        warn_list.append(d)?;
    }
    out.set_item("warnings", warn_list)?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, groups, period_boundaries))]
fn churn_cohort_matrix(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<bool>,
    groups: Vec<i64>,
    period_boundaries: Vec<f64>,
) -> PyResult<Py<PyAny>> {
    let r = ns_inference::cohort_retention_matrix(&times, &events, &groups, &period_boundaries)
        .map_err(|e| PyValueError::new_err(format!("churn_cohort_matrix failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("period_boundaries", &r.period_boundaries)?;

    // Cohort rows.
    let rows_list = PyList::empty(py);
    for row in &r.cohorts {
        let rd = PyDict::new(py);
        rd.set_item("cohort", row.cohort)?;
        rd.set_item("n_total", row.n_total)?;
        rd.set_item("n_events", row.n_events)?;
        let periods = PyList::empty(py);
        for cell in &row.periods {
            let cd = PyDict::new(py);
            cd.set_item("n_at_risk", cell.n_at_risk)?;
            cd.set_item("n_events", cell.n_events)?;
            cd.set_item("n_censored", cell.n_censored)?;
            cd.set_item("retention_rate", cell.retention_rate)?;
            cd.set_item("cumulative_retention", cell.cumulative_retention)?;
            periods.append(cd)?;
        }
        rd.set_item("periods", periods)?;
        rows_list.append(rd)?;
    }
    out.set_item("cohorts", rows_list)?;

    // Overall row.
    let od = PyDict::new(py);
    od.set_item("cohort", r.overall.cohort)?;
    od.set_item("n_total", r.overall.n_total)?;
    od.set_item("n_events", r.overall.n_events)?;
    let op = PyList::empty(py);
    for cell in &r.overall.periods {
        let cd = PyDict::new(py);
        cd.set_item("n_at_risk", cell.n_at_risk)?;
        cd.set_item("n_events", cell.n_events)?;
        cd.set_item("n_censored", cell.n_censored)?;
        cd.set_item("retention_rate", cell.retention_rate)?;
        cd.set_item("cumulative_retention", cell.cumulative_retention)?;
        op.append(cd)?;
    }
    od.set_item("periods", op)?;
    out.set_item("overall", od)?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, groups, *, conf_level=0.95, correction="benjamini_hochberg", alpha=0.05))]
fn churn_compare(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<bool>,
    groups: Vec<i64>,
    conf_level: f64,
    correction: &str,
    alpha: f64,
) -> PyResult<Py<PyAny>> {
    let corr = match correction {
        "bonferroni" => ns_inference::CorrectionMethod::Bonferroni,
        "benjamini_hochberg" | "bh" => ns_inference::CorrectionMethod::BenjaminiHochberg,
        other => {
            return Err(PyValueError::new_err(format!(
                "unknown correction method '{other}'; use 'bonferroni' or 'benjamini_hochberg'"
            )));
        }
    };

    let r =
        ns_inference::segment_comparison_report(&times, &events, &groups, conf_level, corr, alpha)
            .map_err(|e| PyValueError::new_err(format!("churn_compare failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("overall_chi_squared", r.overall_chi_squared)?;
    out.set_item("overall_p_value", r.overall_p_value)?;
    out.set_item("overall_df", r.overall_df)?;
    out.set_item("alpha", r.alpha)?;
    out.set_item("n", r.n)?;
    out.set_item("n_events", r.n_events)?;
    out.set_item("correction_method", correction)?;

    // Segments.
    let seg_list = PyList::empty(py);
    for s in &r.segments {
        let sd = PyDict::new(py);
        sd.set_item("group", s.group)?;
        sd.set_item("n", s.n)?;
        sd.set_item("n_events", s.n_events)?;
        sd.set_item("median", s.median)?;
        sd.set_item("observed", s.observed)?;
        sd.set_item("expected", s.expected)?;
        seg_list.append(sd)?;
    }
    out.set_item("segments", seg_list)?;

    // Pairwise comparisons.
    let pw_list = PyList::empty(py);
    for pw in &r.pairwise {
        let pd = PyDict::new(py);
        pd.set_item("group_a", pw.group_a)?;
        pd.set_item("group_b", pw.group_b)?;
        pd.set_item("chi_squared", pw.chi_squared)?;
        pd.set_item("p_value", pw.p_value)?;
        pd.set_item("p_adjusted", pw.p_adjusted)?;
        pd.set_item("hazard_ratio_proxy", pw.hazard_ratio_proxy)?;
        pd.set_item("median_diff", pw.median_diff)?;
        pd.set_item("significant", pw.significant)?;
        pw_list.append(pd)?;
    }
    out.set_item("pairwise", pw_list)?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, treated, *, covariates=vec![], horizon=12.0, eval_horizons=vec![3.0, 6.0, 12.0, 24.0], trim=0.01))]
fn churn_uplift_survival(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<bool>,
    treated: Vec<u8>,
    covariates: Vec<Vec<f64>>,
    horizon: f64,
    eval_horizons: Vec<f64>,
    trim: f64,
) -> PyResult<Py<PyAny>> {
    let r = ns_inference::survival_uplift_report(
        &times,
        &events,
        &treated,
        &covariates,
        horizon,
        &eval_horizons,
        trim,
    )
    .map_err(|e| PyValueError::new_err(format!("churn_uplift_survival failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("rmst_treated", r.rmst_treated)?;
    out.set_item("rmst_control", r.rmst_control)?;
    out.set_item("delta_rmst", r.delta_rmst)?;
    out.set_item("horizon", r.horizon)?;
    out.set_item("ipw_applied", r.ipw_applied)?;

    // Arms.
    let arms_list = PyList::empty(py);
    for arm in &r.arms {
        let ad = PyDict::new(py);
        ad.set_item("arm", &arm.arm)?;
        ad.set_item("n", arm.n)?;
        ad.set_item("n_events", arm.n_events)?;
        ad.set_item("rmst", arm.rmst)?;
        ad.set_item("median", arm.median)?;
        arms_list.append(ad)?;
    }
    out.set_item("arms", arms_list)?;

    // Survival diffs.
    let sd_list = PyList::empty(py);
    for sd in &r.survival_diffs {
        let dd = PyDict::new(py);
        dd.set_item("horizon", sd.horizon)?;
        dd.set_item("survival_treated", sd.survival_treated)?;
        dd.set_item("survival_control", sd.survival_control)?;
        dd.set_item("delta_survival", sd.delta_survival)?;
        sd_list.append(dd)?;
    }
    out.set_item("survival_diffs", sd_list)?;

    // Overlap.
    let ol = PyDict::new(py);
    ol.set_item("n_total", r.overlap.n_total)?;
    ol.set_item("n_after_trim", r.overlap.n_after_trim)?;
    ol.set_item("n_trimmed", r.overlap.n_trimmed)?;
    ol.set_item("mean_propensity", r.overlap.mean_propensity)?;
    ol.set_item("min_propensity", r.overlap.min_propensity)?;
    ol.set_item("max_propensity", r.overlap.max_propensity)?;
    ol.set_item("ess_treated", r.overlap.ess_treated)?;
    ol.set_item("ess_control", r.overlap.ess_control)?;
    out.set_item("overlap", ol)?;

    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, covariates, names, *, n_bootstrap=1000, seed=42, conf_level=0.95, ci_method="percentile", n_jackknife=200))]
fn churn_bootstrap_hr(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<bool>,
    covariates: Vec<Vec<f64>>,
    names: Vec<String>,
    n_bootstrap: usize,
    seed: u64,
    conf_level: f64,
    ci_method: &str,
    n_jackknife: usize,
) -> PyResult<Py<PyAny>> {
    let ci_method_norm = ci_method.trim().to_ascii_lowercase();
    let method = match ci_method_norm.as_str() {
        "percentile" => ns_inference::BootstrapCiMethod::Percentile,
        "bca" => ns_inference::BootstrapCiMethod::Bca,
        other => {
            return Err(PyValueError::new_err(format!(
                "invalid ci_method '{other}', expected 'percentile' or 'bca'"
            )));
        }
    };

    let r = ns_inference::bootstrap_hazard_ratios_with_method(
        &times,
        &events,
        &covariates,
        &names,
        n_bootstrap,
        seed,
        conf_level,
        method,
        n_jackknife,
    )
    .map_err(|e| PyValueError::new_err(format!("churn_bootstrap_hr failed: {e}")))?;

    let out = PyDict::new(py);
    out.set_item("names", &r.names)?;
    out.set_item("hr_point", &r.hr_point)?;
    out.set_item("hr_ci_lower", &r.hr_ci_lower)?;
    out.set_item("hr_ci_upper", &r.hr_ci_upper)?;
    out.set_item("n_bootstrap", r.n_bootstrap)?;
    out.set_item("n_jackknife_requested", r.n_jackknife_requested)?;
    out.set_item("n_jackknife_attempted", r.n_jackknife_attempted)?;
    out.set_item("n_converged", r.n_converged)?;
    out.set_item("elapsed_s", r.elapsed_s)?;
    out.set_item(
        "ci_method_requested",
        match r.ci_method_requested {
            ns_inference::BootstrapCiMethod::Percentile => "percentile",
            ns_inference::BootstrapCiMethod::Bca => "bca",
        },
    )?;

    let ci_method_effective = PyList::empty(py);
    for m in &r.ci_method_effective {
        ci_method_effective.append(match m {
            ns_inference::BootstrapCiMethod::Percentile => "percentile",
            ns_inference::BootstrapCiMethod::Bca => "bca",
        })?;
    }
    out.set_item("ci_method_effective", ci_method_effective)?;

    let diagnostics = PyList::empty(py);
    for d in &r.ci_diagnostics {
        let dd = PyDict::new(py);
        dd.set_item(
            "requested_method",
            match d.requested_method {
                ns_inference::BootstrapCiMethod::Percentile => "percentile",
                ns_inference::BootstrapCiMethod::Bca => "bca",
            },
        )?;
        dd.set_item(
            "effective_method",
            match d.effective_method {
                ns_inference::BootstrapCiMethod::Percentile => "percentile",
                ns_inference::BootstrapCiMethod::Bca => "bca",
            },
        )?;
        dd.set_item("z0", d.z0)?;
        dd.set_item("acceleration", d.acceleration)?;
        dd.set_item("alpha_low", d.alpha_low)?;
        dd.set_item("alpha_high", d.alpha_high)?;
        dd.set_item("alpha_low_adj", d.alpha_low_adj)?;
        dd.set_item("alpha_high_adj", d.alpha_high_adj)?;
        dd.set_item("n_bootstrap", d.n_bootstrap)?;
        dd.set_item("n_jackknife", d.n_jackknife)?;
        dd.set_item("fallback_reason", &d.fallback_reason)?;
        diagnostics.append(dd)?;
    }
    out.set_item("ci_diagnostics", diagnostics)?;
    Ok(out.into_any().unbind())
}

#[pyfunction]
#[pyo3(signature = (times, events, *, groups=None, treated=None, covariates=vec![], covariate_names=vec![], observation_end=None))]
fn churn_ingest(
    py: Python<'_>,
    times: Vec<f64>,
    events: Vec<bool>,
    groups: Option<Vec<i64>>,
    treated: Option<Vec<u8>>,
    covariates: Vec<Vec<f64>>,
    covariate_names: Vec<String>,
    observation_end: Option<f64>,
) -> PyResult<Py<PyAny>> {
    let r = ns_inference::ingest_churn_arrays(
        &times,
        &events,
        groups.as_deref(),
        treated.as_deref(),
        &covariates,
        &covariate_names,
        observation_end,
    )
    .map_err(|e| PyValueError::new_err(format!("churn_ingest failed: {e}")))?;

    let out = PyDict::new(py);
    let ds = &r.dataset;
    out.set_item("n", ds.records.len())?;
    out.set_item("n_events", ds.events.iter().filter(|&&e| e).count())?;
    out.set_item("times", PyList::new(py, &ds.times)?)?;
    out.set_item("events", PyList::new(py, &ds.events)?)?;
    out.set_item("groups", PyList::new(py, &ds.groups)?)?;
    out.set_item("treated", PyList::new(py, ds.records.iter().map(|r| r.treated))?)?;
    out.set_item("covariates", &ds.covariates)?;
    out.set_item("covariate_names", &r.covariate_names)?;
    out.set_item("n_dropped", r.n_dropped)?;
    out.set_item("warnings", &r.warnings)?;
    Ok(out.into_any().unbind())
}

// ---------------------------------------------------------------------------
// Minimal non-HEP model to exercise the generic sampling surface.
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct GaussianMeanModel {
    y: Vec<f64>,
    inv_var: f64,
    mean_y: f64,
}

impl GaussianMeanModel {
    fn new(y: Vec<f64>, sigma: f64) -> NsResult<Self> {
        if y.is_empty() {
            return Err(NsError::Validation("y must be non-empty".to_string()));
        }
        if !sigma.is_finite() || sigma <= 0.0 {
            return Err(NsError::Validation("sigma must be finite and > 0".to_string()));
        }
        let mean_y = y.iter().sum::<f64>() / (y.len() as f64);
        Ok(Self { y, inv_var: 1.0 / (sigma * sigma), mean_y })
    }
}

#[derive(Clone, Copy)]
struct PreparedGaussianMeanModel<'a> {
    model: &'a GaussianMeanModel,
}

impl PreparedNll for PreparedGaussianMeanModel<'_> {
    fn nll(&self, params: &[f64]) -> NsResult<f64> {
        self.model.nll(params)
    }
}

impl LogDensityModel for GaussianMeanModel {
    type Prepared<'a>
        = PreparedGaussianMeanModel<'a>
    where
        Self: 'a;

    fn dim(&self) -> usize {
        1
    }

    fn parameter_names(&self) -> Vec<String> {
        vec!["mu".to_string()]
    }

    fn parameter_bounds(&self) -> Vec<(f64, f64)> {
        vec![(f64::NEG_INFINITY, f64::INFINITY)]
    }

    fn parameter_init(&self) -> Vec<f64> {
        vec![self.mean_y]
    }

    fn nll(&self, params: &[f64]) -> NsResult<f64> {
        if params.len() != 1 {
            return Err(NsError::Validation("expected 1 parameter".to_string()));
        }
        let mu = params[0];
        if !mu.is_finite() {
            return Err(NsError::Validation("mu must be finite".to_string()));
        }
        // Constant terms don't matter for inference; keep a stable, simple NLL.
        let mut nll = 0.0;
        for &yi in &self.y {
            let r = yi - mu;
            nll += 0.5 * r * r * self.inv_var;
        }
        Ok(nll)
    }

    fn grad_nll(&self, params: &[f64]) -> NsResult<Vec<f64>> {
        if params.len() != 1 {
            return Err(NsError::Validation("expected 1 parameter".to_string()));
        }
        let mu = params[0];
        if !mu.is_finite() {
            return Err(NsError::Validation("mu must be finite".to_string()));
        }
        // d/dmu 0.5 * sum ((yi - mu)^2 / sigma^2) = sum ((mu - yi) / sigma^2)
        let mut g = 0.0;
        for &yi in &self.y {
            g += (mu - yi) * self.inv_var;
        }
        Ok(vec![g])
    }

    fn prepared(&self) -> Self::Prepared<'_> {
        PreparedGaussianMeanModel { model: self }
    }
}

// ---------------------------------------------------------------------------
// Stress toy model: Neal's funnel (N-D) for NUTS/MAMS stability checks.
//
// y ~ Normal(0, 3)
// x_i | y ~ Normal(0, exp(y/2))  for i = 1..d-1
//
// The 2D case (d=2) is the classic Neal's funnel. Higher dimensions make the
// narrow neck of the funnel harder to explore (d-1 coordinates all contract
// when y is very negative).
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct FunnelModel {
    d: usize,
}

impl FunnelModel {
    fn new(d: usize) -> Self {
        assert!(d >= 2, "FunnelModel requires d >= 2");
        Self { d }
    }
}

#[derive(Clone)]
struct PreparedFunnelModel<'a> {
    model: &'a FunnelModel,
}

impl PreparedNll for PreparedFunnelModel<'_> {
    fn nll(&self, params: &[f64]) -> NsResult<f64> {
        self.model.nll(params)
    }
}

impl LogDensityModel for FunnelModel {
    type Prepared<'a>
        = PreparedFunnelModel<'a>
    where
        Self: 'a;

    fn dim(&self) -> usize {
        self.d
    }

    fn parameter_names(&self) -> Vec<String> {
        let mut names = vec!["y".to_string()];
        for i in 1..self.d {
            names.push(format!("x[{}]", i));
        }
        names
    }

    fn parameter_bounds(&self) -> Vec<(f64, f64)> {
        vec![(f64::NEG_INFINITY, f64::INFINITY); self.d]
    }

    fn parameter_init(&self) -> Vec<f64> {
        vec![0.0; self.d]
    }

    fn nll(&self, params: &[f64]) -> NsResult<f64> {
        if params.len() != self.d {
            return Err(NsError::Validation(format!(
                "expected {} parameters, got {}",
                self.d,
                params.len()
            )));
        }
        if params.iter().any(|v| !v.is_finite()) {
            return Err(NsError::Validation("params must be finite".to_string()));
        }

        let y = params[0];
        let ln2pi = (2.0 * std::f64::consts::PI).ln();
        let dm1 = (self.d - 1) as f64;

        // y ~ Normal(0, 3)
        let nll_y = 0.5 * (y * y) / 9.0 + 3.0_f64.ln() + 0.5 * ln2pi;

        // x_i | y ~ Normal(0, exp(y/2)) => variance = exp(y)
        // nll per x_i = 0.5 * x_i^2 * exp(-y) + 0.5*y + 0.5*ln(2π)
        let exp_neg_y = (-y).exp();
        let sum_x2: f64 = params[1..].iter().map(|xi| xi * xi).sum();
        let nll_x = 0.5 * sum_x2 * exp_neg_y + 0.5 * dm1 * y + 0.5 * dm1 * ln2pi;

        Ok(nll_y + nll_x)
    }

    fn grad_nll(&self, params: &[f64]) -> NsResult<Vec<f64>> {
        if params.len() != self.d {
            return Err(NsError::Validation(format!(
                "expected {} parameters, got {}",
                self.d,
                params.len()
            )));
        }
        if params.iter().any(|v| !v.is_finite()) {
            return Err(NsError::Validation("params must be finite".to_string()));
        }

        let y = params[0];
        let dm1 = (self.d - 1) as f64;
        let exp_neg_y = (-y).exp();
        let sum_x2: f64 = params[1..].iter().map(|xi| xi * xi).sum();

        let mut grad = Vec::with_capacity(self.d);
        // d/dy: y/9 + 0.5*(d-1) - 0.5*sum(x_i^2)*exp(-y)
        grad.push(y / 9.0 + 0.5 * dm1 - 0.5 * sum_x2 * exp_neg_y);
        // d/dx_i: x_i * exp(-y)
        for xi in &params[1..] {
            grad.push(xi * exp_neg_y);
        }
        Ok(grad)
    }

    fn prepared(&self) -> Self::Prepared<'_> {
        PreparedFunnelModel { model: self }
    }
}

/// Python wrapper for FunnelModel (Neal's funnel, N-dimensional).
#[pyclass(name = "FunnelModel")]
struct PyFunnelModel {
    inner: FunnelModel,
}

#[pymethods]
impl PyFunnelModel {
    #[new]
    #[pyo3(signature = (dim=2))]
    fn new(dim: usize) -> Self {
        Self { inner: FunnelModel::new(dim) }
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

// ---------------------------------------------------------------------------
// Neal's funnel — Non-Centered Parameterization (NCP).
//
// v ~ Normal(0, 3)
// z_i ~ Normal(0, 1)        for i = 1..d-1
// x_i = exp(v/2) * z_i      (constrained / original parameterization)
//
// NLL = v²/18 + 0.5 * Σ z_i²  (independent normals — trivial geometry)
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct FunnelNcpModel {
    d: usize,
}

impl FunnelNcpModel {
    fn new(d: usize) -> Self {
        assert!(d >= 2, "FunnelNcpModel requires d >= 2");
        Self { d }
    }
}

#[derive(Clone)]
struct PreparedFunnelNcpModel<'a> {
    model: &'a FunnelNcpModel,
}

impl PreparedNll for PreparedFunnelNcpModel<'_> {
    fn nll(&self, params: &[f64]) -> NsResult<f64> {
        self.model.nll(params)
    }
}

impl LogDensityModel for FunnelNcpModel {
    type Prepared<'a>
        = PreparedFunnelNcpModel<'a>
    where
        Self: 'a;

    fn dim(&self) -> usize {
        self.d
    }

    fn parameter_names(&self) -> Vec<String> {
        let mut names = vec!["v".to_string()];
        for i in 1..self.d {
            names.push(format!("z[{}]", i));
        }
        names
    }

    fn parameter_bounds(&self) -> Vec<(f64, f64)> {
        vec![(f64::NEG_INFINITY, f64::INFINITY); self.d]
    }

    fn parameter_init(&self) -> Vec<f64> {
        vec![0.0; self.d]
    }

    fn nll(&self, params: &[f64]) -> NsResult<f64> {
        if params.len() != self.d {
            return Err(NsError::Validation(format!(
                "expected {} parameters, got {}",
                self.d,
                params.len()
            )));
        }
        if params.iter().any(|v| !v.is_finite()) {
            return Err(NsError::Validation("params must be finite".to_string()));
        }
        let v = params[0];
        let sum_z2: f64 = params[1..].iter().map(|zi| zi * zi).sum();
        // v ~ N(0, 9), z_i ~ N(0, 1) — independent
        Ok(v * v / 18.0 + 0.5 * sum_z2)
    }

    fn grad_nll(&self, params: &[f64]) -> NsResult<Vec<f64>> {
        if params.len() != self.d {
            return Err(NsError::Validation(format!(
                "expected {} parameters, got {}",
                self.d,
                params.len()
            )));
        }
        if params.iter().any(|v| !v.is_finite()) {
            return Err(NsError::Validation("params must be finite".to_string()));
        }
        let mut grad = Vec::with_capacity(self.d);
        grad.push(params[0] / 9.0);
        for zi in &params[1..] {
            grad.push(*zi);
        }
        Ok(grad)
    }

    fn prepared(&self) -> Self::Prepared<'_> {
        PreparedFunnelNcpModel { model: self }
    }
}

#[allow(dead_code)]
impl FunnelNcpModel {
    fn to_constrained(&self, params: &[f64]) -> Vec<f64> {
        // Transform NCP → original: v stays, x_i = exp(v/2) * z_i
        let v = params[0];
        let scale = (v * 0.5).exp();
        let mut out = Vec::with_capacity(self.d);
        out.push(v);
        for zi in &params[1..] {
            out.push(scale * zi);
        }
        out
    }

    fn constrained_parameter_names(&self) -> Vec<String> {
        let mut names = vec!["v".to_string()];
        for i in 1..self.d {
            names.push(format!("x[{}]", i));
        }
        names
    }
}

/// Python wrapper for FunnelNcpModel (Neal's funnel, non-centered parameterization).
#[pyclass(name = "FunnelNcpModel")]
struct PyFunnelNcpModel {
    inner: FunnelNcpModel,
}

#[pymethods]
impl PyFunnelNcpModel {
    #[new]
    #[pyo3(signature = (dim=10))]
    fn new(dim: usize) -> Self {
        Self { inner: FunnelNcpModel::new(dim) }
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for GaussianMeanModel.
#[pyclass(name = "GaussianMeanModel")]
struct PyGaussianMeanModel {
    inner: GaussianMeanModel,
}

#[pymethods]
impl PyGaussianMeanModel {
    #[new]
    fn new(y: Vec<f64>, sigma: f64) -> PyResult<Self> {
        let inner =
            GaussianMeanModel::new(y, sigma).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

// ---------------------------------------------------------------------------
// Minimal non-HEP model: standard normal in R^d (useful for perf/profiling).
// ---------------------------------------------------------------------------

#[derive(Debug, Clone)]
struct StdNormalModel {
    dim: usize,
}

impl StdNormalModel {
    fn new(dim: usize) -> NsResult<Self> {
        if dim == 0 {
            return Err(NsError::Validation("dim must be >= 1".to_string()));
        }
        Ok(Self { dim })
    }
}

#[derive(Clone, Copy)]
struct PreparedStdNormalModel<'a> {
    model: &'a StdNormalModel,
}

impl PreparedNll for PreparedStdNormalModel<'_> {
    fn nll(&self, params: &[f64]) -> NsResult<f64> {
        self.model.nll(params)
    }
}

impl LogDensityModel for StdNormalModel {
    type Prepared<'a>
        = PreparedStdNormalModel<'a>
    where
        Self: 'a;

    fn dim(&self) -> usize {
        self.dim
    }

    fn parameter_names(&self) -> Vec<String> {
        (0..self.dim).map(|i| format!("x{i}")).collect()
    }

    fn parameter_bounds(&self) -> Vec<(f64, f64)> {
        vec![(f64::NEG_INFINITY, f64::INFINITY); self.dim]
    }

    fn parameter_init(&self) -> Vec<f64> {
        vec![0.0; self.dim]
    }

    fn nll(&self, params: &[f64]) -> NsResult<f64> {
        if params.len() != self.dim {
            return Err(NsError::Validation(format!(
                "expected {} parameters, got {}",
                self.dim,
                params.len()
            )));
        }
        if params.iter().any(|v| !v.is_finite()) {
            return Err(NsError::Validation("params must be finite".to_string()));
        }
        // Standard normal: 0.5 * sum(x_i^2). Constants don't affect inference.
        Ok(0.5 * params.iter().map(|&v| v * v).sum::<f64>())
    }

    fn grad_nll(&self, params: &[f64]) -> NsResult<Vec<f64>> {
        if params.len() != self.dim {
            return Err(NsError::Validation(format!(
                "expected {} parameters, got {}",
                self.dim,
                params.len()
            )));
        }
        if params.iter().any(|v| !v.is_finite()) {
            return Err(NsError::Validation("params must be finite".to_string()));
        }
        Ok(params.to_vec())
    }

    fn prepared(&self) -> Self::Prepared<'_> {
        PreparedStdNormalModel { model: self }
    }
}

/// Python wrapper for `StdNormalModel` (standard normal in R^d).
#[pyclass(name = "StdNormalModel")]
struct PyStdNormalModel {
    inner: StdNormalModel,
}

#[pymethods]
impl PyStdNormalModel {
    #[new]
    #[pyo3(signature = (dim=1))]
    fn new(dim: usize) -> PyResult<Self> {
        let inner = StdNormalModel::new(dim).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

// ---------------------------------------------------------------------------
// Regression models (Phase 6).
// ---------------------------------------------------------------------------

/// Python wrapper for `LinearRegressionModel` (Gaussian, sigma fixed to 1).
#[pyclass(name = "LinearRegressionModel")]
struct PyLinearRegressionModel {
    inner: RustLinearRegressionModel,
}

#[pymethods]
impl PyLinearRegressionModel {
    #[new]
    #[pyo3(signature = (x, y, *, include_intercept=true))]
    fn new(x: Vec<Vec<f64>>, y: Vec<f64>, include_intercept: bool) -> PyResult<Self> {
        let inner = RustLinearRegressionModel::new(x, y, include_intercept)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `LogisticRegressionModel`.
#[pyclass(name = "LogisticRegressionModel")]
struct PyLogisticRegressionModel {
    inner: RustLogisticRegressionModel,
}

#[pymethods]
impl PyLogisticRegressionModel {
    #[new]
    #[pyo3(signature = (x, y, *, include_intercept=true))]
    fn new(x: Vec<Vec<f64>>, y: Vec<u8>, include_intercept: bool) -> PyResult<Self> {
        let inner = RustLogisticRegressionModel::new(x, y, include_intercept)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `OrderedLogitModel` (ordinal logistic regression).
#[pyclass(name = "OrderedLogitModel")]
struct PyOrderedLogitModel {
    inner: RustOrderedLogitModel,
}

#[pymethods]
impl PyOrderedLogitModel {
    #[new]
    #[pyo3(signature = (x, y, *, n_levels))]
    fn new(x: Vec<Vec<f64>>, y: Vec<u8>, n_levels: usize) -> PyResult<Self> {
        let inner = RustOrderedLogitModel::new(x, y, n_levels)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `OrderedProbitModel` (ordinal probit regression).
#[pyclass(name = "OrderedProbitModel")]
struct PyOrderedProbitModel {
    inner: RustOrderedProbitModel,
}

#[pymethods]
impl PyOrderedProbitModel {
    #[new]
    #[pyo3(signature = (x, y, *, n_levels))]
    fn new(x: Vec<Vec<f64>>, y: Vec<u8>, n_levels: usize) -> PyResult<Self> {
        let inner = RustOrderedProbitModel::new(x, y, n_levels)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `PoissonRegressionModel`.
#[pyclass(name = "PoissonRegressionModel")]
struct PyPoissonRegressionModel {
    inner: RustPoissonRegressionModel,
}

#[pymethods]
impl PyPoissonRegressionModel {
    #[new]
    #[pyo3(signature = (x, y, *, include_intercept=true, offset=None))]
    fn new(
        x: Vec<Vec<f64>>,
        y: Vec<u64>,
        include_intercept: bool,
        offset: Option<Vec<f64>>,
    ) -> PyResult<Self> {
        let inner = RustPoissonRegressionModel::new(x, y, include_intercept, offset)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `NegativeBinomialRegressionModel` (NB2 mean/dispersion).
#[pyclass(name = "NegativeBinomialRegressionModel")]
struct PyNegativeBinomialRegressionModel {
    inner: RustNegativeBinomialRegressionModel,
}

#[pymethods]
impl PyNegativeBinomialRegressionModel {
    #[new]
    #[pyo3(signature = (x, y, *, include_intercept=true, offset=None))]
    fn new(
        x: Vec<Vec<f64>>,
        y: Vec<u64>,
        include_intercept: bool,
        offset: Option<Vec<f64>>,
    ) -> PyResult<Self> {
        let inner = RustNegativeBinomialRegressionModel::new(x, y, include_intercept, offset)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `GammaRegressionModel` (Gamma GLM, log link).
#[pyclass(name = "GammaRegressionModel")]
struct PyGammaRegressionModel {
    inner: RustGammaRegressionModel,
}

#[pymethods]
impl PyGammaRegressionModel {
    #[new]
    #[pyo3(signature = (x, y, *, include_intercept=true))]
    fn new(x: Vec<Vec<f64>>, y: Vec<f64>, include_intercept: bool) -> PyResult<Self> {
        let inner = RustGammaRegressionModel::new(x, y, include_intercept)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }
    fn dim(&self) -> usize {
        self.inner.dim()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner.nll(&params).map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner.grad_nll(&params).map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }
    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }
    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `TweedieRegressionModel` (Tweedie GLM, log link, p ∈ (1,2)).
#[pyclass(name = "TweedieRegressionModel")]
struct PyTweedieRegressionModel {
    inner: RustTweedieRegressionModel,
}

#[pymethods]
impl PyTweedieRegressionModel {
    #[new]
    #[pyo3(signature = (x, y, *, p=1.5, include_intercept=true))]
    fn new(x: Vec<Vec<f64>>, y: Vec<f64>, p: f64, include_intercept: bool) -> PyResult<Self> {
        let inner = RustTweedieRegressionModel::new(x, y, include_intercept, p)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }
    fn dim(&self) -> usize {
        self.inner.dim()
    }
    fn power(&self) -> f64 {
        self.inner.power()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner.nll(&params).map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner.grad_nll(&params).map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }
    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }
    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `GevModel` (Generalized Extreme Value).
#[pyclass(name = "GevModel")]
struct PyGevModel {
    inner: RustGevModel,
}

#[pymethods]
impl PyGevModel {
    #[new]
    fn new(data: Vec<f64>) -> PyResult<Self> {
        let inner = RustGevModel::new(data).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }
    fn dim(&self) -> usize {
        self.inner.dim()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner.nll(&params).map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner.grad_nll(&params).map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }
    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }
    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }

    #[staticmethod]
    fn return_level(params: Vec<f64>, return_period: f64) -> PyResult<f64> {
        RustGevModel::return_level(&params, return_period)
            .map_err(|e| PyValueError::new_err(e.to_string()))
    }
}

/// Python wrapper for `GpdModel` (Generalized Pareto Distribution).
#[pyclass(name = "GpdModel")]
struct PyGpdModel {
    inner: RustGpdModel,
}

#[pymethods]
impl PyGpdModel {
    #[new]
    fn new(exceedances: Vec<f64>) -> PyResult<Self> {
        let inner =
            RustGpdModel::new(exceedances).map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }
    fn dim(&self) -> usize {
        self.inner.dim()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner.nll(&params).map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner.grad_nll(&params).map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }
    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }
    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }

    #[staticmethod]
    fn quantile(params: Vec<f64>, p: f64) -> PyResult<f64> {
        RustGpdModel::quantile(&params, p).map_err(|e| PyValueError::new_err(e.to_string()))
    }
}

/// Python wrapper for `EightSchoolsModel` (hierarchical, non-centered).
#[pyclass(name = "EightSchoolsModel")]
struct PyEightSchoolsModel {
    inner: RustEightSchoolsModel,
}

#[pymethods]
impl PyEightSchoolsModel {
    #[new]
    #[pyo3(signature = (y, sigma, *, prior_mu_sigma=5.0, prior_tau_scale=5.0))]
    fn new(
        y: Vec<f64>,
        sigma: Vec<f64>,
        prior_mu_sigma: f64,
        prior_tau_scale: f64,
    ) -> PyResult<Self> {
        let inner = RustEightSchoolsModel::new(y, sigma, prior_mu_sigma, prior_tau_scale)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }
    fn dim(&self) -> usize {
        self.inner.dim()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner.nll(&params).map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner.grad_nll(&params).map_err(|e| PyValueError::new_err(e.to_string()))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }
    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }
    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Fixed-effects meta-analysis (inverse-variance method).
#[pyfunction]
#[pyo3(signature = (estimates, standard_errors, *, labels=None, conf_level=0.95))]
fn meta_fixed(
    py: Python<'_>,
    estimates: Vec<f64>,
    standard_errors: Vec<f64>,
    labels: Option<Vec<String>>,
    conf_level: f64,
) -> PyResult<Py<PyAny>> {
    let studies = build_study_effects(&estimates, &standard_errors, labels.as_deref())?;
    let res =
        rust_meta_fixed(&studies, conf_level).map_err(|e| PyValueError::new_err(e.to_string()))?;
    meta_result_to_pydict(py, &res)
}

/// Random-effects meta-analysis (DerSimonian–Laird method).
#[pyfunction]
#[pyo3(signature = (estimates, standard_errors, *, labels=None, conf_level=0.95))]
fn meta_random(
    py: Python<'_>,
    estimates: Vec<f64>,
    standard_errors: Vec<f64>,
    labels: Option<Vec<String>>,
    conf_level: f64,
) -> PyResult<Py<PyAny>> {
    let studies = build_study_effects(&estimates, &standard_errors, labels.as_deref())?;
    let res =
        rust_meta_random(&studies, conf_level).map_err(|e| PyValueError::new_err(e.to_string()))?;
    meta_result_to_pydict(py, &res)
}

fn build_study_effects(
    estimates: &[f64],
    standard_errors: &[f64],
    labels: Option<&[String]>,
) -> PyResult<Vec<RustStudyEffect>> {
    if estimates.len() != standard_errors.len() {
        return Err(PyValueError::new_err("estimates and standard_errors must have same length"));
    }
    Ok(estimates
        .iter()
        .zip(standard_errors.iter())
        .enumerate()
        .map(|(i, (&est, &se))| RustStudyEffect {
            label: labels
                .and_then(|l| l.get(i))
                .cloned()
                .unwrap_or_else(|| format!("Study {}", i + 1)),
            estimate: est,
            se,
        })
        .collect())
}

fn meta_result_to_pydict(
    py: Python<'_>,
    res: &ns_inference::meta_analysis::MetaAnalysisResult,
) -> PyResult<Py<PyAny>> {
    let out = PyDict::new(py);
    out.set_item("estimate", res.estimate)?;
    out.set_item("se", res.se)?;
    out.set_item("ci_lower", res.ci_lower)?;
    out.set_item("ci_upper", res.ci_upper)?;
    out.set_item("z", res.z)?;
    out.set_item("p_value", res.p_value)?;
    out.set_item("method", res.method)?;
    out.set_item("conf_level", res.conf_level)?;
    out.set_item("k", res.k)?;

    let het = PyDict::new(py);
    het.set_item("q", res.heterogeneity.q)?;
    het.set_item("df", res.heterogeneity.df)?;
    het.set_item("p_value", res.heterogeneity.p_value)?;
    het.set_item("i_squared", res.heterogeneity.i_squared)?;
    het.set_item("h_squared", res.heterogeneity.h_squared)?;
    het.set_item("tau_squared", res.heterogeneity.tau_squared)?;
    out.set_item("heterogeneity", het)?;

    let forest: Vec<_> = res
        .forest
        .iter()
        .map(|r| {
            let d = PyDict::new(py);
            d.set_item("label", &r.label).unwrap();
            d.set_item("estimate", r.estimate).unwrap();
            d.set_item("se", r.se).unwrap();
            d.set_item("ci_lower", r.ci_lower).unwrap();
            d.set_item("ci_upper", r.ci_upper).unwrap();
            d.set_item("weight", r.weight).unwrap();
            d
        })
        .collect();
    out.set_item("forest", forest)?;

    Ok(out.into_any().unbind())
}

// ---------------------------------------------------------------------------
// Chain Ladder / Mack bindings
// ---------------------------------------------------------------------------

/// Deterministic Chain Ladder reserving from a cumulative claims triangle.
#[pyfunction]
#[pyo3(signature = (triangle))]
fn chain_ladder(py: Python<'_>, triangle: Vec<Vec<f64>>) -> PyResult<Py<PyAny>> {
    let tri = ClaimsTriangle::new(triangle).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let res = rust_chain_ladder(&tri).map_err(|e| PyValueError::new_err(e.to_string()))?;

    let out = PyDict::new(py);
    out.set_item("development_factors", &res.development_factors)?;
    out.set_item("cumulative_factors", &res.cumulative_factors)?;

    let ultimates: Vec<f64> = res.rows.iter().map(|r| r.ultimate).collect();
    let ibnr: Vec<f64> = res.rows.iter().map(|r| r.ibnr).collect();
    let latest: Vec<f64> = res.rows.iter().map(|r| r.latest).collect();
    out.set_item("ultimates", &ultimates)?;
    out.set_item("ibnr", &ibnr)?;
    out.set_item("latest", &latest)?;
    out.set_item("total_ibnr", res.total_ibnr)?;
    out.set_item("projected", &res.projected)?;

    Ok(out.into_any().unbind())
}

/// Mack Chain Ladder with prediction standard errors.
#[pyfunction]
#[pyo3(signature = (triangle, *, conf_level=0.95))]
fn mack_chain_ladder(
    py: Python<'_>,
    triangle: Vec<Vec<f64>>,
    conf_level: f64,
) -> PyResult<Py<PyAny>> {
    let tri = ClaimsTriangle::new(triangle).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let res = rust_mack_chain_ladder(&tri, conf_level)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;

    let out = PyDict::new(py);
    out.set_item("development_factors", &res.development_factors)?;
    out.set_item("sigma_sq", &res.sigma_sq)?;

    let ultimates: Vec<f64> = res.rows.iter().map(|r| r.ultimate).collect();
    let ibnr: Vec<f64> = res.rows.iter().map(|r| r.ibnr).collect();
    let latest: Vec<f64> = res.rows.iter().map(|r| r.latest).collect();
    let se: Vec<f64> = res.rows.iter().map(|r| r.se).collect();
    let cv: Vec<f64> = res.rows.iter().map(|r| r.cv).collect();
    let pi_lower: Vec<f64> = res.rows.iter().map(|r| r.pi_lower).collect();
    let pi_upper: Vec<f64> = res.rows.iter().map(|r| r.pi_upper).collect();

    out.set_item("ultimates", &ultimates)?;
    out.set_item("ibnr", &ibnr)?;
    out.set_item("latest", &latest)?;
    out.set_item("se", &se)?;
    out.set_item("cv", &cv)?;
    out.set_item("pi_lower", &pi_lower)?;
    out.set_item("pi_upper", &pi_upper)?;
    out.set_item("total_ibnr", res.total_ibnr)?;
    out.set_item("total_se", res.total_se)?;
    out.set_item("conf_level", res.conf_level)?;

    Ok(out.into_any().unbind())
}

/// Python wrapper for `ComposedGlmModel` built via `ModelBuilder`.
#[pyclass(name = "ComposedGlmModel")]
struct PyComposedGlmModel {
    inner: RustComposedGlmModel,
}

#[pymethods]
impl PyComposedGlmModel {
    /// Build a composed Gaussian linear regression model (optionally with inferred sigma_y).
    #[staticmethod]
    #[pyo3(signature = (x, y, *, include_intercept=true, group_idx=None, n_groups=None, coef_prior_mu=0.0, coef_prior_sigma=10.0, penalize_intercept=false, obs_sigma_prior_m=None, obs_sigma_prior_s=None, random_intercept_non_centered=false, random_slope_feature_idx=None, random_slope_non_centered=false, correlated_feature_idx=None, lkj_eta=1.0))]
    fn linear_regression(
        x: Vec<Vec<f64>>,
        y: Vec<f64>,
        include_intercept: bool,
        group_idx: Option<Vec<usize>>,
        n_groups: Option<usize>,
        coef_prior_mu: f64,
        coef_prior_sigma: f64,
        penalize_intercept: bool,
        obs_sigma_prior_m: Option<f64>,
        obs_sigma_prior_s: Option<f64>,
        random_intercept_non_centered: bool,
        random_slope_feature_idx: Option<usize>,
        random_slope_non_centered: bool,
        correlated_feature_idx: Option<usize>,
        lkj_eta: f64,
    ) -> PyResult<Self> {
        if group_idx.is_none() && n_groups.is_some() {
            return Err(PyValueError::new_err("n_groups requires group_idx"));
        }

        let mut b = RustModelBuilder::linear_regression(x, y, include_intercept)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        b = b
            .with_coef_prior_normal(coef_prior_mu, coef_prior_sigma)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        b = b.with_penalize_intercept(penalize_intercept);

        if obs_sigma_prior_m.is_some() != obs_sigma_prior_s.is_some() {
            return Err(PyValueError::new_err(
                "obs_sigma_prior_m and obs_sigma_prior_s must be set together",
            ));
        }
        if let (Some(m), Some(s)) = (obs_sigma_prior_m, obs_sigma_prior_s) {
            b = b
                .with_gaussian_obs_sigma_prior_lognormal((m, s))
                .map_err(|e| PyValueError::new_err(e.to_string()))?;
        }

        if correlated_feature_idx.is_some()
            && (random_slope_feature_idx.is_some()
                || random_intercept_non_centered
                || random_slope_non_centered)
        {
            return Err(PyValueError::new_err(
                "correlated_feature_idx cannot be combined with random_slope_feature_idx or non-centered toggles",
            ));
        }

        if let Some(group_idx) = group_idx {
            let ng = n_groups.unwrap_or_else(|| group_idx.iter().copied().max().unwrap_or(0) + 1);

            if let Some(feature_idx) = correlated_feature_idx {
                b = b
                    .with_correlated_random_intercept_slope(feature_idx, group_idx.clone(), ng)
                    .map_err(|e| PyValueError::new_err(e.to_string()))?;
                b = b
                    .with_correlated_lkj_eta(lkj_eta)
                    .map_err(|e| PyValueError::new_err(e.to_string()))?;
            } else {
                b = b
                    .with_random_intercept(group_idx.clone(), ng)
                    .map_err(|e| PyValueError::new_err(e.to_string()))?;
                if random_intercept_non_centered {
                    b = b
                        .with_random_intercept_non_centered(true)
                        .map_err(|e| PyValueError::new_err(e.to_string()))?;
                }

                if let Some(feature_idx) = random_slope_feature_idx {
                    b = b
                        .with_random_slope(feature_idx, group_idx, ng)
                        .map_err(|e| PyValueError::new_err(e.to_string()))?;
                    if random_slope_non_centered {
                        b = b
                            .with_random_slope_non_centered(true)
                            .map_err(|e| PyValueError::new_err(e.to_string()))?;
                    }
                }
            }
        } else if correlated_feature_idx.is_some() || random_slope_feature_idx.is_some() {
            return Err(PyValueError::new_err(
                "random slopes / correlated effects require group_idx",
            ));
        }

        let inner = b.build().map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    /// Build a composed logistic regression model (Bernoulli-logit).
    #[staticmethod]
    #[pyo3(signature = (x, y, *, include_intercept=true, group_idx=None, n_groups=None, coef_prior_mu=0.0, coef_prior_sigma=10.0, penalize_intercept=false, random_intercept_non_centered=false, random_slope_feature_idx=None, random_slope_non_centered=false, correlated_feature_idx=None, lkj_eta=1.0))]
    fn logistic_regression(
        x: Vec<Vec<f64>>,
        y: Vec<u8>,
        include_intercept: bool,
        group_idx: Option<Vec<usize>>,
        n_groups: Option<usize>,
        coef_prior_mu: f64,
        coef_prior_sigma: f64,
        penalize_intercept: bool,
        random_intercept_non_centered: bool,
        random_slope_feature_idx: Option<usize>,
        random_slope_non_centered: bool,
        correlated_feature_idx: Option<usize>,
        lkj_eta: f64,
    ) -> PyResult<Self> {
        if group_idx.is_none() && n_groups.is_some() {
            return Err(PyValueError::new_err("n_groups requires group_idx"));
        }

        let mut b = RustModelBuilder::logistic_regression(x, y, include_intercept)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        b = b
            .with_coef_prior_normal(coef_prior_mu, coef_prior_sigma)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        b = b.with_penalize_intercept(penalize_intercept);

        if correlated_feature_idx.is_some()
            && (random_slope_feature_idx.is_some()
                || random_intercept_non_centered
                || random_slope_non_centered)
        {
            return Err(PyValueError::new_err(
                "correlated_feature_idx cannot be combined with random_slope_feature_idx or non-centered toggles",
            ));
        }

        if let Some(group_idx) = group_idx {
            let ng = n_groups.unwrap_or_else(|| group_idx.iter().copied().max().unwrap_or(0) + 1);

            if let Some(feature_idx) = correlated_feature_idx {
                b = b
                    .with_correlated_random_intercept_slope(feature_idx, group_idx.clone(), ng)
                    .map_err(|e| PyValueError::new_err(e.to_string()))?;
                b = b
                    .with_correlated_lkj_eta(lkj_eta)
                    .map_err(|e| PyValueError::new_err(e.to_string()))?;
            } else {
                b = b
                    .with_random_intercept(group_idx.clone(), ng)
                    .map_err(|e| PyValueError::new_err(e.to_string()))?;
                if random_intercept_non_centered {
                    b = b
                        .with_random_intercept_non_centered(true)
                        .map_err(|e| PyValueError::new_err(e.to_string()))?;
                }

                if let Some(feature_idx) = random_slope_feature_idx {
                    b = b
                        .with_random_slope(feature_idx, group_idx, ng)
                        .map_err(|e| PyValueError::new_err(e.to_string()))?;
                    if random_slope_non_centered {
                        b = b
                            .with_random_slope_non_centered(true)
                            .map_err(|e| PyValueError::new_err(e.to_string()))?;
                    }
                }
            }
        } else if correlated_feature_idx.is_some() || random_slope_feature_idx.is_some() {
            return Err(PyValueError::new_err(
                "random slopes / correlated effects require group_idx",
            ));
        }

        let inner = b.build().map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    /// Build a composed Poisson regression model (log link) with optional offset.
    #[staticmethod]
    #[pyo3(signature = (x, y, *, include_intercept=true, offset=None, group_idx=None, n_groups=None, coef_prior_mu=0.0, coef_prior_sigma=10.0, penalize_intercept=false, random_intercept_non_centered=false, random_slope_feature_idx=None, random_slope_non_centered=false, correlated_feature_idx=None, lkj_eta=1.0))]
    fn poisson_regression(
        x: Vec<Vec<f64>>,
        y: Vec<u64>,
        include_intercept: bool,
        offset: Option<Vec<f64>>,
        group_idx: Option<Vec<usize>>,
        n_groups: Option<usize>,
        coef_prior_mu: f64,
        coef_prior_sigma: f64,
        penalize_intercept: bool,
        random_intercept_non_centered: bool,
        random_slope_feature_idx: Option<usize>,
        random_slope_non_centered: bool,
        correlated_feature_idx: Option<usize>,
        lkj_eta: f64,
    ) -> PyResult<Self> {
        if group_idx.is_none() && n_groups.is_some() {
            return Err(PyValueError::new_err("n_groups requires group_idx"));
        }

        let mut b = RustModelBuilder::poisson_regression(x, y, include_intercept, offset)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        b = b
            .with_coef_prior_normal(coef_prior_mu, coef_prior_sigma)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        b = b.with_penalize_intercept(penalize_intercept);

        if correlated_feature_idx.is_some()
            && (random_slope_feature_idx.is_some()
                || random_intercept_non_centered
                || random_slope_non_centered)
        {
            return Err(PyValueError::new_err(
                "correlated_feature_idx cannot be combined with random_slope_feature_idx or non-centered toggles",
            ));
        }

        if let Some(group_idx) = group_idx {
            let ng = n_groups.unwrap_or_else(|| group_idx.iter().copied().max().unwrap_or(0) + 1);

            if let Some(feature_idx) = correlated_feature_idx {
                b = b
                    .with_correlated_random_intercept_slope(feature_idx, group_idx.clone(), ng)
                    .map_err(|e| PyValueError::new_err(e.to_string()))?;
                b = b
                    .with_correlated_lkj_eta(lkj_eta)
                    .map_err(|e| PyValueError::new_err(e.to_string()))?;
            } else {
                b = b
                    .with_random_intercept(group_idx.clone(), ng)
                    .map_err(|e| PyValueError::new_err(e.to_string()))?;
                if random_intercept_non_centered {
                    b = b
                        .with_random_intercept_non_centered(true)
                        .map_err(|e| PyValueError::new_err(e.to_string()))?;
                }

                if let Some(feature_idx) = random_slope_feature_idx {
                    b = b
                        .with_random_slope(feature_idx, group_idx, ng)
                        .map_err(|e| PyValueError::new_err(e.to_string()))?;
                    if random_slope_non_centered {
                        b = b
                            .with_random_slope_non_centered(true)
                            .map_err(|e| PyValueError::new_err(e.to_string()))?;
                    }
                }
            }
        } else if correlated_feature_idx.is_some() || random_slope_feature_idx.is_some() {
            return Err(PyValueError::new_err(
                "random slopes / correlated effects require group_idx",
            ));
        }

        let inner = b.build().map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

// ---------------------------------------------------------------------------
// Survival models (Phase 9 Pack A).
// ---------------------------------------------------------------------------

fn parse_cox_ties(ties: &str) -> PyResult<RustCoxTies> {
    match ties.to_ascii_lowercase().as_str() {
        "breslow" => Ok(RustCoxTies::Breslow),
        "efron" => Ok(RustCoxTies::Efron),
        _ => Err(PyValueError::new_err("Invalid ties policy: expected 'efron' or 'breslow'")),
    }
}

/// Python wrapper for `ExponentialSurvivalModel` (right-censoring).
#[pyclass(name = "ExponentialSurvivalModel")]
struct PyExponentialSurvivalModel {
    inner: RustExponentialSurvivalModel,
}

#[pymethods]
impl PyExponentialSurvivalModel {
    #[new]
    fn new(times: Vec<f64>, events: Vec<bool>) -> PyResult<Self> {
        let inner = RustExponentialSurvivalModel::new(times, events)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `WeibullSurvivalModel` (right-censoring).
#[pyclass(name = "WeibullSurvivalModel")]
struct PyWeibullSurvivalModel {
    inner: RustWeibullSurvivalModel,
}

#[pymethods]
impl PyWeibullSurvivalModel {
    #[new]
    fn new(times: Vec<f64>, events: Vec<bool>) -> PyResult<Self> {
        let inner = RustWeibullSurvivalModel::new(times, events)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `LogNormalAftModel` (right-censoring).
#[pyclass(name = "LogNormalAftModel")]
struct PyLogNormalAftModel {
    inner: RustLogNormalAftModel,
}

#[pymethods]
impl PyLogNormalAftModel {
    #[new]
    fn new(times: Vec<f64>, events: Vec<bool>) -> PyResult<Self> {
        let inner = RustLogNormalAftModel::new(times, events)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `IntervalCensoredWeibullModel`.
#[pyclass(name = "IntervalCensoredWeibullModel")]
struct PyIntervalCensoredWeibullModel {
    inner: RustIntervalCensoredWeibullModel,
}

#[pymethods]
impl PyIntervalCensoredWeibullModel {
    #[new]
    fn new(time_lower: Vec<f64>, time_upper: Vec<f64>, censor_type: Vec<String>) -> PyResult<Self> {
        let ct: Vec<RustCensoringType> = censor_type
            .iter()
            .map(|s| {
                RustCensoringType::parse_str(s).map_err(|e| PyValueError::new_err(e.to_string()))
            })
            .collect::<PyResult<Vec<_>>>()?;
        let inner = RustIntervalCensoredWeibullModel::new(time_lower, time_upper, ct)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `IntervalCensoredWeibullAftModel`.
#[pyclass(name = "IntervalCensoredWeibullAftModel")]
struct PyIntervalCensoredWeibullAftModel {
    inner: RustIntervalCensoredWeibullAftModel,
}

#[pymethods]
impl PyIntervalCensoredWeibullAftModel {
    #[new]
    fn new(
        time_lower: Vec<f64>,
        time_upper: Vec<f64>,
        censor_type: Vec<String>,
        covariates: Vec<Vec<f64>>,
    ) -> PyResult<Self> {
        let ct: Vec<RustCensoringType> = censor_type
            .iter()
            .map(|s| {
                RustCensoringType::parse_str(s).map_err(|e| PyValueError::new_err(e.to_string()))
            })
            .collect::<PyResult<Vec<_>>>()?;
        let n = time_lower.len();
        let p = covariates.first().map(|r| r.len()).unwrap_or(0);
        // Flatten covariates to row-major
        let mut x_flat = Vec::with_capacity(n * p);
        for (i, row) in covariates.iter().enumerate() {
            if row.len() != p {
                return Err(PyValueError::new_err(format!(
                    "covariates must be rectangular: row {} has len {}, expected {}",
                    i,
                    row.len(),
                    p
                )));
            }
            x_flat.extend_from_slice(row);
        }
        let inner = RustIntervalCensoredWeibullAftModel::new(time_lower, time_upper, ct, x_flat, p)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `IntervalCensoredExponentialModel`.
#[pyclass(name = "IntervalCensoredExponentialModel")]
struct PyIntervalCensoredExponentialModel {
    inner: RustIntervalCensoredExponentialModel,
}

#[pymethods]
impl PyIntervalCensoredExponentialModel {
    #[new]
    fn new(time_lower: Vec<f64>, time_upper: Vec<f64>, censor_type: Vec<String>) -> PyResult<Self> {
        let ct: Vec<RustCensoringType> = censor_type
            .iter()
            .map(|s| {
                RustCensoringType::parse_str(s).map_err(|e| PyValueError::new_err(e.to_string()))
            })
            .collect::<PyResult<Vec<_>>>()?;
        let inner = RustIntervalCensoredExponentialModel::new(time_lower, time_upper, ct)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `IntervalCensoredLogNormalModel`.
#[pyclass(name = "IntervalCensoredLogNormalModel")]
struct PyIntervalCensoredLogNormalModel {
    inner: RustIntervalCensoredLogNormalModel,
}

#[pymethods]
impl PyIntervalCensoredLogNormalModel {
    #[new]
    fn new(time_lower: Vec<f64>, time_upper: Vec<f64>, censor_type: Vec<String>) -> PyResult<Self> {
        let ct: Vec<RustCensoringType> = censor_type
            .iter()
            .map(|s| {
                RustCensoringType::parse_str(s).map_err(|e| PyValueError::new_err(e.to_string()))
            })
            .collect::<PyResult<Vec<_>>>()?;
        let inner = RustIntervalCensoredLogNormalModel::new(time_lower, time_upper, ct)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `CoxPhModel` (partial likelihood; right-censoring).
#[pyclass(name = "CoxPhModel")]
struct PyCoxPhModel {
    inner: RustCoxPhModel,
}

#[pymethods]
impl PyCoxPhModel {
    #[new]
    #[pyo3(signature = (times, events, x, *, ties = "efron"))]
    fn new(times: Vec<f64>, events: Vec<bool>, x: Vec<Vec<f64>>, ties: &str) -> PyResult<Self> {
        let ties = parse_cox_ties(ties)?;
        let inner = RustCoxPhModel::new(times, events, x, ties)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

// ---------------------------------------------------------------------------
// Pharmacometrics (Phase 13): PK / NLME baselines.
// ---------------------------------------------------------------------------

fn parse_lloq_policy(policy: &str) -> PyResult<RustLloqPolicy> {
    match policy.to_ascii_lowercase().as_str() {
        "ignore" => Ok(RustLloqPolicy::Ignore),
        "replace_half" => Ok(RustLloqPolicy::ReplaceHalf),
        "censored" => Ok(RustLloqPolicy::Censored),
        _ => Err(PyValueError::new_err(
            "Invalid lloq_policy: expected 'ignore', 'replace_half', or 'censored'",
        )),
    }
}

fn parse_error_model(
    error_model: &str,
    sigma: f64,
    sigma_add: Option<f64>,
) -> PyResult<RustErrorModel> {
    match error_model.to_ascii_lowercase().as_str() {
        "additive" => Ok(RustErrorModel::Additive(sigma)),
        "proportional" => Ok(RustErrorModel::Proportional(sigma)),
        "combined" => {
            let sa = sigma_add.ok_or_else(|| {
                PyValueError::new_err("sigma_add is required for combined error model")
            })?;
            Ok(RustErrorModel::Combined { sigma_add: sa, sigma_prop: sigma })
        }
        "exponential" => Ok(RustErrorModel::Exponential(sigma)),
        "power" => {
            // Reuse sigma_add slot as power exponent for backward compatibility.
            let power = sigma_add.unwrap_or(1.0);
            Ok(RustErrorModel::Power { sigma, power })
        }
        _ => Err(PyValueError::new_err(
            "error_model must be 'additive', 'proportional', 'combined', 'exponential', or 'power'",
        )),
    }
}

fn parse_pk_model_kind(model: &str) -> PyResult<RustPkModelKind> {
    match model.to_ascii_lowercase().as_str() {
        "1cpt_oral" => Ok(RustPkModelKind::OneCptOral),
        "1cpt_iv" => Ok(RustPkModelKind::OneCptIv),
        "2cpt_iv" => Ok(RustPkModelKind::TwoCptIv),
        "2cpt_oral" => Ok(RustPkModelKind::TwoCptOral),
        "3cpt_iv" => Ok(RustPkModelKind::ThreeCptIv),
        "3cpt_oral" => Ok(RustPkModelKind::ThreeCptOral),
        _ => Err(PyValueError::new_err(
            "model must be one of: '1cpt_oral', '1cpt_iv', '2cpt_iv', '2cpt_oral', '3cpt_iv', '3cpt_oral'",
        )),
    }
}

#[inline]
fn conc_oral(dose: f64, bioavailability: f64, cl: f64, v: f64, ka: f64, t: f64) -> f64 {
    let ke = cl / v;
    let d = ka - ke;
    let d_amt = dose * bioavailability;
    let pref = d_amt / v;

    let eke = (-ke * t).exp();
    let s = if d.abs() < 1e-10 { t } else { (-(-d * t).exp_m1()) / d };

    pref * ka * eke * s
}

/// Python wrapper for `OneCompartmentOralPkModel` (oral, first-order absorption).
#[pyclass(name = "OneCompartmentOralPkModel")]
struct PyOneCompartmentOralPkModel {
    inner: RustOneCompartmentOralPkModel,
    times: Vec<f64>,
    dose: f64,
    bioavailability: f64,
}

#[pymethods]
impl PyOneCompartmentOralPkModel {
    #[new]
    #[pyo3(signature = (times, y, *, dose, bioavailability=1.0, sigma=0.05, lloq=None, lloq_policy="censored"))]
    fn new(
        times: Vec<f64>,
        y: Vec<f64>,
        dose: f64,
        bioavailability: f64,
        sigma: f64,
        lloq: Option<f64>,
        lloq_policy: &str,
    ) -> PyResult<Self> {
        let lloq_policy = parse_lloq_policy(lloq_policy)?;
        let times_for_pred = times.clone();
        let inner = RustOneCompartmentOralPkModel::new(
            times,
            y,
            dose,
            bioavailability,
            sigma,
            lloq,
            lloq_policy,
        )
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner, times: times_for_pred, dose, bioavailability })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn predict(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        if params.len() != 3 {
            return Err(PyValueError::new_err(format!(
                "expected 3 parameters, got {}",
                params.len()
            )));
        }
        if params.iter().any(|v| !v.is_finite() || *v <= 0.0) {
            return Err(PyValueError::new_err("params must be finite and > 0"));
        }
        let cl = params[0];
        let v = params[1];
        let ka = params[2];
        Ok(self
            .times
            .iter()
            .map(|&t| conc_oral(self.dose, self.bioavailability, cl, v, ka, t))
            .collect())
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `OneCompartmentOralPkNlmeModel` (population + random effects).
#[pyclass(name = "OneCompartmentOralPkNlmeModel")]
struct PyOneCompartmentOralPkNlmeModel {
    inner: RustOneCompartmentOralPkNlmeModel,
}

#[pymethods]
impl PyOneCompartmentOralPkNlmeModel {
    #[new]
    #[pyo3(signature = (times, y, subject_idx, n_subjects, *, dose, bioavailability=1.0, sigma=0.05, lloq=None, lloq_policy="censored"))]
    fn new(
        times: Vec<f64>,
        y: Vec<f64>,
        subject_idx: Vec<usize>,
        n_subjects: usize,
        dose: f64,
        bioavailability: f64,
        sigma: f64,
        lloq: Option<f64>,
        lloq_policy: &str,
    ) -> PyResult<Self> {
        let lloq_policy = parse_lloq_policy(lloq_policy)?;
        let inner = RustOneCompartmentOralPkNlmeModel::new(
            times,
            y,
            subject_idx,
            n_subjects,
            dose,
            bioavailability,
            sigma,
            lloq,
            lloq_policy,
        )
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

// ---------------------------------------------------------------------------
// 2-compartment PK concentration helpers (inlined from pk.rs).
// ---------------------------------------------------------------------------

#[inline]
fn conc_iv_2cpt_py(dose: f64, cl: f64, v1: f64, v2: f64, q: f64, t: f64) -> f64 {
    let k10 = cl / v1;
    let k12 = q / v1;
    let k21 = q / v2;
    let sum = k10 + k12 + k21;
    let prod = k10 * k21;
    let disc = (sum * sum - 4.0 * prod).max(0.0);
    let sqrt_disc = disc.sqrt();
    let alpha = 0.5 * (sum + sqrt_disc);
    let beta = 0.5 * (sum - sqrt_disc);
    let ab = alpha - beta;
    let pref = dose / v1;
    if ab.abs() < 1e-12 {
        return pref * (-0.5 * (alpha + beta) * t).exp();
    }
    let coeff_a = (alpha - k21) / ab;
    let coeff_b = (k21 - beta) / ab;
    pref * (coeff_a * (-alpha * t).exp() + coeff_b * (-beta * t).exp())
}

#[inline]
fn conc_oral_2cpt_py(
    dose: f64,
    bioav: f64,
    cl: f64,
    v1: f64,
    v2: f64,
    q: f64,
    ka: f64,
    t: f64,
) -> f64 {
    let k10 = cl / v1;
    let k12 = q / v1;
    let k21 = q / v2;
    let sum = k10 + k12 + k21;
    let prod = k10 * k21;
    let disc = (sum * sum - 4.0 * prod).max(0.0);
    let sqrt_disc = disc.sqrt();
    let alpha = 0.5 * (sum + sqrt_disc);
    let beta = 0.5 * (sum - sqrt_disc);
    let pref = ka * bioav * dose / v1;

    let denom_a = (ka - alpha) * (beta - alpha);
    let denom_b = (ka - beta) * (alpha - beta);
    let denom_c = (alpha - ka) * (beta - ka);

    if denom_a.abs() < 1e-12 || denom_b.abs() < 1e-12 || denom_c.abs() < 1e-12 {
        let ka_p = ka * (1.0 + 1e-8);
        let da = (ka_p - alpha) * (beta - alpha);
        let db = (ka_p - beta) * (alpha - beta);
        let dc = (alpha - ka_p) * (beta - ka_p);
        let ta = (k21 - alpha) / da * (-alpha * t).exp();
        let tb = (k21 - beta) / db * (-beta * t).exp();
        let tc = (k21 - ka_p) / dc * (-ka_p * t).exp();
        return pref * (ta + tb + tc);
    }

    let ta = (k21 - alpha) / denom_a * (-alpha * t).exp();
    let tb = (k21 - beta) / denom_b * (-beta * t).exp();
    let tc = (k21 - ka) / denom_c * (-ka * t).exp();
    pref * (ta + tb + tc)
}

// ---------------------------------------------------------------------------
// 2-compartment PK models.
// ---------------------------------------------------------------------------

/// Python wrapper for `TwoCompartmentIvPkModel` (IV bolus, 4 params: CL, V1, V2, Q).
#[pyclass(name = "TwoCompartmentIvPkModel")]
struct PyTwoCompartmentIvPkModel {
    inner: RustTwoCompartmentIvPkModel,
    times: Vec<f64>,
    dose: f64,
}

#[pymethods]
impl PyTwoCompartmentIvPkModel {
    #[new]
    #[pyo3(signature = (times, y, *, dose, error_model="additive", sigma=0.05, sigma_add=None, lloq=None, lloq_policy="censored"))]
    fn new(
        times: Vec<f64>,
        y: Vec<f64>,
        dose: f64,
        error_model: &str,
        sigma: f64,
        sigma_add: Option<f64>,
        lloq: Option<f64>,
        lloq_policy: &str,
    ) -> PyResult<Self> {
        let em = parse_error_model(error_model, sigma, sigma_add)?;
        let lp = parse_lloq_policy(lloq_policy)?;
        let times_for_pred = times.clone();
        let inner = RustTwoCompartmentIvPkModel::new(times, y, dose, em, lloq, lp)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner, times: times_for_pred, dose })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn predict(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        if params.len() != 4 {
            return Err(PyValueError::new_err(format!(
                "expected 4 parameters (CL, V1, V2, Q), got {}",
                params.len()
            )));
        }
        if params.iter().any(|v| !v.is_finite() || *v <= 0.0) {
            return Err(PyValueError::new_err("params must be finite and > 0"));
        }
        let cl = params[0];
        let v1 = params[1];
        let v2 = params[2];
        let q = params[3];
        Ok(self.times.iter().map(|&t| conc_iv_2cpt_py(self.dose, cl, v1, v2, q, t)).collect())
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `TwoCompartmentOralPkModel` (oral, 5 params: CL, V1, V2, Q, Ka).
#[pyclass(name = "TwoCompartmentOralPkModel")]
struct PyTwoCompartmentOralPkModel {
    inner: RustTwoCompartmentOralPkModel,
    times: Vec<f64>,
    dose: f64,
    bioavailability: f64,
}

#[pymethods]
impl PyTwoCompartmentOralPkModel {
    #[new]
    #[pyo3(signature = (times, y, *, dose, bioavailability=1.0, error_model="additive", sigma=0.05, sigma_add=None, lloq=None, lloq_policy="censored"))]
    fn new(
        times: Vec<f64>,
        y: Vec<f64>,
        dose: f64,
        bioavailability: f64,
        error_model: &str,
        sigma: f64,
        sigma_add: Option<f64>,
        lloq: Option<f64>,
        lloq_policy: &str,
    ) -> PyResult<Self> {
        let em = parse_error_model(error_model, sigma, sigma_add)?;
        let lp = parse_lloq_policy(lloq_policy)?;
        let times_for_pred = times.clone();
        let inner =
            RustTwoCompartmentOralPkModel::new(times, y, dose, bioavailability, em, lloq, lp)
                .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner, times: times_for_pred, dose, bioavailability })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn predict(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        if params.len() != 5 {
            return Err(PyValueError::new_err(format!(
                "expected 5 parameters (CL, V1, V2, Q, Ka), got {}",
                params.len()
            )));
        }
        if params.iter().any(|v| !v.is_finite() || *v <= 0.0) {
            return Err(PyValueError::new_err("params must be finite and > 0"));
        }
        let cl = params[0];
        let v1 = params[1];
        let v2 = params[2];
        let q = params[3];
        let ka = params[4];
        Ok(self
            .times
            .iter()
            .map(|&t| conc_oral_2cpt_py(self.dose, self.bioavailability, cl, v1, v2, q, ka, t))
            .collect())
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

// ---------------------------------------------------------------------------
// 3-compartment PK concentration helpers (delegating to pk.rs).
// ---------------------------------------------------------------------------

#[inline]
fn conc_iv_3cpt_py(dose: f64, cl: f64, v1: f64, q2: f64, v2: f64, q3: f64, v3: f64, t: f64) -> f64 {
    conc_iv_3cpt_macro(dose, t, cl, v1, q2, v2, q3, v3)
}

#[inline]
fn conc_oral_3cpt_py(
    dose: f64,
    bioav: f64,
    cl: f64,
    v1: f64,
    q2: f64,
    v2: f64,
    q3: f64,
    v3: f64,
    ka: f64,
    t: f64,
) -> f64 {
    conc_oral_3cpt_macro(dose * bioav, t, cl, v1, q2, v2, q3, v3, ka)
}

// ---------------------------------------------------------------------------
// 3-compartment PK models.
// ---------------------------------------------------------------------------

/// Python wrapper for `ThreeCompartmentIvPkModel` (IV bolus, 6 params: CL, V1, Q2, V2, Q3, V3).
#[pyclass(name = "ThreeCompartmentIvPkModel")]
struct PyThreeCompartmentIvPkModel {
    inner: RustThreeCompartmentIvPkModel,
    times: Vec<f64>,
    dose: f64,
}

#[pymethods]
impl PyThreeCompartmentIvPkModel {
    #[new]
    #[pyo3(signature = (times, y, *, dose, error_model="additive", sigma=0.05, sigma_add=None, lloq=None, lloq_policy="censored"))]
    fn new(
        times: Vec<f64>,
        y: Vec<f64>,
        dose: f64,
        error_model: &str,
        sigma: f64,
        sigma_add: Option<f64>,
        lloq: Option<f64>,
        lloq_policy: &str,
    ) -> PyResult<Self> {
        let em = parse_error_model(error_model, sigma, sigma_add)?;
        let lp = parse_lloq_policy(lloq_policy)?;
        let times_for_pred = times.clone();
        let inner = RustThreeCompartmentIvPkModel::new(times, y, dose, em, lloq, lp)
            .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner, times: times_for_pred, dose })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn predict(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        if params.len() != 6 {
            return Err(PyValueError::new_err(format!(
                "expected 6 parameters (CL, V1, Q2, V2, Q3, V3), got {}",
                params.len()
            )));
        }
        if params.iter().any(|v| !v.is_finite() || *v <= 0.0) {
            return Err(PyValueError::new_err("params must be finite and > 0"));
        }
        let cl = params[0];
        let v1 = params[1];
        let q2 = params[2];
        let v2 = params[3];
        let q3 = params[4];
        let v3 = params[5];
        Ok(self
            .times
            .iter()
            .map(|&t| conc_iv_3cpt_py(self.dose, cl, v1, q2, v2, q3, v3, t))
            .collect())
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for `ThreeCompartmentOralPkModel` (oral, 7 params: CL, V1, Q2, V2, Q3, V3, Ka).
#[pyclass(name = "ThreeCompartmentOralPkModel")]
struct PyThreeCompartmentOralPkModel {
    inner: RustThreeCompartmentOralPkModel,
    times: Vec<f64>,
    dose: f64,
    bioavailability: f64,
}

#[pymethods]
impl PyThreeCompartmentOralPkModel {
    #[new]
    #[pyo3(signature = (times, y, *, dose, bioavailability=1.0, error_model="additive", sigma=0.05, sigma_add=None, lloq=None, lloq_policy="censored"))]
    fn new(
        times: Vec<f64>,
        y: Vec<f64>,
        dose: f64,
        bioavailability: f64,
        error_model: &str,
        sigma: f64,
        sigma_add: Option<f64>,
        lloq: Option<f64>,
        lloq_policy: &str,
    ) -> PyResult<Self> {
        let em = parse_error_model(error_model, sigma, sigma_add)?;
        let lp = parse_lloq_policy(lloq_policy)?;
        let times_for_pred = times.clone();
        let inner =
            RustThreeCompartmentOralPkModel::new(times, y, dose, bioavailability, em, lloq, lp)
                .map_err(|e| PyValueError::new_err(e.to_string()))?;
        Ok(Self { inner, times: times_for_pred, dose, bioavailability })
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn predict(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        if params.len() != 7 {
            return Err(PyValueError::new_err(format!(
                "expected 7 parameters (CL, V1, Q2, V2, Q3, V3, Ka), got {}",
                params.len()
            )));
        }
        if params.iter().any(|v| !v.is_finite() || *v <= 0.0) {
            return Err(PyValueError::new_err("params must be finite and > 0"));
        }
        let cl = params[0];
        let v1 = params[1];
        let q2 = params[2];
        let v2 = params[3];
        let q3 = params[4];
        let v3 = params[5];
        let ka = params[6];
        Ok(self
            .times
            .iter()
            .map(|&t| {
                conc_oral_3cpt_py(self.dose, self.bioavailability, cl, v1, q2, v2, q3, v3, ka, t)
            })
            .collect())
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

// ---------------------------------------------------------------------------
// Population PK functions (FOCE, SAEM, VPC, GOF, NONMEM).
// ---------------------------------------------------------------------------

/// FOCE/FOCEI population PK estimation with model dispatch.
#[pyfunction]
#[pyo3(signature = (times, y, subject_idx, n_subjects, *, model="1cpt_oral", method="focei", doses, bioavailability=1.0, error_model="proportional", sigma=0.1, sigma_add=None, theta_init, omega_init, omega_matrix=None, omega_fixed=None, diagonal_omega=false, max_outer_iter=100, max_inner_iter=20, tol=1e-4, rel_tol=1e-8, interaction=true, omega_damping=0.7, omega_max_ratio=100.0, estimate_sigma=true, lloq=None, its_max_iter=30, its_max_individual_iter=60, its_tol=1e-4, its_omega_damping=0.3, imp_n_iter=15, imp_n_samples=300, imp_proposal_scale=1.0, imp_seed=42, imp_tol=1e-4, imp_e_only=false, time_varying_covariates=None, iov=None, random_effect_transforms=None, regimens=None))]
fn nlme_foce<'py>(
    py: Python<'py>,
    times: Vec<f64>,
    y: Vec<f64>,
    subject_idx: Vec<usize>,
    n_subjects: usize,
    model: &str,
    method: &str,
    doses: Vec<f64>,
    bioavailability: f64,
    error_model: &str,
    sigma: f64,
    sigma_add: Option<f64>,
    theta_init: Vec<f64>,
    omega_init: Vec<f64>,
    omega_matrix: Option<Vec<Vec<f64>>>,
    omega_fixed: Option<Vec<bool>>,
    diagonal_omega: bool,
    max_outer_iter: usize,
    max_inner_iter: usize,
    tol: f64,
    rel_tol: f64,
    interaction: bool,
    omega_damping: f64,
    omega_max_ratio: f64,
    estimate_sigma: bool,
    lloq: Option<f64>,
    its_max_iter: usize,
    its_max_individual_iter: usize,
    its_tol: f64,
    its_omega_damping: f64,
    imp_n_iter: usize,
    imp_n_samples: usize,
    imp_proposal_scale: f64,
    imp_seed: u64,
    imp_tol: f64,
    imp_e_only: bool,
    time_varying_covariates: Option<&Bound<'py, PyList>>,
    iov: Option<&Bound<'py, PyDict>>,
    random_effect_transforms: Option<&Bound<'py, PyList>>,
    regimens: Option<&Bound<'py, PyList>>,
) -> PyResult<Py<PyAny>> {
    let em = parse_error_model(error_model, sigma, sigma_add)?;
    let omega_fixed_vec = omega_fixed.unwrap_or_default();
    let config = RustFoceConfig {
        max_outer_iter,
        max_inner_iter,
        tol,
        rel_tol,
        interaction,
        omega_damping,
        omega_max_ratio,
        estimate_sigma,
        lloq,
        omega_fixed: omega_fixed_vec.clone(),
        diagonal_omega,
    };
    let estimator = RustFoceEstimator::new(config);
    let doses = if doses.len() == 1 { vec![doses[0]; n_subjects] } else { doses };

    let expected_n = match model {
        "1cpt_iv" => 2usize,
        "1cpt_oral" => 3usize,
        "2cpt_iv" => 4usize,
        "2cpt_oral" => 5usize,
        "3cpt_iv" => 6usize,
        "3cpt_oral" => 7usize,
        other => {
            return Err(PyValueError::new_err(format!(
                "Unknown model '{}'. Supported: '1cpt_iv', '1cpt_oral', '2cpt_iv', '2cpt_oral', '3cpt_iv', '3cpt_oral'.",
                other
            )));
        }
    };
    if theta_init.len() != expected_n {
        return Err(PyValueError::new_err(format!(
            "model '{}' requires {} theta parameters, got {}",
            model,
            expected_n,
            theta_init.len()
        )));
    }
    if omega_matrix.is_none() && omega_init.len() != expected_n {
        return Err(PyValueError::new_err(format!(
            "model '{}' requires {} omega_init values, got {}",
            model,
            expected_n,
            omega_init.len()
        )));
    }

    // For omega_fixed dims, replace zero/near-zero SD with a tiny placeholder
    // so OmegaMatrix construction succeeds; the FOCE loop will hold these at the
    // initial value via apply_omega_fixed_matrix.
    let omega_init = {
        let mut oi = omega_init;
        for (k, &fixed) in omega_fixed_vec.iter().enumerate() {
            if fixed && k < oi.len() && oi[k] <= 0.0 {
                oi[k] = 1e-10;
            }
        }
        oi
    };
    let omega_full = if let Some(ref mat) = omega_matrix {
        RustOmegaMatrix::from_covariance(mat).map_err(|e| PyValueError::new_err(e.to_string()))?
    } else {
        RustOmegaMatrix::from_diagonal(&omega_init)
            .map_err(|e| PyValueError::new_err(e.to_string()))?
    };
    let omega_diag = omega_full.sds();
    let tv_specs = if let Some(tv) = time_varying_covariates {
        Some(parse_time_varying_covariates(tv, n_subjects)?)
    } else {
        None
    };
    let iov_spec =
        if let Some(iov_dict) = iov { Some(parse_iov_spec(iov_dict, n_subjects)?) } else { None };
    if tv_specs.is_some() && iov_spec.is_some() {
        return Err(PyValueError::new_err(
            "Use either time_varying_covariates or iov in one nlme_foce call (combined mode is not yet exposed).",
        ));
    }

    let its_cfg = RustItsConfig {
        max_iter: its_max_iter,
        max_individual_iter: its_max_individual_iter,
        tol: its_tol,
        omega_damping: its_omega_damping,
    };
    let imp_cfg = RustImpConfig {
        n_iter: imp_n_iter,
        n_samples: imp_n_samples,
        proposal_scale: imp_proposal_scale,
        seed: imp_seed,
        tol: imp_tol,
        e_only: imp_e_only,
    };

    let method_lc = method.to_ascii_lowercase();
    let has_tv = tv_specs.is_some();
    let has_iov = iov_spec.is_some();
    if (has_tv || has_iov)
        && !(model == "1cpt_oral" && (method_lc == "foce" || method_lc == "focei"))
    {
        return Err(PyValueError::new_err(
            "time_varying_covariates/iov are currently supported only for model='1cpt_oral' with method='foce' or 'focei'.",
        ));
    }
    let transforms = if let Some(tr) = random_effect_transforms {
        Some(parse_random_effect_transforms(tr, expected_n)?)
    } else {
        None
    };
    let has_transforms = transforms.is_some();
    if has_transforms && !(method_lc == "foce" || method_lc == "focei") {
        return Err(PyValueError::new_err(
            "random_effect_transforms are currently supported only with method='foce' or 'focei'.",
        ));
    }
    let parsed_regimens = if let Some(regs) = regimens {
        Some(parse_regimens(regs, n_subjects, model, bioavailability)?)
    } else {
        None
    };
    let has_regimens = parsed_regimens.is_some();
    if has_regimens
        && !(matches!(
            model,
            "1cpt_iv" | "1cpt_oral" | "2cpt_iv" | "2cpt_oral" | "3cpt_iv" | "3cpt_oral"
        ) && (method_lc == "foce" || method_lc == "focei"))
    {
        return Err(PyValueError::new_err(
            "regimens are supported for all models with method='foce' or 'focei'.",
        ));
    }
    let mode_count = has_tv as u8 + has_iov as u8 + has_transforms as u8 + has_regimens as u8;
    if mode_count > 1 {
        return Err(PyValueError::new_err(
            "Use only one of: time_varying_covariates, iov, random_effect_transforms, regimens.",
        ));
    }
    let mut imp_diag_opt: Option<ns_inference::ImpDiagnostics> = None;
    let result = match (model, method_lc.as_str()) {
        ("1cpt_iv", "foce") | ("1cpt_iv", "focei") => {
            if let Some(regs) = parsed_regimens.as_ref() {
                estimator.fit_1cpt_iv_with_regimens_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    regs,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            } else if let Some(tr) = transforms.as_ref() {
                estimator.fit_1cpt_iv_with_transforms_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    em,
                    &theta_init,
                    omega_full.clone(),
                    tr,
                )
            } else {
                estimator.fit_1cpt_iv_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            }
        }
        ("1cpt_oral", "foce") | ("1cpt_oral", "focei") => {
            if let Some(regs) = parsed_regimens.as_ref() {
                estimator.fit_1cpt_oral_with_regimens_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    regs,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            } else if let Some(tv) = tv_specs.as_ref() {
                estimator.fit_1cpt_oral_with_time_varying_covariates(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    bioavailability,
                    em,
                    &theta_init,
                    &omega_diag,
                    tv,
                )
            } else if let Some(iov_cfg) = iov_spec.as_ref() {
                estimator.fit_1cpt_oral_with_iov(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    bioavailability,
                    em,
                    &theta_init,
                    &omega_diag,
                    iov_cfg,
                )
            } else if let Some(tr) = transforms.as_ref() {
                estimator.fit_1cpt_oral_with_transforms_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    bioavailability,
                    em,
                    &theta_init,
                    omega_full.clone(),
                    tr,
                )
            } else {
                estimator.fit_1cpt_oral_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    bioavailability,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            }
        }
        ("2cpt_iv", "foce") | ("2cpt_iv", "focei") => {
            if let Some(regs) = parsed_regimens.as_ref() {
                estimator.fit_2cpt_iv_with_regimens_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    regs,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            } else if let Some(tr) = transforms.as_ref() {
                estimator.fit_2cpt_iv_with_transforms_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    em,
                    &theta_init,
                    omega_full.clone(),
                    tr,
                )
            } else {
                estimator.fit_2cpt_iv_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            }
        }
        ("2cpt_oral", "foce") | ("2cpt_oral", "focei") => {
            if let Some(regs) = parsed_regimens.as_ref() {
                estimator.fit_2cpt_oral_with_regimens_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    regs,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            } else if let Some(tr) = transforms.as_ref() {
                estimator.fit_2cpt_oral_with_transforms_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    bioavailability,
                    em,
                    &theta_init,
                    omega_full.clone(),
                    tr,
                )
            } else {
                estimator.fit_2cpt_oral_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    bioavailability,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            }
        }
        ("3cpt_iv", "foce") | ("3cpt_iv", "focei") => {
            if let Some(regs) = parsed_regimens.as_ref() {
                estimator.fit_3cpt_iv_with_regimens_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    regs,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            } else if let Some(tr) = transforms.as_ref() {
                estimator.fit_3cpt_iv_with_transforms_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    em,
                    &theta_init,
                    omega_full.clone(),
                    tr,
                )
            } else {
                estimator.fit_3cpt_iv_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            }
        }
        ("3cpt_oral", "foce") | ("3cpt_oral", "focei") => {
            if let Some(regs) = parsed_regimens.as_ref() {
                estimator.fit_3cpt_oral_with_regimens_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    regs,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            } else if let Some(tr) = transforms.as_ref() {
                estimator.fit_3cpt_oral_with_transforms_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    bioavailability,
                    em,
                    &theta_init,
                    omega_full.clone(),
                    tr,
                )
            } else {
                estimator.fit_3cpt_oral_correlated(
                    &times,
                    &y,
                    &subject_idx,
                    n_subjects,
                    &doses,
                    bioavailability,
                    em,
                    &theta_init,
                    omega_full.clone(),
                )
            }
        }

        ("1cpt_iv", "fo") => estimator.fit_1cpt_iv_fo_correlated(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            em,
            &theta_init,
            omega_full.clone(),
        ),
        ("1cpt_oral", "fo") => estimator.fit_1cpt_oral_fo_correlated(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            bioavailability,
            em,
            &theta_init,
            omega_full.clone(),
        ),
        ("2cpt_iv", "fo") => estimator.fit_2cpt_iv_fo_correlated(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            em,
            &theta_init,
            omega_full.clone(),
        ),
        ("2cpt_oral", "fo") => estimator.fit_2cpt_oral_fo_correlated(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            bioavailability,
            em,
            &theta_init,
            omega_full.clone(),
        ),
        ("3cpt_iv", "fo") => estimator.fit_3cpt_iv_fo(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            em,
            &theta_init,
            &omega_diag,
        ),
        ("3cpt_oral", "fo") => estimator.fit_3cpt_oral_fo(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            bioavailability,
            em,
            &theta_init,
            &omega_diag,
        ),

        ("1cpt_iv", "its") => estimator.fit_1cpt_iv_its(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            em,
            &theta_init,
            &omega_diag,
            its_cfg.clone(),
        ),
        ("1cpt_oral", "its") => estimator.fit_1cpt_oral_its(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            bioavailability,
            em,
            &theta_init,
            &omega_diag,
            its_cfg.clone(),
        ),
        ("2cpt_iv", "its") => estimator.fit_2cpt_iv_its(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            em,
            &theta_init,
            &omega_diag,
            its_cfg.clone(),
        ),
        ("2cpt_oral", "its") => estimator.fit_2cpt_oral_its(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            bioavailability,
            em,
            &theta_init,
            &omega_diag,
            its_cfg.clone(),
        ),
        ("3cpt_iv", "its") => estimator.fit_3cpt_iv_its(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            em,
            &theta_init,
            &omega_diag,
            its_cfg.clone(),
        ),
        ("3cpt_oral", "its") => estimator.fit_3cpt_oral_its(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            bioavailability,
            em,
            &theta_init,
            &omega_diag,
            its_cfg.clone(),
        ),

        ("1cpt_iv", "imp") => estimator
            .fit_1cpt_iv_imp(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                em,
                &theta_init,
                &omega_diag,
                imp_cfg.clone(),
            )
            .map(|(r, d)| {
                imp_diag_opt = Some(d);
                r
            }),
        ("1cpt_oral", "imp") => estimator
            .fit_1cpt_oral_imp(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                &omega_diag,
                imp_cfg.clone(),
            )
            .map(|(r, d)| {
                imp_diag_opt = Some(d);
                r
            }),
        ("2cpt_iv", "imp") => estimator
            .fit_2cpt_iv_imp(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                em,
                &theta_init,
                &omega_diag,
                imp_cfg.clone(),
            )
            .map(|(r, d)| {
                imp_diag_opt = Some(d);
                r
            }),
        ("2cpt_oral", "imp") => estimator
            .fit_2cpt_oral_imp(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                &omega_diag,
                imp_cfg.clone(),
            )
            .map(|(r, d)| {
                imp_diag_opt = Some(d);
                r
            }),
        ("3cpt_iv", "imp") => estimator
            .fit_3cpt_iv_imp(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                em,
                &theta_init,
                &omega_diag,
                imp_cfg.clone(),
            )
            .map(|(r, d)| {
                imp_diag_opt = Some(d);
                r
            }),
        ("3cpt_oral", "imp") => estimator
            .fit_3cpt_oral_imp(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                &omega_diag,
                imp_cfg.clone(),
            )
            .map(|(r, d)| {
                imp_diag_opt = Some(d);
                r
            }),

        (_, other_method) => Err(ns_core::Error::Validation(format!(
            "Unknown method '{}'. Supported: 'foce', 'focei', 'fo', 'its', 'imp'.",
            other_method
        ))),
    }
    .map_err(|e| PyValueError::new_err(e.to_string()))?;

    let dict = PyDict::new(py);
    dict.set_item("theta", result.theta.clone())?;
    dict.set_item("omega", result.omega.clone())?;
    dict.set_item("omega_matrix", result.omega_matrix.to_matrix())?;
    dict.set_item("correlation", result.correlation.clone())?;
    dict.set_item("eta", result.eta.clone())?;
    dict.set_item("ofv", result.ofv)?;
    dict.set_item("converged", result.converged)?;
    dict.set_item("n_iter", result.n_iter)?;
    dict.set_item("sigma", result.sigma)?;
    dict.set_item("sigma_init", result.sigma_init)?;
    if let Some(cov) = &result.covariance_step {
        let cov_dict = PyDict::new(py);
        cov_dict.set_item("parameter_names", cov.parameter_names.clone())?;
        cov_dict.set_item("r_matrix", cov.r_matrix.clone())?;
        cov_dict.set_item("s_matrix", cov.s_matrix.clone())?;
        cov_dict.set_item("covariance", cov.covariance.clone())?;
        cov_dict.set_item("robust_covariance", cov.robust_covariance.clone())?;
        cov_dict.set_item("se", cov.se.clone())?;
        cov_dict.set_item("rse_pct", cov.rse_pct.clone())?;
        cov_dict.set_item("r_eigenvalues", cov.r_eigenvalues.clone())?;
        cov_dict.set_item("r_condition_number", cov.r_condition_number)?;
        dict.set_item("covariance_step", cov_dict)?;
    } else {
        dict.set_item("covariance_step", py.None())?;
    }
    if let Some(imp_diag) = imp_diag_opt {
        let imp_dict = PyDict::new(py);
        imp_dict.set_item("ofv_trace", imp_diag.ofv_trace)?;
        imp_dict.set_item("ess_fraction_trace", imp_diag.ess_fraction_trace)?;
        imp_dict.set_item("max_weight_trace", imp_diag.max_weight_trace)?;
        dict.set_item("imp", imp_dict)?;
    } else {
        dict.set_item("imp", py.None())?;
    }
    dict.into_py_any(py)
}

/// Parse a Python list of covariate dicts into `Vec<RustCovariateSpec>`.
///
/// Each dict: `{"param_idx": int, "values": list[float], "reference": float, "relationship": str}`
/// Relationship: "power" (with optional "exponent": float, default 0.75), "exponential",
/// "proportional", "categorical".
fn parse_covariates(
    covariates: &Bound<'_, PyList>,
    n_subjects: usize,
) -> PyResult<Vec<RustCovariateSpec>> {
    let mut specs = Vec::with_capacity(covariates.len());
    for item in covariates.iter() {
        let d = item
            .cast::<PyDict>()
            .map_err(|_| PyValueError::new_err("each covariate must be a dict"))?;
        let param_idx: usize = d
            .get_item("param_idx")?
            .ok_or_else(|| PyValueError::new_err("covariate dict missing 'param_idx'"))?
            .extract()?;
        let values: Vec<f64> = d
            .get_item("values")?
            .ok_or_else(|| PyValueError::new_err("covariate dict missing 'values'"))?
            .extract()?;
        if values.len() != n_subjects {
            return Err(PyValueError::new_err(format!(
                "covariate values length ({}) != n_subjects ({})",
                values.len(),
                n_subjects
            )));
        }
        let reference: f64 = d
            .get_item("reference")?
            .ok_or_else(|| PyValueError::new_err("covariate dict missing 'reference'"))?
            .extract()?;
        let rel_str: String = d
            .get_item("relationship")?
            .ok_or_else(|| PyValueError::new_err("covariate dict missing 'relationship'"))?
            .extract()?;
        let relationship = match rel_str.to_ascii_lowercase().as_str() {
            "power" => {
                let exp: f64 = d
                    .get_item("exponent")?
                    .map(|v| v.extract::<f64>())
                    .transpose()?
                    .unwrap_or(0.75);
                RustCovRelationship::Power { exponent: exp, estimate_exponent: false }
            }
            "exponential" => RustCovRelationship::Exponential,
            "proportional" => RustCovRelationship::Proportional,
            "categorical" => RustCovRelationship::Categorical,
            other => {
                return Err(PyValueError::new_err(format!(
                    "Unknown covariate relationship '{}'. Use 'power', 'exponential', 'proportional', or 'categorical'.",
                    other
                )));
            }
        };
        specs.push(RustCovariateSpec { param_idx, values, reference, relationship });
    }
    Ok(specs)
}

/// Parse time-varying covariates:
///
/// Each dict:
/// {
///   "param_idx": int,
///   "trajectories": [  # len = n_subjects
///     [(t0, v0), (t1, v1), ...],    # or [{"time": t, "value": v}, ...]
///     ...
///   ],
///   "reference": float,
///   "relationship": "power"|"exponential"|"proportional"|"categorical",
///   "interpolation": "locf"|"linear"   # optional, default locf
/// }
fn parse_time_varying_covariates(
    covariates: &Bound<'_, PyList>,
    n_subjects: usize,
) -> PyResult<Vec<RustTimeVaryingCovariateSpec>> {
    let mut specs = Vec::with_capacity(covariates.len());
    for item in covariates.iter() {
        let d = item
            .cast::<PyDict>()
            .map_err(|_| PyValueError::new_err("each time-varying covariate must be a dict"))?;
        let param_idx: usize = d
            .get_item("param_idx")?
            .ok_or_else(|| PyValueError::new_err("time-varying covariate missing 'param_idx'"))?
            .extract()?;
        let reference: f64 = d
            .get_item("reference")?
            .ok_or_else(|| PyValueError::new_err("time-varying covariate missing 'reference'"))?
            .extract()?;
        let rel_str: String = d
            .get_item("relationship")?
            .ok_or_else(|| PyValueError::new_err("time-varying covariate missing 'relationship'"))?
            .extract()?;
        let relationship = match rel_str.to_ascii_lowercase().as_str() {
            "power" => {
                let exp: f64 = d
                    .get_item("exponent")?
                    .map(|v| v.extract::<f64>())
                    .transpose()?
                    .unwrap_or(0.75);
                RustCovRelationship::Power { exponent: exp, estimate_exponent: false }
            }
            "exponential" => RustCovRelationship::Exponential,
            "proportional" => RustCovRelationship::Proportional,
            "categorical" => RustCovRelationship::Categorical,
            other => {
                return Err(PyValueError::new_err(format!(
                    "Unknown time-varying covariate relationship '{}'. Use 'power', 'exponential', 'proportional', or 'categorical'.",
                    other
                )));
            }
        };
        let interp = d
            .get_item("interpolation")?
            .map(|v| v.extract::<String>())
            .transpose()?
            .unwrap_or_else(|| "locf".to_string());
        let interpolation = match interp.to_ascii_lowercase().as_str() {
            "locf" => RustTimeCovariateInterpolation::Locf,
            "linear" => RustTimeCovariateInterpolation::Linear,
            other => {
                return Err(PyValueError::new_err(format!(
                    "Unknown interpolation '{}'. Use 'locf' or 'linear'.",
                    other
                )));
            }
        };

        let trajectories_any = d.get_item("trajectories")?.ok_or_else(|| {
            PyValueError::new_err("time-varying covariate missing 'trajectories'")
        })?;
        let trajectories_list = trajectories_any.cast::<PyList>().map_err(|_| {
            PyValueError::new_err("'trajectories' must be a list of per-subject trajectories")
        })?;
        if trajectories_list.len() != n_subjects {
            return Err(PyValueError::new_err(format!(
                "time-varying trajectories length ({}) != n_subjects ({})",
                trajectories_list.len(),
                n_subjects
            )));
        }
        let mut trajectories: Vec<Vec<RustTimeVaryingCovariatePoint>> =
            Vec::with_capacity(n_subjects);
        for subj_item in trajectories_list.iter() {
            let subj_list = subj_item.cast::<PyList>().map_err(|_| {
                PyValueError::new_err(
                    "each subject trajectory must be a list of (time, value) pairs or dict points",
                )
            })?;
            let mut pts: Vec<RustTimeVaryingCovariatePoint> = Vec::with_capacity(subj_list.len());
            for p in subj_list.iter() {
                if let Ok((t, v)) = p.extract::<(f64, f64)>() {
                    pts.push(RustTimeVaryingCovariatePoint { time: t, value: v });
                    continue;
                }
                let pd = p.cast::<PyDict>().map_err(|_| {
                    PyValueError::new_err(
                        "trajectory point must be (time, value) tuple or {'time':..., 'value':...}",
                    )
                })?;
                let t: f64 = pd
                    .get_item("time")?
                    .ok_or_else(|| PyValueError::new_err("trajectory point missing 'time'"))?
                    .extract()?;
                let v: f64 = pd
                    .get_item("value")?
                    .ok_or_else(|| PyValueError::new_err("trajectory point missing 'value'"))?
                    .extract()?;
                pts.push(RustTimeVaryingCovariatePoint { time: t, value: v });
            }
            trajectories.push(pts);
        }

        specs.push(RustTimeVaryingCovariateSpec {
            param_idx,
            trajectories,
            reference,
            relationship,
            interpolation,
        });
    }
    Ok(specs)
}

/// Parse IOV spec dict:
/// {
///   "param_indices": [int, ...],
///   "occasion_start_times": [[t0, t1, ...], ...],  # len = n_subjects
///   "omega_iov_init": [float, ...]                 # len = len(param_indices)
/// }
fn parse_iov_spec(iov: &Bound<'_, PyDict>, n_subjects: usize) -> PyResult<RustIovSpec> {
    let param_indices: Vec<usize> = iov
        .get_item("param_indices")?
        .ok_or_else(|| PyValueError::new_err("IOV dict missing 'param_indices'"))?
        .extract()?;
    let occasion_start_times: Vec<Vec<f64>> = iov
        .get_item("occasion_start_times")?
        .ok_or_else(|| PyValueError::new_err("IOV dict missing 'occasion_start_times'"))?
        .extract()?;
    let omega_iov_init: Vec<f64> = iov
        .get_item("omega_iov_init")?
        .ok_or_else(|| PyValueError::new_err("IOV dict missing 'omega_iov_init'"))?
        .extract()?;
    if occasion_start_times.len() != n_subjects {
        return Err(PyValueError::new_err(format!(
            "IOV occasion_start_times length ({}) != n_subjects ({})",
            occasion_start_times.len(),
            n_subjects
        )));
    }
    Ok(RustIovSpec { param_indices, occasion_start_times, omega_iov_init })
}

fn parse_random_effect_transforms(
    transforms: &Bound<'_, PyList>,
    expected_n: usize,
) -> PyResult<Vec<RustRandomEffectTransform>> {
    if transforms.len() != expected_n {
        return Err(PyValueError::new_err(format!(
            "random_effect_transforms length ({}) must equal model dimension ({expected_n})",
            transforms.len()
        )));
    }
    let mut out = Vec::with_capacity(expected_n);
    for item in transforms.iter() {
        if let Ok(kind) = item.extract::<String>() {
            let tr = match kind.to_ascii_lowercase().as_str() {
                "lognormal" | "log_normal" | "log-normal" => RustRandomEffectTransform::LogNormal,
                other => {
                    return Err(PyValueError::new_err(format!(
                        "Unknown transform '{}'. Use 'lognormal' or a dict with type='logit_normal'.",
                        other
                    )));
                }
            };
            out.push(tr);
            continue;
        }
        let d = item.cast::<PyDict>().map_err(|_| {
            PyValueError::new_err(
                "each random effect transform must be a string or dict {'type', ...}",
            )
        })?;
        let t: String = d
            .get_item("type")?
            .ok_or_else(|| PyValueError::new_err("transform dict missing 'type'"))?
            .extract()?;
        let tr = match t.to_ascii_lowercase().as_str() {
            "lognormal" | "log_normal" | "log-normal" => RustRandomEffectTransform::LogNormal,
            "logitnormal" | "logit_normal" | "logit-normal" => {
                let lower: f64 = d
                    .get_item("lower")?
                    .ok_or_else(|| PyValueError::new_err("logit_normal transform missing 'lower'"))?
                    .extract()?;
                let upper: f64 = d
                    .get_item("upper")?
                    .ok_or_else(|| PyValueError::new_err("logit_normal transform missing 'upper'"))?
                    .extract()?;
                RustRandomEffectTransform::LogitNormal { lower, upper }
            }
            other => {
                return Err(PyValueError::new_err(format!(
                    "Unknown transform type '{}'. Use 'lognormal' or 'logit_normal'.",
                    other
                )));
            }
        };
        out.push(tr);
    }
    Ok(out)
}

fn parse_dose_route(
    route_val: Option<&Bound<'_, PyAny>>,
    model: &str,
    default_bioavailability: f64,
    duration_val: Option<f64>,
    event_dict: &Bound<'_, PyDict>,
) -> PyResult<RustDoseRoute> {
    if let Some(route_obj) = route_val {
        if let Ok(route_name) = route_obj.extract::<String>() {
            return match route_name.to_ascii_lowercase().as_str() {
                "iv_bolus" | "ivbolus" | "bolus" => Ok(RustDoseRoute::IvBolus),
                "oral" => {
                    let bioavailability: f64 = event_dict
                        .get_item("bioavailability")?
                        .map(|v| v.extract::<f64>())
                        .transpose()?
                        .unwrap_or(default_bioavailability);
                    Ok(RustDoseRoute::Oral { bioavailability })
                }
                "infusion" | "iv_infusion" | "ivinfusion" => {
                    let duration = duration_val
                        .or_else(|| {
                            event_dict
                                .get_item("duration")
                                .ok()
                                .flatten()
                                .and_then(|v| v.extract::<f64>().ok())
                        })
                        .ok_or_else(|| {
                            PyValueError::new_err(
                                "infusion route requires 'duration' in event dict",
                            )
                        })?;
                    Ok(RustDoseRoute::Infusion { duration })
                }
                other => Err(PyValueError::new_err(format!(
                    "Unknown route '{}'. Use iv_bolus/oral/infusion.",
                    other
                ))),
            };
        }
        let route_dict = route_obj
            .cast::<PyDict>()
            .map_err(|_| PyValueError::new_err("route must be string or dict {'type', ...}"))?;
        let route_type: String = route_dict
            .get_item("type")?
            .ok_or_else(|| PyValueError::new_err("route dict missing 'type'"))?
            .extract()?;
        return match route_type.to_ascii_lowercase().as_str() {
            "iv_bolus" | "ivbolus" | "bolus" => Ok(RustDoseRoute::IvBolus),
            "oral" => {
                let bioavailability: f64 = route_dict
                    .get_item("bioavailability")?
                    .map(|v| v.extract::<f64>())
                    .transpose()?
                    .unwrap_or(default_bioavailability);
                Ok(RustDoseRoute::Oral { bioavailability })
            }
            "infusion" | "iv_infusion" | "ivinfusion" => {
                let duration: f64 = route_dict
                    .get_item("duration")?
                    .ok_or_else(|| PyValueError::new_err("infusion route missing 'duration'"))?
                    .extract()?;
                Ok(RustDoseRoute::Infusion { duration })
            }
            other => Err(PyValueError::new_err(format!(
                "Unknown route type '{}'. Use iv_bolus/oral/infusion.",
                other
            ))),
        };
    }

    match model {
        "2cpt_iv" | "1cpt_iv" | "3cpt_iv" => Ok(RustDoseRoute::IvBolus),
        _ => Ok(RustDoseRoute::Oral { bioavailability: default_bioavailability }),
    }
}

fn parse_regimens(
    regimens: &Bound<'_, PyList>,
    n_subjects: usize,
    model: &str,
    default_bioavailability: f64,
) -> PyResult<Vec<RustDosingRegimen>> {
    if regimens.len() != n_subjects {
        return Err(PyValueError::new_err(format!(
            "regimens length ({}) must equal n_subjects ({n_subjects})",
            regimens.len()
        )));
    }
    let mut out: Vec<RustDosingRegimen> = Vec::with_capacity(n_subjects);
    for subj in regimens.iter() {
        let subj_dict = subj
            .cast::<PyDict>()
            .map_err(|_| PyValueError::new_err("each regimen must be a dict"))?;
        let events_any = subj_dict
            .get_item("events")?
            .ok_or_else(|| PyValueError::new_err("each regimen dict must include 'events'"))?;
        let events_list = events_any
            .cast::<PyList>()
            .map_err(|_| PyValueError::new_err("'events' must be a list of event dicts"))?;
        let mut events: Vec<RustDoseEvent> = Vec::with_capacity(events_list.len());
        for ev in events_list.iter() {
            let evd = ev
                .cast::<PyDict>()
                .map_err(|_| PyValueError::new_err("each dosing event must be a dict"))?;
            let time: f64 = evd
                .get_item("time")?
                .ok_or_else(|| PyValueError::new_err("event missing 'time'"))?
                .extract()?;
            let amount: f64 = evd
                .get_item("amount")?
                .ok_or_else(|| PyValueError::new_err("event missing 'amount'"))?
                .extract()?;
            let route_obj = evd.get_item("route")?;
            let duration = evd.get_item("duration")?.map(|v| v.extract::<f64>()).transpose()?;
            let route = parse_dose_route(
                route_obj.as_ref(),
                model,
                default_bioavailability,
                duration,
                evd,
            )?;
            events.push(RustDoseEvent { time, amount, route });
        }
        let regimen = RustDosingRegimen::from_events(events)
            .map_err(|e| PyValueError::new_err(format!("invalid regimen: {}", e)))?;
        out.push(regimen);
    }
    Ok(out)
}

/// Pack SAEM result + diagnostics into a Python dict.
fn pack_saem_result(
    py: Python<'_>,
    result: &ns_inference::FoceResult,
    diag: &ns_inference::SaemDiagnostics,
    return_theta_trace: bool,
) -> PyResult<Py<PyAny>> {
    let dict = PyDict::new(py);
    dict.set_item("theta", result.theta.clone())?;
    dict.set_item("omega", result.omega.clone())?;
    dict.set_item("omega_matrix", result.omega_matrix.to_matrix())?;
    dict.set_item("correlation", result.correlation.clone())?;
    dict.set_item("eta", result.eta.clone())?;
    dict.set_item("ofv", result.ofv)?;
    dict.set_item("converged", result.converged)?;
    dict.set_item("n_iter", result.n_iter)?;
    dict.set_item("sigma", result.sigma)?;
    dict.set_item("sigma_init", result.sigma_init)?;

    let saem_dict = PyDict::new(py);
    saem_dict.set_item("acceptance_rates", diag.acceptance_rates.clone())?;
    saem_dict.set_item("ofv_trace", diag.ofv_trace.clone())?;
    saem_dict.set_item("burn_in_only", diag.burn_in_only)?;
    if return_theta_trace && !diag.theta_trace.is_empty() {
        saem_dict.set_item("theta_trace", diag.theta_trace.clone())?;
    }
    if !diag.relative_change.is_empty() {
        saem_dict.set_item("relative_change", diag.relative_change.clone())?;
    }
    if let Some(ref gs) = diag.geweke_scores {
        saem_dict.set_item("geweke_scores", gs.clone())?;
    }
    dict.set_item("saem", saem_dict)?;
    dict.into_py_any(py)
}

/// SAEM population PK estimation with model dispatch.
///
/// Supported models: "1cpt_iv" (2θ), "1cpt_oral" (3θ), "2cpt_iv" (4θ),
/// "2cpt_oral" (5θ), "3cpt_iv" (6θ), "3cpt_oral" (7θ).
#[pyfunction]
#[pyo3(signature = (times, y, subject_idx, n_subjects, *, model="1cpt_oral", doses, bioavailability=1.0, error_model="proportional", sigma=0.1, sigma_add=None, theta_init, omega_init, omega_matrix=None, covariates=None, time_varying_covariates=None, iov=None, random_effect_transforms=None, regimens=None, n_burn=200, n_iter=100, n_chains=1, seed=12345, tol=1e-4, return_theta_trace=false, lloq=None))]
fn nlme_saem<'py>(
    py: Python<'py>,
    times: Vec<f64>,
    y: Vec<f64>,
    subject_idx: Vec<usize>,
    n_subjects: usize,
    model: &str,
    doses: Vec<f64>,
    bioavailability: f64,
    error_model: &str,
    sigma: f64,
    sigma_add: Option<f64>,
    theta_init: Vec<f64>,
    omega_init: Vec<f64>,
    omega_matrix: Option<Vec<Vec<f64>>>,
    covariates: Option<&Bound<'py, PyList>>,
    time_varying_covariates: Option<&Bound<'py, PyList>>,
    iov: Option<&Bound<'py, PyDict>>,
    random_effect_transforms: Option<&Bound<'py, PyList>>,
    regimens: Option<&Bound<'py, PyList>>,
    n_burn: usize,
    n_iter: usize,
    n_chains: usize,
    seed: u64,
    tol: f64,
    return_theta_trace: bool,
    lloq: Option<f64>,
) -> PyResult<Py<PyAny>> {
    let em = parse_error_model(error_model, sigma, sigma_add)?;
    let doses = if doses.len() == 1 { vec![doses[0]; n_subjects] } else { doses };

    // Validate theta_init length per model.
    let expected_n = match model {
        "1cpt_iv" => 2,
        "1cpt_oral" => 3,
        "2cpt_iv" => 4,
        "2cpt_oral" => 5,
        "3cpt_iv" => 6,
        "3cpt_oral" => 7,
        other => {
            return Err(PyValueError::new_err(format!(
                "Unknown model '{}'. Supported: '1cpt_iv', '1cpt_oral', '2cpt_iv', '2cpt_oral', '3cpt_iv', '3cpt_oral'.",
                other
            )));
        }
    };
    if theta_init.len() != expected_n {
        return Err(PyValueError::new_err(format!(
            "model '{}' requires {} theta parameters, got {}",
            model,
            expected_n,
            theta_init.len()
        )));
    }

    let config = RustSaemConfig {
        n_burn,
        n_iter,
        n_chains,
        seed,
        tol,
        store_theta_trace: return_theta_trace,
        lloq,
        ..Default::default()
    };
    let estimator = RustSaemEstimator::new(config);

    // Parse covariates if provided.
    let cov_specs = if let Some(cov_list) = covariates {
        parse_covariates(cov_list, n_subjects)?
    } else {
        Vec::new()
    };
    let tv_cov_specs = if let Some(tv_list) = time_varying_covariates {
        parse_time_varying_covariates(tv_list, n_subjects)?
    } else {
        Vec::new()
    };
    let iov_spec =
        if let Some(iov_dict) = iov { Some(parse_iov_spec(iov_dict, n_subjects)?) } else { None };
    let has_covariates = !cov_specs.is_empty();
    let has_tv_covariates = !tv_cov_specs.is_empty();
    let has_iov = iov_spec.is_some();
    let transforms = if let Some(tr) = random_effect_transforms {
        Some(parse_random_effect_transforms(tr, expected_n)?)
    } else {
        None
    };
    let parsed_regimens = if let Some(regs) = regimens {
        Some(parse_regimens(regs, n_subjects, model, bioavailability)?)
    } else {
        None
    };
    let has_transforms = transforms.is_some();
    let has_regimens = parsed_regimens.is_some();
    let mode_count = has_covariates as u8
        + has_tv_covariates as u8
        + has_iov as u8
        + has_transforms as u8
        + has_regimens as u8;
    if mode_count > 1 {
        return Err(PyValueError::new_err(
            "Use only one of: covariates, time_varying_covariates, iov, random_effect_transforms, regimens.",
        ));
    }
    if (has_tv_covariates || has_iov) && model != "1cpt_oral" {
        return Err(PyValueError::new_err(
            "time_varying_covariates and iov are currently supported only for model='1cpt_oral' in nlme_saem.",
        ));
    }
    if has_regimens
        && !matches!(
            model,
            "1cpt_iv" | "1cpt_oral" | "2cpt_iv" | "2cpt_oral" | "3cpt_iv" | "3cpt_oral"
        )
    {
        return Err(PyValueError::new_err("regimens are supported for all models in nlme_saem."));
    }

    // Build OmegaMatrix: prefer full matrix, fallback to diagonal.
    let omega = if let Some(ref mat) = omega_matrix {
        RustOmegaMatrix::from_covariance(mat).map_err(|e| PyValueError::new_err(e.to_string()))?
    } else {
        RustOmegaMatrix::from_diagonal(&omega_init)
            .map_err(|e| PyValueError::new_err(e.to_string()))?
    };

    // Dispatch to the appropriate model fit method.
    let (result, diag) = if has_covariates {
        match model {
            "1cpt_iv" => Err(ns_core::Error::Validation(
                "covariates mode is not yet implemented for model='1cpt_iv' in nlme_saem."
                    .to_string(),
            )),
            "1cpt_oral" => estimator.fit_1cpt_oral_with_covariates(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                &omega_init,
                &cov_specs,
            ),
            "2cpt_iv" => estimator.fit_2cpt_iv_with_covariates(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                em,
                &theta_init,
                &omega_init,
                &cov_specs,
            ),
            "2cpt_oral" => estimator.fit_2cpt_oral_with_covariates(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                &omega_init,
                &cov_specs,
            ),
            "3cpt_iv" => estimator.fit_3cpt_iv_with_covariates(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                em,
                &theta_init,
                &omega_init,
                &cov_specs,
            ),
            "3cpt_oral" => estimator.fit_3cpt_oral_with_covariates(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                &omega_init,
                &cov_specs,
            ),
            _ => unreachable!(),
        }
    } else if has_tv_covariates {
        estimator.fit_1cpt_oral_with_time_varying_covariates(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            bioavailability,
            em,
            &theta_init,
            &omega.sds(),
            &tv_cov_specs,
        )
    } else if let Some(ref iov_cfg) = iov_spec {
        estimator.fit_1cpt_oral_with_iov(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            &doses,
            bioavailability,
            em,
            &theta_init,
            &omega.sds(),
            iov_cfg,
        )
    } else if let Some(tr) = transforms.as_ref() {
        match model {
            "1cpt_iv" => estimator.fit_1cpt_iv_with_transforms_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                em,
                &theta_init,
                omega.clone(),
                tr,
            ),
            "1cpt_oral" => estimator.fit_1cpt_oral_with_transforms_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                omega.clone(),
                tr,
            ),
            "2cpt_iv" => estimator.fit_2cpt_iv_with_transforms_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                em,
                &theta_init,
                omega.clone(),
                tr,
            ),
            "2cpt_oral" => estimator.fit_2cpt_oral_with_transforms_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                omega.clone(),
                tr,
            ),
            "3cpt_iv" => estimator.fit_3cpt_iv_with_transforms_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                em,
                &theta_init,
                omega.clone(),
                tr,
            ),
            "3cpt_oral" => estimator.fit_3cpt_oral_with_transforms_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                omega.clone(),
                tr,
            ),
            _ => unreachable!(),
        }
    } else if let Some(regs) = parsed_regimens.as_ref() {
        match model {
            "1cpt_iv" => estimator.fit_1cpt_iv_with_regimens_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                regs,
                em,
                &theta_init,
                omega.clone(),
            ),
            "1cpt_oral" => estimator.fit_1cpt_oral_with_regimens_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                regs,
                em,
                &theta_init,
                omega.clone(),
            ),
            "2cpt_iv" => estimator.fit_2cpt_iv_with_regimens_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                regs,
                em,
                &theta_init,
                omega.clone(),
            ),
            "2cpt_oral" => estimator.fit_2cpt_oral_with_regimens_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                regs,
                em,
                &theta_init,
                omega.clone(),
            ),
            "3cpt_iv" => estimator.fit_3cpt_iv_with_regimens_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                regs,
                em,
                &theta_init,
                omega.clone(),
            ),
            "3cpt_oral" => estimator.fit_3cpt_oral_with_regimens_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                regs,
                em,
                &theta_init,
                omega.clone(),
            ),
            _ => unreachable!(),
        }
    } else {
        match model {
            "1cpt_iv" => estimator.fit_1cpt_iv_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                em,
                &theta_init,
                omega.clone(),
            ),
            "1cpt_oral" => estimator.fit_1cpt_oral_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                omega.clone(),
            ),
            "2cpt_iv" => estimator.fit_2cpt_iv_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                em,
                &theta_init,
                omega.clone(),
            ),
            "2cpt_oral" => estimator.fit_2cpt_oral_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                omega.clone(),
            ),
            "3cpt_iv" => estimator.fit_3cpt_iv_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                em,
                &theta_init,
                omega.clone(),
            ),
            "3cpt_oral" => estimator.fit_3cpt_oral_correlated(
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &doses,
                bioavailability,
                em,
                &theta_init,
                omega.clone(),
            ),
            _ => unreachable!(),
        }
    }
    .map_err(|e| PyValueError::new_err(e.to_string()))?;

    pack_saem_result(py, &result, &diag, return_theta_trace)
}

/// Nonparametric bootstrap for SAEM: resample subjects, refit, collect CIs/SEs.
#[pyfunction]
#[pyo3(signature = (times, y, subject_idx, n_subjects, *, model="1cpt_oral", doses, bioavailability=1.0, error_model="proportional", sigma=0.1, sigma_add=None, theta, omega, covariates=None, n_bootstrap=200, conf_level=0.95, ci_method="percentile", n_burn=200, n_iter=100, n_chains=1, seed=42, tol=1e-4))]
fn bootstrap_nlme<'py>(
    py: Python<'py>,
    times: Vec<f64>,
    y: Vec<f64>,
    subject_idx: Vec<usize>,
    n_subjects: usize,
    model: &str,
    doses: Vec<f64>,
    bioavailability: f64,
    error_model: &str,
    sigma: f64,
    sigma_add: Option<f64>,
    theta: Vec<f64>,
    omega: Vec<f64>,
    covariates: Option<&Bound<'py, PyList>>,
    n_bootstrap: usize,
    conf_level: f64,
    ci_method: &str,
    n_burn: usize,
    n_iter: usize,
    n_chains: usize,
    seed: u64,
    tol: f64,
) -> PyResult<Py<PyAny>> {
    let em = parse_error_model(error_model, sigma, sigma_add)?;
    let doses = if doses.len() == 1 { vec![doses[0]; n_subjects] } else { doses };

    let (expected_n, n_eta) = match model {
        "1cpt_oral" => (3usize, 3usize),
        "2cpt_iv" => (4, 4),
        "2cpt_oral" => (5, 5),
        "3cpt_iv" => (6, 6),
        "3cpt_oral" => (7, 7),
        other => {
            return Err(PyValueError::new_err(format!(
                "Unknown model '{}'. Supported: '1cpt_oral', '2cpt_iv', '2cpt_oral', '3cpt_iv', '3cpt_oral'.",
                other
            )));
        }
    };
    if theta.len() != expected_n {
        return Err(PyValueError::new_err(format!(
            "model '{}' requires {} theta parameters, got {}",
            model,
            expected_n,
            theta.len()
        )));
    }

    let method = match ci_method.to_ascii_lowercase().as_str() {
        "percentile" => RustBootstrapCiMethod::Percentile,
        "bca" => RustBootstrapCiMethod::Bca,
        other => {
            return Err(PyValueError::new_err(format!(
                "Unknown ci_method '{}'. Use 'percentile' or 'bca'.",
                other
            )));
        }
    };

    let cov_specs = if let Some(cov_list) = covariates {
        parse_covariates(cov_list, n_subjects)?
    } else {
        Vec::new()
    };

    let config = RustSaemConfig {
        n_burn,
        n_iter,
        n_chains,
        seed,
        tol,
        store_theta_trace: false,
        ..Default::default()
    };
    let estimator = RustSaemEstimator::new(config);

    // Build the concentration closure per model type.
    let result: Result<RustBootstrapSaemResult, _> = match model {
        "1cpt_oral" => {
            let conc_fn = |th: &[f64], eta: &[f64], d: f64, t: f64| -> f64 {
                let cl = th[0] * eta[0].exp();
                let v = th[1] * eta[1].exp();
                let ka = th[2] * eta[2].exp();
                ns_inference::pk::conc_oral(d, bioavailability, cl, v, ka, t)
            };
            rust_bootstrap_saem(
                &estimator,
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &theta,
                &omega,
                n_bootstrap,
                conf_level,
                method,
                seed,
                &conc_fn,
                n_eta,
                em,
                &doses,
                &cov_specs,
            )
        }
        "2cpt_iv" => {
            let conc_fn = |th: &[f64], eta: &[f64], d: f64, t: f64| -> f64 {
                let cl = th[0] * eta[0].exp();
                let v1 = th[1] * eta[1].exp();
                let q = th[2] * eta[2].exp();
                let v2 = th[3] * eta[3].exp();
                ns_inference::pk::conc_iv_2cpt_macro(d, cl, v1, v2, q, t)
            };
            rust_bootstrap_saem(
                &estimator,
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &theta,
                &omega,
                n_bootstrap,
                conf_level,
                method,
                seed,
                &conc_fn,
                n_eta,
                em,
                &doses,
                &cov_specs,
            )
        }
        "2cpt_oral" => {
            let conc_fn = |th: &[f64], eta: &[f64], d: f64, t: f64| -> f64 {
                let cl = th[0] * eta[0].exp();
                let v1 = th[1] * eta[1].exp();
                let q = th[2] * eta[2].exp();
                let v2 = th[3] * eta[3].exp();
                let ka = th[4] * eta[4].exp();
                ns_inference::pk::conc_oral_2cpt_macro(d, bioavailability, cl, v1, v2, q, ka, t)
            };
            rust_bootstrap_saem(
                &estimator,
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &theta,
                &omega,
                n_bootstrap,
                conf_level,
                method,
                seed,
                &conc_fn,
                n_eta,
                em,
                &doses,
                &cov_specs,
            )
        }
        "3cpt_iv" => {
            let conc_fn = |th: &[f64], eta: &[f64], d: f64, t: f64| -> f64 {
                let cl = th[0] * eta[0].exp();
                let v1 = th[1] * eta[1].exp();
                let q2 = th[2] * eta[2].exp();
                let v2 = th[3] * eta[3].exp();
                let q3 = th[4] * eta[4].exp();
                let v3 = th[5] * eta[5].exp();
                conc_iv_3cpt_macro(d, t, cl, v1, q2, v2, q3, v3)
            };
            rust_bootstrap_saem(
                &estimator,
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &theta,
                &omega,
                n_bootstrap,
                conf_level,
                method,
                seed,
                &conc_fn,
                n_eta,
                em,
                &doses,
                &cov_specs,
            )
        }
        "3cpt_oral" => {
            let conc_fn = |th: &[f64], eta: &[f64], d: f64, t: f64| -> f64 {
                let effective_dose = d * bioavailability;
                let cl = th[0] * eta[0].exp();
                let v1 = th[1] * eta[1].exp();
                let q2 = th[2] * eta[2].exp();
                let v2 = th[3] * eta[3].exp();
                let q3 = th[4] * eta[4].exp();
                let v3 = th[5] * eta[5].exp();
                let ka = th[6] * eta[6].exp();
                conc_oral_3cpt_macro(effective_dose, t, cl, v1, q2, v2, q3, v3, ka)
            };
            rust_bootstrap_saem(
                &estimator,
                &times,
                &y,
                &subject_idx,
                n_subjects,
                &theta,
                &omega,
                n_bootstrap,
                conf_level,
                method,
                seed,
                &conc_fn,
                n_eta,
                em,
                &doses,
                &cov_specs,
            )
        }
        _ => unreachable!(),
    };

    let bs = result.map_err(|e| PyValueError::new_err(e.to_string()))?;

    let dict = PyDict::new(py);
    dict.set_item(
        "theta_ci",
        bs.theta_ci.iter().map(|&(lo, hi)| vec![lo, hi]).collect::<Vec<_>>(),
    )?;
    dict.set_item(
        "omega_ci",
        bs.omega_ci.iter().map(|&(lo, hi)| vec![lo, hi]).collect::<Vec<_>>(),
    )?;
    dict.set_item("theta_se", bs.theta_se)?;
    dict.set_item("omega_se", bs.omega_se)?;
    dict.set_item("n_successful", bs.n_successful)?;
    dict.into_py_any(py)
}

/// Visual Predictive Check with PK model dispatch.
#[pyfunction]
#[pyo3(signature = (times, y, subject_idx, n_subjects, *, model="1cpt_oral", doses, bioavailability=1.0, theta, omega_matrix, error_model="proportional", sigma=0.1, sigma_add=None, n_sim=200, quantiles=None, n_bins=10, seed=42, pi_level=0.90))]
fn pk_vpc(
    py: Python<'_>,
    times: Vec<f64>,
    y: Vec<f64>,
    subject_idx: Vec<usize>,
    n_subjects: usize,
    model: &str,
    doses: Vec<f64>,
    bioavailability: f64,
    theta: Vec<f64>,
    omega_matrix: Vec<Vec<f64>>,
    error_model: &str,
    sigma: f64,
    sigma_add: Option<f64>,
    n_sim: usize,
    quantiles: Option<Vec<f64>>,
    n_bins: usize,
    seed: u64,
    pi_level: f64,
) -> PyResult<Py<PyAny>> {
    let model_kind = parse_pk_model_kind(model)?;
    let em = parse_error_model(error_model, sigma, sigma_add)?;
    let doses = if doses.len() == 1 { vec![doses[0]; n_subjects] } else { doses };
    let omega = RustOmegaMatrix::from_covariance(&omega_matrix)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
    let config = RustVpcConfig {
        n_sim,
        quantiles: quantiles.unwrap_or_else(|| vec![0.05, 0.50, 0.95]),
        n_bins,
        seed,
        pi_level,
    };
    let result = rust_vpc_pk(
        model_kind,
        &times,
        &y,
        &subject_idx,
        n_subjects,
        &doses,
        bioavailability,
        &theta,
        &omega,
        &em,
        &config,
    )
    .map_err(|e| PyValueError::new_err(e.to_string()))?;

    let bins_list = PyList::empty(py);
    for bin in &result.bins {
        let d = PyDict::new(py);
        d.set_item("time", bin.time)?;
        d.set_item("n_obs", bin.n_obs)?;
        d.set_item("obs_quantiles", bin.obs_quantiles.clone())?;
        d.set_item("sim_pi_lower", bin.sim_pi_lower.clone())?;
        d.set_item("sim_pi_median", bin.sim_pi_median.clone())?;
        d.set_item("sim_pi_upper", bin.sim_pi_upper.clone())?;
        bins_list.append(d)?;
    }
    let dict = PyDict::new(py);
    dict.set_item("bins", bins_list)?;
    dict.set_item("quantiles", result.quantiles.clone())?;
    dict.set_item("n_sim", result.n_sim)?;
    dict.into_py_any(py)
}

/// Goodness-of-fit diagnostics with PK model dispatch.
#[pyfunction]
#[pyo3(signature = (times, y, subject_idx, *, model="1cpt_oral", doses, bioavailability=1.0, theta, eta, error_model="proportional", sigma=0.1, sigma_add=None))]
fn pk_gof(
    py: Python<'_>,
    times: Vec<f64>,
    y: Vec<f64>,
    subject_idx: Vec<usize>,
    model: &str,
    doses: Vec<f64>,
    bioavailability: f64,
    theta: Vec<f64>,
    eta: Vec<Vec<f64>>,
    error_model: &str,
    sigma: f64,
    sigma_add: Option<f64>,
) -> PyResult<Py<PyAny>> {
    let model_kind = parse_pk_model_kind(model)?;
    let em = parse_error_model(error_model, sigma, sigma_add)?;
    let n_subjects = eta.len();
    let doses = if doses.len() == 1 { vec![doses[0]; n_subjects] } else { doses };
    let records = rust_gof_pk(
        model_kind,
        &times,
        &y,
        &subject_idx,
        &doses,
        bioavailability,
        &theta,
        &eta,
        &em,
    )
    .map_err(|e| PyValueError::new_err(e.to_string()))?;

    let list = PyList::empty(py);
    for r in &records {
        let d = PyDict::new(py);
        d.set_item("subject", r.subject)?;
        d.set_item("time", r.time)?;
        d.set_item("dv", r.dv)?;
        d.set_item("pred", r.pred)?;
        d.set_item("ipred", r.ipred)?;
        d.set_item("iwres", r.iwres)?;
        d.set_item("cwres", r.cwres)?;
        list.append(d)?;
    }
    list.into_py_any(py)
}

/// NPDE diagnostics with PK model dispatch.
#[pyfunction]
#[pyo3(signature = (times, y, subject_idx, n_subjects, *, model="1cpt_oral", doses, bioavailability=1.0, theta, omega_matrix, error_model="proportional", sigma=0.1, sigma_add=None, n_sim=1000, seed=42))]
fn pk_npde(
    py: Python<'_>,
    times: Vec<f64>,
    y: Vec<f64>,
    subject_idx: Vec<usize>,
    n_subjects: usize,
    model: &str,
    doses: Vec<f64>,
    bioavailability: f64,
    theta: Vec<f64>,
    omega_matrix: Vec<Vec<f64>>,
    error_model: &str,
    sigma: f64,
    sigma_add: Option<f64>,
    n_sim: usize,
    seed: u64,
) -> PyResult<Py<PyAny>> {
    let model_kind = parse_pk_model_kind(model)?;
    let em = parse_error_model(error_model, sigma, sigma_add)?;
    let doses = if doses.len() == 1 { vec![doses[0]; n_subjects] } else { doses };
    let omega = RustOmegaMatrix::from_covariance(&omega_matrix)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
    let cfg = RustNpdeConfig { n_sim, seed };
    let result = rust_npde_pk(
        model_kind,
        &times,
        &y,
        &subject_idx,
        n_subjects,
        &doses,
        bioavailability,
        &theta,
        &omega,
        &em,
        &cfg,
    )
    .map_err(|e| PyValueError::new_err(e.to_string()))?;

    let recs = PyList::empty(py);
    for r in &result.records {
        let d = PyDict::new(py);
        d.set_item("subject", r.subject)?;
        d.set_item("time", r.time)?;
        d.set_item("dv", r.dv)?;
        d.set_item("percentile", r.percentile)?;
        d.set_item("npde", r.npde)?;
        recs.append(d)?;
    }
    let out = PyDict::new(py);
    out.set_item("records", recs)?;
    out.set_item("mean", result.mean)?;
    out.set_item("variance", result.variance)?;
    out.into_py_any(py)
}

/// Parse NONMEM-format CSV dataset.
#[pyfunction]
fn read_nonmem(py: Python<'_>, csv_text: &str) -> PyResult<Py<PyAny>> {
    let ds =
        RustNonmemDataset::from_csv(csv_text).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let (times, dv, subject_idx) = ds.observation_data();
    let dict = PyDict::new(py);
    dict.set_item("n_subjects", ds.n_subjects())?;
    dict.set_item("subject_ids", ds.subject_ids().to_vec())?;
    dict.set_item("times", times)?;
    dict.set_item("dv", dv)?;
    dict.set_item("subject_idx", subject_idx)?;
    dict.into_py_any(py)
}

/// Read CDISC .xpt (SAS Transport v5) file.
///
/// Returns a list of dicts, one per dataset in the file.
/// Each dict has keys: name, label, variables, data.
#[pyfunction]
fn read_xpt(py: Python<'_>, path: &str) -> PyResult<Py<PyAny>> {
    let datasets =
        ns_inference::read_xpt(path).map_err(|e| PyValueError::new_err(e.to_string()))?;
    xpt_datasets_to_py(py, &datasets)
}

/// Write CDISC .xpt (SAS Transport v5) file.
///
/// Takes a path and a list of dataset dicts (same format as read_xpt output).
#[pyfunction]
fn write_xpt(py: Python<'_>, path: &str, datasets: &Bound<'_, PyList>) -> PyResult<Py<PyAny>> {
    let rust_datasets = py_to_xpt_datasets(datasets)?;
    ns_inference::write_xpt(path, &rust_datasets)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
    py.None().into_py_any(py)
}

/// Convert a .xpt dataset to NONMEM format by auto-detecting SDTM/ADaM columns.
///
/// Takes a single dataset dict (from read_xpt output) and returns a NONMEM dict.
#[pyfunction]
fn xpt_to_nonmem(py: Python<'_>, dataset: &Bound<'_, PyDict>) -> PyResult<Py<PyAny>> {
    let rust_ds = py_dict_to_xpt_dataset(dataset)?;
    let nonmem =
        ns_inference::xpt_to_nonmem(&rust_ds).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let (times, dv, subject_idx) = nonmem.observation_data();
    let dict = PyDict::new(py);
    dict.set_item("n_subjects", nonmem.n_subjects())?;
    dict.set_item("subject_ids", nonmem.subject_ids().to_vec())?;
    dict.set_item("times", times)?;
    dict.set_item("dv", dv)?;
    dict.set_item("subject_idx", subject_idx)?;
    dict.into_py_any(py)
}

/// Convert Rust XptDataset list to Python list of dicts.
fn xpt_datasets_to_py(py: Python<'_>, datasets: &[RustXptDataset]) -> PyResult<Py<PyAny>> {
    let list = PyList::empty(py);
    for ds in datasets {
        let d = PyDict::new(py);
        d.set_item("name", &ds.name)?;
        d.set_item("label", &ds.label)?;

        // Variables
        let vars_list = PyList::empty(py);
        for var in &ds.variables {
            let vd = PyDict::new(py);
            vd.set_item("name", &var.name)?;
            vd.set_item("label", &var.label)?;
            vd.set_item(
                "var_type",
                match var.var_type {
                    RustXptVarType::Numeric => "numeric",
                    RustXptVarType::Character => "character",
                },
            )?;
            vd.set_item("length", var.length)?;
            vd.set_item("format", &var.format)?;
            vars_list.append(vd)?;
        }
        d.set_item("variables", vars_list)?;

        // Data: list of lists
        let data_list = PyList::empty(py);
        for row in &ds.data {
            let row_list = PyList::empty(py);
            for val in row {
                match val {
                    RustXptValue::Numeric(v) => row_list.append(*v)?,
                    RustXptValue::Missing => row_list.append(py.None())?,
                    RustXptValue::Character(s) => row_list.append(s)?,
                }
            }
            data_list.append(row_list)?;
        }
        d.set_item("data", data_list)?;

        list.append(d)?;
    }
    list.into_py_any(py)
}

/// Convert a Python dict to a Rust XptDataset.
fn py_dict_to_xpt_dataset(d: &Bound<'_, PyDict>) -> PyResult<RustXptDataset> {
    let name: String = d
        .get_item("name")?
        .ok_or_else(|| PyValueError::new_err("missing 'name' key"))?
        .extract()?;
    let label: String = d
        .get_item("label")?
        .ok_or_else(|| PyValueError::new_err("missing 'label' key"))?
        .extract()?;

    let vars_any =
        d.get_item("variables")?.ok_or_else(|| PyValueError::new_err("missing 'variables' key"))?;
    let vars_list = vars_any
        .cast::<PyList>()
        .map_err(|_| PyValueError::new_err("'variables' must be a list"))?;

    let mut variables = Vec::new();
    for item in vars_list.iter() {
        let vd = item
            .cast::<PyDict>()
            .map_err(|_| PyValueError::new_err("each variable must be a dict"))?;
        let vname: String = vd
            .get_item("name")?
            .ok_or_else(|| PyValueError::new_err("variable missing 'name'"))?
            .extract()?;
        let vlabel: String =
            vd.get_item("label")?.map(|v| v.extract()).unwrap_or(Ok(String::new()))?;
        let vtype_str: String = vd
            .get_item("var_type")?
            .ok_or_else(|| PyValueError::new_err("variable missing 'var_type'"))?
            .extract()?;
        let var_type = match vtype_str.as_str() {
            "numeric" => RustXptVarType::Numeric,
            "character" => RustXptVarType::Character,
            other => return Err(PyValueError::new_err(format!("unknown var_type: {other}"))),
        };
        let length: usize = vd
            .get_item("length")?
            .ok_or_else(|| PyValueError::new_err("variable missing 'length'"))?
            .extract()?;
        let format: String =
            vd.get_item("format")?.map(|v| v.extract()).unwrap_or(Ok(String::new()))?;

        variables.push(RustXptVariable { name: vname, label: vlabel, var_type, length, format });
    }

    let data_any =
        d.get_item("data")?.ok_or_else(|| PyValueError::new_err("missing 'data' key"))?;
    let data_list =
        data_any.cast::<PyList>().map_err(|_| PyValueError::new_err("'data' must be a list"))?;

    let mut data = Vec::new();
    for row_item in data_list.iter() {
        let row_list = row_item
            .cast::<PyList>()
            .map_err(|_| PyValueError::new_err("each data row must be a list"))?;
        let mut row = Vec::new();
        for (col_idx, val) in row_list.iter().enumerate() {
            let var_type =
                variables.get(col_idx).map(|v| v.var_type).unwrap_or(RustXptVarType::Numeric);
            if val.is_none() {
                row.push(RustXptValue::Missing);
            } else {
                match var_type {
                    RustXptVarType::Numeric => {
                        let v: f64 = val.extract().map_err(|_| {
                            PyValueError::new_err(format!(
                                "cannot convert value to float at column {col_idx}"
                            ))
                        })?;
                        row.push(RustXptValue::Numeric(v));
                    }
                    RustXptVarType::Character => {
                        let s: String = val.extract().map_err(|_| {
                            PyValueError::new_err(format!(
                                "cannot convert value to string at column {col_idx}"
                            ))
                        })?;
                        row.push(RustXptValue::Character(s));
                    }
                }
            }
        }
        data.push(row);
    }

    Ok(RustXptDataset { name, label, variables, data })
}

/// Convert a Python list of dataset dicts to Rust XptDataset vec.
fn py_to_xpt_datasets(datasets: &Bound<'_, PyList>) -> PyResult<Vec<RustXptDataset>> {
    let mut result = Vec::new();
    for item in datasets.iter() {
        let d = item
            .cast::<PyDict>()
            .map_err(|_| PyValueError::new_err("each dataset must be a dict"))?;
        result.push(py_dict_to_xpt_dataset(d)?);
    }
    Ok(result)
}

/// Stepwise Covariate Modeling (SCM) for 1-compartment oral PK model.
///
/// Forward selection + backward elimination of covariate–parameter
/// relationships using ΔOFV (χ²(1) likelihood ratio test).
#[pyfunction]
#[pyo3(signature = (times, y, subject_idx, n_subjects, covariates, covariate_names, *, dose, bioavailability=1.0, error_model="proportional", sigma=0.1, sigma_add=None, theta_init, omega_init, param_names=None, relationships=None, forward_alpha=0.05, backward_alpha=0.01, max_outer_iter=100, max_inner_iter=20, tol=1e-4, rel_tol=1e-8))]
fn scm(
    py: Python<'_>,
    times: Vec<f64>,
    y: Vec<f64>,
    subject_idx: Vec<usize>,
    n_subjects: usize,
    covariates: Vec<Vec<f64>>,
    covariate_names: Vec<String>,
    dose: f64,
    bioavailability: f64,
    error_model: &str,
    sigma: f64,
    sigma_add: Option<f64>,
    theta_init: Vec<f64>,
    omega_init: Vec<f64>,
    param_names: Option<Vec<String>>,
    relationships: Option<Vec<String>>,
    forward_alpha: f64,
    backward_alpha: f64,
    max_outer_iter: usize,
    max_inner_iter: usize,
    tol: f64,
    rel_tol: f64,
) -> PyResult<Py<PyAny>> {
    let em = parse_error_model(error_model, sigma, sigma_add)?;
    let foce_cfg = RustFoceConfig {
        max_outer_iter,
        max_inner_iter,
        tol,
        rel_tol,
        interaction: true,
        omega_damping: 0.7,
        omega_max_ratio: 100.0,
        estimate_sigma: true,
        lloq: None,
        omega_fixed: Vec::new(),
        diagonal_omega: false,
    };
    let omega = RustOmegaMatrix::from_diagonal(&omega_init)
        .map_err(|e| PyValueError::new_err(e.to_string()))?;
    let pnames = param_names.unwrap_or_else(|| vec!["CL".into(), "V".into(), "Ka".into()]);

    // Validate covariates dimensions.
    let n_obs = times.len();
    if covariates.len() != covariate_names.len() {
        return Err(PyValueError::new_err(
            "covariates and covariate_names must have the same length",
        ));
    }
    for (i, cov) in covariates.iter().enumerate() {
        if cov.len() != n_obs {
            return Err(PyValueError::new_err(format!(
                "covariate '{}' has {} values, expected {} (n_obs)",
                covariate_names[i],
                cov.len(),
                n_obs,
            )));
        }
    }

    // Extract per-subject covariate values (first observation per subject).
    let mut subj_first: Vec<Option<usize>> = vec![None; n_subjects];
    for (i, &s) in subject_idx.iter().enumerate() {
        if s < n_subjects && subj_first[s].is_none() {
            subj_first[s] = Some(i);
        }
    }

    // Build candidate list: each covariate × each PK parameter.
    let mut candidates: Vec<RustCovariateCandidate> = Vec::new();
    for (ci, cov_name) in covariate_names.iter().enumerate() {
        let rel = if let Some(ref rels) = relationships {
            if ci < rels.len() {
                match rels[ci].to_ascii_lowercase().as_str() {
                    "power" => RustCovariateRelationship::Power,
                    "proportional" => RustCovariateRelationship::Proportional,
                    "exponential" => RustCovariateRelationship::Exponential,
                    other => {
                        return Err(PyValueError::new_err(format!(
                            "Unknown relationship '{other}'. Use 'power', 'proportional', or 'exponential'.",
                        )));
                    }
                }
            } else {
                RustCovariateRelationship::Power
            }
        } else {
            RustCovariateRelationship::Power
        };

        // Per-subject values.
        let subj_vals: Vec<f64> = (0..n_subjects)
            .map(|s| subj_first[s].map(|idx| covariates[ci][idx]).unwrap_or(0.0))
            .collect();

        // Centering: median.
        let mut sorted = subj_vals.clone();
        sorted.sort_by(|a, b| a.partial_cmp(b).unwrap_or(std::cmp::Ordering::Equal));
        let center = if sorted.len().is_multiple_of(2) {
            0.5 * (sorted[sorted.len() / 2 - 1] + sorted[sorted.len() / 2])
        } else {
            sorted[sorted.len() / 2]
        };

        // Test this covariate on each PK parameter.
        for pidx in 0..pnames.len().min(3) {
            candidates.push(RustCovariateCandidate {
                name: format!("{}_on_{}", cov_name, pnames[pidx]),
                param_index: pidx,
                values: subj_vals.clone(),
                center,
                relationship: rel,
            });
        }
    }

    let config = RustScmConfig { forward_alpha, backward_alpha, foce: foce_cfg };
    let estimator = RustScmEstimator::new(config);

    let result = estimator
        .run_1cpt_oral(
            &times,
            &y,
            &subject_idx,
            n_subjects,
            dose,
            bioavailability,
            em,
            &theta_init,
            &omega,
            &candidates,
        )
        .map_err(|e| PyValueError::new_err(e.to_string()))?;

    // Convert ScmStep → PyDict.
    let step_to_dict = |py: Python<'_>, s: &ns_inference::ScmStep| -> PyResult<Py<PyAny>> {
        let d = PyDict::new(py);
        d.set_item("name", &s.name)?;
        d.set_item("param_index", s.param_index)?;
        d.set_item(
            "relationship",
            match s.relationship {
                RustCovariateRelationship::Power => "power",
                RustCovariateRelationship::Proportional => "proportional",
                RustCovariateRelationship::Exponential => "exponential",
            },
        )?;
        d.set_item("delta_ofv", s.delta_ofv)?;
        d.set_item("p_value", s.p_value)?;
        d.set_item("coefficient", s.coefficient)?;
        d.set_item("included", s.included)?;
        d.into_py_any(py)
    };

    let selected = PyList::empty(py);
    for s in &result.selected {
        selected.append(step_to_dict(py, s)?)?;
    }
    let forward_trace = PyList::empty(py);
    for s in &result.forward_trace {
        forward_trace.append(step_to_dict(py, s)?)?;
    }
    let backward_trace = PyList::empty(py);
    for s in &result.backward_trace {
        backward_trace.append(step_to_dict(py, s)?)?;
    }

    let dict = PyDict::new(py);
    dict.set_item("selected", selected)?;
    dict.set_item("forward_trace", forward_trace)?;
    dict.set_item("backward_trace", backward_trace)?;
    dict.set_item("base_ofv", result.base_ofv)?;
    dict.set_item("final_ofv", result.ofv)?;
    dict.set_item("n_forward_steps", result.forward_trace.len())?;
    dict.set_item("n_backward_steps", result.backward_trace.len())?;
    dict.set_item("theta", result.theta.clone())?;
    dict.set_item("omega", result.omega.to_matrix())?;
    dict.into_py_any(py)
}

// ---------------------------------------------------------------------------
// LMM (Phase 9 Pack B).
// ---------------------------------------------------------------------------

/// Python wrapper for `LmmMarginalModel` (Gaussian mixed model, marginal likelihood).
#[pyclass(name = "LmmMarginalModel")]
struct PyLmmMarginalModel {
    inner: RustLmmMarginalModel,
}

#[pymethods]
impl PyLmmMarginalModel {
    #[new]
    #[pyo3(signature = (x, y, *, include_intercept=true, group_idx, n_groups=None, random_slope_feature_idx=None, use_reml=false))]
    fn new(
        x: Vec<Vec<f64>>,
        y: Vec<f64>,
        include_intercept: bool,
        group_idx: Vec<usize>,
        n_groups: Option<usize>,
        random_slope_feature_idx: Option<usize>,
        use_reml: bool,
    ) -> PyResult<Self> {
        let ng = n_groups.unwrap_or_else(|| group_idx.iter().copied().max().unwrap_or(0) + 1);
        let re = if let Some(k) = random_slope_feature_idx {
            RustLmmRandomEffects::InterceptSlope { feature_idx: k }
        } else {
            RustLmmRandomEffects::Intercept
        };
        let inner = RustLmmMarginalModel::new(x, y, include_intercept, group_idx, ng, re)
            .map_err(|e| PyValueError::new_err(e.to_string()))?
            .with_reml(use_reml);
        Ok(Self { inner })
    }

    /// Returns `true` if REML estimation is enabled.
    fn is_reml(&self) -> bool {
        self.inner.is_reml()
    }

    fn n_params(&self) -> usize {
        self.inner.dim()
    }

    fn dim(&self) -> usize {
        self.n_params()
    }

    fn nll(&self, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll(&params)
            .map_err(|e| PyValueError::new_err(format!("NLL computation failed: {}", e)))
    }

    fn grad_nll(&self, params: Vec<f64>) -> PyResult<Vec<f64>> {
        self.inner
            .grad_nll(&params)
            .map_err(|e| PyValueError::new_err(format!("Gradient computation failed: {}", e)))
    }

    fn parameter_names(&self) -> Vec<String> {
        self.inner.parameter_names()
    }

    fn suggested_init(&self) -> Vec<f64> {
        self.inner.parameter_init()
    }

    fn suggested_bounds(&self) -> Vec<(f64, f64)> {
        self.inner.parameter_bounds()
    }
}

/// Python wrapper for FitResult
#[pyclass(name = "FitResult")]
struct PyFitResult {
    #[pyo3(get)]
    parameters: Vec<f64>,
    #[pyo3(get)]
    uncertainties: Vec<f64>,
    #[pyo3(get)]
    nll: f64,
    #[pyo3(get)]
    converged: bool,
    #[pyo3(get)]
    n_iter: usize,
    #[pyo3(get)]
    n_fev: usize,
    #[pyo3(get)]
    n_gev: usize,
    #[pyo3(get)]
    termination_reason: String,
    #[pyo3(get)]
    final_grad_norm: f64,
    #[pyo3(get)]
    initial_nll: f64,
    #[pyo3(get)]
    n_active_bounds: usize,
    #[pyo3(get)]
    edm: f64,
    #[pyo3(get)]
    warnings: Vec<String>,
}

#[pymethods]
impl PyFitResult {
    /// Alias: `bestfit` (pyhf-style).
    #[getter]
    fn bestfit(&self) -> Vec<f64> {
        self.parameters.clone()
    }

    /// Alias: `twice_nll = 2 * nll` (pyhf-style).
    #[getter]
    fn twice_nll(&self) -> f64 {
        2.0 * self.nll
    }

    /// Alias: `success` (pyhf-style).
    #[getter]
    fn success(&self) -> bool {
        self.converged
    }

    /// Back-compat alias: `n_evaluations` historically contained argmin iterations.
    #[getter]
    fn n_evaluations(&self) -> usize {
        self.n_iter
    }
}

impl From<ns_core::FitResult> for PyFitResult {
    fn from(r: ns_core::FitResult) -> Self {
        PyFitResult {
            parameters: r.parameters,
            uncertainties: r.uncertainties,
            nll: r.nll,
            converged: r.converged,
            n_iter: r.n_iter,
            n_fev: r.n_fev,
            n_gev: r.n_gev,
            termination_reason: r.termination_reason,
            final_grad_norm: r.final_grad_norm,
            initial_nll: r.initial_nll,
            n_active_bounds: r.n_active_bounds,
            edm: r.edm,
            warnings: r.warnings,
        }
    }
}

/// Python wrapper for OptimizationResult (fast-path: no covariance/Hessian).
#[pyclass(name = "FitMinimumResult")]
struct PyFitMinimumResult {
    #[pyo3(get)]
    parameters: Vec<f64>,
    /// Objective value at the minimum (NLL for likelihood models).
    #[pyo3(get)]
    nll: f64,
    #[pyo3(get)]
    converged: bool,
    #[pyo3(get)]
    n_iter: u64,
    #[pyo3(get)]
    n_fev: usize,
    #[pyo3(get)]
    n_gev: usize,
    /// Termination message from the optimizer.
    #[pyo3(get)]
    message: String,
    /// Objective value at the initial point (before optimisation).
    #[pyo3(get)]
    initial_nll: f64,
    /// Final gradient vector (None for gradient-free paths).
    #[pyo3(get)]
    final_gradient: Option<Vec<f64>>,
    /// Estimated Distance to Minimum (EDM = g^T H^{-1} g). NaN if unavailable.
    #[pyo3(get)]
    edm: f64,
}

#[pymethods]
impl PyFitMinimumResult {
    /// Alias: `bestfit` (pyhf-style).
    #[getter]
    fn bestfit(&self) -> Vec<f64> {
        self.parameters.clone()
    }

    /// Alias: `twice_nll = 2 * nll` (pyhf-style).
    #[getter]
    fn twice_nll(&self) -> f64 {
        2.0 * self.nll
    }

    /// Alias: `success` (pyhf-style).
    #[getter]
    fn success(&self) -> bool {
        self.converged
    }
}

impl From<RustOptimizationResult> for PyFitMinimumResult {
    fn from(r: RustOptimizationResult) -> Self {
        PyFitMinimumResult {
            parameters: r.parameters,
            nll: r.fval,
            converged: r.converged,
            n_iter: r.n_iter,
            n_fev: r.n_fev,
            n_gev: r.n_gev,
            message: r.message,
            initial_nll: r.initial_cost,
            final_gradient: r.final_gradient,
            edm: r.edm,
        }
    }
}

/// Python wrapper for MaximumLikelihoodEstimator
#[pyclass(name = "MaximumLikelihoodEstimator")]
struct PyMaximumLikelihoodEstimator {
    inner: RustMLE,
}

#[pymethods]
impl PyMaximumLikelihoodEstimator {
    #[new]
    #[pyo3(signature = (*, max_iter=1000, tol=1e-6, m=0, smooth_bounds=false))]
    fn new(max_iter: u64, tol: f64, m: usize, smooth_bounds: bool) -> PyResult<Self> {
        if !tol.is_finite() || tol < 0.0 {
            return Err(PyValueError::new_err("tol must be finite and >= 0"));
        }
        let cfg = OptimizerConfig { max_iter, tol, m, smooth_bounds };
        Ok(PyMaximumLikelihoodEstimator { inner: RustMLE::with_config(cfg) })
    }

    /// Fit any supported model (generic `LogDensityModel`) using MLE.
    ///
    /// `data=` is only supported for `HistFactoryModel` (overrides main-bin observations).
    /// `init_pars=` overrides the model's default initial parameters (warm-start).
    #[pyo3(signature = (model, *, data=None, init_pars=None))]
    fn fit<'py>(
        &self,
        py: Python<'py>,
        model: &Bound<'py, PyAny>,
        data: Option<Vec<f64>>,
        init_pars: Option<Vec<f64>>,
    ) -> PyResult<PyFitResult> {
        let fit_model = extract_posterior_model_with_data(model, data)?;

        if let Some(ref ip) = init_pars {
            validate_f64_vec("init_pars", ip, fit_model.dim())?;
        }

        let mle = self.inner.clone();
        let result = py
            .detach(move || {
                if let Some(ip) = init_pars {
                    fit_model.fit_mle_from(&mle, &ip)
                } else {
                    fit_model.fit_mle(&mle)
                }
            })
            .map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;

        Ok(PyFitResult::from(result))
    }

    /// Minimize NLL and return the fast-path optimizer result (no covariance/Hessian).
    ///
    /// This is the recommended entrypoint for profile likelihood scans and conditional fits.
    ///
    /// `data=` is only supported for `HistFactoryModel` (overrides main-bin observations).
    /// `init_pars=` overrides the model's default initial parameters (warm-start).
    /// `bounds=` (HistFactoryModel only) overrides parameter bounds; clamp a parameter to
    /// `(value, value)` to fix it.
    #[pyo3(signature = (model, *, data=None, init_pars=None, bounds=None))]
    fn fit_minimum<'py>(
        &self,
        py: Python<'py>,
        model: &Bound<'py, PyAny>,
        data: Option<Vec<f64>>,
        init_pars: Option<Vec<f64>>,
        bounds: Option<Vec<(f64, f64)>>,
    ) -> PyResult<PyFitMinimumResult> {
        let fit_model = extract_posterior_model_with_data(model, data)?;

        if let Some(ref ip) = init_pars {
            validate_f64_vec("init_pars", ip, fit_model.dim())?;
        }
        if let Some(ref b) = bounds {
            validate_bounds("bounds", b, fit_model.dim())?;
        }
        if bounds.is_some() && !matches!(fit_model, PosteriorModel::HistFactory(_)) {
            return Err(PyValueError::new_err(
                "bounds= is currently only supported for HistFactoryModel",
            ));
        }

        let mle = self.inner.clone();
        let result = py
            .detach(move || {
                let init_slice = init_pars.as_deref();
                match fit_model {
                    PosteriorModel::HistFactory(m) => {
                        let init_storage;
                        let init: &[f64] = match init_slice {
                            Some(ip) => ip,
                            None => {
                                init_storage = m.parameter_init();
                                &init_storage
                            }
                        };

                        let bounds_storage;
                        let b: &[(f64, f64)] = match bounds.as_deref() {
                            Some(bs) => bs,
                            None => {
                                bounds_storage = m.parameter_bounds();
                                &bounds_storage
                            }
                        };

                        let mut tape = AdTape::with_capacity(m.n_params() * 20);
                        mle.fit_minimum_histfactory_from_with_bounds_with_tape(
                            &m, init, b, &mut tape,
                        )
                    }
                    PosteriorModel::Unbinned(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::Hybrid(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::GaussianMean(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::Funnel(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::FunnelNcp(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::StdNormal(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::LinearRegression(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::LogisticRegression(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::OrderedLogit(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::OrderedProbit(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::PoissonRegression(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::NegativeBinomialRegression(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::ComposedGlm(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::LmmMarginal(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::ExponentialSurvival(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::WeibullSurvival(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::LogNormalAft(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::CoxPh(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::OneCompartmentOralPk(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::OneCompartmentOralPkNlme(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::TwoCompartmentIvPk(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::TwoCompartmentOralPk(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::ThreeCompartmentIvPk(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::ThreeCompartmentOralPk(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::GammaRegression(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::TweedieRegression(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::Gev(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::Gpd(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::IntervalCensoredWeibull(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::IntervalCensoredWeibullAft(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::IntervalCensoredExponential(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::IntervalCensoredLogNormal(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                    PosteriorModel::EightSchools(m) => match init_slice {
                        Some(ip) => mle.fit_minimum_from(&m, ip),
                        None => mle.fit_minimum(&m),
                    },
                }
            })
            .map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;

        Ok(PyFitMinimumResult::from(result))
    }

    /// Fit multiple models in parallel (Rayon).
    ///
    /// Two call forms:
    /// - `fit_batch(models)` — list of models, each with its own observations
    /// - `fit_batch(model, datasets)` — HistFactoryModel + list of observation vectors
    ///
    /// Notes:
    /// - Lists must be homogeneous (all items of the same supported model type).
    /// - `datasets=` is only supported for HistFactoryModel.
    #[pyo3(signature = (models_or_model, datasets=None))]
    fn fit_batch<'py>(
        &self,
        py: Python<'py>,
        models_or_model: &Bound<'py, PyAny>,
        datasets: Option<Vec<Vec<f64>>>,
    ) -> PyResult<Vec<PyFitResult>> {
        let mle = self.inner.clone();

        if let Some(datasets) = datasets {
            // Single model + multiple datasets
            let hf = models_or_model.extract::<PyRef<'_, PyHistFactoryModel>>().map_err(|_| {
                PyValueError::new_err(
                    "When datasets is given, first argument must be a HistFactoryModel",
                )
            })?;
            let base = hf.inner.clone();
            let models: Vec<RustModel> = datasets
                .into_iter()
                .map(|ds| {
                    base.with_observed_main(&ds).map_err(|e| {
                        PyValueError::new_err(format!("Failed to set observed data: {}", e))
                    })
                })
                .collect::<PyResult<Vec<_>>>()?;

            let results = py.detach(move || mle.fit_batch(&models));

            results
                .into_iter()
                .map(|r| {
                    let r = r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                    Ok(PyFitResult::from(r))
                })
                .collect()
        } else {
            // List of models
            let list = models_or_model.cast::<PyList>().map_err(|_| {
                PyValueError::new_err(
                    "Expected a list of models or (HistFactoryModel, datasets=...)",
                )
            })?;

            if list.is_empty() {
                return Err(PyValueError::new_err("models list must be non-empty"));
            }

            let first = list.get_item(0)?;

            // Determine the concrete model type from the first item, then enforce homogeneity.
            if first.extract::<PyRef<'_, PyHistFactoryModel>>().is_ok() {
                let mut models: Vec<RustModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let hf = item.extract::<PyRef<'_, PyHistFactoryModel>>().map_err(|_| {
                        PyValueError::new_err("All items in the list must be HistFactoryModel")
                    })?;
                    models.push(hf.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyUnbinnedModel>>().is_ok() {
                let mut models: Vec<RustUnbinnedModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let ub = item.extract::<PyRef<'_, PyUnbinnedModel>>().map_err(|_| {
                        PyValueError::new_err("All items in the list must be UnbinnedModel")
                    })?;
                    models.push(ub.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyGaussianMeanModel>>().is_ok() {
                let mut models: Vec<GaussianMeanModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let gm = item.extract::<PyRef<'_, PyGaussianMeanModel>>().map_err(|_| {
                        PyValueError::new_err("All items in the list must be GaussianMeanModel")
                    })?;
                    models.push(gm.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyLinearRegressionModel>>().is_ok() {
                let mut models: Vec<RustLinearRegressionModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let lr =
                        item.extract::<PyRef<'_, PyLinearRegressionModel>>().map_err(|_| {
                            PyValueError::new_err(
                                "All items in the list must be LinearRegressionModel",
                            )
                        })?;
                    models.push(lr.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyLogisticRegressionModel>>().is_ok() {
                let mut models: Vec<RustLogisticRegressionModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let logit =
                        item.extract::<PyRef<'_, PyLogisticRegressionModel>>().map_err(|_| {
                            PyValueError::new_err(
                                "All items in the list must be LogisticRegressionModel",
                            )
                        })?;
                    models.push(logit.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyOrderedLogitModel>>().is_ok() {
                let mut models: Vec<RustOrderedLogitModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let m = item.extract::<PyRef<'_, PyOrderedLogitModel>>().map_err(|_| {
                        PyValueError::new_err("All items in the list must be OrderedLogitModel")
                    })?;
                    models.push(m.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyOrderedProbitModel>>().is_ok() {
                let mut models: Vec<RustOrderedProbitModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let m = item.extract::<PyRef<'_, PyOrderedProbitModel>>().map_err(|_| {
                        PyValueError::new_err("All items in the list must be OrderedProbitModel")
                    })?;
                    models.push(m.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyPoissonRegressionModel>>().is_ok() {
                let mut models: Vec<RustPoissonRegressionModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let pois =
                        item.extract::<PyRef<'_, PyPoissonRegressionModel>>().map_err(|_| {
                            PyValueError::new_err(
                                "All items in the list must be PoissonRegressionModel",
                            )
                        })?;
                    models.push(pois.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyNegativeBinomialRegressionModel>>().is_ok() {
                let mut models: Vec<RustNegativeBinomialRegressionModel> =
                    Vec::with_capacity(list.len());
                for item in list.iter() {
                    let nb = item
                        .extract::<PyRef<'_, PyNegativeBinomialRegressionModel>>()
                        .map_err(|_| {
                            PyValueError::new_err(
                                "All items in the list must be NegativeBinomialRegressionModel",
                            )
                        })?;
                    models.push(nb.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyComposedGlmModel>>().is_ok() {
                let mut models: Vec<RustComposedGlmModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let glm = item.extract::<PyRef<'_, PyComposedGlmModel>>().map_err(|_| {
                        PyValueError::new_err("All items in the list must be ComposedGlmModel")
                    })?;
                    models.push(glm.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyLmmMarginalModel>>().is_ok() {
                let mut models: Vec<RustLmmMarginalModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let m = item.extract::<PyRef<'_, PyLmmMarginalModel>>().map_err(|_| {
                        PyValueError::new_err("All items in the list must be LmmMarginalModel")
                    })?;
                    models.push(m.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyExponentialSurvivalModel>>().is_ok() {
                let mut models: Vec<RustExponentialSurvivalModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let m =
                        item.extract::<PyRef<'_, PyExponentialSurvivalModel>>().map_err(|_| {
                            PyValueError::new_err(
                                "All items in the list must be ExponentialSurvivalModel",
                            )
                        })?;
                    models.push(m.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyWeibullSurvivalModel>>().is_ok() {
                let mut models: Vec<RustWeibullSurvivalModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let m = item.extract::<PyRef<'_, PyWeibullSurvivalModel>>().map_err(|_| {
                        PyValueError::new_err("All items in the list must be WeibullSurvivalModel")
                    })?;
                    models.push(m.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyLogNormalAftModel>>().is_ok() {
                let mut models: Vec<RustLogNormalAftModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let m = item.extract::<PyRef<'_, PyLogNormalAftModel>>().map_err(|_| {
                        PyValueError::new_err("All items in the list must be LogNormalAftModel")
                    })?;
                    models.push(m.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyCoxPhModel>>().is_ok() {
                let mut models: Vec<RustCoxPhModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let m = item.extract::<PyRef<'_, PyCoxPhModel>>().map_err(|_| {
                        PyValueError::new_err("All items in the list must be CoxPhModel")
                    })?;
                    models.push(m.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyOneCompartmentOralPkModel>>().is_ok() {
                let mut models: Vec<RustOneCompartmentOralPkModel> = Vec::with_capacity(list.len());
                for item in list.iter() {
                    let m =
                        item.extract::<PyRef<'_, PyOneCompartmentOralPkModel>>().map_err(|_| {
                            PyValueError::new_err(
                                "All items in the list must be OneCompartmentOralPkModel",
                            )
                        })?;
                    models.push(m.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            if first.extract::<PyRef<'_, PyOneCompartmentOralPkNlmeModel>>().is_ok() {
                let mut models: Vec<RustOneCompartmentOralPkNlmeModel> =
                    Vec::with_capacity(list.len());
                for item in list.iter() {
                    let m = item.extract::<PyRef<'_, PyOneCompartmentOralPkNlmeModel>>().map_err(
                        |_| {
                            PyValueError::new_err(
                                "All items in the list must be OneCompartmentOralPkNlmeModel",
                            )
                        },
                    )?;
                    models.push(m.inner.clone());
                }

                let results = py.detach(move || mle.fit_batch(&models));
                return results
                    .into_iter()
                    .map(|r| {
                        let r =
                            r.map_err(|e| PyValueError::new_err(format!("Fit failed: {}", e)))?;
                        Ok(PyFitResult::from(r))
                    })
                    .collect();
            }

            Err(PyValueError::new_err(
                "Unsupported model type. Expected HistFactoryModel, GaussianMeanModel, a regression model, ComposedGlmModel, LmmMarginalModel, a survival model, or a PK model.",
            ))
        }
    }

    /// Generate Poisson toy pseudo-experiments and fit each in parallel.
    #[pyo3(signature = (model, params, *, n_toys=1000, seed=42))]
    fn fit_toys(
        &self,
        py: Python<'_>,
        model: &PyHistFactoryModel,
        params: Vec<f64>,
        n_toys: usize,
        seed: u64,
    ) -> PyResult<Vec<PyFitResult>> {
        let mle = self.inner.clone();
        let m = model.inner.clone();

        let results = py.detach(move || mle.fit_toys(&m, &params, n_toys, seed));

        results
            .into_iter()
            .map(|r| {
                let r = r.map_err(|e| PyValueError::new_err(format!("Toy fit failed: {}", e)))?;
                Ok(PyFitResult::from(r))
            })
            .collect()
    }

    /// Compute nuisance-parameter ranking (impact on POI).
    ///
    /// Returns a list of dicts with keys: name, delta_mu_up, delta_mu_down, pull, constraint.
    fn ranking<'py>(
        &self,
        py: Python<'py>,
        model: &PyHistFactoryModel,
    ) -> PyResult<Vec<Py<PyAny>>> {
        let mle = self.inner.clone();
        let m = model.inner.clone();

        let entries: Vec<RankingEntry> = py
            .detach(move || mle.ranking(&m))
            .map_err(|e| PyValueError::new_err(format!("Ranking failed: {}", e)))?;

        entries
            .into_iter()
            .map(|e| {
                let d = PyDict::new(py);
                d.set_item("name", e.name)?;
                d.set_item("delta_mu_up", e.delta_mu_up)?;
                d.set_item("delta_mu_down", e.delta_mu_down)?;
                d.set_item("pull", e.pull)?;
                d.set_item("constraint", e.constraint)?;
                Ok(d.into_any().unbind())
            })
            .collect()
    }

    /// Discovery-style `q0` and gradient w.r.t. one sample's nominal yields (main bins).
    ///
    /// This mutates the provided `HistFactoryModel` in place by overriding the specified
    /// sample's nominal yields before computing the profiled test statistic.
    ///
    /// Notes:
    /// - The overridden sample must have only multiplicative modifiers (NormFactor/NormSys/Lumi).
    /// - This is intended for ML/training-loop use; prefer reusing a single model instance.
    #[pyo3(signature = (model, *, channel, sample, nominal))]
    fn q0_like_loss_and_grad_nominal(
        &self,
        model: &mut PyHistFactoryModel,
        channel: &str,
        sample: &str,
        nominal: &Bound<'_, PyAny>,
    ) -> PyResult<(f64, Vec<f64>)> {
        let nominal = extract_f64_vec(nominal)?;
        if nominal.iter().any(|v| !v.is_finite()) {
            return Err(PyValueError::new_err("nominal must contain only finite values"));
        }

        let (ch_idx, s_idx) = model
            .inner
            .set_sample_nominal_by_name(channel, sample, &nominal)
            .map_err(|e| PyValueError::new_err(format!("Failed to set sample nominal: {}", e)))?;

        let (q0, grad) = self
            .inner
            .q0_like_loss_and_grad_sample_nominal(&model.inner, ch_idx, s_idx)
            .map_err(|e| PyValueError::new_err(format!("q0_like failed: {}", e)))?;

        Ok((q0, grad))
    }

    /// Upper-limit-style `q_mu` and gradient w.r.t. one sample's nominal yields (main bins).
    ///
    /// This mutates the provided `HistFactoryModel` in place by overriding the specified
    /// sample's nominal yields before computing the profiled test statistic.
    #[pyo3(signature = (model, *, mu_test, channel, sample, nominal))]
    fn qmu_like_loss_and_grad_nominal(
        &self,
        model: &mut PyHistFactoryModel,
        mu_test: f64,
        channel: &str,
        sample: &str,
        nominal: &Bound<'_, PyAny>,
    ) -> PyResult<(f64, Vec<f64>)> {
        if !mu_test.is_finite() {
            return Err(PyValueError::new_err("mu_test must be finite"));
        }

        let nominal = extract_f64_vec(nominal)?;
        if nominal.iter().any(|v| !v.is_finite()) {
            return Err(PyValueError::new_err("nominal must contain only finite values"));
        }

        let (ch_idx, s_idx) = model
            .inner
            .set_sample_nominal_by_name(channel, sample, &nominal)
            .map_err(|e| PyValueError::new_err(format!("Failed to set sample nominal: {}", e)))?;

        let (q, grad) = self
            .inner
            .qmu_like_loss_and_grad_sample_nominal(&model.inner, mu_test, ch_idx, s_idx)
            .map_err(|e| PyValueError::new_err(format!("qmu_like failed: {}", e)))?;

        Ok((q, grad))
    }
}

/// Convenience wrapper: create model from pyhf JSON string.
#[pyfunction]
fn from_pyhf(json_str: &str) -> PyResult<PyHistFactoryModel> {
    PyHistFactoryModel::from_workspace(json_str)
}

// ---------------------------------------------------------------------------
// Arrow / Parquet integration
// ---------------------------------------------------------------------------

/// Create a HistFactoryModel from Arrow IPC bytes.
///
/// The IPC stream must contain a table with columns:
/// `channel` (Utf8), `sample` (Utf8), `yields` (List<Float64>),
/// optionally `stat_error` (List<Float64>).
///
/// Args:
///     ipc_bytes: bytes from `table.serialize()` (PyArrow IPC stream).
///     poi: parameter of interest name (default "mu").
///     observations: optional dict {channel_name: [obs_counts]}.
///
/// Returns:
///     HistFactoryModel
#[pyfunction]
#[pyo3(signature = (ipc_bytes, poi="mu", observations=None))]
fn from_arrow_ipc(
    ipc_bytes: &[u8],
    poi: &str,
    observations: Option<std::collections::HashMap<String, Vec<f64>>>,
) -> PyResult<PyHistFactoryModel> {
    let config = ns_translate::arrow::ingest::ArrowIngestConfig {
        poi: poi.to_string(),
        observations,
        ..Default::default()
    };

    let workspace = ns_translate::arrow::ingest::from_arrow_ipc(ipc_bytes, &config)
        .map_err(|e| PyValueError::new_err(format!("Arrow ingest failed: {e}")))?;

    let model = ns_translate::pyhf::HistFactoryModel::from_workspace(&workspace)
        .map_err(|e| PyValueError::new_err(format!("Model construction failed: {e}")))?;

    Ok(PyHistFactoryModel { inner: model })
}

/// Create a HistFactoryModel from a Parquet file.
///
/// The Parquet file must contain the histogram table schema:
/// `channel` (Utf8), `sample` (Utf8), `yields` (List<Float64>),
/// optionally `stat_error` (List<Float64>).
#[pyfunction]
#[pyo3(signature = (path, poi="mu", observations=None))]
fn from_parquet(
    path: &str,
    poi: &str,
    observations: Option<std::collections::HashMap<String, Vec<f64>>>,
) -> PyResult<PyHistFactoryModel> {
    let config = ns_translate::arrow::ingest::ArrowIngestConfig {
        poi: poi.to_string(),
        observations,
        ..Default::default()
    };

    let workspace = ns_translate::arrow::parquet::from_parquet(std::path::Path::new(path), &config)
        .map_err(|e| PyValueError::new_err(format!("Parquet ingest failed: {e}")))?;

    let model = ns_translate::pyhf::HistFactoryModel::from_workspace(&workspace)
        .map_err(|e| PyValueError::new_err(format!("Model construction failed: {e}")))?;

    Ok(PyHistFactoryModel { inner: model })
}

/// Create a HistFactoryModel from Parquet yields + modifiers files (binned Parquet v2).
///
/// The yields file must contain the histogram yields table schema:
/// `channel` (Utf8), `sample` (Utf8), `yields` (List<Float64>),
/// optionally `stat_error` (List<Float64>).
///
/// The modifiers file must contain the modifiers table schema:
/// `channel` (Utf8), `sample` (Utf8), `modifier_name` (Utf8), `modifier_type` (Utf8),
/// optionally `data_hi`/`data_lo`/`data` (List<Float64>).
#[pyfunction]
#[pyo3(signature = (yields_path, modifiers_path, poi="mu", observations=None))]
fn from_parquet_with_modifiers(
    yields_path: &str,
    modifiers_path: &str,
    poi: &str,
    observations: Option<std::collections::HashMap<String, Vec<f64>>>,
) -> PyResult<PyHistFactoryModel> {
    let config = ns_translate::arrow::ingest::ArrowIngestConfig {
        poi: poi.to_string(),
        observations,
        ..Default::default()
    };

    let workspace = ns_translate::arrow::parquet::from_parquet_with_modifiers(
        std::path::Path::new(yields_path),
        std::path::Path::new(modifiers_path),
        &config,
    )
    .map_err(|e| PyValueError::new_err(format!("Parquet ingest failed: {e}")))?;

    let model = ns_translate::pyhf::HistFactoryModel::from_workspace(&workspace)
        .map_err(|e| PyValueError::new_err(format!("Model construction failed: {e}")))?;

    Ok(PyHistFactoryModel { inner: model })
}

/// Export model expected yields as Arrow IPC bytes.
///
/// Returns bytes that can be deserialized with:
///     `pyarrow.ipc.open_stream(bytes).read_all()`
///
/// Schema: channel (Utf8), sample (Utf8), yields (List<Float64>).
#[pyfunction]
#[pyo3(signature = (model, params=None))]
fn to_arrow_yields_ipc<'py>(
    py: Python<'py>,
    model: &PyHistFactoryModel,
    params: Option<Vec<f64>>,
) -> PyResult<Py<pyo3::types::PyBytes>> {
    let p = params.unwrap_or_else(|| model.inner.parameters().iter().map(|p| p.init).collect());

    let ipc = ns_translate::arrow::export::yields_to_ipc(&model.inner, &p)
        .map_err(|e| PyValueError::new_err(format!("Arrow export failed: {e}")))?;

    Ok(pyo3::types::PyBytes::new(py, &ipc).unbind())
}

/// Export model parameters as Arrow IPC bytes.
///
/// Schema: name (Utf8), index (UInt32), value (Float64),
///         bound_lo (Float64), bound_hi (Float64), init (Float64).
#[pyfunction]
#[pyo3(signature = (model, params=None))]
fn to_arrow_params_ipc<'py>(
    py: Python<'py>,
    model: &PyHistFactoryModel,
    params: Option<Vec<f64>>,
) -> PyResult<Py<pyo3::types::PyBytes>> {
    let p_ref = params.as_deref();

    let ipc = ns_translate::arrow::export::parameters_to_ipc(&model.inner, p_ref)
        .map_err(|e| PyValueError::new_err(format!("Arrow export failed: {e}")))?;

    Ok(pyo3::types::PyBytes::new(py, &ipc).unbind())
}

/// Audit a pyhf workspace JSON string for compatibility.
///
/// Returns a dict with channels, modifier types, unsupported features, etc.
#[pyfunction]
fn workspace_audit(py: Python<'_>, json_str: &str) -> PyResult<Py<PyAny>> {
    let json: serde_json::Value = serde_json::from_str(json_str)
        .map_err(|e| PyValueError::new_err(format!("Invalid JSON: {}", e)))?;
    let audit = ns_translate::pyhf::audit::workspace_audit(&json);
    let audit_json = serde_json::to_value(&audit)
        .map_err(|e| PyValueError::new_err(format!("Serialization failed: {}", e)))?;
    json_value_to_py(py, &audit_json)
}

fn json_value_to_py(py: Python<'_>, val: &serde_json::Value) -> PyResult<Py<PyAny>> {
    use pyo3::types::{PyDict, PyFloat, PyList};
    match val {
        serde_json::Value::Null => Ok(py.None()),
        serde_json::Value::Bool(b) => {
            Ok(b.into_pyobject(py).unwrap().to_owned().into_any().unbind())
        }
        serde_json::Value::Number(n) => {
            if let Some(i) = n.as_i64() {
                Ok(i.into_pyobject(py).unwrap().into_any().unbind())
            } else {
                Ok(PyFloat::new(py, n.as_f64().unwrap_or(0.0)).into_any().unbind())
            }
        }
        serde_json::Value::String(s) => Ok(s.into_pyobject(py).unwrap().into_any().unbind()),
        serde_json::Value::Array(arr) => {
            let items: Vec<Py<PyAny>> =
                arr.iter().map(|v| json_value_to_py(py, v)).collect::<PyResult<_>>()?;
            Ok(PyList::new(py, &items).unwrap().into_any().unbind())
        }
        serde_json::Value::Object(map) => {
            let dict = PyDict::new(py);
            for (k, v) in map {
                dict.set_item(k, json_value_to_py(py, v)?)?;
            }
            Ok(dict.into_any().unbind())
        }
    }
}

/// Apply a pyhf PatchSet (HEPData) to a base workspace JSON string.
///
/// Returns the patched workspace as a pretty JSON string.
#[pyfunction]
#[pyo3(signature = (workspace_json, patchset_json, *, patch_name=None))]
fn apply_patchset(
    workspace_json: &str,
    patchset_json: &str,
    patch_name: Option<String>,
) -> PyResult<String> {
    let base: serde_json::Value =
        serde_json::from_str(workspace_json).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let ps: ns_translate::pyhf::PatchSet =
        serde_json::from_str(patchset_json).map_err(|e| PyValueError::new_err(e.to_string()))?;

    let patched = ps
        .apply_to_value(&base, patch_name.as_deref())
        .map_err(|e| PyValueError::new_err(format!("apply_patchset failed: {}", e)))?;

    serde_json::to_string_pretty(&patched).map_err(|e| PyValueError::new_err(e.to_string()))
}

// ---------------------------------------------------------------------------
// Workspace manipulation (G1-G5, G8, G10)
// ---------------------------------------------------------------------------

/// Combine two pyhf workspace JSON strings into one.
///
/// `join`: `"none"` (error on overlap), `"outer"` (overlap must be identical),
/// `"left_outer"` (keep left), `"right_outer"` (keep right).
#[pyfunction]
#[pyo3(signature = (workspace_json_1, workspace_json_2, *, join="none"))]
fn workspace_combine(
    workspace_json_1: &str,
    workspace_json_2: &str,
    join: &str,
) -> PyResult<String> {
    use ns_translate::pyhf::schema::CombineJoin;
    let ws1: ns_translate::pyhf::Workspace = serde_json::from_str(workspace_json_1)
        .map_err(|e| PyValueError::new_err(format!("Invalid JSON (ws1): {}", e)))?;
    let ws2: ns_translate::pyhf::Workspace = serde_json::from_str(workspace_json_2)
        .map_err(|e| PyValueError::new_err(format!("Invalid JSON (ws2): {}", e)))?;
    let join_mode = match join {
        "none" => CombineJoin::None,
        "outer" => CombineJoin::Outer,
        "left_outer" => CombineJoin::LeftOuter,
        "right_outer" => CombineJoin::RightOuter,
        _ => {
            return Err(PyValueError::new_err(format!(
                "Unknown join mode '{}'. Use 'none', 'outer', 'left_outer', or 'right_outer'.",
                join
            )));
        }
    };
    let combined = ws1.combine(&ws2, join_mode).map_err(PyValueError::new_err)?;
    serde_json::to_string_pretty(&combined).map_err(|e| PyValueError::new_err(e.to_string()))
}

/// Remove channels, samples, modifiers, and/or measurements from a pyhf workspace.
#[pyfunction]
#[pyo3(signature = (workspace_json, *, channels=vec![], samples=vec![], modifiers=vec![], measurements=vec![]))]
fn workspace_prune(
    workspace_json: &str,
    channels: Vec<String>,
    samples: Vec<String>,
    modifiers: Vec<String>,
    measurements: Vec<String>,
) -> PyResult<String> {
    let ws: ns_translate::pyhf::Workspace = serde_json::from_str(workspace_json)
        .map_err(|e| PyValueError::new_err(format!("Invalid JSON: {}", e)))?;
    let ch_refs: Vec<&str> = channels.iter().map(|s| s.as_str()).collect();
    let sa_refs: Vec<&str> = samples.iter().map(|s| s.as_str()).collect();
    let mo_refs: Vec<&str> = modifiers.iter().map(|s| s.as_str()).collect();
    let me_refs: Vec<&str> = measurements.iter().map(|s| s.as_str()).collect();
    let pruned = ws.prune(&ch_refs, &sa_refs, &mo_refs, &me_refs);
    serde_json::to_string_pretty(&pruned).map_err(|e| PyValueError::new_err(e.to_string()))
}

/// Rename channels, samples, modifiers, and/or measurements in a pyhf workspace.
#[pyfunction]
#[pyo3(signature = (workspace_json, *, channels=None, samples=None, modifiers=None, measurements=None))]
fn workspace_rename(
    workspace_json: &str,
    channels: Option<std::collections::HashMap<String, String>>,
    samples: Option<std::collections::HashMap<String, String>>,
    modifiers: Option<std::collections::HashMap<String, String>>,
    measurements: Option<std::collections::HashMap<String, String>>,
) -> PyResult<String> {
    let ws: ns_translate::pyhf::Workspace = serde_json::from_str(workspace_json)
        .map_err(|e| PyValueError::new_err(format!("Invalid JSON: {}", e)))?;
    let empty = std::collections::HashMap::new();
    let renamed = ws.rename(
        channels.as_ref().unwrap_or(&empty),
        samples.as_ref().unwrap_or(&empty),
        modifiers.as_ref().unwrap_or(&empty),
        measurements.as_ref().unwrap_or(&empty),
    );
    serde_json::to_string_pretty(&renamed).map_err(|e| PyValueError::new_err(e.to_string()))
}

/// Return a workspace with all components in canonical (sorted) order.
#[pyfunction]
fn workspace_sorted(workspace_json: &str) -> PyResult<String> {
    let ws: ns_translate::pyhf::Workspace = serde_json::from_str(workspace_json)
        .map_err(|e| PyValueError::new_err(format!("Invalid JSON: {}", e)))?;
    let sorted = ws.sorted();
    serde_json::to_string_pretty(&sorted).map_err(|e| PyValueError::new_err(e.to_string()))
}

/// Compute SHA-256 digest of the canonical (sorted) workspace.
#[pyfunction]
fn workspace_digest(workspace_json: &str) -> PyResult<String> {
    let ws: ns_translate::pyhf::Workspace = serde_json::from_str(workspace_json)
        .map_err(|e| PyValueError::new_err(format!("Invalid JSON: {}", e)))?;
    Ok(ws.digest())
}

/// Export a pyhf workspace to HistFactory XML format.
///
/// Returns a list of `(filename, xml_content)` tuples.
#[pyfunction]
#[pyo3(signature = (workspace_json, output_prefix="output"))]
fn workspace_to_xml(
    py: Python<'_>,
    workspace_json: &str,
    output_prefix: &str,
) -> PyResult<Py<PyAny>> {
    use pyo3::types::PyList;
    let ws: ns_translate::pyhf::Workspace = serde_json::from_str(workspace_json)
        .map_err(|e| PyValueError::new_err(format!("Invalid JSON: {}", e)))?;
    let xml_set = ns_translate::pyhf::xml_export::workspace_to_xml(&ws, output_prefix);
    let items: Vec<(String, String)> = xml_set.files;
    let py_items: Vec<Py<PyAny>> = items
        .into_iter()
        .map(|(name, content)| (name, content).into_pyobject(py).unwrap().into_any().unbind())
        .collect();
    Ok(PyList::new(py, &py_items).unwrap().into_any().unbind())
}

/// Build a workspace with uncorrelated background uncertainties (shapesys).
///
/// Mirrors `pyhf.simplemodels.uncorrelated_background()`.
#[pyfunction]
fn simplemodel_uncorrelated(
    signal: Vec<f64>,
    bkg: Vec<f64>,
    bkg_uncertainty: Vec<f64>,
) -> PyResult<String> {
    let ws =
        ns_translate::pyhf::simplemodels::uncorrelated_background(&signal, &bkg, &bkg_uncertainty);
    serde_json::to_string_pretty(&ws).map_err(|e| PyValueError::new_err(e.to_string()))
}

/// Build a workspace with correlated background uncertainties (histosys).
///
/// Mirrors `pyhf.simplemodels.correlated_background()`.
#[pyfunction]
fn simplemodel_correlated(
    signal: Vec<f64>,
    bkg: Vec<f64>,
    bkg_up: Vec<f64>,
    bkg_down: Vec<f64>,
) -> PyResult<String> {
    let ws =
        ns_translate::pyhf::simplemodels::correlated_background(&signal, &bkg, &bkg_up, &bkg_down);
    serde_json::to_string_pretty(&ws).map_err(|e| PyValueError::new_err(e.to_string()))
}

/// Convenience wrapper: create model from HistFactory XML (combination.xml + ROOT files).
#[pyfunction]
fn from_histfactory(xml_path: &str) -> PyResult<PyHistFactoryModel> {
    PyHistFactoryModel::from_xml(xml_path)
}

/// Extract per-channel bin edges from a HistFactory export (`combination.xml` + ROOT files).
///
/// Uses each channel's `data` histogram as the canonical binning source.
#[pyfunction]
fn histfactory_bin_edges_by_channel<'py>(py: Python<'py>, xml_path: &str) -> PyResult<Py<PyAny>> {
    let path = std::path::Path::new(xml_path);
    let map = ns_translate::histfactory::bin_edges_by_channel_from_xml(path)
        .map_err(|e| PyValueError::new_err(format!("Failed to extract bin edges: {}", e)))?;

    let d = PyDict::new(py);
    for (k, v) in map {
        d.set_item(k, v)?;
    }
    Ok(d.into_any().unbind())
}

/// Read a TH1 histogram from a ROOT file, including sumw2 and under/overflow bins.
///
/// Returns a dict with keys:
/// - name, title
/// - bin_edges, bin_content, sumw2
/// - underflow, overflow, underflow_sumw2, overflow_sumw2
#[pyfunction]
fn read_root_histogram<'py>(
    py: Python<'py>,
    root_path: &str,
    hist_path: &str,
) -> PyResult<Py<PyAny>> {
    let root_path = root_path.to_string();
    let hist_path = hist_path.to_string();

    let wf = py
        .detach(move || {
            let f = RootFile::open(&root_path)?;
            f.get_histogram_with_flows(&hist_path)
        })
        .map_err(|e| PyValueError::new_err(format!("ROOT histogram read failed: {}", e)))?;

    let d = PyDict::new(py);
    d.set_item("name", wf.histogram.name)?;
    d.set_item("title", wf.histogram.title)?;
    d.set_item("bin_edges", wf.histogram.bin_edges)?;
    d.set_item("bin_content", wf.histogram.bin_content)?;
    d.set_item("sumw2", wf.histogram.sumw2)?;
    d.set_item("underflow", wf.underflow)?;
    d.set_item("overflow", wf.overflow)?;
    d.set_item("underflow_sumw2", wf.underflow_sumw2)?;
    d.set_item("overflow_sumw2", wf.overflow_sumw2)?;
    Ok(d.into_any().unbind())
}

/// Convenience wrapper: fit model with optional overridden observations.
///
/// Pass `device="cuda"` to use GPU-accelerated NLL+gradient (requires CUDA build).
#[pyfunction]
#[pyo3(signature = (model, *, data=None, init_pars=None, device="cpu"))]
fn fit<'py>(
    py: Python<'py>,
    model: &Bound<'py, PyAny>,
    data: Option<Vec<f64>>,
    init_pars: Option<Vec<f64>>,
    device: &str,
) -> PyResult<PyFitResult> {
    if device == "cuda" {
        // GPU path: requires HistFactoryModel
        let hf = model
            .extract::<PyRef<'_, PyHistFactoryModel>>()
            .map_err(|_| PyValueError::new_err("device='cuda' requires a HistFactoryModel"))?;
        let mut m = hf.inner.clone();
        if let Some(ref obs) = data {
            m = m
                .with_observed_main(obs)
                .map_err(|e| PyValueError::new_err(format!("Failed to set data: {}", e)))?;
        }
        let ip = init_pars.clone();
        let result = py
            .detach(move || -> ns_core::Result<ns_core::FitResult> {
                let mle = RustMLE::new();
                #[cfg(feature = "cuda")]
                {
                    if let Some(ip) = ip { mle.fit_gpu_from(&m, &ip) } else { mle.fit_gpu(&m) }
                }
                #[cfg(not(feature = "cuda"))]
                {
                    let _ = (mle, m, ip);
                    Err(ns_core::Error::Computation(
                        "CUDA support not compiled in. Build with --features cuda".to_string(),
                    ))
                }
            })
            .map_err(|e| PyValueError::new_err(format!("GPU fit failed: {}", e)))?;

        return Ok(PyFitResult::from(result));
    }

    let mle = PyMaximumLikelihoodEstimator { inner: RustMLE::new() };
    mle.fit(py, model, data, init_pars)
}

/// Convenience wrapper: fit a Posterior (MAP) by minimizing negative log-posterior.
#[pyfunction]
fn map_fit<'py>(py: Python<'py>, posterior: &Bound<'py, PyAny>) -> PyResult<PyFitResult> {
    let post = posterior
        .extract::<PyRef<'_, PyPosterior>>()
        .map_err(|_| PyValueError::new_err("map_fit expects a Posterior"))?;

    let mle = RustMLE::new();
    let model = post.model.clone();
    let priors = post.priors.clone();

    let result = py
        .detach(move || model.fit_map(&mle, priors))
        .map_err(|e| PyValueError::new_err(format!("MAP fit failed: {}", e)))?;

    Ok(PyFitResult::from(result))
}

/// Convenience wrapper: fit multiple models in parallel (Rayon).
///
/// Two call forms:
/// - `fit_batch(models)` — list of models, each with its own observations
/// - `fit_batch(model, datasets)` — HistFactoryModel + list of observation vectors
#[pyfunction]
#[pyo3(signature = (models_or_model, datasets=None))]
fn fit_batch<'py>(
    py: Python<'py>,
    models_or_model: &Bound<'py, PyAny>,
    datasets: Option<Vec<Vec<f64>>>,
) -> PyResult<Vec<PyFitResult>> {
    let mle = PyMaximumLikelihoodEstimator { inner: RustMLE::new() };
    mle.fit_batch(py, models_or_model, datasets)
}

/// Unified toy fitting: generate Poisson toys and fit each.
///
/// Dispatches on model type: HistFactoryModel (CPU/CUDA/Metal), UnbinnedModel (CPU only).
/// - `batch=True` (default): fast batch mode, skips Hessian/covariance.
/// - `batch=False`: full mode with Hessian (HistFactory only, CPU only).
/// - `device="cuda"|"metal"`: GPU-accelerated batch (HistFactory only).
#[pyfunction]
#[pyo3(signature = (model, params, *, n_toys=1000, seed=42, device="cpu", batch=true, compute_hessian=false, max_retries=3, max_iter=5000, init_params=None))]
fn fit_toys(
    py: Python<'_>,
    model: &Bound<'_, PyAny>,
    params: Vec<f64>,
    n_toys: usize,
    seed: u64,
    device: &str,
    batch: bool,
    compute_hessian: bool,
    max_retries: usize,
    max_iter: u64,
    init_params: Option<Vec<f64>>,
) -> PyResult<Vec<PyFitResult>> {
    if let Ok(hf) = model.extract::<PyRef<PyHistFactoryModel>>() {
        match device {
            "cuda" | "metal" => fit_toys_batch_gpu_impl(py, &hf, params, n_toys, seed, device),
            "cpu" => {
                if batch {
                    fit_toys_batch_impl(py, &hf, params, n_toys, seed)
                } else {
                    let mle = PyMaximumLikelihoodEstimator { inner: RustMLE::new() };
                    mle.fit_toys(py, &hf, params, n_toys, seed)
                }
            }
            _ => Err(PyValueError::new_err(format!(
                "Device '{}' not supported for fit_toys. Use 'cpu', 'cuda', or 'metal'.",
                device
            ))),
        }
    } else if let Ok(ub) = model.extract::<PyRef<PyUnbinnedModel>>() {
        if device != "cpu" {
            return Err(PyValueError::new_err(
                "UnbinnedModel fit_toys only supports device='cpu'.",
            ));
        }
        unbinned_fit_toys_impl(
            py,
            &ub,
            params,
            n_toys,
            seed,
            init_params,
            max_retries,
            max_iter,
            compute_hessian,
        )
    } else {
        Err(pyo3::exceptions::PyTypeError::new_err("Expected HistFactoryModel or UnbinnedModel"))
    }
}

/// Internal: unbinned toy fitting — called by unified `fit_toys()`.
fn unbinned_fit_toys_impl(
    py: Python<'_>,
    model: &PyUnbinnedModel,
    params: Vec<f64>,
    n_toys: usize,
    seed: u64,
    init_params: Option<Vec<f64>>,
    max_retries: usize,
    max_iter: u64,
    compute_hessian: bool,
) -> PyResult<Vec<PyFitResult>> {
    let m = model.inner.clone();

    let results = py.detach(move || {
        let toy_config = ns_inference::ToyFitConfig {
            optimizer: OptimizerConfig { max_iter, ..OptimizerConfig::default() },
            max_retries,
            compute_hessian,
            ..ns_inference::ToyFitConfig::default()
        };

        let batch = ns_inference::fit_unbinned_toys_batch_cpu(
            &m,
            &params,
            n_toys,
            seed,
            init_params.as_deref(),
            toy_config,
            |m, p, s| m.sample_poisson_toy(p, s),
        );
        batch.fits
    });

    results
        .into_iter()
        .map(|r| {
            let r =
                r.map_err(|e| PyValueError::new_err(format!("Unbinned toy fit failed: {}", e)))?;
            Ok(PyFitResult::from(r))
        })
        .collect()
}

/// Internal: batch toy fitting for HistFactory — called by unified `fit_toys()`.
fn fit_toys_batch_impl(
    py: Python<'_>,
    model: &PyHistFactoryModel,
    params: Vec<f64>,
    n_toys: usize,
    seed: u64,
) -> PyResult<Vec<PyFitResult>> {
    let m = model.inner.clone();

    let results =
        py.detach(move || ns_inference::batch::fit_toys_batch(&m, &params, n_toys, seed, None));

    results
        .into_iter()
        .map(|r| {
            let r = r.map_err(|e| PyValueError::new_err(format!("Batch toy fit failed: {}", e)))?;
            Ok(PyFitResult::from(r))
        })
        .collect()
}

/// Set the process-wide evaluation mode.
///
/// - `"fast"` (default): maximum speed, naive summation, multi-threaded.
/// - `"parity"`: Kahan summation, Accelerate disabled, single-thread recommended.
///   Used for deterministic pyhf parity validation.
#[pyfunction]
fn set_eval_mode(mode: &str) -> PyResult<()> {
    let m = match mode {
        "fast" => ns_compute::EvalMode::Fast,
        "parity" => ns_compute::EvalMode::Parity,
        _ => {
            return Err(pyo3::exceptions::PyValueError::new_err(format!(
                "Unknown eval mode '{}'. Use 'fast' or 'parity'.",
                mode
            )));
        }
    };
    ns_compute::set_eval_mode(m);
    Ok(())
}

/// Best-effort: configure the global Rayon thread pool.
///
/// Returns `True` if the requested configuration was applied, `False` if Rayon
/// was already initialized (or threads==0, meaning "do not force").
///
/// Notes:
/// - Rayon global thread pool can only be configured once per process.
/// - This is primarily intended for deterministic / parity-mode automation.
#[pyfunction]
fn set_threads(threads: usize) -> PyResult<bool> {
    if threads == 0 {
        return Ok(false);
    }
    let r = rayon::ThreadPoolBuilder::new().num_threads(threads).build_global();
    Ok(r.is_ok())
}

/// Get the current evaluation mode ("fast" or "parity").
#[pyfunction]
fn get_eval_mode() -> &'static str {
    match ns_compute::eval_mode() {
        ns_compute::EvalMode::Fast => "fast",
        ns_compute::EvalMode::Parity => "parity",
    }
}

/// Check if Accelerate backend is available.
#[pyfunction]
fn has_accelerate() -> bool {
    ns_inference::batch::is_accelerate_available()
}

/// Check if CUDA GPU batch backend is available.
///
/// Returns True if:
/// - the `cuda` feature was enabled at compile time, AND
/// - a CUDA-capable GPU is present at runtime.
#[pyfunction]
fn has_cuda() -> bool {
    ns_inference::batch::is_cuda_batch_available()
}

/// Check if Metal GPU batch backend is available.
///
/// Returns True if:
/// - the `metal` feature was enabled at compile time, AND
/// - a Metal-capable GPU is present at runtime (Apple Silicon).
#[pyfunction]
fn has_metal() -> bool {
    ns_inference::batch::is_metal_batch_available()
}

/// Internal: GPU batch toy fitting for HistFactory — called by unified `fit_toys()`.
fn fit_toys_batch_gpu_impl(
    py: Python<'_>,
    model: &PyHistFactoryModel,
    params: Vec<f64>,
    n_toys: usize,
    seed: u64,
    device: &str,
) -> PyResult<Vec<PyFitResult>> {
    let m = model.inner.clone();

    let device_str = device.to_string();

    let results = py.detach(move || match device_str.as_str() {
        "cuda" => {
            #[cfg(feature = "cuda")]
            {
                match ns_inference::gpu_batch::fit_toys_batch_gpu(&m, &params, n_toys, seed, None) {
                    Ok(r) => r,
                    Err(e) => vec![Err(e)],
                }
            }
            #[cfg(not(feature = "cuda"))]
            {
                vec![Err(ns_core::Error::Computation(
                    "CUDA support not compiled in. Build with --features cuda".to_string(),
                ))]
            }
        }
        "metal" => {
            #[cfg(feature = "metal")]
            {
                match ns_inference::metal_batch::fit_toys_batch_metal(
                    &m, &params, n_toys, seed, None,
                ) {
                    Ok(r) => r,
                    Err(e) => vec![Err(e)],
                }
            }
            #[cfg(not(feature = "metal"))]
            {
                vec![Err(ns_core::Error::Computation(
                    "Metal support not compiled in. Build with --features metal".to_string(),
                ))]
            }
        }
        _ => ns_inference::batch::fit_toys_batch(&m, &params, n_toys, seed, None),
    });

    results
        .into_iter()
        .map(|r| {
            let r =
                r.map_err(|e| PyValueError::new_err(format!("GPU batch toy fit failed: {}", e)))?;
            Ok(PyFitResult::from(r))
        })
        .collect()
}

/// Generate an Asimov (deterministic expected) **main** dataset for a HistFactory model.
///
/// Returns a flat vector of main-bin expectations (no auxdata), suitable for passing to
/// `nextstat.fit(model, data=...)` or `model.with_observed_main(...)`.
#[pyfunction]
fn asimov_data(model: &PyHistFactoryModel, params: Vec<f64>) -> PyResult<Vec<f64>> {
    ns_inference::toys::asimov_main(&model.inner, &params)
        .map_err(|e| PyValueError::new_err(format!("asimov_data failed: {}", e)))
}

/// Generate Poisson-fluctuated **main** toy datasets for a HistFactory model.
///
/// Returns `n_toys` flat vectors of main-bin observations (no auxdata).
#[pyfunction]
#[pyo3(signature = (model, params, *, n_toys=1000, seed=42))]
fn poisson_toys(
    model: &PyHistFactoryModel,
    params: Vec<f64>,
    n_toys: usize,
    seed: u64,
) -> PyResult<Vec<Vec<f64>>> {
    ns_inference::toys::poisson_main_toys(&model.inner, &params, n_toys, seed)
        .map_err(|e| PyValueError::new_err(format!("poisson_toys failed: {}", e)))
}

/// Unified nuisance-parameter ranking (impact on POI).
///
/// Dispatches on model type: HistFactoryModel (CPU/CUDA), UnbinnedModel (CPU only).
#[pyfunction]
#[pyo3(signature = (model, *, device="cpu"))]
fn ranking<'py>(
    py: Python<'py>,
    model: &Bound<'py, PyAny>,
    device: &str,
) -> PyResult<Vec<Py<PyAny>>> {
    if let Ok(hf) = model.extract::<PyRef<PyHistFactoryModel>>() {
        match device {
            "cpu" => {
                let mle = PyMaximumLikelihoodEstimator { inner: RustMLE::new() };
                mle.ranking(py, &hf)
            }
            "cuda" => {
                #[cfg(feature = "cuda")]
                {
                    ranking_gpu_impl(py, &hf)
                }
                #[cfg(not(feature = "cuda"))]
                {
                    Err(PyValueError::new_err(
                        "Device 'cuda' not available. Build with --features cuda.",
                    ))
                }
            }
            _ => Err(PyValueError::new_err(format!(
                "Device '{}' not supported for ranking. Use 'cpu' or 'cuda'.",
                device
            ))),
        }
    } else if let Ok(ub) = model.extract::<PyRef<PyUnbinnedModel>>() {
        if device != "cpu" {
            return Err(PyValueError::new_err("UnbinnedModel ranking only supports device='cpu'."));
        }
        unbinned_ranking_impl(py, &ub)
    } else {
        Err(pyo3::exceptions::PyTypeError::new_err("Expected HistFactoryModel or UnbinnedModel"))
    }
}

/// Internal: unbinned ranking logic (called by unified `ranking()`).
fn unbinned_ranking_impl<'py>(
    py: Python<'py>,
    model: &PyUnbinnedModel,
) -> PyResult<Vec<Py<PyAny>>> {
    let poi_idx = model.inner.poi_index().ok_or_else(|| {
        PyValueError::new_err("UnbinnedModel has no POI (spec.model.poi is required for ranking)")
    })?;

    let mle = RustMLE::new();
    let m = model.inner.clone();

    let entries: Vec<RankingEntry> = py
        .detach(move || -> NsResult<Vec<RankingEntry>> {
            // Nominal fit (WITH Hessian) to get pull/constraint.
            let nominal = mle.fit(&m)?;
            let mu_hat = nominal.parameters.get(poi_idx).copied().unwrap_or(f64::NAN);

            let base_bounds: Vec<(f64, f64)> = m.parameters().iter().map(|p| p.bounds).collect();

            let mut entries = Vec::<RankingEntry>::new();
            for (np_idx, p) in m.parameters().iter().enumerate() {
                if np_idx == poi_idx {
                    continue;
                }
                let Some(constraint) = p.constraint.clone() else { continue };
                if (p.bounds.0 - p.bounds.1).abs() < 1e-12 {
                    continue;
                }

                let (center, sigma) = match constraint {
                    ns_unbinned::Constraint::Gaussian { mean, sigma } => (mean, sigma),
                };
                if !sigma.is_finite() || sigma <= 0.0 {
                    continue;
                }

                let (b_lo, b_hi) = base_bounds[np_idx];
                let val_up = (center + sigma).min(b_hi);
                let val_down = (center - sigma).max(b_lo);

                let theta_hat = nominal.parameters[np_idx];
                let pull = (theta_hat - center) / sigma;
                let constraint = nominal.uncertainties[np_idx] / sigma;

                // --- +1σ refit ---
                let m_up = m.with_fixed_param(np_idx, val_up);
                let mut warm_up = nominal.parameters.clone();
                warm_up[np_idx] = val_up;
                let r_up = mle.fit_minimum_from(&m_up, &warm_up);
                let mu_up = r_up
                    .ok()
                    .filter(|r| r.converged)
                    .and_then(|r| r.parameters.get(poi_idx).copied());

                // --- -1σ refit ---
                let m_down = m.with_fixed_param(np_idx, val_down);
                let mut warm_down = nominal.parameters.clone();
                warm_down[np_idx] = val_down;
                let r_down = mle.fit_minimum_from(&m_down, &warm_down);
                let mu_down = r_down
                    .ok()
                    .filter(|r| r.converged)
                    .and_then(|r| r.parameters.get(poi_idx).copied());

                let (Some(mu_up), Some(mu_down)) = (mu_up, mu_down) else { continue };
                entries.push(RankingEntry {
                    name: p.name.clone(),
                    delta_mu_up: mu_up - mu_hat,
                    delta_mu_down: mu_down - mu_hat,
                    pull,
                    constraint,
                });
            }

            // Sort by |impact|
            entries.sort_by(|a, b| {
                let impact_a = a.delta_mu_up.abs().max(a.delta_mu_down.abs());
                let impact_b = b.delta_mu_up.abs().max(b.delta_mu_down.abs());
                impact_b
                    .partial_cmp(&impact_a)
                    .unwrap_or(std::cmp::Ordering::Equal)
                    .then_with(|| a.name.cmp(&b.name))
            });

            Ok(entries)
        })
        .map_err(|e| PyValueError::new_err(format!("Unbinned ranking failed: {}", e)))?;

    entries
        .into_iter()
        .map(|e| {
            let d = PyDict::new(py);
            d.set_item("name", e.name)?;
            d.set_item("delta_mu_up", e.delta_mu_up)?;
            d.set_item("delta_mu_down", e.delta_mu_down)?;
            d.set_item("pull", e.pull)?;
            d.set_item("constraint", e.constraint)?;
            Ok(d.into_any().unbind())
        })
        .collect()
}

/// Internal: GPU-accelerated ranking (called by unified `ranking()`).
#[cfg(feature = "cuda")]
fn ranking_gpu_impl<'py>(py: Python<'py>, model: &PyHistFactoryModel) -> PyResult<Vec<Py<PyAny>>> {
    let mle = RustMLE::new();
    let m = model.inner.clone();

    let entries = py
        .detach(move || ns_inference::ranking_gpu(&mle, &m))
        .map_err(|e| PyValueError::new_err(format!("GPU ranking failed: {}", e)))?;

    entries
        .into_iter()
        .map(|e| {
            let d = PyDict::new(py);
            d.set_item("name", e.name)?;
            d.set_item("delta_mu_up", e.delta_mu_up)?;
            d.set_item("delta_mu_down", e.delta_mu_down)?;
            d.set_item("pull", e.pull)?;
            d.set_item("constraint", e.constraint)?;
            Ok(d.into_any().unbind())
        })
        .collect()
}

fn build_ode_options(
    rtol: f64,
    atol: f64,
    h0: f64,
    h_min: f64,
    h_max: f64,
    max_steps: usize,
    dense_output: bool,
) -> ns_inference::ode_adaptive::OdeOptions {
    ns_inference::ode_adaptive::OdeOptions { rtol, atol, h0, h_min, h_max, max_steps, dense_output }
}

struct LinearOdeSystem {
    a: DMatrix<f64>,
}

impl ns_inference::ode_adaptive::OdeSystem for LinearOdeSystem {
    fn ndim(&self) -> usize {
        self.a.nrows()
    }

    fn rhs(&self, _t: f64, y: &[f64], dydt: &mut [f64]) {
        let n = self.a.nrows();
        for i in 0..n {
            let mut s = 0.0;
            for j in 0..n {
                s += self.a[(i, j)] * y[j];
            }
            dydt[i] = s;
        }
    }
}

struct LinearParamOdeSystem {
    mats: Vec<DMatrix<f64>>,
    n: usize,
}

impl ns_inference::ode_adaptive::ParamOdeSystem for LinearParamOdeSystem {
    fn ndim(&self) -> usize {
        self.n
    }

    fn nparams(&self) -> usize {
        self.mats.len()
    }

    fn rhs_param(&self, _t: f64, y: &[f64], params: &[f64], dydt: &mut [f64]) {
        let n = self.n;
        for i in 0..n {
            let mut s = 0.0;
            for p in 0..self.mats.len() {
                let coef = params[p];
                let a = &self.mats[p];
                for j in 0..n {
                    s += coef * a[(i, j)] * y[j];
                }
            }
            dydt[i] = s;
        }
    }

    fn jacobian_y(&self, _t: f64, _y: &[f64], params: &[f64], jac: &mut Vec<Vec<f64>>) {
        let n = self.n;
        jac.resize(n, vec![0.0; n]);
        for row in jac.iter_mut() {
            row.resize(n, 0.0);
            for v in row.iter_mut() {
                *v = 0.0;
            }
        }
        for p in 0..self.mats.len() {
            let coef = params[p];
            let a = &self.mats[p];
            for i in 0..n {
                for j in 0..n {
                    jac[i][j] += coef * a[(i, j)];
                }
            }
        }
    }

    fn jacobian_params(&self, _t: f64, y: &[f64], _params: &[f64], jac: &mut Vec<Vec<f64>>) {
        let n = self.n;
        let np = self.mats.len();
        jac.resize(n, vec![0.0; np]);
        for row in jac.iter_mut() {
            row.resize(np, 0.0);
        }
        for p in 0..np {
            let a = &self.mats[p];
            for i in 0..n {
                let mut s = 0.0;
                for j in 0..n {
                    s += a[(i, j)] * y[j];
                }
                jac[i][p] = s;
            }
        }
    }
}

fn set_callback_error(slot: &Arc<Mutex<Option<String>>>, msg: String) {
    if let Ok(mut guard) = slot.lock()
        && guard.is_none()
    {
        *guard = Some(msg);
    }
}

fn take_callback_error(slot: &Arc<Mutex<Option<String>>>) -> Option<String> {
    match slot.lock() {
        Ok(mut guard) => guard.take(),
        Err(_) => Some("callback adapter internal error: mutex poisoned".to_string()),
    }
}

fn validate_vec_finite(name: &str, values: &[f64], expected_len: usize) -> Result<(), String> {
    if values.len() != expected_len {
        return Err(format!(
            "{} returned length {}, expected {}",
            name,
            values.len(),
            expected_len
        ));
    }
    if values.iter().any(|v| !v.is_finite()) {
        return Err(format!("{} returned non-finite values", name));
    }
    Ok(())
}

fn validate_mat_finite(
    name: &str,
    mat: &[Vec<f64>],
    expected_rows: usize,
    expected_cols: usize,
) -> Result<(), String> {
    if mat.len() != expected_rows {
        return Err(format!("{} returned {} rows, expected {}", name, mat.len(), expected_rows));
    }
    for (i, row) in mat.iter().enumerate() {
        if row.len() != expected_cols {
            return Err(format!(
                "{} row {} has length {}, expected {}",
                name,
                i,
                row.len(),
                expected_cols
            ));
        }
        if row.iter().any(|v| !v.is_finite()) {
            return Err(format!("{} row {} contains non-finite values", name, i));
        }
    }
    Ok(())
}

struct PythonOdeCallbackSystem {
    n: usize,
    rhs: Py<PyAny>,
    jac: Option<Py<PyAny>>,
    error: Arc<Mutex<Option<String>>>,
}

impl ns_inference::ode_adaptive::OdeSystem for PythonOdeCallbackSystem {
    fn ndim(&self) -> usize {
        self.n
    }

    fn rhs(&self, t: f64, y: &[f64], dydt: &mut [f64]) {
        Python::attach(|py| {
            let call_res: PyResult<Vec<f64>> = (|| {
                let out = self.rhs.bind(py).call1((t, y.to_vec()))?;
                out.extract::<Vec<f64>>()
            })();
            match call_res {
                Ok(vec_out) => {
                    if let Err(msg) = validate_vec_finite("rhs", &vec_out, self.n) {
                        set_callback_error(&self.error, msg);
                        dydt.fill(0.0);
                        return;
                    }
                    dydt.copy_from_slice(&vec_out);
                }
                Err(e) => {
                    set_callback_error(&self.error, format!("rhs callback failed: {}", e));
                    dydt.fill(0.0);
                }
            }
        });
    }

    fn jacobian(&self, t: f64, y: &[f64], jac: &mut Vec<Vec<f64>>) {
        if let Some(jac_cb) = &self.jac {
            Python::attach(|py| {
                let call_res: PyResult<Vec<Vec<f64>>> = (|| {
                    let out = jac_cb.bind(py).call1((t, y.to_vec()))?;
                    out.extract::<Vec<Vec<f64>>>()
                })();
                match call_res {
                    Ok(mat) => {
                        if let Err(msg) = validate_mat_finite("jac", &mat, self.n, self.n) {
                            set_callback_error(&self.error, msg);
                            jac.resize(self.n, vec![0.0; self.n]);
                            return;
                        }
                        *jac = mat;
                    }
                    Err(e) => {
                        set_callback_error(&self.error, format!("jac callback failed: {}", e));
                        jac.resize(self.n, vec![0.0; self.n]);
                    }
                }
            });
            return;
        }

        let n = self.n;
        let eps = 1e-8;
        let mut yp = y.to_vec();
        let mut fp = vec![0.0; n];
        let mut fm = vec![0.0; n];
        jac.resize(n, vec![0.0; n]);
        for row in jac.iter_mut() {
            row.resize(n, 0.0);
        }
        for j in 0..n {
            let orig = yp[j];
            let h = eps * (1.0 + orig.abs());
            yp[j] = orig + h;
            self.rhs(t, &yp, &mut fp);
            yp[j] = orig - h;
            self.rhs(t, &yp, &mut fm);
            yp[j] = orig;
            for i in 0..n {
                jac[i][j] = (fp[i] - fm[i]) / (2.0 * h);
            }
        }
    }
}

struct PythonParamOdeCallbackSystem {
    n: usize,
    np: usize,
    rhs: Py<PyAny>,
    jac_y: Option<Py<PyAny>>,
    jac_params: Option<Py<PyAny>>,
    error: Arc<Mutex<Option<String>>>,
}

impl ns_inference::ode_adaptive::ParamOdeSystem for PythonParamOdeCallbackSystem {
    fn ndim(&self) -> usize {
        self.n
    }

    fn nparams(&self) -> usize {
        self.np
    }

    fn rhs_param(&self, t: f64, y: &[f64], params: &[f64], dydt: &mut [f64]) {
        Python::attach(|py| {
            let call_res: PyResult<Vec<f64>> = (|| {
                let out = self.rhs.bind(py).call1((t, y.to_vec(), params.to_vec()))?;
                out.extract::<Vec<f64>>()
            })();
            match call_res {
                Ok(vec_out) => {
                    if let Err(msg) = validate_vec_finite("rhs", &vec_out, self.n) {
                        set_callback_error(&self.error, msg);
                        dydt.fill(0.0);
                        return;
                    }
                    dydt.copy_from_slice(&vec_out);
                }
                Err(e) => {
                    set_callback_error(&self.error, format!("rhs callback failed: {}", e));
                    dydt.fill(0.0);
                }
            }
        });
    }

    fn jacobian_y(&self, t: f64, y: &[f64], params: &[f64], jac: &mut Vec<Vec<f64>>) {
        if let Some(jac_cb) = &self.jac_y {
            Python::attach(|py| {
                let call_res: PyResult<Vec<Vec<f64>>> = (|| {
                    let out = jac_cb.bind(py).call1((t, y.to_vec(), params.to_vec()))?;
                    out.extract::<Vec<Vec<f64>>>()
                })();
                match call_res {
                    Ok(mat) => {
                        if let Err(msg) = validate_mat_finite("jac_y", &mat, self.n, self.n) {
                            set_callback_error(&self.error, msg);
                            jac.resize(self.n, vec![0.0; self.n]);
                            return;
                        }
                        *jac = mat;
                    }
                    Err(e) => {
                        set_callback_error(&self.error, format!("jac_y callback failed: {}", e));
                        jac.resize(self.n, vec![0.0; self.n]);
                    }
                }
            });
            return;
        }

        let n = self.n;
        let eps = 1e-8;
        let mut yp = y.to_vec();
        let mut fp = vec![0.0; n];
        let mut fm = vec![0.0; n];
        jac.resize(n, vec![0.0; n]);
        for row in jac.iter_mut() {
            row.resize(n, 0.0);
        }
        for j in 0..n {
            let orig = yp[j];
            let h = eps * (1.0 + orig.abs());
            yp[j] = orig + h;
            self.rhs_param(t, &yp, params, &mut fp);
            yp[j] = orig - h;
            self.rhs_param(t, &yp, params, &mut fm);
            yp[j] = orig;
            for i in 0..n {
                jac[i][j] = (fp[i] - fm[i]) / (2.0 * h);
            }
        }
    }

    fn jacobian_params(&self, t: f64, y: &[f64], params: &[f64], jac: &mut Vec<Vec<f64>>) {
        if let Some(jac_cb) = &self.jac_params {
            Python::attach(|py| {
                let call_res: PyResult<Vec<Vec<f64>>> = (|| {
                    let out = jac_cb.bind(py).call1((t, y.to_vec(), params.to_vec()))?;
                    out.extract::<Vec<Vec<f64>>>()
                })();
                match call_res {
                    Ok(mat) => {
                        if let Err(msg) = validate_mat_finite("jac_params", &mat, self.n, self.np) {
                            set_callback_error(&self.error, msg);
                            jac.resize(self.n, vec![0.0; self.np]);
                            return;
                        }
                        *jac = mat;
                    }
                    Err(e) => {
                        set_callback_error(
                            &self.error,
                            format!("jac_params callback failed: {}", e),
                        );
                        jac.resize(self.n, vec![0.0; self.np]);
                    }
                }
            });
            return;
        }

        let n = self.n;
        let np = self.np;
        let eps = 1e-8;
        let mut pp = params.to_vec();
        let mut fp = vec![0.0; n];
        let mut fm = vec![0.0; n];
        jac.resize(n, vec![0.0; np]);
        for row in jac.iter_mut() {
            row.resize(np, 0.0);
        }
        for j in 0..np {
            let orig = pp[j];
            let h = eps * (1.0 + orig.abs());
            pp[j] = orig + h;
            self.rhs_param(t, y, &pp, &mut fp);
            pp[j] = orig - h;
            self.rhs_param(t, y, &pp, &mut fm);
            pp[j] = orig;
            for i in 0..n {
                jac[i][j] = (fp[i] - fm[i]) / (2.0 * h);
            }
        }
    }
}

/// LSODA-style adaptive integration for linear systems `dy/dt = A y`.
#[pyfunction]
#[pyo3(signature = (a, y0, t0, t1, *, rtol=1e-6, atol=1e-9, h0=0.0, h_min=1e-14, h_max=f64::INFINITY, max_steps=100000, dense_output=true))]
fn lsoda(
    py: Python<'_>,
    a: Vec<Vec<f64>>,
    y0: Vec<f64>,
    t0: f64,
    t1: f64,
    rtol: f64,
    atol: f64,
    h0: f64,
    h_min: f64,
    h_max: f64,
    max_steps: usize,
    dense_output: bool,
) -> PyResult<Py<PyAny>> {
    let a = dmatrix_from_nested("A", a)?;
    if a.nrows() != a.ncols() {
        return Err(PyValueError::new_err("A must be square"));
    }
    if y0.len() != a.nrows() {
        return Err(PyValueError::new_err(format!(
            "y0 length ({}) must match system dimension ({})",
            y0.len(),
            a.nrows()
        )));
    }
    let sys = LinearOdeSystem { a };
    let opts = build_ode_options(rtol, atol, h0, h_min, h_max, max_steps, dense_output);
    let sol = ns_inference::ode_adaptive::lsoda(&sys, &y0, t0, t1, &opts)
        .map_err(|e| PyValueError::new_err(format!("lsoda failed: {}", e)))?;
    let out = PyDict::new(py);
    out.set_item("t", sol.t)?;
    out.set_item("y", sol.y)?;
    Ok(out.into_any().unbind())
}

/// Forward sensitivity solve for linear parametric systems:
/// `dy/dt = (sum_p params[p] * A_p) y`.
#[pyfunction]
#[pyo3(signature = (a_params, params, y0, t0, t1, *, solver="lsoda", rtol=1e-6, atol=1e-9, h0=0.0, h_min=1e-14, h_max=f64::INFINITY, max_steps=100000, dense_output=true))]
fn forward_sensitivity_solve(
    py: Python<'_>,
    a_params: Vec<Vec<Vec<f64>>>,
    params: Vec<f64>,
    y0: Vec<f64>,
    t0: f64,
    t1: f64,
    solver: &str,
    rtol: f64,
    atol: f64,
    h0: f64,
    h_min: f64,
    h_max: f64,
    max_steps: usize,
    dense_output: bool,
) -> PyResult<Py<PyAny>> {
    if a_params.is_empty() {
        return Err(PyValueError::new_err("a_params must not be empty"));
    }
    let np = a_params.len();
    if params.len() != np {
        return Err(PyValueError::new_err(format!(
            "params length ({}) must equal number of A_p matrices ({np})",
            params.len()
        )));
    }
    let mats: Vec<DMatrix<f64>> = a_params
        .into_iter()
        .enumerate()
        .map(|(i, m)| dmatrix_from_nested(&format!("a_params[{i}]"), m))
        .collect::<PyResult<Vec<_>>>()?;
    let n = mats[0].nrows();
    if mats[0].ncols() != n {
        return Err(PyValueError::new_err("a_params[0] must be square"));
    }
    for (i, m) in mats.iter().enumerate() {
        if m.nrows() != n || m.ncols() != n {
            return Err(PyValueError::new_err(format!(
                "a_params[{i}] must be {}x{}, got {}x{}",
                n,
                n,
                m.nrows(),
                m.ncols()
            )));
        }
    }
    if y0.len() != n {
        return Err(PyValueError::new_err(format!(
            "y0 length ({}) must match state dimension ({n})",
            y0.len()
        )));
    }
    let sys = LinearParamOdeSystem { mats, n };
    let opts = build_ode_options(rtol, atol, h0, h_min, h_max, max_steps, dense_output);
    let solver_kind = match solver.to_ascii_lowercase().as_str() {
        "rk45" => ns_inference::ode_adaptive::SensitivitySolver::Rk45,
        "esdirk4" => ns_inference::ode_adaptive::SensitivitySolver::Esdirk4,
        "lsoda" => ns_inference::ode_adaptive::SensitivitySolver::Lsoda,
        other => {
            return Err(PyValueError::new_err(format!(
                "unknown solver '{}'; expected 'rk45', 'esdirk4', or 'lsoda'",
                other
            )));
        }
    };
    let sol = ns_inference::ode_adaptive::forward_sensitivity_solve(
        &sys,
        &params,
        &y0,
        t0,
        t1,
        &opts,
        solver_kind,
    )
    .map_err(|e| PyValueError::new_err(format!("forward_sensitivity_solve failed: {}", e)))?;
    let out = PyDict::new(py);
    out.set_item("t", sol.t)?;
    out.set_item("y", sol.y)?;
    out.set_item("sens", sol.sens)?;
    Ok(out.into_any().unbind())
}

/// LSODA-style adaptive integration using Python callbacks.
///
/// `rhs(t, y) -> list[float]` is required.
/// Optional `jac(t, y) -> list[list[float]]` supplies `∂f/∂y`.
#[pyfunction]
#[pyo3(signature = (rhs, y0, t0, t1, *, jac=None, rtol=1e-6, atol=1e-9, h0=0.0, h_min=1e-14, h_max=f64::INFINITY, max_steps=100000, dense_output=true))]
fn lsoda_callback(
    py: Python<'_>,
    rhs: Py<PyAny>,
    y0: Vec<f64>,
    t0: f64,
    t1: f64,
    jac: Option<Py<PyAny>>,
    rtol: f64,
    atol: f64,
    h0: f64,
    h_min: f64,
    h_max: f64,
    max_steps: usize,
    dense_output: bool,
) -> PyResult<Py<PyAny>> {
    if y0.is_empty() {
        return Err(PyValueError::new_err("y0 must not be empty"));
    }
    if !rhs.bind(py).is_callable() {
        return Err(PyValueError::new_err("rhs must be callable"));
    }
    if let Some(jac_cb) = jac.as_ref()
        && !jac_cb.bind(py).is_callable()
    {
        return Err(PyValueError::new_err("jac must be callable"));
    }
    let callback_error = Arc::new(Mutex::new(None::<String>));
    let sys = PythonOdeCallbackSystem { n: y0.len(), rhs, jac, error: callback_error.clone() };
    let opts = build_ode_options(rtol, atol, h0, h_min, h_max, max_steps, dense_output);
    let sol_res = ns_inference::ode_adaptive::lsoda(&sys, &y0, t0, t1, &opts);
    if let Some(msg) = take_callback_error(&callback_error) {
        return Err(PyValueError::new_err(format!("lsoda callback error: {}", msg)));
    }
    let sol = sol_res.map_err(|e| PyValueError::new_err(format!("lsoda failed: {}", e)))?;
    let out = PyDict::new(py);
    out.set_item("t", sol.t)?;
    out.set_item("y", sol.y)?;
    Ok(out.into_any().unbind())
}

/// Forward sensitivity solve using Python callbacks.
///
/// Required callback:
/// - `rhs(t, y, params) -> list[float]`
///
/// Optional Jacobian callbacks:
/// - `jac_y(t, y, params) -> list[list[float]]`
/// - `jac_params(t, y, params) -> list[list[float]]`
#[pyfunction]
#[pyo3(signature = (rhs, params, y0, t0, t1, *, jac_y=None, jac_params=None, solver="lsoda", rtol=1e-6, atol=1e-9, h0=0.0, h_min=1e-14, h_max=f64::INFINITY, max_steps=100000, dense_output=true))]
fn forward_sensitivity_solve_callback(
    py: Python<'_>,
    rhs: Py<PyAny>,
    params: Vec<f64>,
    y0: Vec<f64>,
    t0: f64,
    t1: f64,
    jac_y: Option<Py<PyAny>>,
    jac_params: Option<Py<PyAny>>,
    solver: &str,
    rtol: f64,
    atol: f64,
    h0: f64,
    h_min: f64,
    h_max: f64,
    max_steps: usize,
    dense_output: bool,
) -> PyResult<Py<PyAny>> {
    if y0.is_empty() {
        return Err(PyValueError::new_err("y0 must not be empty"));
    }
    if !rhs.bind(py).is_callable() {
        return Err(PyValueError::new_err("rhs must be callable"));
    }
    if let Some(cb) = jac_y.as_ref()
        && !cb.bind(py).is_callable()
    {
        return Err(PyValueError::new_err("jac_y must be callable"));
    }
    if let Some(cb) = jac_params.as_ref()
        && !cb.bind(py).is_callable()
    {
        return Err(PyValueError::new_err("jac_params must be callable"));
    }
    let solver_kind = match solver.to_ascii_lowercase().as_str() {
        "rk45" => ns_inference::ode_adaptive::SensitivitySolver::Rk45,
        "esdirk4" => ns_inference::ode_adaptive::SensitivitySolver::Esdirk4,
        "lsoda" => ns_inference::ode_adaptive::SensitivitySolver::Lsoda,
        other => {
            return Err(PyValueError::new_err(format!(
                "unknown solver '{}'; expected 'rk45', 'esdirk4', or 'lsoda'",
                other
            )));
        }
    };
    let callback_error = Arc::new(Mutex::new(None::<String>));
    let sys = PythonParamOdeCallbackSystem {
        n: y0.len(),
        np: params.len(),
        rhs,
        jac_y,
        jac_params,
        error: callback_error.clone(),
    };
    let opts = build_ode_options(rtol, atol, h0, h_min, h_max, max_steps, dense_output);
    let sol_res = ns_inference::ode_adaptive::forward_sensitivity_solve(
        &sys,
        &params,
        &y0,
        t0,
        t1,
        &opts,
        solver_kind,
    );
    if let Some(msg) = take_callback_error(&callback_error) {
        return Err(PyValueError::new_err(format!(
            "forward_sensitivity_solve callback error: {}",
            msg
        )));
    }
    let sol = sol_res
        .map_err(|e| PyValueError::new_err(format!("forward_sensitivity_solve failed: {}", e)))?;
    let out = PyDict::new(py);
    out.set_item("t", sol.t)?;
    out.set_item("y", sol.y)?;
    out.set_item("sens", sol.sens)?;
    Ok(out.into_any().unbind())
}

/// Fixed-step RK4 integration for a linear ODE system `dy/dt = A y`.
///
/// Returns a dict: {"t": [...], "y": [[...], ...]}.
#[pyfunction]
#[pyo3(signature = (a, y0, t0, t1, dt, *, max_steps=100000))]
fn rk4_linear(
    py: Python<'_>,
    a: Vec<Vec<f64>>,
    y0: Vec<f64>,
    t0: f64,
    t1: f64,
    dt: f64,
    max_steps: usize,
) -> PyResult<Py<PyAny>> {
    let a = dmatrix_from_nested("A", a)?;
    let sol = ns_inference::ode::rk4_linear(&a, &y0, t0, t1, dt, max_steps)
        .map_err(|e| PyValueError::new_err(format!("rk4_linear failed: {}", e)))?;

    let out = PyDict::new(py);
    out.set_item("t", sol.t)?;
    out.set_item("y", sol.y)?;
    Ok(out.into_any().unbind())
}

/// Fixed-step RK4 integration for a linear fixed-delay DDE system:
///
/// `dy/dt = A y(t) + B y(t - tau)`, with constant pre-history `y(t<=t0)=y_history`.
///
/// Returns a dict: {"t": [...], "y": [[...], ...]}.
#[pyfunction]
#[pyo3(signature = (a, b, y0, y_history, t0, t1, tau, dt, *, max_steps=100000))]
fn rk4_linear_dde(
    py: Python<'_>,
    a: Vec<Vec<f64>>,
    b: Vec<Vec<f64>>,
    y0: Vec<f64>,
    y_history: Vec<f64>,
    t0: f64,
    t1: f64,
    tau: f64,
    dt: f64,
    max_steps: usize,
) -> PyResult<Py<PyAny>> {
    let a = dmatrix_from_nested("A", a)?;
    let b = dmatrix_from_nested("B", b)?;
    let sol =
        ns_inference::ode_dde::rk4_linear_dde(&a, &b, &y0, &y_history, t0, t1, tau, dt, max_steps)
            .map_err(|e| PyValueError::new_err(format!("rk4_linear_dde failed: {}", e)))?;

    let out = PyDict::new(py);
    out.set_item("t", sol.t)?;
    out.set_item("y", sol.y)?;
    Ok(out.into_any().unbind())
}

/// Closed-form OLS fit for linear regression fixtures and baselines.
#[pyfunction]
#[pyo3(signature = (x, y, *, include_intercept=true))]
fn ols_fit(x: Vec<Vec<f64>>, y: Vec<f64>, include_intercept: bool) -> PyResult<Vec<f64>> {
    rust_ols_fit(x, y, include_intercept).map_err(|e| PyValueError::new_err(e.to_string()))
}

/// Frequentist hypotest (asymptotics, qtilde) returning CLs.
///
/// Dispatches on model type: HistFactoryModel or UnbinnedModel.
#[pyfunction]
#[pyo3(signature = (poi_test, model, *, data=None, return_tail_probs=false))]
fn hypotest(
    py: Python<'_>,
    poi_test: f64,
    model: &Bound<'_, PyAny>,
    data: Option<Vec<f64>>,
    return_tail_probs: bool,
) -> PyResult<Py<PyAny>> {
    if let Ok(hf) = model.extract::<PyRef<PyHistFactoryModel>>() {
        let mle = RustMLE::new();
        let fit_model = if let Some(obs_main) = data {
            hf.inner
                .with_observed_main(&obs_main)
                .map_err(|e| PyValueError::new_err(format!("Failed to set observed data: {}", e)))?
        } else {
            hf.inner.clone()
        };

        let ctx = RustCLsCtx::new(&mle, &fit_model).map_err(|e| {
            PyValueError::new_err(format!("Failed to build asymptotic context: {}", e))
        })?;
        let r = ctx
            .hypotest_qtilde(&mle, poi_test)
            .map_err(|e| PyValueError::new_err(format!("Hypotest failed: {}", e)))?;

        if return_tail_probs {
            (r.cls, vec![r.clsb, r.clb]).into_py_any(py)
        } else {
            r.cls.into_py_any(py)
        }
    } else if let Ok(ub) = model.extract::<PyRef<PyUnbinnedModel>>() {
        if data.is_some() {
            return Err(PyValueError::new_err(
                "data override is not supported for UnbinnedModel (data is in the model spec)",
            ));
        }
        unbinned_hypotest_impl(py, poi_test, &ub)
    } else {
        Err(pyo3::exceptions::PyTypeError::new_err("Expected HistFactoryModel or UnbinnedModel"))
    }
}

/// Frequentist hypotest (toy-based CLs, qtilde) returning CLs.
///
/// Dispatches on model type: HistFactoryModel or UnbinnedModel.
#[pyfunction]
#[pyo3(signature = (poi_test, model, *, n_toys=1000, seed=42, expected_set=false, data=None, return_tail_probs=false, return_meta=false))]
fn hypotest_toys(
    py: Python<'_>,
    poi_test: f64,
    model: &Bound<'_, PyAny>,
    n_toys: usize,
    seed: u64,
    expected_set: bool,
    data: Option<Vec<f64>>,
    return_tail_probs: bool,
    return_meta: bool,
) -> PyResult<Py<PyAny>> {
    if let Ok(hf) = model.extract::<PyRef<PyHistFactoryModel>>() {
        hypotest_toys_hf_impl(
            py,
            poi_test,
            &hf,
            n_toys,
            seed,
            expected_set,
            data,
            return_tail_probs,
            return_meta,
        )
    } else if let Ok(ub) = model.extract::<PyRef<PyUnbinnedModel>>() {
        if data.is_some() {
            return Err(PyValueError::new_err(
                "data override is not supported for UnbinnedModel (data is in the model spec)",
            ));
        }
        unbinned_hypotest_toys_impl(
            py,
            poi_test,
            &ub,
            n_toys,
            seed,
            expected_set,
            return_tail_probs,
            return_meta,
        )
    } else {
        Err(pyo3::exceptions::PyTypeError::new_err("Expected HistFactoryModel or UnbinnedModel"))
    }
}

/// Internal: toy-based hypotest for HistFactory models.
fn hypotest_toys_hf_impl(
    py: Python<'_>,
    poi_test: f64,
    model: &PyHistFactoryModel,
    n_toys: usize,
    seed: u64,
    expected_set: bool,
    data: Option<Vec<f64>>,
    return_tail_probs: bool,
    return_meta: bool,
) -> PyResult<Py<PyAny>> {
    let mle = RustMLE::new();
    let fit_model = if let Some(obs_main) = data {
        model
            .inner
            .with_observed_main(&obs_main)
            .map_err(|e| PyValueError::new_err(format!("Failed to set observed data: {}", e)))?
    } else {
        model.inner.clone()
    };

    if expected_set {
        let r = ns_inference::hypotest_qtilde_toys_expected_set(
            &mle, &fit_model, poi_test, n_toys, seed,
        )
        .map_err(|e| PyValueError::new_err(format!("Toy-based hypotest failed: {}", e)))?;

        if return_meta {
            let d = PyDict::new(py);
            d.set_item("mu_test", r.observed.mu_test)?;
            d.set_item("cls", r.observed.cls)?;
            d.set_item("clsb", r.observed.clsb)?;
            d.set_item("clb", r.observed.clb)?;
            d.set_item("q_obs", r.observed.q_obs)?;
            d.set_item("mu_hat", r.observed.mu_hat)?;
            d.set_item("n_toys_b", r.observed.n_toys_b)?;
            d.set_item("n_toys_sb", r.observed.n_toys_sb)?;
            d.set_item("n_error_b", r.observed.n_error_b)?;
            d.set_item("n_error_sb", r.observed.n_error_sb)?;
            d.set_item("n_nonconverged_b", r.observed.n_nonconverged_b)?;
            d.set_item("n_nonconverged_sb", r.observed.n_nonconverged_sb)?;
            d.set_item("expected", r.expected.to_vec())?;
            return Ok(d.into_any().unbind());
        }

        if return_tail_probs {
            (r.observed.cls, r.expected.to_vec(), vec![r.observed.clsb, r.observed.clb])
                .into_py_any(py)
        } else {
            (r.observed.cls, r.expected.to_vec()).into_py_any(py)
        }
    } else {
        let r = ns_inference::hypotest_qtilde_toys(&mle, &fit_model, poi_test, n_toys, seed)
            .map_err(|e| PyValueError::new_err(format!("Toy-based hypotest failed: {}", e)))?;

        if return_meta {
            let d = PyDict::new(py);
            d.set_item("mu_test", r.mu_test)?;
            d.set_item("cls", r.cls)?;
            d.set_item("clsb", r.clsb)?;
            d.set_item("clb", r.clb)?;
            d.set_item("q_obs", r.q_obs)?;
            d.set_item("mu_hat", r.mu_hat)?;
            d.set_item("n_toys_b", r.n_toys_b)?;
            d.set_item("n_toys_sb", r.n_toys_sb)?;
            d.set_item("n_error_b", r.n_error_b)?;
            d.set_item("n_error_sb", r.n_error_sb)?;
            d.set_item("n_nonconverged_b", r.n_nonconverged_b)?;
            d.set_item("n_nonconverged_sb", r.n_nonconverged_sb)?;
            return Ok(d.into_any().unbind());
        }

        if return_tail_probs {
            (r.cls, vec![r.clsb, r.clb]).into_py_any(py)
        } else {
            r.cls.into_py_any(py)
        }
    }
}

/// Internal: unbinned hypotest (toy-based CLs) — called by unified `hypotest_toys()`.
fn unbinned_hypotest_toys_impl(
    py: Python<'_>,
    poi_test: f64,
    model: &PyUnbinnedModel,
    n_toys: usize,
    seed: u64,
    expected_set: bool,
    return_tail_probs: bool,
    return_meta: bool,
) -> PyResult<Py<PyAny>> {
    let mle = RustMLE::new();
    let fit_model = model.inner.clone();

    let sample_toy =
        |m: &RustUnbinnedModel, params: &[f64], seed: u64| m.sample_poisson_toy(params, seed);

    if expected_set {
        let r = ns_inference::hypotest_qtilde_toys_expected_set_with_sampler(
            &mle, &fit_model, poi_test, n_toys, seed, sample_toy,
        )
        .map_err(|e| PyValueError::new_err(format!("Toy-based hypotest failed: {}", e)))?;

        if return_meta {
            let d = PyDict::new(py);
            d.set_item("mu_test", r.observed.mu_test)?;
            d.set_item("cls", r.observed.cls)?;
            d.set_item("clsb", r.observed.clsb)?;
            d.set_item("clb", r.observed.clb)?;
            d.set_item("q_obs", r.observed.q_obs)?;
            d.set_item("mu_hat", r.observed.mu_hat)?;
            d.set_item("n_toys_b", r.observed.n_toys_b)?;
            d.set_item("n_toys_sb", r.observed.n_toys_sb)?;
            d.set_item("n_error_b", r.observed.n_error_b)?;
            d.set_item("n_error_sb", r.observed.n_error_sb)?;
            d.set_item("n_nonconverged_b", r.observed.n_nonconverged_b)?;
            d.set_item("n_nonconverged_sb", r.observed.n_nonconverged_sb)?;
            d.set_item("expected", r.expected.to_vec())?;
            return Ok(d.into_any().unbind());
        }

        if return_tail_probs {
            (r.observed.cls, r.expected.to_vec(), vec![r.observed.clsb, r.observed.clb])
                .into_py_any(py)
        } else {
            (r.observed.cls, r.expected.to_vec()).into_py_any(py)
        }
    } else {
        let r = ns_inference::hypotest_qtilde_toys_with_sampler(
            &mle, &fit_model, poi_test, n_toys, seed, sample_toy,
        )
        .map_err(|e| PyValueError::new_err(format!("Toy-based hypotest failed: {}", e)))?;

        if return_meta {
            let d = PyDict::new(py);
            d.set_item("mu_test", r.mu_test)?;
            d.set_item("cls", r.cls)?;
            d.set_item("clsb", r.clsb)?;
            d.set_item("clb", r.clb)?;
            d.set_item("q_obs", r.q_obs)?;
            d.set_item("mu_hat", r.mu_hat)?;
            d.set_item("n_toys_b", r.n_toys_b)?;
            d.set_item("n_toys_sb", r.n_toys_sb)?;
            d.set_item("n_error_b", r.n_error_b)?;
            d.set_item("n_error_sb", r.n_error_sb)?;
            d.set_item("n_nonconverged_b", r.n_nonconverged_b)?;
            d.set_item("n_nonconverged_sb", r.n_nonconverged_sb)?;
            return Ok(d.into_any().unbind());
        }

        if return_tail_probs {
            (r.cls, vec![r.clsb, r.clb]).into_py_any(py)
        } else {
            r.cls.into_py_any(py)
        }
    }
}

/// Internal: unbinned profile scan — called by unified `profile_scan()`.
fn unbinned_profile_scan_impl(
    py: Python<'_>,
    model: &PyUnbinnedModel,
    mu_values: Vec<f64>,
) -> PyResult<Py<PyAny>> {
    let mle = RustMLE::new();
    let scan = pl::scan(&mle, &model.inner, &mu_values)
        .map_err(|e| PyValueError::new_err(format!("Profile scan failed: {}", e)))?;

    let out = PyDict::new(py);
    out.set_item("input_schema_version", model.schema_version())?;
    out.set_item("poi_index", scan.poi_index)?;
    out.set_item("mu_hat", scan.mu_hat)?;
    out.set_item("nll_hat", scan.nll_hat)?;

    let mut point_objs: Vec<Py<PyAny>> = Vec::with_capacity(scan.points.len());
    for p in scan.points {
        let d = PyDict::new(py);
        d.set_item("mu", p.mu)?;
        d.set_item("q_mu", p.q_mu)?;
        d.set_item("nll_mu", p.nll_mu)?;
        d.set_item("converged", p.converged)?;
        d.set_item("n_iter", p.n_iter)?;
        point_objs.push(d.into_any().unbind());
    }
    out.set_item("points", PyList::new(py, point_objs)?)?;

    Ok(out.into_any().unbind())
}

/// Internal: unbinned `q_mu` computation — called by unified `hypotest()`.
fn unbinned_hypotest_impl(
    py: Python<'_>,
    mu_test: f64,
    model: &PyUnbinnedModel,
) -> PyResult<Py<PyAny>> {
    let poi_idx = model.inner.poi_index().ok_or_else(|| {
        PyValueError::new_err("UnbinnedModel has no POI (spec.model.poi is required for hypotest)")
    })?;

    let mle = RustMLE::new();
    let m = model.inner.clone();

    let (free, fixed_mu, q0, nll_mu0) = py
        .detach(move || -> NsResult<(RustOptimizationResult, RustOptimizationResult, Option<f64>, Option<f64>)> {
            let free = mle.fit_minimum(&m)?;
            let fixed_model = m.with_fixed_param(poi_idx, mu_test);
            let mut warm_mu = free.parameters.clone();
            warm_mu[poi_idx] = mu_test;
            let fixed_mu = mle.fit_minimum_from(&fixed_model, &warm_mu)?;

            let (poi_lo, poi_hi) = m.parameter_bounds()[poi_idx];
            let mut q0: Option<f64> = None;
            let mut nll_mu0: Option<f64> = None;
            if poi_lo <= 0.0 && 0.0 <= poi_hi {
                let fixed0_model = m.with_fixed_param(poi_idx, 0.0);
                let mut warm0 = free.parameters.clone();
                warm0[poi_idx] = 0.0;
                let fixed0 = mle.fit_minimum_from(&fixed0_model, &warm0)?;
                let llr0 = 2.0 * (fixed0.fval - free.fval);
                let mu_hat = free.parameters.get(poi_idx).copied().unwrap_or(f64::NAN);
                q0 = Some(if mu_hat < 0.0 { 0.0 } else { llr0.max(0.0) });
                nll_mu0 = Some(fixed0.fval);
            }

            Ok((free, fixed_mu, q0, nll_mu0))
        })
        .map_err(|e| PyValueError::new_err(format!("Unbinned hypotest failed: {}", e)))?;

    let mu_hat = free.parameters.get(poi_idx).copied().unwrap_or(f64::NAN);
    let nll_hat = free.fval;
    let nll_mu = fixed_mu.fval;

    // Upper-limit style q_mu (one-sided).
    let llr = 2.0 * (nll_mu - nll_hat);
    let mut q_mu = llr.max(0.0);
    if mu_hat > mu_test {
        q_mu = 0.0;
    }

    let out = PyDict::new(py);
    out.set_item("input_schema_version", model.schema_version())?;
    out.set_item("poi_index", poi_idx)?;
    out.set_item("mu_test", mu_test)?;
    out.set_item("mu_hat", mu_hat)?;
    out.set_item("nll_hat", nll_hat)?;
    out.set_item("nll_mu", nll_mu)?;
    out.set_item("q_mu", q_mu)?;
    out.set_item("q0", q0)?;
    out.set_item("nll_mu0", nll_mu0)?;
    out.set_item("converged_hat", free.converged)?;
    out.set_item("converged_mu", fixed_mu.converged)?;
    out.set_item("n_iter_hat", free.n_iter)?;
    out.set_item("n_iter_mu", fixed_mu.n_iter)?;

    Ok(out.into_any().unbind())
}

/// Profile likelihood scan over POI values (q_mu).
///
/// Dispatches on model type: HistFactoryModel (CPU/CUDA) or UnbinnedModel (CPU only).
/// Pass `return_curve=True` for plot-friendly arrays (mu_values, q_mu_values, twice_delta_nll).
#[pyfunction]
#[pyo3(signature = (model, mu_values, *, data=None, device="cpu", return_params=false, return_curve=false))]
fn profile_scan(
    py: Python<'_>,
    model: &Bound<'_, PyAny>,
    mu_values: Vec<f64>,
    data: Option<Vec<f64>>,
    device: &str,
    return_params: bool,
    return_curve: bool,
) -> PyResult<Py<PyAny>> {
    if let Ok(hf) = model.extract::<PyRef<PyHistFactoryModel>>() {
        profile_scan_hf_impl(py, &hf, mu_values, data, device, return_params, return_curve)
    } else if let Ok(ub) = model.extract::<PyRef<PyUnbinnedModel>>() {
        if data.is_some() {
            return Err(PyValueError::new_err(
                "data override is not supported for UnbinnedModel (data is in the model spec)",
            ));
        }
        if device != "cpu" {
            return Err(PyValueError::new_err(
                "UnbinnedModel profile scan only supports device='cpu'.",
            ));
        }
        unbinned_profile_scan_impl(py, &ub, mu_values)
    } else {
        Err(pyo3::exceptions::PyTypeError::new_err("Expected HistFactoryModel or UnbinnedModel"))
    }
}

/// Internal: HistFactory profile scan.
fn profile_scan_hf_impl(
    py: Python<'_>,
    model: &PyHistFactoryModel,
    mu_values: Vec<f64>,
    data: Option<Vec<f64>>,
    device: &str,
    return_params: bool,
    return_curve: bool,
) -> PyResult<Py<PyAny>> {
    let mle = RustMLE::with_config(OptimizerConfig {
        max_iter: 20000,
        tol: 1e-6,
        m: 20,
        smooth_bounds: false,
    });
    let fit_model = if let Some(obs_main) = data {
        model
            .inner
            .with_observed_main(&obs_main)
            .map_err(|e| PyValueError::new_err(format!("Failed to set observed data: {}", e)))?
    } else {
        model.inner.clone()
    };

    if return_params && device == "cuda" {
        return Err(PyValueError::new_err(
            "return_params is not supported for device='cuda' yet (cpu-only debug surface)",
        ));
    }

    let scan = if device == "cuda" {
        #[cfg(feature = "cuda")]
        {
            pl::scan_gpu(&mle, &fit_model, &mu_values)
                .map_err(|e| PyValueError::new_err(format!("GPU profile scan failed: {}", e)))?
        }
        #[cfg(not(feature = "cuda"))]
        {
            return Err(PyValueError::new_err(
                "Device 'cuda' not available. Build with --features cuda.",
            ));
        }
    } else if return_params {
        pl::scan_histfactory_diag(&mle, &fit_model, &mu_values)
            .map_err(|e| PyValueError::new_err(format!("Profile scan failed: {}", e)))?
    } else {
        pl::scan_histfactory(&mle, &fit_model, &mu_values)
            .map_err(|e| PyValueError::new_err(format!("Profile scan failed: {}", e)))?
    };

    // If return_curve, produce the plot-friendly artifact format.
    if return_curve {
        let art: ProfileCurveArtifact = scan.into();
        let out = PyDict::new(py);
        out.set_item("poi_index", art.poi_index)?;
        out.set_item("mu_hat", art.mu_hat)?;
        out.set_item("nll_hat", art.nll_hat)?;
        out.set_item("mu_values", art.mu_values.clone())?;
        out.set_item("q_mu_values", art.q_mu_values.clone())?;
        out.set_item("twice_delta_nll", art.twice_delta_nll.clone())?;

        let points: Vec<Py<PyAny>> = art
            .points
            .iter()
            .map(|p| -> PyResult<Py<PyAny>> {
                let d = PyDict::new(py);
                d.set_item("mu", p.mu)?;
                d.set_item("q_mu", p.q_mu)?;
                d.set_item("nll_mu", p.nll_mu)?;
                d.set_item("converged", p.converged)?;
                d.set_item("n_iter", p.n_iter)?;
                Ok(d.into_any().unbind())
            })
            .collect::<PyResult<Vec<_>>>()?;
        out.set_item("points", PyList::new(py, points)?)?;

        return Ok(out.into_any().unbind());
    }

    let out = PyDict::new(py);
    out.set_item("poi_index", scan.poi_index)?;
    out.set_item("mu_hat", scan.mu_hat)?;
    out.set_item("nll_hat", scan.nll_hat)?;

    let mut point_objs: Vec<Py<PyAny>> = Vec::with_capacity(scan.points.len());
    for p in scan.points {
        let d = PyDict::new(py);
        d.set_item("mu", p.mu)?;
        d.set_item("q_mu", p.q_mu)?;
        d.set_item("nll_mu", p.nll_mu)?;
        d.set_item("converged", p.converged)?;
        d.set_item("n_iter", p.n_iter)?;
        if return_params && let Some(diag) = p.diag {
            d.set_item("params", diag.parameters)?;
            d.set_item("message", diag.message)?;
            d.set_item("n_fev", diag.n_fev)?;
            d.set_item("n_gev", diag.n_gev)?;
            d.set_item("initial_cost", diag.initial_cost)?;
            d.set_item("grad_l2", diag.grad_l2)?;
        }
        point_objs.push(d.into_any().unbind());
    }
    let points = PyList::new(py, point_objs)?;
    out.set_item("points", points)?;

    Ok(out.into_any().unbind())
}

/// Observed upper limit via asymptotic CLs (qtilde).
///
/// `method="bisect"` (default): returns a single float (observed limit).
/// `method="root"`: returns (observed, [expected_band]) like `upper_limits_root()`.
#[pyfunction]
#[pyo3(signature = (model, *, method="bisect", alpha=0.05, lo=0.0, hi=None, rtol=1e-4, max_iter=80, data=None))]
fn upper_limit(
    py: Python<'_>,
    model: &PyHistFactoryModel,
    method: &str,
    alpha: f64,
    lo: f64,
    hi: Option<f64>,
    rtol: f64,
    max_iter: usize,
    data: Option<Vec<f64>>,
) -> PyResult<Py<PyAny>> {
    let mle = RustMLE::new();
    let fit_model = if let Some(obs_main) = data {
        model
            .inner
            .with_observed_main(&obs_main)
            .map_err(|e| PyValueError::new_err(format!("Failed to set observed data: {}", e)))?
    } else {
        model.inner.clone()
    };

    let ctx = RustCLsCtx::new(&mle, &fit_model)
        .map_err(|e| PyValueError::new_err(format!("Failed to build asymptotic context: {}", e)))?;

    let hi0 = hi.unwrap_or_else(|| {
        fit_model
            .poi_index()
            .and_then(|idx| fit_model.parameters().get(idx).map(|p| p.bounds.1))
            .unwrap_or(10.0)
    });

    match method {
        "bisect" => {
            let obs = ctx
                .upper_limit_qtilde(&mle, alpha, lo, hi0, rtol, max_iter)
                .map_err(|e| PyValueError::new_err(format!("Upper limit failed: {}", e)))?;
            obs.into_py_any(py)
        }
        "root" => {
            let (obs, exp) = ctx
                .upper_limits_qtilde_bisection(&mle, alpha, lo, hi0, rtol, max_iter)
                .map_err(|e| PyValueError::new_err(format!("Upper limits root failed: {}", e)))?;
            (obs, exp.to_vec()).into_py_any(py)
        }
        _ => Err(PyValueError::new_err(format!(
            "Unknown method '{}'. Use 'bisect' or 'root'.",
            method
        ))),
    }
}

/// Observed and expected upper limits via linear scan + interpolation (pyhf-compatible).
#[pyfunction]
#[pyo3(signature = (model, scan, *, alpha=0.05, data=None))]
fn upper_limits(
    model: &PyHistFactoryModel,
    scan: Vec<f64>,
    alpha: f64,
    data: Option<Vec<f64>>,
) -> PyResult<(f64, Vec<f64>)> {
    let mle = RustMLE::new();
    let fit_model = if let Some(obs_main) = data {
        model
            .inner
            .with_observed_main(&obs_main)
            .map_err(|e| PyValueError::new_err(format!("Failed to set observed data: {}", e)))?
    } else {
        model.inner.clone()
    };

    let ctx = RustCLsCtx::new(&mle, &fit_model)
        .map_err(|e| PyValueError::new_err(format!("Failed to build asymptotic context: {}", e)))?;
    let (obs, exp) = ctx
        .upper_limits_qtilde_linear_scan(&mle, alpha, &scan)
        .map_err(|e| PyValueError::new_err(format!("Upper limits failed: {}", e)))?;

    Ok((obs, exp.to_vec()))
}

/// Internal: upper limits via bisection root-finding — kept for backward compatibility.
/// Prefer `upper_limit(model, method="root")`.
#[allow(dead_code)]
fn upper_limits_root_impl(
    model: &PyHistFactoryModel,
    alpha: f64,
    lo: f64,
    hi: Option<f64>,
    rtol: f64,
    max_iter: usize,
    data: Option<Vec<f64>>,
) -> PyResult<(f64, Vec<f64>)> {
    let mle = RustMLE::new();
    let fit_model = if let Some(obs_main) = data {
        model
            .inner
            .with_observed_main(&obs_main)
            .map_err(|e| PyValueError::new_err(format!("Failed to set observed data: {}", e)))?
    } else {
        model.inner.clone()
    };

    let ctx = RustCLsCtx::new(&mle, &fit_model)
        .map_err(|e| PyValueError::new_err(format!("Failed to build asymptotic context: {}", e)))?;

    let hi0 = hi.unwrap_or_else(|| {
        fit_model
            .poi_index()
            .and_then(|idx| fit_model.parameters().get(idx).map(|p| p.bounds.1))
            .unwrap_or(10.0)
    });

    let (obs, exp) = ctx
        .upper_limits_qtilde_bisection(&mle, alpha, lo, hi0, rtol, max_iter)
        .map_err(|e| PyValueError::new_err(format!("Upper limits root failed: {}", e)))?;

    Ok((obs, exp.to_vec()))
}

/// Bayesian NUTS/HMC sampling with ArviZ-compatible output.
#[pyfunction]
#[pyo3(signature = (model, *, n_chains=4, n_warmup=500, n_samples=1000, seed=42, max_treedepth=10, target_accept=0.8, init_strategy="random", metric="diagonal", init_jitter=0.0, init_jitter_rel=None, init_overdispersed_rel=None, stepsize_jitter=0.0, data=None))]
fn sample<'py>(
    py: Python<'py>,
    model: &Bound<'py, PyAny>,
    n_chains: usize,
    n_warmup: usize,
    n_samples: usize,
    seed: u64,
    max_treedepth: usize,
    target_accept: f64,
    init_strategy: &str,
    metric: &str,
    init_jitter: f64,
    init_jitter_rel: Option<f64>,
    init_overdispersed_rel: Option<f64>,
    stepsize_jitter: f64,
    data: Option<Vec<f64>>,
) -> PyResult<Py<PyAny>> {
    validate_nuts_config(
        n_chains,
        n_warmup,
        n_samples,
        max_treedepth,
        target_accept,
        init_jitter,
        init_jitter_rel,
        init_overdispersed_rel,
    )?;

    let init_strategy = match init_strategy {
        "random" => InitStrategy::Random,
        "mle" => InitStrategy::Mle,
        "pathfinder" => InitStrategy::Pathfinder,
        other => {
            return Err(PyValueError::new_err(format!(
                "init must be 'random', 'mle', or 'pathfinder', got '{other}'"
            )));
        }
    };

    let metric_type = match metric {
        "diagonal" | "diag" | "diag_e" => ns_inference::MetricType::Diagonal,
        "dense" | "dense_e" => ns_inference::MetricType::Dense,
        "auto" => ns_inference::MetricType::Auto,
        other => {
            return Err(PyValueError::new_err(format!(
                "metric must be 'diagonal', 'dense', or 'auto', got '{other}'"
            )));
        }
    };

    let config = NutsConfig {
        max_treedepth,
        target_accept,
        init_strategy,
        metric_type,
        init_jitter,
        init_jitter_rel,
        init_overdispersed_rel,
        stepsize_jitter,
    };

    // Accept `Posterior` objects (MAP sampling), otherwise sample the model (ML posterior).
    let result = if let Ok(post) = model.extract::<PyRef<'_, PyPosterior>>() {
        if data.is_some() {
            return Err(PyValueError::new_err(
                "data= is not supported when sampling a Posterior; build the Posterior from the desired model/data",
            ));
        }
        let priors = post.priors.clone();
        let m = post.model.clone();
        py.detach(move || {
            m.sample_nuts_multichain_map(n_chains, n_warmup, n_samples, seed, config, priors)
        })
        .map_err(|e| PyValueError::new_err(format!("Sampling failed: {}", e)))?
    } else {
        let sample_model = extract_posterior_model_with_data(model, data)?;
        py.detach(move || {
            sample_model.sample_nuts_multichain(n_chains, n_warmup, n_samples, seed, config)
        })
        .map_err(|e| PyValueError::new_err(format!("Sampling failed: {}", e)))?
    };

    sampler_result_to_py(py, &result, n_chains, n_warmup, n_samples)
}

/// MAMS (Metropolis-Adjusted Microcanonical Sampler) with ArviZ-compatible output.
///
/// Uses microcanonical dynamics (Sundman leapfrog, norm-preserving partial refresh)
/// for improved ESS/gradient on funnel and multiscale geometries.
#[pyfunction]
#[pyo3(name = "sample_mams", signature = (
    model, *, n_chains=4, n_warmup=1000, n_samples=1000, seed=42,
    target_accept=0.9, init_strategy="random", metric="diagonal",
    init_step_size=0.0, init_l=0.0, max_leapfrog=1024,
    diagonal_precond=true, eps_jitter=0.1, data=None
))]
fn sample_mams_py<'py>(
    py: Python<'py>,
    model: &Bound<'py, PyAny>,
    n_chains: usize,
    n_warmup: usize,
    n_samples: usize,
    seed: u64,
    target_accept: f64,
    init_strategy: &str,
    metric: &str,
    init_step_size: f64,
    init_l: f64,
    max_leapfrog: usize,
    diagonal_precond: bool,
    eps_jitter: f64,
    data: Option<Vec<f64>>,
) -> PyResult<Py<PyAny>> {
    // Validate
    if n_chains == 0 {
        return Err(PyValueError::new_err("n_chains must be >= 1"));
    }
    if n_samples == 0 {
        return Err(PyValueError::new_err("n_samples must be >= 1"));
    }
    if !(target_accept.is_finite() && 0.0 < target_accept && target_accept < 1.0) {
        return Err(PyValueError::new_err("target_accept must be finite and in (0,1)"));
    }

    let init_strategy = match init_strategy {
        "random" => InitStrategy::Random,
        "mle" => InitStrategy::Mle,
        "pathfinder" => InitStrategy::Pathfinder,
        other => {
            return Err(PyValueError::new_err(format!(
                "init_strategy must be 'random', 'mle', or 'pathfinder', got '{other}'"
            )));
        }
    };

    let metric_type = match metric {
        "diagonal" | "diag" | "diag_e" => MetricType::Diagonal,
        "dense" | "dense_e" => MetricType::Dense,
        "auto" => MetricType::Auto,
        other => {
            return Err(PyValueError::new_err(format!(
                "metric must be 'diagonal', 'dense', or 'auto', got '{other}'"
            )));
        }
    };

    let config = MamsConfig {
        n_warmup,
        n_samples,
        target_accept,
        init_step_size,
        init_l,
        max_leapfrog,
        diagonal_precond,
        init_strategy,
        metric_type,
        eps_jitter,
    };

    let result = if let Ok(post) = model.extract::<PyRef<'_, PyPosterior>>() {
        if data.is_some() {
            return Err(PyValueError::new_err(
                "data= is not supported when sampling a Posterior; build the Posterior from the desired model/data",
            ));
        }
        let priors = post.priors.clone();
        let m = post.model.clone();
        py.detach(move || m.sample_mams_mc_map(n_chains, seed, config, priors))
            .map_err(|e| PyValueError::new_err(format!("MAMS sampling failed: {}", e)))?
    } else {
        let sample_model = extract_posterior_model_with_data(model, data)?;
        py.detach(move || sample_model.sample_mams_mc(n_chains, seed, config))
            .map_err(|e| PyValueError::new_err(format!("MAMS sampling failed: {}", e)))?
    };

    sampler_result_to_py_gates(py, &result, n_chains, n_warmup, n_samples, true)
}

/// User-defined CUDA model for GPU LAPS sampling via NVRTC JIT compilation.
///
/// The ``cuda_src`` must define two ``__device__`` functions:
///
/// - ``__device__ double user_nll(const double* x, int dim, const double* model_data)``
/// - ``__device__ void user_grad(const double* x, double* grad, int dim, const double* model_data)``
///
/// Example::
///
///     model = nextstat.RawCudaModel(dim=10, cuda_src=r'''
///         __device__ double user_nll(const double* x, int dim, const double* data) {
///             double nll = 0.0;
///             for (int i = 0; i < dim; i++) nll += 0.5 * x[i] * x[i];
///             return nll;
///         }
///         __device__ void user_grad(const double* x, double* grad, int dim, const double* data) {
///             for (int i = 0; i < dim; i++) grad[i] = x[i];
///         }
///     ''')
///     result = nextstat.sample_laps(model, n_chains=4096, n_samples=2000)
#[cfg(feature = "cuda")]
#[pyclass(name = "RawCudaModel")]
#[derive(Clone)]
struct PyRawCudaModel {
    dim: usize,
    cuda_src: String,
    data: Vec<f64>,
    param_names: Vec<String>,
}

#[cfg(feature = "cuda")]
#[pymethods]
impl PyRawCudaModel {
    #[new]
    #[pyo3(signature = (dim, cuda_src, *, data=None, param_names=None))]
    fn new(
        dim: usize,
        cuda_src: String,
        data: Option<Vec<f64>>,
        param_names: Option<Vec<String>>,
    ) -> PyResult<Self> {
        if dim == 0 {
            return Err(PyValueError::new_err("dim must be >= 1"));
        }
        if !cuda_src.contains("user_nll") || !cuda_src.contains("user_grad") {
            return Err(PyValueError::new_err(
                "cuda_src must define __device__ functions user_nll() and user_grad()",
            ));
        }
        Ok(Self {
            dim,
            cuda_src,
            data: data.unwrap_or_default(),
            param_names: param_names.unwrap_or_default(),
        })
    }

    /// Parameter dimensionality.
    #[getter]
    fn dim(&self) -> usize {
        self.dim
    }

    /// Raw CUDA C source code.
    #[getter]
    fn cuda_src(&self) -> &str {
        &self.cuda_src
    }
}

/// LAPS (Late-Adjusted Parallel Sampler): GPU-accelerated MAMS on CUDA.
///
/// Runs thousands of chains simultaneously on GPU. Returns the same dict format
/// as `sample_mams()` plus `wall_time_s` and `n_kernel_launches`.
///
/// The `model` argument can be:
/// - A string name: "std_normal", "eight_schools", "neal_funnel", "neal_funnel_centered",
///   "glm_logistic", "glm_linear", "glm_poisson", "glm_negbin", "glm_composed_logistic"
/// - A `RawCudaModel` instance for JIT-compiled user-defined models
#[cfg(any(feature = "cuda", feature = "metal"))]
#[pyfunction]
#[pyo3(name = "sample_laps", signature = (
    model, *, model_data=None, n_chains=4096, n_warmup=500, n_samples=2000,
    seed=42, target_accept=0.9, init_step_size=0.0, init_l=0.0,
    max_leapfrog=8192, device_ids=None,
    sync_interval=100, welford_chains=256, batch_size=1000, fused_transitions=1000,
    report_chains=256,
    diagonal_precond=true,
    divergence_threshold=1000.0
))]
fn sample_laps_py<'py>(
    py: Python<'py>,
    model: &Bound<'py, PyAny>,
    model_data: Option<&Bound<'py, PyDict>>,
    n_chains: usize,
    n_warmup: usize,
    n_samples: usize,
    seed: u64,
    target_accept: f64,
    init_step_size: f64,
    init_l: f64,
    max_leapfrog: usize,
    device_ids: Option<Vec<usize>>,
    sync_interval: usize,
    welford_chains: usize,
    batch_size: usize,
    fused_transitions: usize,
    report_chains: usize,
    diagonal_precond: bool,
    divergence_threshold: f64,
) -> PyResult<Py<PyAny>> {
    use ns_inference::laps::{LapsConfig, LapsModel};

    if n_chains == 0 {
        return Err(PyValueError::new_err("n_chains must be >= 1"));
    }
    if n_samples == 0 {
        return Err(PyValueError::new_err("n_samples must be >= 1"));
    }
    if report_chains == 0 {
        return Err(PyValueError::new_err("report_chains must be >= 1"));
    }

    // Check if model is a RawCudaModel instance (CUDA only)
    #[cfg(feature = "cuda")]
    let laps_model_from_raw: Option<LapsModel> =
        model.extract::<PyRef<PyRawCudaModel>>().ok().map(|raw| LapsModel::Custom {
            dim: raw.dim,
            param_names: raw.param_names.clone(),
            model_data: raw.data.clone(),
            cuda_src: raw.cuda_src.clone(),
        });
    #[cfg(not(feature = "cuda"))]
    let laps_model_from_raw: Option<LapsModel> = None;

    let laps_model = if let Some(m) = laps_model_from_raw {
        m
    } else if let Ok(name) = model.extract::<&str>() {
        match name {
            "std_normal" => {
                let dim = if let Some(d) = model_data {
                    d.get_item("dim")?.map(|v| v.extract::<usize>()).transpose()?.unwrap_or(10)
                } else {
                    10
                };
                LapsModel::StdNormal { dim }
            }
            "eight_schools" => {
                let d = model_data.ok_or_else(|| {
                    PyValueError::new_err("eight_schools requires model_data with 'y' and 'sigma'")
                })?;
                let y: Vec<f64> = d
                    .get_item("y")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'y'"))?
                    .extract()?;
                let sigma: Vec<f64> = d
                    .get_item("sigma")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'sigma'"))?
                    .extract()?;
                let prior_mu_sigma = d
                    .get_item("prior_mu_sigma")?
                    .map(|v| v.extract::<f64>())
                    .transpose()?
                    .unwrap_or(5.0);
                let prior_tau_scale = d
                    .get_item("prior_tau_scale")?
                    .map(|v| v.extract::<f64>())
                    .transpose()?
                    .unwrap_or(5.0);
                LapsModel::EightSchools { y, sigma, prior_mu_sigma, prior_tau_scale }
            }
            "neal_funnel" | "neal_funnel_ncp" => {
                let dim = if let Some(d) = model_data {
                    d.get_item("dim")?.map(|v| v.extract::<usize>()).transpose()?.unwrap_or(10)
                } else {
                    10
                };
                LapsModel::NealFunnelNcp { dim }
            }
            "neal_funnel_centered" => {
                let dim = if let Some(d) = model_data {
                    d.get_item("dim")?.map(|v| v.extract::<usize>()).transpose()?.unwrap_or(10)
                } else {
                    10
                };
                LapsModel::NealFunnel { dim }
            }
            "neal_funnel_riemannian" => {
                let dim = if let Some(d) = model_data {
                    d.get_item("dim")?.map(|v| v.extract::<usize>()).transpose()?.unwrap_or(10)
                } else {
                    10
                };
                LapsModel::NealFunnelRiemannian { dim }
            }
            "glm_logistic" => {
                let d = model_data.ok_or_else(|| {
                    PyValueError::new_err(
                        "glm_logistic requires model_data with 'x', 'y', 'n', 'p'",
                    )
                })?;
                let x_data: Vec<f64> = d
                    .get_item("x")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'x'"))?
                    .extract()?;
                let y_data: Vec<f64> = d
                    .get_item("y")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'y'"))?
                    .extract()?;
                let n: usize = d
                    .get_item("n")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'n'"))?
                    .extract()?;
                let p: usize = d
                    .get_item("p")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'p'"))?
                    .extract()?;
                // Validate dimensions and values
                if n == 0 || p == 0 {
                    return Err(PyValueError::new_err("glm_logistic: n and p must be > 0"));
                }
                if x_data.len() != n * p {
                    return Err(PyValueError::new_err(format!(
                        "glm_logistic: x_data.len()={} != n*p={}*{}={}",
                        x_data.len(),
                        n,
                        p,
                        n * p
                    )));
                }
                if y_data.len() != n {
                    return Err(PyValueError::new_err(format!(
                        "glm_logistic: y_data.len()={} != n={}",
                        y_data.len(),
                        n
                    )));
                }
                if x_data.iter().any(|v| !v.is_finite()) {
                    return Err(PyValueError::new_err("glm_logistic: x_data contains NaN or Inf"));
                }
                if y_data.iter().any(|v| !v.is_finite()) {
                    return Err(PyValueError::new_err("glm_logistic: y_data contains NaN or Inf"));
                }
                if y_data.iter().any(|v| *v != 0.0 && *v != 1.0) {
                    return Err(PyValueError::new_err(
                        "glm_logistic: y_data must contain only 0.0 or 1.0",
                    ));
                }
                LapsModel::GlmLogistic { x_data, y_data, n, p }
            }
            "glm_linear" => {
                let d = model_data.ok_or_else(|| {
                    PyValueError::new_err("glm_linear requires model_data with 'x', 'y', 'n', 'p'")
                })?;
                let x_data: Vec<f64> = d
                    .get_item("x")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'x'"))?
                    .extract()?;
                let y_data: Vec<f64> = d
                    .get_item("y")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'y'"))?
                    .extract()?;
                let n: usize = d
                    .get_item("n")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'n'"))?
                    .extract()?;
                let p: usize = d
                    .get_item("p")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'p'"))?
                    .extract()?;
                if n == 0 || p == 0 {
                    return Err(PyValueError::new_err("glm_linear: n and p must be > 0"));
                }
                if x_data.len() != n * p {
                    return Err(PyValueError::new_err(format!(
                        "glm_linear: x_data.len()={} != n*p={}",
                        x_data.len(),
                        n * p
                    )));
                }
                if y_data.len() != n {
                    return Err(PyValueError::new_err(format!(
                        "glm_linear: y_data.len()={} != n={}",
                        y_data.len(),
                        n
                    )));
                }
                if x_data.iter().any(|v| !v.is_finite()) {
                    return Err(PyValueError::new_err("glm_linear: x_data contains NaN or Inf"));
                }
                if y_data.iter().any(|v| !v.is_finite()) {
                    return Err(PyValueError::new_err("glm_linear: y_data contains NaN or Inf"));
                }
                LapsModel::GlmLinear { x_data, y_data, n, p }
            }
            "glm_poisson" => {
                let d = model_data.ok_or_else(|| {
                    PyValueError::new_err("glm_poisson requires model_data with 'x', 'y', 'n', 'p'")
                })?;
                let x_data: Vec<f64> = d
                    .get_item("x")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'x'"))?
                    .extract()?;
                let y_data: Vec<f64> = d
                    .get_item("y")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'y'"))?
                    .extract()?;
                let n: usize = d
                    .get_item("n")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'n'"))?
                    .extract()?;
                let p: usize = d
                    .get_item("p")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'p'"))?
                    .extract()?;
                let offset: Option<Vec<f64>> =
                    d.get_item("offset")?.map(|v| v.extract()).transpose()?;
                if n == 0 || p == 0 {
                    return Err(PyValueError::new_err("glm_poisson: n and p must be > 0"));
                }
                if x_data.len() != n * p {
                    return Err(PyValueError::new_err(format!(
                        "glm_poisson: x_data.len()={} != n*p={}",
                        x_data.len(),
                        n * p
                    )));
                }
                if y_data.len() != n {
                    return Err(PyValueError::new_err(format!(
                        "glm_poisson: y_data.len()={} != n={}",
                        y_data.len(),
                        n
                    )));
                }
                if x_data.iter().any(|v| !v.is_finite()) {
                    return Err(PyValueError::new_err("glm_poisson: x_data contains NaN or Inf"));
                }
                if y_data.iter().any(|v| !v.is_finite()) {
                    return Err(PyValueError::new_err("glm_poisson: y_data contains NaN or Inf"));
                }
                if y_data.iter().any(|v| *v < 0.0) {
                    return Err(PyValueError::new_err(
                        "glm_poisson: y_data must be non-negative counts",
                    ));
                }
                if let Some(ref off) = offset {
                    if off.len() != n {
                        return Err(PyValueError::new_err(format!(
                            "glm_poisson: offset.len()={} != n={}",
                            off.len(),
                            n
                        )));
                    }
                    if off.iter().any(|v| !v.is_finite()) {
                        return Err(PyValueError::new_err(
                            "glm_poisson: offset contains NaN or Inf",
                        ));
                    }
                }
                LapsModel::GlmPoisson { x_data, y_data, n, p, offset }
            }
            "glm_negbin" | "glm_negative_binomial" => {
                let d = model_data.ok_or_else(|| {
                    PyValueError::new_err("glm_negbin requires model_data with 'x', 'y', 'n', 'p'")
                })?;
                let x_data: Vec<f64> = d
                    .get_item("x")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'x'"))?
                    .extract()?;
                let y_data: Vec<f64> = d
                    .get_item("y")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'y'"))?
                    .extract()?;
                let n: usize = d
                    .get_item("n")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'n'"))?
                    .extract()?;
                let p: usize = d
                    .get_item("p")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'p'"))?
                    .extract()?;
                let offset: Option<Vec<f64>> =
                    d.get_item("offset")?.map(|v| v.extract()).transpose()?;
                if n == 0 || p == 0 {
                    return Err(PyValueError::new_err("glm_negbin: n and p must be > 0"));
                }
                if x_data.len() != n * p {
                    return Err(PyValueError::new_err(format!(
                        "glm_negbin: x_data.len()={} != n*p={}",
                        x_data.len(),
                        n * p
                    )));
                }
                if y_data.len() != n {
                    return Err(PyValueError::new_err(format!(
                        "glm_negbin: y_data.len()={} != n={}",
                        y_data.len(),
                        n
                    )));
                }
                if x_data.iter().any(|v| !v.is_finite()) {
                    return Err(PyValueError::new_err("glm_negbin: x_data contains NaN or Inf"));
                }
                if y_data.iter().any(|v| !v.is_finite()) {
                    return Err(PyValueError::new_err("glm_negbin: y_data contains NaN or Inf"));
                }
                if y_data.iter().any(|v| *v < 0.0) {
                    return Err(PyValueError::new_err(
                        "glm_negbin: y_data must be non-negative counts",
                    ));
                }
                if let Some(ref off) = offset {
                    if off.len() != n {
                        return Err(PyValueError::new_err(format!(
                            "glm_negbin: offset.len()={} != n={}",
                            off.len(),
                            n
                        )));
                    }
                    if off.iter().any(|v| !v.is_finite()) {
                        return Err(PyValueError::new_err(
                            "glm_negbin: offset contains NaN or Inf",
                        ));
                    }
                }
                LapsModel::GlmNegBin { x_data, y_data, n, p, offset }
            }
            "glm_composed_logistic" => {
                let d = model_data.ok_or_else(|| {
                    PyValueError::new_err("glm_composed_logistic requires model_data with 'x', 'y', 'n', 'p', 'group_idx', 'n_groups'")
                })?;
                let x_data: Vec<f64> = d
                    .get_item("x")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'x'"))?
                    .extract()?;
                let y_data: Vec<f64> = d
                    .get_item("y")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'y'"))?
                    .extract()?;
                let n: usize = d
                    .get_item("n")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'n'"))?
                    .extract()?;
                let p: usize = d
                    .get_item("p")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'p'"))?
                    .extract()?;
                let group_idx: Vec<usize> = d
                    .get_item("group_idx")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'group_idx'"))?
                    .extract()?;
                let n_groups: usize = d
                    .get_item("n_groups")?
                    .ok_or_else(|| PyValueError::new_err("model_data must contain 'n_groups'"))?
                    .extract()?;
                let re_prior_sigma: f64 =
                    d.get_item("re_prior_sigma")?.map(|v| v.extract()).transpose()?.unwrap_or(1.0);
                if n == 0 || p == 0 || n_groups == 0 {
                    return Err(PyValueError::new_err(
                        "glm_composed_logistic: n, p, and n_groups must be > 0",
                    ));
                }
                if x_data.len() != n * p {
                    return Err(PyValueError::new_err(format!(
                        "glm_composed_logistic: x_data.len()={} != n*p={}",
                        x_data.len(),
                        n * p
                    )));
                }
                if y_data.len() != n {
                    return Err(PyValueError::new_err(format!(
                        "glm_composed_logistic: y_data.len()={} != n={}",
                        y_data.len(),
                        n
                    )));
                }
                if group_idx.len() != n {
                    return Err(PyValueError::new_err(format!(
                        "glm_composed_logistic: group_idx.len()={} != n={}",
                        group_idx.len(),
                        n
                    )));
                }
                if x_data.iter().any(|v| !v.is_finite()) {
                    return Err(PyValueError::new_err(
                        "glm_composed_logistic: x_data contains NaN or Inf",
                    ));
                }
                if y_data.iter().any(|v| !v.is_finite()) {
                    return Err(PyValueError::new_err(
                        "glm_composed_logistic: y_data contains NaN or Inf",
                    ));
                }
                if y_data.iter().any(|v| *v != 0.0 && *v != 1.0) {
                    return Err(PyValueError::new_err(
                        "glm_composed_logistic: y_data must contain only 0.0 or 1.0",
                    ));
                }
                if group_idx.iter().any(|&g| g >= n_groups) {
                    return Err(PyValueError::new_err(format!(
                        "glm_composed_logistic: group_idx values must be in [0, {})",
                        n_groups
                    )));
                }
                if re_prior_sigma <= 0.0 || !re_prior_sigma.is_finite() {
                    return Err(PyValueError::new_err(
                        "glm_composed_logistic: re_prior_sigma must be positive and finite",
                    ));
                }
                LapsModel::GlmComposedLogistic {
                    x_data,
                    y_data,
                    n,
                    p,
                    group_idx,
                    n_groups,
                    re_prior_sigma,
                }
            }
            other => {
                return Err(PyValueError::new_err(format!(
                    "model must be 'std_normal', 'eight_schools', 'neal_funnel', 'neal_funnel_centered', 'neal_funnel_ncp', 'neal_funnel_riemannian', 'glm_logistic', 'glm_linear', 'glm_poisson', 'glm_negbin', 'glm_negative_binomial', 'glm_composed_logistic', or a RawCudaModel, got '{other}'"
                )));
            }
        }
    } else {
        return Err(PyValueError::new_err("model must be a string or RawCudaModel instance"));
    };

    let config = LapsConfig {
        n_chains,
        n_warmup,
        n_samples,
        target_accept,
        init_step_size,
        init_l,
        max_leapfrog,
        seed,
        device_ids,
        sync_interval,
        welford_chains_per_device: welford_chains,
        batch_size,
        fused_transitions,
        report_chains,
        use_diagonal_precond: diagonal_precond,
        n_mass_windows: 3,
        divergence_threshold,
    };

    let laps_result = py
        .detach(move || ns_inference::laps::sample_laps(&laps_model, config))
        .map_err(|e| PyValueError::new_err(format!("LAPS sampling failed: {}", e)))?;

    let n_report_chains = laps_result.sampler_result.chains.len();
    let result = sampler_result_to_py_gates(
        py,
        &laps_result.sampler_result,
        n_report_chains,
        n_warmup,
        n_samples,
        true,
    )?;

    // Add LAPS-specific fields
    let out = result.bind(py).cast::<PyDict>()?;
    out.set_item("wall_time_s", laps_result.wall_time_s)?;
    out.set_item("n_kernel_launches", laps_result.n_kernel_launches)?;
    let phase_times = PyDict::new(py);
    phase_times.set_item("init_s", laps_result.phase_times[0])?;
    phase_times.set_item("warmup_s", laps_result.phase_times[1])?;
    phase_times.set_item("sampling_s", laps_result.phase_times[2])?;
    out.set_item("phase_times", phase_times)?;
    out.set_item("n_gpu_chains", n_chains)?;
    out.set_item("n_report_chains", n_report_chains)?;
    out.set_item("n_devices", laps_result.n_devices)?;
    out.set_item("device_ids", laps_result.device_ids)?;

    Ok(result)
}

/// Plot-friendly CLs curve + Brazil band artifact over a scan grid.
#[pyfunction]
#[pyo3(signature = (model, scan, *, alpha=0.05, data=None))]
fn cls_curve(
    py: Python<'_>,
    model: &PyHistFactoryModel,
    scan: Vec<f64>,
    alpha: f64,
    data: Option<Vec<f64>>,
) -> PyResult<Py<PyAny>> {
    if scan.len() < 2 {
        return Err(PyValueError::new_err("scan must have at least 2 points"));
    }

    let mle = RustMLE::new();
    let fit_model = if let Some(obs_main) = data {
        model
            .inner
            .with_observed_main(&obs_main)
            .map_err(|e| PyValueError::new_err(format!("Failed to set observed data: {}", e)))?
    } else {
        model.inner.clone()
    };

    let ctx = RustCLsCtx::new(&mle, &fit_model)
        .map_err(|e| PyValueError::new_err(format!("Failed to build asymptotic context: {}", e)))?;
    let art = ClsCurveArtifact::from_scan(&ctx, &mle, alpha, &scan)
        .map_err(|e| PyValueError::new_err(format!("CLs curve failed: {}", e)))?;

    let out = PyDict::new(py);
    out.set_item("alpha", art.alpha)?;
    out.set_item("nsigma_order", art.nsigma_order.to_vec())?;
    out.set_item("obs_limit", art.obs_limit)?;
    out.set_item("exp_limits", art.exp_limits.to_vec())?;
    out.set_item("mu_values", art.mu_values.clone())?;
    out.set_item("cls_obs", art.cls_obs.clone())?;
    out.set_item("cls_exp", art.cls_exp.to_vec())?;

    let points: Vec<Py<PyAny>> = art
        .points
        .iter()
        .map(|p| -> PyResult<Py<PyAny>> {
            let d = PyDict::new(py);
            d.set_item("mu", p.mu)?;
            d.set_item("cls", p.cls)?;
            d.set_item("expected", p.expected.to_vec())?;
            Ok(d.into_any().unbind())
        })
        .collect::<PyResult<Vec<_>>>()?;
    out.set_item("points", PyList::new(py, points)?)?;

    Ok(out.into_any().unbind())
}

/// Internal: plot-friendly profile scan artifact — prefer `profile_scan(model, mu_values, return_curve=True)`.
#[allow(dead_code)]
fn profile_curve_impl(
    py: Python<'_>,
    model: &PyHistFactoryModel,
    mu_values: Vec<f64>,
    data: Option<Vec<f64>>,
) -> PyResult<Py<PyAny>> {
    let mle = RustMLE::new();
    let fit_model = if let Some(obs_main) = data {
        model
            .inner
            .with_observed_main(&obs_main)
            .map_err(|e| PyValueError::new_err(format!("Failed to set observed data: {}", e)))?
    } else {
        model.inner.clone()
    };

    let scan = pl::scan_histfactory(&mle, &fit_model, &mu_values)
        .map_err(|e| PyValueError::new_err(format!("Profile scan failed: {}", e)))?;
    let art: ProfileCurveArtifact = scan.into();

    let out = PyDict::new(py);
    out.set_item("poi_index", art.poi_index)?;
    out.set_item("mu_hat", art.mu_hat)?;
    out.set_item("nll_hat", art.nll_hat)?;
    out.set_item("mu_values", art.mu_values.clone())?;
    out.set_item("q_mu_values", art.q_mu_values.clone())?;
    out.set_item("twice_delta_nll", art.twice_delta_nll.clone())?;

    let points: Vec<Py<PyAny>> = art
        .points
        .iter()
        .map(|p| -> PyResult<Py<PyAny>> {
            let d = PyDict::new(py);
            d.set_item("mu", p.mu)?;
            d.set_item("q_mu", p.q_mu)?;
            d.set_item("nll_mu", p.nll_mu)?;
            d.set_item("converged", p.converged)?;
            d.set_item("n_iter", p.n_iter)?;
            Ok(d.into_any().unbind())
        })
        .collect::<PyResult<Vec<_>>>()?;
    out.set_item("points", PyList::new(py, points)?)?;

    Ok(out.into_any().unbind())
}

// ---------------------------------------------------------------------------
// DifferentiableSession — PyTorch zero-copy differentiable NLL (CUDA only)
// ---------------------------------------------------------------------------

#[cfg(feature = "cuda")]
#[pyclass(name = "DifferentiableSession")]
struct PyDiffSession {
    inner: ns_inference::DifferentiableSession,
}

#[cfg(feature = "cuda")]
#[pymethods]
impl PyDiffSession {
    /// Create a differentiable GPU session.
    ///
    /// Args:
    ///     model: HistFactoryModel
    ///     signal_sample_name: name of the signal sample in the workspace
    #[new]
    fn new(model: &PyHistFactoryModel, signal_sample_name: &str) -> PyResult<Self> {
        let inner = ns_inference::DifferentiableSession::new(&model.inner, signal_sample_name)
            .map_err(|e| PyValueError::new_err(format!("{e}")))?;
        Ok(Self { inner })
    }

    /// Compute NLL and write signal gradient into PyTorch grad tensor (zero-copy).
    ///
    /// Args:
    ///     params: list[float] — nuisance parameter values
    ///     signal_ptr: int — from torch.Tensor.data_ptr() (CUDA device pointer)
    ///     grad_signal_ptr: int — from torch.Tensor.data_ptr() (CUDA device pointer, pre-zeroed)
    ///
    /// Returns:
    ///     float — NLL value
    fn nll_grad_signal(
        &mut self,
        params: Vec<f64>,
        signal_ptr: u64,
        grad_signal_ptr: u64,
    ) -> PyResult<f64> {
        self.inner
            .nll_grad_signal(&params, signal_ptr, grad_signal_ptr)
            .map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Number of signal bins.
    fn signal_n_bins(&self) -> usize {
        self.inner.signal_n_bins()
    }

    /// Number of model parameters.
    fn n_params(&self) -> usize {
        self.inner.n_params()
    }

    /// Default initial parameter values.
    fn parameter_init(&self) -> Vec<f64> {
        self.inner.parameter_init().to_vec()
    }
}

// ---------------------------------------------------------------------------
// ProfiledDifferentiableSession — profiled q₀/qμ with envelope gradient (CUDA)
// ---------------------------------------------------------------------------

#[cfg(feature = "cuda")]
#[pyclass(name = "ProfiledDifferentiableSession")]
struct PyProfiledDiffSession {
    inner: ns_inference::ProfiledDifferentiableSession,
}

#[cfg(feature = "cuda")]
#[pymethods]
impl PyProfiledDiffSession {
    /// Create a profiled differentiable GPU session.
    ///
    /// Args:
    ///     model: HistFactoryModel
    ///     signal_sample_name: name of the signal sample in the workspace
    #[new]
    fn new(model: &PyHistFactoryModel, signal_sample_name: &str) -> PyResult<Self> {
        let inner =
            ns_inference::ProfiledDifferentiableSession::new(&model.inner, signal_sample_name)
                .map_err(|e| PyValueError::new_err(format!("{e}")))?;
        Ok(Self { inner })
    }

    /// Compute profiled q₀ and its gradient w.r.t. signal bins.
    ///
    /// Args:
    ///     signal_ptr: int — from torch.Tensor.data_ptr() (CUDA device pointer)
    ///
    /// Returns:
    ///     tuple[float, list[float]] — (q0, grad_signal)
    fn profiled_q0_and_grad(&mut self, signal_ptr: u64) -> PyResult<(f64, Vec<f64>)> {
        self.inner
            .profiled_q0_and_grad(signal_ptr)
            .map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Compute profiled qμ and its gradient w.r.t. signal bins.
    ///
    /// Args:
    ///     mu_test: float — signal strength hypothesis to test
    ///     signal_ptr: int — from torch.Tensor.data_ptr() (CUDA device pointer)
    ///
    /// Returns:
    ///     tuple[float, list[float]] — (qmu, grad_signal)
    fn profiled_qmu_and_grad(
        &mut self,
        mu_test: f64,
        signal_ptr: u64,
    ) -> PyResult<(f64, Vec<f64>)> {
        self.inner
            .profiled_qmu_and_grad(mu_test, signal_ptr)
            .map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Number of signal bins.
    fn signal_n_bins(&self) -> usize {
        self.inner.signal_n_bins()
    }

    /// Number of model parameters.
    fn n_params(&self) -> usize {
        self.inner.n_params()
    }

    /// Default initial parameter values.
    fn parameter_init(&self) -> Vec<f64> {
        self.inner.parameter_init().to_vec()
    }

    /// Compute profiled qμ for multiple mu_test values (sequential, GPU session reuse).
    ///
    /// Args:
    ///     signal_ptr: int — from torch.Tensor.data_ptr() (CUDA device pointer)
    ///     mu_values: list[float] — signal strength hypotheses
    ///
    /// Returns:
    ///     list[tuple[float, list[float]]] — [(qmu, grad_signal), ...]
    fn batch_profiled_qmu(
        &mut self,
        signal_ptr: u64,
        mu_values: Vec<f64>,
    ) -> PyResult<Vec<(f64, Vec<f64>)>> {
        self.inner
            .batch_profiled_qmu(signal_ptr, &mu_values)
            .map_err(|e| PyValueError::new_err(format!("{e}")))
    }
}

// ---------------------------------------------------------------------------
// GpuFlowSession — GPU-accelerated flow PDF NLL reduction (CUDA only)
// ---------------------------------------------------------------------------

#[cfg(feature = "cuda")]
#[pyclass(name = "GpuFlowSession")]
struct PyGpuFlowSession {
    inner: ns_inference::gpu_flow_session::GpuFlowSession,
}

#[cfg(feature = "cuda")]
#[pymethods]
impl PyGpuFlowSession {
    /// Create a GPU flow session for unbinned NLL reduction.
    ///
    /// Args:
    ///     n_events: int — number of events
    ///     n_params: int — number of global parameters
    ///     processes: list[dict] — process descriptors, each with keys:
    ///         - process_index: int
    ///         - base_yield: float
    ///         - yield_param_idx: int | None
    ///         - yield_is_scaled: bool (default False)
    ///     gauss_constraints: list[dict] — Gaussian constraint entries, each with keys:
    ///         - center: float
    ///         - sigma: float (> 0)
    ///         - param_idx: int
    ///     constraint_const: float (default 0.0)
    #[new]
    #[pyo3(signature = (n_events, n_params, processes, gauss_constraints=None, constraint_const=0.0))]
    fn new(
        n_events: usize,
        n_params: usize,
        processes: Vec<pyo3::Bound<'_, pyo3::types::PyDict>>,
        gauss_constraints: Option<Vec<pyo3::Bound<'_, pyo3::types::PyDict>>>,
        constraint_const: f64,
    ) -> PyResult<Self> {
        use ns_compute::unbinned_types::GpuUnbinnedGaussConstraintEntry;
        use ns_inference::gpu_flow_session::{FlowProcessDesc, GpuFlowSessionConfig};

        let procs: Vec<FlowProcessDesc> = processes
            .iter()
            .map(|d| {
                let process_index: usize = d.get_item("process_index")?.unwrap().extract()?;
                let base_yield: f64 = d.get_item("base_yield")?.unwrap().extract()?;
                let yield_param_idx: Option<usize> =
                    d.get_item("yield_param_idx")?.and_then(|v| v.extract().ok());
                let yield_is_scaled: bool = d
                    .get_item("yield_is_scaled")
                    .ok()
                    .and_then(|v| v)
                    .and_then(|v| v.extract().ok())
                    .unwrap_or(false);
                let context_param_indices: Vec<usize> = d
                    .get_item("context_param_indices")
                    .ok()
                    .and_then(|v| v)
                    .and_then(|v| v.extract().ok())
                    .unwrap_or_default();
                Ok(FlowProcessDesc {
                    process_index,
                    base_yield,
                    yield_param_idx,
                    yield_is_scaled,
                    context_param_indices,
                })
            })
            .collect::<PyResult<Vec<_>>>()?;

        let gauss: Vec<GpuUnbinnedGaussConstraintEntry> = gauss_constraints
            .unwrap_or_default()
            .iter()
            .map(|d| {
                let center: f64 = d.get_item("center")?.unwrap().extract()?;
                let sigma: f64 = d.get_item("sigma")?.unwrap().extract()?;
                let param_idx: u32 = d.get_item("param_idx")?.unwrap().extract()?;
                Ok(GpuUnbinnedGaussConstraintEntry {
                    center,
                    inv_width: 1.0 / sigma,
                    param_idx,
                    _pad: 0,
                })
            })
            .collect::<PyResult<Vec<_>>>()?;

        let n_context = procs.first().map(|p| p.context_param_indices.len()).unwrap_or(0);
        let config = GpuFlowSessionConfig {
            processes: procs,
            n_events,
            n_params,
            n_context,
            gauss_constraints: gauss,
            constraint_const,
        };

        let inner = ns_inference::gpu_flow_session::GpuFlowSession::new(config)
            .map_err(|e| PyValueError::new_err(format!("{e}")))?;
        Ok(Self { inner })
    }

    /// Compute NLL from host-side f64 log-prob values.
    ///
    /// Args:
    ///     logp_flat: list[float] — [n_procs × n_events] row-major
    ///     params: list[float] — [n_params] current parameter values
    ///
    /// Returns:
    ///     float — NLL value
    fn nll(&mut self, logp_flat: Vec<f64>, params: Vec<f64>) -> PyResult<f64> {
        self.inner.nll(&logp_flat, &params).map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Compute NLL from a GPU-resident float (f32) log-prob buffer (zero-copy CUDA EP path).
    ///
    /// This is the zero-copy path for ONNX Runtime CUDA Execution Provider:
    /// the log_prob output tensor stays on device, no D2H copy, no f32→f64 conversion.
    ///
    /// Args:
    ///     d_logp_flat_ptr: int — raw CUDA device pointer (from ort I/O binding or
    ///         torch.Tensor.data_ptr()) to float[n_procs × n_events]
    ///     params: list[float] — [n_params] current parameter values
    ///
    /// Returns:
    ///     float — NLL value
    fn nll_device_ptr_f32(&mut self, d_logp_flat_ptr: u64, params: Vec<f64>) -> PyResult<f64> {
        self.inner
            .nll_device_ptr_f32(d_logp_flat_ptr, &params)
            .map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Compute yields from parameters.
    ///
    /// Args:
    ///     params: list[float] — [n_params]
    ///
    /// Returns:
    ///     list[float] — [n_procs] computed yields
    fn compute_yields(&self, params: Vec<f64>) -> Vec<f64> {
        self.inner.compute_yields(&params)
    }

    /// Number of events.
    fn n_events(&self) -> usize {
        self.inner.n_events()
    }

    /// Number of processes.
    fn n_procs(&self) -> usize {
        self.inner.n_procs()
    }

    /// Number of parameters.
    fn n_params(&self) -> usize {
        self.inner.n_params()
    }
}

// ---------------------------------------------------------------------------
// MetalProfiledDifferentiableSession — profiled q₀/qμ on Apple Silicon (Metal)
// ---------------------------------------------------------------------------

#[cfg(feature = "metal")]
#[pyclass(name = "MetalProfiledDifferentiableSession")]
struct PyMetalProfiledDiffSession {
    inner: ns_inference::MetalProfiledDifferentiableSession,
}

#[cfg(feature = "metal")]
#[pymethods]
impl PyMetalProfiledDiffSession {
    /// Create a Metal profiled differentiable GPU session.
    ///
    /// Args:
    ///     model: HistFactoryModel
    ///     signal_sample_name: name of the signal sample in the workspace
    #[new]
    fn new(model: &PyHistFactoryModel, signal_sample_name: &str) -> PyResult<Self> {
        let inner =
            ns_inference::MetalProfiledDifferentiableSession::new(&model.inner, signal_sample_name)
                .map_err(|e| PyValueError::new_err(format!("{e}")))?;
        Ok(Self { inner })
    }

    /// Upload signal histogram from CPU (list or numpy array of f64).
    fn upload_signal(&mut self, signal: Vec<f64>) -> PyResult<()> {
        self.inner.upload_signal(&signal).map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Compute profiled q₀ and its gradient w.r.t. signal bins.
    ///
    /// Signal must be uploaded via `upload_signal()` before calling.
    ///
    /// Returns:
    ///     tuple[float, list[float]] — (q0, grad_signal)
    fn profiled_q0_and_grad(&mut self) -> PyResult<(f64, Vec<f64>)> {
        self.inner.profiled_q0_and_grad().map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Compute profiled qμ and its gradient w.r.t. signal bins.
    ///
    /// Signal must be uploaded via `upload_signal()` before calling.
    ///
    /// Args:
    ///     mu_test: float — signal strength hypothesis to test
    ///
    /// Returns:
    ///     tuple[float, list[float]] — (qmu, grad_signal)
    fn profiled_qmu_and_grad(&mut self, mu_test: f64) -> PyResult<(f64, Vec<f64>)> {
        self.inner.profiled_qmu_and_grad(mu_test).map_err(|e| PyValueError::new_err(format!("{e}")))
    }

    /// Number of signal bins.
    fn signal_n_bins(&self) -> usize {
        self.inner.signal_n_bins()
    }

    /// Number of model parameters.
    fn n_params(&self) -> usize {
        self.inner.n_params()
    }

    /// Default initial parameter values.
    fn parameter_init(&self) -> Vec<f64> {
        self.inner.parameter_init().to_vec()
    }

    /// Compute profiled qμ for multiple mu_test values.
    ///
    /// Signal must be uploaded via `upload_signal()` before calling.
    ///
    /// Args:
    ///     mu_values: list[float] — signal strength hypotheses
    ///
    /// Returns:
    ///     list[tuple[float, list[float]]] — [(qmu, grad_signal), ...]
    fn batch_profiled_qmu(&mut self, mu_values: Vec<f64>) -> PyResult<Vec<(f64, Vec<f64>)>> {
        self.inner.batch_profiled_qmu(&mu_values).map_err(|e| PyValueError::new_err(format!("{e}")))
    }
}

// ---------------------------------------------------------------------------
// Fault-tree Monte Carlo
// ---------------------------------------------------------------------------

/// Run Monte Carlo fault-tree simulation.
///
/// Args:
///     spec: dict with keys "components", "nodes", "top_event".
///     n_scenarios: number of MC scenarios.
///     seed: RNG seed for reproducibility.
///     device: "cpu", "cuda", or "metal".
///     chunk_size: scenarios per batch (0 = backend default: CPU 10_000_000, GPU 1_000_000).
///
/// Returns: dict with p_failure, se, ci_lower, ci_upper, component_importance, etc.
#[pyfunction]
#[pyo3(signature = (spec, n_scenarios, *, seed=42, device="cpu", chunk_size=0))]
fn fault_tree_mc(
    py: Python<'_>,
    spec: &Bound<'_, PyAny>,
    n_scenarios: usize,
    seed: u64,
    device: &str,
    chunk_size: usize,
) -> PyResult<Py<PyAny>> {
    use ns_inference::fault_tree_mc::{
        FailureMode as FM, FaultTreeNode as FTN, FaultTreeSpec, Gate,
    };

    // Parse spec from Python dict.
    let spec_dict = spec.cast::<PyDict>()?;

    // Parse components.
    let comps_list = spec_dict
        .get_item("components")?
        .ok_or_else(|| PyValueError::new_err("spec must have 'components' key"))?;
    let comps_list = comps_list.cast::<PyList>()?;
    let mut components = Vec::new();
    for comp in comps_list.iter() {
        let comp = comp.cast::<PyDict>()?;
        let ctype: String = comp
            .get_item("type")?
            .ok_or_else(|| PyValueError::new_err("component must have 'type'"))?
            .extract()?;
        let mode = match ctype.as_str() {
            "bernoulli" => {
                let p: f64 = comp
                    .get_item("p")?
                    .ok_or_else(|| PyValueError::new_err("bernoulli needs 'p'"))?
                    .extract()?;
                FM::Bernoulli { p }
            }
            "bernoulli_uncertain" => {
                let mu: f64 = comp
                    .get_item("mu")?
                    .ok_or_else(|| PyValueError::new_err("bernoulli_uncertain needs 'mu'"))?
                    .extract()?;
                let sigma: f64 = comp
                    .get_item("sigma")?
                    .ok_or_else(|| PyValueError::new_err("bernoulli_uncertain needs 'sigma'"))?
                    .extract()?;
                FM::BernoulliUncertain { mu, sigma }
            }
            "weibull_mission" => {
                let k: f64 = comp
                    .get_item("k")?
                    .ok_or_else(|| PyValueError::new_err("weibull_mission needs 'k'"))?
                    .extract()?;
                let lambda: f64 = comp
                    .get_item("lambda")?
                    .ok_or_else(|| PyValueError::new_err("weibull_mission needs 'lambda'"))?
                    .extract()?;
                let mission_time: f64 = comp
                    .get_item("mission_time")?
                    .ok_or_else(|| PyValueError::new_err("weibull_mission needs 'mission_time'"))?
                    .extract()?;
                FM::WeibullMission { k, lambda, mission_time }
            }
            other => {
                return Err(PyValueError::new_err(format!("unknown component type: '{other}'")));
            }
        };
        components.push(mode);
    }

    // Parse nodes.
    let nodes_list = spec_dict
        .get_item("nodes")?
        .ok_or_else(|| PyValueError::new_err("spec must have 'nodes' key"))?;
    let nodes_list = nodes_list.cast::<PyList>()?;
    let mut nodes = Vec::new();
    for node in nodes_list.iter() {
        let node = node.cast::<PyDict>()?;
        let ntype: String = node
            .get_item("type")?
            .ok_or_else(|| PyValueError::new_err("node must have 'type'"))?
            .extract()?;
        let ftn = match ntype.as_str() {
            "component" => {
                let idx: usize = node
                    .get_item("index")?
                    .ok_or_else(|| PyValueError::new_err("component node needs 'index'"))?
                    .extract()?;
                FTN::Component(idx)
            }
            "and" | "or" => {
                let children: Vec<usize> = node
                    .get_item("children")?
                    .ok_or_else(|| PyValueError::new_err("gate node needs 'children'"))?
                    .extract()?;
                let gate = if ntype == "and" { Gate::And } else { Gate::Or };
                FTN::Gate { gate, children }
            }
            other => return Err(PyValueError::new_err(format!("unknown node type: '{other}'"))),
        };
        nodes.push(ftn);
    }

    let top_event: usize = spec_dict
        .get_item("top_event")?
        .ok_or_else(|| PyValueError::new_err("spec must have 'top_event' key"))?
        .extract()?;

    let ft_spec = FaultTreeSpec { components, nodes, top_event };

    let result = match device {
        "cpu" => ns_inference::fault_tree_mc_cpu(&ft_spec, n_scenarios, seed, chunk_size)
            .map_err(|e| PyValueError::new_err(format!("{e}")))?,
        #[cfg(feature = "cuda")]
        "cuda" => ns_inference::fault_tree_mc_cuda(&ft_spec, n_scenarios, seed, chunk_size)
            .map_err(|e| PyValueError::new_err(format!("{e}")))?,
        #[cfg(feature = "metal")]
        "metal" => ns_inference::fault_tree_mc_metal(&ft_spec, n_scenarios, seed, chunk_size)
            .map_err(|e| PyValueError::new_err(format!("{e}")))?,
        _ => {
            return Err(PyValueError::new_err(format!(
                "unsupported device: '{device}' (available: cpu{}{})",
                if cfg!(feature = "cuda") { ", cuda" } else { "" },
                if cfg!(feature = "metal") { ", metal" } else { "" },
            )));
        }
    };

    let out = PyDict::new(py);
    out.set_item("n_scenarios", result.n_scenarios)?;
    out.set_item("n_top_failures", result.n_top_failures)?;
    out.set_item("p_failure", result.p_failure)?;
    out.set_item("se", result.se)?;
    out.set_item("ci_lower", result.ci_lower)?;
    out.set_item("ci_upper", result.ci_upper)?;
    out.set_item("wall_time_s", result.wall_time_s)?;
    out.set_item("scenarios_per_sec", result.scenarios_per_sec)?;
    out.set_item("component_importance", result.component_importance)?;

    Ok(out.into_any().unbind())
}

/// Cross-Entropy Importance Sampling for fault-tree MC (all failure modes).
#[pyfunction]
#[pyo3(signature = (spec, *, n_per_level=10_000, elite_fraction=0.01, max_levels=20, q_max=0.99, seed=42))]
fn fault_tree_mc_ce_is(
    py: Python<'_>,
    spec: &Bound<'_, PyAny>,
    n_per_level: usize,
    elite_fraction: f64,
    max_levels: usize,
    q_max: f64,
    seed: u64,
) -> PyResult<Py<PyAny>> {
    use ns_inference::fault_tree_mc::{
        FailureMode as FM, FaultTreeCeIsConfig, FaultTreeNode as FTN, FaultTreeSpec, Gate,
    };

    // Parse spec (same as fault_tree_mc).
    let spec_dict = spec.cast::<PyDict>()?;

    let comps_list = spec_dict
        .get_item("components")?
        .ok_or_else(|| PyValueError::new_err("spec must have 'components' key"))?;
    let comps_list = comps_list.cast::<PyList>()?;
    let mut components = Vec::new();
    for comp in comps_list.iter() {
        let comp = comp.cast::<PyDict>()?;
        let ctype: String = comp
            .get_item("type")?
            .ok_or_else(|| PyValueError::new_err("component must have 'type'"))?
            .extract()?;
        let mode = match ctype.as_str() {
            "bernoulli" => {
                let p: f64 = comp
                    .get_item("p")?
                    .ok_or_else(|| PyValueError::new_err("bernoulli needs 'p'"))?
                    .extract()?;
                FM::Bernoulli { p }
            }
            other => {
                return Err(PyValueError::new_err(format!(
                    "CE-IS only supports 'bernoulli' components, got: '{other}'"
                )));
            }
        };
        components.push(mode);
    }

    let nodes_list = spec_dict
        .get_item("nodes")?
        .ok_or_else(|| PyValueError::new_err("spec must have 'nodes' key"))?;
    let nodes_list = nodes_list.cast::<PyList>()?;
    let mut nodes = Vec::new();
    for node in nodes_list.iter() {
        let node = node.cast::<PyDict>()?;
        let ntype: String = node
            .get_item("type")?
            .ok_or_else(|| PyValueError::new_err("node must have 'type'"))?
            .extract()?;
        let ftn = match ntype.as_str() {
            "component" => {
                let idx: usize = node
                    .get_item("index")?
                    .ok_or_else(|| PyValueError::new_err("component node needs 'index'"))?
                    .extract()?;
                FTN::Component(idx)
            }
            "and" | "or" => {
                let children: Vec<usize> = node
                    .get_item("children")?
                    .ok_or_else(|| PyValueError::new_err("gate node needs 'children'"))?
                    .extract()?;
                let gate = if ntype == "and" { Gate::And } else { Gate::Or };
                FTN::Gate { gate, children }
            }
            other => return Err(PyValueError::new_err(format!("unknown node type: '{other}'"))),
        };
        nodes.push(ftn);
    }

    let top_event: usize = spec_dict
        .get_item("top_event")?
        .ok_or_else(|| PyValueError::new_err("spec must have 'top_event' key"))?
        .extract()?;

    let ft_spec = FaultTreeSpec { components, nodes, top_event };
    let config = FaultTreeCeIsConfig { n_per_level, elite_fraction, max_levels, q_max, seed };

    let result = ns_inference::fault_tree_mc_ce_is(&ft_spec, &config)
        .map_err(|e| PyValueError::new_err(format!("{e}")))?;

    let out = PyDict::new(py);
    out.set_item("p_failure", result.p_failure)?;
    out.set_item("se", result.se)?;
    out.set_item("ci_lower", result.ci_lower)?;
    out.set_item("ci_upper", result.ci_upper)?;
    out.set_item("n_levels", result.n_levels)?;
    out.set_item("n_total_scenarios", result.n_total_scenarios)?;
    out.set_item("final_proposal", result.final_proposal)?;
    out.set_item("coefficient_of_variation", result.coefficient_of_variation)?;
    out.set_item("wall_time_s", result.wall_time_s)?;

    Ok(out.into_any().unbind())
}

/// Profile likelihood CI for any posterior model.
#[pyfunction]
#[pyo3(signature = (model, fit_result, *, param_idx=None, chi2_level=3.841, tol=1e-4))]
fn profile_ci_py(
    py: Python<'_>,
    model: &Bound<'_, PyAny>,
    fit_result: &PyFitResult,
    param_idx: Option<usize>,
    chi2_level: f64,
    tol: f64,
) -> PyResult<Py<PyAny>> {
    let pm = extract_posterior_model(model)?;
    let config = ns_inference::OptimizerConfig::default();

    let mle_params = &fit_result.parameters;
    let mle_nll = fit_result.nll;
    let bounds_all = pm.parameter_bounds();

    let compute_one = |idx: usize| -> PyResult<(usize, f64, f64, f64, usize)> {
        let (lo, hi) = bounds_all[idx];
        let lo = if lo.is_finite() {
            lo
        } else {
            mle_params[idx] - 10.0 * fit_result.uncertainties[idx].abs().max(1.0)
        };
        let hi = if hi.is_finite() {
            hi
        } else {
            mle_params[idx] + 10.0 * fit_result.uncertainties[idx].abs().max(1.0)
        };

        let ci = pm
            .profile_ci_one(mle_params, mle_nll, idx, (lo, hi), chi2_level, tol, &config)
            .map_err(|e| PyValueError::new_err(format!("{e}")))?;
        Ok((ci.param_idx, ci.mle, ci.ci_lower, ci.ci_upper, ci.n_evals))
    };

    if let Some(idx) = param_idx {
        // Single parameter
        let (pidx, mle, lo, hi, ne) = compute_one(idx)?;
        let out = PyDict::new(py);
        out.set_item("param_idx", pidx)?;
        out.set_item("mle", mle)?;
        out.set_item("ci_lower", lo)?;
        out.set_item("ci_upper", hi)?;
        out.set_item("n_evals", ne)?;
        Ok(out.into_any().unbind())
    } else {
        // All parameters
        let n = pm.dim();
        let results = PyList::empty(py);
        for i in 0..n {
            if let Ok((pidx, mle, lo, hi, ne)) = compute_one(i) {
                let d = PyDict::new(py);
                d.set_item("param_idx", pidx)?;
                d.set_item("mle", mle)?;
                d.set_item("ci_lower", lo)?;
                d.set_item("ci_upper", hi)?;
                d.set_item("n_evals", ne)?;
                results.append(d)?;
            }
        }
        Ok(results.into_any().unbind())
    }
}

/// Native Rust visualization renderer.
///
/// Returns bytes in the requested format (svg/pdf/png).
#[cfg(feature = "native-render")]
#[pyfunction]
#[pyo3(signature = (artifact_json, kind, format="svg", config_yaml=None, dpi=None))]
fn render_viz(
    artifact_json: &str,
    kind: &str,
    format: &str,
    config_yaml: Option<&str>,
    dpi: Option<u32>,
) -> PyResult<Vec<u8>> {
    let mut config = if let Some(yaml) = config_yaml {
        ns_viz_render::config::resolve_config(Some(yaml))
            .map_err(|e| pyo3::exceptions::PyValueError::new_err(e.to_string()))?
    } else {
        ns_viz_render::config::VizConfig::default()
    };
    if let Some(d) = dpi {
        config.output.dpi = d;
    }
    ns_viz_render::render_to_bytes(artifact_json, kind, format, &config)
        .map_err(|e| pyo3::exceptions::PyRuntimeError::new_err(e.to_string()))
}

// ---------------------------------------------------------------------------
// Bioequivalence functions.
// ---------------------------------------------------------------------------

fn parse_be_design(design: &str) -> PyResult<RustBeDesign> {
    match design {
        "2x2" => Ok(RustBeDesign::Crossover2x2),
        "3x3" => Ok(RustBeDesign::Crossover3x3),
        "parallel" => Ok(RustBeDesign::Parallel),
        _ => Err(PyValueError::new_err("design must be '2x2', '3x3', or 'parallel'")),
    }
}

/// Average bioequivalence (TOST) analysis from paired log-scale observations.
///
/// Constructs a 2x2 crossover BeData from paired test/reference observations
/// and runs the Two One-Sided Tests (TOST) procedure.
#[pyfunction]
#[pyo3(signature = (test_values, ref_values, *, alpha=0.05, limits=(0.80, 1.25), design="2x2"))]
fn average_be(
    py: Python<'_>,
    test_values: Vec<f64>,
    ref_values: Vec<f64>,
    alpha: f64,
    limits: (f64, f64),
    design: &str,
) -> PyResult<Py<PyAny>> {
    let d = parse_be_design(design)?;
    let n = test_values.len();
    if n != ref_values.len() {
        return Err(PyValueError::new_err("test_values and ref_values must have the same length"));
    }
    let config = RustBeConfig { alpha, limits, design: d };
    // Construct BeData: each subject has a Test and Reference observation.
    let mut subject_id = Vec::with_capacity(2 * n);
    let mut sequence = Vec::with_capacity(2 * n);
    let mut period = Vec::with_capacity(2 * n);
    let mut treatment = Vec::with_capacity(2 * n);
    let mut log_value = Vec::with_capacity(2 * n);
    for i in 0..n {
        let seq = if i < n / 2 { 0 } else { 1 };
        // Period 1 observation.
        subject_id.push(i + 1);
        sequence.push(seq);
        period.push(1);
        if seq == 0 {
            treatment.push(0); // R first
            log_value.push(ref_values[i]);
        } else {
            treatment.push(1); // T first
            log_value.push(test_values[i]);
        }
        // Period 2 observation.
        subject_id.push(i + 1);
        sequence.push(seq);
        period.push(2);
        if seq == 0 {
            treatment.push(1); // T second
            log_value.push(test_values[i]);
        } else {
            treatment.push(0); // R second
            log_value.push(ref_values[i]);
        }
    }
    let data = RustBeData { subject_id, sequence, period, treatment, log_value };
    let result =
        rust_average_be(&data, &config).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let dict = PyDict::new(py);
    dict.set_item("geometric_mean_ratio", result.geometric_mean_ratio)?;
    dict.set_item("ci_lower", result.ci_lower)?;
    dict.set_item("ci_upper", result.ci_upper)?;
    dict.set_item("pe_log", result.pe_log)?;
    dict.set_item("se_log", result.se_log)?;
    dict.set_item("df", result.df)?;
    dict.set_item("t_lower", result.t_lower)?;
    dict.set_item("t_upper", result.t_upper)?;
    dict.set_item("p_lower", result.p_lower)?;
    dict.set_item("p_upper", result.p_upper)?;
    dict.set_item("conclusion", format!("{:?}", result.conclusion))?;
    dict.into_py_any(py)
}

/// Compute power of a bioequivalence study for a given total sample size.
#[pyfunction]
#[pyo3(name = "be_power", signature = (n_total, *, cv=0.30, gmr=0.95, alpha=0.05, design="2x2"))]
fn be_power_py(
    _py: Python<'_>,
    n_total: usize,
    cv: f64,
    gmr: f64,
    alpha: f64,
    design: &str,
) -> PyResult<f64> {
    let d = parse_be_design(design)?;
    let config =
        RustBePowerConfig { alpha, target_power: 0.80, cv, gmr, limits: (0.80, 1.25), design: d };
    rust_be_power(n_total, &config).map_err(|e| PyValueError::new_err(e.to_string()))
}

/// Compute minimum sample size to achieve target power for a bioequivalence study.
#[pyfunction]
#[pyo3(name = "be_sample_size", signature = (*, cv=0.30, gmr=0.95, target_power=0.80, alpha=0.05, design="2x2"))]
fn be_sample_size_py(
    py: Python<'_>,
    cv: f64,
    gmr: f64,
    target_power: f64,
    alpha: f64,
    design: &str,
) -> PyResult<Py<PyAny>> {
    let d = parse_be_design(design)?;
    let config =
        RustBePowerConfig { alpha, target_power, cv, gmr, limits: (0.80, 1.25), design: d };
    let result = rust_be_sample_size(&config).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let dict = PyDict::new(py);
    dict.set_item("n_per_sequence", result.n_per_sequence)?;
    dict.set_item("n_total", result.n_total)?;
    dict.set_item("achieved_power", result.achieved_power)?;
    dict.into_py_any(py)
}

// ---------------------------------------------------------------------------
// Trial simulation functions.
// ---------------------------------------------------------------------------

fn parse_pk_model_type(s: &str) -> PyResult<RustPkModelType> {
    match s {
        "1cpt_oral" => Ok(RustPkModelType::OneCompartmentOral),
        "2cpt_iv" => Ok(RustPkModelType::TwoCompartmentIv),
        "2cpt_oral" => Ok(RustPkModelType::TwoCompartmentOral),
        _ => Err(PyValueError::new_err("pk_model must be '1cpt_oral', '2cpt_iv', or '2cpt_oral'")),
    }
}

fn parse_trial_error_model(s: &str) -> PyResult<RustTrialErrorModelType> {
    match s {
        "additive" => Ok(RustTrialErrorModelType::Additive),
        "proportional" => Ok(RustTrialErrorModelType::Proportional),
        _ => Err(PyValueError::new_err("error_model must be 'additive' or 'proportional'")),
    }
}

/// Simulate a single clinical trial with population PK parameters.
#[pyfunction]
#[pyo3(name = "simulate_trial", signature = (*, n_subjects, dose, obs_times, pk_model="1cpt_oral", theta, omega, sigma, error_model="proportional", bioavailability=1.0, seed=42))]
fn simulate_trial_py(
    py: Python<'_>,
    n_subjects: usize,
    dose: f64,
    obs_times: Vec<f64>,
    pk_model: &str,
    theta: Vec<f64>,
    omega: Vec<f64>,
    sigma: f64,
    error_model: &str,
    bioavailability: f64,
    seed: u64,
) -> PyResult<Py<PyAny>> {
    let pk = parse_pk_model_type(pk_model)?;
    let em = parse_trial_error_model(error_model)?;
    let route = if matches!(pk, RustPkModelType::TwoCompartmentIv) {
        RustDoseRoute::IvBolus
    } else {
        RustDoseRoute::Oral { bioavailability }
    };
    let config = RustTrialConfig {
        n_subjects,
        dosing: vec![RustDoseEvent { time: 0.0, amount: dose, route }],
        obs_times,
        pk_model: pk,
        population: RustPopulationPkParams {
            theta,
            omega,
            sigma,
            error_model: em,
            omega_correlation: None,
        },
        seed,
    };
    let result = rust_simulate_trial(&config).map_err(|e| PyValueError::new_err(e.to_string()))?;
    let dict = PyDict::new(py);
    dict.set_item("concentrations", result.concentrations)?;
    dict.set_item("individual_params", result.individual_params)?;
    dict.set_item("auc", result.endpoints.auc)?;
    dict.set_item("cmax", result.endpoints.cmax)?;
    dict.set_item("tmax", result.endpoints.tmax)?;
    dict.set_item("ctrough", result.endpoints.ctrough)?;
    dict.into_py_any(py)
}

#[pyfunction]
#[pyo3(name = "map_estimate", signature = (model, priors, *, max_iter=1000, tol=1e-8, compute_se=true, init=None))]
fn map_estimate_py<'py>(
    py: Python<'py>,
    model: &Bound<'py, PyAny>,
    priors: Vec<(f64, f64)>,
    max_iter: usize,
    tol: f64,
    compute_se: bool,
    init: Option<Vec<f64>>,
) -> PyResult<Py<PyAny>> {
    let posterior_model = extract_posterior_model(model)?;
    let prior_vec: Vec<RustPrior> =
        priors.into_iter().map(|(center, width)| RustPrior::Normal { center, width }).collect();
    let config = RustMapConfig { max_iter, tol, m: 20, compute_se, compute_shrinkage: true, init };
    let result = py
        .detach(move || posterior_model.run_map_estimate(prior_vec, &config))
        .map_err(|e| PyValueError::new_err(format!("MAP estimation failed: {}", e)))?;
    let dict = PyDict::new(py);
    dict.set_item("params", result.params)?;
    dict.set_item("se", result.se)?;
    dict.set_item("nll_posterior", result.nll_posterior)?;
    dict.set_item("nll", result.nll)?;
    dict.set_item("log_prior", result.log_prior)?;
    dict.set_item("n_iter", result.n_iter)?;
    dict.set_item("converged", result.converged)?;
    dict.set_item("param_names", result.param_names)?;
    dict.set_item("shrinkage", result.shrinkage)?;
    dict.into_py_any(py)
}

/// Python submodule: nextstat._core
#[pymodule]
fn _core(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add("__version__", ns_core::VERSION)?;

    // Convenience functions (pyhf-style API).
    m.add_function(wrap_pyfunction!(from_pyhf, m)?)?;
    m.add_function(wrap_pyfunction!(workspace_audit, m)?)?;
    m.add_function(wrap_pyfunction!(workspace_combine, m)?)?;
    m.add_function(wrap_pyfunction!(workspace_prune, m)?)?;
    m.add_function(wrap_pyfunction!(workspace_rename, m)?)?;
    m.add_function(wrap_pyfunction!(workspace_sorted, m)?)?;
    m.add_function(wrap_pyfunction!(workspace_digest, m)?)?;
    m.add_function(wrap_pyfunction!(workspace_to_xml, m)?)?;
    m.add_function(wrap_pyfunction!(simplemodel_uncorrelated, m)?)?;
    m.add_function(wrap_pyfunction!(simplemodel_correlated, m)?)?;
    m.add_function(wrap_pyfunction!(apply_patchset, m)?)?;
    m.add_function(wrap_pyfunction!(from_histfactory, m)?)?;
    m.add_function(wrap_pyfunction!(histfactory_bin_edges_by_channel, m)?)?;
    m.add_function(wrap_pyfunction!(read_root_histogram, m)?)?;
    m.add_function(wrap_pyfunction!(fit, m)?)?;
    m.add_function(wrap_pyfunction!(map_fit, m)?)?;
    m.add_function(wrap_pyfunction!(fit_batch, m)?)?;
    m.add_function(wrap_pyfunction!(fit_toys, m)?)?;
    m.add_function(wrap_pyfunction!(set_eval_mode, m)?)?;
    m.add_function(wrap_pyfunction!(set_threads, m)?)?;
    m.add_function(wrap_pyfunction!(get_eval_mode, m)?)?;
    m.add_function(wrap_pyfunction!(has_accelerate, m)?)?;
    m.add_function(wrap_pyfunction!(has_cuda, m)?)?;
    m.add_function(wrap_pyfunction!(has_metal, m)?)?;
    m.add_function(wrap_pyfunction!(asimov_data, m)?)?;
    m.add_function(wrap_pyfunction!(poisson_toys, m)?)?;
    m.add_function(wrap_pyfunction!(ranking, m)?)?;
    m.add_function(wrap_pyfunction!(lsoda, m)?)?;
    m.add_function(wrap_pyfunction!(lsoda_callback, m)?)?;
    m.add_function(wrap_pyfunction!(forward_sensitivity_solve, m)?)?;
    m.add_function(wrap_pyfunction!(forward_sensitivity_solve_callback, m)?)?;
    m.add_function(wrap_pyfunction!(rk4_linear, m)?)?;
    m.add_function(wrap_pyfunction!(rk4_linear_dde, m)?)?;
    m.add_function(wrap_pyfunction!(ols_fit, m)?)?;
    m.add_function(wrap_pyfunction!(hypotest, m)?)?;
    m.add_function(wrap_pyfunction!(hypotest_toys, m)?)?;
    m.add_function(wrap_pyfunction!(profile_scan, m)?)?;
    m.add_function(wrap_pyfunction!(upper_limit, m)?)?;
    m.add_function(wrap_pyfunction!(upper_limits, m)?)?;
    m.add_function(wrap_pyfunction!(sample, m)?)?;
    m.add_function(wrap_pyfunction!(sample_mams_py, m)?)?;
    #[cfg(any(feature = "cuda", feature = "metal"))]
    m.add_function(wrap_pyfunction!(sample_laps_py, m)?)?;
    #[cfg(feature = "cuda")]
    m.add_class::<PyRawCudaModel>()?;
    m.add_function(wrap_pyfunction!(cls_curve, m)?)?;
    m.add_function(wrap_pyfunction!(kalman_filter, m)?)?;
    m.add_function(wrap_pyfunction!(kalman_smooth, m)?)?;
    m.add_function(wrap_pyfunction!(kalman_em, m)?)?;
    m.add_function(wrap_pyfunction!(kalman_forecast, m)?)?;
    m.add_function(wrap_pyfunction!(kalman_simulate, m)?)?;
    m.add_function(wrap_pyfunction!(garch11_fit, m)?)?;
    m.add_function(wrap_pyfunction!(sv_logchi2_fit, m)?)?;
    m.add_function(wrap_pyfunction!(egarch11_fit, m)?)?;
    m.add_function(wrap_pyfunction!(gjr_garch11_fit, m)?)?;
    m.add_function(wrap_pyfunction!(emax_predict, m)?)?;
    m.add_function(wrap_pyfunction!(emax_nll, m)?)?;
    m.add_function(wrap_pyfunction!(sigmoid_emax_predict, m)?)?;
    m.add_function(wrap_pyfunction!(sigmoid_emax_nll, m)?)?;
    m.add_function(wrap_pyfunction!(idr_simulate, m)?)?;
    m.add_function(wrap_pyfunction!(idr_nll, m)?)?;
    m.add_function(wrap_pyfunction!(cumulative_incidence, m)?)?;
    m.add_function(wrap_pyfunction!(gray_test, m)?)?;
    m.add_function(wrap_pyfunction!(fine_gray_fit, m)?)?;

    // ODE PK models: Transit, Michaelis-Menten, TMDD
    m.add_function(wrap_pyfunction!(ode_pk_solve, m)?)?;
    m.add_function(wrap_pyfunction!(ode_pk_nll_py, m)?)?;

    // Econometrics & Causal Inference
    m.add_function(wrap_pyfunction!(panel_fe, m)?)?;
    m.add_function(wrap_pyfunction!(did, m)?)?;
    m.add_function(wrap_pyfunction!(event_study, m)?)?;
    m.add_function(wrap_pyfunction!(iv_2sls, m)?)?;
    m.add_function(wrap_pyfunction!(aipw_ate, m)?)?;
    m.add_function(wrap_pyfunction!(rosenbaum_bounds, m)?)?;

    // Pharmacometrics: Population PK
    m.add_function(wrap_pyfunction!(nlme_foce, m)?)?;
    m.add_function(wrap_pyfunction!(nlme_saem, m)?)?;
    m.add_function(wrap_pyfunction!(bootstrap_nlme, m)?)?;
    m.add_function(wrap_pyfunction!(pk_vpc, m)?)?;
    m.add_function(wrap_pyfunction!(pk_gof, m)?)?;
    m.add_function(wrap_pyfunction!(pk_npde, m)?)?;
    m.add_function(wrap_pyfunction!(read_nonmem, m)?)?;
    m.add_function(wrap_pyfunction!(read_xpt, m)?)?;
    m.add_function(wrap_pyfunction!(write_xpt, m)?)?;
    m.add_function(wrap_pyfunction!(xpt_to_nonmem, m)?)?;
    m.add_function(wrap_pyfunction!(scm, m)?)?;

    // Survival: Kaplan-Meier + Log-rank
    m.add_function(wrap_pyfunction!(kaplan_meier, m)?)?;
    m.add_function(wrap_pyfunction!(log_rank_test, m)?)?;

    // Churn / Subscription vertical
    m.add_function(wrap_pyfunction!(churn_generate_data, m)?)?;
    m.add_function(wrap_pyfunction!(churn_retention, m)?)?;
    m.add_function(wrap_pyfunction!(churn_risk_model, m)?)?;
    m.add_function(wrap_pyfunction!(churn_uplift, m)?)?;
    m.add_function(wrap_pyfunction!(churn_diagnostics, m)?)?;
    m.add_function(wrap_pyfunction!(churn_cohort_matrix, m)?)?;
    m.add_function(wrap_pyfunction!(churn_compare, m)?)?;
    m.add_function(wrap_pyfunction!(churn_uplift_survival, m)?)?;
    m.add_function(wrap_pyfunction!(churn_bootstrap_hr, m)?)?;
    m.add_function(wrap_pyfunction!(churn_ingest, m)?)?;

    // Arrow / Parquet
    m.add_function(wrap_pyfunction!(from_arrow_ipc, m)?)?;
    m.add_function(wrap_pyfunction!(from_parquet, m)?)?;
    m.add_function(wrap_pyfunction!(from_parquet_with_modifiers, m)?)?;
    m.add_function(wrap_pyfunction!(to_arrow_yields_ipc, m)?)?;
    m.add_function(wrap_pyfunction!(to_arrow_params_ipc, m)?)?;

    // Add classes
    m.add_class::<PyHistFactoryModel>()?;
    m.add_class::<PyUnbinnedModel>()?;
    m.add_class::<PyHybridModel>()?;
    m.add_class::<PyPosterior>()?;
    m.add_class::<PyKalmanModel>()?;
    m.add_class::<PyGaussianMeanModel>()?;
    m.add_class::<PyFunnelModel>()?;
    m.add_class::<PyFunnelNcpModel>()?;
    m.add_class::<PyStdNormalModel>()?;
    m.add_class::<PyLinearRegressionModel>()?;
    m.add_class::<PyLogisticRegressionModel>()?;
    m.add_class::<PyOrderedLogitModel>()?;
    m.add_class::<PyOrderedProbitModel>()?;
    m.add_class::<PyPoissonRegressionModel>()?;
    m.add_class::<PyNegativeBinomialRegressionModel>()?;
    m.add_class::<PyGammaRegressionModel>()?;
    m.add_class::<PyTweedieRegressionModel>()?;
    m.add_class::<PyGevModel>()?;
    m.add_class::<PyGpdModel>()?;
    m.add_class::<PyEightSchoolsModel>()?;
    m.add_wrapped(wrap_pyfunction!(meta_fixed))?;
    m.add_wrapped(wrap_pyfunction!(meta_random))?;
    m.add_wrapped(wrap_pyfunction!(chain_ladder))?;
    m.add_wrapped(wrap_pyfunction!(mack_chain_ladder))?;
    m.add_class::<PyComposedGlmModel>()?;
    m.add_class::<PyLmmMarginalModel>()?;
    m.add_class::<PyExponentialSurvivalModel>()?;
    m.add_class::<PyWeibullSurvivalModel>()?;
    m.add_class::<PyLogNormalAftModel>()?;
    m.add_class::<PyCoxPhModel>()?;
    m.add_class::<PyIntervalCensoredWeibullModel>()?;
    m.add_class::<PyIntervalCensoredWeibullAftModel>()?;
    m.add_class::<PyIntervalCensoredExponentialModel>()?;
    m.add_class::<PyIntervalCensoredLogNormalModel>()?;
    m.add_class::<PyOneCompartmentOralPkModel>()?;
    m.add_class::<PyOneCompartmentOralPkNlmeModel>()?;
    m.add_class::<PyTwoCompartmentIvPkModel>()?;
    m.add_class::<PyTwoCompartmentOralPkModel>()?;
    m.add_class::<PyThreeCompartmentIvPkModel>()?;
    m.add_class::<PyThreeCompartmentOralPkModel>()?;
    m.add_class::<PyMaximumLikelihoodEstimator>()?;
    m.add_class::<PyFitResult>()?;
    m.add_class::<PyFitMinimumResult>()?;

    // Neural PDFs (FlowPdf + DcrSurrogate, neural only)
    #[cfg(feature = "neural")]
    m.add_class::<PyFlowPdf>()?;
    #[cfg(feature = "neural")]
    m.add_class::<PyDcrSurrogate>()?;

    // DifferentiableSession (CUDA only)
    #[cfg(feature = "cuda")]
    m.add_class::<PyDiffSession>()?;
    #[cfg(feature = "cuda")]
    m.add_class::<PyProfiledDiffSession>()?;
    // GpuFlowSession (CUDA only)
    #[cfg(feature = "cuda")]
    m.add_class::<PyGpuFlowSession>()?;
    // MetalProfiledDifferentiableSession (Metal only)
    #[cfg(feature = "metal")]
    m.add_class::<PyMetalProfiledDiffSession>()?;

    m.add_wrapped(wrap_pyfunction!(fault_tree_mc))?;
    m.add_wrapped(wrap_pyfunction!(fault_tree_mc_ce_is))?;
    m.add_function(wrap_pyfunction!(profile_ci_py, m)?)?;
    m.add_function(wrap_pyfunction!(average_be, m)?)?;
    m.add_function(wrap_pyfunction!(be_power_py, m)?)?;
    m.add_function(wrap_pyfunction!(be_sample_size_py, m)?)?;
    m.add_function(wrap_pyfunction!(simulate_trial_py, m)?)?;
    m.add_function(wrap_pyfunction!(map_estimate_py, m)?)?;

    // Native Rust visualization renderer
    #[cfg(feature = "native-render")]
    m.add_function(wrap_pyfunction!(render_viz, m)?)?;

    // Back-compat aliases used in plans/docs.
    let model_cls = m.getattr("HistFactoryModel")?;
    m.add("PyModel", model_cls)?;
    let fit_cls = m.getattr("FitResult")?;
    m.add("PyFitResult", fit_cls)?;
    let fit_min_cls = m.getattr("FitMinimumResult")?;
    m.add("PyFitMinimumResult", fit_min_cls)?;

    Ok(())
}
