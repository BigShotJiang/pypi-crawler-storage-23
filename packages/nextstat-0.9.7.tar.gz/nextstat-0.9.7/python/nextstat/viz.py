"""Visualization helpers (plots).

This module focuses on producing figures from plot-friendly JSON-like artifacts.

Requires matplotlib (install via `pip install nextstat[viz]` once the extra exists,
or just `pip install matplotlib`).
"""

from __future__ import annotations

from typing import Any, Mapping, Optional, Sequence


def cls_curve(model, scan: Sequence[float], *, alpha: float = 0.05, data: Optional[list[float]] = None):
    """Compute CLs curve + expected bands artifact over a scan grid."""
    from . import _core

    return _core.cls_curve(model, list(scan), alpha=alpha, data=data)


def profile_curve(model, mu_values: Sequence[float], *, data: Optional[list[float]] = None):
    """Compute profile likelihood scan artifact over POI values."""
    from . import _core

    return _core.profile_scan(model, list(mu_values), data=data, return_curve=True)

def ranking(model):
    """Compute nuisance-parameter ranking (impact on POI)."""
    from . import _core

    return _core.ranking(model)


def _ranking_arrays_from_entries(entries: Sequence[Mapping[str, Any]]):
    """Convert ranking entries into plot-friendly arrays (no dict-per-entry)."""
    names: list[str] = []
    delta_mu_up: list[float] = []
    delta_mu_down: list[float] = []
    pull: list[float] = []
    constraint: list[float] = []

    for e in entries:
        names.append(str(e["name"]))
        delta_mu_up.append(float(e["delta_mu_up"]))
        delta_mu_down.append(float(e["delta_mu_down"]))
        pull.append(float(e["pull"]))
        constraint.append(float(e["constraint"]))

    return {
        "names": names,
        "delta_mu_up": delta_mu_up,
        "delta_mu_down": delta_mu_down,
        "pull": pull,
        "constraint": constraint,
    }


def ranking_artifact(model, *, top_n: Optional[int] = None) -> Mapping[str, Any]:
    """Compute nuisance-parameter ranking artifact (impact on POI).

    Returns a dict with:
    - entries: list of {name, delta_mu_up, delta_mu_down, pull, constraint}
    - n_total: total number of entries (after internal fit failures are dropped)
    - n_returned: number of entries returned (after `top_n`)
    """
    from . import _core

    entries = list(_core.ranking(model))
    n_total = len(entries)

    if top_n is not None:
        n = int(top_n)
        if n < 0:
            raise ValueError("top_n must be >= 0")
        entries = entries[:n]

    return {"entries": entries, "n_total": n_total, "n_returned": len(entries)}

def ranking_arrays(artifact_or_entries: Mapping[str, Any] | Sequence[Mapping[str, Any]]) -> Mapping[str, Any]:
    """Return plot-friendly ranking arrays.

    Accepts either:
    - a list of entry dicts (as returned by `nextstat.ranking(...)`), or
    - a dict from `ranking_artifact(...)` (must contain `entries`), or
    - a dict that already contains `names`/`delta_mu_up`/etc (returned unchanged).
    """
    if isinstance(artifact_or_entries, (list, tuple)):
        return _ranking_arrays_from_entries(artifact_or_entries)

    artifact = dict(artifact_or_entries)
    if "entries" in artifact:
        return _ranking_arrays_from_entries(list(artifact["entries"]))
    if "names" in artifact and "delta_mu_up" in artifact and "delta_mu_down" in artifact:
        return artifact
    raise ValueError("unsupported ranking input: expected entries list, ranking_artifact dict, or arrays dict")


def _require_matplotlib():
    try:
        import matplotlib.pyplot as plt  # noqa: F401
    except Exception as e:  # pragma: no cover
        raise ImportError("Missing dependency: matplotlib. Install via `pip install matplotlib`.") from e


def _base_name(s: str) -> str:
    return str(s).split("[", 1)[0]


def corr_arrays(artifact: Mapping[str, Any]) -> Mapping[str, Any]:
    """Return plot-friendly arrays for a correlation artifact.

    Accepts:
    - `trex_report_corr_v0` artifact dict (must contain `parameter_names` and `corr`), or
    - a dict already containing `parameter_names` and `corr`.
    """
    names = artifact.get("parameter_names")
    corr = artifact.get("corr")
    if not (isinstance(names, list) and isinstance(corr, list)):
        raise ValueError("corr_arrays expects a dict with `parameter_names` (list) and `corr` (2D list)")
    return {"parameter_names": [str(x) for x in names], "corr": corr}


def corr_subset(
    artifact: Mapping[str, Any],
    *,
    include: Optional[str] = None,
    exclude: Optional[str] = None,
    top_n: Optional[int] = None,
    order: str = "input",
) -> Mapping[str, Any]:
    """Return a filtered/re-ordered correlation artifact view (numbers unchanged).

    This is intended for publication plots where showing the full NxN matrix is unreadable.

    Parameters
    - include/exclude: regex filters applied to parameter names (in that order).
    - top_n: keep the top-N parameters by maximum absolute off-diagonal correlation.
    - order:
      - `"input"`: keep input ordering after filtering
      - `"max_abs_corr"`: order by max |corr(i,j)| (tie-break by name)
      - `"group_base"`: order by base name then full name (helps block structure)
    """
    import re

    arrays = corr_arrays(artifact)
    names = list(arrays["parameter_names"])
    corr = arrays["corr"]

    n = len(names)
    if not (isinstance(corr, list) and len(corr) == n and all(isinstance(r, list) and len(r) == n for r in corr)):
        raise ValueError("corr matrix must be square and aligned with parameter_names")

    keep: list[int] = list(range(n))
    if include:
        rx = re.compile(str(include))
        keep = [i for i in keep if rx.search(names[i])]
    if exclude:
        rx = re.compile(str(exclude))
        keep = [i for i in keep if not rx.search(names[i])]

    order = str(order)
    if top_n is not None:
        k = int(top_n)
        if k < 0:
            raise ValueError("top_n must be >= 0")
        if k == 0:
            keep = []
        else:
            scores: list[tuple[float, str, int]] = []
            keep_set = set(keep)
            for i in keep:
                best = 0.0
                for j in keep:
                    if i == j:
                        continue
                    v = corr[i][j]
                    if isinstance(v, (int, float)):
                        best = max(best, abs(float(v)))
                scores.append((best, names[i], i))
            scores.sort(key=lambda t: (-t[0], t[1]))
            keep = [i for (_s, _name, i) in scores[: min(k, len(scores))] if i in keep_set]
            # `max_abs_corr` implies ranked ordering.
            if order == "input":
                order = "max_abs_corr"

    if order == "max_abs_corr":
        scores2: list[tuple[float, str, int]] = []
        for i in keep:
            best = 0.0
            for j in keep:
                if i == j:
                    continue
                v = corr[i][j]
                if isinstance(v, (int, float)):
                    best = max(best, abs(float(v)))
            scores2.append((best, names[i], i))
        scores2.sort(key=lambda t: (-t[0], t[1]))
        keep = [i for (_s, _name, i) in scores2]
    elif order == "group_base":
        keep = sorted(keep, key=lambda i: (_base_name(names[i]), names[i]))
    elif order != "input":
        raise ValueError("order must be one of: 'input', 'max_abs_corr', 'group_base'")

    out_names = [names[i] for i in keep]
    out_corr = [[float(corr[i][j]) for j in keep] for i in keep]
    return {"parameter_names": out_names, "corr": out_corr}


def _nsigma_index(nsigma_order: Sequence[int] | None, sigma: int) -> Optional[int]:
    if nsigma_order is None:
        return None
    try:
        return list(nsigma_order).index(int(sigma))
    except Exception:
        return None


def plot_cls_curve(
    artifact: Mapping[str, Any],
    *,
    ax=None,
    show_expected: bool = True,
    show_bands: bool = True,
    show_observed: bool = True,
    show_limits: bool = True,
    title: Optional[str] = None,
):
    """Plot CLs(mu) with Brazil bands from a `cls_curve` artifact dict."""
    _require_matplotlib()
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots(figsize=(7.2, 4.2))

    points = artifact.get("points") or []
    mu = artifact.get("mu_values")
    cls_obs = artifact.get("cls_obs")
    cls_exp = artifact.get("cls_exp")
    nsigma_order = artifact.get("nsigma_order")

    if not (isinstance(mu, list) and isinstance(cls_obs, list)):
        mu = [float(p["mu"]) for p in points]
        cls_obs = [float(p["cls"]) for p in points]

    mu = [float(x) for x in (mu or [])]
    cls_obs = [float(x) for x in (cls_obs or [])]

    exp_p2 = exp_p1 = exp_0 = exp_m1 = exp_m2 = None
    if isinstance(cls_exp, list) and mu:
        i2 = _nsigma_index(nsigma_order, 2)
        i1 = _nsigma_index(nsigma_order, 1)
        i0 = _nsigma_index(nsigma_order, 0)
        im1 = _nsigma_index(nsigma_order, -1)
        im2 = _nsigma_index(nsigma_order, -2)
        if None not in (i2, i1, i0, im1, im2):
            try:
                exp_p2 = [float(x) for x in cls_exp[i2]]  # type: ignore[index]
                exp_p1 = [float(x) for x in cls_exp[i1]]  # type: ignore[index]
                exp_0 = [float(x) for x in cls_exp[i0]]  # type: ignore[index]
                exp_m1 = [float(x) for x in cls_exp[im1]]  # type: ignore[index]
                exp_m2 = [float(x) for x in cls_exp[im2]]  # type: ignore[index]
            except Exception:
                exp_p2 = exp_p1 = exp_0 = exp_m1 = exp_m2 = None

    if exp_0 is None and points:
        exp = [p.get("expected") for p in points]
        if all(isinstance(e, (list, tuple)) and len(e) >= 5 for e in exp):
            # Legacy/default order is [2, 1, 0, -1, -2]
            exp_p2 = [float(e[0]) for e in exp]  # type: ignore[index]
            exp_p1 = [float(e[1]) for e in exp]  # type: ignore[index]
            exp_0 = [float(e[2]) for e in exp]  # type: ignore[index]
            exp_m1 = [float(e[3]) for e in exp]  # type: ignore[index]
            exp_m2 = [float(e[4]) for e in exp]  # type: ignore[index]

    if show_bands and mu and exp_m2 is not None and exp_p2 is not None:
        ax.fill_between(mu, exp_m2, exp_p2, color="#F2D95C", alpha=0.55, label="Expected ±2σ")
    if show_bands and mu and exp_m1 is not None and exp_p1 is not None:
        ax.fill_between(mu, exp_m1, exp_p1, color="#7BD389", alpha=0.65, label="Expected ±1σ")

    if show_expected and mu and exp_0 is not None:
        ax.plot(mu, exp_0, color="#1D4ED8", lw=2.0, ls="--", label="Expected (median)")

    if show_observed and mu:
        ax.plot(mu, cls_obs, color="#111827", lw=2.0, label="Observed")

    alpha = float(artifact.get("alpha", 0.05))
    ax.axhline(alpha, color="#6B7280", lw=1.25, ls=":", label=f"alpha={alpha:g}")

    if show_limits:
        try:
            obs_lim = float(artifact.get("obs_limit"))
            ax.axvline(obs_lim, color="#111827", lw=1.25, ls=":", label="Obs. limit")
        except Exception:
            pass
        try:
            exp_lims = artifact.get("exp_limits")
            if exp_lims is not None:
                exp_med = float(exp_lims[2])
                ax.axvline(exp_med, color="#1D4ED8", lw=1.25, ls=":", label="Exp. limit (median)")
        except Exception:
            pass

    ax.set_xlabel("mu")
    ax.set_ylabel("CLs")
    ax.set_ylim(0.0, 1.05)
    ax.grid(True, alpha=0.25)
    if title:
        ax.set_title(title)
    ax.legend(frameon=False, ncol=2)
    return ax


def plot_brazil_limits(
    artifact: Mapping[str, Any],
    *,
    ax=None,
    title: Optional[str] = None,
    show_observed: bool = True,
    show_expected: bool = True,
    show_bands: bool = True,
):
    """Plot a standard 1D Brazil band for the upper limit from a `cls_curve` artifact.

    Uses `obs_limit`, `exp_limits`, and `nsigma_order` (if present).
    """
    _require_matplotlib()
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots(figsize=(7.2, 1.8))

    nsigma_order = artifact.get("nsigma_order")
    exp_limits = artifact.get("exp_limits")
    obs_limit = artifact.get("obs_limit")

    y0 = 0.0
    ax.set_yticks([])
    ax.set_ylim(-0.6, 0.6)

    if isinstance(exp_limits, (list, tuple)) and len(exp_limits) >= 5:
        i2 = _nsigma_index(nsigma_order, 2) or 0
        i1 = _nsigma_index(nsigma_order, 1) or 1
        i0 = _nsigma_index(nsigma_order, 0) or 2
        im1 = _nsigma_index(nsigma_order, -1) or 3
        im2 = _nsigma_index(nsigma_order, -2) or 4
        try:
            p2 = float(exp_limits[i2])
            p1 = float(exp_limits[i1])
            med = float(exp_limits[i0])
            m1 = float(exp_limits[im1])
            m2 = float(exp_limits[im2])
        except Exception:
            p2 = p1 = med = m1 = m2 = None  # type: ignore[assignment]

        if show_bands and None not in (m2, p2):
            ax.fill_betweenx([y0 - 0.2, y0 + 0.2], m2, p2, color="#F2D95C", alpha=0.55, label="Expected ±2σ")
        if show_bands and None not in (m1, p1):
            ax.fill_betweenx([y0 - 0.2, y0 + 0.2], m1, p1, color="#7BD389", alpha=0.65, label="Expected ±1σ")
        if show_expected and med is not None:
            ax.axvline(med, color="#1D4ED8", lw=2.0, ls="--", label="Expected (median)")

    if show_observed:
        try:
            ax.axvline(float(obs_limit), color="#111827", lw=2.0, label="Observed")
        except Exception:
            pass

    ax.set_xlabel("mu_up")
    ax.grid(True, axis="x", alpha=0.25)
    if title:
        ax.set_title(title)
    ax.legend(frameon=False, ncol=2)
    return ax


def plot_profile_curve(
    artifact: Mapping[str, Any],
    *,
    ax=None,
    y: str = "q_mu",
    title: Optional[str] = None,
):
    """Plot a profile scan series from a `profile_curve` artifact dict.

    Parameters
    - y: `"q_mu"` or `"twice_delta_nll"`
    """
    _require_matplotlib()
    import matplotlib.pyplot as plt

    if ax is None:
        _, ax = plt.subplots(figsize=(7.2, 4.2))

    points = artifact.get("points") or []
    mu = artifact.get("mu_values")
    if not isinstance(mu, list):
        mu = [float(p["mu"]) for p in points]
    mu = [float(x) for x in (mu or [])]

    y = str(y)
    if y == "q_mu":
        series = artifact.get("q_mu_values")
        if not isinstance(series, list):
            series = [float(p["q_mu"]) for p in points]
        label = "q_mu"
    elif y == "twice_delta_nll":
        series = artifact.get("twice_delta_nll")
        if not isinstance(series, list):
            nll_hat = artifact.get("nll_hat")
            if nll_hat is not None and points and all("nll_mu" in p for p in points):
                series = [2.0 * (float(p["nll_mu"]) - float(nll_hat)) for p in points]
            else:
                raise ValueError("artifact is missing twice_delta_nll (and cannot infer from points)")
        label = "2ΔNLL"
    else:
        raise ValueError("y must be one of: 'q_mu', 'twice_delta_nll'")

    series = [float(x) for x in (series or [])]

    ax.plot(mu, series, color="#111827", lw=2.0)

    mu_hat = artifact.get("mu_hat")
    if mu_hat is not None:
        try:
            ax.axvline(float(mu_hat), color="#6B7280", lw=1.25, ls=":")
        except Exception:
            pass

    ax.set_xlabel("mu")
    ax.set_ylabel(label)
    ax.grid(True, alpha=0.25)
    if title:
        ax.set_title(title)
    return ax


def plot_ranking(
    artifact: Mapping[str, Any] | Sequence[Mapping[str, Any]],
    *,
    ax_impact=None,
    ax_pull=None,
    top_n: Optional[int] = None,
    max_nps: Optional[int] = None,
    poi_label: str = "mu",
    title: Optional[str] = None,
):
    """Plot a standard ranking plot (NP impacts + pulls/constraints).

    Input can be:
    - the output of `ranking_artifact(...)`, or
    - a list of ranking entries (dict-like).
    """
    _require_matplotlib()
    import matplotlib.pyplot as plt

    if top_n is None and max_nps is not None:
        top_n = int(max_nps)

    if isinstance(artifact, Mapping) and "entries" in artifact:
        entries = list(artifact.get("entries") or [])
    elif isinstance(artifact, Mapping) and "names" in artifact and "delta_mu_up" in artifact:
        names = list(artifact.get("names") or [])
        d_up = list(artifact.get("delta_mu_up") or [])
        d_dn = list(artifact.get("delta_mu_down") or [])
        pull = list(artifact.get("pull") or [])
        constr = list(artifact.get("constraint") or [])
        n = min(len(names), len(d_up), len(d_dn), len(pull), len(constr))
        entries = [
            {
                "name": str(names[i]),
                "delta_mu_up": float(d_up[i]),
                "delta_mu_down": float(d_dn[i]),
                "pull": float(pull[i]),
                "constraint": float(constr[i]),
            }
            for i in range(n)
        ]
    else:
        entries = list(artifact)  # type: ignore[arg-type]

    if top_n is not None:
        n = int(top_n)
        if n < 0:
            raise ValueError("top_n must be >= 0")
        entries = entries[:n]

    if not entries:
        raise ValueError("ranking plot requires at least 1 entry")

    names = [str(e.get("name", "")) for e in entries]
    d_up = [float(e.get("delta_mu_up", 0.0)) for e in entries]
    d_dn = [float(e.get("delta_mu_down", 0.0)) for e in entries]
    pull = [float(e.get("pull", 0.0)) for e in entries]
    constr = [abs(float(e.get("constraint", 0.0))) for e in entries]

    y = list(range(len(entries)))

    if ax_impact is None or ax_pull is None:
        fig, (ax_impact, ax_pull) = plt.subplots(
            ncols=2,
            sharey=True,
            figsize=(9.6, max(3.2, 0.28 * len(entries) + 1.4)),
            gridspec_kw={"width_ratios": [3.2, 1.6], "wspace": 0.05},
        )
    else:
        fig = ax_impact.figure

    # Impact panel
    ax_impact.barh(y, d_dn, color="#93C5FD", alpha=0.85, label=f"Δ{poi_label} (NP −1σ)")
    ax_impact.barh(y, d_up, color="#1D4ED8", alpha=0.85, label=f"Δ{poi_label} (NP +1σ)")
    ax_impact.axvline(0.0, color="#111827", lw=1.0)
    ax_impact.grid(True, axis="x", alpha=0.25)
    ax_impact.set_xlabel(f"Δ{poi_label}")

    # Pull panel (in units of prefit σ, with postfit constraint as errorbar)
    ax_pull.errorbar(
        pull,
        y,
        xerr=constr,
        fmt="o",
        ms=4.5,
        lw=1.0,
        capsize=2.0,
        color="#111827",
    )
    ax_pull.axvline(0.0, color="#111827", lw=1.0)
    ax_pull.axvline(1.0, color="#6B7280", lw=1.0, ls=":")
    ax_pull.axvline(-1.0, color="#6B7280", lw=1.0, ls=":")
    ax_pull.grid(True, axis="x", alpha=0.25)
    ax_pull.set_xlabel("pull (± constraint)")

    ax_impact.set_yticks(y)
    ax_impact.set_yticklabels(names)
    ax_impact.invert_yaxis()

    if title:
        fig.suptitle(title)

    ax_impact.legend(frameon=False, loc="lower right")
    return ax_impact, ax_pull


def plot_pulls(
    artifact: Mapping[str, Any] | Sequence[Mapping[str, Any]],
    *,
    ax=None,
    top_n: Optional[int] = None,
    title: Optional[str] = None,
):
    """Plot TREx-like pulls with postfit constraint error bars.

    Accepts:
    - a `trex_report_pulls_v0` artifact dict containing `entries`, or
    - a list of entry dicts.
    """
    _require_matplotlib()
    import matplotlib.pyplot as plt

    if isinstance(artifact, Mapping):
        entries = list(artifact.get("entries") or [])
    else:
        entries = list(artifact)

    if top_n is not None:
        n = int(top_n)
        if n < 0:
            raise ValueError("top_n must be >= 0")
        entries = entries[:n]

    if not entries:
        raise ValueError("pulls plot requires at least 1 entry")

    names = [str(e.get("name", "")) for e in entries]
    pulls = [float(e.get("pull", 0.0)) for e in entries]
    constraints = [abs(float(e.get("constraint", 0.0))) for e in entries]
    y = list(range(len(entries)))

    if ax is None:
        _, ax = plt.subplots(figsize=(8.6, max(3.2, 0.28 * len(entries) + 1.4)))

    colors = ["#1D4ED8" if p >= 0.0 else "#DC2626" for p in pulls]
    ax.barh(y, pulls, color=colors, alpha=0.75)
    ax.errorbar(
        pulls,
        y,
        xerr=constraints,
        fmt="none",
        ecolor="#111827",
        lw=1.0,
        capsize=2.0,
    )
    ax.axvline(0.0, color="#111827", lw=1.0)
    ax.axvline(1.0, color="#6B7280", lw=1.0, ls=":")
    ax.axvline(-1.0, color="#6B7280", lw=1.0, ls=":")
    ax.grid(True, axis="x", alpha=0.25)

    ax.set_yticks(y)
    ax.set_yticklabels(names)
    ax.invert_yaxis()
    ax.set_xlabel("pull (± constraint)")
    if title:
        ax.set_title(title)
    return ax


def plot_corr_matrix(
    artifact: Mapping[str, Any],
    *,
    ax=None,
    title: Optional[str] = None,
    include: Optional[str] = None,
    exclude: Optional[str] = None,
    top_n: Optional[int] = None,
    order: str = "group_base",
    show_colorbar: bool = True,
    cmap: str = "RdBu_r",
):
    """Plot a correlation matrix heatmap from a `trex_report_corr_v0` artifact.

    This is a pure view: it must not recompute correlations; it only filters/reorders the matrix.
    """
    _require_matplotlib()
    import matplotlib.pyplot as plt

    view = corr_subset(artifact, include=include, exclude=exclude, top_n=top_n, order=order)
    names = list(view["parameter_names"])
    corr = view["corr"]

    n = len(names)
    if ax is None:
        size = max(4.2, 0.18 * float(n) + 2.2)
        _, ax = plt.subplots(figsize=(size, size))

    # Use pcolormesh instead of imshow to keep SVG/PDF vector-friendly (no embedded raster).
    # Coordinates: cells span [i, i+1] with centers at i+0.5.
    im = ax.pcolormesh(
        corr,
        vmin=-1.0,
        vmax=1.0,
        cmap=str(cmap),
        shading="nearest",
        rasterized=False,
    )
    ax.set_xlim(0.0, float(n))
    ax.set_ylim(0.0, float(n))
    ax.invert_yaxis()

    ticks = [i + 0.5 for i in range(n)]
    ax.set_xticks(ticks)
    ax.set_yticks(ticks)

    # Avoid unreadable labels for huge matrices.
    if n <= 40:
        ax.set_xticklabels(names, rotation=90, fontsize=7)
        ax.set_yticklabels(names, fontsize=7)
    else:
        ax.set_xticklabels([])
        ax.set_yticklabels([])

    ax.set_xlabel("parameter")
    ax.set_ylabel("parameter")
    if title:
        ax.set_title(title)

    if show_colorbar:
        ax.figure.colorbar(im, ax=ax, fraction=0.046, pad=0.04, label="corr")

    return ax


def render_svg(artifact: dict, kind: str, *, config: dict | None = None) -> str:
    """Render an artifact dict to SVG string using the native Rust renderer.

    Parameters
    ----------
    artifact : dict
        Artifact data (e.g. pulls, ranking, corr, etc.).
    kind : str
        Artifact kind name (e.g. "pulls", "ranking", "corr", "profile", "cls", etc.).
    config : dict, optional
        VizConfig overrides as a dict (will be serialized to YAML).

    Returns
    -------
    str
        SVG document as a string.
    """
    import json

    from . import _core

    artifact_json = json.dumps(artifact)
    config_yaml = None
    if config is not None:
        import yaml  # type: ignore[import-untyped]

        config_yaml = yaml.dump(config)
    svg_bytes = _core.render_viz(artifact_json, kind, "svg", config_yaml=config_yaml)
    return svg_bytes.decode("utf-8")


def render_to_file(
    artifact: dict,
    kind: str,
    path: str,
    *,
    config: dict | None = None,
    dpi: int | None = None,
) -> None:
    """Render an artifact dict to a file (format inferred from extension).

    Parameters
    ----------
    artifact : dict
        Artifact data.
    kind : str
        Artifact kind name.
    path : str
        Output file path (.svg, .pdf, .png).
    config : dict, optional
        VizConfig overrides.
    dpi : int, optional
        DPI for raster output (PNG).
    """
    import json

    from . import _core

    artifact_json = json.dumps(artifact)
    ext = path.rsplit(".", 1)[-1] if "." in path else "svg"
    config_yaml = None
    if config is not None:
        import yaml  # type: ignore[import-untyped]

        config_yaml = yaml.dump(config)
    data = _core.render_viz(artifact_json, kind, ext, config_yaml=config_yaml, dpi=dpi)
    with open(path, "wb") as f:
        f.write(data)


__all__ = [
    "cls_curve",
    "profile_curve",
    "ranking_artifact",
    "corr_arrays",
    "corr_subset",
    "plot_cls_curve",
    "plot_brazil_limits",
    "plot_profile_curve",
    "plot_pulls",
    "plot_ranking",
    "plot_corr_matrix",
    "render_svg",
    "render_to_file",
]
