# OrBits

OrBits is a tool for visualizing dependency graphs as systems of planets.
It works on both Python projects (using pyproject.toml or similar) or
JavaScript projects (using package-lock.json).

## Installation

Install from Pypi:

```bash
pip install dep-orbits
```

Or, using pipx:

```bash
pipx install dep-orbits
```

Or, using uv:


```bash
uv tool install dep-orbits
```

## Usage

Run, in your project's directory:

```bash
orbits
```

Note that you must have all dependencies installed to measure the size of dependencies. For Python,
this means you must have an active virtual environment with all your dependencies. For node, your
`node_modules` must be populated (using e.g. `npm install`).
