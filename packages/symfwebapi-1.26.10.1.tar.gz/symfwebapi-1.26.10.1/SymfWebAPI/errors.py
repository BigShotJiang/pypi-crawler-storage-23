"""Error hierarchy for Symfonia WebAPI client runtime."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional


class SymfoniaError(RuntimeError):
    """Base exception for all runtime errors."""


class ConfigurationError(SymfoniaError):
    """Raised when client configuration is invalid."""


class TransportError(SymfoniaError):
    """Wrapping lower-level HTTP/IO errors."""

    def __init__(self, message: str, *, endpoint: Optional[str] = None) -> None:
        super().__init__(message)
        self.endpoint = endpoint


class SessionError(SymfoniaError):
    """Base class for session-specific issues."""


class SessionExpiredError(SessionError):
    """Raised when session token is no longer valid."""

    def __init__(self, message: str, *, endpoint: Optional[str] = None) -> None:
        super().__init__(message)
        self.endpoint = endpoint


@dataclass(slots=True)
class WebAPIHttpError(SymfoniaError):
    """Raised for non-success HTTP responses."""

    status_code: int
    endpoint: str
    response_text: str


class SessionManagementBypassWarning(UserWarning):
    """Warning emitted when manual session endpoints are called directly."""
