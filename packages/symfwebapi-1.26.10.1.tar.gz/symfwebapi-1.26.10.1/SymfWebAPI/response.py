"""Response container shared by async/sync controllers."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, Optional, TypeVar

T = TypeVar("T")


@dataclass(slots=True)
class ResponseEnvelope(Generic[T]):
    model: Optional[T]
    status: int
    headers: dict
    raw_text: Optional[str] = None

    def unwrap(self) -> T:
        if self.model is None:
            raise ValueError("Response has no model")
        return self.model
