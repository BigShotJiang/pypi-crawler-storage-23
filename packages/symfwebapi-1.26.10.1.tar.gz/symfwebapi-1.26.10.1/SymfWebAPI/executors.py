"""Sync/async executors implementing one shared request flow policy."""

from __future__ import annotations

from typing import Any, Callable, Optional

from .config import ClientConfig
from .errors import SessionExpiredError
from .request_engine import normalize_query_params, should_retry_auth, to_envelope_or_raise
from .response import ResponseEnvelope
from .session import SessionManager


class SyncRequestExecutor:
    def __init__(
        self,
        _config: ClientConfig,
        session_manager: SessionManager,
        request_fn: Callable[..., Any],
    ) -> None:
        self._session = session_manager
        self._request = request_fn

    def ensure_session(self) -> str:
        state = self._session.ensure_sync()
        if not state.token:
            raise SessionExpiredError("Session not established")
        return state.token

    def invalidate_session(self) -> None:
        self._session.invalidate()

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict] = None,
        data: Any = None,
    ) -> ResponseEnvelope[Any]:
        normalized_params = normalize_query_params(params)
        token = self.ensure_session()
        response = self._request(method, path, token=token, params=normalized_params, data=data)
        if should_retry_auth(response.status_code):
            self.invalidate_session()
            token = self.ensure_session()
            response = self._request(method, path, token=token, params=normalized_params, data=data)
        return to_envelope_or_raise(response, path=path)


class AsyncRequestExecutor:
    def __init__(
        self,
        config: ClientConfig,
        session_manager: SessionManager,
        request_fn: Callable[..., Any],
    ) -> None:
        self._config = config
        self._session = session_manager
        self._request = request_fn

    async def ensure_session(self) -> str:
        # Fast path for hot request loops: avoid full async synchronization when
        # a non-expired token is already present in shared session state.
        cached_state = self._session.state
        if cached_state.token and not cached_state.is_expired(max_age=self._config.max_session_age):
            return cached_state.token

        state = await self._session.ensure_async()
        if not state.token:
            raise SessionExpiredError("Session not established")
        return state.token

    def invalidate_session(self) -> None:
        self._session.invalidate()

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict] = None,
        data: Any = None,
    ) -> ResponseEnvelope[Any]:
        normalized_params = normalize_query_params(params)
        token = await self.ensure_session()
        response = await self._request(method, path, token=token, params=normalized_params, data=data)
        if should_retry_auth(response.status_code):
            self.invalidate_session()
            token = await self.ensure_session()
            response = await self._request(method, path, token=token, params=normalized_params, data=data)
        return to_envelope_or_raise(response, path=path)
