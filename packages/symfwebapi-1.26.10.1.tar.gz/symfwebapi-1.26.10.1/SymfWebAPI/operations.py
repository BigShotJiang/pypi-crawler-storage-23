"""Operation descriptors and shared invocation helpers for generated controllers."""

from __future__ import annotations

from dataclasses import dataclass
import inspect
from typing import Any, Awaitable, Callable, Optional, TypeVar, overload, cast

from pydantic import TypeAdapter

from .protocols import (
    AsyncInvokerProtocol,
    AsyncRequestProtocol,
    SyncInvokerProtocol,
    SyncRequestProtocol,
)
from .response import ResponseEnvelope

T = TypeVar("T")


@dataclass(frozen=True, slots=True)
class OperationSpec:
    """Descriptor of one API endpoint call with response parser."""

    method: str
    path: str
    parser: Callable[[ResponseEnvelope[Any]], ResponseEnvelope[Any]]


def parse_with_adapter(envelope: ResponseEnvelope[Any], adapter: TypeAdapter[T]) -> ResponseEnvelope[T]:
    if envelope.model is not None:
        model = cast(T, envelope.model)
    else:
        model = adapter.validate_json(envelope.raw_text or "null")
    return ResponseEnvelope(
        model=model,
        status=envelope.status,
        headers=envelope.headers,
        raw_text=envelope.raw_text,
    )


def parse_none(envelope: ResponseEnvelope[Any]) -> ResponseEnvelope[None]:
    return ResponseEnvelope(
        model=None,
        status=envelope.status,
        headers=envelope.headers,
        raw_text=envelope.raw_text,
    )


@overload
def invoke_operation(
    api: SyncInvokerProtocol,
    operation: OperationSpec,
    *,
    params: Optional[dict] = None,
    data: Any = None,
) -> ResponseEnvelope[Any]: ...


@overload
def invoke_operation(
    api: AsyncInvokerProtocol,
    operation: OperationSpec,
    *,
    params: Optional[dict] = None,
    data: Any = None,
) -> Awaitable[ResponseEnvelope[Any]]: ...


@overload
def invoke_operation(
    api: SyncRequestProtocol,
    operation: OperationSpec,
    *,
    params: Optional[dict] = None,
    data: Any = None,
) -> ResponseEnvelope[Any]: ...


@overload
def invoke_operation(
    api: AsyncRequestProtocol,
    operation: OperationSpec,
    *,
    params: Optional[dict] = None,
    data: Any = None,
) -> Awaitable[ResponseEnvelope[Any]]: ...


def invoke_operation(
    api: object,
    operation: OperationSpec,
    *,
    params: Optional[dict] = None,
    data: Any = None,
) -> ResponseEnvelope[Any] | Awaitable[ResponseEnvelope[Any]]:
    invoker = getattr(api, "invoke", None)
    if callable(invoker):
        return invoker(operation, params=params, data=data)

    requester = getattr(api, "request", None)
    if not callable(requester):
        raise TypeError("api must expose either invoke(...) or request(...)")

    result = requester(operation.method, operation.path, params=params, data=data)
    if inspect.isawaitable(result):
        async def _resolve() -> ResponseEnvelope[Any]:
            envelope = await cast(Awaitable[ResponseEnvelope[Any]], result)
            return operation.parser(envelope)

        return _resolve()

    return operation.parser(cast(ResponseEnvelope[Any], result))
