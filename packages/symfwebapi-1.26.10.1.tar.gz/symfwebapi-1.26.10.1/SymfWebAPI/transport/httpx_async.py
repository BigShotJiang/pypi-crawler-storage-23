"""Async HTTP transport using httpx."""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

from ..config import ClientConfig
from ..errors import TransportError
from ..session import SessionBackend


class AsyncHttpxTransport(SessionBackend):
    def __init__(self, config: ClientConfig, *, client: httpx.AsyncClient | None = None) -> None:
        self._config = config
        self._client = client or httpx.AsyncClient(
            base_url=config.base_url,
            timeout=config.request_timeout,
        )

    async def open_async(self, device_name: str) -> str:
        path = "/api/Sessions/OpenNewSession"
        try:
            response = await self._client.get(
                path,
                params={"deviceName": device_name},
                headers={"Authorization": f"Application {self._config.application_key}"},
            )
            response.raise_for_status()
            return response.text.strip('"')
        except httpx.HTTPError as exc:
            raise TransportError(f"open session failed: {exc}", endpoint=path) from exc

    def open_sync(self, device_name: str) -> str:  # pragma: no cover - async backend
        raise NotImplementedError("Użyj SyncHttpxTransport dla trybu sync")

    async def close_async(self, token: str) -> None:
        path = "/api/Sessions/CloseSession"
        try:
            response = await self._client.get(
                path,
                headers={"Authorization": f"Session {token}"},
            )
            response.raise_for_status()
        except httpx.HTTPError as exc:
            raise TransportError(f"close session failed: {exc}", endpoint=path) from exc

    def close_sync(self, token: str) -> None:  # pragma: no cover - async backend
        raise NotImplementedError("Użyj SyncHttpxTransport dla trybu sync")

    async def request(
        self,
        method: str,
        path: str,
        *,
        token: str,
        params: Optional[Dict[str, Any]] = None,
        data: Any = None,
    ) -> httpx.Response:
        headers = {"Authorization": f"Session {token}"}
        request_kwargs: Dict[str, Any] = {"params": params, "headers": headers}
        if data is not None:
            if isinstance(data, (str, bytes, bytearray, memoryview)):
                request_kwargs["content"] = data
                if isinstance(data, str):
                    headers["Content-Type"] = "application/json"
            else:
                request_kwargs["json"] = data
        try:
            response = await self._client.request(method, path, **request_kwargs)
            return response
        except httpx.HTTPError as exc:
            raise TransportError(f"request failed: {exc}", endpoint=path) from exc

    async def aclose(self) -> None:
        await self._client.aclose()
