"""Zarządzanie sesją WebAPI (handshake, odświeżanie, zamykanie)."""

from __future__ import annotations

import asyncio
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
import logging
import threading
from typing import Optional, Protocol, Callable, Any

from .config import ClientConfig


class SessionBackend(Protocol):
    """Minimalny interfejs backendu wykonującego żądania sesyjne."""

    async def open_async(self, device_name: str) -> str:
        """Zwraca nowy token sesyjny."""

    def open_sync(self, device_name: str) -> str:
        """Wariant synchroniczny."""

    async def close_async(self, token: str) -> None:
        """Zamyka wskazaną sesję."""

    def close_sync(self, token: str) -> None:
        """Wariant synchroniczny."""


@dataclass(slots=True)
class SessionState:
    token: Optional[str] = None
    opened_at: Optional[datetime] = None
    expires_at: Optional[datetime] = None

    def is_expired(self, *, max_age: Optional[timedelta], now: Optional[datetime] = None) -> bool:
        if not self.token:
            return True
        now = now or datetime.now(timezone.utc)
        if self.expires_at and now >= self.expires_at:
            return True
        if max_age and self.opened_at:
            return now - self.opened_at >= max_age
        return False


class _SharedSessionState:
    """Thread-safe shared state used by sync/async session managers."""

    def __init__(self, config: ClientConfig) -> None:
        self._config = config
        self.state = SessionState()
        self.lock = threading.RLock()
        self.condition = threading.Condition(self.lock)
        self.refreshing = False
        self._async_waiters: list[tuple[Any, Any]] = []

    def is_fresh(self) -> bool:
        return not self.state.is_expired(max_age=self._config.max_session_age)

    def wait_for_refresh_locked(self) -> None:
        while self.refreshing:
            self.condition.wait()

    async def wait_for_refresh_async(self) -> None:
        loop = asyncio.get_running_loop()
        with self.lock:
            if not self.refreshing:
                return
            future = loop.create_future()
            self._async_waiters.append((loop, future))

        try:
            await future
        finally:
            with self.lock:
                self._async_waiters = [
                    (registered_loop, registered_future)
                    for registered_loop, registered_future in self._async_waiters
                    if registered_future is not future
                ]

    def _notify_async_waiters_locked(self) -> None:
        for loop, future in self._async_waiters:
            if future.done():
                continue
            try:
                loop.call_soon_threadsafe(future.set_result, None)
            except RuntimeError:
                continue
        self._async_waiters.clear()

    def fail_refresh(self) -> None:
        with self.lock:
            self.refreshing = False
            self.condition.notify_all()
            self._notify_async_waiters_locked()

    def commit_refresh(self, token: str) -> SessionState:
        now = datetime.now(timezone.utc)
        expires_at = now + self._config.max_session_age if self._config.max_session_age else None
        new_state = SessionState(token=token, opened_at=now, expires_at=expires_at)
        with self.lock:
            self.state = new_state
            self.refreshing = False
            self.condition.notify_all()
            self._notify_async_waiters_locked()
            return self.state


class SyncSessionManager:
    """Synchronous session lifecycle coordinator."""

    def __init__(
        self,
        config: ClientConfig,
        backend: SessionBackend,
        shared_state: Optional[_SharedSessionState] = None,
        *,
        logger: logging.Logger,
        on_open: Optional[Callable[[SessionState], None]] = None,
        on_close: Optional[Callable[[SessionState], None]] = None,
        on_invalidate: Optional[Callable[[SessionState], None]] = None,
    ) -> None:
        self._config = config
        self._backend = backend
        self._shared = shared_state or _SharedSessionState(config)
        self._logger = logger
        self._on_open = on_open
        self._on_close = on_close
        self._on_invalidate = on_invalidate

    @property
    def state(self) -> SessionState:
        return self._shared.state

    def _close_previous_sync(self, previous_state: SessionState) -> None:
        token = previous_state.token
        if not token:
            return
        try:
            self._backend.close_sync(token)
            self._logger.info("Closed previous sync session for device=%s", self._config.device_name)
            if self._on_close:
                self._on_close(previous_state)
        except Exception:
            self._logger.warning(
                "Failed to close previous sync session for device=%s",
                self._config.device_name,
                exc_info=True,
            )

    def ensure_sync(self) -> SessionState:
        while True:
            with self._shared.lock:
                if self._shared.is_fresh():
                    return self._shared.state
                if self._shared.refreshing:
                    self._shared.wait_for_refresh_locked()
                    continue
                self._shared.refreshing = True
                previous_state = self._shared.state

            try:
                self._close_previous_sync(previous_state)
                token = self._backend.open_sync(self._config.device_name)
            except Exception:
                self._shared.fail_refresh()
                raise

            new_state = self._shared.commit_refresh(token)
            self._logger.info("Opened sync session for device=%s", self._config.device_name)
            if self._on_open:
                self._on_open(new_state)
            return new_state

    def close_sync(self) -> None:
        with self._shared.lock:
            self._shared.wait_for_refresh_locked()
            if not self._shared.state.token:
                return
            token = self._shared.state.token
            prev_state = self._shared.state
            self._shared.state = SessionState()
            self._shared.condition.notify_all()

        try:
            self._backend.close_sync(token)
            self._logger.info("Closed sync session for device=%s", self._config.device_name)
        finally:
            if self._on_close:
                self._on_close(prev_state)

    def invalidate(self) -> None:
        with self._shared.lock:
            self._shared.wait_for_refresh_locked()
            if self._shared.state.token:
                self._logger.info("Invalidated session for device=%s", self._config.device_name)
                if self._on_invalidate:
                    self._on_invalidate(self._shared.state)
            self._shared.state = SessionState()
            self._shared.condition.notify_all()


class AsyncSessionManager:
    """Asynchronous session lifecycle coordinator."""

    def __init__(
        self,
        config: ClientConfig,
        backend: SessionBackend,
        shared_state: Optional[_SharedSessionState] = None,
        *,
        logger: logging.Logger,
        on_open: Optional[Callable[[SessionState], None]] = None,
        on_close: Optional[Callable[[SessionState], None]] = None,
    ) -> None:
        self._config = config
        self._backend = backend
        self._shared = shared_state or _SharedSessionState(config)
        self._logger = logger
        self._on_open = on_open
        self._on_close = on_close

    @property
    def state(self) -> SessionState:
        return self._shared.state

    async def _close_previous_async(self, previous_state: SessionState) -> None:
        token = previous_state.token
        if not token:
            return
        try:
            await self._backend.close_async(token)
            self._logger.info("Closed previous async session for device=%s", self._config.device_name)
            if self._on_close:
                self._on_close(previous_state)
        except Exception:
            self._logger.warning(
                "Failed to close previous async session for device=%s",
                self._config.device_name,
                exc_info=True,
            )

    async def ensure_async(self) -> SessionState:
        while True:
            # Hot path: in steady state most async calls only need to read
            # the current token and skip lock/condition coordination.
            current = self._shared.state
            if not current.is_expired(max_age=self._config.max_session_age):
                return current

            with self._shared.lock:
                if self._shared.is_fresh():
                    return self._shared.state
                if self._shared.refreshing:
                    should_refresh = False
                else:
                    self._shared.refreshing = True
                    previous_state = self._shared.state
                    should_refresh = True

            if not should_refresh:
                await self._shared.wait_for_refresh_async()
                continue

            try:
                await self._close_previous_async(previous_state)
                token = await self._backend.open_async(self._config.device_name)
            except Exception:
                self._shared.fail_refresh()
                raise

            new_state = self._shared.commit_refresh(token)
            self._logger.info("Opened async session for device=%s", self._config.device_name)
            if self._on_open:
                self._on_open(new_state)
            return new_state

    async def close_async(self) -> None:
        await self._shared.wait_for_refresh_async()
        with self._shared.lock:
            if not self._shared.state.token:
                return
            token = self._shared.state.token
            prev_state = self._shared.state
            self._shared.state = SessionState()
            self._shared.condition.notify_all()

        try:
            await self._backend.close_async(token)
            self._logger.info("Closed async session for device=%s", self._config.device_name)
        finally:
            if self._on_close:
                self._on_close(prev_state)


class SessionManager:
    """Backward-compatible facade coordinating sync and async session managers."""

    def __init__(
        self,
        config: ClientConfig,
        backend: SessionBackend,
        *,
        on_open: Optional[Callable[[SessionState], None]] = None,
        on_close: Optional[Callable[[SessionState], None]] = None,
        on_invalidate: Optional[Callable[[SessionState], None]] = None,
    ):
        logger = logging.getLogger(__name__)
        shared_state = _SharedSessionState(config)
        self._sync = SyncSessionManager(
            config,
            backend,
            shared_state,
            logger=logger,
            on_open=on_open,
            on_close=on_close,
            on_invalidate=on_invalidate,
        )
        self._async = AsyncSessionManager(
            config,
            backend,
            shared_state,
            logger=logger,
            on_open=on_open,
            on_close=on_close,
        )

    @property
    def state(self) -> SessionState:
        return self._sync.state

    async def ensure_async(self) -> SessionState:
        return await self._async.ensure_async()

    def ensure_sync(self) -> SessionState:
        return self._sync.ensure_sync()

    async def close_async(self) -> None:
        await self._async.close_async()

    def close_sync(self) -> None:
        self._sync.close_sync()

    def invalidate(self) -> None:
        """Czyści lokalny token – użytkownik może wywołać po błędzie 401."""
        self._sync.invalidate()
