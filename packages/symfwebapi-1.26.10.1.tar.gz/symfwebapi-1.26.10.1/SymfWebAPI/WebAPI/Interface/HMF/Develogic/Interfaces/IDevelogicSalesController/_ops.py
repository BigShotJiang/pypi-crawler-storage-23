from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.HMF.Develogic.ViewModels import DevelogicAdvancePayment
from SymfWebAPI.WebAPI.Interface.HMF.Develogic.ViewModels import DevelogicContractInvoiceIssue
from SymfWebAPI.WebAPI.Interface.HMF.Develogic.ViewModels.V2026_1 import DevelogicDocumentIssue
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocument

_ADAPTER_AddNew = TypeAdapter(SaleDocument)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[SaleDocument]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/DevelogicSales/Invoice', parser=_parse_AddNew)

_ADAPTER_IssueAdvancePayment = TypeAdapter(SaleDocument)

def _parse_IssueAdvancePayment(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[SaleDocument]:
    return parse_with_adapter(envelope, _ADAPTER_IssueAdvancePayment)
OP_IssueAdvancePayment = OperationSpec(method='POST', path='/api/DevelogicSales/AdvancePayment', parser=_parse_IssueAdvancePayment)

_ADAPTER_IssueContractInvoice = TypeAdapter(SaleDocument)

def _parse_IssueContractInvoice(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[SaleDocument]:
    return parse_with_adapter(envelope, _ADAPTER_IssueContractInvoice)
OP_IssueContractInvoice = OperationSpec(method='POST', path='/api/DevelogicSales/ContractInvoice', parser=_parse_IssueContractInvoice)
