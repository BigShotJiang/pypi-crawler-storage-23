from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseDocument
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseDocumentIssue

_ADAPTER_AddNew = TypeAdapter(PurchaseDocument)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PurchaseDocument]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/DevelogicPurchases/Invoice', parser=_parse_AddNew)
