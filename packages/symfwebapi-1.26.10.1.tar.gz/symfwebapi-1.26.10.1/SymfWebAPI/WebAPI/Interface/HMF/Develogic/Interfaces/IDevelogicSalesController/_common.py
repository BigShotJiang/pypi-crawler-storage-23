from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/DevelogicSales/Invoice')
def _prepare_AddNew(*, issue, invoiceKind, document) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["issue"] = issue
    params["invoiceKind"] = invoiceKind
    data = document.model_dump_json(exclude_unset=True) if document is not None else None
    return params or None, data

_REQUEST_IssueAdvancePayment = ('POST', '/api/DevelogicSales/AdvancePayment')
def _prepare_IssueAdvancePayment(*, contractId, invoiceKind) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractId"] = contractId
    params["invoiceKind"] = invoiceKind
    data = None
    return params or None, data

_REQUEST_IssueContractInvoice = ('POST', '/api/DevelogicSales/ContractInvoice')
def _prepare_IssueContractInvoice(*, contractId, invoiceKind) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractId"] = contractId
    params["invoiceKind"] = invoiceKind
    data = None
    return params or None, data
