from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseDocument
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseDocumentIssue
from ._common import (
    _prepare_AddNew,
)
from ._ops import (
    OP_AddNew,
)

@overload
def AddNew(api: SyncInvokerProtocol, issue: bool, document: "PurchaseDocumentIssue") -> ResponseEnvelope[PurchaseDocument]: ...
@overload
def AddNew(api: SyncRequestProtocol, issue: bool, document: "PurchaseDocumentIssue") -> ResponseEnvelope[PurchaseDocument]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, issue: bool, document: "PurchaseDocumentIssue") -> Awaitable[ResponseEnvelope[PurchaseDocument]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, issue: bool, document: "PurchaseDocumentIssue") -> Awaitable[ResponseEnvelope[PurchaseDocument]]: ...
def AddNew(api: object, issue: bool, document: "PurchaseDocumentIssue") -> ResponseEnvelope[PurchaseDocument] | Awaitable[ResponseEnvelope[PurchaseDocument]]:
    params, data = _prepare_AddNew(issue=issue, document=document)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

__all__ = ["AddNew"]
