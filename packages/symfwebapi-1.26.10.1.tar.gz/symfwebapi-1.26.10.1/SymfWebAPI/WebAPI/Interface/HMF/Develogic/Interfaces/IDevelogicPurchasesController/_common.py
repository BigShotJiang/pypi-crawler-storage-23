from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/DevelogicPurchases/Invoice')
def _prepare_AddNew(*, issue, document) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["issue"] = issue
    data = document.model_dump_json(exclude_unset=True) if document is not None else None
    return params or None, data
