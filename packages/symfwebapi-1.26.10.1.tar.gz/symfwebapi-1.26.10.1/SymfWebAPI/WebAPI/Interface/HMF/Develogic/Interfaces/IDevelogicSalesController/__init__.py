from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.HMF.Develogic.ViewModels import DevelogicAdvancePayment
from SymfWebAPI.WebAPI.Interface.HMF.Develogic.ViewModels import DevelogicContractInvoiceIssue
from SymfWebAPI.WebAPI.Interface.HMF.Develogic.ViewModels.V2026_1 import DevelogicDocumentIssue
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocument
from ._common import (
    _prepare_AddNew,
    _prepare_IssueAdvancePayment,
    _prepare_IssueContractInvoice,
)
from ._ops import (
    OP_AddNew,
    OP_IssueAdvancePayment,
    OP_IssueContractInvoice,
)

@overload
def AddNew(api: SyncInvokerProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", document: "DevelogicDocumentIssue") -> ResponseEnvelope[SaleDocument]: ...
@overload
def AddNew(api: SyncRequestProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", document: "DevelogicDocumentIssue") -> ResponseEnvelope[SaleDocument]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", document: "DevelogicDocumentIssue") -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", document: "DevelogicDocumentIssue") -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
def AddNew(api: object, issue: bool, invoiceKind: "IssueInvoiceKind", document: "DevelogicDocumentIssue") -> ResponseEnvelope[SaleDocument] | Awaitable[ResponseEnvelope[SaleDocument]]:
    params, data = _prepare_AddNew(issue=issue, invoiceKind=invoiceKind, document=document)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def IssueAdvancePayment(api: SyncInvokerProtocol, contractId: "DevelogicAdvancePayment", invoiceKind: int) -> ResponseEnvelope[SaleDocument]: ...
@overload
def IssueAdvancePayment(api: SyncRequestProtocol, contractId: "DevelogicAdvancePayment", invoiceKind: int) -> ResponseEnvelope[SaleDocument]: ...
@overload
def IssueAdvancePayment(api: AsyncInvokerProtocol, contractId: "DevelogicAdvancePayment", invoiceKind: int) -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
@overload
def IssueAdvancePayment(api: AsyncRequestProtocol, contractId: "DevelogicAdvancePayment", invoiceKind: int) -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
def IssueAdvancePayment(api: object, contractId: "DevelogicAdvancePayment", invoiceKind: int) -> ResponseEnvelope[SaleDocument] | Awaitable[ResponseEnvelope[SaleDocument]]:
    params, data = _prepare_IssueAdvancePayment(contractId=contractId, invoiceKind=invoiceKind)
    return invoke_operation(api, OP_IssueAdvancePayment, params=params, data=data)

@overload
def IssueContractInvoice(api: SyncInvokerProtocol, contractId: "DevelogicContractInvoiceIssue", invoiceKind: int) -> ResponseEnvelope[SaleDocument]: ...
@overload
def IssueContractInvoice(api: SyncRequestProtocol, contractId: "DevelogicContractInvoiceIssue", invoiceKind: int) -> ResponseEnvelope[SaleDocument]: ...
@overload
def IssueContractInvoice(api: AsyncInvokerProtocol, contractId: "DevelogicContractInvoiceIssue", invoiceKind: int) -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
@overload
def IssueContractInvoice(api: AsyncRequestProtocol, contractId: "DevelogicContractInvoiceIssue", invoiceKind: int) -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
def IssueContractInvoice(api: object, contractId: "DevelogicContractInvoiceIssue", invoiceKind: int) -> ResponseEnvelope[SaleDocument] | Awaitable[ResponseEnvelope[SaleDocument]]:
    params, data = _prepare_IssueContractInvoice(contractId=contractId, invoiceKind=invoiceKind)
    return invoke_operation(api, OP_IssueContractInvoice, params=params, data=data)

__all__ = ["AddNew", "IssueAdvancePayment", "IssueContractInvoice"]
