from __future__ import annotations

from pydantic import BaseModel

import importlib
from typing import TYPE_CHECKING
from typing import List, Optional
from datetime import datetime
from decimal import Decimal
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PaymentRegistryBase
from SymfWebAPI.WebAPI.Interface.Enums import (
    enumDocumentReservationType,
    enumJPK_V7DocumentAttribute,
    enumSalePriceType,
)
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import (
    SaleDocumentIssueCatalog,
    SaleDocumentIssueKind,
)

class DevelogicAdvancePayment(BaseModel):
    Value: Decimal
    IsFinal: bool

class DevelogicContractInvoiceIssue(BaseModel):
    TypeCode: str
    Series: str
    CorrectionTypeCode: str
    CorrectionSeries: str
    NumberInSeries: Optional[int]
    ReservationType: Optional["enumDocumentReservationType"]
    PaymentRegistry: "PaymentRegistryBase"
    PaymentFormId: int
    IssueDate: Optional[datetime]
    SaleDate: Optional[datetime]
    MaturityDate: Optional[datetime]
    SalePriceType: "enumSalePriceType"
    SplitPayment: bool
    JPK_V7Attributes: Optional["enumJPK_V7DocumentAttribute"]
    Catalog: "SaleDocumentIssueCatalog"
    Kind: "SaleDocumentIssueKind"
    Marker: int
    ReceivedBy: str
    Note: str
    Positions: List["DevelogicContractInvoiceIssuePosition"]

class DevelogicContractInvoiceIssuePosition(BaseModel):
    ContractPositionId: int
    Quantity: int
    Value: Decimal

_VERSIONED_EXPORTS = {
    'DevelogicDocumentIssue': 'V2026_1',
}

def __getattr__(name: str):
    child_name = _VERSIONED_EXPORTS.get(name)
    if child_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module = importlib.import_module(f".{child_name}", __name__)
    value = getattr(module, name)
    globals()[name] = value
    return value

def __dir__():
    return sorted(set(_VERSIONED_EXPORTS) | {n for n in globals() if not n.startswith('_')})

if TYPE_CHECKING:
    from .V2026_1 import DevelogicDocumentIssue
