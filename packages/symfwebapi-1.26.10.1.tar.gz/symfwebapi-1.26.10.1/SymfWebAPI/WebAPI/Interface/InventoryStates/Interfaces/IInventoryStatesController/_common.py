from __future__ import annotations

from typing import Any

_REQUEST_GetByProductId = ('GET', '/api/InventoryStates/ByProduct')
def _prepare_GetByProductId(*, id) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    data = None
    return params or None, data

_REQUEST_GetByProductCode = ('GET', '/api/InventoryStates/ByProduct')
def _prepare_GetByProductCode(*, code) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["code"] = code
    data = None
    return params or None, data

_REQUEST_GetByWarehouseId = ('GET', '/api/InventoryStates/ByWarehouse')
def _prepare_GetByWarehouseId(*, id) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    data = None
    return params or None, data

_REQUEST_GetByWarehouseCode = ('GET', '/api/InventoryStates/ByWarehouse')
def _prepare_GetByWarehouseCode(*, code) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["code"] = code
    data = None
    return params or None, data

_REQUEST_GetByProductIdAndWarehouseId = ('GET', '/api/InventoryStates/ByProductAndWarehouse')
def _prepare_GetByProductIdAndWarehouseId(*, productId, warehouseId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["productId"] = productId
    params["warehouseId"] = warehouseId
    data = None
    return params or None, data

_REQUEST_GetChanges = ('GET', '/api/InventoryStates/Changes')
def _prepare_GetChanges(*, date) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["date"] = date
    data = None
    return params or None, data
