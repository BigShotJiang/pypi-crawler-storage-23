from __future__ import annotations

from typing import List
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.InventoryStates.ViewModels import InventoryState

_ADAPTER_GetByProductId = TypeAdapter(List[InventoryState])

def _parse_GetByProductId(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[InventoryState]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByProductId)
OP_GetByProductId = OperationSpec(method='GET', path='/api/InventoryStates/ByProduct', parser=_parse_GetByProductId)

_ADAPTER_GetByProductCode = TypeAdapter(List[InventoryState])

def _parse_GetByProductCode(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[InventoryState]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByProductCode)
OP_GetByProductCode = OperationSpec(method='GET', path='/api/InventoryStates/ByProduct', parser=_parse_GetByProductCode)

_ADAPTER_GetByWarehouseId = TypeAdapter(List[InventoryState])

def _parse_GetByWarehouseId(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[InventoryState]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByWarehouseId)
OP_GetByWarehouseId = OperationSpec(method='GET', path='/api/InventoryStates/ByWarehouse', parser=_parse_GetByWarehouseId)

_ADAPTER_GetByWarehouseCode = TypeAdapter(List[InventoryState])

def _parse_GetByWarehouseCode(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[InventoryState]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByWarehouseCode)
OP_GetByWarehouseCode = OperationSpec(method='GET', path='/api/InventoryStates/ByWarehouse', parser=_parse_GetByWarehouseCode)

_ADAPTER_GetByProductIdAndWarehouseId = TypeAdapter(InventoryState)

def _parse_GetByProductIdAndWarehouseId(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[InventoryState]:
    return parse_with_adapter(envelope, _ADAPTER_GetByProductIdAndWarehouseId)
OP_GetByProductIdAndWarehouseId = OperationSpec(method='GET', path='/api/InventoryStates/ByProductAndWarehouse', parser=_parse_GetByProductIdAndWarehouseId)

_ADAPTER_GetChanges = TypeAdapter(List[InventoryState])

def _parse_GetChanges(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[InventoryState]]:
    return parse_with_adapter(envelope, _ADAPTER_GetChanges)
OP_GetChanges = OperationSpec(method='GET', path='/api/InventoryStates/Changes', parser=_parse_GetChanges)
