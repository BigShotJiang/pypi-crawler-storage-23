from __future__ import annotations

from typing import Awaitable, List, overload
from datetime import datetime
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.InventoryStates.ViewModels import InventoryState
from ._common import (
    _prepare_GetByProductId,
    _prepare_GetByProductCode,
    _prepare_GetByWarehouseId,
    _prepare_GetByWarehouseCode,
    _prepare_GetByProductIdAndWarehouseId,
    _prepare_GetChanges,
)
from ._ops import (
    OP_GetByProductId,
    OP_GetByProductCode,
    OP_GetByWarehouseId,
    OP_GetByWarehouseCode,
    OP_GetByProductIdAndWarehouseId,
    OP_GetChanges,
)

@overload
def GetByProductId(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[List[InventoryState]]: ...
@overload
def GetByProductId(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[List[InventoryState]]: ...
@overload
def GetByProductId(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[List[InventoryState]]]: ...
@overload
def GetByProductId(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[List[InventoryState]]]: ...
def GetByProductId(api: object, id: int) -> ResponseEnvelope[List[InventoryState]] | Awaitable[ResponseEnvelope[List[InventoryState]]]:
    params, data = _prepare_GetByProductId(id=id)
    return invoke_operation(api, OP_GetByProductId, params=params, data=data)

@overload
def GetByProductCode(api: SyncInvokerProtocol, code: str) -> ResponseEnvelope[List[InventoryState]]: ...
@overload
def GetByProductCode(api: SyncRequestProtocol, code: str) -> ResponseEnvelope[List[InventoryState]]: ...
@overload
def GetByProductCode(api: AsyncInvokerProtocol, code: str) -> Awaitable[ResponseEnvelope[List[InventoryState]]]: ...
@overload
def GetByProductCode(api: AsyncRequestProtocol, code: str) -> Awaitable[ResponseEnvelope[List[InventoryState]]]: ...
def GetByProductCode(api: object, code: str) -> ResponseEnvelope[List[InventoryState]] | Awaitable[ResponseEnvelope[List[InventoryState]]]:
    params, data = _prepare_GetByProductCode(code=code)
    return invoke_operation(api, OP_GetByProductCode, params=params, data=data)

@overload
def GetByWarehouseId(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[List[InventoryState]]: ...
@overload
def GetByWarehouseId(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[List[InventoryState]]: ...
@overload
def GetByWarehouseId(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[List[InventoryState]]]: ...
@overload
def GetByWarehouseId(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[List[InventoryState]]]: ...
def GetByWarehouseId(api: object, id: int) -> ResponseEnvelope[List[InventoryState]] | Awaitable[ResponseEnvelope[List[InventoryState]]]:
    params, data = _prepare_GetByWarehouseId(id=id)
    return invoke_operation(api, OP_GetByWarehouseId, params=params, data=data)

@overload
def GetByWarehouseCode(api: SyncInvokerProtocol, code: str) -> ResponseEnvelope[List[InventoryState]]: ...
@overload
def GetByWarehouseCode(api: SyncRequestProtocol, code: str) -> ResponseEnvelope[List[InventoryState]]: ...
@overload
def GetByWarehouseCode(api: AsyncInvokerProtocol, code: str) -> Awaitable[ResponseEnvelope[List[InventoryState]]]: ...
@overload
def GetByWarehouseCode(api: AsyncRequestProtocol, code: str) -> Awaitable[ResponseEnvelope[List[InventoryState]]]: ...
def GetByWarehouseCode(api: object, code: str) -> ResponseEnvelope[List[InventoryState]] | Awaitable[ResponseEnvelope[List[InventoryState]]]:
    params, data = _prepare_GetByWarehouseCode(code=code)
    return invoke_operation(api, OP_GetByWarehouseCode, params=params, data=data)

@overload
def GetByProductIdAndWarehouseId(api: SyncInvokerProtocol, productId: int, warehouseId: int) -> ResponseEnvelope[InventoryState]: ...
@overload
def GetByProductIdAndWarehouseId(api: SyncRequestProtocol, productId: int, warehouseId: int) -> ResponseEnvelope[InventoryState]: ...
@overload
def GetByProductIdAndWarehouseId(api: AsyncInvokerProtocol, productId: int, warehouseId: int) -> Awaitable[ResponseEnvelope[InventoryState]]: ...
@overload
def GetByProductIdAndWarehouseId(api: AsyncRequestProtocol, productId: int, warehouseId: int) -> Awaitable[ResponseEnvelope[InventoryState]]: ...
def GetByProductIdAndWarehouseId(api: object, productId: int, warehouseId: int) -> ResponseEnvelope[InventoryState] | Awaitable[ResponseEnvelope[InventoryState]]:
    params, data = _prepare_GetByProductIdAndWarehouseId(productId=productId, warehouseId=warehouseId)
    return invoke_operation(api, OP_GetByProductIdAndWarehouseId, params=params, data=data)

@overload
def GetChanges(api: SyncInvokerProtocol, date: datetime) -> ResponseEnvelope[List[InventoryState]]: ...
@overload
def GetChanges(api: SyncRequestProtocol, date: datetime) -> ResponseEnvelope[List[InventoryState]]: ...
@overload
def GetChanges(api: AsyncInvokerProtocol, date: datetime) -> Awaitable[ResponseEnvelope[List[InventoryState]]]: ...
@overload
def GetChanges(api: AsyncRequestProtocol, date: datetime) -> Awaitable[ResponseEnvelope[List[InventoryState]]]: ...
def GetChanges(api: object, date: datetime) -> ResponseEnvelope[List[InventoryState]] | Awaitable[ResponseEnvelope[List[InventoryState]]]:
    params, data = _prepare_GetChanges(date=date)
    return invoke_operation(api, OP_GetChanges, params=params, data=data)

__all__ = ["GetByProductId", "GetByProductCode", "GetByWarehouseId", "GetByWarehouseCode", "GetByProductIdAndWarehouseId", "GetChanges"]
