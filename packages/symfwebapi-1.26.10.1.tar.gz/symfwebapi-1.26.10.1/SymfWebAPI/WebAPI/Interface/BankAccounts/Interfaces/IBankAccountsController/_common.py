from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/BankAccounts')
def _prepare_Get(*, id) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    data = None
    return params or None, data

_REQUEST_GetListByContractor = ('GET', '/api/BankAccounts')
def _prepare_GetListByContractor(*, contractorCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = None
    return params or None, data

_REQUEST_Insert = ('POST', '/api/BankAccounts/Create')
def _prepare_Insert(*, contractorCode, bankAccount) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = bankAccount.model_dump_json(exclude_unset=True) if bankAccount is not None else None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/BankAccounts/Update')
def _prepare_Update(*, bankAccount) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = bankAccount.model_dump_json(exclude_unset=True) if bankAccount is not None else None
    return params or None, data

_REQUEST_SetAsMain = ('PATCH', '/api/BankAccounts/SetAsMain')
def _prepare_SetAsMain(*, id) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    data = None
    return params or None, data
