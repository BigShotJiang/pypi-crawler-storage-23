from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.BankAccounts.ViewModels import BankAccount

_ADAPTER_Get = TypeAdapter(BankAccount)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[BankAccount]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/BankAccounts', parser=_parse_Get)

_ADAPTER_GetListByContractor = TypeAdapter(List[BankAccount])

def _parse_GetListByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[BankAccount]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByContractor)
OP_GetListByContractor = OperationSpec(method='GET', path='/api/BankAccounts', parser=_parse_GetListByContractor)

_ADAPTER_Insert = TypeAdapter(BankAccount)

def _parse_Insert(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[BankAccount]:
    return parse_with_adapter(envelope, _ADAPTER_Insert)
OP_Insert = OperationSpec(method='POST', path='/api/BankAccounts/Create', parser=_parse_Insert)

def _parse_Update(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Update = OperationSpec(method='PUT', path='/api/BankAccounts/Update', parser=_parse_Update)

def _parse_SetAsMain(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_SetAsMain = OperationSpec(method='PATCH', path='/api/BankAccounts/SetAsMain', parser=_parse_SetAsMain)
