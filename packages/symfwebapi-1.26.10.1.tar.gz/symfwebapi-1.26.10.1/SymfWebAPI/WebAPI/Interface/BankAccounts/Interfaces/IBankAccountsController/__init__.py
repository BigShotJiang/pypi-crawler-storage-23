from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.BankAccounts.ViewModels import BankAccount
from ._common import (
    _prepare_Get,
    _prepare_GetListByContractor,
    _prepare_Insert,
    _prepare_Update,
    _prepare_SetAsMain,
)
from ._ops import (
    OP_Get,
    OP_GetListByContractor,
    OP_Insert,
    OP_Update,
    OP_SetAsMain,
)

@overload
def Get(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[BankAccount]: ...
@overload
def Get(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[BankAccount]: ...
@overload
def Get(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[BankAccount]]: ...
@overload
def Get(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[BankAccount]]: ...
def Get(api: object, id: int) -> ResponseEnvelope[BankAccount] | Awaitable[ResponseEnvelope[BankAccount]]:
    params, data = _prepare_Get(id=id)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetListByContractor(api: SyncInvokerProtocol, contractorCode: str) -> ResponseEnvelope[List[BankAccount]]: ...
@overload
def GetListByContractor(api: SyncRequestProtocol, contractorCode: str) -> ResponseEnvelope[List[BankAccount]]: ...
@overload
def GetListByContractor(api: AsyncInvokerProtocol, contractorCode: str) -> Awaitable[ResponseEnvelope[List[BankAccount]]]: ...
@overload
def GetListByContractor(api: AsyncRequestProtocol, contractorCode: str) -> Awaitable[ResponseEnvelope[List[BankAccount]]]: ...
def GetListByContractor(api: object, contractorCode: str) -> ResponseEnvelope[List[BankAccount]] | Awaitable[ResponseEnvelope[List[BankAccount]]]:
    params, data = _prepare_GetListByContractor(contractorCode=contractorCode)
    return invoke_operation(api, OP_GetListByContractor, params=params, data=data)

@overload
def Insert(api: SyncInvokerProtocol, contractorCode: str, bankAccount: "BankAccount") -> ResponseEnvelope[BankAccount]: ...
@overload
def Insert(api: SyncRequestProtocol, contractorCode: str, bankAccount: "BankAccount") -> ResponseEnvelope[BankAccount]: ...
@overload
def Insert(api: AsyncInvokerProtocol, contractorCode: str, bankAccount: "BankAccount") -> Awaitable[ResponseEnvelope[BankAccount]]: ...
@overload
def Insert(api: AsyncRequestProtocol, contractorCode: str, bankAccount: "BankAccount") -> Awaitable[ResponseEnvelope[BankAccount]]: ...
def Insert(api: object, contractorCode: str, bankAccount: "BankAccount") -> ResponseEnvelope[BankAccount] | Awaitable[ResponseEnvelope[BankAccount]]:
    params, data = _prepare_Insert(contractorCode=contractorCode, bankAccount=bankAccount)
    return invoke_operation(api, OP_Insert, params=params, data=data)

@overload
def Update(api: SyncInvokerProtocol, bankAccount: "BankAccount") -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, bankAccount: "BankAccount") -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, bankAccount: "BankAccount") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, bankAccount: "BankAccount") -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, bankAccount: "BankAccount") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(bankAccount=bankAccount)
    return invoke_operation(api, OP_Update, params=params, data=data)

@overload
def SetAsMain(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[None]: ...
@overload
def SetAsMain(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[None]: ...
@overload
def SetAsMain(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def SetAsMain(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[None]]: ...
def SetAsMain(api: object, id: int) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_SetAsMain(id=id)
    return invoke_operation(api, OP_SetAsMain, params=params, data=data)

__all__ = ["Get", "GetListByContractor", "Insert", "Update", "SetAsMain"]
