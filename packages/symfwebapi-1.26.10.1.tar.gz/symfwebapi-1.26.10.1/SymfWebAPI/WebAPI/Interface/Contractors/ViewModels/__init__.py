from __future__ import annotations

from pydantic import BaseModel

from typing import List, Optional
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import FilterDimensionCriteria
from SymfWebAPI.WebAPI.Interface.Enums import (
    enumContractorType,
    enumFilterCriteriaMode,
    enumPriceKind,
    enumSalePriceType,
)
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension

class ContractorDeliveryAddress(BaseModel):
    Id: Optional[int]
    Code: str
    Country: str
    City: str
    Province: str
    Street: str
    HouseNo: str
    ApartmentNo: str
    PostCode: str
    FullAddress: str

class ContractorFilterCriteria(BaseModel):
    Code_From: str
    Code_To: str
    Code_Mode: Optional["enumFilterCriteriaMode"]
    Name_From: str
    Name_To: str
    Name_Mode: Optional["enumFilterCriteriaMode"]
    NIP_From: str
    NIP_To: str
    NIP_Mode: Optional["enumFilterCriteriaMode"]
    City_From: str
    City_To: str
    City_Mode: Optional["enumFilterCriteriaMode"]
    Province_From: str
    Province_To: str
    Province_Mode: Optional["enumFilterCriteriaMode"]
    Marker_From: int
    Marker_To: int
    Marker_Mode: Optional["enumFilterCriteriaMode"]
    Active: Optional[bool]
    Country: str
    Dimensions: List["FilterDimensionCriteria"]

class ContractorListElementWithDimensions(BaseModel):
    Dimensions: List["Dimension"]
    Id: int
    Code: str
    Name: str
    Type: Optional["enumContractorType"]
    NIP: str
    Pesel: str
    Active: bool
    PriceType: Optional["enumSalePriceType"]
    PriceKind: Optional["enumPriceKind"]
    PaymentFormOid: int
    PaymentRegistryOid: int
    Place: str
    PostCode: str
