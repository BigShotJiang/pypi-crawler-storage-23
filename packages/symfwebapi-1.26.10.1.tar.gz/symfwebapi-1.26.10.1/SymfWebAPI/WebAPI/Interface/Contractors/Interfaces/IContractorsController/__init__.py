from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels.V2026_1 import Contractor
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels import ContractorCriteriaFilter
from SymfWebAPI.WebAPI.Interface.Contractors.ViewModels import ContractorFilterCriteria
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels import ContractorListElement
from SymfWebAPI.WebAPI.Interface.Contractors.ViewModels import ContractorListElementWithDimensions
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import IncrementalSyncListElement
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType
from ._common import (
    _prepare_Get,
    _prepare_GetByNIP,
    _prepare_GetByPesel,
    _prepare_GetByPosition,
    _prepare_GetByNIPAndPosition,
    _prepare_Filter,
    _prepare_FilterWithDimensions,
    _prepare_AddNew,
    _prepare_Update,
    _prepare_SyncFK,
    _prepare_IncrementalSync,
    _prepare_FilterSql,
    _prepare_GetPagedDocument,
    _prepare_GetPagedDocumentWithDimensions,
    _prepare_FilterSqlWithDimensions,
)
from ._ops import (
    OP_Get,
    OP_GetByNIP,
    OP_GetByPesel,
    OP_GetByPosition,
    OP_GetByNIPAndPosition,
    OP_Filter,
    OP_FilterWithDimensions,
    OP_AddNew,
    OP_Update,
    OP_SyncFK,
    OP_IncrementalSync,
    OP_FilterSql,
    OP_GetPagedDocument,
    OP_GetPagedDocumentWithDimensions,
    OP_FilterSqlWithDimensions,
)

@overload
def Get(api: SyncInvokerProtocol, code: str) -> ResponseEnvelope[Contractor]: ...
@overload
def Get(api: SyncRequestProtocol, code: str) -> ResponseEnvelope[Contractor]: ...
@overload
def Get(api: AsyncInvokerProtocol, code: str) -> Awaitable[ResponseEnvelope[Contractor]]: ...
@overload
def Get(api: AsyncRequestProtocol, code: str) -> Awaitable[ResponseEnvelope[Contractor]]: ...
def Get(api: object, code: str) -> ResponseEnvelope[Contractor] | Awaitable[ResponseEnvelope[Contractor]]:
    params, data = _prepare_Get(code=code)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetByNIP(api: SyncInvokerProtocol, nip: str) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByNIP(api: SyncRequestProtocol, nip: str) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByNIP(api: AsyncInvokerProtocol, nip: str) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
@overload
def GetByNIP(api: AsyncRequestProtocol, nip: str) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
def GetByNIP(api: object, nip: str) -> ResponseEnvelope[List[Contractor]] | Awaitable[ResponseEnvelope[List[Contractor]]]:
    params, data = _prepare_GetByNIP(nip=nip)
    return invoke_operation(api, OP_GetByNIP, params=params, data=data)

@overload
def GetByPesel(api: SyncInvokerProtocol, pesel: str) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByPesel(api: SyncRequestProtocol, pesel: str) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByPesel(api: AsyncInvokerProtocol, pesel: str) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
@overload
def GetByPesel(api: AsyncRequestProtocol, pesel: str) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
def GetByPesel(api: object, pesel: str) -> ResponseEnvelope[List[Contractor]] | Awaitable[ResponseEnvelope[List[Contractor]]]:
    params, data = _prepare_GetByPesel(pesel=pesel)
    return invoke_operation(api, OP_GetByPesel, params=params, data=data)

@overload
def GetByPosition(api: SyncInvokerProtocol, position: int) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByPosition(api: SyncRequestProtocol, position: int) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByPosition(api: AsyncInvokerProtocol, position: int) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
@overload
def GetByPosition(api: AsyncRequestProtocol, position: int) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
def GetByPosition(api: object, position: int) -> ResponseEnvelope[List[Contractor]] | Awaitable[ResponseEnvelope[List[Contractor]]]:
    params, data = _prepare_GetByPosition(position=position)
    return invoke_operation(api, OP_GetByPosition, params=params, data=data)

@overload
def GetByNIPAndPosition(api: SyncInvokerProtocol, nip: str, position: int) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByNIPAndPosition(api: SyncRequestProtocol, nip: str, position: int) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByNIPAndPosition(api: AsyncInvokerProtocol, nip: str, position: int) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
@overload
def GetByNIPAndPosition(api: AsyncRequestProtocol, nip: str, position: int) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
def GetByNIPAndPosition(api: object, nip: str, position: int) -> ResponseEnvelope[List[Contractor]] | Awaitable[ResponseEnvelope[List[Contractor]]]:
    params, data = _prepare_GetByNIPAndPosition(nip=nip, position=position)
    return invoke_operation(api, OP_GetByNIPAndPosition, params=params, data=data)

@overload
def Filter(api: SyncInvokerProtocol, criteria: "ContractorFilterCriteria") -> ResponseEnvelope[List[ContractorListElement]]: ...
@overload
def Filter(api: SyncRequestProtocol, criteria: "ContractorFilterCriteria") -> ResponseEnvelope[List[ContractorListElement]]: ...
@overload
def Filter(api: AsyncInvokerProtocol, criteria: "ContractorFilterCriteria") -> Awaitable[ResponseEnvelope[List[ContractorListElement]]]: ...
@overload
def Filter(api: AsyncRequestProtocol, criteria: "ContractorFilterCriteria") -> Awaitable[ResponseEnvelope[List[ContractorListElement]]]: ...
def Filter(api: object, criteria: "ContractorFilterCriteria") -> ResponseEnvelope[List[ContractorListElement]] | Awaitable[ResponseEnvelope[List[ContractorListElement]]]:
    params, data = _prepare_Filter(criteria=criteria)
    return invoke_operation(api, OP_Filter, params=params, data=data)

@overload
def FilterWithDimensions(api: SyncInvokerProtocol, criteria: "ContractorFilterCriteria") -> ResponseEnvelope[List[ContractorListElementWithDimensions]]: ...
@overload
def FilterWithDimensions(api: SyncRequestProtocol, criteria: "ContractorFilterCriteria") -> ResponseEnvelope[List[ContractorListElementWithDimensions]]: ...
@overload
def FilterWithDimensions(api: AsyncInvokerProtocol, criteria: "ContractorFilterCriteria") -> Awaitable[ResponseEnvelope[List[ContractorListElementWithDimensions]]]: ...
@overload
def FilterWithDimensions(api: AsyncRequestProtocol, criteria: "ContractorFilterCriteria") -> Awaitable[ResponseEnvelope[List[ContractorListElementWithDimensions]]]: ...
def FilterWithDimensions(api: object, criteria: "ContractorFilterCriteria") -> ResponseEnvelope[List[ContractorListElementWithDimensions]] | Awaitable[ResponseEnvelope[List[ContractorListElementWithDimensions]]]:
    params, data = _prepare_FilterWithDimensions(criteria=criteria)
    return invoke_operation(api, OP_FilterWithDimensions, params=params, data=data)

@overload
def AddNew(api: SyncInvokerProtocol, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[Contractor]: ...
@overload
def AddNew(api: SyncRequestProtocol, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[Contractor]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, syncFk: bool, contractor: "Contractor") -> Awaitable[ResponseEnvelope[Contractor]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, syncFk: bool, contractor: "Contractor") -> Awaitable[ResponseEnvelope[Contractor]]: ...
def AddNew(api: object, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[Contractor] | Awaitable[ResponseEnvelope[Contractor]]:
    params, data = _prepare_AddNew(syncFk=syncFk, contractor=contractor)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Update(api: SyncInvokerProtocol, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, syncFk: bool, contractor: "Contractor") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, syncFk: bool, contractor: "Contractor") -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(syncFk=syncFk, contractor=contractor)
    return invoke_operation(api, OP_Update, params=params, data=data)

@overload
def SyncFK(api: SyncInvokerProtocol, contractorCode: str, isNew: bool) -> ResponseEnvelope[None]: ...
@overload
def SyncFK(api: SyncRequestProtocol, contractorCode: str, isNew: bool) -> ResponseEnvelope[None]: ...
@overload
def SyncFK(api: AsyncInvokerProtocol, contractorCode: str, isNew: bool) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def SyncFK(api: AsyncRequestProtocol, contractorCode: str, isNew: bool) -> Awaitable[ResponseEnvelope[None]]: ...
def SyncFK(api: object, contractorCode: str, isNew: bool) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_SyncFK(contractorCode=contractorCode, isNew=isNew)
    return invoke_operation(api, OP_SyncFK, params=params, data=data)

@overload
def IncrementalSync(api: SyncInvokerProtocol) -> ResponseEnvelope[List[IncrementalSyncListElement]]: ...
@overload
def IncrementalSync(api: SyncRequestProtocol) -> ResponseEnvelope[List[IncrementalSyncListElement]]: ...
@overload
def IncrementalSync(api: AsyncInvokerProtocol) -> Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]: ...
@overload
def IncrementalSync(api: AsyncRequestProtocol) -> Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]: ...
def IncrementalSync(api: object) -> ResponseEnvelope[List[IncrementalSyncListElement]] | Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]:
    params, data = _prepare_IncrementalSync()
    return invoke_operation(api, OP_IncrementalSync, params=params, data=data)

@overload
def FilterSql(api: SyncInvokerProtocol, criteriaFilter: "ContractorCriteriaFilter") -> ResponseEnvelope[List[ContractorListElement]]: ...
@overload
def FilterSql(api: SyncRequestProtocol, criteriaFilter: "ContractorCriteriaFilter") -> ResponseEnvelope[List[ContractorListElement]]: ...
@overload
def FilterSql(api: AsyncInvokerProtocol, criteriaFilter: "ContractorCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ContractorListElement]]]: ...
@overload
def FilterSql(api: AsyncRequestProtocol, criteriaFilter: "ContractorCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ContractorListElement]]]: ...
def FilterSql(api: object, criteriaFilter: "ContractorCriteriaFilter") -> ResponseEnvelope[List[ContractorListElement]] | Awaitable[ResponseEnvelope[List[ContractorListElement]]]:
    params, data = _prepare_FilterSql(criteriaFilter=criteriaFilter)
    return invoke_operation(api, OP_FilterSql, params=params, data=data)

@overload
def GetPagedDocument(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocument(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocument(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocument(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocument, params=params, data=data)

@overload
def GetPagedDocumentWithDimensions(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocumentWithDimensions(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocumentWithDimensions(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocumentWithDimensions(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocumentWithDimensions(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocumentWithDimensions(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocumentWithDimensions, params=params, data=data)

@overload
def FilterSqlWithDimensions(api: SyncInvokerProtocol, criteriaFilter: "ContractorCriteriaFilter") -> ResponseEnvelope[List[ContractorListElementWithDimensions]]: ...
@overload
def FilterSqlWithDimensions(api: SyncRequestProtocol, criteriaFilter: "ContractorCriteriaFilter") -> ResponseEnvelope[List[ContractorListElementWithDimensions]]: ...
@overload
def FilterSqlWithDimensions(api: AsyncInvokerProtocol, criteriaFilter: "ContractorCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ContractorListElementWithDimensions]]]: ...
@overload
def FilterSqlWithDimensions(api: AsyncRequestProtocol, criteriaFilter: "ContractorCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ContractorListElementWithDimensions]]]: ...
def FilterSqlWithDimensions(api: object, criteriaFilter: "ContractorCriteriaFilter") -> ResponseEnvelope[List[ContractorListElementWithDimensions]] | Awaitable[ResponseEnvelope[List[ContractorListElementWithDimensions]]]:
    params, data = _prepare_FilterSqlWithDimensions(criteriaFilter=criteriaFilter)
    return invoke_operation(api, OP_FilterSqlWithDimensions, params=params, data=data)

__all__ = ["Get", "GetByNIP", "GetByPesel", "GetByPosition", "GetByNIPAndPosition", "Filter", "FilterWithDimensions", "AddNew", "Update", "SyncFK", "IncrementalSync", "FilterSql", "GetPagedDocument", "GetPagedDocumentWithDimensions", "FilterSqlWithDimensions"]
