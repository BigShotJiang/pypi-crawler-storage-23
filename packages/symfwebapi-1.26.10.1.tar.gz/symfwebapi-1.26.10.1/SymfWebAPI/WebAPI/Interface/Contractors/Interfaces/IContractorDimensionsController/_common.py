from __future__ import annotations

from typing import Any

import json

_REQUEST_Get = ('GET', '/api/ContractorDimensions')
def _prepare_Get(*, contractorCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/ContractorDimensions/UpdateList')
def _prepare_Update(*, contractorCode, contractorDimensions) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = json.dumps(contractorDimensions) if contractorDimensions is not None else None
    return params or None, data
