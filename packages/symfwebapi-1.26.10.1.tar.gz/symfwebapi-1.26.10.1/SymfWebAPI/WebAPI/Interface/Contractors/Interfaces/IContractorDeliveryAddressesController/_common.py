from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/ContractorDeliveryAddresses')
def _prepare_Get(*, contractorCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = None
    return params or None, data

_REQUEST_AddNew = ('POST', '/api/ContractorDeliveryAddresses/Create')
def _prepare_AddNew(*, contractorCode, contractorDeliveryAddress) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = contractorDeliveryAddress.model_dump_json(exclude_unset=True) if contractorDeliveryAddress is not None else None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/ContractorDeliveryAddresses/Update')
def _prepare_Update(*, contractorCode, contractorDeliveryAddress) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = contractorDeliveryAddress.model_dump_json(exclude_unset=True) if contractorDeliveryAddress is not None else None
    return params or None, data
