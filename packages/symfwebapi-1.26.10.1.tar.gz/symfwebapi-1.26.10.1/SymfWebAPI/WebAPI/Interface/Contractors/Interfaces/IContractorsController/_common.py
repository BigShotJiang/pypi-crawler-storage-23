from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/Contractors')
def _prepare_Get(*, code) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["code"] = code
    data = None
    return params or None, data

_REQUEST_GetByNIP = ('GET', '/api/Contractors')
def _prepare_GetByNIP(*, nip) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["nip"] = nip
    data = None
    return params or None, data

_REQUEST_GetByPesel = ('GET', '/api/Contractors')
def _prepare_GetByPesel(*, pesel) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["pesel"] = pesel
    data = None
    return params or None, data

_REQUEST_GetByPosition = ('GET', '/api/Contractors')
def _prepare_GetByPosition(*, position) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["position"] = position
    data = None
    return params or None, data

_REQUEST_GetByNIPAndPosition = ('GET', '/api/Contractors')
def _prepare_GetByNIPAndPosition(*, nip, position) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["nip"] = nip
    params["position"] = position
    data = None
    return params or None, data

_REQUEST_Filter = ('PATCH', '/api/Contractors/Filter')
def _prepare_Filter(*, criteria) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteria.model_dump_json(exclude_unset=True) if criteria is not None else None
    return params or None, data

_REQUEST_FilterWithDimensions = ('PATCH', '/api/Contractors/Filter/WithDimensions')
def _prepare_FilterWithDimensions(*, criteria) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteria.model_dump_json(exclude_unset=True) if criteria is not None else None
    return params or None, data

_REQUEST_AddNew = ('POST', '/api/Contractors/Create')
def _prepare_AddNew(*, syncFk, contractor) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["syncFk"] = syncFk
    data = contractor.model_dump_json(exclude_unset=True) if contractor is not None else None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/Contractors/Update')
def _prepare_Update(*, syncFk, contractor) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["syncFk"] = syncFk
    data = contractor.model_dump_json(exclude_unset=True) if contractor is not None else None
    return params or None, data

_REQUEST_SyncFK = ('PATCH', '/api/Contractors/SyncFK')
def _prepare_SyncFK(*, contractorCode, isNew) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    params["isNew"] = isNew
    data = None
    return params or None, data

_REQUEST_IncrementalSync = ('GET', '/api/Contractors/IncrementalSync')
def _prepare_IncrementalSync() -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = None
    return params or None, data

_REQUEST_FilterSql = ('PATCH', '/api/Contractors/FilterSql')
def _prepare_FilterSql(*, criteriaFilter) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteriaFilter.model_dump_json(exclude_unset=True) if criteriaFilter is not None else None
    return params or None, data

_REQUEST_GetPagedDocument = ('GET', '/api/Contractors/Page')
def _prepare_GetPagedDocument(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data

_REQUEST_GetPagedDocumentWithDimensions = ('GET', '/api/Contractors/PageWithDimensions')
def _prepare_GetPagedDocumentWithDimensions(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data

_REQUEST_FilterSqlWithDimensions = ('PATCH', '/api/Contractors/FilterSql/WithDimensions')
def _prepare_FilterSqlWithDimensions(*, criteriaFilter) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteriaFilter.model_dump_json(exclude_unset=True) if criteriaFilter is not None else None
    return params or None, data
