from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels.V2026_1 import Contractor
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels import ContractorCriteriaFilter
from SymfWebAPI.WebAPI.Interface.Contractors.ViewModels import ContractorFilterCriteria
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels import ContractorListElement
from SymfWebAPI.WebAPI.Interface.Contractors.ViewModels import ContractorListElementWithDimensions
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import IncrementalSyncListElement
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

_ADAPTER_Get = TypeAdapter(Contractor)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Contractor]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/Contractors', parser=_parse_Get)

_ADAPTER_GetByNIP = TypeAdapter(List[Contractor])

def _parse_GetByNIP(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Contractor]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByNIP)
OP_GetByNIP = OperationSpec(method='GET', path='/api/Contractors', parser=_parse_GetByNIP)

_ADAPTER_GetByPesel = TypeAdapter(List[Contractor])

def _parse_GetByPesel(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Contractor]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByPesel)
OP_GetByPesel = OperationSpec(method='GET', path='/api/Contractors', parser=_parse_GetByPesel)

_ADAPTER_GetByPosition = TypeAdapter(List[Contractor])

def _parse_GetByPosition(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Contractor]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByPosition)
OP_GetByPosition = OperationSpec(method='GET', path='/api/Contractors', parser=_parse_GetByPosition)

_ADAPTER_GetByNIPAndPosition = TypeAdapter(List[Contractor])

def _parse_GetByNIPAndPosition(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Contractor]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByNIPAndPosition)
OP_GetByNIPAndPosition = OperationSpec(method='GET', path='/api/Contractors', parser=_parse_GetByNIPAndPosition)

_ADAPTER_Filter = TypeAdapter(List[ContractorListElement])

def _parse_Filter(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ContractorListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_Filter)
OP_Filter = OperationSpec(method='PATCH', path='/api/Contractors/Filter', parser=_parse_Filter)

_ADAPTER_FilterWithDimensions = TypeAdapter(List[ContractorListElementWithDimensions])

def _parse_FilterWithDimensions(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ContractorListElementWithDimensions]]:
    return parse_with_adapter(envelope, _ADAPTER_FilterWithDimensions)
OP_FilterWithDimensions = OperationSpec(method='PATCH', path='/api/Contractors/Filter/WithDimensions', parser=_parse_FilterWithDimensions)

_ADAPTER_AddNew = TypeAdapter(Contractor)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Contractor]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/Contractors/Create', parser=_parse_AddNew)

def _parse_Update(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Update = OperationSpec(method='PUT', path='/api/Contractors/Update', parser=_parse_Update)

def _parse_SyncFK(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_SyncFK = OperationSpec(method='PATCH', path='/api/Contractors/SyncFK', parser=_parse_SyncFK)

_ADAPTER_IncrementalSync = TypeAdapter(List[IncrementalSyncListElement])

def _parse_IncrementalSync(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[IncrementalSyncListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_IncrementalSync)
OP_IncrementalSync = OperationSpec(method='GET', path='/api/Contractors/IncrementalSync', parser=_parse_IncrementalSync)

_ADAPTER_FilterSql = TypeAdapter(List[ContractorListElement])

def _parse_FilterSql(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ContractorListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_FilterSql)
OP_FilterSql = OperationSpec(method='PATCH', path='/api/Contractors/FilterSql', parser=_parse_FilterSql)

_ADAPTER_GetPagedDocument = TypeAdapter(Page)

def _parse_GetPagedDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocument)
OP_GetPagedDocument = OperationSpec(method='GET', path='/api/Contractors/Page', parser=_parse_GetPagedDocument)

_ADAPTER_GetPagedDocumentWithDimensions = TypeAdapter(Page)

def _parse_GetPagedDocumentWithDimensions(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocumentWithDimensions)
OP_GetPagedDocumentWithDimensions = OperationSpec(method='GET', path='/api/Contractors/PageWithDimensions', parser=_parse_GetPagedDocumentWithDimensions)

_ADAPTER_FilterSqlWithDimensions = TypeAdapter(List[ContractorListElementWithDimensions])

def _parse_FilterSqlWithDimensions(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ContractorListElementWithDimensions]]:
    return parse_with_adapter(envelope, _ADAPTER_FilterSqlWithDimensions)
OP_FilterSqlWithDimensions = OperationSpec(method='PATCH', path='/api/Contractors/FilterSql/WithDimensions', parser=_parse_FilterSqlWithDimensions)
