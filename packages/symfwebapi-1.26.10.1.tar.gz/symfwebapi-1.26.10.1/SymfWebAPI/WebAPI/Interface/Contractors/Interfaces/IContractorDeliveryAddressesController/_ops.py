from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Contractors.ViewModels import ContractorDeliveryAddress

_ADAPTER_Get = TypeAdapter(List[ContractorDeliveryAddress])

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ContractorDeliveryAddress]]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/ContractorDeliveryAddresses', parser=_parse_Get)

_ADAPTER_AddNew = TypeAdapter(List[ContractorDeliveryAddress])

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ContractorDeliveryAddress]]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/ContractorDeliveryAddresses/Create', parser=_parse_AddNew)

def _parse_Update(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Update = OperationSpec(method='PUT', path='/api/ContractorDeliveryAddresses/Update', parser=_parse_Update)
