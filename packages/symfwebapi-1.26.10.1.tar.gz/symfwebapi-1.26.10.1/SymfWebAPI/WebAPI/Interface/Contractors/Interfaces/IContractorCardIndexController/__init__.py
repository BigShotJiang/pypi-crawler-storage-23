from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from ._common import (
    _prepare_GetByIdAsync,
    _prepare_GetByCodeAsync,
    _prepare_GetByNIPAsync,
)
from ._ops import (
    OP_GetByIdAsync,
    OP_GetByCodeAsync,
    OP_GetByNIPAsync,
)

@overload
def GetByIdAsync(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[None]: ...
@overload
def GetByIdAsync(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[None]: ...
@overload
def GetByIdAsync(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def GetByIdAsync(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[None]]: ...
def GetByIdAsync(api: object, id: int) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_GetByIdAsync(id=id)
    return invoke_operation(api, OP_GetByIdAsync, params=params, data=data)

@overload
def GetByCodeAsync(api: SyncInvokerProtocol, code: str) -> ResponseEnvelope[None]: ...
@overload
def GetByCodeAsync(api: SyncRequestProtocol, code: str) -> ResponseEnvelope[None]: ...
@overload
def GetByCodeAsync(api: AsyncInvokerProtocol, code: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def GetByCodeAsync(api: AsyncRequestProtocol, code: str) -> Awaitable[ResponseEnvelope[None]]: ...
def GetByCodeAsync(api: object, code: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_GetByCodeAsync(code=code)
    return invoke_operation(api, OP_GetByCodeAsync, params=params, data=data)

@overload
def GetByNIPAsync(api: SyncInvokerProtocol, nip: str) -> ResponseEnvelope[None]: ...
@overload
def GetByNIPAsync(api: SyncRequestProtocol, nip: str) -> ResponseEnvelope[None]: ...
@overload
def GetByNIPAsync(api: AsyncInvokerProtocol, nip: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def GetByNIPAsync(api: AsyncRequestProtocol, nip: str) -> Awaitable[ResponseEnvelope[None]]: ...
def GetByNIPAsync(api: object, nip: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_GetByNIPAsync(nip=nip)
    return invoke_operation(api, OP_GetByNIPAsync, params=params, data=data)

__all__ = ["GetByIdAsync", "GetByCodeAsync", "GetByNIPAsync"]
