from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope

def _parse_GetByIdAsync(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_GetByIdAsync = OperationSpec(method='GET', path='/api/Contractors', parser=_parse_GetByIdAsync)

def _parse_GetByCodeAsync(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_GetByCodeAsync = OperationSpec(method='GET', path='/api/Contractors', parser=_parse_GetByCodeAsync)

def _parse_GetByNIPAsync(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_GetByNIPAsync = OperationSpec(method='GET', path='/api/Contractors', parser=_parse_GetByNIPAsync)
