from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/v2/ContractorDimensions')
def _prepare_Get(*, contractorCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = None
    return params or None, data
