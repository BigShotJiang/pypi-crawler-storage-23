from __future__ import annotations

from typing import Any

_REQUEST_Fiscalize = ('PATCH', '/api/FiscalPrinter/Fiscalize')
def _prepare_Fiscalize(*, documentId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentId"] = documentId
    data = None
    return params or None, data
