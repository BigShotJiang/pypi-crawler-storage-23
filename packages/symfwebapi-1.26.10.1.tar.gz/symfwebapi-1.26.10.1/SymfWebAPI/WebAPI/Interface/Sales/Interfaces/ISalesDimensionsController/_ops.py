from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels.Aspects import AspectDocument
from SymfWebAPI.WebAPI.Interface.Common.ViewModels.Aspects import AspectPositionEdit
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PositionDimension

_ADAPTER_Get = TypeAdapter(List[Dimension])

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Dimension]]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/SalesDimensions', parser=_parse_Get)

_ADAPTER_GetPositionsByDocumentId = TypeAdapter(List[PositionDimension])

def _parse_GetPositionsByDocumentId(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PositionDimension]]:
    return parse_with_adapter(envelope, _ADAPTER_GetPositionsByDocumentId)
OP_GetPositionsByDocumentId = OperationSpec(method='GET', path='/api/SalesDimensions/Positions', parser=_parse_GetPositionsByDocumentId)

_ADAPTER_GetPositionsByDocumentNumber = TypeAdapter(List[PositionDimension])

def _parse_GetPositionsByDocumentNumber(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PositionDimension]]:
    return parse_with_adapter(envelope, _ADAPTER_GetPositionsByDocumentNumber)
OP_GetPositionsByDocumentNumber = OperationSpec(method='GET', path='/api/SalesDimensions/Positions', parser=_parse_GetPositionsByDocumentNumber)

_ADAPTER_GetPosition = TypeAdapter(List[Dimension])

def _parse_GetPosition(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Dimension]]:
    return parse_with_adapter(envelope, _ADAPTER_GetPosition)
OP_GetPosition = OperationSpec(method='GET', path='/api/SalesDimensions/Positions', parser=_parse_GetPosition)

def _parse_Update(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Update = OperationSpec(method='PUT', path='/api/SalesDimensions/UpdateList', parser=_parse_Update)

def _parse_UpdatePosition(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_UpdatePosition = OperationSpec(method='PUT', path='/api/SalesDimensions/UpdateMultiPositionsList', parser=_parse_UpdatePosition)

_ADAPTER_GetAspects = TypeAdapter(AspectDocument)

def _parse_GetAspects(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[AspectDocument]:
    return parse_with_adapter(envelope, _ADAPTER_GetAspects)
OP_GetAspects = OperationSpec(method='GET', path='/api/SalesDimensions/Aspects', parser=_parse_GetAspects)

def _parse_UpdateAspect(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_UpdateAspect = OperationSpec(method='PUT', path='/api/SalesDimensions/Aspects', parser=_parse_UpdateAspect)
