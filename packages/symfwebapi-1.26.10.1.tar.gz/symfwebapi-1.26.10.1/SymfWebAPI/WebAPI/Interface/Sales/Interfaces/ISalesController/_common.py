from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/Sales')
def _prepare_Get(*, number, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetList = ('GET', '/api/Sales/Filter')
def _prepare_GetList(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByBuyer = ('GET', '/api/Sales/Filter')
def _prepare_GetListByBuyer(*, buyerCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["buyerCode"] = buyerCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByRecipient = ('GET', '/api/Sales/Filter')
def _prepare_GetListByRecipient(*, recipientCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["recipientCode"] = recipientCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByDimension = ('GET', '/api/Sales/Filter')
def _prepare_GetListByDimension(*, dimensionCode, dictionaryValue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dimensionCode"] = dimensionCode
    params["dictionaryValue"] = dictionaryValue
    data = None
    return params or None, data

_REQUEST_GetWZ = ('GET', '/api/Sales/WZ')
def _prepare_GetWZ(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetZMO = ('GET', '/api/Sales/ZMO')
def _prepare_GetZMO(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetStatus = ('GET', '/api/Sales/Status')
def _prepare_GetStatus(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetDocumentSeries = ('GET', '/api/Sales/DocumentSeries')
def _prepare_GetDocumentSeries(*, documentTypeId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentTypeId"] = documentTypeId
    data = None
    return params or None, data

_REQUEST_GetPDF = ('PATCH', '/api/Sales/PDF')
def _prepare_GetPDF(*, documentNumber, buffer, settings) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = settings.model_dump_json(exclude_unset=True) if settings is not None else None
    return params or None, data

_REQUEST_GetCorrection = ('GET', '/api/Sales/Correction')
def _prepare_GetCorrection(*, number, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetCorrectionSequence = ('GET', '/api/Sales/CorrectionSequence')
def _prepare_GetCorrectionSequence(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_IncrementalSync = ('GET', '/api/Sales/IncrementalSync')
def _prepare_IncrementalSync() -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = None
    return params or None, data

_REQUEST_GetPagedDocument = ('GET', '/api/Sales/Page')
def _prepare_GetPagedDocument(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data

_REQUEST_GetDocumentTypesWithRange = ('GET', '/api/Sales/Filter/ByDocumentTypes')
def _prepare_GetDocumentTypesWithRange(*, dateFrom, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data
