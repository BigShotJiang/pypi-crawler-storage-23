from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import FiscalizationResult
from ._common import (
    _prepare_Fiscalize,
)
from ._ops import (
    OP_Fiscalize,
)

@overload
def Fiscalize(api: SyncInvokerProtocol, documentId: int) -> ResponseEnvelope[FiscalizationResult]: ...
@overload
def Fiscalize(api: SyncRequestProtocol, documentId: int) -> ResponseEnvelope[FiscalizationResult]: ...
@overload
def Fiscalize(api: AsyncInvokerProtocol, documentId: int) -> Awaitable[ResponseEnvelope[FiscalizationResult]]: ...
@overload
def Fiscalize(api: AsyncRequestProtocol, documentId: int) -> Awaitable[ResponseEnvelope[FiscalizationResult]]: ...
def Fiscalize(api: object, documentId: int) -> ResponseEnvelope[FiscalizationResult] | Awaitable[ResponseEnvelope[FiscalizationResult]]:
    params, data = _prepare_Fiscalize(documentId=documentId)
    return invoke_operation(api, OP_Fiscalize, params=params, data=data)

__all__ = ["Fiscalize"]
