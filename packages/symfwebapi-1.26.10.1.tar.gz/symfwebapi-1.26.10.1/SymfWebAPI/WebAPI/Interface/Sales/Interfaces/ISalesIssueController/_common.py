from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/SalesIssue/NewCorrection')
def _prepare_AddNew(*, issue, correction) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["issue"] = issue
    data = correction.model_dump_json(exclude_unset=True) if correction is not None else None
    return params or None, data

_REQUEST_Issue = ('PUT', '/api/SalesIssue/InBuffer')
def _prepare_Issue(*, number) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    data = None
    return params or None, data

_REQUEST_IssueAdvancePayment = ('PUT', '/api/SalesIssue/AdvancePayment')
def _prepare_IssueAdvancePayment(*, documentNumber, options) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    data = options.model_dump_json(exclude_unset=True) if options is not None else None
    return params or None, data

_REQUEST_IssueWZ = ('PUT', '/api/SalesIssue/WZ')
def _prepare_IssueWZ(*, documentNumber, inBuffer = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    if inBuffer is not None:
        params["inBuffer"] = inBuffer
    data = None
    return params or None, data

_REQUEST_IssueWZCorrection = ('PUT', '/api/SalesIssue/IssueWZCorrection')
def _prepare_IssueWZCorrection(*, documentNumber, issue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["issue"] = issue
    data = None
    return params or None, data

_REQUEST_ChangeDocumentNumber = ('PATCH', '/api/SalesIssue/DocumentNumber')
def _prepare_ChangeDocumentNumber(*, id, number) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    params["number"] = number
    data = None
    return params or None, data

_REQUEST_IssuePN = ('PUT', '/api/SalesIssue/IssuePayment')
def _prepare_IssuePN(*, documentNumber) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    data = None
    return params or None, data

_REQUEST_ChangeFiscalStatus = ('PATCH', '/api/SalesIssue/FiscalStatus')
def _prepare_ChangeFiscalStatus(*, documentNumber) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    data = None
    return params or None, data
