from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import FiscalizationResult

_ADAPTER_Fiscalize = TypeAdapter(FiscalizationResult)

def _parse_Fiscalize(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[FiscalizationResult]:
    return parse_with_adapter(envelope, _ADAPTER_Fiscalize)
OP_Fiscalize = OperationSpec(method='PATCH', path='/api/FiscalPrinter/Fiscalize', parser=_parse_Fiscalize)
