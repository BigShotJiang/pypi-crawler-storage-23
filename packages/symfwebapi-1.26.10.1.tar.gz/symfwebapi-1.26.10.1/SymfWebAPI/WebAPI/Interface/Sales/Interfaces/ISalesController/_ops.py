from __future__ import annotations

from typing import List, Optional
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import FilterDocumentType
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import IncrementalSyncListElement
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDFSettings
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleCorrection
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocument
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentCorrection
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentListElement
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentStatus
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentWZ
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentZMO
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

_ADAPTER_Get = TypeAdapter(SaleDocument)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[SaleDocument]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/Sales', parser=_parse_Get)

_ADAPTER_GetList = TypeAdapter(List[SaleDocumentListElement])

def _parse_GetList(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SaleDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetList)
OP_GetList = OperationSpec(method='GET', path='/api/Sales/Filter', parser=_parse_GetList)

_ADAPTER_GetListByBuyer = TypeAdapter(List[SaleDocumentListElement])

def _parse_GetListByBuyer(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SaleDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByBuyer)
OP_GetListByBuyer = OperationSpec(method='GET', path='/api/Sales/Filter', parser=_parse_GetListByBuyer)

_ADAPTER_GetListByRecipient = TypeAdapter(List[SaleDocumentListElement])

def _parse_GetListByRecipient(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SaleDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByRecipient)
OP_GetListByRecipient = OperationSpec(method='GET', path='/api/Sales/Filter', parser=_parse_GetListByRecipient)

_ADAPTER_GetListByDimension = TypeAdapter(List[SaleDocumentListElement])

def _parse_GetListByDimension(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SaleDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByDimension)
OP_GetListByDimension = OperationSpec(method='GET', path='/api/Sales/Filter', parser=_parse_GetListByDimension)

_ADAPTER_GetWZ = TypeAdapter(List[SaleDocumentWZ])

def _parse_GetWZ(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SaleDocumentWZ]]:
    return parse_with_adapter(envelope, _ADAPTER_GetWZ)
OP_GetWZ = OperationSpec(method='GET', path='/api/Sales/WZ', parser=_parse_GetWZ)

_ADAPTER_GetZMO = TypeAdapter(List[SaleDocumentZMO])

def _parse_GetZMO(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SaleDocumentZMO]]:
    return parse_with_adapter(envelope, _ADAPTER_GetZMO)
OP_GetZMO = OperationSpec(method='GET', path='/api/Sales/ZMO', parser=_parse_GetZMO)

_ADAPTER_GetStatus = TypeAdapter(SaleDocumentStatus)

def _parse_GetStatus(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[SaleDocumentStatus]:
    return parse_with_adapter(envelope, _ADAPTER_GetStatus)
OP_GetStatus = OperationSpec(method='GET', path='/api/Sales/Status', parser=_parse_GetStatus)

_ADAPTER_GetDocumentSeries = TypeAdapter(List[DocumentSeries])

def _parse_GetDocumentSeries(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentSeries]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentSeries)
OP_GetDocumentSeries = OperationSpec(method='GET', path='/api/Sales/DocumentSeries', parser=_parse_GetDocumentSeries)

_ADAPTER_GetPDF = TypeAdapter(PDF)

def _parse_GetPDF(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PDF]:
    return parse_with_adapter(envelope, _ADAPTER_GetPDF)
OP_GetPDF = OperationSpec(method='PATCH', path='/api/Sales/PDF', parser=_parse_GetPDF)

_ADAPTER_GetCorrection = TypeAdapter(SaleCorrection)

def _parse_GetCorrection(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[SaleCorrection]:
    return parse_with_adapter(envelope, _ADAPTER_GetCorrection)
OP_GetCorrection = OperationSpec(method='GET', path='/api/Sales/Correction', parser=_parse_GetCorrection)

_ADAPTER_GetCorrectionSequence = TypeAdapter(List[SaleDocumentCorrection])

def _parse_GetCorrectionSequence(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SaleDocumentCorrection]]:
    return parse_with_adapter(envelope, _ADAPTER_GetCorrectionSequence)
OP_GetCorrectionSequence = OperationSpec(method='GET', path='/api/Sales/CorrectionSequence', parser=_parse_GetCorrectionSequence)

_ADAPTER_IncrementalSync = TypeAdapter(List[IncrementalSyncListElement])

def _parse_IncrementalSync(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[IncrementalSyncListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_IncrementalSync)
OP_IncrementalSync = OperationSpec(method='GET', path='/api/Sales/IncrementalSync', parser=_parse_IncrementalSync)

_ADAPTER_GetPagedDocument = TypeAdapter(Page)

def _parse_GetPagedDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocument)
OP_GetPagedDocument = OperationSpec(method='GET', path='/api/Sales/Page', parser=_parse_GetPagedDocument)

_ADAPTER_GetDocumentTypesWithRange = TypeAdapter(List[SaleDocumentListElement])

def _parse_GetDocumentTypesWithRange(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SaleDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentTypesWithRange)
OP_GetDocumentTypesWithRange = OperationSpec(method='GET', path='/api/Sales/Filter/ByDocumentTypes', parser=_parse_GetDocumentTypesWithRange)
