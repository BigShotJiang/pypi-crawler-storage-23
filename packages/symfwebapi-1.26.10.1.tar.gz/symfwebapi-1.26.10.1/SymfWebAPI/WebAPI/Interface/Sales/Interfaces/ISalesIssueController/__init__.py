from __future__ import annotations

from typing import Awaitable, List, Optional, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import AdvancePaymentOptions
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleCorrection
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels.CorrectionIssue.V2026_1 import SaleCorrectionIssue
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocument
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentWZ
from ._common import (
    _prepare_AddNew,
    _prepare_Issue,
    _prepare_IssueAdvancePayment,
    _prepare_IssueWZ,
    _prepare_IssueWZCorrection,
    _prepare_ChangeDocumentNumber,
    _prepare_IssuePN,
    _prepare_ChangeFiscalStatus,
)
from ._ops import (
    OP_AddNew,
    OP_Issue,
    OP_IssueAdvancePayment,
    OP_IssueWZ,
    OP_IssueWZCorrection,
    OP_ChangeDocumentNumber,
    OP_IssuePN,
    OP_ChangeFiscalStatus,
)

@overload
def AddNew(api: SyncInvokerProtocol, issue: bool, correction: "SaleCorrectionIssue") -> ResponseEnvelope[SaleCorrection]: ...
@overload
def AddNew(api: SyncRequestProtocol, issue: bool, correction: "SaleCorrectionIssue") -> ResponseEnvelope[SaleCorrection]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, issue: bool, correction: "SaleCorrectionIssue") -> Awaitable[ResponseEnvelope[SaleCorrection]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, issue: bool, correction: "SaleCorrectionIssue") -> Awaitable[ResponseEnvelope[SaleCorrection]]: ...
def AddNew(api: object, issue: bool, correction: "SaleCorrectionIssue") -> ResponseEnvelope[SaleCorrection] | Awaitable[ResponseEnvelope[SaleCorrection]]:
    params, data = _prepare_AddNew(issue=issue, correction=correction)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Issue(api: SyncInvokerProtocol, number: str) -> ResponseEnvelope[SaleDocument]: ...
@overload
def Issue(api: SyncRequestProtocol, number: str) -> ResponseEnvelope[SaleDocument]: ...
@overload
def Issue(api: AsyncInvokerProtocol, number: str) -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
@overload
def Issue(api: AsyncRequestProtocol, number: str) -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
def Issue(api: object, number: str) -> ResponseEnvelope[SaleDocument] | Awaitable[ResponseEnvelope[SaleDocument]]:
    params, data = _prepare_Issue(number=number)
    return invoke_operation(api, OP_Issue, params=params, data=data)

@overload
def IssueAdvancePayment(api: SyncInvokerProtocol, documentNumber: str, options: "AdvancePaymentOptions") -> ResponseEnvelope[SaleDocument]: ...
@overload
def IssueAdvancePayment(api: SyncRequestProtocol, documentNumber: str, options: "AdvancePaymentOptions") -> ResponseEnvelope[SaleDocument]: ...
@overload
def IssueAdvancePayment(api: AsyncInvokerProtocol, documentNumber: str, options: "AdvancePaymentOptions") -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
@overload
def IssueAdvancePayment(api: AsyncRequestProtocol, documentNumber: str, options: "AdvancePaymentOptions") -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
def IssueAdvancePayment(api: object, documentNumber: str, options: "AdvancePaymentOptions") -> ResponseEnvelope[SaleDocument] | Awaitable[ResponseEnvelope[SaleDocument]]:
    params, data = _prepare_IssueAdvancePayment(documentNumber=documentNumber, options=options)
    return invoke_operation(api, OP_IssueAdvancePayment, params=params, data=data)

@overload
def IssueWZ(api: SyncInvokerProtocol, documentNumber: str, inBuffer: Optional[int] = None) -> ResponseEnvelope[List[SaleDocumentWZ]]: ...
@overload
def IssueWZ(api: SyncRequestProtocol, documentNumber: str, inBuffer: Optional[int] = None) -> ResponseEnvelope[List[SaleDocumentWZ]]: ...
@overload
def IssueWZ(api: AsyncInvokerProtocol, documentNumber: str, inBuffer: Optional[int] = None) -> Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]: ...
@overload
def IssueWZ(api: AsyncRequestProtocol, documentNumber: str, inBuffer: Optional[int] = None) -> Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]: ...
def IssueWZ(api: object, documentNumber: str, inBuffer: Optional[int] = None) -> ResponseEnvelope[List[SaleDocumentWZ]] | Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]:
    params, data = _prepare_IssueWZ(documentNumber=documentNumber, inBuffer=inBuffer)
    return invoke_operation(api, OP_IssueWZ, params=params, data=data)

@overload
def IssueWZCorrection(api: SyncInvokerProtocol, documentNumber: str, issue: bool) -> ResponseEnvelope[List[SaleDocumentWZ]]: ...
@overload
def IssueWZCorrection(api: SyncRequestProtocol, documentNumber: str, issue: bool) -> ResponseEnvelope[List[SaleDocumentWZ]]: ...
@overload
def IssueWZCorrection(api: AsyncInvokerProtocol, documentNumber: str, issue: bool) -> Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]: ...
@overload
def IssueWZCorrection(api: AsyncRequestProtocol, documentNumber: str, issue: bool) -> Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]: ...
def IssueWZCorrection(api: object, documentNumber: str, issue: bool) -> ResponseEnvelope[List[SaleDocumentWZ]] | Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]:
    params, data = _prepare_IssueWZCorrection(documentNumber=documentNumber, issue=issue)
    return invoke_operation(api, OP_IssueWZCorrection, params=params, data=data)

@overload
def ChangeDocumentNumber(api: SyncInvokerProtocol, id: int, number: str) -> ResponseEnvelope[None]: ...
@overload
def ChangeDocumentNumber(api: SyncRequestProtocol, id: int, number: str) -> ResponseEnvelope[None]: ...
@overload
def ChangeDocumentNumber(api: AsyncInvokerProtocol, id: int, number: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def ChangeDocumentNumber(api: AsyncRequestProtocol, id: int, number: str) -> Awaitable[ResponseEnvelope[None]]: ...
def ChangeDocumentNumber(api: object, id: int, number: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_ChangeDocumentNumber(id=id, number=number)
    return invoke_operation(api, OP_ChangeDocumentNumber, params=params, data=data)

@overload
def IssuePN(api: SyncInvokerProtocol, documentNumber: str) -> ResponseEnvelope[None]: ...
@overload
def IssuePN(api: SyncRequestProtocol, documentNumber: str) -> ResponseEnvelope[None]: ...
@overload
def IssuePN(api: AsyncInvokerProtocol, documentNumber: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def IssuePN(api: AsyncRequestProtocol, documentNumber: str) -> Awaitable[ResponseEnvelope[None]]: ...
def IssuePN(api: object, documentNumber: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_IssuePN(documentNumber=documentNumber)
    return invoke_operation(api, OP_IssuePN, params=params, data=data)

@overload
def ChangeFiscalStatus(api: SyncInvokerProtocol, documentNumber: str) -> ResponseEnvelope[None]: ...
@overload
def ChangeFiscalStatus(api: SyncRequestProtocol, documentNumber: str) -> ResponseEnvelope[None]: ...
@overload
def ChangeFiscalStatus(api: AsyncInvokerProtocol, documentNumber: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def ChangeFiscalStatus(api: AsyncRequestProtocol, documentNumber: str) -> Awaitable[ResponseEnvelope[None]]: ...
def ChangeFiscalStatus(api: object, documentNumber: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_ChangeFiscalStatus(documentNumber=documentNumber)
    return invoke_operation(api, OP_ChangeFiscalStatus, params=params, data=data)

__all__ = ["AddNew", "Issue", "IssueAdvancePayment", "IssueWZ", "IssueWZCorrection", "ChangeDocumentNumber", "IssuePN", "ChangeFiscalStatus"]
