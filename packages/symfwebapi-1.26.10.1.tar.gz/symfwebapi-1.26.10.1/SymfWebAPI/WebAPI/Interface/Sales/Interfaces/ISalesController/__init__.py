from __future__ import annotations

from typing import Awaitable, List, Optional, overload
from datetime import datetime
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import FilterDocumentType
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import IncrementalSyncListElement
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDFSettings
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleCorrection
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocument
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentCorrection
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentListElement
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentStatus
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentWZ
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentZMO
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType
from ._common import (
    _prepare_Get,
    _prepare_GetList,
    _prepare_GetListByBuyer,
    _prepare_GetListByRecipient,
    _prepare_GetListByDimension,
    _prepare_GetWZ,
    _prepare_GetZMO,
    _prepare_GetStatus,
    _prepare_GetDocumentSeries,
    _prepare_GetPDF,
    _prepare_GetCorrection,
    _prepare_GetCorrectionSequence,
    _prepare_IncrementalSync,
    _prepare_GetPagedDocument,
    _prepare_GetDocumentTypesWithRange,
)
from ._ops import (
    OP_Get,
    OP_GetList,
    OP_GetListByBuyer,
    OP_GetListByRecipient,
    OP_GetListByDimension,
    OP_GetWZ,
    OP_GetZMO,
    OP_GetStatus,
    OP_GetDocumentSeries,
    OP_GetPDF,
    OP_GetCorrection,
    OP_GetCorrectionSequence,
    OP_IncrementalSync,
    OP_GetPagedDocument,
    OP_GetDocumentTypesWithRange,
)

@overload
def Get(api: SyncInvokerProtocol, number: str, buffer: bool) -> ResponseEnvelope[SaleDocument]: ...
@overload
def Get(api: SyncRequestProtocol, number: str, buffer: bool) -> ResponseEnvelope[SaleDocument]: ...
@overload
def Get(api: AsyncInvokerProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
@overload
def Get(api: AsyncRequestProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
def Get(api: object, number: str, buffer: bool) -> ResponseEnvelope[SaleDocument] | Awaitable[ResponseEnvelope[SaleDocument]]:
    params, data = _prepare_Get(number=number, buffer=buffer)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetList(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]]: ...
@overload
def GetList(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]]: ...
@overload
def GetList(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]: ...
@overload
def GetList(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]: ...
def GetList(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]] | Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]:
    params, data = _prepare_GetList(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetList, params=params, data=data)

@overload
def GetListByBuyer(api: SyncInvokerProtocol, buyerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]]: ...
@overload
def GetListByBuyer(api: SyncRequestProtocol, buyerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]]: ...
@overload
def GetListByBuyer(api: AsyncInvokerProtocol, buyerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]: ...
@overload
def GetListByBuyer(api: AsyncRequestProtocol, buyerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]: ...
def GetListByBuyer(api: object, buyerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]] | Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]:
    params, data = _prepare_GetListByBuyer(buyerCode=buyerCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByBuyer, params=params, data=data)

@overload
def GetListByRecipient(api: SyncInvokerProtocol, recipientCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]]: ...
@overload
def GetListByRecipient(api: SyncRequestProtocol, recipientCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]]: ...
@overload
def GetListByRecipient(api: AsyncInvokerProtocol, recipientCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]: ...
@overload
def GetListByRecipient(api: AsyncRequestProtocol, recipientCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]: ...
def GetListByRecipient(api: object, recipientCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]] | Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]:
    params, data = _prepare_GetListByRecipient(recipientCode=recipientCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByRecipient, params=params, data=data)

@overload
def GetListByDimension(api: SyncInvokerProtocol, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[SaleDocumentListElement]]: ...
@overload
def GetListByDimension(api: SyncRequestProtocol, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[SaleDocumentListElement]]: ...
@overload
def GetListByDimension(api: AsyncInvokerProtocol, dimensionCode: str, dictionaryValue: str) -> Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]: ...
@overload
def GetListByDimension(api: AsyncRequestProtocol, dimensionCode: str, dictionaryValue: str) -> Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]: ...
def GetListByDimension(api: object, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[SaleDocumentListElement]] | Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]:
    params, data = _prepare_GetListByDimension(dimensionCode=dimensionCode, dictionaryValue=dictionaryValue)
    return invoke_operation(api, OP_GetListByDimension, params=params, data=data)

@overload
def GetWZ(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[SaleDocumentWZ]]: ...
@overload
def GetWZ(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[SaleDocumentWZ]]: ...
@overload
def GetWZ(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]: ...
@overload
def GetWZ(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]: ...
def GetWZ(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[SaleDocumentWZ]] | Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]:
    params, data = _prepare_GetWZ(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetWZ, params=params, data=data)

@overload
def GetZMO(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[SaleDocumentZMO]]: ...
@overload
def GetZMO(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[SaleDocumentZMO]]: ...
@overload
def GetZMO(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[SaleDocumentZMO]]]: ...
@overload
def GetZMO(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[SaleDocumentZMO]]]: ...
def GetZMO(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[SaleDocumentZMO]] | Awaitable[ResponseEnvelope[List[SaleDocumentZMO]]]:
    params, data = _prepare_GetZMO(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetZMO, params=params, data=data)

@overload
def GetStatus(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[SaleDocumentStatus]: ...
@overload
def GetStatus(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[SaleDocumentStatus]: ...
@overload
def GetStatus(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[SaleDocumentStatus]]: ...
@overload
def GetStatus(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[SaleDocumentStatus]]: ...
def GetStatus(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[SaleDocumentStatus] | Awaitable[ResponseEnvelope[SaleDocumentStatus]]:
    params, data = _prepare_GetStatus(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetStatus, params=params, data=data)

@overload
def GetDocumentSeries(api: SyncInvokerProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: SyncRequestProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: AsyncInvokerProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
@overload
def GetDocumentSeries(api: AsyncRequestProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
def GetDocumentSeries(api: object, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]] | Awaitable[ResponseEnvelope[List[DocumentSeries]]]:
    params, data = _prepare_GetDocumentSeries(documentTypeId=documentTypeId)
    return invoke_operation(api, OP_GetDocumentSeries, params=params, data=data)

@overload
def GetPDF(api: SyncInvokerProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: SyncRequestProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> Awaitable[ResponseEnvelope[PDF]]: ...
@overload
def GetPDF(api: AsyncRequestProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> Awaitable[ResponseEnvelope[PDF]]: ...
def GetPDF(api: object, documentNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF] | Awaitable[ResponseEnvelope[PDF]]:
    params, data = _prepare_GetPDF(documentNumber=documentNumber, buffer=buffer, settings=settings)
    return invoke_operation(api, OP_GetPDF, params=params, data=data)

@overload
def GetCorrection(api: SyncInvokerProtocol, number: str, buffer: bool) -> ResponseEnvelope[SaleCorrection]: ...
@overload
def GetCorrection(api: SyncRequestProtocol, number: str, buffer: bool) -> ResponseEnvelope[SaleCorrection]: ...
@overload
def GetCorrection(api: AsyncInvokerProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[SaleCorrection]]: ...
@overload
def GetCorrection(api: AsyncRequestProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[SaleCorrection]]: ...
def GetCorrection(api: object, number: str, buffer: bool) -> ResponseEnvelope[SaleCorrection] | Awaitable[ResponseEnvelope[SaleCorrection]]:
    params, data = _prepare_GetCorrection(number=number, buffer=buffer)
    return invoke_operation(api, OP_GetCorrection, params=params, data=data)

@overload
def GetCorrectionSequence(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[SaleDocumentCorrection]]: ...
@overload
def GetCorrectionSequence(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[SaleDocumentCorrection]]: ...
@overload
def GetCorrectionSequence(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[SaleDocumentCorrection]]]: ...
@overload
def GetCorrectionSequence(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[SaleDocumentCorrection]]]: ...
def GetCorrectionSequence(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[SaleDocumentCorrection]] | Awaitable[ResponseEnvelope[List[SaleDocumentCorrection]]]:
    params, data = _prepare_GetCorrectionSequence(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetCorrectionSequence, params=params, data=data)

@overload
def IncrementalSync(api: SyncInvokerProtocol) -> ResponseEnvelope[List[IncrementalSyncListElement]]: ...
@overload
def IncrementalSync(api: SyncRequestProtocol) -> ResponseEnvelope[List[IncrementalSyncListElement]]: ...
@overload
def IncrementalSync(api: AsyncInvokerProtocol) -> Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]: ...
@overload
def IncrementalSync(api: AsyncRequestProtocol) -> Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]: ...
def IncrementalSync(api: object) -> ResponseEnvelope[List[IncrementalSyncListElement]] | Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]:
    params, data = _prepare_IncrementalSync()
    return invoke_operation(api, OP_IncrementalSync, params=params, data=data)

@overload
def GetPagedDocument(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocument(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocument(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocument(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocument, params=params, data=data)

@overload
def GetDocumentTypesWithRange(api: SyncInvokerProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]]: ...
@overload
def GetDocumentTypesWithRange(api: SyncRequestProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]]: ...
@overload
def GetDocumentTypesWithRange(api: AsyncInvokerProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]: ...
@overload
def GetDocumentTypesWithRange(api: AsyncRequestProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]: ...
def GetDocumentTypesWithRange(api: object, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SaleDocumentListElement]] | Awaitable[ResponseEnvelope[List[SaleDocumentListElement]]]:
    params, data = _prepare_GetDocumentTypesWithRange(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDocumentTypesWithRange, params=params, data=data)

__all__ = ["Get", "GetList", "GetListByBuyer", "GetListByRecipient", "GetListByDimension", "GetWZ", "GetZMO", "GetStatus", "GetDocumentSeries", "GetPDF", "GetCorrection", "GetCorrectionSequence", "IncrementalSync", "GetPagedDocument", "GetDocumentTypesWithRange"]
