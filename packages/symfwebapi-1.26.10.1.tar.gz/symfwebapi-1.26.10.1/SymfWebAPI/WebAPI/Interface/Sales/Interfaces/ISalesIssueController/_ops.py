from __future__ import annotations

from typing import List, Optional
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import AdvancePaymentOptions
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleCorrection
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels.CorrectionIssue.V2026_1 import SaleCorrectionIssue
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocument
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentWZ

_ADAPTER_AddNew = TypeAdapter(SaleCorrection)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[SaleCorrection]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/SalesIssue/NewCorrection', parser=_parse_AddNew)

_ADAPTER_Issue = TypeAdapter(SaleDocument)

def _parse_Issue(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[SaleDocument]:
    return parse_with_adapter(envelope, _ADAPTER_Issue)
OP_Issue = OperationSpec(method='PUT', path='/api/SalesIssue/InBuffer', parser=_parse_Issue)

_ADAPTER_IssueAdvancePayment = TypeAdapter(SaleDocument)

def _parse_IssueAdvancePayment(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[SaleDocument]:
    return parse_with_adapter(envelope, _ADAPTER_IssueAdvancePayment)
OP_IssueAdvancePayment = OperationSpec(method='PUT', path='/api/SalesIssue/AdvancePayment', parser=_parse_IssueAdvancePayment)

_ADAPTER_IssueWZ = TypeAdapter(List[SaleDocumentWZ])

def _parse_IssueWZ(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SaleDocumentWZ]]:
    return parse_with_adapter(envelope, _ADAPTER_IssueWZ)
OP_IssueWZ = OperationSpec(method='PUT', path='/api/SalesIssue/WZ', parser=_parse_IssueWZ)

_ADAPTER_IssueWZCorrection = TypeAdapter(List[SaleDocumentWZ])

def _parse_IssueWZCorrection(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SaleDocumentWZ]]:
    return parse_with_adapter(envelope, _ADAPTER_IssueWZCorrection)
OP_IssueWZCorrection = OperationSpec(method='PUT', path='/api/SalesIssue/IssueWZCorrection', parser=_parse_IssueWZCorrection)

def _parse_ChangeDocumentNumber(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_ChangeDocumentNumber = OperationSpec(method='PATCH', path='/api/SalesIssue/DocumentNumber', parser=_parse_ChangeDocumentNumber)

def _parse_IssuePN(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_IssuePN = OperationSpec(method='PUT', path='/api/SalesIssue/IssuePayment', parser=_parse_IssuePN)

def _parse_ChangeFiscalStatus(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_ChangeFiscalStatus = OperationSpec(method='PATCH', path='/api/SalesIssue/FiscalStatus', parser=_parse_ChangeFiscalStatus)
