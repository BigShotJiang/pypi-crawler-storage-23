from __future__ import annotations

from pydantic import BaseModel

from typing import Any, List, Optional
from datetime import datetime
from decimal import Decimal
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentAddress, VatRateBase
from SymfWebAPI.WebAPI.Interface.Enums import (
    enumCancelationType,
    enumDocumentStatus,
    enumFiscalizationStatus,
    enumJPK_V7DocumentAttribute,
    enumManualSettledState,
    enumPriceKind,
    enumRDFStatus,
    enumSalePriceType,
)

class AdvancePaymentOptions(BaseModel):
    Value: Decimal
    IsLast: bool
    AutomaticFillPositions: bool

class FiscalizationResult(BaseModel):
    Success: bool
    ReceiptNumber: Optional[int]
    FiscalDeviceNo: str
    ErrorMessage: str

class SaleCorrection(BaseModel):
    Id: int
    DocumentNumber: str
    MasterDocumentOid: Optional[int]
    Active: bool
    Canceled: "enumCancelationType"
    Buffer: bool
    Settled: bool
    Fisacal: "enumFiscalizationStatus"
    eInvoice: bool
    SplitPayment: bool
    JPK_V7Attributes: "enumJPK_V7DocumentAttribute"
    IssueDate: Optional[datetime]
    SaleDate: Optional[datetime]
    MaturityDate: Optional[datetime]
    TypeCode: str
    Series: str
    NumberInSeries: int
    IssuerId: int
    BuyerId: Optional[int]
    BuyerAddressId: Optional[int]
    RecipientId: Optional[int]
    RecipientAddressId: Optional[int]
    ThirdPartyContractorId: Optional[int]
    ThirdPartyContractorAddressId: Optional[int]
    ReceivedBy: str
    DepartmentId: int
    PriceKind: "enumPriceKind"
    SalePriceType: "enumSalePriceType"
    NetValuePLN: Decimal
    VatValuePLN: Decimal
    NetValue: Decimal
    GrossValue: Decimal
    Currency: str
    CurrencyRate: Decimal
    CurrencyRateCIT: Decimal
    PaymentRegistryId: int
    PaymentFormId: int
    CorrectionReason: str
    CatalogId: int
    KindId: int
    Marker: int
    Note: str
    StatusKSeF: Optional[int]
    NumberKSeF: str
    IssueDateKSeF: Optional[datetime]
    eArchiveId: Optional[str]
    Positions: List["SaleCorrectionPosition"]
    BuyerAddress: "DocumentAddress"
    RecipientAddress: "DocumentAddress"
    ThirdPartyContractorAddress: "DocumentAddress"
    DocumentExternalMetadata: str
    IsSmeProcedure: bool
    InvoiceKind: Any

class SaleCorrectionIssueContractor(BaseModel):
    RecalculatePrices: bool
    Data: "SaleDocumentIssueContractorData"
    DeliveryAddressCode: str

class SaleCorrectionIssuePosition(BaseModel):
    No: Optional[int]
    VatRate: "VatRateBase"
    Elements: List["SaleCorrectionIssuePositionElement"]
    Code: str
    Name: str
    Quantity: Decimal
    UnitOfMeasurement: str
    Value: Decimal

class SaleCorrectionIssuePositionElement(BaseModel):
    Code: str
    Name: str
    Quantity: Decimal
    UnitOfMeasurement: str
    Value: Decimal

class SaleCorrectionPosition(BaseModel):
    No: int
    BeforeCorrection: "SaleCorrectionPositionElement"
    AfterCorrection: "SaleCorrectionPositionElement"

class SaleCorrectionPositionElement(BaseModel):
    Id: int
    SetHeaderId: Optional[int]
    ProductId: Optional[int]
    ProductCode: str
    Description: str
    Quantity: Decimal
    WrittenQuantity: Decimal
    UnitOfMeasurement: str
    WrittenUnitOfMeasurement: str
    VatRate: "VatRateBase"
    PriceKind: "enumPriceKind"
    SalePriceType: "enumSalePriceType"
    PriceValuePLN: Decimal
    PriceValue: Decimal
    NetValuePLN: Decimal
    NetValue: Decimal
    VatValuePLN: Decimal
    GrossValue: Decimal

class SaleDocument(BaseModel):
    Id: int
    DocumentNumber: str
    Active: bool
    Canceled: "enumCancelationType"
    Buffer: bool
    Settled: bool
    Fisacal: "enumFiscalizationStatus"
    eInvoice: bool
    SplitPayment: bool
    JPK_V7Attributes: "enumJPK_V7DocumentAttribute"
    IssueDate: Optional[datetime]
    SaleDate: Optional[datetime]
    MaturityDate: Optional[datetime]
    TypeCode: str
    Series: str
    NumberInSeries: int
    IssuerId: int
    BuyerId: Optional[int]
    BuyerAddressId: Optional[int]
    RecipientId: Optional[int]
    RecipientAddressId: Optional[int]
    ThirdPartyContractorId: Optional[int]
    ThirdPartyContractorAddressId: Optional[int]
    ReceivedBy: str
    DepartmentId: int
    PriceKind: "enumPriceKind"
    SalePriceType: "enumSalePriceType"
    NetValuePLN: Decimal
    VatValuePLN: Decimal
    NetValue: Decimal
    GrossValue: Decimal
    Currency: str
    CurrencyRate: Decimal
    CurrencyRateCIT: Decimal
    PaymentRegistryId: int
    PaymentFormId: int
    Description: str
    CatalogId: int
    KindId: int
    Marker: int
    Note: str
    StatusKSeF: Optional[int]
    NumberKSeF: str
    IssueDateKSeF: Optional[datetime]
    eArchiveId: Optional[str]
    Positions: List["SaleDocumentPosition"]
    BuyerAddress: "DocumentAddress"
    RecipientAddress: "DocumentAddress"
    ThirdPartyContractorAddress: "DocumentAddress"
    TypeExternal: int
    IdExternal: Optional[int]
    Id2External: str
    DocumentExternalMetadata: str
    IsSmeProcedure: bool
    InvoiceKind: Any

class SaleDocumentCorrection(BaseModel):
    No: int
    Id: int
    DocumentNumber: str
    IssueDate: Optional[datetime]
    SaleDate: Optional[datetime]

class SaleDocumentIssueCatalog(BaseModel):
    FullPath: str
    AddIfNotExist: bool

class SaleDocumentIssueContractor(BaseModel):
    Id: Optional[int]
    Code: str
    RecalculatePrices: bool
    Data: "SaleDocumentIssueContractorData"
    DeliveryAddressCode: str

class SaleDocumentIssueContractorData(BaseModel):
    Name: str
    NIP: str
    Country: str
    City: str
    Street: str
    HouseNo: str
    ApartmentNo: str
    PostCode: str

class SaleDocumentIssueDelivery(BaseModel):
    Id: Optional[int]
    Code: str
    Quantity: Decimal

class SaleDocumentIssueKind(BaseModel):
    Code: str
    AddIfNotExist: bool

class SaleDocumentIssuePosition(BaseModel):
    VatRate: "VatRateBase"
    Elements: List["SaleDocumentIssuePositionElement"]
    Code: str
    Name: str
    Quantity: Decimal
    UnitOfMeasurement: str
    Value: Decimal
    Deliveries: List["SaleDocumentIssueDelivery"]
    OssService: Optional[bool]

class SaleDocumentIssuePositionElement(BaseModel):
    Code: str
    Name: str
    Quantity: Decimal
    UnitOfMeasurement: str
    Value: Decimal
    Deliveries: List["SaleDocumentIssueDelivery"]
    OssService: Optional[bool]

class SaleDocumentListElement(BaseModel):
    Id: int
    DocumentNumber: str
    Active: bool
    Canceled: "enumCancelationType"
    Buffer: int
    Settled: int
    IssueDate: Optional[datetime]
    SaleDate: Optional[datetime]
    MaturityDate: Optional[datetime]
    TypeCode: str
    Series: str
    NumberInSeries: int
    IssuerId: int
    BuyerId: Optional[int]
    ThirdPartyContractorId: Optional[int]
    RecipientId: Optional[int]
    DepartmentId: int
    NetValuePLN: Decimal
    VatValuePLN: Decimal
    NetValue: Decimal
    GrossValue: Decimal
    IncomeValue: Decimal
    Currency: str
    Description: str
    IsSmeProcedure: bool
    TypeExternal: int
    IdExternal: Optional[int]
    Id2External: str
    InvoiceKind: Any

class SaleDocumentPosition(BaseModel):
    Id: int
    No: int
    SetHeaderId: Optional[int]
    ProductId: Optional[int]
    ProductCode: str
    Description: str
    Quantity: Decimal
    WrittenQuantity: Decimal
    EnteredQuantity: Decimal
    UnitOfMeasurement: str
    WrittenUnitOfMeasurement: str
    EnteredUnitOfMeasurement: str
    VatRate: "VatRateBase"
    PriceKind: "enumPriceKind"
    SalePriceType: "enumSalePriceType"
    PriceValuePLN: Decimal
    PriceValue: Decimal
    NetValuePLN: Decimal
    NetValue: Decimal
    VatValuePLN: Decimal
    GrossValue: Decimal

class SaleDocumentStatus(BaseModel):
    Id: int
    DocumentNumber: str
    Buffer: bool
    PaymentSettled: int
    WarehouseSettled: int
    RDFStatus: "enumRDFStatus"
    ManualSettled: "enumManualSettledState"
    DocumentStatus: "enumDocumentStatus"
    DocumentStatusText: str

class SaleDocumentWZ(BaseModel):
    Id: int
    DocumentNumber: str
    IssueDate: Optional[datetime]
    OperationDate: Optional[datetime]
    RecipientId: int

class SaleDocumentZMO(BaseModel):
    Id: int
    DocumentNumber: str
    IssueDate: Optional[datetime]
    SaleDate: Optional[datetime]
    BuyerId: int
    RecipientId: int
