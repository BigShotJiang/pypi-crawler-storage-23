from __future__ import annotations

from pydantic import BaseModel

from typing import Optional
from datetime import datetime
from decimal import Decimal

class DocumentIssueSettlement(BaseModel):
    SettlementDate: Optional[datetime]
    Value: Decimal
