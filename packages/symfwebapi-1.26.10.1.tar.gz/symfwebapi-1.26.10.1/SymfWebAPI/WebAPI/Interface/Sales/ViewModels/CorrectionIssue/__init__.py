from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

_VERSIONED_EXPORTS = {
    'SaleCorrectionIssue': 'V2026_1',
}

def __getattr__(name: str):
    child_name = _VERSIONED_EXPORTS.get(name)
    if child_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module = importlib.import_module(f".{child_name}", __name__)
    value = getattr(module, name)
    globals()[name] = value
    return value

def __dir__():
    return sorted(set(_VERSIONED_EXPORTS) | {n for n in globals() if not n.startswith('_')})

if TYPE_CHECKING:
    from .V2026_1 import SaleCorrectionIssue
