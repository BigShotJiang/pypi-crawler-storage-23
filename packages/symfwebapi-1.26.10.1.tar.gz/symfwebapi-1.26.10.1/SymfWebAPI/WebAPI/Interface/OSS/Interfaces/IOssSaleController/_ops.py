from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels.Sales import OssDomesticSaleDocument
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels.Sales.V2026_1 import OssSaleDocument
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocument
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentWZ

_ADAPTER_AddNew = TypeAdapter(SaleDocument)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[SaleDocument]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/OssSale/New', parser=_parse_AddNew)

_ADAPTER_AddNewReceipt = TypeAdapter(SaleDocument)

def _parse_AddNewReceipt(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[SaleDocument]:
    return parse_with_adapter(envelope, _ADAPTER_AddNewReceipt)
OP_AddNewReceipt = OperationSpec(method='POST', path='/api/OssSale/NewReceipt', parser=_parse_AddNewReceipt)

_ADAPTER_IssueWZ = TypeAdapter(List[SaleDocumentWZ])

def _parse_IssueWZ(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SaleDocumentWZ]]:
    return parse_with_adapter(envelope, _ADAPTER_IssueWZ)
OP_IssueWZ = OperationSpec(method='PUT', path='/api/OssSale/WZ', parser=_parse_IssueWZ)
