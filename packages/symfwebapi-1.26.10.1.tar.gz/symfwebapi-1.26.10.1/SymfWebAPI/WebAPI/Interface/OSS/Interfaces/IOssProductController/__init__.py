from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels import CountryProductList
from ._common import (
    _prepare_GetByCountry,
    _prepare_GetByErpProduct,
    _prepare_GetByShopProduct,
)
from ._ops import (
    OP_GetByCountry,
    OP_GetByErpProduct,
    OP_GetByShopProduct,
)

@overload
def GetByCountry(api: SyncInvokerProtocol, countryId: int) -> ResponseEnvelope[CountryProductList]: ...
@overload
def GetByCountry(api: SyncRequestProtocol, countryId: int) -> ResponseEnvelope[CountryProductList]: ...
@overload
def GetByCountry(api: AsyncInvokerProtocol, countryId: int) -> Awaitable[ResponseEnvelope[CountryProductList]]: ...
@overload
def GetByCountry(api: AsyncRequestProtocol, countryId: int) -> Awaitable[ResponseEnvelope[CountryProductList]]: ...
def GetByCountry(api: object, countryId: int) -> ResponseEnvelope[CountryProductList] | Awaitable[ResponseEnvelope[CountryProductList]]:
    params, data = _prepare_GetByCountry(countryId=countryId)
    return invoke_operation(api, OP_GetByCountry, params=params, data=data)

@overload
def GetByErpProduct(api: SyncInvokerProtocol, erpProductId: int) -> ResponseEnvelope[CountryProductList]: ...
@overload
def GetByErpProduct(api: SyncRequestProtocol, erpProductId: int) -> ResponseEnvelope[CountryProductList]: ...
@overload
def GetByErpProduct(api: AsyncInvokerProtocol, erpProductId: int) -> Awaitable[ResponseEnvelope[CountryProductList]]: ...
@overload
def GetByErpProduct(api: AsyncRequestProtocol, erpProductId: int) -> Awaitable[ResponseEnvelope[CountryProductList]]: ...
def GetByErpProduct(api: object, erpProductId: int) -> ResponseEnvelope[CountryProductList] | Awaitable[ResponseEnvelope[CountryProductList]]:
    params, data = _prepare_GetByErpProduct(erpProductId=erpProductId)
    return invoke_operation(api, OP_GetByErpProduct, params=params, data=data)

@overload
def GetByShopProduct(api: SyncInvokerProtocol, shopProductId: str) -> ResponseEnvelope[CountryProductList]: ...
@overload
def GetByShopProduct(api: SyncRequestProtocol, shopProductId: str) -> ResponseEnvelope[CountryProductList]: ...
@overload
def GetByShopProduct(api: AsyncInvokerProtocol, shopProductId: str) -> Awaitable[ResponseEnvelope[CountryProductList]]: ...
@overload
def GetByShopProduct(api: AsyncRequestProtocol, shopProductId: str) -> Awaitable[ResponseEnvelope[CountryProductList]]: ...
def GetByShopProduct(api: object, shopProductId: str) -> ResponseEnvelope[CountryProductList] | Awaitable[ResponseEnvelope[CountryProductList]]:
    params, data = _prepare_GetByShopProduct(shopProductId=shopProductId)
    return invoke_operation(api, OP_GetByShopProduct, params=params, data=data)

__all__ = ["GetByCountry", "GetByErpProduct", "GetByShopProduct"]
