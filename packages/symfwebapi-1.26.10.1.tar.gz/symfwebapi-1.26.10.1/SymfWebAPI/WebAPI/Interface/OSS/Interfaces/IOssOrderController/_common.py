from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/OssOrder/New')
def _prepare_AddNew(*, issue, order) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["issue"] = issue
    data = order.model_dump_json(exclude_unset=True) if order is not None else None
    return params or None, data

_REQUEST_IssueFV = ('PUT', '/api/OssOrder/FV')
def _prepare_IssueFV(*, orderId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderId"] = orderId
    data = None
    return params or None, data

_REQUEST_IssueWZ = ('PUT', '/api/OssOrder/WZ')
def _prepare_IssueWZ(*, orderId, inBuffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderId"] = orderId
    params["inBuffer"] = inBuffer
    data = None
    return params or None, data
