from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/OssContractors')
def _prepare_Get(*, id) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    data = None
    return params or None, data

_REQUEST_AddNew = ('POST', '/api/OssContractors/Create')
def _prepare_AddNew(*, syncFk, contractor) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["syncFk"] = syncFk
    data = contractor.model_dump_json(exclude_unset=True) if contractor is not None else None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/OssContractors/Update')
def _prepare_Update(*, syncFk, contractor) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["syncFk"] = syncFk
    data = contractor.model_dump_json(exclude_unset=True) if contractor is not None else None
    return params or None, data
