from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels import ProductMap
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels import ProductMapCreate

_ADAPTER_Create = TypeAdapter(ProductMap)

def _parse_Create(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[ProductMap]:
    return parse_with_adapter(envelope, _ADAPTER_Create)
OP_Create = OperationSpec(method='POST', path='/api/OssProductMap/Create', parser=_parse_Create)

def _parse_Delete(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Delete = OperationSpec(method='DELETE', path='/api/OssProductMap/Delete', parser=_parse_Delete)

_ADAPTER_GetByCountry = TypeAdapter(List[ProductMap])

def _parse_GetByCountry(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductMap]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByCountry)
OP_GetByCountry = OperationSpec(method='GET', path='/api/OssProductMap', parser=_parse_GetByCountry)

_ADAPTER_GetByErpProduct = TypeAdapter(List[ProductMap])

def _parse_GetByErpProduct(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductMap]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByErpProduct)
OP_GetByErpProduct = OperationSpec(method='GET', path='/api/OssProductMap', parser=_parse_GetByErpProduct)

_ADAPTER_GetByShopProduct = TypeAdapter(List[ProductMap])

def _parse_GetByShopProduct(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductMap]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByShopProduct)
OP_GetByShopProduct = OperationSpec(method='GET', path='/api/OssProductMap', parser=_parse_GetByShopProduct)
