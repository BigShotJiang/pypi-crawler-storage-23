from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from ._common import (
    _prepare_GetOrderPDF,
    _prepare_GetSaleDocumentPDF,
    _prepare_GetWarehouseDocumentPDF,
)
from ._ops import (
    OP_GetOrderPDF,
    OP_GetSaleDocumentPDF,
    OP_GetWarehouseDocumentPDF,
)

@overload
def GetOrderPDF(api: SyncInvokerProtocol, orderId: int) -> ResponseEnvelope[PDF]: ...
@overload
def GetOrderPDF(api: SyncRequestProtocol, orderId: int) -> ResponseEnvelope[PDF]: ...
@overload
def GetOrderPDF(api: AsyncInvokerProtocol, orderId: int) -> Awaitable[ResponseEnvelope[PDF]]: ...
@overload
def GetOrderPDF(api: AsyncRequestProtocol, orderId: int) -> Awaitable[ResponseEnvelope[PDF]]: ...
def GetOrderPDF(api: object, orderId: int) -> ResponseEnvelope[PDF] | Awaitable[ResponseEnvelope[PDF]]:
    params, data = _prepare_GetOrderPDF(orderId=orderId)
    return invoke_operation(api, OP_GetOrderPDF, params=params, data=data)

@overload
def GetSaleDocumentPDF(api: SyncInvokerProtocol, documentId: int) -> ResponseEnvelope[PDF]: ...
@overload
def GetSaleDocumentPDF(api: SyncRequestProtocol, documentId: int) -> ResponseEnvelope[PDF]: ...
@overload
def GetSaleDocumentPDF(api: AsyncInvokerProtocol, documentId: int) -> Awaitable[ResponseEnvelope[PDF]]: ...
@overload
def GetSaleDocumentPDF(api: AsyncRequestProtocol, documentId: int) -> Awaitable[ResponseEnvelope[PDF]]: ...
def GetSaleDocumentPDF(api: object, documentId: int) -> ResponseEnvelope[PDF] | Awaitable[ResponseEnvelope[PDF]]:
    params, data = _prepare_GetSaleDocumentPDF(documentId=documentId)
    return invoke_operation(api, OP_GetSaleDocumentPDF, params=params, data=data)

@overload
def GetWarehouseDocumentPDF(api: SyncInvokerProtocol, documentId: int) -> ResponseEnvelope[PDF]: ...
@overload
def GetWarehouseDocumentPDF(api: SyncRequestProtocol, documentId: int) -> ResponseEnvelope[PDF]: ...
@overload
def GetWarehouseDocumentPDF(api: AsyncInvokerProtocol, documentId: int) -> Awaitable[ResponseEnvelope[PDF]]: ...
@overload
def GetWarehouseDocumentPDF(api: AsyncRequestProtocol, documentId: int) -> Awaitable[ResponseEnvelope[PDF]]: ...
def GetWarehouseDocumentPDF(api: object, documentId: int) -> ResponseEnvelope[PDF] | Awaitable[ResponseEnvelope[PDF]]:
    params, data = _prepare_GetWarehouseDocumentPDF(documentId=documentId)
    return invoke_operation(api, OP_GetWarehouseDocumentPDF, params=params, data=data)

__all__ = ["GetOrderPDF", "GetSaleDocumentPDF", "GetWarehouseDocumentPDF"]
