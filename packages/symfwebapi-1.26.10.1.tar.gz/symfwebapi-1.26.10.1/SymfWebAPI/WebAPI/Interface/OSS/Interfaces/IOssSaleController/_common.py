from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/OssSale/New')
def _prepare_AddNew(*, issue, invoiceKind, saleDocument) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["issue"] = issue
    params["invoiceKind"] = invoiceKind
    data = saleDocument.model_dump_json(exclude_unset=True) if saleDocument is not None else None
    return params or None, data

_REQUEST_AddNewReceipt = ('POST', '/api/OssSale/NewReceipt')
def _prepare_AddNewReceipt(*, issue, invoiceKind, receipt) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["issue"] = issue
    params["invoiceKind"] = invoiceKind
    data = receipt.model_dump_json(exclude_unset=True) if receipt is not None else None
    return params or None, data

_REQUEST_IssueWZ = ('PUT', '/api/OssSale/WZ')
def _prepare_IssueWZ(*, documentId, inBuffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentId"] = documentId
    params["inBuffer"] = inBuffer
    data = None
    return params or None, data
