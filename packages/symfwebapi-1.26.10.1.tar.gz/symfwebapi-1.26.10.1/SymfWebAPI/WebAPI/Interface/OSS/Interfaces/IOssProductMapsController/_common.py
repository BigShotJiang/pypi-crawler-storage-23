from __future__ import annotations

from typing import Any

_REQUEST_Create = ('POST', '/api/OssProductMap/Create')
def _prepare_Create(*, map) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = map.model_dump_json(exclude_unset=True) if map is not None else None
    return params or None, data

_REQUEST_Delete = ('DELETE', '/api/OssProductMap/Delete')
def _prepare_Delete(*, id) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    data = None
    return params or None, data

_REQUEST_GetByCountry = ('GET', '/api/OssProductMap')
def _prepare_GetByCountry(*, countryId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["countryId"] = countryId
    data = None
    return params or None, data

_REQUEST_GetByErpProduct = ('GET', '/api/OssProductMap')
def _prepare_GetByErpProduct(*, erpProductId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["erpProductId"] = erpProductId
    data = None
    return params or None, data

_REQUEST_GetByShopProduct = ('GET', '/api/OssProductMap')
def _prepare_GetByShopProduct(*, shopProductId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["shopProductId"] = shopProductId
    data = None
    return params or None, data
