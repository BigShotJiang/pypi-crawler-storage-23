from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels import ProductMap
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels import ProductMapCreate
from ._common import (
    _prepare_Create,
    _prepare_Delete,
    _prepare_GetByCountry,
    _prepare_GetByErpProduct,
    _prepare_GetByShopProduct,
)
from ._ops import (
    OP_Create,
    OP_Delete,
    OP_GetByCountry,
    OP_GetByErpProduct,
    OP_GetByShopProduct,
)

@overload
def Create(api: SyncInvokerProtocol, map: "ProductMapCreate") -> ResponseEnvelope[ProductMap]: ...
@overload
def Create(api: SyncRequestProtocol, map: "ProductMapCreate") -> ResponseEnvelope[ProductMap]: ...
@overload
def Create(api: AsyncInvokerProtocol, map: "ProductMapCreate") -> Awaitable[ResponseEnvelope[ProductMap]]: ...
@overload
def Create(api: AsyncRequestProtocol, map: "ProductMapCreate") -> Awaitable[ResponseEnvelope[ProductMap]]: ...
def Create(api: object, map: "ProductMapCreate") -> ResponseEnvelope[ProductMap] | Awaitable[ResponseEnvelope[ProductMap]]:
    params, data = _prepare_Create(map=map)
    return invoke_operation(api, OP_Create, params=params, data=data)

@overload
def Delete(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[None]: ...
@overload
def Delete(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[None]: ...
@overload
def Delete(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Delete(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[None]]: ...
def Delete(api: object, id: int) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Delete(id=id)
    return invoke_operation(api, OP_Delete, params=params, data=data)

@overload
def GetByCountry(api: SyncInvokerProtocol, countryId: int) -> ResponseEnvelope[List[ProductMap]]: ...
@overload
def GetByCountry(api: SyncRequestProtocol, countryId: int) -> ResponseEnvelope[List[ProductMap]]: ...
@overload
def GetByCountry(api: AsyncInvokerProtocol, countryId: int) -> Awaitable[ResponseEnvelope[List[ProductMap]]]: ...
@overload
def GetByCountry(api: AsyncRequestProtocol, countryId: int) -> Awaitable[ResponseEnvelope[List[ProductMap]]]: ...
def GetByCountry(api: object, countryId: int) -> ResponseEnvelope[List[ProductMap]] | Awaitable[ResponseEnvelope[List[ProductMap]]]:
    params, data = _prepare_GetByCountry(countryId=countryId)
    return invoke_operation(api, OP_GetByCountry, params=params, data=data)

@overload
def GetByErpProduct(api: SyncInvokerProtocol, erpProductId: int) -> ResponseEnvelope[List[ProductMap]]: ...
@overload
def GetByErpProduct(api: SyncRequestProtocol, erpProductId: int) -> ResponseEnvelope[List[ProductMap]]: ...
@overload
def GetByErpProduct(api: AsyncInvokerProtocol, erpProductId: int) -> Awaitable[ResponseEnvelope[List[ProductMap]]]: ...
@overload
def GetByErpProduct(api: AsyncRequestProtocol, erpProductId: int) -> Awaitable[ResponseEnvelope[List[ProductMap]]]: ...
def GetByErpProduct(api: object, erpProductId: int) -> ResponseEnvelope[List[ProductMap]] | Awaitable[ResponseEnvelope[List[ProductMap]]]:
    params, data = _prepare_GetByErpProduct(erpProductId=erpProductId)
    return invoke_operation(api, OP_GetByErpProduct, params=params, data=data)

@overload
def GetByShopProduct(api: SyncInvokerProtocol, shopProductId: str) -> ResponseEnvelope[List[ProductMap]]: ...
@overload
def GetByShopProduct(api: SyncRequestProtocol, shopProductId: str) -> ResponseEnvelope[List[ProductMap]]: ...
@overload
def GetByShopProduct(api: AsyncInvokerProtocol, shopProductId: str) -> Awaitable[ResponseEnvelope[List[ProductMap]]]: ...
@overload
def GetByShopProduct(api: AsyncRequestProtocol, shopProductId: str) -> Awaitable[ResponseEnvelope[List[ProductMap]]]: ...
def GetByShopProduct(api: object, shopProductId: str) -> ResponseEnvelope[List[ProductMap]] | Awaitable[ResponseEnvelope[List[ProductMap]]]:
    params, data = _prepare_GetByShopProduct(shopProductId=shopProductId)
    return invoke_operation(api, OP_GetByShopProduct, params=params, data=data)

__all__ = ["Create", "Delete", "GetByCountry", "GetByErpProduct", "GetByShopProduct"]
