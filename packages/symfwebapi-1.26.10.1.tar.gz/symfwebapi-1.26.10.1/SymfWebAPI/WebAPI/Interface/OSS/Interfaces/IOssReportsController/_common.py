from __future__ import annotations

from typing import Any

_REQUEST_GetOrderPDF = ('GET', '/api/OssReports/Order')
def _prepare_GetOrderPDF(*, orderId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderId"] = orderId
    data = None
    return params or None, data

_REQUEST_GetSaleDocumentPDF = ('GET', '/api/OssReports/SaleDocument')
def _prepare_GetSaleDocumentPDF(*, documentId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentId"] = documentId
    data = None
    return params or None, data

_REQUEST_GetWarehouseDocumentPDF = ('GET', '/api/OssReports/WarehouseDocument')
def _prepare_GetWarehouseDocumentPDF(*, documentId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentId"] = documentId
    data = None
    return params or None, data
