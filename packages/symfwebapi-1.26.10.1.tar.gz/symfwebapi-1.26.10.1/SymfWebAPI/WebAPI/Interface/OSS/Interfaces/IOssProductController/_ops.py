from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels import CountryProductList

_ADAPTER_GetByCountry = TypeAdapter(CountryProductList)

def _parse_GetByCountry(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[CountryProductList]:
    return parse_with_adapter(envelope, _ADAPTER_GetByCountry)
OP_GetByCountry = OperationSpec(method='GET', path='/api/OssProduct', parser=_parse_GetByCountry)

_ADAPTER_GetByErpProduct = TypeAdapter(CountryProductList)

def _parse_GetByErpProduct(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[CountryProductList]:
    return parse_with_adapter(envelope, _ADAPTER_GetByErpProduct)
OP_GetByErpProduct = OperationSpec(method='GET', path='/api/OssProduct', parser=_parse_GetByErpProduct)

_ADAPTER_GetByShopProduct = TypeAdapter(CountryProductList)

def _parse_GetByShopProduct(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[CountryProductList]:
    return parse_with_adapter(envelope, _ADAPTER_GetByShopProduct)
OP_GetByShopProduct = OperationSpec(method='GET', path='/api/OssProduct', parser=_parse_GetByShopProduct)
