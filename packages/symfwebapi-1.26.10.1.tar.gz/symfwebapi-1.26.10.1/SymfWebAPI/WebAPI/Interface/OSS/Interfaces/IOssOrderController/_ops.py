from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import Order
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderFV
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderWZ
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels.Orders import OssOrder

_ADAPTER_AddNew = TypeAdapter(Order)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Order]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/OssOrder/New', parser=_parse_AddNew)

_ADAPTER_IssueFV = TypeAdapter(List[OrderFV])

def _parse_IssueFV(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OrderFV]]:
    return parse_with_adapter(envelope, _ADAPTER_IssueFV)
OP_IssueFV = OperationSpec(method='PUT', path='/api/OssOrder/FV', parser=_parse_IssueFV)

_ADAPTER_IssueWZ = TypeAdapter(List[OrderWZ])

def _parse_IssueWZ(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OrderWZ]]:
    return parse_with_adapter(envelope, _ADAPTER_IssueWZ)
OP_IssueWZ = OperationSpec(method='PUT', path='/api/OssOrder/WZ', parser=_parse_IssueWZ)
