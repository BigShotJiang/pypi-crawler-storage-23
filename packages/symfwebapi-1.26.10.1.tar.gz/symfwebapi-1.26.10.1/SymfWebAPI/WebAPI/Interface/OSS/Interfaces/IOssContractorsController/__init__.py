from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels.V2026_1 import Contractor
from ._common import (
    _prepare_Get,
    _prepare_AddNew,
    _prepare_Update,
)
from ._ops import (
    OP_Get,
    OP_AddNew,
    OP_Update,
)

@overload
def Get(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[Contractor]: ...
@overload
def Get(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[Contractor]: ...
@overload
def Get(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[Contractor]]: ...
@overload
def Get(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[Contractor]]: ...
def Get(api: object, id: int) -> ResponseEnvelope[Contractor] | Awaitable[ResponseEnvelope[Contractor]]:
    params, data = _prepare_Get(id=id)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def AddNew(api: SyncInvokerProtocol, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[Contractor]: ...
@overload
def AddNew(api: SyncRequestProtocol, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[Contractor]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, syncFk: bool, contractor: "Contractor") -> Awaitable[ResponseEnvelope[Contractor]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, syncFk: bool, contractor: "Contractor") -> Awaitable[ResponseEnvelope[Contractor]]: ...
def AddNew(api: object, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[Contractor] | Awaitable[ResponseEnvelope[Contractor]]:
    params, data = _prepare_AddNew(syncFk=syncFk, contractor=contractor)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Update(api: SyncInvokerProtocol, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, syncFk: bool, contractor: "Contractor") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, syncFk: bool, contractor: "Contractor") -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, syncFk: bool, contractor: "Contractor") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(syncFk=syncFk, contractor=contractor)
    return invoke_operation(api, OP_Update, params=params, data=data)

__all__ = ["Get", "AddNew", "Update"]
