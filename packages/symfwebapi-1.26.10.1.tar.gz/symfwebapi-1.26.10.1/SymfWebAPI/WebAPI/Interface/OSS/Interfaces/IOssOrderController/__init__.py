from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import Order
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderFV
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderWZ
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels.Orders import OssOrder
from ._common import (
    _prepare_AddNew,
    _prepare_IssueFV,
    _prepare_IssueWZ,
)
from ._ops import (
    OP_AddNew,
    OP_IssueFV,
    OP_IssueWZ,
)

@overload
def AddNew(api: SyncInvokerProtocol, issue: bool, order: "OssOrder") -> ResponseEnvelope[Order]: ...
@overload
def AddNew(api: SyncRequestProtocol, issue: bool, order: "OssOrder") -> ResponseEnvelope[Order]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, issue: bool, order: "OssOrder") -> Awaitable[ResponseEnvelope[Order]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, issue: bool, order: "OssOrder") -> Awaitable[ResponseEnvelope[Order]]: ...
def AddNew(api: object, issue: bool, order: "OssOrder") -> ResponseEnvelope[Order] | Awaitable[ResponseEnvelope[Order]]:
    params, data = _prepare_AddNew(issue=issue, order=order)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def IssueFV(api: SyncInvokerProtocol, orderId: int) -> ResponseEnvelope[List[OrderFV]]: ...
@overload
def IssueFV(api: SyncRequestProtocol, orderId: int) -> ResponseEnvelope[List[OrderFV]]: ...
@overload
def IssueFV(api: AsyncInvokerProtocol, orderId: int) -> Awaitable[ResponseEnvelope[List[OrderFV]]]: ...
@overload
def IssueFV(api: AsyncRequestProtocol, orderId: int) -> Awaitable[ResponseEnvelope[List[OrderFV]]]: ...
def IssueFV(api: object, orderId: int) -> ResponseEnvelope[List[OrderFV]] | Awaitable[ResponseEnvelope[List[OrderFV]]]:
    params, data = _prepare_IssueFV(orderId=orderId)
    return invoke_operation(api, OP_IssueFV, params=params, data=data)

@overload
def IssueWZ(api: SyncInvokerProtocol, orderId: int, inBuffer: bool) -> ResponseEnvelope[List[OrderWZ]]: ...
@overload
def IssueWZ(api: SyncRequestProtocol, orderId: int, inBuffer: bool) -> ResponseEnvelope[List[OrderWZ]]: ...
@overload
def IssueWZ(api: AsyncInvokerProtocol, orderId: int, inBuffer: bool) -> Awaitable[ResponseEnvelope[List[OrderWZ]]]: ...
@overload
def IssueWZ(api: AsyncRequestProtocol, orderId: int, inBuffer: bool) -> Awaitable[ResponseEnvelope[List[OrderWZ]]]: ...
def IssueWZ(api: object, orderId: int, inBuffer: bool) -> ResponseEnvelope[List[OrderWZ]] | Awaitable[ResponseEnvelope[List[OrderWZ]]]:
    params, data = _prepare_IssueWZ(orderId=orderId, inBuffer=inBuffer)
    return invoke_operation(api, OP_IssueWZ, params=params, data=data)

__all__ = ["AddNew", "IssueFV", "IssueWZ"]
