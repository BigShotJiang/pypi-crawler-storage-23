from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels.Sales import OssDomesticSaleDocument
from SymfWebAPI.WebAPI.Interface.OSS.ViewModels.Sales.V2026_1 import OssSaleDocument
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocument
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels import SaleDocumentWZ
from ._common import (
    _prepare_AddNew,
    _prepare_AddNewReceipt,
    _prepare_IssueWZ,
)
from ._ops import (
    OP_AddNew,
    OP_AddNewReceipt,
    OP_IssueWZ,
)

@overload
def AddNew(api: SyncInvokerProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", saleDocument: "OssSaleDocument") -> ResponseEnvelope[SaleDocument]: ...
@overload
def AddNew(api: SyncRequestProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", saleDocument: "OssSaleDocument") -> ResponseEnvelope[SaleDocument]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", saleDocument: "OssSaleDocument") -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", saleDocument: "OssSaleDocument") -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
def AddNew(api: object, issue: bool, invoiceKind: "IssueInvoiceKind", saleDocument: "OssSaleDocument") -> ResponseEnvelope[SaleDocument] | Awaitable[ResponseEnvelope[SaleDocument]]:
    params, data = _prepare_AddNew(issue=issue, invoiceKind=invoiceKind, saleDocument=saleDocument)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def AddNewReceipt(api: SyncInvokerProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", receipt: "OssDomesticSaleDocument") -> ResponseEnvelope[SaleDocument]: ...
@overload
def AddNewReceipt(api: SyncRequestProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", receipt: "OssDomesticSaleDocument") -> ResponseEnvelope[SaleDocument]: ...
@overload
def AddNewReceipt(api: AsyncInvokerProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", receipt: "OssDomesticSaleDocument") -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
@overload
def AddNewReceipt(api: AsyncRequestProtocol, issue: bool, invoiceKind: "IssueInvoiceKind", receipt: "OssDomesticSaleDocument") -> Awaitable[ResponseEnvelope[SaleDocument]]: ...
def AddNewReceipt(api: object, issue: bool, invoiceKind: "IssueInvoiceKind", receipt: "OssDomesticSaleDocument") -> ResponseEnvelope[SaleDocument] | Awaitable[ResponseEnvelope[SaleDocument]]:
    params, data = _prepare_AddNewReceipt(issue=issue, invoiceKind=invoiceKind, receipt=receipt)
    return invoke_operation(api, OP_AddNewReceipt, params=params, data=data)

@overload
def IssueWZ(api: SyncInvokerProtocol, documentId: int, inBuffer: bool) -> ResponseEnvelope[List[SaleDocumentWZ]]: ...
@overload
def IssueWZ(api: SyncRequestProtocol, documentId: int, inBuffer: bool) -> ResponseEnvelope[List[SaleDocumentWZ]]: ...
@overload
def IssueWZ(api: AsyncInvokerProtocol, documentId: int, inBuffer: bool) -> Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]: ...
@overload
def IssueWZ(api: AsyncRequestProtocol, documentId: int, inBuffer: bool) -> Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]: ...
def IssueWZ(api: object, documentId: int, inBuffer: bool) -> ResponseEnvelope[List[SaleDocumentWZ]] | Awaitable[ResponseEnvelope[List[SaleDocumentWZ]]]:
    params, data = _prepare_IssueWZ(documentId=documentId, inBuffer=inBuffer)
    return invoke_operation(api, OP_IssueWZ, params=params, data=data)

__all__ = ["AddNew", "AddNewReceipt", "IssueWZ"]
