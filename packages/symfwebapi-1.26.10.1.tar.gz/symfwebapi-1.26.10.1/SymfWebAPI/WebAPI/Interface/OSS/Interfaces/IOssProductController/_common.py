from __future__ import annotations

from typing import Any

_REQUEST_GetByCountry = ('GET', '/api/OssProduct')
def _prepare_GetByCountry(*, countryId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["countryId"] = countryId
    data = None
    return params or None, data

_REQUEST_GetByErpProduct = ('GET', '/api/OssProduct')
def _prepare_GetByErpProduct(*, erpProductId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["erpProductId"] = erpProductId
    data = None
    return params or None, data

_REQUEST_GetByShopProduct = ('GET', '/api/OssProduct')
def _prepare_GetByShopProduct(*, shopProductId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["shopProductId"] = shopProductId
    data = None
    return params or None, data
