from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF

_ADAPTER_GetOrderPDF = TypeAdapter(PDF)

def _parse_GetOrderPDF(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PDF]:
    return parse_with_adapter(envelope, _ADAPTER_GetOrderPDF)
OP_GetOrderPDF = OperationSpec(method='GET', path='/api/OssReports/Order', parser=_parse_GetOrderPDF)

_ADAPTER_GetSaleDocumentPDF = TypeAdapter(PDF)

def _parse_GetSaleDocumentPDF(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PDF]:
    return parse_with_adapter(envelope, _ADAPTER_GetSaleDocumentPDF)
OP_GetSaleDocumentPDF = OperationSpec(method='GET', path='/api/OssReports/SaleDocument', parser=_parse_GetSaleDocumentPDF)

_ADAPTER_GetWarehouseDocumentPDF = TypeAdapter(PDF)

def _parse_GetWarehouseDocumentPDF(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PDF]:
    return parse_with_adapter(envelope, _ADAPTER_GetWarehouseDocumentPDF)
OP_GetWarehouseDocumentPDF = OperationSpec(method='GET', path='/api/OssReports/WarehouseDocument', parser=_parse_GetWarehouseDocumentPDF)
