from __future__ import annotations

from typing import Awaitable, List, Optional, overload
from datetime import datetime
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import FilterDocumentType
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrder
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderFV
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderListElement
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderPZ
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderPositionRelation
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderStatus
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDFSettings
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType
from ._common import (
    _prepare_Get,
    _prepare_GetList,
    _prepare_GetListByDeliverer,
    _prepare_GetListBySeller,
    _prepare_GetListByDimension,
    _prepare_GetPZ,
    _prepare_GetFV,
    _prepare_GetPDF,
    _prepare_GetDocumentSeries,
    _prepare_GetStatus,
    _prepare_GetPositionRelations,
    _prepare_GetPagedDocument,
    _prepare_GetDocumentTypesWithRange,
)
from ._ops import (
    OP_Get,
    OP_GetList,
    OP_GetListByDeliverer,
    OP_GetListBySeller,
    OP_GetListByDimension,
    OP_GetPZ,
    OP_GetFV,
    OP_GetPDF,
    OP_GetDocumentSeries,
    OP_GetStatus,
    OP_GetPositionRelations,
    OP_GetPagedDocument,
    OP_GetDocumentTypesWithRange,
)

@overload
def Get(api: SyncInvokerProtocol, number: str, buffer: bool) -> ResponseEnvelope[OwnOrder]: ...
@overload
def Get(api: SyncRequestProtocol, number: str, buffer: bool) -> ResponseEnvelope[OwnOrder]: ...
@overload
def Get(api: AsyncInvokerProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[OwnOrder]]: ...
@overload
def Get(api: AsyncRequestProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[OwnOrder]]: ...
def Get(api: object, number: str, buffer: bool) -> ResponseEnvelope[OwnOrder] | Awaitable[ResponseEnvelope[OwnOrder]]:
    params, data = _prepare_Get(number=number, buffer=buffer)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetList(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]]: ...
@overload
def GetList(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]]: ...
@overload
def GetList(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]: ...
@overload
def GetList(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]: ...
def GetList(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]] | Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]:
    params, data = _prepare_GetList(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetList, params=params, data=data)

@overload
def GetListByDeliverer(api: SyncInvokerProtocol, delivererCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]]: ...
@overload
def GetListByDeliverer(api: SyncRequestProtocol, delivererCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]]: ...
@overload
def GetListByDeliverer(api: AsyncInvokerProtocol, delivererCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]: ...
@overload
def GetListByDeliverer(api: AsyncRequestProtocol, delivererCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]: ...
def GetListByDeliverer(api: object, delivererCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]] | Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]:
    params, data = _prepare_GetListByDeliverer(delivererCode=delivererCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByDeliverer, params=params, data=data)

@overload
def GetListBySeller(api: SyncInvokerProtocol, sellerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]]: ...
@overload
def GetListBySeller(api: SyncRequestProtocol, sellerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]]: ...
@overload
def GetListBySeller(api: AsyncInvokerProtocol, sellerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]: ...
@overload
def GetListBySeller(api: AsyncRequestProtocol, sellerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]: ...
def GetListBySeller(api: object, sellerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]] | Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]:
    params, data = _prepare_GetListBySeller(sellerCode=sellerCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListBySeller, params=params, data=data)

@overload
def GetListByDimension(api: SyncInvokerProtocol, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[OwnOrderListElement]]: ...
@overload
def GetListByDimension(api: SyncRequestProtocol, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[OwnOrderListElement]]: ...
@overload
def GetListByDimension(api: AsyncInvokerProtocol, dimensionCode: str, dictionaryValue: str) -> Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]: ...
@overload
def GetListByDimension(api: AsyncRequestProtocol, dimensionCode: str, dictionaryValue: str) -> Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]: ...
def GetListByDimension(api: object, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[OwnOrderListElement]] | Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]:
    params, data = _prepare_GetListByDimension(dimensionCode=dimensionCode, dictionaryValue=dictionaryValue)
    return invoke_operation(api, OP_GetListByDimension, params=params, data=data)

@overload
def GetPZ(api: SyncInvokerProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OwnOrderPZ]]: ...
@overload
def GetPZ(api: SyncRequestProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OwnOrderPZ]]: ...
@overload
def GetPZ(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[OwnOrderPZ]]]: ...
@overload
def GetPZ(api: AsyncRequestProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[OwnOrderPZ]]]: ...
def GetPZ(api: object, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OwnOrderPZ]] | Awaitable[ResponseEnvelope[List[OwnOrderPZ]]]:
    params, data = _prepare_GetPZ(orderNumber=orderNumber, buffer=buffer)
    return invoke_operation(api, OP_GetPZ, params=params, data=data)

@overload
def GetFV(api: SyncInvokerProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OwnOrderFV]]: ...
@overload
def GetFV(api: SyncRequestProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OwnOrderFV]]: ...
@overload
def GetFV(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[OwnOrderFV]]]: ...
@overload
def GetFV(api: AsyncRequestProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[OwnOrderFV]]]: ...
def GetFV(api: object, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OwnOrderFV]] | Awaitable[ResponseEnvelope[List[OwnOrderFV]]]:
    params, data = _prepare_GetFV(orderNumber=orderNumber, buffer=buffer)
    return invoke_operation(api, OP_GetFV, params=params, data=data)

@overload
def GetPDF(api: SyncInvokerProtocol, orderNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: SyncRequestProtocol, orderNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool, settings: "PDFSettings") -> Awaitable[ResponseEnvelope[PDF]]: ...
@overload
def GetPDF(api: AsyncRequestProtocol, orderNumber: str, buffer: bool, settings: "PDFSettings") -> Awaitable[ResponseEnvelope[PDF]]: ...
def GetPDF(api: object, orderNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF] | Awaitable[ResponseEnvelope[PDF]]:
    params, data = _prepare_GetPDF(orderNumber=orderNumber, buffer=buffer, settings=settings)
    return invoke_operation(api, OP_GetPDF, params=params, data=data)

@overload
def GetDocumentSeries(api: SyncInvokerProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: SyncRequestProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: AsyncInvokerProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
@overload
def GetDocumentSeries(api: AsyncRequestProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
def GetDocumentSeries(api: object, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]] | Awaitable[ResponseEnvelope[List[DocumentSeries]]]:
    params, data = _prepare_GetDocumentSeries(documentTypeId=documentTypeId)
    return invoke_operation(api, OP_GetDocumentSeries, params=params, data=data)

@overload
def GetStatus(api: SyncInvokerProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[OwnOrderStatus]: ...
@overload
def GetStatus(api: SyncRequestProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[OwnOrderStatus]: ...
@overload
def GetStatus(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[OwnOrderStatus]]: ...
@overload
def GetStatus(api: AsyncRequestProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[OwnOrderStatus]]: ...
def GetStatus(api: object, orderNumber: str, buffer: bool) -> ResponseEnvelope[OwnOrderStatus] | Awaitable[ResponseEnvelope[OwnOrderStatus]]:
    params, data = _prepare_GetStatus(orderNumber=orderNumber, buffer=buffer)
    return invoke_operation(api, OP_GetStatus, params=params, data=data)

@overload
def GetPositionRelations(api: SyncInvokerProtocol, positionId: int) -> ResponseEnvelope[OwnOrderPositionRelation]: ...
@overload
def GetPositionRelations(api: SyncRequestProtocol, positionId: int) -> ResponseEnvelope[OwnOrderPositionRelation]: ...
@overload
def GetPositionRelations(api: AsyncInvokerProtocol, positionId: int) -> Awaitable[ResponseEnvelope[OwnOrderPositionRelation]]: ...
@overload
def GetPositionRelations(api: AsyncRequestProtocol, positionId: int) -> Awaitable[ResponseEnvelope[OwnOrderPositionRelation]]: ...
def GetPositionRelations(api: object, positionId: int) -> ResponseEnvelope[OwnOrderPositionRelation] | Awaitable[ResponseEnvelope[OwnOrderPositionRelation]]:
    params, data = _prepare_GetPositionRelations(positionId=positionId)
    return invoke_operation(api, OP_GetPositionRelations, params=params, data=data)

@overload
def GetPagedDocument(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocument(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocument(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocument(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocument, params=params, data=data)

@overload
def GetDocumentTypesWithRange(api: SyncInvokerProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]]: ...
@overload
def GetDocumentTypesWithRange(api: SyncRequestProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]]: ...
@overload
def GetDocumentTypesWithRange(api: AsyncInvokerProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]: ...
@overload
def GetDocumentTypesWithRange(api: AsyncRequestProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]: ...
def GetDocumentTypesWithRange(api: object, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OwnOrderListElement]] | Awaitable[ResponseEnvelope[List[OwnOrderListElement]]]:
    params, data = _prepare_GetDocumentTypesWithRange(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDocumentTypesWithRange, params=params, data=data)

__all__ = ["Get", "GetList", "GetListByDeliverer", "GetListBySeller", "GetListByDimension", "GetPZ", "GetFV", "GetPDF", "GetDocumentSeries", "GetStatus", "GetPositionRelations", "GetPagedDocument", "GetDocumentTypesWithRange"]
