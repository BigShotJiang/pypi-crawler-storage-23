from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrder
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderIssue
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderPZ

_ADAPTER_AddNew = TypeAdapter(OwnOrder)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[OwnOrder]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/OwnOrdersIssue/New', parser=_parse_AddNew)

def _parse_Delete(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Delete = OperationSpec(method='DELETE', path='/api/OwnOrdersIssue/Delete', parser=_parse_Delete)

_ADAPTER_Issue = TypeAdapter(OwnOrder)

def _parse_Issue(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[OwnOrder]:
    return parse_with_adapter(envelope, _ADAPTER_Issue)
OP_Issue = OperationSpec(method='PUT', path='/api/OwnOrdersIssue/InBuffer', parser=_parse_Issue)

_ADAPTER_IssuePZ = TypeAdapter(List[OwnOrderPZ])

def _parse_IssuePZ(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OwnOrderPZ]]:
    return parse_with_adapter(envelope, _ADAPTER_IssuePZ)
OP_IssuePZ = OperationSpec(method='PUT', path='/api/OwnOrdersIssue/PZ', parser=_parse_IssuePZ)

def _parse_ChangeDocumentNumber(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_ChangeDocumentNumber = OperationSpec(method='PATCH', path='/api/OwnOrdersIssue/DocumentNumber', parser=_parse_ChangeDocumentNumber)

def _parse_IssueFV(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_IssueFV = OperationSpec(method='PUT', path='/api/OwnOrdersIssue/FV', parser=_parse_IssueFV)
