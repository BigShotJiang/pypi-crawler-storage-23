from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/v2/OwnOrderDimensions')
def _prepare_Get(*, orderNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPositionsByOrderId = ('GET', '/api/v2/OwnOrderDimensions/Positions')
def _prepare_GetPositionsByOrderId(*, orderId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderId"] = orderId
    data = None
    return params or None, data

_REQUEST_GetPositionsByOrderNumber = ('GET', '/api/v2/OwnOrderDimensions/Positions')
def _prepare_GetPositionsByOrderNumber(*, orderNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPosition = ('GET', '/api/v2/OwnOrderDimensions/Positions')
def _prepare_GetPosition(*, positionId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["positionId"] = positionId
    data = None
    return params or None, data
