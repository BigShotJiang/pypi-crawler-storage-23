from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrder
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderIssue
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderPZ
from ._common import (
    _prepare_AddNew,
    _prepare_Delete,
    _prepare_Issue,
    _prepare_IssuePZ,
    _prepare_ChangeDocumentNumber,
    _prepare_IssueFV,
)
from ._ops import (
    OP_AddNew,
    OP_Delete,
    OP_Issue,
    OP_IssuePZ,
    OP_ChangeDocumentNumber,
    OP_IssueFV,
)

@overload
def AddNew(api: SyncInvokerProtocol, issue: bool, order: "OwnOrderIssue") -> ResponseEnvelope[OwnOrder]: ...
@overload
def AddNew(api: SyncRequestProtocol, issue: bool, order: "OwnOrderIssue") -> ResponseEnvelope[OwnOrder]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, issue: bool, order: "OwnOrderIssue") -> Awaitable[ResponseEnvelope[OwnOrder]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, issue: bool, order: "OwnOrderIssue") -> Awaitable[ResponseEnvelope[OwnOrder]]: ...
def AddNew(api: object, issue: bool, order: "OwnOrderIssue") -> ResponseEnvelope[OwnOrder] | Awaitable[ResponseEnvelope[OwnOrder]]:
    params, data = _prepare_AddNew(issue=issue, order=order)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Delete(api: SyncInvokerProtocol, number: str, buffer: bool) -> ResponseEnvelope[None]: ...
@overload
def Delete(api: SyncRequestProtocol, number: str, buffer: bool) -> ResponseEnvelope[None]: ...
@overload
def Delete(api: AsyncInvokerProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Delete(api: AsyncRequestProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[None]]: ...
def Delete(api: object, number: str, buffer: bool) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Delete(number=number, buffer=buffer)
    return invoke_operation(api, OP_Delete, params=params, data=data)

@overload
def Issue(api: SyncInvokerProtocol, number: str) -> ResponseEnvelope[OwnOrder]: ...
@overload
def Issue(api: SyncRequestProtocol, number: str) -> ResponseEnvelope[OwnOrder]: ...
@overload
def Issue(api: AsyncInvokerProtocol, number: str) -> Awaitable[ResponseEnvelope[OwnOrder]]: ...
@overload
def Issue(api: AsyncRequestProtocol, number: str) -> Awaitable[ResponseEnvelope[OwnOrder]]: ...
def Issue(api: object, number: str) -> ResponseEnvelope[OwnOrder] | Awaitable[ResponseEnvelope[OwnOrder]]:
    params, data = _prepare_Issue(number=number)
    return invoke_operation(api, OP_Issue, params=params, data=data)

@overload
def IssuePZ(api: SyncInvokerProtocol, orderNumber: str) -> ResponseEnvelope[List[OwnOrderPZ]]: ...
@overload
def IssuePZ(api: SyncRequestProtocol, orderNumber: str) -> ResponseEnvelope[List[OwnOrderPZ]]: ...
@overload
def IssuePZ(api: AsyncInvokerProtocol, orderNumber: str) -> Awaitable[ResponseEnvelope[List[OwnOrderPZ]]]: ...
@overload
def IssuePZ(api: AsyncRequestProtocol, orderNumber: str) -> Awaitable[ResponseEnvelope[List[OwnOrderPZ]]]: ...
def IssuePZ(api: object, orderNumber: str) -> ResponseEnvelope[List[OwnOrderPZ]] | Awaitable[ResponseEnvelope[List[OwnOrderPZ]]]:
    params, data = _prepare_IssuePZ(orderNumber=orderNumber)
    return invoke_operation(api, OP_IssuePZ, params=params, data=data)

@overload
def ChangeDocumentNumber(api: SyncInvokerProtocol, id: int, number: str) -> ResponseEnvelope[None]: ...
@overload
def ChangeDocumentNumber(api: SyncRequestProtocol, id: int, number: str) -> ResponseEnvelope[None]: ...
@overload
def ChangeDocumentNumber(api: AsyncInvokerProtocol, id: int, number: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def ChangeDocumentNumber(api: AsyncRequestProtocol, id: int, number: str) -> Awaitable[ResponseEnvelope[None]]: ...
def ChangeDocumentNumber(api: object, id: int, number: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_ChangeDocumentNumber(id=id, number=number)
    return invoke_operation(api, OP_ChangeDocumentNumber, params=params, data=data)

@overload
def IssueFV(api: SyncInvokerProtocol, orderNumber: str) -> ResponseEnvelope[None]: ...
@overload
def IssueFV(api: SyncRequestProtocol, orderNumber: str) -> ResponseEnvelope[None]: ...
@overload
def IssueFV(api: AsyncInvokerProtocol, orderNumber: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def IssueFV(api: AsyncRequestProtocol, orderNumber: str) -> Awaitable[ResponseEnvelope[None]]: ...
def IssueFV(api: object, orderNumber: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_IssueFV(orderNumber=orderNumber)
    return invoke_operation(api, OP_IssueFV, params=params, data=data)

__all__ = ["AddNew", "Delete", "Issue", "IssuePZ", "ChangeDocumentNumber", "IssueFV"]
