from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/OwnOrdersIssue/New')
def _prepare_AddNew(*, issue, order) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["issue"] = issue
    data = order.model_dump_json(exclude_unset=True) if order is not None else None
    return params or None, data

_REQUEST_Delete = ('DELETE', '/api/OwnOrdersIssue/Delete')
def _prepare_Delete(*, number, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_Issue = ('PUT', '/api/OwnOrdersIssue/InBuffer')
def _prepare_Issue(*, number) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    data = None
    return params or None, data

_REQUEST_IssuePZ = ('PUT', '/api/OwnOrdersIssue/PZ')
def _prepare_IssuePZ(*, orderNumber) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    data = None
    return params or None, data

_REQUEST_ChangeDocumentNumber = ('PATCH', '/api/OwnOrdersIssue/DocumentNumber')
def _prepare_ChangeDocumentNumber(*, id, number) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    params["number"] = number
    data = None
    return params or None, data

_REQUEST_IssueFV = ('PUT', '/api/OwnOrdersIssue/FV')
def _prepare_IssueFV(*, orderNumber) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    data = None
    return params or None, data
