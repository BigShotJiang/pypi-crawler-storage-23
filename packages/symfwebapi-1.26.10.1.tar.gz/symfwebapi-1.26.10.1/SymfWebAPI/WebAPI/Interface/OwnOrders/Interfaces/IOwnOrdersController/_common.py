from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/OwnOrders')
def _prepare_Get(*, number, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetList = ('GET', '/api/OwnOrders/Filter')
def _prepare_GetList(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByDeliverer = ('GET', '/api/OwnOrders/Filter')
def _prepare_GetListByDeliverer(*, delivererCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["delivererCode"] = delivererCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListBySeller = ('GET', '/api/OwnOrders/Filter')
def _prepare_GetListBySeller(*, sellerCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["sellerCode"] = sellerCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByDimension = ('GET', '/api/OwnOrders/Filter')
def _prepare_GetListByDimension(*, dimensionCode, dictionaryValue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dimensionCode"] = dimensionCode
    params["dictionaryValue"] = dictionaryValue
    data = None
    return params or None, data

_REQUEST_GetPZ = ('GET', '/api/OwnOrders/PZ')
def _prepare_GetPZ(*, orderNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetFV = ('GET', '/api/OwnOrders/FV')
def _prepare_GetFV(*, orderNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPDF = ('PATCH', '/api/OwnOrders/PDF')
def _prepare_GetPDF(*, orderNumber, buffer, settings) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = settings.model_dump_json(exclude_unset=True) if settings is not None else None
    return params or None, data

_REQUEST_GetDocumentSeries = ('GET', '/api/OwnOrders/DocumentSeries')
def _prepare_GetDocumentSeries(*, documentTypeId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentTypeId"] = documentTypeId
    data = None
    return params or None, data

_REQUEST_GetStatus = ('GET', '/api/OwnOrders/Status')
def _prepare_GetStatus(*, orderNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPositionRelations = ('GET', '/api/OwnOrders/PositionRelations')
def _prepare_GetPositionRelations(*, positionId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["positionId"] = positionId
    data = None
    return params or None, data

_REQUEST_GetPagedDocument = ('GET', '/api/OwnOrders/Page')
def _prepare_GetPagedDocument(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data

_REQUEST_GetDocumentTypesWithRange = ('GET', '/api/OwnOrders/Filter/ByDocumentTypes')
def _prepare_GetDocumentTypesWithRange(*, dateFrom, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data
