from __future__ import annotations

from typing import List, Optional
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import FilterDocumentType
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrder
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderFV
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderListElement
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderPZ
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderPositionRelation
from SymfWebAPI.WebAPI.Interface.OwnOrders.ViewModels import OwnOrderStatus
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDFSettings
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

_ADAPTER_Get = TypeAdapter(OwnOrder)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[OwnOrder]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/OwnOrders', parser=_parse_Get)

_ADAPTER_GetList = TypeAdapter(List[OwnOrderListElement])

def _parse_GetList(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OwnOrderListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetList)
OP_GetList = OperationSpec(method='GET', path='/api/OwnOrders/Filter', parser=_parse_GetList)

_ADAPTER_GetListByDeliverer = TypeAdapter(List[OwnOrderListElement])

def _parse_GetListByDeliverer(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OwnOrderListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByDeliverer)
OP_GetListByDeliverer = OperationSpec(method='GET', path='/api/OwnOrders/Filter', parser=_parse_GetListByDeliverer)

_ADAPTER_GetListBySeller = TypeAdapter(List[OwnOrderListElement])

def _parse_GetListBySeller(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OwnOrderListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListBySeller)
OP_GetListBySeller = OperationSpec(method='GET', path='/api/OwnOrders/Filter', parser=_parse_GetListBySeller)

_ADAPTER_GetListByDimension = TypeAdapter(List[OwnOrderListElement])

def _parse_GetListByDimension(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OwnOrderListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByDimension)
OP_GetListByDimension = OperationSpec(method='GET', path='/api/OwnOrders/Filter', parser=_parse_GetListByDimension)

_ADAPTER_GetPZ = TypeAdapter(List[OwnOrderPZ])

def _parse_GetPZ(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OwnOrderPZ]]:
    return parse_with_adapter(envelope, _ADAPTER_GetPZ)
OP_GetPZ = OperationSpec(method='GET', path='/api/OwnOrders/PZ', parser=_parse_GetPZ)

_ADAPTER_GetFV = TypeAdapter(List[OwnOrderFV])

def _parse_GetFV(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OwnOrderFV]]:
    return parse_with_adapter(envelope, _ADAPTER_GetFV)
OP_GetFV = OperationSpec(method='GET', path='/api/OwnOrders/FV', parser=_parse_GetFV)

_ADAPTER_GetPDF = TypeAdapter(PDF)

def _parse_GetPDF(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PDF]:
    return parse_with_adapter(envelope, _ADAPTER_GetPDF)
OP_GetPDF = OperationSpec(method='PATCH', path='/api/OwnOrders/PDF', parser=_parse_GetPDF)

_ADAPTER_GetDocumentSeries = TypeAdapter(List[DocumentSeries])

def _parse_GetDocumentSeries(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentSeries]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentSeries)
OP_GetDocumentSeries = OperationSpec(method='GET', path='/api/OwnOrders/DocumentSeries', parser=_parse_GetDocumentSeries)

_ADAPTER_GetStatus = TypeAdapter(OwnOrderStatus)

def _parse_GetStatus(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[OwnOrderStatus]:
    return parse_with_adapter(envelope, _ADAPTER_GetStatus)
OP_GetStatus = OperationSpec(method='GET', path='/api/OwnOrders/Status', parser=_parse_GetStatus)

_ADAPTER_GetPositionRelations = TypeAdapter(OwnOrderPositionRelation)

def _parse_GetPositionRelations(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[OwnOrderPositionRelation]:
    return parse_with_adapter(envelope, _ADAPTER_GetPositionRelations)
OP_GetPositionRelations = OperationSpec(method='GET', path='/api/OwnOrders/PositionRelations', parser=_parse_GetPositionRelations)

_ADAPTER_GetPagedDocument = TypeAdapter(Page)

def _parse_GetPagedDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocument)
OP_GetPagedDocument = OperationSpec(method='GET', path='/api/OwnOrders/Page', parser=_parse_GetPagedDocument)

_ADAPTER_GetDocumentTypesWithRange = TypeAdapter(List[OwnOrderListElement])

def _parse_GetDocumentTypesWithRange(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OwnOrderListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentTypesWithRange)
OP_GetDocumentTypesWithRange = OperationSpec(method='GET', path='/api/OwnOrders/Filter/ByDocumentTypes', parser=_parse_GetDocumentTypesWithRange)
