from __future__ import annotations

from typing import Any

_REQUEST_Get = ('PATCH', '/api/Reports')
def _prepare_Get(*, reportId, objectId, data) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["reportId"] = reportId
    params["objectId"] = objectId
    data = data.model_dump_json(exclude_unset=True) if data is not None else None
    return params or None, data
