from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.RepX.ViewModels import PrintData

_ADAPTER_Get = TypeAdapter(PDF)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PDF]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='PATCH', path='/api/Reports', parser=_parse_Get)
