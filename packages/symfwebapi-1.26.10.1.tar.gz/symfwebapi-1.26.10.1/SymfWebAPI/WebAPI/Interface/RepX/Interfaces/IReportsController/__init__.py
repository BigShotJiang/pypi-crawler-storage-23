from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.RepX.ViewModels import PrintData
from ._common import (
    _prepare_Get,
)
from ._ops import (
    OP_Get,
)

@overload
def Get(api: SyncInvokerProtocol, reportId: int, objectId: int, data: "PrintData") -> ResponseEnvelope[PDF]: ...
@overload
def Get(api: SyncRequestProtocol, reportId: int, objectId: int, data: "PrintData") -> ResponseEnvelope[PDF]: ...
@overload
def Get(api: AsyncInvokerProtocol, reportId: int, objectId: int, data: "PrintData") -> Awaitable[ResponseEnvelope[PDF]]: ...
@overload
def Get(api: AsyncRequestProtocol, reportId: int, objectId: int, data: "PrintData") -> Awaitable[ResponseEnvelope[PDF]]: ...
def Get(api: object, reportId: int, objectId: int, data: "PrintData") -> ResponseEnvelope[PDF] | Awaitable[ResponseEnvelope[PDF]]:
    params, data = _prepare_Get(reportId=reportId, objectId=objectId, data=data)
    return invoke_operation(api, OP_Get, params=params, data=data)

__all__ = ["Get"]
