from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import IncrementalSyncListElement
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.PriceLists import PriceList

_ADAPTER_Get = TypeAdapter(PriceList)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PriceList]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/PriceLists', parser=_parse_Get)

_ADAPTER_IncrementalSync = TypeAdapter(List[IncrementalSyncListElement])

def _parse_IncrementalSync(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[IncrementalSyncListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_IncrementalSync)
OP_IncrementalSync = OperationSpec(method='GET', path='/api/PriceLists/IncrementalSync', parser=_parse_IncrementalSync)
