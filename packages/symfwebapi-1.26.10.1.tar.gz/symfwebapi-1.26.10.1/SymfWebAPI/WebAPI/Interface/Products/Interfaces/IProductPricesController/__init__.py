from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import IndividualDiscount
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.PriceCalculations import PriceCalculationCriteria
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.PriceCalculations import PriceCalculationResult
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import PriceFactor
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import PriceFactorCriteria
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.PriceCalculations import PriceOrderCriteria
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.PriceCalculations import PriceOrderResult
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import ProductPriceListElement
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import ProductPricesEdit
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import ProductSalePriceBase
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import QuantitativeDiscount
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import QuantitativeDiscountListElement
from ._common import (
    _prepare_Update,
    _prepare_Recalculate,
    _prepare_GetSalePricesByProduct,
    _prepare_GetSalePricesByProductKind,
    _prepare_GetQuantitativeDiscountsByProduct,
    _prepare_GetQuantitativeDiscountsByProductKind,
    _prepare_GetIndividualDiscountsByContractor,
    _prepare_GetIndividualDiscountsByContractorKind,
    _prepare_GetPriceFactors,
    _prepare_CalculatePrices,
    _prepare_OrderPrices,
)
from ._ops import (
    OP_Update,
    OP_Recalculate,
    OP_GetSalePricesByProduct,
    OP_GetSalePricesByProductKind,
    OP_GetQuantitativeDiscountsByProduct,
    OP_GetQuantitativeDiscountsByProductKind,
    OP_GetIndividualDiscountsByContractor,
    OP_GetIndividualDiscountsByContractorKind,
    OP_GetPriceFactors,
    OP_CalculatePrices,
    OP_OrderPrices,
)

@overload
def Update(api: SyncInvokerProtocol, productCode: str, prices: "ProductPricesEdit") -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, productCode: str, prices: "ProductPricesEdit") -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, productCode: str, prices: "ProductPricesEdit") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, productCode: str, prices: "ProductPricesEdit") -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, productCode: str, prices: "ProductPricesEdit") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(productCode=productCode, prices=prices)
    return invoke_operation(api, OP_Update, params=params, data=data)

@overload
def Recalculate(api: SyncInvokerProtocol, productCode: str) -> ResponseEnvelope[None]: ...
@overload
def Recalculate(api: SyncRequestProtocol, productCode: str) -> ResponseEnvelope[None]: ...
@overload
def Recalculate(api: AsyncInvokerProtocol, productCode: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Recalculate(api: AsyncRequestProtocol, productCode: str) -> Awaitable[ResponseEnvelope[None]]: ...
def Recalculate(api: object, productCode: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Recalculate(productCode=productCode)
    return invoke_operation(api, OP_Recalculate, params=params, data=data)

@overload
def GetSalePricesByProduct(api: SyncInvokerProtocol, productCode: str) -> ResponseEnvelope[List[ProductSalePriceBase]]: ...
@overload
def GetSalePricesByProduct(api: SyncRequestProtocol, productCode: str) -> ResponseEnvelope[List[ProductSalePriceBase]]: ...
@overload
def GetSalePricesByProduct(api: AsyncInvokerProtocol, productCode: str) -> Awaitable[ResponseEnvelope[List[ProductSalePriceBase]]]: ...
@overload
def GetSalePricesByProduct(api: AsyncRequestProtocol, productCode: str) -> Awaitable[ResponseEnvelope[List[ProductSalePriceBase]]]: ...
def GetSalePricesByProduct(api: object, productCode: str) -> ResponseEnvelope[List[ProductSalePriceBase]] | Awaitable[ResponseEnvelope[List[ProductSalePriceBase]]]:
    params, data = _prepare_GetSalePricesByProduct(productCode=productCode)
    return invoke_operation(api, OP_GetSalePricesByProduct, params=params, data=data)

@overload
def GetSalePricesByProductKind(api: SyncInvokerProtocol, productKindId: int) -> ResponseEnvelope[List[ProductPriceListElement]]: ...
@overload
def GetSalePricesByProductKind(api: SyncRequestProtocol, productKindId: int) -> ResponseEnvelope[List[ProductPriceListElement]]: ...
@overload
def GetSalePricesByProductKind(api: AsyncInvokerProtocol, productKindId: int) -> Awaitable[ResponseEnvelope[List[ProductPriceListElement]]]: ...
@overload
def GetSalePricesByProductKind(api: AsyncRequestProtocol, productKindId: int) -> Awaitable[ResponseEnvelope[List[ProductPriceListElement]]]: ...
def GetSalePricesByProductKind(api: object, productKindId: int) -> ResponseEnvelope[List[ProductPriceListElement]] | Awaitable[ResponseEnvelope[List[ProductPriceListElement]]]:
    params, data = _prepare_GetSalePricesByProductKind(productKindId=productKindId)
    return invoke_operation(api, OP_GetSalePricesByProductKind, params=params, data=data)

@overload
def GetQuantitativeDiscountsByProduct(api: SyncInvokerProtocol, productCode: str) -> ResponseEnvelope[List[QuantitativeDiscount]]: ...
@overload
def GetQuantitativeDiscountsByProduct(api: SyncRequestProtocol, productCode: str) -> ResponseEnvelope[List[QuantitativeDiscount]]: ...
@overload
def GetQuantitativeDiscountsByProduct(api: AsyncInvokerProtocol, productCode: str) -> Awaitable[ResponseEnvelope[List[QuantitativeDiscount]]]: ...
@overload
def GetQuantitativeDiscountsByProduct(api: AsyncRequestProtocol, productCode: str) -> Awaitable[ResponseEnvelope[List[QuantitativeDiscount]]]: ...
def GetQuantitativeDiscountsByProduct(api: object, productCode: str) -> ResponseEnvelope[List[QuantitativeDiscount]] | Awaitable[ResponseEnvelope[List[QuantitativeDiscount]]]:
    params, data = _prepare_GetQuantitativeDiscountsByProduct(productCode=productCode)
    return invoke_operation(api, OP_GetQuantitativeDiscountsByProduct, params=params, data=data)

@overload
def GetQuantitativeDiscountsByProductKind(api: SyncInvokerProtocol, productKindId: int) -> ResponseEnvelope[List[QuantitativeDiscountListElement]]: ...
@overload
def GetQuantitativeDiscountsByProductKind(api: SyncRequestProtocol, productKindId: int) -> ResponseEnvelope[List[QuantitativeDiscountListElement]]: ...
@overload
def GetQuantitativeDiscountsByProductKind(api: AsyncInvokerProtocol, productKindId: int) -> Awaitable[ResponseEnvelope[List[QuantitativeDiscountListElement]]]: ...
@overload
def GetQuantitativeDiscountsByProductKind(api: AsyncRequestProtocol, productKindId: int) -> Awaitable[ResponseEnvelope[List[QuantitativeDiscountListElement]]]: ...
def GetQuantitativeDiscountsByProductKind(api: object, productKindId: int) -> ResponseEnvelope[List[QuantitativeDiscountListElement]] | Awaitable[ResponseEnvelope[List[QuantitativeDiscountListElement]]]:
    params, data = _prepare_GetQuantitativeDiscountsByProductKind(productKindId=productKindId)
    return invoke_operation(api, OP_GetQuantitativeDiscountsByProductKind, params=params, data=data)

@overload
def GetIndividualDiscountsByContractor(api: SyncInvokerProtocol, contractorCode: str) -> ResponseEnvelope[List[IndividualDiscount]]: ...
@overload
def GetIndividualDiscountsByContractor(api: SyncRequestProtocol, contractorCode: str) -> ResponseEnvelope[List[IndividualDiscount]]: ...
@overload
def GetIndividualDiscountsByContractor(api: AsyncInvokerProtocol, contractorCode: str) -> Awaitable[ResponseEnvelope[List[IndividualDiscount]]]: ...
@overload
def GetIndividualDiscountsByContractor(api: AsyncRequestProtocol, contractorCode: str) -> Awaitable[ResponseEnvelope[List[IndividualDiscount]]]: ...
def GetIndividualDiscountsByContractor(api: object, contractorCode: str) -> ResponseEnvelope[List[IndividualDiscount]] | Awaitable[ResponseEnvelope[List[IndividualDiscount]]]:
    params, data = _prepare_GetIndividualDiscountsByContractor(contractorCode=contractorCode)
    return invoke_operation(api, OP_GetIndividualDiscountsByContractor, params=params, data=data)

@overload
def GetIndividualDiscountsByContractorKind(api: SyncInvokerProtocol, contractorKindId: int) -> ResponseEnvelope[List[IndividualDiscount]]: ...
@overload
def GetIndividualDiscountsByContractorKind(api: SyncRequestProtocol, contractorKindId: int) -> ResponseEnvelope[List[IndividualDiscount]]: ...
@overload
def GetIndividualDiscountsByContractorKind(api: AsyncInvokerProtocol, contractorKindId: int) -> Awaitable[ResponseEnvelope[List[IndividualDiscount]]]: ...
@overload
def GetIndividualDiscountsByContractorKind(api: AsyncRequestProtocol, contractorKindId: int) -> Awaitable[ResponseEnvelope[List[IndividualDiscount]]]: ...
def GetIndividualDiscountsByContractorKind(api: object, contractorKindId: int) -> ResponseEnvelope[List[IndividualDiscount]] | Awaitable[ResponseEnvelope[List[IndividualDiscount]]]:
    params, data = _prepare_GetIndividualDiscountsByContractorKind(contractorKindId=contractorKindId)
    return invoke_operation(api, OP_GetIndividualDiscountsByContractorKind, params=params, data=data)

@overload
def GetPriceFactors(api: SyncInvokerProtocol, criteria: "PriceFactorCriteria") -> ResponseEnvelope[List[PriceFactor]]: ...
@overload
def GetPriceFactors(api: SyncRequestProtocol, criteria: "PriceFactorCriteria") -> ResponseEnvelope[List[PriceFactor]]: ...
@overload
def GetPriceFactors(api: AsyncInvokerProtocol, criteria: "PriceFactorCriteria") -> Awaitable[ResponseEnvelope[List[PriceFactor]]]: ...
@overload
def GetPriceFactors(api: AsyncRequestProtocol, criteria: "PriceFactorCriteria") -> Awaitable[ResponseEnvelope[List[PriceFactor]]]: ...
def GetPriceFactors(api: object, criteria: "PriceFactorCriteria") -> ResponseEnvelope[List[PriceFactor]] | Awaitable[ResponseEnvelope[List[PriceFactor]]]:
    params, data = _prepare_GetPriceFactors(criteria=criteria)
    return invoke_operation(api, OP_GetPriceFactors, params=params, data=data)

@overload
def CalculatePrices(api: SyncInvokerProtocol, criteria: "PriceCalculationCriteria") -> ResponseEnvelope[PriceCalculationResult]: ...
@overload
def CalculatePrices(api: SyncRequestProtocol, criteria: "PriceCalculationCriteria") -> ResponseEnvelope[PriceCalculationResult]: ...
@overload
def CalculatePrices(api: AsyncInvokerProtocol, criteria: "PriceCalculationCriteria") -> Awaitable[ResponseEnvelope[PriceCalculationResult]]: ...
@overload
def CalculatePrices(api: AsyncRequestProtocol, criteria: "PriceCalculationCriteria") -> Awaitable[ResponseEnvelope[PriceCalculationResult]]: ...
def CalculatePrices(api: object, criteria: "PriceCalculationCriteria") -> ResponseEnvelope[PriceCalculationResult] | Awaitable[ResponseEnvelope[PriceCalculationResult]]:
    params, data = _prepare_CalculatePrices(criteria=criteria)
    return invoke_operation(api, OP_CalculatePrices, params=params, data=data)

@overload
def OrderPrices(api: SyncInvokerProtocol, criteria: "PriceOrderCriteria") -> ResponseEnvelope[PriceOrderResult]: ...
@overload
def OrderPrices(api: SyncRequestProtocol, criteria: "PriceOrderCriteria") -> ResponseEnvelope[PriceOrderResult]: ...
@overload
def OrderPrices(api: AsyncInvokerProtocol, criteria: "PriceOrderCriteria") -> Awaitable[ResponseEnvelope[PriceOrderResult]]: ...
@overload
def OrderPrices(api: AsyncRequestProtocol, criteria: "PriceOrderCriteria") -> Awaitable[ResponseEnvelope[PriceOrderResult]]: ...
def OrderPrices(api: object, criteria: "PriceOrderCriteria") -> ResponseEnvelope[PriceOrderResult] | Awaitable[ResponseEnvelope[PriceOrderResult]]:
    params, data = _prepare_OrderPrices(criteria=criteria)
    return invoke_operation(api, OP_OrderPrices, params=params, data=data)

__all__ = ["Update", "Recalculate", "GetSalePricesByProduct", "GetSalePricesByProductKind", "GetQuantitativeDiscountsByProduct", "GetQuantitativeDiscountsByProductKind", "GetIndividualDiscountsByContractor", "GetIndividualDiscountsByContractorKind", "GetPriceFactors", "CalculatePrices", "OrderPrices"]
