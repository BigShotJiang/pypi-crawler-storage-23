from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import IndividualDiscount
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.PriceCalculations import PriceCalculationCriteria
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.PriceCalculations import PriceCalculationResult
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import PriceFactor
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import PriceFactorCriteria
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.PriceCalculations import PriceOrderCriteria
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.PriceCalculations import PriceOrderResult
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import ProductPriceListElement
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import ProductPricesEdit
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import ProductSalePriceBase
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import QuantitativeDiscount
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.Prices import QuantitativeDiscountListElement

def _parse_Update(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Update = OperationSpec(method='PUT', path='/api/ProductPrices/Update', parser=_parse_Update)

def _parse_Recalculate(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Recalculate = OperationSpec(method='PATCH', path='/api/ProductPrices/Recalculate', parser=_parse_Recalculate)

_ADAPTER_GetSalePricesByProduct = TypeAdapter(List[ProductSalePriceBase])

def _parse_GetSalePricesByProduct(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductSalePriceBase]]:
    return parse_with_adapter(envelope, _ADAPTER_GetSalePricesByProduct)
OP_GetSalePricesByProduct = OperationSpec(method='GET', path='/api/ProductPrices/SalePrices', parser=_parse_GetSalePricesByProduct)

_ADAPTER_GetSalePricesByProductKind = TypeAdapter(List[ProductPriceListElement])

def _parse_GetSalePricesByProductKind(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductPriceListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetSalePricesByProductKind)
OP_GetSalePricesByProductKind = OperationSpec(method='GET', path='/api/ProductPrices/SalePrices', parser=_parse_GetSalePricesByProductKind)

_ADAPTER_GetQuantitativeDiscountsByProduct = TypeAdapter(List[QuantitativeDiscount])

def _parse_GetQuantitativeDiscountsByProduct(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[QuantitativeDiscount]]:
    return parse_with_adapter(envelope, _ADAPTER_GetQuantitativeDiscountsByProduct)
OP_GetQuantitativeDiscountsByProduct = OperationSpec(method='GET', path='/api/ProductPrices/QuantitativeDiscounts', parser=_parse_GetQuantitativeDiscountsByProduct)

_ADAPTER_GetQuantitativeDiscountsByProductKind = TypeAdapter(List[QuantitativeDiscountListElement])

def _parse_GetQuantitativeDiscountsByProductKind(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[QuantitativeDiscountListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetQuantitativeDiscountsByProductKind)
OP_GetQuantitativeDiscountsByProductKind = OperationSpec(method='GET', path='/api/ProductPrices/QuantitativeDiscounts', parser=_parse_GetQuantitativeDiscountsByProductKind)

_ADAPTER_GetIndividualDiscountsByContractor = TypeAdapter(List[IndividualDiscount])

def _parse_GetIndividualDiscountsByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[IndividualDiscount]]:
    return parse_with_adapter(envelope, _ADAPTER_GetIndividualDiscountsByContractor)
OP_GetIndividualDiscountsByContractor = OperationSpec(method='GET', path='/api/ProductPrices/IndividualDiscounts', parser=_parse_GetIndividualDiscountsByContractor)

_ADAPTER_GetIndividualDiscountsByContractorKind = TypeAdapter(List[IndividualDiscount])

def _parse_GetIndividualDiscountsByContractorKind(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[IndividualDiscount]]:
    return parse_with_adapter(envelope, _ADAPTER_GetIndividualDiscountsByContractorKind)
OP_GetIndividualDiscountsByContractorKind = OperationSpec(method='GET', path='/api/ProductPrices/IndividualDiscounts', parser=_parse_GetIndividualDiscountsByContractorKind)

_ADAPTER_GetPriceFactors = TypeAdapter(List[PriceFactor])

def _parse_GetPriceFactors(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PriceFactor]]:
    return parse_with_adapter(envelope, _ADAPTER_GetPriceFactors)
OP_GetPriceFactors = OperationSpec(method='GET', path='/api/ProductPrices/PriceFactors', parser=_parse_GetPriceFactors)

_ADAPTER_CalculatePrices = TypeAdapter(PriceCalculationResult)

def _parse_CalculatePrices(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PriceCalculationResult]:
    return parse_with_adapter(envelope, _ADAPTER_CalculatePrices)
OP_CalculatePrices = OperationSpec(method='PATCH', path='/api/ProductPrices/CalculatePrices', parser=_parse_CalculatePrices)

_ADAPTER_OrderPrices = TypeAdapter(PriceOrderResult)

def _parse_OrderPrices(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PriceOrderResult]:
    return parse_with_adapter(envelope, _ADAPTER_OrderPrices)
OP_OrderPrices = OperationSpec(method='PATCH', path='/api/ProductPrices/OrderPrices', parser=_parse_OrderPrices)
