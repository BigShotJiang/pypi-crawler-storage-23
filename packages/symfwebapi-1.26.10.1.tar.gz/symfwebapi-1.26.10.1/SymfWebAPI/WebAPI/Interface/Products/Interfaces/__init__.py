"""Auto-generated package (lazy imports)."""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

__all__ = ("IPriceListsController", "IProductDimensions2Controller", "IProductDimensionsController", "IProductPhotosController", "IProductPricesController", "IProductsController",)

def __getattr__(name: str):
    if name in __all__:
        module = importlib.import_module(f".{name}", __name__)
        globals()[name] = module
        return module
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

def __dir__():
    return sorted(set(__all__) | {n for n in globals() if not n.startswith('_')})

if TYPE_CHECKING:
    from . import IPriceListsController as _IPriceListsController
    from . import IProductDimensions2Controller as _IProductDimensions2Controller
    from . import IProductDimensionsController as _IProductDimensionsController
    from . import IProductPhotosController as _IProductPhotosController
    from . import IProductPricesController as _IProductPricesController
    from . import IProductsController as _IProductsController
