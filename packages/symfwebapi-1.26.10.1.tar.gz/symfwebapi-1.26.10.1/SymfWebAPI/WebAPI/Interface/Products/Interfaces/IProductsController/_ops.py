from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import IncrementalSyncListElement
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import Product
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductBarcodes
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductCriteriaFilter
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductFilterCriteria
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductListElement
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductListElementWithDimensions
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductListElementWithSalePrices
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductLogisticField
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

_ADAPTER_Get = TypeAdapter(List[ProductListElement])

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/Products', parser=_parse_Get)

_ADAPTER_Filter = TypeAdapter(List[ProductListElement])

def _parse_Filter(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_Filter)
OP_Filter = OperationSpec(method='PATCH', path='/api/Products/Filter', parser=_parse_Filter)

_ADAPTER_FilterWithSalePrices = TypeAdapter(List[ProductListElementWithSalePrices])

def _parse_FilterWithSalePrices(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductListElementWithSalePrices]]:
    return parse_with_adapter(envelope, _ADAPTER_FilterWithSalePrices)
OP_FilterWithSalePrices = OperationSpec(method='PATCH', path='/api/Products/Filter/WithSalePrices', parser=_parse_FilterWithSalePrices)

_ADAPTER_FilterWithDimensions = TypeAdapter(List[ProductListElementWithDimensions])

def _parse_FilterWithDimensions(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductListElementWithDimensions]]:
    return parse_with_adapter(envelope, _ADAPTER_FilterWithDimensions)
OP_FilterWithDimensions = OperationSpec(method='PATCH', path='/api/Products/Filter/WithDimensions', parser=_parse_FilterWithDimensions)

_ADAPTER_AddNew = TypeAdapter(Product)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Product]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/Products/Create', parser=_parse_AddNew)

def _parse_Update(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Update = OperationSpec(method='PUT', path='/api/Products/Update', parser=_parse_Update)

_ADAPTER_IncrementalSync = TypeAdapter(List[IncrementalSyncListElement])

def _parse_IncrementalSync(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[IncrementalSyncListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_IncrementalSync)
OP_IncrementalSync = OperationSpec(method='GET', path='/api/Products/IncrementalSync', parser=_parse_IncrementalSync)

_ADAPTER_GetBarcodes = TypeAdapter(ProductBarcodes)

def _parse_GetBarcodes(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[ProductBarcodes]:
    return parse_with_adapter(envelope, _ADAPTER_GetBarcodes)
OP_GetBarcodes = OperationSpec(method='GET', path='/api/Products/Barcodes', parser=_parse_GetBarcodes)

def _parse_UpdateBarcodes(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_UpdateBarcodes = OperationSpec(method='GET', path='/api/Products/UpdateBarcodes', parser=_parse_UpdateBarcodes)

_ADAPTER_FilterSql = TypeAdapter(List[ProductListElement])

def _parse_FilterSql(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_FilterSql)
OP_FilterSql = OperationSpec(method='PATCH', path='/api/Products/FilterSql', parser=_parse_FilterSql)

_ADAPTER_GetPagedDocument = TypeAdapter(Page)

def _parse_GetPagedDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocument)
OP_GetPagedDocument = OperationSpec(method='GET', path='/api/Products/Page', parser=_parse_GetPagedDocument)

_ADAPTER_GetPageWithSalePrices = TypeAdapter(Page)

def _parse_GetPageWithSalePrices(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPageWithSalePrices)
OP_GetPageWithSalePrices = OperationSpec(method='GET', path='/api/Products/Page/WithSalePrices', parser=_parse_GetPageWithSalePrices)

_ADAPTER_GetPageWithDimensions = TypeAdapter(Page)

def _parse_GetPageWithDimensions(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPageWithDimensions)
OP_GetPageWithDimensions = OperationSpec(method='GET', path='/api/Products/Page/WithDimensions', parser=_parse_GetPageWithDimensions)

_ADAPTER_FilterSqlWthSalePrices = TypeAdapter(List[ProductListElementWithSalePrices])

def _parse_FilterSqlWthSalePrices(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductListElementWithSalePrices]]:
    return parse_with_adapter(envelope, _ADAPTER_FilterSqlWthSalePrices)
OP_FilterSqlWthSalePrices = OperationSpec(method='PATCH', path='/api/Products/FilterSql/WithSalePrices', parser=_parse_FilterSqlWthSalePrices)

_ADAPTER_FilterSqlWthDimensions = TypeAdapter(List[ProductListElementWithDimensions])

def _parse_FilterSqlWthDimensions(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductListElementWithDimensions]]:
    return parse_with_adapter(envelope, _ADAPTER_FilterSqlWthDimensions)
OP_FilterSqlWthDimensions = OperationSpec(method='PATCH', path='/api/Products/FilterSql/WithDimensions', parser=_parse_FilterSqlWthDimensions)

_ADAPTER_GetLogisticFields = TypeAdapter(List[ProductLogisticField])

def _parse_GetLogisticFields(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ProductLogisticField]]:
    return parse_with_adapter(envelope, _ADAPTER_GetLogisticFields)
OP_GetLogisticFields = OperationSpec(method='GET', path='/api/Products/LogisticFields', parser=_parse_GetLogisticFields)
