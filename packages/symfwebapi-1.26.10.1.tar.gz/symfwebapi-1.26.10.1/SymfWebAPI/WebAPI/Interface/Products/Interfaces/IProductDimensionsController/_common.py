from __future__ import annotations

from typing import Any

import json

_REQUEST_Get = ('GET', '/api/ProductDimensions')
def _prepare_Get(*, productCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["productCode"] = productCode
    data = None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/ProductDimensions/UpdateList')
def _prepare_Update(*, productCode, productDimensions) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["productCode"] = productCode
    data = json.dumps(productDimensions) if productDimensions is not None else None
    return params or None, data
