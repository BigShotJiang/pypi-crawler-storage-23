from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension
from ._common import (
    _prepare_Get,
    _prepare_Update,
)
from ._ops import (
    OP_Get,
    OP_Update,
)

@overload
def Get(api: SyncInvokerProtocol, productCode: str) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def Get(api: SyncRequestProtocol, productCode: str) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def Get(api: AsyncInvokerProtocol, productCode: str) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def Get(api: AsyncRequestProtocol, productCode: str) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def Get(api: object, productCode: str) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_Get(productCode=productCode)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def Update(api: SyncInvokerProtocol, productCode: str, productDimensions: List["Dimension"]) -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, productCode: str, productDimensions: List["Dimension"]) -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, productCode: str, productDimensions: List["Dimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, productCode: str, productDimensions: List["Dimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, productCode: str, productDimensions: List["Dimension"]) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(productCode=productCode, productDimensions=productDimensions)
    return invoke_operation(api, OP_Update, params=params, data=data)

__all__ = ["Get", "Update"]
