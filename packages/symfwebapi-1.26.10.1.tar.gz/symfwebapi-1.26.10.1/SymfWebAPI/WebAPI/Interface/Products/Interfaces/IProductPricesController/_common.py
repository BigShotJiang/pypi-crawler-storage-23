from __future__ import annotations

from typing import Any

_REQUEST_Update = ('PUT', '/api/ProductPrices/Update')
def _prepare_Update(*, productCode, prices) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["productCode"] = productCode
    data = prices.model_dump_json(exclude_unset=True) if prices is not None else None
    return params or None, data

_REQUEST_Recalculate = ('PATCH', '/api/ProductPrices/Recalculate')
def _prepare_Recalculate(*, productCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["productCode"] = productCode
    data = None
    return params or None, data

_REQUEST_GetSalePricesByProduct = ('GET', '/api/ProductPrices/SalePrices')
def _prepare_GetSalePricesByProduct(*, productCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["productCode"] = productCode
    data = None
    return params or None, data

_REQUEST_GetSalePricesByProductKind = ('GET', '/api/ProductPrices/SalePrices')
def _prepare_GetSalePricesByProductKind(*, productKindId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["productKindId"] = productKindId
    data = None
    return params or None, data

_REQUEST_GetQuantitativeDiscountsByProduct = ('GET', '/api/ProductPrices/QuantitativeDiscounts')
def _prepare_GetQuantitativeDiscountsByProduct(*, productCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["productCode"] = productCode
    data = None
    return params or None, data

_REQUEST_GetQuantitativeDiscountsByProductKind = ('GET', '/api/ProductPrices/QuantitativeDiscounts')
def _prepare_GetQuantitativeDiscountsByProductKind(*, productKindId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["productKindId"] = productKindId
    data = None
    return params or None, data

_REQUEST_GetIndividualDiscountsByContractor = ('GET', '/api/ProductPrices/IndividualDiscounts')
def _prepare_GetIndividualDiscountsByContractor(*, contractorCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = None
    return params or None, data

_REQUEST_GetIndividualDiscountsByContractorKind = ('GET', '/api/ProductPrices/IndividualDiscounts')
def _prepare_GetIndividualDiscountsByContractorKind(*, contractorKindId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorKindId"] = contractorKindId
    data = None
    return params or None, data

_REQUEST_GetPriceFactors = ('GET', '/api/ProductPrices/PriceFactors')
def _prepare_GetPriceFactors(*, criteria) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteria.model_dump_json(exclude_unset=True) if criteria is not None else None
    return params or None, data

_REQUEST_CalculatePrices = ('PATCH', '/api/ProductPrices/CalculatePrices')
def _prepare_CalculatePrices(*, criteria) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteria.model_dump_json(exclude_unset=True) if criteria is not None else None
    return params or None, data

_REQUEST_OrderPrices = ('PATCH', '/api/ProductPrices/OrderPrices')
def _prepare_OrderPrices(*, criteria) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteria.model_dump_json(exclude_unset=True) if criteria is not None else None
    return params or None, data
