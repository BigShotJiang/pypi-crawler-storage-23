from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/ProductPhotos')
def _prepare_Get(*, photoId, quality) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["photoId"] = photoId
    params["quality"] = quality.value
    data = None
    return params or None, data
