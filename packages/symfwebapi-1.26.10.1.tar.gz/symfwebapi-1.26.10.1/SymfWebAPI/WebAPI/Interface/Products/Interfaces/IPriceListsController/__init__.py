from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import IncrementalSyncListElement
from SymfWebAPI.WebAPI.Interface.Products.ViewModels.PriceLists import PriceList
from ._common import (
    _prepare_Get,
    _prepare_IncrementalSync,
)
from ._ops import (
    OP_Get,
    OP_IncrementalSync,
)

@overload
def Get(api: SyncInvokerProtocol, code: str) -> ResponseEnvelope[PriceList]: ...
@overload
def Get(api: SyncRequestProtocol, code: str) -> ResponseEnvelope[PriceList]: ...
@overload
def Get(api: AsyncInvokerProtocol, code: str) -> Awaitable[ResponseEnvelope[PriceList]]: ...
@overload
def Get(api: AsyncRequestProtocol, code: str) -> Awaitable[ResponseEnvelope[PriceList]]: ...
def Get(api: object, code: str) -> ResponseEnvelope[PriceList] | Awaitable[ResponseEnvelope[PriceList]]:
    params, data = _prepare_Get(code=code)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def IncrementalSync(api: SyncInvokerProtocol) -> ResponseEnvelope[List[IncrementalSyncListElement]]: ...
@overload
def IncrementalSync(api: SyncRequestProtocol) -> ResponseEnvelope[List[IncrementalSyncListElement]]: ...
@overload
def IncrementalSync(api: AsyncInvokerProtocol) -> Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]: ...
@overload
def IncrementalSync(api: AsyncRequestProtocol) -> Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]: ...
def IncrementalSync(api: object) -> ResponseEnvelope[List[IncrementalSyncListElement]] | Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]:
    params, data = _prepare_IncrementalSync()
    return invoke_operation(api, OP_IncrementalSync, params=params, data=data)

__all__ = ["Get", "IncrementalSync"]
