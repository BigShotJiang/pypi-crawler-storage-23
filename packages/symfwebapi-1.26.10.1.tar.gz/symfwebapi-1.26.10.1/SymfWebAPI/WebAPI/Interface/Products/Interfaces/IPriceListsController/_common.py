from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/PriceLists')
def _prepare_Get(*, code) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["code"] = code
    data = None
    return params or None, data

_REQUEST_IncrementalSync = ('GET', '/api/PriceLists/IncrementalSync')
def _prepare_IncrementalSync() -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = None
    return params or None, data
