from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductPhoto
from SymfWebAPI.WebAPI.Interface.Enums import enumPhotoQuality
from ._common import (
    _prepare_Get,
)
from ._ops import (
    OP_Get,
)

@overload
def Get(api: SyncInvokerProtocol, photoId: int, quality: "enumPhotoQuality") -> ResponseEnvelope[ProductPhoto]: ...
@overload
def Get(api: SyncRequestProtocol, photoId: int, quality: "enumPhotoQuality") -> ResponseEnvelope[ProductPhoto]: ...
@overload
def Get(api: AsyncInvokerProtocol, photoId: int, quality: "enumPhotoQuality") -> Awaitable[ResponseEnvelope[ProductPhoto]]: ...
@overload
def Get(api: AsyncRequestProtocol, photoId: int, quality: "enumPhotoQuality") -> Awaitable[ResponseEnvelope[ProductPhoto]]: ...
def Get(api: object, photoId: int, quality: "enumPhotoQuality") -> ResponseEnvelope[ProductPhoto] | Awaitable[ResponseEnvelope[ProductPhoto]]:
    params, data = _prepare_Get(photoId=photoId, quality=quality)
    return invoke_operation(api, OP_Get, params=params, data=data)

__all__ = ["Get"]
