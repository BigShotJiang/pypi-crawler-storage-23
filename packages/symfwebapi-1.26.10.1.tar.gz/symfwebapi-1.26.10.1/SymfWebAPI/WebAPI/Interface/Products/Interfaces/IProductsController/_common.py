from __future__ import annotations

from typing import Any

import json

_REQUEST_Get = ('GET', '/api/Products')
def _prepare_Get(*, salePrices) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["salePrices"] = salePrices
    data = None
    return params or None, data

_REQUEST_Filter = ('PATCH', '/api/Products/Filter')
def _prepare_Filter(*, salePrices, criteria) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["salePrices"] = salePrices
    data = criteria.model_dump_json(exclude_unset=True) if criteria is not None else None
    return params or None, data

_REQUEST_FilterWithSalePrices = ('PATCH', '/api/Products/Filter/WithSalePrices')
def _prepare_FilterWithSalePrices(*, criteria) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteria.model_dump_json(exclude_unset=True) if criteria is not None else None
    return params or None, data

_REQUEST_FilterWithDimensions = ('PATCH', '/api/Products/Filter/WithDimensions')
def _prepare_FilterWithDimensions(*, criteria) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteria.model_dump_json(exclude_unset=True) if criteria is not None else None
    return params or None, data

_REQUEST_AddNew = ('POST', '/api/Products/Create')
def _prepare_AddNew(*, product) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = product.model_dump_json(exclude_unset=True) if product is not None else None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/Products/Update')
def _prepare_Update(*, product) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = product.model_dump_json(exclude_unset=True) if product is not None else None
    return params or None, data

_REQUEST_IncrementalSync = ('GET', '/api/Products/IncrementalSync')
def _prepare_IncrementalSync() -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = None
    return params or None, data

_REQUEST_GetBarcodes = ('GET', '/api/Products/Barcodes')
def _prepare_GetBarcodes(*, productCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = json.dumps(productCode) if productCode is not None else None
    return params or None, data

_REQUEST_UpdateBarcodes = ('GET', '/api/Products/UpdateBarcodes')
def _prepare_UpdateBarcodes(*, productCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["productCode"] = productCode
    data = None
    return params or None, data

_REQUEST_FilterSql = ('PATCH', '/api/Products/FilterSql')
def _prepare_FilterSql(*, criteriaFilter) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteriaFilter.model_dump_json(exclude_unset=True) if criteriaFilter is not None else None
    return params or None, data

_REQUEST_GetPagedDocument = ('GET', '/api/Products/Page')
def _prepare_GetPagedDocument(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data

_REQUEST_GetPageWithSalePrices = ('GET', '/api/Products/Page/WithSalePrices')
def _prepare_GetPageWithSalePrices(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data

_REQUEST_GetPageWithDimensions = ('GET', '/api/Products/Page/WithDimensions')
def _prepare_GetPageWithDimensions(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data

_REQUEST_FilterSqlWthSalePrices = ('PATCH', '/api/Products/FilterSql/WithSalePrices')
def _prepare_FilterSqlWthSalePrices(*, criteriaFilter) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteriaFilter.model_dump_json(exclude_unset=True) if criteriaFilter is not None else None
    return params or None, data

_REQUEST_FilterSqlWthDimensions = ('PATCH', '/api/Products/FilterSql/WithDimensions')
def _prepare_FilterSqlWthDimensions(*, criteriaFilter) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = criteriaFilter.model_dump_json(exclude_unset=True) if criteriaFilter is not None else None
    return params or None, data

_REQUEST_GetLogisticFields = ('GET', '/api/Products/LogisticFields')
def _prepare_GetLogisticFields(*, productCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = json.dumps(productCode) if productCode is not None else None
    return params or None, data
