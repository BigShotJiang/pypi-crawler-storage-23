from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import IncrementalSyncListElement
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import Product
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductBarcodes
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductCriteriaFilter
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductFilterCriteria
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductListElement
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductListElementWithDimensions
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductListElementWithSalePrices
from SymfWebAPI.WebAPI.Interface.Products.ViewModels import ProductLogisticField
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType
from ._common import (
    _prepare_Get,
    _prepare_Filter,
    _prepare_FilterWithSalePrices,
    _prepare_FilterWithDimensions,
    _prepare_AddNew,
    _prepare_Update,
    _prepare_IncrementalSync,
    _prepare_GetBarcodes,
    _prepare_UpdateBarcodes,
    _prepare_FilterSql,
    _prepare_GetPagedDocument,
    _prepare_GetPageWithSalePrices,
    _prepare_GetPageWithDimensions,
    _prepare_FilterSqlWthSalePrices,
    _prepare_FilterSqlWthDimensions,
    _prepare_GetLogisticFields,
)
from ._ops import (
    OP_Get,
    OP_Filter,
    OP_FilterWithSalePrices,
    OP_FilterWithDimensions,
    OP_AddNew,
    OP_Update,
    OP_IncrementalSync,
    OP_GetBarcodes,
    OP_UpdateBarcodes,
    OP_FilterSql,
    OP_GetPagedDocument,
    OP_GetPageWithSalePrices,
    OP_GetPageWithDimensions,
    OP_FilterSqlWthSalePrices,
    OP_FilterSqlWthDimensions,
    OP_GetLogisticFields,
)

@overload
def Get(api: SyncInvokerProtocol, salePrices: bool) -> ResponseEnvelope[List[ProductListElement]]: ...
@overload
def Get(api: SyncRequestProtocol, salePrices: bool) -> ResponseEnvelope[List[ProductListElement]]: ...
@overload
def Get(api: AsyncInvokerProtocol, salePrices: bool) -> Awaitable[ResponseEnvelope[List[ProductListElement]]]: ...
@overload
def Get(api: AsyncRequestProtocol, salePrices: bool) -> Awaitable[ResponseEnvelope[List[ProductListElement]]]: ...
def Get(api: object, salePrices: bool) -> ResponseEnvelope[List[ProductListElement]] | Awaitable[ResponseEnvelope[List[ProductListElement]]]:
    params, data = _prepare_Get(salePrices=salePrices)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def Filter(api: SyncInvokerProtocol, salePrices: bool, criteria: "ProductFilterCriteria") -> ResponseEnvelope[List[ProductListElement]]: ...
@overload
def Filter(api: SyncRequestProtocol, salePrices: bool, criteria: "ProductFilterCriteria") -> ResponseEnvelope[List[ProductListElement]]: ...
@overload
def Filter(api: AsyncInvokerProtocol, salePrices: bool, criteria: "ProductFilterCriteria") -> Awaitable[ResponseEnvelope[List[ProductListElement]]]: ...
@overload
def Filter(api: AsyncRequestProtocol, salePrices: bool, criteria: "ProductFilterCriteria") -> Awaitable[ResponseEnvelope[List[ProductListElement]]]: ...
def Filter(api: object, salePrices: bool, criteria: "ProductFilterCriteria") -> ResponseEnvelope[List[ProductListElement]] | Awaitable[ResponseEnvelope[List[ProductListElement]]]:
    params, data = _prepare_Filter(salePrices=salePrices, criteria=criteria)
    return invoke_operation(api, OP_Filter, params=params, data=data)

@overload
def FilterWithSalePrices(api: SyncInvokerProtocol, criteria: "ProductFilterCriteria") -> ResponseEnvelope[List[ProductListElementWithSalePrices]]: ...
@overload
def FilterWithSalePrices(api: SyncRequestProtocol, criteria: "ProductFilterCriteria") -> ResponseEnvelope[List[ProductListElementWithSalePrices]]: ...
@overload
def FilterWithSalePrices(api: AsyncInvokerProtocol, criteria: "ProductFilterCriteria") -> Awaitable[ResponseEnvelope[List[ProductListElementWithSalePrices]]]: ...
@overload
def FilterWithSalePrices(api: AsyncRequestProtocol, criteria: "ProductFilterCriteria") -> Awaitable[ResponseEnvelope[List[ProductListElementWithSalePrices]]]: ...
def FilterWithSalePrices(api: object, criteria: "ProductFilterCriteria") -> ResponseEnvelope[List[ProductListElementWithSalePrices]] | Awaitable[ResponseEnvelope[List[ProductListElementWithSalePrices]]]:
    params, data = _prepare_FilterWithSalePrices(criteria=criteria)
    return invoke_operation(api, OP_FilterWithSalePrices, params=params, data=data)

@overload
def FilterWithDimensions(api: SyncInvokerProtocol, criteria: "ProductFilterCriteria") -> ResponseEnvelope[List[ProductListElementWithDimensions]]: ...
@overload
def FilterWithDimensions(api: SyncRequestProtocol, criteria: "ProductFilterCriteria") -> ResponseEnvelope[List[ProductListElementWithDimensions]]: ...
@overload
def FilterWithDimensions(api: AsyncInvokerProtocol, criteria: "ProductFilterCriteria") -> Awaitable[ResponseEnvelope[List[ProductListElementWithDimensions]]]: ...
@overload
def FilterWithDimensions(api: AsyncRequestProtocol, criteria: "ProductFilterCriteria") -> Awaitable[ResponseEnvelope[List[ProductListElementWithDimensions]]]: ...
def FilterWithDimensions(api: object, criteria: "ProductFilterCriteria") -> ResponseEnvelope[List[ProductListElementWithDimensions]] | Awaitable[ResponseEnvelope[List[ProductListElementWithDimensions]]]:
    params, data = _prepare_FilterWithDimensions(criteria=criteria)
    return invoke_operation(api, OP_FilterWithDimensions, params=params, data=data)

@overload
def AddNew(api: SyncInvokerProtocol, product: "Product") -> ResponseEnvelope[Product]: ...
@overload
def AddNew(api: SyncRequestProtocol, product: "Product") -> ResponseEnvelope[Product]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, product: "Product") -> Awaitable[ResponseEnvelope[Product]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, product: "Product") -> Awaitable[ResponseEnvelope[Product]]: ...
def AddNew(api: object, product: "Product") -> ResponseEnvelope[Product] | Awaitable[ResponseEnvelope[Product]]:
    params, data = _prepare_AddNew(product=product)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Update(api: SyncInvokerProtocol, product: "Product") -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, product: "Product") -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, product: "Product") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, product: "Product") -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, product: "Product") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(product=product)
    return invoke_operation(api, OP_Update, params=params, data=data)

@overload
def IncrementalSync(api: SyncInvokerProtocol) -> ResponseEnvelope[List[IncrementalSyncListElement]]: ...
@overload
def IncrementalSync(api: SyncRequestProtocol) -> ResponseEnvelope[List[IncrementalSyncListElement]]: ...
@overload
def IncrementalSync(api: AsyncInvokerProtocol) -> Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]: ...
@overload
def IncrementalSync(api: AsyncRequestProtocol) -> Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]: ...
def IncrementalSync(api: object) -> ResponseEnvelope[List[IncrementalSyncListElement]] | Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]:
    params, data = _prepare_IncrementalSync()
    return invoke_operation(api, OP_IncrementalSync, params=params, data=data)

@overload
def GetBarcodes(api: SyncInvokerProtocol, productCode: str) -> ResponseEnvelope[ProductBarcodes]: ...
@overload
def GetBarcodes(api: SyncRequestProtocol, productCode: str) -> ResponseEnvelope[ProductBarcodes]: ...
@overload
def GetBarcodes(api: AsyncInvokerProtocol, productCode: str) -> Awaitable[ResponseEnvelope[ProductBarcodes]]: ...
@overload
def GetBarcodes(api: AsyncRequestProtocol, productCode: str) -> Awaitable[ResponseEnvelope[ProductBarcodes]]: ...
def GetBarcodes(api: object, productCode: str) -> ResponseEnvelope[ProductBarcodes] | Awaitable[ResponseEnvelope[ProductBarcodes]]:
    params, data = _prepare_GetBarcodes(productCode=productCode)
    return invoke_operation(api, OP_GetBarcodes, params=params, data=data)

@overload
def UpdateBarcodes(api: SyncInvokerProtocol, productCode: str) -> ResponseEnvelope[None]: ...
@overload
def UpdateBarcodes(api: SyncRequestProtocol, productCode: str) -> ResponseEnvelope[None]: ...
@overload
def UpdateBarcodes(api: AsyncInvokerProtocol, productCode: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def UpdateBarcodes(api: AsyncRequestProtocol, productCode: str) -> Awaitable[ResponseEnvelope[None]]: ...
def UpdateBarcodes(api: object, productCode: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_UpdateBarcodes(productCode=productCode)
    return invoke_operation(api, OP_UpdateBarcodes, params=params, data=data)

@overload
def FilterSql(api: SyncInvokerProtocol, criteriaFilter: "ProductCriteriaFilter") -> ResponseEnvelope[List[ProductListElement]]: ...
@overload
def FilterSql(api: SyncRequestProtocol, criteriaFilter: "ProductCriteriaFilter") -> ResponseEnvelope[List[ProductListElement]]: ...
@overload
def FilterSql(api: AsyncInvokerProtocol, criteriaFilter: "ProductCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ProductListElement]]]: ...
@overload
def FilterSql(api: AsyncRequestProtocol, criteriaFilter: "ProductCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ProductListElement]]]: ...
def FilterSql(api: object, criteriaFilter: "ProductCriteriaFilter") -> ResponseEnvelope[List[ProductListElement]] | Awaitable[ResponseEnvelope[List[ProductListElement]]]:
    params, data = _prepare_FilterSql(criteriaFilter=criteriaFilter)
    return invoke_operation(api, OP_FilterSql, params=params, data=data)

@overload
def GetPagedDocument(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocument(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocument(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocument(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocument, params=params, data=data)

@overload
def GetPageWithSalePrices(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPageWithSalePrices(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPageWithSalePrices(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPageWithSalePrices(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPageWithSalePrices(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPageWithSalePrices(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPageWithSalePrices, params=params, data=data)

@overload
def GetPageWithDimensions(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPageWithDimensions(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPageWithDimensions(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPageWithDimensions(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPageWithDimensions(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPageWithDimensions(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPageWithDimensions, params=params, data=data)

@overload
def FilterSqlWthSalePrices(api: SyncInvokerProtocol, criteriaFilter: "ProductCriteriaFilter") -> ResponseEnvelope[List[ProductListElementWithSalePrices]]: ...
@overload
def FilterSqlWthSalePrices(api: SyncRequestProtocol, criteriaFilter: "ProductCriteriaFilter") -> ResponseEnvelope[List[ProductListElementWithSalePrices]]: ...
@overload
def FilterSqlWthSalePrices(api: AsyncInvokerProtocol, criteriaFilter: "ProductCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ProductListElementWithSalePrices]]]: ...
@overload
def FilterSqlWthSalePrices(api: AsyncRequestProtocol, criteriaFilter: "ProductCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ProductListElementWithSalePrices]]]: ...
def FilterSqlWthSalePrices(api: object, criteriaFilter: "ProductCriteriaFilter") -> ResponseEnvelope[List[ProductListElementWithSalePrices]] | Awaitable[ResponseEnvelope[List[ProductListElementWithSalePrices]]]:
    params, data = _prepare_FilterSqlWthSalePrices(criteriaFilter=criteriaFilter)
    return invoke_operation(api, OP_FilterSqlWthSalePrices, params=params, data=data)

@overload
def FilterSqlWthDimensions(api: SyncInvokerProtocol, criteriaFilter: "ProductCriteriaFilter") -> ResponseEnvelope[List[ProductListElementWithDimensions]]: ...
@overload
def FilterSqlWthDimensions(api: SyncRequestProtocol, criteriaFilter: "ProductCriteriaFilter") -> ResponseEnvelope[List[ProductListElementWithDimensions]]: ...
@overload
def FilterSqlWthDimensions(api: AsyncInvokerProtocol, criteriaFilter: "ProductCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ProductListElementWithDimensions]]]: ...
@overload
def FilterSqlWthDimensions(api: AsyncRequestProtocol, criteriaFilter: "ProductCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ProductListElementWithDimensions]]]: ...
def FilterSqlWthDimensions(api: object, criteriaFilter: "ProductCriteriaFilter") -> ResponseEnvelope[List[ProductListElementWithDimensions]] | Awaitable[ResponseEnvelope[List[ProductListElementWithDimensions]]]:
    params, data = _prepare_FilterSqlWthDimensions(criteriaFilter=criteriaFilter)
    return invoke_operation(api, OP_FilterSqlWthDimensions, params=params, data=data)

@overload
def GetLogisticFields(api: SyncInvokerProtocol, productCode: str) -> ResponseEnvelope[List[ProductLogisticField]]: ...
@overload
def GetLogisticFields(api: SyncRequestProtocol, productCode: str) -> ResponseEnvelope[List[ProductLogisticField]]: ...
@overload
def GetLogisticFields(api: AsyncInvokerProtocol, productCode: str) -> Awaitable[ResponseEnvelope[List[ProductLogisticField]]]: ...
@overload
def GetLogisticFields(api: AsyncRequestProtocol, productCode: str) -> Awaitable[ResponseEnvelope[List[ProductLogisticField]]]: ...
def GetLogisticFields(api: object, productCode: str) -> ResponseEnvelope[List[ProductLogisticField]] | Awaitable[ResponseEnvelope[List[ProductLogisticField]]]:
    params, data = _prepare_GetLogisticFields(productCode=productCode)
    return invoke_operation(api, OP_GetLogisticFields, params=params, data=data)

__all__ = ["Get", "Filter", "FilterWithSalePrices", "FilterWithDimensions", "AddNew", "Update", "IncrementalSync", "GetBarcodes", "UpdateBarcodes", "FilterSql", "GetPagedDocument", "GetPageWithSalePrices", "GetPageWithDimensions", "FilterSqlWthSalePrices", "FilterSqlWthDimensions", "GetLogisticFields"]
