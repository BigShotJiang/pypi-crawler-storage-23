from __future__ import annotations

from typing import Any, Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from ._common import (
    _prepare_AddSendToKsefEventAsync,
    _prepare_ChangeKsefStatusAsync,
)
from ._ops import (
    OP_AddSendToKsefEventAsync,
    OP_ChangeKsefStatusAsync,
)

@overload
def AddSendToKsefEventAsync(api: SyncInvokerProtocol, cancellationToken: int, docId: Any) -> ResponseEnvelope[None]: ...
@overload
def AddSendToKsefEventAsync(api: SyncRequestProtocol, cancellationToken: int, docId: Any) -> ResponseEnvelope[None]: ...
@overload
def AddSendToKsefEventAsync(api: AsyncInvokerProtocol, cancellationToken: int, docId: Any) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def AddSendToKsefEventAsync(api: AsyncRequestProtocol, cancellationToken: int, docId: Any) -> Awaitable[ResponseEnvelope[None]]: ...
def AddSendToKsefEventAsync(api: object, cancellationToken: int, docId: Any) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_AddSendToKsefEventAsync(cancellationToken=cancellationToken, docId=docId)
    return invoke_operation(api, OP_AddSendToKsefEventAsync, params=params, data=data)

@overload
def ChangeKsefStatusAsync(api: SyncInvokerProtocol, id: int, ksefStatus: int, cancellationToken: Any) -> ResponseEnvelope[None]: ...
@overload
def ChangeKsefStatusAsync(api: SyncRequestProtocol, id: int, ksefStatus: int, cancellationToken: Any) -> ResponseEnvelope[None]: ...
@overload
def ChangeKsefStatusAsync(api: AsyncInvokerProtocol, id: int, ksefStatus: int, cancellationToken: Any) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def ChangeKsefStatusAsync(api: AsyncRequestProtocol, id: int, ksefStatus: int, cancellationToken: Any) -> Awaitable[ResponseEnvelope[None]]: ...
def ChangeKsefStatusAsync(api: object, id: int, ksefStatus: int, cancellationToken: Any) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_ChangeKsefStatusAsync(id=id, ksefStatus=ksefStatus, cancellationToken=cancellationToken)
    return invoke_operation(api, OP_ChangeKsefStatusAsync, params=params, data=data)

__all__ = ["AddSendToKsefEventAsync", "ChangeKsefStatusAsync"]
