from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import DocumentType
from ._common import (
    _prepare_Get,
    _prepare_GetByCharacter,
)
from ._ops import (
    OP_Get,
    OP_GetByCharacter,
)

@overload
def Get(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[DocumentType]: ...
@overload
def Get(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[DocumentType]: ...
@overload
def Get(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[DocumentType]]: ...
@overload
def Get(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[DocumentType]]: ...
def Get(api: object, id: int) -> ResponseEnvelope[DocumentType] | Awaitable[ResponseEnvelope[DocumentType]]:
    params, data = _prepare_Get(id=id)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetByCharacter(api: SyncInvokerProtocol, documentCharacter: int) -> ResponseEnvelope[List[DocumentType]]: ...
@overload
def GetByCharacter(api: SyncRequestProtocol, documentCharacter: int) -> ResponseEnvelope[List[DocumentType]]: ...
@overload
def GetByCharacter(api: AsyncInvokerProtocol, documentCharacter: int) -> Awaitable[ResponseEnvelope[List[DocumentType]]]: ...
@overload
def GetByCharacter(api: AsyncRequestProtocol, documentCharacter: int) -> Awaitable[ResponseEnvelope[List[DocumentType]]]: ...
def GetByCharacter(api: object, documentCharacter: int) -> ResponseEnvelope[List[DocumentType]] | Awaitable[ResponseEnvelope[List[DocumentType]]]:
    params, data = _prepare_GetByCharacter(documentCharacter=documentCharacter)
    return invoke_operation(api, OP_GetByCharacter, params=params, data=data)

__all__ = ["Get", "GetByCharacter"]
