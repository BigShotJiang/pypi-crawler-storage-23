from __future__ import annotations

from typing import Any
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope

def _parse_AddSendToKsefEventAsync(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_AddSendToKsefEventAsync = OperationSpec(method='POST', path='/api/Ksef/AddSendToKsefEvent', parser=_parse_AddSendToKsefEventAsync)

def _parse_ChangeKsefStatusAsync(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_ChangeKsefStatusAsync = OperationSpec(method='POST', path='/api/Ksef/ChangeKsefStatusAsync', parser=_parse_ChangeKsefStatusAsync)
