from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/PaymentForms')
def _prepare_Get(*, registryId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["registryId"] = registryId
    data = None
    return params or None, data
