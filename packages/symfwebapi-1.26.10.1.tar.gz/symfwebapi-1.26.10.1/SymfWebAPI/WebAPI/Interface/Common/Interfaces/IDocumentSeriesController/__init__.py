from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from ._common import (
    _prepare_Get,
)
from ._ops import (
    OP_Get,
)

@overload
def Get(api: SyncInvokerProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def Get(api: SyncRequestProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def Get(api: AsyncInvokerProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
@overload
def Get(api: AsyncRequestProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
def Get(api: object, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]] | Awaitable[ResponseEnvelope[List[DocumentSeries]]]:
    params, data = _prepare_Get(documentTypeId=documentTypeId)
    return invoke_operation(api, OP_Get, params=params, data=data)

__all__ = ["Get"]
