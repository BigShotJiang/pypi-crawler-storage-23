from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PaymentForm

_ADAPTER_Get = TypeAdapter(List[PaymentForm])

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PaymentForm]]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/PaymentForms', parser=_parse_Get)
