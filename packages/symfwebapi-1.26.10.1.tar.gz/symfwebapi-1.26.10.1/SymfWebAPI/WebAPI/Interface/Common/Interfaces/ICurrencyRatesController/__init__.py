from __future__ import annotations

from typing import Awaitable, List, Optional, overload
from datetime import datetime
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import CurrencyRate
from ._common import (
    _prepare_Get,
    _prepare_GetList,
    _prepare_GetListByCurrency,
)
from ._ops import (
    OP_Get,
    OP_GetList,
    OP_GetListByCurrency,
)

@overload
def Get(api: SyncInvokerProtocol, currencyId: int, date: Optional[datetime] = None) -> ResponseEnvelope[List[CurrencyRate]]: ...
@overload
def Get(api: SyncRequestProtocol, currencyId: int, date: Optional[datetime] = None) -> ResponseEnvelope[List[CurrencyRate]]: ...
@overload
def Get(api: AsyncInvokerProtocol, currencyId: int, date: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CurrencyRate]]]: ...
@overload
def Get(api: AsyncRequestProtocol, currencyId: int, date: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CurrencyRate]]]: ...
def Get(api: object, currencyId: int, date: Optional[datetime] = None) -> ResponseEnvelope[List[CurrencyRate]] | Awaitable[ResponseEnvelope[List[CurrencyRate]]]:
    params, data = _prepare_Get(currencyId=currencyId, date=date)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetList(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CurrencyRate]]: ...
@overload
def GetList(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CurrencyRate]]: ...
@overload
def GetList(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CurrencyRate]]]: ...
@overload
def GetList(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CurrencyRate]]]: ...
def GetList(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CurrencyRate]] | Awaitable[ResponseEnvelope[List[CurrencyRate]]]:
    params, data = _prepare_GetList(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetList, params=params, data=data)

@overload
def GetListByCurrency(api: SyncInvokerProtocol, currencyId: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CurrencyRate]]: ...
@overload
def GetListByCurrency(api: SyncRequestProtocol, currencyId: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CurrencyRate]]: ...
@overload
def GetListByCurrency(api: AsyncInvokerProtocol, currencyId: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CurrencyRate]]]: ...
@overload
def GetListByCurrency(api: AsyncRequestProtocol, currencyId: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CurrencyRate]]]: ...
def GetListByCurrency(api: object, currencyId: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CurrencyRate]] | Awaitable[ResponseEnvelope[List[CurrencyRate]]]:
    params, data = _prepare_GetListByCurrency(currencyId=currencyId, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByCurrency, params=params, data=data)

__all__ = ["Get", "GetList", "GetListByCurrency"]
