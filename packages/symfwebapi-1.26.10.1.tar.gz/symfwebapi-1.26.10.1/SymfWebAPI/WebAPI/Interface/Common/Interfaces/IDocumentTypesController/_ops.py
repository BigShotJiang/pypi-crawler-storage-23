from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import DocumentType

_ADAPTER_Get = TypeAdapter(DocumentType)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[DocumentType]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/DocumentTypes', parser=_parse_Get)

_ADAPTER_GetByCharacter = TypeAdapter(List[DocumentType])

def _parse_GetByCharacter(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentType]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByCharacter)
OP_GetByCharacter = OperationSpec(method='GET', path='/api/DocumentTypes', parser=_parse_GetByCharacter)
