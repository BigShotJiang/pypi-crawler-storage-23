from __future__ import annotations

from typing import List, Optional
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import CurrencyRate

_ADAPTER_Get = TypeAdapter(List[CurrencyRate])

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CurrencyRate]]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/CurrencyRates', parser=_parse_Get)

_ADAPTER_GetList = TypeAdapter(List[CurrencyRate])

def _parse_GetList(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CurrencyRate]]:
    return parse_with_adapter(envelope, _ADAPTER_GetList)
OP_GetList = OperationSpec(method='GET', path='/api/CurrencyRates/Filter', parser=_parse_GetList)

_ADAPTER_GetListByCurrency = TypeAdapter(List[CurrencyRate])

def _parse_GetListByCurrency(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CurrencyRate]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByCurrency)
OP_GetListByCurrency = OperationSpec(method='GET', path='/api/CurrencyRates/Filter', parser=_parse_GetListByCurrency)
