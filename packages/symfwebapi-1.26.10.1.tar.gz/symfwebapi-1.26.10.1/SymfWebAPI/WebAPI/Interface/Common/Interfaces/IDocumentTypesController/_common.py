from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/DocumentTypes')
def _prepare_Get(*, id) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    data = None
    return params or None, data

_REQUEST_GetByCharacter = ('GET', '/api/DocumentTypes')
def _prepare_GetByCharacter(*, documentCharacter) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentCharacter"] = documentCharacter
    data = None
    return params or None, data
