from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/CurrencyRates')
def _prepare_Get(*, currencyId, date = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["currencyId"] = currencyId
    if date is not None:
        params["date"] = date
    data = None
    return params or None, data

_REQUEST_GetList = ('GET', '/api/CurrencyRates/Filter')
def _prepare_GetList(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByCurrency = ('GET', '/api/CurrencyRates/Filter')
def _prepare_GetListByCurrency(*, currencyId, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["currencyId"] = currencyId
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data
