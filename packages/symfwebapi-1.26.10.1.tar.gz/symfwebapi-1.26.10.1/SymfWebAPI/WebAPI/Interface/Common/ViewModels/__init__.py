from __future__ import annotations

from pydantic import BaseModel

from typing import Any, List, Optional
from datetime import datetime
from decimal import Decimal
from SymfWebAPI.WebAPI.Interface.Enums import (
    enumIncrementalSyncModifyType,
    enumPaymentRegistryType,
    enumPrintParameterDocumentStatus,
    enumPrintParameterNotSettledDocuments,
    enumPrintParameterOperationDateFormat,
)
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension

class CurrencyRate(BaseModel):
    CurrencyId: int
    Date: datetime
    Rate: Decimal

class DocumentAddress(BaseModel):
    Name: str
    NIP: str
    City: str
    PostCode: str
    Street: str
    HouseNo: str
    ApartmentNo: str
    CountryId: Optional[int]

class DocumentSeries(BaseModel):
    Id: int
    Code: str

class FilterDimensionCriteria(BaseModel):
    Id: Optional[int]
    Code: str
    Value: str
    DictionaryValue: str

class FilterDocumentType(BaseModel):
    DocumentTypes: List[str]

class IncrementalSyncListElement_1(BaseModel):
    Id: int
    ModifyType: "enumIncrementalSyncModifyType"
    ModifiedAt: datetime
    Object: Any
IncrementalSyncListElement = IncrementalSyncListElement_1

class Kind(BaseModel):
    Id: Optional[int]
    Code: str
    Active: bool

class PDF(BaseModel):
    Hash_SHA1: str
    ContentFile_Base64: str
    CreateDate: datetime

class PDFDimensionSetting(BaseModel):
    Code: str
    PrintLabel: bool

class PDFSettings(BaseModel):
    PrintNote: bool
    PrintRemarks: bool
    PrintFooter: bool
    PrintExecutiveSubject: bool
    OperationDateFormat: "enumPrintParameterOperationDateFormat"
    DocumentStatus: "enumPrintParameterDocumentStatus"
    NotSettledDocuments: "enumPrintParameterNotSettledDocuments"
    DocumentStatusText: str
    IncludedDimensions: List["PDFDimensionSetting"]
    PrintLeftToPay: bool
    PrintReceiptNumber: bool
    PrintDiscountColumns: bool
    MainSubjectAddressDimensionCode: str
    MainSubjectNameDimensionCode: str
    ExecutiveSubjectAddressDimensionCode: str
    ExecutiveSubjectNameDimensionCode: str
    PositionDescriptionDimensionCode: str

class PaymentForm(BaseModel):
    Name: str
    Days: int
    Type: "enumPaymentRegistryType"
    Active: bool
    Id: Optional[int]
    Client: int

class PaymentFormBase(BaseModel):
    Id: Optional[int]
    Client: int

class PaymentRegistryBase(BaseModel):
    Id: Optional[int]
    Code: str
    AccountNumber: str

class PositionDimension(BaseModel):
    PositionId: int
    Dimensions: List["Dimension"]

class RelatedDocumentPosition(BaseModel):
    Id: int
    No: int
    Quantity: Decimal
    NetValuePLN: Decimal
    DocumentId: int
    DocumentNumber: str
    QuantityCorrected: Decimal
    NetValuePLNCorrected: Decimal

class VatRateBase(BaseModel):
    Id: Optional[int]
    Code: str
