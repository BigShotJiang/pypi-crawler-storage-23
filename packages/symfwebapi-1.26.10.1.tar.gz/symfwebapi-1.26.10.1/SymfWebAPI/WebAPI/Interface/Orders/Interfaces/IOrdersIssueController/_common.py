from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/OrdersIssue/New')
def _prepare_AddNew(*, issue, order) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["issue"] = issue
    data = order.model_dump_json(exclude_unset=True) if order is not None else None
    return params or None, data

_REQUEST_Edit = ('PUT', '/api/OrdersIssue/Edit')
def _prepare_Edit(*, order) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = order.model_dump_json(exclude_unset=True) if order is not None else None
    return params or None, data

_REQUEST_Issue = ('PUT', '/api/OrdersIssue/InBuffer')
def _prepare_Issue(*, number) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    data = None
    return params or None, data

_REQUEST_IssueWZ = ('PUT', '/api/OrdersIssue/WZ')
def _prepare_IssueWZ(*, orderNumber, inBuffer = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    if inBuffer is not None:
        params["inBuffer"] = inBuffer
    data = None
    return params or None, data

_REQUEST_IssueFV = ('PUT', '/api/OrdersIssue/FV')
def _prepare_IssueFV(*, orderNumber) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    data = None
    return params or None, data

_REQUEST_Delete = ('DELETE', '/api/OrdersIssue/Delete')
def _prepare_Delete(*, number, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_ChangeDocumentNumber = ('PATCH', '/api/OrdersIssue/DocumentNumber')
def _prepare_ChangeDocumentNumber(*, id, number) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    params["number"] = number
    data = None
    return params or None, data
