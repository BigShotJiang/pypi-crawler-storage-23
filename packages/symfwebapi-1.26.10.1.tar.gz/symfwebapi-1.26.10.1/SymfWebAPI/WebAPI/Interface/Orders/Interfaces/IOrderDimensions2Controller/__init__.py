from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PositionDimension
from ._common import (
    _prepare_Get,
    _prepare_GetPositionsByOrderId,
    _prepare_GetPositionsByOrderNumber,
    _prepare_GetPosition,
)
from ._ops import (
    OP_Get,
    OP_GetPositionsByOrderId,
    OP_GetPositionsByOrderNumber,
    OP_GetPosition,
)

@overload
def Get(api: SyncInvokerProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def Get(api: SyncRequestProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def Get(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def Get(api: AsyncRequestProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def Get(api: object, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_Get(orderNumber=orderNumber, buffer=buffer)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetPositionsByOrderId(api: SyncInvokerProtocol, orderId: int) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByOrderId(api: SyncRequestProtocol, orderId: int) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByOrderId(api: AsyncInvokerProtocol, orderId: int) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
@overload
def GetPositionsByOrderId(api: AsyncRequestProtocol, orderId: int) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
def GetPositionsByOrderId(api: object, orderId: int) -> ResponseEnvelope[List[PositionDimension]] | Awaitable[ResponseEnvelope[List[PositionDimension]]]:
    params, data = _prepare_GetPositionsByOrderId(orderId=orderId)
    return invoke_operation(api, OP_GetPositionsByOrderId, params=params, data=data)

@overload
def GetPositionsByOrderNumber(api: SyncInvokerProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByOrderNumber(api: SyncRequestProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByOrderNumber(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
@overload
def GetPositionsByOrderNumber(api: AsyncRequestProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
def GetPositionsByOrderNumber(api: object, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[PositionDimension]] | Awaitable[ResponseEnvelope[List[PositionDimension]]]:
    params, data = _prepare_GetPositionsByOrderNumber(orderNumber=orderNumber, buffer=buffer)
    return invoke_operation(api, OP_GetPositionsByOrderNumber, params=params, data=data)

@overload
def GetPosition(api: SyncInvokerProtocol, positionId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetPosition(api: SyncRequestProtocol, positionId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetPosition(api: AsyncInvokerProtocol, positionId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def GetPosition(api: AsyncRequestProtocol, positionId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def GetPosition(api: object, positionId: int) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_GetPosition(positionId=positionId)
    return invoke_operation(api, OP_GetPosition, params=params, data=data)

__all__ = ["Get", "GetPositionsByOrderId", "GetPositionsByOrderNumber", "GetPosition"]
