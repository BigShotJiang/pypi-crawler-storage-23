from __future__ import annotations

from typing import Any

import json

_REQUEST_Get = ('GET', '/api/OrderDimensions')
def _prepare_Get(*, orderNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPositionsByOrderId = ('GET', '/api/OrderDimensions/Positions')
def _prepare_GetPositionsByOrderId(*, orderId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderId"] = orderId
    data = None
    return params or None, data

_REQUEST_GetPositionsByOrderNumber = ('GET', '/api/OrderDimensions/Positions')
def _prepare_GetPositionsByOrderNumber(*, orderNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPosition = ('GET', '/api/OrderDimensions/Positions')
def _prepare_GetPosition(*, positionId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["positionId"] = positionId
    data = None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/OrderDimensions/UpdateList')
def _prepare_Update(*, orderNumber, buffer, orderDimensions) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = json.dumps(orderDimensions) if orderDimensions is not None else None
    return params or None, data

_REQUEST_UpdatePosition = ('PUT', '/api/OrderDimensions/UpdateMultiPositionsList')
def _prepare_UpdatePosition(*, positionDimension) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = json.dumps(positionDimension) if positionDimension is not None else None
    return params or None, data

_REQUEST_GetAspects = ('GET', '/api/OwnOrderDimensions/Aspects')
def _prepare_GetAspects(*, orderNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_UpdateAspect = ('PUT', '/api/OwnOrderDimensions/Aspects')
def _prepare_UpdateAspect(*, aspectPosition) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = aspectPosition.model_dump_json(exclude_unset=True) if aspectPosition is not None else None
    return params or None, data
