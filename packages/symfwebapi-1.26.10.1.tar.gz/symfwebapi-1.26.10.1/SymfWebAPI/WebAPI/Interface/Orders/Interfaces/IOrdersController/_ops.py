from __future__ import annotations

from typing import List, Optional
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import FilterDocumentType
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import IncrementalSyncListElement
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import Order
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderFV
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderListElement
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderPositionRelation
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderStatus
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderWZ
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDFSettings
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

_ADAPTER_Get = TypeAdapter(Order)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Order]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/Orders', parser=_parse_Get)

_ADAPTER_GetList = TypeAdapter(List[OrderListElement])

def _parse_GetList(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OrderListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetList)
OP_GetList = OperationSpec(method='GET', path='/api/Orders/Filter', parser=_parse_GetList)

_ADAPTER_GetListByRecipient = TypeAdapter(List[OrderListElement])

def _parse_GetListByRecipient(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OrderListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByRecipient)
OP_GetListByRecipient = OperationSpec(method='GET', path='/api/Orders/Filter', parser=_parse_GetListByRecipient)

_ADAPTER_GetListByBuyer = TypeAdapter(List[OrderListElement])

def _parse_GetListByBuyer(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OrderListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByBuyer)
OP_GetListByBuyer = OperationSpec(method='GET', path='/api/Orders/Filter', parser=_parse_GetListByBuyer)

_ADAPTER_GetListByDimension = TypeAdapter(List[OrderListElement])

def _parse_GetListByDimension(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OrderListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByDimension)
OP_GetListByDimension = OperationSpec(method='GET', path='/api/Orders/Filter', parser=_parse_GetListByDimension)

_ADAPTER_GetWZ = TypeAdapter(List[OrderWZ])

def _parse_GetWZ(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OrderWZ]]:
    return parse_with_adapter(envelope, _ADAPTER_GetWZ)
OP_GetWZ = OperationSpec(method='GET', path='/api/Orders/WZ', parser=_parse_GetWZ)

_ADAPTER_GetFV = TypeAdapter(List[OrderFV])

def _parse_GetFV(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OrderFV]]:
    return parse_with_adapter(envelope, _ADAPTER_GetFV)
OP_GetFV = OperationSpec(method='GET', path='/api/Orders/FV', parser=_parse_GetFV)

_ADAPTER_GetPDF = TypeAdapter(PDF)

def _parse_GetPDF(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PDF]:
    return parse_with_adapter(envelope, _ADAPTER_GetPDF)
OP_GetPDF = OperationSpec(method='PATCH', path='/api/Orders/PDF', parser=_parse_GetPDF)

_ADAPTER_GetInvoicesPDF = TypeAdapter(List[PDF])

def _parse_GetInvoicesPDF(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PDF]]:
    return parse_with_adapter(envelope, _ADAPTER_GetInvoicesPDF)
OP_GetInvoicesPDF = OperationSpec(method='GET', path='/api/Orders/InvoicesPDF', parser=_parse_GetInvoicesPDF)

_ADAPTER_GetDocumentSeries = TypeAdapter(List[DocumentSeries])

def _parse_GetDocumentSeries(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentSeries]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentSeries)
OP_GetDocumentSeries = OperationSpec(method='GET', path='/api/Orders/DocumentSeries', parser=_parse_GetDocumentSeries)

_ADAPTER_GetStatus = TypeAdapter(OrderStatus)

def _parse_GetStatus(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[OrderStatus]:
    return parse_with_adapter(envelope, _ADAPTER_GetStatus)
OP_GetStatus = OperationSpec(method='GET', path='/api/Orders/Status', parser=_parse_GetStatus)

_ADAPTER_GetPositionRelations = TypeAdapter(OrderPositionRelation)

def _parse_GetPositionRelations(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[OrderPositionRelation]:
    return parse_with_adapter(envelope, _ADAPTER_GetPositionRelations)
OP_GetPositionRelations = OperationSpec(method='GET', path='/api/Orders/PositionRelations', parser=_parse_GetPositionRelations)

_ADAPTER_IncrementalSync = TypeAdapter(List[IncrementalSyncListElement])

def _parse_IncrementalSync(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[IncrementalSyncListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_IncrementalSync)
OP_IncrementalSync = OperationSpec(method='GET', path='/api/Orders/IncrementalSync', parser=_parse_IncrementalSync)

_ADAPTER_GetPagedDocument = TypeAdapter(Page)

def _parse_GetPagedDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocument)
OP_GetPagedDocument = OperationSpec(method='GET', path='/api/Orders/Page', parser=_parse_GetPagedDocument)

_ADAPTER_GetDocumentTypesWithRange = TypeAdapter(List[OrderListElement])

def _parse_GetDocumentTypesWithRange(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OrderListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentTypesWithRange)
OP_GetDocumentTypesWithRange = OperationSpec(method='GET', path='/api/Orders/Filter/ByDocumentTypes', parser=_parse_GetDocumentTypesWithRange)
