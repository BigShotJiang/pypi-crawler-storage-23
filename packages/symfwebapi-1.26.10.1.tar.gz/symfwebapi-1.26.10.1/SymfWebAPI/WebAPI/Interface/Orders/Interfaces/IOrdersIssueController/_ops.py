from __future__ import annotations

from typing import List, Optional
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import Order
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderEdit
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderFV
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderIssue
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderWZ

_ADAPTER_AddNew = TypeAdapter(Order)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Order]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/OrdersIssue/New', parser=_parse_AddNew)

_ADAPTER_Edit = TypeAdapter(Order)

def _parse_Edit(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Order]:
    return parse_with_adapter(envelope, _ADAPTER_Edit)
OP_Edit = OperationSpec(method='PUT', path='/api/OrdersIssue/Edit', parser=_parse_Edit)

_ADAPTER_Issue = TypeAdapter(Order)

def _parse_Issue(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Order]:
    return parse_with_adapter(envelope, _ADAPTER_Issue)
OP_Issue = OperationSpec(method='PUT', path='/api/OrdersIssue/InBuffer', parser=_parse_Issue)

_ADAPTER_IssueWZ = TypeAdapter(List[OrderWZ])

def _parse_IssueWZ(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OrderWZ]]:
    return parse_with_adapter(envelope, _ADAPTER_IssueWZ)
OP_IssueWZ = OperationSpec(method='PUT', path='/api/OrdersIssue/WZ', parser=_parse_IssueWZ)

_ADAPTER_IssueFV = TypeAdapter(List[OrderFV])

def _parse_IssueFV(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[OrderFV]]:
    return parse_with_adapter(envelope, _ADAPTER_IssueFV)
OP_IssueFV = OperationSpec(method='PUT', path='/api/OrdersIssue/FV', parser=_parse_IssueFV)

def _parse_Delete(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Delete = OperationSpec(method='DELETE', path='/api/OrdersIssue/Delete', parser=_parse_Delete)

def _parse_ChangeDocumentNumber(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_ChangeDocumentNumber = OperationSpec(method='PATCH', path='/api/OrdersIssue/DocumentNumber', parser=_parse_ChangeDocumentNumber)
