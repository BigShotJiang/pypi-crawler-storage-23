from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PositionDimension

_ADAPTER_Get = TypeAdapter(List[Dimension])

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Dimension]]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/v2/OrderDimensions', parser=_parse_Get)

_ADAPTER_GetPositionsByOrderId = TypeAdapter(List[PositionDimension])

def _parse_GetPositionsByOrderId(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PositionDimension]]:
    return parse_with_adapter(envelope, _ADAPTER_GetPositionsByOrderId)
OP_GetPositionsByOrderId = OperationSpec(method='GET', path='/api/v2/OrderDimensions/Positions', parser=_parse_GetPositionsByOrderId)

_ADAPTER_GetPositionsByOrderNumber = TypeAdapter(List[PositionDimension])

def _parse_GetPositionsByOrderNumber(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PositionDimension]]:
    return parse_with_adapter(envelope, _ADAPTER_GetPositionsByOrderNumber)
OP_GetPositionsByOrderNumber = OperationSpec(method='GET', path='/api/v2/OrderDimensions/Positions', parser=_parse_GetPositionsByOrderNumber)

_ADAPTER_GetPosition = TypeAdapter(List[Dimension])

def _parse_GetPosition(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Dimension]]:
    return parse_with_adapter(envelope, _ADAPTER_GetPosition)
OP_GetPosition = OperationSpec(method='GET', path='/api/v2/OrderDimensions/Positions', parser=_parse_GetPosition)
