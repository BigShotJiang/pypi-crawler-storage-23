from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels.Aspects import AspectDocument
from SymfWebAPI.WebAPI.Interface.Common.ViewModels.Aspects import AspectPositionEdit
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PositionDimension
from ._common import (
    _prepare_Get,
    _prepare_GetPositionsByOrderId,
    _prepare_GetPositionsByOrderNumber,
    _prepare_GetPosition,
    _prepare_Update,
    _prepare_UpdatePosition,
    _prepare_GetAspects,
    _prepare_UpdateAspect,
)
from ._ops import (
    OP_Get,
    OP_GetPositionsByOrderId,
    OP_GetPositionsByOrderNumber,
    OP_GetPosition,
    OP_Update,
    OP_UpdatePosition,
    OP_GetAspects,
    OP_UpdateAspect,
)

@overload
def Get(api: SyncInvokerProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def Get(api: SyncRequestProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def Get(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def Get(api: AsyncRequestProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def Get(api: object, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_Get(orderNumber=orderNumber, buffer=buffer)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetPositionsByOrderId(api: SyncInvokerProtocol, orderId: int) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByOrderId(api: SyncRequestProtocol, orderId: int) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByOrderId(api: AsyncInvokerProtocol, orderId: int) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
@overload
def GetPositionsByOrderId(api: AsyncRequestProtocol, orderId: int) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
def GetPositionsByOrderId(api: object, orderId: int) -> ResponseEnvelope[List[PositionDimension]] | Awaitable[ResponseEnvelope[List[PositionDimension]]]:
    params, data = _prepare_GetPositionsByOrderId(orderId=orderId)
    return invoke_operation(api, OP_GetPositionsByOrderId, params=params, data=data)

@overload
def GetPositionsByOrderNumber(api: SyncInvokerProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByOrderNumber(api: SyncRequestProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByOrderNumber(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
@overload
def GetPositionsByOrderNumber(api: AsyncRequestProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
def GetPositionsByOrderNumber(api: object, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[PositionDimension]] | Awaitable[ResponseEnvelope[List[PositionDimension]]]:
    params, data = _prepare_GetPositionsByOrderNumber(orderNumber=orderNumber, buffer=buffer)
    return invoke_operation(api, OP_GetPositionsByOrderNumber, params=params, data=data)

@overload
def GetPosition(api: SyncInvokerProtocol, positionId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetPosition(api: SyncRequestProtocol, positionId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetPosition(api: AsyncInvokerProtocol, positionId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def GetPosition(api: AsyncRequestProtocol, positionId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def GetPosition(api: object, positionId: int) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_GetPosition(positionId=positionId)
    return invoke_operation(api, OP_GetPosition, params=params, data=data)

@overload
def Update(api: SyncInvokerProtocol, orderNumber: str, buffer: List["Dimension"], orderDimensions: bool) -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, orderNumber: str, buffer: List["Dimension"], orderDimensions: bool) -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, orderNumber: str, buffer: List["Dimension"], orderDimensions: bool) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, orderNumber: str, buffer: List["Dimension"], orderDimensions: bool) -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, orderNumber: str, buffer: List["Dimension"], orderDimensions: bool) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(orderNumber=orderNumber, buffer=buffer, orderDimensions=orderDimensions)
    return invoke_operation(api, OP_Update, params=params, data=data)

@overload
def UpdatePosition(api: SyncInvokerProtocol, positionDimension: List["PositionDimension"]) -> ResponseEnvelope[None]: ...
@overload
def UpdatePosition(api: SyncRequestProtocol, positionDimension: List["PositionDimension"]) -> ResponseEnvelope[None]: ...
@overload
def UpdatePosition(api: AsyncInvokerProtocol, positionDimension: List["PositionDimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def UpdatePosition(api: AsyncRequestProtocol, positionDimension: List["PositionDimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
def UpdatePosition(api: object, positionDimension: List["PositionDimension"]) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_UpdatePosition(positionDimension=positionDimension)
    return invoke_operation(api, OP_UpdatePosition, params=params, data=data)

@overload
def GetAspects(api: SyncInvokerProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[AspectDocument]: ...
@overload
def GetAspects(api: SyncRequestProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[AspectDocument]: ...
@overload
def GetAspects(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[AspectDocument]]: ...
@overload
def GetAspects(api: AsyncRequestProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[AspectDocument]]: ...
def GetAspects(api: object, orderNumber: str, buffer: bool) -> ResponseEnvelope[AspectDocument] | Awaitable[ResponseEnvelope[AspectDocument]]:
    params, data = _prepare_GetAspects(orderNumber=orderNumber, buffer=buffer)
    return invoke_operation(api, OP_GetAspects, params=params, data=data)

@overload
def UpdateAspect(api: SyncInvokerProtocol, aspectPosition: "AspectPositionEdit") -> ResponseEnvelope[None]: ...
@overload
def UpdateAspect(api: SyncRequestProtocol, aspectPosition: "AspectPositionEdit") -> ResponseEnvelope[None]: ...
@overload
def UpdateAspect(api: AsyncInvokerProtocol, aspectPosition: "AspectPositionEdit") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def UpdateAspect(api: AsyncRequestProtocol, aspectPosition: "AspectPositionEdit") -> Awaitable[ResponseEnvelope[None]]: ...
def UpdateAspect(api: object, aspectPosition: "AspectPositionEdit") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_UpdateAspect(aspectPosition=aspectPosition)
    return invoke_operation(api, OP_UpdateAspect, params=params, data=data)

__all__ = ["Get", "GetPositionsByOrderId", "GetPositionsByOrderNumber", "GetPosition", "Update", "UpdatePosition", "GetAspects", "UpdateAspect"]
