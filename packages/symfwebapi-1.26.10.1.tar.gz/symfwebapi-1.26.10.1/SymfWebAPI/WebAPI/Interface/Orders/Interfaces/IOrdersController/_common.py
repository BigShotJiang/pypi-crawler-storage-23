from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/Orders')
def _prepare_Get(*, number, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetList = ('GET', '/api/Orders/Filter')
def _prepare_GetList(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByRecipient = ('GET', '/api/Orders/Filter')
def _prepare_GetListByRecipient(*, recipientCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["recipientCode"] = recipientCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByBuyer = ('GET', '/api/Orders/Filter')
def _prepare_GetListByBuyer(*, buyerCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["buyerCode"] = buyerCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByDimension = ('GET', '/api/Orders/Filter')
def _prepare_GetListByDimension(*, dimensionCode, dictionaryValue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dimensionCode"] = dimensionCode
    params["dictionaryValue"] = dictionaryValue
    data = None
    return params or None, data

_REQUEST_GetWZ = ('GET', '/api/Orders/WZ')
def _prepare_GetWZ(*, orderNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetFV = ('GET', '/api/Orders/FV')
def _prepare_GetFV(*, orderNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPDF = ('PATCH', '/api/Orders/PDF')
def _prepare_GetPDF(*, orderNumber, buffer, settings) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = settings.model_dump_json(exclude_unset=True) if settings is not None else None
    return params or None, data

_REQUEST_GetInvoicesPDF = ('GET', '/api/Orders/InvoicesPDF')
def _prepare_GetInvoicesPDF(*, orderNumber, buffer, printNote) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    params["printNote"] = printNote
    data = None
    return params or None, data

_REQUEST_GetDocumentSeries = ('GET', '/api/Orders/DocumentSeries')
def _prepare_GetDocumentSeries(*, documentTypeId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentTypeId"] = documentTypeId
    data = None
    return params or None, data

_REQUEST_GetStatus = ('GET', '/api/Orders/Status')
def _prepare_GetStatus(*, orderNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["orderNumber"] = orderNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPositionRelations = ('GET', '/api/Orders/PositionRelations')
def _prepare_GetPositionRelations(*, positionId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["positionId"] = positionId
    data = None
    return params or None, data

_REQUEST_IncrementalSync = ('GET', '/api/Orders/IncrementalSync')
def _prepare_IncrementalSync() -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = None
    return params or None, data

_REQUEST_GetPagedDocument = ('GET', '/api/Orders/Page')
def _prepare_GetPagedDocument(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data

_REQUEST_GetDocumentTypesWithRange = ('GET', '/api/Orders/Filter/ByDocumentTypes')
def _prepare_GetDocumentTypesWithRange(*, dateFrom, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data
