from __future__ import annotations

from typing import Awaitable, List, Optional, overload
from datetime import datetime
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import FilterDocumentType
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import IncrementalSyncListElement
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import Order
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderFV
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderListElement
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderPositionRelation
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderStatus
from SymfWebAPI.WebAPI.Interface.Orders.ViewModels import OrderWZ
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDFSettings
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType
from ._common import (
    _prepare_Get,
    _prepare_GetList,
    _prepare_GetListByRecipient,
    _prepare_GetListByBuyer,
    _prepare_GetListByDimension,
    _prepare_GetWZ,
    _prepare_GetFV,
    _prepare_GetPDF,
    _prepare_GetInvoicesPDF,
    _prepare_GetDocumentSeries,
    _prepare_GetStatus,
    _prepare_GetPositionRelations,
    _prepare_IncrementalSync,
    _prepare_GetPagedDocument,
    _prepare_GetDocumentTypesWithRange,
)
from ._ops import (
    OP_Get,
    OP_GetList,
    OP_GetListByRecipient,
    OP_GetListByBuyer,
    OP_GetListByDimension,
    OP_GetWZ,
    OP_GetFV,
    OP_GetPDF,
    OP_GetInvoicesPDF,
    OP_GetDocumentSeries,
    OP_GetStatus,
    OP_GetPositionRelations,
    OP_IncrementalSync,
    OP_GetPagedDocument,
    OP_GetDocumentTypesWithRange,
)

@overload
def Get(api: SyncInvokerProtocol, number: str, buffer: bool) -> ResponseEnvelope[Order]: ...
@overload
def Get(api: SyncRequestProtocol, number: str, buffer: bool) -> ResponseEnvelope[Order]: ...
@overload
def Get(api: AsyncInvokerProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[Order]]: ...
@overload
def Get(api: AsyncRequestProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[Order]]: ...
def Get(api: object, number: str, buffer: bool) -> ResponseEnvelope[Order] | Awaitable[ResponseEnvelope[Order]]:
    params, data = _prepare_Get(number=number, buffer=buffer)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetList(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]]: ...
@overload
def GetList(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]]: ...
@overload
def GetList(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OrderListElement]]]: ...
@overload
def GetList(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OrderListElement]]]: ...
def GetList(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]] | Awaitable[ResponseEnvelope[List[OrderListElement]]]:
    params, data = _prepare_GetList(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetList, params=params, data=data)

@overload
def GetListByRecipient(api: SyncInvokerProtocol, recipientCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]]: ...
@overload
def GetListByRecipient(api: SyncRequestProtocol, recipientCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]]: ...
@overload
def GetListByRecipient(api: AsyncInvokerProtocol, recipientCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OrderListElement]]]: ...
@overload
def GetListByRecipient(api: AsyncRequestProtocol, recipientCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OrderListElement]]]: ...
def GetListByRecipient(api: object, recipientCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]] | Awaitable[ResponseEnvelope[List[OrderListElement]]]:
    params, data = _prepare_GetListByRecipient(recipientCode=recipientCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByRecipient, params=params, data=data)

@overload
def GetListByBuyer(api: SyncInvokerProtocol, buyerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]]: ...
@overload
def GetListByBuyer(api: SyncRequestProtocol, buyerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]]: ...
@overload
def GetListByBuyer(api: AsyncInvokerProtocol, buyerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OrderListElement]]]: ...
@overload
def GetListByBuyer(api: AsyncRequestProtocol, buyerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OrderListElement]]]: ...
def GetListByBuyer(api: object, buyerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]] | Awaitable[ResponseEnvelope[List[OrderListElement]]]:
    params, data = _prepare_GetListByBuyer(buyerCode=buyerCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByBuyer, params=params, data=data)

@overload
def GetListByDimension(api: SyncInvokerProtocol, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[OrderListElement]]: ...
@overload
def GetListByDimension(api: SyncRequestProtocol, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[OrderListElement]]: ...
@overload
def GetListByDimension(api: AsyncInvokerProtocol, dimensionCode: str, dictionaryValue: str) -> Awaitable[ResponseEnvelope[List[OrderListElement]]]: ...
@overload
def GetListByDimension(api: AsyncRequestProtocol, dimensionCode: str, dictionaryValue: str) -> Awaitable[ResponseEnvelope[List[OrderListElement]]]: ...
def GetListByDimension(api: object, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[OrderListElement]] | Awaitable[ResponseEnvelope[List[OrderListElement]]]:
    params, data = _prepare_GetListByDimension(dimensionCode=dimensionCode, dictionaryValue=dictionaryValue)
    return invoke_operation(api, OP_GetListByDimension, params=params, data=data)

@overload
def GetWZ(api: SyncInvokerProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OrderWZ]]: ...
@overload
def GetWZ(api: SyncRequestProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OrderWZ]]: ...
@overload
def GetWZ(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[OrderWZ]]]: ...
@overload
def GetWZ(api: AsyncRequestProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[OrderWZ]]]: ...
def GetWZ(api: object, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OrderWZ]] | Awaitable[ResponseEnvelope[List[OrderWZ]]]:
    params, data = _prepare_GetWZ(orderNumber=orderNumber, buffer=buffer)
    return invoke_operation(api, OP_GetWZ, params=params, data=data)

@overload
def GetFV(api: SyncInvokerProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OrderFV]]: ...
@overload
def GetFV(api: SyncRequestProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OrderFV]]: ...
@overload
def GetFV(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[OrderFV]]]: ...
@overload
def GetFV(api: AsyncRequestProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[OrderFV]]]: ...
def GetFV(api: object, orderNumber: str, buffer: bool) -> ResponseEnvelope[List[OrderFV]] | Awaitable[ResponseEnvelope[List[OrderFV]]]:
    params, data = _prepare_GetFV(orderNumber=orderNumber, buffer=buffer)
    return invoke_operation(api, OP_GetFV, params=params, data=data)

@overload
def GetPDF(api: SyncInvokerProtocol, orderNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: SyncRequestProtocol, orderNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool, settings: "PDFSettings") -> Awaitable[ResponseEnvelope[PDF]]: ...
@overload
def GetPDF(api: AsyncRequestProtocol, orderNumber: str, buffer: bool, settings: "PDFSettings") -> Awaitable[ResponseEnvelope[PDF]]: ...
def GetPDF(api: object, orderNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF] | Awaitable[ResponseEnvelope[PDF]]:
    params, data = _prepare_GetPDF(orderNumber=orderNumber, buffer=buffer, settings=settings)
    return invoke_operation(api, OP_GetPDF, params=params, data=data)

@overload
def GetInvoicesPDF(api: SyncInvokerProtocol, orderNumber: str, buffer: bool, printNote: bool) -> ResponseEnvelope[List[PDF]]: ...
@overload
def GetInvoicesPDF(api: SyncRequestProtocol, orderNumber: str, buffer: bool, printNote: bool) -> ResponseEnvelope[List[PDF]]: ...
@overload
def GetInvoicesPDF(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool, printNote: bool) -> Awaitable[ResponseEnvelope[List[PDF]]]: ...
@overload
def GetInvoicesPDF(api: AsyncRequestProtocol, orderNumber: str, buffer: bool, printNote: bool) -> Awaitable[ResponseEnvelope[List[PDF]]]: ...
def GetInvoicesPDF(api: object, orderNumber: str, buffer: bool, printNote: bool) -> ResponseEnvelope[List[PDF]] | Awaitable[ResponseEnvelope[List[PDF]]]:
    params, data = _prepare_GetInvoicesPDF(orderNumber=orderNumber, buffer=buffer, printNote=printNote)
    return invoke_operation(api, OP_GetInvoicesPDF, params=params, data=data)

@overload
def GetDocumentSeries(api: SyncInvokerProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: SyncRequestProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: AsyncInvokerProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
@overload
def GetDocumentSeries(api: AsyncRequestProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
def GetDocumentSeries(api: object, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]] | Awaitable[ResponseEnvelope[List[DocumentSeries]]]:
    params, data = _prepare_GetDocumentSeries(documentTypeId=documentTypeId)
    return invoke_operation(api, OP_GetDocumentSeries, params=params, data=data)

@overload
def GetStatus(api: SyncInvokerProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[OrderStatus]: ...
@overload
def GetStatus(api: SyncRequestProtocol, orderNumber: str, buffer: bool) -> ResponseEnvelope[OrderStatus]: ...
@overload
def GetStatus(api: AsyncInvokerProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[OrderStatus]]: ...
@overload
def GetStatus(api: AsyncRequestProtocol, orderNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[OrderStatus]]: ...
def GetStatus(api: object, orderNumber: str, buffer: bool) -> ResponseEnvelope[OrderStatus] | Awaitable[ResponseEnvelope[OrderStatus]]:
    params, data = _prepare_GetStatus(orderNumber=orderNumber, buffer=buffer)
    return invoke_operation(api, OP_GetStatus, params=params, data=data)

@overload
def GetPositionRelations(api: SyncInvokerProtocol, positionId: int) -> ResponseEnvelope[OrderPositionRelation]: ...
@overload
def GetPositionRelations(api: SyncRequestProtocol, positionId: int) -> ResponseEnvelope[OrderPositionRelation]: ...
@overload
def GetPositionRelations(api: AsyncInvokerProtocol, positionId: int) -> Awaitable[ResponseEnvelope[OrderPositionRelation]]: ...
@overload
def GetPositionRelations(api: AsyncRequestProtocol, positionId: int) -> Awaitable[ResponseEnvelope[OrderPositionRelation]]: ...
def GetPositionRelations(api: object, positionId: int) -> ResponseEnvelope[OrderPositionRelation] | Awaitable[ResponseEnvelope[OrderPositionRelation]]:
    params, data = _prepare_GetPositionRelations(positionId=positionId)
    return invoke_operation(api, OP_GetPositionRelations, params=params, data=data)

@overload
def IncrementalSync(api: SyncInvokerProtocol) -> ResponseEnvelope[List[IncrementalSyncListElement]]: ...
@overload
def IncrementalSync(api: SyncRequestProtocol) -> ResponseEnvelope[List[IncrementalSyncListElement]]: ...
@overload
def IncrementalSync(api: AsyncInvokerProtocol) -> Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]: ...
@overload
def IncrementalSync(api: AsyncRequestProtocol) -> Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]: ...
def IncrementalSync(api: object) -> ResponseEnvelope[List[IncrementalSyncListElement]] | Awaitable[ResponseEnvelope[List[IncrementalSyncListElement]]]:
    params, data = _prepare_IncrementalSync()
    return invoke_operation(api, OP_IncrementalSync, params=params, data=data)

@overload
def GetPagedDocument(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocument(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocument(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocument(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocument, params=params, data=data)

@overload
def GetDocumentTypesWithRange(api: SyncInvokerProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]]: ...
@overload
def GetDocumentTypesWithRange(api: SyncRequestProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]]: ...
@overload
def GetDocumentTypesWithRange(api: AsyncInvokerProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OrderListElement]]]: ...
@overload
def GetDocumentTypesWithRange(api: AsyncRequestProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[OrderListElement]]]: ...
def GetDocumentTypesWithRange(api: object, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[OrderListElement]] | Awaitable[ResponseEnvelope[List[OrderListElement]]]:
    params, data = _prepare_GetDocumentTypesWithRange(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDocumentTypesWithRange, params=params, data=data)

__all__ = ["Get", "GetList", "GetListByRecipient", "GetListByBuyer", "GetListByDimension", "GetWZ", "GetFV", "GetPDF", "GetInvoicesPDF", "GetDocumentSeries", "GetStatus", "GetPositionRelations", "IncrementalSync", "GetPagedDocument", "GetDocumentTypesWithRange"]
