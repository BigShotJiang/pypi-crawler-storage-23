from __future__ import annotations

from pydantic import BaseModel

import importlib
from typing import TYPE_CHECKING
from typing import Any, List, Optional
from datetime import datetime
from decimal import Decimal
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PaymentRegistryBase, VatRateBase
from SymfWebAPI.WebAPI.Interface.Enums import (
    enumCancelationType,
    enumDocumentStatus,
    enumJPK_V7DocumentAttribute,
    enumManualSettledState,
    enumPriceKind,
    enumRDFStatus,
)

class PurchaseCorrectionIssue(BaseModel):
    MasterDocumentId: Optional[int]
    MasterDocumentNumber: str
    TypeCode: str
    Series: str
    NumberInSeries: Optional[int]
    SplitPayment: bool
    JPK_V7Attributes: Optional["enumJPK_V7DocumentAttribute"]
    Seller: "PurchaseCorrectionIssueContractor"
    Deliverer: "PurchaseCorrectionIssueContractor"
    PaymentRegistry: "PaymentRegistryBase"
    PaymentFormId: Optional[int]
    IssueDate: Optional[datetime]
    ReceiveDate: Optional[datetime]
    PurchaseDate: Optional[datetime]
    ForeignDocumentDate: Optional[datetime]
    MaturityDate: Optional[datetime]
    CurrencyRate: Optional[Decimal]
    Positions: List["PurchaseCorrectionIssuePosition"]
    Catalog: "PurchaseDocumentIssueCatalog"
    Kind: "PurchaseDocumentIssueKind"
    Marker: int
    CorrectionReason: str
    Note: str
    ForeignDocumentNumber: str
    VoluntarySplitPayment: bool
    WhiteList: bool

class PurchaseCorrectionIssueContractor(BaseModel):
    RecalculatePrices: bool
    Data: "PurchaseDocumentIssueContractorData"
    DeliveryAddressCode: str

class PurchaseCorrectionIssuePosition(BaseModel):
    No: Optional[int]
    VatRate: "VatRateBase"
    Elements: List["PurchaseCorrectionIssuePositionElement"]
    Code: str
    Name: str
    Quantity: Decimal
    UnitOfMeasurement: str
    Value: Decimal
    Duty: Decimal
    Excise: Decimal
    PriceValue: Decimal

class PurchaseCorrectionIssuePositionElement(BaseModel):
    Code: str
    Name: str
    Quantity: Decimal
    UnitOfMeasurement: str
    Value: Decimal
    Duty: Decimal
    Excise: Decimal
    PriceValue: Decimal

class PurchaseCorrectionPosition(BaseModel):
    No: int
    BeforeCorrection: "PurchaseCorrectionPositionElement"
    AfterCorrection: "PurchaseCorrectionPositionElement"

class PurchaseCorrectionPositionElement(BaseModel):
    Id: int
    SetHeaderId: Optional[int]
    ProductId: Optional[int]
    ProductCode: str
    Description: str
    Quantity: Decimal
    WrittenQuantity: Decimal
    UnitOfMeasurement: str
    WrittenUnitOfMeasurement: str
    VatRate: "VatRateBase"
    PriceKind: "enumPriceKind"
    PriceValuePLN: Decimal
    PriceValue: Decimal
    NetValuePLN: Decimal
    NetValue: Decimal
    VatValuePLN: Decimal
    GrossValue: Decimal
    Duty: Decimal
    Excise: Decimal

class PurchaseDocumentCorrection(BaseModel):
    No: int
    Id: int
    DocumentNumber: str
    IssueDate: Optional[datetime]
    ReceiveDate: Optional[datetime]
    ForeignDocumentDate: Optional[datetime]

class PurchaseDocumentIssueCatalog(BaseModel):
    FullPath: str
    AddIfNotExist: bool

class PurchaseDocumentIssueContractor(BaseModel):
    Id: Optional[int]
    Code: str
    RecalculatePrices: bool
    Data: "PurchaseDocumentIssueContractorData"
    DeliveryAddressCode: str

class PurchaseDocumentIssueContractorData(BaseModel):
    Name: str
    NIP: str
    Country: str
    City: str
    Street: str
    HouseNo: str
    ApartmentNo: str
    PostCode: str

class PurchaseDocumentIssueKind(BaseModel):
    Code: str
    AddIfNotExist: bool

class PurchaseDocumentIssuePosition(BaseModel):
    VatRate: "VatRateBase"
    Elements: List["PurchaseDocumentIssuePositionElement"]
    Code: str
    Name: str
    Quantity: Decimal
    UnitOfMeasurement: str
    Value: Decimal
    Duty: Decimal
    Excise: Decimal
    PriceValue: Decimal

class PurchaseDocumentIssuePositionElement(BaseModel):
    Code: str
    Name: str
    Quantity: Decimal
    UnitOfMeasurement: str
    Value: Decimal
    Duty: Decimal
    Excise: Decimal
    PriceValue: Decimal

class PurchaseDocumentListElement(BaseModel):
    Id: int
    DocumentNumber: str
    Active: bool
    Canceled: "enumCancelationType"
    Buffer: bool
    Settled: bool
    IssueDate: Optional[datetime]
    PurchaseDate: Optional[datetime]
    ReceiveDate: Optional[datetime]
    MaturityDate: Optional[datetime]
    ForeignDocumentDate: Optional[datetime]
    TypeCode: str
    Series: str
    NumberInSeries: int
    IssuerId: int
    SellerId: Optional[int]
    DelivererId: Optional[int]
    DepartmentId: int
    NetValuePLN: Decimal
    VatValuePLN: Decimal
    NetValue: Decimal
    GrossValue: Decimal
    Currency: str
    Description: str
    IsSmeProcedure: bool
    IsIssuedByBuyer: bool
    InvoiceKind: Any

class PurchaseDocumentPZ(BaseModel):
    Id: int
    DocumentNumber: str
    IssueDate: Optional[datetime]
    OperationDate: Optional[datetime]
    DelivererId: int

class PurchaseDocumentPosition(BaseModel):
    Id: int
    No: int
    SetHeaderId: Optional[int]
    ProductId: Optional[int]
    ProductCode: str
    Description: str
    Quantity: Decimal
    WrittenQuantity: Decimal
    UnitOfMeasurement: str
    WrittenUnitOfMeasurement: str
    VatRate: "VatRateBase"
    PriceKind: "enumPriceKind"
    PriceValuePLN: Decimal
    PriceValue: Decimal
    NetValuePLN: Decimal
    NetValue: Decimal
    VatValuePLN: Decimal
    GrossValue: Decimal
    Duty: Decimal
    Excise: Decimal

class PurchaseDocumentStatus(BaseModel):
    Id: int
    DocumentNumber: str
    Buffer: bool
    PaymentSettled: int
    WarehouseSettled: int
    RDFStatus: "enumRDFStatus"
    ManualSettled: "enumManualSettledState"
    DocumentStatus: "enumDocumentStatus"
    DocumentStatusText: str

_VERSIONED_EXPORTS = {
    'PurchaseCorrection': 'V2026_1',
    'PurchaseDocument': 'V2026_1',
    'PurchaseDocumentIssue': 'V2026_1',
}

def __getattr__(name: str):
    child_name = _VERSIONED_EXPORTS.get(name)
    if child_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module = importlib.import_module(f".{child_name}", __name__)
    value = getattr(module, name)
    globals()[name] = value
    return value

def __dir__():
    return sorted(set(_VERSIONED_EXPORTS) | {n for n in globals() if not n.startswith('_')})

if TYPE_CHECKING:
    from .V2026_1 import PurchaseCorrection, PurchaseDocument, PurchaseDocumentIssue
