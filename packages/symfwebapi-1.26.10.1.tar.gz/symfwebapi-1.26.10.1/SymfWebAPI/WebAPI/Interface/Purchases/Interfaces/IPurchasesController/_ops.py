from __future__ import annotations

from typing import List, Optional
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import FilterDocumentType
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDFSettings
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseCorrection
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseDocument
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseDocumentCorrection
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseDocumentListElement
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseDocumentPZ
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseDocumentStatus
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

_ADAPTER_Get = TypeAdapter(PurchaseDocument)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PurchaseDocument]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/Purchases', parser=_parse_Get)

_ADAPTER_GetCorrection = TypeAdapter(PurchaseCorrection)

def _parse_GetCorrection(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PurchaseCorrection]:
    return parse_with_adapter(envelope, _ADAPTER_GetCorrection)
OP_GetCorrection = OperationSpec(method='GET', path='/api/Purchases/Correction', parser=_parse_GetCorrection)

_ADAPTER_GetList = TypeAdapter(List[PurchaseDocumentListElement])

def _parse_GetList(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PurchaseDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetList)
OP_GetList = OperationSpec(method='GET', path='/api/Purchases/Filter', parser=_parse_GetList)

_ADAPTER_GetListBySeller = TypeAdapter(List[PurchaseDocumentListElement])

def _parse_GetListBySeller(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PurchaseDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListBySeller)
OP_GetListBySeller = OperationSpec(method='GET', path='/api/Purchases/Filter', parser=_parse_GetListBySeller)

_ADAPTER_GetListByDeliverer = TypeAdapter(List[PurchaseDocumentListElement])

def _parse_GetListByDeliverer(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PurchaseDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByDeliverer)
OP_GetListByDeliverer = OperationSpec(method='GET', path='/api/Purchases/Filter', parser=_parse_GetListByDeliverer)

_ADAPTER_GetListByDimension = TypeAdapter(List[PurchaseDocumentListElement])

def _parse_GetListByDimension(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PurchaseDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByDimension)
OP_GetListByDimension = OperationSpec(method='GET', path='/api/Purchases/Filter', parser=_parse_GetListByDimension)

_ADAPTER_GetPZ = TypeAdapter(List[PurchaseDocumentPZ])

def _parse_GetPZ(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PurchaseDocumentPZ]]:
    return parse_with_adapter(envelope, _ADAPTER_GetPZ)
OP_GetPZ = OperationSpec(method='GET', path='/api/Purchases/PZ', parser=_parse_GetPZ)

_ADAPTER_GetZMW = TypeAdapter(List[PurchaseDocumentPZ])

def _parse_GetZMW(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PurchaseDocumentPZ]]:
    return parse_with_adapter(envelope, _ADAPTER_GetZMW)
OP_GetZMW = OperationSpec(method='GET', path='/api/Purchases/ZMW', parser=_parse_GetZMW)

_ADAPTER_GetCorrectionSequence = TypeAdapter(List[PurchaseDocumentCorrection])

def _parse_GetCorrectionSequence(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PurchaseDocumentCorrection]]:
    return parse_with_adapter(envelope, _ADAPTER_GetCorrectionSequence)
OP_GetCorrectionSequence = OperationSpec(method='GET', path='/api/Purchases/CorrectionSequence', parser=_parse_GetCorrectionSequence)

_ADAPTER_GetStatus = TypeAdapter(PurchaseDocumentStatus)

def _parse_GetStatus(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PurchaseDocumentStatus]:
    return parse_with_adapter(envelope, _ADAPTER_GetStatus)
OP_GetStatus = OperationSpec(method='GET', path='/api/Purchases/Status', parser=_parse_GetStatus)

_ADAPTER_GetPDF = TypeAdapter(PDF)

def _parse_GetPDF(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PDF]:
    return parse_with_adapter(envelope, _ADAPTER_GetPDF)
OP_GetPDF = OperationSpec(method='PATCH', path='/api/Purchases/PDF', parser=_parse_GetPDF)

_ADAPTER_GetDocumentSeries = TypeAdapter(List[DocumentSeries])

def _parse_GetDocumentSeries(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentSeries]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentSeries)
OP_GetDocumentSeries = OperationSpec(method='GET', path='/api/Purchases/DocumentSeries', parser=_parse_GetDocumentSeries)

_ADAPTER_GetPagedDocument = TypeAdapter(Page)

def _parse_GetPagedDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocument)
OP_GetPagedDocument = OperationSpec(method='GET', path='/api/Purchases/Page', parser=_parse_GetPagedDocument)

_ADAPTER_GetDocumentTypesWithRange = TypeAdapter(List[PurchaseDocumentListElement])

def _parse_GetDocumentTypesWithRange(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PurchaseDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentTypesWithRange)
OP_GetDocumentTypesWithRange = OperationSpec(method='GET', path='/api/Purchases/Filter/ByDocumentTypes', parser=_parse_GetDocumentTypesWithRange)
