from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/Purchases')
def _prepare_Get(*, number, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetCorrection = ('GET', '/api/Purchases/Correction')
def _prepare_GetCorrection(*, number, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetList = ('GET', '/api/Purchases/Filter')
def _prepare_GetList(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListBySeller = ('GET', '/api/Purchases/Filter')
def _prepare_GetListBySeller(*, sellerCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["sellerCode"] = sellerCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByDeliverer = ('GET', '/api/Purchases/Filter')
def _prepare_GetListByDeliverer(*, delivererCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["delivererCode"] = delivererCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByDimension = ('GET', '/api/Purchases/Filter')
def _prepare_GetListByDimension(*, dimensionCode, dictionaryValue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dimensionCode"] = dimensionCode
    params["dictionaryValue"] = dictionaryValue
    data = None
    return params or None, data

_REQUEST_GetPZ = ('GET', '/api/Purchases/PZ')
def _prepare_GetPZ(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetZMW = ('GET', '/api/Purchases/ZMW')
def _prepare_GetZMW(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetCorrectionSequence = ('GET', '/api/Purchases/CorrectionSequence')
def _prepare_GetCorrectionSequence(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetStatus = ('GET', '/api/Purchases/Status')
def _prepare_GetStatus(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPDF = ('PATCH', '/api/Purchases/PDF')
def _prepare_GetPDF(*, documentNumber, buffer, settings) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = settings.model_dump_json(exclude_unset=True) if settings is not None else None
    return params or None, data

_REQUEST_GetDocumentSeries = ('GET', '/api/Purchases/DocumentSeries')
def _prepare_GetDocumentSeries(*, documentTypeId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentTypeId"] = documentTypeId
    data = None
    return params or None, data

_REQUEST_GetPagedDocument = ('GET', '/api/Purchases/Page')
def _prepare_GetPagedDocument(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data

_REQUEST_GetDocumentTypesWithRange = ('GET', '/api/Purchases/Filter/ByDocumentTypes')
def _prepare_GetDocumentTypesWithRange(*, dateFrom, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data
