from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseCorrection
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseCorrectionIssue
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseDocument
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseDocumentPZ
from ._common import (
    _prepare_AddNew,
    _prepare_Issue,
    _prepare_IssuePZ,
    _prepare_IssuePZCorrection,
    _prepare_ChangeDocumentNumber,
)
from ._ops import (
    OP_AddNew,
    OP_Issue,
    OP_IssuePZ,
    OP_IssuePZCorrection,
    OP_ChangeDocumentNumber,
)

@overload
def AddNew(api: SyncInvokerProtocol, issue: bool, correction: "PurchaseCorrectionIssue") -> ResponseEnvelope[PurchaseCorrection]: ...
@overload
def AddNew(api: SyncRequestProtocol, issue: bool, correction: "PurchaseCorrectionIssue") -> ResponseEnvelope[PurchaseCorrection]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, issue: bool, correction: "PurchaseCorrectionIssue") -> Awaitable[ResponseEnvelope[PurchaseCorrection]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, issue: bool, correction: "PurchaseCorrectionIssue") -> Awaitable[ResponseEnvelope[PurchaseCorrection]]: ...
def AddNew(api: object, issue: bool, correction: "PurchaseCorrectionIssue") -> ResponseEnvelope[PurchaseCorrection] | Awaitable[ResponseEnvelope[PurchaseCorrection]]:
    params, data = _prepare_AddNew(issue=issue, correction=correction)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Issue(api: SyncInvokerProtocol, number: str) -> ResponseEnvelope[PurchaseDocument]: ...
@overload
def Issue(api: SyncRequestProtocol, number: str) -> ResponseEnvelope[PurchaseDocument]: ...
@overload
def Issue(api: AsyncInvokerProtocol, number: str) -> Awaitable[ResponseEnvelope[PurchaseDocument]]: ...
@overload
def Issue(api: AsyncRequestProtocol, number: str) -> Awaitable[ResponseEnvelope[PurchaseDocument]]: ...
def Issue(api: object, number: str) -> ResponseEnvelope[PurchaseDocument] | Awaitable[ResponseEnvelope[PurchaseDocument]]:
    params, data = _prepare_Issue(number=number)
    return invoke_operation(api, OP_Issue, params=params, data=data)

@overload
def IssuePZ(api: SyncInvokerProtocol, documentNumber: str) -> ResponseEnvelope[List[PurchaseDocumentPZ]]: ...
@overload
def IssuePZ(api: SyncRequestProtocol, documentNumber: str) -> ResponseEnvelope[List[PurchaseDocumentPZ]]: ...
@overload
def IssuePZ(api: AsyncInvokerProtocol, documentNumber: str) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]: ...
@overload
def IssuePZ(api: AsyncRequestProtocol, documentNumber: str) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]: ...
def IssuePZ(api: object, documentNumber: str) -> ResponseEnvelope[List[PurchaseDocumentPZ]] | Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]:
    params, data = _prepare_IssuePZ(documentNumber=documentNumber)
    return invoke_operation(api, OP_IssuePZ, params=params, data=data)

@overload
def IssuePZCorrection(api: SyncInvokerProtocol, documentNumber: str, issue: bool) -> ResponseEnvelope[List[PurchaseDocumentPZ]]: ...
@overload
def IssuePZCorrection(api: SyncRequestProtocol, documentNumber: str, issue: bool) -> ResponseEnvelope[List[PurchaseDocumentPZ]]: ...
@overload
def IssuePZCorrection(api: AsyncInvokerProtocol, documentNumber: str, issue: bool) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]: ...
@overload
def IssuePZCorrection(api: AsyncRequestProtocol, documentNumber: str, issue: bool) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]: ...
def IssuePZCorrection(api: object, documentNumber: str, issue: bool) -> ResponseEnvelope[List[PurchaseDocumentPZ]] | Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]:
    params, data = _prepare_IssuePZCorrection(documentNumber=documentNumber, issue=issue)
    return invoke_operation(api, OP_IssuePZCorrection, params=params, data=data)

@overload
def ChangeDocumentNumber(api: SyncInvokerProtocol, id: int, number: str) -> ResponseEnvelope[None]: ...
@overload
def ChangeDocumentNumber(api: SyncRequestProtocol, id: int, number: str) -> ResponseEnvelope[None]: ...
@overload
def ChangeDocumentNumber(api: AsyncInvokerProtocol, id: int, number: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def ChangeDocumentNumber(api: AsyncRequestProtocol, id: int, number: str) -> Awaitable[ResponseEnvelope[None]]: ...
def ChangeDocumentNumber(api: object, id: int, number: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_ChangeDocumentNumber(id=id, number=number)
    return invoke_operation(api, OP_ChangeDocumentNumber, params=params, data=data)

__all__ = ["AddNew", "Issue", "IssuePZ", "IssuePZCorrection", "ChangeDocumentNumber"]
