from __future__ import annotations

from typing import Awaitable, List, Optional, overload
from datetime import datetime
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import FilterDocumentType
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDFSettings
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseCorrection
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseDocument
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseDocumentCorrection
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseDocumentListElement
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseDocumentPZ
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseDocumentStatus
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType
from ._common import (
    _prepare_Get,
    _prepare_GetCorrection,
    _prepare_GetList,
    _prepare_GetListBySeller,
    _prepare_GetListByDeliverer,
    _prepare_GetListByDimension,
    _prepare_GetPZ,
    _prepare_GetZMW,
    _prepare_GetCorrectionSequence,
    _prepare_GetStatus,
    _prepare_GetPDF,
    _prepare_GetDocumentSeries,
    _prepare_GetPagedDocument,
    _prepare_GetDocumentTypesWithRange,
)
from ._ops import (
    OP_Get,
    OP_GetCorrection,
    OP_GetList,
    OP_GetListBySeller,
    OP_GetListByDeliverer,
    OP_GetListByDimension,
    OP_GetPZ,
    OP_GetZMW,
    OP_GetCorrectionSequence,
    OP_GetStatus,
    OP_GetPDF,
    OP_GetDocumentSeries,
    OP_GetPagedDocument,
    OP_GetDocumentTypesWithRange,
)

@overload
def Get(api: SyncInvokerProtocol, number: str, buffer: bool) -> ResponseEnvelope[PurchaseDocument]: ...
@overload
def Get(api: SyncRequestProtocol, number: str, buffer: bool) -> ResponseEnvelope[PurchaseDocument]: ...
@overload
def Get(api: AsyncInvokerProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[PurchaseDocument]]: ...
@overload
def Get(api: AsyncRequestProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[PurchaseDocument]]: ...
def Get(api: object, number: str, buffer: bool) -> ResponseEnvelope[PurchaseDocument] | Awaitable[ResponseEnvelope[PurchaseDocument]]:
    params, data = _prepare_Get(number=number, buffer=buffer)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetCorrection(api: SyncInvokerProtocol, number: str, buffer: bool) -> ResponseEnvelope[PurchaseCorrection]: ...
@overload
def GetCorrection(api: SyncRequestProtocol, number: str, buffer: bool) -> ResponseEnvelope[PurchaseCorrection]: ...
@overload
def GetCorrection(api: AsyncInvokerProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[PurchaseCorrection]]: ...
@overload
def GetCorrection(api: AsyncRequestProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[PurchaseCorrection]]: ...
def GetCorrection(api: object, number: str, buffer: bool) -> ResponseEnvelope[PurchaseCorrection] | Awaitable[ResponseEnvelope[PurchaseCorrection]]:
    params, data = _prepare_GetCorrection(number=number, buffer=buffer)
    return invoke_operation(api, OP_GetCorrection, params=params, data=data)

@overload
def GetList(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]]: ...
@overload
def GetList(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]]: ...
@overload
def GetList(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]: ...
@overload
def GetList(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]: ...
def GetList(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]] | Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]:
    params, data = _prepare_GetList(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetList, params=params, data=data)

@overload
def GetListBySeller(api: SyncInvokerProtocol, sellerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]]: ...
@overload
def GetListBySeller(api: SyncRequestProtocol, sellerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]]: ...
@overload
def GetListBySeller(api: AsyncInvokerProtocol, sellerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]: ...
@overload
def GetListBySeller(api: AsyncRequestProtocol, sellerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]: ...
def GetListBySeller(api: object, sellerCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]] | Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]:
    params, data = _prepare_GetListBySeller(sellerCode=sellerCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListBySeller, params=params, data=data)

@overload
def GetListByDeliverer(api: SyncInvokerProtocol, delivererCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]]: ...
@overload
def GetListByDeliverer(api: SyncRequestProtocol, delivererCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]]: ...
@overload
def GetListByDeliverer(api: AsyncInvokerProtocol, delivererCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]: ...
@overload
def GetListByDeliverer(api: AsyncRequestProtocol, delivererCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]: ...
def GetListByDeliverer(api: object, delivererCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]] | Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]:
    params, data = _prepare_GetListByDeliverer(delivererCode=delivererCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByDeliverer, params=params, data=data)

@overload
def GetListByDimension(api: SyncInvokerProtocol, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[PurchaseDocumentListElement]]: ...
@overload
def GetListByDimension(api: SyncRequestProtocol, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[PurchaseDocumentListElement]]: ...
@overload
def GetListByDimension(api: AsyncInvokerProtocol, dimensionCode: str, dictionaryValue: str) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]: ...
@overload
def GetListByDimension(api: AsyncRequestProtocol, dimensionCode: str, dictionaryValue: str) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]: ...
def GetListByDimension(api: object, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[PurchaseDocumentListElement]] | Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]:
    params, data = _prepare_GetListByDimension(dimensionCode=dimensionCode, dictionaryValue=dictionaryValue)
    return invoke_operation(api, OP_GetListByDimension, params=params, data=data)

@overload
def GetPZ(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PurchaseDocumentPZ]]: ...
@overload
def GetPZ(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PurchaseDocumentPZ]]: ...
@overload
def GetPZ(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]: ...
@overload
def GetPZ(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]: ...
def GetPZ(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PurchaseDocumentPZ]] | Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]:
    params, data = _prepare_GetPZ(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetPZ, params=params, data=data)

@overload
def GetZMW(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PurchaseDocumentPZ]]: ...
@overload
def GetZMW(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PurchaseDocumentPZ]]: ...
@overload
def GetZMW(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]: ...
@overload
def GetZMW(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]: ...
def GetZMW(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PurchaseDocumentPZ]] | Awaitable[ResponseEnvelope[List[PurchaseDocumentPZ]]]:
    params, data = _prepare_GetZMW(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetZMW, params=params, data=data)

@overload
def GetCorrectionSequence(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PurchaseDocumentCorrection]]: ...
@overload
def GetCorrectionSequence(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PurchaseDocumentCorrection]]: ...
@overload
def GetCorrectionSequence(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentCorrection]]]: ...
@overload
def GetCorrectionSequence(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentCorrection]]]: ...
def GetCorrectionSequence(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PurchaseDocumentCorrection]] | Awaitable[ResponseEnvelope[List[PurchaseDocumentCorrection]]]:
    params, data = _prepare_GetCorrectionSequence(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetCorrectionSequence, params=params, data=data)

@overload
def GetStatus(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[PurchaseDocumentStatus]: ...
@overload
def GetStatus(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[PurchaseDocumentStatus]: ...
@overload
def GetStatus(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[PurchaseDocumentStatus]]: ...
@overload
def GetStatus(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[PurchaseDocumentStatus]]: ...
def GetStatus(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[PurchaseDocumentStatus] | Awaitable[ResponseEnvelope[PurchaseDocumentStatus]]:
    params, data = _prepare_GetStatus(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetStatus, params=params, data=data)

@overload
def GetPDF(api: SyncInvokerProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: SyncRequestProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> Awaitable[ResponseEnvelope[PDF]]: ...
@overload
def GetPDF(api: AsyncRequestProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> Awaitable[ResponseEnvelope[PDF]]: ...
def GetPDF(api: object, documentNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF] | Awaitable[ResponseEnvelope[PDF]]:
    params, data = _prepare_GetPDF(documentNumber=documentNumber, buffer=buffer, settings=settings)
    return invoke_operation(api, OP_GetPDF, params=params, data=data)

@overload
def GetDocumentSeries(api: SyncInvokerProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: SyncRequestProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: AsyncInvokerProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
@overload
def GetDocumentSeries(api: AsyncRequestProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
def GetDocumentSeries(api: object, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]] | Awaitable[ResponseEnvelope[List[DocumentSeries]]]:
    params, data = _prepare_GetDocumentSeries(documentTypeId=documentTypeId)
    return invoke_operation(api, OP_GetDocumentSeries, params=params, data=data)

@overload
def GetPagedDocument(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocument(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocument(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocument(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocument, params=params, data=data)

@overload
def GetDocumentTypesWithRange(api: SyncInvokerProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]]: ...
@overload
def GetDocumentTypesWithRange(api: SyncRequestProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]]: ...
@overload
def GetDocumentTypesWithRange(api: AsyncInvokerProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]: ...
@overload
def GetDocumentTypesWithRange(api: AsyncRequestProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]: ...
def GetDocumentTypesWithRange(api: object, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PurchaseDocumentListElement]] | Awaitable[ResponseEnvelope[List[PurchaseDocumentListElement]]]:
    params, data = _prepare_GetDocumentTypesWithRange(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDocumentTypesWithRange, params=params, data=data)

__all__ = ["Get", "GetCorrection", "GetList", "GetListBySeller", "GetListByDeliverer", "GetListByDimension", "GetPZ", "GetZMW", "GetCorrectionSequence", "GetStatus", "GetPDF", "GetDocumentSeries", "GetPagedDocument", "GetDocumentTypesWithRange"]
