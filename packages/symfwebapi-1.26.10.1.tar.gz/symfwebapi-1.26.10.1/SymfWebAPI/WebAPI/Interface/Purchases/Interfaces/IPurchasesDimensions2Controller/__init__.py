from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PositionDimension
from ._common import (
    _prepare_Get,
    _prepare_GetPositionsByDocumentId,
    _prepare_GetPositionsByDocumentNumber,
    _prepare_GetPosition,
)
from ._ops import (
    OP_Get,
    OP_GetPositionsByDocumentId,
    OP_GetPositionsByDocumentNumber,
    OP_GetPosition,
)

@overload
def Get(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def Get(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def Get(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def Get(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def Get(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_Get(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetPositionsByDocumentId(api: SyncInvokerProtocol, documentId: int) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByDocumentId(api: SyncRequestProtocol, documentId: int) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByDocumentId(api: AsyncInvokerProtocol, documentId: int) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
@overload
def GetPositionsByDocumentId(api: AsyncRequestProtocol, documentId: int) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
def GetPositionsByDocumentId(api: object, documentId: int) -> ResponseEnvelope[List[PositionDimension]] | Awaitable[ResponseEnvelope[List[PositionDimension]]]:
    params, data = _prepare_GetPositionsByDocumentId(documentId=documentId)
    return invoke_operation(api, OP_GetPositionsByDocumentId, params=params, data=data)

@overload
def GetPositionsByDocumentNumber(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByDocumentNumber(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PositionDimension]]: ...
@overload
def GetPositionsByDocumentNumber(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
@overload
def GetPositionsByDocumentNumber(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[PositionDimension]]]: ...
def GetPositionsByDocumentNumber(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[PositionDimension]] | Awaitable[ResponseEnvelope[List[PositionDimension]]]:
    params, data = _prepare_GetPositionsByDocumentNumber(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetPositionsByDocumentNumber, params=params, data=data)

@overload
def GetPosition(api: SyncInvokerProtocol, positionId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetPosition(api: SyncRequestProtocol, positionId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetPosition(api: AsyncInvokerProtocol, positionId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def GetPosition(api: AsyncRequestProtocol, positionId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def GetPosition(api: object, positionId: int) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_GetPosition(positionId=positionId)
    return invoke_operation(api, OP_GetPosition, params=params, data=data)

__all__ = ["Get", "GetPositionsByDocumentId", "GetPositionsByDocumentNumber", "GetPosition"]
