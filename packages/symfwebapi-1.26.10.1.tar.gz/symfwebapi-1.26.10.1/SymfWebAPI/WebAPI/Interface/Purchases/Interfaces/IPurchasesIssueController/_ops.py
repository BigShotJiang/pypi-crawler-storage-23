from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseCorrection
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseCorrectionIssue
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels.V2026_1 import PurchaseDocument
from SymfWebAPI.WebAPI.Interface.Purchases.ViewModels import PurchaseDocumentPZ

_ADAPTER_AddNew = TypeAdapter(PurchaseCorrection)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PurchaseCorrection]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/PurchasesIssue/NewCorrection', parser=_parse_AddNew)

_ADAPTER_Issue = TypeAdapter(PurchaseDocument)

def _parse_Issue(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PurchaseDocument]:
    return parse_with_adapter(envelope, _ADAPTER_Issue)
OP_Issue = OperationSpec(method='PUT', path='/api/PurchasesIssue/InBuffer', parser=_parse_Issue)

_ADAPTER_IssuePZ = TypeAdapter(List[PurchaseDocumentPZ])

def _parse_IssuePZ(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PurchaseDocumentPZ]]:
    return parse_with_adapter(envelope, _ADAPTER_IssuePZ)
OP_IssuePZ = OperationSpec(method='PUT', path='/api/PurchasesIssue/PZ', parser=_parse_IssuePZ)

_ADAPTER_IssuePZCorrection = TypeAdapter(List[PurchaseDocumentPZ])

def _parse_IssuePZCorrection(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PurchaseDocumentPZ]]:
    return parse_with_adapter(envelope, _ADAPTER_IssuePZCorrection)
OP_IssuePZCorrection = OperationSpec(method='PUT', path='/api/PurchasesIssue/PZCorrection', parser=_parse_IssuePZCorrection)

def _parse_ChangeDocumentNumber(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_ChangeDocumentNumber = OperationSpec(method='PATCH', path='/api/PurchasesIssue/DocumentNumber', parser=_parse_ChangeDocumentNumber)
