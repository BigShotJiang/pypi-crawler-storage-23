from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/v2/PurchasesDimensions')
def _prepare_Get(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPositionsByDocumentId = ('GET', '/api/v2/PurchasesDimensions/Positions')
def _prepare_GetPositionsByDocumentId(*, documentId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentId"] = documentId
    data = None
    return params or None, data

_REQUEST_GetPositionsByDocumentNumber = ('GET', '/api/v2/PurchasesDimensions/Positions')
def _prepare_GetPositionsByDocumentNumber(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPosition = ('GET', '/api/v2/PurchasesDimensions/Positions')
def _prepare_GetPosition(*, positionId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["positionId"] = positionId
    data = None
    return params or None, data
