from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/PurchasesIssue/NewCorrection')
def _prepare_AddNew(*, issue, correction) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["issue"] = issue
    data = correction.model_dump_json(exclude_unset=True) if correction is not None else None
    return params or None, data

_REQUEST_Issue = ('PUT', '/api/PurchasesIssue/InBuffer')
def _prepare_Issue(*, number) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    data = None
    return params or None, data

_REQUEST_IssuePZ = ('PUT', '/api/PurchasesIssue/PZ')
def _prepare_IssuePZ(*, documentNumber) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    data = None
    return params or None, data

_REQUEST_IssuePZCorrection = ('PUT', '/api/PurchasesIssue/PZCorrection')
def _prepare_IssuePZCorrection(*, documentNumber, issue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["issue"] = issue
    data = None
    return params or None, data

_REQUEST_ChangeDocumentNumber = ('PATCH', '/api/PurchasesIssue/DocumentNumber')
def _prepare_ChangeDocumentNumber(*, id, number) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    params["number"] = number
    data = None
    return params or None, data
