from __future__ import annotations

from typing import List, Optional
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels import Settlement
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels.Issue import SettlementIssue
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels import SettlementListElement

_ADAPTER_Get = TypeAdapter(Settlement)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Settlement]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/Settlements', parser=_parse_Get)

_ADAPTER_GetByDocument = TypeAdapter(Settlement)

def _parse_GetByDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Settlement]:
    return parse_with_adapter(envelope, _ADAPTER_GetByDocument)
OP_GetByDocument = OperationSpec(method='GET', path='/api/Settlements', parser=_parse_GetByDocument)

def _parse_GetListByIssueDate(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_GetListByIssueDate = OperationSpec(method='GET', path='/api/Settlements/Filter/ByIssueDate', parser=_parse_GetListByIssueDate)

_ADAPTER_GetListByMaturityDate = TypeAdapter(List[SettlementListElement])

def _parse_GetListByMaturityDate(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SettlementListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByMaturityDate)
OP_GetListByMaturityDate = OperationSpec(method='GET', path='/api/Settlements/Filter/ByMaturityDate', parser=_parse_GetListByMaturityDate)

def _parse_GetNotSettledByIssueDate(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_GetNotSettledByIssueDate = OperationSpec(method='GET', path='/api/Settlements/Filter/NotSettled/ByIssueDate', parser=_parse_GetNotSettledByIssueDate)

_ADAPTER_GetNotSettledByMaturityDate = TypeAdapter(List[SettlementListElement])

def _parse_GetNotSettledByMaturityDate(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[SettlementListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetNotSettledByMaturityDate)
OP_GetNotSettledByMaturityDate = OperationSpec(method='GET', path='/api/Settlements/Filter/NotSettled/ByMaturityDate', parser=_parse_GetNotSettledByMaturityDate)

_ADAPTER_Issue = TypeAdapter(Settlement)

def _parse_Issue(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Settlement]:
    return parse_with_adapter(envelope, _ADAPTER_Issue)
OP_Issue = OperationSpec(method='POST', path='/api/Settlements/Issue', parser=_parse_Issue)
