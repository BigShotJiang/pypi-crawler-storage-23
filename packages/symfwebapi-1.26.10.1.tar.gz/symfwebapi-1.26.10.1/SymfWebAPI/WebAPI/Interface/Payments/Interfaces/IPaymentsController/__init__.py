from __future__ import annotations

from typing import Awaitable, List, Optional, overload
from datetime import datetime
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels import Payment
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels.Issue import PaymentIssue
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels.IssueKP import PaymentKPIssue
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels import PaymentListElement
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType
from ._common import (
    _prepare_Get,
    _prepare_GetList,
    _prepare_GetListByContractor,
    _prepare_GetListByPaymentRegistry,
    _prepare_GetListByReceivingPaymentRegistry,
    _prepare_GetPDF,
    _prepare_GetDocumentSeries,
    _prepare_IssuePayment,
    _prepare_IssueTransferMinus,
    _prepare_IssueTransferPlus,
    _prepare_IssueKP,
    _prepare_GetPagedDocument,
)
from ._ops import (
    OP_Get,
    OP_GetList,
    OP_GetListByContractor,
    OP_GetListByPaymentRegistry,
    OP_GetListByReceivingPaymentRegistry,
    OP_GetPDF,
    OP_GetDocumentSeries,
    OP_IssuePayment,
    OP_IssueTransferMinus,
    OP_IssueTransferPlus,
    OP_IssueKP,
    OP_GetPagedDocument,
)

@overload
def Get(api: SyncInvokerProtocol, number: str, buffer: bool) -> ResponseEnvelope[Payment]: ...
@overload
def Get(api: SyncRequestProtocol, number: str, buffer: bool) -> ResponseEnvelope[Payment]: ...
@overload
def Get(api: AsyncInvokerProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[Payment]]: ...
@overload
def Get(api: AsyncRequestProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[Payment]]: ...
def Get(api: object, number: str, buffer: bool) -> ResponseEnvelope[Payment] | Awaitable[ResponseEnvelope[Payment]]:
    params, data = _prepare_Get(number=number, buffer=buffer)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetList(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]]: ...
@overload
def GetList(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]]: ...
@overload
def GetList(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PaymentListElement]]]: ...
@overload
def GetList(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PaymentListElement]]]: ...
def GetList(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]] | Awaitable[ResponseEnvelope[List[PaymentListElement]]]:
    params, data = _prepare_GetList(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetList, params=params, data=data)

@overload
def GetListByContractor(api: SyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]]: ...
@overload
def GetListByContractor(api: SyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]]: ...
@overload
def GetListByContractor(api: AsyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PaymentListElement]]]: ...
@overload
def GetListByContractor(api: AsyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PaymentListElement]]]: ...
def GetListByContractor(api: object, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]] | Awaitable[ResponseEnvelope[List[PaymentListElement]]]:
    params, data = _prepare_GetListByContractor(contractorCode=contractorCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByContractor, params=params, data=data)

@overload
def GetListByPaymentRegistry(api: SyncInvokerProtocol, paymentRegistryCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]]: ...
@overload
def GetListByPaymentRegistry(api: SyncRequestProtocol, paymentRegistryCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]]: ...
@overload
def GetListByPaymentRegistry(api: AsyncInvokerProtocol, paymentRegistryCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PaymentListElement]]]: ...
@overload
def GetListByPaymentRegistry(api: AsyncRequestProtocol, paymentRegistryCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PaymentListElement]]]: ...
def GetListByPaymentRegistry(api: object, paymentRegistryCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]] | Awaitable[ResponseEnvelope[List[PaymentListElement]]]:
    params, data = _prepare_GetListByPaymentRegistry(paymentRegistryCode=paymentRegistryCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByPaymentRegistry, params=params, data=data)

@overload
def GetListByReceivingPaymentRegistry(api: SyncInvokerProtocol, receivingPaymentRegistryCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]]: ...
@overload
def GetListByReceivingPaymentRegistry(api: SyncRequestProtocol, receivingPaymentRegistryCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]]: ...
@overload
def GetListByReceivingPaymentRegistry(api: AsyncInvokerProtocol, receivingPaymentRegistryCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PaymentListElement]]]: ...
@overload
def GetListByReceivingPaymentRegistry(api: AsyncRequestProtocol, receivingPaymentRegistryCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[PaymentListElement]]]: ...
def GetListByReceivingPaymentRegistry(api: object, receivingPaymentRegistryCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[PaymentListElement]] | Awaitable[ResponseEnvelope[List[PaymentListElement]]]:
    params, data = _prepare_GetListByReceivingPaymentRegistry(receivingPaymentRegistryCode=receivingPaymentRegistryCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByReceivingPaymentRegistry, params=params, data=data)

@overload
def GetPDF(api: SyncInvokerProtocol, documentNumber: str, buffer: bool, printNote: bool) -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: SyncRequestProtocol, documentNumber: str, buffer: bool, printNote: bool) -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool, printNote: bool) -> Awaitable[ResponseEnvelope[PDF]]: ...
@overload
def GetPDF(api: AsyncRequestProtocol, documentNumber: str, buffer: bool, printNote: bool) -> Awaitable[ResponseEnvelope[PDF]]: ...
def GetPDF(api: object, documentNumber: str, buffer: bool, printNote: bool) -> ResponseEnvelope[PDF] | Awaitable[ResponseEnvelope[PDF]]:
    params, data = _prepare_GetPDF(documentNumber=documentNumber, buffer=buffer, printNote=printNote)
    return invoke_operation(api, OP_GetPDF, params=params, data=data)

@overload
def GetDocumentSeries(api: SyncInvokerProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: SyncRequestProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: AsyncInvokerProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
@overload
def GetDocumentSeries(api: AsyncRequestProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
def GetDocumentSeries(api: object, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]] | Awaitable[ResponseEnvelope[List[DocumentSeries]]]:
    params, data = _prepare_GetDocumentSeries(documentTypeId=documentTypeId)
    return invoke_operation(api, OP_GetDocumentSeries, params=params, data=data)

@overload
def IssuePayment(api: SyncInvokerProtocol, payment: "PaymentIssue") -> ResponseEnvelope[Payment]: ...
@overload
def IssuePayment(api: SyncRequestProtocol, payment: "PaymentIssue") -> ResponseEnvelope[Payment]: ...
@overload
def IssuePayment(api: AsyncInvokerProtocol, payment: "PaymentIssue") -> Awaitable[ResponseEnvelope[Payment]]: ...
@overload
def IssuePayment(api: AsyncRequestProtocol, payment: "PaymentIssue") -> Awaitable[ResponseEnvelope[Payment]]: ...
def IssuePayment(api: object, payment: "PaymentIssue") -> ResponseEnvelope[Payment] | Awaitable[ResponseEnvelope[Payment]]:
    params, data = _prepare_IssuePayment(payment=payment)
    return invoke_operation(api, OP_IssuePayment, params=params, data=data)

@overload
def IssueTransferMinus(api: SyncInvokerProtocol, payment: "PaymentIssue") -> ResponseEnvelope[Payment]: ...
@overload
def IssueTransferMinus(api: SyncRequestProtocol, payment: "PaymentIssue") -> ResponseEnvelope[Payment]: ...
@overload
def IssueTransferMinus(api: AsyncInvokerProtocol, payment: "PaymentIssue") -> Awaitable[ResponseEnvelope[Payment]]: ...
@overload
def IssueTransferMinus(api: AsyncRequestProtocol, payment: "PaymentIssue") -> Awaitable[ResponseEnvelope[Payment]]: ...
def IssueTransferMinus(api: object, payment: "PaymentIssue") -> ResponseEnvelope[Payment] | Awaitable[ResponseEnvelope[Payment]]:
    params, data = _prepare_IssueTransferMinus(payment=payment)
    return invoke_operation(api, OP_IssueTransferMinus, params=params, data=data)

@overload
def IssueTransferPlus(api: SyncInvokerProtocol, paymentNumber: str) -> ResponseEnvelope[Payment]: ...
@overload
def IssueTransferPlus(api: SyncRequestProtocol, paymentNumber: str) -> ResponseEnvelope[Payment]: ...
@overload
def IssueTransferPlus(api: AsyncInvokerProtocol, paymentNumber: str) -> Awaitable[ResponseEnvelope[Payment]]: ...
@overload
def IssueTransferPlus(api: AsyncRequestProtocol, paymentNumber: str) -> Awaitable[ResponseEnvelope[Payment]]: ...
def IssueTransferPlus(api: object, paymentNumber: str) -> ResponseEnvelope[Payment] | Awaitable[ResponseEnvelope[Payment]]:
    params, data = _prepare_IssueTransferPlus(paymentNumber=paymentNumber)
    return invoke_operation(api, OP_IssueTransferPlus, params=params, data=data)

@overload
def IssueKP(api: SyncInvokerProtocol, payment: "PaymentKPIssue") -> ResponseEnvelope[None]: ...
@overload
def IssueKP(api: SyncRequestProtocol, payment: "PaymentKPIssue") -> ResponseEnvelope[None]: ...
@overload
def IssueKP(api: AsyncInvokerProtocol, payment: "PaymentKPIssue") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def IssueKP(api: AsyncRequestProtocol, payment: "PaymentKPIssue") -> Awaitable[ResponseEnvelope[None]]: ...
def IssueKP(api: object, payment: "PaymentKPIssue") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_IssueKP(payment=payment)
    return invoke_operation(api, OP_IssueKP, params=params, data=data)

@overload
def GetPagedDocument(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocument(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocument(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocument(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocument, params=params, data=data)

__all__ = ["Get", "GetList", "GetListByContractor", "GetListByPaymentRegistry", "GetListByReceivingPaymentRegistry", "GetPDF", "GetDocumentSeries", "IssuePayment", "IssueTransferMinus", "IssueTransferPlus", "IssueKP", "GetPagedDocument"]
