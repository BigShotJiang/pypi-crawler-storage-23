from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/Payments')
def _prepare_Get(*, number, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetList = ('GET', '/api/Payments/Filter')
def _prepare_GetList(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByContractor = ('GET', '/api/Payments/Filter')
def _prepare_GetListByContractor(*, contractorCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByPaymentRegistry = ('GET', '/api/Payments/Filter')
def _prepare_GetListByPaymentRegistry(*, paymentRegistryCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["paymentRegistryCode"] = paymentRegistryCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByReceivingPaymentRegistry = ('GET', '/api/Payments/Filter')
def _prepare_GetListByReceivingPaymentRegistry(*, receivingPaymentRegistryCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["receivingPaymentRegistryCode"] = receivingPaymentRegistryCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetPDF = ('GET', '/api/Payments/PDF')
def _prepare_GetPDF(*, documentNumber, buffer, printNote) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    params["printNote"] = printNote
    data = None
    return params or None, data

_REQUEST_GetDocumentSeries = ('GET', '/api/Payments/DocumentSeries')
def _prepare_GetDocumentSeries(*, documentTypeId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentTypeId"] = documentTypeId
    data = None
    return params or None, data

_REQUEST_IssuePayment = ('POST', '/api/Payments/Payment')
def _prepare_IssuePayment(*, payment) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = payment.model_dump_json(exclude_unset=True) if payment is not None else None
    return params or None, data

_REQUEST_IssueTransferMinus = ('POST', '/api/Payments/TransferMinus')
def _prepare_IssueTransferMinus(*, payment) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = payment.model_dump_json(exclude_unset=True) if payment is not None else None
    return params or None, data

_REQUEST_IssueTransferPlus = ('PUT', '/api/Payments/TransferPlus')
def _prepare_IssueTransferPlus(*, paymentNumber) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["paymentNumber"] = paymentNumber
    data = None
    return params or None, data

_REQUEST_IssueKP = ('POST', '/api/Payments/IssueKP')
def _prepare_IssueKP(*, payment) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = payment.model_dump_json(exclude_unset=True) if payment is not None else None
    return params or None, data

_REQUEST_GetPagedDocument = ('GET', '/api/Payments/Page')
def _prepare_GetPagedDocument(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data
