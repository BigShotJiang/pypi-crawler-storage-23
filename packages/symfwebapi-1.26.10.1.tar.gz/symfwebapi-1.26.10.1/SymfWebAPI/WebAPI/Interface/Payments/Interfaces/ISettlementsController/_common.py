from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/Settlements')
def _prepare_Get(*, number, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetByDocument = ('GET', '/api/Settlements')
def _prepare_GetByDocument(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetListByIssueDate = ('GET', '/api/Settlements/Filter/ByIssueDate')
def _prepare_GetListByIssueDate(*, contractorCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetListByMaturityDate = ('GET', '/api/Settlements/Filter/ByMaturityDate')
def _prepare_GetListByMaturityDate(*, contractorCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetNotSettledByIssueDate = ('GET', '/api/Settlements/Filter/NotSettled/ByIssueDate')
def _prepare_GetNotSettledByIssueDate(*, contractorCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetNotSettledByMaturityDate = ('GET', '/api/Settlements/Filter/NotSettled/ByMaturityDate')
def _prepare_GetNotSettledByMaturityDate(*, contractorCode, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_Issue = ('POST', '/api/Settlements/Issue')
def _prepare_Issue(*, settlement) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = settlement.model_dump_json(exclude_unset=True) if settlement is not None else None
    return params or None, data
