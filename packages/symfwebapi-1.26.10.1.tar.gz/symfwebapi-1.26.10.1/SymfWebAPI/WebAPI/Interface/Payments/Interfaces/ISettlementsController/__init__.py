from __future__ import annotations

from typing import Awaitable, List, Optional, overload
from datetime import datetime
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels import Settlement
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels.Issue import SettlementIssue
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels import SettlementListElement
from ._common import (
    _prepare_Get,
    _prepare_GetByDocument,
    _prepare_GetListByIssueDate,
    _prepare_GetListByMaturityDate,
    _prepare_GetNotSettledByIssueDate,
    _prepare_GetNotSettledByMaturityDate,
    _prepare_Issue,
)
from ._ops import (
    OP_Get,
    OP_GetByDocument,
    OP_GetListByIssueDate,
    OP_GetListByMaturityDate,
    OP_GetNotSettledByIssueDate,
    OP_GetNotSettledByMaturityDate,
    OP_Issue,
)

@overload
def Get(api: SyncInvokerProtocol, number: str, buffer: bool) -> ResponseEnvelope[Settlement]: ...
@overload
def Get(api: SyncRequestProtocol, number: str, buffer: bool) -> ResponseEnvelope[Settlement]: ...
@overload
def Get(api: AsyncInvokerProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[Settlement]]: ...
@overload
def Get(api: AsyncRequestProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[Settlement]]: ...
def Get(api: object, number: str, buffer: bool) -> ResponseEnvelope[Settlement] | Awaitable[ResponseEnvelope[Settlement]]:
    params, data = _prepare_Get(number=number, buffer=buffer)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetByDocument(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[Settlement]: ...
@overload
def GetByDocument(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[Settlement]: ...
@overload
def GetByDocument(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[Settlement]]: ...
@overload
def GetByDocument(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[Settlement]]: ...
def GetByDocument(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[Settlement] | Awaitable[ResponseEnvelope[Settlement]]:
    params, data = _prepare_GetByDocument(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetByDocument, params=params, data=data)

@overload
def GetListByIssueDate(api: SyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[None]: ...
@overload
def GetListByIssueDate(api: SyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[None]: ...
@overload
def GetListByIssueDate(api: AsyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def GetListByIssueDate(api: AsyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[None]]: ...
def GetListByIssueDate(api: object, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_GetListByIssueDate(contractorCode=contractorCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByIssueDate, params=params, data=data)

@overload
def GetListByMaturityDate(api: SyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SettlementListElement]]: ...
@overload
def GetListByMaturityDate(api: SyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SettlementListElement]]: ...
@overload
def GetListByMaturityDate(api: AsyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SettlementListElement]]]: ...
@overload
def GetListByMaturityDate(api: AsyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SettlementListElement]]]: ...
def GetListByMaturityDate(api: object, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SettlementListElement]] | Awaitable[ResponseEnvelope[List[SettlementListElement]]]:
    params, data = _prepare_GetListByMaturityDate(contractorCode=contractorCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByMaturityDate, params=params, data=data)

@overload
def GetNotSettledByIssueDate(api: SyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[None]: ...
@overload
def GetNotSettledByIssueDate(api: SyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[None]: ...
@overload
def GetNotSettledByIssueDate(api: AsyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def GetNotSettledByIssueDate(api: AsyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[None]]: ...
def GetNotSettledByIssueDate(api: object, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_GetNotSettledByIssueDate(contractorCode=contractorCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetNotSettledByIssueDate, params=params, data=data)

@overload
def GetNotSettledByMaturityDate(api: SyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SettlementListElement]]: ...
@overload
def GetNotSettledByMaturityDate(api: SyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SettlementListElement]]: ...
@overload
def GetNotSettledByMaturityDate(api: AsyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SettlementListElement]]]: ...
@overload
def GetNotSettledByMaturityDate(api: AsyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[SettlementListElement]]]: ...
def GetNotSettledByMaturityDate(api: object, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[SettlementListElement]] | Awaitable[ResponseEnvelope[List[SettlementListElement]]]:
    params, data = _prepare_GetNotSettledByMaturityDate(contractorCode=contractorCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetNotSettledByMaturityDate, params=params, data=data)

@overload
def Issue(api: SyncInvokerProtocol, settlement: "SettlementIssue") -> ResponseEnvelope[Settlement]: ...
@overload
def Issue(api: SyncRequestProtocol, settlement: "SettlementIssue") -> ResponseEnvelope[Settlement]: ...
@overload
def Issue(api: AsyncInvokerProtocol, settlement: "SettlementIssue") -> Awaitable[ResponseEnvelope[Settlement]]: ...
@overload
def Issue(api: AsyncRequestProtocol, settlement: "SettlementIssue") -> Awaitable[ResponseEnvelope[Settlement]]: ...
def Issue(api: object, settlement: "SettlementIssue") -> ResponseEnvelope[Settlement] | Awaitable[ResponseEnvelope[Settlement]]:
    params, data = _prepare_Issue(settlement=settlement)
    return invoke_operation(api, OP_Issue, params=params, data=data)

__all__ = ["Get", "GetByDocument", "GetListByIssueDate", "GetListByMaturityDate", "GetNotSettledByIssueDate", "GetNotSettledByMaturityDate", "Issue"]
