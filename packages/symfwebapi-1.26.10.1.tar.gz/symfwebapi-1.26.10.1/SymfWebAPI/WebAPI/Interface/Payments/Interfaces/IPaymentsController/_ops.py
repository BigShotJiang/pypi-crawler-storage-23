from __future__ import annotations

from typing import List, Optional
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels import Payment
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels.Issue import PaymentIssue
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels.IssueKP import PaymentKPIssue
from SymfWebAPI.WebAPI.Interface.Payments.ViewModels import PaymentListElement
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

_ADAPTER_Get = TypeAdapter(Payment)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Payment]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/Payments', parser=_parse_Get)

_ADAPTER_GetList = TypeAdapter(List[PaymentListElement])

def _parse_GetList(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PaymentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetList)
OP_GetList = OperationSpec(method='GET', path='/api/Payments/Filter', parser=_parse_GetList)

_ADAPTER_GetListByContractor = TypeAdapter(List[PaymentListElement])

def _parse_GetListByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PaymentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByContractor)
OP_GetListByContractor = OperationSpec(method='GET', path='/api/Payments/Filter', parser=_parse_GetListByContractor)

_ADAPTER_GetListByPaymentRegistry = TypeAdapter(List[PaymentListElement])

def _parse_GetListByPaymentRegistry(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PaymentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByPaymentRegistry)
OP_GetListByPaymentRegistry = OperationSpec(method='GET', path='/api/Payments/Filter', parser=_parse_GetListByPaymentRegistry)

_ADAPTER_GetListByReceivingPaymentRegistry = TypeAdapter(List[PaymentListElement])

def _parse_GetListByReceivingPaymentRegistry(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[PaymentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByReceivingPaymentRegistry)
OP_GetListByReceivingPaymentRegistry = OperationSpec(method='GET', path='/api/Payments/Filter', parser=_parse_GetListByReceivingPaymentRegistry)

_ADAPTER_GetPDF = TypeAdapter(PDF)

def _parse_GetPDF(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PDF]:
    return parse_with_adapter(envelope, _ADAPTER_GetPDF)
OP_GetPDF = OperationSpec(method='GET', path='/api/Payments/PDF', parser=_parse_GetPDF)

_ADAPTER_GetDocumentSeries = TypeAdapter(List[DocumentSeries])

def _parse_GetDocumentSeries(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentSeries]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentSeries)
OP_GetDocumentSeries = OperationSpec(method='GET', path='/api/Payments/DocumentSeries', parser=_parse_GetDocumentSeries)

_ADAPTER_IssuePayment = TypeAdapter(Payment)

def _parse_IssuePayment(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Payment]:
    return parse_with_adapter(envelope, _ADAPTER_IssuePayment)
OP_IssuePayment = OperationSpec(method='POST', path='/api/Payments/Payment', parser=_parse_IssuePayment)

_ADAPTER_IssueTransferMinus = TypeAdapter(Payment)

def _parse_IssueTransferMinus(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Payment]:
    return parse_with_adapter(envelope, _ADAPTER_IssueTransferMinus)
OP_IssueTransferMinus = OperationSpec(method='POST', path='/api/Payments/TransferMinus', parser=_parse_IssueTransferMinus)

_ADAPTER_IssueTransferPlus = TypeAdapter(Payment)

def _parse_IssueTransferPlus(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Payment]:
    return parse_with_adapter(envelope, _ADAPTER_IssueTransferPlus)
OP_IssueTransferPlus = OperationSpec(method='PUT', path='/api/Payments/TransferPlus', parser=_parse_IssueTransferPlus)

def _parse_IssueKP(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_IssueKP = OperationSpec(method='POST', path='/api/Payments/IssueKP', parser=_parse_IssueKP)

_ADAPTER_GetPagedDocument = TypeAdapter(Page)

def _parse_GetPagedDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocument)
OP_GetPagedDocument = OperationSpec(method='GET', path='/api/Payments/Page', parser=_parse_GetPagedDocument)
