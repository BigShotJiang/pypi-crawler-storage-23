from __future__ import annotations

from pydantic import BaseModel

from typing import List, Optional
from datetime import datetime
from decimal import Decimal
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PaymentRegistryBase
from SymfWebAPI.WebAPI.Interface.Sales.ViewModels.DocumentIssue import DocumentIssueSettlement

class DocumentIssueSubject(BaseModel):
    Id: Optional[int]
    Code: str

class PaymentIssue(BaseModel):
    Series: str
    TypeCode: str
    Currency: str
    CurrencyRate: Decimal
    Note: str
    TotalValue: Optional[Decimal]
    PaymentDate: Optional[datetime]
    Subject: "DocumentIssueSubject"
    PaymentRegistry: "PaymentRegistryBase"
    Settlements: List["DocumentIssueSettlement"]

class SettlementIssue(BaseModel):
    MaturityDate: Optional[datetime]
    Series: str
    TypeCode: str
    Currency: str
    CurrencyRate: Decimal
    Note: str
    TotalValue: Optional[Decimal]
    PaymentDate: Optional[datetime]
    Subject: "DocumentIssueSubject"
    PaymentRegistry: "PaymentRegistryBase"
    Settlements: List["DocumentIssueSettlement"]
