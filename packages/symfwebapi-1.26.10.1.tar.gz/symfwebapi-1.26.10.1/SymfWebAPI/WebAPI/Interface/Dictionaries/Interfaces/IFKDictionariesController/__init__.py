from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Dictionaries.ViewModels import BusinessDictionary
from SymfWebAPI.WebAPI.Interface.Dictionaries.ViewModels import BusinessDictionaryElement
from SymfWebAPI.WebAPI.Interface.Dictionaries.ViewModels import ContractorPosition
from SymfWebAPI.WebAPI.Interface.Dictionaries.ViewModels import Dictionary
from SymfWebAPI.WebAPI.Interface.Dictionaries.ViewModels import DictionaryElement
from ._common import (
    _prepare_Get,
    _prepare_AddNew,
    _prepare_Update,
    _prepare_SetElementPosition,
    _prepare_SetContractorPosition,
    _prepare_GetBusiness,
    _prepare_AddNewBusiness,
    _prepare_UpdateBusiness,
)
from ._ops import (
    OP_Get,
    OP_AddNew,
    OP_Update,
    OP_SetElementPosition,
    OP_SetContractorPosition,
    OP_GetBusiness,
    OP_AddNewBusiness,
    OP_UpdateBusiness,
)

@overload
def Get(api: SyncInvokerProtocol) -> ResponseEnvelope[Dictionary]: ...
@overload
def Get(api: SyncRequestProtocol) -> ResponseEnvelope[Dictionary]: ...
@overload
def Get(api: AsyncInvokerProtocol) -> Awaitable[ResponseEnvelope[Dictionary]]: ...
@overload
def Get(api: AsyncRequestProtocol) -> Awaitable[ResponseEnvelope[Dictionary]]: ...
def Get(api: object) -> ResponseEnvelope[Dictionary] | Awaitable[ResponseEnvelope[Dictionary]]:
    params, data = _prepare_Get()
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def AddNew(api: SyncInvokerProtocol, dictionaryId: int, element: "DictionaryElement") -> ResponseEnvelope[None]: ...
@overload
def AddNew(api: SyncRequestProtocol, dictionaryId: int, element: "DictionaryElement") -> ResponseEnvelope[None]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, dictionaryId: int, element: "DictionaryElement") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, dictionaryId: int, element: "DictionaryElement") -> Awaitable[ResponseEnvelope[None]]: ...
def AddNew(api: object, dictionaryId: int, element: "DictionaryElement") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_AddNew(dictionaryId=dictionaryId, element=element)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Update(api: SyncInvokerProtocol, dictionaryId: int, element: "DictionaryElement") -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, dictionaryId: int, element: "DictionaryElement") -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, dictionaryId: int, element: "DictionaryElement") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, dictionaryId: int, element: "DictionaryElement") -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, dictionaryId: int, element: "DictionaryElement") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(dictionaryId=dictionaryId, element=element)
    return invoke_operation(api, OP_Update, params=params, data=data)

@overload
def SetElementPosition(api: SyncInvokerProtocol, id: int, position: int) -> ResponseEnvelope[None]: ...
@overload
def SetElementPosition(api: SyncRequestProtocol, id: int, position: int) -> ResponseEnvelope[None]: ...
@overload
def SetElementPosition(api: AsyncInvokerProtocol, id: int, position: int) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def SetElementPosition(api: AsyncRequestProtocol, id: int, position: int) -> Awaitable[ResponseEnvelope[None]]: ...
def SetElementPosition(api: object, id: int, position: int) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_SetElementPosition(id=id, position=position)
    return invoke_operation(api, OP_SetElementPosition, params=params, data=data)

@overload
def SetContractorPosition(api: SyncInvokerProtocol, id: int, position: int) -> ResponseEnvelope[ContractorPosition]: ...
@overload
def SetContractorPosition(api: SyncRequestProtocol, id: int, position: int) -> ResponseEnvelope[ContractorPosition]: ...
@overload
def SetContractorPosition(api: AsyncInvokerProtocol, id: int, position: int) -> Awaitable[ResponseEnvelope[ContractorPosition]]: ...
@overload
def SetContractorPosition(api: AsyncRequestProtocol, id: int, position: int) -> Awaitable[ResponseEnvelope[ContractorPosition]]: ...
def SetContractorPosition(api: object, id: int, position: int) -> ResponseEnvelope[ContractorPosition] | Awaitable[ResponseEnvelope[ContractorPosition]]:
    params, data = _prepare_SetContractorPosition(id=id, position=position)
    return invoke_operation(api, OP_SetContractorPosition, params=params, data=data)

@overload
def GetBusiness(api: SyncInvokerProtocol) -> ResponseEnvelope[BusinessDictionary]: ...
@overload
def GetBusiness(api: SyncRequestProtocol) -> ResponseEnvelope[BusinessDictionary]: ...
@overload
def GetBusiness(api: AsyncInvokerProtocol) -> Awaitable[ResponseEnvelope[BusinessDictionary]]: ...
@overload
def GetBusiness(api: AsyncRequestProtocol) -> Awaitable[ResponseEnvelope[BusinessDictionary]]: ...
def GetBusiness(api: object) -> ResponseEnvelope[BusinessDictionary] | Awaitable[ResponseEnvelope[BusinessDictionary]]:
    params, data = _prepare_GetBusiness()
    return invoke_operation(api, OP_GetBusiness, params=params, data=data)

@overload
def AddNewBusiness(api: SyncInvokerProtocol, dictionaryId: int, element: "BusinessDictionaryElement") -> ResponseEnvelope[None]: ...
@overload
def AddNewBusiness(api: SyncRequestProtocol, dictionaryId: int, element: "BusinessDictionaryElement") -> ResponseEnvelope[None]: ...
@overload
def AddNewBusiness(api: AsyncInvokerProtocol, dictionaryId: int, element: "BusinessDictionaryElement") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def AddNewBusiness(api: AsyncRequestProtocol, dictionaryId: int, element: "BusinessDictionaryElement") -> Awaitable[ResponseEnvelope[None]]: ...
def AddNewBusiness(api: object, dictionaryId: int, element: "BusinessDictionaryElement") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_AddNewBusiness(dictionaryId=dictionaryId, element=element)
    return invoke_operation(api, OP_AddNewBusiness, params=params, data=data)

@overload
def UpdateBusiness(api: SyncInvokerProtocol, dictionaryId: int, element: "BusinessDictionaryElement") -> ResponseEnvelope[None]: ...
@overload
def UpdateBusiness(api: SyncRequestProtocol, dictionaryId: int, element: "BusinessDictionaryElement") -> ResponseEnvelope[None]: ...
@overload
def UpdateBusiness(api: AsyncInvokerProtocol, dictionaryId: int, element: "BusinessDictionaryElement") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def UpdateBusiness(api: AsyncRequestProtocol, dictionaryId: int, element: "BusinessDictionaryElement") -> Awaitable[ResponseEnvelope[None]]: ...
def UpdateBusiness(api: object, dictionaryId: int, element: "BusinessDictionaryElement") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_UpdateBusiness(dictionaryId=dictionaryId, element=element)
    return invoke_operation(api, OP_UpdateBusiness, params=params, data=data)

__all__ = ["Get", "AddNew", "Update", "SetElementPosition", "SetContractorPosition", "GetBusiness", "AddNewBusiness", "UpdateBusiness"]
