from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/FKDictionaries')
def _prepare_Get() -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = None
    return params or None, data

_REQUEST_AddNew = ('POST', '/api/FKDictionaries/Create')
def _prepare_AddNew(*, dictionaryId, element) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dictionaryId"] = dictionaryId
    data = element.model_dump_json(exclude_unset=True) if element is not None else None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/FKDictionaries/Update')
def _prepare_Update(*, dictionaryId, element) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dictionaryId"] = dictionaryId
    data = element.model_dump_json(exclude_unset=True) if element is not None else None
    return params or None, data

_REQUEST_SetElementPosition = ('PATCH', '/api/FKDictionaries/SetElementPosition')
def _prepare_SetElementPosition(*, id, position) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    params["position"] = position
    data = None
    return params or None, data

_REQUEST_SetContractorPosition = ('PATCH', '/api/FKDictionaries/SetContractorPosition')
def _prepare_SetContractorPosition(*, id, position) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    params["position"] = position
    data = None
    return params or None, data

_REQUEST_GetBusiness = ('GET', '/api/FKDictionaries/Business')
def _prepare_GetBusiness() -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = None
    return params or None, data

_REQUEST_AddNewBusiness = ('POST', '/api/FKDictionaries/CreateBusiness')
def _prepare_AddNewBusiness(*, dictionaryId, element) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dictionaryId"] = dictionaryId
    data = element.model_dump_json(exclude_unset=True) if element is not None else None
    return params or None, data

_REQUEST_UpdateBusiness = ('PUT', '/api/FKDictionaries/UpdateBusiness')
def _prepare_UpdateBusiness(*, dictionaryId, element) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["dictionaryId"] = dictionaryId
    data = element.model_dump_json(exclude_unset=True) if element is not None else None
    return params or None, data
