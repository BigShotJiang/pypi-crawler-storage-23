from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Dictionaries.ViewModels import BusinessDictionary
from SymfWebAPI.WebAPI.Interface.Dictionaries.ViewModels import BusinessDictionaryElement
from SymfWebAPI.WebAPI.Interface.Dictionaries.ViewModels import ContractorPosition
from SymfWebAPI.WebAPI.Interface.Dictionaries.ViewModels import Dictionary
from SymfWebAPI.WebAPI.Interface.Dictionaries.ViewModels import DictionaryElement

_ADAPTER_Get = TypeAdapter(Dictionary)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Dictionary]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/FKDictionaries', parser=_parse_Get)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_AddNew = OperationSpec(method='POST', path='/api/FKDictionaries/Create', parser=_parse_AddNew)

def _parse_Update(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Update = OperationSpec(method='PUT', path='/api/FKDictionaries/Update', parser=_parse_Update)

def _parse_SetElementPosition(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_SetElementPosition = OperationSpec(method='PATCH', path='/api/FKDictionaries/SetElementPosition', parser=_parse_SetElementPosition)

_ADAPTER_SetContractorPosition = TypeAdapter(ContractorPosition)

def _parse_SetContractorPosition(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[ContractorPosition]:
    return parse_with_adapter(envelope, _ADAPTER_SetContractorPosition)
OP_SetContractorPosition = OperationSpec(method='PATCH', path='/api/FKDictionaries/SetContractorPosition', parser=_parse_SetContractorPosition)

_ADAPTER_GetBusiness = TypeAdapter(BusinessDictionary)

def _parse_GetBusiness(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[BusinessDictionary]:
    return parse_with_adapter(envelope, _ADAPTER_GetBusiness)
OP_GetBusiness = OperationSpec(method='GET', path='/api/FKDictionaries/Business', parser=_parse_GetBusiness)

def _parse_AddNewBusiness(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_AddNewBusiness = OperationSpec(method='POST', path='/api/FKDictionaries/CreateBusiness', parser=_parse_AddNewBusiness)

def _parse_UpdateBusiness(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_UpdateBusiness = OperationSpec(method='PUT', path='/api/FKDictionaries/UpdateBusiness', parser=_parse_UpdateBusiness)
