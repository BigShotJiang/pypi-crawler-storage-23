from __future__ import annotations

import warnings

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.errors import SessionManagementBypassWarning
from ._common import (
    _prepare_OpenNewSession,
)
from ._ops import (
    OP_OpenNewSession,
)

@overload
def OpenNewSession(api: SyncInvokerProtocol, deviceName: str) -> ResponseEnvelope[None]: ...
@overload
def OpenNewSession(api: SyncRequestProtocol, deviceName: str) -> ResponseEnvelope[None]: ...
@overload
def OpenNewSession(api: AsyncInvokerProtocol, deviceName: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def OpenNewSession(api: AsyncRequestProtocol, deviceName: str) -> Awaitable[ResponseEnvelope[None]]: ...
def OpenNewSession(api: object, deviceName: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    warnings.warn(
        "Manual call to session endpoint bypasses SessionManager; " "prefer api.open()/api.close() unless you intentionally manage sessions manually.",
        SessionManagementBypassWarning,
        stacklevel=2,
    )
    params, data = _prepare_OpenNewSession(deviceName=deviceName)
    return invoke_operation(api, OP_OpenNewSession, params=params, data=data)

__all__ = ["OpenNewSession"]
