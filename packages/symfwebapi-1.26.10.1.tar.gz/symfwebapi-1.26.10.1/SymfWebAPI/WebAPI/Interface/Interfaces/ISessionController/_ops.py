from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope

def _parse_OpenNewSession(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_OpenNewSession = OperationSpec(method='GET', path='/api/Sessions/OpenNewSession', parser=_parse_OpenNewSession)
