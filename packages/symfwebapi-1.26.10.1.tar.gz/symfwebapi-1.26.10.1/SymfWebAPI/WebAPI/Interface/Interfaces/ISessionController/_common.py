from __future__ import annotations

from typing import Any

_REQUEST_OpenNewSession = ('GET', '/api/Sessions/OpenNewSession')
def _prepare_OpenNewSession(*, deviceName) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["deviceName"] = deviceName
    data = None
    return params or None, data
