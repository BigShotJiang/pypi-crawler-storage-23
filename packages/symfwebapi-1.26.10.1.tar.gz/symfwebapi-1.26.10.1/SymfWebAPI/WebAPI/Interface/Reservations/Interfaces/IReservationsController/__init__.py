from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Reservations.ViewModels import AdvancedReservationNew
from SymfWebAPI.WebAPI.Interface.Reservations.ViewModels import Reservation
from SymfWebAPI.WebAPI.Interface.Reservations.ViewModels import ReservationListElement
from SymfWebAPI.WebAPI.Interface.Reservations.ViewModels import ReservationNew
from ._common import (
    _prepare_Get,
    _prepare_GetListByContractor,
    _prepare_GetListByProduct,
    _prepare_AddNew,
    _prepare_AdvancedAddNew,
    _prepare_Delete,
    _prepare_AdvancedDelete,
)
from ._ops import (
    OP_Get,
    OP_GetListByContractor,
    OP_GetListByProduct,
    OP_AddNew,
    OP_AdvancedAddNew,
    OP_Delete,
    OP_AdvancedDelete,
)

@overload
def Get(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[Reservation]: ...
@overload
def Get(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[Reservation]: ...
@overload
def Get(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[Reservation]]: ...
@overload
def Get(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[Reservation]]: ...
def Get(api: object, id: int) -> ResponseEnvelope[Reservation] | Awaitable[ResponseEnvelope[Reservation]]:
    params, data = _prepare_Get(id=id)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetListByContractor(api: SyncInvokerProtocol, contractorCode: str) -> ResponseEnvelope[List[ReservationListElement]]: ...
@overload
def GetListByContractor(api: SyncRequestProtocol, contractorCode: str) -> ResponseEnvelope[List[ReservationListElement]]: ...
@overload
def GetListByContractor(api: AsyncInvokerProtocol, contractorCode: str) -> Awaitable[ResponseEnvelope[List[ReservationListElement]]]: ...
@overload
def GetListByContractor(api: AsyncRequestProtocol, contractorCode: str) -> Awaitable[ResponseEnvelope[List[ReservationListElement]]]: ...
def GetListByContractor(api: object, contractorCode: str) -> ResponseEnvelope[List[ReservationListElement]] | Awaitable[ResponseEnvelope[List[ReservationListElement]]]:
    params, data = _prepare_GetListByContractor(contractorCode=contractorCode)
    return invoke_operation(api, OP_GetListByContractor, params=params, data=data)

@overload
def GetListByProduct(api: SyncInvokerProtocol, productCode: str) -> ResponseEnvelope[List[ReservationListElement]]: ...
@overload
def GetListByProduct(api: SyncRequestProtocol, productCode: str) -> ResponseEnvelope[List[ReservationListElement]]: ...
@overload
def GetListByProduct(api: AsyncInvokerProtocol, productCode: str) -> Awaitable[ResponseEnvelope[List[ReservationListElement]]]: ...
@overload
def GetListByProduct(api: AsyncRequestProtocol, productCode: str) -> Awaitable[ResponseEnvelope[List[ReservationListElement]]]: ...
def GetListByProduct(api: object, productCode: str) -> ResponseEnvelope[List[ReservationListElement]] | Awaitable[ResponseEnvelope[List[ReservationListElement]]]:
    params, data = _prepare_GetListByProduct(productCode=productCode)
    return invoke_operation(api, OP_GetListByProduct, params=params, data=data)

@overload
def AddNew(api: SyncInvokerProtocol, reservation: "ReservationNew") -> ResponseEnvelope[Reservation]: ...
@overload
def AddNew(api: SyncRequestProtocol, reservation: "ReservationNew") -> ResponseEnvelope[Reservation]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, reservation: "ReservationNew") -> Awaitable[ResponseEnvelope[Reservation]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, reservation: "ReservationNew") -> Awaitable[ResponseEnvelope[Reservation]]: ...
def AddNew(api: object, reservation: "ReservationNew") -> ResponseEnvelope[Reservation] | Awaitable[ResponseEnvelope[Reservation]]:
    params, data = _prepare_AddNew(reservation=reservation)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def AdvancedAddNew(api: SyncInvokerProtocol, reservation: "AdvancedReservationNew") -> ResponseEnvelope[Reservation]: ...
@overload
def AdvancedAddNew(api: SyncRequestProtocol, reservation: "AdvancedReservationNew") -> ResponseEnvelope[Reservation]: ...
@overload
def AdvancedAddNew(api: AsyncInvokerProtocol, reservation: "AdvancedReservationNew") -> Awaitable[ResponseEnvelope[Reservation]]: ...
@overload
def AdvancedAddNew(api: AsyncRequestProtocol, reservation: "AdvancedReservationNew") -> Awaitable[ResponseEnvelope[Reservation]]: ...
def AdvancedAddNew(api: object, reservation: "AdvancedReservationNew") -> ResponseEnvelope[Reservation] | Awaitable[ResponseEnvelope[Reservation]]:
    params, data = _prepare_AdvancedAddNew(reservation=reservation)
    return invoke_operation(api, OP_AdvancedAddNew, params=params, data=data)

@overload
def Delete(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[None]: ...
@overload
def Delete(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[None]: ...
@overload
def Delete(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Delete(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[None]]: ...
def Delete(api: object, id: int) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Delete(id=id)
    return invoke_operation(api, OP_Delete, params=params, data=data)

@overload
def AdvancedDelete(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[None]: ...
@overload
def AdvancedDelete(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[None]: ...
@overload
def AdvancedDelete(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def AdvancedDelete(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[None]]: ...
def AdvancedDelete(api: object, id: int) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_AdvancedDelete(id=id)
    return invoke_operation(api, OP_AdvancedDelete, params=params, data=data)

__all__ = ["Get", "GetListByContractor", "GetListByProduct", "AddNew", "AdvancedAddNew", "Delete", "AdvancedDelete"]
