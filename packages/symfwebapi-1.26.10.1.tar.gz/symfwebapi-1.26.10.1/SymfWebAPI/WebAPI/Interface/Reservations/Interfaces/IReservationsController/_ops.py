from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Reservations.ViewModels import AdvancedReservationNew
from SymfWebAPI.WebAPI.Interface.Reservations.ViewModels import Reservation
from SymfWebAPI.WebAPI.Interface.Reservations.ViewModels import ReservationListElement
from SymfWebAPI.WebAPI.Interface.Reservations.ViewModels import ReservationNew

_ADAPTER_Get = TypeAdapter(Reservation)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Reservation]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/Reservations', parser=_parse_Get)

_ADAPTER_GetListByContractor = TypeAdapter(List[ReservationListElement])

def _parse_GetListByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ReservationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByContractor)
OP_GetListByContractor = OperationSpec(method='GET', path='/api/Reservations/Filter', parser=_parse_GetListByContractor)

_ADAPTER_GetListByProduct = TypeAdapter(List[ReservationListElement])

def _parse_GetListByProduct(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ReservationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByProduct)
OP_GetListByProduct = OperationSpec(method='GET', path='/api/Reservations/Filter', parser=_parse_GetListByProduct)

_ADAPTER_AddNew = TypeAdapter(Reservation)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Reservation]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/Reservations/Create', parser=_parse_AddNew)

_ADAPTER_AdvancedAddNew = TypeAdapter(Reservation)

def _parse_AdvancedAddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Reservation]:
    return parse_with_adapter(envelope, _ADAPTER_AdvancedAddNew)
OP_AdvancedAddNew = OperationSpec(method='POST', path='/api/Reservations/AdvancedCreate', parser=_parse_AdvancedAddNew)

def _parse_Delete(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Delete = OperationSpec(method='DELETE', path='/api/Reservations/Delete', parser=_parse_Delete)

def _parse_AdvancedDelete(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_AdvancedDelete = OperationSpec(method='DELETE', path='/api/Reservations/AdvancedDelete', parser=_parse_AdvancedDelete)
