from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/Reservations')
def _prepare_Get(*, id) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    data = None
    return params or None, data

_REQUEST_GetListByContractor = ('GET', '/api/Reservations/Filter')
def _prepare_GetListByContractor(*, contractorCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = None
    return params or None, data

_REQUEST_GetListByProduct = ('GET', '/api/Reservations/Filter')
def _prepare_GetListByProduct(*, productCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["productCode"] = productCode
    data = None
    return params or None, data

_REQUEST_AddNew = ('POST', '/api/Reservations/Create')
def _prepare_AddNew(*, reservation) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = reservation.model_dump_json(exclude_unset=True) if reservation is not None else None
    return params or None, data

_REQUEST_AdvancedAddNew = ('POST', '/api/Reservations/AdvancedCreate')
def _prepare_AdvancedAddNew(*, reservation) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = reservation.model_dump_json(exclude_unset=True) if reservation is not None else None
    return params or None, data

_REQUEST_Delete = ('DELETE', '/api/Reservations/Delete')
def _prepare_Delete(*, id) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    data = None
    return params or None, data

_REQUEST_AdvancedDelete = ('DELETE', '/api/Reservations/AdvancedDelete')
def _prepare_AdvancedDelete(*, id) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    data = None
    return params or None, data
