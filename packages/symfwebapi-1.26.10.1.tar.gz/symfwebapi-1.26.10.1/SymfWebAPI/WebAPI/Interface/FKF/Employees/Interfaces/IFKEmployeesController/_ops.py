from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Employees.ViewModels import Employee
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

_ADAPTER_GetById = TypeAdapter(Employee)

def _parse_GetById(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Employee]:
    return parse_with_adapter(envelope, _ADAPTER_GetById)
OP_GetById = OperationSpec(method='GET', path='/api/FKEmployees', parser=_parse_GetById)

_ADAPTER_GetByPosition = TypeAdapter(Employee)

def _parse_GetByPosition(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Employee]:
    return parse_with_adapter(envelope, _ADAPTER_GetByPosition)
OP_GetByPosition = OperationSpec(method='GET', path='/api/FKEmployees', parser=_parse_GetByPosition)

_ADAPTER_GetByCode = TypeAdapter(Employee)

def _parse_GetByCode(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Employee]:
    return parse_with_adapter(envelope, _ADAPTER_GetByCode)
OP_GetByCode = OperationSpec(method='GET', path='/api/FKEmployees', parser=_parse_GetByCode)

_ADAPTER_AddNew = TypeAdapter(Employee)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Employee]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/FKEmployees/Create', parser=_parse_AddNew)

def _parse_Update(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Update = OperationSpec(method='PUT', path='/api/FKEmployees/Update', parser=_parse_Update)

_ADAPTER_GetPagedDocument = TypeAdapter(Page)

def _parse_GetPagedDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocument)
OP_GetPagedDocument = OperationSpec(method='GET', path='/api/FKEmployees/Page', parser=_parse_GetPagedDocument)
