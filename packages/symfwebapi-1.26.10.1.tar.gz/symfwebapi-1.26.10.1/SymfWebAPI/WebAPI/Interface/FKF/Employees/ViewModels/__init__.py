from __future__ import annotations

from pydantic import BaseModel

from typing import Optional

class Employee(BaseModel):
    Id: Optional[int]
    Position: Optional[int]
    Active: bool
    Code: str
    Name: str
    SecondName: str
    Surname: str
    NIP: str
    Pesel: str
    Phone: str
    Address: "EmployeeAddress"
    BankInfo: "EmployeeBankInfo"

class EmployeeAddress(BaseModel):
    City: str
    Street: str
    HouseNo: str
    ApartmentNo: str
    PostCode: str

class EmployeeBankInfo(BaseModel):
    AccountNumber: str
    BankName: str
