from __future__ import annotations

from typing import Any

_REQUEST_GetById = ('GET', '/api/FKEmployees')
def _prepare_GetById(*, id) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    data = None
    return params or None, data

_REQUEST_GetByPosition = ('GET', '/api/FKEmployees')
def _prepare_GetByPosition(*, position) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["position"] = position
    data = None
    return params or None, data

_REQUEST_GetByCode = ('GET', '/api/FKEmployees')
def _prepare_GetByCode(*, code) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["code"] = code
    data = None
    return params or None, data

_REQUEST_AddNew = ('POST', '/api/FKEmployees/Create')
def _prepare_AddNew(*, employee) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = employee.model_dump_json(exclude_unset=True) if employee is not None else None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/FKEmployees/Update')
def _prepare_Update(*, employee) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = employee.model_dump_json(exclude_unset=True) if employee is not None else None
    return params or None, data

_REQUEST_GetPagedDocument = ('GET', '/api/FKEmployees/Page')
def _prepare_GetPagedDocument(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data
