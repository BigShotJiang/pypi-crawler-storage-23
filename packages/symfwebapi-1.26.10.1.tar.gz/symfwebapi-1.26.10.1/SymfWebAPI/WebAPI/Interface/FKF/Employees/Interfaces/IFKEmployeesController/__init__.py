from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Employees.ViewModels import Employee
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType
from ._common import (
    _prepare_GetById,
    _prepare_GetByPosition,
    _prepare_GetByCode,
    _prepare_AddNew,
    _prepare_Update,
    _prepare_GetPagedDocument,
)
from ._ops import (
    OP_GetById,
    OP_GetByPosition,
    OP_GetByCode,
    OP_AddNew,
    OP_Update,
    OP_GetPagedDocument,
)

@overload
def GetById(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[Employee]: ...
@overload
def GetById(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[Employee]: ...
@overload
def GetById(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[Employee]]: ...
@overload
def GetById(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[Employee]]: ...
def GetById(api: object, id: int) -> ResponseEnvelope[Employee] | Awaitable[ResponseEnvelope[Employee]]:
    params, data = _prepare_GetById(id=id)
    return invoke_operation(api, OP_GetById, params=params, data=data)

@overload
def GetByPosition(api: SyncInvokerProtocol, position: int) -> ResponseEnvelope[Employee]: ...
@overload
def GetByPosition(api: SyncRequestProtocol, position: int) -> ResponseEnvelope[Employee]: ...
@overload
def GetByPosition(api: AsyncInvokerProtocol, position: int) -> Awaitable[ResponseEnvelope[Employee]]: ...
@overload
def GetByPosition(api: AsyncRequestProtocol, position: int) -> Awaitable[ResponseEnvelope[Employee]]: ...
def GetByPosition(api: object, position: int) -> ResponseEnvelope[Employee] | Awaitable[ResponseEnvelope[Employee]]:
    params, data = _prepare_GetByPosition(position=position)
    return invoke_operation(api, OP_GetByPosition, params=params, data=data)

@overload
def GetByCode(api: SyncInvokerProtocol, code: str) -> ResponseEnvelope[Employee]: ...
@overload
def GetByCode(api: SyncRequestProtocol, code: str) -> ResponseEnvelope[Employee]: ...
@overload
def GetByCode(api: AsyncInvokerProtocol, code: str) -> Awaitable[ResponseEnvelope[Employee]]: ...
@overload
def GetByCode(api: AsyncRequestProtocol, code: str) -> Awaitable[ResponseEnvelope[Employee]]: ...
def GetByCode(api: object, code: str) -> ResponseEnvelope[Employee] | Awaitable[ResponseEnvelope[Employee]]:
    params, data = _prepare_GetByCode(code=code)
    return invoke_operation(api, OP_GetByCode, params=params, data=data)

@overload
def AddNew(api: SyncInvokerProtocol, employee: "Employee") -> ResponseEnvelope[Employee]: ...
@overload
def AddNew(api: SyncRequestProtocol, employee: "Employee") -> ResponseEnvelope[Employee]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, employee: "Employee") -> Awaitable[ResponseEnvelope[Employee]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, employee: "Employee") -> Awaitable[ResponseEnvelope[Employee]]: ...
def AddNew(api: object, employee: "Employee") -> ResponseEnvelope[Employee] | Awaitable[ResponseEnvelope[Employee]]:
    params, data = _prepare_AddNew(employee=employee)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Update(api: SyncInvokerProtocol, employee: "Employee") -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, employee: "Employee") -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, employee: "Employee") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, employee: "Employee") -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, employee: "Employee") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(employee=employee)
    return invoke_operation(api, OP_Update, params=params, data=data)

@overload
def GetPagedDocument(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocument(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocument(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocument(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocument, params=params, data=data)

__all__ = ["GetById", "GetByPosition", "GetByCode", "AddNew", "Update", "GetPagedDocument"]
