from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension
from ._common import (
    _prepare_GetById,
    _prepare_GetByPosition,
    _prepare_GetByCode,
    _prepare_UpdateById,
    _prepare_UpdateByPosition,
    _prepare_UpdateByCode,
)
from ._ops import (
    OP_GetById,
    OP_GetByPosition,
    OP_GetByCode,
    OP_UpdateById,
    OP_UpdateByPosition,
    OP_UpdateByCode,
)

@overload
def GetById(api: SyncInvokerProtocol, contractorId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetById(api: SyncRequestProtocol, contractorId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetById(api: AsyncInvokerProtocol, contractorId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def GetById(api: AsyncRequestProtocol, contractorId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def GetById(api: object, contractorId: int) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_GetById(contractorId=contractorId)
    return invoke_operation(api, OP_GetById, params=params, data=data)

@overload
def GetByPosition(api: SyncInvokerProtocol, contractorPosition: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetByPosition(api: SyncRequestProtocol, contractorPosition: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetByPosition(api: AsyncInvokerProtocol, contractorPosition: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def GetByPosition(api: AsyncRequestProtocol, contractorPosition: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def GetByPosition(api: object, contractorPosition: int) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_GetByPosition(contractorPosition=contractorPosition)
    return invoke_operation(api, OP_GetByPosition, params=params, data=data)

@overload
def GetByCode(api: SyncInvokerProtocol, contractorCode: str) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetByCode(api: SyncRequestProtocol, contractorCode: str) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetByCode(api: AsyncInvokerProtocol, contractorCode: str) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def GetByCode(api: AsyncRequestProtocol, contractorCode: str) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def GetByCode(api: object, contractorCode: str) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_GetByCode(contractorCode=contractorCode)
    return invoke_operation(api, OP_GetByCode, params=params, data=data)

@overload
def UpdateById(api: SyncInvokerProtocol, contractorId: int, contractorDimensions: List["Dimension"]) -> ResponseEnvelope[None]: ...
@overload
def UpdateById(api: SyncRequestProtocol, contractorId: int, contractorDimensions: List["Dimension"]) -> ResponseEnvelope[None]: ...
@overload
def UpdateById(api: AsyncInvokerProtocol, contractorId: int, contractorDimensions: List["Dimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def UpdateById(api: AsyncRequestProtocol, contractorId: int, contractorDimensions: List["Dimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
def UpdateById(api: object, contractorId: int, contractorDimensions: List["Dimension"]) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_UpdateById(contractorId=contractorId, contractorDimensions=contractorDimensions)
    return invoke_operation(api, OP_UpdateById, params=params, data=data)

@overload
def UpdateByPosition(api: SyncInvokerProtocol, contractorPosition: int, contractorDimensions: List["Dimension"]) -> ResponseEnvelope[None]: ...
@overload
def UpdateByPosition(api: SyncRequestProtocol, contractorPosition: int, contractorDimensions: List["Dimension"]) -> ResponseEnvelope[None]: ...
@overload
def UpdateByPosition(api: AsyncInvokerProtocol, contractorPosition: int, contractorDimensions: List["Dimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def UpdateByPosition(api: AsyncRequestProtocol, contractorPosition: int, contractorDimensions: List["Dimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
def UpdateByPosition(api: object, contractorPosition: int, contractorDimensions: List["Dimension"]) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_UpdateByPosition(contractorPosition=contractorPosition, contractorDimensions=contractorDimensions)
    return invoke_operation(api, OP_UpdateByPosition, params=params, data=data)

@overload
def UpdateByCode(api: SyncInvokerProtocol, contractorCode: str, contractorDimensions: List["Dimension"]) -> ResponseEnvelope[None]: ...
@overload
def UpdateByCode(api: SyncRequestProtocol, contractorCode: str, contractorDimensions: List["Dimension"]) -> ResponseEnvelope[None]: ...
@overload
def UpdateByCode(api: AsyncInvokerProtocol, contractorCode: str, contractorDimensions: List["Dimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def UpdateByCode(api: AsyncRequestProtocol, contractorCode: str, contractorDimensions: List["Dimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
def UpdateByCode(api: object, contractorCode: str, contractorDimensions: List["Dimension"]) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_UpdateByCode(contractorCode=contractorCode, contractorDimensions=contractorDimensions)
    return invoke_operation(api, OP_UpdateByCode, params=params, data=data)

__all__ = ["GetById", "GetByPosition", "GetByCode", "UpdateById", "UpdateByPosition", "UpdateByCode"]
