from __future__ import annotations

from pydantic import BaseModel

import importlib
from typing import TYPE_CHECKING
from typing import Optional
from SymfWebAPI.WebAPI.Interface.Enums import enumContractorType
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels.CriteriaFilter import (
    IntCriteriaFilter,
    StringCriteriaFilter,
)

class ContractorAddress(BaseModel):
    Country: str
    City: str
    Province: str
    Street: str
    HouseNo: str
    ApartmentNo: str
    PostCode: str

class ContractorBankInfo(BaseModel):
    AccountNumber: str
    BankName: str

class ContractorContact(BaseModel):
    Name: str
    Surname: str
    Phone1: str
    Phone2: str
    Fax: str
    Telex: str
    Email: str
    WWW: str
    Facebook: str

class ContractorCriteriaFilter(BaseModel):
    Code: "StringCriteriaFilter"
    Name: "StringCriteriaFilter"
    NIP: "StringCriteriaFilter"
    City: "StringCriteriaFilter"
    Province: "StringCriteriaFilter"
    Marker: "IntCriteriaFilter"
    Active: Optional[bool]
    Country: "StringCriteriaFilter"
    EmailDomain: "StringCriteriaFilter"
    KindId: Optional[int]
    CatalogId: Optional[int]

class ContractorListElement(BaseModel):
    Id: int
    Position: int
    Code: str
    Name: str
    Type: Optional["enumContractorType"]
    NIP: str
    Active: bool
    Place: str
    PostCode: str

_VERSIONED_EXPORTS = {
    'Contractor': 'V2026_1',
}

def __getattr__(name: str):
    child_name = _VERSIONED_EXPORTS.get(name)
    if child_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module = importlib.import_module(f".{child_name}", __name__)
    value = getattr(module, name)
    globals()[name] = value
    return value

def __dir__():
    return sorted(set(_VERSIONED_EXPORTS) | {n for n in globals() if not n.startswith('_')})

if TYPE_CHECKING:
    from .V2026_1 import Contractor
