from __future__ import annotations

from typing import Any

import json

_REQUEST_GetById = ('GET', '/api/FKContractorDimensions')
def _prepare_GetById(*, contractorId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorId"] = contractorId
    data = None
    return params or None, data

_REQUEST_GetByPosition = ('GET', '/api/FKContractorDimensions')
def _prepare_GetByPosition(*, contractorPosition) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    data = None
    return params or None, data

_REQUEST_GetByCode = ('GET', '/api/FKContractorDimensions')
def _prepare_GetByCode(*, contractorCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = None
    return params or None, data

_REQUEST_UpdateById = ('PUT', '/api/FKContractorDimensions/UpdateList')
def _prepare_UpdateById(*, contractorId, contractorDimensions) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorId"] = contractorId
    data = json.dumps(contractorDimensions) if contractorDimensions is not None else None
    return params or None, data

_REQUEST_UpdateByPosition = ('PUT', '/api/FKContractorDimensions/UpdateList')
def _prepare_UpdateByPosition(*, contractorPosition, contractorDimensions) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    data = json.dumps(contractorDimensions) if contractorDimensions is not None else None
    return params or None, data

_REQUEST_UpdateByCode = ('PUT', '/api/FKContractorDimensions/UpdateList')
def _prepare_UpdateByCode(*, contractorCode, contractorDimensions) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = json.dumps(contractorDimensions) if contractorDimensions is not None else None
    return params or None, data
