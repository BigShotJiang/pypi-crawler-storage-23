from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension

_ADAPTER_GetById = TypeAdapter(List[Dimension])

def _parse_GetById(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Dimension]]:
    return parse_with_adapter(envelope, _ADAPTER_GetById)
OP_GetById = OperationSpec(method='GET', path='/api/v2/FKContractorDimensions', parser=_parse_GetById)

_ADAPTER_GetByPosition = TypeAdapter(List[Dimension])

def _parse_GetByPosition(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Dimension]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByPosition)
OP_GetByPosition = OperationSpec(method='GET', path='/api/v2/FKContractorDimensions', parser=_parse_GetByPosition)

_ADAPTER_GetByCode = TypeAdapter(List[Dimension])

def _parse_GetByCode(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Dimension]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByCode)
OP_GetByCode = OperationSpec(method='GET', path='/api/v2/FKContractorDimensions', parser=_parse_GetByCode)
