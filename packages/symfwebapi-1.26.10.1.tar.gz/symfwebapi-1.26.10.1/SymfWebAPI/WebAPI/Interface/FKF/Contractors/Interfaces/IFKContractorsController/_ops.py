from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels.V2026_1 import Contractor
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels import ContractorCriteriaFilter
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels import ContractorListElement
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import FilterCriteria
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

_ADAPTER_GetById = TypeAdapter(Contractor)

def _parse_GetById(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Contractor]:
    return parse_with_adapter(envelope, _ADAPTER_GetById)
OP_GetById = OperationSpec(method='GET', path='/api/FKContractors', parser=_parse_GetById)

_ADAPTER_GetByPosition = TypeAdapter(Contractor)

def _parse_GetByPosition(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Contractor]:
    return parse_with_adapter(envelope, _ADAPTER_GetByPosition)
OP_GetByPosition = OperationSpec(method='GET', path='/api/FKContractors', parser=_parse_GetByPosition)

_ADAPTER_GetByCode = TypeAdapter(Contractor)

def _parse_GetByCode(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Contractor]:
    return parse_with_adapter(envelope, _ADAPTER_GetByCode)
OP_GetByCode = OperationSpec(method='GET', path='/api/FKContractors', parser=_parse_GetByCode)

_ADAPTER_GetByNIP = TypeAdapter(List[Contractor])

def _parse_GetByNIP(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Contractor]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByNIP)
OP_GetByNIP = OperationSpec(method='GET', path='/api/FKContractors', parser=_parse_GetByNIP)

_ADAPTER_GetByPesel = TypeAdapter(List[Contractor])

def _parse_GetByPesel(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Contractor]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByPesel)
OP_GetByPesel = OperationSpec(method='GET', path='/api/FKContractors', parser=_parse_GetByPesel)

_ADAPTER_Filter = TypeAdapter(List[ContractorListElement])

def _parse_Filter(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ContractorListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_Filter)
OP_Filter = OperationSpec(method='PATCH', path='/api/FKContractors/Filter', parser=_parse_Filter)

_ADAPTER_AddNew = TypeAdapter(Contractor)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Contractor]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/FKContractors/Create', parser=_parse_AddNew)

def _parse_Update(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Update = OperationSpec(method='PUT', path='/api/FKContractors/Update', parser=_parse_Update)

_ADAPTER_GetPagedDocument = TypeAdapter(Page)

def _parse_GetPagedDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocument)
OP_GetPagedDocument = OperationSpec(method='GET', path='/api/FKContractors/Page', parser=_parse_GetPagedDocument)

_ADAPTER_FilterSql = TypeAdapter(List[ContractorListElement])

def _parse_FilterSql(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[ContractorListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_FilterSql)
OP_FilterSql = OperationSpec(method='PATCH', path='/api/FKContractors/FilterSql', parser=_parse_FilterSql)
