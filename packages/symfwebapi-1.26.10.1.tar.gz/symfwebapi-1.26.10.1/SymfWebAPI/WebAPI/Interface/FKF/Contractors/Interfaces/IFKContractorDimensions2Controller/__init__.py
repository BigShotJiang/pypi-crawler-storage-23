from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension
from ._common import (
    _prepare_GetById,
    _prepare_GetByPosition,
    _prepare_GetByCode,
)
from ._ops import (
    OP_GetById,
    OP_GetByPosition,
    OP_GetByCode,
)

@overload
def GetById(api: SyncInvokerProtocol, contractorId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetById(api: SyncRequestProtocol, contractorId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetById(api: AsyncInvokerProtocol, contractorId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def GetById(api: AsyncRequestProtocol, contractorId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def GetById(api: object, contractorId: int) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_GetById(contractorId=contractorId)
    return invoke_operation(api, OP_GetById, params=params, data=data)

@overload
def GetByPosition(api: SyncInvokerProtocol, contractorPosition: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetByPosition(api: SyncRequestProtocol, contractorPosition: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetByPosition(api: AsyncInvokerProtocol, contractorPosition: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def GetByPosition(api: AsyncRequestProtocol, contractorPosition: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def GetByPosition(api: object, contractorPosition: int) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_GetByPosition(contractorPosition=contractorPosition)
    return invoke_operation(api, OP_GetByPosition, params=params, data=data)

@overload
def GetByCode(api: SyncInvokerProtocol, contractorCode: str) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetByCode(api: SyncRequestProtocol, contractorCode: str) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetByCode(api: AsyncInvokerProtocol, contractorCode: str) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def GetByCode(api: AsyncRequestProtocol, contractorCode: str) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def GetByCode(api: object, contractorCode: str) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_GetByCode(contractorCode=contractorCode)
    return invoke_operation(api, OP_GetByCode, params=params, data=data)

__all__ = ["GetById", "GetByPosition", "GetByCode"]
