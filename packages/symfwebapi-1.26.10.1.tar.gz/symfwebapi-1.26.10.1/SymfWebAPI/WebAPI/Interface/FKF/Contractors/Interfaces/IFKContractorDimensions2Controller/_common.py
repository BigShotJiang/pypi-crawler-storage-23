from __future__ import annotations

from typing import Any

_REQUEST_GetById = ('GET', '/api/v2/FKContractorDimensions')
def _prepare_GetById(*, contractorId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorId"] = contractorId
    data = None
    return params or None, data

_REQUEST_GetByPosition = ('GET', '/api/v2/FKContractorDimensions')
def _prepare_GetByPosition(*, contractorPosition) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    data = None
    return params or None, data

_REQUEST_GetByCode = ('GET', '/api/v2/FKContractorDimensions')
def _prepare_GetByCode(*, contractorCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorCode"] = contractorCode
    data = None
    return params or None, data
