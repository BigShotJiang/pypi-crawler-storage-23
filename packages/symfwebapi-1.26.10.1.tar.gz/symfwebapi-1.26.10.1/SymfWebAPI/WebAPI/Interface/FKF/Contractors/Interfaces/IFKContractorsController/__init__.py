from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels.V2026_1 import Contractor
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels import ContractorCriteriaFilter
from SymfWebAPI.WebAPI.Interface.FKF.Contractors.ViewModels import ContractorListElement
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import FilterCriteria
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType
from ._common import (
    _prepare_GetById,
    _prepare_GetByPosition,
    _prepare_GetByCode,
    _prepare_GetByNIP,
    _prepare_GetByPesel,
    _prepare_Filter,
    _prepare_AddNew,
    _prepare_Update,
    _prepare_GetPagedDocument,
    _prepare_FilterSql,
)
from ._ops import (
    OP_GetById,
    OP_GetByPosition,
    OP_GetByCode,
    OP_GetByNIP,
    OP_GetByPesel,
    OP_Filter,
    OP_AddNew,
    OP_Update,
    OP_GetPagedDocument,
    OP_FilterSql,
)

@overload
def GetById(api: SyncInvokerProtocol, id: int) -> ResponseEnvelope[Contractor]: ...
@overload
def GetById(api: SyncRequestProtocol, id: int) -> ResponseEnvelope[Contractor]: ...
@overload
def GetById(api: AsyncInvokerProtocol, id: int) -> Awaitable[ResponseEnvelope[Contractor]]: ...
@overload
def GetById(api: AsyncRequestProtocol, id: int) -> Awaitable[ResponseEnvelope[Contractor]]: ...
def GetById(api: object, id: int) -> ResponseEnvelope[Contractor] | Awaitable[ResponseEnvelope[Contractor]]:
    params, data = _prepare_GetById(id=id)
    return invoke_operation(api, OP_GetById, params=params, data=data)

@overload
def GetByPosition(api: SyncInvokerProtocol, position: int) -> ResponseEnvelope[Contractor]: ...
@overload
def GetByPosition(api: SyncRequestProtocol, position: int) -> ResponseEnvelope[Contractor]: ...
@overload
def GetByPosition(api: AsyncInvokerProtocol, position: int) -> Awaitable[ResponseEnvelope[Contractor]]: ...
@overload
def GetByPosition(api: AsyncRequestProtocol, position: int) -> Awaitable[ResponseEnvelope[Contractor]]: ...
def GetByPosition(api: object, position: int) -> ResponseEnvelope[Contractor] | Awaitable[ResponseEnvelope[Contractor]]:
    params, data = _prepare_GetByPosition(position=position)
    return invoke_operation(api, OP_GetByPosition, params=params, data=data)

@overload
def GetByCode(api: SyncInvokerProtocol, code: str) -> ResponseEnvelope[Contractor]: ...
@overload
def GetByCode(api: SyncRequestProtocol, code: str) -> ResponseEnvelope[Contractor]: ...
@overload
def GetByCode(api: AsyncInvokerProtocol, code: str) -> Awaitable[ResponseEnvelope[Contractor]]: ...
@overload
def GetByCode(api: AsyncRequestProtocol, code: str) -> Awaitable[ResponseEnvelope[Contractor]]: ...
def GetByCode(api: object, code: str) -> ResponseEnvelope[Contractor] | Awaitable[ResponseEnvelope[Contractor]]:
    params, data = _prepare_GetByCode(code=code)
    return invoke_operation(api, OP_GetByCode, params=params, data=data)

@overload
def GetByNIP(api: SyncInvokerProtocol, nip: str) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByNIP(api: SyncRequestProtocol, nip: str) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByNIP(api: AsyncInvokerProtocol, nip: str) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
@overload
def GetByNIP(api: AsyncRequestProtocol, nip: str) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
def GetByNIP(api: object, nip: str) -> ResponseEnvelope[List[Contractor]] | Awaitable[ResponseEnvelope[List[Contractor]]]:
    params, data = _prepare_GetByNIP(nip=nip)
    return invoke_operation(api, OP_GetByNIP, params=params, data=data)

@overload
def GetByPesel(api: SyncInvokerProtocol, pesel: str) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByPesel(api: SyncRequestProtocol, pesel: str) -> ResponseEnvelope[List[Contractor]]: ...
@overload
def GetByPesel(api: AsyncInvokerProtocol, pesel: str) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
@overload
def GetByPesel(api: AsyncRequestProtocol, pesel: str) -> Awaitable[ResponseEnvelope[List[Contractor]]]: ...
def GetByPesel(api: object, pesel: str) -> ResponseEnvelope[List[Contractor]] | Awaitable[ResponseEnvelope[List[Contractor]]]:
    params, data = _prepare_GetByPesel(pesel=pesel)
    return invoke_operation(api, OP_GetByPesel, params=params, data=data)

@overload
def Filter(api: SyncInvokerProtocol, criteria: List["FilterCriteria"]) -> ResponseEnvelope[List[ContractorListElement]]: ...
@overload
def Filter(api: SyncRequestProtocol, criteria: List["FilterCriteria"]) -> ResponseEnvelope[List[ContractorListElement]]: ...
@overload
def Filter(api: AsyncInvokerProtocol, criteria: List["FilterCriteria"]) -> Awaitable[ResponseEnvelope[List[ContractorListElement]]]: ...
@overload
def Filter(api: AsyncRequestProtocol, criteria: List["FilterCriteria"]) -> Awaitable[ResponseEnvelope[List[ContractorListElement]]]: ...
def Filter(api: object, criteria: List["FilterCriteria"]) -> ResponseEnvelope[List[ContractorListElement]] | Awaitable[ResponseEnvelope[List[ContractorListElement]]]:
    params, data = _prepare_Filter(criteria=criteria)
    return invoke_operation(api, OP_Filter, params=params, data=data)

@overload
def AddNew(api: SyncInvokerProtocol, contractor: "Contractor") -> ResponseEnvelope[Contractor]: ...
@overload
def AddNew(api: SyncRequestProtocol, contractor: "Contractor") -> ResponseEnvelope[Contractor]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, contractor: "Contractor") -> Awaitable[ResponseEnvelope[Contractor]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, contractor: "Contractor") -> Awaitable[ResponseEnvelope[Contractor]]: ...
def AddNew(api: object, contractor: "Contractor") -> ResponseEnvelope[Contractor] | Awaitable[ResponseEnvelope[Contractor]]:
    params, data = _prepare_AddNew(contractor=contractor)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Update(api: SyncInvokerProtocol, contractor: "Contractor") -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, contractor: "Contractor") -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, contractor: "Contractor") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, contractor: "Contractor") -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, contractor: "Contractor") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(contractor=contractor)
    return invoke_operation(api, OP_Update, params=params, data=data)

@overload
def GetPagedDocument(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocument(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocument(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocument(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocument, params=params, data=data)

@overload
def FilterSql(api: SyncInvokerProtocol, criteriaFilter: "ContractorCriteriaFilter") -> ResponseEnvelope[List[ContractorListElement]]: ...
@overload
def FilterSql(api: SyncRequestProtocol, criteriaFilter: "ContractorCriteriaFilter") -> ResponseEnvelope[List[ContractorListElement]]: ...
@overload
def FilterSql(api: AsyncInvokerProtocol, criteriaFilter: "ContractorCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ContractorListElement]]]: ...
@overload
def FilterSql(api: AsyncRequestProtocol, criteriaFilter: "ContractorCriteriaFilter") -> Awaitable[ResponseEnvelope[List[ContractorListElement]]]: ...
def FilterSql(api: object, criteriaFilter: "ContractorCriteriaFilter") -> ResponseEnvelope[List[ContractorListElement]] | Awaitable[ResponseEnvelope[List[ContractorListElement]]]:
    params, data = _prepare_FilterSql(criteriaFilter=criteriaFilter)
    return invoke_operation(api, OP_FilterSql, params=params, data=data)

__all__ = ["GetById", "GetByPosition", "GetByCode", "GetByNIP", "GetByPesel", "Filter", "AddNew", "Update", "GetPagedDocument", "FilterSql"]
