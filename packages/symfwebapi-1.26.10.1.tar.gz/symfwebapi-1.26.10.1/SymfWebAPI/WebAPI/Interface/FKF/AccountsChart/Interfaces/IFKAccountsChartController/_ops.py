from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.AccountsChart.ViewModels import AccountChartElement
from SymfWebAPI.WebAPI.Interface.FKF.AccountsChart.ViewModels import AccountChartElementSimple

_ADAPTER_GetFlatList = TypeAdapter(List[AccountChartElementSimple])

def _parse_GetFlatList(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[AccountChartElementSimple]]:
    return parse_with_adapter(envelope, _ADAPTER_GetFlatList)
OP_GetFlatList = OperationSpec(method='GET', path='/api/FKAccountsChart/FlatList', parser=_parse_GetFlatList)

_ADAPTER_GetTreeList = TypeAdapter(List[AccountChartElement])

def _parse_GetTreeList(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[AccountChartElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetTreeList)
OP_GetTreeList = OperationSpec(method='GET', path='/api/FKAccountsChart/FlatList', parser=_parse_GetTreeList)
