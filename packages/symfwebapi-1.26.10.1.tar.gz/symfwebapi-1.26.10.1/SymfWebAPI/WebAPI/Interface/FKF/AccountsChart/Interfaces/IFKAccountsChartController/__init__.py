from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.AccountsChart.ViewModels import AccountChartElement
from SymfWebAPI.WebAPI.Interface.FKF.AccountsChart.ViewModels import AccountChartElementSimple
from ._common import (
    _prepare_GetFlatList,
    _prepare_GetTreeList,
)
from ._ops import (
    OP_GetFlatList,
    OP_GetTreeList,
)

@overload
def GetFlatList(api: SyncInvokerProtocol, yearId: int) -> ResponseEnvelope[List[AccountChartElementSimple]]: ...
@overload
def GetFlatList(api: SyncRequestProtocol, yearId: int) -> ResponseEnvelope[List[AccountChartElementSimple]]: ...
@overload
def GetFlatList(api: AsyncInvokerProtocol, yearId: int) -> Awaitable[ResponseEnvelope[List[AccountChartElementSimple]]]: ...
@overload
def GetFlatList(api: AsyncRequestProtocol, yearId: int) -> Awaitable[ResponseEnvelope[List[AccountChartElementSimple]]]: ...
def GetFlatList(api: object, yearId: int) -> ResponseEnvelope[List[AccountChartElementSimple]] | Awaitable[ResponseEnvelope[List[AccountChartElementSimple]]]:
    params, data = _prepare_GetFlatList(yearId=yearId)
    return invoke_operation(api, OP_GetFlatList, params=params, data=data)

@overload
def GetTreeList(api: SyncInvokerProtocol, yearId: int) -> ResponseEnvelope[List[AccountChartElement]]: ...
@overload
def GetTreeList(api: SyncRequestProtocol, yearId: int) -> ResponseEnvelope[List[AccountChartElement]]: ...
@overload
def GetTreeList(api: AsyncInvokerProtocol, yearId: int) -> Awaitable[ResponseEnvelope[List[AccountChartElement]]]: ...
@overload
def GetTreeList(api: AsyncRequestProtocol, yearId: int) -> Awaitable[ResponseEnvelope[List[AccountChartElement]]]: ...
def GetTreeList(api: object, yearId: int) -> ResponseEnvelope[List[AccountChartElement]] | Awaitable[ResponseEnvelope[List[AccountChartElement]]]:
    params, data = _prepare_GetTreeList(yearId=yearId)
    return invoke_operation(api, OP_GetTreeList, params=params, data=data)

__all__ = ["GetFlatList", "GetTreeList"]
