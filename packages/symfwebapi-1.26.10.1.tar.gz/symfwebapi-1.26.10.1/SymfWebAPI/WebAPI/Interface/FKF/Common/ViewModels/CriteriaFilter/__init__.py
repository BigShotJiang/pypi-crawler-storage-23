from __future__ import annotations

from pydantic import BaseModel

from SymfWebAPI.WebAPI.Interface.Enums import enumFilterSqlCriteriaMode

class IntCriteriaFilter(BaseModel):
    Value_From: int
    Value_To: int
    Mode: "enumFilterSqlCriteriaMode"

class StringCriteriaFilter(BaseModel):
    Value: str
    Mode: "enumFilterSqlCriteriaMode"
