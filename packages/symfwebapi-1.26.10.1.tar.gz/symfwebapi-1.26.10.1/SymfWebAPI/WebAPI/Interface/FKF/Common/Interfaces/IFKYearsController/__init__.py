from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Year
from ._common import (
    _prepare_Get,
)
from ._ops import (
    OP_Get,
)

@overload
def Get(api: SyncInvokerProtocol) -> ResponseEnvelope[Year]: ...
@overload
def Get(api: SyncRequestProtocol) -> ResponseEnvelope[Year]: ...
@overload
def Get(api: AsyncInvokerProtocol) -> Awaitable[ResponseEnvelope[Year]]: ...
@overload
def Get(api: AsyncRequestProtocol) -> Awaitable[ResponseEnvelope[Year]]: ...
def Get(api: object) -> ResponseEnvelope[Year] | Awaitable[ResponseEnvelope[Year]]:
    params, data = _prepare_Get()
    return invoke_operation(api, OP_Get, params=params, data=data)

__all__ = ["Get"]
