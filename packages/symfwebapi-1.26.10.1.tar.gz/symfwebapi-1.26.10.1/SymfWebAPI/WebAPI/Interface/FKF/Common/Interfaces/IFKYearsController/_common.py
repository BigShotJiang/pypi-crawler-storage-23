from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/FKYears')
def _prepare_Get() -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = None
    return params or None, data
