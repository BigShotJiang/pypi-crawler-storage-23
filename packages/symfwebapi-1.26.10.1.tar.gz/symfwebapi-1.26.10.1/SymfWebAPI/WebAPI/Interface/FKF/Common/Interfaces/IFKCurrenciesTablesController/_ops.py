from __future__ import annotations

from typing import List, Optional
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import CurrencyTable

_ADAPTER_Get = TypeAdapter(List[CurrencyTable])

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CurrencyTable]]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/FKCurrenciesTables', parser=_parse_Get)

_ADAPTER_GetList = TypeAdapter(List[CurrencyTable])

def _parse_GetList(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CurrencyTable]]:
    return parse_with_adapter(envelope, _ADAPTER_GetList)
OP_GetList = OperationSpec(method='GET', path='/api/FKCurrenciesTables/Filter', parser=_parse_GetList)

_ADAPTER_GetListByCurrency = TypeAdapter(List[CurrencyTable])

def _parse_GetListByCurrency(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CurrencyTable]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByCurrency)
OP_GetListByCurrency = OperationSpec(method='GET', path='/api/FKCurrenciesTables/Filter', parser=_parse_GetListByCurrency)
