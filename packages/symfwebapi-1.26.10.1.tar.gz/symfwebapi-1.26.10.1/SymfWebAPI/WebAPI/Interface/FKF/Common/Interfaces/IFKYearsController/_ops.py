from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Year

_ADAPTER_Get = TypeAdapter(Year)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Year]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/FKYears', parser=_parse_Get)
