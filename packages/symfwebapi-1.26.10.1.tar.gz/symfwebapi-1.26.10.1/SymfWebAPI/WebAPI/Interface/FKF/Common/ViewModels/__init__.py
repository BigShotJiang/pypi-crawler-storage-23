from __future__ import annotations

from pydantic import BaseModel

from datetime import datetime
from decimal import Decimal
from SymfWebAPI.WebAPI.Interface.Enums import enumYearClosingStatus

class Account(BaseModel):
    Synthetic: int
    Analytic1: int
    Analytic2: int
    Analytic3: int
    Analytic4: int
    Analytic5: int

class Catalog(BaseModel):
    Id: int
    ParentId: int
    Name: str
    FullPath: str

class CurrencyTable(BaseModel):
    Id: int
    Date: datetime
    CurrencyId: int
    Table: str
    Description: str
    SaleCurrencyRate: Decimal
    PurchaseCurrencyRate: Decimal

class Dimension(BaseModel):
    Name: str
    Code: str
    Value: str
    DictionaryValue: str
    Type: str

class FilterCriteria(BaseModel):
    Code: str
    Value: str

class Year(BaseModel):
    Id: int
    Code: str
    Closed: "enumYearClosingStatus"
    Archived: bool
    StartDate: datetime
    EndDate: datetime
    Length: int
