from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.Issue.Business import BusinessDocumentIssue
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.V2026_1 import Document

_ADAPTER_NewPurchaseInvoice = TypeAdapter(Document)

def _parse_NewPurchaseInvoice(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Document]:
    return parse_with_adapter(envelope, _ADAPTER_NewPurchaseInvoice)
OP_NewPurchaseInvoice = OperationSpec(method='POST', path='/api/FKDocumentsBusinessIssue/NewPurchaseInvoice', parser=_parse_NewPurchaseInvoice)

_ADAPTER_NewPurchaseInvoiceCorrection = TypeAdapter(Document)

def _parse_NewPurchaseInvoiceCorrection(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Document]:
    return parse_with_adapter(envelope, _ADAPTER_NewPurchaseInvoiceCorrection)
OP_NewPurchaseInvoiceCorrection = OperationSpec(method='POST', path='/api/FKDocumentsBusinessIssue/NewPurchaseInvoiceCorrection', parser=_parse_NewPurchaseInvoiceCorrection)

_ADAPTER_NewSaleInvoice = TypeAdapter(Document)

def _parse_NewSaleInvoice(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Document]:
    return parse_with_adapter(envelope, _ADAPTER_NewSaleInvoice)
OP_NewSaleInvoice = OperationSpec(method='POST', path='/api/FKDocumentsBusinessIssue/NewSaleInvoice', parser=_parse_NewSaleInvoice)

_ADAPTER_NewSaleInvoiceCorrection = TypeAdapter(Document)

def _parse_NewSaleInvoiceCorrection(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Document]:
    return parse_with_adapter(envelope, _ADAPTER_NewSaleInvoiceCorrection)
OP_NewSaleInvoiceCorrection = OperationSpec(method='POST', path='/api/FKDocumentsBusinessIssue/NewSaleInvoiceCorrection', parser=_parse_NewSaleInvoiceCorrection)
