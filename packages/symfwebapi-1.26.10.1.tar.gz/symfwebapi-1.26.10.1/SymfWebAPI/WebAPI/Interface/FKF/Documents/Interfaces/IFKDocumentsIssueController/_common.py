from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/FKDocumentsIssue/NewCustom')
def _prepare_AddNew(*, documentIssue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = documentIssue.model_dump_json(exclude_unset=True) if documentIssue is not None else None
    return params or None, data

_REQUEST_Validate = ('PATCH', '/api/FKDocumentsIssue/NewCustom')
def _prepare_Validate(*, documentIssue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = documentIssue.model_dump_json(exclude_unset=True) if documentIssue is not None else None
    return params or None, data
