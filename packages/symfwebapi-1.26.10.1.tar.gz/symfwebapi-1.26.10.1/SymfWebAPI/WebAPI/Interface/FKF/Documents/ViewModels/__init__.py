from __future__ import annotations

from pydantic import BaseModel

import importlib
from typing import TYPE_CHECKING
from typing import List, Optional
from datetime import datetime
from decimal import Decimal
from SymfWebAPI.WebAPI.Interface.Enums import (
    enumCurrencyRateType,
    enumDocumentSource,
    enumFKDocumentCharacter,
    enumFKDocumentMessageType,
    enumFKSplitPaymentType,
    enumJPK_V7DocumentAttribute,
    enumJPK_V7ProductGroup,
    enumKSeFInvoiceStatus,
    enumParallelType,
    enumRecordDecsriptionKind,
    enumSideType,
    enumSplitOpposingAccountType,
    enumSplitType,
    enumTransactionInterestType,
    enumVatRegisterPeriodType,
    enumVatRegisterTypeABCD,
)
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Account

class DocumentListElement(BaseModel):
    Id: int
    DocumentNumber: str
    Source: "enumDocumentSource"
    YearId: int
    DocumentDate: Optional[datetime]
    PeriodDate: Optional[datetime]
    OperationDate: Optional[datetime]
    IssueDate: Optional[datetime]
    ReceiptDate: Optional[datetime]
    TypeCode: str
    NumberInSeries: int
    Content: str
    ContractorPosition: Optional[int]
    Value: Decimal
    ValuePLN: Decimal
    Currency: str

class DocumentMessage(BaseModel):
    Type: "enumFKDocumentMessageType"
    Message: str

class DocumentRecord(BaseModel):
    Id: int
    No: int
    SplitNo: int
    Account: str
    Account_Full: "Account"
    SplitType: "enumSplitType"
    SplitOpposingAccountType: "enumSplitOpposingAccountType"
    ParallelType: "enumParallelType"
    Side: "enumSideType"
    RecordVat: bool
    Description: str
    DescriptionKind: "enumRecordDecsriptionKind"
    Currency: str
    CurrencyRate: Decimal
    CurrencyRateTableId: int
    CurrencyRateType: "enumCurrencyRateType"
    DocumentNumber: str
    Value: Decimal
    ValuePLN: Decimal
    ReportAccount: bool
    KPKWDate: datetime
    Settlements: List["DocumentSettlement"]
    Transactions: List["DocumentTransaction"]
    Features: List[int]

class DocumentRelation(BaseModel):
    DocumentNumber: str
    DocumentDate: datetime
    DocumentId: int
    YearId: int

class DocumentSettlement(BaseModel):
    Id: int
    TransactionId: int
    SettledDocument: str
    Side: "enumSideType"
    Account: str
    Account_Full: "Account"
    Value: Decimal
    ValuePLN: Decimal
    Currency: str
    CurrencyRate: Decimal
    CurrencyForeign: str
    CurrencyRateForeign: Decimal
    ValueForeign: Decimal

class DocumentTransaction(BaseModel):
    Id: int
    Side: "enumSideType"
    Account: str
    Account_Full: "Account"
    MaturityDate: datetime
    Advance: bool
    Value: Decimal
    ValuePLN: Decimal
    Currency: str
    CurrencyRate: Decimal
    InterestType: "enumTransactionInterestType"
    InterestRate: Decimal
    RKP: Decimal
    BankAccountId: Optional[int]

class DocumentType(BaseModel):
    Id: int
    Code: str
    Name: str
    YearId: int
    Character: "enumFKDocumentCharacter"

class DocumentV2(BaseModel):
    Id: int
    DocumentNumber: str
    Source: "enumDocumentSource"
    YearId: int
    SettlementId: int
    IssueDate: datetime
    DocumentDate: datetime
    PeriodDate: datetime
    OperationDate: datetime
    ReceiptDate: datetime
    TypeCode: str
    NumberInSeries: int
    Content: str
    ContractorPosition: int
    TrilateralContractorPosition: int
    Value: Decimal
    ValuePLN: Decimal
    ValueParallel: Decimal
    ValueOffVatRegistry: Decimal
    OpeningBalance: Decimal
    RecordsBalance: Decimal
    Currency: str
    CurrencyRate: Decimal
    CurrencyRateTableId: int
    CurrencyRateType: "enumCurrencyRateType"
    CorrectionNumber: str
    CorrectionDate: datetime
    Marker: int
    SplitPaymentType: "enumFKSplitPaymentType"
    JpkV7Attributes: "enumJPK_V7DocumentAttribute"
    ClearanceDate: Optional[datetime]
    StatusKSeF: "enumKSeFInvoiceStatus"
    EArchiveId: Optional[str]
    NumberKSeF: str
    MaturityDate: Optional[datetime]
    PaymentDate: Optional[datetime]
    Origin: str
    IssueDateKSeF: Optional[datetime]
    Records: List["DocumentRecord"]
    Settlements: List["DocumentSettlement"]
    Transactions: List["DocumentTransaction"]
    VatRegisters: List["DocumentVatRegister"]
    CurrencyVAT: "DocumentVatRegisterCurrency"
    CurrencyCIT_PIT: "DocumentVatRegisterCurrency"
    Features: List[int]
    FKMessages: List["DocumentMessage"]
    Relations: List["DocumentRelation"]

class DocumentVatRegister(BaseModel):
    Id: int
    DefinitionId: int
    Type: "enumVatRegisterTypeABCD"
    Period: datetime
    PeriodType: "enumVatRegisterPeriodType"
    Service: bool
    UE: bool
    Chargable: bool
    VatRate: str
    GrossValue: Decimal
    GrossValuePLN: Decimal
    NetValue: Decimal
    NetValuePLN: Decimal
    VatValue: Decimal
    VatValuePLN: Decimal
    ToPay: Decimal
    Marker: int
    CorrectionNumber: str
    CorrectionDate: datetime
    JPK_V7ProductGroups: "enumJPK_V7ProductGroup"
    ContractorPosition: int
    SplitNo: int
    DocumentDate: datetime
    ReceiptDate: datetime

class DocumentVatRegisterCurrency(BaseModel):
    Currency: str
    CurrencyRate: Optional[Decimal]
    CurrencyRateTableId: Optional[int]
    CurrencyRateTableDate: Optional[datetime]

class Feature(BaseModel):
    Id: int
    Name: str
    Description: str
    YearId: int
    BufferOnly: bool

_VERSIONED_EXPORTS = {
    'Document': 'V2026_1',
}

def __getattr__(name: str):
    child_name = _VERSIONED_EXPORTS.get(name)
    if child_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module = importlib.import_module(f".{child_name}", __name__)
    value = getattr(module, name)
    globals()[name] = value
    return value

def __dir__():
    return sorted(set(_VERSIONED_EXPORTS) | {n for n in globals() if not n.startswith('_')})

if TYPE_CHECKING:
    from .V2026_1 import Document
