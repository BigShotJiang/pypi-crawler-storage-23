from __future__ import annotations

from typing import List, Optional
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.V2026_1 import Document
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import DocumentListElement
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import DocumentType
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import DocumentV2
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import Feature
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.Transactions import TransactionDocument
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

_ADAPTER_Get = TypeAdapter(Document)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Document]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/FKDocuments', parser=_parse_Get)

_ADAPTER_GetV2 = TypeAdapter(DocumentV2)

def _parse_GetV2(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[DocumentV2]:
    return parse_with_adapter(envelope, _ADAPTER_GetV2)
OP_GetV2 = OperationSpec(method='GET', path='/api/FKDocuments', parser=_parse_GetV2)

_ADAPTER_GetFromBuffer = TypeAdapter(List[DocumentListElement])

def _parse_GetFromBuffer(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetFromBuffer)
OP_GetFromBuffer = OperationSpec(method='GET', path='/api/FKDocuments/Buffer', parser=_parse_GetFromBuffer)

_ADAPTER_GetFromAccountingBooks = TypeAdapter(List[DocumentListElement])

def _parse_GetFromAccountingBooks(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetFromAccountingBooks)
OP_GetFromAccountingBooks = OperationSpec(method='GET', path='/api/FKDocuments/Buffer', parser=_parse_GetFromAccountingBooks)

_ADAPTER_GetFromSchemes = TypeAdapter(List[DocumentListElement])

def _parse_GetFromSchemes(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetFromSchemes)
OP_GetFromSchemes = OperationSpec(method='GET', path='/api/FKDocuments/Buffer', parser=_parse_GetFromSchemes)

_ADAPTER_GetDocumentFeatures = TypeAdapter(List[Feature])

def _parse_GetDocumentFeatures(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Feature]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentFeatures)
OP_GetDocumentFeatures = OperationSpec(method='GET', path='/api/FKDocuments/DocumentFeatures', parser=_parse_GetDocumentFeatures)

_ADAPTER_GetDocumentRecordFeatures = TypeAdapter(List[Feature])

def _parse_GetDocumentRecordFeatures(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Feature]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentRecordFeatures)
OP_GetDocumentRecordFeatures = OperationSpec(method='GET', path='/api/FKDocuments/DocumentRecordFeatures', parser=_parse_GetDocumentRecordFeatures)

_ADAPTER_GetDocumentTypes = TypeAdapter(List[DocumentType])

def _parse_GetDocumentTypes(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentType]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentTypes)
OP_GetDocumentTypes = OperationSpec(method='GET', path='/api/FKDocuments/DocumentTypes', parser=_parse_GetDocumentTypes)

_ADAPTER_GetPagedDocument = TypeAdapter(Page)

def _parse_GetPagedDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocument)
OP_GetPagedDocument = OperationSpec(method='GET', path='/api/FKDocuments/Page', parser=_parse_GetPagedDocument)

_ADAPTER_GetDocumentTransactions = TypeAdapter(List[TransactionDocument])

def _parse_GetDocumentTransactions(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[TransactionDocument]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentTransactions)
OP_GetDocumentTransactions = OperationSpec(method='GET', path='/api/FKDocuments/Transactions', parser=_parse_GetDocumentTransactions)
