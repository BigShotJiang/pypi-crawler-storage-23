from __future__ import annotations

from typing import Any

_REQUEST_Get = ('GET', '/api/FKDocuments')
def _prepare_Get(*, id, yearId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    params["yearId"] = yearId
    data = None
    return params or None, data

_REQUEST_GetV2 = ('GET', '/api/FKDocuments')
def _prepare_GetV2(*, id, yearId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    params["yearId"] = yearId
    data = None
    return params or None, data

_REQUEST_GetFromBuffer = ('GET', '/api/FKDocuments/Buffer')
def _prepare_GetFromBuffer(*, yearId, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["yearId"] = yearId
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetFromAccountingBooks = ('GET', '/api/FKDocuments/Buffer')
def _prepare_GetFromAccountingBooks(*, yearId, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["yearId"] = yearId
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetFromSchemes = ('GET', '/api/FKDocuments/Buffer')
def _prepare_GetFromSchemes(*, yearId, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["yearId"] = yearId
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDocumentFeatures = ('GET', '/api/FKDocuments/DocumentFeatures')
def _prepare_GetDocumentFeatures(*, yearId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["yearId"] = yearId
    data = None
    return params or None, data

_REQUEST_GetDocumentRecordFeatures = ('GET', '/api/FKDocuments/DocumentRecordFeatures')
def _prepare_GetDocumentRecordFeatures(*, yearId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["yearId"] = yearId
    data = None
    return params or None, data

_REQUEST_GetDocumentTypes = ('GET', '/api/FKDocuments/DocumentTypes')
def _prepare_GetDocumentTypes(*, yearId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["yearId"] = yearId
    data = None
    return params or None, data

_REQUEST_GetPagedDocument = ('GET', '/api/FKDocuments/Page')
def _prepare_GetPagedDocument(*, page, size, orderBy) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["page"] = page
    params["size"] = size
    params["orderBy"] = orderBy.value
    data = None
    return params or None, data

_REQUEST_GetDocumentTransactions = ('GET', '/api/FKDocuments/Transactions')
def _prepare_GetDocumentTransactions() -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = None
    return params or None, data
