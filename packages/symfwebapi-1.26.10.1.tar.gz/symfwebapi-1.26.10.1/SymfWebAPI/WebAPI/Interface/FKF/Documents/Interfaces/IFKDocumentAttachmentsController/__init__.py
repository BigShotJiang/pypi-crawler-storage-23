from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.Rdf import RdfDocumentAttachment
from ._common import (
    _prepare_AddNew,
    _prepare_Update,
)
from ._ops import (
    OP_AddNew,
    OP_Update,
)

@overload
def AddNew(api: SyncInvokerProtocol, documentId: int, yearId: int, newDocumentAttachment: "RdfDocumentAttachment") -> ResponseEnvelope[None]: ...
@overload
def AddNew(api: SyncRequestProtocol, documentId: int, yearId: int, newDocumentAttachment: "RdfDocumentAttachment") -> ResponseEnvelope[None]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, documentId: int, yearId: int, newDocumentAttachment: "RdfDocumentAttachment") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, documentId: int, yearId: int, newDocumentAttachment: "RdfDocumentAttachment") -> Awaitable[ResponseEnvelope[None]]: ...
def AddNew(api: object, documentId: int, yearId: int, newDocumentAttachment: "RdfDocumentAttachment") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_AddNew(documentId=documentId, yearId=yearId, newDocumentAttachment=newDocumentAttachment)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Update(api: SyncInvokerProtocol, documentId: int, yearId: int, newDocumentAttachment: "RdfDocumentAttachment") -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, documentId: int, yearId: int, newDocumentAttachment: "RdfDocumentAttachment") -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, documentId: int, yearId: int, newDocumentAttachment: "RdfDocumentAttachment") -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, documentId: int, yearId: int, newDocumentAttachment: "RdfDocumentAttachment") -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, documentId: int, yearId: int, newDocumentAttachment: "RdfDocumentAttachment") -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(documentId=documentId, yearId=yearId, newDocumentAttachment=newDocumentAttachment)
    return invoke_operation(api, OP_Update, params=params, data=data)

__all__ = ["AddNew", "Update"]
