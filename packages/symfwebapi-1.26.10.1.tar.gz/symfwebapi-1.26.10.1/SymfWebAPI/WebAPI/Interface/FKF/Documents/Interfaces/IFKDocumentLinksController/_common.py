from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/FKDocumentLinks/AddNew')
def _prepare_AddNew(*, documentId, yearId, newDocumentLink) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentId"] = documentId
    params["yearId"] = yearId
    data = newDocumentLink.model_dump_json(exclude_unset=True) if newDocumentLink is not None else None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/FKDocumentLinks/Update')
def _prepare_Update(*, documentId, yearId, newDocumentLink) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentId"] = documentId
    params["yearId"] = yearId
    data = newDocumentLink.model_dump_json(exclude_unset=True) if newDocumentLink is not None else None
    return params or None, data
