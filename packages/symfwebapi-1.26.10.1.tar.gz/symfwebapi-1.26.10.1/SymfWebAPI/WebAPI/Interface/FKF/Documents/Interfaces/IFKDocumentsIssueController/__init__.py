from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.V2026_1 import Document
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.Issue.Custom import DocumentIssue
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import DocumentMessage
from ._common import (
    _prepare_AddNew,
    _prepare_Validate,
)
from ._ops import (
    OP_AddNew,
    OP_Validate,
)

@overload
def AddNew(api: SyncInvokerProtocol, documentIssue: "DocumentIssue") -> ResponseEnvelope[Document]: ...
@overload
def AddNew(api: SyncRequestProtocol, documentIssue: "DocumentIssue") -> ResponseEnvelope[Document]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, documentIssue: "DocumentIssue") -> Awaitable[ResponseEnvelope[Document]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, documentIssue: "DocumentIssue") -> Awaitable[ResponseEnvelope[Document]]: ...
def AddNew(api: object, documentIssue: "DocumentIssue") -> ResponseEnvelope[Document] | Awaitable[ResponseEnvelope[Document]]:
    params, data = _prepare_AddNew(documentIssue=documentIssue)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Validate(api: SyncInvokerProtocol, documentIssue: "DocumentIssue") -> ResponseEnvelope[List[DocumentMessage]]: ...
@overload
def Validate(api: SyncRequestProtocol, documentIssue: "DocumentIssue") -> ResponseEnvelope[List[DocumentMessage]]: ...
@overload
def Validate(api: AsyncInvokerProtocol, documentIssue: "DocumentIssue") -> Awaitable[ResponseEnvelope[List[DocumentMessage]]]: ...
@overload
def Validate(api: AsyncRequestProtocol, documentIssue: "DocumentIssue") -> Awaitable[ResponseEnvelope[List[DocumentMessage]]]: ...
def Validate(api: object, documentIssue: "DocumentIssue") -> ResponseEnvelope[List[DocumentMessage]] | Awaitable[ResponseEnvelope[List[DocumentMessage]]]:
    params, data = _prepare_Validate(documentIssue=documentIssue)
    return invoke_operation(api, OP_Validate, params=params, data=data)

__all__ = ["AddNew", "Validate"]
