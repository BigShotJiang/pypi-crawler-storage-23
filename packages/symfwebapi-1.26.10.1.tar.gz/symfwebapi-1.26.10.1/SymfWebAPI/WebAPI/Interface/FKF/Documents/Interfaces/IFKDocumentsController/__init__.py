from __future__ import annotations

from typing import Awaitable, List, Optional, overload
from datetime import datetime
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.V2026_1 import Document
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import DocumentListElement
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import DocumentType
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import DocumentV2
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import Feature
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.Transactions import TransactionDocument
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType
from ._common import (
    _prepare_Get,
    _prepare_GetV2,
    _prepare_GetFromBuffer,
    _prepare_GetFromAccountingBooks,
    _prepare_GetFromSchemes,
    _prepare_GetDocumentFeatures,
    _prepare_GetDocumentRecordFeatures,
    _prepare_GetDocumentTypes,
    _prepare_GetPagedDocument,
    _prepare_GetDocumentTransactions,
)
from ._ops import (
    OP_Get,
    OP_GetV2,
    OP_GetFromBuffer,
    OP_GetFromAccountingBooks,
    OP_GetFromSchemes,
    OP_GetDocumentFeatures,
    OP_GetDocumentRecordFeatures,
    OP_GetDocumentTypes,
    OP_GetPagedDocument,
    OP_GetDocumentTransactions,
)

@overload
def Get(api: SyncInvokerProtocol, id: int, yearId: int) -> ResponseEnvelope[Document]: ...
@overload
def Get(api: SyncRequestProtocol, id: int, yearId: int) -> ResponseEnvelope[Document]: ...
@overload
def Get(api: AsyncInvokerProtocol, id: int, yearId: int) -> Awaitable[ResponseEnvelope[Document]]: ...
@overload
def Get(api: AsyncRequestProtocol, id: int, yearId: int) -> Awaitable[ResponseEnvelope[Document]]: ...
def Get(api: object, id: int, yearId: int) -> ResponseEnvelope[Document] | Awaitable[ResponseEnvelope[Document]]:
    params, data = _prepare_Get(id=id, yearId=yearId)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetV2(api: SyncInvokerProtocol, id: int, yearId: int) -> ResponseEnvelope[DocumentV2]: ...
@overload
def GetV2(api: SyncRequestProtocol, id: int, yearId: int) -> ResponseEnvelope[DocumentV2]: ...
@overload
def GetV2(api: AsyncInvokerProtocol, id: int, yearId: int) -> Awaitable[ResponseEnvelope[DocumentV2]]: ...
@overload
def GetV2(api: AsyncRequestProtocol, id: int, yearId: int) -> Awaitable[ResponseEnvelope[DocumentV2]]: ...
def GetV2(api: object, id: int, yearId: int) -> ResponseEnvelope[DocumentV2] | Awaitable[ResponseEnvelope[DocumentV2]]:
    params, data = _prepare_GetV2(id=id, yearId=yearId)
    return invoke_operation(api, OP_GetV2, params=params, data=data)

@overload
def GetFromBuffer(api: SyncInvokerProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[DocumentListElement]]: ...
@overload
def GetFromBuffer(api: SyncRequestProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[DocumentListElement]]: ...
@overload
def GetFromBuffer(api: AsyncInvokerProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[DocumentListElement]]]: ...
@overload
def GetFromBuffer(api: AsyncRequestProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[DocumentListElement]]]: ...
def GetFromBuffer(api: object, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[DocumentListElement]] | Awaitable[ResponseEnvelope[List[DocumentListElement]]]:
    params, data = _prepare_GetFromBuffer(yearId=yearId, contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetFromBuffer, params=params, data=data)

@overload
def GetFromAccountingBooks(api: SyncInvokerProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[DocumentListElement]]: ...
@overload
def GetFromAccountingBooks(api: SyncRequestProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[DocumentListElement]]: ...
@overload
def GetFromAccountingBooks(api: AsyncInvokerProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[DocumentListElement]]]: ...
@overload
def GetFromAccountingBooks(api: AsyncRequestProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[DocumentListElement]]]: ...
def GetFromAccountingBooks(api: object, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[DocumentListElement]] | Awaitable[ResponseEnvelope[List[DocumentListElement]]]:
    params, data = _prepare_GetFromAccountingBooks(yearId=yearId, contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetFromAccountingBooks, params=params, data=data)

@overload
def GetFromSchemes(api: SyncInvokerProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[DocumentListElement]]: ...
@overload
def GetFromSchemes(api: SyncRequestProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[DocumentListElement]]: ...
@overload
def GetFromSchemes(api: AsyncInvokerProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[DocumentListElement]]]: ...
@overload
def GetFromSchemes(api: AsyncRequestProtocol, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[DocumentListElement]]]: ...
def GetFromSchemes(api: object, yearId: int, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[DocumentListElement]] | Awaitable[ResponseEnvelope[List[DocumentListElement]]]:
    params, data = _prepare_GetFromSchemes(yearId=yearId, contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetFromSchemes, params=params, data=data)

@overload
def GetDocumentFeatures(api: SyncInvokerProtocol, yearId: int) -> ResponseEnvelope[List[Feature]]: ...
@overload
def GetDocumentFeatures(api: SyncRequestProtocol, yearId: int) -> ResponseEnvelope[List[Feature]]: ...
@overload
def GetDocumentFeatures(api: AsyncInvokerProtocol, yearId: int) -> Awaitable[ResponseEnvelope[List[Feature]]]: ...
@overload
def GetDocumentFeatures(api: AsyncRequestProtocol, yearId: int) -> Awaitable[ResponseEnvelope[List[Feature]]]: ...
def GetDocumentFeatures(api: object, yearId: int) -> ResponseEnvelope[List[Feature]] | Awaitable[ResponseEnvelope[List[Feature]]]:
    params, data = _prepare_GetDocumentFeatures(yearId=yearId)
    return invoke_operation(api, OP_GetDocumentFeatures, params=params, data=data)

@overload
def GetDocumentRecordFeatures(api: SyncInvokerProtocol, yearId: int) -> ResponseEnvelope[List[Feature]]: ...
@overload
def GetDocumentRecordFeatures(api: SyncRequestProtocol, yearId: int) -> ResponseEnvelope[List[Feature]]: ...
@overload
def GetDocumentRecordFeatures(api: AsyncInvokerProtocol, yearId: int) -> Awaitable[ResponseEnvelope[List[Feature]]]: ...
@overload
def GetDocumentRecordFeatures(api: AsyncRequestProtocol, yearId: int) -> Awaitable[ResponseEnvelope[List[Feature]]]: ...
def GetDocumentRecordFeatures(api: object, yearId: int) -> ResponseEnvelope[List[Feature]] | Awaitable[ResponseEnvelope[List[Feature]]]:
    params, data = _prepare_GetDocumentRecordFeatures(yearId=yearId)
    return invoke_operation(api, OP_GetDocumentRecordFeatures, params=params, data=data)

@overload
def GetDocumentTypes(api: SyncInvokerProtocol, yearId: int) -> ResponseEnvelope[List[DocumentType]]: ...
@overload
def GetDocumentTypes(api: SyncRequestProtocol, yearId: int) -> ResponseEnvelope[List[DocumentType]]: ...
@overload
def GetDocumentTypes(api: AsyncInvokerProtocol, yearId: int) -> Awaitable[ResponseEnvelope[List[DocumentType]]]: ...
@overload
def GetDocumentTypes(api: AsyncRequestProtocol, yearId: int) -> Awaitable[ResponseEnvelope[List[DocumentType]]]: ...
def GetDocumentTypes(api: object, yearId: int) -> ResponseEnvelope[List[DocumentType]] | Awaitable[ResponseEnvelope[List[DocumentType]]]:
    params, data = _prepare_GetDocumentTypes(yearId=yearId)
    return invoke_operation(api, OP_GetDocumentTypes, params=params, data=data)

@overload
def GetPagedDocument(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocument(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocument(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocument(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocument, params=params, data=data)

@overload
def GetDocumentTransactions(api: SyncInvokerProtocol) -> ResponseEnvelope[List[TransactionDocument]]: ...
@overload
def GetDocumentTransactions(api: SyncRequestProtocol) -> ResponseEnvelope[List[TransactionDocument]]: ...
@overload
def GetDocumentTransactions(api: AsyncInvokerProtocol) -> Awaitable[ResponseEnvelope[List[TransactionDocument]]]: ...
@overload
def GetDocumentTransactions(api: AsyncRequestProtocol) -> Awaitable[ResponseEnvelope[List[TransactionDocument]]]: ...
def GetDocumentTransactions(api: object) -> ResponseEnvelope[List[TransactionDocument]] | Awaitable[ResponseEnvelope[List[TransactionDocument]]]:
    params, data = _prepare_GetDocumentTransactions()
    return invoke_operation(api, OP_GetDocumentTransactions, params=params, data=data)

__all__ = ["Get", "GetV2", "GetFromBuffer", "GetFromAccountingBooks", "GetFromSchemes", "GetDocumentFeatures", "GetDocumentRecordFeatures", "GetDocumentTypes", "GetPagedDocument", "GetDocumentTransactions"]
