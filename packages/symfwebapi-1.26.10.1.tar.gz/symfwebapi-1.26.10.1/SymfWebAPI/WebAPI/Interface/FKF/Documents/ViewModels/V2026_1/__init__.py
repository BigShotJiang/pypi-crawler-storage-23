from __future__ import annotations

from pydantic import BaseModel

from typing import List, Optional
from datetime import datetime
from decimal import Decimal
from SymfWebAPI.WebAPI.Interface.Enums import (
    enumCurrencyRateType,
    enumDocumentSource,
    enumFKSplitPaymentType,
    enumJPK_V7DocumentAttribute,
    enumKSeFInvoiceStatus,
)
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import (
    DocumentMessage,
    DocumentRecord,
    DocumentRelation,
    DocumentSettlement,
    DocumentTransaction,
    DocumentVatRegister,
    DocumentVatRegisterCurrency,
)

class Document(BaseModel):
    BuyerOrSellerContractorPosition: Optional[int]
    Id: int
    DocumentNumber: str
    Source: "enumDocumentSource"
    YearId: int
    SettlementId: int
    IssueDate: datetime
    DocumentDate: datetime
    PeriodDate: datetime
    OperationDate: datetime
    ReceiptDate: datetime
    TypeCode: str
    NumberInSeries: int
    Content: str
    ContractorPosition: int
    TrilateralContractorPosition: int
    Value: Decimal
    ValuePLN: Decimal
    ValueParallel: Decimal
    ValueOffVatRegistry: Decimal
    OpeningBalance: Decimal
    RecordsBalance: Decimal
    Currency: str
    CurrencyRate: Decimal
    CurrencyRateTableId: int
    CurrencyRateType: "enumCurrencyRateType"
    CorrectionNumber: str
    CorrectionDate: datetime
    Marker: int
    SplitPaymentType: "enumFKSplitPaymentType"
    JPK_V7Attributes: "enumJPK_V7DocumentAttribute"
    ClearenceDate: Optional[datetime]
    StatusKSeF: "enumKSeFInvoiceStatus"
    eArchiveId: Optional[str]
    NumberKSeF: str
    MaturityDate: Optional[datetime]
    PaymentDate: Optional[datetime]
    Origin: str
    IssueDateKSeF: Optional[datetime]
    Records: List["DocumentRecord"]
    Settlements: List["DocumentSettlement"]
    Transactions: List["DocumentTransaction"]
    VatRegisters: List["DocumentVatRegister"]
    CurrencyVAT: "DocumentVatRegisterCurrency"
    CurrencyCIT_PIT: "DocumentVatRegisterCurrency"
    Features: List[int]
    FKMessages: List["DocumentMessage"]
    Relations: List["DocumentRelation"]
