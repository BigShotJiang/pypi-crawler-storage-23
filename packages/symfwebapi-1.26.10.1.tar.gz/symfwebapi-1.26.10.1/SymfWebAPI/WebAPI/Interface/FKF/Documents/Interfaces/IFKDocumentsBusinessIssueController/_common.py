from __future__ import annotations

from typing import Any

_REQUEST_NewPurchaseInvoice = ('POST', '/api/FKDocumentsBusinessIssue/NewPurchaseInvoice')
def _prepare_NewPurchaseInvoice(*, documentIssue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = documentIssue.model_dump_json(exclude_unset=True) if documentIssue is not None else None
    return params or None, data

_REQUEST_NewPurchaseInvoiceCorrection = ('POST', '/api/FKDocumentsBusinessIssue/NewPurchaseInvoiceCorrection')
def _prepare_NewPurchaseInvoiceCorrection(*, documentIssue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = documentIssue.model_dump_json(exclude_unset=True) if documentIssue is not None else None
    return params or None, data

_REQUEST_NewSaleInvoice = ('POST', '/api/FKDocumentsBusinessIssue/NewSaleInvoice')
def _prepare_NewSaleInvoice(*, documentIssue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = documentIssue.model_dump_json(exclude_unset=True) if documentIssue is not None else None
    return params or None, data

_REQUEST_NewSaleInvoiceCorrection = ('POST', '/api/FKDocumentsBusinessIssue/NewSaleInvoiceCorrection')
def _prepare_NewSaleInvoiceCorrection(*, documentIssue) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = documentIssue.model_dump_json(exclude_unset=True) if documentIssue is not None else None
    return params or None, data
