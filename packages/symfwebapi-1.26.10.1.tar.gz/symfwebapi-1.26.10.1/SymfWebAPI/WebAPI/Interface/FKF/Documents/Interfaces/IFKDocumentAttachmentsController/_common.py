from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/FKDocumentAttachments/AddNew')
def _prepare_AddNew(*, documentId, yearId, newDocumentAttachment) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentId"] = documentId
    params["yearId"] = yearId
    data = newDocumentAttachment.model_dump_json(exclude_unset=True) if newDocumentAttachment is not None else None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/FKDocumentAttachments/Update')
def _prepare_Update(*, documentId, yearId, newDocumentAttachment) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentId"] = documentId
    params["yearId"] = yearId
    data = newDocumentAttachment.model_dump_json(exclude_unset=True) if newDocumentAttachment is not None else None
    return params or None, data
