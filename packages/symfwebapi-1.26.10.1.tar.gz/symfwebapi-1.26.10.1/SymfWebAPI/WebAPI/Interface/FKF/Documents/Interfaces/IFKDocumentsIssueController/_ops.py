from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.V2026_1 import Document
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.Issue.Custom import DocumentIssue
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels import DocumentMessage

_ADAPTER_AddNew = TypeAdapter(Document)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Document]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/FKDocumentsIssue/NewCustom', parser=_parse_AddNew)

_ADAPTER_Validate = TypeAdapter(List[DocumentMessage])

def _parse_Validate(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentMessage]]:
    return parse_with_adapter(envelope, _ADAPTER_Validate)
OP_Validate = OperationSpec(method='PATCH', path='/api/FKDocumentsIssue/NewCustom', parser=_parse_Validate)
