from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.Issue.Business import BusinessDocumentIssue
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.V2026_1 import Document
from ._common import (
    _prepare_NewPurchaseInvoice,
    _prepare_NewPurchaseInvoiceCorrection,
    _prepare_NewSaleInvoice,
    _prepare_NewSaleInvoiceCorrection,
)
from ._ops import (
    OP_NewPurchaseInvoice,
    OP_NewPurchaseInvoiceCorrection,
    OP_NewSaleInvoice,
    OP_NewSaleInvoiceCorrection,
)

@overload
def NewPurchaseInvoice(api: SyncInvokerProtocol, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document]: ...
@overload
def NewPurchaseInvoice(api: SyncRequestProtocol, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document]: ...
@overload
def NewPurchaseInvoice(api: AsyncInvokerProtocol, documentIssue: "BusinessDocumentIssue") -> Awaitable[ResponseEnvelope[Document]]: ...
@overload
def NewPurchaseInvoice(api: AsyncRequestProtocol, documentIssue: "BusinessDocumentIssue") -> Awaitable[ResponseEnvelope[Document]]: ...
def NewPurchaseInvoice(api: object, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document] | Awaitable[ResponseEnvelope[Document]]:
    params, data = _prepare_NewPurchaseInvoice(documentIssue=documentIssue)
    return invoke_operation(api, OP_NewPurchaseInvoice, params=params, data=data)

@overload
def NewPurchaseInvoiceCorrection(api: SyncInvokerProtocol, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document]: ...
@overload
def NewPurchaseInvoiceCorrection(api: SyncRequestProtocol, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document]: ...
@overload
def NewPurchaseInvoiceCorrection(api: AsyncInvokerProtocol, documentIssue: "BusinessDocumentIssue") -> Awaitable[ResponseEnvelope[Document]]: ...
@overload
def NewPurchaseInvoiceCorrection(api: AsyncRequestProtocol, documentIssue: "BusinessDocumentIssue") -> Awaitable[ResponseEnvelope[Document]]: ...
def NewPurchaseInvoiceCorrection(api: object, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document] | Awaitable[ResponseEnvelope[Document]]:
    params, data = _prepare_NewPurchaseInvoiceCorrection(documentIssue=documentIssue)
    return invoke_operation(api, OP_NewPurchaseInvoiceCorrection, params=params, data=data)

@overload
def NewSaleInvoice(api: SyncInvokerProtocol, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document]: ...
@overload
def NewSaleInvoice(api: SyncRequestProtocol, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document]: ...
@overload
def NewSaleInvoice(api: AsyncInvokerProtocol, documentIssue: "BusinessDocumentIssue") -> Awaitable[ResponseEnvelope[Document]]: ...
@overload
def NewSaleInvoice(api: AsyncRequestProtocol, documentIssue: "BusinessDocumentIssue") -> Awaitable[ResponseEnvelope[Document]]: ...
def NewSaleInvoice(api: object, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document] | Awaitable[ResponseEnvelope[Document]]:
    params, data = _prepare_NewSaleInvoice(documentIssue=documentIssue)
    return invoke_operation(api, OP_NewSaleInvoice, params=params, data=data)

@overload
def NewSaleInvoiceCorrection(api: SyncInvokerProtocol, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document]: ...
@overload
def NewSaleInvoiceCorrection(api: SyncRequestProtocol, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document]: ...
@overload
def NewSaleInvoiceCorrection(api: AsyncInvokerProtocol, documentIssue: "BusinessDocumentIssue") -> Awaitable[ResponseEnvelope[Document]]: ...
@overload
def NewSaleInvoiceCorrection(api: AsyncRequestProtocol, documentIssue: "BusinessDocumentIssue") -> Awaitable[ResponseEnvelope[Document]]: ...
def NewSaleInvoiceCorrection(api: object, documentIssue: "BusinessDocumentIssue") -> ResponseEnvelope[Document] | Awaitable[ResponseEnvelope[Document]]:
    params, data = _prepare_NewSaleInvoiceCorrection(documentIssue=documentIssue)
    return invoke_operation(api, OP_NewSaleInvoiceCorrection, params=params, data=data)

__all__ = ["NewPurchaseInvoice", "NewPurchaseInvoiceCorrection", "NewSaleInvoice", "NewSaleInvoiceCorrection"]
