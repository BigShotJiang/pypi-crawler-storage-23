from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Calculations.ViewModels import BalanceAndTurnoverFilterOptions
from SymfWebAPI.WebAPI.Interface.FKF.Calculations.ViewModels import BalanceAndTurnoverListElement

_ADAPTER_BalanceAndTurnoverAsync = TypeAdapter(List[BalanceAndTurnoverListElement])

def _parse_BalanceAndTurnoverAsync(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[BalanceAndTurnoverListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_BalanceAndTurnoverAsync)
OP_BalanceAndTurnoverAsync = OperationSpec(method='GET', path='/api/FKCalculationsBusiness/BalanceAndTurnover', parser=_parse_BalanceAndTurnoverAsync)
