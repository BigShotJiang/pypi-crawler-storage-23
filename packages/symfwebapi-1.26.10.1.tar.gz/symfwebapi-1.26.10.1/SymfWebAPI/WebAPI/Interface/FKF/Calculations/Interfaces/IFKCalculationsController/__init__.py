from __future__ import annotations

from typing import Awaitable, List, Optional, overload
from datetime import datetime
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Calculations.ViewModels import CalculationFilterOptions
from SymfWebAPI.WebAPI.Interface.FKF.Calculations.ViewModels import CalculationListElement
from SymfWebAPI.WebAPI.Interface.FKF.Calculations.ViewModels import CalculationListElementGrouped
from ._common import (
    _prepare_Custom,
    _prepare_GetByContractor,
    _prepare_GetNotSettledByContractor,
    _prepare_GetBeforeMaturityTermByContractor,
    _prepare_GetAfterMaturityTermByContractor,
    _prepare_GetDueByContractor,
    _prepare_GetDueNotSettledByContractor,
    _prepare_GetDueBeforeMaturityTermByContractor,
    _prepare_GetDueAfterMaturityTermByContractor,
    _prepare_GetObligationByContractor,
    _prepare_GetObligationNotSettledByContractor,
    _prepare_GetObligationBeforeMaturityTermByContractor,
    _prepare_GetObligationAfterMaturityTermByContractor,
    _prepare_GetByEmployee,
    _prepare_GetNotSettledByEmployee,
    _prepare_GetBeforeMaturityTermByEmployee,
    _prepare_GetAfterMaturityTermByEmployee,
    _prepare_GetDueByEmployee,
    _prepare_GetDueNotSettledByEmployee,
    _prepare_GetDueBeforeMaturityTermByEmployee,
    _prepare_GetDueAfterMaturityTermByEmployee,
    _prepare_GetObligationByEmployee,
    _prepare_GetObligationNotSettledByEmployee,
    _prepare_GetObligationBeforeMaturityTermByEmployee,
    _prepare_GetObligationAfterMaturityTermByEmployee,
    _prepare_GetDueGroupedBySubject,
    _prepare_GetDueNotSettledGroupedBySubject,
    _prepare_GetDueBeforeMaturityTermGroupedBySubject,
    _prepare_GetDueAfterMaturityTermGroupedBySubject,
    _prepare_GetObligationGroupedBySubject,
    _prepare_GetObligationNotSettledGroupedBySubject,
    _prepare_GetObligationBeforeMaturityTermGroupedBySubject,
    _prepare_GetObligationAfterMaturityTermGroupedBySubject,
)
from ._ops import (
    OP_Custom,
    OP_GetByContractor,
    OP_GetNotSettledByContractor,
    OP_GetBeforeMaturityTermByContractor,
    OP_GetAfterMaturityTermByContractor,
    OP_GetDueByContractor,
    OP_GetDueNotSettledByContractor,
    OP_GetDueBeforeMaturityTermByContractor,
    OP_GetDueAfterMaturityTermByContractor,
    OP_GetObligationByContractor,
    OP_GetObligationNotSettledByContractor,
    OP_GetObligationBeforeMaturityTermByContractor,
    OP_GetObligationAfterMaturityTermByContractor,
    OP_GetByEmployee,
    OP_GetNotSettledByEmployee,
    OP_GetBeforeMaturityTermByEmployee,
    OP_GetAfterMaturityTermByEmployee,
    OP_GetDueByEmployee,
    OP_GetDueNotSettledByEmployee,
    OP_GetDueBeforeMaturityTermByEmployee,
    OP_GetDueAfterMaturityTermByEmployee,
    OP_GetObligationByEmployee,
    OP_GetObligationNotSettledByEmployee,
    OP_GetObligationBeforeMaturityTermByEmployee,
    OP_GetObligationAfterMaturityTermByEmployee,
    OP_GetDueGroupedBySubject,
    OP_GetDueNotSettledGroupedBySubject,
    OP_GetDueBeforeMaturityTermGroupedBySubject,
    OP_GetDueAfterMaturityTermGroupedBySubject,
    OP_GetObligationGroupedBySubject,
    OP_GetObligationNotSettledGroupedBySubject,
    OP_GetObligationBeforeMaturityTermGroupedBySubject,
    OP_GetObligationAfterMaturityTermGroupedBySubject,
)

@overload
def Custom(api: SyncInvokerProtocol, options: "CalculationFilterOptions") -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def Custom(api: SyncRequestProtocol, options: "CalculationFilterOptions") -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def Custom(api: AsyncInvokerProtocol, options: "CalculationFilterOptions") -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def Custom(api: AsyncRequestProtocol, options: "CalculationFilterOptions") -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def Custom(api: object, options: "CalculationFilterOptions") -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_Custom(options=options)
    return invoke_operation(api, OP_Custom, params=params, data=data)

@overload
def GetByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetByContractor, params=params, data=data)

@overload
def GetNotSettledByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetNotSettledByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetNotSettledByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetNotSettledByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetNotSettledByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetNotSettledByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetNotSettledByContractor, params=params, data=data)

@overload
def GetBeforeMaturityTermByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetBeforeMaturityTermByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetBeforeMaturityTermByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetBeforeMaturityTermByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetBeforeMaturityTermByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetBeforeMaturityTermByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetBeforeMaturityTermByContractor, params=params, data=data)

@overload
def GetAfterMaturityTermByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetAfterMaturityTermByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetAfterMaturityTermByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetAfterMaturityTermByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetAfterMaturityTermByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetAfterMaturityTermByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetAfterMaturityTermByContractor, params=params, data=data)

@overload
def GetDueByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetDueByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetDueByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetDueByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueByContractor, params=params, data=data)

@overload
def GetDueNotSettledByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueNotSettledByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueNotSettledByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetDueNotSettledByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetDueNotSettledByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetDueNotSettledByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueNotSettledByContractor, params=params, data=data)

@overload
def GetDueBeforeMaturityTermByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueBeforeMaturityTermByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueBeforeMaturityTermByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetDueBeforeMaturityTermByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetDueBeforeMaturityTermByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetDueBeforeMaturityTermByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueBeforeMaturityTermByContractor, params=params, data=data)

@overload
def GetDueAfterMaturityTermByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueAfterMaturityTermByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueAfterMaturityTermByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetDueAfterMaturityTermByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetDueAfterMaturityTermByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetDueAfterMaturityTermByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueAfterMaturityTermByContractor, params=params, data=data)

@overload
def GetObligationByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetObligationByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetObligationByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetObligationByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationByContractor, params=params, data=data)

@overload
def GetObligationNotSettledByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationNotSettledByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationNotSettledByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetObligationNotSettledByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetObligationNotSettledByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetObligationNotSettledByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationNotSettledByContractor, params=params, data=data)

@overload
def GetObligationBeforeMaturityTermByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationBeforeMaturityTermByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationBeforeMaturityTermByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetObligationBeforeMaturityTermByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetObligationBeforeMaturityTermByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetObligationBeforeMaturityTermByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationBeforeMaturityTermByContractor, params=params, data=data)

@overload
def GetObligationAfterMaturityTermByContractor(api: SyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationAfterMaturityTermByContractor(api: SyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationAfterMaturityTermByContractor(api: AsyncInvokerProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetObligationAfterMaturityTermByContractor(api: AsyncRequestProtocol, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetObligationAfterMaturityTermByContractor(api: object, contractorPosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetObligationAfterMaturityTermByContractor(contractorPosition=contractorPosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationAfterMaturityTermByContractor, params=params, data=data)

@overload
def GetByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetByEmployee, params=params, data=data)

@overload
def GetNotSettledByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetNotSettledByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetNotSettledByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetNotSettledByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetNotSettledByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetNotSettledByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetNotSettledByEmployee, params=params, data=data)

@overload
def GetBeforeMaturityTermByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetBeforeMaturityTermByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetBeforeMaturityTermByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetBeforeMaturityTermByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetBeforeMaturityTermByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetBeforeMaturityTermByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetBeforeMaturityTermByEmployee, params=params, data=data)

@overload
def GetAfterMaturityTermByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetAfterMaturityTermByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetAfterMaturityTermByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetAfterMaturityTermByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetAfterMaturityTermByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetAfterMaturityTermByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetAfterMaturityTermByEmployee, params=params, data=data)

@overload
def GetDueByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetDueByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetDueByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetDueByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueByEmployee, params=params, data=data)

@overload
def GetDueNotSettledByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueNotSettledByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueNotSettledByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetDueNotSettledByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetDueNotSettledByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetDueNotSettledByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueNotSettledByEmployee, params=params, data=data)

@overload
def GetDueBeforeMaturityTermByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueBeforeMaturityTermByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueBeforeMaturityTermByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetDueBeforeMaturityTermByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetDueBeforeMaturityTermByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetDueBeforeMaturityTermByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueBeforeMaturityTermByEmployee, params=params, data=data)

@overload
def GetDueAfterMaturityTermByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueAfterMaturityTermByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetDueAfterMaturityTermByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetDueAfterMaturityTermByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetDueAfterMaturityTermByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetDueAfterMaturityTermByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueAfterMaturityTermByEmployee, params=params, data=data)

@overload
def GetObligationByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetObligationByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetObligationByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetObligationByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationByEmployee, params=params, data=data)

@overload
def GetObligationNotSettledByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationNotSettledByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationNotSettledByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetObligationNotSettledByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetObligationNotSettledByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetObligationNotSettledByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationNotSettledByEmployee, params=params, data=data)

@overload
def GetObligationBeforeMaturityTermByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationBeforeMaturityTermByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationBeforeMaturityTermByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetObligationBeforeMaturityTermByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetObligationBeforeMaturityTermByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetObligationBeforeMaturityTermByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationBeforeMaturityTermByEmployee, params=params, data=data)

@overload
def GetObligationAfterMaturityTermByEmployee(api: SyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationAfterMaturityTermByEmployee(api: SyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]]: ...
@overload
def GetObligationAfterMaturityTermByEmployee(api: AsyncInvokerProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
@overload
def GetObligationAfterMaturityTermByEmployee(api: AsyncRequestProtocol, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElement]]]: ...
def GetObligationAfterMaturityTermByEmployee(api: object, employeePosition: int, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElement]] | Awaitable[ResponseEnvelope[List[CalculationListElement]]]:
    params, data = _prepare_GetObligationAfterMaturityTermByEmployee(employeePosition=employeePosition, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationAfterMaturityTermByEmployee, params=params, data=data)

@overload
def GetDueGroupedBySubject(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetDueGroupedBySubject(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetDueGroupedBySubject(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
@overload
def GetDueGroupedBySubject(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
def GetDueGroupedBySubject(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]] | Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]:
    params, data = _prepare_GetDueGroupedBySubject(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueGroupedBySubject, params=params, data=data)

@overload
def GetDueNotSettledGroupedBySubject(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetDueNotSettledGroupedBySubject(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetDueNotSettledGroupedBySubject(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
@overload
def GetDueNotSettledGroupedBySubject(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
def GetDueNotSettledGroupedBySubject(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]] | Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]:
    params, data = _prepare_GetDueNotSettledGroupedBySubject(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueNotSettledGroupedBySubject, params=params, data=data)

@overload
def GetDueBeforeMaturityTermGroupedBySubject(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetDueBeforeMaturityTermGroupedBySubject(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetDueBeforeMaturityTermGroupedBySubject(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
@overload
def GetDueBeforeMaturityTermGroupedBySubject(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
def GetDueBeforeMaturityTermGroupedBySubject(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]] | Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]:
    params, data = _prepare_GetDueBeforeMaturityTermGroupedBySubject(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueBeforeMaturityTermGroupedBySubject, params=params, data=data)

@overload
def GetDueAfterMaturityTermGroupedBySubject(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetDueAfterMaturityTermGroupedBySubject(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetDueAfterMaturityTermGroupedBySubject(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
@overload
def GetDueAfterMaturityTermGroupedBySubject(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
def GetDueAfterMaturityTermGroupedBySubject(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]] | Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]:
    params, data = _prepare_GetDueAfterMaturityTermGroupedBySubject(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDueAfterMaturityTermGroupedBySubject, params=params, data=data)

@overload
def GetObligationGroupedBySubject(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetObligationGroupedBySubject(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetObligationGroupedBySubject(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
@overload
def GetObligationGroupedBySubject(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
def GetObligationGroupedBySubject(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]] | Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]:
    params, data = _prepare_GetObligationGroupedBySubject(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationGroupedBySubject, params=params, data=data)

@overload
def GetObligationNotSettledGroupedBySubject(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetObligationNotSettledGroupedBySubject(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetObligationNotSettledGroupedBySubject(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
@overload
def GetObligationNotSettledGroupedBySubject(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
def GetObligationNotSettledGroupedBySubject(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]] | Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]:
    params, data = _prepare_GetObligationNotSettledGroupedBySubject(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationNotSettledGroupedBySubject, params=params, data=data)

@overload
def GetObligationBeforeMaturityTermGroupedBySubject(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetObligationBeforeMaturityTermGroupedBySubject(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetObligationBeforeMaturityTermGroupedBySubject(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
@overload
def GetObligationBeforeMaturityTermGroupedBySubject(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
def GetObligationBeforeMaturityTermGroupedBySubject(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]] | Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]:
    params, data = _prepare_GetObligationBeforeMaturityTermGroupedBySubject(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationBeforeMaturityTermGroupedBySubject, params=params, data=data)

@overload
def GetObligationAfterMaturityTermGroupedBySubject(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetObligationAfterMaturityTermGroupedBySubject(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]]: ...
@overload
def GetObligationAfterMaturityTermGroupedBySubject(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
@overload
def GetObligationAfterMaturityTermGroupedBySubject(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]: ...
def GetObligationAfterMaturityTermGroupedBySubject(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[CalculationListElementGrouped]] | Awaitable[ResponseEnvelope[List[CalculationListElementGrouped]]]:
    params, data = _prepare_GetObligationAfterMaturityTermGroupedBySubject(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetObligationAfterMaturityTermGroupedBySubject, params=params, data=data)

__all__ = ["Custom", "GetByContractor", "GetNotSettledByContractor", "GetBeforeMaturityTermByContractor", "GetAfterMaturityTermByContractor", "GetDueByContractor", "GetDueNotSettledByContractor", "GetDueBeforeMaturityTermByContractor", "GetDueAfterMaturityTermByContractor", "GetObligationByContractor", "GetObligationNotSettledByContractor", "GetObligationBeforeMaturityTermByContractor", "GetObligationAfterMaturityTermByContractor", "GetByEmployee", "GetNotSettledByEmployee", "GetBeforeMaturityTermByEmployee", "GetAfterMaturityTermByEmployee", "GetDueByEmployee", "GetDueNotSettledByEmployee", "GetDueBeforeMaturityTermByEmployee", "GetDueAfterMaturityTermByEmployee", "GetObligationByEmployee", "GetObligationNotSettledByEmployee", "GetObligationBeforeMaturityTermByEmployee", "GetObligationAfterMaturityTermByEmployee", "GetDueGroupedBySubject", "GetDueNotSettledGroupedBySubject", "GetDueBeforeMaturityTermGroupedBySubject", "GetDueAfterMaturityTermGroupedBySubject", "GetObligationGroupedBySubject", "GetObligationNotSettledGroupedBySubject", "GetObligationBeforeMaturityTermGroupedBySubject", "GetObligationAfterMaturityTermGroupedBySubject"]
