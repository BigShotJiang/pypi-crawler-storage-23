from __future__ import annotations

from typing import Any

_REQUEST_Custom = ('GET', '/api/FKCalculations/CustomFilter')
def _prepare_Custom(*, options) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = options.model_dump_json(exclude_unset=True) if options is not None else None
    return params or None, data

_REQUEST_GetByContractor = ('GET', '/api/FKCalculations/Filter')
def _prepare_GetByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetNotSettledByContractor = ('GET', '/api/FKCalculations/Filter/NotSettled')
def _prepare_GetNotSettledByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetBeforeMaturityTermByContractor = ('GET', '/api/FKCalculations/Filter/BeforeMaturityTerm')
def _prepare_GetBeforeMaturityTermByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetAfterMaturityTermByContractor = ('GET', '/api/FKCalculations/Filter/AfterMaturityTerm')
def _prepare_GetAfterMaturityTermByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueByContractor = ('GET', '/api/FKCalculations/Filter/Due')
def _prepare_GetDueByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueNotSettledByContractor = ('GET', '/api/FKCalculations/Filter/Due/NotSettled')
def _prepare_GetDueNotSettledByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueBeforeMaturityTermByContractor = ('GET', '/api/FKCalculations/Filter/Due/BeforeMaturityTerm')
def _prepare_GetDueBeforeMaturityTermByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueAfterMaturityTermByContractor = ('GET', '/api/FKCalculations/Filter/Due/AfterMaturityTerm')
def _prepare_GetDueAfterMaturityTermByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationByContractor = ('GET', '/api/FKCalculations/Filter/Obligation')
def _prepare_GetObligationByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationNotSettledByContractor = ('GET', '/api/FKCalculations/Filter/Obligation/NotSettled')
def _prepare_GetObligationNotSettledByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationBeforeMaturityTermByContractor = ('GET', '/api/FKCalculations/Filter/Obligation/BeforeMaturityTerm')
def _prepare_GetObligationBeforeMaturityTermByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationAfterMaturityTermByContractor = ('GET', '/api/FKCalculations/Filter/Obligation/AfterMaturityTerm')
def _prepare_GetObligationAfterMaturityTermByContractor(*, contractorPosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["contractorPosition"] = contractorPosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetByEmployee = ('GET', '/api/FKCalculations/Filter')
def _prepare_GetByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetNotSettledByEmployee = ('GET', '/api/FKCalculations/Filter/NotSettled')
def _prepare_GetNotSettledByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetBeforeMaturityTermByEmployee = ('GET', '/api/FKCalculations/Filter/BeforeMaturityTerm')
def _prepare_GetBeforeMaturityTermByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetAfterMaturityTermByEmployee = ('GET', '/api/FKCalculations/Filter/AfterMaturityTerm')
def _prepare_GetAfterMaturityTermByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueByEmployee = ('GET', '/api/FKCalculations/Filter/Due')
def _prepare_GetDueByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueNotSettledByEmployee = ('GET', '/api/FKCalculations/Filter/Due/NotSettled')
def _prepare_GetDueNotSettledByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueBeforeMaturityTermByEmployee = ('GET', '/api/FKCalculations/Filter/Due/BeforeMaturityTerm')
def _prepare_GetDueBeforeMaturityTermByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueAfterMaturityTermByEmployee = ('GET', '/api/FKCalculations/Filter/Due/AfterMaturityTerm')
def _prepare_GetDueAfterMaturityTermByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationByEmployee = ('GET', '/api/FKCalculations/Filter/Obligation')
def _prepare_GetObligationByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationNotSettledByEmployee = ('GET', '/api/FKCalculations/Filter/Obligation/NotSettled')
def _prepare_GetObligationNotSettledByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationBeforeMaturityTermByEmployee = ('GET', '/api/FKCalculations/Filter/Obligation/BeforeMaturityTerm')
def _prepare_GetObligationBeforeMaturityTermByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationAfterMaturityTermByEmployee = ('GET', '/api/FKCalculations/Filter/Obligation/AfterMaturityTerm')
def _prepare_GetObligationAfterMaturityTermByEmployee(*, employeePosition, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["employeePosition"] = employeePosition
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueGroupedBySubject = ('GET', '/api/FKCalculations/Grouped/Due')
def _prepare_GetDueGroupedBySubject(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueNotSettledGroupedBySubject = ('GET', '/api/FKCalculations/Grouped/Due/NotSettled')
def _prepare_GetDueNotSettledGroupedBySubject(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueBeforeMaturityTermGroupedBySubject = ('GET', '/api/FKCalculations/Grouped/Due/BeforeMaturityTerm')
def _prepare_GetDueBeforeMaturityTermGroupedBySubject(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetDueAfterMaturityTermGroupedBySubject = ('GET', '/api/FKCalculations/Grouped/Due/AfterMaturityTerm')
def _prepare_GetDueAfterMaturityTermGroupedBySubject(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationGroupedBySubject = ('GET', '/api/FKCalculations/Grouped/Obligation')
def _prepare_GetObligationGroupedBySubject(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationNotSettledGroupedBySubject = ('GET', '/api/FKCalculations/Grouped/Obligation/NotSettled')
def _prepare_GetObligationNotSettledGroupedBySubject(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationBeforeMaturityTermGroupedBySubject = ('GET', '/api/FKCalculations/Grouped/Obligation/BeforeMaturityTerm')
def _prepare_GetObligationBeforeMaturityTermGroupedBySubject(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data

_REQUEST_GetObligationAfterMaturityTermGroupedBySubject = ('GET', '/api/FKCalculations/Grouped/Obligation/AfterMaturityTerm')
def _prepare_GetObligationAfterMaturityTermGroupedBySubject(*, dateFrom = None, dateTo = None) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    if dateFrom is not None:
        params["dateFrom"] = dateFrom
    if dateTo is not None:
        params["dateTo"] = dateTo
    data = None
    return params or None, data
