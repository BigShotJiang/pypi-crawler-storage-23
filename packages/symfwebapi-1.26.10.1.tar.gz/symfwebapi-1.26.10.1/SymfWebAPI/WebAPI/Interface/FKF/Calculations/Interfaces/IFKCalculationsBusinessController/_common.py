from __future__ import annotations

from typing import Any

_REQUEST_BalanceAndTurnoverAsync = ('GET', '/api/FKCalculationsBusiness/BalanceAndTurnover')
def _prepare_BalanceAndTurnoverAsync(*, options) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = options.model_dump_json(exclude_unset=True) if options is not None else None
    return params or None, data
