from __future__ import annotations

from typing import List, Optional
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Calculations.ViewModels import CalculationFilterOptions
from SymfWebAPI.WebAPI.Interface.FKF.Calculations.ViewModels import CalculationListElement
from SymfWebAPI.WebAPI.Interface.FKF.Calculations.ViewModels import CalculationListElementGrouped

_ADAPTER_Custom = TypeAdapter(List[CalculationListElement])

def _parse_Custom(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_Custom)
OP_Custom = OperationSpec(method='GET', path='/api/FKCalculations/CustomFilter', parser=_parse_Custom)

_ADAPTER_GetByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByContractor)
OP_GetByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter', parser=_parse_GetByContractor)

_ADAPTER_GetNotSettledByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetNotSettledByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetNotSettledByContractor)
OP_GetNotSettledByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter/NotSettled', parser=_parse_GetNotSettledByContractor)

_ADAPTER_GetBeforeMaturityTermByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetBeforeMaturityTermByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetBeforeMaturityTermByContractor)
OP_GetBeforeMaturityTermByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter/BeforeMaturityTerm', parser=_parse_GetBeforeMaturityTermByContractor)

_ADAPTER_GetAfterMaturityTermByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetAfterMaturityTermByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetAfterMaturityTermByContractor)
OP_GetAfterMaturityTermByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter/AfterMaturityTerm', parser=_parse_GetAfterMaturityTermByContractor)

_ADAPTER_GetDueByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetDueByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueByContractor)
OP_GetDueByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Due', parser=_parse_GetDueByContractor)

_ADAPTER_GetDueNotSettledByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetDueNotSettledByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueNotSettledByContractor)
OP_GetDueNotSettledByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Due/NotSettled', parser=_parse_GetDueNotSettledByContractor)

_ADAPTER_GetDueBeforeMaturityTermByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetDueBeforeMaturityTermByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueBeforeMaturityTermByContractor)
OP_GetDueBeforeMaturityTermByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Due/BeforeMaturityTerm', parser=_parse_GetDueBeforeMaturityTermByContractor)

_ADAPTER_GetDueAfterMaturityTermByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetDueAfterMaturityTermByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueAfterMaturityTermByContractor)
OP_GetDueAfterMaturityTermByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Due/AfterMaturityTerm', parser=_parse_GetDueAfterMaturityTermByContractor)

_ADAPTER_GetObligationByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetObligationByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationByContractor)
OP_GetObligationByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Obligation', parser=_parse_GetObligationByContractor)

_ADAPTER_GetObligationNotSettledByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetObligationNotSettledByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationNotSettledByContractor)
OP_GetObligationNotSettledByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Obligation/NotSettled', parser=_parse_GetObligationNotSettledByContractor)

_ADAPTER_GetObligationBeforeMaturityTermByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetObligationBeforeMaturityTermByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationBeforeMaturityTermByContractor)
OP_GetObligationBeforeMaturityTermByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Obligation/BeforeMaturityTerm', parser=_parse_GetObligationBeforeMaturityTermByContractor)

_ADAPTER_GetObligationAfterMaturityTermByContractor = TypeAdapter(List[CalculationListElement])

def _parse_GetObligationAfterMaturityTermByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationAfterMaturityTermByContractor)
OP_GetObligationAfterMaturityTermByContractor = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Obligation/AfterMaturityTerm', parser=_parse_GetObligationAfterMaturityTermByContractor)

_ADAPTER_GetByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetByEmployee)
OP_GetByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter', parser=_parse_GetByEmployee)

_ADAPTER_GetNotSettledByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetNotSettledByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetNotSettledByEmployee)
OP_GetNotSettledByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter/NotSettled', parser=_parse_GetNotSettledByEmployee)

_ADAPTER_GetBeforeMaturityTermByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetBeforeMaturityTermByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetBeforeMaturityTermByEmployee)
OP_GetBeforeMaturityTermByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter/BeforeMaturityTerm', parser=_parse_GetBeforeMaturityTermByEmployee)

_ADAPTER_GetAfterMaturityTermByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetAfterMaturityTermByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetAfterMaturityTermByEmployee)
OP_GetAfterMaturityTermByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter/AfterMaturityTerm', parser=_parse_GetAfterMaturityTermByEmployee)

_ADAPTER_GetDueByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetDueByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueByEmployee)
OP_GetDueByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Due', parser=_parse_GetDueByEmployee)

_ADAPTER_GetDueNotSettledByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetDueNotSettledByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueNotSettledByEmployee)
OP_GetDueNotSettledByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Due/NotSettled', parser=_parse_GetDueNotSettledByEmployee)

_ADAPTER_GetDueBeforeMaturityTermByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetDueBeforeMaturityTermByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueBeforeMaturityTermByEmployee)
OP_GetDueBeforeMaturityTermByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Due/BeforeMaturityTerm', parser=_parse_GetDueBeforeMaturityTermByEmployee)

_ADAPTER_GetDueAfterMaturityTermByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetDueAfterMaturityTermByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueAfterMaturityTermByEmployee)
OP_GetDueAfterMaturityTermByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Due/AfterMaturityTerm', parser=_parse_GetDueAfterMaturityTermByEmployee)

_ADAPTER_GetObligationByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetObligationByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationByEmployee)
OP_GetObligationByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Obligation', parser=_parse_GetObligationByEmployee)

_ADAPTER_GetObligationNotSettledByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetObligationNotSettledByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationNotSettledByEmployee)
OP_GetObligationNotSettledByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Obligation/NotSettled', parser=_parse_GetObligationNotSettledByEmployee)

_ADAPTER_GetObligationBeforeMaturityTermByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetObligationBeforeMaturityTermByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationBeforeMaturityTermByEmployee)
OP_GetObligationBeforeMaturityTermByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Obligation/BeforeMaturityTerm', parser=_parse_GetObligationBeforeMaturityTermByEmployee)

_ADAPTER_GetObligationAfterMaturityTermByEmployee = TypeAdapter(List[CalculationListElement])

def _parse_GetObligationAfterMaturityTermByEmployee(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationAfterMaturityTermByEmployee)
OP_GetObligationAfterMaturityTermByEmployee = OperationSpec(method='GET', path='/api/FKCalculations/Filter/Obligation/AfterMaturityTerm', parser=_parse_GetObligationAfterMaturityTermByEmployee)

_ADAPTER_GetDueGroupedBySubject = TypeAdapter(List[CalculationListElementGrouped])

def _parse_GetDueGroupedBySubject(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElementGrouped]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueGroupedBySubject)
OP_GetDueGroupedBySubject = OperationSpec(method='GET', path='/api/FKCalculations/Grouped/Due', parser=_parse_GetDueGroupedBySubject)

_ADAPTER_GetDueNotSettledGroupedBySubject = TypeAdapter(List[CalculationListElementGrouped])

def _parse_GetDueNotSettledGroupedBySubject(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElementGrouped]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueNotSettledGroupedBySubject)
OP_GetDueNotSettledGroupedBySubject = OperationSpec(method='GET', path='/api/FKCalculations/Grouped/Due/NotSettled', parser=_parse_GetDueNotSettledGroupedBySubject)

_ADAPTER_GetDueBeforeMaturityTermGroupedBySubject = TypeAdapter(List[CalculationListElementGrouped])

def _parse_GetDueBeforeMaturityTermGroupedBySubject(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElementGrouped]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueBeforeMaturityTermGroupedBySubject)
OP_GetDueBeforeMaturityTermGroupedBySubject = OperationSpec(method='GET', path='/api/FKCalculations/Grouped/Due/BeforeMaturityTerm', parser=_parse_GetDueBeforeMaturityTermGroupedBySubject)

_ADAPTER_GetDueAfterMaturityTermGroupedBySubject = TypeAdapter(List[CalculationListElementGrouped])

def _parse_GetDueAfterMaturityTermGroupedBySubject(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElementGrouped]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDueAfterMaturityTermGroupedBySubject)
OP_GetDueAfterMaturityTermGroupedBySubject = OperationSpec(method='GET', path='/api/FKCalculations/Grouped/Due/AfterMaturityTerm', parser=_parse_GetDueAfterMaturityTermGroupedBySubject)

_ADAPTER_GetObligationGroupedBySubject = TypeAdapter(List[CalculationListElementGrouped])

def _parse_GetObligationGroupedBySubject(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElementGrouped]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationGroupedBySubject)
OP_GetObligationGroupedBySubject = OperationSpec(method='GET', path='/api/FKCalculations/Grouped/Obligation', parser=_parse_GetObligationGroupedBySubject)

_ADAPTER_GetObligationNotSettledGroupedBySubject = TypeAdapter(List[CalculationListElementGrouped])

def _parse_GetObligationNotSettledGroupedBySubject(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElementGrouped]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationNotSettledGroupedBySubject)
OP_GetObligationNotSettledGroupedBySubject = OperationSpec(method='GET', path='/api/FKCalculations/Grouped/Obligation/NotSettled', parser=_parse_GetObligationNotSettledGroupedBySubject)

_ADAPTER_GetObligationBeforeMaturityTermGroupedBySubject = TypeAdapter(List[CalculationListElementGrouped])

def _parse_GetObligationBeforeMaturityTermGroupedBySubject(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElementGrouped]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationBeforeMaturityTermGroupedBySubject)
OP_GetObligationBeforeMaturityTermGroupedBySubject = OperationSpec(method='GET', path='/api/FKCalculations/Grouped/Obligation/BeforeMaturityTerm', parser=_parse_GetObligationBeforeMaturityTermGroupedBySubject)

_ADAPTER_GetObligationAfterMaturityTermGroupedBySubject = TypeAdapter(List[CalculationListElementGrouped])

def _parse_GetObligationAfterMaturityTermGroupedBySubject(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[CalculationListElementGrouped]]:
    return parse_with_adapter(envelope, _ADAPTER_GetObligationAfterMaturityTermGroupedBySubject)
OP_GetObligationAfterMaturityTermGroupedBySubject = OperationSpec(method='GET', path='/api/FKCalculations/Grouped/Obligation/AfterMaturityTerm', parser=_parse_GetObligationAfterMaturityTermGroupedBySubject)
