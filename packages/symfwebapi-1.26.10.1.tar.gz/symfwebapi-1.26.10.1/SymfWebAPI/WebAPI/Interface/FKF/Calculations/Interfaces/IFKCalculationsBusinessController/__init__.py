from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Calculations.ViewModels import BalanceAndTurnoverFilterOptions
from SymfWebAPI.WebAPI.Interface.FKF.Calculations.ViewModels import BalanceAndTurnoverListElement
from ._common import (
    _prepare_BalanceAndTurnoverAsync,
)
from ._ops import (
    OP_BalanceAndTurnoverAsync,
)

@overload
def BalanceAndTurnoverAsync(api: SyncInvokerProtocol, options: "BalanceAndTurnoverFilterOptions") -> ResponseEnvelope[List[BalanceAndTurnoverListElement]]: ...
@overload
def BalanceAndTurnoverAsync(api: SyncRequestProtocol, options: "BalanceAndTurnoverFilterOptions") -> ResponseEnvelope[List[BalanceAndTurnoverListElement]]: ...
@overload
def BalanceAndTurnoverAsync(api: AsyncInvokerProtocol, options: "BalanceAndTurnoverFilterOptions") -> Awaitable[ResponseEnvelope[List[BalanceAndTurnoverListElement]]]: ...
@overload
def BalanceAndTurnoverAsync(api: AsyncRequestProtocol, options: "BalanceAndTurnoverFilterOptions") -> Awaitable[ResponseEnvelope[List[BalanceAndTurnoverListElement]]]: ...
def BalanceAndTurnoverAsync(api: object, options: "BalanceAndTurnoverFilterOptions") -> ResponseEnvelope[List[BalanceAndTurnoverListElement]] | Awaitable[ResponseEnvelope[List[BalanceAndTurnoverListElement]]]:
    params, data = _prepare_BalanceAndTurnoverAsync(options=options)
    return invoke_operation(api, OP_BalanceAndTurnoverAsync, params=params, data=data)

__all__ = ["BalanceAndTurnoverAsync"]
