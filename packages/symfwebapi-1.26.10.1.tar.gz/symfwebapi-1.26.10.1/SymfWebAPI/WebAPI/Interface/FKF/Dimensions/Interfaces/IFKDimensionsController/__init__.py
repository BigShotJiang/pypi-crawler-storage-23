from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.V2026_1 import Document
from ._common import (
    _prepare_GetAccountChartByIdAndYear,
    _prepare_GetDocumentByIdAndYear,
)
from ._ops import (
    OP_GetAccountChartByIdAndYear,
    OP_GetDocumentByIdAndYear,
)

@overload
def GetAccountChartByIdAndYear(api: SyncInvokerProtocol, id: int, yearId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetAccountChartByIdAndYear(api: SyncRequestProtocol, id: int, yearId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def GetAccountChartByIdAndYear(api: AsyncInvokerProtocol, id: int, yearId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def GetAccountChartByIdAndYear(api: AsyncRequestProtocol, id: int, yearId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def GetAccountChartByIdAndYear(api: object, id: int, yearId: int) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_GetAccountChartByIdAndYear(id=id, yearId=yearId)
    return invoke_operation(api, OP_GetAccountChartByIdAndYear, params=params, data=data)

@overload
def GetDocumentByIdAndYear(api: SyncInvokerProtocol, id: int, yearId: int) -> ResponseEnvelope[Document]: ...
@overload
def GetDocumentByIdAndYear(api: SyncRequestProtocol, id: int, yearId: int) -> ResponseEnvelope[Document]: ...
@overload
def GetDocumentByIdAndYear(api: AsyncInvokerProtocol, id: int, yearId: int) -> Awaitable[ResponseEnvelope[Document]]: ...
@overload
def GetDocumentByIdAndYear(api: AsyncRequestProtocol, id: int, yearId: int) -> Awaitable[ResponseEnvelope[Document]]: ...
def GetDocumentByIdAndYear(api: object, id: int, yearId: int) -> ResponseEnvelope[Document] | Awaitable[ResponseEnvelope[Document]]:
    params, data = _prepare_GetDocumentByIdAndYear(id=id, yearId=yearId)
    return invoke_operation(api, OP_GetDocumentByIdAndYear, params=params, data=data)

__all__ = ["GetAccountChartByIdAndYear", "GetDocumentByIdAndYear"]
