from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension
from SymfWebAPI.WebAPI.Interface.FKF.Documents.ViewModels.V2026_1 import Document

_ADAPTER_GetAccountChartByIdAndYear = TypeAdapter(List[Dimension])

def _parse_GetAccountChartByIdAndYear(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Dimension]]:
    return parse_with_adapter(envelope, _ADAPTER_GetAccountChartByIdAndYear)
OP_GetAccountChartByIdAndYear = OperationSpec(method='GET', path='/api/FKDimensions/AccountChart', parser=_parse_GetAccountChartByIdAndYear)

_ADAPTER_GetDocumentByIdAndYear = TypeAdapter(Document)

def _parse_GetDocumentByIdAndYear(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Document]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentByIdAndYear)
OP_GetDocumentByIdAndYear = OperationSpec(method='GET', path='/api/FKDimensions/Document', parser=_parse_GetDocumentByIdAndYear)
