from __future__ import annotations

from typing import Any

_REQUEST_GetAccountChartByIdAndYear = ('GET', '/api/FKDimensions/AccountChart')
def _prepare_GetAccountChartByIdAndYear(*, id, yearId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    params["yearId"] = yearId
    data = None
    return params or None, data

_REQUEST_GetDocumentByIdAndYear = ('GET', '/api/FKDimensions/Document')
def _prepare_GetDocumentByIdAndYear(*, id, yearId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    params["yearId"] = yearId
    data = None
    return params or None, data
