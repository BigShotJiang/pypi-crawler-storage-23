from __future__ import annotations

from SymfWebAPI.enums import ForwardCompatibleEnum

class enumAccountingSchemePositionType(ForwardCompatibleEnum):
    Basic = 0
    Additional01 = 1
    Additional02 = 2
    Additional03 = 3
    Additional04 = 4
    Additional05 = 5
    Additional06 = 6
    Additional07 = 7
    Additional08 = 8
    Additional09 = 9
    Additional10 = 10

class enumCalculationState(ForwardCompatibleEnum):
    All = 0
    Settled = 1
    NotSettled = 2
    NotSettledBeforeMaturityTerm = 3
    NotSettledAfterMaturityTerm = 4
    NotSettledWithoutMaturityTerm = 5

class enumCalculationType(ForwardCompatibleEnum):
    Due = 0
    Obligation = 1
    All = 3

class enumCancelationType(ForwardCompatibleEnum):
    Other = 0
    Standard = 1
    ImportedFromArchive = 2
    CanceledReceipt = 3

class enumContractorSplitPayment(ForwardCompatibleEnum):
    VALUE_0 = 0
    Blocked = 1
    Required = 2

class enumContractorType(ForwardCompatibleEnum):
    Firm = 0
    PersonFirm = 1
    Person = 2

class enumCurrencyRateType(ForwardCompatibleEnum):
    WithoutCurrency = 0
    Purchase = 1
    Sale = 2
    Mean = 3

class enumDefaultUnitOfMeasurementKind(ForwardCompatibleEnum):
    VALUE_0 = 0
    Record = 1
    Additional1 = 2
    Additional2 = 3

class enumDocumentReservationType(ForwardCompatibleEnum):
    VALUE_0 = 0
    Qunatity = 1
    IndicationDelivery = 2

class enumDocumentSource(ForwardCompatibleEnum):
    AccountingBooks = 0
    Buffer = 1
    Schemes = 2

class enumDocumentStatus(ForwardCompatibleEnum):
    Other = 0
    New = 4
    Partial = 8
    Realized = 16
    Closed = 32

class enumFKDocumentCharacter(ForwardCompatibleEnum):
    DP = 1
    FVZ = 2
    FVS = 3
    RUZ = 4
    RUS = 5
    RK = 6
    RK_Old = 7
    DEX = 8
    DIM = 9
    FKZ = 10
    FKS = 11
    RKZ = 12
    RKS = 13
    WB = 14
    RZL = 15
    FWN = 16
    WNT = 17
    WDT = 18
    PWN = 19
    FWV = 20
    RKW = 21
    FWZ = 22
    FWS = 23
    KFWZ = 24
    KFWS = 25
    DS = 26
    WBW = 27

class enumFKDocumentMessageType(ForwardCompatibleEnum):
    Comments = 0
    Warning = 1
    Error = 2

class enumFKSplitPaymentType(ForwardCompatibleEnum):
    VALUE_0 = 0
    SplitPayment = 1
    VoluntarySplitPayment = 3
    TaxPayerRegister = 4
    TaxPayerRegister_SplitPayment = 5
    TaxPayerRegister_VoluntarySplitPayment = 7

class enumFilterCriteriaMode(ForwardCompatibleEnum):
    Within = 0
    StartsWith = 1

class enumFilterSqlCriteriaMode(ForwardCompatibleEnum):
    Within = 0
    Equals = 1
    Like = 2

class enumFiscalizationStatus(ForwardCompatibleEnum):
    NonFiscal = 0
    ToFiscalization = 1
    Fiscializated = 2

class enumIncrementalSyncModifyType(ForwardCompatibleEnum):
    InsertOrUpdate = 1
    Delete = 2

class enumIndividualDiscountSubjectType(ForwardCompatibleEnum):
    Contractor = 0
    ContractorKind = 1
    Product = 2
    ProductKind = 3

class enumJPK_V7DocumentAttribute(ForwardCompatibleEnum):
    VALUE_0 = 0
    RO = 1
    WEW = 2
    FP = 4
    MK = 8
    VAT_RR = 16
    SW = 32
    EE = 64
    TP = 128
    TT_WNT = 256
    TT_D = 512
    MR_T = 1024
    MR_UZ = 2048
    I_42 = 4096
    I_63 = 8192
    B_SPV = 16384
    B_SPV_DOSTAWA = 32768
    B_MPV_PROWIZJA = 65536
    MPP = 131072
    IMP = 262144
    IED = 524288
    WSTO_EE = 1048576

class enumJPK_V7ProductGroup(ForwardCompatibleEnum):
    VALUE_0 = 0
    GTU_01 = 1
    GTU_02 = 2
    GTU_03 = 4
    GTU_04 = 8
    GTU_05 = 16
    GTU_06 = 32
    GTU_07 = 64
    GTU_08 = 128
    GTU_09 = 256
    GTU_10 = 512
    GTU_11 = 1024
    GTU_12 = 2048
    GTU_13 = 4096

class enumKSeFInvoiceStatus(ForwardCompatibleEnum):
    NOT_KSEF_FORMAT = 0
    WAITING_TO_BE_SENT_TO_KSEF_MODULE = 10
    ERROR_SENDING_TO_KSEF_MODULE = 20
    SENDING = 25
    NOT_SENT_TO_KSEF = 30
    ERROR = 40
    PENDING_FOR_VALIDATION_BY_KSEF = 50
    APPROVED_BY_KSEF = 60
    REJECTED_BY_KSEF = 70

class enumManualSettledState(ForwardCompatibleEnum):
    Automatic = 0
    Manual_NotSettled = 1
    Manual_Settled = 2

class enumOrderByType(ForwardCompatibleEnum):
    Desc = 0
    Asc = 1

class enumOssDeliveryKind(ForwardCompatibleEnum):
    Product = 1
    Service = 2

class enumParallelType(ForwardCompatibleEnum):
    Undefined = 0
    Parallel = 1
    StandardWithOnRequestParallel = 2
    StandardWithAutomaticParallel = 4
    ParallelOnDebit = 8
    ParallelOnCredit = 16
    OnRequestParallel = 32
    StuckParallel = 64

class enumPaymentRegistryType(ForwardCompatibleEnum):
    Cash = 0
    Bank = 1
    Other = 2

class enumPaymentSubjectType(ForwardCompatibleEnum):
    Contractor = 0
    PaymentRegistry = 104
    Employee = 106
    Office = 107

class enumPaymentType(ForwardCompatibleEnum):
    Income = 0
    Expenditure = 1

class enumPhotoQuality(ForwardCompatibleEnum):
    Original = 0
    Medium = 1
    Low = 2

class enumPriceCalculationMethod(ForwardCompatibleEnum):
    Handel = 0
    Algorithm = 1

class enumPriceFactorType(ForwardCompatibleEnum):
    Discount = 0
    Price = 1

class enumPriceKind(ForwardCompatibleEnum):
    Undefined = 0
    Gross = 1
    Net = 2

class enumPriceListConnectionType(ForwardCompatibleEnum):
    Individual = 1
    LinkedWithCardIndexAndIndividualDiscounts = 2
    LinkedWithCardIndexAndIndividualDiscountsAndOtherPriceLists = 3

class enumPriceParameter(ForwardCompatibleEnum):
    Profit = 1
    Markup = 2

class enumPriceRecalculateType(ForwardCompatibleEnum):
    PurchasePriceAndBasePriceAreNotAgreed = 0
    AutomaticallyAtEveryPurchasePriceChange = 1
    AutomaticallyWhenPurchasePriceIsHigherThanBasePrice = 2
    ManuallyAtEveryPurchasePriceChange = 3
    ManuallyWhenPurchasePriceIsHigherThanBasePrice = 4

class enumPriceRounding(ForwardCompatibleEnum):
    _0_0001 = 6
    _0_001 = 5
    _0_01 = 0
    _0_10 = 1
    _1_00 = 2
    _10_00 = 3
    _100_00 = 4

class enumPriceType(ForwardCompatibleEnum):
    Undefined = 0
    PriceA = 1
    PriceB = 2
    PriceC = 3
    PriceD = 4
    Price_Individual = 5
    Price_Purchase = 6
    Price_Purchase_In_Currency = 7
    Price_Base = 8
    Other = 9
    Duty = 10
    Excise = 11
    Quantitative_Discount = 12
    Sale_Currency_Exchange_Rate = 13
    Purchase_Currency_Exchange_Rate = 14
    Contractor_Discount = 15
    PriceE = 16
    PriceF = 17
    PriceG = 18
    PriceH = 19
    PriceI = 20
    PriceJ = 21
    PriceK = 22
    PriceL = 23
    PriceM = 24
    PriceN = 25
    PriceO = 26
    PriceP = 27
    PriceQ = 28
    PriceR = 29
    PriceS = 30
    PriceT = 31

class enumPrintParameterDocumentStatus(ForwardCompatibleEnum):
    Automatic = 0
    Original = 1
    Copy = 2
    Original_Copy = 3
    Empty = 4
    Custom = 5

class enumPrintParameterNotSettledDocuments(ForwardCompatibleEnum):
    DoNotPrint = 0
    PrintForIssueDate = 1
    PrintForPrintDate = 2

class enumPrintParameterOperationDateFormat(ForwardCompatibleEnum):
    OperationDate = 0
    OperationPeriod = 1

class enumProductType(ForwardCompatibleEnum):
    Article = 0
    Service = 1
    Kit = 2
    Set = 3
    ServiceProfit = 4

class enumRDFStatus(ForwardCompatibleEnum):
    NoInvoice = 0
    InvoiceNotPrinted = 1
    InvoicePrinted = 2

class enumRecordDecsriptionKind(ForwardCompatibleEnum):
    FromDocument = 0
    FromRecord = 1
    FromFirstRecord = 2

class enumRepXReportText(ForwardCompatibleEnum):
    Empty = 0
    Original = 1
    Copy = 2
    Original_Copy = 3
    Duplicate = 4

class enumReservationDocumentType(ForwardCompatibleEnum):
    Unknown = 0
    SaleDocument = 16
    WarehouseDocument = 33
    ForeignOrder = 45

class enumReservationKind(ForwardCompatibleEnum):
    FIFO_IndicationDelivery = 0
    FIFO_Quantity = 1
    LIFO_IndicationDelivery = 2
    LIFO_Quantity = 3

class enumReservationMode(ForwardCompatibleEnum):
    MadeByUser = 1
    MadeByProgram = 2

class enumReservationPositionType(ForwardCompatibleEnum):
    Unknown = 0
    SaleDocument = 18
    WarehouseDocument = 37
    ForeignOrder = 30

class enumReservationType(ForwardCompatibleEnum):
    Manual = 1
    Automatic = 2

class enumSalePriceType(ForwardCompatibleEnum):
    Undefined = 0
    PriceA = 1
    PriceB = 2
    PriceC = 3
    PriceD = 4
    PriceE = 16
    PriceF = 17
    PriceG = 18
    PriceH = 19
    PriceI = 20
    PriceJ = 21
    PriceK = 22
    PriceL = 23
    PriceM = 24
    PriceN = 25
    PriceO = 26
    PriceP = 27
    PriceQ = 28
    PriceR = 29
    PriceS = 30
    PriceT = 31

class enumSettlementMethod(ForwardCompatibleEnum):
    FIFO = 0
    LIFO = 1

class enumSettlementType(ForwardCompatibleEnum):
    Due = 0
    Obligation = 1

class enumSideType(ForwardCompatibleEnum):
    Debit = 0
    Credit = 1

class enumSplitOpposingAccountType(ForwardCompatibleEnum):
    Debit_SplitInCreaditWithMultipleOpposingAccounts = 99
    Debit_SplitInDebitWithSingleOpposingAccount = 101
    Debit_WithoutSplitWithSingleOpposingAccount = 103
    Credit_SplitInDebitWithMultipleOpposingAccounts = 199
    Credit_SplitInCreditWithSingleOpposingAccount = 201
    Credit_WithoutSplitWithSingleOpposingAccount = 203

class enumSplitType(ForwardCompatibleEnum):
    VALUE_0 = 0
    SplitInDebit = 1
    SplitInCredit = 2

class enumSplitValueType(ForwardCompatibleEnum):
    Value = 0
    Percent = 1

class enumSubjectType(ForwardCompatibleEnum):
    Empty_Null = -1
    Other = 0
    Employees = 1
    Contractors = 2
    Accounts = 3
    Offices = 4
    Currencies = 5
    IncidentalContractors = 8
    Countries = 9
    Dictionaries = 99

class enumTransactionInterestType(ForwardCompatibleEnum):
    VALUE_0 = 0
    Statutory = 1
    FixedRate = 2

class enumVatRegisterPeriodType(ForwardCompatibleEnum):
    SpecificPeriod = 0
    Pending = 1
    PeriodSetByPayment = 2
    PeriodSetByMaturityTerm = 3

class enumVatRegisterTypeABCD(ForwardCompatibleEnum):
    A = 1
    B = 2
    C = 3
    D = 4

class enumYearClosingStatus(ForwardCompatibleEnum):
    Active = 0
    Closed = 1
    Aprroved = 2
