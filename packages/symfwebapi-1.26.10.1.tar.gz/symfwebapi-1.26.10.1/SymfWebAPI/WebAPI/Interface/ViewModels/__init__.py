from __future__ import annotations

from pydantic import BaseModel

from typing import Any, List
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

class Page_1(BaseModel):
    NextPage: str
    PreviousPage: str
    PageNumber: int
    LimitPerPage: int
    TotalItems: int
    OrderBy: "enumOrderByType"
    Data: List[Any]
Page = Page_1
