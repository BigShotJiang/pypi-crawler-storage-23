from __future__ import annotations

from typing import Awaitable, List, Optional, overload
from datetime import datetime
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import FilterDocumentType
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDFSettings
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocument
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocumentFV
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocumentListElement
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocumentStatus
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType
from ._common import (
    _prepare_Get,
    _prepare_GetList,
    _prepare_GetListByContractor,
    _prepare_GetListByWarehouse,
    _prepare_GetListByDimension,
    _prepare_GetFV,
    _prepare_GetStatus,
    _prepare_GetDocumentSeries,
    _prepare_GetPDF,
    _prepare_GetPagedDocument,
    _prepare_GetDocumentTypesWithRange,
)
from ._ops import (
    OP_Get,
    OP_GetList,
    OP_GetListByContractor,
    OP_GetListByWarehouse,
    OP_GetListByDimension,
    OP_GetFV,
    OP_GetStatus,
    OP_GetDocumentSeries,
    OP_GetPDF,
    OP_GetPagedDocument,
    OP_GetDocumentTypesWithRange,
)

@overload
def Get(api: SyncInvokerProtocol, number: str, buffer: bool) -> ResponseEnvelope[WarehouseDocument]: ...
@overload
def Get(api: SyncRequestProtocol, number: str, buffer: bool) -> ResponseEnvelope[WarehouseDocument]: ...
@overload
def Get(api: AsyncInvokerProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[WarehouseDocument]]: ...
@overload
def Get(api: AsyncRequestProtocol, number: str, buffer: bool) -> Awaitable[ResponseEnvelope[WarehouseDocument]]: ...
def Get(api: object, number: str, buffer: bool) -> ResponseEnvelope[WarehouseDocument] | Awaitable[ResponseEnvelope[WarehouseDocument]]:
    params, data = _prepare_Get(number=number, buffer=buffer)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def GetList(api: SyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]]: ...
@overload
def GetList(api: SyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]]: ...
@overload
def GetList(api: AsyncInvokerProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]: ...
@overload
def GetList(api: AsyncRequestProtocol, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]: ...
def GetList(api: object, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]] | Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]:
    params, data = _prepare_GetList(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetList, params=params, data=data)

@overload
def GetListByContractor(api: SyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]]: ...
@overload
def GetListByContractor(api: SyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]]: ...
@overload
def GetListByContractor(api: AsyncInvokerProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]: ...
@overload
def GetListByContractor(api: AsyncRequestProtocol, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]: ...
def GetListByContractor(api: object, contractorCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]] | Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]:
    params, data = _prepare_GetListByContractor(contractorCode=contractorCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByContractor, params=params, data=data)

@overload
def GetListByWarehouse(api: SyncInvokerProtocol, warehouseCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]]: ...
@overload
def GetListByWarehouse(api: SyncRequestProtocol, warehouseCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]]: ...
@overload
def GetListByWarehouse(api: AsyncInvokerProtocol, warehouseCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]: ...
@overload
def GetListByWarehouse(api: AsyncRequestProtocol, warehouseCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]: ...
def GetListByWarehouse(api: object, warehouseCode: str, dateFrom: Optional[datetime] = None, dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]] | Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]:
    params, data = _prepare_GetListByWarehouse(warehouseCode=warehouseCode, dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetListByWarehouse, params=params, data=data)

@overload
def GetListByDimension(api: SyncInvokerProtocol, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[WarehouseDocumentListElement]]: ...
@overload
def GetListByDimension(api: SyncRequestProtocol, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[WarehouseDocumentListElement]]: ...
@overload
def GetListByDimension(api: AsyncInvokerProtocol, dimensionCode: str, dictionaryValue: str) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]: ...
@overload
def GetListByDimension(api: AsyncRequestProtocol, dimensionCode: str, dictionaryValue: str) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]: ...
def GetListByDimension(api: object, dimensionCode: str, dictionaryValue: str) -> ResponseEnvelope[List[WarehouseDocumentListElement]] | Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]:
    params, data = _prepare_GetListByDimension(dimensionCode=dimensionCode, dictionaryValue=dictionaryValue)
    return invoke_operation(api, OP_GetListByDimension, params=params, data=data)

@overload
def GetFV(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[WarehouseDocumentFV]]: ...
@overload
def GetFV(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[WarehouseDocumentFV]]: ...
@overload
def GetFV(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentFV]]]: ...
@overload
def GetFV(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentFV]]]: ...
def GetFV(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[List[WarehouseDocumentFV]] | Awaitable[ResponseEnvelope[List[WarehouseDocumentFV]]]:
    params, data = _prepare_GetFV(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetFV, params=params, data=data)

@overload
def GetStatus(api: SyncInvokerProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[WarehouseDocumentStatus]: ...
@overload
def GetStatus(api: SyncRequestProtocol, documentNumber: str, buffer: bool) -> ResponseEnvelope[WarehouseDocumentStatus]: ...
@overload
def GetStatus(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[WarehouseDocumentStatus]]: ...
@overload
def GetStatus(api: AsyncRequestProtocol, documentNumber: str, buffer: bool) -> Awaitable[ResponseEnvelope[WarehouseDocumentStatus]]: ...
def GetStatus(api: object, documentNumber: str, buffer: bool) -> ResponseEnvelope[WarehouseDocumentStatus] | Awaitable[ResponseEnvelope[WarehouseDocumentStatus]]:
    params, data = _prepare_GetStatus(documentNumber=documentNumber, buffer=buffer)
    return invoke_operation(api, OP_GetStatus, params=params, data=data)

@overload
def GetDocumentSeries(api: SyncInvokerProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: SyncRequestProtocol, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]]: ...
@overload
def GetDocumentSeries(api: AsyncInvokerProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
@overload
def GetDocumentSeries(api: AsyncRequestProtocol, documentTypeId: int) -> Awaitable[ResponseEnvelope[List[DocumentSeries]]]: ...
def GetDocumentSeries(api: object, documentTypeId: int) -> ResponseEnvelope[List[DocumentSeries]] | Awaitable[ResponseEnvelope[List[DocumentSeries]]]:
    params, data = _prepare_GetDocumentSeries(documentTypeId=documentTypeId)
    return invoke_operation(api, OP_GetDocumentSeries, params=params, data=data)

@overload
def GetPDF(api: SyncInvokerProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: SyncRequestProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF]: ...
@overload
def GetPDF(api: AsyncInvokerProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> Awaitable[ResponseEnvelope[PDF]]: ...
@overload
def GetPDF(api: AsyncRequestProtocol, documentNumber: str, buffer: bool, settings: "PDFSettings") -> Awaitable[ResponseEnvelope[PDF]]: ...
def GetPDF(api: object, documentNumber: str, buffer: bool, settings: "PDFSettings") -> ResponseEnvelope[PDF] | Awaitable[ResponseEnvelope[PDF]]:
    params, data = _prepare_GetPDF(documentNumber=documentNumber, buffer=buffer, settings=settings)
    return invoke_operation(api, OP_GetPDF, params=params, data=data)

@overload
def GetPagedDocument(api: SyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: SyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page]: ...
@overload
def GetPagedDocument(api: AsyncInvokerProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
@overload
def GetPagedDocument(api: AsyncRequestProtocol, page: int, size: int, orderBy: "enumOrderByType") -> Awaitable[ResponseEnvelope[Page]]: ...
def GetPagedDocument(api: object, page: int, size: int, orderBy: "enumOrderByType") -> ResponseEnvelope[Page] | Awaitable[ResponseEnvelope[Page]]:
    params, data = _prepare_GetPagedDocument(page=page, size=size, orderBy=orderBy)
    return invoke_operation(api, OP_GetPagedDocument, params=params, data=data)

@overload
def GetDocumentTypesWithRange(api: SyncInvokerProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]]: ...
@overload
def GetDocumentTypesWithRange(api: SyncRequestProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]]: ...
@overload
def GetDocumentTypesWithRange(api: AsyncInvokerProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]: ...
@overload
def GetDocumentTypesWithRange(api: AsyncRequestProtocol, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]: ...
def GetDocumentTypesWithRange(api: object, dateFrom: "FilterDocumentType", dateTo: Optional[datetime] = None) -> ResponseEnvelope[List[WarehouseDocumentListElement]] | Awaitable[ResponseEnvelope[List[WarehouseDocumentListElement]]]:
    params, data = _prepare_GetDocumentTypesWithRange(dateFrom=dateFrom, dateTo=dateTo)
    return invoke_operation(api, OP_GetDocumentTypesWithRange, params=params, data=data)

__all__ = ["Get", "GetList", "GetListByContractor", "GetListByWarehouse", "GetListByDimension", "GetFV", "GetStatus", "GetDocumentSeries", "GetPDF", "GetPagedDocument", "GetDocumentTypesWithRange"]
