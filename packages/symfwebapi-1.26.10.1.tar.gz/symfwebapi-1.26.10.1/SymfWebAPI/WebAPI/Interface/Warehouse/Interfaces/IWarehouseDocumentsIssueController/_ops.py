from __future__ import annotations

from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocument
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocumentEdit
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocumentIssue

_ADAPTER_AddNew = TypeAdapter(WarehouseDocument)

def _parse_AddNew(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[WarehouseDocument]:
    return parse_with_adapter(envelope, _ADAPTER_AddNew)
OP_AddNew = OperationSpec(method='POST', path='/api/WarehouseDocumentsIssue/New', parser=_parse_AddNew)

_ADAPTER_Edit = TypeAdapter(WarehouseDocument)

def _parse_Edit(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[WarehouseDocument]:
    return parse_with_adapter(envelope, _ADAPTER_Edit)
OP_Edit = OperationSpec(method='PUT', path='/api/WarehouseDocumentsIssue/Edit', parser=_parse_Edit)

_ADAPTER_Issue = TypeAdapter(WarehouseDocument)

def _parse_Issue(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[WarehouseDocument]:
    return parse_with_adapter(envelope, _ADAPTER_Issue)
OP_Issue = OperationSpec(method='PUT', path='/api/WarehouseDocumentsIssue/InBuffer', parser=_parse_Issue)

def _parse_IssueMMPlus(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_IssueMMPlus = OperationSpec(method='PUT', path='/api/WarehouseDocumentsIssue/MMPlus', parser=_parse_IssueMMPlus)

def _parse_ChangeDocumentNumber(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_ChangeDocumentNumber = OperationSpec(method='PATCH', path='/api/WarehouseDocumentsIssue/DocumentNumber', parser=_parse_ChangeDocumentNumber)
