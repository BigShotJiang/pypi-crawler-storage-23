from __future__ import annotations

from typing import Any

_REQUEST_GetInWarehouse = ('GET', '/api/Deliveries/InWarehouse')
def _prepare_GetInWarehouse(*, warehouseCode, productCode) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["warehouseCode"] = warehouseCode
    params["productCode"] = productCode
    data = None
    return params or None, data
