from __future__ import annotations

from typing import List, Optional
from datetime import datetime
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import DocumentSeries
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import FilterDocumentType
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDF
from SymfWebAPI.WebAPI.Interface.Common.ViewModels import PDFSettings
from SymfWebAPI.WebAPI.Interface.ViewModels import Page
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocument
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocumentFV
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocumentListElement
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocumentStatus
from SymfWebAPI.WebAPI.Interface.Enums import enumOrderByType

_ADAPTER_Get = TypeAdapter(WarehouseDocument)

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[WarehouseDocument]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/WarehouseDocuments', parser=_parse_Get)

_ADAPTER_GetList = TypeAdapter(List[WarehouseDocumentListElement])

def _parse_GetList(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[WarehouseDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetList)
OP_GetList = OperationSpec(method='GET', path='/api/WarehouseDocuments/Filter', parser=_parse_GetList)

_ADAPTER_GetListByContractor = TypeAdapter(List[WarehouseDocumentListElement])

def _parse_GetListByContractor(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[WarehouseDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByContractor)
OP_GetListByContractor = OperationSpec(method='GET', path='/api/WarehouseDocuments/Filter', parser=_parse_GetListByContractor)

_ADAPTER_GetListByWarehouse = TypeAdapter(List[WarehouseDocumentListElement])

def _parse_GetListByWarehouse(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[WarehouseDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByWarehouse)
OP_GetListByWarehouse = OperationSpec(method='GET', path='/api/WarehouseDocuments/Filter', parser=_parse_GetListByWarehouse)

_ADAPTER_GetListByDimension = TypeAdapter(List[WarehouseDocumentListElement])

def _parse_GetListByDimension(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[WarehouseDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetListByDimension)
OP_GetListByDimension = OperationSpec(method='GET', path='/api/WarehouseDocuments/Filter', parser=_parse_GetListByDimension)

_ADAPTER_GetFV = TypeAdapter(List[WarehouseDocumentFV])

def _parse_GetFV(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[WarehouseDocumentFV]]:
    return parse_with_adapter(envelope, _ADAPTER_GetFV)
OP_GetFV = OperationSpec(method='GET', path='/api/WarehouseDocuments/FV', parser=_parse_GetFV)

_ADAPTER_GetStatus = TypeAdapter(WarehouseDocumentStatus)

def _parse_GetStatus(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[WarehouseDocumentStatus]:
    return parse_with_adapter(envelope, _ADAPTER_GetStatus)
OP_GetStatus = OperationSpec(method='GET', path='/api/WarehouseDocuments/Status', parser=_parse_GetStatus)

_ADAPTER_GetDocumentSeries = TypeAdapter(List[DocumentSeries])

def _parse_GetDocumentSeries(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DocumentSeries]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentSeries)
OP_GetDocumentSeries = OperationSpec(method='GET', path='/api/WarehouseDocuments/DocumentSeries', parser=_parse_GetDocumentSeries)

_ADAPTER_GetPDF = TypeAdapter(PDF)

def _parse_GetPDF(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[PDF]:
    return parse_with_adapter(envelope, _ADAPTER_GetPDF)
OP_GetPDF = OperationSpec(method='PATCH', path='/api/WarehouseDocuments/PDF', parser=_parse_GetPDF)

_ADAPTER_GetPagedDocument = TypeAdapter(Page)

def _parse_GetPagedDocument(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[Page]:
    return parse_with_adapter(envelope, _ADAPTER_GetPagedDocument)
OP_GetPagedDocument = OperationSpec(method='GET', path='/api/WarehouseDocuments/Page', parser=_parse_GetPagedDocument)

_ADAPTER_GetDocumentTypesWithRange = TypeAdapter(List[WarehouseDocumentListElement])

def _parse_GetDocumentTypesWithRange(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[WarehouseDocumentListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetDocumentTypesWithRange)
OP_GetDocumentTypesWithRange = OperationSpec(method='GET', path='/api/WarehouseDocuments/Filter/ByDocumentTypes', parser=_parse_GetDocumentTypesWithRange)
