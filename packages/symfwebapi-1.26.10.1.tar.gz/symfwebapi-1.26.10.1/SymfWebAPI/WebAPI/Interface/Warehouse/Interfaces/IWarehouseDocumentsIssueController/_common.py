from __future__ import annotations

from typing import Any

_REQUEST_AddNew = ('POST', '/api/WarehouseDocumentsIssue/New')
def _prepare_AddNew(*, issue, document) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["issue"] = issue
    data = document.model_dump_json(exclude_unset=True) if document is not None else None
    return params or None, data

_REQUEST_Edit = ('PUT', '/api/WarehouseDocumentsIssue/Edit')
def _prepare_Edit(*, document) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = document.model_dump_json(exclude_unset=True) if document is not None else None
    return params or None, data

_REQUEST_Issue = ('PUT', '/api/WarehouseDocumentsIssue/InBuffer')
def _prepare_Issue(*, number) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["number"] = number
    data = None
    return params or None, data

_REQUEST_IssueMMPlus = ('PUT', '/api/WarehouseDocumentsIssue/MMPlus')
def _prepare_IssueMMPlus(*, documentNumber) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    data = None
    return params or None, data

_REQUEST_ChangeDocumentNumber = ('PATCH', '/api/WarehouseDocumentsIssue/DocumentNumber')
def _prepare_ChangeDocumentNumber(*, id, number) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["id"] = id
    params["number"] = number
    data = None
    return params or None, data
