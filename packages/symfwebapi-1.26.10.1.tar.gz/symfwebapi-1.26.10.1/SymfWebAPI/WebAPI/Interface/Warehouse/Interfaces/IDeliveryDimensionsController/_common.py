from __future__ import annotations

from typing import Any

import json

_REQUEST_Get = ('GET', '/api/DeliveryDimensions')
def _prepare_Get(*, deliveryId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["deliveryId"] = deliveryId
    data = None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/DeliveryDimensions/UpdateList')
def _prepare_Update(*, deliveryId, deliveryDimensions) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["deliveryId"] = deliveryId
    data = json.dumps(deliveryDimensions) if deliveryDimensions is not None else None
    return params or None, data
