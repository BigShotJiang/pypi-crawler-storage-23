from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import DeliveryListElement

_ADAPTER_GetInWarehouse = TypeAdapter(List[DeliveryListElement])

def _parse_GetInWarehouse(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[DeliveryListElement]]:
    return parse_with_adapter(envelope, _ADAPTER_GetInWarehouse)
OP_GetInWarehouse = OperationSpec(method='GET', path='/api/Deliveries/InWarehouse', parser=_parse_GetInWarehouse)
