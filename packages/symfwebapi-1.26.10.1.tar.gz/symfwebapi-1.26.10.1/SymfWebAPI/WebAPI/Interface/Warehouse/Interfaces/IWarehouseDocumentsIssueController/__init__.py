from __future__ import annotations

from typing import Awaitable, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocument
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocumentEdit
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import WarehouseDocumentIssue
from ._common import (
    _prepare_AddNew,
    _prepare_Edit,
    _prepare_Issue,
    _prepare_IssueMMPlus,
    _prepare_ChangeDocumentNumber,
)
from ._ops import (
    OP_AddNew,
    OP_Edit,
    OP_Issue,
    OP_IssueMMPlus,
    OP_ChangeDocumentNumber,
)

@overload
def AddNew(api: SyncInvokerProtocol, issue: bool, document: "WarehouseDocumentIssue") -> ResponseEnvelope[WarehouseDocument]: ...
@overload
def AddNew(api: SyncRequestProtocol, issue: bool, document: "WarehouseDocumentIssue") -> ResponseEnvelope[WarehouseDocument]: ...
@overload
def AddNew(api: AsyncInvokerProtocol, issue: bool, document: "WarehouseDocumentIssue") -> Awaitable[ResponseEnvelope[WarehouseDocument]]: ...
@overload
def AddNew(api: AsyncRequestProtocol, issue: bool, document: "WarehouseDocumentIssue") -> Awaitable[ResponseEnvelope[WarehouseDocument]]: ...
def AddNew(api: object, issue: bool, document: "WarehouseDocumentIssue") -> ResponseEnvelope[WarehouseDocument] | Awaitable[ResponseEnvelope[WarehouseDocument]]:
    params, data = _prepare_AddNew(issue=issue, document=document)
    return invoke_operation(api, OP_AddNew, params=params, data=data)

@overload
def Edit(api: SyncInvokerProtocol, document: "WarehouseDocumentEdit") -> ResponseEnvelope[WarehouseDocument]: ...
@overload
def Edit(api: SyncRequestProtocol, document: "WarehouseDocumentEdit") -> ResponseEnvelope[WarehouseDocument]: ...
@overload
def Edit(api: AsyncInvokerProtocol, document: "WarehouseDocumentEdit") -> Awaitable[ResponseEnvelope[WarehouseDocument]]: ...
@overload
def Edit(api: AsyncRequestProtocol, document: "WarehouseDocumentEdit") -> Awaitable[ResponseEnvelope[WarehouseDocument]]: ...
def Edit(api: object, document: "WarehouseDocumentEdit") -> ResponseEnvelope[WarehouseDocument] | Awaitable[ResponseEnvelope[WarehouseDocument]]:
    params, data = _prepare_Edit(document=document)
    return invoke_operation(api, OP_Edit, params=params, data=data)

@overload
def Issue(api: SyncInvokerProtocol, number: str) -> ResponseEnvelope[WarehouseDocument]: ...
@overload
def Issue(api: SyncRequestProtocol, number: str) -> ResponseEnvelope[WarehouseDocument]: ...
@overload
def Issue(api: AsyncInvokerProtocol, number: str) -> Awaitable[ResponseEnvelope[WarehouseDocument]]: ...
@overload
def Issue(api: AsyncRequestProtocol, number: str) -> Awaitable[ResponseEnvelope[WarehouseDocument]]: ...
def Issue(api: object, number: str) -> ResponseEnvelope[WarehouseDocument] | Awaitable[ResponseEnvelope[WarehouseDocument]]:
    params, data = _prepare_Issue(number=number)
    return invoke_operation(api, OP_Issue, params=params, data=data)

@overload
def IssueMMPlus(api: SyncInvokerProtocol, documentNumber: str) -> ResponseEnvelope[None]: ...
@overload
def IssueMMPlus(api: SyncRequestProtocol, documentNumber: str) -> ResponseEnvelope[None]: ...
@overload
def IssueMMPlus(api: AsyncInvokerProtocol, documentNumber: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def IssueMMPlus(api: AsyncRequestProtocol, documentNumber: str) -> Awaitable[ResponseEnvelope[None]]: ...
def IssueMMPlus(api: object, documentNumber: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_IssueMMPlus(documentNumber=documentNumber)
    return invoke_operation(api, OP_IssueMMPlus, params=params, data=data)

@overload
def ChangeDocumentNumber(api: SyncInvokerProtocol, id: int, number: str) -> ResponseEnvelope[None]: ...
@overload
def ChangeDocumentNumber(api: SyncRequestProtocol, id: int, number: str) -> ResponseEnvelope[None]: ...
@overload
def ChangeDocumentNumber(api: AsyncInvokerProtocol, id: int, number: str) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def ChangeDocumentNumber(api: AsyncRequestProtocol, id: int, number: str) -> Awaitable[ResponseEnvelope[None]]: ...
def ChangeDocumentNumber(api: object, id: int, number: str) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_ChangeDocumentNumber(id=id, number=number)
    return invoke_operation(api, OP_ChangeDocumentNumber, params=params, data=data)

__all__ = ["AddNew", "Edit", "Issue", "IssueMMPlus", "ChangeDocumentNumber"]
