from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.Warehouse.ViewModels import DeliveryListElement
from ._common import (
    _prepare_GetInWarehouse,
)
from ._ops import (
    OP_GetInWarehouse,
)

@overload
def GetInWarehouse(api: SyncInvokerProtocol, warehouseCode: str, productCode: str) -> ResponseEnvelope[List[DeliveryListElement]]: ...
@overload
def GetInWarehouse(api: SyncRequestProtocol, warehouseCode: str, productCode: str) -> ResponseEnvelope[List[DeliveryListElement]]: ...
@overload
def GetInWarehouse(api: AsyncInvokerProtocol, warehouseCode: str, productCode: str) -> Awaitable[ResponseEnvelope[List[DeliveryListElement]]]: ...
@overload
def GetInWarehouse(api: AsyncRequestProtocol, warehouseCode: str, productCode: str) -> Awaitable[ResponseEnvelope[List[DeliveryListElement]]]: ...
def GetInWarehouse(api: object, warehouseCode: str, productCode: str) -> ResponseEnvelope[List[DeliveryListElement]] | Awaitable[ResponseEnvelope[List[DeliveryListElement]]]:
    params, data = _prepare_GetInWarehouse(warehouseCode=warehouseCode, productCode=productCode)
    return invoke_operation(api, OP_GetInWarehouse, params=params, data=data)

__all__ = ["GetInWarehouse"]
