from __future__ import annotations

from typing import Awaitable, List, overload
from SymfWebAPI.operations import invoke_operation
from SymfWebAPI.protocols import (AsyncInvokerProtocol, AsyncRequestProtocol, SyncInvokerProtocol, SyncRequestProtocol)
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension
from ._common import (
    _prepare_Get,
    _prepare_Update,
)
from ._ops import (
    OP_Get,
    OP_Update,
)

@overload
def Get(api: SyncInvokerProtocol, deliveryId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def Get(api: SyncRequestProtocol, deliveryId: int) -> ResponseEnvelope[List[Dimension]]: ...
@overload
def Get(api: AsyncInvokerProtocol, deliveryId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
@overload
def Get(api: AsyncRequestProtocol, deliveryId: int) -> Awaitable[ResponseEnvelope[List[Dimension]]]: ...
def Get(api: object, deliveryId: int) -> ResponseEnvelope[List[Dimension]] | Awaitable[ResponseEnvelope[List[Dimension]]]:
    params, data = _prepare_Get(deliveryId=deliveryId)
    return invoke_operation(api, OP_Get, params=params, data=data)

@overload
def Update(api: SyncInvokerProtocol, deliveryId: int, deliveryDimensions: List["Dimension"]) -> ResponseEnvelope[None]: ...
@overload
def Update(api: SyncRequestProtocol, deliveryId: int, deliveryDimensions: List["Dimension"]) -> ResponseEnvelope[None]: ...
@overload
def Update(api: AsyncInvokerProtocol, deliveryId: int, deliveryDimensions: List["Dimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
@overload
def Update(api: AsyncRequestProtocol, deliveryId: int, deliveryDimensions: List["Dimension"]) -> Awaitable[ResponseEnvelope[None]]: ...
def Update(api: object, deliveryId: int, deliveryDimensions: List["Dimension"]) -> ResponseEnvelope[None] | Awaitable[ResponseEnvelope[None]]:
    params, data = _prepare_Update(deliveryId=deliveryId, deliveryDimensions=deliveryDimensions)
    return invoke_operation(api, OP_Update, params=params, data=data)

__all__ = ["Get", "Update"]
