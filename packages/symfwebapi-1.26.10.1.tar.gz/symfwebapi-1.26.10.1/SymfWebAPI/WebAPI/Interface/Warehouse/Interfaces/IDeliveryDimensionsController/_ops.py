from __future__ import annotations

from typing import List
from pydantic import TypeAdapter
from SymfWebAPI.operations import OperationSpec, parse_none, parse_with_adapter
from SymfWebAPI.response import ResponseEnvelope
from SymfWebAPI.WebAPI.Interface.FKF.Common.ViewModels import Dimension

_ADAPTER_Get = TypeAdapter(List[Dimension])

def _parse_Get(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[List[Dimension]]:
    return parse_with_adapter(envelope, _ADAPTER_Get)
OP_Get = OperationSpec(method='GET', path='/api/DeliveryDimensions', parser=_parse_Get)

def _parse_Update(envelope: ResponseEnvelope[object]) -> ResponseEnvelope[None]:
    return parse_none(envelope)
OP_Update = OperationSpec(method='PUT', path='/api/DeliveryDimensions/UpdateList', parser=_parse_Update)
