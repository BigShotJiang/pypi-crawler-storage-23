from __future__ import annotations

from typing import Any

import json

_REQUEST_Get = ('GET', '/api/WarehouseDocumentDimensions')
def _prepare_Get(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPositionsByOrderId = ('GET', '/api/WarehouseDocumentDimensions/Positions')
def _prepare_GetPositionsByOrderId(*, documentId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentId"] = documentId
    data = None
    return params or None, data

_REQUEST_GetPositionsByOrderNumber = ('GET', '/api/WarehouseDocumentDimensions/Positions')
def _prepare_GetPositionsByOrderNumber(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_GetPosition = ('GET', '/api/WarehouseDocumentDimensions/Positions')
def _prepare_GetPosition(*, positionId) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["positionId"] = positionId
    data = None
    return params or None, data

_REQUEST_Update = ('PUT', '/api/WarehouseDocumentDimensions/UpdateList')
def _prepare_Update(*, documentNumber, buffer, documentDimensions) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = json.dumps(documentDimensions) if documentDimensions is not None else None
    return params or None, data

_REQUEST_UpdatePosition = ('PUT', '/api/WarehouseDocumentDimensions/UpdateMultiPositionsList')
def _prepare_UpdatePosition(*, positionDimension) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = json.dumps(positionDimension) if positionDimension is not None else None
    return params or None, data

_REQUEST_GetAspects = ('GET', '/api/WarehouseDocumentDimensions/Aspects')
def _prepare_GetAspects(*, documentNumber, buffer) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    params["documentNumber"] = documentNumber
    params["buffer"] = buffer
    data = None
    return params or None, data

_REQUEST_UpdateAspect = ('PUT', '/api/WarehouseDocumentDimensions/Aspects')
def _prepare_UpdateAspect(*, aspectPosition) -> tuple[dict[str, Any] | None, Any]:
    params: dict[str, Any] = {}
    data = aspectPosition.model_dump_json(exclude_unset=True) if aspectPosition is not None else None
    return params or None, data
