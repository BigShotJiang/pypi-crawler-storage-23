"""Shared request policy and response mapping for sync/async clients."""

from __future__ import annotations

from datetime import date, datetime
from typing import Any, Optional

from .errors import WebAPIHttpError
from .response import ResponseEnvelope


def normalize_query_value(value: Any) -> Any:
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, date):
        return value.isoformat()
    if isinstance(value, dict):
        return {key: normalize_query_value(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [normalize_query_value(item) for item in value]
    return value


def normalize_query_params(params: Optional[dict]) -> Optional[dict]:
    if params is None:
        return None
    return {key: normalize_query_value(value) for key, value in params.items()}


def should_retry_auth(status_code: int) -> bool:
    return status_code == 401


def to_envelope_or_raise(response: Any, *, path: str) -> ResponseEnvelope[Any]:
    if 200 <= response.status_code < 300:
        text = response.text
        return ResponseEnvelope(
            model=None,
            status=response.status_code,
            headers=dict(response.headers),
            raw_text=text,
        )
    raise WebAPIHttpError(response.status_code, endpoint=path, response_text=response.text)
