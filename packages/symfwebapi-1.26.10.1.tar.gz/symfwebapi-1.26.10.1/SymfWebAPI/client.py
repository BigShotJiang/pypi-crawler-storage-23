"""High-level async/sync clients wrapping transport + session manager."""

from __future__ import annotations

import asyncio
from contextlib import AbstractAsyncContextManager, AbstractContextManager
from typing import Any, Awaitable, Callable, Optional

from .config import ClientConfig
from .executors import AsyncRequestExecutor, SyncRequestExecutor
from .operations import OperationSpec
from .response import ResponseEnvelope
from .session import SessionManager


class AsyncAPI(AbstractAsyncContextManager["AsyncAPI"]):
    def __init__(
        self,
        config: ClientConfig,
        session_manager: SessionManager,
        request_fn: Callable[..., Any],
        shutdown_hook: Optional[Callable[[], Awaitable[None]]] = None,
    ):
        self._config = config
        self._session = session_manager
        self._executor = AsyncRequestExecutor(config, session_manager, request_fn)
        self._shutdown_hook = shutdown_hook

    async def __aenter__(self) -> "AsyncAPI":
        await self.open()
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    async def open(self) -> "AsyncAPI":
        await self._session.ensure_async()
        return self

    async def close(self) -> None:
        try:
            await self._session.close_async()
        finally:
            if self._shutdown_hook:
                await self._shutdown_hook()

    async def ensure_session(self) -> str:
        return await self._executor.ensure_session()

    async def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict] = None,
        data: Any = None,
    ) -> ResponseEnvelope[Any]:
        return await self._executor.request(method, path, params=params, data=data)

    def invalidate_session(self) -> None:
        self._executor.invalidate_session()

    async def invoke(
        self,
        operation: OperationSpec,
        *,
        params: Optional[dict] = None,
        data: Any = None,
    ) -> ResponseEnvelope[Any]:
        envelope = await self.request(operation.method, operation.path, params=params, data=data)
        if self._config.offload_async_parsing:
            return await asyncio.to_thread(operation.parser, envelope)
        return operation.parser(envelope)


class SyncAPI(AbstractContextManager["SyncAPI"]):
    def __init__(
        self,
        config: ClientConfig,
        session_manager: SessionManager,
        request_fn: Callable[..., Any],
        shutdown_hook: Optional[Callable[[], None]] = None,
    ):
        self._session = session_manager
        self._executor = SyncRequestExecutor(config, session_manager, request_fn)
        self._shutdown_hook = shutdown_hook

    def __enter__(self) -> "SyncAPI":
        return self.open()

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

    def open(self) -> "SyncAPI":
        self._session.ensure_sync()
        return self

    def close(self) -> None:
        try:
            self._session.close_sync()
        finally:
            if self._shutdown_hook:
                self._shutdown_hook()

    def ensure_session(self) -> str:
        return self._executor.ensure_session()

    def request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict] = None,
        data: Any = None,
    ) -> ResponseEnvelope[Any]:
        return self._executor.request(method, path, params=params, data=data)

    def invalidate_session(self) -> None:
        self._executor.invalidate_session()

    def invoke(
        self,
        operation: OperationSpec,
        *,
        params: Optional[dict] = None,
        data: Any = None,
    ) -> ResponseEnvelope[Any]:
        envelope = self.request(operation.method, operation.path, params=params, data=data)
        return operation.parser(envelope)
