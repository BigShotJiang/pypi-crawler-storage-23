from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
import logging
import threading
import time

from SymfWebAPI.config import ClientConfig
from SymfWebAPI.session import AsyncSessionManager, SessionManager, SessionBackend, SyncSessionManager


class FakeBackend(SessionBackend):
    def __init__(self) -> None:
        self.tokens: list[str] = []
        self.closed_async: list[str] = []
        self.closed_sync: list[str] = []
        self.fail_close_async = False
        self.fail_close_sync = False

    async def open_async(self, device_name: str) -> str:
        token = f"async-{len(self.tokens)+1}"
        self.tokens.append(token)
        return token

    def open_sync(self, device_name: str) -> str:
        token = f"sync-{len(self.tokens)+1}"
        self.tokens.append(token)
        return token

    async def close_async(self, token: str) -> None:
        if self.fail_close_async:
            raise RuntimeError("close async failed")
        self.closed_async.append(token)

    def close_sync(self, token: str) -> None:
        if self.fail_close_sync:
            raise RuntimeError("close sync failed")
        self.closed_sync.append(token)


class MixedBackend(SessionBackend):
    def __init__(self) -> None:
        self._counter = 0
        self._lock = threading.Lock()
        self.open_sync_calls = 0
        self.open_async_calls = 0

    async def open_async(self, device_name: str) -> str:
        with self._lock:
            self.open_async_calls += 1
            self._counter += 1
            token = f"mix-{self._counter}"
        await asyncio.sleep(0.05)
        return token

    def open_sync(self, device_name: str) -> str:
        with self._lock:
            self.open_sync_calls += 1
            self._counter += 1
            token = f"mix-{self._counter}"
        time.sleep(0.05)
        return token

    async def close_async(self, token: str) -> None:
        return None

    def close_sync(self, token: str) -> None:
        return None


class ControlledSyncBackend(SessionBackend):
    def __init__(self) -> None:
        self.open_started = threading.Event()
        self.allow_open_return = threading.Event()
        self.open_calls = 0
        self.closed_sync: list[str] = []

    async def open_async(self, device_name: str) -> str:  # pragma: no cover
        raise NotImplementedError

    def open_sync(self, device_name: str) -> str:
        self.open_calls += 1
        self.open_started.set()
        self.allow_open_return.wait(timeout=2)
        return f"sync-race-{self.open_calls}"

    async def close_async(self, token: str) -> None:  # pragma: no cover
        raise NotImplementedError

    def close_sync(self, token: str) -> None:
        self.closed_sync.append(token)


class ControlledAsyncBackend(SessionBackend):
    def __init__(self) -> None:
        self.open_started = asyncio.Event()
        self.allow_open_return = asyncio.Event()
        self.open_calls = 0
        self.closed_async: list[str] = []

    async def open_async(self, device_name: str) -> str:
        self.open_calls += 1
        self.open_started.set()
        await asyncio.wait_for(self.allow_open_return.wait(), timeout=2)
        return f"async-race-{self.open_calls}"

    def open_sync(self, device_name: str) -> str:  # pragma: no cover
        raise NotImplementedError

    async def close_async(self, token: str) -> None:
        self.closed_async.append(token)

    def close_sync(self, token: str) -> None:  # pragma: no cover
        raise NotImplementedError


def _make_config() -> ClientConfig:
    return ClientConfig(
        domain="example",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-async",
        max_session_age=timedelta(minutes=1),
    )


def _expire_state(manager: SessionManager) -> None:
    manager.state.opened_at = datetime.now(timezone.utc) - timedelta(minutes=10)


def test_session_manager_async_cache():
    config = _make_config()
    backend = FakeBackend()
    manager = SessionManager(config, backend)

    async def run():
        state1 = await manager.ensure_async()
        state2 = await manager.ensure_async()
        assert state1.token == state2.token
        assert backend.closed_async == []

    asyncio.run(run())


def test_session_manager_async_refresh_closes_previous():
    config = ClientConfig(
        domain="example",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-async",
        max_session_age=timedelta(minutes=1),
    )
    backend = FakeBackend()
    manager = SessionManager(config, backend)

    async def run():
        first = await manager.ensure_async()
        _expire_state(manager)
        second = await manager.ensure_async()
        assert first.token != second.token
        assert backend.closed_async == [first.token]

    asyncio.run(run())


def test_session_manager_async_refresh_opens_new_even_if_close_fails():
    config = _make_config()
    backend = FakeBackend()
    manager = SessionManager(config, backend)

    async def run():
        first = await manager.ensure_async()
        _expire_state(manager)
        backend.fail_close_async = True
        second = await manager.ensure_async()
        assert first.token != second.token
        assert backend.closed_async == []

    asyncio.run(run())


def test_session_manager_sync_refresh_closes_previous():
    config = _make_config()
    backend = FakeBackend()
    manager = SessionManager(config, backend)

    first = manager.ensure_sync()
    _expire_state(manager)
    second = manager.ensure_sync()

    assert first.token != second.token
    assert backend.closed_sync == [first.token]
    assert second.expires_at is not None
    assert second.opened_at is not None
    assert second.expires_at > second.opened_at


def test_sync_session_manager_can_work_standalone():
    config = _make_config()
    backend = FakeBackend()
    manager = SyncSessionManager(config, backend, logger=logging.getLogger(__name__))

    first = manager.ensure_sync()
    second = manager.ensure_sync()

    assert first.token == second.token
    assert first.token and first.token.startswith("sync-")


def test_async_session_manager_can_work_standalone():
    config = _make_config()
    backend = FakeBackend()
    manager = AsyncSessionManager(config, backend, logger=logging.getLogger(__name__))

    async def run() -> None:
        first = await manager.ensure_async()
        second = await manager.ensure_async()
        assert first.token == second.token
        assert first.token and first.token.startswith("async-")

    asyncio.run(run())


def test_session_manager_sync_refresh_opens_new_even_if_close_fails():
    config = _make_config()
    backend = FakeBackend()
    manager = SessionManager(config, backend)

    first = manager.ensure_sync()
    _expire_state(manager)
    backend.fail_close_sync = True
    second = manager.ensure_sync()

    assert first.token != second.token
    assert backend.closed_sync == []


def test_session_manager_full_sync_async_sharing_single_open():
    config = _make_config()
    backend = MixedBackend()
    manager = SessionManager(config, backend)
    sync_tokens: list[str] = []

    def run_sync() -> None:
        sync_tokens.append(manager.ensure_sync().token or "")

    async def run_async() -> str:
        return (await manager.ensure_async()).token or ""

    thread = threading.Thread(target=run_sync)
    thread.start()
    async_token = asyncio.run(run_async())
    thread.join()

    assert len(sync_tokens) == 1
    assert sync_tokens[0] == async_token
    assert backend.open_sync_calls + backend.open_async_calls == 1


def test_close_sync_waits_for_refresh_and_closes_new_token():
    config = _make_config()
    backend = ControlledSyncBackend()
    manager = SessionManager(config, backend)
    ensured_tokens: list[str] = []

    def run_ensure() -> None:
        ensured_tokens.append(manager.ensure_sync().token or "")

    ensure_thread = threading.Thread(target=run_ensure)
    ensure_thread.start()
    assert backend.open_started.wait(timeout=2)

    close_thread = threading.Thread(target=manager.close_sync)
    close_thread.start()

    backend.allow_open_return.set()

    ensure_thread.join(timeout=2)
    close_thread.join(timeout=2)
    assert not ensure_thread.is_alive()
    assert not close_thread.is_alive()
    assert len(ensured_tokens) == 1
    assert backend.closed_sync == [ensured_tokens[0]]


def test_close_async_waits_for_refresh_and_closes_new_token():
    config = _make_config()
    backend = ControlledAsyncBackend()
    manager = SessionManager(config, backend)

    async def run() -> None:
        ensure_task = asyncio.create_task(manager.ensure_async())
        await asyncio.wait_for(backend.open_started.wait(), timeout=2)
        close_task = asyncio.create_task(manager.close_async())
        backend.allow_open_return.set()
        ensured_state = await ensure_task
        await close_task
        assert backend.closed_async == [ensured_state.token]

    asyncio.run(run())


def test_concurrent_ensure_async_refreshes_once_for_many_waiters():
    config = _make_config()
    backend = ControlledAsyncBackend()
    manager = SessionManager(config, backend)

    async def run() -> None:
        tasks = [asyncio.create_task(manager.ensure_async()) for _ in range(30)]
        await asyncio.wait_for(backend.open_started.wait(), timeout=2)
        backend.allow_open_return.set()
        states = await asyncio.gather(*tasks)
        tokens = {state.token for state in states}
        assert len(tokens) == 1
        assert backend.open_calls == 1

    asyncio.run(run())


def test_session_manager_sync_async_share_refresh_after_invalidate():
    config = _make_config()
    backend = MixedBackend()
    manager = SessionManager(config, backend)

    first = manager.ensure_sync().token
    manager.invalidate()

    sync_tokens: list[str] = []

    def run_sync() -> None:
        sync_tokens.append(manager.ensure_sync().token or "")

    async def run_async() -> str:
        return (await manager.ensure_async()).token or ""

    thread = threading.Thread(target=run_sync)
    thread.start()
    async_token = asyncio.run(run_async())
    thread.join(timeout=2)

    assert not thread.is_alive()
    assert len(sync_tokens) == 1
    assert sync_tokens[0] == async_token
    assert sync_tokens[0] != first
    assert backend.open_sync_calls + backend.open_async_calls == 2


def test_session_manager_sync_async_share_refresh_after_expire():
    config = _make_config()
    backend = MixedBackend()
    manager = SessionManager(config, backend)

    first = manager.ensure_sync().token
    _expire_state(manager)

    sync_tokens: list[str] = []

    def run_sync() -> None:
        sync_tokens.append(manager.ensure_sync().token or "")

    async def run_async() -> str:
        return (await manager.ensure_async()).token or ""

    thread = threading.Thread(target=run_sync)
    thread.start()
    async_token = asyncio.run(run_async())
    thread.join(timeout=2)

    assert not thread.is_alive()
    assert len(sync_tokens) == 1
    assert sync_tokens[0] == async_token
    assert sync_tokens[0] != first
    assert backend.open_sync_calls + backend.open_async_calls == 2
