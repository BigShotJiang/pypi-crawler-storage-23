from __future__ import annotations

import httpx
import pytest

from SymfWebAPI.config import ClientConfig
from SymfWebAPI.errors import TransportError
from SymfWebAPI.transport.httpx_async import AsyncHttpxTransport


def _mock_async_transport():
    async def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/Sessions/OpenNewSession":
            assert request.url.params["deviceName"] == "dev-async"
            assert request.headers["Authorization"].startswith("Application ")
            return httpx.Response(200, text='"async-token"')
        if request.url.path == "/api/Sessions/CloseSession":
            assert request.headers["Authorization"] == "Session async-token"
            return httpx.Response(200, text="")
        if request.url.path == "/api/Ping":
            assert request.headers["Authorization"] == "Session async-token"
            return httpx.Response(200, text="pong-async")
        return httpx.Response(404, text="not found")

    transport = httpx.MockTransport(handler)
    return httpx.AsyncClient(base_url="http://example.com", transport=transport)


@pytest.mark.anyio
async def test_async_httpx_transport_flow():
    config = ClientConfig(
        domain="example.com",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-async",
    )
    client = _mock_async_transport()
    transport = AsyncHttpxTransport(config, client=client)

    token = await transport.open_async(config.device_name)
    assert token == "async-token"

    response = await transport.request("GET", "/api/Ping", token=token)
    assert response.status_code == 200
    assert response.text == "pong-async"

    await transport.close_async(token)
    await transport.aclose()


@pytest.mark.anyio
async def test_async_httpx_transport_open_maps_http_errors_to_transport_error():
    async def handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(500, text="boom")

    config = ClientConfig(
        domain="example.com",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-async",
    )
    client = httpx.AsyncClient(base_url="http://example.com", transport=httpx.MockTransport(handler))
    transport = AsyncHttpxTransport(config, client=client)

    with pytest.raises(TransportError) as exc_info:
        await transport.open_async(config.device_name)

    assert exc_info.value.endpoint == "/api/Sessions/OpenNewSession"
    await transport.aclose()


@pytest.mark.anyio
async def test_async_httpx_transport_close_maps_http_errors_to_transport_error():
    async def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/Sessions/OpenNewSession":
            return httpx.Response(200, text='"token-1"')
        if request.url.path == "/api/Sessions/CloseSession":
            return httpx.Response(500, text="boom")
        return httpx.Response(404, text="not found")

    config = ClientConfig(
        domain="example.com",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-async",
    )
    client = httpx.AsyncClient(base_url="http://example.com", transport=httpx.MockTransport(handler))
    transport = AsyncHttpxTransport(config, client=client)

    token = await transport.open_async(config.device_name)
    with pytest.raises(TransportError) as exc_info:
        await transport.close_async(token)

    assert exc_info.value.endpoint == "/api/Sessions/CloseSession"
    await transport.aclose()


@pytest.mark.anyio
async def test_async_httpx_transport_sets_json_content_type_when_body_present():
    async def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/Payload":
            assert request.headers["Authorization"] == "Session token-xyz"
            assert request.headers["Content-Type"] == "application/json"
            return httpx.Response(200, text="ok")
        return httpx.Response(404, text="not found")

    config = ClientConfig(
        domain="example.com",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-async",
    )
    client = httpx.AsyncClient(base_url="http://example.com", transport=httpx.MockTransport(handler))
    transport = AsyncHttpxTransport(config, client=client)

    response = await transport.request("POST", "/api/Payload", token="token-xyz", data='{"x":1}')
    assert response.status_code == 200
    await transport.aclose()


@pytest.mark.anyio
async def test_async_httpx_transport_serializes_dict_payload_as_json():
    async def handler(request: httpx.Request) -> httpx.Response:
        if request.url.path == "/api/Payload":
            assert request.headers["Authorization"] == "Session token-xyz"
            assert request.headers["Content-Type"].startswith("application/json")
            assert request.content == b'{"x":1}'
            return httpx.Response(200, text="ok")
        return httpx.Response(404, text="not found")

    config = ClientConfig(
        domain="example.com",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-async",
    )
    client = httpx.AsyncClient(base_url="http://example.com", transport=httpx.MockTransport(handler))
    transport = AsyncHttpxTransport(config, client=client)

    response = await transport.request("POST", "/api/Payload", token="token-xyz", data={"x": 1})
    assert response.status_code == 200
    await transport.aclose()
