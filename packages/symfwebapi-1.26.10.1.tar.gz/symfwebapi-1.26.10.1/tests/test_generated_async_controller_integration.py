from __future__ import annotations

import json

from pydantic import ValidationError
import pytest

from SymfWebAPI import WebAPI
from SymfWebAPI.response import ResponseEnvelope


class _StubAsyncAPI:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []
        self.response_model: object | None = None
        self.response_text = "[]"

    async def request(self, method: str, path: str, *, params=None, data=None):
        self.calls.append(
            {
                "method": method,
                "path": path,
                "params": params,
                "data": data,
            }
        )
        return ResponseEnvelope(
            model=self.response_model,
            status=200,
            headers={"X-Test": "1"},
            raw_text=self.response_text,
        )


class _StubSyncAPI:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []
        self.response_model: object | None = None
        self.response_text = "[]"

    def request(self, method: str, path: str, *, params=None, data=None):
        self.calls.append(
            {
                "method": method,
                "path": path,
                "params": params,
                "data": data,
            }
        )
        return ResponseEnvelope(
            model=self.response_model,
            status=200,
            headers={"X-Test": "1"},
            raw_text=self.response_text,
        )


class _BodyStub:
    def __init__(self, payload: dict[str, object]) -> None:
        self.payload = payload
        self.dump_calls: list[bool] = []

    def model_dump_json(self, *, exclude_unset: bool) -> str:
        self.dump_calls.append(exclude_unset)
        return json.dumps(self.payload)


class _StubSyncInvokerAPI:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    def invoke(self, operation, *, params=None, data=None):
        self.calls.append(
            {
                "method": operation.method,
                "path": operation.path,
                "params": params,
                "data": data,
            }
        )
        raw = ResponseEnvelope(model=None, status=200, headers={"X-Test": "1"}, raw_text="[]")
        return operation.parser(raw)


class _StubAsyncInvokerAPI:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    async def invoke(self, operation, *, params=None, data=None):
        self.calls.append(
            {
                "method": operation.method,
                "path": operation.path,
                "params": params,
                "data": data,
            }
        )
        raw = ResponseEnvelope(model=None, status=200, headers={"X-Test": "1"}, raw_text="[]")
        return operation.parser(raw)


@pytest.mark.anyio
async def test_generated_async_controller_parses_response_and_uses_contract():
    api = _StubAsyncAPI()
    controller = WebAPI.Interface.Products.Interfaces.IProductsController

    result = await controller.Get(api, salePrices=False)

    assert isinstance(result.model, list)
    assert result.model == []
    assert result.status == 200
    assert api.calls == [
        {
            "method": "GET",
            "path": "/api/Products",
            "params": {"salePrices": False},
            "data": None,
        }
    ]


def test_generated_unified_controller_parses_response_for_sync_api():
    api = _StubSyncAPI()
    controller = WebAPI.Interface.Products.Interfaces.IProductsController

    result = controller.Get(api, salePrices=True)

    assert isinstance(result.model, list)
    assert result.model == []
    assert result.status == 200
    assert api.calls == [
        {
            "method": "GET",
            "path": "/api/Products",
            "params": {"salePrices": True},
            "data": None,
        }
    ]


@pytest.mark.anyio
async def test_generated_unified_controller_parses_response_for_async_api():
    api = _StubAsyncAPI()
    controller = WebAPI.Interface.Products.Interfaces.IProductsController

    result = await controller.Get(api, salePrices=False)

    assert isinstance(result.model, list)
    assert result.model == []
    assert result.status == 200
    assert api.calls == [
        {
            "method": "GET",
            "path": "/api/Products",
            "params": {"salePrices": False},
            "data": None,
        }
    ]


@pytest.mark.anyio
async def test_generated_async_controller_raises_on_invalid_json():
    class _InvalidJsonAPI(_StubAsyncAPI):
        async def request(self, method: str, path: str, *, params=None, data=None):
            self.calls.append(
                {
                    "method": method,
                    "path": path,
                    "params": params,
                    "data": data,
                }
            )
            return ResponseEnvelope(model=None, status=200, headers={"X-Test": "1"}, raw_text="{invalid")

    api = _InvalidJsonAPI()
    controller = WebAPI.Interface.Products.Interfaces.IProductsController

    with pytest.raises(ValidationError):
        await controller.Get(api, salePrices=False)


def test_generated_sync_update_serializes_body_with_model_dump_json():
    api = _StubSyncAPI()
    controller = WebAPI.Interface.Products.Interfaces.IProductsController
    body = _BodyStub({"Id": 1, "Code": "P1"})

    result = controller.Update(api, product=body)

    assert result.status == 200
    assert body.dump_calls == [True]
    assert api.calls == [
        {
            "method": "PUT",
            "path": "/api/Products/Update",
            "params": None,
            "data": '{"Id": 1, "Code": "P1"}',
        }
    ]


def test_generated_sync_get_paged_document_uses_enum_value_in_query():
    api = _StubSyncAPI()
    api.response_model = object()
    controller = WebAPI.Interface.Products.Interfaces.IProductsController
    order_by = WebAPI.Interface.Enums.enumOrderByType.Asc

    result = controller.GetPagedDocument(api, page=1, size=20, orderBy=order_by)

    assert result.model is api.response_model
    assert api.calls == [
        {
            "method": "GET",
            "path": "/api/Products/Page",
            "params": {"page": 1, "size": 20, "orderBy": order_by.value},
            "data": None,
        }
    ]


@pytest.mark.anyio
async def test_generated_async_get_paged_document_uses_enum_value_in_query():
    api = _StubAsyncAPI()
    api.response_model = object()
    controller = WebAPI.Interface.Products.Interfaces.IProductsController
    order_by = WebAPI.Interface.Enums.enumOrderByType.Desc

    result = await controller.GetPagedDocument(api, page=2, size=50, orderBy=order_by)

    assert result.model is api.response_model
    assert api.calls == [
        {
            "method": "GET",
            "path": "/api/Products/Page",
            "params": {"page": 2, "size": 50, "orderBy": order_by.value},
            "data": None,
        }
    ]


def test_generated_controller_uses_invoke_path_for_sync_invoker_api():
    api = _StubSyncInvokerAPI()
    controller = WebAPI.Interface.Products.Interfaces.IProductsController

    result = controller.Get(api, salePrices=False)

    assert result.model == []
    assert api.calls == [
        {
            "method": "GET",
            "path": "/api/Products",
            "params": {"salePrices": False},
            "data": None,
        }
    ]


@pytest.mark.anyio
async def test_generated_controller_uses_invoke_path_for_async_invoker_api():
    api = _StubAsyncInvokerAPI()
    controller = WebAPI.Interface.Products.Interfaces.IProductsController

    result = await controller.Get(api, salePrices=True)

    assert result.model == []
    assert api.calls == [
        {
            "method": "GET",
            "path": "/api/Products",
            "params": {"salePrices": True},
            "data": None,
        }
    ]
