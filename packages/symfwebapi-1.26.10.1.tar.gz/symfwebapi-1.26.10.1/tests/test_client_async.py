from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from types import SimpleNamespace
from typing import Any

import pytest

from SymfWebAPI.config import ClientConfig
from SymfWebAPI.client import AsyncAPI
from SymfWebAPI.operations import OperationSpec
from SymfWebAPI.session import SessionManager, SessionBackend
from SymfWebAPI.errors import WebAPIHttpError


class StubResponse:
    def __init__(self, status_code: int, text: str = ""):
        self.status_code = status_code
        self.text = text
        self.headers = {"X-Test": "1"}


class FakeBackend(SessionBackend):
    def __init__(self) -> None:
        self.counter = 0

    async def open_async(self, device_name: str) -> str:
        self.counter += 1
        return f"token-{self.counter}"

    def open_sync(self, device_name: str) -> str:
        raise NotImplementedError

    async def close_async(self, token: str) -> None:
        pass

    def close_sync(self, token: str) -> None:
        pass


async def fake_request(method: str, path: str, *, token: str, params: dict | None, data: Any) -> StubResponse:
    assert token == "token-1"
    return StubResponse(200, text="ok")


def test_async_api_request_ok():
    config = ClientConfig(
        domain="example",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-client",
    )
    backend = FakeBackend()
    manager = SessionManager(config, backend)
    api = AsyncAPI(config, manager, fake_request)

    async def run():
        resp = await api.request("GET", "/api/test")
        assert resp.status == 200
        assert resp.raw_text == "ok"

    asyncio.run(run())


def test_async_api_http_error():
    async def error_request(method, path, *, token, params, data):
        return StubResponse(500, text="boom")

    config = ClientConfig(
        domain="example",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-client",
    )
    backend = FakeBackend()
    manager = SessionManager(config, backend)
    api = AsyncAPI(config, manager, error_request)

    async def run():
        try:
            await api.request("GET", "/api/test")
        except WebAPIHttpError as exc:
            assert exc.status_code == 500
        else:
            raise AssertionError("Expected WebAPIHttpError")

    asyncio.run(run())


def test_async_api_401_retries_once_with_fresh_session():
    calls: list[tuple[str, str, str]] = []
    responses = [StubResponse(401, text="auth-error"), StubResponse(200, text="ok")]

    async def error_request(method, path, *, token, params, data):
        calls.append((method, path, token))
        return responses.pop(0)

    config = ClientConfig(
        domain="example",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-client",
    )
    backend = FakeBackend()
    manager = SessionManager(config, backend)
    api = AsyncAPI(config, manager, error_request)

    async def run():
        response = await api.request("GET", "/api/secured")
        assert response.status == 200
        assert calls == [
            ("GET", "/api/secured", "token-1"),
            ("GET", "/api/secured", "token-2"),
        ]
        assert await api.ensure_session() == "token-2"

    asyncio.run(run())


def test_async_api_403_does_not_retry_or_invalidate_session():
    calls: list[tuple[str, str, str]] = []

    async def error_request(method, path, *, token, params, data):
        calls.append((method, path, token))
        return StubResponse(403, text="forbidden")

    config = ClientConfig(
        domain="example",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-client",
    )
    backend = FakeBackend()
    manager = SessionManager(config, backend)
    api = AsyncAPI(config, manager, error_request)

    async def run():
        with pytest.raises(WebAPIHttpError) as exc_info:
            await api.request("GET", "/api/secured")
        assert exc_info.value.status_code == 403
        assert calls == [("GET", "/api/secured", "token-1")]
        assert await api.ensure_session() == "token-1"

    asyncio.run(run())


def test_async_api_request_serializes_datetime_query_params():
    dt = datetime(2026, 2, 25, 13, 14, 15, tzinfo=timezone.utc)
    captured_params: dict | None = None

    async def request(method, path, *, token, params, data):
        nonlocal captured_params
        captured_params = params
        return StubResponse(200, text="ok")

    config = ClientConfig(
        domain="example",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-client",
    )
    backend = FakeBackend()
    manager = SessionManager(config, backend)
    api = AsyncAPI(config, manager, request)

    async def run():
        await api.request("GET", "/api/secured", params={"from": dt})

    asyncio.run(run())
    assert captured_params == {"from": "2026-02-25T13:14:15+00:00"}


def test_async_api_request_serializes_nested_datetime_query_params():
    dt = datetime(2026, 2, 25, 13, 14, 15, tzinfo=timezone.utc)
    captured_params: dict | None = None

    async def request(method, path, *, token, params, data):
        nonlocal captured_params
        captured_params = params
        return StubResponse(200, text="ok")

    config = ClientConfig(
        domain="example",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-client",
    )
    backend = FakeBackend()
    manager = SessionManager(config, backend)
    api = AsyncAPI(config, manager, request)

    async def run():
        await api.request("GET", "/api/secured", params={"filter": {"from": dt, "items": [dt]}})

    asyncio.run(run())
    assert captured_params == {
        "filter": {
            "from": "2026-02-25T13:14:15+00:00",
            "items": ["2026-02-25T13:14:15+00:00"],
        }
    }


def test_async_api_invoke_does_not_offload_parsing_by_default(monkeypatch):
    async def request(method, path, *, token, params, data):
        return StubResponse(200, text="ok")

    async def _unexpected_to_thread(func, *args, **kwargs):
        raise AssertionError("to_thread should not be used when offload_async_parsing=False")

    monkeypatch.setattr("SymfWebAPI.client.asyncio.to_thread", _unexpected_to_thread)

    config = ClientConfig(
        domain="example",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-client",
    )
    backend = FakeBackend()
    manager = SessionManager(config, backend)
    api = AsyncAPI(config, manager, request)
    marker = SimpleNamespace(called=False)

    def parser(envelope):
        marker.called = True
        return envelope

    operation = OperationSpec(method="GET", path="/api/test", parser=parser)

    async def run():
        result = await api.invoke(operation)
        assert result.raw_text == "ok"

    asyncio.run(run())
    assert marker.called is True


def test_async_api_invoke_offloads_parsing_when_enabled(monkeypatch):
    async def request(method, path, *, token, params, data):
        return StubResponse(200, text="ok")

    calls = {"count": 0}

    async def _fake_to_thread(func, *args, **kwargs):
        calls["count"] += 1
        return func(*args, **kwargs)

    monkeypatch.setattr("SymfWebAPI.client.asyncio.to_thread", _fake_to_thread)

    config = ClientConfig(
        domain="example",
        application_key="00000000-0000-0000-0000-000000000000",
        device_name="dev-client",
        offload_async_parsing=True,
    )
    backend = FakeBackend()
    manager = SessionManager(config, backend)
    api = AsyncAPI(config, manager, request)

    def parser(envelope):
        return envelope

    operation = OperationSpec(method="GET", path="/api/test", parser=parser)

    async def run():
        result = await api.invoke(operation)
        assert result.raw_text == "ok"

    asyncio.run(run())
    assert calls["count"] == 1
