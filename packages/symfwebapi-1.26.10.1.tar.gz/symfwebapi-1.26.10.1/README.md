# SymfWebAPI

[![CI](https://github.com/maku2903/symf-webapi-py/actions/workflows/public-ci-release.yml/badge.svg)](https://github.com/maku2903/symf-webapi-py/actions/workflows/public-ci-release.yml)
[![PyPI version](https://img.shields.io/pypi/v/SymfWebAPI.svg)](https://pypi.org/project/SymfWebAPI/)
[![Python versions](https://img.shields.io/pypi/pyversions/SymfWebAPI.svg)](https://pypi.org/project/SymfWebAPI/)
[![License](https://img.shields.io/pypi/l/SymfWebAPI.svg)](https://github.com/maku2903/symf-webapi-py/blob/main/LICENSE)

Pythonowa biblioteka kliencka do Symfonia WebAPI (sync + async) z typowanymi modelami i wygenerowanymi kontrolerami.

## Instalacja

```bash
pip install SymfWebAPI
```

## Szybki start

```python
from SymfWebAPI import ClientConfig, WebAPI, build_async_client

config = ClientConfig(
    domain="host:9000",
    application_key="00000000-0000-0000-0000-000000000000",
    device_name="integration-client",
)

async with build_async_client(config) as api:
    resp = await WebAPI.Interface.Products.Interfaces.IProductsController.Get(api, salePrices=False)
    products = resp.unwrap()
    print(len(products))
```

## Dokumentacja

- Omówienie biblioteki: `docs/overview.md`
- Przykłady: `examples/`

## Benchmark bez sekretów

Przykład benchmarku znajduje się w:
- `examples/benchmark_order_details.py`

Konfiguracja przez zmienne środowiskowe (brak hardcode klucza):
- `SYMFWEBAPI_DOMAIN`
- `SYMFWEBAPI_APP_KEY`
- `SYMFWEBAPI_DEVICE_NAME` (opcjonalnie)
- `SYMFWEBAPI_HTTPS` (opcjonalnie, np. `true`/`false`)

## Wersjonowanie

Wersja paczki ma format `X.WM.Wm.I`, np. `1.26.10.3`:
- `X` - major SDK,
- `WM.Wm` - docelowa wersja Symfonia WebAPI,
- `I` - iteracja SDK dla tej samej wersji WebAPI.

## Licencja

BSD-3-Clause.
