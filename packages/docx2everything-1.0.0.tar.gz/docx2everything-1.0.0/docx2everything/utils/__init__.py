"""Utility functions for docx2everything."""

from .xml_utils import qn, NSMAP

__all__ = ['qn', 'NSMAP']
