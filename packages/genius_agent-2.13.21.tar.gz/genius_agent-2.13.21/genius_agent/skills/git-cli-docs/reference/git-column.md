[![Git](https://git-scm.com/images/logo@2x.png)](https://git-scm.com/) --distributed-is-the-new-centralized
![](https://git-scm.com/images/dark-mode.svg)
  * [About](https://git-scm.com/about)
    * [Trademark](https://git-scm.com/about/trademark)
  * [Learn](https://git-scm.com/learn)
    * [Book](https://git-scm.com/book)
    * [Cheat Sheet](https://git-scm.com/cheat-sheet)
    * [Videos](https://git-scm.com/videos)
    * [External Links](https://git-scm.com/doc/ext)
  * [Tools](https://git-scm.com/tools)
    * [Command Line](https://git-scm.com/tools/command-line)
    * [GUIs](https://git-scm.com/tools/guis)
    * [Hosting](https://git-scm.com/tools/hosting)
  * [Reference](https://git-scm.com/docs)
  * [Install](https://git-scm.com/install/linux)
  * [Community](https://git-scm.com/community)


  * Table of Contents
    * [NAME](https://git-scm.com/docs/git-column#_name)
    * [SYNOPSIS](https://git-scm.com/docs/git-column#_synopsis)
    * [DESCRIPTION](https://git-scm.com/docs/git-column#_description)
    * [OPTIONS](https://git-scm.com/docs/git-column#_options)
    * [EXAMPLES](https://git-scm.com/docs/git-column#_examples)
    * [CONFIGURATION](https://git-scm.com/docs/git-column#_configuration)
    * [GIT](https://git-scm.com/docs/git-column#_git)


[ English ▾](https://git-scm.com/docs/git-column)
Localized versions of **git-column** manual
  1. [English ](https://git-scm.com/docs/git-column)
  2. [Français ](https://git-scm.com/docs/git-column/fr)
  3. [Português (Brasil) ](https://git-scm.com/docs/git-column/pt_BR)
  4. [Svenska ](https://git-scm.com/docs/git-column/sv)
  5. [українська мова ](https://git-scm.com/docs/git-column/uk)
  6. [简体中文 ](https://git-scm.com/docs/git-column/zh_HANS-CN)

Want to read in your language or fix typos?
[You can help translate this page](https://github.com/jnavila/git-manpages-l10n).
[Topics ▾](https://git-scm.com/docs/git-column)
### Setup and Config
  * [ git ](https://git-scm.com/docs/git)
  * [ config ](https://git-scm.com/docs/git-config)
  * [ help ](https://git-scm.com/docs/git-help)
  * [ bugreport ](https://git-scm.com/docs/git-bugreport)
  * [ Credential helpers ](https://git-scm.com/doc/credential-helpers)


### Getting and Creating Projects
  * [ init ](https://git-scm.com/docs/git-init)
  * [ clone ](https://git-scm.com/docs/git-clone)


### Basic Snapshotting
  * [ add ](https://git-scm.com/docs/git-add)
  * [ status ](https://git-scm.com/docs/git-status)
  * [ diff ](https://git-scm.com/docs/git-diff)
  * [ commit ](https://git-scm.com/docs/git-commit)
  * [ notes ](https://git-scm.com/docs/git-notes)
  * [ restore ](https://git-scm.com/docs/git-restore)
  * [ reset ](https://git-scm.com/docs/git-reset)
  * [ rm ](https://git-scm.com/docs/git-rm)
  * [ mv ](https://git-scm.com/docs/git-mv)


### Branching and Merging
  * [ branch ](https://git-scm.com/docs/git-branch)
  * [ checkout ](https://git-scm.com/docs/git-checkout)
  * [ switch ](https://git-scm.com/docs/git-switch)
  * [ merge ](https://git-scm.com/docs/git-merge)
  * [ mergetool ](https://git-scm.com/docs/git-mergetool)
  * [ log ](https://git-scm.com/docs/git-log)
  * [ stash ](https://git-scm.com/docs/git-stash)
  * [ tag ](https://git-scm.com/docs/git-tag)
  * [ worktree ](https://git-scm.com/docs/git-worktree)


### Sharing and Updating Projects
  * [ fetch ](https://git-scm.com/docs/git-fetch)
  * [ pull ](https://git-scm.com/docs/git-pull)
  * [ push ](https://git-scm.com/docs/git-push)
  * [ remote ](https://git-scm.com/docs/git-remote)
  * [ submodule ](https://git-scm.com/docs/git-submodule)


### Inspection and Comparison
  * [ show ](https://git-scm.com/docs/git-show)
  * [ log ](https://git-scm.com/docs/git-log)
  * [ diff ](https://git-scm.com/docs/git-diff)
  * [ difftool ](https://git-scm.com/docs/git-difftool)
  * [ range-diff ](https://git-scm.com/docs/git-range-diff)
  * [ shortlog ](https://git-scm.com/docs/git-shortlog)
  * [ describe ](https://git-scm.com/docs/git-describe)


### Patching
  * [ apply ](https://git-scm.com/docs/git-apply)
  * [ cherry-pick ](https://git-scm.com/docs/git-cherry-pick)
  * [ diff ](https://git-scm.com/docs/git-diff)
  * [ rebase ](https://git-scm.com/docs/git-rebase)
  * [ revert ](https://git-scm.com/docs/git-revert)


### Debugging
  * [ bisect ](https://git-scm.com/docs/git-bisect)
  * [ blame ](https://git-scm.com/docs/git-blame)
  * [ grep ](https://git-scm.com/docs/git-grep)


### Email
  * [ am ](https://git-scm.com/docs/git-am)
  * [ apply ](https://git-scm.com/docs/git-apply)
  * [ imap-send ](https://git-scm.com/docs/git-imap-send)
  * [ format-patch ](https://git-scm.com/docs/git-format-patch)
  * [ send-email ](https://git-scm.com/docs/git-send-email)
  * [ request-pull ](https://git-scm.com/docs/git-request-pull)


### External Systems
  * [ svn ](https://git-scm.com/docs/git-svn)
  * [ fast-import ](https://git-scm.com/docs/git-fast-import)


### Server Admin
  * [ daemon ](https://git-scm.com/docs/git-daemon)
  * [ update-server-info ](https://git-scm.com/docs/git-update-server-info)


### Guides
  * [ gitattributes ](https://git-scm.com/docs/gitattributes)
  * [ Command-line interface conventions ](https://git-scm.com/docs/gitcli)
  * [ Everyday Git ](https://git-scm.com/docs/giteveryday)
  * [ Frequently Asked Questions (FAQ) ](https://git-scm.com/docs/gitfaq)
  * [ Glossary ](https://git-scm.com/docs/gitglossary)
  * [ Hooks ](https://git-scm.com/docs/githooks)
  * [ gitignore ](https://git-scm.com/docs/gitignore)
  * [ gitmodules ](https://git-scm.com/docs/gitmodules)
  * [ Revisions ](https://git-scm.com/docs/gitrevisions)
  * [ Submodules ](https://git-scm.com/docs/gitsubmodules)
  * [ Tutorial ](https://git-scm.com/docs/gittutorial)
  * [ Workflows ](https://git-scm.com/docs/gitworkflows)
  * [ All guides... ](https://git-scm.com/docs/git#_guides)


### Administration
  * [ clean ](https://git-scm.com/docs/git-clean)
  * [ gc ](https://git-scm.com/docs/git-gc)
  * [ fsck ](https://git-scm.com/docs/git-fsck)
  * [ reflog ](https://git-scm.com/docs/git-reflog)
  * [ filter-branch ](https://git-scm.com/docs/git-filter-branch)
  * [ instaweb ](https://git-scm.com/docs/git-instaweb)
  * [ archive ](https://git-scm.com/docs/git-archive)
  * [ bundle ](https://git-scm.com/docs/git-bundle)


### Plumbing Commands
  * [ cat-file ](https://git-scm.com/docs/git-cat-file)
  * [ check-ignore ](https://git-scm.com/docs/git-check-ignore)
  * [ checkout-index ](https://git-scm.com/docs/git-checkout-index)
  * [ commit-tree ](https://git-scm.com/docs/git-commit-tree)
  * [ count-objects ](https://git-scm.com/docs/git-count-objects)
  * [ diff-index ](https://git-scm.com/docs/git-diff-index)
  * [ for-each-ref ](https://git-scm.com/docs/git-for-each-ref)
  * [ hash-object ](https://git-scm.com/docs/git-hash-object)
  * [ ls-files ](https://git-scm.com/docs/git-ls-files)
  * [ ls-tree ](https://git-scm.com/docs/git-ls-tree)
  * [ merge-base ](https://git-scm.com/docs/git-merge-base)
  * [ read-tree ](https://git-scm.com/docs/git-read-tree)
  * [ rev-list ](https://git-scm.com/docs/git-rev-list)
  * [ rev-parse ](https://git-scm.com/docs/git-rev-parse)
  * [ show-ref ](https://git-scm.com/docs/git-show-ref)
  * [ symbolic-ref ](https://git-scm.com/docs/git-symbolic-ref)
  * [ update-index ](https://git-scm.com/docs/git-update-index)
  * [ update-ref ](https://git-scm.com/docs/git-update-ref)
  * [ verify-pack ](https://git-scm.com/docs/git-verify-pack)
  * [ write-tree ](https://git-scm.com/docs/git-write-tree)


[ Latest version ▾ ](https://git-scm.com/docs/git-column) git-column last updated in 2.50.0
Changes in the **git-column** manual
  1. 2.50.1 → 2.53.0 no changes
  2. [2.50.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2025-06-16_ ](https://git-scm.com/docs/git-column/2.50.0)
  3. 2.43.1 → 2.49.1 no changes
  4. [2.43.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2023-11-20_ ](https://git-scm.com/docs/git-column/2.43.0)
  5. 2.38.1 → 2.42.4 no changes
  6. [2.38.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2022-10-02_ ](https://git-scm.com/docs/git-column/2.38.0)
  7. 2.33.2 → 2.37.7 no changes
  8. [2.33.1 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2021-10-12_ ](https://git-scm.com/docs/git-column/2.33.1)
  9. 2.21.1 → 2.33.0 no changes
  10. [2.21.0 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2019-02-24_ ](https://git-scm.com/docs/git-column/2.21.0)
  11. 2.19.3 → 2.20.5 no changes
  12. [2.19.2 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2018-11-21_ ](https://git-scm.com/docs/git-column/2.19.2)
  13. 2.1.4 → 2.19.1 no changes
  14. [2.0.5 ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/green-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/red-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) ![](https://git-scm.com/images/icons/grey-dot.png) _2014-12-17_ ](https://git-scm.com/docs/git-column/2.0.5)


Check your version of git by running
`git --version`
##  [](https://git-scm.com/docs/git-column#_name)NAME
git-column - Display data in columns
##  [](https://git-scm.com/docs/git-column#_synopsis)SYNOPSIS
```
_git column_ [--command=<name>] [--[raw-]mode=<mode>] [--width=<width>]
	     [--indent=<string>] [--nl=<string>] [--padding=<n>]
```

##  [](https://git-scm.com/docs/git-column#_description)DESCRIPTION
This command formats the lines of its standard input into a table with multiple columns. Each input line occupies one cell of the table. It is used internally by other git commands to format output into columns.
##  [](https://git-scm.com/docs/git-column#_options)OPTIONS

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt---commandname)--command=<name>

Look up layout mode using configuration variable column.<name> and column.ui.

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt---modemode)--mode=<mode>

Specify layout mode. See configuration variable column.ui for option syntax in [git-config[1]](https://git-scm.com/docs/git-config).

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt---raw-moden)--raw-mode=<n>

Same as --mode but take mode encoded as a number. This is mainly used by other commands that have already parsed layout mode.

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt---widthwidth)--width=<width>

Specify the terminal width. By default _git column_ will detect the terminal width, or fall back to 80 if it is unable to do so.

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt---indentstring)--indent=<string>

String to be printed at the beginning of each line.

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt---nlstring)--nl=<string>

String to be printed at the end of each line, including newline character.

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt---paddingN)--padding=<N>

The number of spaces between columns. One space by default.
##  [](https://git-scm.com/docs/git-column#_examples)EXAMPLES
Format data by columns:
```
$ seq 1 24 | git column --mode=column --padding=5
1      4      7      10     13     16     19     22
2      5      8      11     14     17     20     23
3      6      9      12     15     18     21     24
```

Format data by rows:
```
$ seq 1 21 | git column --mode=row --padding=5
1      2      3      4      5      6      7
8      9      10     11     12     13     14
15     16     17     18     19     20     21
```

List some tags in a table with unequal column widths:
```
$ git tag --list 'v2.4.*' --column=row,dense
v2.4.0  v2.4.0-rc0  v2.4.0-rc1  v2.4.0-rc2  v2.4.0-rc3
v2.4.1  v2.4.10     v2.4.11     v2.4.12     v2.4.2
v2.4.3  v2.4.4      v2.4.5      v2.4.6      v2.4.7
v2.4.8  v2.4.9
```

##  [](https://git-scm.com/docs/git-column#_configuration)CONFIGURATION
Everything below this line in this section is selectively included from the [git-config[1]](https://git-scm.com/docs/git-config) documentation. The content is the same as what’s found there:

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-columnui)column.ui

Specify whether supported commands should output in columns. This variable consists of a list of tokens separated by spaces or commas:
These options control when the feature should be enabled (defaults to _never_):

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-always)`always`

always show in columns

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-never)`never`

never show in columns

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-auto)`auto`

show in columns if the output is to the terminal
These options control layout (defaults to _column_). Setting any of these implies _always_ if none of _always_ , _never_ , or _auto_ are specified.

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-column)`column`

fill columns before rows

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-row)`row`

fill rows before columns

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-plain)`plain`

show in one column
Finally, these options can be combined with a layout option (defaults to _nodense_):

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-dense)`dense`

make unequal size columns to utilize more space

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-nodense)`nodense`

make equal size columns

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-columnbranch)column.branch

Specify whether to output branch listing in `git` `branch` in columns. See `column.ui` for details.

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-columnclean)column.clean

Specify the layout when listing items in `git` `clean` `-i`, which always shows files and directories in columns. See `column.ui` for details.

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-columnstatus)column.status

Specify whether to output untracked files in `git` `status` in columns. See `column.ui` for details.

[](https://git-scm.com/docs/git-column#Documentation/git-column.txt-columntag)column.tag

Specify whether to output tag listings in `git` `tag` in columns. See `column.ui` for details.
##  [](https://git-scm.com/docs/git-column#_git)GIT
Part of the [git[1]](https://git-scm.com/docs/git) suite
### column
[About this site](https://git-scm.com/site)
Patches, suggestions, and comments are welcome.
Git is a member of [Software Freedom Conservancy](https://git-scm.com/sfc)
