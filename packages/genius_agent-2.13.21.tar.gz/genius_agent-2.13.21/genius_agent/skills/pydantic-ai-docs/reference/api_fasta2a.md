[ Skip to content ](https://ai.pydantic.dev/api/fasta2a/#fasta2a_1)
**Join us at the inaugural PyAI Conf in San Francisco on March 10th![Learn More](https://pyai.events/?utm_source=pydantic-ai) **
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI")
Pydantic AI
fasta2a
Type to start searching
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI") Pydantic AI
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
  * [ Pydantic AI  ](https://ai.pydantic.dev/)
  * [ Installation  ](https://ai.pydantic.dev/install/)
  * [ Getting Help  ](https://ai.pydantic.dev/help/)
  * [ Troubleshooting  ](https://ai.pydantic.dev/troubleshooting/)
  * [ Pydantic AI Gateway  ](https://ai.pydantic.dev/gateway/)
  * Documentation
    * Core Concepts
      * [ Agents  ](https://ai.pydantic.dev/agent/)
      * [ Dependencies  ](https://ai.pydantic.dev/dependencies/)
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Output  ](https://ai.pydantic.dev/output/)
      * [ Messages and chat history  ](https://ai.pydantic.dev/message-history/)
      * [ Direct Model Requests  ](https://ai.pydantic.dev/direct/)
    * Models & Providers
      * [ Overview  ](https://ai.pydantic.dev/models/overview/)
      * [ OpenAI  ](https://ai.pydantic.dev/models/openai/)
      * [ Anthropic  ](https://ai.pydantic.dev/models/anthropic/)
      * [ Google  ](https://ai.pydantic.dev/models/google/)
      * [ xAI  ](https://ai.pydantic.dev/models/xai/)
      * [ Bedrock  ](https://ai.pydantic.dev/models/bedrock/)
      * [ Cerebras  ](https://ai.pydantic.dev/models/cerebras/)
      * [ Cohere  ](https://ai.pydantic.dev/models/cohere/)
      * [ Groq  ](https://ai.pydantic.dev/models/groq/)
      * [ Hugging Face  ](https://ai.pydantic.dev/models/huggingface/)
      * [ Mistral  ](https://ai.pydantic.dev/models/mistral/)
      * [ OpenRouter  ](https://ai.pydantic.dev/models/openrouter/)
      * [ Outlines  ](https://ai.pydantic.dev/models/outlines/)
    * Tools & Toolsets
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Advanced Tool Features  ](https://ai.pydantic.dev/tools-advanced/)
      * [ Toolsets  ](https://ai.pydantic.dev/toolsets/)
      * [ Deferred Tools  ](https://ai.pydantic.dev/deferred-tools/)
      * [ Built-in Tools  ](https://ai.pydantic.dev/builtin-tools/)
      * [ Common Tools  ](https://ai.pydantic.dev/common-tools/)
      * [ Third-Party Tools  ](https://ai.pydantic.dev/third-party-tools/)
    * Advanced Features
      * [ Image, Audio, Video & Document Input  ](https://ai.pydantic.dev/input/)
      * [ Thinking  ](https://ai.pydantic.dev/thinking/)
      * [ HTTP Request Retries  ](https://ai.pydantic.dev/retries/)
    * MCP
      * [ Overview  ](https://ai.pydantic.dev/mcp/overview/)
      * [ Client  ](https://ai.pydantic.dev/mcp/client/)
      * [ FastMCP Client  ](https://ai.pydantic.dev/mcp/fastmcp-client/)
      * [ Server  ](https://ai.pydantic.dev/mcp/server/)
    * [ Multi-Agent Patterns  ](https://ai.pydantic.dev/multi-agent-applications/)
    * [ Web Chat UI  ](https://ai.pydantic.dev/web/)
    * [ Embeddings  ](https://ai.pydantic.dev/embeddings/)
    * [ Testing  ](https://ai.pydantic.dev/testing/)
  * Pydantic Evals
    * [ Overview  ](https://ai.pydantic.dev/evals/)
    * Getting Started
      * [ Quick Start  ](https://ai.pydantic.dev/evals/quick-start/)
      * [ Core Concepts  ](https://ai.pydantic.dev/evals/core-concepts/)
    * Evaluators
      * [ Overview  ](https://ai.pydantic.dev/evals/evaluators/overview/)
      * [ Built-in Evaluators  ](https://ai.pydantic.dev/evals/evaluators/built-in/)
      * [ LLM Judge  ](https://ai.pydantic.dev/evals/evaluators/llm-judge/)
      * [ Custom Evaluators  ](https://ai.pydantic.dev/evals/evaluators/custom/)
      * [ Report Evaluators  ](https://ai.pydantic.dev/evals/evaluators/report-evaluators/)
      * [ Span-Based  ](https://ai.pydantic.dev/evals/evaluators/span-based/)
    * How-To Guides
      * [ Logfire Integration  ](https://ai.pydantic.dev/evals/how-to/logfire-integration/)
      * [ Dataset Management  ](https://ai.pydantic.dev/evals/how-to/dataset-management/)
      * [ Dataset Serialization  ](https://ai.pydantic.dev/evals/how-to/dataset-serialization/)
      * [ Concurrency & Performance  ](https://ai.pydantic.dev/evals/how-to/concurrency/)
      * [ Multi-Run Evaluation  ](https://ai.pydantic.dev/evals/how-to/multi-run/)
      * [ Retry Strategies  ](https://ai.pydantic.dev/evals/how-to/retry-strategies/)
      * [ Metrics & Attributes  ](https://ai.pydantic.dev/evals/how-to/metrics-attributes/)
    * Examples
      * [ Simple Validation  ](https://ai.pydantic.dev/evals/examples/simple-validation/)
  * Pydantic Graph
    * [ Overview  ](https://ai.pydantic.dev/graph/)
    * [ Beta API  ](https://ai.pydantic.dev/graph/beta/)
      * [ Steps  ](https://ai.pydantic.dev/graph/beta/steps/)
      * [ Joins & Reducers  ](https://ai.pydantic.dev/graph/beta/joins/)
      * [ Decisions  ](https://ai.pydantic.dev/graph/beta/decisions/)
      * [ Parallel Execution  ](https://ai.pydantic.dev/graph/beta/parallel/)
  * Integrations
    * [ Debugging & Monitoring with Pydantic Logfire  ](https://ai.pydantic.dev/logfire/)
    * Durable Execution
      * [ Overview  ](https://ai.pydantic.dev/durable_execution/overview/)
      * [ Temporal  ](https://ai.pydantic.dev/durable_execution/temporal/)
      * [ DBOS  ](https://ai.pydantic.dev/durable_execution/dbos/)
      * [ Prefect  ](https://ai.pydantic.dev/durable_execution/prefect/)
    * UI Event Streams
      * [ Overview  ](https://ai.pydantic.dev/ui/overview/)
      * [ AG-UI  ](https://ai.pydantic.dev/ui/ag-ui/)
      * [ Vercel AI  ](https://ai.pydantic.dev/ui/vercel-ai/)
    * [ Agent2Agent (A2A)  ](https://ai.pydantic.dev/a2a/)
  * Related Packages
    * [ clai  ](https://ai.pydantic.dev/cli/)
  * Examples
    * [ Setup  ](https://ai.pydantic.dev/examples/setup/)
    * Getting Started
      * [ Pydantic Model  ](https://ai.pydantic.dev/examples/pydantic-model/)
      * [ Weather agent  ](https://ai.pydantic.dev/examples/weather-agent/)
    * Conversational Agents
      * [ Chat App with FastAPI  ](https://ai.pydantic.dev/examples/chat-app/)
      * [ Bank support  ](https://ai.pydantic.dev/examples/bank-support/)
    * Data & Analytics
      * [ SQL Generation  ](https://ai.pydantic.dev/examples/sql-gen/)
      * [ Data Analyst  ](https://ai.pydantic.dev/examples/data-analyst/)
      * [ RAG  ](https://ai.pydantic.dev/examples/rag/)
    * Streaming
      * [ Stream markdown  ](https://ai.pydantic.dev/examples/stream-markdown/)
      * [ Stream whales  ](https://ai.pydantic.dev/examples/stream-whales/)
    * Complex Workflows
      * [ Flight booking  ](https://ai.pydantic.dev/examples/flight-booking/)
      * [ Question Graph  ](https://ai.pydantic.dev/examples/question-graph/)
    * Business Applications
      * [ Slack Lead Qualifier with Modal  ](https://ai.pydantic.dev/examples/slack-lead-qualifier/)
    * UI Examples
      * [ Agent User Interaction (AG-UI)  ](https://ai.pydantic.dev/examples/ag-ui/)
  * API Reference
    * pydantic_ai
      * [ pydantic_ai.ag_ui  ](https://ai.pydantic.dev/api/ag_ui/)
      * [ pydantic_ai.agent  ](https://ai.pydantic.dev/api/agent/)
      * [ pydantic_ai.builtin_tools  ](https://ai.pydantic.dev/api/builtin_tools/)
      * [ pydantic_ai.common_tools  ](https://ai.pydantic.dev/api/common_tools/)
      * [ pydantic_ai — Concurrency  ](https://ai.pydantic.dev/api/concurrency/)
      * [ pydantic_ai.direct  ](https://ai.pydantic.dev/api/direct/)
      * [ pydantic_ai.durable_exec  ](https://ai.pydantic.dev/api/durable_exec/)
      * [ pydantic_ai.embeddings  ](https://ai.pydantic.dev/api/embeddings/)
      * [ pydantic_ai.exceptions  ](https://ai.pydantic.dev/api/exceptions/)
      * [ pydantic_ai.ext  ](https://ai.pydantic.dev/api/ext/)
      * [ pydantic_ai.format_prompt  ](https://ai.pydantic.dev/api/format_prompt/)
      * [ pydantic_ai.mcp  ](https://ai.pydantic.dev/api/mcp/)
      * [ pydantic_ai.messages  ](https://ai.pydantic.dev/api/messages/)
      * [ pydantic_ai.models.anthropic  ](https://ai.pydantic.dev/api/models/anthropic/)
      * [ pydantic_ai.models  ](https://ai.pydantic.dev/api/models/base/)
      * [ pydantic_ai.models.bedrock  ](https://ai.pydantic.dev/api/models/bedrock/)
      * [ pydantic_ai.models.cerebras  ](https://ai.pydantic.dev/api/models/cerebras/)
      * [ pydantic_ai.models.cohere  ](https://ai.pydantic.dev/api/models/cohere/)
      * [ pydantic_ai.models.fallback  ](https://ai.pydantic.dev/api/models/fallback/)
      * [ pydantic_ai.models.function  ](https://ai.pydantic.dev/api/models/function/)
      * [ pydantic_ai.models.google  ](https://ai.pydantic.dev/api/models/google/)
      * [ pydantic_ai.models.xai  ](https://ai.pydantic.dev/api/models/xai/)
      * [ pydantic_ai.models.groq  ](https://ai.pydantic.dev/api/models/groq/)
      * [ pydantic_ai.models.huggingface  ](https://ai.pydantic.dev/api/models/huggingface/)
      * [ pydantic_ai.models.instrumented  ](https://ai.pydantic.dev/api/models/instrumented/)
      * [ pydantic_ai.models.mcp_sampling  ](https://ai.pydantic.dev/api/models/mcp-sampling/)
      * [ pydantic_ai.models.mistral  ](https://ai.pydantic.dev/api/models/mistral/)
      * [ pydantic_ai.models.openai  ](https://ai.pydantic.dev/api/models/openai/)
      * [ pydantic_ai.models.openrouter  ](https://ai.pydantic.dev/api/models/openrouter/)
      * [ pydantic_ai.models.outlines  ](https://ai.pydantic.dev/api/models/outlines/)
      * [ pydantic_ai.models.test  ](https://ai.pydantic.dev/api/models/test/)
      * [ pydantic_ai.models.wrapper  ](https://ai.pydantic.dev/api/models/wrapper/)
      * [ pydantic_ai.output  ](https://ai.pydantic.dev/api/output/)
      * [ pydantic_ai.profiles  ](https://ai.pydantic.dev/api/profiles/)
      * [ pydantic_ai.providers  ](https://ai.pydantic.dev/api/providers/)
      * [ pydantic_ai.result  ](https://ai.pydantic.dev/api/result/)
      * [ pydantic_ai.retries  ](https://ai.pydantic.dev/api/retries/)
      * [ pydantic_ai.run  ](https://ai.pydantic.dev/api/run/)
      * [ pydantic_ai.settings  ](https://ai.pydantic.dev/api/settings/)
      * [ pydantic_ai.tools  ](https://ai.pydantic.dev/api/tools/)
      * [ pydantic_ai.toolsets  ](https://ai.pydantic.dev/api/toolsets/)
      * [ pydantic_ai.ui.ag_ui  ](https://ai.pydantic.dev/api/ui/ag_ui/)
      * [ pydantic_ai.ui  ](https://ai.pydantic.dev/api/ui/base/)
      * [ pydantic_ai.ui.vercel_ai  ](https://ai.pydantic.dev/api/ui/vercel_ai/)
      * [ pydantic_ai.usage  ](https://ai.pydantic.dev/api/usage/)
    * pydantic_evals
      * [ pydantic_evals.dataset  ](https://ai.pydantic.dev/api/pydantic_evals/dataset/)
      * [ pydantic_evals.evaluators  ](https://ai.pydantic.dev/api/pydantic_evals/evaluators/)
      * [ pydantic_evals.reporting  ](https://ai.pydantic.dev/api/pydantic_evals/reporting/)
      * [ pydantic_evals.otel  ](https://ai.pydantic.dev/api/pydantic_evals/otel/)
      * [ pydantic_evals.generation  ](https://ai.pydantic.dev/api/pydantic_evals/generation/)
    * pydantic_graph
      * [ pydantic_graph  ](https://ai.pydantic.dev/api/pydantic_graph/graph/)
      * [ pydantic_graph.nodes  ](https://ai.pydantic.dev/api/pydantic_graph/nodes/)
      * [ pydantic_graph.persistence  ](https://ai.pydantic.dev/api/pydantic_graph/persistence/)
      * [ pydantic_graph.mermaid  ](https://ai.pydantic.dev/api/pydantic_graph/mermaid/)
      * [ pydantic_graph.exceptions  ](https://ai.pydantic.dev/api/pydantic_graph/exceptions/)
      * Beta API
        * [ pydantic_graph.beta  ](https://ai.pydantic.dev/api/pydantic_graph/beta/)
        * [ pydantic_graph.beta.graph  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph/)
        * [ pydantic_graph.beta.graph_builder  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph_builder/)
        * [ pydantic_graph.beta.step  ](https://ai.pydantic.dev/api/pydantic_graph/beta_step/)
        * [ pydantic_graph.beta.join  ](https://ai.pydantic.dev/api/pydantic_graph/beta_join/)
        * [ pydantic_graph.beta.decision  ](https://ai.pydantic.dev/api/pydantic_graph/beta_decision/)
        * [ pydantic_graph.beta.node  ](https://ai.pydantic.dev/api/pydantic_graph/beta_node/)
    * fasta2a
      * fasta2a  [ fasta2a  ](https://ai.pydantic.dev/api/fasta2a/)
        * [ fasta2a  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a)
        * [ FastA2A  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.FastA2A)
        * [ Broker  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Broker)
          * [ run_task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Broker.run_task)
          * [ cancel_task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Broker.cancel_task)
          * [ receive_task_operations  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Broker.receive_task_operations)
        * [ Skill  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill)
          * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.id)
          * [ name  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.name)
          * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.description)
          * [ tags  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.tags)
          * [ examples  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.examples)
          * [ input_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.input_modes)
          * [ output_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.output_modes)
        * [ Storage  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage)
          * [ load_task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage.load_task)
          * [ submit_task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage.submit_task)
          * [ update_task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage.update_task)
          * [ load_context  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage.load_context)
          * [ update_context  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage.update_context)
        * [ Worker  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Worker)
          * [ run  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Worker.run)
        * [ schema  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema)
        * [ AgentCard  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard)
          * [ name  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.name)
          * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.description)
          * [ url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.url)
          * [ version  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.version)
          * [ protocol_version  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.protocol_version)
          * [ provider  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.provider)
          * [ documentation_url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.documentation_url)
          * [ icon_url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.icon_url)
          * [ preferred_transport  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.preferred_transport)
          * [ additional_interfaces  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.additional_interfaces)
          * [ capabilities  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.capabilities)
          * [ security  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.security)
          * [ security_schemes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.security_schemes)
          * [ default_input_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.default_input_modes)
          * [ default_output_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.default_output_modes)
          * [ skills  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.skills)
        * [ AgentProvider  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentProvider)
          * [ organization  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentProvider.organization)
          * [ url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentProvider.url)
        * [ AgentCapabilities  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCapabilities)
          * [ streaming  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCapabilities.streaming)
          * [ push_notifications  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCapabilities.push_notifications)
          * [ state_transition_history  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCapabilities.state_transition_history)
        * [ HttpSecurityScheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.HttpSecurityScheme)
          * [ type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.HttpSecurityScheme.type)
          * [ scheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.HttpSecurityScheme.scheme)
          * [ bearer_format  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.HttpSecurityScheme.bearer_format)
          * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.HttpSecurityScheme.description)
        * [ ApiKeySecurityScheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ApiKeySecurityScheme)
          * [ type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ApiKeySecurityScheme.type)
          * [ name  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ApiKeySecurityScheme.name)
          * [ in_  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ApiKeySecurityScheme.in_)
          * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ApiKeySecurityScheme.description)
        * [ OAuth2SecurityScheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OAuth2SecurityScheme)
          * [ type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OAuth2SecurityScheme.type)
          * [ flows  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OAuth2SecurityScheme.flows)
          * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OAuth2SecurityScheme.description)
        * [ OpenIdConnectSecurityScheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OpenIdConnectSecurityScheme)
          * [ type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OpenIdConnectSecurityScheme.type)
          * [ open_id_connect_url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OpenIdConnectSecurityScheme.open_id_connect_url)
          * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OpenIdConnectSecurityScheme.description)
        * [ SecurityScheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SecurityScheme)
        * [ AgentInterface  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentInterface)
          * [ transport  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentInterface.transport)
          * [ url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentInterface.url)
          * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentInterface.description)
        * [ AgentExtension  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentExtension)
          * [ uri  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentExtension.uri)
          * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentExtension.description)
          * [ required  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentExtension.required)
          * [ params  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentExtension.params)
        * [ Skill  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill)
          * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.id)
          * [ name  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.name)
          * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.description)
          * [ tags  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.tags)
          * [ examples  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.examples)
          * [ input_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.input_modes)
          * [ output_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.output_modes)
        * [ Artifact  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact)
          * [ artifact_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.artifact_id)
          * [ name  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.name)
          * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.description)
          * [ parts  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.parts)
          * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.metadata)
          * [ extensions  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.extensions)
          * [ append  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.append)
          * [ last_chunk  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.last_chunk)
        * [ PushNotificationConfig  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig)
          * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig.id)
          * [ url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig.url)
          * [ token  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig.token)
          * [ authentication  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig.authentication)
        * [ TaskPushNotificationConfig  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskPushNotificationConfig)
          * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskPushNotificationConfig.id)
          * [ push_notification_config  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskPushNotificationConfig.push_notification_config)
        * [ Message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message)
          * [ role  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.role)
          * [ parts  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.parts)
          * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.kind)
          * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.metadata)
          * [ message_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.message_id)
          * [ context_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.context_id)
          * [ task_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.task_id)
          * [ reference_task_ids  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.reference_task_ids)
          * [ extensions  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.extensions)
        * [ TextPart  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TextPart)
          * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TextPart.kind)
          * [ text  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TextPart.text)
        * [ FileWithBytes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithBytes)
          * [ bytes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithBytes.bytes)
          * [ mime_type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithBytes.mime_type)
        * [ FileWithUri  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithUri)
          * [ uri  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithUri.uri)
          * [ mime_type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithUri.mime_type)
        * [ FilePart  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FilePart)
          * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FilePart.kind)
          * [ file  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FilePart.file)
        * [ DataPart  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DataPart)
          * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DataPart.kind)
          * [ data  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DataPart.data)
        * [ Part  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Part)
        * [ TaskState  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskState)
        * [ TaskStatus  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatus)
          * [ state  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatus.state)
          * [ message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatus.message)
          * [ timestamp  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatus.timestamp)
        * [ Task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task)
          * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.id)
          * [ context_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.context_id)
          * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.kind)
          * [ status  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.status)
          * [ history  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.history)
          * [ artifacts  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.artifacts)
          * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.metadata)
        * [ TaskStatusUpdateEvent  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent)
          * [ task_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.task_id)
          * [ context_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.context_id)
          * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.kind)
          * [ status  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.status)
          * [ final  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.final)
          * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.metadata)
        * [ TaskArtifactUpdateEvent  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent)
          * [ task_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.task_id)
          * [ context_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.context_id)
          * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.kind)
          * [ artifact  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.artifact)
          * [ append  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.append)
          * [ last_chunk  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.last_chunk)
          * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.metadata)
        * [ TaskIdParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskIdParams)
          * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskIdParams.id)
          * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskIdParams.metadata)
        * [ TaskQueryParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskQueryParams)
          * [ history_length  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskQueryParams.history_length)
        * [ MessageSendConfiguration  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration)
          * [ accepted_output_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration.accepted_output_modes)
          * [ blocking  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration.blocking)
          * [ history_length  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration.history_length)
          * [ push_notification_config  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration.push_notification_config)
        * [ MessageSendParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendParams)
          * [ configuration  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendParams.configuration)
          * [ message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendParams.message)
          * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendParams.metadata)
        * [ TaskSendParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams)
          * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams.id)
          * [ context_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams.context_id)
          * [ message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams.message)
          * [ history_length  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams.history_length)
          * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams.metadata)
        * [ ListTaskPushNotificationConfigParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ListTaskPushNotificationConfigParams)
          * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ListTaskPushNotificationConfigParams.id)
          * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ListTaskPushNotificationConfigParams.metadata)
        * [ DeleteTaskPushNotificationConfigParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigParams)
          * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigParams.id)
          * [ push_notification_config_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigParams.push_notification_config_id)
          * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigParams.metadata)
        * [ JSONRPCMessage  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCMessage)
          * [ jsonrpc  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCMessage.jsonrpc)
          * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCMessage.id)
        * [ JSONRPCRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest)
          * [ method  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest.method)
          * [ params  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest.params)
        * [ JSONRPCError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError)
          * [ code  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError.code)
          * [ message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError.message)
          * [ data  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError.data)
        * [ JSONRPCResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCResponse)
        * [ JSONParseError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONParseError)
        * [ InvalidRequestError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.InvalidRequestError)
        * [ MethodNotFoundError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MethodNotFoundError)
        * [ InvalidParamsError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.InvalidParamsError)
        * [ InternalError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.InternalError)
        * [ TaskNotFoundError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskNotFoundError)
        * [ TaskNotCancelableError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskNotCancelableError)
        * [ PushNotificationNotSupportedError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationNotSupportedError)
        * [ UnsupportedOperationError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.UnsupportedOperationError)
        * [ ContentTypeNotSupportedError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ContentTypeNotSupportedError)
        * [ InvalidAgentResponseError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.InvalidAgentResponseError)
        * [ SendMessageRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SendMessageRequest)
        * [ SendMessageResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SendMessageResponse)
        * [ StreamMessageRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.StreamMessageRequest)
        * [ StreamMessageResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.StreamMessageResponse)
        * [ GetTaskRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskRequest)
        * [ GetTaskResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskResponse)
        * [ CancelTaskRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.CancelTaskRequest)
        * [ CancelTaskResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.CancelTaskResponse)
        * [ SetTaskPushNotificationRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SetTaskPushNotificationRequest)
        * [ SetTaskPushNotificationResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SetTaskPushNotificationResponse)
        * [ GetTaskPushNotificationRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskPushNotificationRequest)
        * [ GetTaskPushNotificationResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskPushNotificationResponse)
        * [ ResubscribeTaskRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ResubscribeTaskRequest)
        * [ ListTaskPushNotificationConfigRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ListTaskPushNotificationConfigRequest)
        * [ DeleteTaskPushNotificationConfigRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigRequest)
        * [ A2ARequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.A2ARequest)
        * [ A2AResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.A2AResponse)
        * [ client  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.client)
        * [ A2AClient  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.client.A2AClient)
          * [ send_message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.client.A2AClient.send_message)
        * [ UnexpectedResponseError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.client.UnexpectedResponseError)
  * Project
    * [ Contributing  ](https://ai.pydantic.dev/contributing/)
    * [ Upgrade Guide  ](https://ai.pydantic.dev/changelog/)
    * [ Version policy  ](https://ai.pydantic.dev/version-policy/)


  * [ fasta2a  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a)
  * [ FastA2A  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.FastA2A)
  * [ Broker  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Broker)
    * [ run_task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Broker.run_task)
    * [ cancel_task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Broker.cancel_task)
    * [ receive_task_operations  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Broker.receive_task_operations)
  * [ Skill  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill)
    * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.id)
    * [ name  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.name)
    * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.description)
    * [ tags  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.tags)
    * [ examples  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.examples)
    * [ input_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.input_modes)
    * [ output_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Skill.output_modes)
  * [ Storage  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage)
    * [ load_task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage.load_task)
    * [ submit_task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage.submit_task)
    * [ update_task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage.update_task)
    * [ load_context  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage.load_context)
    * [ update_context  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Storage.update_context)
  * [ Worker  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Worker)
    * [ run  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.Worker.run)
  * [ schema  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema)
  * [ AgentCard  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard)
    * [ name  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.name)
    * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.description)
    * [ url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.url)
    * [ version  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.version)
    * [ protocol_version  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.protocol_version)
    * [ provider  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.provider)
    * [ documentation_url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.documentation_url)
    * [ icon_url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.icon_url)
    * [ preferred_transport  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.preferred_transport)
    * [ additional_interfaces  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.additional_interfaces)
    * [ capabilities  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.capabilities)
    * [ security  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.security)
    * [ security_schemes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.security_schemes)
    * [ default_input_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.default_input_modes)
    * [ default_output_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.default_output_modes)
    * [ skills  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCard.skills)
  * [ AgentProvider  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentProvider)
    * [ organization  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentProvider.organization)
    * [ url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentProvider.url)
  * [ AgentCapabilities  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCapabilities)
    * [ streaming  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCapabilities.streaming)
    * [ push_notifications  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCapabilities.push_notifications)
    * [ state_transition_history  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCapabilities.state_transition_history)
  * [ HttpSecurityScheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.HttpSecurityScheme)
    * [ type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.HttpSecurityScheme.type)
    * [ scheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.HttpSecurityScheme.scheme)
    * [ bearer_format  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.HttpSecurityScheme.bearer_format)
    * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.HttpSecurityScheme.description)
  * [ ApiKeySecurityScheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ApiKeySecurityScheme)
    * [ type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ApiKeySecurityScheme.type)
    * [ name  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ApiKeySecurityScheme.name)
    * [ in_  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ApiKeySecurityScheme.in_)
    * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ApiKeySecurityScheme.description)
  * [ OAuth2SecurityScheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OAuth2SecurityScheme)
    * [ type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OAuth2SecurityScheme.type)
    * [ flows  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OAuth2SecurityScheme.flows)
    * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OAuth2SecurityScheme.description)
  * [ OpenIdConnectSecurityScheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OpenIdConnectSecurityScheme)
    * [ type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OpenIdConnectSecurityScheme.type)
    * [ open_id_connect_url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OpenIdConnectSecurityScheme.open_id_connect_url)
    * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OpenIdConnectSecurityScheme.description)
  * [ SecurityScheme  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SecurityScheme)
  * [ AgentInterface  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentInterface)
    * [ transport  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentInterface.transport)
    * [ url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentInterface.url)
    * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentInterface.description)
  * [ AgentExtension  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentExtension)
    * [ uri  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentExtension.uri)
    * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentExtension.description)
    * [ required  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentExtension.required)
    * [ params  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentExtension.params)
  * [ Skill  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill)
    * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.id)
    * [ name  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.name)
    * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.description)
    * [ tags  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.tags)
    * [ examples  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.examples)
    * [ input_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.input_modes)
    * [ output_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill.output_modes)
  * [ Artifact  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact)
    * [ artifact_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.artifact_id)
    * [ name  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.name)
    * [ description  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.description)
    * [ parts  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.parts)
    * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.metadata)
    * [ extensions  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.extensions)
    * [ append  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.append)
    * [ last_chunk  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact.last_chunk)
  * [ PushNotificationConfig  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig)
    * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig.id)
    * [ url  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig.url)
    * [ token  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig.token)
    * [ authentication  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig.authentication)
  * [ TaskPushNotificationConfig  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskPushNotificationConfig)
    * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskPushNotificationConfig.id)
    * [ push_notification_config  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskPushNotificationConfig.push_notification_config)
  * [ Message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message)
    * [ role  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.role)
    * [ parts  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.parts)
    * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.kind)
    * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.metadata)
    * [ message_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.message_id)
    * [ context_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.context_id)
    * [ task_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.task_id)
    * [ reference_task_ids  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.reference_task_ids)
    * [ extensions  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message.extensions)
  * [ TextPart  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TextPart)
    * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TextPart.kind)
    * [ text  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TextPart.text)
  * [ FileWithBytes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithBytes)
    * [ bytes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithBytes.bytes)
    * [ mime_type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithBytes.mime_type)
  * [ FileWithUri  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithUri)
    * [ uri  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithUri.uri)
    * [ mime_type  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithUri.mime_type)
  * [ FilePart  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FilePart)
    * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FilePart.kind)
    * [ file  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FilePart.file)
  * [ DataPart  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DataPart)
    * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DataPart.kind)
    * [ data  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DataPart.data)
  * [ Part  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Part)
  * [ TaskState  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskState)
  * [ TaskStatus  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatus)
    * [ state  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatus.state)
    * [ message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatus.message)
    * [ timestamp  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatus.timestamp)
  * [ Task  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task)
    * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.id)
    * [ context_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.context_id)
    * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.kind)
    * [ status  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.status)
    * [ history  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.history)
    * [ artifacts  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.artifacts)
    * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task.metadata)
  * [ TaskStatusUpdateEvent  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent)
    * [ task_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.task_id)
    * [ context_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.context_id)
    * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.kind)
    * [ status  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.status)
    * [ final  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.final)
    * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent.metadata)
  * [ TaskArtifactUpdateEvent  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent)
    * [ task_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.task_id)
    * [ context_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.context_id)
    * [ kind  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.kind)
    * [ artifact  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.artifact)
    * [ append  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.append)
    * [ last_chunk  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.last_chunk)
    * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent.metadata)
  * [ TaskIdParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskIdParams)
    * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskIdParams.id)
    * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskIdParams.metadata)
  * [ TaskQueryParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskQueryParams)
    * [ history_length  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskQueryParams.history_length)
  * [ MessageSendConfiguration  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration)
    * [ accepted_output_modes  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration.accepted_output_modes)
    * [ blocking  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration.blocking)
    * [ history_length  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration.history_length)
    * [ push_notification_config  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration.push_notification_config)
  * [ MessageSendParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendParams)
    * [ configuration  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendParams.configuration)
    * [ message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendParams.message)
    * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendParams.metadata)
  * [ TaskSendParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams)
    * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams.id)
    * [ context_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams.context_id)
    * [ message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams.message)
    * [ history_length  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams.history_length)
    * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams.metadata)
  * [ ListTaskPushNotificationConfigParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ListTaskPushNotificationConfigParams)
    * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ListTaskPushNotificationConfigParams.id)
    * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ListTaskPushNotificationConfigParams.metadata)
  * [ DeleteTaskPushNotificationConfigParams  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigParams)
    * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigParams.id)
    * [ push_notification_config_id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigParams.push_notification_config_id)
    * [ metadata  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigParams.metadata)
  * [ JSONRPCMessage  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCMessage)
    * [ jsonrpc  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCMessage.jsonrpc)
    * [ id  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCMessage.id)
  * [ JSONRPCRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest)
    * [ method  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest.method)
    * [ params  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest.params)
  * [ JSONRPCError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError)
    * [ code  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError.code)
    * [ message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError.message)
    * [ data  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError.data)
  * [ JSONRPCResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCResponse)
  * [ JSONParseError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONParseError)
  * [ InvalidRequestError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.InvalidRequestError)
  * [ MethodNotFoundError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MethodNotFoundError)
  * [ InvalidParamsError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.InvalidParamsError)
  * [ InternalError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.InternalError)
  * [ TaskNotFoundError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskNotFoundError)
  * [ TaskNotCancelableError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskNotCancelableError)
  * [ PushNotificationNotSupportedError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationNotSupportedError)
  * [ UnsupportedOperationError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.UnsupportedOperationError)
  * [ ContentTypeNotSupportedError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ContentTypeNotSupportedError)
  * [ InvalidAgentResponseError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.InvalidAgentResponseError)
  * [ SendMessageRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SendMessageRequest)
  * [ SendMessageResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SendMessageResponse)
  * [ StreamMessageRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.StreamMessageRequest)
  * [ StreamMessageResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.StreamMessageResponse)
  * [ GetTaskRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskRequest)
  * [ GetTaskResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskResponse)
  * [ CancelTaskRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.CancelTaskRequest)
  * [ CancelTaskResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.CancelTaskResponse)
  * [ SetTaskPushNotificationRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SetTaskPushNotificationRequest)
  * [ SetTaskPushNotificationResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SetTaskPushNotificationResponse)
  * [ GetTaskPushNotificationRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskPushNotificationRequest)
  * [ GetTaskPushNotificationResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskPushNotificationResponse)
  * [ ResubscribeTaskRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ResubscribeTaskRequest)
  * [ ListTaskPushNotificationConfigRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ListTaskPushNotificationConfigRequest)
  * [ DeleteTaskPushNotificationConfigRequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigRequest)
  * [ A2ARequest  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.A2ARequest)
  * [ A2AResponse  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.A2AResponse)
  * [ client  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.client)
  * [ A2AClient  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.client.A2AClient)
    * [ send_message  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.client.A2AClient.send_message)
  * [ UnexpectedResponseError  ](https://ai.pydantic.dev/api/fasta2a/#fasta2a.client.UnexpectedResponseError)


  1. [ Pydantic AI  ](https://ai.pydantic.dev/)
  2. [ API Reference  ](https://ai.pydantic.dev/api/ag_ui/)
  3. [ fasta2a  ](https://ai.pydantic.dev/api/fasta2a/)


# `fasta2a`
###  FastA2A
Bases: `Starlette`
The main class for the FastA2A library.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/applications.py`
```
 29
 30
 31
 32
 33
 34
 35
 36
 37
 38
 39
 40
 41
 42
 43
 44
 45
 46
 47
 48
 49
 50
 51
 52
 53
 54
 55
 56
 57
 58
 59
 60
 61
 62
 63
 64
 65
 66
 67
 68
 69
 70
 71
 72
 73
 74
 75
 76
 77
 78
 79
 80
 81
 82
 83
 84
 85
 86
 87
 88
 89
 90
 91
 92
 93
 94
 95
 96
 97
 98
 99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
133
134
135
136
137
138
```
| ```
class FastA2A(Starlette):
    """The main class for the FastA2A library."""

    def __init__(
        self,
        *,
        storage: Storage,
        broker: Broker,
        # Agent card
        name: str | None = None,
        url: str = 'http://localhost:8000',
        version: str = '1.0.0',
        description: str | None = None,
        provider: AgentProvider | None = None,
        skills: list[Skill] | None = None,
        # Starlette
        debug: bool = False,
        routes: Sequence[Route] | None = None,
        middleware: Sequence[Middleware] | None = None,
        exception_handlers: dict[Any, ExceptionHandler] | None = None,
        lifespan: Lifespan[FastA2A] | None = None,
    ):
        if lifespan is None:
            lifespan = _default_lifespan

        super().__init__(
            debug=debug,
            routes=routes,
            middleware=middleware,
            exception_handlers=exception_handlers,
            lifespan=lifespan,
        )

        self.name = name or 'My Agent'
        self.url = url
        self.version = version
        self.description = description
        self.provider = provider
        self.skills = skills or []
        # NOTE: For now, I don't think there's any reason to support any other input/output modes.
        self.default_input_modes = ['application/json']
        self.default_output_modes = ['application/json']

        self.task_manager = TaskManager(broker=broker, storage=storage)

        # Setup
        self._agent_card_json_schema: bytes | None = None
        self.router.add_route(
            '/.well-known/agent-card.json', self._agent_card_endpoint, methods=['HEAD', 'GET', 'OPTIONS']
        )
        self.router.add_route('/', self._agent_run_endpoint, methods=['POST'])
        self.router.add_route('/docs', self._docs_endpoint, methods=['GET'])

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope['type'] == 'http' and not self.task_manager.is_running:
            raise RuntimeError('TaskManager was not properly initialized.')
        await super().__call__(scope, receive, send)

    async def _agent_card_endpoint(self, request: Request) -> Response:
        if self._agent_card_json_schema is None:
            agent_card = AgentCard(
                name=self.name,
                description=self.description or 'An AI agent exposed as an A2A agent.',
                url=self.url,
                version=self.version,
                protocol_version='0.3.0',
                skills=self.skills,
                default_input_modes=self.default_input_modes,
                default_output_modes=self.default_output_modes,
                capabilities=AgentCapabilities(
                    streaming=False, push_notifications=False, state_transition_history=False
                ),
            )
            if self.provider is not None:
                agent_card['provider'] = self.provider
            self._agent_card_json_schema = agent_card_ta.dump_json(agent_card, by_alias=True)
        return Response(content=self._agent_card_json_schema, media_type='application/json')

    async def _docs_endpoint(self, request: Request) -> Response:
        """Serve the documentation interface."""
        docs_path = Path(__file__).parent / 'static' / 'docs.html'
        return FileResponse(docs_path, media_type='text/html')

    async def _agent_run_endpoint(self, request: Request) -> Response:
        """This is the main endpoint for the A2A server.

        Although the specification allows freedom of choice and implementation, I'm pretty sure about some decisions.

        1. The server will always either send a "submitted" or a "failed" on `message/send`.
            Never a "completed" on the first message.
        2. There are three possible ends for the task:
            2.1. The task was "completed" successfully.
            2.2. The task was "canceled".
            2.3. The task "failed".
        3. The server will send a "working" on the first chunk on `tasks/pushNotification/get`.
        """
        data = await request.body()
        a2a_request = a2a_request_ta.validate_json(data)

        if a2a_request['method'] == 'message/send':
            jsonrpc_response = await self.task_manager.send_message(a2a_request)
        elif a2a_request['method'] == 'tasks/get':
            jsonrpc_response = await self.task_manager.get_task(a2a_request)
        elif a2a_request['method'] == 'tasks/cancel':
            jsonrpc_response = await self.task_manager.cancel_task(a2a_request)
        else:
            raise NotImplementedError(f'Method {a2a_request["method"]} not implemented.')
        return Response(
            content=a2a_response_ta.dump_json(jsonrpc_response, by_alias=True), media_type='application/json'
        )

```

---|---
###  Broker `dataclass`
Bases: `ABC[](https://docs.python.org/3/library/abc.html#abc.ABC "abc.ABC")`
The broker class is in charge of scheduling the tasks.
The HTTP server uses the broker to schedule tasks.
The simple implementation is the `InMemoryBroker`, which is the broker that runs the tasks in the same process as the HTTP server. That said, this class can be extended to support remote workers.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/broker.py`
```
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
```
| ```
@dataclass
class Broker(ABC):
    """The broker class is in charge of scheduling the tasks.

    The HTTP server uses the broker to schedule tasks.

    The simple implementation is the `InMemoryBroker`, which is the broker that
    runs the tasks in the same process as the HTTP server. That said, this class can be
    extended to support remote workers.
    """

    @abstractmethod
    async def run_task(self, params: TaskSendParams) -> None:
        """Send a task to be executed by the worker."""
        raise NotImplementedError('send_run_task is not implemented yet.')

    @abstractmethod
    async def cancel_task(self, params: TaskIdParams) -> None:
        """Cancel a task."""
        raise NotImplementedError('send_cancel_task is not implemented yet.')

    @abstractmethod
    async def __aenter__(self) -> Self: ...

    @abstractmethod
    async def __aexit__(self, exc_type: Any, exc_value: Any, traceback: Any): ...

    @abstractmethod
    def receive_task_operations(self) -> AsyncIterator[TaskOperation]:
        """Receive task operations from the broker.

        On a multi-worker setup, the broker will need to round-robin the task operations
        between the workers.
        """

```

---|---
####  run_task `abstractmethod` `async`
```
run_task(params: TaskSendParams[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskSendParams "TaskSendParams \(fasta2a.schema.TaskSendParams\)")) -> None

```

Send a task to be executed by the worker.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/broker.py`
```
30
31
32
33
```
| ```
@abstractmethod
async def run_task(self, params: TaskSendParams) -> None:
    """Send a task to be executed by the worker."""
    raise NotImplementedError('send_run_task is not implemented yet.')

```

---|---
####  cancel_task `abstractmethod` `async`
```
cancel_task(params: TaskIdParams[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskIdParams "TaskIdParams \(fasta2a.schema.TaskIdParams\)")) -> None

```

Cancel a task.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/broker.py`
```
35
36
37
38
```
| ```
@abstractmethod
async def cancel_task(self, params: TaskIdParams) -> None:
    """Cancel a task."""
    raise NotImplementedError('send_cancel_task is not implemented yet.')

```

---|---
####  receive_task_operations `abstractmethod`
```
receive_task_operations() -> AsyncIterator[](https://docs.python.org/3/library/collections.abc.html#collections.abc.AsyncIterator "collections.abc.AsyncIterator")[TaskOperation]

```

Receive task operations from the broker.
On a multi-worker setup, the broker will need to round-robin the task operations between the workers.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/broker.py`
```
46
47
48
49
50
51
52
```
| ```
@abstractmethod
def receive_task_operations(self) -> AsyncIterator[TaskOperation]:
    """Receive task operations from the broker.

    On a multi-worker setup, the broker will need to round-robin the task operations
    between the workers.
    """

```

---|---
###  Skill
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Skills are a unit of capability that an agent can perform.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
197
198
199
200
201
202
203
204
205
206
207
208
209
210
211
212
213
214
215
216
217
218
219
220
221
222
223
224
225
226
227
228
229
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class Skill(TypedDict):
    """Skills are a unit of capability that an agent can perform."""

    id: str
    """A unique identifier for the skill."""

    name: str
    """Human readable name of the skill."""

    description: str
    """A human-readable description of the skill.

    It will be used by the client or a human as a hint to understand the skill.
    """

    tags: list[str]
    """Set of tag-words describing classes of capabilities for this specific skill.

    Examples: "cooking", "customer support", "billing".
    """

    examples: NotRequired[list[str]]
    """The set of example scenarios that the skill can perform.

    Will be used by the client as a hint to understand how the skill can be used. (e.g. "I need a recipe for bread")
    """

    input_modes: list[str]
    """Supported mime types for input data."""

    output_modes: list[str]
    """Supported mime types for output data."""

```

---|---
####  id `instance-attribute`
```
id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

A unique identifier for the skill.
####  name `instance-attribute`
```
name: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

Human readable name of the skill.
####  description `instance-attribute`
```
description: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

A human-readable description of the skill.
It will be used by the client or a human as a hint to understand the skill.
####  tags `instance-attribute`
```
tags: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Set of tag-words describing classes of capabilities for this specific skill.
Examples: "cooking", "customer support", "billing".
####  examples `instance-attribute`
```
examples: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]]

```

The set of example scenarios that the skill can perform.
Will be used by the client as a hint to understand how the skill can be used. (e.g. "I need a recipe for bread")
####  input_modes `instance-attribute`
```
input_modes: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Supported mime types for input data.
####  output_modes `instance-attribute`
```
output_modes: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Supported mime types for output data.
###  Storage
Bases: `ABC[](https://docs.python.org/3/library/abc.html#abc.ABC "abc.ABC")`, `Generic[](https://docs.python.org/3/library/typing.html#typing.Generic "typing.Generic")[ContextT]`
A storage to retrieve and save tasks, as well as retrieve and save context.
The storage serves two purposes: 1. Task storage: Stores tasks in A2A protocol format with their status, artifacts, and message history 2. Context storage: Stores conversation context in a format optimized for the specific agent implementation
Source code in `.venv/lib/python3.12/site-packages/fasta2a/storage.py`
```
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
```
| ```
class Storage(ABC, Generic[ContextT]):
    """A storage to retrieve and save tasks, as well as retrieve and save context.

    The storage serves two purposes:
    1. Task storage: Stores tasks in A2A protocol format with their status, artifacts, and message history
    2. Context storage: Stores conversation context in a format optimized for the specific agent implementation
    """

    @abstractmethod
    async def load_task(self, task_id: str, history_length: int | None = None) -> Task | None:
        """Load a task from storage.

        If the task is not found, return None.
        """

    @abstractmethod
    async def submit_task(self, context_id: str, message: Message) -> Task:
        """Submit a task to storage."""

    @abstractmethod
    async def update_task(
        self,
        task_id: str,
        state: TaskState,
        new_artifacts: list[Artifact] | None = None,
        new_messages: list[Message] | None = None,
    ) -> Task:
        """Update the state of a task. Appends artifacts and messages, if specified."""

    @abstractmethod
    async def load_context(self, context_id: str) -> ContextT | None:
        """Retrieve the stored context given the `context_id`."""

    @abstractmethod
    async def update_context(self, context_id: str, context: ContextT) -> None:
        """Updates the context for a `context_id`.

        Implementing agent can decide what to store in context.
        """

```

---|---
####  load_task `abstractmethod` `async`
```
load_task(
    task_id: str[](https://docs.python.org/3/library/stdtypes.html#str), history_length: int[](https://docs.python.org/3/library/functions.html#int) | None = None
) -> Task[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task "Task \(fasta2a.schema.Task\)") | None

```

Load a task from storage.
If the task is not found, return None.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/storage.py`
```
25
26
27
28
29
30
```
| ```
@abstractmethod
async def load_task(self, task_id: str, history_length: int | None = None) -> Task | None:
    """Load a task from storage.

    If the task is not found, return None.
    """

```

---|---
####  submit_task `abstractmethod` `async`
```
submit_task(context_id: str[](https://docs.python.org/3/library/stdtypes.html#str), message: Message[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message "Message \(fasta2a.schema.Message\)")) -> Task[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task "Task \(fasta2a.schema.Task\)")

```

Submit a task to storage.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/storage.py`
```
32
33
34
```
| ```
@abstractmethod
async def submit_task(self, context_id: str, message: Message) -> Task:
    """Submit a task to storage."""

```

---|---
####  update_task `abstractmethod` `async`
```
update_task(
    task_id: str[](https://docs.python.org/3/library/stdtypes.html#str),
    state: TaskState[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskState "TaskState



      module-attribute
   \(fasta2a.schema.TaskState\)"),
    new_artifacts: list[](https://docs.python.org/3/library/stdtypes.html#list)[Artifact[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact "Artifact \(fasta2a.schema.Artifact\)")] | None = None,
    new_messages: list[](https://docs.python.org/3/library/stdtypes.html#list)[Message[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message "Message \(fasta2a.schema.Message\)")] | None = None,
) -> Task[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task "Task \(fasta2a.schema.Task\)")

```

Update the state of a task. Appends artifacts and messages, if specified.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/storage.py`
```
36
37
38
39
40
41
42
43
44
```
| ```
@abstractmethod
async def update_task(
    self,
    task_id: str,
    state: TaskState,
    new_artifacts: list[Artifact] | None = None,
    new_messages: list[Message] | None = None,
) -> Task:
    """Update the state of a task. Appends artifacts and messages, if specified."""

```

---|---
####  load_context `abstractmethod` `async`
```
load_context(context_id: str[](https://docs.python.org/3/library/stdtypes.html#str)) -> ContextT | None

```

Retrieve the stored context given the `context_id`.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/storage.py`
```
46
47
48
```
| ```
@abstractmethod
async def load_context(self, context_id: str) -> ContextT | None:
    """Retrieve the stored context given the `context_id`."""

```

---|---
####  update_context `abstractmethod` `async`
```
update_context(context_id: str[](https://docs.python.org/3/library/stdtypes.html#str), context: ContextT) -> None

```

Updates the context for a `context_id`.
Implementing agent can decide what to store in context.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/storage.py`
```
50
51
52
53
54
55
```
| ```
@abstractmethod
async def update_context(self, context_id: str, context: ContextT) -> None:
    """Updates the context for a `context_id`.

    Implementing agent can decide what to store in context.
    """

```

---|---
###  Worker `dataclass`
Bases: `ABC[](https://docs.python.org/3/library/abc.html#abc.ABC "abc.ABC")`, `Generic[](https://docs.python.org/3/library/typing.html#typing.Generic "typing.Generic")[ContextT]`
A worker is responsible for executing tasks.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/worker.py`
```
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
```
| ```
@dataclass
class Worker(ABC, Generic[ContextT]):
    """A worker is responsible for executing tasks."""

    broker: Broker
    storage: Storage[ContextT]

    @asynccontextmanager
    async def run(self) -> AsyncIterator[None]:
        """Run the worker.

        It connects to the broker, and it makes itself available to receive commands.
        """
        async with anyio.create_task_group() as tg:
            tg.start_soon(self._loop)
            yield
            tg.cancel_scope.cancel()

    async def _loop(self) -> None:
        async for task_operation in self.broker.receive_task_operations():
            await self._handle_task_operation(task_operation)

    async def _handle_task_operation(self, task_operation: TaskOperation) -> None:
        try:
            with use_span(task_operation['_current_span']):
                with tracer.start_as_current_span(
                    f'{task_operation["operation"]} task', attributes={'logfire.tags': ['fasta2a']}
                ):
                    if task_operation['operation'] == 'run':
                        await self.run_task(task_operation['params'])
                    elif task_operation['operation'] == 'cancel':
                        await self.cancel_task(task_operation['params'])
                    else:
                        assert_never(task_operation)
        except Exception:
            await self.storage.update_task(task_operation['params']['id'], state='failed')

    @abstractmethod
    async def run_task(self, params: TaskSendParams) -> None: ...

    @abstractmethod
    async def cancel_task(self, params: TaskIdParams) -> None: ...

    @abstractmethod
    def build_message_history(self, history: list[Message]) -> list[Any]: ...

    @abstractmethod
    def build_artifacts(self, result: Any) -> list[Artifact]: ...

```

---|---
####  run `async`
```
run() -> AsyncIterator[](https://docs.python.org/3/library/collections.abc.html#collections.abc.AsyncIterator "collections.abc.AsyncIterator")[None]

```

Run the worker.
It connects to the broker, and it makes itself available to receive commands.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/worker.py`
```
29
30
31
32
33
34
35
36
37
38
```
| ```
@asynccontextmanager
async def run(self) -> AsyncIterator[None]:
    """Run the worker.

    It connects to the broker, and it makes itself available to receive commands.
    """
    async with anyio.create_task_group() as tg:
        tg.start_soon(self._loop)
        yield
        tg.cancel_scope.cancel()

```

---|---
This module contains the schema for the agent card.
###  AgentCard
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
The card that describes an agent.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
13
14
15
16
17
18
19
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class AgentCard(TypedDict):
    """The card that describes an agent."""

    name: str
    """Human readable name of the agent e.g. "Recipe Agent"."""

    description: str
    """A human-readable description of the agent.

    Used to assist users and other agents in understanding what the agent can do.
    (e.g. "Agent that helps users with recipes and cooking.")
    """

    url: str
    """A URL to the address the agent is hosted at."""

    version: str
    """The version of the agent - format is up to the provider. (e.g. "1.0.0")"""

    protocol_version: str
    """The version of the A2A protocol this agent supports."""

    provider: NotRequired[AgentProvider]
    """The service provider of the agent."""

    documentation_url: NotRequired[str]
    """A URL to documentation for the agent."""

    icon_url: NotRequired[str]
    """A URL to an icon for the agent."""

    preferred_transport: NotRequired[str]
    """The transport of the preferred endpoint. If empty, defaults to JSONRPC."""

    additional_interfaces: NotRequired[list[AgentInterface]]
    """Announcement of additional supported transports."""

    capabilities: AgentCapabilities
    """The capabilities of the agent."""

    security: NotRequired[list[dict[str, list[str]]]]
    """Security requirements for contacting the agent."""

    security_schemes: NotRequired[dict[str, SecurityScheme]]
    """Security scheme definitions."""

    default_input_modes: list[str]
    """Supported mime types for input data."""

    default_output_modes: list[str]
    """Supported mime types for output data."""

    skills: list[Skill]
    """The set of skills, or distinct capabilities, that the agent can perform."""

```

---|---
####  name `instance-attribute`
```
name: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

Human readable name of the agent e.g. "Recipe Agent".
####  description `instance-attribute`
```
description: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

A human-readable description of the agent.
Used to assist users and other agents in understanding what the agent can do. (e.g. "Agent that helps users with recipes and cooking.")
####  url `instance-attribute`
```
url: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

A URL to the address the agent is hosted at.
####  version `instance-attribute`
```
version: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The version of the agent - format is up to the provider. (e.g. "1.0.0")
####  protocol_version `instance-attribute`
```
protocol_version: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The version of the A2A protocol this agent supports.
####  provider `instance-attribute`
```
provider: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[AgentProvider[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentProvider "AgentProvider \(fasta2a.schema.AgentProvider\)")]

```

The service provider of the agent.
####  documentation_url `instance-attribute`
```
documentation_url: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

A URL to documentation for the agent.
####  icon_url `instance-attribute`
```
icon_url: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

A URL to an icon for the agent.
####  preferred_transport `instance-attribute`
```
preferred_transport: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

The transport of the preferred endpoint. If empty, defaults to JSONRPC.
####  additional_interfaces `instance-attribute`
```
additional_interfaces: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[list[](https://docs.python.org/3/library/stdtypes.html#list)[AgentInterface[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentInterface "AgentInterface \(fasta2a.schema.AgentInterface\)")]]

```

Announcement of additional supported transports.
####  capabilities `instance-attribute`
```
capabilities: AgentCapabilities[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.AgentCapabilities "AgentCapabilities \(fasta2a.schema.AgentCapabilities\)")

```

The capabilities of the agent.
####  security `instance-attribute`
```
security: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[list[](https://docs.python.org/3/library/stdtypes.html#list)[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]]]]

```

Security requirements for contacting the agent.
####  security_schemes `instance-attribute`
```
security_schemes: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), SecurityScheme[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SecurityScheme "SecurityScheme



      module-attribute
   \(fasta2a.schema.SecurityScheme\)")]]

```

Security scheme definitions.
####  default_input_modes `instance-attribute`
```
default_input_modes: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Supported mime types for input data.
####  default_output_modes `instance-attribute`
```
default_output_modes: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Supported mime types for output data.
####  skills `instance-attribute`
```
skills: list[](https://docs.python.org/3/library/stdtypes.html#list)[Skill[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Skill "Skill \(fasta2a.schema.Skill\)")]

```

The set of skills, or distinct capabilities, that the agent can perform.
###  AgentProvider
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
The service provider of the agent.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
73
74
75
76
77
78
79
80
```
| ```
class AgentProvider(TypedDict):
    """The service provider of the agent."""

    organization: str
    """The name of the agent provider's organization."""

    url: str
    """A URL for the agent provider's website or relevant documentation."""

```

---|---
####  organization `instance-attribute`
```
organization: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The name of the agent provider's organization.
####  url `instance-attribute`
```
url: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

A URL for the agent provider's website or relevant documentation.
###  AgentCapabilities
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
The capabilities of the agent.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
83
84
85
86
87
88
89
90
91
92
93
94
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class AgentCapabilities(TypedDict):
    """The capabilities of the agent."""

    streaming: NotRequired[bool]
    """Whether the agent supports streaming."""

    push_notifications: NotRequired[bool]
    """Whether the agent can notify updates to client."""

    state_transition_history: NotRequired[bool]
    """Whether the agent exposes status change history for tasks."""

```

---|---
####  streaming `instance-attribute`
```
streaming: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[bool[](https://docs.python.org/3/library/functions.html#bool)]

```

Whether the agent supports streaming.
####  push_notifications `instance-attribute`
```
push_notifications: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[bool[](https://docs.python.org/3/library/functions.html#bool)]

```

Whether the agent can notify updates to client.
####  state_transition_history `instance-attribute`
```
state_transition_history: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[bool[](https://docs.python.org/3/library/functions.html#bool)]

```

Whether the agent exposes status change history for tasks.
###  HttpSecurityScheme
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
HTTP security scheme.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
 97
 98
 99
100
101
102
103
104
105
106
107
108
109
110
111
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class HttpSecurityScheme(TypedDict):
    """HTTP security scheme."""

    type: Literal['http']
    """The type of the security scheme. Must be 'http'."""

    scheme: str
    """The name of the HTTP Authorization scheme."""

    bearer_format: NotRequired[str]
    """A hint to the client to identify how the bearer token is formatted."""

    description: NotRequired[str]
    """Description of this security scheme."""

```

---|---
####  type `instance-attribute`
```
type: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['http']

```

The type of the security scheme. Must be 'http'.
####  scheme `instance-attribute`
```
scheme: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The name of the HTTP Authorization scheme.
####  bearer_format `instance-attribute`
```
bearer_format: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

A hint to the client to identify how the bearer token is formatted.
####  description `instance-attribute`
```
description: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Description of this security scheme.
###  ApiKeySecurityScheme
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
API Key security scheme.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class ApiKeySecurityScheme(TypedDict):
    """API Key security scheme."""

    type: Literal['apiKey']
    """The type of the security scheme. Must be 'apiKey'."""

    name: str
    """The name of the header, query or cookie parameter to be used."""

    in_: Literal['query', 'header', 'cookie']
    """The location of the API key."""

    description: NotRequired[str]
    """Description of this security scheme."""

```

---|---
####  type `instance-attribute`
```
type: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['apiKey']

```

The type of the security scheme. Must be 'apiKey'.
####  name `instance-attribute`
```
name: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The name of the header, query or cookie parameter to be used.
####  in_ `instance-attribute`
```
in_: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['query', 'header', 'cookie']

```

The location of the API key.
####  description `instance-attribute`
```
description: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Description of this security scheme.
###  OAuth2SecurityScheme
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
OAuth2 security scheme.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
131
132
133
134
135
136
137
138
139
140
141
142
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class OAuth2SecurityScheme(TypedDict):
    """OAuth2 security scheme."""

    type: Literal['oauth2']
    """The type of the security scheme. Must be 'oauth2'."""

    flows: dict[str, Any]
    """An object containing configuration information for the flow types supported."""

    description: NotRequired[str]
    """Description of this security scheme."""

```

---|---
####  type `instance-attribute`
```
type: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['oauth2']

```

The type of the security scheme. Must be 'oauth2'.
####  flows `instance-attribute`
```
flows: dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]

```

An object containing configuration information for the flow types supported.
####  description `instance-attribute`
```
description: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Description of this security scheme.
###  OpenIdConnectSecurityScheme
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
OpenID Connect security scheme.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
145
146
147
148
149
150
151
152
153
154
155
156
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class OpenIdConnectSecurityScheme(TypedDict):
    """OpenID Connect security scheme."""

    type: Literal['openIdConnect']
    """The type of the security scheme. Must be 'openIdConnect'."""

    open_id_connect_url: str
    """OpenId Connect URL to discover OAuth2 configuration values."""

    description: NotRequired[str]
    """Description of this security scheme."""

```

---|---
####  type `instance-attribute`
```
type: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['openIdConnect']

```

The type of the security scheme. Must be 'openIdConnect'.
####  open_id_connect_url `instance-attribute`
```
open_id_connect_url: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

OpenId Connect URL to discover OAuth2 configuration values.
####  description `instance-attribute`
```
description: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Description of this security scheme.
###  SecurityScheme `module-attribute`
```
SecurityScheme = Annotated[](https://docs.python.org/3/library/typing.html#typing.Annotated "typing.Annotated")[
    Union[](https://docs.python.org/3/library/typing.html#typing.Union "typing.Union")[
        HttpSecurityScheme[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.HttpSecurityScheme "HttpSecurityScheme \(fasta2a.schema.HttpSecurityScheme\)"),
        ApiKeySecurityScheme[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ApiKeySecurityScheme "ApiKeySecurityScheme \(fasta2a.schema.ApiKeySecurityScheme\)"),
        OAuth2SecurityScheme[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OAuth2SecurityScheme "OAuth2SecurityScheme \(fasta2a.schema.OAuth2SecurityScheme\)"),
        OpenIdConnectSecurityScheme[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.OpenIdConnectSecurityScheme "OpenIdConnectSecurityScheme \(fasta2a.schema.OpenIdConnectSecurityScheme\)"),
    ],
    Field[](https://docs.pydantic.dev/latest/api/fields/#pydantic.fields.Field "pydantic.Field")(discriminator="type"),
]

```

A security scheme for authentication.
###  AgentInterface
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
An interface that the agent supports.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
166
167
168
169
170
171
172
173
174
175
176
177
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class AgentInterface(TypedDict):
    """An interface that the agent supports."""

    transport: str
    """The transport protocol (e.g., 'jsonrpc', 'websocket')."""

    url: str
    """The URL endpoint for this transport."""

    description: NotRequired[str]
    """Description of this interface."""

```

---|---
####  transport `instance-attribute`
```
transport: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The transport protocol (e.g., 'jsonrpc', 'websocket').
####  url `instance-attribute`
```
url: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The URL endpoint for this transport.
####  description `instance-attribute`
```
description: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Description of this interface.
###  AgentExtension
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
A declaration of an extension supported by an Agent.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
180
181
182
183
184
185
186
187
188
189
190
191
192
193
194
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class AgentExtension(TypedDict):
    """A declaration of an extension supported by an Agent."""

    uri: str
    """The URI of the extension."""

    description: NotRequired[str]
    """A description of how this agent uses this extension."""

    required: NotRequired[bool]
    """Whether the client must follow specific requirements of the extension."""

    params: NotRequired[dict[str, Any]]
    """Optional configuration for the extension."""

```

---|---
####  uri `instance-attribute`
```
uri: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The URI of the extension.
####  description `instance-attribute`
```
description: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

A description of how this agent uses this extension.
####  required `instance-attribute`
```
required: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[bool[](https://docs.python.org/3/library/functions.html#bool)]

```

Whether the client must follow specific requirements of the extension.
####  params `instance-attribute`
```
params: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]]

```

Optional configuration for the extension.
###  Skill
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Skills are a unit of capability that an agent can perform.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
197
198
199
200
201
202
203
204
205
206
207
208
209
210
211
212
213
214
215
216
217
218
219
220
221
222
223
224
225
226
227
228
229
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class Skill(TypedDict):
    """Skills are a unit of capability that an agent can perform."""

    id: str
    """A unique identifier for the skill."""

    name: str
    """Human readable name of the skill."""

    description: str
    """A human-readable description of the skill.

    It will be used by the client or a human as a hint to understand the skill.
    """

    tags: list[str]
    """Set of tag-words describing classes of capabilities for this specific skill.

    Examples: "cooking", "customer support", "billing".
    """

    examples: NotRequired[list[str]]
    """The set of example scenarios that the skill can perform.

    Will be used by the client as a hint to understand how the skill can be used. (e.g. "I need a recipe for bread")
    """

    input_modes: list[str]
    """Supported mime types for input data."""

    output_modes: list[str]
    """Supported mime types for output data."""

```

---|---
####  id `instance-attribute`
```
id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

A unique identifier for the skill.
####  name `instance-attribute`
```
name: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

Human readable name of the skill.
####  description `instance-attribute`
```
description: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

A human-readable description of the skill.
It will be used by the client or a human as a hint to understand the skill.
####  tags `instance-attribute`
```
tags: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Set of tag-words describing classes of capabilities for this specific skill.
Examples: "cooking", "customer support", "billing".
####  examples `instance-attribute`
```
examples: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]]

```

The set of example scenarios that the skill can perform.
Will be used by the client as a hint to understand how the skill can be used. (e.g. "I need a recipe for bread")
####  input_modes `instance-attribute`
```
input_modes: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Supported mime types for input data.
####  output_modes `instance-attribute`
```
output_modes: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Supported mime types for output data.
###  Artifact
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Agents generate Artifacts as an end result of a Task.
Artifacts are immutable, can be named, and can have multiple parts. A streaming response can append parts to existing Artifacts.
A single Task can generate many Artifacts. For example, "create a webpage" could create separate HTML and image Artifacts.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
232
233
234
235
236
237
238
239
240
241
242
243
244
245
246
247
248
249
250
251
252
253
254
255
256
257
258
259
260
261
262
263
264
265
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class Artifact(TypedDict):
    """Agents generate Artifacts as an end result of a Task.

    Artifacts are immutable, can be named, and can have multiple parts. A streaming response can append parts to
    existing Artifacts.

    A single Task can generate many Artifacts. For example, "create a webpage" could create separate HTML and image
    Artifacts.
    """

    artifact_id: str
    """Unique identifier for the artifact."""

    name: NotRequired[str]
    """The name of the artifact."""

    description: NotRequired[str]
    """A description of the artifact."""

    parts: list[Part]
    """The parts that make up the artifact."""

    metadata: NotRequired[dict[str, Any]]
    """Metadata about the artifact."""

    extensions: NotRequired[list[str]]
    """Array of extensions."""

    append: NotRequired[bool]
    """Whether to append this artifact to an existing one."""

    last_chunk: NotRequired[bool]
    """Whether this is the last chunk of the artifact."""

```

---|---
####  artifact_id `instance-attribute`
```
artifact_id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

Unique identifier for the artifact.
####  name `instance-attribute`
```
name: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

The name of the artifact.
####  description `instance-attribute`
```
description: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

A description of the artifact.
####  parts `instance-attribute`
```
parts: list[](https://docs.python.org/3/library/stdtypes.html#list)[Part[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Part "Part



      module-attribute
   \(fasta2a.schema.Part\)")]

```

The parts that make up the artifact.
####  metadata `instance-attribute`
```
metadata: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]]

```

Metadata about the artifact.
####  extensions `instance-attribute`
```
extensions: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]]

```

Array of extensions.
####  append `instance-attribute`
```
append: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[bool[](https://docs.python.org/3/library/functions.html#bool)]

```

Whether to append this artifact to an existing one.
####  last_chunk `instance-attribute`
```
last_chunk: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[bool[](https://docs.python.org/3/library/functions.html#bool)]

```

Whether this is the last chunk of the artifact.
###  PushNotificationConfig
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Configuration for push notifications.
A2A supports a secure notification mechanism whereby an agent can notify a client of an update outside a connected session via a PushNotificationService. Within and across enterprises, it is critical that the agent verifies the identity of the notification service, authenticates itself with the service, and presents an identifier that ties the notification to the executing Task.
The target server of the PushNotificationService should be considered a separate service, and is not guaranteed (or even expected) to be the client directly. This PushNotificationService is responsible for authenticating and authorizing the agent and for proxying the verified notification to the appropriate endpoint (which could be anything from a pub/sub queue, to an email inbox or other service, etc.).
For contrived scenarios with isolated client-agent pairs (e.g. local service mesh in a contained VPC, etc.) or isolated environments without enterprise security concerns, the client may choose to simply open a port and act as its own PushNotificationService. Any enterprise implementation will likely have a centralized service that authenticates the remote agents with trusted notification credentials and can handle online/offline scenarios. (This should be thought of similarly to a mobile Push Notification Service).
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
268
269
270
271
272
273
274
275
276
277
278
279
280
281
282
283
284
285
286
287
288
289
290
291
292
293
294
295
296
297
298
299
300
301
302
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class PushNotificationConfig(TypedDict):
    """Configuration for push notifications.

    A2A supports a secure notification mechanism whereby an agent can notify a client of an update
    outside a connected session via a PushNotificationService. Within and across enterprises,
    it is critical that the agent verifies the identity of the notification service, authenticates
    itself with the service, and presents an identifier that ties the notification to the executing
    Task.

    The target server of the PushNotificationService should be considered a separate service, and
    is not guaranteed (or even expected) to be the client directly. This PushNotificationService is
    responsible for authenticating and authorizing the agent and for proxying the verified notification
    to the appropriate endpoint (which could be anything from a pub/sub queue, to an email inbox or
    other service, etc.).

    For contrived scenarios with isolated client-agent pairs (e.g. local service mesh in a contained
    VPC, etc.) or isolated environments without enterprise security concerns, the client may choose to
    simply open a port and act as its own PushNotificationService. Any enterprise implementation will
    likely have a centralized service that authenticates the remote agents with trusted notification
    credentials and can handle online/offline scenarios. (This should be thought of similarly to a
    mobile Push Notification Service).
    """

    id: NotRequired[str]
    """Server-assigned identifier."""

    url: str
    """The URL to send push notifications to."""

    token: NotRequired[str]
    """Token unique to this task/session."""

    authentication: NotRequired[SecurityScheme]
    """Authentication details for push notifications."""

```

---|---
####  id `instance-attribute`
```
id: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Server-assigned identifier.
####  url `instance-attribute`
```
url: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The URL to send push notifications to.
####  token `instance-attribute`
```
token: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Token unique to this task/session.
####  authentication `instance-attribute`
```
authentication: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[SecurityScheme[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SecurityScheme "SecurityScheme



      module-attribute
   \(fasta2a.schema.SecurityScheme\)")]

```

Authentication details for push notifications.
###  TaskPushNotificationConfig
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Configuration for task push notifications.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
305
306
307
308
309
310
311
312
313
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class TaskPushNotificationConfig(TypedDict):
    """Configuration for task push notifications."""

    id: str
    """The task id."""

    push_notification_config: PushNotificationConfig
    """The push notification configuration."""

```

---|---
####  id `instance-attribute`
```
id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The task id.
####  push_notification_config `instance-attribute`
```
push_notification_config: PushNotificationConfig[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig "PushNotificationConfig \(fasta2a.schema.PushNotificationConfig\)")

```

The push notification configuration.
###  Message
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
A Message contains any content that is not an Artifact.
This can include things like agent thoughts, user context, instructions, errors, status, or metadata.
All content from a client comes in the form of a Message. Agents send Messages to communicate status or to provide instructions (whereas generated results are sent as Artifacts).
A Message can have multiple parts to denote different pieces of content. For example, a user request could include a textual description from a user and then multiple files used as context from the client.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
316
317
318
319
320
321
322
323
324
325
326
327
328
329
330
331
332
333
334
335
336
337
338
339
340
341
342
343
344
345
346
347
348
349
350
351
352
353
354
355
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class Message(TypedDict):
    """A Message contains any content that is not an Artifact.

    This can include things like agent thoughts, user context, instructions, errors, status, or metadata.

    All content from a client comes in the form of a Message. Agents send Messages to communicate status or to provide
    instructions (whereas generated results are sent as Artifacts).

    A Message can have multiple parts to denote different pieces of content. For example, a user request could include
    a textual description from a user and then multiple files used as context from the client.
    """

    role: Literal['user', 'agent']
    """The role of the message."""

    parts: list[Part]
    """The parts of the message."""

    kind: Literal['message']
    """Event type."""

    metadata: NotRequired[dict[str, Any]]
    """Metadata about the message."""

    # Additional fields
    message_id: str
    """Identifier created by the message creator."""

    context_id: NotRequired[str]
    """The context the message is associated with."""

    task_id: NotRequired[str]
    """Identifier of task the message is related to."""

    reference_task_ids: NotRequired[list[str]]
    """Array of task IDs this message references."""

    extensions: NotRequired[list[str]]
    """Array of extensions."""

```

---|---
####  role `instance-attribute`
```
role: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['user', 'agent']

```

The role of the message.
####  parts `instance-attribute`
```
parts: list[](https://docs.python.org/3/library/stdtypes.html#list)[Part[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Part "Part



      module-attribute
   \(fasta2a.schema.Part\)")]

```

The parts of the message.
####  kind `instance-attribute`
```
kind: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['message']

```

Event type.
####  metadata `instance-attribute`
```
metadata: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]]

```

Metadata about the message.
####  message_id `instance-attribute`
```
message_id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

Identifier created by the message creator.
####  context_id `instance-attribute`
```
context_id: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

The context the message is associated with.
####  task_id `instance-attribute`
```
task_id: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Identifier of task the message is related to.
####  reference_task_ids `instance-attribute`
```
reference_task_ids: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]]

```

Array of task IDs this message references.
####  extensions `instance-attribute`
```
extensions: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]]

```

Array of extensions.
###  TextPart
Bases: `_BasePart`
A part that contains text.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
364
365
366
367
368
369
370
371
372
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class TextPart(_BasePart):
    """A part that contains text."""

    kind: Literal['text']
    """The kind of the part."""

    text: str
    """The text of the part."""

```

---|---
####  kind `instance-attribute`
```
kind: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['text']

```

The kind of the part.
####  text `instance-attribute`
```
text: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The text of the part.
###  FileWithBytes
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
File with base64 encoded data.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
375
376
377
378
379
380
381
382
383
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class FileWithBytes(TypedDict):
    """File with base64 encoded data."""

    bytes: str
    """The base64 encoded content of the file."""

    mime_type: NotRequired[str]
    """Optional mime type for the file."""

```

---|---
####  bytes `instance-attribute`
```
bytes: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The base64 encoded content of the file.
####  mime_type `instance-attribute`
```
mime_type: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Optional mime type for the file.
###  FileWithUri
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
File with URI reference.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
386
387
388
389
390
391
392
393
394
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class FileWithUri(TypedDict):
    """File with URI reference."""

    uri: str
    """The URI of the file."""

    mime_type: NotRequired[str]
    """The mime type of the file."""

```

---|---
####  uri `instance-attribute`
```
uri: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The URI of the file.
####  mime_type `instance-attribute`
```
mime_type: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

The mime type of the file.
###  FilePart
Bases: `_BasePart`
A part that contains a file.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
397
398
399
400
401
402
403
404
405
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class FilePart(_BasePart):
    """A part that contains a file."""

    kind: Literal['file']
    """The kind of the part."""

    file: FileWithBytes | FileWithUri
    """The file content - either bytes or URI."""

```

---|---
####  kind `instance-attribute`
```
kind: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['file']

```

The kind of the part.
####  file `instance-attribute`
```
file: FileWithBytes[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithBytes "FileWithBytes \(fasta2a.schema.FileWithBytes\)") | FileWithUri[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FileWithUri "FileWithUri \(fasta2a.schema.FileWithUri\)")

```

The file content - either bytes or URI.
###  DataPart
Bases: `_BasePart`
A part that contains structured data.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
408
409
410
411
412
413
414
415
416
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class DataPart(_BasePart):
    """A part that contains structured data."""

    kind: Literal['data']
    """The kind of the part."""

    data: dict[str, Any]
    """The data of the part."""

```

---|---
####  kind `instance-attribute`
```
kind: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['data']

```

The kind of the part.
####  data `instance-attribute`
```
data: dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]

```

The data of the part.
###  Part `module-attribute`
```
Part = Annotated[](https://docs.python.org/3/library/typing.html#typing.Annotated "typing.Annotated")[
    Union[](https://docs.python.org/3/library/typing.html#typing.Union "typing.Union")[TextPart[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TextPart "TextPart \(fasta2a.schema.TextPart\)"), FilePart[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.FilePart "FilePart \(fasta2a.schema.FilePart\)"), DataPart[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DataPart "DataPart \(fasta2a.schema.DataPart\)")],
    Field[](https://docs.pydantic.dev/latest/api/fields/#pydantic.fields.Field "pydantic.Field")(discriminator="kind"),
]

```

A fully formed piece of content exchanged between a client and a remote agent as part of a Message or an Artifact.
Each Part has its own content type and metadata.
###  TaskState `module-attribute`
```
TaskState: TypeAlias[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypeAlias "typing_extensions.TypeAlias") = Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[
    "submitted",
    "working",
    "input-required",
    "completed",
    "canceled",
    "failed",
    "rejected",
    "auth-required",
    "unknown",
]

```

The possible states of a task.
###  TaskStatus
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Status and accompanying message for a task.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
431
432
433
434
435
436
437
438
439
440
441
442
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class TaskStatus(TypedDict):
    """Status and accompanying message for a task."""

    state: TaskState
    """The current state of the task."""

    message: NotRequired[Message]
    """Additional status updates for client."""

    timestamp: NotRequired[str]
    """ISO datetime value of when the status was updated."""

```

---|---
####  state `instance-attribute`
```
state: TaskState[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskState "TaskState



      module-attribute
   \(fasta2a.schema.TaskState\)")

```

The current state of the task.
####  message `instance-attribute`
```
message: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[Message[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message "Message \(fasta2a.schema.Message\)")]

```

Additional status updates for client.
####  timestamp `instance-attribute`
```
timestamp: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

ISO datetime value of when the status was updated.
###  Task
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
A Task is a stateful entity that allows Clients and Remote Agents to achieve a specific outcome.
Clients and Remote Agents exchange Messages within a Task. Remote Agents generate results as Artifacts. A Task is always created by a Client and the status is always determined by the Remote Agent.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
445
446
447
448
449
450
451
452
453
454
455
456
457
458
459
460
461
462
463
464
465
466
467
468
469
470
471
472
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class Task(TypedDict):
    """A Task is a stateful entity that allows Clients and Remote Agents to achieve a specific outcome.

    Clients and Remote Agents exchange Messages within a Task. Remote Agents generate results as Artifacts.
    A Task is always created by a Client and the status is always determined by the Remote Agent.
    """

    id: str
    """Unique identifier for the task."""

    context_id: str
    """The context the task is associated with."""

    kind: Literal['task']
    """Event type."""

    status: TaskStatus
    """Current status of the task."""

    history: NotRequired[list[Message]]
    """Optional history of messages."""

    artifacts: NotRequired[list[Artifact]]
    """Collection of artifacts created by the agent."""

    metadata: NotRequired[dict[str, Any]]
    """Extension metadata."""

```

---|---
####  id `instance-attribute`
```
id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

Unique identifier for the task.
####  context_id `instance-attribute`
```
context_id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The context the task is associated with.
####  kind `instance-attribute`
```
kind: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['task']

```

Event type.
####  status `instance-attribute`
```
status: TaskStatus[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatus "TaskStatus \(fasta2a.schema.TaskStatus\)")

```

Current status of the task.
####  history `instance-attribute`
```
history: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[list[](https://docs.python.org/3/library/stdtypes.html#list)[Message[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message "Message \(fasta2a.schema.Message\)")]]

```

Optional history of messages.
####  artifacts `instance-attribute`
```
artifacts: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[list[](https://docs.python.org/3/library/stdtypes.html#list)[Artifact[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact "Artifact \(fasta2a.schema.Artifact\)")]]

```

Collection of artifacts created by the agent.
####  metadata `instance-attribute`
```
metadata: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]]

```

Extension metadata.
###  TaskStatusUpdateEvent
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Sent by server during message/stream requests.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
475
476
477
478
479
480
481
482
483
484
485
486
487
488
489
490
491
492
493
494
495
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class TaskStatusUpdateEvent(TypedDict):
    """Sent by server during message/stream requests."""

    task_id: str
    """The id of the task."""

    context_id: str
    """The context the task is associated with."""

    kind: Literal['status-update']
    """Event type."""

    status: TaskStatus
    """The status of the task."""

    final: bool
    """Indicates the end of the event stream."""

    metadata: NotRequired[dict[str, Any]]
    """Extension metadata."""

```

---|---
####  task_id `instance-attribute`
```
task_id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The id of the task.
####  context_id `instance-attribute`
```
context_id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The context the task is associated with.
####  kind `instance-attribute`
```
kind: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['status-update']

```

Event type.
####  status `instance-attribute`
```
status: TaskStatus[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatus "TaskStatus \(fasta2a.schema.TaskStatus\)")

```

The status of the task.
####  final `instance-attribute`
```
final: bool[](https://docs.python.org/3/library/functions.html#bool)

```

Indicates the end of the event stream.
####  metadata `instance-attribute`
```
metadata: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]]

```

Extension metadata.
###  TaskArtifactUpdateEvent
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Sent by server during message/stream requests.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
498
499
500
501
502
503
504
505
506
507
508
509
510
511
512
513
514
515
516
517
518
519
520
521
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class TaskArtifactUpdateEvent(TypedDict):
    """Sent by server during message/stream requests."""

    task_id: str
    """The id of the task."""

    context_id: str
    """The context the task is associated with."""

    kind: Literal['artifact-update']
    """Event type identification."""

    artifact: Artifact
    """The artifact that was updated."""

    append: NotRequired[bool]
    """Whether to append to existing artifact (true) or replace (false)."""

    last_chunk: NotRequired[bool]
    """Indicates this is the final chunk of the artifact."""

    metadata: NotRequired[dict[str, Any]]
    """Extension metadata."""

```

---|---
####  task_id `instance-attribute`
```
task_id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The id of the task.
####  context_id `instance-attribute`
```
context_id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The context the task is associated with.
####  kind `instance-attribute`
```
kind: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['artifact-update']

```

Event type identification.
####  artifact `instance-attribute`
```
artifact: Artifact[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Artifact "Artifact \(fasta2a.schema.Artifact\)")

```

The artifact that was updated.
####  append `instance-attribute`
```
append: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[bool[](https://docs.python.org/3/library/functions.html#bool)]

```

Whether to append to existing artifact (true) or replace (false).
####  last_chunk `instance-attribute`
```
last_chunk: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[bool[](https://docs.python.org/3/library/functions.html#bool)]

```

Indicates this is the final chunk of the artifact.
####  metadata `instance-attribute`
```
metadata: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]]

```

Extension metadata.
###  TaskIdParams
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Parameters for a task id.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
524
525
526
527
528
529
530
531
532
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class TaskIdParams(TypedDict):
    """Parameters for a task id."""

    id: str
    """The unique identifier for the task."""

    metadata: NotRequired[dict[str, Any]]
    """Optional metadata associated with the request."""

```

---|---
####  id `instance-attribute`
```
id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The unique identifier for the task.
####  metadata `instance-attribute`
```
metadata: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]]

```

Optional metadata associated with the request.
###  TaskQueryParams
Bases: `TaskIdParams[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskIdParams "TaskIdParams \(fasta2a.schema.TaskIdParams\)")`
Query parameters for a task.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
535
536
537
538
539
540
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class TaskQueryParams(TaskIdParams):
    """Query parameters for a task."""

    history_length: NotRequired[int]
    """Number of recent messages to be retrieved."""

```

---|---
####  history_length `instance-attribute`
```
history_length: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[int[](https://docs.python.org/3/library/functions.html#int)]

```

Number of recent messages to be retrieved.
###  MessageSendConfiguration
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Configuration for the send message request.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
543
544
545
546
547
548
549
550
551
552
553
554
555
556
557
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class MessageSendConfiguration(TypedDict):
    """Configuration for the send message request."""

    accepted_output_modes: list[str]
    """Accepted output modalities by the client."""

    blocking: NotRequired[bool]
    """If the server should treat the client as a blocking request."""

    history_length: NotRequired[int]
    """Number of recent messages to be retrieved."""

    push_notification_config: NotRequired[PushNotificationConfig]
    """Where the server should send notifications when disconnected."""

```

---|---
####  accepted_output_modes `instance-attribute`
```
accepted_output_modes: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]

```

Accepted output modalities by the client.
####  blocking `instance-attribute`
```
blocking: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[bool[](https://docs.python.org/3/library/functions.html#bool)]

```

If the server should treat the client as a blocking request.
####  history_length `instance-attribute`
```
history_length: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[int[](https://docs.python.org/3/library/functions.html#int)]

```

Number of recent messages to be retrieved.
####  push_notification_config `instance-attribute`
```
push_notification_config: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[
    PushNotificationConfig[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationConfig "PushNotificationConfig \(fasta2a.schema.PushNotificationConfig\)")
]

```

Where the server should send notifications when disconnected.
###  MessageSendParams
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Parameters for message/send method.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
560
561
562
563
564
565
566
567
568
569
570
571
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class MessageSendParams(TypedDict):
    """Parameters for message/send method."""

    configuration: NotRequired[MessageSendConfiguration]
    """Send message configuration."""

    message: Message
    """The message being sent to the server."""

    metadata: NotRequired[dict[str, Any]]
    """Extension metadata."""

```

---|---
####  configuration `instance-attribute`
```
configuration: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[MessageSendConfiguration[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration "MessageSendConfiguration \(fasta2a.schema.MessageSendConfiguration\)")]

```

Send message configuration.
####  message `instance-attribute`
```
message: Message[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message "Message \(fasta2a.schema.Message\)")

```

The message being sent to the server.
####  metadata `instance-attribute`
```
metadata: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]]

```

Extension metadata.
###  TaskSendParams
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Internal parameters for task execution within the framework.
Note: This is not part of the A2A protocol - it's used internally for broker/worker communication.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
574
575
576
577
578
579
580
581
582
583
584
585
586
587
588
589
590
591
592
593
594
595
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class TaskSendParams(TypedDict):
    """Internal parameters for task execution within the framework.

    Note: This is not part of the A2A protocol - it's used internally
    for broker/worker communication.
    """

    id: str
    """The id of the task."""

    context_id: str
    """The context id for the task."""

    message: Message
    """The message to process."""

    history_length: NotRequired[int]
    """Number of recent messages to be retrieved."""

    metadata: NotRequired[dict[str, Any]]
    """Extension metadata."""

```

---|---
####  id `instance-attribute`
```
id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The id of the task.
####  context_id `instance-attribute`
```
context_id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The context id for the task.
####  message `instance-attribute`
```
message: Message[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message "Message \(fasta2a.schema.Message\)")

```

The message to process.
####  history_length `instance-attribute`
```
history_length: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[int[](https://docs.python.org/3/library/functions.html#int)]

```

Number of recent messages to be retrieved.
####  metadata `instance-attribute`
```
metadata: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]]

```

Extension metadata.
###  ListTaskPushNotificationConfigParams
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Parameters for getting list of pushNotificationConfigurations associated with a Task.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
598
599
600
601
602
603
604
605
606
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class ListTaskPushNotificationConfigParams(TypedDict):
    """Parameters for getting list of pushNotificationConfigurations associated with a Task."""

    id: str
    """Task id."""

    metadata: NotRequired[dict[str, Any]]
    """Extension metadata."""

```

---|---
####  id `instance-attribute`
```
id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

Task id.
####  metadata `instance-attribute`
```
metadata: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]]

```

Extension metadata.
###  DeleteTaskPushNotificationConfigParams
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Parameters for removing pushNotificationConfiguration associated with a Task.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
609
610
611
612
613
614
615
616
617
618
619
620
```
| ```
@pydantic.with_config({'alias_generator': to_camel})
class DeleteTaskPushNotificationConfigParams(TypedDict):
    """Parameters for removing pushNotificationConfiguration associated with a Task."""

    id: str
    """Task id."""

    push_notification_config_id: str
    """The push notification config id to delete."""

    metadata: NotRequired[dict[str, Any]]
    """Extension metadata."""

```

---|---
####  id `instance-attribute`
```
id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

Task id.
####  push_notification_config_id `instance-attribute`
```
push_notification_config_id: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The push notification config id to delete.
####  metadata `instance-attribute`
```
metadata: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]]

```

Extension metadata.
###  JSONRPCMessage
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
A JSON RPC message.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
623
624
625
626
627
628
629
630
```
| ```
class JSONRPCMessage(TypedDict):
    """A JSON RPC message."""

    jsonrpc: Literal['2.0']
    """The JSON RPC version."""

    id: int | str | None
    """The request id."""

```

---|---
####  jsonrpc `instance-attribute`
```
jsonrpc: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['2.0']

```

The JSON RPC version.
####  id `instance-attribute`
```
id: int[](https://docs.python.org/3/library/functions.html#int) | str[](https://docs.python.org/3/library/stdtypes.html#str) | None

```

The request id.
###  JSONRPCRequest
Bases: `JSONRPCMessage[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCMessage "JSONRPCMessage \(fasta2a.schema.JSONRPCMessage\)")`, `Generic[](https://docs.python.org/3/library/typing.html#typing.Generic "typing.Generic")[Method, Params]`
A JSON RPC request.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
637
638
639
640
641
642
643
644
```
| ```
class JSONRPCRequest(JSONRPCMessage, Generic[Method, Params]):
    """A JSON RPC request."""

    method: Method
    """The method to call."""

    params: Params
    """The parameters to pass to the method."""

```

---|---
####  method `instance-attribute`
```
method: Method

```

The method to call.
####  params `instance-attribute`
```
params: Params

```

The parameters to pass to the method.
###  JSONRPCError
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`, `Generic[](https://docs.python.org/3/library/typing.html#typing.Generic "typing.Generic")[CodeT, MessageT]`
A JSON RPC error.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
655
656
657
658
659
660
661
662
663
664
665
```
| ```
class JSONRPCError(TypedDict, Generic[CodeT, MessageT]):
    """A JSON RPC error."""

    code: CodeT
    """A number that indicates the error type that occurred."""

    message: MessageT
    """A string providing a short description of the error."""

    data: NotRequired[Any]
    """A primitive or structured value containing additional information about the error."""

```

---|---
####  code `instance-attribute`
```
code: CodeT

```

A number that indicates the error type that occurred.
####  message `instance-attribute`
```
message: MessageT

```

A string providing a short description of the error.
####  data `instance-attribute`
```
data: NotRequired[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.NotRequired "typing_extensions.NotRequired")[Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]

```

A primitive or structured value containing additional information about the error.
###  JSONRPCResponse
Bases: `JSONRPCMessage[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCMessage "JSONRPCMessage \(fasta2a.schema.JSONRPCMessage\)")`, `Generic[](https://docs.python.org/3/library/typing.html#typing.Generic "typing.Generic")[ResultT, ErrorT]`
A JSON RPC response.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/schema.py`
```
672
673
674
675
676
```
| ```
class JSONRPCResponse(JSONRPCMessage, Generic[ResultT, ErrorT]):
    """A JSON RPC response."""

    result: NotRequired[ResultT]
    error: NotRequired[ErrorT]

```

---|---
###  JSONParseError `module-attribute`
```
JSONParseError = JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[-32700], Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["Invalid JSON payload"]
]

```

A JSON RPC error for a parse error.
###  InvalidRequestError `module-attribute`
```
InvalidRequestError = JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[-32600],
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["Request payload validation error"],
]

```

A JSON RPC error for an invalid request.
###  MethodNotFoundError `module-attribute`
```
MethodNotFoundError = JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[-32601], Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["Method not found"]
]

```

A JSON RPC error for a method not found.
###  InvalidParamsError `module-attribute`
```
InvalidParamsError = JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[-32602], Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["Invalid parameters"]
]

```

A JSON RPC error for invalid parameters.
###  InternalError `module-attribute`
```
InternalError = JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[-32603], Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["Internal error"]
]

```

A JSON RPC error for an internal error.
###  TaskNotFoundError `module-attribute`
```
TaskNotFoundError = JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[-32001], Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["Task not found"]
]

```

A JSON RPC error for a task not found.
###  TaskNotCancelableError `module-attribute`
```
TaskNotCancelableError = JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[-32002], Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["Task not cancelable"]
]

```

A JSON RPC error for a task not cancelable.
###  PushNotificationNotSupportedError `module-attribute`
```
PushNotificationNotSupportedError = JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[-32003],
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["Push notification not supported"],
]

```

A JSON RPC error for a push notification not supported.
###  UnsupportedOperationError `module-attribute`
```
UnsupportedOperationError = JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[-32004],
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["This operation is not supported"],
]

```

A JSON RPC error for an unsupported operation.
###  ContentTypeNotSupportedError `module-attribute`
```
ContentTypeNotSupportedError = JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[-32005], Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["Incompatible content types"]
]

```

A JSON RPC error for incompatible content types.
###  InvalidAgentResponseError `module-attribute`
```
InvalidAgentResponseError = JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[-32006], Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["Invalid agent response"]
]

```

A JSON RPC error for invalid agent response.
###  SendMessageRequest `module-attribute`
```
SendMessageRequest = JSONRPCRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest "JSONRPCRequest \(fasta2a.schema.JSONRPCRequest\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["message/send"], MessageSendParams[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendParams "MessageSendParams \(fasta2a.schema.MessageSendParams\)")
]

```

A JSON RPC request to send a message.
###  SendMessageResponse `module-attribute`
```
SendMessageResponse = JSONRPCResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCResponse "JSONRPCResponse \(fasta2a.schema.JSONRPCResponse\)")[
    Union[](https://docs.python.org/3/library/typing.html#typing.Union "typing.Union")[Task[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task "Task \(fasta2a.schema.Task\)"), Message[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message "Message \(fasta2a.schema.Message\)")], JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any"), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")]
]

```

A JSON RPC response to send a message.
###  StreamMessageRequest `module-attribute`
```
StreamMessageRequest = JSONRPCRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest "JSONRPCRequest \(fasta2a.schema.JSONRPCRequest\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["message/stream"], MessageSendParams[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendParams "MessageSendParams \(fasta2a.schema.MessageSendParams\)")
]

```

A JSON RPC request to stream a message.
###  StreamMessageResponse `module-attribute`
```
StreamMessageResponse = JSONRPCResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCResponse "JSONRPCResponse \(fasta2a.schema.JSONRPCResponse\)")[
    Union[](https://docs.python.org/3/library/typing.html#typing.Union "typing.Union")[
        Task[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task "Task \(fasta2a.schema.Task\)"),
        Message[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message "Message \(fasta2a.schema.Message\)"),
        TaskStatusUpdateEvent[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskStatusUpdateEvent "TaskStatusUpdateEvent \(fasta2a.schema.TaskStatusUpdateEvent\)"),
        TaskArtifactUpdateEvent[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskArtifactUpdateEvent "TaskArtifactUpdateEvent \(fasta2a.schema.TaskArtifactUpdateEvent\)"),
    ],
    JSONRPCError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCError "JSONRPCError \(fasta2a.schema.JSONRPCError\)")[Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any"), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")],
]

```

A JSON RPC response to a StreamMessageRequest.
###  GetTaskRequest `module-attribute`
```
GetTaskRequest = JSONRPCRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest "JSONRPCRequest \(fasta2a.schema.JSONRPCRequest\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["tasks/get"], TaskQueryParams[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskQueryParams "TaskQueryParams \(fasta2a.schema.TaskQueryParams\)")
]

```

A JSON RPC request to get a task.
###  GetTaskResponse `module-attribute`
```
GetTaskResponse = JSONRPCResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCResponse "JSONRPCResponse \(fasta2a.schema.JSONRPCResponse\)")[Task[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task "Task \(fasta2a.schema.Task\)"), TaskNotFoundError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskNotFoundError "TaskNotFoundError



      module-attribute
   \(fasta2a.schema.TaskNotFoundError\)")]

```

A JSON RPC response to get a task.
###  CancelTaskRequest `module-attribute`
```
CancelTaskRequest = JSONRPCRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest "JSONRPCRequest \(fasta2a.schema.JSONRPCRequest\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["tasks/cancel"], TaskIdParams[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskIdParams "TaskIdParams \(fasta2a.schema.TaskIdParams\)")
]

```

A JSON RPC request to cancel a task.
###  CancelTaskResponse `module-attribute`
```
CancelTaskResponse = JSONRPCResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCResponse "JSONRPCResponse \(fasta2a.schema.JSONRPCResponse\)")[
    Task[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Task "Task \(fasta2a.schema.Task\)"), Union[](https://docs.python.org/3/library/typing.html#typing.Union "typing.Union")[TaskNotCancelableError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskNotCancelableError "TaskNotCancelableError



      module-attribute
   \(fasta2a.schema.TaskNotCancelableError\)"), TaskNotFoundError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskNotFoundError "TaskNotFoundError



      module-attribute
   \(fasta2a.schema.TaskNotFoundError\)")]
]

```

A JSON RPC response to cancel a task.
###  SetTaskPushNotificationRequest `module-attribute`
```
SetTaskPushNotificationRequest = JSONRPCRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest "JSONRPCRequest \(fasta2a.schema.JSONRPCRequest\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["tasks/pushNotification/set"],
    TaskPushNotificationConfig[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskPushNotificationConfig "TaskPushNotificationConfig \(fasta2a.schema.TaskPushNotificationConfig\)"),
]

```

A JSON RPC request to set a task push notification.
###  SetTaskPushNotificationResponse `module-attribute`
```
SetTaskPushNotificationResponse = JSONRPCResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCResponse "JSONRPCResponse \(fasta2a.schema.JSONRPCResponse\)")[
    TaskPushNotificationConfig[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskPushNotificationConfig "TaskPushNotificationConfig \(fasta2a.schema.TaskPushNotificationConfig\)"),
    PushNotificationNotSupportedError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationNotSupportedError "PushNotificationNotSupportedError



      module-attribute
   \(fasta2a.schema.PushNotificationNotSupportedError\)"),
]

```

A JSON RPC response to set a task push notification.
###  GetTaskPushNotificationRequest `module-attribute`
```
GetTaskPushNotificationRequest = JSONRPCRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest "JSONRPCRequest \(fasta2a.schema.JSONRPCRequest\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["tasks/pushNotification/get"], TaskIdParams[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskIdParams "TaskIdParams \(fasta2a.schema.TaskIdParams\)")
]

```

A JSON RPC request to get a task push notification.
###  GetTaskPushNotificationResponse `module-attribute`
```
GetTaskPushNotificationResponse = JSONRPCResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCResponse "JSONRPCResponse \(fasta2a.schema.JSONRPCResponse\)")[
    TaskPushNotificationConfig[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskPushNotificationConfig "TaskPushNotificationConfig \(fasta2a.schema.TaskPushNotificationConfig\)"),
    PushNotificationNotSupportedError[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.PushNotificationNotSupportedError "PushNotificationNotSupportedError



      module-attribute
   \(fasta2a.schema.PushNotificationNotSupportedError\)"),
]

```

A JSON RPC response to get a task push notification.
###  ResubscribeTaskRequest `module-attribute`
```
ResubscribeTaskRequest = JSONRPCRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest "JSONRPCRequest \(fasta2a.schema.JSONRPCRequest\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["tasks/resubscribe"], TaskIdParams[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.TaskIdParams "TaskIdParams \(fasta2a.schema.TaskIdParams\)")
]

```

A JSON RPC request to resubscribe to a task.
###  ListTaskPushNotificationConfigRequest `module-attribute`
```
ListTaskPushNotificationConfigRequest = JSONRPCRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest "JSONRPCRequest \(fasta2a.schema.JSONRPCRequest\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["tasks/pushNotificationConfig/list"],
    ListTaskPushNotificationConfigParams[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ListTaskPushNotificationConfigParams "ListTaskPushNotificationConfigParams \(fasta2a.schema.ListTaskPushNotificationConfigParams\)"),
]

```

A JSON RPC request to list task push notification configs.
###  DeleteTaskPushNotificationConfigRequest `module-attribute`
```
DeleteTaskPushNotificationConfigRequest = JSONRPCRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.JSONRPCRequest "JSONRPCRequest \(fasta2a.schema.JSONRPCRequest\)")[
    Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["tasks/pushNotificationConfig/delete"],
    DeleteTaskPushNotificationConfigParams[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigParams "DeleteTaskPushNotificationConfigParams \(fasta2a.schema.DeleteTaskPushNotificationConfigParams\)"),
]

```

A JSON RPC request to delete a task push notification config.
###  A2ARequest `module-attribute`
```
A2ARequest = Annotated[](https://docs.python.org/3/library/typing.html#typing.Annotated "typing.Annotated")[
    Union[](https://docs.python.org/3/library/typing.html#typing.Union "typing.Union")[
        SendMessageRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SendMessageRequest "SendMessageRequest



      module-attribute
   \(fasta2a.schema.SendMessageRequest\)"),
        StreamMessageRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.StreamMessageRequest "StreamMessageRequest



      module-attribute
   \(fasta2a.schema.StreamMessageRequest\)"),
        GetTaskRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskRequest "GetTaskRequest



      module-attribute
   \(fasta2a.schema.GetTaskRequest\)"),
        CancelTaskRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.CancelTaskRequest "CancelTaskRequest



      module-attribute
   \(fasta2a.schema.CancelTaskRequest\)"),
        SetTaskPushNotificationRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SetTaskPushNotificationRequest "SetTaskPushNotificationRequest



      module-attribute
   \(fasta2a.schema.SetTaskPushNotificationRequest\)"),
        GetTaskPushNotificationRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskPushNotificationRequest "GetTaskPushNotificationRequest



      module-attribute
   \(fasta2a.schema.GetTaskPushNotificationRequest\)"),
        ResubscribeTaskRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ResubscribeTaskRequest "ResubscribeTaskRequest



      module-attribute
   \(fasta2a.schema.ResubscribeTaskRequest\)"),
        ListTaskPushNotificationConfigRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.ListTaskPushNotificationConfigRequest "ListTaskPushNotificationConfigRequest



      module-attribute
   \(fasta2a.schema.ListTaskPushNotificationConfigRequest\)"),
        DeleteTaskPushNotificationConfigRequest[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.DeleteTaskPushNotificationConfigRequest "DeleteTaskPushNotificationConfigRequest



      module-attribute
   \(fasta2a.schema.DeleteTaskPushNotificationConfigRequest\)"),
    ],
    Discriminator[](https://docs.pydantic.dev/latest/api/types/#pydantic.types.Discriminator "pydantic.Discriminator")("method"),
]

```

A JSON RPC request to the A2A server.
###  A2AResponse `module-attribute`
```
A2AResponse: TypeAlias[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypeAlias "typing_extensions.TypeAlias") = Union[](https://docs.python.org/3/library/typing.html#typing.Union "typing.Union")[
    SendMessageResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SendMessageResponse "SendMessageResponse



      module-attribute
   \(fasta2a.schema.SendMessageResponse\)"),
    StreamMessageResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.StreamMessageResponse "StreamMessageResponse



      module-attribute
   \(fasta2a.schema.StreamMessageResponse\)"),
    GetTaskResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskResponse "GetTaskResponse



      module-attribute
   \(fasta2a.schema.GetTaskResponse\)"),
    CancelTaskResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.CancelTaskResponse "CancelTaskResponse



      module-attribute
   \(fasta2a.schema.CancelTaskResponse\)"),
    SetTaskPushNotificationResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SetTaskPushNotificationResponse "SetTaskPushNotificationResponse



      module-attribute
   \(fasta2a.schema.SetTaskPushNotificationResponse\)"),
    GetTaskPushNotificationResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.GetTaskPushNotificationResponse "GetTaskPushNotificationResponse



      module-attribute
   \(fasta2a.schema.GetTaskPushNotificationResponse\)"),
]

```

A JSON RPC response from the A2A server.
###  A2AClient
A client for the A2A protocol.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/client.py`
```
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
```
| ```
class A2AClient:
    """A client for the A2A protocol."""

    def __init__(self, base_url: str = 'http://localhost:8000', http_client: httpx.AsyncClient | None = None) -> None:
        if http_client is None:
            self.http_client = httpx.AsyncClient(base_url=base_url)
        else:
            self.http_client = http_client
            self.http_client.base_url = base_url

    async def send_message(
        self,
        message: Message,
        *,
        metadata: dict[str, Any] | None = None,
        configuration: MessageSendConfiguration | None = None,
    ) -> SendMessageResponse:
        """Send a message using the A2A protocol.

        Returns a JSON-RPC response containing either a result (Task) or an error.
        """
        params = MessageSendParams(message=message)
        if metadata is not None:
            params['metadata'] = metadata
        if configuration is not None:
            params['configuration'] = configuration

        request_id = str(uuid.uuid4())
        payload = SendMessageRequest(jsonrpc='2.0', id=request_id, method='message/send', params=params)
        content = send_message_request_ta.dump_json(payload, by_alias=True)
        response = await self.http_client.post('/', content=content, headers={'Content-Type': 'application/json'})
        self._raise_for_status(response)

        return send_message_response_ta.validate_json(response.content)

    async def get_task(self, task_id: str) -> GetTaskResponse:
        payload = GetTaskRequest(jsonrpc='2.0', id=None, method='tasks/get', params={'id': task_id})
        content = a2a_request_ta.dump_json(payload, by_alias=True)
        response = await self.http_client.post('/', content=content, headers={'Content-Type': 'application/json'})
        self._raise_for_status(response)
        return get_task_response_ta.validate_json(response.content)

    def _raise_for_status(self, response: httpx.Response) -> None:
        if response.status_code >= 400:
            raise UnexpectedResponseError(response.status_code, response.text)

```

---|---
####  send_message `async`
```
send_message(
    message: Message[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.Message "Message \(fasta2a.schema.Message\)"),
    *,
    metadata: dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://docs.python.org/3/library/typing.html#typing.Any "typing.Any")] | None = None,
    configuration: MessageSendConfiguration[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.MessageSendConfiguration "MessageSendConfiguration \(fasta2a.schema.MessageSendConfiguration\)") | None = None
) -> SendMessageResponse[](https://ai.pydantic.dev/api/fasta2a/#fasta2a.schema.SendMessageResponse "SendMessageResponse



      module-attribute
   \(fasta2a.schema.SendMessageResponse\)")

```

Send a message using the A2A protocol.
Returns a JSON-RPC response containing either a result (Task) or an error.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/client.py`
```
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
```
| ```
async def send_message(
    self,
    message: Message,
    *,
    metadata: dict[str, Any] | None = None,
    configuration: MessageSendConfiguration | None = None,
) -> SendMessageResponse:
    """Send a message using the A2A protocol.

    Returns a JSON-RPC response containing either a result (Task) or an error.
    """
    params = MessageSendParams(message=message)
    if metadata is not None:
        params['metadata'] = metadata
    if configuration is not None:
        params['configuration'] = configuration

    request_id = str(uuid.uuid4())
    payload = SendMessageRequest(jsonrpc='2.0', id=request_id, method='message/send', params=params)
    content = send_message_request_ta.dump_json(payload, by_alias=True)
    response = await self.http_client.post('/', content=content, headers={'Content-Type': 'application/json'})
    self._raise_for_status(response)

    return send_message_response_ta.validate_json(response.content)

```

---|---
###  UnexpectedResponseError
Bases: `Exception[](https://docs.python.org/3/library/exceptions.html#Exception)`
An error raised when an unexpected response is received from the server.
Source code in `.venv/lib/python3.12/site-packages/fasta2a/client.py`
```
78
79
80
81
82
83
```
| ```
class UnexpectedResponseError(Exception):
    """An error raised when an unexpected response is received from the server."""

    def __init__(self, status_code: int, content: str) -> None:
        self.status_code = status_code
        self.content = content

```

---|---
© Pydantic Services Inc. 2024 to present
