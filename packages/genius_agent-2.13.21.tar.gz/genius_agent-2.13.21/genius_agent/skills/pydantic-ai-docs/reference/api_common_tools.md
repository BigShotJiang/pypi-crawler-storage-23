[ Skip to content ](https://ai.pydantic.dev/api/common_tools/#pydantic_aicommon_tools)
**Join us at the inaugural PyAI Conf in San Francisco on March 10th![Learn More](https://pyai.events/?utm_source=pydantic-ai) **
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI")
Pydantic AI
pydantic_ai.common_tools
Type to start searching
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI") Pydantic AI
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
  * [ Pydantic AI  ](https://ai.pydantic.dev/)
  * [ Installation  ](https://ai.pydantic.dev/install/)
  * [ Getting Help  ](https://ai.pydantic.dev/help/)
  * [ Troubleshooting  ](https://ai.pydantic.dev/troubleshooting/)
  * [ Pydantic AI Gateway  ](https://ai.pydantic.dev/gateway/)
  * Documentation
    * Core Concepts
      * [ Agents  ](https://ai.pydantic.dev/agent/)
      * [ Dependencies  ](https://ai.pydantic.dev/dependencies/)
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Output  ](https://ai.pydantic.dev/output/)
      * [ Messages and chat history  ](https://ai.pydantic.dev/message-history/)
      * [ Direct Model Requests  ](https://ai.pydantic.dev/direct/)
    * Models & Providers
      * [ Overview  ](https://ai.pydantic.dev/models/overview/)
      * [ OpenAI  ](https://ai.pydantic.dev/models/openai/)
      * [ Anthropic  ](https://ai.pydantic.dev/models/anthropic/)
      * [ Google  ](https://ai.pydantic.dev/models/google/)
      * [ xAI  ](https://ai.pydantic.dev/models/xai/)
      * [ Bedrock  ](https://ai.pydantic.dev/models/bedrock/)
      * [ Cerebras  ](https://ai.pydantic.dev/models/cerebras/)
      * [ Cohere  ](https://ai.pydantic.dev/models/cohere/)
      * [ Groq  ](https://ai.pydantic.dev/models/groq/)
      * [ Hugging Face  ](https://ai.pydantic.dev/models/huggingface/)
      * [ Mistral  ](https://ai.pydantic.dev/models/mistral/)
      * [ OpenRouter  ](https://ai.pydantic.dev/models/openrouter/)
      * [ Outlines  ](https://ai.pydantic.dev/models/outlines/)
    * Tools & Toolsets
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Advanced Tool Features  ](https://ai.pydantic.dev/tools-advanced/)
      * [ Toolsets  ](https://ai.pydantic.dev/toolsets/)
      * [ Deferred Tools  ](https://ai.pydantic.dev/deferred-tools/)
      * [ Built-in Tools  ](https://ai.pydantic.dev/builtin-tools/)
      * [ Common Tools  ](https://ai.pydantic.dev/common-tools/)
      * [ Third-Party Tools  ](https://ai.pydantic.dev/third-party-tools/)
    * Advanced Features
      * [ Image, Audio, Video & Document Input  ](https://ai.pydantic.dev/input/)
      * [ Thinking  ](https://ai.pydantic.dev/thinking/)
      * [ HTTP Request Retries  ](https://ai.pydantic.dev/retries/)
    * MCP
      * [ Overview  ](https://ai.pydantic.dev/mcp/overview/)
      * [ Client  ](https://ai.pydantic.dev/mcp/client/)
      * [ FastMCP Client  ](https://ai.pydantic.dev/mcp/fastmcp-client/)
      * [ Server  ](https://ai.pydantic.dev/mcp/server/)
    * [ Multi-Agent Patterns  ](https://ai.pydantic.dev/multi-agent-applications/)
    * [ Web Chat UI  ](https://ai.pydantic.dev/web/)
    * [ Embeddings  ](https://ai.pydantic.dev/embeddings/)
    * [ Testing  ](https://ai.pydantic.dev/testing/)
  * Pydantic Evals
    * [ Overview  ](https://ai.pydantic.dev/evals/)
    * Getting Started
      * [ Quick Start  ](https://ai.pydantic.dev/evals/quick-start/)
      * [ Core Concepts  ](https://ai.pydantic.dev/evals/core-concepts/)
    * Evaluators
      * [ Overview  ](https://ai.pydantic.dev/evals/evaluators/overview/)
      * [ Built-in Evaluators  ](https://ai.pydantic.dev/evals/evaluators/built-in/)
      * [ LLM Judge  ](https://ai.pydantic.dev/evals/evaluators/llm-judge/)
      * [ Custom Evaluators  ](https://ai.pydantic.dev/evals/evaluators/custom/)
      * [ Report Evaluators  ](https://ai.pydantic.dev/evals/evaluators/report-evaluators/)
      * [ Span-Based  ](https://ai.pydantic.dev/evals/evaluators/span-based/)
    * How-To Guides
      * [ Logfire Integration  ](https://ai.pydantic.dev/evals/how-to/logfire-integration/)
      * [ Dataset Management  ](https://ai.pydantic.dev/evals/how-to/dataset-management/)
      * [ Dataset Serialization  ](https://ai.pydantic.dev/evals/how-to/dataset-serialization/)
      * [ Concurrency & Performance  ](https://ai.pydantic.dev/evals/how-to/concurrency/)
      * [ Multi-Run Evaluation  ](https://ai.pydantic.dev/evals/how-to/multi-run/)
      * [ Retry Strategies  ](https://ai.pydantic.dev/evals/how-to/retry-strategies/)
      * [ Metrics & Attributes  ](https://ai.pydantic.dev/evals/how-to/metrics-attributes/)
    * Examples
      * [ Simple Validation  ](https://ai.pydantic.dev/evals/examples/simple-validation/)
  * Pydantic Graph
    * [ Overview  ](https://ai.pydantic.dev/graph/)
    * [ Beta API  ](https://ai.pydantic.dev/graph/beta/)
      * [ Steps  ](https://ai.pydantic.dev/graph/beta/steps/)
      * [ Joins & Reducers  ](https://ai.pydantic.dev/graph/beta/joins/)
      * [ Decisions  ](https://ai.pydantic.dev/graph/beta/decisions/)
      * [ Parallel Execution  ](https://ai.pydantic.dev/graph/beta/parallel/)
  * Integrations
    * [ Debugging & Monitoring with Pydantic Logfire  ](https://ai.pydantic.dev/logfire/)
    * Durable Execution
      * [ Overview  ](https://ai.pydantic.dev/durable_execution/overview/)
      * [ Temporal  ](https://ai.pydantic.dev/durable_execution/temporal/)
      * [ DBOS  ](https://ai.pydantic.dev/durable_execution/dbos/)
      * [ Prefect  ](https://ai.pydantic.dev/durable_execution/prefect/)
    * UI Event Streams
      * [ Overview  ](https://ai.pydantic.dev/ui/overview/)
      * [ AG-UI  ](https://ai.pydantic.dev/ui/ag-ui/)
      * [ Vercel AI  ](https://ai.pydantic.dev/ui/vercel-ai/)
    * [ Agent2Agent (A2A)  ](https://ai.pydantic.dev/a2a/)
  * Related Packages
    * [ clai  ](https://ai.pydantic.dev/cli/)
  * Examples
    * [ Setup  ](https://ai.pydantic.dev/examples/setup/)
    * Getting Started
      * [ Pydantic Model  ](https://ai.pydantic.dev/examples/pydantic-model/)
      * [ Weather agent  ](https://ai.pydantic.dev/examples/weather-agent/)
    * Conversational Agents
      * [ Chat App with FastAPI  ](https://ai.pydantic.dev/examples/chat-app/)
      * [ Bank support  ](https://ai.pydantic.dev/examples/bank-support/)
    * Data & Analytics
      * [ SQL Generation  ](https://ai.pydantic.dev/examples/sql-gen/)
      * [ Data Analyst  ](https://ai.pydantic.dev/examples/data-analyst/)
      * [ RAG  ](https://ai.pydantic.dev/examples/rag/)
    * Streaming
      * [ Stream markdown  ](https://ai.pydantic.dev/examples/stream-markdown/)
      * [ Stream whales  ](https://ai.pydantic.dev/examples/stream-whales/)
    * Complex Workflows
      * [ Flight booking  ](https://ai.pydantic.dev/examples/flight-booking/)
      * [ Question Graph  ](https://ai.pydantic.dev/examples/question-graph/)
    * Business Applications
      * [ Slack Lead Qualifier with Modal  ](https://ai.pydantic.dev/examples/slack-lead-qualifier/)
    * UI Examples
      * [ Agent User Interaction (AG-UI)  ](https://ai.pydantic.dev/examples/ag-ui/)
  * API Reference
    * pydantic_ai
      * [ pydantic_ai.ag_ui  ](https://ai.pydantic.dev/api/ag_ui/)
      * [ pydantic_ai.agent  ](https://ai.pydantic.dev/api/agent/)
      * [ pydantic_ai.builtin_tools  ](https://ai.pydantic.dev/api/builtin_tools/)
      * pydantic_ai.common_tools  [ pydantic_ai.common_tools  ](https://ai.pydantic.dev/api/common_tools/)
        * [ duckduckgo  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo)
        * [ DuckDuckGoResult  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult)
          * [ title  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult.title)
          * [ href  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult.href)
          * [ body  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult.body)
        * [ DuckDuckGoSearchTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoSearchTool)
          * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoSearchTool.client)
          * [ max_results  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoSearchTool.max_results)
          * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoSearchTool.__call__)
        * [ duckduckgo_search_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.duckduckgo_search_tool)
        * [ exa  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa)
        * [ ExaSearchResult  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult)
          * [ title  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult.title)
          * [ url  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult.url)
          * [ published_date  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult.published_date)
          * [ author  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult.author)
          * [ text  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult.text)
        * [ ExaAnswerResult  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerResult)
          * [ answer  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerResult.answer)
          * [ citations  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerResult.citations)
        * [ ExaContentResult  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult)
          * [ url  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult.url)
          * [ title  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult.title)
          * [ text  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult.text)
          * [ author  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult.author)
          * [ published_date  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult.published_date)
        * [ ExaSearchTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchTool)
          * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchTool.client)
          * [ num_results  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchTool.num_results)
          * [ max_characters  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchTool.max_characters)
          * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchTool.__call__)
        * [ ExaFindSimilarTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaFindSimilarTool)
          * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaFindSimilarTool.client)
          * [ num_results  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaFindSimilarTool.num_results)
          * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaFindSimilarTool.__call__)
        * [ ExaGetContentsTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaGetContentsTool)
          * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaGetContentsTool.client)
          * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaGetContentsTool.__call__)
        * [ ExaAnswerTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerTool)
          * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerTool.client)
          * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerTool.__call__)
        * [ exa_search_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.exa_search_tool)
        * [ exa_find_similar_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.exa_find_similar_tool)
        * [ exa_get_contents_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.exa_get_contents_tool)
        * [ exa_answer_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.exa_answer_tool)
        * [ ExaToolset  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaToolset)
          * [ __init__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaToolset.__init__)
        * [ tavily  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily)
        * [ TavilySearchResult  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult)
          * [ title  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult.title)
          * [ url  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult.url)
          * [ content  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult.content)
          * [ score  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult.score)
        * [ TavilySearchTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchTool)
          * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchTool.client)
          * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchTool.__call__)
        * [ tavily_search_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.tavily_search_tool)
      * [ pydantic_ai — Concurrency  ](https://ai.pydantic.dev/api/concurrency/)
      * [ pydantic_ai.direct  ](https://ai.pydantic.dev/api/direct/)
      * [ pydantic_ai.durable_exec  ](https://ai.pydantic.dev/api/durable_exec/)
      * [ pydantic_ai.embeddings  ](https://ai.pydantic.dev/api/embeddings/)
      * [ pydantic_ai.exceptions  ](https://ai.pydantic.dev/api/exceptions/)
      * [ pydantic_ai.ext  ](https://ai.pydantic.dev/api/ext/)
      * [ pydantic_ai.format_prompt  ](https://ai.pydantic.dev/api/format_prompt/)
      * [ pydantic_ai.mcp  ](https://ai.pydantic.dev/api/mcp/)
      * [ pydantic_ai.messages  ](https://ai.pydantic.dev/api/messages/)
      * [ pydantic_ai.models.anthropic  ](https://ai.pydantic.dev/api/models/anthropic/)
      * [ pydantic_ai.models  ](https://ai.pydantic.dev/api/models/base/)
      * [ pydantic_ai.models.bedrock  ](https://ai.pydantic.dev/api/models/bedrock/)
      * [ pydantic_ai.models.cerebras  ](https://ai.pydantic.dev/api/models/cerebras/)
      * [ pydantic_ai.models.cohere  ](https://ai.pydantic.dev/api/models/cohere/)
      * [ pydantic_ai.models.fallback  ](https://ai.pydantic.dev/api/models/fallback/)
      * [ pydantic_ai.models.function  ](https://ai.pydantic.dev/api/models/function/)
      * [ pydantic_ai.models.google  ](https://ai.pydantic.dev/api/models/google/)
      * [ pydantic_ai.models.xai  ](https://ai.pydantic.dev/api/models/xai/)
      * [ pydantic_ai.models.groq  ](https://ai.pydantic.dev/api/models/groq/)
      * [ pydantic_ai.models.huggingface  ](https://ai.pydantic.dev/api/models/huggingface/)
      * [ pydantic_ai.models.instrumented  ](https://ai.pydantic.dev/api/models/instrumented/)
      * [ pydantic_ai.models.mcp_sampling  ](https://ai.pydantic.dev/api/models/mcp-sampling/)
      * [ pydantic_ai.models.mistral  ](https://ai.pydantic.dev/api/models/mistral/)
      * [ pydantic_ai.models.openai  ](https://ai.pydantic.dev/api/models/openai/)
      * [ pydantic_ai.models.openrouter  ](https://ai.pydantic.dev/api/models/openrouter/)
      * [ pydantic_ai.models.outlines  ](https://ai.pydantic.dev/api/models/outlines/)
      * [ pydantic_ai.models.test  ](https://ai.pydantic.dev/api/models/test/)
      * [ pydantic_ai.models.wrapper  ](https://ai.pydantic.dev/api/models/wrapper/)
      * [ pydantic_ai.output  ](https://ai.pydantic.dev/api/output/)
      * [ pydantic_ai.profiles  ](https://ai.pydantic.dev/api/profiles/)
      * [ pydantic_ai.providers  ](https://ai.pydantic.dev/api/providers/)
      * [ pydantic_ai.result  ](https://ai.pydantic.dev/api/result/)
      * [ pydantic_ai.retries  ](https://ai.pydantic.dev/api/retries/)
      * [ pydantic_ai.run  ](https://ai.pydantic.dev/api/run/)
      * [ pydantic_ai.settings  ](https://ai.pydantic.dev/api/settings/)
      * [ pydantic_ai.tools  ](https://ai.pydantic.dev/api/tools/)
      * [ pydantic_ai.toolsets  ](https://ai.pydantic.dev/api/toolsets/)
      * [ pydantic_ai.ui.ag_ui  ](https://ai.pydantic.dev/api/ui/ag_ui/)
      * [ pydantic_ai.ui  ](https://ai.pydantic.dev/api/ui/base/)
      * [ pydantic_ai.ui.vercel_ai  ](https://ai.pydantic.dev/api/ui/vercel_ai/)
      * [ pydantic_ai.usage  ](https://ai.pydantic.dev/api/usage/)
    * pydantic_evals
      * [ pydantic_evals.dataset  ](https://ai.pydantic.dev/api/pydantic_evals/dataset/)
      * [ pydantic_evals.evaluators  ](https://ai.pydantic.dev/api/pydantic_evals/evaluators/)
      * [ pydantic_evals.reporting  ](https://ai.pydantic.dev/api/pydantic_evals/reporting/)
      * [ pydantic_evals.otel  ](https://ai.pydantic.dev/api/pydantic_evals/otel/)
      * [ pydantic_evals.generation  ](https://ai.pydantic.dev/api/pydantic_evals/generation/)
    * pydantic_graph
      * [ pydantic_graph  ](https://ai.pydantic.dev/api/pydantic_graph/graph/)
      * [ pydantic_graph.nodes  ](https://ai.pydantic.dev/api/pydantic_graph/nodes/)
      * [ pydantic_graph.persistence  ](https://ai.pydantic.dev/api/pydantic_graph/persistence/)
      * [ pydantic_graph.mermaid  ](https://ai.pydantic.dev/api/pydantic_graph/mermaid/)
      * [ pydantic_graph.exceptions  ](https://ai.pydantic.dev/api/pydantic_graph/exceptions/)
      * Beta API
        * [ pydantic_graph.beta  ](https://ai.pydantic.dev/api/pydantic_graph/beta/)
        * [ pydantic_graph.beta.graph  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph/)
        * [ pydantic_graph.beta.graph_builder  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph_builder/)
        * [ pydantic_graph.beta.step  ](https://ai.pydantic.dev/api/pydantic_graph/beta_step/)
        * [ pydantic_graph.beta.join  ](https://ai.pydantic.dev/api/pydantic_graph/beta_join/)
        * [ pydantic_graph.beta.decision  ](https://ai.pydantic.dev/api/pydantic_graph/beta_decision/)
        * [ pydantic_graph.beta.node  ](https://ai.pydantic.dev/api/pydantic_graph/beta_node/)
    * fasta2a
      * [ fasta2a  ](https://ai.pydantic.dev/api/fasta2a/)
  * Project
    * [ Contributing  ](https://ai.pydantic.dev/contributing/)
    * [ Upgrade Guide  ](https://ai.pydantic.dev/changelog/)
    * [ Version policy  ](https://ai.pydantic.dev/version-policy/)


  * [ duckduckgo  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo)
  * [ DuckDuckGoResult  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult)
    * [ title  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult.title)
    * [ href  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult.href)
    * [ body  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult.body)
  * [ DuckDuckGoSearchTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoSearchTool)
    * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoSearchTool.client)
    * [ max_results  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoSearchTool.max_results)
    * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoSearchTool.__call__)
  * [ duckduckgo_search_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.duckduckgo_search_tool)
  * [ exa  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa)
  * [ ExaSearchResult  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult)
    * [ title  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult.title)
    * [ url  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult.url)
    * [ published_date  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult.published_date)
    * [ author  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult.author)
    * [ text  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult.text)
  * [ ExaAnswerResult  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerResult)
    * [ answer  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerResult.answer)
    * [ citations  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerResult.citations)
  * [ ExaContentResult  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult)
    * [ url  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult.url)
    * [ title  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult.title)
    * [ text  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult.text)
    * [ author  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult.author)
    * [ published_date  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult.published_date)
  * [ ExaSearchTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchTool)
    * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchTool.client)
    * [ num_results  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchTool.num_results)
    * [ max_characters  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchTool.max_characters)
    * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchTool.__call__)
  * [ ExaFindSimilarTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaFindSimilarTool)
    * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaFindSimilarTool.client)
    * [ num_results  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaFindSimilarTool.num_results)
    * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaFindSimilarTool.__call__)
  * [ ExaGetContentsTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaGetContentsTool)
    * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaGetContentsTool.client)
    * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaGetContentsTool.__call__)
  * [ ExaAnswerTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerTool)
    * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerTool.client)
    * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerTool.__call__)
  * [ exa_search_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.exa_search_tool)
  * [ exa_find_similar_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.exa_find_similar_tool)
  * [ exa_get_contents_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.exa_get_contents_tool)
  * [ exa_answer_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.exa_answer_tool)
  * [ ExaToolset  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaToolset)
    * [ __init__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaToolset.__init__)
  * [ tavily  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily)
  * [ TavilySearchResult  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult)
    * [ title  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult.title)
    * [ url  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult.url)
    * [ content  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult.content)
    * [ score  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult.score)
  * [ TavilySearchTool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchTool)
    * [ client  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchTool.client)
    * [ __call__  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchTool.__call__)
  * [ tavily_search_tool  ](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.tavily_search_tool)


  1. [ Pydantic AI  ](https://ai.pydantic.dev/)
  2. [ API Reference  ](https://ai.pydantic.dev/api/ag_ui/)
  3. [ pydantic_ai  ](https://ai.pydantic.dev/api/ag_ui/)


# `pydantic_ai.common_tools`
###  DuckDuckGoResult
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
A DuckDuckGo search result.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/duckduckgo.py`
```
24
25
26
27
28
29
30
31
32
```
| ```
class DuckDuckGoResult(TypedDict):
    """A DuckDuckGo search result."""

    title: str
    """The title of the search result."""
    href: str
    """The URL of the search result."""
    body: str
    """The body of the search result."""

```

---|---
####  title `instance-attribute`
```
title: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The title of the search result.
####  href `instance-attribute`
```
href: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The URL of the search result.
####  body `instance-attribute`
```
body: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The body of the search result.
###  DuckDuckGoSearchTool `dataclass`
The DuckDuckGo search tool.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/duckduckgo.py`
```
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
```
| ```
@dataclass
class DuckDuckGoSearchTool:
    """The DuckDuckGo search tool."""

    client: DDGS
    """The DuckDuckGo search client."""

    _: KW_ONLY

    max_results: int | None
    """The maximum number of results. If None, returns results only from the first response."""

    async def __call__(self, query: str) -> list[DuckDuckGoResult]:
        """Searches DuckDuckGo for the given query and returns the results.

        Args:
            query: The query to search for.

        Returns:
            The search results.
        """
        search = functools.partial(self.client.text, max_results=self.max_results)
        results = await anyio.to_thread.run_sync(search, query)
        return duckduckgo_ta.validate_python(results)

```

---|---
####  client `instance-attribute`
```
client: DDGS

```

The DuckDuckGo search client.
####  max_results `instance-attribute`
```
max_results: int[](https://docs.python.org/3/library/functions.html#int) | None

```

The maximum number of results. If None, returns results only from the first response.
####  __call__ `async`
```
__call__(query: str[](https://docs.python.org/3/library/stdtypes.html#str)) -> list[](https://docs.python.org/3/library/stdtypes.html#list)[DuckDuckGoResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult "DuckDuckGoResult \(pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult\)")]

```

Searches DuckDuckGo for the given query and returns the results.
Parameters:
Name | Type | Description | Default
---|---|---|---
`query` |  `str[](https://docs.python.org/3/library/stdtypes.html#str)` |  The query to search for. |  _required_
Returns:
Type | Description
---|---
`list[](https://docs.python.org/3/library/stdtypes.html#list)[DuckDuckGoResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult "DuckDuckGoResult \(pydantic_ai.common_tools.duckduckgo.DuckDuckGoResult\)")]` |  The search results.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/duckduckgo.py`
```
50
51
52
53
54
55
56
57
58
59
60
61
```
| ```
async def __call__(self, query: str) -> list[DuckDuckGoResult]:
    """Searches DuckDuckGo for the given query and returns the results.

    Args:
        query: The query to search for.

    Returns:
        The search results.
    """
    search = functools.partial(self.client.text, max_results=self.max_results)
    results = await anyio.to_thread.run_sync(search, query)
    return duckduckgo_ta.validate_python(results)

```

---|---
###  duckduckgo_search_tool
```
duckduckgo_search_tool(
    duckduckgo_client: DDGS | None = None,
    max_results: int[](https://docs.python.org/3/library/functions.html#int) | None = None,
)

```

Creates a DuckDuckGo search tool.
Parameters:
Name | Type | Description | Default
---|---|---|---
`duckduckgo_client` |  `DDGS | None` |  The DuckDuckGo search client. |  `None`
`max_results` |  `int[](https://docs.python.org/3/library/functions.html#int) | None` |  The maximum number of results. If None, returns results only from the first response. |  `None`
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/duckduckgo.py`
```
64
65
66
67
68
69
70
71
72
73
74
75
```
| ```
def duckduckgo_search_tool(duckduckgo_client: DDGS | None = None, max_results: int | None = None):
    """Creates a DuckDuckGo search tool.

    Args:
        duckduckgo_client: The DuckDuckGo search client.
        max_results: The maximum number of results. If None, returns results only from the first response.
    """
    return Tool[Any](
        DuckDuckGoSearchTool(client=duckduckgo_client or DDGS(), max_results=max_results).__call__,
        name='duckduckgo_search',
        description='Searches DuckDuckGo for the given query and returns the results.',
    )

```

---|---
Exa tools for Pydantic AI agents.
Provides web search, content retrieval, and AI-powered answer capabilities using the Exa API, a neural search engine that finds high-quality, relevant results across billions of web pages.
###  ExaSearchResult
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
An Exa search result with content.
See [Exa Search API documentation](https://docs.exa.ai/reference/search) for more information.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
```
| ```
class ExaSearchResult(TypedDict):
    """An Exa search result with content.

    See [Exa Search API documentation](https://docs.exa.ai/reference/search)
    for more information.
    """

    title: str
    """The title of the search result."""
    url: str
    """The URL of the search result."""
    published_date: str | None
    """The published date of the content, if available."""
    author: str | None
    """The author of the content, if available."""
    text: str
    """The text content of the search result."""

```

---|---
####  title `instance-attribute`
```
title: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The title of the search result.
####  url `instance-attribute`
```
url: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The URL of the search result.
####  published_date `instance-attribute`
```
published_date: str[](https://docs.python.org/3/library/stdtypes.html#str) | None

```

The published date of the content, if available.
####  author `instance-attribute`
```
author: str[](https://docs.python.org/3/library/stdtypes.html#str) | None

```

The author of the content, if available.
####  text `instance-attribute`
```
text: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The text content of the search result.
###  ExaAnswerResult
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
An Exa answer result with citations.
See [Exa Answer API documentation](https://docs.exa.ai/reference/answer) for more information.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
52
53
54
55
56
57
58
59
60
61
62
```
| ```
class ExaAnswerResult(TypedDict):
    """An Exa answer result with citations.

    See [Exa Answer API documentation](https://docs.exa.ai/reference/answer)
    for more information.
    """

    answer: str
    """The AI-generated answer to the query."""
    citations: list[dict[str, Any]]
    """Citations supporting the answer."""

```

---|---
####  answer `instance-attribute`
```
answer: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The AI-generated answer to the query.
####  citations `instance-attribute`
```
citations: list[](https://docs.python.org/3/library/stdtypes.html#list)[dict[](https://docs.python.org/3/library/stdtypes.html#dict)[str[](https://docs.python.org/3/library/stdtypes.html#str), Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]]

```

Citations supporting the answer.
###  ExaContentResult
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
Content retrieved from a URL.
See [Exa Contents API documentation](https://docs.exa.ai/reference/get-contents) for more information.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
80
81
```
| ```
class ExaContentResult(TypedDict):
    """Content retrieved from a URL.

    See [Exa Contents API documentation](https://docs.exa.ai/reference/get-contents)
    for more information.
    """

    url: str
    """The URL of the content."""
    title: str
    """The title of the page."""
    text: str
    """The text content of the page."""
    author: str | None
    """The author of the content, if available."""
    published_date: str | None
    """The published date of the content, if available."""

```

---|---
####  url `instance-attribute`
```
url: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The URL of the content.
####  title `instance-attribute`
```
title: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The title of the page.
####  text `instance-attribute`
```
text: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The text content of the page.
####  author `instance-attribute`
```
author: str[](https://docs.python.org/3/library/stdtypes.html#str) | None

```

The author of the content, if available.
####  published_date `instance-attribute`
```
published_date: str[](https://docs.python.org/3/library/stdtypes.html#str) | None

```

The published date of the content, if available.
###  ExaSearchTool `dataclass`
The Exa search tool.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
 84
 85
 86
 87
 88
 89
 90
 91
 92
 93
 94
 95
 96
 97
 98
 99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
```
| ```
@dataclass
class ExaSearchTool:
    """The Exa search tool."""

    client: AsyncExa
    """The Exa async client."""

    num_results: int
    """The number of results to return."""

    max_characters: int | None
    """Maximum characters of text content per result, or None for no limit."""

    async def __call__(
        self,
        query: str,
        search_type: Literal['auto', 'keyword', 'neural', 'fast', 'deep'] = 'auto',
    ) -> list[ExaSearchResult]:
        """Searches Exa for the given query and returns the results with content.

        Args:
            query: The search query to execute with Exa.
            search_type: The type of search to perform. 'auto' automatically chooses
                the best search type, 'keyword' for exact matches, 'neural' for
                semantic search, 'fast' for speed-optimized search, 'deep' for
                comprehensive multi-query search.

        Returns:
            The search results with text content.
        """
        text_config: bool | dict[str, int] = {'maxCharacters': self.max_characters} if self.max_characters else True
        response = await self.client.search(  # pyright: ignore[reportUnknownMemberType]
            query,
            num_results=self.num_results,
            type=search_type,
            contents={'text': text_config},
        )

        return [
            ExaSearchResult(
                title=result.title or '',
                url=result.url,
                published_date=result.published_date,
                author=result.author,
                text=result.text or '',
            )
            for result in response.results
        ]

```

---|---
####  client `instance-attribute`
```
client: AsyncExa

```

The Exa async client.
####  num_results `instance-attribute`
```
num_results: int[](https://docs.python.org/3/library/functions.html#int)

```

The number of results to return.
####  max_characters `instance-attribute`
```
max_characters: int[](https://docs.python.org/3/library/functions.html#int) | None

```

Maximum characters of text content per result, or None for no limit.
####  __call__ `async`
```
__call__(
    query: str[](https://docs.python.org/3/library/stdtypes.html#str),
    search_type: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[
        "auto", "keyword", "neural", "fast", "deep"
    ] = "auto",
) -> list[](https://docs.python.org/3/library/stdtypes.html#list)[ExaSearchResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult "ExaSearchResult \(pydantic_ai.common_tools.exa.ExaSearchResult\)")]

```

Searches Exa for the given query and returns the results with content.
Parameters:
Name | Type | Description | Default
---|---|---|---
`query` |  `str[](https://docs.python.org/3/library/stdtypes.html#str)` |  The search query to execute with Exa. |  _required_
`search_type` |  `Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['auto', 'keyword', 'neural', 'fast', 'deep']` |  The type of search to perform. 'auto' automatically chooses the best search type, 'keyword' for exact matches, 'neural' for semantic search, 'fast' for speed-optimized search, 'deep' for comprehensive multi-query search. |  `'auto'`
Returns:
Type | Description
---|---
`list[](https://docs.python.org/3/library/stdtypes.html#list)[ExaSearchResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult "ExaSearchResult \(pydantic_ai.common_tools.exa.ExaSearchResult\)")]` |  The search results with text content.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
 97
 98
 99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
```
| ```
async def __call__(
    self,
    query: str,
    search_type: Literal['auto', 'keyword', 'neural', 'fast', 'deep'] = 'auto',
) -> list[ExaSearchResult]:
    """Searches Exa for the given query and returns the results with content.

    Args:
        query: The search query to execute with Exa.
        search_type: The type of search to perform. 'auto' automatically chooses
            the best search type, 'keyword' for exact matches, 'neural' for
            semantic search, 'fast' for speed-optimized search, 'deep' for
            comprehensive multi-query search.

    Returns:
        The search results with text content.
    """
    text_config: bool | dict[str, int] = {'maxCharacters': self.max_characters} if self.max_characters else True
    response = await self.client.search(  # pyright: ignore[reportUnknownMemberType]
        query,
        num_results=self.num_results,
        type=search_type,
        contents={'text': text_config},
    )

    return [
        ExaSearchResult(
            title=result.title or '',
            url=result.url,
            published_date=result.published_date,
            author=result.author,
            text=result.text or '',
        )
        for result in response.results
    ]

```

---|---
###  ExaFindSimilarTool `dataclass`
The Exa find similar tool.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
134
135
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150
151
152
153
154
155
156
157
158
159
160
161
162
163
164
165
166
167
168
169
170
171
172
173
174
175
```
| ```
@dataclass
class ExaFindSimilarTool:
    """The Exa find similar tool."""

    client: AsyncExa
    """The Exa async client."""

    num_results: int
    """The number of results to return."""

    async def __call__(
        self,
        url: str,
        exclude_source_domain: bool = True,
    ) -> list[ExaSearchResult]:
        """Finds pages similar to the given URL and returns them with content.

        Args:
            url: The URL to find similar pages for.
            exclude_source_domain: Whether to exclude results from the same domain
                as the input URL. Defaults to True.

        Returns:
            Similar pages with text content.
        """
        response = await self.client.find_similar(  # pyright: ignore[reportUnknownMemberType]
            url,
            num_results=self.num_results,
            exclude_source_domain=exclude_source_domain,
            contents={'text': True},
        )

        return [
            ExaSearchResult(
                title=result.title or '',
                url=result.url,
                published_date=result.published_date,
                author=result.author,
                text=result.text or '',
            )
            for result in response.results
        ]

```

---|---
####  client `instance-attribute`
```
client: AsyncExa

```

The Exa async client.
####  num_results `instance-attribute`
```
num_results: int[](https://docs.python.org/3/library/functions.html#int)

```

The number of results to return.
####  __call__ `async`
```
__call__(
    url: str[](https://docs.python.org/3/library/stdtypes.html#str), exclude_source_domain: bool[](https://docs.python.org/3/library/functions.html#bool) = True
) -> list[](https://docs.python.org/3/library/stdtypes.html#list)[ExaSearchResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult "ExaSearchResult \(pydantic_ai.common_tools.exa.ExaSearchResult\)")]

```

Finds pages similar to the given URL and returns them with content.
Parameters:
Name | Type | Description | Default
---|---|---|---
`url` |  `str[](https://docs.python.org/3/library/stdtypes.html#str)` |  The URL to find similar pages for. |  _required_
`exclude_source_domain` |  `bool[](https://docs.python.org/3/library/functions.html#bool)` |  Whether to exclude results from the same domain as the input URL. Defaults to True. |  `True`
Returns:
Type | Description
---|---
`list[](https://docs.python.org/3/library/stdtypes.html#list)[ExaSearchResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaSearchResult "ExaSearchResult \(pydantic_ai.common_tools.exa.ExaSearchResult\)")]` |  Similar pages with text content.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
144
145
146
147
148
149
150
151
152
153
154
155
156
157
158
159
160
161
162
163
164
165
166
167
168
169
170
171
172
173
174
175
```
| ```
async def __call__(
    self,
    url: str,
    exclude_source_domain: bool = True,
) -> list[ExaSearchResult]:
    """Finds pages similar to the given URL and returns them with content.

    Args:
        url: The URL to find similar pages for.
        exclude_source_domain: Whether to exclude results from the same domain
            as the input URL. Defaults to True.

    Returns:
        Similar pages with text content.
    """
    response = await self.client.find_similar(  # pyright: ignore[reportUnknownMemberType]
        url,
        num_results=self.num_results,
        exclude_source_domain=exclude_source_domain,
        contents={'text': True},
    )

    return [
        ExaSearchResult(
            title=result.title or '',
            url=result.url,
            published_date=result.published_date,
            author=result.author,
            text=result.text or '',
        )
        for result in response.results
    ]

```

---|---
###  ExaGetContentsTool `dataclass`
The Exa get contents tool.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
178
179
180
181
182
183
184
185
186
187
188
189
190
191
192
193
194
195
196
197
198
199
200
201
202
203
204
205
206
207
208
```
| ```
@dataclass
class ExaGetContentsTool:
    """The Exa get contents tool."""

    client: AsyncExa
    """The Exa async client."""

    async def __call__(
        self,
        urls: list[str],
    ) -> list[ExaContentResult]:
        """Gets the content of the specified URLs.

        Args:
            urls: A list of URLs to get content for.

        Returns:
            The content of each URL.
        """
        response = await self.client.get_contents(urls, text=True)  # pyright: ignore[reportUnknownMemberType,reportUnknownVariableType]

        return [
            ExaContentResult(
                url=result.url,  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
                title=result.title or '',  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
                text=result.text or '',  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
                author=result.author,  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
                published_date=result.published_date,  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
            )
            for result in response.results  # pyright: ignore[reportUnknownVariableType,reportUnknownMemberType]
        ]

```

---|---
####  client `instance-attribute`
```
client: AsyncExa

```

The Exa async client.
####  __call__ `async`
```
__call__(urls: list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]) -> list[](https://docs.python.org/3/library/stdtypes.html#list)[ExaContentResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult "ExaContentResult \(pydantic_ai.common_tools.exa.ExaContentResult\)")]

```

Gets the content of the specified URLs.
Parameters:
Name | Type | Description | Default
---|---|---|---
`urls` |  `list[](https://docs.python.org/3/library/stdtypes.html#list)[str[](https://docs.python.org/3/library/stdtypes.html#str)]` |  A list of URLs to get content for. |  _required_
Returns:
Type | Description
---|---
`list[](https://docs.python.org/3/library/stdtypes.html#list)[ExaContentResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaContentResult "ExaContentResult \(pydantic_ai.common_tools.exa.ExaContentResult\)")]` |  The content of each URL.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
185
186
187
188
189
190
191
192
193
194
195
196
197
198
199
200
201
202
203
204
205
206
207
208
```
| ```
async def __call__(
    self,
    urls: list[str],
) -> list[ExaContentResult]:
    """Gets the content of the specified URLs.

    Args:
        urls: A list of URLs to get content for.

    Returns:
        The content of each URL.
    """
    response = await self.client.get_contents(urls, text=True)  # pyright: ignore[reportUnknownMemberType,reportUnknownVariableType]

    return [
        ExaContentResult(
            url=result.url,  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
            title=result.title or '',  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
            text=result.text or '',  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
            author=result.author,  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
            published_date=result.published_date,  # pyright: ignore[reportUnknownMemberType,reportUnknownArgumentType]
        )
        for result in response.results  # pyright: ignore[reportUnknownVariableType,reportUnknownMemberType]
    ]

```

---|---
###  ExaAnswerTool `dataclass`
The Exa answer tool.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
211
212
213
214
215
216
217
218
219
220
221
222
223
224
225
226
227
228
229
230
231
232
233
234
235
236
237
238
239
240
241
242
```
| ```
@dataclass
class ExaAnswerTool:
    """The Exa answer tool."""

    client: AsyncExa
    """The Exa async client."""

    async def __call__(
        self,
        query: str,
    ) -> ExaAnswerResult:
        """Generates an AI-powered answer to the query with citations.

        Args:
            query: The question to answer.

        Returns:
            An answer with supporting citations from web sources.
        """
        response = await self.client.answer(query, text=True)

        return ExaAnswerResult(
            answer=response.answer,  # pyright: ignore[reportUnknownMemberType,reportArgumentType,reportAttributeAccessIssue]
            citations=[
                {
                    'url': citation.url,  # pyright: ignore[reportUnknownMemberType]
                    'title': citation.title or '',  # pyright: ignore[reportUnknownMemberType]
                    'text': citation.text or '',  # pyright: ignore[reportUnknownMemberType]
                }
                for citation in response.citations  # pyright: ignore[reportUnknownVariableType,reportUnknownMemberType,reportAttributeAccessIssue]
            ],
        )

```

---|---
####  client `instance-attribute`
```
client: AsyncExa

```

The Exa async client.
####  __call__ `async`
```
__call__(query: str[](https://docs.python.org/3/library/stdtypes.html#str)) -> ExaAnswerResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerResult "ExaAnswerResult \(pydantic_ai.common_tools.exa.ExaAnswerResult\)")

```

Generates an AI-powered answer to the query with citations.
Parameters:
Name | Type | Description | Default
---|---|---|---
`query` |  `str[](https://docs.python.org/3/library/stdtypes.html#str)` |  The question to answer. |  _required_
Returns:
Type | Description
---|---
`ExaAnswerResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.exa.ExaAnswerResult "ExaAnswerResult \(pydantic_ai.common_tools.exa.ExaAnswerResult\)")` |  An answer with supporting citations from web sources.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
218
219
220
221
222
223
224
225
226
227
228
229
230
231
232
233
234
235
236
237
238
239
240
241
242
```
| ```
async def __call__(
    self,
    query: str,
) -> ExaAnswerResult:
    """Generates an AI-powered answer to the query with citations.

    Args:
        query: The question to answer.

    Returns:
        An answer with supporting citations from web sources.
    """
    response = await self.client.answer(query, text=True)

    return ExaAnswerResult(
        answer=response.answer,  # pyright: ignore[reportUnknownMemberType,reportArgumentType,reportAttributeAccessIssue]
        citations=[
            {
                'url': citation.url,  # pyright: ignore[reportUnknownMemberType]
                'title': citation.title or '',  # pyright: ignore[reportUnknownMemberType]
                'text': citation.text or '',  # pyright: ignore[reportUnknownMemberType]
            }
            for citation in response.citations  # pyright: ignore[reportUnknownVariableType,reportUnknownMemberType,reportAttributeAccessIssue]
        ],
    )

```

---|---
###  exa_search_tool
```
exa_search_tool(
    api_key: str[](https://docs.python.org/3/library/stdtypes.html#str),
    *,
    num_results: int[](https://docs.python.org/3/library/functions.html#int) = 5,
    max_characters: int[](https://docs.python.org/3/library/functions.html#int) | None = None
) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

```
exa_search_tool(
    *,
    client: AsyncExa,
    num_results: int[](https://docs.python.org/3/library/functions.html#int) = 5,
    max_characters: int[](https://docs.python.org/3/library/functions.html#int) | None = None
) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

```
exa_search_tool(
    api_key: str[](https://docs.python.org/3/library/stdtypes.html#str) | None = None,
    *,
    client: AsyncExa | None = None,
    num_results: int[](https://docs.python.org/3/library/functions.html#int) = 5,
    max_characters: int[](https://docs.python.org/3/library/functions.html#int) | None = None
) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

Creates an Exa search tool.
Parameters:
Name | Type | Description | Default
---|---|---|---
`api_key` |  `str[](https://docs.python.org/3/library/stdtypes.html#str) | None` |  The Exa API key. Required if `client` is not provided. You can get one by signing up at <https://dashboard.exa.ai>. |  `None`
`client` |  `AsyncExa | None` |  An existing AsyncExa client. If provided, `api_key` is ignored. This is useful for sharing a client across multiple tools. |  `None`
`num_results` |  `int[](https://docs.python.org/3/library/functions.html#int)` |  The number of results to return. Defaults to 5. |  `5`
`max_characters` |  `int[](https://docs.python.org/3/library/functions.html#int) | None` |  Maximum characters of text content per result. Use this to limit token usage. Defaults to None (no limit). |  `None`
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
263
264
265
266
267
268
269
270
271
272
273
274
275
276
277
278
279
280
281
282
283
284
285
286
287
288
289
290
291
292
293
294
```
| ```
def exa_search_tool(
    api_key: str | None = None,
    *,
    client: AsyncExa | None = None,
    num_results: int = 5,
    max_characters: int | None = None,
) -> Tool[Any]:
    """Creates an Exa search tool.

    Args:
        api_key: The Exa API key. Required if `client` is not provided.

            You can get one by signing up at [https://dashboard.exa.ai](https://dashboard.exa.ai).
        client: An existing AsyncExa client. If provided, `api_key` is ignored.
            This is useful for sharing a client across multiple tools.
        num_results: The number of results to return. Defaults to 5.
        max_characters: Maximum characters of text content per result. Use this to limit
            token usage. Defaults to None (no limit).
    """
    if client is None:
        if api_key is None:
            raise ValueError('Either api_key or client must be provided')
        client = AsyncExa(api_key=api_key)
    return Tool[Any](
        ExaSearchTool(
            client=client,
            num_results=num_results,
            max_characters=max_characters,
        ).__call__,
        name='exa_search',
        description='Searches Exa for the given query and returns the results with content. Exa is a neural search engine that finds high-quality, relevant results.',
    )

```

---|---
###  exa_find_similar_tool
```
exa_find_similar_tool(
    api_key: str[](https://docs.python.org/3/library/stdtypes.html#str), *, num_results: int[](https://docs.python.org/3/library/functions.html#int) = 5
) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

```
exa_find_similar_tool(
    *, client: AsyncExa, num_results: int[](https://docs.python.org/3/library/functions.html#int) = 5
) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

```
exa_find_similar_tool(
    api_key: str[](https://docs.python.org/3/library/stdtypes.html#str) | None = None,
    *,
    client: AsyncExa | None = None,
    num_results: int[](https://docs.python.org/3/library/functions.html#int) = 5
) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

Creates an Exa find similar tool.
Parameters:
Name | Type | Description | Default
---|---|---|---
`api_key` |  `str[](https://docs.python.org/3/library/stdtypes.html#str) | None` |  The Exa API key. Required if `client` is not provided. You can get one by signing up at <https://dashboard.exa.ai>. |  `None`
`client` |  `AsyncExa | None` |  An existing AsyncExa client. If provided, `api_key` is ignored. This is useful for sharing a client across multiple tools. |  `None`
`num_results` |  `int[](https://docs.python.org/3/library/functions.html#int)` |  The number of similar results to return. Defaults to 5. |  `5`
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
313
314
315
316
317
318
319
320
321
322
323
324
325
326
327
328
329
330
331
332
333
334
335
336
337
```
| ```
def exa_find_similar_tool(
    api_key: str | None = None,
    *,
    client: AsyncExa | None = None,
    num_results: int = 5,
) -> Tool[Any]:
    """Creates an Exa find similar tool.

    Args:
        api_key: The Exa API key. Required if `client` is not provided.

            You can get one by signing up at [https://dashboard.exa.ai](https://dashboard.exa.ai).
        client: An existing AsyncExa client. If provided, `api_key` is ignored.
            This is useful for sharing a client across multiple tools.
        num_results: The number of similar results to return. Defaults to 5.
    """
    if client is None:
        if api_key is None:
            raise ValueError('Either api_key or client must be provided')
        client = AsyncExa(api_key=api_key)
    return Tool[Any](
        ExaFindSimilarTool(client=client, num_results=num_results).__call__,
        name='exa_find_similar',
        description='Finds web pages similar to a given URL. Useful for discovering related content, competitors, or alternative sources.',
    )

```

---|---
###  exa_get_contents_tool
```
exa_get_contents_tool(api_key: str[](https://docs.python.org/3/library/stdtypes.html#str)) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

```
exa_get_contents_tool(*, client: AsyncExa) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

```
exa_get_contents_tool(
    api_key: str[](https://docs.python.org/3/library/stdtypes.html#str) | None = None,
    *,
    client: AsyncExa | None = None
) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

Creates an Exa get contents tool.
Parameters:
Name | Type | Description | Default
---|---|---|---
`api_key` |  `str[](https://docs.python.org/3/library/stdtypes.html#str) | None` |  The Exa API key. Required if `client` is not provided. You can get one by signing up at <https://dashboard.exa.ai>. |  `None`
`client` |  `AsyncExa | None` |  An existing AsyncExa client. If provided, `api_key` is ignored. This is useful for sharing a client across multiple tools. |  `None`
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
348
349
350
351
352
353
354
355
356
357
358
359
360
361
362
363
364
365
366
367
368
369
370
```
| ```
def exa_get_contents_tool(
    api_key: str | None = None,
    *,
    client: AsyncExa | None = None,
) -> Tool[Any]:
    """Creates an Exa get contents tool.

    Args:
        api_key: The Exa API key. Required if `client` is not provided.

            You can get one by signing up at [https://dashboard.exa.ai](https://dashboard.exa.ai).
        client: An existing AsyncExa client. If provided, `api_key` is ignored.
            This is useful for sharing a client across multiple tools.
    """
    if client is None:
        if api_key is None:
            raise ValueError('Either api_key or client must be provided')
        client = AsyncExa(api_key=api_key)
    return Tool[Any](
        ExaGetContentsTool(client=client).__call__,
        name='exa_get_contents',
        description='Gets the full text content of specified URLs. Useful for reading articles, documentation, or any web page when you have the exact URL.',
    )

```

---|---
###  exa_answer_tool
```
exa_answer_tool(api_key: str[](https://docs.python.org/3/library/stdtypes.html#str)) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

```
exa_answer_tool(*, client: AsyncExa) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

```
exa_answer_tool(
    api_key: str[](https://docs.python.org/3/library/stdtypes.html#str) | None = None,
    *,
    client: AsyncExa | None = None
) -> Tool[](https://ai.pydantic.dev/api/tools/#pydantic_ai.tools.Tool "Tool



      dataclass
   \(pydantic_ai.tools.Tool\)")[Any[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Any "typing_extensions.Any")]

```

Creates an Exa answer tool.
Parameters:
Name | Type | Description | Default
---|---|---|---
`api_key` |  `str[](https://docs.python.org/3/library/stdtypes.html#str) | None` |  The Exa API key. Required if `client` is not provided. You can get one by signing up at <https://dashboard.exa.ai>. |  `None`
`client` |  `AsyncExa | None` |  An existing AsyncExa client. If provided, `api_key` is ignored. This is useful for sharing a client across multiple tools. |  `None`
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
381
382
383
384
385
386
387
388
389
390
391
392
393
394
395
396
397
398
399
400
401
402
403
```
| ```
def exa_answer_tool(
    api_key: str | None = None,
    *,
    client: AsyncExa | None = None,
) -> Tool[Any]:
    """Creates an Exa answer tool.

    Args:
        api_key: The Exa API key. Required if `client` is not provided.

            You can get one by signing up at [https://dashboard.exa.ai](https://dashboard.exa.ai).
        client: An existing AsyncExa client. If provided, `api_key` is ignored.
            This is useful for sharing a client across multiple tools.
    """
    if client is None:
        if api_key is None:
            raise ValueError('Either api_key or client must be provided')
        client = AsyncExa(api_key=api_key)
    return Tool[Any](
        ExaAnswerTool(client=client).__call__,
        name='exa_answer',
        description='Generates an AI-powered answer to a question with citations from web sources. Returns a comprehensive answer backed by real sources.',
    )

```

---|---
###  ExaToolset
Bases: `FunctionToolset[](https://ai.pydantic.dev/api/toolsets/#pydantic_ai.toolsets.FunctionToolset "FunctionToolset \(pydantic_ai.FunctionToolset\)")`
A toolset that provides Exa search tools with a shared client.
This is more efficient than creating individual tools when using multiple Exa tools, as it shares a single API client across all tools.
Example:
```
from pydantic_ai import Agent
from pydantic_ai.common_tools.exa import ExaToolset

toolset = ExaToolset(api_key='your-api-key')
agent = Agent('openai:gpt-5.2', toolsets=[toolset])

```

Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
406
407
408
409
410
411
412
413
414
415
416
417
418
419
420
421
422
423
424
425
426
427
428
429
430
431
432
433
434
435
436
437
438
439
440
441
442
443
444
445
446
447
448
449
450
451
452
453
454
455
456
457
458
459
460
461
462
463
464
```
| ```
class ExaToolset(FunctionToolset):
    """A toolset that provides Exa search tools with a shared client.

    This is more efficient than creating individual tools when using multiple
    Exa tools, as it shares a single API client across all tools.

    Example:
```python
    from pydantic_ai import Agent
    from pydantic_ai.common_tools.exa import ExaToolset

    toolset = ExaToolset(api_key='your-api-key')
    agent = Agent('openai:gpt-5.2', toolsets=[toolset])
```
    """

    def __init__(
        self,
        api_key: str,
        *,
        num_results: int = 5,
        max_characters: int | None = None,
        include_search: bool = True,
        include_find_similar: bool = True,
        include_get_contents: bool = True,
        include_answer: bool = True,
        id: str | None = None,
    ):
        """Creates an Exa toolset with a shared client.

        Args:
            api_key: The Exa API key.

                You can get one by signing up at [https://dashboard.exa.ai](https://dashboard.exa.ai).
            num_results: The number of results to return for search and find_similar. Defaults to 5.
            max_characters: Maximum characters of text content per result. Use this to limit
                token usage. Defaults to None (no limit).
            include_search: Whether to include the search tool. Defaults to True.
            include_find_similar: Whether to include the find_similar tool. Defaults to True.
            include_get_contents: Whether to include the get_contents tool. Defaults to True.
            include_answer: Whether to include the answer tool. Defaults to True.
            id: Optional ID for the toolset, used for durable execution environments.
        """
        client = AsyncExa(api_key=api_key)
        tools: list[Tool[Any]] = []

        if include_search:
            tools.append(exa_search_tool(client=client, num_results=num_results, max_characters=max_characters))

        if include_find_similar:
            tools.append(exa_find_similar_tool(client=client, num_results=num_results))

        if include_get_contents:
            tools.append(exa_get_contents_tool(client=client))

        if include_answer:
            tools.append(exa_answer_tool(client=client))

        super().__init__(tools, id=id)

```

---|---
####  __init__
```
__init__(
    api_key: str[](https://docs.python.org/3/library/stdtypes.html#str),
    *,
    num_results: int[](https://docs.python.org/3/library/functions.html#int) = 5,
    max_characters: int[](https://docs.python.org/3/library/functions.html#int) | None = None,
    include_search: bool[](https://docs.python.org/3/library/functions.html#bool) = True,
    include_find_similar: bool[](https://docs.python.org/3/library/functions.html#bool) = True,
    include_get_contents: bool[](https://docs.python.org/3/library/functions.html#bool) = True,
    include_answer: bool[](https://docs.python.org/3/library/functions.html#bool) = True,
    id: str[](https://docs.python.org/3/library/stdtypes.html#str) | None = None
)

```

Creates an Exa toolset with a shared client.
Parameters:
Name | Type | Description | Default
---|---|---|---
`api_key` |  `str[](https://docs.python.org/3/library/stdtypes.html#str)` |  The Exa API key. You can get one by signing up at <https://dashboard.exa.ai>. |  _required_
`num_results` |  `int[](https://docs.python.org/3/library/functions.html#int)` |  The number of results to return for search and find_similar. Defaults to 5. |  `5`
`max_characters` |  `int[](https://docs.python.org/3/library/functions.html#int) | None` |  Maximum characters of text content per result. Use this to limit token usage. Defaults to None (no limit). |  `None`
`include_search` |  `bool[](https://docs.python.org/3/library/functions.html#bool)` |  Whether to include the search tool. Defaults to True. |  `True`
`include_find_similar` |  `bool[](https://docs.python.org/3/library/functions.html#bool)` |  Whether to include the find_similar tool. Defaults to True. |  `True`
`include_get_contents` |  `bool[](https://docs.python.org/3/library/functions.html#bool)` |  Whether to include the get_contents tool. Defaults to True. |  `True`
`include_answer` |  `bool[](https://docs.python.org/3/library/functions.html#bool)` |  Whether to include the answer tool. Defaults to True. |  `True`
`id` |  `str[](https://docs.python.org/3/library/stdtypes.html#str) | None` |  Optional ID for the toolset, used for durable execution environments. |  `None`
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/exa.py`
```
422
423
424
425
426
427
428
429
430
431
432
433
434
435
436
437
438
439
440
441
442
443
444
445
446
447
448
449
450
451
452
453
454
455
456
457
458
459
460
461
462
463
464
```
| ```
def __init__(
    self,
    api_key: str,
    *,
    num_results: int = 5,
    max_characters: int | None = None,
    include_search: bool = True,
    include_find_similar: bool = True,
    include_get_contents: bool = True,
    include_answer: bool = True,
    id: str | None = None,
):
    """Creates an Exa toolset with a shared client.

    Args:
        api_key: The Exa API key.

            You can get one by signing up at [https://dashboard.exa.ai](https://dashboard.exa.ai).
        num_results: The number of results to return for search and find_similar. Defaults to 5.
        max_characters: Maximum characters of text content per result. Use this to limit
            token usage. Defaults to None (no limit).
        include_search: Whether to include the search tool. Defaults to True.
        include_find_similar: Whether to include the find_similar tool. Defaults to True.
        include_get_contents: Whether to include the get_contents tool. Defaults to True.
        include_answer: Whether to include the answer tool. Defaults to True.
        id: Optional ID for the toolset, used for durable execution environments.
    """
    client = AsyncExa(api_key=api_key)
    tools: list[Tool[Any]] = []

    if include_search:
        tools.append(exa_search_tool(client=client, num_results=num_results, max_characters=max_characters))

    if include_find_similar:
        tools.append(exa_find_similar_tool(client=client, num_results=num_results))

    if include_get_contents:
        tools.append(exa_get_contents_tool(client=client))

    if include_answer:
        tools.append(exa_answer_tool(client=client))

    super().__init__(tools, id=id)

```

---|---
###  TavilySearchResult
Bases: `TypedDict[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.TypedDict "typing_extensions.TypedDict")`
A Tavily search result.
See [Tavily Search Endpoint documentation](https://docs.tavily.com/api-reference/endpoint/search) for more information.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/tavily.py`
```
20
21
22
23
24
25
26
27
28
29
30
31
32
33
34
```
| ```
class TavilySearchResult(TypedDict):
    """A Tavily search result.

    See [Tavily Search Endpoint documentation](https://docs.tavily.com/api-reference/endpoint/search)
    for more information.
    """

    title: str
    """The title of the search result."""
    url: str
    """The URL of the search result.."""
    content: str
    """A short description of the search result."""
    score: float
    """The relevance score of the search result."""

```

---|---
####  title `instance-attribute`
```
title: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The title of the search result.
####  url `instance-attribute`
```
url: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

The URL of the search result..
####  content `instance-attribute`
```
content: str[](https://docs.python.org/3/library/stdtypes.html#str)

```

A short description of the search result.
####  score `instance-attribute`
```
score: float[](https://docs.python.org/3/library/functions.html#float)

```

The relevance score of the search result.
###  TavilySearchTool `dataclass`
The Tavily search tool.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/tavily.py`
```
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
```
| ```
@dataclass
class TavilySearchTool:
    """The Tavily search tool."""

    client: AsyncTavilyClient
    """The Tavily search client."""

    async def __call__(
        self,
        query: str,
        search_deep: Literal['basic', 'advanced'] = 'basic',
        topic: Literal['general', 'news'] = 'general',
        time_range: Literal['day', 'week', 'month', 'year', 'd', 'w', 'm', 'y'] | None = None,
    ) -> list[TavilySearchResult]:
        """Searches Tavily for the given query and returns the results.

        Args:
            query: The search query to execute with Tavily.
            search_deep: The depth of the search.
            topic: The category of the search.
            time_range: The time range back from the current date to filter results.

        Returns:
            A list of search results from Tavily.
        """
        results = await self.client.search(query, search_depth=search_deep, topic=topic, time_range=time_range)  # type: ignore[reportUnknownMemberType]
        return tavily_search_ta.validate_python(results['results'])

```

---|---
####  client `instance-attribute`
```
client: AsyncTavilyClient

```

The Tavily search client.
####  __call__ `async`
```
__call__(
    query: str[](https://docs.python.org/3/library/stdtypes.html#str),
    search_deep: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["basic", "advanced"] = "basic",
    topic: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")["general", "news"] = "general",
    time_range: (
        Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[
            "day",
            "week",
            "month",
            "year",
            "d",
            "w",
            "m",
            "y",
        ]
        | None
    ) = None,
) -> list[](https://docs.python.org/3/library/stdtypes.html#list)[TavilySearchResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult "TavilySearchResult \(pydantic_ai.common_tools.tavily.TavilySearchResult\)")]

```

Searches Tavily for the given query and returns the results.
Parameters:
Name | Type | Description | Default
---|---|---|---
`query` |  `str[](https://docs.python.org/3/library/stdtypes.html#str)` |  The search query to execute with Tavily. |  _required_
`search_deep` |  `Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['basic', 'advanced']` |  The depth of the search. |  `'basic'`
`topic` |  `Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['general', 'news']` |  The category of the search. |  `'general'`
`time_range` |  `Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")['day', 'week', 'month', 'year', 'd', 'w', 'm', 'y'] | None` |  The time range back from the current date to filter results. |  `None`
Returns:
Type | Description
---|---
`list[](https://docs.python.org/3/library/stdtypes.html#list)[TavilySearchResult[](https://ai.pydantic.dev/api/common_tools/#pydantic_ai.common_tools.tavily.TavilySearchResult "TavilySearchResult \(pydantic_ai.common_tools.tavily.TavilySearchResult\)")]` |  A list of search results from Tavily.
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/tavily.py`
```
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
```
| ```
async def __call__(
    self,
    query: str,
    search_deep: Literal['basic', 'advanced'] = 'basic',
    topic: Literal['general', 'news'] = 'general',
    time_range: Literal['day', 'week', 'month', 'year', 'd', 'w', 'm', 'y'] | None = None,
) -> list[TavilySearchResult]:
    """Searches Tavily for the given query and returns the results.

    Args:
        query: The search query to execute with Tavily.
        search_deep: The depth of the search.
        topic: The category of the search.
        time_range: The time range back from the current date to filter results.

    Returns:
        A list of search results from Tavily.
    """
    results = await self.client.search(query, search_depth=search_deep, topic=topic, time_range=time_range)  # type: ignore[reportUnknownMemberType]
    return tavily_search_ta.validate_python(results['results'])

```

---|---
###  tavily_search_tool
```
tavily_search_tool(api_key: str[](https://docs.python.org/3/library/stdtypes.html#str))

```

Creates a Tavily search tool.
Parameters:
Name | Type | Description | Default
---|---|---|---
`api_key` |  `str[](https://docs.python.org/3/library/stdtypes.html#str)` |  The Tavily API key. You can get one by signing up at <https://app.tavily.com/home>. |  _required_
Source code in `pydantic_ai_slim/pydantic_ai/common_tools/tavily.py`
```
69
70
71
72
73
74
75
76
77
78
79
80
81
```
| ```
def tavily_search_tool(api_key: str):
    """Creates a Tavily search tool.

    Args:
        api_key: The Tavily API key.

            You can get one by signing up at [https://app.tavily.com/home](https://app.tavily.com/home).
    """
    return Tool[Any](
        TavilySearchTool(client=AsyncTavilyClient(api_key)).__call__,
        name='tavily_search',
        description='Searches Tavily for the given query and returns the results.',
    )

```

---|---
© Pydantic Services Inc. 2024 to present
