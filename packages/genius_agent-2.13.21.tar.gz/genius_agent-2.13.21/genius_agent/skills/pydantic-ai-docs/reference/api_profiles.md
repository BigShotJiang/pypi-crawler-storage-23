[ Skip to content ](https://ai.pydantic.dev/api/profiles/#pydantic_aiprofiles)
**Join us at the inaugural PyAI Conf in San Francisco on March 10th![Learn More](https://pyai.events/?utm_source=pydantic-ai) **
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI")
Pydantic AI
pydantic_ai.profiles
Type to start searching
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
[ ![logo](https://ai.pydantic.dev/img/logo-white.svg) ](https://ai.pydantic.dev/ "Pydantic AI") Pydantic AI
[ pydantic/pydantic-ai
  * v1.63.0
  * 15.1k
  * 1.7k

](https://github.com/pydantic/pydantic-ai "Go to repository")
  * [ Pydantic AI  ](https://ai.pydantic.dev/)
  * [ Installation  ](https://ai.pydantic.dev/install/)
  * [ Getting Help  ](https://ai.pydantic.dev/help/)
  * [ Troubleshooting  ](https://ai.pydantic.dev/troubleshooting/)
  * [ Pydantic AI Gateway  ](https://ai.pydantic.dev/gateway/)
  * Documentation
    * Core Concepts
      * [ Agents  ](https://ai.pydantic.dev/agent/)
      * [ Dependencies  ](https://ai.pydantic.dev/dependencies/)
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Output  ](https://ai.pydantic.dev/output/)
      * [ Messages and chat history  ](https://ai.pydantic.dev/message-history/)
      * [ Direct Model Requests  ](https://ai.pydantic.dev/direct/)
    * Models & Providers
      * [ Overview  ](https://ai.pydantic.dev/models/overview/)
      * [ OpenAI  ](https://ai.pydantic.dev/models/openai/)
      * [ Anthropic  ](https://ai.pydantic.dev/models/anthropic/)
      * [ Google  ](https://ai.pydantic.dev/models/google/)
      * [ xAI  ](https://ai.pydantic.dev/models/xai/)
      * [ Bedrock  ](https://ai.pydantic.dev/models/bedrock/)
      * [ Cerebras  ](https://ai.pydantic.dev/models/cerebras/)
      * [ Cohere  ](https://ai.pydantic.dev/models/cohere/)
      * [ Groq  ](https://ai.pydantic.dev/models/groq/)
      * [ Hugging Face  ](https://ai.pydantic.dev/models/huggingface/)
      * [ Mistral  ](https://ai.pydantic.dev/models/mistral/)
      * [ OpenRouter  ](https://ai.pydantic.dev/models/openrouter/)
      * [ Outlines  ](https://ai.pydantic.dev/models/outlines/)
    * Tools & Toolsets
      * [ Function Tools  ](https://ai.pydantic.dev/tools/)
      * [ Advanced Tool Features  ](https://ai.pydantic.dev/tools-advanced/)
      * [ Toolsets  ](https://ai.pydantic.dev/toolsets/)
      * [ Deferred Tools  ](https://ai.pydantic.dev/deferred-tools/)
      * [ Built-in Tools  ](https://ai.pydantic.dev/builtin-tools/)
      * [ Common Tools  ](https://ai.pydantic.dev/common-tools/)
      * [ Third-Party Tools  ](https://ai.pydantic.dev/third-party-tools/)
    * Advanced Features
      * [ Image, Audio, Video & Document Input  ](https://ai.pydantic.dev/input/)
      * [ Thinking  ](https://ai.pydantic.dev/thinking/)
      * [ HTTP Request Retries  ](https://ai.pydantic.dev/retries/)
    * MCP
      * [ Overview  ](https://ai.pydantic.dev/mcp/overview/)
      * [ Client  ](https://ai.pydantic.dev/mcp/client/)
      * [ FastMCP Client  ](https://ai.pydantic.dev/mcp/fastmcp-client/)
      * [ Server  ](https://ai.pydantic.dev/mcp/server/)
    * [ Multi-Agent Patterns  ](https://ai.pydantic.dev/multi-agent-applications/)
    * [ Web Chat UI  ](https://ai.pydantic.dev/web/)
    * [ Embeddings  ](https://ai.pydantic.dev/embeddings/)
    * [ Testing  ](https://ai.pydantic.dev/testing/)
  * Pydantic Evals
    * [ Overview  ](https://ai.pydantic.dev/evals/)
    * Getting Started
      * [ Quick Start  ](https://ai.pydantic.dev/evals/quick-start/)
      * [ Core Concepts  ](https://ai.pydantic.dev/evals/core-concepts/)
    * Evaluators
      * [ Overview  ](https://ai.pydantic.dev/evals/evaluators/overview/)
      * [ Built-in Evaluators  ](https://ai.pydantic.dev/evals/evaluators/built-in/)
      * [ LLM Judge  ](https://ai.pydantic.dev/evals/evaluators/llm-judge/)
      * [ Custom Evaluators  ](https://ai.pydantic.dev/evals/evaluators/custom/)
      * [ Report Evaluators  ](https://ai.pydantic.dev/evals/evaluators/report-evaluators/)
      * [ Span-Based  ](https://ai.pydantic.dev/evals/evaluators/span-based/)
    * How-To Guides
      * [ Logfire Integration  ](https://ai.pydantic.dev/evals/how-to/logfire-integration/)
      * [ Dataset Management  ](https://ai.pydantic.dev/evals/how-to/dataset-management/)
      * [ Dataset Serialization  ](https://ai.pydantic.dev/evals/how-to/dataset-serialization/)
      * [ Concurrency & Performance  ](https://ai.pydantic.dev/evals/how-to/concurrency/)
      * [ Multi-Run Evaluation  ](https://ai.pydantic.dev/evals/how-to/multi-run/)
      * [ Retry Strategies  ](https://ai.pydantic.dev/evals/how-to/retry-strategies/)
      * [ Metrics & Attributes  ](https://ai.pydantic.dev/evals/how-to/metrics-attributes/)
    * Examples
      * [ Simple Validation  ](https://ai.pydantic.dev/evals/examples/simple-validation/)
  * Pydantic Graph
    * [ Overview  ](https://ai.pydantic.dev/graph/)
    * [ Beta API  ](https://ai.pydantic.dev/graph/beta/)
      * [ Steps  ](https://ai.pydantic.dev/graph/beta/steps/)
      * [ Joins & Reducers  ](https://ai.pydantic.dev/graph/beta/joins/)
      * [ Decisions  ](https://ai.pydantic.dev/graph/beta/decisions/)
      * [ Parallel Execution  ](https://ai.pydantic.dev/graph/beta/parallel/)
  * Integrations
    * [ Debugging & Monitoring with Pydantic Logfire  ](https://ai.pydantic.dev/logfire/)
    * Durable Execution
      * [ Overview  ](https://ai.pydantic.dev/durable_execution/overview/)
      * [ Temporal  ](https://ai.pydantic.dev/durable_execution/temporal/)
      * [ DBOS  ](https://ai.pydantic.dev/durable_execution/dbos/)
      * [ Prefect  ](https://ai.pydantic.dev/durable_execution/prefect/)
    * UI Event Streams
      * [ Overview  ](https://ai.pydantic.dev/ui/overview/)
      * [ AG-UI  ](https://ai.pydantic.dev/ui/ag-ui/)
      * [ Vercel AI  ](https://ai.pydantic.dev/ui/vercel-ai/)
    * [ Agent2Agent (A2A)  ](https://ai.pydantic.dev/a2a/)
  * Related Packages
    * [ clai  ](https://ai.pydantic.dev/cli/)
  * Examples
    * [ Setup  ](https://ai.pydantic.dev/examples/setup/)
    * Getting Started
      * [ Pydantic Model  ](https://ai.pydantic.dev/examples/pydantic-model/)
      * [ Weather agent  ](https://ai.pydantic.dev/examples/weather-agent/)
    * Conversational Agents
      * [ Chat App with FastAPI  ](https://ai.pydantic.dev/examples/chat-app/)
      * [ Bank support  ](https://ai.pydantic.dev/examples/bank-support/)
    * Data & Analytics
      * [ SQL Generation  ](https://ai.pydantic.dev/examples/sql-gen/)
      * [ Data Analyst  ](https://ai.pydantic.dev/examples/data-analyst/)
      * [ RAG  ](https://ai.pydantic.dev/examples/rag/)
    * Streaming
      * [ Stream markdown  ](https://ai.pydantic.dev/examples/stream-markdown/)
      * [ Stream whales  ](https://ai.pydantic.dev/examples/stream-whales/)
    * Complex Workflows
      * [ Flight booking  ](https://ai.pydantic.dev/examples/flight-booking/)
      * [ Question Graph  ](https://ai.pydantic.dev/examples/question-graph/)
    * Business Applications
      * [ Slack Lead Qualifier with Modal  ](https://ai.pydantic.dev/examples/slack-lead-qualifier/)
    * UI Examples
      * [ Agent User Interaction (AG-UI)  ](https://ai.pydantic.dev/examples/ag-ui/)
  * API Reference
    * pydantic_ai
      * [ pydantic_ai.ag_ui  ](https://ai.pydantic.dev/api/ag_ui/)
      * [ pydantic_ai.agent  ](https://ai.pydantic.dev/api/agent/)
      * [ pydantic_ai.builtin_tools  ](https://ai.pydantic.dev/api/builtin_tools/)
      * [ pydantic_ai.common_tools  ](https://ai.pydantic.dev/api/common_tools/)
      * [ pydantic_ai — Concurrency  ](https://ai.pydantic.dev/api/concurrency/)
      * [ pydantic_ai.direct  ](https://ai.pydantic.dev/api/direct/)
      * [ pydantic_ai.durable_exec  ](https://ai.pydantic.dev/api/durable_exec/)
      * [ pydantic_ai.embeddings  ](https://ai.pydantic.dev/api/embeddings/)
      * [ pydantic_ai.exceptions  ](https://ai.pydantic.dev/api/exceptions/)
      * [ pydantic_ai.ext  ](https://ai.pydantic.dev/api/ext/)
      * [ pydantic_ai.format_prompt  ](https://ai.pydantic.dev/api/format_prompt/)
      * [ pydantic_ai.mcp  ](https://ai.pydantic.dev/api/mcp/)
      * [ pydantic_ai.messages  ](https://ai.pydantic.dev/api/messages/)
      * [ pydantic_ai.models.anthropic  ](https://ai.pydantic.dev/api/models/anthropic/)
      * [ pydantic_ai.models  ](https://ai.pydantic.dev/api/models/base/)
      * [ pydantic_ai.models.bedrock  ](https://ai.pydantic.dev/api/models/bedrock/)
      * [ pydantic_ai.models.cerebras  ](https://ai.pydantic.dev/api/models/cerebras/)
      * [ pydantic_ai.models.cohere  ](https://ai.pydantic.dev/api/models/cohere/)
      * [ pydantic_ai.models.fallback  ](https://ai.pydantic.dev/api/models/fallback/)
      * [ pydantic_ai.models.function  ](https://ai.pydantic.dev/api/models/function/)
      * [ pydantic_ai.models.google  ](https://ai.pydantic.dev/api/models/google/)
      * [ pydantic_ai.models.xai  ](https://ai.pydantic.dev/api/models/xai/)
      * [ pydantic_ai.models.groq  ](https://ai.pydantic.dev/api/models/groq/)
      * [ pydantic_ai.models.huggingface  ](https://ai.pydantic.dev/api/models/huggingface/)
      * [ pydantic_ai.models.instrumented  ](https://ai.pydantic.dev/api/models/instrumented/)
      * [ pydantic_ai.models.mcp_sampling  ](https://ai.pydantic.dev/api/models/mcp-sampling/)
      * [ pydantic_ai.models.mistral  ](https://ai.pydantic.dev/api/models/mistral/)
      * [ pydantic_ai.models.openai  ](https://ai.pydantic.dev/api/models/openai/)
      * [ pydantic_ai.models.openrouter  ](https://ai.pydantic.dev/api/models/openrouter/)
      * [ pydantic_ai.models.outlines  ](https://ai.pydantic.dev/api/models/outlines/)
      * [ pydantic_ai.models.test  ](https://ai.pydantic.dev/api/models/test/)
      * [ pydantic_ai.models.wrapper  ](https://ai.pydantic.dev/api/models/wrapper/)
      * [ pydantic_ai.output  ](https://ai.pydantic.dev/api/output/)
      * pydantic_ai.profiles  [ pydantic_ai.profiles  ](https://ai.pydantic.dev/api/profiles/)
        * [ ModelProfile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile)
        * [ supports_tools  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.supports_tools)
        * [ supports_json_schema_output  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.supports_json_schema_output)
        * [ supports_json_object_output  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.supports_json_object_output)
        * [ supports_image_output  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.supports_image_output)
        * [ default_structured_output_mode  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.default_structured_output_mode)
        * [ prompted_output_template  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.prompted_output_template)
        * [ native_output_requires_schema_in_instructions  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.native_output_requires_schema_in_instructions)
        * [ json_schema_transformer  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.json_schema_transformer)
        * [ thinking_tags  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.thinking_tags)
        * [ ignore_streamed_leading_whitespace  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.ignore_streamed_leading_whitespace)
        * [ supported_builtin_tools  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.supported_builtin_tools)
        * [ from_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.from_profile)
        * [ update  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.update)
        * [ openai  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai)
        * [ SAMPLING_PARAMS  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.SAMPLING_PARAMS)
        * [ OpenAIModelProfile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile)
          * [ openai_chat_thinking_field  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_chat_thinking_field)
          * [ openai_chat_send_back_thinking_parts  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_chat_send_back_thinking_parts)
          * [ openai_supports_strict_tool_definition  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_strict_tool_definition)
          * [ openai_supports_sampling_settings  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_sampling_settings)
          * [ openai_unsupported_model_settings  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_unsupported_model_settings)
          * [ openai_supports_tool_choice_required  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_tool_choice_required)
          * [ openai_system_prompt_role  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_system_prompt_role)
          * [ openai_chat_supports_web_search  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_chat_supports_web_search)
          * [ openai_chat_audio_input_encoding  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_chat_audio_input_encoding)
          * [ openai_chat_supports_file_urls  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_chat_supports_file_urls)
          * [ openai_supports_encrypted_reasoning_content  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_encrypted_reasoning_content)
          * [ openai_supports_reasoning  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_reasoning)
          * [ openai_supports_reasoning_effort_none  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_reasoning_effort_none)
          * [ openai_responses_requires_function_call_status_none  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_responses_requires_function_call_status_none)
        * [ openai_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.openai_model_profile)
        * [ OpenAIJsonSchemaTransformer  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIJsonSchemaTransformer)
        * [ anthropic  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.anthropic)
        * [ anthropic_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.anthropic.anthropic_model_profile)
        * [ google  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.google)
        * [ GoogleModelProfile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.google.GoogleModelProfile)
          * [ google_supports_native_output_with_builtin_tools  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.google.GoogleModelProfile.google_supports_native_output_with_builtin_tools)
        * [ google_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.google.google_model_profile)
        * [ GoogleJsonSchemaTransformer  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.google.GoogleJsonSchemaTransformer)
        * [ meta  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.meta)
        * [ meta_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.meta.meta_model_profile)
        * [ amazon  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.amazon)
        * [ amazon_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.amazon.amazon_model_profile)
        * [ deepseek  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.deepseek)
        * [ deepseek_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.deepseek.deepseek_model_profile)
        * [ grok  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.grok)
        * [ GrokModelProfile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.grok.GrokModelProfile)
          * [ grok_supports_builtin_tools  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.grok.GrokModelProfile.grok_supports_builtin_tools)
          * [ grok_supports_tool_choice_required  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.grok.GrokModelProfile.grok_supports_tool_choice_required)
        * [ grok_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.grok.grok_model_profile)
        * [ mistral  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.mistral)
        * [ mistral_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.mistral.mistral_model_profile)
        * [ qwen  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.qwen)
        * [ qwen_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.qwen.qwen_model_profile)
      * [ pydantic_ai.providers  ](https://ai.pydantic.dev/api/providers/)
      * [ pydantic_ai.result  ](https://ai.pydantic.dev/api/result/)
      * [ pydantic_ai.retries  ](https://ai.pydantic.dev/api/retries/)
      * [ pydantic_ai.run  ](https://ai.pydantic.dev/api/run/)
      * [ pydantic_ai.settings  ](https://ai.pydantic.dev/api/settings/)
      * [ pydantic_ai.tools  ](https://ai.pydantic.dev/api/tools/)
      * [ pydantic_ai.toolsets  ](https://ai.pydantic.dev/api/toolsets/)
      * [ pydantic_ai.ui.ag_ui  ](https://ai.pydantic.dev/api/ui/ag_ui/)
      * [ pydantic_ai.ui  ](https://ai.pydantic.dev/api/ui/base/)
      * [ pydantic_ai.ui.vercel_ai  ](https://ai.pydantic.dev/api/ui/vercel_ai/)
      * [ pydantic_ai.usage  ](https://ai.pydantic.dev/api/usage/)
    * pydantic_evals
      * [ pydantic_evals.dataset  ](https://ai.pydantic.dev/api/pydantic_evals/dataset/)
      * [ pydantic_evals.evaluators  ](https://ai.pydantic.dev/api/pydantic_evals/evaluators/)
      * [ pydantic_evals.reporting  ](https://ai.pydantic.dev/api/pydantic_evals/reporting/)
      * [ pydantic_evals.otel  ](https://ai.pydantic.dev/api/pydantic_evals/otel/)
      * [ pydantic_evals.generation  ](https://ai.pydantic.dev/api/pydantic_evals/generation/)
    * pydantic_graph
      * [ pydantic_graph  ](https://ai.pydantic.dev/api/pydantic_graph/graph/)
      * [ pydantic_graph.nodes  ](https://ai.pydantic.dev/api/pydantic_graph/nodes/)
      * [ pydantic_graph.persistence  ](https://ai.pydantic.dev/api/pydantic_graph/persistence/)
      * [ pydantic_graph.mermaid  ](https://ai.pydantic.dev/api/pydantic_graph/mermaid/)
      * [ pydantic_graph.exceptions  ](https://ai.pydantic.dev/api/pydantic_graph/exceptions/)
      * Beta API
        * [ pydantic_graph.beta  ](https://ai.pydantic.dev/api/pydantic_graph/beta/)
        * [ pydantic_graph.beta.graph  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph/)
        * [ pydantic_graph.beta.graph_builder  ](https://ai.pydantic.dev/api/pydantic_graph/beta_graph_builder/)
        * [ pydantic_graph.beta.step  ](https://ai.pydantic.dev/api/pydantic_graph/beta_step/)
        * [ pydantic_graph.beta.join  ](https://ai.pydantic.dev/api/pydantic_graph/beta_join/)
        * [ pydantic_graph.beta.decision  ](https://ai.pydantic.dev/api/pydantic_graph/beta_decision/)
        * [ pydantic_graph.beta.node  ](https://ai.pydantic.dev/api/pydantic_graph/beta_node/)
    * fasta2a
      * [ fasta2a  ](https://ai.pydantic.dev/api/fasta2a/)
  * Project
    * [ Contributing  ](https://ai.pydantic.dev/contributing/)
    * [ Upgrade Guide  ](https://ai.pydantic.dev/changelog/)
    * [ Version policy  ](https://ai.pydantic.dev/version-policy/)


  * [ ModelProfile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile)
  * [ supports_tools  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.supports_tools)
  * [ supports_json_schema_output  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.supports_json_schema_output)
  * [ supports_json_object_output  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.supports_json_object_output)
  * [ supports_image_output  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.supports_image_output)
  * [ default_structured_output_mode  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.default_structured_output_mode)
  * [ prompted_output_template  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.prompted_output_template)
  * [ native_output_requires_schema_in_instructions  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.native_output_requires_schema_in_instructions "native_output_requires_schema_in_instructions")
  * [ json_schema_transformer  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.json_schema_transformer)
  * [ thinking_tags  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.thinking_tags)
  * [ ignore_streamed_leading_whitespace  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.ignore_streamed_leading_whitespace "ignore_streamed_leading_whitespace")
  * [ supported_builtin_tools  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.supported_builtin_tools)
  * [ from_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.from_profile)
  * [ update  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile.update)
  * [ openai  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai)
  * [ SAMPLING_PARAMS  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.SAMPLING_PARAMS)
  * [ OpenAIModelProfile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile)
    * [ openai_chat_thinking_field  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_chat_thinking_field)
    * [ openai_chat_send_back_thinking_parts  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_chat_send_back_thinking_parts)
    * [ openai_supports_strict_tool_definition  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_strict_tool_definition)
    * [ openai_supports_sampling_settings  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_sampling_settings)
    * [ openai_unsupported_model_settings  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_unsupported_model_settings)
    * [ openai_supports_tool_choice_required  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_tool_choice_required)
    * [ openai_system_prompt_role  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_system_prompt_role)
    * [ openai_chat_supports_web_search  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_chat_supports_web_search)
    * [ openai_chat_audio_input_encoding  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_chat_audio_input_encoding)
    * [ openai_chat_supports_file_urls  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_chat_supports_file_urls)
    * [ openai_supports_encrypted_reasoning_content  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_encrypted_reasoning_content)
    * [ openai_supports_reasoning  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_reasoning)
    * [ openai_supports_reasoning_effort_none  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_supports_reasoning_effort_none)
    * [ openai_responses_requires_function_call_status_none  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIModelProfile.openai_responses_requires_function_call_status_none)
  * [ openai_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.openai_model_profile)
  * [ OpenAIJsonSchemaTransformer  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.openai.OpenAIJsonSchemaTransformer)
  * [ anthropic  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.anthropic)
  * [ anthropic_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.anthropic.anthropic_model_profile)
  * [ google  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.google)
  * [ GoogleModelProfile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.google.GoogleModelProfile)
    * [ google_supports_native_output_with_builtin_tools  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.google.GoogleModelProfile.google_supports_native_output_with_builtin_tools)
  * [ google_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.google.google_model_profile)
  * [ GoogleJsonSchemaTransformer  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.google.GoogleJsonSchemaTransformer)
  * [ meta  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.meta)
  * [ meta_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.meta.meta_model_profile)
  * [ amazon  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.amazon)
  * [ amazon_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.amazon.amazon_model_profile)
  * [ deepseek  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.deepseek)
  * [ deepseek_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.deepseek.deepseek_model_profile)
  * [ grok  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.grok)
  * [ GrokModelProfile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.grok.GrokModelProfile)
    * [ grok_supports_builtin_tools  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.grok.GrokModelProfile.grok_supports_builtin_tools)
    * [ grok_supports_tool_choice_required  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.grok.GrokModelProfile.grok_supports_tool_choice_required)
  * [ grok_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.grok.grok_model_profile)
  * [ mistral  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.mistral)
  * [ mistral_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.mistral.mistral_model_profile)
  * [ qwen  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.qwen)
  * [ qwen_model_profile  ](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.qwen.qwen_model_profile)


  1. [ Pydantic AI  ](https://ai.pydantic.dev/)
  2. [ API Reference  ](https://ai.pydantic.dev/api/ag_ui/)
  3. [ pydantic_ai  ](https://ai.pydantic.dev/api/ag_ui/)


# `pydantic_ai.profiles`
Describes how requests to and responses from specific models or families of models need to be constructed and processed to get the best results, independent of the model and provider classes used.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/__init__.py`
```
22
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
76
77
78
79
80
81
82
83
84
85
86
87
88
89
90
91
92
93
94
95
96
97
```
| ```
@dataclass(kw_only=True)
class ModelProfile:
    """Describes how requests to and responses from specific models or families of models need to be constructed and processed to get the best results, independent of the model and provider classes used."""

    supports_tools: bool = True
    """Whether the model supports tools."""
    supports_json_schema_output: bool = False
    """Whether the model supports JSON schema output.

    This is also referred to as 'native' support for structured output.
    Relates to the `NativeOutput` output type.
    """
    supports_json_object_output: bool = False
    """Whether the model supports a dedicated mode to enforce JSON output, without necessarily sending a schema.

    E.g. [OpenAI's JSON mode](https://platform.openai.com/docs/guides/structured-outputs#json-mode)
    Relates to the `PromptedOutput` output type.
    """
    supports_image_output: bool = False
    """Whether the model supports image output."""
    default_structured_output_mode: StructuredOutputMode = 'tool'
    """The default structured output mode to use for the model."""
    prompted_output_template: str = dedent(
        """
        Always respond with a JSON object that's compatible with this schema:

        {schema}

        Don't include any text or Markdown fencing before or after.
        """
    )
    """The instructions template to use for prompted structured output. The '{schema}' placeholder will be replaced with the JSON schema for the output."""
    native_output_requires_schema_in_instructions: bool = False
    """Whether to add prompted output template in native structured output mode"""
    json_schema_transformer: type[JsonSchemaTransformer] | None = None
    """The transformer to use to make JSON schemas for tools and structured output compatible with the model."""

    thinking_tags: tuple[str, str] = ('<think>', '</think>')
    """The tags used to indicate thinking parts in the model's output. Defaults to ('<think>', '</think>')."""

    ignore_streamed_leading_whitespace: bool = False
    """Whether to ignore leading whitespace when streaming a response.

    This is a workaround for models that emit `<think>\n</think>\n\n` or an empty text part ahead of tool calls (e.g. Ollama + Qwen3),
    which we don't want to end up treating as a final result when using `run_stream` with `str` a valid `output_type`.

    This is currently only used by `OpenAIChatModel`, `HuggingFaceModel`, and `GroqModel`.
    """

    supported_builtin_tools: frozenset[type[AbstractBuiltinTool]] = field(
        default_factory=lambda: SUPPORTED_BUILTIN_TOOLS
    )
    """The set of builtin tool types that this model/profile supports.

    Defaults to ALL builtin tools. Profile functions should explicitly
    restrict this based on model capabilities.
    """

    @classmethod
    def from_profile(cls, profile: ModelProfile | None) -> Self:
        """Build a ModelProfile subclass instance from a ModelProfile instance."""
        if isinstance(profile, cls):
            return profile
        return cls().update(profile)

    def update(self, profile: ModelProfile | None) -> Self:
        """Update this ModelProfile (subclass) instance with the non-default values from another ModelProfile instance."""
        if not profile:
            return self
        field_names = set(f.name for f in fields(self))
        non_default_attrs = {
            f.name: getattr(profile, f.name)
            for f in fields(profile)
            if f.name in field_names and getattr(profile, f.name) != f.default
        }
        return replace(self, **non_default_attrs)

```

---|---
###  supports_tools `class-attribute` `instance-attribute`
```
supports_tools: bool[](https://docs.python.org/3/library/functions.html#bool) = True

```

Whether the model supports tools.
###  supports_json_schema_output `class-attribute` `instance-attribute`
```
supports_json_schema_output: bool[](https://docs.python.org/3/library/functions.html#bool) = False

```

Whether the model supports JSON schema output.
This is also referred to as 'native' support for structured output. Relates to the `NativeOutput` output type.
###  supports_json_object_output `class-attribute` `instance-attribute`
```
supports_json_object_output: bool[](https://docs.python.org/3/library/functions.html#bool) = False

```

Whether the model supports a dedicated mode to enforce JSON output, without necessarily sending a schema.
E.g. [OpenAI's JSON mode](https://platform.openai.com/docs/guides/structured-outputs#json-mode) Relates to the `PromptedOutput` output type.
###  supports_image_output `class-attribute` `instance-attribute`
```
supports_image_output: bool[](https://docs.python.org/3/library/functions.html#bool) = False

```

Whether the model supports image output.
###  default_structured_output_mode `class-attribute` `instance-attribute`
```
default_structured_output_mode: StructuredOutputMode = (
    "tool"
)

```

The default structured output mode to use for the model.
###  prompted_output_template `class-attribute` `instance-attribute`
```
prompted_output_template: str[](https://docs.python.org/3/library/stdtypes.html#str) = dedent[](https://docs.python.org/3/library/textwrap.html#textwrap.dedent "textwrap.dedent")(
    "\n        Always respond with a JSON object that's compatible with this schema:\n\n        {schema}\n\n        Don't include any text or Markdown fencing before or after.\n        "
)

```

The instructions template to use for prompted structured output. The '{schema}' placeholder will be replaced with the JSON schema for the output.
###  native_output_requires_schema_in_instructions `class-attribute` `instance-attribute`
```
native_output_requires_schema_in_instructions: bool[](https://docs.python.org/3/library/functions.html#bool) = False

```

Whether to add prompted output template in native structured output mode
###  json_schema_transformer `class-attribute` `instance-attribute`
```
json_schema_transformer: (
    type[](https://docs.python.org/3/library/functions.html#type)[JsonSchemaTransformer] | None
) = None

```

The transformer to use to make JSON schemas for tools and structured output compatible with the model.
###  thinking_tags `class-attribute` `instance-attribute`
```
thinking_tags: tuple[](https://docs.python.org/3/library/stdtypes.html#tuple)[str[](https://docs.python.org/3/library/stdtypes.html#str), str[](https://docs.python.org/3/library/stdtypes.html#str)] = ('<think>', '</think>')

```

The tags used to indicate thinking parts in the model's output. Defaults to ('', '').
###  ignore_streamed_leading_whitespace `class-attribute` `instance-attribute`
```
ignore_streamed_leading_whitespace: bool[](https://docs.python.org/3/library/functions.html#bool) = False

```

Whether to ignore leading whitespace when streaming a response.
```
This is a workaround for models that emit `<think>

```

`or an empty text part ahead of tool calls (e.g. Ollama + Qwen3),     which we don't want to end up treating as a final result when using`run_stream`with`str`a valid`output_type`.
```
This is currently only used by `OpenAIChatModel`, `HuggingFaceModel`, and `GroqModel`.

```

###  supported_builtin_tools `class-attribute` `instance-attribute`
```
supported_builtin_tools: frozenset[](https://docs.python.org/3/library/stdtypes.html#frozenset)[
    type[](https://docs.python.org/3/library/functions.html#type)[AbstractBuiltinTool[](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.AbstractBuiltinTool "AbstractBuiltinTool



      dataclass
   \(pydantic_ai.builtin_tools.AbstractBuiltinTool\)")]
] = field[](https://docs.python.org/3/library/dataclasses.html#dataclasses.field "dataclasses.field")(default_factory=lambda: SUPPORTED_BUILTIN_TOOLS[](https://ai.pydantic.dev/api/builtin_tools/#pydantic_ai.builtin_tools.SUPPORTED_BUILTIN_TOOLS "SUPPORTED_BUILTIN_TOOLS



      module-attribute
   \(pydantic_ai.builtin_tools.SUPPORTED_BUILTIN_TOOLS\)"))

```

The set of builtin tool types that this model/profile supports.
Defaults to ALL builtin tools. Profile functions should explicitly restrict this based on model capabilities.
###  from_profile `classmethod`
```
from_profile(profile: ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile") | None) -> Self[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Self "typing_extensions.Self")

```

Build a ModelProfile subclass instance from a ModelProfile instance.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/__init__.py`
```
80
81
82
83
84
85
```
| ```
@classmethod
def from_profile(cls, profile: ModelProfile | None) -> Self:
    """Build a ModelProfile subclass instance from a ModelProfile instance."""
    if isinstance(profile, cls):
        return profile
    return cls().update(profile)

```

---|---
###  update
```
update(profile: ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile") | None) -> Self[](https://typing-extensions.readthedocs.io/en/latest/index.html#typing_extensions.Self "typing_extensions.Self")

```

Update this ModelProfile (subclass) instance with the non-default values from another ModelProfile instance.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/__init__.py`
```
87
88
89
90
91
92
93
94
95
96
97
```
| ```
def update(self, profile: ModelProfile | None) -> Self:
    """Update this ModelProfile (subclass) instance with the non-default values from another ModelProfile instance."""
    if not profile:
        return self
    field_names = set(f.name for f in fields(self))
    non_default_attrs = {
        f.name: getattr(profile, f.name)
        for f in fields(profile)
        if f.name in field_names and getattr(profile, f.name) != f.default
    }
    return replace(self, **non_default_attrs)

```

---|---
###  SAMPLING_PARAMS `module-attribute`
```
SAMPLING_PARAMS = (
    "temperature",
    "top_p",
    "presence_penalty",
    "frequency_penalty",
    "logit_bias",
    "openai_logprobs",
    "openai_top_logprobs",
)

```

Sampling parameter names that are incompatible with reasoning.
These parameters are not supported when reasoning is enabled (reasoning_effort != 'none'). See https://platform.openai.com/docs/guides/reasoning for details.
###  OpenAIModelProfile `dataclass`
Bases: `ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile")`
Profile for models used with `OpenAIChatModel`.
ALL FIELDS MUST BE `openai_` PREFIXED SO YOU CAN MERGE THEM WITH OTHER MODELS.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/openai.py`
```
 31
 32
 33
 34
 35
 36
 37
 38
 39
 40
 41
 42
 43
 44
 45
 46
 47
 48
 49
 50
 51
 52
 53
 54
 55
 56
 57
 58
 59
 60
 61
 62
 63
 64
 65
 66
 67
 68
 69
 70
 71
 72
 73
 74
 75
 76
 77
 78
 79
 80
 81
 82
 83
 84
 85
 86
 87
 88
 89
 90
 91
 92
 93
 94
 95
 96
 97
 98
 99
100
101
102
103
104
105
106
107
108
109
110
111
112
113
114
115
116
117
118
119
120
121
122
123
124
125
126
127
128
129
130
131
132
```
| ```
@dataclass(kw_only=True)
class OpenAIModelProfile(ModelProfile):
    """Profile for models used with `OpenAIChatModel`.

    ALL FIELDS MUST BE `openai_` PREFIXED SO YOU CAN MERGE THEM WITH OTHER MODELS.
    """

    openai_chat_thinking_field: str | None = None
    """Non-standard field name used by some providers for model thinking content in Chat Completions API responses.

    Plenty of providers use custom field names for thinking content. Ollama and newer versions of vLLM use `reasoning`,
    while DeepSeek, older vLLM and some others use `reasoning_content`.

    Notice that the thinking field configured here is currently limited to `str` type content.

    If `openai_chat_send_back_thinking_parts` is set to `'field'`, this field must be set to a non-None value."""

    openai_chat_send_back_thinking_parts: Literal['auto', 'tags', 'field', False] = 'auto'
    """Whether the model includes thinking content in requests.

    This can be:
    * `'auto'` (default): Automatically detects how to send thinking content. If thinking was received in a custom field
    (tracked via `ThinkingPart.id` and `ThinkingPart.provider_name`), it's sent back in that same field. Otherwise,
    it's sent using tags. Only the `reasoning` and `reasoning_content` fields are checked by
    default when receiving responses. If your provider uses a different field name, you must explicitly set
    `openai_chat_thinking_field` to that field name.
    * `'tags'`: The thinking content is included in the main `content` field, enclosed within thinking tags as
    specified in `thinking_tags` profile option.
    * `'field'`: The thinking content is included in a separate field specified by `openai_chat_thinking_field`.
    * `False`: No thinking content is sent in the request.

    Defaults to `'auto'` to ensure thinking is sent back in the format expected by the model/provider."""

    openai_supports_strict_tool_definition: bool = True
    """This can be set by a provider or user if the OpenAI-"compatible" API doesn't support strict tool definitions."""

    openai_supports_sampling_settings: bool = True
    """Turn off to don't send sampling settings like `temperature` and `top_p` to models that don't support them, like OpenAI's o-series reasoning models."""

    openai_unsupported_model_settings: Sequence[str] = ()
    """A list of model settings that are not supported by this model."""

    # Some OpenAI-compatible providers (e.g. MoonshotAI) currently do **not** accept
    # `tool_choice="required"`.  This flag lets the calling model know whether it's
    # safe to pass that value along.  Default is `True` to preserve existing
    # behaviour for OpenAI itself and most providers.
    openai_supports_tool_choice_required: bool = True
    """Whether the provider accepts the value ``tool_choice='required'`` in the request payload."""

    openai_system_prompt_role: OpenAISystemPromptRole | None = None
    """The role to use for the system prompt message. If not provided, defaults to `'system'`."""

    openai_chat_supports_web_search: bool = False
    """Whether the model supports web search in Chat Completions API."""

    openai_chat_audio_input_encoding: Literal['base64', 'uri'] = 'base64'
    """The encoding to use for audio input in Chat Completions requests.

    - `'base64'`: Raw base64 encoded string. (Default, used by OpenAI)
    - `'uri'`: Data URI (e.g. `data:audio/wav;base64,...`).
    """

    openai_chat_supports_file_urls: bool = False
    """Whether the Chat API supports file URLs directly in the `file_data` field.

    OpenAI's native Chat API only supports base64-encoded data, but some providers
    like OpenRouter support passing URLs directly.
    """

    openai_supports_encrypted_reasoning_content: bool = False
    """Whether the model supports including encrypted reasoning content in the response."""

    openai_supports_reasoning: bool = False
    """Whether the model supports reasoning (o-series, GPT-5+).

    When True, sampling parameters may need to be dropped depending on reasoning_effort setting."""

    openai_supports_reasoning_effort_none: bool = False
    """Whether the model supports sampling parameters (temperature, top_p, etc.) when reasoning_effort='none'.

    Models like GPT-5.1 and GPT-5.2 default to reasoning_effort='none' and support sampling params in that mode.
    When reasoning is enabled (low/medium/high/xhigh), sampling params are not supported."""

    openai_responses_requires_function_call_status_none: bool = False
    """Whether the Responses API requires the `status` field on function tool calls to be `None`.

    This is required by vLLM Responses API versions before https://github.com/vllm-project/vllm/pull/26706.
    See https://github.com/pydantic/pydantic-ai/issues/3245 for more details.
    """

    def __post_init__(self):  # pragma: no cover
        if not self.openai_supports_sampling_settings:
            warnings.warn(
                'The `openai_supports_sampling_settings` has no effect, and it will be removed in future versions. '
                'Use `openai_unsupported_model_settings` instead.',
                DeprecationWarning,
            )
        if self.openai_chat_send_back_thinking_parts == 'field' and not self.openai_chat_thinking_field:
            raise UserError(
                'If `openai_chat_send_back_thinking_parts` is "field", '
                '`openai_chat_thinking_field` must be set to a non-None value.'
            )

```

---|---
####  openai_chat_thinking_field `class-attribute` `instance-attribute`
```
openai_chat_thinking_field: str[](https://docs.python.org/3/library/stdtypes.html#str) | None = None

```

Non-standard field name used by some providers for model thinking content in Chat Completions API responses.
Plenty of providers use custom field names for thinking content. Ollama and newer versions of vLLM use `reasoning`, while DeepSeek, older vLLM and some others use `reasoning_content`.
Notice that the thinking field configured here is currently limited to `str` type content.
If `openai_chat_send_back_thinking_parts` is set to `'field'`, this field must be set to a non-None value.
####  openai_chat_send_back_thinking_parts `class-attribute` `instance-attribute`
```
openai_chat_send_back_thinking_parts: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[
    "auto", "tags", "field", False
] = "auto"

```

Whether the model includes thinking content in requests.
This can be: * `'auto'` (default): Automatically detects how to send thinking content. If thinking was received in a custom field (tracked via `ThinkingPart.id` and `ThinkingPart.provider_name`), it's sent back in that same field. Otherwise, it's sent using tags. Only the `reasoning` and `reasoning_content` fields are checked by default when receiving responses. If your provider uses a different field name, you must explicitly set `openai_chat_thinking_field` to that field name. * `'tags'`: The thinking content is included in the main `content` field, enclosed within thinking tags as specified in `thinking_tags` profile option. * `'field'`: The thinking content is included in a separate field specified by `openai_chat_thinking_field`. * `False`: No thinking content is sent in the request.
Defaults to `'auto'` to ensure thinking is sent back in the format expected by the model/provider.
####  openai_supports_strict_tool_definition `class-attribute` `instance-attribute`
```
openai_supports_strict_tool_definition: bool[](https://docs.python.org/3/library/functions.html#bool) = True

```

This can be set by a provider or user if the OpenAI-"compatible" API doesn't support strict tool definitions.
####  openai_supports_sampling_settings `class-attribute` `instance-attribute`
```
openai_supports_sampling_settings: bool[](https://docs.python.org/3/library/functions.html#bool) = True

```

Turn off to don't send sampling settings like `temperature` and `top_p` to models that don't support them, like OpenAI's o-series reasoning models.
####  openai_unsupported_model_settings `class-attribute` `instance-attribute`
```
openai_unsupported_model_settings: Sequence[](https://docs.python.org/3/library/collections.abc.html#collections.abc.Sequence "collections.abc.Sequence")[str[](https://docs.python.org/3/library/stdtypes.html#str)] = ()

```

A list of model settings that are not supported by this model.
####  openai_supports_tool_choice_required `class-attribute` `instance-attribute`
```
openai_supports_tool_choice_required: bool[](https://docs.python.org/3/library/functions.html#bool) = True

```

Whether the provider accepts the value `tool_choice='required'` in the request payload.
####  openai_system_prompt_role `class-attribute` `instance-attribute`
```
openai_system_prompt_role: OpenAISystemPromptRole | None = (
    None
)

```

The role to use for the system prompt message. If not provided, defaults to `'system'`.
####  openai_chat_supports_web_search `class-attribute` `instance-attribute`
```
openai_chat_supports_web_search: bool[](https://docs.python.org/3/library/functions.html#bool) = False

```

Whether the model supports web search in Chat Completions API.
####  openai_chat_audio_input_encoding `class-attribute` `instance-attribute`
```
openai_chat_audio_input_encoding: Literal[](https://docs.python.org/3/library/typing.html#typing.Literal "typing.Literal")[
    "base64", "uri"
] = "base64"

```

The encoding to use for audio input in Chat Completions requests.
  * `'base64'`: Raw base64 encoded string. (Default, used by OpenAI)
  * `'uri'`: Data URI (e.g. `data:audio/wav;base64,...`).


####  openai_chat_supports_file_urls `class-attribute` `instance-attribute`
```
openai_chat_supports_file_urls: bool[](https://docs.python.org/3/library/functions.html#bool) = False

```

Whether the Chat API supports file URLs directly in the `file_data` field.
OpenAI's native Chat API only supports base64-encoded data, but some providers like OpenRouter support passing URLs directly.
####  openai_supports_encrypted_reasoning_content `class-attribute` `instance-attribute`
```
openai_supports_encrypted_reasoning_content: bool[](https://docs.python.org/3/library/functions.html#bool) = False

```

Whether the model supports including encrypted reasoning content in the response.
####  openai_supports_reasoning `class-attribute` `instance-attribute`
```
openai_supports_reasoning: bool[](https://docs.python.org/3/library/functions.html#bool) = False

```

Whether the model supports reasoning (o-series, GPT-5+).
When True, sampling parameters may need to be dropped depending on reasoning_effort setting.
####  openai_supports_reasoning_effort_none `class-attribute` `instance-attribute`
```
openai_supports_reasoning_effort_none: bool[](https://docs.python.org/3/library/functions.html#bool) = False

```

Whether the model supports sampling parameters (temperature, top_p, etc.) when reasoning_effort='none'.
Models like GPT-5.1 and GPT-5.2 default to reasoning_effort='none' and support sampling params in that mode. When reasoning is enabled (low/medium/high/xhigh), sampling params are not supported.
####  openai_responses_requires_function_call_status_none `class-attribute` `instance-attribute`
```
openai_responses_requires_function_call_status_none: (
    bool[](https://docs.python.org/3/library/functions.html#bool)
) = False

```

Whether the Responses API requires the `status` field on function tool calls to be `None`.
This is required by vLLM Responses API versions before https://github.com/vllm-project/vllm/pull/26706. See https://github.com/pydantic/pydantic-ai/issues/3245 for more details.
###  openai_model_profile
```
openai_model_profile(model_name: str[](https://docs.python.org/3/library/stdtypes.html#str)) -> ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile")

```

Get the model profile for an OpenAI model.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/openai.py`
```
136
137
138
139
140
141
142
143
144
145
146
147
148
149
150
151
152
153
154
155
156
157
158
159
160
161
162
163
164
165
166
167
168
169
170
171
172
173
174
175
176
```
| ```
def openai_model_profile(model_name: str) -> ModelProfile:
    """Get the model profile for an OpenAI model."""
    # GPT-5.1+ models use `reasoning={"effort": "none"}` by default, which allows sampling params.
    is_gpt_5_1_plus = model_name.startswith(('gpt-5.1', 'gpt-5.2'))

    # doesn't support `reasoning={"effort": "none"}` -  default is set at 'medium'
    # see https://platform.openai.com/docs/guides/reasoning
    is_gpt_5 = model_name.startswith('gpt-5') and not is_gpt_5_1_plus

    # always reasoning
    is_o_series = model_name.startswith('o')

    thinking_always_enabled = is_o_series or (is_gpt_5 and 'gpt-5-chat' not in model_name)

    supports_reasoning = thinking_always_enabled or is_gpt_5_1_plus

    # The o1-mini model doesn't support the `system` role, so we default to `user`.
    # See https://github.com/pydantic/pydantic-ai/issues/974 for more details.
    openai_system_prompt_role = 'user' if model_name.startswith('o1-mini') else None

    # Check if the model supports web search (only specific search-preview models)
    supports_web_search = '-search-preview' in model_name
    supports_image_output = (
        is_gpt_5 or is_gpt_5_1_plus or 'o3' in model_name or '4.1' in model_name or '4o' in model_name
    )

    # Structured Outputs (output mode 'native') is only supported with the gpt-4o-mini, gpt-4o-mini-2024-07-18,
    # and gpt-4o-2024-08-06 model snapshots and later. We leave it in here for all models because the
    # `default_structured_output_mode` is `'tool'`, so `native` is only used when the user specifically uses
    # the `NativeOutput` marker, so an error from the API is acceptable.
    return OpenAIModelProfile(
        json_schema_transformer=OpenAIJsonSchemaTransformer,
        supports_json_schema_output=True,
        supports_json_object_output=True,
        supports_image_output=supports_image_output,
        openai_system_prompt_role=openai_system_prompt_role,
        openai_chat_supports_web_search=supports_web_search,
        openai_supports_encrypted_reasoning_content=supports_reasoning,
        openai_supports_reasoning=supports_reasoning,
        openai_supports_reasoning_effort_none=is_gpt_5_1_plus,
    )

```

---|---
###  OpenAIJsonSchemaTransformer `dataclass`
Bases: `JsonSchemaTransformer`
Recursively handle the schema to make it compatible with OpenAI strict mode.
See https://platform.openai.com/docs/guides/function-calling?api-mode=responses#strict-mode for more details, but this basically just requires: * `additionalProperties` must be set to false for each object in the parameters * all fields in properties must be marked as required
Source code in `pydantic_ai_slim/pydantic_ai/profiles/openai.py`
```
209
210
211
212
213
214
215
216
217
218
219
220
221
222
223
224
225
226
227
228
229
230
231
232
233
234
235
236
237
238
239
240
241
242
243
244
245
246
247
248
249
250
251
252
253
254
255
256
257
258
259
260
261
262
263
264
265
266
267
268
269
270
271
272
273
274
275
276
277
278
279
280
281
282
283
284
285
286
287
288
289
290
291
292
293
294
295
296
297
298
299
300
301
302
303
304
305
306
307
308
309
310
311
312
313
314
315
316
```
| ```
@dataclass(init=False)
class OpenAIJsonSchemaTransformer(JsonSchemaTransformer):
    """Recursively handle the schema to make it compatible with OpenAI strict mode.

    See https://platform.openai.com/docs/guides/function-calling?api-mode=responses#strict-mode for more details,
    but this basically just requires:
    * `additionalProperties` must be set to false for each object in the parameters
    * all fields in properties must be marked as required
    """

    def __init__(self, schema: JsonSchema, *, strict: bool | None = None):
        super().__init__(schema, strict=strict)
        self.root_ref = schema.get('$ref')

    def walk(self) -> JsonSchema:
        # Note: OpenAI does not support anyOf at the root in strict mode
        # However, we don't need to check for it here because we ensure in pydantic_ai._utils.check_object_json_schema
        # that the root schema either has type 'object' or is recursive.
        result = super().walk()

        # For recursive models, we need to tweak the schema to make it compatible with strict mode.
        # Because the following should never change the semantics of the schema we apply it unconditionally.
        if self.root_ref is not None:
            result.pop('$ref', None)  # We replace references to the self.root_ref with just '#' in the transform method
            root_key = re.sub(r'^#/\$defs/', '', self.root_ref)
            result.update(self.defs.get(root_key) or {})

        return result

    def transform(self, schema: JsonSchema) -> JsonSchema:  # noqa: C901
        # Remove unnecessary keys
        schema.pop('title', None)
        schema.pop('$schema', None)
        schema.pop('discriminator', None)

        default = schema.get('default', _sentinel)
        if default is not _sentinel:
            # the "default" keyword is not allowed in strict mode, but including it makes some Ollama models behave
            # better, so we keep it around when not strict
            if self.strict is True:
                schema.pop('default', None)
            elif self.strict is None:  # pragma: no branch
                self.is_strict_compatible = False

        if schema_ref := schema.get('$ref'):
            if schema_ref == self.root_ref:
                schema['$ref'] = '#'
            if len(schema) > 1:
                # OpenAI Strict mode doesn't support siblings to "$ref", but _does_ allow siblings to "anyOf".
                # So if there is a "description" field or any other extra info, we move the "$ref" into an "anyOf":
                schema['anyOf'] = [{'$ref': schema.pop('$ref')}]

        # Track strict-incompatible keys
        incompatible_values: dict[str, Any] = {}
        for key in _STRICT_INCOMPATIBLE_KEYS:
            value = schema.get(key, _sentinel)
            if value is not _sentinel:
                incompatible_values[key] = value
        if format := schema.get('format'):
            if format not in _STRICT_COMPATIBLE_STRING_FORMATS:
                incompatible_values['format'] = format
        description = schema.get('description')
        if incompatible_values:
            if self.strict is True:
                notes: list[str] = []
                for key, value in incompatible_values.items():
                    schema.pop(key)
                    notes.append(f'{key}={value}')
                notes_string = ', '.join(notes)
                schema['description'] = notes_string if not description else f'{description} ({notes_string})'
            elif self.strict is None:  # pragma: no branch
                self.is_strict_compatible = False

        schema_type = schema.get('type')
        if 'oneOf' in schema:
            # OpenAI does not support oneOf in strict mode
            if self.strict is True:
                schema['anyOf'] = schema.pop('oneOf')
            else:
                self.is_strict_compatible = False

        if schema_type == 'object':
            # Always ensure 'properties' key exists - OpenAI drops objects without it
            if 'properties' not in schema:
                schema['properties'] = dict[str, Any]()

            if self.strict is True:
                # additional properties are disallowed
                schema['additionalProperties'] = False

                # all properties are required
                schema['required'] = list(schema['properties'].keys())

            elif self.strict is None:
                if schema.get('additionalProperties', None) not in (None, False):
                    self.is_strict_compatible = False
                else:
                    # additional properties are disallowed by default
                    schema['additionalProperties'] = False

                if 'properties' not in schema or 'required' not in schema:
                    self.is_strict_compatible = False
                else:
                    required = schema['required']
                    for k in schema['properties'].keys():
                        if k not in required:
                            self.is_strict_compatible = False
        return schema

```

---|---
###  anthropic_model_profile
```
anthropic_model_profile(
    model_name: str[](https://docs.python.org/3/library/stdtypes.html#str),
) -> ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile") | None

```

Get the model profile for an Anthropic model.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/anthropic.py`
```
 6
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
20
21
22
23
24
```
| ```
def anthropic_model_profile(model_name: str) -> ModelProfile | None:
    """Get the model profile for an Anthropic model."""
    models_that_support_json_schema_output = (
        'claude-haiku-4-5',
        'claude-sonnet-4-5',
        'claude-sonnet-4-6',
        'claude-opus-4-1',
        'claude-opus-4-5',
        'claude-opus-4-6',
    )
    """These models support both structured outputs and strict tool calling."""
    # TODO update when new models are released that support structured outputs
    # https://docs.claude.com/en/docs/build-with-claude/structured-outputs#example-usage

    supports_json_schema_output = model_name.startswith(models_that_support_json_schema_output)
    return ModelProfile(
        thinking_tags=('<thinking>', '</thinking>'),
        supports_json_schema_output=supports_json_schema_output,
    )

```

---|---
###  GoogleModelProfile `dataclass`
Bases: `ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile")`
Profile for models used with `GoogleModel`.
ALL FIELDS MUST BE `google_` PREFIXED SO YOU CAN MERGE THEM WITH OTHER MODELS.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/google.py`
```
 9
10
11
12
13
14
15
16
17
18
```
| ```
@dataclass(kw_only=True)
class GoogleModelProfile(ModelProfile):
    """Profile for models used with `GoogleModel`.

    ALL FIELDS MUST BE `google_` PREFIXED SO YOU CAN MERGE THEM WITH OTHER MODELS.
    """

    google_supports_native_output_with_builtin_tools: bool = False
    """Whether the model supports native output with builtin tools.
    See https://ai.google.dev/gemini-api/docs/structured-output?example=recipe#structured_outputs_with_tools"""

```

---|---
####  google_supports_native_output_with_builtin_tools `class-attribute` `instance-attribute`
```
google_supports_native_output_with_builtin_tools: bool[](https://docs.python.org/3/library/functions.html#bool) = (
    False
)

```

Whether the model supports native output with builtin tools. See https://ai.google.dev/gemini-api/docs/structured-output?example=recipe#structured_outputs_with_tools
###  google_model_profile
```
google_model_profile(
    model_name: str[](https://docs.python.org/3/library/stdtypes.html#str),
) -> ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile") | None

```

Get the model profile for a Google model.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/google.py`
```
21
22
23
24
25
26
27
28
29
30
31
32
```
| ```
def google_model_profile(model_name: str) -> ModelProfile | None:
    """Get the model profile for a Google model."""
    is_image_model = 'image' in model_name
    is_3_or_newer = 'gemini-3' in model_name
    return GoogleModelProfile(
        json_schema_transformer=GoogleJsonSchemaTransformer,
        supports_image_output=is_image_model,
        supports_json_schema_output=is_3_or_newer or not is_image_model,
        supports_json_object_output=is_3_or_newer or not is_image_model,
        supports_tools=not is_image_model,
        google_supports_native_output_with_builtin_tools=is_3_or_newer,
    )

```

---|---
###  GoogleJsonSchemaTransformer `dataclass`
Bases: `JsonSchemaTransformer`
Transforms the JSON Schema from Pydantic to be suitable for Gemini.
Gemini supports [a subset of OpenAPI v3.0.3](https://ai.google.dev/gemini-api/docs/function-calling#function_declarations).
Source code in `pydantic_ai_slim/pydantic_ai/profiles/google.py`
```
35
36
37
38
39
40
41
42
43
44
45
46
47
48
49
50
51
52
53
54
55
56
57
58
59
60
61
62
63
64
65
66
67
68
69
70
71
72
73
74
75
76
```
| ```
class GoogleJsonSchemaTransformer(JsonSchemaTransformer):
    """Transforms the JSON Schema from Pydantic to be suitable for Gemini.

    Gemini supports [a subset of OpenAPI v3.0.3](https://ai.google.dev/gemini-api/docs/function-calling#function_declarations).
    """

    def transform(self, schema: JsonSchema) -> JsonSchema:
        # Remove properties not supported by Gemini
        schema.pop('$schema', None)
        if (const := schema.pop('const', None)) is not None:
            # Gemini doesn't support const, but it does support enum with a single value
            schema['enum'] = [const]
            # If type is not present, infer it from the const value for Gemini API compatibility
            if 'type' not in schema:
                if isinstance(const, str):
                    schema['type'] = 'string'
                elif isinstance(const, bool):
                    # bool must be checked before int since bool is a subclass of int in Python
                    schema['type'] = 'boolean'
                elif isinstance(const, int):
                    schema['type'] = 'integer'
                elif isinstance(const, float):
                    schema['type'] = 'number'
        schema.pop('discriminator', None)
        schema.pop('examples', None)

        # Remove 'title' due to https://github.com/googleapis/python-genai/issues/1732
        schema.pop('title', None)

        type_ = schema.get('type')
        if type_ == 'string' and (fmt := schema.pop('format', None)):
            description = schema.get('description')
            if description:
                schema['description'] = f'{description} (format: {fmt})'
            else:
                schema['description'] = f'Format: {fmt}'

        # Note: exclusiveMinimum/exclusiveMaximum are NOT yet supported
        schema.pop('exclusiveMinimum', None)
        schema.pop('exclusiveMaximum', None)

        return schema

```

---|---
###  meta_model_profile
```
meta_model_profile(model_name: str[](https://docs.python.org/3/library/stdtypes.html#str)) -> ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile") | None

```

Get the model profile for a Meta model.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/meta.py`
```
6
7
8
```
| ```
def meta_model_profile(model_name: str) -> ModelProfile | None:
    """Get the model profile for a Meta model."""
    return ModelProfile(json_schema_transformer=InlineDefsJsonSchemaTransformer)

```

---|---
###  amazon_model_profile
```
amazon_model_profile(
    model_name: str[](https://docs.python.org/3/library/stdtypes.html#str),
) -> ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile") | None

```

Get the model profile for an Amazon model.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/amazon.py`
```
6
7
8
```
| ```
def amazon_model_profile(model_name: str) -> ModelProfile | None:
    """Get the model profile for an Amazon model."""
    return ModelProfile(json_schema_transformer=InlineDefsJsonSchemaTransformer)

```

---|---
###  deepseek_model_profile
```
deepseek_model_profile(
    model_name: str[](https://docs.python.org/3/library/stdtypes.html#str),
) -> ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile") | None

```

Get the model profile for a DeepSeek model.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/deepseek.py`
```
6
7
8
```
| ```
def deepseek_model_profile(model_name: str) -> ModelProfile | None:
    """Get the model profile for a DeepSeek model."""
    return ModelProfile(ignore_streamed_leading_whitespace='r1' in model_name)

```

---|---
###  GrokModelProfile `dataclass`
Bases: `ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile")`
Profile for Grok models (used with both GrokProvider and XaiProvider).
ALL FIELDS MUST BE `grok_` PREFIXED SO YOU CAN MERGE THEM WITH OTHER MODELS.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/grok.py`
```
 9
10
11
12
13
14
15
16
17
18
19
20
```
| ```
@dataclass(kw_only=True)
class GrokModelProfile(ModelProfile):
    """Profile for Grok models (used with both GrokProvider and XaiProvider).

    ALL FIELDS MUST BE `grok_` PREFIXED SO YOU CAN MERGE THEM WITH OTHER MODELS.
    """

    grok_supports_builtin_tools: bool = False
    """Whether the model supports builtin tools (web_search, code_execution, mcp)."""

    grok_supports_tool_choice_required: bool = True
    """Whether the provider accepts the value ``tool_choice='required'`` in the request payload."""

```

---|---
####  grok_supports_builtin_tools `class-attribute` `instance-attribute`
```
grok_supports_builtin_tools: bool[](https://docs.python.org/3/library/functions.html#bool) = False

```

Whether the model supports builtin tools (web_search, code_execution, mcp).
####  grok_supports_tool_choice_required `class-attribute` `instance-attribute`
```
grok_supports_tool_choice_required: bool[](https://docs.python.org/3/library/functions.html#bool) = True

```

Whether the provider accepts the value `tool_choice='required'` in the request payload.
###  grok_model_profile
```
grok_model_profile(model_name: str[](https://docs.python.org/3/library/stdtypes.html#str)) -> ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile") | None

```

Get the model profile for a Grok model.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/grok.py`
```
23
24
25
26
27
28
29
30
31
32
33
34
35
36
37
38
39
40
41
42
43
```
| ```
def grok_model_profile(model_name: str) -> ModelProfile | None:
    """Get the model profile for a Grok model."""
    # Grok-4 models support builtin tools
    grok_supports_builtin_tools = model_name.startswith('grok-4') or 'code' in model_name

    # Set supported builtin tools based on model capability
    supported_builtin_tools: frozenset[type[AbstractBuiltinTool]] = (
        SUPPORTED_BUILTIN_TOOLS if grok_supports_builtin_tools else frozenset()
    )

    return GrokModelProfile(
        # xAI supports tool calling
        supports_tools=True,
        # xAI supports JSON schema output for structured responses
        supports_json_schema_output=True,
        # xAI supports JSON object output
        supports_json_object_output=True,
        # Support for builtin tools (web_search, code_execution, mcp)
        grok_supports_builtin_tools=grok_supports_builtin_tools,
        supported_builtin_tools=supported_builtin_tools,
    )

```

---|---
###  mistral_model_profile
```
mistral_model_profile(
    model_name: str[](https://docs.python.org/3/library/stdtypes.html#str),
) -> ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile") | None

```

Get the model profile for a Mistral model.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/mistral.py`
```
6
7
8
```
| ```
def mistral_model_profile(model_name: str) -> ModelProfile | None:
    """Get the model profile for a Mistral model."""
    return None

```

---|---
###  qwen_model_profile
```
qwen_model_profile(model_name: str[](https://docs.python.org/3/library/stdtypes.html#str)) -> ModelProfile[](https://ai.pydantic.dev/api/profiles/#pydantic_ai.profiles.ModelProfile "pydantic_ai.profiles.ModelProfile") | None

```

Get the model profile for a Qwen model.
Source code in `pydantic_ai_slim/pydantic_ai/profiles/qwen.py`
```
 7
 8
 9
10
11
12
13
14
15
16
17
18
19
```
| ```
def qwen_model_profile(model_name: str) -> ModelProfile | None:
    """Get the model profile for a Qwen model."""
    if model_name.startswith('qwen-3-coder'):
        return OpenAIModelProfile(
            json_schema_transformer=InlineDefsJsonSchemaTransformer,
            openai_supports_tool_choice_required=False,
            openai_supports_strict_tool_definition=False,
            ignore_streamed_leading_whitespace=True,
        )
    return ModelProfile(
        json_schema_transformer=InlineDefsJsonSchemaTransformer,
        ignore_streamed_leading_whitespace=True,
    )

```

---|---
© Pydantic Services Inc. 2024 to present
