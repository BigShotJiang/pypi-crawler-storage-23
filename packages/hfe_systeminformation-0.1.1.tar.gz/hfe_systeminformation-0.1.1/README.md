# hfe-systeminformation

Install:
```bash
pip install hfe-systeminformation