"""
__main__.py - Entry point para execução do módulo synesis_lsp

Permite executar o servidor via: python -m synesis_lsp
"""

from synesis_lsp.server import main

if __name__ == "__main__":
    main()
