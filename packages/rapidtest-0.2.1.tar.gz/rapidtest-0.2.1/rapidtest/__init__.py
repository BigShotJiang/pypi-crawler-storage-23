"""
RapidTest: Una librería para simplificar las pruebas de APIs REST.
"""

from .RapidTest import Test as Test
from .RapidData import Data as Data


