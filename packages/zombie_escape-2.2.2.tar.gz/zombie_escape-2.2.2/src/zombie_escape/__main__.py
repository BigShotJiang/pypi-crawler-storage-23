from __future__ import annotations

from .zombie_escape import main


if __name__ == "__main__":
    main()
