"""Dynamic action definitions for LLM-based intent classification."""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

from typing import Dict
from unishell.core.action_registry import ActionSchema, PermissionLevel, RiskLevel, RollbackStrategy, ExecutionConfig


class DynamicAKSActionRegistry:
    """Dynamic action registry for LLM understanding."""
    
    @staticmethod
    def get_actions() -> Dict[str, ActionSchema]:
        """Get all AKS actions with LLM-friendly IDs."""
        return {
            "deploy_application": ActionSchema(
                action_id="deploy_application",
                category="deployment",
                required_params=["app_path"],
                optional_params=["namespace", "replicas", "image_tag"],
                permission_level=PermissionLevel.USER,
                risk_level=RiskLevel.MEDIUM,
                execution=ExecutionConfig(timeout=600, retry_count=2, requires_confirmation=True),
                rollback_strategy=RollbackStrategy.AUTOMATIC,
                description="Deploy application to AKS cluster"
            ),
            "build_docker_image": ActionSchema(
                action_id="build_docker_image",
                category="build",
                required_params=["app_path"],
                optional_params=["image_name", "tag"],
                permission_level=PermissionLevel.USER,
                risk_level=RiskLevel.LOW,
                execution=ExecutionConfig(timeout=900, retry_count=1, requires_confirmation=False),
                rollback_strategy=RollbackStrategy.NONE,
                description="Build Docker image from application"
            ),
            "push_to_acr": ActionSchema(
                action_id="push_to_acr",
                category="registry",
                required_params=["image_name"],
                optional_params=["registry_name", "tag"],
                permission_level=PermissionLevel.USER,
                risk_level=RiskLevel.LOW,
                execution=ExecutionConfig(timeout=600, retry_count=2, requires_confirmation=False),
                rollback_strategy=RollbackStrategy.NONE,
                description="Push image to Azure Container Registry"
            ),
            "create_deployment": ActionSchema(
                action_id="create_deployment",
                category="kubernetes",
                required_params=["app_name", "image"],
                optional_params=["namespace", "replicas", "port"],
                permission_level=PermissionLevel.USER,
                risk_level=RiskLevel.MEDIUM,
                execution=ExecutionConfig(timeout=300, retry_count=1, requires_confirmation=True),
                rollback_strategy=RollbackStrategy.AUTOMATIC,
                description="Create Kubernetes deployment"
            ),
            "create_service": ActionSchema(
                action_id="create_service",
                category="kubernetes",
                required_params=["app_name"],
                optional_params=["namespace", "port", "type"],
                permission_level=PermissionLevel.USER,
                risk_level=RiskLevel.LOW,
                execution=ExecutionConfig(timeout=120, retry_count=1, requires_confirmation=False),
                rollback_strategy=RollbackStrategy.AUTOMATIC,
                description="Create Kubernetes service"
            ),
            "scale_deployment": ActionSchema(
                action_id="scale_deployment",
                category="kubernetes",
                required_params=["app_name", "replicas"],
                optional_params=["namespace"],
                permission_level=PermissionLevel.USER,
                risk_level=RiskLevel.MEDIUM,
                execution=ExecutionConfig(timeout=180, retry_count=1, requires_confirmation=True),
                rollback_strategy=RollbackStrategy.MANUAL,
                description="Scale Kubernetes deployment"
            ),
            "rollback_deployment": ActionSchema(
                action_id="rollback_deployment",
                category="kubernetes",
                required_params=["app_name"],
                optional_params=["namespace", "revision"],
                permission_level=PermissionLevel.USER,
                risk_level=RiskLevel.HIGH,
                execution=ExecutionConfig(timeout=300, retry_count=0, requires_confirmation=True),
                rollback_strategy=RollbackStrategy.NONE,
                description="Rollback Kubernetes deployment"
            ),
            "get_deployment_status": ActionSchema(
                action_id="get_deployment_status",
                category="monitoring",
                required_params=["app_name"],
                optional_params=["namespace"],
                permission_level=PermissionLevel.USER,
                risk_level=RiskLevel.LOW,
                execution=ExecutionConfig(timeout=60, retry_count=1, requires_confirmation=False),
                rollback_strategy=RollbackStrategy.NONE,
                description="Get deployment status"
            ),
        }
