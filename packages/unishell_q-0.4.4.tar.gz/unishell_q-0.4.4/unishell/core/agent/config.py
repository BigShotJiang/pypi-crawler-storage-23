"""Agent configuration."""
from dataclasses import dataclass

@dataclass
class AgentConfig:
    gateway_url: str
    desktop_id: str
    device_token: str
    polling_interval: int = 5
    heartbeat_interval: int = 10
    agent_version: str = "1.0.0"
