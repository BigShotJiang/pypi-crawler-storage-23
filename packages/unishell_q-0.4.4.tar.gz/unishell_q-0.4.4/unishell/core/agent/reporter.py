"""Status reporter for desktop agent."""
import aiohttp
from datetime import datetime

class StatusReporter:
    def __init__(self, config):
        self.config = config
        
    async def update_status(self, action_id, status, log=None, result=None, error=None):
        """Update action status on gateway."""
        url = f"{self.config.gateway_url}/agent/actions/{action_id}"
        headers = {"Authorization": self.config.device_token}
        payload = {"status": status}
        
        if log:
            payload["log"] = log
        if result:
            payload["result"] = result
        if error:
            payload["error"] = error
            
        try:
            async with aiohttp.ClientSession() as session:
                async with session.patch(url, json=payload, headers=headers, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                    return resp.status == 200
        except:
            return False
