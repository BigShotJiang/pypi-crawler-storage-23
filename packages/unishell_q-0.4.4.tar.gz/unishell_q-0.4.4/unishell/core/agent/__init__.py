"""Desktop Agent module for secure gateway integration."""
from .agent import DesktopAgent
from .config import AgentConfig

__all__ = ["DesktopAgent", "AgentConfig"]
