"""Execution adapter abstract base class."""

from abc import ABC, abstractmethod
from typing import Dict, Any, AsyncIterator
from enum import Enum


class ExecutionStatus(Enum):
    """Execution status states."""
    PENDING = "pending"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"


class ExecutionAdapter(ABC):
    """Abstract base class for action execution."""

    @abstractmethod
    async def execute(self, intent: str, parameters: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute action with parameters.
        
        Args:
            intent: Intent identifier
            parameters: Action parameters
            context: Execution context
            
        Returns:
            Execution result dictionary
        """
        pass

    @abstractmethod
    async def execute_stream(self, intent: str, parameters: Dict[str, Any], context: Dict[str, Any]) -> AsyncIterator[Dict[str, Any]]:
        """Execute action with streaming results.
        
        Args:
            intent: Intent identifier
            parameters: Action parameters
            context: Execution context
            
        Yields:
            Execution result chunks
        """
        pass

    @abstractmethod
    async def get_status(self, execution_id: str) -> ExecutionStatus:
        """Get execution status.
        
        Args:
            execution_id: Execution identifier
            
        Returns:
            Current execution status
        """
        pass

    @abstractmethod
    async def cancel(self, execution_id: str) -> bool:
        """Cancel running execution.
        
        Args:
            execution_id: Execution identifier
            
        Returns:
            True if cancellation successful
        """
        pass
