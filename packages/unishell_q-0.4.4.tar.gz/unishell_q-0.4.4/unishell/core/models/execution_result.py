"""Execution result data model."""

from pydantic import BaseModel, Field
from typing import Dict, Any, Optional


class ExecutionResult(BaseModel):
    """Result of action execution."""
    
    success: bool = Field(..., description="Execution success status")
    message: str = Field(..., description="Result message")
    data: Optional[Dict[str, Any]] = Field(None, description="Result data")
    dry_run: bool = Field(default=False, description="Was this a dry run")
    metadata: Dict[str, Any] = Field(default_factory=dict)
