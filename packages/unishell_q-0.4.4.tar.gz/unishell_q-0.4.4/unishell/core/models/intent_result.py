"""Intent classification result data model."""

from pydantic import BaseModel, Field
from typing import Dict, Any, Optional


class IntentResult(BaseModel):
    """Result of intent classification."""
    
    action_id: str = Field(..., description="Identified action ID")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Confidence score")
    reasoning: Optional[str] = Field(None, description="Classification reasoning")
    needs_clarification: bool = Field(default=False, description="Requires user clarification")
    metadata: Dict[str, Any] = Field(default_factory=dict)


class ParameterResult(BaseModel):
    """Result of parameter extraction."""
    
    parameters: Dict[str, Any] = Field(default_factory=dict, description="Extracted parameters")
    missing_fields: list[str] = Field(default_factory=list, description="Missing required fields")
    confidence: float = Field(..., ge=0.0, le=1.0, description="Extraction confidence")
    metadata: Dict[str, Any] = Field(default_factory=dict)
