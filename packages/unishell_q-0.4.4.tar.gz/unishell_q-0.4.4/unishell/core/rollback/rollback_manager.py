"""Rollback manager abstract base class."""

from abc import ABC, abstractmethod
from typing import Dict, Any, Callable


class RollbackManager(ABC):
    """Abstract base class for rollback management."""

    @abstractmethod
    async def create_checkpoint(self, execution_id: str, state: Dict[str, Any]) -> str:
        """Create rollback checkpoint.
        
        Args:
            execution_id: Execution identifier
            state: Current state snapshot
            
        Returns:
            Checkpoint identifier
        """
        pass

    @abstractmethod
    async def rollback(self, checkpoint_id: str) -> bool:
        """Rollback to checkpoint.
        
        Args:
            checkpoint_id: Checkpoint identifier
            
        Returns:
            True if rollback successful
        """
        pass

    @abstractmethod
    def register_rollback_handler(self, intent: str, handler: Callable) -> None:
        """Register rollback handler for intent.
        
        Args:
            intent: Intent identifier
            handler: Rollback handler callable
        """
        pass

    @abstractmethod
    async def can_rollback(self, execution_id: str) -> bool:
        """Check if execution can be rolled back.
        
        Args:
            execution_id: Execution identifier
            
        Returns:
            True if rollback possible
        """
        pass
