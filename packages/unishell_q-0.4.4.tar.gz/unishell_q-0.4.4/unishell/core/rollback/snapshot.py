"""Snapshot data model for rollback."""

from pydantic import BaseModel, Field
from typing import Dict, Any
from datetime import datetime


class Snapshot(BaseModel):
    """Snapshot for rollback."""
    
    snapshot_id: str = Field(..., description="Unique snapshot identifier")
    action_id: str = Field(..., description="Action identifier")
    parameters: Dict[str, Any] = Field(..., description="Action parameters")
    state: Dict[str, Any] = Field(..., description="State before execution")
    timestamp: datetime = Field(default_factory=datetime.now, description="Snapshot creation time")
    committed: bool = Field(default=False, description="Whether snapshot is committed")
