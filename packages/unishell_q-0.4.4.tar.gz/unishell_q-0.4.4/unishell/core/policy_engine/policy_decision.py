"""Policy decision data model."""

from pydantic import BaseModel, Field


class PolicyDecision(BaseModel):
    """Result of policy evaluation."""
    
    allowed: bool = Field(..., description="Whether action is allowed")
    reason: str = Field(..., description="Reason for decision")
    metadata: dict = Field(default_factory=dict, description="Additional context")
