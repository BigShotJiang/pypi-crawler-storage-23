"""Policy engine abstract base class."""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Callable
from enum import Enum


class PolicyDecision(Enum):
    """Policy decision outcomes."""
    ALLOW = "allow"
    DENY = "deny"
    REQUIRE_APPROVAL = "require_approval"


class PolicyEngine(ABC):
    """Abstract base class for policy evaluation."""

    @abstractmethod
    async def evaluate(self, intent: str, parameters: Dict[str, Any], context: Dict[str, Any]) -> PolicyDecision:
        """Evaluate policy for action execution.
        
        Args:
            intent: Intent identifier
            parameters: Action parameters
            context: Execution context
            
        Returns:
            Policy decision
        """
        pass

    @abstractmethod
    async def get_violations(self, intent: str, parameters: Dict[str, Any]) -> List[str]:
        """Get policy violations for action.
        
        Args:
            intent: Intent identifier
            parameters: Action parameters
            
        Returns:
            List of violation descriptions
        """
        pass

    @abstractmethod
    def add_policy(self, policy_id: str, policy: Callable) -> None:
        """Add a policy rule.
        
        Args:
            policy_id: Policy identifier
            policy: Policy evaluation callable
        """
        pass
