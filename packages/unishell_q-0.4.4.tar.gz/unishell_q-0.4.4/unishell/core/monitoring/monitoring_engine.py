"""Monitoring engine abstract base class."""

from abc import ABC, abstractmethod
from typing import Dict, Any, List
from datetime import datetime


class MonitoringEngine(ABC):
    """Abstract base class for execution monitoring."""

    @abstractmethod
    async def track_execution(self, execution_id: str, intent: str, parameters: Dict[str, Any]) -> None:
        """Track execution start.
        
        Args:
            execution_id: Execution identifier
            intent: Intent identifier
            parameters: Action parameters
        """
        pass

    @abstractmethod
    async def record_result(self, execution_id: str, result: Dict[str, Any], status: str) -> None:
        """Record execution result.
        
        Args:
            execution_id: Execution identifier
            result: Execution result
            status: Execution status
        """
        pass

    @abstractmethod
    async def get_metrics(self, intent: str, start_time: datetime, end_time: datetime) -> Dict[str, Any]:
        """Get execution metrics for intent.
        
        Args:
            intent: Intent identifier
            start_time: Metrics start time
            end_time: Metrics end time
            
        Returns:
            Metrics dictionary
        """
        pass

    @abstractmethod
    async def get_history(self, execution_id: str) -> List[Dict[str, Any]]:
        """Get execution history.
        
        Args:
            execution_id: Execution identifier
            
        Returns:
            List of execution events
        """
        pass
