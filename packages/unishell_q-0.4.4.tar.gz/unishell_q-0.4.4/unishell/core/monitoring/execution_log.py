"""Execution log data model."""

from pydantic import BaseModel, Field
from typing import Dict, Any
from datetime import datetime


class ExecutionLog(BaseModel):
    """Log entry for execution tracking."""
    
    timestamp: datetime = Field(default_factory=datetime.now, description="Log timestamp")
    action_id: str = Field(..., description="Action identifier")
    status: str = Field(..., description="Execution status")
    details: Dict[str, Any] = Field(default_factory=dict, description="Additional details")
