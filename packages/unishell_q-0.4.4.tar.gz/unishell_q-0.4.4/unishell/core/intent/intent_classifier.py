"""Intent classifier abstract base class."""

from abc import ABC, abstractmethod
from typing import Dict, Any


class IntentClassifier(ABC):
    """Abstract base class for intent classification."""

    @abstractmethod
    async def classify(self, user_input: str, context: Dict[str, Any]) -> str:
        """Classify user intent from input.
        
        Args:
            user_input: Raw user input text
            context: Additional context information
            
        Returns:
            Intent identifier string
        """
        pass

    @abstractmethod
    async def get_confidence(self, user_input: str, intent: str) -> float:
        """Get confidence score for classified intent.
        
        Args:
            user_input: Raw user input text
            intent: Classified intent identifier
            
        Returns:
            Confidence score between 0.0 and 1.0
        """
        pass
