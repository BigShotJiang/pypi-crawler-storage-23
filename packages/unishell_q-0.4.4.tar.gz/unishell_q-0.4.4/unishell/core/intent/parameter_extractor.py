"""Parameter extractor abstract base class."""

from abc import ABC, abstractmethod
from typing import Dict, Any


class ParameterExtractor(ABC):
    """Abstract base class for parameter extraction."""

    @abstractmethod
    async def extract(self, user_input: str, intent: str) -> Dict[str, Any]:
        """Extract parameters from user input for given intent.
        
        Args:
            user_input: Raw user input text
            intent: Classified intent identifier
            
        Returns:
            Dictionary of extracted parameters
        """
        pass

    @abstractmethod
    async def validate(self, parameters: Dict[str, Any], intent: str) -> bool:
        """Validate extracted parameters.
        
        Args:
            parameters: Extracted parameters
            intent: Intent identifier
            
        Returns:
            True if parameters are valid
        """
        pass
