"""
This is an Open UniShell profile. It configures Open UniShell to run `Llama 3.1 70B` using Groq.

Make sure to set GROQ_API_KEY environment variable to your API key.
"""

from unishell import unishell

unishell.llm.model = "groq/llama-3.1-70b-versatile"

unishell.computer.import_computer_api = True

unishell.llm.supports_functions = False
unishell.llm.supports_vision = False
unishell.llm.context_window = 110000
unishell.llm.max_tokens = 4096
