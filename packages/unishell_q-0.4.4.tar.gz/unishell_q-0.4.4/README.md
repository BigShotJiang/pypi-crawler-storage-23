# UniShell - Complete Technical Documentation

<h1 align="center">● UniShell (Open UniShell)</h1>

---

## Table of Contents

1. [Overview](#overview)
2. [Architecture](#architecture)
3. [Installation](#installation)
4. [Core Components](#core-components)
5. [Language Support](#language-support)
6. [Computer API](#computer-api)
7. [LLM Integration](#llm-integration)
8. [Terminal Interface](#terminal-interface)
9. [Server Mode](#server-mode)
10. [Configuration](#configuration)
11. [Message Format](#message-format)
12. [Advanced Features](#advanced-features)
13. [Security](#security)
14. [Development](#development)

---

## Overview

**UniShell** is an advanced AI-powered code execution framework that bridges Large Language Models (LLMs) with local system execution. It provides a natural language interface to your computer's capabilities through a ChatGPT-like terminal interface.

### Key Capabilities

- **Multi-Language Code Execution**: Python, JavaScript, Shell, Ruby, R, Java, PowerShell, AppleScript, HTML, React
- **Stateful Execution**: Maintains context between code runs using Jupyter kernels
- **Computer Control**: Mouse, keyboard, display, browser, file system, and OS-level operations
- **Vision Support**: Multimodal models can process images; non-vision models use automatic image description
- **Local & Cloud Models**: OpenAI, Anthropic, Ollama, LM Studio, and custom endpoints
- **Safety Features**: Code approval, safe mode scanning, output truncation
- **Server Mode**: WebSocket and REST API for remote access
- **Conversation History**: Automatic saving and resumption of conversations

### Version Information

- **Current Version**: 0.4.3
- **Python Requirement**: >=3.9, <3.13
- **License**: AGPL

---

## Architecture

### Project Structure

```
unishell/
├── core/                      # Core execution engine
│   ├── computer/              # Computer control API
│   │   ├── terminal/          # Code execution
│   │   │   └── languages/     # Language implementations
│   │   ├── ai/                # AI capabilities
│   │   ├── browser/           # Web automation
│   │   ├── display/           # Screen control
│   │   ├── keyboard/          # Keyboard automation
│   │   ├── mouse/             # Mouse automation
│   │   ├── files/             # File operations
│   │   ├── vision/            # Image processing
│   │   ├── os/                # OS operations
│   │   ├── mail/              # Email
│   │   ├── sms/               # SMS
│   │   ├── calendar/          # Calendar
│   │   ├── contacts/          # Contacts
│   │   ├── clipboard/         # Clipboard
│   │   ├── skills/            # Reusable code patterns
│   │   └── docs/              # Documentation
│   ├── llm/                   # LLM integration
│   │   ├── llm.py             # Main LLM class
│   │   ├── run_tool_calling_llm.py  # Function calling
│   │   └── run_text_llm.py    # Text-only models
│   ├── core.py                # UniShell main class
│   ├── async_core.py          # Async/server implementation
│   ├── respond.py             # Response generation
│   ├── default_system_message.py  # System prompt
│   └── render_message.py      # Message rendering
├── terminal_interface/        # CLI interface
│   ├── components/            # UI components
│   ├── profiles/              # Configuration profiles
│   ├── terminal_interface.py  # Main interface
│   └── start_terminal_interface.py  # Entry point
├── computer_use/              # OS control mode
└── __init__.py                # Package initialization
```

### Execution Flow

```
User Input → UniShell.chat()
    ↓
Terminal Interface (display=True) or Direct (display=False)
    ↓
UniShell._streaming_chat()
    ↓
UniShell._respond_and_store()
    ↓
respond() function
    ↓
┌─────────────────────────────────────┐
│ 1. Render System Message            │
│    - Base system message             │
│    - Language-specific messages      │
│    - Custom instructions             │
│    - Computer API system message     │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ 2. LLM.run(messages)                │
│    - Convert to OpenAI format        │
│    - Trim to context window          │
│    - Handle vision/function support  │
│    - Stream response chunks          │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ 3. Parse LLM Response               │
│    - Extract code blocks             │
│    - Detect language                 │
│    - Handle hallucinations           │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ 4. Code Approval (if auto_run=False)│
│    - Display code to user            │
│    - Optional safe mode scan         │
│    - Wait for y/n/e response         │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ 5. Computer.run(language, code)     │
│    - Get/create language instance    │
│    - Execute code (streaming)        │
│    - Capture output/errors           │
│    - Track active line               │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ 6. Yield Output Chunks              │
│    - Console output                  │
│    - Images (base64)                 │
│    - HTML/JavaScript                 │
│    - Active line updates             │
└─────────────────────────────────────┘
    ↓
┌─────────────────────────────────────┐
│ 7. Loop Decision                    │
│    - Check loop_breakers             │
│    - Continue or complete            │
└─────────────────────────────────────┘
    ↓
Save to Conversation History (if enabled)
```

---

## Installation

### Basic Installation

```bash
# Clone the repository
git clone https://github.com/UniShell/open-unishell.git
cd open-unishell

# Install dependencies
pip install -r requirements.txt

# Install the package
pip install -e .
```

### Optional Dependencies

Install additional packages as needed:

```bash
# OS control (computer vision, GUI automation)
pip install opencv-python pyautogui plyer pywinctl pytesseract sentence-transformers ipywidgets timm screeninfo

# Local model support
pip install torch transformers einops torchvision easyocr

# Safe mode (code scanning)
pip install semgrep
```

### Command-Line Aliases

After installation, the following commands are available:

- `unishell` - Main command
- `u` - Short alias
- `unishell-classic` - Classic mode
- `wtf` - Terminal helper script (implemented in scripts/terminal_helper.py)

---

## Core Components

### 1. UniShell Class (`core/core.py`)

The central orchestrator managing conversation flow.

#### Key Attributes

```python
# State
messages: list              # Conversation history (LMC format)
responding: bool            # Currently generating response
last_messages_count: int    # Track new messages

# Settings
auto_run: bool = False      # Auto-execute code without approval
verbose: bool = False       # Detailed logging
debug: bool = False         # Debug mode
max_output: int = 2800      # Max characters in output
safe_mode: str = "off"      # "off", "ask", "auto"
shrink_images: bool = True  # Compress images for LLM
offline: bool = False       # Disable online features
disable_telemetry: bool = False  # Opt out of analytics

# Loop settings
loop: bool = False          # Autonomous mode
loop_message: str           # Prompt to continue
loop_breakers: list         # Phrases that end loop

# Conversation history
conversation_history: bool = True
conversation_filename: str
conversation_history_path: str

# OS control mode
os: bool = False            # Enable OS control
speak_messages: bool = False  # TTS on Mac

# Display
plain_text_display: bool = False
highlight_active_line: bool = True
in_terminal_interface: bool = False
multi_line: bool = True

# Components
computer: Computer          # Computer control API
llm: Llm                   # Language model interface

# Message templates
system_message: str
custom_instructions: str
user_message_template: str
code_output_template: str
empty_code_output_template: str
code_output_sender: str = "user"
```

#### Key Methods

**chat(message=None, display=True, stream=False, blocking=True)**
- Main entry point for interaction
- `message`: String, dict, or list of messages
- `display=True`: Use terminal interface
- `stream=True`: Return generator
- `blocking=False`: Run in background thread

**_streaming_chat(message, display)**
- Internal streaming implementation
- Handles message formatting
- Saves conversation history

**_respond_and_store()**
- Pulls from respond() stream
- Adds start/end flags
- Assembles and stores messages
- Handles ephemeral chunks (active_line, review)

**reset()**
- Terminates all language processes
- Clears messages
- Resets flags

**wait()**
- Blocks until response complete
- Returns new messages

### 2. Computer Class (`core/computer/computer.py`)

Provides system-level capabilities to the LLM.

#### Sub-modules

```python
computer.terminal      # Code execution
computer.mouse         # Mouse control
computer.keyboard      # Keyboard control
computer.display       # Screen capture/control
computer.clipboard     # Clipboard operations
computer.mail          # Email
computer.sms           # SMS
computer.calendar      # Calendar events
computer.contacts      # Contact management
computer.browser       # Web automation
computer.os            # OS operations
computer.vision        # Image analysis
computer.skills        # Reusable code
computer.docs          # Documentation
computer.ai            # AI capabilities
computer.files         # File operations
```

#### Key Attributes

```python
emit_images: bool = True    # Return images in output
api_base: str              # Computer API endpoint
save_skills: bool = True   # Auto-save functions
import_computer_api: bool = False  # Pre-import in Python
import_skills: bool = False  # Import saved skills
max_output: int            # Mirror unishell.max_output
verbose: bool
debug: bool
offline: bool
```

#### System Message

The Computer API automatically generates documentation for all available methods:

```python
computer.system_message = """
# THE COMPUTER API

A python `computer` module is ALREADY IMPORTED, and can be used for many tasks:

```python
computer.browser.search(query) # Searches the web
computer.display.screenshot() # Takes screenshot
computer.mouse.click(text="Button") # Clicks text
computer.keyboard.write(text) # Types text
...
```

Do not import the computer module, or any of its sub-modules.
"""
```

### 3. Terminal Class (`core/computer/terminal/terminal.py`)

Manages code execution across multiple languages.

#### Supported Languages

```python
languages = [
    Python,      # Via Jupyter kernel
    JavaScript,  # Via Node.js
    Shell,       # Via subprocess
    Ruby,        # Via subprocess
    R,           # Via subprocess
    PowerShell,  # Windows only
    AppleScript, # macOS only
    HTML,        # Via html2image
    React,       # Via Node.js
    Java,        # Via subprocess
]
```

#### Key Methods

**run(language, code, stream=False, display=False)**
- Execute code in specified language
- Returns list of LMC messages or generator
- Handles special cases (apt install, computer API import)

**get_language(language)**
- Returns language class by name or alias
- Case-insensitive matching

**stop()**
- Interrupt current execution
- Maintains state

**terminate()**
- Kill all language processes
- Clear state

#### Language Implementation

Each language inherits from `BaseLanguage`:

```python
class BaseLanguage:
    name: str              # "Python", "JavaScript", etc.
    file_extension: str    # "py", "js", etc.
    aliases: list          # ["py"], ["js", "node"], etc.
    
    def run(self, code):
        """Generator yielding LMC chunks"""
        pass
    
    def stop(self):
        """Interrupt execution"""
        pass
    
    def terminate(self):
        """Kill process"""
        pass
```

### 4. Llm Class (`core/llm/llm.py`)

Interfaces with language models via LiteLLM.

#### Key Attributes

```python
model: str = "gpt-4o"
temperature: float = 0.0
supports_vision: bool = None      # Auto-detect
supports_functions: bool = None   # Auto-detect
context_window: int = None        # Auto-detect
max_tokens: int = None           # Auto-detect
api_base: str = None
api_key: str = None
api_version: str = None
max_budget: float = None         # USD limit

# Vision fallback
vision_renderer: callable        # For non-vision models

# Function calling fallback
execution_instructions: str      # For non-function models
```

#### Key Methods

**run(messages)**
- Main LLM execution
- Converts LMC → OpenAI format
- Handles vision/function support
- Trims to context window
- Streams response chunks

**load()**
- Initialize model
- Download if needed (Ollama)
- Detect capabilities
- Set context window

#### Model Support

**Hosted Models:**
- OpenAI: gpt-4o, gpt-4-turbo, gpt-3.5-turbo
- Anthropic: claude-3.5-sonnet, claude-3-opus
- Google: gemini-pro
- Mistral: mistral-large
- Groq: llama3-70b, mixtral-8x7b

**Local Models:**
- Ollama: Any model (auto-download)
- LM Studio: OpenAI-compatible endpoint
- Jan.ai: OpenAI-compatible endpoint
- Llamafile: Built-in local server

**Custom:**
- Any OpenAI-compatible API

---

## Language Support

### Python (Jupyter Kernel)

**Implementation**: `languages/jupyter_language.py`

**Features:**
- Stateful execution via Jupyter kernel
- Matplotlib integration (inline backend)
- Active line tracking via AST manipulation
- Image output (PNG, JPEG)
- HTML/JavaScript output
- Automatic error handling

**Special Handling:**
- Adds `print("##active_line{N}##")` statements
- Detects long-running processes
- Auto-suggests input for hanging processes
- Imports computer API on first use

**Environment Variables:**
- `UNISHELL_ACTIVE_LINE_DETECTION`: Enable/disable (default: True)
- `UNISHELL_TERMINAL_INPUT_PATIENCE`: Seconds before input prompt (default: 15)

### JavaScript

**Implementation**: `languages/javascript.py`

**Features:**
- Node.js subprocess execution
- Persistent state between runs
- Console output capture
- Error handling

### Shell

**Implementation**: `languages/shell.py`

**Features:**
- Bash/Zsh/PowerShell support
- Streaming output
- Environment variable persistence
- Special handling for `apt install` (sudo prompt)

### Other Languages

All use `subprocess_language.py` base:
- Ruby
- R
- Java
- PowerShell (Windows)
- AppleScript (macOS)

---

## Computer API

### Display (`computer/display/display.py`)

```python
computer.display.screenshot(show=True, quadrant=None)
# Takes screenshot, returns base64 image
# quadrant: "top left", "top right", "bottom left", "bottom right"

computer.display.view(show=True)
# Alias for screenshot()

computer.display.width
computer.display.height
# Screen dimensions
```

### Mouse (`computer/mouse/mouse.py`)

```python
computer.mouse.click(text=None, icon=None, x=None, y=None)
# Click by text, icon, or coordinates

computer.mouse.move(text=None, icon=None, x=None, y=None)
# Move cursor

computer.mouse.scroll(clicks)
# Scroll up (positive) or down (negative)

computer.mouse.position()
# Get current (x, y)
```

### Keyboard (`computer/keyboard/keyboard.py`)

```python
computer.keyboard.write(text)
# Type text

computer.keyboard.press(key)
# Press single key

computer.keyboard.hotkey(*keys)
# Press key combination (e.g., "ctrl", "c")
```

### Browser (`computer/browser/browser.py`)

```python
computer.browser.search(query)
# Search and return results

computer.browser.open(url)
# Open URL in browser

computer.browser.click(text)
# Click element by text

computer.browser.screenshot()
# Capture browser window
```

### Files (`computer/files/files.py`)

```python
computer.files.read(path)
# Read file contents

computer.files.write(path, content)
# Write to file

computer.files.list(directory)
# List directory contents

computer.files.delete(path)
# Delete file/directory
```

### OS (`computer/os/os.py`)

```python
computer.os.notify(message)
# Show system notification

computer.os.get_selected_text()
# Get currently selected text

computer.os.get_clipboard()
# Get clipboard contents

computer.os.set_clipboard(text)
# Set clipboard contents
```

### Vision (`computer/vision/vision.py`)

```python
computer.vision.query(path=None, lmc=None, query="Describe this image")
# Ask questions about images

computer.vision.ocr(path=None, lmc=None)
# Extract text from image

computer.vision.load()
# Load local vision model (moondream)
```

### AI (`computer/ai/ai.py`)

```python
computer.ai.chat(message, model=None)
# Quick LLM query

computer.ai.embed(text)
# Get text embeddings
```

### Skills (`computer/skills/skills.py`)

```python
computer.skills.path
# Directory for saved skills

computer.skills.import_skills()
# Import all saved Python functions

computer.skills.save(name, code)
# Save function for reuse
```

---


## Terminal Interface

### Entry Point (`terminal_interface/start_terminal_interface.py`)

**Command-Line Arguments:**

```bash
# Model configuration
--model, -m <model>              # LLM model name
--temperature, -t <float>        # Sampling temperature
--context_window, -cw <int>      # Context window size
--max_tokens, -x <int>           # Max tokens per response
--max_budget, -b <float>         # Budget limit (USD)

# API configuration
--api_base, -ab <url>            # API endpoint
--api_key, -ak <key>             # API key
--api_version, -av <version>     # API version

# Behavior
--auto_run, -y                   # Skip code approval
--verbose, -v                    # Detailed logging
--debug                          # Debug mode
--loop                           # Autonomous mode
--offline, -o                    # Disable online features

# Display
--plain, -pl                     # Plain text output
--no_highlight_active_line, -nhl # Disable line highlighting
--multi_line, -ml                # Enable multi-line input

# Safety
--safe_mode <off|ask|auto>       # Code scanning
--max_output, -xo <int>          # Max output characters

# Profiles (shortcuts)
--profile, -p <name>             # Load profile
--fast, -f                       # Fast mode (gpt-4o-mini)
--local, -l                      # Local model setup
--vision, -vi                    # Vision mode
--os                             # OS control mode
--groq                           # Groq profile
--llama3                         # Llama3 profile
--codestral                      # Codestral profile
--assistant                      # Assistant profile

# Special commands
--profiles                       # Open profiles directory
--local_models                   # Open models directory
--conversations                  # List saved conversations
--reset_profile <name>           # Reset profile to default
--version                        # Show version
--server                         # Start server mode
--stdin, -s                      # Read from stdin

# LLM capabilities
--llm_supports_vision, -lsv      # Force vision support
--llm_supports_functions, -lsf   # Force function support

# Other
--custom_instructions, -ci <text>  # Add to system message
--system_message, -sm <text>       # Override system message
--disable_telemetry, -dt           # Opt out of analytics
--speak_messages, -sp              # TTS (Mac only)
--contribute_conversation          # Share for training
```

### Magic Commands

Available during interactive sessions:

```bash
%verbose [true/false]    # Toggle verbose mode
%reset                   # Clear conversation
%undo                    # Remove last exchange
%tokens [prompt]         # Calculate token usage
%help                    # Show help
```

### Interactive Features

**Multi-line Input:**
```bash
> """
Your multi-line
message here
"""
```

**Image Input:**
Drag and drop image files into terminal (auto-detected)

**Code Editing:**
When prompted to run code, type `e` to edit in $EDITOR

**History:**
Up/down arrows navigate command history

### Display Components

**MessageBlock** (`components/message_block.py`):
- Renders assistant messages
- Markdown formatting via Rich
- Streaming updates

**CodeBlock** (`components/code_block.py`):
- Syntax highlighting
- Active line highlighting
- Output display
- Execution status

---

## Server Mode

### AsyncInterpreter (`core/async_core.py`)

Extended UniShell with async capabilities and server interface.

#### Additional Attributes

```python
respond_thread: Thread          # Background response thread
stop_event: threading.Event     # Interrupt signal
output_queue: janus.Queue       # Async-safe queue
unsent_messages: deque          # Retry queue
id: str                         # Instance identifier
print: bool = False             # Console output
require_acknowledge: bool       # Message confirmation
acknowledged_outputs: list      # Confirmed message IDs
context_mode: bool = False      # Accumulate context
```

#### Key Methods

**async input(chunk)**
- Accumulate LMC chunks
- Handle commands (stop, go)
- Trigger response on "end" flag

**async output()**
- Get next output chunk from queue
- Async-safe

**respond(run_code=None)**
- Background thread execution
- Streams to output_queue
- Error handling and retries

**accumulate(chunk)**
- Build messages from chunks
- Handle start/content/end flags

### Server Class

**Endpoints:**

**WebSocket: `ws://host:port/`**
- Bidirectional streaming
- LMC message format
- Authentication via `{"auth": "key"}`
- Acknowledgment system (optional)

**REST: `POST /openai/chat/completions`**
- OpenAI-compatible API
- Streaming and non-streaming
- Special control tokens:
  - `{STOP}` - Interrupt execution
  - `{CONTEXT_MODE_ON}` - Accumulate context
  - `{CONTEXT_MODE_OFF}` - Respond immediately
  - `{AUTO_RUN_ON}` - Enable auto-run
  - `{AUTO_RUN_OFF}` - Disable auto-run
  - `{START}` - Begin response (context mode)

**Other Endpoints:**
- `GET /heartbeat` - Health check
- `GET /` - Web interface
- `POST /settings` - Update configuration
- `GET /settings/{setting}` - Get configuration
- `POST /run` - Execute code (if UNISHELL_INSECURE_ROUTES=true)
- `POST /upload` - Upload file (if UNISHELL_INSECURE_ROUTES=true)
- `GET /download/{filename}` - Download file (if UNISHELL_INSECURE_ROUTES=true)

**Environment Variables:**
```bash
UNISHELL_HOST=127.0.0.1          # Server host
UNISHELL_PORT=8000               # Server port
UNISHELL_API_KEY=<key>           # Authentication key
UNISHELL_REQUIRE_AUTH=True       # Require auth
UNISHELL_REQUIRE_ACKNOWLEDGE=True # Require message acks
UNISHELL_INSECURE_ROUTES=False   # Enable dangerous endpoints
```

**Starting Server:**
```bash
unishell --server
```

Or programmatically:
```python
from unishell import AsyncInterpreter

interpreter = AsyncInterpreter()
interpreter.server.run(host="0.0.0.0", port=8000)
```

---

## Configuration

### Profiles

Profiles are YAML or Python files in `~/.config/unishell/profiles/` (or `%APPDATA%\unishell\profiles\` on Windows).

**YAML Profile Example:**
```yaml
# fast.yaml
model: gpt-4o-mini
temperature: 0.0
custom_instructions: "Be extremely concise. No explanations."
auto_run: false
max_tokens: 1000
```

**Python Profile Example:**
```python
# local.py
unishell.llm.model = "ollama/codellama"
unishell.llm.api_base = "http://localhost:11434"
unishell.llm.context_window = 4096
unishell.llm.max_tokens = 1000

# Can run arbitrary Python
import os
print("Loading local model...")
```

**Built-in Profiles:**
- `default.yaml` - Default settings
- `fast.yaml` - GPT-4o-mini, concise
- `local.py` - Local model setup wizard
- `vision.yaml` - Vision-enabled model
- `os.py` - OS control mode
- `groq.py` - Groq API
- `llama3.py` - Llama3 via Ollama
- `codestral.py` - Codestral model
- `assistant.py` - Assistant mode

**Loading Profiles:**
```bash
unishell --profile fast.yaml
unishell -p local.py
```

### Environment Variables

```bash
# API Keys
OPENAI_API_KEY=<key>
ANTHROPIC_API_KEY=<key>
GROQ_API_KEY=<key>
GOOGLE_API_KEY=<key>

# Ollama
OLLAMA_HOST=http://localhost:11434

# Telemetry
DISABLE_TELEMETRY=true

# Computer API
UNISHELL_COMPUTER_API=False      # Prevent recursive import

# Debugging
UNISHELL_ACTIVE_LINE_DETECTION=True
UNISHELL_TERMINAL_INPUT_PATIENCE=15

# Server
UNISHELL_HOST=127.0.0.1
UNISHELL_PORT=8000
UNISHELL_API_KEY=<key>
UNISHELL_REQUIRE_AUTH=True
UNISHELL_REQUIRE_ACKNOWLEDGE=True
UNISHELL_INSECURE_ROUTES=False
UNISHELL_ID=<identifier>
UNISHELL_REQUIRE_AUTHENTICATION=False

# LiteLLM
LITELLM_LOCAL_MODEL_COST_MAP=True
```

---

## Message Format (LMC)

UniShell uses Language Model Communication (LMC) format internally.

### Message Structure

```python
{
    "role": str,        # "user", "assistant", "computer", "server"
    "type": str,        # "message", "code", "console", "image", "command", "confirmation", "error", "status", "review"
    "format": str,      # Language, output type, or image format
    "content": Any,     # Message content
    "start": bool,      # (optional) Start of message block
    "end": bool,        # (optional) End of message block
    "recipient": str,   # (optional) "user", "assistant"
    "id": str,          # (optional) Message ID for acknowledgment
}
```

### Message Types

**User Messages:**
```python
{"role": "user", "type": "message", "content": "Hello"}
{"role": "user", "type": "image", "format": "path", "content": "/path/to/image.png"}
{"role": "user", "type": "image", "format": "base64.png", "content": "<base64>"}
{"role": "user", "type": "command", "content": "stop"}  # Server mode
```

**Assistant Messages:**
```python
{"role": "assistant", "type": "message", "content": "I'll help you"}
{"role": "assistant", "type": "code", "format": "python", "content": "print('hello')"}
```

**Computer Messages:**
```python
{"role": "computer", "type": "console", "format": "output", "content": "hello\n"}
{"role": "computer", "type": "console", "format": "active_line", "content": 5}
{"role": "computer", "type": "image", "format": "base64.png", "content": "<base64>"}
{"role": "computer", "type": "code", "format": "html", "content": "<div>...</div>"}
{"role": "computer", "type": "confirmation", "format": "execution", "content": {...}}
```

**Server Messages:**
```python
{"role": "server", "type": "status", "content": "complete"}
{"role": "server", "type": "error", "content": "Error message"}
```

**Review Messages (Judge Layer):**
```python
{"type": "review", "format": "safe", "content": "Code is safe"}
{"type": "review", "format": "warning", "content": "Potential issue"}
{"type": "review", "format": "unsafe", "content": "Dangerous code"}
```

### Streaming Flags

Messages are streamed with start/end flags:

```python
# Start of code block
{"role": "assistant", "type": "code", "format": "python", "start": True}

# Content chunks
{"role": "assistant", "type": "code", "format": "python", "content": "print"}
{"role": "assistant", "type": "code", "format": "python", "content": "("}
{"role": "assistant", "type": "code", "format": "python", "content": "'hello'"}
{"role": "assistant", "type": "code", "format": "python", "content": ")"}

# End of code block
{"role": "assistant", "type": "code", "format": "python", "end": True}
```

### Recipient System

Messages can be directed to specific recipients:

```python
{"role": "computer", "type": "console", "format": "output", "content": "Debug info", "recipient": "assistant"}
# This output is only sent to the LLM, not displayed to user
```

Triggered by special markers in output:
```python
print("@@@RECIPIENT:assistant@@@Debug information")
# Everything after marker goes only to assistant
```

---

## Advanced Features

### Loop Mode

Autonomous task completion:

```python
unishell.loop = True
unishell.loop_message = "Proceed. If done, say 'The task is done.'"
unishell.loop_breakers = [
    "The task is done.",
    "The task is impossible.",
    "Please provide more information."
]
```

The LLM will continue working until it says one of the loop_breakers.

### Vision Handling

**Multimodal Models:**
- Images sent directly to LLM
- Automatic image trimming (keeps first and last 2)
- OS mode: Only keeps last 2 images

**Non-Vision Models:**
- Automatic image description via vision_renderer
- OCR extraction
- Formatted as text message

```python
unishell.llm.supports_vision = True  # Force enable
unishell.llm.vision_renderer = custom_function  # Custom renderer
```

### Skills System

Automatically save and reuse functions:

```python
# Enable skills
unishell.computer.save_skills = True
unishell.computer.import_skills = True
unishell.computer.skills.path = "/path/to/skills"

# Functions are automatically extracted and saved
def useful_function():
    """This will be saved"""
    pass
```

### Context Window Management

Automatic message trimming via tokentrim:

```python
unishell.llm.context_window = 8000
unishell.llm.max_tokens = 2000

# Messages automatically trimmed to fit:
# context_window - max_tokens - 25 (buffer)
```

### Output Truncation

Prevent overwhelming output:

```python
unishell.max_output = 2800  # Characters

# Output is truncated with message:
# "... (truncated)"
```

### Custom Instructions

Add to system message:

```python
unishell.custom_instructions = """
Always use type hints in Python.
Prefer functional programming.
"""
```

### Message Templates

Customize how messages are formatted:

```python
unishell.user_message_template = "{content}"
unishell.code_output_template = "Output: {content}\n\nWhat's next?"
unishell.empty_code_output_template = "No output. What's next?"
unishell.code_output_sender = "user"  # or "computer"
```

### Conversation History

```python
# Save conversations
unishell.conversation_history = True
unishell.conversation_history_path = "~/.config/unishell/conversations"

# Resume conversation
messages = json.load(open("conversation.json"))
unishell.messages = messages
unishell.chat()
```

### Sync Computer State

Share computer state between LLM's Python and your Python:

```python
unishell.sync_computer = True

# Computer settings are synced before/after code execution
```

---

## Security

### Safe Mode

Code scanning with Semgrep:

```bash
# Install semgrep
pip install semgrep

# Enable safe mode
unishell --safe_mode ask   # Prompt before scan
unishell --safe_mode auto  # Auto-scan
```

Scans for:
- SQL injection
- Command injection
- Path traversal
- Dangerous functions
- Security vulnerabilities

### Code Approval

Default behavior requires approval:

```bash
> unishell
Would you like to run this code? (y/n)
```

Bypass with:
```bash
unishell -y  # Auto-run
```

### Output Truncation

Prevents token exhaustion:
- Default: 2800 characters
- Configurable: `--max_output`

### API Key Security

Never hardcode keys:
```bash
export OPENAI_API_KEY=<key>
```

Or use profiles:
```yaml
# profile.yaml
api_key: ${OPENAI_API_KEY}
```

### Server Authentication

```bash
export UNISHELL_API_KEY=secret-key
unishell --server
```

Clients must send:
```python
headers = {"X-API-KEY": "secret-key"}
```

### Isolation

Run in containers:
```bash
docker run -it unishell/unishell
```

Or use E2B sandboxes (see docs).

---

## Development

### Project Setup

```bash
git clone https://github.com/UniShell/open-unishell.git
cd open-unishell
pip install -r requirements.txt
pip install -e .

# For development
pip install black isort pre-commit pytest
pre-commit install
```

### Running Tests

```bash
pytest tests/
```

### Code Style

```bash
black unishell/
isort unishell/
```

### Creating Custom Languages

```python
from unishell.core.computer.terminal.base_language import BaseLanguage

class MyLanguage(BaseLanguage):
    name = "mylang"
    file_extension = "ml"
    aliases = ["ml"]
    
    def __init__(self):
        # Setup
        pass
    
    def run(self, code):
        # Execute code
        yield {"type": "console", "format": "output", "content": "result"}
    
    def stop(self):
        # Interrupt
        pass
    
    def terminate(self):
        # Cleanup
        pass

# Add to terminal
unishell.computer.terminal.languages.append(MyLanguage)
```

### Creating Computer API Extensions

```python
class MyTool:
    def __init__(self, computer):
        self.computer = computer
    
    def my_method(self, arg):
        """Method description for LLM"""
        return "result"

# Add to computer
unishell.computer.mytool = MyTool(unishell.computer)
```

### Debugging

```bash
# Verbose mode
unishell --verbose

# Debug mode
unishell --debug

# Print OpenAI messages
unishell.debug = True
```

### Telemetry

Anonymous usage stats (opt-out):
```bash
unishell --disable_telemetry
# or
export DISABLE_TELEMETRY=true
```

Collected data:
- Event type (started_chat, errored)
- Message type (str, dict, list)
- OS mode (boolean)
- No message content
- No personal information

---

## Troubleshooting

### Common Issues

**"Model not found"**
```bash
# Check model name
unishell --model gpt-4o

# For Ollama, ensure model is pulled
ollama pull codellama
```

**"API key not found"**
```bash
export OPENAI_API_KEY=<key>
# or
unishell --api_key <key>
```

**"Context window exceeded"**
```bash
unishell --context_window 8000 --max_tokens 2000
```

**"Jupyter kernel not starting"**
```bash
pip install --upgrade ipykernel jupyter-client
```

**"Safe mode requires semgrep"**
```bash
pip install semgrep
```

**"Server dependencies not found"**
```bash
pip install "open-unishell[server]"
```

### Debug Information

```python
from unishell.core.utils.system_debug_info import system_info
system_info(unishell)
```

Prints:
- Python version
- OS information
- Package versions
- Model settings
- Error traceback

---

## API Reference

### Python API

```python
from unishell import unishell

# Basic usage
unishell.chat("Create a file")

# Streaming
for chunk in unishell.chat("Hello", stream=True):
    print(chunk)

# Non-blocking
unishell.chat("Long task", blocking=False)
new_messages = unishell.wait()

# Configuration
unishell.llm.model = "gpt-4o"
unishell.auto_run = True
unishell.custom_instructions = "Be concise"

# Reset
unishell.reset()

# Computer API
unishell.computer.display.screenshot()
unishell.computer.mouse.click(text="Button")
unishell.computer.keyboard.write("Hello")

# Direct code execution
output = unishell.computer.run("python", "print('hello')")
```

### CLI API

```bash
# One-shot command
unishell "create a file named test.txt"

# Interactive
unishell

# With options
unishell --model gpt-4o --auto_run --verbose

# Profile
unishell --profile fast.yaml

# Server
unishell --server --host 0.0.0.0 --port 8000
```

---

## Contributing

See [CONTRIBUTING.md](docs/CONTRIBUTING.md)

### Guidelines

1. Fork the repository
2. Create a feature branch
3. Write tests
4. Follow code style (black, isort)
5. Submit pull request

### Areas for Contribution

- New language support
- Computer API extensions
- Profile templates
- Documentation
- Bug fixes
- Performance improvements

---

## License

AGPL-3.0 - See [LICENSE](LICENSE)

---

## Links

- **Documentation**: https://docs.unishell.com/
- **GitHub**: https://github.com/UniShell/open-unishell
- **Discord**: https://discord.gg/Hvz9Axh84z
- **Desktop App**: https://0ggfznkwh4j.typeform.com/to/G21i9lJ2

---

## Acknowledgments

Built with:
- LiteLLM - Universal LLM interface
- Jupyter - Code execution
- Rich - Terminal formatting
- FastAPI - Server framework
- Selenium - Browser automation
- PyAutoGUI - GUI automation

---

**Note**: This is a comprehensive technical reference. For quick start guide, see [README.md](README.md).


## Modular Architecture (New)

### Overview

UniShell now includes a complete modular architecture for safe, deterministic action execution with LLM-based intent classification, policy authorization, transactional rollback, monitoring, and distributed task management.

### Architecture Components

```
unishell/core/
├── intent/                    # Intent classification & parameter extraction
│   ├── llm_intent_classifier.py # LLM → action_id mapping
│   └── llm_parameter_extractor.py # LLM → parameters
├── action_registry/           # Deterministic action definitions
│   ├── action_schema.py      # Pydantic schemas
│   ├── registry_impl.py      # JSON/YAML loading
│   └── actions/              # Action definitions
├── policy_engine/            # Authorization layer
│   ├── policy_decision.py    # Pydantic model
│   └── simple_policy_engine.py # RBAC + risk evaluation
├── execution/                # Safe OS abstraction
│   └── safe_os_adapter.py    # Path validation, dry-run
├── rollback/                 # Transactional control
│   ├── snapshot.py           # State capture
│   └── simple_rollback_manager.py # Rollback on failure
├── monitoring/               # Execution tracking
│   ├── execution_log.py      # Pydantic model
│   └── simple_monitoring_engine.py # Logging & statistics
└── gateway/                  # Orchestration & distribution
    ├── execution_orchestrator.py # Pipeline coordinator
    └── simple_gateway_orchestrator.py # Task queue
```

### Execution Pipeline

```
User Input → Intent Classification → Action Registry → Parameter Extraction
    → Policy Evaluation → Create Snapshot → Execute Action
    → Success: Commit + Log | Failure: Rollback + Log
```

### Key Features

- **Safety**: No eval/exec, path validation, dry-run default, RBAC, automatic rollback
- **Determinism**: JSON/YAML actions, Pydantic validation, predefined methods only
- **Observability**: Execution logging, success rate tracking, event filtering
- **Reliability**: Transactional execution, automatic rollback, error handling

### Quick Start

```python
from unishell.core.gateway import ExecutionOrchestrator
from unishell.core.intent import LLMIntentClassifier, LLMParameterExtractor
from unishell.core.action_registry import ActionRegistryImpl
from unishell.core.policy_engine import SimplePolicyEngine
from unishell.core.rollback import SimpleRollbackManager
from unishell.core.execution import SafeOSExecutionAdapter
from unishell.core.monitoring import SimpleMonitoringEngine

# Initialize components
orchestrator = ExecutionOrchestrator(
    LLMIntentClassifier(llm_client),
    LLMParameterExtractor(llm_client),
    ActionRegistryImpl(),
    SimplePolicyEngine(user_role="user"),
    SimpleRollbackManager(),
    SafeOSExecutionAdapter(),
    SimpleMonitoringEngine()
)

# Execute
result = orchestrator.execute("Move file from /tmp/a.txt to /tmp/b.txt")
```

### Testing

```bash
# Run all tests (69 tests)
python tests\test_action_registry_simple.py
python tests\test_intent_layer.py
python tests\test_execution_adapter.py
python tests\test_policy_engine.py
python tests\test_rollback_manager.py
python tests\test_monitoring_engine.py
python tests\test_orchestrator.py
python tests\test_gateway.py
```

### Documentation

See `FINAL_SUMMARY.md` for complete details on all 9 phases.

---
