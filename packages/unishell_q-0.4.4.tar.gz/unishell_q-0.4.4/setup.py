from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

with open("requirements.txt", "r", encoding="utf-8") as fh:
    requirements = [line.strip() for line in fh if line.strip() and not line.startswith("#")]

setup(
    name="unishell-q",
    version="0.4.4",
    description="Let language models run code with intelligent action system",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/QuantamAIDevelopment/unishell.git",
    packages=find_packages(),
    include_package_data=True,
    python_requires=">=3.9,<3.13",
    install_requires=requirements,
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    entry_points={
        "console_scripts": [
            "u=unishell.terminal_interface.start_terminal_interface:main",
            "unishell=unishell.terminal_interface.start_terminal_interface:main",
            "wtf=scripts.terminal_helper:main",
            "unishell-classic=unishell.terminal_interface.start_terminal_interface:main",
        ],
    },
)
