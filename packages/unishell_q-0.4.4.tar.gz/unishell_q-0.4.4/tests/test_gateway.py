"""Test gateway orchestrator."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from unishell.core.gateway import SimpleGatewayOrchestrator, TaskStatus

print("=== Gateway Orchestrator Tests ===\n")

# Initialize
gateway = SimpleGatewayOrchestrator()

print("=== Test 1: Register Devices ===")
result = gateway.register_device("device_1", {"type": "laptop"})
print(f"Success: {result['success']}")
print(f"Message: {result['message']}")

result = gateway.register_device("device_2", {"type": "server"})
print(f"Device 2: {result['success']}")

# Try duplicate
result = gateway.register_device("device_1")
print(f"Duplicate: {result['success']} - {result['message']}")
print()

print("=== Test 2: Queue Tasks ===")
task1 = gateway.queue_task("Move file from /tmp/a.txt to /tmp/b.txt")
print(f"Task 1 ID: {task1.task_id}")
print(f"Status: {task1.status}")
print(f"Input: {task1.user_input}")

task2 = gateway.queue_task("Delete file /tmp/old.log")
print(f"Task 2 ID: {task2.task_id}")
print()

print("=== Test 3: Fetch Task ===")
task = gateway.fetch_task("device_1")
print(f"Fetched Task: {task.task_id}")
print(f"Assigned to: {task.device_id}")
print(f"Status: {task.status}")
print(f"Input: {task.user_input}")
print()

print("=== Test 4: Acknowledge Task ===")
result = gateway.acknowledge_task(task.task_id, {
    "success": True,
    "message": "File moved successfully"
})
print(f"Success: {result['success']}")
print(f"Message: {result['message']}")

# Check task status
task = gateway.get_task(task.task_id)
print(f"Task status after ack: {task.status}")
print(f"Task result: {task.result}")
print()

print("=== Test 5: List Tasks by Status ===")
pending = gateway.list_tasks(TaskStatus.PENDING)
print(f"Pending tasks: {len(pending)}")
for t in pending:
    print(f"  - {t.task_id}: {t.user_input}")

completed = gateway.list_tasks(TaskStatus.COMPLETED)
print(f"Completed tasks: {len(completed)}")
for t in completed:
    print(f"  - {t.task_id}: {t.result.get('message')}")
print()

print("=== Test 6: List Devices ===")
devices = gateway.list_devices()
print(f"Registered devices: {len(devices)}")
for device in devices:
    print(f"  - {device['device_id']}: {device['metadata']}")
print()

print("=== Test 7: Get Statistics ===")
stats = gateway.get_statistics()
print(f"Total tasks: {stats['total_tasks']}")
print(f"Total devices: {stats['total_devices']}")
print(f"Pending: {stats['pending']}")
print(f"Assigned: {stats['assigned']}")
print(f"Completed: {stats['completed']}")
print(f"Failed: {stats['failed']}")
print()

print("=== Test 8: Multiple Device Workflow ===")
# Queue more tasks
for i in range(3):
    gateway.queue_task(f"Task {i+3}")

# Device 2 fetches task
task = gateway.fetch_task("device_2")
print(f"Device 2 fetched: {task.task_id}")

# Device 1 fetches another
task = gateway.fetch_task("device_1")
print(f"Device 1 fetched: {task.task_id}")

stats = gateway.get_statistics()
print(f"Pending: {stats['pending']}, Assigned: {stats['assigned']}")
print()

print("=== Test 9: Unregister Device ===")
result = gateway.unregister_device("device_1")
print(f"Success: {result['success']}")
print(f"Message: {result['message']}")

devices = gateway.list_devices()
print(f"Remaining devices: {len(devices)}")
print()

print("[SUCCESS] Gateway orchestrator tests complete!")
