"""Test policy engine."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from unishell.core.policy_engine import SimplePolicyEngine, PolicyDecision
from unishell.core.action_registry import ActionRegistryImpl

print("=== Policy Engine Tests ===\n")

# Load actions
registry = ActionRegistryImpl()
actions_dir = Path(__file__).parent.parent / "unishell" / "core" / "action_registry" / "actions"
for file in actions_dir.glob("*.json"):
    registry.load_from_file(str(file))

# Get test actions
file_move = registry.get_action("file.move")
file_delete = registry.get_action("file.delete")
system_restart = registry.get_action("system.restart")

print("=== Test 1: User Role - Sufficient Permissions ===")
policy = SimplePolicyEngine(user_role="user", environment="development")
decision = policy.evaluate(file_move, {"source": "/tmp/a.txt", "destination": "/tmp/b.txt"})
print(f"Action: file.move (requires: user)")
print(f"User Role: user")
print(f"Allowed: {decision.allowed}")
print(f"Reason: {decision.reason}")
print()

print("=== Test 2: User Role - Insufficient Permissions ===")
policy = SimplePolicyEngine(user_role="user", environment="development")
decision = policy.evaluate(system_restart, {})
print(f"Action: system.restart (requires: admin)")
print(f"User Role: user")
print(f"Allowed: {decision.allowed}")
print(f"Reason: {decision.reason}")
print()

print("=== Test 3: Admin Role - Has Permissions ===")
policy = SimplePolicyEngine(user_role="admin", environment="development")
decision = policy.evaluate(system_restart, {})
print(f"Action: system.restart (requires: admin)")
print(f"User Role: admin")
print(f"Allowed: {decision.allowed}")
print(f"Reason: {decision.reason}")
print()

print("=== Test 4: Critical Risk in Production ===")
policy = SimplePolicyEngine(user_role="admin", environment="production")
decision = policy.evaluate(system_restart, {})
print(f"Action: system.restart (risk: critical)")
print(f"Environment: production")
print(f"Allowed: {decision.allowed}")
print(f"Reason: {decision.reason}")
print()

print("=== Test 5: Critical Risk in Development ===")
policy = SimplePolicyEngine(user_role="admin", environment="development")
decision = policy.evaluate(system_restart, {})
print(f"Action: system.restart (risk: critical)")
print(f"Environment: development")
print(f"Allowed: {decision.allowed}")
print(f"Reason: {decision.reason}")
print()

print("=== Test 6: Missing Required Parameters ===")
policy = SimplePolicyEngine(user_role="user", environment="development")
decision = policy.evaluate(file_move, {"source": "/tmp/a.txt"})
print(f"Action: file.move (requires: source, destination)")
print(f"Parameters: {{'source': '/tmp/a.txt'}}")
print(f"Allowed: {decision.allowed}")
print(f"Reason: {decision.reason}")
print()

print("=== Test 7: High Risk in Production ===")
policy = SimplePolicyEngine(user_role="user", environment="production")
decision = policy.evaluate(file_delete, {"path": "/tmp/file.txt"})
print(f"Action: file.delete (risk: high)")
print(f"Environment: production")
print(f"Allowed: {decision.allowed}")
print(f"Reason: {decision.reason}")
print()

print("=== Test 8: Path Safety Check - System Path ===")
policy = SimplePolicyEngine(user_role="admin", environment="production")
decision = policy.check_path_safety("/etc/passwd")
print(f"Path: /etc/passwd")
print(f"Environment: production")
print(f"Allowed: {decision.allowed}")
print(f"Reason: {decision.reason}")
print()

print("=== Test 9: Path Safety Check - Safe Path ===")
policy = SimplePolicyEngine(user_role="user", environment="production")
decision = policy.check_path_safety("/home/user/file.txt")
print(f"Path: /home/user/file.txt")
print(f"Environment: production")
print(f"Allowed: {decision.allowed}")
print(f"Reason: {decision.reason}")
print()

print("=== Test 10: Role Hierarchy ===")
policy = SimplePolicyEngine(user_role="public", environment="development")
decision = policy.evaluate(file_move, {"source": "/tmp/a.txt", "destination": "/tmp/b.txt"})
print(f"Action: file.move (requires: user)")
print(f"User Role: public")
print(f"Allowed: {decision.allowed}")
print(f"Reason: {decision.reason}")
print()

print("=== Test 11: Dynamic Role Change ===")
policy = SimplePolicyEngine(user_role="user", environment="development")
print(f"Initial role: user")
decision = policy.evaluate(system_restart, {})
print(f"  system.restart allowed: {decision.allowed}")

policy.set_user_role("admin")
print(f"Changed role to: admin")
decision = policy.evaluate(system_restart, {})
print(f"  system.restart allowed: {decision.allowed}")
print()

print("=== Test 12: Dynamic Environment Change ===")
policy = SimplePolicyEngine(user_role="admin", environment="development")
print(f"Initial environment: development")
decision = policy.evaluate(system_restart, {})
print(f"  system.restart allowed: {decision.allowed}")

policy.set_environment("production")
print(f"Changed environment to: production")
decision = policy.evaluate(system_restart, {})
print(f"  system.restart allowed: {decision.allowed}")
print()

print("[SUCCESS] All policy engine tests complete!")
