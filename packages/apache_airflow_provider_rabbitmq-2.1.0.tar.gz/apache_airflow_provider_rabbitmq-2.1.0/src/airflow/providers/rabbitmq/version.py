import os

__version__ = os.getenv("PACKAGE_VERSION", "2.0.0")
