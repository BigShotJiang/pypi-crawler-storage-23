# Apache Airflow Provider for RabbitMQ
"""
This is the Apache Airflow Provider for RabbitMQ.
It provides hooks, operators, and sensors for interacting with RabbitMQ.
"""

__version__ = "0.1.0"
