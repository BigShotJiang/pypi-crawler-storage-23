#!/usr/bin/env python3
from __future__ import annotations

import os
import platform
import shutil
import socket
import stat
import subprocess
import tarfile
import tempfile
import urllib.request
import zipfile
from contextlib import contextmanager
from pathlib import Path

from reflex.reflex import cli as reflex_cli

BUN_VERSION = "1.3.6"
MIN_NODE_VERSION = "20.19.0"
MIN_NODE_VERSION_PROD_SINGLE_PORT = "22.14.0"
DEFAULT_FRONTEND_PORT = 3000
DEFAULT_BACKEND_PORT = 8000
SUPPORTED_RUN_MODES = {"dev", "prod-single-port"}
SUPPORTED_TRANSPORTS = {"websocket", "polling"}


def run(cmd: list[str], env: dict[str, str] | None = None, cwd: Path | None = None) -> None:
    subprocess.run(cmd, check=True, env=env, cwd=str(cwd) if cwd else None)


def app_dir() -> Path:
    return Path(__file__).resolve().parent


def parse_port(value: str, label: str) -> int:
    try:
        port = int(value)
    except ValueError as exc:
        raise ValueError(f"{label} must be an integer, got: {value!r}") from exc
    if not (1 <= port <= 65535):
        raise ValueError(f"{label} must be between 1 and 65535, got: {port}")
    return port


def ensure_port_available(port: int, label: str) -> None:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("0.0.0.0", port))
        except OSError as exc:
            if label == "Single":
                env_hint = "REFLEX_SINGLE_PORT"
            else:
                env_hint = "REFLEX_FRONTEND_PORT/REFLEX_BACKEND_PORT"
            raise RuntimeError(
                f"{label} port {port} is already in use. Stop the existing process "
                f"or set a different port via {env_hint}."
            ) from exc


def resolve_reflex_ports() -> tuple[int, int]:
    frontend_port = parse_port(
        os.environ.get("REFLEX_FRONTEND_PORT", str(DEFAULT_FRONTEND_PORT)),
        "REFLEX_FRONTEND_PORT",
    )
    backend_port = parse_port(
        os.environ.get("REFLEX_BACKEND_PORT", str(DEFAULT_BACKEND_PORT)),
        "REFLEX_BACKEND_PORT",
    )
    if frontend_port == backend_port:
        raise ValueError(
            "REFLEX_FRONTEND_PORT and REFLEX_BACKEND_PORT must be different in dev mode."
        )
    ensure_port_available(frontend_port, "Frontend")
    ensure_port_available(backend_port, "Backend")
    return frontend_port, backend_port


def resolve_single_port() -> int:
    port_value = os.environ.get("REFLEX_SINGLE_PORT")
    if not port_value:
        port_value = os.environ.get("REFLEX_FRONTEND_PORT", str(DEFAULT_FRONTEND_PORT))
    port = parse_port(port_value, "REFLEX_SINGLE_PORT")
    ensure_port_available(port, "Single")
    return port


def resolve_run_mode() -> str:
    run_mode = os.environ.get("REFLEX_RUN_MODE")
    if run_mode:
        if run_mode not in SUPPORTED_RUN_MODES:
            supported = ", ".join(sorted(SUPPORTED_RUN_MODES))
            raise ValueError(
                f"REFLEX_RUN_MODE must be one of [{supported}], got: {run_mode!r}"
            )
        return run_mode
    if os.environ.get("CODESPACES") == "true":
        return "prod-single-port"
    return "dev"


def resolve_transport() -> str:
    transport = os.environ.get("REFLEX_TRANSPORT")
    if transport:
        transport = transport.lower()
        if transport not in SUPPORTED_TRANSPORTS:
            supported = ", ".join(sorted(SUPPORTED_TRANSPORTS))
            raise ValueError(
                f"REFLEX_TRANSPORT must be one of [{supported}], got: {transport!r}"
            )
        return transport
    if os.environ.get("CODESPACES") == "true":
        return "polling"
    return "websocket"


def should_use_bun() -> bool:
    return os.environ.get("REFLEX_USE_NPM", "").lower() != "true"


@contextmanager
def scoped_process_context(env: dict[str, str], cwd: Path):
    original_env = os.environ.copy()
    original_cwd = Path.cwd()
    os.environ.clear()
    os.environ.update(env)
    os.chdir(cwd)
    try:
        yield
    finally:
        os.chdir(original_cwd)
        os.environ.clear()
        os.environ.update(original_env)


def runtime_base_dir() -> Path:
    if os.name == "nt":
        local_app_data = os.environ.get("LOCALAPPDATA")
        if local_app_data:
            return Path(local_app_data) / "reflex-pdf-app"
    xdg_cache_home = os.environ.get("XDG_CACHE_HOME")
    if xdg_cache_home:
        return Path(xdg_cache_home) / "reflex-pdf-app"
    return Path.home() / ".cache" / "reflex-pdf-app"


def build_runtime_env(base: Path) -> dict[str, str]:
    reflex_dir = base / "reflex"
    web_dir = base / "web"
    states_dir = base / "states"
    (reflex_dir / "bun" / "bin").mkdir(parents=True, exist_ok=True)

    env = os.environ.copy()
    env["REFLEX_DIR"] = str(reflex_dir)
    env["REFLEX_WEB_WORKDIR"] = str(web_dir)
    env["REFLEX_STATES_WORKDIR"] = str(states_dir)
    return env


def make_executable(path: Path) -> None:
    mode = path.stat().st_mode
    path.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)


def download_file(url: str, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    with urllib.request.urlopen(url) as response, destination.open("wb") as out_file:
        shutil.copyfileobj(response, out_file)


def bun_target() -> str:
    system = platform.system()
    machine = platform.machine().lower()

    if system == "Linux":
        if machine in {"x86_64", "amd64"}:
            target = "linux-x64"
        elif machine in {"aarch64", "arm64"}:
            target = "linux-aarch64"
        else:
            raise RuntimeError(f"Unsupported platform for bun bootstrap: {system}/{machine}")
        if Path("/etc/alpine-release").exists():
            target += "-musl"
        return target

    if system == "Darwin":
        if machine in {"x86_64", "amd64"}:
            return "darwin-x64"
        if machine in {"arm64", "aarch64"}:
            return "darwin-aarch64"
        raise RuntimeError(f"Unsupported platform for bun bootstrap: {system}/{machine}")

    if system == "Windows":
        if machine in {"x86_64", "amd64"}:
            return "windows-x64"
        if machine in {"arm64", "aarch64"}:
            return "windows-aarch64"
        raise RuntimeError(f"Unsupported platform for bun bootstrap: {system}/{machine}")

    raise RuntimeError(f"Unsupported platform for bun bootstrap: {system}/{machine}")


def ensure_bun(reflex_dir: Path) -> None:
    target = bun_target()
    is_windows = target.startswith("windows-")
    bun_bin = reflex_dir / "bun" / "bin" / ("bun.exe" if is_windows else "bun")

    if bun_bin.exists():
        return

    bun_root = reflex_dir / "bun" / "bin"
    zip_name = f"bun-{target}.zip"
    zip_path = bun_root / zip_name
    bun_url = f"https://github.com/oven-sh/bun/releases/download/bun-v{BUN_VERSION}/{zip_name}"

    download_file(bun_url, zip_path)

    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(bun_root)

    extracted_dir = bun_root / f"bun-{target}"
    extracted_bin = extracted_dir / ("bun.exe" if is_windows else "bun")
    if not extracted_bin.exists():
        raise RuntimeError(f"bun binary was not found after extracting {zip_name}")

    shutil.move(str(extracted_bin), str(bun_bin))
    if not is_windows:
        make_executable(bun_bin)


def parse_semver(version: str) -> tuple[int, int, int]:
    parts = version.split(".")
    return tuple(int(x) for x in parts[:3])  # type: ignore[return-value]


def node_target() -> str:
    system = platform.system()
    machine = platform.machine().lower()

    if system == "Linux":
        if machine in {"x86_64", "amd64"}:
            return "linux-x64"
        if machine in {"aarch64", "arm64"}:
            return "linux-arm64"
    elif system == "Darwin":
        if machine in {"x86_64", "amd64"}:
            return "darwin-x64"
        if machine in {"aarch64", "arm64"}:
            return "darwin-arm64"
    elif system == "Windows":
        if machine in {"x86_64", "amd64"}:
            return "win-x64"
        if machine in {"aarch64", "arm64"}:
            return "win-arm64"

    raise RuntimeError(f"Unsupported platform for Node bootstrap: {system}/{machine}")


def node_bin_path(node_root: Path) -> Path:
    if os.name == "nt":
        return node_root / "node.exe"
    return node_root / "bin" / "node"


def has_compatible_system_node(minimum_version: str) -> bool:
    node_path = shutil.which("node")
    if not node_path:
        return False

    try:
        output = subprocess.check_output([node_path, "-v"], text=True).strip()
    except subprocess.CalledProcessError:
        return False

    current = parse_semver(output.removeprefix("v"))
    minimum = parse_semver(minimum_version)
    return current >= minimum


def ensure_node(
    runtime_dir: Path, env: dict[str, str], minimum_version: str = MIN_NODE_VERSION
) -> dict[str, str]:
    if has_compatible_system_node(minimum_version):
        return env

    target = node_target()
    node_dir_name = f"node-v{minimum_version}-{target}"
    node_root = runtime_dir / f"node-v{minimum_version}"
    node_bin = node_bin_path(node_root)

    if not node_bin.exists():
        with tempfile.TemporaryDirectory() as tmp_dir:
            tmp_path = Path(tmp_dir)
            if target.startswith("win-"):
                archive_name = f"{node_dir_name}.zip"
                archive_path = tmp_path / archive_name
                url = f"https://nodejs.org/dist/v{minimum_version}/{archive_name}"
                download_file(url, archive_path)
                with zipfile.ZipFile(archive_path) as zf:
                    zf.extractall(tmp_path)
            else:
                archive_name = f"{node_dir_name}.tar.xz"
                archive_path = tmp_path / archive_name
                url = f"https://nodejs.org/dist/v{minimum_version}/{archive_name}"
                download_file(url, archive_path)
                with tarfile.open(archive_path, mode="r:xz") as tf:
                    tf.extractall(tmp_path)

            extracted_dir = tmp_path / node_dir_name
            if not extracted_dir.exists():
                raise RuntimeError(f"Failed to extract Node archive: {archive_name}")

            if node_root.exists():
                shutil.rmtree(node_root)
            shutil.move(str(extracted_dir), str(node_root))

    env = env.copy()
    env["PATH"] = (
        f"{node_root}{os.pathsep}{env.get('PATH', '')}"
        if os.name == "nt"
        else f"{node_root / 'bin'}{os.pathsep}{env.get('PATH', '')}"
    )
    return env


def main(setup_only=False) -> None:
    runtime_dir = runtime_base_dir()
    run_mode = resolve_run_mode()
    transport = resolve_transport()
    frontend_port: int | None = None
    backend_port: int | None = None
    single_port: int | None = None
    required_node_version = MIN_NODE_VERSION_PROD_SINGLE_PORT
    if run_mode == "dev":
        required_node_version = MIN_NODE_VERSION
    if not setup_only:
        if run_mode == "dev":
            frontend_port, backend_port = resolve_reflex_ports()
        else:
            single_port = resolve_single_port()

    env = build_runtime_env(runtime_dir)
    env["REFLEX_TRANSPORT"] = transport
    if should_use_bun():
        ensure_bun(Path(env["REFLEX_DIR"]))
    env = ensure_node(runtime_dir, env, required_node_version)

    if not setup_only:
        with scoped_process_context(env=env, cwd=app_dir()):
            if run_mode == "dev":
                assert frontend_port is not None
                assert backend_port is not None
                reflex_cli(
                    args=[
                        "run",
                        "--frontend-port",
                        str(frontend_port),
                        "--backend-port",
                        str(backend_port),
                        "--backend-host",
                        "0.0.0.0",
                    ],
                    standalone_mode=False,
                )
            else:
                assert single_port is not None
                reflex_cli(
                    args=[
                        "run",
                        "--env",
                        "prod",
                        "--single-port",
                        "--frontend-port",
                        str(single_port),
                        "--backend-port",
                        str(single_port),
                        "--backend-host",
                        "0.0.0.0",
                    ],
                    standalone_mode=False,
                )


if __name__ == "__main__":
    main()
