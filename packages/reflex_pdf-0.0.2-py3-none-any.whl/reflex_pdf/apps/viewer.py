import reflex as rx
from typing import Any
from urllib.parse import parse_qsl
from reflex_pdf import Document, Page


QUERY_PARAM_WARNING = (
    "At most one query parameter is supported (?pdf=<url_encoded_pdf_url>). "
    "If your PDF URL contains query arguments, URL encode the entire value."
)


def validate_pdf_query(search: str) -> tuple[str, str]:
    params = parse_qsl(search.lstrip("?"), keep_blank_values=True)
    if len(params) > 1:
        return "", QUERY_PARAM_WARNING
    if len(params) == 1 and params[0][0] == "pdf":
        return params[0][1], ""
    return "", ""


class State(rx.State):
    n_pages: int = 1
    current_page: int = 1
    pdf_url: str = ""
    pdf_error: str = ""
    query_param_warning: str = ""

    @rx.event
    def initialize_from_query(self):
        pdf_url, warning = validate_pdf_query(self.router.url.query)
        self.pdf_url = pdf_url.strip()
        self.query_param_warning = warning
        self.current_page = 1

    @rx.event
    def set_pdf_url(self, url: str):
        self.pdf_url = url.strip()
        self.current_page = 1
        self.pdf_error = ""

    @rx.event
    def load_success(self, info: dict):
        self.n_pages = info.get("numPages", 1)
        self.current_page = 1
        self.pdf_error = ""

    @rx.event
    def load_error(self, error: Any):
        self.pdf_error = str(error)

    @rx.event
    def prev_page(self):
        self.current_page = max(1, self.current_page - 1)

    @rx.event
    def next_page(self):
        self.current_page = min(self.n_pages, self.current_page + 1)


def page_control():
    return rx.hstack(
        rx.button(
            "<", on_click=State.prev_page, is_disabled=State.current_page <= 1
        ),
        rx.text(f"{State.current_page} / {State.n_pages}"),
        rx.button(
            ">",
            on_click=State.next_page,
            is_disabled=State.current_page >= State.n_pages,
        ),
    )


def mfe_bridge() -> rx.Component:
    return rx.fragment(
        rx.input(
            id="pdf-url-bridge-input",
            value=State.pdf_url,
            on_change=State.set_pdf_url,
            display="none",
        ),
        rx.text(
            State.query_param_warning,
            color="crimson",
            font_size="0.9rem",
            margin_bottom="0.5rem",
        ),
        # Support URL Modification
        rx.script(
            """
            (() => {
              if (window.__reflexPdfBridgeBound) return;
              window.__reflexPdfBridgeBound = true;

              const applyUrl = (url) => {
                if (typeof url !== "string") return;
                const input = document.getElementById("pdf-url-bridge-input");
                if (!input) return;

                const setter = Object.getOwnPropertyDescriptor(
                  window.HTMLInputElement.prototype,
                  "value",
                )?.set;
                if (!setter) return;

                setter.call(input, url);
                input.dispatchEvent(new Event("input", { bubbles: true }));
                input.dispatchEvent(new Event("change", { bubbles: true }));
              };

              window.addEventListener("message", (event) => {
                const data = event?.data;
                if (!data || data.type !== "reflex-pdf:set-url") return;
                applyUrl(data.url);
              });
            })();
            """
        ),
    )


def index() -> rx.Component:
    return rx.container(
        rx.color_mode.button(position="top-right"),
        mfe_bridge(),
        rx.vstack(
            page_control(),
            rx.cond(
                State.pdf_error != "",
                rx.text(
                    f"{State.pdf_error}. If this is a remote URL, ensure the server allows CORS.",
                    color="crimson",
                    font_size="0.9rem",
                ),
            ),
            Document.create(
                Page.create(
                    page_number=State.current_page,
                ),
                file=State.pdf_url,
                error="Failed to load PDF. If this is a remote URL, ensure it allows CORS.",
                on_load_success=State.load_success,
                on_load_error=State.load_error,
            ),
            page_control(),
            align="center",
            spacing="4",
        ),
    )


app = rx.App()
app.add_page(index, on_load=State.initialize_from_query)
