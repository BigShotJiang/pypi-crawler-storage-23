"""TUI components for dashboard."""
