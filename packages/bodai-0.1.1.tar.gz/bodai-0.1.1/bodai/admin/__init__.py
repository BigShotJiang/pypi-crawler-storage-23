"""Admin tools: IPython shell."""
