"""Core functionality: config, health, operations."""
