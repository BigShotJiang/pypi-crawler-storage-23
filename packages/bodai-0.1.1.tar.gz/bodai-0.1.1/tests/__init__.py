"""Tests for Bodai."""
