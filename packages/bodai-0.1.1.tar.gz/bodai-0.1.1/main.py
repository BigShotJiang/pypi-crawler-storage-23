def main() -> None:
    """Entry point for the bodai CLI."""
    print("Hello from bodai!")


if __name__ == "__main__":
    main()
