#!/bin/sh
set -e

# Skip repo operations when using a local/bundled chart
case "${ILUM_CHART_REF:-}" in
  /*)
    echo "Using bundled chart at ${ILUM_CHART_REF}, skipping repo setup."
    ;;
  *)
    ILUM_HELM_REPO_URL="${ILUM_HELM_REPO_URL:-https://charts.ilum.cloud}"
    helm repo add ilum "$ILUM_HELM_REPO_URL" --force-update 2>/dev/null || true
    helm repo update ilum 2>/dev/null || true
    ;;
esac

exec ilum-api "$@"
