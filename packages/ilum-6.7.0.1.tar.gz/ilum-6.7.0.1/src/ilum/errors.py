"""Typed exception hierarchy for the Ilum CLI."""

from __future__ import annotations


class IlumError(Exception):
    """Base exception for all Ilum CLI errors."""

    def __init__(
        self,
        message: str,
        suggestion: str = "",
        *,
        error_code: str = "",
        recovery_steps: list[str] | tuple[str, ...] = (),
    ) -> None:
        super().__init__(message)
        self.suggestion = suggestion
        self.error_code = error_code
        self.recovery_steps = list(recovery_steps)


class PrerequisiteError(IlumError):
    """A required tool or resource is missing."""


class ClusterConnectionError(IlumError):
    """Cannot connect to the Kubernetes cluster."""


class HelmError(IlumError):
    """A Helm operation failed."""


class HelmTimeoutError(HelmError):
    """A Helm operation timed out."""


class HelmReleaseError(HelmError):
    """A Helm release is in a bad state (e.g. pending-install, pending-upgrade)."""


class ConfigError(IlumError):
    """Configuration is missing or invalid."""


class ValuesError(IlumError):
    """Problem with Helm values files."""


class ModuleError(IlumError):
    """Module dependency or conflict error."""


class ReleaseExistsError(IlumError):
    """A Helm release already exists when a fresh install was requested."""


class ReleaseNotFoundError(IlumError):
    """A Helm release was expected but does not exist."""


class AuthError(IlumError):
    """Authentication configuration error."""
