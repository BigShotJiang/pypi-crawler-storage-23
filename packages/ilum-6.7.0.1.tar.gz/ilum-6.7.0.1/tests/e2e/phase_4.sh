#!/usr/bin/env bash
# =============================================================================
# Phase 4: Status/Info Commands
# =============================================================================
# Test status, module status, logs, history against live deployment.
# =============================================================================

print_phase "Phase 4: Status/Info Commands"

# Ensure we're connected
if ! "$ILUM" config show &>/dev/null; then
    log_info "No config found, connecting first..."
    "$ILUM" connect --release "$HELM_RELEASE" --namespace "$HELM_NAMESPACE" --yes 2>/dev/null || true
fi

# ---- Status command ----

run_test "P4-001" "status shows deployment info" "$ILUM" status
assert_exit_code 0 || true

run_test "P4-002" "status --no-pods" "$ILUM" status --no-pods
assert_exit_code 0 || true

run_test "P4-003" "status --no-modules" "$ILUM" status --no-modules
assert_exit_code 0 || true

run_test "P4-004" "status -o json" "$ILUM" --output json status
assert_exit_code 0 || true
# Verify it's valid JSON if exit was 0
if [[ "$LAST_EXIT_CODE" -eq 0 && -n "$LAST_STDOUT" ]]; then
    run_test "P4-004b" "status JSON is valid" echo "$LAST_STDOUT"
    # Re-read the saved stdout for JSON validation
    LAST_STDOUT=$(cat "$TEST_LOG_DIR/P4-004/stdout.txt")
    assert_json_valid || {
        log_issue "BUG" "medium" "P4-004b" "status -o json produces invalid JSON"
        true
    }
fi

run_test "P4-005" "status -o yaml" "$ILUM" --output yaml status
assert_exit_code 0 || true

run_test "P4-006" "status --release nonexistent" "$ILUM" status --release nonexistent_release
assert_exit_code_not 0 || true

# ---- Module status ----

run_test "P4-007" "module status" "$ILUM" module status
assert_exit_code 0 || true

run_test "P4-008" "module status --category core" "$ILUM" module status --category core
assert_exit_code 0 || true

run_test "P4-009" "module status -o json" "$ILUM" --output json module status
assert_exit_code 0 || true

# ---- Logs ----

run_test "P4-010" "logs core" "$ILUM" logs core
assert_exit_code 0 || true

run_test "P4-011" "logs core --tail 10" "$ILUM" logs core --tail 10
assert_exit_code 0 || true

run_test "P4-012" "logs ui" "$ILUM" logs ui
assert_exit_code 0 || true

run_test "P4-013" "logs nonexistent module" "$ILUM" logs nonexistent_module
assert_exit_code_not 0 || true

# Logs for a disabled module
run_test "P4-014" "logs for disabled module (airflow)" "$ILUM" logs airflow
# Should fail since airflow is disabled
if [[ "$LAST_EXIT_CODE" -ne 0 ]]; then
    PASSED_TESTS=$((PASSED_TESTS + 1))
    print_pass "P4-014 — logs for disabled module fails properly"
    echo "PASS" > "$TEST_LOG_DIR/P4-014/result.txt"
else
    log_issue "UX" "low" "P4-014" "logs for disabled module does not fail"
    PASSED_TESTS=$((PASSED_TESTS + 1))
    print_pass "P4-014 — logs for disabled module (may show empty)"
    echo "PASS" > "$TEST_LOG_DIR/P4-014/result.txt"
fi

run_test "P4-015" "logs --previous core" "$ILUM" logs core --previous
# May fail if no previous container — that's OK
if [[ "$LAST_EXIT_CODE" -eq 0 ]]; then
    PASSED_TESTS=$((PASSED_TESTS + 1))
    print_pass "P4-015 — logs --previous succeeded"
    echo "PASS" > "$TEST_LOG_DIR/P4-015/result.txt"
else
    PASSED_TESTS=$((PASSED_TESTS + 1))
    print_pass "P4-015 — logs --previous fails (no previous container, expected)"
    echo "PASS" > "$TEST_LOG_DIR/P4-015/result.txt"
fi

# ---- History ----

run_test "P4-016" "history shows entries" "$ILUM" history
assert_exit_code 0 || true

run_test "P4-017" "history --last 5" "$ILUM" history --last 5
assert_exit_code 0 || true

run_test "P4-018" "history -o json" "$ILUM" --output json history
assert_exit_code 0 || true

run_test "P4-019" "history --operation install" "$ILUM" history --operation install
assert_exit_code 0 || true

# ---- Security checks ----

# Check that status output doesn't leak passwords
run_test "P4-020" "status output security check" "$ILUM" status
assert_not_contains "CHANGEMEPLEASE" || {
    log_issue "SECURITY" "high" "P4-020" "status output contains default password placeholder"
    true
}

# Check logs output for secrets
run_test "P4-021" "logs output security check" "$ILUM" logs core --tail 50
assert_not_contains "CHANGEMEPLEASE" || {
    log_issue "SECURITY" "medium" "P4-021" "logs output contains default password placeholder"
    true
}

# ---- Performance ----

run_test "P4-022" "status command performance" "$ILUM" status
assert_duration_under 30000 || {
    log_issue "PERF" "medium" "P4-022" "status command took ${LAST_DURATION}ms (>30s)"
    true
}

log_info "Phase 4 complete — status/info commands tested"
