#!/usr/bin/env bash
# =============================================================================
# Phase 10: Full Lifecycle Regression
# =============================================================================
# Complete cleanup → init → install → status → module changes → upgrade →
# history → uninstall → verify clean state.
# =============================================================================

print_phase "Phase 10: Full Lifecycle Regression"

# ---- Complete cleanup ----

log_info "Full cleanup for lifecycle test..."
cleanup_config

# Make sure no release exists
helm uninstall "$HELM_RELEASE" -n "$HELM_NAMESPACE" 2>/dev/null || true
sleep 5

# Clean PVCs from previous runs
cleanup_pvcs "$HELM_NAMESPACE"
sleep 3

# ---- Fresh init ----

run_test "P10-001" "fresh init --yes" "$ILUM" init --yes
assert_exit_code 0 || true

# ---- Connect to set up release/namespace info ----

# Use connect to properly link the CLI to the cluster (even if no release exists yet)
run_test "P10-002" "set release/namespace via config set" bash -c "$ILUM config set active_profile default 2>/dev/null; echo done"
assert_exit_code 0 || true

# ---- Install (minimal) ----

run_test "P10-003" "install --yes (minimal, core+ui+mongodb+minio)" "$ILUM" install --yes --timeout 15m
if [[ "$LAST_EXIT_CODE" -ne 0 ]]; then
    log_issue "BUG" "high" "P10-003" "install failed: exit $LAST_EXIT_CODE"
    FAILED_TESTS=$((FAILED_TESTS + 1))
    print_fail "P10-003 — install failed"
    echo "FAIL" > "$TEST_LOG_DIR/P10-003/result.txt"
    FAILURES+=("P10-003: install failed")

    # Try to continue anyway — maybe it partially deployed
    log_warn "Install failed, skipping remaining lifecycle tests"
    skip_test "P10-004" "wait for pods" "install failed"
    skip_test "P10-005" "status after install" "install failed"
    skip_test "P10-006" "module enable jupyter" "install failed"
    skip_test "P10-007" "logs jupyter" "install failed"
    skip_test "P10-008" "module disable jupyter" "install failed"
    skip_test "P10-009" "upgrade --set" "install failed"
    skip_test "P10-010" "history" "install failed"
    skip_test "P10-011" "uninstall --delete-data" "install failed"
    log_info "Phase 10 aborted due to install failure"
    return 0
else
    assert_exit_code 0 || true
fi

# ---- Wait for pods ----

run_test "P10-004" "wait for pods after install" bash -c "sleep 30 && kubectl get pods -n $HELM_NAMESPACE --no-headers | head -20"
# Give 30s and then check — we don't need all pods ready, just some
assert_exit_code 0 || true

# ---- Status ----

run_test "P10-005" "status after fresh install" "$ILUM" status
assert_exit_code 0 || true

# ---- Module enable jupyter ----

run_test "P10-006" "module enable jupyter --yes" "$ILUM" module enable jupyter --yes --timeout 15m
assert_exit_code 0 || {
    log_issue "BUG" "medium" "P10-006" "module enable jupyter failed"
    true
}

# ---- Logs jupyter ----

if [[ "$LAST_EXIT_CODE" -eq 0 ]]; then
    sleep 30  # Give jupyter time to start
    run_test "P10-007" "logs jupyter" "$ILUM" logs jupyter --tail 20
    assert_exit_code 0 || true
else
    skip_test "P10-007" "logs jupyter" "jupyter enable failed"
fi

# ---- Module disable jupyter ----

run_test "P10-008" "module disable jupyter --yes" "$ILUM" module disable jupyter --yes --timeout 15m
assert_exit_code 0 || true

# ---- Upgrade with --set ----

run_test "P10-009" "upgrade --set custom value --yes" "$ILUM" upgrade --set ilum-core.replicaCount=1 --yes --timeout 15m
assert_exit_code 0 || true

# ---- History ----

run_test "P10-010" "history shows lifecycle operations" "$ILUM" history
assert_exit_code 0 || true

# ---- Uninstall with --delete-data ----

run_test "P10-011" "uninstall --delete-data --yes" "$ILUM" uninstall --delete-data --yes
assert_exit_code 0 || true

# ---- Verify clean state ----

sleep 10

# Check no helm release
if helm status "$HELM_RELEASE" -n "$HELM_NAMESPACE" &>/dev/null; then
    log_issue "BUG" "high" "P10-011" "Release still exists after uninstall --delete-data"
fi

log_info "Phase 10 complete — full lifecycle regression tested"
