#!/usr/bin/env bash
# =============================================================================
# Phase 3: Connect
# =============================================================================
# Test connecting the CLI to existing Ilum installations.
# =============================================================================

print_phase "Phase 3: Connect"

# Save and clean config for fresh connect tests
backup_config
cleanup_config

# ---- Connect auto-detect ----

run_test "P3-001" "connect --yes auto-detect" "$ILUM" connect --yes
assert_exit_code 0 || true

run_test "P3-002" "config show after connect" "$ILUM" config show
assert_exit_code 0 || true

# ---- Connect with explicit release/namespace ----

cleanup_config

run_test "P3-003" "connect with explicit release and namespace" "$ILUM" connect --release "$HELM_RELEASE" --namespace "$HELM_NAMESPACE" --yes
assert_exit_code 0 || true

# ---- Connect to nonexistent release ----

cleanup_config

run_test "P3-004" "connect to nonexistent release" "$ILUM" connect --release nonexistent_release_xyz --namespace "$HELM_NAMESPACE" --yes
assert_exit_code_not 0 || true

# ---- Connect with wrong namespace ----

cleanup_config

run_test "P3-005" "connect with wrong namespace" "$ILUM" connect --release "$HELM_RELEASE" --namespace wrong_namespace_xyz --yes
assert_exit_code_not 0 || true

# ---- Connect with profile ----

cleanup_config

run_test "P3-006" "connect with --profile production" "$ILUM" connect --release "$HELM_RELEASE" --namespace "$HELM_NAMESPACE" --profile production --yes
assert_exit_code 0 || true

# Verify profile was created
run_test "P3-007" "verify production profile exists" "$ILUM" config list-profiles
assert_contains "production" || true

# Restore original config
restore_config

log_info "Phase 3 complete — connect tested"
