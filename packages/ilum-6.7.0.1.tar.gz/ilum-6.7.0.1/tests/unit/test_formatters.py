"""Tests for ilum.cli.formatters."""

from __future__ import annotations

import json

from ilum.cli.formatters import CommandResult, OutputFormat, ResultFormatter


class TestOutputFormat:
    def test_values(self) -> None:
        assert OutputFormat.TABLE == "table"
        assert OutputFormat.JSON == "json"
        assert OutputFormat.YAML == "yaml"

    def test_string_enum(self) -> None:
        assert isinstance(OutputFormat.JSON, str)


class TestCommandResult:
    def test_defaults(self) -> None:
        result = CommandResult(data={"key": "value"}, summary="Done")
        assert result.exit_code == 0
        assert result.data == {"key": "value"}
        assert result.summary == "Done"

    def test_custom_exit_code(self) -> None:
        result = CommandResult(data={}, summary="Failed", exit_code=1)
        assert result.exit_code == 1


class TestResultFormatter:
    def test_json_output(self, capsys) -> None:
        from unittest.mock import MagicMock

        from rich.console import Console

        console = MagicMock()
        console._console = Console(force_terminal=False, no_color=True)

        result = CommandResult(data={"status": "ok", "count": 42}, summary="All good")
        formatter = ResultFormatter()
        formatter.format(result, OutputFormat.JSON, console)

        captured = capsys.readouterr()
        parsed = json.loads(captured.out.strip())
        assert parsed["status"] == "ok"
        assert parsed["count"] == 42

    def test_yaml_output(self, capsys) -> None:
        from unittest.mock import MagicMock

        from rich.console import Console

        console = MagicMock()
        console._console = Console(force_terminal=False, no_color=True)

        result = CommandResult(data={"name": "ilum", "version": "6.7.0"}, summary="Info")
        formatter = ResultFormatter()
        formatter.format(result, OutputFormat.YAML, console)

        captured = capsys.readouterr()
        assert "name: ilum" in captured.out
        assert "version: 6.7.0" in captured.out

    def test_table_output(self) -> None:
        from unittest.mock import MagicMock

        console = MagicMock()

        result = CommandResult(data={"key": "value"}, summary="Summary text")
        formatter = ResultFormatter()
        formatter.format(result, OutputFormat.TABLE, console)

        console.info.assert_called_once_with("Summary text")

    def test_json_serializes_non_json_types(self, capsys) -> None:
        """Verify that default=str handles non-serializable types."""
        from pathlib import Path
        from unittest.mock import MagicMock

        from rich.console import Console

        console = MagicMock()
        console._console = Console(force_terminal=False, no_color=True)

        result = CommandResult(
            data={"path": Path("/tmp/test")},
            summary="Paths",
        )
        formatter = ResultFormatter()
        formatter.format(result, OutputFormat.JSON, console)

        captured = capsys.readouterr()
        parsed = json.loads(captured.out.strip())
        assert "/tmp/test" in parsed["path"]
