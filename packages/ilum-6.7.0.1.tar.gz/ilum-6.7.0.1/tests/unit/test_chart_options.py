"""Tests for --chart, --devel, and --reset-defaults CLI options."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

from ilum.constants import DEFAULT_CHART_REF, is_local_chart
from ilum.core.helm import HelmClient

# ---------------------------------------------------------------------------
# is_local_chart()
# ---------------------------------------------------------------------------


class TestIsLocalChart:
    def test_relative_dot_slash(self) -> None:
        assert is_local_chart("./helm_aio") is True

    def test_relative_parent(self) -> None:
        assert is_local_chart("../charts/ilum") is True

    def test_absolute_path(self) -> None:
        assert is_local_chart("/absolute/path") is True

    def test_repo_reference(self) -> None:
        assert is_local_chart("ilum/ilum") is False

    def test_simple_name(self) -> None:
        assert is_local_chart("myrepo/mychart") is False

    def test_default_chart_ref(self) -> None:
        assert is_local_chart(DEFAULT_CHART_REF) is False


# ---------------------------------------------------------------------------
# --devel threading through HelmClient
# ---------------------------------------------------------------------------


class TestHelmClientDevel:
    def setup_method(self) -> None:
        self.helm = HelmClient(namespace="default")

    def test_install_args_with_devel(self) -> None:
        args = self.helm._install_args("rel", "chart", devel=True)
        assert "--devel" in args

    def test_install_args_without_devel(self) -> None:
        args = self.helm._install_args("rel", "chart", devel=False)
        assert "--devel" not in args

    def test_upgrade_args_with_devel(self) -> None:
        args = self.helm._upgrade_args("rel", "chart", devel=True)
        assert "--devel" in args

    def test_upgrade_args_without_devel(self) -> None:
        args = self.helm._upgrade_args("rel", "chart", devel=False)
        assert "--devel" not in args

    def test_search_repo_with_devel(self) -> None:
        with patch.object(self.helm, "_run") as mock_run:
            mock_run.return_value = MagicMock(json_data=[])
            self.helm.search_repo("ilum/ilum", devel=True)
            call_args = mock_run.call_args[0][0]
            assert "--devel" in call_args

    def test_search_repo_without_devel(self) -> None:
        with patch.object(self.helm, "_run") as mock_run:
            mock_run.return_value = MagicMock(json_data=[])
            self.helm.search_repo("ilum/ilum", devel=False)
            call_args = mock_run.call_args[0][0]
            assert "--devel" not in call_args

    def test_preview_install_with_devel(self) -> None:
        cmd = self.helm.preview_install("rel", "chart", devel=True)
        assert "--devel" in cmd

    def test_preview_upgrade_with_devel(self) -> None:
        cmd = self.helm.preview_upgrade("rel", "chart", devel=True)
        assert "--devel" in cmd


# ---------------------------------------------------------------------------
# ReleasePlan devel field
# ---------------------------------------------------------------------------


class TestReleasePlanDevel:
    def test_default_devel_is_false(self) -> None:
        from ilum.core.release import ReleasePlan

        plan = ReleasePlan(
            action="install",
            release="ilum",
            namespace="default",
            chart="ilum/ilum",
        )
        assert plan.devel is False

    def test_devel_set_true(self) -> None:
        from ilum.core.release import ReleasePlan

        plan = ReleasePlan(
            action="install",
            release="ilum",
            namespace="default",
            chart="ilum/ilum",
            devel=True,
        )
        assert plan.devel is True


# ---------------------------------------------------------------------------
# --reset-then-reuse-values threading through HelmClient
# ---------------------------------------------------------------------------


class TestHelmClientResetThenReuseValues:
    def setup_method(self) -> None:
        self.helm = HelmClient(namespace="default")

    def test_upgrade_args_with_reset_then_reuse(self) -> None:
        args = self.helm._upgrade_args("rel", "chart", reset_then_reuse_values=True)
        assert "--reset-then-reuse-values" in args
        assert "--reuse-values" not in args

    def test_upgrade_args_with_reuse_values(self) -> None:
        args = self.helm._upgrade_args("rel", "chart", reuse_values=True)
        assert "--reuse-values" in args
        assert "--reset-then-reuse-values" not in args

    def test_reuse_values_takes_precedence_over_reset(self) -> None:
        args = self.helm._upgrade_args(
            "rel", "chart", reuse_values=True, reset_then_reuse_values=True
        )
        assert "--reuse-values" in args
        assert "--reset-then-reuse-values" not in args

    def test_neither_flag(self) -> None:
        args = self.helm._upgrade_args("rel", "chart")
        assert "--reuse-values" not in args
        assert "--reset-then-reuse-values" not in args

    def test_preview_upgrade_with_reset_then_reuse(self) -> None:
        cmd = self.helm.preview_upgrade("rel", "chart", reset_then_reuse_values=True)
        assert "--reset-then-reuse-values" in cmd
        assert "--reuse-values" not in cmd

    def test_upgrade_passes_reset_then_reuse(self) -> None:
        with patch.object(self.helm, "_run") as mock_run:
            mock_run.return_value = MagicMock(returncode=0)
            self.helm.upgrade("rel", "chart", reset_then_reuse_values=True)
            call_args = mock_run.call_args[0][0]
            assert "--reset-then-reuse-values" in call_args
            assert "--reuse-values" not in call_args


# ---------------------------------------------------------------------------
# ReleasePlan reset_defaults field
# ---------------------------------------------------------------------------


class TestReleasePlanResetDefaults:
    def test_default_reset_defaults_is_false(self) -> None:
        from ilum.core.release import ReleasePlan

        plan = ReleasePlan(
            action="upgrade",
            release="ilum",
            namespace="default",
            chart="ilum/ilum",
        )
        assert plan.reset_defaults is False

    def test_reset_defaults_set_true(self) -> None:
        from ilum.core.release import ReleasePlan

        plan = ReleasePlan(
            action="upgrade",
            release="ilum",
            namespace="default",
            chart="ilum/ilum",
            reset_defaults=True,
        )
        assert plan.reset_defaults is True
