"""Tests for shell completion functions (Phase 4)."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

from ilum.cli.completers import (
    complete_check_names,
    complete_module_names,
    complete_profile_names,
)


class TestCompleteModuleNames:
    def test_returns_all_with_empty(self) -> None:
        result = complete_module_names("")
        assert len(result) > 0
        assert "core" in result
        assert "ui" in result

    def test_filters_by_prefix(self) -> None:
        result = complete_module_names("co")
        assert "core" in result
        assert "ui" not in result

    def test_no_match_returns_empty(self) -> None:
        result = complete_module_names("zzz-nonexistent")
        assert result == []


class TestCompleteProfileNames:
    def test_returns_profiles(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        if sys.platform == "win32":
            monkeypatch.setenv("APPDATA", str(tmp_path / "appdata"))
            monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "localappdata"))
        else:
            monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "config"))
            monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "data"))
            monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))
            monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "cache"))

        from ilum.config.manager import ConfigManager
        from ilum.config.models import IlumConfig, ProfileConfig
        from ilum.config.paths import IlumPaths

        paths = IlumPaths.default()
        paths.ensure_dirs()
        mgr = ConfigManager(paths)
        config = IlumConfig(
            profiles={
                "dev": ProfileConfig(name="dev"),
                "staging": ProfileConfig(name="staging"),
            }
        )
        mgr.save(config)

        result = complete_profile_names("")
        assert "dev" in result
        assert "staging" in result

    def test_filters_by_prefix(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        if sys.platform == "win32":
            monkeypatch.setenv("APPDATA", str(tmp_path / "appdata"))
            monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "localappdata"))
        else:
            monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "config"))
            monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "data"))
            monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "state"))
            monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "cache"))

        from ilum.config.manager import ConfigManager
        from ilum.config.models import IlumConfig, ProfileConfig
        from ilum.config.paths import IlumPaths

        paths = IlumPaths.default()
        paths.ensure_dirs()
        mgr = ConfigManager(paths)
        config = IlumConfig(
            profiles={
                "dev": ProfileConfig(name="dev"),
                "staging": ProfileConfig(name="staging"),
            }
        )
        mgr.save(config)

        result = complete_profile_names("s")
        assert "staging" in result
        assert "dev" not in result

    def test_handles_no_config(self, tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
        """Should return empty list when no config exists."""
        if sys.platform == "win32":
            monkeypatch.setenv("APPDATA", str(tmp_path / "noconfig_appdata"))
            monkeypatch.setenv("LOCALAPPDATA", str(tmp_path / "noconfig_local"))
        else:
            monkeypatch.setenv("XDG_CONFIG_HOME", str(tmp_path / "noconfig"))
            monkeypatch.setenv("XDG_DATA_HOME", str(tmp_path / "nodata"))
            monkeypatch.setenv("XDG_STATE_HOME", str(tmp_path / "nostate"))
            monkeypatch.setenv("XDG_CACHE_HOME", str(tmp_path / "nocache"))

        result = complete_profile_names("")
        # Should return empty (or default profile) without error
        assert isinstance(result, list)


class TestCompleteCheckNames:
    def test_returns_all_with_empty(self) -> None:
        result = complete_check_names("")
        assert "helm" in result
        assert "cluster" in result
        assert "namespace" in result
        assert "storage-class" in result

    def test_filters_by_prefix(self) -> None:
        result = complete_check_names("he")
        assert "helm" in result
        assert "helm-repo" in result
        assert "cluster" not in result
