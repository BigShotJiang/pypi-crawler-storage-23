"""Tests for config_cmd.py — editor fallback."""

from __future__ import annotations

from unittest.mock import patch

from typer.testing import CliRunner

from ilum.cli.main import app
from ilum.config.paths import IlumPaths


class TestEditorFallback:
    def test_editor_default_windows(self, tmp_config_dir: IlumPaths, monkeypatch) -> None:
        """On Windows, the default editor should be notepad."""
        monkeypatch.delenv("EDITOR", raising=False)
        monkeypatch.delenv("VISUAL", raising=False)
        monkeypatch.setattr("ilum.cli.config_cmd.sys.platform", "win32")

        runner = CliRunner()
        with patch("ilum.cli.config_cmd.subprocess.run") as mock_run:
            runner.invoke(app, ["config", "edit"])
            mock_run.assert_called_once()
            args = mock_run.call_args[0][0]
            assert args[0] == "notepad"

    def test_editor_default_unix(self, tmp_config_dir: IlumPaths, monkeypatch) -> None:
        """On Unix, the default editor should be vi."""
        monkeypatch.delenv("EDITOR", raising=False)
        monkeypatch.delenv("VISUAL", raising=False)
        monkeypatch.setattr("ilum.cli.config_cmd.sys.platform", "linux")

        runner = CliRunner()
        with patch("ilum.cli.config_cmd.subprocess.run") as mock_run:
            runner.invoke(app, ["config", "edit"])
            mock_run.assert_called_once()
            args = mock_run.call_args[0][0]
            assert args[0] == "vi"

    def test_editor_env_override(self, tmp_config_dir: IlumPaths, monkeypatch) -> None:
        """$EDITOR overrides the platform default."""
        monkeypatch.setenv("EDITOR", "nano")
        monkeypatch.delenv("VISUAL", raising=False)

        runner = CliRunner()
        with patch("ilum.cli.config_cmd.subprocess.run") as mock_run:
            runner.invoke(app, ["config", "edit"])
            mock_run.assert_called_once()
            args = mock_run.call_args[0][0]
            assert args[0] == "nano"
