"""Tests for ``ilum preset`` sub-commands."""

from __future__ import annotations

import pytest
from typer.testing import CliRunner

from ilum.cli.main import app


@pytest.fixture()
def runner() -> CliRunner:
    return CliRunner()


class TestPresetList:
    def test_preset_list_shows_all_presets(self, runner: CliRunner) -> None:
        result = runner.invoke(app, ["preset", "list"])
        assert result.exit_code == 0
        assert "tiny" in result.output
        assert "default" in result.output
        assert "production" in result.output
        assert "data-engineering" in result.output
        assert "ml-ops" in result.output
        assert "analyst" in result.output
        assert "air-gapped" in result.output

    def test_preset_list_shows_descriptions(self, runner: CliRunner) -> None:
        result = runner.invoke(app, ["preset", "list"])
        assert result.exit_code == 0
        # default preset description
        assert "Standard" in result.output or "default" in result.output
        # production preset description contains "security"
        assert "security" in result.output

    def test_preset_list_shows_module_count(self, runner: CliRunner) -> None:
        result = runner.invoke(app, ["preset", "list"])
        assert result.exit_code == 0
        # tiny has 7 modules, air-gapped has 7 modules
        assert "7" in result.output
        # default has 11 modules
        assert "11" in result.output
        # production has 13 modules
        assert "13" in result.output

    def test_preset_help(self, runner: CliRunner) -> None:
        result = runner.invoke(app, ["preset", "--help"])
        assert result.exit_code == 0
