"""Tests for the main CLI entry point."""

from __future__ import annotations

from typer.testing import CliRunner

from ilum.cli.main import app


class TestCLIMain:
    def test_version_flag(self) -> None:
        runner = CliRunner()
        result = runner.invoke(app, ["--version"])
        assert result.exit_code == 0
        assert "ilum" in result.stdout

    def test_no_args_shows_help(self) -> None:
        runner = CliRunner()
        result = runner.invoke(app, [])
        assert result.exit_code == 0
        assert "doctor" in result.stdout
        assert "config" in result.stdout

    def test_help_flag(self) -> None:
        runner = CliRunner()
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "ilum" in result.stdout.lower() or "Ilum" in result.stdout

    def test_doctor_command_exists(self) -> None:
        runner = CliRunner()
        result = runner.invoke(app, ["doctor", "--help"])
        assert result.exit_code == 0
        assert "health check" in result.stdout.lower() or "namespace" in result.stdout.lower()

    def test_config_command_exists(self) -> None:
        runner = CliRunner()
        result = runner.invoke(app, ["config", "--help"])
        assert result.exit_code == 0
        assert "show" in result.stdout
        assert "set" in result.stdout
