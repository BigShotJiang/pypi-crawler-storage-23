"""Tests for auto_connect startup logic."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from ilum.core.release import ReleaseInfo


class TestAutoConnect:
    def test_uses_env_vars(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When ILUM_RELEASE_NAME and ILUM_NAMESPACE are set, uses them directly."""
        monkeypatch.setenv("ILUM_RELEASE_NAME", "my-release")
        monkeypatch.setenv("ILUM_NAMESPACE", "production")

        with (
            patch("ilum.api.startup.HelmClient") as mock_helm_cls,
            patch("ilum.api.startup.KubeClient"),
            patch("ilum.api.startup.ConfigManager"),
            patch("ilum.api.startup.IlumPaths") as mock_paths_cls,
            patch("ilum.api.startup.set_manager") as mock_set,
        ):
            mock_paths_cls.default.return_value.ensure_dirs.return_value = None
            from ilum.api.startup import auto_connect

            auto_connect()

            mock_set.assert_called_once()
            mock_helm_cls.assert_called_once_with(kubecontext="", namespace="production")

    def test_auto_detect_release(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When no ILUM_RELEASE_NAME, scans and picks first release."""
        monkeypatch.delenv("ILUM_RELEASE_NAME", raising=False)
        monkeypatch.setenv("ILUM_NAMESPACE", "default")

        mock_mgr = MagicMock()
        mock_mgr.scan_releases.return_value = [
            ReleaseInfo(
                name="ilum",
                namespace="default",
                status="deployed",
                chart="ilum",
                chart_version="6.7.0",
                revision=1,
                last_deployed="",
            )
        ]
        mock_mgr.helm.namespace = "default"

        with (
            patch("ilum.api.startup.ReleaseManager", return_value=mock_mgr),
            patch("ilum.api.startup.HelmClient"),
            patch("ilum.api.startup.KubeClient"),
            patch("ilum.api.startup.ConfigManager"),
            patch("ilum.api.startup.IlumPaths") as mock_paths_cls,
            patch("ilum.api.startup.set_manager") as mock_set,
        ):
            mock_paths_cls.default.return_value.ensure_dirs.return_value = None
            from ilum.api.startup import auto_connect

            auto_connect()

            mock_set.assert_called_once()

    def test_ensures_repo_for_remote_chart(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When ILUM_CHART_REF is a remote repo ref, ensure_repo() is called."""
        monkeypatch.setenv("ILUM_RELEASE_NAME", "ilum")
        monkeypatch.setenv("ILUM_NAMESPACE", "default")
        monkeypatch.setenv("ILUM_CHART_REF", "ilum/ilum")

        mock_mgr = MagicMock()
        mock_mgr.is_stuck.return_value = False

        with (
            patch("ilum.api.startup.ReleaseManager", return_value=mock_mgr),
            patch("ilum.api.startup.HelmClient"),
            patch("ilum.api.startup.KubeClient"),
            patch("ilum.api.startup.ConfigManager"),
            patch("ilum.api.startup.IlumPaths") as mock_paths_cls,
            patch("ilum.api.startup.set_manager"),
        ):
            mock_paths_cls.default.return_value.ensure_dirs.return_value = None
            from ilum.api.startup import auto_connect

            auto_connect()

            mock_mgr.ensure_repo.assert_called_once()

    def test_skips_repo_for_local_chart(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When ILUM_CHART_REF is a local path, ensure_repo() is NOT called."""
        monkeypatch.setenv("ILUM_RELEASE_NAME", "ilum")
        monkeypatch.setenv("ILUM_NAMESPACE", "default")
        monkeypatch.setenv("ILUM_CHART_REF", "/opt/ilum-chart")

        mock_mgr = MagicMock()
        mock_mgr.is_stuck.return_value = False

        with (
            patch("ilum.api.startup.ReleaseManager", return_value=mock_mgr),
            patch("ilum.api.startup.HelmClient"),
            patch("ilum.api.startup.KubeClient"),
            patch("ilum.api.startup.ConfigManager"),
            patch("ilum.api.startup.IlumPaths") as mock_paths_cls,
            patch("ilum.api.startup.set_manager"),
        ):
            mock_paths_cls.default.return_value.ensure_dirs.return_value = None
            from ilum.api.startup import auto_connect

            auto_connect()

            mock_mgr.ensure_repo.assert_not_called()

    def test_no_releases_found(self, monkeypatch: pytest.MonkeyPatch) -> None:
        """When no releases found, uses defaults and still sets manager."""
        monkeypatch.delenv("ILUM_RELEASE_NAME", raising=False)
        monkeypatch.setenv("ILUM_NAMESPACE", "default")

        mock_mgr = MagicMock()
        mock_mgr.scan_releases.return_value = []

        with (
            patch("ilum.api.startup.ReleaseManager", return_value=mock_mgr),
            patch("ilum.api.startup.HelmClient"),
            patch("ilum.api.startup.KubeClient"),
            patch("ilum.api.startup.ConfigManager"),
            patch("ilum.api.startup.IlumPaths") as mock_paths_cls,
            patch("ilum.api.startup.set_manager") as mock_set,
        ):
            mock_paths_cls.default.return_value.ensure_dirs.return_value = None
            from ilum.api.startup import auto_connect

            auto_connect()

            mock_set.assert_called_once()
