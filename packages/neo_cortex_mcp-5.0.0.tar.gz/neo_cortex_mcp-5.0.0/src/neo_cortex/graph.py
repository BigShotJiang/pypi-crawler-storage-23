"""ConceptGraph — NetworkX concept co-occurrence graph with spreading activation."""

import json
import os
from collections import deque

import networkx as nx


class ConceptGraph:
    """Graph of concepts linked by co-occurrence in memories."""

    def __init__(self, path: str):
        self._path = path
        self._graph = nx.Graph()
        self._memory_concepts: dict[str, list[str]] = {}
        self._load()

    def add_memory(self, memory_id: str, concepts: list[str]) -> None:
        """Add concept nodes + co-occurrence edges for a memory."""
        if not concepts:
            return

        self._memory_concepts[memory_id] = list(concepts)

        for c in concepts:
            if not self._graph.has_node(c):
                self._graph.add_node(c, mentions=0, memories=[])
            self._graph.nodes[c]["mentions"] += 1
            if memory_id not in self._graph.nodes[c]["memories"]:
                self._graph.nodes[c]["memories"].append(memory_id)

        # Co-occurrence edges
        for i in range(len(concepts)):
            for j in range(i + 1, len(concepts)):
                a, b = concepts[i], concepts[j]
                if self._graph.has_edge(a, b):
                    self._graph[a][b]["weight"] += 1
                else:
                    self._graph.add_edge(a, b, weight=1)

        self.save()

    def remove_memory(self, memory_id: str, concepts: list[str]) -> None:
        """Decrement weights for a removed memory."""
        for c in concepts:
            if self._graph.has_node(c):
                self._graph.nodes[c]["mentions"] = max(0, self._graph.nodes[c]["mentions"] - 1)
                mems = self._graph.nodes[c]["memories"]
                if memory_id in mems:
                    mems.remove(memory_id)

        for i in range(len(concepts)):
            for j in range(i + 1, len(concepts)):
                a, b = concepts[i], concepts[j]
                if self._graph.has_edge(a, b):
                    self._graph[a][b]["weight"] -= 1
                    if self._graph[a][b]["weight"] <= 0:
                        self._graph.remove_edge(a, b)

        self._memory_concepts.pop(memory_id, None)
        self.save()

    def spreading_activation(
        self, concepts: list[str], hops: int = 2, decay: float = 0.5
    ) -> dict[str, float]:
        """BFS from seed concepts with decaying activation per hop."""
        if not concepts:
            return {}

        activation: dict[str, float] = {}
        queue: deque[tuple[str, float, int]] = deque()

        for c in concepts:
            if self._graph.has_node(c):
                activation[c] = 1.0
                queue.append((c, 1.0, 0))

        while queue:
            node, energy, hop = queue.popleft()
            if hop >= hops:
                continue
            for neighbor in self._graph.neighbors(node):
                weight = self._graph[node][neighbor].get("weight", 1)
                new_energy = energy * decay * min(weight, 3) / 3
                if neighbor not in activation or new_energy > activation[neighbor]:
                    activation[neighbor] = new_energy
                    queue.append((neighbor, new_energy, hop + 1))

        return activation

    def get_related_memories(self, concepts: list[str], n: int = 5) -> list[str]:
        """Use spreading activation to find related memory IDs."""
        activated = self.spreading_activation(concepts)
        if not activated:
            return []

        # Collect memory IDs weighted by activation
        memory_scores: dict[str, float] = {}
        for concept, score in activated.items():
            if self._graph.has_node(concept):
                for mid in self._graph.nodes[concept]["memories"]:
                    memory_scores[mid] = memory_scores.get(mid, 0) + score

        sorted_memories = sorted(memory_scores, key=memory_scores.get, reverse=True)
        return sorted_memories[:n]

    def has_node(self, concept: str) -> bool:
        return self._graph.has_node(concept)

    def has_edge(self, a: str, b: str) -> bool:
        return self._graph.has_edge(a, b)

    def edge_weight(self, a: str, b: str) -> int:
        if not self._graph.has_edge(a, b):
            return 0
        return self._graph[a][b]["weight"]

    def mentions(self, concept: str) -> int:
        if not self._graph.has_node(concept):
            return 0
        return self._graph.nodes[concept]["mentions"]

    def memories_for(self, concept: str) -> list[str]:
        if not self._graph.has_node(concept):
            return []
        return list(self._graph.nodes[concept]["memories"])

    def node_count(self) -> int:
        return self._graph.number_of_nodes()

    def save(self) -> None:
        """Serialize graph + memory_concepts to JSON."""
        data = {
            "nodes": {
                n: {"mentions": d["mentions"], "memories": d["memories"]}
                for n, d in self._graph.nodes(data=True)
            },
            "edges": [
                {"a": u, "b": v, "weight": d["weight"]}
                for u, v, d in self._graph.edges(data=True)
            ],
            "memory_concepts": self._memory_concepts,
        }
        with open(self._path, "w", encoding="utf-8") as f:
            json.dump(data, f)

    def _load(self) -> None:
        """Load from JSON if exists."""
        if not os.path.exists(self._path):
            return
        try:
            with open(self._path, encoding="utf-8") as f:
                data = json.load(f)
            for name, attrs in data.get("nodes", {}).items():
                self._graph.add_node(name, **attrs)
            for edge in data.get("edges", []):
                self._graph.add_edge(edge["a"], edge["b"], weight=edge["weight"])
            self._memory_concepts = data.get("memory_concepts", {})
        except (json.JSONDecodeError, KeyError):
            pass
