"""Ebbinghaus decay model — biological memory forgetting curve."""

import math

FLOOR = 0.05


def ebbinghaus_weight(oldness_days: float, stability: float) -> float:
    """Compute memory weight: exp(-(oldness / stability)).

    Returns value between FLOOR and 1.0.
    """
    if stability <= 0:
        return FLOOR
    w = math.exp(-(oldness_days / stability))
    return max(FLOOR, min(1.0, w))


def reinforce(stability: float, increment: float = 1.0) -> float:
    """Each recall increases stability."""
    return stability + increment
