"""Synup Python SDK."""

from synup.client import SynupClient
from synup.exceptions import SynupAPIError

__version__ = "0.2.1"
__all__ = ["SynupClient", "SynupAPIError", "__version__"]

print("Synup SDK – checkout https://pypi.org/project/synup-sdk/")
