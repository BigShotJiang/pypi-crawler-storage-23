"""Synup MCP Server — exposes synup-sdk methods as MCP tools for LLM agents.

Authentication:
    Set the SYNUP_API_KEY environment variable with your Synup API key.
    For HTTP transport, pass: Authorization: Bearer {base64(api_key:{key};user_email:{email})}

Usage:
    # stdio (Claude Desktop, MCP Inspector)
    SYNUP_API_KEY=your_key synup-mcp

    # Or run directly
    python -m synup.mcp.server
"""

from __future__ import annotations

import asyncio
import base64
import os
from typing import Any, Optional

from fastmcp import FastMCP
from pydantic import Field
from typing import Annotated

from synup import SynupClient

mcp = FastMCP(
    name="Synup",
    instructions=(
        "You have access to the full Synup API through this MCP server. "
        "Use these tools to manage business locations, listings, reviews, "
        "rankings, and analytics. All write operations take effect immediately. "
        "Location IDs can be provided as numeric IDs or base64-encoded strings.\n\n"
        "EFFICIENCY RULES — always follow these:\n"
        "1. Use list_locations (not get_all_locations) when you only need IDs, names, or cities.\n"
        "2. Use get_account_review_summary (not looping get_review_analytics_overview) to get review totals across locations.\n"
        "3. Never call the same tool in a loop when an aggregate tool exists."
    ),
)


# ---------------------------------------------------------------------------
# Authentication helpers
# ---------------------------------------------------------------------------

def _get_api_key() -> str:
    """Extract API key from SYNUP_API_KEY env var or HTTP Authorization header.

    Header format (HTTP transport):
        Authorization: Bearer {base64(api_key:{key};user_email:{email})}
    """
    api_key = os.getenv("SYNUP_API_KEY")
    if api_key:
        return api_key

    # Try to parse from Authorization header (HTTP transport)
    try:
        from fastmcp.server.context import get_http_headers  # type: ignore[import]
        headers = get_http_headers()
        if headers:
            auth = headers.get("authorization", "") or headers.get("Authorization", "")
            if auth.startswith("Bearer "):
                token = auth[7:]
                decoded = base64.b64decode(token + "==").decode("utf-8")
                for part in decoded.split(";"):
                    if part.startswith("api_key:"):
                        return part[8:].strip()
    except Exception:
        pass

    raise ValueError(
        "Synup API key not found. Set the SYNUP_API_KEY environment variable, "
        "or pass an Authorization header: "
        "Bearer {base64(api_key:YOUR_KEY;user_email:YOUR_EMAIL)}"
    )


def _get_client() -> SynupClient:
    """Create a SynupClient using the API key from the current request context."""
    return SynupClient(api_key=_get_api_key())


# ---------------------------------------------------------------------------
# Location tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def get_all_locations(
    first: Annotated[Optional[int], Field(default=None, description="Number of locations to return from the start (default: all)")] = None,
    after: Annotated[Optional[str], Field(default=None, description="Pagination cursor — return locations after this cursor")] = None,
    fetch_all: Annotated[bool, Field(default=False, description="If true, fetch all locations across all pages and return as a flat list")] = False,
    page_size: Annotated[int, Field(default=100, description="Page size when fetch_all is true (default: 100)")] = 100,
) -> dict[str, Any]:
    """Get all locations in the account with optional pagination.

    Returns a paginated list of locations, or all locations if fetch_all is true.
    Each location includes id, name, street, city, state, phone, storeId, and more.
    """
    client = _get_client()
    result = await asyncio.to_thread(
        client.fetch_all_locations,
        first=first,
        after=after,
        fetch_all=fetch_all,
        page_size=page_size,
    )
    if isinstance(result, list):
        return {"success": True, "locations": result, "total": len(result)}
    return result


@mcp.tool()
async def get_locations_by_ids(
    location_ids: Annotated[list[str], Field(description="List of location IDs (numeric or base64-encoded)")],
) -> dict[str, Any]:
    """Get specific locations by their IDs.

    Accepts numeric IDs (e.g. 16808) or base64-encoded IDs. Returns full location details.
    """
    client = _get_client()
    locations = await asyncio.to_thread(client.fetch_locations_by_ids, location_ids)
    return {"success": True, "locations": locations, "total": len(locations)}


@mcp.tool()
async def get_locations_by_store_codes(
    store_codes: Annotated[list[str], Field(description="List of store codes (e.g. ['STORE01', 'STORE02'])")],
) -> dict[str, Any]:
    """Get locations by their store codes.

    Useful when you know the store identifiers but not the internal location IDs.
    """
    client = _get_client()
    locations = await asyncio.to_thread(client.fetch_locations_by_store_codes, store_codes)
    return {"success": True, "locations": locations, "total": len(locations)}


@mcp.tool()
async def search_locations(
    query: Annotated[str, Field(description="Search term to match against location name, street, or store ID")],
    fields: Annotated[Optional[list[str]], Field(default=None, description="Restrict search to specific fields, e.g. ['name'] or ['store_id']. If omitted, all fields are searched.")] = None,
    first: Annotated[Optional[int], Field(default=None, description="Max number of results to return")] = None,
    fetch_all: Annotated[bool, Field(default=False, description="If true, return all matching locations across all pages")] = False,
) -> dict[str, Any]:
    """Search locations by keyword across name, address, or store ID.

    Returns matching locations with full details. Use fetch_all=true to get all matches.
    """
    client = _get_client()
    result = await asyncio.to_thread(
        client.search_locations,
        query=query,
        fields=fields,
        first=first,
        fetch_all=fetch_all,
    )
    if isinstance(result, list):
        return {"success": True, "locations": result, "total": len(result)}
    return result


@mcp.tool()
async def get_locations_by_folder(
    folder_id: Annotated[Optional[str], Field(default=None, description="Folder UUID")] = None,
    folder_name: Annotated[Optional[str], Field(default=None, description="Human-readable folder name (e.g. 'franchise')")] = None,
) -> dict[str, Any]:
    """Get all locations in a folder (including subfolders).

    Provide either folder_id or folder_name. Returns all locations in that folder.
    """
    client = _get_client()
    locations = await asyncio.to_thread(
        client.fetch_locations_by_folder,
        folder_id=folder_id,
        folder_name=folder_name,
    )
    return {"success": True, "locations": locations, "total": len(locations)}


@mcp.tool()
async def get_locations_by_tags(
    tags: Annotated[list[str], Field(description="List of tag names — locations with any of these tags are returned")],
    archived: Annotated[Optional[bool], Field(default=None, description="Filter by archived status: true=archived only, false=active only, null=both")] = None,
    fetch_all: Annotated[bool, Field(default=False, description="If true, return all matching locations across all pages")] = False,
) -> dict[str, Any]:
    """Get locations that have any of the specified tags.

    Returns all locations tagged with at least one of the provided tag names.
    """
    client = _get_client()
    result = await asyncio.to_thread(
        client.fetch_locations_by_tags,
        tags=tags,
        archived=archived,
        fetch_all=fetch_all,
    )
    if isinstance(result, list):
        return {"success": True, "locations": result, "total": len(result)}
    return result


@mcp.tool()
async def create_location(
    name: Annotated[str, Field(description="Business name")],
    store_id: Annotated[str, Field(description="Unique store code/identifier for this location")],
    street: Annotated[str, Field(description="Street address")],
    city: Annotated[str, Field(description="City name")],
    state_iso: Annotated[str, Field(description="State/region code (e.g. 'CA', 'NY')")],
    postal_code: Annotated[str, Field(description="ZIP or postal code")],
    country_iso: Annotated[str, Field(description="Country code (e.g. 'US', 'CA', 'GB')")],
    phone: Annotated[str, Field(description="Business phone number")],
    description: Annotated[Optional[str], Field(default=None, description="Business description")] = None,
    website: Annotated[Optional[str], Field(default=None, description="Business website URL")] = None,
    email: Annotated[Optional[str], Field(default=None, description="Business email address")] = None,
    owner_name: Annotated[Optional[str], Field(default=None, description="Owner's name")] = None,
    owner_email: Annotated[Optional[str], Field(default=None, description="Owner's email address")] = None,
) -> dict[str, Any]:
    """Create a new location in the account.

    All required fields must be provided. Returns the created location object on success.
    """
    client = _get_client()
    input_data: dict[str, Any] = {
        "name": name,
        "storeId": store_id,
        "street": street,
        "city": city,
        "stateIso": state_iso,
        "postalCode": postal_code,
        "countryIso": country_iso,
        "phone": phone,
    }
    if description is not None:
        input_data["description"] = description
    if website is not None:
        input_data["website"] = website
    if email is not None:
        input_data["email"] = email
    if owner_name is not None:
        input_data["ownerName"] = owner_name
    if owner_email is not None:
        input_data["ownerEmail"] = owner_email
    return await asyncio.to_thread(client.create_location, input_data)


@mcp.tool()
async def update_location(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    name: Annotated[Optional[str], Field(default=None, description="Business name")] = None,
    phone: Annotated[Optional[str], Field(default=None, description="Phone number")] = None,
    street: Annotated[Optional[str], Field(default=None, description="Street address")] = None,
    city: Annotated[Optional[str], Field(default=None, description="City name")] = None,
    state_iso: Annotated[Optional[str], Field(default=None, description="State/region code (e.g. 'CA')")] = None,
    country_iso: Annotated[Optional[str], Field(default=None, description="Country code (e.g. 'US')")] = None,
    postal_code: Annotated[Optional[str], Field(default=None, description="ZIP/postal code")] = None,
    website: Annotated[Optional[str], Field(default=None, description="Website URL")] = None,
    description: Annotated[Optional[str], Field(default=None, description="Business description")] = None,
    store_id: Annotated[Optional[str], Field(default=None, description="Store code/identifier")] = None,
    email: Annotated[Optional[str], Field(default=None, description="Business email address")] = None,
    temporarily_closed: Annotated[Optional[bool], Field(default=None, description="Whether the location is temporarily closed")] = None,
    tags: Annotated[Optional[list[str]], Field(default=None, description="List of tags to set on the location")] = None,
) -> dict[str, Any]:
    """Update a location's information.

    Only pass fields you want to change. The location_id is always required.
    Returns the updated location on success.
    """
    client = _get_client()
    input_data: dict[str, Any] = {"id": location_id}
    if name is not None:
        input_data["name"] = name
    if phone is not None:
        input_data["phone"] = phone
    if street is not None:
        input_data["street"] = street
    if city is not None:
        input_data["city"] = city
    if state_iso is not None:
        input_data["stateIso"] = state_iso
    if country_iso is not None:
        input_data["countryIso"] = country_iso
    if postal_code is not None:
        input_data["postalCode"] = postal_code
    if website is not None:
        input_data["website"] = website
    if description is not None:
        input_data["description"] = description
    if store_id is not None:
        input_data["storeId"] = store_id
    if email is not None:
        input_data["email"] = email
    if temporarily_closed is not None:
        input_data["temporarilyClosed"] = temporarily_closed
    if tags is not None:
        input_data["tags"] = tags
    return await asyncio.to_thread(client.update_location, input_data)


@mcp.tool()
async def archive_locations(
    location_ids: Annotated[list[str], Field(description="List of base64-encoded location IDs to archive")],
) -> dict[str, Any]:
    """Archive one or more locations (hidden, not deleted).

    Archived locations can be reactivated later with activate_locations.
    """
    client = _get_client()
    return await asyncio.to_thread(client.archive_locations, location_ids)


@mcp.tool()
async def activate_locations(
    location_ids: Annotated[list[str], Field(description="List of base64-encoded location IDs to reactivate")],
) -> dict[str, Any]:
    """Reactivate previously archived locations.

    Use this to restore locations that were archived with archive_locations.
    """
    client = _get_client()
    return await asyncio.to_thread(client.activate_locations, location_ids)


# ---------------------------------------------------------------------------
# Lightweight / aggregate tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def list_locations(
    search: Annotated[Optional[str], Field(default=None, description="Optional search term to filter locations by name, address, or store ID")] = None,
) -> dict[str, Any]:
    """Get a lightweight list of all locations — just id, name, city, state, and storeId.

    PREFER THIS over get_all_locations when you only need to identify locations or
    show a summary list. Much smaller response, much faster.
    """
    client = _get_client()
    if search:
        raw = await asyncio.to_thread(client.search_locations, query=search, fetch_all=True)
    else:
        raw = await asyncio.to_thread(client.fetch_all_locations, fetch_all=True)
    locations = raw if isinstance(raw, list) else raw.get("locations", [])
    slim = [
        {
            "id": loc.get("id"),
            "name": loc.get("name"),
            "city": loc.get("city"),
            "state": loc.get("state"),
            "storeId": loc.get("storeId"),
            "phone": loc.get("phone"),
        }
        for loc in locations
    ]
    return {"success": True, "locations": slim, "total": len(slim)}


@mcp.tool()
async def get_account_review_summary(
    location_ids: Annotated[Optional[list[str]], Field(default=None, description="Specific location IDs to summarize. If omitted, all locations in the account are included.")] = None,
    start_date: Annotated[Optional[str], Field(default=None, description="Start date in YYYY-MM-DD format")] = None,
    end_date: Annotated[Optional[str], Field(default=None, description="End date in YYYY-MM-DD format")] = None,
) -> dict[str, Any]:
    """Get aggregated review stats rolled up across all (or specified) locations.

    USE THIS instead of calling get_review_analytics_overview in a loop.
    Returns total review count, average rating, and response rate in a single call.
    Also lists which locations have reviews so you can drill in if needed.
    """
    client = _get_client()

    if location_ids is None:
        raw = await asyncio.to_thread(client.fetch_all_locations, fetch_all=True)
        locs = raw if isinstance(raw, list) else raw.get("locations", [])
        location_ids = [loc["id"] for loc in locs]

    total_reviews = 0
    ratings: list[float] = []
    response_rates: list[float] = []
    locations_with_reviews: list[dict[str, Any]] = []

    for loc_id in location_ids:
        try:
            result = await asyncio.to_thread(
                client.fetch_review_analytics_overview,
                location_id=loc_id,
                start_date=start_date,
                end_date=end_date,
            )
            stats = {s["name"]: s["value"] for s in result.get("stats", [])}
            count = stats.get("total-reviews", 0)
            rating = stats.get("overall-rating", 0)
            response_rate = stats.get("review-response-rate", 0)
            total_reviews += count
            if count > 0:
                ratings.append(rating)
                response_rates.append(response_rate)
                locations_with_reviews.append({
                    "location_id": loc_id,
                    "total_reviews": count,
                    "rating": rating,
                    "response_rate": response_rate,
                })
        except Exception:
            pass

    return {
        "success": True,
        "total_reviews": total_reviews,
        "locations_checked": len(location_ids),
        "locations_with_reviews": len(locations_with_reviews),
        "average_rating": round(sum(ratings) / len(ratings), 2) if ratings else 0,
        "average_response_rate": round(sum(response_rates) / len(response_rates), 2) if response_rates else 0,
        "breakdown": locations_with_reviews,
    }


# ---------------------------------------------------------------------------
# Folder management tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def create_folder(
    name: Annotated[str, Field(description="Name for the new folder")],
    parent_folder: Annotated[Optional[str], Field(default=None, description="Parent folder UUID (to nest this folder under another)")] = None,
    parent_folder_name: Annotated[Optional[str], Field(default=None, description="Parent folder name (alternative to parent_folder UUID)")] = None,
) -> dict[str, Any]:
    """Create a folder to organize locations.

    Folders can be nested by providing a parent folder. Returns the created folder.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.create_folder,
        name=name,
        parent_folder=parent_folder,
        parent_folder_name=parent_folder_name,
    )


@mcp.tool()
async def rename_folder(
    old_name: Annotated[str, Field(description="Current folder name")],
    new_name: Annotated[str, Field(description="New name for the folder")],
) -> dict[str, Any]:
    """Rename an existing folder."""
    client = _get_client()
    return await asyncio.to_thread(client.rename_folder, old_name=old_name, new_name=new_name)


@mcp.tool()
async def delete_folder(
    name: Annotated[str, Field(description="Exact folder name to delete")],
) -> dict[str, Any]:
    """Delete a folder by name.

    Locations in the folder are NOT deleted — they are unassigned from the folder.
    """
    client = _get_client()
    return await asyncio.to_thread(client.delete_folder, name=name)


@mcp.tool()
async def add_locations_to_folder(
    folder_name: Annotated[str, Field(description="Folder name (created automatically if it does not exist)")],
    location_ids: Annotated[list[str], Field(description="List of base64-encoded location IDs to add to the folder")],
) -> dict[str, Any]:
    """Add locations to a folder.

    The folder is created if it does not already exist.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.add_locations_to_folder,
        folder_name=folder_name,
        location_ids=location_ids,
    )


@mcp.tool()
async def remove_locations_from_folder(
    location_ids: Annotated[list[str], Field(description="List of base64-encoded location IDs to remove from their current folder")],
) -> dict[str, Any]:
    """Remove locations from their current folder."""
    client = _get_client()
    return await asyncio.to_thread(client.remove_locations_from_folder, location_ids)


# ---------------------------------------------------------------------------
# Tag management tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def add_location_tag(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    tag: Annotated[str, Field(description="Tag name to add (e.g. 'vip', 'new', 'franchise')")],
) -> dict[str, Any]:
    """Add a tag to a location.

    The tag is created automatically if it does not already exist.
    """
    client = _get_client()
    return await asyncio.to_thread(client.add_location_tag, location_id=location_id, tag=tag)


@mcp.tool()
async def remove_location_tag(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    tag: Annotated[str, Field(description="Tag name to remove")],
) -> dict[str, Any]:
    """Remove a tag from a location."""
    client = _get_client()
    return await asyncio.to_thread(client.remove_location_tag, location_id=location_id, tag=tag)


# ---------------------------------------------------------------------------
# Listings tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def get_premium_listings(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
) -> dict[str, Any]:
    """Get premium (directory) listings for a location.

    Returns listings from sites like Google Business Profile, Yelp, Bing Places, etc.
    Each listing includes site name, sync status, display status, and listing URL.
    """
    client = _get_client()
    listings = await asyncio.to_thread(client.fetch_premium_listings, location_id)
    return {"success": True, "listings": listings, "total": len(listings)}


@mcp.tool()
async def get_voice_listings(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
) -> dict[str, Any]:
    """Get voice assistant listings for a location.

    Returns listings for voice platforms like Google Assistant, Amazon Alexa, and Apple Siri.
    """
    client = _get_client()
    listings = await asyncio.to_thread(client.fetch_voice_listings, location_id)
    return {"success": True, "listings": listings, "total": len(listings)}


# ---------------------------------------------------------------------------
# Reviews & Interactions tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def get_interactions(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    first: Annotated[Optional[int], Field(default=None, description="Number of interactions to return")] = None,
    site_urls: Annotated[Optional[list[str]], Field(default=None, description="Filter by site URLs (e.g. ['maps.google.com', 'yelp.com'])")] = None,
    start_date: Annotated[Optional[str], Field(default=None, description="Start date filter in YYYY-MM-DD format")] = None,
    end_date: Annotated[Optional[str], Field(default=None, description="End date filter in YYYY-MM-DD format")] = None,
    category: Annotated[Optional[str], Field(default=None, description="Filter by category: 'Review' or 'Social'")] = None,
    rating_filters: Annotated[Optional[list[int]], Field(default=None, description="Filter by star ratings (e.g. [4, 5] for 4 and 5 star reviews)")] = None,
    fetch_all: Annotated[bool, Field(default=False, description="If true, return all interactions across all pages")] = False,
) -> dict[str, Any]:
    """Get reviews and social interactions for a location.

    Defaults to the last 30 days if no date range is provided.
    Returns reviews with content, rating, site, reviewer name, response status, and more.
    """
    client = _get_client()
    result = await asyncio.to_thread(
        client.fetch_interactions,
        location_id=location_id,
        first=first,
        site_urls=site_urls,
        start_date=start_date,
        end_date=end_date,
        category=category,
        rating_filters=rating_filters,
        fetch_all=fetch_all,
    )
    if isinstance(result, list):
        return {"success": True, "interactions": result, "total": len(result)}
    return result


@mcp.tool()
async def respond_to_review(
    interaction_id: Annotated[str, Field(description="UUID of the interaction (review) to respond to")],
    response_content: Annotated[str, Field(description="Text of your reply (shown publicly where applicable)")],
) -> dict[str, Any]:
    """Post a reply to a review or interaction.

    Get the interaction_id from get_interactions. The response is published publicly
    on the review platform where applicable.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.respond_to_review,
        interaction_id=interaction_id,
        response_content=response_content,
    )


@mcp.tool()
async def edit_review_response(
    review_id: Annotated[str, Field(description="ID of the review (interaction)")],
    response_id: Annotated[str, Field(description="ID of the existing response to edit")],
    response_content: Annotated[str, Field(description="New reply text to replace the current response")],
) -> dict[str, Any]:
    """Edit an existing reply to a review.

    Both the review ID and response ID are required. Get these from get_interactions.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.edit_review_response,
        review_id=review_id,
        response_id=response_id,
        response_content=response_content,
    )


@mcp.tool()
async def archive_review_response(
    response_id: Annotated[str, Field(description="ID of the response to archive/hide")],
) -> dict[str, Any]:
    """Archive (hide) an existing reply to a review.

    The response is hidden but not permanently deleted.
    """
    client = _get_client()
    return await asyncio.to_thread(client.archive_review_response, response_id=response_id)


# ---------------------------------------------------------------------------
# Review analytics tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def get_review_analytics_overview(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    start_date: Annotated[Optional[str], Field(default=None, description="Start date in YYYY-MM-DD format")] = None,
    end_date: Annotated[Optional[str], Field(default=None, description="End date in YYYY-MM-DD format")] = None,
) -> dict[str, Any]:
    """Get overall review analytics for a location.

    Returns aggregate stats: total reviews, average rating, response rate, and more.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.fetch_review_analytics_overview,
        location_id=location_id,
        start_date=start_date,
        end_date=end_date,
    )


@mcp.tool()
async def get_review_analytics_timeline(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    start_date: Annotated[Optional[str], Field(default=None, description="Start date in YYYY-MM-DD format")] = None,
    end_date: Annotated[Optional[str], Field(default=None, description="End date in YYYY-MM-DD format")] = None,
) -> dict[str, Any]:
    """Get review analytics over time for a location.

    Returns review count and rating by time period — useful for trend analysis.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.fetch_review_analytics_timeline,
        location_id=location_id,
        start_date=start_date,
        end_date=end_date,
    )


@mcp.tool()
async def get_review_analytics_sites_stats(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    start_date: Annotated[Optional[str], Field(default=None, description="Start date in YYYY-MM-DD format")] = None,
    end_date: Annotated[Optional[str], Field(default=None, description="End date in YYYY-MM-DD format")] = None,
) -> dict[str, Any]:
    """Get review analytics broken down by site (Google, Yelp, etc.) for a location.

    Returns per-site review counts, average ratings, and response rates.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.fetch_review_analytics_sites_stats,
        location_id=location_id,
        start_date=start_date,
        end_date=end_date,
    )


@mcp.tool()
async def get_review_campaigns(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    start_date: Annotated[Optional[str], Field(default=None, description="Filter campaigns starting from this date (YYYY-MM-DD)")] = None,
    end_date: Annotated[Optional[str], Field(default=None, description="Filter campaigns ending before this date (YYYY-MM-DD)")] = None,
) -> dict[str, Any]:
    """Get review campaigns for a location.

    Returns a list of review request campaigns with their status and metrics.
    """
    client = _get_client()
    campaigns = await asyncio.to_thread(
        client.fetch_review_campaigns,
        location_id=location_id,
        start_date=start_date,
        end_date=end_date,
    )
    return {"success": True, "campaigns": campaigns, "total": len(campaigns)}


@mcp.tool()
async def create_review_campaign(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    name: Annotated[str, Field(description="Campaign name")],
    customers: Annotated[list[dict[str, Any]], Field(description="List of customer dicts with 'name' (required) and optional 'email' and 'phone'. Example: [{'name': 'John', 'email': 'john@example.com'}]")],
    screening: Annotated[Optional[bool], Field(default=None, description="Enable review screening (filters negative reviews before they go public)")] = None,
) -> dict[str, Any]:
    """Create a review campaign to request reviews from customers.

    Sends review requests to the provided customer list. Returns the created campaign.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.create_review_campaign,
        location_id=location_id,
        name=name,
        location_customers=customers,
        screening=screening,
    )


# ---------------------------------------------------------------------------
# Keywords & Rankings tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def get_keywords(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
) -> dict[str, Any]:
    """Get all keywords tracked for a location's ranking performance.

    Returns the list of keywords being monitored, with their IDs and names.
    """
    client = _get_client()
    keywords = await asyncio.to_thread(client.fetch_keywords, location_id)
    return {"success": True, "keywords": keywords, "total": len(keywords)}


@mcp.tool()
async def get_keywords_performance(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    from_date: Annotated[Optional[str], Field(default=None, description="Start date in YYYY-MM-DD format")] = None,
    to_date: Annotated[Optional[str], Field(default=None, description="End date in YYYY-MM-DD format")] = None,
) -> dict[str, Any]:
    """Get ranking performance data for a location's keywords.

    Returns keyword positions and trends over the specified date range.
    """
    client = _get_client()
    performance = await asyncio.to_thread(
        client.fetch_keywords_performance,
        location_id=location_id,
        from_date=from_date,
        to_date=to_date,
    )
    return {"success": True, "performance": performance, "total": len(performance)}


@mcp.tool()
async def add_keywords(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    keywords: Annotated[list[str], Field(description="List of keywords to track (e.g. ['plumber near me', 'emergency plumber'])")],
) -> dict[str, Any]:
    """Add keywords to a location for ranking tracking.

    Returns the created keyword objects with their IDs.
    """
    client = _get_client()
    created = await asyncio.to_thread(client.add_keywords, location_id=location_id, keywords=keywords)
    return {"success": True, "keywords": created, "total": len(created)}


@mcp.tool()
async def archive_keyword(
    keyword_id: Annotated[str, Field(description="Base64-encoded keyword ID (from get_keywords or add_keywords)")],
) -> dict[str, Any]:
    """Archive a keyword so it is no longer tracked.

    Get the keyword_id from get_keywords or add_keywords.
    """
    client = _get_client()
    return await asyncio.to_thread(client.archive_keyword, keyword_id=keyword_id)


@mcp.tool()
async def get_ranking_analytics_timeline(
    location_ids: Annotated[list[str], Field(description="List of base64-encoded location IDs")],
    from_date: Annotated[str, Field(description="Start date in YYYY-MM-DD format")],
    to_date: Annotated[str, Field(description="End date in YYYY-MM-DD format")],
    source: Annotated[list[str], Field(description="List of ranking sources (e.g. ['Google', 'Bing'])")],
) -> dict[str, Any]:
    """Get keyword ranking positions over time for one or more locations.

    Returns timeline data showing how positions have changed across the date range.
    """
    client = _get_client()
    timeline = await asyncio.to_thread(
        client.fetch_ranking_analytics_timeline,
        location_ids=location_ids,
        from_date=from_date,
        to_date=to_date,
        source=source,
    )
    return {"success": True, "timeline": timeline}


@mcp.tool()
async def get_ranking_sitewise_histogram(
    location_ids: Annotated[list[str], Field(description="List of base64-encoded location IDs")],
    from_date: Annotated[str, Field(description="Start date in YYYY-MM-DD format")],
    to_date: Annotated[str, Field(description="End date in YYYY-MM-DD format")],
    source: Annotated[list[str], Field(description="List of ranking sources (e.g. ['Google'])")],
) -> dict[str, Any]:
    """Get a histogram of keyword rankings by position bucket (e.g. top 3, 4-10, 11-20).

    Useful for understanding the distribution of keyword ranking positions.
    """
    client = _get_client()
    histogram = await asyncio.to_thread(
        client.fetch_ranking_sitewise_histogram,
        location_ids=location_ids,
        from_date=from_date,
        to_date=to_date,
        source=source,
    )
    return {"success": True, "histogram": histogram}


# ---------------------------------------------------------------------------
# Analytics tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def get_google_analytics(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    from_date: Annotated[Optional[str], Field(default=None, description="Start date in YYYY-MM-DD format")] = None,
    to_date: Annotated[Optional[str], Field(default=None, description="End date in YYYY-MM-DD format")] = None,
) -> dict[str, Any]:
    """Get Google Business Profile analytics for a location.

    Returns Google insights: searches, views, calls, direction requests, website clicks, etc.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.fetch_google_analytics,
        location_id=location_id,
        from_date=from_date,
        to_date=to_date,
    )


@mcp.tool()
async def get_bing_analytics(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    from_date: Annotated[Optional[str], Field(default=None, description="Start date in YYYY-MM-DD format")] = None,
    to_date: Annotated[Optional[str], Field(default=None, description="End date in YYYY-MM-DD format")] = None,
) -> dict[str, Any]:
    """Get Bing Places analytics for a location.

    Returns Bing insights: views, clicks, and actions on the Bing listing.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.fetch_bing_analytics,
        location_id=location_id,
        from_date=from_date,
        to_date=to_date,
    )


@mcp.tool()
async def get_facebook_analytics(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    from_date: Annotated[Optional[str], Field(default=None, description="Start date in YYYY-MM-DD format")] = None,
    to_date: Annotated[Optional[str], Field(default=None, description="End date in YYYY-MM-DD format")] = None,
) -> dict[str, Any]:
    """Get Facebook page analytics for a location.

    Returns Facebook insights: reach, impressions, page views, and engagement.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.fetch_facebook_analytics,
        location_id=location_id,
        from_date=from_date,
        to_date=to_date,
    )


# ---------------------------------------------------------------------------
# Connected accounts tools
# ---------------------------------------------------------------------------

@mcp.tool()
async def connect_google_account(
    success_url: Annotated[str, Field(description="Your app URL where users are redirected after successful connection")],
    error_url: Annotated[str, Field(description="Your app URL where users are redirected if connection fails")],
) -> dict[str, Any]:
    """Get a URL to connect a Google account for bulk location management.

    The returned URL is valid for 24 hours. Redirect your user to it to start the OAuth flow.
    After connecting, use trigger_connected_account_matches to link Google locations to Synup locations.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.connect_google_account,
        success_url=success_url,
        error_url=error_url,
    )


@mcp.tool()
async def connect_facebook_account(
    success_url: Annotated[str, Field(description="Your app URL where users are redirected after successful connection")],
    error_url: Annotated[str, Field(description="Your app URL where users are redirected if connection fails")],
) -> dict[str, Any]:
    """Get a URL to connect a Facebook account for bulk location management.

    The returned URL is valid for 24 hours. Redirect your user to it to start the OAuth flow.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.connect_facebook_account,
        success_url=success_url,
        error_url=error_url,
    )


@mcp.tool()
async def disconnect_google_account(
    connected_account_id: Annotated[str, Field(description="ID of the Google connected account to disconnect")],
) -> dict[str, Any]:
    """Disconnect a Google connected account from bulk location management."""
    client = _get_client()
    return await asyncio.to_thread(
        client.disconnect_google_account,
        connected_account_id=connected_account_id,
    )


@mcp.tool()
async def disconnect_facebook_account(
    connected_account_id: Annotated[str, Field(description="ID of the Facebook connected account to disconnect")],
) -> dict[str, Any]:
    """Disconnect a Facebook connected account from bulk location management."""
    client = _get_client()
    return await asyncio.to_thread(
        client.disconnect_facebook_account,
        connected_account_id=connected_account_id,
    )


@mcp.tool()
async def get_connected_account_listings(
    connected_account_id: Annotated[str, Field(description="ID of the connected Google or Facebook account")],
    location_info: Annotated[Optional[str], Field(default=None, description="Optional filter: substring to match in street, city, phone, or business name")] = None,
    page: Annotated[Optional[int], Field(default=None, description="Page number for pagination")] = None,
    per_page: Annotated[Optional[int], Field(default=None, description="Items per page (max 500)")] = None,
) -> dict[str, Any]:
    """Get listings (locations) accessible through a connected Google or Facebook account.

    Use this to see which Google/Facebook locations can be linked to Synup locations.
    After reviewing, use confirm_connected_account_matches to link them.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.fetch_connected_account_listings,
        connected_account_id=connected_account_id,
        location_info=location_info,
        page=page,
        per_page=per_page,
    )


@mcp.tool()
async def trigger_connected_account_matches(
    connected_account_ids: Annotated[list[str], Field(description="List of connected account IDs to run matching for")],
) -> dict[str, Any]:
    """Trigger matching of Google/Facebook profile locations to Synup locations.

    Synup will attempt to automatically match connected account listings to Synup locations.
    After triggering, use get_connected_account_listings to review and confirm matches.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.trigger_connected_account_matches,
        connected_account_ids=connected_account_ids,
    )


@mcp.tool()
async def confirm_connected_account_matches(
    match_record_ids: Annotated[list[str], Field(description="List of base64-encoded match record IDs to confirm")],
) -> dict[str, Any]:
    """Confirm suggested matches between connected account listings and Synup locations.

    Get match_record_ids from get_connected_account_listings. Confirming a match
    links the Google/Facebook listing to the corresponding Synup location.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.confirm_connected_account_matches,
        match_record_ids=match_record_ids,
    )


@mcp.tool()
async def connect_listing(
    location_id: Annotated[str, Field(description="Synup location ID (numeric or base64-encoded)")],
    connected_account_listing_id: Annotated[str, Field(description="Listing ID from get_connected_account_listings (records[].id)")],
    connected_account_id: Annotated[str, Field(description="Connected account ID")],
) -> dict[str, Any]:
    """Link a Synup location to a listing from a connected Google or Facebook account.

    Use IDs from get_connected_account_listings to link a specific listing to a Synup location.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.connect_listing,
        location_id=location_id,
        connected_account_listing_id=connected_account_listing_id,
        connected_account_id=connected_account_id,
    )


@mcp.tool()
async def disconnect_listing(
    location_id: Annotated[str, Field(description="Location ID (numeric or base64-encoded)")],
    site: Annotated[str, Field(description="Platform to disconnect: 'GOOGLE' or 'FACEBOOK'")],
) -> dict[str, Any]:
    """Unlink a location from its Google or Facebook listing."""
    client = _get_client()
    return await asyncio.to_thread(
        client.disconnect_listing,
        location_id=location_id,
        site=site,
    )


@mcp.tool()
async def create_gmb_listing(
    location_id: Annotated[str, Field(description="Synup location ID (numeric or base64-encoded)")],
    connected_account_id: Annotated[str, Field(description="Google connected account ID")],
    folder_id: Annotated[Optional[str], Field(default=None, description="Optional GMB folder/group ID")] = None,
) -> dict[str, Any]:
    """Create a Google Business Profile listing for an existing Synup location.

    This process is asynchronous — creation may complete in the background after the call returns.
    Check success in the response and monitor for completion.
    """
    client = _get_client()
    return await asyncio.to_thread(
        client.create_gmb_listing,
        location_id=location_id,
        connected_account_id=connected_account_id,
        folder_id=folder_id,
    )


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Run the Synup MCP server using stdio transport (default for Claude Desktop)."""
    mcp.run()


if __name__ == "__main__":
    main()
