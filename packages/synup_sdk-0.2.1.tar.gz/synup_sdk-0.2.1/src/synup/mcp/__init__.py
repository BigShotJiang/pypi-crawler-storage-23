"""Synup MCP module — exposes synup-sdk as an MCP server for LLM agents."""

from synup.mcp.server import mcp, main

__all__ = ["mcp", "main"]
