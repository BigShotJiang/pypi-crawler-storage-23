# Saigon

Welcome to *Saigon*! This packaage provides a rich set of constructs and reusable components to
build backend applications, reducing boilerplate code to the minimum and allowing you to focus
on the business logic.

Learn more with the [Official Documentation](https://saigon.readthedocs.io/en/latest).
