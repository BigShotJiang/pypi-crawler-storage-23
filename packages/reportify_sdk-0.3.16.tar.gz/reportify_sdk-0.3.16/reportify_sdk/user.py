"""
User Module

Provides access to user-related tools and data.
"""

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from reportify_sdk.client import Reportify


class UserModule:
    """
    User module for accessing user-related tools

    Access through the main client:
        >>> client = Reportify(api_key="xxx")
        >>> companies = client.user.followed_companies()
    """

    def __init__(self, client: "Reportify"):
        self._client = client

    def _get(self, path: str, params: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._client._get(path, params=params)

    def _post(self, path: str, json: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._client._post(path, json=json)

    def followed_companies(self) -> list[dict[str, Any]]:
        """
        Get all companies followed by the user

        Returns a list of companies that the user is following,
        including company details like symbol, name, logo, and follow timestamp.

        Returns:
            List of followed company information

        Example:
            >>> companies = client.user.followed_companies()
            >>> for company in companies:
            ...     print(f"{company['symbol']}: {company['name']}")
        """
        response = self._get("/v1/tools/user/followed-companies")
        return response.get("companies", [])

    def follow_company(self, symbol: str) -> dict[str, Any]:
        """
        Follow a company (add to stock watchlist)

        Args:
            symbol: Stock symbol in market:ticker format (e.g., US:AAPL, HK:00700, SH:600519)

        Returns:
            Followed company information

        Example:
            >>> result = client.user.follow_company("US:AAPL")
            >>> print(f"Followed: {result['symbol']} - {result['name']}")
        """
        return self._post("/v1/tools/user/follow-company", json={"symbol": symbol})

    def unfollow_company(self, symbol: str) -> dict[str, Any]:
        """
        Unfollow a company (remove from stock watchlist)

        Args:
            symbol: Stock symbol in market:ticker format (e.g., US:AAPL, HK:00700, SH:600519)

        Returns:
            Status message

        Example:
            >>> result = client.user.unfollow_company("US:AAPL")
            >>> print(result['message'])
        """
        return self._post("/v1/tools/user/unfollow-company", json={"symbol": symbol})

    def create_follow_group(self, name: str, follow_values: list[dict[str, int | str]] | None = None) -> dict[str, Any]:
        """
        Create a new follow group

        Args:
            name: Group name
            follow_values: List of follow values (each with 'follow_type' as int and 'follow_value' as str)
                          follow_type: 1=company, 3=channel

        Returns:
            Created group information including group_id, name, and count

        Example:
            >>> result = client.user.create_follow_group(
            ...     name="My Stocks",
            ...     follow_values=[
            ...         {"follow_type": 1, "follow_value": "US:AAPL"},
            ...         {"follow_type": 1, "follow_value": "HK:00700"}
            ...     ]
            ... )
            >>> print(f"Created group: {result['group_id']}")
        """
        json_data = {"name": name}
        if follow_values is not None:
            json_data["follow_values"] = follow_values
        return self._post("/v1/tools/user/follow-groups", json=json_data)

    def get_follow_groups(self) -> list[dict[str, Any]]:
        """
        Get all follow groups for the authenticated user

        Returns:
            List of follow groups with group_id, name, and count

        Example:
            >>> groups = client.user.get_follow_groups()
            >>> for group in groups:
            ...     print(f"{group['name']}: {group['count']} items")
        """
        response = self._get("/v1/tools/user/follow-groups")
        return response.get("groups", [])

    def get_follow_group(self, group_id: str) -> dict[str, Any]:
        """
        Get a follow group by ID

        Args:
            group_id: Group ID

        Returns:
            Group information including group_id, name, count, and follow_values

        Example:
            >>> group = client.user.get_follow_group("group_123")
            >>> print(f"{group['name']}: {group['count']} items")
            >>> for fv in group['follow_values']:
            ...     print(f"  - Type {fv['follow_type']}: {fv['follow_value']}")
        """
        return self._get(f"/v1/tools/user/follow-groups/{group_id}")

    def update_follow_group(self, group_id: str, name: str | None = None) -> dict[str, Any]:
        """
        Update a follow group

        Args:
            group_id: Group ID
            name: New group name

        Returns:
            Updated group information

        Example:
            >>> result = client.user.update_follow_group("group_123", name="New Name")
            >>> print(f"Updated: {result['name']}")
        """
        json_data = {}
        if name is not None:
            json_data["name"] = name
        return self._post(f"/v1/tools/user/follow-groups/{group_id}", json=json_data)

    def delete_follow_group(self, group_id: str) -> dict[str, Any]:
        """
        Delete a follow group

        Args:
            group_id: Group ID

        Returns:
            Status message

        Example:
            >>> result = client.user.delete_follow_group("group_123")
            >>> print(result.get('message', 'Deleted'))
        """
        return self._client._delete(f"/v1/tools/user/follow-groups/{group_id}")

    def add_follows_to_group(self, group_id: str, follow_values: list[dict[str, int | str]]) -> dict[str, Any]:
        """
        Add follows to a group

        Args:
            group_id: Group ID
            follow_values: List of follow values (each with 'follow_type' as int and 'follow_value' as str)
                          follow_type: 1=company, 3=channel

        Returns:
            Status message

        Example:
            >>> result = client.user.add_follows_to_group(
            ...     "group_123",
            ...     follow_values=[{"follow_type": 1, "follow_value": "US:TSLA"}]
            ... )
            >>> print(result.get('message', 'Added'))
        """
        return self._post(f"/v1/tools/user/follow-groups/{group_id}/follows", json={"follow_values": follow_values})

    def remove_follows_from_group(self, group_id: str, follow_ids: list[str]) -> dict[str, Any]:
        """
        Remove follows from a group

        Args:
            group_id: Group ID
            follow_ids: List of follow IDs to remove

        Returns:
            Status message

        Example:
            >>> result = client.user.remove_follows_from_group("group_123", ["follow_1", "follow_2"])
            >>> print(result.get('message', 'Removed'))
        """
        return self._client._delete(f"/v1/tools/user/follow-groups/{group_id}/follows", params={"follow_ids": follow_ids})

    def set_group_follows(self, group_id: str, follow_values: list[dict[str, int | str]]) -> dict[str, Any]:
        """
        Set follows for a group (replace all existing follows)

        Args:
            group_id: Group ID
            follow_values: List of follow values (each with 'follow_type' as int and 'follow_value' as str)
                          follow_type: 1=company, 3=channel

        Returns:
            Status message

        Example:
            >>> result = client.user.set_group_follows(
            ...     "group_123",
            ...     follow_values=[
            ...         {"follow_type": 1, "follow_value": "US:AAPL"},
            ...         {"follow_type": 1, "follow_value": "HK:00700"}
            ...     ]
            ... )
            >>> print(result.get('message', 'Set'))
        """
        return self._put(f"/v1/tools/user/follow-groups/{group_id}/follows", json={"follow_values": follow_values})

    def get_follow_group_reports(self, group_id: str, page_num: int = 1, page_size: int = 10) -> dict[str, Any]:
        """
        Get reports for a follow group

        Args:
            group_id: Group ID
            page_num: Page number (default: 1)
            page_size: Page size (default: 10, max: 100)

        Returns:
            Report data including items list, total_count, page_num, and page_size

        Example:
            >>> result = client.user.get_group_reports("group_123", page_num=1, page_size=20)
            >>> print(f"Total: {result['total_count']}")
            >>> for report in result['items']:
            ...     print(report.get('title', 'Untitled'))
        """
        params = {"page_num": page_num, "page_size": page_size}
        return self._get(f"/v1/tools/user/follow-groups/{group_id}/reports", params=params)

    def _put(self, path: str, json: dict[str, Any] | None = None) -> dict[str, Any]:
        return self._client._put(path, json=json)
