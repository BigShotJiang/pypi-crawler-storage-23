import numpy as np
from typing import Optional

class State:
    
    def __init__(self):
        self._rng = np.random.RandomState()
        
    @property
    def rng(self):
        return self._rng
        
    def seed(self, seed: Optional[int] = None):
        self._rng = np.random.RandomState(seed)

state = State()

def seed(s: Optional[int] = None):
    state.seed(s)
