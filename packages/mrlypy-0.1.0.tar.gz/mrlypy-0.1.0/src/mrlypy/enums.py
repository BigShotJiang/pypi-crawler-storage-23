from enum import Enum

class Mode(Enum):
    TYPE = "type"
    TAG = "tag"
    INDEX = "index"
    ENUMERATE = "enumerate"
    RANDOM = "random"
    ROW = "row"
    COLUMN = "column"
    DEPTH = "depth"
