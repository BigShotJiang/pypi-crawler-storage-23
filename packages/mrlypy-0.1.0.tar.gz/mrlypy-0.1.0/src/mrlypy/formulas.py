import numpy as np
from . import binary
from math import ceil, floor, log
from typing import Callable

# GRID

def grid_lines(number: int, level: int) -> int:
    return number**level

def grid_squares(number: int, level: int) -> int:
    return (number**2)**level

def grid_cubes(number: int, level: int) -> int:
    return (number**3)**level

# CARPET

def carpet_fill_squares(number: int, level: int) -> int:
    return (number**2-floor(number/2)**2)**level

def carpet_void_squares(number: int, level: int) -> int:
    return grid_squares(number, level) - carpet_fill_squares(number, level)

def carpet_fill_cubes(number: int, level: int) -> int:
    E = ceil(number/2)
    O = floor(number/2)
    return (E**3 + 3*O*E**2)**level

def carpet_void_cubes(number: int, level: int) -> int:
    return grid_cubes(number, level) - carpet_fill_cubes(number, level)

# NET

def net_fill_squares(number: int, level: int) -> int:
    return (number**2-floor((number+1)/2)**2)**level

def net_void_squares(number: int, level: int) -> int:
    return grid_squares(number, level) - net_fill_squares(number, level)

def net_fill_cubes(number: int, level: int) -> int:
    E = ceil(number/2)
    O = floor(number/2)
    return (O**3 + 3*E*O**2)**level

def net_void_cubes(number: int, level: int) -> int:
    return grid_cubes(number, level) - net_fill_cubes(number, level)

# TREE

def tree_fill_squares(number: int, level: int) -> int:
    return (number*floor((number+1)/2))**level

def tree_void_squares(number: int, level: int) -> int:
    return grid_squares(number, level) - tree_fill_squares(number, level)

def tree_fill_cubes(number: int, level: int) -> int:
    return (number * ceil(number/2)**2)**level

def tree_void_cubes(number: int, level: int) -> int:
    return grid_cubes(number, level) - tree_fill_cubes(number, level)

# VOID

def void_fill_squares(number: int, level: int) -> int:
    return (ceil(number**2/2))**level

def void_void_squares(number: int, level: int) -> int:
    return grid_squares(number, level) - void_fill_squares(number, level)

def void_fill_cubes(number: int, level: int) -> int:
    E = ceil(number/2)
    O = floor(number/2)
    return (E**3 + O**3)**level

def void_void_cubes(number: int, level: int) -> int:
    return grid_cubes(number, level) - void_fill_cubes(number, level)

# RATIOS

def carpet_ratio_2d(number: int, level: int) -> float:
    return carpet_fill_squares(number, level) / grid_squares(number, level)

def carpet_ratio_3d(number: int, level: int) -> float:
    return carpet_fill_cubes(number, level) / grid_cubes(number, level)

def net_ratio_2d(number: int, level: int) -> float:
    return net_fill_squares(number, level) / grid_squares(number, level)

def net_ratio_3d(number: int, level: int) -> float:
    return net_fill_cubes(number, level) / grid_cubes(number, level)

def tree_ratio_2d(number: int, level: int) -> float:
    return tree_fill_squares(number, level) / grid_squares(number, level)

def tree_ratio_3d(number: int, level: int) -> float:
    return tree_fill_cubes(number, level) / grid_cubes(number, level)

def void_ratio_2d(number: int, level: int) -> float:
    return void_fill_squares(number, level) / grid_squares(number, level)

def void_ratio_3d(number: int, level: int) -> float:
    return void_fill_cubes(number, level) / grid_cubes(number, level)

# DIMENSIONS

def calculate_dimension(design: Callable, number: int, dimension: int) -> float:
    if number == 1:
        return float(dimension)
    grid = design(number)
    fill = np.sum(grid)
    if fill <= 0:
        return 0.0
    return log(fill) / log(number)

def carpet_2d_dimension(number: int) -> float:
    return calculate_dimension(binary.carpet_2d, number, 2)

def carpet_3d_dimension(number: int) -> float:
    return calculate_dimension(binary.carpet_3d, number, 3)

def net_2d_dimension(number: int) -> float:
    return calculate_dimension(binary.net_2d, number, 2)

def net_3d_dimension(number: int) -> float:
    return calculate_dimension(binary.net_3d, number, 3)

def tree_2d_dimension(number: int) -> float:
    return calculate_dimension(binary.tree_2d, number, 2)

def tree_3d_dimension(number: int) -> float:
    return calculate_dimension(binary.tree_3d, number, 3)

def void_2d_dimension(number: int) -> float:
    return calculate_dimension(binary.void_2d, number, 2)

def void_3d_dimension(number: int) -> float:
    return calculate_dimension(binary.void_3d, number, 3)
