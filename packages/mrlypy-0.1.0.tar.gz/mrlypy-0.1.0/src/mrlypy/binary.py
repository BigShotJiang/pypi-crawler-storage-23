import numpy as np
from typing import List
from .errors import MrlyError

# ZEROS

def zeros_2d(n: int) -> np.ndarray:
    return np.zeros((n, n), dtype=np.uint8)

def zeros_3d(n: int) -> np.ndarray:
    return np.zeros((n, n, n), dtype=np.uint8)

# ONES

def ones_2d(n: int) -> np.ndarray:
    return np.ones((n, n), dtype=np.uint8)

def ones_3d(n: int) -> np.ndarray:
    return np.ones((n, n, n), dtype=np.uint8)

# NOISE

def noise_2d(n: int, density: float = 0.5, rng=None) -> np.ndarray:
    if rng is None:
        rng = np.random
    return (rng.random((n, n)) < density).astype(np.uint8)

def noise_3d(n: int, density: float = 0.5, rng=None) -> np.ndarray:
    if rng is None:
        rng = np.random
    return (rng.random((n, n, n)) < density).astype(np.uint8)

# CARPET

def carpet_2d(n: int) -> np.ndarray:
    x, y = np.indices((n, n))
    return (1 - (x % 2) * (y % 2)).astype(np.uint8)

def carpet_3d(n: int) -> np.ndarray:
    x, y, z = np.indices((n, n, n))
    return ((x % 2) + (y % 2) + (z % 2) <= 1).astype(np.uint8)

# NET

def net_2d(n: int) -> np.ndarray:
    x, y = np.indices((n, n))
    return (1 - (1 - x % 2) * (1 - y % 2)).astype(np.uint8)

def net_3d(n: int) -> np.ndarray:
    x, y, z = np.indices((n, n, n))
    return ((x % 2) + (y % 2) + (z % 2) > 1).astype(np.uint8)

# TREE

def tree_2d(n: int) -> np.ndarray:
    _, y = np.indices((n, n))
    return (y % 2 == 0).astype(np.uint8)

def tree_3d(n: int) -> np.ndarray:
    x, y, _ = np.indices((n, n, n))
    return ((x % 2 == 0) * (y % 2 == 0)).astype(np.uint8)

# VOID

def void_2d(n: int) -> np.ndarray:
    x, y = np.indices((n, n))
    return ((x + y) % 2 == 0).astype(np.uint8)

def void_3d(n: int) -> np.ndarray:
    x, y, z = np.indices((n, n, n))
    return (((x % 2) == (y % 2)) & ((y % 2) == (z % 2))).astype(np.uint8)

# GEOMETRY

def invert(grid: np.ndarray) -> np.ndarray:
    return 1 - grid

def rotate(grid: np.ndarray, k: int = 1) -> np.ndarray:
    k = k % 4
    if k == 0:
        return grid
    return np.rot90(grid, k=k)

def combine(grid_1: np.ndarray, grid_2: np.ndarray) -> np.ndarray:
    return np.kron(grid_1, grid_2).astype(np.uint8)

def magic(grids: List[np.ndarray]) -> np.ndarray:
    if not grids:
        return np.array([[]], dtype=np.uint8)
    result: np.ndarray = grids[0]
    for i in range(1, len(grids)):
        result = combine(result, grids[i])
    return result

def fractal(grid: np.ndarray, level: int) -> np.ndarray:
    if level == 1:
        return grid
    result = grid
    for _ in range(1, level):
        result = np.kron(result, grid)
    return result.astype(np.uint8)
