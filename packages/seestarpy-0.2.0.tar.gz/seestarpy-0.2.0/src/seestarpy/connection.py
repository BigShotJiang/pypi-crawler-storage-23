import json
import socket
from functools import wraps
from concurrent.futures import ThreadPoolExecutor, as_completed
from concurrent.futures import TimeoutError as FuturesTimeoutError

VERBOSE_LEVEL = 1
DEFAULT_PORT = 4700


def find_seestar():
    """
    Find a Seestar on the local network using mDNS hostname resolution.

    Attempts to resolve ``seestar.local`` via DNS.  This function is called
    automatically when the ``seestarpy`` package is imported, and its result
    is used to set :data:`DEFAULT_IP`.

    If the Seestar is not found (e.g. you are connected to a different
    network), :data:`DEFAULT_IP` falls back to ``"10.0.0.1"`` — the
    Seestar's own Wi-Fi hotspot address.

    Returns
    -------
    str or None
        The IP address of the Seestar if found, otherwise ``None``.

    Examples
    --------

        >>> from seestarpy import connection as conn
        >>> conn.find_seestar()
        Seestar found at: 192.168.1.243
        '192.168.1.243'

    """
    try:
        ip = socket.gethostbyname('seestar.local')
        print(f"Seestar found at: {ip}")
        return ip
    except socket.gaierror:
        print("Seestar not found on network")
        return None


seestar_ip = find_seestar()
DEFAULT_IP = seestar_ip if seestar_ip else "10.0.0.1"
AVAILABLE_IPS = {'seestar.local': DEFAULT_IP}


def multiple_ips(func):
    """
    Decorator that allows a function to run against multiple IP addresses.
    Pass `ips` at call time to override DEFAULT_IP.
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        global DEFAULT_IP
        # Extract the ips list from call arguments
        call_time_ips = kwargs.pop('ips', None)

        def resolve_ip(ip):
            print(ip)
            # Use provided IPs or default to current DEFAULT_IP
            if isinstance(ip, list):
                return [resolve_ip(ip) for ip in ip]
            elif isinstance(ip, str):
                if ip in AVAILABLE_IPS:
                    return AVAILABLE_IPS[ip]
                elif ip in AVAILABLE_IPS.values():
                    return ip
                else:
                    print(f"{ip} is not a valid IP address")
                    return None
            elif isinstance(ip, int):
                name = f"seestar-{ip}.local" if ip > 1 else "seestar.local"
                return resolve_ip(name)
            elif ip is None:
                return DEFAULT_IP

        if isinstance(call_time_ips, str) and call_time_ips.lower() == "all":
            call_time_ips = list(AVAILABLE_IPS.values())
        if not isinstance(call_time_ips, list):
            call_time_ips = [call_time_ips]
        ips = resolve_ip(call_time_ips)

        def call_with_ip(ip):
            """Helper function to call the original function with a specific IP"""
            global DEFAULT_IP
            DEFAULT_IP = ip
            print(f"{func.__name__}: call to {ip}")
            return func(*args, **kwargs)

        results = {}
        original_ip = DEFAULT_IP  # Save the original IP

        try:
            with ThreadPoolExecutor(max_workers=len(ips)) as executor:
                # Submit all tasks
                future_to_ip = {executor.submit(call_with_ip, ip): ip for ip in
                                ips}

                # Collect results as they complete
                for future in future_to_ip:
                    ip = future_to_ip[future]
                    results[ip] = future.result()

        finally:
            DEFAULT_IP = original_ip  # Always restore the original IP

        # Return single result if only one IP, otherwise return list
        return list(results.values())[0] if len(results) == 1 else results

    return wrapper


def find_available_ips(n_ip, timeout=2):
    """
    Find all Seestars on the local network using parallel mDNS lookups.

    Resolves hostnames ``seestar.local``, ``seestar-2.local``, …,
    ``seestar-<n_ip>.local`` in parallel and updates the module-level
    :data:`AVAILABLE_IPS` dictionary with the results.  Use this when
    controlling multiple Seestars from a single script.

    Parameters
    ----------
    n_ip : int
        Maximum Seestar index to search for.  For example, ``n_ip=3``
        will probe ``seestar.local``, ``seestar-2.local``, and
        ``seestar-3.local``.
    timeout : float, optional
        Maximum time in seconds to wait for all lookups.  Default is 2.

    Examples
    --------

        >>> from seestarpy import connection as conn
        >>> conn.find_available_ips(3)
        ✓ Found seestar.local at 192.168.1.243
        ✓ Found seestar-2.local at 192.168.1.244
        ✗ seestar-3.local has no active IP address
        Use connection.AVAILABLE_IPS to get active addresses
        >>> conn.AVAILABLE_IPS
        {'seestar.local': '192.168.1.243', 'seestar-2.local': '192.168.1.244'}

    """
    hostnames = ['seestar.local'] + [f'seestar-{i}.local' for i in
                                     range(2, n_ip + 1)]
    found = {}

    def try_lookup(hostname):
        try:
            ip = socket.gethostbyname(hostname)
            return (hostname, ip)
        except socket.gaierror:
            return None

    with ThreadPoolExecutor(max_workers=16) as executor:
        futures = {executor.submit(try_lookup, h): h for h in hostnames}

    try:
        for future in as_completed(futures, timeout=timeout):
            result = future.result()
            if result:
                name, ip = result
                found[name] = ip
                print(f"✓ Found {name} at {ip}")
    except FuturesTimeoutError:
        pass

    for hostname in hostnames:
        if hostname not in found:
            print(f"✗ {hostname} has no active IP address")

    print("Use connection.AVAILABLE_IPS to get active addresses")
    AVAILABLE_IPS.update(found)


def set_default_ip(n):
    """
    Set :data:`DEFAULT_IP` to the *n*-th Seestar in :data:`AVAILABLE_IPS`.

    This is a convenience shorthand so you can switch between Seestars
    with a single integer instead of typing full hostnames or IPs.

    The mapping follows the Seestar naming convention:

    - ``1`` → ``seestar.local``
    - ``2`` → ``seestar-2.local``
    - ``3`` → ``seestar-3.local``
    - etc.

    Parameters
    ----------
    n : int
        Seestar number (1-based).

    Raises
    ------
    KeyError
        If the corresponding hostname is not in :data:`AVAILABLE_IPS`.
        Call :func:`find_available_ips` first to populate the dictionary.

    Examples
    --------
    ::

        >>> from seestarpy import connection as conn
        >>> conn.find_available_ips(3)
        >>> conn.set_default_ip(2)
        DEFAULT_IP → 192.168.1.83 (seestar-2.local)

    """
    global DEFAULT_IP
    hostname = f"seestar-{n}.local" if n > 1 else "seestar.local"
    if hostname not in AVAILABLE_IPS:
        raise KeyError(
            f"{hostname} not found in AVAILABLE_IPS. "
            f"Call find_available_ips() first. "
            f"Available: {list(AVAILABLE_IPS.keys())}"
        )
    DEFAULT_IP = AVAILABLE_IPS[hostname]
    print(f"DEFAULT_IP \u2192 {DEFAULT_IP} ({hostname})")


def send_command(params):
    """
    Send a JSON-RPC command to the Seestar over TCP.

    Opens a short-lived TCP socket to :data:`DEFAULT_IP` on port
    :data:`DEFAULT_PORT`, sends the JSON payload, and waits for a
    ``\\r\\n``-terminated response.

    Most users will not call this directly — use the functions in
    :mod:`seestarpy.raw` or the top-level convenience API instead.

    Parameters
    ----------
    params : dict
        A dictionary with at least a ``"method"`` key.  An optional
        ``"params"`` key provides method-specific arguments.
        For example: ``{"method": "scope_park", "params": {"equ_mode": True}}``.

    Returns
    -------
    dict or str
        On success, a parsed JSON-RPC response dictionary with keys
        ``'jsonrpc'``, ``'Timestamp'``, ``'method'``, ``'result'``,
        ``'code'``, and ``'id'``.  If the response cannot be parsed as
        JSON, the raw response string is returned instead.

    Examples
    --------

        >>> from seestarpy.connection import send_command
        >>> send_command({"method": "test_connection"})
        {'jsonrpc': '2.0', 'Timestamp': '...', 'method': 'test_connection',
         'result': 'ok', 'code': 0, 'id': 1}

    """
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((DEFAULT_IP, DEFAULT_PORT))

    # params = {"method":"scope_park","params":{"equ_mode":self.is_EQ_mode}}
    cmd = {"id": 1, "verify": True}
    cmd.update(params)

    message = json.dumps(cmd) + "\r\n"
    if VERBOSE_LEVEL >= 1: print(f"\nSending: {message.strip()}")
    s.sendall(message.encode())

    # Read until we get a complete message (ends with \r\n)
    response = ""
    while "\r\n" not in response:
        chunk = s.recv(4096).decode("utf-8")
        if not chunk:
            break
        response += chunk

    if VERBOSE_LEVEL >= 1: print(f"\nRecieved: {response}")
    s.close()

    try:
        parsed = json.loads(response.split("\r\n")[0])
        method = parsed.get("method")
        result = parsed.get("result")
        code = parsed.get("code")
        error = parsed.get("error")

        if VERBOSE_LEVEL >= 2:
            print("\n✅ Response:")
            print(f"  method: {method}")
            print(f"  result: {json.dumps(result, indent=2)}")
            print(f"  code  : {code}")
            print(f"  error : {error}")
        return parsed

    except json.JSONDecodeError:
        print("⚠️ Could not parse response as JSON.")
        print("Raw response:\n", response)

        return response
