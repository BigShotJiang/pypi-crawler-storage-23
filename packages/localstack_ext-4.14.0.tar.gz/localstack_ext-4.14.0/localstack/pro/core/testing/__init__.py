from localstack.pro.core.testing.pytest.persistence import PersistenceMarkers

persistence = PersistenceMarkers
