from localstack.packages import Package
from localstack.pro.core.packages.core import pro_package
@pro_package(name='mqtt')
def mosquitto_package()->Package:from localstack.pro.core.services.iot.packages import mosquitto_package as A;return A
@pro_package(name='iot-rule-engine')
def iot_rule_engine_package()->Package:from localstack.pro.core.services.iot.packages import iot_rule_engine_package as A;return A