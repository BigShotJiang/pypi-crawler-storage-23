# huscy.xml

![PyPi Version](https://img.shields.io/pypi/v/huscy-xml.svg)
![PyPi Status](https://img.shields.io/pypi/status/huscy-xml)
![PyPI Downloads](https://img.shields.io/pypi/dm/huscy-xml)
![PyPI License](https://img.shields.io/pypi/l/huscy-xml?color=yellow)
![Python Versions](https://img.shields.io/pypi/pyversions/huscy-xml.svg)
![Django Versions](https://img.shields.io/pypi/djversions/huscy-xml)



## Requirements

- Python 3.8+
- A supported version of Django

Tox tests on Django versions 4.2, 5.0 and 5.1.



## Installation

To install `husy.xml` simply run:

	pip install huscy.xml



## Configuration

The `huscy.xml` application has to be hooked into the project.

Add `huscy.xml` to `INSTALLED_APPS` in settings module:

```python
INSTALLED_APPS = (
	...

	'huscy.xml',
)
```



## Development

After checking out the repository you should activate any virtual environment.
Install all development and test dependencies:

	make install

Create database tables:

	python manage.py migrate

We assume you're having a running postgres database with a user `huscy` and a database also called `huscy`.
You can easily create them by running

	sudo -u postgres createdb huscy
	sudo -u postgres createuser -d huscy
	sudo -u postgres psql -c "ALTER USER huscy WITH PASSWORD '123';"
	sudo -u postgres psql -c "ALTER DATABASE huscy OWNER TO huscy;"
