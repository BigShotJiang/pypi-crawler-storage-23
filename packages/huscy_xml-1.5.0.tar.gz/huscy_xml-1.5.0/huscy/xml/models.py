from djxml import xmlmodels


class XmlModel(xmlmodels.XmlModel):
    # full_name = serializers.ReadOnlyField(source='get_full_name')

    class Meta:
        extension_ns_uri = "urn:local:number-functions"
        namespaces = {"fn": extension_ns_uri}

    # all_numbers = xmlmodels.XPathIntegerListField("//num")

    # exp_nr = xmlmodels.XPathIntegerListField(
    #   "/Daten/Experimente//*[substring(name(), 1, 10) = 'Experiment']/Exp_Nr")
    # exp_nr = xmlmodels.XPathIntegerListField("//Exp_Nr") --> überall wo Exp_Nr

    participated_experiments = xmlmodels.XPathTextListField(
        "//Experimente//*[substring(name(), 1, 10) = 'Experiment']/Experimentname"
    )
    scheduled_experiments = xmlmodels.XPathTextListField(
        "//Termine//*[substring(name(), 1, 6) = 'Termin']/Experimentname"
    )
    invited_experiments = xmlmodels.XPathTextListField(
        "//Kontaktverlauf//*[substring(name(), 1, 22) = 'Tabelle_Kontaktverlauf']/Kontakt"
    )

    huscy_id = xmlmodels.XPathTextListField("//Huscy_ID")

    def create(self, xml_data):
        return self.create_from_string(**xml_data)
