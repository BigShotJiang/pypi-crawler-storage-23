from django.urls import path

from huscy.xml import views


urlpatterns = [
    path(
        'api/xml/participations/',
        views.ParticipationsXMLView.as_view(),
        name='user-participations-xml',
    ),
    path(
        'api/xml/participation_status/',
        views.ParticipationStatusXMLView.as_view(),
        name='user-participation-status-xml',
    ),
]
