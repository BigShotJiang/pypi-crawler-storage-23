from django.http import QueryDict
from rest_framework import serializers


class ParticipationsSerializer(serializers.Serializer):
    experiment_name = serializers.CharField(max_length=32)


class ParticipationStatusSerializer(serializers.Serializer):
    experiment_name = serializers.CharField(max_length=32)
    subjects = serializers.ListField(
        child=serializers.CharField(allow_blank=False, trim_whitespace=True),
        allow_empty=False,
    )

    def to_internal_value(self, data):
        raw = data.get('subjects')
        if isinstance(data, QueryDict):
            data = data.dict()
        data['subjects'] = [s.strip() for s in raw.split(',') if s.strip()]
        return super().to_internal_value(data)
