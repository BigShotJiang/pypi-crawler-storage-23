"""Presentation layer utilities (user vs debug output formatting)."""
