"""
aaa_mcp/config — Configuration module for MCP Server

Environment and server configuration management.
"""
