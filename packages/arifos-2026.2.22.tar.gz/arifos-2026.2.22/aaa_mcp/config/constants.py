"""Compatibility shim for kernel constants."""

from core.kernel.constants import (
    ConstitutionalThresholds,
    PerformanceLimits,
    SessionConfig,
    ToolDefaults,
)

__all__ = [
    "ConstitutionalThresholds",
    "ToolDefaults",
    "SessionConfig",
    "PerformanceLimits",
]
