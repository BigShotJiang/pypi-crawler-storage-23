# !==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==
# >-|===|>                             Imports                             <|===|-<
# !==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==
from kbasic import cyan, yellow, red, File, TOML, Folder, ensure_path, could_be_path
from os.path import abspath
from os import system
from argparse import ArgumentParser, Namespace

# !==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==
# >-|===|>                           Definitions                           <|===|-<
# !==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==
commands = ['init']
parser = ArgumentParser(
    prog='kpaper', # the program is called kpaper
    usage='kpaper [command] *[arguments]',
    description="a utility for creating python projects corresponding to scientific papers",
    epilog=""
)
parser.add_argument(
    'command', # the action you want kpaper to take
    action='store', nargs='?', help=f"the action you want kpaper to take (one of {",".join(commands)})"
)
parser.add_argument(
    'arguments', 
    action='store', default=[], nargs='*', help=""
)
parser.add_argument(
    '-b', '--basic', 
    action='store_true', help="use a minimal template paper"
)

# !==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==
# >-|===|>                      Command Line Interface                     <|===|-<
# !==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==
def kpaper():
    args = parser.parse_args()
    match args:
        case Namespace(command=None): print(yellow(f'no commands given...\nplease choose use one of the following:\n\t* {'\n\t* '.join(commands)}'))
        case Namespace(command='init'): kpaper_init(args)
        case Namespace(command='add', arguments=x): print(x)
    

# !==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==
# >-|===|>                            Functions                            <|===|-<
# !==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==
def kpaper_init(x: Namespace):
    paths = [abspath(xi) for xi in x.arguments] if len(x.arguments)>0 else ['./']
    for p in paths: copy_template()
def copy_template(template_name: str, destination) -> None:
    ensure_path(destination)
    print(cyan(f'initializing kpaper project in {abspath(destination)}'))
    kpaperDir = File(__file__).parent
    template: Folder = kpaperDir + f'/templates/{template_name}'
    config_file = File(kpaperDir.path + '/templates/config-template')
    config_file.copy(destination+'/.kpaper')
    for c in template.children: 
        name = c.split('/')[-1]
        system(f"cp -r {c} {destination+'/'+name}")    

# !==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==
# >-|===|>                             Classes                             <|===|-<
# !==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==!==
class KPaperConfig(TOML):
    def __init__(self, path: str):
        TOML.__init__(self, path)

class KPaper(Folder):
    def __init__(self, path: str|Folder): pass