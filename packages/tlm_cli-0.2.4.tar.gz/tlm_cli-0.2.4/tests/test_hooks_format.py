"""Tests for hooks_format — hook entry builder and format abstraction."""

import pytest

from tlm.hooks_format import build_hook_entry, build_all_hooks


class TestBuildHookEntry:
    def test_basic_event_hook(self):
        """Build a hook with just event and command."""
        entry = build_hook_entry("SessionStart", "tlm _hook session_start")
        assert entry == {
            "matcher": {"event": "SessionStart"},
            "hooks": [{"type": "command", "command": "tlm _hook session_start"}],
        }

    def test_hook_with_tool_name(self):
        """Build a hook with tool_name matcher."""
        entry = build_hook_entry("PreToolUse", "tlm _hook guard", tool_name="Write")
        assert entry == {
            "matcher": {"event": "PreToolUse", "tool_name": "Write"},
            "hooks": [{"type": "command", "command": "tlm _hook guard"}],
        }

    def test_hook_without_tool_name_has_no_tool_key(self):
        """When tool_name is None, matcher should not have tool_name key."""
        entry = build_hook_entry("Stop", "tlm _hook stop")
        assert "tool_name" not in entry["matcher"]


class TestBuildAllHooks:
    def test_returns_list(self):
        """build_all_hooks should return a list."""
        hooks = build_all_hooks()
        assert isinstance(hooks, list)

    def test_has_session_start(self):
        """Should include SessionStart hook."""
        hooks = build_all_hooks()
        events = [h["matcher"]["event"] for h in hooks]
        assert "SessionStart" in events

    def test_has_user_prompt_submit(self):
        """Should include UserPromptSubmit hook."""
        hooks = build_all_hooks()
        events = [h["matcher"]["event"] for h in hooks]
        assert "UserPromptSubmit" in events

    def test_has_write_guard(self):
        """Should include PreToolUse Write guard."""
        hooks = build_all_hooks()
        write_hooks = [
            h for h in hooks
            if h["matcher"].get("event") == "PreToolUse"
            and h["matcher"].get("tool_name") == "Write"
        ]
        assert len(write_hooks) == 1

    def test_has_edit_guard(self):
        """Should include PreToolUse Edit guard."""
        hooks = build_all_hooks()
        edit_hooks = [
            h for h in hooks
            if h["matcher"].get("event") == "PreToolUse"
            and h["matcher"].get("tool_name") == "Edit"
        ]
        assert len(edit_hooks) == 1

    def test_has_bash_compliance(self):
        """Should include PreToolUse Bash compliance hook."""
        hooks = build_all_hooks()
        bash_hooks = [
            h for h in hooks
            if h["matcher"].get("event") == "PreToolUse"
            and h["matcher"].get("tool_name") == "Bash"
        ]
        assert len(bash_hooks) == 1

    def test_has_spec_review_post_hook(self):
        """Should include PostToolUse Write spec_review hook."""
        hooks = build_all_hooks()
        post_write = [
            h for h in hooks
            if h["matcher"].get("event") == "PostToolUse"
            and h["matcher"].get("tool_name") == "Write"
        ]
        assert len(post_write) == 1

    def test_has_stop_hook(self):
        """Should include Stop hook."""
        hooks = build_all_hooks()
        events = [h["matcher"]["event"] for h in hooks]
        assert "Stop" in events

    def test_all_hooks_have_correct_structure(self):
        """Every hook entry should have matcher and hooks list."""
        hooks = build_all_hooks()
        for hook in hooks:
            assert "matcher" in hook
            assert "hooks" in hook
            assert isinstance(hook["hooks"], list)
            assert len(hook["hooks"]) == 1
            assert hook["hooks"][0]["type"] == "command"
            assert hook["hooks"][0]["command"].startswith("tlm _hook")
