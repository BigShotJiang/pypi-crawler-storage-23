"""Hook format abstraction — centralizes Claude Code hook entry format.

Claude Code hook format has changed before (commit 0952734) and will change again.
This module ensures future format changes only require updating ONE function.
"""


def build_hook_entry(event: str, command: str, tool_name: str | None = None) -> dict:
    """Build a single hook entry in whatever format Claude Code currently expects.

    Centralizes format so future changes require updating ONE function.
    """
    matcher = {"event": event}
    if tool_name:
        matcher["tool_name"] = tool_name
    return {
        "matcher": matcher,
        "hooks": [{"type": "command", "command": command}],
    }


def build_all_hooks() -> list[dict]:
    """Build the complete TLM hook list."""
    return [
        build_hook_entry("SessionStart", "tlm _hook session_start"),
        build_hook_entry("UserPromptSubmit", "tlm _hook prompt_submit"),
        build_hook_entry("PreToolUse", "tlm _hook guard", tool_name="Write"),
        build_hook_entry("PreToolUse", "tlm _hook guard", tool_name="Edit"),
        build_hook_entry("PreToolUse", "tlm _hook compliance", tool_name="Bash"),
        build_hook_entry("PostToolUse", "tlm _hook spec_review", tool_name="Write"),
        build_hook_entry("Stop", "tlm _hook stop"),
    ]
