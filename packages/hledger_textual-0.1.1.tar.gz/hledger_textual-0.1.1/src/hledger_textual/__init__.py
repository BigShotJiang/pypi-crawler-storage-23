"""A terminal user interface for managing hledger journal transactions."""

__version__ = "0.1.0"
