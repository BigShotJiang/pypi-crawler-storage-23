SEGMENT_DTYPE = (
    ('streamline', 'i8'),
    ('start', 'f4', 3),
    ('end', 'f4', 3),
    ('orientation', 'f4', 3),
    ('id', 'i8')
)
