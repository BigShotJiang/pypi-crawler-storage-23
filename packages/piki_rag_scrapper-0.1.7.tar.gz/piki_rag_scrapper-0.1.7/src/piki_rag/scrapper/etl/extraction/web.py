import asyncio
from urllib.parse import urlparse

import trafilatura
from piki_rag.common.exception import WebScrappingException
from playwright.async_api import async_playwright
from playwright_stealth import Stealth

from .common import Extractor


def async_to_sync(coro):
    try:
        loop = asyncio.get_running_loop()
        future = asyncio.run_coroutine_threadsafe(coro, loop)
        return future.result()
    except RuntimeError:
        return asyncio.run(coro)


class DefaultWebExtractor(Extractor):
    def __init__(self, timeout: int = 30000, headless: bool = True):
        self.timeout = timeout
        self.headless = headless

    def is_extractable(self, path: str) -> bool:
        return path and urlparse(path).scheme in ["http", "https"]

    def extract(self, path) -> str:
        return async_to_sync(self.extract_async(path))

    async def extract_async(self, path: str) -> str:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=self.headless)
            page = None
            try:
                page = await browser.new_page()
                await Stealth().apply_stealth_async(page)
                await page.goto(path, timeout=self.timeout)
                try:
                    await page.wait_for_load_state('networkidle', timeout=self.timeout)
                except Exception as e:
                    if self.headless:
                        raise WebScrappingException() from e
                html = await page.content()
                text = trafilatura.extract(html, include_comments=False, include_tables=True)
                if not text:
                    raise WebScrappingException(f"Текст для ресурса {path} не найден")
                return text
            except WebScrappingException:
                raise
            except Exception as e:
                raise WebScrappingException() from e
            finally:
                if page:
                    await page.close()


class MultiStrategyWebExtractor(Extractor):
    def __init__(self, timeout: int = 30000):
        self.web_extractors = [
            DefaultWebExtractor(timeout, True),
            DefaultWebExtractor(timeout, False)
        ]

    def is_extractable(self, path: str) -> bool:
        return self.web_extractors[0].is_extractable(path)

    def extract(self, path: str) -> str:
        last_error = None
        for extractor in self.web_extractors:
            try:
                result = extractor.extract(path)
                if result:
                    return result
            except WebScrappingException as e:
                last_error = e
                continue

        if last_error:
            raise WebScrappingException() from last_error
        raise WebScrappingException()
