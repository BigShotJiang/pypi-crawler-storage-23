SUPPORT_FORMS: dict[str, str] = {
    "default": "plain.support.forms.SupportForm",
}
SUPPORT_EMAIL: str
