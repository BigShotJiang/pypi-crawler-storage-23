"""pybhatlib: Python implementation of BHATLIB for matrix-based econometric inference."""

from pybhatlib._version import __version__

__all__ = ["__version__"]
