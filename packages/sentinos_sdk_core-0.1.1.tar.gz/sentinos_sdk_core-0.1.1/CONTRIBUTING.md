# Contributing

This repository contains `sentinos-sdk-core`, the low-level generated Python client for the Sentinos API.

Most users should use the ergonomic wrapper SDK instead:

- `pip install sentinos`

## Development setup

```bash
python3 -m venv .venv && source .venv/bin/activate
python -m pip install --upgrade pip
pip install -U ruff build twine
python -m ruff check sentinos_core
python -m build
python -m twine check dist/*
```

## Regenerating

The code under `sentinos_core/` is generated. Manual edits should be avoided unless you are fixing generation bugs.

