from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.arbiter_active_policies_env import ArbiterActivePoliciesEnv
from ...models.arbiter_active_policies_response_200 import ArbiterActivePoliciesResponse200
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    tenant_id: str,
    tool: str,
    env: ArbiterActivePoliciesEnv | Unset = UNSET,
    tag: str | Unset = UNSET,
) -> dict[str, Any]:
    params: dict[str, Any] = {}

    params["tenant_id"] = tenant_id

    params["tool"] = tool

    json_env: str | Unset = UNSET
    if not isinstance(env, Unset):
        json_env = env.value

    params["env"] = json_env

    params["tag"] = tag

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/arbitr/policies/active",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ArbiterActivePoliciesResponse200 | None:
    if response.status_code == 200:
        response_200 = ArbiterActivePoliciesResponse200.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ArbiterActivePoliciesResponse200]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: str,
    tool: str,
    env: ArbiterActivePoliciesEnv | Unset = UNSET,
    tag: str | Unset = UNSET,
) -> Response[ArbiterActivePoliciesResponse200]:
    """List active policy keys for a tenant and tool (scope/status filtered)

    Args:
        tenant_id (str):
        tool (str):
        env (ArbiterActivePoliciesEnv | Unset):
        tag (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ArbiterActivePoliciesResponse200]
    """

    kwargs = _get_kwargs(
        tenant_id=tenant_id,
        tool=tool,
        env=env,
        tag=tag,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: str,
    tool: str,
    env: ArbiterActivePoliciesEnv | Unset = UNSET,
    tag: str | Unset = UNSET,
) -> ArbiterActivePoliciesResponse200 | None:
    """List active policy keys for a tenant and tool (scope/status filtered)

    Args:
        tenant_id (str):
        tool (str):
        env (ArbiterActivePoliciesEnv | Unset):
        tag (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ArbiterActivePoliciesResponse200
    """

    return sync_detailed(
        client=client,
        tenant_id=tenant_id,
        tool=tool,
        env=env,
        tag=tag,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: str,
    tool: str,
    env: ArbiterActivePoliciesEnv | Unset = UNSET,
    tag: str | Unset = UNSET,
) -> Response[ArbiterActivePoliciesResponse200]:
    """List active policy keys for a tenant and tool (scope/status filtered)

    Args:
        tenant_id (str):
        tool (str):
        env (ArbiterActivePoliciesEnv | Unset):
        tag (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ArbiterActivePoliciesResponse200]
    """

    kwargs = _get_kwargs(
        tenant_id=tenant_id,
        tool=tool,
        env=env,
        tag=tag,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    tenant_id: str,
    tool: str,
    env: ArbiterActivePoliciesEnv | Unset = UNSET,
    tag: str | Unset = UNSET,
) -> ArbiterActivePoliciesResponse200 | None:
    """List active policy keys for a tenant and tool (scope/status filtered)

    Args:
        tenant_id (str):
        tool (str):
        env (ArbiterActivePoliciesEnv | Unset):
        tag (str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ArbiterActivePoliciesResponse200
    """

    return (
        await asyncio_detailed(
            client=client,
            tenant_id=tenant_id,
            tool=tool,
            env=env,
            tag=tag,
        )
    ).parsed
