from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.workforce_token_session import WorkforceTokenSession


T = TypeVar("T", bound="ControlplaneListWorkforceSessionsResponse200")


@_attrs_define
class ControlplaneListWorkforceSessionsResponse200:
    """
    Attributes:
        sessions (list[WorkforceTokenSession]):
    """

    sessions: list[WorkforceTokenSession]

    def to_dict(self) -> dict[str, Any]:
        sessions = []
        for sessions_item_data in self.sessions:
            sessions_item = sessions_item_data.to_dict()
            sessions.append(sessions_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "sessions": sessions,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.workforce_token_session import WorkforceTokenSession

        d = dict(src_dict)
        sessions = []
        _sessions = d.pop("sessions")
        for sessions_item_data in _sessions:
            sessions_item = WorkforceTokenSession.from_dict(sessions_item_data)

            sessions.append(sessions_item)

        controlplane_list_workforce_sessions_response_200 = cls(
            sessions=sessions,
        )

        return controlplane_list_workforce_sessions_response_200
