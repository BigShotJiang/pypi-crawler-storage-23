from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.escalation_record import EscalationRecord


T = TypeVar("T", bound="KernelGetEscalationResponse200")


@_attrs_define
class KernelGetEscalationResponse200:
    """
    Attributes:
        escalation (EscalationRecord):
    """

    escalation: EscalationRecord

    def to_dict(self) -> dict[str, Any]:
        escalation = self.escalation.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "escalation": escalation,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.escalation_record import EscalationRecord

        d = dict(src_dict)
        escalation = EscalationRecord.from_dict(d.pop("escalation"))

        kernel_get_escalation_response_200 = cls(
            escalation=escalation,
        )

        return kernel_get_escalation_response_200
