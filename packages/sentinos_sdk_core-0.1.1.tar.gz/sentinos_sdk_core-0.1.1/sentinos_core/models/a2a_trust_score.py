from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

if TYPE_CHECKING:
    from ..models.a2a_trust_score_last_violations_item import A2ATrustScoreLastViolationsItem
    from ..models.a2a_trust_score_score_factors import A2ATrustScoreScoreFactors


T = TypeVar("T", bound="A2ATrustScore")


@_attrs_define
class A2ATrustScore:
    """
    Attributes:
        agent_id (str):
        agent_trust_score (float):
        score_factors (A2ATrustScoreScoreFactors):
        last_violations (list[A2ATrustScoreLastViolationsItem]):
        attestation_status (str):
        updated_at (datetime.datetime):
    """

    agent_id: str
    agent_trust_score: float
    score_factors: A2ATrustScoreScoreFactors
    last_violations: list[A2ATrustScoreLastViolationsItem]
    attestation_status: str
    updated_at: datetime.datetime

    def to_dict(self) -> dict[str, Any]:
        agent_id = self.agent_id

        agent_trust_score = self.agent_trust_score

        score_factors = self.score_factors.to_dict()

        last_violations = []
        for last_violations_item_data in self.last_violations:
            last_violations_item = last_violations_item_data.to_dict()
            last_violations.append(last_violations_item)

        attestation_status = self.attestation_status

        updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "agent_id": agent_id,
                "agent_trust_score": agent_trust_score,
                "score_factors": score_factors,
                "last_violations": last_violations,
                "attestation_status": attestation_status,
                "updated_at": updated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.a2a_trust_score_last_violations_item import A2ATrustScoreLastViolationsItem
        from ..models.a2a_trust_score_score_factors import A2ATrustScoreScoreFactors

        d = dict(src_dict)
        agent_id = d.pop("agent_id")

        agent_trust_score = d.pop("agent_trust_score")

        score_factors = A2ATrustScoreScoreFactors.from_dict(d.pop("score_factors"))

        last_violations = []
        _last_violations = d.pop("last_violations")
        for last_violations_item_data in _last_violations:
            last_violations_item = A2ATrustScoreLastViolationsItem.from_dict(last_violations_item_data)

            last_violations.append(last_violations_item)

        attestation_status = d.pop("attestation_status")

        updated_at = isoparse(d.pop("updated_at"))

        a2a_trust_score = cls(
            agent_id=agent_id,
            agent_trust_score=agent_trust_score,
            score_factors=score_factors,
            last_violations=last_violations,
            attestation_status=attestation_status,
            updated_at=updated_at,
        )

        return a2a_trust_score
