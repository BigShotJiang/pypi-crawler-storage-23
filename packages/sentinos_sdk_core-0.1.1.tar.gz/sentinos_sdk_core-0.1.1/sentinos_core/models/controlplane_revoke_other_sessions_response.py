from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

T = TypeVar("T", bound="ControlplaneRevokeOtherSessionsResponse")


@_attrs_define
class ControlplaneRevokeOtherSessionsResponse:
    """
    Attributes:
        ok (bool):
        revoked (int):
    """

    ok: bool
    revoked: int

    def to_dict(self) -> dict[str, Any]:
        ok = self.ok

        revoked = self.revoked

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "ok": ok,
                "revoked": revoked,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ok = d.pop("ok")

        revoked = d.pop("revoked")

        controlplane_revoke_other_sessions_response = cls(
            ok=ok,
            revoked=revoked,
        )

        return controlplane_revoke_other_sessions_response
