from enum import Enum


class ChronosSnapshotCreateResponseStatus(str, Enum):
    PENDING = "pending"
    READY = "ready"

    def __str__(self) -> str:
        return str(self.value)
