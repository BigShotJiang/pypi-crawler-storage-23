from enum import Enum


class IntegrationChannelHealthStatus(str, Enum):
    DISABLED = "disabled"
    HEALTHY = "healthy"
    INVALID_CONFIG = "invalid_config"

    def __str__(self) -> str:
        return str(self.value)
