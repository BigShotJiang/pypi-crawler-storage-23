from enum import Enum


class ExportSIEMBodyDestinationType(str, Enum):
    SPLUNK_HEC = "SPLUNK_HEC"

    def __str__(self) -> str:
        return str(self.value)
