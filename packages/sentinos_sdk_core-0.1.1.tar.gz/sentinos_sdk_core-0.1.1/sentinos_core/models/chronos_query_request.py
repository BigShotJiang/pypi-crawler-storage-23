from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ChronosQueryRequest")


@_attrs_define
class ChronosQueryRequest:
    """
    Attributes:
        tenant_id (str):
        query (str):
        depth (int | Unset):
        limit (int | Unset):
        include_decision_traces (bool | Unset):
    """

    tenant_id: str
    query: str
    depth: int | Unset = UNSET
    limit: int | Unset = UNSET
    include_decision_traces: bool | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        query = self.query

        depth = self.depth

        limit = self.limit

        include_decision_traces = self.include_decision_traces

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "query": query,
            }
        )
        if depth is not UNSET:
            field_dict["depth"] = depth
        if limit is not UNSET:
            field_dict["limit"] = limit
        if include_decision_traces is not UNSET:
            field_dict["include_decision_traces"] = include_decision_traces

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        tenant_id = d.pop("tenant_id")

        query = d.pop("query")

        depth = d.pop("depth", UNSET)

        limit = d.pop("limit", UNSET)

        include_decision_traces = d.pop("include_decision_traces", UNSET)

        chronos_query_request = cls(
            tenant_id=tenant_id,
            query=query,
            depth=depth,
            limit=limit,
            include_decision_traces=include_decision_traces,
        )

        return chronos_query_request
