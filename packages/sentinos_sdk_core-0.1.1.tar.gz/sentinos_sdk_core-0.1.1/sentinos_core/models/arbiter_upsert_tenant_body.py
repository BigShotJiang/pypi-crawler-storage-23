from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.arbiter_upsert_tenant_body_config import ArbiterUpsertTenantBodyConfig


T = TypeVar("T", bound="ArbiterUpsertTenantBody")


@_attrs_define
class ArbiterUpsertTenantBody:
    """
    Attributes:
        config (ArbiterUpsertTenantBodyConfig):
    """

    config: ArbiterUpsertTenantBodyConfig

    def to_dict(self) -> dict[str, Any]:
        config = self.config.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "config": config,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.arbiter_upsert_tenant_body_config import ArbiterUpsertTenantBodyConfig

        d = dict(src_dict)
        config = ArbiterUpsertTenantBodyConfig.from_dict(d.pop("config"))

        arbiter_upsert_tenant_body = cls(
            config=config,
        )

        return arbiter_upsert_tenant_body
