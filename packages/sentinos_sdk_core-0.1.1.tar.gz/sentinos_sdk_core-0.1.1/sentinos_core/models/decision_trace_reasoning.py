from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.decision_trace_reasoning_garbage_can_context import DecisionTraceReasoningGarbageCanContext


T = TypeVar("T", bound="DecisionTraceReasoning")


@_attrs_define
class DecisionTraceReasoning:
    """
    Attributes:
        captured_at_decision_time (bool | Unset):
        pattern_recognized (str | Unset):
        satisficing_threshold (float | Unset):
        alternatives_considered (int | Unset):
        garbage_can_context (DecisionTraceReasoningGarbageCanContext | Unset):
    """

    captured_at_decision_time: bool | Unset = UNSET
    pattern_recognized: str | Unset = UNSET
    satisficing_threshold: float | Unset = UNSET
    alternatives_considered: int | Unset = UNSET
    garbage_can_context: DecisionTraceReasoningGarbageCanContext | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        captured_at_decision_time = self.captured_at_decision_time

        pattern_recognized = self.pattern_recognized

        satisficing_threshold = self.satisficing_threshold

        alternatives_considered = self.alternatives_considered

        garbage_can_context: dict[str, Any] | Unset = UNSET
        if not isinstance(self.garbage_can_context, Unset):
            garbage_can_context = self.garbage_can_context.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if captured_at_decision_time is not UNSET:
            field_dict["captured_at_decision_time"] = captured_at_decision_time
        if pattern_recognized is not UNSET:
            field_dict["pattern_recognized"] = pattern_recognized
        if satisficing_threshold is not UNSET:
            field_dict["satisficing_threshold"] = satisficing_threshold
        if alternatives_considered is not UNSET:
            field_dict["alternatives_considered"] = alternatives_considered
        if garbage_can_context is not UNSET:
            field_dict["garbage_can_context"] = garbage_can_context

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.decision_trace_reasoning_garbage_can_context import DecisionTraceReasoningGarbageCanContext

        d = dict(src_dict)
        captured_at_decision_time = d.pop("captured_at_decision_time", UNSET)

        pattern_recognized = d.pop("pattern_recognized", UNSET)

        satisficing_threshold = d.pop("satisficing_threshold", UNSET)

        alternatives_considered = d.pop("alternatives_considered", UNSET)

        _garbage_can_context = d.pop("garbage_can_context", UNSET)
        garbage_can_context: DecisionTraceReasoningGarbageCanContext | Unset
        if isinstance(_garbage_can_context, Unset):
            garbage_can_context = UNSET
        else:
            garbage_can_context = DecisionTraceReasoningGarbageCanContext.from_dict(_garbage_can_context)

        decision_trace_reasoning = cls(
            captured_at_decision_time=captured_at_decision_time,
            pattern_recognized=pattern_recognized,
            satisficing_threshold=satisficing_threshold,
            alternatives_considered=alternatives_considered,
            garbage_can_context=garbage_can_context,
        )

        return decision_trace_reasoning
