from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ChronosIngestRecord")


@_attrs_define
class ChronosIngestRecord:
    """
    Attributes:
        ingest_id (UUID):
        tenant_id (str):
        trace_ids (list[UUID]):
        status (str):
        attempts (int):
        updated_at (datetime.datetime):
        last_error (str | Unset):
        last_http_status (int | Unset):
        next_retry_at (datetime.datetime | Unset):
    """

    ingest_id: UUID
    tenant_id: str
    trace_ids: list[UUID]
    status: str
    attempts: int
    updated_at: datetime.datetime
    last_error: str | Unset = UNSET
    last_http_status: int | Unset = UNSET
    next_retry_at: datetime.datetime | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        ingest_id = str(self.ingest_id)

        tenant_id = self.tenant_id

        trace_ids = []
        for trace_ids_item_data in self.trace_ids:
            trace_ids_item = str(trace_ids_item_data)
            trace_ids.append(trace_ids_item)

        status = self.status

        attempts = self.attempts

        updated_at = self.updated_at.isoformat()

        last_error = self.last_error

        last_http_status = self.last_http_status

        next_retry_at: str | Unset = UNSET
        if not isinstance(self.next_retry_at, Unset):
            next_retry_at = self.next_retry_at.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "ingest_id": ingest_id,
                "tenant_id": tenant_id,
                "trace_ids": trace_ids,
                "status": status,
                "attempts": attempts,
                "updated_at": updated_at,
            }
        )
        if last_error is not UNSET:
            field_dict["last_error"] = last_error
        if last_http_status is not UNSET:
            field_dict["last_http_status"] = last_http_status
        if next_retry_at is not UNSET:
            field_dict["next_retry_at"] = next_retry_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ingest_id = UUID(d.pop("ingest_id"))

        tenant_id = d.pop("tenant_id")

        trace_ids = []
        _trace_ids = d.pop("trace_ids")
        for trace_ids_item_data in _trace_ids:
            trace_ids_item = UUID(trace_ids_item_data)

            trace_ids.append(trace_ids_item)

        status = d.pop("status")

        attempts = d.pop("attempts")

        updated_at = isoparse(d.pop("updated_at"))

        last_error = d.pop("last_error", UNSET)

        last_http_status = d.pop("last_http_status", UNSET)

        _next_retry_at = d.pop("next_retry_at", UNSET)
        next_retry_at: datetime.datetime | Unset
        if isinstance(_next_retry_at, Unset):
            next_retry_at = UNSET
        else:
            next_retry_at = isoparse(_next_retry_at)

        chronos_ingest_record = cls(
            ingest_id=ingest_id,
            tenant_id=tenant_id,
            trace_ids=trace_ids,
            status=status,
            attempts=attempts,
            updated_at=updated_at,
            last_error=last_error,
            last_http_status=last_http_status,
            next_retry_at=next_retry_at,
        )

        return chronos_ingest_record
