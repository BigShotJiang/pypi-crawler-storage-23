from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.autonomy_session import AutonomySession


T = TypeVar("T", bound="KernelListAutonomySessionsResponse200")


@_attrs_define
class KernelListAutonomySessionsResponse200:
    """
    Attributes:
        sessions (list[AutonomySession]):
    """

    sessions: list[AutonomySession]

    def to_dict(self) -> dict[str, Any]:
        sessions = []
        for sessions_item_data in self.sessions:
            sessions_item = sessions_item_data.to_dict()
            sessions.append(sessions_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "sessions": sessions,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.autonomy_session import AutonomySession

        d = dict(src_dict)
        sessions = []
        _sessions = d.pop("sessions")
        for sessions_item_data in _sessions:
            sessions_item = AutonomySession.from_dict(sessions_item_data)

            sessions.append(sessions_item)

        kernel_list_autonomy_sessions_response_200 = cls(
            sessions=sessions,
        )

        return kernel_list_autonomy_sessions_response_200
