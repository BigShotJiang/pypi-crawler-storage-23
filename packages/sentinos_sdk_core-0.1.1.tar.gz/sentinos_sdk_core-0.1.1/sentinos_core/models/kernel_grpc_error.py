from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..models.kernel_grpc_error_code import KernelGRPCErrorCode

T = TypeVar("T", bound="KernelGRPCError")


@_attrs_define
class KernelGRPCError:
    """
    Attributes:
        code (KernelGRPCErrorCode):
        message (str):
    """

    code: KernelGRPCErrorCode
    message: str

    def to_dict(self) -> dict[str, Any]:
        code = self.code.value

        message = self.message

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "code": code,
                "message": message,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        code = KernelGRPCErrorCode(d.pop("code"))

        message = d.pop("message")

        kernel_grpc_error = cls(
            code=code,
            message=message,
        )

        return kernel_grpc_error
