from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="GovernanceViolation")


@_attrs_define
class GovernanceViolation:
    """
    Attributes:
        trace_id (UUID | Unset):
        tenant_id (str | Unset):
        policy_id (str | Unset):
        decision (str | Unset):
        reason (str | Unset):
        governance_category (str | Unset):
        alert_on_violation (bool | Unset):
        alert_severity (str | Unset):
        occurred_at (datetime.datetime | Unset):
    """

    trace_id: UUID | Unset = UNSET
    tenant_id: str | Unset = UNSET
    policy_id: str | Unset = UNSET
    decision: str | Unset = UNSET
    reason: str | Unset = UNSET
    governance_category: str | Unset = UNSET
    alert_on_violation: bool | Unset = UNSET
    alert_severity: str | Unset = UNSET
    occurred_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        trace_id: str | Unset = UNSET
        if not isinstance(self.trace_id, Unset):
            trace_id = str(self.trace_id)

        tenant_id = self.tenant_id

        policy_id = self.policy_id

        decision = self.decision

        reason = self.reason

        governance_category = self.governance_category

        alert_on_violation = self.alert_on_violation

        alert_severity = self.alert_severity

        occurred_at: str | Unset = UNSET
        if not isinstance(self.occurred_at, Unset):
            occurred_at = self.occurred_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if trace_id is not UNSET:
            field_dict["trace_id"] = trace_id
        if tenant_id is not UNSET:
            field_dict["tenant_id"] = tenant_id
        if policy_id is not UNSET:
            field_dict["policy_id"] = policy_id
        if decision is not UNSET:
            field_dict["decision"] = decision
        if reason is not UNSET:
            field_dict["reason"] = reason
        if governance_category is not UNSET:
            field_dict["governance_category"] = governance_category
        if alert_on_violation is not UNSET:
            field_dict["alert_on_violation"] = alert_on_violation
        if alert_severity is not UNSET:
            field_dict["alert_severity"] = alert_severity
        if occurred_at is not UNSET:
            field_dict["occurred_at"] = occurred_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _trace_id = d.pop("trace_id", UNSET)
        trace_id: UUID | Unset
        if isinstance(_trace_id, Unset):
            trace_id = UNSET
        else:
            trace_id = UUID(_trace_id)

        tenant_id = d.pop("tenant_id", UNSET)

        policy_id = d.pop("policy_id", UNSET)

        decision = d.pop("decision", UNSET)

        reason = d.pop("reason", UNSET)

        governance_category = d.pop("governance_category", UNSET)

        alert_on_violation = d.pop("alert_on_violation", UNSET)

        alert_severity = d.pop("alert_severity", UNSET)

        _occurred_at = d.pop("occurred_at", UNSET)
        occurred_at: datetime.datetime | Unset
        if isinstance(_occurred_at, Unset):
            occurred_at = UNSET
        else:
            occurred_at = isoparse(_occurred_at)

        governance_violation = cls(
            trace_id=trace_id,
            tenant_id=tenant_id,
            policy_id=policy_id,
            decision=decision,
            reason=reason,
            governance_category=governance_category,
            alert_on_violation=alert_on_violation,
            alert_severity=alert_severity,
            occurred_at=occurred_at,
        )

        governance_violation.additional_properties = d
        return governance_violation

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
