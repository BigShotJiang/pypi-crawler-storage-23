from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.kernel_grpc_error import KernelGRPCError


T = TypeVar("T", bound="KernelGRPCErrorEnvelope")


@_attrs_define
class KernelGRPCErrorEnvelope:
    """
    Attributes:
        error (KernelGRPCError):
    """

    error: KernelGRPCError

    def to_dict(self) -> dict[str, Any]:
        error = self.error.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "error": error,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.kernel_grpc_error import KernelGRPCError

        d = dict(src_dict)
        error = KernelGRPCError.from_dict(d.pop("error"))

        kernel_grpc_error_envelope = cls(
            error=error,
        )

        return kernel_grpc_error_envelope
