from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..models.condition_ast_op import ConditionAstOp
from ..models.condition_ast_type import ConditionAstType
from ..types import UNSET, Unset

T = TypeVar("T", bound="ConditionAst")


@_attrs_define
class ConditionAst:
    """
    Attributes:
        type_ (ConditionAstType):
        children (list[ConditionAst] | Unset):
        field (str | Unset):
        op (ConditionAstOp | Unset):
        value (Any | Unset):
    """

    type_: ConditionAstType
    children: list[ConditionAst] | Unset = UNSET
    field: str | Unset = UNSET
    op: ConditionAstOp | Unset = UNSET
    value: Any | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_.value

        children: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.children, Unset):
            children = []
            for children_item_data in self.children:
                children_item = children_item_data.to_dict()
                children.append(children_item)

        field = self.field

        op: str | Unset = UNSET
        if not isinstance(self.op, Unset):
            op = self.op.value

        value = self.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "type": type_,
            }
        )
        if children is not UNSET:
            field_dict["children"] = children
        if field is not UNSET:
            field_dict["field"] = field
        if op is not UNSET:
            field_dict["op"] = op
        if value is not UNSET:
            field_dict["value"] = value

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = ConditionAstType(d.pop("type"))

        _children = d.pop("children", UNSET)
        children: list[ConditionAst] | Unset = UNSET
        if _children is not UNSET:
            children = []
            for children_item_data in _children:
                children_item = ConditionAst.from_dict(children_item_data)

                children.append(children_item)

        field = d.pop("field", UNSET)

        _op = d.pop("op", UNSET)
        op: ConditionAstOp | Unset
        if isinstance(_op, Unset):
            op = UNSET
        else:
            op = ConditionAstOp(_op)

        value = d.pop("value", UNSET)

        condition_ast = cls(
            type_=type_,
            children=children,
            field=field,
            op=op,
            value=value,
        )

        return condition_ast
