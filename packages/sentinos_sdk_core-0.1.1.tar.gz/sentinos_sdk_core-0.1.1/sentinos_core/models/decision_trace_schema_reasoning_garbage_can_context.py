from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="DecisionTraceSchemaReasoningGarbageCanContext")


@_attrs_define
class DecisionTraceSchemaReasoningGarbageCanContext:
    """
    Attributes:
        problems_present (list[str] | Unset):
        solutions_available (list[str] | Unset):
        participants (list[str] | Unset):
        choice_opportunity (str | Unset):
    """

    problems_present: list[str] | Unset = UNSET
    solutions_available: list[str] | Unset = UNSET
    participants: list[str] | Unset = UNSET
    choice_opportunity: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        problems_present: list[str] | Unset = UNSET
        if not isinstance(self.problems_present, Unset):
            problems_present = self.problems_present

        solutions_available: list[str] | Unset = UNSET
        if not isinstance(self.solutions_available, Unset):
            solutions_available = self.solutions_available

        participants: list[str] | Unset = UNSET
        if not isinstance(self.participants, Unset):
            participants = self.participants

        choice_opportunity = self.choice_opportunity

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if problems_present is not UNSET:
            field_dict["problems_present"] = problems_present
        if solutions_available is not UNSET:
            field_dict["solutions_available"] = solutions_available
        if participants is not UNSET:
            field_dict["participants"] = participants
        if choice_opportunity is not UNSET:
            field_dict["choice_opportunity"] = choice_opportunity

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        problems_present = cast(list[str], d.pop("problems_present", UNSET))

        solutions_available = cast(list[str], d.pop("solutions_available", UNSET))

        participants = cast(list[str], d.pop("participants", UNSET))

        choice_opportunity = d.pop("choice_opportunity", UNSET)

        decision_trace_schema_reasoning_garbage_can_context = cls(
            problems_present=problems_present,
            solutions_available=solutions_available,
            participants=participants,
            choice_opportunity=choice_opportunity,
        )

        return decision_trace_schema_reasoning_garbage_can_context
