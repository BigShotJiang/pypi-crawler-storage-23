from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="A2AHandoffLineageEntry")


@_attrs_define
class A2AHandoffLineageEntry:
    """
    Attributes:
        handoff_id (str):
        sender_agent (str):
        receiver_agent (str):
        decision (str):
        issued_at (datetime.datetime):
        receipt_id (str):
        receipt_signature (str):
        tenant_id (str | Unset):
        session_id (str | Unset):
        classification (str | Unset):
        reason (str | Unset):
        policy_keys (list[str] | Unset):
    """

    handoff_id: str
    sender_agent: str
    receiver_agent: str
    decision: str
    issued_at: datetime.datetime
    receipt_id: str
    receipt_signature: str
    tenant_id: str | Unset = UNSET
    session_id: str | Unset = UNSET
    classification: str | Unset = UNSET
    reason: str | Unset = UNSET
    policy_keys: list[str] | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        handoff_id = self.handoff_id

        sender_agent = self.sender_agent

        receiver_agent = self.receiver_agent

        decision = self.decision

        issued_at = self.issued_at.isoformat()

        receipt_id = self.receipt_id

        receipt_signature = self.receipt_signature

        tenant_id = self.tenant_id

        session_id = self.session_id

        classification = self.classification

        reason = self.reason

        policy_keys: list[str] | Unset = UNSET
        if not isinstance(self.policy_keys, Unset):
            policy_keys = self.policy_keys

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "handoff_id": handoff_id,
                "sender_agent": sender_agent,
                "receiver_agent": receiver_agent,
                "decision": decision,
                "issued_at": issued_at,
                "receipt_id": receipt_id,
                "receipt_signature": receipt_signature,
            }
        )
        if tenant_id is not UNSET:
            field_dict["tenant_id"] = tenant_id
        if session_id is not UNSET:
            field_dict["session_id"] = session_id
        if classification is not UNSET:
            field_dict["classification"] = classification
        if reason is not UNSET:
            field_dict["reason"] = reason
        if policy_keys is not UNSET:
            field_dict["policy_keys"] = policy_keys

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        handoff_id = d.pop("handoff_id")

        sender_agent = d.pop("sender_agent")

        receiver_agent = d.pop("receiver_agent")

        decision = d.pop("decision")

        issued_at = isoparse(d.pop("issued_at"))

        receipt_id = d.pop("receipt_id")

        receipt_signature = d.pop("receipt_signature")

        tenant_id = d.pop("tenant_id", UNSET)

        session_id = d.pop("session_id", UNSET)

        classification = d.pop("classification", UNSET)

        reason = d.pop("reason", UNSET)

        policy_keys = cast(list[str], d.pop("policy_keys", UNSET))

        a2a_handoff_lineage_entry = cls(
            handoff_id=handoff_id,
            sender_agent=sender_agent,
            receiver_agent=receiver_agent,
            decision=decision,
            issued_at=issued_at,
            receipt_id=receipt_id,
            receipt_signature=receipt_signature,
            tenant_id=tenant_id,
            session_id=session_id,
            classification=classification,
            reason=reason,
            policy_keys=policy_keys,
        )

        return a2a_handoff_lineage_entry
