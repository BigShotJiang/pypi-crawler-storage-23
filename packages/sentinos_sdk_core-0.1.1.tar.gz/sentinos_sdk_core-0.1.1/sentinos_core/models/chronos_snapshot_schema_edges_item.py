from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chronos_snapshot_schema_edges_item_provenance import ChronosSnapshotSchemaEdgesItemProvenance


T = TypeVar("T", bound="ChronosSnapshotSchemaEdgesItem")


@_attrs_define
class ChronosSnapshotSchemaEdgesItem:
    """
    Attributes:
        edge_id (str | Unset):
        from_node (str | Unset):
        to_node (str | Unset):
        type_ (str | Unset):
        confidence (float | Unset):
        provenance (ChronosSnapshotSchemaEdgesItemProvenance | Unset):
    """

    edge_id: str | Unset = UNSET
    from_node: str | Unset = UNSET
    to_node: str | Unset = UNSET
    type_: str | Unset = UNSET
    confidence: float | Unset = UNSET
    provenance: ChronosSnapshotSchemaEdgesItemProvenance | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        edge_id = self.edge_id

        from_node = self.from_node

        to_node = self.to_node

        type_ = self.type_

        confidence = self.confidence

        provenance: dict[str, Any] | Unset = UNSET
        if not isinstance(self.provenance, Unset):
            provenance = self.provenance.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if edge_id is not UNSET:
            field_dict["edge_id"] = edge_id
        if from_node is not UNSET:
            field_dict["from_node"] = from_node
        if to_node is not UNSET:
            field_dict["to_node"] = to_node
        if type_ is not UNSET:
            field_dict["type"] = type_
        if confidence is not UNSET:
            field_dict["confidence"] = confidence
        if provenance is not UNSET:
            field_dict["provenance"] = provenance

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chronos_snapshot_schema_edges_item_provenance import ChronosSnapshotSchemaEdgesItemProvenance

        d = dict(src_dict)
        edge_id = d.pop("edge_id", UNSET)

        from_node = d.pop("from_node", UNSET)

        to_node = d.pop("to_node", UNSET)

        type_ = d.pop("type", UNSET)

        confidence = d.pop("confidence", UNSET)

        _provenance = d.pop("provenance", UNSET)
        provenance: ChronosSnapshotSchemaEdgesItemProvenance | Unset
        if isinstance(_provenance, Unset):
            provenance = UNSET
        else:
            provenance = ChronosSnapshotSchemaEdgesItemProvenance.from_dict(_provenance)

        chronos_snapshot_schema_edges_item = cls(
            edge_id=edge_id,
            from_node=from_node,
            to_node=to_node,
            type_=type_,
            confidence=confidence,
            provenance=provenance,
        )

        chronos_snapshot_schema_edges_item.additional_properties = d
        return chronos_snapshot_schema_edges_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
