from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.autonomy_risk_budget import AutonomyRiskBudget
    from ..models.autonomy_session_create_request_metadata import AutonomySessionCreateRequestMetadata


T = TypeVar("T", bound="AutonomySessionCreateRequest")


@_attrs_define
class AutonomySessionCreateRequest:
    """
    Attributes:
        agent_id (str):
        tenant_id (str | Unset):
        session_id (str | Unset):
        risk_budget_snapshot (AutonomyRiskBudget | Unset):
        metadata (AutonomySessionCreateRequestMetadata | Unset):
    """

    agent_id: str
    tenant_id: str | Unset = UNSET
    session_id: str | Unset = UNSET
    risk_budget_snapshot: AutonomyRiskBudget | Unset = UNSET
    metadata: AutonomySessionCreateRequestMetadata | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        agent_id = self.agent_id

        tenant_id = self.tenant_id

        session_id = self.session_id

        risk_budget_snapshot: dict[str, Any] | Unset = UNSET
        if not isinstance(self.risk_budget_snapshot, Unset):
            risk_budget_snapshot = self.risk_budget_snapshot.to_dict()

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "agent_id": agent_id,
            }
        )
        if tenant_id is not UNSET:
            field_dict["tenant_id"] = tenant_id
        if session_id is not UNSET:
            field_dict["session_id"] = session_id
        if risk_budget_snapshot is not UNSET:
            field_dict["risk_budget_snapshot"] = risk_budget_snapshot
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.autonomy_risk_budget import AutonomyRiskBudget
        from ..models.autonomy_session_create_request_metadata import AutonomySessionCreateRequestMetadata

        d = dict(src_dict)
        agent_id = d.pop("agent_id")

        tenant_id = d.pop("tenant_id", UNSET)

        session_id = d.pop("session_id", UNSET)

        _risk_budget_snapshot = d.pop("risk_budget_snapshot", UNSET)
        risk_budget_snapshot: AutonomyRiskBudget | Unset
        if isinstance(_risk_budget_snapshot, Unset):
            risk_budget_snapshot = UNSET
        else:
            risk_budget_snapshot = AutonomyRiskBudget.from_dict(_risk_budget_snapshot)

        _metadata = d.pop("metadata", UNSET)
        metadata: AutonomySessionCreateRequestMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = AutonomySessionCreateRequestMetadata.from_dict(_metadata)

        autonomy_session_create_request = cls(
            agent_id=agent_id,
            tenant_id=tenant_id,
            session_id=session_id,
            risk_budget_snapshot=risk_budget_snapshot,
            metadata=metadata,
        )

        return autonomy_session_create_request
