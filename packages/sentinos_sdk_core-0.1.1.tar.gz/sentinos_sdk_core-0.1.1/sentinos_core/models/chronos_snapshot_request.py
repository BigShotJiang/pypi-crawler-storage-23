from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chronos_snapshot_request_trace_filter import ChronosSnapshotRequestTraceFilter


T = TypeVar("T", bound="ChronosSnapshotRequest")


@_attrs_define
class ChronosSnapshotRequest:
    """
    Attributes:
        tenant_id (str):
        anchors (list[str]):
        depth (int | Unset):
        valid_time (datetime.datetime | Unset):
        include_decision_traces (bool | Unset):
        trace_filter (ChronosSnapshotRequestTraceFilter | Unset):
    """

    tenant_id: str
    anchors: list[str]
    depth: int | Unset = UNSET
    valid_time: datetime.datetime | Unset = UNSET
    include_decision_traces: bool | Unset = UNSET
    trace_filter: ChronosSnapshotRequestTraceFilter | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        anchors = self.anchors

        depth = self.depth

        valid_time: str | Unset = UNSET
        if not isinstance(self.valid_time, Unset):
            valid_time = self.valid_time.isoformat()

        include_decision_traces = self.include_decision_traces

        trace_filter: dict[str, Any] | Unset = UNSET
        if not isinstance(self.trace_filter, Unset):
            trace_filter = self.trace_filter.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "anchors": anchors,
            }
        )
        if depth is not UNSET:
            field_dict["depth"] = depth
        if valid_time is not UNSET:
            field_dict["valid_time"] = valid_time
        if include_decision_traces is not UNSET:
            field_dict["include_decision_traces"] = include_decision_traces
        if trace_filter is not UNSET:
            field_dict["trace_filter"] = trace_filter

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chronos_snapshot_request_trace_filter import ChronosSnapshotRequestTraceFilter

        d = dict(src_dict)
        tenant_id = d.pop("tenant_id")

        anchors = cast(list[str], d.pop("anchors"))

        depth = d.pop("depth", UNSET)

        _valid_time = d.pop("valid_time", UNSET)
        valid_time: datetime.datetime | Unset
        if isinstance(_valid_time, Unset):
            valid_time = UNSET
        else:
            valid_time = isoparse(_valid_time)

        include_decision_traces = d.pop("include_decision_traces", UNSET)

        _trace_filter = d.pop("trace_filter", UNSET)
        trace_filter: ChronosSnapshotRequestTraceFilter | Unset
        if isinstance(_trace_filter, Unset):
            trace_filter = UNSET
        else:
            trace_filter = ChronosSnapshotRequestTraceFilter.from_dict(_trace_filter)

        chronos_snapshot_request = cls(
            tenant_id=tenant_id,
            anchors=anchors,
            depth=depth,
            valid_time=valid_time,
            include_decision_traces=include_decision_traces,
            trace_filter=trace_filter,
        )

        return chronos_snapshot_request
