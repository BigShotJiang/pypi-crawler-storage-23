from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

T = TypeVar("T", bound="ChronosConnectorIngestResponse")


@_attrs_define
class ChronosConnectorIngestResponse:
    """
    Attributes:
        ok (bool):
        tenant_id (str):
        source_id (str):
        event_id (str):
        event_node (str):
        ts (datetime.datetime):
    """

    ok: bool
    tenant_id: str
    source_id: str
    event_id: str
    event_node: str
    ts: datetime.datetime

    def to_dict(self) -> dict[str, Any]:
        ok = self.ok

        tenant_id = self.tenant_id

        source_id = self.source_id

        event_id = self.event_id

        event_node = self.event_node

        ts = self.ts.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "ok": ok,
                "tenant_id": tenant_id,
                "source_id": source_id,
                "event_id": event_id,
                "event_node": event_node,
                "ts": ts,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ok = d.pop("ok")

        tenant_id = d.pop("tenant_id")

        source_id = d.pop("source_id")

        event_id = d.pop("event_id")

        event_node = d.pop("event_node")

        ts = isoparse(d.pop("ts"))

        chronos_connector_ingest_response = cls(
            ok=ok,
            tenant_id=tenant_id,
            source_id=source_id,
            event_id=event_id,
            event_node=event_node,
            ts=ts,
        )

        return chronos_connector_ingest_response
