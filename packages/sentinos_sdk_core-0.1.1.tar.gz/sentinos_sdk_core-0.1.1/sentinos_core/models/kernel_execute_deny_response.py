from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..models.decision import Decision
from ..types import UNSET, Unset

T = TypeVar("T", bound="KernelExecuteDenyResponse")


@_attrs_define
class KernelExecuteDenyResponse:
    """
    Attributes:
        trace_id (UUID):
        decision (Decision):
        message (str | Unset):
        next_action (str | Unset):
        reason_code (str | Unset):
    """

    trace_id: UUID
    decision: Decision
    message: str | Unset = UNSET
    next_action: str | Unset = UNSET
    reason_code: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        trace_id = str(self.trace_id)

        decision = self.decision.value

        message = self.message

        next_action = self.next_action

        reason_code = self.reason_code

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "trace_id": trace_id,
                "decision": decision,
            }
        )
        if message is not UNSET:
            field_dict["message"] = message
        if next_action is not UNSET:
            field_dict["next_action"] = next_action
        if reason_code is not UNSET:
            field_dict["reason_code"] = reason_code

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        trace_id = UUID(d.pop("trace_id"))

        decision = Decision(d.pop("decision"))

        message = d.pop("message", UNSET)

        next_action = d.pop("next_action", UNSET)

        reason_code = d.pop("reason_code", UNSET)

        kernel_execute_deny_response = cls(
            trace_id=trace_id,
            decision=decision,
            message=message,
            next_action=next_action,
            reason_code=reason_code,
        )

        return kernel_execute_deny_response
