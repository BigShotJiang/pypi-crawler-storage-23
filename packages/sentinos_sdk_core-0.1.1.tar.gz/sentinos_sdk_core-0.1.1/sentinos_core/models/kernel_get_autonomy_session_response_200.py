from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.autonomy_session import AutonomySession


T = TypeVar("T", bound="KernelGetAutonomySessionResponse200")


@_attrs_define
class KernelGetAutonomySessionResponse200:
    """
    Attributes:
        session (AutonomySession):
    """

    session: AutonomySession

    def to_dict(self) -> dict[str, Any]:
        session = self.session.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "session": session,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.autonomy_session import AutonomySession

        d = dict(src_dict)
        session = AutonomySession.from_dict(d.pop("session"))

        kernel_get_autonomy_session_response_200 = cls(
            session=session,
        )

        return kernel_get_autonomy_session_response_200
