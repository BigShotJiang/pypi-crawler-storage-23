from enum import Enum


class AlertStatus(str, Enum):
    ACKNOWLEDGED = "ACKNOWLEDGED"
    ESCALATED = "ESCALATED"
    FIRING = "FIRING"
    RESOLVED = "RESOLVED"
    SUPPRESSED = "SUPPRESSED"

    def __str__(self) -> str:
        return str(self.value)
