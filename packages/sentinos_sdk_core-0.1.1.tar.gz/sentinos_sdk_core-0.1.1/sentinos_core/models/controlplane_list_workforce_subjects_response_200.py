from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.workforce_subject import WorkforceSubject


T = TypeVar("T", bound="ControlplaneListWorkforceSubjectsResponse200")


@_attrs_define
class ControlplaneListWorkforceSubjectsResponse200:
    """
    Attributes:
        subjects (list[WorkforceSubject]):
    """

    subjects: list[WorkforceSubject]

    def to_dict(self) -> dict[str, Any]:
        subjects = []
        for subjects_item_data in self.subjects:
            subjects_item = subjects_item_data.to_dict()
            subjects.append(subjects_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "subjects": subjects,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.workforce_subject import WorkforceSubject

        d = dict(src_dict)
        subjects = []
        _subjects = d.pop("subjects")
        for subjects_item_data in _subjects:
            subjects_item = WorkforceSubject.from_dict(subjects_item_data)

            subjects.append(subjects_item)

        controlplane_list_workforce_subjects_response_200 = cls(
            subjects=subjects,
        )

        return controlplane_list_workforce_subjects_response_200
