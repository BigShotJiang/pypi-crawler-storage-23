from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.compliance_control_result_status import ComplianceControlResultStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.compliance_control_evidence_item import ComplianceControlEvidenceItem


T = TypeVar("T", bound="ComplianceControlResult")


@_attrs_define
class ComplianceControlResult:
    """
    Attributes:
        framework (str | Unset):
        control_id (str | Unset):
        title (str | Unset):
        status (ComplianceControlResultStatus | Unset):
        rationale (str | Unset):
        evidence (list[ComplianceControlEvidenceItem] | Unset):
    """

    framework: str | Unset = UNSET
    control_id: str | Unset = UNSET
    title: str | Unset = UNSET
    status: ComplianceControlResultStatus | Unset = UNSET
    rationale: str | Unset = UNSET
    evidence: list[ComplianceControlEvidenceItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        framework = self.framework

        control_id = self.control_id

        title = self.title

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        rationale = self.rationale

        evidence: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.evidence, Unset):
            evidence = []
            for evidence_item_data in self.evidence:
                evidence_item = evidence_item_data.to_dict()
                evidence.append(evidence_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if framework is not UNSET:
            field_dict["framework"] = framework
        if control_id is not UNSET:
            field_dict["control_id"] = control_id
        if title is not UNSET:
            field_dict["title"] = title
        if status is not UNSET:
            field_dict["status"] = status
        if rationale is not UNSET:
            field_dict["rationale"] = rationale
        if evidence is not UNSET:
            field_dict["evidence"] = evidence

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.compliance_control_evidence_item import ComplianceControlEvidenceItem

        d = dict(src_dict)
        framework = d.pop("framework", UNSET)

        control_id = d.pop("control_id", UNSET)

        title = d.pop("title", UNSET)

        _status = d.pop("status", UNSET)
        status: ComplianceControlResultStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = ComplianceControlResultStatus(_status)

        rationale = d.pop("rationale", UNSET)

        _evidence = d.pop("evidence", UNSET)
        evidence: list[ComplianceControlEvidenceItem] | Unset = UNSET
        if _evidence is not UNSET:
            evidence = []
            for evidence_item_data in _evidence:
                evidence_item = ComplianceControlEvidenceItem.from_dict(evidence_item_data)

                evidence.append(evidence_item)

        compliance_control_result = cls(
            framework=framework,
            control_id=control_id,
            title=title,
            status=status,
            rationale=rationale,
            evidence=evidence,
        )

        compliance_control_result.additional_properties = d
        return compliance_control_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
