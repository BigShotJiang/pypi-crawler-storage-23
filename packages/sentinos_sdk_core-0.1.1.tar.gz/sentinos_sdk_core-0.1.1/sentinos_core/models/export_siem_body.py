from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.export_siem_body_format import ExportSIEMBodyFormat
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.export_siem_body_destination import ExportSIEMBodyDestination


T = TypeVar("T", bound="ExportSIEMBody")


@_attrs_define
class ExportSIEMBody:
    """
    Attributes:
        format_ (ExportSIEMBodyFormat | Unset):
        from_ (datetime.datetime | Unset):
        to (datetime.datetime | Unset):
        limit (int | Unset):
        destination (ExportSIEMBodyDestination | Unset):
    """

    format_: ExportSIEMBodyFormat | Unset = UNSET
    from_: datetime.datetime | Unset = UNSET
    to: datetime.datetime | Unset = UNSET
    limit: int | Unset = UNSET
    destination: ExportSIEMBodyDestination | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        format_: str | Unset = UNSET
        if not isinstance(self.format_, Unset):
            format_ = self.format_.value

        from_: str | Unset = UNSET
        if not isinstance(self.from_, Unset):
            from_ = self.from_.isoformat()

        to: str | Unset = UNSET
        if not isinstance(self.to, Unset):
            to = self.to.isoformat()

        limit = self.limit

        destination: dict[str, Any] | Unset = UNSET
        if not isinstance(self.destination, Unset):
            destination = self.destination.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if format_ is not UNSET:
            field_dict["format"] = format_
        if from_ is not UNSET:
            field_dict["from"] = from_
        if to is not UNSET:
            field_dict["to"] = to
        if limit is not UNSET:
            field_dict["limit"] = limit
        if destination is not UNSET:
            field_dict["destination"] = destination

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.export_siem_body_destination import ExportSIEMBodyDestination

        d = dict(src_dict)
        _format_ = d.pop("format", UNSET)
        format_: ExportSIEMBodyFormat | Unset
        if isinstance(_format_, Unset):
            format_ = UNSET
        else:
            format_ = ExportSIEMBodyFormat(_format_)

        _from_ = d.pop("from", UNSET)
        from_: datetime.datetime | Unset
        if isinstance(_from_, Unset):
            from_ = UNSET
        else:
            from_ = isoparse(_from_)

        _to = d.pop("to", UNSET)
        to: datetime.datetime | Unset
        if isinstance(_to, Unset):
            to = UNSET
        else:
            to = isoparse(_to)

        limit = d.pop("limit", UNSET)

        _destination = d.pop("destination", UNSET)
        destination: ExportSIEMBodyDestination | Unset
        if isinstance(_destination, Unset):
            destination = UNSET
        else:
            destination = ExportSIEMBodyDestination.from_dict(_destination)

        export_siem_body = cls(
            format_=format_,
            from_=from_,
            to=to,
            limit=limit,
            destination=destination,
        )

        export_siem_body.additional_properties = d
        return export_siem_body

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
