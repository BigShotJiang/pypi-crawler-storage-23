from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

T = TypeVar("T", bound="ControlplaneCreateScimTokenBody")


@_attrs_define
class ControlplaneCreateScimTokenBody:
    """
    Attributes:
        service_account_id (UUID):
    """

    service_account_id: UUID

    def to_dict(self) -> dict[str, Any]:
        service_account_id = str(self.service_account_id)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "service_account_id": service_account_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        service_account_id = UUID(d.pop("service_account_id"))

        controlplane_create_scim_token_body = cls(
            service_account_id=service_account_id,
        )

        return controlplane_create_scim_token_body
