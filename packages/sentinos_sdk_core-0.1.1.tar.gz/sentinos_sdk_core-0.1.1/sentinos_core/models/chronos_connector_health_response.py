from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

if TYPE_CHECKING:
    from ..models.chronos_connector_health_response_sources_item import ChronosConnectorHealthResponseSourcesItem
    from ..models.chronos_connector_health_response_summary import ChronosConnectorHealthResponseSummary


T = TypeVar("T", bound="ChronosConnectorHealthResponse")


@_attrs_define
class ChronosConnectorHealthResponse:
    """
    Attributes:
        ok (bool):
        tenant_id (str):
        summary (ChronosConnectorHealthResponseSummary):
        sources (list[ChronosConnectorHealthResponseSourcesItem]):
        ts (datetime.datetime):
    """

    ok: bool
    tenant_id: str
    summary: ChronosConnectorHealthResponseSummary
    sources: list[ChronosConnectorHealthResponseSourcesItem]
    ts: datetime.datetime

    def to_dict(self) -> dict[str, Any]:
        ok = self.ok

        tenant_id = self.tenant_id

        summary = self.summary.to_dict()

        sources = []
        for sources_item_data in self.sources:
            sources_item = sources_item_data.to_dict()
            sources.append(sources_item)

        ts = self.ts.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "ok": ok,
                "tenant_id": tenant_id,
                "summary": summary,
                "sources": sources,
                "ts": ts,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chronos_connector_health_response_sources_item import ChronosConnectorHealthResponseSourcesItem
        from ..models.chronos_connector_health_response_summary import ChronosConnectorHealthResponseSummary

        d = dict(src_dict)
        ok = d.pop("ok")

        tenant_id = d.pop("tenant_id")

        summary = ChronosConnectorHealthResponseSummary.from_dict(d.pop("summary"))

        sources = []
        _sources = d.pop("sources")
        for sources_item_data in _sources:
            sources_item = ChronosConnectorHealthResponseSourcesItem.from_dict(sources_item_data)

            sources.append(sources_item)

        ts = isoparse(d.pop("ts"))

        chronos_connector_health_response = cls(
            ok=ok,
            tenant_id=tenant_id,
            summary=summary,
            sources=sources,
            ts=ts,
        )

        return chronos_connector_health_response
