from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.incident_severity import IncidentSeverity
from ..models.incident_source import IncidentSource
from ..models.incident_status import IncidentStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.incident_metadata import IncidentMetadata


T = TypeVar("T", bound="Incident")


@_attrs_define
class Incident:
    """
    Attributes:
        title (str):
        incident_id (UUID | Unset):
        tenant_id (str | Unset):
        description (str | Unset):
        severity (IncidentSeverity | Unset):
        status (IncidentStatus | Unset):
        source (IncidentSource | Unset):
        correlation_key (str | Unset):
        started_at (datetime.datetime | Unset):
        detected_at (datetime.datetime | Unset):
        acknowledged_at (datetime.datetime | Unset):
        resolved_at (datetime.datetime | Unset):
        mttd_seconds (int | Unset):
        mttr_seconds (int | Unset):
        created_by (str | Unset):
        updated_by (str | Unset):
        tags (list[str] | Unset):
        metadata (IncidentMetadata | Unset):
        created_at (datetime.datetime | Unset):
        updated_at (datetime.datetime | Unset):
    """

    title: str
    incident_id: UUID | Unset = UNSET
    tenant_id: str | Unset = UNSET
    description: str | Unset = UNSET
    severity: IncidentSeverity | Unset = UNSET
    status: IncidentStatus | Unset = UNSET
    source: IncidentSource | Unset = UNSET
    correlation_key: str | Unset = UNSET
    started_at: datetime.datetime | Unset = UNSET
    detected_at: datetime.datetime | Unset = UNSET
    acknowledged_at: datetime.datetime | Unset = UNSET
    resolved_at: datetime.datetime | Unset = UNSET
    mttd_seconds: int | Unset = UNSET
    mttr_seconds: int | Unset = UNSET
    created_by: str | Unset = UNSET
    updated_by: str | Unset = UNSET
    tags: list[str] | Unset = UNSET
    metadata: IncidentMetadata | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    updated_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        title = self.title

        incident_id: str | Unset = UNSET
        if not isinstance(self.incident_id, Unset):
            incident_id = str(self.incident_id)

        tenant_id = self.tenant_id

        description = self.description

        severity: str | Unset = UNSET
        if not isinstance(self.severity, Unset):
            severity = self.severity.value

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value

        source: str | Unset = UNSET
        if not isinstance(self.source, Unset):
            source = self.source.value

        correlation_key = self.correlation_key

        started_at: str | Unset = UNSET
        if not isinstance(self.started_at, Unset):
            started_at = self.started_at.isoformat()

        detected_at: str | Unset = UNSET
        if not isinstance(self.detected_at, Unset):
            detected_at = self.detected_at.isoformat()

        acknowledged_at: str | Unset = UNSET
        if not isinstance(self.acknowledged_at, Unset):
            acknowledged_at = self.acknowledged_at.isoformat()

        resolved_at: str | Unset = UNSET
        if not isinstance(self.resolved_at, Unset):
            resolved_at = self.resolved_at.isoformat()

        mttd_seconds = self.mttd_seconds

        mttr_seconds = self.mttr_seconds

        created_by = self.created_by

        updated_by = self.updated_by

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "title": title,
            }
        )
        if incident_id is not UNSET:
            field_dict["incident_id"] = incident_id
        if tenant_id is not UNSET:
            field_dict["tenant_id"] = tenant_id
        if description is not UNSET:
            field_dict["description"] = description
        if severity is not UNSET:
            field_dict["severity"] = severity
        if status is not UNSET:
            field_dict["status"] = status
        if source is not UNSET:
            field_dict["source"] = source
        if correlation_key is not UNSET:
            field_dict["correlation_key"] = correlation_key
        if started_at is not UNSET:
            field_dict["started_at"] = started_at
        if detected_at is not UNSET:
            field_dict["detected_at"] = detected_at
        if acknowledged_at is not UNSET:
            field_dict["acknowledged_at"] = acknowledged_at
        if resolved_at is not UNSET:
            field_dict["resolved_at"] = resolved_at
        if mttd_seconds is not UNSET:
            field_dict["mttd_seconds"] = mttd_seconds
        if mttr_seconds is not UNSET:
            field_dict["mttr_seconds"] = mttr_seconds
        if created_by is not UNSET:
            field_dict["created_by"] = created_by
        if updated_by is not UNSET:
            field_dict["updated_by"] = updated_by
        if tags is not UNSET:
            field_dict["tags"] = tags
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.incident_metadata import IncidentMetadata

        d = dict(src_dict)
        title = d.pop("title")

        _incident_id = d.pop("incident_id", UNSET)
        incident_id: UUID | Unset
        if isinstance(_incident_id, Unset):
            incident_id = UNSET
        else:
            incident_id = UUID(_incident_id)

        tenant_id = d.pop("tenant_id", UNSET)

        description = d.pop("description", UNSET)

        _severity = d.pop("severity", UNSET)
        severity: IncidentSeverity | Unset
        if isinstance(_severity, Unset):
            severity = UNSET
        else:
            severity = IncidentSeverity(_severity)

        _status = d.pop("status", UNSET)
        status: IncidentStatus | Unset
        if isinstance(_status, Unset):
            status = UNSET
        else:
            status = IncidentStatus(_status)

        _source = d.pop("source", UNSET)
        source: IncidentSource | Unset
        if isinstance(_source, Unset):
            source = UNSET
        else:
            source = IncidentSource(_source)

        correlation_key = d.pop("correlation_key", UNSET)

        _started_at = d.pop("started_at", UNSET)
        started_at: datetime.datetime | Unset
        if isinstance(_started_at, Unset):
            started_at = UNSET
        else:
            started_at = isoparse(_started_at)

        _detected_at = d.pop("detected_at", UNSET)
        detected_at: datetime.datetime | Unset
        if isinstance(_detected_at, Unset):
            detected_at = UNSET
        else:
            detected_at = isoparse(_detected_at)

        _acknowledged_at = d.pop("acknowledged_at", UNSET)
        acknowledged_at: datetime.datetime | Unset
        if isinstance(_acknowledged_at, Unset):
            acknowledged_at = UNSET
        else:
            acknowledged_at = isoparse(_acknowledged_at)

        _resolved_at = d.pop("resolved_at", UNSET)
        resolved_at: datetime.datetime | Unset
        if isinstance(_resolved_at, Unset):
            resolved_at = UNSET
        else:
            resolved_at = isoparse(_resolved_at)

        mttd_seconds = d.pop("mttd_seconds", UNSET)

        mttr_seconds = d.pop("mttr_seconds", UNSET)

        created_by = d.pop("created_by", UNSET)

        updated_by = d.pop("updated_by", UNSET)

        tags = cast(list[str], d.pop("tags", UNSET))

        _metadata = d.pop("metadata", UNSET)
        metadata: IncidentMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = IncidentMetadata.from_dict(_metadata)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        _updated_at = d.pop("updated_at", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        incident = cls(
            title=title,
            incident_id=incident_id,
            tenant_id=tenant_id,
            description=description,
            severity=severity,
            status=status,
            source=source,
            correlation_key=correlation_key,
            started_at=started_at,
            detected_at=detected_at,
            acknowledged_at=acknowledged_at,
            resolved_at=resolved_at,
            mttd_seconds=mttd_seconds,
            mttr_seconds=mttr_seconds,
            created_by=created_by,
            updated_by=updated_by,
            tags=tags,
            metadata=metadata,
            created_at=created_at,
            updated_at=updated_at,
        )

        incident.additional_properties = d
        return incident

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
