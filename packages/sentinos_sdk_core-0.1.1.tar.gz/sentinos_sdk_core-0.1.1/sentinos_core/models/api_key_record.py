from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ApiKeyRecord")


@_attrs_define
class ApiKeyRecord:
    """
    Attributes:
        key_id (UUID):
        tenant_id (str):
        name (str):
        key_prefix (str):
        scopes (list[str]):
        created_at (datetime.datetime):
        expires_at (datetime.datetime | Unset):
        revoked_at (datetime.datetime | Unset):
    """

    key_id: UUID
    tenant_id: str
    name: str
    key_prefix: str
    scopes: list[str]
    created_at: datetime.datetime
    expires_at: datetime.datetime | Unset = UNSET
    revoked_at: datetime.datetime | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        key_id = str(self.key_id)

        tenant_id = self.tenant_id

        name = self.name

        key_prefix = self.key_prefix

        scopes = self.scopes

        created_at = self.created_at.isoformat()

        expires_at: str | Unset = UNSET
        if not isinstance(self.expires_at, Unset):
            expires_at = self.expires_at.isoformat()

        revoked_at: str | Unset = UNSET
        if not isinstance(self.revoked_at, Unset):
            revoked_at = self.revoked_at.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "key_id": key_id,
                "tenant_id": tenant_id,
                "name": name,
                "key_prefix": key_prefix,
                "scopes": scopes,
                "created_at": created_at,
            }
        )
        if expires_at is not UNSET:
            field_dict["expires_at"] = expires_at
        if revoked_at is not UNSET:
            field_dict["revoked_at"] = revoked_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        key_id = UUID(d.pop("key_id"))

        tenant_id = d.pop("tenant_id")

        name = d.pop("name")

        key_prefix = d.pop("key_prefix")

        scopes = cast(list[str], d.pop("scopes"))

        created_at = isoparse(d.pop("created_at"))

        _expires_at = d.pop("expires_at", UNSET)
        expires_at: datetime.datetime | Unset
        if isinstance(_expires_at, Unset):
            expires_at = UNSET
        else:
            expires_at = isoparse(_expires_at)

        _revoked_at = d.pop("revoked_at", UNSET)
        revoked_at: datetime.datetime | Unset
        if isinstance(_revoked_at, Unset):
            revoked_at = UNSET
        else:
            revoked_at = isoparse(_revoked_at)

        api_key_record = cls(
            key_id=key_id,
            tenant_id=tenant_id,
            name=name,
            key_prefix=key_prefix,
            scopes=scopes,
            created_at=created_at,
            expires_at=expires_at,
            revoked_at=revoked_at,
        )

        return api_key_record
