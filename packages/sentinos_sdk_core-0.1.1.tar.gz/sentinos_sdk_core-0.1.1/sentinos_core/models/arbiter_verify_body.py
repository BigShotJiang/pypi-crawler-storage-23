from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.policy_dsl_schema import PolicyDslSchema
    from ..models.testcase_suite import TestcaseSuite


T = TypeVar("T", bound="ArbiterVerifyBody")


@_attrs_define
class ArbiterVerifyBody:
    """
    Attributes:
        policy_dsl (PolicyDslSchema):
        candidate_rego (str):
        testcases (TestcaseSuite):
        policy_id (str | Unset):
        version (str | Unset):
    """

    policy_dsl: PolicyDslSchema
    candidate_rego: str
    testcases: TestcaseSuite
    policy_id: str | Unset = UNSET
    version: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        policy_dsl = self.policy_dsl.to_dict()

        candidate_rego = self.candidate_rego

        testcases = self.testcases.to_dict()

        policy_id = self.policy_id

        version = self.version

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "policy_dsl": policy_dsl,
                "candidate_rego": candidate_rego,
                "testcases": testcases,
            }
        )
        if policy_id is not UNSET:
            field_dict["policy_id"] = policy_id
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.policy_dsl_schema import PolicyDslSchema
        from ..models.testcase_suite import TestcaseSuite

        d = dict(src_dict)
        policy_dsl = PolicyDslSchema.from_dict(d.pop("policy_dsl"))

        candidate_rego = d.pop("candidate_rego")

        testcases = TestcaseSuite.from_dict(d.pop("testcases"))

        policy_id = d.pop("policy_id", UNSET)

        version = d.pop("version", UNSET)

        arbiter_verify_body = cls(
            policy_dsl=policy_dsl,
            candidate_rego=candidate_rego,
            testcases=testcases,
            policy_id=policy_id,
            version=version,
        )

        return arbiter_verify_body
