from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="DecisionTraceIntent")


@_attrs_define
class DecisionTraceIntent:
    """
    Attributes:
        type_ (str):
        tool (str):
        args (Any | Unset):
    """

    type_: str
    tool: str
    args: Any | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        tool = self.tool

        args = self.args

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "type": type_,
                "tool": tool,
            }
        )
        if args is not UNSET:
            field_dict["args"] = args

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = d.pop("type")

        tool = d.pop("tool")

        args = d.pop("args", UNSET)

        decision_trace_intent = cls(
            type_=type_,
            tool=tool,
            args=args,
        )

        return decision_trace_intent
