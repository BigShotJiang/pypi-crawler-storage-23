from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="A2AHandoffReceipt")


@_attrs_define
class A2AHandoffReceipt:
    """
    Attributes:
        receipt_id (str):
        handoff_id (str):
        sender_agent (str):
        receiver_agent (str):
        decision (str):
        issued_at (datetime.datetime):
        signature (str):
        tenant_id (str | Unset):
        session_id (str | Unset):
        classification (str | Unset):
        policy_keys (list[str] | Unset):
        reason (str | Unset):
    """

    receipt_id: str
    handoff_id: str
    sender_agent: str
    receiver_agent: str
    decision: str
    issued_at: datetime.datetime
    signature: str
    tenant_id: str | Unset = UNSET
    session_id: str | Unset = UNSET
    classification: str | Unset = UNSET
    policy_keys: list[str] | Unset = UNSET
    reason: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        receipt_id = self.receipt_id

        handoff_id = self.handoff_id

        sender_agent = self.sender_agent

        receiver_agent = self.receiver_agent

        decision = self.decision

        issued_at = self.issued_at.isoformat()

        signature = self.signature

        tenant_id = self.tenant_id

        session_id = self.session_id

        classification = self.classification

        policy_keys: list[str] | Unset = UNSET
        if not isinstance(self.policy_keys, Unset):
            policy_keys = self.policy_keys

        reason = self.reason

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "receipt_id": receipt_id,
                "handoff_id": handoff_id,
                "sender_agent": sender_agent,
                "receiver_agent": receiver_agent,
                "decision": decision,
                "issued_at": issued_at,
                "signature": signature,
            }
        )
        if tenant_id is not UNSET:
            field_dict["tenant_id"] = tenant_id
        if session_id is not UNSET:
            field_dict["session_id"] = session_id
        if classification is not UNSET:
            field_dict["classification"] = classification
        if policy_keys is not UNSET:
            field_dict["policy_keys"] = policy_keys
        if reason is not UNSET:
            field_dict["reason"] = reason

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        receipt_id = d.pop("receipt_id")

        handoff_id = d.pop("handoff_id")

        sender_agent = d.pop("sender_agent")

        receiver_agent = d.pop("receiver_agent")

        decision = d.pop("decision")

        issued_at = isoparse(d.pop("issued_at"))

        signature = d.pop("signature")

        tenant_id = d.pop("tenant_id", UNSET)

        session_id = d.pop("session_id", UNSET)

        classification = d.pop("classification", UNSET)

        policy_keys = cast(list[str], d.pop("policy_keys", UNSET))

        reason = d.pop("reason", UNSET)

        a2a_handoff_receipt = cls(
            receipt_id=receipt_id,
            handoff_id=handoff_id,
            sender_agent=sender_agent,
            receiver_agent=receiver_agent,
            decision=decision,
            issued_at=issued_at,
            signature=signature,
            tenant_id=tenant_id,
            session_id=session_id,
            classification=classification,
            policy_keys=policy_keys,
            reason=reason,
        )

        return a2a_handoff_receipt
