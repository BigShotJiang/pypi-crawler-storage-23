from enum import Enum


class ArbiterUpsertPolicyBodyStatus(str, Enum):
    DRAFT = "draft"
    PROD = "prod"
    STAGING = "staging"

    def __str__(self) -> str:
        return str(self.value)
