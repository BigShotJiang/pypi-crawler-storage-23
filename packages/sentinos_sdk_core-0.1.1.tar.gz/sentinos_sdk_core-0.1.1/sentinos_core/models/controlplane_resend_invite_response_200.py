from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.invitation import Invitation


T = TypeVar("T", bound="ControlplaneResendInviteResponse200")


@_attrs_define
class ControlplaneResendInviteResponse200:
    """
    Attributes:
        invitation (Invitation):
        invite_token (str):
    """

    invitation: Invitation
    invite_token: str

    def to_dict(self) -> dict[str, Any]:
        invitation = self.invitation.to_dict()

        invite_token = self.invite_token

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "invitation": invitation,
                "invite_token": invite_token,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.invitation import Invitation

        d = dict(src_dict)
        invitation = Invitation.from_dict(d.pop("invitation"))

        invite_token = d.pop("invite_token")

        controlplane_resend_invite_response_200 = cls(
            invitation=invitation,
            invite_token=invite_token,
        )

        return controlplane_resend_invite_response_200
