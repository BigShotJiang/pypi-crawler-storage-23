from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.service_account_record import ServiceAccountRecord


T = TypeVar("T", bound="ControlplaneListServiceAccountsResponse200")


@_attrs_define
class ControlplaneListServiceAccountsResponse200:
    """
    Attributes:
        service_accounts (list[ServiceAccountRecord]):
    """

    service_accounts: list[ServiceAccountRecord]

    def to_dict(self) -> dict[str, Any]:
        service_accounts = []
        for service_accounts_item_data in self.service_accounts:
            service_accounts_item = service_accounts_item_data.to_dict()
            service_accounts.append(service_accounts_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "service_accounts": service_accounts,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.service_account_record import ServiceAccountRecord

        d = dict(src_dict)
        service_accounts = []
        _service_accounts = d.pop("service_accounts")
        for service_accounts_item_data in _service_accounts:
            service_accounts_item = ServiceAccountRecord.from_dict(service_accounts_item_data)

            service_accounts.append(service_accounts_item)

        controlplane_list_service_accounts_response_200 = cls(
            service_accounts=service_accounts,
        )

        return controlplane_list_service_accounts_response_200
