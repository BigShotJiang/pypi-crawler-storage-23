from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define

from ..models.a2a_handoff_authorize_request_decision import A2AHandoffAuthorizeRequestDecision
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.a2a_handoff_authorize_request_metadata import A2AHandoffAuthorizeRequestMetadata


T = TypeVar("T", bound="A2AHandoffAuthorizeRequest")


@_attrs_define
class A2AHandoffAuthorizeRequest:
    """
    Attributes:
        sender_agent (str):
        receiver_agent (str):
        handoff_id (str | Unset):
        tenant_id (str | Unset):
        session_id (str | Unset):
        classification (str | Unset):
        policy_keys (list[str] | Unset):
        metadata (A2AHandoffAuthorizeRequestMetadata | Unset):
        decision (A2AHandoffAuthorizeRequestDecision | Unset):
    """

    sender_agent: str
    receiver_agent: str
    handoff_id: str | Unset = UNSET
    tenant_id: str | Unset = UNSET
    session_id: str | Unset = UNSET
    classification: str | Unset = UNSET
    policy_keys: list[str] | Unset = UNSET
    metadata: A2AHandoffAuthorizeRequestMetadata | Unset = UNSET
    decision: A2AHandoffAuthorizeRequestDecision | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        sender_agent = self.sender_agent

        receiver_agent = self.receiver_agent

        handoff_id = self.handoff_id

        tenant_id = self.tenant_id

        session_id = self.session_id

        classification = self.classification

        policy_keys: list[str] | Unset = UNSET
        if not isinstance(self.policy_keys, Unset):
            policy_keys = self.policy_keys

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        decision: str | Unset = UNSET
        if not isinstance(self.decision, Unset):
            decision = self.decision.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "sender_agent": sender_agent,
                "receiver_agent": receiver_agent,
            }
        )
        if handoff_id is not UNSET:
            field_dict["handoff_id"] = handoff_id
        if tenant_id is not UNSET:
            field_dict["tenant_id"] = tenant_id
        if session_id is not UNSET:
            field_dict["session_id"] = session_id
        if classification is not UNSET:
            field_dict["classification"] = classification
        if policy_keys is not UNSET:
            field_dict["policy_keys"] = policy_keys
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if decision is not UNSET:
            field_dict["decision"] = decision

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.a2a_handoff_authorize_request_metadata import A2AHandoffAuthorizeRequestMetadata

        d = dict(src_dict)
        sender_agent = d.pop("sender_agent")

        receiver_agent = d.pop("receiver_agent")

        handoff_id = d.pop("handoff_id", UNSET)

        tenant_id = d.pop("tenant_id", UNSET)

        session_id = d.pop("session_id", UNSET)

        classification = d.pop("classification", UNSET)

        policy_keys = cast(list[str], d.pop("policy_keys", UNSET))

        _metadata = d.pop("metadata", UNSET)
        metadata: A2AHandoffAuthorizeRequestMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = A2AHandoffAuthorizeRequestMetadata.from_dict(_metadata)

        _decision = d.pop("decision", UNSET)
        decision: A2AHandoffAuthorizeRequestDecision | Unset
        if isinstance(_decision, Unset):
            decision = UNSET
        else:
            decision = A2AHandoffAuthorizeRequestDecision(_decision)

        a2a_handoff_authorize_request = cls(
            sender_agent=sender_agent,
            receiver_agent=receiver_agent,
            handoff_id=handoff_id,
            tenant_id=tenant_id,
            session_id=session_id,
            classification=classification,
            policy_keys=policy_keys,
            metadata=metadata,
            decision=decision,
        )

        return a2a_handoff_authorize_request
