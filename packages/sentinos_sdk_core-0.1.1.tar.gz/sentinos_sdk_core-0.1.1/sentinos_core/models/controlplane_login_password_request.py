from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ControlplaneLoginPasswordRequest")


@_attrs_define
class ControlplaneLoginPasswordRequest:
    """
    Attributes:
        email (str):
        password (str):
        org_id (UUID | Unset):
    """

    email: str
    password: str
    org_id: UUID | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        email = self.email

        password = self.password

        org_id: str | Unset = UNSET
        if not isinstance(self.org_id, Unset):
            org_id = str(self.org_id)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "email": email,
                "password": password,
            }
        )
        if org_id is not UNSET:
            field_dict["org_id"] = org_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        password = d.pop("password")

        _org_id = d.pop("org_id", UNSET)
        org_id: UUID | Unset
        if isinstance(_org_id, Unset):
            org_id = UNSET
        else:
            org_id = UUID(_org_id)

        controlplane_login_password_request = cls(
            email=email,
            password=password,
            org_id=org_id,
        )

        return controlplane_login_password_request
