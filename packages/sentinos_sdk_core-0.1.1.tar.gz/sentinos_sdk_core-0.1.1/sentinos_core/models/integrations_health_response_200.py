from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.integration_channel_health import IntegrationChannelHealth
    from ..models.integrations_health_response_200_summary import IntegrationsHealthResponse200Summary


T = TypeVar("T", bound="IntegrationsHealthResponse200")


@_attrs_define
class IntegrationsHealthResponse200:
    """
    Attributes:
        tenant_id (str | Unset):
        summary (IntegrationsHealthResponse200Summary | Unset):
        channels (list[IntegrationChannelHealth] | Unset):
    """

    tenant_id: str | Unset = UNSET
    summary: IntegrationsHealthResponse200Summary | Unset = UNSET
    channels: list[IntegrationChannelHealth] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        summary: dict[str, Any] | Unset = UNSET
        if not isinstance(self.summary, Unset):
            summary = self.summary.to_dict()

        channels: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.channels, Unset):
            channels = []
            for channels_item_data in self.channels:
                channels_item = channels_item_data.to_dict()
                channels.append(channels_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if tenant_id is not UNSET:
            field_dict["tenant_id"] = tenant_id
        if summary is not UNSET:
            field_dict["summary"] = summary
        if channels is not UNSET:
            field_dict["channels"] = channels

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.integration_channel_health import IntegrationChannelHealth
        from ..models.integrations_health_response_200_summary import IntegrationsHealthResponse200Summary

        d = dict(src_dict)
        tenant_id = d.pop("tenant_id", UNSET)

        _summary = d.pop("summary", UNSET)
        summary: IntegrationsHealthResponse200Summary | Unset
        if isinstance(_summary, Unset):
            summary = UNSET
        else:
            summary = IntegrationsHealthResponse200Summary.from_dict(_summary)

        _channels = d.pop("channels", UNSET)
        channels: list[IntegrationChannelHealth] | Unset = UNSET
        if _channels is not UNSET:
            channels = []
            for channels_item_data in _channels:
                channels_item = IntegrationChannelHealth.from_dict(channels_item_data)

                channels.append(channels_item)

        integrations_health_response_200 = cls(
            tenant_id=tenant_id,
            summary=summary,
            channels=channels,
        )

        integrations_health_response_200.additional_properties = d
        return integrations_health_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
