from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="AutonomyRiskBudget")


@_attrs_define
class AutonomyRiskBudget:
    """
    Attributes:
        max_runtime_seconds (int | Unset):
        max_tool_calls (int | Unset):
        max_external_domains (int | Unset):
        max_data_egress_bytes (int | Unset):
        max_token_spend_usd (float | Unset):
        approval_on_privilege_escalation (bool | Unset):
    """

    max_runtime_seconds: int | Unset = UNSET
    max_tool_calls: int | Unset = UNSET
    max_external_domains: int | Unset = UNSET
    max_data_egress_bytes: int | Unset = UNSET
    max_token_spend_usd: float | Unset = UNSET
    approval_on_privilege_escalation: bool | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        max_runtime_seconds = self.max_runtime_seconds

        max_tool_calls = self.max_tool_calls

        max_external_domains = self.max_external_domains

        max_data_egress_bytes = self.max_data_egress_bytes

        max_token_spend_usd = self.max_token_spend_usd

        approval_on_privilege_escalation = self.approval_on_privilege_escalation

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if max_runtime_seconds is not UNSET:
            field_dict["max_runtime_seconds"] = max_runtime_seconds
        if max_tool_calls is not UNSET:
            field_dict["max_tool_calls"] = max_tool_calls
        if max_external_domains is not UNSET:
            field_dict["max_external_domains"] = max_external_domains
        if max_data_egress_bytes is not UNSET:
            field_dict["max_data_egress_bytes"] = max_data_egress_bytes
        if max_token_spend_usd is not UNSET:
            field_dict["max_token_spend_usd"] = max_token_spend_usd
        if approval_on_privilege_escalation is not UNSET:
            field_dict["approval_on_privilege_escalation"] = approval_on_privilege_escalation

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        max_runtime_seconds = d.pop("max_runtime_seconds", UNSET)

        max_tool_calls = d.pop("max_tool_calls", UNSET)

        max_external_domains = d.pop("max_external_domains", UNSET)

        max_data_egress_bytes = d.pop("max_data_egress_bytes", UNSET)

        max_token_spend_usd = d.pop("max_token_spend_usd", UNSET)

        approval_on_privilege_escalation = d.pop("approval_on_privilege_escalation", UNSET)

        autonomy_risk_budget = cls(
            max_runtime_seconds=max_runtime_seconds,
            max_tool_calls=max_tool_calls,
            max_external_domains=max_external_domains,
            max_data_egress_bytes=max_data_egress_bytes,
            max_token_spend_usd=max_token_spend_usd,
            approval_on_privilege_escalation=approval_on_privilege_escalation,
        )

        return autonomy_risk_budget
