from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chronos_snapshot_schema_nodes_item_properties import ChronosSnapshotSchemaNodesItemProperties
    from ..models.chronos_snapshot_schema_nodes_item_provenance_item import ChronosSnapshotSchemaNodesItemProvenanceItem
    from ..models.chronos_snapshot_schema_nodes_item_schema_context import ChronosSnapshotSchemaNodesItemSchemaContext


T = TypeVar("T", bound="ChronosSnapshotSchemaNodesItem")


@_attrs_define
class ChronosSnapshotSchemaNodesItem:
    """
    Attributes:
        node_id (str | Unset):
        type_ (str | Unset):
        schema_type (str | Unset):
        schema_context (ChronosSnapshotSchemaNodesItemSchemaContext | Unset):
        properties (ChronosSnapshotSchemaNodesItemProperties | Unset):
        confidence (float | Unset):
        provenance (list[ChronosSnapshotSchemaNodesItemProvenanceItem] | Unset):
    """

    node_id: str | Unset = UNSET
    type_: str | Unset = UNSET
    schema_type: str | Unset = UNSET
    schema_context: ChronosSnapshotSchemaNodesItemSchemaContext | Unset = UNSET
    properties: ChronosSnapshotSchemaNodesItemProperties | Unset = UNSET
    confidence: float | Unset = UNSET
    provenance: list[ChronosSnapshotSchemaNodesItemProvenanceItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        node_id = self.node_id

        type_ = self.type_

        schema_type = self.schema_type

        schema_context: dict[str, Any] | Unset = UNSET
        if not isinstance(self.schema_context, Unset):
            schema_context = self.schema_context.to_dict()

        properties: dict[str, Any] | Unset = UNSET
        if not isinstance(self.properties, Unset):
            properties = self.properties.to_dict()

        confidence = self.confidence

        provenance: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.provenance, Unset):
            provenance = []
            for provenance_item_data in self.provenance:
                provenance_item = provenance_item_data.to_dict()
                provenance.append(provenance_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if node_id is not UNSET:
            field_dict["node_id"] = node_id
        if type_ is not UNSET:
            field_dict["type"] = type_
        if schema_type is not UNSET:
            field_dict["schema_type"] = schema_type
        if schema_context is not UNSET:
            field_dict["schema_context"] = schema_context
        if properties is not UNSET:
            field_dict["properties"] = properties
        if confidence is not UNSET:
            field_dict["confidence"] = confidence
        if provenance is not UNSET:
            field_dict["provenance"] = provenance

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chronos_snapshot_schema_nodes_item_properties import ChronosSnapshotSchemaNodesItemProperties
        from ..models.chronos_snapshot_schema_nodes_item_provenance_item import (
            ChronosSnapshotSchemaNodesItemProvenanceItem,
        )
        from ..models.chronos_snapshot_schema_nodes_item_schema_context import (
            ChronosSnapshotSchemaNodesItemSchemaContext,
        )

        d = dict(src_dict)
        node_id = d.pop("node_id", UNSET)

        type_ = d.pop("type", UNSET)

        schema_type = d.pop("schema_type", UNSET)

        _schema_context = d.pop("schema_context", UNSET)
        schema_context: ChronosSnapshotSchemaNodesItemSchemaContext | Unset
        if isinstance(_schema_context, Unset):
            schema_context = UNSET
        else:
            schema_context = ChronosSnapshotSchemaNodesItemSchemaContext.from_dict(_schema_context)

        _properties = d.pop("properties", UNSET)
        properties: ChronosSnapshotSchemaNodesItemProperties | Unset
        if isinstance(_properties, Unset):
            properties = UNSET
        else:
            properties = ChronosSnapshotSchemaNodesItemProperties.from_dict(_properties)

        confidence = d.pop("confidence", UNSET)

        _provenance = d.pop("provenance", UNSET)
        provenance: list[ChronosSnapshotSchemaNodesItemProvenanceItem] | Unset = UNSET
        if _provenance is not UNSET:
            provenance = []
            for provenance_item_data in _provenance:
                provenance_item = ChronosSnapshotSchemaNodesItemProvenanceItem.from_dict(provenance_item_data)

                provenance.append(provenance_item)

        chronos_snapshot_schema_nodes_item = cls(
            node_id=node_id,
            type_=type_,
            schema_type=schema_type,
            schema_context=schema_context,
            properties=properties,
            confidence=confidence,
            provenance=provenance,
        )

        chronos_snapshot_schema_nodes_item.additional_properties = d
        return chronos_snapshot_schema_nodes_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
