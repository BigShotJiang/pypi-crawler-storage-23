from enum import Enum


class ControlplanePatchMemberBodyStatus(str, Enum):
    ACTIVE = "ACTIVE"
    REMOVED = "REMOVED"
    SUSPENDED = "SUSPENDED"

    def __str__(self) -> str:
        return str(self.value)
