from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.arbiter_get_tenant_response_200_config import ArbiterGetTenantResponse200Config


T = TypeVar("T", bound="ArbiterGetTenantResponse200")


@_attrs_define
class ArbiterGetTenantResponse200:
    """
    Attributes:
        tenant_id (str):
        config (ArbiterGetTenantResponse200Config):
    """

    tenant_id: str
    config: ArbiterGetTenantResponse200Config

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        config = self.config.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "config": config,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.arbiter_get_tenant_response_200_config import ArbiterGetTenantResponse200Config

        d = dict(src_dict)
        tenant_id = d.pop("tenant_id")

        config = ArbiterGetTenantResponse200Config.from_dict(d.pop("config"))

        arbiter_get_tenant_response_200 = cls(
            tenant_id=tenant_id,
            config=config,
        )

        return arbiter_get_tenant_response_200
