from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.role_record import RoleRecord


T = TypeVar("T", bound="ControlplaneListRolesResponse200")


@_attrs_define
class ControlplaneListRolesResponse200:
    """
    Attributes:
        roles (list[RoleRecord]):
    """

    roles: list[RoleRecord]

    def to_dict(self) -> dict[str, Any]:
        roles = []
        for roles_item_data in self.roles:
            roles_item = roles_item_data.to_dict()
            roles.append(roles_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "roles": roles,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.role_record import RoleRecord

        d = dict(src_dict)
        roles = []
        _roles = d.pop("roles")
        for roles_item_data in _roles:
            roles_item = RoleRecord.from_dict(roles_item_data)

            roles.append(roles_item)

        controlplane_list_roles_response_200 = cls(
            roles=roles,
        )

        return controlplane_list_roles_response_200
