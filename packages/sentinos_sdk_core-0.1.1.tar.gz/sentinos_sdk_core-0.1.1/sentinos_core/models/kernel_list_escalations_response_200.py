from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.escalation_record import EscalationRecord


T = TypeVar("T", bound="KernelListEscalationsResponse200")


@_attrs_define
class KernelListEscalationsResponse200:
    """
    Attributes:
        escalations (list[EscalationRecord]):
    """

    escalations: list[EscalationRecord]

    def to_dict(self) -> dict[str, Any]:
        escalations = []
        for escalations_item_data in self.escalations:
            escalations_item = escalations_item_data.to_dict()
            escalations.append(escalations_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "escalations": escalations,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.escalation_record import EscalationRecord

        d = dict(src_dict)
        escalations = []
        _escalations = d.pop("escalations")
        for escalations_item_data in _escalations:
            escalations_item = EscalationRecord.from_dict(escalations_item_data)

            escalations.append(escalations_item)

        kernel_list_escalations_response_200 = cls(
            escalations=escalations,
        )

        return kernel_list_escalations_response_200
