from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.incident import Incident
    from ..models.incident_timeline_event import IncidentTimelineEvent


T = TypeVar("T", bound="GetIncidentResponse200")


@_attrs_define
class GetIncidentResponse200:
    """
    Attributes:
        incident (Incident | Unset):
        timeline (list[IncidentTimelineEvent] | Unset):
    """

    incident: Incident | Unset = UNSET
    timeline: list[IncidentTimelineEvent] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        incident: dict[str, Any] | Unset = UNSET
        if not isinstance(self.incident, Unset):
            incident = self.incident.to_dict()

        timeline: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.timeline, Unset):
            timeline = []
            for timeline_item_data in self.timeline:
                timeline_item = timeline_item_data.to_dict()
                timeline.append(timeline_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if incident is not UNSET:
            field_dict["incident"] = incident
        if timeline is not UNSET:
            field_dict["timeline"] = timeline

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.incident import Incident
        from ..models.incident_timeline_event import IncidentTimelineEvent

        d = dict(src_dict)
        _incident = d.pop("incident", UNSET)
        incident: Incident | Unset
        if isinstance(_incident, Unset):
            incident = UNSET
        else:
            incident = Incident.from_dict(_incident)

        _timeline = d.pop("timeline", UNSET)
        timeline: list[IncidentTimelineEvent] | Unset = UNSET
        if _timeline is not UNSET:
            timeline = []
            for timeline_item_data in _timeline:
                timeline_item = IncidentTimelineEvent.from_dict(timeline_item_data)

                timeline.append(timeline_item)

        get_incident_response_200 = cls(
            incident=incident,
            timeline=timeline,
        )

        get_incident_response_200.additional_properties = d
        return get_incident_response_200

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
