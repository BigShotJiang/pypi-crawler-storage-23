from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

T = TypeVar("T", bound="ChronosConnectorHealthResponseSummary")


@_attrs_define
class ChronosConnectorHealthResponseSummary:
    """
    Attributes:
        enabled (int):
        disabled (int):
        healthy (int):
        unhealthy (int):
    """

    enabled: int
    disabled: int
    healthy: int
    unhealthy: int

    def to_dict(self) -> dict[str, Any]:
        enabled = self.enabled

        disabled = self.disabled

        healthy = self.healthy

        unhealthy = self.unhealthy

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "enabled": enabled,
                "disabled": disabled,
                "healthy": healthy,
                "unhealthy": unhealthy,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        enabled = d.pop("enabled")

        disabled = d.pop("disabled")

        healthy = d.pop("healthy")

        unhealthy = d.pop("unhealthy")

        chronos_connector_health_response_summary = cls(
            enabled=enabled,
            disabled=disabled,
            healthy=healthy,
            unhealthy=unhealthy,
        )

        return chronos_connector_health_response_summary
