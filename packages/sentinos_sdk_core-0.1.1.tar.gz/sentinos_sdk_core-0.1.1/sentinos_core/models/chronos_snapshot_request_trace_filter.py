from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ChronosSnapshotRequestTraceFilter")


@_attrs_define
class ChronosSnapshotRequestTraceFilter:
    """
    Attributes:
        since (datetime.datetime | Unset):
        policy_ids (list[str] | Unset):
    """

    since: datetime.datetime | Unset = UNSET
    policy_ids: list[str] | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        since: str | Unset = UNSET
        if not isinstance(self.since, Unset):
            since = self.since.isoformat()

        policy_ids: list[str] | Unset = UNSET
        if not isinstance(self.policy_ids, Unset):
            policy_ids = self.policy_ids

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if since is not UNSET:
            field_dict["since"] = since
        if policy_ids is not UNSET:
            field_dict["policy_ids"] = policy_ids

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _since = d.pop("since", UNSET)
        since: datetime.datetime | Unset
        if isinstance(_since, Unset):
            since = UNSET
        else:
            since = isoparse(_since)

        policy_ids = cast(list[str], d.pop("policy_ids", UNSET))

        chronos_snapshot_request_trace_filter = cls(
            since=since,
            policy_ids=policy_ids,
        )

        return chronos_snapshot_request_trace_filter
