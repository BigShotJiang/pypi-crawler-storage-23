from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="AuthNMappingCreateRequest")


@_attrs_define
class AuthNMappingCreateRequest:
    """
    Attributes:
        attribute_key (str):
        attribute_value (str):
        target_role_id (UUID):
        target_team_id (UUID | Unset):
        priority (int | Unset):
    """

    attribute_key: str
    attribute_value: str
    target_role_id: UUID
    target_team_id: UUID | Unset = UNSET
    priority: int | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        attribute_key = self.attribute_key

        attribute_value = self.attribute_value

        target_role_id = str(self.target_role_id)

        target_team_id: str | Unset = UNSET
        if not isinstance(self.target_team_id, Unset):
            target_team_id = str(self.target_team_id)

        priority = self.priority

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "attribute_key": attribute_key,
                "attribute_value": attribute_value,
                "target_role_id": target_role_id,
            }
        )
        if target_team_id is not UNSET:
            field_dict["target_team_id"] = target_team_id
        if priority is not UNSET:
            field_dict["priority"] = priority

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        attribute_key = d.pop("attribute_key")

        attribute_value = d.pop("attribute_value")

        target_role_id = UUID(d.pop("target_role_id"))

        _target_team_id = d.pop("target_team_id", UNSET)
        target_team_id: UUID | Unset
        if isinstance(_target_team_id, Unset):
            target_team_id = UNSET
        else:
            target_team_id = UUID(_target_team_id)

        priority = d.pop("priority", UNSET)

        auth_n_mapping_create_request = cls(
            attribute_key=attribute_key,
            attribute_value=attribute_value,
            target_role_id=target_role_id,
            target_team_id=target_team_id,
            priority=priority,
        )

        return auth_n_mapping_create_request
