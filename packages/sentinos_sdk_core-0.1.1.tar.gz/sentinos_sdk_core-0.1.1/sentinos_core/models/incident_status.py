from enum import Enum


class IncidentStatus(str, Enum):
    INVESTIGATING = "INVESTIGATING"
    MITIGATING = "MITIGATING"
    OPEN = "OPEN"
    RESOLVED = "RESOLVED"

    def __str__(self) -> str:
        return str(self.value)
