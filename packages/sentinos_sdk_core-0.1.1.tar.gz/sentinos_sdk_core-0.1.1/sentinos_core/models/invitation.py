from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="Invitation")


@_attrs_define
class Invitation:
    """
    Attributes:
        invitation_id (UUID):
        org_id (UUID):
        email (str):
        invited_by (UUID):
        expires_at (datetime.datetime):
        resent_count (int):
        created_at (datetime.datetime):
        accepted_at (datetime.datetime | Unset):
        cancelled_at (datetime.datetime | Unset):
    """

    invitation_id: UUID
    org_id: UUID
    email: str
    invited_by: UUID
    expires_at: datetime.datetime
    resent_count: int
    created_at: datetime.datetime
    accepted_at: datetime.datetime | Unset = UNSET
    cancelled_at: datetime.datetime | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        invitation_id = str(self.invitation_id)

        org_id = str(self.org_id)

        email = self.email

        invited_by = str(self.invited_by)

        expires_at = self.expires_at.isoformat()

        resent_count = self.resent_count

        created_at = self.created_at.isoformat()

        accepted_at: str | Unset = UNSET
        if not isinstance(self.accepted_at, Unset):
            accepted_at = self.accepted_at.isoformat()

        cancelled_at: str | Unset = UNSET
        if not isinstance(self.cancelled_at, Unset):
            cancelled_at = self.cancelled_at.isoformat()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "invitation_id": invitation_id,
                "org_id": org_id,
                "email": email,
                "invited_by": invited_by,
                "expires_at": expires_at,
                "resent_count": resent_count,
                "created_at": created_at,
            }
        )
        if accepted_at is not UNSET:
            field_dict["accepted_at"] = accepted_at
        if cancelled_at is not UNSET:
            field_dict["cancelled_at"] = cancelled_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        invitation_id = UUID(d.pop("invitation_id"))

        org_id = UUID(d.pop("org_id"))

        email = d.pop("email")

        invited_by = UUID(d.pop("invited_by"))

        expires_at = isoparse(d.pop("expires_at"))

        resent_count = d.pop("resent_count")

        created_at = isoparse(d.pop("created_at"))

        _accepted_at = d.pop("accepted_at", UNSET)
        accepted_at: datetime.datetime | Unset
        if isinstance(_accepted_at, Unset):
            accepted_at = UNSET
        else:
            accepted_at = isoparse(_accepted_at)

        _cancelled_at = d.pop("cancelled_at", UNSET)
        cancelled_at: datetime.datetime | Unset
        if isinstance(_cancelled_at, Unset):
            cancelled_at = UNSET
        else:
            cancelled_at = isoparse(_cancelled_at)

        invitation = cls(
            invitation_id=invitation_id,
            org_id=org_id,
            email=email,
            invited_by=invited_by,
            expires_at=expires_at,
            resent_count=resent_count,
            created_at=created_at,
            accepted_at=accepted_at,
            cancelled_at=cancelled_at,
        )

        return invitation
