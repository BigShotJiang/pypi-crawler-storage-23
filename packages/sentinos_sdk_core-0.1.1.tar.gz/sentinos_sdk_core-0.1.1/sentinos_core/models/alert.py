from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.alert_severity import AlertSeverity
from ..models.alert_status import AlertStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.alert_evidence import AlertEvidence
    from ..models.alert_labels import AlertLabels


T = TypeVar("T", bound="Alert")


@_attrs_define
class Alert:
    """
    Attributes:
        alert_id (UUID):
        tenant_id (str):
        status (AlertStatus):
        severity (AlertSeverity):
        title (str):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        rule_id (UUID | Unset):
        anomaly_id (UUID | Unset):
        incident_id (UUID | Unset):
        description (str | Unset):
        correlation_key (str | Unset):
        metric_value (float | Unset):
        threshold_value (float | Unset):
        labels (AlertLabels | Unset):
        evidence (AlertEvidence | Unset):
        first_fired_at (datetime.datetime | Unset):
        last_fired_at (datetime.datetime | Unset):
        acknowledged_at (datetime.datetime | Unset):
        acknowledged_by (str | Unset):
        resolved_at (datetime.datetime | Unset):
        resolved_by (str | Unset):
        escalated_at (datetime.datetime | Unset):
        escalated_to (str | Unset):
    """

    alert_id: UUID
    tenant_id: str
    status: AlertStatus
    severity: AlertSeverity
    title: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    rule_id: UUID | Unset = UNSET
    anomaly_id: UUID | Unset = UNSET
    incident_id: UUID | Unset = UNSET
    description: str | Unset = UNSET
    correlation_key: str | Unset = UNSET
    metric_value: float | Unset = UNSET
    threshold_value: float | Unset = UNSET
    labels: AlertLabels | Unset = UNSET
    evidence: AlertEvidence | Unset = UNSET
    first_fired_at: datetime.datetime | Unset = UNSET
    last_fired_at: datetime.datetime | Unset = UNSET
    acknowledged_at: datetime.datetime | Unset = UNSET
    acknowledged_by: str | Unset = UNSET
    resolved_at: datetime.datetime | Unset = UNSET
    resolved_by: str | Unset = UNSET
    escalated_at: datetime.datetime | Unset = UNSET
    escalated_to: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        alert_id = str(self.alert_id)

        tenant_id = self.tenant_id

        status = self.status.value

        severity = self.severity.value

        title = self.title

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        rule_id: str | Unset = UNSET
        if not isinstance(self.rule_id, Unset):
            rule_id = str(self.rule_id)

        anomaly_id: str | Unset = UNSET
        if not isinstance(self.anomaly_id, Unset):
            anomaly_id = str(self.anomaly_id)

        incident_id: str | Unset = UNSET
        if not isinstance(self.incident_id, Unset):
            incident_id = str(self.incident_id)

        description = self.description

        correlation_key = self.correlation_key

        metric_value = self.metric_value

        threshold_value = self.threshold_value

        labels: dict[str, Any] | Unset = UNSET
        if not isinstance(self.labels, Unset):
            labels = self.labels.to_dict()

        evidence: dict[str, Any] | Unset = UNSET
        if not isinstance(self.evidence, Unset):
            evidence = self.evidence.to_dict()

        first_fired_at: str | Unset = UNSET
        if not isinstance(self.first_fired_at, Unset):
            first_fired_at = self.first_fired_at.isoformat()

        last_fired_at: str | Unset = UNSET
        if not isinstance(self.last_fired_at, Unset):
            last_fired_at = self.last_fired_at.isoformat()

        acknowledged_at: str | Unset = UNSET
        if not isinstance(self.acknowledged_at, Unset):
            acknowledged_at = self.acknowledged_at.isoformat()

        acknowledged_by = self.acknowledged_by

        resolved_at: str | Unset = UNSET
        if not isinstance(self.resolved_at, Unset):
            resolved_at = self.resolved_at.isoformat()

        resolved_by = self.resolved_by

        escalated_at: str | Unset = UNSET
        if not isinstance(self.escalated_at, Unset):
            escalated_at = self.escalated_at.isoformat()

        escalated_to = self.escalated_to

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "alert_id": alert_id,
                "tenant_id": tenant_id,
                "status": status,
                "severity": severity,
                "title": title,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if rule_id is not UNSET:
            field_dict["rule_id"] = rule_id
        if anomaly_id is not UNSET:
            field_dict["anomaly_id"] = anomaly_id
        if incident_id is not UNSET:
            field_dict["incident_id"] = incident_id
        if description is not UNSET:
            field_dict["description"] = description
        if correlation_key is not UNSET:
            field_dict["correlation_key"] = correlation_key
        if metric_value is not UNSET:
            field_dict["metric_value"] = metric_value
        if threshold_value is not UNSET:
            field_dict["threshold_value"] = threshold_value
        if labels is not UNSET:
            field_dict["labels"] = labels
        if evidence is not UNSET:
            field_dict["evidence"] = evidence
        if first_fired_at is not UNSET:
            field_dict["first_fired_at"] = first_fired_at
        if last_fired_at is not UNSET:
            field_dict["last_fired_at"] = last_fired_at
        if acknowledged_at is not UNSET:
            field_dict["acknowledged_at"] = acknowledged_at
        if acknowledged_by is not UNSET:
            field_dict["acknowledged_by"] = acknowledged_by
        if resolved_at is not UNSET:
            field_dict["resolved_at"] = resolved_at
        if resolved_by is not UNSET:
            field_dict["resolved_by"] = resolved_by
        if escalated_at is not UNSET:
            field_dict["escalated_at"] = escalated_at
        if escalated_to is not UNSET:
            field_dict["escalated_to"] = escalated_to

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.alert_evidence import AlertEvidence
        from ..models.alert_labels import AlertLabels

        d = dict(src_dict)
        alert_id = UUID(d.pop("alert_id"))

        tenant_id = d.pop("tenant_id")

        status = AlertStatus(d.pop("status"))

        severity = AlertSeverity(d.pop("severity"))

        title = d.pop("title")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        _rule_id = d.pop("rule_id", UNSET)
        rule_id: UUID | Unset
        if isinstance(_rule_id, Unset):
            rule_id = UNSET
        else:
            rule_id = UUID(_rule_id)

        _anomaly_id = d.pop("anomaly_id", UNSET)
        anomaly_id: UUID | Unset
        if isinstance(_anomaly_id, Unset):
            anomaly_id = UNSET
        else:
            anomaly_id = UUID(_anomaly_id)

        _incident_id = d.pop("incident_id", UNSET)
        incident_id: UUID | Unset
        if isinstance(_incident_id, Unset):
            incident_id = UNSET
        else:
            incident_id = UUID(_incident_id)

        description = d.pop("description", UNSET)

        correlation_key = d.pop("correlation_key", UNSET)

        metric_value = d.pop("metric_value", UNSET)

        threshold_value = d.pop("threshold_value", UNSET)

        _labels = d.pop("labels", UNSET)
        labels: AlertLabels | Unset
        if isinstance(_labels, Unset):
            labels = UNSET
        else:
            labels = AlertLabels.from_dict(_labels)

        _evidence = d.pop("evidence", UNSET)
        evidence: AlertEvidence | Unset
        if isinstance(_evidence, Unset):
            evidence = UNSET
        else:
            evidence = AlertEvidence.from_dict(_evidence)

        _first_fired_at = d.pop("first_fired_at", UNSET)
        first_fired_at: datetime.datetime | Unset
        if isinstance(_first_fired_at, Unset):
            first_fired_at = UNSET
        else:
            first_fired_at = isoparse(_first_fired_at)

        _last_fired_at = d.pop("last_fired_at", UNSET)
        last_fired_at: datetime.datetime | Unset
        if isinstance(_last_fired_at, Unset):
            last_fired_at = UNSET
        else:
            last_fired_at = isoparse(_last_fired_at)

        _acknowledged_at = d.pop("acknowledged_at", UNSET)
        acknowledged_at: datetime.datetime | Unset
        if isinstance(_acknowledged_at, Unset):
            acknowledged_at = UNSET
        else:
            acknowledged_at = isoparse(_acknowledged_at)

        acknowledged_by = d.pop("acknowledged_by", UNSET)

        _resolved_at = d.pop("resolved_at", UNSET)
        resolved_at: datetime.datetime | Unset
        if isinstance(_resolved_at, Unset):
            resolved_at = UNSET
        else:
            resolved_at = isoparse(_resolved_at)

        resolved_by = d.pop("resolved_by", UNSET)

        _escalated_at = d.pop("escalated_at", UNSET)
        escalated_at: datetime.datetime | Unset
        if isinstance(_escalated_at, Unset):
            escalated_at = UNSET
        else:
            escalated_at = isoparse(_escalated_at)

        escalated_to = d.pop("escalated_to", UNSET)

        alert = cls(
            alert_id=alert_id,
            tenant_id=tenant_id,
            status=status,
            severity=severity,
            title=title,
            created_at=created_at,
            updated_at=updated_at,
            rule_id=rule_id,
            anomaly_id=anomaly_id,
            incident_id=incident_id,
            description=description,
            correlation_key=correlation_key,
            metric_value=metric_value,
            threshold_value=threshold_value,
            labels=labels,
            evidence=evidence,
            first_fired_at=first_fired_at,
            last_fired_at=last_fired_at,
            acknowledged_at=acknowledged_at,
            acknowledged_by=acknowledged_by,
            resolved_at=resolved_at,
            resolved_by=resolved_by,
            escalated_at=escalated_at,
            escalated_to=escalated_to,
        )

        alert.additional_properties = d
        return alert

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
