from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.membership import Membership
    from ..models.organization import Organization


T = TypeVar("T", bound="ControlplaneCreateOrganizationResponse200")


@_attrs_define
class ControlplaneCreateOrganizationResponse200:
    """
    Attributes:
        organization (Organization):
        membership (Membership):
    """

    organization: Organization
    membership: Membership

    def to_dict(self) -> dict[str, Any]:
        organization = self.organization.to_dict()

        membership = self.membership.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "organization": organization,
                "membership": membership,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.membership import Membership
        from ..models.organization import Organization

        d = dict(src_dict)
        organization = Organization.from_dict(d.pop("organization"))

        membership = Membership.from_dict(d.pop("membership"))

        controlplane_create_organization_response_200 = cls(
            organization=organization,
            membership=membership,
        )

        return controlplane_create_organization_response_200
