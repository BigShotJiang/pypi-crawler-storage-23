from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..models.decision import Decision
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.kernel_execute_allow_response_outcome import KernelExecuteAllowResponseOutcome


T = TypeVar("T", bound="KernelExecuteAllowResponse")


@_attrs_define
class KernelExecuteAllowResponse:
    """
    Attributes:
        trace_id (UUID):
        decision (Decision):
        message (str | Unset):
        outcome (KernelExecuteAllowResponseOutcome | Unset):
    """

    trace_id: UUID
    decision: Decision
    message: str | Unset = UNSET
    outcome: KernelExecuteAllowResponseOutcome | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        trace_id = str(self.trace_id)

        decision = self.decision.value

        message = self.message

        outcome: dict[str, Any] | Unset = UNSET
        if not isinstance(self.outcome, Unset):
            outcome = self.outcome.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "trace_id": trace_id,
                "decision": decision,
            }
        )
        if message is not UNSET:
            field_dict["message"] = message
        if outcome is not UNSET:
            field_dict["outcome"] = outcome

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.kernel_execute_allow_response_outcome import KernelExecuteAllowResponseOutcome

        d = dict(src_dict)
        trace_id = UUID(d.pop("trace_id"))

        decision = Decision(d.pop("decision"))

        message = d.pop("message", UNSET)

        _outcome = d.pop("outcome", UNSET)
        outcome: KernelExecuteAllowResponseOutcome | Unset
        if isinstance(_outcome, Unset):
            outcome = UNSET
        else:
            outcome = KernelExecuteAllowResponseOutcome.from_dict(_outcome)

        kernel_execute_allow_response = cls(
            trace_id=trace_id,
            decision=decision,
            message=message,
            outcome=outcome,
        )

        return kernel_execute_allow_response
