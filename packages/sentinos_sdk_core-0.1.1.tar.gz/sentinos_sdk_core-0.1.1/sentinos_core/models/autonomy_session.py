from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..models.autonomy_session_status import AutonomySessionStatus
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.autonomy_risk_budget import AutonomyRiskBudget
    from ..models.autonomy_session_metadata import AutonomySessionMetadata


T = TypeVar("T", bound="AutonomySession")


@_attrs_define
class AutonomySession:
    """
    Attributes:
        session_id (str):
        tenant_id (str):
        agent_id (str):
        status (AutonomySessionStatus):
        started_at (datetime.datetime):
        updated_at (datetime.datetime):
        paused_at (datetime.datetime | Unset):
        terminated_at (datetime.datetime | Unset):
        risk_budget_snapshot (AutonomyRiskBudget | Unset):
        budget_violation_reason (str | Unset):
        metadata (AutonomySessionMetadata | Unset):
    """

    session_id: str
    tenant_id: str
    agent_id: str
    status: AutonomySessionStatus
    started_at: datetime.datetime
    updated_at: datetime.datetime
    paused_at: datetime.datetime | Unset = UNSET
    terminated_at: datetime.datetime | Unset = UNSET
    risk_budget_snapshot: AutonomyRiskBudget | Unset = UNSET
    budget_violation_reason: str | Unset = UNSET
    metadata: AutonomySessionMetadata | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        session_id = self.session_id

        tenant_id = self.tenant_id

        agent_id = self.agent_id

        status = self.status.value

        started_at = self.started_at.isoformat()

        updated_at = self.updated_at.isoformat()

        paused_at: str | Unset = UNSET
        if not isinstance(self.paused_at, Unset):
            paused_at = self.paused_at.isoformat()

        terminated_at: str | Unset = UNSET
        if not isinstance(self.terminated_at, Unset):
            terminated_at = self.terminated_at.isoformat()

        risk_budget_snapshot: dict[str, Any] | Unset = UNSET
        if not isinstance(self.risk_budget_snapshot, Unset):
            risk_budget_snapshot = self.risk_budget_snapshot.to_dict()

        budget_violation_reason = self.budget_violation_reason

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "session_id": session_id,
                "tenant_id": tenant_id,
                "agent_id": agent_id,
                "status": status,
                "started_at": started_at,
                "updated_at": updated_at,
            }
        )
        if paused_at is not UNSET:
            field_dict["paused_at"] = paused_at
        if terminated_at is not UNSET:
            field_dict["terminated_at"] = terminated_at
        if risk_budget_snapshot is not UNSET:
            field_dict["risk_budget_snapshot"] = risk_budget_snapshot
        if budget_violation_reason is not UNSET:
            field_dict["budget_violation_reason"] = budget_violation_reason
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.autonomy_risk_budget import AutonomyRiskBudget
        from ..models.autonomy_session_metadata import AutonomySessionMetadata

        d = dict(src_dict)
        session_id = d.pop("session_id")

        tenant_id = d.pop("tenant_id")

        agent_id = d.pop("agent_id")

        status = AutonomySessionStatus(d.pop("status"))

        started_at = isoparse(d.pop("started_at"))

        updated_at = isoparse(d.pop("updated_at"))

        _paused_at = d.pop("paused_at", UNSET)
        paused_at: datetime.datetime | Unset
        if isinstance(_paused_at, Unset):
            paused_at = UNSET
        else:
            paused_at = isoparse(_paused_at)

        _terminated_at = d.pop("terminated_at", UNSET)
        terminated_at: datetime.datetime | Unset
        if isinstance(_terminated_at, Unset):
            terminated_at = UNSET
        else:
            terminated_at = isoparse(_terminated_at)

        _risk_budget_snapshot = d.pop("risk_budget_snapshot", UNSET)
        risk_budget_snapshot: AutonomyRiskBudget | Unset
        if isinstance(_risk_budget_snapshot, Unset):
            risk_budget_snapshot = UNSET
        else:
            risk_budget_snapshot = AutonomyRiskBudget.from_dict(_risk_budget_snapshot)

        budget_violation_reason = d.pop("budget_violation_reason", UNSET)

        _metadata = d.pop("metadata", UNSET)
        metadata: AutonomySessionMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = AutonomySessionMetadata.from_dict(_metadata)

        autonomy_session = cls(
            session_id=session_id,
            tenant_id=tenant_id,
            agent_id=agent_id,
            status=status,
            started_at=started_at,
            updated_at=updated_at,
            paused_at=paused_at,
            terminated_at=terminated_at,
            risk_budget_snapshot=risk_budget_snapshot,
            budget_violation_reason=budget_violation_reason,
            metadata=metadata,
        )

        return autonomy_session
