from enum import Enum


class AuthSessionRecordAuthMethod(str, Enum):
    GOOGLE_OIDC = "GOOGLE_OIDC"
    PASSWORD = "PASSWORD"
    SAML = "SAML"

    def __str__(self) -> str:
        return str(self.value)
