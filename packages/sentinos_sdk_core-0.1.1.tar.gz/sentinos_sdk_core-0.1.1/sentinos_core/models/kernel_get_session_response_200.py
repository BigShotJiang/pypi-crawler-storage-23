from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.kernel_get_session_response_200_state import KernelGetSessionResponse200State


T = TypeVar("T", bound="KernelGetSessionResponse200")


@_attrs_define
class KernelGetSessionResponse200:
    """
    Attributes:
        tenant_id (str):
        session_id (str):
        state (KernelGetSessionResponse200State):
    """

    tenant_id: str
    session_id: str
    state: KernelGetSessionResponse200State

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        session_id = self.session_id

        state = self.state.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "tenant_id": tenant_id,
                "session_id": session_id,
                "state": state,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.kernel_get_session_response_200_state import KernelGetSessionResponse200State

        d = dict(src_dict)
        tenant_id = d.pop("tenant_id")

        session_id = d.pop("session_id")

        state = KernelGetSessionResponse200State.from_dict(d.pop("state"))

        kernel_get_session_response_200 = cls(
            tenant_id=tenant_id,
            session_id=session_id,
            state=state,
        )

        return kernel_get_session_response_200
