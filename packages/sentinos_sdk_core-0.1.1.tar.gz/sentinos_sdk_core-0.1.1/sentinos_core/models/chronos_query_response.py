from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chronos_query_response_decision_traces_item import ChronosQueryResponseDecisionTracesItem
    from ..models.chronos_query_response_edges_item import ChronosQueryResponseEdgesItem
    from ..models.chronos_query_response_hits_item import ChronosQueryResponseHitsItem
    from ..models.chronos_query_response_nodes_item import ChronosQueryResponseNodesItem


T = TypeVar("T", bound="ChronosQueryResponse")


@_attrs_define
class ChronosQueryResponse:
    """
    Attributes:
        query_id (str):
        hits (list[ChronosQueryResponseHitsItem]):
        nodes (list[ChronosQueryResponseNodesItem]):
        edges (list[ChronosQueryResponseEdgesItem]):
        generated_at (datetime.datetime | Unset):
        decision_traces (list[ChronosQueryResponseDecisionTracesItem] | Unset):
    """

    query_id: str
    hits: list[ChronosQueryResponseHitsItem]
    nodes: list[ChronosQueryResponseNodesItem]
    edges: list[ChronosQueryResponseEdgesItem]
    generated_at: datetime.datetime | Unset = UNSET
    decision_traces: list[ChronosQueryResponseDecisionTracesItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        query_id = self.query_id

        hits = []
        for hits_item_data in self.hits:
            hits_item = hits_item_data.to_dict()
            hits.append(hits_item)

        nodes = []
        for nodes_item_data in self.nodes:
            nodes_item = nodes_item_data.to_dict()
            nodes.append(nodes_item)

        edges = []
        for edges_item_data in self.edges:
            edges_item = edges_item_data.to_dict()
            edges.append(edges_item)

        generated_at: str | Unset = UNSET
        if not isinstance(self.generated_at, Unset):
            generated_at = self.generated_at.isoformat()

        decision_traces: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.decision_traces, Unset):
            decision_traces = []
            for decision_traces_item_data in self.decision_traces:
                decision_traces_item = decision_traces_item_data.to_dict()
                decision_traces.append(decision_traces_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "query_id": query_id,
                "hits": hits,
                "nodes": nodes,
                "edges": edges,
            }
        )
        if generated_at is not UNSET:
            field_dict["generated_at"] = generated_at
        if decision_traces is not UNSET:
            field_dict["decision_traces"] = decision_traces

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chronos_query_response_decision_traces_item import ChronosQueryResponseDecisionTracesItem
        from ..models.chronos_query_response_edges_item import ChronosQueryResponseEdgesItem
        from ..models.chronos_query_response_hits_item import ChronosQueryResponseHitsItem
        from ..models.chronos_query_response_nodes_item import ChronosQueryResponseNodesItem

        d = dict(src_dict)
        query_id = d.pop("query_id")

        hits = []
        _hits = d.pop("hits")
        for hits_item_data in _hits:
            hits_item = ChronosQueryResponseHitsItem.from_dict(hits_item_data)

            hits.append(hits_item)

        nodes = []
        _nodes = d.pop("nodes")
        for nodes_item_data in _nodes:
            nodes_item = ChronosQueryResponseNodesItem.from_dict(nodes_item_data)

            nodes.append(nodes_item)

        edges = []
        _edges = d.pop("edges")
        for edges_item_data in _edges:
            edges_item = ChronosQueryResponseEdgesItem.from_dict(edges_item_data)

            edges.append(edges_item)

        _generated_at = d.pop("generated_at", UNSET)
        generated_at: datetime.datetime | Unset
        if isinstance(_generated_at, Unset):
            generated_at = UNSET
        else:
            generated_at = isoparse(_generated_at)

        _decision_traces = d.pop("decision_traces", UNSET)
        decision_traces: list[ChronosQueryResponseDecisionTracesItem] | Unset = UNSET
        if _decision_traces is not UNSET:
            decision_traces = []
            for decision_traces_item_data in _decision_traces:
                decision_traces_item = ChronosQueryResponseDecisionTracesItem.from_dict(decision_traces_item_data)

                decision_traces.append(decision_traces_item)

        chronos_query_response = cls(
            query_id=query_id,
            hits=hits,
            nodes=nodes,
            edges=edges,
            generated_at=generated_at,
            decision_traces=decision_traces,
        )

        chronos_query_response.additional_properties = d
        return chronos_query_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
