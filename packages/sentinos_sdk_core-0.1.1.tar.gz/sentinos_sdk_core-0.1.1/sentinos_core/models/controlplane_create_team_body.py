from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ControlplaneCreateTeamBody")


@_attrs_define
class ControlplaneCreateTeamBody:
    """
    Attributes:
        name (str):
        handle (str | Unset):
        description (str | Unset):
    """

    name: str
    handle: str | Unset = UNSET
    description: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        handle = self.handle

        description = self.description

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "name": name,
            }
        )
        if handle is not UNSET:
            field_dict["handle"] = handle
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        handle = d.pop("handle", UNSET)

        description = d.pop("description", UNSET)

        controlplane_create_team_body = cls(
            name=name,
            handle=handle,
            description=description,
        )

        return controlplane_create_team_body
