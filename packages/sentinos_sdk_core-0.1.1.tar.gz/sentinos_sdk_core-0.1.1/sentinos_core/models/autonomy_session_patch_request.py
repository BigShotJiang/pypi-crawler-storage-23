from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.autonomy_risk_budget import AutonomyRiskBudget
    from ..models.autonomy_session_patch_request_metadata import AutonomySessionPatchRequestMetadata


T = TypeVar("T", bound="AutonomySessionPatchRequest")


@_attrs_define
class AutonomySessionPatchRequest:
    """
    Attributes:
        risk_budget_snapshot (AutonomyRiskBudget | Unset):
        budget_violation_reason (str | Unset):
        metadata (AutonomySessionPatchRequestMetadata | Unset):
    """

    risk_budget_snapshot: AutonomyRiskBudget | Unset = UNSET
    budget_violation_reason: str | Unset = UNSET
    metadata: AutonomySessionPatchRequestMetadata | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        risk_budget_snapshot: dict[str, Any] | Unset = UNSET
        if not isinstance(self.risk_budget_snapshot, Unset):
            risk_budget_snapshot = self.risk_budget_snapshot.to_dict()

        budget_violation_reason = self.budget_violation_reason

        metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metadata, Unset):
            metadata = self.metadata.to_dict()

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if risk_budget_snapshot is not UNSET:
            field_dict["risk_budget_snapshot"] = risk_budget_snapshot
        if budget_violation_reason is not UNSET:
            field_dict["budget_violation_reason"] = budget_violation_reason
        if metadata is not UNSET:
            field_dict["metadata"] = metadata

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.autonomy_risk_budget import AutonomyRiskBudget
        from ..models.autonomy_session_patch_request_metadata import AutonomySessionPatchRequestMetadata

        d = dict(src_dict)
        _risk_budget_snapshot = d.pop("risk_budget_snapshot", UNSET)
        risk_budget_snapshot: AutonomyRiskBudget | Unset
        if isinstance(_risk_budget_snapshot, Unset):
            risk_budget_snapshot = UNSET
        else:
            risk_budget_snapshot = AutonomyRiskBudget.from_dict(_risk_budget_snapshot)

        budget_violation_reason = d.pop("budget_violation_reason", UNSET)

        _metadata = d.pop("metadata", UNSET)
        metadata: AutonomySessionPatchRequestMetadata | Unset
        if isinstance(_metadata, Unset):
            metadata = UNSET
        else:
            metadata = AutonomySessionPatchRequestMetadata.from_dict(_metadata)

        autonomy_session_patch_request = cls(
            risk_budget_snapshot=risk_budget_snapshot,
            budget_violation_reason=budget_violation_reason,
            metadata=metadata,
        )

        return autonomy_session_patch_request
