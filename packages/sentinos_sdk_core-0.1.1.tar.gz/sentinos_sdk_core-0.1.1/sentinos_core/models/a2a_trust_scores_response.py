from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.a2a_trust_score import A2ATrustScore


T = TypeVar("T", bound="A2ATrustScoresResponse")


@_attrs_define
class A2ATrustScoresResponse:
    """
    Attributes:
        scores (list[A2ATrustScore]):
    """

    scores: list[A2ATrustScore]

    def to_dict(self) -> dict[str, Any]:
        scores = []
        for scores_item_data in self.scores:
            scores_item = scores_item_data.to_dict()
            scores.append(scores_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "scores": scores,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.a2a_trust_score import A2ATrustScore

        d = dict(src_dict)
        scores = []
        _scores = d.pop("scores")
        for scores_item_data in _scores:
            scores_item = A2ATrustScore.from_dict(scores_item_data)

            scores.append(scores_item)

        a2a_trust_scores_response = cls(
            scores=scores,
        )

        return a2a_trust_scores_response
