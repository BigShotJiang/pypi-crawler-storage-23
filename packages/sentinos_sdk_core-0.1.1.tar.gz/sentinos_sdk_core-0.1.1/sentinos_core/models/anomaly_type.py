from enum import Enum


class AnomalyType(str, Enum):
    PATTERN = "PATTERN"
    ZSCORE = "ZSCORE"

    def __str__(self) -> str:
        return str(self.value)
