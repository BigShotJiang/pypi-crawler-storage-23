from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define

from ..models.chronos_ingest_accepted_response_status import ChronosIngestAcceptedResponseStatus

T = TypeVar("T", bound="ChronosIngestAcceptedResponse")


@_attrs_define
class ChronosIngestAcceptedResponse:
    """
    Attributes:
        ingest_id (UUID):
        status (ChronosIngestAcceptedResponseStatus):
    """

    ingest_id: UUID
    status: ChronosIngestAcceptedResponseStatus

    def to_dict(self) -> dict[str, Any]:
        ingest_id = str(self.ingest_id)

        status = self.status.value

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "ingest_id": ingest_id,
                "status": status,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        ingest_id = UUID(d.pop("ingest_id"))

        status = ChronosIngestAcceptedResponseStatus(d.pop("status"))

        chronos_ingest_accepted_response = cls(
            ingest_id=ingest_id,
            status=status,
        )

        return chronos_ingest_accepted_response
