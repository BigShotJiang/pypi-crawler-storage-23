from enum import Enum


class ExportSIEMBodyFormat(str, Enum):
    CEF = "CEF"
    JSON = "JSON"

    def __str__(self) -> str:
        return str(self.value)
