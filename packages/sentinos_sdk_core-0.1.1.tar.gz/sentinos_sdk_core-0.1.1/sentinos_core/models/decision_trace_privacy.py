from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.decision_trace_privacy_events_item import DecisionTracePrivacyEventsItem


T = TypeVar("T", bound="DecisionTracePrivacy")


@_attrs_define
class DecisionTracePrivacy:
    """
    Attributes:
        policy_version (str | Unset):
        write_redaction_applied (bool | Unset):
        seal_applied (bool | Unset):
        seal_mode (str | Unset):
        events (list[DecisionTracePrivacyEventsItem] | Unset):
    """

    policy_version: str | Unset = UNSET
    write_redaction_applied: bool | Unset = UNSET
    seal_applied: bool | Unset = UNSET
    seal_mode: str | Unset = UNSET
    events: list[DecisionTracePrivacyEventsItem] | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        policy_version = self.policy_version

        write_redaction_applied = self.write_redaction_applied

        seal_applied = self.seal_applied

        seal_mode = self.seal_mode

        events: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.events, Unset):
            events = []
            for events_item_data in self.events:
                events_item = events_item_data.to_dict()
                events.append(events_item)

        field_dict: dict[str, Any] = {}

        field_dict.update({})
        if policy_version is not UNSET:
            field_dict["policy_version"] = policy_version
        if write_redaction_applied is not UNSET:
            field_dict["write_redaction_applied"] = write_redaction_applied
        if seal_applied is not UNSET:
            field_dict["seal_applied"] = seal_applied
        if seal_mode is not UNSET:
            field_dict["seal_mode"] = seal_mode
        if events is not UNSET:
            field_dict["events"] = events

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.decision_trace_privacy_events_item import DecisionTracePrivacyEventsItem

        d = dict(src_dict)
        policy_version = d.pop("policy_version", UNSET)

        write_redaction_applied = d.pop("write_redaction_applied", UNSET)

        seal_applied = d.pop("seal_applied", UNSET)

        seal_mode = d.pop("seal_mode", UNSET)

        _events = d.pop("events", UNSET)
        events: list[DecisionTracePrivacyEventsItem] | Unset = UNSET
        if _events is not UNSET:
            events = []
            for events_item_data in _events:
                events_item = DecisionTracePrivacyEventsItem.from_dict(events_item_data)

                events.append(events_item)

        decision_trace_privacy = cls(
            policy_version=policy_version,
            write_redaction_applied=write_redaction_applied,
            seal_applied=seal_applied,
            seal_mode=seal_mode,
            events=events,
        )

        return decision_trace_privacy
