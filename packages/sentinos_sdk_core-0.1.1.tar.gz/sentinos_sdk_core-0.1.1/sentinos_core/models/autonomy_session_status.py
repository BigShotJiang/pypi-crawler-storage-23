from enum import Enum


class AutonomySessionStatus(str, Enum):
    ACTIVE = "ACTIVE"
    PAUSED = "PAUSED"
    TERMINATED = "TERMINATED"

    def __str__(self) -> str:
        return str(self.value)
