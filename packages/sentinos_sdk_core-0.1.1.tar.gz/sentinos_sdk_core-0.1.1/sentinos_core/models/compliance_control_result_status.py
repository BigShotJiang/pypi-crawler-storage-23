from enum import Enum


class ComplianceControlResultStatus(str, Enum):
    ATTENTION = "ATTENTION"
    PASS = "PASS"

    def __str__(self) -> str:
        return str(self.value)
