from enum import Enum


class AuthMePrincipalType(str, Enum):
    HUMAN = "HUMAN"
    SERVICE = "SERVICE"
    WORKFORCE = "WORKFORCE"

    def __str__(self) -> str:
        return str(self.value)
