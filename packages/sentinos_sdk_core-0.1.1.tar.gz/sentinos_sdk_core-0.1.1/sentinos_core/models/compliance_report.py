from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.audit_log_entry import AuditLogEntry
    from ..models.compliance_report_metrics import ComplianceReportMetrics


T = TypeVar("T", bound="ComplianceReport")


@_attrs_define
class ComplianceReport:
    """
    Attributes:
        tenant_id (str | Unset):
        generated_at (datetime.datetime | Unset):
        window_start (datetime.datetime | Unset):
        window_end (datetime.datetime | Unset):
        metrics (ComplianceReportMetrics | Unset):
        recent_audit_items (list[AuditLogEntry] | Unset):
    """

    tenant_id: str | Unset = UNSET
    generated_at: datetime.datetime | Unset = UNSET
    window_start: datetime.datetime | Unset = UNSET
    window_end: datetime.datetime | Unset = UNSET
    metrics: ComplianceReportMetrics | Unset = UNSET
    recent_audit_items: list[AuditLogEntry] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        tenant_id = self.tenant_id

        generated_at: str | Unset = UNSET
        if not isinstance(self.generated_at, Unset):
            generated_at = self.generated_at.isoformat()

        window_start: str | Unset = UNSET
        if not isinstance(self.window_start, Unset):
            window_start = self.window_start.isoformat()

        window_end: str | Unset = UNSET
        if not isinstance(self.window_end, Unset):
            window_end = self.window_end.isoformat()

        metrics: dict[str, Any] | Unset = UNSET
        if not isinstance(self.metrics, Unset):
            metrics = self.metrics.to_dict()

        recent_audit_items: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.recent_audit_items, Unset):
            recent_audit_items = []
            for recent_audit_items_item_data in self.recent_audit_items:
                recent_audit_items_item = recent_audit_items_item_data.to_dict()
                recent_audit_items.append(recent_audit_items_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if tenant_id is not UNSET:
            field_dict["tenant_id"] = tenant_id
        if generated_at is not UNSET:
            field_dict["generated_at"] = generated_at
        if window_start is not UNSET:
            field_dict["window_start"] = window_start
        if window_end is not UNSET:
            field_dict["window_end"] = window_end
        if metrics is not UNSET:
            field_dict["metrics"] = metrics
        if recent_audit_items is not UNSET:
            field_dict["recent_audit_items"] = recent_audit_items

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.audit_log_entry import AuditLogEntry
        from ..models.compliance_report_metrics import ComplianceReportMetrics

        d = dict(src_dict)
        tenant_id = d.pop("tenant_id", UNSET)

        _generated_at = d.pop("generated_at", UNSET)
        generated_at: datetime.datetime | Unset
        if isinstance(_generated_at, Unset):
            generated_at = UNSET
        else:
            generated_at = isoparse(_generated_at)

        _window_start = d.pop("window_start", UNSET)
        window_start: datetime.datetime | Unset
        if isinstance(_window_start, Unset):
            window_start = UNSET
        else:
            window_start = isoparse(_window_start)

        _window_end = d.pop("window_end", UNSET)
        window_end: datetime.datetime | Unset
        if isinstance(_window_end, Unset):
            window_end = UNSET
        else:
            window_end = isoparse(_window_end)

        _metrics = d.pop("metrics", UNSET)
        metrics: ComplianceReportMetrics | Unset
        if isinstance(_metrics, Unset):
            metrics = UNSET
        else:
            metrics = ComplianceReportMetrics.from_dict(_metrics)

        _recent_audit_items = d.pop("recent_audit_items", UNSET)
        recent_audit_items: list[AuditLogEntry] | Unset = UNSET
        if _recent_audit_items is not UNSET:
            recent_audit_items = []
            for recent_audit_items_item_data in _recent_audit_items:
                recent_audit_items_item = AuditLogEntry.from_dict(recent_audit_items_item_data)

                recent_audit_items.append(recent_audit_items_item)

        compliance_report = cls(
            tenant_id=tenant_id,
            generated_at=generated_at,
            window_start=window_start,
            window_end=window_end,
            metrics=metrics,
            recent_audit_items=recent_audit_items,
        )

        compliance_report.additional_properties = d
        return compliance_report

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
