from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

from ..types import UNSET, Unset

T = TypeVar("T", bound="ControlplaneAcceptInvitationRequest")


@_attrs_define
class ControlplaneAcceptInvitationRequest:
    """
    Attributes:
        token (str):
        email (str):
        password (str):
        display_name (str | Unset):
    """

    token: str
    email: str
    password: str
    display_name: str | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        token = self.token

        email = self.email

        password = self.password

        display_name = self.display_name

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "token": token,
                "email": email,
                "password": password,
            }
        )
        if display_name is not UNSET:
            field_dict["display_name"] = display_name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        token = d.pop("token")

        email = d.pop("email")

        password = d.pop("password")

        display_name = d.pop("display_name", UNSET)

        controlplane_accept_invitation_request = cls(
            token=token,
            email=email,
            password=password,
            display_name=display_name,
        )

        return controlplane_accept_invitation_request
