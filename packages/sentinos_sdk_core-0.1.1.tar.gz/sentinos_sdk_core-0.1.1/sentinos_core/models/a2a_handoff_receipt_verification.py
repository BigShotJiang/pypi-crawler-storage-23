from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from dateutil.parser import isoparse

T = TypeVar("T", bound="A2AHandoffReceiptVerification")


@_attrs_define
class A2AHandoffReceiptVerification:
    """
    Attributes:
        handoff_id (str):
        receipt_id (str):
        decision (str):
        issued_at (datetime.datetime):
        verified (bool):
        reason (str):
        observed_signature (str):
        expected_signature (str):
        verification_source (str):
    """

    handoff_id: str
    receipt_id: str
    decision: str
    issued_at: datetime.datetime
    verified: bool
    reason: str
    observed_signature: str
    expected_signature: str
    verification_source: str

    def to_dict(self) -> dict[str, Any]:
        handoff_id = self.handoff_id

        receipt_id = self.receipt_id

        decision = self.decision

        issued_at = self.issued_at.isoformat()

        verified = self.verified

        reason = self.reason

        observed_signature = self.observed_signature

        expected_signature = self.expected_signature

        verification_source = self.verification_source

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "handoff_id": handoff_id,
                "receipt_id": receipt_id,
                "decision": decision,
                "issued_at": issued_at,
                "verified": verified,
                "reason": reason,
                "observed_signature": observed_signature,
                "expected_signature": expected_signature,
                "verification_source": verification_source,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        handoff_id = d.pop("handoff_id")

        receipt_id = d.pop("receipt_id")

        decision = d.pop("decision")

        issued_at = isoparse(d.pop("issued_at"))

        verified = d.pop("verified")

        reason = d.pop("reason")

        observed_signature = d.pop("observed_signature")

        expected_signature = d.pop("expected_signature")

        verification_source = d.pop("verification_source")

        a2a_handoff_receipt_verification = cls(
            handoff_id=handoff_id,
            receipt_id=receipt_id,
            decision=decision,
            issued_at=issued_at,
            verified=verified,
            reason=reason,
            observed_signature=observed_signature,
            expected_signature=expected_signature,
            verification_source=verification_source,
        )

        return a2a_handoff_receipt_verification
