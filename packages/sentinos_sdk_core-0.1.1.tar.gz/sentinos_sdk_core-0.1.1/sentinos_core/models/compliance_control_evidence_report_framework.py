from enum import Enum


class ComplianceControlEvidenceReportFramework(str, Enum):
    ALL = "ALL"
    FEDRAMP = "FEDRAMP"
    HIPAA = "HIPAA"
    SOC2 = "SOC2"

    def __str__(self) -> str:
        return str(self.value)
