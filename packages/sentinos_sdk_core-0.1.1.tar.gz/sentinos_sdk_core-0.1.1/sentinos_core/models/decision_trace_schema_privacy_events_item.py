from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define

T = TypeVar("T", bound="DecisionTraceSchemaPrivacyEventsItem")


@_attrs_define
class DecisionTraceSchemaPrivacyEventsItem:
    """
    Attributes:
        redaction_rule_id (str):
        field_path (str):
        match_type (str):
        before_hash (str):
        after_hash (str):
        reason (str):
    """

    redaction_rule_id: str
    field_path: str
    match_type: str
    before_hash: str
    after_hash: str
    reason: str

    def to_dict(self) -> dict[str, Any]:
        redaction_rule_id = self.redaction_rule_id

        field_path = self.field_path

        match_type = self.match_type

        before_hash = self.before_hash

        after_hash = self.after_hash

        reason = self.reason

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "redaction_rule_id": redaction_rule_id,
                "field_path": field_path,
                "match_type": match_type,
                "before_hash": before_hash,
                "after_hash": after_hash,
                "reason": reason,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        redaction_rule_id = d.pop("redaction_rule_id")

        field_path = d.pop("field_path")

        match_type = d.pop("match_type")

        before_hash = d.pop("before_hash")

        after_hash = d.pop("after_hash")

        reason = d.pop("reason")

        decision_trace_schema_privacy_events_item = cls(
            redaction_rule_id=redaction_rule_id,
            field_path=field_path,
            match_type=match_type,
            before_hash=before_hash,
            after_hash=after_hash,
            reason=reason,
        )

        return decision_trace_schema_privacy_events_item
