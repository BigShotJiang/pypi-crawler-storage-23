from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar
from uuid import UUID

from attrs import define as _attrs_define
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="AuthNMappingRecord")


@_attrs_define
class AuthNMappingRecord:
    """
    Attributes:
        mapping_id (UUID):
        org_id (UUID):
        attribute_key (str):
        attribute_value (str):
        target_role_id (UUID):
        priority (int):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        target_team_id (UUID | Unset):
    """

    mapping_id: UUID
    org_id: UUID
    attribute_key: str
    attribute_value: str
    target_role_id: UUID
    priority: int
    created_at: datetime.datetime
    updated_at: datetime.datetime
    target_team_id: UUID | Unset = UNSET

    def to_dict(self) -> dict[str, Any]:
        mapping_id = str(self.mapping_id)

        org_id = str(self.org_id)

        attribute_key = self.attribute_key

        attribute_value = self.attribute_value

        target_role_id = str(self.target_role_id)

        priority = self.priority

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        target_team_id: str | Unset = UNSET
        if not isinstance(self.target_team_id, Unset):
            target_team_id = str(self.target_team_id)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "mapping_id": mapping_id,
                "org_id": org_id,
                "attribute_key": attribute_key,
                "attribute_value": attribute_value,
                "target_role_id": target_role_id,
                "priority": priority,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if target_team_id is not UNSET:
            field_dict["target_team_id"] = target_team_id

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        mapping_id = UUID(d.pop("mapping_id"))

        org_id = UUID(d.pop("org_id"))

        attribute_key = d.pop("attribute_key")

        attribute_value = d.pop("attribute_value")

        target_role_id = UUID(d.pop("target_role_id"))

        priority = d.pop("priority")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        _target_team_id = d.pop("target_team_id", UNSET)
        target_team_id: UUID | Unset
        if isinstance(_target_team_id, Unset):
            target_team_id = UNSET
        else:
            target_team_id = UUID(_target_team_id)

        auth_n_mapping_record = cls(
            mapping_id=mapping_id,
            org_id=org_id,
            attribute_key=attribute_key,
            attribute_value=attribute_value,
            target_role_id=target_role_id,
            priority=priority,
            created_at=created_at,
            updated_at=updated_at,
            target_team_id=target_team_id,
        )

        return auth_n_mapping_record
