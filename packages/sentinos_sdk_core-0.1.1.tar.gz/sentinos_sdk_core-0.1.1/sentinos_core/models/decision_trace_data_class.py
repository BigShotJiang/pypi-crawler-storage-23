from enum import Enum


class DecisionTraceDataClass(str, Enum):
    CONFIDENTIAL = "CONFIDENTIAL"
    INTERNAL = "INTERNAL"
    PUBLIC = "PUBLIC"
    REGULATED = "REGULATED"
    SECRET = "SECRET"

    def __str__(self) -> str:
        return str(self.value)
