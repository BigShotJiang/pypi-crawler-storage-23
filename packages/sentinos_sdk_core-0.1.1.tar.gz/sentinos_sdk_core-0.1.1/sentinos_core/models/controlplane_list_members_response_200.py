from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define

if TYPE_CHECKING:
    from ..models.member_record import MemberRecord


T = TypeVar("T", bound="ControlplaneListMembersResponse200")


@_attrs_define
class ControlplaneListMembersResponse200:
    """
    Attributes:
        members (list[MemberRecord]):
    """

    members: list[MemberRecord]

    def to_dict(self) -> dict[str, Any]:
        members = []
        for members_item_data in self.members:
            members_item = members_item_data.to_dict()
            members.append(members_item)

        field_dict: dict[str, Any] = {}

        field_dict.update(
            {
                "members": members,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.member_record import MemberRecord

        d = dict(src_dict)
        members = []
        _members = d.pop("members")
        for members_item_data in _members:
            members_item = MemberRecord.from_dict(members_item_data)

            members.append(members_item)

        controlplane_list_members_response_200 = cls(
            members=members,
        )

        return controlplane_list_members_response_200
