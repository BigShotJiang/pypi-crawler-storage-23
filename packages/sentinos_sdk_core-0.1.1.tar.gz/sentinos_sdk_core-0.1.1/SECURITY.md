# Security Policy

## Reporting a vulnerability

If you believe you have found a security vulnerability in this repository, please report it privately.

- Email: security@sentinoshq.com

Please include as much detail as possible to help us reproduce and triage the issue.

