from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_evidence_list_response_schema import APIResponseModelEvidenceListResponseSchema
from ...models.compliance_query_evidence_body_params import ComplianceQueryEvidenceBodyParams
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: ComplianceQueryEvidenceBodyParams,
    stack_id: None | str | Unset = UNSET,
    evidence_type: None | str | Unset = UNSET,
    validation_id: None | str | Unset = UNSET,
    created_after: None | str | Unset = UNSET,
    created_before: None | str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_stack_id: None | str | Unset
    if isinstance(stack_id, Unset):
        json_stack_id = UNSET
    else:
        json_stack_id = stack_id
    params["stack_id"] = json_stack_id

    json_evidence_type: None | str | Unset
    if isinstance(evidence_type, Unset):
        json_evidence_type = UNSET
    else:
        json_evidence_type = evidence_type
    params["evidence_type"] = json_evidence_type

    json_validation_id: None | str | Unset
    if isinstance(validation_id, Unset):
        json_validation_id = UNSET
    else:
        json_validation_id = validation_id
    params["validation_id"] = json_validation_id

    json_created_after: None | str | Unset
    if isinstance(created_after, Unset):
        json_created_after = UNSET
    else:
        json_created_after = created_after
    params["created_after"] = json_created_after

    json_created_before: None | str | Unset
    if isinstance(created_before, Unset):
        json_created_before = UNSET
    else:
        json_created_before = created_before
    params["created_before"] = json_created_before

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/compliance/stacks/evidence",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelEvidenceListResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelEvidenceListResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelEvidenceListResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ComplianceQueryEvidenceBodyParams,
    stack_id: None | str | Unset = UNSET,
    evidence_type: None | str | Unset = UNSET,
    validation_id: None | str | Unset = UNSET,
    created_after: None | str | Unset = UNSET,
    created_before: None | str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[APIResponseModelEvidenceListResponseSchema]:
    """Query stack evidence


            Query evidence with filtering by frameworks, control IDs, date range, and more.
            Uses PostgreSQL GIN indexes for efficient framework and control filtering.


    Args:
        stack_id (None | str | Unset):
        evidence_type (None | str | Unset):
        validation_id (None | str | Unset):
        created_after (None | str | Unset):
        created_before (None | str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        body (ComplianceQueryEvidenceBodyParams):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelEvidenceListResponseSchema]
    """

    kwargs = _get_kwargs(
        body=body,
        stack_id=stack_id,
        evidence_type=evidence_type,
        validation_id=validation_id,
        created_after=created_after,
        created_before=created_before,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ComplianceQueryEvidenceBodyParams,
    stack_id: None | str | Unset = UNSET,
    evidence_type: None | str | Unset = UNSET,
    validation_id: None | str | Unset = UNSET,
    created_after: None | str | Unset = UNSET,
    created_before: None | str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> APIResponseModelEvidenceListResponseSchema | None:
    """Query stack evidence


            Query evidence with filtering by frameworks, control IDs, date range, and more.
            Uses PostgreSQL GIN indexes for efficient framework and control filtering.


    Args:
        stack_id (None | str | Unset):
        evidence_type (None | str | Unset):
        validation_id (None | str | Unset):
        created_after (None | str | Unset):
        created_before (None | str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        body (ComplianceQueryEvidenceBodyParams):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelEvidenceListResponseSchema
    """

    return sync_detailed(
        client=client,
        body=body,
        stack_id=stack_id,
        evidence_type=evidence_type,
        validation_id=validation_id,
        created_after=created_after,
        created_before=created_before,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ComplianceQueryEvidenceBodyParams,
    stack_id: None | str | Unset = UNSET,
    evidence_type: None | str | Unset = UNSET,
    validation_id: None | str | Unset = UNSET,
    created_after: None | str | Unset = UNSET,
    created_before: None | str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[APIResponseModelEvidenceListResponseSchema]:
    """Query stack evidence


            Query evidence with filtering by frameworks, control IDs, date range, and more.
            Uses PostgreSQL GIN indexes for efficient framework and control filtering.


    Args:
        stack_id (None | str | Unset):
        evidence_type (None | str | Unset):
        validation_id (None | str | Unset):
        created_after (None | str | Unset):
        created_before (None | str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        body (ComplianceQueryEvidenceBodyParams):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelEvidenceListResponseSchema]
    """

    kwargs = _get_kwargs(
        body=body,
        stack_id=stack_id,
        evidence_type=evidence_type,
        validation_id=validation_id,
        created_after=created_after,
        created_before=created_before,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ComplianceQueryEvidenceBodyParams,
    stack_id: None | str | Unset = UNSET,
    evidence_type: None | str | Unset = UNSET,
    validation_id: None | str | Unset = UNSET,
    created_after: None | str | Unset = UNSET,
    created_before: None | str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> APIResponseModelEvidenceListResponseSchema | None:
    """Query stack evidence


            Query evidence with filtering by frameworks, control IDs, date range, and more.
            Uses PostgreSQL GIN indexes for efficient framework and control filtering.


    Args:
        stack_id (None | str | Unset):
        evidence_type (None | str | Unset):
        validation_id (None | str | Unset):
        created_after (None | str | Unset):
        created_before (None | str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        body (ComplianceQueryEvidenceBodyParams):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelEvidenceListResponseSchema
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            stack_id=stack_id,
            evidence_type=evidence_type,
            validation_id=validation_id,
            created_after=created_after,
            created_before=created_before,
            limit=limit,
            offset=offset,
        )
    ).parsed
