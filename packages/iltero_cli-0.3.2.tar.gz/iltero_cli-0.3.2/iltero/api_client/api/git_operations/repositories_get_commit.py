from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.api_response_model_commit_detail_response_schema import APIResponseModelCommitDetailResponseSchema
from ...types import Response


def _get_kwargs(
    repository_id: str,
    commit_sha: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/git/{repository_id}/commits/{commit_sha}".format(
            repository_id=quote(str(repository_id), safe=""),
            commit_sha=quote(str(commit_sha), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> APIResponseModelCommitDetailResponseSchema | None:
    if response.status_code == 200:
        response_200 = APIResponseModelCommitDetailResponseSchema.from_dict(response.json())

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[APIResponseModelCommitDetailResponseSchema]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    repository_id: str,
    commit_sha: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelCommitDetailResponseSchema]:
    """Get Commit Details


            Get detailed information about a specific commit.

            Returns commit message, author, timestamp, changed files, and diff information.


    Args:
        repository_id (str):
        commit_sha (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelCommitDetailResponseSchema]
    """

    kwargs = _get_kwargs(
        repository_id=repository_id,
        commit_sha=commit_sha,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    repository_id: str,
    commit_sha: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelCommitDetailResponseSchema | None:
    """Get Commit Details


            Get detailed information about a specific commit.

            Returns commit message, author, timestamp, changed files, and diff information.


    Args:
        repository_id (str):
        commit_sha (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelCommitDetailResponseSchema
    """

    return sync_detailed(
        repository_id=repository_id,
        commit_sha=commit_sha,
        client=client,
    ).parsed


async def asyncio_detailed(
    repository_id: str,
    commit_sha: str,
    *,
    client: AuthenticatedClient,
) -> Response[APIResponseModelCommitDetailResponseSchema]:
    """Get Commit Details


            Get detailed information about a specific commit.

            Returns commit message, author, timestamp, changed files, and diff information.


    Args:
        repository_id (str):
        commit_sha (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[APIResponseModelCommitDetailResponseSchema]
    """

    kwargs = _get_kwargs(
        repository_id=repository_id,
        commit_sha=commit_sha,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    repository_id: str,
    commit_sha: str,
    *,
    client: AuthenticatedClient,
) -> APIResponseModelCommitDetailResponseSchema | None:
    """Get Commit Details


            Get detailed information about a specific commit.

            Returns commit message, author, timestamp, changed files, and diff information.


    Args:
        repository_id (str):
        commit_sha (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        APIResponseModelCommitDetailResponseSchema
    """

    return (
        await asyncio_detailed(
            repository_id=repository_id,
            commit_sha=commit_sha,
            client=client,
        )
    ).parsed
